"""
app.py — djhudpicam v0.1.3
Changes from 0.1.2:
 - Removed auto-tracking (overkill for Pi Zero 2 W)
 - Cam preview freezes when streaming (shows last frame)
 - Shift+drag handle = proportional scale on HUD strip
 - FIX: re-pick warp now recalculates out_w/out_h
 - Perspective handles draggable directly on cam preview (no modal dialog)
   Select region → drag corners → press Enter to confirm / Esc to revert
"""

from __future__ import annotations
import json, logging, os, threading, time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Optional
import numpy as np

from . import __version__
from .camera import CameraCapture, RESOLUTIONS
from .region import Region, RegionSet
from .output import OutputManager, VpnStreamOutput, VdoNinjaOutput, VirtualCamOutput

try:
    from PIL import Image, ImageTk, ImageDraw
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

log = logging.getLogger(__name__)

PREVIEW_W = 640
PREVIEW_H = 360
STRIP_H = 100
STRIP_PADDING = 20
CONFIG_FILE = os.path.expanduser("~/.djhudpicam_config.json")
HANDLE_SIZE = 4
HANDLE_HIT = 6
CORNER_COLORS = ["#FF4444", "#44FF44", "#4488FF", "#FFFF44"]
CORNER_LABELS = ["TL", "TR", "BR", "BL"]
DOT_R = 7  # perspective handle radius on cam preview


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"DJ HUD PiCam v{__version__}")
        self.configure(bg="#1e1e2e")
        self.resizable(True, True)

        self.camera = CameraCapture(width=1280, height=720, fps=30)
        self.regions = RegionSet()
        self.outputs = OutputManager()

        self._running = False
        self._streaming = False  # True when any output is active
        self._preview_thread: Optional[threading.Thread] = None
        self._latest_frame: Optional[np.ndarray] = None
        self._latest_strip: Optional[np.ndarray] = None
        self._frame_lock = threading.Lock()

        # Corner-pick mode: adding new regions (4 clicks)
        self._picking = False
        self._pick_pts: list = []
        self._region_counter = 0

        # Perspective handle dragging on cam preview
        self._warp_drag_idx: Optional[int] = None    # region index
        self._warp_drag_corner: Optional[int] = None  # corner 0-3
        self._warp_backup: Optional[list] = None       # backup for Esc revert

        # Strip drag state (output preview)
        self._drag_idx: Optional[int] = None
        self._drag_mode: Optional[str] = None
        self._drag_mouse: tuple = (0, 0)
        self._drag_geom: tuple = (0, 0, 0, 0)
        self._drag_shift: bool = False  # shift held during drag

        self._strip_w = 1080
        self._strip_h = STRIP_H
        self._editor_loading = False

        self._build_ui()
        self._load_config()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ==================================================================
    # UI
    # ==================================================================

    def _build_ui(self):
        s = ttk.Style(self); s.theme_use("clam")
        s.configure(".", background="#1e1e2e", foreground="#cdd6f4",
                    fieldbackground="#313244", troughcolor="#313244")
        s.configure("TButton", background="#313244", foreground="#cdd6f4", relief="flat", padding=4)
        s.map("TButton", background=[("active", "#45475a")])
        s.configure("Accent.TButton", background="#89b4fa", foreground="#1e1e2e")
        for w in ("TLabel","TFrame"):
            s.configure(w, background="#1e1e2e", foreground="#cdd6f4")
        s.configure("TLabelframe", background="#1e1e2e", foreground="#89b4fa")
        s.configure("TLabelframe.Label", background="#1e1e2e", foreground="#89b4fa")

        # ── Toolbar ──
        tb = ttk.Frame(self, padding=4); tb.pack(fill=tk.X)
        ttk.Label(tb, text="Res:").pack(side=tk.LEFT)
        self._res_var = tk.StringVar(value="1280x720")
        ttk.Combobox(tb, textvariable=self._res_var,
                     values=[f"{w}x{h}" for w,h in RESOLUTIONS],
                     width=11, state="readonly").pack(side=tk.LEFT, padx=4)
        ttk.Label(tb, text="FPS:").pack(side=tk.LEFT, padx=(6,0))
        self._fps_var = tk.StringVar(value="30")
        ttk.Combobox(tb, textvariable=self._fps_var,
                     values=["10","15","20","25","30","60"], width=4,
                     state="readonly").pack(side=tk.LEFT, padx=4)
        self._start_btn = ttk.Button(tb, text="Start Camera", style="Accent.TButton",
                                     command=self._toggle_camera)
        self._start_btn.pack(side=tk.LEFT, padx=8)
        ttk.Button(tb, text="Save", command=self._save_config).pack(side=tk.LEFT, padx=2)
        ttk.Button(tb, text="Load", command=self._load_config_dialog).pack(side=tk.LEFT, padx=2)

        # ── Main ──
        main = ttk.Frame(self, padding=4); main.pack(fill=tk.BOTH, expand=True)

        # Camera preview
        pf = ttk.LabelFrame(main, text="Camera Preview (drag corners to edit warp)", padding=4)
        pf.grid(row=0, column=0, sticky="nsew", padx=(0,4))
        self._cam_cv = tk.Canvas(pf, width=PREVIEW_W, height=PREVIEW_H,
                                 bg="#11111b", highlightthickness=0)
        self._cam_cv.pack()
        self._cam_cv.bind("<Button-1>", self._on_cam_click)
        self._cam_cv.bind("<B1-Motion>", self._on_cam_drag)
        self._cam_cv.bind("<ButtonRelease-1>", self._on_cam_release)
        self._cam_cv.bind("<Button-3>", self._on_cam_rclick)
        self.bind("<Return>", self._on_enter)
        self.bind("<Escape>", self._on_escape)

        # Right panel
        rp = ttk.Frame(main); rp.grid(row=0, column=1, sticky="nsew", padx=(4,0))

        # Region list
        lf = ttk.LabelFrame(rp, text="Regions", padding=4); lf.pack(fill=tk.BOTH, expand=True)
        self._rlist = tk.Listbox(lf, width=28, height=8, bg="#313244", fg="#cdd6f4",
                                 selectbackground="#89b4fa", selectforeground="#1e1e2e",
                                 activestyle="none")
        self._rlist.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        self._rlist.bind("<<ListboxSelect>>", self._on_rlist_select)
        bb = ttk.Frame(lf); bb.pack(fill=tk.X)
        ttk.Button(bb, text="+ Add (4 clicks)", command=self._add_region).pack(side=tk.LEFT, padx=2)
        ttk.Button(bb, text="Del", command=self._del_region).pack(side=tk.LEFT, padx=2)
        ttk.Button(bb, text="Up", command=lambda: self._move(-1)).pack(side=tk.LEFT, padx=1)
        ttk.Button(bb, text="Dn", command=lambda: self._move(1)).pack(side=tk.LEFT, padx=1)

        # Editor panel
        ed = ttk.LabelFrame(rp, text="Region Editor", padding=6); ed.pack(fill=tk.X, pady=(4,0))
        ttk.Label(ed, text="Name").grid(row=0, column=0, sticky="w")
        self._ed_name = tk.StringVar(); self._ed_name.trace_add("write", self._ed_apply)
        ttk.Entry(ed, textvariable=self._ed_name, width=14).grid(row=0, column=1, columnspan=3, sticky="ew", padx=(4,0))
        for row, (la, lb, va, vb) in enumerate([("X","Y","_ed_ox","_ed_oy"),("W","H","_ed_ow","_ed_oh")], start=1):
            ttk.Label(ed, text=la).grid(row=row, column=0, sticky="w", pady=(4,0))
            v1 = tk.IntVar(); setattr(self, va, v1); v1.trace_add("write", self._ed_apply)
            ttk.Spinbox(ed, from_=-5000, to=8000, textvariable=v1, width=6).grid(row=row, column=1, sticky="ew", padx=(4,0), pady=(4,0))
            ttk.Label(ed, text=lb).grid(row=row, column=2, sticky="e", padx=(4,0), pady=(4,0))
            v2 = tk.IntVar(); setattr(self, vb, v2); v2.trace_add("write", self._ed_apply)
            ttk.Spinbox(ed, from_=-5000, to=8000, textvariable=v2, width=6).grid(row=row, column=3, sticky="ew", padx=(4,0), pady=(4,0))
        self._ed_enabled = tk.BooleanVar(value=True); self._ed_enabled.trace_add("write", self._ed_apply)
        ttk.Checkbutton(ed, text="Enabled", variable=self._ed_enabled).grid(row=3, column=0, columnspan=2, sticky="w", pady=(4,0))
        self._ed_locked = tk.BooleanVar(); self._ed_locked.trace_add("write", self._ed_apply)
        ttk.Checkbutton(ed, text="Locked", variable=self._ed_locked).grid(row=3, column=2, columnspan=2, sticky="w", pady=(4,0))
        ttk.Button(ed, text="Clear Warp", command=self._clear_warp).grid(row=4, column=0, columnspan=4, sticky="ew", pady=(6,0))
        ed.columnconfigure(1, weight=1); ed.columnconfigure(3, weight=1)

        # Snap
        sr = ttk.Frame(rp); sr.pack(fill=tk.X, pady=(4,0))
        self._snap = tk.BooleanVar(value=True)
        ttk.Checkbutton(sr, text="Snap to grid", variable=self._snap).pack(side=tk.LEFT)
        ttk.Label(sr, text="Size:").pack(side=tk.LEFT, padx=(8,2))
        self._gsz = tk.IntVar(value=10)
        ttk.Spinbox(sr, from_=1, to=100, textvariable=self._gsz, width=4).pack(side=tk.LEFT)

        main.columnconfigure(0, weight=3); main.columnconfigure(1, weight=1); main.rowconfigure(0, weight=1)

        # ── Strip preview ──
        sf = ttk.LabelFrame(self, text="HUD Strip — drag to move, handles to resize (Shift=scale), arrows to nudge", padding=4)
        sf.pack(fill=tk.X, padx=4, pady=4)
        szr = ttk.Frame(sf); szr.pack(fill=tk.X, pady=(0,4))
        ttk.Label(szr, text="Canvas W:").pack(side=tk.LEFT)
        self._cw = tk.IntVar(value=1080)
        ttk.Spinbox(szr, from_=100, to=8000, textvariable=self._cw, width=6).pack(side=tk.LEFT, padx=(2,8))
        ttk.Label(szr, text="H:").pack(side=tk.LEFT)
        self._ch = tk.IntVar(value=STRIP_H)
        ttk.Spinbox(szr, from_=10, to=4000, textvariable=self._ch, width=6).pack(side=tk.LEFT, padx=(2,0))
        self._strip_cv = tk.Canvas(sf, height=STRIP_H+STRIP_PADDING*2, bg="#1b1b1b",
                                   highlightthickness=0, takefocus=True)
        self._strip_cv.pack(fill=tk.X)
        self._strip_cv.bind("<Button-1>", self._sc_click)
        self._strip_cv.bind("<B1-Motion>", self._sc_drag)
        self._strip_cv.bind("<ButtonRelease-1>", self._sc_release)
        for seq in ("<Left>","<Right>","<Up>","<Down>",
                     "<Shift-Left>","<Shift-Right>","<Shift-Up>","<Shift-Down>"):
            self._strip_cv.bind(seq, self._sc_arrow)

        # ── Outputs ──
        of = ttk.LabelFrame(self, text="Outputs", padding=6); of.pack(fill=tk.X, padx=4, pady=4)
        self._vpn_var = tk.BooleanVar(); self._vdo_var = tk.BooleanVar(); self._vcam_var = tk.BooleanVar()
        ttk.Checkbutton(of, text="VPN WebSocket", variable=self._vpn_var, command=self._tog_vpn).grid(row=0,column=0,sticky="w",padx=8)
        ttk.Label(of, text="Port:").grid(row=0,column=1,sticky="e")
        self._vpn_port = tk.StringVar(value="8765")
        ttk.Entry(of, textvariable=self._vpn_port, width=6).grid(row=0,column=2,padx=4)
        self._vpn_url = ttk.Label(of, text="", foreground="#a6e3a1"); self._vpn_url.grid(row=0,column=3,padx=8)
        ttk.Checkbutton(of, text="VDO.Ninja", variable=self._vdo_var, command=self._tog_vdo).grid(row=1,column=0,sticky="w",padx=8,pady=2)
        ttk.Label(of, text="Room:").grid(row=1,column=1,sticky="e")
        self._vdo_room = tk.StringVar(value="djhudpicam")
        ttk.Entry(of, textvariable=self._vdo_room, width=14).grid(row=1,column=2,padx=4)
        ttk.Checkbutton(of, text="Virtual Camera", variable=self._vcam_var, command=self._tog_vcam).grid(row=2,column=0,sticky="w",padx=8,pady=2)

        # ── Status ──
        self._status_var = tk.StringVar(value="Ready.")
        ttk.Label(self, textvariable=self._status_var, foreground="#6c7086", anchor="w").pack(fill=tk.X, padx=6, pady=(0,4))

    # ==================================================================
    # Camera
    # ==================================================================

    def _toggle_camera(self):
        if self._running: self._stop_cam()
        else: self._start_cam()

    def _start_cam(self):
        w, h = self._parse_res()
        fps = int(self._fps_var.get())
        self.camera.width, self.camera.height, self.camera.fps = w, h, fps
        backend = self.camera.start()
        self._running = True
        self._start_btn.config(text="Stop Camera")
        self._status(f"Camera started ({backend}) @ {w}x{h} {fps}fps")
        self._preview_thread = threading.Thread(target=self._loop, daemon=True)
        self._preview_thread.start()

    def _stop_cam(self):
        self._running = False; self.camera.stop()
        self._start_btn.config(text="Start Camera"); self._status("Camera stopped.")

    def _parse_res(self):
        t = self._res_var.get().replace("\u00d7","x"); w,h = t.split("x"); return int(w), int(h)

    def _update_streaming_state(self):
        self._streaming = bool(self.outputs.vpn or self.outputs.vdoninja or self.outputs.virtualcam)

    # ==================================================================
    # Main loop
    # ==================================================================

    def _loop(self):
        while self._running:
            frame = self.camera.get_frame()
            if frame is not None:
                cw, ch = max(100, self._cw.get()), max(10, self._ch.get())
                strip = self.regions.composite(frame, cw, ch)
                with self._frame_lock:
                    self._latest_frame = frame
                    self._latest_strip = strip
                    self._strip_w, self._strip_h = cw, ch
                self.after(0, self._update_display)
            time.sleep(1/30)

    def _update_display(self):
        with self._frame_lock:
            frame, strip = self._latest_frame, self._latest_strip
        if frame is None: return
        if HAS_PIL:
            # Freeze cam preview when streaming (save CPU)
            if not self._streaming:
                self._draw_cam(frame)
            self._draw_strip(strip)
        if strip is not None:
            self.outputs.push_frame(strip)

    # ==================================================================
    # Camera preview drawing
    # ==================================================================

    def _cam_scale(self):
        """Return (sx, sy) from camera pixels to display pixels."""
        if self._latest_frame is None: return 1.0, 1.0
        fh, fw = self._latest_frame.shape[:2]
        return PREVIEW_W / fw, PREVIEW_H / fh

    def _draw_cam(self, frame):
        if not HAS_PIL: return
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) if HAS_CV2 else frame
        img = Image.fromarray(rgb).resize((PREVIEW_W, PREVIEW_H), Image.NEAREST)
        draw = ImageDraw.Draw(img)
        sx, sy = self._cam_scale()
        si = self._sel_idx()

        for i, r in enumerate(self.regions.regions):
            c = "#f9e2af" if i == si else "#89b4fa"
            w = 3 if i == si else 2
            if r.src_pts and len(r.src_pts) == 4:
                pts = [(int(x * sx), int(y * sy)) for x, y in r.src_pts]
                for j in range(4):
                    draw.line([pts[j], pts[(j + 1) % 4]], fill=c, width=w)
                # Corner dots (draggable handles)
                for j, (px, py) in enumerate(pts):
                    dr = DOT_R + 2 if i == si else DOT_R
                    draw.ellipse([px - dr, py - dr, px + dr, py + dr],
                                 fill=CORNER_COLORS[j], outline="white", width=2)
                    if i == si:
                        draw.text((px + dr + 2, py - dr), CORNER_LABELS[j],
                                  fill=CORNER_COLORS[j])
                draw.text((pts[0][0] + 6, pts[0][1] + DOT_R + 4), r.name, fill="#cdd6f4")
            else:
                x1, y1 = int(r.crop_x * sx), int(r.crop_y * sy)
                x2, y2 = int((r.crop_x + r.crop_w) * sx), int((r.crop_y + r.crop_h) * sy)
                draw.rectangle([x1, y1, x2, y2], outline=c, width=w)
                draw.text((x1 + 4, y1 + 4), r.name, fill="#cdd6f4")

        # In-progress picks for new region
        if self._picking and self._pick_pts:
            for j, (px, py) in enumerate(self._pick_pts):
                draw.ellipse([px - 6, py - 6, px + 6, py + 6],
                             fill=CORNER_COLORS[j], outline="white", width=2)
                draw.text((px + 8, py - 6), CORNER_LABELS[j], fill=CORNER_COLORS[j])
            for j in range(len(self._pick_pts) - 1):
                draw.line([tuple(self._pick_pts[j]), tuple(self._pick_pts[j + 1])],
                          fill="white", width=1)
            rem = 4 - len(self._pick_pts)
            draw.text((PREVIEW_W // 2 - 80, PREVIEW_H - 20),
                      f"Click {CORNER_LABELS[len(self._pick_pts)]}  ({rem} left)  |  Right-click: cancel",
                      fill="#f9e2af")

        # Warp editing hint
        if self._warp_drag_idx is not None:
            draw.text((10, PREVIEW_H - 20),
                      "Dragging warp corner — release to place, Enter=confirm, Esc=revert",
                      fill="#a6e3a1")

        ti = ImageTk.PhotoImage(img)
        self._cam_cv.config(width=PREVIEW_W, height=PREVIEW_H)
        self._cam_cv.create_image(0, 0, anchor=tk.NW, image=ti)
        self._cam_cv._img = ti

    # ==================================================================
    # Camera preview interaction — perspective handle dragging
    # ==================================================================

    def _cam_hit_warp_corner(self, ex, ey):
        """Check if (ex, ey) display coords hit a warp corner. Returns (region_idx, corner_idx) or None."""
        sx, sy = self._cam_scale()
        si = self._sel_idx()
        # Check selected region first, then others
        order = []
        if si is not None: order.append(si)
        order.extend(i for i in range(len(self.regions.regions)) if i != si)
        for i in order:
            r = self.regions.regions[i]
            if not r.src_pts or len(r.src_pts) != 4: continue
            for j, (cx, cy) in enumerate(r.src_pts):
                dx = ex - cx * sx
                dy = ey - cy * sy
                if dx * dx + dy * dy <= (DOT_R + 4) ** 2:
                    return i, j
        return None

    def _on_cam_click(self, event):
        if self._latest_frame is None: return

        # Adding new region mode
        if self._picking:
            self._pick_pts.append([event.x, event.y])
            if len(self._pick_pts) < 4:
                self._status(f"Click {CORNER_LABELS[len(self._pick_pts)]}  ({4 - len(self._pick_pts)} left)")
            else:
                self._finish_pick()
            return

        # Try to grab a warp corner handle
        hit = self._cam_hit_warp_corner(event.x, event.y)
        if hit:
            ri, ci = hit
            self._sel(ri)
            r = self.regions.regions[ri]
            self._warp_drag_idx = ri
            self._warp_drag_corner = ci
            self._warp_backup = [list(p) for p in r.src_pts]  # backup for Esc
            self._status(f"Dragging {CORNER_LABELS[ci]} of '{r.name}'")
            return

        # Click inside a region quad to select it
        if HAS_CV2:
            sx, sy = self._cam_scale()
            cx, cy = int(event.x / sx), int(event.y / sy)
            for i, r in enumerate(self.regions.regions):
                if r.src_pts and len(r.src_pts) == 4:
                    pts = np.array(r.src_pts, dtype=np.float32)
                    if cv2.pointPolygonTest(pts, (float(cx), float(cy)), False) >= 0:
                        self._sel(i); return

    def _on_cam_drag(self, event):
        if self._warp_drag_idx is None or self._warp_drag_corner is None:
            return
        r = self.regions.regions[self._warp_drag_idx]
        sx, sy = self._cam_scale()
        # Convert display coords back to camera coords
        cam_x = int(event.x / sx)
        cam_y = int(event.y / sy)
        # Clamp to frame bounds
        if self._latest_frame is not None:
            fh, fw = self._latest_frame.shape[:2]
            cam_x = max(0, min(fw - 1, cam_x))
            cam_y = max(0, min(fh - 1, cam_y))
        r.src_pts[self._warp_drag_corner] = [cam_x, cam_y]
        r.compute_homography()

    def _on_cam_release(self, event):
        if self._warp_drag_idx is not None:
            r = self.regions.regions[self._warp_drag_idx]
            # Recalculate output size to match new quad
            self._recalc_region_size(r)
            self._load_ed(self._sel_idx())
            self._status(f"Corner placed — Enter=confirm, Esc=revert")
            # Don't clear _warp_drag_idx yet — wait for Enter/Esc
            self._warp_drag_corner = None

    def _on_cam_rclick(self, event):
        if self._picking:
            self._picking = False; self._pick_pts = []
            self._cam_cv.config(cursor="arrow"); self._status("Pick cancelled.")

    def _on_enter(self, event):
        if self._warp_drag_idx is not None:
            r = self.regions.regions[self._warp_drag_idx]
            self._warp_backup = None
            self._warp_drag_idx = None
            self._warp_drag_corner = None
            self._refresh()
            self._status(f"Warp confirmed for '{r.name}'")

    def _on_escape(self, event):
        if self._warp_drag_idx is not None and self._warp_backup is not None:
            r = self.regions.regions[self._warp_drag_idx]
            r.src_pts = self._warp_backup
            r.compute_homography()
            self._recalc_region_size(r)
            self._warp_backup = None
            self._warp_drag_idx = None
            self._warp_drag_corner = None
            self._load_ed(self._sel_idx())
            self._status("Warp reverted.")

    def _recalc_region_size(self, r: Region):
        """Recalculate out_w/out_h from warp quad dimensions."""
        if not r.src_pts or len(r.src_pts) != 4: return
        p = r.src_pts
        tw = ((p[1][0]-p[0][0])**2 + (p[1][1]-p[0][1])**2)**.5
        bw = ((p[2][0]-p[3][0])**2 + (p[2][1]-p[3][1])**2)**.5
        lh = ((p[3][0]-p[0][0])**2 + (p[3][1]-p[0][1])**2)**.5
        rh = ((p[2][0]-p[1][0])**2 + (p[2][1]-p[1][1])**2)**.5
        r.out_w = max(32, int((tw + bw) / 2))
        r.out_h = max(32, int((lh + rh) / 2))

    def _finish_pick(self):
        fh, fw = self._latest_frame.shape[:2]
        sx, sy = fw / PREVIEW_W, fh / PREVIEW_H
        pts = [[int(x * sx), int(y * sy)] for x, y in self._pick_pts]
        tw = ((pts[1][0]-pts[0][0])**2+(pts[1][1]-pts[0][1])**2)**.5
        bw = ((pts[2][0]-pts[3][0])**2+(pts[2][1]-pts[3][1])**2)**.5
        ow = max(32, int((tw+bw)/2))
        lh = ((pts[3][0]-pts[0][0])**2+(pts[3][1]-pts[0][1])**2)**.5
        rh = ((pts[2][0]-pts[1][0])**2+(pts[2][1]-pts[1][1])**2)**.5
        oh = max(32, int((lh+rh)/2))
        self._region_counter += 1; name = f"R{self._region_counter}"
        ox = 0
        for r in self.regions.regions: ox = max(ox, r.out_x + r.out_w)
        if ox > 0: ox += 2
        r = Region(name=name, src_pts=pts, crop_x=pts[0][0], crop_y=pts[0][1],
                   crop_w=ow, crop_h=oh, out_x=self._snp(ox), out_y=0, out_w=ow, out_h=oh)
        r.compute_homography(); self.regions.add(r)
        self._refresh(); self._sel(len(self.regions.regions) - 1)
        self._picking = False; self._pick_pts = []; self._cam_cv.config(cursor="arrow")
        self._status(f"Region '{name}' created ({ow}x{oh})")

    # ==================================================================
    # Strip preview drawing
    # ==================================================================

    def _draw_strip(self, strip):
        if not HAS_PIL or strip is None: return
        cw, ch = self._strip_w, self._strip_h; pad = STRIP_PADDING
        ws = Image.new("RGB", (cw+pad*2, ch+pad*2), "#1b1b1b")
        rgb = cv2.cvtColor(strip, cv2.COLOR_BGR2RGB) if HAS_CV2 else strip
        ws.paste(Image.fromarray(rgb), (pad, pad))
        draw = ImageDraw.Draw(ws)
        draw.rectangle([pad, pad, pad+cw-1, pad+ch-1], outline=(140,140,140), width=2)
        # Grid
        if self._snap.get():
            gs = max(1, self._gsz.get()); gc = (50,50,50)
            rboxes = [(pad+r.out_x, pad+r.out_y, pad+r.out_x+r.out_w, pad+r.out_y+r.out_h)
                      for r in self.regions.regions if r.enabled]
            for gx in range(0, cw+1, gs):
                lx = pad+gx; ss = pad
                for rb in sorted(rboxes, key=lambda b:b[1]):
                    if lx<rb[0] or lx>rb[2]: continue
                    if ss<rb[1]: draw.line((lx,ss,lx,rb[1]), fill=gc)
                    ss = max(ss, rb[3])
                if ss<pad+ch: draw.line((lx,ss,lx,pad+ch), fill=gc)
            for gy in range(0, ch+1, gs):
                ly = pad+gy; ss = pad
                for rb in sorted(rboxes, key=lambda b:b[0]):
                    if ly<rb[1] or ly>rb[3]: continue
                    if ss<rb[0]: draw.line((ss,ly,rb[0],ly), fill=gc)
                    ss = max(ss, rb[2])
                if ss<pad+cw: draw.line((ss,ly,pad+cw,ly), fill=gc)
        si = self._sel_idx(); hs = HANDLE_SIZE
        for i, r in enumerate(self.regions.regions):
            x1,y1 = pad+r.out_x, pad+r.out_y; x2,y2 = x1+r.out_w, y1+r.out_h
            sel = i==si; ol = (255,180,0) if sel else ((0,180,255) if r.enabled else (120,120,120))
            draw.rectangle([x1,y1,x2,y2], outline=ol, width=3 if sel else 2)
            draw.text((x1+4,y1+2), r.name, fill=(255,255,255))
            if sel:
                hc = (111,199,255)
                for px,py in [(x1,y1),((x1+x2)//2,y1),(x2,y1),(x1,(y1+y2)//2),
                              (x2,(y1+y2)//2),(x1,y2),((x1+x2)//2,y2),(x2,y2)]:
                    draw.rectangle([px-hs,py-hs,px+hs-1,py+hs-1], outline=hc, fill=hc)
        ti = ImageTk.PhotoImage(ws)
        self._strip_cv.config(height=ch+pad*2)
        self._strip_cv.delete("all")
        self._strip_cv.create_image(0,0,anchor=tk.NW,image=ti)
        self._strip_cv._img = ti

    # ==================================================================
    # Strip interaction — move, resize, scale, nudge
    # ==================================================================

    def _s2c(self, event): return event.x - STRIP_PADDING, event.y - STRIP_PADDING

    def _s_hit(self, ax, ay):
        for i in reversed(range(len(self.regions.regions))):
            r = self.regions.regions[i]
            if r.out_x <= ax <= r.out_x+r.out_w and r.out_y <= ay <= r.out_y+r.out_h: return i
        return None

    def _s_handle(self, r, ax, ay):
        x1,y1,x2,y2 = r.out_x,r.out_y,r.out_x+r.out_w,r.out_y+r.out_h; hh=HANDLE_HIT
        for n,(a,b,c,d) in {"nw":(x1-hh,y1-hh,x1+hh,y1+hh),"n":((x1+x2)//2-hh,y1-hh,(x1+x2)//2+hh,y1+hh),
            "ne":(x2-hh,y1-hh,x2+hh,y1+hh),"w":(x1-hh,(y1+y2)//2-hh,x1+hh,(y1+y2)//2+hh),
            "e":(x2-hh,(y1+y2)//2-hh,x2+hh,(y1+y2)//2+hh),"sw":(x1-hh,y2-hh,x1+hh,y2+hh),
            "s":((x1+x2)//2-hh,y2-hh,(x1+x2)//2+hh,y2+hh),"se":(x2-hh,y2-hh,x2+hh,y2+hh)}.items():
            if a<=ax<=c and b<=ay<=d: return n
        return None

    def _snp(self, v):
        if not self._snap.get(): return v
        gs = max(1, self._gsz.get()); return int(round(v/gs)*gs)

    def _sc_click(self, event):
        self._strip_cv.focus_set(); ax,ay = self._s2c(event)
        idx = self._s_hit(ax, ay)
        if idx is None: self._drag_idx = None; self._drag_mode = None; return
        self._sel(idx); r = self.regions.regions[idx]
        if getattr(r,'locked',False): self._drag_mode = None; return
        self._drag_idx = idx; self._drag_mouse = (ax,ay)
        self._drag_geom = (r.out_x, r.out_y, r.out_w, r.out_h)
        self._drag_shift = bool(event.state & 0x0001)
        h = self._s_handle(r, ax, ay); self._drag_mode = h if h else "move"

    def _sc_drag(self, event):
        if self._drag_idx is None or self._drag_mode is None: return
        ax,ay = self._s2c(event)
        dx,dy = ax-self._drag_mouse[0], ay-self._drag_mouse[1]
        r = self.regions.regions[self._drag_idx]
        sx,sy,sw,sh = self._drag_geom
        shift = bool(event.state & 0x0001)

        if self._drag_mode == "move":
            r.out_x, r.out_y = self._snp(sx+dx), self._snp(sy+dy)
        elif shift and self._drag_mode in ("se","ne","sw","nw"):
            # Proportional scale from corner
            aspect = sh / max(1, sw)
            if "e" in self._drag_mode: nw = max(10, sw + dx)
            elif "w" in self._drag_mode: nw = max(10, sw - dx)
            else: nw = sw
            nh = max(10, int(nw * aspect))
            r.out_w, r.out_h = self._snp(nw), self._snp(nh)
            if "w" in self._drag_mode: r.out_x = self._snp(sx + sw - r.out_w)
            if "n" in self._drag_mode: r.out_y = self._snp(sy + sh - r.out_h)
        else:
            nx1,ny1,nx2,ny2 = sx,sy,sx+sw,sy+sh
            if "w" in self._drag_mode: nx1 = self._snp(sx+dx)
            if "e" in self._drag_mode: nx2 = self._snp(sx+sw+dx)
            if "n" in self._drag_mode: ny1 = self._snp(sy+dy)
            if "s" in self._drag_mode: ny2 = self._snp(sy+sh+dy)
            if nx2<nx1: nx1,nx2=nx2,nx1
            if ny2<ny1: ny1,ny2=ny2,ny1
            r.out_x, r.out_y = nx1, ny1
            r.out_w, r.out_h = max(10,nx2-nx1), max(10,ny2-ny1)
        self._load_ed(self._drag_idx)

    def _sc_release(self, event): self._drag_idx = None; self._drag_mode = None

    def _sc_arrow(self, event):
        idx = self._sel_idx()
        if idx is None: return "break"
        r = self.regions.regions[idx]
        if getattr(r,'locked',False): return "break"
        step = max(1, self._gsz.get()) if self._snap.get() else 1
        if event.state & 0x0001: step *= 10
        dx=dy=0
        if event.keysym=="Left": dx=-step
        elif event.keysym=="Right": dx=step
        elif event.keysym=="Up": dy=-step
        elif event.keysym=="Down": dy=step
        r.out_x += dx; r.out_y += dy
        self._load_ed(idx); return "break"

    # ==================================================================
    # Region list
    # ==================================================================

    def _refresh(self):
        self._rlist.delete(0, tk.END)
        for r in self.regions.regions:
            ic = "\u2714" if r.enabled else "\u2718"
            w = " W" if r.src_pts else ""; lk = " L" if getattr(r,'locked',False) else ""
            self._rlist.insert(tk.END, f"{ic} {r.name}{w}{lk}")

    def _sel_idx(self):
        s = self._rlist.curselection()
        if not s: return None
        return s[0] if s[0] < len(self.regions.regions) else None

    def _sel(self, idx):
        self._rlist.selection_clear(0, tk.END); self._rlist.selection_set(idx); self._rlist.see(idx)
        self._load_ed(idx)

    def _on_rlist_select(self, event=None):
        idx = self._sel_idx()
        if idx is not None: self._load_ed(idx)

    def _add_region(self):
        if self._latest_frame is None:
            messagebox.showwarning("No frame", "Start the camera first."); return
        self._picking = True; self._pick_pts = []
        self._cam_cv.config(cursor="crosshair")
        self._status("Click TL corner (4 clicks)  |  Right-click to cancel")

    def _del_region(self):
        idx = self._sel_idx()
        if idx is not None: self.regions.remove(idx); self._refresh()

    def _move(self, d):
        idx = self._sel_idx()
        if idx is None: return
        if d<0 and idx>0: self.regions.move_up(idx); self._refresh(); self._sel(idx-1)
        elif d>0 and idx<len(self.regions.regions)-1: self.regions.move_down(idx); self._refresh(); self._sel(idx+1)

    # ==================================================================
    # Editor panel
    # ==================================================================

    def _load_ed(self, idx):
        if idx is None or idx >= len(self.regions.regions): return
        self._editor_loading = True
        r = self.regions.regions[idx]
        self._ed_name.set(r.name); self._ed_ox.set(r.out_x); self._ed_oy.set(r.out_y)
        self._ed_ow.set(r.out_w); self._ed_oh.set(r.out_h)
        self._ed_enabled.set(r.enabled); self._ed_locked.set(getattr(r,'locked',False))
        self._editor_loading = False

    def _ed_apply(self, *_):
        if self._editor_loading: return
        idx = self._sel_idx()
        if idx is None or idx >= len(self.regions.regions): return
        r = self.regions.regions[idx]
        try:
            r.name = self._ed_name.get()
            r.out_x = self._ed_ox.get(); r.out_y = self._ed_oy.get()
            r.out_w = max(10, self._ed_ow.get()); r.out_h = max(10, self._ed_oh.get())
            r.enabled = self._ed_enabled.get(); r.locked = self._ed_locked.get()
        except (tk.TclError, ValueError): pass
        self._refresh()
        self._rlist.selection_clear(0, tk.END); self._rlist.selection_set(idx)

    def _clear_warp(self):
        idx = self._sel_idx()
        if idx is None: return
        r = self.regions.regions[idx]; r.src_pts = None; r._H = None; self._refresh()

    # ==================================================================
    # Outputs
    # ==================================================================

    def _tog_vpn(self):
        if self._vpn_var.get():
            p = int(self._vpn_port.get()); self.outputs.vpn = VpnStreamOutput(port=p); self.outputs.vpn.start()
            u = self.outputs.vpn.viewer_url; self._vpn_url.config(text=u); self._status(f"VPN: {u}")
        elif self.outputs.vpn: self.outputs.vpn.stop(); self.outputs.vpn = None; self._vpn_url.config(text="")
        self._update_streaming_state()
        if self._streaming: self._status("Streaming — cam preview frozen to save CPU")

    def _tog_vdo(self):
        if self._vdo_var.get():
            rm = self._vdo_room.get(); self.outputs.vdoninja = VdoNinjaOutput(room=rm); self.outputs.vdoninja.start()
        elif self.outputs.vdoninja: self.outputs.vdoninja.stop(); self.outputs.vdoninja = None
        self._update_streaming_state()

    def _tog_vcam(self):
        if self._vcam_var.get():
            self.outputs.virtualcam = VirtualCamOutput(); self.outputs.virtualcam.start()
        elif self.outputs.virtualcam: self.outputs.virtualcam.stop(); self.outputs.virtualcam = None
        self._update_streaming_state()

    # ==================================================================
    # Config
    # ==================================================================

    def _save_config(self, path=CONFIG_FILE):
        data = {"resolution": self._res_var.get(), "fps": self._fps_var.get(),
                "vpn_port": self._vpn_port.get(), "vdo_room": self._vdo_room.get(),
                "canvas_w": self._cw.get(), "canvas_h": self._ch.get(),
                "snap": self._snap.get(), "grid_size": self._gsz.get(),
                "regions": [r.to_dict() for r in self.regions.regions]}
        with open(path, "w") as f: json.dump(data, f, indent=2)
        self._status(f"Saved -> {path}")

    def _load_config(self, path=CONFIG_FILE):
        if not os.path.exists(path): return
        try:
            with open(path) as f: data = json.load(f)
            self._res_var.set(data.get("resolution","1280x720"))
            self._fps_var.set(data.get("fps","30"))
            self._vpn_port.set(data.get("vpn_port","8765"))
            self._vdo_room.set(data.get("vdo_room","djhudpicam"))
            self._cw.set(data.get("canvas_w",1080)); self._ch.set(data.get("canvas_h",STRIP_H))
            self._snap.set(data.get("snap",True)); self._gsz.set(data.get("grid_size",10))
            self.regions.regions = [Region.from_dict(d) for d in data.get("regions",[])]
            self._region_counter = len(self.regions.regions); self._refresh()
            self._status(f"Loaded <- {path}")
        except Exception as e: log.warning("Config load error: %s", e)

    def _load_config_dialog(self):
        p = filedialog.askopenfilename(filetypes=[("JSON","*.json"),("All","*.*")])
        if p: self._load_config(p)

    # ==================================================================
    # Misc
    # ==================================================================

    def _status(self, msg): self._status_var.set(msg); log.info(msg)

    def _on_close(self):
        self._save_config(); self._stop_cam(); self.outputs.stop_all(); self.destroy()
