[![PyPI](https://img.shields.io/pypi/v/kanon-kit)](https://pypi.org/project/kanon-kit/)
[![Tests](https://img.shields.io/badge/tests-971%20passed-brightgreen)]()
[![Coverage](https://img.shields.io/badge/coverage-90%25-brightgreen)]()
[![License](https://img.shields.io/badge/license-Apache%202.0-blue)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)]()

# kanon

**A protocol substrate that gives your LLM agent process discipline.**

<!-- ADR-0048: kanon is a protocol substrate, not a workflow engine -->

Your agent writes code. kanon makes sure it plans first, specs what it's building, tests what it ships, and doesn't skip steps. One config generates rules for every major agent harness — Claude Code, Cursor, Copilot, and six more — so the discipline follows the agent, not the other way around.

<!-- TODO: Replace with real GIF via `vhs docs/kanon-demo.tape` -->
<div align="center">

```console
$ kanon init ~/myproject --profile solo
✓ Created .kanon/config.yaml
✓ Generated AGENTS.md + harness shims (CLAUDE.md, .cursor/rules/kanon.mdc, ...)
✓ Scaffolded docs/decisions/, docs/plans/
✓ Profile: solo (kanon-sdd:1, kanon-testing:1, kanon-worktrees:1)
Ready. Open ~/myproject with your agent.

$ kanon verify ~/myproject
✓ kanon-sdd .............. ok (depth 1)
✓ kanon-testing .......... ok (depth 1)
✓ kanon-worktrees ........ ok (depth 1)
3 aspects verified, 0 issues.
```

</div>

## Why kanon?

You've seen it: you ask an agent to build a feature and it jumps straight to code. No plan. No spec. No tests until you ask. Then it "fixes" something by rewriting half the file.

Every team using LLM agents hits the same progression:

1. **No rules.** The agent does whatever it wants. Fast, chaotic.
2. **A rules file.** `CLAUDE.md`, `.cursorrules`, `copilot-instructions.md`. Better — but now you're maintaining N copies for N tools, they drift, and there's no way to know if the agent actually followed them.
3. **A protocol.** One source of truth, generated into tool-specific formats, with disciplines that scale up or down and verification that catches deviation.

kanon is step 3.

## Quickstart

```bash
uv tool install kanon-kit

kanon init ~/myproject --profile solo
```

```
✓ Created .kanon/config.yaml
✓ Generated AGENTS.md
✓ Generated CLAUDE.md, .cursor/rules/kanon.mdc, .github/copilot-instructions.md ...
✓ Scaffolded docs/decisions/, docs/plans/
✓ Profile: solo (kanon-sdd:1, kanon-testing:1, kanon-worktrees:1)

Ready. Open ~/myproject with your agent.
```

```bash
# Verify the agent followed process
kanon verify ~/myproject

# Dial up rigor as the project matures
kanon aspect set-depth ~/myproject kanon-sdd 2

# Upgrade when new versions ship
kanon upgrade ~/myproject
```

Profiles give you a starting point:

| Profile | For | Aspects enabled |
|---------|-----|-----------------|
| `solo` | One developer, real project | sdd:1, testing:1, worktrees:1 |
| `team` | Multiple contributors | sdd:2, testing:2, worktrees:2, release:1, security:1 |
| `max` | Full rigor | All aspects at max depth |

## Works with

kanon generates and manages agent-specific rule files from a single `AGENTS.md`:

| Agent | Rule file |
|-------|-----------|
| Claude Code | `CLAUDE.md` |
| Cursor | `.cursor/rules/kanon.mdc` |
| GitHub Copilot | `.github/copilot-instructions.md` |
| Windsurf | `.windsurf/rules/kanon.md` |
| Cline | `.clinerules/kanon.md` |
| Roo Code | `.roo/rules/kanon.md` |
| JetBrains AI | `.aiassistant/rules/kanon.md` |
| Kiro | `.kiro/steering/kanon.md` |

One source of truth. Switch agents without rewriting rules.

## Aspects

Seven reference disciplines ship out of the box. Each is opt-in and depth-dialed.

| Aspect | Depth | What it does |
|--------|-------|--------------|
| `kanon-sdd` | 0–3 | Plans → specs → design docs → verification |
| `kanon-testing` | 0–3 | Test discipline, acceptance-criteria-first TDD |
| `kanon-worktrees` | 0–2 | Git worktree isolation for parallel work |
| `kanon-release` | 0–2 | Release publishing protocol |
| `kanon-security` | 0–2 | Secure-by-default protocols |
| `kanon-deps` | 0–2 | Dependency hygiene |
| `kanon-fidelity` | 0–1 | Behavioural conformance checks on agent transcripts |

Need something custom? Define `project-*` aspects in `.kanon/aspects/` — they're first-class citizens with the same verification, composition, and depth-dialing as the reference set.

## Key commands

```bash
kanon init <path> --profile <solo|team|max>   # scaffold a project
kanon verify .                                 # check protocol compliance
kanon protocols check .                        # route agent to correct process step
kanon aspect set-depth . <aspect> <depth>      # dial a discipline up or down
kanon upgrade .                                # upgrade substrate to latest
```

## How is this different?

| | **kanon** | **spec-kit** | **GSD** | **cc-sdd** | **Raw rule files** |
|---|---|---|---|---|---|
| **Approach** | Protocol substrate + composable aspects | SDD toolkit with extensions | Meta-prompting + context engineering | Kiro-inspired skill installer | Manual per-tool files |
| **Cross-harness** | 9 harnesses, one source | 30+ agents | 14 runtimes | 8 agents | One file per tool |
| **Modularity** | Named aspects, publisher-symmetric namespaces | Extensions + presets | Phases (not pluggable) | Templates (not pluggable) | Monolithic |
| **Verification** | `kanon verify` — built-in, deterministic | Via optional extensions | ✗ | ✗ | ✗ |
| **Depth-dialing** | 0–3 per aspect | ✗ | ✗ | ✗ | ✗ |
| **Custom disciplines** | First-class (`project-*` aspects) | First-class (extensions) | Config only | Template edits | Edit the file |
| **Self-hosting** | ✓ (verifies itself) | ✗ | ✗ | ✗ | — |

kanon's differentiators: **depth-dialing** (progressive disclosure per discipline), **built-in deterministic verification**, and **publisher-symmetric composition** (your aspects = kit aspects = third-party aspects, same rules).

## Documentation

- [AGENTS.md](AGENTS.md) — the canonical rules your agent reads
- [Aspect model](docs/design/aspect-model.md) — how aspects and depths work
- [SDD method](docs/sdd-method.md) — the spec-driven development process
- [Vision](docs/foundations/vision.md) — what kanon is and is not
- [ADR index](docs/decisions/README.md) — architectural decisions
- [Contributing](docs/contributing.md) — where does my change go?
- [Roadmap](docs/plans/roadmap.md) — what's next

## Development

<details>
<summary>Setup and testing</summary>

```bash
uv sync

# Run tests
.venv/bin/pytest                    # fast tests (~971, 90% coverage)
.venv/bin/pytest -m e2e --no-cov    # end-to-end tests
.venv/bin/pytest -m ''              # everything
```

kanon is self-hosting — it verifies its own process discipline on every commit.

**Requires:** Python 3.10+, POSIX (Linux / macOS)

</details>

## License

Apache 2.0 — see [LICENSE](LICENSE).
