---
contract-id: kanon-testing/test-suite-present
semantic-version: "1.0"
surface: preflight.push
realization-shape:
  verbs: [invoke]
  evidence-kinds: [build-config]
  stages: [push]
kanon-dialect: "2026-05-01"
---
# Contract: test-suite-present

## Obligation

The consumer repository MUST have a functioning test suite that:

1. Can be invoked via a single shell command from the repo root
2. Exercises the project's source code
3. Reports pass/fail via exit code (0 = pass, non-zero = fail)

## What the resolver must determine

Inspect the repository and identify:

1. **The test runner** — which tool runs tests (pytest, jest, go test, cargo test, etc.)
2. **The invocation command** — the exact shell command that runs the full test suite
3. **Evidence of configuration** — the file(s) that declare the test runner and its settings

## Realization

The resolution entry MUST contain:

- `realized-by:` with a single entry using label `invoke` and `invocation-form: shell`
- `evidence:` citing at least one build/config file proving the test runner is configured

## Staleness

This resolution is stale when:

- The test runner configuration changes (e.g., pytest options modified)
- The build system's test dependencies change (e.g., test framework removed or replaced)
- The source paths declared for testing change
