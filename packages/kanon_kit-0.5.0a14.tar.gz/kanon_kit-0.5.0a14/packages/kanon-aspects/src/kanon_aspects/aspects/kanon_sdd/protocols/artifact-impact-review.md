---
status: accepted
date: 2026-05-05
depth-min: 2
invoke-when: >
  An accepted SDD artifact (spec, design, plan, principle, persona) has been
  substantively modified (not typo/formatting-only), and the user wants to
  assess downstream impact — OR — `kanon verify` reports a staleness warning
  for downstream references. Does NOT fire for vision changes (use
  foundations-review instead) or for changes that are themselves amendments
  triggered by this protocol (no cascading re-triggers).
---
# Protocol: Artifact Impact Review

## Purpose

When an accepted artifact changes, identify downstream dependents via the
document graph and classify each as keep/amend/retire so the project stays
coherent.

## Steps

### 1. Confirm substantive change

Read the modified artifact's diff. If the change is typo-only, formatting-only,
or metadata-only (no semantic shift), stop — no downstream review needed.
State: "Change is non-substantive; skipping impact review."

### 2. Run impact analysis

```bash
kanon graph impact . <slug>
```

Where `<slug>` is the artifact's identifier (the filename without extension, e.g.,
`pagination` for `docs/specs/pagination.md`).

The output format is:
```
<slug> (<type>) [<status>]
  ← <dep-slug> (<dep-type>) [<edge-kind>]
  ← <dep-slug> (<dep-type>) [<edge-kind>]
```

**Use only direct dependents (depth 1).** Ignore second-level entries (indented
further). Transitive dependents will be caught when the direct dependent is
amended and this protocol fires for it in a future session.

If the output shows no direct dependents, stop — no review needed.

### 2b. Check referencing ADRs

If the modified artifact is a spec or principle, check whether any accepted
ADR's prose references it. If so, add those ADRs to the disposition table
with additional dispositions:

- **Acknowledge** — the ADR's decision still holds despite the upstream change.
- **Supersede** — the ADR's reasoning is invalidated; write a new ADR.

### 3. Read each dependent

For each dependent artifact, read the file and identify which sections
reference or rely on the changed artifact's content.

### 4. Classify each dependent

Assign one disposition:

- **Keep** — still aligned; no changes needed.
- **Amend** — directionally correct but references, rationale, or constraints
  need updating to reflect the upstream change.
- **Retire** — contradicted or obsoleted by the upstream change. Mark
  `status: superseded` in frontmatter.

### 5. Present disposition table

| Dependent | Edge | Disposition | Rationale |
|-----------|------|-------------|-----------|
| design-foo | realizes | amend | Invariant 3 references removed spec constraint |
| plan-bar | implements | keep | No overlap with changed section |

Present to user for approval. User may override any disposition.

### 6. Execute approved changes

- **Amend**: edit the dependent in-place, updating only the affected sections.
- **Retire**: add `status: superseded` and `superseded-by:` frontmatter.
- Do NOT re-trigger this protocol for amendments made in this step.

### 7. Verify

Run `kanon verify .` to confirm no staleness warnings remain for the
modified subgraph.

## Exit criteria

- Every dependent from step 2 has a disposition.
- User has approved the disposition table.
- Approved changes are committed.
- `kanon verify` passes for the affected subgraph.

## Anti-patterns

- **Cascading re-triggers.** Amendments made in step 6 do not re-invoke this
  protocol. One pass per upstream change.
- **Reviewing typos.** Step 1 exists to prevent disproportionate reviews.
- **Skipping user approval.** The disposition table is mandatory — no silent
  rewrites.
