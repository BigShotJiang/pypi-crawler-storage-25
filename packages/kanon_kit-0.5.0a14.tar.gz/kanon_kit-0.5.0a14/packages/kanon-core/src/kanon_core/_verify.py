"""Structural verification pass: file existence, markers, fidelity locks.

This is the first of two verification layers invoked by ``kanon verify``.
Each ``check_*`` function validates config-level and file-existence
invariants.  The second layer (``_dag_verify``) handles graph-relational
checks across the document DAG.
"""

from __future__ import annotations

import importlib
import re
import sys
from pathlib import Path
from typing import Any

import yaml

from kanon_core._manifest import (
    _all_known_aspects,
    _aspect_depth_range,
    _aspect_provides,
    _aspect_sections,
    _aspect_validators,
    _expected_files,
    _find_section_pair,
    _iter_markers,
    _namespaced_section,
    _parse_frontmatter,
)


def check_aspects_known(
    aspects: dict[str, int],
    errors: list[str],
    warnings: list[str],
) -> dict[str, int]:
    """Validate aspect names and depth ranges against the kit + project registry.

    Returns the subset of *aspects* registered (kit + active project overlay),
    safe for further checks.
    """
    known = _all_known_aspects()
    for name, depth in aspects.items():
        if name not in known:
            warnings.append(
                f"config.aspects.{name}: aspect not in installed kit registry."
            )
            continue
        min_d, max_d = _aspect_depth_range(name)
        if not (min_d <= depth <= max_d):
            errors.append(
                f"config.aspects.{name}.depth={depth}: outside range [{min_d},{max_d}]."
            )
    return {n: d for n, d in aspects.items() if n in known}


def check_required_files(
    target: Path,
    known_aspects: dict[str, int],
    errors: list[str],
) -> None:
    """Check that every file required by the active aspects exists."""
    for rel in _expected_files(known_aspects):
        p = target / rel
        if not p.exists():
            errors.append(f"missing required file: {rel}")


def check_agents_md_markers(
    target: Path,
    aspects: dict[str, int],
    known_aspects: dict[str, int],
    errors: list[str],
) -> None:
    """Check AGENTS.md for expected section markers and marker balance.

    Uses line-anchored, fenced-block-aware marker detection so quoted markers
    in user prose or code blocks do not influence the check.
    """
    agents_md_path = target / "AGENTS.md"
    if not agents_md_path.is_file():
        return
    agents_text = agents_md_path.read_text(encoding="utf-8")
    known = _all_known_aspects()
    for aspect, depth in aspects.items():
        if aspect not in known:
            continue
        for section in _aspect_sections(aspect, depth):
            namespaced = _namespaced_section(aspect, section)
            if _find_section_pair(agents_text, namespaced) is None:
                errors.append(
                    f"AGENTS.md missing marker pair for section '{namespaced}' "
                    f"(aspect {aspect}, depth {depth})."
                )
    begins = 0
    ends = 0
    for kind, _, _, _ in _iter_markers(agents_text):
        if kind == "begin":
            begins += 1
        else:
            ends += 1
    if begins != ends:
        errors.append(
            f"AGENTS.md marker imbalance: {begins} begin(s), {ends} end(s)."
        )


def check_fidelity_lock(
    target: Path,
    sdd_depth: int,
    warnings: list[str],
    spec_sha_fn: Any,
    accepted_specs_fn: Any,
) -> None:
    """Check fidelity lock for spec/fixture drift (sdd depth >= 2)."""
    if sdd_depth < 2:
        return
    lock_path = target / ".kanon" / "fidelity.lock"
    if not lock_path.is_file():
        return
    lock_data = yaml.safe_load(lock_path.read_text(encoding="utf-8"))
    if not isinstance(lock_data, dict) or "entries" not in lock_data:
        return
    lock_entries = lock_data["entries"] or {}
    specs_dir = target / "docs" / "specs"
    current_specs = accepted_specs_fn(specs_dir)
    for slug, entry in sorted(lock_entries.items()):
        spec_path = specs_dir / f"{slug}.md"
        if spec_path.is_file():
            current_sha = spec_sha_fn(spec_path)
            if current_sha != entry.get("spec_sha"):
                warnings.append(
                    f"fidelity: spec {slug} has changed since last fidelity update."  # nosec
                )
        for fpath, locked_sha in sorted(
            (entry.get("fixture_shas") or {}).items()
        ):
            full = target / fpath
            if not full.is_file():
                warnings.append(
                    f"fidelity: fixture {fpath} no longer exists (spec: {slug})."
                )
            elif spec_sha_fn(full) != locked_sha:
                warnings.append(
                    f"fidelity: fixture {fpath} has changed since last fidelity update (spec: {slug})."  # nosec
                )
    for p in current_specs:
        if p.stem not in lock_entries:
            warnings.append(
                f"fidelity: spec {p.stem} is not tracked in fidelity.lock."
            )


def check_verified_by(
    target: Path,
    sdd_depth: int,
    warnings: list[str],
) -> None:
    """Check invariant coverage completeness (sdd depth >= 2)."""
    if sdd_depth < 2:
        return
    inv_re = re.compile(r"<!--\s*(INV-[a-z][a-z0-9-]*-[a-z][a-z0-9-]*)\s*-->")
    specs_dir = target / "docs" / "specs"
    if not specs_dir.is_dir():
        return
    for sp in sorted(specs_dir.glob("*.md")):
        if sp.name.startswith("_") or sp.name == "README.md":
            continue
        text = sp.read_text(encoding="utf-8")
        fm = _parse_frontmatter(text)
        if fm.get("status") != "accepted" or fm.get("fixtures_deferred"):
            continue
        anchors = inv_re.findall(text)
        if not anchors:
            continue
        coverage = fm.get("invariant_coverage") or {}
        missing = [a for a in anchors if a not in coverage]
        if missing:
            warnings.append(
                f"verified-by: {sp.name} missing invariant_coverage "
                f"for {len(missing)} anchor(s)."
            )


def run_project_validators(
    target: Path,
    aspects: dict[str, int],
    errors: list[str],
    warnings: list[str],
) -> None:
    """Invoke each enabled project-aspect's declared ``validators:`` in-process.

    Per ADR-0028 / project-aspects spec INV-7 the trust boundary is in-process:
    each ``validators:`` entry is a dotted Python module path that ``kanon
    verify`` ``importlib.import_module``s, then calls its ``check(target,
    errors, warnings) -> None`` entrypoint. Findings flow into the same
    ``errors``/``warnings`` lists the kit's structural checks populate.

    Per spec INV-9 (validator non-overriding), the kit's own structural
    checks are authoritative. Callers MUST invoke this function BEFORE the
    kit checks so any ``errors.clear()`` from a hostile project-validator is
    overwritten by the kit's subsequent appends. Failures raised by a
    validator (import error, missing entrypoint, exception during ``check``)
    are recorded as errors and verify continues with the remaining checks.
    """
    # Project validators use relative module paths (e.g. ``ci.validators.foo``)
    # resolved from the target directory.  Temporarily add *target* to
    # ``sys.path`` so ``importlib.import_module`` can find them.
    target_str = str(target)
    inserted = target_str not in sys.path
    if inserted:
        sys.path.insert(0, target_str)
    try:
        for aspect_name in sorted(aspects):
            if not aspect_name.startswith("project-"):
                continue
            try:
                module_paths = _aspect_validators(aspect_name)
            except Exception as exc:
                errors.append(
                    f"project-aspect {aspect_name!r}: failed to load manifest "
                    f"for validator discovery: {exc}"
                )
                continue
            for module_path in module_paths:
                try:
                    module = importlib.import_module(module_path)
                except ImportError as exc:
                    errors.append(
                        f"project-validator {module_path!r} (aspect {aspect_name!r}): "
                        f"import failed: {exc}"
                    )
                    continue
                check = getattr(module, "check", None)
                if not callable(check):
                    errors.append(
                        f"project-validator {module_path!r} (aspect {aspect_name!r}): "
                        f"module exposes no callable `check(target, errors, warnings)`."
                    )
                    continue
                try:
                    check(target, errors, warnings)
                except Exception as exc:
                    errors.append(
                        f"project-validator {module_path!r} (aspect {aspect_name!r}): "
                        f"raised {type(exc).__name__}: {exc}"
                    )
    finally:
        if inserted:
            sys.path.remove(target_str)


def check_adr_staleness(
    target: Path,
    warnings: list[str],
) -> None:
    """Check accepted ADRs for references to superseded or deleted artifacts."""
    decisions_dir = target / "docs" / "decisions"
    if not decisions_dir.is_dir():
        return
    spec_link_re = re.compile(
        r"\]\(\.\./specs/([a-z0-9][a-z0-9-]*)\.md(?:#[^)\s]*)?\)"
    )
    principle_link_re = re.compile(
        r"\]\(\.\./foundations/principles/(P-[a-z][a-z0-9-]*)\.md(?:#[^)\s]*)?\)"
    )
    principle_inline_re = re.compile(r"(?:^|(?<=\s))(P-[a-z][a-z0-9-]+)")

    for adr_path in sorted(decisions_dir.glob("*.md")):
        if adr_path.name == "README.md" or adr_path.name.startswith("_"):
            continue
        text = adr_path.read_text(encoding="utf-8")
        fm = _parse_frontmatter(text)
        status = fm.get("status")
        if status not in ("accepted", "accepted (lite)"):
            continue
        # Extract body after frontmatter
        body = text
        if text.startswith("---\n"):
            end = text.find("\n---\n", 4)
            if end >= 0:
                body = text[end + 5:]

        # Check spec references
        for match in spec_link_re.finditer(body):
            spec_slug = match.group(1)
            spec_path = target / "docs" / "specs" / f"{spec_slug}.md"
            _check_ref_staleness(adr_path, spec_path, f"docs/specs/{spec_slug}.md", warnings)

        # Check principle references
        seen_principles: set[str] = set()
        for match in principle_link_re.finditer(body):
            pid = match.group(1)
            if pid not in seen_principles:
                seen_principles.add(pid)
                p_path = target / "docs" / "foundations" / "principles" / f"{pid}.md"
                _check_ref_staleness(adr_path, p_path, f"docs/foundations/principles/{pid}.md", warnings)
        for match in principle_inline_re.finditer(body):
            pid = match.group(1)
            if pid not in seen_principles:
                seen_principles.add(pid)
                p_path = target / "docs" / "foundations" / "principles" / f"{pid}.md"
                _check_ref_staleness(adr_path, p_path, f"docs/foundations/principles/{pid}.md", warnings)


def _check_ref_staleness(
    adr_path: Path,
    target_path: Path,
    target_rel: str,
    warnings: list[str],
) -> None:
    """Emit a warning if target_path is missing or superseded."""
    if not target_path.is_file():
        warnings.append(
            f"adr-staleness: {adr_path.name} references {target_rel} which is missing"
        )
        return
    text = target_path.read_text(encoding="utf-8")
    fm = _parse_frontmatter(text)
    status = fm.get("status")
    if status == "superseded":
        warnings.append(
            f"adr-staleness: {adr_path.name} references {target_rel} which is superseded"
        )


def _check_kernel_freshness(
    target: Path,
    aspects: dict[str, int],
    aspect_order: list[str],
) -> tuple[list[str], list[str]]:
    """Check .kanon/kernel.md exists and contains the expected hash.

    Returns (errors, warnings) matching the pattern used by other check_* functions.
    """
    from kanon_core._scaffold import _assemble_kernel

    errors: list[str] = []
    warnings: list[str] = []
    kernel_path = target / ".kanon" / "kernel.md"
    if not kernel_path.is_file():
        warnings.append("kernel: .kanon/kernel.md is missing — run `kanon upgrade` to regenerate.")
        return errors, warnings

    _, expected_hash = _assemble_kernel(aspects, aspect_order)
    text = kernel_path.read_text(encoding="utf-8")
    hash_re = re.compile(r"kanon:kernel\s+hash=([0-9a-f]{8})")
    match = hash_re.search(text)
    if match is None:
        errors.append("kernel: .kanon/kernel.md missing hash marker.")
    elif match.group(1) != expected_hash:
        errors.append(
            f"kernel: .kanon/kernel.md is stale (expected hash {expected_hash}, "
            f"found {match.group(1)}). Run `kanon upgrade` to regenerate."
        )
    return errors, warnings


def check_fidelity_assertions(
    target: Path,
    aspects: dict[str, int],
    errors: list[str],
    warnings: list[str],
) -> None:
    """Run fidelity-fixture replay if any enabled aspect declares the
    ``behavioural-verification`` capability.

    Realises the verification-contract carve-out (INV-10, ratified by
    ADR-0029). Per ``docs/specs/fidelity.md`` INV-6 (aspect-gated) and INV-7
    (text-only bounds): when no enabled aspect declares the capability, this
    function returns immediately with zero filesystem reads under
    ``.kanon/fidelity/`` and emits no errors or warnings.

    Failure taxonomy (spec INV-8):
        - Missing required frontmatter, malformed lists, regex compilation
          errors, dogfood files with zero turns matching the configured
          actor, and any assertion failure → ``errors``.
        - Missing paired ``.dogfood.md`` capture → ``warnings``.
    """
    from kanon_core._fidelity import (
        BEHAVIOURAL_VERIFICATION_CAPABILITY,
        discover_fixtures,
        dogfood_path_for,
        evaluate_fixture,
        parse_fixture,
    )

    # INV-6 gate: any enabled aspect declaring the capability is sufficient.
    capability_aspect: str | None = None
    for name, depth in aspects.items():
        if depth < 1:
            continue
        try:
            provides = _aspect_provides(name)
        except Exception as exc:
            warnings.append(
                f"verify: {name}: capability lookup failed: {exc}"
            )
            continue
        if BEHAVIOURAL_VERIFICATION_CAPABILITY in provides:
            capability_aspect = name
            break
    if capability_aspect is None:
        return

    fixture_paths = discover_fixtures(target)
    if not fixture_paths:
        return  # Aspect enabled but no fixtures authored yet — silent.

    for fixture_path in fixture_paths:
        fixture, parse_errors = parse_fixture(fixture_path)
        if parse_errors:
            errors.extend(parse_errors)
            continue
        assert fixture is not None
        dogfood = dogfood_path_for(fixture_path)
        if not dogfood.is_file():
            warnings.append(
                f"fidelity: {fixture_path.name}: paired dogfood capture "
                f"({dogfood.name}) is missing"
            )
            continue
        try:
            dogfood_text = dogfood.read_text(encoding="utf-8")
        except OSError as exc:
            errors.append(
                f"fidelity: {dogfood.name}: cannot read capture: {exc}"
            )
            continue
        errors.extend(evaluate_fixture(fixture, dogfood_text))
