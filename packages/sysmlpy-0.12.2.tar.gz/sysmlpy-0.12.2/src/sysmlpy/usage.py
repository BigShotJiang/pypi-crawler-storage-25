#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 30 23:23:31 2023

@author: christophercox
"""


# import os

# os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

import uuid as uuidlib

import pint

ureg = pint.UnitRegistry()

from sysmlpy.formatting import classtree
from sysmlpy.navigate import Searchable

from sysmlpy.grammar.classes import (
    Identification,
    DefinitionBody,
    DefinitionBodyItem,
    FeatureSpecializationPart,
    SubclassificationPart,
)

from sysmlpy.grammar.classes import (
    AttributeUsage,
    AttributeDefinition,
    ValuePart,
    PartUsage,
    PartDefinition,
    ItemUsage,
    ItemDefinition,
    PortUsage,
    PortDefinition,
    DefaultReferenceUsage,
    RefPrefix,
    ActionUsage,
    ActionDefinition,
    RequirementDefinition,
    UseCaseDefinition,
    StateUsage,
    StateDefinition,
    ConstraintUsage,
    ConstraintDefinition,
    ConnectionUsage,
    ConnectionDefinition,
    FlowConnectionUsage,
    FlowConnectionDefinition,
    CalculationUsage,
    CalculationDefinition,
    EnumerationDefinition,
    AllocationDefinition,
    AllocationUsage,
    MetadataDefinition,
    MetadataUsage,
    RenderingDefinition,
    RenderingUsage,
    IndividualDefinition,
    IndividualUsageSimple,
    FlowDefinition,
    ViewDefinition,
    ViewUsage,
    ViewpointDefinition,
    ViewpointUsage,
    ConcernDefinition,
    ConcernUsage,
    CaseDefinition,
    CaseUsage,
    AnalysisCaseDefinition,
    AnalysisCaseUsage,
    VerificationCaseDefinition,
    VerificationCaseUsage,
)


class Usage(Searchable):
    """Base class for all SysML v2 usage and definition wrapper objects."""

    #: SysML type keyword for this element (overridden by each subclass).
    sysml_type = None

    def __init__(self):
        self.name = str(uuidlib.uuid4())
        self.children = []
        self.typedby = None
        self._is_definition = None  # overridden via the setter below
        self.parent = None

    @property
    def is_definition(self):
        """``True`` when this object wraps a *definition* (e.g. ``part def``)
        rather than a usage (``part``).

        Subclass ``__init__`` methods assign ``self.is_definition = True/False``
        which is stored via the setter so we never mask existing instance
        variable semantics.
        """
        if self._is_definition is not None:
            return self._is_definition
        # Fallback: infer from the grammar class name
        return type(getattr(self, "grammar", None)).__name__.endswith("Definition")

    @is_definition.setter
    def is_definition(self, value):
        self._is_definition = bool(value)

    def _ensure_body(self, subgrammar="usage"):
        # Add children
        body = []
        for abc in self.children:
            body.append(
                DefinitionBodyItem(
                    abc._get_definition(child="DefinitionBody")
                ).get_definition()
            )

        if len(body) > 0:
            target = getattr(self.grammar, subgrammar)
            if hasattr(target, 'completion'):
                target.completion.body.body = DefinitionBody(
                    {"name": "DefinitionBody", "ownedRelatedElement": body}
                )
            else:
                target.body = DefinitionBody(
                    {"name": "DefinitionBody", "ownedRelatedElement": body}
                )
        return self

    def usage_dump(self, child):
        # This is a usage.

        self._ensure_body("usage")

        # Add packaging
        package = {
            "name": "StructureUsageElement",
            "ownedRelatedElement": self.grammar.get_definition(),
        }
        package = {"name": "OccurrenceUsageElement", "ownedRelatedElement": package}

        if child == "DefinitionBody":
            package = {
                "name": "OccurrenceUsageMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }

            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        elif "PackageBody":
            package = {"name": "UsageElement", "ownedRelatedElement": package}
            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }

        return package

    def definition_dump(self, child):
        # This is a definition.

        self._ensure_body("definition")

        package = {
            "name": "DefinitionElement",
            "ownedRelatedElement": self.grammar.get_definition(),
        }

        if child == "DefinitionBody":
            package = {
                "name": "DefinitionMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }

            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}

        elif child == "PackageBody" or child == None:
            # Add these packets to make this dump without parents

            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }

        return package

    def _get_definition(self, child=None):
        # Determine if this is a usage or definition based on grammar class name
        grammar_cls_name = type(self.grammar).__name__
        is_def = grammar_cls_name.endswith('Definition')
        
        if is_def:
            package = self.definition_dump(child)
        else:
            package = self.usage_dump(child)

        if child is None:
            package = {
                "name": "PackageBodyElement",
                "ownedRelationship": [package],
                "prefix": None,
            }

        # Add the typed by definition to the package output
        if self.typedby is not None:
            if child is None:
                package["ownedRelationship"].insert(
                    0, self.typedby._get_definition(child="PackageBody")
                )
            elif child == "PackageBody":
                package = [self.typedby._get_definition(child="PackageBody"), package]
            else:
                package["ownedRelationship"].insert(
                    0, self.typedby._get_definition(child=child)["ownedRelationship"][0]
                )

        return package

    def dump(self, child=None):
        return classtree(self._get_definition(child)).dump()

    def __repr__(self):
        # Safely get name
        try:
            name = getattr(self, 'name', None)
            if not name:
                id_obj = getattr(self.grammar, 'usage', None)
                if id_obj:
                    id_obj = getattr(id_obj.declaration, 'declaration', None)
                    if id_obj:
                        name = getattr(id_obj.identification, 'declaredName', None)
        except (AttributeError, TypeError):
            name = None
        
        # Safely get shortname
        try:
            shortname = None
            id_obj = getattr(self.grammar, 'usage', None)
            if id_obj:
                id_obj = getattr(id_obj.declaration, 'declaration', None)
                if id_obj:
                    shortname = getattr(id_obj.identification, 'declaredShortName', None)
            if shortname:
                shortname = shortname.strip('<').strip('>')
        except (AttributeError, TypeError):
            shortname = None
            
        is_def = hasattr(self.grammar, 'definition')
        cls_name = self.__class__.__name__
        
        if is_def:
            if name and shortname:
                return f"{cls_name}(definition=True, name={name!r}, shortname={shortname!r})"
            elif name:
                return f"{cls_name}(definition=True, name={name!r})"
            else:
                return f"{cls_name}(definition=True)"
        else:
            if name and shortname:
                return f"{cls_name}(name={name!r}, shortname={shortname!r})"
            elif name:
                return f"{cls_name}(name={name!r})"
            else:
                return f"{cls_name}()"

    def _set_name(self, name, short=False):
        if hasattr(self.grammar, "usage"):
            path = self.grammar.usage.declaration.declaration
        elif hasattr(self.grammar, "definition"):
            path = self.grammar.definition.declaration
        else:
            # Navigate recursively through .declaration chain to find identification
            path = self.grammar.declaration
            while hasattr(path, "declaration") and not hasattr(path, "identification"):
                path = path.declaration

        if path.identification is None:
            path.identification = Identification()

        if short:
            path.identification.declaredShortName = "<" + name + ">"
        else:
            self.name = name
            path.identification.declaredName = name

        return self

    def _get_name(self):
        return self.grammar.usage.declaration.declaration.identification.declaredName

    def _set_child(self, child):
        self.children.append(child)
        child.parent = self
        return self

    def _get_child(self, featurechain):
        # 'x.y.z'
        if isinstance(featurechain, str):
            fc = featurechain.split(".")
        else:
            raise TypeError

        if fc[0] == self.name:
            # This first one must match self name, otherwise pass it all
            featurechain = ".".join(fc[1:])

        for child in self.children:
            fcs = featurechain.split(".")
            if child.name == fcs[0]:
                if len(fcs) == 1:
                    return child
                else:
                    return child._get_child(featurechain)

    def _set_typed_by(self, typed):
        # Only set if the pointed object is a definition
        if "definition" in typed.grammar.__dict__:
            self.typedby = typed
            if "definition" in self.grammar.__dict__:
                raise ValueError("A definition element cannot be defined.")
            else:
                if self.grammar.usage.declaration.declaration.specialization is None:
                    package = {
                        "name": "QualifiedName",
                        "names": [typed.name],
                    }
                    package = {
                        "name": "FeatureType",
                        "type": package,
                        "ownedRelatedElement": [],
                    }
                    package = {"name": "OwnedFeatureTyping", "type": package}
                    package = {"name": "FeatureTyping", "ownedRelationship": package}
                    package = {"name": "TypedBy", "ownedRelationship": [package]}
                    package = {
                        "name": "Typings",
                        "typedby": package,
                        "ownedRelationship": [],
                    }
                    package = {
                        "name": "FeatureSpecialization",
                        "ownedRelationship": package,
                    }
                    package = {
                        "name": "FeatureSpecializationPart",
                        "specialization": [package],
                        "multiplicity": None,
                        "specialization2": [],
                        "multiplicity2": None,
                    }
                    self.grammar.usage.declaration.declaration.specialization = (
                        FeatureSpecializationPart(package)
                    )
        else:
            raise ValueError("Typed by element was not a definition.")
        return self

    def _set_specializes(self, *parents):
        """Set specialization (`:>`) for definitions.
        
        In SysML v2: `part def Car :> Vehicle;`
        
        Args:
            *parents: One or more definition elements to specialize.
        """
        if "definition" not in self.grammar.__dict__:
            raise ValueError(
                "Only definition elements can use specializes. "
                "Use _set_subsets() for usage elements."
            )
        
        names = [p.name for p in parents]
        relationships = []
        for name in names:
            relationships.append({
                "name": "OwnedSubclassification",
                "superclassifier": {
                    "name": "QualifiedName",
                    "names": [name],
                },
            })
        
        package = {
            "name": "SubclassificationPart",
            "ownedRelationship": relationships,
        }
        self.grammar.definition.declaration.subclassificationpart = (
            SubclassificationPart(package)
        )
        return self

    def _set_subsets(self, *parents):
        """Set subsetting (`:>`) for usage elements.
        
        In SysML v2: `part myEng :> eng;`
        
        Args:
            *parents: One or more elements to subset.
        """
        if "definition" in self.grammar.__dict__:
            raise ValueError(
                "Definition elements cannot use subsets. "
                "Use _set_specializes() for definitions."
            )
        
        names = [p.name if hasattr(p, 'name') else str(p) for p in parents]
        relationships = []
        for name in names:
            relationships.append({
                "name": "OwnedSubsetting",
                "subsettedFeature": {
                    "name": "QualifiedName",
                    "names": [name],
                },
                "ownedRelatedElement": [],
            })
        
        package = {
            "name": "Subsettings",
            "ownedRelationship": relationships,
        }
        package = {
            "name": "FeatureSpecialization",
            "ownedRelationship": package,
        }
        package = {
            "name": "FeatureSpecializationPart",
            "specialization": [package],
            "multiplicity": None,
            "specialization2": [],
            "multiplicity2": None,
        }
        self.grammar.usage.declaration.declaration.specialization = (
            FeatureSpecializationPart(package)
        )
        return self

    def _set_redefines(self, parent):
        """Set redefinition (`:>>`) for usage elements.
        
        In SysML v2: `attribute :>> mass = 100;`
        
        Args:
            parent: The element being redefined.
        """
        if "definition" in self.grammar.__dict__:
            raise ValueError("Definition elements cannot use redefines.")
        
        name = parent.name if hasattr(parent, 'name') else str(parent)
        
        package = {
            "name": "OwnedRedefinition",
            "redefinedFeature": {
                "name": "QualifiedName",
                "names": [name],
            },
            "ownedRelatedElement": [],
        }
        package = {
            "name": "Redefinitions",
            "ownedRelationship": [package],
        }
        package = {
            "name": "FeatureSpecialization",
            "ownedRelationship": package,
        }
        package = {
            "name": "FeatureSpecializationPart",
            "specialization": [package],
            "multiplicity": None,
            "specialization2": [],
            "multiplicity2": None,
        }
        self.grammar.usage.declaration.declaration.specialization = (
            FeatureSpecializationPart(package)
        )
        return self

    def _get_grammar(self):
        self._ensure_body()
        return self.grammar

    def load_from_grammar(self, grammar):
        #!TODO Typed By
        self.__init__()
        self.grammar = grammar
        children = []
        
        # Check if this is a definition or usage
        # Some definition types use 'definition' (PartDefinition, AttributeDefinition)
        # Others use 'declaration' directly (RequirementDefinition, UseCaseDefinition)
        # PartDefinition: has .definition which is a Definition object
        # Usage: has .declaration directly
        
        # First check if grammar has 'definition' (for definitions like PartDefinition)
        defn = getattr(grammar, 'definition', None)
        if defn:
            # This type uses 'definition' (PartDefinition, etc.)
            # Get name from definition.declaration.identification.declaredName
            u_name = defn.declaration.identification.declaredName
            
            # Get body from definition.body
            body = defn.body if hasattr(defn, 'body') else None
            
            # body is DefinitionBody with .children
            if body and hasattr(body, 'children') and body.children:
                children_list = []
                for body_item in body.children:
                    if hasattr(body_item, 'children') and body_item.children:
                        member = body_item.children[0]
                        if hasattr(member, 'children') and member.children:
                            inner = member.children[0]
                            # Handle DefinitionElement wrapping
                            if inner.__class__.__name__ == 'DefinitionElement' and hasattr(inner, 'children') and inner.children:
                                inner = inner.children[0]
                            if hasattr(inner, 'children'):
                                children_list.append(inner)
                            else:
                                children_list.append(inner)
                    elif hasattr(body_item, 'ownedRelatedElement'):
                        children_list.append(body_item)
                children = children_list
            else:
                children = []
        elif hasattr(grammar, 'usage'):
            # This is a usage (like PartUsage, ItemUsage)
            # Get name from grammar.usage.declaration.declaration.identification.declaredName
            usage = grammar.usage
            if hasattr(usage, 'declaration') and hasattr(usage.declaration, 'declaration'):
                decl = usage.declaration.declaration
                if hasattr(decl, 'identification') and decl.identification:
                    u_name = decl.identification.declaredName
                else:
                    u_name = None
            else:
                u_name = None
            
            # Extract children from usage body: grammar.usage.completion.body.body.children
            # This mirrors the PartDefinition path: grammar.definition.body.children
            try:
                body = usage.completion.body.body
                if hasattr(body, 'children') and body.children:
                    children_list = []
                    for body_item in body.children:
                        if hasattr(body_item, 'children') and body_item.children:
                            member = body_item.children[0]
                            mc = member.children if isinstance(member.children, list) else [member.children]
                            for inner in mc:
                                if inner is None:
                                    continue
                                # Handle DefinitionElement wrapping
                                if inner.__class__.__name__ == 'DefinitionElement' and hasattr(inner, 'children') and inner.children:
                                    inner = inner.children[0]
                                children_list.append(inner)
                    children = children_list
                else:
                    children = []
            except AttributeError:
                children = []
        elif hasattr(grammar, 'declaration'):
            # This type uses 'declaration' directly (RequirementDefinition, UseCaseDefinition, some usages)
            decl = grammar.declaration
            u_name = None
            
            # Check nested declaration for Usage (UsageDeclaration -> FeatureDeclaration)
            nested_decl = getattr(decl, 'declaration', None)
            if nested_decl and hasattr(nested_decl, 'identification') and nested_decl.identification:
                u_name = nested_decl.identification.declaredName
            # Check direct identification (for RequirementDefinition, UseCaseDefinition)
            elif hasattr(decl, 'identification') and decl.identification:
                u_name = decl.identification.declaredName
            children = []
        else:
            u_name = None
            children = []

        if u_name is not None:
            self.name = u_name

        for child in children:
            # Handle different child types
            if hasattr(child, 'definition') and hasattr(child, 'body'):
                # It's a Definition (PartDefinition, ItemDefinition, etc.)
                sc = child
            elif hasattr(child, 'children'):
                # It's a StructureUsageElement or similar
                sc = child.children if hasattr(child, 'children') else child
            else:
                continue
                
            # Process the child
            class_name = sc.__class__.__name__ if not hasattr(sc, '__class__') else sc.__class__.__name__
            
            if class_name == "PartDefinition":
                c = Part(definition=True).load_from_grammar(sc)
                c.parent = self
                self.children.append(c)
            elif class_name == "ItemDefinition":
                c = Item(definition=True).load_from_grammar(sc)
                c.parent = self
                self.children.append(c)
            elif class_name == "PartUsage":
                c = Part().load_from_grammar(sc)
                c.parent = self
                self.children.append(c)
            elif class_name == "ItemUsage":
                c = Item().load_from_grammar(sc)
                c.parent = self
                self.children.append(c)
            elif class_name == "AttributeUsage":
                c = Attribute().load_from_grammar(sc)
                c.parent = self
                self.children.append(c)
            elif class_name == "AttributeDefinition":
                c = Attribute(definition=True).load_from_grammar(sc)
                c.parent = self
                self.children.append(c)
            elif class_name == "StructureUsageElement":
                if hasattr(sc, 'children'):
                    inner = sc.children
                    if inner.__class__.__name__ == "PartUsage":
                        c = Part().load_from_grammar(inner)
                        c.parent = self
                        self.children.append(c)
                    elif inner.__class__.__name__ == "ItemUsage":
                        c = Item().load_from_grammar(inner)
                        c.parent = self
                        self.children.append(c)
            elif class_name == "Definition":
                # Unwrap Definition to get the inner type
                if hasattr(sc, 'body') and hasattr(sc.body, 'children') and sc.body.children:
                    for body_item in sc.body.children:
                        if hasattr(body_item, 'children') and body_item.children:
                            inner = body_item.children[0]
                            if hasattr(inner, 'children'):
                                inner = inner.children
                            if inner.__class__.__name__ == 'PartDefinition':
                                c = Part(definition=True).load_from_grammar(inner)
                            else:
                                c = Item(definition=True).load_from_grammar(inner)
                            c.parent = self
                            self.children.append(c)

        return self

    def add_directed_feature(self, direction, name=str(uuidlib.uuid4())):
        self._set_child(DefaultReference()._set_name(name).set_direction(direction))
        return self

    # def modify_directed_feature(self, direction, name):
    #     child = self._get_child(name)
    #     if child is not None:
    #         pass
    #     else:
    #         raise AttributeError("Invalid Feature Name or Chain")


class Attribute(Usage):
    sysml_type = 'attribute'
    def __init__(self, definition=False, name=None):
        Usage.__init__(self)

        if definition:
            self.grammar = AttributeDefinition()
        else:
            self.grammar = AttributeUsage()

        if name is not None:
            self._set_name(name)

    def usage_dump(self, child):
        # Override - base output

        # Add children
        body = []
        for abc in self.children:
            body.append(DefinitionBodyItem(abc.dump(child=True)).get_definition())
        if len(body) > 0:
            self.grammar.usage.completion.body.body = DefinitionBody(
                {"name": "DefinitionBody", "ownedRelatedElement": body}
            )

        # Add packaging
        package = {
            "name": "NonOccurrenceUsageElement",
            "ownedRelatedElement": self.grammar.get_definition(),
        }

        if child == "DefinitionBody":
            package = {
                "name": "NonOccurrenceUsageMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }
            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        else:
            # Add these packets to make this dump without parents
            package = {"name": "UsageElement", "ownedRelatedElement": package}
            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }
        return package

    def set_value(self, value):
        if not isinstance(value, pint.Quantity):
            value = value * ureg.dimensionless
        if isinstance(value, pint.Quantity):
            # Only add units if not dimensionless
            if not value.units.dimensionless:
                package_units = {
                    "name": "QualifiedName",
                    "names": [str(value.units)],
                }
                package_units = {
                    "name": "FeatureReferenceMember",
                    "memberElement": package_units,
                }
                package_units = {
                    "name": "FeatureReferenceExpression",
                    "ownedRelationship": [package_units],
                }
                package_units = {
                    "name": "BaseExpression",
                    "ownedRelationship": package_units,
                }
                package_units = {
                    "name": "PrimaryExpression",
                    "operand": [],
                    "base": package_units,
                    "operator": [],
                    "ownedRelationship1": [],
                    "ownedRelationship2": [],
                }
                package_units = {
                    "name": "ExtentExpression",
                    "operator": "",
                    "ownedRelationship": [],
                    "primary": package_units,
                }
                package_units = {
                    "name": "UnaryExpression",
                    "operand": [],
                    "operator": None,
                    "extent": package_units,
                }
                package_units = {
                    "name": "ExponentiationExpression",
                    "operand": [],
                    "operator": [],
                    "unary": package_units,
                }
                package_units = {
                    "name": "MultiplicativeExpression",
                    "operation": [],
                    "exponential": package_units,
                }
                package_units = {
                    "name": "AdditiveExpression",
                    "operation": [],
                    "multiplicitive": package_units,
                }
                package_units = {
                    "name": "RangeExpression",
                    "operand": None,
                    "additive": package_units,
                }
                package_units = {
                    "name": "RelationalExpression",
                    "operation": [],
                    "range": package_units,
                }
                package_units = {
                    "name": "ClassificationExpression",
                    "operand": [],
                    "operator": None,
                    "ownedRelationship": [],
                    "relational": package_units,
                }
                package_units = {
                    "name": "EqualityExpression",
                    "operation": [],
                    "classification": package_units,
                }
                package_units = {
                    "name": "AndExpression",
                    "operation": [],
                    "equality": package_units,
                }
                package_units = {
                    "name": "XorExpression",
                    "operand": [],
                    "operator": [],
                    "and": package_units,
                }
                package_units = {
                    "name": "OrExpression",
                    "xor": package_units,
                    "operand": [],
                    "operator": [],
                }
                package_units = {
                    "name": "ImpliesExpression",
                    "operand": [],
                    "operator": [],
                    "or": package_units,
                }
                package_units = {
                    "name": "NullCoalescingExpression",
                    "implies": package_units,
                    "operator": [],
                    "operand": [],
                }
                package_units = {
                    "name": "ConditionalExpression",
                    "operator": None,
                    "operand": [package_units],
                }
                package_units = {"name": "OwnedExpression", "expression": package_units}
                package_units = {
                    "name": "SequenceExpression",
                    "operation": [],
                    "ownedRelationship": package_units,
                }
                package_units = [package_units]
                operator = ["["]
            else:
                package_units = []
                operator = []

            package = {
                "name": "BaseExpression",
                "ownedRelationship": {
                    "name": "LiteralInteger",
                    "value": str(value.magnitude),
                },
            }
            package = {
                "name": "PrimaryExpression",
                "operand": package_units,
                "base": package,
                "operator": operator,
                "ownedRelationship1": [],
                "ownedRelationship2": [],
            }
            package = {
                "name": "ExtentExpression",
                "operator": "",
                "ownedRelationship": [],
                "primary": package,
            }
            package = {
                "name": "UnaryExpression",
                "operand": [],
                "operator": None,
                "extent": package,
            }
            package = {
                "name": "ExponentiationExpression",
                "operand": [],
                "operator": [],
                "unary": package,
            }
            package = {
                "name": "MultiplicativeExpression",
                "operation": [],
                "exponential": package,
            }
            package = {
                "name": "AdditiveExpression",
                "operation": [],
                "multiplicitive": package,
            }
            package = {
                "name": "RangeExpression",
                "operand": None,
                "additive": package,
            }
            package = {
                "name": "RelationalExpression",
                "operation": [],
                "range": package,
            }
            package = {
                "name": "ClassificationExpression",
                "operand": [],
                "operator": None,
                "ownedRelationship": [],
                "relational": package,
            }
            package = {
                "name": "EqualityExpression",
                "operation": [],
                "classification": package,
            }
            package = {
                "name": "AndExpression",
                "operation": [],
                "equality": package,
            }
            package = {
                "name": "XorExpression",
                "operand": [],
                "operator": [],
                "and": package,
            }
            package = {
                "name": "OrExpression",
                "xor": package,
                "operand": [],
                "operator": [],
            }
            package = {
                "name": "ImpliesExpression",
                "operand": [],
                "operator": [],
                "or": package,
            }
            package = {
                "name": "NullCoalescingExpression",
                "implies": package,
                "operator": [],
                "operand": [],
            }
            package = {
                "name": "ConditionalExpression",
                "operator": None,
                "operand": [package],
            }
            package = {"name": "OwnedExpression", "expression": package}
            package = {
                "name": "FeatureValue",
                "isDefault": False,
                "isEqual": False,
                "isInitial": False,
                "ownedRelatedElement": package,
            }
            package = {"name": "ValuePart", "ownedRelationship": [package]}
            self.grammar.usage.completion.valuepart = ValuePart(package)
            # value.unit

        return self

    def get_value(self):
        valuepart = self.grammar.usage.completion.valuepart
        if valuepart is None:
            raise AttributeError("No valuepart found in grammar")
        
        feature_value = valuepart.relationships[0]
        primary = (
            feature_value.element.expression.operands[0]
            .implies.orexpression.xor.andexpression.equality.classification.relational.range.additive.left_hand.exponential.unary.extent.primary
        )
        
        base = primary.base.relationship
        base_name = base.__class__.__name__
        
        has_unit = hasattr(primary, 'operand') and primary.operand and len(primary.operand) > 0
        
        if has_unit:
            unit = primary.operand[0]
            unit_name = None
            if hasattr(unit, 'relationship'):
                unit_expr = unit.relationship.expression
                if hasattr(unit_expr, 'operands') and unit_expr.operands:
                    primary2 = unit_expr.operands[0]
                    if hasattr(primary2, 'implies'):
                        primary2 = primary2.implies.orexpression.xor.andexpression.equality.classification.relational.range.additive.left_hand.exponential.unary.extent.primary
                    if hasattr(primary2, 'base'):
                        unit_rel = primary2.base.relationship
                        if hasattr(unit_rel, 'children') and unit_rel.children:
                            unit_name = unit_rel.children[0].memberElement.dump()
                        elif hasattr(unit_rel, 'dump'):
                            unit_name = unit_rel.dump()
            if unit_name:
                if base_name == "LiteralInteger":
                    return int(base.dump()) * ureg(unit_name)
                elif base_name == "LiteralReal":
                    return float(base.dump()) * ureg(unit_name)
        
        base_dump = base.dump()
        
        if base_name == "LiteralString":
            return base_dump.strip('"')
        elif base_name == "LiteralInteger":
            return int(base_dump)
        elif base_name == "LiteralReal":
            return float(base_dump)
        elif base_name in ("LiteralTrue", "LiteralFalse"):
            return base_name == "LiteralTrue"
        elif base_name == "LiteralNull":
            return None
        elif base_name == "FeatureReferenceExpression":
            return base_dump
        else:
            return base_dump


class Part(Usage):
    sysml_type = 'part'
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = PartDefinition()
        else:
            self.grammar = PartUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Item(Usage):
    sysml_type = 'item'
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = ItemDefinition()
        else:
            self.grammar = ItemUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Port(Usage):
    sysml_type = 'port'
    def __init__(self, definition=False, name=None, shortname=None, conjugated=False):
        Usage.__init__(self)
        if definition:
            self.grammar = PortDefinition()
        else:
            self.grammar = PortUsage()

        self.is_definition = definition
        self.conjugated = conjugated
        self.port_attributes = []  # list of (name, type_name)
        self.port_in_items = []  # list of (name, type_name)
        self.port_out_items = []  # list of (name, type_name)
        self.port_inout_items = []  # list of (name, type_name)

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)

    def add_attribute(self, name, type_name=None):
        """Add an attribute to the port definition.

        Args:
            name: Attribute name
            type_name: Optional type
        """
        self.port_attributes.append((name, type_name))
        return self

    def add_in_item(self, name, type_name=None):
        """Add an input item to the port definition.

        Args:
            name: Item name
            type_name: Optional type
        """
        self.port_in_items.append((name, type_name))
        return self

    def add_out_item(self, name, type_name=None):
        """Add an output item to the port definition.

        Args:
            name: Item name
            type_name: Optional type
        """
        self.port_out_items.append((name, type_name))
        return self

    def add_inout_item(self, name, type_name=None):
        """Add an inout item to the port definition.

        Args:
            name: Item name
            type_name: Optional type
        """
        self.port_inout_items.append((name, type_name))
        return self

    def dump(self, child=None):
        # Check if we have enhanced features
        has_port_features = (
            self.port_attributes or self.port_in_items
            or self.port_out_items or self.port_inout_items
        )

        if not has_port_features:
            # Use standard grammar dump for basic ports
            return classtree(self._get_definition(child)).dump()

        # Enhanced dump with in/out items
        keyword = "port def" if self.is_definition else "port"
        name_str = getattr(self, 'name', "") or ""

        body_items = []
        for attr_name, attr_type in self.port_attributes:
            if attr_type:
                body_items.append(f"attribute {attr_name} : {attr_type}")
            else:
                body_items.append(f"attribute {attr_name}")

        for item_name, item_type in self.port_out_items:
            if item_type:
                body_items.append(f"out item {item_name} : {item_type}")
            else:
                body_items.append(f"out item {item_name}")

        for item_name, item_type in self.port_in_items:
            if item_type:
                body_items.append(f"in item {item_name} : {item_type}")
            else:
                body_items.append(f"in item {item_name}")

        for item_name, item_type in self.port_inout_items:
            if item_type:
                body_items.append(f"inout item {item_name} : {item_type}")
            else:
                body_items.append(f"inout item {item_name}")

        return f"{keyword} {name_str} {{\n   " + ";\n   ".join(body_items) + ";\n}"


class Interface(Usage):
    sysml_type = 'interface'
    def __init__(self, definition=False, name=None, shortname=None):
        self.is_definition = definition
        self.name = name if name else str(uuidlib.uuid4())
        self.children = []
        self.typedby = None
        self.parent = None
        self.grammar = True
        self.iface_shortname = shortname
        self.ends = []  # list of (name, type_name, multiplicity, children)
        self.connections = []  # list of (from_path, to_path)

        if definition:
            self.keyword = "interface def"
        else:
            self.keyword = "interface"

    def add_end(self, name, type_name=None, multiplicity=None):
        """Add an end to the interface definition.

        Args:
            name: End name
            type_name: Optional type (e.g., 'FuelOutPort')
            multiplicity: Optional multiplicity (e.g., '1', '1..*')
        """
        self.ends.append((name, type_name, multiplicity))
        return self

    def add_connection(self, from_path, to_path):
        """Add a connection between ends.

        Args:
            from_path: Source path (e.g., 'suppliedBy.hot')
            to_path: Target path (e.g., 'deliveredTo.hot')
        """
        self.connections.append((from_path, to_path))
        return self

    def _set_typed_by(self, typed):
        """Set typing (`:`) for interface usage."""
        self._typed_by_name = typed.name if hasattr(typed, 'name') else str(typed)
        return self

    def _set_specializes(self, *parents):
        """Set specialization (`:>`) for interface definitions."""
        self._specializes_names = [
            p.name if hasattr(p, 'name') else str(p) for p in parents
        ]
        return self

    def dump(self):
        name_str = getattr(self, 'name', "") or ""
        keyword = getattr(self, 'keyword', 'interface')

        # Build type/specialization suffix
        type_suffix = ""
        if hasattr(self, '_typed_by_name') and self._typed_by_name:
            type_suffix = f" : {self._typed_by_name}"
        elif hasattr(self, '_specializes_names') and self._specializes_names:
            type_suffix = " :> " + ", ".join(self._specializes_names)

        body_items = []

        for end_name, end_type, end_mult in self.ends:
            mult_str = f"[{end_mult}]" if end_mult else ""
            if end_type:
                body_items.append(f"end {end_name} : {end_type}{mult_str};")
            else:
                body_items.append(f"end {end_name}{mult_str};")

        for from_path, to_path in self.connections:
            body_items.append(f"connect {from_path} to {to_path};")

        if body_items:
            body = " {\n   " + "\n   ".join(body_items) + "\n}"
            return f"{keyword} {name_str}{type_suffix}{body}"
        else:
            return f"{keyword} {name_str}{type_suffix};"


class Action(Usage):
    sysml_type = 'action'
    def __init__(self, definition=False, name=None, shortname=None, grammar=None):
        # If grammar is provided (from load_from_grammar), use it
        if grammar is not None:
            self.grammar = grammar
        else:
            # Initialize grammar properly (like Part does)
            if definition:
                self.grammar = ActionDefinition()
                self.grammar.declaration.identification.declaredName = name if name else None
            else:
                self.grammar = ActionUsage(None)
                if self.grammar.declaration and hasattr(self.grammar.declaration, 'declaration') and self.grammar.declaration.declaration:
                    if hasattr(self.grammar.declaration.declaration, 'identification') and self.grammar.declaration.declaration.identification:
                        self.grammar.declaration.declaration.identification.declaredName = name if name else None
        
        self.is_definition = definition
        self.action_shortname = shortname
        self.name = name if name else str(uuidlib.uuid4())
        self.children = []
        self.typedby = None
        self.parent = None
        self.action_inputs = []  # List of (name, type_name)
        self.action_outputs = []
        
        if definition:
            self.keyword = "action def"
        else:
            self.keyword = "action"

    def add_input(self, name, type_name=None):
        """Add an input parameter (in) to the action.
        
        Args:
            name: Name of the input
            type_name: Optional type (e.g., 'Scene')
        """
        self.action_inputs.append((name, type_name))
        return self
    
    def add_output(self, name, type_name=None):
        """Add an output parameter (out) to the action.
        
        Args:
            name: Name of the output  
            type_name: Optional type (e.g., 'Image')
        """
        self.action_outputs.append((name, type_name))
        return self

    def _get_definition(self, child=None):
        if self.is_definition:
            keyword = "action def"
        else:
            keyword = "action"
        
        decl = {
            "name": "UsageDeclaration",
            "identification": {
                "name": "Identification",
                "declaredName": self.name if self.name else "",
                "declaredShortName": None
            }
        }
        
        # Build action body with in/out parameters
        body_items = []
        
        # Add inputs
        for inp_name, inp_type in self.action_inputs:
            if inp_type:
                item = f"in {inp_name} : {inp_type};"
            else:
                item = f"in {inp_name};"
            body_items.append(item)
        
        # Add outputs  
        for out_name, out_type in self.action_outputs:
            if out_type:
                item = f"out {out_name} : {out_type};"
            else:
                item = f"out {out_name};"
            body_items.append(item)
        
        body = {"name": "ActionBody", "items": body_items}
        
        if self.is_definition:
            grammar_type = "ActionDefinition"
        else:
            grammar_type = "ActionUsage"
        
        return {
            "name": grammar_type,
            "declaration": decl,
            "body": body
        }

    def load_from_grammar(self, grammar):
        # Set the grammar
        self.grammar = grammar
        
        self.is_definition = False
        self.action_inputs = []
        self.action_outputs = []
        self._nested_actions = []
        
        # Check for 'declaration' directly (for definitions like ActionDefinition, RequirementDefinition)
        decl = getattr(grammar, 'declaration', None)
        if decl and hasattr(decl, 'identification') and decl.identification:
            self.name = decl.identification.declaredName
            self.is_definition = True
            self.keyword = "action def"
        elif hasattr(grammar, 'declaration') and grammar.declaration:
            # Handle nested declaration structure (ActionUsageDeclaration -> UsageDeclaration -> FeatureDeclaration)
            decl = getattr(grammar.declaration, 'declaration', None)
            if decl:
                # Try nested: declaration.declaration.declaration.identification (for ANTLR)
                nested_decl = getattr(decl, 'declaration', None)
                if nested_decl and hasattr(nested_decl, 'identification') and nested_decl.identification:
                    self.name = nested_decl.identification.declaredName
                    self.is_definition = False
                    self.keyword = "action"
                elif hasattr(decl, 'identification') and decl.identification:
                    self.name = decl.identification.declaredName
                    self.is_definition = False
                    self.keyword = "action"
        
        # Extract parameters and nested actions from body
        body = getattr(grammar, 'body', None)
        if body and hasattr(body, 'children'):
            for item in body.children:
                if hasattr(item, 'children'):
                    for child in item.children:
                        child_name = child.__class__.__name__
                        # Extract in/out parameters from NonOccurrenceUsageMember -> DefaultReferenceUsage
                        if child_name == "NonOccurrenceUsageMember":
                            self._extract_parameter_from_non_occurrence(child)
                        elif child_name == "BehaviorUsageMember":
                            self._extract_behavior_usage(child)
                        elif child_name == "ActionNodeMember":
                            self._extract_nested_action(child)
        
        return self
    
    def _extract_parameter_from_non_occurrence(self, non_occ_member):
        """Extract in/out parameter from NonOccurrenceUsageMember -> NonOccurrenceUsageElement -> DefaultReferenceUsage."""
        if hasattr(non_occ_member, 'children'):
            children = non_occ_member.children
            if not isinstance(children, list):
                children = [children]
            for elem in children:
                # elem is NonOccurrenceUsageElement
                if hasattr(elem, 'children'):
                    # elem.children is DefaultReferenceUsage (not a list)
                    usage = elem.children
                    if isinstance(usage, list):
                        usage = usage[0] if usage else None
                    if usage and hasattr(usage, 'declaration') and usage.declaration:
                        # UsageDeclaration has a 'declaration' attribute which is FeatureDeclaration
                        usage_decl = usage.declaration
                        if hasattr(usage_decl, 'declaration') and usage_decl.declaration:
                            feat_decl = usage_decl.declaration
                            if hasattr(feat_decl, 'identification') and feat_decl.identification:
                                name = feat_decl.identification.declaredName
                                # Extract direction from prefix (RefPrefix has direction directly)
                                direction = None
                                if hasattr(usage, 'prefix') and usage.prefix:
                                    prefix = usage.prefix
                                    # RefPrefix has direction directly
                                    if hasattr(prefix, 'direction') and prefix.direction:
                                        dir_obj = prefix.direction
                                        if hasattr(dir_obj, 'isIn') and dir_obj.isIn:
                                            direction = 'in'
                                        elif hasattr(dir_obj, 'isOut') and dir_obj.isOut:
                                            direction = 'out'
                                    # OccurrenceUsagePrefix has nested prefix
                                    elif hasattr(prefix, 'prefix') and prefix.prefix:
                                        inner_prefix = prefix.prefix
                                        if hasattr(inner_prefix, 'direction') and inner_prefix.direction:
                                            dir_obj = inner_prefix.direction
                                            if hasattr(dir_obj, 'isIn') and dir_obj.isIn:
                                                direction = 'in'
                                            elif hasattr(dir_obj, 'isOut') and dir_obj.isOut:
                                                direction = 'out'
                                # Extract type from specialization
                                type_name = None
                                if hasattr(feat_decl, 'specialization') and feat_decl.specialization:
                                    for spec in feat_decl.specialization.specializations:
                                        if hasattr(spec, 'relationship') and spec.relationship:
                                            rel = spec.relationship
                                            type_name = self._extract_type_from_typings(rel)
                                if direction == 'in' and name:
                                    self.action_inputs.append((name, type_name))
                                elif direction == 'out' and name:
                                    self.action_outputs.append((name, type_name))
    
    def _extract_type_from_typings(self, rel):
        """Extract type name from a Typings relationship."""
        if not hasattr(rel, 'typing') or not rel.typing:
            return None
        
        typing = rel.typing
        
        # Direct type attribute (simple case)
        if hasattr(typing, 'type') and typing.type:
            return typing.type.dump()
        
        # TypedBy case: typing.relationships -> FeatureTyping -> relationship -> OwnedFeatureTyping -> type
        if hasattr(typing, 'relationships') and typing.relationships:
            for ft in typing.relationships:
                if hasattr(ft, 'relationship') and ft.relationship:
                    owned = ft.relationship
                    if hasattr(owned, 'type') and owned.type:
                        return owned.type.dump()
        
        return None
    
    def _extract_nested_action(self, action_node_member):
        """Extract nested action from ActionNodeMember."""
        if hasattr(action_node_member, 'children'):
            node = action_node_member.children
            if hasattr(node, 'children'):
                action_node = node.children
                if hasattr(action_node, 'declaration'):
                    decl = action_node.declaration
                    if hasattr(decl, 'identification') and decl.identification:
                        name = decl.identification.declaredName
                        if name:
                            nested_action = Action(name=name)
                            nested_action.load_from_grammar(action_node)
                            self._nested_actions.append(nested_action)
                            self.children.append(nested_action)
    
    def _extract_behavior_usage(self, behavior_usage_member):
        """Extract behavior usage (nested action/state) from BehaviorUsageMember."""
        if hasattr(behavior_usage_member, 'children'):
            for child in behavior_usage_member.children:
                if hasattr(child, 'children'):
                    # child is BehaviorUsageElement, its children contain the actual usage
                    behavior_element = child.children
                    if isinstance(behavior_element, list):
                        usage_list = behavior_element
                    else:
                        usage_list = [behavior_element]
                    for usage in usage_list:
                        if not usage:
                            continue
                        # Check if BehaviorUsageElement has children with the actual usage
                        if hasattr(usage, 'children') and usage.children:
                            inner = usage.children
                            if isinstance(inner, list):
                                inner_list = inner
                            else:
                                inner_list = [inner]
                            for actual_usage in inner_list:
                                if not actual_usage:
                                    continue
                                self._process_nested_usage(actual_usage)
                        elif hasattr(usage, 'declaration'):
                            self._process_nested_usage(usage)
    
    def _process_nested_usage(self, usage):
        """Process a nested usage element (ActionUsage, StateUsage, etc.)."""
        usage_type = usage.__class__.__name__
        
        # Get name from declaration
        name = None
        if hasattr(usage, 'declaration') and usage.declaration:
            decl = usage.declaration
            # Handle nested declaration structure
            while hasattr(decl, 'declaration') and not hasattr(decl, 'identification'):
                decl = decl.declaration
            if hasattr(decl, 'identification') and decl.identification:
                name = decl.identification.declaredName
        
        if not name:
            return
        
        if 'Action' in usage_type:
            nested_action = Action(name=name)
            nested_action.parent = self
            nested_action.load_from_grammar(usage)
            self._nested_actions.append(nested_action)
            self.children.append(nested_action)
    
    def _get_definition(self, child=None):
        # Sync self.name to grammar before getting definition
        if hasattr(self.grammar, 'declaration') and hasattr(self.grammar.declaration, 'identification'):
            self.grammar.declaration.identification.declaredName = self.name
        
        # Get the grammar's get_definition output
        if hasattr(self.grammar, 'get_definition'):
            grammar_def = self.grammar.get_definition()
        else:
            # Fallback - shouldn't happen now
            grammar_def = {"name": "ActionDefinition", "declaration": {}, "body": {}}
        
        if self.is_definition:
            package = {
                "name": "DefinitionElement",
                "ownedRelatedElement": grammar_def,
            }
        else:
            package = {
                "name": "BehaviorUsageElement",
                "ownedRelationship": grammar_def,
            }
            package = {"name": "OccurrenceUsageElement", "ownedRelatedElement": package}

        if child == "DefinitionBody":
            if self.is_definition:
                package = {
                    "name": "DefinitionMember",
                    "prefix": None,
                    "ownedRelatedElement": [package],
                }
            else:
                package = {
                    "name": "OccurrenceUsageMember",
                    "prefix": None,
                    "ownedRelatedElement": [package],
                }
            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        elif child == "PackageBody" or child == None:
            if self.is_definition:
                package = {
                    "name": "PackageMember",
                    "ownedRelatedElement": package,
                    "prefix": None,
                }
            else:
                package = {"name": "UsageElement", "ownedRelatedElement": package}
                package = {
                    "name": "PackageMember",
                    "ownedRelatedElement": package,
                    "prefix": None,
                }

        return package

    def dump(self):
        name_str = getattr(self, 'name', "") or ""
        keyword = getattr(self, 'keyword', 'action')
        
        # Build output with in/out parameters
        parts = [keyword, name_str]
        
        # Add in/out parameters
        params = []
        for inp_name, inp_type in self.action_inputs:
            if inp_type:
                params.append(f"in {inp_name} : {inp_type}")
            else:
                params.append(f"in {inp_name}")
        
        for out_name, out_type in self.action_outputs:
            if out_type:
                params.append(f"out {out_name} : {out_type}")
            else:
                params.append(f"out {out_name}")
        
        # Build type/specialization suffix
        type_suffix = ""
        if hasattr(self, '_typed_by_name') and self._typed_by_name:
            type_suffix = f" : {self._typed_by_name}"
        elif hasattr(self, '_specializes_names') and self._specializes_names:
            type_suffix = " :> " + ", ".join(self._specializes_names)
        
        if params:
            return f"{keyword} {name_str}{type_suffix} {{ " + "; ".join(params) + "; }"
        else:
            return f"{keyword} {name_str}{type_suffix};"

    def _set_typed_by(self, typed):
        """Set typing (`:`) for action usage typed by action definition."""
        self._typed_by_name = typed.name if hasattr(typed, 'name') else str(typed)
        return self

    def _set_specializes(self, *parents):
        """Set specialization (`:>`) for action definitions."""
        self._specializes_names = [
            p.name if hasattr(p, 'name') else str(p) for p in parents
        ]
        return self


class UseCase(Usage):
    sysml_type = 'use_case'
    def __init__(self, definition=False, name=None, shortname=None):
        if definition:
            self.grammar = UseCaseDefinition()
            self.grammar.declaration.identification.declaredName = name if name else None
        else:
            self.grammar = True
        
        self.is_definition = definition
        self.name = name if name else str(uuidlib.uuid4())
        self.children = []
        self.typedby = None
        self.parent = None
        self.subject = None  # (name, type_name)
        self.actors = []  # list of (name, type_name)
        self.includes = []  # list of use case names
        
        if definition:
            self.keyword = "use case def"
        else:
            self.keyword = "use case"

    def _get_definition(self, child=None):
        # Sync name to grammar
        if hasattr(self.grammar, 'declaration') and hasattr(self.grammar.declaration, 'identification'):
            self.grammar.declaration.identification.declaredName = self.name
        
        if hasattr(self.grammar, 'get_definition'):
            grammar_def = self.grammar.get_definition()
        else:
            grammar_def = {"name": "UseCaseDefinition", "declaration": {}, "body": {}}
        
        package = {
            "name": "DefinitionElement",
            "ownedRelatedElement": grammar_def,
        }

        if child == "DefinitionBody":
            package = {
                "name": "DefinitionMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }
            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        elif child == "PackageBody" or child == None:
            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }

        return package

    def set_subject(self, name, type_name=None):
        """Set the subject of the use case.
        
        Args:
            name: Name of the subject
            type_name: Optional type (e.g., 'Vehicle')
        """
        self.subject = (name, type_name)
        return self

    def add_actor(self, name, type_name=None):
        """Add an actor to the use case.
        
        Args:
            name: Name of the actor
            type_name: Optional type (e.g., 'Driver')
        """
        self.actors.append((name, type_name))
        return self

    def add_include(self, use_case):
        """Add an included use case.
        
        Args:
            use_case: UseCase object or name string to include
        """
        name = use_case.name if hasattr(use_case, 'name') else str(use_case)
        self.includes.append(name)
        return self

    def _set_typed_by(self, typed):
        """Set typing (`:`) for use case usage."""
        self._typed_by_name = typed.name if hasattr(typed, 'name') else str(typed)
        return self

    def _set_specializes(self, *parents):
        """Set specialization (`:>`) for use case definitions."""
        self._specializes_names = [
            p.name if hasattr(p, 'name') else str(p) for p in parents
        ]
        return self

    def dump(self):
        name_str = getattr(self, 'name', "") or ""
        keyword = getattr(self, 'keyword', 'use case')
        
        # Build type/specialization suffix
        type_suffix = ""
        if hasattr(self, '_typed_by_name') and self._typed_by_name:
            type_suffix = f" : {self._typed_by_name}"
        elif hasattr(self, '_specializes_names') and self._specializes_names:
            type_suffix = " :> " + ", ".join(self._specializes_names)
        
        # Build body members
        body_items = []
        
        if self.subject:
            subj_name, subj_type = self.subject
            if subj_type:
                body_items.append(f"subject {subj_name} : {subj_type};")
            else:
                body_items.append(f"subject {subj_name};")
        
        for actor_name, actor_type in self.actors:
            if actor_type:
                body_items.append(f"actor {actor_name} : {actor_type};")
            else:
                body_items.append(f"actor {actor_name};")
        
        for inc in self.includes:
            body_items.append(f"include use case {inc};")
        
        if body_items:
            body = " {\n   " + "\n   ".join(body_items) + "\n}"
            return f"{keyword} {name_str}{type_suffix}{body}"
        else:
            return f"{keyword} {name_str}{type_suffix};"


class Requirement(Usage):
    sysml_type = 'requirement'
    def __init__(self, definition=False, name=None, shortname=None):
        if definition:
            self.grammar = RequirementDefinition(None)
            if self.grammar.declaration is not None and hasattr(self.grammar.declaration, 'identification'):
                self.grammar.declaration.identification.declaredName = name if name else None
        else:
            self.grammar = True
        
        self.is_definition = definition
        self.name = name if name else str(uuidlib.uuid4())
        self.children = []
        self.typedby = None
        self.parent = None
        self.req_shortname = shortname
        self.subject = None
        self.actors = []
        self.doc = None
        self.req_attributes = []
        self.req_constraints = []
        self.assume_constraints = []

        if definition:
            self.keyword = "requirement def"
        else:
            self.keyword = "requirement"

    def _get_definition(self, child=None):
        # Sync name to grammar
        if hasattr(self.grammar, 'declaration') and hasattr(self.grammar.declaration, 'identification'):
            self.grammar.declaration.identification.declaredName = self.name
        
        if hasattr(self.grammar, 'get_definition'):
            grammar_def = self.grammar.get_definition()
        else:
            grammar_def = {"name": "RequirementDefinition", "declaration": {}, "body": {}}
        
        package = {
            "name": "DefinitionElement",
            "ownedRelatedElement": grammar_def,
        }

        if child == "DefinitionBody":
            package = {
                "name": "DefinitionMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }
            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        elif child == "PackageBody" or child == None:
            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }

        return package

    def set_subject(self, name, type_name=None):
        """Set the subject of the requirement.

        Args:
            name: Name of the subject
            type_name: Optional type (e.g., 'Vehicle')
        """
        self.subject = (name, type_name)
        return self

    def add_actor(self, name, type_name=None):
        """Add an actor to the requirement.

        Args:
            name: Name of the actor
            type_name: Optional type
        """
        self.actors.append((name, type_name))
        return self

    def set_doc(self, text):
        """Set the documentation string.

        Args:
            text: Documentation text
        """
        self.doc = text
        return self

    def add_attribute(self, name, type_name=None):
        """Add an attribute to the requirement.

        Args:
            name: Attribute name
            type_name: Optional type
        """
        self.req_attributes.append((name, type_name))
        return self

    def add_constraint(self, expr):
        """Add a require constraint expression.

        Args:
            expr: Constraint expression string (e.g., 'massActual <= massReqd')
        """
        self.req_constraints.append(expr)
        return self

    def add_assume_constraint(self, expr):
        """Add an assume constraint expression.

        Args:
            expr: Assume constraint expression string
        """
        self.assume_constraints.append(expr)
        return self

    def _set_typed_by(self, typed):
        """Set typing (`:`) for requirement usage."""
        self._typed_by_name = typed.name if hasattr(typed, 'name') else str(typed)
        return self

    def _set_specializes(self, *parents):
        """Set specialization (`:>`) for requirement definitions."""
        self._specializes_names = [
            p.name if hasattr(p, 'name') else str(p) for p in parents
        ]
        return self

    def dump(self):
        name_str = getattr(self, 'name', "") or ""
        keyword = getattr(self, 'keyword', 'requirement')

        # Add shortname
        shortname_str = ""
        if self.req_shortname:
            shortname_str = f" <{self.req_shortname}>"

        # Build type/specialization suffix
        type_suffix = ""
        if hasattr(self, '_typed_by_name') and self._typed_by_name:
            type_suffix = f" : {self._typed_by_name}"
        elif hasattr(self, '_specializes_names') and self._specializes_names:
            type_suffix = " :> " + ", ".join(self._specializes_names)

        # Build body members
        body_items = []

        if self.doc:
            body_items.append(f"doc /* {self.doc} */")

        if self.subject:
            subj_name, subj_type = self.subject
            if subj_type:
                body_items.append(f"subject {subj_name} : {subj_type};")
            else:
                body_items.append(f"subject {subj_name};")

        for actor_name, actor_type in self.actors:
            if actor_type:
                body_items.append(f"actor {actor_name} : {actor_type};")
            else:
                body_items.append(f"actor {actor_name};")

        for attr_name, attr_type in self.req_attributes:
            if attr_type:
                body_items.append(f"attribute {attr_name} : {attr_type};")
            else:
                body_items.append(f"attribute {attr_name};")

        for expr in self.req_constraints:
            body_items.append(f"require constraint {{ {expr} }}")

        for expr in self.assume_constraints:
            body_items.append(f"assume constraint {{ {expr} }}")

        if body_items:
            body = " {\n   " + "\n   ".join(body_items) + "\n}"
            return f"{keyword}{shortname_str} {name_str}{type_suffix}{body}"
        else:
            return f"{keyword}{shortname_str} {name_str}{type_suffix};"


class Message(Usage):
    sysml_type = 'message'
    def __init__(self, name=None, from_port=None, to_port=None, of_type=None):
        """Create a message.

        Args:
            name: Optional message name
            from_port: Source port/part path (e.g., 'sensor')
            to_port: Target port/part path (e.g., 'controller')
            of_type: Optional item type (e.g., 'SensorData')
        """
        self.name = name if name else str(uuidlib.uuid4())
        self.children = []
        self.typedby = None
        self.parent = None
        self.grammar = True
        self.from_port = from_port
        self.to_port = to_port
        self.of_type = of_type

    def set_from(self, from_port):
        """Set the source of the message.

        Args:
            from_port: Source path string or element with .name
        """
        self.from_port = from_port.name if hasattr(from_port, 'name') else str(from_port)
        return self

    def set_to(self, to_port):
        """Set the target of the message.

        Args:
            to_port: Target path string or element with .name
        """
        self.to_port = to_port.name if hasattr(to_port, 'name') else str(to_port)
        return self

    def set_of(self, of_type):
        """Set the item type of the message.

        Args:
            of_type: Item type string or element with .name
        """
        self.of_type = of_type.name if hasattr(of_type, 'name') else str(of_type)
        return self

    def dump(self):
        parts = ["message"]

        # Name (if not a UUID)
        name_str = getattr(self, 'name', "") or ""
        try:
            import uuid as _uuid
            _uuid.UUID(name_str)
            # It's a UUID - anonymous message, skip name
        except ValueError:
            parts.append(name_str)

        if self.of_type:
            parts.append(f"of {self.of_type}")

        if self.from_port and self.to_port:
            parts.append(f"from {self.from_port} to {self.to_port}")
        elif self.to_port:
            parts.append(f"to {self.to_port}")

        return " ".join(parts) + ";"


class _BehaviorUsage(Usage):
    """Base class for behavior-style usages (state, action, etc.).
    
    These get wrapped in BehaviorUsageElement rather than StructureUsageElement.
    """
    # Subclasses should set _is_definition_grammar based on grammar class
    _is_definition_grammar = False
    
    def _get_definition(self, child=None):
        # Determine if this is a definition or usage based on grammar class name
        grammar_cls_name = type(self.grammar).__name__
        is_def = grammar_cls_name.endswith('Definition')
        
        if is_def:
            package = self.behavior_definition_dump(child)
        else:
            package = self.usage_dump(child)

        if child is None:
            package = {
                "name": "PackageBodyElement",
                "ownedRelationship": [package],
                "prefix": None,
            }
        return package
    
    def usage_dump(self, child):
        # This is a behavior usage, not a structure usage.
        package = {
            "name": "BehaviorUsageElement",
            "ownedRelationship": self.grammar.get_definition(),
        }
        package = {"name": "OccurrenceUsageElement", "ownedRelatedElement": package}

        if child == "DefinitionBody":
            package = {
                "name": "OccurrenceUsageMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }
            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        else:
            package = {"name": "UsageElement", "ownedRelatedElement": package}
            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }
        return package

    def behavior_definition_dump(self, child):
        package = {
            "name": "DefinitionElement",
            "ownedRelatedElement": self.grammar.get_definition(),
        }

        if child == "DefinitionBody":
            package = {
                "name": "DefinitionMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }
            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        else:
            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }
        return package


class _NonOccurrenceUsage(Usage):
    """Base class for non-occurrence usages (attribute, calculation, constraint, etc.).
    
    These get wrapped in NonOccurrenceUsageElement rather than StructureUsageElement.
    """
    def _get_definition(self, child=None):
        grammar_cls_name = type(self.grammar).__name__
        is_def = grammar_cls_name.endswith('Definition')
        
        if is_def:
            package = self.nonocc_definition_dump(child)
        else:
            package = self.usage_dump(child)

        if child is None:
            package = {
                "name": "PackageBodyElement",
                "ownedRelationship": [package],
                "prefix": None,
            }
        return package
    
    def usage_dump(self, child):
        # Add packaging for non-occurrence usage
        package = {
            "name": "NonOccurrenceUsageElement",
            "ownedRelatedElement": self.grammar.get_definition(),
        }

        if child == "DefinitionBody":
            package = {
                "name": "NonOccurrenceUsageMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }
            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        else:
            package = {"name": "UsageElement", "ownedRelatedElement": package}
            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }
        return package

    def nonocc_definition_dump(self, child):
        package = {
            "name": "DefinitionElement",
            "ownedRelatedElement": self.grammar.get_definition(),
        }

        if child == "DefinitionBody":
            package = {
                "name": "DefinitionMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }
            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        else:
            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }
        return package


class Transition:
    """Represents a state machine transition.
    
    Attributes:
        name: Transition name (if any)
        source: Source state name (for explicit transitions)
        trigger: Trigger event (accept parameter)
        guard: Guard condition expression
        target: Target state name
        effect: Effect action
        is_entry: Whether this is an entry transition
        parent: Parent State element
    """
    def __init__(self):
        self.name = None
        self.source = None
        self.trigger = None
        self.guard = None
        self.target = None
        self.effect = None
        self.is_entry = False
        self.grammar = None
        self.parent = None
    
    def load_from_grammar(self, grammar, is_entry=False):
        """Load transition from grammar element.
        
        Args:
            grammar: TargetTransitionUsage, EntryTransitionMember, TransitionUsageMember, or similar
            is_entry: Whether this is an entry transition
        """
        self.grammar = grammar
        self.is_entry = is_entry
        
        if grammar.__class__.__name__ == 'EntryTransitionMember':
            self.is_entry = True
            self._load_from_entry_transition(grammar)
        elif grammar.__class__.__name__ == 'TargetTransitionUsageMember':
            self._load_from_target_transition(grammar)
        elif grammar.__class__.__name__ == 'TargetTransitionUsage':
            self._load_from_target_transition_usage(grammar)
        elif grammar.__class__.__name__ == 'TransitionUsageMember':
            self._load_from_transition_usage_member(grammar)
        
        return self
    
    def _load_from_transition_usage_member(self, member):
        """Load from TransitionUsageMember (explicit `transition name first X then Y;`)."""
        if hasattr(member, 'children') and member.children:
            usage = member.children
            if hasattr(usage, '__class__') and usage.__class__.__name__ == 'TransitionUsage':
                self._load_from_transition_usage(usage)
    
    def _load_from_transition_usage(self, usage):
        """Load from TransitionUsage."""
        # Extract name from declaration
        if hasattr(usage, 'declaration') and usage.declaration:
            decl = usage.declaration
            while hasattr(decl, 'declaration') and not hasattr(decl, 'identification'):
                decl = decl.declaration
            if hasattr(decl, 'identification') and decl.identification:
                self.name = decl.identification.declaredName
        
        # Extract source and target from ownedRelationship
        if hasattr(usage, 'children'):
            for child in usage.children:
                child_name = child.__class__.__name__
                if child_name == 'TransitionSourceMember':
                    self._extract_source(child)
                elif child_name == 'TransitionSuccessionMember':
                    self._extract_target(child)
                elif child_name == 'TriggerActionMember':
                    self._extract_trigger(child)
                elif child_name == 'GuardExpressionMember':
                    self._extract_guard(child)
                elif child_name == 'EffectBehaviorMember':
                    self._extract_effect(child)
    
    def _extract_source(self, source_member):
        """Extract source from TransitionSourceMember."""
        if hasattr(source_member, 'children') and source_member.children:
            qname = source_member.children
            if isinstance(qname, list):
                qname = qname[0]
            if hasattr(qname, 'names'):
                self.source = '.'.join(qname.names)
    
    def _load_from_entry_transition(self, entry_member):
        """Load from EntryTransitionMember."""
        if hasattr(entry_member, 'children') and entry_member.children:
            child = entry_member.children
            if child.__class__.__name__ == 'GuardedTargetSuccession':
                self._load_from_guarded_succession(child)
            elif child.__class__.__name__ == 'TransitionSuccession':
                self._extract_target_from_succession(child)
    
    def _load_from_target_transition(self, target_member):
        """Load from TargetTransitionUsageMember."""
        if hasattr(target_member, 'children') and target_member.children:
            usage = target_member.children
            if hasattr(usage, '__class__') and usage.__class__.__name__ == 'TargetTransitionUsage':
                self._load_from_target_transition_usage(usage)
    
    def _load_from_target_transition_usage(self, usage):
        """Load from TargetTransitionUsage."""
        if hasattr(usage, 'children'):
            for child in usage.children:
                child_name = child.__class__.__name__
                if child_name == 'TriggerActionMember':
                    self._extract_trigger(child)
                elif child_name == 'GuardExpressionMember':
                    self._extract_guard(child)
                elif child_name == 'EffectBehaviorMember':
                    self._extract_effect(child)
                elif child_name == 'TransitionSuccessionMember':
                    self._extract_target(child)
    
    def _load_from_guarded_succession(self, guarded):
        """Load from GuardedTargetSuccession."""
        if hasattr(guarded, 'children'):
            for child in guarded.children:
                if child.__class__.__name__ == 'GuardExpressionMember':
                    self._extract_guard(child)
                elif child.__class__.__name__ == 'TransitionSuccessionMember':
                    self._extract_target(child)
    
    def _extract_trigger(self, trigger_member):
        """Extract trigger from TriggerActionMember."""
        if hasattr(trigger_member, 'children') and trigger_member.children:
            trigger = trigger_member.children
            if hasattr(trigger, 'children') and trigger.children:
                accept_param = trigger.children
                if hasattr(accept_param, 'children'):
                    for param in accept_param.children:
                        if param.__class__.__name__ == 'PayloadParameterMember':
                            if hasattr(param, 'children') and param.children:
                                payload = param.children
                                # PayloadParameter can have .children (PayloadFeature) or .identification
                                if hasattr(payload, 'children') and payload.children:
                                    feat = payload.children
                                    if hasattr(feat, 'identification') and feat.identification:
                                        self.trigger = feat.identification.declaredName
                                    elif hasattr(feat, 'dump'):
                                        self.trigger = feat.dump()
                                elif hasattr(payload, 'identification') and payload.identification:
                                    self.trigger = payload.identification.declaredName
    
    def _extract_guard(self, guard_member):
        """Extract guard from GuardExpressionMember."""
        if hasattr(guard_member, 'children') and guard_member.children:
            self.guard = guard_member.children.dump()
    
    def _extract_effect(self, effect_member):
        """Extract effect from EffectBehaviorMember."""
        if hasattr(effect_member, 'children') and effect_member.children:
            effect = effect_member.children
            if hasattr(effect, 'declaration') and effect.declaration:
                self.effect = effect.declaration.dump()
    
    def _extract_target(self, succession_member):
        """Extract target from TransitionSuccessionMember."""
        if hasattr(succession_member, 'children') and succession_member.children:
            succession = succession_member.children
            if hasattr(succession, 'children') and succession.children:
                self._extract_target_from_succession(succession)
    
    def _extract_target_from_succession(self, succession):
        """Extract target from TransitionSuccession."""
        if hasattr(succession, 'children') and succession.children:
            connector = succession.children
            if hasattr(connector, 'children'):
                target_list = connector.children
                if isinstance(target_list, list) and target_list:
                    target = target_list[0]
                    if hasattr(target, 'dump'):
                        self.target = target.dump()
                elif hasattr(target_list, 'dump'):
                    self.target = target_list.dump()
    
    def __repr__(self):
        parts = []
        if self.trigger:
            parts.append(f"trigger={self.trigger!r}")
        if self.guard:
            parts.append(f"guard={self.guard!r}")
        if self.target:
            parts.append(f"target={self.target!r}")
        if self.is_entry:
            parts.append("entry=True")
        return f"Transition({', '.join(parts)})"


class State(_BehaviorUsage):
    sysml_type = 'state'
    """SysML v2 State Machine state usage/definition.
    
    Usage:
        State()                              # state ;
        State(name='Idle')                   # state Idle;
        State(definition=True, name='Mode')  # state def Mode;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = StateDefinition()
        else:
            self.grammar = StateUsage()

        self.transitions = []
        self.entry_actions = []
        self.exit_actions = []
        self.do_actions = []

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)

    def load_from_grammar(self, grammar):
        """Load state from grammar, extracting nested states, transitions, and actions."""
        self.grammar = grammar
        self.children = []
        self.transitions = []
        self.entry_actions = []
        self.exit_actions = []
        self.do_actions = []
        
        # Extract name
        if hasattr(grammar, 'declaration') and grammar.declaration:
            decl = grammar.declaration
            # Handle nested declaration structure
            while hasattr(decl, 'declaration') and not hasattr(decl, 'identification'):
                decl = decl.declaration
            if hasattr(decl, 'identification') and decl.identification:
                self.name = decl.identification.declaredName
        
        # Extract nested states, transitions, and actions from body
        # StateDefinition: grammar.body -> StateDefBody -> children -> StateBodyPart -> children -> items
        # StateUsage: grammar.body -> StateUsageBody -> children -> StateDefBody -> children -> StateBodyPart -> children -> items
        body = getattr(grammar, 'body', None)
        if body is None:
            return self
        
        # Handle StateUsageBody wrapper (has .children -> StateDefBody)
        body_type = body.__class__.__name__
        if body_type == 'StateUsageBody':
            body = body.children
        if body is None:
            return self
        
        if not hasattr(body, 'children'):
            return self
            
        state_body_part = body.children
        if state_body_part is None:
            return self
        
        if hasattr(state_body_part, 'children'):
            items = state_body_part.children
        elif isinstance(state_body_part, list):
            items = state_body_part
        else:
            items = []
        
        if not items:
            return self
        
        for item in items:
            if not hasattr(item, 'children') or not item.children:
                continue
            # Each StateBodyItem can have multiple members (e.g., state + transition)
            for member in item.children:
                member_name = member.__class__.__name__
                
                if member_name == 'BehaviorUsageMember':
                    self._extract_state_from_behavior_member(member)
                elif member_name == 'TargetTransitionUsageMember':
                    self._extract_transition(member)
                elif member_name == 'EntryTransitionMember':
                    self._extract_entry_transition(member)
                elif member_name == 'TransitionUsageMember':
                    self._extract_transition(member)
                elif member_name == 'EntryActionMember':
                    self._extract_entry_action(member)
                elif member_name == 'ExitActionMember':
                    self._extract_exit_action(member)
                elif member_name == 'DoActionMember':
                    self._extract_do_action(member)
        
        return self
    
    def _extract_state_from_behavior_member(self, behavior_member):
        """Extract nested state from BehaviorUsageMember."""
        if hasattr(behavior_member, 'children'):
            for child in behavior_member.children:
                if hasattr(child, 'children'):
                    # child is BehaviorUsageElement, its children is the actual usage (StateUsage, etc.)
                    usage = child.children
                    if not usage:
                        continue
                    
                    usage_type = usage.__class__.__name__
                    if usage_type in ('StateUsage', 'StateDefinition'):
                        is_def = usage_type == 'StateDefinition'
                        nested_state = State(definition=is_def)
                        nested_state.parent = self
                        nested_state.load_from_grammar(usage)
                        self.children.append(nested_state)
    
    def _extract_transition(self, target_member):
        """Extract transition from TargetTransitionUsageMember."""
        transition = Transition()
        transition.parent = self
        transition.load_from_grammar(target_member)
        self.transitions.append(transition)
    
    def _extract_entry_transition(self, entry_member):
        """Extract entry transition from EntryTransitionMember."""
        transition = Transition()
        transition.parent = self
        transition.load_from_grammar(entry_member, is_entry=True)
        self.transitions.append(transition)
    
    def _extract_entry_action(self, entry_member):
        """Extract entry action from EntryActionMember."""
        if hasattr(entry_member, 'children') and entry_member.children:
            action = entry_member.children
            self.entry_actions.append(action)
    
    def _extract_exit_action(self, exit_member):
        """Extract exit action from ExitActionMember."""
        if hasattr(exit_member, 'children') and exit_member.children:
            action = exit_member.children
            self.exit_actions.append(action)
    
    def _extract_do_action(self, do_member):
        """Extract do action from DoActionMember."""
        if hasattr(do_member, 'children') and do_member.children:
            action = do_member.children
            self.do_actions.append(action)


class Constraint(_NonOccurrenceUsage):
    sysml_type = 'constraint'
    """SysML v2 Constraint usage/definition.
    
    Usage:
        Constraint()                              # constraint ;
        Constraint(name='PowerLimit')             # constraint PowerLimit;
        Constraint(definition=True, name='Limit') # constraint def Limit;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = ConstraintDefinition()
        else:
            self.grammar = ConstraintUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Connection(Usage):
    sysml_type = 'connection'
    """SysML v2 Connection usage/definition.
    
    Usage:
        Connection()                                  # connection ;
        Connection(name='wire')                       # connection wire;
        Connection(definition=True, name='DataLink')  # connection def DataLink;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = ConnectionDefinition()
        else:
            self.grammar = ConnectionUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Flow(Usage):
    sysml_type = 'flow'
    """SysML v2 Flow connection usage/definition.
    
    Usage:
        Flow()                                       # flow ;
        Flow(name='fuelFlow')                        # flow fuelFlow;
        Flow(definition=True, name='WaterFlow')      # flow def WaterFlow;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = FlowConnectionDefinition()
        else:
            self.grammar = FlowConnectionUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Calculation(_NonOccurrenceUsage):
    sysml_type = 'calculation'
    """SysML v2 Calculation usage/definition.
    
    Usage:
        Calculation()                                   # calc ;
        Calculation(name='computeArea')                 # calc computeArea;
        Calculation(definition=True, name='Distance')   # calc def Distance;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = CalculationDefinition()
        else:
            self.grammar = CalculationUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Enumeration(Usage):
    sysml_type = 'enumeration'
    """SysML v2 Enumeration definition.
    
    Note: SysML v2 only has EnumerationDefinition, no EnumerationUsage.
    
    Usage:
        Enumeration(name='Color')  # enum def Color;
    """
    def __init__(self, definition=True, name=None, shortname=None):
        Usage.__init__(self)
        # EnumerationDefinition is the only form
        self.grammar = EnumerationDefinition()
        
        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Allocation(Usage):
    sysml_type = 'allocation'
    """SysML v2 Allocation usage/definition.
    
    Allocation represents mapping from one model element to another.
    
    Usage:
        Allocation()                                  # allocation ;
        Allocation(name='alloc1')                     # allocation alloc1;
        Allocation(definition=True, name='AllocSpec') # allocation def AllocSpec;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = AllocationDefinition()
        else:
            self.grammar = AllocationUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Metadata(_NonOccurrenceUsage):
    sysml_type = 'metadata'
    """SysML v2 Metadata usage/definition.
    
    Metadata attaches additional information to model elements.
    
    Usage:
        Metadata()                                       # metadata ;
        Metadata(name='tag1')                            # metadata tag1;
        Metadata(definition=True, name='AuthorMeta')     # metadata def AuthorMeta;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = MetadataDefinition()
        else:
            self.grammar = MetadataUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Rendering(Usage):
    sysml_type = 'rendering'
    """SysML v2 Rendering usage/definition.
    
    Rendering specifies how views should be rendered.
    
    Usage:
        Rendering()                                    # rendering ;
        Rendering(name='myRender')                     # rendering myRender;
        Rendering(definition=True, name='DefRender')   # rendering def DefRender;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = RenderingDefinition()
        else:
            self.grammar = RenderingUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Individual(Usage):
    sysml_type = 'individual'
    """SysML v2 Individual usage/definition.
    
    Individual represents a specific instance or occurrence.
    
    Usage:
        Individual()                                     # individual ;
        Individual(name='instance1')                     # individual instance1;
        Individual(definition=True, name='DefIndiv')     # individual def DefIndiv;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = IndividualDefinition()
        else:
            self.grammar = IndividualUsageSimple()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class FlowDef(Usage):
    sysml_type = 'flow'
    """SysML v2 FlowDefinition alternate form.
    
    Note: This is the simpler 'flow def' form (distinct from FlowConnectionDefinition).
    Usage already provides Flow class for flowConnectionUsage/Definition.
    
    Usage:
        FlowDef(name='DataStream')   # flow def DataStream;
    """
    def __init__(self, name=None, shortname=None):
        Usage.__init__(self)
        self.grammar = FlowDefinition()
        
        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class View(Usage):
    sysml_type = 'view'
    """SysML v2 View usage/definition.
    
    Views define how models are presented and filtered.
    
    Usage:
        View()                                  # view ;
        View(name='systemOverview')             # view systemOverview;
        View(definition=True, name='SysView')   # view def SysView;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = ViewDefinition()
        else:
            self.grammar = ViewUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Viewpoint(_BehaviorUsage):
    sysml_type = 'viewpoint'
    """SysML v2 Viewpoint usage/definition.
    
    Viewpoints specify viewing perspectives with stakeholder concerns.
    
    Usage:
        Viewpoint()                                   # viewpoint ;
        Viewpoint(name='stakeholderVP')               # viewpoint stakeholderVP;
        Viewpoint(definition=True, name='VPDef')      # viewpoint def VPDef;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = ViewpointDefinition()
        else:
            self.grammar = ViewpointUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Concern(_BehaviorUsage):
    sysml_type = 'concern'
    """SysML v2 Concern usage/definition.
    
    Concerns represent stakeholder concerns for viewpoints.
    
    Usage:
        Concern()                                  # concern ;
        Concern(name='security')                   # concern security;
        Concern(definition=True, name='Safety')    # concern def Safety;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = ConcernDefinition()
        else:
            self.grammar = ConcernUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Case(_BehaviorUsage):
    sysml_type = 'case'
    """SysML v2 Case usage/definition.
    
    A case is a broad classifier for analysis, verification, and use cases.
    
    Usage:
        Case()                                  # case ;
        Case(name='scenario1')                  # case scenario1;
        Case(definition=True, name='CaseSpec')  # case def CaseSpec;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = CaseDefinition()
        else:
            self.grammar = CaseUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class AnalysisCase(_BehaviorUsage):
    sysml_type = 'analysis'
    """SysML v2 AnalysisCase usage/definition.
    
    Analysis cases represent analytical scenarios or studies.
    
    Usage:
        AnalysisCase()                                  # analysis ;
        AnalysisCase(name='thermal1')                   # analysis thermal1;
        AnalysisCase(definition=True, name='Thermal')   # analysis def Thermal;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = AnalysisCaseDefinition()
        else:
            self.grammar = AnalysisCaseUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class VerificationCase(_BehaviorUsage):
    sysml_type = 'verification'
    """SysML v2 VerificationCase usage/definition.
    
    Verification cases represent verification scenarios or tests.
    
    Usage:
        VerificationCase()                                    # verification ;
        VerificationCase(name='test1')                        # verification test1;
        VerificationCase(definition=True, name='Verify1')     # verification case def Verify1;
    """
    def __init__(self, definition=False, name=None, shortname=None):
        Usage.__init__(self)
        if definition:
            self.grammar = VerificationCaseDefinition()
        else:
            self.grammar = VerificationCaseUsage()

        if name is not None:
            self._set_name(name)
        if shortname is not None:
            self._set_name(shortname, short=True)


class Reference(Usage):
    sysml_type = 'reference'
    def __init__(self, name=None, shortname=None, redefines=None):
        self.name = name if name else str(uuidlib.uuid4())
        self.children = []
        self.typedby = None
        self.grammar = None
        self.parent = None
        self.shortname = shortname
        self.redefines = redefines  # for redefinition like ref :>> name :
        self.ref_type = None  # type reference

    def set_type(self, type_obj):
        """Set the type this reference points to.
        
        Args:
            type_obj: Another element (Item, Part, etc.) to reference
        """
        self.ref_type = type_obj
        return self

    def _set_typed_by(self, type_obj):
        """Alias for set_type for consistency with other classes."""
        return self.set_type(type_obj)

    def dump(self):
        name_str = getattr(self, 'name', "") or ""
        type_str = ""
        
        if self.ref_type:
            type_name = getattr(self.ref_type, 'name', str(self.ref_type))
            type_str = f" : {type_name}"
        
        if self.redefines:
            return f"ref :>> {name_str}{type_str};"
        
        return f"ref {name_str}{type_str};"


class DefaultReference(Usage):
    def __init__(self):
        Usage.__init__(self)
        self.grammar = DefaultReferenceUsage()

    def set_direction(self, direction):
        r = RefPrefix()
        if direction == "in":
            r.direction.isIn = True
        elif direction == "out":
            r.direction.isOut = True
        elif direction == "inout":
            r.direction.isInOut = True
        else:
            raise ValueError
        self.grammar.prefix = r
        return self

    def usage_dump(self, child):
        # This is a usage.

        self._ensure_body("definition")

        # Add packaging
        package = {
            "name": "NonOccurrenceUsageElement",
            "ownedRelatedElement": self.grammar.get_definition(),
        }

        if child == "DefinitionBody":
            package = {
                "name": "NonOccurrenceUsageMember",
                "prefix": None,
                "ownedRelatedElement": [package],
            }

            package = {"name": "DefinitionBodyItem", "ownedRelationship": [package]}
        elif "PackageBody":
            package = {"name": "UsageElement", "ownedRelatedElement": package}
            package = {
                "name": "PackageMember",
                "ownedRelatedElement": package,
                "prefix": None,
            }

        return package

    def _get_definition(self, child=None):
        package = self.usage_dump(child)

        if child is None:
            package = {
                "name": "PackageBodyElement",
                "ownedRelationship": [package],
                "prefix": None,
            }

        # Add the typed by definition to the package output
        if self.typedby is not None:
            if child is None:
                package["ownedRelationship"].insert(
                    0, self.typedby._get_definition(child="PackageBody")
                )
            elif child == "PackageBody":
                package = [self.typedby._get_definition(child="PackageBody"), package]
            else:
                package["ownedRelationship"].insert(
                    0, self.typedby._get_definition(child=child)["ownedRelationship"][0]
                )

        return package

    # def dump(self, child=None):
    #     package = self.usage_dump(child)

    #     if child is None:
    #         package = {
    #             "name": "PackageBodyElement",
    #             "ownedRelationship": [package],
    #             "prefix": None,
    #         }

    #     # Add the typed by definition to the package output
    #     if self.typedby is not None:
    #         if child is None:
    #             package["ownedRelationship"].insert(
    #                 0, self.typedby.dump(child="PackageBody")
    #             )
    #         elif child == "PackageBody":
    #             package = [self.typedby.dump(child="PackageBody"), package]
    #         else:
    #             package["ownedRelationship"].insert(
    #                 0, self.typedby.dump(child=child)["ownedRelationship"][0]
    #             )

    #     return package
