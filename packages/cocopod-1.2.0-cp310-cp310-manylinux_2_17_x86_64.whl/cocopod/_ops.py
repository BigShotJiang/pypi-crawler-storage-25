"""
cocopod 算子模块
实际的算子实现来自 torch.ops.xspeedgate_ops
"""
# 算子通过 torch.ops.xspeedgate_ops 命名空间访问
# 此模块主要提供类型提示支持
import torch

# 从 torch.ops 命名空间导出所有算子
_ops_namespace = torch.ops.cocopod

def __getattr__(name):
    return getattr(_ops_namespace, name)
