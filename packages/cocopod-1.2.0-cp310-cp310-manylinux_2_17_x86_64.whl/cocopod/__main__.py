'''
cocopod 的工具函数, 使用 python -m cocopod --help 查看使用帮助
'''

import ast
import os
import rich
import torch
import typer
import re

from rich.console import Console
from rich.markdown import Markdown
from typing_extensions import Annotated

app = typer.Typer()


def highlight(text):
    '''
    高亮 schema

    text: schema 字符串
    '''
    parts = re.split(r'([,() \t=])', text)
    res = []
    types = {'Tensor', 'Scalar', 'int', 'float', 'bool', 'str'}
    
    for p in parts:
        if p in types:
            res.append(f"\x1b[94m{p}\x1b[0m")  # 蓝色类型
        elif re.match(r'^[a-zA-Z_]\w*$', p):
            res.append(f"\x1b[92m{p}\x1b[0m")  # 绿色参数
        elif re.match(r'^-?\d+$', p):
            res.append(f"\x1b[93m{p}\x1b[0m")  # 黄色数字
        else:
            res.append(p)
    return "".join(res)


def get_operator_schemas(op, color: bool):
    '''
    打印算子的 schema 字符串, 并可选择高亮

    op: 传入的算子, 必须是已经注册到 torch.ops 的算子
    color: 表示是否进行高亮显示
    '''
    for overload, schema in op._schemas.items():
        if overload == "":
            overload = "default"
        out_str = f"{(op.__name__ + '.' + overload + ':'):50s} {schema}"
        if color:
            out_str = highlight(out_str)
        return out_str


def get_namespace_all_ops(target_namespace: str):
    '''
    打印某个 torch.ops 的命名空间的所有算子

    参数
        target_namespace: 目标命名空间

    返回值
        返回值类型是一个 list, 里面包含目标命名空间所有的算子名, 格式为 命名空间::算子名
    '''
    all_ops = torch._C._dispatch_get_all_op_names()
    return [op for op in all_ops if op.startswith(f"{target_namespace}::")]


def get_func_details(file_path, function_name):
    '''
    获取算子对应的函数声明和说明

    Args:
        file_path: pyi 文件路径, 通常输入 _ops.pyi 的路径, 用来递归地从 from .xxx import * 中寻找定义
        function_name: 算子名, 需要保证 schema 算子名和 pyi 算子名一致, 才能找到相应的 pyi 函数

    Returns:
        ret1: 函数声明字符串
        ret2: 函数注释字符串 (markdown 格式)
    '''
    with open(file_path, "r", encoding="utf-8") as f:
        source = f.read()
        tree = ast.parse(source)

    for node in tree.body:
        # 1. 直接匹配函数名
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name:
            # 提取 docstring
            doc = ast.get_docstring(node)
            
            # 提取函数头声明（排除 docstring 节点）
            full_code = ast.get_source_segment(source, node)
            lines = full_code.splitlines()
            
            # 简单的逻辑：通常第一行是 def...，直到遇到冒号
            declaration = []
            for line in lines:
                declaration.append(line)
                if line.strip().endswith(':'):
                    break
            
            return "\n".join(declaration), doc

        # 2. 递归处理 import *
        if isinstance(node, ast.ImportFrom) and node.module and node.names[0].name == '*':
            base_dir = os.path.dirname(os.path.abspath(file_path))
            module_path = node.module.lstrip('.')
            sub_pyi = os.path.join(base_dir, f"{module_path}.pyi")
            if os.path.exists(sub_pyi):
                src, doc = get_func_details(sub_pyi, function_name)
                if src is not None:
                    return src, doc
    return None, None


@app.command()
def schema(
    op_name: Annotated[str, typer.Argument(help="Operator name")],
    color: Annotated[bool, typer.Option(help="Highlight with color")] = True,
    doc: Annotated[bool, typer.Option(help="print with document")] = True,
    less_env: Annotated[str, typer.Argument(help="environ for LESS")] = "R",
):
    '''
    Print operator schema with color(optional) and document(optional)
    '''
    op = getattr(torch.ops.xspeedgate_ops, op_name)

    if doc:
        schema_str = get_operator_schemas(op, False)
        current_file_path = os.path.abspath(__file__)
        current_dir = os.path.dirname(current_file_path)
        defines, document = get_func_details(os.path.join(current_dir, "_ops.pyi"), op_name)

        if defines is None:
            print(f"{op_name} not found!")

        # R 颜色
        # F 如果内容不满一屏，立刻退出
        # X 禁止清屏
        os.environ["LESS"] = "-" + less_env

        console = Console()
        md = Markdown(document)
        with console.pager(styles=True):
            console.print("[schema]:", markup=False)
            console.print(schema_str + "\n", markup=False)
            console.print("[函数声明]:\n" + defines + "\n\n" + "[说明]:", markup=False)
            console.print(md)
    else:
        schema_str = get_operator_schemas(op, color)
        print(schema_str)


@app.command("list")
def op_list(
    show_schema: Annotated[bool, typer.Option(help="Print with operator schema or just namespace::op_name")] = False,
    schema_color: Annotated[bool, typer.Option(help="Highlight schema with color")] = True
):
    '''
    List all ops in xspeedgate_ops
    '''
    all_xspeedgate_ops = get_namespace_all_ops("xspeedgate_ops")

    if show_schema:
        print("all xspeedgate ops with schema:")
        for op in all_xspeedgate_ops:
            op_name = op.split("::")[-1]
            schema(op_name, schema_color, False)
    else:
        print("all xspeedgate ops:")
        for op in all_xspeedgate_ops:
            print(op)

    print(f"xspeedgate have {len(all_xspeedgate_ops)} ops")


@app.command(hidden=True)
def placeholder():
    '''
    占位符入口, 当只有一个 command 的时候, typer 会将其设为主命令
    '''
    pass


if __name__ == "__main__":
    app()
