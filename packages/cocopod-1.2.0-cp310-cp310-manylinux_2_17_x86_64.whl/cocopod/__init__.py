'''
cocopod 的初始化 py 文件
'''

import torch
from cocopod.cocopod import *

ops = torch.ops.xspeedgate_ops
