'''
cocopod 类型存根
'''

from . import _ops as ops
