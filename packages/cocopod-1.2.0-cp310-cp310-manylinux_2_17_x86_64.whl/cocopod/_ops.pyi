"""
cocopod 算子类型存根
所有算子的类型签名定义
"""

from typing import Optional, Tuple, List
from torch import Tensor


def chunk_fwd_o(
    q: Tensor,
    k: Tensor,
    v: Tensor,
    h: Tensor,
    g: Tensor,
    scale: float,
    cu_seqlens: Optional[Tensor] = None,
    chunk_indices: Optional[Tensor] = None,
    chunk_size: int = 64
) -> Tensor:
    """
    Chunk forward output 计算

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `q` | Tensor | [B, T, H, K] | float16 | Query 张量 |
    | `k` | Tensor | [B, T, H, K] | float16 | Key 张量 |
    | `v` | Tensor | [B, T, H, V] | float16 | Value 张量 |
    | `h` | Tensor | [B*NT, H, K, V] | float16 | Hidden state 张量 |
    | `g` | Tensor | [B, T, H] | float16, float32 | Gate 张量 |
    | `scale` | float | | | 缩放因子 |
    | `cu_seqlens` | Tensor | [N+1] | int32 | 累积序列长度，默认为 None |
    | `chunk_indices` | Tensor | [total_chunks, 2] | int32 | Chunk 索引，默认为 None |
    | `chunk_size` | int | | | Chunk 大小，默认 64 |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `output` | Tensor | [B, T, H, V] | float16 | 输出张量 |

    Constraints:
    - `chunk_size` 必须为 64
    - 所有 Tensor 必须是 CUDA 张量且连续存储
    - `cu_seqlens` 必须有效（varlen 模式）
    - B 必须为 1（varlen 模式）
    """
    ...


def recompute_w_u_fwd(
    k: Tensor,
    v: Tensor,
    beta: Tensor,
    g_cumsum: Tensor,
    A: Tensor,
    cu_seqlens: Optional[Tensor] = None,
    chunk_indices: Optional[Tensor] = None,
    chunk_size: int = 64
) -> Tuple[Tensor, Tensor]:
    """
    重计算 W 和 U 的前向传播

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `k` | Tensor | [B, T, H, K] | float16 | Key 张量 |
    | `v` | Tensor | [B, T, H, V] | float16 | Value 张量 |
    | `beta` | Tensor | [B, T, H] | float16 | Beta 参数张量 |
    | `g_cumsum` | Tensor | [B, T, H] | float16, float32 | Gate 累积和张量 |
    | `A` | Tensor | [B*NT, H, BT, BT] | float16 | A 矩阵 |
    | `cu_seqlens` | Tensor | [N+1] | int32 | 累积序列长度，默认为 None |
    | `chunk_indices` | Tensor | [total_chunks, 2] | int32 | Chunk 索引，默认为 None |
    | `chunk_size` | int | | | Chunk 大小，默认 64 |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `W` | Tensor | [B, T, H, K] | float16 | W 矩阵 |
    | `U` | Tensor | [B, T, H, V] | float16 | U 矩阵 |

    Constraints:
    - `chunk_size` 必须为 64
    - 所有 Tensor 必须是 CUDA 张量且连续存储
    - `cu_seqlens` 和 `chunk_indices` 必须有效
    - `k.dtype == A.dtype`
    """
    ...


def chunk_scaled_dot_kkt_fwd(
    k: Tensor,
    beta: Tensor,
    g_cumsum: Tensor,
    cu_seqlens: Optional[Tensor] = None,
    chunk_indices: Optional[Tensor] = None,
    chunk_size: int = 64
) -> Tensor:
    """
    Chunk scaled dot product K*K^T 前向

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `k` | Tensor | [B, T, H, K] | float16 | Key 张量 |
    | `beta` | Tensor | [B, T, H] | float16 | Beta 参数张量 |
    | `g_cumsum` | Tensor | [B, T, H] | float16, float32 | Gate 累积和张量 |
    | `cu_seqlens` | Tensor | [N+1] | int32 | 累积序列长度，默认为 None |
    | `chunk_indices` | Tensor | [total_chunks, 2] | int32 | Chunk 索引，默认为 None |
    | `chunk_size` | int | | | Chunk 大小，默认 64 |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `output` | Tensor | [B*NT, H, BT, BT] | float16 | K*K^T 结果张量 |

    Constraints:
    - `chunk_size` <= 64
    - 所有 Tensor 必须是 CUDA 张量且连续存储
    - `beta.dtype == k.dtype`
    - `cu_seqlens` 和 `chunk_indices` 必须有效
    """
    ...


def rms_norm_gated_extreme(
    x: Tensor,
    weight: Tensor,
    bias: Optional[Tensor] = None,
    eps: float = 1e-6,
    z: Optional[Tensor] = None,
    group_size: Optional[int] = None,
    norm_before_gate: bool = True,
    is_rms_norm: bool = False
) -> Tuple[Tensor, Tensor, Tensor]:
    """
    RMS Norm Gated Extreme 算子

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `x` | Tensor | [M, N] | float16 | 输入张量 |
    | `weight` | Tensor | [N] | float16 | 权重张量 |
    | `bias` | Tensor | [N] | float16 | 偏置张量，默认为 None |
    | `eps` | float | | | epsilon 值，默认 1e-6 |
    | `z` | Tensor | [M, N] | float16 | Gate 输入，默认为 None |
    | `group_size` | int | | | 分组大小，默认为 None |
    | `norm_before_gate` | bool | | | 是否先做 norm 再 gate，默认 True |
    | `is_rms_norm` | bool | | | 是否为 RMS Norm，默认 False |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `output` | Tensor | [M, N] | float16 | 输出张量 |
    | `mean` | Tensor | [M, 1] | float32 | 均值 |
    | `rstd` | Tensor | [M, 1] | float32 | 逆标准差 |

    Constraints:
    - N <= 8192
    - `x` 必须是 CUDA 张量
    - 若提供 `z`，则 `z.size(1) == N`
    """
    ...


def chunk_gated_delta_rule_fwd_h(
    k: Tensor,
    u: Tensor,
    w: Tensor,
    g: Tensor,
    h0: Optional[Tensor] = None,
    cu_seqlens: Optional[Tensor] = None,
    chunk_indices: Optional[Tensor] = None,
    chunk_offsets: Optional[Tensor] = None,
    chunk_size: int = 64,
    output_final_state: bool = True,
    save_new_value: bool = True
) -> Tuple[Tensor, Optional[Tensor], Optional[Tensor]]:
    """
    Chunk Gated Delta Rule 前向 H 计算

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `k` | Tensor | [B, T, H, K] | float16 | Key 张量 |
    | `u` | Tensor | [B, T, H, V] | float16 | U 张量 |
    | `w` | Tensor | [B, T, H, K] | float16 | W 张量 |
    | `g` | Tensor | [B, T, H] | float16, float32 | Gate 张量 |
    | `h0` | Tensor | [N, H, K, V] | float32 | 初始 hidden state，默认为 None |
    | `cu_seqlens` | Tensor | [N+1] | int32 | 累积序列长度，默认为 None |
    | `chunk_indices` | Tensor | [total_chunks, 2] | int32 | Chunk 索引，默认为 None |
    | `chunk_offsets` | Tensor | [N+1] | int32 | Chunk 偏移，默认为 None |
    | `chunk_size` | int | | | Chunk 大小，默认 64 |
    | `output_final_state` | bool | | | 是否输出最终状态，默认 True |
    | `save_new_value` | bool | | | 是否保存新值，默认 True |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `h` | Tensor | [B*NT, H, K, V] | float16 | Hidden state |
    | `v_new` | Tensor | [B, T, H, V] | float16 | 新 value，当 save_new_value=True |
    | `final_state` | Tensor | [N, H, K, V] | float32 | 最终状态，当 output_final_state=True |

    Constraints:
    - 所有 Tensor 必须是 CUDA 张量且连续存储
    - `cu_seqlens`、`chunk_indices`、`chunk_offsets` 必须有效
    - 当 `h0` 提供时，`output_final_state` 必须为 True
    - 当 `h0` 为 None 时，`output_final_state` 必须为 False
    - `save_new_value` 必须为 True
    - `k.dtype == u.dtype == w.dtype`
    - `u.size(2) % k.size(2) == 0` (H 能被 Hg 整除)
    """
    ...


def moe_active_expert_balance(
    topk_index: Tensor,
    expert_num: int,
    index_have_neg: bool
) -> Tensor:
    """
    MoE 活跃专家均衡

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `topk_index` | Tensor | [m, topk] | int32 | TopK 索引张量 |
    | `expert_num` | int | | | 专家数量 |
    | `index_have_neg` | bool | | | 索引是否包含负值 |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `output` | Tensor | [expert_num] | int32 | 每个专家的活跃 token 数 |

    Constraints:
    - m * topk <= 768
    - topk <= 64
    - expert_num <= 512
    - `topk_index` 必须是 CUDA 张量且连续存储
    """
    ...


def moe_pre_small(
    topk_index: Tensor,
    expert_num: int,
    index_have_neg: bool,
    sort_mode: bool,
    x: Optional[Tensor] = None
) -> Tuple[Tensor, Tensor, Optional[Tensor]]:
    """
    MoE 预处理 (小规模)

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `topk_index` | Tensor | [m, topk] | int32 | TopK 索引张量 |
    | `expert_num` | int | | | 专家数量 |
    | `index_have_neg` | bool | | | 索引是否包含负值 |
    | `sort_mode` | bool | | | 是否使用排序模式 |
    | `x` | Tensor | [m, hidden_dim] | float16, bfloat16, float32 | 输入张量，默认为 None |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `moe_index` | Tensor | [m * topk] | int32 | 排序后的 token 索引 |
    | `sorted_tokens_num_lod` | Tensor | [expert_num + 1] | int32 | 每个专家的 token 数 LOD |
    | `sorted_x` | Tensor | | 同 `x` | 排序后的输入，当 x 不为 None |

    Constraints:
    - m * topk <= 768
    - topk <= 64
    - expert_num <= 512
    - `topk_index` 必须是 CUDA 张量且连续存储
    - 若提供 `x`，必须是 CUDA 张量且连续存储
    """
    ...


def moe_pre_process(
    topk_index: Tensor,
    expert_num: int,
    index_have_neg: bool,
    num_actual_tokens: Optional[int] = None
) -> Tuple[Tensor, Tensor, Tensor]:
    """
    MoE 预处理

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `topk_index` | Tensor | [m, topk] | int32 | TopK 索引张量，必须连续 |
    | `expert_num` | int | | | 专家数量 |
    | `index_have_neg` | bool | | | 索引是否包含负值 |
    | `num_actual_tokens` | int | | | 实际 token 数量，默认为 None |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `moe_index` | Tensor | [m * topk] | int32 | 排序后的 token 索引 |
    | `sorted_tokens_num_lod` | Tensor | [expert_num + 1] | int32 | 每个专家的 token 数 LOD |
    | `experts_num_lod` | Tensor | [cluster_num + 1] | int32 | 专家统计信息 |

    Constraints:
    - m * topk <= 768
    - topk <= 64
    - expert_num <= 512
    - `topk_index` 必须连续存储
    - 若提供 `num_actual_tokens`，必须在 [0, m] 范围内
    """
    ...


def fused_moe(
    x: Tensor,
    w13: Tensor,
    w2: Tensor,
    normed_scores: Optional[Tensor],
    sorted_tokens_num_lod: Tensor,
    sorted_tokens_ids: Tensor,
    experts_statics: Tensor
) -> Tensor:
    """
    融合 MoE 算子

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `x` | Tensor | [num_tokens, hidden_dim] | float16 | 输入张量，必须连续 |
    | `w13` | Tensor | [E, gate_up_dim, hidden_dim] | float16 | W1 和 W3 融合权重，必须连续 |
    | `w2` | Tensor | [E, gate_down_dim, act_dim] | float16 | W2 权重，必须连续 |
    | `normed_scores` | Tensor | [num_tokens, topk] | float16 | 归一化分数，默认为 None |
    | `sorted_tokens_num_lod` | Tensor | [expert_num + 1] | int32 | 排序后 token 数量 LOD |
    | `sorted_tokens_ids` | Tensor | [num_tokens * topk] | int32 | 排序后 token ID |
    | `experts_statics` | Tensor | [13] | int32 | 专家统计信息 |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `output` | Tensor | [num_tokens, topk, gate_down_dim] | float16 | MoE 输出 |

    Constraints:
    - 所有 Tensor 必须是 CUDA 张量且连续存储
    - `x.dtype == w13.dtype == w2.dtype`
    - gate_up_dim == act_dim * 2 (GLU 结构)
    - `sorted_tokens_num_lod.numel() == expert_num + 1`
    - `experts_statics.numel() == 13`
    """
    ...


def fused_moe_full(
    x: Tensor,
    w13: Tensor,
    w2: Tensor,
    topk_index: Tensor,
    normed_scores: Optional[Tensor] = None,
    index_have_neg: bool = False,
    num_actual_tokens: Optional[int] = None
) -> Tensor:
    """
    完整融合 MoE 算子 (包含预处理)

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `x` | Tensor | [m, hidden_dim] | float16 | 输入张量，必须连续 |
    | `w13` | Tensor | [E, gate_up_dim, hidden_dim] | float16 | W1 和 W3 融合权重，必须连续 |
    | `w2` | Tensor | [E, gate_down_dim, act_dim] | float16 | W2 权重，必须连续 |
    | `topk_index` | Tensor | [m, topk] | int32 | TopK 索引，必须连续 |
    | `normed_scores` | Tensor | [m, topk] | float16 | 归一化分数，默认为 None |
    | `index_have_neg` | bool | | | 索引是否包含负值，默认 False |
    | `num_actual_tokens` | int | | | 实际 token 数量，默认为 None |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `output` | Tensor | [m, gate_down_dim] | float16 | MoE 输出 |

    Constraints:
    - m * topk <= 768
    - topk <= 64
    - expert_num <= 512
    - gate_up_dim == act_dim * 2
    - 所有 Tensor 必须是 CUDA 张量且连续存储
    - `x.dtype == w13.dtype == w2.dtype`
    - 若提供 `num_actual_tokens`，必须在 [0, m] 范围内
    """
    ...


def chunk_bwd_dv_local(
    q: Tensor,
    k: Tensor,
    g: Tensor,
    do_: Tensor,
    chunk_size: int,
    scale: float,
    cu_seqlens: Optional[Tensor] = None,
    chunk_indices: Optional[Tensor] = None
) -> Tensor:
    """
    Chunk 反向传播 dV Local 计算

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `q` | Tensor | [B, T, H, K] | float16, bfloat16, float32 | Query 张量 |
    | `k` | Tensor | [B, T, H, K] | 同 `q` | Key 张量 |
    | `g` | Tensor | [B, T, H] | 同 `q` | Gate 张量 |
    | `do_` | Tensor | [B, T, H, V] | float16, bfloat16, float32 | 输出梯度张量 |
    | `chunk_size` | int | | | Chunk 大小 |
    | `scale` | float | | | 缩放因子 |
    | `cu_seqlens` | Tensor | [N+1] | int32 | 累积序列长度，默认为 None |
    | `chunk_indices` | Tensor | [total_chunks, 2] | int32 | Chunk 索引，默认为 None |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `dv` | Tensor | [B, T, H, V] | 同 `q` | dV 梯度 |

    Constraints:
    - `q.dtype == k.dtype == g.dtype`
    - 使用 `cu_seqlens` 时，B 必须为 1
    """
    ...


def prepare_wy_repr_bwd(
    k: Tensor,
    v: Tensor,
    beta: Tensor,
    A: Tensor,
    dw: Tensor,
    du: Tensor,
    chunk_size: int,
    g: Optional[Tensor] = None,
    cu_seqlens: Optional[Tensor] = None,
    chunk_indices: Optional[Tensor] = None
) -> Tuple[Tensor, Tensor, Tensor, Optional[Tensor]]:
    """
    WY 表示的反向传播

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `k` | Tensor | [B, T, H, K] | float16, bfloat16, float32 | Key 张量 |
    | `v` | Tensor | [B, T, H, V] | 同 `k` | Value 张量 |
    | `beta` | Tensor | [B, T, H] | 同 `k` | Beta 张量 |
    | `A` | Tensor | [B*NT, H, BT, BT] | 同 `k` | A 矩阵 |
    | `dw` | Tensor | [B, T, H, K] | 同 `k` | W 梯度 |
    | `du` | Tensor | [B, T, H, V] | 同 `k` | U 梯度 |
    | `chunk_size` | int | | | Chunk 大小 |
    | `g` | Tensor | [B, T, H] | 同 `k` | Gate 张量，默认为 None |
    | `cu_seqlens` | Tensor | [N+1] | int32 | 累积序列长度，默认为 None |
    | `chunk_indices` | Tensor | [total_chunks, 2] | int32 | Chunk 索引，默认为 None |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `dk` | Tensor | [B, T, H, K] | bfloat16 | Key 梯度 |
    | `dv` | Tensor | [B, T, H, V] | bfloat16 | Value 梯度 |
    | `dbeta` | Tensor | [B, T, H] | bfloat16 | Beta 梯度 |
    | `dg` | Tensor | [B, T, H] | bfloat16 | Gate 梯度，当 g 不为 None |

    Constraints:
    - `k.dtype == v.dtype == beta.dtype == dw.dtype == du.dtype`
    - H % Hg == 0 (H 能被 Hg 整除)
    - K <= 128 (受 SRAM 限制)
    - V <= 128 (受 SRAM 限制)
    - 使用 `cu_seqlens` 时，B 必须为 1
    """
    ...


def mha_varlen_fwd(
    q: Tensor,
    k: Tensor,
    v: Tensor,
    cu_seqlens_q: Tensor,
    cu_seqlens_k: Tensor,
    out_: Optional[Tensor],
    block_table: Tensor,
    task_metadata: Tensor,
    task_prefix_sum: Tensor,
    max_seqlen_q: int,
    max_seqlen_k: int,
    softmax_scale: float,
    is_causal: bool,
    return_softmax: bool
) -> List[Tensor]:
    """
    Flash Attention Varlen 前向传播

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `q` | Tensor | [total_q, num_heads, head_dim] | float16 | Query 张量 |
    | `k` | Tensor | [total_k, num_kv_heads, head_dim] | float16 | Key 张量 |
    | `v` | Tensor | [total_k, num_kv_heads, head_dim] | float16 | Value 张量 |
    | `cu_seqlens_q` | Tensor | [batch + 1] | int32 | Query 累积序列长度 |
    | `cu_seqlens_k` | Tensor | [batch + 1] | int32 | Key 累积序列长度 |
    | `out_` | Tensor | [total_q, num_heads, head_dim] | float16 | 输出张量（可选预分配） |
    | `block_table` | Tensor | | int32 | Block 表 |
    | `task_metadata` | Tensor | [N, 5] | int32 | 任务元数据 |
    | `task_prefix_sum` | Tensor | [core + 1] | int32 | 任务前缀和 |
    | `max_seqlen_q` | int | | | Query 最大序列长度 |
    | `max_seqlen_k` | int | | | Key 最大序列长度 |
    | `softmax_scale` | float | | | Softmax 缩放因子 |
    | `is_causal` | bool | | | 是否为因果注意力 |
    | `return_softmax` | bool | | | 是否返回 softmax 结果 |

    Returns:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `output` | Tensor | [total_q, num_heads, head_dim] | float16 | 注意力输出 |

    Constraints:
    - `q`、`k`、`v` 必须是 CUDA 张量且连续存储
    - `q.dtype == k.dtype == v.dtype == float16`
    - `q.dim() == k.dim() == v.dim() == 3`
    - 若提供 `out_`，必须是 float16 且 shape 与 q 相同
    """
    ...


def solve_tril_ns(
    Attn: Tensor,
    cu_seqlens: Tensor,
    chunk_indices: Tensor,
    chunk_size: int
) -> None:
    """
    原地求解下三角线性系统 (inplace solve lower triangular)

    对 Attn 张量进行原地下三角求解，用于 chunk-wise attention 的前向计算。

    Args:
    | name | type | shape | dtype | 备注 |
    | :--- | :--- | :--- | :--- | :--- |
    | `Attn` | Tensor | [B, T, H, chunk_size] | float16, float32 | 注意力矩阵，原地修改 |
    | `cu_seqlens` | Tensor | [N+1] | int32 | 累积序列长度 |
    | `chunk_indices` | Tensor | [total_chunks, 2] | int32 | Chunk 索引 |
    | `chunk_size` | int | | | Chunk 大小，必须为 64 |

    Returns:
        无返回值，原地修改 Attn。

    Constraints:
    - `chunk_size` 必须为 64
    - `Attn` 必须是 CUDA 张量且连续存储
    - `Attn.size(0)` 必须为 1 (varlen 模式)
    - `Attn.size(3)` 必须等于 chunk_size
    """
    ...
