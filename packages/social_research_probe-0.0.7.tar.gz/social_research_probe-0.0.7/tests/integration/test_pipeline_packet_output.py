import os
import subprocess
import sys


def test_run_research_emits_packet_envelope(tmp_path):
    env = {
        **os.environ,
        "SRP_DATA_DIR": str(tmp_path),
        "PYTHONPATH": "src",
        "SRP_TEST_USE_FAKE_YOUTUBE": "1",
    }
    subprocess.run(
        [
            sys.executable,
            "-m",
            "social_research_probe.cli",
            "update-purposes",
            "--add",
            '"trends"="Track emergence"',
        ],
        check=True,
        env=env,
    )
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "social_research_probe.cli",
            "research",
            "youtube",
            "ai agents",
            "trends",
        ],
        capture_output=True,
        text=True,
        env=env,
    )
    assert proc.returncode == 0, proc.stderr
    out = proc.stdout.strip()
    assert out.endswith(".html") or out.endswith(".md")
    # Stdout contract is the report file path; HTML/MD content is the source of truth.
    assert out.startswith("file://") or out.endswith(".md")
