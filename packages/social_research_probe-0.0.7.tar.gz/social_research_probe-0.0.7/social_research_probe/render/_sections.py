"""HTML section builders for the research report.

Each public function takes packet data and returns an HTML string fragment
for one numbered section. Mirrors the section structure in
synthesize/formatter.py but produces HTML instead of Markdown.
"""

from __future__ import annotations

import base64
import html
import re
from pathlib import Path

from social_research_probe.synthesize.formatter import (
    _contextual_explanation,
    _infer_model,
)
from social_research_probe.types import ResearchPacket, ScoredItem


def _esc(text: str) -> str:
    """HTML-escape a string for safe insertion into element content."""
    return html.escape(str(text), quote=False)


def section_1_topic_purpose(packet: ResearchPacket) -> str:
    """Section 1: Topic and purpose set."""
    purposes = _esc(", ".join(packet["purpose_set"]))
    return (
        "<ul>"
        f"<li><strong>Topic:</strong> {_esc(packet['topic'])}</li>"
        f"<li><strong>Purposes:</strong> {purposes}</li>"
        "</ul>"
    )


def section_2_platform(packet: ResearchPacket) -> str:
    """Section 2: Platform."""
    return f"<ul><li><strong>Platform:</strong> {_esc(packet['platform'])}</li></ul>"


def section_3_top_items(packet: ResearchPacket) -> str:
    """Section 3: Scored top-N items with table and per-item links."""
    items = packet.get("items_top_n", [])
    if not items:
        return "<p><em>(no items returned)</em></p>"
    return _items_score_table(items) + "\n" + _items_links(items)


def _items_score_table(items: list[ScoredItem]) -> str:
    """Render the score table for top items."""
    rows = [
        "<tr><th>#</th><th>Channel</th><th>Class</th><th>Trust</th>"
        "<th>Trend</th><th>Opp</th><th>Overall</th><th>Title</th></tr>"
    ]
    for i, it in enumerate(items, 1):
        sc = it.get("scores", {})
        rows.append(
            f"<tr><td>{i}</td><td>{_esc(it.get('channel', ''))}</td>"
            f"<td>{_esc(it.get('source_class', '?'))}</td>"
            f"<td>{sc.get('trust', 0):.2f}</td><td>{sc.get('trend', 0):.2f}</td>"
            f"<td>{sc.get('opportunity', 0):.2f}</td><td>{sc.get('overall', 0):.2f}</td>"
            f"<td>{_esc(it.get('title', ''))}</td></tr>"
        )
    return f'<div class="table-wrap"><table>{"".join(rows)}</table></div>'


def _items_links(items: list[ScoredItem]) -> str:
    """Render per-item URL + one-line takeaway as a bullet list."""
    lis = []
    for i, it in enumerate(items, 1):
        url = _esc(it.get("url", "#"))
        channel = _esc(it.get("channel", ""))
        takeaway = _esc(it.get("one_line_takeaway", ""))
        transcript = it.get("transcript", "")
        if transcript:
            extra = (
                "<details><summary>Transcript</summary>"
                f"<pre>{_esc(transcript[:3000])}{'...' if len(transcript) > 3000 else ''}</pre>"
                "</details>"
            )
        else:
            extra = ""
        description_notice = (
            '<p class="summary-notice"><em>Summary generated from the video\'s'
            " description — transcript unavailable.</em></p>"
            if it.get("summary_source") == "description"
            else ""
        )
        lis.append(
            f"<li><strong>[{i}]</strong> "
            f'<a href="{url}" rel="noopener noreferrer">{channel}</a>'
            f" — {takeaway}{description_notice}{extra}</li>"
        )
    return f"<ul>{''.join(lis)}</ul>"


def section_4_platform_signals(packet: ResearchPacket) -> str:
    """Section 4: Platform signals as bullet list."""
    return _bulletise(packet.get("platform_signals_summary", ""))


def section_5_source_validation(packet: ResearchPacket) -> str:
    """Section 5: Source validation counts."""
    svs = packet["source_validation_summary"]
    lines = [
        f"<li>Validated: {svs['validated']}, Partial: {svs['partially']}, "
        f"Unverified: {svs['unverified']}, Low-trust: {svs['low_trust']}</li>",
        f"<li>Primary / Secondary / Commentary: "
        f"{svs['primary']} / {svs['secondary']} / {svs['commentary']}</li>",
    ]
    if svs.get("notes"):
        lines.append(f"<li>Notes: {_esc(svs['notes'])}</li>")
    return f"<ul>{''.join(lines)}</ul>"


def section_6_evidence(packet: ResearchPacket) -> str:
    """Section 6: Evidence summary as bullet list."""
    return _bulletise(packet.get("evidence_summary", ""))


def section_7_statistics(packet: ResearchPacket) -> str:
    """Section 7: Statistics highlights table."""
    stats = packet.get("stats_summary", {})
    highlights = stats.get("highlights", [])
    low_confidence = stats.get("low_confidence", False)
    result = "<p><em>(no highlights)</em></p>" if not highlights else _highlights_table(highlights)
    if low_confidence:
        result += '<p><em style="color:#c0392b">Low confidence — interpret with caution.</em></p>'
    return result


def _highlights_table(highlights: list[str]) -> str:
    """Render statistics highlights as a four-column HTML table."""
    rows = ["<tr><th>Model</th><th>Metric</th><th>Finding</th><th>What it means</th></tr>"]
    prev_model = None
    for h in highlights:
        if " — " in h:
            metric, finding = h.split(" — ", 1)
        else:
            metric, finding = h, ""
        model = _infer_model(metric)
        explanation = _contextual_explanation(metric, finding)
        model_cell = model if model != prev_model else ""
        prev_model = model
        rows.append(
            "<tr>"
            f"<td>{_esc(model_cell)}</td>"
            f"<td>{_esc(metric)}</td>"
            f"<td>{_esc(finding)}</td>"
            f"<td>{_esc(explanation)}</td>"
            "</tr>"
        )
    return f'<div class="table-wrap"><table>{"".join(rows)}</table></div>'


def section_8_charts(packet: ResearchPacket, charts_dir: Path | None) -> str:
    """Section 8: Embedded chart images and captions."""
    captions = packet.get("chart_captions", [])
    if not captions:
        return "<p><em>(no charts rendered)</em></p>"
    blocks = []
    for cap in captions:
        blocks.append(_chart_block(cap, charts_dir))
    return "\n".join(blocks)


def _chart_block(caption: str, charts_dir: Path | None) -> str:
    """Render one chart: embedded image (if available) plus caption text."""
    png_path = _find_chart_path(caption, charts_dir)
    img_tag = ""
    if png_path:
        try:
            b64 = base64.b64encode(Path(png_path).read_bytes()).decode()
            img_tag = f'<img src="data:image/png;base64,{b64}" alt="" loading="lazy">'
        except OSError:
            pass

    # Strip the _(see PNG: ...)_ annotation from caption before display
    display_cap = re.sub(r"_\(see PNG:[^)]+\)_", "", caption).strip()
    # Split on first newline: first line is title, rest may be ASCII art
    parts = display_cap.split("\n", 1)
    title_html = _esc(parts[0])
    ascii_html = (
        f'<pre class="chart-ascii" aria-hidden="true">{_esc(parts[1])}</pre>'
        if len(parts) > 1 and parts[1].strip()
        else ""
    )
    return (
        '<div class="chart-block">'
        + img_tag
        + f'<p class="chart-caption">{title_html}</p>'
        + ascii_html
        + "</div>"
    )


def _find_chart_path(caption: str, charts_dir: Path | None) -> str | None:
    """Extract the PNG file path referenced in a chart caption, if available."""
    if charts_dir is None:
        return None
    # Most chart types embed path as _(see PNG: /absolute/path.png)_
    m = re.search(r"\(see PNG:\s*([^\)]+)\)", caption)
    if m:
        p = Path(m.group(1).strip())
        return str(p) if p.exists() else None
    # Bar chart embeds "Bar chart: <label> (N items)" — path is derivable
    m = re.match(r"Bar chart:\s+(\S+)\s*\(", caption)
    if m:
        slug = m.group(1).replace(" ", "_")
        p = charts_dir / f"{slug}_bar.png"
        return str(p) if p.exists() else None
    return None


def section_9_warnings(packet: ResearchPacket) -> str:
    """Section 9: Research warnings."""
    warnings = packet.get("warnings", [])
    if not warnings:
        return "<p><em>(none)</em></p>"
    lis = "".join(f"<li>{_esc(w)}</li>" for w in warnings)
    return f'<ul class="warning-list">{lis}</ul>'


def section_10_synthesis(text: str | None) -> str:
    """Section 10: Compiled synthesis (LLM-generated or placeholder)."""
    if not text:
        return "<p><em>(LLM synthesis unavailable — runner disabled or all runners failed; see terminal logs)</em></p>"
    from social_research_probe.render.markdown_to_html import md_to_html

    return md_to_html(text)


def section_11_opportunity(text: str | None) -> str:
    """Section 11: Opportunity analysis (LLM-generated or placeholder)."""
    if not text:
        return "<p><em>(LLM synthesis unavailable — runner disabled or all runners failed; see terminal logs)</em></p>"
    from social_research_probe.render.markdown_to_html import md_to_html

    return md_to_html(text)


def _bulletise(text: str) -> str:
    """Convert a semicolon-separated summary string to an HTML bullet list."""
    parts = [p.strip() for p in text.split(";") if p.strip()]
    if not parts:
        return "<p><em>(no data)</em></p>"
    lis = "".join(f"<li>{_esc(p)}</li>" for p in parts)
    return f"<ul>{lis}</ul>"
