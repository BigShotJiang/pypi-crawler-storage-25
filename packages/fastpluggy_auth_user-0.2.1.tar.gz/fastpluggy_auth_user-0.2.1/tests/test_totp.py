"""Tests for TOTP two-factor authentication.

Covers backup code generation, TOTP verify, backup code single-use consumption,
and the login flow redirect when 2FA is enabled.
"""

import hashlib
import re

import pyotp
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from fastpluggy.core.database import Base
from fastpluggy_plugin.auth_user.models import (
    FastPluggyBaseUser,
    TwoFactorSecret,
    Session as AuthSession,
)
from fastpluggy_plugin.auth_user.auth.basic_auth import BasicAuthManager
from fastpluggy_plugin.auth_user.routers.totp import _generate_backup_codes
from fastpluggy_plugin.auth_user.routers.login import _verify_totp_or_backup
from fastpluggy_plugin.auth_user.repository import create_or_update_session


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db():
    """Yield a fresh SQLAlchemy session backed by an in-memory SQLite DB."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    yield session
    session.close()
    engine.dispose()


@pytest.fixture()
def user_alice(db):
    """Create user 'alice' with a known password."""
    u = FastPluggyBaseUser(
        username="alice",
        hashed_password=BasicAuthManager.hash_password("password123"),
        is_admin=False,
    )
    db.add(u)
    db.commit()
    db.refresh(u)
    return u


@pytest.fixture()
def totp_secret():
    """Return a deterministic TOTP secret for testing."""
    return pyotp.random_base32()


@pytest.fixture()
def totp_record(db, user_alice, totp_secret):
    """Create and return an enabled TwoFactorSecret for alice."""
    record = TwoFactorSecret(
        user_id=user_alice.id,
        secret=totp_secret,
        enabled=True,
        backup_codes=[],
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


# ---------------------------------------------------------------------------
# Test 1: Backup code generation
# ---------------------------------------------------------------------------

class TestBackupCodeGeneration:
    """Verify _generate_backup_codes produces correct format and hashes."""

    def test_generates_ten_codes(self):
        plain, hashed = _generate_backup_codes()
        assert len(plain) == 10
        assert len(hashed) == 10

    def test_custom_count(self):
        plain, hashed = _generate_backup_codes(n=5)
        assert len(plain) == 5
        assert len(hashed) == 5

    def test_format_xxxx_xxxx_uppercase_hex(self):
        plain, _ = _generate_backup_codes()
        pattern = re.compile(r"^[0-9A-F]{8}-[0-9A-F]{8}$")
        for code in plain:
            assert pattern.match(code), f"Code {code!r} does not match XXXX-XXXX hex format"

    def test_hashes_are_sha256_of_plaintext(self):
        plain, hashed = _generate_backup_codes()
        for code, h in zip(plain, hashed):
            expected = hashlib.sha256(code.encode()).hexdigest()
            assert h == expected

    def test_codes_are_unique(self):
        plain, hashed = _generate_backup_codes()
        assert len(set(plain)) == len(plain)
        assert len(set(hashed)) == len(hashed)


# ---------------------------------------------------------------------------
# Test 2: Verify valid TOTP code
# ---------------------------------------------------------------------------

class TestVerifyTotpValid:
    """A valid TOTP code generated with the same secret must pass."""

    def test_valid_code_passes(self, db, totp_record, totp_secret):
        totp = pyotp.TOTP(totp_secret)
        code = totp.now()
        assert _verify_totp_or_backup(totp_record, code, db) is True


# ---------------------------------------------------------------------------
# Test 3: Verify invalid TOTP code
# ---------------------------------------------------------------------------

class TestVerifyTotpInvalid:
    """A wrong TOTP code must fail."""

    def test_wrong_code_fails(self, db, totp_record):
        assert _verify_totp_or_backup(totp_record, "000000", db) is False

    def test_empty_code_fails(self, db, totp_record):
        assert _verify_totp_or_backup(totp_record, "", db) is False

    def test_garbage_code_fails(self, db, totp_record):
        assert _verify_totp_or_backup(totp_record, "not-a-code", db) is False


# ---------------------------------------------------------------------------
# Test 4: Backup code is single-use
# ---------------------------------------------------------------------------

class TestBackupCodeSingleUse:
    """A backup code works once, then is consumed and cannot be reused."""

    def test_backup_code_works_then_consumed(self, db, totp_record):
        plain, hashed = _generate_backup_codes(n=3)
        totp_record.backup_codes = hashed
        db.commit()

        # The backup code stored is sha256(plain.encode()), but _verify_totp_or_backup
        # hashes code.upper().encode(). Since plain codes are already uppercase, this matches.
        target_code = plain[0]

        # First use succeeds
        assert _verify_totp_or_backup(totp_record, target_code, db) is True
        # Code list shrinks by one
        assert len(totp_record.backup_codes) == 2

        # Second use of same code fails
        assert _verify_totp_or_backup(totp_record, target_code, db) is False
        # No further codes consumed
        assert len(totp_record.backup_codes) == 2

    def test_backup_code_case_insensitive(self, db, totp_record):
        """Backup codes work regardless of case (login helper uppercases)."""
        plain, hashed = _generate_backup_codes(n=1)
        totp_record.backup_codes = hashed
        db.commit()

        # Use lowercase version — _verify_totp_or_backup uppercases before hashing
        assert _verify_totp_or_backup(totp_record, plain[0].lower(), db) is True
        assert len(totp_record.backup_codes) == 0

    def test_other_backup_codes_still_work(self, db, totp_record):
        """Using one backup code does not invalidate the others."""
        plain, hashed = _generate_backup_codes(n=3)
        totp_record.backup_codes = hashed
        db.commit()

        # Use first code
        assert _verify_totp_or_backup(totp_record, plain[0], db) is True
        # Second code still works
        assert _verify_totp_or_backup(totp_record, plain[1], db) is True
        assert len(totp_record.backup_codes) == 1


# ---------------------------------------------------------------------------
# Test 5: Login flow with 2FA creates pending session and redirects
# ---------------------------------------------------------------------------

class TestLoginFlowWith2FA:
    """POST /login for a user with TOTP enabled should create a pending
    session (not a real one) and redirect to /login/2fa."""

    def test_login_creates_pending_session_and_redirects(self, db, user_alice, totp_record):
        """Simulate the login_post logic: valid credentials + TOTP enabled
        should produce a pending 2FA session, not a real login session."""
        import uuid

        # Verify credentials are valid (same check as login_post)
        assert BasicAuthManager.verify_password("password123", user_alice.hashed_password)

        # Verify user has TOTP enabled (same query as login_post)
        record = (
            db.query(TwoFactorSecret)
            .filter_by(user_id=user_alice.id, enabled=True)
            .first()
        )
        assert record is not None, "TOTP should be enabled for alice"

        # Simulate what login_post does when TOTP is present:
        # create a pending 2FA session instead of a real one
        pending_id = str(uuid.uuid4())
        pending_data = {
            "pending_2fa_user_id": user_alice.id,
            "next": "/",
            "remember": False,
            "attempts": 0,
        }
        create_or_update_session(db, pending_id, pending_data, 300)

        # Verify the pending session was created correctly
        pending = db.query(AuthSession).filter_by(session_id=pending_id).first()
        assert pending is not None
        assert pending.session_data["pending_2fa_user_id"] == user_alice.id
        assert pending.session_data["attempts"] == 0

        # Verify NO real session exists (user_id key, not pending_2fa_user_id)
        all_sessions = db.query(AuthSession).all()
        real_sessions = [
            s for s in all_sessions
            if "user_id" in s.session_data and "pending_2fa_user_id" not in s.session_data
        ]
        assert len(real_sessions) == 0, "No real session should exist before 2FA verification"

    def test_login_without_2fa_creates_real_session(self, db, user_alice):
        """For a user without TOTP, login should create a real session directly."""
        import uuid

        # Verify no TOTP record
        record = (
            db.query(TwoFactorSecret)
            .filter_by(user_id=user_alice.id, enabled=True)
            .first()
        )
        assert record is None

        # Simulate normal login (no 2FA) — creates real session
        session_id = str(uuid.uuid4())
        create_or_update_session(db, session_id, {"user_id": user_alice.id}, 3600)

        sess = db.query(AuthSession).filter_by(session_id=session_id).first()
        assert sess is not None
        assert sess.session_data["user_id"] == user_alice.id
        assert "pending_2fa_user_id" not in sess.session_data
