# test_auth.py — basic import/smoke tests for auth_user
#
# Full endpoint testing (login, admin, etc.) is covered by the e2e suite
# in e2e/auth-test.mjs which runs against a live FastPluggy instance.



def test_plugin_importable():
    """Plugin module and key submodules can be imported."""
    from fastpluggy_plugin.auth_user.plugin import AuthUserPlugin
    from fastpluggy_plugin.auth_user.auth.session_auth import SessionAuthManager
    from fastpluggy_plugin.auth_user.auth.basic_auth import BasicAuthManager
    from fastpluggy_plugin.auth_user.models import FastPluggyBaseUser

    assert AuthUserPlugin is not None
    assert SessionAuthManager is not None
    assert BasicAuthManager is not None
    assert FastPluggyBaseUser is not None


def test_session_auth_manager_instantiation():
    """SessionAuthManager can be created without side effects."""
    from fastpluggy_plugin.auth_user.auth.session_auth import SessionAuthManager

    manager = SessionAuthManager()
    assert manager is not None
