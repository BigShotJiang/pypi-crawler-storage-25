"""Tests for session invalidation on password change (Phase 3).

Uses an in-memory SQLite database with the real Session / User models
so we test actual SQL behaviour, not mocks.
"""

from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from fastpluggy.core.database import Base
from fastpluggy_plugin.auth_user.models import FastPluggyBaseUser, Session as AuthSession
from fastpluggy_plugin.auth_user.auth.basic_auth import BasicAuthManager
from fastpluggy_plugin.auth_user.repository import (
    delete_user_sessions,
    get_user_sessions,
    create_or_update_session,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db():
    """Yield a fresh SQLAlchemy session backed by an in-memory SQLite DB."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    yield session
    session.close()
    engine.dispose()


@pytest.fixture()
def user_alice(db):
    """Create user 'alice' (id will be auto-assigned)."""
    u = FastPluggyBaseUser(
        username="alice",
        hashed_password=BasicAuthManager.hash_password("password123"),
        is_admin=False,
    )
    db.add(u)
    db.commit()
    db.refresh(u)
    return u


@pytest.fixture()
def user_bob(db):
    """Create user 'bob'."""
    u = FastPluggyBaseUser(
        username="bob",
        hashed_password=BasicAuthManager.hash_password("bobpass"),
        is_admin=False,
    )
    db.add(u)
    db.commit()
    db.refresh(u)
    return u


def _make_session(db, session_id: str, user_id: int, lifetime_seconds: int = 3600):
    """Helper: insert a session row and return it."""
    return create_or_update_session(db, session_id, {"user_id": user_id}, lifetime_seconds)


# ---------------------------------------------------------------------------
# Test: password change invalidates other sessions, keeps current
# ---------------------------------------------------------------------------

class TestPasswordChangeInvalidation:
    """Simulates the profile password-change flow."""

    def test_keeps_current_session_deletes_others(self, db, user_alice):
        """After password change the current session survives; others are deleted."""
        current = _make_session(db, "sess-current", user_alice.id)
        other1 = _make_session(db, "sess-other-1", user_alice.id)
        other2 = _make_session(db, "sess-other-2", user_alice.id)

        # Simulate what profile_change_password does
        deleted = delete_user_sessions(db, user_alice.id, except_session_id="sess-current")

        assert deleted == 2
        remaining = get_user_sessions(db, user_alice.id)
        remaining_ids = [s.session_id for s in remaining]
        assert "sess-current" in remaining_ids
        assert "sess-other-1" not in remaining_ids
        assert "sess-other-2" not in remaining_ids

    def test_no_other_sessions(self, db, user_alice):
        """If only the current session exists, nothing is deleted."""
        _make_session(db, "only-sess", user_alice.id)
        deleted = delete_user_sessions(db, user_alice.id, except_session_id="only-sess")
        assert deleted == 0
        assert len(get_user_sessions(db, user_alice.id)) == 1


# ---------------------------------------------------------------------------
# Test: admin password reset invalidates ALL sessions
# ---------------------------------------------------------------------------

class TestAdminPasswordResetInvalidation:
    """Simulates the admin password-reset flow (no except_session_id)."""

    def test_all_sessions_deleted(self, db, user_alice):
        """Admin reset removes every session for the target user."""
        _make_session(db, "s1", user_alice.id)
        _make_session(db, "s2", user_alice.id)
        _make_session(db, "s3", user_alice.id)

        deleted = delete_user_sessions(db, user_alice.id)
        assert deleted == 3
        assert get_user_sessions(db, user_alice.id) == []

    def test_does_not_affect_other_users(self, db, user_alice, user_bob):
        """Admin reset for alice must not touch bob's sessions."""
        _make_session(db, "alice-s", user_alice.id)
        _make_session(db, "bob-s", user_bob.id)

        delete_user_sessions(db, user_alice.id)

        assert get_user_sessions(db, user_alice.id) == []
        bob_sessions = get_user_sessions(db, user_bob.id)
        assert len(bob_sessions) == 1
        assert bob_sessions[0].session_id == "bob-s"


# ---------------------------------------------------------------------------
# Test: delete_user_sessions with except_session_id
# ---------------------------------------------------------------------------

class TestDeleteUserSessionsExcept:
    """Focused tests on the except_session_id parameter."""

    def test_except_keeps_specified_session(self, db, user_alice):
        _make_session(db, "keep-me", user_alice.id)
        _make_session(db, "delete-me", user_alice.id)

        deleted = delete_user_sessions(db, user_alice.id, except_session_id="keep-me")
        assert deleted == 1
        remaining = get_user_sessions(db, user_alice.id)
        assert len(remaining) == 1
        assert remaining[0].session_id == "keep-me"

    def test_except_with_nonexistent_id(self, db, user_alice):
        """If except_session_id doesn't match any session, all are deleted."""
        _make_session(db, "s1", user_alice.id)
        _make_session(db, "s2", user_alice.id)

        deleted = delete_user_sessions(db, user_alice.id, except_session_id="nonexistent")
        assert deleted == 2
        assert get_user_sessions(db, user_alice.id) == []

    def test_except_none_deletes_all(self, db, user_alice):
        """except_session_id=None means delete everything."""
        _make_session(db, "a", user_alice.id)
        _make_session(db, "b", user_alice.id)

        deleted = delete_user_sessions(db, user_alice.id, except_session_id=None)
        assert deleted == 2

    def test_returns_zero_when_no_sessions(self, db, user_alice):
        """No sessions exist → returns 0, no error."""
        assert delete_user_sessions(db, user_alice.id) == 0


# ---------------------------------------------------------------------------
# Test: sessions list returns only current user's sessions
# ---------------------------------------------------------------------------

class TestGetUserSessions:
    """Tests for get_user_sessions (used by the sessions list endpoint)."""

    def test_returns_only_own_sessions(self, db, user_alice, user_bob):
        _make_session(db, "alice-1", user_alice.id)
        _make_session(db, "alice-2", user_alice.id)
        _make_session(db, "bob-1", user_bob.id)

        alice_sessions = get_user_sessions(db, user_alice.id)
        assert len(alice_sessions) == 2
        assert all(s.session_data["user_id"] == user_alice.id for s in alice_sessions)

    def test_excludes_expired_sessions(self, db, user_alice):
        """Expired sessions must not appear in the list."""
        _make_session(db, "active", user_alice.id, lifetime_seconds=3600)
        # Create an expired session by manipulating the lifetime directly
        expired = _make_session(db, "expired", user_alice.id, lifetime_seconds=1)
        expired.session_lifetime = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=1)
        db.commit()

        sessions = get_user_sessions(db, user_alice.id)
        assert len(sessions) == 1
        assert sessions[0].session_id == "active"

    def test_empty_when_no_sessions(self, db, user_alice):
        assert get_user_sessions(db, user_alice.id) == []


# ---------------------------------------------------------------------------
# Test: revoke endpoint deletes the target session
# ---------------------------------------------------------------------------

class TestRevokeSession:
    """Tests the revoke logic (delete a specific session by DB id)."""

    def test_revoke_deletes_target(self, db, user_alice):
        """Revoking a session removes it from the DB."""
        s1 = _make_session(db, "keep", user_alice.id)
        s2 = _make_session(db, "revoke-me", user_alice.id)

        # Simulate what revoke_session endpoint does
        target = db.query(AuthSession).filter(AuthSession.id == s2.id).first()
        assert target is not None
        assert target.session_data.get("user_id") == user_alice.id

        db.delete(target)
        db.commit()

        remaining = get_user_sessions(db, user_alice.id)
        assert len(remaining) == 1
        assert remaining[0].session_id == "keep"

    def test_cannot_revoke_other_users_session(self, db, user_alice, user_bob):
        """A user must not be able to revoke another user's session."""
        bob_sess = _make_session(db, "bob-sess", user_bob.id)

        # Simulate the endpoint guard: check user_id matches
        target = db.query(AuthSession).filter(AuthSession.id == bob_sess.id).first()
        assert target.session_data.get("user_id") != user_alice.id  # guard rejects

    def test_revoke_nonexistent_returns_none(self, db):
        """Querying a non-existent session ID returns None."""
        target = db.query(AuthSession).filter(AuthSession.id == 9999).first()
        assert target is None
