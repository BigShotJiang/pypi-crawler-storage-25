"""Tests for LoginRateLimiter — sliding window rate limiting + lockout."""

from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from src.rate_limiter import LoginRateLimiter


class TestPerUserLimit:
    def test_sixth_attempt_blocked_after_five_fast_failures(self):
        limiter = LoginRateLimiter(per_user=5, per_ip=100, window=60)
        ip = "10.0.0.1"

        for i in range(5):
            result = limiter.check_rate_limit("alice", ip)
            assert result.allowed, f"Attempt {i + 1} should be allowed"
            limiter.record_attempt("alice", ip, success=False)

        result = limiter.check_rate_limit("alice", ip)
        assert not result.allowed
        assert "account" in result.reason.lower()


class TestPerIPLimit:
    def test_21st_attempt_blocked_after_20_from_same_ip(self):
        limiter = LoginRateLimiter(per_user=100, per_ip=20, window=60)
        ip = "192.168.1.1"

        for i in range(20):
            username = f"user{i}"
            result = limiter.check_rate_limit(username, ip)
            assert result.allowed, f"Attempt {i + 1} should be allowed"
            limiter.record_attempt(username, ip, success=False)

        result = limiter.check_rate_limit("user_final", ip)
        assert not result.allowed
        assert "ip" in result.reason.lower()


class TestWindowExpiry:
    def test_attempts_expire_after_window(self):
        limiter = LoginRateLimiter(per_user=5, per_ip=100, window=60)
        ip = "10.0.0.1"
        base_time = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        with patch("src.rate_limiter.datetime") as mock_dt:
            mock_dt.now.return_value = base_time
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)

            for _ in range(5):
                limiter.check_rate_limit("alice", ip)
                limiter.record_attempt("alice", ip, success=False)

            result = limiter.check_rate_limit("alice", ip)
            assert not result.allowed

            # Advance 61 seconds past the window
            mock_dt.now.return_value = base_time + timedelta(seconds=61)

            result = limiter.check_rate_limit("alice", ip)
            assert result.allowed


class TestSuccessResetsCounter:
    def test_success_clears_user_attempts(self):
        limiter = LoginRateLimiter(per_user=5, per_ip=100, window=60)
        ip = "10.0.0.1"

        # 4 failed attempts
        for _ in range(4):
            limiter.check_rate_limit("bob", ip)
            limiter.record_attempt("bob", ip, success=False)

        # Successful login resets counter
        limiter.record_attempt("bob", ip, success=True)

        # 5 more failed attempts should all be allowed (counter was reset)
        for i in range(5):
            result = limiter.check_rate_limit("bob", ip)
            assert result.allowed, f"Attempt {i + 1} after reset should be allowed"
            limiter.record_attempt("bob", ip, success=False)


class TestLockoutAfterThreshold:
    def test_is_locked_after_threshold_failures(self):
        limiter = LoginRateLimiter(per_user=100, per_ip=100, window=60,
                                   lockout_threshold=3)
        ip = "10.0.0.1"

        for _ in range(3):
            limiter.record_attempt("charlie", ip, success=False)

        assert limiter.is_locked("charlie")


class TestAutoUnlockAfterDuration:
    def test_lockout_expires_after_duration(self):
        limiter = LoginRateLimiter(per_user=100, per_ip=100, window=60,
                                   lockout_threshold=3, lockout_duration=10)
        ip = "10.0.0.1"
        base_time = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)

        with patch("src.rate_limiter.datetime") as mock_dt:
            mock_dt.now.return_value = base_time
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)

            for _ in range(3):
                limiter.record_attempt("dave", ip, success=False)

            assert limiter.is_locked("dave")

            # Advance 11 seconds past lockout duration
            mock_dt.now.return_value = base_time + timedelta(seconds=11)

            assert not limiter.is_locked("dave")


class TestAdminUnlock:
    def test_unlock_clears_lockout_and_allows_attempts(self):
        limiter = LoginRateLimiter(per_user=100, per_ip=100, window=60,
                                   lockout_threshold=3, lockout_duration=0)
        ip = "10.0.0.1"

        for _ in range(3):
            limiter.record_attempt("eve", ip, success=False)

        assert limiter.is_locked("eve")

        limiter.unlock("eve")

        assert not limiter.is_locked("eve")
        result = limiter.check_rate_limit("eve", ip)
        assert result.allowed


class TestGetRemaining:
    def test_fresh_state_returns_full_limit(self):
        limiter = LoginRateLimiter(per_user=5, per_ip=20, window=60)
        remaining = limiter.get_remaining("frank", "10.0.0.1")
        assert remaining["user_remaining"] == 5
        assert remaining["ip_remaining"] == 20
        assert remaining["remaining"] == 5

    def test_remaining_decreases_after_attempts(self):
        limiter = LoginRateLimiter(per_user=5, per_ip=20, window=60)
        ip = "10.0.0.1"

        for _ in range(3):
            limiter.record_attempt("frank", ip, success=False)

        remaining = limiter.get_remaining("frank", ip)
        assert remaining["user_remaining"] == 2
        assert remaining["ip_remaining"] == 17
        assert remaining["remaining"] == 2
