# test_register.py — registration route tests
#
# Tests the self-registration feature: disabled by default (redirects),
# enabled flow (creates user, duplicate blocked, password mismatch).


def test_register_imports():
    """Registration router and form can be imported."""
    from fastpluggy_plugin.auth_user.routers.register import (
        register_router,
        RegistrationForm,
        _registration_allowed,
    )
    assert register_router is not None
    assert RegistrationForm is not None
    assert _registration_allowed is not None


def test_registration_form_valid():
    """RegistrationForm validates matching passwords."""
    from fastpluggy_plugin.auth_user.routers.register import RegistrationForm

    form = RegistrationForm(data={
        "username": "testuser",
        "password": "secret123",
        "confirm_password": "secret123",
    })
    assert form.validate(), f"Expected valid form, got errors: {form.errors}"


def test_registration_form_password_mismatch():
    """RegistrationForm rejects mismatched passwords."""
    from fastpluggy_plugin.auth_user.routers.register import RegistrationForm

    form = RegistrationForm(data={
        "username": "testuser",
        "password": "secret123",
        "confirm_password": "different",
    })
    assert not form.validate()
    assert "confirm_password" in form.errors


def test_registration_form_short_username():
    """RegistrationForm rejects usernames shorter than 3 chars."""
    from fastpluggy_plugin.auth_user.routers.register import RegistrationForm

    form = RegistrationForm(data={
        "username": "ab",
        "password": "secret123",
        "confirm_password": "secret123",
    })
    assert not form.validate()
    assert "username" in form.errors


def test_registration_form_short_password():
    """RegistrationForm rejects passwords shorter than 6 chars."""
    from fastpluggy_plugin.auth_user.routers.register import RegistrationForm

    form = RegistrationForm(data={
        "username": "testuser",
        "password": "short",
        "confirm_password": "short",
    })
    assert not form.validate()
    assert "password" in form.errors


def test_create_user_importable():
    """create_user function can be imported from repository."""
    from fastpluggy_plugin.auth_user.repository import create_user
    assert create_user is not None


def test_config_has_allow_self_registration():
    """AuthUserConfig has the allow_self_registration field, defaulting to False."""
    from fastpluggy_plugin.auth_user.config import AuthUserConfig
    config = AuthUserConfig()
    assert hasattr(config, "allow_self_registration")
    assert config.allow_self_registration is False
