"""Tests for the auth_user CLI commands (``fp auth-user …``)."""

from unittest.mock import MagicMock, patch

import click
from click.testing import CliRunner

from fastpluggy_plugin.auth_user.cli import auth_user_group


def _make_fake_user(**kwargs):
    """Return a lightweight mock that looks like FastPluggyBaseUser."""
    user = MagicMock()
    for k, v in kwargs.items():
        setattr(user, k, v)
    return user


class TestCreateUser:
    """Tests for ``auth-user create-user``."""

    @patch("fastpluggy_plugin.auth_user.cli.with_db_session")
    def test_creates_user_successfully(self, mock_decorator):
        """Happy path: user does not exist → created."""
        # Make the decorator pass-through but capture the inner function
        captured = {}

        def passthrough(fn):
            captured["fn"] = fn
            def wrapper(*a, **kw):
                db = MagicMock()
                query = MagicMock()
                query.filter.return_value.first.return_value = None  # no existing user
                db.query.return_value = query
                return fn(*a, db=db, **kw)
            return wrapper

        mock_decorator.side_effect = passthrough

        runner = CliRunner()
        result = runner.invoke(
            auth_user_group,
            ["create-user", "--username", "alice", "--email", "a@b.com", "--password", "secret", "--admin"],
            input="secret\n",  # confirmation prompt
        )
        assert result.exit_code == 0, result.output
        assert "alice" in result.output
        assert "created successfully" in result.output

    @patch("fastpluggy_plugin.auth_user.cli.with_db_session")
    def test_duplicate_user_fails(self, mock_decorator):
        """Existing username → ClickException."""
        def passthrough(fn):
            def wrapper(*a, **kw):
                db = MagicMock()
                query = MagicMock()
                query.filter.return_value.first.return_value = _make_fake_user(username="alice")
                db.query.return_value = query
                return fn(*a, db=db, **kw)
            return wrapper

        mock_decorator.side_effect = passthrough

        runner = CliRunner()
        result = runner.invoke(
            auth_user_group,
            ["create-user", "--username", "alice", "--email", "", "--password", "secret"],
            input="secret\n",
        )
        assert result.exit_code != 0
        assert "already exists" in result.output


class TestGroupStructure:
    """Verify the CLI group shape expected by the discovery mechanism."""

    def test_auth_user_group_is_click_group(self):
        assert isinstance(auth_user_group, click.Group)

    def test_group_name(self):
        assert auth_user_group.name == "auth-user"

    def test_create_user_is_registered(self):
        assert "create-user" in auth_user_group.commands
