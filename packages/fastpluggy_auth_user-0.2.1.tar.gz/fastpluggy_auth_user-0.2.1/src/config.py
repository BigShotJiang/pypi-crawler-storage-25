from fastpluggy.core.config import BaseDatabaseSettings
from typing import Optional, Literal


class AuthUserConfig(BaseDatabaseSettings):
    # Set to None to enable UI-based setup on first install
    # If None, admin user creation will be handled via setup UI
    default_admin_username: Optional[str] = None
    default_admin_password: Optional[str] = None

    # Auth backend: "session" (cookies + tokens + login redirect) or "basic" (HTTP Basic popup)
    auth_backend: Literal["session", "basic"] = "session"

    login_template: str = 'auth_user/login.html'

    collect_login_ip: bool = True
    allow_api_tokens: bool = True
    allow_self_registration: bool = False

    # Session lifetimes (seconds)
    session_lifetime: int = 3600              # 1 hour
    session_lifetime_remember: int = 2592000  # 30 days (Remember Me)

    # TOTP 2FA
    allow_totp: bool = True
    require_totp: bool = False
    totp_pending_lifetime: int = 300          # 5 minutes for 2FA code entry
    totp_max_attempts: int = 5                # max failed 2FA attempts per pending session

    # Login rate limiting
    login_rate_limit_per_user: int = 5       # max attempts per username per window
    login_rate_limit_per_ip: int = 20        # max attempts per IP per window
    login_rate_limit_window: int = 60        # window size in seconds
    login_lockout_threshold: int = 15        # total failed attempts before account lockout
    login_lockout_duration: int = 900        # lockout duration in seconds (0 = manual unlock only)

