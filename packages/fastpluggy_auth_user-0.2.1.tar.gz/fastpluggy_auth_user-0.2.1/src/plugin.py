from typing import Annotated, Any

from fastpluggy.core.database import session_scope
from fastpluggy.core.events import EventSpec
from fastpluggy.core.menu.schema import MenuItem
from fastpluggy.core.module_base import FastPluggyBaseModule
from fastpluggy.core.tools.inspect_tools import InjectDependency
from fastpluggy.fastpluggy import FastPluggy
from .config import AuthUserConfig


def get_auth_router():
    from .routers import router
    return router

class AuthUserPlugin(FastPluggyBaseModule):
    module_name: str = "auth_user"
    module_settings: Any = AuthUserConfig
    module_mount_url: str = ""
    module_menu_name: str = "User Auth"
    module_menu_icon: str = "fa fa-user"
    module_menu_type: str = "no"
    module_router: Any = get_auth_router
    capabilities: list = ["authentication"]

    emits: list = [
        EventSpec(
            name="user.login",
            description="Emitted after successful credential validation and session creation.",
            payload={"user_id": "int", "username": "str", "ip": "str", "remember": "bool"},
        ),
        EventSpec(
            name="user.logout",
            description="Emitted when an authenticated user's session is terminated.",
            payload={"user_id": "int", "username": "str"},
        ),
        EventSpec(
            name="user.password_changed",
            description="Emitted after a user's password is changed (by self or admin).",
            payload={"user_id": "int", "username": "str", "changed_by": "str"},
        ),
        EventSpec(
            name="user.totp_enabled",
            description="Emitted when a user enables TOTP two-factor authentication.",
            payload={"user_id": "int", "username": "str"},
        ),
        EventSpec(
            name="user.totp_disabled",
            description="Emitted when TOTP 2FA is disabled (by user or admin).",
            payload={"user_id": "int", "username": "str"},
        ),
        EventSpec(
            name="user.locked_out",
            description="Emitted when an account is locked due to repeated failed login attempts.",
            payload={"username": "str", "ip": "str"},
        ),
        EventSpec(
            name="user.unlocked",
            description="Emitted when a locked account is unlocked by an admin.",
            payload={"username": "str", "unlocked_by": "str"},
        ),
    ]

    def on_load_complete(self, fast_pluggy: Annotated["FastPluggy", InjectDependency]) -> None:
        from fastpluggy.core.database import create_table_if_not_exist
        from .models import (
            FastPluggyBaseUser, Session as AuthSession, Token, TwoFactorSecret,
            LoginAttempt, AccountLockout,
        )

        self._perform_sqlite_migrations()
        create_table_if_not_exist(model=FastPluggyBaseUser)
        create_table_if_not_exist(model=AuthSession)
        create_table_if_not_exist(model=Token)
        create_table_if_not_exist(model=TwoFactorSecret)
        create_table_if_not_exist(model=LoginAttempt)
        create_table_if_not_exist(model=AccountLockout)

        # Restore active lockouts from DB into in-memory rate limiter
        self._restore_lockouts()

        from fastpluggy.core.global_registry import GlobalRegistry
        GlobalRegistry.register_capability("authentication", self)

        # Auto-wire auth manager if not already set
        if not fast_pluggy.auth_manager:
            config = AuthUserConfig()
            if config.auth_backend == "basic":
                from .auth.basic_auth import BasicAuthManager
                fast_pluggy.set_auth_manager(BasicAuthManager())
            else:
                from .auth.session_auth import SessionAuthManager
                fast_pluggy.set_auth_manager(SessionAuthManager())

        fast_pluggy.menu_manager.add_menu_item(
            menu_type='user',
            item=MenuItem(url='/profile/', label="Profile", icon="fa-solid fa-user")
        )
        fast_pluggy.menu_manager.add_menu_item(
            menu_type='user',
            item=MenuItem(url='/profile/tokens/', label="API Tokens", icon="ti ti-key")
        )
        fast_pluggy.menu_manager.add_menu_item(
            menu_type='user',
            item=MenuItem(url='/profile/sessions/', label="Active Sessions", icon="ti ti-devices")
        )
        fast_pluggy.menu_manager.add_menu_item(
            menu_type='user',
            item=MenuItem(url='/logout', label="Logout", icon="fa-solid fa-sign-out-alt")
        )

        # Initialize admin user if needed
        self._initialize_admin_user_if_needed()

        # Add login page to the auth_user module
        #from fastpluggy.core.auth import get_auth_manager
        #auth_manager = get_auth_manager()
        #if hasattr(auth_manager, 'login_url'):
        #    auth_manager.login_url = "/login"

    def _perform_sqlite_migrations(self) -> None:
        """Execute SQLite-specific migrations if applicable."""
        # todo: add test to check is working with pg and sqlite
        from fastpluggy.core.database import get_engine
        engine = get_engine()
        if engine.dialect.name == 'sqlite':
            self._migrate_sessions_table()
            self._migrate_users_table()

    def _migrate_users_table(self) -> None:
        """Add last_login_at and last_login_ip columns if they don't exist."""
        try:
            from fastpluggy.core.database import get_engine
            from loguru import logger
            import sqlalchemy as sa

            engine = get_engine()
            with engine.connect() as conn:
                result = conn.execute(sa.text(
                    "SELECT sql FROM sqlite_master WHERE type='table' AND name='users'"
                )).fetchone()
                if result:
                    table_sql = result[0]
                    added = False
                    for col_name, col_type in [
                        ("last_login_at", "TIMESTAMP"),
                        ("last_login_ip", "VARCHAR(45)"),
                    ]:
                        if col_name not in table_sql:
                            conn.execute(sa.text(
                                f"ALTER TABLE users ADD COLUMN {col_name} {col_type}"
                            ))
                            logger.info(f"users table: added column '{col_name}'.")
                            added = True
                    if added:
                        conn.commit()
        except Exception as e:
            from loguru import logger
            logger.warning(f"users table migration check skipped: {e}")

    def _migrate_sessions_table(self) -> None:
        """Drop the sessions table if it was created with the old composite PK
        (session_id + id). create_table_if_not_exist will recreate it correctly."""
        try:
            from fastpluggy.core.database import get_engine
            from loguru import logger
            import sqlalchemy as sa

            engine = get_engine()
            with engine.connect() as conn:
                result = conn.execute(sa.text(
                    "SELECT sql FROM sqlite_master WHERE type='table' AND name='sessions'"
                )).fetchone()
                if result and "PRIMARY KEY (session_id" in result[0]:
                    logger.warning(
                        "sessions table has stale composite PK — dropping and recreating."
                    )
                    conn.execute(sa.text("DROP TABLE sessions"))
                    conn.commit()
        except Exception as e:
            from loguru import logger
            logger.warning(f"sessions migration check skipped: {e}")

    def _restore_lockouts(self) -> None:
        """Restore active lockouts from DB into the in-memory rate limiter."""
        try:
            from .models import AccountLockout
            from .rate_limiter import get_rate_limiter
            from loguru import logger
            from datetime import datetime, timezone

            limiter = get_rate_limiter()
            with session_scope() as db:
                active = db.query(AccountLockout).filter(
                    AccountLockout.unlocked_at.is_(None)
                ).all()
                for lockout in active:
                    config = AuthUserConfig()
                    if config.login_lockout_duration > 0:
                        from datetime import timedelta
                        locked_until = lockout.locked_at + timedelta(seconds=config.login_lockout_duration)
                        if locked_until > datetime.now(timezone.utc).replace(tzinfo=None):
                            limiter._lockouts[lockout.username.lower()] = locked_until
                        else:
                            # Expired — mark as unlocked in DB
                            lockout.unlocked_at = datetime.now(timezone.utc).replace(tzinfo=None)
                            lockout.unlocked_by = "auto-expired"
                    else:
                        limiter._lockouts[lockout.username.lower()] = None  # manual unlock
                if active:
                    logger.info(f"Restored {len(limiter._lockouts)} active lockout(s) from DB")
        except Exception as e:
            from loguru import logger
            logger.warning(f"Failed to restore lockouts: {e}")

    def _initialize_admin_user_if_needed(self) -> None:
        """
        Check if admin user initialization is needed and handle it appropriately.
        If default credentials are configured, create admin user automatically.
        If not, log that setup UI is available.
        """
        try:
            from .repository import initialize_admin_user, needs_initial_setup
            from loguru import logger

            with session_scope() as db:
            
                if needs_initial_setup(db):
                    # Try to initialize with default credentials if configured
                    initialize_admin_user(db)

                    # If still needs setup, inform about the setup UI
                    if needs_initial_setup(db):
                        logger.info("No admin user exists. Visit /setup/ to create the first admin user.")
                else:
                    logger.debug("Admin user already exists, no initialization needed.")
                
        except Exception as e:
            from loguru import logger
            logger.error(f"Error during admin user initialization check: {e}")

