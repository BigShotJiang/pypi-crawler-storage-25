from sqlalchemy import Column, String, Boolean, TIMESTAMP, JSON, Integer, ForeignKey, func
from starlette.authentication import BaseUser

from fastpluggy.core.database import Base


class FastPluggyBaseUser(Base, BaseUser):
    __tablename__ = "users"

    username = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_admin = Column(Boolean, default=False)
    last_login_at = Column(TIMESTAMP(), nullable=True)
    last_login_ip = Column(String(45), nullable=True)

    def __repr__(self) -> str:
        return self._repr(id=self.id, username=self.username)

    @property
    def is_authenticated(self) -> bool:
        return True

    @property
    def identity(self) -> str:
        return str(self.id)

    @property
    def display_name(self) -> str:
        return self.username




class Token(Base):
    __tablename__ = "api_tokens"

    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(100), nullable=False)
    token_hash = Column(String(64), nullable=False, unique=True, index=True)
    expires_at = Column(TIMESTAMP(), nullable=True)
    last_used_at = Column(TIMESTAMP(), nullable=True)

    def __repr__(self) -> str:
        return self._repr(id=self.id, name=self.name, user_id=self.user_id)


class TwoFactorSecret(Base):
    __tablename__ = "totp_secrets"
    __table_args__ = {"extend_existing": True}

    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"),
                     nullable=False, unique=True, index=True)
    secret = Column(String(64), nullable=False)       # base32 TOTP secret
    enabled = Column(Boolean, default=False)           # False until first verify
    backup_codes = Column(JSON, nullable=False, default=list)  # list of hashed codes


class Session(Base):
    __tablename__ = 'sessions'

    # session_id is the UUID token stored in the cookie; id (integer PK) is inherited from Base
    session_id = Column(String(255), unique=True, index=True, nullable=False)
    session_data = Column(JSON, nullable=False)
    session_lifetime = Column(TIMESTAMP(), nullable=False)
    session_time = Column(TIMESTAMP(), nullable=False)


class LoginAttempt(Base):
    __tablename__ = "login_attempts"

    username = Column(String(255), nullable=False, index=True)
    ip = Column(String(45), nullable=False, index=True)
    success = Column(Boolean, nullable=False, default=False)
    attempted_at = Column(TIMESTAMP(), nullable=False, server_default=func.now(), index=True)


class AccountLockout(Base):
    __tablename__ = "account_lockouts"

    username = Column(String(255), nullable=False, unique=True, index=True)
    locked_at = Column(TIMESTAMP(), nullable=False, server_default=func.now())
    reason = Column(String(255), nullable=False)
    unlocked_at = Column(TIMESTAMP(), nullable=True)
    unlocked_by = Column(String(255), nullable=True)
