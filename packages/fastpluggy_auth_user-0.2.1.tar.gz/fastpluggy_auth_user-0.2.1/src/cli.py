"""CLI commands for the auth_user plugin.

Registered as ``fp auth-user <command>`` via the ``fastpluggy.cli``
entry point group.  Heavy imports (DB models, auth managers) are lazy
(inside command bodies) so that loading the CLI module is fast.
"""


import click

from fastpluggy.cli_utils import with_db_session


@click.group("auth-user")
def auth_user_group():
    """Manage FastPluggy users."""


@auth_user_group.command("create-user")
@click.option("--username", prompt=True, help="Username for the new account")
@click.option("--email", prompt=True, default="", help="Email address (optional)")
@click.option(
    "--password",
    prompt=True,
    hide_input=True,
    confirmation_prompt=True,
    help="Password for the new account",
)
@click.option("--admin", is_flag=True, default=False, help="Grant admin privileges")
def create_user(username: str, email: str, password: str, admin: bool) -> None:
    """Create a new user interactively."""

    @with_db_session
    def _create(db):
        from fastpluggy_plugin.auth_user.auth.basic_auth import BasicAuthManager
        from fastpluggy_plugin.auth_user.models import FastPluggyBaseUser

        existing = (
            db.query(FastPluggyBaseUser)
            .filter(FastPluggyBaseUser.username == username)
            .first()
        )
        if existing:
            raise click.ClickException(f"Username '{username}' already exists.")

        hashed = BasicAuthManager.hash_password(password)
        user = FastPluggyBaseUser(
            username=username,
            hashed_password=hashed,
            is_admin=admin,
        )
        db.add(user)
        click.echo(f"User '{username}' created successfully (admin={admin}).")

    _create()
