from loguru import logger

from .config import AuthUserConfig
from .auth.basic_auth import BasicAuthManager
from .models import FastPluggyBaseUser, Session
from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session as DBSession  # alias to avoid conflict with our Session model


def initialize_admin_user(db):
    """
    Create a default admin user if no users exist in the database.
    Only works if default credentials are configured (not None).
    """
    user_count = db.query(FastPluggyBaseUser).count()
    if user_count == 0:
        settings_auth = AuthUserConfig()

        # Only create admin user if default credentials are configured
        if settings_auth.default_admin_username and settings_auth.default_admin_password:
            hashed_password = BasicAuthManager.hash_password(settings_auth.default_admin_password)

            admin_user = FastPluggyBaseUser(
                username=settings_auth.default_admin_username,
                hashed_password=hashed_password,
                is_admin=True,
            )

            db.add(admin_user)
            db.commit()
            logger.info(f"Default admin user created with username '{settings_auth.default_admin_username}'.")
        else:
            logger.info("No default admin credentials configured. Admin user setup required via UI.")


def needs_initial_setup(db) -> bool:
    """
    Check if the system needs initial setup (no users exist).
    """
    user_count = db.query(FastPluggyBaseUser).count()
    return user_count == 0


def create_admin_user(db, username: str, password: str):
    """
    Create an admin user with the provided credentials.
    """
    existing_user = db.query(FastPluggyBaseUser).filter(
        FastPluggyBaseUser.username == username
    ).first()

    if existing_user:
        raise ValueError(f"Username '{username}' already exists")

    hashed_password = BasicAuthManager.hash_password(password)

    admin_user = FastPluggyBaseUser(
        username=username,
        hashed_password=hashed_password,
        is_admin=True,
    )

    db.add(admin_user)
    db.commit()
    logger.info(f"Admin user '{username}' created successfully.")
    return admin_user




def create_user(db, username: str, password: str):
    """
    Create a regular (non-admin) user with the provided credentials.
    """
    existing_user = db.query(FastPluggyBaseUser).filter(
        FastPluggyBaseUser.username == username
    ).first()

    if existing_user:
        raise ValueError(f"Username '{username}' already exists")

    hashed_password = BasicAuthManager.hash_password(password)

    user = FastPluggyBaseUser(
        username=username,
        hashed_password=hashed_password,
        is_admin=False,
    )

    db.add(user)
    db.commit()
    logger.info(f"User '{username}' created via self-registration.")
    return user


def get_user_sessions(db: DBSession, user_id: int) -> list[Session]:
    """Return all non-expired sessions for a given user, newest first."""
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    return [
        s for s in db.query(Session).all()
        if s.session_data.get("user_id") == user_id and s.session_lifetime > now
    ]


def delete_user_sessions(db: DBSession, user_id: int, except_session_id: str | None = None) -> int:
    """
    Delete all session rows belonging to a user.

    Args:
        db: SQLAlchemy database session.
        user_id: The user whose sessions should be deleted.
        except_session_id: If provided, keep this session (the caller's current session).

    Returns:
        The number of deleted sessions.
    """
    sessions = db.query(Session).all()
    count = 0
    for s in sessions:
        if s.session_data.get("user_id") != user_id:
            continue
        if except_session_id is not None and s.session_id == except_session_id:
            continue
        db.delete(s)
        count += 1
    if count:
        db.commit()
    return count


def create_or_update_session(db: DBSession, sess_id: str, sess_data: dict, lifetime_seconds: int):
    """
    Create or update a session record in the sessions table.

    Args:
        db (DBSession): The SQLAlchemy database session.
        sess_id (str): The unique session identifier.
        sess_data (dict): The session data to be stored (will be saved as JSON).
        lifetime_seconds (int): The lifetime of the session in seconds.

    Returns:
        The session record (instance of Session) that was created or updated.
    """
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    expiry_time = now + timedelta(seconds=lifetime_seconds)

    # Query for an existing session with the same ID.
    session_record = db.query(Session).filter(Session.session_id == sess_id).first()

    if session_record:
        # Update the existing session.
        session_record.session_data = sess_data
        session_record.session_lifetime = expiry_time
        session_record.session_time = now
    else:
        # Create a new session record.
        session_record = Session(
            session_id=sess_id,
            session_data=sess_data,
            session_lifetime=expiry_time,
            session_time=now
        )
        db.add(session_record)

    db.commit()
    return session_record
