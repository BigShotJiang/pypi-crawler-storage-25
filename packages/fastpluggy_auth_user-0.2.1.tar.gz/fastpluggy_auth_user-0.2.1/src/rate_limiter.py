"""Login rate limiter — in-memory sliding window with DB-backed lockout."""
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass
from loguru import logger


@dataclass
class RateLimitResult:
    allowed: bool
    retry_after: int = 0  # seconds
    reason: str = ""


class LoginRateLimiter:
    """Sliding window rate limiter for login attempts.

    Two layers:
    - Per-username: prevents brute force against a single account
    - Per-IP: prevents distributed attacks from one source
    """

    def __init__(self, per_user: int = 5, per_ip: int = 20, window: int = 60,
                 lockout_threshold: int = 15, lockout_duration: int = 900):
        self.per_user = per_user
        self.per_ip = per_ip
        self.window = window  # seconds
        self.lockout_threshold = lockout_threshold
        self.lockout_duration = lockout_duration  # 0 = manual unlock only

        # Sliding window: username/IP → deque of attempt timestamps
        self._user_attempts: dict[str, deque] = defaultdict(deque)
        self._ip_attempts: dict[str, deque] = defaultdict(deque)
        # Total failed attempts per username (for lockout threshold)
        self._user_failures: dict[str, int] = defaultdict(int)
        # Active lockouts: username → locked_until (None = manual unlock only)
        self._lockouts: dict[str, datetime | None] = {}

    def check_rate_limit(self, username: str, ip: str) -> RateLimitResult:
        """Check if a login attempt is allowed."""
        now = datetime.now(timezone.utc)
        username_lower = username.lower()

        # Check lockout first
        if self.is_locked(username_lower):
            locked_until = self._lockouts.get(username_lower)
            retry_after = 0
            if locked_until:
                retry_after = max(0, int((locked_until - now).total_seconds()))
            return RateLimitResult(
                allowed=False,
                retry_after=retry_after,
                reason="Account locked due to repeated failed attempts."
            )

        # Check per-username rate
        self._prune(self._user_attempts[username_lower], now)
        if len(self._user_attempts[username_lower]) >= self.per_user:
            oldest = self._user_attempts[username_lower][0]
            retry_after = max(0, int((oldest + timedelta(seconds=self.window) - now).total_seconds()))
            return RateLimitResult(
                allowed=False,
                retry_after=retry_after,
                reason="Too many login attempts for this account."
            )

        # Check per-IP rate
        self._prune(self._ip_attempts[ip], now)
        if len(self._ip_attempts[ip]) >= self.per_ip:
            oldest = self._ip_attempts[ip][0]
            retry_after = max(0, int((oldest + timedelta(seconds=self.window) - now).total_seconds()))
            return RateLimitResult(
                allowed=False,
                retry_after=retry_after,
                reason="Too many login attempts from this IP."
            )

        return RateLimitResult(allowed=True)

    def record_attempt(self, username: str, ip: str, success: bool) -> None:
        """Record a login attempt. Resets counters on success."""
        now = datetime.now(timezone.utc)
        username_lower = username.lower()

        if success:
            # Clear rate limit counters for this username
            self._user_attempts.pop(username_lower, None)
            self._user_failures.pop(username_lower, None)
            return

        # Failed attempt
        self._user_attempts[username_lower].append(now)
        self._ip_attempts[ip].append(now)
        self._user_failures[username_lower] += 1

        # Check lockout threshold
        if self._user_failures[username_lower] >= self.lockout_threshold:
            self.record_lockout(username_lower)

    def record_lockout(self, username: str) -> None:
        """Lock an account."""
        username_lower = username.lower()
        if self.lockout_duration > 0:
            self._lockouts[username_lower] = datetime.now(timezone.utc) + timedelta(seconds=self.lockout_duration)
        else:
            self._lockouts[username_lower] = None  # manual unlock only
        logger.warning(f"Account locked: {username_lower} (threshold: {self.lockout_threshold} failures)")

    def is_locked(self, username: str) -> bool:
        """Check if an account is currently locked."""
        username_lower = username.lower()
        if username_lower not in self._lockouts:
            return False
        locked_until = self._lockouts[username_lower]
        if locked_until is None:
            return True  # manual unlock only
        if datetime.now(timezone.utc) >= locked_until:
            # Auto-unlock expired
            self.unlock(username_lower)
            return False
        return True

    def unlock(self, username: str) -> None:
        """Unlock an account and reset failure counters."""
        username_lower = username.lower()
        self._lockouts.pop(username_lower, None)
        self._user_failures.pop(username_lower, None)
        self._user_attempts.pop(username_lower, None)
        logger.info(f"Account unlocked: {username_lower}")

    def get_remaining(self, username: str, ip: str) -> dict:
        """Get remaining attempts for headers."""
        now = datetime.now(timezone.utc)
        username_lower = username.lower()
        self._prune(self._user_attempts[username_lower], now)
        self._prune(self._ip_attempts[ip], now)
        user_remaining = max(0, self.per_user - len(self._user_attempts[username_lower]))
        ip_remaining = max(0, self.per_ip - len(self._ip_attempts[ip]))
        return {
            "user_remaining": user_remaining,
            "ip_remaining": ip_remaining,
            "remaining": min(user_remaining, ip_remaining),
        }

    def _prune(self, dq: deque, now: datetime) -> None:
        """Remove entries older than the window."""
        cutoff = now - timedelta(seconds=self.window)
        while dq and dq[0] < cutoff:
            dq.popleft()


# Module-level singleton — initialized from config on first use
_limiter: LoginRateLimiter | None = None


def get_rate_limiter() -> LoginRateLimiter:
    """Get or create the singleton rate limiter, configured from AuthUserConfig."""
    global _limiter
    if _limiter is None:
        from .config import AuthUserConfig
        config = AuthUserConfig()
        _limiter = LoginRateLimiter(
            per_user=config.login_rate_limit_per_user,
            per_ip=config.login_rate_limit_per_ip,
            window=config.login_rate_limit_window,
            lockout_threshold=config.login_lockout_threshold,
            lockout_duration=config.login_lockout_duration,
        )
    return _limiter
