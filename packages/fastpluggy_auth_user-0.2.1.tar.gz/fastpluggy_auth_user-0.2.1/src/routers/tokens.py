import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from starlette import status

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.widgets import CustomTemplateWidget
from ..config import AuthUserConfig
from ..models import Token


def _tokens_enabled() -> bool:
    return AuthUserConfig().allow_api_tokens

TOKENS_PREFIX = "/profile/tokens"

tokens_router = APIRouter(prefix="/tokens", tags=["tokens"])


@tokens_router.get("/", response_class=HTMLResponse)
async def tokens_page(
    request: Request,
    view_builder=Depends(get_view_builder),
    db: Session = Depends(get_db),
):
    if not _tokens_enabled():
        FlashMessage.add(request, "API access tokens are disabled by the administrator.", "warning")
        return RedirectResponse("/profile/", status_code=303)
    user = request.state.current_user
    new_token = request.session.pop("new_token", None)
    tokens = (
        db.query(Token)
        .filter(Token.user_id == user.id)
        .order_by(Token.created_at.desc())
        .all()
    )
    return view_builder.generate(
        request,
        title="API Access Tokens",
        widgets=[
            CustomTemplateWidget(
                template_name="auth_user/tokens.html.j2",
                context={
                    "tokens": tokens,
                    "now": datetime.now(timezone.utc).replace(tzinfo=None),
                    "new_token": new_token,
                    "tokens_prefix": TOKENS_PREFIX,
                },
            )
        ],
    )


@tokens_router.post("/create", response_class=HTMLResponse)
async def create_token(
    request: Request,
    name: str = Form(...),
    expires_in_days: Optional[int] = Form(None),
    db: Session = Depends(get_db),
):
    if not _tokens_enabled():
        FlashMessage.add(request, "API access tokens are disabled by the administrator.", "warning")
        return RedirectResponse("/profile/", status_code=303)
    user = request.state.current_user
    if not name.strip():
        FlashMessage.add(request, "Token name is required.", "danger")
        return RedirectResponse(TOKENS_PREFIX + "/", status_code=status.HTTP_303_SEE_OTHER)

    raw_token = secrets.token_hex(32)
    token_hash = hashlib.sha256(raw_token.encode()).hexdigest()
    expires_at = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=expires_in_days) if expires_in_days else None

    token = Token(
        user_id=user.id,
        name=name.strip(),
        token_hash=token_hash,
        expires_at=expires_at,
    )
    db.add(token)
    db.commit()

    request.session["new_token"] = raw_token
    FlashMessage.add(request, "Token created. Copy it now — it won't be shown again.", "success")
    return RedirectResponse(TOKENS_PREFIX + "/", status_code=status.HTTP_303_SEE_OTHER)


@tokens_router.post("/revoke/{token_id}", response_class=HTMLResponse)
async def revoke_token(
    token_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    user = request.state.current_user
    token = db.query(Token).filter(Token.id == token_id, Token.user_id == user.id).first()
    if not token:
        FlashMessage.add(request, "Token not found.", "danger")
        return RedirectResponse(TOKENS_PREFIX + "/", status_code=status.HTTP_303_SEE_OTHER)

    name = token.name
    db.delete(token)
    db.commit()
    FlashMessage.add(request, f"Token '{name}' revoked.", "success")
    return RedirectResponse(TOKENS_PREFIX + "/", status_code=status.HTTP_303_SEE_OTHER)
