from datetime import datetime, timezone

from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from starlette import status

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.widgets import CustomTemplateWidget
from ..models import Session as AuthSession
from ..repository import get_user_sessions, delete_user_sessions

SESSIONS_PREFIX = "/profile/sessions"

sessions_router = APIRouter(prefix="/sessions", tags=["sessions"])


@sessions_router.get("/", response_class=HTMLResponse)
async def sessions_page(
    request: Request,
    view_builder=Depends(get_view_builder),
    db: Session = Depends(get_db),
):
    user = request.state.current_user
    current_session_id = request.cookies.get("session")
    sessions = get_user_sessions(db, user.id)
    return view_builder.generate(
        request,
        title="Active Sessions",
        widgets=[
            CustomTemplateWidget(
                template_name="auth_user/sessions.html.j2",
                context={
                    "sessions": sessions,
                    "current_session_id": current_session_id,
                    "now": datetime.now(timezone.utc).replace(tzinfo=None),
                    "sessions_prefix": SESSIONS_PREFIX,
                },
            )
        ],
    )


@sessions_router.post("/revoke/{session_id:int}", response_class=HTMLResponse)
async def revoke_session(
    session_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    user = request.state.current_user
    current_session_id = request.cookies.get("session")
    target = db.query(AuthSession).filter(AuthSession.id == session_id).first()

    if not target or target.session_data.get("user_id") != user.id:
        FlashMessage.add(request, "Session not found.", "danger")
        return RedirectResponse(SESSIONS_PREFIX + "/", status_code=status.HTTP_303_SEE_OTHER)

    if target.session_id == current_session_id:
        FlashMessage.add(request, "You cannot revoke your current session.", "warning")
        return RedirectResponse(SESSIONS_PREFIX + "/", status_code=status.HTTP_303_SEE_OTHER)

    db.delete(target)
    db.commit()
    FlashMessage.add(request, "Session revoked.", "success")
    return RedirectResponse(SESSIONS_PREFIX + "/", status_code=status.HTTP_303_SEE_OTHER)


@sessions_router.post("/revoke-all", response_class=HTMLResponse)
async def revoke_all_other_sessions(
    request: Request,
    db: Session = Depends(get_db),
):
    user = request.state.current_user
    current_session_id = request.cookies.get("session")
    count = delete_user_sessions(db, user.id, except_session_id=current_session_id)

    if count:
        FlashMessage.add(request, f"{count} other session(s) revoked.", "success")
    else:
        FlashMessage.add(request, "No other sessions to revoke.", "info")
    return RedirectResponse(SESSIONS_PREFIX + "/", status_code=status.HTTP_303_SEE_OTHER)
