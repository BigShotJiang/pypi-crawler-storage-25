from fastapi import APIRouter, Request, Depends
from fastapi.responses import RedirectResponse, HTMLResponse
from sqlalchemy.orm import Session
from wtforms import StringField, PasswordField, validators
from wtforms.form import Form

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_templates
from fastpluggy.core.flash import FlashMessage
from ..config import AuthUserConfig
from ..repository import create_user

register_router = APIRouter(prefix="", tags=["register"])


class RegistrationForm(Form):
    username = StringField('Username', [
        validators.DataRequired(),
        validators.Length(min=3, max=50)
    ])
    password = PasswordField('Password', [
        validators.DataRequired(),
        validators.Length(min=6, max=100)
    ])
    confirm_password = PasswordField('Confirm Password', [
        validators.DataRequired(),
        validators.EqualTo('password', message='Passwords must match')
    ])


def _registration_allowed() -> bool:
    config = AuthUserConfig()
    return config.allow_self_registration and config.auth_backend == "session"


@register_router.get("/register", response_class=HTMLResponse)
async def register_page(
    request: Request,
    templates=Depends(get_templates),
):
    if not _registration_allowed():
        return RedirectResponse(url="/login", status_code=302)

    return templates.TemplateResponse(
        "auth_user/register.html.j2",
        {"request": request, "title": "Create an Account"},
    )


@register_router.post("/register", response_class=HTMLResponse)
async def register_post(
    request: Request,
    db: Session = Depends(get_db),
    templates=Depends(get_templates),
):
    if not _registration_allowed():
        return RedirectResponse(url="/login", status_code=302)

    form_data = await request.form()
    form = RegistrationForm(formdata=form_data)

    if not form.validate():
        return templates.TemplateResponse(
            "auth_user/register.html.j2",
            {
                "request": request,
                "title": "Create an Account",
                "errors": dict(form.errors),
                "form_data": {"username": form.username.data or ""},
            },
            status_code=400,
        )

    try:
        create_user(db, form.username.data, form.password.data)
        FlashMessage.add(request, f"Account '{form.username.data}' created successfully! You can now sign in.", "success")
        return RedirectResponse(url="/login", status_code=303)
    except ValueError as e:
        return templates.TemplateResponse(
            "auth_user/register.html.j2",
            {
                "request": request,
                "title": "Create an Account",
                "errors": {"username": [str(e)]},
                "form_data": {"username": form.username.data or ""},
            },
            status_code=400,
        )
