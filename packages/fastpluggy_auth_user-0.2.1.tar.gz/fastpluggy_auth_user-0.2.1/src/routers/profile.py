from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from starlette import status

from fastpluggy.core.auth import require_authentication
from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.widgets import CustomTemplateWidget
from ..auth.basic_auth import BasicAuthManager
from ..config import AuthUserConfig
from ..models import FastPluggyBaseUser, TwoFactorSecret
from ..repository import delete_user_sessions
from ..widgets import ChangePasswordWidget

profile_router = APIRouter(prefix="/profile", tags=["profile"])


@profile_router.get("/", response_class=HTMLResponse)
async def profile(
    request: Request,
    view_builder=Depends(get_view_builder),
    user=Depends(require_authentication),
    db: Session = Depends(get_db),
):
    widgets = [
        CustomTemplateWidget(
            template_name="auth_user/profile_card.html.j2",
            context={"user": user},
        ),
        ChangePasswordWidget(),
    ]

    # Add TOTP status card if 2FA is allowed
    config = AuthUserConfig()
    if config.allow_totp:
        totp_record = (
            db.query(TwoFactorSecret)
            .filter_by(user_id=user.id)
            .first()
        )
        totp_enabled = totp_record is not None and totp_record.enabled
        widgets.append(
            CustomTemplateWidget(
                template_name="auth_user/totp_status_card.html.j2",
                context={
                    "totp_enabled": totp_enabled,
                    "allow_totp": config.allow_totp,
                },
            )
        )

    return view_builder.generate(request, title="My Profile", widgets=widgets)


@profile_router.post("/", response_class=HTMLResponse)
async def profile_change_password(
    request: Request,
    current_password: str = Form(...),
    new_password: str = Form(...),
    confirm_password: str = Form(...),
    db: Session = Depends(get_db),
    user=Depends(require_authentication),
):
    if not BasicAuthManager.verify_password(current_password, user.hashed_password):
        FlashMessage.add(request, "Current password is incorrect.", "danger")
        return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)

    if new_password != confirm_password:
        FlashMessage.add(request, "New passwords do not match.", "danger")
        return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)

    if len(new_password) < 8:
        FlashMessage.add(request, "New password must be at least 8 characters.", "danger")
        return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)

    db_user = db.get(FastPluggyBaseUser, user.id)
    db_user.hashed_password = BasicAuthManager.hash_password(new_password)
    db.commit()

    current_session_id = request.cookies.get("session")
    delete_user_sessions(db, user.id, except_session_id=current_session_id)

    events = getattr(request.app.state, "events", None)
    if events:
        events.emit(
            "user.password_changed",
            source="auth_user",
            user_id=user.id,
            username=user.username,
            changed_by="self",
        )

    FlashMessage.add(request, "Password changed successfully.", "success")
    return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)
