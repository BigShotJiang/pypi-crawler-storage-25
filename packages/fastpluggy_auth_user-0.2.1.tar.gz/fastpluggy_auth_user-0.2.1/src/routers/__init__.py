from fastapi import APIRouter, Depends

from ..routers.login import login_router
from ..routers.profile import profile_router
from ..routers.setup import setup_router
from ..routers.admin import user_router
from ..routers.tokens import tokens_router
from ..routers.sessions import sessions_router
from ..routers.auth_settings import auth_settings_router
from ..routers.register import register_router
from ..routers.security import security_router
from ..routers.totp import totp_router
from fastpluggy.core.auth import require_authentication, require_role

router = APIRouter(
    tags=["auth_user"],
)

router.include_router(setup_router)   # Setup router (no auth required)
router.include_router(register_router)  # Registration (no auth required)
router.include_router(login_router)
router.include_router(profile_router, dependencies=[Depends(require_authentication)])
router.include_router(totp_router, dependencies=[Depends(require_authentication)])
router.include_router(tokens_router, prefix="/profile", dependencies=[Depends(require_authentication)])
router.include_router(sessions_router, prefix="/profile", dependencies=[Depends(require_authentication)])
router.include_router(user_router, dependencies=[Depends(require_authentication), Depends(require_role("fp_admin"))])
router.include_router(auth_settings_router, dependencies=[Depends(require_authentication), Depends(require_role("fp_admin"))])
router.include_router(security_router, dependencies=[Depends(require_authentication), Depends(require_role("fp_admin"))])