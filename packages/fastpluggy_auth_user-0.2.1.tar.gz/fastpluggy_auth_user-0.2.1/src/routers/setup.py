from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import RedirectResponse, HTMLResponse
from sqlalchemy.orm import Session
from wtforms import StringField, PasswordField, validators
from wtforms.form import Form

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_templates
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.repository.app_settings import set_app_setting
from ..config import AuthUserConfig
from ..repository import needs_initial_setup, create_admin_user

setup_router = APIRouter(prefix="/setup", tags=["setup"])


class AdminSetupForm(Form):
    username = StringField('Admin Username', [
        validators.DataRequired(),
        validators.Length(min=3, max=50)
    ])
    password = PasswordField('Admin Password', [
        validators.DataRequired(),
        validators.Length(min=6, max=100)
    ])
    confirm_password = PasswordField('Confirm Password', [
        validators.DataRequired(),
        validators.EqualTo('password', message='Passwords must match')
    ])


@setup_router.get("/", response_class=HTMLResponse)
async def setup_page(
    request: Request,
    db: Session = Depends(get_db),
    templates = Depends(get_templates)
):
    """
    Display the initial admin setup page if no users exist.
    Redirect to login if users already exist.
    """
    if not needs_initial_setup(db):
        FlashMessage.add(request, "Setup is already complete. Please sign in.", "warning")
        return RedirectResponse(url="/login", status_code=303)

    return templates.TemplateResponse(
        "auth_user/setup.html.j2",
        {"request": request, "title": "Initial Setup - Create Admin User"}
    )


@setup_router.post("/", response_class=HTMLResponse)
async def setup_post(
    request: Request,
    db: Session = Depends(get_db),
    templates = Depends(get_templates)
):
    """
    Process the admin setup form and create the first admin user.
    """
    # Check if setup is still needed
    if not needs_initial_setup(db):
        FlashMessage.add(request, "Setup is already complete. Please sign in.", "warning")
        return RedirectResponse(url="/login", status_code=303)
    
    # Get form data as multidict (proper format for WTForms)
    form_data = await request.form()
    form = AdminSetupForm(formdata=form_data)
    
    if not form.validate():
        # Return form with errors
        errors = {}
        for field, field_errors in form.errors.items():
            errors[field] = field_errors
        
        return templates.TemplateResponse(
            "auth_user/setup.html.j2",
            {
                "request": request,
                "title": "Initial Setup - Create Admin User",
                "errors": errors,
                "form_data": {
                    "username": form.username.data or "",
                    "password": "",  # Don't pre-fill password for security
                    "confirm_password": ""
                }
            },
            status_code=400
        )
    
    try:
        # Create the admin user
        create_admin_user(db, form.username.data, form.password.data)

        # Persist settings chosen during setup
        config = AuthUserConfig()
        set_app_setting(db, config, "collect_login_ip", "collect_login_ip" in form_data)
        set_app_setting(db, config, "allow_api_tokens", "allow_api_tokens" in form_data)
        set_app_setting(db, config, "allow_self_registration", "allow_self_registration" in form_data)
        set_app_setting(db, config, "allow_totp", "allow_totp" in form_data)

        # Redirect to login with success message
        response = RedirectResponse(url="/login", status_code=303)
        FlashMessage.add(request, f"Admin user '{form.username.data}' created successfully! You can now log in.", "success")
        return response
        
    except ValueError as e:
        # Handle username already exists error
        return templates.TemplateResponse(
            "auth_user/setup.html.j2",
            {
                "request": request,
                "title": "Initial Setup - Create Admin User",
                "errors": {"username": [str(e)]},
                "form_data": {
                    "username": form.username.data or "",
                    "password": "",  # Don't pre-fill password for security
                    "confirm_password": ""
                }
            },
            status_code=400
        )
    except Exception as e:
        # Handle other errors
        return templates.TemplateResponse(
            "auth_user/setup.html.j2",
            {
                "request": request,
                "title": "Initial Setup - Create Admin User",
                "errors": {"general": [f"An error occurred: {str(e)}"]},
                "form_data": {
                    "username": form.username.data or "",
                    "password": "",  # Don't pre-fill password for security
                    "confirm_password": ""
                }
            },
            status_code=500
        )


@setup_router.get("/check", response_class=HTMLResponse)
async def setup_check(db: Session = Depends(get_db)):
    """
    API endpoint to check if initial setup is needed.
    Returns JSON response.
    """
    return {"setup_needed": needs_initial_setup(db)}