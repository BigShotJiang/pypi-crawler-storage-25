from typing import Optional

from fastapi import APIRouter, Request, Depends, Query
from sqlalchemy.orm import Session
from starlette.responses import HTMLResponse, RedirectResponse
from wtforms import PasswordField
from wtforms.validators import DataRequired, Length

from ..auth.basic_auth import BasicAuthManager
from ..models import TwoFactorSecret
from ..repository import delete_user_sessions
from fastpluggy.core.database import get_db
from fastpluggy.core.menu.decorator import menu_entry
from fastpluggy.core.dependency import get_view_builder, get_fastpluggy
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.widgets.render_field_tools import RenderFieldTools
from fastpluggy.core.widgets import TableModelWidget, CustomTemplateWidget
from fastpluggy.core.widgets.categories.input.button_list import ButtonListWidget
from fastpluggy.core.widgets.categories.input.button import ButtonWidget
from fastpluggy.core.widgets.categories.input.form import FormWidget

# Define a constant for the common prefix
ADMIN_USERS_PREFIX = "/admin/users"

user_router = APIRouter(
    prefix=ADMIN_USERS_PREFIX,
    tags=["admin"]
)

@menu_entry(label="List Users", icon="ti ti-users", type='admin')
@user_router.get("/", response_class=HTMLResponse)
def list_users(
    request: Request,
    db: Session = Depends(get_db),
    fast_pluggy=Depends(get_fastpluggy),
    view_builder=Depends(get_view_builder),
    username: Optional[str] = Query(default=None),
    is_admin_filter: Optional[str] = Query(default=None),
):
    user_model = fast_pluggy.auth_manager.user_model

    # Build static is_admin filter with proper Python bool (avoids string-to-bool
    # coercion issues in the auto-filter). Username LIKE is handled automatically
    # by TableModelWidget.apply_filters_from_query via the request query params.
    static_filters = None
    if is_admin_filter == "true":
        static_filters = {"is_admin": True}
    elif is_admin_filter == "false":
        static_filters = {"is_admin": False}

    items = [
        CustomTemplateWidget(
            template_name="auth_user/user_filter.html.j2",
            context={
                "username": username or "",
                "is_admin_filter": is_admin_filter or "",
                "action_url": f"{ADMIN_USERS_PREFIX}/",
            },
        ),
        ButtonListWidget(
            buttons=[
                {
                    "url": f"{ADMIN_USERS_PREFIX}/add",
                    "label": "Add New User",
                    "icon": "ti ti-plus",
                },
                ButtonWidget(
                    url="/admin/auth-settings/",
                    label="Auth Settings",
                    css_class="btn btn-outline-secondary btn-sm",
                    icon="ti ti-settings",
                ),
            ]
        ),
        TableModelWidget(
            model=user_model,
            filters=static_filters,
            field_callbacks={
                user_model.is_admin: RenderFieldTools.render_boolean
            },
            exclude_fields=[
                user_model.hashed_password,
                user_model.last_login_at,
                user_model.last_login_ip,
            ],
        ),
    ]
    return view_builder.generate(
        request,
        title="Users",
        widgets=items,
    )


@user_router.api_route("/add", methods=["GET", "POST"])
async def add_user(
        request: Request,
        db: Session = Depends(get_db),
        fast_pluggy=Depends(get_fastpluggy),
        view_builder=Depends(get_view_builder),
):
    user_model = fast_pluggy.auth_manager.user_model

    form_view = FormWidget(
        model=user_model,
        exclude_fields=['hashed_password', user_model.created_at, user_model.updated_at,
                        user_model.last_login_at, user_model.last_login_ip],
        readonly_fields=["id"],
        additional_fields={
            'password': PasswordField('Password', validators=[DataRequired(), Length(min=6)]),
        },
        submit_label="Create User",
    )

    if request.method == "POST":
        form_data = await request.form()
        form = form_view.get_form(form_data)
        if form.validate():
            # Create a new user instance
            user = user_model()
            form.populate_obj(user)

            # Handle password separately
            if form.password.data:
                user.hashed_password = BasicAuthManager.hash_password(form.password.data)
            else:
                FlashMessage.add(request, "Password is required", "error")
                return RedirectResponse(f"{ADMIN_USERS_PREFIX}/add", status_code=303)

            user.id = None
            db.add(user)
            db.commit()
            FlashMessage.add(request, f"User '{user.username}' created successfully!", "success")
            return RedirectResponse(ADMIN_USERS_PREFIX, status_code=303)
        else:
            # Handle form errors
            FlashMessage.add(request, "Form is invalid. Please correct the errors and try again.", "error")

    back_button = ButtonListWidget(buttons=[
        ButtonWidget(url=f"{ADMIN_USERS_PREFIX}/", label="Back to Users",
                     css_class="btn btn-secondary btn-sm", icon="ti ti-arrow-left"),
    ])

    # Render the form (either with errors or as a blank form)
    return view_builder.generate(
        request,
        title="Add User",
        widgets=[back_button, form_view]
    )


@user_router.api_route("/edit/{user_id}", methods=["GET", "POST"])
async def edit_user(
        user_id: int,
        request: Request,
        db: Session = Depends(get_db),
        fast_pluggy=Depends(get_fastpluggy),
        view_builder=Depends(get_view_builder),
):
    user_model = fast_pluggy.auth_manager.user_model

    user = db.query(user_model).filter(user_model.id == user_id).first()
    if not user:
        FlashMessage.add(request, f"User {user_id} not found !", "error")
        return RedirectResponse(ADMIN_USERS_PREFIX, status_code=303)

    form_view = FormWidget(
        model=user_model,
        exclude_fields=['hashed_password', user_model.created_at, user_model.updated_at,
                        user_model.last_login_at, user_model.last_login_ip],
        readonly_fields=["id"],
        additional_fields={
            'password': PasswordField('Password')
        },
        data=user,
        submit_label="Update User",
    )

    if request.method == "POST":
        form_data = await request.form()
        form = form_view.get_form(form_data)
        if form.validate():
            form.populate_obj(user)

            # Handle password separately
            if form.password.data:
                user.hashed_password = BasicAuthManager.hash_password(form.password.data)

            db.commit()

            # Admin reset → revoke ALL sessions (no exception for current)
            if form.password.data:
                delete_user_sessions(db, user.id)
                events = getattr(request.app.state, "events", None)
                if events:
                    admin = getattr(request.state, "current_user", None)
                    events.emit(
                        "user.password_changed",
                        source="auth_user",
                        user_id=user.id,
                        username=user.username,
                        changed_by=f"admin:{getattr(admin, 'username', 'unknown')}",
                    )
            FlashMessage.add(request, f"User '{user.username}' updated successfully!", "success")
            return RedirectResponse(ADMIN_USERS_PREFIX, status_code=303)

    current_user = getattr(request.state, "current_user", None)
    is_self = current_user and getattr(current_user, "id", None) == user_id

    # Check if user has 2FA enabled
    totp_record = db.query(TwoFactorSecret).filter_by(user_id=user_id, enabled=True).first()

    delete_button = ButtonListWidget(
        title="Danger Zone",
        buttons=[
            ButtonWidget(
                url=f"{ADMIN_USERS_PREFIX}/disable-2fa/{user_id}",
                label="Disable 2FA",
                method="post",
                css_class="btn btn-warning btn-sm",
                icon="ti ti-shield-off",
                condition=bool(totp_record),
                confirm="Disable two-factor authentication for this user? They will need to set it up again.",
            ),
            ButtonWidget(
                url=f"{ADMIN_USERS_PREFIX}/delete/{user_id}",
                label="Delete User",
                method="post",
                css_class="btn btn-danger btn-sm",
                icon="ti ti-trash",
                condition=not is_self,
                confirm="Permanently delete this user? This cannot be undone.",
            )
        ],
    )

    back_button = ButtonListWidget(buttons=[
        ButtonWidget(url=f"{ADMIN_USERS_PREFIX}/", label="Back to Users",
                     css_class="btn btn-secondary btn-sm", icon="ti ti-arrow-left"),
    ])

    # Render the form (either with errors or as a blank form)
    return view_builder.generate(
        request,
        title="Edit User",
        widgets=[back_button, form_view, delete_button]
    )


@user_router.post("/delete/{user_id}")
async def delete_user(
    user_id: int,
    request: Request,
    db: Session = Depends(get_db),
    fast_pluggy=Depends(get_fastpluggy),
):
    current_user = getattr(request.state, "current_user", None)
    if current_user and getattr(current_user, "id", None) == user_id:
        FlashMessage.add(request, "You cannot delete your own account.", "error")
        return RedirectResponse(f"{ADMIN_USERS_PREFIX}/edit/{user_id}", status_code=303)

    user_model = fast_pluggy.auth_manager.user_model
    user = db.query(user_model).filter(user_model.id == user_id).first()
    if not user:
        FlashMessage.add(request, f"User {user_id} not found.", "error")
        return RedirectResponse(ADMIN_USERS_PREFIX, status_code=303)

    username = user.username
    db.delete(user)
    db.commit()
    FlashMessage.add(request, f"User '{username}' deleted successfully.", "success")
    return RedirectResponse(ADMIN_USERS_PREFIX, status_code=303)


@user_router.post("/disable-2fa/{user_id}")
async def admin_disable_2fa(
    user_id: int,
    request: Request,
    db: Session = Depends(get_db),
    fast_pluggy=Depends(get_fastpluggy),
):
    user_model = fast_pluggy.auth_manager.user_model
    user = db.query(user_model).filter(user_model.id == user_id).first()
    if not user:
        FlashMessage.add(request, f"User {user_id} not found.", "error")
        return RedirectResponse(ADMIN_USERS_PREFIX, status_code=303)

    record = db.query(TwoFactorSecret).filter_by(user_id=user_id).first()
    if record:
        db.delete(record)
        db.commit()

        events = getattr(request.app.state, "events", None)
        if events:
            admin = getattr(request.state, "current_user", None)
            events.emit(
                "user.totp_disabled",
                source="auth_user",
                user_id=user.id,
                username=user.username,
                disabled_by=f"admin:{getattr(admin, 'username', 'unknown')}",
            )

    FlashMessage.add(request, f"2FA disabled for '{user.username}'.", "success")
    return RedirectResponse(f"{ADMIN_USERS_PREFIX}/edit/{user_id}", status_code=303)
