import hashlib
import io
import secrets

import pyotp
import qrcode
import qrcode.image.svg
from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from starlette import status

from fastpluggy.core.auth import require_authentication
from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.widgets import CustomTemplateWidget
from ..auth.basic_auth import BasicAuthManager
from ..config import AuthUserConfig
from ..models import TwoFactorSecret

totp_router = APIRouter(prefix="/profile/2fa", tags=["totp"])


def _get_config() -> AuthUserConfig:
    return AuthUserConfig()


def _generate_qr_uri(username: str, secret: str, issuer: str | None = None) -> str:
    config = _get_config()
    totp = pyotp.TOTP(secret)
    return totp.provisioning_uri(
        name=username,
        issuer_name=issuer or getattr(config, "app_name", None) or "FastPluggy",
    )


def _qr_as_svg(uri: str) -> str:
    img = qrcode.make(uri, image_factory=qrcode.image.svg.SvgPathImage)
    buf = io.BytesIO()
    img.save(buf)
    return buf.getvalue().decode()


def _format_secret(secret: str) -> str:
    """Format a base32 secret as groups of 4 characters separated by spaces."""
    return " ".join(secret[i : i + 4] for i in range(0, len(secret), 4))


def _generate_backup_codes(n: int = 10) -> tuple[list[str], list[str]]:
    """Return (plaintext_list, hashed_list) -- store hashed, show plaintext once."""
    plain = [
        f"{secrets.token_hex(4).upper()}-{secrets.token_hex(4).upper()}"
        for _ in range(n)
    ]
    hashed = [hashlib.sha256(c.encode()).hexdigest() for c in plain]
    return plain, hashed


@totp_router.get("/", response_class=HTMLResponse)
async def totp_status(
    request: Request,
    view_builder=Depends(get_view_builder),
    user=Depends(require_authentication),
    db: Session = Depends(get_db),
):
    config = _get_config()
    if not config.allow_totp:
        return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)

    record = (
        db.query(TwoFactorSecret)
        .filter_by(user_id=user.id)
        .first()
    )
    totp_enabled = record is not None and record.enabled

    widgets = [
        CustomTemplateWidget(
            template_name="auth_user/totp_status_card.html.j2",
            context={
                "totp_enabled": totp_enabled,
                "allow_totp": config.allow_totp,
            },
        ),
    ]
    return view_builder.generate(
        request, title="Two-Factor Authentication", widgets=widgets
    )


@totp_router.post("/setup", response_class=HTMLResponse)
async def totp_setup(
    request: Request,
    view_builder=Depends(get_view_builder),
    user=Depends(require_authentication),
    db: Session = Depends(get_db),
):
    config = _get_config()
    if not config.allow_totp:
        return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)

    # Check if already enabled
    existing = (
        db.query(TwoFactorSecret)
        .filter_by(user_id=user.id, enabled=True)
        .first()
    )
    if existing:
        FlashMessage.add(request, "2FA is already enabled on your account.", "warning")
        return RedirectResponse(
            url="/profile/2fa/", status_code=status.HTTP_303_SEE_OTHER
        )

    # Generate a new secret
    secret = pyotp.random_base32()
    uri = _generate_qr_uri(user.username, secret)
    qr_svg = _qr_as_svg(uri)
    manual_key = _format_secret(secret)

    widgets = [
        CustomTemplateWidget(
            template_name="auth_user/totp_setup.html.j2",
            context={
                "qr_svg": qr_svg,
                "manual_key": manual_key,
                "secret": secret,
            },
        ),
    ]
    return view_builder.generate(
        request, title="Set Up Two-Factor Authentication", widgets=widgets
    )


@totp_router.post("/verify", response_class=HTMLResponse)
async def totp_verify(
    request: Request,
    secret: str = Form(...),
    code: str = Form(...),
    view_builder=Depends(get_view_builder),
    user=Depends(require_authentication),
    db: Session = Depends(get_db),
):
    config = _get_config()
    if not config.allow_totp:
        return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)

    # Verify the TOTP code against the provided secret
    totp = pyotp.TOTP(secret)
    if not totp.verify(code.strip(), valid_window=1):
        FlashMessage.add(
            request,
            "Invalid verification code. Please try again.",
            "danger",
        )
        # Re-show the setup page with the same secret
        uri = _generate_qr_uri(user.username, secret)
        qr_svg = _qr_as_svg(uri)
        manual_key = _format_secret(secret)
        widgets = [
            CustomTemplateWidget(
                template_name="auth_user/totp_setup.html.j2",
                context={
                    "qr_svg": qr_svg,
                    "manual_key": manual_key,
                    "secret": secret,
                },
            ),
        ]
        return view_builder.generate(
            request, title="Set Up Two-Factor Authentication", widgets=widgets
        )

    # Generate backup codes
    plain_codes, hashed_codes = _generate_backup_codes()

    # Create or update TwoFactorSecret record
    record = db.query(TwoFactorSecret).filter_by(user_id=user.id).first()
    if record:
        record.secret = secret
        record.enabled = True
        record.backup_codes = hashed_codes
    else:
        record = TwoFactorSecret(
            user_id=user.id,
            secret=secret,
            enabled=True,
            backup_codes=hashed_codes,
        )
        db.add(record)
    db.commit()

    # Emit event
    events = getattr(request.app.state, "events", None)
    if events:
        events.emit(
            "user.totp_enabled",
            source="auth_user",
            user_id=user.id,
            username=user.username,
        )

    FlashMessage.add(request, "Two-factor authentication has been enabled.", "success")

    # Show backup codes
    widgets = [
        CustomTemplateWidget(
            template_name="auth_user/totp_backup_codes.html.j2",
            context={"backup_codes": plain_codes},
        ),
    ]
    return view_builder.generate(
        request, title="Backup Codes", widgets=widgets
    )


@totp_router.post("/disable", response_class=HTMLResponse)
async def totp_disable(
    request: Request,
    password: str = Form(...),
    code: str = Form(...),
    user=Depends(require_authentication),
    db: Session = Depends(get_db),
):
    config = _get_config()
    if not config.allow_totp:
        return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)

    # Verify password
    if not BasicAuthManager.verify_password(password, user.hashed_password):
        FlashMessage.add(request, "Incorrect password.", "danger")
        return RedirectResponse(
            url="/profile/2fa/", status_code=status.HTTP_303_SEE_OTHER
        )

    # Verify TOTP code
    record = (
        db.query(TwoFactorSecret)
        .filter_by(user_id=user.id, enabled=True)
        .first()
    )
    if not record:
        FlashMessage.add(request, "2FA is not enabled on your account.", "warning")
        return RedirectResponse(
            url="/profile/2fa/", status_code=status.HTTP_303_SEE_OTHER
        )

    totp = pyotp.TOTP(record.secret)
    if not totp.verify(code.strip(), valid_window=1):
        FlashMessage.add(request, "Invalid 2FA code.", "danger")
        return RedirectResponse(
            url="/profile/2fa/", status_code=status.HTTP_303_SEE_OTHER
        )

    # Delete the record
    db.delete(record)
    db.commit()

    # Emit event
    events = getattr(request.app.state, "events", None)
    if events:
        events.emit(
            "user.totp_disabled",
            source="auth_user",
            user_id=user.id,
            username=user.username,
        )

    FlashMessage.add(
        request, "Two-factor authentication has been disabled.", "success"
    )
    return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)


@totp_router.post("/backup-codes", response_class=HTMLResponse)
async def totp_regenerate_backup_codes(
    request: Request,
    code: str = Form(...),
    view_builder=Depends(get_view_builder),
    user=Depends(require_authentication),
    db: Session = Depends(get_db),
):
    config = _get_config()
    if not config.allow_totp:
        return RedirectResponse(url="/profile/", status_code=status.HTTP_303_SEE_OTHER)

    record = (
        db.query(TwoFactorSecret)
        .filter_by(user_id=user.id, enabled=True)
        .first()
    )
    if not record:
        FlashMessage.add(request, "2FA is not enabled on your account.", "warning")
        return RedirectResponse(
            url="/profile/2fa/", status_code=status.HTTP_303_SEE_OTHER
        )

    # Verify current TOTP code
    totp = pyotp.TOTP(record.secret)
    if not totp.verify(code.strip(), valid_window=1):
        FlashMessage.add(request, "Invalid 2FA code.", "danger")
        return RedirectResponse(
            url="/profile/2fa/", status_code=status.HTTP_303_SEE_OTHER
        )

    # Generate new backup codes
    plain_codes, hashed_codes = _generate_backup_codes()
    record.backup_codes = hashed_codes
    db.commit()

    FlashMessage.add(request, "Backup codes have been regenerated.", "success")

    widgets = [
        CustomTemplateWidget(
            template_name="auth_user/totp_backup_codes.html.j2",
            context={"backup_codes": plain_codes},
        ),
    ]
    return view_builder.generate(
        request, title="New Backup Codes", widgets=widgets
    )
