import hashlib
import uuid
from datetime import datetime, timezone
from typing import Optional

import pyotp
from fastapi import APIRouter, Request, Form, Depends
from loguru import logger
from fastapi.responses import RedirectResponse, HTMLResponse
from sqlalchemy.orm import Session
from starlette import status

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_templates
from fastpluggy.core.tools.fastapi import get_client_ip
from ..auth.basic_auth import BasicAuthManager
from ..config import AuthUserConfig
from ..models import FastPluggyBaseUser, TwoFactorSecret, LoginAttempt, AccountLockout
from ..rate_limiter import get_rate_limiter
from ..repository import create_or_update_session, needs_initial_setup


login_router = APIRouter()


def _verify_totp_or_backup(record: TwoFactorSecret, code: str, db: Session) -> bool:
    """Verify a TOTP code or single-use backup code. Consumes backup code if used."""
    code = code.strip()
    # Try TOTP
    totp = pyotp.TOTP(record.secret)
    if totp.verify(code, valid_window=1):
        return True
    # Try backup codes (uppercase for case-insensitive match)
    code_hash = hashlib.sha256(code.upper().encode()).hexdigest()
    if code_hash in (record.backup_codes or []):
        record.backup_codes = [c for c in record.backup_codes if c != code_hash]
        db.commit()
        return True
    return False


@login_router.get("/login", name="login", response_class=HTMLResponse)
async def login_page(
    request: Request,
    next: Optional[str] = None,
    signed_out: Optional[str] = None,
    db: Session = Depends(get_db),
    templates=Depends(get_templates),
):
    current_user = getattr(request.state, "current_user", None)
    if current_user and getattr(current_user, "is_authenticated", False):
        return RedirectResponse(url=next or "/", status_code=302)
    config = AuthUserConfig()
    return templates.TemplateResponse(
        "auth_user/login.html.j2",
        {
            "request": request,
            "next": next or "",
            "setup_needed": needs_initial_setup(db),
            "signed_out": signed_out == "1",
            "allow_registration": config.allow_self_registration and config.auth_backend == "session",
        },
    )


@login_router.post("/login", name="login_post", response_class=HTMLResponse)
async def login_post(
    request: Request,
    username: Optional[str] = Form(None),
    password: Optional[str] = Form(None),
    remember: Optional[str] = Form(None),
    next: Optional[str] = Form(None),
    db: Session = Depends(get_db),
    templates=Depends(get_templates),
):
    config = AuthUserConfig()
    ip = get_client_ip(request)

    if not username or not password:
        return templates.TemplateResponse(
            "auth_user/login.html.j2",
            {
                "request": request,
                "error": "Username and password are required",
                "next": next or "",
                "setup_needed": needs_initial_setup(db),
                "allow_registration": config.allow_self_registration and config.auth_backend == "session",
            },
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        )

    # Rate limit check
    limiter = get_rate_limiter()
    result = limiter.check_rate_limit(username, ip)
    if not result.allowed:
        logger.warning("Rate limited login for username='{}' ip={}: {}", username, ip, result.reason)
        status_code = status.HTTP_403_FORBIDDEN if limiter.is_locked(username.lower()) else 429
        response = templates.TemplateResponse(
            "auth_user/login.html.j2",
            {
                "request": request,
                "error": result.reason,
                "next": next or "",
                "setup_needed": needs_initial_setup(db),
                "allow_registration": config.allow_self_registration and config.auth_backend == "session",
            },
            status_code=status_code,
        )
        if result.retry_after > 0:
            response.headers["Retry-After"] = str(result.retry_after)
        remaining = limiter.get_remaining(username, ip)
        response.headers["X-RateLimit-Remaining"] = str(remaining["remaining"])
        return response

    user = db.query(FastPluggyBaseUser).filter(FastPluggyBaseUser.username == username).first()

    if not user or not BasicAuthManager.verify_password(password, user.hashed_password):
        logger.warning("Failed login attempt for username='{}' ip={}", username, ip)
        # Record failed attempt
        limiter.record_attempt(username, ip, success=False)
        db.add(LoginAttempt(username=username, ip=ip, success=False))
        db.commit()
        # Check if lockout was triggered
        if limiter.is_locked(username.lower()):
            db.add(AccountLockout(
                username=username.lower(),
                reason=f"{config.login_lockout_threshold} failed attempts",
            ))
            db.commit()
            events = getattr(request.app.state, "events", None)
            if events:
                events.emit("user.locked_out", source="auth_user", username=username, ip=ip)

        return templates.TemplateResponse(
            "auth_user/login.html.j2",
            {
                "request": request,
                "error": "Invalid username or password",
                "next": next or "",
                "setup_needed": needs_initial_setup(db),
                "allow_registration": config.allow_self_registration and config.auth_backend == "session",
            },
            status_code=status.HTTP_401_UNAUTHORIZED,
        )

    # Successful credential check — record and clear rate counters
    limiter.record_attempt(username, ip, success=True)
    db.add(LoginAttempt(username=username, ip=ip, success=True))
    db.commit()

    # Check if user has TOTP 2FA enabled
    totp_record = db.query(TwoFactorSecret).filter_by(user_id=user.id, enabled=True).first()
    if totp_record:
        # Create pending 2FA session instead of real session
        pending_id = str(uuid.uuid4())
        create_or_update_session(db, pending_id, {
            "pending_2fa_user_id": user.id,
            "next": next or "/",
            "remember": bool(remember),
            "attempts": 0,
        }, config.totp_pending_lifetime)
        response = RedirectResponse(url="/login/2fa", status_code=status.HTTP_303_SEE_OTHER)
        response.set_cookie("pending_2fa", pending_id, httponly=True, samesite="lax", max_age=config.totp_pending_lifetime)
        return response

    # If require_totp is enabled but user has no 2FA, force setup
    if config.require_totp and config.allow_totp:
        _complete_login(request, db, user, remember, config)
        session_id = str(uuid.uuid4())
        lifetime = config.session_lifetime_remember if remember else config.session_lifetime
        create_or_update_session(db, session_id, {"user_id": user.id}, lifetime)
        response = RedirectResponse(url="/profile/2fa/", status_code=status.HTTP_303_SEE_OTHER)
        response.set_cookie(key="session", value=session_id, max_age=lifetime, httponly=True, samesite="lax")
        return response

    # Normal login — no 2FA
    logger.info("User '{}' logged in from {} (remember={})", user.username, get_client_ip(request), bool(remember))
    user.last_login_at = datetime.now(timezone.utc).replace(tzinfo=None)
    if config.collect_login_ip:
        user.last_login_ip = get_client_ip(request)

    lifetime = config.session_lifetime_remember if remember else config.session_lifetime
    session_id = str(uuid.uuid4())
    create_or_update_session(db, session_id, {"user_id": user.id}, lifetime)

    redirect_url = next if next and next.startswith("/") else "/"
    response = RedirectResponse(url=redirect_url, status_code=status.HTTP_303_SEE_OTHER)
    response.set_cookie(
        key="session",
        value=session_id,
        max_age=lifetime,
        httponly=True,
        samesite="lax",
    )

    events = getattr(request.app.state, "events", None)
    if events:
        events.emit(
            "user.login",
            source="auth_user",
            user_id=user.id,
            username=user.username,
            ip=get_client_ip(request),
            remember=bool(remember),
        )

    return response


def _complete_login(request: Request, db: Session, user, remember, config: AuthUserConfig):
    """Update user metadata on successful login (shared by normal and 2FA paths)."""
    logger.info("User '{}' logged in from {} (remember={})", user.username, get_client_ip(request), bool(remember))
    user.last_login_at = datetime.now(timezone.utc).replace(tzinfo=None)
    if config.collect_login_ip:
        user.last_login_ip = get_client_ip(request)
    db.commit()


@login_router.get("/login/2fa", name="login_2fa", response_class=HTMLResponse)
async def login_2fa_page(
    request: Request,
    db: Session = Depends(get_db),
    templates=Depends(get_templates),
):
    """Show the 2FA code entry form. Requires a valid pending_2fa cookie."""
    # If user already has a real session, redirect to home
    current_user = getattr(request.state, "current_user", None)
    if current_user and getattr(current_user, "is_authenticated", False):
        return RedirectResponse(url="/", status_code=302)

    pending_id = request.cookies.get("pending_2fa")
    if not pending_id:
        return RedirectResponse(url="/login", status_code=302)

    from ..models import Session as AuthSession
    pending = db.query(AuthSession).filter_by(session_id=pending_id).first()
    if not pending or not pending.session_data.get("pending_2fa_user_id"):
        response = RedirectResponse(url="/login", status_code=302)
        response.delete_cookie("pending_2fa")
        return response

    # Check expiry
    if pending.session_lifetime < datetime.now(timezone.utc).replace(tzinfo=None):
        db.delete(pending)
        db.commit()
        response = RedirectResponse(url="/login", status_code=302)
        response.delete_cookie("pending_2fa")
        return response

    return templates.TemplateResponse(
        "auth_user/totp_verify.html.j2",
        {"request": request},
    )


@login_router.post("/login/2fa", name="login_2fa_post", response_class=HTMLResponse)
async def login_2fa_verify(
    request: Request,
    code: Optional[str] = Form(None),
    db: Session = Depends(get_db),
    templates=Depends(get_templates),
):
    """Verify the 2FA code and complete the login."""
    config = AuthUserConfig()
    pending_id = request.cookies.get("pending_2fa")
    if not pending_id:
        return RedirectResponse(url="/login", status_code=302)

    from ..models import Session as AuthSession
    pending = db.query(AuthSession).filter_by(session_id=pending_id).first()
    if not pending or not pending.session_data.get("pending_2fa_user_id"):
        response = RedirectResponse(url="/login", status_code=302)
        response.delete_cookie("pending_2fa")
        return response

    # Check expiry
    if pending.session_lifetime < datetime.now(timezone.utc).replace(tzinfo=None):
        db.delete(pending)
        db.commit()
        response = RedirectResponse(url="/login?error=expired", status_code=302)
        response.delete_cookie("pending_2fa")
        return response

    # IP-based rate limit on 2FA endpoint
    ip = get_client_ip(request)
    limiter = get_rate_limiter()
    username_from_pending = str(pending.session_data.get("pending_2fa_user_id", "2fa"))
    rate_result = limiter.check_rate_limit(username_from_pending, ip)
    if not rate_result.allowed:
        return templates.TemplateResponse(
            "auth_user/totp_verify.html.j2",
            {"request": request, "error": rate_result.reason},
            status_code=429,
        )

    if not code or not code.strip():
        return templates.TemplateResponse(
            "auth_user/totp_verify.html.j2",
            {"request": request, "error": "Please enter a code"},
            status_code=422,
        )

    # Rate limiting: check attempts
    data = dict(pending.session_data)
    attempts = data.get("attempts", 0)
    if attempts >= config.totp_max_attempts:
        db.delete(pending)
        db.commit()
        logger.warning("2FA rate limit exceeded for user_id={}", data.get("pending_2fa_user_id"))
        response = RedirectResponse(url="/login", status_code=302)
        response.delete_cookie("pending_2fa")
        return response

    user_id = data["pending_2fa_user_id"]
    totp_record = db.query(TwoFactorSecret).filter_by(user_id=user_id, enabled=True).first()
    if not totp_record:
        # 2FA was disabled between login and verify — complete login normally
        db.delete(pending)
        db.commit()
        response = RedirectResponse(url="/login", status_code=302)
        response.delete_cookie("pending_2fa")
        return response

    if not _verify_totp_or_backup(totp_record, code.strip(), db):
        # Increment attempt counter
        data["attempts"] = attempts + 1
        pending.session_data = data
        db.commit()
        remaining = config.totp_max_attempts - data["attempts"]
        error = "Invalid code. Please try again."
        if remaining <= 2:
            error = f"Invalid code. {remaining} attempt(s) remaining."
        return templates.TemplateResponse(
            "auth_user/totp_verify.html.j2",
            {"request": request, "error": error},
            status_code=401,
        )

    # Success — delete pending session, create real session
    remember = data.get("remember", False)
    redirect_url = data.get("next", "/")
    if not redirect_url or not redirect_url.startswith("/"):
        redirect_url = "/"

    db.delete(pending)

    user = db.get(FastPluggyBaseUser, user_id)
    config = AuthUserConfig()
    _complete_login(request, db, user, remember, config)

    lifetime = config.session_lifetime_remember if remember else config.session_lifetime
    session_id = str(uuid.uuid4())
    create_or_update_session(db, session_id, {"user_id": user.id}, lifetime)

    response = RedirectResponse(url=redirect_url, status_code=status.HTTP_303_SEE_OTHER)
    response.set_cookie(key="session", value=session_id, max_age=lifetime, httponly=True, samesite="lax")
    response.delete_cookie("pending_2fa")

    events = getattr(request.app.state, "events", None)
    if events:
        events.emit(
            "user.login",
            source="auth_user",
            user_id=user.id,
            username=user.username,
            ip=get_client_ip(request),
            remember=remember,
        )

    return response


@login_router.get("/logout", name="logout")
async def logout(request: Request):
    current_user = getattr(request.state, "current_user", None)
    events = getattr(request.app.state, "events", None)
    if events and current_user and getattr(current_user, "is_authenticated", False):
        events.emit(
            "user.logout",
            source="auth_user",
            user_id=getattr(current_user, "id", None),
            username=getattr(current_user, "display_name", None),
        )

    response = RedirectResponse(url="/login?signed_out=1", status_code=303)
    response.delete_cookie(key="session")
    return response

