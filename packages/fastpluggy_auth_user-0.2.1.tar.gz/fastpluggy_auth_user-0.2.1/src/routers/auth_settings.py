from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.repository.app_settings import set_app_setting
from fastpluggy.core.widgets import CustomTemplateWidget
from ..config import AuthUserConfig

auth_settings_router = APIRouter(prefix="/admin/auth-settings", tags=["admin"])


@auth_settings_router.get("/", response_class=HTMLResponse)
async def auth_settings_page(
    request: Request,
    view_builder=Depends(get_view_builder),
):
    config = AuthUserConfig()
    return view_builder.generate(
        request,
        title="Auth Settings",
        widgets=[
            CustomTemplateWidget(
                template_name="auth_user/auth_settings.html.j2",
                context={
                    "collect_login_ip": config.collect_login_ip,
                    "allow_api_tokens": config.allow_api_tokens,
                    "allow_self_registration": config.allow_self_registration,
                    "allow_totp": config.allow_totp,
                    "require_totp": config.require_totp,
                },
            )
        ],
    )


@auth_settings_router.post("/", response_class=HTMLResponse)
async def auth_settings_update(
    request: Request,
    db: Session = Depends(get_db),
):
    form_data = await request.form()
    config = AuthUserConfig()
    set_app_setting(db, config, "collect_login_ip", "collect_login_ip" in form_data)
    set_app_setting(db, config, "allow_api_tokens", "allow_api_tokens" in form_data)
    set_app_setting(db, config, "allow_self_registration", "allow_self_registration" in form_data)
    set_app_setting(db, config, "allow_totp", "allow_totp" in form_data)
    set_app_setting(db, config, "require_totp", "require_totp" in form_data)
    FlashMessage.add(request, "Settings saved.", "success")
    return RedirectResponse(url="/admin/auth-settings/", status_code=303)
