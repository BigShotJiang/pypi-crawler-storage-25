from datetime import datetime, timezone
from math import ceil
from typing import Optional

from fastapi import APIRouter, Request, Depends, Query
from sqlalchemy.orm import Session
from starlette.responses import HTMLResponse, RedirectResponse

from fastpluggy.core.database import get_db
from fastpluggy.core.menu.decorator import menu_entry
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.widgets import CustomTemplateWidget
from ..models import LoginAttempt, AccountLockout
from ..rate_limiter import get_rate_limiter

ADMIN_SECURITY_PREFIX = "/admin/security"
PER_PAGE = 50

security_router = APIRouter(
    prefix=ADMIN_SECURITY_PREFIX,
    tags=["admin"],
)


@menu_entry(label="Login Attempts", icon="ti ti-shield-lock", type='admin')
@security_router.get("/attempts", response_class=HTMLResponse)
def login_attempts(
    request: Request,
    db: Session = Depends(get_db),
    view_builder=Depends(get_view_builder),
    username: Optional[str] = Query(default=None),
    ip: Optional[str] = Query(default=None),
    success: Optional[str] = Query(default=None),
    date_from: Optional[str] = Query(default=None),
    date_to: Optional[str] = Query(default=None),
    page: int = Query(default=1, ge=1),
):
    query = db.query(LoginAttempt)

    if username:
        query = query.filter(LoginAttempt.username.ilike(f"%{username}%"))
    if ip:
        query = query.filter(LoginAttempt.ip.ilike(f"%{ip}%"))
    if success == "true":
        query = query.filter(LoginAttempt.success.is_(True))
    elif success == "false":
        query = query.filter(LoginAttempt.success.is_(False))
    if date_from:
        try:
            dt_from = datetime.fromisoformat(date_from)
            query = query.filter(LoginAttempt.attempted_at >= dt_from)
        except ValueError:
            pass
    if date_to:
        try:
            dt_to = datetime.fromisoformat(date_to)
            query = query.filter(LoginAttempt.attempted_at <= dt_to)
        except ValueError:
            pass

    query = query.order_by(LoginAttempt.attempted_at.desc())

    total = query.count()
    total_pages = max(1, ceil(total / PER_PAGE))
    page = min(page, total_pages)
    attempts = query.offset((page - 1) * PER_PAGE).limit(PER_PAGE).all()

    widget = CustomTemplateWidget(
        template_name="auth_user/login_attempts.html.j2",
        context={
            "attempts": attempts,
            "page": page,
            "total_pages": total_pages,
            "total": total,
            "filters": {
                "username": username or "",
                "ip": ip or "",
                "success": success or "",
                "date_from": date_from or "",
                "date_to": date_to or "",
            },
        },
    )

    return view_builder.generate(
        request,
        title="Login Attempts",
        widgets=[widget],
    )


@menu_entry(label="Account Lockouts", icon="ti ti-lock", type='admin')
@security_router.get("/lockouts", response_class=HTMLResponse)
def lockouts(
    request: Request,
    db: Session = Depends(get_db),
    view_builder=Depends(get_view_builder),
):
    all_lockouts = db.query(AccountLockout).order_by(AccountLockout.locked_at.desc()).all()
    active_count = db.query(AccountLockout).filter(AccountLockout.unlocked_at.is_(None)).count()

    widget = CustomTemplateWidget(
        template_name="auth_user/lockouts.html.j2",
        context={
            "lockouts": all_lockouts,
            "active_count": active_count,
        },
    )

    return view_builder.generate(
        request,
        title="Account Lockouts",
        widgets=[widget],
    )


@security_router.post("/lockouts/unlock/{username}")
def unlock_account(
    username: str,
    request: Request,
    db: Session = Depends(get_db),
):
    lockout = db.query(AccountLockout).filter(
        AccountLockout.username == username,
        AccountLockout.unlocked_at.is_(None),
    ).first()

    if not lockout:
        FlashMessage.add(request, f"No active lockout found for '{username}'.", "error")
        return RedirectResponse(f"{ADMIN_SECURITY_PREFIX}/lockouts", status_code=303)

    admin_user = getattr(request.state, "current_user", None)
    admin_name = getattr(admin_user, "display_name", "unknown") if admin_user else "unknown"

    lockout.unlocked_at = datetime.now(timezone.utc).replace(tzinfo=None)
    lockout.unlocked_by = admin_name
    db.commit()

    get_rate_limiter().unlock(username)

    events = getattr(request.app.state, "events", None)
    if events:
        events.emit(
            "user.unlocked",
            source="auth_user",
            username=username,
            unlocked_by=admin_name,
        )

    FlashMessage.add(request, f"Account '{username}' unlocked successfully.", "success")
    return RedirectResponse(f"{ADMIN_SECURITY_PREFIX}/lockouts", status_code=303)
