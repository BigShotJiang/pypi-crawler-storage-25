import base64
from datetime import datetime, timezone
from typing import Optional, Tuple, Type

from fastapi import Request, status, HTTPException
from starlette.authentication import AuthCredentials, BaseUser

from fastpluggy.core.auth.auth_interface import AuthInterface
from fastpluggy.core.database import get_db
from ..models import Session, FastPluggyBaseUser, Token


class SessionAuthManager(AuthInterface):
    login_redirect: bool = True
    login_url: str = "/login"
    logout_url: str = "/logout"

    @property
    def user_model(self) -> Type[FastPluggyBaseUser]:
        return FastPluggyBaseUser

    async def on_authenticate_error(self, request: Request):
        if self.login_redirect:
            from urllib.parse import quote
            next_path = str(request.url.path)
            if request.url.query:
                next_path = f"{next_path}?{request.url.query}"
            redirect = f"{self.login_url}?next={quote(next_path, safe='')}"
            raise HTTPException(
                status_code=status.HTTP_307_TEMPORARY_REDIRECT,
                detail="Not authenticated",
                headers={"Location": redirect},
            )
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    async def authenticate(self, request: Request) -> Optional[Tuple[AuthCredentials, BaseUser]]:
        auth_header = request.headers.get("Authorization", "")

        # Bearer token (API clients using Authorization: Bearer {token})
        if auth_header.startswith("Bearer "):
            return await self._authenticate_token(auth_header[7:])

        # HTTP Basic auth with token (pip/twine: Authorization: Basic base64(__token__:token_value))
        if auth_header.startswith("Basic "):
            try:
                decoded = base64.b64decode(auth_header[6:]).decode("utf-8")
                username, _, password = decoded.partition(":")
                if username == "__token__" and password:
                    return await self._authenticate_token(password)
            except Exception:
                pass

        session_id = request.cookies.get("session")
        if not session_id:
            return None

        db = next(get_db())
        try:
            session_record = db.query(Session).filter(Session.session_id == session_id).first()
            if not session_record:
                return None

            # Check expiry
            if datetime.now(timezone.utc).replace(tzinfo=None) > session_record.session_lifetime:
                db.delete(session_record)
                db.commit()
                return None

            user_id = session_record.session_data.get("user_id")
            if not user_id:
                return None

            user = db.get(self.user_model, user_id)
            if not user:
                return None

            scopes = ["authenticated", "fp_admin"] if user.is_admin else ["authenticated"]
            return AuthCredentials(scopes), user
        finally:
            db.close()

    async def _authenticate_token(self, raw_token: str) -> Optional[Tuple[AuthCredentials, BaseUser]]:
        from ..config import AuthUserConfig
        if not AuthUserConfig().allow_api_tokens:
            return None
        import hashlib
        token_hash = hashlib.sha256(raw_token.encode()).hexdigest()
        db = next(get_db())
        try:
            token = db.query(Token).filter(Token.token_hash == token_hash).first()
            if not token:
                return None
            if token.expires_at and datetime.now(timezone.utc).replace(tzinfo=None) > token.expires_at:
                return None
            token.last_used_at = datetime.now(timezone.utc).replace(tzinfo=None)
            db.commit()
            user = db.get(self.user_model, token.user_id)
            if not user:
                return None
            scopes = ["authenticated", "fp_admin"] if user.is_admin else ["authenticated"]
            return AuthCredentials(scopes), user
        finally:
            db.close()
