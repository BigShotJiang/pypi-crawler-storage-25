from fastpluggy.core.widgets.base import AbstractWidget


class ChangePasswordWidget(AbstractWidget):
    widget_type = "change_password"
    template_name = "auth_user/change_password.html.j2"

    def __init__(self, action: str = "/profile/", **kwargs):
        super().__init__(**kwargs)
        self.action = action

    def process(self, **kwargs):
        pass
