"""HTTP client and Canvas API utilities."""

import asyncio
import weakref
from typing import Any
from urllib.parse import urlencode

import httpx

from .anonymization import anonymize_response_data
from .credentials import get_request_credentials
from .logging import log_debug, log_error, log_warning, sanitize_url

# Rate limit retry configuration
MAX_RETRIES = 3
INITIAL_BACKOFF_SECONDS = 2

# Default number of results per page for paginated requests
DEFAULT_PAGE_SIZE = 100

# HTTP client will be initialized with configuration
http_client: httpx.AsyncClient | None = None
_http_client_loop_ref: "weakref.ref[asyncio.AbstractEventLoop] | None" = None  # weakref to the loop that owns http_client

# Concurrency limiter for outbound Canvas API calls
_request_semaphore: asyncio.Semaphore | None = None
_semaphore_loop_ref: "weakref.ref[asyncio.AbstractEventLoop] | None" = None  # weakref to the loop that owns _request_semaphore


def _get_request_semaphore() -> asyncio.Semaphore:
    """Get or create the concurrency semaphore from config.

    Recreates the semaphore when the running event loop has changed (e.g. after
    asyncio.run() closes one loop and mcp.run() starts a new one) to avoid
    "Event loop is closed" errors on asyncio synchronization primitives.

    A weakref to the creating loop is stored so that when the old loop is
    garbage-collected (as asyncio.run() does), the weakref goes dead and we
    detect the loop change reliably without relying on object id() reuse.
    """
    global _request_semaphore, _semaphore_loop_ref
    try:
        current_loop: asyncio.AbstractEventLoop | None = asyncio.get_running_loop()
    except RuntimeError:
        current_loop = None

    stored_loop = _semaphore_loop_ref() if _semaphore_loop_ref is not None else None

    if _request_semaphore is not None and current_loop is not None and stored_loop is not current_loop:
        _request_semaphore = None
        _semaphore_loop_ref = None

    if _request_semaphore is None:
        from .config import get_config
        _request_semaphore = asyncio.Semaphore(get_config().max_concurrent_requests)
        _semaphore_loop_ref = weakref.ref(current_loop) if current_loop is not None else None
    return _request_semaphore


def _determine_data_type(endpoint: str) -> str:
    """Determine the type of data based on the API endpoint."""
    endpoint_lower = endpoint.lower()

    if '/users' in endpoint_lower:
        return 'users'
    elif '/discussion_topics' in endpoint_lower and '/entries' in endpoint_lower:
        return 'discussions'
    elif '/discussion' in endpoint_lower:
        return 'discussions'
    elif '/submissions' in endpoint_lower:
        return 'submissions'
    elif '/assignments' in endpoint_lower:
        return 'assignments'
    elif '/enrollments' in endpoint_lower:
        return 'users'  # Enrollments contain user data
    else:
        return 'general'


def _should_anonymize_endpoint(endpoint: str) -> bool:
    """Determine if an endpoint should have its data anonymized."""
    # Don't anonymize these endpoints as they don't contain student data
    safe_endpoints = [
        '/courses',  # Course info without student data (unless it includes users)
        '/self',     # User's own profile
        '/accounts', # Account information
        '/terms',    # Academic terms
    ]

    endpoint_lower = endpoint.lower()

    # Always anonymize discussion entries as they contain student posts
    if '/discussion_topics' in endpoint_lower and '/entries' in endpoint_lower:
        return True

    # Check if it's a safe endpoint
    for safe in safe_endpoints:
        if safe in endpoint_lower and '/users' not in endpoint_lower:
            return False

    # Anonymize endpoints that contain student data
    student_data_endpoints = [
        '/users',
        '/discussion',
        '/submissions',
        '/enrollments',
        '/groups',
        '/analytics'
    ]

    return any(student_endpoint in endpoint_lower for student_endpoint in student_data_endpoints)


def _get_http_client() -> httpx.AsyncClient:
    """Get or create the HTTP client with current configuration.

    Recreates the client when the running event loop has changed (e.g. after
    asyncio.run() closes one loop and mcp.run() starts a new one).  The stale
    client's internal anyio/asyncio connection-pool primitives are tied to the
    closed loop and will raise "Event loop is closed" on the first use.

    A weakref to the creating loop is stored so that when the old loop is
    garbage-collected (as asyncio.run() does), the weakref goes dead and we
    detect the loop change reliably without relying on object id() reuse.
    """
    global http_client, _http_client_loop_ref
    try:
        current_loop: asyncio.AbstractEventLoop | None = asyncio.get_running_loop()
    except RuntimeError:
        current_loop = None

    stored_loop = _http_client_loop_ref() if _http_client_loop_ref is not None else None

    if http_client is not None and (
        http_client.is_closed
        or (current_loop is not None and stored_loop is not current_loop)
    ):
        http_client = None
        _http_client_loop_ref = None

    if http_client is None:
        from .. import __version__
        from .config import get_config
        config = get_config()
        http_client = httpx.AsyncClient(
            headers={
                'Authorization': f'Bearer {config.api_token}',
                'User-Agent': f'canvas-mcp/{__version__} (https://github.com/vishalsachdev/canvas-mcp)'
            },
            timeout=config.api_timeout
        )
        _http_client_loop_ref = weakref.ref(current_loop) if current_loop is not None else None
    return http_client


async def cleanup_http_client() -> None:
    """Close the HTTP client and release resources."""
    global http_client
    if http_client is not None:
        await http_client.aclose()
        http_client = None


async def make_canvas_request(
    method: str,
    endpoint: str,
    params: dict[str, Any] | None = None,
    data: dict[str, Any] | None = None,
    use_form_data: bool = False,
    skip_anonymization: bool = False
) -> Any:
    """Make a request to the Canvas API with proper error handling.

    Automatically retries on rate limit errors (429) with exponential backoff.

    Args:
        method: HTTP method (get, post, put, delete)
        endpoint: Canvas API endpoint
        params: Query parameters
        data: Request body data
        use_form_data: Use form data instead of JSON
        skip_anonymization: Skip anonymization (used by paginated fetchers)
    """

    from .audit import log_data_access
    from .config import get_config

    config = get_config()

    # Check for per-request credentials (HTTP transport mode)
    req_creds = get_request_credentials()

    # Ensure the endpoint starts with a slash
    if not endpoint.startswith('/'):
        endpoint = f"/{endpoint}"

    if req_creds:
        # Per-request client with user's credentials (HTTP mode)
        from .. import __version__

        client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {req_creds.api_token}",
                "User-Agent": f"canvas-mcp/{__version__} (https://github.com/vishalsachdev/canvas-mcp)",
            },
            timeout=config.api_timeout,
        )
        url = f"{req_creds.api_url.rstrip('/')}{endpoint}"
        _close_client = True
    else:
        # Global client (stdio mode)
        client = _get_http_client()
        url = f"{config.api_base_url.rstrip('/')}{endpoint}"
        _close_client = False

    # Gate outbound calls with concurrency semaphore (uses MAX_CONCURRENT_REQUESTS)
    semaphore = _get_request_semaphore()
    async with semaphore:
        # Retry loop for rate limiting
        try:
            for attempt in range(MAX_RETRIES + 1):
                try:
                    # Log the request for debugging (if enabled)
                    if config.log_api_requests:
                        retry_info = f" (retry {attempt}/{MAX_RETRIES})" if attempt > 0 else ""
                        log_debug(f"Making {method.upper()} request to {sanitize_url(url)}{retry_info}")

                    if method.lower() == "get":
                        response = await client.get(url, params=params)
                    elif method.lower() == "post":
                        if use_form_data:
                            # Handle list of tuples separately to work around httpx async bug
                            # with duplicate keys (e.g., module[prerequisite_module_ids][])
                            if isinstance(data, list):
                                encoded = urlencode(data)
                                response = await client.post(
                                    url,
                                    content=encoded,
                                    headers={"Content-Type": "application/x-www-form-urlencoded"}
                                )
                            else:
                                response = await client.post(url, data=data)
                        else:
                            response = await client.post(url, json=data)
                    elif method.lower() == "put":
                        if use_form_data:
                            # Handle list of tuples separately to work around httpx async bug
                            if isinstance(data, list):
                                encoded = urlencode(data)
                                response = await client.put(
                                    url,
                                    content=encoded,
                                    headers={"Content-Type": "application/x-www-form-urlencoded"}
                                )
                            else:
                                response = await client.put(url, data=data)
                        else:
                            response = await client.put(url, json=data)
                    elif method.lower() == "delete":
                        response = await client.delete(url, params=params)
                    else:
                        return {"error": f"Unsupported method: {method}"}

                    response.raise_for_status()
                    result = response.json()

                    # Apply anonymization if enabled and this endpoint contains student data
                    # Skip if explicitly requested (e.g., from paginated fetcher that will anonymize the full result)
                    if not skip_anonymization and config.enable_data_anonymization and _should_anonymize_endpoint(endpoint):
                        data_type = _determine_data_type(endpoint)
                        result = anonymize_response_data(result, data_type)

                        # Log anonymization for debugging (if enabled)
                        if config.anonymization_debug:
                            log_debug(f"Applied {data_type} anonymization to {endpoint}")

                    # Audit: log successful data access
                    log_data_access(method, endpoint, "success")

                    return result

                except httpx.HTTPStatusError as e:
                    # Handle rate limiting with exponential backoff
                    if e.response.status_code == 429 and attempt < MAX_RETRIES:
                        # Check for Retry-After header
                        retry_after = e.response.headers.get('Retry-After')
                        if retry_after:
                            try:
                                wait_time = int(retry_after)
                            except ValueError:
                                wait_time = INITIAL_BACKOFF_SECONDS * (2 ** attempt)
                        else:
                            wait_time = INITIAL_BACKOFF_SECONDS * (2 ** attempt)

                        log_warning(f"Rate limited (429). Retrying in {wait_time}s...", attempt=attempt + 1, max_retries=MAX_RETRIES)
                        await asyncio.sleep(wait_time)
                        continue

                    # Not a rate limit error or out of retries - format and return error
                    error_message = f"HTTP error: {e.response.status_code}"
                    try:
                        error_details = e.response.json()
                        error_message += f", Details: {error_details}"
                    except ValueError:
                        error_details = e.response.text
                        error_message += f", Text: {error_details}"

                    log_error(f"API error on {sanitize_url(endpoint)}", status_code=e.response.status_code)

                    # Audit: log HTTP error (status code only — response body may contain PII)
                    log_data_access(method, endpoint, "error", f"HTTP {e.response.status_code}")

                    return {"error": error_message}

                except Exception as e:
                    log_error(f"Request failed for {sanitize_url(endpoint)}", error_type=type(e).__name__)

                    # Audit: log request exception (type only — message may contain PII)
                    log_data_access(method, endpoint, "error", type(e).__name__)

                    return {"error": f"Request failed: {str(e)}"}

            # Should never reach here, but just in case
            return {"error": "Max retries exceeded"}
        finally:
            if _close_client:
                await client.aclose()


async def upload_file_to_storage(
    upload_url: str,
    upload_params: dict[str, Any],
    file_path: str,
    filename: str,
    content_type: str
) -> dict[str, Any]:
    """Upload a file to Canvas storage URL (step 2 of 3-step upload process).

    This function handles the multipart file upload to S3/Instructure storage.
    It's called after requesting an upload URL from the Canvas API.

    Args:
        upload_url: The pre-signed upload URL from Canvas API
        upload_params: Additional parameters required by the storage (from Canvas API)
        file_path: Local filesystem path to the file
        filename: Name to use for the uploaded file
        content_type: MIME type of the file

    Returns:
        Response from the storage service, typically containing file confirmation
        or redirect location

    Note:
        This posts to external storage (S3/Instructure), not the Canvas API.
        The response handling differs from regular Canvas API calls.
    """
    from .config import get_config

    config = get_config()

    # Create a separate client for external uploads (no auth header needed)
    async with httpx.AsyncClient(timeout=config.api_timeout) as client:
        try:
            # Read the file content
            with open(file_path, 'rb') as f:
                file_content = f.read()

            # Build multipart form data
            # upload_params contains required fields like 'key', 'Policy', 'Signature', etc.
            files = {
                'file': (filename, file_content, content_type)
            }

            # Log for debugging
            if config.log_api_requests:
                log_debug(f"Uploading file to storage: {upload_url}", filename=filename, content_type=content_type, size=len(file_content))

            # Make the upload request
            # Note: follow_redirects=False because Canvas may return a 3xx with file info
            response = await client.post(
                upload_url,
                data=upload_params,
                files=files,
                follow_redirects=False
            )

            # Canvas storage upload can return:
            # - 200/201 with JSON body containing file info
            # - 301/302/303 redirect to Canvas API with file info
            if response.status_code in (200, 201):
                # Direct success response
                try:
                    return response.json()
                except ValueError:
                    # Some storage backends return empty success
                    return {"success": True, "status_code": response.status_code}

            elif response.status_code in (301, 302, 303):
                # Redirect - follow it to get file info from Canvas
                redirect_url = response.headers.get('Location')
                if redirect_url:
                    # Follow the redirect to get file info
                    # This goes back to Canvas API, needs auth
                    req_creds = get_request_credentials()
                    if req_creds:
                        from .. import __version__

                        async with httpx.AsyncClient(
                            headers={
                                "Authorization": f"Bearer {req_creds.api_token}",
                                "User-Agent": f"canvas-mcp/{__version__} (https://github.com/vishalsachdev/canvas-mcp)",
                            },
                            timeout=config.api_timeout,
                        ) as canvas_client:
                            confirm_response = await canvas_client.get(redirect_url)
                            confirm_response.raise_for_status()
                            return confirm_response.json()
                    else:
                        canvas_client = _get_http_client()
                        confirm_response = await canvas_client.get(redirect_url)
                        confirm_response.raise_for_status()
                        return confirm_response.json()
                else:
                    return {"error": "Redirect without Location header"}

            else:
                # Unexpected status
                error_text = response.text
                return {
                    "error": f"Storage upload failed with status {response.status_code}",
                    "details": error_text
                }

        except FileNotFoundError:
            return {"error": f"File not found: {file_path}"}
        except PermissionError:
            return {"error": f"Permission denied reading file: {file_path}"}
        except httpx.TimeoutException:
            return {"error": "Upload timed out"}
        except Exception as e:
            return {"error": f"Upload failed: {str(e)}"}


async def fetch_all_paginated_results(endpoint: str, params: dict[str, Any] | None = None) -> Any:
    """Fetch all results from a paginated Canvas API endpoint.

    Handles pagination automatically and applies anonymization once to the complete dataset
    to ensure consistent anonymization across all pages.
    """
    if params is None:
        params = {}

    # Ensure we get a reasonable number per page
    if "per_page" not in params:
        params["per_page"] = 100

    all_results: list[Any] = []
    page = 1

    while True:
        current_params = {**params, "page": page}
        # Skip anonymization on individual pages - we'll anonymize the complete dataset
        response = await make_canvas_request("get", endpoint, params=current_params, skip_anonymization=True)

        if isinstance(response, dict) and "error" in response:
            log_error(f"Error fetching page {page}", error=response['error'])
            return response

        if not response or not isinstance(response, list) or len(response) == 0:
            break

        all_results.extend(response)

        # If we got fewer results than requested per page, we're done
        if len(response) < params.get("per_page", 100):
            break

        page += 1

    # Apply anonymization to the complete result set if needed
    from .config import get_config
    config = get_config()

    if config.enable_data_anonymization and _should_anonymize_endpoint(endpoint):
        data_type = _determine_data_type(endpoint)
        all_results = anonymize_response_data(all_results, data_type)

        if config.anonymization_debug:
            log_debug(f"Applied {data_type} anonymization to paginated results from {endpoint}")

    return all_results
