# Copyright 2026 OpenSynergy Indonesia
# Copyright 2026 PT. Simetri Sinergi Indonesia
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl-3.0-standalone.html).
# pylint: disable=C8101
{
    "name": "Letter Management - Documenso Signing Integration",
    "version": "14.0.1.2.0",
    "website": "https://simetri-sinergi.id",
    "author": "OpenSynergy Indonesia, PT. Simetri Sinergi Indonesia",
    "license": "AGPL-3",
    "installable": True,
    "depends": [
        "ssi_letter",
        "ssi_connector_documenso_signing",
    ],
    "data": [],
    "demo": [],
    "images": [],
    "contributors": [
        "Andhitia Rama <andhitia.r@gmail.com>",
    ],
}
