# cyberxyz-scanner

CyberXYZ Security CLI. Real-time supply-chain protection for npm, PyPI, Go and .NET (NuGet) on macOS, Linux and Windows.

[![PyPI version](https://img.shields.io/pypi/v/cyberxyz-scanner.svg)](https://pypi.org/project/cyberxyz-scanner/)
[![Python](https://img.shields.io/pypi/pyversions/cyberxyz-scanner.svg)](https://pypi.org/project/cyberxyz-scanner/)
[![License](https://img.shields.io/badge/license-Proprietary-blue.svg)](LICENSE)

The CLI pairs with the CyberXYZ platform to give you per-machine package inventory, proxy
enforcement on every `npm install` / `pip install`, and CI/CD gating on flagged
dependencies. It is the implementer's interface to a platform that also exposes the same
controls in a web dashboard.

## Install

The package is published on PyPI as `cyberxyz-scanner`. The CLI binary it installs is named
`xyz`.

### With pip

```bash
pip install cyberxyz-scanner
```

### With uv

```bash
uv pip install cyberxyz-scanner
```

Verify the install:

```bash
xyz --help
```

## Quick start (one-time per machine)

```bash
# 1. Browser-based login. Stores a JWT in ~/.xyz/config.json
xyz login

# 2. Enroll this machine. Single command does all of:
#    - Registers the device server-side
#    - Writes the proxy token to ~/.npmrc
#    - Configures pip's global index URL
#    - Installs the OS service for dashboard "Scan now" support
#      (LaunchAgent on macOS, systemd --user on Linux, Task Scheduler on Windows)
xyz proxy setup --machine-name "Alex's MacBook"
```

That's it. Every subsequent `npm install` and `pip install` on this device is checked
through the CyberXYZ proxy, and the dashboard's "Scan now" button can trigger a fresh
inventory audit on demand.

For environments that should not run a long-running background process (CI build agents,
sealed builds), pass `--no-install-daemon`.

## Audit installed packages

Each command below audits the matching ecosystem on this machine, runs the CyberXYZ
watchlist + deep check on suspect packages, and uploads the full inventory to the
platform.

```bash
xyz audit npm                  # local + global node_modules
xyz audit python               # active Python environment via pip
xyz audit go                   # $GOPATH module cache
xyz audit nuget                # packages.lock.json files under cwd
xyz audit                      # npm + python + go back-to-back
```

By default each command uses the watchlist pre-filter for speed (~25-40s on a typical
machine). Pass `--full` to skip the pre-filter and deep-check every package (slower but
covers advisory-only matches at scan time).

## Other useful commands

```bash
# One-off safety check on a single package + version
xyz check axios 1.14.1 -e npm

# CI/CD gate. Drops a non-zero exit on flagged packages.
xyz depalert scan --package-lock package-lock.json --fail-on block
xyz depalert scan --requirements requirements.txt --fail-on quarantine
xyz depalert scan -p axios@1.14.1 -p lodash@4.17.21

# SBOM upload (CycloneDX or SPDX)
xyz inventory upload ./my-app
xyz inventory upload --sbom syft.json

# Diagnostic / housekeeping
xyz proxy status               # show current npm + pip proxy config
xyz proxy whoami               # what (org, machine) does my token resolve to
xyz proxy remove               # restore default registries on this machine
xyz scans list                 # history of recent scans for your org
xyz upgrade                    # pull the latest release from PyPI
```

## CI/CD integrations

Drop one of the templates below into your repo, set `XYZ_API_KEY` as a secret, and any
push or PR that pulls in a malicious or vulnerable package will fail the build with a
clear reason.

* GitHub Actions: `.github/workflows/xyz-depalert.yml` (template in the
  `XYZ-APT-Scanner` repo)
* Azure DevOps Pipelines: `integrations/azure-pipelines/cyberxyz-supply-chain.yml`

Both run the same `xyz depalert scan` engine your laptops use.

## Re-enroll, rotate, remove

To rotate the proxy token on a device, just re-run `xyz proxy setup --machine-name "..."`.
The platform revokes the old token and writes a fresh one. The daemon picks it up at next
restart.

To remove a device cleanly, delete it from the dashboard Fleet view. The deletion sweeps
proxy_install_log, proxy_tokens, cli_scans, customer_inventory_uploads,
customer_package_inventory and scan_jobs in one transaction. Re-enroll with the same
command above.

## Platform

* Dashboard: <https://app.cyberxyz.io>
* Documentation: <https://cyberxyz.io>

## License

Proprietary. See [LICENSE](LICENSE).

## Contact

Email: amro@cyberxyz.io
