import json
import logging
import os
import time
from collections.abc import Callable
from logging import Logger
from pathlib import Path
from typing import Any

import yaml
from colorlog import ColoredFormatter

from custom_python_logger.consts import LOG_COLORS, CustomLoggerLevel

CUSTOM_LOGGER = "custom_logger"


def json_pretty_format(data: Any, indent: int = 4, sort_keys: bool = True, default: Callable | None = None) -> str:
    return json.dumps(data, indent=indent, sort_keys=sort_keys, default=default)


def yaml_pretty_format(data: Any, indent: int = 4, sort_keys: bool = False, allow_unicode: bool = True) -> str:
    return yaml.dump(data, sort_keys=sort_keys, indent=indent, allow_unicode=allow_unicode)


def get_project_path_by_file(markers: set[str] | None = None) -> Path:
    markers = markers or {".git", "setup.py", "pyproject.toml", "LICENSE", "README.md"}
    path = Path(__file__).resolve() if "__file__" in globals() else Path.cwd().resolve()

    for marker in markers:
        if (path / marker).exists():
            return path

    for parent in path.parents:
        for marker in markers:
            if (parent / marker).exists():
                return parent
    raise RuntimeError(f'Project root with one of the markers: "{markers}" not found.')


def print_before_logger(project_name: str, sleep_time: float = 0.3) -> None:
    main_string = f'Start "{project_name}" Process'

    number_of_ladder = "#" * len(f"### {main_string} ###")
    print(f"\n{number_of_ladder}")
    print(f"### {main_string} ###")
    print(f"{number_of_ladder}\n")
    time.sleep(sleep_time)


class CustomLoggerAdapter(logging.LoggerAdapter):
    def exception(self, msg: str, *args: Any, **kwargs: Any) -> None:
        logging.addLevelName(CustomLoggerLevel.EXCEPTION.value, "EXCEPTION")
        kwargs.setdefault("stacklevel", 2)
        self.log(CustomLoggerLevel.EXCEPTION.value, msg, *args, exc_info=True, **kwargs)

    def step(self, msg: str, *args: Any, **kwargs: Any) -> None:
        logging.addLevelName(CustomLoggerLevel.STEP.value, "STEP")
        kwargs.setdefault("stacklevel", 2)
        self.log(CustomLoggerLevel.STEP.value, msg, *args, exc_info=False, **kwargs)

    def success(self, msg: str, *args: Any, **kwargs: Any) -> None:
        logging.addLevelName(CustomLoggerLevel.SUCCESS.value, "SUCCESS")
        kwargs.setdefault("stacklevel", 2)
        self.log(CustomLoggerLevel.SUCCESS.value, msg, *args, **kwargs)

    def alert(self, msg: str, *args: Any, **kwargs: Any) -> None:
        logging.addLevelName(CustomLoggerLevel.ALERT.value, "ALERT")
        kwargs.setdefault("stacklevel", 2)
        self.log(CustomLoggerLevel.ALERT.value, msg, *args, **kwargs)

    def trace(self, msg: str, *args: Any, **kwargs: Any) -> None:
        logging.addLevelName(CustomLoggerLevel.TRACE.value, "TRACE")
        kwargs.setdefault("stacklevel", 2)
        self.log(CustomLoggerLevel.TRACE.value, msg, *args, **kwargs)


def clear_existing_handlers(logger: Logger) -> None:
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)


def add_file_handler(logger: Logger, log_file_path: str | None, log_format: str) -> None:
    if log_file_path is not None:
        log_file_formatter = logging.Formatter(log_format)

        if log_dir := os.path.dirname(log_file_path):
            os.makedirs(log_dir, exist_ok=True)

        file_handler = logging.FileHandler(log_file_path)
        file_handler.setFormatter(log_file_formatter)
        logger.addHandler(file_handler)


def add_console_handler(logger: Logger, log_format: str) -> None:
    log_console_formatter = ColoredFormatter(
        "%(log_color)s " + log_format,
        log_colors=LOG_COLORS,
    )

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_console_formatter)
    logger.addHandler(console_handler)


def get_logger(name: str, log_level: int | None = None, extra: dict | None = None) -> CustomLoggerAdapter:
    custom_logger = logging.getLogger(CUSTOM_LOGGER)
    full_name = f"{CUSTOM_LOGGER}.{name}"
    new_logger = CustomLoggerAdapter(logging.getLogger(full_name), extra=extra)

    if log_level is None:
        log_level = custom_logger.level
    new_logger.setLevel(log_level)

    return new_logger


def build_logger(  # pylint: disable=R0913
    project_name: str,
    extra: dict[str, Any] | None = None,
    log_format: str = "%(asctime)s | %(levelname)-9s | l.%(levelno)s | %(name)s | %(filename)s:%(lineno)s | %(message)s",  # pylint: disable=C0301
    log_level: int = logging.DEBUG,
    log_file: bool = False,
    log_file_path: str | None = None,
    console_output: bool = True,
    utc: bool = False,
) -> CustomLoggerAdapter:
    """
    Configure global logging settings and get a named logger with optional extra context.

    Args:
        project_name: Name of the project
        log_level: Optional specific log level
        extra: Optional dictionary of extra context values
        log_format: Format string for log messages
        log_file: Whether to log to a file
        log_file_path: Path to log file (if None, no file logging)
        console_output: Whether to output logs to console
        utc: Whether to use UTC time for log timestamps
    Returns:
        Configured logger
    """

    if utc:
        logging.Formatter.converter = time.gmtime

    root_logger = logging.getLogger()
    clear_existing_handlers(logger=root_logger)

    if console_output:
        add_console_handler(logger=root_logger, log_format=log_format)

    if log_file:
        if not log_file_path:
            log_file_path = f"{get_project_path_by_file()}/logs/{project_name}.log"
            log_file_path = log_file_path.lower().replace(" ", "_")
        add_file_handler(logger=root_logger, log_file_path=log_file_path, log_format=log_format)

    logger = CustomLoggerAdapter(logging.getLogger(CUSTOM_LOGGER), extra)
    logger.setLevel(log_level)

    return get_logger(project_name)
