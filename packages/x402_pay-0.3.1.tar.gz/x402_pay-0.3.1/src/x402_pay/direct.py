"""DirectClient — wallet-based direct x402 payment.

Power-user mode: pay upstream APIs directly from your own wallet.
No broker, no API key — just on-chain micropayments.

Requires: pip install x402-pay[wallet]
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import httpx


class DirectClient:
    """Call any x402 API directly with your own wallet.

    Usage::

        async with DirectClient(private_key="0x...") as client:
            resp = await client.get("https://weather.hugen.tokyo/weather/current?city=Tokyo")
            print(resp.json())
    """

    def __init__(
        self,
        private_key: str,
        timeout: float = 60.0,
    ):
        self._private_key = private_key
        self._timeout = timeout
        self._http: httpx.AsyncClient | None = None

    async def _ensure_init(self):
        if self._http is not None:
            return

        try:
            import httpx as _httpx
            from eth_account import Account
            from x402 import x402Client
            from x402.http.clients import x402HttpxClient
            from x402.mechanisms.evm import EthAccountSigner
            from x402.mechanisms.evm.exact.register import register_exact_evm_client
        except ImportError as exc:
            raise ImportError(
                "DirectClient requires wallet dependencies. "
                "Install with: pip install x402-pay[wallet]"
            ) from exc

        account = Account.from_key(self._private_key)
        client = x402Client()
        register_exact_evm_client(client, EthAccountSigner(account))

        self._http = x402HttpxClient(client, timeout=_httpx.Timeout(self._timeout))
        await self._http.__aenter__()

    async def get(self, url: str, **kwargs):
        """Send a GET request with x402 auto-payment."""
        await self._ensure_init()
        assert self._http is not None
        return await self._http.get(url, **kwargs)

    async def post(self, url: str, **kwargs):
        """Send a POST request with x402 auto-payment."""
        await self._ensure_init()
        assert self._http is not None
        return await self._http.post(url, **kwargs)

    async def __aenter__(self):
        await self._ensure_init()
        return self

    async def __aexit__(self, *exc):
        await self.close()

    async def close(self):
        if self._http:
            await self._http.__aexit__(None, None, None)
            self._http = None
