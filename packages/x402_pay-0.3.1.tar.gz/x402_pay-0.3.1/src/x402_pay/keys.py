"""API key management — create, check balance, top up."""

from __future__ import annotations

import httpx

from . import config
from .exceptions import KeyError_, PayError


async def create_key(
    label: str = "x402-pay-auto",
    *,
    client: httpx.AsyncClient | None = None,
) -> dict:
    """Create a new API key with trial balance.

    Returns dict with 'key', 'balance_usd', etc.
    """
    base = config.get_broker_url()
    url = f"{base}/keys/create"
    params = {"label": label} if label else {}

    close = False
    if client is None:
        client = httpx.AsyncClient(timeout=30)
        close = True
    try:
        r = await client.post(url, params=params)
        r.raise_for_status()
        return r.json()
    except httpx.HTTPStatusError as exc:
        raise PayError(f"Key creation failed: {exc.response.status_code} {exc.response.text[:200]}") from exc
    finally:
        if close:
            await client.aclose()


async def get_balance(
    key: str = "",
    *,
    client: httpx.AsyncClient | None = None,
) -> dict:
    """Check API key balance and usage stats."""
    key = key or config.get_api_key()
    if not key:
        raise KeyError_("No API key configured. Call create_key() or set X402_API_KEY env var.")

    base = config.get_broker_url()
    url = f"{base}/keys/balance"

    close = False
    if client is None:
        client = httpx.AsyncClient(timeout=30)
        close = True
    try:
        r = await client.get(url, params={"key": key})
        if r.status_code == 404:
            raise KeyError_(f"Key not found: {key[:12]}...")
        r.raise_for_status()
        return r.json()
    finally:
        if close:
            await client.aclose()


async def ensure_key(*, client: httpx.AsyncClient | None = None) -> str:
    """Return existing API key, or auto-create one and save it.

    This is the key provisioning logic used by PayClient on first use.
    """
    existing = config.get_api_key()
    if existing:
        return existing

    result = await create_key(client=client)
    key = result["key"]
    config.set_api_key(key)
    return key
