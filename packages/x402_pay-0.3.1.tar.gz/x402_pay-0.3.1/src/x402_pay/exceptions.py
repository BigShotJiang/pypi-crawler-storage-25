"""x402-pay exceptions."""


class PayError(Exception):
    """Base exception for x402-pay."""


class InsufficientBalance(PayError):
    """API key balance too low for the requested call."""

    def __init__(self, balance: float, needed: float, topup_url: str = ""):
        self.balance = balance
        self.needed = needed
        self.topup_url = topup_url
        super().__init__(
            f"Insufficient balance: ${balance:.4f} < ${needed:.4f}"
            + (f" — top up at {topup_url}" if topup_url else "")
        )


class NotInCatalog(PayError):
    """URL not found in the x402 API catalog."""

    def __init__(self, url: str):
        self.url = url
        super().__init__(f"URL not in catalog: {url}")


class BrokerError(PayError):
    """Upstream API call failed via broker."""

    def __init__(self, message: str, refunded: bool = False):
        self.refunded = refunded
        super().__init__(message)


class KeyError_(PayError):
    """API key is invalid or inactive."""

    def __init__(self, message: str = "Invalid or inactive API key"):
        super().__init__(message)
