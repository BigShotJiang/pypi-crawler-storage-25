"""Synchronous convenience wrappers for x402-pay.

For scripts that don't use async/await. Runs the event loop internally.

Usage::

    import x402_pay

    resp = x402_pay.get("https://weather.hugen.tokyo/weather/current?city=Tokyo")
    print(resp.json())
"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx


def _run_async(coro):
    """Run an async coroutine from synchronous code.

    Handles the case where an event loop is already running (e.g., Jupyter)
    by creating a new thread with its own loop.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is None:
        # No running loop — standard case (scripts, CLI)
        return asyncio.run(coro)
    else:
        # Loop already running (Jupyter, nested async) — run in a new thread
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result(timeout=120)


def get(url: str, *, api_key: str = "", broker_url: str = "", **kwargs: Any) -> httpx.Response:
    """Synchronous GET through the x402 broker.

    Auto-provisions an API key on first use.

    Args:
        url: Target x402 API URL.
        api_key: Optional explicit API key. Auto-created if omitted.
        broker_url: Optional broker URL override.
        **kwargs: Passed to httpx GET request.

    Returns:
        httpx.Response from the upstream API.

    Raises:
        InsufficientBalance: Key balance too low.
        NotInCatalog: URL not in x402 catalog.
        BrokerError: Upstream call failed.
    """
    from .client import PayClient

    async def _do():
        async with PayClient(api_key=api_key, broker_url=broker_url) as client:
            return await client.get(url, **kwargs)

    return _run_async(_do())


def post(url: str, *, api_key: str = "", broker_url: str = "", **kwargs: Any) -> httpx.Response:
    """Synchronous POST through the x402 broker.

    Auto-provisions an API key on first use.

    Args:
        url: Target x402 API URL.
        api_key: Optional explicit API key. Auto-created if omitted.
        broker_url: Optional broker URL override.
        **kwargs: Passed to httpx POST request (e.g., json={...}).

    Returns:
        httpx.Response from the upstream API.

    Raises:
        InsufficientBalance: Key balance too low.
        NotInCatalog: URL not in x402 catalog.
        BrokerError: Upstream call failed.
    """
    from .client import PayClient

    async def _do():
        async with PayClient(api_key=api_key, broker_url=broker_url) as client:
            return await client.post(url, **kwargs)

    return _run_async(_do())


def discover(query: str, *, limit: int = 5, api_key: str = "", broker_url: str = "") -> list[dict]:
    """Search the x402 API catalog. Returns list of matching APIs.

    Usage::

        import x402_pay

        apis = x402_pay.discover("weather")
        if apis:
            resp = x402_pay.get(apis[0]["url"])
            print(resp.json())

    Args:
        query: Search keywords (e.g., "weather", "defi token security").
        limit: Max results (1-20).
        api_key: Optional explicit API key.
        broker_url: Optional broker URL override.

    Returns:
        List of dicts with url, description, price, brokerable, call_hint.
    """
    from .client import PayClient

    async def _do():
        async with PayClient(api_key=api_key, broker_url=broker_url) as client:
            return await client.discover(query, limit=limit)

    return _run_async(_do())


def balance(api_key: str = "", broker_url: str = "") -> float:
    """Synchronous balance check.

    Args:
        api_key: API key to check. Uses saved key if omitted.
        broker_url: Optional broker URL override.

    Returns:
        Balance in USD.
    """
    from .client import PayClient

    async def _do():
        async with PayClient(api_key=api_key, broker_url=broker_url) as client:
            return await client.balance()

    return _run_async(_do())
