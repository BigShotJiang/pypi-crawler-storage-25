"""PayClient — the main entry point for x402-pay.

API key mode: routes all requests through the broker REST API.
No wallet, no on-chain transactions, no crypto dependencies needed.
"""

from __future__ import annotations

import httpx

from . import config
from .keys import ensure_key, get_balance
from .transport import BrokerTransport


class PayClient:
    """Call any x402 API with just an API key — no wallet needed.

    Auto-provisions a key with $0.05 trial balance on first use.

    Usage::

        async with PayClient() as client:
            resp = await client.get("https://weather.hugen.tokyo/weather/current?city=Tokyo")
            print(resp.json())
            print(f"Balance: ${await client.balance():.2f}")
    """

    def __init__(
        self,
        api_key: str = "",
        broker_url: str = "",
        timeout: float = 60.0,
    ):
        self._api_key = api_key
        self._broker_url = broker_url or config.get_broker_url()
        self._timeout = timeout
        self._transport: BrokerTransport | None = None
        self._client: httpx.AsyncClient | None = None

    async def _ensure_init(self):
        """Lazy init: provision key + create transport on first use."""
        if self._client is not None:
            return

        if not self._api_key:
            self._api_key = await ensure_key()

        self._transport = BrokerTransport(
            api_key=self._api_key,
            broker_url=self._broker_url,
            timeout=self._timeout,
        )
        self._client = httpx.AsyncClient(transport=self._transport)

    async def get(self, url: str, **kwargs) -> httpx.Response:
        """Send a GET request through the broker."""
        await self._ensure_init()
        assert self._client is not None
        return await self._client.get(url, **kwargs)

    async def post(self, url: str, **kwargs) -> httpx.Response:
        """Send a POST request through the broker."""
        await self._ensure_init()
        assert self._client is not None
        return await self._client.post(url, **kwargs)

    async def balance(self) -> float:
        """Check current API key balance in USD."""
        if not self._api_key:
            self._api_key = await ensure_key()
        info = await get_balance(self._api_key)
        return info.get("balance_usd", 0.0)

    async def topup_url(self) -> str:
        """Return the URL to top up this API key.

        The URL accepts a $1.00 x402 payment (USDC on Base) and credits
        $1.00 to the key balance (~100 broker calls at $0.01 each).

        Returns:
            HTTPS URL for the topup endpoint with key parameter.
        """
        if not self._api_key:
            self._api_key = await ensure_key()
        return f"{self._broker_url}/keys/topup?key={self._api_key}"

    async def discover(self, query: str, limit: int = 5) -> list[dict]:
        """Search the x402 API catalog and return matching APIs.

        Returns a list of dicts with url, description, price, brokerable, call_hint.
        Uses the discovery search endpoint directly (not via broker).

        Usage::

            async with PayClient() as client:
                apis = await client.discover("weather")
                if apis:
                    resp = await client.get(apis[0]["url"])
                    print(resp.json())
        """
        await self._ensure_init()
        # Direct call to discovery API (not through broker transport)
        async with httpx.AsyncClient() as direct:
            resp = await direct.get(
                f"{self._broker_url}/discovery/search",
                params={"q": query, "limit": limit},
                headers={"X-API-Key": self._api_key},
            )
        data = resp.json()
        return data.get("results", [])

    @property
    def api_key(self) -> str:
        """Return the current API key (may be empty before first call)."""
        return self._api_key

    async def __aenter__(self):
        await self._ensure_init()
        return self

    async def __aexit__(self, *exc):
        await self.close()

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None
        if self._transport:
            await self._transport.aclose()
            self._transport = None
