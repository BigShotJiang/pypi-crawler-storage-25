"""x402-pay local configuration management.

Stores API key and settings in ~/.x402-pay/config.json.
"""

import json
import os
from pathlib import Path

_DEFAULTS = {
    "broker_url": "https://discovery.hugen.tokyo",
    "api_key": "",
}


def _config_dir() -> Path:
    return Path(os.getenv("X402_PAY_CONFIG_DIR", "~/.x402-pay")).expanduser()


def _config_file() -> Path:
    return _config_dir() / "config.json"


def _ensure_dir():
    _config_dir().mkdir(parents=True, exist_ok=True)


def load() -> dict:
    """Load config, returning defaults if file doesn't exist."""
    cf = _config_file()
    if not cf.exists():
        return dict(_DEFAULTS)
    try:
        with open(cf) as f:
            data = json.load(f)
        merged = dict(_DEFAULTS)
        merged.update(data)
        return merged
    except (json.JSONDecodeError, OSError):
        return dict(_DEFAULTS)


def save(config: dict):
    """Persist config to disk."""
    _ensure_dir()
    cf = _config_file()
    with open(cf, "w") as f:
        json.dump(config, f, indent=2)
    os.chmod(cf, 0o600)


def get_api_key() -> str:
    """Return cached API key, or empty string if none."""
    return os.getenv("X402_API_KEY", "") or load().get("api_key", "")


def set_api_key(key: str):
    """Save API key to local config."""
    cfg = load()
    cfg["api_key"] = key
    save(cfg)


def get_broker_url() -> str:
    """Return broker base URL."""
    return os.getenv("X402_BROKER_URL", "") or load().get("broker_url", _DEFAULTS["broker_url"])
