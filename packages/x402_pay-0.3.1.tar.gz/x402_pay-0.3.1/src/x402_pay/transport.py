"""BrokerTransport — httpx AsyncBaseTransport that routes through the x402 broker.

All requests go through POST /broker/call with API key authentication.
The broker handles upstream x402 payment on the caller's behalf.
"""

from __future__ import annotations

import json as _json

import httpx

from .exceptions import BrokerError, InsufficientBalance, KeyError_, NotInCatalog


class BrokerTransport(httpx.AsyncBaseTransport):
    """httpx transport that proxies requests through the x402 broker REST API.

    Usage::

        transport = BrokerTransport(api_key="gw_xxx", broker_url="https://discovery.hugen.tokyo")
        async with httpx.AsyncClient(transport=transport) as client:
            r = await client.get("https://weather.hugen.tokyo/weather/current?city=Tokyo")
    """

    def __init__(
        self,
        api_key: str,
        broker_url: str = "https://discovery.hugen.tokyo",
        timeout: float = 60.0,
    ):
        self._api_key = api_key
        self._broker_url = broker_url.rstrip("/")
        self._broker_endpoint = f"{self._broker_url}/broker/call"
        self._http = httpx.AsyncClient(timeout=timeout)

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        """Route request through broker, return upstream response."""
        url = str(request.url)
        method = request.method.upper()

        # Build broker request body
        body_payload: dict = {"url": url, "method": method}
        if method == "POST" and request.content:
            try:
                body_payload["body"] = _json.loads(request.content)
            except (ValueError, TypeError):
                body_payload["body"] = None

        broker_resp = await self._http.post(
            self._broker_endpoint,
            json=body_payload,
            headers={"X-API-Key": self._api_key},
        )

        # Map broker error responses to exceptions
        if broker_resp.status_code == 401:
            raise KeyError_("Invalid API key.")
        if broker_resp.status_code == 402:
            data = broker_resp.json()
            raise InsufficientBalance(
                balance=data.get("balance_usd", 0),
                needed=data.get("needed", 0.01),
                topup_url=data.get("topup", ""),
            )
        if broker_resp.status_code == 404:
            raise NotInCatalog(url)
        if broker_resp.status_code == 429:
            raise BrokerError("Rate limited. Try again in a minute.")
        if broker_resp.status_code == 502:
            data = broker_resp.json()
            raise BrokerError(
                data.get("error", "Upstream error"),
                refunded=data.get("refunded", False),
            )
        if broker_resp.status_code >= 400:
            data = broker_resp.json() if broker_resp.headers.get("content-type", "").startswith("application/json") else {}
            raise BrokerError(data.get("error", f"Broker returned {broker_resp.status_code}"))

        # Success — broker now returns upstream data directly in body,
        # with cost/balance in headers. Pass through as-is.
        return httpx.Response(
            status_code=broker_resp.status_code,
            headers=dict(broker_resp.headers),
            content=broker_resp.content,
            request=request,
        )

    async def aclose(self):
        await self._http.aclose()
