"""LangChain integration — use x402 APIs as LangChain tools.

Requires: pip install x402-pay[langchain]

Usage::

    from x402_pay.integrations.langchain import X402Toolkit

    tools = X402Toolkit().get_tools()
    agent = create_react_agent(llm, tools)
    agent.invoke({"input": "Check the security of USDC on Base"})
"""

from __future__ import annotations

import json
from typing import Any, Optional, Type

try:
    from langchain_core.tools import BaseTool
    from pydantic import BaseModel, Field
except ImportError as e:
    raise ImportError(
        "LangChain integration requires langchain-core. "
        "Install with: pip install x402-pay[langchain]"
    ) from e

import x402_pay


class _DiscoverInput(BaseModel):
    query: str = Field(description="Search keywords for x402 API catalog (e.g., 'weather', 'defi token security', 'email validation')")
    limit: int = Field(default=5, description="Max results (1-20)")


class _CallAPIInput(BaseModel):
    url: str = Field(description="Full URL of the x402 API endpoint to call (from discover results)")
    method: str = Field(default="GET", description="HTTP method: GET or POST")
    body: Optional[str] = Field(default=None, description="JSON body for POST requests")


class _BalanceInput(BaseModel):
    pass


class DiscoverTool(BaseTool):
    """Search 2,400+ x402 APIs by keyword. Returns URLs, descriptions, prices."""

    name: str = "x402_discover"
    description: str = (
        "Search the x402 API catalog to find paid APIs. "
        "Returns a list of APIs with URL, description, price, and whether they can be called via broker. "
        "Use this first to find the right API, then call it with x402_call."
    )
    args_schema: Type[BaseModel] = _DiscoverInput

    def _run(self, query: str, limit: int = 5) -> str:
        results = x402_pay.discover(query, limit=limit)
        if not results:
            return json.dumps({"message": f"No x402 APIs found for '{query}'", "results": []})
        return json.dumps({"total": len(results), "results": results}, indent=2)

    async def _arun(self, query: str, limit: int = 5) -> str:
        return self._run(query, limit)


class CallAPITool(BaseTool):
    """Call any x402 API endpoint. Payment handled automatically via broker."""

    name: str = "x402_call"
    description: str = (
        "Call an x402 API endpoint. The URL should come from x402_discover results. "
        "Payment is handled automatically ($0.01/call via broker). "
        "Returns the API response as JSON."
    )
    args_schema: Type[BaseModel] = _CallAPIInput

    def _run(self, url: str, method: str = "GET", body: Optional[str] = None) -> str:
        try:
            if method.upper() == "POST" and body:
                resp = x402_pay.post(url, json=json.loads(body))
            else:
                resp = x402_pay.get(url)

            if resp.status_code == 200:
                return json.dumps(resp.json(), indent=2)
            return json.dumps({"error": f"HTTP {resp.status_code}", "body": resp.text[:500]})
        except x402_pay.InsufficientBalance:
            return json.dumps({"error": "Insufficient balance. Top up at: POST https://discovery.hugen.tokyo/keys/topup"})
        except x402_pay.NotInCatalog:
            return json.dumps({"error": f"URL not in x402 catalog: {url}"})
        except x402_pay.BrokerError as e:
            return json.dumps({"error": f"Broker error: {e}"})

    async def _arun(self, url: str, method: str = "GET", body: Optional[str] = None) -> str:
        return self._run(url, method, body)


class BalanceTool(BaseTool):
    """Check remaining API key balance in USD."""

    name: str = "x402_balance"
    description: str = "Check how much credit remains on the x402 API key. Returns balance in USD."
    args_schema: Type[BaseModel] = _BalanceInput

    def _run(self) -> str:
        bal = x402_pay.balance()
        return json.dumps({"balance_usd": bal})

    async def _arun(self) -> str:
        return self._run()


class X402Toolkit:
    """LangChain toolkit providing x402 API access.

    Three tools: discover (find APIs), call (use APIs), balance (check credit).

    Usage::

        from x402_pay.integrations.langchain import X402Toolkit
        tools = X402Toolkit().get_tools()
    """

    def get_tools(self) -> list[BaseTool]:
        return [DiscoverTool(), CallAPITool(), BalanceTool()]
