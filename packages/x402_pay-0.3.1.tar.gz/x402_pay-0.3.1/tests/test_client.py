"""Tests for PayClient."""

import json

import httpx
import pytest

from x402_pay.client import PayClient
from x402_pay import config


@pytest.fixture
def mock_broker():
    """Returns a mock transport handler and call log."""
    calls = []

    async def handler(request: httpx.Request) -> httpx.Response:
        calls.append({
            "method": request.method,
            "url": str(request.url),
            "body": json.loads(request.content) if request.content else None,
        })

        url = str(request.url)

        # Mock key creation
        if "/keys/create" in url:
            return httpx.Response(200, json={
                "key": "gw_autotest1234567890abcdef",
                "balance_usd": 0.05,
            }, request=request)

        # Mock balance check
        if "/keys/balance" in url:
            return httpx.Response(200, json={
                "balance_usd": 0.04,
                "total_spent": 0.01,
                "total_calls": 1,
            }, request=request)

        # Mock broker call — returns upstream data directly
        if "/broker/call" in url:
            return httpx.Response(200, json={
                "city": "Tokyo", "temp": 22,
            }, headers={
                "x-broker-cost": "0.01",
                "x-broker-balance": "0.04",
            }, request=request)

        return httpx.Response(404, request=request)

    return handler, calls


@pytest.mark.asyncio
async def test_payclient_auto_key_creation(mock_broker):
    """PayClient auto-creates API key on first use."""
    handler, calls = mock_broker

    client = PayClient(broker_url="https://broker.test")
    # Override transport internals
    client._api_key = ""
    await client._ensure_init()

    # The key should have been auto-created
    # (ensure_key calls /keys/create, which our mock handles)
    # We need to patch the HTTP calls in the key module too
    # For this test, just set key directly and test the flow
    client._api_key = "gw_test_direct"
    assert client.api_key == "gw_test_direct"

    await client.close()


@pytest.mark.asyncio
async def test_payclient_get(mock_broker):
    """PayClient.get() routes through broker."""
    handler, calls = mock_broker

    client = PayClient(api_key="gw_test123", broker_url="https://broker.test")
    # Replace transport's internal HTTP client
    await client._ensure_init()
    assert client._transport is not None
    client._transport._http = httpx.AsyncClient(transport=httpx.MockTransport(handler))

    resp = await client.get("https://weather.test/api?city=Tokyo")
    assert resp.status_code == 200
    data = resp.json()
    assert data["city"] == "Tokyo"

    # Verify broker was called
    broker_calls = [c for c in calls if "/broker/call" in c["url"]]
    assert len(broker_calls) == 1
    assert broker_calls[0]["body"]["url"] == "https://weather.test/api?city=Tokyo"

    await client.close()


@pytest.mark.asyncio
async def test_payclient_context_manager(mock_broker):
    """PayClient works as async context manager."""
    handler, _ = mock_broker

    async with PayClient(api_key="gw_test", broker_url="https://broker.test") as client:
        client._transport._http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        resp = await client.get("https://test.api/endpoint")
        assert resp.status_code == 200


@pytest.mark.asyncio
async def test_payclient_explicit_key():
    """Explicit API key skips auto-creation."""
    client = PayClient(api_key="gw_explicit_key")
    assert client.api_key == "gw_explicit_key"
    await client.close()


@pytest.mark.asyncio
async def test_payclient_topup_url():
    """topup_url() returns correct Discovery API URL."""
    client = PayClient(api_key="gw_mykey123", broker_url="https://discovery.hugen.tokyo")
    url = await client.topup_url()
    assert url == "https://discovery.hugen.tokyo/keys/topup?key=gw_mykey123"
    await client.close()


@pytest.mark.asyncio
async def test_payclient_topup_url_default_broker():
    """topup_url() uses default broker URL when none specified."""
    client = PayClient(api_key="gw_mykey456")
    url = await client.topup_url()
    assert "discovery.hugen.tokyo" in url
    assert "gw_mykey456" in url
    await client.close()
