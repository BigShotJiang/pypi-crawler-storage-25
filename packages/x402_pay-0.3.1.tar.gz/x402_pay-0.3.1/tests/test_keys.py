"""Tests for API key management."""

import json

import httpx
import pytest

from x402_pay import config
from x402_pay.keys import create_key, get_balance, ensure_key
from x402_pay.exceptions import KeyError_, PayError


@pytest.mark.asyncio
async def test_create_key():
    """Key creation calls broker and returns key data."""
    async def handler(request: httpx.Request) -> httpx.Response:
        assert "/keys/create" in str(request.url)
        return httpx.Response(200, json={
            "key": "gw_newkey1234",
            "balance_usd": 0.05,
            "trial_calls": 10,
        }, request=request)

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    result = await create_key(label="test", client=client)

    assert result["key"] == "gw_newkey1234"
    assert result["balance_usd"] == 0.05

    await client.aclose()


@pytest.mark.asyncio
async def test_get_balance():
    """Balance check returns key info."""
    async def handler(request: httpx.Request) -> httpx.Response:
        assert "/keys/balance" in str(request.url)
        return httpx.Response(200, json={
            "balance_usd": 0.04,
            "total_spent": 0.01,
            "total_calls": 1,
        }, request=request)

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    result = await get_balance("gw_test123", client=client)

    assert result["balance_usd"] == 0.04
    assert result["total_calls"] == 1

    await client.aclose()


@pytest.mark.asyncio
async def test_get_balance_no_key():
    """Balance check without key raises KeyError_."""
    with pytest.raises(KeyError_):
        await get_balance("")


@pytest.mark.asyncio
async def test_get_balance_404():
    """Balance check for nonexistent key raises KeyError_."""
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"error": "Key not found."}, request=request)

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    with pytest.raises(KeyError_):
        await get_balance("gw_nonexistent", client=client)

    await client.aclose()


@pytest.mark.asyncio
async def test_ensure_key_creates_new(tmp_path, monkeypatch):
    """ensure_key auto-creates when no key exists."""
    monkeypatch.setenv("X402_PAY_CONFIG_DIR", str(tmp_path / ".x402-pay"))

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={
            "key": "gw_auto_created",
            "balance_usd": 0.05,
        }, request=request)

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    key = await ensure_key(client=client)

    assert key == "gw_auto_created"
    # Should be saved to config
    assert config.get_api_key() == "gw_auto_created"

    await client.aclose()


@pytest.mark.asyncio
async def test_ensure_key_uses_existing(monkeypatch):
    """ensure_key returns existing key without network call."""
    monkeypatch.setenv("X402_API_KEY", "gw_env_key")

    key = await ensure_key()
    assert key == "gw_env_key"
