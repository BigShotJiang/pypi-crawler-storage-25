"""Tests for BrokerTransport."""

import json

import httpx
import pytest

from x402_pay.transport import BrokerTransport
from x402_pay.exceptions import InsufficientBalance, NotInCatalog, BrokerError, KeyError_


class FakeBrokerApp:
    """Mock broker that responds to POST /broker/call."""

    def __init__(self, responses: dict | None = None):
        self.responses = responses or {}
        self.calls: list[dict] = []

    async def handle(self, request: httpx.Request) -> httpx.Response:
        self.calls.append({
            "method": request.method,
            "url": str(request.url),
            "headers": dict(request.headers),
            "body": json.loads(request.content) if request.content else None,
        })

        # Default success response — broker returns upstream data directly
        target_url = ""
        if request.content:
            body = json.loads(request.content)
            target_url = body.get("url", "")

        if target_url in self.responses:
            return self.responses[target_url]

        return httpx.Response(
            200,
            json={"result": "ok"},
            headers={"x-broker-cost": "0.01", "x-broker-balance": "0.04"},
            request=request,
        )


@pytest.mark.asyncio
async def test_transport_success():
    """Successful request through broker."""
    app = FakeBrokerApp()
    transport = BrokerTransport(api_key="gw_test123", broker_url="https://broker.test")
    # Replace internal client with mock
    transport._http = httpx.AsyncClient(transport=httpx.MockTransport(app.handle))

    request = httpx.Request("GET", "https://weather.test/api?city=Tokyo")
    response = await transport.handle_async_request(request)

    assert response.status_code == 200
    data = json.loads(response.content)
    assert data["result"] == "ok"

    # Verify broker was called correctly
    assert len(app.calls) == 1
    call = app.calls[0]
    assert call["method"] == "POST"
    assert call["headers"]["x-api-key"] == "gw_test123"
    assert call["body"]["url"] == "https://weather.test/api?city=Tokyo"
    assert call["body"]["method"] == "GET"

    await transport.aclose()


@pytest.mark.asyncio
async def test_transport_401_invalid_key():
    """Invalid API key raises KeyError_."""
    async def reject(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": "Invalid API key."}, request=request)

    transport = BrokerTransport(api_key="bad_key")
    transport._http = httpx.AsyncClient(transport=httpx.MockTransport(reject))

    with pytest.raises(KeyError_):
        await transport.handle_async_request(httpx.Request("GET", "https://test.api/x"))

    await transport.aclose()


@pytest.mark.asyncio
async def test_transport_402_insufficient_balance():
    """Insufficient balance raises InsufficientBalance."""
    async def low_balance(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            402,
            json={"balance_usd": 0.002, "needed": 0.01, "topup": "https://topup.url"},
            request=request,
        )

    transport = BrokerTransport(api_key="gw_test")
    transport._http = httpx.AsyncClient(transport=httpx.MockTransport(low_balance))

    with pytest.raises(InsufficientBalance) as exc_info:
        await transport.handle_async_request(httpx.Request("GET", "https://test.api/x"))

    assert exc_info.value.balance == 0.002
    assert exc_info.value.needed == 0.01
    assert "topup" in exc_info.value.topup_url

    await transport.aclose()


@pytest.mark.asyncio
async def test_transport_404_not_in_catalog():
    """Unknown URL raises NotInCatalog."""
    async def not_found(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"error": "URL not in catalog."}, request=request)

    transport = BrokerTransport(api_key="gw_test")
    transport._http = httpx.AsyncClient(transport=httpx.MockTransport(not_found))

    with pytest.raises(NotInCatalog) as exc_info:
        await transport.handle_async_request(httpx.Request("GET", "https://unknown.api/x"))

    assert "unknown.api" in exc_info.value.url

    await transport.aclose()


@pytest.mark.asyncio
async def test_transport_502_upstream_error():
    """Upstream failure raises BrokerError with refund info."""
    async def upstream_fail(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            502,
            json={"error": "Upstream timeout", "refunded": True, "balance_remaining": 0.05},
            request=request,
        )

    transport = BrokerTransport(api_key="gw_test")
    transport._http = httpx.AsyncClient(transport=httpx.MockTransport(upstream_fail))

    with pytest.raises(BrokerError) as exc_info:
        await transport.handle_async_request(httpx.Request("GET", "https://test.api/x"))

    assert exc_info.value.refunded is True

    await transport.aclose()


@pytest.mark.asyncio
async def test_transport_post_with_body():
    """POST request forwards body to broker."""
    app = FakeBrokerApp()
    transport = BrokerTransport(api_key="gw_test")
    transport._http = httpx.AsyncClient(transport=httpx.MockTransport(app.handle))

    request = httpx.Request("POST", "https://test.api/submit", content=json.dumps({"key": "value"}).encode())
    await transport.handle_async_request(request)

    assert app.calls[0]["body"]["method"] == "POST"
    assert app.calls[0]["body"]["body"] == {"key": "value"}

    await transport.aclose()
