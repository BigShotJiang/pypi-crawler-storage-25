# AutoPR — AI-powered Pull Request Generator & Reviewer

[![PyPI version](https://badge.fury.io/py/autopr-core.svg)](https://pypi.org/project/autopr-core/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

AutoPR automates the repetitive parts of pull requests: it writes concise PR titles & descriptions, validates CI/tests, runs deterministic static and lint checks, and provides an AI-assisted review summary.

## Quickstart

### 1. Install

```bash
pip install autopr-core
```

### 2. Configure your API key

AutoPR requires your own OpenAI or Anthropic API key. Run the interactive setup:

```bash
autopr configure
```

This will prompt you to:
- Choose a provider (`openai` or `anthropic`)
- Enter your API key (stored locally in `.env`, never shared)

**Or set environment variables manually:**

```bash
# For OpenAI
export OPENAI_API_KEY="your-openai-api-key"
export AUTOPR_PROVIDER="openai"

# For Anthropic
export ANTHROPIC_API_KEY="your-anthropic-api-key"
export AUTOPR_PROVIDER="anthropic"
```

### 3. Use AutoPR

```bash
# Generate a PR title & description
autopr gen --diff "$(git diff)" --commits "feat: add helper"

# AI-assisted code review
autopr review --diff "$(git diff)"

# Run static analysis
autopr analyze --diff "$(git diff)" --summary
```

## Command Cheat Sheet

| Command | Description |
|---------|-------------|
| `autopr configure` | Interactive setup — set your AI provider and API key |
| `autopr gen` | Generate PR title and description |
| `autopr review` | Perform AI-assisted code review |
| `autopr analyze` | Run static analysis on code diffs |
| `autopr analyze-files` | Batch-analyze files in a directory |
| `autopr ci-parse` | Parse CI/test logs |
| `autopr coverage-compare` | Compare coverage reports |
| `autopr validate-issue` | Check if changes align with an issue |
| `autopr doctor` | Check system health and configuration |
| `autopr init` | Initialize AutoPR config in your repo |
| `autopr suggest-reviewers` | Suggest reviewers based on git history |

## Features

- **AI-Powered PR Generation** — Titles, descriptions, and risk assessments
- **AI Code Review** — Senior-engineer-level review with actionable findings
- **Static Analysis** — Deterministic Python code analysis (security, complexity, style)
- **CI/Test Parsing** — Parse pytest, unittest, and GitHub Actions logs
- **Coverage Comparison** — Diff coverage reports before and after changes
- **Multiple LLM Providers** — OpenAI and Anthropic with robust error handling
- **FastAPI Backend** — REST API with `/generate` and `/review` endpoints
- **CLI Tool** — Full-featured command-line interface

## API Server

Run the FastAPI server for REST API access:

```bash
uvicorn autopr.main:app --reload --port 8000
```

Visit [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs) for interactive API docs.

## Install from Source

```bash
git clone https://github.com/surenkotian/AutoPR.git
cd AutoPR
pip install -e .
autopr configure
```

## License

MIT