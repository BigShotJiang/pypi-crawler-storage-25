from __future__ import annotations

import argparse
import asyncio
import copy
import logging
import os
import signal
import sys
from importlib import resources
from typing import Optional

import uvicorn

from bearpaw.api import create_app
from bearpaw.config import load_config


logger = logging.getLogger("bearpaw")

_NOISY_LOG_MARKERS = (
    "GET /api/v1/status",
    "GET /api/v1/device/info",
    "GET /api/v1/lockouts",
    "OPTIONS /api/v1/",
    "WebSocket /ws",
)


class _AccessLogFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        return not any(marker in message for marker in _NOISY_LOG_MARKERS)


def _install_access_log_filters() -> None:
    logging.getLogger("uvicorn.access").addFilter(_AccessLogFilter())
    logging.getLogger("uvicorn.error").addFilter(_AccessLogFilter())


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Bearpaw backend")
    parser.add_argument("--config", help="Path to YAML or TOML config")
    parser.add_argument("--port", help="Serial port override")
    parser.add_argument("--api-host", help="API host override")
    parser.add_argument("--api-port", type=int, help="API port override")
    parser.add_argument(
        "--log-level",
        default=None,
        choices=["debug", "info", "warning", "error", "critical"],
        help="Override logging.level from config",
    )
    parser.add_argument("--foreground", action="store_true", help="Run in foreground")
    parser.add_argument("--daemon", action="store_true", help="Run as daemon")
    parser.add_argument("--pid-file", default="/var/run/bearpaw.pid")
    parser.add_argument("--log-file", default="/var/log/bearpaw.log")
    parser.add_argument(
        "--print-example-config",
        action="store_true",
        help="Print the bundled config.example.yaml to stdout and exit",
    )
    return parser.parse_args()


def _print_example_config() -> None:
    text = (
        resources.files("bearpaw")
        .joinpath("config.example.yaml")
        .read_text(encoding="utf-8")
    )
    sys.stdout.write(text)


async def _foreground_console(app) -> None:
    while not hasattr(app.state, "runtime"):
        await asyncio.sleep(0.1)
    runtime = app.state.runtime
    print("Bearpaw foreground mode (h=hold, s=scan, q=quit)")
    while True:
        try:
            line = await asyncio.to_thread(sys.stdin.read, 1)
        except Exception:
            return
        if not line:
            await asyncio.sleep(0.1)
            continue
        key = line.strip().lower()
        if key == "h":
            await runtime.driver.send_hold()
        elif key == "s":
            await runtime.driver.send_scan()
        elif key == "q":
            return


async def _foreground_status(app) -> None:
    while not hasattr(app.state, "runtime"):
        await asyncio.sleep(0.1)
    runtime = app.state.runtime
    while True:
        state = runtime.state_store.get_live_state()
        output = (
            f"\r{state.frequency:.4f} {state.modulation} "
            f"RSSI {state.rssi} "
            f"{'OPEN' if state.squelch_open else 'CLOSE'} "
            f"CH {state.channel or '-'} "
            f"{'STALE' if state.stale else '     '}"
        )
        print(output, end="", flush=True)
        await asyncio.sleep(0.5)


async def run_foreground(
    app, host: str, port: int, log_level: str, config_path: Optional[str]
) -> None:
    log_config = copy.deepcopy(uvicorn.config.LOGGING_CONFIG)
    log_config["formatters"]["access"]["fmt"] = (
        '%(levelprefix)s "%(request_line)s" %(status_code)s'
    )
    config = uvicorn.Config(
        app, host=host, port=port, log_level=log_level, log_config=log_config
    )
    server = uvicorn.Server(config)
    _install_signal_handlers(server, app, config_path)
    server_task = asyncio.create_task(server.serve())
    status_task = asyncio.create_task(_foreground_status(app))
    console_task = asyncio.create_task(_foreground_console(app))
    done, _ = await asyncio.wait(
        [server_task, status_task, console_task], return_when=asyncio.FIRST_COMPLETED
    )
    for task in done:
        if task is console_task:
            server.should_exit = True
    await server_task
    status_task.cancel()
    console_task.cancel()


def _daemonize(pid_file: str, log_file: str) -> None:
    if os.name != "posix":
        raise RuntimeError("Daemon mode is only supported on POSIX systems")
    pid = os.fork()
    if pid > 0:
        sys.exit(0)
    os.setsid()
    pid = os.fork()
    if pid > 0:
        sys.exit(0)
    os.umask(0o027)
    sys.stdout.flush()
    sys.stderr.flush()
    with open("/dev/null", "rb") as devnull:
        os.dup2(devnull.fileno(), sys.stdin.fileno())
    log_handle = open(log_file, "a", buffering=1)
    os.dup2(log_handle.fileno(), sys.stdout.fileno())
    os.dup2(log_handle.fileno(), sys.stderr.fileno())
    with open(pid_file, "w", encoding="ascii") as handle:
        handle.write(str(os.getpid()))


def _install_signal_handlers(
    server: uvicorn.Server, app, config_path: Optional[str]
) -> None:
    def handle_exit(signum, frame):
        server.should_exit = True

    def handle_reload(signum, frame):
        logger.info("SIGHUP received; reload config requested.")
        app.state.runtime.config = load_config(config_path)

    signal.signal(signal.SIGTERM, handle_exit)
    signal.signal(signal.SIGINT, handle_exit)
    if hasattr(signal, "SIGHUP"):
        signal.signal(signal.SIGHUP, handle_reload)


def run_server(
    app,
    host: str,
    port: int,
    daemon: bool,
    pid_file: str,
    log_file: str,
    config_path: Optional[str],
    log_level: str,
) -> None:
    if daemon:
        _daemonize(pid_file, log_file)
    _install_access_log_filters()
    log_config = copy.deepcopy(uvicorn.config.LOGGING_CONFIG)
    log_config["formatters"]["access"]["fmt"] = (
        '%(levelprefix)s "%(request_line)s" %(status_code)s'
    )
    config = uvicorn.Config(
        app, host=host, port=port, log_level=log_level, log_config=log_config
    )
    server = uvicorn.Server(config)
    _install_signal_handlers(server, app, config_path)
    asyncio.run(server.serve())


def main() -> None:
    args = parse_args()
    if args.print_example_config:
        _print_example_config()
        return
    config = load_config(args.config)

    if args.log_level:
        config.logging.level = args.log_level.upper()
    log_level = config.logging.level.upper()
    logging.basicConfig(level=log_level, format=config.logging.format)
    logging.getLogger().setLevel(log_level)
    logger.debug("Debug logging enabled")
    if args.api_host:
        config.api.host = args.api_host
    if args.api_port:
        config.api.port = args.api_port

    if args.daemon and args.foreground:
        print("Choose either --daemon or --foreground", file=sys.stderr)
        sys.exit(2)

    app = create_app(config, port_override=args.port)
    _install_access_log_filters()
    uvicorn_log_level = config.logging.level.lower()
    if args.foreground:
        asyncio.run(
            run_foreground(
                app, config.api.host, config.api.port, uvicorn_log_level, args.config
            )
        )
        return
    run_server(
        app,
        config.api.host,
        config.api.port,
        args.daemon,
        args.pid_file,
        args.log_file,
        args.config,
        uvicorn_log_level,
    )


if __name__ == "__main__":
    main()
