import sys
import re
import ast
import math
import uuid
import traceback
import os
from io import StringIO
from typing import Dict, Any, Optional
from fastapi import FastAPI, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# 1. SETUP
HOST = os.getenv("MIMIQ_HOST", "127.0.0.1")
PORT = int(os.getenv("MIMIQ_PORT", "8002"))

app = FastAPI(title="Mimiq IDE Pro", version="2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

jobs: Dict[str, Dict[str, Any]] = {}
MAX_JOBS = 200


def _evict_old_jobs() -> None:
    """Keep the jobs dict bounded — drop terminal entries when over limit."""
    if len(jobs) <= MAX_JOBS:
        return
    terminal = [
        jid for jid, j in jobs.items()
        if j.get("status") in ("completed", "failed", "cancelled")
    ]
    for jid in terminal[: len(jobs) - MAX_JOBS]:
        del jobs[jid]


@app.get("/health")
async def health():
    return {"status": "ok", "version": "2.0"}


class CodeRequest(BaseModel):
    code: str
    timeout: Optional[int] = 30
    mode: str = "quantanium"  # Options: 'quantanium' or 'mimiqlink'
    nshots: Optional[int] = 1000


def _to_serializable(obj):
    """Recursively convert mimiqcircuits/protobuf types to JSON-safe Python primitives."""
    # numpy arrays
    if hasattr(obj, "tolist"):
        return obj.tolist()
    # protobuf RepeatedScalarContainer and similar iterables (not str/bytes/dict)
    if hasattr(obj, "__iter__") and not isinstance(obj, (str, bytes, dict)):
        try:
            return [_to_serializable(v) for v in obj]
        except Exception:
            pass
    # dicts — convert keys to strings (handles frozenbitarray keys)
    if isinstance(obj, dict):
        return {str(k): _to_serializable(v) for k, v in obj.items()}
    # frozenbitarray and similar — convert to bit-string
    if hasattr(obj, "__str__") and not isinstance(
        obj, (int, float, bool, str, type(None))
    ):
        try:
            s = str(obj)
            # frozenbitarray repr is "frozenbitarray('0110')" — extract the inner string
            m = re.search(r"'([01]+)'", s)
            if m:
                return m.group(1)
            return s
        except Exception:
            pass
    return obj


def _histogram_to_dict(histogram):
    """Convert a mimiqcircuits histogram (frozenbitarray keys) to a plain {str: int} dict."""
    result = {}
    for k, v in histogram.items():
        key_str = str(k)
        m = re.search(r"'([01]+)'", key_str)
        if m:
            key_str = m.group(1)
        result[key_str] = int(v)
    return result


# 2. EXECUTION ENGINES
def execute_internal(code: str, mode: str, nshots: int = 1000):
    stdout_io = StringIO()
    stderr_io = StringIO()
    orig_stdout, orig_stderr = sys.stdout, sys.stderr

    try:
        sys.stdout, sys.stderr = stdout_io, stderr_io
        namespace = {"__builtins__": __builtins__}

        # Imports
        from mimiqcircuits import Circuit
        import numpy as np
        import math as _math

        namespace.update({"Circuit": Circuit, "np": np, "math": _math})
        namespace.update({k: getattr(_math, k) for k in dir(_math) if not k.startswith('_')})
        namespace.update({
            "arcsin": _math.asin, "arccos": _math.acos,
            "arctan": _math.atan, "arctan2": _math.atan2,
        })

        # Run User Code (Circuit Definition)
        exec(code, namespace)

        # Extract Circuit
        circuit = namespace.get("c") or namespace.get("circuit")
        if not circuit:
            raise ValueError("No 'c' variable found in code.")

        # Dispatch
        result_data = None
        if mode == "mimiqlink":
            # CLOUD EXECUTION
            from mimiqlink import MimiqConnection

            conn = MimiqConnection()
            conn.connect()  # Uses local credentials
            job = conn.execute(circuit)
            return {
                "success": True,
                "status": "processing",
                "job_obj": job,
                "stdout": stdout_io.getvalue(),
                "stderr": stderr_io.getvalue(),
            }
        else:
            # LOCAL PYTHON SIMULATION via Quantanium
            from quantanium import Quantanium

            sim = Quantanium()
            res = sim.execute(circuit, nsamples=nshots)

            # --- Histogram: frozenbitarray keys → plain str keys ---
            raw_hist = res.histogram() if hasattr(res, "histogram") else {}
            result_data = _histogram_to_dict(raw_hist)

            # --- Statevector: run evolve() to get complex amplitudes ---
            # This gives us real phase information per basis state.
            statevector_data = None
            try:
                sim2 = Quantanium()
                sim2.evolve(circuit, stop_before_measure=True)
                sv = sim2.get_statevector()  # list of complex numbers
                if sv is not None:
                    num_qubits = (
                        circuit.num_qubits() if hasattr(circuit, "num_qubits") else None
                    )
                    if num_qubits is None:
                        num_qubits = int(math.log2(len(sv))) if len(sv) > 1 else 1
                    statevector_data = {}
                    for idx, amp in enumerate(sv):
                        # amp is a Python complex number
                        real = (
                            float(amp.real) if hasattr(amp, "real") else float(amp[0])
                        )
                        imag = (
                            float(amp.imag) if hasattr(amp, "imag") else float(amp[1])
                        )
                        state_str = format(idx, f"0{num_qubits}b")
                        statevector_data[state_str] = [real, imag]
            except Exception:
                pass
                # non-fatal: phase display falls back to layout angle

            # --- Fidelities: protobuf RepeatedScalarContainer → list[float] ---
            fidelities = None
            try:
                if hasattr(res, "fidelities"):
                    fidelities = [float(f) for f in res.fidelities]
            except Exception:
                pass

            # --- Timings: plain dict, add 'total' = sum of all values ---
            timings = None
            try:
                if hasattr(res, "timings") and isinstance(res.timings, dict):
                    timings = {str(k): float(v) for k, v in res.timings.items()}
                    timings["total"] = sum(timings.values())
            except Exception:
                pass

        return {
            "success": True,
            "result": result_data,
            "statevector": statevector_data,
            "fidelities": fidelities,
            "timings": timings,
            "stdout": stdout_io.getvalue(),
            "stderr": stderr_io.getvalue(),
        }

    except Exception as e:
        return {
            "success": False,
            "error": f"{type(e).__name__}: {str(e)}",
            "stdout": stdout_io.getvalue(),
            "stderr": stderr_io.getvalue() + "\n" + traceback.format_exc(),
        }
    finally:
        sys.stdout, sys.stderr = orig_stdout, orig_stderr


def worker(job_id, code, mode, nshots=1000):
    jobs[job_id]["status"] = "running"
    res = execute_internal(code, mode, nshots=nshots)

    if not res["success"]:
        jobs[job_id].update(
            {"status": "failed", "error": res["error"], "stderr": res["stderr"]}
        )
        return

    if res.get("status") == "processing":
        jobs[job_id].update({"status": "processing", "stdout": res["stdout"]})
        try:
            # Poll for result (non-blocking in the background thread)
            job_obj = res["job_obj"]
            result_data = (
                job_obj.result()
            )  # Still blocks this thread, but it's a worker thread
            jobs[job_id].update(
                {"status": "completed", "result": _to_serializable(result_data)}
            )
        except Exception as e:
            jobs[job_id].update({"status": "failed", "error": str(e)})
    else:
        jobs[job_id].update(
            {
                "status": "completed",
                "result": res["result"],
                "statevector": res.get("statevector"),
                "fidelities": res.get("fidelities"),
                "timings": res.get("timings"),
                "stdout": res["stdout"],
            }
        )


# 3. API ROUTES
@app.post("/api/execute")
async def start_job(req: CodeRequest, bg: BackgroundTasks):
    _evict_old_jobs()
    job_id = str(uuid.uuid4())
    jobs[job_id] = {"id": job_id, "status": "queued", "mode": req.mode}
    bg.add_task(worker, job_id, req.code, req.mode, req.nshots or 1000)
    return {"job_id": job_id}


@app.get("/api/job/{job_id}")
async def job_status(job_id: str):
    return jobs.get(job_id, {"status": "not_found"})


class ParseRequest(BaseModel):
    code: str


@app.post("/api/parse")
async def parse_circuit(req: ParseRequest):
    """
    Execute the user's Python code (circuit definition only, no simulation),
    walk the resulting circuit and return structured gate data for the visualizer.
    """
    stdout_io = StringIO()
    stderr_io = StringIO()
    orig_stdout, orig_stderr = sys.stdout, sys.stderr
    try:
        sys.stdout, sys.stderr = stdout_io, stderr_io

        # Auto-inject mimiqcircuits import if missing
        code = req.code
        if "from mimiqcircuits" not in code and "import mimiqcircuits" not in code:
            code = "from mimiqcircuits import *\n" + code

        namespace = {"__builtins__": __builtins__}
        from mimiqcircuits import Circuit
        import numpy as np
        import math as _math

        namespace.update({"Circuit": Circuit, "np": np, "math": _math})
        namespace.update({k: getattr(_math, k) for k in dir(_math) if not k.startswith('_')})
        namespace.update({
            "arcsin": _math.asin, "arccos": _math.acos,
            "arctan": _math.atan, "arctan2": _math.atan2,
        })

        # Try to import all of mimiqcircuits into namespace for convenience
        try:
            import mimiqcircuits as _mc

            for name in dir(_mc):
                if not name.startswith("_"):
                    namespace[name] = getattr(_mc, name)
        except Exception:
            pass

        exec(code, namespace)

        circuit = namespace.get("c") or namespace.get("circuit")
        if not circuit:
            return {"success": False, "error": "No circuit variable 'c' found"}

        instructions = []
        num_qubits = circuit.num_qubits() if hasattr(circuit, "num_qubits") else 0

        # Map each circuit instruction index → the actual Python source line number
        # by scanning the AST for .push() calls and predicting their footprint.
        _orig_lines = req.code.split("\n")
        push_line_numbers = []
        try:
            tree = ast.parse(req.code)
            for node in ast.walk(tree):
                if (
                    isinstance(node, ast.Call)
                    and getattr(node.func, "attr", "") == "push"
                ):
                    line_idx = getattr(node, "lineno", 1) - 1

                    # Estimate the number of instructions this `.push` call produces.
                    # By default it's 1. But if ANY argument is a multi-item range/list,
                    # Mimiqcircuits broadcasts the gate across them.
                    count = 1
                    for arg in node.args[1:]:
                        if (
                            isinstance(arg, ast.Call)
                            and getattr(arg.func, "id", "") == "range"
                        ):
                            if len(arg.args) == 1 and isinstance(
                                arg.args[0], ast.Constant
                            ):
                                count = max(count, int(str(arg.args[0].value)))
                            elif (
                                len(arg.args) == 2
                                and isinstance(arg.args[0], ast.Constant)
                                and isinstance(arg.args[1], ast.Constant)
                            ):
                                count = max(
                                    count,
                                    int(str(arg.args[1].value)) - int(str(arg.args[0].value)),
                                )
                        elif isinstance(arg, (ast.List, ast.Tuple)):
                            count = max(count, len(arg.elts))

                    for _ in range(count):
                        push_line_numbers.append(line_idx)
            # Sort is needed because ast.walk doesn't guarantee traversal order
            push_line_numbers.sort()
        except Exception:
            # Fallback for invalid syntax or complex multi-target parsing failure
            push_line_numbers = [
                i
                for i, ln in enumerate(_orig_lines)
                if ".push(" in ln and not ln.strip().startswith("#")
            ]

        def _gate_name(op):
            cls = type(op).__name__

            if cls in ("Power", "Inverse"):
                try:
                    base_str = str(op).split("(")[0]
                    return base_str.replace("†", "DG")
                except Exception:
                    pass

            # Handle generic Control wrapper (e.g. GateCX() -> Control(X, 1))
            if cls == "Control":
                try:
                    inner = op.op if hasattr(op, "op") else getattr(op, "_op", None)
                    num_ctrl = (
                        op.num_controls
                        if hasattr(op, "num_controls")
                        else getattr(op, "_num_controls", 1)
                    )

                    if inner:
                        inner_cls = type(inner).__name__
                        if inner_cls.startswith("Gate"):
                            inner_cls = inner_cls[4:]

                        if inner_cls == "X":
                            if num_ctrl == 1:
                                return "CX"
                            if num_ctrl == 2:
                                return "CCX"
                            if num_ctrl == 3:
                                return "C3X"
                            return f"C{num_ctrl}X"

                        elif inner_cls == "Z":
                            if num_ctrl == 1:
                                return "CZ"
                            return "CCZ"

                        elif inner_cls == "P":
                            if num_ctrl == 1:
                                return "CP"
                            return "CCP"

                        elif inner_cls == "Id":  # Controlled-Identity?
                            return "Id"

                        return f"C{inner_cls}"
                except Exception:
                    pass

            # Strip Gate prefix: GateH → H, GateCX → CX, etc.
            if cls.startswith("Gate"):
                cls = cls[4:]
            # Special mappings (after Gate prefix is stripped)
            mapping = {
                "ID": "I",
                "Measure": "M",
                "MeasureReset": "MR",
                "Reset": "Reset",
                "Barrier": "Barrier",
                "Delay": "Delay",
            }
            return mapping.get(cls, cls)

        def _gate_params(op):
            """Return a compact string of gate parameters, or empty string."""
            try:
                params = op.getparams() if hasattr(op, "getparams") else []
                if not params:
                    # Try .params attribute
                    params = list(op.params) if hasattr(op, "params") else []
                if params:

                    def _fmt(p):
                        try:
                            fv = float(p)
                            # Show as fraction of π when close
                            for num in range(1, 9):
                                for den in range(1, 9):
                                    if abs(fv - num * math.pi / den) < 1e-9:
                                        return (
                                            f"{num}π/{den}" if num > 1 else f"π/{den}"
                                        )
                                    if abs(fv + num * math.pi / den) < 1e-9:
                                        return f"-π/{den}"
                            return f"{fv:.3g}"
                        except Exception:
                            return str(p)

                    return ", ".join(_fmt(p) for p in params)
            except Exception:
                pass
            return ""

        for idx, inst in enumerate(circuit):
            try:
                op = inst.get_operation()
                name = _gate_name(op)
                params_str = _gate_params(op)

                # Qubit targets
                targets = []
                try:
                    qubits = inst.get_qubits()
                    targets = [int(q) for q in qubits]
                except Exception:
                    pass

                # Classical bit targets (for measurements)
                bits = []
                try:
                    b = inst.get_bits()
                    bits = [int(x) for x in b]
                except Exception:
                    pass

                instructions.append(
                    {
                        "id": f"gate-{idx}",
                        "gate": name,
                        "targets": targets,
                        "bits": bits,
                        "params": params_str,
                        "lineIndex": (
                            push_line_numbers[idx]
                            if idx < len(push_line_numbers)
                            else idx
                        ),
                    }
                )
            except Exception as inst_err:
                # Skip instructions we can't parse
                instructions.append(
                    {
                        "id": f"gate-{idx}",
                        "gate": "?",
                        "targets": [],
                        "bits": [],
                        "params": str(inst_err)[:40],
                        "lineIndex": (
                            push_line_numbers[idx]
                            if idx < len(push_line_numbers)
                            else idx
                        ),
                    }
                )

        return {
            "success": True,
            "instructions": instructions,
            "num_qubits": num_qubits,
        }

    except Exception as e:
        return {"success": False, "error": f"{type(e).__name__}: {str(e)}"}
    finally:
        sys.stdout, sys.stderr = orig_stdout, orig_stderr


# 4. SERVE REACT FRONTEND (Production Mode)
# This assumes you ran `npm run build` and the output is in 'dist'
_STATIC_DIR = os.getenv("MIMIQ_STATIC_DIR", "dist")
if os.path.exists(_STATIC_DIR):
    app.mount("/", StaticFiles(directory=_STATIC_DIR, html=True), name="static")
else:

    @app.get("/")
    def index():
        return "API Running. Please run 'npm run build' to generate the UI."


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host=HOST, port=PORT)
