"""
Mimiq IDE — entry point for pip-installed package.

    python -m mimiq_ide
    mimiq
"""

import os
import sys
import socket
import subprocess
import threading
import webbrowser
import time

PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR  = os.path.join(PACKAGE_DIR, "static")
API_SCRIPT  = os.path.join(PACKAGE_DIR, "api.py")


def _find_free_port(start: int = 8002) -> int:
    for port in range(start, start + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return start


def main() -> None:
    if not os.path.exists(API_SCRIPT):
        print("[ERROR] api.py not found inside the package. Re-install mimiq-ide.")
        sys.exit(1)

    if not os.path.exists(os.path.join(STATIC_DIR, "index.html")):
        print("[ERROR] Static UI files are missing from the package.")
        print("        Re-install mimiq-ide or report the issue to support@mimiq.io")
        sys.exit(1)

    port = _find_free_port()
    url  = f"http://127.0.0.1:{port}"

    env = os.environ.copy()
    env["MIMIQ_PORT"]       = str(port)
    env["MIMIQ_STATIC_DIR"] = STATIC_DIR

    proc = subprocess.Popen([sys.executable, API_SCRIPT], env=env)

    def _open() -> None:
        time.sleep(1.5)
        webbrowser.open(url)

    threading.Thread(target=_open, daemon=True).start()

    print(f"\n  Mimiq IDE  —  {url}")
    print("  Press Ctrl+C to stop.\n")

    try:
        proc.wait()
    except KeyboardInterrupt:
        proc.terminate()
        proc.wait()
        print("\n  Stopped.")


if __name__ == "__main__":
    main()
