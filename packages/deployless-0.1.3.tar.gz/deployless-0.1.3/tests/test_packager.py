"""Tests for deployless.providers.aws.packager."""
from deployless.providers.aws.packager import (
    _build_cors_block,
    _build_init_app_block,
    _collect_deps,
    _generate_feature_stubs,
    _has_flask_cors,
    _merge_requirements,
    _pkg_name,
    _routes_import,
    build_cron_package,
    build_feature_package,
    build_lambda_package,
    build_split_route_package,
)


class TestPkgName:
    def test_plain(self):
        assert _pkg_name("flask") == "flask"

    def test_with_version(self):
        assert _pkg_name("Flask>=2.0") == "flask"

    def test_with_extras(self):
        assert _pkg_name("flask[async]>=2.0") == "flask"

    def test_hyphen_normalized(self):
        assert _pkg_name("aws-wsgi") == "aws_wsgi"

    def test_comment_returns_empty(self):
        assert _pkg_name("# comment") == ""

    def test_empty_returns_empty(self):
        assert _pkg_name("") == ""


class TestCollectDeps:
    def test_reads_requirements_txt(self, tmp_path):
        (tmp_path / "requirements.txt").write_text("flask\nboto3\n")
        assert _collect_deps(tmp_path) == ["flask", "boto3"]

    def test_reads_pyproject_toml(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text(
            '[project]\ndependencies = ["flask>=2.0", "boto3"]\n'
        )
        assert _collect_deps(tmp_path) == ["flask>=2.0", "boto3"]

    def test_requirements_txt_takes_priority(self, tmp_path):
        (tmp_path / "requirements.txt").write_text("flask==3.0\n")
        (tmp_path / "pyproject.toml").write_text(
            '[project]\ndependencies = ["flask>=2.0"]\n'
        )
        assert _collect_deps(tmp_path) == ["flask==3.0"]

    def test_pyproject_without_dependencies(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text("[build-system]\nrequires = []\n")
        assert _collect_deps(tmp_path) == []

    def test_missing_directory(self, tmp_path):
        assert _collect_deps(tmp_path / "nonexistent") == []

    def test_empty_directory(self, tmp_path):
        assert _collect_deps(tmp_path) == []


class TestMergeRequirements:
    def test_merges_global_and_feature(self, tmp_path):
        global_dir = tmp_path / "global"
        feature_dir = tmp_path / "feature"
        global_dir.mkdir()
        feature_dir.mkdir()
        (global_dir / "requirements.txt").write_text("flask\nrequests\n")
        (feature_dir / "requirements.txt").write_text("boto3\nrequests\n")  # duplicate

        result = _merge_requirements(global_dir, feature_dir)
        lines = result.strip().split("\n")
        assert "flask" in lines
        assert "boto3" in lines
        assert "requests" in lines
        assert len(lines) == 3  # deduplicated

    def test_extra_packages(self, tmp_path):
        global_dir = tmp_path / "global"
        global_dir.mkdir()
        (global_dir / "requirements.txt").write_text("flask\n")

        result = _merge_requirements(global_dir, None, extra=["aws-wsgi"])
        assert "aws-wsgi" in result

    def test_missing_directory_ok(self, tmp_path):
        result = _merge_requirements(tmp_path / "nonexistent", None)
        assert result.strip() == ""

    def test_pyproject_toml_as_source(self, tmp_path):
        global_dir = tmp_path / "project"
        global_dir.mkdir()
        (global_dir / "pyproject.toml").write_text(
            '[project]\ndependencies = ["flask>=2.0", "boto3"]\n'
        )
        result = _merge_requirements(global_dir, None)
        assert "flask>=2.0" in result
        assert "boto3" in result

    def test_feature_pyproject_merged_with_global_requirements(self, tmp_path):
        global_dir = tmp_path / "project"
        feature_dir = tmp_path / "feature"
        global_dir.mkdir()
        feature_dir.mkdir()
        (global_dir / "requirements.txt").write_text("flask\nboto3\n")
        (feature_dir / "pyproject.toml").write_text(
            '[project]\ndependencies = ["pandas>=2.0"]\n'
        )
        result = _merge_requirements(global_dir, feature_dir)
        assert "flask" in result
        assert "boto3" in result
        assert "pandas>=2.0" in result

    def test_version_conflict_feature_wins(self, tmp_path, capsys):
        global_dir = tmp_path / "global"
        feature_dir = tmp_path / "feature"
        global_dir.mkdir()
        feature_dir.mkdir()
        (global_dir / "requirements.txt").write_text("flask>=2.0\n")
        (feature_dir / "requirements.txt").write_text("flask==3.0\n")

        result = _merge_requirements(global_dir, feature_dir)

        captured = capsys.readouterr()
        assert "WARNING" in captured.out
        assert "flask" in captured.out
        assert "flask==3.0" in result  # feature wins

    def test_deployless_excluded(self, tmp_path):
        global_dir = tmp_path / "global"
        global_dir.mkdir()
        (global_dir / "requirements.txt").write_text("flask\ndeployless\n")
        result = _merge_requirements(global_dir, None)
        assert "deployless" not in result


class TestBuildFeaturePackage:
    def test_creates_package(self, tmp_path):
        project_root = tmp_path
        feature_dir = tmp_path / "app" / "features" / "auth"
        feature_dir.mkdir(parents=True)
        (feature_dir / "routes.py").write_text("# routes")
        (feature_dir / "services.py").write_text("# services")
        (project_root / "requirements.txt").write_text("flask\n")

        dist_dir = tmp_path / ".dist"
        pkg = build_feature_package("auth", feature_dir, None, project_root, dist_dir)

        assert pkg.exists()
        assert (pkg / "app" / "features" / "auth" / "routes.py").exists()
        assert (pkg / "app" / "features" / "auth" / "services.py").exists()
        assert (pkg / "bootstrap.py").exists()
        assert (pkg / "requirements.txt").exists()
        assert "aws-wsgi" in (pkg / "requirements.txt").read_text()

    def test_copies_shared(self, tmp_path):
        project_root = tmp_path
        feature_dir = tmp_path / "app" / "features" / "auth"
        feature_dir.mkdir(parents=True)
        (feature_dir / "routes.py").write_text("")
        shared_dir = tmp_path / "app" / "shared"
        shared_dir.mkdir(parents=True)
        (shared_dir / "utils.py").write_text("# utils")
        (project_root / "requirements.txt").write_text("")

        dist_dir = tmp_path / ".dist"
        pkg = build_feature_package("auth", feature_dir, shared_dir, project_root, dist_dir)
        assert (pkg / "app" / "shared" / "utils.py").exists()


class TestBuildCronPackage:
    def test_creates_package(self, tmp_path):
        feature_dir = tmp_path / "app" / "features" / "tasks"
        feature_dir.mkdir(parents=True)
        (feature_dir / "routes.py").write_text("def cleanup(e, c): pass")
        (tmp_path / "requirements.txt").write_text("")

        cron = {
            "name": "cleanup",
            "module_file": str(feature_dir / "routes.py"),
        }

        dist_dir = tmp_path / ".dist"
        pkg = build_cron_package(cron, feature_dir, None, tmp_path, dist_dir)

        assert pkg.exists()
        assert (pkg / "bootstrap.py").exists()
        bootstrap = (pkg / "bootstrap.py").read_text()
        assert "cleanup" in bootstrap
        assert "from app.features.tasks.routes import cleanup" in bootstrap


class TestBuildLambdaPackage:
    def test_creates_package(self, tmp_path):
        feature_dir = tmp_path / "app" / "features" / "worker"
        feature_dir.mkdir(parents=True)
        (feature_dir / "handlers.py").write_text("def process(e, c): pass")
        (tmp_path / "requirements.txt").write_text("")

        lmb = {
            "name": "process",
            "module_file": str(feature_dir / "handlers.py"),
        }

        dist_dir = tmp_path / ".dist"
        pkg = build_lambda_package(lmb, feature_dir, None, tmp_path, dist_dir)

        assert pkg.exists()
        assert (pkg / "bootstrap.py").exists()
        bootstrap = (pkg / "bootstrap.py").read_text()
        assert "process" in bootstrap
        assert "from app.features.worker.handlers import process" in bootstrap

    def test_standalone_file_without_feature_dir(self, tmp_path):
        src_file = tmp_path / "worker.py"
        src_file.write_text("def handler(e, c): pass")
        (tmp_path / "requirements.txt").write_text("")

        lmb = {
            "name": "handler",
            "module_file": str(src_file),
        }

        dist_dir = tmp_path / ".dist"
        pkg = build_lambda_package(lmb, None, None, tmp_path, dist_dir)

        assert (pkg / "worker.py").exists()
        assert (pkg / "bootstrap.py").exists()


class TestHasFlaskCors:
    def test_detects_flask_cors_in_requirements(self, tmp_path):
        (tmp_path / "requirements.txt").write_text("flask\nflask-cors\n")
        assert _has_flask_cors(tmp_path, None) is True

    def test_detects_flask_cors_in_pyproject(self, tmp_path):
        (tmp_path / "pyproject.toml").write_text(
            '[project]\ndependencies = ["flask", "Flask-Cors>=4.0"]\n'
        )
        assert _has_flask_cors(tmp_path, None) is True

    def test_detects_flask_cors_in_feature_dir(self, tmp_path):
        project = tmp_path / "project"
        feature = tmp_path / "feature"
        project.mkdir()
        feature.mkdir()
        (project / "requirements.txt").write_text("flask\n")
        (feature / "requirements.txt").write_text("flask-cors\n")
        assert _has_flask_cors(project, feature) is True

    def test_returns_false_when_absent(self, tmp_path):
        (tmp_path / "requirements.txt").write_text("flask\nboto3\n")
        assert _has_flask_cors(tmp_path, None) is False


class TestBootstrapCors:
    def _make_feature(self, tmp_path):
        feature_dir = tmp_path / "app" / "features" / "auth"
        feature_dir.mkdir(parents=True)
        (feature_dir / "routes.py").write_text("# routes")
        (tmp_path / "requirements.txt").write_text("flask\n")
        return feature_dir

    def test_bootstrap_includes_cors_when_no_flask_cors(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        cors_config = {"allow_origin": "https://example.com"}
        dist_dir = tmp_path / ".dist"

        pkg = build_feature_package("auth", feature_dir, None, tmp_path, dist_dir, cors_config=cors_config)
        bootstrap = (pkg / "bootstrap.py").read_text()

        assert "_deployless_cors" in bootstrap
        assert "https://example.com" in bootstrap
        assert "Access-Control-Allow-Origin" in bootstrap

    def test_bootstrap_uses_default_cors_values(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        cors_config = {}
        dist_dir = tmp_path / ".dist"

        pkg = build_feature_package("auth", feature_dir, None, tmp_path, dist_dir, cors_config=cors_config)
        bootstrap = (pkg / "bootstrap.py").read_text()

        assert "'*'" in bootstrap
        assert "GET,POST,PUT,DELETE,OPTIONS" in bootstrap
        assert "Content-Type,Authorization" in bootstrap

    def test_bootstrap_cors_injected_even_when_flask_cors_present(self, tmp_path):
        # flask-cors in requirements does NOT suppress CORS injection — the bootstrap
        # creates its own Flask app and never calls create_app(), so flask-cors would
        # never be applied unless the user also registers it via init_app. The
        # _deployless_cors hook has an 'if header not set' guard, so if flask-cors
        # is applied via init_app it wins (LIFO order) and the deployless hook is no-op.
        feature_dir = self._make_feature(tmp_path)
        (tmp_path / "requirements.txt").write_text("flask\nflask-cors\n")
        cors_config = {"allow_origin": "*"}
        dist_dir = tmp_path / ".dist"

        pkg = build_feature_package("auth", feature_dir, None, tmp_path, dist_dir, cors_config=cors_config)
        bootstrap = (pkg / "bootstrap.py").read_text()

        assert "_deployless_cors" in bootstrap

    def test_bootstrap_no_cors_when_cors_config_none(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        dist_dir = tmp_path / ".dist"

        pkg = build_feature_package("auth", feature_dir, None, tmp_path, dist_dir, cors_config=None)
        bootstrap = (pkg / "bootstrap.py").read_text()

        assert "_deployless_cors" not in bootstrap

    def test_split_route_includes_cors(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        cors_config = {"allow_origin": "https://app.io"}
        dist_dir = tmp_path / ".dist"

        split = {"endpoint": "get-users", "feature": "auth", "feature_dir": feature_dir}
        pkg = build_split_route_package(split, feature_dir, None, tmp_path, dist_dir, cors_config=cors_config)
        bootstrap = (pkg / "bootstrap.py").read_text()

        assert "_deployless_cors" in bootstrap
        assert "https://app.io" in bootstrap


class TestRoutesImport:
    def test_flat_routes_py(self, tmp_path):
        routes_file = tmp_path / "app" / "features" / "todo" / "routes.py"
        routes_file.parent.mkdir(parents=True)
        routes_file.touch()
        result = _routes_import("todo", routes_file, tmp_path)
        assert result == "app.features.todo.routes"

    def test_routes_package_named_file(self, tmp_path):
        routes_file = tmp_path / "app" / "features" / "todo" / "routes" / "todo_routes.py"
        routes_file.parent.mkdir(parents=True)
        routes_file.touch()
        result = _routes_import("todo", routes_file, tmp_path)
        assert result == "app.features.todo.routes.todo_routes"

    def test_routes_package_other_name(self, tmp_path):
        routes_file = tmp_path / "app" / "features" / "auth" / "routes" / "auth.py"
        routes_file.parent.mkdir(parents=True)
        routes_file.touch()
        result = _routes_import("auth", routes_file, tmp_path)
        assert result == "app.features.auth.routes.auth"

    def test_no_routes_file_fallback(self, tmp_path):
        result = _routes_import("todo", None, tmp_path)
        assert result == "app.features.todo.routes"


class TestBootstrapRoutesPackage:
    def _make_feature_routes_pkg(self, tmp_path):
        """Feature with routes/ package instead of routes.py"""
        feature_dir = tmp_path / "app" / "features" / "todo"
        routes_dir = feature_dir / "routes"
        routes_dir.mkdir(parents=True)
        (routes_dir / "__init__.py").write_text("")
        routes_file = routes_dir / "todo_routes.py"
        routes_file.write_text("# routes")
        (tmp_path / "requirements.txt").write_text("flask\n")
        return feature_dir, routes_file

    def test_bootstrap_imports_correct_submodule(self, tmp_path):
        feature_dir, routes_file = self._make_feature_routes_pkg(tmp_path)
        dist_dir = tmp_path / ".dist"
        pkg = build_feature_package(
            "todo", feature_dir, None, tmp_path, dist_dir, routes_file=routes_file
        )
        bootstrap = (pkg / "bootstrap.py").read_text()
        assert "import app.features.todo.routes.todo_routes as _routes_module" in bootstrap

    def test_bootstrap_flat_routes_unchanged(self, tmp_path):
        feature_dir = tmp_path / "app" / "features" / "todo"
        feature_dir.mkdir(parents=True)
        routes_file = feature_dir / "routes.py"
        routes_file.write_text("# routes")
        (tmp_path / "requirements.txt").write_text("flask\n")
        dist_dir = tmp_path / ".dist"
        pkg = build_feature_package(
            "todo", feature_dir, None, tmp_path, dist_dir, routes_file=routes_file
        )
        bootstrap = (pkg / "bootstrap.py").read_text()
        assert "import app.features.todo.routes as _routes_module" in bootstrap


class TestBuildInitAppBlock:
    def test_generates_import_and_call(self):
        result = _build_init_app_block(["app.shared.errors.register_error_handlers"])
        assert "from app.shared.errors import register_error_handlers" in result
        assert "register_error_handlers(flask_app)" in result

    def test_multiple_entries(self):
        result = _build_init_app_block([
            "app.shared.errors.register_error_handlers",
            "app.shared.middleware.register_middleware",
        ])
        assert "from app.shared.errors import register_error_handlers" in result
        assert "register_error_handlers(flask_app)" in result
        assert "from app.shared.middleware import register_middleware" in result
        assert "register_middleware(flask_app)" in result

    def test_empty_list_returns_empty(self):
        assert _build_init_app_block([]) == ""

    def test_skips_invalid_entry(self):
        result = _build_init_app_block(["no_dot_here"])
        assert "import" not in result or result == ""


class TestBootstrapInitApp:
    def _make_feature(self, tmp_path):
        feature_dir = tmp_path / "app" / "features" / "auth"
        feature_dir.mkdir(parents=True)
        (feature_dir / "routes.py").write_text("# routes")
        (tmp_path / "requirements.txt").write_text("flask\n")
        return feature_dir

    def test_bootstrap_includes_init_app_hooks(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        dist_dir = tmp_path / ".dist"
        init_app = ["app.shared.errors.register_error_handlers"]

        pkg = build_feature_package("auth", feature_dir, None, tmp_path, dist_dir, init_app=init_app)
        bootstrap = (pkg / "bootstrap.py").read_text()

        assert "from app.shared.errors import register_error_handlers" in bootstrap
        assert "register_error_handlers(flask_app)" in bootstrap

    def test_bootstrap_no_init_app_when_empty(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        dist_dir = tmp_path / ".dist"

        pkg = build_feature_package("auth", feature_dir, None, tmp_path, dist_dir, init_app=[])
        bootstrap = (pkg / "bootstrap.py").read_text()

        assert "initialization hooks" not in bootstrap

    def test_split_route_includes_init_app(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        dist_dir = tmp_path / ".dist"
        init_app = ["app.shared.errors.register_error_handlers"]

        split = {"endpoint": "get-users", "feature": "auth", "feature_dir": feature_dir}
        pkg = build_split_route_package(split, feature_dir, None, tmp_path, dist_dir, init_app=init_app)
        bootstrap = (pkg / "bootstrap.py").read_text()

        assert "from app.shared.errors import register_error_handlers" in bootstrap
        assert "register_error_handlers(flask_app)" in bootstrap


class TestBuildCorsBlock:
    def test_returns_empty_when_none(self):
        assert _build_cors_block(None) == ""

    def test_contains_after_request_decorator(self):
        result = _build_cors_block({"allow_origin": "*"})
        assert "@flask_app.after_request" in result
        assert "_deployless_cors" in result

    def test_uses_provided_origin(self):
        result = _build_cors_block({"allow_origin": "https://example.com"})
        assert "https://example.com" in result

    def test_uses_default_origin_when_empty_config(self):
        result = _build_cors_block({})
        assert "'*'" in result

    def test_uses_provided_methods(self):
        result = _build_cors_block({"allow_methods": ["GET", "POST"]})
        assert "GET,POST" in result

    def test_uses_provided_headers(self):
        result = _build_cors_block({"allow_headers": ["X-Custom-Header"]})
        assert "X-Custom-Header" in result

    def test_guard_checks_existing_header(self):
        result = _build_cors_block({"allow_origin": "*"})
        assert "Access-Control-Allow-Origin" in result
        assert "not in response.headers" in result


class TestSetupAppNamespace:
    def _make_feature(self, tmp_path):
        feature_dir = tmp_path / "app" / "features" / "todo"
        feature_dir.mkdir(parents=True)
        (feature_dir / "routes.py").write_text("# routes")
        return feature_dir

    def test_writes_empty_init_without_app_init_file(self, tmp_path):
        from deployless.providers.aws.packager import _setup_app_namespace
        feature_dir = self._make_feature(tmp_path)
        pkg_dir = tmp_path / "pkg"
        pkg_dir.mkdir()
        _setup_app_namespace(pkg_dir, "todo", feature_dir, None, app_init_file=None)
        assert (pkg_dir / "app" / "__init__.py").read_text() == ""

    def test_copies_real_app_init_when_provided(self, tmp_path):
        from deployless.providers.aws.packager import _setup_app_namespace
        feature_dir = self._make_feature(tmp_path)
        app_init = tmp_path / "real_init.py"
        app_init.write_text("def create_app(): pass")
        pkg_dir = tmp_path / "pkg"
        pkg_dir.mkdir()
        _setup_app_namespace(pkg_dir, "todo", feature_dir, None, app_init_file=app_init)
        assert (pkg_dir / "app" / "__init__.py").read_text() == "def create_app(): pass"

    def test_ignores_nonexistent_app_init_file(self, tmp_path):
        from deployless.providers.aws.packager import _setup_app_namespace
        feature_dir = self._make_feature(tmp_path)
        nonexistent = tmp_path / "does_not_exist.py"
        pkg_dir = tmp_path / "pkg"
        pkg_dir.mkdir()
        _setup_app_namespace(pkg_dir, "todo", feature_dir, None, app_init_file=nonexistent)
        assert (pkg_dir / "app" / "__init__.py").read_text() == ""


class TestGenerateFeatureStubs:
    def _make_pkg_app_dir(self, tmp_path):
        pkg_app_dir = tmp_path / "app"
        (pkg_app_dir / "features").mkdir(parents=True)
        return pkg_app_dir

    def test_creates_stub_for_other_features(self, tmp_path):
        pkg_app_dir = self._make_pkg_app_dir(tmp_path)
        other_features = [
            {"name": "auth", "dir": tmp_path / "auth", "routes_file": tmp_path / "auth" / "routes.py"},
            {"name": "user", "dir": tmp_path / "user", "routes_file": tmp_path / "user" / "routes.py"},
        ]
        _generate_feature_stubs(pkg_app_dir, "todo", other_features)
        assert (pkg_app_dir / "features" / "auth" / "routes.py").exists()
        assert (pkg_app_dir / "features" / "user" / "routes.py").exists()

    def test_does_not_stub_own_feature(self, tmp_path):
        pkg_app_dir = self._make_pkg_app_dir(tmp_path)
        other_features = [
            {"name": "todo", "dir": tmp_path / "todo", "routes_file": tmp_path / "todo" / "routes.py"},
        ]
        _generate_feature_stubs(pkg_app_dir, "todo", other_features)
        assert not (pkg_app_dir / "features" / "todo").exists()

    def test_stub_contains_getattr(self, tmp_path):
        pkg_app_dir = self._make_pkg_app_dir(tmp_path)
        other_features = [
            {"name": "auth", "dir": tmp_path / "auth", "routes_file": tmp_path / "auth" / "routes.py"},
        ]
        _generate_feature_stubs(pkg_app_dir, "todo", other_features)
        stub = (pkg_app_dir / "features" / "auth" / "routes.py").read_text()
        assert "__getattr__" in stub
        assert "_Blueprint" in stub

    def test_stub_returns_blueprint_on_import(self, tmp_path):
        import importlib.util
        pkg_app_dir = self._make_pkg_app_dir(tmp_path)
        other_features = [
            {"name": "auth", "dir": tmp_path / "auth", "routes_file": tmp_path / "auth" / "routes.py"},
        ]
        _generate_feature_stubs(pkg_app_dir, "todo", other_features)
        stub_file = pkg_app_dir / "features" / "auth" / "routes.py"
        spec = importlib.util.spec_from_file_location("_test_stub_auth_routes", stub_file)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        result = mod.auth_bp
        assert result.__class__.__name__ == "Blueprint"

    def test_stub_with_routes_subpackage(self, tmp_path):
        pkg_app_dir = self._make_pkg_app_dir(tmp_path)
        auth_dir = tmp_path / "auth"
        routes_file = auth_dir / "routes" / "auth_routes.py"
        other_features = [
            {"name": "auth", "dir": auth_dir, "routes_file": routes_file},
        ]
        _generate_feature_stubs(pkg_app_dir, "todo", other_features)
        assert (pkg_app_dir / "features" / "auth" / "routes" / "auth_routes.py").exists()
        assert (pkg_app_dir / "features" / "auth" / "routes" / "__init__.py").exists()

    def test_multiple_stubs_produce_unique_blueprint_names(self, tmp_path):
        """Regression: multiple stubs exporting `bp` must not collide on blueprint name."""
        import importlib.util

        from flask import Flask

        pkg_app_dir = self._make_pkg_app_dir(tmp_path)
        other_features = [
            {"name": "links", "dir": tmp_path / "links", "routes_file": tmp_path / "links" / "routes.py"},
            {"name": "groups", "dir": tmp_path / "groups", "routes_file": tmp_path / "groups" / "routes.py"},
        ]
        _generate_feature_stubs(pkg_app_dir, "auth", other_features)

        # Import both stubs and access the same attribute name (bp)
        stubs = []
        for feat in ("links", "groups"):
            stub_file = pkg_app_dir / "features" / feat / "routes.py"
            mod_name = f"app.features.{feat}.routes"
            spec = importlib.util.spec_from_file_location(mod_name, stub_file)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            stubs.append(mod.bp)

        # Blueprint names must differ
        assert stubs[0].name != stubs[1].name

        # Both must register without ValueError
        app = Flask(__name__)
        app.register_blueprint(stubs[0])
        app.register_blueprint(stubs[1])

    def test_stub_falls_back_to_routes_py_when_no_routes_file(self, tmp_path):
        pkg_app_dir = self._make_pkg_app_dir(tmp_path)
        other_features = [
            {"name": "auth", "dir": tmp_path / "auth", "routes_file": None},
        ]
        _generate_feature_stubs(pkg_app_dir, "todo", other_features)
        assert (pkg_app_dir / "features" / "auth" / "routes.py").exists()


class TestBootstrapFactory:
    def _make_feature(self, tmp_path):
        feature_dir = tmp_path / "app" / "features" / "auth"
        feature_dir.mkdir(parents=True)
        (feature_dir / "routes.py").write_text("# routes")
        (tmp_path / "requirements.txt").write_text("flask\n")
        return feature_dir

    def test_bootstrap_has_create_app_try(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        pkg = build_feature_package("auth", feature_dir, None, tmp_path, tmp_path / ".dist")
        bootstrap = (pkg / "bootstrap.py").read_text()
        assert "from app import create_app" in bootstrap
        assert "try:" in bootstrap

    def test_bootstrap_has_except_fallback(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        pkg = build_feature_package("auth", feature_dir, None, tmp_path, tmp_path / ".dist")
        bootstrap = (pkg / "bootstrap.py").read_text()
        assert "except (ImportError, AttributeError)" in bootstrap
        assert "Using manual bootstrap" in bootstrap

    def test_fallback_cors_block_present_when_cors_config(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        cors_config = {"allow_origin": "https://app.io"}
        pkg = build_feature_package("auth", feature_dir, None, tmp_path, tmp_path / ".dist", cors_config=cors_config)
        bootstrap = (pkg / "bootstrap.py").read_text()
        assert "_deployless_cors" in bootstrap
        assert "https://app.io" in bootstrap

    def test_fallback_no_cors_block_when_no_cors_config(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        pkg = build_feature_package("auth", feature_dir, None, tmp_path, tmp_path / ".dist", cors_config=None)
        bootstrap = (pkg / "bootstrap.py").read_text()
        assert "_deployless_cors" not in bootstrap

    def test_cors_block_is_inside_except_not_at_top_level(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        cors_config = {"allow_origin": "*"}
        pkg = build_feature_package("auth", feature_dir, None, tmp_path, tmp_path / ".dist", cors_config=cors_config)
        bootstrap = (pkg / "bootstrap.py").read_text()
        # The @after_request decorator must appear AFTER the except line
        except_pos = bootstrap.find("except (ImportError")
        cors_pos = bootstrap.find("_deployless_cors")
        assert cors_pos > except_pos

    def test_init_app_is_inside_except_block(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        init_app = ["app.shared.errors.register_error_handlers"]
        pkg = build_feature_package("auth", feature_dir, None, tmp_path, tmp_path / ".dist", init_app=init_app)
        bootstrap = (pkg / "bootstrap.py").read_text()
        # init_app hook must appear AFTER the except line
        except_pos = bootstrap.find("except (ImportError")
        hook_pos = bootstrap.find("register_error_handlers")
        assert hook_pos > except_pos

    def test_split_route_bootstrap_has_create_app_try(self, tmp_path):
        feature_dir = self._make_feature(tmp_path)
        split = {"endpoint": "get-auth", "feature": "auth", "feature_dir": feature_dir}
        pkg = build_split_route_package(split, feature_dir, None, tmp_path, tmp_path / ".dist")
        bootstrap = (pkg / "bootstrap.py").read_text()
        assert "from app import create_app" in bootstrap


class TestFeatureStubsIntegration:
    """Integration tests: build_feature_package with other_features generates stubs."""

    def _make_project(self, tmp_path):
        for feature in ["todo", "auth", "user"]:
            d = tmp_path / "app" / "features" / feature
            d.mkdir(parents=True)
            (d / "routes.py").write_text(f"# {feature} routes")
        (tmp_path / "requirements.txt").write_text("flask\n")

    def test_stubs_created_for_other_features(self, tmp_path):
        self._make_project(tmp_path)
        feature_dir = tmp_path / "app" / "features" / "todo"
        other_features = [
            {"name": "todo", "dir": tmp_path / "app" / "features" / "todo",
             "routes_file": tmp_path / "app" / "features" / "todo" / "routes.py"},
            {"name": "auth", "dir": tmp_path / "app" / "features" / "auth",
             "routes_file": tmp_path / "app" / "features" / "auth" / "routes.py"},
            {"name": "user", "dir": tmp_path / "app" / "features" / "user",
             "routes_file": tmp_path / "app" / "features" / "user" / "routes.py"},
        ]
        pkg = build_feature_package(
            "todo", feature_dir, None, tmp_path, tmp_path / ".dist",
            other_features=other_features,
        )
        assert (pkg / "app" / "features" / "auth" / "routes.py").exists()
        assert (pkg / "app" / "features" / "user" / "routes.py").exists()

    def test_own_feature_has_real_code_not_stub(self, tmp_path):
        self._make_project(tmp_path)
        feature_dir = tmp_path / "app" / "features" / "todo"
        other_features = [
            {"name": "todo", "dir": feature_dir,
             "routes_file": feature_dir / "routes.py"},
            {"name": "auth", "dir": tmp_path / "app" / "features" / "auth",
             "routes_file": tmp_path / "app" / "features" / "auth" / "routes.py"},
        ]
        pkg = build_feature_package(
            "todo", feature_dir, None, tmp_path, tmp_path / ".dist",
            other_features=other_features,
        )
        todo_routes = (pkg / "app" / "features" / "todo" / "routes.py").read_text()
        assert "__getattr__" not in todo_routes
        assert "# todo routes" in todo_routes

    def test_app_init_copied_when_provided(self, tmp_path):
        self._make_project(tmp_path)
        app_init = tmp_path / "app" / "__init__.py"
        app_init.parent.mkdir(parents=True, exist_ok=True)
        app_init.write_text("def create_app(): return None")
        feature_dir = tmp_path / "app" / "features" / "todo"
        pkg = build_feature_package(
            "todo", feature_dir, None, tmp_path, tmp_path / ".dist",
            app_init_file=app_init,
        )
        assert (pkg / "app" / "__init__.py").read_text() == "def create_app(): return None"
