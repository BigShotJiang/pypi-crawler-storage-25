"""Wire-level types for the otto RPC protocol.

Mirrors sdk/src/protocol.ts. We use TypedDicts rather than pydantic models so
the SDK has zero runtime dependencies; callers can swap to pydantic at their
boundary if they want validation.
"""

from __future__ import annotations

from typing import Any, Literal, TypedDict

# Values accepted by the agent's thinking-level knob.
ThinkingLevel = Literal["off", "minimal", "low", "medium", "high", "xhigh"]


# ─── Commands (stdin) ────────────────────────────────────────────────────────


class _PromptCommand(TypedDict, total=False):
    id: str
    type: Literal["prompt"]
    message: str
    images: list[dict[str, Any]]


class _SteerCommand(TypedDict, total=False):
    id: str
    type: Literal["steer"]
    message: str
    images: list[dict[str, Any]]


class _FollowUpCommand(TypedDict, total=False):
    id: str
    type: Literal["follow_up"]
    message: str
    images: list[dict[str, Any]]


class _AbortCommand(TypedDict, total=False):
    id: str
    type: Literal["abort"]


class _GetStateCommand(TypedDict, total=False):
    id: str
    type: Literal["get_state"]


class _GetLastAssistantTextCommand(TypedDict, total=False):
    id: str
    type: Literal["get_last_assistant_text"]


# `RpcCommand` is a structural dict at runtime. Keep the alias liberal — we
# construct commands by hand internally rather than relying on static dispatch.
RpcCommand = dict[str, Any]


# ─── Responses (stdout) ──────────────────────────────────────────────────────


class RpcResponse(TypedDict, total=False):
    """Response to a previously-sent command (correlated by `id`)."""

    id: str
    type: Literal["response"]
    command: str
    success: bool
    data: Any
    error: str


# ─── Session state ───────────────────────────────────────────────────────────


class RpcSessionState(TypedDict, total=False):
    model: dict[str, Any]
    thinkingLevel: str
    isStreaming: bool
    isCompacting: bool
    steeringMode: Literal["all", "one-at-a-time"]
    followUpMode: Literal["all", "one-at-a-time"]
    sessionFile: str
    sessionId: str
    sessionName: str
    autoCompactionEnabled: bool
    messageCount: int
    pendingMessageCount: int


# ─── Streaming agent events ──────────────────────────────────────────────────


class AgentMessage(TypedDict, total=False):
    role: Literal["user", "assistant", "tool"]
    content: Any


class AgentEvent(TypedDict, total=False):
    """One streaming event from the agent.

    At runtime this is a plain dict with a required `type` key. Narrow on
    `event["type"]` (e.g. with match/case) to access variant-specific fields.
    """

    type: str
    # Union of all fields across variants — keep total=False so narrowing is by type.
    messages: list[AgentMessage]
    message: AgentMessage
    assistantMessageEvent: Any
    toolResults: list[Any]
    toolCallId: str
    toolName: str
    args: Any
    partialResult: Any
    result: Any
    isError: bool


# ─── Extension UI requests ───────────────────────────────────────────────────


class ExtensionUIRequest(TypedDict, total=False):
    type: Literal["extension_ui_request"]
    id: str
    method: str
    title: str
    message: str
    options: list[str]
    placeholder: str
    prefill: str
    notifyType: Literal["info", "warning", "error"]
    statusKey: str
    statusText: str
    widgetKey: str
    widgetLines: list[str]
    widgetPlacement: Literal["aboveEditor", "belowEditor"]
