"""astronomer-otto-sdk — Python SDK for the otto agent binary.

Two shapes:
    - `query(...)`  → async iterator of AgentEvent (one-shot)
    - `OttoClient`  → async context manager for multi-turn sessions

Both spawn the otto binary in --rpc mode and talk JSON-lines over stdin/stdout.
"""

from otto_sdk.binary import OttoBinaryNotFoundError, resolve_otto_binary
from otto_sdk.client import OttoClient, OttoClientError
from otto_sdk.options import OttoOptions, QueryOptions
from otto_sdk.protocol import (
    AgentEvent,
    AgentMessage,
    ExtensionUIRequest,
    RpcResponse,
    RpcSessionState,
    ThinkingLevel,
)
from otto_sdk.query import FINAL_ANSWER_TOOL_NAME, QueryResult, query, run_query

__all__ = [
    "FINAL_ANSWER_TOOL_NAME",
    "AgentEvent",
    "AgentMessage",
    "ExtensionUIRequest",
    "OttoBinaryNotFoundError",
    "OttoClient",
    "OttoClientError",
    "OttoOptions",
    "QueryOptions",
    "QueryResult",
    "RpcResponse",
    "RpcSessionState",
    "ThinkingLevel",
    "query",
    "resolve_otto_binary",
    "run_query",
]
