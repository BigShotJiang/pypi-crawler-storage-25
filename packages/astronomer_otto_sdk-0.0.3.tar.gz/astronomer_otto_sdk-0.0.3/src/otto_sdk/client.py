"""OttoClient — spawns the otto binary in --rpc mode and exposes an asyncio
API for multi-turn interaction.

Mirrors sdk/src/client.ts. Wire protocol is JSON-lines over stdin/stdout.
"""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from otto_sdk.binary import build_env, resolve_otto_binary
from otto_sdk.options import OttoOptions
from otto_sdk.protocol import (
    AgentEvent,
    ExtensionUIRequest,
    RpcCommand,
    RpcResponse,
    RpcSessionState,
    ThinkingLevel,
)


class OttoClientError(RuntimeError):
    """Raised when the otto subprocess errors out or returns a failed response."""


EventListener = Callable[[AgentEvent], None]
ExtensionUIHandler = Callable[[ExtensionUIRequest], Awaitable[dict[str, Any]]]

# Bumps StreamReader's default 64KB line limit so readline() can handle large JSONL events.
_STDOUT_LINE_LIMIT_BYTES = 64 * 1024 * 1024


@dataclass
class _Pending:
    future: asyncio.Future[RpcResponse]


class OttoClient:
    """Async client for the otto --rpc subprocess.

    Usage:
        async with OttoClient(cwd="./project") as client:
            await client.prompt("list the DAGs")
            async for event in client.events():
                ...
    """

    def __init__(self, options: OttoOptions | None = None) -> None:
        self.options = options or OttoOptions()
        self._proc: asyncio.subprocess.Process | None = None
        self._reader_task: asyncio.Task[None] | None = None
        self._stderr_task: asyncio.Task[None] | None = None
        self._event_listeners: list[EventListener] = []
        self._event_queue: asyncio.Queue[AgentEvent | None] = asyncio.Queue()
        self._pending: dict[str, _Pending] = {}
        self._request_counter = 0
        self._stderr_buffer = ""
        self._reader_error: str | None = None
        self._ext_ui_handler: ExtensionUIHandler | None = None
        self._started = False
        self._mcp_config_tmpdir: tempfile.TemporaryDirectory[str] | None = None
        self._system_prompt_tmpdir: tempfile.TemporaryDirectory[str] | None = None
        self._permissions_config_path: Path | None = None
        self._permissions_config_backup: str | None = None

    # ─── lifecycle ──────────────────────────────────────────────────────────

    async def __aenter__(self) -> OttoClient:
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.stop()

    async def start(self) -> None:
        """Spawn the otto subprocess. Idempotent within a client instance."""
        if self._started:
            return
        self._started = True

        binary = resolve_otto_binary(self.options.otto_path)

        args = ["--rpc"]
        if self.options.provider:
            args += ["--provider", self.options.provider]
        if self.options.model:
            args += ["--model", self.options.model]
        if self.options.no_session:
            args.append("--no-session")
        if self.options.session_path:
            args += ["--session", self.options.session_path]
        if self.options.allowed_tools is not None:
            tools = list(self.options.allowed_tools)
            if self.options.output_schema and "submit_final_answer" not in tools:
                tools.append("submit_final_answer")
            args += ["--allowed-tools", ",".join(tools)]
        if self.options.allowed_skills is not None:
            args += ["--allowed-skills", ",".join(self.options.allowed_skills)]
        if self.options.permissions_config is not None:
            # Otto reads project-local permissions from {cwd}/.astro/otto/permissions.json.
            cwd = self.options.cwd or os.getcwd()
            permissions_dir = Path(cwd) / ".astro" / "otto"
            permissions_dir.mkdir(parents=True, exist_ok=True)
            self._permissions_config_path = permissions_dir / "permissions.json"
            if self._permissions_config_path.exists():
                self._permissions_config_backup = self._permissions_config_path.read_text()
            self._permissions_config_path.write_text(
                json.dumps(self.options.permissions_config, indent=2)
            )
        if self.options.output_schema is not None:
            args += ["--output-schema", json.dumps(self.options.output_schema)]
        if self.options.system_prompt is not None:
            self._system_prompt_tmpdir = tempfile.TemporaryDirectory(prefix="otto-sysprompt-")
            system_prompt_path = Path(self._system_prompt_tmpdir.name) / "system_prompt.md"
            system_prompt_path.write_text(self.options.system_prompt, encoding="utf-8")
            args += ["--system-prompt", str(system_prompt_path)]
        if self.options.mcp_servers is not None:
            self._mcp_config_tmpdir = tempfile.TemporaryDirectory(prefix="otto-mcp-")
            config_path = Path(self._mcp_config_tmpdir.name) / "mcp.json"
            config_path.write_text(json.dumps({"mcpServers": self.options.mcp_servers}))
            args += ["--mcp-config", str(config_path)]
        args += self.options.extra_args

        env = build_env(self.options.env)

        self._proc = await asyncio.create_subprocess_exec(
            binary,
            *args,
            cwd=self.options.cwd,
            env=env,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=_STDOUT_LINE_LIMIT_BYTES,
        )

        self._reader_task = asyncio.create_task(self._read_stdout(), name="otto-sdk-reader")
        self._stderr_task = asyncio.create_task(self._read_stderr(), name="otto-sdk-stderr")

        # Give the process a moment to initialize and surface startup errors.
        await asyncio.sleep(0.1)
        if self._proc.returncode is not None:
            error = OttoClientError(
                f"otto exited immediately with code {self._proc.returncode}. "
                f"Stderr: {self._stderr_buffer}"
            )
            await self.stop()
            raise error

        # Apply startup-time RPC adjustments.
        if self.options.thinking_level is not None:
            await self.set_thinking_level(self.options.thinking_level)

    async def set_thinking_level(self, level: ThinkingLevel) -> None:
        """Set the agent's thinking level (off/minimal/low/medium/high/xhigh)."""
        res = await self._send({"type": "set_thinking_level", "level": level})
        if not res.get("success"):
            raise OttoClientError(res.get("error", "set_thinking_level failed"))

    async def stop(self) -> None:
        """Terminate the subprocess and release resources."""
        if self._proc is None:
            return

        # Fail any outstanding requests so callers unblock.
        process_returncode = getattr(self._proc, "returncode", None)
        for pending in self._pending.values():
            if not pending.future.done():
                pending.future.set_exception(
                    OttoClientError(
                        f"client stopped. Returncode: {process_returncode}. "
                        f"Stderr: {self._stderr_buffer}"
                    )
                )
        self._pending.clear()

        # Unblock anyone iterating events().
        await self._event_queue.put(None)

        try:
            self._proc.terminate()
        except ProcessLookupError:
            pass

        try:
            await asyncio.wait_for(self._proc.wait(), timeout=1.0)
        except asyncio.TimeoutError:
            try:
                self._proc.kill()
            except ProcessLookupError:
                pass
            await self._proc.wait()

        for task in (self._reader_task, self._stderr_task):
            if task is not None:
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass

        self._proc = None
        self._reader_task = None
        self._stderr_task = None
        self._started = False

        if self._mcp_config_tmpdir is not None:
            try:
                self._mcp_config_tmpdir.cleanup()
            except Exception:  # noqa: BLE001
                pass
            self._mcp_config_tmpdir = None

        if self._system_prompt_tmpdir is not None:
            try:
                self._system_prompt_tmpdir.cleanup()
            except Exception:  # noqa: BLE001
                pass
            self._system_prompt_tmpdir = None

        if self._permissions_config_path is not None:
            try:
                if self._permissions_config_backup is not None:
                    self._permissions_config_path.write_text(self._permissions_config_backup)
                else:
                    self._permissions_config_path.unlink(missing_ok=True)
            except Exception:  # noqa: BLE001
                pass
            self._permissions_config_path = None
            self._permissions_config_backup = None

    # ─── event streaming ────────────────────────────────────────────────────

    def on_event(self, listener: EventListener) -> Callable[[], None]:
        """Register a listener for streaming agent events. Returns an unsubscribe callable."""
        self._event_listeners.append(listener)

        def unsubscribe() -> None:
            if listener in self._event_listeners:
                self._event_listeners.remove(listener)

        return unsubscribe

    def on_extension_ui_request(self, handler: ExtensionUIHandler) -> None:
        """Handle extension UI requests (select/confirm/input/etc.).

        If unset, requests are auto-cancelled so the agent never blocks.
        """
        self._ext_ui_handler = handler

    @property
    def stderr(self) -> str:
        return self._stderr_buffer

    async def events(self, timeout: float = 600.0) -> AsyncIterator[AgentEvent]:
        """Yield events until `agent_end` or timeout.

        Call this after `prompt()`/`follow_up()` to consume the stream for
        that turn. Raises OttoClientError if the process exits unexpectedly.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout

        while True:
            remaining = deadline - loop.time()
            if remaining <= 0:
                process_returncode = self._proc.returncode if self._proc is not None else None
                raise OttoClientError(
                    f"Timed out after {timeout}s waiting for agent_end. "
                    f"Returncode: {process_returncode}."
                )

            try:
                event = await asyncio.wait_for(self._event_queue.get(), timeout=remaining)
            except asyncio.TimeoutError as e:
                process_returncode = self._proc.returncode if self._proc is not None else None
                raise OttoClientError(
                    f"Timed out after {timeout}s waiting for agent_end. "
                    f"Returncode: {process_returncode}."
                ) from e

            if event is None:  # sentinel — process exited or stdout reader failed
                process_returncode = self._proc.returncode if self._proc is not None else None
                if self._reader_error:
                    raise OttoClientError(
                        f"{self._reader_error}. Returncode: {process_returncode}. "
                        f"Stderr: {self._stderr_buffer}"
                    )
                raise OttoClientError(
                    f"otto exited while awaiting events. Returncode: {process_returncode}. "
                    f"Stderr: {self._stderr_buffer}"
                )

            yield event

            if event.get("type") == "agent_end":
                return

    # ─── commands ───────────────────────────────────────────────────────────

    async def prompt(self, message: str, images: list[dict[str, Any]] | None = None) -> None:
        """Send a user prompt. Does not wait for completion — iterate events() for that."""
        cmd: RpcCommand = {"type": "prompt", "message": message}
        if images is not None:
            cmd["images"] = images
        await self._send(cmd)

    async def steer(self, message: str, images: list[dict[str, Any]] | None = None) -> None:
        """Queue a steering message to interrupt the agent mid-run."""
        cmd: RpcCommand = {"type": "steer", "message": message}
        if images is not None:
            cmd["images"] = images
        await self._send(cmd)

    async def follow_up(self, message: str, images: list[dict[str, Any]] | None = None) -> None:
        """Queue a follow-up message to run after the current turn."""
        cmd: RpcCommand = {"type": "follow_up", "message": message}
        if images is not None:
            cmd["images"] = images
        await self._send(cmd)

    async def abort(self) -> None:
        """Abort the currently running operation."""
        await self._send({"type": "abort"})

    async def get_state(self) -> RpcSessionState:
        """Get current session state."""
        res = await self._send({"type": "get_state"})
        if not res.get("success"):
            raise OttoClientError(res.get("error", "unknown error"))
        return res["data"]

    async def get_last_assistant_text(self) -> str | None:
        """Get the text of the last assistant message, or None."""
        res = await self._send({"type": "get_last_assistant_text"})
        if not res.get("success"):
            raise OttoClientError(res.get("error", "unknown error"))
        data = res.get("data") or {}
        return data.get("text")

    # ─── internals ──────────────────────────────────────────────────────────

    async def _send(self, cmd: RpcCommand) -> RpcResponse:
        if self._proc is None or self._proc.stdin is None:
            raise OttoClientError("client not started")
        self._request_counter += 1
        req_id = str(self._request_counter)
        payload = {**cmd, "id": req_id}

        loop = asyncio.get_running_loop()
        fut: asyncio.Future[RpcResponse] = loop.create_future()
        self._pending[req_id] = _Pending(future=fut)

        line = (json.dumps(payload) + "\n").encode("utf-8")
        try:
            self._proc.stdin.write(line)
            await self._proc.stdin.drain()
        except Exception as e:
            self._pending.pop(req_id, None)
            raise OttoClientError(f"failed to write to otto stdin: {e}") from e

        return await fut

    async def _read_stdout(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        try:
            while line_bytes := await self._proc.stdout.readline():
                line = line_bytes.decode("utf-8", errors="replace").rstrip("\r\n")
                if line:
                    self._handle_line(line)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            self._reader_error = f"failed to read otto stdout: {type(e).__name__}: {e}"
        self._event_queue.put_nowait(None)

    async def _read_stderr(self) -> None:
        assert self._proc is not None and self._proc.stderr is not None
        try:
            while True:
                chunk = await self._proc.stderr.read(4096)
                if not chunk:
                    return
                text = chunk.decode("utf-8", errors="replace")
                self._stderr_buffer += text
                if self.options.on_stderr is not None:
                    self.options.on_stderr(text)
        except asyncio.CancelledError:
            raise
        except Exception:
            return

    def _handle_line(self, line: str) -> None:
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            return  # ignore non-JSON noise
        if not isinstance(msg, dict):
            return

        msg_type = msg.get("type")

        if msg_type == "response":
            req_id = msg.get("id")
            if req_id and req_id in self._pending:
                pending = self._pending.pop(req_id)
                if not pending.future.done():
                    pending.future.set_result(msg)
            return

        if msg_type == "extension_ui_request":
            asyncio.create_task(self._handle_ext_ui_request(msg))
            return

        # Anything else is a streaming AgentEvent.
        event: AgentEvent = msg
        for listener in list(self._event_listeners):
            try:
                listener(event)
            except Exception:  # noqa: BLE001 — listener errors must not break the loop
                pass
        self._event_queue.put_nowait(event)

    async def _handle_ext_ui_request(self, req: ExtensionUIRequest) -> None:
        if self._proc is None or self._proc.stdin is None:
            return

        payload: dict[str, Any]
        if self._ext_ui_handler is not None:
            try:
                payload = await self._ext_ui_handler(req)
            except Exception:  # noqa: BLE001
                payload = {"cancelled": True}
        else:
            payload = {"cancelled": True}

        response = {
            "type": "extension_ui_response",
            "id": req.get("id"),
            **payload,
        }
        try:
            self._proc.stdin.write((json.dumps(response) + "\n").encode("utf-8"))
            await self._proc.stdin.drain()
        except Exception:  # noqa: BLE001
            pass
