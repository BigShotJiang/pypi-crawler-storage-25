"""Options dataclasses for the Python SDK.

Mirrors sdk/src/options.ts.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from otto_sdk.protocol import ThinkingLevel


@dataclass
class OttoOptions:
    """Options for OttoClient and query()."""

    # Absolute path to the otto binary. If None, resolved via OTTO_PATH,
    # ~/.astro/bin/otto, then PATH.
    otto_path: str | None = None

    # Working directory for the agent. Defaults to os.getcwd().
    cwd: str | None = None

    # Env var overrides. Merged on top of forwarded ASTRO_*, AIRFLOW_*, OTTO_*
    # vars from the caller's environment. Set a key to None to unset a
    # forwarded var.
    env: dict[str, str | None] | None = None

    # Provider name. Defaults to "astronomer".
    provider: str | None = None

    # Model id. If None, otto's current default model is used.
    model: str | None = None

    # If True, starts with --no-session so nothing is persisted to
    # ~/.astro/otto/sessions/. Defaults to True for query(), False for OttoClient.
    no_session: bool = False

    # Path to an existing session .jsonl file to resume. Maps to `--session <path>`.
    # Mutually exclusive with no_session.
    session_path: str | None = None

    # Thinking-level override applied right after the client starts.
    # Valid values: "off", "minimal", "low", "medium", "high", "xhigh".
    # If None, otto's default is used.
    thinking_level: ThinkingLevel | None = None

    # MCP server configurations. When set, the SDK writes the config to a temp
    # file and passes `--mcp-config <path>` to the otto subprocess.
    #
    # Format matches the standard MCP config shape (same as Claude Code / Cursor):
    #
    #   mcp_servers={
    #       "docs": {"url": "http://...", "headers": {"Authorization": "Bearer ..."}},
    #       "my-tool": {"command": "npx", "args": ["-y", "my-mcp-server"]},
    #   }
    mcp_servers: dict[str, dict[str, Any]] | None = None

    # Tool allowlist. When set, only these tools are available to the agent —
    # disabled tools are removed from the model's view entirely (including the
    # system prompt).
    #
    # Glob-suffix wildcards work for MCP tool prefixes:
    #     allowed_tools=["read", "grep", "glob", "ls", "mcp__docs__*"]
    #
    # `submit_final_answer` is always allowed when `output_schema` is set.
    allowed_tools: list[str] | None = None

    # Hosted-skill allowlist for the `skill` tool. [] disables hosted skills;
    # None allows all. Dedicated skill tools are controlled via allowed_tools.
    allowed_skills: list[str] | None = None

    # Permissions configuration for Otto's built-in permission layer. When set,
    # the SDK writes this as `.astro/otto/permissions.json` in the working
    # directory; Otto loads it as the project-local scope.
    #
    # Example: deny common interpreters and stay inside the project directory.
    #     permissions_config={
    #         "rules": {
    #             "deny": ["Bash(python:*)", "Bash(pip:*)", "Bash(node:*)", "Bash(npm:*)"],
    #         },
    #         "restrictToProjectDir": True,
    #     }
    permissions_config: dict[str, Any] | None = None

    # Replaces Otto's entire system prompt. When set, extension prompt additions
    # (commit-attribution, tasks, etc.), OTTO_APPEND_SYSTEM_PROMPT, memory, and
    # the permissions-mode reminder are all bypassed — only this string is used.
    system_prompt: str | None = None

    # JSON schema for structured final-output mode. When set, otto registers a
    # synthetic `submit_final_answer` tool with this schema and instructs the
    # agent to call it to deliver its final result. `run_query()` extracts the
    # args into `QueryResult.final_structured_output`.
    #
    # Pass a plain JSON Schema dict. For pydantic models:
    #     output_schema=MyModel.model_json_schema()
    #
    # Not supported in interactive mode.
    output_schema: dict[str, Any] | None = None

    # Additional raw CLI args to pass through.
    extra_args: list[str] = field(default_factory=list)

    # Optional sink for stderr chunks from the otto subprocess. If None,
    # stderr is buffered internally and exposed via client.stderr.
    on_stderr: Callable[[str], None] | None = None


@dataclass
class QueryOptions(OttoOptions):
    """Options for one-shot query()."""

    prompt: str = ""
    images: list[dict[str, Any]] | None = None
    # Timeout in seconds for the agent to complete (emit agent_end). Default 10 min.
    timeout: float = 600.0
