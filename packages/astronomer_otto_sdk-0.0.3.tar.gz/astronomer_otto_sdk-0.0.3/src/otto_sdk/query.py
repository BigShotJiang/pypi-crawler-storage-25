"""One-shot query() — the claude-agent-sdk-shaped API. Spawns otto, sends a
single prompt, yields streaming events until agent_end, then cleans up.

Mirrors sdk/src/query.ts.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from otto_sdk.client import OttoClient
from otto_sdk.options import OttoOptions, QueryOptions
from otto_sdk.protocol import AgentEvent

# Tool name otto registers when `output_schema` is set.
FINAL_ANSWER_TOOL_NAME = "submit_final_answer"


@dataclass
class QueryResult:
    events: list[AgentEvent] = field(default_factory=list)
    final_text: str | None = None
    # Structured output extracted from the last successful submit_final_answer
    # tool call. None if the tool wasn't called (e.g. output_schema wasn't set).
    final_structured_output: Any = None


async def query(options: QueryOptions) -> AsyncIterator[AgentEvent]:
    """Run otto with a single prompt and stream events as they arrive.

    Example:
        async for event in query(QueryOptions(prompt="list dags", cwd="./project")):
            if event["type"] == "message_end":
                print(event["message"])
    """
    # One-shot defaults to no_session=True unless caller opted in.
    client_options = OttoOptions(
        otto_path=options.otto_path,
        cwd=options.cwd,
        env=options.env,
        provider=options.provider,
        model=options.model,
        no_session=options.no_session if options.no_session else True,
        session_path=options.session_path,
        thinking_level=options.thinking_level,
        mcp_servers=options.mcp_servers,
        allowed_tools=options.allowed_tools,
        allowed_skills=options.allowed_skills,
        permissions_config=options.permissions_config,
        system_prompt=options.system_prompt,
        output_schema=options.output_schema,
        extra_args=list(options.extra_args),
        on_stderr=options.on_stderr,
    )

    async with OttoClient(client_options) as client:
        await client.prompt(options.prompt, options.images)
        async for event in client.events(timeout=options.timeout):
            yield event


async def run_query(options: QueryOptions) -> QueryResult:
    """Collect all events and return them, plus final text and structured output."""
    events: list[AgentEvent] = []
    final_text: str | None = None
    final_structured_output: Any = None
    # Correlate tool_execution_start → tool_execution_end by toolCallId since
    # args only live on the _start event.
    pending_args: dict[str, Any] = {}

    async for event in query(options):
        events.append(event)
        etype = event.get("type")

        if etype == "message_end":
            content = event.get("message", {}).get("content")
            if isinstance(content, str):
                final_text = content
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text = block.get("text")
                        if isinstance(text, str):
                            final_text = text

        elif etype == "tool_execution_start":
            if event.get("toolName") == FINAL_ANSWER_TOOL_NAME:
                pending_args[event.get("toolCallId", "")] = event.get("args")

        elif etype == "tool_execution_end":
            if event.get("toolName") == FINAL_ANSWER_TOOL_NAME and not event.get("isError"):
                tool_id = event.get("toolCallId", "")
                if tool_id in pending_args:
                    final_structured_output = pending_args[tool_id]

    return QueryResult(
        events=events,
        final_text=final_text,
        final_structured_output=final_structured_output,
    )
