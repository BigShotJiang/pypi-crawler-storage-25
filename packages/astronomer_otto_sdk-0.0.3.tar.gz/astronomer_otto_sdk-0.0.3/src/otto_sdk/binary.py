"""Locate the otto binary on disk and build its env.

Resolution order:
    1. Explicit path passed in options
    2. OTTO_PATH env var
    3. ~/.astro/bin/otto (standard install location)
    4. otto on PATH (via shutil.which)
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path


class OttoBinaryNotFoundError(RuntimeError):
    """Raised when we can't find the otto binary in any of the usual places."""

    def __init__(self, searched: list[str]) -> None:
        bullets = "\n".join(f"  - {p}" for p in searched)
        super().__init__(
            "Could not locate the otto binary. Searched:\n"
            f"{bullets}\n\n"
            "Install otto (see https://github.com/astronomer/otto) "
            "or pass otto_path explicitly."
        )
        self.searched = searched


def resolve_otto_binary(explicit: str | None = None) -> str:
    """Return the absolute path to the otto binary, or raise OttoBinaryNotFoundError."""
    searched: list[str] = []

    if explicit:
        if os.path.exists(explicit):
            return explicit
        searched.append(f"{explicit} (explicit)")

    from_env = os.environ.get("OTTO_PATH")
    if from_env:
        if os.path.exists(from_env):
            return from_env
        searched.append(f"{from_env} (OTTO_PATH)")

    astro_bin = str(Path.home() / ".astro" / "bin" / "otto")
    if os.path.exists(astro_bin):
        return astro_bin
    searched.append(astro_bin)

    which = shutil.which("otto")
    if which:
        return which
    searched.append("PATH lookup (shutil.which)")

    raise OttoBinaryNotFoundError(searched)


# Env vars the otto binary actually reads. Forwarded explicitly so the
# subprocess env stays small and auditable.
_FORWARD_ENV_KEYS = (
    "ASTRO_TOKEN",
    "ASTRO_DOMAIN",
    "ASTRO_ORGANIZATION",
    "ASTRO_API_URL",
    "AIRFLOW_API_URL",
    "AIRFLOW_USERNAME",
    "AIRFLOW_PASSWORD",
    "OTTO_LOG_LEVEL",
    "PATH",
    "HOME",
    "USER",
)


def build_env(overrides: dict[str, str | None] | None = None) -> dict[str, str]:
    """Build the env dict for the otto subprocess.

    Forwards a whitelist of vars from the caller's environment; overrides
    (values may be None to delete) win.
    """
    env: dict[str, str] = {}
    for key in _FORWARD_ENV_KEYS:
        v = os.environ.get(key)
        if v is not None:
            env[key] = v

    if overrides:
        for k, v in overrides.items():
            if v is None:
                env.pop(k, None)
            else:
                env[k] = v

    return env
