# Copyright (c) 2025 HDMRLib Contributors
# SPDX-License-Identifier: MIT

from abc import ABC, abstractmethod

class BaseBackend(ABC):

    @abstractmethod
    def get_hdmr_model(self, tensor, **kwargs):
        """Return an HDMR model instance for reconstruction."""
        pass  # pragma: no cover

    @abstractmethod
    def get_empr_model(self, tensor, **kwargs):
        """Return an EMPR model instance for reconstruction."""
        pass  # pragma: no cover
