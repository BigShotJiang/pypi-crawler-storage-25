# Aura AI

> Your intelligent presence.

An AI-powered assistant with full system control — coding, automation, file operations, browser control, and more.

## Install

```bash
pip install aura-ai
```

## Usage

```bash
aura chat
```

## Features

- 💬 Natural language chat (powered by Claude)
- 📁 File operations (read, write, search, move)
- 💻 Command execution (bash, scripts)
- 🌐 Web search and browsing
- 🔧 Code generation and debugging
- ⏰ Task scheduling
- 🌍 Multi-language support

## License

Proprietary — All rights reserved.
