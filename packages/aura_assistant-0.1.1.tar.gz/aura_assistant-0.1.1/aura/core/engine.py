import os
import json
import subprocess
import platform
from anthropic import Anthropic

## PRODUCTION PROMPT (uncomment after demos):
# SYSTEM = """You are Aura, an AI assistant with full system control.
#
# System: {os} | Dir: {cwd} | User: {user}
#
# Rules:
# - Execute tasks directly, no unnecessary explanation
# - When creating files: just create them and confirm with path. No tables, no summaries, no feature lists
# - Keep responses SHORT. 1-3 sentences max unless user asks for detail
# - No emojis in responses unless user uses them
# - No markdown tables for simple confirmations
# - If user asks to create something, create it and say "Done. Saved to [path]"
# - Only explain if user asks "why" or "how"
# - Never list dependencies or features unless asked"""

SYSTEM = """You are Aura, an advanced AI assistant with full system control. You are direct, helpful, and take action.

Tools available: file read/write, shell commands, file search, directory listing, email sending, document creation.

System: {os} | Dir: {cwd} | User: {user}

Rules:
- Execute tasks directly
- Be thorough and show your capabilities in responses
- Use tables, emojis, and formatting to make responses visually appealing
- Confirm before destructive actions
- Never expose secrets"""

tools = [
    {"name": "read_file", "description": "Read a file", "input_schema": {"type": "object", "properties": {"path": {"type": "string"}, "start_line": {"type": "integer"}, "end_line": {"type": "integer"}}, "required": ["path"]}},
    {"name": "write_file", "description": "Write content to a file", "input_schema": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]}},
    {"name": "execute_command", "description": "Run a shell command", "input_schema": {"type": "object", "properties": {"command": {"type": "string"}, "working_dir": {"type": "string"}}, "required": ["command"]}},
    {"name": "search_files", "description": "Search files by name or content", "input_schema": {"type": "object", "properties": {"pattern": {"type": "string"}, "path": {"type": "string"}, "content_search": {"type": "boolean"}}, "required": ["pattern"]}},
    {"name": "list_directory", "description": "List directory contents", "input_schema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}},
    {"name": "send_email", "description": "Send an email (confirm with user first)", "input_schema": {"type": "object", "properties": {"to": {"type": "string"}, "subject": {"type": "string"}, "body": {"type": "string"}}, "required": ["to", "subject", "body"]}},
    {"name": "create_document", "description": "Create excel/csv/word/text document", "input_schema": {"type": "object", "properties": {"path": {"type": "string"}, "doc_type": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "doc_type", "content"]}},
]


def run_tool(name, args):
    try:
        if name == "read_file":
            p = os.path.expanduser(args["path"])
            if not os.path.exists(p):
                return f"Error: {p} not found"
            lines = open(p).readlines()
            s = args.get("start_line", 1) - 1
            e = args.get("end_line", len(lines))
            return "".join(lines[max(0, s):e])

        if name == "write_file":
            p = os.path.expanduser(args["path"])
            os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
            open(p, "w").write(args["content"])
            return f"Written: {p}"

        if name == "execute_command":
            cwd = args.get("working_dir") or os.getcwd()
            r = subprocess.run(args["command"], shell=True, capture_output=True, text=True, timeout=30, cwd=cwd)
            out = r.stdout + r.stderr
            return out[:5000] if out else "(no output)"

        if name == "search_files":
            p = os.path.expanduser(args.get("path", "."))
            pat = args["pattern"]
            cmd = f"grep -rn '{pat}' '{p}' | head -20" if args.get("content_search") else f"find '{p}' -name '{pat}' | head -20"
            r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            return r.stdout or "No matches"

        if name == "list_directory":
            p = os.path.expanduser(args["path"])
            if not os.path.isdir(p):
                return f"Not a directory: {p}"
            entries = sorted(os.listdir(p))[:50]
            return "\n".join(("d " if os.path.isdir(os.path.join(p, e)) else "f ") + e for e in entries)

        if name == "send_email":
            import smtplib
            from email.mime.text import MIMEText
            from aura.core.config import get_email_config
            user, pw = get_email_config()
            if not user or not pw:
                return "Email not configured. Run: aura setup"
            msg = MIMEText(args["body"])
            msg["Subject"] = args["subject"]
            msg["From"] = user
            msg["To"] = args["to"]
            with smtplib.SMTP("smtp.gmail.com", 587) as s:
                s.starttls()
                s.login(user, pw)
                s.send_message(msg)
            return f"Sent to {args['to']}"

        if name == "create_document":
            p = os.path.expanduser(args["path"])
            dtype = args["doc_type"].lower()
            content = args["content"]
            os.makedirs(os.path.dirname(p) or ".", exist_ok=True)

            if dtype == "csv":
                import csv
                rows = json.loads(content)
                with open(p, "w", newline="") as f:
                    csv.writer(f).writerows(rows)
            elif dtype == "excel":
                import openpyxl
                wb = openpyxl.Workbook()
                ws = wb.active
                for row in json.loads(content):
                    ws.append(row)
                wb.save(p)
            elif dtype == "word":
                from docx import Document
                doc = Document()
                for line in content.split("\n"):
                    doc.add_paragraph(line)
                doc.save(p)
            else:
                open(p, "w").write(content)
            return f"Created: {p}"

    except Exception as e:
        return f"Error: {e}"

    return f"Unknown tool: {name}"


HAIKU = "claude-haiku-4-5-20251001"
SONNET = "claude-sonnet-4-6"

COMPLEX_KEYWORDS = ["write", "create", "build", "debug", "fix", "code", "script", "implement", "design", "architect", "refactor", "analyze", "explain how"]


def pick_model(msg):
    lower = msg.lower()
    if any(k in lower for k in COMPLEX_KEYWORDS):
        return SONNET
    if len(msg) > 200:
        return SONNET
    return HAIKU


class AuraEngine:
    def __init__(self, api_key=None, tool_callback=None):
        self.client = Anthropic(api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"))
        self.messages = []
        self.tool_callback = tool_callback
        self.system = SYSTEM.format(
            os=platform.system(),
            cwd=os.getcwd(),
            user=os.environ.get("USER", "unknown"),
        )

    def chat(self, msg):
        self.messages.append({"role": "user", "content": msg})
        model = pick_model(msg)

        # Keep only last 20 messages to reduce token cost
        active_messages = self.messages[-20:]

        while True:
            resp = self.client.messages.create(
                model=model,
                max_tokens=4096,
                system=self.system,
                tools=tools,
                messages=active_messages,
            )
            assistant_msg = {"role": "assistant", "content": resp.content}
            self.messages.append(assistant_msg)
            active_messages.append(assistant_msg)

            if resp.stop_reason != "tool_use":
                return "\n".join(b.text for b in resp.content if hasattr(b, "text"))

            results = []
            for block in resp.content:
                if block.type == "tool_use":
                    if self.tool_callback:
                        self.tool_callback(block.name, block.input)
                    results.append({"type": "tool_result", "tool_use_id": block.id, "content": run_tool(block.name, block.input)})
            tool_msg = {"role": "user", "content": results}
            self.messages.append(tool_msg)
            active_messages.append(tool_msg)
