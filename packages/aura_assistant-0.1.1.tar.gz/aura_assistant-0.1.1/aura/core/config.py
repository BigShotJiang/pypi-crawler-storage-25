import os
import json

CONFIG_DIR = os.path.expanduser("~/.aura")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


def load_config():
    if os.path.exists(CONFIG_FILE):
        return json.load(open(CONFIG_FILE))
    return {}


def save_config(config):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    json.dump(config, open(CONFIG_FILE, "w"), indent=2)
    os.chmod(CONFIG_FILE, 0o600)


def get_api_key():
    return os.environ.get("ANTHROPIC_API_KEY") or load_config().get("api_key", "")


def get_email_config():
    c = load_config()
    return (
        os.environ.get("AURA_EMAIL") or c.get("email", ""),
        os.environ.get("AURA_EMAIL_PASS") or c.get("email_pass", ""),
    )


def run_setup():
    print("\n  ✨ Aura Setup\n  ─────────────\n")
    config = load_config()

    print("  1. Aura API Key")
    print("     Contact admin for your key")
    cur = config.get("api_key", "")
    if cur:
        print(f"     Current: {cur[:10]}...{cur[-4:]}")
    key = input("     Key (Enter to keep): ").strip()
    if key:
        config["api_key"] = key

    print("\n  2. Email (optional, for sending)")
    email = input("     Gmail address (Enter to skip): ").strip()
    if email:
        config["email"] = email
        pw = input("     App password: ").strip()
        if pw:
            config["email_pass"] = pw

    save_config(config)
    print("\n  ✅ Saved. Run 'aura' to start.\n")
