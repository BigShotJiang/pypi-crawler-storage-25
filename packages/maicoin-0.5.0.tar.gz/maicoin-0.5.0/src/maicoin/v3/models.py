from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field


class MaxBaseModel(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)


class Market(MaxBaseModel):
    id: str
    status: str
    base_unit: str
    base_unit_precision: int
    min_base_amount: float
    quote_unit: str
    quote_unit_precision: int
    min_quote_amount: float
    m_wallet_supported: bool


class Staking(MaxBaseModel):
    stake_flag: bool
    unstake_flag: bool


class CurrencyNetwork(MaxBaseModel):
    token_contract_address: str | None
    precision: int
    id: str
    network_protocol: str
    network_congested: bool | str
    deposit_confirmations: int
    withdrawal_fee: float
    min_withdrawal_amount: float
    withdrawal_enabled: bool
    deposit_enabled: bool
    need_memo: bool


class Currency(MaxBaseModel):
    currency: str
    type: str
    precision: int
    m_wallet_supported: bool
    m_wallet_mortgageable: bool
    m_wallet_borrowable: bool
    min_borrow_amount: str
    networks: list[CurrencyNetwork]
    staking: Staking | None


class Timestamp(MaxBaseModel):
    timestamp: int


class KLine(MaxBaseModel):
    timestamp: int
    open: str
    high: str
    low: str
    close: str
    volume: str


class Depth(MaxBaseModel):
    timestamp: int
    asks: list[tuple[str, str]]
    bids: list[tuple[str, str]]
    last_update_version: int | None = None
    last_update_id: int | None = None


class PublicTrade(MaxBaseModel):
    id: int
    price: str
    volume: str
    funds: str
    market: str
    side: str
    created_at: int


class Account(MaxBaseModel):
    currency: str
    balance: str
    locked: str
    staked: str | None = None
    principal: str | None = None
    interest: str | None = None


class OrderSide(StrEnum):
    SELL = "sell"
    BUY = "buy"


class OrderState(StrEnum):
    WAIT = "wait"
    DONE = "done"
    CANCEL = "cancel"
    CONVERT = "convert"


class OrderType(StrEnum):
    MARKET = "market"
    LIMIT = "limit"
    STOP_MARKET = "stop_market"
    STOP_LIMIT = "stop_limit"
    POST_ONLY = "post_only"
    IOC_LIMIT = "ioc_limit"


class Order(MaxBaseModel):
    id: int
    wallet_type: str
    market: str
    client_oid: str | None = None
    group_id: int | None = None
    side: OrderSide
    state: OrderState
    ord_type: OrderType
    price: str | None = None
    stop_price: str | None = None
    avg_price: str
    volume: str
    remaining_volume: str
    executed_volume: str
    trades_count: int
    created_at: int
    updated_at: int


class PrivateTrade(MaxBaseModel):
    id: int
    order_id: int
    wallet_type: str
    price: str
    volume: str
    funds: str
    market: str
    market_name: str
    side: str
    fee: str | None = None
    fee_currency: str | None = None
    fee_discounted: bool | None = None
    self_trade_bid_fee: str | None = None
    self_trade_bid_fee_currency: str | None = None
    self_trade_bid_fee_discounted: bool | None = None
    self_trade_bid_order_id: int | None = None
    liquidity: str
    created_at: int


class VipLevel(MaxBaseModel):
    level: int
    minimum_trading_volume: int
    minimum_staking_volume: int
    maker_fee: float
    taker_fee: float


class UserInfo(MaxBaseModel):
    email: str
    level: int
    current_vip_level: VipLevel
    next_vip_level: VipLevel | None
    m_wallet_enabled: bool | None = None


class Withdrawal(MaxBaseModel):
    uuid: str
    currency: str
    network_protocol: str | None
    amount: str
    fee: str
    fee_currency: str
    to_address: str
    label: str
    txid: str | None
    created_at: int
    state: str
    transaction_type: str


class WithdrawAddress(MaxBaseModel):
    uuid: str
    currency: str
    network_protocol: str | None
    address: str
    extra_label: str
    created_at: int
    activated_at: int | None
    is_internal: bool
    network_congested: bool


class Deposit(MaxBaseModel):
    uuid: str
    currency: str
    network_protocol: str
    amount: str
    to_address: str
    txid: str
    created_at: int
    confirmations: int
    state: str
    state_reason: str


class DepositAddress(MaxBaseModel):
    currency: str
    network_protocol: str
    currency_version: str
    address: str | None


class InternalTransfer(MaxBaseModel):
    uuid: str
    currency: str
    amount: str
    created_at: int
    from_: str = Field(validation_alias="from", serialization_alias="from")
    to: str
    state: str


class Reward(MaxBaseModel):
    uuid: str
    currency: str
    amount: str
    created_at: int
    type: str
    note: str


class FundTransactionDeposit(MaxBaseModel):
    sn: str
    is_internal: bool
    currency: str
    amount: str
    state: str
    created_at: int
    network_protocol: str | None
    to_address: str | None
    txid: str | None
    from_: str | None = Field(validation_alias="from", serialization_alias="from")


class FundTransactionWithdrawal(MaxBaseModel):
    sn: str
    is_internal: bool
    currency: str
    amount: str
    state: str
    created_at: int
    network_protocol: str | None
    fee: str | None
    fee_currency: str | None
    to_address: str | None
    label: str | None
    txid: str | None
    to: str | None


class FundTransactionSource(MaxBaseModel):
    platform: str
    sn: object
    wallet_type: str


class FundTransactionTransfer(MaxBaseModel):
    sn: str
    currency: str
    amount: str
    state: str
    created_at: int
    from_: FundTransactionSource = Field(validation_alias="from", serialization_alias="from")
    to: FundTransactionSource


class ConvertOrder(MaxBaseModel):
    sn: str
    from_currency: str
    from_amount: str
    to_currency: str
    to_amount: str
    fee: str
    fee_currency: str
    fee_in_twd: str
    created_at: int


class Ticker(MaxBaseModel):
    market: str
    at: int
    buy: str
    buy_vol: str
    sell: str
    sell_vol: str
    open: str
    low: str
    high: str
    last: str
    vol: str
    vol_in_btc: str
    vol_in_quote: str


class HistoricalIndexPrice(MaxBaseModel):
    timestamp: str
    price: str


class InterestRate(MaxBaseModel):
    hourly_interest_rate: str
    next_hourly_interest_rate: str


class MWalletLoan(MaxBaseModel):
    sn: str
    currency: str
    amount: str
    state: str
    created_at: int
    interest_rate: str


class MWalletTransfer(MaxBaseModel):
    sn: str
    side: str
    currency: str
    amount: str
    created_at: int
    state: str


class MWalletRepayment(MaxBaseModel):
    currency: str
    amount: str
    principal: str
    interest: str
    state: str
    sn: str
    created_at: int


class MWalletLiquidation(MaxBaseModel):
    sn: str
    ad_ratio: str
    expected_ad_ratio: str
    created_at: int
    state: str


class MWalletLiquidationRepayment(MaxBaseModel):
    currency: str
    amount: str
    principal: str
    interest: str
    state: str


class MWalletForcedLiquidation(MaxBaseModel):
    market: str
    type: str
    price: str
    volume: str
    fee: str
    fee_currency: str
    repayment: MWalletLiquidationRepayment


class MWalletLiquidationDetail(MWalletLiquidation):
    repayments: list[MWalletLiquidationRepayment]
    liquidations: list[MWalletForcedLiquidation]


class MWalletInterest(MaxBaseModel):
    currency: str
    amount: str
    interest_rate: str
    principal: str
    created_at: int


class MWalletADRatio(MaxBaseModel):
    ad_ratio: str
    asset_in_usdt: str
    debt_in_usdt: str
