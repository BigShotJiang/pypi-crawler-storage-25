/**
 * Reviewer Activity Chart Module
 *
 * Renders reviewer activity as a horizontal bar chart showing
 * weekly reviewer counts for the last 8 weeks.
 *
 * DOM-INJECTED: Container element is passed as parameter.
 * This module works identically in both extension and local dashboard modes.
 */

import type { Rollup } from "../../dataset-loader";
import type { DataAvailabilitySignal } from "../../types";
import type { FilterState } from "../filters";
import { classifyEmptyState } from "../empty-state-classifier";
import {
  escapeHtml,
  renderNoData,
  renderTrustedHtml,
} from "../shared/render";

/** Maximum weeks displayed in the reviewer activity panel. */
export const MAX_REVIEWER_WEEKS = 8;

/**
 * Render reviewer activity chart (horizontal bar chart).
 *
 * Shows reviewer counts for the last 8 weeks as horizontal bars.
 * The panel is inherently capped at {@link MAX_REVIEWER_WEEKS} weeks,
 * so DOM element count is bounded regardless of input size.
 * Tested with reviewer counts up to 200+ per week (enterprise scale).
 *
 * @param container - Target container element (or null for no-op)
 * @param rollups - Array of weekly rollup data
 * @param options - Optional rendering mode and classifier inputs
 */
export function renderReviewerActivity(
  container: HTMLElement | null,
  rollups: Rollup[],
  options: {
    reviewerFilterActive?: boolean;
    filters?: FilterState;
    unfilteredRollups?: Rollup[];
    availability?: DataAvailabilitySignal;
  } = {},
): void {
  if (!container) return;

  const { reviewerFilterActive = false } = options;
  const noun = reviewerFilterActive ? "reviews" : "reviewers";
  const subtitle = reviewerFilterActive
    ? `Review activity per week (last ${Math.min(rollups.length, MAX_REVIEWER_WEEKS)} weeks)`
    : `Active reviewers per week (last ${Math.min(rollups.length, MAX_REVIEWER_WEEKS)} weeks)`;

  if (!rollups || !rollups.length) {
    const classification = options.availability
      ? classifyEmptyState({
          chartType: "reviewer_activity",
          filters: options.filters ?? { repos: [], teams: [], reviewers: [], authors: [] },
          unfilteredRollups: options.unfilteredRollups ?? [],
          filteredRollups: rollups ?? [],
          availability: options.availability,
          minimumDataPoints: 0,
        })
      : null;
    const fallbackHint = reviewerFilterActive
      ? "Try widening the date range or adjusting reviewer filters."
      : "Try widening the date range or adjusting repository/team filters.";
    renderNoData(
      container,
      classification?.message ??
        (reviewerFilterActive
          ? "No review activity available"
          : "No reviewer data available"),
      classification?.hint ?? fallbackHint,
    );
    return;
  }

  // Take last MAX_REVIEWER_WEEKS weeks for display
  const truncated = rollups.length > MAX_REVIEWER_WEEKS;
  const recentRollups = rollups.slice(-MAX_REVIEWER_WEEKS);
  const maxReviewers = Math.max(
    ...recentRollups.map((r) => r.reviewers_count || 0),
  );

  if (maxReviewers === 0) {
    const classification = options.availability
      ? classifyEmptyState({
          chartType: "reviewer_activity",
          filters: options.filters ?? { repos: [], teams: [], reviewers: [], authors: [] },
          unfilteredRollups: options.unfilteredRollups ?? [],
          filteredRollups: rollups,
          availability: options.availability,
          minimumDataPoints: 1, // Requires at least 1 reviewer to render
        })
      : null;
    const fallbackHint = reviewerFilterActive
      ? "Try widening the date range or adjusting reviewer filters."
      : "Reviewer data requires the extraction pipeline to capture reviewer details.";
    renderNoData(
      container,
      classification?.message ??
        (reviewerFilterActive
          ? "No review activity available"
          : "No reviewer data available"),
      classification?.hint ?? fallbackHint,
    );
    return;
  }

  const barsHtml = recentRollups
    .map((r) => {
      const count = r.reviewers_count || 0;
      const pct = (count / maxReviewers) * 100;
      const wParts = r.week.split("-W");
      const weekLabel = wParts[1] ?? r.week;
      // SECURITY: Escape data-controlled values to prevent XSS
      return `
            <div class="h-bar-row" title="${escapeHtml(r.week)}: ${count} ${noun}">
                <span class="h-bar-label">W${escapeHtml(weekLabel)}</span>
                <div class="h-bar-container">
                    <div class="h-bar" style="width: ${pct}%"></div>
                </div>
                <span class="h-bar-value">${count}</span>
            </div>
        `;
    })
    .join("");

  // Truncation indicator (matches throughput.ts and cycle-time.ts pattern)
  const truncationHtml = truncated
    ? `<div class="truncation-indicator">Showing last ${MAX_REVIEWER_WEEKS} weeks</div>`
    : "";

  // SECURITY: barsHtml uses escapeHtml for week values, count is numeric
  renderTrustedHtml(
    container,
    `${truncationHtml}<p class="chart-subtitle">${escapeHtml(subtitle)}</p><div class="horizontal-bar-chart">${barsHtml}</div>`,
  );
}
