"""Tests for iam_service.learngual.serializers.mixins.

Read side (``NestedFileStateMixin``):
- No / empty / None state in context → response unchanged
- Trashed file (state[id]=None) → swapped for default_schema + file_id
- Active file (state[id]=dict) → fresh fields merged + file_id set
- id="0" placeholder in response → left alone (not keyed in state)
- Nested in list / polymorphic body → handled by signature walker
- Serializer field renames don't break recognition (signature-based)
- Misconfigured (no nested_file_config) → graceful no-op + warning
- End-to-end with a real DRF serializer

Write side (``NormalizeMediaWriteMixin``):
- Real id passthrough → file_id dropped
- Round-trip with existing file → id restored from file_id
- Round-trip with permanently-deleted file → file_id dropped, id stays "0"
- Overwrite (no file_id) → save verbatim
- Deeply-nested polymorphic body → walked
- Misconfigured (no config) → no-op + warning
- DB error propagates (write must abort, not silently leak)
- End-to-end with a real DRF serializer
"""
from __future__ import annotations

import logging
from typing import Any

import pytest
from rest_framework import serializers

from iam_service.learngual.serializers.mixins import (
    NestedFileStateMixin,
    NormalizeMediaWriteMixin,
)
from iam_service.learngual.services.nested_file_state import NestedFileStateConfig

DEFAULT_FILE_SCHEMA: dict[str, Any] = {
    "id": "0",
    "url": "https://cdn.example.com/default.png",
    "name": None,
    "size": 0,
    "mimetype": "image/png",
    "convertion_status": None,
    "stream_url": None,
}


def _media(id_: str, **extra) -> dict[str, Any]:
    """Full signature-matched media object for the walker."""
    return {
        "id": id_,
        "url": f"https://stored.example.com/{id_}.jpg",
        "name": f"{id_}.jpg",
        "size": 1024,
        "mimetype": "image/jpeg",
        "convertion_status": "DONE",
        **extra,
    }


def _make_config() -> NestedFileStateConfig:
    return NestedFileStateConfig(
        file_media_qs=lambda ids: [],  # not invoked by the mixin
        default_schema=DEFAULT_FILE_SCHEMA,
    )


def _make_mixin_instance(
    *,
    config: NestedFileStateConfig | None = None,
    context: dict | None = None,
    rendered_data: Any,
):
    """Build a NestedFileStateMixin subclass that returns *rendered_data*
    from super().to_representation() so we can isolate the mixin's behaviour
    from real serializer plumbing."""

    class _Parent:
        def to_representation(self, instance):
            return rendered_data

    class _Mixed(NestedFileStateMixin, _Parent):
        pass

    obj = _Mixed()
    obj.nested_file_config = config if config is not None else _make_config()
    obj.context = context if context is not None else {}
    return obj


# ---------------------------------------------------------------------------
# Pass-through cases (no state, empty state)
# ---------------------------------------------------------------------------


def test_no_state_in_context_returns_response_unchanged():
    """Without context['nested_file_state'], the mixin is a pass-through."""
    rendered = {"thumbnail": _media("abc"), "name": "Course A"}
    obj = _make_mixin_instance(rendered_data=rendered, context={})
    result = obj.to_representation(instance=None)
    assert result == rendered


def test_empty_state_in_context_returns_response_unchanged():
    """Explicit empty state map → same."""
    rendered = {"thumbnail": _media("abc")}
    obj = _make_mixin_instance(
        rendered_data=rendered, context={"nested_file_state": {}}
    )
    assert obj.to_representation(instance=None) == rendered


def test_none_state_in_context_returns_response_unchanged():
    """None in the context key is treated like empty state."""
    rendered = {"thumbnail": _media("abc")}
    obj = _make_mixin_instance(
        rendered_data=rendered, context={"nested_file_state": None}
    )
    assert obj.to_representation(instance=None) == rendered


# ---------------------------------------------------------------------------
# Trashed file → placeholder + file_id
# ---------------------------------------------------------------------------


def test_trashed_file_swapped_for_placeholder_with_file_id():
    """state[id]=None → object replaced by default_schema + file_id."""
    rendered = {"thumbnail": _media("abc")}
    obj = _make_mixin_instance(
        rendered_data=rendered,
        context={"nested_file_state": {"abc": None}},
    )
    out = obj.to_representation(instance=None)
    # The whole nested object was swapped.
    assert out["thumbnail"] == {**DEFAULT_FILE_SCHEMA, "file_id": "abc"}
    # The original is NOT mutated.
    assert rendered["thumbnail"]["id"] == "abc"


# ---------------------------------------------------------------------------
# Active file → merge fresh + file_id
# ---------------------------------------------------------------------------


def test_active_file_merges_fresh_state_and_sets_file_id():
    """state[id]=dict → original obj is merged with fresh dict + file_id."""
    rendered = {"thumbnail": _media("abc")}
    fresh = {
        "url": "https://fresh.example.com/abc.jpg",
        "convertion_status": "DONE",
        "size": 2048,
    }
    obj = _make_mixin_instance(
        rendered_data=rendered,
        context={"nested_file_state": {"abc": fresh}},
    )
    out = obj.to_representation(instance=None)["thumbnail"]
    assert out["url"] == fresh["url"]
    assert out["convertion_status"] == "DONE"
    assert out["size"] == 2048
    # Untouched fields preserved.
    assert out["name"] == "abc.jpg"
    # Persistent reference set.
    assert out["file_id"] == "abc"
    assert out["id"] == "abc"  # original id preserved (and equal to fresh.id absent)


# ---------------------------------------------------------------------------
# id not in state → untouched
# ---------------------------------------------------------------------------


def test_id_not_in_state_left_alone():
    """An object whose id isn't in the state map is preserved verbatim."""
    rendered = {"thumbnail": _media("abc"), "preview": _media("xyz")}
    obj = _make_mixin_instance(
        rendered_data=rendered,
        context={"nested_file_state": {"abc": None}},  # only abc keyed
    )
    out = obj.to_representation(instance=None)
    assert out["thumbnail"] == {**DEFAULT_FILE_SCHEMA, "file_id": "abc"}
    # xyz untouched.
    assert out["preview"] == _media("xyz")


def test_zero_id_placeholder_left_alone():
    """Stored placeholder values (id='0') aren't in the state map → unchanged."""
    placeholder = {**DEFAULT_FILE_SCHEMA}
    rendered = {"thumbnail": placeholder}
    obj = _make_mixin_instance(
        rendered_data=rendered,
        context={"nested_file_state": {"abc": None}},
    )
    out = obj.to_representation(instance=None)
    assert out["thumbnail"] == placeholder


# ---------------------------------------------------------------------------
# Deeply nested / polymorphic
# ---------------------------------------------------------------------------


def test_deeply_nested_polymorphic_body_rewrites_correctly():
    """Lecture.body-shape: media buried in a list under blocks is rewritten."""
    rendered = {
        "lecture": {
            "body": {
                "blocks": [
                    {"type": "text", "content": "hi"},
                    {"type": "audio", "file": _media("aud-1")},
                    {"type": "video", "file": _media("vid-1")},
                ]
            }
        }
    }
    fresh_video = {"url": "https://fresh.example.com/v.mp4"}
    obj = _make_mixin_instance(
        rendered_data=rendered,
        context={"nested_file_state": {"aud-1": None, "vid-1": fresh_video}},
    )
    out = obj.to_representation(instance=None)
    blocks = out["lecture"]["body"]["blocks"]
    # Text block untouched.
    assert blocks[0] == {"type": "text", "content": "hi"}
    # Audio swapped to placeholder + file_id.
    assert blocks[1]["file"] == {**DEFAULT_FILE_SCHEMA, "file_id": "aud-1"}
    # Video merged + file_id.
    assert blocks[2]["file"]["url"] == fresh_video["url"]
    assert blocks[2]["file"]["file_id"] == "vid-1"


def test_media_in_list_at_root_handled():
    """Media object as a direct list element is rewritten."""
    rendered = {"files": [_media("a"), {"plain": "dict"}, _media("b")]}
    obj = _make_mixin_instance(
        rendered_data=rendered,
        context={"nested_file_state": {"a": None}},
    )
    out = obj.to_representation(instance=None)
    assert out["files"][0] == {**DEFAULT_FILE_SCHEMA, "file_id": "a"}
    assert out["files"][1] == {"plain": "dict"}
    assert out["files"][2] == _media("b")  # b not in state


# ---------------------------------------------------------------------------
# Serializer field renames don't break recognition
# ---------------------------------------------------------------------------


def test_serializer_field_rename_does_not_break_walk():
    """The mixin doesn't read keys by name — a renamed field still gets walked."""
    # Same media object served under an unusual field name.
    rendered = {"some_renamed_field": _media("abc")}
    obj = _make_mixin_instance(
        rendered_data=rendered,
        context={"nested_file_state": {"abc": None}},
    )
    out = obj.to_representation(instance=None)
    assert out["some_renamed_field"] == {**DEFAULT_FILE_SCHEMA, "file_id": "abc"}


# ---------------------------------------------------------------------------
# Misconfiguration: no nested_file_config attribute
# ---------------------------------------------------------------------------


def test_missing_nested_file_config_logs_warning_and_returns_unchanged(caplog):
    """A misconfigured serializer (no config) doesn't crash the request."""

    class _Parent:
        def to_representation(self, instance):
            return {"thumbnail": _media("abc")}

    class _Mixed(NestedFileStateMixin, _Parent):
        pass

    obj = _Mixed()
    # Deliberately do NOT set nested_file_config.
    obj.context = {"nested_file_state": {"abc": None}}

    with caplog.at_level(logging.WARNING, logger="learngual.serializers.mixins"):
        out = obj.to_representation(instance=None)

    # No swap occurred (config was missing).
    assert out == {"thumbnail": _media("abc")}
    # And a warning was logged.
    assert any("nested_file_config" in rec.getMessage() for rec in caplog.records)


# ---------------------------------------------------------------------------
# Integration with a real DRF serializer
# ---------------------------------------------------------------------------


class _FakeCourseSerializer(NestedFileStateMixin, serializers.Serializer):
    """Minimal DRF serializer that surfaces nested file objects.

    Verifies the mixin composes correctly with ``serializers.Serializer``
    (MRO order, context propagation, etc.).
    """

    thumbnail = serializers.JSONField()
    preview_video = serializers.JSONField()
    name = serializers.CharField()


def test_composition_with_drf_serializer_swaps_and_merges_correctly():
    """End-to-end: real DRF serializer + mixin produces the expected output."""
    instance = {
        "name": "Calculus 101",
        "thumbnail": _media("aud-1"),
        "preview_video": _media("vid-1"),
    }
    fresh = {"url": "https://fresh.example.com/v.mp4"}
    serializer = _FakeCourseSerializer(
        instance=instance,
        context={"nested_file_state": {"aud-1": None, "vid-1": fresh}},
    )
    # Bind the config (the per-service subclass would do this).
    serializer.nested_file_config = _make_config()

    out = serializer.data

    assert out["name"] == "Calculus 101"
    # Trashed → placeholder + file_id.
    assert out["thumbnail"] == {**DEFAULT_FILE_SCHEMA, "file_id": "aud-1"}
    # Active → fresh merged + file_id.
    assert out["preview_video"]["url"] == fresh["url"]
    assert out["preview_video"]["file_id"] == "vid-1"


# ===========================================================================
# Write side: NormalizeMediaWriteMixin
# ===========================================================================


def _make_write_config(existing_ids: set[str]) -> NestedFileStateConfig:
    """Config whose file_media_qs returns FileMedia rows for `existing_ids`."""

    class _Row:
        def __init__(self, pk):
            self.pk = pk

    def fake_qs(ids):
        return [_Row(i) for i in ids if str(i) in {str(x) for x in existing_ids}]

    return NestedFileStateConfig(
        file_media_qs=fake_qs,
        default_schema=DEFAULT_FILE_SCHEMA,
    )


def _make_write_mixin_instance(
    *,
    config: NestedFileStateConfig | None = None,
    captured_seen: list | None = None,
):
    """Build a NormalizeMediaWriteMixin subclass whose super().to_internal_value
    captures the (already-normalised) data into ``captured_seen`` and returns it.
    Lets us isolate the mixin's behaviour from DRF validator plumbing."""
    seen = captured_seen if captured_seen is not None else []

    class _Parent:
        def to_internal_value(self, data):
            seen.append(data)
            return data

    class _Mixed(NormalizeMediaWriteMixin, _Parent):
        pass

    obj = _Mixed()
    if config is not None:
        obj.nested_file_config = config
    return obj


# ---------------------------------------------------------------------------
# Rule 1: real id passthrough
# ---------------------------------------------------------------------------


def test_write_real_id_drops_file_id():
    """id non-'0' → trust id, drop file_id (it was informational only)."""
    config = _make_write_config(existing_ids=set())
    obj = _make_write_mixin_instance(config=config)
    payload = {"thumbnail": {**_media("real-id"), "file_id": "ignored"}}
    out = obj.to_internal_value(payload)
    assert out["thumbnail"]["id"] == "real-id"
    assert "file_id" not in out["thumbnail"]


# ---------------------------------------------------------------------------
# Rule 2: round-trip when file still exists
# ---------------------------------------------------------------------------


def test_write_round_trip_existing_file_restores_id():
    """id='0' + file_id present + file exists → restore id, drop file_id."""
    config = _make_write_config(existing_ids={"real-id-xyz"})
    obj = _make_write_mixin_instance(config=config)
    payload = {
        "thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "real-id-xyz"},
    }
    out = obj.to_internal_value(payload)
    assert out["thumbnail"]["id"] == "real-id-xyz"
    assert "file_id" not in out["thumbnail"]


# ---------------------------------------------------------------------------
# Rule 3: round-trip on permanently-deleted file (drop file_id)
# ---------------------------------------------------------------------------


def test_write_round_trip_deleted_file_drops_reference():
    """id='0' + file_id present + file GONE → drop file_id, id stays '0'."""
    config = _make_write_config(existing_ids=set())  # file_media_qs returns nothing
    obj = _make_write_mixin_instance(config=config)
    payload = {
        "thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "deleted-999"},
    }
    out = obj.to_internal_value(payload)
    assert out["thumbnail"]["id"] == "0"  # NOT restored (dangling ref)
    assert "file_id" not in out["thumbnail"]


# ---------------------------------------------------------------------------
# Rule 4: explicit overwrite (no file_id)
# ---------------------------------------------------------------------------


def test_write_overwrite_no_file_id_saves_verbatim():
    """id='0' + no file_id → save verbatim (explicit clear; old-client path)."""
    config = _make_write_config(existing_ids={"some-id"})
    obj = _make_write_mixin_instance(config=config)
    payload = {"thumbnail": {**DEFAULT_FILE_SCHEMA}}  # no file_id
    out = obj.to_internal_value(payload)
    assert out["thumbnail"]["id"] == "0"
    assert "file_id" not in out["thumbnail"]


def test_write_overwrite_file_id_zero_treated_as_no_file_id():
    """file_id == '0' is the same as missing."""
    config = _make_write_config(existing_ids={"some-id"})
    obj = _make_write_mixin_instance(config=config)
    payload = {"thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "0"}}
    out = obj.to_internal_value(payload)
    assert out["thumbnail"]["id"] == "0"
    assert "file_id" not in out["thumbnail"]


# ---------------------------------------------------------------------------
# Deeply nested / polymorphic
# ---------------------------------------------------------------------------


def test_write_deeply_nested_polymorphic_body_normalised():
    """Lecture.body-shape: media buried in list items get rule-based normalisation."""
    config = _make_write_config(existing_ids={"aud-real"})
    obj = _make_write_mixin_instance(config=config)
    payload = {
        "body": {
            "blocks": [
                {"type": "text", "content": "intro"},
                {
                    "type": "audio",
                    "file": {**DEFAULT_FILE_SCHEMA, "file_id": "aud-real"},
                },
                {
                    "type": "video",
                    "file": {**DEFAULT_FILE_SCHEMA, "file_id": "vid-gone"},
                },
            ]
        }
    }
    out = obj.to_internal_value(payload)
    blocks = out["body"]["blocks"]
    # Audio: existing file → id restored.
    assert blocks[1]["file"]["id"] == "aud-real"
    assert "file_id" not in blocks[1]["file"]
    # Video: deleted → file_id dropped, id stays "0".
    assert blocks[2]["file"]["id"] == "0"
    assert "file_id" not in blocks[2]["file"]


# ---------------------------------------------------------------------------
# Misconfiguration: missing config
# ---------------------------------------------------------------------------


def test_write_missing_config_logs_warning_and_passes_through(caplog):
    """No nested_file_config → log warning, return data unchanged."""
    obj = _make_write_mixin_instance(config=None)
    payload = {"thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "x"}}

    with caplog.at_level(logging.WARNING, logger="learngual.serializers.mixins"):
        out = obj.to_internal_value(payload)

    # Untouched (no normalisation ran).
    assert out["thumbnail"]["id"] == "0"
    assert out["thumbnail"]["file_id"] == "x"
    # Warning was emitted.
    assert any("nested_file_config" in rec.getMessage() for rec in caplog.records)


# ---------------------------------------------------------------------------
# DB error propagates (must abort the write)
# ---------------------------------------------------------------------------


def test_write_db_error_propagates_not_swallowed():
    """A DB error during the existence query must propagate.

    Silently degrading would either preserve dangling references or strip
    legitimate ones — both bad.  Failing the write is the only safe option.
    """

    def failing_qs(ids):
        raise RuntimeError("database connection lost")

    config = NestedFileStateConfig(
        file_media_qs=failing_qs, default_schema=DEFAULT_FILE_SCHEMA
    )
    obj = _make_write_mixin_instance(config=config)
    payload = {"thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "x"}}

    with pytest.raises(RuntimeError, match="database"):
        obj.to_internal_value(payload)


# ---------------------------------------------------------------------------
# Non-media payload pass-through
# ---------------------------------------------------------------------------


def test_write_payload_with_no_media_objects_passes_through_unchanged():
    """Payloads that don't carry any media objects round-trip verbatim."""
    config = _make_write_config(existing_ids=set())
    obj = _make_write_mixin_instance(config=config)
    payload = {"name": "Course A", "level": 3, "tags": ["x", "y"]}
    out = obj.to_internal_value(payload)
    assert out == payload


# ---------------------------------------------------------------------------
# End-to-end with a real DRF serializer
# ---------------------------------------------------------------------------


class _FakeCourseWriteSerializer(NormalizeMediaWriteMixin, serializers.Serializer):
    """Minimal write serializer that accepts a nested thumbnail field."""

    name = serializers.CharField()
    thumbnail = serializers.JSONField()


def test_write_composition_with_drf_serializer_round_trip_preserves_reference():
    """End-to-end: real DRF serializer normalises the round-trip payload."""
    serializer = _FakeCourseWriteSerializer(
        data={
            "name": "Calculus 101",
            "thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "real-id-xyz"},
        }
    )
    serializer.nested_file_config = _make_write_config(existing_ids={"real-id-xyz"})
    assert serializer.is_valid(), serializer.errors
    # The validated data has the id restored.
    assert serializer.validated_data["thumbnail"]["id"] == "real-id-xyz"
    assert "file_id" not in serializer.validated_data["thumbnail"]
    # Non-media fields untouched.
    assert serializer.validated_data["name"] == "Calculus 101"


def test_write_composition_with_drf_serializer_deleted_file_drops_reference():
    """End-to-end: deleted file path through a real DRF serializer."""
    serializer = _FakeCourseWriteSerializer(
        data={
            "name": "Calculus 101",
            "thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "deleted-999"},
        }
    )
    serializer.nested_file_config = _make_write_config(existing_ids=set())
    assert serializer.is_valid(), serializer.errors
    # File_id dropped; id stays "0" — no dangling reference saved.
    assert serializer.validated_data["thumbnail"]["id"] == "0"
    assert "file_id" not in serializer.validated_data["thumbnail"]
