"""DRF serializer mixins for nested media file state.

Two mixins, one purpose: keep nested media objects in API responses /
write payloads consistent with the canonical state in the ``FileMedia``
table, without touching the stored JSON.

Read side (``NestedFileStateMixin``)
-----------------------------------
After ``super().to_representation()`` produces the response dict, the mixin
walks it recursively via ``MediaHelper.replace_media_objects`` and rewrites
every signature-matched media object using the state map prebuilt by
:func:`~iam_service.learngual.services.nested_file_state.fetch_nested_file_state`
(stashed in ``self.context["nested_file_state"]`` by the view).

Recognition is by signature — a dict counts as a media object iff it
contains the 6 canonical keys ``{id, url, name, size, mimetype,
convertion_status}``.  This means:

* Profile photos, course thumbnails, Lecture.body audio/video items,
  notification thumbnails, room icons — all handled by one walk.
* Serializer field renames don't matter (we don't read keys by name).
* Polymorphic Lecture bodies don't need a special mixin variant.

Write side (``NormalizeMediaWriteMixin``)
-----------------------------------------
On the way in, the mixin walks the client-supplied payload via
``MediaHelper.normalize_media_payloads`` and applies the ``file_id``
round-trip rule per media object:

* ``id`` non-"0" → trust id, drop file_id (informational only).
* ``id == "0"`` + ``file_id`` present and the FileMedia still exists →
  restore the reference: set ``id = file_id``, drop file_id.
* ``id == "0"`` + ``file_id`` present but the FileMedia was permanently
  deleted → drop file_id, save verbatim (no dangling reference).
* ``id == "0"`` + ``file_id`` missing → save verbatim (overwrite path;
  old pre-``file_id`` clients land here naturally).

The existence check is a single batch query per request, using the per-
service ``NestedFileStateConfig.file_media_qs``.  DB errors propagate —
a write that can't verify references must abort.
"""
from __future__ import annotations

import logging
from typing import Any

from ..services.media_helper import normalize_media_payloads, replace_media_objects
from ..services.nested_file_state import NestedFileStateConfig

logger = logging.getLogger("learngual.serializers.mixins")


class NestedFileStateMixin:
    """DRF serializer mixin that rewrites nested media objects in the response.

    Pattern of use:

    1. The view runs ``fetch_nested_file_state(page, account=..., enterprise=...)``
       AFTER pagination and stashes the result in serializer context under
       ``nested_file_state``.
    2. The serializer inherits this mixin and binds a service-specific
       ``nested_file_config`` (typically via a subclass like
       ``IamNestedFileMixin``).
    3. ``super().to_representation()`` produces the response payload.
    4. This mixin walks the payload recursively, finds every media object
       by signature, and applies the state rule for that object's id:

       * id not in state → leave it alone (no FileMedia row exists or the
         id is the ``"0"`` placeholder).
       * ``state[id]`` is ``None`` → swap the object for
         ``{**default_schema, "file_id": id}`` (trash placeholder; the
         ``file_id`` preserves the persistent reference for a PATCH
         round-trip — see ``normalize_media_object``).
       * ``state[id]`` is a dict → merge ``{**obj, **state[id],
         "file_id": id}`` so fresh ``url`` / ``convertion_status`` etc.
         override the stored JSON.

    The DB is never written to; only the outgoing response is rewritten.

    Each service exports a thin subclass with its config baked in
    (``IamNestedFileMixin``, ``ElearningNestedFileMixin``, ...).
    """

    nested_file_config: NestedFileStateConfig
    """Per-service config singleton.  Bound by the service-specific
    subclass.  The mixin only reads ``.default_schema`` from it; everything
    else (the state map, the walker itself) is signature-based."""

    def to_representation(self, instance: Any) -> Any:
        data = super().to_representation(instance)
        state = self.context.get("nested_file_state") or {}
        if not state:
            return data
        try:
            default_schema = self.nested_file_config.default_schema
        except AttributeError:
            # Misconfigured serializer (no config bound).  Log once and
            # return the response unchanged — failing the request over a
            # config typo would be worse than serving fresh-but-unmasked
            # URLs.
            logger.warning(
                "NestedFileStateMixin: %s has no nested_file_config; "
                "returning response unchanged.",
                type(self).__name__,
            )
            return data
        return replace_media_objects(
            data,
            state=state,
            default_schema=default_schema,
        )


class NormalizeMediaWriteMixin:
    """DRF serializer mixin that normalises nested media objects on write.

    Apply to any serializer that accepts a payload containing nested media
    objects (profile photos, course thumbnails, Lecture.body audio/video
    items, Room.group_icon, polymorphic Question.data, ...).

    After DRF parses the incoming ``data`` (but before ``super()``'s
    validation), the mixin walks ``data`` recursively via
    ``MediaHelper.normalize_media_payloads`` so the ``file_id`` round-trip
    rule is applied uniformly:

    * ``id`` non-"0" → trust id; drop ``file_id`` (informational only).
    * ``id == "0"`` + ``file_id`` present + FileMedia still exists →
      restore the reference (set ``id = file_id``, drop ``file_id``).
    * ``id == "0"`` + ``file_id`` present + FileMedia permanently deleted
      → drop ``file_id``, save verbatim (no dangling reference).
    * ``id == "0"`` + ``file_id`` missing → save verbatim (explicit clear).

    The existence check is a single batch query against
    ``config.file_media_qs``.  Per-serializer opt-in keeps call sites
    visible and auditable — ``grep NormalizeMediaWriteMixin`` lists every
    write site that participates.

    Race-safety: ``to_internal_value`` is a pure transform on its ``data``
    argument and immediately delegates to ``super()``.  No module-level
    mutable state.  Concurrent requests are independent calls.  Database
    races on the same row are the pre-existing Django write concern,
    unchanged by this mixin.
    """

    nested_file_config: NestedFileStateConfig
    """Per-service config singleton (same one the read-side mixin uses).
    Bound by the service-specific subclass.  Provides
    ``file_media_qs`` for the batch existence check."""

    def to_internal_value(self, data: Any) -> Any:
        config = getattr(self, "nested_file_config", None)
        if config is None:
            logger.warning(
                "NormalizeMediaWriteMixin: %s has no nested_file_config; "
                "skipping payload normalisation.",
                type(self).__name__,
            )
            return super().to_internal_value(data)

        file_media_qs = getattr(config, "file_media_qs", None)
        normalised = normalize_media_payloads(
            data,
            file_media_qs=file_media_qs,
        )
        return super().to_internal_value(normalised)
