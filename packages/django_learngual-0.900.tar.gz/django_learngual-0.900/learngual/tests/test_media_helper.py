"""Comprehensive tests for iam_service.learngual.services.media_helper.

Covers:
- _group_by_prefix          (internal)
- _find_media_prefixes      (internal)
- extract_media_ids         (public)
- remove_media_by_ids       (public)
- diff_media_ids            (public)
- replace_media_objects     (public; read-side per-id substitution)
- normalize_media_object    (public; single-object PATCH normalisation)
- normalize_media_payloads  (public; recursive PATCH normalisation)
"""
from __future__ import annotations

from typing import Any

from ..services.media_helper import (
    _find_media_prefixes,
    _group_by_prefix,
    diff_media_ids,
    extract_media_ids,
    normalize_media_object,
    normalize_media_payloads,
    remove_media_by_ids,
    replace_media_objects,
)

# ---------------------------------------------------------------------------
# Fixtures / shared helpers
# ---------------------------------------------------------------------------

MEDIA_A: dict[str, Any] = {
    "id": "aaa111",
    "name": "track.wav",
    "url": "https://example.com/track.wav",
    "convertion_status": "DEFAULT",
    "size": 84906.0,
    "mimetype": "audio/x-wav",
}

MEDIA_B: dict[str, Any] = {
    "id": "bbb222",
    "name": "video.mp4",
    "url": "https://example.com/video.mp4",
    "convertion_status": "DONE",
    "size": 5_000_000.0,
    "mimetype": "video/mp4",
}

MEDIA_C: dict[str, Any] = {
    "id": "ccc333",
    "name": "image.png",
    "url": "https://example.com/image.png",
    "convertion_status": "DEFAULT",
    "size": 12_000.0,
    "mimetype": "image/png",
}

MEDIA_D: dict[str, Any] = {
    "id": "ddd444",
    "name": "subtitle.srt",
    "url": "https://example.com/subtitle.srt",
    "convertion_status": "DONE",
    "size": 3_200.0,
    "mimetype": "text/plain",
}

# ---------------------------------------------------------------------------
# Complex nested fixtures for diff_media_ids tests.
# Files are embedded both as dict values AND as direct list elements.
# Also includes None slots, empty lists, and partial (non-media) dicts.
#
# COMPLEX_OLD_BODY unique media IDs: {A, B, C}
# COMPLEX_NEW_BODY unique media IDs: {B, C, D}
#   → diff: added=[D], removed=[A]
# ---------------------------------------------------------------------------

COMPLEX_OLD_BODY: dict[str, Any] = {
    "id": "lesson-001",
    "title": "Advanced Python Programming",
    "metadata": {"author": "Alice", "tags": ["python", "advanced"], "version": 3},
    # Media as a direct nested dict value
    "cover_image": MEDIA_C,
    "sections": [
        {
            "id": "sec-1",
            "type": "introduction",
            "title": "Getting Started",
            # Media as dict value inside a list item
            "audio_narration": MEDIA_A,
            # None in a slot that could hold a file
            "thumbnail": None,
            "content_blocks": [
                {"type": "text", "value": "Welcome to the course"},
                # Media deeply nested inside a list-of-block-dicts
                {"type": "video", "file": MEDIA_B},
                # Partial dict — missing signature fields — must NOT be detected
                {
                    "type": "caption",
                    "file": {
                        "id": "cap-001",
                        "url": "https://example.com/cap.vtt",
                        "name": "captions.vtt",
                    },
                },
            ],
            # Media objects as direct elements inside a list
            "attachments": [MEDIA_A, MEDIA_C],
        },
        {
            "id": "sec-2",
            "type": "exercise",
            "title": "Practice",
            "audio_narration": None,
            "resources": [
                {
                    "title": "Worksheet",
                    # Media inside a list of resource objects
                    "file": MEDIA_B,
                    "thumbnail": None,
                },
                {
                    "title": "Reference",
                    "file": None,  # explicitly no file
                    "notes": "Check intranet",
                },
            ],
            "attachments": [],  # empty list
        },
    ],
    "footer": {
        "credits": {"audio": None},  # None at deep path
        "related": [],
    },
}

# Modified body: cover_image C→D; MEDIA_A removed from every location;
# MEDIA_B and MEDIA_C unchanged.
COMPLEX_NEW_BODY: dict[str, Any] = {
    "id": "lesson-001",
    "title": "Advanced Python Programming (v2)",
    "metadata": {"author": "Alice", "tags": ["python", "advanced"], "version": 4},
    # cover_image swapped: C stayed, D added as new hero
    "cover_image": MEDIA_D,
    "sections": [
        {
            "id": "sec-1",
            "type": "introduction",
            "title": "Getting Started",
            # MEDIA_A removed — slot now None
            "audio_narration": None,
            "thumbnail": None,
            "content_blocks": [
                {"type": "text", "value": "Welcome to the course"},
                {"type": "video", "file": MEDIA_B},
                {
                    "type": "caption",
                    "file": {
                        "id": "cap-001",
                        "url": "https://example.com/cap.vtt",
                        "name": "captions.vtt",
                    },
                },
            ],
            # MEDIA_A removed from the list; MEDIA_C remains
            "attachments": [MEDIA_C],
        },
        {
            "id": "sec-2",
            "type": "exercise",
            "title": "Practice",
            "audio_narration": None,
            "resources": [
                {
                    "title": "Worksheet",
                    "file": MEDIA_B,
                    "thumbnail": None,
                },
                {
                    "title": "Reference",
                    "file": None,
                    "notes": "Check intranet",
                },
            ],
            "attachments": [],
        },
    ],
    "footer": {
        "credits": {"audio": None},
        "related": [],
    },
}


# ---------------------------------------------------------------------------
# _group_by_prefix
# ---------------------------------------------------------------------------


def test_group_by_prefix_root_level_keys():
    """Keys with no dot land under __root__."""
    flat = {"alpha": 1, "beta": 2}
    groups = _group_by_prefix(flat)
    assert "__root__" in groups
    assert groups["__root__"] == {"alpha": 1, "beta": 2}


def test_group_by_prefix_single_level_nesting():
    """One-dot keys are grouped by their prefix."""
    flat = {"a.x": 1, "a.y": 2, "b.z": 3}
    groups = _group_by_prefix(flat)
    assert groups["a"] == {"x": 1, "y": 2}
    assert groups["b"] == {"z": 3}


def test_group_by_prefix_deep_nesting():
    """Deep paths use their immediate parent as prefix."""
    flat = {"a.b.c.id": "x", "a.b.c.url": "y", "a.b.d": 99}
    groups = _group_by_prefix(flat)
    assert groups["a.b.c"] == {"id": "x", "url": "y"}
    assert groups["a.b"] == {"d": 99}


def test_group_by_prefix_mixed_depths():
    flat = {"root_key": True, "section.title": "hello", "section.meta.version": 2}
    groups = _group_by_prefix(flat)
    assert groups["__root__"] == {"root_key": True}
    assert groups["section"] == {"title": "hello"}
    assert groups["section.meta"] == {"version": 2}


def test_group_by_prefix_empty_dict():
    assert _group_by_prefix({}) == {}


# ---------------------------------------------------------------------------
# _find_media_prefixes
# ---------------------------------------------------------------------------


def _flatten(data: dict[str, Any]) -> dict[str, Any]:
    """Thin wrapper to avoid importing flatten_dict directly in tests."""
    from ..utils import flatten_dict

    return flatten_dict(data)


def test_find_media_prefixes_detects_root_media():
    """A media object at root level is found under __root__."""
    flat = _flatten(MEDIA_A)
    found = _find_media_prefixes(flat)
    assert "__root__" in found
    assert found["__root__"] == MEDIA_A["id"]


def test_find_media_prefixes_detects_nested_media():
    data = {"lesson": {"audio": MEDIA_A}}
    flat = _flatten(data)
    found = _find_media_prefixes(flat)
    assert "lesson.audio" in found
    assert found["lesson.audio"] == MEDIA_A["id"]


def test_find_media_prefixes_detects_deeply_nested_media():
    data = {"body": {"blocks": {"item_0": {"file": MEDIA_B}}}}
    flat = _flatten(data)
    found = _find_media_prefixes(flat)
    assert "body.blocks.item_0.file" in found
    assert found["body.blocks.item_0.file"] == MEDIA_B["id"]


def test_find_media_prefixes_multiple_media_objects():
    data = {"audio": MEDIA_A, "video": MEDIA_B}
    flat = _flatten(data)
    found = _find_media_prefixes(flat)
    assert found["audio"] == MEDIA_A["id"]
    assert found["video"] == MEDIA_B["id"]


def test_find_media_prefixes_partial_signature_not_detected():
    """A dict missing even one signature field must NOT be detected."""
    partial = {k: v for k, v in MEDIA_A.items() if k != "convertion_status"}
    data = {"file": partial}
    flat = _flatten(data)
    found = _find_media_prefixes(flat)
    assert found == {}


def test_find_media_prefixes_extra_keys_still_detected():
    """Extra keys beyond the signature don't prevent detection."""
    extended = {**MEDIA_A, "extra_field": "something", "another": 42}
    data = {"file": extended}
    flat = _flatten(data)
    found = _find_media_prefixes(flat)
    assert "file" in found
    assert found["file"] == MEDIA_A["id"]


def test_find_media_prefixes_no_media_returns_empty():
    data = {"title": "Hello", "meta": {"author": "Alice", "version": 1}}
    flat = _flatten(data)
    assert _find_media_prefixes(flat) == {}


def test_find_media_prefixes_empty_dict():
    assert _find_media_prefixes({}) == {}


# ---------------------------------------------------------------------------
# extract_media_ids
# ---------------------------------------------------------------------------


def test_extract_media_ids_empty_dict():
    assert extract_media_ids({}) == []


def test_extract_media_ids_none_like_empty():
    # Falsy but non-empty corner case: empty nested dicts
    assert extract_media_ids({"a": {}}) == []


def test_extract_media_ids_no_media_objects():
    data = {"title": "Lesson 1", "description": "Some text", "order": 3}
    assert extract_media_ids(data) == []


def test_extract_media_ids_single_media_at_root():
    """Media object is the top-level dict itself."""
    ids = extract_media_ids(MEDIA_A)
    assert ids == [MEDIA_A["id"]]


def test_extract_media_ids_single_nested_media():
    data = {"lesson": {"audio": MEDIA_A}}
    assert extract_media_ids(data) == [MEDIA_A["id"]]


def test_extract_media_ids_multiple_distinct_media():
    data = {"audio": MEDIA_A, "video": MEDIA_B, "image": MEDIA_C}
    ids = extract_media_ids(data)
    assert set(ids) == {MEDIA_A["id"], MEDIA_B["id"], MEDIA_C["id"]}
    assert len(ids) == 3


def test_extract_media_ids_deduplication_same_id_at_multiple_paths():
    """Same media object referenced at two different paths → one ID returned."""
    data = {
        "block_1": {"file": MEDIA_A},
        "block_2": {"file": MEDIA_A},  # same object, different path
    }
    ids = extract_media_ids(data)
    assert ids == [MEDIA_A["id"]]
    assert len(ids) == 1


def test_extract_media_ids_preserves_first_seen_order():
    """IDs are returned in first-encountered order."""
    data = {
        "first": MEDIA_A,
        "second": MEDIA_B,
        "third": MEDIA_C,
    }
    ids = extract_media_ids(data)
    # Dict insertion order is preserved in Python 3.7+; flatten_dict preserves it too.
    assert ids[0] == MEDIA_A["id"]
    assert ids[-1] == MEDIA_C["id"]


def test_extract_media_ids_deeply_nested():
    data = {
        "body": {
            "sections": {
                "intro": {
                    "content": {
                        "attachment": MEDIA_B,
                    }
                }
            }
        }
    }
    assert extract_media_ids(data) == [MEDIA_B["id"]]


def test_extract_media_ids_mixed_media_and_plain_fields():
    data = {
        "title": "My Lesson",
        "order": 1,
        "audio": MEDIA_A,
        "meta": {"author": "Alice"},
    }
    assert extract_media_ids(data) == [MEDIA_A["id"]]


def test_extract_media_ids_partial_signature_ignored():
    """Dicts missing a signature key must not appear in the result."""
    incomplete = {k: v for k, v in MEDIA_A.items() if k != "size"}
    data = {"file": incomplete}
    assert extract_media_ids(data) == []


# ---------------------------------------------------------------------------
# remove_media_by_ids
# ---------------------------------------------------------------------------


def test_remove_media_by_ids_empty_data_returns_unchanged():
    assert remove_media_by_ids({}, ["aaa111"]) == {}


def test_remove_media_by_ids_empty_ids_returns_original():
    data = {"audio": MEDIA_A}
    result = remove_media_by_ids(data, [])
    assert result == data


def test_remove_media_by_ids_id_not_in_data_no_op():
    data = {"audio": MEDIA_A}
    result = remove_media_by_ids(data, ["nonexistent_id"])
    assert result == data


def test_remove_media_by_ids_replace_with_none_default():
    """Default: media object is replaced with None at the same key."""
    data = {"lesson": {"audio": MEDIA_A}}
    result = remove_media_by_ids(data, [MEDIA_A["id"]])
    assert result == {"lesson": {"audio": None}}


def test_remove_media_by_ids_replace_with_custom_value():
    data = {"audio": MEDIA_A}
    result = remove_media_by_ids(
        data, [MEDIA_A["id"]], replacement={"placeholder": True}
    )
    assert result == {"audio": {"placeholder": True}}


def test_remove_media_by_ids_replace_with_ellipsis_omits_key():
    """replacement=... → the key is removed entirely from the output."""
    data = {"lesson": {"audio": MEDIA_A, "title": "Hello"}}
    result = remove_media_by_ids(data, [MEDIA_A["id"]], replacement=...)
    assert "audio" not in result["lesson"]
    assert result["lesson"]["title"] == "Hello"


def test_remove_media_by_ids_remove_multiple():
    data = {"audio": MEDIA_A, "video": MEDIA_B, "image": MEDIA_C}
    result = remove_media_by_ids(data, [MEDIA_A["id"], MEDIA_B["id"]])
    assert result["audio"] is None
    assert result["video"] is None
    assert result["image"] == MEDIA_C  # untouched


def test_remove_media_by_ids_same_id_at_multiple_paths_all_removed():
    """Both occurrences of the same media are nullified."""
    data = {
        "block_1": {"file": MEDIA_A},
        "block_2": {"file": MEDIA_A},
    }
    result = remove_media_by_ids(data, [MEDIA_A["id"]])
    assert result["block_1"]["file"] is None
    assert result["block_2"]["file"] is None


def test_remove_media_by_ids_deeply_nested():
    data = {
        "body": {
            "intro": {
                "attachment": MEDIA_B,
            },
            "title": "Section",
        }
    }
    result = remove_media_by_ids(data, [MEDIA_B["id"]])
    assert result["body"]["intro"]["attachment"] is None
    assert result["body"]["title"] == "Section"


def test_remove_media_by_ids_no_media_in_data_returns_unchanged():
    data = {"title": "Lesson", "order": 1, "meta": {"author": "Bob"}}
    result = remove_media_by_ids(data, [MEDIA_A["id"]])
    assert result == data


def test_remove_media_by_ids_preserves_non_targeted_media():
    """Only the targeted ID is removed; other media objects stay intact."""
    data = {"audio": MEDIA_A, "video": MEDIA_B}
    result = remove_media_by_ids(data, [MEDIA_A["id"]])
    assert result["audio"] is None
    assert result["video"] == MEDIA_B


def test_remove_media_by_ids_ellipsis_multiple_occurrences():
    data = {
        "a": MEDIA_A,
        "b": MEDIA_A,
        "c": {"title": "keep me"},
    }
    result = remove_media_by_ids(data, [MEDIA_A["id"]], replacement=...)
    assert "a" not in result
    assert "b" not in result
    assert result["c"] == {"title": "keep me"}


def test_remove_media_by_ids_root_level_media_replaced_with_none():
    """When the media object IS the root, it cannot be given a parent key;
    the result should be an empty dict (no prefix ≠ __root__ in flat form)."""
    # The media object at root lands under __root__ prefix — since __root__
    # is a sentinel and not a real key, replacement is only injected when
    # prefix != "__root__".  After removing all signature keys the result is {}.
    result = remove_media_by_ids(MEDIA_A, [MEDIA_A["id"]])
    assert result == {}


def test_remove_media_by_ids_string_and_non_string_ids_coerced():
    """IDs are coerced to str; passing an int ID should still match."""
    media_int_id: dict[str, Any] = {**MEDIA_A, "id": 12345}
    data = {"file": media_int_id}
    # Pass as int — should be coerced to "12345" and match
    result = remove_media_by_ids(data, [12345])
    assert result["file"] is None


def test_remove_media_by_ids_extra_keys_in_media_all_removed():
    """Extra fields beyond the signature are all removed along with the object."""
    extended = {**MEDIA_A, "custom_meta": {"resolution": "4K"}}
    data = {"file": extended}
    result = remove_media_by_ids(data, [MEDIA_A["id"]])
    assert result == {"file": None}


# List-embedded media — the core scenario that flatten_dict cannot handle.


def test_remove_media_by_ids_direct_list_element_replaced_with_none():
    """Media object that is a direct element in a list → replaced with None."""
    data = {"attachments": [MEDIA_A, MEDIA_C]}
    result = remove_media_by_ids(data, [MEDIA_A["id"]])
    assert result["attachments"] == [None, MEDIA_C]


def test_remove_media_by_ids_direct_list_element_omitted_with_ellipsis():
    """Media object that is a direct list element is removed entirely."""
    data = {"attachments": [MEDIA_A, MEDIA_C]}
    result = remove_media_by_ids(data, [MEDIA_A["id"]], replacement=...)
    assert result == {"attachments": [MEDIA_C]}


def test_remove_media_by_ids_all_list_elements_removed():
    """All elements in a list are targeted → list becomes empty."""
    data = {"files": [MEDIA_A, MEDIA_B]}
    result = remove_media_by_ids(data, [MEDIA_A["id"], MEDIA_B["id"]], replacement=...)
    assert result == {"files": []}


def test_remove_media_by_ids_media_inside_list_of_dicts():
    """Media nested as a value inside dicts that are elements of a list."""
    data = {
        "sections": [
            {"audio": MEDIA_A, "label": "intro"},
            {"audio": MEDIA_B, "label": "main"},
        ]
    }
    result = remove_media_by_ids(data, [MEDIA_A["id"]])
    assert result["sections"][0]["audio"] is None
    assert result["sections"][0]["label"] == "intro"
    assert result["sections"][1]["audio"] == MEDIA_B  # untouched


def test_remove_media_by_ids_media_inside_list_of_dicts_ellipsis():
    """Key removed from its parent dict when media is inside a list element."""
    data = {
        "sections": [
            {"audio": MEDIA_A, "label": "intro"},
            {"audio": MEDIA_B, "label": "main"},
        ]
    }
    result = remove_media_by_ids(data, [MEDIA_A["id"]], replacement=...)
    assert "audio" not in result["sections"][0]
    assert result["sections"][0]["label"] == "intro"
    assert result["sections"][1]["audio"] == MEDIA_B


def test_remove_media_by_ids_deeply_nested_in_list():
    """Media buried deep inside nested list-of-dicts structure."""
    data = {
        "chapters": [
            {
                "slides": [
                    {"content": {"file": MEDIA_B}},
                    {"content": {"file": MEDIA_C}},
                ]
            }
        ]
    }
    result = remove_media_by_ids(data, [MEDIA_B["id"]])
    assert result["chapters"][0]["slides"][0]["content"]["file"] is None
    assert result["chapters"][0]["slides"][1]["content"]["file"] == MEDIA_C


def test_remove_media_by_ids_mixed_list_dict_and_scalar_elements():
    """List contains a mix of media objects, plain dicts, and scalars."""
    data = {
        "items": [
            MEDIA_A,
            {"note": "plain dict"},
            42,
            MEDIA_B,
        ]
    }
    result = remove_media_by_ids(data, [MEDIA_A["id"]], replacement=...)
    assert len(result["items"]) == 3
    assert {"note": "plain dict"} in result["items"]
    assert 42 in result["items"]
    assert MEDIA_B in result["items"]


def test_remove_media_by_ids_none_slots_in_list_untouched():
    """None elements inside a list are left in place (they are not media)."""
    data = {"files": [None, MEDIA_A, None]}
    result = remove_media_by_ids(data, [MEDIA_A["id"]], replacement=...)
    assert result == {"files": [None, None]}


def test_remove_media_by_ids_list_same_media_multiple_times():
    """Same media object appears multiple times in the same list."""
    data = {"files": [MEDIA_A, MEDIA_A, MEDIA_B]}
    result = remove_media_by_ids(data, [MEDIA_A["id"]], replacement=...)
    assert result == {"files": [MEDIA_B]}


def test_remove_media_by_ids_complex_body_removes_list_and_dict_media():
    """Uses COMPLEX_OLD_BODY to remove MEDIA_A from both dict values and list
    elements simultaneously."""
    result = remove_media_by_ids(COMPLEX_OLD_BODY, [MEDIA_A["id"]], replacement=...)
    # audio_narration (dict value) must be gone
    assert "audio_narration" not in result["sections"][0]
    # attachments list had [MEDIA_A, MEDIA_C] — MEDIA_A element removed
    assert MEDIA_C in result["sections"][0]["attachments"]
    assert not any(
        isinstance(item, dict) and item.get("id") == MEDIA_A["id"]
        for item in result["sections"][0]["attachments"]
    )
    # MEDIA_C and MEDIA_B elsewhere are untouched
    assert result["cover_image"] == MEDIA_C


# ---------------------------------------------------------------------------
# diff_media_ids  —  complex nested data
# ---------------------------------------------------------------------------


def test_diff_media_ids_both_empty():
    """Two empty dicts → nothing added or removed."""
    added, removed = diff_media_ids({}, {})
    assert added == []
    assert removed == []


def test_diff_media_ids_identical_complex_data_no_diff():
    """Same complex structure passed as both old and new → no changes."""
    added, removed = diff_media_ids(COMPLEX_OLD_BODY, COMPLEX_OLD_BODY)
    assert added == []
    assert removed == []


def test_diff_media_ids_complex_main_scenario():
    """Core scenario using realistic lesson body.

    Old IDs (dict values + list elements): {A, B, C}
    New IDs: {B, C, D}  (A removed everywhere; D added as cover_image)
    Expected: added=[D], removed=[A].
    """
    added, removed = diff_media_ids(COMPLEX_OLD_BODY, COMPLEX_NEW_BODY)
    assert set(added) == {MEDIA_D["id"]}
    assert set(removed) == {MEDIA_A["id"]}


def test_diff_media_ids_complex_all_removed_new_empty():
    """All media removed when new data is an empty dict."""
    added, removed = diff_media_ids(COMPLEX_OLD_BODY, {})
    assert added == []
    assert set(removed) == {MEDIA_A["id"], MEDIA_B["id"], MEDIA_C["id"]}


def test_diff_media_ids_complex_all_added_old_empty():
    """All media treated as added when old data is an empty dict."""
    added, removed = diff_media_ids({}, COMPLEX_OLD_BODY)
    assert set(added) == {MEDIA_A["id"], MEDIA_B["id"], MEDIA_C["id"]}
    assert removed == []


def test_diff_media_ids_media_in_list_added():
    """New data introduces files directly inside a list."""
    old_data = {"title": "Lesson", "attachments": []}
    new_data = {"title": "Lesson", "attachments": [MEDIA_A, MEDIA_B]}
    added, removed = diff_media_ids(old_data, new_data)
    assert set(added) == {MEDIA_A["id"], MEDIA_B["id"]}
    assert removed == []


def test_diff_media_ids_media_in_list_removed():
    """Removing a file that was directly inside a list."""
    old_data = {"title": "Lesson", "attachments": [MEDIA_A, MEDIA_B]}
    new_data = {"title": "Lesson", "attachments": [MEDIA_B]}
    added, removed = diff_media_ids(old_data, new_data)
    assert added == []
    assert removed == [MEDIA_A["id"]]


def test_diff_media_ids_media_in_list_replaced():
    """One file inside a list replaced by another."""
    old_data = {"files": [MEDIA_A, MEDIA_B]}
    new_data = {"files": [MEDIA_C, MEDIA_B]}
    added, removed = diff_media_ids(old_data, new_data)
    assert added == [MEDIA_C["id"]]
    assert removed == [MEDIA_A["id"]]


def test_diff_media_ids_media_in_nested_list_of_block_dicts():
    """Files embedded inside a list of block objects at various nesting depths."""
    old_data = {
        "blocks": [
            {"type": "audio", "file": MEDIA_A},
            {"type": "video", "file": MEDIA_B},
            {"type": "text", "value": "No file here"},
        ]
    }
    new_data = {
        "blocks": [
            {"type": "audio", "file": MEDIA_A},
            {"type": "video", "file": MEDIA_C},  # B replaced with C
            {"type": "text", "value": "No file here"},
        ]
    }
    added, removed = diff_media_ids(old_data, new_data)
    assert added == [MEDIA_C["id"]]
    assert removed == [MEDIA_B["id"]]


def test_diff_media_ids_deeply_nested_inside_lists():
    """Media several levels deep inside nested lists and dicts."""
    old_data = {
        "course": {
            "chapters": [
                {
                    "lessons": [
                        {
                            "resources": [MEDIA_A, MEDIA_B],
                            "cover": MEDIA_C,
                        }
                    ]
                }
            ]
        }
    }
    new_data = {
        "course": {
            "chapters": [
                {
                    "lessons": [
                        {
                            "resources": [MEDIA_D],  # A and B replaced by D
                            "cover": MEDIA_C,
                        }
                    ]
                }
            ]
        }
    }
    added, removed = diff_media_ids(old_data, new_data)
    assert added == [MEDIA_D["id"]]
    assert set(removed) == {MEDIA_A["id"], MEDIA_B["id"]}


def test_diff_media_ids_mixed_list_and_dict_embedding():
    """Files appear both as dict values AND as direct list elements in the
    same structure; all are detected and diffed correctly."""
    old_data = {
        "header_file": MEDIA_A,  # dict value
        "gallery": [MEDIA_B, MEDIA_C],  # direct list elements
        "sections": [
            {"file": MEDIA_A},  # nested dict inside a list
        ],
    }
    # B replaced by D; A and C remain
    new_data = {
        "header_file": MEDIA_A,
        "gallery": [MEDIA_D, MEDIA_C],  # B → D
        "sections": [
            {"file": MEDIA_A},
        ],
    }
    added, removed = diff_media_ids(old_data, new_data)
    assert added == [MEDIA_D["id"]]
    assert removed == [MEDIA_B["id"]]


def test_diff_media_ids_none_slots_silently_ignored():
    """None values in file slots are ignored on both sides."""
    old_data = {
        "audio": MEDIA_A,
        "thumbnail": None,
        "sections": [
            {"file": None, "title": "intro"},
            {"file": MEDIA_B, "title": "main"},
        ],
    }
    # Replace MEDIA_A with None; MEDIA_B remains
    new_data = {
        "audio": None,
        "thumbnail": None,
        "sections": [
            {"file": None, "title": "intro"},
            {"file": MEDIA_B, "title": "main"},
        ],
    }
    added, removed = diff_media_ids(old_data, new_data)
    assert added == []
    assert removed == [MEDIA_A["id"]]


def test_diff_media_ids_list_of_nones_harmless():
    """A list containing only None values is silently skipped."""
    old_data = {"files": [None, None], "audio": MEDIA_A}
    new_data = {"files": [None, None], "audio": None}
    added, removed = diff_media_ids(old_data, new_data)
    assert added == []
    assert removed == [MEDIA_A["id"]]


def test_diff_media_ids_empty_lists_no_diff():
    """Structures with only empty lists produce no diff."""
    old_data = {"attachments": [], "sections": [{"files": []}]}
    new_data = {"attachments": [], "sections": [{"files": []}]}
    added, removed = diff_media_ids(old_data, new_data)
    assert added == []
    assert removed == []


def test_diff_media_ids_partial_dicts_not_detected():
    """Dicts resembling media but missing signature fields are ignored."""
    incomplete = {k: v for k, v in MEDIA_A.items() if k != "convertion_status"}
    old_data = {"file": incomplete, "audio": MEDIA_B}
    new_data = {"file": incomplete, "audio": MEDIA_C}  # B → C
    added, removed = diff_media_ids(old_data, new_data)
    assert added == [MEDIA_C["id"]]
    assert removed == [MEDIA_B["id"]]


def test_diff_media_ids_same_id_many_locations_dedup():
    """Same ID appearing in multiple locations (dict + list) counts once."""
    old_data = {
        "audio": MEDIA_A,
        "backup_audio": MEDIA_A,  # dict duplicate
        "attachments": [MEDIA_A],  # list duplicate
    }
    new_data = {}
    added, removed = diff_media_ids(old_data, new_data)
    assert added == []
    assert removed == [MEDIA_A["id"]]  # deduplicated to a single entry


def test_diff_media_ids_no_media_in_either():
    """Plain structured data with no media objects → empty diff."""
    old_data = {
        "title": "Lesson",
        "sections": [
            {"title": "Intro", "text": "Hello"},
            {"title": "Body", "items": [1, 2, 3]},
        ],
    }
    new_data = {
        "title": "Lesson Updated",
        "sections": [
            {"title": "Intro", "text": "Hello world"},
            {"title": "Body", "items": [4, 5, 6]},
        ],
    }
    added, removed = diff_media_ids(old_data, new_data)
    assert added == []
    assert removed == []


def test_diff_media_ids_returns_lists_not_sets():
    """Return types must be list, not set or other iterable."""
    added, removed = diff_media_ids({"a": MEDIA_A}, {})
    assert isinstance(added, list)
    assert isinstance(removed, list)


def test_diff_media_ids_added_and_removed_are_disjoint():
    """An ID must never appear in both added and removed simultaneously."""
    added, removed = diff_media_ids(COMPLEX_OLD_BODY, COMPLEX_NEW_BODY)
    assert set(added).isdisjoint(set(removed))


def test_diff_media_ids_preserves_stable_order_from_each_side():
    """Added/removed ordering follows first-encountered order, not set order."""
    old_data = {
        "files": [MEDIA_A, MEDIA_B],
    }
    new_data = {
        "files": [MEDIA_C, MEDIA_B, MEDIA_D],
    }
    added, removed = diff_media_ids(old_data, new_data)
    assert added == [MEDIA_C["id"], MEDIA_D["id"]]
    assert removed == [MEDIA_A["id"]]


# ---------------------------------------------------------------------------
# exclude parameter (extract_media_ids / diff_media_ids)
# ---------------------------------------------------------------------------

# A zero-ID media object — should be filtered out by default.
MEDIA_ZERO_ID: dict[str, Any] = {
    "id": "0",
    "name": "placeholder.wav",
    "url": "https://example.com/placeholder.wav",
    "convertion_status": "DEFAULT",
    "size": 0.0,
    "mimetype": "audio/x-wav",
}


def test_extract_media_ids_default_excludes_zero_id():
    """ID '0' is excluded by default without passing exclude explicitly."""
    data = {"file": MEDIA_ZERO_ID}
    assert extract_media_ids(data) == []


def test_extract_media_ids_default_excludes_zero_id_among_others():
    """'0' is silently dropped; real IDs are still returned."""
    data = {"placeholder": MEDIA_ZERO_ID, "real": MEDIA_A}
    assert extract_media_ids(data) == [MEDIA_A["id"]]


def test_extract_media_ids_zero_id_included_when_exclude_overridden():
    """Passing exclude=set() disables filtering and includes id '0'."""
    data = {"file": MEDIA_ZERO_ID}
    assert extract_media_ids(data, exclude=set()) == ["0"]


def test_extract_media_ids_custom_exclude_list():
    """Custom exclude set filters out any specified IDs."""
    data = {"a": MEDIA_A, "b": MEDIA_B, "c": MEDIA_C}
    ids = extract_media_ids(data, exclude={MEDIA_B["id"]})
    assert MEDIA_B["id"] not in ids
    assert set(ids) == {MEDIA_A["id"], MEDIA_C["id"]}


def test_extract_media_ids_exclude_all_ids():
    """Excluding every ID present returns an empty list."""
    data = {"a": MEDIA_A, "b": MEDIA_B}
    ids = extract_media_ids(data, exclude={MEDIA_A["id"], MEDIA_B["id"]})
    assert ids == []


def test_extract_media_ids_exclude_in_list():
    """Excluded IDs inside a list are also filtered out."""
    data = {"attachments": [MEDIA_ZERO_ID, MEDIA_A]}
    assert extract_media_ids(data) == [MEDIA_A["id"]]


def test_extract_media_ids_exclude_int_zero_coerced():
    """Integer 0 in a media id field is also excluded by default (coerced to str)."""
    media_int_zero: dict[str, Any] = {**MEDIA_A, "id": 0}
    data = {"file": media_int_zero}
    assert extract_media_ids(data) == []


def test_extract_media_ids_int_zero_included_when_exclude_overridden():
    """Integer 0 should be included when exclude filtering is disabled."""
    media_int_zero: dict[str, Any] = {**MEDIA_A, "id": 0}
    data = {"file": media_int_zero}
    assert extract_media_ids(data, exclude=set()) == ["0"]


def test_diff_media_ids_default_excludes_zero_id():
    """'0' IDs are excluded from both sides of a diff by default."""
    old_data = {"file": MEDIA_ZERO_ID, "audio": MEDIA_A}
    new_data = {"file": MEDIA_ZERO_ID, "audio": MEDIA_B}
    added, removed = diff_media_ids(old_data, new_data)
    assert "0" not in added
    assert "0" not in removed
    assert added == [MEDIA_B["id"]]
    assert removed == [MEDIA_A["id"]]


def test_diff_media_ids_zero_id_included_when_exclude_overridden():
    """Passing exclude=set() makes '0' visible to the diff."""
    old_data = {"file": MEDIA_ZERO_ID}
    new_data = {}
    added, removed = diff_media_ids(old_data, new_data, exclude=set())
    assert removed == ["0"]
    assert added == []


def test_diff_media_ids_custom_exclude_consistent_both_sides():
    """A custom exclude ID present in both old and new is invisible in the diff."""
    # MEDIA_B is excluded — it appears in both old and new, so neither add nor remove
    old_data = {"audio": MEDIA_A, "video": MEDIA_B}
    new_data = {"audio": MEDIA_C, "video": MEDIA_B}
    added, removed = diff_media_ids(old_data, new_data, exclude={MEDIA_B["id"]})
    assert MEDIA_B["id"] not in added
    assert MEDIA_B["id"] not in removed
    assert added == [MEDIA_C["id"]]
    assert removed == [MEDIA_A["id"]]


# ===========================================================================
# replace_media_objects
# ===========================================================================

# Canonical placeholder a typical service might ship.
DEFAULT_FILE_SCHEMA: dict[str, Any] = {
    "id": "0",
    "name": None,
    "url": "https://cdn.example.com/default-avatar.png",
    "size": 0,
    "mimetype": "image/png",
    "convertion_status": None,
    "stream_url": None,
}


# Shape that mirrors the real media-service media-retrieve response payload.
# Sourced from a live production example so tests validate against the exact
# field set, types (integer size, microsecond-precise duration), and the
# relative `/media/v1/...` URL shape that backend code actually returns.
# uploaded_by carries nested profile_picture / cover_photo dicts; those are
# NOT signature-matched media objects (they only have 2 keys, not 6) so the
# walker correctly leaves them alone.
RETRIEVE_RESPONSE: dict[str, Any] = {
    "id": "eefc567b63704707b87171cea2f0ac0c",
    "tag": "Hello",
    "name": "administration.wav",
    "url": "/media/v1/enterprise/files/eefc567b63704707b87171cea2f0ac0c/stream/",
    "thumbnail_url": None,
    "size": 84906,
    "caption": "hello",
    "convertion_status": "DONE",
    "convertion_canceled": False,
    "mimetype": "audio/x-wav",
    "last_used": "2024-11-04T14:25:59.846304Z",
    "duration": "00:00:01.924263",
    "created_at": "2024-11-04T14:25:28.360554Z",
    "updated_at": "2024-11-04T14:25:28.360590Z",
    "uploaded_by": {
        "id": "d15e07cf88",
        "full_name": "Retha Bergnaum",
        "profile_picture": {
            "url": "https://learngual-bucket.sfo3.cdn.digitaloceanspaces.com/static/default-avatar.png",
            "mimetype": "image/png",
        },
        "cover_photo": {},
    },
}


def test_replace_media_objects_empty_inputs_return_unchanged():
    """Empty data or empty state → input returned untouched."""
    assert (
        replace_media_objects(None, state={}, default_schema=DEFAULT_FILE_SCHEMA)
        is None
    )
    assert replace_media_objects({}, state={}, default_schema=DEFAULT_FILE_SCHEMA) == {}
    assert replace_media_objects(
        {"file": MEDIA_A}, state={}, default_schema=DEFAULT_FILE_SCHEMA
    ) == {"file": MEDIA_A}


def test_replace_media_objects_id_not_in_state_leaves_untouched():
    """Media object whose id isn't keyed in state is preserved verbatim."""
    data = {"file": MEDIA_A}
    out = replace_media_objects(
        data,
        state={"different-id": {"url": "https://fresh.example.com/x"}},
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    assert out == {"file": MEDIA_A}


def test_replace_media_objects_trashed_swaps_to_placeholder_with_file_id():
    """state[id] is None → swap object for default_schema with file_id."""
    data = {"file": MEDIA_A}
    out = replace_media_objects(
        data,
        state={MEDIA_A["id"]: None},
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    assert out["file"] == {**DEFAULT_FILE_SCHEMA, "file_id": MEDIA_A["id"]}


def test_replace_media_objects_fresh_state_merges_and_sets_file_id():
    """state[id] is a dict (the FULL media-service Retrieve response shape)
    → merge over stored JSON + set file_id = id. The fresh state contains
    every key the real Retrieve endpoint returns, so the merge produces
    exactly the payload a client would get from media-service directly.

    In production both sides refer to the same FileMedia, so obj.id ==
    fresh.id. We mirror that by deriving the fresh state from
    RETRIEVE_RESPONSE with the carrier's id substituted in.
    """
    data = {"file": MEDIA_A}
    # Real Retrieve shape, with id aligned to MEDIA_A (in production the
    # resolver always pairs the right id with its row).
    fresh = {**RETRIEVE_RESPONSE, "id": MEDIA_A["id"]}
    out = replace_media_objects(
        data,
        state={MEDIA_A["id"]: fresh},
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    # Every key from the fresh Retrieve response is present in the merged
    # output (covers tag, caption, convertion_canceled, last_used,
    # uploaded_by nested account, etc.).
    for key in fresh:
        assert out["file"][key] == fresh[key], f"key {key!r} not merged"
    # file_id is the persistent reference (added by replace_media_objects).
    assert out["file"]["file_id"] == MEDIA_A["id"]
    # The merged dict carries the carrier's id.
    assert out["file"]["id"] == MEDIA_A["id"]


def test_replace_media_objects_deeply_nested_via_signature():
    """Media inside a polymorphic body / list / nested dict is rewritten too."""
    data = {
        "lecture": {
            "body": {
                "blocks": [
                    {"type": "text", "content": "hi"},
                    {"type": "audio", "file": MEDIA_A},
                    {"type": "video", "file": MEDIA_B},
                ]
            }
        }
    }
    # Fresh state for B mirrors a full media-service Retrieve response for
    # the video file (different id from RETRIEVE_RESPONSE which is audio).
    video_fresh = {
        **RETRIEVE_RESPONSE,
        "id": MEDIA_B["id"],
        "name": "video.mp4",
        "url": "https://fresh.example.com/video.mp4?Signature=fresh",
        "thumbnail_url": "https://fresh.example.com/video-thumb.jpg?Signature=fresh",
        "mimetype": "video/mp4",
        "size": 5_000_000.0,
        "duration": "00:05:00",
    }
    out = replace_media_objects(
        data,
        state={MEDIA_A["id"]: None, MEDIA_B["id"]: video_fresh},
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    blocks = out["lecture"]["body"]["blocks"]
    assert blocks[0] == {"type": "text", "content": "hi"}  # untouched
    assert blocks[1]["file"] == {**DEFAULT_FILE_SCHEMA, "file_id": MEDIA_A["id"]}
    # B's file dict merges the full fresh Retrieve shape + file_id.
    for key in video_fresh:
        assert blocks[2]["file"][key] == video_fresh[key], f"key {key!r} not merged"
    assert blocks[2]["file"]["file_id"] == MEDIA_B["id"]


def test_replace_media_objects_input_not_mutated():
    """The walker rebuilds — original payload stays intact for caller reuse."""
    data: dict[str, Any] = {"file": dict(MEDIA_A)}
    snapshot = {"file": dict(MEDIA_A)}
    replace_media_objects(
        data,
        state={MEDIA_A["id"]: None},
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    assert data == snapshot


def test_extract_media_ids_include_file_id_recovers_from_masked_row():
    """A stored masked row ({id:'0', file_id:'abc'}) is invisible by default
    but surfaces 'abc' when include_file_id=True."""
    masked = {
        "thumb": {
            "id": "0",
            "file_id": "abc",
            "url": "default",
            "name": None,
            "size": 0,
            "mimetype": "image/png",
            "convertion_status": None,
        }
    }
    # Default behaviour (trash cleanup) — masked rows skipped.
    assert extract_media_ids(masked) == []
    # Resolver behaviour — file_id beacon recovered.
    assert extract_media_ids(masked, include_file_id=True) == ["abc"]


def test_extract_media_ids_include_file_id_only_when_id_is_excluded():
    """When ``id`` is non-zero, file_id is NOT also collected (avoids
    double-counting the same FileMedia under two different keys)."""
    obj = {
        "id": "real-id",
        "file_id": "real-id",
        "url": "u",
        "name": "n",
        "size": 1,
        "mimetype": "m",
        "convertion_status": "DONE",
    }
    # Only the id is collected — file_id is a beacon that mirrors id here.
    assert extract_media_ids({"file": obj}, include_file_id=True) == ["real-id"]


def test_extract_media_ids_include_file_id_handles_zero_file_id():
    """file_id='0' is also excluded — a fully-cleared placeholder yields
    no ids even with include_file_id=True."""
    masked = {
        "thumb": {
            "id": "0",
            "file_id": "0",
            "url": "default",
            "name": None,
            "size": 0,
            "mimetype": "image/png",
            "convertion_status": None,
        }
    }
    assert extract_media_ids(masked, include_file_id=True) == []


def test_replace_media_objects_recovers_active_file_from_stale_masked_row():
    """End-to-end: a stored masked row with file_id='abc' + state['abc']
    = fresh dict → response restores id='abc' (auto-recovery on read)."""
    stale = {
        "thumb": {
            "id": "0",
            "file_id": "abc",
            "url": "stored-default",
            "name": None,
            "size": 0,
            "mimetype": "image/png",
            "convertion_status": None,
        }
    }
    fresh = {
        "url": "https://fresh.example.com/abc.jpg",
        "mimetype": "image/jpeg",
        "convertion_status": "DONE",
    }
    out = replace_media_objects(
        stale,
        state={"abc": fresh},
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    # id restored from file_id; fresh fields merged.
    assert out["thumb"]["id"] == "abc"
    assert out["thumb"]["file_id"] == "abc"
    assert out["thumb"]["url"] == fresh["url"]
    assert out["thumb"]["mimetype"] == "image/jpeg"


def test_replace_media_objects_keeps_placeholder_when_stale_row_still_trashed():
    """Stale masked row + state['abc']=None (still trashed) → keep
    placeholder + file_id, no recovery."""
    stale = {
        "thumb": {
            "id": "0",
            "file_id": "abc",
            "url": "stored-default",
            "name": None,
            "size": 0,
            "mimetype": "image/png",
            "convertion_status": None,
        }
    }
    out = replace_media_objects(
        stale,
        state={"abc": None},
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    assert out["thumb"] == {**DEFAULT_FILE_SCHEMA, "file_id": "abc"}


def test_replace_media_objects_dangling_file_id_left_alone():
    """Stale masked row whose file_id is NOT in state (file permanently
    deleted) → leave the placeholder unchanged.  The dangling reference
    persists in the stored JSON but doesn't cause a swap on read."""
    stale = {
        "thumb": {
            "id": "0",
            "file_id": "gone",
            "url": "stored-default",
            "name": None,
            "size": 0,
            "mimetype": "image/png",
            "convertion_status": None,
        }
    }
    out = replace_media_objects(
        stale,
        state={},  # empty state — "gone" isn't anywhere
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    assert out == stale  # untouched


def test_replace_media_objects_media_in_list_at_root():
    """Media objects can be direct list elements at the root of the walk."""
    data = [MEDIA_A, MEDIA_B, {"plain": "dict"}]
    out = replace_media_objects(
        data,
        state={MEDIA_A["id"]: None},
        default_schema=DEFAULT_FILE_SCHEMA,
    )
    assert out[0] == {**DEFAULT_FILE_SCHEMA, "file_id": MEDIA_A["id"]}
    assert out[1] == MEDIA_B  # not in state → untouched
    assert out[2] == {"plain": "dict"}


# ===========================================================================
# normalize_media_object
# ===========================================================================


def test_normalize_media_object_passthrough_for_empty_and_non_dict():
    """None, empty, and non-dict-non-Pydantic inputs return unchanged."""
    assert normalize_media_object(None) is None
    assert normalize_media_object({}) == {}
    assert normalize_media_object("not-a-dict") == "not-a-dict"
    assert normalize_media_object(42) == 42


def test_normalize_media_object_real_id_drops_file_id():
    """Rule 1: id non-'0' → trust id, drop file_id."""
    payload = {**MEDIA_A, "file_id": "ignored"}
    out = normalize_media_object(payload)
    assert out["id"] == MEDIA_A["id"]
    assert "file_id" not in out
    # Other fields preserved.
    assert out["url"] == MEDIA_A["url"]
    assert out["name"] == MEDIA_A["name"]


def test_normalize_media_object_masked_round_trip_with_existing_file_restores_id():
    """Rule 2: id == '0' + file_id present + file exists → restore reference."""
    payload = {
        **DEFAULT_FILE_SCHEMA,
        "file_id": "real-id-123",
    }
    out = normalize_media_object(payload, existing_file_ids=frozenset({"real-id-123"}))
    assert out["id"] == "real-id-123"
    assert "file_id" not in out


def test_normalize_media_object_masked_round_trip_with_deleted_file_drops_reference():
    """Rule 3: id == '0' + file_id present + file gone → drop file_id, save verbatim."""
    payload = {
        **DEFAULT_FILE_SCHEMA,
        "file_id": "deleted-id-999",
    }
    out = normalize_media_object(payload, existing_file_ids=frozenset())  # empty
    assert out["id"] == "0"  # NOT restored to deleted reference
    assert "file_id" not in out
    # Rest of the payload preserved.
    assert out["url"] == DEFAULT_FILE_SCHEMA["url"]


def test_normalize_media_object_explicit_clear_no_file_id_overwrites():
    """Rule 4: id == '0' + no file_id → save verbatim (genuine clear)."""
    payload = {**DEFAULT_FILE_SCHEMA}  # no file_id
    out = normalize_media_object(payload, existing_file_ids=frozenset({"some-id"}))
    assert out["id"] == "0"
    assert "file_id" not in out
    assert out["url"] == DEFAULT_FILE_SCHEMA["url"]


def test_normalize_media_object_explicit_clear_file_id_zero_overwrites():
    """file_id == '0' counts as missing — overwrite path."""
    payload = {**DEFAULT_FILE_SCHEMA, "file_id": "0"}
    out = normalize_media_object(payload, existing_file_ids=frozenset({"some-id"}))
    assert out["id"] == "0"
    assert "file_id" not in out


def test_normalize_media_object_existing_file_ids_none_skips_check():
    """existing_file_ids=None → rule 2 fires whenever file_id is set (test-only path)."""
    payload = {**DEFAULT_FILE_SCHEMA, "file_id": "any-id"}
    out = normalize_media_object(payload, existing_file_ids=None)
    assert out["id"] == "any-id"
    assert "file_id" not in out


def test_normalize_media_object_pydantic_input_via_model_dump():
    """A duck-typed object with model_dump() should be normalised."""

    class FakePydantic:
        def model_dump(self):
            return {**MEDIA_A, "file_id": "ignored"}

    out = normalize_media_object(FakePydantic())
    assert out["id"] == MEDIA_A["id"]
    assert "file_id" not in out


def test_normalize_media_object_model_dump_raising_is_swallowed():
    """If model_dump raises, the payload is returned unchanged + a warning logged."""

    class BadPydantic:
        def model_dump(self):
            raise RuntimeError("boom")

    obj = BadPydantic()
    out = normalize_media_object(obj)
    assert out is obj  # unchanged


def test_normalize_media_object_malformed_id_field_returns_payload():
    """An exotic id value that breaks str() falls into the safe-passthrough branch."""

    class WeirdId:
        def __str__(self):
            raise ValueError("can't stringify")

    payload = {**MEDIA_A, "id": WeirdId()}
    # Should not raise; behaviour: log and return unchanged.
    out = normalize_media_object(payload)
    assert out is payload


# ===========================================================================
# normalize_media_payloads
# ===========================================================================


def test_normalize_media_payloads_empty_input_returns_unchanged():
    """None / empty inputs short-circuit."""
    assert normalize_media_payloads(None) is None
    assert normalize_media_payloads({}) == {}
    assert normalize_media_payloads([]) == []


def test_normalize_media_payloads_no_round_trip_candidates_skips_db_query():
    """If no nested media objects need existence checks, file_media_qs is never called."""
    calls: list[Any] = []

    def fake_qs(ids):  # pragma: no cover - asserted via len(calls)
        calls.append(ids)
        return []

    data = {"file": MEDIA_A, "image": MEDIA_C}  # all non-zero ids → no candidates
    out = normalize_media_payloads(data, file_media_qs=fake_qs)
    assert out == data  # nothing to normalise
    assert calls == []  # no DB hit


def test_normalize_media_payloads_round_trip_with_existing_files_restores_refs():
    """Single batch query returns the existing ids; references are restored."""

    class Row:
        def __init__(self, pk):
            self.pk = pk

    queried: list[set[str]] = []

    def fake_qs(ids):
        queried.append(set(ids))
        return [Row("real-id-123")]  # this id exists; others don't

    data = {
        "thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "real-id-123"},
        "cover": {**DEFAULT_FILE_SCHEMA, "file_id": "deleted-999"},
    }
    out = normalize_media_payloads(data, file_media_qs=fake_qs)

    # One batch query, including both candidate ids.
    assert len(queried) == 1
    assert queried[0] == {"real-id-123", "deleted-999"}

    # Existing file → id restored.
    assert out["thumbnail"]["id"] == "real-id-123"
    assert "file_id" not in out["thumbnail"]
    # Deleted file → file_id dropped, id stays "0".
    assert out["cover"]["id"] == "0"
    assert "file_id" not in out["cover"]


def test_normalize_media_payloads_deeply_nested_polymorphic_walk():
    """File ids buried in a polymorphic body (Lecture-shaped) are found and normalised."""

    class Row:
        def __init__(self, pk):
            self.pk = pk

    def fake_qs(ids):
        # Only the audio file still exists.
        return [Row("audio-real-id")]

    body = {
        "blocks": [
            {"type": "text", "content": "hello"},
            {
                "type": "audio",
                "file": {**DEFAULT_FILE_SCHEMA, "file_id": "audio-real-id"},
            },
            {
                "type": "video",
                "file": {**DEFAULT_FILE_SCHEMA, "file_id": "video-deleted"},
            },
        ]
    }
    out = normalize_media_payloads(body, file_media_qs=fake_qs)
    audio = out["blocks"][1]["file"]
    video = out["blocks"][2]["file"]
    assert audio["id"] == "audio-real-id"
    assert "file_id" not in audio
    assert video["id"] == "0"  # not restored
    assert "file_id" not in video


def test_normalize_media_payloads_file_media_qs_none_logs_and_preserves():
    """Misconfiguration: qs=None with candidates present → warning logged, refs preserved."""
    data = {
        "thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "some-id"},
    }
    out = normalize_media_payloads(data, file_media_qs=None)
    # In test mode (qs=None) we preserve optimistically.
    assert out["thumbnail"]["id"] == "some-id"
    assert "file_id" not in out["thumbnail"]


def test_normalize_media_payloads_file_media_qs_db_error_propagates():
    """A DB exception during the batch query is NOT swallowed — it must abort the write."""

    def failing_qs(ids):
        raise RuntimeError("database connection lost")

    data = {"thumbnail": {**DEFAULT_FILE_SCHEMA, "file_id": "some-id"}}
    try:
        normalize_media_payloads(data, file_media_qs=failing_qs)
    except RuntimeError as exc:
        assert "database" in str(exc)
    else:
        assert False, "expected RuntimeError to propagate"


def test_normalize_media_payloads_real_ids_passthrough_with_file_id_dropped():
    """Non-zero ids never participate in the existence check; file_id is dropped."""
    calls: list[Any] = []

    def fake_qs(ids):
        calls.append(ids)
        return []

    data = {"file": {**MEDIA_A, "file_id": "ignored"}}
    out = normalize_media_payloads(data, file_media_qs=fake_qs)
    assert out["file"]["id"] == MEDIA_A["id"]
    assert "file_id" not in out["file"]
    # No DB hit: real ids don't go through existence check.
    assert calls == []


def test_normalize_media_payloads_explicit_clears_skip_db():
    """Payloads with id='0' and no file_id never trigger a DB query."""
    calls: list[Any] = []

    def fake_qs(ids):
        calls.append(ids)
        return []

    data = {"thumbnail": {**DEFAULT_FILE_SCHEMA}}  # no file_id
    out = normalize_media_payloads(data, file_media_qs=fake_qs)
    assert out["thumbnail"]["id"] == "0"
    assert "file_id" not in out["thumbnail"]
    assert calls == []  # no candidates, no query
