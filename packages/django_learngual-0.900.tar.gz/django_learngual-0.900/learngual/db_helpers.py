from django.db import models
from django.db.models import PositiveIntegerField, Subquery


class TrashModelMixin:
    """Abstract mixin that adds trash/soft-delete fields to a model.

    Combine with TrashableItemInterface to get the full trash behaviour.
    """

    trashed_at = models.DateTimeField(null=True, blank=True, db_index=True)
    # True if this record was trashed because its parent was trashed
    trashed_by_parent = models.BooleanField(default=False)
    # Commented out: the Account model lives in different locations across services.
    # Add this FK in the concrete model or service that has the correct import path.
    # trashed_by = models.ForeignKey(
    #     "accounts.Account",
    #     null=True,
    #     blank=True,
    #     on_delete=models.SET_NULL,
    #     related_name="trashed_%(class)s",
    # )
    # trash = models.ForeignKey(
    #     "trash.Trash",
    #     null=True,
    #     blank=True,
    #     on_delete=models.SET_NULL,
    #     related_name="trashed_items",
    # )


class SubqueryCount(Subquery):
    """
    from django.db.models import OuterRef

    weapons = Weapon.objects.filter(unit__player_id=OuterRef('id'))
    units = Unit.objects.filter(player_id=OuterRef('id'))

    qs = Player.objects.annotate(weapon_count=SubqueryCount(weapons),
                                rarity_sum=SubquerySum(units, 'rarity'))
    """

    # Custom Count function to just perform simple count on any queryset without grouping.
    # https://stackoverflow.com/a/47371514/1164966
    template = "(SELECT count(*) FROM (%(subquery)s) _count)"
    output_field = PositiveIntegerField()


class SubqueryAggregate(Subquery):
    # https://code.djangoproject.com/ticket/10060
    template = '(SELECT %(function)s(_agg."%(column)s") FROM (%(subquery)s) _agg)'

    def __init__(self, queryset, column, output_field=None, **extra):
        if not output_field:
            # infer output_field from field type
            output_field = queryset.model._meta.get_field(column)
        super().__init__(
            queryset, output_field, column=column, function=self.function, **extra
        )


class SubquerySum(SubqueryAggregate):
    function = "SUM"
