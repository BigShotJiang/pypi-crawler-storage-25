"""Bulk resolver for the nested-file state map.

Given a list/page/queryset of carrier rows (Course, Account, Lecture, ...),
this module walks every column that might carry a nested ``MediaFileSchema``
object, collects the referenced FileMedia ids, fires ONE query against
FileMedia, and returns a ``dict[file_id -> fresh_state_or_None]`` that the
read-side mixin uses to rewrite the response.

The walker uses ``MediaHelper.extract_media_ids`` to find media objects by
signature at any depth — so ``Course.thumbnail`` (a flat MediaFileSchema dict),
``Lecture.body`` (polymorphic with media nested inside list items), and
``Question.data`` (discriminated union, audio in some variants) are all
handled uniformly without any per-model extractor code.

Design notes
------------
* The config is injected (per-service ``NestedFileStateConfig``) so the
  ``learngual`` package never imports any service's FileMedia model class.
* Account/enterprise objects are accepted as duck-typed primitives — the
  resolver extracts ``.type`` and ``.id`` once and forwards primitives to the
  presigner.  Deeper code has no Account-model dependency.
* ``rows`` accepts both a Django ``QuerySet`` (uses ``.values()`` — cheapest
  path; only the JSON columns are loaded) and an iterable of materialised
  rows (a paginated page of model instances).  Best practice: paginate
  first, then pass the page — never walk the unpaginated queryset.
* Exactly one DB query per call, regardless of page size.  When no candidate
  ids are found in the page, the query is skipped entirely.
"""
from __future__ import annotations

import logging
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from itertools import chain
from typing import Any

from .media_helper import extract_media_ids
from .presign import presign_media_url, presign_thumbnail_url

logger = logging.getLogger("learngual.nested_file_state")


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class NestedFileStateConfig:
    """Per-service injection container.

    Constructed once at app startup (typically as a module-level singleton)
    and passed into every call to :func:`fetch_nested_file_state`.

    The whole point of this dataclass is to keep the shared resolver
    service-agnostic — it knows how to walk nested JSON and merge fresh
    file state, but doesn't know which ``FileMedia`` model lives in this
    service or what its placeholder schema looks like.  Those bits — and
    optionally a custom presigner — are injected here.
    """

    file_media_qs: Callable[[Iterable[str]], Any]
    """Factory: given an iterable of file ids, returns a Django queryset
    (or any iterable of objects with the same attributes) of FileMedia
    rows.  The queryset MUST project at least these fields:

        id, upload, thumbnail, mimetype, convertion_status, duration,
        size, trashed_at

    Injected (not hard-coded to ``FileMedia.objects``) because each service
    has its own FileMedia model class and its own storage backend bindings.
    """

    default_schema: dict
    """The ``id: "0"`` placeholder dict for this service.  When a referenced
    FileMedia is trashed, the resolver returns ``None`` for that id; the
    read-side mixin then swaps the nested object for this placeholder
    (plus ``file_id`` to preserve the persistent reference)."""

    presign: Callable[..., str | None] = field(default=presign_media_url)
    """URL builder for the main file.  Defaults to the package's
    ``presign_media_url`` (image → direct S3, video/audio → stream
    endpoint).  Override only if a service has genuinely different signing
    semantics — most won't."""

    presign_thumb: Callable[..., str | None] = field(default=presign_thumbnail_url)
    """URL builder for the thumbnail.  Defaults to the package's
    ``presign_thumbnail_url`` (always direct S3)."""


# ---------------------------------------------------------------------------
# Resolver
# ---------------------------------------------------------------------------


def _as_dict(value: Any) -> dict[str, Any] | None:
    """Coerce a column value to a plain dict for MediaHelper.

    PydanticModelField attribute reads return Pydantic instances; JSONField
    and ``.values()`` return plain dicts.  We normalise to dict before
    handing off to the signature walker (which only knows dicts and lists).
    """
    if value is None:
        return None
    if isinstance(value, dict):
        return value
    if hasattr(value, "model_dump"):
        try:
            return value.model_dump()
        except Exception as exc:
            logger.warning(
                "nested_file_state._as_dict: model_dump failed (%s); skipping value",
                exc.__class__.__name__,
            )
            return None
    if isinstance(value, list):
        # Some carriers store a list of media objects directly (rare).
        # Wrap so MediaHelper can walk it.
        return {"__items__": value}
    return None


def fetch_nested_file_state(
    rows: Any,
    nested_file_fields: tuple[str, ...],
    *,
    config: NestedFileStateConfig,
    account: Any = None,
    enterprise: Any = None,
) -> dict[str, dict[str, Any] | None]:
    """Bulk resolver: given a list of carrier rows, return the state map.

    Walks every ``nested_file_fields`` column on every row via
    ``MediaHelper.extract_media_ids``, collects every non-zero file id,
    fires ONE FileMedia query, and returns the per-id state for the
    read-side mixin to consume.

    Best practice: pass a paginated page (list of model instances) so the
    walker only inspects rows that will actually render.  Passing the full
    queryset is supported (``QuerySet.values()`` path — cheap projection)
    but means walking every row.

    Args:
        rows: an iterable of carrier rows (model instances or dicts) OR a
            Django QuerySet.
        nested_file_fields: tuple of column names that *might* carry nested
            file objects (e.g. ``("thumbnail", "preview_video")`` for
            Course, ``("body",)`` for Lecture).  The actual walk inside
            each column is signature-based via MediaHelper.
        config: per-service ``NestedFileStateConfig`` singleton.
        account: viewer's account object (duck-typed: any object with
            ``.type``).  Used to extract ``account_type`` for stream URL
            routing.  ``None`` is fine for image-only carriers.
        enterprise: viewer's enterprise account (duck-typed: any object
            with ``.id``).  Used to extract ``enterprise_id`` for the
            INSTRUCTOR-under-ENTERPRISE stream route.

    Returns:
        ``dict[str, dict | None]`` keyed by file id:

        * value is ``None`` when ``FileMedia.trashed_at`` is set — the
          mixin will swap the nested object for ``config.default_schema``
          (plus ``file_id`` to preserve the reference).
        * value is a dict of fresh fields (``url``, ``thumbnail_url``,
          ``mimetype``, ``convertion_status``, ``duration``, ``size``) —
          the mixin will merge this over the stored JSON.

        Empty dict if no nested file ids are found (no DB hit in that case).
    """
    if not rows or not nested_file_fields:
        return {}

    # ----- Pass 1: collect every file id referenced anywhere in the page -----
    # Single generator pipeline drives both the QuerySet (.values()) path
    # and the materialised-iterable path: each yields per-column payloads,
    # extract_media_ids fans those out into ids, and chain.from_iterable
    # flattens into one set comprehension.

    try:
        from django.db.models import QuerySet

        is_queryset = isinstance(rows, QuerySet)
    except Exception:  # Django not importable — treat as list.
        is_queryset = False

    if is_queryset:
        # Cheapest path: load only the JSON columns we read.  .values()
        # returns plain dicts even for PydanticModelField (the underlying
        # storage is JSONB).
        row_iter: Iterable[Any] = rows.values(*nested_file_fields)

        def _field(row: Any, fname: str) -> Any:
            return row.get(fname)

    else:
        row_iter = rows

        def _field(row: Any, fname: str) -> Any:
            return (
                row.get(fname) if isinstance(row, dict) else getattr(row, fname, None)
            )

    payload_stream = (
        payload
        for row in row_iter
        for fname in nested_file_fields
        for payload in (_as_dict(_field(row, fname)),)
        if payload
    )
    ids: set[str] = set(
        chain.from_iterable(
            extract_media_ids(payload, include_file_id=True)
            for payload in payload_stream
        )
    )

    if not ids:
        return {}

    # ----- Pass 2: translate account/enterprise objects to primitives -----
    # Done once per request (not per row).  The presigner sees primitives
    # only and has no dependency on any service's Account model class.

    account_type = getattr(account, "type", None) if account else None
    enterprise_id = (
        getattr(enterprise, "id", None) or getattr(enterprise, "pk", None)
        if enterprise
        else None
    )

    # ----- Pass 3: single FileMedia query + build the state map -----

    state: dict[str, dict | None] = {}
    for media in config.file_media_qs(ids):
        pk = str(getattr(media, "pk", None) or getattr(media, "id", None) or "")
        if not pk:
            continue
        if getattr(media, "trashed_at", None) is not None:
            # Trashed → mixin will swap for default_schema.
            state[pk] = None
            continue
        state[pk] = {
            "url": config.presign(
                media, account_type=account_type, enterprise_id=enterprise_id
            ),
            "thumbnail_url": config.presign_thumb(media),
            "mimetype": getattr(media, "mimetype", None),
            "convertion_status": getattr(media, "convertion_status", None),
            "duration": getattr(media, "duration", None),
            "size": getattr(media, "size", None),
        }

    return state
