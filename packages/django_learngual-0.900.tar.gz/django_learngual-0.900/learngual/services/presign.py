"""Canonical media URL builder for the learngual ecosystem.

One implementation shared by every service that exposes a FileMedia URL to a
client.  Today three services duplicate this work
(iam-service ``media_service_file_url``, elearning-service ``presign_media_url``,
media-service ``build_media_url_v2``); this module is their replacement.

Routing
-------
The URL returned depends on the file's mimetype:

* **video / audio** → media-service stream-endpoint URL, account-scoped by
  ``account_type`` (PERSONAL / ENTERPRISE / INSTRUCTOR).  When the client
  follows the URL, media-service decides at request time whether to redirect
  to the HLS playlist (``/index.m3u8``, when ``convertion_status == DONE`` and
  ``delivery_mode in {"hls", None}``) or to a presigned raw upload (still
  converting, or progressive delivery).  We do **not** need to know
  ``convertion_status`` here — the stream endpoint owns that decision.
* **image / document / other** → direct presigned S3 URL to the raw upload.
* **thumbnail** → always direct presigned S3 (thumbnails are still images
  regardless of the parent's media type).

Settings consumed
-----------------
Standard ``AWS_*`` settings (already configured in every service):

* ``AWS_STORAGE_BUCKET_NAME`` — S3 bucket name.
* ``AWS_S3_ENDPOINT_URL`` — set for MinIO/local; omit for AWS S3.
* ``AWS_ACCESS_KEY_ID`` / ``AWS_SECRET_ACCESS_KEY`` — boto3 credentials.
* ``AWS_S3_REGION_NAME`` — AWS region.
* ``AWS_S3_DOMAIN`` — CDN / CloudFront domain.  When set, the package emits
  unsigned ``https://{domain}/{bucket}/{prefix}/{key}`` URLs.  Services that
  need signed CloudFront URLs should keep using their existing storage class
  override (the package emits the same shape as the existing fallback in
  ``media_service_file_url`` did).
* ``PRESIGNED_STREAM_EXPIRES_IN`` — presigned URL TTL in seconds.  Defaults
  to 3600.

The single new setting introduced by this work:

* ``MEDIA_SERVICE_S3_PREFIX`` — the folder where media-service stores its
  FileMedia uploads.  Default: ``"media/media"``.  Consumers always sign on
  behalf of media-service, so this prefix is media-service's namespace —
  not the consumer's own folder (which is irrelevant here).
"""
from __future__ import annotations

import logging
import os
from enum import Enum
from typing import Any

import boto3
import botocore.config
from django.conf import settings
from django.utils.encoding import filepath_to_uri

logger = logging.getLogger("learngual.presign")


def _get_base_url(service: str) -> str:
    """Lazy proxy to ``learngual.utils.get_base_url``.

    Deferred so importing this module doesn't transitively pull
    ``learngual.utils`` (which imports DRF filters that require Django
    settings to be configured at class-definition time).
    """
    from ..utils import get_base_url as _gbu

    return _gbu(service)


# Default video file extensions, kept in lockstep with media-service's
# MediaHelper.infer_media_type so the shared package recognises the same
# files as the bundled stream endpoint.
_VIDEO_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".mp4",
        ".mov",
        ".avi",
        ".mkv",
        ".webm",
        ".m4v",
        ".flv",
        ".wmv",
        ".mpeg",
        ".mpg",
        ".3gp",
        "mp4",
        "mov",
        "avi",
        "mkv",
        "webm",
        "m4v",
        "flv",
        "wmv",
        "mpeg",
        "mpg",
        "3gp",
    }
)
_AUDIO_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".mp3",
        ".wav",
        ".m4a",
        ".aac",
        ".ogg",
        ".flac",
        ".wma",
        ".opus",
        "mp3",
        "wav",
        "m4a",
        "aac",
        "ogg",
        "flac",
        "wma",
        "opus",
    }
)


class AccountType(str, Enum):
    """Viewer roles recognised by media-service's stream endpoint.

    Each value maps to a different stream URL path template.  The shared
    presigner accepts this enum (or its raw string) instead of a full
    Account object, so the package has no dependency on any service's
    Account model class — pure DI primitives only.
    """

    PERSONAL = "PERSONAL"
    ENTERPRISE = "ENTERPRISE"
    INSTRUCTOR = "INSTRUCTOR"


# Stream URL path templates relative to media-service's base host.  The
# media-service URL conf registers v1 and v2 with identical shapes; both
# resolve the same view handlers.  Default stream version is v2 (newer
# code path used by ``build_media_url_v2``).
_DEFAULT_STREAM_VERSION = "v2"

_STREAM_PATH_TEMPLATES: dict[str, str] = {
    "PERSONAL": "/media/{version}/files/{pk}/stream/",
    "ENTERPRISE": "/media/{version}/enterprise/files/{pk}/stream/",
    "INSTRUCTOR": "/media/{version}/instructor/files/{pk}/stream/",
    "INSTRUCTOR_WITH_ENTERPRISE": (
        "/media/{version}/instructor/{enterprise_id}/files/{pk}/stream/"
    ),
}


# ---------------------------------------------------------------------------
# Public: mimetype inference (shared with media-service's MediaHelper)
# ---------------------------------------------------------------------------


def infer_media_type(mimetype: str | None, filename: str | None) -> str | None:
    """Return ``"video"``, ``"audio"``, or ``None`` based on mimetype/filename.

    Mirrors ``core.utils.media.MediaHelper.infer_media_type`` in media-service.
    Mimetype is checked first (prefix match); falls back to file extension.
    Returns ``None`` for images, documents, and anything not video/audio —
    the caller treats that as "presign S3 directly".
    """
    if mimetype:
        category = str(mimetype).split("/")[0].lower()
        if category in {"video", "audio"}:
            return category
    if not filename:
        return None
    ext = os.path.splitext(str(filename))[1].lower()
    ext_no_dot = ext.lstrip(".")
    if ext in _VIDEO_EXTENSIONS or ext_no_dot in _VIDEO_EXTENSIONS:
        return "video"
    if ext in _AUDIO_EXTENSIONS or ext_no_dot in _AUDIO_EXTENSIONS:
        return "audio"
    return None


# ---------------------------------------------------------------------------
# Internal: stream URL builder (account-scoped path templates)
# ---------------------------------------------------------------------------


def _build_stream_url(
    file_media: Any,
    account_type: AccountType | str | None,
    enterprise_id: str | None,
) -> str | None:
    """Return the media-service stream-endpoint URL for a FileMedia.

    Folds ``build_stream_path_v2`` from media-service, but takes primitives
    instead of Account objects (the shared package never imports any
    service's Account model class).

    Path templates are constants in this module because they are the
    media-service contract — both v1 and v2 URL configs register the same
    paths.  When ``account_type`` is ``None`` (or unknown), we fall back to
    the PERSONAL template so an image-context caller that accidentally hits
    the video branch never returns ``None`` silently.
    """
    pk = getattr(file_media, "id", None) or getattr(file_media, "pk", None)
    if not pk:
        return None

    version = getattr(settings, "MEDIA_SERVICE_STREAM_VERSION", _DEFAULT_STREAM_VERSION)

    at = (
        account_type.value
        if isinstance(account_type, AccountType)
        else (str(account_type).upper() if account_type else "PERSONAL")
    )

    if at == "INSTRUCTOR" and enterprise_id:
        template = _STREAM_PATH_TEMPLATES["INSTRUCTOR_WITH_ENTERPRISE"]
        path = template.format(version=version, enterprise_id=enterprise_id, pk=pk)
    elif at in _STREAM_PATH_TEMPLATES:
        template = _STREAM_PATH_TEMPLATES[at]
        path = template.format(version=version, pk=pk)
    else:
        # Unknown role → fall back to PERSONAL.  Logged so misconfigured
        # callers are visible.
        logger.warning(
            "_build_stream_url: unknown account_type %r; falling back to PERSONAL",
            at,
        )
        path = _STREAM_PATH_TEMPLATES["PERSONAL"].format(version=version, pk=pk)

    try:
        host = _get_base_url("media").rstrip("/")
    except Exception:
        logger.exception("_build_stream_url: get_base_url('media') failed")
        return path  # relative-path fallback (still routable in single-domain envs)
    return f"{host}{path}"


# ---------------------------------------------------------------------------
# Internal: S3 presigning (CloudFront-compatible CDN URL or MinIO presign)
# ---------------------------------------------------------------------------


def _presign_s3(field: Any) -> str | None:
    """Return a client-facing URL for the raw S3-stored file.

    Branches:
      * ``AWS_S3_DOMAIN`` set → emit ``https://{domain}/{bucket}/{prefix}/{key}``.
        Unsigned CDN URL — services that need CloudFront-signed URLs should
        override the presigner via ``NestedFileStateConfig.presign``.
      * Else → boto3 ``generate_presigned_url("get_object")`` against the
        configured ``AWS_S3_ENDPOINT_URL`` (works for both AWS S3 and MinIO).
      * Last resort: fall back to the field's ``.url`` attribute (django-storages
        default).  Covers misconfigured environments and tests.

    Always signs on behalf of media-service: the object key is prefixed with
    ``MEDIA_SERVICE_S3_PREFIX`` (default ``"media/media"``), regardless of
    the calling service's own bucket layout.
    """
    if not field or not getattr(field, "name", None):
        return None

    name = field.name
    prefix = getattr(settings, "MEDIA_SERVICE_S3_PREFIX", "media/media").strip("/")
    object_key = f"{prefix}/{name.lstrip('/')}"

    bucket = getattr(settings, "AWS_STORAGE_BUCKET_NAME", None) or os.getenv(
        "AWS_STORAGE_BUCKET_NAME", "learngual-bucket"
    )
    cdn_domain = getattr(settings, "AWS_S3_DOMAIN", None)

    # Production / staging: unsigned CDN URL via configured AWS_S3_DOMAIN.
    if cdn_domain:
        try:
            path = filepath_to_uri(f"{bucket}/{object_key}")
            return f"https://{cdn_domain}/{path}"
        except Exception:
            logger.exception(
                "_presign_s3: failed to build CDN URL for key=%s", object_key
            )
            # Fall through to boto3 / .url fallback.

    # Dev / local: boto3 presigning against MinIO (or AWS S3 without a CDN).
    endpoint_url = getattr(settings, "AWS_S3_ENDPOINT_URL", None) or os.getenv(
        "AWS_S3_ENDPOINT_URL", "http://0.0.0.0:9000"
    )
    access_key = getattr(settings, "AWS_ACCESS_KEY_ID", None) or os.getenv(
        "AWS_ACCESS_KEY", "minioadmin"
    )
    secret_key = getattr(settings, "AWS_SECRET_ACCESS_KEY", None) or os.getenv(
        "AWS_SECRET_ACCESS_KEY", "minioadmin"
    )
    expire_in = getattr(settings, "PRESIGNED_STREAM_EXPIRES_IN", None) or 3600

    if endpoint_url and access_key and secret_key and bucket:
        try:
            client = boto3.client(
                "s3",
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                endpoint_url=endpoint_url,
                config=botocore.config.Config(
                    signature_version="s3",
                    s3={"addressing_style": "path"},
                ),
            )
            return client.generate_presigned_url(
                "get_object",
                Params={"Bucket": bucket, "Key": object_key},
                ExpiresIn=expire_in,
            )
        except Exception:
            logger.exception(
                "_presign_s3: boto3 presign failed for key=%s; falling back to field.url",
                object_key,
            )

    # Last-resort fallback.
    try:
        return field.url
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Public: the canonical entry points
# ---------------------------------------------------------------------------


def presign_media_url(
    file_media: Any,
    *,
    account_type: AccountType | str | None = None,
    enterprise_id: str | None = None,
    request: Any = None,
) -> str | None:
    """Build the client-facing URL for a FileMedia.

    Single canonical function — every consumer (media-service Retrieve,
    iam-service profile photo, elearning course thumbnail, ...) calls into
    this.  Reads Django settings; no service passes a callable.

    Branches by mimetype:

    * **video / audio** → returns the media-service stream-endpoint URL
      (routed by ``account_type``, and ``enterprise_id`` when an INSTRUCTOR
      is operating under an ENTERPRISE).  Convertion status / delivery mode
      are NOT consulted here — the stream endpoint decides at redirect time.
    * **image / document / other** → direct presigned S3 URL to the raw
      upload (CloudFront / boto3 fallback depending on settings).

    Args:
        file_media: a FileMedia (or duck-type) with ``upload``, ``mimetype``,
            and ``id``.
        account_type: viewer's role.  Required for video/audio routing.
            Falls back to PERSONAL when ``None``.
        enterprise_id: required when ``account_type == INSTRUCTOR`` AND the
            instructor is operating inside an enterprise.  Ignored otherwise.
        request: kept for API compatibility with the legacy iam-service
            helper; not currently used.

    Returns:
        URL string, or ``None`` if the FileMedia has no upload / no mimetype.
    """
    if not file_media:
        return None
    upload = getattr(file_media, "upload", None)
    mimetype = getattr(file_media, "mimetype", None)
    if not upload or not mimetype:
        return None

    filetype = infer_media_type(mimetype, getattr(upload, "name", None))
    if filetype in {"video", "audio"}:
        return _build_stream_url(file_media, account_type, enterprise_id)
    return _presign_s3(upload)


def presign_thumbnail_url(file_media: Any, *, request: Any = None) -> str | None:
    """Build the client-facing URL for a FileMedia's thumbnail.

    Thumbnails are still images regardless of the parent media type, so there
    is no streaming branch — always a direct presigned S3 URL.  Returns
    ``None`` if the FileMedia has no thumbnail set.
    """
    if not file_media:
        return None
    thumbnail = getattr(file_media, "thumbnail", None)
    if not thumbnail or not getattr(thumbnail, "name", None):
        return None
    return _presign_s3(thumbnail)
