# 凭证管理 (Voucher)

## 概述

记账凭证是会计核算的基础单据。本模块支持：
- Agent 审核流水并指定科目生成凭证（`suggest` + `assign`）
- 智能科目建议（按关键词匹配，输出置信度供 Agent 判断）
- 从发票创建凭证
- 手工创建凭证
- 批量过账（审核）

## 命令

### 查看凭证列表

```bash
ft voucher list [选项]
```

**选项：**
- `--period YYYY-MM` — 按期间筛选
- `--status draft|posted|void` — 按状态筛选

### 过账单张凭证

```bash
ft voucher post <凭证ID>
```

### 批量过账

```bash
ft voucher post-all --period YYYY-MM
```

将指定期间的所有草稿凭证批量过账。只有已过账的凭证才会计入报表。

### 科目建议（Agent 审核辅助）

```bash
ft voucher suggest <流水ID>
```

为指定银行流水推荐会计科目，输出 JSON 格式的建议列表（含置信度和匹配原因）。供 Agent 参考决策，无匹配时返回空列表。

**输出示例：**
```json
{
  "transaction_id": 1,
  "date": "2025-01-05",
  "debit": 0.0,
  "credit": 50000.0,
  "summary": "收到货款-销售",
  "counterparty": "ABC公司",
  "is_processed": false,
  "suggestions": [
    {
      "debit_account_code": "1002",
      "debit_account_name": "银行存款",
      "credit_account_code": "5001",
      "credit_account_name": "主营业务收入",
      "confidence": 0.5,
      "reason": "关键词匹配: 货款"
    }
  ]
}
```

### 手动指定科目生成凭证（Agent 审核用）

```bash
ft voucher assign <流水ID> --debit <科目> --credit <科目> [选项]
```

**参数：**
- `<流水ID>` — 银行流水 ID（通过 `bank list --json-output` 获取）
- `--debit` — 借方科目（支持科目**名称**或**编码**，如 `"银行存款"` 或 `"1002"`）
- `--credit` — 贷方科目（同上）
- `--description` — 凭证摘要（默认使用流水摘要）
- `--post` — 生成后自动过账
- `--json-output` — JSON 格式输出

**使用示例：**
```bash
# Agent 判断为归还借款
ft voucher assign 1 --debit "其他应付款" --credit "银行存款" --description "归还私人借款" --post --json-output

# 用科目编码指定
ft voucher assign 2 --debit 1002 --credit 5301 --post --json-output
```

### 手工创建凭证（不关联银行流水）

用于计提工资、计提折旧、结转损益等非银行流水触发的凭证。

**简单模式（一借一贷）：**
```bash
uv run ft voucher create --date 2025-01-31 \
  --debit "管理费用/工资" --credit "应付职工薪酬/工资" \
  --amount 15000 --description "计提1月工资" --post --json-output
```

**多分录模式（多借多贷）：**
```bash
uv run ft voucher create --date 2025-01-31 --description "计提1月工资及社保" --entries '[
  {"account": "管理费用/工资", "debit": 15000, "credit": 0, "summary": "计提工资"},
  {"account": "管理费用/社保公积金", "debit": 4200, "credit": 0, "summary": "计提社保"},
  {"account": "应付职工薪酬/工资", "debit": 0, "credit": 15000, "summary": "计提工资"},
  {"account": "应付职工薪酬/社会保险费", "debit": 0, "credit": 4200, "summary": "计提社保"}
]' --post --json-output
```

**参数：**
- `--date` — 凭证日期 YYYY-MM-DD
- `--debit` / `--credit` / `--amount` — 简单模式（一借一贷）
- `--entries` — 多分录模式，JSON 数组（每项含 account/debit/credit/summary）
- `--description` — 凭证摘要
- `--post` — 生成后自动过账
- `--json-output` — JSON 格式输出

**科目指定方式（三种均可）：**
- 科目编码: `"560210"`
- 科目名称: `"工资"`（有歧义时取第一个匹配）
- 科目全名: `"管理费用/工资"`（推荐，无歧义）

#### 常见工资凭证示例

**计提工资（月末）：**
```
借: 管理费用/工资        15,000    ← 公司工资成本
借: 管理费用/社保公积金   4,200    ← 公司承担社保
贷: 应付职工薪酬/工资    15,000    ← 欠员工的工资
贷: 应付职工薪酬/社会保险费 4,200   ← 欠社保机构的
```

**发放工资（银行转账，用 voucher assign 处理流水）：**
```
借: 应付职工薪酬/工资    15,000
贷: 银行存款            15,000
```

### Agent 审核工作流

推荐的 Agent 处理银行流水的标准流程：

```
1. ft bank list --unprocessed --json-output     → 获取待处理流水
2. ft voucher suggest <id>                       → 获取科目建议
3. Agent 判断 / 询问用户确认科目
4. ft voucher assign <id> --debit X --credit Y   → 生成凭证
5. ft voucher post-all --period YYYY-MM          → 批量过账
```

月末额外操作：
```
6. ft voucher create --date YYYY-MM-DD --entries '...'  → 计提工资/折旧等
7. ft voucher post-all --period YYYY-MM                 → 再次过账
```

## 智能科目匹配规则

系统根据银行流水摘要中的关键词自动匹配科目：

### 收入类
| 关键词 | 匹配科目 |
|-------|---------|
| 销售、货款、服务费收入 | 主营业务收入 |
| 利息收入、结息 | 财务费用-利息收入 |

### 费用类（管理费用）
| 关键词 | 匹配科目 |
|-------|---------|
| 房租、租金、租赁 | 管理费用-租赁费 |
| 办公用品、办公费 | 管理费用-办公费 |
| 差旅、出差、住宿 | 管理费用-差旅费 |
| 餐费、招待 | 管理费用-业务招待费 |
| 水电、电费 | 管理费用-水电费 |
| 电话、通讯 | 管理费用-通讯费 |
| 打车、加油、交通 | 管理费用-交通费 |
| 咨询、顾问、服务费 | 管理费用-咨询服务费 |
| 工资、薪酬 | 管理费用-工资 |
| 社保、公积金 | 管理费用-社保公积金 |

### 财务费用
| 关键词 | 匹配科目 |
|-------|---------|
| 手续费、转账手续费 | 财务费用-手续费 |

### 销售费用
| 关键词 | 匹配科目 |
|-------|---------|
| 快递、物流、运费 | 销售费用-运输费 |
| 广告、推广 | 销售费用-广告宣传费 |

### 税费类
| 关键词 | 匹配科目 |
|-------|---------|
| 税款、缴税、增值税 | 应交税费 |

Agent 可通过 `voucher suggest` 获取匹配建议。无匹配时需询问用户确认科目，再通过 `voucher assign` 生成凭证。

## 凭证状态流转

```
draft(草稿) → posted(已过账) → void(已作废)
```

- **草稿**：可修改，不计入报表
- **已过账**：计入报表，不可修改（需先反过账）
- **已作废**：不计入报表，保留记录

## 复式记账规则

每张凭证必须满足**借贷平衡**：借方合计 = 贷方合计

### 银行收入凭证示例
```
借: 银行存款          10,000.00
  贷: 主营业务收入              10,000.00
```

### 银行支出凭证示例
```
借: 管理费用-租赁费    5,000.00
  贷: 银行存款                   5,000.00
```

### 发票入账凭证示例（进项）
```
借: 管理费用-咨询服务费  9,433.96
借: 应交税费-应交增值税    566.04
  贷: 应付账款                  10,000.00
```
