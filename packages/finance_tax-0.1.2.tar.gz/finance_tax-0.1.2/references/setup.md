# 初始化配置 (Setup)

## 概述

首次使用 finance-tax 技能包时，通过命令行参数完成以下配置：
- 公司基本信息（名称、税号）
- 纳税人类型（小规模纳税人 / 一般纳税人）
- 会计准则（小企业会计准则 / 企业会计准则）
- 所属行业
- 启用年度

初始化完成后，系统会自动：
1. 创建本地 SQLite 数据库
2. 导入对应会计准则的标准科目表
3. 初始化当年 12 个会计期间

## 命令

```bash
ft init --name "公司名称" [选项]
```

**参数：**
- `--name TEXT` — 公司名称（**必填**）
- `--tax-id TEXT` — 统一社会信用代码/税号（默认: 空）
- `--taxpayer-type [small_scale|general]` — 纳税人类型（默认: `small_scale`）
- `--standard [small_enterprise|enterprise]` — 会计准则（默认: `small_enterprise`）
- `--industry TEXT` — 所属行业（默认: `信息技术服务`）
- `--year INT` — 启用年度（默认: 当前年份）
- `--json-output` — JSON 格式输出

**示例：**
```bash
# 最简初始化（小规模 + 小企业准则）
ft init --name "XX科技有限公司"

# 完整参数
ft init --name "XX科技有限公司" --tax-id 91110000XXXXXXXX --taxpayer-type small_scale --standard small_enterprise --industry "信息技术服务" --year 2025

# 一般纳税人 + 企业准则
ft init --name "大型公司" --taxpayer-type general --standard enterprise

# JSON 输出（适合程序解析）
ft init --name "测试公司" --json-output
```

## 查看当前状态

```bash
ft status
```

显示当前账套的公司信息、凭证数量、未处理流水数等概览信息。

## 数据存储

- 默认数据目录：`~/.finance-tax/`
- 数据库文件：`~/.finance-tax/finance_tax.db`
- 配置文件：`~/.finance-tax/config.json`
- 可通过 `--data-dir` 参数指定自定义数据目录

## 配置说明

### 纳税人类型差异

| 项目 | 小规模纳税人 | 一般纳税人 |
|------|-------------|-----------|
| 增值税税率 | 3%（减按1%） | 6%/9%/13% |
| 进项抵扣 | 不可抵扣 | 可抵扣 |
| 季度免征额 | 30万以下免征 | 无 |
| 印花税 | 减半征收 | 全额 |
| 附加税 | 减半征收 | 全额 |

### 会计准则差异

| 项目 | 小企业会计准则 | 企业会计准则 |
|------|--------------|-------------|
| 科目编码 | 权益3xxx, 收入5xxx | 权益4xxx, 收入6xxx |
| 资产减值 | 不计提 | 需计提 |
| 递延所得税 | 不核算 | 需核算 |
| 适用范围 | 小微企业 | 一般企业 |
