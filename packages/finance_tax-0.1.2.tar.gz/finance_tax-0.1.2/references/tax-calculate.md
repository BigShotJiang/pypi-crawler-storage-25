# 税务计算与申报 (Tax)

## 概述

支持中国税务合规的税费自动计算，覆盖中小微企业常见税种：
- **增值税** — 小规模/一般纳税人，含免征判断
- **企业所得税** — 季度预缴，小微企业优惠
- **印花税** — 按合同类型计税，小规模减半
- **附加税** — 城建税、教育费附加、地方教育费附加

## 命令

### 增值税

```bash
ft tax vat --period-start YYYY-MM --period-end YYYY-MM [选项]
```

**选项：**
- `--frequency monthly|quarterly` — 申报频率（默认: quarterly）
- `--save` — 保存申报记录
- `--json-output` — JSON 格式输出

**小规模纳税人规则：**
- 税率：3%（疫情期间减按1%）
- 季度销售额 ≤ 30万元：免征增值税
- 月度销售额 ≤ 10万元：免征增值税

**一般纳税人规则（预留）：**
- 按行业适用 6%/9%/13% 税率
- 应纳税额 = 销项税额 - 进项税额

**示例：**
```bash
# 计算2025年Q1增值税
ft tax vat --period-start 2025-01 --period-end 2025-03 --save
```

### 企业所得税

```bash
ft tax income --year YYYY --quarter N [选项]
```

**选项：**
- `--save` — 保存申报记录
- `--json-output` — JSON 格式输出

**计算逻辑：**
1. 取年初至本季度末的累计利润总额
2. 判断是否适用小微企业优惠（应纳税所得额 ≤ 300万）
3. 小微企业实际税率 5%，标准税率 25%
4. 本季应补缴 = 累计应纳税额 - 已预缴税额

**小微企业认定标准：**
- 年应纳税所得额 ≤ 300万元
- 从业人员 ≤ 300人
- 资产总额 ≤ 5000万元

**示例：**
```bash
# 计算2025年Q1企业所得税
ft tax income --year 2025 --quarter 1 --save
```

### 印花税

```bash
ft tax stamp --period YYYY-MM --type <合同类型> --amount <合同金额> [选项]
```

**选项：**
- `--save` — 保存申报记录
- `--json-output` — JSON 格式输出

**合同类型及税率（万分比）：**

| 类型 key | 说明 | 税率(‱) |
|---------|------|---------|
| `purchase_sale_contract` | 买卖合同 | 3 |
| `loan_contract` | 借款合同 | 0.5 |
| `lease_contract` | 租赁合同 | 10 |
| `processing_contract` | 承揽合同 | 5 |
| `construction_contract` | 建设工程合同 | 3 |
| `transport_contract` | 运输合同 | 3 |
| `technology_contract` | 技术合同 | 3 |
| `storage_contract` | 仓储保管合同 | 10 |
| `property_insurance` | 财产保险合同 | 10 |
| `business_books_capital` | 营业账簿(资金) | 2.5 |
| `property_transfer` | 产权转移书据 | 5 |

**小规模纳税人减半征收。**

**示例：**
```bash
# 计算一份10万元买卖合同的印花税
ft tax stamp --period 2025-03 --type purchase_sale_contract --amount 100000
```

### 附加税

```bash
ft tax surcharge --period YYYY-MM --vat-paid <实缴增值税额> [选项]
```

**选项：**
- `--location city|county|other` — 企业所在地（影响城建税率，默认: city）
- `--save` — 保存申报记录
- `--json-output` — JSON 格式输出

**税率：**
| 税种 | 市区 | 县城 | 其他 |
|------|------|------|------|
| 城建税 | 7% | 5% | 1% |
| 教育费附加 | 3% | 3% | 3% |
| 地方教育费附加 | 2% | 2% | 2% |

以实际缴纳的增值税为计税基础。小规模纳税人减半征收。

**示例：**
```bash
# 增值税缴纳5000元，计算附加税
ft tax surcharge --period 2025-03 --vat-paid 5000 --location city --save
```

## 季度报税流程

每季度（1月/4月/7月/10月）15日前完成上季度申报：

```bash
# 1. 确保凭证已过账
ft voucher post-all --period 2025-01
ft voucher post-all --period 2025-02
ft voucher post-all --period 2025-03

# 2. 计算增值税
ft tax vat --period-start 2025-01 --period-end 2025-03 --save

# 3. 计算企业所得税
ft tax income --year 2025 --quarter 1 --save

# 4. 如有印花税应税合同
ft tax stamp --period 2025-03 --type purchase_sale_contract --amount 500000 --save

# 5. 根据增值税结果计算附加税
ft tax surcharge --period 2025-03 --vat-paid <增值税额> --save

# 6. 生成报表（用于核对和备案）
ft report balance-sheet --period 2025-03
ft report income --period 2025-03 --start 2025-01
```
