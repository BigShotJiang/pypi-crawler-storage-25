# 科目与期间管理 (Account & Period)

## 会计科目管理

### 查看科目列表

```bash
ft account list [选项]
```

**选项：**
- `--category TEXT` — 按分类筛选: `asset`(资产) / `liability`(负债) / `equity`(权益) / `revenue`(收入) / `cost`(成本) / `expense`(费用)
- `--keyword TEXT` — 按编码或名称搜索
- `--level INT` — 按层级筛选（1=一级科目）
- `--json-output` — JSON 格式输出

**示例：**
```bash
# 查看所有一级科目
ft account list --level 1

# 搜索费用类科目
ft account list --category expense

# 搜索包含"银行"的科目
ft account list --keyword 银行
```

### 科目体系说明

系统内置两套标准科目表：

**小企业会计准则：**
- 资产类: 1xxx（1001库存现金, 1002银行存款...）
- 负债类: 2xxx（2001短期借款, 2202应付账款...）
- 权益类: 3xxx（3001实收资本, 3101盈余公积...）
- 收入类: 5001-5xxx
- 成本类: 5401-5xxx
- 费用类: 5601-5xxx

**企业会计准则：**
- 资产类: 1xxx
- 负债类: 2xxx
- 权益类: 4xxx（4001实收资本, 4101盈余公积...）
- 收入类: 6001-6xxx
- 成本类: 6401-6xxx
- 费用类: 6601-6xxx

## 会计期间管理

### 查看会计期间

```bash
ft period list [选项]
```

**选项：**
- `--year INT` — 按年度筛选

### 初始化年度期间

```bash
ft period init-year <年度>
```

为指定年度创建 12 个会计期间（1月~12月）。

### 结账

```bash
ft period close <YYYY-MM>
```

关闭指定期间，关闭后该期间不可再录入凭证。

**示例：**
```bash
# 查看2025年所有期间
ft period list --year 2025

# 初始化2026年期间
ft period init-year 2026

# 结账2025年1月
ft period close 2025-01
```

## 月末/季末工作流

```bash
# 1. 确认流水和发票都已导入
ft bank list --unprocessed
ft invoice list --unprocessed

# 2. 生成凭证
ft voucher generate

# 3. 核对凭证
ft voucher list --period 2025-01 --status draft

# 4. 批量过账
ft voucher post-all --period 2025-01

# 5. 查看科目余额表核对
ft report trial-balance --period 2025-01

# 6. 结账
ft period close 2025-01
```
