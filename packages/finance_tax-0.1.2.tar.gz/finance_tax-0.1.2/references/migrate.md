# 迁移记账 (Migrate)

## 概述

当用户从其他记账系统（如"自记账"App、代账公司、金蝶、用友等）切换到本技能包时，需要导入**期初余额**以保证账务连续性。

本模块**不绑定任何特定平台的导出格式**。Agent 负责解析用户提供的任意格式数据（Excel、CSV、截图等），然后通过结构化命令写入期初余额。

## Agent 引导流程

> **重要**：以下流程说明是写给 Agent 的，请按此流程引导用户完成迁移。

### 第一步：判断记账类型

首次使用时，向用户询问：

```
请问您是首次记账还是从其他系统迁移？
1. 首次记账 — 公司刚成立或之前没有正式记账
2. 迁移记账 — 之前使用过自记账、代账公司、金蝶、用友等系统
```

- 如果是**首次记账**，直接执行 `ft init` 即可，无需迁移。
- 如果是**迁移记账**，继续以下步骤。

### 第二步：初始化账套

```bash
ft init --name "公司名称" --tax-id "税号" --taxpayer-type small_scale
```

### 第三步：引导用户提供期初余额数据

向用户说明：

```
请从您之前使用的记账系统中导出【科目余额表】（或叫试算平衡表）。
导出的格式不限（Excel、CSV、截图均可），我会帮您解析。

需要包含以下信息：
- 科目名称（如：银行存款、应收账款、实收资本等）
- 期末余额
- 余额方向（借方/贷方）

如果是年中迁移（比如从7月开始），最好还有：
- 本年累计借方发生额
- 本年累计贷方发生额
```

### 第四步：Agent 解析用户数据

Agent 拿到用户提供的数据后，自行解析（或借助其他 skill 解析 Excel），提取出每个科目的：
- 科目名称
- 余额金额
- 余额方向（debit/credit）

**科目名称映射**：使用 `ft account list --json-output` 获取本系统的科目表，将用户数据中的科目名称映射到系统科目。如有无法映射的科目，询问用户确认。

### 第五步：写入期初余额

**方式一：逐条写入**（适合少量科目或需要逐条确认）

```bash
ft migrate set-balance --account "银行存款" --balance 150000 --direction debit --period 2025-06 --json-output
ft migrate set-balance --account "应收账款" --balance 30000 --direction debit --period 2025-06 --json-output
ft migrate set-balance --account "应付账款" --balance 50000 --direction credit --period 2025-06 --json-output
ft migrate set-balance --account "实收资本" --balance 100000 --direction credit --period 2025-06 --json-output
```

**方式二：批量写入**（推荐，Agent 整理好 JSON 后一次性导入）

```bash
ft migrate import-balance --period 2025-06 --json-output --json-data '[
  {"account": "银行存款", "balance": 150000, "direction": "debit"},
  {"account": "应收账款", "balance": 30000, "direction": "debit"},
  {"account": "固定资产", "balance": 200000, "direction": "debit"},
  {"account": "应付账款", "balance": 50000, "direction": "credit"},
  {"account": "应交税费", "balance": 12000, "direction": "credit"},
  {"account": "实收资本", "balance": 300000, "direction": "credit"},
  {"account": "未分配利润", "balance": 18000, "direction": "credit"}
]'
```

### 第六步：验证借贷平衡

```bash
ft migrate verify --period 2025-06 --json-output
```

**输出示例：**
```json
{
  "period": "2025-06",
  "total_debit": 380000.0,
  "total_credit": 380000.0,
  "difference": 0.0,
  "is_balanced": true,
  "account_count": 7,
  "accounts": [...]
}
```

- `is_balanced: true` → 迁移成功，可以开始正常记账
- `is_balanced: false` → 显示差额，询问用户核对并修正

### 第七步：开始正常记账

迁移完成后，正常流程：

```bash
ft bank import 银行流水.xlsx
ft bank list --unprocessed --json-output
ft voucher suggest <流水ID>
ft voucher assign <流水ID> --debit <科目> --credit <科目> --post
```

## 命令参考

### set-balance — 设置单个科目期初余额

```bash
ft migrate set-balance [选项]
```

**选项：**
- `--account` — 科目（名称或编码，如 `"银行存款"` 或 `"1002"`）
- `--balance` — 期初余额（正数）
- `--direction debit|credit` — 余额方向
- `--period YYYY-MM` — 期初期间
- `--ytd-debit` — 本年累计借方（年中迁移用，默认 0）
- `--ytd-credit` — 本年累计贷方（年中迁移用，默认 0）
- `--json-output` — JSON 格式输出

### import-balance — 批量导入期初余额

```bash
ft migrate import-balance --json-data '<JSON数组>' --period YYYY-MM [--json-output]
```

**JSON 数组格式：**
```json
[
  {
    "account": "科目名称或编码",
    "balance": 金额,
    "direction": "debit 或 credit",
    "ytd_debit": 本年累计借方(可选),
    "ytd_credit": 本年累计贷方(可选)
  }
]
```

### verify — 验证期初余额借贷平衡

```bash
ft migrate verify --period YYYY-MM [--json-output]
```

返回借方合计、贷方合计、差额、是否平衡，以及各科目明细。

## 会计原理

期初余额必须满足**会计等式**：

```
资产 = 负债 + 所有者权益
```

即：所有**借方余额**科目合计 = 所有**贷方余额**科目合计

常见科目余额方向：
| 类别 | 余额方向 | 常见科目 |
|------|---------|---------|
| 资产 | 借方(debit) | 银行存款、应收账款、固定资产、库存现金 |
| 负债 | 贷方(credit) | 应付账款、应交税费、短期借款 |
| 权益 | 贷方(credit) | 实收资本、资本公积、未分配利润 |

## 年中迁移注意事项

如果在年度中间迁移（如 7 月），损益类科目（收入/费用）的余额已结转到"未分配利润"中，但报表可能需要**本年累计发生额**才能正确生成年度利润表。

此时需要额外提供 `ytd_debit` 和 `ytd_credit` 字段：

```bash
ft migrate set-balance --account "主营业务收入" --balance 0 --direction credit --period 2025-06 --ytd-credit 500000
ft migrate set-balance --account "管理费用" --balance 0 --direction debit --period 2025-06 --ytd-debit 200000
```
