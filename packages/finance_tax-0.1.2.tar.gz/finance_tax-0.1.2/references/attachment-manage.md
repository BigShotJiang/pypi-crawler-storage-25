# 附件管理 (Attachment Management)

管理发票照片、电子发票 PDF、银行回单等电子凭证文件。支持多态关联到发票、银行流水、凭证三种业务对象。

## Agent 工作流

```
用户提供发票/回单文件
  ↓
Agent 识别文件内容 → ft invoice add / ft bank import（录入业务数据）
  ↓
ft attachment add --entity-type invoice --entity-id <ID> --file /path/to/file（上传附件）
  ↓
ft invoice verify → ft invoice suggest → ft invoice assign（入账流程）
  ↓
入账时自动将发票附件关联到生成的凭证（无需额外操作）
```

## 存储结构

文件存储在 `~/.finance-tax/attachments/` 下，按公司、类型、月份归档：

```
~/.finance-tax/attachments/
└── {company_id}/
    ├── invoice/
    │   └── 2026-01/
    │       ├── a1b2c3d4e5f6.pdf
    │       └── 7890abcdef01.jpg
    ├── bank_transaction/
    │   └── 2026-01/
    └── voucher/
        └── 2026-01/
```

- 文件名使用 SHA-256 前12位 + 原始扩展名
- 相同哈希不重复存储
- 同一业务对象下不允许上传相同文件

## 支持的附件类别

| category | 说明 |
|----------|------|
| `invoice_photo` | 纸质发票拍照 |
| `e_invoice` | 电子发票文件（PDF/OFD） |
| `bank_cert` | 银行回单/电子凭证 |
| `other` | 其他附件 |

## 限制

- 单文件最大 20MB
- 关联对象类型: `invoice` / `bank_transaction` / `voucher`

---

## CLI 命令参考

### add — 上传附件

```bash
ft attachment add --entity-type <类型> --entity-id <ID> --file <文件路径> [选项]
```

将本地文件复制到托管目录并关联到指定业务对象。

**参数：**
- `--entity-type` — 关联对象类型: `invoice` / `bank_transaction` / `voucher`（必填）
- `--entity-id` — 关联对象 ID（必填）
- `--file` — 本地文件路径（必填）
- `--category` — 附件类别: `invoice_photo` / `e_invoice` / `bank_cert` / `other`（默认 `other`）
- `--memo` — 备注
- `--json-output` — JSON 格式输出

**示例：**
```bash
# 上传发票照片
ft attachment add --entity-type invoice --entity-id 1 --file /tmp/发票.jpg --category invoice_photo --json-output

# 上传电子发票 PDF
ft attachment add --entity-type invoice --entity-id 1 --file /tmp/e_invoice.pdf --category e_invoice --json-output

# 上传银行回单
ft attachment add --entity-type bank_transaction --entity-id 5 --file /tmp/回单.jpg --category bank_cert --json-output
```

**输出示例：**
```json
{
  "status": "ok",
  "id": 1,
  "entity_type": "invoice",
  "entity_id": 1,
  "file_name": "发票.jpg",
  "file_path": "/Users/xxx/.finance-tax/attachments/1/invoice/2026-01/a1b2c3d4e5f6.jpg",
  "file_size": 125430,
  "file_hash": "a1b2c3d4e5f6...",
  "mime_type": "image/jpeg",
  "category": "invoice_photo",
  "memo": null
}
```

### list — 查看附件列表

```bash
ft attachment list --entity-type <类型> --entity-id <ID> [--json-output]
```

列出指定业务对象的所有附件。

**参数：**
- `--entity-type` — 关联对象类型（必填）
- `--entity-id` — 关联对象 ID（必填）
- `--json-output` — JSON 格式输出

**输出示例：**
```json
{
  "entity_type": "invoice",
  "entity_id": 1,
  "total": 2,
  "attachments": [
    {
      "id": 1,
      "file_name": "发票.jpg",
      "file_size": 125430,
      "category": "invoice_photo"
    },
    {
      "id": 2,
      "file_name": "e_invoice.pdf",
      "file_size": 89200,
      "category": "e_invoice"
    }
  ]
}
```

### info — 查看附件详情

```bash
ft attachment info <附件ID>
```

返回附件的完整信息（JSON 格式），包括绝对文件路径。Agent 可据此向用户展示文件。

### delete — 删除附件

```bash
ft attachment delete <附件ID> [--json-output]
```

删除附件记录。文件本身不删除（可能被其他记录引用）。

---

## 自动关联机制

当通过 `ft invoice assign` 入账时，系统会自动：

1. 检查该发票是否有附件
2. 将所有发票附件关联到生成的凭证（不复制文件，新增数据库引用）
3. 更新凭证的 `attachment_count` 字段
4. 在入账结果中返回 `attachments_linked` 数量

Agent 无需额外操作，只需在录入发票时上传附件即可。
