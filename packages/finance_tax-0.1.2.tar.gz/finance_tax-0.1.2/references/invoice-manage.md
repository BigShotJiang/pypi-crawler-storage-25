# 发票管理 (Invoice)

## 概述

管理进项发票（购入）和销项发票（销售）。

本模块**不负责发票识别**。Agent 自行通过 OCR 能力、PDF 解析能力或其他 skill 识别发票内容（图片、PDF、截图等），提取出结构化字段后，通过 CLI 命令参数写入系统。

## Agent 引导流程

> **重要**：以下流程说明是写给 Agent 的，请按此流程引导用户完成发票录入。

### 第一步：获取发票原始文件

向用户说明：

```
请提供发票文件（图片、PDF、截图均可），我会帮您识别并录入。
也可以直接告诉我发票信息，我来帮您手工录入。
```

### 第二步：Agent 识别发票内容

Agent 通过自身 OCR 能力或其他 skill 识别发票，提取以下字段：

| 字段 | 说明 | 是否必填 |
|------|------|---------|
| 发票号码 | 发票上的号码 | ✓ |
| 开票日期 | YYYY-MM-DD 格式 | ✓ |
| 方向 | input（进项）或 output（销项） | ✓ |
| 不含税金额 | 正数 | ✓（至少填一项金额） |
| 税额 | 正数 | |
| 价税合计 | 正数 | |
| 发票代码 | | |
| 发票类型 | vat_special / vat_normal / vat_electronic | |
| 税率 | 如 3、6、9、13 等 | |
| 销售方名称 | | |
| 销售方税号 | | |
| 购买方名称 | | |
| 购买方税号 | | |
| 费用类别 | 如 办公费、差旅费 等 | |
| 备注 | | |

### 第三步：写入发票

**方式一：逐条录入**

```bash
ft invoice add \
  --invoice-number "12345678" \
  --invoice-date 2025-03-15 \
  --direction input \
  --amount 10000.00 \
  --tax-amount 1300.00 \
  --total-amount 11300.00 \
  --invoice-type vat_special \
  --tax-rate 13 \
  --seller-name "XX供应商有限公司" \
  --seller-tax-id 91110000XXXXXXXX \
  --buyer-name "我的公司" \
  --expense-category "办公费" \
  --memo "购买办公设备" \
  --json-output
```

**方式二：批量录入**（推荐，Agent 整理好 JSON 后一次性导入）

```bash
ft invoice batch-add --json-output --json-data '[
  {
    "invoice_number": "12345678",
    "invoice_date": "2025-03-15",
    "direction": "input",
    "amount": 10000.00,
    "tax_amount": 1300.00,
    "total_amount": 11300.00,
    "invoice_type": "vat_special",
    "tax_rate": 13,
    "seller_name": "XX供应商有限公司",
    "expense_category": "办公费"
  },
  {
    "invoice_number": "87654321",
    "invoice_date": "2025-03-20",
    "direction": "output",
    "amount": 50000.00,
    "tax_amount": 6500.00,
    "total_amount": 56500.00,
    "invoice_type": "vat_special",
    "tax_rate": 13,
    "buyer_name": "客户有限公司"
  }
]'
```

### 第四步：查验发票

录入后需查验发票真伪（未查验的发票不允许入账）：

```bash
ft invoice verify --invoice-id <发票ID> --json-output
```

查验通过后发票 `is_verified` 自动标记为 `true`。

### 第五步：审核入账

**5a. 获取科目建议**

```bash
ft invoice suggest <发票ID>
```

系统根据发票的费用类别、备注等信息推荐科目，输出 JSON 格式的建议列表（含置信度）。无匹配时返回默认建议（进项→管理费用，销项→主营业务收入）。

**输出示例：**
```json
{
  "invoice_id": 1,
  "invoice_number": "12345678",
  "direction": "input",
  "amount": 10000.00,
  "is_verified": true,
  "is_processed": false,
  "suggestions": [
    {
      "account_code": "560206",
      "account_name": "办公费",
      "confidence": 0.7,
      "reason": "关键词匹配: 办公"
    }
  ]
}
```

**5b. Agent 判断 / 询问用户确认科目**

如果建议列表为空或置信度较低，Agent 应询问用户确认科目。

**5c. 指定科目生成凭证**

```bash
ft invoice assign <发票ID> --account <科目> [--post] --json-output
```

- 进项发票自动生成: 借 费用/成本科目(不含税) + 借 进项税额, 贷 应付账款
- 销项发票自动生成: 借 应收账款, 贷 收入科目(不含税) + 贷 销项税额

**示例：**
```bash
# 进项发票 - 办公费
ft invoice assign 1 --account "办公费" --post --json-output

# 销项发票 - 主营业务收入
ft invoice assign 2 --account "主营业务收入" --post --json-output

# 用科目编码
ft invoice assign 3 --account 560206 --post --json-output
```

### Agent 发票审核工作流

推荐的 Agent 处理发票的标准流程：

```
1. ft invoice list --unprocessed --json-output    → 获取未入账发票
2. ft invoice verify --invoice-id <id>             → 查验发票真伪
3. ft invoice suggest <id>                         → 获取科目建议
4. Agent 判断 / 询问用户确认科目
5. ft invoice assign <id> --account <科目> --post  → 指定科目生成凭证
```

### 第六步：确认录入结果

```bash
ft invoice list --json-output
```

## 命令参考

### add — 录入单张发票

```bash
ft invoice add [选项]
```

**必填选项：**
- `--invoice-number TEXT` — 发票号码
- `--invoice-date YYYY-MM-DD` — 开票日期
- `--direction input|output` — 方向（input=进项, output=销项）
- `--amount DECIMAL` — 不含税金额

**可选选项：**
- `--invoice-code TEXT` — 发票代码
- `--invoice-type vat_special|vat_normal|vat_electronic` — 发票类型（默认: vat_normal）
- `--tax-amount DECIMAL` — 税额（默认: 0）
- `--total-amount DECIMAL` — 价税合计（默认: 自动计算 amount + tax_amount）
- `--tax-rate DECIMAL` — 税率（如 13, 9, 6, 3 等）
- `--seller-name TEXT` — 销售方名称
- `--seller-tax-id TEXT` — 销售方税号
- `--buyer-name TEXT` — 购买方名称
- `--buyer-tax-id TEXT` — 购买方税号
- `--expense-category TEXT` — 费用类别
- `--memo TEXT` — 备注
- `--json-output` — JSON 格式输出

### batch-add — 批量录入发票

```bash
ft invoice batch-add --json-data '<JSON数组>' [--json-output]
```

**JSON 数组格式：**
```json
[
  {
    "invoice_number": "发票号码(必填)",
    "invoice_date": "开票日期 YYYY-MM-DD(必填)",
    "direction": "input 或 output(必填)",
    "amount": "不含税金额(必填)",
    "invoice_code": "发票代码(可选)",
    "invoice_type": "vat_special|vat_normal|vat_electronic(可选, 默认 vat_normal)",
    "tax_amount": "税额(可选, 默认 0)",
    "total_amount": "价税合计(可选, 自动计算)",
    "tax_rate": "税率(可选)",
    "seller_name": "销售方名称(可选)",
    "seller_tax_id": "销售方税号(可选)",
    "buyer_name": "购买方名称(可选)",
    "buyer_tax_id": "购买方税号(可选)",
    "expense_category": "费用类别(可选)",
    "memo": "备注(可选)"
  }
]
```

### list — 查看发票列表

```bash
ft invoice list [选项]
```

**选项：**
- `--direction input|output|all` — 筛选方向（默认: all）
- `--unprocessed` — 只显示未记账的
- `--limit INT` — 显示条数（默认: 50）
- `--json-output` — JSON 格式输出

### verify — 查验发票

```bash
ft invoice verify --invoice-id <发票ID> [--json-output]
```

通过阿里云云市场发票查验 API 查验发票真伪。需要先配置 AppCode。**未查验的发票不允许入账。**

**前置条件：** 需要配置发票查验 AppCode（阿里云云市场购买）:

```bash
ft config set --invoice-verify-appcode YOUR_APPCODE
```

AppCode 也可在初始化时配置：

```bash
ft init --name "公司名称" --invoice-verify-appcode YOUR_APPCODE
```

> AppCode 购买地址: [阿里云云市场 - 发票查验](https://market.aliyun.com/detail/cmapi00069751)

**选项：**
- `--invoice-id INT` — 系统中的发票 ID（必填）
- `--json-output` — JSON 格式输出

### suggest — 为发票推荐科目

```bash
ft invoice suggest <发票ID>
```

根据发票的费用类别、备注等信息推荐费用/收入科目，输出 JSON 格式的建议列表（含置信度和匹配原因）。供 Agent 参考决策。

**参数：**
- `<发票ID>` — 发票 ID

**输出示例：**
```json
{
  "invoice_id": 1,
  "invoice_number": "12345678",
  "direction": "input",
  "amount": 10000.00,
  "is_verified": true,
  "is_processed": false,
  "suggestions": [
    {
      "account_code": "560206",
      "account_name": "办公费",
      "confidence": 0.7,
      "reason": "关键词匹配: 办公费"
    }
  ]
}
```

### assign — 为发票指定科目生成凭证

```bash
ft invoice assign <发票ID> --account <科目> [选项]
```

**前置条件：** 发票必须已通过查验（`is_verified: true`），否则拒绝入账。

**参数：**
- `<发票ID>` — 发票 ID
- `--account` — 费用/收入科目（支持科目**名称**或**编码**）
- `--post` — 生成后自动过账
- `--json-output` — JSON 格式输出

**自动分录规则：**
- **进项发票**: 借 费用/成本科目(不含税) + 借 应交税费-进项税额, 贷 应付账款
- **销项发票**: 借 应收账款, 贷 收入科目(不含税) + 贷 应交税费-销项税额

**使用示例：**
```bash
ft invoice assign 1 --account "管理费用-办公费" --post --json-output
ft invoice assign 2 --account "主营业务收入" --post --json-output
ft invoice assign 3 --account 560206 --post --json-output
```

## 发票类型说明

| 类型值 | 说明 |
|-------|------|
| `vat_special` | 增值税专用发票 |
| `vat_normal` | 增值税普通发票 |
| `vat_electronic` | 增值税电子发票 |

## 方向说明

| 方向值 | 说明 |
|-------|------|
| `input` | 进项（购入费用/成本） |
| `output` | 销项（销售收入） |
