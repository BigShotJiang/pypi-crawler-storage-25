---
name: finance-tax
description: 中国企业记账报税助手，支持银行流水导入、发票管理、自动记账、财务报表生成和税务申报。适配小规模/一般纳税人，兼容小企业会计准则和企业会计准则。
metadata: { "openclaw": { "emoji": "🧾", "requires": { "bins": ["uv"] }, "homepage": "https://github.com/jiulingyun/finance-tax" } }
---

# 记账报税技能包 (finance-tax)

这是一个面向中国中小微企业的智能记账报税技能包，帮助 OpenClaw 等 AI Agent 完成从银行流水导入到税务申报的完整财务流程。

## � 安装

本技能包已发布到 [PyPI](https://pypi.org/project/finance-tax/)，通过 uv 安装即可使用：

```bash
# 安装
uv tool install finance-tax

# 安装可选依赖（Web 看板）
uv tool install "finance-tax[api]"

# 更新到最新版本
uv tool upgrade finance-tax
```

安装后 `ft` 命令全局可用，无需在项目目录下运行。

## 📦 包含模块

### 1. 初始化配置 (Setup)
首次使用时通过参数完成公司信息、纳税人类型、会计准则的配置。
*   **指令**: `ft init --name "公司名称" [--tax-id 税号] [--taxpayer-type small_scale|general] [--standard small_enterprise|enterprise] [--industry 行业] [--year 年度] [--invoice-verify-appcode APPCODE]`
*   **指令**: `ft config set --invoice-verify-appcode <APPCODE>` — 配置发票查验AppCode
*   **指令**: `ft config show` — 查看当前配置
*   **详情**: [查看文档](references/setup.md)

### 2. 银行流水管理 (Bank Statement)
导入主流银行导出的Excel流水文件，自动识别列映射，支持去重和批量导入。
*   **指令**: `ft bank import <excel_path>` / `ft bank list`
*   **详情**: [查看文档](references/bank-import.md)

### 3. 发票管理 (Invoice)
Agent 自行识别发票内容（OCR、PDF解析等），提取结构化字段后通过参数写入系统，支持查验、科目建议、审核入账全流程。
*   **指令**: `ft invoice add --invoice-number <号码> --invoice-date <日期> --direction input|output --amount <金额> [--json-output]` — 录入单张发票
*   **指令**: `ft invoice batch-add --json-data '<JSON数组>' [--json-output]` — 批量录入发票
*   **指令**: `ft invoice list [--direction input|output|all] [--unprocessed] [--json-output]` — 查看发票列表
*   **指令**: `ft invoice verify --invoice-id <发票ID> [--json-output]` — 查验发票真伪（对接阿里云API，需配置AppCode）
*   **指令**: `ft invoice suggest <发票ID>` — 为发票推荐费用/收入科目（JSON输出，含置信度）
*   **指令**: `ft invoice assign <发票ID> --account <科目> [--post] [--json-output]` — 指定科目生成凭证（需先查验通过）
*   **详情**: [查看文档](references/invoice-manage.md)

### 4. 凭证管理 (Voucher)
Agent 审核银行流水并指定科目生成凭证，支持智能科目建议、手动指定科目、批量过账。
*   **指令**: `ft voucher suggest <流水ID>` — 为流水推荐科目（JSON输出，含置信度）
*   **指令**: `ft voucher assign <流水ID> --debit <科目> --credit <科目> [--description <摘要>] [--post] [--json-output]` — 指定科目生成凭证
*   **指令**: `ft voucher create --date YYYY-MM-DD --debit <科目> --credit <科目> --amount <金额> [--description <摘要>] [--post] [--json-output]` — 手工创建凭证（计提工资/折旧等）
*   **指令**: `ft voucher create --date YYYY-MM-DD --entries '<JSON数组>' [--description <摘要>] [--post] [--json-output]` — 多借多贷手工凭证
*   **指令**: `ft voucher list` / `ft voucher post-all --period YYYY-MM`
*   **详情**: [查看文档](references/voucher-generate.md)

### 5. 财务报表 (Report)
自动生成符合中国会计准则的五大财务报表。
*   **指令**: `ft report trial-balance --period YYYY-MM`
*   **指令**: `ft report balance-sheet --period YYYY-MM`
*   **指令**: `ft report income --period YYYY-MM`
*   **指令**: `ft report cashflow --period YYYY-MM`
*   **详情**: [查看文档](references/report-generate.md)

### 6. 税务计算与申报 (Tax)
支持增值税、企业所得税、印花税、附加税的自动计算，生成符合税局格式的申报数据。
*   **指令**: `ft tax vat --period-start YYYY-MM --period-end YYYY-MM`
*   **指令**: `ft tax income --year YYYY --quarter N`
*   **指令**: `ft tax stamp --period YYYY-MM --type <合同类型> --amount <金额>`
*   **指令**: `ft tax surcharge --period YYYY-MM --vat-paid <增值税额>`
*   **详情**: [查看文档](references/tax-calculate.md)

### 7. 科目与期间管理 (Account & Period)
查看和管理会计科目表、会计期间，支持结账/反结账。
*   **指令**: `ft account list` / `ft period list` / `ft period close YYYY-MM`
*   **详情**: [查看文档](references/account-period.md)

### 8. 迁移记账 (Migrate)
从其他记账系统（自记账App、代账公司、金蝶、用友等）迁移期初余额，保证账务连续性。支持逐条或批量导入，自动验证借贷平衡。
*   **指令**: `ft migrate set-balance --account <科目> --balance <金额> --direction debit|credit --period YYYY-MM` — 设置单个科目期初余额
*   **指令**: `ft migrate import-balance --period YYYY-MM --json-data '<JSON数组>'` — 批量导入期初余额
*   **指令**: `ft migrate verify --period YYYY-MM` — 验证期初余额借贷平衡
*   **详情**: [查看文档](references/migrate.md)

### 9. 附件管理 (Attachment)
管理发票照片、电子发票文件、银行回单等电子凭证，支持上传、查询、关联。发票入账时自动将附件关联到生成的凭证。
*   **指令**: `ft attachment add --entity-type invoice|bank_transaction|voucher --entity-id <ID> --file <文件路径> [--category invoice_photo|e_invoice|bank_cert|other] [--memo 备注]` — 上传附件
*   **指令**: `ft attachment list --entity-type <类型> --entity-id <ID> [--json-output]` — 查看附件列表
*   **指令**: `ft attachment info <附件ID>` — 查看附件详情（JSON输出）
*   **指令**: `ft attachment delete <附件ID> [--json-output]` — 删除附件
*   **详情**: [查看文档](references/attachment-manage.md)

### 10. Web 数据看板 (Dashboard)
内置专业 Web 界面，提供数据概览、银行流水/发票/凭证查询、财务报表展示、月度收支图表。
*   **指令**: `ft web [--host 0.0.0.0] [--port 8000]`
*   **依赖**: 需安装 api 可选依赖 `uv tool install "finance-tax[api]"`

### 11. 电子税务局自动开票 (E-Tax Invoice)
通过浏览器自动化控制宁波电子税务局，完成蓝字发票在线开具。请查看文档 `references/etax-invoice.md` 获取详细流程和注意事项再开始操作。
*   **前提**: Agent 需具备浏览器控制能力（Playwright 或等效工具）
*   **流程**: 扫码登录 → 导航开票页 → 选择票类 → 填写信息 → 用户确认 → 提交开具 → 同步系统
*   **注意**: 会话不可持久化，整个流程必须在单次浏览器会话中连续完成
*   **详情**: [查看文档](references/etax-invoice.md)

## ⚙️ 使用前准备

通过 `uv tool install finance-tax` 安装后，`ft` 命令全局可用。首次使用请先运行 `ft init --name "公司名称"` 完成初始化。所有命令均为非交互式，通过参数传递配置，适合 Agent 直接调用。

## 💡 典型工作流

1. `ft init --name "XX科技有限公司" --tax-id 91110000XXXXXXXX` — 初始化账套
2. `ft bank import 银行流水.xlsx` — 导入银行流水
3. `ft invoice add --invoice-number <号码> --invoice-date <日期> --direction input --amount <金额>` — 录入发票
4. `ft invoice verify --invoice-id <发票ID>` — 查验发票真伪
5. `ft bank list --unprocessed --json-output` — 获取待处理流水
6. `ft voucher suggest <流水ID>` — 获取科目建议（无匹配时询问用户）
7. `ft voucher assign <流水ID> --debit <科目> --credit <科目> --post` — 审核并生成凭证
8. `ft invoice suggest <发票ID>` — 获取发票科目建议
9. `ft invoice assign <发票ID> --account <科目> --post` — 审核发票入账
10. `ft voucher create --date YYYY-MM-DD --entries '...' --post` — 月末计提工资/折旧等
11. `ft report balance-sheet --period 2026-03` — 生成资产负债表
12. `ft tax vat --period-start 2026-01 --period-end 2026-03` — 计算季度增值税
