"""CLI 单元测试 - 覆盖所有 ft 命令"""

import json
import os
import re
import tempfile
from datetime import date
from decimal import Decimal
from pathlib import Path

import pytest
from click.testing import CliRunner

from finance_tax.cli import cli
from finance_tax.database import reset_engine


def strip_ansi(text: str) -> str:
    """移除 Rich 输出中的所有 ANSI / OSC 转义序列"""
    # CSI sequences: ESC[ ... letter
    text = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', text)
    # OSC sequences: ESC] ... (BEL or ST)
    text = re.sub(r'\x1b\].*?(?:\x07|\x1b\\)', '', text)
    return text


def parse_json_output(output: str):
    """从 CLI 输出中解析 JSON（先去除 ANSI 转义，再用 strict=False 容忍残留控制字符）"""
    return json.loads(strip_ansi(output), strict=False)


@pytest.fixture(autouse=True)
def isolated_data_dir(tmp_path):
    """每个测试使用独立的临时数据目录，避免污染真实数据"""
    reset_engine()
    yield tmp_path
    reset_engine()


def invoke(runner, args, data_dir):
    """辅助调用 CLI 并注入 --data-dir"""
    return runner.invoke(cli, ["--data-dir", str(data_dir)] + args, catch_exceptions=False)


def init_company(runner, data_dir, **kwargs):
    """初始化一个测试公司，返回 Result"""
    args = [
        "init",
        "--name", kwargs.get("name", "测试公司"),
        "--json-output",
    ]
    if "tax_id" in kwargs:
        args += ["--tax-id", kwargs["tax_id"]]
    if "taxpayer_type" in kwargs:
        args += ["--taxpayer-type", kwargs["taxpayer_type"]]
    if "standard" in kwargs:
        args += ["--standard", kwargs["standard"]]
    if "year" in kwargs:
        args += ["--year", str(kwargs["year"])]
    return invoke(runner, args, data_dir)


# ============================================================
# init 命令
# ============================================================
class TestInit:
    def test_init_default(self, isolated_data_dir):
        runner = CliRunner()
        result = invoke(runner, [
            "init", "--name", "单元测试公司", "--json-output"
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["status"] == "ok"
        assert data["company"] == "单元测试公司"
        assert data["taxpayer_type"] == "small_scale"
        assert data["accounting_standard"] == "small_enterprise"
        assert data["accounts_imported"] > 0

    def test_init_with_all_options(self, isolated_data_dir):
        runner = CliRunner()
        result = invoke(runner, [
            "init", "--name", "完整参数公司",
            "--tax-id", "91110000TEST0001",
            "--taxpayer-type", "general",
            "--standard", "enterprise",
            "--industry", "软件开发",
            "--year", "2025",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["company"] == "完整参数公司"
        assert data["tax_id"] == "91110000TEST0001"
        assert data["taxpayer_type"] == "general"
        assert data["accounting_standard"] == "enterprise"
        assert data["year"] == 2025

    def test_init_text_output(self, isolated_data_dir):
        runner = CliRunner()
        result = invoke(runner, [
            "init", "--name", "文本输出公司",
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "初始化完成" in result.output
        assert "文本输出公司" in result.output

    def test_init_missing_name(self, isolated_data_dir):
        runner = CliRunner()
        result = invoke(runner, ["init"], isolated_data_dir)
        assert result.exit_code != 0

    def test_init_invalid_taxpayer_type(self, isolated_data_dir):
        runner = CliRunner()
        result = runner.invoke(cli, [
            "--data-dir", str(isolated_data_dir),
            "init", "--name", "X", "--taxpayer-type", "invalid"
        ])
        assert result.exit_code != 0


# ============================================================
# status 命令
# ============================================================
class TestStatus:
    def test_status_after_init(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir, name="状态测试公司")
        result = invoke(runner, ["status"], isolated_data_dir)
        assert result.exit_code == 0
        assert "状态测试公司" in result.output

    def test_status_without_init(self, isolated_data_dir):
        runner = CliRunner()
        result = runner.invoke(cli, [
            "--data-dir", str(isolated_data_dir), "status"
        ])
        # 未初始化应退出
        assert result.exit_code != 0


# ============================================================
# bank 命令
# ============================================================
class TestBank:
    def _create_bank_excel(self, tmp_path) -> str:
        """创建测试用银行流水 Excel"""
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["交易日期", "摘要", "借方金额", "贷方金额", "余额", "对方户名", "流水号"])
        ws.append([date(2025, 1, 5), "收到货款", "", 50000.00, 150000.00, "ABC公司", "20250105001"])
        ws.append([date(2025, 1, 8), "支付办公用品", 1200.00, "", 148800.00, "京东", "20250108001"])
        ws.append([date(2025, 1, 10), "支付房租", 8000.00, "", 140800.00, "物业公司", "20250110001"])
        filepath = str(tmp_path / "bank_test.xlsx")
        wb.save(filepath)
        return filepath

    def test_bank_import(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        excel_path = self._create_bank_excel(isolated_data_dir)
        result = invoke(runner, [
            "bank", "import", excel_path, "--bank-name", "测试银行"
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "导入完成" in result.output

    def test_bank_list(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        excel_path = self._create_bank_excel(isolated_data_dir)
        invoke(runner, ["bank", "import", excel_path], isolated_data_dir)
        result = invoke(runner, ["bank", "list"], isolated_data_dir)
        assert result.exit_code == 0
        assert "银行流水" in result.output

    def test_bank_list_json(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        excel_path = self._create_bank_excel(isolated_data_dir)
        invoke(runner, ["bank", "import", excel_path], isolated_data_dir)
        result = invoke(runner, [
            "bank", "list", "--json-output"
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert isinstance(data, list)
        assert len(data) == 3

    def test_bank_list_unprocessed(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        excel_path = self._create_bank_excel(isolated_data_dir)
        invoke(runner, ["bank", "import", excel_path], isolated_data_dir)
        result = invoke(runner, [
            "bank", "list", "--unprocessed", "--json-output"
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert all(not t["processed"] for t in data)


# ============================================================
# invoice 命令
# ============================================================
class TestInvoice:
    def _create_invoice_excel(self, tmp_path) -> str:
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append([
            "发票号码", "开票日期", "发票类型", "方向",
            "不含税金额", "税额", "价税合计", "税率",
            "销售方名称", "购买方名称", "费用类别", "备注"
        ])
        ws.append([
            "10001234", date(2025, 1, 5), "普通发票", "销项",
            48543.69, 1456.31, 50000.00, "3%",
            "", "ABC公司", "", "服务费"
        ])
        ws.append([
            "20005678", date(2025, 1, 8), "普通发票", "进项",
            1132.08, 67.92, 1200.00, "6%",
            "京东", "", "办公费", "办公用品"
        ])
        filepath = str(tmp_path / "invoice_test.xlsx")
        wb.save(filepath)
        return filepath

    def test_invoice_add(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "invoice", "add",
            "--invoice-number", "10001234",
            "--invoice-date", "2025-01-05",
            "--direction", "output",
            "--amount", "48543.69",
            "--tax-amount", "1456.31",
            "--invoice-type", "vat_normal",
            "--buyer-name", "ABC公司",
            "--memo", "服务费",
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "录入成功" in result.output

    def test_invoice_batch_add(self, isolated_data_dir):
        import json
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        json_data = json.dumps([
            {
                "invoice_number": "10001234",
                "invoice_date": "2025-01-05",
                "direction": "output",
                "amount": 48543.69,
                "tax_amount": 1456.31,
                "buyer_name": "ABC公司",
            },
            {
                "invoice_number": "20005678",
                "invoice_date": "2025-01-08",
                "direction": "input",
                "amount": 1132.08,
                "tax_amount": 67.92,
                "seller_name": "京东",
                "expense_category": "办公费",
            },
        ], ensure_ascii=False)
        result = invoke(runner, [
            "invoice", "batch-add", "--json-data", json_data,
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "批量录入完成" in result.output
        assert "成功: 2" in result.output

    def test_invoice_list(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        invoke(runner, [
            "invoice", "add",
            "--invoice-number", "10001234",
            "--invoice-date", "2025-01-05",
            "--direction", "output",
            "--amount", "48543.69",
        ], isolated_data_dir)
        result = invoke(runner, ["invoice", "list"], isolated_data_dir)
        assert result.exit_code == 0
        assert "发票列表" in result.output

    def test_invoice_list_direction_filter(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        invoke(runner, [
            "invoice", "add",
            "--invoice-number", "20005678",
            "--invoice-date", "2025-01-08",
            "--direction", "input",
            "--amount", "1132.08",
        ], isolated_data_dir)
        result = invoke(runner, [
            "invoice", "list", "--direction", "input"
        ], isolated_data_dir)
        assert result.exit_code == 0

    def test_invoice_verify_no_appcode(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        invoke(runner, [
            "invoice", "add",
            "--invoice-number", "10001234",
            "--invoice-date", "2025-01-05",
            "--direction", "output",
            "--amount", "48543.69",
        ], isolated_data_dir)
        result = invoke(runner, [
            "invoice", "verify", "--invoice-id", "1",
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "未配置" in result.output or "AppCode" in result.output

    def test_invoice_add_duplicate(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        invoke(runner, [
            "invoice", "add",
            "--invoice-number", "10001234",
            "--invoice-date", "2025-01-05",
            "--direction", "output",
            "--amount", "48543.69",
        ], isolated_data_dir)
        result = invoke(runner, [
            "invoice", "add",
            "--invoice-number", "10001234",
            "--invoice-date", "2025-01-05",
            "--direction", "output",
            "--amount", "48543.69",
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "已存在" in result.output


# ============================================================
# voucher 命令
# ============================================================
class TestVoucher:
    def _setup_with_bank_data(self, runner, data_dir):
        """初始化 + 导入银行流水"""
        init_company(runner, data_dir)
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["交易日期", "摘要", "借方金额", "贷方金额", "余额", "对方户名", "流水号"])
        ws.append([date(2025, 1, 5), "收到货款-销售", "", 50000.00, 150000.00, "ABC公司", "V001"])
        ws.append([date(2025, 1, 8), "支付房租", 8000.00, "", 142000.00, "物业", "V002"])
        filepath = str(data_dir / "bank_v.xlsx")
        wb.save(filepath)
        invoke(runner, ["bank", "import", filepath], data_dir)

    def _assign_all(self, runner, data_dir):
        """用 assign 为测试流水生成凭证（替代 generate）"""
        # 流水 #1: 收到货款-销售 (收入)
        invoke(runner, [
            "voucher", "assign", "1",
            "--debit", "银行存款", "--credit", "主营业务收入",
        ], data_dir)
        # 流水 #2: 支付房租 (支出)
        invoke(runner, [
            "voucher", "assign", "2",
            "--debit", "租赁费", "--credit", "银行存款",
        ], data_dir)

    def test_voucher_list(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_bank_data(runner, isolated_data_dir)
        self._assign_all(runner, isolated_data_dir)
        result = invoke(runner, ["voucher", "list"], isolated_data_dir)
        assert result.exit_code == 0
        assert "凭证列表" in result.output

    def test_voucher_list_by_period(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_bank_data(runner, isolated_data_dir)
        self._assign_all(runner, isolated_data_dir)
        result = invoke(runner, [
            "voucher", "list", "--period", "2025-01"
        ], isolated_data_dir)
        assert result.exit_code == 0

    def test_voucher_post_all(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_bank_data(runner, isolated_data_dir)
        self._assign_all(runner, isolated_data_dir)
        result = invoke(runner, [
            "voucher", "post-all", "--period", "2025-01"
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "已过账" in result.output

    def test_voucher_suggest(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_bank_data(runner, isolated_data_dir)
        # 流水 #1 摘要为 "收到货款-销售"，应匹配 "货款" 关键词
        result = invoke(runner, ["voucher", "suggest", "1"], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["transaction_id"] == 1
        assert data["is_processed"] is False
        assert isinstance(data["suggestions"], list)
        assert len(data["suggestions"]) > 0
        assert "confidence" in data["suggestions"][0]

    def test_voucher_suggest_no_match(self, isolated_data_dir):
        """摘要无匹配关键词时返回空建议列表"""
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["交易日期", "摘要", "借方金额", "贷方金额", "余额", "对方户名", "流水号"])
        ws.append([date(2025, 1, 5), "其他转账", 1000.00, "", 99000.00, "张三", "S001"])
        fp = str(isolated_data_dir / "bank_s.xlsx")
        wb.save(fp)
        invoke(runner, ["bank", "import", fp], isolated_data_dir)
        result = invoke(runner, ["voucher", "suggest", "1"], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["suggestions"] == []

    def test_voucher_assign(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_bank_data(runner, isolated_data_dir)
        # 手动为 #1 (收入 50000) 指定科目
        result = invoke(runner, [
            "voucher", "assign", "1",
            "--debit", "银行存款", "--credit", "主营业务收入",
            "--description", "收到ABC销售货款",
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "已生成" in strip_ansi(result.output)
        assert "50,000.00" in strip_ansi(result.output)

    def test_voucher_assign_json(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_bank_data(runner, isolated_data_dir)
        result = invoke(runner, [
            "voucher", "assign", "2",
            "--debit", "租赁费", "--credit", "银行存款",
            "--description", "支付1月房租",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["voucher_id"] > 0
        assert data["amount"] == 8000.0
        assert data["debit_account"]["name"] == "租赁费"
        assert data["credit_account"]["name"] == "银行存款"

    def test_voucher_assign_with_post(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_bank_data(runner, isolated_data_dir)
        result = invoke(runner, [
            "voucher", "assign", "1",
            "--debit", "银行存款", "--credit", "主营业务收入",
            "--post", "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["status"] == "posted"

    def test_voucher_assign_duplicate_rejected(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_bank_data(runner, isolated_data_dir)
        invoke(runner, [
            "voucher", "assign", "1",
            "--debit", "银行存款", "--credit", "主营业务收入",
        ], isolated_data_dir)
        # 再次 assign 同一笔应被拒绝
        result = invoke(runner, [
            "voucher", "assign", "1",
            "--debit", "银行存款", "--credit", "主营业务收入",
        ], isolated_data_dir)
        assert result.exit_code == 1
        assert "已处理" in strip_ansi(result.output)

    def test_voucher_assign_by_code(self, isolated_data_dir):
        """支持用科目编码指定"""
        runner = CliRunner()
        self._setup_with_bank_data(runner, isolated_data_dir)
        result = invoke(runner, [
            "voucher", "assign", "1",
            "--debit", "1002", "--credit", "5001",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["debit_account"]["code"] == "1002"
        assert data["credit_account"]["code"] == "5001"

    def test_voucher_create_simple(self, isolated_data_dir):
        """简单模式: 一借一贷"""
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "voucher", "create",
            "--date", "2025-01-31",
            "--debit", "管理费用/工资", "--credit", "应付职工薪酬/工资",
            "--amount", "15000",
            "--description", "计提1月工资",
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "已生成" in result.output

    def test_voucher_create_simple_json(self, isolated_data_dir):
        """简单模式 JSON 输出"""
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "voucher", "create",
            "--date", "2025-01-31",
            "--debit", "560210", "--credit", "221101",
            "--amount", "15000",
            "--description", "计提1月工资",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["period"] == "2025-01"
        assert len(data["entries"]) == 2
        assert data["entries"][0]["debit"] == 15000.0
        assert data["entries"][1]["credit"] == 15000.0

    def test_voucher_create_multi_entries(self, isolated_data_dir):
        """多分录模式: 工资+社保计提"""
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        entries = json.dumps([
            {"account": "管理费用/工资", "debit": 15000, "credit": 0, "summary": "计提工资"},
            {"account": "管理费用/社保公积金", "debit": 4200, "credit": 0, "summary": "计提社保"},
            {"account": "应付职工薪酬/工资", "debit": 0, "credit": 15000, "summary": "计提工资"},
            {"account": "应付职工薪酬/社会保险费", "debit": 0, "credit": 4200, "summary": "计提社保"},
        ])
        result = invoke(runner, [
            "voucher", "create",
            "--date", "2025-01-31",
            "--description", "计提1月工资及社保",
            "--entries", entries,
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert len(data["entries"]) == 4
        total_debit = sum(e["debit"] for e in data["entries"])
        total_credit = sum(e["credit"] for e in data["entries"])
        assert total_debit == total_credit == 19200.0

    def test_voucher_create_with_post(self, isolated_data_dir):
        """创建后自动过账"""
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "voucher", "create",
            "--date", "2025-01-31",
            "--debit", "管理费用/工资", "--credit", "应付职工薪酬/工资",
            "--amount", "15000",
            "--post", "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["status"] == "posted"

    def test_voucher_create_unbalanced(self, isolated_data_dir):
        """借贷不平衡应报错"""
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        entries = json.dumps([
            {"account": "管理费用/工资", "debit": 15000, "credit": 0},
            {"account": "应付职工薪酬/工资", "debit": 0, "credit": 10000},
        ])
        result = invoke(runner, [
            "voucher", "create",
            "--date", "2025-01-31",
            "--entries", entries,
        ], isolated_data_dir)
        assert result.exit_code == 1

    def test_voucher_create_bad_account(self, isolated_data_dir):
        """科目不存在应报错"""
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "voucher", "create",
            "--date", "2025-01-31",
            "--debit", "不存在科目", "--credit", "银行存款",
            "--amount", "100",
        ], isolated_data_dir)
        assert result.exit_code == 1


# ============================================================
# migrate 命令
# ============================================================
class TestMigrate:
    def test_set_balance_by_name(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "migrate", "set-balance",
            "--account", "银行存款", "--balance", "150000",
            "--direction", "debit", "--period", "2025-06",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["account_name"] == "银行存款"
        assert data["opening_balance"] == 150000.0
        assert data["opening_period"] == "2025-06"

    def test_set_balance_by_code(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "migrate", "set-balance",
            "--account", "1002", "--balance", "80000",
            "--direction", "debit", "--period", "2025-06",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["account_code"] == "1002"
        assert data["opening_balance"] == 80000.0

    def test_set_balance_credit_account(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "migrate", "set-balance",
            "--account", "应付账款", "--balance", "50000",
            "--direction", "credit", "--period", "2025-06",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["opening_balance"] == 50000.0

    def test_set_balance_with_ytd(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "migrate", "set-balance",
            "--account", "银行存款", "--balance", "150000",
            "--direction", "debit", "--period", "2025-06",
            "--ytd-debit", "500000", "--ytd-credit", "350000",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["ytd_debit"] == 500000.0
        assert data["ytd_credit"] == 350000.0

    def test_set_balance_not_found(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "migrate", "set-balance",
            "--account", "不存在的科目", "--balance", "100",
            "--direction", "debit", "--period", "2025-06",
        ], isolated_data_dir)
        assert result.exit_code == 1

    def test_import_balance(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        json_data = json.dumps([
            {"account": "银行存款", "balance": 150000, "direction": "debit"},
            {"account": "应付账款", "balance": 50000, "direction": "credit"},
            {"account": "实收资本", "balance": 100000, "direction": "credit"},
        ])
        result = invoke(runner, [
            "migrate", "import-balance",
            "--json-data", json_data,
            "--period", "2025-06",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["success_count"] == 3
        assert data["error_count"] == 0

    def test_import_balance_with_errors(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        json_data = json.dumps([
            {"account": "银行存款", "balance": 150000, "direction": "debit"},
            {"account": "不存在科目", "balance": 100, "direction": "debit"},
        ])
        result = invoke(runner, [
            "migrate", "import-balance",
            "--json-data", json_data,
            "--period", "2025-06",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["success_count"] == 1
        assert data["error_count"] == 1
        assert data["errors"][0]["account"] == "不存在科目"

    def test_verify_balanced(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        # 资产 = 负债 + 权益: 150000 = 50000 + 100000
        json_data = json.dumps([
            {"account": "银行存款", "balance": 150000, "direction": "debit"},
            {"account": "应付账款", "balance": 50000, "direction": "credit"},
            {"account": "实收资本", "balance": 100000, "direction": "credit"},
        ])
        invoke(runner, [
            "migrate", "import-balance",
            "--json-data", json_data,
            "--period", "2025-06",
        ], isolated_data_dir)
        result = invoke(runner, [
            "migrate", "verify", "--period", "2025-06", "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["is_balanced"] is True
        assert data["total_debit"] == 150000.0
        assert data["total_credit"] == 150000.0
        assert data["difference"] == 0.0

    def test_verify_unbalanced(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        json_data = json.dumps([
            {"account": "银行存款", "balance": 150000, "direction": "debit"},
            {"account": "应付账款", "balance": 50000, "direction": "credit"},
        ])
        invoke(runner, [
            "migrate", "import-balance",
            "--json-data", json_data,
            "--period", "2025-06",
        ], isolated_data_dir)
        result = invoke(runner, [
            "migrate", "verify", "--period", "2025-06", "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert data["is_balanced"] is False
        assert data["difference"] == 100000.0


# ============================================================
# report 命令
# ============================================================
class TestReport:
    def _setup_with_posted_vouchers(self, runner, data_dir):
        """初始化 + 导入 + 生成凭证 + 过账"""
        init_company(runner, data_dir, year=2025)
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["交易日期", "摘要", "借方金额", "贷方金额", "余额", "对方户名", "流水号"])
        ws.append([date(2025, 1, 5), "收到货款-销售", "", 50000.00, 150000.00, "ABC公司", "R001"])
        ws.append([date(2025, 1, 10), "支付办公用品", 1200.00, "", 148800.00, "京东", "R002"])
        filepath = str(data_dir / "bank_r.xlsx")
        wb.save(filepath)
        invoke(runner, ["bank", "import", filepath], data_dir)
        # 用 assign 逐笔审核生成凭证
        invoke(runner, [
            "voucher", "assign", "1",
            "--debit", "银行存款", "--credit", "主营业务收入",
        ], data_dir)
        invoke(runner, [
            "voucher", "assign", "2",
            "--debit", "办公费", "--credit", "银行存款",
        ], data_dir)
        invoke(runner, ["voucher", "post-all", "--period", "2025-01"], data_dir)

    def test_trial_balance(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_posted_vouchers(runner, isolated_data_dir)
        result = invoke(runner, [
            "report", "trial-balance", "--period", "2025-01"
        ], isolated_data_dir)
        assert result.exit_code == 0

    def test_trial_balance_json(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_posted_vouchers(runner, isolated_data_dir)
        result = invoke(runner, [
            "report", "trial-balance", "--period", "2025-01", "--json-output"
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert isinstance(data, list)

    def test_balance_sheet(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_posted_vouchers(runner, isolated_data_dir)
        result = invoke(runner, [
            "report", "balance-sheet", "--period", "2025-01"
        ], isolated_data_dir)
        assert result.exit_code == 0

    def test_income_statement(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_posted_vouchers(runner, isolated_data_dir)
        result = invoke(runner, [
            "report", "income", "--period", "2025-01"
        ], isolated_data_dir)
        assert result.exit_code == 0

    def test_cashflow(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_with_posted_vouchers(runner, isolated_data_dir)
        result = invoke(runner, [
            "report", "cashflow", "--period", "2025-01"
        ], isolated_data_dir)
        assert result.exit_code == 0


# ============================================================
# tax 命令
# ============================================================
class TestTax:
    def _setup_company(self, runner, data_dir):
        init_company(runner, data_dir, year=2025)

    def test_tax_vat(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "tax", "vat",
            "--period-start", "2025-01", "--period-end", "2025-03",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert "tax_payable" in data or "period" in data

    def test_tax_vat_save(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "tax", "vat",
            "--period-start", "2025-01", "--period-end", "2025-03",
            "--save",
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "保存" in result.output or "增值税" in result.output

    def test_tax_income(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "tax", "income", "--year", "2025", "--quarter", "1",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert "tax_payable" in data

    def test_tax_stamp(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "tax", "stamp",
            "--period", "2025-01",
            "--type", "purchase_sale_contract",
            "--amount", "100000",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert "tax_due" in data
        assert data["tax_due"] > 0

    def test_tax_surcharge(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "tax", "surcharge",
            "--period", "2025-01",
            "--vat-paid", "5000",
            "--location", "city",
            "--json-output",
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert "total_surcharge" in data
        assert data["total_surcharge"] > 0

    def test_tax_surcharge_text_output(self, isolated_data_dir):
        runner = CliRunner()
        self._setup_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "tax", "surcharge",
            "--period", "2025-01", "--vat-paid", "3000",
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "附加税" in result.output


# ============================================================
# account 命令
# ============================================================
class TestAccount:
    def test_account_list(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, ["account", "list"], isolated_data_dir)
        assert result.exit_code == 0
        assert "会计科目" in result.output

    def test_account_list_by_category(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "account", "list", "--category", "asset"
        ], isolated_data_dir)
        assert result.exit_code == 0

    def test_account_list_by_keyword(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "account", "list", "--keyword", "银行"
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "银行" in result.output

    def test_account_list_by_level(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "account", "list", "--level", "1"
        ], isolated_data_dir)
        assert result.exit_code == 0

    def test_account_list_json(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir)
        result = invoke(runner, [
            "account", "list", "--json-output"
        ], isolated_data_dir)
        assert result.exit_code == 0
        data = parse_json_output(result.output)
        assert isinstance(data, list)
        assert len(data) > 0
        assert "code" in data[0]
        assert "name" in data[0]


# ============================================================
# period 命令
# ============================================================
class TestPeriod:
    def test_period_list(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir, year=2025)
        result = invoke(runner, ["period", "list"], isolated_data_dir)
        assert result.exit_code == 0
        assert "会计期间" in result.output

    def test_period_list_by_year(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir, year=2025)
        result = invoke(runner, [
            "period", "list", "--year", "2025"
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "2025" in result.output

    def test_period_close(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir, year=2025)
        result = invoke(runner, [
            "period", "close", "2025-01"
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "已结账" in result.output

    def test_period_init_year(self, isolated_data_dir):
        runner = CliRunner()
        init_company(runner, isolated_data_dir, year=2025)
        result = invoke(runner, [
            "period", "init-year", "2026"
        ], isolated_data_dir)
        assert result.exit_code == 0
        assert "2026" in result.output
