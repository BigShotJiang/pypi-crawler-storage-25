"""finance-tax: 中国企业记账报税技能包"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("finance-tax")
except PackageNotFoundError:
    __version__ = "0.1.0"
