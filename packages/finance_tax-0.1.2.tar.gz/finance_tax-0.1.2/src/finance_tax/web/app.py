"""FastAPI Web 应用 — 记账报税数据看板"""

from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, Depends, Query, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import func

from finance_tax.config import AppConfig, load_config
from finance_tax.database import init_db, get_session as _get_session
from finance_tax import __version__

# ---------------------------------------------------------------------------
# App & Config
# ---------------------------------------------------------------------------
_config: AppConfig | None = None
STATIC_DIR = Path(__file__).parent / "static"


def create_app(data_dir: Path | None = None) -> FastAPI:
    global _config
    _config = load_config(data_dir)
    init_db(_config)

    app = FastAPI(title="finance-tax", version="0.1.0")

    # --- dependency ---
    def get_db():
        with _get_session(_config) as session:
            yield session

    def get_company_id():
        if not _config or not _config.current_company_id:
            raise HTTPException(503, "尚未初始化账套，请先运行 ft init")
        return _config.current_company_id

    # --- helpers ---
    def _dec(v) -> float:
        return float(v) if v else 0.0

    # ===================================================================
    # Dashboard
    # ===================================================================
    @app.get("/api/dashboard")
    def dashboard(db: Session = Depends(get_db), cid: int = Depends(get_company_id)):
        from finance_tax.models.company import Company
        from finance_tax.models.voucher import Voucher
        from finance_tax.models.transaction import BankTransaction
        from finance_tax.models.invoice import Invoice
        from finance_tax.models.period import FiscalPeriod
        from finance_tax.models.account import Account

        company = db.query(Company).filter_by(id=cid).first()
        if not company:
            raise HTTPException(404, "公司不存在")

        voucher_count = db.query(Voucher).filter_by(company_id=cid).count()
        voucher_posted = db.query(Voucher).filter_by(company_id=cid, status="posted").count()
        txn_count = db.query(BankTransaction).filter_by(company_id=cid).count()
        txn_unprocessed = db.query(BankTransaction).filter_by(company_id=cid, is_processed=False).count()
        inv_count = db.query(Invoice).filter_by(company_id=cid).count()
        account_count = db.query(Account).filter_by(company_id=cid).count()

        current_period = (
            db.query(FiscalPeriod)
            .filter_by(company_id=cid, status="open")
            .order_by(FiscalPeriod.period)
            .first()
        )

        # 月度收支汇总 (最近12个月)
        monthly = (
            db.query(
                func.strftime("%Y-%m", BankTransaction.trans_date).label("month"),
                func.sum(BankTransaction.debit_amount).label("total_debit"),
                func.sum(BankTransaction.credit_amount).label("total_credit"),
            )
            .filter_by(company_id=cid)
            .group_by("month")
            .order_by("month")
            .limit(12)
            .all()
        )

        return {
            "version": __version__,
            "company": {
                "name": company.name,
                "tax_id": company.tax_id or "",
                "taxpayer_type": company.taxpayer_type,
                "accounting_standard": company.accounting_standard,
                "industry": company.industry or "",
            },
            "stats": {
                "voucher_count": voucher_count,
                "voucher_posted": voucher_posted,
                "txn_count": txn_count,
                "txn_unprocessed": txn_unprocessed,
                "invoice_count": inv_count,
                "account_count": account_count,
                "current_period": current_period.period if current_period else "-",
            },
            "monthly_cashflow": [
                {"month": m.month, "debit": _dec(m.total_debit), "credit": _dec(m.total_credit)}
                for m in monthly
            ],
        }

    # ===================================================================
    # Bank Transactions
    # ===================================================================
    @app.get("/api/bank/transactions")
    def list_transactions(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        page: int = Query(1, ge=1),
        size: int = Query(20, ge=1, le=200),
        keyword: str = Query("", description="搜索摘要/对方户名"),
        unprocessed: bool = Query(False),
    ):
        from finance_tax.models.transaction import BankTransaction
        q = db.query(BankTransaction).filter_by(company_id=cid)
        if unprocessed:
            q = q.filter_by(is_processed=False)
        if keyword:
            like = f"%{keyword}%"
            q = q.filter(
                BankTransaction.summary.ilike(like)
                | BankTransaction.counterparty.ilike(like)
            )
        total = q.count()
        items = q.order_by(BankTransaction.trans_date.desc()).offset((page - 1) * size).limit(size).all()

        # 批量查询附件数量
        from finance_tax.models.attachment import Attachment as AttModel
        item_ids = [t.id for t in items]
        att_counts: dict[int, int] = {}
        if item_ids:
            att_counts = dict(
                db.query(AttModel.entity_id, func.count(AttModel.id))
                .filter(
                    AttModel.company_id == cid,
                    AttModel.entity_type == "bank_transaction",
                    AttModel.entity_id.in_(item_ids),
                )
                .group_by(AttModel.entity_id)
                .all()
            )

        return {
            "total": total, "page": page, "size": size,
            "items": [
                {
                    "id": t.id,
                    "date": t.trans_date.isoformat(),
                    "bank_name": t.bank_name or "",
                    "account_number": t.account_number or "",
                    "debit": _dec(t.debit_amount),
                    "credit": _dec(t.credit_amount),
                    "balance": _dec(t.balance),
                    "summary": t.summary or "",
                    "counterparty": t.counterparty or "",
                    "counterparty_bank": t.counterparty_bank or "",
                    "reference_no": t.reference_no or "",
                    "processed": t.is_processed,
                    "attachment_count": att_counts.get(t.id, 0),
                }
                for t in items
            ],
        }

    # ===================================================================
    # Invoices
    # ===================================================================
    @app.get("/api/invoices")
    def list_invoices(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        page: int = Query(1, ge=1),
        size: int = Query(20, ge=1, le=200),
        direction: str = Query("all", description="input/output/all"),
        keyword: str = Query(""),
    ):
        from finance_tax.models.invoice import Invoice
        q = db.query(Invoice).filter_by(company_id=cid)
        if direction != "all":
            q = q.filter_by(direction=direction)
        if keyword:
            like = f"%{keyword}%"
            q = q.filter(
                Invoice.invoice_number.ilike(like)
                | Invoice.seller_name.ilike(like)
                | Invoice.buyer_name.ilike(like)
            )
        total = q.count()
        items = q.order_by(Invoice.invoice_date.desc()).offset((page - 1) * size).limit(size).all()

        # 批量查询附件数量
        from finance_tax.models.attachment import Attachment as AttModel
        item_ids = [i.id for i in items]
        att_counts: dict[int, int] = {}
        if item_ids:
            att_counts = dict(
                db.query(AttModel.entity_id, func.count(AttModel.id))
                .filter(
                    AttModel.company_id == cid,
                    AttModel.entity_type == "invoice",
                    AttModel.entity_id.in_(item_ids),
                )
                .group_by(AttModel.entity_id)
                .all()
            )

        return {
            "total": total, "page": page, "size": size,
            "items": [
                {
                    "id": i.id,
                    "date": i.invoice_date.isoformat() if i.invoice_date else "",
                    "number": i.invoice_number or "",
                    "type": i.invoice_type or "",
                    "direction": i.direction,
                    "amount": _dec(i.amount),
                    "tax_amount": _dec(i.tax_amount),
                    "total_amount": _dec(i.total_amount),
                    "seller": i.seller_name or "",
                    "buyer": i.buyer_name or "",
                    "processed": i.is_processed,
                    "attachment_count": att_counts.get(i.id, 0),
                }
                for i in items
            ],
        }

    # ===================================================================
    # Vouchers
    # ===================================================================
    @app.get("/api/vouchers")
    def list_vouchers(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        page: int = Query(1, ge=1),
        size: int = Query(20, ge=1, le=200),
        period: str = Query("", description="期间 YYYY-MM"),
        status: str = Query("", description="draft/posted/void"),
    ):
        from finance_tax.models.voucher import Voucher, VoucherEntry
        q = db.query(Voucher).filter_by(company_id=cid)
        if period:
            q = q.filter_by(period=period)
        if status:
            q = q.filter_by(status=status)
        total = q.count()
        vouchers = q.order_by(Voucher.voucher_date.desc(), Voucher.id.desc()).offset((page - 1) * size).limit(size).all()

        # 批量查询附件数量
        from finance_tax.models.attachment import Attachment as AttModel
        voucher_ids = [v.id for v in vouchers]
        att_counts: dict[int, int] = {}
        if voucher_ids:
            att_counts = dict(
                db.query(AttModel.entity_id, func.count(AttModel.id))
                .filter(
                    AttModel.company_id == cid,
                    AttModel.entity_type == "voucher",
                    AttModel.entity_id.in_(voucher_ids),
                )
                .group_by(AttModel.entity_id)
                .all()
            )

        result = []
        for v in vouchers:
            entries = db.query(VoucherEntry).filter_by(voucher_id=v.id).all()
            result.append({
                "id": v.id,
                "number": f"{v.voucher_type}-{v.voucher_number:04d}",
                "date": v.voucher_date.isoformat(),
                "period": v.period,
                "description": v.memo or "",
                "total_debit": _dec(v.total_debit),
                "total_credit": _dec(v.total_credit),
                "source": v.source or "",
                "status": v.status,
                "attachment_count": att_counts.get(v.id, 0),
                "entries": [
                    {
                        "account_code": e.account_code,
                        "account_name": e.account_name or "",
                        "description": e.summary or "",
                        "debit": _dec(e.debit_amount),
                        "credit": _dec(e.credit_amount),
                    }
                    for e in entries
                ],
            })
        return {"total": total, "page": page, "size": size, "items": result}

    # ===================================================================
    # Accounts
    # ===================================================================
    @app.get("/api/accounts")
    def list_accounts(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        keyword: str = Query(""),
        category: str = Query(""),
        level: Optional[int] = Query(None),
    ):
        from finance_tax.models.account import Account
        q = db.query(Account).filter_by(company_id=cid)
        if keyword:
            like = f"%{keyword}%"
            q = q.filter(Account.name.ilike(like) | Account.code.ilike(like))
        if category:
            q = q.filter_by(category=category)
        if level is not None:
            q = q.filter_by(level=level)
        accounts = q.order_by(Account.code).all()
        return [
            {
                "code": a.code,
                "name": a.name,
                "category": a.category,
                "direction": a.balance_direction,
                "level": a.level,
            }
            for a in accounts
        ]

    # ===================================================================
    # Periods
    # ===================================================================
    @app.get("/api/periods")
    def list_periods(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        year: Optional[int] = Query(None),
    ):
        from finance_tax.models.period import FiscalPeriod
        q = db.query(FiscalPeriod).filter_by(company_id=cid)
        if year:
            q = q.filter_by(year=year)
        periods = q.order_by(FiscalPeriod.period).all()
        return [
            {
                "period": p.period,
                "year": p.year,
                "month": p.month,
                "start_date": p.start_date.isoformat(),
                "end_date": p.end_date.isoformat(),
                "status": p.status,
            }
            for p in periods
        ]

    # ===================================================================
    # Reports
    # ===================================================================
    @app.get("/api/reports/trial-balance")
    def report_trial_balance(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        period: str = Query(..., description="期间 YYYY-MM"),
        start: str = Query("", description="起始期间"),
        level: Optional[int] = Query(None),
    ):
        from finance_tax.reporting.trial_balance import TrialBalanceReport
        rpt = TrialBalanceReport(db, cid)
        if start and start != period:
            return rpt.generate(period_start=start, period_end=period, level=level)
        return rpt.generate(period=period, level=level)

    @app.get("/api/reports/balance-sheet")
    def report_balance_sheet(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        period: str = Query(..., description="期间 YYYY-MM"),
    ):
        from finance_tax.reporting.balance_sheet import BalanceSheetReport
        rpt = BalanceSheetReport(db, cid)
        return rpt.generate(period)

    @app.get("/api/reports/income")
    def report_income(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        period: str = Query(..., description="截止期间 YYYY-MM"),
        start: str = Query("", description="起始期间"),
    ):
        from finance_tax.reporting.income_statement import IncomeStatementReport
        rpt = IncomeStatementReport(db, cid)
        return rpt.generate(period, start or None)

    @app.get("/api/reports/cashflow")
    def report_cashflow(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        period: str = Query(..., description="截止期间 YYYY-MM"),
        start: str = Query("", description="起始期间"),
    ):
        from finance_tax.reporting.cashflow import CashFlowReport
        rpt = CashFlowReport(db, cid)
        return rpt.generate(period, start or None)

    # ===================================================================
    # Attachments
    # ===================================================================
    @app.get("/api/attachments")
    def list_attachments(
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
        entity_type: str = Query(..., description="invoice/bank_transaction/voucher"),
        entity_id: int = Query(..., description="关联对象ID"),
    ):
        from finance_tax.models.attachment import Attachment
        items = (
            db.query(Attachment)
            .filter_by(company_id=cid, entity_type=entity_type, entity_id=entity_id)
            .order_by(Attachment.id)
            .all()
        )
        return [
            {
                "id": a.id,
                "file_name": a.file_name,
                "file_size": a.file_size,
                "mime_type": a.mime_type,
                "category": a.category,
                "memo": a.memo or "",
            }
            for a in items
        ]

    @app.get("/api/attachments/{attachment_id}/file")
    def get_attachment_file(
        attachment_id: int,
        db: Session = Depends(get_db),
        cid: int = Depends(get_company_id),
    ):
        from finance_tax.models.attachment import Attachment
        att = (
            db.query(Attachment)
            .filter_by(id=attachment_id, company_id=cid)
            .first()
        )
        if not att:
            raise HTTPException(404, "附件不存在")

        att_root = (_config.data_dir / "attachments").resolve()
        file_path = (att_root / att.file_path).resolve()

        # 安全检查：确保路径在 attachments 目录内
        if not str(file_path).startswith(str(att_root)):
            raise HTTPException(403, "非法文件路径")
        if not file_path.exists():
            raise HTTPException(404, "附件文件不存在")

        return FileResponse(
            str(file_path),
            media_type=att.mime_type,
            filename=att.file_name,
        )

    # ===================================================================
    # Static files & SPA fallback
    # ===================================================================
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/{full_path:path}")
    def spa_fallback(full_path: str):
        """SPA fallback — 所有非API路径返回 index.html"""
        index = STATIC_DIR / "index.html"
        if not index.exists():
            raise HTTPException(404, "前端文件不存在")
        return FileResponse(str(index))

    return app
