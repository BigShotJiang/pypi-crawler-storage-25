/**
 * finance-tax Web Dashboard — 主应用入口
 *
 * 模块化架构:
 *   index.html  — 骨架 + 各视图 HTML 模板
 *   css/app.css — 全局样式
 *   js/app.js   — Vue 根实例，组装各视图 composable
 *   js/api.js   — 后端 API 请求封装
 *   js/utils.js — 格式化 / 工具函数
 *   js/views/*  — 各视图的状态逻辑 (composable)
 */
import { fmtMoney, categoryLabel, categoryBadge, fmtFileSize } from './utils.js';
import * as api from './api.js';
import { useDashboard } from './views/dashboard.js';
import { useBank } from './views/bank.js';
import { useInvoice } from './views/invoice.js';
import { useVoucher } from './views/voucher.js';
import { useAccount } from './views/account.js';
import { useReport, REPORT_TABS, buildRangeOptions } from './views/report.js';

const { createApp, ref, reactive, computed, watch, onMounted, onUnmounted } = Vue;

/** 侧边栏菜单定义 */
const MENU_ITEMS = [
  { key: 'dashboard', label: '数据概览', icon: '📊' },
  { key: 'bank',      label: '银行流水', icon: '🏦' },
  { key: 'invoice',   label: '发票管理', icon: '🧾' },
  { key: 'voucher',   label: '记账凭证', icon: '📋' },
  { key: 'account',   label: '会计科目', icon: '📒' },
  { key: 'report',    label: '财务报表', icon: '📈' },
  { key: 'period',    label: '会计期间', icon: '📅' },
];

const PAGE_SIZE = 20;

createApp({
  setup() {
    // ---- 导航 ----
    const currentView = ref('dashboard');
    const currentTitle = computed(
      () => MENU_ITEMS.find(m => m.key === currentView.value)?.label || ''
    );

    // ---- 各视图 composable（用 reactive 包装，确保嵌套 ref 在模板中自动解包） ----
    const dashboardCtx = useDashboard();
    const bank         = reactive(useBank(PAGE_SIZE));
    const invoice      = reactive(useInvoice(PAGE_SIZE));
    const voucher      = reactive(useVoucher(PAGE_SIZE));
    const account      = reactive(useAccount());
    const report       = reactive(useReport());

    // ---- 全局共享：会计期间 ----
    const periods = ref([]);
    async function loadPeriods() {
      periods.value = await api.fetchPeriods();
    }

    // ---- 视图切换 → 按需加载 ----
    watch(currentView, (v) => {
      const loaders = {
        dashboard: () => dashboardCtx.fetchData(),
        bank:      () => bank.fetch(),
        invoice:   () => invoice.fetch(),
        voucher:   () => { loadPeriods(); voucher.fetch(); },
        account:   () => account.fetch(),
        report:    () => { loadPeriods(); report.data = null; },
        period:    () => loadPeriods(),
      };
      loaders[v]?.();
    });

    // ---- 生命周期 ----
    onMounted(() => {
      dashboardCtx.fetchData();
      loadPeriods();
      window.addEventListener('resize', dashboardCtx.handleResize);
    });
    onUnmounted(() => {
      window.removeEventListener('resize', dashboardCtx.handleResize);
    });

    // ---- 附件展开/折叠 ----
    async function toggleAttachments(entityType, item) {
      item._open = !item._open;
      if (item._open && item._attachments === null) {
        item._attachments = await api.fetchAttachments(entityType, item.id);
      }
    }

    // ---- 报表：期间范围选项 ----
    const reportRangeOptions = computed(() =>
      buildRangeOptions(periods.value, report.rangeMode)
    );

    function onReportRangeChange(val) {
      report.rangeValue = val;
      const opt = reportRangeOptions.value.find(o => o.value === val);
      if (opt) {
        report.period = opt.end;    // period 传的是截止月份
        report._start = opt.start;  // 记住起始月份
      }
      report.fetch();
    }

    function onReportModeChange(mode) {
      report.rangeMode = mode;
      report.rangeValue = '';
      report.period = '';
      report.data = null;
    }

    // ---- 暴露给模板 ----
    return {
      menuItems: MENU_ITEMS,
      currentView,
      currentTitle,
      // 各视图 composable 对象
      dashboard: dashboardCtx.dashboard,
      bank,
      invoice,
      voucher,
      account,
      report,
      // 共享
      periods,
      reportTabs: REPORT_TABS,
      reportRangeOptions,
      pageSize: PAGE_SIZE,
      // 模板工具函数
      fmtMoney,
      fmtFileSize,
      categoryLabel,
      categoryBadge,
      toggleAttachments,
      attachmentFileUrl: api.attachmentFileUrl,
      onReportRangeChange,
      onReportModeChange,
    };
  },
}).mount('#app');
