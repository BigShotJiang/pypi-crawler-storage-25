/**
 * finance-tax Web Dashboard — API 请求封装
 */

const BASE = '';

async function request(url, params = {}) {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v != null && v !== '') qs.set(k, v);
  }
  const fullUrl = qs.toString() ? `${BASE}${url}?${qs}` : `${BASE}${url}`;
  const res = await fetch(fullUrl);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }
  return res.json();
}

/** Dashboard */
export function fetchDashboard() {
  return request('/api/dashboard');
}

/** 银行流水 */
export function fetchBankTransactions({ page = 1, size = 20, keyword = '', unprocessed = false } = {}) {
  const params = { page, size, keyword };
  if (unprocessed) params.unprocessed = 'true';
  return request('/api/bank/transactions', params);
}

/** 发票 */
export function fetchInvoices({ page = 1, size = 20, keyword = '', direction = 'all' } = {}) {
  return request('/api/invoices', { page, size, keyword, direction });
}

/** 凭证 */
export function fetchVouchers({ page = 1, size = 20, period = '', status = '' } = {}) {
  return request('/api/vouchers', { page, size, period, status });
}

/** 会计科目 */
export function fetchAccounts({ keyword = '', category = '', level = null } = {}) {
  const params = { keyword, category };
  if (level != null) params.level = level;
  return request('/api/accounts', params);
}

/** 会计期间 */
export function fetchPeriods({ year = null } = {}) {
  const params = {};
  if (year) params.year = year;
  return request('/api/periods', params);
}

/** 报表 */
export function fetchReport(type, { period, start = '' } = {}) {
  const urlMap = {
    trial: '/api/reports/trial-balance',
    'balance-sheet': '/api/reports/balance-sheet',
    income: '/api/reports/income',
    cashflow: '/api/reports/cashflow',
  };
  return request(urlMap[type] || urlMap.trial, { period, start });
}

/** 附件列表 */
export function fetchAttachments(entityType, entityId) {
  return request('/api/attachments', { entity_type: entityType, entity_id: entityId });
}

/** 附件文件URL */
export function attachmentFileUrl(id) {
  return `/api/attachments/${id}/file`;
}
