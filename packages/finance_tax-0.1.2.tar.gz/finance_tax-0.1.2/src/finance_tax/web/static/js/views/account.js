/**
 * 会计科目视图模块
 */
import * as api from '../api.js';
import { debounce } from '../utils.js';

export function useAccount() {
  const { ref } = Vue;

  const items = ref([]);
  const keyword = ref('');
  const category = ref('');
  const level = ref(null);

  async function fetch_() {
    items.value = await api.fetchAccounts({
      keyword: keyword.value,
      category: category.value,
      level: level.value,
    });
  }

  const debouncedFetch = debounce(fetch_);

  return { items, keyword, category, level, fetch: fetch_, debouncedFetch };
}
