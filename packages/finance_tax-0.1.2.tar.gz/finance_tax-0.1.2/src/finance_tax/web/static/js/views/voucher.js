/**
 * 凭证管理视图模块
 */
import * as api from '../api.js';

export function useVoucher(pageSize) {
  const { ref } = Vue;

  const data = ref({ total: 0, items: [] });
  const page = ref(1);
  const period = ref('');
  const status = ref('');

  async function fetch_() {
    const raw = await api.fetchVouchers({
      page: page.value, size: pageSize,
      period: period.value, status: status.value,
    });
    raw.items.forEach(v => { v._open = false; v._attachments = null; });
    data.value = raw;
  }

  return { data, page, period, status, fetch: fetch_ };
}
