/**
 * 银行流水视图模块
 */
import * as api from '../api.js';
import { debounce } from '../utils.js';

export function useBank(pageSize) {
  const { ref } = Vue;

  const data = ref({ total: 0, items: [] });
  const page = ref(1);
  const keyword = ref('');
  const unprocessed = ref(false);

  async function fetch_() {
    const raw = await api.fetchBankTransactions({
      page: page.value, size: pageSize,
      keyword: keyword.value,
      unprocessed: unprocessed.value,
    });
    raw.items.forEach(t => { t._open = false; t._attachments = null; });
    data.value = raw;
  }

  const debouncedFetch = debounce(() => { page.value = 1; fetch_(); });

  return { data, page, keyword, unprocessed, fetch: fetch_, debouncedFetch };
}
