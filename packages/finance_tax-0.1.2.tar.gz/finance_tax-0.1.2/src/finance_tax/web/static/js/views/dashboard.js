/**
 * Dashboard 视图模块
 */
import * as api from '../api.js';

export function useDashboard() {
  const { ref, nextTick } = Vue;

  const dashboard = ref(null);
  let chartInstance = null;

  async function fetchData() {
    try {
      dashboard.value = await api.fetchDashboard();
      await nextTick();
      renderChart();
    } catch (e) {
      console.error('Dashboard fetch error:', e);
    }
  }

  function renderChart() {
    const el = document.getElementById('cashflow-chart');
    if (!el || !dashboard.value?.monthly_cashflow?.length) return;

    if (chartInstance) chartInstance.dispose();
    chartInstance = echarts.init(el);

    const data = dashboard.value.monthly_cashflow;
    chartInstance.setOption({
      tooltip: { trigger: 'axis' },
      legend: { data: ['收入', '支出'], top: 0, textStyle: { fontSize: 12 } },
      grid: { top: 30, bottom: 20, left: 50, right: 20 },
      xAxis: {
        type: 'category',
        data: data.map(d => d.month),
        axisLabel: { fontSize: 11 },
      },
      yAxis: { type: 'value', axisLabel: { fontSize: 11 } },
      series: [
        {
          name: '收入', type: 'bar',
          data: data.map(d => d.credit),
          itemStyle: { color: '#10b981', borderRadius: [4, 4, 0, 0] },
        },
        {
          name: '支出', type: 'bar',
          data: data.map(d => d.debit),
          itemStyle: { color: '#f43f5e', borderRadius: [4, 4, 0, 0] },
        },
      ],
    });
  }

  function handleResize() {
    if (chartInstance) chartInstance.resize();
  }

  return { dashboard, fetchData, handleResize };
}
