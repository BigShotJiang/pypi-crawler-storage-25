/**
 * 发票管理视图模块
 */
import * as api from '../api.js';
import { debounce } from '../utils.js';

export function useInvoice(pageSize) {
  const { ref } = Vue;

  const data = ref({ total: 0, items: [] });
  const page = ref(1);
  const keyword = ref('');
  const direction = ref('all');

  async function fetch_() {
    const raw = await api.fetchInvoices({
      page: page.value, size: pageSize,
      keyword: keyword.value,
      direction: direction.value,
    });
    raw.items.forEach(i => { i._open = false; i._attachments = null; });
    data.value = raw;
  }

  const debouncedFetch = debounce(() => { page.value = 1; fetch_(); });

  return { data, page, keyword, direction, fetch: fetch_, debouncedFetch };
}
