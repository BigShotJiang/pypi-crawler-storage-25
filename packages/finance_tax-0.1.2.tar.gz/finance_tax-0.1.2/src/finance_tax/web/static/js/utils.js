/**
 * finance-tax Web Dashboard — 工具函数
 */

/**
 * 格式化金额显示
 * @param {number} v - 金额
 * @returns {string}
 */
export function fmtMoney(v) {
  if (v == null || v === 0) return '-';
  return Number(v).toLocaleString('zh-CN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/** 科目分类中文映射 */
const CATEGORY_LABELS = {
  asset: '资产',
  liability: '负债',
  equity: '权益',
  revenue: '收入',
  cost: '成本',
  expense: '费用',
};

/** 科目分类 badge 样式 */
const CATEGORY_BADGES = {
  asset: 'badge-blue',
  liability: 'badge-red',
  equity: 'badge-green',
  revenue: 'badge-green',
  cost: 'badge-yellow',
  expense: 'badge-yellow',
};

export function categoryLabel(c) {
  return CATEGORY_LABELS[c] || c;
}

export function categoryBadge(c) {
  return CATEGORY_BADGES[c] || 'badge-gray';
}

/**
 * 创建防抖函数
 * @param {Function} fn
 * @param {number} ms
 * @returns {Function}
 */
export function debounce(fn, ms = 300) {
  let timer = null;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), ms);
  };
}

/**
 * 格式化文件大小
 * @param {number} bytes
 * @returns {string}
 */
export function fmtFileSize(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let size = bytes;
  while (size >= 1024 && i < units.length - 1) { size /= 1024; i++; }
  return size.toFixed(i > 0 ? 1 : 0) + ' ' + units[i];
}
