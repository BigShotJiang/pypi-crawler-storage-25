/**
 * 财务报表视图模块
 */
import * as api from '../api.js';

export const REPORT_TABS = [
  { key: 'trial', label: '科目余额表' },
  { key: 'balance-sheet', label: '资产负债表' },
  { key: 'income', label: '利润表' },
  { key: 'cashflow', label: '现金流量表' },
];

/**
 * 根据 periods 列表和 rangeMode 生成可选范围列表
 * @param {Array} periods - [{period:'2025-01', year:2025, month:1}, ...]
 * @param {string} mode - 'month' | 'quarter' | 'year'
 * @returns {Array} [{label, value, start, end}]
 */
export function buildRangeOptions(periods, mode) {
  if (!periods || !periods.length) return [];

  if (mode === 'month') {
    return periods.map(p => ({
      label: p.period,
      value: p.period,
      start: p.period,
      end: p.period,
    }));
  }

  if (mode === 'quarter') {
    const map = new Map();
    for (const p of periods) {
      const q = Math.ceil(p.month / 3);
      const key = `${p.year}-Q${q}`;
      if (!map.has(key)) {
        map.set(key, { label: `${p.year}年第${q}季度`, value: key, start: p.period, end: p.period, year: p.year, q });
      } else {
        const entry = map.get(key);
        if (p.period < entry.start) entry.start = p.period;
        if (p.period > entry.end) entry.end = p.period;
      }
    }
    return [...map.values()];
  }

  if (mode === 'year') {
    const map = new Map();
    for (const p of periods) {
      const key = `${p.year}`;
      if (!map.has(key)) {
        map.set(key, { label: `${p.year}年度`, value: key, start: p.period, end: p.period });
      } else {
        const entry = map.get(key);
        if (p.period < entry.start) entry.start = p.period;
        if (p.period > entry.end) entry.end = p.period;
      }
    }
    return [...map.values()];
  }

  return [];
}

export function useReport() {
  const { ref } = Vue;

  const tab = ref('trial');
  const period = ref('');
  const rangeMode = ref('month');
  const rangeValue = ref('');
  const data = ref(null);
  const _start = ref('');

  async function fetch_() {
    if (!period.value) { data.value = null; return; }

    // 季度/年度模式下传 start 参数（聚合多月数据）
    let start = '';
    if (rangeMode.value !== 'month') {
      start = _start.value || '';
    }

    try {
      data.value = await api.fetchReport(tab.value, { period: period.value, start });
    } catch {
      data.value = null;
    }
  }

  return { tab, period, rangeMode, rangeValue, data, _start, fetch: fetch_ };
}
