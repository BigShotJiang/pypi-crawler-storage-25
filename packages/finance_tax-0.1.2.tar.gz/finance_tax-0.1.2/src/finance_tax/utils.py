"""公共工具函数"""

from pathlib import Path

# 技能包根目录（始终指向项目根，兼容 uv run 和直接安装两种场景）
_SKILL_ROOT: Path | None = None


def get_skill_root() -> Path:
    """获取技能包根目录

    优先级:
    1. 手动设置的路径
    2. 环境变量 FINANCE_TAX_ROOT
    3. 从源码路径推算（开发模式）
    """
    global _SKILL_ROOT
    if _SKILL_ROOT:
        return _SKILL_ROOT

    import os
    env_root = os.environ.get("FINANCE_TAX_ROOT")
    if env_root:
        _SKILL_ROOT = Path(env_root)
        return _SKILL_ROOT

    # 从当前文件推算: src/finance_tax/utils.py → 向上3级到项目根
    _SKILL_ROOT = Path(__file__).resolve().parent.parent.parent
    return _SKILL_ROOT


def get_data_dir() -> Path:
    """获取 data/ 目录路径"""
    return get_skill_root() / "data"


def set_skill_root(path: Path) -> None:
    """手动设置技能包根目录"""
    global _SKILL_ROOT
    _SKILL_ROOT = path


def json_safe(obj):
    """递归将 dict/list 中的 Decimal/date 转为 JSON 安全类型"""
    from datetime import date, datetime
    from decimal import Decimal

    if isinstance(obj, dict):
        return {k: json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(v) for v in obj]
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    return obj
