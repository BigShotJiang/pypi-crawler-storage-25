"""凭证引擎 - 自动生成记账凭证"""

from datetime import date
from decimal import Decimal
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from finance_tax.models.voucher import Voucher, VoucherEntry
from finance_tax.models.transaction import BankTransaction
from finance_tax.models.invoice import Invoice
from finance_tax.accounting.chart_of_accounts import ChartOfAccountsManager


# 银行流水摘要→科目映射规则
# 使用科目名称匹配（而非编码），自动兼容小企业/企业两种会计准则
BANK_KEYWORD_RULES: list[dict[str, Any]] = [
    # 收入类
    {"keywords": ["销售", "货款", "服务费收入", "收到货款"], "account_name": "主营业务收入", "type": "income", "summary_prefix": "收到"},
    {"keywords": ["利息收入", "结息", "利息"], "account_name": "利息收入", "type": "interest_income", "summary_prefix": "收到银行利息"},

    # 费用类 - 管理费用
    {"keywords": ["房租", "租金", "租赁"], "account_name": "租赁费", "type": "expense", "summary_prefix": "支付"},
    {"keywords": ["办公用品", "办公费", "文具"], "account_name": "办公费", "type": "expense", "summary_prefix": "支付"},
    {"keywords": ["差旅", "出差", "住宿", "机票", "火车票"], "account_name": "差旅费", "type": "expense", "summary_prefix": "支付"},
    {"keywords": ["餐费", "招待", "聚餐"], "account_name": "业务招待费", "type": "expense", "summary_prefix": "支付"},
    {"keywords": ["水电", "电费", "水费"], "account_name": "水电费", "type": "expense", "summary_prefix": "支付"},
    {"keywords": ["电话", "通讯", "话费", "网费"], "account_name": "通讯费", "type": "expense", "summary_prefix": "支付"},
    {"keywords": ["打车", "加油", "停车", "交通"], "account_name": "交通费", "type": "expense", "summary_prefix": "支付"},
    {"keywords": ["咨询", "顾问", "服务费", "代理费"], "account_name": "咨询服务费", "type": "expense", "summary_prefix": "支付"},
    {"keywords": ["工资", "薪酬", "薪资"], "account_name": "工资", "parent_hint": "管理费用", "type": "salary", "summary_prefix": "支付"},
    {"keywords": ["社保", "公积金", "五险一金"], "account_name": "社保公积金", "type": "social_insurance", "summary_prefix": "支付"},

    # 费用类 - 财务费用
    {"keywords": ["手续费", "转账手续费", "汇款手续费"], "account_name": "手续费", "type": "expense", "summary_prefix": "支付"},

    # 费用类 - 销售费用
    {"keywords": ["快递", "物流", "运费", "邮寄"], "account_name": "运输费", "type": "expense", "summary_prefix": "支付"},
    {"keywords": ["广告", "推广", "宣传"], "account_name": "广告宣传费", "type": "expense", "summary_prefix": "支付"},

    # 税费类
    {"keywords": ["税款", "缴税", "税费", "增值税", "所得税", "印花税"], "account_name": "应交税费", "type": "tax_payment", "summary_prefix": "缴纳"},
]


class VoucherEngine:
    """凭证引擎"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id
        self.coa = ChartOfAccountsManager(session, company_id)
        # 预加载常用科目（编码在两种准则中相同）
        self._common_accounts: dict[str, tuple[str, str]] = {}  # name -> (code, name)
        for name in ("银行存款", "应收账款", "应付账款", "应交增值税", "应交税费"):
            acc = self._find_account_by_name(name)
            if acc:
                self._common_accounts[name] = (acc.code, acc.name)

    def _resolve(self, name: str) -> tuple[str, str]:
        """获取常用科目的 (code, name)，优先用缓存"""
        if name in self._common_accounts:
            return self._common_accounts[name]
        acc = self._find_account_by_name(name)
        if acc:
            self._common_accounts[name] = (acc.code, acc.name)
            return (acc.code, acc.name)
        raise ValueError(f"找不到科目: {name}")

    def _next_voucher_number(self, period: str, voucher_type: str = "记") -> int:
        """获取指定期间下一个凭证号"""
        max_num = (
            self.session.query(func.max(Voucher.voucher_number))
            .filter_by(
                company_id=self.company_id,
                period=period,
                voucher_type=voucher_type,
            )
            .scalar()
        )
        return (max_num or 0) + 1

    def _find_account_by_name(self, name: str, parent_hint: str = "") -> Any | None:
        """按名称从数据库查找科目（兼容两种会计准则）"""
        from finance_tax.models.account import Account
        query = (
            self.session.query(Account)
            .filter_by(company_id=self.company_id, name=name, is_active=True)
        )
        results = query.all()
        if len(results) == 1:
            return results[0]
        if len(results) > 1 and parent_hint:
            # 如果同名科目多个，按父科目名称筛选
            for acc in results:
                parent = self.coa.get_account_by_code(acc.parent_code) if acc.parent_code else None
                if parent and parent_hint in parent.name:
                    return acc
            return results[0]
        if results:
            return results[0]
        return None

    def match_account_for_transaction(self, transaction: BankTransaction) -> dict[str, Any] | None:
        """根据银行流水摘要匹配会计科目"""
        summary = (transaction.summary or "") + " " + (transaction.memo or "")

        for rule in BANK_KEYWORD_RULES:
            for keyword in rule["keywords"]:
                if keyword in summary:
                    account = self._find_account_by_name(
                        rule["account_name"],
                        parent_hint=rule.get("parent_hint", ""),
                    )
                    if account:
                        return {
                            "account_code": account.code,
                            "account_name": account.name,
                            "type": rule["type"],
                            "summary_prefix": rule["summary_prefix"],
                        }
        return None

    def suggest_accounts_for_transaction(self, transaction: BankTransaction) -> list[dict[str, Any]]:
        """为银行流水生成科目建议列表（供 Agent 审核参考）

        返回所有匹配的规则建议，按匹配质量排序。
        每条建议包含: debit/credit 科目、置信度、匹配原因。
        """
        summary = (transaction.summary or "") + " " + (transaction.memo or "")
        is_income = transaction.credit_amount > 0

        suggestions: list[dict[str, Any]] = []
        seen_accounts: set[str] = set()

        bank_code, bank_name = self._resolve("银行存款")

        for rule in BANK_KEYWORD_RULES:
            matched_keywords = [kw for kw in rule["keywords"] if kw in summary]
            if not matched_keywords:
                continue

            account = self._find_account_by_name(
                rule["account_name"],
                parent_hint=rule.get("parent_hint", ""),
            )
            if not account or account.code in seen_accounts:
                continue
            seen_accounts.add(account.code)

            # 置信度: 匹配关键词越多越高，匹配越精确越高
            keyword_score = min(len(matched_keywords) * 0.3, 0.6)
            exact_score = 0.2 if any(kw == summary.strip() for kw in matched_keywords) else 0.0
            confidence = round(min(keyword_score + exact_score + 0.2, 1.0), 2)

            if is_income:
                debit_code, debit_name = bank_code, bank_name
                credit_code, credit_name = account.code, account.name
            else:
                debit_code, debit_name = account.code, account.name
                credit_code, credit_name = bank_code, bank_name

            suggestions.append({
                "debit_account_code": debit_code,
                "debit_account_name": debit_name,
                "credit_account_code": credit_code,
                "credit_account_name": credit_name,
                "confidence": confidence,
                "reason": f"关键词匹配: {', '.join(matched_keywords)}",
            })

        suggestions.sort(key=lambda s: s["confidence"], reverse=True)
        return suggestions

    def create_voucher_from_transaction(
        self,
        transaction: BankTransaction,
        account_code: str | None = None,
        account_name: str | None = None,
        summary: str | None = None,
    ) -> Voucher:
        """从银行流水创建凭证"""
        period = transaction.trans_date.strftime("%Y-%m")

        # 自动匹配科目
        if not account_code:
            match = self.match_account_for_transaction(transaction)
            if match:
                account_code = match["account_code"]
                account_name = match["account_name"]
                if not summary:
                    summary = f"{match['summary_prefix']}{transaction.summary or ''}"
            else:
                raise ValueError(
                    f"无法自动匹配科目，请手动指定。流水摘要: {transaction.summary}"
                )

        if not account_name:
            acc = self.coa.get_account_by_code(account_code)
            account_name = acc.name if acc else account_code

        if not summary:
            summary = transaction.summary or "银行流水"

        voucher = Voucher(
            company_id=self.company_id,
            voucher_type="记",
            voucher_number=self._next_voucher_number(period),
            voucher_date=transaction.trans_date,
            period=period,
            source="bank_import",
            source_ref=transaction.reference_no or f"bank_{transaction.id}",
            status="draft",
        )
        self.session.add(voucher)
        self.session.flush()

        entries = []
        is_income = transaction.credit_amount > 0
        amount = transaction.credit_amount if is_income else transaction.debit_amount

        bank_code, bank_name = self._resolve("银行存款")

        if is_income:
            # 收入: 借 银行存款, 贷 对应科目
            entries.append(VoucherEntry(
                voucher_id=voucher.id, seq=1,
                account_code=bank_code, account_name=bank_name,
                summary=summary,
                debit_amount=amount, credit_amount=Decimal("0.00"),
            ))
            entries.append(VoucherEntry(
                voucher_id=voucher.id, seq=2,
                account_code=account_code, account_name=account_name,
                summary=summary,
                debit_amount=Decimal("0.00"), credit_amount=amount,
            ))
        else:
            # 支出: 借 对应科目, 贷 银行存款
            entries.append(VoucherEntry(
                voucher_id=voucher.id, seq=1,
                account_code=account_code, account_name=account_name,
                summary=summary,
                debit_amount=amount, credit_amount=Decimal("0.00"),
            ))
            entries.append(VoucherEntry(
                voucher_id=voucher.id, seq=2,
                account_code=bank_code, account_name=bank_name,
                summary=summary,
                debit_amount=Decimal("0.00"), credit_amount=amount,
            ))

        for entry in entries:
            self.session.add(entry)

        # 更新流水状态
        transaction.is_processed = True
        transaction.voucher_id = voucher.id
        transaction.matched_account_code = account_code

        self.session.flush()
        return voucher

    def suggest_accounts_for_invoice(self, invoice: Invoice) -> list[dict[str, Any]]:
        """为发票推荐费用/收入科目（供 Agent 审核参考）

        根据发票的费用类别、货物名称、备注等信息匹配科目。
        """
        # 拼接可用于匹配的文本
        text_parts = []
        if invoice.expense_category:
            text_parts.append(invoice.expense_category)
        if invoice.memo:
            text_parts.append(invoice.memo)
        if invoice.seller_name and invoice.direction == "input":
            text_parts.append(invoice.seller_name)
        search_text = " ".join(text_parts)

        suggestions: list[dict[str, Any]] = []
        seen_accounts: set[str] = set()

        for rule in BANK_KEYWORD_RULES:
            matched_keywords = [kw for kw in rule["keywords"] if kw in search_text]
            if not matched_keywords:
                continue

            account = self._find_account_by_name(
                rule["account_name"],
                parent_hint=rule.get("parent_hint", ""),
            )
            if not account or account.code in seen_accounts:
                continue
            seen_accounts.add(account.code)

            keyword_score = min(len(matched_keywords) * 0.3, 0.6)
            exact_score = 0.2 if invoice.expense_category and any(
                kw == invoice.expense_category for kw in matched_keywords
            ) else 0.0
            confidence = round(min(keyword_score + exact_score + 0.2, 1.0), 2)

            suggestions.append({
                "account_code": account.code,
                "account_name": account.name,
                "confidence": confidence,
                "reason": f"关键词匹配: {', '.join(matched_keywords)}",
            })

        # 按方向补充默认建议
        if not suggestions:
            if invoice.direction == "input":
                # 进项默认建议管理费用
                acc = self._find_account_by_name("管理费用")
                if acc:
                    suggestions.append({
                        "account_code": acc.code,
                        "account_name": acc.name,
                        "confidence": 0.1,
                        "reason": "默认建议: 进项发票归入管理费用",
                    })
            else:
                # 销项默认建议主营业务收入
                acc = self._find_account_by_name("主营业务收入")
                if acc:
                    suggestions.append({
                        "account_code": acc.code,
                        "account_name": acc.name,
                        "confidence": 0.1,
                        "reason": "默认建议: 销项发票归入主营业务收入",
                    })

        suggestions.sort(key=lambda s: s["confidence"], reverse=True)
        return suggestions

    def create_voucher_from_invoice(
        self,
        invoice: Invoice,
        expense_account_code: str | None = None,
        expense_account_name: str | None = None,
    ) -> Voucher:
        """从发票创建凭证"""
        if not invoice.is_verified:
            raise ValueError(
                f"发票 {invoice.invoice_number} 尚未通过查验，不允许入账。"
                f"请先执行: ft invoice verify --invoice-id {invoice.id}"
            )

        period = invoice.invoice_date.strftime("%Y-%m")

        if not expense_account_code:
            raise ValueError("请指定费用/成本科目编码")

        if not expense_account_name:
            acc = self.coa.get_account_by_code(expense_account_code)
            expense_account_name = acc.name if acc else expense_account_code

        voucher = Voucher(
            company_id=self.company_id,
            voucher_type="记",
            voucher_number=self._next_voucher_number(period),
            voucher_date=invoice.invoice_date,
            period=period,
            source="invoice",
            source_ref=invoice.invoice_number,
            attachment_count=1,
            status="draft",
        )
        self.session.add(voucher)
        self.session.flush()

        entries = []
        if invoice.direction == "input":
            # 进项发票(购入): 借 费用/成本科目(不含税), 借 应交税费-进项税额(如有), 贷 应付账款/银行存款
            seq = 1
            entries.append(VoucherEntry(
                voucher_id=voucher.id, seq=seq,
                account_code=expense_account_code,
                account_name=expense_account_name,
                summary=f"购入 {invoice.seller_name or ''} {invoice.invoice_number}",
                debit_amount=invoice.amount,
                credit_amount=Decimal("0.00"),
            ))
            seq += 1

            vat_code, vat_name = self._resolve("应交增值税")
            payable_code, payable_name = self._resolve("应付账款")

            if invoice.tax_amount > 0:
                entries.append(VoucherEntry(
                    voucher_id=voucher.id, seq=seq,
                    account_code=vat_code, account_name=vat_name,
                    summary=f"进项税额 {invoice.invoice_number}",
                    debit_amount=invoice.tax_amount,
                    credit_amount=Decimal("0.00"),
                ))
                seq += 1

            entries.append(VoucherEntry(
                voucher_id=voucher.id, seq=seq,
                account_code=payable_code, account_name=payable_name,
                summary=f"应付 {invoice.seller_name or ''} {invoice.invoice_number}",
                debit_amount=Decimal("0.00"),
                credit_amount=invoice.total_amount,
            ))

        elif invoice.direction == "output":
            # 销项发票(销售): 借 应收账款, 贷 主营业务收入(不含税), 贷 应交税费-销项税额
            receivable_code, receivable_name = self._resolve("应收账款")
            vat_code, vat_name = self._resolve("应交增值税")

            entries.append(VoucherEntry(
                voucher_id=voucher.id, seq=1,
                account_code=receivable_code, account_name=receivable_name,
                summary=f"应收 {invoice.buyer_name or ''} {invoice.invoice_number}",
                debit_amount=invoice.total_amount,
                credit_amount=Decimal("0.00"),
            ))

            seq = 2
            entries.append(VoucherEntry(
                voucher_id=voucher.id, seq=seq,
                account_code=expense_account_code,
                account_name=expense_account_name,
                summary=f"销售收入 {invoice.invoice_number}",
                debit_amount=Decimal("0.00"),
                credit_amount=invoice.amount,
            ))
            seq += 1

            if invoice.tax_amount > 0:
                entries.append(VoucherEntry(
                    voucher_id=voucher.id, seq=seq,
                    account_code=vat_code, account_name=vat_name,
                    summary=f"销项税额 {invoice.invoice_number}",
                    debit_amount=Decimal("0.00"),
                    credit_amount=invoice.tax_amount,
                ))

        for entry in entries:
            self.session.add(entry)

        invoice.is_processed = True
        invoice.voucher_id = voucher.id
        invoice.matched_account_code = expense_account_code

        self.session.flush()
        return voucher

    def create_manual_voucher(
        self,
        voucher_date: date,
        entries_data: list[dict[str, Any]],
        voucher_type: str = "记",
        memo: str | None = None,
    ) -> Voucher:
        """创建手工凭证（不关联银行流水，支持多借多贷）

        entries_data 每项支持两种格式:
        - {"account_code": "5602", ...}  — 按科目编码
        - {"account": "管理费用-工资", ...}  — 按名称或编码自动解析
        """
        from finance_tax.models.account import Account

        period = voucher_date.strftime("%Y-%m")

        # 校验借贷平衡
        total_debit = sum(Decimal(str(e.get("debit", 0))) for e in entries_data)
        total_credit = sum(Decimal(str(e.get("credit", 0))) for e in entries_data)
        if total_debit != total_credit:
            raise ValueError(
                f"借贷不平衡: 借方合计 {total_debit}, 贷方合计 {total_credit}"
            )
        if total_debit == 0:
            raise ValueError("凭证金额不能为零")

        # 解析科目（支持 account_code 或 account 字段）
        resolved = []
        for i, ed in enumerate(entries_data, 1):
            account_key = ed.get("account_code") or ed.get("account", "")
            if not account_key:
                raise ValueError(f"分录 #{i} 缺少 account 或 account_code 字段")

            acc = self.session.query(Account).filter_by(
                company_id=self.company_id, code=account_key, is_active=True
            ).first()
            if not acc:
                acc = self.session.query(Account).filter_by(
                    company_id=self.company_id, name=account_key, is_active=True
                ).first()
            if not acc:
                # 支持 full_name 匹配（如 "管理费用/工资" 或 "管理费用-工资"）
                normalized = account_key.replace("-", "/")
                acc = self.session.query(Account).filter(
                    Account.company_id == self.company_id,
                    Account.full_name.in_([account_key, normalized]),
                    Account.is_active == True,
                ).first()
            if not acc:
                raise ValueError(f"找不到科目: {account_key} (分录 #{i})")

            resolved.append({
                "account_code": acc.code,
                "account_name": acc.name,
                "summary": ed.get("summary", memo or "手工凭证"),
                "debit": Decimal(str(ed.get("debit", 0))),
                "credit": Decimal(str(ed.get("credit", 0))),
            })

        voucher = Voucher(
            company_id=self.company_id,
            voucher_type=voucher_type,
            voucher_number=self._next_voucher_number(period, voucher_type),
            voucher_date=voucher_date,
            period=period,
            source="manual",
            memo=memo,
            status="draft",
        )
        self.session.add(voucher)
        self.session.flush()

        for seq, r in enumerate(resolved, 1):
            self.session.add(VoucherEntry(
                voucher_id=voucher.id,
                seq=seq,
                account_code=r["account_code"],
                account_name=r["account_name"],
                summary=r["summary"],
                debit_amount=r["debit"],
                credit_amount=r["credit"],
            ))

        self.session.flush()
        return voucher

    def post_voucher(self, voucher_id: int) -> Voucher:
        """过账（审核）凭证"""
        voucher = self.session.query(Voucher).filter_by(
            id=voucher_id, company_id=self.company_id
        ).first()
        if not voucher:
            raise ValueError(f"凭证 {voucher_id} 不存在")
        if voucher.status != "draft":
            raise ValueError(f"凭证状态为 {voucher.status}，只有草稿状态可以过账")
        if not voucher.is_balanced:
            raise ValueError("凭证借贷不平衡，无法过账")

        voucher.status = "posted"
        self.session.flush()
        return voucher

    def batch_generate_from_transactions(self) -> list[Voucher]:
        """批量从未处理的银行流水生成凭证"""
        unprocessed = (
            self.session.query(BankTransaction)
            .filter_by(company_id=self.company_id, is_processed=False)
            .order_by(BankTransaction.trans_date)
            .all()
        )

        vouchers = []
        failed = []
        for txn in unprocessed:
            try:
                v = self.create_voucher_from_transaction(txn)
                vouchers.append(v)
            except ValueError as e:
                failed.append({"transaction_id": txn.id, "error": str(e)})

        return vouchers

    def list_vouchers(
        self, period: str | None = None, status: str | None = None
    ) -> list[Voucher]:
        """查询凭证列表"""
        query = self.session.query(Voucher).filter_by(company_id=self.company_id)
        if period:
            query = query.filter_by(period=period)
        if status:
            query = query.filter_by(status=status)
        return query.order_by(Voucher.voucher_date, Voucher.voucher_number).all()
