"""会计科目表管理"""

import json
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from finance_tax.models.account import Account
from finance_tax.utils import get_data_dir


class ChartOfAccountsManager:
    """科目表管理器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id

    def load_standard_accounts(self, standard: str = "small_enterprise") -> list[dict]:
        """从JSON文件加载标准科目表"""
        filename = f"chart_of_accounts_{standard}.json"
        filepath = get_data_dir() / filename
        if not filepath.exists():
            raise FileNotFoundError(f"科目表文件不存在: {filepath}")

        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data["accounts"]

    def init_accounts(self, standard: str = "small_enterprise") -> int:
        """初始化科目表到数据库，返回导入数量"""
        accounts_data = self.load_standard_accounts(standard)
        count = 0

        for acc in accounts_data:
            existing = (
                self.session.query(Account)
                .filter_by(company_id=self.company_id, code=acc["code"])
                .first()
            )
            if existing:
                continue

            # 确定是否末级科目（没有子科目的就是末级）
            has_children = any(
                a.get("parent_code") == acc["code"] for a in accounts_data
            )

            account = Account(
                company_id=self.company_id,
                code=acc["code"],
                name=acc["name"],
                category=acc["category"],
                balance_direction=acc["direction"],
                level=acc["level"],
                parent_code=acc.get("parent_code"),
                is_leaf=not has_children,
                is_system=True,
                is_active=True,
            )
            # 构建全名
            if acc.get("parent_code"):
                parent = next(
                    (a for a in accounts_data if a["code"] == acc["parent_code"]), None
                )
                if parent:
                    account.full_name = f"{parent['name']}/{acc['name']}"
                else:
                    account.full_name = acc["name"]
            else:
                account.full_name = acc["name"]

            self.session.add(account)
            count += 1

        self.session.flush()
        return count

    def get_account_by_code(self, code: str) -> Account | None:
        """根据编码查找科目"""
        return (
            self.session.query(Account)
            .filter_by(company_id=self.company_id, code=code)
            .first()
        )

    def search_accounts(
        self,
        keyword: str = "",
        category: str = "",
        level: int | None = None,
        leaf_only: bool = False,
    ) -> list[Account]:
        """搜索科目"""
        query = self.session.query(Account).filter_by(
            company_id=self.company_id, is_active=True
        )
        if keyword:
            query = query.filter(
                (Account.code.contains(keyword)) | (Account.name.contains(keyword))
            )
        if category:
            query = query.filter_by(category=category)
        if level is not None:
            query = query.filter_by(level=level)
        if leaf_only:
            query = query.filter_by(is_leaf=True)
        return query.order_by(Account.code).all()

    def list_all(self) -> list[Account]:
        """列出所有科目"""
        return (
            self.session.query(Account)
            .filter_by(company_id=self.company_id, is_active=True)
            .order_by(Account.code)
            .all()
        )

    def add_custom_account(
        self,
        code: str,
        name: str,
        category: str,
        balance_direction: str,
        parent_code: str | None = None,
    ) -> Account:
        """添加自定义科目"""
        existing = self.get_account_by_code(code)
        if existing:
            raise ValueError(f"科目编码 {code} 已存在")

        level = 1
        full_name = name
        if parent_code:
            parent = self.get_account_by_code(parent_code)
            if not parent:
                raise ValueError(f"上级科目 {parent_code} 不存在")
            level = parent.level + 1
            full_name = f"{parent.full_name}/{name}"
            # 将父科目标记为非末级
            parent.is_leaf = False

        account = Account(
            company_id=self.company_id,
            code=code,
            name=name,
            full_name=full_name,
            category=category,
            balance_direction=balance_direction,
            level=level,
            parent_code=parent_code,
            is_leaf=True,
            is_system=False,
            is_active=True,
        )
        self.session.add(account)
        self.session.flush()
        return account
