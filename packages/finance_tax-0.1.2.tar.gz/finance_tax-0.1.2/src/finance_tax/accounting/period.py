"""会计期间管理"""

import calendar
from datetime import date

from sqlalchemy.orm import Session

from finance_tax.models.period import FiscalPeriod


class PeriodManager:
    """会计期间管理器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id

    def init_year_periods(self, year: int, start_month: int = 1) -> list[FiscalPeriod]:
        """初始化一个会计年度的所有期间"""
        periods = []
        for i in range(12):
            month = ((start_month - 1 + i) % 12) + 1
            actual_year = year if month >= start_month else year + 1
            if start_month == 1:
                actual_year = year

            period_str = f"{actual_year:04d}-{month:02d}"

            existing = (
                self.session.query(FiscalPeriod)
                .filter_by(company_id=self.company_id, period=period_str)
                .first()
            )
            if existing:
                periods.append(existing)
                continue

            last_day = calendar.monthrange(actual_year, month)[1]
            fp = FiscalPeriod(
                company_id=self.company_id,
                year=actual_year,
                month=month,
                period=period_str,
                start_date=date(actual_year, month, 1),
                end_date=date(actual_year, month, last_day),
                status="open",
                is_year_end=(i == 11),
            )
            self.session.add(fp)
            periods.append(fp)

        self.session.flush()
        return periods

    def get_current_period(self) -> FiscalPeriod | None:
        """获取当前打开的最早期间"""
        return (
            self.session.query(FiscalPeriod)
            .filter_by(company_id=self.company_id, status="open")
            .order_by(FiscalPeriod.period)
            .first()
        )

    def get_period(self, period_str: str) -> FiscalPeriod | None:
        """获取指定期间"""
        return (
            self.session.query(FiscalPeriod)
            .filter_by(company_id=self.company_id, period=period_str)
            .first()
        )

    def close_period(self, period_str: str) -> FiscalPeriod:
        """结账（关闭）期间"""
        fp = self.get_period(period_str)
        if not fp:
            raise ValueError(f"期间 {period_str} 不存在")
        if fp.status == "closed":
            raise ValueError(f"期间 {period_str} 已经结账")
        fp.status = "closed"
        self.session.flush()
        return fp

    def reopen_period(self, period_str: str) -> FiscalPeriod:
        """反结账（重新打开）期间"""
        fp = self.get_period(period_str)
        if not fp:
            raise ValueError(f"期间 {period_str} 不存在")
        if fp.status == "open":
            raise ValueError(f"期间 {period_str} 已经是打开状态")
        fp.status = "open"
        self.session.flush()
        return fp

    def list_periods(self, year: int | None = None) -> list[FiscalPeriod]:
        """列出会计期间"""
        query = self.session.query(FiscalPeriod).filter_by(company_id=self.company_id)
        if year:
            query = query.filter_by(year=year)
        return query.order_by(FiscalPeriod.period).all()
