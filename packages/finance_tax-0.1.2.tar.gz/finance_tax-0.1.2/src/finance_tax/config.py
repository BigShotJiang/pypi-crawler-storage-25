"""配置管理模块 - 支持本地化配置和初始化引导"""

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


# 默认数据目录
DEFAULT_DATA_DIR = Path.home() / ".finance-tax"
CONFIG_FILE = "config.json"
DB_FILE = "finance_tax.db"


class CompanyConfig(BaseModel):
    """公司配置"""
    name: str = Field(description="公司名称")
    tax_id: str = Field(default="", description="统一社会信用代码/税号")
    taxpayer_type: str = Field(
        default="small_scale",
        description="纳税人类型: small_scale=小规模纳税人, general=一般纳税人"
    )
    accounting_standard: str = Field(
        default="small_enterprise",
        description="会计准则: small_enterprise=小企业会计准则, enterprise=企业会计准则"
    )
    industry: str = Field(default="", description="所属行业")
    fiscal_year_start_month: int = Field(default=1, description="会计年度起始月份")


class AppConfig(BaseSettings):
    """应用配置"""
    data_dir: Path = Field(default=DEFAULT_DATA_DIR, description="数据存储目录")
    db_url: str = Field(default="", description="数据库连接URL(留空则自动使用SQLite)")
    current_company_id: int = Field(default=0, description="当前活动公司ID")
    invoice_verify_appcode: str = Field(default="", description="发票查验API AppCode(阿里云云市场)")

    @property
    def db_path(self) -> Path:
        return self.data_dir / DB_FILE

    @property
    def database_url(self) -> str:
        if self.db_url:
            return self.db_url
        return f"sqlite:///{self.db_path}"

    @property
    def config_path(self) -> Path:
        return self.data_dir / CONFIG_FILE

    @property
    def is_initialized(self) -> bool:
        return self.config_path.exists()


def load_config(data_dir: Path | None = None) -> AppConfig:
    """加载配置文件"""
    base_dir = data_dir or DEFAULT_DATA_DIR
    config_path = base_dir / CONFIG_FILE

    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        data["data_dir"] = str(base_dir)
        # 移除旧版配置字段，防止 pydantic 校验失败
        valid_fields = AppConfig.model_fields.keys()
        data = {k: v for k, v in data.items() if k in valid_fields}
        return AppConfig(**data)

    return AppConfig(data_dir=base_dir)


def save_config(config: AppConfig) -> None:
    """保存配置到文件"""
    config.data_dir.mkdir(parents=True, exist_ok=True)
    data = config.model_dump(mode="json")
    # 将Path转为字符串
    data["data_dir"] = str(data["data_dir"])
    with open(config.config_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def get_company_config_from_file(data_dir: Path | None = None) -> CompanyConfig | None:
    """从配置文件中读取公司配置"""
    base_dir = data_dir or DEFAULT_DATA_DIR
    company_config_path = base_dir / "company.json"
    if company_config_path.exists():
        with open(company_config_path, "r", encoding="utf-8") as f:
            return CompanyConfig(**json.load(f))
    return None


def save_company_config(company: CompanyConfig, data_dir: Path | None = None) -> None:
    """保存公司配置"""
    base_dir = data_dir or DEFAULT_DATA_DIR
    base_dir.mkdir(parents=True, exist_ok=True)
    company_config_path = base_dir / "company.json"
    with open(company_config_path, "w", encoding="utf-8") as f:
        json.dump(company.model_dump(), f, ensure_ascii=False, indent=2)
