"""现金流量表

采用直接法编制，基于银行存款和库存现金科目的发生额分类汇总。
"""

from decimal import Decimal
from typing import Any

from sqlalchemy import func, and_
from sqlalchemy.orm import Session

from finance_tax.models.account import Account
from finance_tax.models.voucher import Voucher, VoucherEntry
from finance_tax.models.company import Company


class CashFlowReport:
    """现金流量表生成器（直接法）"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id

    # 现金类科目前缀
    CASH_PREFIXES = ("1001", "1002", "1012")

    def _get_cash_flows(
        self, period_start: str, period_end: str
    ) -> list[dict[str, Any]]:
        """获取所有涉及现金科目的凭证分录对

        返回每笔现金流动的对方科目和金额。
        """
        # 查找所有现金科目编码
        cash_codes = (
            self.session.query(Account.code)
            .filter(
                Account.company_id == self.company_id,
                Account.is_active == True,
            )
            .all()
        )
        cash_codes = [
            a.code for a in cash_codes
            if any(a.code.startswith(p) for p in self.CASH_PREFIXES)
        ]
        if not cash_codes:
            return []

        # 查找涉及现金科目的凭证
        cash_entries = (
            self.session.query(VoucherEntry, Voucher.period)
            .join(Voucher, VoucherEntry.voucher_id == Voucher.id)
            .filter(
                Voucher.company_id == self.company_id,
                Voucher.status == "posted",
                Voucher.period >= period_start,
                Voucher.period <= period_end,
                VoucherEntry.account_code.in_(cash_codes),
            )
            .all()
        )

        flows = []
        for entry, _ in cash_entries:
            # 找同一凭证中的对方分录
            counterparts = (
                self.session.query(VoucherEntry)
                .filter(
                    VoucherEntry.voucher_id == entry.voucher_id,
                    VoucherEntry.id != entry.id,
                    ~VoucherEntry.account_code.in_(cash_codes),
                )
                .all()
            )

            # 现金流入 = 现金科目借方; 现金流出 = 现金科目贷方
            is_inflow = entry.debit_amount > 0
            cash_amount = entry.debit_amount if is_inflow else entry.credit_amount

            for cp in counterparts:
                # 分配比例（如果多个对方科目）
                if len(counterparts) > 1:
                    cp_amount = cp.credit_amount if is_inflow else cp.debit_amount
                else:
                    cp_amount = cash_amount

                flows.append({
                    "counterpart_code": cp.account_code,
                    "counterpart_name": cp.account_name,
                    "summary": cp.summary,
                    "is_inflow": is_inflow,
                    "amount": cp_amount,
                })

        return flows

    def _classify_flow(self, code: str) -> str:
        """根据对方科目编码分类现金流量类别

        Returns: operating/investing/financing
        """
        # 经营活动: 收入、成本、费用、税费、往来
        operating_prefixes = (
            "5", "6",      # 收入/费用/成本类
            "1122", "1123", # 应收/预付
            "1221",         # 其他应收
            "1401", "1402", "1403", "1405",  # 存货
            "2201", "2202", "2203",  # 应付/预收
            "2211",         # 应付职工薪酬
            "2221",         # 应交税费
            "2241",         # 其他应付
        )
        # 投资活动: 固定资产、无形资产、长期投资
        investing_prefixes = (
            "1501", "1511",  # 长期投资
            "1601", "1604", "1605", "1606",  # 固定资产/在建工程
            "1701",          # 无形资产
        )
        # 筹资活动: 借款、实收资本、分配股利
        financing_prefixes = (
            "2001", "2501",  # 借款
            "3001", "4001",  # 实收资本
            "3002", "4002",  # 资本公积
            "3104", "4104",  # 利润分配
            "2231", "2232",  # 应付利息/股利
            "2701",          # 长期应付
        )

        for prefix in investing_prefixes:
            if code.startswith(prefix):
                return "investing"
        for prefix in financing_prefixes:
            if code.startswith(prefix):
                return "financing"
        return "operating"

    def generate(self, period: str, period_start: str | None = None) -> dict[str, Any]:
        """生成现金流量表"""
        company = self.session.query(Company).filter_by(id=self.company_id).first()
        standard = company.accounting_standard if company else "small_enterprise"

        ps = period_start or period
        pe = period

        flows = self._get_cash_flows(ps, pe)

        # 分类汇总
        operating_in = Decimal("0.00")
        operating_out = Decimal("0.00")
        investing_in = Decimal("0.00")
        investing_out = Decimal("0.00")
        financing_in = Decimal("0.00")
        financing_out = Decimal("0.00")

        detail = {"operating": [], "investing": [], "financing": []}

        for flow in flows:
            category = self._classify_flow(flow["counterpart_code"])
            if flow["is_inflow"]:
                if category == "operating":
                    operating_in += flow["amount"]
                elif category == "investing":
                    investing_in += flow["amount"]
                else:
                    financing_in += flow["amount"]
            else:
                if category == "operating":
                    operating_out += flow["amount"]
                elif category == "investing":
                    investing_out += flow["amount"]
                else:
                    financing_out += flow["amount"]

            detail[category].append(flow)

        items = {
            "一、经营活动产生的现金流量": None,
            "  经营活动现金流入小计": operating_in,
            "  经营活动现金流出小计": operating_out,
            "  经营活动产生的现金流量净额": operating_in - operating_out,

            "二、投资活动产生的现金流量": None,
            "  投资活动现金流入小计": investing_in,
            "  投资活动现金流出小计": investing_out,
            "  投资活动产生的现金流量净额": investing_in - investing_out,

            "三、筹资活动产生的现金流量": None,
            "  筹资活动现金流入小计": financing_in,
            "  筹资活动现金流出小计": financing_out,
            "  筹资活动产生的现金流量净额": financing_in - financing_out,

            "四、现金及现金等价物净增加额": (
                (operating_in - operating_out) +
                (investing_in - investing_out) +
                (financing_in - financing_out)
            ),
        }

        return {
            "title": "现金流量表",
            "period": f"{ps} 至 {pe}",
            "standard": standard,
            "items": items,
            "net_increase": items["四、现金及现金等价物净增加额"],
        }

    def to_text(self, data: dict[str, Any]) -> str:
        """转为文本格式"""
        lines = [
            data["title"],
            f"报表期间: {data['period']}",
            "=" * 50,
        ]
        for k, v in data["items"].items():
            if v is None:
                lines.append(f"\n{k}")
            else:
                lines.append(f"  {k:<32} {v:>14,.2f}")
        return "\n".join(lines)
