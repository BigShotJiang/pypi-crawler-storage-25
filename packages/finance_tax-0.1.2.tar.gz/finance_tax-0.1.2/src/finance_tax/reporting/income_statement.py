"""利润表"""

from decimal import Decimal
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from finance_tax.models.account import Account
from finance_tax.models.voucher import Voucher, VoucherEntry
from finance_tax.models.company import Company


class IncomeStatementReport:
    """利润表生成器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id

    def _get_period_amount(
        self, period_start: str, period_end: str, code_prefix: str, direction: str = "credit"
    ) -> Decimal:
        """获取期间内指定科目的发生额

        Args:
            direction: 取哪方发生额 credit=贷方(收入), debit=借方(费用)
        """
        col = (
            func.coalesce(func.sum(VoucherEntry.credit_amount), 0)
            if direction == "credit"
            else func.coalesce(func.sum(VoucherEntry.debit_amount), 0)
        )

        # 查找所有匹配前缀的科目编码
        accounts = (
            self.session.query(Account.code)
            .filter(
                Account.company_id == self.company_id,
                Account.code.startswith(code_prefix),
                Account.is_active == True,
            )
            .all()
        )
        codes = [a.code for a in accounts]
        if not codes:
            return Decimal("0.00")

        result = (
            self.session.query(col.label("total"))
            .select_from(VoucherEntry)
            .join(Voucher, VoucherEntry.voucher_id == Voucher.id)
            .filter(
                Voucher.company_id == self.company_id,
                Voucher.status == "posted",
                Voucher.period >= period_start,
                Voucher.period <= period_end,
                VoucherEntry.account_code.in_(codes),
            )
            .first()
        )
        return Decimal(str(result.total)) if result else Decimal("0.00")

    def _amt(self, ps: str, pe: str, *prefixes: str, direction: str = "credit") -> Decimal:
        """汇总多个科目前缀的发生额"""
        total = Decimal("0.00")
        for prefix in prefixes:
            total += self._get_period_amount(ps, pe, prefix, direction)
        return total

    def generate(self, period: str, period_start: str | None = None) -> dict[str, Any]:
        """生成利润表

        Args:
            period: 报表截止期间 YYYY-MM
            period_start: 起始期间（默认为当月，也可设为年初以生成累计数）
        """
        company = self.session.query(Company).filter_by(id=self.company_id).first()
        standard = company.accounting_standard if company else "small_enterprise"
        is_enterprise = standard == "enterprise"

        ps = period_start or period
        pe = period

        # 科目前缀根据准则不同而不同
        rev_prefix = "6001" if is_enterprise else "5001"
        other_rev_prefix = "6051" if is_enterprise else "5051"
        invest_rev_prefix = "6111" if is_enterprise else "5111"
        non_op_rev_prefix = "6301" if is_enterprise else "5301"

        cost_prefix = "6401" if is_enterprise else "5401"
        other_cost_prefix = "6402" if is_enterprise else "5402"
        tax_surcharge_prefix = "6403" if is_enterprise else "5403"

        sell_expense_prefix = "6601" if is_enterprise else "5601"
        admin_expense_prefix = "6602" if is_enterprise else "5602"
        finance_expense_prefix = "6603" if is_enterprise else "5603"
        non_op_expense_prefix = "6711" if is_enterprise else "5711"
        income_tax_prefix = "6801" if is_enterprise else "5801"

        data = {}

        # 一、营业收入
        data["一、营业收入"] = self._amt(ps, pe, rev_prefix) + self._amt(ps, pe, other_rev_prefix)
        data["  主营业务收入"] = self._amt(ps, pe, rev_prefix)
        data["  其他业务收入"] = self._amt(ps, pe, other_rev_prefix)

        # 二、营业成本
        data["二、营业成本"] = self._amt(ps, pe, cost_prefix, direction="debit") + self._amt(ps, pe, other_cost_prefix, direction="debit")
        data["  主营业务成本"] = self._amt(ps, pe, cost_prefix, direction="debit")
        data["  其他业务成本"] = self._amt(ps, pe, other_cost_prefix, direction="debit")

        # 税金及附加
        data["  营业税金及附加"] = self._amt(ps, pe, tax_surcharge_prefix, direction="debit")

        # 期间费用
        data["  销售费用"] = self._amt(ps, pe, sell_expense_prefix, direction="debit")
        data["  管理费用"] = self._amt(ps, pe, admin_expense_prefix, direction="debit")
        data["  财务费用"] = self._amt(ps, pe, finance_expense_prefix, direction="debit")

        if is_enterprise:
            data["  资产减值损失"] = self._amt(ps, pe, "6701", direction="debit")

        # 营业利润
        op_profit = (
            data["一、营业收入"]
            - data["二、营业成本"]
            - data["  营业税金及附加"]
            - data["  销售费用"]
            - data["  管理费用"]
            - data["  财务费用"]
        )
        if is_enterprise:
            op_profit -= data.get("  资产减值损失", Decimal("0.00"))
        # 加投资收益
        invest_income = self._amt(ps, pe, invest_rev_prefix)
        op_profit += invest_income
        data["  投资收益"] = invest_income
        data["三、营业利润"] = op_profit

        # 营业外
        data["  营业外收入"] = self._amt(ps, pe, non_op_rev_prefix)
        data["  营业外支出"] = self._amt(ps, pe, non_op_expense_prefix, direction="debit")

        # 利润总额
        data["四、利润总额"] = op_profit + data["  营业外收入"] - data["  营业外支出"]

        # 所得税费用
        data["  所得税费用"] = self._amt(ps, pe, income_tax_prefix, direction="debit")

        # 净利润
        data["五、净利润"] = data["四、利润总额"] - data["  所得税费用"]

        return {
            "title": "利润表",
            "period": f"{ps} 至 {pe}",
            "standard": standard,
            "items": data,
            "net_profit": data["五、净利润"],
        }

    def to_text(self, data: dict[str, Any]) -> str:
        """转为文本格式"""
        lines = [
            data["title"],
            f"报表期间: {data['period']}",
            f"会计准则: {'企业会计准则' if data['standard'] == 'enterprise' else '小企业会计准则'}",
            "=" * 50,
        ]
        for k, v in data["items"].items():
            lines.append(f"  {k:<28} {v:>14,.2f}")
        return "\n".join(lines)
