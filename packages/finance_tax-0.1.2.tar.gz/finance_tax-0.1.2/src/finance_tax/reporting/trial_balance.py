"""科目余额表"""

from decimal import Decimal
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from finance_tax.models.account import Account
from finance_tax.models.voucher import Voucher, VoucherEntry


class TrialBalanceReport:
    """科目余额表生成器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id

    def generate(
        self,
        period: str | None = None,
        period_start: str | None = None,
        period_end: str | None = None,
        level: int | None = None,
    ) -> list[dict[str, Any]]:
        """生成科目余额表

        Args:
            period: 单一期间 (YYYY-MM)
            period_start: 起始期间
            period_end: 截止期间
            level: 科目层级筛选 (None=所有层级)

        Returns:
            科目余额列表
        """
        # 获取科目列表
        acc_query = (
            self.session.query(Account)
            .filter_by(company_id=self.company_id, is_active=True)
        )
        if level is not None:
            acc_query = acc_query.filter_by(level=level)
        accounts = acc_query.order_by(Account.code).all()

        # 查询本期发生额
        entry_query = (
            self.session.query(
                VoucherEntry.account_code,
                func.sum(VoucherEntry.debit_amount).label("period_debit"),
                func.sum(VoucherEntry.credit_amount).label("period_credit"),
            )
            .join(Voucher, VoucherEntry.voucher_id == Voucher.id)
            .filter(
                Voucher.company_id == self.company_id,
                Voucher.status == "posted",
            )
        )

        if period:
            entry_query = entry_query.filter(Voucher.period == period)
        elif period_start and period_end:
            entry_query = entry_query.filter(
                Voucher.period >= period_start, Voucher.period <= period_end
            )

        entry_query = entry_query.group_by(VoucherEntry.account_code)
        period_data = {
            row.account_code: {
                "period_debit": row.period_debit or Decimal("0.00"),
                "period_credit": row.period_credit or Decimal("0.00"),
            }
            for row in entry_query.all()
        }

        # 查询年初至今累计发生额 (用于余额计算)
        if period:
            year = period[:4]
            year_start = f"{year}-01"
            end_period = period
        elif period_end:
            year = period_end[:4]
            year_start = f"{year}-01"
            end_period = period_end
        else:
            end_period = None

        if end_period:
            cumulative_query = (
                self.session.query(
                    VoucherEntry.account_code,
                    func.sum(VoucherEntry.debit_amount).label("cum_debit"),
                    func.sum(VoucherEntry.credit_amount).label("cum_credit"),
                )
                .join(Voucher, VoucherEntry.voucher_id == Voucher.id)
                .filter(
                    Voucher.company_id == self.company_id,
                    Voucher.status == "posted",
                    Voucher.period >= year_start,
                    Voucher.period <= end_period,
                )
                .group_by(VoucherEntry.account_code)
            )
            cumulative_data = {
                row.account_code: {
                    "cum_debit": row.cum_debit or Decimal("0.00"),
                    "cum_credit": row.cum_credit or Decimal("0.00"),
                }
                for row in cumulative_query.all()
            }
        else:
            cumulative_data = period_data

        # 组装报表
        rows = []
        for acc in accounts:
            pd_data = period_data.get(acc.code, {"period_debit": Decimal("0.00"), "period_credit": Decimal("0.00")})
            cd_data = cumulative_data.get(acc.code, {"cum_debit": Decimal("0.00"), "cum_credit": Decimal("0.00")})

            opening = acc.opening_balance
            # 计算期末余额
            if acc.balance_direction == "debit":
                ending = opening + cd_data["cum_debit"] - cd_data["cum_credit"]
            else:
                ending = opening + cd_data["cum_credit"] - cd_data["cum_debit"]

            # 只显示有发生额或有余额的科目
            has_activity = (
                pd_data["period_debit"] != 0
                or pd_data["period_credit"] != 0
                or opening != 0
                or ending != 0
            )
            if not has_activity:
                continue

            rows.append({
                "account_code": acc.code,
                "account_name": acc.name,
                "full_name": acc.full_name or acc.name,
                "level": acc.level,
                "direction": acc.balance_direction,
                "opening_debit": opening if acc.balance_direction == "debit" else Decimal("0.00"),
                "opening_credit": opening if acc.balance_direction == "credit" else Decimal("0.00"),
                "period_debit": pd_data["period_debit"],
                "period_credit": pd_data["period_credit"],
                "cumulative_debit": cd_data.get("cum_debit", Decimal("0.00")),
                "cumulative_credit": cd_data.get("cum_credit", Decimal("0.00")),
                "ending_debit": ending if acc.balance_direction == "debit" else Decimal("0.00"),
                "ending_credit": ending if acc.balance_direction == "credit" else Decimal("0.00"),
                "ending_balance": ending,
            })

        return rows

    def to_text(self, rows: list[dict[str, Any]], title: str = "科目余额表") -> str:
        """将科目余额表转为文本格式"""
        if not rows:
            return f"{title}\n（无数据）"

        lines = [
            title,
            "=" * 100,
            f"{'科目编码':<12} {'科目名称':<20} {'方向':<6} "
            f"{'期初余额':>14} {'本期借方':>14} {'本期贷方':>14} {'期末余额':>14}",
            "-" * 100,
        ]

        total_debit = Decimal("0.00")
        total_credit = Decimal("0.00")

        for row in rows:
            indent = "  " * (row["level"] - 1)
            name = f"{indent}{row['account_name']}"
            opening = row["opening_debit"] if row["direction"] == "debit" else row["opening_credit"]
            lines.append(
                f"{row['account_code']:<12} {name:<20} "
                f"{'借' if row['direction'] == 'debit' else '贷':<6} "
                f"{opening:>14,.2f} {row['period_debit']:>14,.2f} "
                f"{row['period_credit']:>14,.2f} {row['ending_balance']:>14,.2f}"
            )
            total_debit += row["period_debit"]
            total_credit += row["period_credit"]

        lines.append("-" * 100)
        lines.append(
            f"{'合计':<12} {'':<20} {'':<6} "
            f"{'':>14} {total_debit:>14,.2f} {total_credit:>14,.2f} {'':>14}"
        )

        return "\n".join(lines)
