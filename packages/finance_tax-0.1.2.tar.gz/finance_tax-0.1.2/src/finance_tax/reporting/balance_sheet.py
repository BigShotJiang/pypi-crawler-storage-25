"""资产负债表"""

from decimal import Decimal
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from finance_tax.models.account import Account
from finance_tax.models.voucher import Voucher, VoucherEntry
from finance_tax.models.company import Company


class BalanceSheetReport:
    """资产负债表生成器

    支持小企业会计准则和企业会计准则两种格式。
    """

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id

    def _get_account_balance(self, period: str, code_prefix: str) -> Decimal:
        """获取指定科目前缀在指定期间末的余额"""
        # 获取科目信息
        accounts = (
            self.session.query(Account)
            .filter(
                Account.company_id == self.company_id,
                Account.code.startswith(code_prefix),
                Account.is_active == True,
            )
            .all()
        )
        if not accounts:
            return Decimal("0.00")

        year = period[:4]
        year_start = f"{year}-01"

        total = Decimal("0.00")
        for acc in accounts:
            # 期初余额
            opening = acc.opening_balance

            # 本年累计发生额
            result = (
                self.session.query(
                    func.coalesce(func.sum(VoucherEntry.debit_amount), 0).label("total_debit"),
                    func.coalesce(func.sum(VoucherEntry.credit_amount), 0).label("total_credit"),
                )
                .join(Voucher, VoucherEntry.voucher_id == Voucher.id)
                .filter(
                    Voucher.company_id == self.company_id,
                    Voucher.status == "posted",
                    Voucher.period >= year_start,
                    Voucher.period <= period,
                    VoucherEntry.account_code == acc.code,
                )
                .first()
            )

            cum_debit = Decimal(str(result.total_debit)) if result else Decimal("0.00")
            cum_credit = Decimal(str(result.total_credit)) if result else Decimal("0.00")

            if acc.balance_direction == "debit":
                balance = opening + cum_debit - cum_credit
            else:
                balance = opening + cum_credit - cum_debit

            total += balance

        return total

    def _bal(self, period: str, *code_prefixes: str) -> Decimal:
        """汇总多个科目前缀的余额"""
        total = Decimal("0.00")
        for prefix in code_prefixes:
            total += self._get_account_balance(period, prefix)
        return total

    def generate(self, period: str) -> dict[str, Any]:
        """生成资产负债表

        Args:
            period: 报表期间 YYYY-MM

        Returns:
            资产负债表数据字典
        """
        company = self.session.query(Company).filter_by(id=self.company_id).first()
        standard = company.accounting_standard if company else "small_enterprise"

        # 根据准则确定科目前缀
        is_enterprise = standard == "enterprise"
        # 企业会计准则: 权益类4xxx, 收入6xxx, 成本6xxx, 费用6xxx
        # 小企业会计准则: 权益类3xxx, 收入5xxx, 成本5xxx, 费用5xxx

        # ========== 资产类 ==========
        assets = {}
        assets["货币资金"] = self._bal(period, "1001", "1002", "1012")
        if is_enterprise:
            assets["交易性金融资产"] = self._bal(period, "1101")
        else:
            assets["短期投资"] = self._bal(period, "1101")
        assets["应收票据"] = self._bal(period, "1121")
        assets["应收账款"] = self._bal(period, "1122")
        assets["预付账款"] = self._bal(period, "1123")
        assets["应收股利"] = self._bal(period, "1131")
        assets["应收利息"] = self._bal(period, "1132")
        assets["其他应收款"] = self._bal(period, "1221")
        assets["存货"] = self._bal(
            period, "1401", "1402", "1403", "1404", "1405", "1407", "1408", "1411"
        )
        assets["流动资产合计"] = sum(assets.values())

        assets["长期股权投资"] = self._bal(period, "1511")
        assets["固定资产原价"] = self._bal(period, "1601")
        assets["累计折旧"] = self._bal(period, "1602")
        assets["固定资产净值"] = assets["固定资产原价"] - assets["累计折旧"]
        assets["在建工程"] = self._bal(period, "1604")
        assets["无形资产"] = self._bal(period, "1701") - self._bal(period, "1702")
        assets["长期待摊费用"] = self._bal(period, "1801")
        if is_enterprise:
            assets["递延所得税资产"] = self._bal(period, "1811")

        non_current = (
            assets["长期股权投资"] + assets["固定资产净值"] +
            assets["在建工程"] + assets["无形资产"] + assets["长期待摊费用"]
        )
        if is_enterprise:
            non_current += assets.get("递延所得税资产", Decimal("0.00"))
        assets["非流动资产合计"] = non_current
        assets["资产总计"] = assets["流动资产合计"] + assets["非流动资产合计"]

        # ========== 负债类 ==========
        liabilities = {}
        liabilities["短期借款"] = self._bal(period, "2001")
        liabilities["应付票据"] = self._bal(period, "2201")
        liabilities["应付账款"] = self._bal(period, "2202")
        liabilities["预收账款"] = self._bal(period, "2203")
        liabilities["应付职工薪酬"] = self._bal(period, "2211")
        liabilities["应交税费"] = self._bal(period, "2221")
        liabilities["应付利息"] = self._bal(period, "2231")
        liabilities["应付股利"] = self._bal(period, "2232")
        liabilities["其他应付款"] = self._bal(period, "2241")
        liabilities["流动负债合计"] = sum(liabilities.values())

        liabilities["长期借款"] = self._bal(period, "2501")
        liabilities["长期应付款"] = self._bal(period, "2701")
        if is_enterprise:
            liabilities["预计负债"] = self._bal(period, "2801")
            liabilities["递延所得税负债"] = self._bal(period, "2901")

        non_current_liab = liabilities["长期借款"] + liabilities["长期应付款"]
        if is_enterprise:
            non_current_liab += liabilities.get("预计负债", Decimal("0.00"))
            non_current_liab += liabilities.get("递延所得税负债", Decimal("0.00"))
        liabilities["非流动负债合计"] = non_current_liab
        liabilities["负债合计"] = liabilities["流动负债合计"] + liabilities["非流动负债合计"]

        # ========== 所有者权益 ==========
        equity = {}
        equity_prefix = "4001" if is_enterprise else "3001"
        capital_reserve_prefix = "4002" if is_enterprise else "3002"
        surplus_prefix = "4101" if is_enterprise else "3101"
        current_profit_prefix = "4103" if is_enterprise else "3103"
        profit_dist_prefix = "4104" if is_enterprise else "3104"

        equity["实收资本(股本)"] = self._bal(period, equity_prefix)
        equity["资本公积"] = self._bal(period, capital_reserve_prefix)
        equity["盈余公积"] = self._bal(period, surplus_prefix)
        equity["未分配利润"] = (
            self._bal(period, profit_dist_prefix) +
            self._bal(period, current_profit_prefix)
        )
        equity["所有者权益合计"] = sum(equity.values())

        total_liab_equity = liabilities["负债合计"] + equity["所有者权益合计"]

        return {
            "title": "资产负债表",
            "period": period,
            "standard": standard,
            "assets": assets,
            "liabilities": liabilities,
            "equity": equity,
            "total_assets": assets["资产总计"],
            "total_liabilities_and_equity": total_liab_equity,
            "is_balanced": assets["资产总计"] == total_liab_equity,
        }

    def to_text(self, data: dict[str, Any]) -> str:
        """转为文本格式"""
        lines = [
            data["title"],
            f"报表期间: {data['period']}",
            f"会计准则: {'企业会计准则' if data['standard'] == 'enterprise' else '小企业会计准则'}",
            "=" * 60,
            "",
            "一、资产",
            "-" * 60,
        ]
        for k, v in data["assets"].items():
            lines.append(f"  {k:<24} {v:>14,.2f}")

        lines.extend(["", "二、负债", "-" * 60])
        for k, v in data["liabilities"].items():
            lines.append(f"  {k:<24} {v:>14,.2f}")

        lines.extend(["", "三、所有者权益", "-" * 60])
        for k, v in data["equity"].items():
            lines.append(f"  {k:<24} {v:>14,.2f}")

        lines.extend([
            "",
            "=" * 60,
            f"  {'负债和所有者权益合计':<24} {data['total_liabilities_and_equity']:>14,.2f}",
            f"  {'平衡校验':<24} {'✓ 平衡' if data['is_balanced'] else '✗ 不平衡'}",
        ])

        return "\n".join(lines)
