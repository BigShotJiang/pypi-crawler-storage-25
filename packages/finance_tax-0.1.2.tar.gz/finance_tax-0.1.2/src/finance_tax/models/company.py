"""公司/账套模型"""

from sqlalchemy import String, Integer, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from finance_tax.models.base import Base, TimestampMixin


class Company(Base, TimestampMixin):
    """公司/账套信息"""
    __tablename__ = "company"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False, comment="公司名称")
    tax_id: Mapped[str | None] = mapped_column(String(30), comment="统一社会信用代码/税号")
    legal_person: Mapped[str | None] = mapped_column(String(50), comment="法定代表人")

    # 纳税人类型: small_scale=小规模纳税人, general=一般纳税人
    taxpayer_type: Mapped[str] = mapped_column(
        String(20), nullable=False, default="small_scale",
        comment="纳税人类型: small_scale/general"
    )
    # 会计准则: small_enterprise=小企业会计准则, enterprise=企业会计准则
    accounting_standard: Mapped[str] = mapped_column(
        String(30), nullable=False, default="small_enterprise",
        comment="会计准则: small_enterprise/enterprise"
    )

    fiscal_year_start_month: Mapped[int] = mapped_column(
        Integer, nullable=False, default=1, comment="会计年度起始月份"
    )

    industry: Mapped[str | None] = mapped_column(String(100), comment="所属行业")
    address: Mapped[str | None] = mapped_column(String(500), comment="注册地址")
    bank_name: Mapped[str | None] = mapped_column(String(200), comment="开户银行")
    bank_account: Mapped[str | None] = mapped_column(String(50), comment="银行账号")

    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # 关系
    accounts = relationship("Account", back_populates="company", lazy="dynamic")
    vouchers = relationship("Voucher", back_populates="company", lazy="dynamic")
    bank_transactions = relationship("BankTransaction", back_populates="company", lazy="dynamic")
    invoices = relationship("Invoice", back_populates="company", lazy="dynamic")
    fixed_assets = relationship("FixedAsset", back_populates="company", lazy="dynamic")
    fiscal_periods = relationship("FiscalPeriod", back_populates="company", lazy="dynamic")
    tax_declarations = relationship("TaxDeclaration", back_populates="company", lazy="dynamic")
    attachments = relationship("Attachment", back_populates="company", lazy="dynamic")

    def __repr__(self) -> str:
        return f"<Company(id={self.id}, name='{self.name}', type='{self.taxpayer_type}')>"
