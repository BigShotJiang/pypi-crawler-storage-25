"""固定资产模型"""

from datetime import date
from decimal import Decimal

from sqlalchemy import String, Integer, Date, ForeignKey, Numeric, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from finance_tax.models.base import Base, TimestampMixin


class FixedAsset(Base, TimestampMixin):
    """固定资产"""
    __tablename__ = "fixed_asset"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[int] = mapped_column(Integer, ForeignKey("company.id"), nullable=False)

    asset_code: Mapped[str] = mapped_column(String(30), nullable=False, comment="资产编号")
    name: Mapped[str] = mapped_column(String(200), nullable=False, comment="资产名称")
    category: Mapped[str] = mapped_column(
        String(50), nullable=False, comment="资产类别: house/machine/vehicle/electronic/other"
    )

    # 价值信息
    original_value: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, comment="原值"
    )
    residual_rate: Mapped[Decimal] = mapped_column(
        Numeric(5, 2), nullable=False, default=Decimal("5.00"), comment="残值率(%)"
    )
    residual_value: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="预计净残值"
    )
    accumulated_depreciation: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="累计折旧"
    )

    # 折旧信息
    depreciation_method: Mapped[str] = mapped_column(
        String(30), nullable=False, default="straight_line",
        comment="折旧方法: straight_line/declining_balance/sum_of_years/units_of_production"
    )
    useful_life_months: Mapped[int] = mapped_column(
        Integer, nullable=False, comment="预计使用寿命(月)"
    )
    monthly_depreciation: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="月折旧额"
    )
    depreciated_months: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, comment="已折旧月数"
    )

    # 日期
    purchase_date: Mapped[date] = mapped_column(Date, nullable=False, comment="购入日期")
    start_depreciation_date: Mapped[date] = mapped_column(Date, nullable=False, comment="开始折旧日期")
    disposal_date: Mapped[date | None] = mapped_column(Date, comment="处置日期")

    # 使用信息
    department: Mapped[str | None] = mapped_column(String(100), comment="使用部门")
    location: Mapped[str | None] = mapped_column(String(200), comment="存放地点")

    # 关联科目
    asset_account_code: Mapped[str] = mapped_column(
        String(20), nullable=False, default="1601", comment="固定资产科目编码"
    )
    depreciation_account_code: Mapped[str] = mapped_column(
        String(20), nullable=False, default="1602", comment="累计折旧科目编码"
    )
    expense_account_code: Mapped[str | None] = mapped_column(
        String(20), comment="折旧费用科目编码"
    )

    # 状态: in_use=使用中, idle=闲置, disposed=已处置
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="in_use", comment="状态"
    )

    memo: Mapped[str | None] = mapped_column(Text, comment="备注")

    company = relationship("Company", back_populates="fixed_assets")

    @property
    def net_value(self) -> Decimal:
        """净值 = 原值 - 累计折旧"""
        return self.original_value - self.accumulated_depreciation

    def __repr__(self) -> str:
        return f"<FixedAsset(code='{self.asset_code}', name='{self.name}', net={self.net_value})>"
