"""税务申报模型"""

from datetime import date
from decimal import Decimal

from sqlalchemy import String, Integer, Date, ForeignKey, Numeric, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from finance_tax.models.base import Base, TimestampMixin


class TaxDeclaration(Base, TimestampMixin):
    """税务申报记录"""
    __tablename__ = "tax_declaration"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[int] = mapped_column(Integer, ForeignKey("company.id"), nullable=False)

    # 税种: vat=增值税, corporate_income=企业所得税, stamp=印花税,
    # urban_maintenance=城建税, education_surcharge=教育费附加,
    # local_education_surcharge=地方教育费附加, personal_income=个人所得税
    tax_type: Mapped[str] = mapped_column(String(30), nullable=False, comment="税种")

    # 申报期间
    period: Mapped[str] = mapped_column(String(7), nullable=False, comment="所属期间 YYYY-MM")
    period_start: Mapped[date] = mapped_column(Date, nullable=False, comment="期间起始日")
    period_end: Mapped[date] = mapped_column(Date, nullable=False, comment="期间终止日")

    # 申报频率: monthly=月度, quarterly=季度, annual=年度
    frequency: Mapped[str] = mapped_column(
        String(20), nullable=False, comment="申报频率: monthly/quarterly/annual"
    )

    # 金额
    taxable_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="计税基数/应纳税所得额"
    )
    tax_rate: Mapped[Decimal | None] = mapped_column(
        Numeric(8, 4), comment="适用税率"
    )
    tax_due: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="应纳税额"
    )
    tax_deduction: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="减免税额"
    )
    tax_paid: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="已预缴税额"
    )
    tax_payable: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="应补(退)税额"
    )

    # 申报表详细数据 (JSON格式存储，便于扩展)
    report_data: Mapped[dict | None] = mapped_column(JSON, comment="申报表详细数据")

    # 状态: calculated=已计算, filed=已申报, paid=已缴款
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="calculated", comment="状态"
    )

    memo: Mapped[str | None] = mapped_column(Text, comment="备注")

    company = relationship("Company", back_populates="tax_declarations")

    def __repr__(self) -> str:
        return f"<TaxDeclaration(type={self.tax_type}, period={self.period}, payable={self.tax_payable})>"
