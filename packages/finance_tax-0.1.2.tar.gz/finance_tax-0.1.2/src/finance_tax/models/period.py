"""会计期间模型"""

from datetime import date

from sqlalchemy import String, Integer, Date, ForeignKey, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from finance_tax.models.base import Base, TimestampMixin


class FiscalPeriod(Base, TimestampMixin):
    """会计期间"""
    __tablename__ = "fiscal_period"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[int] = mapped_column(Integer, ForeignKey("company.id"), nullable=False)

    year: Mapped[int] = mapped_column(Integer, nullable=False, comment="会计年度")
    month: Mapped[int] = mapped_column(Integer, nullable=False, comment="会计月份")
    period: Mapped[str] = mapped_column(String(7), nullable=False, comment="期间标识 YYYY-MM")

    start_date: Mapped[date] = mapped_column(Date, nullable=False, comment="期间起始日")
    end_date: Mapped[date] = mapped_column(Date, nullable=False, comment="期间终止日")

    # 状态: open=未结账, closed=已结账
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="open", comment="状态: open/closed"
    )

    is_year_end: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, comment="是否年末期间"
    )

    company = relationship("Company", back_populates="fiscal_periods")

    def __repr__(self) -> str:
        return f"<FiscalPeriod(period={self.period}, status={self.status})>"
