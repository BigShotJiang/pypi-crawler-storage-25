"""记账凭证模型"""

from datetime import date
from decimal import Decimal

from sqlalchemy import String, Integer, Date, ForeignKey, Numeric, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from finance_tax.models.base import Base, TimestampMixin


class Voucher(Base, TimestampMixin):
    """记账凭证（凭证头）"""
    __tablename__ = "voucher"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[int] = mapped_column(Integer, ForeignKey("company.id"), nullable=False)

    # 凭证字号: 记-0001
    voucher_type: Mapped[str] = mapped_column(
        String(10), nullable=False, default="记", comment="凭证字: 记/收/付/转"
    )
    voucher_number: Mapped[int] = mapped_column(Integer, nullable=False, comment="凭证号")

    voucher_date: Mapped[date] = mapped_column(Date, nullable=False, comment="凭证日期")
    period: Mapped[str] = mapped_column(String(7), nullable=False, comment="所属期间 YYYY-MM")

    attachment_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, comment="附件张数"
    )
    memo: Mapped[str | None] = mapped_column(Text, comment="备注")

    # 凭证来源: manual=手工, bank_import=银行流水导入, invoice=发票, system=系统自动
    source: Mapped[str] = mapped_column(
        String(20), nullable=False, default="manual", comment="凭证来源"
    )
    source_ref: Mapped[str | None] = mapped_column(String(100), comment="来源单据号")

    # 状态: draft=草稿, posted=已过账, void=已作废
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="draft", comment="状态"
    )

    company = relationship("Company", back_populates="vouchers")
    entries = relationship(
        "VoucherEntry", back_populates="voucher", cascade="all, delete-orphan",
        order_by="VoucherEntry.seq"
    )

    @property
    def total_debit(self) -> Decimal:
        return sum((e.debit_amount for e in self.entries), Decimal("0.00"))

    @property
    def total_credit(self) -> Decimal:
        return sum((e.credit_amount for e in self.entries), Decimal("0.00"))

    @property
    def is_balanced(self) -> bool:
        return self.total_debit == self.total_credit

    def __repr__(self) -> str:
        return f"<Voucher({self.voucher_type}-{self.voucher_number}, date={self.voucher_date})>"


class VoucherEntry(Base):
    """凭证分录（借贷明细）"""
    __tablename__ = "voucher_entry"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    voucher_id: Mapped[int] = mapped_column(Integer, ForeignKey("voucher.id"), nullable=False)

    seq: Mapped[int] = mapped_column(Integer, nullable=False, comment="分录序号")
    account_code: Mapped[str] = mapped_column(String(20), nullable=False, comment="科目编码")
    account_name: Mapped[str] = mapped_column(String(100), nullable=False, comment="科目名称")
    summary: Mapped[str] = mapped_column(String(500), nullable=False, comment="摘要")

    debit_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="借方金额"
    )
    credit_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="贷方金额"
    )

    # 辅助信息
    auxiliary_info: Mapped[str | None] = mapped_column(String(500), comment="辅助核算信息(JSON)")

    voucher = relationship("Voucher", back_populates="entries")

    def __repr__(self) -> str:
        return f"<VoucherEntry(seq={self.seq}, account={self.account_code}, D={self.debit_amount}, C={self.credit_amount})>"
