"""附件模型 - 发票/银行流水/凭证的电子凭证管理"""

from sqlalchemy import String, Integer, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from finance_tax.models.base import Base, TimestampMixin


class Attachment(Base, TimestampMixin):
    """附件表 — 多态关联发票/银行流水/凭证"""
    __tablename__ = "attachment"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[int] = mapped_column(Integer, ForeignKey("company.id"), nullable=False)

    # 多态关联
    entity_type: Mapped[str] = mapped_column(
        String(30), nullable=False,
        comment="关联对象类型: invoice / bank_transaction / voucher",
    )
    entity_id: Mapped[int] = mapped_column(
        Integer, nullable=False, comment="关联对象ID",
    )

    # 文件信息
    file_name: Mapped[str] = mapped_column(
        String(255), nullable=False, comment="原始文件名",
    )
    file_path: Mapped[str] = mapped_column(
        String(500), nullable=False, comment="相对存储路径",
    )
    file_size: Mapped[int] = mapped_column(
        Integer, nullable=False, comment="文件大小(字节)",
    )
    file_hash: Mapped[str] = mapped_column(
        String(64), nullable=False, comment="SHA-256 哈希",
    )
    mime_type: Mapped[str] = mapped_column(
        String(100), nullable=False, default="application/octet-stream",
        comment="MIME类型",
    )

    # 业务标签
    category: Mapped[str] = mapped_column(
        String(30), nullable=False, default="other",
        comment="类别: invoice_photo / e_invoice / bank_cert / other",
    )
    memo: Mapped[str | None] = mapped_column(Text, comment="备注")

    company = relationship("Company", back_populates="attachments")

    def __repr__(self) -> str:
        return f"<Attachment(id={self.id}, entity={self.entity_type}:{self.entity_id}, file={self.file_name})>"
