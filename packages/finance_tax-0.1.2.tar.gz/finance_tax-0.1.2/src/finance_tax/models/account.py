"""会计科目模型"""

from decimal import Decimal

from sqlalchemy import String, Integer, ForeignKey, Numeric, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from finance_tax.models.base import Base, TimestampMixin


class Account(Base, TimestampMixin):
    """会计科目表"""
    __tablename__ = "account"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[int] = mapped_column(Integer, ForeignKey("company.id"), nullable=False)

    code: Mapped[str] = mapped_column(String(20), nullable=False, comment="科目编码")
    name: Mapped[str] = mapped_column(String(100), nullable=False, comment="科目名称")
    full_name: Mapped[str | None] = mapped_column(String(500), comment="科目全称(含上级)")

    # 科目层级: 1=一级科目, 2=二级, 3=三级, 4=四级
    level: Mapped[int] = mapped_column(Integer, nullable=False, default=1, comment="科目层级")
    parent_code: Mapped[str | None] = mapped_column(String(20), comment="上级科目编码")

    # 科目分类: asset=资产, liability=负债, equity=权益, revenue=收入,
    # cost=成本, expense=费用, profit_loss=损益
    category: Mapped[str] = mapped_column(String(20), nullable=False, comment="科目分类")

    # 余额方向: debit=借方, credit=贷方
    balance_direction: Mapped[str] = mapped_column(
        String(10), nullable=False, comment="余额方向: debit/credit"
    )

    # 辅助核算标记
    has_auxiliary: Mapped[bool] = mapped_column(Boolean, default=False, comment="是否有辅助核算")
    auxiliary_type: Mapped[str | None] = mapped_column(
        String(50), comment="辅助核算类型: customer/supplier/project/department"
    )

    is_leaf: Mapped[bool] = mapped_column(Boolean, default=True, comment="是否末级科目")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_system: Mapped[bool] = mapped_column(Boolean, default=True, comment="是否系统预设科目")

    # 期初余额（迁移记账用）
    opening_balance: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="期初余额"
    )
    opening_period: Mapped[str | None] = mapped_column(
        String(7), comment="期初余额所属期间 YYYY-MM"
    )
    ytd_debit: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="本年累计借方（年中迁移用）"
    )
    ytd_credit: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="本年累计贷方（年中迁移用）"
    )

    company = relationship("Company", back_populates="accounts")

    def __repr__(self) -> str:
        return f"<Account(code='{self.code}', name='{self.name}')>"
