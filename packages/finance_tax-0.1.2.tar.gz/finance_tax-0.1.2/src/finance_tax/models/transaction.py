"""银行流水模型"""

from datetime import date
from decimal import Decimal

from sqlalchemy import String, Integer, Date, ForeignKey, Numeric, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from finance_tax.models.base import Base, TimestampMixin


class BankTransaction(Base, TimestampMixin):
    """银行流水记录"""
    __tablename__ = "bank_transaction"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[int] = mapped_column(Integer, ForeignKey("company.id"), nullable=False)

    bank_name: Mapped[str | None] = mapped_column(String(100), comment="银行名称")
    account_number: Mapped[str | None] = mapped_column(String(50), comment="银行账号")

    trans_date: Mapped[date] = mapped_column(Date, nullable=False, comment="交易日期")
    trans_type: Mapped[str | None] = mapped_column(
        String(50), comment="交易类型: income/expense/transfer"
    )

    # 金额信息
    debit_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="借方(支出)金额"
    )
    credit_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="贷方(收入)金额"
    )
    balance: Mapped[Decimal | None] = mapped_column(
        Numeric(18, 2), comment="交易后余额"
    )

    counterparty: Mapped[str | None] = mapped_column(String(200), comment="对方户名")
    counterparty_account: Mapped[str | None] = mapped_column(String(50), comment="对方账号")
    counterparty_bank: Mapped[str | None] = mapped_column(String(200), comment="对方开户行")

    summary: Mapped[str | None] = mapped_column(String(500), comment="摘要")
    memo: Mapped[str | None] = mapped_column(Text, comment="备注")
    reference_no: Mapped[str | None] = mapped_column(String(100), comment="银行流水号")

    # 记账处理状态
    is_processed: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, comment="是否已生成凭证"
    )
    voucher_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("voucher.id"), comment="关联凭证ID"
    )
    matched_account_code: Mapped[str | None] = mapped_column(
        String(20), comment="匹配的会计科目编码"
    )

    # 导入批次
    import_batch: Mapped[str | None] = mapped_column(String(50), comment="导入批次号")

    company = relationship("Company", back_populates="bank_transactions")

    def __repr__(self) -> str:
        amt = self.credit_amount if self.credit_amount else -self.debit_amount
        return f"<BankTransaction(date={self.trans_date}, amount={amt}, summary='{self.summary}')>"
