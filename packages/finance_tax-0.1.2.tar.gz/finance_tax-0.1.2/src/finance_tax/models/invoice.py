"""发票模型"""

from datetime import date
from decimal import Decimal

from sqlalchemy import String, Integer, Date, ForeignKey, Numeric, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from finance_tax.models.base import Base, TimestampMixin


class Invoice(Base, TimestampMixin):
    """发票台账"""
    __tablename__ = "invoice"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[int] = mapped_column(Integer, ForeignKey("company.id"), nullable=False)

    # 发票基本信息
    invoice_code: Mapped[str | None] = mapped_column(String(30), comment="发票代码")
    invoice_number: Mapped[str] = mapped_column(String(30), nullable=False, comment="发票号码")
    invoice_date: Mapped[date] = mapped_column(Date, nullable=False, comment="开票日期")

    # 发票类型: vat_special=增值税专用发票, vat_normal=增值税普通发票,
    # vat_electronic=增值税电子发票, toll=通行费发票, other=其他
    invoice_type: Mapped[str] = mapped_column(
        String(30), nullable=False, default="vat_normal", comment="发票类型"
    )

    # 购销方向: input=进项(购入), output=销项(销售)
    direction: Mapped[str] = mapped_column(
        String(10), nullable=False, comment="方向: input/output"
    )

    # 金额信息
    amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, comment="不含税金额"
    )
    tax_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="税额"
    )
    total_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, comment="价税合计"
    )
    tax_rate: Mapped[Decimal | None] = mapped_column(
        Numeric(5, 2), comment="税率(%)"
    )

    # 购销双方
    seller_name: Mapped[str | None] = mapped_column(String(200), comment="销售方名称")
    seller_tax_id: Mapped[str | None] = mapped_column(String(30), comment="销售方税号")
    buyer_name: Mapped[str | None] = mapped_column(String(200), comment="购买方名称")
    buyer_tax_id: Mapped[str | None] = mapped_column(String(30), comment="购买方税号")

    # 记账状态
    is_processed: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, comment="是否已记账"
    )
    voucher_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("voucher.id"), comment="关联凭证ID"
    )
    matched_account_code: Mapped[str | None] = mapped_column(
        String(20), comment="匹配的会计科目编码"
    )

    # 报销信息
    expense_category: Mapped[str | None] = mapped_column(String(50), comment="费用类别")
    memo: Mapped[str | None] = mapped_column(Text, comment="备注")

    # 认证/勾选状态 (一般纳税人进项)
    is_verified: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, comment="是否已认证勾选"
    )

    import_batch: Mapped[str | None] = mapped_column(String(50), comment="导入批次号")

    company = relationship("Company", back_populates="invoices")
    items = relationship("InvoiceItem", back_populates="invoice", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Invoice(no={self.invoice_number}, amount={self.total_amount}, type={self.invoice_type})>"


class InvoiceItem(Base):
    """发票明细行"""
    __tablename__ = "invoice_item"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    invoice_id: Mapped[int] = mapped_column(Integer, ForeignKey("invoice.id"), nullable=False)

    seq: Mapped[int] = mapped_column(Integer, nullable=False, comment="行号")
    item_name: Mapped[str] = mapped_column(String(200), nullable=False, comment="货物/服务名称")
    specification: Mapped[str | None] = mapped_column(String(100), comment="规格型号")
    unit: Mapped[str | None] = mapped_column(String(20), comment="单位")
    quantity: Mapped[Decimal | None] = mapped_column(Numeric(18, 4), comment="数量")
    unit_price: Mapped[Decimal | None] = mapped_column(Numeric(18, 6), comment="单价")
    amount: Mapped[Decimal] = mapped_column(Numeric(18, 2), nullable=False, comment="金额")
    tax_rate: Mapped[Decimal | None] = mapped_column(Numeric(5, 2), comment="税率(%)")
    tax_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 2), nullable=False, default=Decimal("0.00"), comment="税额"
    )

    invoice = relationship("Invoice", back_populates="items")
