"""版本检查 - 启动时异步检查 PyPI 最新版本"""

import json
import logging
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# 缓存文件路径（避免每次命令都请求 PyPI）
_CACHE_DIR = Path.home() / ".finance-tax"
_CACHE_FILE = _CACHE_DIR / ".version_cache.json"
# 检查间隔: 6 小时
_CHECK_INTERVAL = 6 * 3600
# PyPI JSON API
_PYPI_URL = "https://pypi.org/pypi/finance-tax/json"

PACKAGE_NAME = "finance-tax"


def _parse_version(v: str) -> tuple[int, ...]:
    """将版本字符串解析为可比较的元组"""
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except (ValueError, AttributeError):
        return (0,)


def _read_cache() -> dict[str, Any] | None:
    """读取版本缓存"""
    try:
        if _CACHE_FILE.exists():
            data = json.loads(_CACHE_FILE.read_text(encoding="utf-8"))
            return data
    except Exception:
        pass
    return None


def _write_cache(latest_version: str) -> None:
    """写入版本缓存"""
    try:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _CACHE_FILE.write_text(
            json.dumps({
                "latest_version": latest_version,
                "checked_at": time.time(),
            }),
            encoding="utf-8",
        )
    except Exception:
        pass


def _fetch_latest_version() -> str | None:
    """从 PyPI 获取最新版本号（使用 urllib，无额外依赖）"""
    try:
        import urllib.request
        req = urllib.request.Request(_PYPI_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("info", {}).get("version")
    except Exception:
        logger.debug("版本检查请求失败", exc_info=True)
        return None


def check_for_update(current_version: str) -> dict[str, Any] | None:
    """检查是否有新版本可用

    返回:
        None — 无需更新或检查失败
        {"current": "0.1.0", "latest": "0.2.0", "update_cmd": "..."} — 有新版本

    特性:
        - 6 小时内只检查一次（缓存）
        - 网络失败静默跳过，不影响正常使用
        - 超时 3 秒
    """
    try:
        # 读缓存，未过期则用缓存
        cache = _read_cache()
        if cache:
            elapsed = time.time() - cache.get("checked_at", 0)
            if elapsed < _CHECK_INTERVAL:
                latest = cache.get("latest_version", "")
                if latest and _parse_version(latest) > _parse_version(current_version):
                    return {
                        "current": current_version,
                        "latest": latest,
                        "update_cmd": f"uv pip install --upgrade {PACKAGE_NAME}",
                    }
                return None

        # 从 PyPI 获取
        latest = _fetch_latest_version()
        if not latest:
            # 包未发布或网络不可达，写缓存避免频繁重试
            _write_cache(current_version)
            return None

        _write_cache(latest)

        if _parse_version(latest) > _parse_version(current_version):
            return {
                "current": current_version,
                "latest": latest,
                "update_cmd": f"uv pip install --upgrade {PACKAGE_NAME}",
            }
    except Exception:
        logger.debug("版本检查异常", exc_info=True)

    return None
