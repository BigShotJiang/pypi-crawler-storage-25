"""发票查验模块 — 对接阿里云云市场发票查验API

API来源: https://market.aliyun.com/detail/cmapi00069751
"""

import urllib.parse
from typing import Any

import urllib3


API_URL = "https://kzinvoice.market.alicloudapi.com/api/invoice/checkv2"

# 发票类型编码映射
INVOICE_TYPE_MAP = {
    "0100": "增值税专用发票",
    "0200": "增值税普通发票",
    "0400": "机动车销售统一发票",
    "0500": "二手车销售统一发票",
    "0700": "通行费电子发票",
    "0800": "货物运输业增值税专用发票",
    "0900": "增值税电子专用发票",
    "0910": "电子发票(普通发票)",
    "0920": "电子发票(增值税专用发票)",
}


class InvoiceVerifier:
    """发票查验器"""

    def __init__(self, appcode: str):
        self.appcode = appcode
        self.http = urllib3.PoolManager()

    def verify(
        self,
        fphm: str,
        kprq: str,
        je: str,
        fpdm: str = "",
        jym: str = "",
    ) -> dict[str, Any]:
        """查验发票真伪

        Args:
            fphm: 发票号码（必填）
            kprq: 开票日期，格式 YYYYMMDD（必填）
            je: 金额/价税合计（必填）
            fpdm: 发票代码（全电发票可不填）
            jym: 校验码后6位（专票可不填）

        Returns:
            查验结果字典
        """
        headers = {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Authorization": "APPCODE " + self.appcode,
        }

        body = {
            "fphm": fphm,
            "kprq": kprq,
            "je": je,
        }
        if fpdm:
            body["fpdm"] = fpdm
        if jym:
            body["jym"] = jym

        post_data = urllib.parse.urlencode(body).encode("utf-8")

        try:
            response = self.http.request("POST", API_URL, body=post_data, headers=headers)
        except Exception as e:
            return {
                "status": "error",
                "message": f"网络请求失败: {e}",
            }

        if response.status == 403:
            return {
                "status": "error",
                "message": "AppCode无效或已过期，请检查配置。",
            }

        if response.status != 200:
            return {
                "status": "error",
                "message": f"API请求失败，HTTP状态码: {response.status}",
            }

        try:
            import json
            resp = json.loads(response.data.decode("utf-8"))
        except Exception as e:
            return {
                "status": "error",
                "message": f"API响应解析失败: {e}",
            }

        if not resp.get("success"):
            return {
                "status": "error",
                "message": resp.get("msg", "查验失败"),
            }

        data = resp.get("data", {})
        if not data.get("success"):
            return {
                "status": "error",
                "message": data.get("msg", "查验失败"),
            }

        # 提取核心信息
        detail = data.get("data", {})
        fplx_code = data.get("fplx", "")
        fplx_name = INVOICE_TYPE_MAP.get(fplx_code, fplx_code)

        is_cancelled = detail.get("zfbz", "0") != "0"

        # 提取货物/服务明细
        items = []
        for hw in detail.get("hwxx", []):
            items.append({
                "name": hw.get("hwmc", ""),
                "amount": hw.get("je", ""),
                "tax_amount": hw.get("se", ""),
                "tax_rate": hw.get("slv", ""),
                "quantity": hw.get("sl", ""),
                "unit_price": hw.get("dj", ""),
                "unit": hw.get("dw", ""),
            })

        return {
            "status": "ok",
            "verify_status": "valid",
            "message": "查验成功",
            "invoice_number": detail.get("fphm", fphm),
            "invoice_code": detail.get("fpdm", fpdm),
            "invoice_date": detail.get("kprq", ""),
            "invoice_type": fplx_name,
            "invoice_type_code": fplx_code,
            "seller_name": detail.get("xfmc", ""),
            "seller_tax_id": detail.get("xfsbh", ""),
            "buyer_name": detail.get("gfmc", ""),
            "buyer_tax_id": detail.get("gfsbh", ""),
            "amount": detail.get("je", ""),
            "tax_amount": detail.get("se", ""),
            "total_amount": detail.get("jshj", ""),
            "is_cancelled": is_cancelled,
            "check_count": detail.get("cycs", 0),
            "items": items,
        }
