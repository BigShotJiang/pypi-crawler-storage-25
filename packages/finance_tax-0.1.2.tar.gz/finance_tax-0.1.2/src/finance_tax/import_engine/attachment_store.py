"""附件存储引擎 - 文件复制、去重、路径管理"""

import hashlib
import mimetypes
import shutil
from datetime import date
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from finance_tax.models.attachment import Attachment

# 允许的 MIME 类型前缀
ALLOWED_MIME_PREFIXES = ("image/", "application/pdf", "application/ofd")
# 单文件最大 20MB
MAX_FILE_SIZE = 20 * 1024 * 1024

VALID_ENTITY_TYPES = ("invoice", "bank_transaction", "voucher")
VALID_CATEGORIES = ("invoice_photo", "e_invoice", "bank_cert", "other")


def _compute_sha256(file_path: Path) -> str:
    """计算文件 SHA-256"""
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _guess_mime(file_path: Path) -> str:
    mime, _ = mimetypes.guess_type(str(file_path))
    return mime or "application/octet-stream"


def _attachments_root(data_dir: Path) -> Path:
    return data_dir / "attachments"


def _storage_dir(
    data_dir: Path,
    company_id: int,
    entity_type: str,
    ref_date: date | None = None,
) -> Path:
    """生成存储目录: attachments/{company_id}/{entity_type}/{YYYY-MM}/"""
    period = (ref_date or date.today()).strftime("%Y-%m")
    d = _attachments_root(data_dir) / str(company_id) / entity_type / period
    d.mkdir(parents=True, exist_ok=True)
    return d


class AttachmentStore:
    """附件存储管理"""

    def __init__(self, session: Session, company_id: int, data_dir: Path):
        self.session = session
        self.company_id = company_id
        self.data_dir = data_dir

    def add(
        self,
        source_path: str | Path,
        entity_type: str,
        entity_id: int,
        category: str = "other",
        memo: str | None = None,
        ref_date: date | None = None,
    ) -> Attachment:
        """添加附件 — 复制文件到托管目录并入库

        Args:
            source_path: 源文件绝对路径
            entity_type: 关联对象类型 (invoice/bank_transaction/voucher)
            entity_id: 关联对象 ID
            category: 附件类别
            memo: 备注
            ref_date: 参考日期（用于文件归档目录，默认今天）

        Returns:
            Attachment 对象

        Raises:
            FileNotFoundError: 源文件不存在
            ValueError: 参数校验失败
        """
        src = Path(source_path)
        if not src.is_file():
            raise FileNotFoundError(f"文件不存在: {source_path}")

        # 参数校验
        if entity_type not in VALID_ENTITY_TYPES:
            raise ValueError(
                f"无效的 entity_type: {entity_type}，"
                f"支持: {', '.join(VALID_ENTITY_TYPES)}"
            )
        if category not in VALID_CATEGORIES:
            raise ValueError(
                f"无效的 category: {category}，"
                f"支持: {', '.join(VALID_CATEGORIES)}"
            )

        # 文件大小检查
        file_size = src.stat().st_size
        if file_size > MAX_FILE_SIZE:
            raise ValueError(
                f"文件过大: {file_size / 1024 / 1024:.1f}MB，上限 {MAX_FILE_SIZE // 1024 // 1024}MB"
            )

        # 计算哈希和 MIME
        file_hash = _compute_sha256(src)
        mime_type = _guess_mime(src)

        # 去重检查 — 同一业务对象下不重复上传同一文件
        existing = (
            self.session.query(Attachment)
            .filter_by(
                company_id=self.company_id,
                entity_type=entity_type,
                entity_id=entity_id,
                file_hash=file_hash,
            )
            .first()
        )
        if existing:
            raise ValueError(
                f"重复文件: 该附件已存在 (ID={existing.id}, {existing.file_name})"
            )

        # 确定存储路径
        dest_dir = _storage_dir(self.data_dir, self.company_id, entity_type, ref_date)
        ext = src.suffix.lower()
        dest_name = f"{file_hash[:12]}{ext}"
        dest_path = dest_dir / dest_name

        # 如果文件已存在（跨业务对象共享），不重复复制
        if not dest_path.exists():
            shutil.copy2(str(src), str(dest_path))

        # 计算相对路径（相对于 attachments 根目录）
        rel_path = dest_path.relative_to(_attachments_root(self.data_dir))

        att = Attachment(
            company_id=self.company_id,
            entity_type=entity_type,
            entity_id=entity_id,
            file_name=src.name,
            file_path=str(rel_path),
            file_size=file_size,
            file_hash=file_hash,
            mime_type=mime_type,
            category=category,
            memo=memo,
        )
        self.session.add(att)
        self.session.flush()
        return att

    def list_for_entity(
        self, entity_type: str, entity_id: int
    ) -> list[Attachment]:
        """列出某业务对象的所有附件"""
        return (
            self.session.query(Attachment)
            .filter_by(
                company_id=self.company_id,
                entity_type=entity_type,
                entity_id=entity_id,
            )
            .order_by(Attachment.id)
            .all()
        )

    def get(self, attachment_id: int) -> Attachment | None:
        """获取附件详情"""
        return (
            self.session.query(Attachment)
            .filter_by(id=attachment_id, company_id=self.company_id)
            .first()
        )

    def delete(self, attachment_id: int) -> bool:
        """删除附件记录（文件不删除，可能被其他记录引用）"""
        att = self.get(attachment_id)
        if not att:
            return False
        self.session.delete(att)
        self.session.flush()
        return True

    def get_absolute_path(self, attachment: Attachment) -> Path:
        """获取附件的绝对路径"""
        return _attachments_root(self.data_dir) / attachment.file_path

    def copy_to_entity(
        self,
        source_attachment: Attachment,
        target_entity_type: str,
        target_entity_id: int,
    ) -> Attachment:
        """将附件关联到另一个业务对象（发票入账时自动关联到凭证）

        不复制文件，只新增一条数据库记录指向同一文件。
        """
        # 检查目标是否已有该文件
        existing = (
            self.session.query(Attachment)
            .filter_by(
                company_id=self.company_id,
                entity_type=target_entity_type,
                entity_id=target_entity_id,
                file_hash=source_attachment.file_hash,
            )
            .first()
        )
        if existing:
            return existing

        att = Attachment(
            company_id=self.company_id,
            entity_type=target_entity_type,
            entity_id=target_entity_id,
            file_name=source_attachment.file_name,
            file_path=source_attachment.file_path,
            file_size=source_attachment.file_size,
            file_hash=source_attachment.file_hash,
            mime_type=source_attachment.mime_type,
            category=source_attachment.category,
            memo=source_attachment.memo,
        )
        self.session.add(att)
        self.session.flush()
        return att

    def to_dict(self, att: Attachment) -> dict[str, Any]:
        """附件转字典（JSON 输出用）"""
        return {
            "id": att.id,
            "entity_type": att.entity_type,
            "entity_id": att.entity_id,
            "file_name": att.file_name,
            "file_path": str(self.get_absolute_path(att)),
            "file_size": att.file_size,
            "file_hash": att.file_hash,
            "mime_type": att.mime_type,
            "category": att.category,
            "memo": att.memo,
        }
