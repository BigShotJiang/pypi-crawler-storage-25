"""银行流水Excel导入解析器

支持主流银行导出格式，通过列名智能匹配实现自动识别。
"""

import uuid
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

import pandas as pd
from sqlalchemy.orm import Session

from finance_tax.models.transaction import BankTransaction


# 列名映射规则：银行导出Excel中常见的列名 → 标准字段
COLUMN_MAPPINGS: dict[str, list[str]] = {
    "trans_date": [
        "交易日期", "日期", "记账日期", "交易时间", "入账日期",
        "Transaction Date", "Date", "Value Date",
    ],
    "trans_purpose": [
        "交易用途", "用途", "付款事由", "Purpose",
    ],
    "debit_amount": [
        "借方金额", "支出金额", "支出", "借方发生额", "付款金额",
        "Debit", "Debit Amount", "Withdrawal",
    ],
    "credit_amount": [
        "贷方金额", "收入金额", "收入", "贷方发生额", "收款金额",
        "Credit", "Credit Amount", "Deposit",
    ],
    "amount": [
        "交易金额", "金额", "发生额", "Amount", "Transaction Amount",
    ],
    "balance": [
        "余额", "账户余额", "对账余额", "Balance", "Available Balance",
    ],
    "summary": [
        "摘要", "交易摘要", "用途", "附言", "交易说明",
        "Summary", "Description", "Narrative", "Remarks",
    ],
    "counterparty": [
        "对方户名", "对方名称", "收付款人", "交易对手",
        "Counterparty", "Payee", "Payer",
    ],
    "counterparty_account": [
        "对方账号", "对方卡号", "Counterparty Account",
    ],
    "counterparty_bank": [
        "对方开户行", "对方银行", "对方账号开户行", "Counterparty Bank",
    ],
    "reference_no": [
        "流水号", "交易流水号", "凭证号", "交易参考号", "序号",
        "核心唯一流水号", "业务流水号",
        "Reference", "Transaction ID", "Ref No",
    ],
    "memo": [
        "备注", "附注", "Memo", "Note",
    ],
}


class BankStatementParser:
    """银行流水Excel解析器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id

    def _match_columns(self, df_columns: list[str]) -> dict[str, str]:
        """将Excel列名映射到标准字段名"""
        mapping = {}
        for standard_field, aliases in COLUMN_MAPPINGS.items():
            for col in df_columns:
                col_clean = str(col).strip()
                if col_clean in aliases:
                    mapping[standard_field] = col
                    break
        return mapping

    def _parse_date(self, value: Any) -> date | None:
        """解析日期值"""
        if pd.isna(value):
            return None
        if isinstance(value, (datetime, date)):
            return value if isinstance(value, date) else value.date()
        s = str(value).strip()
        # 处理纯数字时间戳: 14位(YYYYMMDDHHmmss) 或 8位(YYYYMMDD)
        digits_only = s.replace(" ", "")
        if digits_only.isdigit() and len(digits_only) >= 8:
            try:
                return datetime.strptime(digits_only[:8], "%Y%m%d").date()
            except ValueError:
                pass
        for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y%m%d", "%Y年%m月%d日", "%m/%d/%Y"):
            try:
                return datetime.strptime(s[:10], fmt).date()
            except ValueError:
                continue
        return None

    def _build_summary(self, row: pd.Series, col_map: dict[str, str]) -> str:
        """构建摘要：合并「摘要」和「交易用途」字段"""
        parts = []
        if "summary" in col_map:
            v = str(row.get(col_map["summary"], "")).strip()
            if v and v.lower() != "nan":
                parts.append(v)
        if "trans_purpose" in col_map:
            v = str(row.get(col_map["trans_purpose"], "")).strip()
            if v and v.lower() != "nan" and v not in parts:
                parts.append(v)
        return "-".join(parts) if parts else ""

    def _parse_decimal(self, value: Any) -> Decimal:
        """解析金额值"""
        if pd.isna(value) or value is None:
            return Decimal("0.00")
        s = str(value).strip().replace(",", "").replace("，", "")
        if not s or s == "-":
            return Decimal("0.00")
        try:
            return Decimal(s).quantize(Decimal("0.01"))
        except InvalidOperation:
            return Decimal("0.00")

    def parse_excel(
        self,
        file_path: str | Path,
        sheet_name: str | int = 0,
        bank_name: str = "",
        account_number: str = "",
        skip_rows: int = 0,
    ) -> list[dict[str, Any]]:
        """解析银行流水Excel文件，返回标准化记录列表"""
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")

        df = pd.read_excel(
            file_path, sheet_name=sheet_name, skiprows=skip_rows,
            engine="openpyxl", dtype=str,
        )

        # 自动从 Sheet 名提取账号（平安银行等以账号命名Sheet）
        if not account_number:
            import openpyxl as _xl
            _wb = _xl.load_workbook(file_path, read_only=True)
            _sheet_name = _wb.sheetnames[0] if isinstance(sheet_name, int) else sheet_name
            if _sheet_name and _sheet_name.isdigit() and len(_sheet_name) >= 10:
                account_number = _sheet_name
            _wb.close()

        # 自动匹配列
        col_map = self._match_columns(df.columns.tolist())
        if "trans_date" not in col_map:
            raise ValueError(
                f"无法识别日期列。当前Excel列名: {df.columns.tolist()}\n"
                f"请确保包含以下列名之一: {COLUMN_MAPPINGS['trans_date']}"
            )

        # 冲正标志列检测（平安银行: '_'=正常, 'C'=冲正）
        reversal_col = None
        for c in df.columns:
            if "冲正" in str(c):
                reversal_col = c
                break

        records = []
        for _, row in df.iterrows():
            # 跳过冲正交易
            if reversal_col and str(row.get(reversal_col, "")).strip().upper() == "C":
                continue

            trans_date = self._parse_date(row.get(col_map.get("trans_date", ""), None))
            if not trans_date:
                continue

            # 处理金额：有些银行用单独的借贷列，有些用正负金额
            debit = Decimal("0.00")
            credit = Decimal("0.00")

            if "debit_amount" in col_map and "credit_amount" in col_map:
                debit = self._parse_decimal(row.get(col_map["debit_amount"]))
                credit = self._parse_decimal(row.get(col_map["credit_amount"]))
            elif "amount" in col_map:
                amount = self._parse_decimal(row.get(col_map["amount"]))
                if amount > 0:
                    credit = amount
                elif amount < 0:
                    debit = abs(amount)

            if debit == 0 and credit == 0:
                continue

            record = {
                "trans_date": trans_date,
                "debit_amount": debit,
                "credit_amount": credit,
                "balance": self._parse_decimal(row.get(col_map.get("balance", ""), None)),
                "summary": self._build_summary(row, col_map),
                "counterparty": str(row.get(col_map.get("counterparty", ""), "")).strip() if col_map.get("counterparty") else "",
                "counterparty_account": str(row.get(col_map.get("counterparty_account", ""), "")).strip() if col_map.get("counterparty_account") else "",
                "counterparty_bank": str(row.get(col_map.get("counterparty_bank", ""), "")).strip() if col_map.get("counterparty_bank") else "",
                "reference_no": str(row.get(col_map.get("reference_no", ""), "")).strip() if col_map.get("reference_no") else "",
                "memo": str(row.get(col_map.get("memo", ""), "")).strip() if col_map.get("memo") else "",
                "bank_name": bank_name,
                "account_number": account_number,
            }
            # 清理 nan 字符串
            for k, v in record.items():
                if isinstance(v, str) and v.lower() == "nan":
                    record[k] = ""

            records.append(record)

        return records

    def import_to_db(
        self,
        file_path: str | Path,
        bank_name: str = "",
        account_number: str = "",
        sheet_name: str | int = 0,
        skip_rows: int = 0,
    ) -> dict[str, Any]:
        """解析并导入银行流水到数据库"""
        records = self.parse_excel(
            file_path,
            sheet_name=sheet_name,
            bank_name=bank_name,
            account_number=account_number,
            skip_rows=skip_rows,
        )

        batch_id = f"BANK-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6]}"
        imported = 0
        skipped = 0

        for rec in records:
            # 简单去重：同日期、同金额、同摘要
            existing = (
                self.session.query(BankTransaction)
                .filter_by(
                    company_id=self.company_id,
                    trans_date=rec["trans_date"],
                    debit_amount=rec["debit_amount"],
                    credit_amount=rec["credit_amount"],
                    summary=rec["summary"],
                )
                .first()
            )
            if existing:
                skipped += 1
                continue

            txn = BankTransaction(
                company_id=self.company_id,
                bank_name=rec["bank_name"],
                account_number=rec["account_number"],
                trans_date=rec["trans_date"],
                debit_amount=rec["debit_amount"],
                credit_amount=rec["credit_amount"],
                balance=rec["balance"] if rec["balance"] is not None else None,
                summary=rec["summary"],
                counterparty=rec["counterparty"],
                counterparty_account=rec["counterparty_account"],
                counterparty_bank=rec["counterparty_bank"],
                reference_no=rec["reference_no"],
                memo=rec["memo"],
                import_batch=batch_id,
                is_processed=False,
            )
            self.session.add(txn)
            imported += 1

        self.session.flush()
        return {
            "batch_id": batch_id,
            "total_records": len(records),
            "imported": imported,
            "skipped": skipped,
            "file": str(file_path),
        }
