"""发票录入模块

支持:
1. 单张发票参数录入（Agent 识别后通过 CLI 参数传入）
2. 批量发票 JSON 录入
"""

import uuid
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

from sqlalchemy.orm import Session

from finance_tax.models.invoice import Invoice


class InvoiceParser:
    """发票录入处理器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id

    def _parse_date(self, value: Any) -> date | None:
        if isinstance(value, date):
            return value
        if isinstance(value, datetime):
            return value.date()
        if not value:
            return None
        s = str(value).strip()
        for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y%m%d", "%Y年%m月%d日"):
            try:
                return datetime.strptime(s[:10], fmt).date()
            except ValueError:
                continue
        return None

    def _parse_decimal(self, value: Any) -> Decimal:
        if value is None or value == "":
            return Decimal("0.00")
        s = str(value).strip().replace(",", "").replace("，", "").replace("%", "")
        if not s or s == "-":
            return Decimal("0.00")
        try:
            return Decimal(s).quantize(Decimal("0.01"))
        except InvalidOperation:
            return Decimal("0.00")

    def _build_invoice(self, data: dict[str, Any]) -> Invoice:
        """从字典构建 Invoice 对象"""
        amount = self._parse_decimal(data.get("amount", 0))
        tax_amount = self._parse_decimal(data.get("tax_amount", 0))
        total_amount = self._parse_decimal(data.get("total_amount", ""))

        # 自动计算缺失值
        if total_amount == 0 and amount > 0:
            total_amount = amount + tax_amount
        if amount == 0 and total_amount > 0:
            amount = total_amount - tax_amount

        tax_rate = self._parse_decimal(data.get("tax_rate", ""))
        if tax_rate == 0 and amount > 0 and tax_amount > 0:
            tax_rate = (tax_amount / amount * 100).quantize(Decimal("0.01"))

        inv_date = self._parse_date(data.get("invoice_date"))
        if not inv_date:
            raise ValueError(f"无效的开票日期: {data.get('invoice_date')}")

        direction = data.get("direction", "input")
        if direction not in ("input", "output"):
            raise ValueError(f"方向必须是 input 或 output，当前: {direction}")

        invoice_type = data.get("invoice_type", "vat_normal")

        return Invoice(
            company_id=self.company_id,
            invoice_number=str(data["invoice_number"]).strip(),
            invoice_code=data.get("invoice_code") or None,
            invoice_date=inv_date,
            invoice_type=invoice_type,
            direction=direction,
            amount=amount,
            tax_amount=tax_amount,
            total_amount=total_amount,
            tax_rate=tax_rate if tax_rate else None,
            seller_name=data.get("seller_name") or None,
            seller_tax_id=data.get("seller_tax_id") or None,
            buyer_name=data.get("buyer_name") or None,
            buyer_tax_id=data.get("buyer_tax_id") or None,
            expense_category=data.get("expense_category") or None,
            memo=data.get("memo") or None,
            is_processed=False,
        )

    def add_invoice(self, **kwargs) -> dict[str, Any]:
        """录入单张发票

        Args:
            invoice_number: 发票号码
            invoice_date: 开票日期
            direction: 方向 (input/output)
            amount: 不含税金额
            以及其他可选字段...

        Returns:
            录入结果字典
        """
        inv_number = str(kwargs.get("invoice_number", "")).strip()
        if not inv_number:
            return {"status": "error", "message": "发票号码不能为空"}

        # 去重检查
        existing = (
            self.session.query(Invoice)
            .filter_by(company_id=self.company_id, invoice_number=inv_number)
            .first()
        )
        if existing:
            return {
                "status": "skipped",
                "message": f"发票号码 {inv_number} 已存在 (ID: {existing.id})",
                "invoice_id": existing.id,
                "invoice_number": inv_number,
            }

        try:
            invoice = self._build_invoice(kwargs)
        except ValueError as e:
            return {"status": "error", "message": str(e)}

        self.session.add(invoice)
        self.session.flush()

        return {
            "status": "ok",
            "invoice_id": invoice.id,
            "invoice_number": invoice.invoice_number,
            "invoice_date": invoice.invoice_date,
            "direction": invoice.direction,
            "amount": invoice.amount,
            "tax_amount": invoice.tax_amount,
            "total_amount": invoice.total_amount,
        }

    def batch_add_invoices(self, invoices: list[dict]) -> dict[str, Any]:
        """批量录入发票

        Args:
            invoices: 发票字典列表

        Returns:
            批量录入结果
        """
        imported = 0
        skipped = 0
        errors: list[str] = []

        for i, data in enumerate(invoices):
            inv_number = str(data.get("invoice_number", "")).strip()
            if not inv_number:
                errors.append(f"第{i+1}条: 缺少发票号码")
                continue

            # 去重检查
            existing = (
                self.session.query(Invoice)
                .filter_by(company_id=self.company_id, invoice_number=inv_number)
                .first()
            )
            if existing:
                skipped += 1
                continue

            try:
                invoice = self._build_invoice(data)
                self.session.add(invoice)
                imported += 1
            except ValueError as e:
                errors.append(f"第{i+1}条({inv_number}): {e}")
                continue

        self.session.flush()

        return {
            "status": "ok",
            "total": len(invoices),
            "imported": imported,
            "skipped": skipped,
            "errors": errors,
        }
