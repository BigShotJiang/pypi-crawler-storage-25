"""增值税计算引擎

支持小规模纳税人和一般纳税人（预留）。
"""

import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from finance_tax.models.company import Company
from finance_tax.models.invoice import Invoice
from finance_tax.models.tax import TaxDeclaration
from finance_tax.utils import get_data_dir, json_safe


class VATCalculator:
    """增值税计算器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id
        self._load_rules()

    def _load_rules(self):
        with open(get_data_dir() / "tax_rules.json", "r", encoding="utf-8") as f:
            rules = json.load(f)
        self.vat_rules = rules["vat"]
        self.surcharge_rules = rules["surcharge"]

    def _get_company(self) -> Company:
        company = self.session.query(Company).filter_by(id=self.company_id).first()
        if not company:
            raise ValueError(f"公司ID {self.company_id} 不存在")
        return company

    def calculate_small_scale(
        self,
        period_start: str,
        period_end: str,
        frequency: str = "quarterly",
    ) -> dict[str, Any]:
        """小规模纳税人增值税计算

        Args:
            period_start: 起始期间 YYYY-MM
            period_end: 截止期间 YYYY-MM
            frequency: quarterly=季度, monthly=月度
        """
        rules = self.vat_rules["small_scale"]
        rate = Decimal(str(rules["rate"])) / 100

        # 查询期间内的销项发票
        output_invoices = (
            self.session.query(
                func.coalesce(func.sum(Invoice.total_amount), 0).label("total_sales"),
                func.coalesce(func.sum(Invoice.tax_amount), 0).label("total_tax"),
                func.coalesce(func.sum(Invoice.amount), 0).label("total_amount"),
            )
            .filter(
                Invoice.company_id == self.company_id,
                Invoice.direction == "output",
                Invoice.invoice_date >= date.fromisoformat(f"{period_start}-01"),
                Invoice.invoice_date <= self._period_end_date(period_end),
            )
            .first()
        )

        total_sales = Decimal(str(output_invoices.total_sales))
        total_amount = Decimal(str(output_invoices.total_amount))

        # 判断是否免征
        threshold = Decimal(str(
            rules["threshold_quarterly"] if frequency == "quarterly"
            else rules["threshold_monthly"]
        ))
        is_exempt = total_sales <= threshold

        if is_exempt:
            tax_due = Decimal("0.00")
            exemption = total_amount * rate
        else:
            tax_due = total_amount * rate
            exemption = Decimal("0.00")

        result = {
            "taxpayer_type": "small_scale",
            "period": f"{period_start} ~ {period_end}",
            "frequency": frequency,
            "sales_total": total_sales,
            "sales_amount_excl_tax": total_amount,
            "tax_rate": rate * 100,
            "threshold": threshold,
            "is_exempt": is_exempt,
            "tax_due": tax_due,
            "tax_exemption": exemption,
            "tax_payable": tax_due,
        }

        return result

    def calculate(
        self,
        period_start: str,
        period_end: str,
        frequency: str = "quarterly",
    ) -> dict[str, Any]:
        """根据纳税人类型自动选择计算方式"""
        company = self._get_company()
        if company.taxpayer_type == "small_scale":
            return self.calculate_small_scale(period_start, period_end, frequency)
        else:
            # 一般纳税人预留
            return self._calculate_general(period_start, period_end)

    def _calculate_general(
        self, period_start: str, period_end: str
    ) -> dict[str, Any]:
        """一般纳税人增值税计算（预留框架）"""
        # 销项税额
        output_result = (
            self.session.query(
                func.coalesce(func.sum(Invoice.tax_amount), 0).label("output_tax"),
                func.coalesce(func.sum(Invoice.amount), 0).label("sales_amount"),
            )
            .filter(
                Invoice.company_id == self.company_id,
                Invoice.direction == "output",
                Invoice.invoice_date >= date.fromisoformat(f"{period_start}-01"),
                Invoice.invoice_date <= self._period_end_date(period_end),
            )
            .first()
        )

        # 进项税额
        input_result = (
            self.session.query(
                func.coalesce(func.sum(Invoice.tax_amount), 0).label("input_tax"),
            )
            .filter(
                Invoice.company_id == self.company_id,
                Invoice.direction == "input",
                Invoice.is_verified == True,
                Invoice.invoice_date >= date.fromisoformat(f"{period_start}-01"),
                Invoice.invoice_date <= self._period_end_date(period_end),
            )
            .first()
        )

        output_tax = Decimal(str(output_result.output_tax))
        input_tax = Decimal(str(input_result.input_tax))
        tax_payable = max(output_tax - input_tax, Decimal("0.00"))

        return {
            "taxpayer_type": "general",
            "period": f"{period_start} ~ {period_end}",
            "output_tax": output_tax,
            "input_tax": input_tax,
            "tax_payable": tax_payable,
            "carried_forward": max(input_tax - output_tax, Decimal("0.00")),
        }

    def save_declaration(self, calc_result: dict[str, Any]) -> TaxDeclaration:
        """保存增值税申报记录"""
        period_parts = calc_result["period"].split(" ~ ")
        ps, pe = period_parts[0], period_parts[1]

        decl = TaxDeclaration(
            company_id=self.company_id,
            tax_type="vat",
            period=pe,
            period_start=date.fromisoformat(f"{ps}-01"),
            period_end=self._period_end_date(pe),
            frequency=calc_result.get("frequency", "quarterly"),
            taxable_amount=calc_result.get("sales_amount_excl_tax", Decimal("0.00")),
            tax_rate=calc_result.get("tax_rate", Decimal("0.00")),
            tax_due=calc_result.get("tax_due", Decimal("0.00")),
            tax_deduction=calc_result.get("tax_exemption", Decimal("0.00")),
            tax_payable=calc_result.get("tax_payable", Decimal("0.00")),
            report_data=json_safe(calc_result),
            status="calculated",
        )
        self.session.add(decl)
        self.session.flush()
        return decl

    @staticmethod
    def _period_end_date(period: str) -> date:
        """获取期间最后一天"""
        import calendar
        year, month = int(period[:4]), int(period[5:7])
        last_day = calendar.monthrange(year, month)[1]
        return date(year, month, last_day)
