"""印花税计算引擎"""

import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from finance_tax.models.company import Company
from finance_tax.models.tax import TaxDeclaration
from finance_tax.utils import get_data_dir, json_safe


class StampTaxCalculator:
    """印花税计算器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id
        self._load_rules()

    def _load_rules(self):
        with open(get_data_dir() / "tax_rules.json", "r", encoding="utf-8") as f:
            rules = json.load(f)
        self.stamp_rules = rules["stamp_tax"]

    def _get_company(self) -> Company:
        company = self.session.query(Company).filter_by(id=self.company_id).first()
        if not company:
            raise ValueError(f"公司ID {self.company_id} 不存在")
        return company

    def calculate(
        self,
        contract_type: str,
        contract_amount: Decimal,
        period: str,
    ) -> dict[str, Any]:
        """计算印花税

        Args:
            contract_type: 合同类型（对应 tax_rules.json 中的 key）
            contract_amount: 合同金额
            period: 所属期间 YYYY-MM
        """
        company = self._get_company()

        if contract_type not in self.stamp_rules:
            available = [
                k for k in self.stamp_rules.keys()
                if k not in ("description", "quarterly_declaration", "small_scale_half_exemption",
                             "small_scale_half_exemption_description")
            ]
            raise ValueError(
                f"不支持的合同类型: {contract_type}\n可选类型: {available}"
            )

        rule = self.stamp_rules[contract_type]
        rate = Decimal(str(rule["rate"])) / 10000  # 万分比转换

        tax_before_exemption = (contract_amount * rate).quantize(Decimal("0.01"))

        # 小规模纳税人减半征收
        is_half_exempt = (
            self.stamp_rules.get("small_scale_half_exemption", False)
            and company.taxpayer_type == "small_scale"
        )
        if is_half_exempt:
            tax_due = (tax_before_exemption / 2).quantize(Decimal("0.01"))
            exemption = tax_before_exemption - tax_due
        else:
            tax_due = tax_before_exemption
            exemption = Decimal("0.00")

        return {
            "contract_type": contract_type,
            "contract_type_name": rule["description"],
            "contract_amount": contract_amount,
            "rate_per_10000": Decimal(str(rule["rate"])),
            "tax_before_exemption": tax_before_exemption,
            "is_half_exempt": is_half_exempt,
            "tax_exemption": exemption,
            "tax_due": tax_due,
            "period": period,
        }

    def calculate_batch(
        self,
        contracts: list[dict[str, Any]],
        period: str,
    ) -> dict[str, Any]:
        """批量计算印花税

        Args:
            contracts: [{"type": "purchase_sale_contract", "amount": 100000}, ...]
            period: 所属期间
        """
        results = []
        total_tax = Decimal("0.00")

        for contract in contracts:
            result = self.calculate(
                contract_type=contract["type"],
                contract_amount=Decimal(str(contract["amount"])),
                period=period,
            )
            results.append(result)
            total_tax += result["tax_due"]

        return {
            "period": period,
            "items": results,
            "total_tax_due": total_tax,
            "item_count": len(results),
        }

    def save_declaration(self, calc_result: dict[str, Any]) -> TaxDeclaration:
        """保存印花税申报记录"""
        import calendar
        period = calc_result["period"]
        year, month = int(period[:4]), int(period[5:7])

        decl = TaxDeclaration(
            company_id=self.company_id,
            tax_type="stamp",
            period=period,
            period_start=date(year, month, 1),
            period_end=date(year, month, calendar.monthrange(year, month)[1]),
            frequency="quarterly",
            taxable_amount=sum(
                item["contract_amount"] for item in calc_result.get("items", [])
            ),
            tax_due=calc_result["total_tax_due"],
            tax_payable=calc_result["total_tax_due"],
            report_data=json_safe(calc_result),
            status="calculated",
        )
        self.session.add(decl)
        self.session.flush()
        return decl
