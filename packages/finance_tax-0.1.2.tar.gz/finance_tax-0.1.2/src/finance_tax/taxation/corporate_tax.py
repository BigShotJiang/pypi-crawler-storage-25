"""企业所得税计算引擎"""

import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from finance_tax.models.company import Company
from finance_tax.models.tax import TaxDeclaration
from finance_tax.reporting.income_statement import IncomeStatementReport
from finance_tax.utils import get_data_dir, json_safe


class CorporateIncomeTaxCalculator:
    """企业所得税计算器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id
        self._load_rules()

    def _load_rules(self):
        with open(get_data_dir() / "tax_rules.json", "r", encoding="utf-8") as f:
            rules = json.load(f)
        self.cit_rules = rules["corporate_income_tax"]

    def _get_company(self) -> Company:
        company = self.session.query(Company).filter_by(id=self.company_id).first()
        if not company:
            raise ValueError(f"公司ID {self.company_id} 不存在")
        return company

    def calculate_quarterly(
        self,
        year: int,
        quarter: int,
    ) -> dict[str, Any]:
        """季度预缴企业所得税计算

        Args:
            year: 年度
            quarter: 季度 (1-4)
        """
        # 确定季度的起止期间
        quarter_months = {
            1: ("01", "03"),
            2: ("04", "06"),
            3: ("07", "09"),
            4: ("10", "12"),
        }
        if quarter not in quarter_months:
            raise ValueError(f"无效季度: {quarter}")

        # 年初到本季度末的累计利润
        year_start = f"{year}-01"
        quarter_end = f"{year}-{quarter_months[quarter][1]}"

        income_report = IncomeStatementReport(self.session, self.company_id)
        profit_data = income_report.generate(
            period=quarter_end, period_start=year_start
        )
        total_profit = profit_data["items"]["四、利润总额"]

        # 查询本年已预缴的所得税
        prev_declarations = (
            self.session.query(TaxDeclaration)
            .filter(
                TaxDeclaration.company_id == self.company_id,
                TaxDeclaration.tax_type == "corporate_income",
                TaxDeclaration.period >= year_start,
                TaxDeclaration.period < f"{year}-{quarter_months[quarter][0]}",
            )
            .all()
        )
        already_paid = sum(d.tax_payable for d in prev_declarations)

        # 应纳税所得额（简化处理，未做纳税调整）
        taxable_income = max(total_profit, Decimal("0.00"))

        # 判断是否适用小微企业优惠
        small_micro = self.cit_rules["small_micro"]
        threshold = Decimal(str(small_micro["threshold_taxable_income"]))

        if taxable_income <= threshold:
            # 小微企业优惠税率
            actual_rate = Decimal(str(small_micro["rate_tier1"]["actual_rate"])) / 100
            tax_due = taxable_income * actual_rate
        else:
            # 标准税率
            standard_rate = Decimal(str(self.cit_rules["standard_rate"])) / 100
            tax_due = taxable_income * standard_rate

        # 本季度应补缴
        tax_payable = max(tax_due - already_paid, Decimal("0.00"))

        result = {
            "year": year,
            "quarter": quarter,
            "period": quarter_end,
            "cumulative_profit": total_profit,
            "taxable_income": taxable_income,
            "is_small_micro": taxable_income <= threshold,
            "tax_rate": actual_rate * 100 if taxable_income <= threshold else Decimal(str(self.cit_rules["standard_rate"])),
            "cumulative_tax_due": tax_due,
            "already_paid": already_paid,
            "tax_payable": tax_payable,
        }

        return result

    def save_declaration(self, calc_result: dict[str, Any]) -> TaxDeclaration:
        """保存企业所得税申报记录"""
        import calendar
        period = calc_result["period"]
        year, month = int(period[:4]), int(period[5:7])

        quarter = calc_result["quarter"]
        quarter_start_month = (quarter - 1) * 3 + 1

        decl = TaxDeclaration(
            company_id=self.company_id,
            tax_type="corporate_income",
            period=period,
            period_start=date(year, quarter_start_month, 1),
            period_end=date(year, month, calendar.monthrange(year, month)[1]),
            frequency="quarterly",
            taxable_amount=calc_result["taxable_income"],
            tax_rate=calc_result["tax_rate"],
            tax_due=calc_result["cumulative_tax_due"],
            tax_paid=calc_result["already_paid"],
            tax_payable=calc_result["tax_payable"],
            report_data=json_safe(calc_result),
            status="calculated",
        )
        self.session.add(decl)
        self.session.flush()
        return decl
