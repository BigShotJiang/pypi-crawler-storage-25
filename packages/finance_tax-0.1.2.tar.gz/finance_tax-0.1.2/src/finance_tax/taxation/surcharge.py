"""附加税计算引擎

包括城市维护建设税、教育费附加、地方教育费附加。
"""

import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from finance_tax.models.company import Company
from finance_tax.models.tax import TaxDeclaration
from finance_tax.utils import get_data_dir, json_safe


class SurchargeCalculator:
    """附加税计算器"""

    def __init__(self, session: Session, company_id: int):
        self.session = session
        self.company_id = company_id
        self._load_rules()

    def _load_rules(self):
        with open(get_data_dir() / "tax_rules.json", "r", encoding="utf-8") as f:
            rules = json.load(f)
        self.rules = rules["surcharge"]

    def _get_company(self) -> Company:
        company = self.session.query(Company).filter_by(id=self.company_id).first()
        if not company:
            raise ValueError(f"公司ID {self.company_id} 不存在")
        return company

    def calculate(
        self,
        vat_paid: Decimal,
        period: str,
        location_type: str = "city",
    ) -> dict[str, Any]:
        """计算附加税

        Args:
            vat_paid: 实际缴纳的增值税额（附加税的计税基础）
            period: 所属期间
            location_type: 企业所在地类型 city=市区, county=县城, other=其他
        """
        company = self._get_company()

        # 城市维护建设税
        urban_rates = self.rules["urban_maintenance"]
        urban_rate = Decimal(str(urban_rates.get(location_type, urban_rates["other"]))) / 100
        urban_tax = (vat_paid * urban_rate).quantize(Decimal("0.01"))

        # 教育费附加
        edu_rate = Decimal(str(self.rules["education"]["rate"])) / 100
        edu_tax = (vat_paid * edu_rate).quantize(Decimal("0.01"))

        # 地方教育费附加
        local_edu_rate = Decimal(str(self.rules["local_education"]["rate"])) / 100
        local_edu_tax = (vat_paid * local_edu_rate).quantize(Decimal("0.01"))

        # 小规模纳税人减半征收
        is_small_scale = company.taxpayer_type == "small_scale"
        if is_small_scale:
            urban_tax = (urban_tax / 2).quantize(Decimal("0.01"))
            edu_tax = (edu_tax / 2).quantize(Decimal("0.01"))
            local_edu_tax = (local_edu_tax / 2).quantize(Decimal("0.01"))

        total = urban_tax + edu_tax + local_edu_tax

        return {
            "period": period,
            "vat_basis": vat_paid,
            "location_type": location_type,
            "is_small_scale": is_small_scale,
            "urban_maintenance_tax": urban_tax,
            "urban_maintenance_rate": urban_rate * 100,
            "education_surcharge": edu_tax,
            "education_rate": edu_rate * 100,
            "local_education_surcharge": local_edu_tax,
            "local_education_rate": local_edu_rate * 100,
            "total_surcharge": total,
        }

    def save_declarations(self, calc_result: dict[str, Any]) -> list[TaxDeclaration]:
        """保存附加税申报记录"""
        import calendar
        period = calc_result["period"]
        year, month = int(period[:4]), int(period[5:7])
        start = date(year, month, 1)
        end = date(year, month, calendar.monthrange(year, month)[1])

        declarations = []

        for tax_type, amount_key in [
            ("urban_maintenance", "urban_maintenance_tax"),
            ("education_surcharge", "education_surcharge"),
            ("local_education_surcharge", "local_education_surcharge"),
        ]:
            decl = TaxDeclaration(
                company_id=self.company_id,
                tax_type=tax_type,
                period=period,
                period_start=start,
                period_end=end,
                frequency="quarterly",
                taxable_amount=calc_result["vat_basis"],
                tax_due=calc_result[amount_key],
                tax_payable=calc_result[amount_key],
                report_data=json_safe(calc_result),
                status="calculated",
            )
            self.session.add(decl)
            declarations.append(decl)

        self.session.flush()
        return declarations
