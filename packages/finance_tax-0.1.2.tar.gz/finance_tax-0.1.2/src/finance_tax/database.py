"""数据库初始化与会话管理"""

import logging
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import Session, sessionmaker

from finance_tax.config import AppConfig, load_config
from finance_tax.models.base import Base

logger = logging.getLogger(__name__)

# 全局引擎和会话工厂
_engine = None
_SessionLocal = None

# ------------------------------------------------------------------
# Schema 版本管理
# ------------------------------------------------------------------
# 当前代码期望的 schema 版本号。
# 每次新增/修改表结构时递增，并在 MIGRATIONS 中追加对应的迁移 SQL。
SCHEMA_VERSION = 3

# 迁移字典: {目标版本: [SQL语句列表]}
# 从 version N-1 升级到 version N 时执行对应的 SQL 列表。
# 注意: version 1 是基础版本(由 create_all 创建)，无需迁移 SQL。
MIGRATIONS: dict[int, list[str]] = {
    # v1 → v2: account 表添加迁移记账字段
    2: [
        "ALTER TABLE account ADD COLUMN opening_period VARCHAR(7)",
        "ALTER TABLE account ADD COLUMN ytd_debit NUMERIC(18,2) NOT NULL DEFAULT 0",
        "ALTER TABLE account ADD COLUMN ytd_credit NUMERIC(18,2) NOT NULL DEFAULT 0",
    ],
    # v2 → v3: 新增 attachment 附件表
    3: [
        """CREATE TABLE IF NOT EXISTS attachment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL REFERENCES company(id),
            entity_type VARCHAR(30) NOT NULL,
            entity_id INTEGER NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(500) NOT NULL,
            file_size INTEGER NOT NULL,
            file_hash VARCHAR(64) NOT NULL,
            mime_type VARCHAR(100) NOT NULL DEFAULT 'application/octet-stream',
            category VARCHAR(30) NOT NULL DEFAULT 'other',
            memo TEXT,
            created_at DATETIME NOT NULL DEFAULT (datetime('now')),
            updated_at DATETIME NOT NULL DEFAULT (datetime('now'))
        )""",
    ],
}


def _get_schema_version(engine) -> int:
    """读取当前数据库的 schema 版本号 (SQLite PRAGMA user_version)"""
    with engine.connect() as conn:
        result = conn.execute(text("PRAGMA user_version"))
        return result.scalar() or 0


def _set_schema_version(engine, version: int) -> None:
    """设置数据库的 schema 版本号"""
    with engine.connect() as conn:
        conn.execute(text(f"PRAGMA user_version = {version}"))
        conn.commit()


def _run_migrations(engine) -> None:
    """执行待执行的 schema 迁移

    - 新建数据库: create_all 后直接设为 SCHEMA_VERSION
    - 已有数据库: 检测当前版本，执行缺失的迁移 SQL，再 create_all 补全新表
    """
    current = _get_schema_version(engine)

    if current >= SCHEMA_VERSION:
        return  # 已是最新

    if current == 0:
        # 可能是新建库，也可能是升级前的旧库。
        # 检查是否有表存在来区分。
        with engine.connect() as conn:
            result = conn.execute(
                text("SELECT name FROM sqlite_master WHERE type='table' AND name='company'")
            )
            has_tables = result.scalar() is not None

        if not has_tables:
            # 全新数据库，稍后由 create_all 创建完整 schema
            return  # _finalize_new_db 会在 init_db 末尾设置版本号
        else:
            # 旧库，没有版本号 → 判断已有字段来确定起始版本
            current = _detect_legacy_version(engine)
            logger.info(f"检测到旧数据库，推断 schema 版本: {current}")

    # 依次执行迁移
    for target_ver in sorted(MIGRATIONS.keys()):
        if target_ver <= current:
            continue
        logger.info(f"执行 schema 迁移: v{target_ver - 1} → v{target_ver}")
        with engine.connect() as conn:
            for sql in MIGRATIONS[target_ver]:
                try:
                    conn.execute(text(sql))
                except Exception as e:
                    # 如果列/表已存在则跳过（幂等）
                    err_msg = str(e).lower()
                    if "duplicate column" in err_msg or "already exists" in err_msg:
                        logger.debug(f"跳过已存在的变更: {e}")
                    else:
                        raise
            conn.commit()

    _set_schema_version(engine, SCHEMA_VERSION)
    logger.info(f"schema 迁移完成，当前版本: {SCHEMA_VERSION}")


def _detect_legacy_version(engine) -> int:
    """检测没有版本号的旧数据库当前处于哪个版本

    通过检查特征字段/表是否存在来推断。
    """
    with engine.connect() as conn:
        # 检查 v3 特征: attachment 表
        result = conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table' AND name='attachment'")
        )
        if result.scalar():
            return 3

        # 检查 v2 特征: account.opening_period 列
        try:
            conn.execute(text("SELECT opening_period FROM account LIMIT 1"))
            return 2
        except Exception:
            pass

        # 基础版本
        return 1


def get_engine(config: AppConfig | None = None):
    """获取数据库引擎（单例）"""
    global _engine
    if _engine is None:
        if config is None:
            config = load_config()
        config.data_dir.mkdir(parents=True, exist_ok=True)
        _engine = create_engine(
            config.database_url,
            echo=False,
            pool_pre_ping=True,
        )
        # SQLite 开启外键约束
        if "sqlite" in config.database_url:
            @event.listens_for(_engine, "connect")
            def set_sqlite_pragma(dbapi_connection, connection_record):
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.close()
    return _engine


def get_session_factory(config: AppConfig | None = None) -> sessionmaker:
    """获取会话工厂"""
    global _SessionLocal
    if _SessionLocal is None:
        engine = get_engine(config)
        _SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
    return _SessionLocal


def init_db(config: AppConfig | None = None) -> None:
    """初始化数据库（执行迁移 + 创建所有表）"""
    engine = get_engine(config)
    # 导入所有模型以确保它们被注册
    import finance_tax.models  # noqa: F401
    # 先执行 schema 迁移（旧库 ALTER TABLE 等），再 create_all 补全新表
    _run_migrations(engine)
    Base.metadata.create_all(engine)
    # 新数据库: create_all 后设置版本号
    if _get_schema_version(engine) == 0:
        _set_schema_version(engine, SCHEMA_VERSION)
        logger.info(f"新数据库，schema 版本设为 {SCHEMA_VERSION}")


def reset_engine() -> None:
    """重置引擎（用于测试或切换数据库）"""
    global _engine, _SessionLocal
    if _engine:
        _engine.dispose()
    _engine = None
    _SessionLocal = None


@contextmanager
def get_session(config: AppConfig | None = None) -> Generator[Session, None, None]:
    """获取数据库会话的上下文管理器"""
    factory = get_session_factory(config)
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
