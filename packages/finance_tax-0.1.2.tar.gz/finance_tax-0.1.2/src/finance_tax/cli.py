"""CLI入口 - 记账报税技能包命令行工具

通过 `ft` 命令调用，供 OpenClaw 等 AI Agent 使用。
"""

import json
import sys
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from finance_tax.config import (
    AppConfig, CompanyConfig, load_config, save_config,
    save_company_config, get_company_config_from_file,
)
from finance_tax.database import init_db, get_session

console = Console()


class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, date):
            return obj.isoformat()
        return super().default(obj)


def _json_output(data: Any) -> str:
    return json.dumps(data, cls=DecimalEncoder, ensure_ascii=False, indent=2)


def _ensure_initialized(config: AppConfig) -> int:
    """确保已初始化，返回当前公司ID"""
    if not config.is_initialized or config.current_company_id == 0:
        console.print("[red]尚未初始化，请先运行: ft init[/red]")
        sys.exit(1)
    return config.current_company_id


# ============================================================
# 主命令组
# ============================================================
@click.group()
@click.option("--data-dir", type=click.Path(), default=None, help="数据目录路径")
@click.version_option(package_name="finance-tax", prog_name="finance-tax")
@click.pass_context
def cli(ctx, data_dir):
    """finance-tax: 中国企业记账报税工具"""
    ctx.ensure_object(dict)
    data_path = Path(data_dir) if data_dir else None
    ctx.obj["config"] = load_config(data_path)

    # 版本更新检查
    from finance_tax import __version__
    from finance_tax.version_check import check_for_update
    update_info = check_for_update(__version__)
    if update_info:
        console.print(
            f"[yellow]⬆ 发现新版本 {update_info['latest']}"
            f" (当前 {update_info['current']})。"
            f" 请执行: {update_info['update_cmd']}[/yellow]"
        )


# ============================================================
# init - 初始化账套
# ============================================================
@cli.command()
@click.option("--name", required=True, help="公司名称")
@click.option("--tax-id", default="", help="统一社会信用代码/税号")
@click.option(
    "--taxpayer-type", type=click.Choice(["small_scale", "general"]),
    default="small_scale", help="纳税人类型: small_scale=小规模, general=一般纳税人"
)
@click.option(
    "--standard", type=click.Choice(["small_enterprise", "enterprise"]),
    default="small_enterprise", help="会计准则: small_enterprise=小企业, enterprise=企业"
)
@click.option("--industry", default="信息技术服务", help="所属行业")
@click.option("--year", default=None, type=int, help="启用年度(默认当前年)")
@click.option("--invoice-verify-appcode", default="", help="发票查验API AppCode(阿里云云市场购买)")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def init(ctx, name, tax_id, taxpayer_type, standard, industry, year, invoice_verify_appcode, as_json):
    """初始化账套 - 通过参数配置公司信息、纳税人类型、会计准则

    示例:
      ft init --name "XX科技有限公司" --tax-id 91110000XXXXXXXX
      ft init --name "测试公司" --taxpayer-type general --standard enterprise
    """
    config: AppConfig = ctx.obj["config"]
    year = year or datetime.now().year

    company_config = CompanyConfig(
        name=name,
        tax_id=tax_id,
        taxpayer_type=taxpayer_type,
        accounting_standard=standard,
        industry=industry,
    )

    # 保存配置
    save_company_config(company_config, config.data_dir)

    # 初始化数据库
    init_db(config)

    # 创建公司记录和科目表
    with get_session(config) as session:
        from finance_tax.models.company import Company
        from finance_tax.accounting.chart_of_accounts import ChartOfAccountsManager
        from finance_tax.accounting.period import PeriodManager

        company = Company(
            name=name,
            tax_id=tax_id or None,
            taxpayer_type=taxpayer_type,
            accounting_standard=standard,
            industry=industry,
        )
        session.add(company)
        session.flush()

        # 初始化科目表
        coa = ChartOfAccountsManager(session, company.id)
        count = coa.init_accounts(standard)

        # 初始化会计期间
        pm = PeriodManager(session, company.id)
        pm.init_year_periods(year)

        config.current_company_id = company.id
        if invoice_verify_appcode:
            config.invoice_verify_appcode = invoice_verify_appcode
        save_config(config)

    result = {
        "status": "ok",
        "company": name,
        "tax_id": tax_id or None,
        "taxpayer_type": taxpayer_type,
        "accounting_standard": standard,
        "industry": industry,
        "year": year,
        "accounts_imported": count,
        "data_dir": str(config.data_dir),
    }

    if as_json:
        console.print(_json_output(result))
    else:
        console.print(f"初始化完成")
        console.print(f"  公司: {name}")
        console.print(f"  纳税人类型: {'小规模纳税人' if taxpayer_type == 'small_scale' else '一般纳税人'}")
        console.print(f"  会计准则: {'小企业会计准则' if standard == 'small_enterprise' else '企业会计准则'}")
        console.print(f"  导入科目: {count} 个")
        console.print(f"  数据目录: {config.data_dir}")


# ============================================================
# config - 配置管理
# ============================================================
@cli.group()
def config():
    """配置管理"""
    pass


@config.command("set")
@click.option("--invoice-verify-appcode", default=None, help="发票查验API AppCode(阿里云云市场)")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def config_set(ctx, invoice_verify_appcode, as_json):
    """设置配置项

    示例:
      ft config set --invoice-verify-appcode YOUR_APPCODE
    """
    app_config: AppConfig = ctx.obj["config"]
    updated = {}

    if invoice_verify_appcode is not None:
        app_config.invoice_verify_appcode = invoice_verify_appcode
        updated["invoice_verify_appcode"] = invoice_verify_appcode

    if not updated:
        console.print("[yellow]未指定任何配置项[/yellow]")
        return

    save_config(app_config)

    if as_json:
        console.print(_json_output({"status": "ok", "updated": updated}))
    else:
        console.print("[green]✓ 配置已更新[/green]")
        for k, v in updated.items():
            display_v = v[:8] + "****" if len(v) > 8 else v
            console.print(f"  {k}: {display_v}")


@config.command("show")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def config_show(ctx, as_json):
    """查看当前配置"""
    app_config: AppConfig = ctx.obj["config"]

    data = {
        "data_dir": str(app_config.data_dir),
        "current_company_id": app_config.current_company_id,
        "invoice_verify_appcode": ("****" + app_config.invoice_verify_appcode[-4:]
                                   if len(app_config.invoice_verify_appcode) > 4
                                   else "(未配置)"),
    }

    if as_json:
        console.print(_json_output(data))
    else:
        for k, v in data.items():
            console.print(f"  {k}: {v}")


# ============================================================
# status - 查看状态
# ============================================================
@cli.command()
@click.pass_context
def status(ctx):
    """查看当前账套状态"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.models.company import Company
        from finance_tax.models.voucher import Voucher
        from finance_tax.models.transaction import BankTransaction
        from finance_tax.models.invoice import Invoice
        from finance_tax.models.period import FiscalPeriod

        company = session.query(Company).filter_by(id=company_id).first()
        if not company:
            console.print("[red]公司不存在[/red]")
            return

        voucher_count = session.query(Voucher).filter_by(company_id=company_id).count()
        txn_count = session.query(BankTransaction).filter_by(company_id=company_id).count()
        txn_unprocessed = session.query(BankTransaction).filter_by(
            company_id=company_id, is_processed=False
        ).count()
        inv_count = session.query(Invoice).filter_by(company_id=company_id).count()
        current_period = (
            session.query(FiscalPeriod)
            .filter_by(company_id=company_id, status="open")
            .order_by(FiscalPeriod.period)
            .first()
        )

        info = {
            "公司名称": company.name,
            "税号": company.tax_id or "-",
            "纳税人类型": "小规模纳税人" if company.taxpayer_type == "small_scale" else "一般纳税人",
            "会计准则": "小企业会计准则" if company.accounting_standard == "small_enterprise" else "企业会计准则",
            "当前期间": current_period.period if current_period else "-",
            "凭证总数": str(voucher_count),
            "银行流水": f"{txn_count} (未处理: {txn_unprocessed})",
            "发票数量": str(inv_count),
            "数据目录": str(config.data_dir),
        }

        table = Table(title="账套状态", show_header=False)
        table.add_column("项目", style="bold")
        table.add_column("值")
        for k, v in info.items():
            table.add_row(k, v)
        console.print(table)


# ============================================================
# bank - 银行流水管理
# ============================================================
@cli.group()
def bank():
    """银行流水管理"""
    pass


@bank.command("import")
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--bank-name", default="", help="银行名称")
@click.option("--account", default="", help="银行账号")
@click.option("--sheet", default=0, help="Sheet名称或索引")
@click.option("--skip-rows", default=0, help="跳过前N行")
@click.pass_context
def bank_import(ctx, file_path, bank_name, account, sheet, skip_rows):
    """导入银行流水Excel文件"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.import_engine.bank_parser import BankStatementParser
        parser = BankStatementParser(session, company_id)
        result = parser.import_to_db(
            file_path, bank_name=bank_name, account_number=account,
            sheet_name=sheet, skip_rows=skip_rows,
        )

    console.print(f"[green]✓ 银行流水导入完成[/green]")
    console.print(f"  文件: {result['file']}")
    console.print(f"  批次号: {result['batch_id']}")
    console.print(f"  总记录: {result['total_records']}")
    console.print(f"  导入: {result['imported']}")
    console.print(f"  跳过(重复): {result['skipped']}")


@bank.command("list")
@click.option("--unprocessed", is_flag=True, help="只显示未处理的")
@click.option("--limit", default=50, help="显示条数")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def bank_list(ctx, unprocessed, limit, as_json):
    """查看银行流水列表"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.models.transaction import BankTransaction
        query = session.query(BankTransaction).filter_by(company_id=company_id)
        if unprocessed:
            query = query.filter_by(is_processed=False)
        transactions = query.order_by(BankTransaction.trans_date.desc()).limit(limit).all()

        if as_json:
            data = [{
                "id": t.id, "date": t.trans_date.isoformat(),
                "bank_name": t.bank_name or "",
                "account_number": t.account_number or "",
                "debit": float(t.debit_amount), "credit": float(t.credit_amount),
                "balance": float(t.balance) if t.balance else None,
                "summary": t.summary, "counterparty": t.counterparty,
                "reference_no": t.reference_no or "",
                "processed": t.is_processed,
            } for t in transactions]
            console.print(_json_output(data))
        else:
            table = Table(title=f"银行流水 (共{len(transactions)}条)")
            table.add_column("ID", style="dim")
            table.add_column("日期")
            table.add_column("银行")
            table.add_column("支出", justify="right", style="red")
            table.add_column("收入", justify="right", style="green")
            table.add_column("余额", justify="right")
            table.add_column("摘要")
            table.add_column("对方")
            table.add_column("状态")

            for t in transactions:
                table.add_row(
                    str(t.id), str(t.trans_date),
                    (t.bank_name or "")[:10],
                    f"{t.debit_amount:,.2f}" if t.debit_amount else "",
                    f"{t.credit_amount:,.2f}" if t.credit_amount else "",
                    f"{t.balance:,.2f}" if t.balance else "",
                    (t.summary or "")[:30],
                    (t.counterparty or "")[:20],
                    "✓" if t.is_processed else "待处理",
                )
            console.print(table)


# ============================================================
# invoice - 发票管理
# ============================================================
@cli.group()
def invoice():
    """发票管理"""
    pass


@invoice.command("add")
@click.option("--invoice-number", required=True, help="发票号码")
@click.option("--invoice-date", required=True, help="开票日期(YYYY-MM-DD)")
@click.option("--direction", required=True, type=click.Choice(["input", "output"]), help="方向: input=进项, output=销项")
@click.option("--amount", required=True, type=str, help="不含税金额")
@click.option("--invoice-code", default="", help="发票代码")
@click.option("--invoice-type", type=click.Choice(["vat_special", "vat_normal", "vat_electronic"]), default="vat_normal", help="发票类型")
@click.option("--tax-amount", default="0", help="税额")
@click.option("--total-amount", default="", help="价税合计(不填则自动计算)")
@click.option("--tax-rate", default="", help="税率(如 13, 9, 6, 3)")
@click.option("--seller-name", default="", help="销售方名称")
@click.option("--seller-tax-id", default="", help="销售方税号")
@click.option("--buyer-name", default="", help="购买方名称")
@click.option("--buyer-tax-id", default="", help="购买方税号")
@click.option("--expense-category", default="", help="费用类别")
@click.option("--memo", default="", help="备注")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def invoice_add(ctx, invoice_number, invoice_date, direction, amount,
                invoice_code, invoice_type, tax_amount, total_amount,
                tax_rate, seller_name, seller_tax_id, buyer_name,
                buyer_tax_id, expense_category, memo, as_json):
    """录入单张发票 — Agent 识别发票后通过参数写入

    示例:
      ft invoice add --invoice-number "12345678" --invoice-date 2025-03-15 --direction input --amount 10000 --tax-amount 1300
    """
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.import_engine.invoice_parser import InvoiceParser
        parser = InvoiceParser(session, company_id)
        result = parser.add_invoice(
            invoice_number=invoice_number,
            invoice_date=invoice_date,
            direction=direction,
            amount=amount,
            invoice_code=invoice_code,
            invoice_type=invoice_type,
            tax_amount=tax_amount,
            total_amount=total_amount,
            tax_rate=tax_rate,
            seller_name=seller_name,
            seller_tax_id=seller_tax_id,
            buyer_name=buyer_name,
            buyer_tax_id=buyer_tax_id,
            expense_category=expense_category,
            memo=memo,
        )

    if as_json:
        console.print(_json_output(result))
    else:
        if result["status"] == "ok":
            console.print(f"[green]✓ 发票录入成功[/green]")
            console.print(f"  发票号码: {result['invoice_number']}")
            console.print(f"  发票ID: {result['invoice_id']}")
        else:
            console.print(f"[yellow]⚠ {result['message']}[/yellow]")


@invoice.command("batch-add")
@click.option("--json-data", required=True, help="发票JSON数组")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def invoice_batch_add(ctx, json_data, as_json):
    """批量录入发票 — Agent 整理好 JSON 后一次性导入

    示例:
      ft invoice batch-add --json-data '[{"invoice_number":"12345678","invoice_date":"2025-03-15","direction":"input","amount":10000}]'
    """
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    try:
        invoices = json.loads(json_data)
    except json.JSONDecodeError as e:
        console.print(f"[red]JSON解析失败: {e}[/red]")
        sys.exit(1)

    if not isinstance(invoices, list):
        console.print("[red]json-data 必须是 JSON 数组[/red]")
        sys.exit(1)

    with get_session(config) as session:
        from finance_tax.import_engine.invoice_parser import InvoiceParser
        parser = InvoiceParser(session, company_id)
        result = parser.batch_add_invoices(invoices)

    if as_json:
        console.print(_json_output(result))
    else:
        console.print(f"[green]✓ 批量录入完成[/green]")
        console.print(f"  总记录: {result['total']}")
        console.print(f"  成功: {result['imported']}")
        console.print(f"  跳过(重复): {result['skipped']}")
        if result.get("errors"):
            console.print(f"  [red]失败: {len(result['errors'])}[/red]")
            for err in result["errors"]:
                console.print(f"    - {err}")


@invoice.command("list")
@click.option("--direction", type=click.Choice(["input", "output", "all"]), default="all")
@click.option("--unprocessed", is_flag=True)
@click.option("--limit", default=50)
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def invoice_list(ctx, direction, unprocessed, limit, as_json):
    """查看发票列表"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.models.invoice import Invoice
        query = session.query(Invoice).filter_by(company_id=company_id)
        if direction != "all":
            query = query.filter_by(direction=direction)
        if unprocessed:
            query = query.filter_by(is_processed=False)
        invoices = query.order_by(Invoice.invoice_date.desc()).limit(limit).all()

        if as_json:
            data = []
            for inv in invoices:
                data.append({
                    "id": inv.id,
                    "invoice_number": inv.invoice_number,
                    "invoice_code": inv.invoice_code,
                    "invoice_date": inv.invoice_date,
                    "invoice_type": inv.invoice_type,
                    "direction": inv.direction,
                    "amount": inv.amount,
                    "tax_amount": inv.tax_amount,
                    "total_amount": inv.total_amount,
                    "tax_rate": float(inv.tax_rate) if inv.tax_rate else None,
                    "seller_name": inv.seller_name,
                    "buyer_name": inv.buyer_name,
                    "expense_category": inv.expense_category,
                    "is_processed": inv.is_processed,
                })
            console.print(_json_output({"total": len(data), "invoices": data}))
        else:
            table = Table(title=f"发票列表 (共{len(invoices)}条)")
            table.add_column("ID", style="dim")
            table.add_column("日期")
            table.add_column("发票号码")
            table.add_column("方向")
            table.add_column("金额", justify="right")
            table.add_column("税额", justify="right")
            table.add_column("价税合计", justify="right")
            table.add_column("对方")
            table.add_column("状态")

            for inv in invoices:
                table.add_row(
                    str(inv.id), str(inv.invoice_date), inv.invoice_number,
                    "进项" if inv.direction == "input" else "销项",
                    f"{inv.amount:,.2f}", f"{inv.tax_amount:,.2f}",
                    f"{inv.total_amount:,.2f}",
                    (inv.seller_name if inv.direction == "input" else inv.buyer_name or "")[:20] if (inv.seller_name if inv.direction == "input" else inv.buyer_name) else "",
                    "✓" if inv.is_processed else "待处理",
                )
            console.print(table)


@invoice.command("verify")
@click.option("--invoice-id", required=True, type=int, help="发票ID")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def invoice_verify(ctx, invoice_id, as_json):
    """查验发票真伪（对接阿里云云市场发票查验API）"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    if not config.invoice_verify_appcode:
        result = {
            "status": "error",
            "message": "未配置发票查验AppCode。请通过 ft config set --invoice-verify-appcode <APPCODE> 配置，"
                       "AppCode可在阿里云云市场购买: https://market.aliyun.com/detail/cmapi00069751",
        }
        if as_json:
            console.print(_json_output(result))
        else:
            console.print(f"[red]{result['message']}[/red]")
        return

    with get_session(config) as session:
        from finance_tax.models.invoice import Invoice
        from finance_tax.import_engine.invoice_verify import InvoiceVerifier

        inv = session.query(Invoice).filter_by(
            id=invoice_id, company_id=company_id
        ).first()

        if not inv:
            result = {"status": "error", "message": f"发票ID {invoice_id} 不存在"}
        else:
            verifier = InvoiceVerifier(config.invoice_verify_appcode)
            result = verifier.verify(
                fphm=inv.invoice_number,
                kprq=inv.invoice_date.strftime("%Y%m%d"),
                je=str(inv.total_amount),
                fpdm=inv.invoice_code or "",
            )
            result["invoice_id"] = inv.id

            # 更新发票认证状态
            if result.get("verify_status") == "valid":
                inv.is_verified = True
                session.flush()

    if as_json:
        console.print(_json_output(result))
    else:
        if result.get("status") == "error":
            console.print(f"[red]✗ {result['message']}[/red]")
        elif result.get("verify_status") == "valid":
            console.print(f"[green]✓ 发票查验通过[/green]")
            console.print(f"  发票号码: {result.get('invoice_number', '')}")
            console.print(f"  销售方: {result.get('seller_name', '')}")
            console.print(f"  购买方: {result.get('buyer_name', '')}")
            console.print(f"  价税合计: {result.get('total_amount', '')}")
            console.print(f"  开票日期: {result.get('invoice_date', '')}")
            if result.get('is_cancelled'):
                console.print(f"  [red]注意: 该发票已作废[/red]")
        else:
            console.print(f"[yellow]⚠ {result.get('message', '查验失败')}[/yellow]")


@invoice.command("suggest")
@click.argument("invoice_id", type=int)
@click.option("--json-output", "as_json", is_flag=True, default=True, help="JSON格式输出(默认)")
@click.pass_context
def invoice_suggest(ctx, invoice_id, as_json):
    """为发票推荐费用/收入科目（供 Agent 审核参考）"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.models.invoice import Invoice
        from finance_tax.accounting.voucher_engine import VoucherEngine

        inv = session.query(Invoice).filter_by(
            id=invoice_id, company_id=company_id
        ).first()
        if not inv:
            console.print(f"[red]✗ 找不到发票 ID={invoice_id}[/red]")
            sys.exit(1)

        engine = VoucherEngine(session, company_id)
        suggestions = engine.suggest_accounts_for_invoice(inv)

        result = {
            "invoice_id": inv.id,
            "invoice_number": inv.invoice_number,
            "invoice_date": inv.invoice_date,
            "direction": inv.direction,
            "amount": inv.amount,
            "tax_amount": inv.tax_amount,
            "total_amount": inv.total_amount,
            "expense_category": inv.expense_category,
            "is_verified": inv.is_verified,
            "is_processed": inv.is_processed,
            "suggestions": suggestions,
        }
        console.print(_json_output(result))


@invoice.command("assign")
@click.argument("invoice_id", type=int)
@click.option("--account", required=True, help="费用/收入科目（名称或编码）")
@click.option("--post", "auto_post", is_flag=True, help="生成后自动过账")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def invoice_assign(ctx, invoice_id, account, auto_post, as_json):
    """为发票指定科目并生成凭证（Agent 审核用）

    进项发票: 借 费用/成本科目 + 借 进项税额, 贷 应付账款
    销项发票: 借 应收账款, 贷 收入科目 + 贷 销项税额

    示例:
      ft invoice assign 1 --account "管理费用-办公费" --post --json-output
      ft invoice assign 2 --account 5001 --post --json-output
    """
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.models.invoice import Invoice
        from finance_tax.models.account import Account
        from finance_tax.accounting.voucher_engine import VoucherEngine

        inv = session.query(Invoice).filter_by(
            id=invoice_id, company_id=company_id
        ).first()
        if not inv:
            console.print(f"[red]✗ 找不到发票 ID={invoice_id}[/red]")
            sys.exit(1)
        if inv.is_processed:
            console.print(f"[yellow]⚠ 发票 ID={invoice_id} 已入账，关联凭证 ID={inv.voucher_id}[/yellow]")
            sys.exit(1)

        # 解析科目
        acc = session.query(Account).filter_by(
            company_id=company_id, code=account, is_active=True
        ).first()
        if not acc:
            acc = session.query(Account).filter_by(
                company_id=company_id, name=account, is_active=True
            ).first()
        if not acc:
            console.print(f"[red]✗ 找不到科目: {account}[/red]")
            sys.exit(1)

        engine = VoucherEngine(session, company_id)
        try:
            v = engine.create_voucher_from_invoice(
                inv,
                expense_account_code=acc.code,
                expense_account_name=acc.name,
            )
        except ValueError as e:
            if as_json:
                console.print(_json_output({"status": "error", "message": str(e)}))
            else:
                console.print(f"[red]✗ {e}[/red]")
            sys.exit(1)

        if auto_post:
            engine.post_voucher(v.id)

        # 自动关联附件: 将发票附件复制到凭证
        from finance_tax.import_engine.attachment_store import AttachmentStore
        att_store = AttachmentStore(session, company_id, config.data_dir)
        inv_atts = att_store.list_for_entity("invoice", inv.id)
        linked_count = 0
        for src_att in inv_atts:
            att_store.copy_to_entity(src_att, "voucher", v.id)
            linked_count += 1
        if linked_count:
            v.attachment_count = linked_count

        session.commit()

        if as_json:
            result = {
                "status": "ok",
                "voucher_id": v.id,
                "number": f"{v.voucher_type}-{v.voucher_number:04d}",
                "date": v.voucher_date,
                "period": v.period,
                "status": "posted" if auto_post else v.status,
                "invoice_id": inv.id,
                "invoice_number": inv.invoice_number,
                "account": {"code": acc.code, "name": acc.name},
                "amount": inv.amount,
                "tax_amount": inv.tax_amount,
                "total_amount": inv.total_amount,
                "attachments_linked": linked_count,
            }
            console.print(_json_output(result))
        else:
            console.print(f"[green]✓ 发票入账成功[/green]")
            console.print(f"  凭证: {v.voucher_type}-{v.voucher_number:04d}")
            console.print(f"  发票: {inv.invoice_number}")
            console.print(f"  科目: {acc.name}")
            console.print(f"  金额: {inv.total_amount:,.2f}")
            if linked_count:
                console.print(f"  附件: {linked_count} 个已关联到凭证")
            if auto_post:
                console.print(f"  状态: 已过账")


# ============================================================
# voucher - 凭证管理
# ============================================================
@cli.group()
def voucher():
    """记账凭证管理"""
    pass


@voucher.command("list")
@click.option("--period", default=None, help="期间 YYYY-MM")
@click.option("--status", "v_status", default=None, type=click.Choice(["draft", "posted", "void"]))
@click.pass_context
def voucher_list(ctx, period, v_status):
    """查看凭证列表"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.accounting.voucher_engine import VoucherEngine
        engine = VoucherEngine(session, company_id)
        vouchers = engine.list_vouchers(period=period, status=v_status)

        table = Table(title=f"凭证列表 (共{len(vouchers)}张)")
        table.add_column("ID", style="dim")
        table.add_column("凭证字号")
        table.add_column("日期")
        table.add_column("期间")
        table.add_column("借方合计", justify="right")
        table.add_column("贷方合计", justify="right")
        table.add_column("来源")
        table.add_column("状态")

        for v in vouchers:
            table.add_row(
                str(v.id), f"{v.voucher_type}-{v.voucher_number:04d}",
                str(v.voucher_date), v.period,
                f"{v.total_debit:,.2f}", f"{v.total_credit:,.2f}",
                v.source, v.status,
            )
        console.print(table)


@voucher.command("post")
@click.argument("voucher_id", type=int)
@click.pass_context
def voucher_post(ctx, voucher_id):
    """过账（审核）凭证"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.accounting.voucher_engine import VoucherEngine
        engine = VoucherEngine(session, company_id)
        v = engine.post_voucher(voucher_id)
    console.print(f"[green]✓ 凭证 {v.voucher_type}-{v.voucher_number:04d} 已过账[/green]")


@voucher.command("post-all")
@click.option("--period", required=True, help="期间 YYYY-MM")
@click.pass_context
def voucher_post_all(ctx, period):
    """批量过账指定期间所有草稿凭证"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.accounting.voucher_engine import VoucherEngine
        engine = VoucherEngine(session, company_id)
        drafts = engine.list_vouchers(period=period, status="draft")
        count = 0
        for v in drafts:
            try:
                engine.post_voucher(v.id)
                count += 1
            except ValueError as e:
                console.print(f"[yellow]跳过凭证 {v.id}: {e}[/yellow]")
    console.print(f"[green]✓ 已过账 {count} 张凭证[/green]")


@voucher.command("suggest")
@click.argument("transaction_id", type=int)
@click.option("--json-output", "as_json", is_flag=True, default=True, help="JSON格式输出(默认)")
@click.pass_context
def voucher_suggest(ctx, transaction_id, as_json):
    """为指定银行流水推荐会计科目（供 Agent 审核参考）"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.models.transaction import BankTransaction
        from finance_tax.accounting.voucher_engine import VoucherEngine

        txn = session.query(BankTransaction).filter_by(
            id=transaction_id, company_id=company_id
        ).first()
        if not txn:
            console.print(f"[red]✗ 找不到流水 ID={transaction_id}[/red]")
            sys.exit(1)

        engine = VoucherEngine(session, company_id)
        suggestions = engine.suggest_accounts_for_transaction(txn)

        result = {
            "transaction_id": txn.id,
            "date": txn.trans_date.isoformat(),
            "debit": float(txn.debit_amount),
            "credit": float(txn.credit_amount),
            "summary": txn.summary,
            "counterparty": txn.counterparty,
            "is_processed": txn.is_processed,
            "suggestions": suggestions,
        }
        console.print(_json_output(result))


@voucher.command("assign")
@click.argument("transaction_id", type=int)
@click.option("--debit", "debit_account", required=True, help="借方科目（名称或编码）")
@click.option("--credit", "credit_account", required=True, help="贷方科目（名称或编码）")
@click.option("--description", default=None, help="凭证摘要（默认使用流水摘要）")
@click.option("--post", "auto_post", is_flag=True, help="生成后自动过账")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def voucher_assign(ctx, transaction_id, debit_account, credit_account, description, auto_post, as_json):
    """手动为银行流水指定科目并生成凭证（Agent 审核用）"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.models.transaction import BankTransaction
        from finance_tax.models.account import Account
        from finance_tax.accounting.voucher_engine import VoucherEngine

        txn = session.query(BankTransaction).filter_by(
            id=transaction_id, company_id=company_id
        ).first()
        if not txn:
            console.print(f"[red]✗ 找不到流水 ID={transaction_id}[/red]")
            sys.exit(1)
        if txn.is_processed:
            console.print(f"[yellow]⚠ 流水 ID={transaction_id} 已处理，关联凭证 ID={txn.voucher_id}[/yellow]")
            sys.exit(1)

        engine = VoucherEngine(session, company_id)

        # 解析借方科目（支持名称或编码）
        def resolve_account(name_or_code: str) -> tuple[str, str]:
            acc = session.query(Account).filter_by(
                company_id=company_id, code=name_or_code, is_active=True
            ).first()
            if acc:
                return acc.code, acc.name
            acc = session.query(Account).filter_by(
                company_id=company_id, name=name_or_code, is_active=True
            ).first()
            if acc:
                return acc.code, acc.name
            raise click.ClickException(f"找不到科目: {name_or_code}")

        debit_code, debit_name = resolve_account(debit_account)
        credit_code, credit_name = resolve_account(credit_account)

        is_income = txn.credit_amount > 0
        amount = txn.credit_amount if is_income else txn.debit_amount
        summary = description or txn.summary or "银行流水"

        # 确定对方科目（非银行存款的那个）用于 create_voucher_from_transaction
        bank_code, _ = engine._resolve("银行存款")
        if debit_code == bank_code:
            contra_code, contra_name = credit_code, credit_name
        else:
            contra_code, contra_name = debit_code, debit_name

        v = engine.create_voucher_from_transaction(
            txn,
            account_code=contra_code,
            account_name=contra_name,
            summary=summary,
        )

        if auto_post:
            engine.post_voucher(v.id)

        session.commit()

        if as_json:
            result = {
                "voucher_id": v.id,
                "number": f"{v.voucher_type}-{v.voucher_number:04d}",
                "date": v.voucher_date.isoformat(),
                "period": v.period,
                "status": "posted" if auto_post else v.status,
                "debit_account": {"code": debit_code, "name": debit_name},
                "credit_account": {"code": credit_code, "name": credit_name},
                "amount": float(amount),
                "description": summary,
                "transaction_id": txn.id,
            }
            console.print(_json_output(result))
        else:
            console.print(f"[green]✓ 凭证 {v.voucher_type}-{v.voucher_number:04d} 已生成[/green]")
            console.print(f"  借: {debit_code} {debit_name}  {amount:,.2f}")
            console.print(f"  贷: {credit_code} {credit_name}  {amount:,.2f}")
            console.print(f"  摘要: {summary}")
            if auto_post:
                console.print(f"  [green]已自动过账[/green]")


@voucher.command("create")
@click.option("--date", "v_date", required=True, help="凭证日期 YYYY-MM-DD")
@click.option("--debit", "debit_account", default=None, help="借方科目（简单模式，名称或编码）")
@click.option("--credit", "credit_account", default=None, help="贷方科目（简单模式，名称或编码）")
@click.option("--amount", type=float, default=None, help="金额（简单模式）")
@click.option("--description", default="", help="凭证摘要")
@click.option("--entries", "entries_json", default=None, help='多分录模式: JSON数组，每项含 account/debit/credit/summary')
@click.option("--post", "auto_post", is_flag=True, help="生成后自动过账")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def voucher_create(ctx, v_date, debit_account, credit_account, amount, description, entries_json, auto_post, as_json):
    """创建手工凭证（不关联银行流水，支持计提工资/折旧等）

    简单模式（一借一贷）:
      ft voucher create --date 2025-01-31 --debit "管理费用-工资" --credit "应付职工薪酬-工资" --amount 15000 --description "计提1月工资"

    多分录模式（多借多贷）:
      ft voucher create --date 2025-01-31 --description "计提1月工资及社保" --entries '[
        {"account": "管理费用-工资", "debit": 15000, "credit": 0, "summary": "计提工资"},
        {"account": "管理费用-社保公积金", "debit": 4200, "credit": 0, "summary": "计提社保"},
        {"account": "应付职工薪酬-工资", "debit": 0, "credit": 15000, "summary": "计提工资"},
        {"account": "应付职工薪酬-社会保险费", "debit": 0, "credit": 4200, "summary": "计提社保"}
      ]'
    """
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    # 解析日期
    try:
        voucher_date = datetime.strptime(v_date, "%Y-%m-%d").date()
    except ValueError:
        console.print(f"[red]✗ 日期格式错误: {v_date}，请使用 YYYY-MM-DD[/red]")
        sys.exit(1)

    # 构建分录列表
    if entries_json:
        try:
            entries = json.loads(entries_json)
        except json.JSONDecodeError as e:
            console.print(f"[red]✗ JSON解析失败: {e}[/red]")
            sys.exit(1)
        if not isinstance(entries, list) or len(entries) < 2:
            console.print("[red]✗ entries 必须是至少包含2条分录的数组[/red]")
            sys.exit(1)
    elif debit_account and credit_account and amount:
        entries = [
            {"account": debit_account, "debit": amount, "credit": 0, "summary": description or "手工凭证"},
            {"account": credit_account, "debit": 0, "credit": amount, "summary": description or "手工凭证"},
        ]
    else:
        console.print("[red]✗ 请使用简单模式(--debit/--credit/--amount)或多分录模式(--entries)[/red]")
        sys.exit(1)

    with get_session(config) as session:
        from finance_tax.accounting.voucher_engine import VoucherEngine

        engine = VoucherEngine(session, company_id)

        try:
            v = engine.create_manual_voucher(
                voucher_date=voucher_date,
                entries_data=entries,
                memo=description,
            )
        except ValueError as e:
            console.print(f"[red]✗ {e}[/red]")
            sys.exit(1)

        if auto_post:
            engine.post_voucher(v.id)

        session.commit()

        # 获取分录详情用于输出
        from finance_tax.models.voucher import VoucherEntry
        v_entries = session.query(VoucherEntry).filter_by(voucher_id=v.id).order_by(VoucherEntry.seq).all()

        if as_json:
            result = {
                "voucher_id": v.id,
                "number": f"{v.voucher_type}-{v.voucher_number:04d}",
                "date": v.voucher_date.isoformat(),
                "period": v.period,
                "status": "posted" if auto_post else v.status,
                "description": description,
                "entries": [
                    {
                        "seq": e.seq,
                        "account_code": e.account_code,
                        "account_name": e.account_name,
                        "debit": float(e.debit_amount),
                        "credit": float(e.credit_amount),
                        "summary": e.summary or "",
                    }
                    for e in v_entries
                ],
            }
            console.print(_json_output(result))
        else:
            console.print(f"[green]✓ 手工凭证 {v.voucher_type}-{v.voucher_number:04d} 已生成[/green]")
            for e in v_entries:
                if e.debit_amount > 0:
                    console.print(f"  借: {e.account_code} {e.account_name}  {e.debit_amount:,.2f}")
                if e.credit_amount > 0:
                    console.print(f"  贷: {e.account_code} {e.account_name}  {e.credit_amount:,.2f}")
            if description:
                console.print(f"  摘要: {description}")
            if auto_post:
                console.print(f"  [green]已自动过账[/green]")


# ============================================================
# migrate - 迁移记账
# ============================================================
@cli.group()
def migrate():
    """迁移记账（从其他系统导入期初余额）"""
    pass


@migrate.command("set-balance")
@click.option("--account", required=True, help="科目（名称或编码）")
@click.option("--balance", required=True, type=float, help="期初余额（正数）")
@click.option("--direction", required=True, type=click.Choice(["debit", "credit"]), help="余额方向")
@click.option("--period", required=True, help="期初期间 YYYY-MM")
@click.option("--ytd-debit", type=float, default=0.0, help="本年累计借方（年中迁移用）")
@click.option("--ytd-credit", type=float, default=0.0, help="本年累计贷方（年中迁移用）")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def migrate_set_balance(ctx, account, balance, direction, period, ytd_debit, ytd_credit, as_json):
    """设置单个科目的期初余额"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.models.account import Account

        # 按编码或名称查找科目
        acc = session.query(Account).filter_by(
            company_id=company_id, code=account, is_active=True
        ).first()
        if not acc:
            acc = session.query(Account).filter_by(
                company_id=company_id, name=account, is_active=True
            ).first()
        if not acc:
            console.print(f"[red]✗ 找不到科目: {account}[/red]")
            sys.exit(1)

        amt = Decimal(str(balance))
        # 按科目余额方向存储：如果传入方向与科目方向相同则为正，否则为负
        if direction != acc.balance_direction:
            amt = -amt

        acc.opening_balance = amt
        acc.opening_period = period
        acc.ytd_debit = Decimal(str(ytd_debit))
        acc.ytd_credit = Decimal(str(ytd_credit))
        session.commit()

        result = {
            "account_code": acc.code,
            "account_name": acc.name,
            "opening_balance": float(acc.opening_balance),
            "balance_direction": acc.balance_direction,
            "opening_period": period,
            "ytd_debit": float(acc.ytd_debit),
            "ytd_credit": float(acc.ytd_credit),
        }
        if as_json:
            console.print(_json_output(result))
        else:
            dir_label = "借方" if direction == "debit" else "贷方"
            console.print(f"[green]✓ 已设置期初余额[/green]")
            console.print(f"  科目: {acc.code} {acc.name}")
            console.print(f"  期初余额({dir_label}): {balance:,.2f}")
            console.print(f"  期间: {period}")


@migrate.command("import-balance")
@click.option("--json-data", "json_str", required=True, help='JSON数组，每项含 account/balance/direction 字段')
@click.option("--period", required=True, help="期初期间 YYYY-MM")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def migrate_import_balance(ctx, json_str, period, as_json):
    """批量导入期初余额（接收JSON数组）"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    try:
        items = json.loads(json_str)
    except json.JSONDecodeError as e:
        console.print(f"[red]✗ JSON解析失败: {e}[/red]")
        sys.exit(1)

    if not isinstance(items, list):
        console.print("[red]✗ JSON数据必须是数组[/red]")
        sys.exit(1)

    with get_session(config) as session:
        from finance_tax.models.account import Account

        results = []
        errors = []

        for i, item in enumerate(items):
            account_key = item.get("account", "")
            bal = item.get("balance", 0)
            direction = item.get("direction", "")
            ytd_d = item.get("ytd_debit", 0)
            ytd_c = item.get("ytd_credit", 0)

            if not account_key or not direction:
                errors.append({"index": i, "account": account_key, "error": "缺少 account 或 direction 字段"})
                continue

            acc = session.query(Account).filter_by(
                company_id=company_id, code=account_key, is_active=True
            ).first()
            if not acc:
                acc = session.query(Account).filter_by(
                    company_id=company_id, name=account_key, is_active=True
                ).first()
            if not acc:
                errors.append({"index": i, "account": account_key, "error": "科目不存在"})
                continue

            amt = Decimal(str(bal))
            if direction != acc.balance_direction:
                amt = -amt

            acc.opening_balance = amt
            acc.opening_period = period
            acc.ytd_debit = Decimal(str(ytd_d))
            acc.ytd_credit = Decimal(str(ytd_c))

            results.append({
                "account_code": acc.code,
                "account_name": acc.name,
                "opening_balance": float(acc.opening_balance),
                "direction": direction,
            })

        session.commit()

        output = {
            "period": period,
            "success_count": len(results),
            "error_count": len(errors),
            "results": results,
            "errors": errors,
        }
        if as_json:
            console.print(_json_output(output))
        else:
            console.print(f"[green]✓ 批量导入期初余额完成[/green]")
            console.print(f"  成功: {len(results)} 个科目")
            if errors:
                console.print(f"  [yellow]失败: {len(errors)} 个[/yellow]")
                for err in errors:
                    console.print(f"    - {err['account']}: {err['error']}")


@migrate.command("verify")
@click.option("--period", required=True, help="验证的期初期间 YYYY-MM")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def migrate_verify(ctx, period, as_json):
    """验证期初余额借贷平衡"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.models.account import Account

        accounts = (
            session.query(Account)
            .filter_by(company_id=company_id, is_active=True)
            .filter(Account.opening_balance != Decimal("0.00"))
            .order_by(Account.code)
            .all()
        )

        total_debit = Decimal("0.00")
        total_credit = Decimal("0.00")
        details = []

        for acc in accounts:
            bal = acc.opening_balance
            if acc.balance_direction == "debit":
                if bal >= 0:
                    total_debit += bal
                else:
                    total_credit += abs(bal)
            else:
                if bal >= 0:
                    total_credit += bal
                else:
                    total_debit += abs(bal)

            details.append({
                "account_code": acc.code,
                "account_name": acc.name,
                "balance_direction": acc.balance_direction,
                "opening_balance": float(bal),
                "debit": float(bal) if (acc.balance_direction == "debit" and bal >= 0) or (acc.balance_direction == "credit" and bal < 0) else 0.0,
                "credit": float(abs(bal)) if (acc.balance_direction == "credit" and bal >= 0) or (acc.balance_direction == "debit" and bal < 0) else 0.0,
            })

        diff = total_debit - total_credit
        is_balanced = diff == Decimal("0.00")

        result = {
            "period": period,
            "total_debit": float(total_debit),
            "total_credit": float(total_credit),
            "difference": float(diff),
            "is_balanced": is_balanced,
            "account_count": len(details),
            "accounts": details,
        }

        if as_json:
            console.print(_json_output(result))
        else:
            status = "[green]✓ 借贷平衡[/green]" if is_balanced else "[red]✗ 借贷不平衡[/red]"
            console.print(f"期初余额验证 ({period}): {status}")
            console.print(f"  借方合计: {total_debit:,.2f}")
            console.print(f"  贷方合计: {total_credit:,.2f}")
            if not is_balanced:
                console.print(f"  [red]差额: {diff:,.2f}[/red]")

            if details:
                table = Table(title="期初余额明细")
                table.add_column("科目编码", style="dim")
                table.add_column("科目名称")
                table.add_column("借方", justify="right")
                table.add_column("贷方", justify="right")
                for d in details:
                    table.add_row(
                        d["account_code"], d["account_name"],
                        f"{d['debit']:,.2f}" if d["debit"] else "",
                        f"{d['credit']:,.2f}" if d["credit"] else "",
                    )
                console.print(table)


# ============================================================
# report - 报表生成
# ============================================================
@cli.group()
def report():
    """财务报表生成"""
    pass


@report.command("trial-balance")
@click.option("--period", required=True, help="期间 YYYY-MM")
@click.option("--level", default=None, type=int, help="科目层级")
@click.option("--json-output", "as_json", is_flag=True)
@click.pass_context
def report_trial_balance(ctx, period, level, as_json):
    """生成科目余额表"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.reporting.trial_balance import TrialBalanceReport
        rpt = TrialBalanceReport(session, company_id)
        rows = rpt.generate(period=period, level=level)

        if as_json:
            console.print(_json_output(rows))
        else:
            text = rpt.to_text(rows, title=f"科目余额表 ({period})")
            console.print(text)


@report.command("balance-sheet")
@click.option("--period", required=True, help="期间 YYYY-MM")
@click.option("--json-output", "as_json", is_flag=True)
@click.pass_context
def report_balance_sheet(ctx, period, as_json):
    """生成资产负债表"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.reporting.balance_sheet import BalanceSheetReport
        rpt = BalanceSheetReport(session, company_id)
        data = rpt.generate(period)

        if as_json:
            console.print(_json_output(data))
        else:
            console.print(rpt.to_text(data))


@report.command("income")
@click.option("--period", required=True, help="截止期间 YYYY-MM")
@click.option("--start", "period_start", default=None, help="起始期间(默认=当月)")
@click.option("--json-output", "as_json", is_flag=True)
@click.pass_context
def report_income(ctx, period, period_start, as_json):
    """生成利润表"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.reporting.income_statement import IncomeStatementReport
        rpt = IncomeStatementReport(session, company_id)
        data = rpt.generate(period, period_start)

        if as_json:
            console.print(_json_output(data))
        else:
            console.print(rpt.to_text(data))


@report.command("cashflow")
@click.option("--period", required=True, help="截止期间 YYYY-MM")
@click.option("--start", "period_start", default=None, help="起始期间(默认=当月)")
@click.option("--json-output", "as_json", is_flag=True)
@click.pass_context
def report_cashflow(ctx, period, period_start, as_json):
    """生成现金流量表"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.reporting.cashflow import CashFlowReport
        rpt = CashFlowReport(session, company_id)
        data = rpt.generate(period, period_start)

        if as_json:
            console.print(_json_output(data))
        else:
            console.print(rpt.to_text(data))


# ============================================================
# tax - 税务计算
# ============================================================
@cli.group()
def tax():
    """税务计算与申报"""
    pass


@tax.command("vat")
@click.option("--period-start", required=True, help="起始期间 YYYY-MM")
@click.option("--period-end", required=True, help="截止期间 YYYY-MM")
@click.option("--frequency", default="quarterly", type=click.Choice(["monthly", "quarterly"]))
@click.option("--save", is_flag=True, help="保存申报记录")
@click.option("--json-output", "as_json", is_flag=True)
@click.pass_context
def tax_vat(ctx, period_start, period_end, frequency, save, as_json):
    """计算增值税"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.taxation.vat import VATCalculator
        calc = VATCalculator(session, company_id)
        result = calc.calculate(period_start, period_end, frequency)

        if save:
            calc.save_declaration(result)
            console.print("[green]✓ 已保存增值税申报记录[/green]")

        if as_json:
            console.print(_json_output(result))
        else:
            console.print(Panel.fit(
                f"期间: {result['period']}\n"
                f"纳税人类型: {result['taxpayer_type']}\n"
                f"销售额(含税): {result.get('sales_total', 0):,.2f}\n"
                f"销售额(不含税): {result.get('sales_amount_excl_tax', 0):,.2f}\n"
                f"税率: {result.get('tax_rate', 0)}%\n"
                f"免征: {'是' if result.get('is_exempt') else '否'}\n"
                f"应纳税额: {result.get('tax_payable', 0):,.2f}",
                title="增值税计算结果",
            ))


@tax.command("income")
@click.option("--year", required=True, type=int, help="年度")
@click.option("--quarter", required=True, type=int, help="季度(1-4)")
@click.option("--save", is_flag=True, help="保存申报记录")
@click.option("--json-output", "as_json", is_flag=True)
@click.pass_context
def tax_income(ctx, year, quarter, save, as_json):
    """计算企业所得税（季度预缴）"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.taxation.corporate_tax import CorporateIncomeTaxCalculator
        calc = CorporateIncomeTaxCalculator(session, company_id)
        result = calc.calculate_quarterly(year, quarter)

        if save:
            calc.save_declaration(result)
            console.print("[green]✓ 已保存企业所得税申报记录[/green]")

        if as_json:
            console.print(_json_output(result))
        else:
            console.print(Panel.fit(
                f"年度: {result['year']} Q{result['quarter']}\n"
                f"累计利润总额: {result['cumulative_profit']:,.2f}\n"
                f"应纳税所得额: {result['taxable_income']:,.2f}\n"
                f"小微企业优惠: {'是' if result['is_small_micro'] else '否'}\n"
                f"适用税率: {result['tax_rate']}%\n"
                f"累计应纳税额: {result['cumulative_tax_due']:,.2f}\n"
                f"已预缴: {result['already_paid']:,.2f}\n"
                f"本季应补缴: {result['tax_payable']:,.2f}",
                title="企业所得税(季度预缴)",
            ))


@tax.command("stamp")
@click.option("--period", required=True, help="所属期间 YYYY-MM")
@click.option("--type", "contract_type", required=True, help="合同类型")
@click.option("--amount", required=True, type=float, help="合同金额")
@click.option("--save", is_flag=True)
@click.option("--json-output", "as_json", is_flag=True)
@click.pass_context
def tax_stamp(ctx, period, contract_type, amount, save, as_json):
    """计算印花税"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.taxation.stamp_tax import StampTaxCalculator
        calc = StampTaxCalculator(session, company_id)
        result = calc.calculate(contract_type, Decimal(str(amount)), period)

        if save:
            batch = {"period": period, "items": [result], "total_tax_due": result["tax_due"]}
            calc.save_declaration(batch)
            console.print("[green]✓ 已保存印花税申报记录[/green]")

        if as_json:
            console.print(_json_output(result))
        else:
            console.print(Panel.fit(
                f"合同类型: {result['contract_type_name']}\n"
                f"合同金额: {result['contract_amount']:,.2f}\n"
                f"税率: {result['rate_per_10000']}‱\n"
                f"小规模减半: {'是' if result['is_half_exempt'] else '否'}\n"
                f"应纳税额: {result['tax_due']:,.2f}",
                title="印花税计算结果",
            ))


@tax.command("surcharge")
@click.option("--period", required=True, help="所属期间 YYYY-MM")
@click.option("--vat-paid", required=True, type=float, help="实缴增值税额")
@click.option("--location", default="city", type=click.Choice(["city", "county", "other"]))
@click.option("--save", is_flag=True)
@click.option("--json-output", "as_json", is_flag=True)
@click.pass_context
def tax_surcharge(ctx, period, vat_paid, location, save, as_json):
    """计算附加税（城建税+教育费附加）"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.taxation.surcharge import SurchargeCalculator
        calc = SurchargeCalculator(session, company_id)
        result = calc.calculate(Decimal(str(vat_paid)), period, location)

        if save:
            calc.save_declarations(result)
            console.print("[green]✓ 已保存附加税申报记录[/green]")

        if as_json:
            console.print(_json_output(result))
        else:
            console.print(Panel.fit(
                f"期间: {result['period']}\n"
                f"增值税基数: {result['vat_basis']:,.2f}\n"
                f"城建税({result['urban_maintenance_rate']}%): {result['urban_maintenance_tax']:,.2f}\n"
                f"教育费附加({result['education_rate']}%): {result['education_surcharge']:,.2f}\n"
                f"地方教育费附加({result['local_education_rate']}%): {result['local_education_surcharge']:,.2f}\n"
                f"附加税合计: {result['total_surcharge']:,.2f}",
                title="附加税计算结果",
            ))


# ============================================================
# account - 科目管理
# ============================================================
@cli.group()
def account():
    """会计科目管理"""
    pass


@account.command("list")
@click.option("--category", default="", help="分类: asset/liability/equity/revenue/cost/expense")
@click.option("--keyword", default="", help="搜索关键词")
@click.option("--level", default=None, type=int)
@click.option("--json-output", "as_json", is_flag=True)
@click.pass_context
def account_list(ctx, category, keyword, level, as_json):
    """查看科目列表"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.accounting.chart_of_accounts import ChartOfAccountsManager
        coa = ChartOfAccountsManager(session, company_id)
        accounts = coa.search_accounts(keyword=keyword, category=category, level=level)

        if as_json:
            data = [{"code": a.code, "name": a.name, "category": a.category,
                      "direction": a.balance_direction, "level": a.level}
                     for a in accounts]
            console.print(_json_output(data))
        else:
            table = Table(title="会计科目")
            table.add_column("编码")
            table.add_column("名称")
            table.add_column("分类")
            table.add_column("方向")
            table.add_column("层级")

            for a in accounts:
                indent = "  " * (a.level - 1)
                table.add_row(
                    a.code, f"{indent}{a.name}", a.category,
                    "借" if a.balance_direction == "debit" else "贷",
                    str(a.level),
                )
            console.print(table)


# ============================================================
# period - 会计期间管理
# ============================================================
@cli.group()
def period():
    """会计期间管理"""
    pass


@period.command("list")
@click.option("--year", default=None, type=int)
@click.pass_context
def period_list(ctx, year):
    """查看会计期间"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.accounting.period import PeriodManager
        pm = PeriodManager(session, company_id)
        periods = pm.list_periods(year)

        table = Table(title="会计期间")
        table.add_column("期间")
        table.add_column("起始日")
        table.add_column("截止日")
        table.add_column("状态")

        for p in periods:
            status_style = "green" if p.status == "open" else "dim"
            table.add_row(
                p.period, str(p.start_date), str(p.end_date),
                f"[{status_style}]{p.status}[/{status_style}]",
            )
        console.print(table)


@period.command("close")
@click.argument("period_str")
@click.pass_context
def period_close(ctx, period_str):
    """结账"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.accounting.period import PeriodManager
        pm = PeriodManager(session, company_id)
        pm.close_period(period_str)
    console.print(f"[green]✓ 期间 {period_str} 已结账[/green]")


@period.command("init-year")
@click.argument("year", type=int)
@click.pass_context
def period_init_year(ctx, year):
    """初始化指定年度的会计期间"""
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.accounting.period import PeriodManager
        pm = PeriodManager(session, company_id)
        periods = pm.init_year_periods(year)
    console.print(f"[green]✓ 已初始化 {year} 年度 {len(periods)} 个会计期间[/green]")


# ============================================================
# attachment - 附件管理
# ============================================================
@cli.group()
def attachment():
    """附件管理 — 发票/银行流水/凭证的电子凭证管理"""
    pass


@attachment.command("add")
@click.option("--entity-type", required=True, type=click.Choice(["invoice", "bank_transaction", "voucher"]), help="关联对象类型")
@click.option("--entity-id", required=True, type=int, help="关联对象ID")
@click.option("--file", "file_path", required=True, type=click.Path(exists=True), help="文件路径")
@click.option("--category", default="other", type=click.Choice(["invoice_photo", "e_invoice", "bank_cert", "other"]), help="附件类别")
@click.option("--memo", default=None, help="备注")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def attachment_add(ctx, entity_type, entity_id, file_path, category, memo, as_json):
    """上传附件 — Agent 提供本地文件路径，系统复制到托管目录

    示例:
      ft attachment add --entity-type invoice --entity-id 1 --file /path/to/发票.pdf --category e_invoice
      ft attachment add --entity-type bank_transaction --entity-id 5 --file /path/to/回单.jpg --category bank_cert
    """
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.import_engine.attachment_store import AttachmentStore

        store = AttachmentStore(session, company_id, config.data_dir)
        try:
            att = store.add(
                source_path=file_path,
                entity_type=entity_type,
                entity_id=entity_id,
                category=category,
                memo=memo,
            )
        except (FileNotFoundError, ValueError) as e:
            if as_json:
                console.print(_json_output({"status": "error", "message": str(e)}))
            else:
                console.print(f"[red]✗ {e}[/red]")
            sys.exit(1)

        session.commit()

        if as_json:
            result = {"status": "ok", **store.to_dict(att)}
            console.print(_json_output(result))
        else:
            console.print(f"[green]✓ 附件上传成功[/green]")
            console.print(f"  ID: {att.id}")
            console.print(f"  文件: {att.file_name}")
            console.print(f"  大小: {att.file_size:,} 字节")
            console.print(f"  类别: {att.category}")
            console.print(f"  关联: {att.entity_type} #{att.entity_id}")


@attachment.command("list")
@click.option("--entity-type", required=True, type=click.Choice(["invoice", "bank_transaction", "voucher"]), help="关联对象类型")
@click.option("--entity-id", required=True, type=int, help="关联对象ID")
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def attachment_list(ctx, entity_type, entity_id, as_json):
    """查看某业务对象的附件列表

    示例:
      ft attachment list --entity-type invoice --entity-id 1 --json-output
    """
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.import_engine.attachment_store import AttachmentStore

        store = AttachmentStore(session, company_id, config.data_dir)
        items = store.list_for_entity(entity_type, entity_id)

        if as_json:
            result = {
                "entity_type": entity_type,
                "entity_id": entity_id,
                "total": len(items),
                "attachments": [store.to_dict(a) for a in items],
            }
            console.print(_json_output(result))
        else:
            if not items:
                console.print(f"[yellow]{entity_type} #{entity_id} 暂无附件[/yellow]")
                return
            table = Table(title=f"{entity_type} #{entity_id} 附件列表")
            table.add_column("ID", style="cyan")
            table.add_column("文件名")
            table.add_column("大小")
            table.add_column("类别")
            table.add_column("备注")
            for a in items:
                size_str = (
                    f"{a.file_size / 1024:.1f}KB"
                    if a.file_size < 1024 * 1024
                    else f"{a.file_size / 1024 / 1024:.1f}MB"
                )
                table.add_row(
                    str(a.id),
                    a.file_name,
                    size_str,
                    a.category,
                    a.memo or "",
                )
            console.print(table)


@attachment.command("info")
@click.argument("attachment_id", type=int)
@click.option("--json-output", "as_json", is_flag=True, default=True, help="JSON格式输出(默认)")
@click.pass_context
def attachment_info(ctx, attachment_id, as_json):
    """查看附件详情

    示例:
      ft attachment info 1
    """
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.import_engine.attachment_store import AttachmentStore

        store = AttachmentStore(session, company_id, config.data_dir)
        att = store.get(attachment_id)
        if not att:
            console.print(f"[red]✗ 找不到附件 ID={attachment_id}[/red]")
            sys.exit(1)

        console.print(_json_output(store.to_dict(att)))


@attachment.command("delete")
@click.argument("attachment_id", type=int)
@click.option("--json-output", "as_json", is_flag=True, help="JSON格式输出")
@click.pass_context
def attachment_delete(ctx, attachment_id, as_json):
    """删除附件记录

    示例:
      ft attachment delete 1 --json-output
    """
    config: AppConfig = ctx.obj["config"]
    company_id = _ensure_initialized(config)

    with get_session(config) as session:
        from finance_tax.import_engine.attachment_store import AttachmentStore

        store = AttachmentStore(session, company_id, config.data_dir)
        att = store.get(attachment_id)
        if not att:
            if as_json:
                console.print(_json_output({"status": "error", "message": f"找不到附件 ID={attachment_id}"}))
            else:
                console.print(f"[red]✗ 找不到附件 ID={attachment_id}[/red]")
            sys.exit(1)

        file_name = att.file_name
        store.delete(attachment_id)
        session.commit()

        if as_json:
            console.print(_json_output({"status": "ok", "deleted_id": attachment_id, "file_name": file_name}))
        else:
            console.print(f"[green]✓ 已删除附件: {file_name} (ID={attachment_id})[/green]")


# ============================================================
# web - 启动 Web 看板
# ============================================================
@cli.command()
@click.option("--host", default="127.0.0.1", help="监听地址")
@click.option("--port", default=8000, type=int, help="监听端口")
@click.pass_context
def web(ctx, host, port):
    """启动 Web 数据看板"""
    try:
        import uvicorn
    except ImportError:
        console.print("[red]请先安装 Web 依赖: uv pip install finance-tax[api][/red]")
        sys.exit(1)

    config: AppConfig = ctx.obj["config"]
    _ensure_initialized(config)

    from finance_tax.web.app import create_app
    app = create_app(config.data_dir)
    console.print(f"[green]✓ Web 看板启动: http://{host}:{port}[/green]")
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    cli()
