"""
Protocol types for LLM Council.

Defines Pydantic models for council requests, responses, and configuration.
These types enable JSON-lines stdin/stdout communication for IDE integration.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class SummaryTier(str, Enum):
    """Summarization detail levels."""

    GIST = "gist"  # ~50 tokens, one-liner
    FINDINGS = "findings"  # ~150 tokens, key points
    ACTIONS = "actions"  # ~300 tokens, actionable items
    RATIONALE = "rationale"  # ~500 tokens, reasoning included
    AUDIT = "audit"  # Full detail for audit trail


class ReasoningProfile(str, Enum):
    """High-level reasoning intensity overrides for runtime execution."""

    DEFAULT = "default"
    OFF = "off"
    LIGHT = "light"


class RuntimeProfile(str, Enum):
    """High-level execution budget overrides for council phases."""

    DEFAULT = "default"
    BOUNDED = "bounded"


class CouncilConfig(BaseModel):
    """Configuration for a council run."""

    model_config = ConfigDict(extra="allow")

    providers: list[str] = Field(
        default=["openrouter"],
        description="List of provider names to use for drafts",
    )
    models: list[str] | None = Field(
        default=None,
        description=(
            "List of OpenRouter model IDs for multi-model council. "
            "When set with providers=['openrouter'], creates virtual providers for each model. "
            "Example: ['anthropic/claude-3.5-sonnet', 'openai/gpt-4o', 'google/gemini-pro']"
        ),
    )
    timeout: int = Field(
        default=120,
        ge=10,
        le=900,
        description="Timeout per provider call in seconds (max 15 min)",
    )
    max_retries: int = Field(
        default=3,
        ge=1,
        le=10,
        description="Maximum validation retries",
    )
    summary_tier: SummaryTier = Field(
        default=SummaryTier.ACTIONS,
        description="Summarization detail level",
    )
    max_draft_tokens: int = Field(
        default=4000,
        description="Max tokens per draft before summarization",
    )
    enable_artifact_store: bool = Field(
        default=True,
        description="Store verbose outputs in artifact store",
    )
    enable_health_check: bool = Field(
        default=False,
        description="Run preflight health check before council run",
    )
    enable_graceful_degradation: bool = Field(
        default=True,
        description="Enable graceful degradation on provider failures",
    )
    mode: str | None = Field(
        default=None,
        description="Agent mode for consolidated agents (e.g., 'impl', 'arch', 'review')",
    )
    temperature: float | None = Field(
        default=None,
        ge=0.0,
        le=2.0,
        description="Model temperature for generation (0.0-2.0)",
    )
    max_tokens: int | None = Field(
        default=None,
        ge=1,
        description="Maximum output tokens",
    )
    runtime_profile: RuntimeProfile = Field(
        default=RuntimeProfile.DEFAULT,
        description="High-level runtime budget override (default/bounded).",
    )
    reasoning_profile: ReasoningProfile = Field(
        default=ReasoningProfile.DEFAULT,
        description="High-level override for reasoning intensity (default/off/light).",
    )
    system_context: str | None = Field(
        default=None,
        description="Additional system context/instructions to prepend",
    )
    output_schema: dict[str, Any] | None = Field(
        default=None,
        description="Custom JSON schema for output validation",
    )
    model_pack: str | None = Field(
        default=None,
        description="Optional runtime model-pack override (e.g. deep_reasoner, grounded)",
    )
    model_overrides: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Explicit per-provider model overrides. "
            "These are user-selected models and should take precedence over subagent defaults."
        ),
    )
    execution_profile: str | None = Field(
        default=None,
        description="Optional execution-profile override (prompt_only, light_tools, grounded, deep_analysis)",
    )
    budget_class: str | None = Field(
        default=None,
        description="Optional budget-class override (cheap, normal, premium)",
    )
    required_capabilities: list[str] = Field(
        default_factory=list,
        description="Optional capability-pack overrides to merge into the run",
    )
    disable_local_evidence: bool = Field(
        default=False,
        description="Disable local evidence collection and rely only on provided reference material.",
    )
    follow_router: bool = Field(
        default=False,
        description=(
            "If true, a router run is followed by a second run using the router's "
            "recommended subagent and mode."
        ),
    )
    provider_configs: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description=(
            "Per-provider constructor kwargs keyed by provider name. "
            "E.g. {'openai': {'default_model': 'gpt-5.4'}}"
        ),
    )


class CouncilRequest(BaseModel):
    """Request to run a council task."""

    model_config = ConfigDict(extra="allow")

    type: str = Field(default="council_request", description="Message type")
    task: str = Field(..., description="The task to process")
    subagent: str = Field(
        default="router",
        description="Subagent type (drafter, critic, planner, etc.)",
    )
    mode: str | None = Field(
        default=None,
        description="Agent mode for consolidated agents",
    )
    follow_router: bool = Field(
        default=False,
        description="Follow router output by running the recommended subagent and mode",
    )
    config: CouncilConfig | None = Field(
        default=None,
        description="Optional configuration override",
    )
    context: dict[str, Any] | None = Field(
        default=None,
        description="Additional context for the task",
    )


class CostEstimate(BaseModel):
    """Estimated cost for a council run."""

    model_config = ConfigDict(frozen=True)

    provider_calls: dict[str, int] = Field(
        default_factory=dict,
        description="Call count per provider",
    )
    total_input_tokens: int = Field(default=0, description="Total input tokens")
    total_output_tokens: int = Field(default=0, description="Total output tokens")
    estimated_cost_usd: float = Field(default=0.0, description="Estimated cost in USD")


class PhaseTiming(BaseModel):
    """Timing information for a council phase."""

    model_config = ConfigDict(frozen=True)

    phase: str = Field(..., description="Phase name")
    duration_ms: int = Field(..., description="Duration in milliseconds")


class CouncilResponse(BaseModel):
    """Response from a council run."""

    model_config = ConfigDict(extra="allow")

    type: str = Field(default="council_response", description="Message type")
    success: bool = Field(..., description="Whether the council succeeded")
    output: dict[str, Any] | None = Field(
        default=None,
        description="Validated JSON output",
    )
    drafts: dict[str, str] | None = Field(
        default=None,
        description="Draft outputs by provider",
    )
    critique: str | None = Field(
        default=None,
        description="Adversarial critique",
    )
    synthesis_attempts: int = Field(
        default=1,
        description="Number of synthesis attempts",
    )
    duration_ms: int = Field(
        default=0,
        description="Total duration in milliseconds",
    )
    phase_timings: list[PhaseTiming] | None = Field(
        default=None,
        description="Timing per phase",
    )
    validation_errors: list[str] | None = Field(
        default=None,
        description="Validation errors if failed",
    )
    cost_estimate: CostEstimate | None = Field(
        default=None,
        description="Cost estimation",
    )
    run_id: str | None = Field(
        default=None,
        description="Artifact store run ID",
    )
    routed: bool = Field(
        default=False,
        description="Whether this response came from a router-followed execution",
    )
    routing_decision: dict[str, Any] | None = Field(
        default=None,
        description="Router output used to select the routed subagent and mode",
    )
    routing_execution_plan: dict[str, Any] | None = Field(
        default=None,
        description="Execution plan produced by the router run before follow-up execution",
    )


class ErrorResponse(BaseModel):
    """Error response for failed requests."""

    model_config = ConfigDict(frozen=True)

    type: str = Field(default="error", description="Message type")
    error: str = Field(..., description="Error message")
    code: str | None = Field(default=None, description="Error code")
    details: dict[str, Any] | None = Field(
        default=None,
        description="Additional error details",
    )
