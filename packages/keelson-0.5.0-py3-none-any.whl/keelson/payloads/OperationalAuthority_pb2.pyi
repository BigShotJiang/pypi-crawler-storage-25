from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class OperationalAuthority(_message.Message):
    __slots__ = ("timestamp", "level", "composite_score", "reason", "component_scores")
    class AuthorityLevel(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        AUTHORITY_LEVEL_UNKNOWN: _ClassVar[OperationalAuthority.AuthorityLevel]
        AUTHORITY_LEVEL_MINIMAL_SAFE_MODE: _ClassVar[OperationalAuthority.AuthorityLevel]
        AUTHORITY_LEVEL_SUPERVISED_REMOTE: _ClassVar[OperationalAuthority.AuthorityLevel]
        AUTHORITY_LEVEL_REMOTE_CONTROLLED: _ClassVar[OperationalAuthority.AuthorityLevel]
        AUTHORITY_LEVEL_ASSISTED_AUTONOMOUS: _ClassVar[OperationalAuthority.AuthorityLevel]
        AUTHORITY_LEVEL_FULL_AUTONOMOUS: _ClassVar[OperationalAuthority.AuthorityLevel]
    AUTHORITY_LEVEL_UNKNOWN: OperationalAuthority.AuthorityLevel
    AUTHORITY_LEVEL_MINIMAL_SAFE_MODE: OperationalAuthority.AuthorityLevel
    AUTHORITY_LEVEL_SUPERVISED_REMOTE: OperationalAuthority.AuthorityLevel
    AUTHORITY_LEVEL_REMOTE_CONTROLLED: OperationalAuthority.AuthorityLevel
    AUTHORITY_LEVEL_ASSISTED_AUTONOMOUS: OperationalAuthority.AuthorityLevel
    AUTHORITY_LEVEL_FULL_AUTONOMOUS: OperationalAuthority.AuthorityLevel
    class ComponentScoresEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: float
        def __init__(self, key: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    COMPOSITE_SCORE_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_SCORES_FIELD_NUMBER: _ClassVar[int]
    timestamp: _timestamp_pb2.Timestamp
    level: OperationalAuthority.AuthorityLevel
    composite_score: float
    reason: str
    component_scores: _containers.ScalarMap[str, float]
    def __init__(self, timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., level: _Optional[_Union[OperationalAuthority.AuthorityLevel, str]] = ..., composite_score: _Optional[float] = ..., reason: _Optional[str] = ..., component_scores: _Optional[_Mapping[str, float]] = ...) -> None: ...
