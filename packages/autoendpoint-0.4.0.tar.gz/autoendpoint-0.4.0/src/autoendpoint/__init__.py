from autoendpoint.core import AutoEndpoint
from autoendpoint.models import generate_crud_models
from autoendpoint.utils import is_primary_key

__version__ = "0.4.0"
