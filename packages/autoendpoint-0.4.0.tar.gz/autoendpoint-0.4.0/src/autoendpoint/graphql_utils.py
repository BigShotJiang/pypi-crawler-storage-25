from typing import List, Type, Dict, Any, Optional, Union
import strawberry
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import SQLModel, select
from sqlalchemy.orm import class_mapper


def generate_graphql_schema(models: List[Type[SQLModel]], db_session: AsyncSession) -> strawberry.Schema:
    """Dynamically generates a Strawberry GraphQL schema for the given SQLModels.

    Args:
        models: A list of SQLModel classes to include in the schema.
        db_session: The asynchronous database session to use for queries.

    Returns:
        A Strawberry Schema object.
    """

    model_to_strawberry_type: Dict[Type[SQLModel], Any] = {}

    # First pass: Create the basic Strawberry types without relationships
    for model in models:
        @strawberry.experimental.pydantic.type(model=model, all_fields=True, name=f"{model.__name__}Type")
        class ModelType:
            @strawberry.field
            def string_representation(self) -> str:
                return str(self)

        model_to_strawberry_type[model] = ModelType

    # Second pass: Add relationship fields to the Strawberry types
    for model, strawberry_type in model_to_strawberry_type.items():
        mapper = class_mapper(model)
        for rel in mapper.relationships:
            target_model = rel.mapper.class_
            if target_model in model_to_strawberry_type:
                target_strawberry_type = model_to_strawberry_type[target_model]
                rel_name = rel.key
                is_list = rel.uselist

                # Define a resolver for the relationship
                def make_rel_resolver(r_n=rel_name):
                    async def resolve_rel(root: Any) -> Any:
                        # Since we are in an async environment, 
                        # we must ensure the relationship is loaded.
                        # However, for simplicity now, let's try direct access.
                        # A better approach might involve selectinload in the main query.
                        return getattr(root, r_n)
                    return resolve_rel

                # Determine the type annotation
                if is_list:
                    field_type = List[target_strawberry_type] # type: ignore
                else:
                    field_type = Optional[target_strawberry_type] # type: ignore

                # Create the field
                field = strawberry.field(resolver=make_rel_resolver(), name=rel_name)
                # Use strawberry.annotation.StrawberryAnnotation to wrap the type
                from strawberry.annotation import StrawberryAnnotation
                field.type_annotation = StrawberryAnnotation(field_type)
                
                # Add to the type definition
                strawberry_type.__strawberry_definition__.fields.append(field)

    query_fields = {}
    for model, strawberry_type in model_to_strawberry_type.items():
        # To make strawberry recognize the arguments, the resolver function signature 
        # must have them. We can use a helper to create such a function.
        def create_resolver_with_args(m=model, t=strawberry_type):
            from sqlalchemy.orm import selectinload
            mapper = class_mapper(m)
            options = []
            for rel in mapper.relationships:
                if rel.mapper.class_ in model_to_strawberry_type:
                    options.append(selectinload(getattr(m, rel.key)))

            # Dynamically create a function with arguments matching the model columns
            # We need to include type annotations for strawberry to work
            arg_names = []
            arg_defs = []
            arg_types = {}
            for column in mapper.columns:
                name = column.key
                try:
                    py_type = column.type.python_type
                except NotImplementedError:
                    # Fallback to str if python_type is not implemented for the column type
                    # Most fields can be represented as strings in GraphQL queries
                    py_type = str
                # We'll use the type name in the string, and provide the type in globals
                type_name = f"Type_{name}"
                arg_names.append(name)
                arg_defs.append(f"{name}: Optional[{type_name}] = None")
                arg_types[type_name] = py_type

            arg_defs_str = ", ".join(arg_defs)
            
            # Create a function with the right signature using exec
            func_code = f"async def resolve(self, {arg_defs_str}) -> List[t]:\n"
            func_code += f"    kwargs = {{{', '.join([f'\"{name}\": {name}' for name in arg_names])}}}\n"
            func_code += f"    stmt = select(m)\n"
            func_code += f"    if options:\n"
            func_code += f"        stmt = stmt.options(*options)\n"
            func_code += f"    for field, value in kwargs.items():\n"
            func_code += f"        if value is not None:\n"
            func_code += f"            stmt = stmt.where(getattr(m, field) == value)\n"
            func_code += f"    results = await db_session.execute(stmt)\n"
            func_code += f"    return results.scalars().all()"
            
            globals_dict = {
                "m": m,
                "select": select,
                "db_session": db_session,
                "options": options,
                "List": List,
                "Optional": Optional,
                "t": t
            }
            globals_dict.update(arg_types)
            
            locs = {}
            exec(func_code, globals_dict, locs)
            resolve_func = locs["resolve"]
            # Set __module__ to avoid KeyError in strawberry
            resolve_func.__module__ = __name__
            return resolve_func

        query_fields[f"list_{model.__name__.lower()}"] = strawberry.field(resolver=create_resolver_with_args())

    DynamicQuery = type("Query", (object,), query_fields)
    DynamicQuery = strawberry.type(DynamicQuery)

    return strawberry.Schema(query=DynamicQuery)
