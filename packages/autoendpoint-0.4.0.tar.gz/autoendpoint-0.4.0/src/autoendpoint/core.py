import asyncio
import csv
import io
from typing import Any, List, Optional, Type, get_args, get_origin

from fastapi import APIRouter, Body, File, HTTPException, Path, Query, UploadFile, status
from sqlalchemy import inspect
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import SQLModel, select
from strawberry.fastapi import GraphQLRouter

from autoendpoint.graphql_utils import generate_graphql_schema
from autoendpoint.models import generate_crud_models
from autoendpoint.utils import is_primary_key


class RelationRouter:
    """Handles the creation and registration of linking routes for m:n relationships.

    Attributes:
        model_a (Type[SQLModel]): The first SQLModel class in the relationship.
        model_b (Type[SQLModel]): The second SQLModel class in the relationship.
        rel_name (str): The name of the relationship on model_a.
        _db_session (AsyncSession): The asynchronous database session.
        router (APIRouter): The FastAPI router for these relationship endpoints.
    """

    def __init__(
        self,
        model_a: Type[SQLModel],
        model_b: Type[SQLModel],
        rel_name: str,
        db_session: AsyncSession,
        link_model: Optional[Type[SQLModel]] = None
    ) -> None:
        """Initializes the RelationRouter for m:n relationships.

        Args:
            model_a (Type[SQLModel]): The first SQLModel class in the relationship.
            model_b (Type[SQLModel]): The second SQLModel class in the relationship.
            rel_name (str): The name of the relationship on model_a.
            db_session (AsyncSession): The asynchronous database session.
            link_model (Optional[Type[SQLModel]]): The optional link model for many-to-many.
        """
        self.model_a = model_a
        self.model_b = model_b
        self.rel_name = rel_name
        self._db_session = db_session
        self.link_model = link_model

        self.router = APIRouter(
            prefix=f"/{model_a.__name__.lower()}",
            tags=[model_a.__name__]
        )
        self._setup_routes()

    def _setup_routes(self) -> None:
        """Configures the relationship routes for linking and unlinking."""
        model = self.model_a
        target_model = self.model_b
        rel_name = self.rel_name

        pk_name = next(
            (n for n, f in model.model_fields.items() if is_primary_key(field=f)),
            "id"
        )
        pk_type = model.model_fields[pk_name].annotation
        model_pk_param = f"{model.__name__.lower()}_{pk_name}"

        target_pk_name = next(
            (n for n, f in target_model.model_fields.items() if is_primary_key(field=f)),
            "id"
        )
        target_pk_type = target_model.model_fields[target_pk_name].annotation
        target_pk_param = f"{target_model.__name__.lower()}_{target_pk_name}"

        # Add link route
        self._add_link_route(
            pk_name=pk_name,
            pk_type=pk_type,
            model_pk_param=model_pk_param,
            target_pk_name=target_pk_name,
            target_pk_type=target_pk_type,
            target_pk_param=target_pk_param
        )

        # Add patch route (if link model exists)
        if self.link_model:
            self._add_patch_route(
                pk_name=pk_name,
                pk_type=pk_type,
                model_pk_param=model_pk_param,
                target_pk_name=target_pk_name,
                target_pk_type=target_pk_type,
                target_pk_param=target_pk_param
            )

        # Add unlink route
        self._add_unlink_route(
            pk_name=pk_name,
            pk_type=pk_type,
            model_pk_param=model_pk_param,
            target_pk_name=target_pk_name,
            target_pk_type=target_pk_type,
            target_pk_param=target_pk_param
        )

    def _add_link_route(
        self,
        pk_name: str,
        pk_type: Type,
        model_pk_param: str,
        target_pk_name: str,
        target_pk_type: Type,
        target_pk_param: str
    ) -> None:
        """Adds a POST route to link two models in a relationship.

        Args:
            pk_name (str): Primary key field name of the source model.
            pk_type (Type): Type of the primary key.
            model_pk_param (str): Parameter name for the source model ID in the path.
            target_pk_name (str): Primary key field name of the target model.
            target_pk_type (Type): Type of the target primary key.
            target_pk_param (str): Parameter name for the target model ID in the path.
        """
        model = self.model_a
        target_model = self.model_b
        rel_name = self.rel_name

        @self.router.post(
            f"/{{{model_pk_param}}}/{rel_name}/{{{target_pk_param}}}",
            description=f"Link a {target_model.__name__} to this {model.__name__}",
            summary=f"Link {target_model.__name__} to {model.__name__}"
        )
        async def link_relationship(
            pk_value: pk_type = Path(
                ...,
                alias=model_pk_param,
                description=f"The {model.__name__} {pk_name}"
            ),
            target_pk_value: target_pk_type = Path(
                ...,
                alias=target_pk_param,
                description=f"The {target_model.__name__} {target_pk_name}"
            )
        ) -> Any:
            """Links two records together."""
            # Verify both records exist
            parent = await self._db_session.get(entity=model, ident=pk_value)
            if not parent:
                raise HTTPException(
                    status_code=404,
                    detail=f"{model.__name__} not found"
                )

            target = await self._db_session.get(
                entity=target_model,
                ident=target_pk_value
            )
            if not target:
                raise HTTPException(
                    status_code=404,
                    detail=f"{target_model.__name__} not found"
                )

            # Add to collection
            from sqlalchemy.orm import selectinload
            # Reload with relationship to check if already linked
            stmt = (
                select(model)
                .where(getattr(model, pk_name) == pk_value)
                .options(selectinload(getattr(model, rel_name)))
            )
            results = await self._db_session.execute(stmt)
            parent = results.scalars().first()

            collection = getattr(parent, rel_name)
            if target not in collection:
                collection.append(target)
                try:
                    self._db_session.add(parent)
                    await self._db_session.commit()
                except IntegrityError as e:
                    await self._db_session.rollback()
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=(
                            f"Integrity error: "
                            f"{str(e.orig) if hasattr(e, 'orig') else str(e)}"
                        )
                    )

            # If we have a link_model, let's find the link record to return it
            if self.link_model:
                link_mapper = inspect(self.link_model)
                query = select(self.link_model)

                for column in link_mapper.columns:
                    for fk in column.foreign_keys:
                        if fk.references(model.__table__):
                            query = query.where(column == pk_value)
                        elif fk.references(target_model.__table__):
                            query = query.where(column == target_pk_value)

                link_result = await self._db_session.execute(query)
                link_record = link_result.scalars().first()
                if link_record:
                    return link_record

            return {
                "detail": f"Linked {target_model.__name__} to {model.__name__}"
            }

    def _add_patch_route(
        self,
        pk_name: str,
        pk_type: Type,
        model_pk_param: str,
        target_pk_name: str,
        target_pk_type: Type,
        target_pk_param: str
    ) -> None:
        """Adds a PATCH route to update link data in a many-to-many relationship.

        Args:
            pk_name (str): Primary key field name of the source model.
            pk_type (Type): Type of the primary key.
            model_pk_param (str): Parameter name for the source model ID in the path.
            target_pk_name (str): Primary key field name of the target model.
            target_pk_type (Type): Type of the target primary key.
            target_pk_param (str): Parameter name for the target model ID in the path.
        """
        model = self.model_a
        target_model = self.model_b
        rel_name = self.rel_name

        if self.link_model:
            _, _, PatchModel = generate_crud_models(model=self.link_model)

            @self.router.patch(
                f"/{{{model_pk_param}}}/{rel_name}/{{{target_pk_param}}}",
                response_model=self.link_model,
                description=(
                    f"Update the link between {model.__name__} "
                    f"and {target_model.__name__}"
                ),
                summary="Update relationship link"
            )
            async def patch_relationship(
                item: PatchModel = Body(
                    ...,
                    description="The link data to patch"
                ),
                pk_value: pk_type = Path(
                    ...,
                    alias=model_pk_param,
                    description=f"The {model.__name__} {pk_name}"
                ),
                target_pk_value: target_pk_type = Path(
                    ...,
                    alias=target_pk_param,
                    description=f"The {target_model.__name__} {target_pk_name}"
                )
            ) -> Any:
                """Updates the link record."""
                link_mapper = inspect(self.link_model)
                query = select(self.link_model)
                for column in link_mapper.columns:
                    for fk in column.foreign_keys:
                        if fk.references(model.__table__):
                            query = query.where(column == pk_value)
                        elif fk.references(target_model.__table__):
                            query = query.where(column == target_pk_value)

                results = await self._db_session.execute(query)
                db_item = results.scalars().first()
                if not db_item:
                    raise HTTPException(
                        status_code=404,
                        detail="Relationship link not found"
                    )

                update_data = item.model_dump(exclude_unset=True)
                for key, value in update_data.items():
                    setattr(db_item, key, value)

                try:
                    self._db_session.add(db_item)
                    await self._db_session.commit()
                    await self._db_session.refresh(db_item)
                    return db_item
                except IntegrityError as e:
                    await self._db_session.rollback()
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=(
                            f"Integrity error: "
                            f"{str(e.orig) if hasattr(e, 'orig') else str(e)}"
                        )
                    )

    def _add_unlink_route(
        self,
        pk_name: str,
        pk_type: Type,
        model_pk_param: str,
        target_pk_name: str,
        target_pk_type: Type,
        target_pk_param: str
    ) -> None:
        """Adds a DELETE route to unlink two models in a relationship.

        Args:
            pk_name (str): Primary key field name of the source model.
            pk_type (Type): Type of the primary key.
            model_pk_param (str): Parameter name for the source model ID in the path.
            target_pk_name (str): Primary key field name of the target model.
            target_pk_type (Type): Type of the target primary key.
            target_pk_param (str): Parameter name for the target model ID in the path.
        """
        model = self.model_a
        target_model = self.model_b
        rel_name = self.rel_name

        @self.router.delete(
            f"/{{{model_pk_param}}}/{rel_name}/{{{target_pk_param}}}",
            description=(
                f"Unlink a {target_model.__name__} "
                f"from this {model.__name__}"
            ),
            summary=f"Unlink {target_model.__name__} from {model.__name__}"
        )
        async def unlink_relationship(
            pk_value: pk_type = Path(
                ...,
                alias=model_pk_param,
                description=f"The {model.__name__} {pk_name}"
            ),
            target_pk_value: target_pk_type = Path(
                ...,
                alias=target_pk_param,
                description=f"The {target_model.__name__} {target_pk_name}"
            )
        ) -> Any:
            """Unlinks two records."""
            # Reload with relationship
            from sqlalchemy.orm import selectinload
            stmt = (
                select(model)
                .where(getattr(model, pk_name) == pk_value)
                .options(selectinload(getattr(model, rel_name)))
            )
            results = await self._db_session.execute(statement=stmt)
            parent = results.scalars().first()

            if not parent:
                raise HTTPException(
                    status_code=404,
                    detail=f"{model.__name__} not found"
                )

            target = await self._db_session.get(
                entity=target_model,
                ident=target_pk_value
            )
            if not target:
                raise HTTPException(
                    status_code=404,
                    detail=f"{target_model.__name__} not found"
                )

            collection = getattr(parent, rel_name)
            if target in collection:
                collection.remove(target)
                self._db_session.add(instance=parent)
                await self._db_session.commit()
                return {
                    "detail": (
                        f"Unlinked {target_model.__name__} "
                        f"from {model.__name__}"
                    )
                }

            return {
                "detail": (
                    f"{target_model.__name__} was not "
                    f"linked to {model.__name__}"
                )
            }


class ModelRouter:
    """Handles the creation and registration of CRUD routes for a single SQLModel.

    Attributes:
        model (Type[SQLModel]): The SQLModel class.
        _db_session (AsyncSession): The asynchronous database session.
        router (APIRouter): The FastAPI router for this model's endpoints.
    """

    def __init__(self, model: Type[SQLModel], db_session: AsyncSession) -> None:
        """Initializes the ModelRouter for a specific SQLModel.

        Args:
            model (Type[SQLModel]): The SQLModel class to handle.
            db_session (AsyncSession): The asynchronous database session.
        """
        self.model = model
        self._db_session = db_session
        self.name = model.__name__.lower()
        self.router = APIRouter(
            prefix=f"/{self.name}",
            tags=[model.__name__]
        )
        self._setup_routes()

    def _setup_routes(self) -> None:
        """Generates and registers CRUD endpoints for the model."""
        model_fields = self.model.model_fields
        CreateModel, UpdateModel, PatchModel = generate_crud_models(model=self.model)
        # Identify Primary Key
        pks = [n for n, f in model_fields.items() if is_primary_key(field=f)]
        if not pks:
            pk_name = "id"
        elif "id" in pks:
            pk_name = "id"
        else:
            pk_name = pks[0]

        self._add_read_all_route()
        self._add_create_one_route(CreateModel=CreateModel)
        self._add_bulk_csv_create_route(CreateModel=CreateModel)

        if pk_name:
            pk_type = model_fields[pk_name].annotation
            self._add_read_one_by_id_route(pk_name=pk_name, pk_type=pk_type)
            self._add_update_one_route(
                pk_name=pk_name,
                pk_type=pk_type,
                UpdateModel=UpdateModel
            )
            self._add_patch_one_route(
                pk_name=pk_name,
                pk_type=pk_type,
                PatchModel=PatchModel
            )
            self._add_delete_one_route(pk_name=pk_name, pk_type=pk_type)
            self._add_relationship_routes(pk_name=pk_name, pk_type=pk_type)

        self._add_read_one_by_unique_field_route(model_fields=model_fields)
        self._add_read_by_field_route(model_fields=model_fields)

    def _add_read_all_route(self) -> None:
        """Adds a GET route to retrieve all records of the model with pagination."""
        model = self.model

        @self.router.get(
            "",
            response_model=List[model],
            description=f"Retrieve all {model.__name__} records",
            summary=f"Retrieve all {model.__name__}"
        )
        async def read_all(
            limit: int = Query(
                default=10,
                description="The maximum number of records to return. Set to 0 to return all records"
            ),
            page: int = Query(
                default=1,
                description="The page number to return"
            )
        ) -> Any:
            """Retrieves all records with pagination."""
            stmt = select(model)
            if limit > 0:
                offset = (page - 1) * limit
                stmt = stmt.offset(offset=offset).limit(limit=limit)
            results = await self._db_session.execute(stmt)
            return results.scalars().all()

    def _add_create_one_route(self, CreateModel: Type[SQLModel]) -> None:
        """Adds a POST route to create a new record.

        Args:
            CreateModel (Type[SQLModel]): The Pydantic model for creation data.
        """
        model = self.model

        @self.router.post(
            "",
            response_model=model,
            description=f"Create a new {model.__name__} record",
            summary=f"Create {model.__name__}"
        )
        async def create_one(
            item: CreateModel = Body(
                ...,
                description=f"The {model.__name__} data to create"
            )
        ) -> Any:
            """Creates a new record."""
            db_item = model(**item.model_dump())
            try:
                self._db_session.add(db_item)
                await self._db_session.commit()
                await self._db_session.refresh(db_item)
                return db_item
            except IntegrityError as e:
                await self._db_session.rollback()
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Integrity error: {str(e.orig) if hasattr(e, 'orig') else str(e)}"
                )

    def _add_bulk_csv_create_route(self, CreateModel: Type[SQLModel]) -> None:
        """Adds a POST route to bulk create records from a CSV file.

        The endpoint is added at `/{model_name}/bulk/csv`. It accepts a CSV file
        upload and an optional `has_header` query parameter.

        Args:
            CreateModel (Type[SQLModel]): The Pydantic model for creation data,
                used to validate each row from the CSV.
        """
        model = self.model

        @self.router.post(
            "/bulk/csv",
            response_model=List[model],
            description=f"Bulk create {model.__name__} records from a CSV file. The first row must be a header matching the model fields.",
            summary=f"Bulk create {model.__name__} from CSV"
        )
        async def bulk_csv_create(
            file: UploadFile = File(..., description="The CSV file to upload"),
            has_header: bool = Query(True, description="Whether the CSV has a header row. If False, columns are matched by order to the model's fields.")
        ) -> Any:
            """Bulk creates records from a CSV file."""
            if not file.filename.endswith('.csv'):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="File must be a CSV"
                )

            content = await file.read()
            try:
                decoded = content.decode('utf-8')
            except UnicodeDecodeError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="CSV file must be UTF-8 encoded"
                )

            io_string = io.StringIO(decoded)
            if has_header:
                csv_reader = csv.DictReader(io_string)
            else:
                # If no header, we assume columns follow the CreateModel field order
                csv_reader_raw = csv.reader(io_string)
                field_names = list(CreateModel.model_fields.keys())
                
                def dict_generator():
                    for row in csv_reader_raw:
                        if not row: continue
                        yield dict(zip(field_names, row))
                
                csv_reader = dict_generator()

            items = []
            for row in csv_reader:
                try:
                    # Validate row data using CreateModel
                    item = CreateModel(**row)
                    db_item = model(**item.model_dump())
                    items.append(db_item)
                except Exception as e:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Validation error in CSV row: {str(e)}"
                    )

            if not items:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="CSV file is empty or contains no valid data"
                )

            try:
                self._db_session.add_all(items)
                await self._db_session.commit()
                for item in items:
                    await self._db_session.refresh(item)
                return items
            except IntegrityError as e:
                await self._db_session.rollback()
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Integrity error during bulk insertion: {str(e.orig) if hasattr(e, 'orig') else str(e)}"
                )

    def _add_read_one_by_id_route(self, pk_name: str, pk_type: Type) -> None:
        """Adds a GET route to retrieve a single record by its primary key.

        Args:
            pk_name (str): The primary key field name.
            pk_type (Type): The type of the primary key.
        """
        model = self.model

        @self.router.get(
            f"/{{{pk_name}}}",
            response_model=model,
            description=f"Retrieve a {model.__name__} record by {pk_name}",
            summary=f"Retrieve {model.__name__} by {pk_name}"
        )
        async def read_one_by_id(
            pk_value: pk_type = Path(
                ...,
                alias=pk_name,
                description=f"The {model.__name__} record to retrieve by {pk_name}"
            )
        ) -> Any:
            """Retrieves a single record by its ID."""
            stmt = select(model).where(getattr(model, pk_name) == pk_value)
            results = await self._db_session.execute(stmt)
            records = results.scalars().all()
            if not records:
                raise HTTPException(
                    status_code=404,
                    detail=f"{model.__name__} not found"
                )
            if len(records) > 1:
                raise HTTPException(
                    status_code=400,
                    detail=f"Multiple {model.__name__} records found for {pk_name}={pk_value}"
                )
            return records[0]

    def _add_update_one_route(self, pk_name: str, pk_type: Type, UpdateModel: Type[SQLModel]) -> None:
        """Adds a PUT route to update a record by its primary key.

        Args:
            pk_name (str): The primary key field name.
            pk_type (Type): The type of the primary key.
            UpdateModel (Type[SQLModel]): The Pydantic model for update data.
        """
        model = self.model

        @self.router.put(
            f"/{{{pk_name}}}",
            response_model=model,
            description=f"Update a {model.__name__} record by {pk_name}",
            summary=f"Update {model.__name__} by {pk_name}"
        )
        async def update_one(
            item: UpdateModel = Body(
                ...,
                description=f"The {model.__name__} data to update"
            ),
            pk_value: pk_type = Path(
                ...,
                alias=pk_name,
                description=f"The {model.__name__} record to update by {pk_name}"
            )
        ) -> Any:
            """Updates an existing record by its ID."""
            stmt = select(model).where(getattr(model, pk_name) == pk_value)
            results = await self._db_session.execute(stmt)
            db_item = results.scalars().first()
            if not db_item:
                raise HTTPException(
                    status_code=404,
                    detail=f"{model.__name__} not found"
                )

            update_data = item.model_dump(exclude_unset=False)
            for key, value in update_data.items():
                setattr(db_item, key, value)

            try:
                self._db_session.add(db_item)
                await self._db_session.commit()
                await self._db_session.refresh(db_item)
                return db_item
            except IntegrityError as e:
                await self._db_session.rollback()
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Integrity error: {str(e.orig) if hasattr(e, 'orig') else str(e)}"
                )

    def _add_patch_one_route(self, pk_name: str, pk_type: Type, PatchModel: Type[SQLModel]) -> None:
        """Adds a PATCH route to partially update a record by its primary key.

        Args:
            pk_name (str): The primary key field name.
            pk_type (Type): The type of the primary key.
            PatchModel (Type[SQLModel]): The Pydantic model for patch data.
        """
        model = self.model

        @self.router.patch(
            f"/{{{pk_name}}}",
            response_model=model,
            description=f"Partially update a {model.__name__} record by {pk_name}",
            summary=f"Patch {model.__name__} by {pk_name}"
        )
        async def patch_one(
            item: PatchModel = Body(
                ...,
                description=f"The {model.__name__} data to patch"
            ),
            pk_value: pk_type = Path(
                ...,
                alias=pk_name,
                description=f"The {model.__name__} record to patch by {pk_name}"
            )
        ) -> Any:
            """Partially updates an existing record by its ID."""
            stmt = select(model).where(getattr(model, pk_name) == pk_value)
            results = await self._db_session.execute(stmt)
            db_item = results.scalars().first()
            if not db_item:
                raise HTTPException(
                    status_code=404,
                    detail=f"{model.__name__} not found"
                )

            update_data = item.model_dump(exclude_unset=True)
            for key, value in update_data.items():
                setattr(db_item, key, value)

            try:
                self._db_session.add(db_item)
                await self._db_session.commit()
                await self._db_session.refresh(db_item)
                return db_item
            except IntegrityError as e:
                await self._db_session.rollback()
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Integrity error: {str(e.orig) if hasattr(e, 'orig') else str(e)}"
                )

    def _add_delete_one_route(self, pk_name: str, pk_type: Type) -> None:
        """Adds a DELETE route to remove a record by its primary key.

        Args:
            pk_name (str): The primary key field name.
            pk_type (Type): The type of the primary key.
        """
        model = self.model

        @self.router.delete(
            f"/{{{pk_name}}}",
            description=f"Delete a {model.__name__} record by {pk_name}",
            summary=f"Delete {model.__name__} by {pk_name}"
        )
        async def delete_one(
            pk_value: pk_type = Path(
                ...,
                alias=pk_name,
                description=f"The {model.__name__} record to delete by {pk_name}"
            )
        ) -> Any:
            """Deletes a record by its ID."""
            stmt = select(model).where(getattr(model, pk_name) == pk_value)
            results = await self._db_session.execute(stmt)
            db_item = results.scalars().first()
            if not db_item:
                raise HTTPException(
                    status_code=404,
                    detail=f"{model.__name__} not found"
                )

            await self._db_session.delete(db_item)
            await self._db_session.commit()
            return {"detail": f"{model.__name__} deleted"}

    def _add_read_one_by_unique_field_route(self, model_fields: dict) -> None:
        """Adds a GET route to retrieve a record by a unique field.

        Args:
            model_fields (dict): Dictionary of model fields.
        """
        model = self.model

        @self.router.get(
            "/unique/{field_name}",
            response_model=model,
            description=f"Retrieve a {model.__name__} record by a unique field and value",
            summary=f"Retrieve {model.__name__} by unique field"
        )
        async def read_one_by_unique_field(
            field_name: str = Path(
                ...,
                description="The name of the unique field to search by"
            ),
            value: Any = Query(
                ...,
                description="The value of the unique field to search for"
            )
        ) -> Any:
            """Retrieves a single record by a unique field value."""
            if field_name not in model_fields:
                raise HTTPException(
                    status_code=400,
                    detail=f"Field '{field_name}' not found in {model.__name__}"
                )

            stmt = select(model).where(getattr(model, field_name) == value)
            results = await self._db_session.execute(stmt)
            records = results.scalars().all()

            if not records:
                raise HTTPException(
                    status_code=404,
                    detail=f"{model.__name__} not found"
                )
            if len(records) > 1:
                raise HTTPException(
                    status_code=400,
                    detail=f"Multiple {model.__name__} records found for {field_name}={value}"
                )
            return records[0]

    def _add_read_by_field_route(self, model_fields: dict) -> None:
        """Adds a GET route to retrieve records filtered by a field value.

        Args:
            model_fields (dict): Dictionary of model fields.
        """
        model = self.model

        @self.router.get(
            "/filter/{field_name}",
            response_model=List[model],
            description=f"Retrieve {model.__name__} records by a field and value",
            summary=f"Retrieve {model.__name__} by field"
        )
        async def read_by_field(
            field_name: str = Path(
                ...,
                description="The name of the field to filter by"
            ),
            value: Any = Query(
                ...,
                description="The value of the field to filter for"
            )
        ) -> Any:
            """Retrieves records filtered by a field value."""
            if field_name not in model_fields:
                raise HTTPException(
                    status_code=400,
                    detail=f"Field '{field_name}' not found in {model.__name__}"
                )

            stmt = select(model).where(getattr(model, field_name) == value)
            results = await self._db_session.execute(stmt)
            return results.scalars().all()

    def _add_relationship_routes(self, pk_name: str, pk_type: Type) -> None:
        """Adds nested routes for relationships (1:n and 1:1)."""
        model = self.model
        mapper = inspect(model)

        for rel in mapper.relationships:
            # Check if it is a 1:n or 1:1 relationship
            # Read-only nested routes are also useful for many-to-many

            rel_name = rel.key
            uselist = rel.uselist

            # Define parameter names to avoid duplicates in nested routes
            model_pk_param = f"{model.__name__.lower()}_{pk_name}"

            if uselist:
                def make_read_relationship_list(r_name: str, m_pk_param: str) -> Any:
                    """Factory to create a list relationship reader.

                    Args:
                        r_name (str): The name of the relationship.
                        m_pk_param (str): The parameter name for the parent model's PK.

                    Returns:
                        Callable: The read_relationship async function.
                    """
                    @self.router.get(
                        f"/{{{m_pk_param}}}/{r_name}",
                        response_model=List[Any],
                        description=f"Retrieve all {r_name} for a specific {model.__name__}",
                        summary=f"Retrieve {r_name} by {model.__name__} {pk_name}"
                    )
                    async def read_relationship(
                        pk_value: pk_type = Path(
                            ...,
                            alias=m_pk_param,
                            description=f"The {model.__name__} {pk_name}"
                        )
                    ) -> Any:
                        """Retrieves related records for a specific model instance."""
                        from sqlalchemy.orm import selectinload
                        stmt = (
                            select(model)
                            .where(getattr(model, pk_name) == pk_value)
                            .options(selectinload(getattr(model, r_name)))
                        )
                        results = await self._db_session.execute(stmt)
                        parent = results.scalars().first()
                        if not parent:
                            raise HTTPException(
                                status_code=404,
                                detail=f"{model.__name__} not found"
                            )
                        return getattr(parent, r_name)
                    return read_relationship

                make_read_relationship_list(r_name=rel_name, m_pk_param=model_pk_param)
            else:
                def make_read_relationship_single(r_name: str, m_pk_param: str) -> Any:
                    """Factory to create a single relationship reader.

                    Args:
                        r_name (str): The name of the relationship.
                        m_pk_param (str): The parameter name for the parent model's PK.

                    Returns:
                        Callable: The read_relationship async function.
                    """
                    @self.router.get(
                        f"/{{{m_pk_param}}}/{r_name}",
                        response_model=Optional[Any],
                        description=f"Retrieve the {r_name} for a specific {model.__name__}",
                        summary=f"Retrieve {r_name} by {model.__name__} {pk_name}"
                    )
                    async def read_relationship(
                        pk_value: pk_type = Path(
                            ...,
                            alias=m_pk_param,
                            description=f"The {model.__name__} {pk_name}"
                        )
                    ) -> Any:
                        """Retrieves the related record for a specific model instance."""
                        from sqlalchemy.orm import selectinload
                        stmt = (
                            select(model)
                            .where(getattr(model, pk_name) == pk_value)
                            .options(selectinload(getattr(model, r_name)))
                        )
                        results = await self._db_session.execute(stmt)
                        parent = results.scalars().first()
                        if not parent:
                            raise HTTPException(
                                status_code=404,
                                detail=f"{model.__name__} not found"
                            )
                        return getattr(parent, r_name)
                    return read_relationship

                make_read_relationship_single(r_name=rel_name, m_pk_param=model_pk_param)


class AutoEndpoint:
    """Automatic FastAPI endpoint generator for SQLModel models.

    This class takes a database session and a list of SQLModel models and automatically
    generates a set of CRUD (Create, Read, Update, Delete) endpoints for each model.
    The generated endpoints are registered to a FastAPI APIRouter.

    Attributes:
        _db_session (AsyncSession): The asynchronous database session.
        models (List[Type[SQLModel]]): A list of SQLModel classes to generate endpoints for.
        router (APIRouter): The FastAPI router containing the generated endpoints.
    """

    def __init__(
        self,
        db_session: AsyncSession,
        models: List[Type[SQLModel]],
        enable_graphql: bool = True,
        check_consistency: bool = False
    ) -> None:
        """Initializes the AutoEndpoint with a database session and models.

        Args:
            db_session (AsyncSession): The asynchronous SQLAlchemy/SQLModel session.
            models (List[Type[SQLModel]]): A list of SQLModel classes to be exposed via API.
            enable_graphql (bool): Whether to enable the GraphQL endpoint. Defaults to True.
            check_consistency (bool): Whether to check if models are consistent with the DB. Defaults to False.
        """
        self._db_session = db_session
        self.models = models
        self.enable_graphql = enable_graphql
        self.check_consistency = check_consistency
        self._consistency_task: Optional[asyncio.Task] = None
        self.router = APIRouter()
        self._build_routes()

    def _build_routes(self) -> None:
        """Builds all CRUD and relationship routes for registered models."""
        if self.check_consistency:
            try:
                loop = asyncio.get_running_loop()
                if loop.is_running():
                    self._consistency_task = loop.create_task(self._check_models_consistency())
                    
                    def handle_exception(t):
                        try:
                            t.result()
                        except Exception as e:
                            # We re-raise or handle as needed. 
                            # Since it's a background task, we might want to log it
                            # or set an attribute. For development, printing to stderr
                            # is often helpful if no logger is configured.
                            import sys
                            print(f"\n[AutoEndpoint] Consistency Check Error: {e}", file=sys.stderr)
                            
                    self._consistency_task.add_done_callback(handle_exception)
            except RuntimeError:
                # No running event loop, this might happen in some environments
                # We skip the check or find another way
                pass

        for model in self.models:
            model_router = ModelRouter(model=model, db_session=self._db_session)
            self.router.include_router(router=model_router.router)
            self._add_relation_routes(model=model)

        if self.enable_graphql:
            self._add_graphql_route()

    def _add_relation_routes(self, model: Type[SQLModel]) -> None:
        """Detects many-to-many relationships and adds their routers.

        Args:
            model (Type[SQLModel]): The SQLModel class to inspect for relationships.
        """
        mapper = inspect(model)
        for rel in mapper.relationships:
            if rel.secondary is not None:
                # Many-to-Many relationship
                target_model = rel.mapper.class_
                rel_name = rel.key

                # Try to find the link model among registered models
                link_model = None
                for m in self.models:
                    if getattr(m, "__table__", None) is rel.secondary:
                        link_model = m
                        break

                # We instantiate a RelationRouter for this specific relationship.
                # Note: This will create routes like /model_a/{id}/rel_name/{target_id}
                relation_router = RelationRouter(
                    model_a=model,
                    model_b=target_model,
                    rel_name=rel_name,
                    db_session=self._db_session,
                    link_model=link_model
                )
                self.router.include_router(router=relation_router.router)

    def _add_graphql_route(self) -> None:
        """Adds a GraphQL route using Strawberry and the registered models."""
        schema = generate_graphql_schema(
            models=self.models,
            db_session=self._db_session
        )
        graphql_app = GraphQLRouter(schema=schema)
        self.router.include_router(
            router=graphql_app,
            prefix="/graphql",
            tags=["GraphQL"]
        )

    def init_app(self, app: Any) -> None:
        """Includes the generated router into a FastAPI application.

        Args:
            app: The FastAPI application instance.
        """
        app.include_router(router=self.router)

    async def _check_models_consistency(self) -> None:
        """Checks if the registered models are consistent with the database schema.

        This method verifies that each model has a corresponding table in the
        database and that the columns in the database match those defined in
        the SQLModel class.

        Raises:
            RuntimeError: If a table is missing or if there is a mismatch between
                model columns and database columns.
        """
        # Use a mock if provided in the session's info
        mock_inspector = self._db_session.info.get("mock_inspector")

        def validate(sync_conn):
            if mock_inspector:
                insp = mock_inspector
            else:
                insp = inspect(sync_conn)
            
            # Cache for table names by schema
            schema_tables = {}

            def get_tables_for_schema(schema):
                if schema not in schema_tables:
                    schema_tables[schema] = set(insp.get_table_names(schema=schema))
                return schema_tables[schema]
            
            for model in self.models:
                table_name = model.__tablename__
                # Get schema from model if specified
                schema = getattr(model.__table__, "schema", None)
                
                db_tables = get_tables_for_schema(schema)
                
                if table_name not in db_tables:
                    error_msg = f"Table '{table_name}'"
                    if schema:
                        error_msg += f" in schema '{schema}'"
                    error_msg += f" for model '{model.__name__}' not found in database."
                    raise RuntimeError(error_msg)
                
                columns_info = insp.get_columns(table_name, schema=schema)
                db_columns = {c['name'] for c in columns_info}
                model_columns = set(model.__table__.columns.keys())
                
                missing_in_db = model_columns - db_columns
                missing_in_model = db_columns - model_columns
                
                if missing_in_db or missing_in_model:
                    error_msg = f"Model '{model.__name__}' is inconsistent with table '{table_name}'"
                    if schema:
                        error_msg += f" in schema '{schema}'"
                    error_msg += "."
                    
                    if missing_in_db:
                        error_msg += f" Missing columns in DB: {missing_in_db}."
                    if missing_in_model:
                        error_msg += f" Columns in DB not in Model: {missing_in_model}."
                        
                    raise RuntimeError(error_msg)
        
        if mock_inspector:
            validate(None)
            return

        # Note: We use the session to get the bind. In some cases, 
        # get_bind() might return an AsyncEngine or AsyncConnection
        engine = self._db_session.get_bind()
        
        # Determine if we are using an async or sync engine
        # We check for the presence of run_sync which is typical for AsyncEngine/AsyncConnection
        from sqlalchemy.ext.asyncio import AsyncEngine, AsyncConnection, AsyncSession
        
        # If the bind is a sync engine but we are using an async driver (like aiosqlite),
        # SQLAlchemy might wrap it. However, the most reliable way to run_sync is to 
        # use an AsyncConnection if possible.
        
        if isinstance(engine, (AsyncEngine, AsyncConnection)):
            async with engine.connect() as conn:
                await conn.run_sync(validate)
        elif hasattr(engine, "run_sync"):
            async with engine.connect() as conn:
                await conn.run_sync(validate)
        else:
            # If the engine is sync, it might still be part of an async setup
            # Let's try to use the session's run_sync if it's an AsyncSession
            if isinstance(self._db_session, AsyncSession):
                await self._db_session.run_sync(lambda session: validate(session.bind))
            else:
                # Regular sync session and engine
                with engine.connect() as conn:
                    validate(conn)
