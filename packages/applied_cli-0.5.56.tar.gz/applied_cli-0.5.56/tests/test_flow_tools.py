import pytest

from applied_cli import tools


def _make_flow(*, edges=None):
    return {
        "id": "flow-1",
        "name": "Test Flow",
        "type": "conversational",
        "graph": {
            "nodes": [
                {
                    "id": "trigger-1",
                    "type": "trigger",
                    "position": {"x": 0, "y": 0},
                    "data": {"name": "trigger", "humanReadableName": "Trigger"},
                },
                {
                    "id": "branch-1",
                    "type": "branch",
                    "position": {"x": 0, "y": 0},
                    "data": {
                        "name": "branch-1",
                        "humanReadableName": "Branch",
                        "metadata": {
                            "value": "{trigger.messages[0].text}",
                            "comparisons": [
                                {
                                    "comparison_operator": "contains",
                                    "comparison_value": "pause",
                                    "comparison_type": "string",
                                }
                            ],
                        },
                    },
                },
                {
                    "id": "node-a",
                    "type": "completion",
                    "position": {"x": 0, "y": 0},
                    "data": {"name": "completion-a", "humanReadableName": "Agent Response"},
                },
                {
                    "id": "node-b",
                    "type": "completion",
                    "position": {"x": 0, "y": 0},
                    "data": {"name": "completion-b", "humanReadableName": "Agent Response"},
                },
            ],
            "edges": edges or [],
        },
    }


class FakeFlowClient:
    def __init__(self, flow):
        self.flow = flow
        self.created_node = None
        self.created_edge = None
        self.updated_nodes = []

    async def get_flow(self, flow_id):
        assert flow_id == self.flow["id"]
        return self.flow

    async def create_node(
        self,
        flow_id,
        name,
        metadata=None,
        description="",
        prompt="",
        guardrail="",
    ):
        self.created_node = {
            "flow_id": flow_id,
            "name": name,
            "metadata": metadata or {},
            "description": description,
            "prompt": prompt,
            "guardrail": guardrail,
        }
        return {
            "id": "node-new",
            "name": name,
            "data": {"name": f"{name}-node-new"},
        }

    async def create_edge(
        self,
        flow_id,
        source_node_id,
        target_node_id,
        source_handle=None,
        target_handle=None,
        label=None,
    ):
        self.created_edge = {
            "flow_id": flow_id,
            "source": source_node_id,
            "target": target_node_id,
            "source_handle": source_handle,
            "target_handle": target_handle,
            "label": label,
        }
        return {
            "id": "edge-new",
            "source": source_node_id,
            "target": target_node_id,
        }

    async def update_node(self, flow_id, node_id, **kwargs):
        self.updated_nodes.append(
            {
                "flow_id": flow_id,
                "node_id": node_id,
                **kwargs,
            }
        )
        return {"id": node_id, "name": node_id}


class FakeFlowRunClient:
    def __init__(self):
        self.ensure_kwargs = None
        self.run_kwargs = None

    async def get_flow(self, flow_id):
        return {
            "id": flow_id,
            "name": "Test Flow",
            "agent_id": "agent-1",
        }

    async def ensure_test_conversation(self, **kwargs):
        self.ensure_kwargs = kwargs
        return {"id": "conv-test"}

    async def run_flow(
        self,
        flow_id,
        trigger_data=None,
        wait=True,
        wait_timeout=60.0,
    ):
        self.run_kwargs = {
            "flow_id": flow_id,
            "trigger_data": trigger_data,
            "wait": wait,
            "wait_timeout": wait_timeout,
        }
        return {
            "id": "run-1",
            "status": "Success",
            "started_at": "2026-03-21T10:00:00Z",
            "spans": [],
            "actions": [],
        }


@pytest.mark.asyncio
async def test_flow_node_create_maps_ui_label_to_canonical_executor():
    flow = _make_flow(edges=[])
    client = FakeFlowClient(flow)

    result = await tools.flow_node_create(
        client,
        flow_id="flow-1",
        executor_type="Agent Response",
    )

    assert client.created_node["name"] == "completion"
    assert client.created_node["metadata"]["position"] == {"x": 380, "y": 0}
    assert "executor_type: completion" in result
    assert "ui_label: Agent Response" in result


@pytest.mark.asyncio
async def test_flow_edge_create_requires_explicit_branch_path():
    flow = _make_flow(edges=[{"id": "edge-1", "source": "trigger-1", "target": "branch-1"}])
    client = FakeFlowClient(flow)

    result = await tools.flow_edge_create(
        client,
        flow_id="flow-1",
        source_node_id="branch-1",
        target_node_id="node-a",
    )

    assert "Branch edges require a branch path" in result
    assert client.created_edge is None


@pytest.mark.asyncio
async def test_flow_edge_create_rejects_duplicate_branch_handle():
    flow = _make_flow(
        edges=[
            {"id": "edge-1", "source": "trigger-1", "target": "branch-1"},
            {
                "id": "edge-2",
                "source": "branch-1",
                "target": "node-a",
                "sourceHandle": "1",
            },
        ]
    )
    client = FakeFlowClient(flow)

    result = await tools.flow_edge_create(
        client,
        flow_id="flow-1",
        source_node_id="branch-1",
        target_node_id="node-b",
        branch="branch 1",
    )

    assert "already connected" in result
    assert client.created_edge is None


@pytest.mark.asyncio
async def test_flow_layout_spreads_branch_children():
    flow = _make_flow(
        edges=[
            {"id": "edge-1", "source": "trigger-1", "target": "branch-1"},
            {
                "id": "edge-2",
                "source": "branch-1",
                "target": "node-a",
                "sourceHandle": "1",
            },
            {
                "id": "edge-3",
                "source": "branch-1",
                "target": "node-b",
                "sourceHandle": "default",
            },
        ]
    )
    client = FakeFlowClient(flow)

    result = await tools.flow_layout(client, flow_id="flow-1")

    updates = {item["node_id"]: item["metadata"]["position"] for item in client.updated_nodes}
    assert updates["trigger-1"] == {"x": 0, "y": 0}
    assert updates["branch-1"] == {"x": 380, "y": 0}
    assert updates["node-a"]["x"] == 760
    assert updates["node-b"]["x"] == 760
    assert updates["node-a"]["y"] != updates["node-b"]["y"]
    assert "# Flow Layout Applied: Test Flow" in result


@pytest.mark.asyncio
async def test_flow_run_creates_test_conversation_for_contact_email():
    client = FakeFlowRunClient()

    result = await tools.flow_run(
        client,
        flow_id="flow-1",
        trigger_data={"message": "Pause my subscription"},
        contact_email="customer@example.com",
        contact_name="Customer Example",
    )

    assert client.ensure_kwargs == {
        "agent_id": "agent-1",
        "contact_email": "customer@example.com",
        "contact_name": "Customer Example",
        "contact_phone": None,
    }
    assert client.run_kwargs["trigger_data"]["conversation_id"] == "conv-test"
    assert client.run_kwargs["trigger_data"]["contact"]["email"] == "customer@example.com"
    assert "test_conversation_id: conv-test" in result


@pytest.mark.asyncio
async def test_flow_run_rejects_contact_overrides_for_existing_conversation():
    client = FakeFlowRunClient()

    result = await tools.flow_run(
        client,
        flow_id="flow-1",
        trigger_data={"conversation_id": "conv-existing"},
        contact_email="customer@example.com",
    )

    assert "Pass either trigger_data['conversation_id']" in result
    assert client.ensure_kwargs is None
    assert client.run_kwargs is None
