import json

import pytest

from applied_cli import tools

CONVERSATION_TARGET = {
    "id": "conv-audit-1",
    "title": "Payment not received",
    "status": "open",
    "resolution": "escalated",
    "type": "email",
    "remote_platform": "zendesk",
    "summary": "Expert says they completed the survey but never received payment.",
    "score": 1,
    "comment": "AI escalated without clear next steps.",
    "sentiment": "negative",
    "sentiment_score": -0.8,
    "created_at": "2026-03-19T10:00:00Z",
    "last_message_at": "2026-03-19T10:10:00Z",
    "message_count": 4,
    "contact": {"name": "Alex Expert", "email": "alex@example.com"},
    "label": {"name": "Payments"},
    "sublabel": {"name": "Payment not received"},
    "agent": {"id": "agent-1", "name": "Payments Bot"},
    "flags": [{"name": "Payment issue"}],
}

AUDIT_BATCH = {
    "id": "audit-batch-1",
    "target_type": "conversation",
    "rubric": "rubric-1",
    "period_start": "2026-03-16",
    "period_end": "2026-03-22",
    "status": "in_progress",
    "desired_sample_size": 25,
    "filters": {"label_id": "label-1", "is_test": False},
    "metric_aggregates": {
        "field-accuracy": {"count": 1, "choice_counts": {"Needs action": 1}}
    },
    "sample_size": 1,
    "audited_count": 1,
    "progress": 0.04,
    "derived_status": "in_progress",
    "created_by_id": "user-1",
    "created_at": "2026-03-23T10:00:00Z",
    "updated_at": "2026-03-23T10:05:00Z",
}

AUDIT_RUBRIC = {
    "id": "rubric-1",
    "name": "NewtonX Resolution Audit",
    "description": "Review failed payment conversations.",
    "applies_to": "conversation",
    "is_active": True,
    "field_ids": ["field-accuracy", "field-root-cause"],
    "created_at": "2026-03-20T09:00:00Z",
    "updated_at": "2026-03-20T09:00:00Z",
}

AUDIT_FIELDS = [
    {
        "id": "field-accuracy",
        "name": "accuracy_bucket",
        "label": "Accuracy",
        "description": "Was the AI response accurate?",
        "metric_type": "single_choice",
        "is_active": True,
        "order": 1,
        "range_min": None,
        "range_max": None,
        "allowed_choices": ["Good", "Needs action"],
    },
    {
        "id": "field-root-cause",
        "name": "root_cause",
        "label": "Root cause",
        "description": "Main failure reason",
        "metric_type": "text",
        "is_active": True,
        "order": 2,
        "range_min": None,
        "range_max": None,
        "allowed_choices": [],
    },
]

AUDIT_RATING = {
    "id": "audit-rating-1",
    "batch_id": "audit-batch-1",
    "target_type": "conversation",
    "target_object_id": "conv-audit-1",
    "rubric_id": "rubric-1",
    "audited_by_id": "user-1",
    "dimension_values": {
        "resolution": "escalated",
        "type": "email",
        "score": 1,
        "remote_platform": "zendesk",
        "label_name": "Payments",
        "sublabel_name": "Payment not received",
    },
    "denormalized_metric_values": {
        "field-accuracy": {"type": "single_choice", "value": "Needs action"},
        "field-root-cause": {
            "type": "text",
            "value": "AI recognizes payment status but cannot take action.",
        },
    },
    "notes": (
        "Most failures were action gaps. The bot knows payment status but cannot "
        "resend links or trigger a payout."
    ),
    "quality_score": 2.0,
    "is_completed": True,
    "metric_values": [
        {
            "metric_field_id": "field-accuracy",
            "metric_field_name": "accuracy_bucket",
            "metric_field_label": "Accuracy",
            "metric_field_type": "single_choice",
            "value": "Needs action",
        }
    ],
    "created_at": "2026-03-23T10:01:00Z",
    "updated_at": "2026-03-23T10:04:00Z",
}

MESSAGES = [
    {
        "id": "msg-1",
        "created_at": "2026-03-19T10:00:00Z",
        "role": "user",
        "text": "I completed the survey but never got paid.",
        "contact": {"email": "alex@example.com"},
    },
    {
        "id": "msg-2",
        "created_at": "2026-03-19T10:02:00Z",
        "role": "assistant",
        "content": "I can check that for you.",
        "agent": {"name": "Payments Bot"},
    },
]

REFERENCES = [
    {
        "id": "ref-1",
        "message_id": "msg-2",
        "response": {"id": "resp-1", "type": "qa", "question": "Payment status"},
        "content": {
            "id": "content-1",
            "title": "Payment status troubleshooting",
            "source_url": "https://example.com/payments",
        },
        "reason": "Matched payment article",
        "relevance_score": 0.92,
        "text_fragment_data": {"start": 0, "end": 24},
        "knowledge_gap": {"id": "gap-1", "title": "Missing payout action"},
    }
]

SPANS = [
    {
        "span_id": "span-1",
        "span_name": "completion",
        "scope_name": "flows",
        "duration": 1.1,
        "status_code": "ERROR",
        "status_message": "Escalated after lookup",
        "span_attributes": {"tool_name": "Agent Response"},
    }
]

FLOW_RUNS = [
    {
        "id": "flow-run-1",
        "conversation_id": "conv-audit-1",
        "status": "Failed",
        "started_at": "2026-03-19T10:01:00Z",
        "ended_at": "2026-03-19T10:01:03Z",
        "duration": 3.0,
        "flow": {"id": "flow-1", "name": "Payments Flow"},
    }
]


class FakeAuditClient:
    def __init__(self):
        self.query_conversations_kwargs = None
        self.list_ratings_kwargs = None
        self.update_rating_kwargs = None
        self.set_value_kwargs = None

    async def list_audit_metric_fields(self, *, is_active=None, limit=100):
        return AUDIT_FIELDS

    async def list_audit_rubrics(
        self,
        *,
        applies_to=None,
        is_active=None,
        name=None,
        limit=100,
    ):
        return [AUDIT_RUBRIC]

    async def get_audit_rubric(self, rubric_id):
        assert rubric_id == "rubric-1"
        return AUDIT_RUBRIC

    async def list_audit_batches(
        self,
        *,
        target_type=None,
        status=None,
        rubric_id=None,
        period_start_gte=None,
        period_start_lte=None,
        period_end_gte=None,
        period_end_lte=None,
        limit=100,
    ):
        return [AUDIT_BATCH]

    async def get_audit_batch(self, batch_id):
        assert batch_id == "audit-batch-1"
        return AUDIT_BATCH

    async def list_audit_ratings(
        self,
        *,
        batch_id=None,
        target_type=None,
        audited_by_id=None,
        audited_by_isnull=None,
        limit=100,
    ):
        self.list_ratings_kwargs = {
            "batch_id": batch_id,
            "target_type": target_type,
            "audited_by_id": audited_by_id,
            "audited_by_isnull": audited_by_isnull,
            "limit": limit,
        }
        return [AUDIT_RATING]

    async def get_audit_rating(self, rating_id):
        assert rating_id == "audit-rating-1"
        return AUDIT_RATING

    async def update_audit_rating(self, rating_id, *, notes=None, quality_score=None):
        self.update_rating_kwargs = {
            "rating_id": rating_id,
            "notes": notes,
            "quality_score": quality_score,
        }
        updated = dict(AUDIT_RATING)
        if notes is not None:
            updated["notes"] = notes
        if quality_score is not None:
            updated["quality_score"] = quality_score
        return updated

    async def set_audit_rating_value(self, rating_id, *, metric_field_id, value):
        self.set_value_kwargs = {
            "rating_id": rating_id,
            "metric_field_id": metric_field_id,
            "value": value,
        }
        updated = dict(AUDIT_RATING)
        updated["denormalized_metric_values"] = {
            **AUDIT_RATING["denormalized_metric_values"],
            metric_field_id: {"type": "single_choice", "value": value},
        }
        return updated

    async def query_conversations(self, **kwargs):
        self.query_conversations_kwargs = kwargs
        return [CONVERSATION_TARGET]

    async def get_conversation(self, conversation_id, *, shop_id=None):
        assert conversation_id == "conv-audit-1"
        assert shop_id is None
        return CONVERSATION_TARGET

    async def get_messages(
        self,
        *,
        conversation_id=None,
        ticket_id=None,
        limit=50,
        ordering="created_at",
        shop_id=None,
    ):
        assert conversation_id == "conv-audit-1"
        return MESSAGES

    async def get_conversation_references(self, conversation_id, *, shop_id=None):
        assert conversation_id == "conv-audit-1"
        return REFERENCES

    async def get_spans(self, object_type, object_id):
        assert object_type == "conversations"
        assert object_id == "conv-audit-1"
        return SPANS

    async def list_flow_runs(
        self,
        flow_id=None,
        conversation_id=None,
        status=None,
        limit=20,
    ):
        assert conversation_id == "conv-audit-1"
        return FLOW_RUNS


@pytest.mark.asyncio
async def test_audit_get_json_includes_batch_rubric_fields_and_notes_view():
    client = FakeAuditClient()

    result = await tools.audit_get(
        client,
        batch_id="audit-batch-1",
        ratings_view="notes",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["batch"]["id"] == "audit-batch-1"
    assert payload["rubric"]["name"] == "NewtonX Resolution Audit"
    assert len(payload["metric_fields"]) == 2
    assert payload["ratings"][0]["notes"].startswith("Most failures were action gaps")
    assert payload["ratings"][0]["target"]["contact_email"] == "alex@example.com"
    assert client.query_conversations_kwargs["filters"] == {
        "id": {"in": ["conv-audit-1"]}
    }


@pytest.mark.asyncio
async def test_audit_rating_list_json_filters_to_completed_notes_only():
    client = FakeAuditClient()

    result = await tools.audit_rating_list(
        client,
        batch_id="audit-batch-1",
        completed_only=True,
        notes_only=True,
        view="summary",
        output_format="json",
    )

    rows = json.loads(result)
    assert len(rows) == 1
    assert rows[0]["id"] == "audit-rating-1"
    assert rows[0]["contact_email"] == "alex@example.com"
    assert rows[0]["has_notes"] is True


@pytest.mark.asyncio
async def test_audit_rating_get_target_debug_includes_trace_bundle():
    client = FakeAuditClient()

    result = await tools.audit_rating_get(
        client,
        rating_id="audit-rating-1",
        target_debug=True,
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["rating"]["id"] == "audit-rating-1"
    assert payload["target"]["conversation"]["id"] == "conv-audit-1"
    assert len(payload["target"]["messages"]) == 2
    assert len(payload["target"]["message_references"]) == 1
    assert len(payload["target"]["spans"]) == 1
    assert len(payload["target"]["flow_runs"]) == 1


@pytest.mark.asyncio
async def test_audit_rating_update_updates_notes():
    client = FakeAuditClient()

    result = await tools.audit_rating_update(
        client,
        rating_id="audit-rating-1",
        notes="Primary issue is missing payout action.",
        quality_score=3.0,
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["notes"] == "Primary issue is missing payout action."
    assert payload["quality_score"] == 3.0
    assert client.update_rating_kwargs == {
        "rating_id": "audit-rating-1",
        "notes": "Primary issue is missing payout action.",
        "quality_score": 3.0,
    }
