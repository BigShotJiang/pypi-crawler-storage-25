from typer.testing import CliRunner

from applied_cli import __version__
from applied_cli import cli

runner = CliRunner()


def test_version_flag_long():
    result = runner.invoke(cli.app, ["--version"])

    assert result.exit_code == 0
    assert result.stdout == f"applied {__version__}\n"


def test_version_flag_short():
    result = runner.invoke(cli.app, ["-V"])

    assert result.exit_code == 0
    assert result.stdout == f"applied {__version__}\n"


def test_analytics_sql_command_accepts_inline_sql(monkeypatch):
    seen = {}

    async def fake_analytics_sql(
        client,
        *,
        sql,
        parameters=None,
        limit=None,
        output_format="csv",
    ):
        seen["sql"] = sql
        seen["parameters"] = parameters
        seen["limit"] = limit
        seen["output_format"] = output_format
        return "ok-inline"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: object())
    monkeypatch.setattr(cli.tools, "analytics_sql", fake_analytics_sql)

    result = runner.invoke(
        cli.app,
        [
            "analytics-sql",
            "--sql",
            "SELECT count() AS total FROM conversation_latest_state",
            "--param",
            'resolution="escalated"',
            "--param",
            "counts=[1,2]",
            "--limit",
            "25",
            "--format",
            "json",
        ],
    )

    assert result.exit_code == 0
    assert "ok-inline" in result.stdout
    assert seen == {
        "sql": "SELECT count() AS total FROM conversation_latest_state",
        "parameters": {"resolution": "escalated", "counts": [1, 2]},
        "limit": 25,
        "output_format": "json",
    }


def test_analytics_sql_command_accepts_sql_file(monkeypatch, tmp_path):
    query_file = tmp_path / "query.sql"
    query_file.write_text(
        "SELECT resolution, count() AS count FROM conversation_latest_state",
        encoding="utf-8",
    )
    seen = {}

    async def fake_analytics_sql(
        client,
        *,
        sql,
        parameters=None,
        limit=None,
        output_format="csv",
    ):
        seen["sql"] = sql
        return "ok-file"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: object())
    monkeypatch.setattr(cli.tools, "analytics_sql", fake_analytics_sql)

    result = runner.invoke(cli.app, ["analytics-sql", "--file", str(query_file)])

    assert result.exit_code == 0
    assert "ok-file" in result.stdout
    assert seen["sql"] == query_file.read_text(encoding="utf-8")
