"""Conversation identifier parsing for Applied and remote platform links."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import parse_qsl, urlparse

_UUID_RE = re.compile(
    r"\b[0-9a-fA-F]{8}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{12}\b"
)
_URL_RE = re.compile(r"https?://\S+")
_LONG_ID_RE = re.compile(r"\b[A-Za-z0-9_-]{6,}\b")
_NUMERIC_ID_RE = re.compile(r"^\d{5,}$")

_URL_STOPWORDS = {
    "agent",
    "app",
    "conversation",
    "conversations",
    "inbox",
    "ticket",
    "tickets",
}

_PLATFORM_ALIASES = {
    "dixa": "dixa",
    "gorgias": "gorgias",
    "gorgious": "gorgias",
    "zendesk": "zendesk",
}

_PLATFORM_HOST_SNIPPETS = {
    "dixa": "dixa.com",
    "gorgias": "gorgias.com",
    "zendesk": "zendesk.com",
}


def normalize_platform(platform: str | None) -> str | None:
    """Normalize remote platform aliases."""
    if not platform:
        return None
    normalized = platform.strip().lower()
    return _PLATFORM_ALIASES.get(normalized, normalized or None)


def _clean_token(token: str) -> str:
    return token.strip().strip("()[]{}<>,.;:'\"")


def _extract_first_url(text: str) -> str | None:
    match = _URL_RE.search(text)
    if not match:
        return None
    return _clean_token(match.group(0))


def _extract_uuid(text: str) -> str | None:
    match = _UUID_RE.search(text)
    return match.group(0) if match else None


def _extract_generic_tokens(text: str) -> list[str]:
    tokens = [_clean_token(match.group(0)) for match in _LONG_ID_RE.finditer(text)]
    seen: set[str] = set()
    result: list[str] = []
    for token in tokens:
        if token and token not in seen:
            seen.add(token)
            result.append(token)
    return result


def _extract_url_tokens(url: str) -> tuple[str | None, list[str]]:
    parsed = urlparse(url)
    host = parsed.netloc.lower()
    path_parts = [_clean_token(part) for part in parsed.path.split("/") if part]

    platform = None
    for name, snippet in _PLATFORM_HOST_SNIPPETS.items():
        if snippet in host:
            platform = name
            break

    tokens: list[str] = []

    if "appliedlabs.ai" in host:
        for idx, part in enumerate(path_parts):
            if part == "conversations" and idx + 1 < len(path_parts):
                tokens.append(path_parts[idx + 1])

    if platform == "gorgias":
        for idx, part in enumerate(path_parts):
            if part == "ticket" and idx + 1 < len(path_parts):
                tokens.append(path_parts[idx + 1])
    elif platform == "zendesk":
        for idx, part in enumerate(path_parts):
            if part == "tickets" and idx + 1 < len(path_parts):
                tokens.append(path_parts[idx + 1])
    elif platform == "dixa":
        for idx, part in enumerate(path_parts):
            if part in {"conversation", "conversations"} and idx + 1 < len(path_parts):
                tokens.append(path_parts[idx + 1])

    generic_tokens = []
    for part in path_parts:
        if part.lower() in _URL_STOPWORDS:
            continue
        if _UUID_RE.search(part) or _NUMERIC_ID_RE.match(part) or any(
            ch.isdigit() for ch in part
        ):
            generic_tokens.append(part)
    generic_tokens.extend(
        value
        for _, value in parse_qsl(parsed.query)
        if value and (_UUID_RE.search(value) or _NUMERIC_ID_RE.match(value))
    )

    tokens.extend(generic_tokens)

    seen: set[str] = set()
    deduped: list[str] = []
    for token in tokens:
        cleaned = _clean_token(token)
        if not cleaned:
            continue
        if cleaned not in seen:
            seen.add(cleaned)
            deduped.append(cleaned)

    return platform, deduped


def parse_conversation_identifier(
    identifier: str,
    *,
    platform_hint: str | None = None,
) -> dict[str, Any]:
    """Parse a conversation identifier into lookup candidates."""
    raw = identifier
    normalized = identifier.strip()
    platform = normalize_platform(platform_hint)

    prefixed_platform = None
    prefix, separator, suffix = normalized.partition(":")
    if separator:
        prefixed_platform = normalize_platform(prefix)
        if prefixed_platform in _PLATFORM_ALIASES.values() and suffix.strip():
            platform = prefixed_platform
            normalized = suffix.strip()

    url = _extract_first_url(normalized)
    if url:
        url_platform, tokens = _extract_url_tokens(url)
        platform = normalize_platform(url_platform or platform)
        conversation_id = next((token for token in tokens if _extract_uuid(token)), None)
        if conversation_id and "appliedlabs.ai" in urlparse(url).netloc.lower():
            return {
                "raw": raw,
                "normalized": normalized,
                "kind": "applied_url",
                "conversation_id": conversation_id,
                "platform": platform,
                "url": url,
                "remote_candidates": [],
                "primary_value": conversation_id,
            }

        remote_candidates = [token for token in tokens if token != conversation_id]
        return {
            "raw": raw,
            "normalized": normalized,
            "kind": "remote_url",
            "conversation_id": conversation_id if conversation_id else None,
            "platform": platform,
            "url": url,
            "remote_candidates": remote_candidates,
            "primary_value": remote_candidates[0] if remote_candidates else conversation_id,
        }

    conversation_id = _extract_uuid(normalized)
    if conversation_id:
        return {
            "raw": raw,
            "normalized": normalized,
            "kind": "conversation_id",
            "conversation_id": conversation_id,
            "platform": platform,
            "url": None,
            "remote_candidates": [],
            "primary_value": conversation_id,
        }

    remote_candidates = _extract_generic_tokens(normalized)
    if not remote_candidates and normalized:
        remote_candidates = [_clean_token(normalized)]

    return {
        "raw": raw,
        "normalized": normalized,
        "kind": "remote_id",
        "conversation_id": None,
        "platform": platform,
        "url": None,
        "remote_candidates": remote_candidates,
        "primary_value": remote_candidates[0] if remote_candidates else normalized,
    }
