"""Applied Labs CLI entrypoint."""

import asyncio
import json
import sys
from pathlib import Path

import httpx
import typer

from applied_cli import __version__, tools
from applied_cli.agent_scoped_flows import run_agent_scoped_flow_command
from applied_cli.client import AppliedClient
from applied_cli.credentials import (
    clear_credentials,
    load_credentials,
    save_credentials,
)

app = typer.Typer(
    name="applied",
    help="Applied Labs CLI - manage your AI agents and conversations.",
    no_args_is_help=True,
)

DEFAULT_BASE_URL = "https://api.appliedlabs.ai"
DEFAULT_CLIENT_URL = "https://appliedlabs.ai"


def _version_callback(value: bool) -> None:
    if not value:
        return
    typer.echo(f"applied {__version__}")
    raise typer.Exit()


@app.callback()
def app_callback(
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show the Applied CLI version and exit.",
    ),
) -> None:
    """Applied CLI root options."""


def get_client(shop_id: str | None = None) -> AppliedClient:
    """Get an authenticated client from stored credentials."""
    creds = load_credentials()
    if not creds or not creds.get("api_token"):
        typer.echo("Not logged in. Run 'applied login' first.", err=True)
        raise typer.Exit(1)

    return AppliedClient(
        token=creds["api_token"],
        shop_id=shop_id or creds.get("shop_id"),
        base_url=creds.get("base_url", DEFAULT_BASE_URL),
    )


def _parse_json_option(value: str | None, *, option_name: str) -> dict | None:
    if not value:
        return None

    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        typer.echo(
            f"Error: {option_name} must be valid JSON, got: {value}",
            err=True,
        )
        raise typer.Exit(1) from None

    if not isinstance(parsed, dict):
        typer.echo(f"Error: {option_name} must decode to a JSON object.", err=True)
        raise typer.Exit(1)

    return parsed


def _parse_json_array_option(value: str | None, *, option_name: str) -> list | None:
    if not value:
        return None

    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        typer.echo(
            f"Error: {option_name} must be valid JSON, got: {value}",
            err=True,
        )
        raise typer.Exit(1) from None

    if not isinstance(parsed, list):
        typer.echo(f"Error: {option_name} must decode to a JSON array.", err=True)
        raise typer.Exit(1)

    return parsed


def _parse_csv_option(value: str | None) -> list[str] | None:
    if not value:
        return None
    return [item.strip() for item in value.split(",") if item.strip()]


def _parse_jsonish_key_value_pairs(
    values: list[str] | None, *, option_name: str
) -> dict:
    result: dict[str, object] = {}
    for raw in values or []:
        if "=" not in raw:
            typer.echo(
                f"Error: {option_name} entries must look like key=value, got: {raw}",
                err=True,
            )
            raise typer.Exit(1)
        key, raw_value = raw.split("=", 1)
        key = key.strip()
        if not key:
            typer.echo(f"Error: {option_name} keys may not be empty.", err=True)
            raise typer.Exit(1)
        try:
            value = json.loads(raw_value)
        except json.JSONDecodeError:
            value = raw_value
        result[key] = value
    return result


def _build_conversation_filters(
    filter_value: str | None,
    resolution: str | None,
) -> dict | None:
    filters = _parse_json_option(filter_value, option_name="--filter") or {}
    if resolution:
        filters["resolution"] = resolution
    return filters or None


# -----------------------------------------------------------------------------
# Auth commands
# -----------------------------------------------------------------------------


@app.command()
def login(
    base_url: str = typer.Option(DEFAULT_BASE_URL, "--api", help="API base URL"),
    client_url: str = typer.Option(
        DEFAULT_CLIENT_URL, "--client", help="Client URL for auth page"
    ),
) -> None:
    """Login using device authorization flow."""

    async def do_login() -> None:
        # Start device flow
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(f"{base_url}/v1/cli/device/start/")
            resp.raise_for_status()
            data = resp.json()

        device_code = data["device_code"]
        user_code = data["user_code"]
        auth_url = f"{client_url}/cli/authorize?code={user_code}"

        typer.echo(f"\nOpen this URL to authenticate:\n\n  {auth_url}\n")
        typer.echo(f"Your code: {user_code}\n")
        typer.echo("Waiting for approval...", nl=False)

        # Poll for token
        max_attempts = 60
        interval = 2

        async with httpx.AsyncClient(timeout=30.0) as client:
            for _ in range(max_attempts):
                await asyncio.sleep(interval)
                typer.echo(".", nl=False)

                resp = await client.post(
                    f"{base_url}/v1/cli/device/token/",
                    json={"device_code": device_code},
                )

                if resp.status_code == 200:
                    token_data = resp.json()
                    api_token = token_data.get("access_token")
                    shop_id = token_data.get("shop_id")

                    if api_token:
                        save_credentials(
                            {
                                "api_token": api_token,
                                "shop_id": shop_id,
                                "base_url": base_url,
                            }
                        )
                        typer.echo("\n\nLogged in successfully!")
                        return

                elif resp.status_code == 400:
                    error = resp.json().get("error")
                    if error == "authorization_pending":
                        continue
                    elif error == "access_denied":
                        typer.echo("\n\nAuthorization denied.", err=True)
                        raise typer.Exit(1)
                    elif error == "expired_token":
                        typer.echo(
                            "\n\nDevice code expired. Please try again.", err=True
                        )
                        raise typer.Exit(1)

        typer.echo("\n\nTimeout waiting for authorization.", err=True)
        raise typer.Exit(1)

    asyncio.run(do_login())


@app.command()
def logout() -> None:
    """Clear stored credentials."""
    clear_credentials()
    typer.echo("Logged out.")


@app.command()
def whoami() -> None:
    """Show current authentication status."""
    creds = load_credentials()
    if not creds or not creds.get("api_token"):
        typer.echo("Not logged in.")
        raise typer.Exit(1)

    token = creds["api_token"]
    masked = f"{token[:8]}...{token[-4:]}" if len(token) > 12 else "***"
    typer.echo(f"API Token: {masked}")
    typer.echo(f"Base URL: {creds.get('base_url', DEFAULT_BASE_URL)}")
    if creds.get("shop_id"):
        typer.echo(f"Shop ID: {creds['shop_id']}")


# -----------------------------------------------------------------------------
# Agent commands
# -----------------------------------------------------------------------------


@app.command()
def agents(
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List all AI agents."""
    client = get_client()
    result = asyncio.run(tools.agent_list(client, output_format=format))
    typer.echo(result)


# -----------------------------------------------------------------------------
# Taxonomy commands
# -----------------------------------------------------------------------------


@app.command()
def taxonomy(
    type: str = typer.Option(
        "all", "--type", "-t", help="Type: all, topics, intents, flags"
    ),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List conversation taxonomy (topics, intents, flags)."""
    client = get_client()
    result = asyncio.run(
        tools.taxonomy_list(client, taxonomy_type=type, output_format=format)
    )
    typer.echo(result)


@app.command()
def analytics(
    group_by: str = typer.Option(
        ...,
        "--group-by",
        "-g",
        help=(
            "Comma-separated dimensions: label_name, sublabel_name, agent_name, "
            "resolution, sentiment, type, user_id, label_id, sublabel_id, agent_id"
        ),
    ),
    metrics: str = typer.Option(
        "count",
        "--metrics",
        "-m",
        help="Comma-separated metrics: count, avg_score, avg_ttr, resolution_rate",
    ),
    filter: list[str] | None = typer.Option(  # noqa: B008
        None,
        "--filter",
        help='Filter as "field=value". Repeatable.',
    ),
    start: str = typer.Option(None, "--start", help="Start date, e.g. 2025-01-01"),
    end: str = typer.Option(None, "--end", help="End date, e.g. 2025-01-31"),
    limit: int = typer.Option(1000, "--limit", "-l", help="Max rows to return"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Run a server-side analytics query grouped by dimensions."""
    client = get_client()
    result = asyncio.run(
        tools.analytics_query(
            client,
            group_by=[g.strip() for g in group_by.split(",") if g.strip()],
            metrics=[m.strip() for m in metrics.split(",") if m.strip()],
            filters=list(filter) if filter else None,
            start=start,
            end=end,
            limit=limit if limit != 1000 else None,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("analytics-sql")
def analytics_sql(
    sql: str | None = typer.Option(
        None,
        "--sql",
        help="Inline SQL query to execute against the scoped analytics surface.",
    ),
    file: str | None = typer.Option(
        None,
        "--file",
        help="Path to a .sql file to execute.",
    ),
    param: list[str] | None = typer.Option(  # noqa: B008
        None,
        "--param",
        help="Named SQL parameter as key=value. Values are JSON-decoded when possible.",
    ),
    limit: int = typer.Option(500, "--limit", "-l", help="Max rows to return"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Run a raw scoped ClickHouse analytics query."""
    if bool(sql) == bool(file):
        typer.echo("Error: pass exactly one of --sql or --file.", err=True)
        raise typer.Exit(1)

    query_text = sql or Path(file).read_text(encoding="utf-8")
    parameters = _parse_jsonish_key_value_pairs(param, option_name="--param") or None

    client = get_client()
    result = asyncio.run(
        tools.analytics_sql(
            client,
            sql=query_text,
            parameters=parameters,
            limit=limit if limit != 500 else None,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command()
def metrics(
    metric_name: str = typer.Option(
        ...,
        "--metric-name",
        "-n",
        help="Metric name, e.g. customer.cancel, customer.save",
    ),
    group_by: str = typer.Option(
        "",
        "--group-by",
        "-g",
        help="Property key to group by, e.g. reason",
    ),
    period: str = typer.Option(
        "",
        "--period",
        "-p",
        help="Trending period: day, week, month",
    ),
    filter: list[str] | None = typer.Option(  # noqa: B008
        None,
        "--filter",
        help='Property filter as "key=value". Repeatable.',
    ),
    start: str = typer.Option(None, "--start", help="Start date, e.g. 2025-01-01"),
    end: str = typer.Option(None, "--end", help="End date, e.g. 2025-01-31"),
    object_type: str = typer.Option(
        "conversation", "--object-type", help="Object type"
    ),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Query metric events with property grouping and trending."""
    client = get_client()
    result = asyncio.run(
        tools.analytics_metrics(
            client,
            metric_name=metric_name,
            group_by=group_by or None,
            period=period or None,
            filters=list(filter) if filter else None,
            start=start,
            end=end,
            object_type=object_type,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("analytics-report")
def analytics_report(
    view: str = typer.Option(
        ...,
        "--view",
        help=(
            "Analytics view, e.g. dashboard_rate_metrics, custom_rate_metrics, "
            "overview_aggregate_metrics, overview_aggregates"
        ),
    ),
    model: str = typer.Option(
        "conversation", "--model", help="Analytics model: conversation or ticket"
    ),
    group_by: str = typer.Option(
        None, "--group-by", "-g", help="Comma-separated grouping dimensions"
    ),
    period: str = typer.Option(
        None, "--period", "-p", help="Trend period: hour, day, week, month"
    ),
    start: str = typer.Option(None, "--start", help="Start date/datetime"),
    end: str = typer.Option(None, "--end", help="End date/datetime"),
    tz: str = typer.Option(
        None,
        "--tz",
        help="Timezone for analytics date bucketing, e.g. America/Los_Angeles",
    ),
    date_column: str = typer.Option(
        None,
        "--date-column",
        help="Date axis, e.g. created_at, resolved_at, first_human_response_at",
    ),
    conversation_filter: str = typer.Option(
        None,
        "--conversation-filter",
        help='JSON conversation filters for analytics, e.g. \'{"agent_revision_version":"448"}\'',
    ),
    requests: str = typer.Option(
        None,
        "--requests",
        help=(
            "JSON array for custom_rate_metrics_requests, e.g. "
            '\'[{"rate":"escalation_rate","numerator":"escalated_total_cnt","denominator":"total"}]\''
        ),
    ),
    sample_object_ids: int = typer.Option(
        None, "--sample-object-ids", help="Optional sample object id count"
    ),
    format: str = typer.Option(
        "json", "--format", "-f", help="Output format: json or text"
    ),
) -> None:
    """Run a dashboard-style analytics report."""
    client = get_client()
    conversation_filters = _parse_json_option(
        conversation_filter, option_name="--conversation-filter"
    )
    custom_rate_metrics_requests = _parse_json_array_option(
        requests, option_name="--requests"
    )
    result = asyncio.run(
        tools.analytics_report(
            client,
            view=view,
            model=model,
            group_by=group_by,
            period=period,
            start=start,
            end=end,
            timezone=tz,
            date_column=date_column,
            conversation_filters=conversation_filters,
            custom_rate_metrics_requests=custom_rate_metrics_requests,
            sample_object_ids=sample_object_ids,
            output_format=format,
        )
    )
    typer.echo(result)


# -----------------------------------------------------------------------------
# Conversation commands
# -----------------------------------------------------------------------------


@app.command()
def conversations(
    filter: str = typer.Option(
        None,
        "--filter",
        help='JSON filter, e.g. \'{"score": {"gte": 4}}\' or \'{"resolution": ["escalated", "human"]}\'',
    ),
    search: str = typer.Option(None, "--search", "-s", help="Full-text search"),
    fields: str = typer.Option(
        None,
        "--fields",
        help="Comma-separated fields: id,title,score,comment,summary,sublabel.name,flags",
    ),
    distinct_by: str = typer.Option(
        None,
        "--distinct-by",
        help="Comma-separated fields to dedupe by after projection, e.g. contact.email",
    ),
    view: str = typer.Option(
        "search",
        "--view",
        help="Result view: ids, search, detail, full. Ignored when --fields is set.",
    ),
    resolution: str = typer.Option(
        None, "--resolution", "-r", help="Filter by resolution (shorthand)"
    ),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    fetch_all: bool = typer.Option(
        False, "--fetch-all", help="Fetch all pages (use carefully)"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Query conversations with filters and field selection."""
    client = get_client(shop_id=shop_id)
    filters_dict = _build_conversation_filters(filter, resolution)
    field_list = _parse_csv_option(fields)
    distinct_fields = _parse_csv_option(distinct_by)

    result = asyncio.run(
        tools.conversation_query(
            client,
            filters=filters_dict,
            search=search,
            fields=field_list,
            distinct_by=distinct_fields,
            view=view,
            limit=limit,
            fetch_all=fetch_all,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command()
def conversation_find(
    query: str = typer.Option(
        None,
        "--query",
        "--search",
        "-q",
        help="Full-text search across conversation content",
    ),
    filter: str = typer.Option(
        None,
        "--filter",
        help='JSON filter, e.g. \'{"resolution": "escalated"}\'',
    ),
    distinct_by: str = typer.Option(
        None,
        "--distinct-by",
        help="Comma-separated fields to dedupe by after projection, e.g. contact.email",
    ),
    view: str = typer.Option(
        "search",
        "--view",
        help="Result view: ids, search, detail, full",
    ),
    resolution: str = typer.Option(
        None, "--resolution", "-r", help="Filter by resolution (shorthand)"
    ),
    limit: int = typer.Option(10, "--limit", "-l", help="Max results"),
    fetch_all: bool = typer.Option(
        False, "--fetch-all", help="Fetch all pages (use carefully)"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Find conversations using a compact agent-friendly view."""
    client = get_client(shop_id=shop_id)
    filters_dict = _build_conversation_filters(filter, resolution)
    distinct_fields = _parse_csv_option(distinct_by)
    result = asyncio.run(
        tools.conversation_find(
            client,
            query=query,
            filters=filters_dict,
            distinct_by=distinct_fields,
            view=view,
            limit=limit,
            fetch_all=fetch_all,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("conversation-lookup")
def conversation_lookup(
    identifier: str = typer.Argument(
        ..., help="Applied conversation URL/ID, remote ticket URL, or remote id"
    ),
    platform: str = typer.Option(
        None, "--platform", help="Optional platform hint: gorgias, zendesk, dixa"
    ),
    view: str = typer.Option(
        "detail",
        "--view",
        help="Result view: ids, search, detail, full",
    ),
    limit: int = typer.Option(10, "--limit", "-l", help="Max matches"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "json", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Resolve a conversation from an Applied or remote platform identifier."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.conversation_lookup(
            client,
            identifier=identifier,
            platform=platform,
            view=view,
            limit=limit,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command()
def conversation(
    id: str = typer.Argument(..., help="Conversation ID"),
    messages: bool = typer.Option(False, "--messages", "-m", help="Include messages"),
    message_limit: int = typer.Option(50, "--message-limit", help="Max messages"),
    view: str = typer.Option(
        "detail", "--view", help="Conversation view: detail or full"
    ),
    message_view: str = typer.Option(
        "compact", "--message-view", help="Message view: compact or full"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Get a single conversation by ID."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.conversation_get(
            client,
            id,
            include_messages=messages,
            message_limit=message_limit,
            view=view,
            message_view=message_view,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("conversation-debug")
def conversation_debug(
    identifier: str = typer.Argument(
        ..., help="Applied conversation URL/ID, remote ticket URL, or remote id"
    ),
    platform: str = typer.Option(
        None, "--platform", help="Optional platform hint: gorgias, zendesk, dixa"
    ),
    message_limit: int = typer.Option(100, "--message-limit", help="Max messages"),
    flow_run_limit: int = typer.Option(
        10, "--flow-run-limit", help="Max recent flow runs"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "json", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Resolve a conversation identifier and return the main debug bundle."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.conversation_debug(
            client,
            identifier=identifier,
            platform=platform,
            message_limit=message_limit,
            flow_run_limit=flow_run_limit,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("conversation-repro")
def conversation_repro(
    identifier: str = typer.Argument(
        ..., help="Applied conversation URL/ID, remote ticket URL, or remote id"
    ),
    platform: str = typer.Option(
        None, "--platform", help="Optional platform hint: gorgias, zendesk, dixa"
    ),
    scenario_name: str = typer.Option(
        None, "--scenario-name", help="Optional scenario name"
    ),
    benchmark_id: str = typer.Option(
        None, "--benchmark-id", help="Attach the scenario to an existing benchmark"
    ),
    benchmark_name: str = typer.Option(
        None, "--benchmark-name", help="Create or reuse a benchmark by name"
    ),
    agent_id: str = typer.Option(
        None, "--agent-id", help="Agent ID for benchmark creation when needed"
    ),
    run_now: bool = typer.Option(
        True, "--run-now/--no-run-now", help="Queue a rerun immediately"
    ),
    target_agent_id: str = typer.Option(
        None, "--target-agent-id", help="Optional target agent for reruns"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "json", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Resolve a conversation identifier and save it as a reproducible scenario."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.conversation_repro(
            client,
            identifier=identifier,
            platform=platform,
            scenario_name=scenario_name,
            benchmark_id=benchmark_id,
            benchmark_name=benchmark_name,
            agent_id=agent_id,
            run_now=run_now,
            target_agent_id=target_agent_id,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("conversation-reply")
def conversation_reply(
    id: str = typer.Argument(..., help="Conversation ID"),
    content: str = typer.Argument(..., help="Reply content"),
    agent_id: str = typer.Option(..., "--agent-id", help="Agent ID to author reply"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Send a reply on a conversation."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.conversation_reply(
            client,
            id,
            agent_id=agent_id,
            content=content,
            shop_id=shop_id,
        )
    )
    typer.echo(result)


@app.command("conversation-update")
def conversation_update(
    id: str = typer.Argument(..., help="Conversation ID"),
    resolution: str = typer.Option(
        None, "--resolution", help="Conversation resolution"
    ),
    user_id: str = typer.Option(None, "--user-id", help="Owner user ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Update a conversation."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.conversation_update(
            client,
            id,
            resolution=resolution,
            user_id=user_id,
            shop_id=shop_id,
        )
    )
    typer.echo(result)


# -----------------------------------------------------------------------------
# Ticket commands
# -----------------------------------------------------------------------------


@app.command()
def tickets(
    status: str = typer.Option(None, "--status", "-s", help="Filter by status"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Query tickets."""
    client = get_client(shop_id=shop_id)
    filters = {}
    if status:
        filters["status"] = status

    result = asyncio.run(
        tools.ticket_query(
            client,
            filters=filters,
            limit=limit,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command()
def ticket(
    id: str = typer.Argument(..., help="Ticket ID"),
    messages: bool = typer.Option(False, "--messages", "-m", help="Include messages"),
    message_limit: int = typer.Option(50, "--message-limit", help="Max messages"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Get a single ticket by ID."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.ticket_get(
            client,
            id,
            include_messages=messages,
            message_limit=message_limit,
            shop_id=shop_id,
        )
    )
    typer.echo(result)


@app.command("ticket-note")
def ticket_note(
    id: str = typer.Argument(..., help="Ticket ID"),
    content: str = typer.Argument(..., help="Note content"),
    agent_id: str = typer.Option(..., "--agent-id", help="Agent ID to author note"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Add an assistant-authored note to a ticket."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.ticket_note(
            client,
            id,
            agent_id=agent_id,
            content=content,
            shop_id=shop_id,
        )
    )
    typer.echo(result)


@app.command("ticket-update")
def ticket_update(
    id: str = typer.Argument(..., help="Ticket ID"),
    status: str = typer.Option(None, "--status", help="Ticket status"),
    content: str = typer.Option(None, "--content", help="Ticket content/brief"),
    metadata: str = typer.Option(
        None, "--metadata", help="JSON metadata patch to set on the ticket"
    ),
    assignee_id: str = typer.Option(None, "--assignee-id", help="Assignee user ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Update a ticket."""
    import json as json_mod

    metadata_dict = None
    if metadata:
        try:
            metadata_dict = json_mod.loads(metadata)
        except json_mod.JSONDecodeError:
            typer.echo(
                f"Error: --metadata must be valid JSON, got: {metadata}",
                err=True,
            )
            raise typer.Exit(1) from None

    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.ticket_update(
            client,
            id,
            status=status,
            content=content,
            metadata=metadata_dict,
            assignee_id=assignee_id,
            shop_id=shop_id,
        )
    )
    typer.echo(result)


# -----------------------------------------------------------------------------
# Knowledge commands
# -----------------------------------------------------------------------------


@app.command()
def knowledge(
    type: str = typer.Option(
        None, "--type", "-t", help="Filter by type: qa, context, escalate, exact"
    ),
    search: str = typer.Option(None, "--search", "-s", help="Search query"),
    limit: int = typer.Option(100, "--limit", "-l", help="Results per page"),
    all_pages: bool = typer.Option(
        True, "--all/--no-all", help="Fetch all pages (default: True)"
    ),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List knowledge base items."""
    client = get_client()
    result = asyncio.run(
        tools.knowledge_list(
            client,
            kb_type=type,
            search=search,
            limit=limit,
            fetch_all=all_pages,
            output_format=format,
        )
    )
    typer.echo(result)


# -----------------------------------------------------------------------------
# Flow commands
# -----------------------------------------------------------------------------


@app.command()
def flows(
    agent_id: str = typer.Option(None, "--agent", "-a", help="Filter by agent ID"),
    status: str = typer.Option(
        None, "--status", "-s", help="Filter by status: Active, Draft, Archived"
    ),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List flows."""
    client = get_client()
    result = asyncio.run(
        tools.flow_list(client, agent_id=agent_id, status=status, output_format=format)
    )
    typer.echo(result)


@app.command()
def flow(
    id: str = typer.Argument(..., help="Flow ID"),
    format: str = typer.Option(
        "summary", "--format", "-f", help="Output format: summary, full, or json"
    ),
) -> None:
    """Get a single flow with its graph (nodes and edges)."""
    client = get_client()
    result = asyncio.run(tools.flow_get(client, id, output_format=format))
    typer.echo(result)


@app.command("flow-runs")
def flow_runs(
    flow_id: str = typer.Option(None, "--flow-id", help="Filter by flow ID"),
    conversation_id: str = typer.Option(
        None, "--conversation-id", help="Filter by conversation ID"
    ),
    status: str = typer.Option(None, "--status", help="Filter by run status"),
    limit: int = typer.Option(20, "--limit", "-l", help="Max results"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List recent flow runs."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.flow_run_list(
            client,
            flow_id=flow_id,
            conversation_id=conversation_id,
            status=status,
            limit=limit,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("flow-run")
def flow_run(
    id: str = typer.Argument(..., help="Flow run ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Get a single flow run with trace details."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(tools.flow_run_get(client, id, output_format=format))
    typer.echo(result)


@app.command("conversation-spans")
def conversation_spans(
    id: str = typer.Argument(..., help="Conversation ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Get execution spans for a conversation."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.conversation_spans(client, conversation_id=id, output_format=format)
    )
    typer.echo(result)


@app.command("conversation-references")
def conversation_references(
    id: str = typer.Argument(..., help="Conversation ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """Get message references for a conversation."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.conversation_references(
            client,
            conversation_id=id,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("send-message")
def send_message_cmd(
    agent_id: str = typer.Option(..., "--agent-id", help="Agent ID"),
    message: str = typer.Argument(..., help="User message to send"),
    conversation_id: str = typer.Option(
        None, "--conversation-id", help="Continue an existing test conversation"
    ),
    contact_email: str = typer.Option(
        None, "--contact-email", help="Email for a new test contact"
    ),
    contact_name: str = typer.Option(
        None, "--contact-name", help="Name for a new test contact"
    ),
    contact_phone: str = typer.Option(
        None, "--contact-phone", help="Phone for a new test contact"
    ),
    flow_id: str = typer.Option(None, "--flow-id", help="Force a specific flow to run"),
    metadata: str = typer.Option(
        None, "--metadata", help="JSON metadata for trigger.metadata"
    ),
    conversation_type: str = typer.Option(
        None, "--conversation-type", help="Conversation type: email, web_chat, sms"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Send a test message to an agent."""
    metadata_dict = _parse_json_option(metadata, option_name="--metadata")
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.send_message(
            client,
            agent_id=agent_id,
            message=message,
            conversation_id=conversation_id,
            contact_email=contact_email,
            contact_name=contact_name,
            contact_phone=contact_phone,
            flow_id=flow_id,
            metadata=metadata_dict,
            conversation_type=conversation_type,
            output_format=format,
        )
    )
    typer.echo(result)


# -----------------------------------------------------------------------------
# Benchmark and Scenario commands
# -----------------------------------------------------------------------------


@app.command()
def benchmarks(
    agent_id: str = typer.Option(None, "--agent-id", help="Filter by agent ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List benchmarks."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.benchmark_list(client, agent_id=agent_id, output_format=format)
    )
    typer.echo(result)


@app.command()
def benchmark(
    id: str = typer.Argument(..., help="Benchmark ID"),
    include_scenarios: bool = typer.Option(
        True, "--include-scenarios/--no-include-scenarios", help="Include scenarios"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Get a single benchmark with scenarios."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.benchmark_get(
            client,
            benchmark_id=id,
            include_scenarios=include_scenarios,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("benchmark-create")
def benchmark_create(
    agent_id: str = typer.Option(..., "--agent-id", help="Agent ID"),
    name: str = typer.Option(..., "--name", help="Benchmark name"),
    description: str = typer.Option("", "--description", help="Benchmark description"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Create a benchmark."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.benchmark_create(
            client,
            agent_id=agent_id,
            name=name,
            description=description,
        )
    )
    typer.echo(result)


@app.command()
def scenarios(
    benchmark_id: str = typer.Option(
        None, "--benchmark-id", help="Filter by benchmark ID"
    ),
    agent_id: str = typer.Option(None, "--agent-id", help="Filter by agent ID"),
    pass_status: str = typer.Option(
        None, "--pass-status", help="Filter by pass/fail/unrated"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List test scenarios."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.scenario_list(
            client,
            benchmark_id=benchmark_id,
            agent_id=agent_id,
            pass_status=pass_status,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command()
def scenario(
    id: str = typer.Argument(..., help="Scenario ID"),
    include_runs: bool = typer.Option(
        True, "--include-runs/--no-include-runs", help="Include recent runs"
    ),
    run_limit: int = typer.Option(5, "--run-limit", help="Number of recent runs"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Get a single scenario with conversation and run details."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.scenario_get(
            client,
            scenario_id=id,
            include_runs=include_runs,
            run_limit=run_limit,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("scenario-create")
def scenario_create(
    input_conversation_id: str = typer.Option(
        ..., "--input-conversation-id", help="Source conversation ID"
    ),
    name: str = typer.Option(..., "--name", help="Scenario name"),
    benchmark_id: str = typer.Option(
        None, "--benchmark-id", help="Attach to an existing benchmark"
    ),
    benchmark_name: str = typer.Option(
        None, "--benchmark-name", help="Create or reuse a benchmark by name"
    ),
    agent_id: str = typer.Option(
        None, "--agent-id", help="Required when --benchmark-name is used"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Create a scenario from a conversation."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.scenario_create(
            client,
            input_conversation_id=input_conversation_id,
            name=name,
            benchmark_id=benchmark_id,
            benchmark_name=benchmark_name,
            agent_id=agent_id,
        )
    )
    typer.echo(result)


@app.command("scenario-update")
def scenario_update_cmd(
    id: str = typer.Argument(..., help="Scenario ID"),
    pass_status: str = typer.Option(None, "--pass-status", help="pass/fail/unrated"),
    csat_score: float = typer.Option(None, "--csat-score", help="CSAT score"),
    feedback: str = typer.Option(None, "--feedback", help="Scenario feedback"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Update scenario evaluation fields."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.scenario_update(
            client,
            scenario_id=id,
            pass_status=pass_status,
            csat_score=csat_score,
            feedback=feedback,
        )
    )
    typer.echo(result)


@app.command("scenario-runs")
def scenario_runs(
    scenario_id: str = typer.Option(
        None, "--scenario-id", help="Filter by scenario ID"
    ),
    benchmark_id: str = typer.Option(
        None, "--benchmark-id", help="Filter by benchmark ID"
    ),
    latest: bool = typer.Option(
        True, "--latest/--all", help="Only show the latest run per scenario"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List scenario runs."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.scenario_run_list(
            client,
            scenario_id=scenario_id,
            benchmark_id=benchmark_id,
            latest=latest,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("scenario-run")
def scenario_run(
    id: str = typer.Argument(..., help="Scenario run ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Get a scenario run with output conversation details."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.scenario_run_get(client, run_id=id, output_format=format)
    )
    typer.echo(result)


@app.command("scenario-run-update")
def scenario_run_update_cmd(
    id: str = typer.Argument(..., help="Scenario run ID"),
    pass_status: str = typer.Option(None, "--pass-status", help="pass/fail/unrated"),
    csat_score: float = typer.Option(None, "--csat-score", help="CSAT score"),
    feedback: str = typer.Option(None, "--feedback", help="Run feedback"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Update scenario run evaluation fields."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.scenario_run_update(
            client,
            run_id=id,
            pass_status=pass_status,
            csat_score=csat_score,
            feedback=feedback,
        )
    )
    typer.echo(result)


@app.command("scenario-bulk-run")
def scenario_bulk_run(
    scenario_ids: str = typer.Option(
        None, "--scenario-ids", help="Comma-separated scenario IDs"
    ),
    benchmark_id: str = typer.Option(
        None, "--benchmark-id", help="Run every scenario in a benchmark"
    ),
    target_agent_id: str = typer.Option(
        None, "--target-agent-id", help="Optional target agent for reruns"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Queue scenario reruns for a benchmark or explicit scenario list."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.scenario_bulk_run(
            client,
            scenario_ids=_parse_csv_option(scenario_ids),
            benchmark_id=benchmark_id,
            target_agent_id=target_agent_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("scenario-bulk-status")
def scenario_bulk_status(
    job_id: str = typer.Argument(..., help="Bulk run job ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Get status for a bulk scenario rerun job."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.scenario_bulk_status(client, job_id=job_id, output_format=format)
    )
    typer.echo(result)


@app.command("audit-metric-fields")
def audit_metric_fields(
    is_active: bool = typer.Option(
        True, "--is-active/--all", help="Show only active fields by default"
    ),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List audit metric fields."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_metric_field_list(
            client,
            is_active=is_active if is_active else None,
            limit=limit,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-rubrics")
def audit_rubrics(
    applies_to: str = typer.Option(
        None, "--applies-to", help="Filter by target type: conversation or ticket"
    ),
    is_active: bool = typer.Option(
        True, "--is-active/--all", help="Show only active rubrics by default"
    ),
    name: str = typer.Option(None, "--name", help="Filter by rubric name"),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List audit rubrics."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_rubric_list(
            client,
            applies_to=applies_to,
            is_active=is_active if is_active else None,
            name=name,
            limit=limit,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audits")
def audits(
    target_type: str = typer.Option(
        "conversation", "--target-type", help="Filter by target type"
    ),
    status: str = typer.Option(None, "--status", help="Filter by audit status"),
    rubric_id: str = typer.Option(None, "--rubric-id", help="Filter by rubric ID"),
    start: str = typer.Option(
        None, "--start", help="Window start; matches overlapping audits"
    ),
    end: str = typer.Option(
        None, "--end", help="Window end; matches overlapping audits"
    ),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List audit batches."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_list(
            client,
            target_type=target_type,
            status=status,
            rubric_id=rubric_id,
            start=start,
            end=end,
            limit=limit,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit")
def audit(
    id: str = typer.Argument(..., help="Audit batch ID"),
    include_ratings: bool = typer.Option(
        True, "--ratings/--no-ratings", help="Include rating summaries"
    ),
    ratings_view: str = typer.Option(
        "notes",
        "--ratings-view",
        help="summary, notes, detail, or full",
    ),
    rating_limit: int = typer.Option(
        200, "--rating-limit", help="Max ratings to include"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Get an audit batch with optional rating summaries."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_get(
            client,
            batch_id=id,
            include_ratings=include_ratings,
            ratings_view=ratings_view,
            rating_limit=rating_limit,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-create")
def audit_create(
    target_type: str = typer.Option(
        ..., "--target-type", help="conversation or ticket"
    ),
    period_start: str = typer.Option(..., "--period-start", help="YYYY-MM-DD"),
    period_end: str = typer.Option(..., "--period-end", help="YYYY-MM-DD"),
    rubric_id: str = typer.Option(None, "--rubric-id", help="Optional rubric ID"),
    desired_sample_size: int = typer.Option(
        None, "--desired-sample-size", help="Requested sample size"
    ),
    filters: str = typer.Option(
        None, "--filters", help="JSON filter object for the audit batch"
    ),
    populate: bool = typer.Option(
        False, "--populate/--no-populate", help="Populate sampled ratings immediately"
    ),
    populate_limit: int = typer.Option(
        None, "--populate-limit", help="Override rating population count"
    ),
    only_unaudited: bool = typer.Option(
        True, "--only-unaudited/--include-audited", help="Populate only new targets"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Create a new audit batch."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_create(
            client,
            target_type=target_type,
            period_start=period_start,
            period_end=period_end,
            rubric_id=rubric_id,
            desired_sample_size=desired_sample_size,
            filters=_parse_json_option(filters, option_name="--filters"),
            populate=populate,
            populate_limit=populate_limit,
            only_unaudited=only_unaudited,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-size")
def audit_size(
    target_type: str = typer.Option(
        ..., "--target-type", help="conversation or ticket"
    ),
    period_start: str = typer.Option(..., "--period-start", help="YYYY-MM-DD"),
    period_end: str = typer.Option(..., "--period-end", help="YYYY-MM-DD"),
    rubric_id: str = typer.Option(None, "--rubric-id", help="Optional rubric ID"),
    filters: str = typer.Option(
        None, "--filters", help="JSON filter object for the audit batch"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Calculate audit candidate size without creating a batch."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_calculate_size(
            client,
            target_type=target_type,
            period_start=period_start,
            period_end=period_end,
            rubric_id=rubric_id,
            filters=_parse_json_option(filters, option_name="--filters"),
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-populate")
def audit_populate(
    id: str = typer.Argument(..., help="Audit batch ID"),
    limit: int = typer.Option(None, "--limit", help="Populate up to this many ratings"),
    only_unaudited: bool = typer.Option(
        True, "--only-unaudited/--include-audited", help="Populate only new targets"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Populate an audit batch with sampled ratings."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_populate(
            client,
            batch_id=id,
            limit=limit,
            only_unaudited=only_unaudited,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-submit")
def audit_submit(
    id: str = typer.Argument(..., help="Audit batch ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Submit and lock an audit batch."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_submit(
            client,
            batch_id=id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-recalculate")
def audit_recalculate(
    id: str = typer.Argument(..., help="Audit batch ID"),
    dimension_filters: str = typer.Option(
        None, "--dimension-filters", help="Optional JSON dimension filter object"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Recalculate audit aggregates."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_recalculate(
            client,
            batch_id=id,
            dimension_filters=_parse_json_option(
                dimension_filters, option_name="--dimension-filters"
            ),
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-ratings")
def audit_ratings(
    batch_id: str = typer.Option(None, "--batch-id", help="Filter by audit batch ID"),
    target_type: str = typer.Option(
        None, "--target-type", help="Filter by target type"
    ),
    audited_by_id: str = typer.Option(
        None, "--audited-by-id", help="Filter by auditor user ID"
    ),
    unassigned_only: bool = typer.Option(
        False, "--unassigned-only", help="Only show unrated ownership rows"
    ),
    completed_only: bool = typer.Option(
        False, "--completed-only", help="Only show completed ratings"
    ),
    notes_only: bool = typer.Option(
        False, "--notes-only", help="Only show ratings with notes"
    ),
    view: str = typer.Option("notes", "--view", help="summary, notes, detail, or full"),
    limit: int = typer.Option(100, "--limit", "-l", help="Max results"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv or json"
    ),
) -> None:
    """List audit ratings."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_rating_list(
            client,
            batch_id=batch_id,
            target_type=target_type,
            audited_by_id=audited_by_id,
            unassigned_only=unassigned_only,
            completed_only=completed_only,
            notes_only=notes_only,
            view=view,
            limit=limit,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-rating")
def audit_rating(
    id: str = typer.Argument(..., help="Audit rating ID"),
    include_target: bool = typer.Option(
        True, "--target/--no-target", help="Include the audited target object"
    ),
    target_debug: bool = typer.Option(
        False,
        "--target-debug",
        help="For conversation targets, include transcript, references, spans, and flow runs",
    ),
    message_limit: int = typer.Option(
        100, "--message-limit", help="Max target messages when --target-debug is used"
    ),
    flow_run_limit: int = typer.Option(
        10, "--flow-run-limit", help="Max flow runs when --target-debug is used"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Get a single audit rating."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_rating_get(
            client,
            rating_id=id,
            include_target=include_target,
            target_debug=target_debug,
            message_limit=message_limit,
            flow_run_limit=flow_run_limit,
            shop_id=shop_id,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-rating-update")
def audit_rating_update(
    id: str = typer.Argument(..., help="Audit rating ID"),
    notes: str = typer.Option(None, "--notes", help="Reviewer notes"),
    quality_score: float = typer.Option(
        None, "--quality-score", help="Optional overall quality score"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Update audit rating notes or quality score."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_rating_update(
            client,
            rating_id=id,
            notes=notes,
            quality_score=quality_score,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("audit-rating-set-value")
def audit_rating_set_value(
    id: str = typer.Argument(..., help="Audit rating ID"),
    metric_field_id: str = typer.Option(
        ..., "--metric-field-id", help="Metric field ID"
    ),
    value: str = typer.Option(
        ..., "--value", help="JSON-encoded value for the metric field"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text or json"
    ),
) -> None:
    """Set a typed metric value on an audit rating."""
    try:
        parsed_value = json.loads(value)
    except json.JSONDecodeError:
        parsed_value = value

    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.audit_rating_set_value(
            client,
            rating_id=id,
            metric_field_id=metric_field_id,
            value=parsed_value,
            output_format=format,
        )
    )
    typer.echo(result)


@app.command("connector-types")
def connector_types(
    type: str = typer.Option(
        None, "--type", "-t", help="Filter to specific connector (e.g. shopify, zendesk)"
    ),
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text, csv, or json"
    ),
) -> None:
    """List available connector types and their supported actions."""
    client = get_client()
    result = asyncio.run(
        tools.connector_types(client, connector_type=type, output_format=format)
    )
    typer.echo(result)


@app.command("agent-update")
def agent_update(
    id: str = typer.Argument(..., help="Agent ID"),
    name: str = typer.Option(None, "--name", help="Agent name"),
    prompt: str = typer.Option(None, "--prompt", help="Guidance/guardrails text"),
    model: str = typer.Option(None, "--model", help="Model name"),
    modality: str = typer.Option(
        None, "--modality", help="Modality: Chat, Email, Call, SMS, All"
    ),
    agent_type: str = typer.Option(
        None, "--type", help="Type: Customer Support, Generic, etc."
    ),
    escalation_mode: str = typer.Option(
        None,
        "--escalation-mode",
        help="Escalation mode: default, email, sms, email_non_opening_hours, ticketing_integration",
    ),
    auto_reply: bool = typer.Option(None, "--auto-reply", help="Enable auto-reply"),
    metadata: str = typer.Option(
        None, "--metadata", help="JSON metadata to set on the agent"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Update an agent."""
    metadata_dict = _parse_json_option(metadata, option_name="--metadata")
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.agent_update(
            client,
            id,
            name=name,
            prompt=prompt,
            model=model,
            modality=modality,
            agent_type=agent_type,
            escalation_mode=escalation_mode,
            auto_reply=auto_reply,
            metadata=metadata_dict,
        )
    )
    typer.echo(result)


@app.command("knowledge-create")
def knowledge_create(
    kb_type: str = typer.Option(
        ..., "--type", "-t", help="Type: qa, exact, escalate, context, greeting, signature"
    ),
    question: str = typer.Option(..., "--question", "-q", help="Trigger text / question"),
    answer: str = typer.Option(..., "--answer", "-a", help="Response text / answer"),
    guardrail: str = typer.Option("", "--guardrail", help="Guardrail instructions"),
    active: bool = typer.Option(True, "--active/--inactive", help="Whether the item is active"),
    agent_ids: str = typer.Option(
        None, "--agent-ids", help="Comma-separated agent UUIDs (empty = shop-wide)"
    ),
    label_id: str = typer.Option(None, "--label-id", help="Topic label UUID"),
    flow_id: str = typer.Option(None, "--flow-id", help="Flow UUID to associate with"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Create a knowledge base item."""
    parsed_agent_ids = _parse_csv_option(agent_ids)
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.knowledge_create(
            client,
            kb_type=kb_type,
            question=question,
            answer=answer,
            guardrail=guardrail,
            active=active,
            agent_ids=parsed_agent_ids,
            label_id=label_id,
            flow_id=flow_id,
        )
    )
    typer.echo(result)


@app.command("knowledge-update")
def knowledge_update(
    id: str = typer.Argument(..., help="Knowledge item ID"),
    question: str = typer.Option(None, "--question", "-q", help="Trigger text / question"),
    answer: str = typer.Option(None, "--answer", "-a", help="Response text / answer"),
    guardrail: str = typer.Option(None, "--guardrail", help="Guardrail instructions"),
    active: bool = typer.Option(None, "--active/--inactive", help="Whether the item is active"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Update a knowledge base item."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.knowledge_update(
            client,
            id,
            question=question,
            answer=answer,
            guardrail=guardrail,
            active=active,
        )
    )
    typer.echo(result)


@app.command("product-create")
def product_create(
    title: str = typer.Option(..., "--title", help="Product title"),
    description: str = typer.Option("", "--description", help="Product description"),
    url: str = typer.Option("", "--url", help="Product page URL"),
    images: str = typer.Option(None, "--images", help="Comma-separated image URLs"),
    price: str = typer.Option(None, "--price", help="Price (e.g. '29.99')"),
    compare_at_price: str = typer.Option(None, "--compare-at-price", help="Compare-at price"),
    currency: str = typer.Option("USD", "--currency", help="Currency code"),
    rating: float = typer.Option(None, "--rating", help="Average rating"),
    review_count: int = typer.Option(None, "--review-count", help="Number of reviews"),
    status: str = typer.Option("Active", "--status", help="Status: Active, Draft, Pending"),
    auto_generate_kb: bool = typer.Option(
        True, "--auto-generate-kb/--no-auto-generate-kb", help="Auto-generate Q&A"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Create a product."""
    parsed_images = _parse_csv_option(images)
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.product_create(
            client,
            title=title,
            description=description,
            url=url,
            images=parsed_images,
            price=price,
            compare_at_price=compare_at_price,
            currency=currency,
            rating=rating,
            review_count=review_count,
            status=status,
            auto_generate_kb=auto_generate_kb,
        )
    )
    typer.echo(result)


@app.command("taxonomy-create")
def taxonomy_create(
    name: str = typer.Option(..., "--name", "-n", help="Topic or intent name"),
    parent_id: str = typer.Option(
        None, "--parent-id", help="Parent topic UUID (if set, creates an intent)"
    ),
    color: str = typer.Option(None, "--color", help="Color"),
    description: str = typer.Option(None, "--description", help="Description"),
    comments: str = typer.Option(None, "--comments", help="Example queries (3 per line)"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Create a topic or intent."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.taxonomy_create(
            client,
            name=name,
            parent_id=parent_id,
            color=color,
            description=description,
            comments=comments,
        )
    )
    typer.echo(result)


@app.command("taxonomy-update")
def taxonomy_update(
    id: str = typer.Argument(..., help="Topic or intent ID"),
    name: str = typer.Option(None, "--name", "-n", help="Name"),
    color: str = typer.Option(None, "--color", help="Color"),
    description: str = typer.Option(None, "--description", help="Description"),
    comments: str = typer.Option(None, "--comments", help="Example queries"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Update a topic or intent."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.taxonomy_update(
            client,
            id,
            name=name,
            color=color,
            description=description,
            comments=comments,
        )
    )
    typer.echo(result)


@app.command("agent-create")
def agent_create(
    name: str = typer.Option(..., "--name", help="Agent name"),
    modality: str = typer.Option(
        ..., "--modality", help="Modality: Chat, Email, Call, SMS, All"
    ),
    agent_type: str = typer.Option(
        "Customer Support", "--type", help="Type: Customer Support, Generic, etc."
    ),
    model: str = typer.Option("GPT-4.1-mini", "--model", help="Model name"),
    prompt: str = typer.Option("", "--prompt", help="Guidance/guardrails text"),
    escalation_mode: str = typer.Option(
        "default",
        "--escalation-mode",
        help="Escalation mode: default, email, sms, email_non_opening_hours, ticketing_integration",
    ),
    auto_reply: bool = typer.Option(False, "--auto-reply", help="Enable auto-reply"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Create a new agent."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(
        tools.agent_create(
            client,
            name=name,
            modality=modality,
            agent_type=agent_type,
            model=model,
            prompt=prompt,
            escalation_mode=escalation_mode,
            auto_reply=auto_reply,
        )
    )
    typer.echo(result)


@app.command("agent-set-picture")
def agent_set_picture(
    id: str = typer.Argument(..., help="Agent ID"),
    image: str = typer.Option(
        ..., "--image", "-i", help="Path to image file (PNG, JPG, etc.)"
    ),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Set an agent's profile picture."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(tools.agent_set_picture(client, id, image))
    typer.echo(result)


@app.command("agent-delete")
def agent_delete(
    id: str = typer.Argument(..., help="Agent ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Delete an agent."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(tools.agent_delete(client, id))
    typer.echo(result)


@app.command("knowledge-delete")
def knowledge_delete(
    id: str = typer.Argument(..., help="Knowledge item ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Delete a knowledge base item."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(tools.knowledge_delete(client, id))
    typer.echo(result)


@app.command("product-delete")
def product_delete(
    id: str = typer.Argument(..., help="Product ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Delete a product."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(tools.product_delete(client, id))
    typer.echo(result)


@app.command("taxonomy-delete")
def taxonomy_delete(
    id: str = typer.Argument(..., help="Topic or intent ID"),
    shop_id: str = typer.Option(None, "--shop-id", help="Override shop ID"),
) -> None:
    """Delete a topic or intent."""
    client = get_client(shop_id=shop_id)
    result = asyncio.run(tools.taxonomy_delete(client, id))
    typer.echo(result)


def main() -> None:
    """CLI entrypoint."""
    nested_exit_code = run_agent_scoped_flow_command(sys.argv[1:], get_client)
    if nested_exit_code is not None:
        raise SystemExit(nested_exit_code)
    app()


if __name__ == "__main__":
    main()
