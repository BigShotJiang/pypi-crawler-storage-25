from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field


T = TypeVar("T", bound="UsageAttributes")


@_attrs_define
class UsageAttributes:
    """Usage counter for a single metered limit.

    Attributes:
        limit_key (str): Identifier of the metered limit, e.g. `flags.items`.
        period (str): Period the counter covers. `current` is the only supported value.
        value (int): Count for the period.
    """

    limit_key: str
    period: str
    value: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        limit_key = self.limit_key

        period = self.period

        value = self.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "limit_key": limit_key,
                "period": period,
                "value": value,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        limit_key = d.pop("limit_key")

        period = d.pop("period")

        value = d.pop("value")

        usage_attributes = cls(
            limit_key=limit_key,
            period=period,
            value=value,
        )

        usage_attributes.additional_properties = d
        return usage_attributes

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
