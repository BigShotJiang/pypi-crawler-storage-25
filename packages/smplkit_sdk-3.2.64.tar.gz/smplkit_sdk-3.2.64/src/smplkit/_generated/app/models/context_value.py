from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field


T = TypeVar("T", bound="ContextValue")


@_attrs_define
class ContextValue:
    """A single distinct attribute value observed across context instances.

    Returned by `GET /api/v1/context_values` to power typeahead pickers in
    rule-building UIs. The set of values reflects what has been registered
    via the bulk-context endpoint — it is observational, not a customer-
    declared enumeration.

        Example:
            {'value': 'Michael'}

        Attributes:
            value (str): The distinct attribute value as it appears on at least one context instance of the requested type.
    """

    value: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        value = self.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "value": value,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        value = d.pop("value")

        context_value = cls(
            value=value,
        )

        context_value.additional_properties = d
        return context_value

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
