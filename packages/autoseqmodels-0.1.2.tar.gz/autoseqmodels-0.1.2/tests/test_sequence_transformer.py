"""Tests for models/sequence_transformer.py."""
import numpy as np
import pytest

torch = pytest.importorskip("torch")

from autoseqmodels.models.sequence_transformer import (
    SequenceTransformer,
    predict_holdout_transformer,
)
from autoseqmodels.models.training import (
    SequenceDataset,
    evaluate_predictions,
    make_train_val_split,
    train_model,
)


# ---------------------------------------------------------------------------
# Minimal seqs fixture — matches build_transaction_sequences() output shape
# ---------------------------------------------------------------------------

def _make_seqs(
    n_customers: int = 8,
    n_train: int = 20,
    n_holdout: int = 10,
    feature_names=None,
    max_tx: int = 5,
):
    """Build a minimal seqs dict with controllable dimensions."""
    if feature_names is None:
        feature_names = ["week", "woy_sin", "woy_cos", "Income", "transactions"]
    n_feat = len(feature_names)
    week_idx = feature_names.index("week")
    tx_idx   = feature_names.index("transactions")

    rng = np.random.default_rng(0)

    def _make_frame(rows):
        frame = rng.uniform(0, 1, (rows, n_feat)).astype(np.float32)
        frame[:, week_idx] = (np.arange(rows) % 52).astype(np.float32)
        frame[:, tx_idx]   = rng.integers(0, max_tx + 1, rows).astype(np.float32)
        return frame

    calibration, samples, targets, holdout = [], [], [], []
    for _ in range(n_customers):
        calib = _make_frame(n_train)
        calibration.append(calib)
        samples.append(calib[:-1])
        targets.append(calib[1:, tx_idx])
        holdout.append(_make_frame(n_holdout))

    return {
        "samples":            samples,
        "targets":            targets,
        "calibration":        calibration,
        "holdout":            holdout,
        "account_ids":        list(range(n_customers)),
        "n_features":         n_feat,
        "feature_names":      feature_names,
        "total_transactions": int(sum(t.sum() for t in targets)),
    }


@pytest.fixture
def seqs():
    return _make_seqs()


@pytest.fixture
def seqs_no_float():
    """Minimal seqs with only week + transactions (no float features)."""
    return _make_seqs(feature_names=["week", "transactions"])


# ---------------------------------------------------------------------------
# SequenceTransformer — construction
# ---------------------------------------------------------------------------

class TestSequenceTransformer:
    def test_from_sequences_instantiates(self, seqs):
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        assert model is not None

    def test_d_model_must_be_divisible_by_heads(self, seqs):
        with pytest.raises(ValueError, match="divisible"):
            SequenceTransformer.from_sequences(
                seqs, d_model=33, n_heads=4, n_layers=1,
            )

    def test_output_size_equals_n_classes(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        # Last linear in the head produces (..., n_classes)
        last_linear = model.head[-1]
        assert last_linear.out_features == ds.n_classes

    def test_multi_layer_instantiates(self, seqs):
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=3, dropout=0.1,
        )
        assert len(model.encoder.layers) == 3

    def test_no_float_drops_projection(self, seqs_no_float):
        model = SequenceTransformer.from_sequences(
            seqs_no_float, d_model=32, n_heads=4, n_layers=1,
        )
        assert model.float_proj is None

    def test_forward_output_shape(self, seqs):
        from torch.utils.data import DataLoader
        ds     = SequenceDataset(seqs)
        model  = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        loader = DataLoader(ds, batch_size=4)
        week, txn, floats, _ = next(iter(loader))
        logits, kv = model(week, txn, floats)
        B, T = week.shape
        assert logits.shape == (B, T, ds.n_classes)
        # Second slot reserved for KV cache; currently None
        assert kv is None

    def test_no_float_forward(self, seqs_no_float):
        from torch.utils.data import DataLoader
        ds     = SequenceDataset(seqs_no_float)
        model  = SequenceTransformer.from_sequences(
            seqs_no_float, d_model=32, n_heads=4, n_layers=1,
        )
        loader = DataLoader(ds, batch_size=4)
        week, txn, floats, _ = next(iter(loader))
        logits, _ = model(week, txn, floats)
        assert logits.shape[2] == ds.n_classes

    def test_seq_length_overflow_raises(self, seqs):
        from torch.utils.data import DataLoader
        ds     = SequenceDataset(seqs)
        model  = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1, max_seq_len=4,
        )
        loader = DataLoader(ds, batch_size=4)
        week, txn, floats, _ = next(iter(loader))
        with pytest.raises(ValueError, match="max_seq_len"):
            model(week, txn, floats)


# ---------------------------------------------------------------------------
# train_model (generic — works on any model returning (logits, _))
# ---------------------------------------------------------------------------

class TestTrainTransformer:
    def test_returns_history(self, seqs):
        ds = SequenceDataset(seqs)
        train_ds, val_ds = make_train_val_split(ds, val_fraction=0.25)
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        history = train_model(model, train_ds, val_ds, epochs=2, verbose=False)
        assert "train_loss" in history
        assert "val_loss"   in history
        assert len(history["train_loss"]) == 2

    def test_loss_is_finite(self, seqs):
        ds = SequenceDataset(seqs)
        train_ds, val_ds = make_train_val_split(ds, val_fraction=0.25)
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        history = train_model(model, train_ds, val_ds, epochs=3, verbose=False)
        for loss in history["train_loss"] + history["val_loss"]:
            assert np.isfinite(loss)


# ---------------------------------------------------------------------------
# predict_holdout_transformer
# ---------------------------------------------------------------------------

class TestPredictHoldoutTransformer:
    def test_output_shape(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        preds = predict_holdout_transformer(
            model, seqs, ds, n_simulations=1, verbose=False,
        )
        N = len(seqs["holdout"])
        H = seqs["holdout"][0].shape[0]
        assert preds.shape == (N, H)

    def test_predictions_non_negative(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        preds = predict_holdout_transformer(
            model, seqs, ds, n_simulations=1, verbose=False,
        )
        assert (preds >= 0).all()

    def test_no_nan_in_predictions(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        preds = predict_holdout_transformer(
            model, seqs, ds, n_simulations=1, verbose=False,
        )
        assert not np.isnan(preds).any()

    def test_no_float_predict(self, seqs_no_float):
        ds    = SequenceDataset(seqs_no_float)
        model = SequenceTransformer.from_sequences(
            seqs_no_float, d_model=32, n_heads=4, n_layers=1,
        )
        preds = predict_holdout_transformer(
            model, seqs_no_float, ds, n_simulations=1, verbose=False,
        )
        assert preds.shape[0] == len(seqs_no_float["holdout"])


# ---------------------------------------------------------------------------
# evaluate_predictions on the transformer's output
# ---------------------------------------------------------------------------

class TestEvaluateTransformerPredictions:
    def test_returns_expected_keys(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        preds = predict_holdout_transformer(
            model, seqs, ds, n_simulations=1, verbose=False,
        )
        metrics = evaluate_predictions(preds, seqs, verbose=False)
        assert set(metrics.keys()) == {"bias_pct", "rmse", "mape_pct"}

    def test_rmse_non_negative(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceTransformer.from_sequences(
            seqs, d_model=32, n_heads=4, n_layers=1,
        )
        preds = predict_holdout_transformer(
            model, seqs, ds, n_simulations=1, verbose=False,
        )
        metrics = evaluate_predictions(preds, seqs, verbose=False)
        assert metrics["rmse"] >= 0.0
