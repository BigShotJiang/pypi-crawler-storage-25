"""Tests for models/sequence_lstm.py."""
import numpy as np
import pytest

torch = pytest.importorskip("torch")

from autoseqmodels.models.sequence_lstm import (
    SequenceDataset,
    SequenceLSTM,
    evaluate_predictions,
    make_train_val_split,
    predict_holdout,
    train_model,
)


# ---------------------------------------------------------------------------
# Minimal seqs fixture — matches build_transaction_sequences() output shape
# ---------------------------------------------------------------------------

def _make_seqs(
    n_customers: int = 8,
    n_train: int = 20,
    n_holdout: int = 10,
    feature_names=None,
    max_tx: int = 5,
):
    """Build a minimal seqs dict with controllable dimensions."""
    if feature_names is None:
        feature_names = ["week", "woy_sin", "woy_cos", "Income", "transactions"]
    n_feat = len(feature_names)
    week_idx = feature_names.index("week")
    tx_idx   = feature_names.index("transactions")

    rng = np.random.default_rng(0)

    def _make_frame(rows):
        frame = rng.uniform(0, 1, (rows, n_feat)).astype(np.float32)
        frame[:, week_idx] = (np.arange(rows) % 52).astype(np.float32)
        frame[:, tx_idx]   = rng.integers(0, max_tx + 1, rows).astype(np.float32)
        return frame

    calibration, samples, targets, holdout = [], [], [], []
    for _ in range(n_customers):
        calib = _make_frame(n_train)
        calibration.append(calib)
        samples.append(calib[:-1])
        targets.append(calib[1:, tx_idx])
        holdout.append(_make_frame(n_holdout))

    return {
        "samples":            samples,
        "targets":            targets,
        "calibration":        calibration,
        "holdout":            holdout,
        "account_ids":        list(range(n_customers)),
        "n_features":         n_feat,
        "feature_names":      feature_names,
        "total_transactions": int(sum(t.sum() for t in targets)),
    }


@pytest.fixture
def seqs():
    return _make_seqs()


@pytest.fixture
def seqs_no_float():
    """Minimal seqs with only week + transactions (no float features)."""
    return _make_seqs(feature_names=["week", "transactions"])


# ---------------------------------------------------------------------------
# SequenceDataset
# ---------------------------------------------------------------------------

class TestSequenceDataset:
    def test_length_matches_customers(self, seqs):
        ds = SequenceDataset(seqs)
        assert len(ds) == len(seqs["account_ids"])

    def test_item_shapes(self, seqs):
        ds = SequenceDataset(seqs)
        week, txn, floats, target = ds[0]
        T = seqs["samples"][0].shape[0]          # T-1
        n_float = len(ds.float_indices)
        assert week.shape   == (T,)
        assert txn.shape    == (T,)
        assert floats.shape == (T, n_float)
        assert target.shape == (T,)

    def test_week_dtype_is_long(self, seqs):
        ds = SequenceDataset(seqs)
        week, _, _, _ = ds[0]
        assert week.dtype == torch.long

    def test_float_dtype_is_float32(self, seqs):
        ds = SequenceDataset(seqs)
        _, _, floats, _ = ds[0]
        assert floats.dtype == torch.float32

    def test_target_dtype_is_long(self, seqs):
        ds = SequenceDataset(seqs)
        _, _, _, target = ds[0]
        assert target.dtype == torch.long

    def test_n_classes_derived_from_data(self, seqs):
        ds = SequenceDataset(seqs)
        # n_classes = max_tx + 1 = 6
        assert ds.n_classes >= 1

    def test_n_float_excludes_week_and_tx(self, seqs):
        ds = SequenceDataset(seqs)
        # feature_names = [week, woy_sin, woy_cos, Income, transactions]
        # float features = [woy_sin, woy_cos, Income] → 3
        assert ds.n_float == 3

    def test_no_float_features(self, seqs_no_float):
        ds = SequenceDataset(seqs_no_float)
        assert ds.n_float == 0
        _, _, floats, _ = ds[0]
        assert floats.shape[1] == 0

    def test_transactions_clipped_to_max(self):
        seqs = _make_seqs(max_tx=3)
        ds = SequenceDataset(seqs, max_transactions=2)
        for _, txn, _, target in ds:
            assert txn.max().item()    <= 2
            assert target.max().item() <= 2


# ---------------------------------------------------------------------------
# make_train_val_split
# ---------------------------------------------------------------------------

class TestTrainValSplit:
    def test_sizes_sum_to_total(self, seqs):
        ds = SequenceDataset(seqs)
        train, val = make_train_val_split(ds, val_fraction=0.25)
        assert len(train) + len(val) == len(ds)

    def test_val_size_at_least_one(self, seqs):
        ds = SequenceDataset(seqs)
        _, val = make_train_val_split(ds, val_fraction=0.01)
        assert len(val) >= 1


# ---------------------------------------------------------------------------
# SequenceLSTM — construction
# ---------------------------------------------------------------------------

class TestSequenceLSTM:
    def test_from_sequences_instantiates(self, seqs):
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16, n_layers=1)
        assert model is not None

    def test_input_size_includes_floats(self, seqs):
        ds = SequenceDataset(seqs)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        # input_size = week_emb + txn_emb + n_float
        cell_input = model.cells[0].input_size
        assert cell_input > ds.n_float   # at least the float part

    def test_output_size_equals_n_classes(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        assert model.out.out_features == ds.n_classes

    def test_multi_layer_instantiates(self, seqs):
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16, n_layers=2, dropout=0.1)
        assert len(model.cells) == 2
        assert len(model.layer_norms) == 2

    def test_forward_output_shape(self, seqs):
        import torch
        from torch.utils.data import DataLoader
        ds     = SequenceDataset(seqs)
        model  = SequenceLSTM.from_sequences(seqs, hidden_size=16, n_layers=1)
        loader = DataLoader(ds, batch_size=4)
        week, txn, floats, _ = next(iter(loader))
        logits, (h, c) = model(week, txn, floats)
        B = week.shape[0]
        T = week.shape[1]
        assert logits.shape == (B, T, ds.n_classes)
        assert h.shape == (1, B, 16)
        assert c.shape == (1, B, 16)

    def test_no_float_forward(self, seqs_no_float):
        import torch
        from torch.utils.data import DataLoader
        ds     = SequenceDataset(seqs_no_float)
        model  = SequenceLSTM.from_sequences(seqs_no_float, hidden_size=16)
        loader = DataLoader(ds, batch_size=4)
        week, txn, floats, _ = next(iter(loader))
        logits, _ = model(week, txn, floats)
        assert logits.shape[2] == ds.n_classes


# ---------------------------------------------------------------------------
# train_model
# ---------------------------------------------------------------------------

class TestTrainModel:
    def test_returns_history(self, seqs):
        ds = SequenceDataset(seqs)
        train_ds, val_ds = make_train_val_split(ds, val_fraction=0.25)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16, n_layers=1)
        history = train_model(model, train_ds, val_ds, epochs=2, verbose=False)
        assert "train_loss" in history
        assert "val_loss"   in history
        assert len(history["train_loss"]) == 2

    def test_loss_is_finite(self, seqs):
        ds = SequenceDataset(seqs)
        train_ds, val_ds = make_train_val_split(ds, val_fraction=0.25)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        history = train_model(model, train_ds, val_ds, epochs=3, verbose=False)
        for loss in history["train_loss"] + history["val_loss"]:
            assert np.isfinite(loss)

    def test_early_stopping_triggers(self, seqs):
        ds = SequenceDataset(seqs)
        train_ds, val_ds = make_train_val_split(ds, val_fraction=0.25)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        history = train_model(
            model, train_ds, val_ds,
            epochs=50, patience=2, verbose=False,
        )
        assert len(history["train_loss"]) < 50


# ---------------------------------------------------------------------------
# predict_holdout
# ---------------------------------------------------------------------------

class TestPredictHoldout:
    def test_output_shape(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        preds = predict_holdout(model, seqs, ds, n_simulations=1)
        N = len(seqs["holdout"])
        H = seqs["holdout"][0].shape[0]
        assert preds.shape == (N, H)

    def test_predictions_non_negative(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        preds = predict_holdout(model, seqs, ds, n_simulations=1)
        assert (preds >= 0).all()

    def test_mc_simulations_shape(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        preds = predict_holdout(model, seqs, ds, n_simulations=10)
        N = len(seqs["holdout"])
        H = seqs["holdout"][0].shape[0]
        assert preds.shape == (N, H)

    def test_no_nan_in_predictions(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        preds = predict_holdout(model, seqs, ds, n_simulations=1)
        assert not np.isnan(preds).any()

    def test_no_float_predict(self, seqs_no_float):
        ds    = SequenceDataset(seqs_no_float)
        model = SequenceLSTM.from_sequences(seqs_no_float, hidden_size=16)
        preds = predict_holdout(model, seqs_no_float, ds, n_simulations=1)
        assert preds.shape[0] == len(seqs_no_float["holdout"])


# ---------------------------------------------------------------------------
# evaluate_predictions
# ---------------------------------------------------------------------------

class TestEvaluatePredictions:
    def test_returns_expected_keys(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        preds = predict_holdout(model, seqs, ds, n_simulations=1)
        metrics = evaluate_predictions(preds, seqs, verbose=False)
        assert set(metrics.keys()) == {"bias_pct", "rmse", "mape_pct"}

    def test_rmse_non_negative(self, seqs):
        ds    = SequenceDataset(seqs)
        model = SequenceLSTM.from_sequences(seqs, hidden_size=16)
        preds = predict_holdout(model, seqs, ds, n_simulations=1)
        metrics = evaluate_predictions(preds, seqs, verbose=False)
        assert metrics["rmse"] >= 0.0

    def test_perfect_prediction_has_zero_error(self, seqs):
        tx_idx = seqs["feature_names"].index("transactions")
        perfect = np.stack([h[:, tx_idx] for h in seqs["holdout"]]).astype(np.float32)
        metrics = evaluate_predictions(perfect, seqs, verbose=False)
        assert abs(metrics["bias_pct"])   < 1e-3
        assert abs(metrics["rmse"])       < 1e-5
        assert abs(metrics["mape_pct"])   < 1e-3
