"""Tests for data_prep/inspection.py."""
import pandas as pd
import pytest

from autoseqmodels.data_prep.inspection import (
    DETECTED_COLS,
    DataStructure,
    _check_detected,
    _check_df,
    cast_columns_by_detected_type,
    classify_time_variance,
    infer_column_types,
    propose_structure,
)


# ---------------------------------------------------------------------------
# infer_column_types
# ---------------------------------------------------------------------------

class TestInferColumnTypes:
    def test_output_has_required_columns(self, raw_tx_df):
        detected = infer_column_types(raw_tx_df)
        assert set(detected.columns) >= DETECTED_COLS

    def test_integer_id_detected_as_identifier(self, raw_tx_df):
        detected = infer_column_types(raw_tx_df)
        row = detected.loc[detected["column"] == "Id"].iloc[0]
        assert row["statistical_type"] == "identifier"
        assert row["refined_type"] == "id"

    def test_binary_integer_not_promoted_to_identifier(self):
        df = pd.DataFrame({"is_active": [0, 1, 0, 1]})
        detected = infer_column_types(df)
        row = detected.iloc[0]
        assert row["statistical_type"] == "binary"
        assert row["refined_type"] == "int"

    def test_string_id_column_detected(self):
        df = pd.DataFrame({"customer_id": ["A001", "A002", "A003"]})
        detected = infer_column_types(df)
        row = detected.iloc[0]
        assert row["statistical_type"] == "identifier"
        assert row["refined_type"] == "id"

    def test_date_string_detected(self, raw_tx_df):
        df = raw_tx_df.copy()
        df["Date"] = df["Date"].astype(str)
        detected = infer_column_types(df)
        row = detected.loc[detected["column"] == "Date"].iloc[0]
        assert row["refined_type"] == "date"
        assert row["statistical_type"] == "temporal"

    def test_datetime64_detected(self, raw_tx_df):
        detected = infer_column_types(raw_tx_df)
        row = detected.loc[detected["column"] == "Date"].iloc[0]
        assert row["refined_type"] == "date"
        assert row["statistical_type"] == "temporal"

    def test_float_continuous(self):
        df = pd.DataFrame({"x": [float(i) for i in range(100)]})
        detected = infer_column_types(df)
        assert detected.iloc[0]["statistical_type"] == "continuous"

    def test_float_few_unique_is_discrete(self):
        df = pd.DataFrame({"tier": [1.0, 2.0, 3.0] * 20})
        detected = infer_column_types(df)
        assert detected.iloc[0]["statistical_type"] == "discrete"

    def test_bool_dtype_is_binary(self):
        df = pd.DataFrame({"flag": [True, False, True]})
        detected = infer_column_types(df)
        assert detected.iloc[0]["statistical_type"] == "binary"

    def test_low_cardinality_string_is_category(self):
        df = pd.DataFrame({"channel": ["web", "app", "store"] * 10})
        detected = infer_column_types(df)
        assert detected.iloc[0]["statistical_type"] == "categorical"

    def test_n_unique_counts(self, raw_tx_df):
        detected = infer_column_types(raw_tx_df)
        id_row = detected.loc[detected["column"] == "Id"].iloc[0]
        assert id_row["n_unique"] == 3

    def test_empty_df_raises(self):
        with pytest.raises(ValueError, match="empty"):
            infer_column_types(pd.DataFrame())

    def test_wrong_type_raises(self):
        with pytest.raises(TypeError, match="pandas DataFrame"):
            infer_column_types("not a dataframe")


# ---------------------------------------------------------------------------
# propose_structure
# ---------------------------------------------------------------------------

class TestProposeStructure:
    def test_detects_entity_and_date(self, raw_tx_df, capsys):
        detected = infer_column_types(raw_tx_df)
        structure = propose_structure(detected)
        assert structure.entity_col == "Id"
        assert structure.date_col == "Date"
        assert structure.target_col is None

    def test_entity_none_when_no_identifier(self, capsys):
        df = pd.DataFrame({"x": [1.0, 2.0], "y": [3.0, 4.0]})
        detected = infer_column_types(df)
        structure = propose_structure(detected)
        assert structure.entity_col is None

    def test_picks_date_with_most_unique(self, capsys):
        df = pd.DataFrame({
            "cohort_date": pd.to_datetime(["2020-01-01", "2020-01-01", "2020-01-01"]),
            "tx_date":     pd.to_datetime(["2020-01-01", "2020-06-15", "2020-12-31"]),
            "Id":          [1, 2, 3],
        })
        detected = infer_column_types(df)
        structure = propose_structure(detected)
        assert structure.date_col == "tx_date"

    def test_wrong_input_raises(self, raw_tx_df):
        with pytest.raises(ValueError, match="infer_column_types"):
            propose_structure(raw_tx_df)


# ---------------------------------------------------------------------------
# classify_time_variance
# ---------------------------------------------------------------------------

class TestClassifyTimeVariance:
    def test_variant_and_invariant_labels(self, panel_df, detected_panel):
        summary, _ = classify_time_variance(panel_df, "Id", detected_panel)
        assert summary.loc[summary["column"] == "Revenue", "time_variance"].iloc[0] == "variant"
        assert summary.loc[summary["column"] == "Income",  "time_variance"].iloc[0] == "invariant"
        assert summary.loc[summary["column"] == "Gender",  "time_variance"].iloc[0] == "invariant"

    def test_entity_col_labeled_identifier(self, panel_df, detected_panel):
        summary, _ = classify_time_variance(panel_df, "Id", detected_panel)
        assert summary.loc[summary["column"] == "Id", "time_variance"].iloc[0] == "identifier"

    def test_main_date_detected(self, panel_df, detected_panel):
        _, main_date = classify_time_variance(panel_df, "Id", detected_panel)
        assert main_date == "Week"

    def test_updates_datastructure_in_place(self, panel_df, detected_panel, capsys):
        structure = DataStructure(
            entity_col="Id", date_col=None, target_col=None,
            entity_candidates=[], date_candidates=[],
        )
        classify_time_variance(panel_df, structure, detected_panel)
        assert structure.date_col == "Week"

    def test_wrong_detected_raises(self, panel_df, raw_tx_df):
        with pytest.raises(ValueError, match="infer_column_types"):
            classify_time_variance(panel_df, "Id", raw_tx_df)

    def test_wrong_df_raises(self, detected_panel):
        with pytest.raises(TypeError, match="pandas DataFrame"):
            classify_time_variance("nope", "Id", detected_panel)

    def test_none_entity_in_datastructure_raises(self, panel_df, detected_panel):
        structure = DataStructure(
            entity_col=None, date_col=None, target_col=None,
            entity_candidates=[], date_candidates=[],
        )
        with pytest.raises(ValueError, match="entity_col is None"):
            classify_time_variance(panel_df, structure, detected_panel)


# ---------------------------------------------------------------------------
# cast_columns_by_detected_type
# ---------------------------------------------------------------------------

class TestCastColumnsByDetectedType:
    def test_casts_date_strings_to_datetime(self):
        df = pd.DataFrame({"Date": ["2020-01-01", "2020-06-15"]})
        detected = infer_column_types(df)
        result = cast_columns_by_detected_type(df, detected)
        assert pd.api.types.is_datetime64_any_dtype(result["Date"])

    def test_casts_bool_strings(self):
        # _looks_like_bool matches a single known pair; use only "true"/"false"
        df = pd.DataFrame({"active": ["true", "false", "true", "false"]})
        detected = infer_column_types(df)
        result = cast_columns_by_detected_type(df, detected)
        assert result["active"].dtype == bool

    def test_id_column_left_unchanged(self, raw_tx_df, detected_raw):
        result = cast_columns_by_detected_type(raw_tx_df, detected_raw)
        assert result["Id"].dtype == raw_tx_df["Id"].dtype

    def test_wrong_detected_raises(self, raw_tx_df):
        with pytest.raises(ValueError, match="infer_column_types"):
            cast_columns_by_detected_type(raw_tx_df, raw_tx_df)

    def test_wrong_df_raises(self, detected_raw):
        with pytest.raises(TypeError, match="pandas DataFrame"):
            cast_columns_by_detected_type(42, detected_raw)


# ---------------------------------------------------------------------------
# Shared validation helpers
# ---------------------------------------------------------------------------

class TestValidationHelpers:
    def test_check_df_wrong_type(self):
        with pytest.raises(TypeError, match="pandas DataFrame"):
            _check_df([1, 2, 3], "test_fn")

    def test_check_df_empty(self):
        with pytest.raises(ValueError, match="empty"):
            _check_df(pd.DataFrame(), "test_fn")

    def test_check_detected_wrong_type(self):
        with pytest.raises(TypeError, match="infer_column_types"):
            _check_detected("oops", "test_fn")

    def test_check_detected_missing_cols(self, raw_tx_df):
        with pytest.raises(ValueError, match="missing required column"):
            _check_detected(raw_tx_df, "test_fn")

    def test_check_detected_error_lists_expected_cols(self, raw_tx_df):
        with pytest.raises(ValueError, match="statistical_type"):
            _check_detected(raw_tx_df, "test_fn")
