"""Tests for data_prep/encoders.py."""
import numpy as np
import pandas as pd
import pytest

from autoseqmodels.data_prep.encoders import (
    EncodingSpec,
    encoding_report,
    prepare_encodings,
)
from autoseqmodels.data_prep.inspection import infer_column_types


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def numeric_df():
    """Simple DataFrame with no identifiers — tests scaling and passthrough."""
    return pd.DataFrame({
        "price":   [10.0, 20.0, 30.0, 40.0, 50.0],
        "quantity": [1,    2,    3,    4,    5],
    })


@pytest.fixture
def seasonal_df():
    """DataFrame with manually-built sin/cos seasonality columns.

    Mirrors what build_transaction_sequences emits: columns ending in
    ``_sin`` / ``_cos`` are detected by encoders.py as cyclical and
    routed to passthrough (already in [-1, 1]; scaling would distort).
    """
    months = np.array([1, 4, 7, 10])
    return pd.DataFrame({
        "moy_sin": np.sin(2 * np.pi * months / 12),
        "moy_cos": np.cos(2 * np.pi * months / 12),
        "price":   [10.0, 20.0, 30.0, 40.0],
    })


@pytest.fixture
def full_df(raw_tx_df):
    """Encoded-ready DataFrame: Id (identifier) + Date (temporal) + Price (continuous)."""
    return raw_tx_df


# ---------------------------------------------------------------------------
# Strategy detection
# ---------------------------------------------------------------------------

class TestStrategyDetection:
    def test_sin_cos_are_passthrough(self, seasonal_df):
        detected = infer_column_types(seasonal_df)
        _, spec = prepare_encodings(seasonal_df, detected)
        sin_cos = [c for c in spec.passthrough if c.endswith("_sin") or c.endswith("_cos")]
        assert len(sin_cos) > 0, "No _sin/_cos columns in passthrough"
        for col in sin_cos:
            assert col in spec.passthrough

    def test_sin_cos_not_scaled(self, seasonal_df):
        detected = infer_column_types(seasonal_df)
        _, spec = prepare_encodings(seasonal_df, detected)
        for col in spec.scaled:
            assert not col.endswith("_sin") and not col.endswith("_cos")

    def test_identifier_is_embedded(self, full_df):
        detected = infer_column_types(full_df)
        _, spec = prepare_encodings(full_df, detected)
        assert "Id" in spec.embeddings

    def test_numeric_is_scaled(self, full_df):
        detected = infer_column_types(full_df)
        _, spec = prepare_encodings(full_df, detected)
        assert "Price" in spec.scaled

    def test_binary_routes_to_binary(self):
        df = pd.DataFrame({"flag": [0, 1, 0, 1, 1], "value": [1.0, 2.0, 3.0, 4.0, 5.0]})
        detected = infer_column_types(df)
        _, spec = prepare_encodings(df, detected)
        assert "flag" in spec.binary

    def test_low_cardinality_category_is_onehot(self):
        df = pd.DataFrame({"channel": ["web", "app", "store"] * 4})
        detected = infer_column_types(df)
        _, spec = prepare_encodings(df, detected)
        assert "channel" in spec.onehot

    def test_override_changes_strategy(self, numeric_df):
        detected = infer_column_types(numeric_df)
        _, spec = prepare_encodings(numeric_df, detected, overrides={"price": "passthrough"})
        assert "price" in spec.passthrough
        assert "price" not in spec.scaled


# ---------------------------------------------------------------------------
# Embedding dimension
# ---------------------------------------------------------------------------

class TestEmbeddingDim:
    def test_guo_berkhahn_formula(self):
        """embed_dim = min(max_embed_dim, max(2, (n_unique + 1) // 2))"""
        df = pd.DataFrame({"cust_id": list(range(1, 11))})   # 10 unique
        detected = infer_column_types(df)
        _, spec = prepare_encodings(df, detected)
        expected = min(50, max(2, (10 + 1) // 2))            # = 5
        assert spec.embeddings["cust_id"].embed_dim == expected

    def test_small_cardinality_embed_dim_at_least_2(self):
        df = pd.DataFrame({"order_id": [1, 2, 3]})           # 3 unique
        detected = infer_column_types(df)
        _, spec = prepare_encodings(df, detected)
        assert spec.embeddings["order_id"].embed_dim >= 2

    def test_large_cardinality_capped_at_max_embed_dim(self):
        df = pd.DataFrame({"cust_id": list(range(1, 1001))}) # 1000 unique
        detected = infer_column_types(df)
        _, spec = prepare_encodings(df, detected, max_embed_dim=20)
        assert spec.embeddings["cust_id"].embed_dim == 20


# ---------------------------------------------------------------------------
# input_width consistency
# ---------------------------------------------------------------------------

class TestInputWidth:
    def test_input_width_no_embeddings(self, seasonal_df):
        """When there are no embedding columns, input_width == number of output columns."""
        detected = infer_column_types(seasonal_df)
        enc_df, spec = prepare_encodings(seasonal_df, detected)
        # All sin/cos → passthrough, price → scale; no embeddings, no onehot
        assert spec.input_width == len(spec.scaled) + len(spec.passthrough)
        assert spec.input_width == enc_df.shape[1]

    def test_input_width_with_embedding(self, full_df):
        """input_width = embed_dim + scaled + passthrough (> enc_df.shape[1])."""
        detected = infer_column_types(full_df)
        enc_df, spec = prepare_encodings(full_df, detected)
        embed_width = sum(e.embed_dim for e in spec.embeddings.values())
        expected = embed_width + len(spec.scaled) + len(spec.passthrough)
        assert spec.input_width == expected

    def test_input_width_with_onehot(self):
        df = pd.DataFrame({
            "channel": ["web", "app", "store"] * 4,
            "price": [float(i) for i in range(12)],
        })
        detected = infer_column_types(df)
        enc_df, spec = prepare_encodings(df, detected)
        onehot_width = sum(len(cats) for cats in spec.onehot.values())
        assert spec.input_width == onehot_width + len(spec.scaled) + len(spec.passthrough)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

class TestValidation:
    def test_empty_df_raises(self, detected_raw):
        with pytest.raises(ValueError, match="empty"):
            prepare_encodings(pd.DataFrame())

    def test_wrong_df_type_raises(self, detected_raw):
        with pytest.raises(TypeError, match="pandas DataFrame"):
            prepare_encodings("not a df", detected_raw)

    def test_stale_detected_warns_extra_col_in_detected(self, full_df):
        detected = infer_column_types(full_df)
        df_fewer = full_df.drop(columns=["Date"])
        with pytest.warns(UserWarning, match="NOT in df"):
            prepare_encodings(df_fewer, detected)

    def test_stale_detected_warns_extra_col_in_df(self, full_df):
        detected = infer_column_types(full_df)
        df_more = full_df.copy()
        df_more["NewCol"] = 99.0
        with pytest.warns(UserWarning, match="NOT in"):
            prepare_encodings(df_more, detected)


# ---------------------------------------------------------------------------
# encoding_report
# ---------------------------------------------------------------------------

class TestEncodingReport:
    def test_report_has_required_columns(self, full_df):
        detected = infer_column_types(full_df)
        _, spec = prepare_encodings(full_df, detected)
        report = encoding_report(spec)
        assert set(report.columns) >= {"original_col", "strategy", "output_cols", "details"}

    def test_report_footer_shows_input_width(self, full_df):
        detected = infer_column_types(full_df)
        _, spec = prepare_encodings(full_df, detected)
        report = encoding_report(spec)
        footer = report.iloc[-1]
        assert f"input_width = {spec.input_width}" in footer["output_cols"]

    def test_wrong_spec_type_raises(self):
        with pytest.raises(TypeError, match="EncodingSpec"):
            encoding_report("not a spec")

    def test_report_row_count(self, full_df):
        detected = infer_column_types(full_df)
        _, spec = prepare_encodings(full_df, detected)
        report = encoding_report(spec)
        n_data = len(full_df.columns)           # one data row per original column
        assert len(report) == n_data + 1        # + 1 footer row
