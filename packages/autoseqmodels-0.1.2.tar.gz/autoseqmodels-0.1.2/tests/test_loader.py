"""Tests for data_prep/loader.py."""
import pandas as pd
import pytest

from autoseqmodels.data_prep.loader import load_table


class TestLoadTable:
    def test_load_csv_basic(self, tmp_path):
        csv = tmp_path / "data.csv"
        csv.write_text("Id,Date,Price\n1,2020-01-01,10.0\n2,2020-02-01,20.0\n")
        df = load_table(csv)
        assert list(df.columns) == ["Id", "Date", "Price"]
        assert len(df) == 2

    def test_load_csv_with_encoding(self, tmp_path):
        csv = tmp_path / "data.csv"
        csv.write_bytes("Id,Value\n1,10\n2,20\n".encode("latin-1"))
        df = load_table(csv, encoding="latin-1")
        assert len(df) == 2

    def test_load_nonexistent_file_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError, match="not found"):
            load_table(tmp_path / "does_not_exist.csv")

    def test_load_unsupported_extension_raises(self, tmp_path):
        f = tmp_path / "data.json"
        f.write_text("{}")
        with pytest.raises(ValueError, match="not supported"):
            load_table(f)

    def test_load_r_requires_merge_on(self, tmp_path):
        """Passing r_covariates_object_name without merge_on must raise."""
        # We can't easily test a real .RData file, but we can test the
        # validation that fires before pyreadr is called.
        fake_r = tmp_path / "data.rda"
        fake_r.write_bytes(b"")  # invalid content — triggers pyreadr error, not our check
        with pytest.raises((ValueError, Exception)):
            load_table(fake_r, r_covariates_object_name="covariates")

    def test_load_returns_dataframe(self, tmp_path):
        csv = tmp_path / "data.csv"
        csv.write_text("A,B\n1,2\n3,4\n")
        result = load_table(csv)
        assert isinstance(result, pd.DataFrame)
