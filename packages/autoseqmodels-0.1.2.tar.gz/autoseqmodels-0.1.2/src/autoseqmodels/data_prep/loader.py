# Needed Packages :
from __future__ import annotations
from pathlib import Path
from typing import Optional, Union
import warnings
import numpy as np
import pandas as pd


def _coerce_merge_key(base: pd.Series, other: pd.Series) -> tuple[pd.Series, pd.Series]:
    """
    Align merge key dtypes across two Series before a join.

    Handles the case where R integer columns (including bit64::integer64
    misread as float64) face string IDs from the other table — cast both
    sides to string so the join can match.
    """
    base_numeric = pd.api.types.is_numeric_dtype(base)
    other_numeric = pd.api.types.is_numeric_dtype(other)

    if base_numeric and not other_numeric:
        # float64 may be a misread bit64::integer64 — reinterpret bytes first
        if base.dtype == np.float64:
            base = pd.Series(base.values.view(np.int64), index=base.index)
        return base.astype(str), other.astype(str)

    if other_numeric and not base_numeric:
        if other.dtype == np.float64:
            other = pd.Series(other.values.view(np.int64), index=other.index)
        return base.astype(str), other.astype(str)

    return base, other


def _find_date_col(df: pd.DataFrame, exclude: Optional[set] = None) -> str:
    """Return the name of the first date/datetime column in df, skipping *exclude*."""
    exclude = exclude or set()
    for col in df.columns:
        if col not in exclude and pd.api.types.is_datetime64_any_dtype(df[col]):
            return col
    for col in df.columns:
        if col not in exclude and "date" in col.lower():
            return col
    raise ValueError(
        f"Cannot detect a date column in DataFrame with columns {list(df.columns)}. "
        "Ensure the date column has a datetime dtype or contains 'date' in its name."
    )


# Loading Table function :
def load_table(
    path: str | Path,
    encoding: Optional[str] = None,
    r_covariates_object_name: Optional[str] = None,
    r_base_object_name: Optional[str] = None,
) -> Union[pd.DataFrame, tuple[pd.DataFrame, pd.DataFrame]]:
    """
    Load a table from a supported file type.

    Path : Path to the file to load.
    Encoding : Optional encoding to use when reading text files (e.g. utf-8, latin-1). If not specified, the function will attempt to auto-detect the encoding.

    Supported:
    - .csv
    - .xlsx / .xls
    - .RData / .rda

    R-specific behavior
    -------------------
    - .RData / .rda:
        If `r_covariates_object_name` is provided, the function returns a
        tuple ``(base_df, covariates_df)``.  Pass the result to
        ``build_transaction_panel`` to aggregate transactions and expand to
        the full covariate calendar.

        If `r_base_object_name` is also provided, that object is used as
        the base table. Otherwise the function looks for exactly one
        non-covariate object to use as the base.

        If neither is provided, the function returns the first DataFrame found.

    Notes
    -----
    - `.rds` files are also supported via `pyreadr`.
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: '{path}'")

    suffix = path.suffix.lower()

    if suffix == ".csv":
        return pd.read_csv(path, encoding=encoding)

    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)

    if suffix not in {".csv", ".xlsx", ".xls", ".rdata", ".rda"}:
        raise ValueError(
            f"The {suffix} format is not supported by this loader. "
            f"Convert '{path.name}' to '.csv', '.xlsx', or '.RData' to load it with this function."
        )

    # RData/RDA loading with pyreadr
    if suffix in {".rdata", ".rda"}:
        try:
            import pyreadr
        except ImportError as exc:
            raise ImportError(
                "Reading .RData/.rda files requires the 'pyreadr' package. "
                "Install it with: pip install pyreadr"
            ) from exc

        try:
            result = pyreadr.read_r(str(path))
        except Exception as exc:
            raise ValueError(f"Failed to read R file '{path}': {exc}") from exc

        dataframes: dict[str, pd.DataFrame] = {
            k: v for k, v in result.items() if v is not None
        }

        if not dataframes:
            raise ValueError(f"No readable objects found in R file: '{path}'")

        if r_covariates_object_name is not None:
            if r_covariates_object_name not in dataframes:
                raise ValueError(
                    f"Covariates object '{r_covariates_object_name}' not found in "
                    f"'{path.name}'. Available objects: {list(dataframes.keys())}"
                )

            covariates_df = dataframes[r_covariates_object_name]
            base_candidates = [
                name for name in dataframes if name != r_covariates_object_name
            ]

            if r_base_object_name is not None:
                if r_base_object_name not in dataframes:
                    raise ValueError(
                        f"Base object '{r_base_object_name}' not found in '{path.name}'. "
                        f"Available objects: {list(dataframes.keys())}"
                    )
                base_name = r_base_object_name
            elif len(base_candidates) == 1:
                base_name = base_candidates[0]
            else:
                raise ValueError(
                    f"Could not uniquely identify the base table in '{path.name}'. "
                    f"Found {len(base_candidates)} candidates: {base_candidates}. "
                    f"Pass `r_base_object_name` to specify which one to use."
                )

            base_df = dataframes[base_name]

            return base_df, covariates_df

        if len(dataframes) == 1:
            return next(iter(dataframes.values()))

        first_name, first_df = next(iter(dataframes.items()))
        warnings.warn(
            f"'{path.name}' contains multiple objects {list(dataframes.keys())}. "
            f"Returning '{first_name}'. Use `r_covariates_object_name` to load two "
            f"objects, or specify a more explicit loading strategy.",
            UserWarning,
            stacklevel=2,
        )
        return first_df

    raise ValueError(f"Unsupported file type: '{suffix}'")


def build_transaction_panel(
    tx_df: pd.DataFrame,
    cov_df: Optional[pd.DataFrame] = None,
    merge_on: Optional[str] = None,
) -> pd.DataFrame:
    """
    Aggregate raw transactions to a weekly (customer, week) panel.

    Two modes:

    - With covariate calendar (``cov_df`` provided): aggregate transactions
      to ``(merge_on, week)`` and left-join onto *cov_df* (one row per
      customer × week). Weeks with no transactions receive
      ``transaction_count = 0``.
    - Without covariates (``cov_df=None``): aggregate transactions to
      ``(merge_on, week)`` and return one row per customer × purchase-week
      with the count summed. The downstream ``build_transaction_sequences``
      will fill in zero-transaction weeks itself.

    Parameters
    ----------
    tx_df : raw transaction DataFrame (one row = one purchase).
    cov_df : optional covariate calendar DataFrame (one row per customer × week).
    merge_on : column name that identifies customers. Required.

    Returns
    -------
    DataFrame with one row per customer × week and a ``transaction_count``
    column. When *cov_df* is given, all covariate columns are preserved.
    """
    if merge_on is None:
        raise ValueError("build_transaction_panel: 'merge_on' is required.")

    tx_df = tx_df.copy()

    # When cov_df is given, coerce merge-key dtypes on both sides first so
    # the eventual join matches.
    if cov_df is not None:
        cov_df = cov_df.copy()
        tx_df[merge_on], cov_df[merge_on] = _coerce_merge_key(
            tx_df[merge_on], cov_df[merge_on]
        )

    # Detect transaction date column and ensure datetime dtype
    tx_date_col = _find_date_col(tx_df, exclude={merge_on})
    if not pd.api.types.is_datetime64_any_dtype(tx_df[tx_date_col]):
        tx_df[tx_date_col] = pd.to_datetime(tx_df[tx_date_col])

    # Mark each transaction and bucket by week
    tx_df["transaction_count"] = 1
    tx_df["_week"] = tx_df[tx_date_col].dt.to_period("W")

    tx_counts = (
        tx_df
        .groupby([merge_on, "_week"], as_index=False)["transaction_count"]
        .sum()
    )

    # No-covariate mode: return (customer, week_start_date, transaction_count)
    if cov_df is None:
        tx_counts[tx_date_col] = tx_counts["_week"].dt.start_time
        tx_counts = tx_counts.drop(columns="_week")
        return tx_counts[[merge_on, tx_date_col, "transaction_count"]]

    # Covariate mode: expand onto cov_df calendar; missing weeks → 0
    cov_date_col = _find_date_col(cov_df, exclude={merge_on})
    if not pd.api.types.is_datetime64_any_dtype(cov_df[cov_date_col]):
        cov_df[cov_date_col] = pd.to_datetime(cov_df[cov_date_col])
    cov_df["_week"] = cov_df[cov_date_col].dt.to_period("W")

    merged = cov_df.merge(tx_counts, on=[merge_on, "_week"], how="left")
    merged["transaction_count"] = merged["transaction_count"].fillna(0).astype(int)
    merged = merged.drop(columns="_week")

    return merged
