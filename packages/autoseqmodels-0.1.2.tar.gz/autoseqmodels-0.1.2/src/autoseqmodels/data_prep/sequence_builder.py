"""
Build per-customer weekly LSTM input sequences from a clean panel DataFrame.

Pipeline position:
    encoders.apply_encodings → build_transaction_sequences → SequenceDataset

Input  : a fully-numeric panel with one row per (customer, week) and a
         pre-aggregated transaction-count column.  Produced by the
         data_prep flow (load_table → build_transaction_panel →
         cast_columns_by_detected_type → apply_encodings).

Output : a dict of per-customer ndarrays ready to be wrapped by
         SequenceDataset and fed to SequenceLSTM.
"""

from __future__ import annotations

import warnings
from typing import Any, TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from .inspection import CovariatePlan

_VALID_SEASONALITY: frozenset[str] = frozenset({"woy", "moy", "dow", "year"})

_SEASONALITY_COLS: dict[str, list[str]] = {
    "woy":  ["woy_sin",  "woy_cos"],
    "moy":  ["moy_sin",  "moy_cos"],
    "dow":  ["dow_sin",  "dow_cos"],
    "year": ["year"],
}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _week_index(dates: pd.Series) -> pd.Series:
    """Ordinal week index within the year: dayofyear // 7, clipped to 0-51."""
    return (dates.dt.dayofyear // 7).clip(upper=51)


def _build_calendar(start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    """Return one row per (year, week) between start and end."""
    daily = pd.date_range(start, end, freq="D")
    cal = pd.DataFrame({"date": daily})
    cal["year"] = cal["date"].dt.year
    cal["week"] = _week_index(cal["date"])
    cal = (
        cal.groupby(["year", "week"], sort=False)
        .agg(date=("date", "min"))
        .reset_index()
        .sort_values("date")
        .reset_index(drop=True)
    )
    return cal


def _add_seasonality_to_calendar(
    cal: pd.DataFrame, features: list[str]
) -> pd.DataFrame:
    pi2 = 2.0 * np.pi
    for feat in features:
        if feat == "woy":
            cal["woy_sin"] = np.sin(pi2 * cal["week"] / 52.0)
            cal["woy_cos"] = np.cos(pi2 * cal["week"] / 52.0)
        elif feat == "moy":
            moy = cal["date"].dt.month
            cal["moy_sin"] = np.sin(pi2 * moy / 12.0)
            cal["moy_cos"] = np.cos(pi2 * moy / 12.0)
        elif feat == "dow":
            dow = cal["date"].dt.dayofweek
            cal["dow_sin"] = np.sin(pi2 * dow / 7.0)
            cal["dow_cos"] = np.cos(pi2 * dow / 7.0)
    return cal


def _propose_time_varying(
    df: pd.DataFrame,
    account_col: str,
    date_col: str,
    already_static: list[str],
) -> None:
    """Scan df for columns that vary by date_col and print a proposal."""
    reserved = {account_col, date_col}
    reserved |= set(already_static)
    candidates = [c for c in df.columns if c not in reserved]
    if not candidates:
        return

    all_accounts = df[account_col].unique()
    sample_accounts = all_accounts[: min(50, len(all_accounts))]
    sdf = df[df[account_col].isin(sample_accounts)]

    per_obs  = sdf.groupby([account_col, date_col])[candidates].nunique()
    per_cust = sdf.groupby(account_col)[candidates].nunique()

    time_varying: list[str] = []
    also_static:  list[str] = []
    ambiguous:    list[str] = []

    for col in candidates:
        if (per_obs[col] <= 1).all():
            if (per_cust[col] > 1).mean() > 0.3:
                time_varying.append(col)
            else:
                also_static.append(col)
        else:
            ambiguous.append(col)

    if not time_varying and not also_static:
        return

    sep = "─" * 62

    def _grouped_display(cols: list[str]) -> list[str]:
        from collections import defaultdict
        groups: dict[str, list[str]] = defaultdict(list)
        ungrouped: list[str] = []
        for col in cols:
            parts = col.split("_")
            prefix = parts[0] if len(parts) > 1 else ""
            same_prefix = [c for c in cols if c.startswith(prefix + "_")] if prefix else []
            if prefix and len(same_prefix) >= 3:
                groups[prefix].append(col)
            else:
                ungrouped.append(col)
        lines = []
        for prefix, group_cols in sorted(groups.items()):
            first_few = "  ".join(group_cols[:3])
            rest = f"  … +{len(group_cols) - 3} more" if len(group_cols) > 3 else ""
            lines.append(f"    {prefix}_*  ({len(group_cols)})  e.g. {first_few}{rest}")
        for col in ungrouped:
            lines.append(f"    {col}")
        return lines

    print(sep)
    print("  Time-varying covariate candidates")
    print(f"  (scanned {len(candidates)} column(s) across {len(sample_accounts)} accounts)")
    print(sep)

    if time_varying:
        print(f"  Vary across '{date_col}' → candidates for time_varying_cols:")
        for line in _grouped_display(time_varying):
            print(line)
        print()
        example = time_varying[:3]
        print(f"  Pass to build_transaction_sequences:")
        print(f"    time_varying_cols = {example!r}  # ← edit as needed")

    if also_static:
        print()
        print(f"  Appear static (same value per customer across all observation weeks):")
        for line in _grouped_display(also_static):
            print(line)
        print(f"  → consider covariate_cols instead.")

    if ambiguous:
        print()
        print(f"  Ambiguous (multiple values within a single observation week):")
        for line in _grouped_display(ambiguous):
            print(line)
        print(f"  → not suitable as covariates (likely transaction-level columns).")

    print(sep)


def _print_summary(
    seqs: dict[str, Any],
    t_start: pd.Timestamp,
    t_end: pd.Timestamp,
    h_start: pd.Timestamp,
    h_end: pd.Timestamp,
    n_training_weeks: int,
    n_holdout_weeks: int,
    n_skipped: int,
    clip_transactions: int | None,
) -> None:
    sep = "─" * 62
    print(sep)
    print("  build_transaction_sequences — summary")
    print(sep)

    print(f"  Training period : {t_start.date()} → {t_end.date()}  ({n_training_weeks} weeks)")
    print(f"  Holdout period  : {h_start.date()} → {h_end.date()}  ({n_holdout_weeks} weeks)")
    print()

    n = len(seqs["samples"])
    print(f"  Customers processed : {n}")
    if n_skipped:
        print(f"  Customers skipped   : {n_skipped}  (< 2 training weeks)")
    print(f"  Total transactions  : {seqs['total_transactions']}")
    if clip_transactions is not None:
        print(f"  Clip transactions   : {clip_transactions}")
    print()

    print(f"  Features ({seqs['n_features']}): {seqs['feature_names']}")
    print()

    if n > 0:
        train_lens = [s.shape[0] for s in seqs["samples"]]
        hold_lens  = [h.shape[0] for h in seqs["holdout"]]
        n_feat     = seqs["n_features"]
        t_minus_1  = (f"{min(train_lens)}"
                      if min(train_lens) == max(train_lens)
                      else f"[{min(train_lens)}, {max(train_lens)}]")
        t_full     = (f"{min(train_lens)+1}"
                      if min(train_lens) == max(train_lens)
                      else f"[{min(train_lens)+1}, {max(train_lens)+1}]")
        h_full     = (f"{min(hold_lens)}"
                      if min(hold_lens) == max(hold_lens)
                      else f"[{min(hold_lens)}, {max(hold_lens)}]")

        print(f"  samples[i]      shape  ({t_minus_1}, {n_feat})        T-1 = {t_minus_1}")
        print(f"  targets[i]      shape  ({t_minus_1},)            T-1 = {t_minus_1}")
        print(f"  calibration[i]  shape  ({t_full},   {n_feat})        T   = {t_full}")
        print(f"  holdout[i]      shape  ({h_full},   {n_feat})        H   = {h_full}")
        print()

        tx_idx = seqs["feature_names"].index("transactions")
        train_tx = np.concatenate([c[:, tx_idx] for c in seqs["calibration"]])
        hold_tx  = np.concatenate([h[:, tx_idx] for h in seqs["holdout"]])
        all_tx   = np.concatenate([train_tx, hold_tx])

        nonzero_train = train_tx[train_tx > 0]

        print(f"  Weekly transaction counts (training):")
        print(f"    zero-transaction weeks : {(train_tx == 0).sum():,}  "
              f"({100*(train_tx == 0).mean():.1f}%)")
        print(f"    non-zero weeks         : {len(nonzero_train):,}")
        if len(nonzero_train):
            print(f"    mean / max per week    : "
                  f"{nonzero_train.mean():.2f} / {int(nonzero_train.max())}")
        print(f"  max_trans_per_week (all periods) : {int(all_tx.max())}")

    print(sep)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def build_transaction_sequences(
    df: pd.DataFrame,
    *,
    account_col: str,
    date_col: str,
    training_start: str,
    training_end: str,
    holdout_start: str,
    holdout_end: str,
    transaction_col: str = "transaction_count",
    plan: "CovariatePlan | None" = None,
    covariate_cols: list[str] | None = None,
    time_varying_cols: list[str] | None = None,
    seasonality: list[str] | None = None,
    clip_transactions: int | None = None,
) -> dict[str, Any]:
    """
    Build weekly transaction sequences for LSTM training.

    Expects a pre-aggregated panel DataFrame — one row per (customer, week) —
    as produced by ``build_transaction_panel``.  The ``transaction_col`` column
    already holds the count of purchases for that week (0 for weeks with no
    purchase).

    Parameters
    ----------
    df : pd.DataFrame
        Weekly panel with one row per customer × week.
        Must contain account_col, date_col, and transaction_col.
    account_col : str
        Customer identifier column (e.g. "Id").
    date_col : str
        Column holding the weekly observation date.
    training_start, training_end : str
        Inclusive start/end of the calibration (training) period.
    holdout_start, holdout_end : str
        Inclusive start/end of the holdout evaluation period.
        holdout_start must be strictly after training_end.
    transaction_col : str
        Column with per-week transaction counts. Default: "transaction_count".
    plan : CovariatePlan | None
        Pre-computed covariate plan from plan_covariates().
        Fills covariate_cols and time_varying_cols when not set explicitly.
    covariate_cols : list[str] | None
        Time-invariant (static) customer attributes, e.g. ["Income", "Gender"].
    time_varying_cols : list[str] | None
        Columns whose values change week by week, aligned by date_col.
        Pass [] explicitly to suppress the automatic proposal.
    seasonality : list[str] | None
        Calendar-derived features: "woy", "moy", "dow", "year".
    clip_transactions : int | None
        Cap weekly transaction counts at this value.

    Returns
    -------
    dict with keys:
        samples            list[np.ndarray (T-1, n_features)]
        targets            list[np.ndarray (T-1,)]
        calibration        list[np.ndarray (T, n_features)]
        holdout            list[np.ndarray (H, n_features)]
        account_ids        list
        n_features         int
        feature_names      list[str]
        total_transactions int
    """
    # ------------------------------------------------------------------
    # Apply CovariatePlan
    # ------------------------------------------------------------------
    if plan is not None:
        if covariate_cols is None:
            covariate_cols = list(plan.static_cols)
        if time_varying_cols is None:
            time_varying_cols = list(plan.time_varying_cols)

        if plan.encoding_notes:
            sep = "─" * 62
            print(sep)
            print("  Covariate encoding plan")
            print(sep)
            for col, note in plan.encoding_notes.items():
                role = "static" if col in plan.static_cols else "time-varying"
                print(f"  {col:<26} ({role:<12})  →  {note}")
            print(sep)

    # ------------------------------------------------------------------
    # Validate inputs
    # ------------------------------------------------------------------
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"df must be a pandas DataFrame, got {type(df).__name__}.")

    if df.empty:
        raise ValueError("df is empty — nothing to process.")

    required_cols = [account_col, date_col, transaction_col]
    missing_cols = [c for c in required_cols if c not in df.columns]
    if missing_cols:
        raise ValueError(
            f"Column(s) not found in DataFrame: {missing_cols}. "
            f"Available columns: {list(df.columns)}"
        )

    if clip_transactions is not None and clip_transactions < 1:
        raise ValueError(f"clip_transactions must be >= 1, got {clip_transactions}.")

    # ------------------------------------------------------------------
    # Validate seasonality keys
    # ------------------------------------------------------------------
    seasonality = list(seasonality) if seasonality is not None else []
    bad_keys = [k for k in seasonality if k not in _VALID_SEASONALITY]
    if bad_keys:
        raise ValueError(
            f"Unknown seasonality key(s): {bad_keys}. "
            f"Valid keys are: {sorted(_VALID_SEASONALITY)}."
        )
    seasonality_cols: list[str] = []
    for key in seasonality:
        seasonality_cols.extend(_SEASONALITY_COLS[key])

    # ------------------------------------------------------------------
    # Parse and validate date boundaries
    # ------------------------------------------------------------------
    try:
        t_start = pd.Timestamp(training_start)
        t_end   = pd.Timestamp(training_end)
        h_start = pd.Timestamp(holdout_start)
        h_end   = pd.Timestamp(holdout_end)
    except Exception as exc:
        raise ValueError(
            f"Could not parse one of the date boundary strings: {exc}."
        ) from exc

    if t_start >= t_end:
        raise ValueError(f"training_start ({training_start}) must be before training_end ({training_end}).")
    if h_start > h_end:
        raise ValueError(f"holdout_start ({holdout_start}) must be before or equal to holdout_end ({holdout_end}).")
    if h_start <= t_end:
        raise ValueError(
            f"holdout_start ({holdout_start}) must be strictly after training_end ({training_end}). "
            f"There is a {(h_start - t_end).days}-day overlap."
        )

    # ------------------------------------------------------------------
    # Validate time-varying covariate parameters
    # ------------------------------------------------------------------
    time_varying_cols = list(time_varying_cols) if time_varying_cols is not None else None

    if time_varying_cols is not None and len(time_varying_cols) > 0:
        reserved_tv = {account_col, date_col, transaction_col}
        bad_tv = [c for c in time_varying_cols if c in reserved_tv]
        if bad_tv:
            raise ValueError(
                f"time_varying_cols contains reserved column(s) {bad_tv}."
            )
        missing_tv = [c for c in time_varying_cols if c not in df.columns]
        if missing_tv:
            raise ValueError(
                f"time_varying_cols not found in df: {missing_tv}. "
                f"Available columns: {list(df.columns)}"
            )

    # ------------------------------------------------------------------
    # Validate static covariate columns
    # ------------------------------------------------------------------
    covariate_cols = list(covariate_cols or [])
    if covariate_cols:
        reserved = {account_col, date_col, transaction_col}
        bad = [c for c in covariate_cols if c in reserved]
        if bad:
            raise ValueError(f"covariate_cols contains reserved column(s) {bad}.")
        missing = [c for c in covariate_cols if c not in df.columns]
        if missing:
            raise ValueError(
                f"covariate_cols not found in DataFrame: {missing}. "
                f"Available columns: {list(df.columns)}"
            )
        overlap = set(covariate_cols) & set(time_varying_cols or [])
        if overlap:
            raise ValueError(
                f"Column(s) appear in both covariate_cols and time_varying_cols: {sorted(overlap)}."
            )
        for col in covariate_cols:
            varying = df.groupby(account_col)[col].nunique()
            if (varying > 1).any():
                warnings.warn(
                    f"Covariate '{col}' has multiple distinct values for "
                    f"{(varying > 1).sum()} customer(s). "
                    "Only the first observed value per customer is used.",
                    UserWarning,
                    stacklevel=2,
                )

    # ------------------------------------------------------------------
    # Precompute year/week from date_col
    # ------------------------------------------------------------------
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
    df["_year"] = df[date_col].dt.year
    df["_week"] = _week_index(df[date_col])

    # Check that the date column covers the training period
    valid_dates = df[date_col].dropna()
    in_training = valid_dates.between(t_start, t_end)
    if not in_training.any():
        raise ValueError(
            f"No rows found between training_start={training_start} and "
            f"training_end={training_end}. "
            f"date_col range: {valid_dates.min().date()} → {valid_dates.max().date()}."
        )

    if not valid_dates.between(h_start, h_end).any():
        warnings.warn(
            f"No rows fall in the holdout period ({holdout_start} → {holdout_end}). "
            "Holdout sequences will contain only zero-transaction weeks.",
            UserWarning,
            stacklevel=2,
        )

    total_transactions = int(df[transaction_col].sum())

    # ------------------------------------------------------------------
    # Propose time-varying covariates when not yet chosen
    # ------------------------------------------------------------------
    if time_varying_cols is None:
        _propose_time_varying(
            df,
            account_col=account_col,
            date_col=date_col,
            already_static=covariate_cols,
        )
        time_varying_cols = []

    time_varying_cols = time_varying_cols or []

    # ------------------------------------------------------------------
    # Build universal weekly calendar
    # ------------------------------------------------------------------
    calendar = _build_calendar(t_start, h_end)
    if seasonality:
        calendar = _add_seasonality_to_calendar(calendar, seasonality)
    n_training_weeks = int((calendar["date"] < h_start).sum())
    n_holdout_weeks  = int((calendar["date"] >= h_start).sum())

    if n_training_weeks < 2:
        raise ValueError(
            f"Training period spans only {n_training_weeks} week(s). At least 2 needed."
        )

    # ------------------------------------------------------------------
    # Build static covariate lookup
    # ------------------------------------------------------------------
    cov_lookup: dict[Any, dict[str, float]] = {}
    if covariate_cols:
        cov_frame = df[[account_col] + covariate_cols].groupby(account_col).first()
        cov_lookup = cov_frame.to_dict(orient="index")

    # ------------------------------------------------------------------
    # Build time-varying covariate lookup  {account → DataFrame(year, week, cols)}
    # ------------------------------------------------------------------
    tv_by_account: dict[Any, pd.DataFrame] = {}
    if time_varying_cols:
        tv_raw = df[[account_col, "_year", "_week"] + time_varying_cols].copy()
        tv_raw = tv_raw.rename(columns={"_year": "year", "_week": "week"})
        tv_raw = (
            tv_raw.groupby([account_col, "year", "week"])[time_varying_cols]
            .first()
            .reset_index()
        )
        for account, group in tv_raw.groupby(account_col):
            tv_by_account[account] = group[["year", "week"] + time_varying_cols].reset_index(drop=True)

    feature_names = ["week"] + seasonality_cols + time_varying_cols + covariate_cols + ["transactions"]

    # ------------------------------------------------------------------
    # Build one sequence per customer
    # ------------------------------------------------------------------
    samples, targets, calibration, holdout_seqs, account_ids = [], [], [], [], []
    n_skipped = 0
    accounts  = df[account_col].unique()

    for account in accounts:
        user_df = df[df[account_col] == account]

        tx_counts = (
            user_df[["_year", "_week", transaction_col]]
            .rename(columns={"_year": "year", "_week": "week", transaction_col: "transactions"})
        )

        frame = calendar.copy()
        frame = frame.merge(tx_counts, on=["year", "week"], how="left")
        frame["transactions"] = frame["transactions"].fillna(0).astype(int)

        if clip_transactions is not None:
            frame["transactions"] = frame["transactions"].clip(upper=clip_transactions)

        # Time-varying covariates
        if time_varying_cols:
            user_tv = tv_by_account.get(account)
            if user_tv is not None:
                frame = frame.merge(user_tv, on=["year", "week"], how="left")
            else:
                for col in time_varying_cols:
                    frame[col] = float("nan")
            frame[time_varying_cols] = frame[time_varying_cols].ffill().fillna(0.0)

        # Static covariates
        for col in covariate_cols:
            val = cov_lookup.get(account, {}).get(col, 0.0)
            try:
                frame[col] = float(val)
            except (TypeError, ValueError):
                frame[col] = 0.0

        frame = frame[["week"] + seasonality_cols + time_varying_cols + covariate_cols + ["transactions"]].astype(float)

        training_frame = frame.iloc[:n_training_weeks]
        holdout_frame  = frame.iloc[n_training_weeks:]

        if len(training_frame) < 2:
            n_skipped += 1
            continue

        calibration.append(training_frame.values)
        samples.append(training_frame.iloc[:-1].values)
        targets.append(training_frame["transactions"].iloc[1:].values)
        holdout_seqs.append(holdout_frame.values)
        account_ids.append(account)

    if len(samples) == 0:
        raise ValueError(
            "No customer sequences were built. All customers were skipped "
            f"(fewer than 2 training weeks). Training period may be too short: "
            f"{training_start} → {training_end} ({n_training_weeks} weeks)."
        )

    result = {
        "samples":            samples,
        "targets":            targets,
        "calibration":        calibration,
        "holdout":            holdout_seqs,
        "account_ids":        account_ids,
        "n_features":         len(feature_names),
        "feature_names":      feature_names,
        "total_transactions": total_transactions,
    }

    _print_summary(
        result, t_start, t_end, h_start, h_end,
        n_training_weeks, n_holdout_weeks, n_skipped, clip_transactions,
    )

    return result
