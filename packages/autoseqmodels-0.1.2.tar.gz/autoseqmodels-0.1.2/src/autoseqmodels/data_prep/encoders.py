# Encoding utilities for preparing DataFrame columns for PyTorch LSTM / Transformer models.
#
# Every timestep in a sequence model receives one flat numeric vector. This module
# decides how each column contributes to that vector and returns:
#   1. A transformed DataFrame where every column is numeric (integer label codes
#      for embeddings, scaled floats for numerics, 0/1 for booleans, one-hot
#      expanded columns for low-cardinality categoricals).
#   2. An EncodingSpec dataclass that tells the PyTorch model exactly how to build
#      its nn.Embedding layers and how wide the resulting input vector will be.
#
# Decision logic (automatic, overridable per column):
#   - id          → EMBED   (entity embedding; strongest signal in CLV models)
#   - binary      → PASSTHROUGH as float
#   - int / float → SCALE   (StandardScaler by default, MinMax optional)
#   - temporal    → caller should run Sesonality.add_seasonality_features() first;
#                   the resulting integer columns are then scaled here
#   (- Using Bert-Sort for ordinal categoricals)(not implemented yet)
#   - category, n_unique ≤ embed_threshold  → ONE-HOT
#   - category, n_unique >  embed_threshold → EMBED
#   - text        → WARN + DROP (requires a separate NLP pipeline)
#
# Embedding dimension follows the Guo & Berkhahn rule used by fast.ai:
#   embed_dim = min(max_embed_dim, max(2, (n_unique + 1) // 2))
#
# Public API:
#   EncodingSpec    – dataclass holding the full encoding metadata
#   prepare_encodings(df, detected, ...)  – main entry point

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Literal

import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler

from autoseqmodels.data_prep.inspection import (
    CovariatePlan,
    infer_column_types,
    _check_df,
    _check_detected,
)


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class EmbeddingInfo:
    """Metadata for a single embedding column."""
    n_unique: int
    embed_dim: int
    vocab: dict[str, int]       # original value → integer label code


@dataclass
class ScalerInfo:
    """Stored scaler parameters for a single numeric column."""
    mean: float | None          # None when using MinMax
    std: float | None
    min_val: float | None       # None when using Standard
    max_val: float | None


@dataclass
class EncodingSpec:
    """
    Full encoding specification produced by prepare_encodings().

    Feed this to your PyTorch model __init__ to build nn.Embedding layers
    and to know the total input width at each timestep.

    Attributes
    ----------
    embeddings : dict[col_name → EmbeddingInfo]
        Columns encoded as integer label codes. Build one nn.Embedding per entry.
    onehot : dict[col_name → list[category_values]]
        Low-cardinality categoricals expanded to one-hot. The DataFrame already
        contains the expanded boolean columns; this records the original column
        and its category order.
    scaled : dict[col_name → ScalerInfo]
        Numeric columns that were standardised or min-max scaled.
    passthrough : list[col_name]
        Boolean/binary columns left as 0.0 / 1.0 floats.
    dropped : list[col_name]
        Columns removed (text or explicit drop overrides).
    input_width : int
        Total number of numeric values per timestep after encoding.
        = sum of embed_dims + onehot widths + len(scaled) + len(passthrough)
    """
    embeddings: dict[str, EmbeddingInfo] = field(default_factory=dict)
    onehot: dict[str, list] = field(default_factory=dict)
    scaled: dict[str, ScalerInfo] = field(default_factory=dict)
    ordinal: dict[str, list] = field(default_factory=dict)   # col → ordered category list
    binary: dict[str, list] = field(default_factory=dict)    # col → [zero_value, one_value]
    passthrough: list[str] = field(default_factory=list)
    dropped: list[str] = field(default_factory=list)
    input_width: int = 0


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _embed_dim(n_unique: int, max_embed_dim: int) -> int:
    """Guo & Berkhahn embedding dimension heuristic."""
    return min(max_embed_dim, max(2, (n_unique + 1) // 2))


def _build_vocab(series: pd.Series) -> dict[str, int]:
    """Map each unique non-null value to a contiguous integer code (1-based; 0 = unknown)."""
    unique_vals = sorted(series.dropna().astype(str).unique())
    return {v: i + 1 for i, v in enumerate(unique_vals)}


def _apply_vocab(series: pd.Series, vocab: dict[str, int]) -> pd.Series:
    """Replace values with their integer codes; unknowns and nulls → 0."""
    return series.astype(str).map(vocab).fillna(0).astype(int)


def _scale_series(
    series: pd.Series,
    method: Literal["standard", "minmax"],
) -> tuple[pd.Series, ScalerInfo]:
    """Fit a scaler on series and return the scaled values alongside a ScalerInfo for later inversion."""
    values = series.values.reshape(-1, 1)
    if method == "standard":
        scaler = StandardScaler()
        scaled = scaler.fit_transform(values).flatten()
        info = ScalerInfo(
            mean=float(scaler.mean_[0]),
            std=float(scaler.scale_[0]),
            min_val=None,
            max_val=None,
        )
    else:
        scaler = MinMaxScaler()
        scaled = scaler.fit_transform(values).flatten()
        info = ScalerInfo(
            mean=None,
            std=None,
            min_val=float(scaler.data_min_[0]),
            max_val=float(scaler.data_max_[0]),
        )
    return pd.Series(scaled, index=series.index, name=series.name), info


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

Override = Literal["embed", "onehot", "ordinal", "binary", "scale", "passthrough", "drop"]


def _decide_strategy(row: dict, embed_threshold: int, col: str) -> Override:
    """Pure function: pick a default encoding strategy from a detected row."""
    stat_type: str = row["statistical_type"]
    refined: str  = row["refined_type"]
    n_unique: int = int(row["n_unique"])

    if stat_type == "identifier":
        return "embed"
    if stat_type == "binary":
        return "binary"
    if col.endswith("_sin") or col.endswith("_cos"):
        # Cyclical features from add_seasonality_features() are already in [-1, 1].
        return "passthrough"
    if stat_type in {"continuous", "discrete"} and refined in {"int", "float"}:
        return "scale"
    if stat_type == "categorical":
        return "onehot" if n_unique <= embed_threshold else "embed"
    if stat_type == "temporal":
        return "scale"
    if stat_type == "text":
        return "drop"
    return "scale"


def propose_encodings(
    df: pd.DataFrame,
    detected: pd.DataFrame,
    plan: CovariatePlan | None = None,
    *,
    embed_threshold: int = 10,
    verbose: bool = True,
) -> dict[str, Override]:
    """
    Decide an encoding strategy per column and return it as an editable dict.

    The user reviews the dict, optionally overrides any entries, then passes
    it to apply_encodings(df, encoding_plan, train_mask=...).

    Parameters
    ----------
    df, detected
        DataFrame and the matching infer_column_types() output.
    plan
        Optional CovariatePlan.  Columns in plan.skip_cols are excluded from
        the returned dict (they are not features).
    embed_threshold
        Categoricals with n_unique > embed_threshold are embedded; otherwise
        one-hot.  Default 10.

    Returns
    -------
    dict[col → strategy]  with strategy in
    {"embed", "onehot", "scale", "passthrough", "drop"}.
    """
    _check_df(df, "propose_encodings")
    _check_detected(detected, "propose_encodings")

    skip = set(plan.skip_cols) if plan is not None else set()
    type_map = {row["column"]: row for row in detected.to_dict(orient="records")}

    encoding_plan: dict[str, Override] = {}
    for col in df.columns:
        if col in skip or col not in type_map:
            continue
        encoding_plan[col] = _decide_strategy(type_map[col], embed_threshold, col)

    if verbose:
        sep = "─" * 62
        print(sep)
        print("  propose_encodings — proposed strategy per column")
        print(sep)
        print(f"  {'Column':<24}  {'Strategy':<12}  Reason")
        print(sep)
        for col, strategy in encoding_plan.items():
            row = type_map[col]
            reason = f"{row['statistical_type']}, n_unique={int(row['n_unique'])}"
            print(f"  {col:<24}  {strategy:<12}  {reason}")
        print(sep)
        print()
        print("  To override before applying:")
        print('    encoding_plan["<col>"] = "embed"   # or "onehot", "ordinal", "binary", "scale", "passthrough", "drop"')
        print()
        print("  Strategies: embed  onehot  ordinal  binary  scale  passthrough  drop")
        print()
        print("  Note: 'ordinal' is never auto-proposed (data alone cannot tell whether")
        print("  categories have a meaningful order).  Set it manually for ordered")
        print("  categoricals like ratings, sizes, satisfaction levels, etc.")
        print(sep)

    return encoding_plan


def apply_encodings(
    df: pd.DataFrame,
    encoding_plan: dict[str, Override],
    *,
    train_mask: "pd.Series | None" = None,
    max_embed_dim: int = 50,
    scale_method: Literal["standard", "minmax"] = "standard",
) -> tuple[pd.DataFrame, EncodingSpec]:
    """
    Apply a user-edited encoding plan to df.

    Learned encoders (StandardScaler, embed vocabs, one-hot categories) are
    fit on training rows only when train_mask is provided, then applied to
    every row.  This prevents leaking holdout-period statistics into the
    encoders.

    Parameters
    ----------
    df
        Input DataFrame.  Not modified in place.
    encoding_plan
        Dict produced by propose_encodings(), optionally edited.
    train_mask
        Boolean Series aligned to df.index.  True = training row.
        None → fit encoders on the whole DataFrame (no leakage protection).
    max_embed_dim
        Upper cap on embedding dimension.
    scale_method
        "standard" or "minmax".

    Returns
    -------
    (df_enc, EncodingSpec)
    """
    _check_df(df, "apply_encodings")

    valid = {"embed", "onehot", "ordinal", "binary", "scale", "passthrough", "drop"}
    bad = {a for a in encoding_plan.values() if a not in valid}
    if bad:
        raise ValueError(
            f"Unknown encoding strategies: {sorted(bad)}.  Valid: {sorted(valid)}."
        )

    if train_mask is None:
        fit_idx = df.index
    else:
        if len(train_mask) != len(df):
            raise ValueError(
                f"train_mask length ({len(train_mask)}) must match df length ({len(df)})."
            )
        fit_idx = df.index[train_mask.values]
        if len(fit_idx) == 0:
            raise ValueError("train_mask selected zero rows — nothing to fit on.")

    out = df.copy()
    spec = EncodingSpec()

    for col, strategy in encoding_plan.items():
        if col not in out.columns:
            continue

        if strategy == "drop":
            out = out.drop(columns=[col])
            spec.dropped.append(col)

        elif strategy == "passthrough":
            out[col] = pd.to_numeric(out[col], errors="coerce").fillna(0).astype(float)
            spec.passthrough.append(col)

        elif strategy == "binary":
            # Two cases:
            #   (a) column is already numeric (0/1, True/False)  → cast to float
            #   (b) column has 2 string values (M/F, yes/no, …) → map to 0/1
            numeric = pd.to_numeric(out[col], errors="coerce")
            if numeric.notna().all():
                out[col] = numeric.astype(float)
                vals = sorted(numeric.dropna().unique().tolist())
                spec.binary[col] = [v for v in vals]   # record the two values seen
            else:
                train_vals = sorted(
                    str(v) for v in out.loc[fit_idx, col].dropna().unique()
                )
                if len(train_vals) > 2:
                    raise ValueError(
                        f"Column '{col}' marked as 'binary' has {len(train_vals)} "
                        f"unique values in training rows ({train_vals}); "
                        "binary requires at most 2.  Use 'onehot' or 'embed' instead."
                    )
                # First training value → 0, second → 1.  Unknowns at apply time → 0.
                if len(train_vals) == 2:
                    out[col] = (out[col].astype(str) == train_vals[1]).astype(float)
                elif len(train_vals) == 1:
                    out[col] = (out[col].astype(str) == train_vals[0]).astype(float)
                else:
                    out[col] = 0.0
                spec.binary[col] = list(train_vals)

        elif strategy == "scale":
            numeric = pd.to_numeric(out[col], errors="coerce")
            train_numeric = numeric.loc[fit_idx]
            col_median = train_numeric.median()
            if pd.isna(col_median):
                warnings.warn(
                    f"Column '{col}' is all-null on training rows after numeric "
                    "coercion and will be filled with 0.",
                    UserWarning, stacklevel=2,
                )
                col_median = 0.0
            numeric = numeric.fillna(col_median)
            if numeric.loc[fit_idx].std() == 0:
                warnings.warn(
                    f"Column '{col}' has zero variance on training rows. "
                    "Scaling will produce all-zero values.",
                    UserWarning, stacklevel=2,
                )

            train_arr = numeric.loc[fit_idx].values.reshape(-1, 1)
            if scale_method == "standard":
                scaler = StandardScaler().fit(train_arr)
                info = ScalerInfo(
                    mean=float(scaler.mean_[0]), std=float(scaler.scale_[0]),
                    min_val=None, max_val=None,
                )
            else:
                scaler = MinMaxScaler().fit(train_arr)
                info = ScalerInfo(
                    mean=None, std=None,
                    min_val=float(scaler.data_min_[0]),
                    max_val=float(scaler.data_max_[0]),
                )
            scaled = scaler.transform(numeric.values.reshape(-1, 1)).flatten()
            out[col] = pd.Series(scaled, index=numeric.index, name=col)
            spec.scaled[col] = info

        elif strategy == "embed":
            vocab = _build_vocab(out.loc[fit_idx, col])
            out[col] = _apply_vocab(out[col], vocab)
            n_unique = len(vocab)
            spec.embeddings[col] = EmbeddingInfo(
                n_unique=n_unique,
                embed_dim=_embed_dim(n_unique, max_embed_dim),
                vocab=vocab,
            )

        elif strategy == "onehot":
            train_cats = sorted(
                str(v) for v in out.loc[fit_idx, col].dropna().unique()
            )
            str_col = out[col].astype(str)
            new_cols = {f"{col}_{cat}": (str_col == cat) for cat in train_cats}
            dummies = pd.DataFrame(new_cols, index=out.index)
            out = pd.concat([out.drop(columns=[col]), dummies], axis=1)
            spec.onehot[col] = train_cats

        elif strategy == "ordinal":
            s = out[col]
            # Use the explicit category order if the column is an ordered Categorical;
            # otherwise fall back to sorted-alphabetic and warn the user.
            if isinstance(s.dtype, pd.CategoricalDtype) and s.cat.ordered:
                order = list(s.cat.categories)
            else:
                order = sorted(
                    str(v) for v in out.loc[fit_idx, col].dropna().unique()
                )
                warnings.warn(
                    f"Column '{col}' marked as ordinal but is not an ordered "
                    f"Categorical.  Using alphabetic order: {order}.\n"
                    f"  Set the order explicitly to control encoding:\n"
                    f"    df['{col}'] = pd.Categorical(df['{col}'], "
                    f"categories=['low', 'medium', 'high'], ordered=True)",
                    UserWarning, stacklevel=2,
                )
            mapping = {v: i + 1 for i, v in enumerate(order)}   # 0 reserved for unknown/null
            out[col] = out[col].astype(str).map(mapping).fillna(0).astype(int)
            spec.ordinal[col] = order

    embed_width  = sum(info.embed_dim for info in spec.embeddings.values())
    onehot_width = sum(len(cats) for cats in spec.onehot.values())
    spec.input_width = (
        embed_width + onehot_width
        + len(spec.scaled) + len(spec.ordinal)
        + len(spec.binary) + len(spec.passthrough)
    )

    return out, spec


def expand_plan(plan: CovariatePlan, spec: EncodingSpec) -> CovariatePlan:
    """
    Rewrite plan.static_cols / plan.time_varying_cols using the column names
    produced by apply_encodings.

    After one-hot encoding, "Gender" no longer exists in the DataFrame —
    it has been replaced by "Gender_M" and "Gender_F".  Sequence builders
    need the expanded names.  Columns dropped during encoding are removed
    from the plan entirely.
    """
    def expand(cols: list[str]) -> list[str]:
        result: list[str] = []
        for c in cols:
            if c in spec.onehot:
                result.extend(f"{c}_{cat}" for cat in spec.onehot[c])
            elif c in spec.dropped:
                continue
            else:
                result.append(c)
        return result

    return CovariatePlan(
        static_cols=expand(plan.static_cols),
        time_varying_cols=expand(plan.time_varying_cols),
        covariate_date_col=plan.covariate_date_col,
        skip_cols=list(plan.skip_cols),
        encoding_notes=dict(plan.encoding_notes),
    )


def prepare_encodings(
    df: pd.DataFrame,
    detected: pd.DataFrame | None = None,
    *,
    embed_threshold: int = 10,
    max_embed_dim: int = 50,
    scale_method: Literal["standard", "minmax"] = "standard",
    overrides: dict[str, Override] | None = None,
    train_mask: "pd.Series | None" = None,
) -> tuple[pd.DataFrame, EncodingSpec]:
    """
    One-shot encoder: propose_encodings() + apply_encodings() in a single call.

    For interactive use where you want to review and edit the proposed
    strategy, call propose_encodings() and apply_encodings() separately.
    """
    _check_df(df, "prepare_encodings")
    if detected is None:
        detected = infer_column_types(df)
    else:
        _check_detected(detected, "prepare_encodings")
        detected_cols = set(detected["column"])
        df_cols = set(df.columns)
        only_in_detected = detected_cols - df_cols
        only_in_df = df_cols - detected_cols
        if only_in_detected:
            warnings.warn(
                f"prepare_encodings(): 'detected' references column(s) "
                f"{sorted(only_in_detected)} that are NOT in df and will be ignored.\n"
                "  → Re-run infer_column_types(df) if df has changed since detected was built.",
                UserWarning, stacklevel=2,
            )
        if only_in_df:
            warnings.warn(
                f"prepare_encodings(): df contains column(s) {sorted(only_in_df)} "
                "that are NOT in 'detected' and will be passed through unchanged.\n"
                "  → Re-run infer_column_types(df) to include them.",
                UserWarning, stacklevel=2,
            )

    encoding_plan = propose_encodings(
        df, detected, embed_threshold=embed_threshold, verbose=False,
    )
    if overrides:
        encoding_plan.update(overrides)

    return apply_encodings(
        df, encoding_plan,
        train_mask=train_mask,
        max_embed_dim=max_embed_dim,
        scale_method=scale_method,
    )


# ---------------------------------------------------------------------------
# Encoding report
# ---------------------------------------------------------------------------

def encoding_report(spec: EncodingSpec) -> pd.DataFrame:
    """
    Build a human-readable summary table of what prepare_encodings() did.

    Returns one row per original column showing: the strategy applied, the
    output column name(s), and the key parameters used.

    Parameters
    ----------
    spec : EncodingSpec
        The second return value of prepare_encodings().

    Returns
    -------
    pd.DataFrame with columns:
        original_col  – name of the input column
        strategy      – embed / onehot / scale / passthrough / drop
        output_cols   – resulting column name(s) in the encoded DataFrame
        details       – key parameters (embed_dim, mean/std, categories, …)

    Example
    -------
    >>> enc_df, spec = prepare_encodings(df, detected)
    >>> encoding_report(spec)
    """
    if not isinstance(spec, EncodingSpec):
        raise TypeError(
            f"encoding_report() expects an EncodingSpec returned by prepare_encodings(), "
            f"got {type(spec).__name__!r}.\n"
            "  → Call prepare_encodings(df, detected) first and pass its second return value here."
        )
    rows = []

    for col, info in spec.embeddings.items():
        rows.append({
            "original_col": col,
            "strategy":     "embed",
            "output_cols":  col,
            "details":      f"n_unique={info.n_unique},  embed_dim={info.embed_dim}",
        })

    for col, cats in spec.onehot.items():
        dummy_names = ",  ".join(f"{col}_{c}" for c in cats)
        rows.append({
            "original_col": col,
            "strategy":     "onehot",
            "output_cols":  dummy_names,
            "details":      f"n_categories={len(cats)}  →  {',  '.join(str(c) for c in cats)}",
        })

    for col, info in spec.scaled.items():
        if info.mean is not None:
            detail = f"StandardScaler  mean={info.mean:.3f},  std={info.std:.3f}"
        else:
            detail = f"MinMaxScaler  min={info.min_val:.3f},  max={info.max_val:.3f}"
        rows.append({
            "original_col": col,
            "strategy":     "scale",
            "output_cols":  col,
            "details":      detail,
        })

    for col, order in spec.ordinal.items():
        rows.append({
            "original_col": col,
            "strategy":     "ordinal",
            "output_cols":  col,
            "details":      f"order={order}  (0 reserved for unknown/null)",
        })

    for col, vals in spec.binary.items():
        if len(vals) == 2:
            detail = f"{vals[0]} → 0,  {vals[1]} → 1"
        elif len(vals) == 1:
            detail = f"only one value seen ({vals[0]} → 1)"
        else:
            detail = "no values seen → all 0"
        rows.append({
            "original_col": col,
            "strategy":     "binary",
            "output_cols":  col,
            "details":      detail,
        })

    for col in spec.passthrough:
        rows.append({
            "original_col": col,
            "strategy":     "passthrough",
            "output_cols":  col,
            "details":      "kept as 0.0 / 1.0 float",
        })

    for col in spec.dropped:
        rows.append({
            "original_col": col,
            "strategy":     "drop",
            "output_cols":  "—",
            "details":      "removed (text column)",
        })

    report = pd.DataFrame(rows, columns=["original_col", "strategy", "output_cols", "details"])

    # summary footer row
    footer = pd.DataFrame([{
        "original_col": f"TOTAL  ({len(report)} columns)",
        "strategy":     "",
        "output_cols":  f"input_width = {spec.input_width}",
        "details":      (
            f"{len(spec.embeddings)} embedded,  "
            f"{len(spec.onehot)} one-hot,  "
            f"{len(spec.ordinal)} ordinal,  "
            f"{len(spec.binary)} binary,  "
            f"{len(spec.scaled)} scaled,  "
            f"{len(spec.passthrough)} passthrough,  "
            f"{len(spec.dropped)} dropped"
        ),
    }])

    return pd.concat([report, footer], ignore_index=True)
