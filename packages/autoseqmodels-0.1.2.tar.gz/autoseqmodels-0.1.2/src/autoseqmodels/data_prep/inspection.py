# Data inspection utilities for DataFrame column analysis.
#
# Public API:
# - TypeDetectionConfig           : thresholds controlling automatic type detection
# - DETECTED_COLS                 : column names produced by infer_column_types()
# - infer_column_types            : inspect every column → typed summary DataFrame
# - cast_columns_by_detected_type : cast columns to the dtypes inferred above
# - DataStructure                 : proposed column roles returned by propose_structure()
# - CovariatePlan                 : covariate assignment returned by plan_covariates()
# - propose_structure             : propose entity / date roles from detected types
# - classify_time_variance        : label columns as time-invariant or time-variant
# - plan_covariates               : assign every column a modelling role
#
# Internal helpers (_looks_like_*, _detect_*, _check_*) implement Auto-Prep-
# inspired heuristics and shared input validation.

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Union
import pandas as pd


# ---------------------------------------------------------------------------
# Public constants
# ---------------------------------------------------------------------------

DETECTED_COLS: frozenset[str] = frozenset({
    "column", "pandas_dtype", "basic_type", "refined_type",
    "statistical_type", "n_non_null", "n_unique",
})


# ---------------------------------------------------------------------------
# Configuration dataclass
# ---------------------------------------------------------------------------

@dataclass
class TypeDetectionConfig:
    """Thresholds and options that control automatic type detection."""
    category_unique_threshold: int = 20   # Need to be discussed in limitations
    category_ratio_threshold: float = 0.05
    date_dayfirst: bool = False
    sample_non_null: int | None = 2000
    id_unique_min: int = 50               # reserved; name-based detection does not use this


# ---------------------------------------------------------------------------
# Shared validation helpers
# ---------------------------------------------------------------------------

def _check_df(df: Any, caller: str) -> None:
    """Raise TypeError or ValueError if df is not a non-empty pandas DataFrame."""
    if not isinstance(df, pd.DataFrame):
        raise TypeError(
            f"{caller}: expected a pandas DataFrame, got {type(df).__name__}."
        )
    if df.empty:
        raise ValueError(f"{caller}: df is empty — nothing to process.")


def _check_detected(detected: Any, caller: str) -> None:
    """Raise if detected is not the DataFrame returned by infer_column_types()."""
    if not isinstance(detected, pd.DataFrame):
        raise TypeError(
            f"{caller}: detected must be the DataFrame returned by infer_column_types(), "
            f"got {type(detected).__name__}."
        )
    missing = DETECTED_COLS - set(detected.columns)
    if missing:
        raise ValueError(
            f"{caller}: detected is missing required column(s) {sorted(missing)}. "
            f"Pass the DataFrame returned by infer_column_types(). "
            f"Expected columns include: {sorted(DETECTED_COLS)}."
        )


# ---------------------------------------------------------------------------
# Type-detection helpers
# ---------------------------------------------------------------------------

def _sample_non_null(series: pd.Series, n: int | None) -> pd.Series:
    """Return up to n non-null values from a Series for type-detection probing."""
    s = series.dropna()
    if n is not None and len(s) > n:
        return s.iloc[:n]
    return s


def _all_strings_short_enough(s: pd.Series, max_len: int) -> bool:
    """Return True if every value in s has at most max_len characters."""
    return s.astype(str).str.len().le(max_len).all()


def _contains_any_date_sep(s: pd.Series) -> bool:
    """Return True if every value contains '-' or '/', as expected in date strings."""
    x = s.astype(str)
    return x.str.contains(r"[-/]").all()


def _contains_time_sep(s: pd.Series) -> bool:
    """Return True if every value contains ':', as expected in time strings."""
    x = s.astype(str)
    return x.str.contains(":").all()


def _all_strings_short_for_time(s: pd.Series, max_len: int = 8) -> bool:
    """Return True if every value is short enough to be a hh:mm or hh:mm:ss string."""
    return s.astype(str).str.len().le(max_len).all()


_BOOL_PAIRS: frozenset[frozenset[str]] = frozenset({
    frozenset({"true", "false"}),
    frozenset({"yes", "no"}),
    frozenset({"1", "0"}),
    frozenset({"y", "n"}),
})


def _looks_like_bool(s: pd.Series) -> bool:
    """Return True if the column's distinct values match a known boolean vocabulary pair."""
    distinct = frozenset(s.dropna().astype(str).str.strip().str.lower().unique())
    return distinct in _BOOL_PAIRS


def _looks_like_date(s: pd.Series, dayfirst: bool = False) -> bool:
    """
    Return True if all values parse as dates.

    Auto-Prep-inspired rule:
    - entries up to 10 characters
    - contain '-' or '/'
    then attempt datetime conversion.
    """
    s = s.dropna().astype(str).str.strip()
    if s.empty:
        return False

    if not _all_strings_short_enough(s, 10):
        return False

    if not _contains_any_date_sep(s):
        return False

    parsed = pd.to_datetime(s, errors="coerce", dayfirst=dayfirst)
    return parsed.notna().all()


def _looks_like_time(s: pd.Series) -> bool:
    """
    Return True if all values parse as time-of-day strings.

    Auto-Prep-inspired rule:
    - contains ':'
    - length <= 8
    """
    s = s.dropna().astype(str).str.strip()
    if s.empty:
        return False

    if not _contains_time_sep(s):
        return False

    if not _all_strings_short_for_time(s, 8):
        return False

    # Simple parsing check via timedelta, robust for hh:mm or hh:mm:ss
    parsed = pd.to_timedelta(s, errors="coerce")
    return parsed.notna().all()


_ID_KEYWORDS: frozenset[str] = frozenset({
    "id", "identifier", "identifiant",
    "customer", "client", "user", "account",
    "member", "subscriber", "contact",
    "order", "transaction", "invoice", "ticket",
    "sku", "product", "item",
    "uuid", "guid", "key", "code", "ref", "reference",
})


def _looks_like_id(col_name: str) -> bool:
    """Return True if the column name contains a known identifier keyword."""
    name = col_name.lower().replace("-", "_").replace(" ", "_")
    parts = set(name.split("_"))
    return bool(parts & _ID_KEYWORDS)


def _looks_like_category(
    s: pd.Series,
    unique_threshold: int,
    ratio_threshold: float,
) -> bool:
    """
    Return True if the column looks like a finite set of label values.

    A column qualifies when the number of unique values is below
    unique_threshold, or when the unique-to-total ratio is below
    ratio_threshold — whichever fires first.
    """
    s = s.dropna().astype(str).str.strip()
    if s.empty:
        return False

    n_unique = s.nunique(dropna=True)
    n_total = len(s)
    ratio = n_unique / max(n_total, 1)

    return (n_unique <= unique_threshold) or (ratio <= ratio_threshold)


def _detect_object_subtype(
    series: pd.Series,
    config: TypeDetectionConfig,
) -> str:
    """
    Refine an object-dtype column into one of: bool, date, time, category, string.

    Priority order follows Auto-Prep:
    bool -> date -> time -> category -> string/object
    """
    s = _sample_non_null(series, config.sample_non_null)

    if s.dropna().empty:
        return "string"

    if _looks_like_bool(s):
        return "bool"

    if _looks_like_date(s, dayfirst=config.date_dayfirst):
        return "date"

    if _looks_like_time(s):
        return "time"

    if _looks_like_category(
        s,
        unique_threshold=config.category_unique_threshold,
        ratio_threshold=config.category_ratio_threshold,
    ):
        return "category"

    return "string"


def _detect_numeric_statistical_type(series: pd.Series) -> str:
    """
    Classify a numeric column as binary, discrete, or continuous.

    Two-valued columns (int or float) → binary.
    Integer columns with 3+ unique values → discrete.
    Float columns: few unique values → discrete; otherwise → continuous.
    """
    s = series.dropna()
    if s.empty:
        return "continuous"

    n_unique = s.nunique(dropna=True)

    # Two-valued check fires before integer-dtype check so binary 0/1 integer
    # columns are not silently promoted to "discrete".
    if n_unique == 2:
        return "binary"

    if pd.api.types.is_integer_dtype(s):
        return "discrete"

    if n_unique <= 20:
        return "discrete"

    return "continuous"


# ---------------------------------------------------------------------------
# Core public functions
# ---------------------------------------------------------------------------

def infer_column_types(
    df: pd.DataFrame,
    config: TypeDetectionConfig | None = None,
) -> pd.DataFrame:
    """
    Inspect every column of df and return a summary DataFrame with one row per column.

    Each row reports:
    - pandas_dtype    : the raw dtype string as pandas sees it
    - basic_type      : coarse bucket (int, float, bool, datetime, object)
    - refined_type    : finer label (id, date, time, category, string, …)
    - statistical_type: role for modelling (identifier, discrete, continuous, binary,
                        categorical, temporal, text)
    - n_non_null      : count of non-null values
    - n_unique        : count of distinct non-null values
    """
    _check_df(df, "infer_column_types")
    config = config or TypeDetectionConfig()

    rows: list[Dict[str, Any]] = []

    for col in df.columns:
        s = df[col]
        non_null = s.dropna()
        pandas_dtype = str(s.dtype)
        n_unique = int(non_null.nunique(dropna=True))

        if pd.api.types.is_integer_dtype(s):
            basic_type = "int"
            if _looks_like_id(col):
                refined_type = "id"
                statistical_type = "identifier"
            else:
                refined_type = "int"
                statistical_type = _detect_numeric_statistical_type(s)

        elif pd.api.types.is_float_dtype(s):
            basic_type = "float"
            refined_type = "float"
            statistical_type = _detect_numeric_statistical_type(s)

        elif pd.api.types.is_bool_dtype(s):
            basic_type = "bool"
            refined_type = "bool"
            statistical_type = "binary"

        elif pd.api.types.is_datetime64_any_dtype(s):
            basic_type = "datetime"
            refined_type = "date"
            statistical_type = "temporal"

        else:
            basic_type = "object"
            if _looks_like_id(col):
                refined_type = "id"
                statistical_type = "identifier"
            else:
                refined_type = _detect_object_subtype(s, config)
                if refined_type == "bool":
                    statistical_type = "binary"
                elif refined_type == "category":
                    # 2-value categoricals are binary, not "categorical".
                    # Avoids redundant one-hot expansion (Gender_M + Gender_F).
                    statistical_type = "binary" if n_unique == 2 else "categorical"
                elif refined_type in {"date", "time"}:
                    statistical_type = "temporal"
                else:
                    statistical_type = "text"

        rows.append({
            "column": col,
            "pandas_dtype": pandas_dtype,
            "basic_type": basic_type,
            "refined_type": refined_type,
            "statistical_type": statistical_type,
            "n_non_null": int(non_null.shape[0]),
            "n_unique": n_unique,
        })

    result = pd.DataFrame(rows)

    sep = "─" * 62
    print(sep)
    print(f"  infer_column_types — {len(result)} column(s) inspected")
    print(sep)
    print(f"  {'Column':<24}  {'Refined type':<14}  Statistical type")
    print(sep)
    for _, row in result.iterrows():
        print(
            f"  {row['column']:<24}  {row['refined_type']:<14}  {row['statistical_type']}"
        )
    print(sep)
    print()
    print("  To correct a column before casting:")
    print('    detected.loc[detected["column"] == "<col>", "refined_type"]    = "<new>"')
    print('    detected.loc[detected["column"] == "<col>", "statistical_type"] = "<new>"')
    print()
    print("  refined_type values    : id  int  float  bool  date  time  category  string")
    print("  statistical_type values: identifier  discrete  continuous  binary  categorical  temporal  text")
    print(sep)

    return result


def cast_columns_by_detected_type(
    df: pd.DataFrame,
    detected: pd.DataFrame,
    date_dayfirst: bool = False,
) -> pd.DataFrame:
    """
    Cast each column of df to the dtype implied by its refined_type in detected.

    detected is the DataFrame returned by infer_column_types(). Columns not
    present in detected are left unchanged.
    """
    _check_df(df, "cast_columns_by_detected_type")
    _check_detected(detected, "cast_columns_by_detected_type")

    out = df.copy()
    type_map = dict(zip(detected["column"], detected["refined_type"]))

    for col, inferred in type_map.items():
        if inferred == "id":
            continue

        if inferred == "bool":
            stripped = out[col].astype("string").str.strip().str.lower()
            true_vals = {"true", "yes", "1"}
            out[col] = stripped.isin(true_vals)

        elif inferred == "date":
            out[col] = pd.to_datetime(out[col], errors="coerce", dayfirst=date_dayfirst)

        elif inferred == "time":
            out[col] = pd.to_timedelta(out[col], errors="coerce")

        elif inferred == "category":
            out[col] = out[col].astype("string").str.strip().astype("category")

        elif inferred == "string":
            out[col] = out[col].astype("string").str.strip()

        elif inferred in {"int", "float"}:
            out[col] = pd.to_numeric(out[col], errors="coerce")

    return out


def classify_time_variance(
    df: pd.DataFrame,
    entity_col: Union[str, "DataStructure"],
    detected: pd.DataFrame,
) -> tuple[pd.DataFrame, str | None]:
    """
    Classify each column as time-invariant or time-variant, and identify
    the main transaction date column.

    Parameters
    ----------
    df         : the raw DataFrame (one row per transaction)
    entity_col : column name identifying the entity (e.g. "Id"), OR a
                 DataStructure whose entity_col field is used.  When a
                 DataStructure is passed its date_col is updated in-place
                 to the detected main transaction date.
    detected   : summary DataFrame returned by infer_column_types()

    Returns
    -------
    summary   : detected extended with a 'time_variance' column:
                  'invariant'  — same value for every row of a given entity
                  'variant'    — changes across rows for at least one entity
                  'identifier' — the entity_col itself (excluded from analysis)
    main_date : name of the detected main transaction date column, or None.

    The main transaction date is the variant date column where the highest
    number of entities have more than one distinct value.
    """
    _check_df(df, "classify_time_variance")
    _check_detected(detected, "classify_time_variance")

    structure: DataStructure | None = None
    if isinstance(entity_col, DataStructure):
        structure = entity_col
        if structure.entity_col is None:
            raise ValueError(
                "classify_time_variance: entity_col is None in the provided DataStructure. "
                "Set structure.entity_col before calling classify_time_variance()."
            )
        col_name = structure.entity_col
    else:
        col_name = entity_col

    summary = detected.copy()
    variance_labels: dict[str, str] = {}

    for col in summary["column"]:
        if col == col_name:
            variance_labels[col] = "identifier"
            continue
        if col not in df.columns:
            variance_labels[col] = "unknown"
            continue
        max_unique = df.groupby(col_name)[col].nunique().max()
        variance_labels[col] = "variant" if max_unique > 1 else "invariant"

    summary["time_variance"] = summary["column"].map(variance_labels)

    # Detect main transaction date: date column where most entities vary
    date_cols = summary.loc[
        (summary["refined_type"] == "date") & (summary["time_variance"] == "variant"),
        "column",
    ].tolist()

    main_date: str | None = None
    if date_cols:
        main_date = max(
            date_cols,
            key=lambda c: (df.groupby(col_name)[c].nunique() > 1).sum(),
        )

    if structure is not None:
        structure.date_col = main_date

    return summary, main_date


# ---------------------------------------------------------------------------
# Structure proposal and covariate planning
# ---------------------------------------------------------------------------

@dataclass
class DataStructure:
    """Proposed column roles returned by propose_structure().

    Override any field before passing to plan_covariates():
        structure.entity_col = "CustomerId"
    """
    entity_col: str | None
    date_col: str | None
    target_col: str | None
    entity_candidates: list[str]
    date_candidates: list[str]


@dataclass
class CovariatePlan:
    """Output of plan_covariates(): which columns play which role.

    Pass to build_transaction_sequences(plan=...) to avoid listing
    columns explicitly.
    """
    static_cols: list[str]
    time_varying_cols: list[str]
    covariate_date_col: str | None
    skip_cols: list[str]
    encoding_notes: dict[str, str]


def propose_structure(detected: pd.DataFrame) -> DataStructure:
    """Propose entity / date column roles from the infer_column_types() output.

    Scans detected for identifier and date columns, ranks date columns by
    cardinality (higher n_unique → transaction date, lower → covariate date),
    and prints a proposal table.  Override any field on the returned object
    before passing it to plan_covariates().
    """
    _check_detected(detected, "propose_structure")

    id_rows = detected[detected["statistical_type"] == "identifier"]
    entity_candidates: list[str] = id_rows["column"].tolist()
    entity_col: str | None = entity_candidates[0] if entity_candidates else None

    date_rows = (
        detected[detected["refined_type"] == "date"]
        .sort_values("n_unique", ascending=False)
    )
    date_candidates: list[str] = date_rows["column"].tolist()
    date_col: str | None = date_candidates[0] if date_candidates else None

    sep = "─" * 62
    print(sep)
    print("  propose_structure — proposed column roles")
    print(sep)

    entries = [
        ("entity_col", entity_col, "customer / entity identifier"),
        ("date_col",   date_col,   "purchase / event date  (highest-cardinality date)"),
        ("target_col", None,       "prediction target  (set manually if needed)"),
    ]
    for name, val, desc in entries:
        label = val if val is not None else "(none detected)"
        if val is not None:
            n_uniq = int(detected.loc[detected["column"] == val, "n_unique"].iloc[0])
            extra = f"  ({n_uniq:,} unique)  {desc}"
        else:
            extra = f"  {desc}"
        print(f"  {name:<14} → {label:<20}{extra}")

    if len(date_candidates) > 1:
        print()
        print(f"  Other date columns (potential covariate dates): {date_candidates[1:]}")

    print()
    print("  Override any field before calling plan_covariates():")
    print(f"    structure.entity_col = {entity_col!r}")
    print(f"    structure.date_col   = {date_col!r}")
    print(sep)

    return DataStructure(
        entity_col=entity_col,
        date_col=date_col,
        target_col=None,
        entity_candidates=entity_candidates,
        date_candidates=date_candidates,
    )


def _encoding_note(stat_type: str) -> str | None:
    """Return an encoding hint for the user, or None if not needed."""
    if stat_type == "categorical":
        return "one-hot or ordinal encoding recommended before building sequences"
    if stat_type == "binary":
        return "encode as 0/1 (cast_columns_by_detected_type handles this)"
    if stat_type == "text":
        return "not directly usable as a numeric covariate; consider excluding"
    if stat_type == "continuous":
        return "normalize/standardize before building sequences; fit on training rows only"
    if stat_type == "discrete":
        return "normalize or treat as ordinal; fit scaler on training rows only"
    return None


def plan_covariates(
    df: pd.DataFrame,
    detected: pd.DataFrame,
    structure: DataStructure,
) -> CovariatePlan:
    """Classify every column as static, time-varying, or skip.

    Calls classify_time_variance() internally using structure.entity_col.
    The second date column in structure.date_candidates (if any) becomes
    the covariate observation date (covariate_date_col).
    The returned CovariatePlan can be passed directly to
    build_transaction_sequences(plan=...).

    Parameters
    ----------
    df        : the raw DataFrame (same one used with infer_column_types)
    detected  : DataFrame returned by infer_column_types()
    structure : DataStructure returned by propose_structure(),
                optionally with fields overridden by the user

    Returns
    -------
    CovariatePlan with static_cols, time_varying_cols, covariate_date_col,
    skip_cols, and encoding_notes filled in.
    """
    if structure.entity_col is None:
        raise ValueError(
            "structure.entity_col is None. "
            "Set it to the customer-identifier column before calling plan_covariates()."
        )

    entity_col = structure.entity_col
    transaction_date_col = structure.date_col

    # Second date column (if any) becomes the covariate observation date
    covariate_date_col: str | None = (
        structure.date_candidates[1]
        if len(structure.date_candidates) > 1
        else None
    )

    summary, _main_date = classify_time_variance(df, entity_col, detected)

    reserved: set[str] = {entity_col}
    if transaction_date_col:
        reserved.add(transaction_date_col)
    if covariate_date_col:
        reserved.add(covariate_date_col)
    if structure.target_col:
        reserved.add(structure.target_col)

    static_cols: list[str]         = []
    time_varying_cols: list[str]   = []
    skip_cols: list[str]           = []
    encoding_notes: dict[str, str] = {}
    role_labels: dict[str, str]    = {}

    for _, row in summary.iterrows():
        col       = str(row["column"])
        stat_type = str(row["statistical_type"])
        refined   = str(row["refined_type"])
        variance  = str(row.get("time_variance", "unknown"))

        if col in reserved or stat_type == "identifier" or refined in {"date", "time"}:
            skip_cols.append(col)
            if col == entity_col:
                role_labels[col] = "entity (skip)"
            elif col == transaction_date_col:
                role_labels[col] = "transaction_date (skip)"
            elif col == covariate_date_col:
                role_labels[col] = "covariate_date (skip)"
            elif stat_type == "identifier":
                role_labels[col] = "identifier (skip)"
            else:
                role_labels[col] = "temporal (skip)"
            continue

        if variance == "variant":
            time_varying_cols.append(col)
            role_labels[col] = "time_varying_col"
        elif variance == "invariant":
            static_cols.append(col)
            role_labels[col] = "static_col"
        else:
            skip_cols.append(col)
            role_labels[col] = "unknown (skip)"
            continue

        note = _encoding_note(stat_type)
        if note:
            encoding_notes[col] = note

    sep = "─" * 62
    print(sep)
    print("  plan_covariates — covariate classification")
    print(sep)
    print(f"  {'Column':<24}  {'Stat. type':<14}  {'Variance':<12}  Role")
    print(sep)
    for _, row in summary.iterrows():
        col       = str(row["column"])
        stat_type = str(row["statistical_type"])
        variance  = str(row.get("time_variance", "—"))
        role      = role_labels.get(col, "—")
        print(f"  {col:<24}  {stat_type:<14}  {variance:<12}  {role}")
    print(sep)
    print()
    print(f"  static_cols       : {static_cols}")
    print(f"  time_varying_cols : {time_varying_cols}")
    print(f"  covariate_date_col: {covariate_date_col!r}")
    if encoding_notes:
        print()
        print("  Encoding reminders (apply before building sequences):")
        for col, note in encoding_notes.items():
            print(f"    {col}: {note}")
    print(sep)

    return CovariatePlan(
        static_cols=static_cols,
        time_varying_cols=time_varying_cols,
        covariate_date_col=covariate_date_col,
        skip_cols=skip_cols,
        encoding_notes=encoding_notes,
    )


def analyze_structure(
    df: pd.DataFrame,
    detected: pd.DataFrame,
    unknown_future_cols: list[str] | None = None,
    target_col: str | None = None,
) -> tuple[DataStructure, CovariatePlan]:
    """One-shot replacement for propose_structure() + plan_covariates().

    Parameters
    ----------
    df, detected
        Same arguments as propose_structure()/plan_covariates().
    unknown_future_cols
        Time-varying columns whose future values are NOT known at
        prediction time.  Removed from plan.time_varying_cols (they
        cannot be fed to the LSTM during the holdout rollout) and
        moved to plan.skip_cols.
    target_col
        The column being predicted (e.g. "transaction_count").
        Excluded from plan.static_cols / plan.time_varying_cols so it
        is not double-counted as both target and feature.

    Returns
    -------
    (DataStructure, CovariatePlan)
    """
    structure = propose_structure(detected)
    if target_col is not None:
        if target_col not in detected["column"].values:
            raise ValueError(
                f"target_col '{target_col}' not found in detected columns: "
                f"{detected['column'].tolist()}"
            )
        structure.target_col = target_col
    plan = plan_covariates(df, detected, structure)

    if unknown_future_cols:
        unknown = set(unknown_future_cols)
        dropped = [c for c in plan.time_varying_cols if c in unknown]
        plan.time_varying_cols = [c for c in plan.time_varying_cols if c not in unknown]
        for c in dropped:
            if c not in plan.skip_cols:
                plan.skip_cols.append(c)
            plan.encoding_notes.pop(c, None)
        if dropped:
            sep = "─" * 62
            print(sep)
            print(f"  analyze_structure — dropped {len(dropped)} unknown-future column(s):")
            for c in dropped:
                print(f"    {c}")
            print(sep)

    return structure, plan
