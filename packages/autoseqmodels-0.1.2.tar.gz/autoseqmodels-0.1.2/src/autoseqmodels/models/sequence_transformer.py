"""
Simple causal Transformer for transaction-count prediction.

Mirrors the LSTM workflow:
  • Same SequenceDataset (from training.py) — no rebuild required.
  • Same train_model from training.py — works because forward returns
    (logits, _) and train_model only needs `logits`.
  • Same evaluate_predictions and plot_training_and_predictions.

What is genuinely different:
  • predict_holdout_transformer — transformers have no recurrent state,
    so the rollout grows the input context by one token per holdout step
    and re-runs the encoder.  Simpler than the LSTM rollout, just slower.
  • forward signature uses `past_kv` (placeholder for an eventual KV cache)
    instead of `h0/c0`.

Public API:
  SequenceTransformer        — model class
  predict_holdout_transformer — autoregressive rollout
  tune_transformer           — Optuna search
  train_tuned_transformer    — retrain with best params
"""

from __future__ import annotations

import gc
from typing import Any

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from .training import SequenceDataset, train_model


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

class SequenceTransformer(nn.Module):
    """
    Encoder-only causal Transformer.

    Input convention (identical to SequenceLSTM):
      week    (B, T)            int64    week-of-year index 0..51
      txn     (B, T)            int64    past transaction count
      floats  (B, T, n_float)   float32  seasonality + covariates

    Three input streams are summed into a single d_model token vector
    per timestep, then a learned positional embedding is added.  The
    sequence passes through stacked TransformerEncoderLayer with a
    causal mask so position t can only attend to positions <= t.

    Forward returns (logits, None).  The second slot mirrors the LSTM's
    (logits, (h, c)) tuple so train_model from sequence_lstm.py works
    unchanged.  When KV caching is added later, the second slot will
    hold the cache instead of None.
    """

    def __init__(
        self,
        n_weeks:     int,
        n_classes:   int,
        n_float:     int,
        d_model:     int   = 128,
        n_heads:     int   = 4,
        n_layers:    int   = 2,
        d_ff:        int   | None = None,    # default: 4 × d_model (standard)
        dropout:     float = 0.1,
        max_seq_len: int   = 512,
    ):
        super().__init__()
        if d_model % n_heads != 0:
            raise ValueError(
                f"d_model ({d_model}) must be divisible by n_heads ({n_heads})."
            )
        if d_ff is None:
            d_ff = 4 * d_model

        # Three input streams → all projected to d_model so they can be summed.
        # LayerNorm after each lookup/projection stabilises the sum that follows
        # (otherwise the magnitudes of the three streams can drift apart and
        # one stream silently dominates).
        self.week_emb   = nn.Sequential(
            nn.Embedding(n_weeks,   d_model),
            nn.LayerNorm(d_model),
        )
        self.txn_emb    = nn.Sequential(
            nn.Embedding(n_classes, d_model),
            nn.LayerNorm(d_model),
        )
        if n_float > 0:
            self.float_proj = nn.Sequential(
                nn.Linear(n_float, d_model),
                nn.LayerNorm(d_model),
            )
        else:
            self.float_proj = None

        # Learned positional embedding — simpler than sinusoidal, parallels
        # the LSTM's learned week embedding.
        self.pos_emb = nn.Embedding(max_seq_len, d_model)

        # Pre-norm = more stable training, especially for deeper stacks.
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=n_layers)

        # 2-layer output head (Linear → ReLU → LayerNorm → Linear).
        # Adds a non-linearity between hidden state and class logits so the
        # mapping isn't a single affine transform.
        self.head = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.ReLU(),
            nn.LayerNorm(d_model),
            nn.Linear(d_model, n_classes),
        )

        self.d_model     = d_model
        self.n_classes   = n_classes
        self.max_seq_len = max_seq_len

    @classmethod
    def from_sequences(cls, seqs: dict[str, Any], **kwargs) -> "SequenceTransformer":
        """Auto-configure dimensions from build_transaction_sequences() output."""
        ds = SequenceDataset(seqs)
        return cls(
            n_weeks=52,
            n_classes=ds.n_classes,
            n_float=ds.n_float,
            **kwargs,
        )

    def forward(
        self,
        week:    torch.Tensor,           # (B, T) int64
        txn:     torch.Tensor,           # (B, T) int64
        floats:  torch.Tensor,           # (B, T, n_float) float32
        past_kv=None,                    # placeholder — not used in this version
    ) -> tuple[torch.Tensor, None]:
        B, T = week.shape
        if T > self.max_seq_len:
            raise ValueError(
                f"Sequence length {T} exceeds max_seq_len={self.max_seq_len}. "
                "Pass a larger max_seq_len when constructing the model."
            )

        # Sum the three input streams
        x = self.week_emb(week) + self.txn_emb(txn)
        if self.float_proj is not None:
            x = x + self.float_proj(floats)

        # Add positional embedding (one row per absolute position)
        positions = torch.arange(T, device=week.device).expand(B, T)
        x = x + self.pos_emb(positions)

        # Causal self-attention — each position only sees positions <= itself
        mask = nn.Transformer.generate_square_subsequent_mask(T, device=week.device)
        x = self.encoder(x, mask=mask, is_causal=True)

        logits = self.head(x)            # (B, T, n_classes)
        return logits, None              # second slot reserved for KV cache


# ---------------------------------------------------------------------------
# Autoregressive holdout prediction
# ---------------------------------------------------------------------------

@torch.no_grad()
def predict_holdout_transformer(
    model:          SequenceTransformer,
    seqs:           dict[str, Any],
    dataset:        SequenceDataset,
    *,
    n_simulations:  int                       = 100,
    sim_chunk_size: int                       = 4,
    device:         str | torch.device | None = None,
    verbose:        bool                      = True,
) -> np.ndarray:
    """
    Autoregressive holdout prediction.

    Strategy:
      Phase 1 — run the FULL calibration through the encoder.  The output at
                the last calibration position predicts the first holdout
                week's count (training contract: output at step t predicts
                transactions[t+1]).
      Phase 2 — for each subsequent holdout step k:
                  1. Append (holdout_weeks[k-1], previous_prediction,
                             holdout_floats[k-1]) to the running context.
                  2. Re-run the encoder on the grown context.
                  3. Read the last-position logits → prediction for week k.
                Cost per step is O((T+k)^2) due to attention over the full
                history; the rollout grows quadratically.  Acceptable for
                T+H around 250; add KV caching if you scale up.

    Output:
      pred_matrix  (N_customers, H_holdout_weeks)  ndarray of expected counts.
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device)
    model.to(device)
    model.eval()

    feature_names = seqs["feature_names"]
    week_idx      = feature_names.index("week")
    tx_idx        = feature_names.index("transactions")
    float_indices = dataset.float_indices
    n_classes     = dataset.n_classes

    N = len(seqs["calibration"])
    H = seqs["holdout"][0].shape[0]

    # ── pre-compute calibration + holdout tensors on device ──────────────
    calib_arr   = np.stack(seqs["calibration"])                               # (N, T, F)
    holdout_arr = np.stack(seqs["holdout"])                                   # (N, H, F)

    calib_w  = torch.from_numpy(calib_arr[:, :, week_idx].astype(np.int64)).to(device)
    calib_t  = torch.from_numpy(
        np.clip(calib_arr[:, :, tx_idx].astype(np.int64), 0, n_classes - 1)
    ).to(device)
    calib_f  = torch.from_numpy(calib_arr[:, :, float_indices].astype(np.float32)).to(device)

    hold_w   = torch.from_numpy(holdout_arr[:, :, week_idx].astype(np.int64)).to(device)
    hold_f   = torch.from_numpy(holdout_arr[:, :, float_indices].astype(np.float32)).to(device)

    counts_t = torch.arange(n_classes, dtype=torch.float32, device=device)

    # -----------------------------------------------------------------------
    # Deterministic mode (n_simulations == 1) — expected value, single run
    # -----------------------------------------------------------------------
    if n_simulations == 1:
        ctx_w, ctx_t, ctx_f = calib_w.clone(), calib_t.clone(), calib_f.clone()

        # Phase 1
        logits, _   = model(ctx_w, ctx_t, ctx_f)            # (N, T, C)
        last_logits = logits[:, -1, :]                       # (N, C)
        pred_first  = (torch.softmax(last_logits, -1) * counts_t).sum(-1)

        preds       = torch.zeros(N, H, device=device)
        preds[:, 0] = pred_first
        prev_txn    = pred_first.round().long().clamp(0, n_classes - 1)

        # Phase 2
        for k in tqdm(range(1, H), desc="Predicting holdout",
                      unit="week", disable=not verbose):
            ctx_w = torch.cat([ctx_w, hold_w[:, k-1:k]],            dim=1)
            ctx_t = torch.cat([ctx_t, prev_txn.unsqueeze(1)],       dim=1)
            ctx_f = torch.cat([ctx_f, hold_f[:, k-1:k, :]],         dim=1)

            logits, _   = model(ctx_w, ctx_t, ctx_f)
            pred_val    = (torch.softmax(logits[:, -1, :], -1) * counts_t).sum(-1)
            preds[:, k] = pred_val
            prev_txn    = pred_val.round().long().clamp(0, n_classes - 1)

        return preds.cpu().numpy()

    # -----------------------------------------------------------------------
    # Monte-Carlo mode — chunk simulations to cap memory
    # -----------------------------------------------------------------------
    all_preds = torch.zeros(N, n_simulations, H)
    n_chunks  = (n_simulations + sim_chunk_size - 1) // sim_chunk_size
    sim_done  = 0

    chunk_bar = tqdm(range(n_chunks), desc="Predicting holdout",
                     unit="chunk", disable=not verbose)
    for _ in chunk_bar:
        S = min(sim_chunk_size, n_simulations - sim_done)

        # Replicate calibration across S simulations: (N, ...) → (N*S, ...)
        ctx_w = calib_w.repeat_interleave(S, dim=0)
        ctx_t = calib_t.repeat_interleave(S, dim=0)
        ctx_f = calib_f.repeat_interleave(S, dim=0)

        weeks_rep  = hold_w.repeat_interleave(S, dim=0)
        floats_rep = hold_f.repeat_interleave(S, dim=0)

        # Phase 1 — sample first prediction from full-calibration logits
        logits, _ = model(ctx_w, ctx_t, ctx_f)
        sampled_first = torch.multinomial(
            torch.softmax(logits[:, -1, :], -1), 1
        ).squeeze(1)

        chunk_preds = torch.zeros(N * S, H, device=device)
        chunk_preds[:, 0] = sampled_first.float()
        prev_txn = sampled_first.clamp(0, n_classes - 1)

        # Phase 2 — append-and-rerun
        for k in range(1, H):
            ctx_w = torch.cat([ctx_w, weeks_rep[:, k-1:k]],     dim=1)
            ctx_t = torch.cat([ctx_t, prev_txn.unsqueeze(1)],   dim=1)
            ctx_f = torch.cat([ctx_f, floats_rep[:, k-1:k, :]], dim=1)

            logits, _ = model(ctx_w, ctx_t, ctx_f)
            sampled   = torch.multinomial(
                torch.softmax(logits[:, -1, :], -1), 1
            ).squeeze(1)
            chunk_preds[:, k] = sampled.float()
            prev_txn = sampled.clamp(0, n_classes - 1)

        all_preds[:, sim_done:sim_done + S, :] = (
            chunk_preds.cpu().reshape(N, S, H)
        )
        sim_done += S
        chunk_bar.set_postfix(sims=f"{sim_done}/{n_simulations}")

    return all_preds.mean(dim=1).numpy()


# ---------------------------------------------------------------------------
# Optuna hyperparameter search
# ---------------------------------------------------------------------------

def _pick_n_heads(d_model: int) -> int:
    """Largest reasonable head count that still divides d_model evenly."""
    for h in (8, 4, 2, 1):
        if d_model % h == 0:
            return h
    return 1


def _build_objective_transformer(
    train_ds, val_ds,
    n_classes:  int,
    n_float:    int,
    max_epochs: int,
    device:     torch.device,
    fixed:      dict[str, Any],
):
    """Optuna objective: build a SequenceTransformer, train, return best val loss."""
    import optuna

    def objective(trial: optuna.Trial) -> float:
        def _fix_or(name, suggest_fn):
            return fixed[name] if name in fixed else suggest_fn()

        d_model    = _fix_or("d_model",    lambda: trial.suggest_categorical("d_model", [64, 128, 256]))
        n_layers   = _fix_or("n_layers",   lambda: trial.suggest_int("n_layers", 1, 4))
        dropout    = _fix_or("dropout",    lambda: trial.suggest_float("dropout", 0.0, 0.4))
        lr         = _fix_or("lr",         lambda: trial.suggest_float("lr", 1e-4, 1e-2, log=True))
        patience   = _fix_or("patience",   lambda: trial.suggest_int("patience", 5, 15))
        batch_size = _fix_or("batch_size", lambda: trial.suggest_categorical("batch_size", [128, 256, 512]))

        n_heads = _pick_n_heads(d_model)

        model = SequenceTransformer(
            n_weeks=52,
            n_classes=n_classes,
            n_float=n_float,
            d_model=d_model,
            n_heads=n_heads,
            n_layers=n_layers,
            dropout=dropout,
        ).to(device)

        history = train_model(
            model, train_ds, val_ds,
            lr=lr,
            epochs=max_epochs,
            patience=patience,
            batch_size=batch_size,
            device=device,
            verbose=False,
        )

        best_val   = min(history["val_loss"])
        best_epoch = int(np.argmin(history["val_loss"])) + 1
        trial.set_user_attr("best_epoch", best_epoch)
        trial.set_user_attr("last_epoch", len(history["val_loss"]))

        # Free GPU memory between trials
        del model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        return best_val

    return objective


def tune_transformer(
    seqs:          dict[str, Any],
    train_dataset,
    val_dataset,
    *,
    n_trials:      int                       = 30,
    max_epochs:    int                       = 100,
    storage:       str | None                = None,
    study_name:    str | None                = None,
    device:        str | torch.device | None = None,
    verbose:       bool                      = True,
    fixed_params:  dict[str, Any] | None     = None,
):
    """
    Optuna search for SequenceTransformer.  Same shape as tune_lstm.

    Tunable hyperparameters (override via fixed_params to fix any of them):
      d_model    : categorical [64, 128, 256]
      n_layers   : int 1 – 4
      dropout    : float 0.0 – 0.4
      lr         : float 1e-4 – 1e-2 (log)
      patience   : int 5 – 15
      batch_size : categorical [128, 256, 512]

    n_heads is derived from d_model (largest power of 2 that divides it).
    d_ff is set to 2 × d_model.
    """
    import optuna

    fixed = fixed_params or {}
    ds    = SequenceDataset(seqs)

    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device)

    if verbose:
        _ALL = {"d_model", "n_layers", "dropout", "lr", "patience", "batch_size"}
        tuned  = sorted(_ALL - fixed.keys())
        pinned = sorted(fixed.keys())
        sep = "─" * 52
        print(sep)
        print("  tune_transformer")
        print(sep)
        print(f"  Train customers : {len(train_dataset)}")
        print(f"  Val   customers : {len(val_dataset)}")
        if tuned:
            print(f"  Tuning   : {tuned}")
        if pinned:
            print(f"  Fixed    : { {k: fixed[k] for k in pinned} }")
        print(f"  Trials   : {n_trials}   max_epochs: {max_epochs}")
        print(f"  Device   : {device}")
        print(sep)

    pruner = optuna.pruners.HyperbandPruner(
        min_resource=5,
        max_resource=max_epochs,
        reduction_factor=3,
    )
    study = optuna.create_study(
        direction="minimize",
        pruner=pruner,
        storage=storage,
        study_name=study_name,
        load_if_exists=True,
    )
    optuna.logging.set_verbosity(
        optuna.logging.INFO if verbose else optuna.logging.WARNING
    )
    study.optimize(
        _build_objective_transformer(
            train_dataset, val_dataset,
            ds.n_classes, ds.n_float, max_epochs, device, fixed,
        ),
        n_trials=n_trials,
        show_progress_bar=verbose,
    )

    if verbose:
        print(f"  Best params    : {study.best_params}")
        print(f"  Best val loss  : {study.best_value:.4f}")

    return study


def train_tuned_transformer(
    seqs:    dict[str, Any],
    study,
    train_dataset,
    val_dataset,
    *,
    device:  str | torch.device | None = None,
    verbose: bool = True,
) -> tuple[SequenceTransformer, dict[str, list[float]]]:
    """
    Retrain SequenceTransformer with the best hyperparameters from tune_transformer().

    Returns
    -------
    (model, history)  — same shape as train_tuned_lstm.
    """
    p   = study.best_params
    ds  = SequenceDataset(seqs)

    d_model = p["d_model"]
    n_heads = _pick_n_heads(d_model)

    model = SequenceTransformer(
        n_weeks=52,
        n_classes=ds.n_classes,
        n_float=ds.n_float,
        d_model=d_model,
        n_heads=n_heads,
        n_layers=p.get("n_layers", 2),
        dropout=p.get("dropout", 0.0),
    )

    history = train_model(
        model, train_dataset, val_dataset,
        lr=p["lr"],
        epochs=200,
        patience=p.get("patience", 8),
        batch_size=p.get("batch_size", 256),
        device=device,
        verbose=verbose,
    )

    return model, history
