# LSTMCell-based sequence model for transaction count prediction.
# Works directly with the output of build_transaction_sequences().
#
# Architecture follows LSTM_Based_Models.ipynb (LSTMCellModel):
#   - Separate embeddings for week (0-51) and past transaction count
#   - Additional float features (seasonality sin/cos, covariates) concatenated
#   - Multi-layer LSTMCell with LayerNorm + variational dropout
#   - Output: logits over transaction count classes → CrossEntropyLoss
#
# Prediction is autoregressive:
#   1. Warm up hidden state by teacher-forcing on the calibration sequence.
#   2. Step through holdout weeks, feeding predicted counts back as input.
#   3. Optionally average n_simulations Monte Carlo trajectories.
#
# Public API:
#   SequenceLSTM       — the model (classmethod from_sequences for auto-config)
#   predict_holdout    — autoregressive MC prediction → (N, H) matrix
#   tune_lstm          — Optuna hyperparameter search (requires optuna)
#   train_tuned_lstm   — retrain with best params found by tune_lstm
#
# Generic utilities (SequenceDataset, make_train_val_split, train_model,
# evaluate_predictions, plot_training_and_predictions) live in training.py
# and are re-exported here for backward compatibility.

from __future__ import annotations

import gc
from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from tqdm.auto import tqdm

# Re-export generic utilities.  Single definition in training.py — these names
# stay available as `sequence_lstm.SequenceDataset` etc. for existing notebook
# code, but new code should prefer `from autoseqmodels.models import training`.
from .training import (                                               # noqa: F401
    SequenceDataset,
    make_train_val_split,
    train_model,
    evaluate_predictions,
    plot_training_and_predictions,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _emb_dim(n: int) -> int:
    """Guo & Berkhahn (2016) embedding dimension heuristic."""
    return max(4, min(50, round(1.6 * n ** 0.56)))


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

class SequenceLSTM(nn.Module):
    """
    LSTMCell model with week + transaction embeddings and continuous float inputs.

    Matches LSTMCellModel from LSTM_Based_Models.ipynb, extended to accept
    additional float-valued features (seasonality sin/cos, covariates).

    Parameters
    ----------
    n_weeks : int
        Number of distinct week index values (52 for the ordinal 0-51 scheme).
    n_classes : int
        Transaction count classes = max_transactions + 1.
    n_float : int
        Number of continuous float features per timestep.
    week_emb_dim : int | None
        Embedding size for week. None → Guo & Berkhahn heuristic.
    txn_emb_dim : int | None
        Embedding size for transaction count. None → Guo & Berkhahn heuristic.
    hidden_size : int
        LSTMCell hidden state dimension.
    n_layers : int
        Number of stacked LSTMCells.
    dropout : float
        Variational dropout probability (Gal & Ghahramani, 2016).
        One mask sampled per forward pass, reused at every timestep.
        Set to 0 to disable.
    """

    def __init__(
        self,
        n_weeks:      int,
        n_classes:    int,
        n_float:      int,
        week_emb_dim: int | None = None,
        txn_emb_dim:  int | None = None,
        hidden_size:  int   = 256,
        n_layers:     int   = 1,
        dropout:      float = 0.0,
    ):
        super().__init__()
        week_emb_dim = week_emb_dim or _emb_dim(n_weeks)
        txn_emb_dim  = txn_emb_dim  or _emb_dim(n_classes)

        self.week_emb    = nn.Embedding(n_weeks,   week_emb_dim)
        self.txn_emb     = nn.Embedding(n_classes, txn_emb_dim)
        self.hidden_size = hidden_size
        self.n_layers    = n_layers
        self.dropout_p   = dropout
        self.n_classes   = n_classes

        input_size = week_emb_dim + txn_emb_dim + n_float

        self.cells = nn.ModuleList([
            nn.LSTMCell(input_size if i == 0 else hidden_size, hidden_size)
            for i in range(n_layers)
        ])
        self.layer_norms = nn.ModuleList([
            nn.LayerNorm(hidden_size) for _ in range(n_layers)
        ])
        self.out = nn.Linear(hidden_size, n_classes)

    @classmethod
    def from_sequences(
        cls,
        seqs: dict[str, Any],
        **kwargs,
    ) -> "SequenceLSTM":
        """
        Construct a SequenceLSTM auto-configured from build_transaction_sequences() output.

        Keyword arguments (hidden_size, n_layers, dropout, …) are forwarded to __init__.

        Example
        -------
        model = SequenceLSTM.from_sequences(seqs, hidden_size=256, n_layers=1, dropout=0.1)
        """
        ds = SequenceDataset(seqs)
        return cls(
            n_weeks=52,
            n_classes=ds.n_classes,
            n_float=ds.n_float,
            **kwargs,
        )

    # -- variational dropout --------------------------------------------------

    def _sample_mask(self, batch_size: int, size: int, device) -> torch.Tensor | None:
        """Sample a (B, size) binary dropout mask; returns None when dropout is off or in eval mode."""
        if self.dropout_p == 0.0 or not self.training:
            return None
        return torch.nn.functional.dropout(
            torch.ones(batch_size, size, device=device),
            p=self.dropout_p,
            training=True,
        )

    @staticmethod
    def _apply_mask(x: torch.Tensor, mask) -> torch.Tensor:
        """Multiply x by mask if mask is not None, otherwise return x unchanged."""
        return x * mask if mask is not None else x

    # -- forward --------------------------------------------------------------

    def forward(
        self,
        week:   torch.Tensor,       # (B, T)           int64
        txn:    torch.Tensor,       # (B, T)           int64
        floats: torch.Tensor,       # (B, T, n_float)  float32
        h0: torch.Tensor | None = None,   # (n_layers, B, H)
        c0: torch.Tensor | None = None,   # (n_layers, B, H)
    ) -> tuple[torch.Tensor, tuple]:
        """
        Returns
        -------
        logits : (B, T, n_classes)
        (h, c) : (n_layers, B, H)  — final states for autoregressive chaining
        """
        B, T = week.shape

        w   = self.week_emb(week)               # (B, T, Ew)
        x   = self.txn_emb(txn)                 # (B, T, Ex)
        inp = torch.cat([w, x, floats], dim=-1)  # (B, T, input_size)

        input_mask   = self._sample_mask(B, inp.shape[-1], week.device)
        hidden_masks = [
            self._sample_mask(B, self.hidden_size, week.device)
            for _ in range(self.n_layers)
        ]

        h = [h0[i] for i in range(self.n_layers)] if h0 is not None else \
            [torch.zeros(B, self.hidden_size, device=week.device) for _ in range(self.n_layers)]
        c = [c0[i] for i in range(self.n_layers)] if c0 is not None else \
            [torch.zeros(B, self.hidden_size, device=week.device) for _ in range(self.n_layers)]

        outputs = []
        for t in range(T):
            x_t = self._apply_mask(inp[:, t, :], input_mask)
            for i, (cell, ln) in enumerate(zip(self.cells, self.layer_norms)):
                h[i], c[i] = cell(x_t, (h[i], c[i]))
                h_norm = ln(h[i])
                x_t = self._apply_mask(h_norm, hidden_masks[i]) \
                      if i < self.n_layers - 1 else h_norm
            outputs.append(self.out(x_t).unsqueeze(1))     # (B, 1, C)

        logits = torch.cat(outputs, dim=1)      # (B, T, C)
        h_last = torch.stack(h)                 # (n_layers, B, H)
        c_last = torch.stack(c)                 # (n_layers, B, H)
        return logits, (h_last, c_last)


# ---------------------------------------------------------------------------
# Prediction
# ---------------------------------------------------------------------------

def predict_holdout(
    model:          SequenceLSTM,
    seqs:           dict[str, Any],
    dataset:        SequenceDataset,
    *,
    n_simulations:  int                       = 100,
    sim_chunk_size: int                       = 10,
    batch_size:     int                       = 256,
    device:         str | torch.device | None = None,
    verbose:        bool                      = True,
) -> np.ndarray:
    """
    Autoregressively predict transaction counts over the holdout period.

    Two-phase batched implementation:
      Phase 1 — calibration warm-up: DataLoader batches all N customers
                through the calibration sequence to obtain hidden states.
      Phase 2 — autoregressive rollout: all N × sim_chunk_size trajectories
                are stepped simultaneously, one week at a time.

    Memory scales as O(N × sim_chunk_size × n_layers × hidden_size).
    sim_chunk_size=10 keeps peak memory under ~200 MB for typical hidden sizes.

    Parameters
    ----------
    model           : trained SequenceLSTM.
    seqs            : output of build_transaction_sequences().
    dataset         : SequenceDataset built from the same seqs.
    n_simulations   : MC trajectories per customer. 1 → expected-value (no sampling).
    sim_chunk_size  : simulations processed in parallel. Lower = less memory.
                      Ignored when n_simulations == 1.
    batch_size      : customers per batch during calibration warm-up.
    device          : inference device (None = auto).
    verbose         : show progress bar.

    Returns
    -------
    pred_matrix : np.ndarray  shape (N_customers, H)
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device)
    model.to(device)
    model.eval()

    feature_names = seqs["feature_names"]
    week_idx      = feature_names.index("week")
    tx_idx        = feature_names.index("transactions")
    float_indices = dataset.float_indices
    n_classes     = dataset.n_classes

    N = len(seqs["calibration"])
    H = seqs["holdout"][0].shape[0]

    # ── pre-compute holdout tensors once ──────────────────────────────────
    holdout_arr    = np.stack(seqs["holdout"])                         # (N, H, F)
    holdout_weeks  = torch.from_numpy(
        holdout_arr[:, :, week_idx].astype(np.int64)
    ).to(device)                                                        # (N, H)
    holdout_floats = torch.from_numpy(
        holdout_arr[:, :, float_indices].astype(np.float32)
    ).to(device)                                                        # (N, H, n_float)

    # ── phase 1: calibration warm-up via DataLoader ───────────────────────
    calib_lens = [seqs["calibration"][i].shape[0] for i in range(N)]
    if len(set(calib_lens)) > 1:
        raise ValueError(
            f"Calibration sequences have variable lengths "
            f"({min(calib_lens)}–{max(calib_lens)}). "
            "All customers must share the same training period for batched prediction."
        )
    calib_arr = np.stack(seqs["calibration"])                          # (N, T, F)

    # ── phase 1: warm up by consuming the FULL calibration sequence ──────
    # Final state h_calib is the model's view "at the end of the training
    # period".  The output at the final calibration step (last_logits) is —
    # under the training contract that target[t] = transactions[t+1] — the
    # model's prediction for the FIRST holdout week's count.  We reuse those
    # logits as the first holdout prediction instead of re-running the model
    # with a synthetic input.  This matches the rollout in
    # LSTM_Based_Models.ipynb (cells 45/53/76).
    calib_ds = TensorDataset(
        torch.from_numpy(calib_arr[:, :, week_idx].astype(np.int64)),
        torch.from_numpy(
            np.clip(calib_arr[:, :, tx_idx].astype(np.int64), 0, n_classes - 1)
        ),
        torch.from_numpy(calib_arr[:, :, float_indices].astype(np.float32)),
    )
    calib_loader = DataLoader(calib_ds, batch_size=batch_size, shuffle=False)

    h_list, c_list, last_logits_list = [], [], []
    with torch.no_grad():
        calib_bar = tqdm(calib_loader, desc="Warming up calibration",
                         unit="batch", leave=False, disable=not verbose)
        for week_b, txn_b, float_b in calib_bar:
            logits_b, (h_b, c_b) = model(
                week_b.to(device), txn_b.to(device), float_b.to(device)
            )
            last_logits_list.append(logits_b[:, -1, :].cpu())   # (B, n_classes)
            h_list.append(h_b.cpu())
            c_list.append(c_b.cpu())

    h_calib     = torch.cat(h_list, dim=1).to(device)               # (n_layers, N, hidden)
    c_calib     = torch.cat(c_list, dim=1).to(device)
    last_logits = torch.cat(last_logits_list, dim=0).to(device)     # (N, n_classes)

    counts_t = torch.arange(n_classes, dtype=torch.float32, device=device)

    # ── phase 2: aligned autoregressive rollout ─────────────────────────
    # step_preds[0]   ← derived from last_logits      (predicts holdout week 0)
    # step_preds[k]   ← model output at iter k        (predicts holdout week k)
    #     iter k input = (holdout_weeks[k-1], previous prediction,
    #                     holdout_floats[k-1, :])  — week and floats are the
    #     PREVIOUS holdout step's features, matching the training contract
    #     where step t's input describes week t and the output predicts
    #     transactions[t+1].
    with torch.no_grad():

        if n_simulations == 1:
            # expected-value prediction — no sampling, no chunking needed
            h_r, c_r = h_calib.clone(), c_calib.clone()

            probs_first = torch.softmax(last_logits, dim=-1)            # (N, C)
            pred_first  = (probs_first * counts_t).sum(dim=-1)          # (N,)
            step_preds  = [pred_first.cpu()]
            prev_txn    = pred_first.round().long().clamp(0, n_classes - 1)

            week_bar = tqdm(range(1, H), desc="Predicting holdout",
                            unit="week", disable=not verbose)
            for k in week_bar:
                logits, (h_r, c_r) = model(
                    holdout_weeks[:, k - 1].unsqueeze(1),               # (N, 1)
                    prev_txn.unsqueeze(1),                              # (N, 1)
                    holdout_floats[:, k - 1, :].unsqueeze(1),           # (N, 1, n_float)
                    h0=h_r, c0=c_r,
                )
                probs    = torch.softmax(logits[:, 0, :], dim=-1)
                pred_val = (probs * counts_t).sum(dim=-1)
                step_preds.append(pred_val.cpu())
                prev_txn = pred_val.round().long().clamp(0, n_classes - 1)

            pred_matrix = torch.stack(step_preds, dim=1).numpy()        # (N, H)

        else:
            # MC sampling — chunk simulations to cap memory
            all_preds = torch.zeros(N, n_simulations, H)
            n_chunks  = (n_simulations + sim_chunk_size - 1) // sim_chunk_size
            sim_done  = 0

            chunk_bar = tqdm(range(n_chunks), desc="Predicting holdout",
                             unit="chunk", disable=not verbose)
            for _ in chunk_bar:
                S = min(sim_chunk_size, n_simulations - sim_done)

                h_r = h_calib.repeat_interleave(S, dim=1)               # (n_layers, N*S, hidden)
                c_r = c_calib.repeat_interleave(S, dim=1)

                # First prediction for each trajectory: sample from last_logits
                last_logits_rep = last_logits.repeat_interleave(S, dim=0)   # (N*S, C)
                probs_first     = torch.softmax(last_logits_rep, dim=-1)
                sampled_first   = torch.multinomial(probs_first, 1).squeeze(1)

                weeks_rep  = holdout_weeks.repeat_interleave(S, dim=0)  # (N*S, H)
                floats_rep = holdout_floats.repeat_interleave(S, dim=0) # (N*S, H, n_float)

                chunk_preds = torch.zeros(N * S, H, device=device)
                chunk_preds[:, 0] = sampled_first.float()
                prev_txn = sampled_first.clamp(0, n_classes - 1)

                for k in range(1, H):
                    logits, (h_r, c_r) = model(
                        weeks_rep[:, k - 1].unsqueeze(1),               # (N*S, 1)
                        prev_txn.unsqueeze(1),                          # (N*S, 1)
                        floats_rep[:, k - 1, :].unsqueeze(1),           # (N*S, 1, n_float)
                        h0=h_r, c0=c_r,
                    )
                    probs   = torch.softmax(logits[:, 0, :], dim=-1)
                    sampled = torch.multinomial(probs, 1).squeeze(1)
                    chunk_preds[:, k] = sampled.float()
                    prev_txn = sampled.clamp(0, n_classes - 1)

                all_preds[:, sim_done:sim_done + S, :] = (
                    chunk_preds.cpu().reshape(N, S, H)
                )
                sim_done += S
                chunk_bar.set_postfix(sims=f"{sim_done}/{n_simulations}")

            pred_matrix = all_preds.mean(dim=1).numpy()                 # (N, H)

    return pred_matrix


# ---------------------------------------------------------------------------
# Optuna hyperparameter search  (requires: pip install optuna)
# ---------------------------------------------------------------------------

def _build_objective(
    train_ds,
    val_ds,
    n_classes:    int,
    n_float:      int,
    max_epochs:   int,
    device:       torch.device,
    fixed:        dict[str, Any],
):
    """
    Return an Optuna objective function closed over the pre-split datasets.

    Each trial builds a SequenceLSTM with hyperparameters suggested by Optuna
    (or taken from `fixed`), trains with early stopping, and returns the best
    validation loss. The model and optimizer are deleted after each trial to
    free memory.
    """
    import optuna

    def objective(trial: optuna.Trial) -> float:
        def _fix_or(name, suggest_fn):
            return fixed[name] if name in fixed else suggest_fn()

        hidden_size = _fix_or("hidden_size", lambda: trial.suggest_categorical("hidden_size", [64, 128, 256]))
        n_layers    = _fix_or("n_layers",    lambda: trial.suggest_int("n_layers", 1, 3))
        dropout     = _fix_or("dropout",     lambda: trial.suggest_float("dropout", 0.0, 0.4))
        lr          = _fix_or("lr",          lambda: trial.suggest_float("lr", 1e-4, 1e-1, log=True))
        patience    = _fix_or("patience",    lambda: trial.suggest_int("patience", 5, 15))
        batch_size  = _fix_or("batch_size",  lambda: trial.suggest_categorical("batch_size", [256, 512, 1024]))

        model = SequenceLSTM(
            n_weeks=52,
            n_classes=n_classes,
            n_float=n_float,
            hidden_size=hidden_size,
            n_layers=n_layers,
            dropout=dropout,
        ).to(device)

        optimizer    = optim.Adam(model.parameters(), lr=lr)
        loss_fn      = nn.CrossEntropyLoss()
        train_loader = DataLoader(train_ds, batch_size=batch_size,
                                  shuffle=True,  drop_last=False)
        val_loader   = DataLoader(val_ds,   batch_size=batch_size * 2,
                                  shuffle=False, drop_last=False)

        best_val   = float("inf")
        bad_epochs = 0
        best_epoch = 0

        for epoch in range(1, max_epochs + 1):
            model.train()
            for week, txn, floats, y in train_loader:
                week, txn, floats, y = (t.to(device) for t in (week, txn, floats, y))
                optimizer.zero_grad()
                logits, _ = model(week, txn, floats)
                B, T, C   = logits.shape
                loss      = loss_fn(logits.reshape(B * T, C), y.reshape(B * T))
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()

            model.eval()
            val_loss, val_n = 0.0, 0
            with torch.no_grad():
                for week, txn, floats, y in val_loader:
                    week, txn, floats, y = (t.to(device) for t in (week, txn, floats, y))
                    logits, _ = model(week, txn, floats)
                    B, T, C   = logits.shape
                    loss      = loss_fn(logits.reshape(B * T, C), y.reshape(B * T))
                    val_loss += loss.item() * (B * T)
                    val_n    += B * T
            avg_val = val_loss / max(1, val_n)

            trial.report(avg_val, epoch)
            if trial.should_prune():
                raise optuna.TrialPruned()

            if avg_val < best_val - 1e-6:
                best_val, bad_epochs, best_epoch = avg_val, 0, epoch
            else:
                bad_epochs += 1
                if bad_epochs >= patience:
                    break

        del model, optimizer
        torch.cuda.empty_cache()
        gc.collect()

        trial.set_user_attr("best_epoch", best_epoch)
        return best_val

    return objective


def tune_lstm(
    seqs:          dict[str, Any],
    train_dataset,
    val_dataset,
    *,
    n_trials:      int                       = 30,
    max_epochs:    int                       = 100,
    storage:       str | None                = None,
    study_name:    str | None                = None,
    device:        str | torch.device | None = None,
    verbose:       bool                      = True,
    fixed_params:  dict[str, Any] | None     = None,
):
    """
    Run (or resume) an Optuna hyperparameter search for SequenceLSTM.

    The train/val split is your responsibility — pass pre-built subsets so you
    control the seed and fraction. Use make_train_val_split() or any PyTorch
    random_split() to build them.

    Tunable hyperparameters (all can be fixed via fixed_params):
      hidden_size : categorical  [64, 128, 256]
      n_layers    : int          1 – 3
      dropout     : float        0.0 – 0.4
      lr          : float        1e-4 – 1e-1  (log scale)
      patience    : int          5 – 15
      batch_size  : categorical  [256, 512, 1024]

    Parameters
    ----------
    seqs          : output of build_transaction_sequences().
    train_dataset : training subset (from make_train_val_split).
    val_dataset   : validation subset (from make_train_val_split).
    n_trials      : number of Optuna trials to run.
    max_epochs    : maximum epochs per trial.
    storage       : Optuna storage URL, e.g. "sqlite:///optuna_lstm.db".
                    None keeps results in-memory (lost when Python exits).
    study_name    : name for the study. None = auto.
    device        : torch device. None = auto (CUDA if available, else CPU).
    verbose       : print progress and best params on completion.
    fixed_params  : hyperparameters to fix instead of tuning.
                    Any key present here is used as-is; the rest are tuned.
                    Example: fixed_params={"patience": 10, "batch_size": 512}

    Returns
    -------
    optuna.Study — inspect .best_params, .best_value, .trials, etc.

    Example
    -------
    ds               = SequenceDataset(seqs)
    train_ds, val_ds = make_train_val_split(ds, val_fraction=0.1, seed=42)

    study = tune_lstm(
        seqs, train_ds, val_ds,
        n_trials=30,
        fixed_params={"patience": 10},
        storage="sqlite:///optuna_lstm.db",
    )
    model = train_tuned_lstm(seqs, study, train_ds, val_ds)
    preds = predict_holdout(model, seqs, ds)
    metrics = evaluate_predictions(preds, seqs)
    """
    import optuna

    fixed = fixed_params or {}

    ds = SequenceDataset(seqs)

    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device)

    if verbose:
        _ALL_PARAMS = {"hidden_size", "n_layers", "dropout", "lr", "patience", "batch_size"}
        tuned  = sorted(_ALL_PARAMS - fixed.keys())
        pinned = sorted(fixed.keys())
        sep = "─" * 52
        print(sep)
        print("  tune_lstm")
        print(sep)
        print(f"  Train customers : {len(train_dataset)}")
        print(f"  Val   customers : {len(val_dataset)}")
        if tuned:
            print(f"  Tuning   : {tuned}")
        if pinned:
            print(f"  Fixed    : { {k: fixed[k] for k in pinned} }")
        print(f"  Trials   : {n_trials}   max_epochs: {max_epochs}")
        print(f"  Device   : {device}")
        print(sep)

    pruner = optuna.pruners.HyperbandPruner(
        min_resource=5,
        max_resource=max_epochs,
        reduction_factor=3,
    )
    study = optuna.create_study(
        direction="minimize",
        pruner=pruner,
        storage=storage,
        study_name=study_name,
        load_if_exists=True,
    )
    optuna.logging.set_verbosity(
        optuna.logging.INFO if verbose else optuna.logging.WARNING
    )
    study.optimize(
        _build_objective(train_dataset, val_dataset, ds.n_classes, ds.n_float,
                         max_epochs, device, fixed),
        n_trials=n_trials,
        show_progress_bar=verbose,
    )

    if verbose:
        print(f"Best params   : {study.best_params}")
        print(f"Best val loss : {study.best_value:.6f}")

    return study


def train_tuned_lstm(
    seqs:    dict[str, Any],
    study,
    train_dataset,
    val_dataset,
    *,
    device:  str | torch.device | None = None,
    verbose: bool = True,
) -> tuple[SequenceLSTM, dict[str, list[float]]]:
    """
    Retrain SequenceLSTM with the best hyperparameters found by tune_lstm().

    Pass the same train_dataset / val_dataset you used in tune_lstm() so the
    final model is evaluated on the same split.

    Parameters
    ----------
    seqs          : output of build_transaction_sequences().
    study         : optuna.Study returned by tune_lstm().
    train_dataset : training subset (same one passed to tune_lstm).
    val_dataset   : validation subset (same one passed to tune_lstm).
    device        : torch device. None = auto.
    verbose       : show tqdm training progress.

    Returns
    -------
    (model, history) — SequenceLSTM ready for predict_holdout(),
    and the per-epoch loss dict from train_model().

    Example
    -------
    ds               = SequenceDataset(seqs)
    train_ds, val_ds = make_train_val_split(ds, val_fraction=0.1, seed=42)

    study           = tune_lstm(seqs, train_ds, val_ds, n_trials=30)
    model, history  = train_tuned_lstm(seqs, study, train_ds, val_ds)
    preds           = predict_holdout(model, seqs, ds)
    metrics         = evaluate_predictions(preds, seqs)
    """
    p  = study.best_params
    ds = SequenceDataset(seqs)

    model = SequenceLSTM(
        n_weeks=52, #Hardcoded, need to find solution later
        n_classes=ds.n_classes,
        n_float=ds.n_float,
        hidden_size=p["hidden_size"],
        n_layers=p.get("n_layers", 1),
        dropout=p.get("dropout", 0.0),
    )

    history = train_model(
        model,
        train_dataset,
        val_dataset,
        lr=p["lr"],
        epochs=200,
        patience=p.get("patience", 8),
        batch_size=p.get("batch_size", 512),
        device=device,
        verbose=verbose,
    )

    return model, history
