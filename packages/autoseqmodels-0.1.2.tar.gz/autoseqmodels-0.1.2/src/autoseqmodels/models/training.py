"""
Model-agnostic training utilities for sequence models.

These were originally part of sequence_lstm.py but are not LSTM-specific —
any model with a forward signature ``(week, txn, floats, …) -> (logits, …)``
can use them.  The transformer (sequence_transformer.py) reuses them as-is.

Public API:
  SequenceDataset                — wraps build_transaction_sequences() output
  make_train_val_split           — random customer-level train/val split
  train_model                    — Adam + CrossEntropy + grad clip + early stopping
  evaluate_predictions           — Bias, RMSE, volume-weighted MAPE
  plot_training_and_predictions  — diagnostic two-panel figure
"""

from __future__ import annotations

from typing import Any

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset, random_split
from tqdm.auto import tqdm


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class SequenceDataset(Dataset):
    """
    Wraps the output dict of build_transaction_sequences().

    Each item is one customer's full training sequence:
      week_seq   (T-1,)          int64  — week index 0-51
      txn_seq    (T-1,)          int64  — past transaction count (model input)
      float_seq  (T-1, n_float)  float32 — seasonality / covariate features
      target_seq (T-1,)          int64  — next-week transaction count (label)

    Parameters
    ----------
    seqs : dict
        Output of build_transaction_sequences().
    max_transactions : int | None
        Clip transaction counts at this value. Derives from data if None.
    """

    def __init__(
        self,
        seqs: dict[str, Any],
        max_transactions: int | None = None,
    ):
        # ── Locate the special feature columns by name ────────────────────
        # `week` and `transactions` are embedded by the model (nn.Embedding);
        # all other columns are concatenated as raw float features.  We cache
        # their positions so per-customer slicing in the loop below is cheap.
        feature_names = seqs["feature_names"]
        self.week_idx = feature_names.index("week")
        self.tx_idx   = feature_names.index("transactions")
        self.float_indices = [
            i for i in range(len(feature_names))
            if i != self.week_idx and i != self.tx_idx
        ]
        self.float_names = [feature_names[i] for i in self.float_indices]
        self.n_float = len(self.float_indices)

        # ── Determine the classification head's output size ──────────────
        # The model treats the prediction as classification over discrete
        # weekly counts {0, 1, …, max_transactions}.  Default to the largest
        # observed count in training so no class is wasted; the caller can
        # override (e.g. to match a previously-trained model).
        if max_transactions is None:
            all_tx = np.concatenate([t for t in seqs["targets"]])
            max_transactions = int(all_tx.max())
        self.max_transactions = max_transactions
        self.n_classes = max_transactions + 1   # classes: 0, 1, …, max_trans

        # ── Split each customer's (T-1, n_features) array into 4 streams ─
        # The model takes (week, txn, floats) as separate inputs because
        # week and txn go through their own embedding tables.  Clipping the
        # txn input AND the target to max_transactions keeps every value a
        # valid class index — anything larger would crash CrossEntropyLoss
        # / nn.Embedding lookups.
        self._data: list[tuple] = []
        for sample, target in zip(seqs["samples"], seqs["targets"]):
            week_seq  = sample[:, self.week_idx].astype(np.int64)
            txn_seq   = np.clip(sample[:, self.tx_idx].astype(np.int64), 0, max_transactions)
            float_seq = sample[:, self.float_indices].astype(np.float32)
            tgt_seq   = np.clip(target.astype(np.int64), 0, max_transactions)
            self._data.append((week_seq, txn_seq, float_seq, tgt_seq))

        # Customer IDs are kept aligned with self._data so predictions can
        # be mapped back to source rows after training.
        self.account_ids = list(seqs["account_ids"])

        # ── Pre-stack into (N, …) tensors ────────────────────────────────
        # Every sequence shares the same T-1 length (same universal calendar),
        # so np.stack works.  These pre-stacked tensors are unused by the
        # DataLoader path (which calls __getitem__) but speed up direct
        # indexing — e.g. predict_holdout reads them when chunking by
        # customer rather than by batch.
        self.week    = torch.from_numpy(np.stack([w for w, _, _, _ in self._data]))
        self.txn     = torch.from_numpy(np.stack([t for _, t, _, _ in self._data]))
        self.floats  = torch.from_numpy(np.stack([f for _, _, f, _ in self._data]))
        self.targets = torch.from_numpy(np.stack([y for _, _, _, y in self._data]))

    def __len__(self) -> int:
        """Number of customers in the dataset."""
        return len(self._data)

    def __getitem__(self, idx: int):
        """Return (week_seq, txn_seq, float_seq, target_seq) tensors for customer idx."""
        w, t, f, y = self._data[idx]
        return (
            torch.from_numpy(w),
            torch.from_numpy(t),
            torch.from_numpy(f),
            torch.from_numpy(y),
        )


# ---------------------------------------------------------------------------
# Train / val split
# ---------------------------------------------------------------------------

def make_train_val_split(
    dataset: SequenceDataset,
    val_fraction: float = 0.1,
    seed: int = 42,
):
    """
    Random customer-level train / val split of a SequenceDataset.

    Returns (train_subset, val_subset) — both are compatible with DataLoader.
    """
    n_val   = max(1, round(len(dataset) * val_fraction))
    n_train = len(dataset) - n_val
    return random_split(
        dataset,
        [n_train, n_val],
        generator=torch.Generator().manual_seed(seed),
    )


# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------

def train_model(
    model:        nn.Module,
    train_dataset,
    val_dataset,
    *,
    lr:           float = 1e-3,
    epochs:       int   = 100,
    patience:     int   = 8,
    batch_size:   int   = 256,
    val_batch:    int   = 1024,
    device:       str | torch.device | None = None,
    verbose:      bool  = True,
) -> dict[str, list[float]]:
    """
    Train any sequence model that returns (logits, _) from forward.

    Adam + CrossEntropyLoss, gradient clipping at 1.0, early stopping with
    `patience` epochs of no improvement.  Restores best weights at the end.

    Parameters
    ----------
    model         : nn.Module whose forward returns (logits, _).
    train_dataset : training subset (from make_train_val_split or SequenceDataset).
    val_dataset   : validation subset.
    lr            : Adam learning rate.
    epochs        : maximum number of epochs.
    patience      : early-stopping patience (epochs without val improvement).
    batch_size    : training batch size (customers per batch).
    val_batch     : validation batch size.
    device        : "cpu" / "cuda" / None (auto-detect).
    verbose       : print loss each epoch.

    Returns
    -------
    dict with "train_loss" and "val_loss" lists (one entry per epoch run).
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device)
    model.to(device)

    optimizer    = optim.Adam(model.parameters(), lr=lr)
    loss_fn      = nn.CrossEntropyLoss()
    train_loader = DataLoader(train_dataset, batch_size=batch_size,  shuffle=True,  drop_last=False)
    val_loader   = DataLoader(val_dataset,   batch_size=val_batch,   shuffle=False, drop_last=False)

    history    = {"train_loss": [], "val_loss": []}
    best_val   = float("inf")
    bad_epochs = 0
    best_state = None

    epoch_bar = tqdm(range(1, epochs + 1), desc="Training", unit="epoch", disable=not verbose)

    for epoch in epoch_bar:

        # ── train ─────────────────────────────────────────────────────────
        model.train()
        train_loss  = 0.0
        batch_bar   = tqdm(train_loader, desc=f"  Epoch {epoch:3d} train",
                           leave=False, unit="batch", disable=not verbose)
        for week, txn, floats, y in batch_bar:
            week, txn, floats, y = (t.to(device) for t in (week, txn, floats, y))
            optimizer.zero_grad()
            logits, _ = model(week, txn, floats)
            B, T, C   = logits.shape
            loss      = loss_fn(logits.reshape(B * T, C), y.reshape(B * T))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            train_loss += loss.item()
            batch_bar.set_postfix(loss=f"{loss.item():.4f}")
        train_loss /= max(1, len(train_loader))

        # ── validate ──────────────────────────────────────────────────────
        model.eval()
        val_loss = 0.0
        val_n    = 0
        with torch.no_grad():
            for week, txn, floats, y in val_loader:
                week, txn, floats, y = (t.to(device) for t in (week, txn, floats, y))
                logits, _ = model(week, txn, floats)
                B, T, C   = logits.shape
                loss      = loss_fn(logits.reshape(B * T, C), y.reshape(B * T))
                val_loss  += loss.item() * (B * T)
                val_n     += B * T
        val_loss /= max(1, val_n)

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)

        # ── update epoch bar with live metrics ─────────────────────────────
        epoch_bar.set_postfix(
            train=f"{train_loss:.4f}",
            val=f"{val_loss:.4f}",
            best=f"{best_val:.4f}",
            bad=bad_epochs,
        )

        # ── early stopping ─────────────────────────────────────────────────
        if val_loss < best_val - 1e-6:
            best_val   = val_loss
            bad_epochs = 0
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        else:
            bad_epochs += 1
            if bad_epochs >= patience:
                epoch_bar.set_description(f"Early stop (best val={best_val:.4f})")
                epoch_bar.close()
                break

    if best_state is not None:
        model.load_state_dict(best_state)
        model.to(device)

    return history


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------

def evaluate_predictions(
    pred_matrix: np.ndarray,
    seqs:        dict[str, Any],
    *,
    verbose: bool = True,
) -> dict[str, float]:
    """
    Compute Bias, RMSE, and volume-weighted MAPE matching LSTM_Based_Models.ipynb.

    Metrics
    -------
    Bias (%) : 100 * (Σpred − Σactual) / Σactual
    RMSE     : sqrt(mean((pred_ij − actual_ij)²))   — individual level
    MAPE (%) : 100 * Σ|pred_w − actual_w| / Σactual_w   — volume-weighted (Eq. 5)

    The textbook per-week MAPE (mean over weeks of |Δ| / actual) is omitted
    because it explodes when actual_w = 0, which is the common case for
    sparse transaction data.

    Parameters
    ----------
    pred_matrix : (N, H) — output of predict_holdout / predict_holdout_transformer.
    seqs        : output of build_transaction_sequences().

    Returns
    -------
    dict with keys: bias_pct, rmse, mape_pct
    """
    tx_idx = seqs["feature_names"].index("transactions")
    actual_matrix = np.stack([
        h[:, tx_idx] for h in seqs["holdout"]
    ]).astype(np.float32)   # (N, H)

    bias_pct = 100.0 * (pred_matrix.sum() - actual_matrix.sum()) / (actual_matrix.sum() + 1e-9)
    rmse     = float(np.sqrt(np.mean((pred_matrix - actual_matrix) ** 2)))

    pred_agg   = pred_matrix.sum(0)    # (H,) — total predicted per holdout week
    actual_agg = actual_matrix.sum(0)  # (H,)
    mape_pct = 100.0 * float(
        np.sum(np.abs(pred_agg - actual_agg)) / (np.sum(actual_agg) + 1e-9)
    )

    if verbose:
        sep = "─" * 50
        print(sep)
        print("  Holdout evaluation")
        print(sep)
        print(f"  Customers     : {pred_matrix.shape[0]}")
        print(f"  Holdout weeks : {pred_matrix.shape[1]}")
        print()
        print(f"  Bias  : {bias_pct:+.2f}%")
        print(f"  RMSE  : {rmse:.4f}")
        print(f"  MAPE  : {mape_pct:.2f}%   [volume-weighted, paper Eq. 5]")
        print(sep)

    return {
        "bias_pct": float(bias_pct),
        "rmse":     rmse,
        "mape_pct": float(mape_pct),
    }


# ---------------------------------------------------------------------------
# Visualisation
# ---------------------------------------------------------------------------

def plot_training_and_predictions(
    history:     dict[str, list[float]],
    predictions: np.ndarray,
    seqs:        dict[str, Any],
    *,
    figsize:     tuple[float, float] = (13, 4),
    save_path:   str | None          = None,
):
    """
    Two-panel diagnostic plot.

    Panel 1 (left)  — training and validation cross-entropy loss per epoch.
    Panel 2 (right) — total weekly transactions across all customers,
                      actual vs predicted, over the holdout period.

    Parameters
    ----------
    history     : dict returned by train_model().
    predictions : (N_customers, H_weeks) ndarray from predict_holdout*.
    seqs        : dict from build_transaction_sequences() — needed to read
                  the actual holdout transaction counts.
    figsize     : matplotlib figure size.
    save_path   : optional path to save the figure (PNG/PDF/SVG).

    Returns
    -------
    matplotlib.figure.Figure
    """
    import matplotlib.pyplot as plt

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)

    # ── panel 1: loss curves ─────────────────────────────────────────────
    epochs = range(1, len(history["train_loss"]) + 1)
    ax1.plot(epochs, history["train_loss"], label="Train", linewidth=2)
    ax1.plot(epochs, history["val_loss"],   label="Val",   linewidth=2)
    best_epoch = int(np.argmin(history["val_loss"])) + 1
    best_val   = min(history["val_loss"])
    ax1.axvline(best_epoch, color="grey", linestyle="--", alpha=0.5,
                label=f"Best epoch ({best_epoch})")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Cross-entropy loss  (log scale)")
    ax1.set_yscale("log")
    ax1.set_title(f"Training history  (best val = {best_val:.4f})")
    ax1.legend()
    ax1.grid(alpha=0.3, which="both")

    # ── panel 2: predicted vs actual weekly volume ───────────────────────
    feature_names = seqs["feature_names"]
    tx_idx        = feature_names.index("transactions")
    holdout_arr   = np.stack(seqs["holdout"])                  # (N, H, F)
    actual_per_wk = holdout_arr[:, :, tx_idx].sum(axis=0)      # (H,)
    pred_per_wk   = predictions.sum(axis=0)                    # (H,)

    weeks = np.arange(len(actual_per_wk))
    ax2.plot(weeks, actual_per_wk, label="Actual",    linewidth=2)
    ax2.plot(weeks, pred_per_wk,   label="Predicted", linewidth=2, alpha=0.8)
    ax2.set_xlabel("Holdout week")
    ax2.set_ylabel("Total transactions (all customers)")
    ax2.set_title("Predicted vs actual weekly volume")
    ax2.legend()
    ax2.grid(alpha=0.3)

    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    # Close to prevent Jupyter from rendering the figure twice
    # (once auto-displayed by %matplotlib inline, once via the return value).
    plt.close(fig)
    return fig
