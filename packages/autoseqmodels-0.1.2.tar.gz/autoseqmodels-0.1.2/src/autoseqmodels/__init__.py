"""autoseqmodels — pre-aggregated weekly sequence-model workflow for transaction prediction.

Single workflow (matches Data_integration.ipynb):

    1.  loader.load_table                       — read CSV / Excel / RData
    2.  loader.build_transaction_panel          — aggregate to (customer, week)
    3.  inspection.infer_column_types           — detect dtypes (user editable)
    4.  inspection.cast_columns_by_detected_type
    5.  inspection.analyze_structure            — DataStructure + CovariatePlan
    6.  encoders.propose_encodings              — strategy dict (user editable)
    7.  encoders.apply_encodings + expand_plan  — fit on training rows only
    8.  sequence_builder.build_transaction_sequences   — per-customer sequences

    Generic model utilities (training.py):
      training.SequenceDataset
      training.make_train_val_split
      training.train_model
      training.evaluate_predictions
      training.plot_training_and_predictions

    LSTM-specific (sequence_lstm.py):
      SequenceLSTM, predict_holdout, tune_lstm, train_tuned_lstm

    Transformer-specific (sequence_transformer.py):
      SequenceTransformer, predict_holdout_transformer,
      tune_transformer, train_tuned_transformer
"""

from .data_prep import inspection, loader, encoders, sequence_builder
from .models import training, sequence_lstm, sequence_transformer

__all__ = [
    "inspection",
    "loader",
    "encoders",
    "sequence_builder",
    "training",
    "sequence_lstm",
    "sequence_transformer",
]
