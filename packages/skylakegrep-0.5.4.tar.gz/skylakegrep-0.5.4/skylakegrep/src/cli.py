"""Command-line entry point for ``skygrep``.

Two-mode CLI:

  - **Bare-form** (95% of use): ``skygrep "<query>"`` runs a search with smart
    defaults. The first argument is treated as a query whenever it isn't a
    known subcommand. Auto-index runs the first time a project is queried,
    incremental refresh runs on subsequent queries when files have changed.
  - **Subcommand form** (admin / power use): ``skygrep <verb> [args]`` for
    ``index``, ``watch``, ``serve``, ``stats``, ``doctor``, and the explicit
    ``search`` form. ``skygrep --help`` prints the full surface.

Routing rule: known subcommands win. Anything that isn't a known subcommand
is treated as the first argument to ``search``. A query that happens to
collide with a subcommand name (rare) can be quoted: ``skygrep "stats and
metrics"`` searches; ``skygrep stats`` runs the subcommand.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import sys
import time
from pathlib import Path

import click

logger = logging.getLogger(__name__)

from . import auto_index, bootstrap, code_graph, config as cfg_mod, enrich as enrich_mod, integrations as integrations_mod
from .answerer import get_answerer
from .config import get_config
from .embeddings import get_embedder
from .indexer import batch_embed, collect_indexable_files, prepare_file_chunks
from .intent import classify_intent, merge_results as merge_tiers
from .llm_router import RouterDecision, route_query
from .intelligent_cli import (
    assess_result_quality,
    detect_out_of_scope,
    hints_disabled,
    mark_first_run_nudge_shown,
    render_first_run_nudge,
    render_out_of_scope_hint,
    should_show_first_run_nudge,
    suggest_for_unknown_option,
)
from .recovery import (
    get_recovery_state,
    maybe_start_recovery,
    render_recovery_footer,
)
from .render import render_compact_source, render_terminal_result
from .storage import (
    CASCADE_DEFAULT_TAU,
    cascade_search,
    delete_file_chunks,
    delete_missing_files,
    get_indexed_files,
    init_db,
    populate_file_embeddings,
    populate_symbols,
    search,
    store_chunks_batch,
)


def _symbols_table_populated(conn) -> bool:
    """Return True iff the ``symbols`` table has at least one row.

    Wrapped because the table may be missing on databases built before L2.
    The init_db pass adds the table, but the underlying sqlite query is
    cheap enough that a try/except is the simplest contract.
    """

    try:
        row = conn.execute("SELECT EXISTS (SELECT 1 FROM symbols LIMIT 1)").fetchone()
    except sqlite3.Error:
        return False
    return bool(row and row[0])


def merge_results(result_groups: list[list[dict]], top: int) -> list[dict]:
    merged = {}
    for results in result_groups:
        for result in results:
            key = (
                result["path"],
                result.get("start_line"),
                result.get("end_line"),
                result["snippet"],
            )
            if key not in merged or result["score"] > merged[key]["score"]:
                merged[key] = result
    return sorted(merged.values(), key=lambda item: item["score"], reverse=True)[:top]


def render_json_results(results: list[dict]) -> str:
    payload = [
        {
            "path": r["path"],
            "start_line": r["start_line"],
            "end_line": r["end_line"],
            "language": r["language"],
            "score": float(r["score"]),
            "snippet": r["snippet"],
        }
        for r in results
    ]
    return json.dumps(payload, indent=2)


# Subcommand names that take precedence over bare-form query routing.
_SUBCOMMANDS = {"index", "search", "watch", "serve", "stats", "doctor", "enrich", "setup"}


class MgrepCLI(click.Group):
    """Click group that routes unknown first-args to ``search``.

    Implements two adjustments to default Click behaviour:
      - ``skygrep "<query>"`` (no subcommand) routes to ``search "<query>"``.
      - ``skygrep stats and metrics`` (subcommand-shaped but with extra args
        that don't fit) prints a friendly suggestion to quote the query.
    """

    def parse_args(self, ctx, args):  # type: ignore[override]
        # If first non-flag token is not a known subcommand, treat the whole
        # arg list as the search query.
        if args and not args[0].startswith("-") and args[0] not in _SUBCOMMANDS:
            return super().parse_args(ctx, ["search", *args])
        return super().parse_args(ctx, args)


@click.group(cls=MgrepCLI, invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """``skygrep`` — local semantic code search.

    Common usage:

        skygrep "where is the auth token refreshed?"      # bare query
        skygrep doctor                                    # health check
        skygrep stats                                     # index info
        skygrep index .                                   # explicit reindex
    """

    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@cli.command()
@click.argument("path", default=".")
@click.option("--reset", is_flag=True, help="Reset existing index before reindexing")
@click.option("--incremental/--full", default=True, help="Only update changed files")
def index(path: str, reset: bool, incremental: bool):
    """Build or refresh the index explicitly. ``skygrep search`` already
    auto-indexes the first time you query a project; use this command for
    forced full rebuilds, ``--reset`` after switching embedding models, or
    indexing a directory other than the current working tree."""

    config = get_config()
    db_path = config["db_path"]
    if reset and db_path.exists():
        db_path.unlink()
    conn = init_db(db_path)
    embedder = get_embedder()

    root = Path(path)
    files = collect_indexable_files(root)

    click.echo(f"Found {len(files)} files to index")

    if incremental and not reset:
        indexed_files = get_indexed_files(conn)
        deleted_files = delete_missing_files(conn, {str(f) for f in files}, root)
        to_index = []
        to_reindex = []
        for f in files:
            f_str = str(f)
            if f_str not in indexed_files:
                to_index.append(f)
            elif f.stat().st_mtime > indexed_files[f_str]:
                to_reindex.append(f)
        click.echo(
            f"Incremental: {len(to_index)} new, {len(to_reindex)} changed, "
            f"{len(deleted_files)} deleted"
        )
        files_to_process = to_index + to_reindex
    else:
        files_to_process = files

    if not files_to_process:
        click.echo("No files to index")
        return

    click.echo(f"Indexing {len(files_to_process)} files...")
    total_chunks = 0
    for f in files_to_process:
        chunks = prepare_file_chunks(f, root=root)
        if chunks:
            chunks = batch_embed(chunks, embedder, batch_size=10)
            for c in chunks:
                delete_file_chunks(conn, c["file"])
            store_chunks_batch(conn, chunks)
            total_chunks += len(chunks)
            click.echo(f"  Indexed: {f} ({len(chunks)} chunks)")

    click.echo(
        f"Indexing complete! {total_chunks} chunks in {len(files_to_process)} files"
    )
    file_count = populate_file_embeddings(conn)
    click.echo(
        f"File-level embeddings populated: {file_count} files (mean of chunk vectors)"
    )
    # Mark refresh state so subsequent searches skip the throttle.
    auto_index._meta_set(conn, "last_full_index_at", str(time.time()))
    auto_index._meta_set(conn, "last_refresh_at", str(time.time()))


@cli.command()
@click.argument("query")
@click.option("--top", "-n", "-m", default=5, help="Number of results")
@click.option("--json", "json_output", is_flag=True, help="Emit stable JSON results")
@click.option("--answer", is_flag=True, help="Synthesize a local Ollama answer from search results")
@click.option("--content/--no-content", default=True, help="Show or hide matched snippets")
@click.option("--language", multiple=True, help="Restrict results to language(s)")
@click.option("--include", "include_patterns", multiple=True, help="Include only matching paths")
@click.option("--exclude", "exclude_patterns", multiple=True, help="Exclude matching paths")
@click.option("--agentic", is_flag=True, help="Use local Ollama to split the query into bounded subqueries")
@click.option("--max-subqueries", default=3, help="Maximum local agentic subqueries")
@click.option("--semantic-only", is_flag=True, help="Disable local lexical reranking and use pure vector similarity")
@click.option("--rerank/--no-rerank", default=True, help="Apply cross-encoder reranking on the non-cascade path (default on when sentence-transformers is installed)")
@click.option("--rerank-pool", default=None, type=int, help="Candidate pool size before reranking (default 50, env SKYGREP_RERANK_POOL)")
@click.option("--rerank-model", default=None, help="HuggingFace cross-encoder model id for reranking")
@click.option("--hyde/--no-hyde", default=False, help="Force a HyDE rewrite even outside the cascade (rarely needed; the cascade decides per query)")
@click.option("--multi-resolution/--no-multi-resolution", default=True, help="Two-stage retrieval: pick top-N files by file-level cosine first, then drill into their chunks (helps small canonical files compete against large consumer files)")
@click.option("--file-top", default=30, type=int, help="Number of files surfaced by file-level retrieval before chunk-level scoring (only used with --multi-resolution)")
@click.option("--lexical-prefilter/--no-lexical-prefilter", default=True, help="Use ripgrep to narrow the candidate file set before cosine + rerank (default on; the high-recall fast path)")
@click.option("--lexical-root", default=None, help="Root directory ripgrep scans for the lexical prefilter (defaults to the project root)")
@click.option("--lexical-min-candidates", default=2, type=int, help="If ripgrep returns fewer than this many candidate files we fall back to corpus-wide cosine retrieval")
@click.option("--daemon-url", default=None, help="If set, send the search to a running skygrep daemon instead of loading the reranker in-process (eliminates cold-load latency)")
@click.option("--rank-by", default="chunk", type=click.Choice(["chunk", "file"]), help="Ranking strategy on the non-cascade path: 'chunk' returns top-K chunks with per-file diversity cap; 'file' returns one best chunk per file")
@click.option("--cascade/--no-cascade", default=True, help="Confidence-gated retrieval (default on): cheap file-mean cosine first, escalate to HyDE-union only on uncertain queries. Pass --no-cascade for the chunk-only legacy path.")
@click.option("--cascade-tau", default=CASCADE_DEFAULT_TAU, type=float, help=f"Confidence threshold (top1 - top2 file-mean cosine) above which the cascade returns the cheap result. Default {CASCADE_DEFAULT_TAU}.")
@click.option("--auto-index/--no-auto-index", default=None, help="Auto-build the index for this project on first query and refresh on subsequent queries. Default: on for the project-scoped DB; off when SKYGREP_DB_PATH is set externally so curated indexes are not auto-mutated.")
@click.option("--rg-shortcut/--no-rg-shortcut", default=True, help="Lexical pre-gate: if the query is short and ripgrep returns a small, clustered, path-token-overlapping result set, return the rg result directly and skip the semantic cascade. Default on. Pass --no-rg-shortcut to force pure cascade (useful for benchmarking).")
@click.option("--filename-shortcut/--no-filename-shortcut", default=True, help="Filename-lookup pre-gate (v0.13.0+): when the query looks like 'where is foo file' / 'find package.json', route to `find -iname '*token*'` and skip both content shortcuts. Default on. Pass --no-filename-shortcut to disable.")
@click.option("--llm-router/--no-llm-router", default=True, help="LLM-driven query understanding (v0.15.0+). Routes queries via a small local Ollama model (default qwen2.5:3b) for generic intent classification. Falls back to v0.14.0 hand-rolled rules on any failure. Pass --no-llm-router to force the rule-based fallback.")
@click.option("--detail", default="standard", type=click.Choice(["brief", "standard", "full", "summary"]), help="Output verbosity. `brief` = path + score one-liner. `standard` = +10 lines body (default). `full` = +full extracted PDF/docx content for filename matches. `summary` = +1-line truncated preview (first non-empty line, ≤160 chars; no LLM call).")
@click.option("--ocr", is_flag=True, help="Run tesseract OCR on scanned PDFs (slow, ~5-30s/page). Opt-in only; requires tesseract + pdftoppm on PATH.")
@click.option("--lazy/--no-lazy", default=True, help="0.5.1+ auto-trigger: on cold-start (no index yet), if ripgrep alone returns a weak result (few hits or no path/token overlap with the query) the cold-start path also fires the lazy LLM-routed semantic tier (~5 s) and merges. When ripgrep already returns a strong keyword answer, lazy is skipped — user gets the instant rg result. Default on so the user never has to know which tier they need; pass --no-lazy to force pure rg cold-start (benchmarking).")
def search_cmd(
    query: str,
    top: int,
    json_output: bool,
    answer: bool,
    content: bool,
    language: tuple[str, ...],
    include_patterns: tuple[str, ...],
    exclude_patterns: tuple[str, ...],
    agentic: bool,
    max_subqueries: int,
    semantic_only: bool,
    rerank: bool,
    rerank_pool: int,
    rerank_model: str,
    hyde: bool,
    multi_resolution: bool,
    file_top: int,
    lexical_prefilter: bool,
    lexical_root: str,
    lexical_min_candidates: int,
    daemon_url: str,
    rank_by: str,
    cascade: bool,
    cascade_tau: float,
    auto_index: bool | None,
    rg_shortcut: bool,
    filename_shortcut: bool,
    llm_router: bool,
    detail: str,
    ocr: bool,
    lazy: bool,
):
    """Run a search. Aliased as the bare form: ``skygrep "<query>"``."""

    # Intelligent CLI hint — out-of-scope query detection.
    #
    # 0.2.4 originally fired this *before* the LLM router decision was
    # available (using a pure keyword list). 0.2.6 moved the primary
    # detector to the LLM router prompt itself, so we now defer this
    # render to AFTER ``decision`` is computed and pass it through.
    # The keyword list survives as the offline fallback inside
    # ``detect_out_of_scope`` for when the LLM is unreachable.
    #
    # Note: still gated by ``hints_disabled()`` and the search still
    # runs after the hint so the user is never blocked.

    import os as _os

    config = get_config()
    if auto_index is None:
        # Default policy: auto-index unless the caller has pinned the DB
        # location with SKYGREP_DB_PATH (curated index — don't auto-mutate it).
        auto_index = _os.environ.get("SKYGREP_DB_PATH") is None
    if daemon_url:
        from .server import daemon_search

        start = time.time()
        try:
            payload = daemon_search(
                daemon_url,
                query,
                top_k=top,
                rerank=rerank,
                rerank_pool=rerank_pool if rerank_pool is not None else config["rerank_pool"],
                multi_resolution=multi_resolution,
                file_top=file_top,
                hyde=hyde,
                languages=tuple(language),
                include_patterns=tuple(include_patterns),
                exclude_patterns=tuple(exclude_patterns),
            )
        except Exception as exc:
            click.echo(f"daemon error: {exc}; falling back to in-process search", err=True)
        else:
            elapsed = time.time() - start
            results = payload.get("results", [])
            if json_output:
                click.echo(render_json_results(results))
                return
            for r in results:
                click.echo(render_terminal_result(
                    r, content=content, detail=detail, ocr=ocr,
                ))
            click.echo(
                f"\n[Daemon search completed in {elapsed:.3f}s; "
                f"daemon-side {payload.get('latency_seconds')}s]"
            )
            return

    # Fire-and-forget Ollama preheat. Loads embed + HyDE models with
    # ``keep_alive=-1`` in background threads so the cold-load cost
    # (~5-10 s per model on Mac CPU) is amortised across the time we
    # spend on rg prefilter, file-mean cosine, and DB migrations.
    # Best-effort: failures are silently swallowed inside ``preheat_models``.
    bootstrap.preheat_models()

    project_root = cfg_mod.project_root()
    db_path = config["db_path"]

    from . import auto_index as ai

    # v0.15.0 LLM-driven query routing. Resolves query intent + token
    # selection + skip decisions via local Ollama. Falls back to the
    # v0.14.0 rule-based classifier on any failure. The decision is
    # consulted by the filename / lexical / cascade tier dispatchers
    # below.
    # Persistent global router-decision cache. The router's decision
    # depends on query phrasing only, not on project content, so a
    # single SQLite shared across projects is sound — same query
    # never pays the LLM cost twice within or across sessions. Drop
    # ~/.skylakegrep/router_cache.db to force re-classification.
    router_start = time.time()
    _router_cache_db = None
    try:
        from pathlib import Path as _P
        _cache_dir = _P.home() / ".skylakegrep"
        _cache_dir.mkdir(parents=True, exist_ok=True)
        _router_cache_db = sqlite3.connect(str(_cache_dir / "router_cache.db"))
    except (OSError, sqlite3.Error):
        _router_cache_db = None
    decision: RouterDecision = route_query(
        query, conn=_router_cache_db, use_llm=llm_router
    )
    if _router_cache_db is not None:
        try:
            _router_cache_db.close()
        except sqlite3.Error:
            pass
    router_elapsed = time.time() - router_start

    # Intelligent CLI hint — out-of-scope query detection (0.2.6+).
    # Now driven by the LLM router's ``out_of_scope`` field
    # (``content`` / ``recency`` / ``size`` / ``listing``) rather than
    # the 0.2.4–0.2.5 keyword list. The keyword list survives only as
    # an offline fallback inside ``detect_out_of_scope`` when the LLM
    # is unreachable. See ``docs/PRINCIPLES.md`` Principle 1
    # ("Understanding > Enumeration") for the rationale.
    if not hints_disabled():
        _oos_hint = detect_out_of_scope(query, decision=decision)
        if _oos_hint is not None:
            click.echo(render_out_of_scope_hint(_oos_hint, query), err=True)

    # v0.14.0 hierarchical merge: collect filename-lookup results
    # without short-circuiting. The merged results from all enabled
    # tiers are ranked by `classify_intent(query)` later. This runs
    # BEFORE the index-ready check so the filename tier works on
    # un-indexed directories (~/Downloads etc.).
    fn_results: list[dict] = []
    fn_elapsed = 0.0
    if filename_shortcut and not decision.skip_filename and not agentic and not answer:
        fn_start = time.time()
        fn_hits = ai.filename_shortcut(query, project_root, top_k=top)
        fn_elapsed = time.time() - fn_start
        if fn_hits:
            fn_results = fn_hits

    # Routing decision: ready → cascade; building or absent → rg fallback.
    # 0.5.1: when the cold-start path is taken (no index yet) and rg
    # alone is weak, that fallback now also fires the lazy LLM-routed
    # semantic tier and merges the two — wired below in the cold-start
    # branch. This stays AUTO so the user never has to know which tier
    # to ask for; the `--lazy / --no-lazy` flag only opts out.
    conn = init_db(db_path)

    # Intelligent CLI hint — first-run nudge (0.2.4+). Once-per-project
    # greeting that explains the auto-index + rg-fallback flow so a
    # first-time user doesn't think the tool is broken or slow. The
    # ``mark_first_run_nudge_shown`` call records the metadata flag so
    # subsequent queries don't repeat the greeting.
    #
    # Gated on ``not json_output`` because JSON consumers (test runners,
    # downstream tooling, agents) don't want a chatty stderr greeting
    # to leak into their captured output, and CliRunner by default
    # merges stderr into stdout for ``--json`` calls.
    if (
        not hints_disabled()
        and not json_output
        and should_show_first_run_nudge(conn)
    ):
        click.echo(render_first_run_nudge(), err=True)
        mark_first_run_nudge_shown(conn)
    ready = ai.is_index_ready(conn)
    if not ready and auto_index:
        # Spawn (or no-op if already running) a detached indexer; do NOT
        # block the user. The next query that lands after the spawn
        # finishes will get full semantic results.
        try:
            ai.spawn_background_index(project_root, db_path)
        except Exception as exc:
            logger.warning("background index spawn failed: %s", exc)

        # 0.5.4 streaming UX: tell the user immediately that something
        # is happening. Otherwise the cold-start path stays silent for
        # the duration of the rg call (typically 100 ms but seconds on
        # a large home dir or with cold disk cache), then silent again
        # for the 5–30 s lazy embed pass — the user sees a frozen
        # prompt with no signal that the system is working.
        if not json_output:
            click.echo(
                "🔍 ripgrep cold-start · scanning project keywords…",
                err=True,
            )

        # Fall back to a pure-rg result for this query, merged with any
        # filename-lookup hits collected above so the cold-start path
        # also benefits from the v0.14.0 hierarchical-merge model.
        start = time.time()
        rg_cold = ai.rg_fallback_results(query, project_root, top_k=top)
        rg_elapsed = time.time() - start

        # 0.5.1 auto-trigger lazy semantic on a weak rg cold-start.
        # The user can't be expected to know whether they're in the
        # right folder or whether their keyword query happens to align
        # with the code's vocabulary — so we decide for them: if rg
        # already returns a strong keyword answer (≥ 3 results AND at
        # least one path contains a query term ≥ 3 chars), the user
        # gets that instantly and we skip the 5 s lazy embed pass. If
        # rg is weak (no path-token overlap or < 3 hits), we fire the
        # LLM-routed lazy semantic tier in the same call and merge.
        # `--no-lazy` opts out (e.g. for benchmarking pure rg).
        def _rg_is_strong(results_: list, query_: str) -> bool:
            if not results_ or len(results_) < 3:
                return False
            import re as _re
            # Tokenize query terms with camelCase / PascalCase splitting
            # so "ModelForm" → {"modelform", "model", "form"} and matches
            # both `ModelForm.py` and `model_form.py` paths.
            raw = [t for t in query_.split() if len(t) >= 3]
            terms: set[str] = set()
            for t in raw:
                terms.add(t.lower())
                # Pascal/camelCase split: "ModelForm" → ["Model", "Form"]
                for p in _re.findall(r"[A-Z][a-z]+|[a-z]{3,}|\d+", t):
                    if len(p) >= 3:
                        terms.add(p.lower())
            if not terms:
                return False
            matched: set[str] = set()
            for r in results_:
                raw_path = str(r.get("path", "")).lower()
                # Normalize path by stripping separators so
                # `model_form` and `model-form` reduce to `modelform`.
                norm_path = raw_path.replace("_", "").replace("-", "")
                for t in terms:
                    if t in raw_path or t in norm_path:
                        matched.add(t)
            # rg is "strong" only when ≥ 2 distinct query tokens land
            # in paths. A single common token like `schema` matching
            # 5 unrelated `schema.py` files in different backends is
            # NOT strong — that's how vocabulary-mismatch queries
            # ("schema synchronization across releases") fool a naive
            # gate. Single-word queries with no camel/snake case split
            # always fire lazy, by design — the 5 s wait is cheaper
            # than the wrong answer.
            return len(matched) >= 2

        lazy_results: list = []
        lazy_tele: dict = {}
        cross_results: list = []
        cross_tele: dict = {}
        lazy_elapsed = 0.0
        rg_strong = _rg_is_strong(rg_cold, query)

        # 0.5.4 streaming UX — STAGE 1: when lazy is about to fire (rg
        # is weak), print the rg + filename preliminary hits *first*
        # so the user has something to look at while we spend 5–30 s
        # on the embed pass. The lazy-augmentation results are then
        # printed after the lazy call returns. Tracked in
        # ``early_printed_paths`` so STAGE 2 only echoes the newly-
        # found-by-lazy results.
        early_printed_paths: set = set()
        will_fire_lazy = lazy and not rg_strong
        if will_fire_lazy and not json_output:
            preliminary: list = []
            seen_p: set = set()
            for source in (fn_results, rg_cold):
                for r in source:
                    p = r.get("path", "")
                    if not p or p in seen_p:
                        continue
                    seen_p.add(p)
                    preliminary.append(r)
                    if len(preliminary) >= top:
                        break
                if len(preliminary) >= top:
                    break
            if preliminary:
                click.echo(
                    "▾ preliminary keyword matches "
                    "(lazy semantic refinement starting…):",
                    err=True,
                )
                for r in preliminary:
                    click.echo(
                        render_terminal_result(
                            r,
                            content=content,
                            project_root=str(project_root),
                            detail=detail,
                            ocr=ocr,
                        )
                    )
                    early_printed_paths.add(r.get("path", ""))
                click.echo("", err=True)
            else:
                click.echo(
                    "▾ no keyword matches yet — lazy semantic search "
                    "exploring (5–30 s)…",
                    err=True,
                )
        # 0.5.3 cold-start lazy + cross-folder dispatch.
        #
        #   rg has hits, paths overlap query tokens   → rg-only, skip lazy
        #   rg has hits, paths weak (vocab-mismatch)  → lazy_cwd
        #   rg has zero hits (probably wrong folder)  → lazy_cwd ∥ lazy_cross_folder
        #
        # The third case is the user's "我们在错的 path 下面" scenario:
        # rg returned nothing in cwd, so the answer is most likely in
        # a sibling folder. Both lazy paths run in parallel — Ollama
        # serialises embed requests at the model layer, so wall time
        # is dominated by whichever batch is bigger, not their sum.
        cold_wrong_folder = (lazy and len(rg_cold) == 0)
        if lazy and not rg_strong:
            from concurrent.futures import ThreadPoolExecutor as _TPE
            from . import lazy_indexer as LZ

            # Wire a stderr progress sink unless --json is requested.
            _progress = None if json_output else LZ._stderr_progress

            def _run_cwd():
                try:
                    embedder_cwd = get_embedder(role="query")
                    return LZ.lazy_explore_cold_start(
                        conn, query, project_root, embedder_cwd,
                        top_k=top, progress=_progress,
                    )
                except Exception as exc:  # noqa: BLE001
                    logger.warning("lazy cold-start cwd failed: %s", exc)
                    return [], {}

            def _run_cross():
                try:
                    embedder_cross = get_embedder(role="query")
                    return LZ.lazy_explore_cross_folder(
                        conn, query, embedder=embedder_cross,
                        top_k=top, progress=_progress,
                    )
                except Exception as exc:  # noqa: BLE001
                    logger.warning("lazy cross-folder failed: %s", exc)
                    return [], {}

            lazy_start = time.time()
            if cold_wrong_folder:
                with _TPE(max_workers=2) as _pool:
                    f_cwd = _pool.submit(_run_cwd)
                    f_cross = _pool.submit(_run_cross)
                    lazy_results, lazy_tele = f_cwd.result()
                    cross_results, cross_tele = f_cross.result()
            else:
                lazy_results, lazy_tele = _run_cwd()
            lazy_elapsed = time.time() - lazy_start

        elapsed = rg_elapsed + lazy_elapsed
        intent = decision.intent
        # 0.5.3 cold-start merge: when lazy fired (only happens when
        # the rg-quality gate already classified rg as weak), trust
        # lazy's σ-validated cosine ranking for the primary top-K
        # slots and only use rg for de-duplicated backfill. Without
        # this the prior `merge_tiers(lexical=rg, semantic=lazy)`
        # call applied intent-aware ranking that reliably buried the
        # lazy answer beneath rg's score-1.0 hits — visible as 1/10
        # auto-trigger hit rate on the Django oracle bench. With
        # lazy-priority, the lazy module's top-K reaches the user
        # whenever it fired. Filename hits remain prepended (0.13
        # behaviour) — the bench shows filename can still drown
        # everything for filename-shaped queries; that's tracked as
        # a 0.6 issue, not in scope for this patch.
        if lazy_results or cross_results:
            seen: set[str] = set()
            ordered: list = []
            # filename → cwd-lazy → cross-folder → rg backfill,
            # deduped by path. Cross-folder is appended AFTER cwd-lazy
            # because when cwd genuinely contains the answer (rg
            # returned 0 because of vocabulary mismatch, but the file
            # IS local), we want the cwd hit to win.
            for source in (fn_results, lazy_results, cross_results, rg_cold):
                for r in source:
                    p = r.get("path", "")
                    if not p or p in seen:
                        continue
                    seen.add(p)
                    ordered.append(r)
                    if len(ordered) >= top:
                        break
                if len(ordered) >= top:
                    break
            results = ordered[:top]
        else:
            results = merge_tiers(
                filename=fn_results,
                lexical=rg_cold,
                semantic=[],
                intent=intent,
                top_k=top,
            )
        if json_output:
            click.echo(render_json_results(results))
            return
        # 0.2.8: try proactive enhancers in the cold-start path too.
        # 0.2.7 only ran proactive on the main cascade path, which
        # meant the user-reported case (filename lookup against an
        # un-indexed dir, rg can't grep the binary target) hit the
        # ``return`` below before proactive ever got a chance to
        # search ~/Downloads / ~/Desktop / ~/Documents. Let the
        # framework run here so cold-start users get the same
        # proactive helpfulness as warm queries.
        # 0.2.11: pass ctx with conn so enhancers like
        # ``recovery_progress_hint`` can read live recovery state.
        cold_proactive_results: list = []
        try:
            from . import proactive as _proactive
            cold_proactive_results, _ = _proactive.run_enhancers_parallel(
                query, decision, results, top_k=top,
                ctx=_proactive.ProactiveContext(
                    conn=conn, project_root=project_root,
                ),
            )
        except Exception:
            logger.exception(
                "proactive enhancer in cold-start path failed; ignoring"
            )
        if not results and not cold_proactive_results:
            click.echo(
                "No matches yet. Semantic index is building in the background; "
                "try the same query again in a minute, or run `skygrep stats` to "
                "see progress.",
                err=True,
            )
            return
        # 0.5.4 streaming UX — STAGE 2: if STAGE 1 already printed
        # preliminary keyword hits, only echo NEW results found by the
        # lazy semantic pass (deduped against the early printed set).
        # Otherwise (rg-strong fast path or json mode), print the full
        # ranked top-K as before.
        if early_printed_paths:
            new_results = [
                r for r in results
                if r.get("path", "") and r.get("path", "") not in early_printed_paths
            ]
            if new_results:
                click.echo(
                    "▾ refined matches from lazy semantic search:",
                    err=True,
                )
                for r in new_results:
                    click.echo(
                        render_terminal_result(
                            r,
                            content=content,
                            project_root=str(project_root),
                            detail=detail,
                            ocr=ocr,
                        )
                    )
            else:
                # Lazy didn't find anything beyond what rg already
                # surfaced. Tell the user explicitly so they don't
                # think the system hung.
                click.echo(
                    "▾ lazy semantic search added no new matches "
                    "(top-K above is the final answer).",
                    err=True,
                )
        else:
            for r in results:
                click.echo(
                    render_terminal_result(
                        r,
                        content=content,
                        project_root=str(project_root),
                        detail=detail,
                        ocr=ocr,
                    )
                )
        if cold_proactive_results:
            rendered = _proactive.render_proactive_output(cold_proactive_results)
            if rendered:
                click.echo(rendered)
        building = ai.is_index_building(db_path)
        suffix = "building in background" if building else "queued"
        proactive_tag = (
            f" + {len(cold_proactive_results)} proactive"
            if cold_proactive_results else ""
        )
        if lazy_results or cross_results:
            lazy_tag = (
                f" + lazy auto (σ={lazy_tele.get('sigma', 0):.3f}, "
                f"conf={lazy_tele.get('confidence', '?')}, "
                f"{lazy_tele.get('embed_new', 0)}new/"
                f"{lazy_tele.get('embed_cached', 0)}cached)"
            )
            if cross_results:
                lazy_tag += (
                    f" + cross-folder ({cross_tele.get('candidate_roots', 0)} "
                    f"roots · {cross_tele.get('files_seen', 0)} files seen)"
                )
        elif lazy and rg_strong:
            lazy_tag = " · rg strong → lazy skipped"
        elif not lazy:
            lazy_tag = " · --no-lazy"
        else:
            lazy_tag = ""
        click.echo(
            f"\n[{elapsed:.3f}s · ripgrep cold-start{proactive_tag}{lazy_tag} · "
            f"intent={intent} · {len(fn_results)} filename + "
            f"{len(rg_cold)} rg + {len(lazy_results)} lazy + "
            f"{len(cross_results)} cross-folder · index {suffix}]"
        )
        return

    # Index is ready (or auto_index disabled): run the normal pipeline,
    # plus an mtime-based incremental refresh on the way in.
    if auto_index:
        try:
            ai.incremental_refresh(
                conn,
                project_root,
                throttle_seconds=ai._refresh_throttle_from_env(),
                quiet=json_output,
            )
        except Exception as exc:
            logger.warning("auto-refresh failed: %s", exc)

    # L2 one-time symbol extraction. The ``symbols`` table is created by
    # ``init_db`` but is empty on indexes built before L2 — populate it on
    # first use, best-effort so a parser failure or filesystem issue can't
    # block the search itself. Stay quiet on the JSON path so stable
    # consumers (CliRunner, scripts) keep parsing the output cleanly.
    if not _symbols_table_populated(conn):
        try:
            if not json_output:
                click.echo("↻ extracting symbols (one-time, no LLM)…", err=True)
            inserted = populate_symbols(conn, project_root)
            if not json_output:
                click.echo(f"✓ {inserted} symbols indexed", err=True)
        except Exception as exc:
            logger.warning("symbol indexing failed: %s", exc)

    # L4 one-time migration: build the file-export graph if the table is
    # empty. Best-effort; failures here must not block search. Suppressed
    # under ``--json`` so machine-readable callers see clean stdout.
    graph_ready = False
    try:
        row = conn.execute("SELECT COUNT(*) FROM file_graph").fetchone()
        graph_count = row[0] if row else 0
        if graph_count == 0:
            if not json_output:
                click.echo("↻ building file-export graph (one-time)…", err=True)
            try:
                code_graph.populate_graph_table(conn, project_root)
                graph_ready = True
            except Exception as exc:  # noqa: BLE001
                logger.warning("file-export graph build failed: %s", exc)
        else:
            graph_ready = True
    except sqlite3.OperationalError:
        # Old DB without file_graph table; init_db creates it now, so this
        # path is rare. Silently fall through.
        pass

    status = ai.index_status(conn)
    if status["chunks"] == 0:
        # Empty index is a legitimate state (e.g. after `index --reset` on a
        # directory with no indexable files, or after every file was
        # deleted). Return empty results rather than erroring.
        if json_output:
            click.echo(render_json_results([]))
        else:
            click.echo("[no indexed chunks]")
        return

    # v0.14.0 hierarchical merge: collect lexical-content shortcut
    # results without short-circuiting. The merged results from all
    # enabled tiers are ranked by intent later — borderline queries
    # always also run cascade so semantic recall is never sacrificed.
    rg_results: list[dict] = []
    rg_elapsed = 0.0
    if rg_shortcut and not decision.skip_lexical and not agentic and not answer:
        rg_start = time.time()
        rg_hits = ai.lexical_shortcut(query, project_root, top_k=top)
        rg_elapsed = time.time() - rg_start
        if rg_hits:
            rg_results = rg_hits

    # v0.15.0 LLM-router can authorise skipping the cascade entirely
    # when it is highly confident the query is a pure filename lookup.
    # The decision is gated by MIN_CONFIDENCE_TO_SKIP_CASCADE — never
    # skipped on a low-confidence call.
    answerer = None
    cascade_telemetry: dict | None = None
    recovery_state: dict | None = None
    if decision.skip_cascade and not agentic and not answer:
        results: list[dict] = []
        elapsed = 0.0
    else:
        embedder = get_embedder(role="query")
        # Intelligent-recovery hook (0.2.2+). Embed the user's query first
        # to get the current embedder dim — that probe gives us
        # ``current_dim`` for free since we'd embed it for the cascade
        # below anyway. ``maybe_start_recovery`` compares the dim against
        # the index's stored embedder fingerprint and spawns a daemon
        # thread to re-embed stale chunks in mtime-DESC order. The thread
        # never blocks the user; the existing ``_filter_to_matching_dim``
        # helper hides stale-dim rows from the cascade so this query
        # returns instantly with whatever has been recovered so far,
        # progressively gaining semantic coverage as the worker commits.
        _probe_vec = embedder.embed(query)
        _probe_dim = len(_probe_vec)
        try:
            recovery_state = maybe_start_recovery(
                db_path, conn, embedder, _probe_dim
            )
        except Exception:
            logger.exception(
                "recovery hook failed; continuing with whatever the index has"
            )
            recovery_state = None
        if recovery_state and recovery_state.get("just_started"):
            stale = recovery_state.get("stale_count", 0)
            eta_min = recovery_state.get("eta_seconds")
            click.echo(
                f"⟳ Embedder upgraded "
                f"({recovery_state.get('stored_fingerprint', '?')} → "
                f"{recovery_state.get('current_fingerprint', '?')}); "
                f"re-embedding {stale} stale chunks in the background "
                f"(mtime-DESC priority). This query falls back to rg "
                f"+ partial semantic; full semantic resumes "
                f"progressively as files re-embed.",
                err=True,
            )
        start = time.time()
        queries = [query]
        if agentic:
            answerer = get_answerer()
            subqueries = answerer.decompose(query, max_queries=max_subqueries)
            for subquery in subqueries:
                if subquery not in queries:
                    queries.append(subquery)
        pool = rerank_pool if rerank_pool is not None else config["rerank_pool"]
        if hyde and not cascade:
            if answerer is None:
                answerer = get_answerer()
            queries = [answerer.hyde(item) for item in queries]
        candidate_paths = None
        if lexical_prefilter:
            from .hybrid import lexical_candidate_paths

            prefilter_root = Path(lexical_root) if lexical_root else project_root
            cands = lexical_candidate_paths(query, prefilter_root)
            if len(cands) >= lexical_min_candidates:
                candidate_paths = cands
            # else fall through to corpus-wide cosine

        result_groups: list[list[dict]] = []
        for item in queries:
            query_embedding = embedder.embed(item)
            if cascade:
                if answerer is None:
                    answerer = get_answerer()
                cascade_results, cascade_telemetry = cascade_search(
                    conn,
                    query_embedding,
                    query_text=item,
                    embedder=embedder,
                    answerer=answerer,
                    top_k=max(top, top * 2),
                    candidate_paths=candidate_paths,
                    tau=cascade_tau,
                    languages=tuple(language),
                    include_patterns=tuple(include_patterns),
                    exclude_patterns=tuple(exclude_patterns),
                )
                result_groups.append(cascade_results)
                continue
            result_groups.append(
                search(
                    conn,
                    query_embedding,
                    max(top, top * 2),
                    languages=tuple(language),
                    include_patterns=tuple(include_patterns),
                    exclude_patterns=tuple(exclude_patterns),
                    query_text=item,
                    semantic_only=semantic_only,
                    rerank=rerank,
                    rerank_pool=pool,
                    rerank_model=rerank_model,
                    multi_resolution=multi_resolution,
                    file_top=file_top,
                    candidate_paths=candidate_paths,
                    rank_by=rank_by,
                )
            )
        results = merge_results(result_groups, top)
        elapsed = time.time() - start

    # 0.5.3 warm-path low-confidence augmentation: when the cascade
    # ran and reports a small ``top1 - top2`` gap (its own σ-adaptive
    # confidence signal), the answer may not live in cwd. Fire
    # ``lazy_explore_cross_folder`` against the SKYGREP_PROACTIVE_DIRS
    # roots and include those hits as augmentation. Cascade remains
    # primary; cross-folder is appended after merge_tiers below.
    # Skipped when --no-lazy, agentic mode, JSON output, or no
    # cascade telemetry available.
    warm_cross_results: list = []
    warm_cross_tele: dict = {}
    warm_cross_elapsed = 0.0
    if (lazy and cascade and len(queries) == 1
            and 'cascade_telemetry' in dir() and cascade_telemetry is not None
            and not agentic):
        _gap = cascade_telemetry.get("gap")
        _tau = cascade_telemetry.get("tau")
        if (_gap is not None and _tau is not None and _gap < _tau):
            try:
                from . import lazy_indexer as _LZ
                _cross_embedder = get_embedder(role="query")
                _t_cross = time.time()
                warm_cross_results, warm_cross_tele = (
                    _LZ.lazy_explore_cross_folder(
                        conn, query, embedder=_cross_embedder,
                        top_k=top,
                        progress=None if json_output else _LZ._stderr_progress,
                    )
                )
                warm_cross_elapsed = time.time() - _t_cross
                elapsed += warm_cross_elapsed
            except Exception as exc:  # noqa: BLE001
                logger.warning("warm cross-folder lazy failed: %s", exc)

    # v0.14.0 hierarchical merge across tiers: cascade (semantic) +
    # lexical-shortcut hits + filename-lookup hits, deduplicated by
    # path, ranked by the v0.15.0 router-supplied intent so the right
    # tier wins for the user's query phrasing.
    intent = decision.intent
    results = merge_tiers(
        filename=fn_results,
        lexical=rg_results,
        semantic=results,
        intent=intent,
        top_k=top,
    )
    # 0.5.3: append warm-path cross-folder augmentation if cascade was
    # uncertain. Cross-folder is appended after merge_tiers (cascade
    # primary; sibling-folder hits added as long as room remains in
    # top-K), deduped by path so a result already returned by cascade
    # isn't double-printed.
    if warm_cross_results:
        _seen_paths = {r.get("path", "") for r in results}
        for r in warm_cross_results:
            if len(results) >= top:
                break
            p = r.get("path", "")
            if not p or p in _seen_paths:
                continue
            results.append(r)
            _seen_paths.add(p)
    if json_output:
        click.echo(render_json_results(results))
        return
    if answer:
        if answerer is None:
            answerer = get_answerer()
        synthesized = answerer.answer(query, results)
        click.echo(synthesized)
        click.echo("\nSources:")
        for result in results:
            click.echo(render_compact_source(result))
        click.echo(f"\n[Answer completed in {elapsed:.3f}s]")
        return
    for r in results:
        click.echo(
            render_terminal_result(
                r,
                content=content,
                project_root=str(project_root),
                detail=detail,
                ocr=ocr,
            )
        )

    # ``path=`` is the headline routing decision the user actually cares
    # about: which retrieval strategy answered this specific query.
    path_label = "rg-only" if decision.skip_cascade else "cascade-skipped"
    if cascade and cascade_telemetry is not None:
        path_label = cascade_telemetry.get("path") or (
            "cosine-cheap" if cascade_telemetry.get("early_exit") else "cosine-escalated-rerank"
        )
    # Recovery state — read fresh from the metadata table even if the
    # search-cmd-time snapshot is stale by the time results print.
    live_recovery = get_recovery_state(conn) if recovery_state is not None else None
    recovery_footer = render_recovery_footer(live_recovery) if live_recovery else None
    quality = "DEGRADED-recovery" if recovery_footer else "BEST"

    # ``SKYGREP_FOOTER_COMPACT=1`` keeps the legacy single-line format
    # for users / scripts that prefer terse output. Default is the
    # 0.2.5 hierarchical multi-line footer with category groups so
    # the user can scan path / router / evidence / pool / index
    # vertically rather than parsing one long ``·``-separated line.
    compact = _os.environ.get("SKYGREP_FOOTER_COMPACT") == "1"

    if compact:
        # Legacy footer — preserved verbatim for any tooling that grepped
        # the old format. New behaviour is the hierarchical block below.
        parts: list[str] = [f"{elapsed:.3f}s", f"path={path_label}"]
        parts.append(
            f"router={decision.source} · intent={intent} "
            f"({decision.confidence:.2f}) · "
            f"{len(fn_results)} filename + {len(rg_results)} lexical"
        )
        if cascade and cascade_telemetry is not None:
            gap = cascade_telemetry.get('gap', 0)
            tau = cascade_telemetry.get('tau', 0)
            tau_mode = cascade_telemetry.get('tau_mode', 'static')
            if cascade_telemetry.get("early_exit"):
                parts.append(
                    f"σ-gap={gap:.4f} ≥ τ={tau:.4f} ({tau_mode}) → high-confidence early-exit"
                )
            else:
                parts.append(
                    f"σ-gap={gap:.4f} < τ={tau:.4f} ({tau_mode}) → escalated to rerank"
                )
        parts.append(f"index {ai.index_age_human(conn)} · {status['files']} files")
        if _symbols_table_populated(conn):
            parts.append("L2 symbols on")
        if graph_ready:
            parts.append("graph prior on")
        if recovery_footer:
            parts.append(recovery_footer)
        parts.append(f"quality={quality}")
        click.echo("\n[" + " · ".join(parts) + "]")
    else:
        # Hierarchical footer. One header line with elapsed + quality
        # (with a ✓ / ⚠ glyph that's scannable at a glance), then
        # indented category rows. Each row is a single semantic group
        # so the user can read top-down without parsing separators.
        glyph = "⚠" if recovery_footer else "✓"
        path_detail = ""
        if cascade and cascade_telemetry is not None:
            if cascade_telemetry.get("early_exit"):
                path_detail = " (high-confidence early-exit)"
            else:
                path_detail = " (escalated to rerank)"
        rows: list[tuple[str, str]] = []
        rows.append(("path", f"{path_label}{path_detail}"))
        rows.append((
            "router",
            f"{decision.source} → intent={intent} ({decision.confidence:.2f})",
        ))
        if cascade and cascade_telemetry is not None:
            gap = cascade_telemetry.get('gap', 0)
            tau = cascade_telemetry.get('tau', 0)
            tau_mode = cascade_telemetry.get('tau_mode', 'static')
            cmp = "≥" if cascade_telemetry.get("early_exit") else "<"
            rows.append((
                "evidence",
                f"σ-gap={gap:.4f} {cmp} τ={tau:.4f} ({tau_mode})",
            ))
        pool_pieces = [
            f"{len(fn_results)} filename",
            f"{len(rg_results)} lexical",
        ]
        if cascade and not decision.skip_cascade:
            pool_pieces.append("cascade")
        elif decision.skip_cascade:
            pool_pieces.append("cascade-skipped")
        rows.append(("pool", " + ".join(pool_pieces[:2]) + " · " + pool_pieces[2]))
        index_pieces = [f"{ai.index_age_human(conn)} ago", f"{status['files']} files"]
        index_extras: list[str] = []
        if _symbols_table_populated(conn):
            index_extras.append("L2 symbols")
        if graph_ready:
            index_extras.append("graph prior")
        if index_extras:
            index_pieces.append(" + ".join(index_extras))
        if any(r.get("graph_tiebreak") for r in results) and len(results) >= 2:
            tie_gap = float(results[0].get("score", 0)) - float(results[1].get("score", 0))
            index_pieces.append(f"tied (Δ={tie_gap:.3f})")
        rows.append(("index", " · ".join(index_pieces)))
        if recovery_footer:
            # The recovery_footer already returns a "key=value · key=value"
            # string ("recovery=in-progress chunks=N/T coverage=N% ETA=Nm");
            # strip the leading "recovery=in-progress " so the row reads
            # cleanly under the "recovery" label.
            cleaned = recovery_footer.replace("recovery=in-progress", "in-progress")
            rows.append(("recovery", cleaned))
        # Render
        click.echo(f"\n{glyph} {elapsed:.3f}s · quality={quality}")
        label_w = max(len(label) for label, _ in rows)
        for label, value in rows:
            click.echo(f"   {label.ljust(label_w)} : {value}")

    # Proactive enhancement framework (0.2.7+). Runs registered
    # enhancers (filename_extend, ...) IN PARALLEL with a hard
    # ``SKYGREP_PROACTIVE_BUDGET_MS`` cap (default 500 ms) so normal
    # queries pay zero extra latency — only the should-fire-eligible
    # enhancers get scheduled, and over-budget ones are cancelled by
    # the thread pool. See ``docs/PRINCIPLES.md`` Principle 6
    # ("Proactive over Passive") for the contract every enhancer
    # must honour.
    proactive_results: list = []
    if not json_output:
        try:
            from . import proactive as _proactive

            proactive_results, _proactive_telemetry = (
                _proactive.run_enhancers_parallel(
                    query, decision, results, top_k=top,
                    ctx=_proactive.ProactiveContext(
                        conn=conn, project_root=project_root,
                    ),
                )
            )
            if proactive_results:
                rendered = _proactive.render_proactive_output(proactive_results)
                if rendered:
                    click.echo(rendered)
        except Exception:
            logger.exception("proactive enhancer runner failed; ignoring")

    # Intelligent CLI hint — low-confidence result quality (0.2.4+).
    # When top-1 cosine and σ-gap are both below floor, the result is
    # in the noise band; offer a recovery menu rather than letting the
    # user quit thinking the tool failed. Hint is silenced when the
    # query produced no results AND was already routed through rg
    # fallback (the user will know they need to refine), and also when
    # the proactive framework already surfaced extra hits — the user
    # has more to look at, no need to also nag.
    if (
        not hints_disabled()
        and not json_output
        and not proactive_results
    ):
        _quality_hint = assess_result_quality(results, cascade_telemetry)
        if _quality_hint:
            click.echo(_quality_hint, err=True)

    # First-run nudge: encourage the user to register skylakegrep with any
    # detected LLM CLIs once. Suppressed under --json (machine consumers
    # parsing the output), in non-TTY contexts (agents piping output), and
    # after `skygrep setup` has been run at least once.
    if (
        not json_output
        and sys.stdout.isatty()
        and not integrations_mod.is_setup_done()
    ):
        msg = integrations_mod.first_run_banner_message()
        if msg:
            click.echo(msg, err=True)

    # Optional background auto-enrich. Off by default; users opt in by
    # exporting ``SKYGREP_AUTO_ENRICH=yes``. We only spawn when the index is
    # actually ready — never alongside the rg-fallback path — so we don't
    # contend with the still-running first-time indexer for Ollama.
    if (
        ready
        and _os.environ.get("SKYGREP_AUTO_ENRICH") == "yes"
        and enrich_mod.count_pending(conn) > 0
    ):
        try:
            import subprocess as _subprocess

            log = db_path.with_suffix(db_path.suffix + ".enrich.log")
            env = dict(_os.environ)
            env["SKYGREP_DB_PATH"] = str(db_path)
            _subprocess.Popen(
                [sys.executable, "-m", "skylakegrep.src.cli", "enrich", "--max", "50"],
                cwd=str(project_root),
                env=env,
                stdout=open(log, "ab", buffering=0),
                stderr=_subprocess.STDOUT,
                stdin=_subprocess.DEVNULL,
                start_new_session=True,
                close_fds=True,
            )
        except Exception as exc:  # pragma: no cover — best-effort spawn
            logger.warning("auto-enrich spawn failed: %s", exc)


@cli.command()
@click.argument("path", default=".")
@click.option("--interval", "-i", default=5, help="Check interval in seconds")
def watch(path: str, interval: int):
    """Continuously index a directory: poll mtimes, reindex changed files."""

    config = get_config()
    db_path = config["db_path"]
    conn = init_db(db_path)
    embedder = get_embedder()
    indexed_files = get_indexed_files(conn)

    click.echo(f"Watching {path} for changes (Ctrl+C to stop)")
    while True:
        try:
            root = Path(path)
            files = collect_indexable_files(root)
            deleted_files = delete_missing_files(conn, {str(f) for f in files}, root)
            for deleted_file in deleted_files:
                indexed_files.pop(deleted_file, None)
                click.echo(f"  Deleted: {deleted_file}")
            for f in files:
                f_str = str(f)
                current_mtime = f.stat().st_mtime
                if f_str in indexed_files:
                    if current_mtime > indexed_files[f_str]:
                        chunks = prepare_file_chunks(f, root=root)
                        if chunks:
                            chunks = batch_embed(chunks, embedder, batch_size=10)
                            for c in chunks:
                                delete_file_chunks(conn, c["file"])
                            store_chunks_batch(conn, chunks)
                            indexed_files[f_str] = current_mtime
                            click.echo(f"  Updated: {f}")
                else:
                    chunks = prepare_file_chunks(f, root=root)
                    if chunks:
                        chunks = batch_embed(chunks, embedder, batch_size=10)
                        store_chunks_batch(conn, chunks)
                        indexed_files[f_str] = current_mtime
                        click.echo(f"  Added: {f}")
            time.sleep(interval)
        except KeyboardInterrupt:
            click.echo("\nStopping watch mode")
            break


@cli.command()
@click.option("--host", default="127.0.0.1", help="Host to bind the daemon on")
@click.option("--port", default=7878, type=int, help="Port to bind the daemon on")
def serve(host: str, port: int):
    """Run a long-running daemon that holds the reranker + embedder warm."""

    from .server import serve as _serve

    _serve(host=host, port=port)


@cli.command()
def stats():
    """Print chunk and file counts for the current project's index."""

    config = get_config()
    db_path = config["db_path"]
    click.echo(f"DB:           {db_path}")
    click.echo(f"Project root: {cfg_mod.project_root()}")
    if not db_path.exists():
        click.echo("No index yet. Run a query to auto-index, or `skygrep index .`.")
        return
    conn = init_db(db_path)
    row = conn.execute("SELECT COUNT(*), COUNT(DISTINCT file) FROM chunks").fetchone()
    click.echo(f"Total chunks: {row[0]}")
    click.echo(f"Total files:  {row[1]}")
    enriched, total = enrich_mod.count_enriched(conn)
    if total:
        pct = 100.0 * enriched / total
        click.echo(f"Enriched:     {enriched} / {total} ({pct:.1f}%)")
    snap = auto_index.index_status(conn)
    if snap["last_full_index_at"]:
        click.echo(f"Last full:    {auto_index._human_age(time.time() - snap['last_full_index_at'])}")
    if snap["last_refresh_at"]:
        click.echo(f"Last refresh: {auto_index._human_age(time.time() - snap['last_refresh_at'])}")


@cli.command()
@click.option("--max", "max_chunks", type=int, default=None,
              help="Stop after this many chunks (default: run to completion).")
@click.option("--batch", default=5, help="Chunks per progress line.")
def enrich(max_chunks, batch):
    """Run doc2query enrichment over the current project's index.

    For each chunk that has not been enriched yet, call the local LLM to
    write a one-sentence description, append it to the chunk text, and
    re-embed. Resumable — safe to Ctrl+C and re-run.
    """

    config = get_config()
    db_path = config["db_path"]
    if not db_path.exists():
        click.echo(
            "No index yet. Run `skygrep index .` (or just query the project) "
            "before enrichment.",
            err=True,
        )
        return
    conn = init_db(db_path)
    pending_before = enrich_mod.count_pending(conn)
    if pending_before == 0:
        click.echo("All chunks are already enriched.")
        return
    click.echo(
        f"Enriching up to {max_chunks if max_chunks is not None else pending_before} "
        f"chunk(s) ({pending_before} pending)..."
    )
    n = enrich_mod.enrich_pending_chunks(
        conn,
        max_chunks=max_chunks,
        batch_size=batch,
    )
    enriched, total = enrich_mod.count_enriched(conn)
    pct = 100.0 * enriched / total if total else 0.0
    click.echo(
        f"Enriched {n} chunk(s) this run · {enriched} / {total} ({pct:.1f}%) total."
    )


@cli.command()
def doctor():
    """Health check: probe Ollama, list models, summarise the project index."""

    config = get_config()
    report = bootstrap.doctor_report(config["ollama_url"])
    pad = lambda label: f"  {label:<26}"  # noqa: E731
    click.echo("skygrep doctor")
    if report["ollama"]["ok"]:
        click.echo(f"{pad('Ollama runtime')}✓ {report['ollama']['url']}")
    else:
        click.echo(f"{pad('Ollama runtime')}× {report['ollama']['url']}")
        click.echo(f"  → {report['ollama']['error']}")
        click.echo(f"\n{bootstrap.OLLAMA_INSTALL_HINT}")
        sys.exit(1)
    for entry in report["models"]:
        mark = "✓" if entry["present"] else "×"
        click.echo(f"{pad(entry['role'].title() + ' model')}{mark} {entry['name']}")
        if not entry["present"]:
            click.echo(f"  → run: ollama pull {entry['name']}")
    keep_alive = report.get("keep_alive") or "(default)"
    click.echo(f"{pad('Ollama keep_alive')}{keep_alive}")
    # Project index status.
    db_path = config["db_path"]
    if db_path.exists():
        conn = init_db(db_path)
        snap = auto_index.index_status(conn)
        click.echo(
            f"{pad('Project index')}✓ {snap['files']} files / {snap['chunks']} chunks"
            + (f" · refreshed {auto_index._human_age(time.time() - snap['last_refresh_at'])}" if snap["last_refresh_at"] else "")
        )
        enriched, total = enrich_mod.count_enriched(conn)
        if total:
            pct = 100.0 * enriched / total
            click.echo(f"{pad('Enriched chunks')}{enriched} / {total} ({pct:.1f}%)")
        click.echo(f"{pad('Index DB')}{db_path}")
    else:
        click.echo(f"{pad('Project index')}× not yet built — run a query to auto-index, or `skygrep index .`")
        click.echo(f"{pad('Would write to')}{db_path}")
    # Reranker presence is a soft check.
    try:
        import sentence_transformers  # noqa: F401

        click.echo(f"{pad('Reranker (optional)')}✓ sentence-transformers installed")
    except ImportError:
        click.echo(f"{pad('Reranker (optional)')}— install: pip install 'skylakegrep[rerank]'")
    click.echo(f"{pad('Project root')}{cfg_mod.project_root()}")
    # LLM-CLI integrations registered via ``skygrep setup``.
    detected = [i for i in integrations_mod.all_integrations() if i.is_detected()]
    if detected:
        for i in detected:
            mark = "✓" if i.is_registered() else "—"
            click.echo(f"{pad(f'LLM CLI: {i.name}')}{mark} {'registered' if i.is_registered() else 'not registered (run `skygrep setup`)'}")


@cli.command()
@click.option("--list", "list_only", is_flag=True, help="List detected LLM CLIs and registration state, then exit.")
@click.option("--uninstall", is_flag=True, help="Remove all snippets previously written by `skygrep setup`.")
@click.option("--skip", is_flag=True, help="Mark setup as done without registering anything (suppresses the first-run banner).")
@click.option("--yes", "-y", is_flag=True, help="Auto-confirm every detected integration without an interactive prompt.")
def setup(list_only: bool, uninstall: bool, skip: bool, yes: bool):
    """Register skylakegrep as preferred semantic search with installed LLM CLIs.

    Detects Claude Code, Codex, OpenCode, Gemini CLI, and Cursor on
    your machine and offers to write a tiny markdown snippet into each
    one's user-level instructions file. The snippet hints to the agent
    that it should prefer ``skygrep`` for natural-language code search and
    fall back to ``rg`` otherwise.

    Use ``--list`` to inspect without modifying. Use ``--uninstall`` to
    remove every snippet previously written. Use ``--skip`` to suppress
    the first-run banner without registering anything.
    """
    items = integrations_mod.all_integrations()

    if list_only:
        click.echo("Detected LLM CLIs (run `skygrep setup` to register):")
        for i in items:
            mark = "✓" if i.is_detected() else "·"
            reg = " [registered]" if i.is_registered() else ""
            click.echo(f"  {mark} {i.name:<14} {i.description}{reg}")
            click.echo(f"      config: {i.config_path}")
        return

    if uninstall:
        n_removed = 0
        for i in items:
            if i.unregister():
                click.echo(f"  ✓ removed snippet from {i.name} ({i.config_path})")
                n_removed += 1
        click.echo(f"\nDone. Removed {n_removed} integration(s).")
        return

    if skip:
        integrations_mod.mark_setup_done()
        click.echo("Marked setup done. The first-run banner will no longer appear.")
        click.echo("Re-run `skygrep setup` any time to register integrations.")
        return

    detected = [i for i in items if i.is_detected()]
    if not detected:
        click.echo("No supported LLM CLIs detected.")
        click.echo("\nWe look for:")
        for i in items:
            click.echo(f"  · {i.name} — {i.description}")
        click.echo("\nIf you do have one of these installed but it wasn't detected, "
                   "either ensure its binary is on PATH or its config dir exists "
                   "before running `skygrep setup` again.")
        integrations_mod.mark_setup_done()
        return

    click.echo("Detected the following LLM CLIs on your machine:\n")
    for i in detected:
        already = " [already registered]" if i.is_registered() else ""
        click.echo(f"  ✓ {i.name:<14} → {i.config_path}{already}")
    click.echo()
    if yes:
        click.echo("--yes set; registering all without prompting.\n")

    n_registered = 0
    for i in detected:
        if i.is_registered():
            continue
        if yes:
            answer = "y"
        else:
            try:
                answer = input(f"Register skylakegrep with {i.name}? [Y/n] ").strip().lower()
            except EOFError:
                answer = ""
        if answer and answer not in {"y", "yes"}:
            click.echo(f"  · skipped {i.name}")
            continue
        try:
            wrote = i.register()
            if wrote:
                click.echo(f"  ✓ wrote snippet to {i.config_path}")
                n_registered += 1
            else:
                click.echo(f"  · {i.name} already had the snippet (no change)")
        except OSError as exc:
            click.echo(f"  × {i.name}: failed to write {i.config_path}: {exc}", err=True)

    integrations_mod.mark_setup_done()
    click.echo(f"\nDone. Registered {n_registered} integration(s).")
    if n_registered:
        click.echo("Restart any open Claude Code / Codex / Gemini / Cursor sessions to pick up the change.")
    click.echo("Run `skygrep setup --uninstall` to remove all snippets later.")


def _collect_search_flag_names() -> list[str]:
    """Return the set of long-form flag names registered on the
    ``search`` subcommand. Used by the typo-correction wrapper in
    :func:`main` to suggest the closest match when the user types an
    unknown ``--flag``. Computed lazily on first call so importing
    this module stays cheap."""

    names: list[str] = []
    for name, command in cli.commands.items():  # type: ignore[attr-defined]
        for param in command.params:
            for opt in getattr(param, "opts", ()):
                if opt.startswith("--"):
                    names.append(opt)
    # Dedupe while preserving order.
    seen = set()
    unique = []
    for n in names:
        if n not in seen:
            seen.add(n)
            unique.append(n)
    return unique


def main():
    """CLI entry point.

    Wraps the click invocation with a typo-correcting error handler
    (0.2.4+): when the user types an unknown flag, click's default
    is "Error: No such option: --tup" with no suggestion. We catch
    ``NoSuchOption`` and run ``difflib`` against every long-form flag
    registered on every command to surface a "Did you mean '--top'?"
    line. Falls back to click's default formatting when the typo is
    too far from any known flag (cutoff 0.6 in
    ``intelligent_cli.closest_match``).
    """

    try:
        cli(standalone_mode=False)
    except click.exceptions.NoSuchOption as exc:
        suggestion = suggest_for_unknown_option(
            exc.option_name or "", _collect_search_flag_names()
        )
        if suggestion and not hints_disabled():
            click.echo(suggestion, err=True)
        else:
            exc.show()
        sys.exit(2)
    except click.exceptions.UsageError as exc:
        # Other usage errors (missing arg, conflicting flags). Click's
        # default error message is the right thing to render here; we
        # only intercept NoSuchOption above. Preserve click's exit code
        # to match standalone-mode behaviour.
        exc.show()
        sys.exit(exc.exit_code)
    except click.exceptions.ClickException as exc:
        exc.show()
        sys.exit(exc.exit_code)
    except click.exceptions.Abort:
        click.echo("Aborted!", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
