import requests
import json
import time
import uuid
from base64 import b64decode, b64encode
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Signature import PKCS1_v1_5
import urllib3

urllib3.disable_warnings()


# ============================================================================
# UTILITY FUNCTIONS FOR CRYPTOGRAPHY AND DATA HANDLING
# ============================================================================

def create_merchant_order_id():
    """
    Create a unique merchant order ID using current timestamp.

    Returns:
        str: Unique merchant order ID based on current time
    """
    return str(time.time())


def create_timestamp():
    """
    Create a timestamp string in seconds since epoch.

    Returns:
        str: Current timestamp as string
    """
    return str(time.time())


def create_nonce_str():
    """
    Generate a unique nonce string using UUID.

    Returns:
        str: UUID-based nonce string
    """
    return str(uuid.uuid4())


def sign_with_rsa(data, private_key, sign_type="SHA256withRSA"):
    """
    Generate SHA256 signature using RSA private key.

    Args:
        data: String data to be signed
        private_key: Base64-encoded RSA private key
        sign_type: Signature algorithm type (default: SHA256withRSA)

    Returns:
        str: Base64-encoded signature

    Raises:
        ValueError: If sign_type is not SHA256withRSA
    """
    if sign_type == "SHA256withRSA":
        key_bytes = b64decode(private_key.encode("utf-8"))
        key = RSA.importKey(key_bytes)
        digest = SHA256.new()
        digest.update(data.encode("utf-8"))
        signer = PKCS1_v1_5.new(key)
        signature = signer.sign(digest)
        return b64encode(signature).decode("utf-8")
    else:
        raise ValueError("Only SHA256withRSA signature type is supported")


def get_para_map_to_sign(data_dict):
    """
    Extract request attributes to be signed, excluding specific fields.

    Args:
        data_dict: Request dictionary to process

    Returns:
        dict: Filtered dictionary with only fields that should be signed
    """
    exclude_fields = [
        "sign",
        "sign_type",
        "header",
        "refund_info",
        "openType",
        "raw_request"
    ]
    result = {}
    for key, value in data_dict.items():
        if key in exclude_fields:
            continue
        if isinstance(value, dict):
            result.update(get_para_map_to_sign(value))
        else:
            result[key] = value
    return result


def get_sign_source_string(data_dict):
    """
    Generate signature source string from dictionary in key=value&key=value format.

    Args:
        data_dict: Dictionary to convert to signature source string

    Returns:
        str: URL-encoded signature source string
    """
    sorted_dict = dict(sorted(data_dict.items()))
    result = "&".join(
        [f"{str(key)}={str(value)}" for key, value in sorted_dict.items()]
    )
    return result


def sign_sha256(data_dict, private_key):
    """
    Generate SHA256 signature for dictionary data using RSA private key.
    Orchestrates extraction, sorting, and signing of request data.

    Args:
        data_dict: Dictionary to sign
        private_key: Base64-encoded RSA private key

    Returns:
        str: Base64-encoded RSA signature
    """
    # Extract signable fields
    para_map = get_para_map_to_sign(data_dict)
    # Generate signature source string
    sign_source_string = get_sign_source_string(para_map)
    # Generate and return signature
    return sign_with_rsa(sign_source_string, private_key)


# ============================================================================
# TELEBIRR PAYMENT SERVICE
# ============================================================================


class TelebirrSuperApp:
    """
    Service class for handling Telebirr payment order creation.
    Manages token acquisition, order request creation, and raw request generation.
    """

    def __init__(self, short_code, app_key, app_secret, merchant_id, private_key, url):
        """
        Initialize Telebirr payment service with required credentials.

        Args:
            short_code: Merchant short code
            app_key: Application key for authentication
            app_secret: Application secret for token generation
            merchant_id: Merchant/Application ID
            private_key: Private key for signing requests
            url: Base URL for API endpoints
        """
        self.short_code = short_code
        self.app_key = app_key
        self.app_secret = app_secret
        self.merchant_id = merchant_id
        self.private_key = private_key
        self.url = url
        self.notify_path = "https://"

    def create_order(self, title, amount):
        """
        Main orchestration method for creating a payment order.
        Coordinates token acquisition, order creation, and raw request generation.

        Args:
            title: Order title/description
            amount: Order amount

        Returns:
            str: Raw request string for H5 page payment initialization
        """
        # Step 1: Acquire fabric token
        fabric_token = self._apply_fabric_token()
        token = fabric_token.get("token")

        # Step 2: Create order request and get prepay_id
        create_order_result = self._request_create_order(token, title, amount)
        prepay_id = create_order_result.get("biz_content", {}).get("prepay_id")

        # Step 3: Create raw request string for payment initialization
        raw_request = self._create_raw_request(prepay_id)
        return raw_request

    def _apply_fabric_token(self):
        """
        Acquire authentication token from Telebirr fabric gateway.

        Returns:
            dict: Response containing authentication token
        """
        headers = {
            "X-App-key": self.app_key
        }
        payload = {
            "appSecret": self.app_secret
        }
        response = requests.post(
            url=self.url + "/apiaccess/payment/gateway/payment/v1/token",
            headers=headers,
            json=payload,
            verify=False
        )
        return json.loads(response.content)

    def _request_create_order(self, fabric_token, title, amount):
        """
        Submit order creation request to payment gateway.

        Args:
            fabric_token: Authentication token from fabric gateway
            title: Order title
            amount: Order amount

        Returns:
            dict: Gateway response containing prepay_id and order details
        """
        headers = {
            "Content-Type": "application/json",
            "X-App-Key": self.app_key,
            "Authorization": fabric_token
        }

        # Build order request payload
        payload = self._create_request_object(title, amount)

        # Submit to payment gateway
        response = requests.post(
            url=self.url + "/apiaccess/payment/gateway/payment/v1/merchant/preOrder",
            headers=headers,
            json=payload,
            verify=False
        )
        return json.loads(response.content)

    def _create_request_object(self, title, amount):
        """
        Construct the order request payload with all required parameters.

        Args:
            title: Order title/description
            amount: Order amount in minor units

        Returns:
            dict: Complete order request object with signature
        """
        nonce_str = create_nonce_str()
        timestamp = create_timestamp()

        request_obj = {
            "nonce_str": nonce_str,
            "method": "payment.preorder",
            "timestamp": timestamp,
            "version": "1.0",
            "sign_type": "SHA256withRSA",
            "biz_content": {
                "notify_url": self.notify_path,
                "business_type": "BuyGoods",
                "trade_type": "InApp",
                "appid": self.merchant_id,
                "merch_code": self.short_code,
                "merch_order_id": create_merchant_order_id(),
                "title": title,
                "total_amount": amount,
                "trans_currency": "ETB",
                "timeout_express": "120m",
                "payee_identifier": self.short_code,
                "payee_identifier_type": "04",
                "payee_type": "5000"
            }
        }

        # Generate and attach signature
        signature = self._sign_request(request_obj)
        request_obj["sign"] = signature
        return request_obj

    def _create_raw_request(self, prepay_id):
        """
        Build the raw request string for H5 payment page initialization.
        Concatenates key-value pairs and appends signature.

        Args:
            prepay_id: Prepayment ID from order creation response

        Returns:
            str: URL-encoded raw request string with signature
        """
        nonce_str = create_nonce_str()
        timestamp = create_timestamp()

        payload = {
            "appid": self.merchant_id,
            "merch_code": self.short_code,
            "nonce_str": nonce_str,
            "prepay_id": prepay_id,
            "timestamp": timestamp,
            "sign_type": "SHA256WithRSA"
        }

        # Build query string from payload
        raw_request = ""
        for key, value in payload.items():
            raw_request = raw_request + key + "=" + str(value) + "&"

        # Generate and append signature
        signature = self._sign_request(payload)
        raw_request = raw_request + "sign=" + signature

        return raw_request

    def _sign_request(self, data):
        """
        Generate SHA256withRSA signature for request data.
        Excludes specific fields from signing and flattens nested structures.

        Args:
            data: Request payload dictionary to sign

        Returns:
            str: Base64-encoded signature
        """
        # Generate SHA256 signature using private key
        signature = sign_sha256(data, self.private_key)
        return signature
