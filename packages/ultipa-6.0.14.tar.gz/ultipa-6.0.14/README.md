# Ultipa Python Driver

Official Python driver for Ultipa graph database (GQL).

## Requirements

- Python 3.9+

## Installation

```bash
pip install ultipa
```

> **Note:** This is the v6.x driver for Ultipa Graph. If you are using Ultipa v4.x, please install [ultipa==4.5.2](https://pypi.org/project/ultipa/4.5.2/). If you are using Ultipa v5.x, please install [ultipa==5.2.1](https://pypi.org/project/ultipa/5.2.1/).

## Quick Start

```python
from gqldb import GqldbClient
from gqldb.config import GqldbConfig

# Create client
config = GqldbConfig(
    hosts=["localhost:60061"],
    username="admin",
    password="password",
    default_graph="myGraph"
)
client = GqldbClient(config)
client.login("admin", "password")

# Execute query
response = client.gql("MATCH (n) RETURN n LIMIT 10")

print(f"Rows: {len(response.rows)}")
print(f"Columns: {response.columns}")

# Close
client.close()
```

## Features

- GQL query execution with parameters
- Streaming results for large datasets
- Transaction support (begin, commit, rollback)
- Graph management (create, drop, list)
- Bulk import for high-throughput loading
- Algorithm support (CALL algo.pagerank, algo.degree, etc.)
- Type hints support
- Health checks

## Documentation

See [Quick Start](https://www.ultipa.com/docs/drivers/python-quick-start) for detailed usage.

## License

MIT License
