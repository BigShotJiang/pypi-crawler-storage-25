"""Smoke tests for GQLDB Python SDK.

Quick sanity checks to verify basic SDK functionality.
Run with: pytest tests/smoke/ -v
"""

import os
os.environ.setdefault("no_proxy", "192.168.1.100")
import pytest

from gqldb.config import ConfigBuilder, GqldbConfig
from gqldb.client import GqldbClient
from gqldb.errors import GqldbError


# Test configuration - can be overridden via environment variables
HOST = os.getenv("GQLDB_HOST", "192.168.1.100:60061")
USERNAME = os.getenv("GQLDB_USERNAME", "admin")
PASSWORD = os.getenv("GQLDB_PASSWORD", "root11")
GRAPH = os.getenv("GQLDB_TEST_GRAPH", "miniCircle")


@pytest.fixture
def config() -> GqldbConfig:
    """Return test configuration."""
    return (
        ConfigBuilder()
        .hosts(HOST)
        .username(USERNAME)
        .password(PASSWORD)
        .default_graph(GRAPH)
        .timeout(30)
        .build()
    )


@pytest.fixture
def client(config: GqldbConfig) -> GqldbClient:
    """Return a GQLDB client."""
    c = GqldbClient(config)
    yield c
    c.close()


@pytest.mark.smoke
class TestSmokeTests:
    """Smoke tests for basic SDK functionality."""

    def test_client_creation(self, config: GqldbConfig):
        """Verify that a client can be instantiated successfully."""
        client = GqldbClient(config)
        assert client is not None
        client.close()

    def test_connection_ping(self, client: GqldbClient):
        """Verify that the client can ping the server."""
        # Try to login first (may fail if auth is disabled)
        try:
            client.login(USERNAME, PASSWORD)
        except GqldbError as e:
            if "authentication is not enabled" in str(e).lower():
                pass  # Continue without login
            else:
                raise

        latency = client.ping()
        assert latency is not None
        assert latency > 0

    def test_authentication(self, client: GqldbClient):
        """Verify that login succeeds with valid credentials."""
        try:
            session_info = client.login(USERNAME, PASSWORD)
            assert session_info is not None
        except GqldbError as e:
            if "authentication is not enabled" in str(e).lower():
                pytest.skip("Authentication is not enabled on this server")
            raise

    def test_simple_query(self, client: GqldbClient):
        """Verify that a simple query can be executed."""
        # Login first
        try:
            client.login(USERNAME, PASSWORD)
        except GqldbError as e:
            if "authentication is not enabled" not in str(e).lower():
                raise

        response = client.gql("RETURN 1 AS result")
        assert response is not None
        assert not response.is_empty()

    def test_health_check(self, client: GqldbClient):
        """Verify that the health service responds."""
        # Login first
        try:
            client.login(USERNAME, PASSWORD)
        except GqldbError as e:
            if "authentication is not enabled" not in str(e).lower():
                raise

        status = client.health_check()
        assert status is not None

    def test_version_info(self):
        """Verify that the SDK version is accessible."""
        from gqldb import __version__
        assert __version__ is not None
        assert len(__version__) > 0
