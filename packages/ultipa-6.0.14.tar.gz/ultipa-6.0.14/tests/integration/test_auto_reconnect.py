"""Auto-reconnect integration tests.

Verifies that the SDK automatically re-authenticates when the server session
becomes invalid (UNAUTHENTICATED) and stored credentials are still available.
"""

import pytest

from gqldb.client import GqldbClient
from gqldb.config import ConfigBuilder
from tests.conftest import AUTH_HOST, TEST_USERNAME, TEST_PASSWORD


def _make_client() -> GqldbClient:
    """Create a client WITHOUT default_graph to avoid auth error."""
    config = ConfigBuilder().hosts(AUTH_HOST).timeout(30).build()
    return GqldbClient(config)


@pytest.mark.integration
class TestAutoReconnect:
    """Auto-reconnect on UNAUTHENTICATED after session invalidation."""

    def test_reconnect_after_logout(self):
        """After logout, gql() should auto-reconnect using stored credentials."""
        client = _make_client()
        try:
            client.login(TEST_USERNAME, TEST_PASSWORD)
            client.use_graph("default")

            # Query should work normally
            resp = client.gql("RETURN 1 AS num")
            assert resp.row_count == 1

            # Invalidate server session but keep stored credentials
            client.logout()

            # Next gql() should detect UNAUTHENTICATED, re-login, and succeed
            resp = client.gql("RETURN 2 AS num")
            assert resp.row_count == 1
        finally:
            client.close()

    def test_stored_credentials_preserved_after_logout(self):
        """Stored credentials survive logout and enable auto-reconnect."""
        client = _make_client()
        try:
            client.login(TEST_USERNAME, TEST_PASSWORD)
            assert client.is_logged_in()

            # Verify credentials are stored
            assert client._stored_username == TEST_USERNAME
            assert client._stored_password == TEST_PASSWORD

            client.logout()

            # Credentials must still be present after logout
            assert client._stored_username == TEST_USERNAME
            assert client._stored_password == TEST_PASSWORD
        finally:
            client.close()

    def test_multiple_calls_after_reconnect(self):
        """After auto-reconnect, subsequent calls continue to work."""
        client = _make_client()
        try:
            client.login(TEST_USERNAME, TEST_PASSWORD)
            client.use_graph("default")
            client.logout()

            # First call triggers auto-reconnect
            resp = client.gql("RETURN 1 AS a")
            assert resp.row_count == 1

            # Subsequent calls should work without another reconnect
            for i in range(5):
                resp = client.gql(f"RETURN {i} AS val")
                assert resp.row_count == 1
        finally:
            client.close()

    def test_reconnect_restores_session(self):
        """After auto-reconnect, the client reports as logged in."""
        client = _make_client()
        try:
            client.login(TEST_USERNAME, TEST_PASSWORD)
            client.use_graph("default")
            client.logout()
            assert not client.is_logged_in()

            # Trigger auto-reconnect
            resp = client.gql("RETURN 42 AS answer")
            assert resp.row_count == 1

            # Session should be restored
            assert client.is_logged_in()
        finally:
            client.close()

    def test_reconnect_cycle_repeated(self):
        """Auto-reconnect works across multiple logout/reconnect cycles."""
        client = _make_client()
        try:
            for cycle in range(3):
                client.login(TEST_USERNAME, TEST_PASSWORD)
                client.use_graph("default")
                resp = client.gql(f"RETURN {cycle} AS cycle")
                assert resp.row_count == 1

                client.logout()

                # Auto-reconnect on next call
                resp = client.gql(f"RETURN {cycle + 10} AS after_reconnect")
                assert resp.row_count == 1
        finally:
            client.close()
