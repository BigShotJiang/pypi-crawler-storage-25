"""Graph Service integration tests - comprehensive parameter coverage."""

import pytest
import time

from gqldb.client import GqldbClient
from gqldb.types import GraphType
from gqldb.errors import GqldbError
from tests.conftest import drop_test_graph


@pytest.mark.integration
class TestGraphCreate:
    """Tests for CreateGraph with all parameter combinations."""

    def test_create_open_graph(self, connected_client: GqldbClient):
        """Create OPEN (schema-less) graph."""
        name = f"test_open_{int(time.time())}"
        connected_client.create_graph(name, GraphType.OPEN, "test open graph")
        info = connected_client.get_graph_info(name)
        assert info.name == name
        assert info.graph_type == GraphType.OPEN
        drop_test_graph(connected_client, name)

    def test_create_closed_graph(self, connected_client: GqldbClient):
        """Create CLOSED (schema-enforced) graph."""
        name = f"test_closed_{int(time.time())}"
        connected_client.create_graph(name, GraphType.CLOSED, "test closed graph")
        info = connected_client.get_graph_info(name)
        assert info.name == name
        assert info.graph_type == GraphType.CLOSED
        drop_test_graph(connected_client, name)

    def test_create_ontology_graph(self, connected_client: GqldbClient):
        """Create ONTOLOGY graph."""
        name = f"test_onto_{int(time.time())}"
        connected_client.create_graph(name, GraphType.ONTOLOGY, "test ontology graph")
        info = connected_client.get_graph_info(name)
        assert info.name == name
        assert info.graph_type == GraphType.ONTOLOGY
        drop_test_graph(connected_client, name)

    def test_create_graph_empty_description(self, connected_client: GqldbClient):
        """Create graph with empty description."""
        name = f"test_nodesc_{int(time.time())}"
        connected_client.create_graph(name, GraphType.OPEN, "")
        info = connected_client.get_graph_info(name)
        assert info.name == name
        drop_test_graph(connected_client, name)

    def test_create_graph_no_description(self, connected_client: GqldbClient):
        """Create graph with None description."""
        name = f"test_nonedesc_{int(time.time())}"
        connected_client.create_graph(name, GraphType.OPEN, None)
        info = connected_client.get_graph_info(name)
        assert info.name == name
        drop_test_graph(connected_client, name)

    def test_create_duplicate_graph(self, connected_client: GqldbClient):
        """Creating a graph that already exists should fail."""
        with pytest.raises(GqldbError):
            connected_client.create_graph("default", GraphType.OPEN, "dup")

    def test_create_graph_empty_name(self, connected_client: GqldbClient):
        """Creating with empty name should fail."""
        with pytest.raises(GqldbError):
            connected_client.create_graph("", GraphType.OPEN, "empty name")

    def test_create_graph_unicode_description(self, connected_client: GqldbClient):
        """Create graph with unicode description."""
        name = f"test_unicode_{int(time.time())}"
        connected_client.create_graph(name, GraphType.OPEN, "测试图集 description")
        info = connected_client.get_graph_info(name)
        assert info.name == name
        drop_test_graph(connected_client, name)


@pytest.mark.integration
class TestGraphDrop:
    """Tests for DropGraph with all parameter combinations."""

    def test_drop_existing_graph(self, connected_client: GqldbClient):
        """Drop an existing graph."""
        name = f"test_drop_{int(time.time())}"
        connected_client.create_graph(name, GraphType.OPEN, "to drop")
        connected_client.use_graph("default")
        connected_client.drop_graph(name)
        graphs = connected_client.list_graphs()
        assert name not in [g.name for g in graphs]

    def test_drop_nonexistent_graph(self, connected_client: GqldbClient):
        """Dropping a non-existent graph should fail."""
        with pytest.raises(GqldbError):
            connected_client.drop_graph("nonexistent_graph_xyz")

    def test_drop_nonexistent_if_exists(self, connected_client: GqldbClient):
        """Drop non-existent with if_exists=True should succeed."""
        connected_client.drop_graph("nonexistent_graph_xyz", if_exists=True)

    def test_drop_empty_name(self, connected_client: GqldbClient):
        """Dropping with empty name should fail."""
        with pytest.raises(GqldbError):
            connected_client.drop_graph("")

    def test_drop_default_graph(self, connected_client: GqldbClient):
        """Dropping the default graph should fail."""
        with pytest.raises(GqldbError):
            connected_client.drop_graph("default")


@pytest.mark.integration
class TestGraphUse:
    """Tests for UseGraph with all parameter combinations."""

    def test_use_existing_graph(self, connected_client: GqldbClient):
        """Switch to an existing graph."""
        connected_client.use_graph("miniCircle")
        connected_client.use_graph("default")

    def test_use_nonexistent_graph(self, connected_client: GqldbClient):
        """Switching to non-existent graph should fail."""
        with pytest.raises(GqldbError):
            connected_client.use_graph("nonexistent_graph_xyz")

    def test_use_empty_name(self, connected_client: GqldbClient):
        """Switching to empty name should fail."""
        with pytest.raises(GqldbError):
            connected_client.use_graph("")


@pytest.mark.integration
class TestGraphList:
    """Tests for ListGraphs."""

    def test_list_graphs(self, connected_client: GqldbClient):
        """List all available graphs."""
        graphs = connected_client.list_graphs()
        assert isinstance(graphs, list)
        assert len(graphs) > 0
        names = [g.name for g in graphs]
        assert "default" in names

    def test_list_graphs_has_info(self, connected_client: GqldbClient):
        """Listed graphs should have name, node_count, edge_count."""
        graphs = connected_client.list_graphs()
        for g in graphs:
            assert g.name is not None
            assert g.node_count >= 0
            assert g.edge_count >= 0


@pytest.mark.integration
class TestGraphInfo:
    """Tests for GetGraphInfo with all parameter combinations."""

    def test_get_info_existing(self, connected_client: GqldbClient):
        """Get info for an existing graph."""
        info = connected_client.get_graph_info("miniCircle")
        assert info.name == "miniCircle"
        assert info.node_count > 0
        assert info.edge_count > 0

    def test_get_info_default(self, connected_client: GqldbClient):
        """Get info for the default graph."""
        info = connected_client.get_graph_info("default")
        assert info.name == "default"

    def test_get_info_nonexistent(self, connected_client: GqldbClient):
        """Getting info for non-existent graph should fail."""
        with pytest.raises(GqldbError):
            connected_client.get_graph_info("nonexistent_graph_xyz")

    def test_get_info_empty_name(self, connected_client: GqldbClient):
        """Getting info for empty name should fail."""
        with pytest.raises(GqldbError):
            connected_client.get_graph_info("")
