"""Query Service integration tests."""

import pytest

from gqldb.client import GqldbClient, QueryConfig


@pytest.mark.integration
class TestQuery:
    """Tests for GQL query execution."""

    def test_simple_query(self, connected_client: GqldbClient):
        """Test a simple GQL query."""
        response = connected_client.gql("RETURN 1 AS num")
        assert response is not None
        print(f"Query returned {len(response.rows)} rows")
        print(f"Columns: {response.columns}")

    def test_return_literal(self, connected_client: GqldbClient):
        """Test returning literal values."""
        response = connected_client.gql("RETURN 'hello' AS greeting, 42 AS answer")
        print(f"Query returned {len(response.rows)} rows")
        print(f"Columns: {response.columns}")
        if response.rows:
            for i, row in enumerate(response.rows):
                print(f"Row {i}: {[row.get(j) for j in range(len(response.columns))]}")

    def test_empty_query_raises_error(self, connected_client: GqldbClient):
        """Test that empty query raises EmptyQueryError."""
        from gqldb.errors import EmptyQueryError

        with pytest.raises(EmptyQueryError):
            connected_client.gql("")

    def test_gql_statement(self, connected_client: GqldbClient):
        """Test executing a GQL statement."""
        result = connected_client.gql("RETURN 1")
        assert result is not None
        print(f"Gql result: rows={result.row_count}, columns={result.columns}")

    def test_gql_stream(self, connected_client: GqldbClient):
        """Test streaming GQL query."""
        results = []

        def callback(response):
            results.append(response)
            print(f"Stream chunk: {len(response.rows)} rows")

        connected_client.gql_stream("RETURN 1 AS num", callback=callback)
        print(f"Received {len(results)} stream chunks")

    def test_gql_with_graph_name(self, connected_client: GqldbClient):
        """Test query with explicit graph name."""
        config = QueryConfig(graph_name="miniCircle")
        response = connected_client.gql("MATCH (n) RETURN n LIMIT 5", config)
        assert response is not None
        print(f"Query on miniCircle returned {len(response.rows)} rows")

    def test_explain(self, connected_client: GqldbClient):
        """Test EXPLAIN query."""
        try:
            plan = connected_client.explain("RETURN 1 AS num")
            print(f"Explain plan: {plan}")
        except Exception as e:
            print(f"Explain error: {e}")

    def test_profile(self, connected_client: GqldbClient):
        """Test PROFILE query."""
        try:
            profile = connected_client.profile("RETURN 1 AS num")
            print(f"Profile result: {profile}")
        except Exception as e:
            print(f"Profile error: {e}")


@pytest.mark.integration
class TestMaxPathResults:
    """Tests for max_path_results parameter."""

    def test_query_with_max_path_results(self, connected_client: GqldbClient):
        """Test query with max_path_results limit."""
        try:
            # Try a path query
            config = QueryConfig(max_path_results=5)
            response = connected_client.gql(
                "MATCH p=(n)-[*1..2]-(m) RETURN p LIMIT 10",
                config
            )
            print(f"Path query with max_path_results=5: {len(response.rows)} rows")
        except Exception as e:
            # Path query syntax may not be supported, try simple query
            print(f"Path query failed: {e}, trying simple query")
            config = QueryConfig(max_path_results=5)
            response = connected_client.gql("RETURN 1 AS result", config)
            assert response is not None
            print(f"Simple query with max_path_results=5: {len(response.rows)} rows")

    def test_query_with_max_path_results_zero(self, connected_client: GqldbClient):
        """Test query with max_path_results=0 (unlimited)."""
        config = QueryConfig(max_path_results=0)
        response = connected_client.gql("RETURN 1 AS result", config)
        assert response is not None
        print(f"Query with max_path_results=0 (unlimited): {len(response.rows)} rows")

    def test_query_with_max_path_results_large(self, connected_client: GqldbClient):
        """Test query with large max_path_results value."""
        config = QueryConfig(max_path_results=1000000)
        response = connected_client.gql("RETURN 1 AS result", config)
        assert response is not None
        print(f"Query with max_path_results=1000000: {len(response.rows)} rows")

    def test_gql_stream_with_max_path_results(self, connected_client: GqldbClient):
        """Test streaming query with max_path_results."""
        results = []

        def callback(response):
            results.append(response)
            print(f"Stream chunk with max_path_results=10: {len(response.rows)} rows")

        config = QueryConfig(max_path_results=10)
        connected_client.gql_stream("RETURN 1 AS num", config, callback=callback)
        print(f"Received {len(results)} stream chunks")

    def test_explain_with_max_path_results(self, connected_client: GqldbClient):
        """Test EXPLAIN with max_path_results."""
        try:
            config = QueryConfig(max_path_results=10)
            plan = connected_client.explain("RETURN 1 AS num", config)
            print(f"Explain with max_path_results=10: {plan if plan else '(empty)'}")
        except Exception as e:
            print(f"Explain with max_path_results error: {e}")

    def test_profile_with_max_path_results(self, connected_client: GqldbClient):
        """Test PROFILE with max_path_results."""
        try:
            config = QueryConfig(max_path_results=10)
            profile = connected_client.profile("RETURN 1 AS num", config)
            print(f"Profile with max_path_results=10: {profile if profile else '(empty)'}")
        except Exception as e:
            print(f"Profile with max_path_results error: {e}")
