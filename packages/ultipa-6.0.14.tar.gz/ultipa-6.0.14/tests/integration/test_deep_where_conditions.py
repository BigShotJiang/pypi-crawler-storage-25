"""Deep WHERE Conditions integration tests."""

import time
import pytest

from gqldb.client import GqldbClient, QueryConfig


@pytest.mark.integration
class TestDeepWhereConditions:

    @pytest.fixture(scope="class")
    def test_graph(self, connected_client: GqldbClient):
        graph_name = f"test_deep_where_{int(time.time() * 1000)}"
        connected_client.create_graph(graph_name)
        time.sleep(0.5)
        cfg = QueryConfig(graph_name=graph_name)
        connected_client.gql(
            "INSERT "
            "(:Person {_id: 'p1', name: 'Alice', age: 30, score: 95.5, active: true, city: 'Beijing', email: 'alice@test.com'}), "
            "(:Person {_id: 'p2', name: 'Bob', age: 25, score: 80.0, active: false, city: 'Shanghai', email: 'bob@test.com'}), "
            "(:Person {_id: 'p3', name: 'Charlie', age: 35, score: 70.5, active: true, city: 'Beijing', email: ''}), "
            "(:Person {_id: 'p4', name: 'Diana', age: 28, score: 90.0, active: false, city: 'Guangzhou', email: 'diana@test.com'}), "
            "(:Person {_id: 'p5', name: 'Eve', age: 30, score: 85.5, active: true, city: 'Shanghai', email: 'eve@test.com'}), "
            "(:Person {_id: 'p6', name: '', age: 0, score: 0.0, active: false, city: '', email: ''})",
            cfg
        )
        connected_client.gql("MATCH (a WHERE id(a)='p1'), (b WHERE id(b)='p2') INSERT (a)-[:KNOWS {since: 2020, weight: 0.9}]->(b)", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='p2'), (b WHERE id(b)='p3') INSERT (a)-[:KNOWS {since: 2021, weight: 0.5}]->(b)", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='p3'), (b WHERE id(b)='p4') INSERT (a)-[:KNOWS {since: 2022, weight: 0.3}]->(b)", cfg)
        yield graph_name
        try:
            connected_client.use_graph("default")
        except Exception:
            pass
        try:
            connected_client.drop_graph(graph_name, if_exists=True)
        except Exception:
            pass

    def _count(self, connected_client: GqldbClient, test_graph: str, gql: str) -> int:
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql(gql, cfg)
        return int(str(r.get_by_name(r.rows[0], "cnt")))

    def test_eq_int(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age = 30 RETURN count(n) AS cnt") == 2

    def test_neq_int(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age <> 30 RETURN count(n) AS cnt") == 4

    def test_gt(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age > 30 RETURN count(n) AS cnt") == 1

    def test_gte(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age >= 30 RETURN count(n) AS cnt") == 3

    def test_lt(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age < 28 RETURN count(n) AS cnt") == 2

    def test_lte(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age <= 28 RETURN count(n) AS cnt") == 3

    def test_eq_string(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.name = 'Alice' RETURN count(n) AS cnt") == 1

    def test_eq_empty_string(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.name = '' RETURN count(n) AS cnt") == 1

    def test_neq_empty_string(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.name != '' RETURN count(n) AS cnt") == 5

    def test_eq_bool_true(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.active = true RETURN count(n) AS cnt") == 3

    def test_eq_float(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.score = 95.5 RETURN count(n) AS cnt") == 1

    def test_gt_float(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.score > 85.0 RETURN count(n) AS cnt") == 3

    def test_contains(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.name CONTAINS 'li' RETURN count(n) AS cnt") == 2

    def test_starts_with(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.name STARTS WITH 'A' RETURN count(n) AS cnt") == 1

    def test_ends_with(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.name ENDS WITH 'e' RETURN count(n) AS cnt") == 3

    def test_contains_lower(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE lower(n.name) CONTAINS 'alice' RETURN count(n) AS cnt") == 1

    def test_ends_with_email(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.email ENDS WITH '@test.com' RETURN count(n) AS cnt") == 4

    def test_and(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age > 25 AND n.active = true RETURN count(n) AS cnt") == 3

    def test_or(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.city = 'Beijing' OR n.city = 'Shanghai' RETURN count(n) AS cnt") == 4

    def test_not(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE NOT n.active = true RETURN count(n) AS cnt") == 3

    def test_and_or_parens(self, connected_client, test_graph):
        cnt = self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.active = true AND (n.city = 'Beijing' OR n.city = 'Shanghai') RETURN count(n) AS cnt")
        assert cnt == 3

    def test_double_or_and(self, connected_client, test_graph):
        cnt = self._count(connected_client, test_graph, "MATCH (n:Person) WHERE (n.city = 'Beijing' OR n.city = 'Shanghai') AND (n.age >= 30 OR n.score >= 90) RETURN count(n) AS cnt")
        assert cnt == 3

    def test_triple_and(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age >= 25 AND n.active = true AND n.score > 80 RETURN count(n) AS cnt") == 2

    def test_triple_or(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.name = 'Alice' OR n.name = 'Bob' OR n.name = 'Charlie' RETURN count(n) AS cnt") == 3

    def test_and_not(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.city = 'Beijing' AND n.name <> 'Alice' RETURN count(n) AS cnt") == 1

    def test_in_string_list(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.city IN ['Beijing', 'Guangzhou'] RETURN count(n) AS cnt") == 3

    def test_in_int_list(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age IN [25, 30] RETURN count(n) AS cnt") == 3

    def test_in_empty_list(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.name IN [] RETURN count(n) AS cnt") == 0

    def test_id_function(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE id(n) = 'p1' RETURN count(n) AS cnt") == 1

    def test_id_in_list(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE id(n) IN ['p1', 'p2', 'p3'] RETURN count(n) AS cnt") == 3

    def test_edge_where_int(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH ()-[e:KNOWS]->() WHERE e.since >= 2021 RETURN count(e) AS cnt") == 2

    def test_edge_where_float(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH ()-[e:KNOWS]->() WHERE e.weight > 0.5 RETURN count(e) AS cnt") == 1

    def test_where_node_and_edge(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (a:Person)-[e:KNOWS]->(b:Person) WHERE a.active = true AND e.since >= 2020 RETURN count(e) AS cnt") == 2

    def test_order_by_asc(self, connected_client, test_graph):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql("MATCH (n:Person) WHERE n.name != '' RETURN n.name ORDER BY n.age ASC", cfg)
        assert str(r.get_by_name(r.rows[0], "n.name")) == "Bob"

    def test_order_by_desc(self, connected_client, test_graph):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql("MATCH (n:Person) WHERE n.name != '' RETURN n.name ORDER BY n.age DESC", cfg)
        assert str(r.get_by_name(r.rows[0], "n.name")) == "Charlie"

    def test_limit(self, connected_client, test_graph):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql("MATCH (n:Person) RETURN n.name LIMIT 3", cfg)
        assert r.row_count == 3

    def test_skip_limit(self, connected_client, test_graph):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql("MATCH (n:Person) WHERE n.name != '' RETURN n.name ORDER BY n.name SKIP 2 LIMIT 2", cfg)
        assert r.row_count == 2

    def test_count(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) RETURN count(n) AS cnt") == 6

    def test_sum(self, connected_client, test_graph):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql("MATCH (n:Person) RETURN sum(n.age) AS total", cfg)
        assert str(r.get_by_name(r.rows[0], "total")) == "148"

    def test_min_max(self, connected_client, test_graph):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql("MATCH (n:Person) WHERE n.name != '' RETURN min(n.age) AS mn, max(n.age) AS mx", cfg)
        assert str(r.get_by_name(r.rows[0], "mn")) == "25"
        assert str(r.get_by_name(r.rows[0], "mx")) == "35"

    def test_distinct(self, connected_client, test_graph):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql("MATCH (n:Person) WHERE n.city != '' RETURN DISTINCT n.city AS city ORDER BY city", cfg)
        assert r.row_count >= 3

    # ================================================================
    # Ported from the extended deep-coverage suite (gqldb-python-test):
    # `!=` form, false-bool match, CONTAINS empty string, email-prefix /
    # explicit edge-label filter, lower() function, NOT(...) wrapping AND/OR,
    # IS [NOT] NULL, AVG, GROUP BY.
    # ================================================================

    def test_neq_bang(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.age != 30 RETURN count(n) AS cnt") == 4

    def test_eq_bool_false(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.active = false RETURN count(n) AS cnt") == 3

    def test_contains_empty(self, connected_client, test_graph):
        # CONTAINS '' should match every row (including the empty-name p6).
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.name CONTAINS '' RETURN count(n) AS cnt") == 6

    def test_starts_with_email(self, connected_client, test_graph):
        assert self._count(connected_client, test_graph, "MATCH (n:Person) WHERE n.email STARTS WITH 'alice' RETURN count(n) AS cnt") == 1

    def test_not_and(self, connected_client, test_graph):
        # NOT (age > 30 AND active = true) excludes only Charlie (35, active=true) → 5 remaining.
        assert self._count(connected_client, test_graph,
            "MATCH (n:Person) WHERE NOT (n.age > 30 AND n.active = true) RETURN count(n) AS cnt") == 5

    def test_not_or(self, connected_client, test_graph):
        # NOT (city = 'Beijing' OR city = 'Shanghai') keeps Diana(Guangzhou) + p6('').
        assert self._count(connected_client, test_graph,
            "MATCH (n:Person) WHERE NOT (n.city = 'Beijing' OR n.city = 'Shanghai') RETURN count(n) AS cnt") == 2

    def test_is_null(self, connected_client, test_graph):
        # All 6 nodes lack a `nonexistent` property → they should all be IS NULL.
        cnt = self._count(connected_client, test_graph,
            "MATCH (n:Person) WHERE n.nonexistent IS NULL RETURN count(n) AS cnt")
        assert cnt == 6

    def test_is_not_null(self, connected_client, test_graph):
        # `name` is set on all 6 (one of them is empty string but still NOT NULL).
        cnt = self._count(connected_client, test_graph,
            "MATCH (n:Person) WHERE n.name IS NOT NULL RETURN count(n) AS cnt")
        assert cnt == 6

    def test_edge_label_filter(self, connected_client, test_graph):
        # The fixture only inserts KNOWS edges, so a query for WORKS_WITH should
        # match nothing (verifies edge-label predicate routing).
        cnt = self._count(connected_client, test_graph,
            "MATCH (a)-[e:WORKS_WITH]->(b) RETURN count(e) AS cnt")
        assert cnt == 0

    def test_lower_function(self, connected_client, test_graph):
        # 2 nodes have city='Beijing'; lower() should make a case-insensitive match work.
        cnt = self._count(connected_client, test_graph,
            "MATCH (n:Person) WHERE lower(n.city) = 'beijing' RETURN count(n) AS cnt")
        assert cnt == 2

    def test_avg(self, connected_client, test_graph):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql(
            "MATCH (n:Person) WHERE n.name != '' RETURN avg(n.age) AS avg_age", cfg)
        assert r.row_count == 1

    def test_group_by(self, connected_client, test_graph):
        cfg = QueryConfig(graph_name=test_graph)
        r = connected_client.gql(
            "MATCH (n:Person) WHERE n.city != '' "
            "RETURN n.city AS city, count(n) AS cnt ORDER BY cnt DESC",
            cfg,
        )
        assert r.row_count >= 1
