"""AdminService integration tests."""

import pytest

from gqldb.client import GqldbClient
from gqldb.errors import GqldbError
from gqldb.types import CacheType


@pytest.mark.integration
class TestAdminService:
    """Tests for AdminService operations."""

    def test_warmup_parser(self, connected_client: GqldbClient):
        """Test warmup parser with valid count."""
        connected_client.warmup_parser(2)

    def test_warmup_parser_count_1(self, connected_client: GqldbClient):
        """Test warmup parser with count=1."""
        connected_client.warmup_parser(1)

    def test_warmup_parser_count_0(self, connected_client: GqldbClient):
        """Test warmup parser with count=0."""
        connected_client.warmup_parser(0)

    def test_get_cache_stats(self, connected_client: GqldbClient):
        """Test getting cache statistics."""
        stats = connected_client.get_cache_stats(CacheType.ALL)
        assert stats is not None
        print(f"CacheStats: {stats}")

    def test_get_cache_stats_ast(self, connected_client: GqldbClient):
        """Test getting AST cache statistics."""
        stats = connected_client.get_cache_stats(CacheType.AST)
        assert stats is not None

    def test_get_cache_stats_plan(self, connected_client: GqldbClient):
        """Test getting plan cache statistics."""
        stats = connected_client.get_cache_stats(CacheType.PLAN)
        assert stats is not None

    def test_clear_cache(self, connected_client: GqldbClient):
        """Test clearing all caches."""
        connected_client.clear_cache(CacheType.ALL)

    def test_get_statistics(self, connected_client: GqldbClient):
        """Test getting database statistics."""
        stats = connected_client.get_statistics("miniCircle")
        assert stats is not None
        print(f"Statistics: nodes={stats.node_count}, edges={stats.edge_count}")

    def test_get_statistics_default(self, connected_client: GqldbClient):
        """Test getting statistics with default graph."""
        stats = connected_client.get_statistics("default")
        assert stats is not None

    def test_invalidate_permission_cache_all(self, connected_client: GqldbClient):
        """Test invalidating permission cache for all users."""
        connected_client.invalidate_permission_cache()

    def test_invalidate_permission_cache_specific_user(self, connected_client: GqldbClient):
        """Test invalidating permission cache for specific user."""
        connected_client.invalidate_permission_cache("admin")

    def test_get_statistics_nonexistent(self, connected_client: GqldbClient):
        """Getting stats for non-existent graph should fail."""
        from gqldb.errors import GqldbError
        with pytest.raises(GqldbError):
            connected_client.get_statistics("nonexistent_graph_xyz")

    def test_compact(self, connected_client: GqldbClient):
        """Test manual compaction."""
        result = connected_client.compact()
        assert result is not None
        print(f"Compact: success={result.success}, message={result.message}")

    def test_get_system_metrics(self, connected_client: GqldbClient):
        """Test getting system metrics."""
        metrics = connected_client.get_system_metrics()
        assert metrics is not None

        if metrics.cpu is not None:
            print(f"CPU: process={metrics.cpu.process_percent:.2f}%, "
                  f"system={metrics.cpu.system_percent:.2f}%, cores={metrics.cpu.num_cores}")
        if metrics.memory is not None:
            print(f"Memory: rss={metrics.memory.process_rss}, "
                  f"total={metrics.memory.system_total}")
        if metrics.disk_io is not None:
            print(f"DiskIO: read={metrics.disk_io.read_bytes}, "
                  f"write={metrics.disk_io.write_bytes}")
        if metrics.storage is not None:
            print(f"Storage: path={metrics.storage.db_path}, "
                  f"size={metrics.storage.db_size_bytes}")
        if metrics.network is not None:
            print(f"Network: sent={metrics.network.bytes_sent}, "
                  f"recv={metrics.network.bytes_recv}")

    def test_warmup_parser_negative(self, connected_client: GqldbClient):
        """Test warmup parser with negative count (-1) to check behavior."""
        try:
            connected_client.warmup_parser(-1)
            print("warmup_parser(-1) succeeded (server accepted negative)")
        except GqldbError as e:
            print(f"warmup_parser(-1) raised expected error: {e}")

    # NOTE: wait_for_compute_topology is implemented in AdminService but is NOT
    # exposed on the GqldbClient class. These tests access the internal service
    # directly to verify the RPC behavior.

    def test_wait_for_compute_topology(self, connected_client: GqldbClient):
        """Test basic wait_for_compute_topology call with timeout_ms=0."""
        try:
            admin_svc = connected_client._admin_service
            result = admin_svc.wait_for_compute_topology("default", timeout_ms=0)
            assert result is not None
            print(f"ComputeTopology: ready={result.ready}, message={result.message}")
        except GqldbError as e:
            # May fail if compute engine not enabled
            print(f"wait_for_compute_topology: {e}")

    def test_wait_for_compute_topology_nonexistent(self, connected_client: GqldbClient):
        """Test wait_for_compute_topology on a nonexistent graph should fail."""
        admin_svc = connected_client._admin_service
        with pytest.raises(GqldbError):
            admin_svc.wait_for_compute_topology("nonexistent_graph_xyz", timeout_ms=0)
