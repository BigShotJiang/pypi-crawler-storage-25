"""Convenience API integration tests — all 64 methods.

Optimized: tests share graphs by category to minimize create/drop cycles.
- 1 CLOSED graph for Label/Property/Constraint/Index/Fulltext tests
- 1 OPEN graph for Insert tests
- Graph tests create/drop their own (small count)
- System tests use no graphs or miniCircle (read-only)
"""

import pytest
import time
import uuid

from gqldb.client import GqldbClient, QueryConfig
from gqldb.errors import GqldbError
from gqldb.types import (
    GraphType, NodeData, EdgeData,
    DBType, LabelInfo, ConvPropertyDef, NodeTypeInfo, EdgeTypeInfo,
    IndexProperty, IndexInfo, FulltextInfo, AlgoInfo, TaskInfo,
    ProcessInfo, GraphStats, InsertResponse,
)
from tests.conftest import drop_test_graph


def _uid():
    return uuid.uuid4().hex[:8]


# =========================================================================
# 1. Graph (6 methods) — each test creates/drops its own graph
# =========================================================================

@pytest.mark.integration
class TestConvenienceGraph:

    def test_create_open_graph(self, connected_client):
        name = f"test_g_{_uid()}"
        try:
            resp = connected_client.create_open_graph(name)
            assert resp is not None
            assert connected_client.has_graph(name)
        finally:
            drop_test_graph(connected_client, name)

    def test_create_closed_graph(self, connected_client):
        name = f"test_g_{_uid()}"
        try:
            connected_client.create_closed_graph(name)
            assert connected_client.has_graph(name)
        finally:
            drop_test_graph(connected_client, name)

    def test_create_graph_if_not_exist_new(self, connected_client):
        name = f"test_g_{_uid()}"
        try:
            created = connected_client.create_graph_if_not_exist(name, GraphType.OPEN)
            assert created is True
        finally:
            drop_test_graph(connected_client, name)

    def test_create_graph_if_not_exist_existing(self, connected_client):
        name = f"test_g_{_uid()}"
        try:
            connected_client.create_graph(name, GraphType.OPEN, "")
            created = connected_client.create_graph_if_not_exist(name)
            assert created is False
        finally:
            drop_test_graph(connected_client, name)

    def test_has_graph(self, connected_client):
        assert connected_client.has_graph("default") is True
        assert connected_client.has_graph("nonexistent_xyz") is False

    def test_alter_graph(self, connected_client):
        old = f"test_g_{_uid()}"
        new = f"test_g_{_uid()}"
        try:
            connected_client.create_graph(old, GraphType.OPEN, "")
            connected_client.alter_graph(old, new)
            assert connected_client.has_graph(new)
            assert not connected_client.has_graph(old)
        finally:
            drop_test_graph(connected_client, new)
            drop_test_graph(connected_client, old)

    def test_truncate(self, connected_client):
        name = f"test_g_{_uid()}"
        try:
            connected_client.create_graph(name, GraphType.OPEN, "")
            connected_client.gql("INSERT (:X {v:1})", QueryConfig(graph_name=name))
            connected_client.truncate(name)
            info = connected_client.get_graph_info(name)
            assert info.node_count == 0
        finally:
            drop_test_graph(connected_client, name)


# =========================================================================
# 2-7. Label/Property/Constraint/Index/Fulltext — share 1 CLOSED graph
# =========================================================================

@pytest.mark.integration
class TestConvenienceSchema:
    """All schema tests share one CLOSED graph to minimize create/drop."""

    @pytest.fixture(scope="class")
    def schema_env(self):
        """Create one CLOSED graph with its own client, add base labels, yield, then drop."""
        from gqldb.config import ConfigBuilder
        from tests.conftest import AUTH_HOST, TEST_USERNAME, TEST_PASSWORD, TEST_DATABASE
        client = GqldbClient(
            ConfigBuilder().hosts(AUTH_HOST).default_graph(TEST_DATABASE).timeout(30).build()
        )
        client.login(TEST_USERNAME, TEST_PASSWORD)
        name = f"conv_schema_{_uid()}"
        client.create_closed_graph(name)
        client.use_graph(name)
        client.create_node_label("Person", [
            ConvPropertyDef(name="name", type="STRING"),
            ConvPropertyDef(name="age", type="INT64"),
        ])
        client.create_edge_label("KNOWS", [
            ConvPropertyDef(name="since", type="INT64"),
        ])
        yield name
        try:
            client.drop_graph(name, if_exists=True)
        except Exception:
            pass
        client.close()

    @pytest.fixture(autouse=True)
    def _use_schema_graph(self, connected_client, schema_env):
        """Automatically set the current graph before each test."""
        connected_client.use_graph(schema_env)

    # --- Label: Show (5) ---

    def test_show_labels(self, connected_client, schema_env):
        labels = connected_client.show_labels()
        assert isinstance(labels, list)
        assert len(labels) >= 2
        all_names = {n for l in labels for n in l.labels}
        assert "Person" in all_names
        assert "KNOWS" in all_names

    def test_show_node_labels(self, connected_client, schema_env):
        labels = connected_client.show_node_labels()
        all_names = {n for l in labels for n in l.labels}
        assert "Person" in all_names

    def test_show_edge_labels(self, connected_client, schema_env):
        labels = connected_client.show_edge_labels()
        all_names = {n for l in labels for n in l.labels}
        assert "KNOWS" in all_names

    def test_show_node_types(self, connected_client, schema_env):
        types = connected_client.show_node_types()
        assert any(t.name == "Person" for t in types)
        person = [t for t in types if t.name == "Person"][0]
        prop_names = [p.name for p in person.properties]
        assert "name" in prop_names
        assert "age" in prop_names

    def test_show_edge_types(self, connected_client, schema_env):
        types = connected_client.show_edge_types()
        assert any(t.name == "KNOWS" for t in types)

    # --- Label: Get (3) ---

    def test_get_label_existing(self, connected_client, schema_env):
        label = connected_client.get_label("Person")
        assert label is not None
        assert "Person" in label.labels

    def test_get_label_nonexistent(self, connected_client, schema_env):
        label = connected_client.get_label("Nonexistent")
        assert label is None

    def test_get_node_label(self, connected_client, schema_env):
        label = connected_client.get_node_label("Person")
        assert label is not None
        assert label.name == "Person"
        assert len(label.properties) >= 2

    def test_get_node_label_nonexistent(self, connected_client, schema_env):
        label = connected_client.get_node_label("Ghost")
        assert label is None

    def test_get_edge_label(self, connected_client, schema_env):
        label = connected_client.get_edge_label("KNOWS")
        assert label is not None

    def test_get_edge_label_nonexistent(self, connected_client, schema_env):
        label = connected_client.get_edge_label("Ghost")
        assert label is None

    # --- Label: Create/Drop (5) ---

    def test_create_and_drop_node_label(self, connected_client, schema_env):
        connected_client.create_node_label("Animal", [
            ConvPropertyDef(name="species", type="STRING"),
        ])
        labels = connected_client.show_node_labels()
        assert any("Animal" in l.labels for l in labels)
        connected_client.drop_node_label("Animal")
        labels = connected_client.show_node_labels()
        assert not any("Animal" in l.labels for l in labels)

    def test_create_and_drop_edge_label(self, connected_client, schema_env):
        connected_client.create_edge_label("LIKES", [])
        labels = connected_client.show_edge_labels()
        assert any("LIKES" in l.labels for l in labels)
        connected_client.drop_edge_label("LIKES")
        labels = connected_client.show_edge_labels()
        assert not any("LIKES" in l.labels for l in labels)

    def test_create_label_if_not_exist_new(self, connected_client, schema_env):
        created = connected_client.create_label_if_not_exist(
DBType.NODE, "TempLabel", [])
        assert created is True
        connected_client.drop_node_label("TempLabel")

    def test_create_label_if_not_exist_existing(self, connected_client, schema_env):
        created = connected_client.create_label_if_not_exist(
DBType.NODE, "Person", [])
        assert created is False

    # --- Label: Alter (2) ---

    def test_alter_node_label(self, connected_client, schema_env):
        connected_client.create_node_label("OldName", [])
        connected_client.alter_node_label("OldName", "NewName")
        labels = connected_client.show_node_labels()
        all_names = {n for l in labels for n in l.labels}
        assert "NewName" in all_names
        assert "OldName" not in all_names
        connected_client.drop_node_label("NewName")

    def test_alter_edge_label(self, connected_client, schema_env):
        connected_client.create_edge_label("OLD_EDGE", [])
        connected_client.alter_edge_label("OLD_EDGE", "NEW_EDGE")
        labels = connected_client.show_edge_labels()
        all_names = {n for l in labels for n in l.labels}
        assert "NEW_EDGE" in all_names
        connected_client.drop_edge_label("NEW_EDGE")

    # --- Label: ShowAlgos (1) ---

    def test_show_algos(self, connected_client):
        algos = connected_client.show_algos()
        assert isinstance(algos, list)
        assert len(algos) > 0
        assert algos[0].name != ""

    # --- Property: Show (3) ---

    def test_show_node_property(self, connected_client, schema_env):
        props = connected_client.show_node_property("Person")
        assert isinstance(props, list)
        names = [p.name for p in props]
        assert "name" in names
        assert "age" in names

    def test_show_edge_property(self, connected_client, schema_env):
        props = connected_client.show_edge_property("KNOWS")
        assert isinstance(props, list)
        names = [p.name for p in props]
        assert "since" in names

    def test_show_property_dispatch(self, connected_client, schema_env):
        props = connected_client.show_property(DBType.NODE, "Person")
        assert any(p.name == "name" for p in props)

    def test_show_property_nonexistent(self, connected_client, schema_env):
        props = connected_client.show_node_property("Ghost")
        assert props == [] or props is None

    # --- Property: Get (3) ---

    def test_get_node_property_existing(self, connected_client, schema_env):
        prop = connected_client.get_node_property("Person", "name")
        assert prop is not None
        assert prop.name == "name"

    def test_get_node_property_nonexistent(self, connected_client, schema_env):
        prop = connected_client.get_node_property("Person", "ghost")
        assert prop is None

    def test_get_edge_property(self, connected_client, schema_env):
        prop = connected_client.get_edge_property("KNOWS", "since")
        assert prop is not None

    # --- Property: Create/Drop (7) ---

    def test_create_and_drop_node_property(self, connected_client, schema_env):
        connected_client.create_node_property("Person", [
            ConvPropertyDef(name="email", type="STRING"),
        ])
        props = connected_client.show_node_property("Person")
        assert any(p.name == "email" for p in props)
        connected_client.drop_node_property("Person", "email")
        props = connected_client.show_node_property("Person")
        assert not any(p.name == "email" for p in props)

    def test_create_and_drop_edge_property(self, connected_client, schema_env):
        connected_client.create_edge_property("KNOWS", [
            ConvPropertyDef(name="weight", type="FLOAT"),
        ])
        props = connected_client.show_edge_property("KNOWS")
        assert any(p.name == "weight" for p in props)
        connected_client.drop_edge_property("KNOWS", "weight")

    def test_create_property_dispatch(self, connected_client, schema_env):
        connected_client.create_property(DBType.NODE, "Person", [
            ConvPropertyDef(name="phone", type="STRING"),
        ])
        prop = connected_client.get_node_property("Person", "phone")
        assert prop is not None
        connected_client.drop_property(DBType.NODE, "Person", "phone")

    def test_create_property_if_not_exist_new(self, connected_client, schema_env):
        created = connected_client.create_property_if_not_exist(
DBType.NODE, "Person",
            [ConvPropertyDef(name="tmp_prop", type="STRING")])
        assert created is True
        connected_client.drop_node_property("Person", "tmp_prop")

    def test_create_property_if_not_exist_existing(self, connected_client, schema_env):
        created = connected_client.create_property_if_not_exist(
DBType.NODE, "Person",
            [ConvPropertyDef(name="name", type="STRING")])
        assert created is False

    # --- Constraint (4) ---

    def test_add_and_drop_not_null(self, connected_client, schema_env):
        connected_client.create_not_null_constraint(DBType.NODE, "Person", "name")
        connected_client.drop_not_null_constraint(DBType.NODE, "Person", "name")

    def test_add_and_drop_unique(self, connected_client, schema_env):
        connected_client.create_unique_constraint(DBType.NODE, "Person", "name")
        connected_client.drop_unique_constraint(DBType.NODE, "Person", "name")

    # --- Index (7) ---

    def test_show_index_empty(self, connected_client, schema_env):
        indexes = connected_client.show_index()
        assert isinstance(indexes, list)

    def test_create_and_drop_node_index(self, connected_client, schema_env):
        connected_client.create_node_index("idx_name", "Person", [
            IndexProperty(name="name"),
        ])
        time.sleep(1)
        indexes = connected_client.show_node_index()
        assert any(i.index_name == "idx_name" for i in indexes)
        connected_client.drop_node_index("idx_name")
        indexes = connected_client.show_node_index()
        assert not any(i.index_name == "idx_name" for i in indexes)

    def test_create_and_drop_edge_index(self, connected_client, schema_env):
        connected_client.create_edge_index("idx_since", "KNOWS", [
            IndexProperty(name="since"),
        ])
        time.sleep(1)
        indexes = connected_client.show_edge_index()
        assert any(i.index_name == "idx_since" for i in indexes)
        connected_client.drop_edge_index("idx_since")

    def test_create_node_index_prefix(self, connected_client, schema_env):
        connected_client.create_node_index("idx_name_pfx", "Person", [
            IndexProperty(name="name", prefix_length=10),
        ])
        time.sleep(1)
        indexes = connected_client.show_index()
        assert any(i.index_name == "idx_name_pfx" for i in indexes)
        connected_client.drop_node_index("idx_name_pfx")

    # --- Fulltext (7) ---

    def test_show_fulltext_empty(self, connected_client, schema_env):
        fts = connected_client.show_fulltext()
        assert isinstance(fts, list)

    def test_create_and_drop_node_fulltext(self, connected_client, schema_env):
        connected_client.create_node_fulltext("ft_name", "Person", ["name"])
        time.sleep(2)
        fts = connected_client.show_node_fulltext()
        assert any(f.index_name == "ft_name" for f in fts)
        connected_client.drop_node_fulltext("ft_name")
        time.sleep(1)

    def test_create_and_drop_edge_fulltext(self, connected_client, schema_env):
        # Add a STRING property for fulltext on edge
        try:
            connected_client.create_edge_property("KNOWS", [
                ConvPropertyDef(name="note", type="STRING"),
            ])
        except GqldbError:
            pass  # already exists
        connected_client.create_edge_fulltext("ft_note", "KNOWS", ["note"])
        time.sleep(2)
        fts = connected_client.show_edge_fulltext()
        assert any(f.index_name == "ft_note" for f in fts)
        connected_client.drop_edge_fulltext("ft_note")
        time.sleep(1)


# =========================================================================
# 8. Task (3 methods)
# =========================================================================

@pytest.mark.integration
class TestConvenienceTask:

    def test_show_tasks(self, connected_client):
        tasks = connected_client.show_tasks()
        assert isinstance(tasks, list)

    def test_delete_task_nonexistent(self, connected_client):
        with pytest.raises(GqldbError):
            connected_client.delete_task("nonexistent_task_id")

    def test_stop_task_nonexistent(self, connected_client):
        with pytest.raises(GqldbError):
            connected_client.stop_task("nonexistent_task_id")


# =========================================================================
# 9. Data Insert (4 methods) — share 1 OPEN graph
# =========================================================================

@pytest.mark.integration
class TestConvenienceInsert:

    @pytest.fixture(scope="class")
    def open_graph(self):
        from gqldb.config import ConfigBuilder
        from tests.conftest import AUTH_HOST, TEST_USERNAME, TEST_PASSWORD, TEST_DATABASE
        client = GqldbClient(
            ConfigBuilder().hosts(AUTH_HOST).default_graph(TEST_DATABASE).timeout(30).build()
        )
        client.login(TEST_USERNAME, TEST_PASSWORD)
        name = f"conv_ins_{_uid()}"
        client.create_graph(name, GraphType.OPEN, "insert tests")
        yield name
        try:
            client.drop_graph(name, if_exists=True)
        except Exception:
            pass
        client.close()

    def test_insert_nodes(self, connected_client, open_graph):
        connected_client.use_graph(open_graph)
        resp = connected_client.insert_nodes([
            NodeData(labels=["Person"], properties={"name": "Alice", "age": 30}),
            NodeData(labels=["Person"], properties={"name": "Bob", "age": 25}),
        ])
        assert resp is not None
        assert resp.row_count >= 1

    def test_insert_nodes_missing_label(self, connected_client, open_graph):
        connected_client.use_graph(open_graph)
        with pytest.raises((GqldbError, ValueError)):
            connected_client.insert_nodes([
                NodeData(labels=[], properties={"x": 1}),
            ])

    def test_insert_nodes_empty(self, connected_client, open_graph):
        connected_client.use_graph(open_graph)
        resp = connected_client.insert_nodes([])
        assert resp is not None

    def test_insert_nodes_with_properties(self, connected_client, open_graph):
        """Insert node with various property types."""
        connected_client.use_graph(open_graph)
        resp = connected_client.insert_nodes([
            NodeData(labels=["TypeTest"], properties={"name": "test", "count": 42, "active": True}),
        ])
        assert resp is not None
        assert resp.row_count >= 1

    def test_insert_edges(self, connected_client, open_graph):
        # Get node IDs
        r = connected_client.gql(
            "MATCH (n:Person) RETURN id(n) AS nid LIMIT 2",
            QueryConfig(graph_name=open_graph))
        if r.row_count >= 2:
            id1 = r.get_by_name(r.rows[0], "nid")
            id2 = r.get_by_name(r.rows[1], "nid")
            resp = connected_client.insert_edges([
                EdgeData(label="KNOWS", from_node_id=id1, to_node_id=id2, properties={"since": 2024}),
            ])
            assert resp is not None

    def test_insert_edges_empty(self, connected_client, open_graph):
        resp = connected_client.insert_edges([])
        assert resp.rows_affected == 0

    def test_insert_nodes_batch_auto(self, connected_client, open_graph):
        session = connected_client.start_bulk_import(open_graph)
        try:
            resp = connected_client.insert_nodes_batch_auto(
                open_graph,
                [NodeData(labels=["BatchNode"], properties={"val": 1})],
                bulk_import_session_id=session.session_id)
            assert resp.success
        finally:
            connected_client.end_bulk_import(session.session_id)

    def test_insert_edges_batch_auto(self, connected_client, open_graph):
        # Get IDs
        r = connected_client.gql(
            "MATCH (n) RETURN id(n) AS nid LIMIT 2",
            QueryConfig(graph_name=open_graph))
        if r.row_count >= 2:
            id1 = r.get_by_name(r.rows[0], "nid")
            id2 = r.get_by_name(r.rows[1], "nid")
            session = connected_client.start_bulk_import(open_graph)
            try:
                resp = connected_client.insert_edges_batch_auto(
                    open_graph,
                    [EdgeData(label="BATCH_EDGE", from_node_id=id1, to_node_id=id2)],
                    bulk_import_session_id=session.session_id)
                assert resp.success
            finally:
                connected_client.end_bulk_import(session.session_id)


# =========================================================================
# 10. System & Process (4 methods) — no graph creation needed
# =========================================================================

@pytest.mark.integration
class TestConvenienceSystem:

    def test_top(self, connected_client):
        procs = connected_client.top()
        assert isinstance(procs, list)

    def test_kill_nonexistent(self, connected_client):
        with pytest.raises(GqldbError):
            connected_client.kill("nonexistent_query_id")

    def test_stats(self, connected_client):
        stats = connected_client.stats()
        assert isinstance(stats, GraphStats)
        assert stats.node_count > 0

    def test_test_connectivity(self, connected_client):
        latency = connected_client.test()
        assert latency >= 0

    def test_show_algos(self, connected_client):
        algos = connected_client.show_algos()
        assert isinstance(algos, list)
        assert len(algos) > 0
        assert algos[0].name != ""
