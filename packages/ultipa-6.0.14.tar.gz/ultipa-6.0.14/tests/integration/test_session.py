"""Session Service integration tests - comprehensive parameter coverage."""

import pytest

from gqldb.client import GqldbClient
from gqldb.config import ConfigBuilder, GqldbConfig
from gqldb.errors import GqldbError
from tests.conftest import (
    check_auth_enabled, TEST_USERNAME, TEST_PASSWORD, TEST_DATABASE,
    AUTH_HOST, NO_AUTH_HOST,
)


@pytest.mark.integration
class TestLogin:
    """Tests for Login with all parameter combinations."""

    def test_login_valid(self, client: GqldbClient):
        """Login with valid credentials."""
        if not check_auth_enabled(client):
            pytest.skip("Auth disabled")
        session = client.login(TEST_USERNAME, TEST_PASSWORD)
        assert session is not None
        assert session.id > 0
        assert client.is_logged_in()
        client.logout()
        client.close()

    def test_login_with_default_graph(self, client: GqldbClient):
        """Login with a default graph specified."""
        if not check_auth_enabled(client):
            pytest.skip("Auth disabled")
        session = client.login(TEST_USERNAME, TEST_PASSWORD)
        assert session is not None
        client.logout()
        client.close()

    def test_login_wrong_password(self, client: GqldbClient):
        """Login with wrong password should fail."""
        if not check_auth_enabled(client):
            pytest.skip("Auth disabled")
        with pytest.raises(GqldbError):
            client.login(TEST_USERNAME, "wrong_password")
        client.close()

    def test_login_empty_username(self, client: GqldbClient):
        """Login with empty username should fail."""
        if not check_auth_enabled(client):
            pytest.skip("Auth disabled")
        with pytest.raises(GqldbError):
            client.login("", "")
        client.close()

    def test_login_nonexistent_user(self, client: GqldbClient):
        """Login with non-existent user should fail."""
        if not check_auth_enabled(client):
            pytest.skip("Auth disabled")
        with pytest.raises(GqldbError):
            client.login("nonexistent_user_xyz", "password")
        client.close()

    def test_login_nonexistent_default_graph(self):
        """Login with non-existent default graph - should still login."""
        config = ConfigBuilder().hosts(AUTH_HOST).default_graph("no_such_graph").timeout(10).build()
        client = GqldbClient(config)
        try:
            session = client.login(TEST_USERNAME, TEST_PASSWORD)
            # Server may accept login even with bad default graph
            assert session is not None
            client.logout()
        except GqldbError:
            pass  # Also acceptable to reject
        finally:
            client.close()


@pytest.mark.integration
class TestLogout:
    """Tests for Logout."""

    def test_logout_valid(self, client: GqldbClient):
        """Logout from a valid session."""
        if not check_auth_enabled(client):
            pytest.skip("Auth disabled")
        client.login(TEST_USERNAME, TEST_PASSWORD)
        assert client.is_logged_in()
        client.logout()
        assert not client.is_logged_in()
        client.close()

    def test_logout_twice(self, client: GqldbClient):
        """Logout twice should handle gracefully."""
        if not check_auth_enabled(client):
            pytest.skip("Auth disabled")
        client.login(TEST_USERNAME, TEST_PASSWORD)
        client.logout()
        # Second logout should not crash (may raise error)
        try:
            client.logout()
        except GqldbError:
            pass  # Expected
        client.close()


@pytest.mark.integration
class TestPing:
    """Tests for Ping."""

    def test_ping_logged_in(self, connected_client: GqldbClient):
        """Ping with valid session."""
        latency = connected_client.ping()
        assert latency >= 0

    def test_ping_multiple(self, connected_client: GqldbClient):
        """Multiple pings should all succeed."""
        for _ in range(5):
            latency = connected_client.ping()
            assert latency >= 0


@pytest.mark.integration
class TestSessionNoAuth:
    """Tests for server without authentication."""

    def test_ping_without_login(self, no_auth_client: GqldbClient):
        """Ping works without login on no-auth server."""
        latency = no_auth_client.ping()
        assert latency >= 0

    def test_login_returns_error(self, no_auth_client: GqldbClient):
        """Login on no-auth server should fail."""
        with pytest.raises(GqldbError) as exc_info:
            no_auth_client.login(TEST_USERNAME, TEST_PASSWORD)
        assert "authentication is not enabled" in str(exc_info.value).lower()

    def test_query_without_login(self, no_auth_client: GqldbClient):
        """Query works without login on no-auth server."""
        try:
            resp = no_auth_client.gql("MATCH (n) RETURN n LIMIT 1")
            assert resp is not None
        except GqldbError as e:
            if "not found" not in str(e).lower():
                raise
