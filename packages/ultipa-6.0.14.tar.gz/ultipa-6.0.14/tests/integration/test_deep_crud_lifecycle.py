"""Deep CRUD Lifecycle integration tests."""

import time
import pytest

from gqldb.client import GqldbClient, QueryConfig


@pytest.mark.integration
class TestDeepCRUDLifecycle:

    @pytest.fixture(scope="class")
    def test_graph(self, connected_client: GqldbClient):
        graph_name = f"test_crud_lc_{int(time.time() * 1000)}"
        connected_client.create_graph(graph_name)
        time.sleep(0.5)
        yield graph_name
        try:
            connected_client.use_graph("default")
        except Exception:
            pass
        try:
            connected_client.drop_graph(graph_name, if_exists=True)
        except Exception:
            pass

    @pytest.fixture(autouse=True)
    def clean_data(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        try:
            connected_client.gql("MATCH (n) DETACH DELETE n", cfg)
        except Exception:
            pass
        yield

    def test_node_crud_string(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Person {_id: 'c1', name: 'Alice'})", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c1' RETURN n.name AS name", cfg)
        assert str(r.get_by_name(r.rows[0], "name")) == "Alice"

        connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c1' SET n.name = 'Alice Updated'", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c1' RETURN n.name AS name", cfg)
        assert str(r.get_by_name(r.rows[0], "name")) == "Alice Updated"

        connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c1' DELETE n", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c1' RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "0"

    def test_node_crud_int(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Person {_id: 'c2', age: 25})", cfg)
        connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c2' SET n.age = 30", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c2' RETURN n.age AS age", cfg)
        assert str(r.get_by_name(r.rows[0], "age")) == "30"

    def test_node_set_multiple(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Person {_id: 'c3', name: 'Eve', age: 20, score: 70.0})", cfg)
        connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c3' SET n.name = 'Eve V2', n.age = 25, n.score = 90.0", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c3' RETURN n.name, n.age", cfg)
        assert str(r.get_by_name(r.rows[0], "n.name")) == "Eve V2"
        assert str(r.get_by_name(r.rows[0], "n.age")) == "25"

    def test_node_set_unicode(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Person {_id: 'c4', name: 'test'})", cfg)
        connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c4' SET n.name = '你好世界🚀'", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'c4' RETURN n.name AS name", cfg)
        assert "你好" in str(r.get_by_name(r.rows[0], "name"))

    def test_detach_delete(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'dd1'}), (:P {_id: 'dd2'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='dd1'), (b WHERE id(b)='dd2') INSERT (a)-[:KNOWS]->(b)", cfg)
        with pytest.raises(Exception):
            connected_client.gql("MATCH (n) WHERE id(n) = 'dd1' DELETE n", cfg)
        connected_client.gql("MATCH (n) WHERE id(n) = 'dd1' DETACH DELETE n", cfg)
        r = connected_client.gql("MATCH (n) WHERE id(n) = 'dd1' RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "0"

    def test_delete_with_where(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Temp {name: 'keep', tag: 'A'}), (:Temp {name: 'd1', tag: 'B'}), (:Temp {name: 'd2', tag: 'B'})", cfg)
        connected_client.gql("MATCH (n:Temp) WHERE n.tag = 'B' DELETE n", cfg)
        r = connected_client.gql("MATCH (n:Temp) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "1"

    def test_edge_crud(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'ea'}), (:P {_id: 'eb'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='ea'), (b WHERE id(b)='eb') INSERT (a)-[:KNOWS {since: 2020}]->(b)", cfg)

        r = connected_client.gql("MATCH (a)-[e:KNOWS]->(b) WHERE id(a)='ea' RETURN e.since AS since", cfg)
        assert str(r.get_by_name(r.rows[0], "since")) == "2020"

        connected_client.gql("MATCH (a)-[e:KNOWS]->(b) WHERE id(a)='ea' SET e.since = 2025", cfg)
        r = connected_client.gql("MATCH (a)-[e:KNOWS]->(b) WHERE id(a)='ea' RETURN e.since AS since", cfg)
        assert str(r.get_by_name(r.rows[0], "since")) == "2025"

        connected_client.gql("MATCH (a)-[e:KNOWS]->(b) WHERE id(a)='ea' DELETE e", cfg)
        r = connected_client.gql("MATCH (a)-[e:KNOWS]->(b) WHERE id(a)='ea' RETURN count(e) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "0"

    def test_multi_hop_query(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'h1', name: 'A'}), (:P {_id: 'h2', name: 'B'}), (:P {_id: 'h3', name: 'C'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='h1'), (b WHERE id(b)='h2') INSERT (a)-[:NEXT]->(b)", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='h2'), (b WHERE id(b)='h3') INSERT (a)-[:NEXT]->(b)", cfg)
        r = connected_client.gql("MATCH (a)-[:NEXT]->(b)-[:NEXT]->(c) WHERE id(a)='h1' RETURN c.name AS name", cfg)
        assert r.row_count == 1
        assert str(r.get_by_name(r.rows[0], "name")) == "C"

    def test_read_after_write(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        for i in range(10):
            connected_client.gql(f"INSERT (:RAW {{_id: 'raw{i}', val: {i}}})", cfg)
            r = connected_client.gql(f"MATCH (n:RAW) WHERE id(n) = 'raw{i}' RETURN n.val AS val", cfg)
            assert str(r.get_by_name(r.rows[0], "val")) == str(i)

    def test_update_same_node_multiple_times(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Counter {_id: 'um1', counter: 0})", cfg)
        for i in range(1, 11):
            connected_client.gql(f"MATCH (n:Counter) WHERE id(n) = 'um1' SET n.counter = {i}", cfg)
        r = connected_client.gql("MATCH (n:Counter) WHERE id(n) = 'um1' RETURN n.counter AS val", cfg)
        assert str(r.get_by_name(r.rows[0], "val")) == "10"

    def test_friend_of_friend(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:User {_id: 'u1', name: 'Alice'}), (:User {_id: 'u2', name: 'Bob'}), (:User {_id: 'u3', name: 'Charlie'}), (:User {_id: 'u4', name: 'Diana'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='u1'), (b WHERE id(b)='u2') INSERT (a)-[:FRIEND]->(b)", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='u2'), (b WHERE id(b)='u3') INSERT (a)-[:FRIEND]->(b)", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='u2'), (b WHERE id(b)='u4') INSERT (a)-[:FRIEND]->(b)", cfg)
        r = connected_client.gql("MATCH (a:User)-[:FRIEND]->(b)-[:FRIEND]->(c) WHERE id(a) = 'u1' RETURN c.name AS name ORDER BY name", cfg)
        assert r.row_count >= 2

    def test_star_topology(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Hub {_id: 'hub', name: 'center'})", cfg)
        for i in range(10):
            connected_client.gql(f"INSERT (:Leaf {{_id: 'leaf{i}', idx: {i}}})", cfg)
            connected_client.gql(f"MATCH (h WHERE id(h)='hub'), (l WHERE id(l)='leaf{i}') INSERT (h)-[:HAS]->(l)", cfg)
        r = connected_client.gql("MATCH (:Hub)-[e:HAS]->(:Leaf) RETURN count(e) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "10"

    def test_return_expression(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Calc {_id: 'c1', a: 10, b: 3})", cfg)
        r = connected_client.gql("MATCH (n:Calc) WHERE id(n) = 'c1' RETURN n.a + n.b AS sum_val, n.a * n.b AS prod_val", cfg)
        assert str(r.get_by_name(r.rows[0], "sum_val")) == "13"
        assert str(r.get_by_name(r.rows[0], "prod_val")) == "30"

    # ================================================================
    # Ported from the extended deep-coverage suite (gqldb-python-test):
    # these cover additional CRUD dimensions the shorter original version
    # omitted — bool/float scalars, empty-string / special-char / unicode
    # SET payloads, bulk DELETE, and edge property mutation.
    # ================================================================

    def test_node_crud_bool(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Person {_id: 'crud4', active: true})", cfg)
        connected_client.gql("MATCH (n:Person) WHERE id(n) = 'crud4' SET n.active = false", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'crud4' RETURN n.active AS val", cfg)
        assert r.row_count == 1

    def test_node_crud_float(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Person {_id: 'crud3', score: 85.5})", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'crud3' RETURN n.score AS score", cfg)
        assert r.row_count == 1
        connected_client.gql("MATCH (n:Person) WHERE id(n) = 'crud3' SET n.score = 95.0", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'crud3' RETURN n.score AS score", cfg)
        assert r.row_count == 1

    def test_node_set_empty_string(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Person {_id: 'crud6', name: 'Frank'})", cfg)
        connected_client.gql("MATCH (n:Person) WHERE id(n) = 'crud6' SET n.name = ''", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'crud6' RETURN n.name AS name", cfg)
        assert r.get_by_name(r.rows[0], "name") == ""

    def test_node_set_special_chars(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Person {_id: 'crud7', name: 'test'})", cfg)
        connected_client.gql(r"MATCH (n:Person) WHERE id(n) = 'crud7' SET n.name = 'it\'s a \"test\"'", cfg)
        r = connected_client.gql("MATCH (n:Person) WHERE id(n) = 'crud7' RETURN n.name AS name", cfg)
        assert r.row_count == 1

    def test_node_delete_all(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:X {name: '1'}), (:X {name: '2'}), (:X {name: '3'})", cfg)
        r = connected_client.gql("MATCH (n:X) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "3"
        connected_client.gql("MATCH (n:X) DELETE n", cfg)
        r = connected_client.gql("MATCH (n:X) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "0"

    def test_edge_set_multiple(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'ec'}), (:P {_id: 'ed'})", cfg)
        connected_client.gql(
            "MATCH (a WHERE id(a)='ec'), (b WHERE id(b)='ed') INSERT (a)-[:REL {w: 0.5, note: 'old'}]->(b)", cfg)
        connected_client.gql(
            "MATCH (a)-[e:REL]->(b) WHERE id(a)='ec' SET e.w = 0.9, e.note = 'updated'", cfg)
        r = connected_client.gql(
            "MATCH (a)-[e:REL]->(b) WHERE id(a)='ec' RETURN e.note AS note", cfg)
        assert r.get_by_name(r.rows[0], "note") == "updated"

    def test_edge_delete_by_label(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'ef'}), (:P {_id: 'eg'}), (:P {_id: 'eh'})", cfg)
        connected_client.gql(
            "MATCH (a WHERE id(a)='ef'), (b WHERE id(b)='eg') INSERT (a)-[:DEL_TEST]->(b)", cfg)
        connected_client.gql(
            "MATCH (a WHERE id(a)='eg'), (b WHERE id(b)='eh') INSERT (a)-[:DEL_TEST]->(b)", cfg)
        connected_client.gql("MATCH ()-[e:DEL_TEST]->() DELETE e", cfg)
        r = connected_client.gql("MATCH ()-[e:DEL_TEST]->() RETURN count(e) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "0"
