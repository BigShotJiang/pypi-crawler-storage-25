"""PropertyType integration tests.

Includes roundtrip verification for encode/decode correctness.
"""

import pytest
import uuid
from datetime import datetime, date
import math

from gqldb.client import GqldbClient, QueryConfig
from gqldb.types import GraphType, NodeData, EdgeData
from tests.conftest import drop_test_graph
from gqldb.types.data_types import (
    Point,
    Point3D,
    GqldbDecimal,
    GqldbLocalDateTime,
    GqldbZonedDateTime,
    GqldbLocalTime,
    GqldbZonedTime,
    YearToMonth,
    DayToSecond,
    Vector,
)


@pytest.mark.integration
class TestPropertyTypes:
    """Tests for all PropertyType values."""

    @pytest.fixture
    def propertytype_graph(self, connected_client: GqldbClient, request):
        """Create a temporary test graph for PropertyType tests."""
        graph_name = f"test_propertytype_{uuid.uuid4().hex[:8]}"
        connected_client.create_graph(graph_name, GraphType.OPEN, "PropertyType test graph")
        yield graph_name
        drop_test_graph(connected_client, graph_name)

    def test_insert_nodes_all_property_types(self, connected_client: GqldbClient, propertytype_graph: str):
        """Test inserting nodes with all supported PropertyTypes."""
        # Start bulk import session
        session = connected_client.start_bulk_import(propertytype_graph)

        try:
            now = datetime.now()
            today = date.today()

            nodes = [
                NodeData(
                    labels=["TestAllTypes"],
                    properties={
                        # Basic numeric types
                        "prop_int32": 42,
                        "prop_int64": 9223372036854775807,
                        "prop_float": 3.14,
                        "prop_double": 3.141592653589793,
                        # String types
                        "prop_string": "Hello, World!",
                        "prop_unicode": "你好世界 🌍",
                        # Boolean
                        "prop_bool_true": True,
                        "prop_bool_false": False,
                        # Time types
                        "prop_timestamp": now,
                        "prop_date": today,
                        # Binary
                        "prop_blob": bytes([0x00, 0x01, 0x02, 0xFF, 0xFE]),
                        # Complex types
                        "prop_list": ["a", "b", "c"],
                        "prop_list_mixed": [1, "two", 3.0],
                        "prop_map": {"key1": "value1", "key2": 2},
                        "prop_nested_list": [[1, 2], [3, 4]],
                    }
                ),
                NodeData(
                    labels=["TestNumericEdgeCases"],
                    properties={
                        # Edge cases for numeric types
                        "int32_min": -2147483648,
                        "int32_max": 2147483647,
                        "int64_min": -9223372036854775808,
                        "int64_max": 9223372036854775807,
                        "float_zero": 0.0,
                        "float_neg": -123.456,
                    }
                ),
                NodeData(
                    labels=["TestStringEdgeCases"],
                    properties={
                        "empty_string": "",
                        "special_chars": "!@#$%^&*()_+-=[]{}|;':\",./<>?",
                        "newlines": "line1\nline2\rline3",
                        "emoji_string": "😀🎉🚀💻🌟",
                        "japanese": "日本語テスト",
                        "arabic": "اختبار عربي",
                    }
                ),
            ]

            result = connected_client.insert_nodes_batch_auto(
                propertytype_graph,
                nodes,
                bulk_import_session_id=session.session_id
            )
            assert result.success
            assert result.node_count == 3

            print(f"Inserted {result.node_count} nodes with all PropertyTypes")
        finally:
            connected_client.end_bulk_import(session.session_id)

        # Verify by query
        config = QueryConfig(graph_name=propertytype_graph)
        response = connected_client.gql("MATCH (n:TestAllTypes) RETURN n", config)
        print(f"Verification query returned {len(response.rows)} rows")

    def test_insert_edges_all_property_types(self, connected_client: GqldbClient, propertytype_graph: str):
        """Test inserting edges with all supported PropertyTypes."""
        # Start bulk import session
        session = connected_client.start_bulk_import(propertytype_graph)

        try:
            # First insert nodes
            nodes = [
                NodeData(labels=["Source"], properties={"name": "SourceNode"}),
                NodeData(labels=["Target"], properties={"name": "TargetNode"}),
            ]
            node_result = connected_client.insert_nodes_batch_auto(
                propertytype_graph,
                nodes,
                bulk_import_session_id=session.session_id
            )
            assert node_result.success

            # Query to get node IDs
            config = QueryConfig(graph_name=propertytype_graph)
            resp = connected_client.gql(
                "MATCH (n) WHERE n.name IN ['SourceNode', 'TargetNode'] RETURN id(n) AS node_id, n.name ORDER BY n.name",
                config
            )

            node_ids = []
            for i in range(resp.row_count):
                row = resp.rows[i]
                value = resp.get_by_name(row, "node_id")
                if value:
                    node_ids.append(value)

            assert len(node_ids) >= 2
            from_id = node_ids[0]
            to_id = node_ids[1]
            now = datetime.now()

            edges = [
                EdgeData(
                    label="HAS_ALL_TYPES",
                    from_node_id=from_id,
                    to_node_id=to_id,
                    properties={
                        # Numeric types
                        "edge_int32": 100,
                        "edge_int64": 200,
                        "edge_double": 3.14159,
                        # String types
                        "edge_string": "edge property",
                        "edge_unicode": "边缘属性 🔗",
                        # Boolean
                        "edge_bool": True,
                        # Time
                        "edge_timestamp": now,
                        # Binary
                        "edge_blob": bytes([0xDE, 0xAD, 0xBE, 0xEF]),
                        # Complex types
                        "edge_list": ["x", "y", "z"],
                        "edge_map": {"weight": 1.5, "type": "strong"},
                    }
                ),
                EdgeData(
                    label="NUMERIC_EDGE",
                    from_node_id=from_id,
                    to_node_id=to_id,
                    properties={
                        "weight": 0.75,
                        "count": 42,
                        "distance": 1234.5678,
                    }
                ),
            ]

            result = connected_client.insert_edges_batch_auto(
                propertytype_graph,
                edges,
                bulk_import_session_id=session.session_id
            )
            assert result.success
            assert result.edge_count == 2

            print(f"Inserted {result.edge_count} edges with all PropertyTypes")
        finally:
            connected_client.end_bulk_import(session.session_id)


# ============================================================================
# Roundtrip Tests - Verify encode/decode correctness for all property types
# ============================================================================

@pytest.mark.integration
class TestPropertyTypeRoundtrip:
    """Roundtrip tests for all PropertyType values."""

    @pytest.fixture
    def roundtrip_graph(self, connected_client: GqldbClient):
        """Create a temporary test graph for roundtrip tests."""
        graph_name = f"test_roundtrip_{uuid.uuid4().hex[:8]}"
        connected_client.create_graph(graph_name, GraphType.OPEN, "Roundtrip test graph")
        yield graph_name
        drop_test_graph(connected_client, graph_name)

    def insert_and_query_property(
        self, client: GqldbClient, graph_name: str, prop_name: str, prop_value
    ):
        """Insert a node with a property and query it back."""
        # Ensure session graph context points to the test graph
        client.use_graph(graph_name)

        # Start bulk import session
        session = client.start_bulk_import(graph_name)

        try:
            nodes = [NodeData(labels=["RoundtripTest"], properties={prop_name: prop_value})]
            result = client.insert_nodes_batch_auto(graph_name, nodes, bulk_import_session_id=session.session_id)
            assert result.success

            # Query to get node ID
            config = QueryConfig(graph_name=graph_name)
            query_for_id = f"MATCH (n:RoundtripTest) WHERE n.{prop_name} IS NOT NULL RETURN id(n) AS node_id ORDER BY id(n) DESC LIMIT 1"
            resp_id = client.gql(query_for_id, config)
            assert resp_id.row_count > 0

            node_id = resp_id.get_by_name(resp_id.rows[0], "node_id")

            # Query back the property
            query = f"MATCH (n:RoundtripTest) WHERE id(n) = '{node_id}' RETURN n.{prop_name} AS value"
            resp = client.gql(query, config)
            assert resp.row_count > 0

            return resp.get_by_name(resp.rows[0], "value")
        finally:
            client.end_bulk_import(session.session_id)

    # --- Numeric Types ---

    @pytest.mark.parametrize("idx,value", [
        (0, 0),
        (1, 9223372036854775807),
        (2, 1234567890123),
    ])
    def test_int64_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, value: int):
        """Test Int64 roundtrip."""
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"int64_{idx}", value)
        assert result == value

    @pytest.mark.parametrize("idx,value", [
        (0, 0.0),
        (1, 3.141592653589793),
        (2, 1e-300),
        (3, 1e300),
    ])
    def test_float64_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, value: float):
        """Test Float64 roundtrip."""
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"float64_{idx}", value)
        # Database may return int for integer-valued floats
        if isinstance(result, int):
            result = float(result)
        assert abs(result - value) < 1e-10

    # --- String Types ---

    @pytest.mark.parametrize("idx,value", [
        (0, ""),
        (1, "Hello, World!"),
        (2, "你好世界 🌍"),
        (3, "😀🎉🚀💻🌟"),
        (4, "!@#$%^&*()_+-=[]{}|;':\",./<>?"),
        (5, "line1\nline2\rline3"),
        (6, "日本語テスト"),
        (7, "اختبار عربي"),
    ])
    def test_string_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, value: str):
        """Test String roundtrip."""
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"str_{idx}", value)
        assert result == value

    @pytest.mark.parametrize("idx,value", [
        (0, b""),
        (1, bytes([0x00, 0x01, 0x02, 0xFF, 0xFE])),
        (2, bytes([0xDE, 0xAD, 0xBE, 0xEF])),
    ])
    def test_blob_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, value: bytes):
        """Test Blob roundtrip."""
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"blob_{idx}", value)
        assert result == value

    # --- Boolean Type ---

    @pytest.mark.parametrize("value", [True, False])
    def test_bool_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, value: bool):
        """Test Bool roundtrip."""
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"bool_{value}", value)
        assert result == value

    # --- Spatial Types ---

    @pytest.mark.parametrize("idx,lat,lon", [
        (0, 40.7128, -74.0060),
        (1, 0.0, 0.0),
        (2, 35.6762, 139.6503),
        (3, 90.0, 180.0),
        (4, -90.0, -180.0),
    ])
    def test_point_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, lat: float, lon: float):
        """Test Point roundtrip."""
        point = Point(latitude=lat, longitude=lon)
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"point_{idx}", point)
        assert isinstance(result, Point)
        assert abs(result.latitude - lat) < 1e-10
        assert abs(result.longitude - lon) < 1e-10

    @pytest.mark.parametrize("idx,x,y,z", [
        (0, 0.0, 0.0, 0.0),
        (1, 1.0, 2.0, 3.0),
        (2, -1.5, -2.5, -3.5),
        (3, 1e10, 1e10, 1e10),
    ])
    def test_point3d_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, x: float, y: float, z: float):
        """Test Point3D roundtrip."""
        point = Point3D(x=x, y=y, z=z)
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"point3d_{idx}", point)
        assert isinstance(result, Point3D)
        assert abs(result.x - x) < 1e-10
        assert abs(result.y - y) < 1e-10
        assert abs(result.z - z) < 1e-10

    # --- Special Types ---

    @pytest.mark.parametrize("idx,value", [
        (0, "123.456"),
        (1, "-987.654321"),
        (2, "12345"),
    ])
    def test_decimal_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, value: str):
        """Test Decimal roundtrip."""
        decimal = GqldbDecimal(value=value)
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"decimal_{idx}", decimal)
        # Database may return decimal as string or GqldbDecimal object
        if isinstance(result, GqldbDecimal):
            assert result.value == value
        elif isinstance(result, str):
            assert result == value
        else:
            print(f"Decimal {idx} returned type: {type(result)}, value: {result}")
            assert result is not None

    @pytest.mark.parametrize("idx,values", [
        (0, [1.0, 2.0, 3.0, 4.0]),
        (1, [0.5, 0.5, 0.5, 0.5]),
        (2, [-1.0, -2.0, 0.0, 1.0]),
    ])
    def test_vector_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, values: list):
        """Test Vector roundtrip."""
        vector = Vector(values=values)
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"vector_{idx}", vector)
        assert isinstance(result, Vector)
        assert len(result.values) == len(values)
        for i, v in enumerate(values):
            assert abs(result.values[i] - v) < 1e-5

    # --- Temporal Types ---

    @pytest.mark.parametrize("idx,nanos", [
        (0, 1718458245123456789),
        (1, 1718409600000000000),
    ])
    def test_local_datetime_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, nanos: int):
        """Test LocalDateTime roundtrip."""
        from datetime import datetime, timezone
        epoch_seconds = nanos // 1_000_000_000
        sub_nanos = nanos % 1_000_000_000
        dt = datetime.fromtimestamp(epoch_seconds, tz=timezone.utc)
        ldt = GqldbLocalDateTime(
            year=dt.year, month=dt.month, day=dt.day,
            hour=dt.hour, minute=dt.minute, second=dt.second,
            nanosecond=sub_nanos,
        )
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"ldt_{idx}", ldt)
        # Database may return as GqldbLocalDateTime or other type
        if isinstance(result, GqldbLocalDateTime):
            assert result.year == ldt.year
            assert result.month == ldt.month
            assert result.day == ldt.day
        else:
            print(f"LocalDateTime {idx} returned type: {type(result)}, value: {result}")
            assert result is not None

    @pytest.mark.skip(reason="Database may not support ZonedDateTime type in this schema")
    @pytest.mark.parametrize("idx,nanos,offset", [
        (0, 1718458245000000000, 0),
    ])
    def test_zoned_datetime_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, nanos: int, offset: int):
        """Test ZonedDateTime roundtrip."""
        zdt = GqldbZonedDateTime(nanos=nanos, offset_seconds=offset)
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"zdt_{idx}", zdt)
        assert isinstance(result, GqldbZonedDateTime)

    @pytest.mark.parametrize("idx,hour,minute,second,nanosecond", [
        (0, 0, 0, 0, 0),
        (1, 12, 0, 0, 0),
    ])
    def test_local_time_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, hour: int, minute: int, second: int, nanosecond: int):
        """Test LocalTime roundtrip."""
        lt = GqldbLocalTime(hour=hour, minute=minute, second=second, nanosecond=nanosecond)
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"lt_{idx}", lt)
        if isinstance(result, GqldbLocalTime):
            assert result.hour == hour and result.minute == minute and result.second == second
        else:
            print(f"LocalTime {idx} returned type: {type(result)}, value: {result}")
            assert result is not None

    @pytest.mark.skip(reason="Database may not support ZonedTime type in this schema")
    @pytest.mark.parametrize("idx,nanos,offset", [
        (0, 43200000000000, 0),
    ])
    def test_zoned_time_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, nanos: int, offset: int):
        """Test ZonedTime roundtrip."""
        zt = GqldbZonedTime(nanos_of_day=nanos, offset_seconds=offset)
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"zt_{idx}", zt)
        assert isinstance(result, GqldbZonedTime)

    @pytest.mark.parametrize("idx,months", [
        (0, 0),
        (1, 12),
        (2, 18),
    ])
    def test_year_to_month_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, months: int):
        """Test YearToMonth roundtrip."""
        ytm = YearToMonth(months=months)
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"ytm_{idx}", ytm)
        if isinstance(result, YearToMonth):
            assert result.months == months
        else:
            print(f"YearToMonth {idx} returned type: {type(result)}, value: {result}")
            assert result is not None

    @pytest.mark.skip(reason="Database may not support DayToSecond type in all graph schemas")
    @pytest.mark.parametrize("idx,nanos", [
        (0, 0),
        (1, 86400000000000),
    ])
    def test_day_to_second_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, nanos: int):
        """Test DayToSecond roundtrip."""
        dts = DayToSecond(seconds=nanos // 1_000_000_000, nanoseconds=nanos % 1_000_000_000)
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"dts_{idx}", dts)
        if isinstance(result, DayToSecond):
            assert result.seconds == nanos // 1_000_000_000
            assert result.nanoseconds == nanos % 1_000_000_000

    # --- Collection Types ---

    @pytest.mark.skip(reason="List type may not be supported in all graph schemas")
    @pytest.mark.parametrize("idx,value", [
        (0, ["a", "b", "c"]),
        (1, [1, 2, 3]),
    ])
    def test_list_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, value: list):
        """Test List roundtrip."""
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"list_{idx}", value)
        assert isinstance(result, list)
        assert len(result) == len(value)

    @pytest.mark.skip(reason="Map type may not be supported in all graph schemas")
    @pytest.mark.parametrize("idx,value", [
        (0, {"key1": "value1", "key2": 42}),
        (1, {"str": "text", "num": 123, "bool": True}),
    ])
    def test_map_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, value: dict):
        """Test Map roundtrip."""
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"map_{idx}", value)
        assert isinstance(result, dict)
        assert len(result) == len(value)

    @pytest.mark.skip(reason="Set type may not be supported in all graph schemas")
    @pytest.mark.parametrize("idx,value", [
        (0, {"a", "b", "c"}),
        (1, {1, 2, 3}),
    ])
    def test_set_roundtrip(self, connected_client: GqldbClient, roundtrip_graph: str, idx: int, value: set):
        """Test Set roundtrip."""
        result = self.insert_and_query_property(connected_client, roundtrip_graph, f"set_{idx}", value)
        # Set may be returned as list or set
        if isinstance(result, set):
            assert len(result) == len(value)
        else:
            assert len(result) == len(value)
