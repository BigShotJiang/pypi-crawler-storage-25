"""Deep RPC Coverage integration tests."""

import time
import threading
import pytest

from gqldb.client import GqldbClient, QueryConfig
from gqldb.response import ExportConfig, ExportChunk
from gqldb.types import GraphType, NodeData, EdgeData
from tests.conftest import drop_test_graph

TEST_DATABASE = "miniCircle"


def _is_unimplemented(e: Exception) -> bool:
    return "UNIMPLEMENTED" in str(e).upper()


@pytest.mark.integration
class TestDeepRPCCoverage:

    @pytest.fixture(scope="class")
    def test_graph(self, connected_client: GqldbClient):
        graph_name = f"test_deeprpc_{int(time.time() * 1000)}"
        connected_client.create_graph(graph_name, GraphType.OPEN, "Test deep rpc graph")
        time.sleep(0.5)
        yield graph_name
        drop_test_graph(connected_client, graph_name)

    def test_top(self, connected_client: GqldbClient, test_graph: str):
        try:
            processes = connected_client.top()
            assert processes is not None
            print(f"Top returned {len(processes)} processes")
            for p in processes:
                print(f"  Process: {p}")
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: Top is not implemented on this server")
            else:
                raise

    def test_kill_nonexistent_query(self, connected_client: GqldbClient, test_graph: str):
        try:
            connected_client.kill("nonexistent_query_id_99999")
            print("Kill nonexistent returned without error")
        except Exception as e:
            print(f"Kill nonexistent query threw as expected: {e}")

    def test_show_tasks(self, connected_client: GqldbClient, test_graph: str):
        try:
            tasks = connected_client.show_tasks()
            assert tasks is not None
            print(f"ShowTasks returned {len(tasks)} tasks")
            for t in tasks:
                print(f"  Task: {t}")
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: ShowTasks is not implemented on this server")
            else:
                raise

    def test_task_lifecycle(self, connected_client: GqldbClient, test_graph: str):
        try:
            bg_error = [None]

            def run_algo():
                try:
                    connected_client.gql(
                        "CALL algo.louvain() ON alimama YIELD nodeId, communityId LIMIT 10",
                        QueryConfig(graph_name="alimama")
                    )
                except Exception as e:
                    bg_error[0] = e

            thread = threading.Thread(target=run_algo)
            thread.start()

            time.sleep(0.5)

            tasks = connected_client.show_tasks()
            assert tasks is not None
            print(f"Tasks after starting algo: {len(tasks)}")

            task_id = None
            for t in tasks:
                print(f"  Task: {t}")
                task_id = getattr(t, 'task_id', None)

            if task_id:
                try:
                    connected_client.stop_task(task_id)
                    print(f"StopTask returned for task {task_id}")
                except Exception as e:
                    print(f"StopTask error (may already be finished): {e}")

                try:
                    connected_client.delete_task(task_id)
                    print(f"DeleteTask returned for task {task_id}")
                except Exception as e:
                    print(f"DeleteTask error: {e}")
            else:
                print("No tasks found (algo may have completed too quickly)")

            thread.join(timeout=30)

        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: Task operations not implemented on this server")
            else:
                raise

    def test_stop_task_nonexistent(self, connected_client: GqldbClient, test_graph: str):
        try:
            connected_client.stop_task("nonexistent_task_id_99999")
            print("StopTask nonexistent returned without error")
        except Exception as e:
            print(f"StopTask nonexistent threw as expected: {e}")

    def test_delete_task_nonexistent(self, connected_client: GqldbClient, test_graph: str):
        try:
            connected_client.delete_task("nonexistent_task_id_99999")
            print("DeleteTask nonexistent returned without error")
        except Exception as e:
            print(f"DeleteTask nonexistent threw as expected: {e}")

    def test_gql_stream(self, connected_client: GqldbClient, test_graph: str):
        try:
            responses = []

            def callback(response):
                assert response is not None
                responses.append(response)

            connected_client.gql_stream(
                "MATCH (n) RETURN n LIMIT 100",
                QueryConfig(graph_name=TEST_DATABASE),
                callback=callback
            )

            assert len(responses) > 0, "Should receive at least one streaming response"
            print(f"GqlStream received {len(responses)} responses")

        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: GqlStream is not implemented on this server")
            else:
                raise

    def test_explain(self, connected_client: GqldbClient, test_graph: str):
        try:
            plan = connected_client.explain(
                "MATCH (n) RETURN n LIMIT 10",
                QueryConfig(graph_name=TEST_DATABASE)
            )
            assert plan is not None
            assert len(plan) > 0
            print(f"Explain result length: {len(plan)}")
            print(f"Explain result (truncated): {plan[:500]}")
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: Explain is not implemented on this server")
            else:
                raise

    def test_profile(self, connected_client: GqldbClient, test_graph: str):
        try:
            result = connected_client.profile(
                "MATCH (n) RETURN n LIMIT 10",
                QueryConfig(graph_name=TEST_DATABASE)
            )
            assert result is not None
            assert len(result) > 0
            print(f"Profile result length: {len(result)}")
            print(f"Profile result (truncated): {result[:500]}")
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: Profile is not implemented on this server")
            else:
                raise

    def test_export_nodes(self, connected_client: GqldbClient, test_graph: str):
        try:
            chunks = []
            all_data = []

            def callback(chunk: ExportChunk):
                assert chunk is not None
                chunks.append(chunk)
                all_data.append(chunk.get_data_as_string())

            config = ExportConfig(
                graph_name=TEST_DATABASE,
                export_nodes=True,
                export_edges=False,
                batch_size=100
            )
            connected_client.export(config, callback)

            assert len(chunks) > 0, "Should receive at least one export chunk"
            total_bytes = sum(len(d) for d in all_data)
            print(f"Export nodes: {len(chunks)} chunks, {total_bytes} bytes")

        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: Export is not implemented on this server")
            else:
                raise

    def test_export_edges(self, connected_client: GqldbClient, test_graph: str):
        try:
            chunks = []
            all_data = []

            def callback(chunk: ExportChunk):
                assert chunk is not None
                chunks.append(chunk)
                all_data.append(chunk.get_data_as_string())

            config = ExportConfig(
                graph_name=TEST_DATABASE,
                export_nodes=False,
                export_edges=True,
                batch_size=100
            )
            connected_client.export(config, callback)

            assert len(chunks) > 0, "Should receive at least one export chunk"
            total_bytes = sum(len(d) for d in all_data)
            print(f"Export edges: {len(chunks)} chunks, {total_bytes} bytes")

        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: Export is not implemented on this server")
            else:
                raise

    def test_bulk_import_full_flow(self, connected_client: GqldbClient):
        bulk_graph = f"test_bulkfull_{int(time.time() * 1000)}"
        connected_client.create_graph(bulk_graph, GraphType.OPEN, "Test bulk full flow")
        time.sleep(0.5)
        session = None
        try:
            if not hasattr(connected_client, 'start_bulk_import'):
                print("SKIP: start_bulk_import not available")
                return

            session = connected_client.start_bulk_import(bulk_graph)
            assert session is not None
            assert session.success
            assert session.session_id
            session_id = session.session_id
            print(f"BulkImport started, sessionId={session_id}")

            nodes = []
            for i in range(100):
                nodes.append(NodeData(labels=["BulkNode"], properties={"index": i, "name": f"node_{i}"}))
            nodes_result = connected_client.insert_nodes_batch_auto(
                bulk_graph, nodes, bulk_import_session_id=session_id
            )
            assert nodes_result is not None
            print(f"Inserted nodes: success={nodes_result.success}, count={nodes_result.node_count}")

            if nodes_result.success and hasattr(nodes_result, 'node_ids') and len(nodes_result.node_ids) >= 100:
                edges = []
                node_ids = nodes_result.node_ids
                for i in range(50):
                    edges.append(EdgeData(
                        label="BulkEdge",
                        from_node_id=node_ids[i * 2],
                        to_node_id=node_ids[i * 2 + 1],
                        properties={"weight": float(i)}
                    ))
                edges_result = connected_client.insert_edges_batch_auto(
                    bulk_graph, edges, bulk_import_session_id=session_id
                )
                assert edges_result is not None
                print(f"Inserted edges: success={edges_result.success}, count={edges_result.edge_count}")

            status = connected_client.get_bulk_import_status(session_id)
            print(f"BulkImport status: active={status.is_active}, records={status.record_count}")

            end_result = connected_client.end_bulk_import(session_id)
            assert end_result is not None
            assert end_result.success
            print(f"BulkImport ended: totalRecords={end_result.total_records}")
            session = None

            count_resp = connected_client.gql("MATCH (n:BulkNode) RETURN count(n)", QueryConfig(graph_name=bulk_graph))
            assert count_resp is not None
            print(f"Verification query rows: {count_resp.row_count}")

        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: BulkImport is not implemented on this server")
            else:
                raise
        finally:
            if session is not None:
                try:
                    connected_client.end_bulk_import(session.session_id)
                except Exception:
                    pass
            drop_test_graph(connected_client, bulk_graph)

    def test_bulk_import_abort(self, connected_client: GqldbClient):
        abort_graph = f"test_bulkabort_{int(time.time() * 1000)}"
        connected_client.create_graph(abort_graph, GraphType.OPEN, "Test bulk abort")
        time.sleep(0.5)
        session = None
        try:
            if not hasattr(connected_client, 'start_bulk_import'):
                print("SKIP: start_bulk_import not available")
                return

            session = connected_client.start_bulk_import(abort_graph)
            assert session is not None
            assert session.success
            session_id = session.session_id

            nodes = []
            for i in range(10):
                nodes.append(NodeData(labels=["AbortNode"], properties={"index": i}))
            connected_client.insert_nodes_batch_auto(
                abort_graph, nodes, bulk_import_session_id=session_id
            )

            abort_result = connected_client.abort_bulk_import(session_id)
            assert abort_result is not None
            assert abort_result.success
            print(f"BulkImport aborted: {getattr(abort_result, 'message', '')}")
            session = None

            try:
                count_resp = connected_client.gql("MATCH (n:AbortNode) RETURN count(n)", QueryConfig(graph_name=abort_graph))
                print(f"After abort, query returned rows: {count_resp.row_count}")
            except Exception as e:
                print(f"After abort, query failed as expected: {e}")

        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: BulkImport is not implemented on this server")
            else:
                raise
        finally:
            if session is not None:
                try:
                    connected_client.abort_bulk_import(session.session_id)
                except Exception:
                    pass
            drop_test_graph(connected_client, abort_graph)

    def test_concurrent_writes(self, connected_client: GqldbClient):
        conc_graph = f"test_concurrent_{int(time.time() * 1000)}"
        connected_client.create_graph(conc_graph, GraphType.OPEN, "Test concurrent writes")
        time.sleep(0.5)
        session = None
        try:
            if not hasattr(connected_client, 'start_bulk_import'):
                print("SKIP: start_bulk_import not available")
                return

            session = connected_client.start_bulk_import(conc_graph)
            assert session is not None
            session_id = session.session_id

            thread_count = 5
            nodes_per_thread = 20
            success_count = [0]
            error_count = [0]
            lock = threading.Lock()

            def worker(thread_idx: int):
                try:
                    nodes = []
                    for i in range(nodes_per_thread):
                        nodes.append(NodeData(
                            labels=["ConcNode"],
                            properties={"thread": thread_idx, "index": i, "name": f"t{thread_idx}_n{i}"}
                        ))
                    result = connected_client.insert_nodes_batch_auto(
                        conc_graph, nodes, bulk_import_session_id=session_id
                    )
                    if result.success:
                        with lock:
                            success_count[0] += 1
                except Exception as e:
                    with lock:
                        error_count[0] += 1
                    print(f"Thread {thread_idx} error: {e}")

            threads = []
            for t in range(thread_count):
                thread = threading.Thread(target=worker, args=(t,))
                threads.append(thread)
                thread.start()

            for thread in threads:
                thread.join(timeout=60)

            for thread in threads:
                assert not thread.is_alive(), "All threads should complete within 60 seconds"

            print(f"Concurrent writes: {success_count[0]} succeeded, {error_count[0]} failed out of {thread_count} threads")

            assert success_count[0] > 0, "At least one concurrent insert should succeed"

            end_result = connected_client.end_bulk_import(session_id)
            assert end_result is not None
            print(f"BulkImport ended after concurrent writes: totalRecords={end_result.total_records}")
            session = None

        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: BulkImport/concurrent writes not implemented on this server")
            else:
                raise
        finally:
            if session is not None:
                try:
                    connected_client.end_bulk_import(session.session_id)
                except Exception:
                    pass
            drop_test_graph(connected_client, conc_graph)

    # ================================================================
    # Ported from the extended deep-coverage suite (gqldb-python-test):
    # explicit Top/Watch/ShowTasks shape assertions, EXPLAIN/PROFILE
    # content sanity, GqlStream large/empty paths, BulkImport status
    # check, and a louvain-driven SHOW TASKS / STOP TASK / DELETE TASK
    # lifecycle.
    # ================================================================

    def test_top_returns_list(self, connected_client: GqldbClient, test_graph: str):
        try:
            processes = connected_client.top()
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: Top is not implemented on this server")
                return
            raise
        assert isinstance(processes, list)

    def test_top_fields(self, connected_client: GqldbClient, test_graph: str):
        try:
            processes = connected_client.top()
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: Top is not implemented on this server")
                return
            raise
        for p in processes:
            assert hasattr(p, "query_id")
            assert hasattr(p, "status")

    def test_kill_nonexistent(self, connected_client: GqldbClient, test_graph: str):
        # Kill of an unknown id should either no-op or raise — both are acceptable.
        try:
            connected_client.kill("nonexistent_query_id_999")
        except Exception:
            pass

    def test_show_tasks_empty_graph(self, connected_client: GqldbClient, test_graph: str):
        try:
            tasks = connected_client.show_tasks()
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: ShowTasks is not implemented on this server")
                return
            raise
        assert isinstance(tasks, list)

    def test_watch_basic(self, connected_client: GqldbClient, test_graph: str):
        # Watch may not be supported on every server; treat exceptions / "watch_iter
        # not present" as a skip rather than a failure.
        if not hasattr(connected_client, "watch_iter"):
            print("SKIP: watch_iter not available on this client")
            return
        try:
            for _ in connected_client.watch_iter(service=""):
                break
        except Exception as e:
            print(f"watch_iter not supported / errored: {e}")

    def test_gql_stream_large(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph, timeout=30)
        # Seed enough rows to make streaming meaningful.
        connected_client.gql(
            "INSERT " + ", ".join(f"(:StreamLarge {{_id: 'sl{i}', idx: {i}}})" for i in range(50)),
            cfg,
        )
        chunks = []
        try:
            connected_client.gql_stream(
                "MATCH (n:StreamLarge) RETURN n.idx LIMIT 100",
                callback=lambda chunk: chunks.append(chunk),
                config=cfg,
            )
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: gql_stream is not implemented on this server")
                return
            raise
        total_rows = sum(c.row_count for c in chunks)
        assert total_rows > 0

    def test_gql_stream_empty(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph, timeout=30)
        chunks = []
        try:
            connected_client.gql_stream(
                "MATCH (n:NonExistentLabel999) RETURN n",
                callback=lambda chunk: chunks.append(chunk),
                config=cfg,
            )
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: gql_stream is not implemented on this server")
                return
            # Empty stream may surface as either no chunks or a benign error;
            # we don't require a specific outcome here.
            print(f"gql_stream(empty) raised: {e}")

    def test_explain_content(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph, timeout=30)
        if not hasattr(connected_client, "explain"):
            print("SKIP: explain not available on this client")
            return
        try:
            plan = connected_client.explain("MATCH (n) RETURN n LIMIT 10", config=cfg)
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: explain not implemented on this server")
                return
            raise
        assert plan is not None
        assert len(str(plan)) > 0

    def test_explain_complex(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph, timeout=30)
        if not hasattr(connected_client, "explain"):
            print("SKIP: explain not available on this client")
            return
        try:
            plan = connected_client.explain(
                "MATCH (a)-[e]->(b) RETURN a, e, b LIMIT 10", config=cfg)
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: explain not implemented on this server")
                return
            raise
        assert len(str(plan)) > 10

    def test_profile_content(self, connected_client: GqldbClient, test_graph: str):
        cfg = QueryConfig(graph_name=test_graph, timeout=30)
        if not hasattr(connected_client, "profile"):
            print("SKIP: profile not available on this client")
            return
        try:
            prof = connected_client.profile("MATCH (n) RETURN n LIMIT 10", config=cfg)
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: profile not implemented on this server")
                return
            raise
        assert prof is not None
        assert len(str(prof)) > 0

    def test_bulk_import_status(self, connected_client: GqldbClient):
        status_graph = f"test_bulkstatus_{int(time.time() * 1000)}"
        connected_client.create_graph(status_graph, GraphType.OPEN, "Test bulk status")
        time.sleep(0.5)
        session = None
        try:
            if not hasattr(connected_client, "start_bulk_import"):
                print("SKIP: start_bulk_import not available")
                return
            session = connected_client.start_bulk_import(status_graph)
            assert session is not None and session.success
            try:
                status = connected_client.get_bulk_import_status(session.session_id)
                assert status is not None
                print(f"BulkImport status: active={status.is_active}, records={status.record_count}")
            except Exception as e:
                if _is_unimplemented(e):
                    print("SKIP: get_bulk_import_status not implemented")
                else:
                    raise
        finally:
            if session is not None:
                try:
                    connected_client.end_bulk_import(session.session_id)
                except Exception:
                    pass
            drop_test_graph(connected_client, status_graph)

    def test_task_lifecycle_louvain(self, connected_client: GqldbClient, test_graph: str):
        # Lightweight version of the python-test scenario — we don't depend on a
        # specific large preloaded graph (alimama). Just verify SHOW TASKS works
        # and STOP/DELETE on a synthetic id either no-ops or raises cleanly.
        cfg = QueryConfig(graph_name=test_graph, timeout=10)
        try:
            r = connected_client.gql("SHOW TASKS", cfg)
        except Exception as e:
            if _is_unimplemented(e):
                print("SKIP: SHOW TASKS not implemented")
                return
            raise
        assert r is not None
        # If there happens to be a task, exercise STOP / DELETE; otherwise the
        # synthetic-id branch covers error handling.
        if r.row_count > 0:
            task_id = str(r.get_by_name(r.rows[0], r.columns[0]))
        else:
            task_id = "nonexistent_task_999"
        for stmt in (f"STOP TASK {task_id}", f"DELETE TASK {task_id}"):
            try:
                connected_client.gql(stmt, cfg)
            except Exception:
                pass
