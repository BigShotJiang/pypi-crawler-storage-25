"""Deep Insert Types integration tests."""

import time
import pytest

from gqldb.client import GqldbClient, QueryConfig


@pytest.mark.integration
class TestDeepInsertTypes:

    @pytest.fixture(scope="class")
    def test_graph(self, connected_client: GqldbClient):
        graph_name = f"test_deep_ins_{int(time.time() * 1000)}"
        connected_client.create_graph(graph_name)
        time.sleep(0.5)
        connected_client.use_graph(graph_name)
        yield graph_name
        try:
            connected_client.use_graph("default")
        except Exception:
            pass
        try:
            connected_client.drop_graph(graph_name, if_exists=True)
        except Exception:
            pass

    def _clean_data(self, connected_client: GqldbClient, test_graph: str):
        try:
            connected_client.gql("MATCH (n) DETACH DELETE n", QueryConfig(graph_name=test_graph))
        except Exception:
            pass

    def _insert_and_verify(self, connected_client: GqldbClient, test_graph: str, label: str, props: str):
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql(f"INSERT (:{label} {{{props}}})", cfg)
        r = connected_client.gql(f"MATCH (n:{label}) RETURN count(n) AS cnt", cfg)
        assert r.row_count >= 1

    def test_int32_positive(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "IntTest", "_id: 'i1', val: 42")

    def test_int32_zero(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "IntTest", "_id: 'i2', val: 0")

    def test_int32_negative(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "IntTest", "_id: 'i3', val: -100")

    def test_int32_max(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "IntTest", "_id: 'i4', val: 2147483647")

    def test_int32_min(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "IntTest", "_id: 'i5', val: -2147483648")

    def test_int64_large(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "IntTest", "_id: 'i6', val: 9999999999999")

    def test_int64_large_neg(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "IntTest", "_id: 'i7', val: -9999999999999")

    def test_float_positive(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "FloatTest", "_id: 'f1', val: 3.14")

    def test_float_negative(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "FloatTest", "_id: 'f2', val: -1.5")

    def test_float_zero(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "FloatTest", "_id: 'f3', val: 0.0")

    def test_double_precision(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "FloatTest", "_id: 'f4', val: 3.141592653589793")

    def test_bool_true(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "BoolTest", "_id: 'b1', val: true")

    def test_bool_false(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "BoolTest", "_id: 'b2', val: false")

    def test_string_normal(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", "_id: 's1', val: 'hello world'")

    def test_string_empty(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", "_id: 's2', val: ''")

    def test_string_single_quote(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", "_id: 's3', val: 'it\\'s a test'")

    def test_string_unicode_chinese(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", "_id: 's4', val: '你好世界'")

    def test_string_unicode_emoji(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", "_id: 's5', val: '🚀🎉'")

    def test_string_long(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        s = "x" * 1000
        self._insert_and_verify(connected_client, test_graph, "StrTest", f"_id: 's6', val: '{s}'")

    def test_null_value(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:NullTest {_id: 'n1', name: 'test', val: NULL})", cfg)
        r = connected_client.gql("MATCH (n:NullTest) WHERE id(n) = 'n1' RETURN n.val AS val", cfg)
        assert r.row_count == 1

    def test_list_int(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "ListTest", "_id: 'l1', val: [1, 2, 3]")

    def test_list_str(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "ListTest", "_id: 'l2', val: ['a', 'b', 'c']")

    def test_list_empty(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "ListTest", "_id: 'l3', val: []")

    def test_list_nested(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "ListTest", "_id: 'l4', val: [[1, 2], [3, 4]]")

    def test_list_mixed(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "ListTest", "_id: 'l5', val: [1, 'two', 3.0, true]")

    def test_map_simple(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "MapTest", "_id: 'map1', val: {key: 'value', num: 42}")

    def test_map_empty(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "MapTest", "_id: 'map2', val: {}")

    def test_multi_type_properties(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:MultiType {_id: 'mt1', str_val: 'hello', int_val: 42, float_val: 3.14, bool_val: true, list_val: [1, 2, 3]})", cfg)
        r = connected_client.gql("MATCH (n:MultiType) WHERE id(n) = 'mt1' RETURN n.str_val", cfg)
        assert r.row_count == 1
        assert str(r.get_by_name(r.rows[0], "n.str_val")) == "hello"

    def test_overwrite_string(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:OW {_id: 'ow1', val: 'old'})", cfg)
        connected_client.gql("INSERT OVERWRITE (:OW {_id: 'ow1', val: 'new'})", cfg)
        r = connected_client.gql("MATCH (n:OW) WHERE id(n) = 'ow1' RETURN n.val AS val", cfg)
        assert str(r.get_by_name(r.rows[0], "val")) == "new"

    def test_overwrite_int(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:OW {_id: 'ow2', val: 100})", cfg)
        connected_client.gql("INSERT OVERWRITE (:OW {_id: 'ow2', val: 999})", cfg)
        r = connected_client.gql("MATCH (n:OW) WHERE id(n) = 'ow2' RETURN n.val AS val", cfg)
        assert str(r.get_by_name(r.rows[0], "val")) == "999"

    def test_overwrite_no_duplicate(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:OW {_id: 'ow3', val: 1})", cfg)
        connected_client.gql("INSERT OVERWRITE (:OW {_id: 'ow3', val: 2})", cfg)
        r = connected_client.gql("MATCH (n:OW) WHERE id(n) = 'ow3' RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "1"

    def test_insert_normal_duplicate_fails(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:Dup {_id: 'dup1', name: 'first'})", cfg)
        with pytest.raises(Exception):
            connected_client.gql("INSERT (:Dup {_id: 'dup1', name: 'second'})", cfg)

    def test_edge_int_prop(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'ea'}), (:P {_id: 'eb'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='ea'), (b WHERE id(b)='eb') INSERT (a)-[:R {val: 42}]->(b)", cfg)
        r = connected_client.gql("MATCH ()-[e:R]->() RETURN e.val AS val", cfg)
        assert r.row_count == 1

    def test_edge_string_prop(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'ec'}), (:P {_id: 'ed'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='ec'), (b WHERE id(b)='ed') INSERT (a)-[:R {val: 'hello'}]->(b)", cfg)
        r = connected_client.gql("MATCH (a)-[e:R]->(b) WHERE id(a)='ec' RETURN e.val", cfg)
        assert r.row_count == 1

    def test_edge_no_prop(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'ee'}), (:P {_id: 'ef'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='ee'), (b WHERE id(b)='ef') INSERT (a)-[:EMPTY]->(b)", cfg)
        r = connected_client.gql("MATCH (a)-[e:EMPTY]->(b) WHERE id(a)='ee' RETURN e", cfg)
        assert r.row_count == 1

    def test_edge_self_loop(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'self1'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='self1') INSERT (a)-[:SELF_REF]->(a)", cfg)
        r = connected_client.gql("MATCH (a)-[e:SELF_REF]->(b) WHERE id(a)='self1' RETURN e", cfg)
        assert r.row_count == 1

    def test_batch_50_nodes(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        parts = []
        for i in range(50):
            parts.append(f"(:Batch {{_id: 'b{i}', idx: {i}}})")
        connected_client.gql("INSERT " + ", ".join(parts), cfg)
        r = connected_client.gql("MATCH (n:Batch) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "50"

    def test_batch_100_nodes(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        parts = []
        for i in range(100):
            parts.append(f"(:BigBatch {{_id: 'bb{i}', idx: {i}}})")
        connected_client.gql("INSERT " + ", ".join(parts), cfg)
        r = connected_client.gql("MATCH (n:BigBatch) RETURN count(n) AS cnt", cfg)
        assert str(r.get_by_name(r.rows[0], "cnt")) == "100"

    # ================================================================
    # Ported from the extended deep-coverage suite (gqldb-python-test):
    # boundary float values, extended string / unicode / escape forms,
    # missing-property read, date/datetime/timestamp literals, more list
    # shapes, nested maps, additional OVERWRITE scenarios, and extra
    # edge-property-type / multi-edge coverage.
    # ================================================================

    # Float boundaries
    def test_float_very_small(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "FloatTest", "_id: 'f4', val: 0.000001")

    def test_float_very_large(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "FloatTest", "_id: 'f5', val: 99999999.99")

    # Additional string edge cases
    def test_string_double_quote(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", "_id: 's4', val: 'say \"hello\"'")

    def test_string_backslash(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", r"_id: 's5', val: 'path\\to\\file'")

    def test_string_unicode_japanese(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", "_id: 's8', val: 'こんにちは'")

    def test_string_128_chars(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        s = "a" * 128
        self._insert_and_verify(connected_client, test_graph, "StrTest", f"_id: 's9', val: '{s}'")

    def test_string_1000_chars(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        s = "x" * 1000
        self._insert_and_verify(connected_client, test_graph, "StrTest", f"_id: 's10', val: '{s}'")

    def test_string_newline(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", r"_id: 's11', val: 'line1\nline2'")

    def test_string_tab(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "StrTest", r"_id: 's12', val: 'col1\tcol2'")

    # Missing/optional property
    def test_missing_property(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:NullTest {_id: 'n2', name: 'only_name'})", cfg)
        r = connected_client.gql("MATCH (n:NullTest) WHERE id(n) = 'n2' RETURN n.val AS val", cfg)
        assert r.row_count == 1

    # Date / datetime / timestamp
    def test_datetime(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "DateTest", "_id: 'd1', val: '2024-01-15 10:30:00'")

    def test_date_only(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "DateTest", "_id: 'd2', val: '2024-01-15'")

    def test_timestamp(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "DateTest", "_id: 'd3', val: 1705315800")

    # Extra list shapes
    def test_list_float(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "ListTest", "_id: 'l3', val: [1.1, 2.2, 3.3]")

    def test_list_bool(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "ListTest", "_id: 'l4', val: [true, false, true]")

    def test_list_single(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "ListTest", "_id: 'l6', val: [42]")

    def test_list_large(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        items = ", ".join(str(i) for i in range(100))
        self._insert_and_verify(connected_client, test_graph, "ListTest", f"_id: 'l9', val: [{items}]")

    # Nested map
    def test_map_nested(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        self._insert_and_verify(connected_client, test_graph, "MapTest", "_id: 'map2', val: {outer: {inner: 'deep'}}")

    # Additional OVERWRITE scenarios
    def test_overwrite_float(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:OW {_id: 'ow3', val: 1.5})", cfg)
        connected_client.gql("INSERT OVERWRITE (:OW {_id: 'ow3', val: 9.9})", cfg)
        r = connected_client.gql("MATCH (n:OW) WHERE id(n) = 'ow3' RETURN n.val AS val", cfg)
        assert r.row_count == 1

    def test_overwrite_bool(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:OW {_id: 'ow4', val: true})", cfg)
        connected_client.gql("INSERT OVERWRITE (:OW {_id: 'ow4', val: false})", cfg)
        r = connected_client.gql("MATCH (n:OW) WHERE id(n) = 'ow4' RETURN n.val AS val", cfg)
        assert r.row_count == 1

    def test_overwrite_list(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:OW {_id: 'ow5', val: [1, 2]})", cfg)
        connected_client.gql("INSERT OVERWRITE (:OW {_id: 'ow5', val: [3, 4, 5]})", cfg)
        r = connected_client.gql("MATCH (n:OW) WHERE id(n) = 'ow5' RETURN n.val AS val", cfg)
        assert r.row_count == 1

    def test_overwrite_add_property(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:OW {_id: 'ow6', name: 'test'})", cfg)
        connected_client.gql("INSERT OVERWRITE (:OW {_id: 'ow6', name: 'test', extra: 'added'})", cfg)
        r = connected_client.gql("MATCH (n:OW) WHERE id(n) = 'ow6' RETURN n.extra AS val", cfg)
        assert r.row_count == 1
        assert str(r.get_by_name(r.rows[0], "val")) == "added"

    # Extra edge property types
    def test_edge_float_prop(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'ee'}), (:P {_id: 'ef'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='ee'), (b WHERE id(b)='ef') INSERT (a)-[:R {val: 3.14}]->(b)", cfg)
        r = connected_client.gql("MATCH (a)-[e:R]->(b) WHERE id(a)='ee' RETURN e.val AS val", cfg)
        assert r.row_count == 1

    def test_edge_bool_prop(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'eg'}), (:P {_id: 'eh'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='eg'), (b WHERE id(b)='eh') INSERT (a)-[:R {val: true}]->(b)", cfg)
        r = connected_client.gql("MATCH (a)-[e:R]->(b) WHERE id(a)='eg' RETURN e.val AS val", cfg)
        assert r.row_count == 1

    def test_edge_list_prop(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'ei'}), (:P {_id: 'ej'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='ei'), (b WHERE id(b)='ej') INSERT (a)-[:R {val: [1,2,3]}]->(b)", cfg)
        r = connected_client.gql("MATCH (a)-[e:R]->(b) WHERE id(a)='ei' RETURN e.val AS val", cfg)
        assert r.row_count == 1

    def test_edge_no_props(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'ek'}), (:P {_id: 'el'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='ek'), (b WHERE id(b)='el') INSERT (a)-[:EMPTY]->(b)", cfg)
        r = connected_client.gql("MATCH (a)-[e:EMPTY]->(b) WHERE id(a)='ek' RETURN e", cfg)
        assert r.row_count == 1

    def test_edge_multi_between_same(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'em1'}), (:P {_id: 'em2'})", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='em1'), (b WHERE id(b)='em2') INSERT (a)-[:MULTI {type: 'first'}]->(b)", cfg)
        connected_client.gql("MATCH (a WHERE id(a)='em1'), (b WHERE id(b)='em2') INSERT (a)-[:MULTI {type: 'second'}]->(b)", cfg)
        r = connected_client.gql("MATCH (a)-[e:MULTI]->(b) WHERE id(a)='em1' RETURN e.type ORDER BY e.type", cfg)
        assert r.row_count == 2

    def test_edge_nonexistent_source(self, connected_client, test_graph):
        self._clean_data(connected_client, test_graph)
        cfg = QueryConfig(graph_name=test_graph)
        connected_client.gql("INSERT (:P {_id: 'exist1'})", cfg)
        r = connected_client.gql(
            "MATCH (a WHERE id(a)='nonexistent_xxx'), (b WHERE id(b)='exist1') INSERT (a)-[:BAD]->(b) RETURN a",
            cfg,
        )
        # MATCH with nonexistent id may still succeed but return 0 rows; verify no crash.
        assert r is not None
