"""Convenience types for GQLDB Python driver schema operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Dict, List, Optional


class DBType(IntEnum):
    """Database element type."""
    NODE = 0
    EDGE = 1


class InsertType(IntEnum):
    """Insert mode for GQL-based insert operations.

    - ``NORMAL``    INSERT — error if ``_id`` already exists.
    - ``OVERWRITE`` INSERT OVERWRITE — REPLACE existing entity wholesale
      on duplicate ``_id``. Properties not in the write are LOST.
    - ``UPSERT``    UPSERT — MERGE new properties into existing entity
      on duplicate ``_id``. Properties not in the write are
      PRESERVED; properties in the write OVERWRITE existing values.
      Falls back to plain insert when no ``_id`` matches.

    OVERWRITE and UPSERT are different semantics. Choose UPSERT (merge)
    for partial-update workloads where you don't want to lose existing
    fields; choose OVERWRITE (replace) for known-clean re-ingest of an
    entity's full state.
    """
    NORMAL = 0
    OVERWRITE = 1
    UPSERT = 2


@dataclass
class LabelInfo:
    """Label information from SHOW LABELS.

    GQL supports multi-label nodes (e.g. (n:Person:Employee)), so the
    server returns labels as a list even when there is only one.
    """
    labels: List[str] = field(default_factory=list)
    type: str = ""  # "NODE" or "EDGE"


@dataclass
class ConvPropertyDef:
    """Property definition used by convenience methods.

    Separate from types.schema.PropertyDef which uses PropertyType enum.
    This uses string type names (e.g., "STRING", "INTEGER") matching GQL syntax.
    """
    name: str = ""
    type: str = ""  # "STRING", "INTEGER", "FLOAT", "DATETIME", etc.


@dataclass
class NodeTypeInfo:
    """Node type information from SHOW NODE TYPES."""
    name: str = ""
    properties: List[ConvPropertyDef] = field(default_factory=list)


@dataclass
class EdgeTypeInfo:
    """Edge type information from SHOW EDGE TYPES."""
    name: str = ""
    properties: List[ConvPropertyDef] = field(default_factory=list)


@dataclass
class AiStage:
    """One stage emitted by the server during CALL ai.read(...) / ai.gql(...).

    Each AI call streams multiple stages (start / routing / intent_extraction /
    describe_algorithm / generation / validation / execution / final / error).
    """
    stage: str = ""
    detail: str = ""
    elapsed_ms: int = 0
    tokens_input: int = 0
    tokens_output: int = 0
    tokens_cached: int = 0
    data: Any = None


@dataclass
class AiReadResult:
    """Structured result returned by ai_read() / ai_gql() convenience methods.

    - `stages`: full stage log (advanced inspection)
    - `generated_gql`: GQL synthesized by the LLM
    - `data`: final query result (ai_read only; None for ai_gql)
    - `success` / `error`: convenience flags
    - Token / time metrics are aggregated across stages
    """
    stages: List[AiStage] = field(default_factory=list)
    generated_gql: Optional[str] = None
    data: Any = None
    success: bool = True
    error: Optional[str] = None
    total_elapsed_ms: int = 0
    total_tokens_input: int = 0
    total_tokens_output: int = 0
    total_tokens_cached: int = 0


@dataclass
class LabelDef:
    """Label definition for creating closed graphs."""
    name: str = ""
    properties: List[ConvPropertyDef] = field(default_factory=list)


@dataclass
class IndexProperty:
    """Property reference for index creation."""
    name: str = ""
    prefix_length: int = 0  # 0 = no prefix, >0 = prefix length for STRING


@dataclass
class IndexInfo:
    """Index information from SHOW INDEX."""
    index_name: str = ""
    entity_type: str = ""  # "NODE" or "EDGE"
    label: str = ""
    property: str = ""
    prefix_length: Optional[int] = None
    status: str = ""
    progress: str = ""
    indexed_count: int = 0
    total_count: int = 0
    error: str = ""


@dataclass
class FulltextInfo:
    """Fulltext index information from SHOW FULLTEXT."""
    index_name: str = ""
    entity_type: str = ""  # "NODE" or "EDGE"
    schema_name: str = ""
    properties: str = ""
    analyzer: str = ""
    status: str = ""
    doc_count: int = 0
    progress: str = ""


@dataclass
class AlgoInfo:
    """Algorithm information from SHOW ALGOS."""
    name: str = ""
    description: str = ""
    version: str = ""
    parameters: str = ""


@dataclass
class TaskInfo:
    """Task information from SHOW TASKS."""
    task_id: str = ""
    type: str = ""
    query: str = ""
    algo_name: str = ""
    status: str = ""
    started_at: str = ""
    progress: str = ""
    parameters: str = ""
    nodes_written: int = 0
    compute_time_ms: int = 0
    write_time_ms: int = 0


@dataclass
class ProcessInfo:
    """Process information from TOP."""
    query_id: str = ""
    query_text: str = ""
    start_time: str = ""
    duration_ms: int = 0
    status: str = ""


@dataclass
class GraphStats:
    """Graph statistics from db.stats()."""
    graph_name: str = ""
    node_count: int = 0
    edge_count: int = 0
    label_counts: Dict[str, int] = field(default_factory=dict)
    edge_label_counts: Dict[str, int] = field(default_factory=dict)
    node_property_stats: Dict[str, Dict[str, int]] = field(default_factory=dict)
    edge_property_stats: Dict[str, Dict[str, int]] = field(default_factory=dict)


@dataclass
class InsertResponse:
    """Response for GQL-based insert operations."""
    inserted_nodes: int = 0
    inserted_edges: int = 0
    node_ids: List[str] = field(default_factory=list)


## ConvNode and ConvEdge have been removed.
## Use NodeData and EdgeData from graph_models instead.
