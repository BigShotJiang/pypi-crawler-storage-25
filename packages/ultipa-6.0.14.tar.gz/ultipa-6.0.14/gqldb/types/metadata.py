"""Metadata types for GQLDB Python driver."""

from dataclasses import dataclass, field
from typing import Dict, Optional

from .enums import GraphType

@dataclass
class GraphInfo:
    """Information about a graph."""
    name: str
    graph_type: GraphType
    node_count: int
    edge_count: int
    description: str


@dataclass
class TransactionInfo:
    """Information about a transaction."""
    transaction_id: int
    session_id: int
    graph_name: str
    read_only: bool
    created_at: int
    duration_ms: int
    internal_tx_id: str


@dataclass
class ASTCacheStats:
    """AST cache statistics."""
    hits: int
    misses: int
    evictions: int
    entries: int
    hit_rate: float


@dataclass
class PlanCacheStats:
    """Plan cache statistics."""
    size: int
    capacity: int
    hits: int
    misses: int
    hit_rate: float


@dataclass
class CacheStats:
    """Combined cache statistics."""
    ast_stats: Optional[ASTCacheStats] = None
    plan_stats: Optional[PlanCacheStats] = None


@dataclass
class Statistics:
    """Database statistics."""
    node_count: int
    edge_count: int
    label_counts: Dict[str, int] = field(default_factory=dict)
    edge_label_counts: Dict[str, int] = field(default_factory=dict)


@dataclass
class CpuMetrics:
    """CPU usage metrics."""
    process_percent: float
    system_percent: float
    num_cores: int

@dataclass
class MemoryMetrics:
    """Memory usage metrics."""
    process_rss: int
    heap_alloc: int
    heap_sys: int
    stack_in_use: int
    system_total: int
    system_available: int
    system_used: int
    system_used_percent: float

@dataclass
class DiskIOMetrics:
    """Disk I/O metrics."""
    read_bytes: int
    write_bytes: int
    read_count: int
    write_count: int

@dataclass
class StorageMetrics:
    """Storage metrics."""
    db_path: str
    db_size_bytes: int
    volume_total: int
    volume_free: int
    volume_used: int

@dataclass
class NetworkMetrics:
    """Network metrics."""
    bytes_sent: int
    bytes_recv: int
    packets_sent: int
    packets_recv: int

@dataclass
class SystemMetrics:
    """System-level metrics."""
    cpu: Optional[CpuMetrics] = None
    memory: Optional[MemoryMetrics] = None
    disk_io: Optional[DiskIOMetrics] = None
    storage: Optional[StorageMetrics] = None
    network: Optional[NetworkMetrics] = None
