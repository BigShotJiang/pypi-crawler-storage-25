"""Numeric type wrappers for explicit type specification."""

from dataclasses import dataclass

@dataclass
class Int32:
    """Wrapper for explicit 32-bit signed integer."""
    value: int


@dataclass
class UInt32:
    """Wrapper for explicit 32-bit unsigned integer."""
    value: int


@dataclass
class Float32:
    """Wrapper for explicit 32-bit float."""
    value: float


@dataclass
class UInt64:
    """Wrapper for explicit 64-bit unsigned integer."""
    value: int
