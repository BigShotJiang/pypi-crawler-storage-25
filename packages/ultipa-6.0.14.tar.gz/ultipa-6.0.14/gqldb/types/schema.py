"""Schema types for GQLDB Python driver."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List

from .enums import PropertyType

@dataclass
class PropertyDef:
    """Property definition in a schema."""
    name: str
    type: PropertyType


@dataclass
class Schema:
    """Node/edge schema metadata."""
    name: str
    properties: List[PropertyDef] = field(default_factory=list)


@dataclass
class Header:
    """Column header in a table."""
    name: str
    type: PropertyType = PropertyType.UNSET


@dataclass
class Table:
    """Generic result table."""
    name: str = ""
    headers: List[Header] = field(default_factory=list)
    rows: List[List[Any]] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            'name': self.name,
            'headers': [
                {'property_name': h.name, 'property_type': h.type.name.lower()}
                for h in self.headers
            ],
            'rows': self.rows,
        }


@dataclass
class Attr:
    """Scalar or list attribute result."""
    name: str
    type: PropertyType = PropertyType.UNSET
    values: List[Any] = field(default_factory=list)