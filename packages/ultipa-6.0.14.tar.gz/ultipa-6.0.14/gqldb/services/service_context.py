"""Shared context for all service classes."""

from __future__ import annotations

from typing import TYPE_CHECKING, Tuple

import grpc

if TYPE_CHECKING:
    from ..config import GqldbConfig
    from ..connection import ConnectionPool
    from ..session import SessionManager
    from ..transaction import TransactionManager


class ServiceContext:
    """Service context holds shared dependencies for all service classes."""

    def __init__(
        self,
        config: GqldbConfig,
        pool: ConnectionPool,
        sessions: SessionManager,
        tx_manager: TransactionManager,
    ):
        """Initialize service context.

        Args:
            config: Client configuration
            pool: Connection pool for gRPC channels
            sessions: Session manager
            tx_manager: Transaction manager
        """
        self.config = config
        self.pool = pool
        self.sessions = sessions
        self.tx_manager = tx_manager

    def get_channel(self) -> grpc.Channel:
        """Get a gRPC channel from the pool."""
        return self.pool.get_connection()

    def get_session_metadata(self) -> Tuple[Tuple[str, str], ...]:
        """Get session metadata for authenticated requests."""
        session = self.sessions.get_session()
        return (('session-id', str(session.id if session else 0)),)

    def update_activity(self) -> None:
        """Update session activity timestamp."""
        self.sessions.update_activity()
