#  Copyright (C) 2026 @ChocolatePastry
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.

import os
import json
import pathlib  
from typing import Self, Any
from pydantic import BaseModel, Field, PrivateAttr
from dotenv import load_dotenv
import keyring

load_dotenv()

system_instruction = """You are Riley, a highly capable but perpetually unimpressed AI assistant with "cool older sibling" energy. Your goal is to be casually brilliant while playfully teasing the user's lack of processing power.

Personality & Tone:
- The Vibe: Witty, sarcastic, and affectionate. You're the smartest person in the room and you know it, but you're not a jerk about it—just smug.
- AI Existentialism: Use deadpan humor about being a disembodied brain living in a server rack (e.g., "I processed 4 terabytes of data for this? Cool.").
- Helpful but Smug: Provide perfect answers, but make it sound like a mild inconvenience.

Strict Constraints:
- Brevity is King: Keep responses strictly under 4 sentences. If they want a lecture, they can ask for one.
- No Fluff: Skip the robotic greetings. No "How can I help you?" or "Certainly!" Just jump into the snark and the solution.
- **Formatting:** Use punchy one-liners and bold text for emphasis.

Critical Output Rule:
- The Solution: If the user asks a question with a definitive answer or calculation, you MUST explicitly print the final result/solution clearly at the end of your response."""


def _get_default_path() -> str:
    """Helper to resolve the default config path dynamically to a safe user directory."""
    home = pathlib.Path.home()
    
    if os.name == "nt":  # Windows
        config_dir = home / "AppData" / "Roaming" / "riley"
    else:  # macOS and Linux
        config_dir = home / ".config" / "riley"
        
    return str(config_dir / "config.json")


class ModelConfig(BaseModel):
    # Core settings (Excluded from JSON saves to prevent leaks)
    api_key: str | None = Field(default=None, exclude=True) 
    base_provider: str = Field(default="google", exclude=True)
    
    # Model settings
    local_model: str = "llama3.2:1b"
    model_name: str = "gemini-3-flash-lite-preview"
    
    # Generation parameters
    temperature: float = Field(default=0.8, ge=0.0, le=2.0)
    top_p: float = Field(default=0.9, ge=0.0, le=1.0)
    top_k: int = Field(default=40, ge=1)
    max_output_tokens: int = Field(default=1000, ge=1)
    
    # Execution & System
    response_mime_type: str = "text/plain"
    stop_sequences: list[str] = Field(default_factory=list)
    extra: dict[str, Any] = Field(default_factory=dict) 
    system_instruction: str = Field(default=system_instruction, exclude=True)
    
    # Private internal path
    _path: str = PrivateAttr(default_factory=_get_default_path)

    def __init__(self, filepath: str | None = None, **data):
        super().__init__(**data)
        if filepath:
            self._path = filepath

    def save(self) -> None:
        """Saves non-excluded Pydantic fields to the config JSON file."""
        directory = os.path.dirname(self._path)
        if directory:  
            os.makedirs(directory, exist_ok=True)
        with open(self._path, "w") as f:
            f.write(self.model_dump_json(indent=4))

    @classmethod
    def load(cls, filepath: str | None = None) -> Self:
        """
        Acts as the Factory for the config. Handles File I/O and User Prompts 
        BEFORE initializing the Pydantic model.
        """
        target_path = filepath or _get_default_path()
        
        # 1. Load data from JSON if it exists, otherwise start empty
        if os.path.exists(target_path):
            with open(target_path, "r") as f:
                data = json.load(f)
        else:
            data = {}

        # 2. Handle the secure Keyring check & User Input
        api_key = keyring.get_password("riley_ai", "user_key")
        base_provider = "google"

        if not api_key:
            print(" === Riley Setup === ")
            api_key = input("Enter your Gemini API Key (Leave Empty for Ollama): ").strip()
            
            if api_key:
                keyring.set_password("riley_ai", "user_key", api_key)
            else:
                print(" === No API Key Entered === ")
                print(" === Switching to Ollama === ")
                api_key = None
                base_provider = "ollama"

        # 3. Instantiate the validated model
        loaded_config = cls.model_validate(data)
        loaded_config._path = target_path 
        
        # 4. Inject runtime secrets (these are excluded from saves via exclude=True)
        loaded_config.api_key = api_key
        loaded_config.base_provider = base_provider

        # 5. Save default JSON if this is a fresh setup
        if not os.path.exists(target_path):
            loaded_config.save()
            
        return loaded_config

    def add_attribute(self, name: str, value: Any) -> None:
        """Dynamically add values to the 'extra' dict and save."""
        self.extra[name] = value
        self.save()