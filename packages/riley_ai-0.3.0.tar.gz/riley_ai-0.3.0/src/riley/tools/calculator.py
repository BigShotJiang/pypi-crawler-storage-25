#  Copyright (C) 2026 @ChocolatePastry
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.

import os
import json
import re
import pathlib
from dataclasses import dataclass, field, asdict
from typing import Any, Final

from sympy import solve, Eq
from sympy.parsing.sympy_parser import (
    parse_expr, 
    standard_transformations, 
    implicit_multiplication_application
)



DESCRIPTION: Final[str] = (
    "Compute arithmetic, algebraic equations, and word problems. "
    "Map entities to variables in the scratchpad, then provide raw expressions."
)

CALCULATOR_SCHEMA: Final[dict[str, Any]] = {
    "type": "object",
    "properties": {
        "reasoning_scratchpad": {
            "type": "string",
            "description": "Identify entities and assign lowercase variables (e.g., m=mohan)."
        },
        "expressions": {
            "type": "string",
            "description": "Comma-separated equations or expressions. Use explicit '*' for multiplication."
        }
    },
    "required": ["reasoning_scratchpad", "expressions"],
}



@dataclass
class Calculator: 
    name: str = "smart_calculator"
    description: str = DESCRIPTION
    parameters_json_schema: dict[str, Any] = field(
        default_factory=lambda: dict(CALCULATOR_SCHEMA)
    )
    # Updated path to use the user's config directory
    path: pathlib.Path = field(
        default_factory=lambda: (
            pathlib.Path.home() / ("AppData/Roaming/riley" if os.name == "nt" else ".config/riley") 
            / "tools" / "calculator.json"
        )
    )

    def save_tools(self) -> None:
        """Persists the tool configuration to a JSON file."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = asdict(self)
        data['path'] = str(self.path) 
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

    @classmethod
    def load_tools(cls) -> "Calculator":
        """Factory method to load tool from disk or return default."""
        # Updated default_path to match the class field
        default_path = (
            pathlib.Path.home() / ("AppData/Roaming/riley" if os.name == "nt" else ".config/riley") 
            / "tools" / "calculator.json"
        )
        
        if not default_path.exists():
            instance = cls(path=default_path)
            instance.save_tools()
            return instance

        with default_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
            data['path'] = pathlib.Path(data['path'])
            return cls(**data)


def get_router_regex() -> re.Pattern:
    """Returns a compiled regex for parsing router commands."""
    return re.compile(r"^\/(calculate|web_search)(?:\s+(.*))?$", re.DOTALL)

def smart_calculator(expressions: str) -> str:
    """Deterministic math execution engine with implicit multiplication support."""
   
    expressions = expressions.strip().lower()

   
    if not re.match(r"^[a-z0-9\s\+\-\*\/\(\)\.\,\=\^]+$", expressions):
        return "Security Alert: Look, I'm not running that. Use math, not code."


    expressions = expressions.replace("^", "**")
    
    # Implicit multiplication (e.g., 2x -> 2*x) handled by Sympy transformations
    transformations = standard_transformations + (implicit_multiplication_application,)
    
    try:
        # SCENARIO A: Solving Equation Systems
        if "=" in expressions:
            raw_equations = expressions.split(",")
            parsed_equations = []
            
            for eq_string in raw_equations:
                if "=" not in eq_string:
                    return "Error: If you're solving a system, every statement needs an '=' sign."
                     
                parts = eq_string.split("=", 1)
                left_expr = parse_expr(parts[0].strip(), transformations=transformations, evaluate=False)
                right_expr = parse_expr(parts[1].strip(), transformations=transformations, evaluate=False)
                parsed_equations.append(Eq(left_expr, right_expr))
            
            answers = solve(parsed_equations)
            return f"The solutions are: {answers}"
            
        # SCENARIO B: Evaluating Expressions
        else:
            if "," in expressions:
                results = [
                    str(parse_expr(ex.strip(), transformations=transformations, evaluate=False).doit())
                    for ex in expressions.split(",") if ex.strip()
                ]
                return f"Results: {', '.join(results)}"
            
            expression = parse_expr(expressions, transformations=transformations, evaluate=False)
            return f"Result: {expression.doit()}"
                
    except Exception as e:
        return f"Error: My math brain stalled. Details: {str(e)}"



if __name__ == "__main__":
    calc_tool = Calculator.load_tools()
    print(f"Riley's Calculator initialized at: {calc_tool.path}\n")
    

    print("Test 1 (2(x+1)=10):", smart_calculator("2(x+1)=10"))
    

    print("Test 2 (m=2s, m+s=24):", smart_calculator("m=2*s, m+s=24"))
    

    print("Test 3 (10/2, 5*5):", smart_calculator("10/2, 5*5"))