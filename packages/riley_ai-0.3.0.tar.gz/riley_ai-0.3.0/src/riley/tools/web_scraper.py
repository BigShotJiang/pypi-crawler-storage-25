#  Copyright (C) 2026 @ChocolatePastry
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.

import json
import os
import logging
import concurrent.futures
import pathlib
from dataclasses import dataclass, field, asdict
from typing import Any, Self

import requests
from sentence_transformers import SentenceTransformer, util
from ddgs import DDGS  
from trafilatura import fetch_url, extract


os.environ['HF_HUB_OFFLINE'] = "1"

logging.basicConfig(level=logging.WARNING, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)



@dataclass
class WebSearch: 
    name: str = "rank_chunks" 
    description: str = (
        "CRITICAL: Use this tool for any factual query requiring information beyond your 2023 training cutoff, "
        "including current events, real-time weather, latest technical documentation, or biographical verification. "
        "The tool performs an automated RAG pipeline (Search -> Scrape -> Rank). "
        "Input must be a singular, keyword-optimized search string. Do not use natural language questions."
    )
    

    parameters_json_schema: dict[str, Any] = field(default_factory=lambda: {
        'type': 'object',
        'properties': {
            'query': {
                'type': 'string',
                'description': (
                    "A high-density keyword query. Example: 'Python 3.14 PEP 735 features' "
                    "instead of 'What are the new features in Python 3.14?'"
                )
            },
            'reasoning_scratchpad': {
                'type': 'string',
                'description': "Briefly explain why this search is necessary before defining the query."
            }
        },
        'required': ['query', 'reasoning_scratchpad'],
    })
    
    # Updated path to use the user's config directory
    path: pathlib.Path = field(
        default_factory=lambda: (
            pathlib.Path.home() / ("AppData/Roaming/riley" if os.name == "nt" else ".config/riley") 
            / "tools" / "web_search.json"
        )
    )

    def save_tools(self) -> None:
        """Persists the tool configuration to a JSON file."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = asdict(self)
        data['path'] = str(self.path) 
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

    @classmethod
    def load_tools(cls) -> Self:
        """Factory method to load tool from disk or return default."""
        default_path = (
            pathlib.Path.home() / ("AppData/Roaming/riley" if os.name == "nt" else ".config/riley") 
            / "tools" / "web_search.json"
        )
        
        if not default_path.exists():
            instance = cls(path=default_path)
            instance.save_tools()
            return instance

        with default_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
            data['path'] = pathlib.Path(data['path'])
            return cls(**data)



class WebRAGPipeline:
    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5"):
        self.model_name = model_name
        logger.info(f"Loading SentenceTransformer model: {self.model_name}...")
        self.model = SentenceTransformer(self.model_name)
        logger.info("Model loaded successfully.")

    def search_links(self, query: str, max_results: int = 3) -> list[str]:
        try:
            logger.info("Attempting local search API (SearXNG)...")
            r = requests.get(f"http://127.0.0.1:8888/search?q={query}&format=json", timeout=5)
            r.raise_for_status()
            return [res.get('url') for res in r.json().get('results', []) if res.get('url')][:max_results]
        except Exception:
            logger.warning("Local API failed. Falling back to DuckDuckGo Search.")
            try:
                results = DDGS().text(query=query, max_results=max_results)
                return [res.get('href') for res in results if res.get('href')]
            except Exception as ddg_e:
                logger.error(f"DuckDuckGo search also failed: {ddg_e}")
                return []

    def scrape_web(self, links: list[str]) -> list[str]:
        data = []
        
        def fetch_and_extract(link: str) -> str | None:
            logger.info(f"Scraping: {link}")
            downloaded = fetch_url(link)
            if downloaded:
                return extract(downloaded)
            return None

        # Multithreaded scraping for huge performance gains
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            results = executor.map(fetch_and_extract, links)
            for res in results:
                if res:
                    data.append(res)
        return data

    def chunk_text(self, text: str, chunk_size: int = 1000, overlap: int = 200) -> list[str]:
        chunks = []
        start = 0
        text_length = len(text)
        
        while start < text_length:
            end = min(start + chunk_size, text_length)
            if end < text_length:
                last_period = text.rfind(".", start, end)
                last_space = text.rfind(" ", start, end)
                break_point = last_period if last_period != -1 else last_space
                
                if break_point != -1 and break_point > start:
                    end = break_point + 1
                    
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            
            step_size = end - start
            if step_size <= overlap:
                start = end  
            else:
                start = end - overlap
                
        return chunks

    def execute_rag(self, query: str, top_k: int = 5) -> list[tuple[str, float]]:
        links = self.search_links(query)
        if not links:
            return []

        scraped_texts = self.scrape_web(links)
        if not scraped_texts:
            return []

        all_chunks = []
        for text in scraped_texts:
            all_chunks.extend(self.chunk_text(text))

        if not all_chunks:
            return []

        # BGE models require an instruction prefix for queries
        if "bge" in self.model_name.lower():
            query_for_embedding = f"Represent this sentence for searching relevant passages: {query}"
        else:
            query_for_embedding = query

        query_embedding = self.model.encode(query_for_embedding, convert_to_tensor=True)

        # Process chunks in batches to prevent Out-Of-Memory errors
        chunk_embeddings = self.model.encode(all_chunks, batch_size=32, convert_to_tensor=True)

        cos_scores = util.cos_sim(query_embedding, chunk_embeddings)[0] #  np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
        
        ranked = sorted(
            zip(all_chunks, cos_scores.tolist()), 
            key=lambda x: x[1], 
            reverse=True
        )
        
        return ranked[:top_k]



# Global singleton to prevent reloading the ML model on every single search
_PIPELINE_INSTANCE = None

def rank_chunks(query: str, top_k: int = 5) -> list[str]:
    """
    Exposed function for the LLM Tool map. 
    Returns a clean list of string chunks for the LLM to read.
    """
    global _PIPELINE_INSTANCE
    if _PIPELINE_INSTANCE is None:
        _PIPELINE_INSTANCE = WebRAGPipeline()
        

    raw_results = _PIPELINE_INSTANCE.execute_rag(query, top_k)
    
    # Strip the scores and just return the text for the LLM context window
    return [chunk for chunk, score in raw_results]

if __name__ == "__main__":
    tool = WebSearch.load_tools()
    print(f"Tool Schema loaded at: {tool.path}")
    
    print("\nTesting rank_chunks function...")
    results = rank_chunks("Python 3.14 release date", top_k=2)
    for i, res in enumerate(results):
        print(f"\nResult {i+1}:\n{res[:200]}...")