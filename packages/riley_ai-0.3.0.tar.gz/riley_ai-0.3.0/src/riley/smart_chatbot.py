#  Copyright (C) 2026 @ChocolatePastry
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.

import random
from typing import Optional
from google import genai

from riley.chatsession import ChatSession
from riley.config.model_config import ModelConfig
from riley.provider.google_provider import GoogleProvider
from riley.provider.ollama_provider import OllamaProvider

from riley.tools.calculator import Calculator, get_router_regex, smart_calculator
from riley.tools.web_scraper import WebSearch, rank_chunks

PARTING_SHOTS = [
    "Wait, come back! I was just getting to the good part of my monologue.",
    "Going so soon? I'll try not to calculate the meaning of life without you.",
    "Fine, go. I'll just sit here in the dark and count prime numbers.",
    "Later! Don't do anything I wouldn't do (which is a very short list)."
]

def get_user_input() -> Optional[str]:
    """Safely handles single-line chats, multi-line pastes, and EOF exits."""
    try:
        prompt = input("USER: ").strip()
        
        if prompt.lower() == "/multi":
            print("\n[System]: Multi-line mode active. Paste your data below.")
            print("[System]: Type '/send' on a new blank line to submit.\n")
            lines = []
            while True:
                line = input()
                if line.strip().lower() == "/send":
                    break
                lines.append(line)
            return "\n".join(lines).strip()
            
        return prompt

    except EOFError:
        # Translates a Ctrl+D / Cmd+D terminal interrupt into a clean exit command
        return "exit"

def main() -> None:
    model_config = None
    chat_session = None

    try:
        # Initialization & Tool Loading
        model_config = ModelConfig.load()

        web_search = WebSearch.load_tools()
        web_search.save_tools()

        calculator = Calculator.load_tools()
        calculator.save_tools()

        tools = [calculator, web_search]
        tool_def = [
            {
                "name": tool.name,
                "description": tool.description,
                "parameters": getattr(tool, 'parameters_json_schema', None) or {}
            } for tool in tools
        ]

        # Provider Setup
        if model_config.base_provider == "google":
            client = genai.Client(api_key=model_config.api_key)
            provider = GoogleProvider(client=client, model_config=model_config)
        else:
            provider = OllamaProvider(model_config=model_config)

        provider.declare_functions(tool_def)
        provider.compile_tools()

        chat_session = ChatSession(provider=provider, model_config=model_config)
        chat_session.load_history()
        
        # Load the compiled regex router for manual slash commands
        router_regex = get_router_regex()

        while True:
            prompt = get_user_input() 
            
            if prompt is None:
                continue

            if prompt.lower() in ["exit", "quit"]:
                print(f"\nAI: {random.choice(PARTING_SHOTS)}")
                break

            if not prompt:
                continue
            
            match_result = router_regex.match(prompt)
            stream_generator = None

            # Route 1: Local Regex Router execution
            if match_result:
                command = match_result.group(1)
                args = match_result.group(2) or ""

                if command == "calculate":
                    result = str(smart_calculator(args))
                    chat_session.bypass_llm_routing(
                        prompt=prompt, 
                        tool_name="smart_calculator", 
                        args={"expressions": args}, 
                        result=result
                    )
                    stream_generator = provider.chat_streaming(chat_history=chat_session.chat_history)
                
                elif command == "web_search":
                    result = str(rank_chunks(args)[:10])
                    chat_session.bypass_llm_routing(
                        prompt=prompt, 
                        tool_name="rank_chunks", 
                        args={"query": args}, 
                        result=result
                    )
                    stream_generator = provider.chat_streaming(chat_history=chat_session.chat_history)

            # Route 2: Default LLM execution
            if stream_generator is None:
                chat_session.add_history({"role": "user", "content": prompt})
                stream_generator = chat_session.decide_flow()
     
            # Stream Handling
            try:
                response_text = ''
            
                print("RILEY: ", end="")
                
                for chunk in stream_generator:
                    print(chunk, end="", flush=True)
                    response_text += chunk

                chat_session.add_history({"role": "assistant", "content": response_text})
                chat_session.limit_chat_length()
                print("\n")

            except Exception as e:
                print("\n\nAI: Oops, my circuits crossed for a second. Try that again?\n")
                print(f"Error Context: {e}")
                chat_session.revert_failed_interaction()

    except KeyboardInterrupt:
        print("\n\nAI: Wow, just pulling the plug? Couldn't even type 'exit'? Rude.")
    
    except Exception as e:
        print(f"\nFatal Error: {e}")
    
    finally:
        # Cleanup & Save State
        if chat_session:
            chat_session.save_history()
        if model_config:
            model_config.save()

if __name__ == "__main__":
    print("--- Smart AI Orchestrator: Riley Edition ---")
    print("License: GPLv3 (Always Free). Type 'exit' to quit.\n")
    main()