#  Copyright (C) 2026 @ChocolatePastry
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.

import os
import json
import uuid
import pathlib
from dataclasses import dataclass, field
from typing import Any 

from riley.config.model_config import ModelConfig
from riley.provider.base_provider import BaseProvider
from riley.tools.calculator import smart_calculator
from riley.tools.web_scraper import rank_chunks

TOOL_MAP = {
    "smart_calculator": smart_calculator, 
    "rank_chunks": rank_chunks
}

@dataclass
class ChatSession:
    provider: BaseProvider 
    model_config: ModelConfig
    chat_history: list[dict[str, Any]] = field(default_factory=list)
    
    # Updated path to point to the user's config directory
    path: pathlib.Path = field(
        default_factory=lambda: (
            pathlib.Path.home() / ("AppData/Roaming/riley" if os.name == "nt" else ".config/riley") 
            / "history" / "history.json"
        )
    )

    def load_history(self):
        """Loads chat history from the local JSON file."""
        if self.path.exists():
            try:
                with self.path.open("r", encoding="utf-8") as f:
                    self.chat_history = json.load(f)
            except json.JSONDecodeError:
                self.chat_history = []

    def revert_failed_interaction(self):
        """Removes the last prompt and any partial tool/assistant chains to keep history clean after a crash."""
        while (self.chat_history and (self.chat_history[-1]["role"] != "assistant" or self.chat_history[-1].get("content") is None)):
            self.chat_history.pop()
            
        self.save_history()

    def decide_flow(self):
        """The main orchestration loop for tool chaining."""
        tool_calls = self.provider.use_tools(self.chat_history)
        
        iteration = 0
        max_iterations = 5 
        
        while tool_calls and iteration < max_iterations:
            iteration += 1
            assistant_msg = {
                "role": "assistant",
                "content": None,
                "tool_calls": []
            }
            tool_responses = []

            for tc in tool_calls:
                name = tc.get("name")
                args_dict = tc.get("arguments", {})
                thought_signature = tc.get("thoughtSignature")
                
                # IMPORTANT: Use the ID from the provider if it exists to maintain the chain of custody
                call_id = tc.get("id") or uuid.uuid4().hex

                # Create a clean execution copy 
                exec_args = args_dict.copy()
                
                # Safely pop scratchpad without mutating the original dictionary
                scratchpad = exec_args.pop("reasoning_scratchpad", None)
                if scratchpad:
                    print(f"\n🧠 [Agent Scratchpad]: {scratchpad}\n")

                

                try:
                    result = TOOL_MAP[name](**exec_args) if name in TOOL_MAP else f"Error: Tool '{name}' not found."
                except Exception as e:
                    result = f"Tool Execution Error: {str(e)}"
                
                # 1. Build the base dictionary
                tool_call_dict = {
                    "id": call_id,
                    "type": "function",
                    "function": {"name": name, "arguments": args_dict}
                }
                
                # 2. Conditionally add the thought signature
                if thought_signature:
                    tool_call_dict["thoughtSignature"] = thought_signature
                    
                # 3. Append to the assistant message
                assistant_msg["tool_calls"].append(tool_call_dict)
                
                tool_responses.append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "name": name,
                    "content": str(result)
                })

            self.add_history(assistant_msg)
            for response in tool_responses:
                self.add_history(response)

            self.save_history()
            
            # Re-evaluate with new context
            tool_calls = self.provider.use_tools(self.chat_history)

        
        if tool_calls:
            yield f"\n[System Error]: I've hit my limit of {max_iterations} execution loops. Aborting to save quota."
        else:
            yield from self.provider.chat_streaming(self.chat_history)

    def add_history(self, msg: dict[str, Any]):
        self.chat_history.append(msg)

    def save_history(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("w", encoding="utf-8") as f:
            json.dump(self.chat_history, f, indent=4)

    def limit_chat_length(self, max_length: int = 20):
        if len(self.chat_history) <= max_length:
            return
        self.chat_history = self.chat_history[-max_length:]
        while self.chat_history and self.chat_history[0]["role"] != "user":
            self.chat_history.pop(0)

    def bypass_llm_routing(self, prompt: str, tool_name: str, args: dict[str, Any], result: str):
        """
        Directly injects a tool interaction into history as a text prompt.
        This avoids faking API 'tool_calls' which would trigger signature forgery errors.
        """
        # Bundle the user's prompt and the bypass result into a single user message
        combined_prompt = (
            f"{prompt}\n\n"
            f"[System Bypass Executed: {tool_name}]\n"
            f"Args: {args}\n"
            f"Result: {result}"
        )

        self.add_history({"role": "user", "content": combined_prompt})
        self.save_history()