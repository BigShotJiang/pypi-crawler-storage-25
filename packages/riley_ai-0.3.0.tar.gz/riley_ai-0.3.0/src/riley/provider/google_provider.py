#  Copyright (C) 2026 @ChocolatePastry
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.

from google import genai
from google.genai import types
from dataclasses import dataclass, field
from typing import Iterator, Any
from riley.provider.base_provider import BaseProvider

@dataclass
class GoogleProvider(BaseProvider):
    client: genai.Client | None = None 
    func_declarations: list[dict[str, Any]] = field(default_factory=list)
    tools: types.Tool | None = None 

    def __post_init__(self):
        self.setup_configs()

    def setup_configs(self):
        """Builds the static configuration dictionaries for the session."""
        self.base_config_kwargs = {
            "system_instruction": self.model_config.system_instruction,
            "temperature": self.model_config.temperature,
            "top_p": self.model_config.top_p,
            "top_k": self.model_config.top_k,
            "max_output_tokens": self.model_config.max_output_tokens,
            "response_mime_type": self.model_config.response_mime_type,
            "stop_sequences": self.model_config.stop_sequences,
        }

        self.tool_config_kwargs = self.base_config_kwargs.copy()
        self.tool_config_kwargs.update({
            "system_instruction": self.TOOL_INSTRUCTION,
            "temperature": 0.0,
            "top_p": 0.5,
            "top_k": 3,
            "automatic_function_calling": types.AutomaticFunctionCallingConfig(disable=True)
        })

    def translate_history(self, chat_history: list[dict[str, Any]]) -> list[dict[str, Any]]: 
        """Adapts common chat format to Gemini-specific parts architecture."""
        
        messages = []
        for msg in chat_history:
            role = "model" if msg['role'] == 'assistant' else msg['role']

            if msg.get("content") and msg.get("role") != "tool":
                messages.append({"role": role, "parts": [{"text": msg["content"]}]})

            elif msg.get("tool_calls"):
                parts = []
                for tc in msg["tool_calls"]:
                    part_dict = {
                        "function_call": {
                            "args": tc["function"]["arguments"], 
                            "name": tc["function"]["name"]
                        }
                    }
                    
                    # Re-attach the thought signature to the part if it exists!
                    if "thoughtSignature" in tc:
                        # Convert the hex string from our JSON back into raw bytes for the SDK
                        try:
                            part_dict["thought_signature"] = bytes.fromhex(tc["thoughtSignature"])
                        except ValueError:
                            # Fallback just in case it wasn't hex-encoded for some reason
                            part_dict["thought_signature"] = tc["thoughtSignature"].encode('utf-8')
                        
                    parts.append(part_dict)
                
                messages.append({"role": "model", "parts": parts})

            elif msg.get("role") == "tool":
                content = msg.get("content")
                response_data = content if isinstance(content, dict) else {"result": content}
                
                messages.append({
                    "role": "tool", 
                    "parts": [{
                        "function_response": {
                            "name": msg.get("name"), 
                            "response": response_data,
                            "id": msg.get("tool_call_id")
                        }
                    }]
                })                
                
        return messages
           
    def chat_streaming(self, chat_history: list[dict[str, Any]]) -> Iterator[str]: 
        gemini_history = self.translate_history(chat_history)

        response = self.client.models.generate_content_stream(
            model=self.model_config.model_name,
            contents=gemini_history,
            config=types.GenerateContentConfig(**self.base_config_kwargs)
        )

        for chunk in response:
            text = getattr(chunk, "text", None)
            if text:
                yield text
        
    def use_tools(self, chat_history: list[dict[str, Any]]) -> list[dict[str, Any]]: 
        gemini_history = self.translate_history(chat_history)
    
        response = self.client.models.generate_content(
            model=self.model_config.model_name,
            contents=gemini_history,
            config=types.GenerateContentConfig(**self.tool_config_kwargs)
        )
        
        if not response.candidates:
            return []
            
        content = response.candidates[0].content
        if not content or not content.parts:
            return []
        
        extracted_tools = []
        for part in content.parts:
            if part.function_call:
                thought_sig = getattr(part, "thought_signature", None) or getattr(part, "thoughtSignature", None)
                
                # CRITICAL: If it's a bytes object, convert it to a hex string so JSON can read it
                if isinstance(thought_sig, bytes):
                    thought_sig = thought_sig.hex()

                extracted_tools.append({
                    "id": part.function_call.id, 
                    "name": part.function_call.name,
                    "arguments": dict(part.function_call.args),
                    "thoughtSignature": thought_sig
                })
                        
        return extracted_tools

    def declare_functions(self, tool_definitions: list[dict[str, Any]]) -> None:
        """Accumulates tool definitions into Gemini-compatible schema objects."""
        for tool in tool_definitions:
            self.func_declarations.append(types.FunctionDeclarationDict(tool))
    
    def compile_tools(self) -> None:
        """Binds all declared functions into a single Tool object for the session."""
        if self.func_declarations:
            self.tools = types.Tool(function_declarations=self.func_declarations)
            self.tool_config_kwargs["tools"] = [self.tools]