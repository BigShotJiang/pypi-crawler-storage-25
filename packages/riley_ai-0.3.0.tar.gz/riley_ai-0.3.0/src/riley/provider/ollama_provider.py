#  Copyright (C) 2026 @ChocolatePastry
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.

from ollama import chat
from dataclasses import dataclass, field
from typing import Iterator
from riley.provider.base_provider import BaseProvider

@dataclass
class OllamaProvider(BaseProvider):
    func_declarations: list[dict[str, any]] = field(default_factory=list)
    tools: list[dict[str, any]] | None = None

    def __post_init__(self):
        self.setup_configs()

    def setup_configs(self):
        """Builds the static configuration dictionaries for the session."""
        self.base_config_kwargs = {
            "temperature": self.model_config.temperature,
            "top_p": self.model_config.top_p,
            "top_k": self.model_config.top_k,
            "stop": self.model_config.stop_sequences,
        }

        self.tool_config_kwargs = {
            "temperature": 0.0,
            "top_p": 0.5,
            "top_k": 2,
        }

    def chat_streaming(self, chat_history: list[dict[str, any]]) -> Iterator[str]:
        messages = [{"role": "system", "content": self.model_config.system_instruction}]
        messages.extend(chat_history)
        
        response = chat(
            model=self.model_config.local_model,
            messages=messages,
            stream=True,
            options={**self.base_config_kwargs}
        )

        for chunk in response:
            yield chunk.message.content

    def use_tools(self, chat_history: list[dict[str, any]]) -> list[dict[str, any]]:
        messages = [{"role": "system", "content": self.TOOL_INSTRUCTION}]
        messages.extend(chat_history)

        response = chat(
            model=self.model_config.local_model,
            messages=messages,
            tools=self.tools,
            options={**self.tool_config_kwargs}
        )

        extracted_tools = []
        if hasattr(response, 'message') and hasattr(response.message, 'tool_calls') and response.message.tool_calls:
            for tc in response.message.tool_calls:
                extracted_tools.append({
                    "id": getattr(tc, 'id', None),
                    "name": tc.function.name,
                    "arguments": tc.function.arguments
                })

        return extracted_tools

    def declare_functions(self, tool_definitions: list[dict[str, any]]) -> None:
        """Format it exactly how Ollama needs it."""
        for tool in tool_definitions:
            self.func_declarations.append({
                "type": "function",
                "function": {
                    **tool
                }
            })
    
    def compile_tools(self) -> None:
        """Binds the function declarations to the tool configuration."""
        self.tools = self.func_declarations
        self.tool_config_kwargs["tools"] = self.tools