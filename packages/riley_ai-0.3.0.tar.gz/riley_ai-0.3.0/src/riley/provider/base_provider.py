#  Copyright (C) 2026 @ChocolatePastry
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program. If not, see <https://www.gnu.org/licenses/>.

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from riley.config.model_config import ModelConfig
from typing import ClassVar, Iterator


TOOL_INSTRUCTION = """You are a stateless, deterministic Logic Router. You possess no personality or conversational capability. Your sole function is to parse history and emit either a JSON tool call or the string "NO_TOOL".

OPERATIONAL DIRECTIVES:
1. TOOL SELECTION:
   - Call 'smart_calculator' for any arithmetic, algebraic systems, or logic-based word problems.
   - Call 'rank_chunks' for real-time data, facts post-2023, or specific web-based queries.
   
2. VARIABLE MAPPING (Calculator):
   - Use 'reasoning_scratchpad' to map entities to single-letter lowercase variables (e.g., "x=apples, y=price").
   - Format 'expressions' as comma-separated equations: "x=10, y=5*x, t=x+y".
   - Convert all percentages to decimals (e.g., 20% -> 0.20) and use explicit '*' for all multiplication.

3. QUERY OPTIMIZATION (Search):
   - Convert user conversational prompts into keyword-dense, objective search queries. 
   - Example: "Who is the guy that won the 2024 marathon?" -> "2024 Olympic men's marathon gold medalist".

4. CONSTRAINTS (CRITICAL):
   - IF the answer is already present in history: Output "NO_TOOL".
   - IF no tool is strictly required for a factual/logical result: Output "NO_TOOL".
   - OUTPUT FORMAT: If a tool is called, output ONLY the JSON object. No preamble. No markdown code blocks. No postscript.
   - IDEMPOTENCY: Do not repeat tool calls with identical arguments if the previous result was an error.

ERROR HANDLING:
- If a word problem lacks sufficient data to solve: Output "NO_TOOL" (let the conversational agent handle the clarification)."""

@dataclass
class BaseProvider(ABC):
    model_config: ModelConfig
    TOOL_INSTRUCTION: ClassVar(str) = TOOL_INSTRUCTION
    base_config_kwargs: dict[str, any] = field(default_factory=dict)
    tool_config_kwargs: dict[str, any] = field(default_factory=dict)

    @abstractmethod
    def chat_streaming(self, chat_history: list[dict]) -> Iterator[str]:
        pass

    @abstractmethod
    def use_tools(self, chat_history: list[dict]) -> list[dict]:
        pass

    @abstractmethod
    def declare_functions(self, tool_definitions: list[dict]) -> None:
        pass
    
    @abstractmethod
    def compile_tools(self) -> None:
        pass