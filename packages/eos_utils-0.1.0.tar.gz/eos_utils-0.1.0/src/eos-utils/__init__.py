from get_voms import get_voms
from copy_eos import copy_eos