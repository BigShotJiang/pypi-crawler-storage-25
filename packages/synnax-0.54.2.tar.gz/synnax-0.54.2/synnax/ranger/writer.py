#  Copyright 2026 Synnax Labs, Inc.
#
#  Use of this software is governed by the Business Source License included in the file
#  licenses/BSL.txt.
#
#  As of the Change Date specified in that file, in accordance with the Business Source
#  License, use of this software will be governed by the Apache License, Version 2.0,
#  included in the file licenses/APL.txt.

from pydantic import BaseModel

from alamos import NOOP, Instrumentation, trace
from freighter import Empty, UnaryClient, send_required
from synnax.ontology.payload import ID
from synnax.ranger.payload import Key, Payload


class _CreateRequest(BaseModel):
    parent: ID | None = None
    ranges: list[Payload] = []


_CreateResponse = _CreateRequest


class _DeleteRequest(BaseModel):
    keys: list[Key]


class Writer:
    _client: UnaryClient
    instrumentation: Instrumentation

    def __init__(
        self,
        client: UnaryClient,
        instrumentation: Instrumentation = NOOP,
    ) -> None:
        self._client = client
        self.instrumentation = instrumentation

    @trace("debug", "range.create")
    def create(
        self, ranges: list[Payload], *, parent: ID | None = None
    ) -> list[Payload]:
        req = _CreateRequest(ranges=ranges, parent=parent)
        return send_required(self._client, "/range/create", req, _CreateResponse).ranges

    @trace("debug", "range.delete")
    def delete(self, keys: list[Key]) -> None:
        req = _DeleteRequest(keys=keys)
        send_required(self._client, "/range/delete", req, Empty)
