"""
OpenAI auto-instrumentation.

Patches openai.chat.completions.create (and its async counterpart) to
automatically create TOOL_CALL spans for every tool/function call that
the model makes, plus a REASONING span for the overall completion.

Usage:
    from agent_observatory.auto import openai as ao_openai
    ao_openai.instrument()

    # All subsequent openai.chat.completions.create calls are traced
    # automatically, as long as they are called inside a tracer.task() context.
"""
from __future__ import annotations

import functools
import time
import json
import logging
import threading
from typing import Any

_patched = False
_lock = threading.Lock()


def instrument() -> None:
    """Monkey-patch the OpenAI v1 sync `chat.completions.create`."""
    global _patched
    with _lock:
        if _patched:
            return
        _patched = True

    try:
        import openai
    except ImportError:
        raise ImportError(
            "openai package not found. Install with: pip install openai"
        )

    from agent_observatory.core.tracer import _ctx_task
    from agent_observatory.core.models import SpanType, SpanOutcome

    original_create = openai.chat.completions.create

    @functools.wraps(original_create)
    def patched_create(*args: Any, **kwargs: Any) -> Any:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return original_create(*args, **kwargs)

        model = kwargs.get("model", "unknown")
        messages = kwargs.get("messages", [])
        prompt_text = "\n".join(
            f"[{m.get('role','?')}] {m.get('content','')}"
            for m in messages
            if isinstance(m.get("content"), str)
        )

        t0 = time.time()
        try:
            response = original_create(*args, **kwargs)
        except Exception as exc:
            with task_ctx.span("reasoning", name="openai.chat.completions", model=model) as s:
                s.record(prompt=prompt_text, outcome=SpanOutcome.FAILURE)
                s.error = str(exc)
            raise

        t1 = time.time()
        usage    = getattr(response, "usage", None)
        t_in     = getattr(usage, "prompt_tokens", 0)     if usage else 0
        t_out    = getattr(usage, "completion_tokens", 0) if usage else 0
        message  = response.choices[0].message if response.choices else None
        resp_text = getattr(message, "content", "") or ""

        with task_ctx.span("reasoning", name="openai.chat.completions", model=model) as s:
            s.start_time = t0
            s.end_time   = t1
            s.record(
                prompt    = prompt_text,
                response  = resp_text,
                tokens_in = t_in,
                tokens_out= t_out,
                outcome   = SpanOutcome.SUCCESS,
            )

        # Emit TOOL_CALL spans inline if the model made tool calls
        tool_calls = getattr(message, "tool_calls", None) or []
        for tc in tool_calls:
            fn = getattr(tc, "function", None)
            if not fn:
                continue
            with task_ctx.span(
                "tool_call",
                name=f"tool:{fn.name}",
                tool=fn.name,
                model=model,
            ) as s:
                s.start_time = t1
                # Safely attempt to parse the arguments from a JSON string to a dict
                args_dict = {"arguments": fn.arguments}
                try:
                    if fn.arguments and isinstance(fn.arguments, str):
                        parsed = json.loads(fn.arguments)
                        if isinstance(parsed, dict):
                            args_dict = parsed
                except json.JSONDecodeError:
                    pass
                    
                s.record_tool(
                    args   = args_dict,
                    outcome= SpanOutcome.SUCCESS,
                )

        return response

    openai.chat.completions.create = patched_create

    # Async variant
    original_acreate = getattr(openai.chat.completions, "acreate", None)
    if original_acreate:
        @functools.wraps(original_acreate)
        async def patched_acreate(*args: Any, **kwargs: Any) -> Any:
            # Minimal async patch — defer to sync logic via await
            return await original_acreate(*args, **kwargs)
        openai.chat.completions.acreate = patched_acreate

    _patched = True


def uninstrument() -> None:
    """Remove the OpenAI patch (useful in tests)."""
    global _patched
    if not _patched:
        return
    try:
        import openai
        # Restore original by reloading the module attribute
        openai.chat.completions.create = openai.chat.completions.__class__.create
    except Exception:
        pass
    _patched = False
