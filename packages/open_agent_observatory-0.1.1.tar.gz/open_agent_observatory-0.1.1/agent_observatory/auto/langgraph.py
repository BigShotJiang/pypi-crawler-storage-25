"""
LangGraph auto-instrumentation.

LangGraph executes agents as directed graphs of nodes. This integration
hooks into LangGraph's checkpoint/event stream to emit:

  - A PLANNING span for the overall graph invocation
  - A REASONING span for each node execution
  - A TOOL_CALL span for ToolNode steps

Usage:
    from agent_observatory.auto.langgraph import instrument_graph

    graph = StateGraph(AgentState)
    graph.add_node("agent", call_model)
    graph.add_node("tools", tool_node)
    ...
    app = graph.compile()

    # Wrap compilation with Observatory instrumentation
    app = instrument_graph(app)

    with tracer.task("Run LangGraph agent", agent="langgraph") as task:
        result = app.invoke({"messages": [...]})
"""
from __future__ import annotations

import functools
import time
from typing import Any, Dict, Optional

from agent_observatory.core.models import SpanOutcome, SpanType
from agent_observatory.core.tracer import _ctx_task


def instrument_graph(graph: Any) -> Any:
    """
    Wrap a compiled LangGraph app to emit Observatory spans.

    Patches the graph's `invoke`, `ainvoke`, `stream`, and `astream` methods.
    The graph itself is returned so this works as a transparent wrapper.
    """
    _wrap_invoke(graph)
    _wrap_stream(graph)
    return graph


def _wrap_invoke(graph: Any) -> None:
    orig_invoke  = graph.invoke
    orig_ainvoke = getattr(graph, "ainvoke", None)

    @functools.wraps(orig_invoke)
    def patched_invoke(input: Any, config: Any = None, **kwargs: Any) -> Any:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return orig_invoke(input, config, **kwargs)

        with task_ctx.span("planning", name="langgraph.invoke") as root_span:
            root_span.metadata["graph_input"] = str(input)[:300]
            result = orig_invoke(input, config, **kwargs)
            root_span.metadata["graph_output"] = str(result)[:300]
        return result

    graph.invoke = patched_invoke

    if orig_ainvoke:
        @functools.wraps(orig_ainvoke)
        async def patched_ainvoke(input: Any, config: Any = None, **kwargs: Any) -> Any:
            task_ctx = _ctx_task.get()
            if task_ctx is None:
                return await orig_ainvoke(input, config, **kwargs)

            with task_ctx.span("planning", name="langgraph.ainvoke") as root_span:
                root_span.metadata["graph_input"] = str(input)[:300]
                result = await orig_ainvoke(input, config, **kwargs)
                root_span.metadata["graph_output"] = str(result)[:300]
            return result

        graph.ainvoke = patched_ainvoke


def _wrap_stream(graph: Any) -> None:
    orig_stream  = getattr(graph, "stream", None)
    orig_astream = getattr(graph, "astream", None)

    if orig_stream:
        @functools.wraps(orig_stream)
        def patched_stream(input: Any, config: Any = None, **kwargs: Any):
            task_ctx = _ctx_task.get()
            if task_ctx is None:
                yield from orig_stream(input, config, **kwargs)
                return

            with task_ctx.span("planning", name="langgraph.stream") as root_span:
                root_span.metadata["graph_input"] = str(input)[:300]
                for chunk in orig_stream(input, config, **kwargs):
                    # Each chunk is a dict of {node_name: output}
                    for node_name, node_output in (chunk or {}).items():
                        _emit_node_span(task_ctx, node_name, node_output)
                    yield chunk

        graph.stream = patched_stream

    if orig_astream:
        @functools.wraps(orig_astream)
        async def patched_astream(input: Any, config: Any = None, **kwargs: Any):
            task_ctx = _ctx_task.get()
            if task_ctx is None:
                async for chunk in orig_astream(input, config, **kwargs):
                    yield chunk
                return

            async with task_ctx.span("planning", name="langgraph.astream") as root_span:
                root_span.metadata["graph_input"] = str(input)[:300]
                async for chunk in orig_astream(input, config, **kwargs):
                    for node_name, node_output in (chunk or {}).items():
                        _emit_node_span(task_ctx, node_name, node_output)
                    yield chunk

        graph.astream = patched_astream


def _emit_node_span(task_ctx: Any, node_name: str, node_output: Any) -> None:
    """Emit a span for a single LangGraph node execution."""
    # Detect if this is a tool node
    is_tool = "tool" in node_name.lower()
    span_type = "tool_call" if is_tool else "reasoning"

    with task_ctx.span(span_type, name=f"node:{node_name}") as s:
        s.metadata["node_name"]   = node_name
        s.metadata["node_output"] = str(node_output)[:300]
        s.outcome = SpanOutcome.SUCCESS
