"""
Anthropic auto-instrumentation.

Patches anthropic.messages.create to automatically emit spans for every
Anthropic Claude API call, including tool_use blocks.

Usage:
    from agent_observatory.auto import anthropic as ao_anthropic
    ao_anthropic.instrument()
"""
from __future__ import annotations

import functools
import json
import time
import threading
from typing import Any

_patched = False
_lock = threading.Lock()

def instrument() -> None:
    """Monkey-patch the Anthropic client to emit Observatory spans."""
    global _patched
    with _lock:
        if _patched:
            return
        _patched = True

    try:
        import anthropic as _anthropic
    except ImportError:
        raise ImportError(
            "anthropic package not found. Install with: pip install anthropic"
        )

    from agent_observatory.core.tracer import _ctx_task
    from agent_observatory.core.models import SpanType, SpanOutcome

    original_create = _anthropic.resources.messages.Messages.create

    @functools.wraps(original_create)
    def patched_create(self_client: Any, *args: Any, **kwargs: Any) -> Any:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return original_create(self_client, *args, **kwargs)

        model    = kwargs.get("model", "claude-unknown")
        messages = kwargs.get("messages", [])
        system   = kwargs.get("system", "")
        prompt_parts = []
        if system:
            prompt_parts.append(f"[system] {system}")
        for m in messages:
            content = m.get("content", "")
            if isinstance(content, str):
                prompt_parts.append(f"[{m.get('role','?')}] {content}")
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        prompt_parts.append(f"[{m.get('role','?')}] {block.get('text','')}")
        prompt_text = "\n".join(prompt_parts)

        # Emit TOOL_RESPONSE spans for incoming tool results in the most recent message
        if messages and isinstance(messages, list) and len(messages) > 0:
            last_m = messages[-1]
            if getattr(last_m, "get", None) and last_m.get("role") == "user":
                msg_content = last_m.get("content", [])
                if isinstance(msg_content, list):
                    for block in msg_content:
                        if isinstance(block, dict) and block.get("type") == "tool_result":
                            tool_id = block.get("tool_use_id", "unknown")
                            tr = str(block.get("content", ""))
                            with task_ctx.span("tool_response", name=f"tool_result:{tool_id}") as ts:
                                ts.record_tool(result=tr, outcome=SpanOutcome.SUCCESS)

        t0 = time.time()
        try:
            response = original_create(self_client, *args, **kwargs)
        except Exception as exc:
            with task_ctx.span("reasoning", name="anthropic.messages", model=model) as s:
                s.record(prompt=prompt_text, outcome=SpanOutcome.FAILURE)
                s.error = str(exc)
            raise

        t1 = time.time()
        usage  = getattr(response, "usage", None)
        t_in   = getattr(usage, "input_tokens",  0) if usage else 0
        t_out  = getattr(usage, "output_tokens", 0) if usage else 0

        # Extract text content and tool_use blocks
        content_blocks = getattr(response, "content", []) or []
        text_parts     = []
        tool_use_blocks = []
        for block in content_blocks:
            btype = getattr(block, "type", None)
            if btype == "text":
                text_parts.append(getattr(block, "text", ""))
            elif btype == "tool_use":
                tool_use_blocks.append(block)

        resp_text = "\n".join(text_parts)

        with task_ctx.span("reasoning", name="anthropic.messages", model=model) as s:
            s.start_time = t0
            s.end_time   = t1
            s.record(
                prompt    = prompt_text,
                response  = resp_text,
                tokens_in = t_in,
                tokens_out= t_out,
                outcome   = SpanOutcome.SUCCESS,
            )

        # Emit a TOOL_CALL span for each tool_use block
        for block in tool_use_blocks:
            tool_name = getattr(block, "name", "unknown_tool")
            tool_input = getattr(block, "input", {})
            with task_ctx.span(
                "tool_call",
                name=f"tool:{tool_name}",
                tool=tool_name,
                model=model,
            ) as s:
                s.start_time = t1
                s.record_tool(
                    args   = tool_input if isinstance(tool_input, dict) else {"input": str(tool_input)},
                    outcome= SpanOutcome.SUCCESS,
                )

        return response

    _anthropic.resources.messages.Messages.create = patched_create
    _patched = True


def uninstrument() -> None:
    global _patched
    _patched = False
