"""
Agno auto-instrumentation.

Patches:
  1. Agent.run / Agent.arun       → emits REASONING span per agent invocation
  2. Agent.print_response         → delegates to patched run()
  3. Function.entrypoint (tools)  → emits TOOL_CALL + TOOL_RESPONSE spans
                                     with args, result, latency, tokens per call

Zero friction — just call instrument() once before creating any agents:

    import agent_observatory as obs
    obs.instrument()                   # ← that's it

    from agno.agent import Agent
    from agno.models.google import Gemini
    from agno.tools.yfinance import YFinanceTools

    agent = Agent(model=Gemini(...), tools=[YFinanceTools()])
    agent.run("Give me a quick investment brief on NVIDIA")
    # → all LLM calls AND Yahoo Finance tool calls appear in the dashboard

Tool analytics visible in dashboard:
    - Tool name and parameters per call
    - Latency per tool call
    - Result (first 1000 chars)
    - Call count (run the diff engine to compare runs)
"""
from __future__ import annotations

import functools
import json
import time
import threading
from typing import Any, Callable

_patched = False
_lock = threading.Lock()


def instrument(auto_task: bool = True) -> None:
    """Monkey-patch Agno: agents AND tools. Safe to call multiple times."""
    global _patched
    with _lock:
        if _patched:
            return
        _patched = True

    try:
        from agno.agent import Agent as AgnoAgent
    except ImportError:
        raise ImportError("agno not found. Install with: pip install agno")

    from agent_observatory import tracer as obs_tracer
    from agent_observatory.core.models import SpanOutcome
    from agent_observatory.core.tracer import _ctx_task

    # ── 1. Patch Agent.run ──────────────────────────────────────────────────

    original_run = AgnoAgent.run

    @functools.wraps(original_run)
    def patched_run(self_agent: Any, *args: Any, **kwargs: Any) -> Any:
        # Auto-task: if no task is active, create one automatically
        task_ctx = _ctx_task.get()

        # Extract input message/text
        message = args[0] if args else kwargs.get("input", kwargs.get("message"))

        # Auto-task: if no task is active, create one automatically
        if task_ctx is None:
            model_id   = getattr(getattr(self_agent, "model", None), "id", "unknown-model")
            agent_name = getattr(self_agent, "name", None) or model_id
            
            # Use the global tracer singleton
            if obs_tracer is None:
                return original_run(self_agent, message, *args, **kwargs)
                
            with obs_tracer.task(
                str(message)[:120] if message else "Agent Run",
                agent=agent_name,
                model=model_id,
                parent_trace_id=task_ctx.task.trace_id if task_ctx else None,
                parent_span_id=task_ctx.current_span.span_id if task_ctx and task_ctx.current_span else None,
            ) as auto_task:
                return _run_with_span(original_run, self_agent, args, kwargs, auto_task)

        return _run_with_span(original_run, self_agent, args, kwargs, task_ctx)

    AgnoAgent.run = patched_run

    # ── 2. Patch Agent.arun ─────────────────────────────────────────────────

    original_arun = getattr(AgnoAgent, "arun", None)
    if original_arun:
        @functools.wraps(original_arun)
        async def patched_arun(self_agent: Any, *args: Any, **kwargs: Any) -> Any:
            task_ctx = _ctx_task.get()
            
            message  = args[0] if args else kwargs.get("input", kwargs.get("message"))

            if task_ctx is None:
                model_id   = getattr(getattr(self_agent, "model", None), "id", "unknown-model")
                agent_name = getattr(self_agent, "name", None) or model_id
                
                if obs_tracer is None:
                    return await original_arun(self_agent, message, *args, **kwargs)
                    
                with obs_tracer.task(
                    str(message)[:120] if message else "Agent Run",
                    agent=agent_name,
                    model=model_id,
                    parent_trace_id=task_ctx.task.trace_id if task_ctx else None,
                    parent_span_id=task_ctx.current_span.span_id if task_ctx and task_ctx.current_span else None,
                ) as auto_task:
                    return await _arun_with_span(
                        original_arun, self_agent, args, kwargs, auto_task
                    )

            return await _arun_with_span(
                original_arun, self_agent, args, kwargs, task_ctx
            )

        AgnoAgent.arun = patched_arun

    # ── 3. Patch Agent.print_response ───────────────────────────────────────
    # print_response internally calls run(). The run() patch will capture the span.
    # We only need to ensure an auto-task exists if there isn't one.

    original_print_response = getattr(AgnoAgent, "print_response", None)
    if original_print_response:
        @functools.wraps(original_print_response)
        def patched_print_response(
            self_agent: Any, *args: Any, **kwargs: Any
        ) -> Any:
            task_ctx = _ctx_task.get()
            message  = args[0] if args else kwargs.get("input", kwargs.get("message"))
            if task_ctx is None:
                model_id   = getattr(getattr(self_agent, "model", None), "id", "unknown-model")
                agent_name = getattr(self_agent, "name", None) or model_id
                
                if obs_tracer is None:
                    return original_print_response(self_agent, *args, **kwargs)
                    
                with obs_tracer.task(
                    str(message)[:120] if message else "Agent Run",
                    agent=agent_name,
                    model=model_id,
                ):
                    return original_print_response(self_agent, *args, **kwargs)
            return original_print_response(self_agent, *args, **kwargs)

        AgnoAgent.print_response = patched_print_response

    # ── 4. Patch Function.entrypoint (tool calls) ───────────────────────────
    _patch_agno_functions()


# ── Helpers for agent run spans ─────────────────────────────────────────────

def _populate_replay_info(task: Any, self_agent: Any, message: Any) -> None:
    # Safely extract replay details without crashing
    if not hasattr(task, "task_prompt"): return
    try:
        if message and not task.task_prompt:
            task.task_prompt = str(message)
            
        if not task.agent_config:
            system_prompt = getattr(self_agent, "system_prompt", None)
            if callable(system_prompt): system_prompt = "callable"
            params = {
                "system_prompt": system_prompt,
                "description": getattr(self_agent, "description", None),
                "instructions": getattr(self_agent, "instructions", None)
            }
            # Convert any non-serializable objects to string before assigning to dict
            def _to_str(v): return str(v) if v is not None and not isinstance(v, (str, int, float, bool, dict, list)) else v
            params = {k: _to_str(v) for k, v in params.items()}
            task.agent_config = params
            
        if not task.model_config:
            model = getattr(self_agent, "model", None)
            if model:
                task.model_config = {
                    "id": getattr(model, "id", None),
                    "metrics": getattr(model, "metrics", False)
                }
                
        if not task.tool_registry:
            tools = getattr(self_agent, "tools", []) or []
            tool_names = []
            for t in tools:
                if hasattr(t, "name"): tool_names.append(t.name)
                elif hasattr(t, "functions") and hasattr(t.functions, "keys"):
                    tool_names.extend(list(t.functions.keys()))
                else: tool_names.append(str(t))
            task.tool_registry = tool_names
    except Exception as e:
        print("[observatory] warning: failed to extract replay info:", e)

def _run_with_span(original_run, self_agent, args, kwargs, task_ctx):
    _populate_replay_info(task_ctx.task, self_agent, args[0] if args else kwargs.get("input", kwargs.get("message")))
    from agent_observatory.core.models import SpanOutcome
    model_id   = getattr(getattr(self_agent, "model", None), "id", "unknown-model")
    agent_name = getattr(self_agent, "name", None) or model_id
    message    = args[0] if args else kwargs.get("input", kwargs.get("message"))
    is_stream  = kwargs.get("stream", False)

    with task_ctx.span(
        "reasoning",
        name=f"agno:{agent_name}",
        model=model_id,
    ) as s:
        if message:
            s.prompt = str(message)[:2000]
        try:
            result = original_run(self_agent, *args, **kwargs)
            
            # ── Handle Streaming ─────────────────────────────────────────────
            if is_stream and hasattr(result, "__iter__"):
                def _wrap_stream(it):
                    full_content = []
                    last_event = None
                    try:
                        for event in it:
                            last_event = event
                            # In Agno, events might have content
                            content = getattr(event, "content", None)
                            if content: full_content.append(str(content))
                            yield event
                    finally:
                        s.response = "".join(full_content)[:2000]
                        # Extract tokens from the final RunOutput if available
                        _apply_tokens(s, last_event)

                return _wrap_stream(result)

            # ── Handle Non-Streaming ─────────────────────────────────────────
            content = getattr(result, "content", None) or ""
            s.response = str(content)[:2000]
            _apply_tokens(s, result)
            return result
        except Exception as exc:
            s.error = str(exc)
            raise


async def _arun_with_span(original_arun, self_agent, args, kwargs, task_ctx):
    _populate_replay_info(task_ctx.task, self_agent, args[0] if args else kwargs.get("input", kwargs.get("message")))
    from agent_observatory.core.models import SpanOutcome
    model_id   = getattr(getattr(self_agent, "model", None), "id", "unknown-model")
    agent_name = getattr(self_agent, "name", None) or model_id
    message    = args[0] if args else kwargs.get("input", kwargs.get("message"))
    is_stream  = kwargs.get("stream", False)

    with task_ctx.span(
        "reasoning",
        name=f"agno:{agent_name}",
        model=model_id,
    ) as s:
        if message:
            s.prompt = str(message)[:2000]
        try:
            result = await original_arun(self_agent, *args, **kwargs)

            # ── Handle Async Streaming ────────────────────────────────────────
            if is_stream and hasattr(result, "__aiter__"):
                async def _wrap_async_stream(it):
                    full_content = []
                    last_event = None
                    try:
                        async for event in it:
                            last_event = event
                            content = getattr(event, "content", None)
                            if content: full_content.append(str(content))
                            yield event
                    finally:
                        s.response = "".join(full_content)[:2000]
                        _apply_tokens(s, last_event)

                return _wrap_async_stream(result)

            # ── Handle Non-Streaming ─────────────────────────────────────────
            content = getattr(result, "content", None) or ""
            s.response = str(content)[:2000]
            _apply_tokens(s, result)
            return result
        except Exception as exc:
            s.error = str(exc)
            raise


# ── Tool patching ────────────────────────────────────────────────────────────

def _patch_agno_functions() -> None:
    """
    Wrap every Agno Function's entrypoint so tool calls appear as spans.

    Strategy: patch `Function._wrap_callable` which is called once per function
    when a Toolkit registers its tools. We inject our tracing wrapper around the
    entrypoint callable at registration time.

    Fallback: Also patch `Toolkit.register` to wrap all tools in a toolkit.
    """
    from agent_observatory.core.tracer import _ctx_task
    from agent_observatory.core.models import SpanOutcome

    try:
        from agno.tools.function import Function
        from agno.tools.toolkit import Toolkit
    except ImportError:
        return

    # ── Patch Toolkit.register to intercept tool registration ───────────────
    original_register = getattr(Toolkit, "register", None)

    if original_register:
        @functools.wraps(original_register)
        def patched_register(self_toolkit: Any, fn: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_register(self_toolkit, fn, *args, **kwargs)
            # After registration, wrap the entrypoint of all registered functions
            for func_obj in (self_toolkit.functions or {}).values():
                _wrap_function_entrypoint(func_obj)
            return result

        Toolkit.register = patched_register

    # ── Also patch Function.from_callable (used for @tool decorators) ────────
    original_from_callable = getattr(Function, "from_callable", None)
    if original_from_callable:
        @classmethod
        @functools.wraps(original_from_callable.__func__ if hasattr(original_from_callable, '__func__') else original_from_callable)
        def patched_from_callable(cls, *args, **kwargs):
            func_obj = original_from_callable(*args, **kwargs)
            _wrap_function_entrypoint(func_obj)
            return func_obj

        Function.from_callable = patched_from_callable


_wrapped_entrypoints: set = set()


def _wrap_function_entrypoint(func_obj: Any) -> None:
    """
    Wrap func_obj.entrypoint so that each call emits TOOL_CALL + TOOL_RESPONSE spans.
    """
    from agent_observatory.core.tracer import _ctx_task
    from agent_observatory.core.models import SpanOutcome

    entrypoint = getattr(func_obj, "entrypoint", None)
    if entrypoint is None:
        return

    ep_id = id(entrypoint)
    if ep_id in _wrapped_entrypoints:
        return
    _wrapped_entrypoints.add(ep_id)

    fn_name = getattr(func_obj, "name", None) or getattr(entrypoint, "__name__", "tool")

    @functools.wraps(entrypoint)
    def traced_entrypoint(*args: Any, **kwargs: Any) -> Any:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return entrypoint(*args, **kwargs)

        # Build clean args dict (skip agent/team internal kwargs)
        _SKIP = {"agent", "team", "run_context", "images", "videos", "audios", "files"}
        clean_args = {k: v for k, v in kwargs.items() if k not in _SKIP}

        t0 = time.perf_counter()

        with task_ctx.span("tool_call", name=f"tool:{fn_name}", tool=fn_name) as call_span:
            call_span.tool_name = fn_name
            call_span.tool_args = clean_args
            
            # Out-of-band context propagation happens automatically via contextvars
            # so we no longer inject __observatory_parent_trace_id__ into kwargs.
                
            try:
                result      = entrypoint(*args, **kwargs)
                elapsed_ms  = (time.perf_counter() - t0) * 1000
                result_str  = str(result)[:1000]
                call_span.record_tool(
                    args    = clean_args,
                    result  = result_str,
                    outcome = SpanOutcome.SUCCESS,
                )
            except Exception as exc:
                call_span.record_tool(
                    args    = clean_args,
                    result  = str(exc),
                    outcome = SpanOutcome.FAILURE,
                )
                raise

        # Emit a sibling TOOL_RESPONSE span (keeps timeline readable)
        with task_ctx.span("tool_response", name=f"result:{fn_name}") as resp_span:
            resp_span.record(
                response = result_str,
                outcome  = SpanOutcome.SUCCESS,
            )

        return result

    func_obj.entrypoint = traced_entrypoint


# ── Token extraction ─────────────────────────────────────────────────────────

def _apply_tokens(span: Any, run_response: Any) -> None:
    """Extract input/output token counts from Agno's RunOutput.metrics."""
    try:
        metrics = getattr(run_response, "metrics", None)
        if metrics is None:
            return
        tok_in  = int(getattr(metrics, "input_tokens",  0) or 0)
        tok_out = int(getattr(metrics, "output_tokens", 0) or 0)
        if tok_in or tok_out:
            span.tokens.tokens_in  += tok_in
            span.tokens.tokens_out += tok_out
            return
        # Fallback: dict-style (older Agno)
        if isinstance(metrics, dict):
            def _s(k):
                v = metrics.get(k, [])
                return sum(x for x in (v if isinstance(v, (list,tuple)) else [v]) if isinstance(x,(int,float)))
            span.tokens.tokens_in  += _s("input_tokens")  or _s("prompt_tokens")
            span.tokens.tokens_out += _s("output_tokens") or _s("completion_tokens")
    except Exception:
        pass


def _global_tracer():
    """NOT USED anymore — use top-level 'tracer' singleton"""
    pass


def uninstrument() -> None:
    global _patched
    _patched = False
