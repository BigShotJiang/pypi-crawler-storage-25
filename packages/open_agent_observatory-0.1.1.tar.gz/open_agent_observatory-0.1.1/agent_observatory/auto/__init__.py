"""
Agent Observatory auto-instrumentation.

Import the sub-module for the framework you want to instrument:

    from agent_observatory.auto import openai as ao_openai
    ao_openai.instrument()

    from agent_observatory.auto import anthropic as ao_anthropic
    ao_anthropic.instrument()

    from agent_observatory.auto.langchain import ObservatoryCallbackHandler

    from agent_observatory.auto import langgraph as ao_lg
    app = ao_lg.instrument_graph(compiled_graph)

    from agent_observatory.auto import crewai as ao_crewai
    ao_crewai.instrument()

    from agent_observatory.auto import agno as ao_agno
    ao_agno.instrument()
"""
