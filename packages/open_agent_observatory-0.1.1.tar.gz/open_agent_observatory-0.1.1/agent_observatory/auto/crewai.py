"""
CrewAI auto-instrumentation.

Patches CrewAI's Agent.execute_task to emit spans for:
  - Each agent's task execution (PLANNING span wrapping the whole crew run)
  - LLM calls made by agents (delegated to the OpenAI/Anthropic patches)
  - Tool invocations made by agents

Usage:
    from agent_observatory.auto import crewai as ao_crewai
    ao_crewai.instrument()

    from crewai import Agent, Task, Crew

    with tracer.task("Research and write report", agent="crewai") as task:
        crew = Crew(agents=[researcher, writer], tasks=[research_task, write_task])
        result = crew.kickoff()
"""
from __future__ import annotations

import functools
import time
import threading
from typing import Any

_patched = False
_lock = threading.Lock()

def instrument() -> None:
    """Monkey-patch CrewAI's execution loop to emit Observatory spans."""
    global _patched
    with _lock:
        if _patched:
            return
        _patched = True

    try:
        import crewai
        from crewai import Agent, Task, Crew
    except ImportError:
        raise ImportError(
            "crewai not found. Install with: pip install crewai"
        )

    from agent_observatory.core.tracer import _ctx_task
    from agent_observatory.core.models import SpanOutcome

    # ---- Patch Agent.execute_task ----------------------------------------

    original_execute = Agent.execute_task

    @functools.wraps(original_execute)
    def patched_execute_task(
        self_agent: Any,
        task: Any,
        context: Any = None,
        tools: Any = None,
    ) -> Any:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return original_execute(self_agent, task, context, tools)

        agent_role = getattr(self_agent, "role", "unknown-agent")
        task_desc  = getattr(task, "description", "unknown-task")[:200]

        with task_ctx.span(
            "planning",
            name=f"crewai.agent:{agent_role}",
            crewai_role=agent_role,
            crewai_task=task_desc,
        ) as s:
            try:
                result = original_execute(self_agent, task, context, tools)
                s.record(response=str(result)[:500], outcome=SpanOutcome.SUCCESS)
                return result
            except Exception as exc:
                s.outcome = SpanOutcome.FAILURE
                s.error   = str(exc)
                raise

    Agent.execute_task = patched_execute_task

    # ---- Patch Crew.kickoff ----------------------------------------------

    original_kickoff = Crew.kickoff

    @functools.wraps(original_kickoff)
    def patched_kickoff(self_crew: Any, *args: Any, **kwargs: Any) -> Any:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return original_kickoff(self_crew, *args, **kwargs)

        crew_name = getattr(self_crew, "name", "unnamed-crew")
        n_agents   = len(getattr(self_crew, "agents", []))
        n_tasks    = len(getattr(self_crew, "tasks",  []))

        with task_ctx.span(
            "planning",
            name=f"crewai.kickoff:{crew_name}",
            crew_name=crew_name,
            n_agents=n_agents,
            n_tasks=n_tasks,
        ) as s:
            result = original_kickoff(self_crew, *args, **kwargs)
            s.record(response=str(result)[:500], outcome=SpanOutcome.SUCCESS)
            return result

    Crew.kickoff = patched_kickoff

    _patched = True


def uninstrument() -> None:
    global _patched
    _patched = False
