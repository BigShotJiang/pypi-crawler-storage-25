"""
LangChain auto-instrumentation.

Implements a LangChain BaseCallbackHandler that hooks into:
  - on_llm_start / on_llm_end / on_llm_error
  - on_tool_start / on_tool_end / on_tool_error
  - on_chain_start / on_chain_end / on_chain_error
  - on_agent_action / on_agent_finish

Usage:
    from agent_observatory.auto.langchain import ObservatoryCallbackHandler
    from agent_observatory import tracer

    handler = ObservatoryCallbackHandler()

    # Option A — pass as callback to any LangChain component
    llm = ChatOpenAI(callbacks=[handler])
    agent = AgentExecutor(agent=..., tools=..., callbacks=[handler])

    # Option B — set as global callback
    from langchain.callbacks import set_handler
    set_handler(handler)

    # Both options require wrapping the run in a tracer.task():
    with tracer.task("Answer complex question", agent="langchain") as task:
        result = agent.invoke({"input": "..."})
"""
from __future__ import annotations

import time
import uuid
from typing import Any, Dict, List, Optional, Union

from agent_observatory.core.models import SpanOutcome, SpanType
from agent_observatory.core.tracer import _ctx_task, _ctx_span

try:
    from langchain_core.callbacks.base import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
    _HAS_LANGCHAIN = True
except ImportError:
    # Provide a no-op base if langchain is not installed
    class BaseCallbackHandler:  # type: ignore
        pass
    LLMResult = Any  # type: ignore
    _HAS_LANGCHAIN = False


class ObservatoryCallbackHandler(BaseCallbackHandler):
    """
    LangChain callback handler that emits Agent Observatory spans.

    Attach once to your LangChain agent/chain/LLM and every execution
    step is automatically captured — no manual instrumentation needed.
    """

    def __init__(self) -> None:
        super().__init__()
        # Per-run_id state to track timing
        self._run_starts: Dict[str, float] = {}
        self._run_spans:  Dict[str, Any]   = {}

    # ------------------------------------------------------------------
    # LLM hooks
    # ------------------------------------------------------------------

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> None:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return

        model = (
            serialized.get("kwargs", {}).get("model_name")
            or serialized.get("name", "unknown-llm")
        )
        prompt_text = "\n---\n".join(prompts)
        span_ctx = task_ctx.span("reasoning", name=f"llm:{model}", model=model)
        span = span_ctx.__enter__()
        span.prompt = prompt_text
        self._run_starts[str(run_id)] = time.time()
        self._run_spans[str(run_id)]  = (span_ctx, span)

    def on_llm_end(
        self,
        response: "LLMResult",
        *,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key not in self._run_spans:
            return
        span_ctx, span = self._run_spans.pop(key)
        self._run_starts.pop(key, None)

        # Extract token usage if available
        llm_output = getattr(response, "llm_output", {}) or {}
        usage = llm_output.get("token_usage", {})
        span.tokens.tokens_in  += usage.get("prompt_tokens", 0)
        span.tokens.tokens_out += usage.get("completion_tokens", 0)

        # Extract response text
        texts = []
        for gen_list in (response.generations or []):
            for gen in gen_list:
                texts.append(getattr(gen, "text", ""))
        span.response = "\n".join(texts)
        span_ctx.__exit__(None, None, None)

    def on_llm_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key not in self._run_spans:
            return
        span_ctx, span = self._run_spans.pop(key)
        self._run_starts.pop(key, None)
        span_ctx.__exit__(type(error), error, None)

    # ------------------------------------------------------------------
    # Tool hooks
    # ------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> None:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return

        tool_name = serialized.get("name", "unknown_tool")
        span_ctx = task_ctx.span("tool_call", name=f"tool:{tool_name}", tool=tool_name)
        span = span_ctx.__enter__()
        span.tool_args = {"input": input_str}
        self._run_spans[str(run_id)] = (span_ctx, span)

    def on_tool_end(
        self,
        output: str,
        *,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key not in self._run_spans:
            return
        span_ctx, span = self._run_spans.pop(key)
        span.tool_result = str(output)
        span.outcome     = SpanOutcome.SUCCESS
        span_ctx.__exit__(None, None, None)

    def on_tool_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key not in self._run_spans:
            return
        span_ctx, span = self._run_spans.pop(key)
        span_ctx.__exit__(type(error), error, None)

    # ------------------------------------------------------------------
    # Chain hooks (captures sub-chain/agent execution frames)
    # ------------------------------------------------------------------

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> None:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return

        chain_name = serialized.get("id", ["unknown_chain"])[-1]
        span_ctx = task_ctx.span("planning", name=f"chain:{chain_name}")
        span = span_ctx.__enter__()
        span.metadata["chain_inputs"] = str(inputs)[:500]
        self._run_spans[str(run_id)] = (span_ctx, span)

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key not in self._run_spans:
            return
        span_ctx, span = self._run_spans.pop(key)
        span.metadata["chain_outputs"] = str(outputs)[:500]
        span.outcome = SpanOutcome.SUCCESS
        span_ctx.__exit__(None, None, None)

    def on_chain_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: uuid.UUID,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key not in self._run_spans:
            return
        span_ctx, span = self._run_spans.pop(key)
        span_ctx.__exit__(type(error), error, None)

    # ------------------------------------------------------------------
    # Agent action / finish (AgentExecutor-level events)
    # ------------------------------------------------------------------

    def on_agent_action(self, action: Any, *, run_id: uuid.UUID, **kwargs: Any) -> None:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return
        tool   = getattr(action, "tool", "unknown")
        t_input = getattr(action, "tool_input", {})
        with task_ctx.span("tool_call", name=f"agent_action:{tool}", tool=tool) as s:
            s.record_tool(
                args   = t_input if isinstance(t_input, dict) else {"input": str(t_input)},
                outcome= SpanOutcome.SUCCESS,
            )

    def on_agent_finish(self, finish: Any, *, run_id: uuid.UUID, **kwargs: Any) -> None:
        task_ctx = _ctx_task.get()
        if task_ctx is None:
            return
        output = getattr(finish, "return_values", {})
        with task_ctx.span("reflection", name="agent_finish") as s:
            s.record(response=str(output)[:500], outcome=SpanOutcome.SUCCESS)
