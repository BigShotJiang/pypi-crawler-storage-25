"""
Zero-friction Observatory SDK.

Two integration modes:

1.  ONE-LINER (auto-instrument everything):
    ─────────────────────────────────────────
    import agent_observatory as obs
    obs.instrument()          # detects + patches Agno, LangChain, OpenAI, etc.

    from agno.agent import Agent
    agent = Agent(...)
    agent.run("What is NVDA trading at?")   # ← fully traced, tools captured

2.  EXPLICIT TASK WRAPPING (fine-grained control):
    ─────────────────────────────────────────
    import agent_observatory as obs
    obs.instrument()

    with obs.task("NVIDIA brief", agent="finance-agent") as t:
        agent.run("Give me a quick investment brief on NVIDIA")

3.  DECORATOR (trace a function as one task):
    ─────────────────────────────────────────
    @obs.observe("NVIDIA brief", agent="finance-agent")
    def run():
        agent.run("Give me a quick investment brief on NVIDIA")
"""
from agent_observatory.core.tracer import GlobalTracer as _GlobalTracer

# ── Global singleton ────────────────────────────────────────────────────────
tracer = _GlobalTracer()

# ── Re-export the key types so users only need one import ───────────────────
from agent_observatory.core.models import (
    AgentTask, AgentSpan, TokenUsage,
    SpanType, SpanOutcome, TaskOutcome,
)
from agent_observatory.core.outcome import RichOutcome, HallucinationSignal
from agent_observatory.core import redaction


import threading
_INSTRUMENTED = False
_INSTRUMENT_LOCK = threading.Lock()

# ── Top-level convenience API ───────────────────────────────────────────────

def instrument(
    agno:       bool | str = "auto",
    openai:     bool | str = "auto",
    anthropic:  bool | str = "auto",
    langchain:  bool | str = "auto",
    langgraph:  bool | str = "auto",
    crewai:     bool | str = "auto",
    auto_task:  bool = True,
    db_path:    str | None = None,
    scrubber_config:  "redaction.Scrubber | None" = None,
    scrubber:   "redaction.Scrubber | None" = None,
) -> None:
    """
    One-line setup.  Automatically detects installed frameworks and patches them.

    Args:
        agno / openai / … : True = always patch, False = skip, "auto" = patch if installed
        auto_task : If True, every Agent.run() that is NOT already inside a tracer.task()
                    block will be automatically wrapped in its own task so you still get
                    a complete trace even without explicit task() wrapping.
        db_path   : Override default SQLite path (~/.observatory/traces.db)
        redaction : Optional Scrubber for PII redaction.  Use obs.redaction.RegexScrubber()
                    or obs.redaction.HookScrubber(fn=...) etc.
        scrubber  : Alias for redaction.
    """
    global _INSTRUMENTED
    with _INSTRUMENT_LOCK:
        if _INSTRUMENTED:
            return
        _INSTRUMENTED = True

    tracer.configure(db_path=db_path, redaction=scrubber_config or scrubber)

    def _try(flag, module_path, fn_name="instrument"):
        if flag is False:
            return
        try:
            import importlib
            mod = importlib.import_module(module_path)
            getattr(mod, fn_name)()
        except (ImportError, AttributeError):
            if flag is True:  # user explicitly asked → raise
                raise
        except Exception as e:
            # For things like OpenAI lazy-loading key checks
            import logging
            logging.debug(f"Failed to patch {module_path}: {e}")
            if flag is True:  # user explicitly asked → raise
                raise

    _try(agno,      "agent_observatory.auto.agno")
    _try(openai,    "agent_observatory.auto.openai")
    _try(anthropic, "agent_observatory.auto.anthropic")
    _try(langchain, "agent_observatory.auto.langchain", "_instrument_global")
    _try(langgraph, "agent_observatory.auto.langgraph", "_instrument_global")
    _try(crewai,    "agent_observatory.auto.crewai")


def task(name: str = "Agent Task", **kwargs):
    """
    Convenience shortcut:  with obs.task("brief") as t: ...

    Identical to `tracer.task(name, **kwargs)`.
    """
    return tracer.task(name, **kwargs)


def observe(name: str | None = None, **task_kwargs):
    """
    Decorator that wraps a function in a tracer.task().

    @obs.observe("NVIDIA brief", agent="finance-agent", model="gemini-2.5-flash-lite")
    def run():
        agent.run("Give me a quick investment brief on NVIDIA")
    """
    import functools

    def decorator(fn):
        task_name = name or fn.__name__

        @functools.wraps(fn)
        def sync_wrapper(*args, **kwargs):
            with tracer.task(task_name, **task_kwargs):
                return fn(*args, **kwargs)

        @functools.wraps(fn)
        async def async_wrapper(*args, **kwargs):
            with tracer.task(task_name, **task_kwargs):
                return await fn(*args, **kwargs)

        import asyncio, inspect
        return async_wrapper if inspect.iscoroutinefunction(fn) else sync_wrapper

    return decorator


__all__ = [
    "tracer", "instrument", "task", "observe",
    "AgentTask", "AgentSpan", "TokenUsage",
    "SpanType", "SpanOutcome", "TaskOutcome",
    "RichOutcome", "HallucinationSignal",
    "redaction",
]
