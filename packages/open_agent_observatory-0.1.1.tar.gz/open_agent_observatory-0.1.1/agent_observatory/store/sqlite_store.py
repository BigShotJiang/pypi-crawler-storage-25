"""
SQLite-backed local trace store.

Tables
------
traces  — one row per task; stores full JSON blob + indexed summary columns
spans   — flattened span rows for fast analytical queries (no blob scan)

The database lives at ~/.observatory/traces.db by default, so traces are
available across projects. Override with `db_path` or the OBSERVATORY_DB
environment variable.
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from agent_observatory.core.models import AgentSpan, AgentTask

if TYPE_CHECKING:
    from agent_observatory.core.redaction import Scrubber


def _default_db_path() -> Path:
    env = os.environ.get("OBSERVATORY_DB")
    if env:
        return Path(env)
    return Path.home() / ".observatory" / "traces.db"


class SQLiteStore:
    """Thread-safe SQLite trace store using WAL mode."""

    def __init__(self, db_path: Optional[str] = None) -> None:
        self.db_path = Path(db_path) if db_path else _default_db_path()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._init_db()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS traces (
                    task_id          TEXT PRIMARY KEY,
                    trace_id         TEXT NOT NULL,
                    name             TEXT NOT NULL DEFAULT '',
                    agent_name       TEXT,
                    model            TEXT,
                    agent_version    TEXT,
                    tags             TEXT DEFAULT '[]',
                    start_time       REAL NOT NULL,
                    end_time         REAL,
                    latency_ms       REAL,
                    outcome          TEXT NOT NULL DEFAULT 'unknown',
                    terminal_state   TEXT,
                    error            TEXT,
                    total_tokens     INTEGER DEFAULT 0,
                    span_count       INTEGER DEFAULT 0,
                    efficiency_score REAL,
                    hallucination_count INTEGER DEFAULT 0,
                    parent_trace_id  TEXT,
                    task_prompt      TEXT,
                    model_config     TEXT,
                    tool_registry    TEXT,
                    agent_config     TEXT,
                    blob             TEXT NOT NULL,
                    created_at       REAL NOT NULL DEFAULT (unixepoch('now', 'subsec'))
                );

                CREATE TABLE IF NOT EXISTS spans (
                    span_id    TEXT PRIMARY KEY,
                    task_id    TEXT NOT NULL,
                    parent_id  TEXT,
                    type       TEXT NOT NULL,
                    name       TEXT,
                    start_time REAL,
                    end_time   REAL,
                    latency_ms REAL,
                    model      TEXT,
                    tokens_in  INTEGER DEFAULT 0,
                    tokens_out INTEGER DEFAULT 0,
                    tool_name  TEXT,
                    outcome    TEXT,
                    FOREIGN KEY (task_id) REFERENCES traces(task_id) ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_traces_start   ON traces(start_time DESC);
                CREATE INDEX IF NOT EXISTS idx_traces_outcome  ON traces(outcome);
                CREATE INDEX IF NOT EXISTS idx_traces_agent    ON traces(agent_name);
                CREATE INDEX IF NOT EXISTS idx_traces_model    ON traces(model);
                CREATE INDEX IF NOT EXISTS idx_spans_task      ON spans(task_id);
                CREATE INDEX IF NOT EXISTS idx_spans_type      ON spans(type);
                CREATE INDEX IF NOT EXISTS idx_spans_outcome   ON spans(outcome);
            """)
        self._migrate_db()

    def _migrate_db(self) -> None:
        """
        Safe, additive migrations for existing databases.
        Each ALTER TABLE is wrapped in a try/except so it is a no-op when
        the column already exists (SQLite raises OperationalError).
        """
        migrations = [
            "ALTER TABLE traces ADD COLUMN agent_version    TEXT",
            "ALTER TABLE traces ADD COLUMN terminal_state   TEXT",
            "ALTER TABLE traces ADD COLUMN efficiency_score REAL",
            "ALTER TABLE traces ADD COLUMN hallucination_count INTEGER DEFAULT 0",
            "ALTER TABLE traces ADD COLUMN parent_trace_id  TEXT",
            "ALTER TABLE traces ADD COLUMN task_prompt      TEXT",
            "ALTER TABLE traces ADD COLUMN model_config     TEXT",
            "ALTER TABLE traces ADD COLUMN tool_registry    TEXT",
            "ALTER TABLE traces ADD COLUMN agent_config     TEXT",
        ]
        index_migrations = [
            "CREATE INDEX IF NOT EXISTS idx_traces_version ON traces(agent_version)",
            "CREATE INDEX IF NOT EXISTS idx_traces_parent  ON traces(parent_trace_id)",
            "CREATE INDEX IF NOT EXISTS idx_spans_tool     ON spans(tool_name)",
            "CREATE INDEX IF NOT EXISTS idx_spans_trace    ON spans(task_id)",
            "CREATE INDEX IF NOT EXISTS idx_traces_id      ON traces(trace_id)",
        ]
        with self._connect() as conn:
            for sql in migrations:
                try:
                    conn.execute(sql)
                except sqlite3.OperationalError:
                    pass  # column already exists
            for sql in index_migrations:
                try:
                    conn.execute(sql)
                except sqlite3.OperationalError:
                    pass  # index already exists

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def save_task(self, task: AgentTask, scrubber: Optional["Scrubber"] = None) -> None:
        """Persist a task and all its spans atomically.
        
        If a scrubber is provided, the JSON blob is scrubbed before writing.
        The in-memory AgentTask object is never mutated.
        """
        raw_dict = task.to_dict()
        if scrubber is not None:
            raw_dict = scrubber.scrub_dict(raw_dict)
        blob = json.dumps(raw_dict, default=str)

        ro = task.rich_outcome

        with self._lock:
            conn = self._connect()
            try:
                with conn:
                    conn.execute("""
                        INSERT OR REPLACE INTO traces
                            (task_id, trace_id, name, agent_name, model, agent_version, tags,
                             start_time, end_time, latency_ms, outcome, terminal_state, error,
                             total_tokens, span_count, efficiency_score, hallucination_count,
                             parent_trace_id, task_prompt, model_config, tool_registry, agent_config,
                             blob)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        task.task_id, task.trace_id, task.name, task.agent_name,
                        task.model, task.agent_version, json.dumps(task.tags),
                        task.start_time, task.end_time, task.latency_ms,
                        task.outcome.value,
                        (ro.terminal_state if ro else task.outcome.value),
                        task.error,
                        task.total_tokens, task.span_count,
                        (ro.efficiency_score if ro else None),
                        (len(ro.hallucination_signals) if ro else 0),
                        task.parent_trace_id,
                        raw_dict.get("task_prompt"),
                        json.dumps(raw_dict.get("model_config")) if raw_dict.get("model_config") is not None else None,
                        json.dumps(raw_dict.get("tool_registry")) if raw_dict.get("tool_registry") is not None else None,
                        json.dumps(raw_dict.get("agent_config")) if raw_dict.get("agent_config") is not None else None,
                        blob,
                    ))

                    # Upsert spans
                    conn.execute("DELETE FROM spans WHERE task_id = ?", (task.task_id,))
                    conn.executemany("""
                        INSERT OR IGNORE INTO spans
                            (span_id, task_id, parent_id, type, name,
                             start_time, end_time, latency_ms, model,
                             tokens_in, tokens_out, tool_name, outcome)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """, [
                        (
                            s.span_id, task.task_id, s.parent_id,
                            s.type.value, s.name,
                            s.start_time, s.end_time, s.latency_ms, s.model,
                            s.tokens.tokens_in, s.tokens.tokens_out,
                            s.tool_name,
                            (s.outcome.value if hasattr(s.outcome, "value") else str(s.outcome)),
                        )
                        for s in task.spans
                    ])
            finally:
                conn.close()

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get_task(self, task_id: str) -> Optional[AgentTask]:
        """Retrieve a full task by ID (deserialises from JSON blob)."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT blob FROM traces WHERE task_id = ?", (task_id,)
            ).fetchone()
        if not row:
            return None
        return AgentTask.from_dict(json.loads(row["blob"]))

    def list_tasks(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        agent: Optional[str] = None,
        outcome: Optional[str] = None,
        model: Optional[str] = None,
        search: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Return lightweight summaries (no blob), newest first."""
        conditions: List[str] = []
        params: List[Any] = []

        if agent:
            conditions.append("agent_name = ?"); params.append(agent)
        if outcome:
            conditions.append("outcome = ?");    params.append(outcome)
        if model:
            conditions.append("model = ?");      params.append(model)
        if search:
            conditions.append("name LIKE ?");    params.append(f"%{search}%")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""

        with self._connect() as conn:
            rows = conn.execute(f"""
                SELECT task_id, trace_id, name, agent_name, model, agent_version, tags,
                       start_time, end_time, latency_ms, outcome, terminal_state, error,
                       total_tokens, span_count, efficiency_score, hallucination_count,
                       parent_trace_id
                FROM traces
                {where}
                ORDER BY start_time DESC
                LIMIT ? OFFSET ?
            """, params + [limit, offset]).fetchall()

        results = []
        for r in rows:
            d = dict(r)
            d["tags"] = json.loads(d.get("tags") or "[]")
            results.append(d)
        return results

    def count_tasks(
        self,
        *,
        agent: Optional[str] = None,
        outcome: Optional[str] = None,
    ) -> int:
        conditions: List[str] = []
        params: List[Any] = []
        if agent:
            conditions.append("agent_name = ?"); params.append(agent)
        if outcome:
            conditions.append("outcome = ?");    params.append(outcome)
        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        with self._connect() as conn:
            return conn.execute(f"SELECT COUNT(*) FROM traces {where}", params).fetchone()[0]

    def delete_task(self, task_id: str) -> bool:
        """Delete a task and all its spans. Returns True if a row was deleted."""
        with self._connect() as conn:
            result = conn.execute("DELETE FROM traces WHERE task_id = ?", (task_id,))
        return result.rowcount > 0

    def get_min_successful_steps(
        self,
        group_key: str,
        group_type: str = "agent_name",
        min_corpus: int = 5,
    ) -> Optional[int]:
        """
        Return the minimum span_count across successful traces with the same agent_name or name.
        Returns None if there are fewer than `min_corpus` qualifying traces
        (cold-start guard: avoids returning noise from a single outlier).
        """
        valid_cols = {"agent_name", "name", "model"}
        col = group_type if group_type in valid_cols else "agent_name"
        
        with self._connect() as conn:
            rows = conn.execute(f"""
                SELECT span_count FROM traces
                WHERE outcome = 'success' AND {col} = ?
                ORDER BY span_count ASC
                LIMIT 50
            """, (group_key,)).fetchall()

        if len(rows) < min_corpus:
            return None
        return rows[0]["span_count"]

    def get_failed_traces(
        self,
        task_name: Optional[str] = None,
        limit: int = 200,
    ) -> List[Dict[str, Any]]:
        """
        Return full task dicts for failed traces.
        Used by FailureMiner — deserialized from the JSON blob.
        """
        conditions = ["outcome IN ('failure', 'stuck_loop')"]
        params: List[Any] = []
        if task_name:
            conditions.append("name = ?")
            params.append(task_name)
        where = "WHERE " + " AND ".join(conditions)
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT blob FROM traces {where} ORDER BY start_time DESC LIMIT ?",
                params + [limit],
            ).fetchall()
        return [json.loads(r["blob"]) for r in rows]

    # ------------------------------------------------------------------
    # Analytics
    # ------------------------------------------------------------------

    def get_analytics(self) -> Dict[str, Any]:
        """Aggregate stats used by the dashboard analytics view."""
        with self._connect() as conn:

            summary = dict(conn.execute("""
                SELECT
                    COUNT(*)  AS total_tasks,
                    SUM(CASE WHEN outcome='success' THEN 1 ELSE 0 END) AS successful,
                    SUM(CASE WHEN outcome='failure' THEN 1 ELSE 0 END) AS failed,
                    AVG(latency_ms)   AS avg_latency_ms,
                    SUM(total_tokens) AS total_tokens,
                    AVG(total_tokens) AS avg_tokens_per_task
                FROM traces
            """).fetchone() or {})

            by_outcome = [dict(r) for r in conn.execute("""
                SELECT outcome, COUNT(*) AS count FROM traces GROUP BY outcome
            """).fetchall()]

            by_agent = [dict(r) for r in conn.execute("""
                SELECT agent_name,
                       COUNT(*)  AS count,
                       AVG(latency_ms)   AS avg_latency_ms,
                       SUM(total_tokens) AS total_tokens,
                       SUM(CASE WHEN outcome='success' THEN 1 ELSE 0 END) AS successful
                FROM traces
                WHERE agent_name IS NOT NULL
                GROUP BY agent_name
                ORDER BY count DESC
                LIMIT 10
            """).fetchall()]

            by_span_type = [dict(r) for r in conn.execute("""
                SELECT type,
                       COUNT(*) AS count,
                       AVG(latency_ms) AS avg_latency_ms,
                       SUM(tokens_in + tokens_out) AS total_tokens
                FROM spans
                GROUP BY type
                ORDER BY count DESC
            """).fetchall()]

            timeline = [dict(r) for r in conn.execute("""
                SELECT
                    date(start_time, 'unixepoch') AS day,
                    COUNT(*) AS total,
                    SUM(CASE WHEN outcome='success' THEN 1 ELSE 0 END) AS successful,
                    SUM(CASE WHEN outcome='failure' THEN 1 ELSE 0 END) AS failed
                FROM traces
                WHERE start_time >= unixepoch('now', '-30 days')
                GROUP BY day
                ORDER BY day
            """).fetchall()]

        return {
            "summary":      summary,
            "by_outcome":   by_outcome,
            "by_agent":     by_agent,
            "by_span_type": by_span_type,
            "timeline":     timeline,
        }
