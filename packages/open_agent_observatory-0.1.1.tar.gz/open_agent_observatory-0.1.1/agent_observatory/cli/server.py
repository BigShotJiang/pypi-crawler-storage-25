"""
Built-in HTTP server for the Observatory dashboard.

Serves:
  GET /                       → dashboard/index.html
  GET /api/traces             → JSON list of trace summaries
  GET /api/traces/<task_id>   → JSON full trace
  GET /api/analytics          → JSON analytics aggregate
  GET /api/diff/<id1>/<id2>   → JSON TraceDiff
  DELETE /api/traces/<id>     → delete a trace
"""
from __future__ import annotations

import json
import os
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import parse_qs, urlparse


def _json_response(handler: BaseHTTPRequestHandler, data: Any, status: int = 200) -> None:
    body = json.dumps(data, default=str).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.end_headers()
    handler.wfile.write(body)


def _html_response(handler: BaseHTTPRequestHandler, path: Path) -> None:
    content = path.read_bytes()
    handler.send_response(200)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Content-Length", str(len(content)))
    handler.end_headers()
    handler.wfile.write(content)


def _make_handler(store: Any, dashboard_path: Path) -> type:
    """Factory: return a handler class closed over `store` and `dashboard_path`."""

    class ObservatoryHandler(BaseHTTPRequestHandler):

        def log_message(self, format: str, *args: Any) -> None:  # suppress default logging
            pass

        def do_OPTIONS(self) -> None:
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, DELETE, OPTIONS")
            self.end_headers()

        def do_DELETE(self) -> None:
            parsed = urlparse(self.path)
            parts  = parsed.path.strip("/").split("/")
            if len(parts) == 2 and parts[0] == "api" and parts[1] == "traces":
                # /api/traces/<id>  — this is a 3-segment path, handle below
                pass  # falls through to 404

            if len(parts) == 3 and parts[0] == "api" and parts[1] == "traces":
                task_id = parts[2]
                deleted = store.delete_task(task_id)
                _json_response(self, {"deleted": deleted})
            else:
                _json_response(self, {"error": "Not found"}, 404)

        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            path   = parsed.path.rstrip("/") or "/"
            qs     = parse_qs(parsed.query)

            # Dashboard
            if path in ("/", "/index.html"):
                if dashboard_path.exists():
                    _html_response(self, dashboard_path)
                else:
                    _json_response(self, {"error": "Dashboard not found"}, 404)
                return

            parts = path.strip("/").split("/")

            # GET /api/traces
            if parts == ["api", "traces"]:
                limit  = int(qs.get("limit",  ["50"])[0])
                offset = int(qs.get("offset", ["0"])[0])
                agent  = qs.get("agent",  [None])[0]
                outcome= qs.get("outcome",[None])[0]
                model  = qs.get("model",  [None])[0]
                search = qs.get("search", [None])[0]
                tasks = store.list_tasks(
                    limit=limit, offset=offset, agent=agent,
                    outcome=outcome, model=model, search=search,
                )
                total = store.count_tasks(agent=agent, outcome=outcome)
                _json_response(self, {"tasks": tasks, "total": total, "limit": limit, "offset": offset})
                return

            # GET /api/traces/<id>
            if len(parts) == 3 and parts[:2] == ["api", "traces"]:
                task_id = parts[2]
                task = store.get_task(task_id)
                if task:
                    _json_response(self, task.to_dict())
                else:
                    _json_response(self, {"error": f"Trace {task_id!r} not found"}, 404)
                return

            # GET /api/analytics
            if parts == ["api", "analytics"]:
                _json_response(self, store.get_analytics())
                return

            # GET /api/diff/<id1>/<id2>
            if len(parts) == 4 and parts[:2] == ["api", "diff"]:
                id1, id2 = parts[2], parts[3]
                task_a = store.get_task(id1)
                task_b = store.get_task(id2)
                if not task_a:
                    _json_response(self, {"error": f"Trace {id1!r} not found"}, 404); return
                if not task_b:
                    _json_response(self, {"error": f"Trace {id2!r} not found"}, 404); return

                semantic = qs.get("semantic", ["true"])[0].lower() != "false"
                from agent_observatory.diff.engine import diff as compute_diff
                result = compute_diff(task_a, task_b, semantic=semantic)
                _json_response(self, result.to_dict())
                return

            # GET /api/analyze/failures
            if parts == ["api", "analyze", "failures"]:
                min_cluster = int(qs.get("min_cluster", ["2"])[0])
                from agent_observatory.analytics.failure_miner import FailureMiner
                miner  = FailureMiner(store)
                report = miner.mine(min_cluster_size=min_cluster)
                _json_response(self, report.to_dict())
                return

            _json_response(self, {"error": "Not found"}, 404)

    return ObservatoryHandler


class ObservatoryServer:
    """Wrapper around HTTPServer for clean start/stop."""

    def __init__(self, store: Any, port: int = 7421) -> None:
        self.store = store
        self.port  = port

        # Find the dashboard HTML
        here = Path(__file__).parent.parent
        self.dashboard_path = here / "dashboard" / "index.html"

        handler = _make_handler(store, self.dashboard_path)
        self._server = HTTPServer(("0.0.0.0", port), handler)
        self._thread: Optional[threading.Thread] = None

    def start(self, blocking: bool = True) -> None:
        if blocking:
            self._server.serve_forever()
        else:
            self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
            self._thread.start()

    def stop(self) -> None:
        self._server.shutdown()
