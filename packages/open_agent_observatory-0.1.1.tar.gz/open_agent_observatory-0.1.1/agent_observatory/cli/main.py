"""
Observatory CLI — main entrypoint.

All commands accessible via:
    observatory <command> [options]
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional

import click

from agent_observatory import tracer as _tracer


@click.group()
@click.version_option(version="0.1.0", package_name="agent-observatory")
def cli() -> None:
    """
    \b
      ░█████╗░██████╗░███████╗███████╗██████╗ ██╗   ██╗ █████╗ ████████╗ █████╗ ██████╗ ██╗   ██╗
      ██╔══██╗██╔══██╗██╔════╝██╔════╝██╔══██╗██║   ██║██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗╚██╗ ██╔╝
      ███████║██║  ██║█████╗  █████╗  ██████╔╝██║   ██║███████║   ██║   ██║  ██║██████╔╝ ╚████╔╝
      ██╔══██║██║  ██║██╔══╝  ██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══██║   ██║   ██║  ██║██╔══██╗  ╚██╔╝
      ██║  ██║██████╔╝██║     ███████╗██║  ██║ ╚████╔╝ ██║  ██║   ██║   ╚█████╔╝██║  ██║   ██║
      ╚═╝  ╚═╝╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝   ╚═╝    ╚════╝ ╚═╝  ╚═╝   ╚═╝

    The OpenTelemetry for AI agents. Trace, diff, and mine your agent runs.
    """


# ---------------------------------------------------------------------------
# observatory traces …
# ---------------------------------------------------------------------------

@cli.group()
def traces() -> None:
    """List, inspect, and export agent traces."""


@traces.command("list")
@click.option("--limit",  "-n", default=20,   help="Max traces to show.")
@click.option("--agent",  "-a", default=None, help="Filter by agent name.")
@click.option("--outcome","-o", default=None, type=click.Choice(["success","failure","partial","unknown"]))
@click.option("--model",  "-m", default=None, help="Filter by model name.")
@click.option("--search", "-s", default=None, help="Search across task names.")
@click.option("--db",          default=None,  help="Override DB path.")
def traces_list(limit, agent, outcome, model, search, db) -> None:
    """List recent agent traces."""
    _tracer.configure(db_path=db)
    store = _tracer.store
    tasks = store.list_tasks(
        limit=limit, agent=agent, outcome=outcome, model=model, search=search
    )
    total = store.count_tasks(agent=agent, outcome=outcome)

    if not tasks:
        click.echo("No traces found.")
        return

    # Header
    click.echo(
        f"\n{'TASK NAME':<35} {'AGENT':<15} {'MODEL':<18} {'OUTCOME':<10} "
        f"{'TOKENS':>8} {'LATENCY':>9} {'SPANS':>6}"
    )
    click.echo("─" * 105)

    outcome_colors = {
        "success": "green", "failure": "red", "partial": "yellow", "unknown": "white"
    }
    for t in tasks:
        oc    = t.get("outcome", "unknown")
        color = outcome_colors.get(oc, "white")
        lat   = t.get("latency_ms")
        lat_s = f"{lat/1000:.2f}s" if lat else "—"
        click.echo(
            f"{str(t.get('name',''))[:34]:<35} "
            f"{str(t.get('agent_name') or '—')[:14]:<15} "
            f"{str(t.get('model') or '—')[:17]:<18} "
            + click.style(f"{oc:<10}", fg=color) +
            f" {t.get('total_tokens', 0):>8,} {lat_s:>9} {t.get('span_count', 0):>6}"
        )

    click.echo(f"\n  Showing {len(tasks)} of {total} traces.\n")


@traces.command("show")
@click.argument("task_id")
@click.option("--format", "-f", "fmt",
              type=click.Choice(["tree", "json", "summary"]), default="tree")
@click.option("--db", default=None, help="Override DB path.")
def traces_show(task_id: str, fmt: str, db: Optional[str]) -> None:
    """Show a trace in detail."""
    _tracer.configure(db_path=db)
    task = _tracer.store.get_task(task_id)
    if not task:
        click.echo(click.style(f"Trace {task_id!r} not found.", fg="red"))
        sys.exit(1)

    if fmt == "json":
        click.echo(json.dumps(task.to_dict(), indent=2, default=str))
        return

    if fmt == "summary":
        d = task.to_summary_dict()
        for k, v in d.items():
            click.echo(f"  {k:<20} {v}")
        return

    # Tree view
    _print_tree(task)


def _print_tree(task) -> None:
    from agent_observatory.core.models import SpanType

    oc_color = {"success": "green", "failure": "red", "partial": "yellow"}.get(
        task.outcome.value, "white"
    )
    type_colors = {
        "reasoning":    "bright_blue",
        "tool_call":    "bright_yellow",
        "tool_response":"bright_green",
        "reflection":   "bright_magenta",
        "backtrack":    "bright_red",
        "planning":     "bright_cyan",
        "custom":       "white",
    }

    click.echo()
    click.echo(click.style(f"  Task: {task.name}", bold=True))
    click.echo(f"  ID:   {task.task_id}")
    click.echo(f"  Agent: {task.agent_name or '—'}   Model: {task.model or '—'}")
    click.echo(
        f"  Outcome: " + click.style(task.outcome.value, fg=oc_color) +
        f"   Tokens: {task.total_tokens:,}   Latency: "
        f"{task.latency_ms/1000:.2f}s" if task.latency_ms else "  Outcome: —"
    )
    click.echo()

    # Build tree
    by_id = {s.span_id: s for s in task.spans}
    children = {s.span_id: [] for s in task.spans}
    roots    = []
    for s in task.spans:
        if s.parent_id and s.parent_id in by_id:
            children[s.parent_id].append(s)
        else:
            roots.append(s)
    for lst in children.values():
        lst.sort(key=lambda s: s.start_time)

    def print_span(span, prefix="", is_last=True):
        connector = "└─ " if is_last else "├─ "
        color     = type_colors.get(span.type.value, "white")
        type_label = click.style(f"[{span.type.value}]", fg=color)
        lat   = f"{span.latency_ms:.0f}ms" if span.latency_ms else "—"
        tok   = f"{span.tokens.total}tok" if span.tokens.total else ""
        oc    = span.outcome.value
        oc_label = click.style(oc, fg={"success":"green","failure":"red"}.get(oc,"white"))
        click.echo(f"  {prefix}{connector}{type_label} {span.name}  {lat}  {tok}  {oc_label}")

        child_prefix = prefix + ("   " if is_last else "│  ")
        kids = children.get(span.span_id, [])
        for i, child in enumerate(kids):
            print_span(child, child_prefix, i == len(kids) - 1)

    for i, root in enumerate(roots):
        print_span(root, "", i == len(roots) - 1)
    click.echo()


@traces.command("export")
@click.argument("task_id")
@click.option("--format", "-f", "fmt",
              type=click.Choice(["json", "otlp"]), default="json")
@click.option("--output", "-o", default=None, help="Output file path (default: stdout).")
@click.option("--db",          default=None, help="Override DB path.")
def traces_export(task_id: str, fmt: str, output: Optional[str], db: Optional[str]) -> None:
    """Export a trace to JSON or OTLP format."""
    _tracer.configure(db_path=db)
    task = _tracer.store.get_task(task_id)
    if not task:
        click.echo(click.style(f"Trace {task_id!r} not found.", fg="red"))
        sys.exit(1)

    if fmt == "otlp":
        from agent_observatory.exporters.otlp import task_to_otlp
        data = json.dumps(task_to_otlp(task), indent=2, default=str)
    else:
        data = json.dumps(task.to_dict(), indent=2, default=str)

    if output:
        Path(output).write_text(data, encoding="utf-8")
        click.echo(f"Exported to {output}")
    else:
        click.echo(data)


@traces.command("delete")
@click.argument("task_id")
@click.option("--db", default=None)
def traces_delete(task_id: str, db: Optional[str]) -> None:
    """Delete a trace from the store."""
    _tracer.configure(db_path=db)
    deleted = _tracer.store.delete_task(task_id)
    if deleted:
        click.echo(click.style(f"Deleted trace {task_id}.", fg="green"))
    else:
        click.echo(click.style(f"Trace {task_id!r} not found.", fg="red"))


# ---------------------------------------------------------------------------
# observatory serve
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--port", "-p", default=7421, help="Port to serve on (default: 7421).")
@click.option("--db",         default=None, help="Override DB path.")
@click.option("--open/--no-open", default=True, help="Auto-open browser.")
def serve(port: int, db: Optional[str], open: bool) -> None:
    """Launch the local Observatory dashboard."""
    _tracer.configure(db_path=db)
    store = _tracer.store

    from agent_observatory.cli.server import ObservatoryServer
    server = ObservatoryServer(store=store, port=port)

    url = f"http://localhost:{port}"
    click.echo(click.style("\n  🔭 Agent Observatory", bold=True, fg="bright_cyan"))
    click.echo(f"  Dashboard → {url}")
    click.echo(f"  DB        → {store.db_path}")
    click.echo(f"  Press Ctrl+C to stop.\n")

    if open:
        import webbrowser
        webbrowser.open(url)

    try:
        server.start(blocking=True)
    except KeyboardInterrupt:
        click.echo("\n  Stopped.")


# ---------------------------------------------------------------------------
# observatory diff
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("task_id_a")
@click.argument("task_id_b")
@click.option("--semantic/--no-semantic", default=True,
              help="Use sentence-transformers for semantic similarity.")
@click.option("--threshold", "-t", default=0.75, help="Divergence threshold (0–1).")
@click.option("--db", default=None)
def diff(task_id_a: str, task_id_b: str, semantic: bool, threshold: float,
         db: Optional[str]) -> None:
    """Semantically diff two agent traces."""
    _tracer.configure(db_path=db)
    store = _tracer.store

    task_a = store.get_task(task_id_a)
    task_b = store.get_task(task_id_b)

    if not task_a:
        click.echo(click.style(f"Trace {task_id_a!r} not found.", fg="red")); sys.exit(1)
    if not task_b:
        click.echo(click.style(f"Trace {task_id_b!r} not found.", fg="red")); sys.exit(1)

    click.echo(f"\n  Diffing traces…")
    if semantic:
        click.echo(f"  Using semantic similarity (threshold={threshold})")

    from agent_observatory.diff.engine import diff as compute_diff
    result = compute_diff(task_a, task_b, semantic=semantic, divergence_threshold=threshold)

    s = result.summary
    click.echo(f"\n  A: {task_a.name}  [{task_a.outcome.value}]")
    click.echo(f"  B: {task_b.name}  [{task_b.outcome.value}]")
    click.echo()
    click.echo(click.style(f"  ✓ Matched:              {s['matched']}", fg="green"))
    click.echo(click.style(f"  ~ Semantic divergences: {s['semantic_divergences']}", fg="yellow"))
    click.echo(click.style(f"  ← Only in A:            {s['only_in_left']}", fg="cyan"))
    click.echo(click.style(f"  → Only in B:            {s['only_in_right']}", fg="magenta"))
    click.echo()

    if result.semantic_divergences:
        click.echo("  Semantic divergences:")
        for pair in result.semantic_divergences[:5]:
            click.echo(
                f"    [{pair.left.type.value}] {pair.left.name!r} "
                f"vs {pair.right.name!r}  sim={pair.similarity:.2f}"
            )
    if len(result.semantic_divergences) > 5:
        click.echo(f"    … and {len(result.semantic_divergences)-5} more.")


# ---------------------------------------------------------------------------
# observatory analyze
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--pattern", type=click.Choice(["failures"]), default="failures")
@click.option("--min-cluster", default=2, help="Min cluster size to report.")
@click.option("--db", default=None)
def analyze(pattern: str, min_cluster: int, db: Optional[str]) -> None:
    """Mine failure patterns across trace history."""
    _tracer.configure(db_path=db)
    click.echo(f"\n  Mining {pattern} patterns…\n")
    from agent_observatory.analytics.failure_miner import FailureMiner
    miner  = FailureMiner(_tracer.store)
    report = miner.mine(min_cluster_size=min_cluster)
    click.echo(str(report))


if __name__ == "__main__":
    cli()
