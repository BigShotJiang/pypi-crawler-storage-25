"""
agent_observatory.core.outcome
==============================
Richer outcome model for AgentTask.

Replaces the three-state TaskOutcome enum with a structured object that
carries enough signal for downstream consumers: diff scoring, failure
pattern mining, and regression baselines.

Usage (automatic — runs inside TaskContext.__exit__):
    rich = RichOutcome.compute(task)
    task.rich_outcome = rich
"""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Set

from agent_observatory.core.models import AgentSpan, AgentTask, SpanType, TaskOutcome

# ---------------------------------------------------------------------------
# Constants & Thresholds
# ---------------------------------------------------------------------------

LOOP_WINDOW_SIZE   = 12
LOOP_REPEAT_THRESH = 3     # how many identical hashes trigger a "stuck" flag
MIN_CORPUS_FOR_EFFICIENCY = 5  # minimum successful traces required for learned baseline


# ---------------------------------------------------------------------------
# HallucinationSignal
# ---------------------------------------------------------------------------


@dataclass
class HallucinationSignal:
    """A specific indicator that the agent may have fabricated information."""

    signal_type: Literal[
        "output_mismatch",       # tool arg value never appeared in any prior tool response
        "unregistered_tool_call",# agent called a tool not in its registered set
        "type_mismatch",         # arg type doesn't match the tool's declared signature
        "invented_entity",       # entity never appeared in the conversation context
    ]
    span_id: str
    detail: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signal_type": self.signal_type,
            "span_id":     self.span_id,
            "detail":      self.detail,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "HallucinationSignal":
        return cls(
            signal_type=d["signal_type"],
            span_id=d["span_id"],
            detail=d.get("detail", ""),
        )


# ---------------------------------------------------------------------------
# RichOutcome
# ---------------------------------------------------------------------------


@dataclass
class RichOutcome:
    """
    Structured outcome that goes beyond success/failure/exception.

    Computed automatically at the end of each TaskContext and stored
    alongside the standard TaskOutcome enum on AgentTask.
    """

    # Primary terminal state (superset of TaskOutcome)
    terminal_state: Literal[
        "success",
        "failure",
        "exception",
        "timeout",
        "stuck_loop",
    ]

    # Efficiency score: actual_steps / baseline_min_steps
    # None when insufficient data for the learned baseline and no declared min.
    efficiency_score:  Optional[float] = None
    efficiency_source: Literal["declared", "learned", "unavailable"] = "unavailable"

    # Redundant tool calls: tool names called 2+ times with identical args
    redundant_tool_calls: List[str] = field(default_factory=list)

    # Did the agent reverse a prior decision (backtrack span detected)?
    backtracked: bool = False

    # Did the agent hit a failure span but ultimately reach success?
    recovered_from_error: bool = False

    # Grounding / hallucination signals
    hallucination_signals: List[HallucinationSignal] = field(default_factory=list)

    # ---------------------------------------------------------------------------
    # Serialisation
    # ---------------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {
            "terminal_state":       self.terminal_state,
            "efficiency_score":     self.efficiency_score,
            "efficiency_source":    self.efficiency_source,
            "redundant_tool_calls": self.redundant_tool_calls,
            "backtracked":          self.backtracked,
            "recovered_from_error": self.recovered_from_error,
            "hallucination_signals": [h.to_dict() for h in self.hallucination_signals],
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "RichOutcome":
        return cls(
            terminal_state        = d.get("terminal_state", "unknown"),
            efficiency_score      = d.get("efficiency_score"),
            efficiency_source     = d.get("efficiency_source", "unavailable"),
            redundant_tool_calls  = d.get("redundant_tool_calls", []),
            backtracked           = d.get("backtracked", False),
            recovered_from_error  = d.get("recovered_from_error", False),
            hallucination_signals = [
                HallucinationSignal.from_dict(h)
                for h in d.get("hallucination_signals", [])
            ],
        )

    # ---------------------------------------------------------------------------
    # Factory — the main compute entry point
    # ---------------------------------------------------------------------------

    @classmethod
    def compute(
        cls,
        task: AgentTask,
        *,
        declared_min_steps: Optional[int] = None,
        learned_min_steps: Optional[int] = None,
        registered_tools: Optional[Set[str]] = None,
    ) -> "RichOutcome":
        """
        Analyse a finished AgentTask and produce a RichOutcome.

        Args:
            task:               The completed AgentTask.
            declared_min_steps: User-declared minimum steps for efficiency baseline.
                                From benchmark YAML or obs.task(..., min_steps=N).
            learned_min_steps:  Computed from historical successful traces.
                                Caller is responsible for querying the store.
            registered_tools:   Set of tool names the agent is allowed to call.
                                Used for unregistered-tool hallucination detection.
        """
        spans = task.spans

        # --- primary terminal state ---
        terminal_state = _determine_terminal_state(task, spans)

        # --- efficiency score ---
        efficiency_score, efficiency_source = _compute_efficiency(
            len(spans), declared_min_steps, learned_min_steps
        )

        # --- redundant tool calls ---
        redundant_tool_calls = _detect_redundant_calls(spans)

        # --- backtrack detection ---
        backtracked = any(s.type == SpanType.BACKTRACK for s in spans)

        # --- recovery detection ---
        had_failure  = any(s.outcome.value == "failure" for s in spans)
        task_success = task.outcome in (TaskOutcome.SUCCESS,)
        recovered_from_error = had_failure and task_success

        # --- hallucination signals ---
        hallucination_signals = _detect_hallucination_signals(
            spans, registered_tools=registered_tools, task_prompt=task.task_prompt
        )

        return cls(
            terminal_state        = terminal_state,
            efficiency_score      = efficiency_score,
            efficiency_source     = efficiency_source,
            redundant_tool_calls  = redundant_tool_calls,
            backtracked           = backtracked,
            recovered_from_error  = recovered_from_error,
            hallucination_signals = hallucination_signals,
        )


# ---------------------------------------------------------------------------
# Internal detectors
# ---------------------------------------------------------------------------


def _determine_terminal_state(
    task: AgentTask,
    spans: List[AgentSpan],
) -> str:
    """Map task.outcome + span analysis → enriched terminal state string."""
    if _detect_stuck_loop(spans):
        return "stuck_loop"
    if task.error and "Timeout" in (task.error or ""):
        return "timeout"
    ov = task.outcome.value
    if ov in ("success", "failure", "partial"):
        return ov
    if ov == "unknown" and task.error:
        return "exception"
    return ov  # in_progress / unknown fall through


def _span_hash(span: AgentSpan) -> str:
    """Stable hash of a span's essential content for loop detection."""
    payload = {
        "type":      span.type.value,
        "tool_name": span.tool_name or "",
        "tool_args": json.dumps(span.tool_args or {}, sort_keys=True),
    }
    return hashlib.sha256(json.dumps(payload).encode()).hexdigest()[:16]


def _detect_stuck_loop(spans: List[AgentSpan]) -> bool:
    """
    Sliding-window cycle detection.

    Flags True when any span-content hash repeats LOOP_REPEAT_THRESH times
    within a LOOP_WINDOW_SIZE rolling window.
    """
    if len(spans) < LOOP_WINDOW_SIZE:
        return False

    hashes = [_span_hash(s) for s in spans]

    for i in range(len(hashes) - LOOP_WINDOW_SIZE + 1):
        window = hashes[i : i + LOOP_WINDOW_SIZE]
        counts = Counter(window)
        if any(v >= LOOP_REPEAT_THRESH for v in counts.values()):
            return True

    return False


def _detect_redundant_calls(spans: List[AgentSpan]) -> List[str]:
    """
    Return tool names that were called 2+ times with *identical* arguments.
    """
    call_hashes: Counter = Counter()
    for span in spans:
        if span.type != SpanType.TOOL_CALL:
            continue
        h = hashlib.sha256(
            f"{span.tool_name}:{json.dumps(span.tool_args or {}, sort_keys=True)}"
            .encode()
        ).hexdigest()
        call_hashes[h] += 1

    # Map back hash → tool_name for readable output
    redundant: List[str] = []
    seen_hashes: set = set()
    for span in spans:
        if span.type != SpanType.TOOL_CALL:
            continue
        h = hashlib.sha256(
            f"{span.tool_name}:{json.dumps(span.tool_args or {}, sort_keys=True)}"
            .encode()
        ).hexdigest()
        if call_hashes[h] >= 2 and h not in seen_hashes:
            redundant.append(span.tool_name or "unknown")
            seen_hashes.add(h)

    return redundant


def _compute_efficiency(
    actual_steps: int,
    declared_min: Optional[int],
    learned_min: Optional[int],
) -> tuple[Optional[float], str]:
    """
    Returns (efficiency_score, source).

    Priority: declared > learned > unavailable.
    Score = actual_steps / baseline  (1.0 = perfect, >1.0 = more steps than needed).
    Capped at 5.0 to avoid exploding values on pathological traces.
    """
    baseline = declared_min or learned_min
    if baseline is None or baseline <= 0:
        return None, "unavailable"

    source = "declared" if declared_min else "learned"
    score  = round(min(actual_steps / baseline, 5.0), 3)
    return score, source


def _detect_hallucination_signals(
    spans: List[AgentSpan],
    registered_tools: Optional[Set[str]] = None,
    task_prompt: Optional[str] = None,
) -> List[HallucinationSignal]:
    """
    Multi-signal hallucination detector.

    Checks:
    1. unregistered_tool_call — tool name not in the registered set
    2. output_mismatch       — arg value never appeared in any prior tool response
    """
    signals: List[HallucinationSignal] = []
    prior_outputs: List[str] = []  # cumulative text of all tool responses so far
    
    if task_prompt:
        prior_outputs.append(task_prompt.lower())

    for span in spans:
        if span.type == SpanType.TOOL_RESPONSE and span.tool_result:
            prior_outputs.append(span.tool_result.lower())
            continue

        if span.type == SpanType.TOOL_CALL:
            # 1. Unregistered tool
            if registered_tools and span.tool_name and span.tool_name not in registered_tools:
                signals.append(HallucinationSignal(
                    signal_type="unregistered_tool_call",
                    span_id=span.span_id,
                    detail=f"Tool '{span.tool_name}' not in registered set: {registered_tools}",
                ))

            # 2. Output mismatch — check each arg string value against prior outputs
            if span.tool_args and prior_outputs:
                combined_prior = " ".join(prior_outputs)
                for arg_val in span.tool_args.values():
                    val_str = str(arg_val).lower().strip()
                    if len(val_str) > 4 and val_str not in combined_prior:
                        # Only flag if the value looks like a specific entity (not a number/bool)
                        if not val_str.replace(".", "").replace("-", "").isdigit():
                            signals.append(HallucinationSignal(
                                signal_type="output_mismatch",
                                span_id=span.span_id,
                                detail=f"Arg value '{val_str[:60]}' not found in any prior tool response.",
                            ))
                            break  # one signal per span is enough

    return signals
