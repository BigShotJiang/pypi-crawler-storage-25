"""
Agent Observatory tracer — the main instrumentation interface.

Three-line integration for any Python agent:

    from agent_observatory import tracer

    with tracer.task("Fix the login bug", agent="my-agent", model="gpt-4o") as task:
        with task.span("reasoning", name="Analyse the traceback") as s:
            s.record(prompt=..., response=..., tokens_in=450, tokens_out=120)
        with task.span("tool_call", name="run_pytest", tool="bash") as s:
            s.record_tool(args={"cmd": "pytest tests/"}, result="3 failed")

Works correctly with threading AND asyncio — context is propagated via
contextvars so nested spans wire up automatically even across await boundaries.
"""
from __future__ import annotations

import threading
import time
from contextvars import ContextVar, Token
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from agent_observatory.core.models import (
    AgentSpan,
    AgentTask,
    SpanOutcome,
    SpanType,
    TaskOutcome,
)

if TYPE_CHECKING:
    from agent_observatory.core.redaction import Scrubber
    from agent_observatory.exporters.base import SpanExporter
    from agent_observatory.store.sqlite_store import SQLiteStore

# ---------------------------------------------------------------------------
# Context variables — async-safe, thread-safe propagation
# ---------------------------------------------------------------------------

_ctx_task: ContextVar[Optional["TaskContext"]] = ContextVar("_ctx_task", default=None)
_ctx_span: ContextVar[Optional[AgentSpan]]     = ContextVar("_ctx_span", default=None)


# ---------------------------------------------------------------------------
# SpanContext  (the 'with task.span(...)' handle)
# ---------------------------------------------------------------------------


class SpanContext:
    """
    Context manager that wraps an AgentSpan.

    On entry: pushes itself onto the context-var stack so that nested
              task.span() calls can find their parent automatically.
    On exit:  finalises timing, records exceptions, pops the stack.
    """

    def __init__(self, span: AgentSpan, task_ctx: "TaskContext") -> None:
        self._span     = span
        self._task_ctx = task_ctx
        self._token:   Optional[Token] = None

    # ---- context protocol ------------------------------------------------

    def __enter__(self) -> AgentSpan:
        self._token = _ctx_span.set(self._span)
        return self._span

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Record exception if one bubbled up
        if exc_type is not None:
            self._span.outcome = SpanOutcome.FAILURE
            self._span.error   = f"{exc_type.__name__}: {exc_val}"

        # Finalise timing
        if not self._span.is_finished:
            self._span.end_time = time.time()
            if self._span.outcome == SpanOutcome.UNKNOWN:
                self._span.outcome = SpanOutcome.SUCCESS

        # Restore previous span context
        if self._token is not None:
            _ctx_span.reset(self._token)

        # Do NOT suppress exceptions
        return False

    # ---- async support ---------------------------------------------------

    async def __aenter__(self) -> AgentSpan:
        return self.__enter__()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        return self.__exit__(exc_type, exc_val, exc_tb)


# ---------------------------------------------------------------------------
# TaskContext  (the 'with tracer.task(...)' handle)
# ---------------------------------------------------------------------------


class TaskContext:
    """
    Context manager that wraps an AgentTask.

    Exposes .span() to create child spans, and automatically persists the
    completed task to the configured store on exit.
    """

    def __init__(self, task: AgentTask, tracer: "GlobalTracer") -> None:
        self._task   = task
        self._tracer = tracer
        self._token: Optional[Token] = None
        self._lock   = threading.Lock()

    # ---- context protocol ------------------------------------------------

    def __enter__(self) -> "TaskContext":
        self._token = _ctx_task.set(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self._task.outcome = TaskOutcome.FAILURE
            self._task.error   = f"{exc_type.__name__}: {exc_val}"

        if not self._task.is_finished:
            self._task.end_time = time.time()
            if self._task.outcome == TaskOutcome.IN_PROGRESS:
                self._task.outcome = TaskOutcome.SUCCESS

        # ── Compute rich outcome ──────────────────────────────────────
        try:
            from agent_observatory.core.outcome import RichOutcome
            # Query learned baseline from store if available
            learned_min = None
            if self._tracer._store and self._task.name:
                try:
                    learned_min = self._tracer._store.get_min_successful_steps(
                        group_key=self._task.agent_name or self._task.name,
                        group_type="agent_name" if self._task.agent_name else "name",
                    )
                except Exception:
                    pass
            self._task.rich_outcome = RichOutcome.compute(
                self._task,
                declared_min_steps=self._task.metadata.get("min_steps"),
                learned_min_steps=learned_min,
            )
            # Promote stuck_loop state to task outcome
            if self._task.rich_outcome.terminal_state == "stuck_loop":
                self._task.outcome = TaskOutcome.STUCK_LOOP
        except Exception:
            pass  # rich outcome is optional — never crash the main path

        # ── Auto-version if not already set ──────────────────────────
        if not self._task.agent_version:
            try:
                self._task.agent_version = self._task.compute_version()
            except Exception:
                pass

        if self._token is not None:
            _ctx_task.reset(self._token)

        self._tracer._on_task_finished(self._task)
        return False

    async def __aenter__(self) -> "TaskContext":
        return self.__enter__()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        return self.__exit__(exc_type, exc_val, exc_tb)

    # ---- span factory ----------------------------------------------------

    def span(
        self,
        type: str,
        *,
        name: str = "",
        tool: Optional[str] = None,
        model: Optional[str] = None,
        **metadata: Any,
    ) -> SpanContext:
        """
        Create a child span within this task.

        The current context span (from a surrounding `with task.span()`) is
        automatically used as parent — no manual wiring needed.

        Args:
            type:     SpanType string ("reasoning", "tool_call", …)
            name:     Human-readable label shown in the dashboard
            tool:     Tool name (for type="tool_call")
            model:    Override the model for this span
            **metadata: Arbitrary key/value pairs stored in span.metadata
        """
        try:
            span_type = SpanType(type)
        except ValueError:
            span_type = SpanType.CUSTOM

        parent_span = _ctx_span.get()

        span = AgentSpan(
            task_id   = self._task.task_id,
            trace_id  = self._task.trace_id,
            type      = span_type,
            name      = name or type,
            parent_id = parent_span.span_id if parent_span else None,
            model     = model or self._task.model,
            tool_name = tool,
            metadata  = dict(metadata),
        )

        with self._lock:
            self._task.spans.append(span)

        return SpanContext(span, self)

    # ---- direct access ---------------------------------------------------

    @property
    def task(self) -> AgentTask:
        return self._task

    def finish(self, outcome: TaskOutcome = TaskOutcome.SUCCESS) -> None:
        """Manually finish the task (use when not using 'with' statement)."""
        self._task.finish(outcome)
        self._tracer._on_task_finished(self._task)


# ---------------------------------------------------------------------------
# GlobalTracer  (the singleton imported as `tracer`)
# ---------------------------------------------------------------------------


class GlobalTracer:
    """
    Global tracer singleton.

    Configured once at startup; then used throughout the codebase.

    Example:
        from agent_observatory import tracer
        tracer.configure(db_path="./my_project.db")

        with tracer.task("Fix the login bug", agent="openhands") as task:
            with task.span("reasoning", name="Analyse error") as s:
                s.record(prompt=..., response=..., tokens_in=500, tokens_out=150)
    """

    def __init__(self) -> None:
        self._store:      Optional["SQLiteStore"] = None
        self._exporters:  List["SpanExporter"]    = []
        self._scrubber:   Optional["Scrubber"]    = None
        self._configured: bool                    = False
        self._lock = threading.Lock()

    # ---- configuration ---------------------------------------------------

    def configure(
        self,
        *,
        store: Optional["SQLiteStore"] = None,
        exporters: Optional[List["SpanExporter"]] = None,
        db_path: Optional[str] = None,
        auto_store: bool = True,
        scrubber: Optional["Scrubber"] = None,
        redaction: Optional["Scrubber"] = None,   # alias for scrubber
    ) -> "GlobalTracer":
        """
        Configure the global tracer. Safe to call multiple times.

        Args:
            store:      A pre-built SQLiteStore (or compatible store).
            exporters:  List of SpanExporter instances (OTLP, JSON, etc.).
            db_path:    Path to the SQLite DB file.  If omitted, defaults to
                        ~/.observatory/traces.db
            auto_store: Automatically create a SQLiteStore if none provided.
            scrubber:   A Scrubber instance for PII redaction before storage.
                        Use redaction= as an alias.
        """
        with self._lock:
            if store:
                self._store = store
            elif auto_store:
                from agent_observatory.store.sqlite_store import SQLiteStore
                self._store = SQLiteStore(db_path=db_path)

            if exporters:
                self._exporters = list(exporters)

            # scrubber / redaction kwarg (alias)
            chosen_scrubber = scrubber or redaction
            if chosen_scrubber is not None:
                self._scrubber = chosen_scrubber

            self._configured = True

        return self

    def _ensure_configured(self) -> None:
        if not self._configured:
            self.configure()  # lazy auto-config with defaults

    # ---- task factory ----------------------------------------------------

    def task(
        self,
        name: str,
        *,
        agent: Optional[str] = None,
        model: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
        parent_trace_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        **metadata: Any,
    ) -> TaskContext:
        """
        Start a new task trace and return a TaskContext.

        Intended to be used as a context manager:
            with tracer.task("scaffold app", agent="gpt-engineer") as task:
                ...
        """
        self._ensure_configured()

        # In-process automatic context link if omitted but currently inside a span/task
        if parent_trace_id is None:
            curr_task = self.current_task()
            if curr_task:
                parent_trace_id = curr_task.task_id
                curr_span = self.current_span()
                if curr_span and parent_span_id is None:
                    parent_span_id = curr_span.span_id

        task = AgentTask(
            name            = name,
            description     = description,
            agent_name      = agent,
            model           = model,
            tags            = list(tags or []),
            parent_trace_id = parent_trace_id,
            parent_span_id  = parent_span_id,
            metadata        = dict(metadata),
        )

        return TaskContext(task, self)

    # ---- internal --------------------------------------------------------

    def _on_task_finished(self, task: AgentTask) -> None:
        """Persist and export a finished task. Called by TaskContext on exit."""
        if self._store:
            try:
                self._store.save_task(task, scrubber=self._scrubber)
            except Exception as exc:
                print(f"[observatory] store.save_task failed: {exc}")

        for exporter in self._exporters:
            try:
                exporter.export(task)
            except Exception as exc:
                print(f"[observatory] exporter {exporter.__class__.__name__} failed: {exc}")

    # ---- helpers ---------------------------------------------------------

    @property
    def store(self) -> Optional["SQLiteStore"]:
        self._ensure_configured()
        return self._store

    def current_task(self) -> Optional[AgentTask]:
        """Return the AgentTask currently being traced (if any)."""
        ctx = _ctx_task.get()
        return ctx._task if ctx else None

    def current_span(self) -> Optional[AgentSpan]:
        """Return the innermost active AgentSpan (if any)."""
        return _ctx_span.get()
