"""
Agent Observatory — The OpenTelemetry for AI Agents.

Canonical data model for traces. Every concept flows through these classes.

Hierarchy:
    AgentTask  — one "run" of an agent (e.g. "Fix the login bug")
    ├── AgentSpan  — one unit of cognitive work (reasoning, tool_call, …)
    │   └── AgentSpan  — child spans (nested tool responses, sub-steps, …)
    └── …

Usage:
    data = AgentTask(name="Fix login bug", agent_name="my-agent")
    span = AgentSpan(task_id=data.task_id, type=SpanType.REASONING, name="Analyze error")
"""
from __future__ import annotations

import hashlib
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from agent_observatory.core.outcome import RichOutcome


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class SpanType(str, Enum):
    """The type of cognitive work a span represents."""
    REASONING    = "reasoning"
    TOOL_CALL    = "tool_call"
    TOOL_RESPONSE = "tool_response"
    REFLECTION   = "reflection"
    BACKTRACK    = "backtrack"
    PLANNING     = "planning"
    CUSTOM       = "custom"


class SpanOutcome(str, Enum):
    """Terminal state of a span."""
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"
    SKIPPED = "skipped"
    UNKNOWN = "unknown"


class TaskOutcome(str, Enum):
    """Terminal state of a full task."""
    SUCCESS     = "success"
    FAILURE     = "failure"
    PARTIAL     = "partial"
    IN_PROGRESS = "in_progress"
    UNKNOWN     = "unknown"
    STUCK_LOOP  = "stuck_loop"
    TIMEOUT     = "timeout"


# ---------------------------------------------------------------------------
# Token usage
# ---------------------------------------------------------------------------


@dataclass
class TokenUsage:
    """Token consumption for one model call."""
    tokens_in:  int = 0
    tokens_out: int = 0

    @property
    def total(self) -> int:
        return self.tokens_in + self.tokens_out

    def __add__(self, other: "TokenUsage") -> "TokenUsage":
        return TokenUsage(
            tokens_in=self.tokens_in + other.tokens_in,
            tokens_out=self.tokens_out + other.tokens_out,
        )

    def to_dict(self) -> Dict[str, int]:
        return {"tokens_in": self.tokens_in, "tokens_out": self.tokens_out, "total": self.total}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "TokenUsage":
        return cls(tokens_in=d.get("tokens_in", 0), tokens_out=d.get("tokens_out", 0))


# ---------------------------------------------------------------------------
# AgentSpan
# ---------------------------------------------------------------------------


@dataclass
class AgentSpan:
    """
    One discrete, measurable unit of cognitive work inside an agent run.

    A span is analogous to an OpenTelemetry Span but enriched with
    agent-specific fields: prompt/response, token counts, tool args/result,
    and a semantic `type` that classifies the kind of cognitive work.
    """

    # Identity
    span_id:   str = field(default_factory=lambda: str(uuid.uuid4()))
    parent_id: Optional[str] = None
    task_id:   str = ""
    trace_id:  str = ""

    # Classification
    type: SpanType = SpanType.CUSTOM
    name: str = ""

    # Timing (Unix epoch seconds, float precision)
    start_time: float = field(default_factory=time.time)
    end_time:   Optional[float] = None

    # Model interaction
    model:    Optional[str] = None
    prompt:   Optional[str] = None
    response: Optional[str] = None
    tokens:   TokenUsage = field(default_factory=TokenUsage)

    # Tool call fields (populated when type == TOOL_CALL / TOOL_RESPONSE)
    tool_name:   Optional[str] = None
    tool_args:   Optional[Dict[str, Any]] = None
    tool_result: Optional[str] = None

    # Outcome
    outcome: SpanOutcome = SpanOutcome.UNKNOWN
    error:   Optional[str] = None

    # Framework / integration metadata (e.g. crew_name, node_name, agent_role)
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Child spans (populated when building the tree from a flat list)
    children: List["AgentSpan"] = field(default_factory=list)

    # ------------------------------------------------------------------
    # Computed properties
    # ------------------------------------------------------------------

    @property
    def latency_ms(self) -> Optional[float]:
        if self.end_time is not None and self.start_time is not None:
            return round((self.end_time - self.start_time) * 1000, 3)
        return None

    @property
    def is_finished(self) -> bool:
        return self.end_time is not None

    # ------------------------------------------------------------------
    # Fluent builder helpers
    # ------------------------------------------------------------------

    def record(
        self,
        *,
        prompt: Optional[str] = None,
        response: Optional[str] = None,
        tokens_in: int = 0,
        tokens_out: int = 0,
        model: Optional[str] = None,
        outcome: SpanOutcome = SpanOutcome.SUCCESS,
        **metadata: Any,
    ) -> "AgentSpan":
        """Record a model interaction on this span. Returns self for chaining."""
        if prompt   is not None: self.prompt   = prompt
        if response is not None: self.response = response
        if model    is not None: self.model    = model
        self.tokens.tokens_in  += tokens_in
        self.tokens.tokens_out += tokens_out
        self.outcome = outcome
        self.metadata.update(metadata)
        return self

    def record_tool(
        self,
        *,
        args: Optional[Dict[str, Any]] = None,
        result: Optional[str] = None,
        outcome: SpanOutcome = SpanOutcome.SUCCESS,
        **metadata: Any,
    ) -> "AgentSpan":
        """Record a tool invocation on this span. Returns self for chaining."""
        if args   is not None: self.tool_args   = args
        if result is not None: self.tool_result = result
        self.outcome = outcome
        self.metadata.update(metadata)
        return self

    def finish(self, outcome: Optional[SpanOutcome] = None) -> "AgentSpan":
        """Mark span as finished, setting end_time and optional outcome."""
        self.end_time = time.time()
        if outcome is not None:
            self.outcome = outcome
        elif self.outcome == SpanOutcome.UNKNOWN:
            self.outcome = SpanOutcome.SUCCESS
        return self

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {
            "span_id":     self.span_id,
            "parent_id":   self.parent_id,
            "task_id":     self.task_id,
            "trace_id":    self.trace_id,
            "type":        self.type.value,
            "name":        self.name,
            "start_time":  self.start_time,
            "end_time":    self.end_time,
            "latency_ms":  self.latency_ms,
            "model":       self.model,
            "prompt":      self.prompt,
            "response":    self.response,
            "tokens":      self.tokens.to_dict(),
            "tool_name":   self.tool_name,
            "tool_args":   self.tool_args,
            "tool_result": self.tool_result,
            "outcome":     self.outcome.value,
            "error":       self.error,
            "metadata":    self.metadata,
            "children":    [c.to_dict() for c in self.children],
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AgentSpan":
        span = cls(
            span_id    = d.get("span_id",   str(uuid.uuid4())),
            parent_id  = d.get("parent_id"),
            task_id    = d.get("task_id",   ""),
            trace_id   = d.get("trace_id",  ""),
            type       = SpanType(d.get("type", "custom")),
            name       = d.get("name", ""),
            start_time = d.get("start_time", time.time()),
            end_time   = d.get("end_time"),
            model      = d.get("model"),
            prompt     = d.get("prompt"),
            response   = d.get("response"),
            tokens     = TokenUsage.from_dict(d.get("tokens", {})),
            tool_name  = d.get("tool_name"),
            tool_args  = d.get("tool_args"),
            tool_result= d.get("tool_result"),
            outcome    = SpanOutcome(d.get("outcome", "unknown")),
            error      = d.get("error"),
            metadata   = d.get("metadata", {}),
        )
        span.children = [cls.from_dict(c) for c in d.get("children", [])]
        return span


# ---------------------------------------------------------------------------
# AgentTask
# ---------------------------------------------------------------------------


@dataclass
class AgentTask:
    """
    Root container for a complete agent execution trace.

    A task is the top-level unit: "Fix the login bug", "Scaffold a React app".
    It contains a flat list of AgentSpan objects (hierarchy is encoded via
    parent_id). Call `to_dict()` to get the full JSON-LD export.
    """

    task_id:     str = field(default_factory=lambda: str(uuid.uuid4()))
    trace_id:    str = field(default_factory=lambda: str(uuid.uuid4()))

    name:        str = ""
    description: Optional[str] = None
    agent_name:  Optional[str] = None
    model:       Optional[str] = None
    tags:        List[str] = field(default_factory=list)

    start_time:  float = field(default_factory=time.time)
    end_time:    Optional[float] = None

    outcome:     TaskOutcome = TaskOutcome.IN_PROGRESS
    error:       Optional[str] = None

    # All spans in insertion order (flat; hierarchy reconstructed via parent_id)
    spans:       List[AgentSpan] = field(default_factory=list)

    # Framework-level metadata (e.g. {"framework": "crewai", "crew_name": "..."})
    metadata:    Dict[str, Any] = field(default_factory=dict)

    # ── v0.2: Richer outcome (computed post-run) ─────────────────────────────
    rich_outcome: Optional["RichOutcome"] = None

    # ── v0.4: Multi-agent correlation ────────────────────────────────────────
    parent_trace_id: Optional[str] = None  # task_id of the spawning agent
    parent_span_id:  Optional[str] = None  # span_id of the handoff call

    # ── v0.5: Replay readiness — capture at task creation ────────────────────
    task_prompt:   Optional[str] = None   # original user prompt
    model_config:  Optional[Dict[str, Any]] = None  # {"model_id": ..., "temperature": ...}
    tool_registry: Optional[List[str]] = None       # registered tool names
    agent_config:  Optional[Dict[str, Any]] = None  # {"system_prompt": ..., "agent_name": ...}

    # ── v0.7: Agent versioning ────────────────────────────────────────────────
    agent_version: Optional[str] = None  # auto-hash of (system_prompt + model + tools)

    # ------------------------------------------------------------------
    # Computed properties
    # ------------------------------------------------------------------

    @property
    def latency_ms(self) -> Optional[float]:
        if self.end_time and self.start_time:
            return round((self.end_time - self.start_time) * 1000, 3)
        return None

    @property
    def total_tokens(self) -> int:
        return sum(s.tokens.total for s in self.spans)

    @property
    def total_tokens_in(self) -> int:
        return sum(s.tokens.tokens_in for s in self.spans)

    @property
    def total_tokens_out(self) -> int:
        return sum(s.tokens.tokens_out for s in self.spans)

    @property
    def span_count(self) -> int:
        return len(self.spans)

    @property
    def is_finished(self) -> bool:
        return self.end_time is not None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def finish(self, outcome: TaskOutcome = TaskOutcome.SUCCESS) -> "AgentTask":
        self.end_time = time.time()
        self.outcome  = outcome
        return self

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def compute_version(self) -> str:
        """Auto-compute an 8-char version hash from model + agent_config + tool_registry."""
        payload = (
            str(self.model or "")
            + str((self.agent_config or {}).get("system_prompt", ""))
            + str(sorted(self.tool_registry or []))
        )
        return hashlib.sha256(payload.encode()).hexdigest()[:8]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "@context":       "https://agent-observatory.dev/schema/v1",
            "schema_version": "0.2",
            "task_id":        self.task_id,
            "trace_id":       self.trace_id,
            "name":           self.name,
            "description":    self.description,
            "agent_name":     self.agent_name,
            "model":          self.model,
            "agent_version":  self.agent_version,
            "tags":           self.tags,
            "start_time":     self.start_time,
            "end_time":       self.end_time,
            "latency_ms":     self.latency_ms,
            "outcome":        self.outcome.value,
            "error":          self.error,
            "spans":          [s.to_dict() for s in self.spans],
            "metadata":       self.metadata,
            # Multi-agent correlation
            "parent_trace_id": self.parent_trace_id,
            "parent_span_id":  self.parent_span_id,
            # Replay readiness
            "task_prompt":    self.task_prompt,
            "model_config":   self.model_config,
            "tool_registry":  self.tool_registry,
            "agent_config":   self.agent_config,
            # Rich outcome
            "rich_outcome":   self.rich_outcome.to_dict() if self.rich_outcome else None,
            "summary": {
                "total_tokens":     self.total_tokens,
                "total_tokens_in":  self.total_tokens_in,
                "total_tokens_out": self.total_tokens_out,
                "span_count":       self.span_count,
                # Rich outcome summary fields for quick dashboard display
                "terminal_state":          self.rich_outcome.terminal_state if self.rich_outcome else self.outcome.value,
                "efficiency_score":        self.rich_outcome.efficiency_score if self.rich_outcome else None,
                "redundant_tool_calls":    self.rich_outcome.redundant_tool_calls if self.rich_outcome else [],
                "backtracked":             self.rich_outcome.backtracked if self.rich_outcome else False,
                "hallucination_count":     len(self.rich_outcome.hallucination_signals) if self.rich_outcome else 0,
            },
        }

    def to_summary_dict(self) -> Dict[str, Any]:
        """Lightweight summary for list views — no span blobs."""
        return {
            "task_id":      self.task_id,
            "trace_id":     self.trace_id,
            "name":         self.name,
            "agent_name":   self.agent_name,
            "model":        self.model,
            "tags":         self.tags,
            "start_time":   self.start_time,
            "end_time":     self.end_time,
            "latency_ms":   self.latency_ms,
            "outcome":      self.outcome.value,
            "total_tokens": self.total_tokens,
            "span_count":   self.span_count,
            "metadata":     self.metadata,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AgentTask":
        from agent_observatory.core.outcome import RichOutcome as _RichOutcome
        task = cls(
            task_id          = d.get("task_id",   str(uuid.uuid4())),
            trace_id         = d.get("trace_id",  str(uuid.uuid4())),
            name             = d.get("name", ""),
            description      = d.get("description"),
            agent_name       = d.get("agent_name"),
            model            = d.get("model"),
            agent_version    = d.get("agent_version"),
            tags             = d.get("tags", []),
            start_time       = d.get("start_time", time.time()),
            end_time         = d.get("end_time"),
            outcome          = TaskOutcome(d.get("outcome", "unknown")),
            error            = d.get("error"),
            metadata         = d.get("metadata", {}),
            parent_trace_id  = d.get("parent_trace_id"),
            parent_span_id   = d.get("parent_span_id"),
            task_prompt      = d.get("task_prompt"),
            model_config     = d.get("model_config"),
            tool_registry    = d.get("tool_registry"),
            agent_config     = d.get("agent_config"),
        )
        task.spans = [AgentSpan.from_dict(s) for s in d.get("spans", [])]
        ro = d.get("rich_outcome")
        if ro:
            task.rich_outcome = _RichOutcome.from_dict(ro)
        return task
