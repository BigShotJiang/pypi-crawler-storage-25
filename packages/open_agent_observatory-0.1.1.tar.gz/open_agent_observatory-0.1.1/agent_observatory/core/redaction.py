"""
agent_observatory.core.redaction
=================================
Pluggable PII / sensitive-data scrubber.

Runs as a final pass in SQLiteStore.save_task() — the persisted blob is
scrubbed, but the in-memory AgentTask is never mutated.

Usage in obs.instrument():
    obs.instrument(
        redaction=obs.redaction.RegexScrubber(patterns=[r"sk-[a-zA-Z0-9]{32,}"])
    )

Or from obs.configure():
    tracer.configure(redaction=my_scrubber)
"""
from __future__ import annotations

import copy
import re
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, Pattern


# ---------------------------------------------------------------------------
# Base interface
# ---------------------------------------------------------------------------


class Scrubber(ABC):
    """Abstract base class for all scrubbers."""

    @abstractmethod
    def scrub(self, text: str) -> str:
        """Replace sensitive content in a string. Return the scrubbed string."""
        ...

    def scrub_dict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Deep-copy a dict and scrub all string values.
        Called by the store on the serialised JSON blob before writing.
        """
        return _scrub_deep(copy.deepcopy(data), self.scrub)


# ---------------------------------------------------------------------------
# Built-in Scrubbers
# ---------------------------------------------------------------------------


# Default patterns — conservative set; should not break agent responses
_DEFAULT_PATTERNS: List[str] = [
    r"sk-[a-zA-Z0-9\-_]{20,}",              # OpenAI / generic API keys
    r"AIza[0-9A-Za-z\-_]{35}",              # Google API keys
    r"Bearer\s+[A-Za-z0-9\-._~+/]+=*",     # Bearer tokens
    r"\b[A-Z]{2}[0-9]{6,9}\b",              # Passport numbers (rough heuristic)
    r"\b\d{3}-\d{2}-\d{4}\b",               # US SSNs
    r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b",  # Credit card numbers
]

_REDACT_PLACEHOLDER = "[REDACTED]"


class RegexScrubber(Scrubber):
    """
    Scrubs text matching any of the provided regex patterns.

    Args:
        patterns:    List of regex pattern strings to redact.
        placeholder: Replacement text (default: '[REDACTED]').
        include_defaults: If True, also apply the built-in default patterns
                          (API keys, SSNs, etc.).
    """

    def __init__(
        self,
        patterns: Optional[List[str]] = None,
        placeholder: str = _REDACT_PLACEHOLDER,
        include_defaults: bool = True,
    ) -> None:
        compiled: List[Pattern] = []
        all_patterns = list(_DEFAULT_PATTERNS if include_defaults else [])
        if patterns:
            all_patterns.extend(patterns)
        for p in all_patterns:
            try:
                compiled.append(re.compile(p))
            except re.error:
                pass  # silently skip bad patterns
        self._patterns    = compiled
        self._placeholder = placeholder

    def scrub(self, text: str) -> str:
        for pattern in self._patterns:
            text = pattern.sub(self._placeholder, text)
        return text


class HookScrubber(Scrubber):
    """
    Delegates to a user-supplied callable.

    Args:
        fn: A function (str) -> str that performs the redaction.
    """

    def __init__(self, fn: Callable[[str], str]) -> None:
        self._fn = fn

    def scrub(self, text: str) -> str:
        return self._fn(text)


class EntityScrubber(Scrubber):
    """
    Redacts named entities using spaCy NER.

    Requires: pip install spacy && python -m spacy download en_core_web_sm

    Args:
        entities:   List of entity types to redact (e.g. ['PERSON', 'ORG']).
        placeholder: Replacement text.
    """

    def __init__(
        self,
        entities: Optional[List[str]] = None,
        placeholder: str = _REDACT_PLACEHOLDER,
    ) -> None:
        self._entities    = set(entities or ["PERSON", "GPE", "LOC"])
        self._placeholder = placeholder
        self._nlp         = None  # lazy-loaded

    def _load_nlp(self):
        if self._nlp is None:
            try:
                import spacy
                self._nlp = spacy.load("en_core_web_sm")
            except (ImportError, OSError) as e:
                raise RuntimeError(
                    "EntityScrubber requires spaCy: "
                    "pip install spacy && python -m spacy download en_core_web_sm"
                ) from e
        return self._nlp

    def scrub(self, text: str) -> str:
        nlp = self._load_nlp()
        doc = nlp(text)
        result = text
        # Replace from right-to-left so offsets don't shift
        for ent in reversed(doc.ents):
            if ent.label_ in self._entities:
                result = result[: ent.start_char] + self._placeholder + result[ent.end_char :]
        return result


class CompositeScrubber(Scrubber):
    """Chains multiple scrubbers in sequence."""

    def __init__(self, scrubbers: List[Scrubber]) -> None:
        self._scrubbers = scrubbers

    def scrub(self, text: str) -> str:
        for s in self._scrubbers:
            text = s.scrub(text)
        return text


# ---------------------------------------------------------------------------
# Helper: deep-scrub a JSON-serialisable structure
# ---------------------------------------------------------------------------


def _scrub_deep(obj: Any, fn: Callable[[str], str]) -> Any:
    """Recursively apply fn to all string leaf values in a JSON structure."""
    if isinstance(obj, str):
        return fn(obj)
    if isinstance(obj, dict):
        return {k: _scrub_deep(v, fn) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_scrub_deep(item, fn) for item in obj]
    return obj  # int, float, bool, None — pass through unchanged


# ---------------------------------------------------------------------------
# Convenience factory used in obs.instrument()
# ---------------------------------------------------------------------------

_DEFAULT_SCRUBBER: Optional[Scrubber] = None


def default_scrubber() -> Scrubber:
    """Return a RegexScrubber with all default patterns."""
    return RegexScrubber(patterns=None, include_defaults=True)
