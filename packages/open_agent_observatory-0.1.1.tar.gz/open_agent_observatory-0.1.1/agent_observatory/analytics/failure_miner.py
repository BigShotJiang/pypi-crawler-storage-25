"""
Failure pattern miner.

Given a corpus of traces, clusters failure traces by their span-type sequence
and surfaces the common decision point where failures diverge from successes.

Usage:
    from agent_observatory.analytics.failure_miner import FailureMiner
    from agent_observatory.store.sqlite_store import SQLiteStore

    store  = SQLiteStore()
    miner  = FailureMiner(store)
    report = miner.mine(min_cluster_size=3)
    print(report)
"""
from __future__ import annotations

import difflib
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from agent_observatory.core.models import AgentTask, TaskOutcome


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class FailureCluster:
    """A group of failure traces sharing a common span-type sequence prefix."""
    cluster_id:    int
    size:          int
    common_prefix: List[str]          # span type sequence prefix
    task_ids:      List[str] = field(default_factory=list)
    divergence_point: Optional[int]   = None  # index in common_prefix where paths fork
    lift:          float = 0.0          # (fail_freq / succ_freq)

@dataclass
class FailureMiningReport:
    """Complete failure mining result for a corpus of traces."""
    total_traces:    int
    failure_traces:  int
    success_traces:  int
    failure_rate:    float
    clusters:        List[FailureCluster] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_traces":   self.total_traces,
            "failure_traces": self.failure_traces,
            "success_traces": self.success_traces,
            "failure_rate":   round(self.failure_rate, 4),
            "clusters": [
                {
                    "cluster_id":       c.cluster_id,
                    "size":             c.size,
                    "common_prefix":    c.common_prefix,
                    "task_ids":         c.task_ids,
                    "divergence_point": c.divergence_point,
                    "lift":             round(c.lift, 2),
                }
                for c in self.clusters
            ],
        }

    def __str__(self) -> str:
        lines = [
            "═" * 60,
            "  FAILURE PATTERN MINING REPORT",
            "═" * 60,
            f"  Total traces:   {self.total_traces}",
            f"  Failures:       {self.failure_traces}  ({self.failure_rate:.1%})",
            f"  Successes:      {self.success_traces}",
            f"  Clusters found: {len(self.clusters)}",
            "",
        ]
        for c in sorted(self.clusters, key=lambda x: x.size, reverse=True):
            lines.append(f"  Cluster #{c.cluster_id}  ({c.size} traces) — Lift: {c.lift:.1f}x")
            lines.append(f"    Common pattern: {' → '.join(c.common_prefix)}")
            if c.divergence_point is not None and c.divergence_point < len(c.common_prefix):
                lines.append(f"    Failure diverges at step {c.divergence_point}: "
                             f"'{c.common_prefix[c.divergence_point]}'")
            lines.append("")
        lines.append("═" * 60)
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Sequence helpers
# ---------------------------------------------------------------------------


def _span_sequence(task: AgentTask) -> List[str]:
    """Return the ordered list of span types for a task (pre-order DFS)."""
    by_id = {s.span_id: s for s in task.spans}
    children: Dict[str, List[Any]] = defaultdict(list)
    roots = []

    for span in task.spans:
        if span.parent_id and span.parent_id in by_id:
            children[span.parent_id].append(span)
        else:
            roots.append(span)

    for lst in children.values():
        lst.sort(key=lambda s: s.start_time)
    roots.sort(key=lambda s: s.start_time)

    result: List[str] = []

    def dfs(span: Any) -> None:
        if span.type.value == "tool_call":
            result.append(f"tool_call:{span.tool_name or 'unknown'}")
        else:
            result.append(span.type.value)
            
        for child in children[span.span_id]:
            dfs(child)

    for r in roots:
        dfs(r)
    return result


def _sequence_similarity(a: List[str], b: List[str]) -> float:
    """Normalised sequence similarity using difflib (0.0–1.0)."""
    return difflib.SequenceMatcher(None, a, b).ratio()


def _common_prefix(sequences: List[List[str]]) -> List[str]:
    """Longest sequence that is a prefix of ALL sequences in the list."""
    if not sequences:
        return []
    prefix = sequences[0][:]
    for seq in sequences[1:]:
        n = min(len(prefix), len(seq))
        prefix = [prefix[i] for i in range(n) if prefix[i] == seq[i]]
        if not prefix:
            break
    return prefix


# ---------------------------------------------------------------------------
# Miner
# ---------------------------------------------------------------------------


class FailureMiner:
    """
    Mine failure patterns from a trace store.

    Algorithm:
      1. Load all failure traces from the store.
      2. Compute span-type sequences for each.
      3. Greedily cluster by sequence similarity (threshold 0.6).
      4. For each cluster, compute the common prefix and the divergence point.
    """

    SIMILARITY_THRESHOLD = 0.60

    def __init__(self, store: Any) -> None:
        self._store = store

    def mine(
        self,
        min_cluster_size: int = 2,
        limit: int = 500,
    ) -> FailureMiningReport:
        # Load summaries
        all_summaries = self._store.list_tasks(limit=limit)
        total  = len(all_summaries)
        n_fail = sum(1 for t in all_summaries if t["outcome"] == "failure")
        n_succ = sum(1 for t in all_summaries if t["outcome"] == "success")

        failure_summaries = [t for t in all_summaries if t["outcome"] == "failure"]

        if not failure_summaries:
            return FailureMiningReport(
                total_traces=total, failure_traces=0, success_traces=n_succ,
                failure_rate=0.0, clusters=[],
            )

        # Load full traces for failures AND successes to compute lift
        failure_tasks: List[AgentTask] = []
        for s in failure_summaries:
            task = self._store.get_task(s["task_id"])
            if task:
                failure_tasks.append(task)
                
        success_tasks: List[AgentTask] = []
        for s in all_summaries:
            if s["outcome"] == "success":
                task = self._store.get_task(s["task_id"])
                if task:
                    success_tasks.append(task)

        # Compute sequences
        sequences: List[List[str]] = [_span_sequence(t) for t in failure_tasks]
        success_sequences: List[List[str]] = [_span_sequence(t) for t in success_tasks]

        # Greedy clustering
        clusters: List[List[int]] = []  # list of lists of indices
        assigned = [False] * len(sequences)

        for i in range(len(sequences)):
            if assigned[i]:
                continue
            cluster = [i]
            assigned[i] = True
            for j in range(i + 1, len(sequences)):
                if assigned[j]:
                    continue
                if _sequence_similarity(sequences[i], sequences[j]) >= self.SIMILARITY_THRESHOLD:
                    cluster.append(j)
                    assigned[j] = True
            clusters.append(cluster)

        # Build result
        result_clusters: List[FailureCluster] = []
        for cid, indices in enumerate(clusters):
            if len(indices) < min_cluster_size:
                continue
            seqs   = [sequences[i] for i in indices]
            prefix = _common_prefix(seqs)
            task_ids = [failure_tasks[i].task_id for i in indices]

            # Find divergence point: first position where any sequence differs
            divergence = len(prefix)
            for seq in seqs:
                for pos in range(len(prefix)):
                    if pos >= len(seq) or seq[pos] != prefix[pos]:
                        divergence = min(divergence, pos)
                        break

            failure_freq = len(indices) / len(sequences) if sequences else 0
            
            # Compute success frequency
            succ_matches = 0
            for s_seq in success_sequences:
                # Is prefix a prefix of s_seq?
                if len(s_seq) >= len(prefix) and s_seq[:len(prefix)] == prefix:
                    succ_matches += 1
            
            succ_freq = succ_matches / max(len(success_sequences), 1)
            lift = failure_freq / succ_freq if succ_freq > 0 else (failure_freq * 10.0) # avoid inf
            
            # Ignore non-discriminative patterns
            if lift <= 1.5 and len(success_sequences) > 0:
                continue

            result_clusters.append(FailureCluster(
                cluster_id       = cid,
                size             = len(indices),
                common_prefix    = prefix,
                task_ids         = task_ids,
                divergence_point = divergence if divergence < len(prefix) else None,
                lift             = lift,
            ))

        result_clusters.sort(key=lambda c: c.lift * c.size, reverse=True)

        return FailureMiningReport(
            total_traces   = total,
            failure_traces = n_fail,
            success_traces = n_succ,
            failure_rate   = n_fail / total if total else 0.0,
            clusters       = result_clusters,
        )
