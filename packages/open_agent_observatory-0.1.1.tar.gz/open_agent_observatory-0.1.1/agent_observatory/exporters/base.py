"""Abstract base class for span exporters."""
from __future__ import annotations
from abc import ABC, abstractmethod
from agent_observatory.core.models import AgentTask


class SpanExporter(ABC):
    """
    Interface for exporting completed AgentTask traces to external systems.

    Implement this to push traces to OTLP collectors, hosted platforms,
    message queues, or any other sink.
    """

    @abstractmethod
    def export(self, task: AgentTask) -> None:
        """Export a finished task. Implementations must be thread-safe."""
        ...

    def shutdown(self) -> None:
        """Optional cleanup (flush buffers, close connections, etc.)."""
        pass
