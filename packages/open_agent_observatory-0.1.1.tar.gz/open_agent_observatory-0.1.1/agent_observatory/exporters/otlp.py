"""
OTLP-compatible JSON exporter.

Converts an AgentTask trace into OpenTelemetry Protocol (OTLP) JSON format
so that traces can be sent to any OTLP-compatible backend:

    Jaeger     → http://localhost:4318/v1/traces
    Honeycomb  → https://api.honeycomb.io/v1/traces
    Grafana    → https://otlp-gateway-xxx.grafana.net/otlp/v1/traces
    Signoz     → http://localhost:4318/v1/traces

Usage:
    from agent_observatory.exporters.otlp import OTLPExporter
    from agent_observatory import tracer

    tracer.configure(exporters=[OTLPExporter("http://localhost:4318/v1/traces")])
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional

from agent_observatory.core.models import AgentSpan, AgentTask, SpanType
from agent_observatory.exporters.base import SpanExporter


# OpenTelemetry span-kind mapping
_SPAN_KIND_MAP = {
    SpanType.REASONING:     2,  # INTERNAL
    SpanType.PLANNING:      2,  # INTERNAL
    SpanType.REFLECTION:    2,  # INTERNAL
    SpanType.BACKTRACK:     2,  # INTERNAL
    SpanType.TOOL_CALL:     3,  # CLIENT
    SpanType.TOOL_RESPONSE: 4,  # PRODUCER (response side)
    SpanType.CUSTOM:        2,  # INTERNAL
}

# Status codes
_STATUS_OK    = {"code": 1}
_STATUS_ERROR = {"code": 2}


def _to_ns(ts: Optional[float]) -> int:
    """Convert Unix epoch seconds (float) to nanoseconds (int)."""
    return int((ts or time.time()) * 1_000_000_000)


def _attrs(d: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Convert a flat dict into OTLP KeyValue attribute format."""
    result = []
    for k, v in d.items():
        if v is None:
            continue
        if isinstance(v, bool):
            result.append({"key": k, "value": {"boolValue": v}})
        elif isinstance(v, int):
            result.append({"key": k, "value": {"intValue": v}})
        elif isinstance(v, float):
            result.append({"key": k, "value": {"doubleValue": v}})
        else:
            result.append({"key": k, "value": {"stringValue": str(v)}})
    return result


def _span_to_otlp(span: AgentSpan, service_name: str) -> Dict[str, Any]:
    """Convert an AgentSpan to an OTLP span dict."""
    attributes = {
        "agent_observatory.span_type":   span.type.value,
        "agent_observatory.outcome":     span.outcome.value,
        "agent_observatory.tokens_in":   span.tokens.tokens_in,
        "agent_observatory.tokens_out":  span.tokens.tokens_out,
        "agent_observatory.task_id":     span.task_id,
    }
    if span.model:
        attributes["llm.model"]          = span.model
        attributes["gen_ai.system"]      = "openai"  # generic
        attributes["gen_ai.request.model"] = span.model
    if span.tool_name:
        attributes["agent_observatory.tool_name"] = span.tool_name
    if span.error:
        attributes["exception.message"]  = span.error
    if span.prompt:
        # Truncate to 512 chars to stay within OTLP size limits
        attributes["llm.prompt"]         = span.prompt[:512]
    if span.response:
        attributes["llm.response"]       = span.response[:512]

    # Merge user-provided metadata
    for k, v in span.metadata.items():
        attributes[f"agent_observatory.meta.{k}"] = v

    otlp_span = {
        "traceId":          span.trace_id.replace("-", ""),
        "spanId":           span.span_id.replace("-", "")[:16],
        "parentSpanId":     (span.parent_id or "").replace("-", "")[:16] or None,
        "name":             span.name or span.type.value,
        "kind":             _SPAN_KIND_MAP.get(span.type, 2),
        "startTimeUnixNano": str(_to_ns(span.start_time)),
        "endTimeUnixNano":   str(_to_ns(span.end_time)),
        "attributes":       _attrs(attributes),
        "status":           _STATUS_ERROR if span.error else _STATUS_OK,
        "events":           [],
        "links":            [],
    }
    if otlp_span["parentSpanId"] == "":
        del otlp_span["parentSpanId"]

    return otlp_span


def task_to_otlp(task: AgentTask) -> Dict[str, Any]:
    """Convert an AgentTask to the OTLP /v1/traces JSON body."""
    service_name = task.agent_name or "agent-observatory"

    resource_attrs = _attrs({
        "service.name":          service_name,
        "service.version":       "0.1.0",
        "agent_observatory.task_id":  task.task_id,
        "agent_observatory.task_name": task.name,
        "agent_observatory.outcome":  task.outcome.value,
        "agent_observatory.total_tokens": task.total_tokens,
    })

    otlp_spans = [_span_to_otlp(s, service_name) for s in task.spans]

    return {
        "resourceSpans": [{
            "resource": {"attributes": resource_attrs},
            "scopeSpans": [{
                "scope": {"name": "agent-observatory", "version": "0.1.0"},
                "spans": otlp_spans,
            }],
        }]
    }


class OTLPExporter(SpanExporter):
    """
    Push completed traces to any OTLP HTTP/JSON endpoint.

    Args:
        endpoint:     OTLP traces URL, e.g. "http://localhost:4318/v1/traces"
        headers:      Extra HTTP headers (e.g. {"x-honeycomb-team": "..."})
        timeout:      Request timeout in seconds (default 10)
    """

    def __init__(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 10,
    ) -> None:
        self.endpoint = endpoint
        self.headers  = {"Content-Type": "application/json", **(headers or {})}
        self.timeout  = timeout

    def export(self, task: AgentTask) -> None:
        try:
            import requests
        except ImportError:
            raise ImportError(
                "OTLPExporter requires 'requests'. Install with: "
                "pip install agent-observatory[otlp]"
            )

        body = task_to_otlp(task)
        resp = requests.post(
            self.endpoint,
            data=json.dumps(body),
            headers=self.headers,
            timeout=self.timeout,
        )
        resp.raise_for_status()


class ConsoleOTLPExporter(SpanExporter):
    """Debug exporter that pretty-prints the OTLP payload to stdout."""

    def export(self, task: AgentTask) -> None:
        body = task_to_otlp(task)
        print(json.dumps(body, indent=2))
