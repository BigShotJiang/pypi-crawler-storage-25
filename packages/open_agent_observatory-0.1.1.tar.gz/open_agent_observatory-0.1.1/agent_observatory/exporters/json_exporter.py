"""
JSON-LD file exporter.

Writes completed traces to .json files on disk — useful for sharing,
archiving, or feeding into offline analysis pipelines.

Usage:
    from agent_observatory.exporters.json_exporter import JSONExporter
    from agent_observatory import tracer

    tracer.configure(exporters=[JSONExporter("./traces/")])
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from agent_observatory.core.models import AgentTask
from agent_observatory.exporters.base import SpanExporter


class JSONExporter(SpanExporter):
    """
    Export each completed task to a JSON-LD file.

    Files are named: {output_dir}/{timestamp}_{task_id[:8]}.json
    """

    def __init__(self, output_dir: str = "./observatory_traces", indent: int = 2) -> None:
        self.output_dir = Path(output_dir)
        self.indent     = indent
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export(self, task: AgentTask) -> None:
        ts   = datetime.fromtimestamp(task.start_time, tz=timezone.utc).strftime("%Y%m%dT%H%M%S")
        name = f"{ts}_{task.task_id[:8]}.json"
        path = self.output_dir / name

        with open(path, "w", encoding="utf-8") as f:
            json.dump(task.to_dict(), f, indent=self.indent, default=str, ensure_ascii=False)
