"""
Semantic diff engine for AgentTask traces.

Two-stage algorithm:
  1. Structural alignment  -- Zhang-Shasha / APTED tree-edit distance
     Maps spans across two traces by their structural position in the tree.
  2. Semantic matching     -- sentence-transformers cosine similarity
     For structurally-aligned pairs, compute embedding similarity to detect
     "same reasoning step, different wording vs. genuinely diverged logic."

The output is a TraceDiff object:
  - matched_pairs        : spans that align structurally AND semantically
  - semantic_divergences : aligned by structure but low semantic similarity
  - only_in_left         : spans present in trace A, absent in trace B
  - only_in_right        : spans present in trace B, absent in trace A
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from agent_observatory.core.models import AgentSpan, AgentTask


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class SpanPair:
    """Two spans from different traces matched together."""
    left:       AgentSpan
    right:      AgentSpan
    similarity: float = 1.0   # 0.0–1.0; 1.0 = identical semantics


@dataclass
class TraceDiff:
    """The complete diff between two agent traces."""
    task_a_id: str
    task_b_id: str

    matched_pairs:        List[SpanPair]  = field(default_factory=list)
    semantic_divergences: List[SpanPair]  = field(default_factory=list)
    only_in_left:         List[AgentSpan] = field(default_factory=list)
    only_in_right:        List[AgentSpan] = field(default_factory=list)

    # Threshold below which a matched pair is flagged as "semantically diverged"
    divergence_threshold: float = 0.75

    @property
    def summary(self) -> Dict[str, Any]:
        return {
            "task_a_id":               self.task_a_id,
            "task_b_id":               self.task_b_id,
            "matched":                 len(self.matched_pairs),
            "semantic_divergences":    len(self.semantic_divergences),
            "only_in_left":            len(self.only_in_left),
            "only_in_right":           len(self.only_in_right),
        }

    def to_dict(self) -> Dict[str, Any]:
        def pair_to_dict(p: SpanPair) -> Dict[str, Any]:
            return {
                "left":       p.left.to_dict(),
                "right":      p.right.to_dict(),
                "similarity": round(p.similarity, 4),
            }

        return {
            "summary":             self.summary,
            "matched_pairs":       [pair_to_dict(p) for p in self.matched_pairs],
            "semantic_divergences":[pair_to_dict(p) for p in self.semantic_divergences],
            "only_in_left":        [s.to_dict() for s in self.only_in_left],
            "only_in_right":       [s.to_dict() for s in self.only_in_right],
        }


# ---------------------------------------------------------------------------
# Tree builder (flat span list → ordered list with depth)
# ---------------------------------------------------------------------------


def _build_ordered_spans(task: AgentTask) -> List[Tuple[AgentSpan, int]]:
    """
    Return spans in DFS pre-order with their tree depth.
    Depth 0 = root span (no parent).
    """
    by_id: Dict[str, AgentSpan] = {s.span_id: s for s in task.spans}
    children: Dict[str, List[AgentSpan]] = {s.span_id: [] for s in task.spans}
    roots: List[AgentSpan] = []

    for span in task.spans:
        if span.parent_id and span.parent_id in by_id:
            children[span.parent_id].append(span)
        else:
            roots.append(span)

    # Sort children by start_time for deterministic ordering
    for lst in children.values():
        lst.sort(key=lambda s: s.start_time)
    roots.sort(key=lambda s: s.start_time)

    result: List[Tuple[AgentSpan, int]] = []

    def dfs(span: AgentSpan, depth: int) -> None:
        result.append((span, depth))
        for child in children[span.span_id]:
            dfs(child, depth + 1)

    for root in roots:
        dfs(root, 0)

    return result


# ---------------------------------------------------------------------------
# Structural alignment (positional matching)
# ---------------------------------------------------------------------------


def _structural_match(
    left_spans:  List[Tuple[AgentSpan, int]],
    right_spans: List[Tuple[AgentSpan, int]],
) -> Tuple[List[Tuple[AgentSpan, AgentSpan]], List[AgentSpan], List[AgentSpan]]:
    """
    Match spans by (type, depth, positional index within that depth+type group).

    This is a lightweight alternative to full APTED — good enough for traces
    of typical agent length (< 200 spans) without heavy dependencies.
    Returns: (matched_pairs, unmatched_left, unmatched_right)
    """
    from collections import defaultdict

    def key(span: AgentSpan, depth: int) -> str:
        return f"{depth}:{span.type.value}"

    left_groups:  Dict[str, List[AgentSpan]] = defaultdict(list)
    right_groups: Dict[str, List[AgentSpan]] = defaultdict(list)

    for span, depth in left_spans:
        left_groups[key(span, depth)].append(span)
    for span, depth in right_spans:
        right_groups[key(span, depth)].append(span)

    matched:       List[Tuple[AgentSpan, AgentSpan]] = []
    unmatched_left:  List[AgentSpan] = []
    unmatched_right: List[AgentSpan] = []

    all_keys = set(left_groups) | set(right_groups)

    for k in all_keys:
        llist = left_groups.get(k, [])
        rlist = right_groups.get(k, [])
        n = min(len(llist), len(rlist))
        for i in range(n):
            matched.append((llist[i], rlist[i]))
        unmatched_left.extend(llist[n:])
        unmatched_right.extend(rlist[n:])

    return matched, unmatched_left, unmatched_right


# ---------------------------------------------------------------------------
# Semantic similarity (sentence-transformers)
# ---------------------------------------------------------------------------

_embed_model = None


def _cosine(a: List[float], b: List[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def _span_text(span: AgentSpan) -> str:
    """Concatenate prompt + response for embedding."""
    parts = [span.name, span.type.value]
    if span.prompt:
        parts.append(span.prompt[:256])
    if span.response:
        parts.append(span.response[:256])
    if span.tool_result:
        parts.append(span.tool_result[:128])
    return " ".join(parts)


def _compute_semantic_similarities(
    pairs: List[Tuple[AgentSpan, AgentSpan]],
) -> List[float]:
    """
    Compute cosine similarities for each pair using sentence-transformers.
    Falls back to name-based similarity if the library is not installed.
    """
    if not pairs:
        return []

    texts = []
    for (left, right) in pairs:
        texts.append(_span_text(left))
        texts.append(_span_text(right))

    global _embed_model
    try:
        from sentence_transformers import SentenceTransformer
        if _embed_model is None:
            _embed_model = SentenceTransformer("all-MiniLM-L6-v2")
            
        embeddings = _embed_model.encode(texts, convert_to_numpy=True, show_progress_bar=False)
        sims = []
        for i in range(0, len(embeddings), 2):
            sims.append(float(_cosine(embeddings[i].tolist(), embeddings[i + 1].tolist())))
        return sims
    except ImportError:
        # Fallback: name-matching similarity
        sims = []
        for (left, right) in pairs:
            ln = (left.name or "").lower()
            rn = (right.name or "").lower()
            common = len(set(ln.split()) & set(rn.split()))
            total  = max(len(set(ln.split()) | set(rn.split())), 1)
            sims.append(common / total)
        return sims


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def diff(
    task_a: AgentTask,
    task_b: AgentTask,
    *,
    semantic: bool = True,
    divergence_threshold: float = 0.75,
) -> TraceDiff:
    """
    Compute the diff between two agent traces.

    Args:
        task_a:               First trace (the "left" side)
        task_b:               Second trace (the "right" side)
        semantic:             If True, use sentence-transformers for similarity.
                              If False, uses name-based heuristic (no dependencies).
        divergence_threshold: Similarity below this → flagged as semantic divergence.

    Returns:
        A TraceDiff with matched, diverged, and unmatched spans.
    """
    left_ordered  = _build_ordered_spans(task_a)
    right_ordered = _build_ordered_spans(task_b)

    matched_pairs, unmatched_left, unmatched_right = _structural_match(
        left_ordered, right_ordered
    )

    if semantic and matched_pairs:
        sims = _compute_semantic_similarities(matched_pairs)
    else:
        sims = [1.0] * len(matched_pairs)

    result = TraceDiff(
        task_a_id            = task_a.task_id,
        task_b_id            = task_b.task_id,
        divergence_threshold = divergence_threshold,
        only_in_left         = unmatched_left,
        only_in_right        = unmatched_right,
    )

    for (left, right), sim in zip(matched_pairs, sims):
        pair = SpanPair(left=left, right=right, similarity=sim)
        if sim < divergence_threshold:
            result.semantic_divergences.append(pair)
        else:
            result.matched_pairs.append(pair)

    return result
