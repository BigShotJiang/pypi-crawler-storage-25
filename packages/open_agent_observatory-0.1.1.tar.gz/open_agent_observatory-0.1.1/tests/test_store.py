"""
Tests for SQLiteStore persistence layer.
"""
import pytest
import tempfile
import os
from pathlib import Path

from agent_observatory.core.models import (
    AgentSpan, AgentTask, SpanType, SpanOutcome, TaskOutcome, TokenUsage,
)
from agent_observatory.store.sqlite_store import SQLiteStore


@pytest.fixture
def store(tmp_path):
    """Fresh in-memory-style store for each test."""
    db = tmp_path / "test.db"
    return SQLiteStore(db_path=str(db))


def make_task(name="Test Task", outcome=TaskOutcome.SUCCESS, n_spans=3):
    import time
    task = AgentTask(name=name, agent_name="test-agent", model="gpt-4o")
    task.spans = [
        AgentSpan(
            task_id=task.task_id,
            trace_id=task.trace_id,
            type=SpanType.REASONING,
            name=f"span-{i}",
            tokens=TokenUsage(100, 50),
        )
        for i in range(n_spans)
    ]
    for s in task.spans:
        s.finish()
    task.finish(outcome)
    return task


class TestSQLiteStore:
    def test_save_and_get(self, store):
        task = make_task("hello world")
        store.save_task(task)
        loaded = store.get_task(task.task_id)
        assert loaded is not None
        assert loaded.name == "hello world"
        assert loaded.task_id == task.task_id
        assert len(loaded.spans) == 3

    def test_get_nonexistent(self, store):
        assert store.get_task("doesnotexist") is None

    def test_list_tasks(self, store):
        for i in range(5):
            store.save_task(make_task(f"Task {i}"))
        tasks = store.list_tasks(limit=10)
        assert len(tasks) == 5

    def test_list_filter_outcome(self, store):
        store.save_task(make_task("ok", TaskOutcome.SUCCESS))
        store.save_task(make_task("fail", TaskOutcome.FAILURE))
        ok   = store.list_tasks(outcome="success")
        fail = store.list_tasks(outcome="failure")
        assert len(ok)   == 1 and ok[0]["outcome"]   == "success"
        assert len(fail) == 1 and fail[0]["outcome"]  == "failure"

    def test_list_filter_agent(self, store):
        t1 = make_task("A"); t1.agent_name = "agent-x"
        t2 = make_task("B"); t2.agent_name = "agent-y"
        store.save_task(t1); store.save_task(t2)
        res = store.list_tasks(agent="agent-x")
        assert len(res) == 1
        assert res[0]["agent_name"] == "agent-x"

    def test_count_tasks(self, store):
        for i in range(7):
            store.save_task(make_task(f"t{i}"))
        assert store.count_tasks() == 7

    def test_delete_task(self, store):
        task = make_task()
        store.save_task(task)
        assert store.get_task(task.task_id) is not None
        deleted = store.delete_task(task.task_id)
        assert deleted is True
        assert store.get_task(task.task_id) is None

    def test_delete_nonexistent(self, store):
        assert store.delete_task("ghost") is False

    def test_upsert_on_resave(self, store):
        task = make_task("original")
        store.save_task(task)
        task.name = "updated"
        store.save_task(task)
        loaded = store.get_task(task.task_id)
        assert loaded.name == "updated"

    def test_analytics_runs(self, store):
        for i in range(3):
            store.save_task(make_task(f"t{i}", TaskOutcome.SUCCESS if i%2==0 else TaskOutcome.FAILURE))
        data = store.get_analytics()
        assert "summary" in data
        assert "by_outcome" in data
        assert "by_span_type" in data
        assert "timeline" in data
        assert data["summary"]["total_tasks"] == 3

    def test_search_filter(self, store):
        store.save_task(make_task("alpha task"))
        store.save_task(make_task("beta task"))
        store.save_task(make_task("gamma run"))
        res = store.list_tasks(search="task")
        assert len(res) == 2
