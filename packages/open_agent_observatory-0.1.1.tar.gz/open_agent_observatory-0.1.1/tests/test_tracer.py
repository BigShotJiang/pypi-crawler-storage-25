"""
Tests for the GlobalTracer and context management.
"""
import pytest
import time
from agent_observatory import tracer as global_tracer
from agent_observatory.core.tracer import GlobalTracer, _ctx_task, _ctx_span
from agent_observatory.core.models import SpanType, SpanOutcome, TaskOutcome
from agent_observatory.store.sqlite_store import SQLiteStore


@pytest.fixture
def tracer(tmp_path):
    t = GlobalTracer()
    t.configure(db_path=str(tmp_path / "test.db"))
    return t


class TestTracerBasic:
    def test_task_context(self, tracer):
        with tracer.task("basic test", agent="pytest") as ctx:
            assert ctx.task.name == "basic test"
            assert ctx.task.agent_name == "pytest"
        assert ctx.task.is_finished
        assert ctx.task.outcome == TaskOutcome.SUCCESS

    def test_span_inside_task(self, tracer):
        with tracer.task("span test") as task:
            with task.span("reasoning", name="think") as s:
                s.record(prompt="hello", response="world", tokens_in=10, tokens_out=5)
        assert len(task.task.spans) == 1
        assert task.task.spans[0].name == "think"
        assert task.task.spans[0].tokens.total == 15

    def test_nested_spans(self, tracer):
        with tracer.task("nested") as task:
            with task.span("planning", name="plan") as s1:
                with task.span("reasoning", name="think") as s2:
                    pass

        spans = task.task.spans
        assert len(spans) == 2
        parent = next(s for s in spans if s.name == "plan")
        child  = next(s for s in spans if s.name == "think")
        assert child.parent_id == parent.span_id

    def test_task_failure_on_exception(self, tracer):
        try:
            with tracer.task("will fail") as task:
                raise ValueError("intentional error")
        except ValueError:
            pass
        assert task.task.outcome == TaskOutcome.FAILURE
        assert "intentional error" in (task.task.error or "")

    def test_span_failure_on_exception(self, tracer):
        with tracer.task("span exception test") as task:
            try:
                with task.span("reasoning", name="bad span") as s:
                    raise RuntimeError("span error")
            except RuntimeError:
                pass

        assert task.task.spans[0].outcome == SpanOutcome.FAILURE
        assert "span error" in (task.task.spans[0].error or "")

    def test_persisted_to_store(self, tracer):
        with tracer.task("persist check") as task:
            with task.span("reasoning") as s:
                s.record(tokens_in=100, tokens_out=50)

        loaded = tracer.store.get_task(task.task.task_id)
        assert loaded is not None
        assert loaded.name == "persist check"
        assert loaded.total_tokens == 150

    def test_span_type_string_coercion(self, tracer):
        with tracer.task("type coerce") as task:
            with task.span("tool_call", name="t") as s:
                pass
        assert task.task.spans[0].type == SpanType.TOOL_CALL

    def test_multiple_spans_sequential(self, tracer):
        with tracer.task("multi span") as task:
            for i in range(5):
                with task.span("reasoning", name=f"step-{i}") as s:
                    s.record(tokens_in=10, tokens_out=5)

        assert len(task.task.spans) == 5
        assert task.task.total_tokens == 75

    def test_configure_returns_self(self, tmp_path):
        t = GlobalTracer()
        result = t.configure(db_path=str(tmp_path / "x.db"))
        assert result is t


class TestTracerCurrentContext:
    def test_current_task_none_outside(self, tracer):
        assert tracer.current_task() is None

    def test_current_task_inside(self, tracer):
        with tracer.task("ctx test") as task:
            assert tracer.current_task() is not None
            assert tracer.current_task().name == "ctx test"

    def test_current_span_none_outside(self, tracer):
        assert tracer.current_span() is None

    def test_current_span_inside(self, tracer):
        with tracer.task("span ctx") as task:
            assert tracer.current_span() is None
            with task.span("reasoning", name="active") as s:
                assert tracer.current_span() is not None
                assert tracer.current_span().name == "active"
            assert tracer.current_span() is None
