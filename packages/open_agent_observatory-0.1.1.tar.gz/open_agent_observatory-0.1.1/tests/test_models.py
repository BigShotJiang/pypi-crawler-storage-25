"""
Tests for Agent Observatory core data model.
"""
import time
import pytest
from agent_observatory.core.models import (
    AgentSpan, AgentTask, SpanType, SpanOutcome, TaskOutcome, TokenUsage,
)


class TestTokenUsage:
    def test_total(self):
        t = TokenUsage(tokens_in=100, tokens_out=50)
        assert t.total == 150

    def test_add(self):
        a = TokenUsage(10, 20)
        b = TokenUsage(30, 40)
        c = a + b
        assert c.tokens_in == 40
        assert c.tokens_out == 60

    def test_round_trip(self):
        t = TokenUsage(111, 222)
        assert TokenUsage.from_dict(t.to_dict()) == t


class TestAgentSpan:
    def test_defaults(self):
        s = AgentSpan()
        assert s.span_id
        assert s.type == SpanType.CUSTOM
        assert s.outcome == SpanOutcome.UNKNOWN
        assert not s.is_finished

    def test_finish(self):
        s = AgentSpan()
        s.finish()
        assert s.is_finished
        assert s.outcome == SpanOutcome.SUCCESS
        assert s.latency_ms is not None
        assert s.latency_ms >= 0

    def test_record(self):
        s = AgentSpan()
        s.record(prompt="hello", response="world", tokens_in=10, tokens_out=5)
        assert s.prompt == "hello"
        assert s.response == "world"
        assert s.tokens.tokens_in == 10
        assert s.tokens.tokens_out == 5
        assert s.tokens.total == 15

    def test_record_tool(self):
        s = AgentSpan(type=SpanType.TOOL_CALL)
        s.record_tool(args={"cmd": "ls"}, result="file.txt", outcome=SpanOutcome.SUCCESS)
        assert s.tool_args == {"cmd": "ls"}
        assert s.tool_result == "file.txt"
        assert s.outcome == SpanOutcome.SUCCESS

    def test_round_trip(self):
        s = AgentSpan(
            type=SpanType.REASONING,
            name="think",
            model="gpt-4o",
            prompt="test prompt",
            response="test response",
        )
        s.finish()
        d = s.to_dict()
        s2 = AgentSpan.from_dict(d)
        assert s2.span_id == s.span_id
        assert s2.type == SpanType.REASONING
        assert s2.prompt == "test prompt"
        assert s2.response == "test response"
        assert s2.latency_ms == s.latency_ms

    def test_children_round_trip(self):
        parent = AgentSpan(name="parent")
        child  = AgentSpan(name="child", parent_id=parent.span_id)
        parent.children = [child]
        d = parent.to_dict()
        p2 = AgentSpan.from_dict(d)
        assert len(p2.children) == 1
        assert p2.children[0].name == "child"


class TestAgentTask:
    def test_defaults(self):
        t = AgentTask(name="test task")
        assert t.task_id
        assert t.trace_id
        assert t.outcome == TaskOutcome.IN_PROGRESS
        assert not t.is_finished

    def test_finish(self):
        t = AgentTask(name="test")
        t.finish()
        assert t.is_finished
        assert t.outcome == TaskOutcome.SUCCESS

    def test_token_aggregation(self):
        task = AgentTask(name="test")
        task.spans = [
            AgentSpan(tokens=TokenUsage(100, 50)),
            AgentSpan(tokens=TokenUsage(200, 80)),
        ]
        assert task.total_tokens_in  == 300
        assert task.total_tokens_out == 130
        assert task.total_tokens     == 430

    def test_round_trip(self):
        task = AgentTask(
            name="Round-trip test",
            agent_name="test-agent",
            model="claude-3",
            tags=["test"],
        )
        span = AgentSpan(
            task_id=task.task_id,
            trace_id=task.trace_id,
            type=SpanType.PLANNING,
            name="plan",
        )
        span.record(prompt="p", response="r", tokens_in=10, tokens_out=5)
        span.finish()
        task.spans = [span]
        task.finish()

        d   = task.to_dict()
        t2  = AgentTask.from_dict(d)
        assert t2.task_id    == task.task_id
        assert t2.name       == "Round-trip test"
        assert t2.outcome    == TaskOutcome.SUCCESS
        assert len(t2.spans) == 1
        assert t2.spans[0].type == SpanType.PLANNING

    def test_summary_dict(self):
        task = AgentTask(name="summary test")
        task.spans = [AgentSpan(tokens=TokenUsage(50, 30))]
        d = task.to_summary_dict()
        assert "task_id" in d
        assert "total_tokens" in d
        assert d["total_tokens"] == 80
