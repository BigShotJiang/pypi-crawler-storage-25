# tests/test_visualizer.py
from pathlib import Path
from unittest.mock import MagicMock
import pytest
from arcgis_item_graph.visualizer import ItemGraphVisualizer
from arcgis_item_graph.query import QueryResult
from tests.conftest import make_mock_node, make_mock_graph, make_mock_unhydrated_node, make_mock_cycle_graph


@pytest.fixture
def simple_result():
    node_a = make_mock_node("id_a", title="My Dashboard", item_type="Dashboard",
                            contains_ids=["id_b"])
    node_b = make_mock_node("id_b", title="Base Map", item_type="Web Map",
                            contains_ids=[])
    graph = make_mock_graph([node_a, node_b])
    # Mock NetworkX edges
    graph.edges = MagicMock(return_value=[("id_a", "id_b")])
    return QueryResult(
        nodes=[node_a, node_b],
        graph=graph,
        queried_ids={"id_a"},
    )


def test_render_writes_file(simple_result, tmp_path):
    """render(output_file=...) should write a self-contained HTML file."""
    out = tmp_path / "out.html"
    vis = ItemGraphVisualizer(simple_result)
    vis.render(output_file=str(out))
    assert out.exists()
    content = out.read_text(encoding="utf-8")
    assert "let G =" in content              # GRAPH_DATA blob present
    assert "forceSimulation" in content     # D3 force simulation present


def test_render_html_contains_all_node_ids(simple_result, tmp_path):
    """render() output HTML should contain all node IDs in the GRAPH_DATA blob."""
    out = tmp_path / "out.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    content = out.read_text(encoding="utf-8")
    assert '"id_a"' in content
    assert '"id_b"' in content


def test_render_html_contains_edge(simple_result, tmp_path):
    """render() output HTML should contain the edge between id_a and id_b."""
    out = tmp_path / "out.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    content = out.read_text(encoding="utf-8")
    assert '"source":"id_a"' in content
    assert '"target":"id_b"' in content


def test_render_raises_if_no_output_and_no_inline(simple_result):
    """render() with neither output_file nor show_inline should raise ValueError."""
    vis = ItemGraphVisualizer(simple_result)
    with pytest.raises(ValueError, match="Provide output_file"):
        vis.render()


def test_query_result_portal_url_defaults_none():
    """QueryResult should default portal_url to None."""
    from arcgis_item_graph.query import QueryResult
    result = QueryResult(nodes=[], graph=MagicMock(), queried_ids=set())
    assert result.portal_url is None


def test_serialize_nodes_present(simple_result):
    """_serialize() should include every node from the result."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    ids = {n["id"] for n in data["nodes"]}
    assert ids == {"id_a", "id_b"}


def test_serialize_queried_flag(simple_result):
    """_serialize() should mark queried nodes with queried=True."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    node_a = next(n for n in data["nodes"] if n["id"] == "id_a")
    node_b = next(n for n in data["nodes"] if n["id"] == "id_b")
    assert node_a["queried"] is True
    assert node_b["queried"] is False


def test_serialize_item_types(simple_result):
    """_serialize() meta.item_types should list unique types in sorted order."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    assert "Dashboard" in data["meta"]["item_types"]
    assert "Web Map" in data["meta"]["item_types"]


def test_serialize_edges_direction(simple_result):
    """
    _serialize() edges should have direction='forward' for edges outgoing
    from the queried node.

    simple_result has: id_a (queried) → id_b
    id_a is the queried node with no ancestors → edge is 'forward'.
    """
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    assert len(data["edges"]) == 1
    edge = data["edges"][0]
    assert edge["source"] == "id_a"
    assert edge["target"] == "id_b"
    assert edge["direction"] == "forward"


def test_serialize_backward_edge():
    """
    _serialize() should mark edges from ancestor nodes as direction='backward'.

    Graph: upstream (queried=False) → queried_node
    upstream is an ancestor of queried_node → its edge is 'backward'.
    """
    upstream = make_mock_node("upstream", title="Upstream", item_type="Dashboard")
    queried = make_mock_node("queried", title="My Map", item_type="Web Map")
    graph = make_mock_graph([upstream, queried])
    graph.edges = MagicMock(return_value=[("upstream", "queried")])
    result = QueryResult(nodes=[upstream, queried], graph=graph, queried_ids={"queried"})

    vis = ItemGraphVisualizer(result)
    data = vis.serialize()
    assert len(data["edges"]) == 1
    assert data["edges"][0]["direction"] == "backward"


def test_serialize_cycles_detected():
    """_serialize() meta.cycles should be non-empty when the graph has a cycle."""
    node_a = make_mock_node("a", title="A", item_type="Dashboard")
    node_b = make_mock_node("b", title="B", item_type="Web Map")
    node_c = make_mock_node("c", title="C", item_type="Form")
    graph = make_mock_cycle_graph()
    result = QueryResult(nodes=[node_a, node_b, node_c], graph=graph, queried_ids={"a"})

    vis = ItemGraphVisualizer(result)
    data = vis.serialize()
    assert len(data["meta"]["cycles"]) >= 1
    flat = [item for cycle in data["meta"]["cycles"] for item in cycle]
    assert "a" in flat and "b" in flat and "c" in flat


def test_serialize_no_cycles(simple_result):
    """_serialize() meta.cycles should be empty when the graph is acyclic."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    assert data["meta"]["cycles"] == []


def test_serialize_unhydrated_node():
    """_serialize() should mark nodes with item=None as hydrated=False."""
    unhydrated = make_mock_unhydrated_node("ghost_id")
    graph = make_mock_graph([unhydrated])
    graph.edges = MagicMock(return_value=[])
    result = QueryResult(nodes=[unhydrated], graph=graph, queried_ids={"ghost_id"})

    vis = ItemGraphVisualizer(result)
    data = vis.serialize()
    node = data["nodes"][0]
    assert node["hydrated"] is False
    assert node["id"] == "ghost_id"
    assert node["type"] == "Unknown"


def test_serialize_portal_url():
    """_serialize() should build portal_url from result.portal_url + node id."""
    node = make_mock_node("abc123", title="My Layer", item_type="Feature Service")
    graph = make_mock_graph([node])
    graph.edges = MagicMock(return_value=[])
    result = QueryResult(
        nodes=[node],
        graph=graph,
        queried_ids={"abc123"},
        portal_url="https://myorg.arcgis.com",
    )

    vis = ItemGraphVisualizer(result)
    data = vis.serialize()
    node_data = data["nodes"][0]
    assert node_data["portal_url"] == "https://myorg.arcgis.com/home/item.html?id=abc123"


def test_serialize_portal_url_none_when_no_portal(simple_result):
    """_serialize() should set portal_url=None when result.portal_url is None."""
    vis = ItemGraphVisualizer(simple_result)
    data = vis.serialize()
    for n in data["nodes"]:
        assert n["portal_url"] is None


def test_visualizer_renders_impact_panel(tmp_path):
    """Rendered HTML must contain the impact panel structure."""
    from arcgis_item_graph.visualizer import ItemGraphVisualizer
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=["bbb"])
    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert 'id="impact-panel"' in html
    assert 'id="panel-inner"' in html
    assert 'id="panel-back"' in html
    assert 'id="collapse-btn"' in html


def test_visualizer_renders_panel_js_functions(tmp_path):
    """Rendered HTML must contain the panel JavaScript functions."""
    from arcgis_item_graph.visualizer import ItemGraphVisualizer
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=[])
    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert 'PANEL_CONTAINS' in html
    assert 'PANEL_REQUIRED_BY' in html
    assert 'function renderPanel(' in html
    assert 'function panelRowClick(' in html
    assert 'function showQueried(' in html


def test_visualizer_panel_maps_use_forward_edges_only(tmp_path):
    """PANEL_CONTAINS/REQUIRED_BY must filter to forward edges only."""
    from arcgis_item_graph.visualizer import ItemGraphVisualizer
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=["bbb"])
    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert "e.direction !== 'forward'" in html


def test_visualizer_no_detail_panel(tmp_path):
    """The old right-side #detail panel must be removed."""
    from arcgis_item_graph.visualizer import ItemGraphVisualizer
    from arcgis_item_graph.query import QueryResult
    from tests.conftest import make_mock_node, make_mock_graph

    node = make_mock_node("aaa", contains_ids=[])
    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert 'id="detail"' not in html
    assert 'id="detail-title"' not in html


def test_serialize_includes_broken_reason_field(simple_result):
    """_serialize() must include broken_reason in each node dict."""
    for node in simple_result.nodes:
        node.broken_reason = "deleted"

    data = ItemGraphVisualizer(simple_result).serialize()

    assert "broken_reason" in data["nodes"][0]
    assert data["nodes"][0]["broken_reason"] == "deleted"


def test_serialize_includes_deprecated_field(simple_result):
    """_serialize() must include deprecated in each node dict."""
    for node in simple_result.nodes:
        node.deprecated = True

    data = ItemGraphVisualizer(simple_result).serialize()

    assert "deprecated" in data["nodes"][0]
    assert data["nodes"][0]["deprecated"] is True


def test_visualizer_renders_broken_reason_and_deprecated_in_graph_data(tmp_path):
    """broken_reason and deprecated must appear as keys in the embedded G.nodes JSON."""
    node = make_mock_node("aaa", contains_ids=[])
    node.item = None
    node.broken_reason = "permission"

    graph = make_mock_graph([node])
    result = QueryResult(nodes=[node], graph=graph, queried_ids={"aaa"})

    out = tmp_path / "g.html"
    ItemGraphVisualizer(result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")

    assert '"broken_reason"' in html
    assert '"deprecated"' in html


def test_visualizer_renders_requery_input(simple_result, tmp_path):
    """Rendered HTML must include the 'Go to Item' input element."""
    v = ItemGraphVisualizer(simple_result)
    out = tmp_path / "g.html"
    v.render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'id="requery-wrap"' in html
    assert 'id="requery-input"' in html
    assert 'reQueryItem' in html


def test_serialize_is_public(simple_result):
    """serialize() must be callable as a public method."""
    v = ItemGraphVisualizer(simple_result)
    data = v.serialize()
    assert set(data.keys()) == {"nodes", "edges", "meta"}
    assert isinstance(data["nodes"], list)
    assert isinstance(data["edges"], list)
    assert "queried_ids" in data["meta"]


def test_visualizer_renders_zoom_overlay(simple_result, tmp_path):
    """Rendered HTML must include the floating zoom control overlay."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'id="zoom-ctrl"' in html
    assert 'id="zoom-slider"' in html
    assert 'id="btn-zoom-in"' in html
    assert 'id="btn-zoom-out"' in html
    assert 'id="zoom-label"' in html


def test_visualizer_renders_zoom_js(simple_result, tmp_path):
    """Rendered HTML must include the setZoom function and cy.on('zoom') sync."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'function setZoom(' in html
    assert "d3.zoom" in html                # NEW — D3 zoom behavior present


def test_visualizer_tap_pivots_graph(simple_result, tmp_path):
    """Single-click tap handler must update QUERIED and re-render around the clicked node."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'QUERIED = new Set([nid])' in html
    assert 'ctrlKey' in html


def test_visualizer_no_dblclick_handler(simple_result, tmp_path):
    """Double-click expand handler must be removed."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert "cy.on('dblclick'" not in html


def test_visualizer_renders_d3_node_builder(simple_result, tmp_path):
    """Rendered HTML must contain D3 node/link builder and depth computation."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'function buildGraph(' in html
    assert 'function nodeRadius(' in html
    assert 'computeDepths' in html


def test_visualizer_renders_d3_svg_container(simple_result, tmp_path):
    """Rendered HTML must use SVG container with D3 glow filter defs."""
    out = tmp_path / "g.html"
    ItemGraphVisualizer(simple_result).render(output_file=str(out))
    html = out.read_text(encoding="utf-8")
    assert 'id="graph-svg"' in html
    assert 'feGaussianBlur' in html
    assert 'id="glow"' in html
