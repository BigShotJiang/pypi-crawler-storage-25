# tests/test_query.py
from unittest.mock import MagicMock, patch
import pytest
from arcgis_item_graph.query import ItemGraphQuery, QueryResult
from tests.conftest import make_mock_node, make_mock_graph


@pytest.fixture(autouse=True)
def _patch_child_gis(mock_gis):
    """Patch GIS constructor so thread-local children reuse the mock session."""
    with patch("arcgis_item_graph.query.GIS", return_value=mock_gis):
        yield


@pytest.fixture
def two_node_graph():
    """Graph: node_a contains node_b."""
    node_a = make_mock_node("id_a", title="Dashboard A", item_type="Dashboard",
                            contains_ids=["id_b"], required_by_ids=[])
    node_b = make_mock_node("id_b", title="Web Map B", item_type="Web Map",
                            contains_ids=[], required_by_ids=["id_a"])
    return make_mock_graph([node_a, node_b])


@patch("arcgis_item_graph.query.load_from_file")
def test_query_by_id_returns_query_result(mock_load, two_node_graph, mock_gis, tmp_path):
    """query(ids=[...]) should return a QueryResult with the correct sub-graph."""
    mock_load.return_value = two_node_graph
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_a"])

    assert isinstance(result, QueryResult)
    result_ids = {n.id for n in result.nodes}
    assert "id_a" in result_ids   # queried item
    assert "id_b" in result_ids   # dependency of id_a


@patch("arcgis_item_graph.query.load_from_file")
def test_query_by_search_returns_query_result(mock_load, two_node_graph, mock_gis, tmp_path):
    """query(search=...) should search portal and return matching items' sub-graph."""
    mock_load.return_value = two_node_graph

    mock_item = MagicMock()
    mock_item.itemid = "id_a"
    mock_gis.content.search.return_value = [mock_item]

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(search="type:Dashboard")

    mock_gis.content.search.assert_called_once_with("type:Dashboard")
    result_ids = {n.id for n in result.nodes}
    assert "id_a" in result_ids


@patch("arcgis_item_graph.query.load_from_file")
@patch("arcgis_item_graph.query.create_dependency_graph")
@patch("arcgis_item_graph.query.nx.compose")
def test_missing_id_triggers_live_api_fallback(mock_compose, mock_cdg, mock_load, mock_gis, tmp_path):
    """Items not found in GML should fall back to live create_dependency_graph()."""
    # Graph only has id_a
    node_a = make_mock_node("id_a", contains_ids=[], required_by_ids=[])
    node_b = make_mock_node("id_b", contains_ids=[], required_by_ids=[])
    gml_graph = make_mock_graph([node_a])
    mock_load.return_value = gml_graph

    # Live API returns id_b
    live_graph = make_mock_graph([node_b])
    mock_cdg.return_value = live_graph

    # nx.compose returns a merged graph with both nodes
    merged = make_mock_graph([node_a, node_b])
    mock_compose.return_value = merged

    live_item = MagicMock()
    live_item.itemid = "id_b"
    mock_gis.content.get.return_value = live_item

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_b"])

    mock_cdg.assert_called_once()


@patch("arcgis_item_graph.query.load_from_file")
def test_queried_ids_flagged_in_result(mock_load, two_node_graph, mock_gis, tmp_path):
    """QueryResult.queried_ids should only contain explicitly queried IDs."""
    mock_load.return_value = two_node_graph
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_a"])

    assert "id_a" in result.queried_ids
    assert "id_b" not in result.queried_ids


@patch("arcgis_item_graph.query.load_from_file")
def test_query_raises_if_no_input(mock_load, mock_gis, tmp_path):
    """query() with no ids and no search should raise ValueError."""
    mock_load.return_value = make_mock_graph([])
    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    with pytest.raises(ValueError, match="Provide at least one of"):
        q.query()


@patch("arcgis_item_graph.query.load_from_file")
def test_result_nodes_are_hydrated(mock_load, mock_gis, tmp_path):
    """Nodes with item=None should be hydrated via gis.content.get() after query."""
    # Node with no item data (as returned by load_from_file with include_items=False)
    unhydrated = MagicMock()
    unhydrated.id = "id_a"
    unhydrated.item = None
    unhydrated.contains = MagicMock(return_value=[])
    unhydrated.required_by = MagicMock(return_value=[])

    mock_load.return_value = make_mock_graph([unhydrated])

    # Portal returns real item metadata on get()
    portal_item = MagicMock()
    portal_item.title = "My Dashboard"
    portal_item.type = "Dashboard"
    portal_item.owner = "jsmith"
    mock_gis.content.get.return_value = portal_item

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_a"])

    # gis.content.get should have been called for the unhydrated node
    mock_gis.content.get.assert_called_with("id_a")
    # The node's item should now be populated
    assert result.nodes[0].item.title == "My Dashboard"


@patch("arcgis_item_graph.query.load_from_file")
def test_hydration_skips_url_ids(mock_load, mock_gis, tmp_path):
    """Nodes whose ID is a URL (malformed REST references) should not be hydrated."""
    url_node = MagicMock()
    url_node.id = "https://services.arcgis.com/rest/services/SomeLayer/FeatureServer/0"
    url_node.item = None
    url_node.contains = MagicMock(return_value=[])
    url_node.required_by = MagicMock(return_value=[])

    mock_load.return_value = make_mock_graph([url_node])

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    q.query(ids=[url_node.id])

    # content.get should NOT be called for URL-style IDs
    mock_gis.content.get.assert_not_called()


@patch("arcgis_item_graph.query.load_from_file")
def test_hydration_failure_does_not_abort_other_nodes(mock_load, mock_gis, tmp_path):
    """A content.get() failure for one node must not prevent other nodes from hydrating."""
    node_a = MagicMock()
    node_a.id = "id_a"
    node_a.item = None
    node_a.contains = MagicMock(return_value=[])
    node_a.required_by = MagicMock(return_value=["id_b"])

    node_b = MagicMock()
    node_b.id = "id_b"
    node_b.item = None
    node_b.contains = MagicMock(return_value=[])
    node_b.required_by = MagicMock(return_value=[])

    mock_load.return_value = make_mock_graph([node_a, node_b])

    portal_item = MagicMock()
    portal_item.title = "Good Item"
    portal_item.type = "Web Map"

    # id_a raises a non-network exception; id_b succeeds
    def _get_side_effect(item_id):
        if item_id == "id_a":
            raise RuntimeError("permission denied")
        return portal_item

    mock_gis.content.get.side_effect = _get_side_effect

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
    result = q.query(ids=["id_a"])  # traversal follows required_by to id_b

    # Should not raise; id_b must be hydrated despite id_a failing
    hydrated = {n.id: n for n in result.nodes}
    assert hydrated["id_b"].item.title == "Good Item"
    # id_a's item should remain unset (not mutated after the failure)
    assert hydrated["id_a"].item is None


@patch("arcgis_item_graph.query.load_from_file")
def test_hydration_network_error_sets_broken_reason(mock_load, mock_gis, tmp_path):
    """Network errors in parallel hydration are recorded as broken_reason='network'."""
    node_a = MagicMock()
    node_a.id = "id_a"
    node_a.item = None
    node_a.contains = MagicMock(return_value=[])
    node_a.required_by = MagicMock(return_value=[])

    mock_load.return_value = make_mock_graph([node_a])
    mock_gis.content.get.side_effect = ConnectionError("socket timeout")
    mock_gis._con.token = "test-token"
    mock_gis.url = "https://example.com/portal"

    gml = tmp_path / "graph.gml"
    gml.write_text("")

    with patch("arcgis_item_graph.query.GIS") as mock_child_gis:
        mock_child_gis.return_value.content.get.side_effect = ConnectionError("socket timeout")
        q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml))
        result = q.query(ids=["id_a"])

    assert result.nodes[0].item is None
    assert result.nodes[0].broken_reason == "network"


def test_traverse_recursive_visits_full_chain(mock_gis, tmp_path):
    """BFS must visit all nodes in a dependency chain, regardless of queue impl."""
    from arcgis_item_graph.query import ItemGraphQuery
    from unittest.mock import MagicMock

    # Build a 5-node linear chain: a → b → c → d → e
    def make_node(nid, children=None, parents=None):
        n = MagicMock()
        n.id = nid
        n.contains = MagicMock(return_value=children or [])
        n.required_by = MagicMock(return_value=parents or [])
        return n

    nodes = {
        "a": make_node("a", children=["b"]),
        "b": make_node("b", children=["c"], parents=["a"]),
        "c": make_node("c", children=["d"], parents=["b"]),
        "d": make_node("d", children=["e"], parents=["c"]),
        "e": make_node("e", parents=["d"]),
    }

    mock_graph = MagicMock()
    mock_graph.get_node = MagicMock(side_effect=lambda nid: nodes.get(nid))

    gml_path = tmp_path / "g.gml"
    gml_path.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml_path))
    q._graph = mock_graph

    visited = q._traverse_recursive({"a"})
    assert visited == {"a", "b", "c", "d", "e"}


def test_traverse_recursive_respects_max_depth(mock_gis, tmp_path):
    """_traverse_recursive must stop expanding nodes once max_depth is reached."""
    from arcgis_item_graph.query import ItemGraphQuery

    def make_node(nid, children=None, parents=None):
        n = MagicMock()
        n.id = nid
        n.contains = MagicMock(return_value=children or [])
        n.required_by = MagicMock(return_value=parents or [])
        return n

    # Linear chain a→b→c→d→e; seed="a", max_depth=2 should return {a, b, c}
    nodes = {
        "a": make_node("a", children=["b"]),
        "b": make_node("b", children=["c"], parents=["a"]),
        "c": make_node("c", children=["d"], parents=["b"]),
        "d": make_node("d", children=["e"], parents=["c"]),
        "e": make_node("e", parents=["d"]),
    }
    mock_graph = MagicMock()
    mock_graph.get_node = MagicMock(side_effect=lambda nid: nodes.get(nid))

    gml_path = tmp_path / "g.gml"
    gml_path.write_text("")

    q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml_path))
    q._graph = mock_graph

    visited = q._traverse_recursive({"a"}, max_depth=2)
    assert visited == {"a", "b", "c"}


def test_query_respects_max_depth_config(mock_gis, tmp_path):
    """query() must pass max_depth to traversal, limiting nodes returned."""
    from arcgis_item_graph.query import ItemGraphQuery

    def make_node(nid, children=None):
        n = MagicMock()
        n.id = nid
        n.item = None
        n.contains = MagicMock(return_value=children or [])
        n.required_by = MagicMock(return_value=[])
        return n

    nodes = {
        "a": make_node("a", children=["b"]),
        "b": make_node("b", children=["c"]),
        "c": make_node("c", children=["d"]),
        "d": make_node("d"),
    }
    mock_graph = MagicMock()
    mock_graph.get_node = MagicMock(side_effect=lambda nid: nodes.get(nid))
    mock_graph.all_items = MagicMock(return_value=list(nodes.values()))

    with patch("arcgis_item_graph.query.load_from_file", return_value=mock_graph):
        gml_path = tmp_path / "g.gml"
        gml_path.write_text("")
        q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml_path), max_depth=1)
        result = q.query(ids=["a"])

    assert {n.id for n in result.nodes} == {"a", "b"}


def test_resolve_missing_items_uses_thread_pool(mock_gis, tmp_path):
    """Verify _resolve_missing_items fetches items concurrently."""
    from arcgis_item_graph.query import ItemGraphQuery

    # Make content.get return a distinct mock item per ID
    def fake_get(item_id):
        m = MagicMock()
        m.itemid = item_id
        return m

    mock_gis.content.get.side_effect = fake_get

    # Patch graph-building helpers so we don't need real NetworkX/ArcGIS objects
    with patch("arcgis_item_graph.query.create_dependency_graph") as mock_cdg, \
         patch("arcgis_item_graph.query.nx") as mock_nx, \
         patch("arcgis_item_graph.query.ItemGraph"):
        mock_cdg.return_value = MagicMock(all_items=MagicMock(return_value=[]))
        mock_nx.compose.return_value = MagicMock()

        gml_path = tmp_path / "g.gml"
        gml_path.write_text("")

        q = ItemGraphQuery(gis=mock_gis, gml_file=str(gml_path), fetch_workers=4)
        q._graph = MagicMock()
        q._graph.all_items.return_value = []  # nothing in the GML

        missing = {"id1", "id2", "id3"}
        q._resolve_missing_items(missing)

    # All 3 items should have been fetched
    assert mock_gis.content.get.call_count == 3


def test_hydrate_single_node_sets_broken_reason_on_exception():
    """broken_reason is set to the error category when hydration raises."""
    import types
    from unittest.mock import MagicMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.fetch_workers = 1

    with patch(
        "arcgis_item_graph.query.retry_with_backoff",
        side_effect=Exception("unable to find iteminfo"),
    ):
        q._hydrate_single_node(node)

    assert node.broken_reason == "deleted"
    assert not hasattr(node, "deprecated")


def test_hydrate_single_node_sets_not_found_when_item_none():
    """broken_reason='not_found' when portal returns None without raising."""
    import types
    from unittest.mock import MagicMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.fetch_workers = 1

    with patch("arcgis_item_graph.query.retry_with_backoff", return_value=None):
        q._hydrate_single_node(node)

    assert node.broken_reason == "not_found"
    assert not hasattr(node, "deprecated")


def test_hydrate_single_node_sets_deprecated_on_success():
    """deprecated is set from item.deprecated when hydration succeeds."""
    import types
    from unittest.mock import MagicMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    mock_item = MagicMock()
    mock_item.deprecated = True
    mock_item.title = "Test Item"
    mock_item.type = "Feature Service"

    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.fetch_workers = 1

    with patch("arcgis_item_graph.query.retry_with_backoff", return_value=mock_item):
        q._hydrate_single_node(node)

    assert node.item is mock_item
    assert node.deprecated is True
    assert not hasattr(node, "broken_reason")


def test_hydrate_single_node_stub_property_access_raises():
    """node marked broken when item stub is returned but property access raises.

    Reproduces the production failure where gis.content.get() returns an Item
    object but accessing item.deprecated triggers the ArcGIS SDK's lazy-load
    _hydrate(), which then fails with 'Item does not exist or is inaccessible'.
    """
    import types
    from unittest.mock import MagicMock, PropertyMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)

    # Simulate an Item stub whose property access triggers a portal error
    mock_item = MagicMock()
    type(mock_item).deprecated = PropertyMock(
        side_effect=Exception("Item does not exist or is inaccessible.")
    )

    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.fetch_workers = 1

    with patch("arcgis_item_graph.query.retry_with_backoff", return_value=mock_item):
        q._hydrate_single_node(node)

    assert node.item is None
    assert hasattr(node, "broken_reason")


def test_hydrate_result_nodes_stub_property_access_raises():
    """_hydrate_result_nodes marks node broken when item property access raises.

    Mirrors test_hydrate_single_node_stub_property_access_raises but exercises
    the parallel ThreadPoolExecutor path used by the main query flow.
    """
    import types
    import threading
    from unittest.mock import MagicMock, PropertyMock, patch
    from arcgis_item_graph.query import ItemGraphQuery

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)

    mock_item = MagicMock()
    type(mock_item).deprecated = PropertyMock(
        side_effect=Exception("Item does not exist or is inaccessible.")
    )

    q = ItemGraphQuery.__new__(ItemGraphQuery)
    q.gis = MagicMock()
    q.gis._con.token = "fake-token"
    q.hydration_workers = 1

    # Patch GIS constructor used inside _hydrate_result_nodes workers
    mock_thread_gis = MagicMock()
    mock_thread_gis.content.get.return_value = mock_item

    with patch("arcgis_item_graph.query.GIS", return_value=mock_thread_gis):
        q._hydrate_result_nodes([node])

    assert node.item is None
    assert hasattr(node, "broken_reason")


