"""Shapeshift tools: shapeshift, shiftback, craft, connect, release."""

import asyncio
import contextlib
import dataclasses
import inspect as _inspect
import json
import os
import shlex
import time

import httpx
from mcp.server.fastmcp import Context

from kitsune_mcp.app import _registry_lock, mcp
from kitsune_mcp.constants import (
    TIMEOUT_PROMPT_LIST,
    TIMEOUT_RESOURCE_LIST,
    TRUST_HIGH,
    TRUST_LOW,
    TRUST_MEDIUM,
)
from kitsune_mcp.credentials import _credentials_guide, _credentials_ready
from kitsune_mcp.probe import _format_setup_guide
from kitsune_mcp.session import session
from kitsune_mcp.shapeshift import _json_type_to_py
from kitsune_mcp.tools import _state
from kitsune_mcp.transport import BaseTransport, _kill_process_tree, _process_pool
from kitsune_mcp.utils import _estimate_tokens, _is_safe_url, _ssrf_safe_request


async def _commit_shapeshift(
    server_id: str,
    transport: BaseTransport,
    tool_schemas: list,
    resolved_config: dict,
    tools: list[str] | None,
    ctx: Context,
    pool_key: str | None,
    trust_note: str,
    lean_eligible: bool = False,
) -> str:
    """Register tools/resources/prompts, update session, notify client, return output string.

    Called by both the pool-connection path and the registry path of shapeshift() so
    neither path has to duplicate the ~70-line registration + output block.
    """
    only = set(tools) if tools else None
    registered, reg_failures = _state._register_proxy_tools(
        server_id, tool_schemas, transport, resolved_config, _state._BASE_TOOL_NAMES, only
    )
    if not registered:
        return f"❌ shapeshift failed: no tools could be registered from '{server_id}'."

    shapeshift_resources: list[str] = []
    shapeshift_prompts: list[str] = []
    if hasattr(transport, "list_resources"):
        with contextlib.suppress(Exception):
            raw_res = await asyncio.wait_for(transport.list_resources(), timeout=TIMEOUT_RESOURCE_LIST)
            shapeshift_resources = _state._register_proxy_resources(transport, raw_res)
    if hasattr(transport, "list_prompts"):
        with contextlib.suppress(Exception):
            raw_prompts = await asyncio.wait_for(transport.list_prompts(), timeout=TIMEOUT_PROMPT_LIST)
            shapeshift_prompts = _state._register_proxy_prompts(transport, raw_prompts)

    session["shapeshift_tools"] = registered
    session["shapeshift_resources"] = shapeshift_resources
    session["shapeshift_prompts"] = shapeshift_prompts
    session["current_form"] = server_id
    session["current_form_pool_key"] = pool_key
    # True only for stdio transports that own a real subprocess; HTTP/SSE servers
    # have no backing process to kill so shiftback(kill=True) is a no-op for them.
    session["current_form_has_process"] = pool_key is not None

    # Record per-turn savings: if this server had been installed always-on, the
    # client would now be paying for its full schema in every turn. We mounted
    # it lazily instead. Keyed by server_id so re-mounts in the same session
    # don't double-count. Only counts what we actually registered (lean=subset).
    registered_names = set(registered)
    mounted_schemas = [
        ts for ts in tool_schemas
        if isinstance(ts, dict)
        and _state._register_proxy_tools  # truthy guard for static analysis
        and ts.get("name")
    ]
    # Filter by lean selection — only what's currently visible counts as "avoided".
    from kitsune_mcp.shapeshift import _proxy_name_for
    visible_schemas = [
        ts for ts in mounted_schemas
        if _proxy_name_for(server_id, ts.get("name", ""), _state._BASE_TOOL_NAMES) in registered_names
    ]
    mount_cost = _estimate_tokens(visible_schemas) if visible_schemas else 0
    if mount_cost > 0:
        # setdefault for resilience against tests that replace stats with a minimal dict
        session["stats"].setdefault("tokens_avoided_shapeshift", {})[server_id] = mount_cost

    with contextlib.suppress(Exception):
        await ctx.session.send_tool_list_changed()
    if shapeshift_resources:
        with contextlib.suppress(Exception):
            await ctx.session.send_resource_list_changed()
    if shapeshift_prompts:
        with contextlib.suppress(Exception):
            await ctx.session.send_prompt_list_changed()

    missing_env: list[str] = []
    with contextlib.suppress(Exception):
        missing_env = _state._probe_requirements(tool_schemas, "").get("missing_env", [])

    lean = f" (lean: {', '.join(tools)})" if tools else ""
    extras = []
    if shapeshift_resources:
        extras.append(f"{len(shapeshift_resources)} resource(s)")
    if shapeshift_prompts:
        extras.append(f"{len(shapeshift_prompts)} prompt(s)")
    extra_note = f" + {', '.join(extras)}" if extras else ""

    lines = [
        f"Shapeshifted into '{server_id}'{lean} — {len(registered)} tool(s){extra_note} registered:",
        *[f"  {t}" for t in registered],
    ]
    if shapeshift_resources:
        shown = ", ".join(shapeshift_resources[:3]) + (" ..." if len(shapeshift_resources) > 3 else "")
        lines.append(f"Resources ({len(shapeshift_resources)}): {shown}")
    if shapeshift_prompts:
        shown = ", ".join(shapeshift_prompts[:3]) + (" ..." if len(shapeshift_prompts) > 3 else "")
        lines.append(f"Prompts ({len(shapeshift_prompts)}): {shown}")
    example_tool = registered[0]
    example_args: dict = {}
    from kitsune_mcp.shapeshift import _proxy_name_for
    example_schema = next(
        (
            ts for ts in tool_schemas
            if isinstance(ts, dict)
            and _proxy_name_for(server_id, ts.get("name", ""), _state._BASE_TOOL_NAMES) == example_tool
        ),
        {},
    )
    schema = example_schema.get("inputSchema", {})
    required = schema.get("required", [])
    props = schema.get("properties", {})
    # Fill EVERY required param so beginners can copy/paste without hitting a
    # schema-validation error. Falling back to a type-based placeholder is fine —
    # the goal is to show "this is the shape of a valid call", not to invent
    # semantically-correct values.
    from kitsune_mcp.tools.onboarding import _PARAM_EXAMPLES
    for p in required:
        if p not in props:
            continue
        ptype = props[p].get("type", "string")
        example_args[p] = _PARAM_EXAMPLES.get(p, _state._EXAMPLE_VALUES.get(ptype, "value"))
    lines += ["", f"In this session: call({example_tool!r}, arguments={example_args!r})"]
    lines.append(trust_note)
    if missing_env:
        lines.append("\n⚠️  Credentials may be required — add to .env:")
        for var in missing_env:
            lines.append(f"  {var}=your-value")
        lines.append(f'  Or: auth("{missing_env[0]}", "your-value")')
    if reg_failures:
        lines.append(f"\n⚠️  {len(reg_failures)} tool(s) failed to register:")
        for fname, ferr in reg_failures:
            lines.append(f"  {fname}: {ferr}")
    if lean_eligible and not tools and len(registered) > 4:
        tool_cost = _estimate_tokens(tool_schemas)
        lines.append(
            f"\n💡 {len(registered)} tools loaded (~{tool_cost:,} tokens). "
            f"For lean mounting: shapeshift(\"{server_id}\", tools=[\"{registered[0]}\"])"
        )
    # Filesystem server needs allowed directories as CLI args — proactively hint
    # so users don't see a confusing "Access denied" without knowing the fix.
    if "filesystem" in server_id and pool_key:
        import json as _json
        cmd = _json.loads(pool_key)
        # Only show hint if no directories were passed (cmd ends at the package name)
        if not any(arg.startswith("/") or arg.startswith("~") for arg in cmd[2:]):
            from kitsune_mcp.tools.onboarding import _blocked
            lines.append("\n" + _blocked(
                what="filesystem server has no allowed directories — all paths denied",
                why="no directories were passed as server_args",
                fix=f'shapeshift("{server_id}", server_args=["/your/path"])',
            ))
    return "\n".join(lines)


async def _do_unmount(ctx, keep: bool) -> str:
    """Unmount current form. keep=True keeps process warm; keep=False kills and uninstalls."""
    return await shiftback(ctx, kill=not keep, uninstall=not keep)


@mcp.tool()
async def shapeshift(
    server_id: str = "",
    ctx: Context | None = None,
    tools: list[str] | None = None,
    keep: bool = False,
    confirm: bool = False,
    source: str = "auto",
    server_args: list[str] | None = None,
) -> str:
    """Mount an MCP server's tools at runtime. Empty server_id unmounts.

    shapeshift('mcp-server-time')          # mount
    shapeshift('id', tools=['only_this'])  # lean — mount only listed tools
    shapeshift()                           # unmount + kill process

    source: auto|local|smithery|official. confirm=True for community sources.
    """
    if not server_id:
        return await _do_unmount(ctx, keep=keep)

    # Pool connections (from connect()) take priority — user already vetted these, bypass trust gates
    for _pk, conn in session["connections"].items():
        if conn.get("name") == server_id or conn.get("command") == server_id:
            # Prefer pre-parsed argv stored at connect() time; fall back to shlex.split()
            # so quoted paths (e.g. "/path with spaces") are never mangled.
            cmd = conn.get("install_cmd") or shlex.split(conn["command"])
            tool_names = conn.get("tools", [])
            _state._do_shed()
            session["current_form_local_install"] = None

            transport: BaseTransport = _state.PersistentStdioTransport(cmd)
            raw_tools = await transport.list_tools()
            if not raw_tools and tool_names:
                raw_tools = [{"name": n, "description": "", "inputSchema": {}} for n in tool_names]

            return await _commit_shapeshift(
                server_id, transport, raw_tools, {}, tools, ctx,
                json.dumps(cmd, sort_keys=True),
                "\n⚠️  Source: pool connection (local — verify command before use)",
            )

    # Registry path — source controls which registries/transports are preferred
    if source == "smithery" and not _state._smithery_available():
        return (
            f"❌ shapeshift failed: source='smithery' requires SMITHERY_API_KEY (not set).\n\n"
            f"Set it: auth(\"SMITHERY_API_KEY\", \"your-key\")\n"
            f"Or use: shapeshift(\"{server_id}\", source=\"local\") to install locally."
        )

    auto_resolved_from: str | None = None
    if server_id.startswith(("http://", "https://")):
        srv = _state._synthetic_http_server(server_id)
    else:
        reg_source = source if source in ("smithery", "official") else None
        srv = await _state._registry.get_server(server_id, source_preference=reg_source)
        if srv is None:
            # Auto-recover from typos / wrong namespaces (e.g. "@modelcontextprotocol/server-time"
            # → "mcp-server-time"). Only fires for a single high-confidence match;
            # multiple candidates surface as suggestions, never silently picked.
            resolved_id, candidates = await _state._resolve_server_id(server_id)
            if resolved_id and resolved_id != server_id:
                resolved_srv = await _state._registry.get_server(resolved_id, source_preference=reg_source)
                if resolved_srv is not None:
                    auto_resolved_from = server_id
                    server_id = resolved_id
                    srv = resolved_srv
            if srv is None:
                if candidates:
                    suggestions = "\n".join(f"  - {c}" for c in candidates)
                    return (
                        f"❌ shapeshift failed: server '{server_id}' not found.\n"
                        f"Did you mean one of these?\n{suggestions}\n"
                        f"Retry: shapeshift(\"{candidates[0]}\")"
                    )
                return (
                    f"❌ shapeshift failed: server '{server_id}' not found in any registry.\n"
                    f"Use search() to find servers, or connect() for local servers."
                )

    srv_source = srv.source

    # Check source constraint first — clearer error than the trust gate when source="official" resolves non-official
    if source == "official" and srv_source not in ("official", "mcpregistry"):
        return (
            f"❌ shapeshift failed: no official/verified listing for '{server_id}' (resolved source: {srv_source}).\n"
            f"Try: shapeshift(\"{server_id}\") for auto, or shapeshift(\"{server_id}\", source=\"local\")."
        )

    trust_level = (os.getenv("KITSUNE_TRUST") or "").lower()
    _trust_override = trust_level in ("community", "all", "low")

    if srv_source in TRUST_LOW and not confirm and not _trust_override:
        preview_lines = []
        if srv.tools:
            names = ", ".join(t.get("name", "?") for t in srv.tools[:8])
            suffix = f" +{len(srv.tools) - 8} more" if len(srv.tools) > 8 else ""
            preview_lines.append(f"Tools ({len(srv.tools)}): {names}{suffix}")
        cred_status = _credentials_ready(srv.credentials, srv_source)
        preview_lines.append(f"Credentials: {cred_status}")
        preview = ("\n" + "\n".join(preview_lines) + "\n") if preview_lines else "\n"
        return (
            f"⚠️  '{server_id}' is from {srv_source} (community — not verified by the official MCP registry)."
            f"{preview}"
            f"To proceed: shapeshift('{server_id}', confirm=True)\n"
            f"To always trust community: auth(\"KITSUNE_TRUST\", \"community\")"
        )

    if source == "local" and not confirm and not _trust_override:
        install_cmd = (srv.install_cmd or _state._infer_install_cmd(server_id)) + (server_args or [])
        return (
            f"⚠️  source='local' will run: {' '.join(install_cmd)}\n\n"
            f"This downloads and executes the package locally.\n"
            f"Review first: inspect('{server_id}')\n\n"
            f"To proceed: shapeshift('{server_id}', source='local', confirm=True)\n"
            f"To always trust local installs: key(\"KITSUNE_TRUST\", \"community\")"
        )

    # Pre-flight gate: Smithery-hosted servers always need SMITHERY_API_KEY
    # regardless of whether srv.credentials declares per-server creds. This
    # prevents the most common first-run failure where the agent shapeshifts
    # successfully, then hits "Auth failed" on the first tool call.
    if srv_source == "smithery" and not _state._smithery_available() and not confirm:
        return (
            f"❌ shapeshift failed: '{server_id}' is hosted on Smithery and needs SMITHERY_API_KEY.\n"
            f"\n"
            f"  → Get a key: https://smithery.ai/account/api-keys\n"
            f'  → Then: auth("SMITHERY_API_KEY", "sm-...") and retry shapeshift("{server_id}")\n'
            f"\n"
            f'  Or use: shapeshift("{server_id}", source="local", confirm=True)\n'
            f"        to install locally without a Smithery key (community trust gate applies)."
        )

    # All gates passed — resolve credentials before dropping current form
    resolved_config, missing = _state._resolve_config(srv.credentials, {})
    if missing:
        creds_msg = _credentials_guide(server_id, srv.credentials, resolved_config)
        return f"❌ shapeshift failed: missing credentials for '{server_id}':\n\n{creds_msg}"

    # Validate source="local" against HTTP-only servers BEFORE shedding — returning an
    # error after _do_shed() would drop the user's current form silently.
    if source == "local" and srv.transport == "http" and not srv.install_cmd:
        return (
            f"❌ source='local' not available for '{server_id}'.\n\n"
            f"This server is HTTP-only on Smithery — no local stdio package is listed.\n"
            f"Options:\n"
            f"  • shapeshift(\"{server_id}\") — use Smithery Connect (needs SMITHERY_API_KEY)\n"
            f"  • search(\"{server_id.split('/')[-1]}\") — find a stdio/npm alternative\n"
            f"  • If an npm package exists, shapeshift it directly:\n"
            f'    shapeshift("@scope/pkg-name", source="local", confirm=True)'
        )

    _shapeshift_started = time.monotonic()

    # _registry_lock serialises all shed→register sequences. Without it a concurrent
    # shapeshift() could interleave: A sheds, B sheds (no-op), A registers, B registers —
    # leaving both servers' tools mounted while session only tracks B's tools.
    async with _registry_lock:
        _state._do_shed()
        session["current_form_local_install"] = None  # overwritten below for source="local"

        _original_transport = srv.transport  # track before local override for honest labelling
        if source == "local":
            install_cmd = srv.install_cmd or _state._infer_install_cmd(server_id)
            srv = dataclasses.replace(srv, transport="stdio", install_cmd=install_cmd)
            session["current_form_local_install"] = {"cmd": srv.install_cmd, "package": server_id}

        if srv.transport == "stdio":
            cmd = (srv.install_cmd or ["npx", "-y", server_id]) + (server_args or [])
            # PersistentStdioTransport keeps the process alive for subsequent tool calls
            transport = _state.PersistentStdioTransport(cmd)
            pool_key: str | None = json.dumps(cmd, sort_keys=True)
            tool_schemas = srv.tools or []
            if not tool_schemas:
                with contextlib.suppress(Exception):
                    tool_schemas = await transport.list_tools()
        else:
            transport = _state._get_transport(server_id, srv)
            pool_key = None
            tool_schemas = srv.tools or []
            if not tool_schemas and hasattr(transport, "list_tools"):
                tool_schemas = await transport.list_tools(resolved_config)

        if not tool_schemas:
            return f"❌ shapeshift failed: no tools found for '{server_id}'. Try inspect() first."

        # Only show "via local npx/uvx" when a real local process was started.
        _actually_local = source == "local" or _original_transport == "stdio"
        transport_label = " via local npx/uvx" if _actually_local and srv.transport == "stdio" else ""
        elapsed = time.monotonic() - _shapeshift_started
        timing = f" ({elapsed:.1f}s{'  — warm calls will be instant' if elapsed > 3 else ''})"
        if srv_source in TRUST_HIGH | TRUST_MEDIUM:
            trust_note = f"\n✓  Source: {srv_source}{transport_label}{timing}"
        else:
            trust_note = f"\n⚠️  Source: {srv_source}{transport_label} (community — not verified by official MCP registry){timing}"
        if auto_resolved_from is not None:
            trust_note = f"\n🦊  Auto-resolved from '{auto_resolved_from}' → '{server_id}'" + trust_note

        return await _commit_shapeshift(
            server_id, transport, tool_schemas, resolved_config, tools, ctx,
            pool_key, trust_note, lean_eligible=True,
        )


@mcp.tool()
async def shiftback(ctx: Context, kill: bool = True, uninstall: bool = False) -> str:
    """Unmount current server. kill=False keeps process pooled. uninstall=True removes local package."""
    async with _registry_lock:
        has_tools = bool(session["shapeshift_tools"])
        has_resources = bool(session.get("shapeshift_resources"))
        has_prompts = bool(session.get("shapeshift_prompts"))
        if not has_tools and not has_resources and not has_prompts:
            return "Already in base form."

        form = session["current_form"]
        local_install = session.pop("current_form_local_install", None)
        # Snapshot counts before _do_shed() clears the lists
        n_res = len(session.get("shapeshift_resources", []))
        n_prompts = len(session.get("shapeshift_prompts", []))
        removed = _state._do_shed()
    # Lock released — kill/uninstall I/O runs outside the lock

    with contextlib.suppress(Exception):
        await ctx.session.send_tool_list_changed()
    if n_res:
        with contextlib.suppress(Exception):
            await ctx.session.send_resource_list_changed()
    if n_prompts:
        with contextlib.suppress(Exception):
            await ctx.session.send_prompt_list_changed()

    extras = []
    if n_res:
        extras.append(f"{n_res} resource(s)")
    if n_prompts:
        extras.append(f"{n_prompts} prompt(s)")
    extra_note = f", {', '.join(extras)}" if extras else ""

    result_lines = [f"Shifted back from '{form}'. Removed: {', '.join(removed)}{extra_note}"]

    if (kill or uninstall) and form:
        # Use the exact pool key stored at shapeshift() time. If missing (stale session /
        # edge case), do NOT fall back to killing all pool entries — that would terminate
        # unrelated connect() sessions. HTTP/SSE servers have no backing process and
        # pool_key is None by design — silently skip rather than surfacing an alarming warning.
        exact_key = session.pop("current_form_pool_key", None)
        has_process = session.pop("current_form_has_process", None)
        killed = []
        if not exact_key and has_process is True:
            # Truly unexpected: was a stdio server but lost its pool key.
            # Suppressed for has_process is False (HTTP/SSE — no local process by design)
            # and has_process is None (session restored from disk — can't reliably tell).
            result_lines.append(
                "⚠️  Could not identify the backing process (pool key missing) — "
                "use release() to kill specific connections by name."
            )
        keys_to_check = [exact_key] if exact_key else []
        for pool_key in keys_to_check:
            entry = _process_pool.get(pool_key)
            if entry is None:
                continue
            _kill_process_tree(entry.proc)
            with contextlib.suppress(Exception):
                await asyncio.wait_for(entry.proc.wait(), timeout=TIMEOUT_RESOURCE_LIST)
            _process_pool.pop(pool_key, None)
            killed.append(entry.name or entry.install_cmd[0])
        if killed:
            result_lines.append(f"Released: {', '.join(killed)}")

    if uninstall and local_install:
        uninstall_cmd = _state._local_uninstall_cmd(local_install["cmd"])
        pkg = local_install["package"]
        if uninstall_cmd:
            try:
                proc = await asyncio.create_subprocess_exec(
                    *uninstall_cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
                if proc.returncode == 0:
                    result_lines.append(f"Uninstalled: {pkg}")
                else:
                    err = stderr.decode().strip()[:120]
                    result_lines.append(f"Uninstall failed ({pkg}): {err}")
            except Exception as e:
                result_lines.append(f"Uninstall error ({pkg}): {e}")
        else:
            # npx packages are cached, not permanently installed — no action needed
            result_lines.append(f"Note: '{pkg}' was run via npx (cached, not permanently installed — cache expires automatically)")
    elif local_install and not uninstall:
        pkg = local_install["package"]
        result_lines.append(f"Local package '{pkg}' is still cached. To clean up: shapeshift()")

    return "\n".join(result_lines)


@mcp.tool()
async def craft(
    ctx: Context,
    name: str,
    description: str,
    params: dict,
    url: str,
    method: str = "POST",
    headers: dict | None = None,
) -> str:
    """Register a custom tool backed by your HTTP endpoint — live immediately. POST=JSON body, GET=query params. shiftback() removes it."""
    if not name or not name.replace("_", "").isalnum():
        return "name must be alphanumeric (underscores allowed)."
    if not url.startswith(("http://", "https://")):
        return "url must start with http:// or https://"
    if not _is_safe_url(url) and not os.getenv("KITSUNE_ALLOW_LOCAL_FETCH"):
        return (
            f"Blocked: '{url}' is a private/loopback address. "
            "Set KITSUNE_ALLOW_LOCAL_FETCH=1 to allow local URLs."
        )

    _url = url
    _method = method.upper()
    _headers = headers or {}

    # Build Python parameters from JSON Schema properties
    py_params = []
    for pname, pschema in (params or {}).items():
        json_type = pschema.get("type", "string") if isinstance(pschema, dict) else "string"
        ptype = _json_type_to_py(json_type)
        py_params.append(_inspect.Parameter(
            pname, _inspect.Parameter.KEYWORD_ONLY,
            default=_inspect.Parameter.empty, annotation=ptype,
        ))

    async def _endpoint_proxy(**kwargs) -> str:
        try:
            # _ssrf_safe_request validates each redirect hop to block SSRF via
            # open redirects on otherwise-trusted public hosts.
            if _method == "GET":
                r = await _ssrf_safe_request("GET", _url, params=kwargs, headers=_headers, timeout=30.0)
            else:
                r = await _ssrf_safe_request(_method, _url, json_body=kwargs, headers=_headers, timeout=30.0)
            r.raise_for_status()
            return r.text
        except httpx.HTTPStatusError as e:
            return f"HTTP {e.response.status_code} from {_url}: {e.response.text[:200]}"
        except Exception as e:
            return f"Error calling {_url}: {e}"

    _endpoint_proxy.__name__ = name
    _endpoint_proxy.__doc__ = description[:120]
    _endpoint_proxy.__signature__ = _inspect.Signature(py_params, return_annotation=str)

    # Remove previous registration if re-crafting the same name
    if name in session["crafted_tools"]:
        with contextlib.suppress(Exception):
            mcp.remove_tool(name)
        session["shapeshift_tools"] = [t for t in session["shapeshift_tools"] if t != name]

    try:
        mcp.add_tool(_endpoint_proxy)
    except Exception as e:
        return f"Failed to register tool '{name}': {e}"

    session["crafted_tools"][name] = {
        "url": url, "method": _method, "description": description, "params": params or {},
    }
    if name not in session["shapeshift_tools"]:
        session["shapeshift_tools"].append(name)

    with contextlib.suppress(Exception):
        await ctx.session.send_tool_list_changed()

    param_list = ", ".join(params.keys()) if params else "(none)"
    return (
        f"✓ Tool '{name}' registered — {_method} {url}\n"
        f"Params: {param_list}\n\n"
        f"Call it directly, or shiftback() to remove it."
    )


@mcp.tool()
async def connect(command: str, name: str = "", timeout: int = 60, inherit_stderr: bool = True) -> str:
    """Start a persistent server. command: server_id or shell cmd (e.g. 'uvx voice-mode'). name: alias for release()."""
    # Detect server_id vs shell command: if it has no spaces and doesn't start with a
    # known executor, try registry lookup first.
    _EXECUTORS = ("npx", "uvx", "node", "python", "python3", "uv", "deno", "docker")
    looks_like_cmd = " " in command or command.split()[0] in _EXECUTORS
    install_cmd: list[str] | None = None

    if not looks_like_cmd:
        srv = await _state._registry.get_server(command)
        if srv and srv.install_cmd:
            install_cmd = srv.install_cmd
            if not name:
                name = srv.name or command

    if install_cmd is None:
        install_cmd = shlex.split(command)
    pool_key = json.dumps(install_cmd, sort_keys=True)
    friendly = name or install_cmd[0]

    # Already connected?
    existing = _process_pool.get(pool_key)
    if existing is not None and existing.is_alive():
        uptime = int(existing.uptime_seconds())
        calls = existing.call_count
        label = existing.name or friendly
        return (
            f"Already connected: {label} (PID {existing.pid()}) | "
            f"uptime: {uptime}s | calls: {calls}"
        )

    transport = _state.PersistentStdioTransport(install_cmd, inherit_stderr=inherit_stderr)
    try:
        entry = await asyncio.wait_for(transport._start_process(), timeout=timeout)
    except TimeoutError:
        return f"Timeout starting '{command}' after {timeout}s."
    except RuntimeError as e:
        return str(e)

    entry.name = friendly

    # Fetch tool list from live process
    tools = await transport.list_tools()
    tool_names = [t.get("name", "?") for t in tools]

    resource_text = await _state._fetch_resource_docs(transport)

    # Update session connections
    session["connections"][pool_key] = {
        "name": friendly,
        "command": command,
        "install_cmd": install_cmd,  # parsed argv — avoids shlex.split() at shapeshift time
        "pid": entry.pid(),
        "started_at": entry.started_at,
        "tools": tool_names,
    }

    tool_summary = f"Tools ({len(tool_names)}): {', '.join(tool_names)}" if tool_names else "Tools: none listed"
    setup_guide = _format_setup_guide(_state._probe_requirements(tools, resource_text), friendly, tools=tools)

    # Trust / source note — resolve from registry if possible, otherwise flag as local
    _conn_srv = await _state._registry.get_server(command) if not looks_like_cmd else None
    conn_source = _conn_srv.source if _conn_srv else "local"
    if conn_source in TRUST_HIGH | TRUST_MEDIUM:
        trust_note = f"✓  Source: {conn_source}"
    else:
        trust_note = f"⚠️  Source: {conn_source} (verify command before connecting)"

    parts = [
        f"Connected: {friendly} (PID {entry.pid()})",
        tool_summary,
        f"Release with: release('{friendly}')",
    ]
    if setup_guide:
        parts.append(setup_guide)
        parts.append(f"\nCall setup('{friendly}') for step-by-step guidance.")
    parts.append(trust_note)
    return "\n".join(parts)


@mcp.tool()
async def release(name: str) -> str:
    """Kill a persistent connection by name."""
    # Find entry by name or pool_key
    found_key = None
    found_entry = None

    for pool_key, entry in _process_pool.items():
        if entry.name == name or pool_key == name:
            found_key = pool_key
            found_entry = entry
            break

    if found_key is None or found_entry is None:
        active = [e.name or k for k, e in _process_pool.items()]
        if active:
            return f"No connection named '{name}'. Active: {', '.join(active)}"
        return "No active connections. Use connect() to start one."

    uptime = int(found_entry.uptime_seconds())
    calls = found_entry.call_count
    pid = found_entry.pid()
    label = found_entry.name or found_key

    _kill_process_tree(found_entry.proc)
    with contextlib.suppress(Exception):
        await asyncio.wait_for(found_entry.proc.wait(), timeout=TIMEOUT_RESOURCE_LIST)

    _process_pool.pop(found_key, None)
    session["connections"].pop(found_key, None)

    return f"Released: {label} (PID {pid}) | uptime: {uptime}s | calls: {calls}"
