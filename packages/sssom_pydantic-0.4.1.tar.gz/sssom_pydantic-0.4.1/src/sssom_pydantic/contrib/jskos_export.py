"""Convert semantic mappings into JSKOS format."""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

import curies
from curies import NamableReference, Reference

import sssom_pydantic
from sssom_pydantic import SemanticMapping

if TYPE_CHECKING:
    import jskos
    from jskos.api import ProcessedJSKOSSet

    from sssom_pydantic import MappingSet, MappingSetRecord, Metadata

__all__ = [
    "from_jskos",
    "from_jskos_path",
    "to_jskos",
]


def to_jskos(
    mappings: SemanticMapping | list[SemanticMapping],
    *,
    metadata: MappingSet | Metadata | MappingSetRecord | None = None,
    converter: curies.Converter | None = None,
) -> jskos.Concept:
    """Convert mapping(s) to JSKOS using sssom-js.

    :param mappings: a SemanticMapping or a list of SemanticMappings
    :param metadata: metadata about the mapping set
    :param converter: a Converter object

    :returns: a JSKOS concept representing the mapping set, with mappings contained
        within

    .. warning::

        JSKOS does not yet support all SSSOM fields, so a round trip is not possible
    """
    if isinstance(mappings, SemanticMapping):
        mappings = [mappings]
    with tempfile.TemporaryDirectory() as temporary_directory:
        path = Path(temporary_directory).joinpath("tmp.sssom.tsv")
        sssom_pydantic.write(
            mappings,
            path,
            metadata=metadata,
            converter=converter,
        )
        return _path_to_jskos(path)


def from_jskos(concept: jskos.Concept, converter: curies.Converter) -> list[SemanticMapping]:
    """Get mappings from a JSKOS mapping.

    :param concept: a JSKOS concept, which contains ``mappings``
    :param converter: a Converter object used to process the JSKOS object

    :returns: A list of SSSOM mappings

    .. warning::

        JSKOS does not yet support all SSSOM fields, so a round trip is not possible
    """
    return [
        m
        for mapping in concept.mappings or []
        if (m := _process_jskos_mapping(mapping, converter)) is not None
    ]


def _process_metadata(concept: jskos.Concept) -> MappingSet:
    raise NotImplementedError("metadata processing not yet implemented")


def _process_jskos_mapping(
    jskos_mapping: jskos.Mapping, converter: curies.Converter
) -> SemanticMapping | None:
    processed_mapping = jskos_mapping.process(converter)

    subject_member_set = processed_mapping.from_bundle.member_set
    object_member_set = processed_mapping.to_bundle.member_set
    if not subject_member_set or not object_member_set or not processed_mapping.type:
        return None

    subject = _from_set(subject_member_set)
    predicate = processed_mapping.type[0]
    obj = _from_set(object_member_set)

    justification = processed_mapping.justification

    # `und` means undefined language
    if processed_mapping.note and "und" in processed_mapping.note:
        comment = processed_mapping.note["und"][0]
    else:
        comment = None

    return SemanticMapping(
        subject=subject,
        predicate=predicate,
        object=obj,
        justification=justification,
        comment=comment,
        authors=_extract_references(processed_mapping.contributor),
        creators=_extract_references(processed_mapping.creator),
        mapping_date=processed_mapping.created,
    )


def _extract_references(
    contributors: ProcessedJSKOSSet | None,
) -> list[Reference] | None:
    if contributors is None:
        return None
    return [
        contributor.reference
        for contributor in contributors
        if contributor and contributor.reference
    ]


def _from_set(member_set: list[jskos.ProcessedConcept]) -> NamableReference:
    processed_concept = member_set[0]
    reference = processed_concept.reference
    if reference is None:
        raise ValueError
    if processed_concept.preferred_label is None or "und" not in processed_concept.preferred_label:
        label = None
    else:
        label = processed_concept.preferred_label["und"]
    return NamableReference(prefix=reference.prefix, identifier=reference.identifier, name=label)


def from_jskos_path(path: Path, converter: curies.Converter) -> list[SemanticMapping]:
    """Convert SSSOM TSV to JSKOS using sssom-js."""
    from jskos import Concept

    concept = Concept.model_validate_json(path.read_text())
    return from_jskos(concept, converter)


def _path_to_jskos(sssom_tsv_path: Path) -> jskos.Concept:
    """Convert SSSOM TSV to JSKOS using sssom-js."""
    import jskos

    text = _convert(sssom_tsv_path, "tsv", "jskos")
    return jskos.Concept.model_validate_json(text)


def _convert(input_path: Path, input_format: str, output_format: str) -> str:
    with tempfile.TemporaryDirectory() as temporary_directory:
        # Convert the SSSOM TSV to JSKOS using the sssom-js package
        # on NPM (https://www.npmjs.com/package/sssom-js)
        output_path = Path(temporary_directory).joinpath("tmp.sssom.json")
        result = subprocess.run(  # noqa:S603
            [  # noqa:S607
                "npx",
                "sssom-js",
                "--from",
                input_format,
                "--to",
                output_format,
                "--output",
                output_path.as_posix(),
                input_path.as_posix(),
            ],
            stderr=subprocess.PIPE,
        )
        if not output_path.is_file():
            raise ValueError(
                f"sssom-js produced no output.\n\nstderr: {result.stderr.decode('utf-8')}"
            )
        text = output_path.read_text()
        if not text:
            raise ValueError(
                f"sssom-js produced no output.\n\nstderr: {result.stderr.decode('utf-8')}"
            )
        return text
