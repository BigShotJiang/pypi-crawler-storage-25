"""Database model.

.. code-block:: python

    from sssom_pydantic.database import SemanticMappingDatabase
    from sssom_pydantic.api import mapping_hash_v1

    database = SemanticMappingDatabase.memory(semantic_mapping_hash=mapping_hash_v1)
    database.read("https://w3id.org/biopragmatics/biomappings/biomappings.sssom.tsv")
"""

from __future__ import annotations

import contextlib
import datetime
from collections.abc import Callable, Generator, Iterable, Sequence
from typing import TYPE_CHECKING, Any, ClassVar, Literal, ParamSpec, TypeVar, cast, overload

import curies
import sqlmodel
from curies import NamableReference, Reference
from curies.database import get_reference_list_sa_column, get_reference_sa_column
from curies.vocabulary import manual_mapping_curation
from pydantic import AnyUrl
from sqlalchemy import Dialect, TypeDecorator
from sqlalchemy.engine.base import Engine
from sqlalchemy.sql.type_api import TypeEngine
from sqlmodel import JSON, Column, Field, Session, SQLModel, String, and_, col, func, or_, select
from sqlmodel.sql._expression_select_cls import SelectOfScalar
from tqdm import tqdm
from typing_extensions import Self

from sssom_pydantic.api import MappingTool, SemanticMapping, SemanticMappingHash
from sssom_pydantic.database.repo import CURIENotFoundError, SemanticMappingRepository
from sssom_pydantic.models import Cardinality
from sssom_pydantic.query import Query, Sort

if TYPE_CHECKING:
    from sqlalchemy.sql.selectable import ColumnExpressionArgument  # type:ignore[attr-defined]

__all__ = [
    "DEFAULT_SORT",
    "NEGATIVE_MAPPING_CLAUSE",
    "POSITIVE_MAPPING_CLAUSE",
    "QUERY_TO_CLAUSE",
    "UNCURATED_NOT_UNSURE_CLAUSE",
    "UNCURATED_UNSURE_CLAUSE",
    "SemanticMappingDatabase",
    "SemanticMappingModel",
    "clauses_from_query",
]

X = TypeVar("X")
P = ParamSpec("P")


class MappingToolTypeDecorator(TypeDecorator[MappingTool]):
    """A SQLAlchemy type decorator for a mapping tool."""

    impl: ClassVar[type[TypeEngine[str]]] = JSON  # type:ignore[misc]
    #: Set SQLAlchemy caching to true
    cache_ok: ClassVar[bool] = True  # type:ignore[misc]

    def process_bind_param(
        self, value: MappingTool | None, dialect: Dialect
    ) -> dict[str, Any] | None:
        """Convert the Python object into a database value."""
        if value is None:
            return None
        return value.model_dump()

    def process_result_value(
        self, value: dict[str, Any] | None, dialect: Dialect
    ) -> MappingTool | None:
        """Convert the database value into a Python object."""
        if value is None:
            return None
        return MappingTool.model_validate(value)


class AnyURLTypeDecorator(TypeDecorator[AnyUrl]):
    """A SQLAlchemy type decorator for a URL."""

    impl: ClassVar[type[TypeEngine[str]]] = String  # type:ignore[misc]
    #: Set SQLAlchemy caching to true
    cache_ok: ClassVar[bool] = True  # type:ignore[misc]

    def process_bind_param(self, value: AnyUrl | None, dialect: Dialect) -> str | None:
        """Convert the Python object into a database value."""
        if value is None:
            return None
        return str(value)

    def process_result_value(self, value: str | None, dialect: Dialect) -> AnyUrl | None:
        """Convert the database value into a Python object."""
        if value is None:
            return None
        return AnyUrl(value)


class SemanticMappingModel(SQLModel, table=True):
    """A model."""

    id: int | None = Field(
        default=None, primary_key=True, description="The identifier for the SSSOM record"
    )
    triple_id: str = Field(
        ..., index=True, description="The identifier for the subject-predicate-object triple"
    )

    # required
    subject: Reference = Field(..., sa_column=get_reference_sa_column())
    subject_name: str | None = Field(None)
    predicate: Reference = Field(..., sa_column=get_reference_sa_column())
    predicate_name: str | None = Field(None)
    object: Reference = Field(..., sa_column=get_reference_sa_column())
    object_name: str | None = Field(None)
    justification: Reference = Field(..., sa_column=get_reference_sa_column())
    predicate_modifier: Literal["Not"] | None = Field(None, sa_type=String)

    # core
    record: Reference | None = Field(
        None, sa_column=get_reference_sa_column(unique=True, index=True)
    )
    authors: list[Reference] | None = Field(None, sa_column=get_reference_list_sa_column())
    confidence: float | None = Field(None)
    mapping_tool: MappingTool | None = Field(None, sa_column=Column(MappingToolTypeDecorator()))
    license: str | None = Field(None)

    # rest
    subject_category: Reference | None = Field(None, sa_column=get_reference_sa_column())
    subject_match_field: list[Reference] | None = Field(
        None, sa_column=get_reference_list_sa_column()
    )
    subject_preprocessing: list[Reference] | None = Field(
        None, sa_column=get_reference_list_sa_column()
    )
    subject_source: Reference | None = Field(None, sa_column=get_reference_sa_column())
    subject_source_version: str | None = Field(None)
    subject_type: Reference | None = Field(None, sa_column=get_reference_sa_column())

    predicate_type: Reference | None = Field(None, sa_column=get_reference_sa_column())

    object_category: Reference | None = Field(None, sa_column=get_reference_sa_column())
    object_match_field: list[Reference] | None = Field(
        None, sa_column=get_reference_list_sa_column()
    )
    object_preprocessing: list[Reference] | None = Field(
        None, sa_column=get_reference_list_sa_column()
    )
    object_source: Reference | None = Field(None, sa_column=get_reference_sa_column())
    object_source_version: str | None = Field(None)
    object_type: Reference | None = Field(None, sa_column=get_reference_sa_column())

    creators: list[Reference] | None = Field(None, sa_column=get_reference_list_sa_column())
    reviewers: list[Reference] | None = Field(None, sa_column=get_reference_list_sa_column())

    publication_date: datetime.date | None = Field(None)
    mapping_date: datetime.date | None = Field(None)
    review_date: datetime.date | None = Field(None)
    reviewer_agreement: float | None = Field(None)

    comment: str | None = Field(None)
    curation_rule: list[Reference] | None = Field(None, sa_column=get_reference_list_sa_column())
    curation_rule_text: list[str] | None = Field(None, sa_type=JSON)
    issue_tracker_item: Reference | None = Field(None, sa_column=get_reference_sa_column())

    #: see https://mapping-commons.github.io/sssom/MappingCardinalityEnum/
    #: and https://w3id.org/sssom/mapping_cardinality
    cardinality: Cardinality | None = Field(None, sa_type=String)
    cardinality_scope: list[str] | None = Field(None, sa_type=JSON)
    # https://w3id.org/sssom/mapping_provider
    provider: AnyUrl | None = Field(None, sa_column=Column(AnyURLTypeDecorator()))
    # https://w3id.org/sssom/mapping_source
    source: Reference | None = Field(None, sa_column=get_reference_sa_column())

    match_string: list[str] | None = Field(None, sa_type=JSON)

    other: dict[str, str] | None = Field(None, sa_type=JSON)
    see_also: list[str] | None = Field(None, sa_type=JSON)
    similarity_measure: str | None = Field(None)
    similarity_score: float | None = Field(None)

    @classmethod
    def from_semantic_mapping(
        cls, mapping: SemanticMapping, *, converter: curies.Converter
    ) -> Self:
        """Get from a non-ORM mapping."""
        d = mapping.model_dump(exclude_none=True, exclude_unset=True, exclude_defaults=True)
        # do this explicitly since the model might not be smart enough
        # to fully dump a NamableReference, since it's only annotated
        # as a regular Reference
        if subject_name := mapping.subject_name:
            d["subject_name"] = subject_name
        if predicate_name := mapping.predicate_name:
            d["predicate_name"] = predicate_name
        if object_name := mapping.object_name:
            d["object_name"] = object_name
        d["triple_id"] = converter.hash_triple(mapping)
        return cls.model_validate(d)

    def to_semantic_mapping(self) -> SemanticMapping:
        """Get a non-ORM mapping."""
        # exclude_unset=True breaks it
        d = self.model_dump(exclude_none=True, exclude_defaults=True)
        if subject_name := d.pop("subject_name", None):
            d["subject"]["name"] = subject_name
            d["subject"] = NamableReference.model_validate(d["subject"])
        if predicate_name := d.pop("predicate_name", None):
            d["predicate"]["name"] = predicate_name
            d["predicate"] = NamableReference.model_validate(d["predicate"])
        if object_name := d.pop("object_name", None):
            d["object"]["name"] = object_name
            d["object"] = NamableReference.model_validate(d["object"])
        return SemanticMapping.model_validate(d)


class SemanticMappingDatabase(SemanticMappingRepository):
    """A repository of semantic mappings in a SQL database, implemented using :mod:`sqlalchemy`."""

    def __init__(
        self,
        *,
        engine: Engine,
        semantic_mapping_hash: SemanticMappingHash | None = None,
        session_cls: type[Session] | None = None,
        converter: curies.Converter,
    ) -> None:
        """Construct a database.

        :param engine: SQLAlchemy engine instance
        :param semantic_mapping_hash: A function that deterministically hashes a
            mapping. This is required until the SSSOM specification `defines a standard
            hashing procedure <https://github.com/mapping-commons/sssom/issues/436>`_.
        :param session_cls: SQLAlchemy session class. By default, this uses
            :class:`sqlmodel.Session`
        """
        self.engine = engine
        self.session_cls = session_cls if session_cls is not None else Session
        SQLModel.metadata.create_all(self.engine)
        # TODO converter inside database?
        super().__init__(semantic_mapping_hash=semantic_mapping_hash, converter=converter)

    @classmethod
    def from_connection(
        cls,
        *,
        connection: str,
        semantic_mapping_hash: SemanticMappingHash | None = None,
        session_cls: type[Session] | None = None,
        converter: curies.Converter,
    ) -> Self:
        """Construct a database by a connection string."""
        return cls(
            engine=sqlmodel.create_engine(connection),
            semantic_mapping_hash=semantic_mapping_hash,
            session_cls=session_cls,
            converter=converter,
        )

    @classmethod
    def memory(
        cls,
        *,
        semantic_mapping_hash: SemanticMappingHash | None = None,
        session_cls: type[Session] | None = None,
        converter: curies.Converter,
    ) -> Self:
        """Construct an in-memory database."""
        return cls.from_connection(
            connection="sqlite:///:memory:",
            semantic_mapping_hash=semantic_mapping_hash,
            session_cls=session_cls,
            converter=converter,
        )

    @contextlib.contextmanager
    def get_session(self) -> Generator[Session, None, None]:
        """Open a context manager for a session."""
        with contextlib.closing(self.session_cls(self.engine)) as session:
            yield session

    def count_mappings(
        self, query: Query | list[ColumnExpressionArgument[bool]] | None = None
    ) -> int:
        """Count the mappings in the database."""
        with self.get_session() as session:
            statement = select(func.count()).select_from(SemanticMappingModel)
            statement = _apply_where_clauses(statement, query)
            return session.exec(statement).one()

    def count_entities(
        self, query: Query | list[ColumnExpressionArgument[bool]] | None = None
    ) -> int:
        """Count the mappings in the database."""
        with self.get_session() as session:
            sources = _apply_where_clauses(  # type:ignore[var-annotated]
                select(col(SemanticMappingModel.source).label("entity_id")), query
            )
            targets = _apply_where_clauses(  # type:ignore[var-annotated]
                select(col(SemanticMappingModel.object).label("entity_id")), query
            )
            all_entities = sqlmodel.union(sources, targets).subquery()
            return session.exec(select(func.count()).select_from(all_entities)).one()

    def add_mappings(
        self, mappings: Iterable[SemanticMapping], *, progress: bool = False
    ) -> list[Reference]:
        """Add mappings to the database."""
        rv: list[Reference] = []
        with self.get_session() as session:
            for mapping in tqdm(
                mappings,
                unit_scale=True,
                desc="Adding SSSOM records to session",
                disable=not progress,
                leave=False,
            ):
                reference = self.hash_mapping(mapping)
                session.add(
                    SemanticMappingModel.from_semantic_mapping(
                        mapping.model_copy(update={"record": reference}),
                        converter=self.converter,
                    )
                )
                rv.append(reference)
            session.commit()
        return rv

    @staticmethod
    def _get_mapping_by_reference(reference: Reference) -> SelectOfScalar[SemanticMappingModel]:
        return select(SemanticMappingModel).where(SemanticMappingModel.record == reference)

    def delete_mapping(self, reference: Reference | SemanticMapping) -> None:
        """Delete a mapping from the database."""
        reference = self._ensure(reference)
        with self.get_session() as session:
            if obj := session.exec(self._get_mapping_by_reference(reference)).first():
                session.delete(obj)
                session.commit()

    # docstr-coverage:excused `overload`
    @overload
    def get_mapping(
        self, reference: Reference, *, strict: Literal[True] = ...
    ) -> SemanticMapping: ...

    # docstr-coverage:excused `overload`
    @overload
    def get_mapping(
        self, reference: Reference, *, strict: Literal[False] = ...
    ) -> SemanticMapping | None: ...

    def get_mapping(self, reference: Reference, *, strict: bool = False) -> SemanticMapping | None:
        """Get a mapping."""
        with self.get_session() as session:
            rv = session.exec(self._get_mapping_by_reference(reference)).first()
            if rv is not None:
                return rv.to_semantic_mapping()
            elif strict:
                raise CURIENotFoundError(reference)
            else:
                return None

    def get_mappings(
        self,
        query: Query | list[ColumnExpressionArgument[bool]] | None = None,
        *,
        limit: int | None = None,
        offset: int | None = None,
        order_by: Sort
        | ColumnExpressionArgument[Any]
        | list[ColumnExpressionArgument[Any]]
        | None = None,
    ) -> Sequence[SemanticMapping]:
        """Get mappings."""
        with self.get_session() as session:
            statement = select(SemanticMappingModel)
            statement = _apply_where_clauses(statement, query, converter=self.converter)

            if limit is not None:
                statement = statement.limit(limit)
            if offset is not None:
                statement = statement.offset(offset)

            if order_by is None:
                pass
            elif isinstance(order_by, str):
                statement = statement.order_by(_get_sorter(cast(Sort, order_by)))
            elif isinstance(order_by, list):
                statement = statement.order_by(*order_by)
            else:
                statement = statement.order_by(order_by)

            return [mapping.to_semantic_mapping() for mapping in session.exec(statement).all()]


POSITIVE_MAPPING_CLAUSE = or_(
    # Option 1: the mapping is manually curated
    and_(
        SemanticMappingModel.justification == manual_mapping_curation,
        col(SemanticMappingModel.predicate_modifier).is_(None),
    ),
    # Option 2: the mapping has been reviewed in a positive way
    and_(
        SemanticMappingModel.justification != manual_mapping_curation,
        # implicit: col(SemanticMappingModel.reviewers).is_not(None),
        col(SemanticMappingModel.reviewer_agreement) > 0.0,
    ),
)
NEGATIVE_MAPPING_CLAUSE = or_(
    # Option 1: the mapping is manually curated
    and_(
        SemanticMappingModel.justification == manual_mapping_curation,
        SemanticMappingModel.predicate_modifier == "Not",
    ),
    # Option 2: the mapping has been reviewed in a positive way
    and_(
        SemanticMappingModel.justification != manual_mapping_curation,
        # implicit: col(SemanticMappingModel.reviewers).is_not(None),
        col(SemanticMappingModel.reviewer_agreement) < 0.0,
    ),
)
UNCURATED_UNSURE_CLAUSE = and_(
    SemanticMappingModel.justification != manual_mapping_curation,
    # implicit: col(SemanticMappingModel.reviewers).is_not(None),
    SemanticMappingModel.reviewer_agreement == 0.0,
)
UNCURATED_NOT_UNSURE_CLAUSE = and_(
    SemanticMappingModel.justification != manual_mapping_curation,
    col(SemanticMappingModel.reviewer_agreement).is_(None),
)


#: The default sort order by subject, predicate, and object CURIEs
#: that can be passed to :meth:`SemanticMappingDatabase.get_mappings`
#: ``order_by`` argument
DEFAULT_SORT = [
    SemanticMappingModel.subject,
    SemanticMappingModel.predicate,
    SemanticMappingModel.object,
]

#: A mapping from :class:`Query` fields to functions that produce appropriate
#: clauses for database querying
QUERY_TO_CLAUSE: dict[str, Callable[[str], ColumnExpressionArgument[bool] | None]] = {
    "triple_id": lambda value: col(SemanticMappingModel.triple_id) == value,
    "query": lambda value: or_(
        col(SemanticMappingModel.subject).icontains(value.lower()),
        col(SemanticMappingModel.subject_name).icontains(value.lower()),
        col(SemanticMappingModel.object).icontains(value.lower()),
        col(SemanticMappingModel.object_name).icontains(value.lower()),
        func.json_extract(SemanticMappingModel.mapping_tool, "$.name").icontains(value.lower()),
    ),
    "subject_prefix": lambda value: col(SemanticMappingModel.subject).icontains(value.lower()),
    "subject_query": lambda value: or_(
        col(SemanticMappingModel.subject).icontains(value.lower()),
        col(SemanticMappingModel.subject_name).icontains(value.lower()),
    ),
    "object_query": lambda value: or_(
        col(SemanticMappingModel.object).icontains(value.lower()),
        col(SemanticMappingModel.object_name).icontains(value.lower()),
    ),
    "object_prefix": lambda value: col(SemanticMappingModel.object).icontains(value.lower()),
    "prefix": lambda value: or_(
        col(SemanticMappingModel.subject).icontains(value.lower()),
        col(SemanticMappingModel.object).icontains(value.lower()),
    ),
    "mapping_tool": lambda value: or_(
        func.json_extract(SemanticMappingModel.mapping_tool, "$.name").icontains(value.lower()),
    ),
    "same_text": lambda value: (
        and_(
            SemanticMappingModel.predicate == "skos:exactMatch",
            (
                _str_norm(SemanticMappingModel.subject_name)
                == _str_norm(SemanticMappingModel.object_name)
            )
            if value
            else or_(
                col(SemanticMappingModel.subject_name).is_(None),
                col(SemanticMappingModel.object_name).is_(None),
                and_(
                    col(SemanticMappingModel.subject_name).is_not(None),
                    col(SemanticMappingModel.object_name).is_not(None),
                    _str_norm(SemanticMappingModel.subject_name)
                    != _str_norm(SemanticMappingModel.object_name),
                ),
            ),
        )
        if value is not None
        else None
    ),
}


def _str_norm(column: Any) -> Any:
    return func.lower(func.replace(func.replace(column, "-", ""), " ", ""))


def clauses_from_query(
    query: Query | None = None, *, converter: curies.Converter | None = None
) -> list[ColumnExpressionArgument[bool]]:
    """Get clauses from the query."""
    if query is None:
        return []
    return [
        clause
        for name in Query.model_fields
        if (value := getattr(query, name)) is not None
        and (clause := QUERY_TO_CLAUSE[name](value)) is not None
    ]


def _apply_where_clauses(
    statement: SelectOfScalar[X],
    where_clauses: Query | list[ColumnExpressionArgument[bool]] | None,
    converter: curies.Converter | None = None,
) -> SelectOfScalar[X]:
    if where_clauses is None:
        return statement
    elif isinstance(where_clauses, Query):
        return statement.where(*clauses_from_query(where_clauses, converter=converter))
    else:
        return statement.where(*where_clauses)


def _get_sorter(sort: Sort) -> ColumnExpressionArgument[Any]:
    match sort:
        case "confidence" | "desc" | "-confidence":
            return col(SemanticMappingModel.confidence).desc()
        case "+confidence" | "asc":
            return col(SemanticMappingModel.confidence).asc()
        case "date" | "-date":
            return col(SemanticMappingModel.mapping_date).desc()
        case "+date":
            return col(SemanticMappingModel.mapping_date).asc()
        case "date-published" | "-date-published":
            return col(SemanticMappingModel.publication_date).desc()
        case "+date-published":
            return col(SemanticMappingModel.publication_date).asc()
        case "date-reviewed" | "-date-reviewed":
            return col(SemanticMappingModel.review_date).desc()
        case "+date-reviewed":
            return col(SemanticMappingModel.review_date).desc()
        case "subject":
            return col(SemanticMappingModel.subject).asc()
        case "object":
            return col(SemanticMappingModel.object).asc()
        # TODO add remaining values
        case _:
            raise ValueError(sort)
