# SMSD Cross-Platform Benchmarks

Publication-quality benchmark suite comparing MCS (Maximum Common Subgraph)
performance across three implementations:

| Engine | Language | Invocation |
|--------|----------|------------|
| **SMSD** | Java (CDK) | CLI jar with `--mode mcs --json -` |
| **RDKit FindMCS** | Python (C++ backend) | `rdFMCS.FindMCS()` |
| **SMSD C++** | C++17 header-only | Standalone binary or via `benchmark_cpp.sh` |

All benchmarks use the same **20 molecule pairs** covering trivial to
computationally challenging cases.

## Quick Start

```bash
# 1. Build SMSD Java jar (one-time)
cd /path/to/SMSD
mvn package -DskipTests

# 2. Install RDKit
pip install rdkit

# 3. Run the unified benchmark (RDKit + SMSD Java + optional C++)
python3 benchmarks/benchmark_all.py
```

Output files:
- `benchmarks/results.tsv` -- machine-readable tab-separated values
- `benchmarks/results_summary.txt` -- formatted comparison table

## Running Individual Benchmarks

### RDKit only

```bash
pip install rdkit
python3 benchmarks/benchmark_rdkit.py
```

### SMSD Java only

```bash
mvn package -DskipTests
bash benchmarks/benchmark_java.sh
```

### C++ only

```bash
bash benchmarks/benchmark_cpp.sh
```

This script handles CMake configuration, compilation in Release mode, and
execution. Requires CMake 3.16+ and a C++17 compiler.

### Unified (all engines)

```bash
python3 benchmarks/benchmark_all.py
```

Runs RDKit and SMSD Java head-to-head on all 20 pairs. If the C++ binary
is compiled (via `benchmark_cpp.sh`), it is automatically included.

## Molecule Pairs (20)

| # | Pair | Category | Notes |
|---|------|----------|-------|
| 1 | Methane / Ethane | Trivial | 1-2 atoms |
| 2 | Benzene / Toluene | Small aromatic | Methyl substituent |
| 3 | Benzene / Phenol | Heteroatom | OH substituent |
| 4 | Aspirin / Acetaminophen | Drug pair | Different scaffolds |
| 5 | Caffeine / Theophylline | N-methyl diff | Single N-CH3 removal |
| 6 | Morphine / Codeine | Alkaloid | Complex ring system |
| 7 | Ibuprofen / Naproxen | NSAID | Scaffold change |
| 8 | ATP / ADP | Nucleotide | Phosphate chain |
| 9 | NAD+ / NADH | Cofactor | Redox pair, large |
| 10 | Atorvastatin / Rosuvastatin | Statin | Different heterocycles |
| 11 | Paclitaxel / Docetaxel | Taxane | ~50 atoms, complex |
| 12 | Erythromycin / Azithromycin | Macrolide | Macrocyclic ring |
| 13 | Strychnine / Quinine | Alkaloid scaffold | Different frameworks |
| 14 | Vancomycin / self | Self-match large | ~100 atoms |
| 15 | Adamantane / self | Symmetric | Cage, high symmetry |
| 16 | Cubane / self | Cage | 8-atom cube |
| 17 | PEG-12 / PEG-16 | Polymer | Repetitive chain |
| 18 | Coronene / self | PAH | Polycyclic aromatic |
| 19 | Guanine keto / enol | Tautomer | Tautomeric forms |
| 20 | RDKit #1585 pair | Known failure | Stress test |

## Output Format

The unified benchmark (`benchmark_all.py`) produces a comparison table:

```
 #  Pair                          Category            RDKit ms  R.MCS   SMSD ms  S.MCS  Winner  Speed    Quality
------------------------------------------------------------------------------------------------------------------
 1  methane-ethane                 Trivial                0.012      1     0.008      1  SMSD      1.5x  equal
 2  benzene-toluene                Small aromatic         0.045      6     0.023      6  SMSD      2.0x  equal
...
```

Columns:
- **RDKit ms / SMSD ms**: Best time across 5 runs (lower is better)
- **R.MCS / S.MCS**: MCS size in atoms (higher is better)
- **Winner**: Which engine was faster
- **Speed**: Speedup factor
- **Quality**: Whether MCS sizes agree

## Prerequisites

| Benchmark | Requirements |
|-----------|-------------|
| Unified (`benchmark_all.py`) | Python 3.8+, `rdkit`, Java 11+, built SMSD jar |
| Java only | Java 11+, Maven (to build SMSD jar) |
| Python only | Python 3.8+, `pip install rdkit` |
| C++ only | CMake 3.16+, C++17 compiler |

## Methodology

- **Warmup**: 1 warmup run per pair (discarded) to eliminate JIT and cache effects
- **Timed runs**: 5 runs per pair; best and median times recorded
- **Timeout**: 10 seconds per pair (both engines)
- **Timing**: `time.perf_counter()` (Python), wall-clock subprocess timing (Java CLI)
- **MCS mode**: Atom-count-based MCS (not bond-count)

## Notes

- Java CLI timing includes JVM startup overhead per pair invocation. For
  in-process Java benchmarks, use the `--benchmark` CLI flag.
- The C++ benchmark covers a subset of pairs (those buildable without a SMILES
  parser). It measures raw graph algorithm speed.
- RDKit `FindMCS` returns a SMARTS pattern; SMSD returns atom-pair mappings.
  MCS sizes should agree for correct implementations.
- An asterisk (`*`) after RDKit time indicates the timeout was hit.

---

## Substructure Search Benchmark

A separate benchmark suite for **substructure search** (subgraph isomorphism),
comparing SMSD against CDK's `DfPattern` in a pure Java-to-Java setting.

### Files

| File | Description |
|------|-------------|
| `substructure_pairs.tsv` | 28 query/target SMILES pairs across 7 test sections |
| `benchmark_substructure_java.java` | Java benchmark: SMSD vs CDK DfPattern |
| `results_substructure.tsv` | Output with per-pair timings and speedup factors |

### Test Data (`substructure_pairs.tsv`)

28 query/target pairs organised into 7 sections:

| Section | Pairs | Description |
|---------|-------|-------------|
| Trivial / chain | 1-4 | Methane in ethane, propane chain, ethanol substructure |
| Ring containment | 5-8 | Benzene in toluene, naphthalene, biphenyl |
| Aromatic | 9-12 | Pyridine in nicotine, indole in tryptophan |
| Heterocyclic drugs | 13-16 | Imidazole in histamine, purine in caffeine |
| Drug fragments | 17-20 | Phenol in acetaminophen, piperidine in fentanyl |
| Edge cases | 21-24 | Self-match, single atom, symmetric cages |
| Negative controls | 25-28 | Pairs with no substructure match expected |

Format: `query_smiles<TAB>target_smiles<TAB>label`

All SMILES use kekulized form for CDK 2.11 compatibility.

### Running the Benchmark (`benchmark_substructure_java.java`)

Compares three approaches:

1. **SMSD IAtomContainer API** -- standard atom-container interface
2. **SMSD cached MolGraph API** -- pre-built graph, avoids repeated setup
3. **CDK DfPattern** -- CDK's built-in substructure matcher

```bash
# Set up Java (adjust path as needed)
export JAVA_HOME=/usr/local/Cellar/openjdk/25.0.2/libexec/openjdk.jdk/Contents/Home
export PATH="$JAVA_HOME/bin:$PATH"

# Build SMSD jar
mvn package -DskipTests

# Compile and run
javac -cp target/smsd-6.7.0-jar-with-dependencies.jar benchmarks/benchmark_substructure_java.java -d benchmarks/
java -cp target/smsd-6.7.0-jar-with-dependencies.jar:benchmarks/ benchmark_substructure_java
```

### Results (`results_substructure.tsv`)

Output columns:

| Column | Description |
|--------|-------------|
| `Pair` | Pair label from test data |
| `SMSD_us` | SMSD IAtomContainer time (microseconds) |
| `SMSD_cached_us` | SMSD cached MolGraph time (microseconds) |
| `CDK_us` | CDK DfPattern time (microseconds) |
| `Speedup` | CDK time / SMSD time |
| `Cached_Speedup` | CDK time / SMSD cached time |
| `SMSD_match` | Whether SMSD found a match (true/false) |
| `CDK_match` | Whether CDK found a match (true/false) |

**Key result**: SMSD cached MolGraph API beats CDK DfPattern on all 28/28
pairs, with speedups ranging from 2.5x to 13x.
