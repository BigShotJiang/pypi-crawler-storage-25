# Changelog

All notable changes to SMSD Pro are documented in this file.

## [6.7.0] - 2026-03-31

### Summary
Cumulative release consolidating all v6.5—v6.6 features, performance caches, and bug fixes.

### Features
- CIP Rules 1-5 with pseudoasymmetric r/s detection
- BondChangeScorer for reaction-aware MCS ranking
- batch_mcs_constrained with residual re-run (14/14 coverage)
- Two-phase reduceCrossings with individual ring flipping
- Python auto-detects input types (MolGraph, SMILES, native Mol)
- strip_atom_maps + parse_mapped_smiles (100% Golden parse rate)
- prefer_rare_heteroatoms for reaction mapping

### Performance
- MolGraph identity cache (eliminates redundant graph construction)
- Domain space cache (337x fingerprint speedup)
- ECFP/FCFP/pharmacophore feature caches
- C++ GraphBuilder precomputed compatibility matrix

### Breaking
- McsOptions.timeoutMillis renamed to timeoutMs

## [6.6.4] - 2026-03-31

### Added
- `strip_atom_maps()` — bracket-aware atom map removal that preserves aromatic ring closures (59.9% to 100% parse rate on Golden benchmark)
- `parse_mapped_smiles()` — one-step strip + parse for reaction SMILES

### Reverted
- 3-hop NLF back to off by default — benchmarks showed 3% slower with no accuracy gain

## [6.6.3] - 2026-03-31

### Changed
- **3-hop NLF pruning enabled by default** — stronger pruning at L2 McSplit for molecules >20 atoms. Auto-disabled for small molecules. Advanced users can toggle via `ChemOptions.withThreeHopNLF(false)`.

## [6.6.2] - 2026-03-31

### Fixed
- **CRITICAL**: `batch_mcs_constrained` now RE-RUNS MCS on residual target subgraph when atoms overlap between queries, instead of just filtering overlapping pairs. Multi-fragment reactions now achieve full coverage (e.g. ArBr + ArNH2 → biaryl amine: 14/14 product atoms mapped, was 8/14).
- Java residual graph built via CDK clone + atom removal with index translation
- C++ residual graph built via `extractSubgraph()` with index translation

## [6.6.1] - 2026-03-31

### Fixed
- **CRITICAL**: `batch_mcs_constrained` redesigned — each query now maps against ALL targets with non-overlapping target atom exclusion (was 1:1 pairing, breaking N-reactants to 1-product use case)
- **CRITICAL**: CIP R/S implicit H SMILES ordering fix — amino acids (L-alanine S, L-cysteine R, R-glyceraldehyde R) now correct
- pybind11 `assignRS` binding fixed for 3-param signature (wheel build fix)

### Changed
- `BondChangeScorer` uses combined score (size - 0.15 * penalty) so K-1 candidates with better bond alignment can win
- Python `batch_mcs_constrained` auto-translates native Mol indices

---

## [6.6.0] - 2026-03-30

### Breaking
- `McsOptions.timeoutMillis` renamed to `timeoutMs` (Java parity with C++/Python)

### Added
- C++ `McsOptions`: `postFilter` callback and `bondChangeAware` flag
- CIP: Rules 4b-c (like/unlike pairing), Rule 5 (R>S), pseudoasymmetric r/s detection
- Layout: two-phase `reduceCrossings` with individual ring flipping
- Python API: auto-detects native Mol objects, returns native indices, `prefer_rare_heteroatoms`
- New `BondChangeScorer` post-filter for reaction-aware MCS
- New `batchMcsConstrained` for multi-pair MCS with non-overlap constraints

### Performance
- MolGraph cache, domain space cache, ECFP/FCFP cache, pharmacophore features cache
- C++ `GraphBuilder` precomputed compatibility matrix

### Fixed
- Python: fixed roundtrip index correctness (no shared MolGraph across Mol objects)

### Changed
- Removed all competitor toolkit references from C++ headers

---

## [6.5.2] - 2026-03-30

### Added
- Python API: `mcs()`, `mcs_result()`, `map_reaction_aware()` now auto-detect native Mol objects and return native indices
- New `_ensure_mol_ex()` and `_auto_translate()` helpers with element validation
- New `prefer_rare_heteroatoms` parameter in `mcs()` for SAM/ATP heteroatom-weighted scoring

---

## [6.5.1] - 2026-03-30

### Added
- Two-phase `reduceCrossings`: phase 1 system-level crossing minimisation + phase 2 individual ring flipping
- Shared (fusion) atoms used as fixed pivots for individual ring flips
- `@since` tags on layout methods (`forceDirectedLayout`, `stressMajorisation`, `reduceCrossings`)

---

## [6.5.0] - 2026-03-30

### Added
- `ChemOptions.copyOf()` for safe, immutable option cloning
- Heteroatom-seeded MCS now uses charge-relaxed options automatically

### Fixed
- Reaction-aware MCS charge relaxation fix: S+ to S mapping now handled
  correctly (e.g. SAM sulfonium centre maps to neutral sulfur)

### Changed
- Competitor reference cleanup across documentation and build metadata

## [6.4.1] - 2025

- Full Java/C++/Python parity, 32 binding gaps fixed

## [6.4.0] - 2025

- Force-directed layout, reaction-aware MCS, SMACOF stress majorisation

---

Copyright (c) 2018-2026 BioInception PVT LTD. Algorithm Copyright (c) 2009-2026 Syed Asad Rahman.
