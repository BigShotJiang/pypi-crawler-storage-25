/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (c) 2018-2026 BioInception PVT LTD
 * Algorithm Copyright (c) 2009-2026 Syed Asad Rahman
 * See the NOTICE file for attribution, trademark, and algorithm IP terms. *
 * VF2++ Substructure Search Engine -- header-only C++17 port.
 * Zero external dependencies; requires "smsd/mol_graph.hpp" for MolGraph / ChemOptions.
 *
 * Algorithms ported from the Java SMSD SubstructureEngine:
 *   - Greedy probe (O(N) fast-path)
 *   - FASTiso ordering (forward-checking, smallest domain first, < 30 atoms)
 *   - VF3-Light ordering (label rarity sort, >= 30 atoms)
 *   - VF2PP backtracking with bit-parallel domains, NLF-1/2/3 pruning
 *   - Full feasibility check: degree, NLF, mapped-neighbor adjacency, bond compat
 */
#ifndef SMSD_VF2PP_HPP
#define SMSD_VF2PP_HPP

#include "smsd/mol_graph.hpp"

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <numeric>
#include <unordered_map>
#include <utility>
#include <vector>

#include "gpu_kernels.hpp"

namespace smsd {

// ============================================================================
// Forward declarations of public API
// ============================================================================

bool isSubstructure(const MolGraph& query, const MolGraph& target,
                    const ChemOptions& opts, int64_t timeoutMs = 10000);

std::vector<std::pair<int,int>> findSubstructure(
    const MolGraph& query, const MolGraph& target,
    const ChemOptions& opts, int64_t timeoutMs = 10000);

std::vector<std::vector<std::pair<int,int>>> findAllSubstructures(
    const MolGraph& query, const MolGraph& target,
    const ChemOptions& opts, int64_t timeoutMs = 10000);

// ============================================================================
// Implementation detail namespace
// ============================================================================
namespace detail {

// Bit-ops: delegate to smsd::popcount64 / smsd::ctz64 from bitops.hpp
using smsd::popcount64;
using smsd::ctz64;

// ---------- Time budget ----------------------------------------------------

struct TimeBudget {
    using Clock = std::chrono::steady_clock;
    Clock::time_point deadline;
    int64_t counter_ = 0;
    static constexpr int64_t CHECK_EVERY = 1024;

    explicit TimeBudget(int64_t ms)
        : deadline(Clock::now() + std::chrono::milliseconds(std::max<int64_t>(1, ms))) {}

    bool expired() {
        if ((++counter_ & (CHECK_EVERY - 1)) != 0) return false;
        return Clock::now() >= deadline;
    }
    bool expiredNow() const { return Clock::now() >= deadline; }
    int64_t remainingMs() const {
        auto r = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - Clock::now()).count();
        return std::max<int64_t>(0, r);
    }
};

// ---------- Iterate set bits in a uint64_t word array ----------------------

inline void iterateBits(const uint64_t* words, int nWords,
                        int* out, int& outCount) {
    outCount = 0;
    for (int w = 0; w < nWords; ++w) {
        uint64_t bits = words[w];
        while (bits != 0) {
            out[outCount++] = (w << 6) | ctz64(bits);
            bits &= bits - 1;
        }
    }
}

// ---------- NLF sorted-array merge check -----------------------------------

inline bool nlfOk(const int* fq, int fqLen, const int* ft, int ftLen) {
    int fi = 0, ti = 0;
    while (fi < fqLen) {
        int fLabel = fq[fi], fFreq = fq[fi + 1];
        while (ti < ftLen && ft[ti] < fLabel) ti += 2;
        if (ti >= ftLen || ft[ti] != fLabel || ft[ti + 1] < fFreq) return false;
        fi += 2;
    }
    return true;
}

// ---------- NLF builders ---------------------------------------------------

// NLF label: atomicNum + aromaticity, WITHOUT ring bit (ring is a one-directional
// constraint so including it would over-prune non-ring-query vs ring-target matches).
inline int nlfLabel(const MolGraph& g, int idx) {
    return (g.atomicNum[idx] << 1) | (g.aromatic[idx] ? 1 : 0);
}

// Builds sorted (label, freq) pairs for 1-hop neighbors.
inline std::vector<int> buildNLF1(const MolGraph& g, int idx) {
    std::unordered_map<int,int> freq;
    for (int k = 0; k < g.degree[idx]; ++k)
        ++freq[nlfLabel(g, g.neighbors[idx][k])];
    // Pack into sorted array of (label, freq) pairs
    std::vector<int> arr(freq.size() * 2);
    int p = 0;
    for (auto& kv : freq) { arr[p++] = kv.first; arr[p++] = kv.second; }
    // Insertion-sort by label
    int pairs = static_cast<int>(freq.size());
    for (int i = 1; i < pairs; ++i) {
        int kl = arr[i*2], kf = arr[i*2+1];
        int j = i - 1;
        while (j >= 0 && arr[j*2] > kl) {
            arr[(j+1)*2]   = arr[j*2];
            arr[(j+1)*2+1] = arr[j*2+1];
            --j;
        }
        arr[(j+1)*2]   = kl;
        arr[(j+1)*2+1] = kf;
    }
    return arr;
}

// 2-hop NLF: nodes at distance exactly 2.
inline std::vector<int> buildNLF2(const MolGraph& g, int idx) {
    std::unordered_map<int,int> freq;
    std::vector<bool> seen(g.n, false);
    // Mark direct neighbors
    for (int k = 0; k < g.degree[idx]; ++k) seen[g.neighbors[idx][k]] = true;
    seen[idx] = true;
    for (int k = 0; k < g.degree[idx]; ++k) {
        int nb = g.neighbors[idx][k];
        for (int m = 0; m < g.degree[nb]; ++m) {
            int j = g.neighbors[nb][m];
            if (!seen[j]) {
                seen[j] = true;
                ++freq[nlfLabel(g, j)];
            }
        }
    }
    std::vector<int> arr(freq.size() * 2);
    int p = 0;
    for (auto& kv : freq) { arr[p++] = kv.first; arr[p++] = kv.second; }
    int pairs = static_cast<int>(freq.size());
    for (int i = 1; i < pairs; ++i) {
        int kl = arr[i*2], kf = arr[i*2+1], j = i - 1;
        while (j >= 0 && arr[j*2] > kl) {
            arr[(j+1)*2] = arr[j*2]; arr[(j+1)*2+1] = arr[j*2+1]; --j;
        }
        arr[(j+1)*2] = kl; arr[(j+1)*2+1] = kf;
    }
    return arr;
}

// 3-hop NLF: nodes at distance exactly 3.
inline std::vector<int> buildNLF3(const MolGraph& g, int idx) {
    // level1 = direct neighbors
    std::vector<bool> level1(g.n, false), level2(g.n, false), level3(g.n, false);
    level1[idx] = true;
    for (int k = 0; k < g.degree[idx]; ++k) level1[g.neighbors[idx][k]] = true;
    // level2
    for (int k = 0; k < g.degree[idx]; ++k) {
        int nb = g.neighbors[idx][k];
        for (int m = 0; m < g.degree[nb]; ++m) {
            int j = g.neighbors[nb][m];
            if (!level1[j]) level2[j] = true;
        }
    }
    // level3
    for (int j = 0; j < g.n; ++j) {
        if (!level2[j]) continue;
        for (int m = 0; m < g.degree[j]; ++m) {
            int v = g.neighbors[j][m];
            if (!level1[v] && !level2[v]) level3[v] = true;
        }
    }
    std::unordered_map<int,int> freq;
    for (int j = 0; j < g.n; ++j)
        if (level3[j]) ++freq[nlfLabel(g, j)];
    std::vector<int> arr(freq.size() * 2);
    int p = 0;
    for (auto& kv : freq) { arr[p++] = kv.first; arr[p++] = kv.second; }
    int pairs = static_cast<int>(freq.size());
    for (int i = 1; i < pairs; ++i) {
        int kl = arr[i*2], kf = arr[i*2+1], j = i - 1;
        while (j >= 0 && arr[j*2] > kl) {
            arr[(j+1)*2] = arr[j*2]; arr[(j+1)*2+1] = arr[j*2+1]; --j;
        }
        arr[(j+1)*2] = kl; arr[(j+1)*2+1] = kf;
    }
    return arr;
}

// ---------- Atom / bond compatibility --------------------------------------

inline bool atomsCompatFast(const MolGraph& gq, int qi,
                            const MolGraph& gt, int tj,
                            const ChemOptions& C) {
    // Tautomer-aware: C/N/O can interchange within tautomeric regions,
    // but all OTHER atom-level constraints still apply (charge, aromaticity,
    // ring membership, isotope, chirality, ring fusion).
    bool tautRelax = C.tautomerAware
        && !gq.tautomerClass.empty() && !gt.tautomerClass.empty()
        && gq.tautomerClass[qi] != -1 && gt.tautomerClass[tj] != -1;
    if (tautRelax) {
        int aq = gq.atomicNum[qi], at = gt.atomicNum[tj];
        if (!((aq == 6 || aq == 7 || aq == 8) &&
              (at == 6 || at == 7 || at == 8)))
            tautRelax = false;  // not C/N/O pair — fall through to normal matching
        // Degree guard: genuine tautomers shift at most 1 proton,
        // so degree difference should be <= 1 for same-element matches.
        // Prevents over-matching unrelated functional groups (e.g., -OH vs =O).
        if (tautRelax && aq == at && std::abs(gq.degree[qi] - gt.degree[tj]) > 1)
            tautRelax = false;
    }
    if (!tautRelax && C.matchAtomType && gq.atomicNum[qi] != gt.atomicNum[tj]) return false;
    if (C.matchFormalCharge && gq.formalCharge[qi] != gt.formalCharge[tj]) return false;
    if (C.aromaticityMode == ChemOptions::AromaticityMode::STRICT && gq.aromatic[qi] != gt.aromatic[tj]) return false;
    if (C.ringMatchesRingOnly && gq.ring[qi] && !gt.ring[tj]) return false;
    if (C.matchIsotope) {
        int qm = gq.massNumber[qi], tm = gt.massNumber[tj];
        if (qm != 0 && tm != 0 && qm != tm) return false;
    }
    if (C.useChirality) {
        int qs = gq.tetraChirality[qi], ts = gt.tetraChirality[tj];
        if (qs != 0 && ts != 0 && qs != ts) return false;
    }
    if (C.ringFusionMode != ChemOptions::RingFusionMode::IGNORE && gq.ring[qi] && gt.ring[tj]) {
        if (C.ringFusionMode == ChemOptions::RingFusionMode::STRICT) {
            if (gq.ringCount[qi] != gt.ringCount[tj]) return false;
        }
    }
    return true;
}

inline bool bondsCompatible(const MolGraph& g1, int qi, int qk,
                            const MolGraph& g2, int tj, int tk,
                            const ChemOptions& C) {
    int qOrd = g1.bondOrder(qi, qk), tOrd = g2.bondOrder(tj, tk);
    if (qOrd == 0 || tOrd == 0) return false;
    // Tautomer-aware: relax bond ORDER (single/double interchangeable)
    // but still enforce aromaticity, stereo, and ring constraints.
    bool tautBondRelax = C.tautomerAware
        && !g1.tautomerClass.empty() && !g2.tautomerClass.empty()
        && g1.tautomerClass[qi] != -1 && g1.tautomerClass[qk] != -1
        && g2.tautomerClass[tj] != -1 && g2.tautomerClass[tk] != -1;
    // Strict aromaticity: check bond aromaticity directly (no ring guard)
    if (C.aromaticityMode == ChemOptions::AromaticityMode::STRICT
        && g1.bondAromatic(qi, qk) != g2.bondAromatic(tj, tk)) return false;
    if (C.useBondStereo) {
        int qConf = g1.dbStereo(qi, qk), tConf = g2.dbStereo(tj, tk);
        if (qConf != 0 && tConf != 0 && qConf != tConf) return false;
    }
    if (C.ringMatchesRingOnly && g1.bondInRing(qi, qk) && !g2.bondInRing(tj, tk)) return false;
    if (tautBondRelax) return true;  // bond order relaxed for tautomeric bonds
    if (C.matchBondOrder == ChemOptions::BondOrderMode::ANY) return true;
    if (qOrd == tOrd) return true;
    if (C.matchBondOrder == ChemOptions::BondOrderMode::LOOSE) return true;
    if (C.aromaticityMode == ChemOptions::AromaticityMode::FLEXIBLE) {
        bool qa = g1.bondAromatic(qi, qk), ta = g2.bondAromatic(tj, tk);
        if ((qa && ta) || (qa && (tOrd == 1 || tOrd == 2)) || (ta && (qOrd == 1 || qOrd == 2)))
            return true;
    }
    return false;
}

// ==========================================================================
// AbstractVFMatcher -- base class with all shared state & algorithms
// ==========================================================================

class AbstractVFMatcher {
protected:
    const MolGraph& gq_;
    const MolGraph& gt_;
    const ChemOptions& C_;
    TimeBudget tb_;

    int Nq_, Nt_;
    int tWords_;
    bool singleWord_;

    // Mapping arrays -- pre-allocated, zero heap in hot loops
    std::vector<int> q2t_;
    std::vector<int> t2q_;

    // NLF caches: pointers into MolGraph lazy caches — zero-copy, lifetime tied to gq_/gt_
    const std::vector<std::vector<int>>* qNLF1_ = nullptr;
    const std::vector<std::vector<int>>* tNLF1_ = nullptr;
    const std::vector<std::vector<int>>* qNLF2_ = nullptr;
    const std::vector<std::vector<int>>* tNLF2_ = nullptr;
    const std::vector<std::vector<int>>* qNLF3_ = nullptr;
    const std::vector<std::vector<int>>* tNLF3_ = nullptr;

    bool useTwoHop_, useThreeHop_, useBitParallel_, useRingOnly_, useStereo_;
    bool bitParallelSufficient_;

    // Bit-parallel candidate domains: domain_[i][w] is a uint64_t word
    std::vector<std::vector<uint64_t>> domain_;
    std::vector<uint64_t> usedMask_;

    // Query degree and target degree (raw pointers into MolGraph arrays)
    const int* qdeg_;
    const int* tdeg_;

    // Query neighbors sorted by descending degree
    std::vector<std::vector<int>> qNeighborsByDegDesc_;

    // Scratch buffers for candidate iteration (avoid allocation in hot loop)
    std::vector<int> probeCandBuf_;                // for non-recursive greedy probe
    std::vector<std::vector<int>> candBufStack_;   // per-depth for backtrack/enumerate
    std::vector<uint64_t> availBuf_;               // sized to tWords

    // Stats
    int64_t nodesVisited_  = 0;
    int64_t backtracks_    = 0;
    int64_t candidatesTried_ = 0;
    int64_t prunesAtom_    = 0;
    int64_t prunesBond_    = 0;
    int64_t prunesDegree_  = 0;
    int64_t prunesNLF_     = 0;
    bool    timedOut_      = false;
    bool    found_         = false;

public:
    AbstractVFMatcher(const MolGraph& gq, const MolGraph& gt,
                      const ChemOptions& C, int64_t timeoutMs)
        : gq_(gq), gt_(gt), C_(C), tb_(timeoutMs),
          Nq_(gq.n), Nt_(gt.n),
          tWords_((gt.n + 63) >> 6),
          singleWord_(((gt.n + 63) >> 6) <= 1),
          q2t_(gq.n, -1), t2q_(gt.n, -1),
          useTwoHop_(C.useTwoHopNLF),
          useThreeHop_(C.useThreeHopNLF),
          useBitParallel_(C.useBitParallelFeasibility),
          useRingOnly_(C.ringMatchesRingOnly),
          useStereo_(C.useBondStereo),
          bitParallelSufficient_(C.useBitParallelFeasibility
              && C.matchBondOrder == ChemOptions::BondOrderMode::ANY
              && !C.useBondStereo && !C.ringMatchesRingOnly),
          domain_(gq.n, std::vector<uint64_t>(((gt.n + 63) >> 6), 0)),
          usedMask_(((gt.n + 63) >> 6), 0),
          qdeg_(gq.degree.data()),
          tdeg_(gt.degree.data()),
          qNeighborsByDegDesc_(gq.n),
          probeCandBuf_(gt.n + 64),
          candBufStack_(std::max(1, gq.n), std::vector<int>(gt.n + 64)),
          availBuf_(((gt.n + 63) >> 6), 0)
    {
        // Adaptive NLF disable for small molecules
        if (Nq_ <= 12 || Nt_ <= 12) useTwoHop_ = false;
        if (Nq_ <= 20 || Nt_ <= 20) useThreeHop_ = false;

        // Build query neighbors sorted by descending degree
        for (int i = 0; i < Nq_; ++i) {
            int deg = gq_.degree[i];
            qNeighborsByDegDesc_[i].resize(deg);
            for (int k = 0; k < deg; ++k)
                qNeighborsByDegDesc_[i][k] = gq_.neighbors[i][k];
            // Insertion sort descending by degree
            auto& nb = qNeighborsByDegDesc_[i];
            for (int a = 1; a < deg; ++a) {
                int key = nb[a], keyDeg = gq_.degree[key];
                int b = a - 1;
                while (b >= 0 && gq_.degree[nb[b]] < keyDeg) {
                    nb[b+1] = nb[b]; --b;
                }
                nb[b+1] = key;
            }
        }

        // Ensure lazy-computed fields are ready before matching
        if (C.ringFusionMode != ChemOptions::RingFusionMode::IGNORE) {
            gq_.ensureRingCounts();
            gt_.ensureRingCounts();
        }

        // Use lazy-cached NLF tables from MolGraph (zero-copy pointer assignment)
        qNLF1_ = &gq_.getNLF1();
        tNLF1_ = &gt_.getNLF1();
        if (useTwoHop_) {
            qNLF2_ = &gq_.getNLF2();
            tNLF2_ = &gt_.getNLF2();
        }
        if (useThreeHop_) {
            qNLF3_ = &gq_.getNLF3();
            tNLF3_ = &gt_.getNLF3();
        }

        // --- GPU fast path for domain initialization ---
        // For large enough workloads, dispatch the Nq×Nt compatibility matrix
        // to GPU.  The GPU implements common-case checks only (atomicNum,
        // charge, aromaticity, ringOnly).  Advanced checks (tautomer, isotope,
        // chirality, ring fusion) are handled by the CPU feasibility check
        // during backtracking — the GPU domain is a safe superset.
        bool gpuDomainOk = false;
        if (Nq_ > 0 && Nt_ > 0 && static_cast<int64_t>(Nq_) * Nt_ > 2000
            && gpu_kern::graphKernelsAvailable()) {
            // Materialize vector<bool> to int arrays (vector<bool> has no .data())
            std::vector<int> qRi(Nq_), qAr(Nq_), tRi(Nt_), tAr(Nt_);
            for (int i = 0; i < Nq_; ++i) { qRi[i] = gq_.ring[i]; qAr[i] = gq_.aromatic[i]; }
            for (int j = 0; j < Nt_; ++j) { tRi[j] = gt_.ring[j]; tAr[j] = gt_.aromatic[j]; }
            std::vector<uint64_t> flatDom(static_cast<size_t>(Nq_) * tWords_, 0);
            gpuDomainOk = gpu_kern::domainInit(
                Nq_, Nt_, tWords_,
                gq_.atomicNum.data(), gq_.formalCharge.data(), qRi.data(), qAr.data(),
                gt_.atomicNum.data(), gt_.formalCharge.data(), tRi.data(), tAr.data(),
                C_.matchAtomType, C_.matchFormalCharge, C_.ringMatchesRingOnly,
                C_.aromaticityMode == ChemOptions::AromaticityMode::STRICT,
                flatDom.data());
            if (gpuDomainOk) {
                for (int i = 0; i < Nq_; ++i)
                    std::memcpy(domain_[i].data(), &flatDom[i * tWords_],
                                tWords_ * sizeof(uint64_t));
            }
        }

        // --- CPU fallback (or small workload) ---
        if (!gpuDomainOk && Nq_ > 0 && Nt_ > 50) {
            std::unordered_map<int, std::vector<int>> targetByLabel;
            for (int j = 0; j < Nt_; ++j) {
                int key = C_.matchAtomType ? gt_.atomicNum[j] : 0;
                // Only bucket by aromatic; skip ring bit to avoid incorrectly
                // blocking non-ring query atoms from matching ring target atoms.
                key = (key << 1) | (gt_.aromatic[j] ? 1 : 0);
                targetByLabel[key].push_back(j);
            }
            for (int i = 0; i < Nq_; ++i) {
                for (auto& [labelKey, targets] : targetByLabel) {
                    if (C_.matchAtomType && !targets.empty()
                        && gq_.atomicNum[i] != gt_.atomicNum[targets[0]]) {
                        prunesAtom_ += static_cast<int64_t>(targets.size());
                        continue;
                    }
                    for (int j : targets) {
                        if (atomsCompatFast(gq_, i, gt_, j, C_))
                            domain_[i][j >> 6] |= uint64_t(1) << (j & 63);
                        else
                            ++prunesAtom_;
                    }
                }
            }
        } else if (!gpuDomainOk) {
            for (int i = 0; i < Nq_; ++i)
                for (int j = 0; j < Nt_; ++j) {
                    if (atomsCompatFast(gq_, i, gt_, j, C_))
                        domain_[i][j >> 6] |= uint64_t(1) << (j & 63);
                    else
                        ++prunesAtom_;
                }
        }
    }

    virtual ~AbstractVFMatcher() = default;

    // ----- Domain candidates (available & compatible) ----------------------

    int domainCandidates(int qi, int* out) const {
        int count = 0;
        for (int w = 0; w < tWords_; ++w) {
            uint64_t bits = domain_[qi][w] & ~usedMask_[w];
            while (bits != 0) {
                out[count++] = (w << 6) | ctz64(bits);
                bits &= bits - 1;
            }
        }
        return count;
    }

    // ----- Greedy probe (O(N) fast path) -----------------------------------

    bool greedyProbe(const int* order) {
        int matched = 0;
        for (int idx = 0; idx < Nq_; ++idx) {
            int qi = order[idx];
            int nCands = domainCandidates(qi, probeCandBuf_.data());
            int bestTj = -1, bestDist = 0x7FFFFFFF;
            bool found2 = false;
            for (int c = 0; c < nCands; ++c) {
                int tj = probeCandBuf_[c];
                int dist = tdeg_[tj] - qdeg_[qi];
                if (dist < 0) dist = -dist;
                if (dist < bestDist && feasible(qi, tj)) {
                    bestTj = tj; bestDist = dist; found2 = true;
                    if (dist == 0) break;
                }
            }
            if (!found2) {
                // Undo all matched so far
                for (int k = matched - 1; k >= 0; --k) {
                    int qk = order[k], tk = q2t_[qk];
                    q2t_[qk] = -1; t2q_[tk] = -1;
                    usedMask_[tk >> 6] &= ~(uint64_t(1) << (tk & 63));
                }
                return false;
            }
            q2t_[qi] = bestTj; t2q_[bestTj] = qi;
            usedMask_[bestTj >> 6] |= uint64_t(1) << (bestTj & 63);
            ++matched;
        }
        return true;
    }

    // ----- FASTiso ordering ------------------------------------------------
    // Forward-checking, smallest domain first, break ties by highest degree.

    void fastisoOrder(int* order) const {
        std::vector<bool> picked(Nq_, false);

        // Compute connected components of the query graph via BFS
        std::vector<int> compId(Nq_, -1);
        int nComp = 0;
        for (int s = 0; s < Nq_; ++s) {
            if (compId[s] >= 0) continue;
            int cid = nComp++;
            compId[s] = cid;
            std::deque<int> bfs;
            bfs.push_back(s);
            while (!bfs.empty()) {
                int u = bfs.front(); bfs.pop_front();
                for (int k = 0; k < gq_.degree[u]; ++k) {
                    int v = gq_.neighbors[u][k];
                    if (compId[v] < 0) { compId[v] = cid; bfs.push_back(v); }
                }
            }
        }

        // Working copy of domains for forward checking
        std::vector<std::vector<uint64_t>> workDomain(Nq_);
        for (int i = 0; i < Nq_; ++i) workDomain[i] = domain_[i];

        std::vector<uint64_t> reachable(tWords_, 0);
        int activeComp = -1; // current component being ordered

        for (int pos = 0; pos < Nq_; ++pos) {
            int bestQ = -1, bestSize = 0x7FFFFFFF, bestDeg = -1;

            // First pass: prefer atoms from the active component
            if (activeComp >= 0) {
                for (int i = 0; i < Nq_; ++i) {
                    if (picked[i] || compId[i] != activeComp) continue;
                    int size = 0;
                    for (int w = 0; w < tWords_; ++w)
                        size += popcount64(workDomain[i][w]);
                    if (size < bestSize || (size == bestSize && gq_.degree[i] > bestDeg)) {
                        bestQ = i; bestSize = size; bestDeg = gq_.degree[i];
                    }
                }
            }

            // If no unpicked atom in active component, pick globally (starts new component)
            if (bestQ < 0) {
                for (int i = 0; i < Nq_; ++i) {
                    if (picked[i]) continue;
                    int size = 0;
                    for (int w = 0; w < tWords_; ++w)
                        size += popcount64(workDomain[i][w]);
                    if (size < bestSize || (size == bestSize && gq_.degree[i] > bestDeg)) {
                        bestQ = i; bestSize = size; bestDeg = gq_.degree[i];
                    }
                }
                activeComp = compId[bestQ];
            }

            order[pos] = bestQ;
            picked[bestQ] = true;

            // Forward-check: restrict neighbor domains to reachable from bestQ's domain.
            // Skip neighbors whose domain is already empty (nothing to restrict).
            for (int nk = 0; nk < gq_.degree[bestQ]; ++nk) {
                int qk = gq_.neighbors[bestQ][nk];
                if (picked[qk]) continue;
                // Check if qk's domain is already empty — skip expensive reachability
                bool hasAny = false;
                for (int w = 0; w < tWords_ && !hasAny; ++w)
                    if (workDomain[qk][w]) hasAny = true;
                if (!hasAny) continue;
                std::memset(reachable.data(), 0, tWords_ * sizeof(uint64_t));
                for (int w = 0; w < tWords_; ++w) {
                    uint64_t bits = workDomain[bestQ][w];
                    while (bits != 0) {
                        int tj = (w << 6) | ctz64(bits);
                        bits &= bits - 1;
                        if (tj < Nt_) {
                            for (int rw = 0; rw < tWords_; ++rw)
                                reachable[rw] |= gt_.adjLong[tj][rw];
                        }
                    }
                }
                for (int rw = 0; rw < tWords_; ++rw)
                    workDomain[qk][rw] &= reachable[rw];
            }
        }
    }

    // ----- VF3-Light ordering ----------------------------------------------
    // Sort by label rarity (ascending), then degree (descending), then
    // domain size (ascending).

    void vf3LightOrder(int* order) const {
        // Count label frequency in query
        std::unordered_map<int,int> labelFreq;
        for (int i = 0; i < Nq_; ++i)
            ++labelFreq[gq_.label[i]];

        // Initialize identity
        for (int i = 0; i < Nq_; ++i) order[i] = i;

        // Sort using the three-key comparator
        std::sort(order, order + Nq_, [&](int a, int b) {
            int fA = labelFreq[gq_.label[a]], fB = labelFreq[gq_.label[b]];
            if (fA != fB) return fA < fB;
            if (gq_.degree[a] != gq_.degree[b]) return gq_.degree[a] > gq_.degree[b];
            int domA = 0, domB = 0;
            for (int w = 0; w < tWords_; ++w) {
                domA += popcount64(domain_[a][w]);
                domB += popcount64(domain_[b][w]);
            }
            return domA < domB;
        });
    }

    // ----- Feasibility check -----------------------------------------------

    bool feasible(int qi, int tj) {
        // Degree check
        if (gt_.degree[tj] < gq_.degree[qi]) { ++prunesDegree_; return false; }

        // Ring-only check (cheapest boolean test — run early for fast exit)
        if (useRingOnly_ && gq_.ring[qi] && !gt_.ring[tj]) {
            ++prunesAtom_; return false;
        }

        // NLF-1 check
        if (!nlfOk((*qNLF1_)[qi].data(), static_cast<int>((*qNLF1_)[qi].size()),
                   (*tNLF1_)[tj].data(), static_cast<int>((*tNLF1_)[tj].size()))) {
            ++prunesNLF_; return false;
        }

        // NLF-2 check
        if (useTwoHop_
            && !nlfOk((*qNLF2_)[qi].data(), static_cast<int>((*qNLF2_)[qi].size()),
                      (*tNLF2_)[tj].data(), static_cast<int>((*tNLF2_)[tj].size()))) {
            ++prunesNLF_; return false;
        }

        // NLF-3 check
        if (useThreeHop_
            && !nlfOk((*qNLF3_)[qi].data(), static_cast<int>((*qNLF3_)[qi].size()),
                      (*tNLF3_)[tj].data(), static_cast<int>((*tNLF3_)[tj].size()))) {
            ++prunesNLF_; return false;
        }

        // Mapped-neighbor adjacency (bit-parallel fast path)
        const auto& nbSorted = qNeighborsByDegDesc_[qi];
        if (useBitParallel_) {
            const uint64_t* tAdj = gt_.adjLong[tj].data();
            for (int qk : nbSorted) {
                int tk = q2t_[qk];
                if (tk != -1 && (tAdj[tk >> 6] & (uint64_t(1) << (tk & 63))) == 0) {
                    ++prunesBond_; return false;
                }
            }
            if (bitParallelSufficient_) return true;
        }

        // Full bond-compatibility check
        for (int qk : nbSorted) {
            int tk = q2t_[qk];
            if (tk != -1 && !bondsCompatible(gq_, qi, qk, gt_, tj, tk, C_)) {
                ++prunesBond_; return false;
            }
        }

        return true;
    }

    // ----- Insertion sort candidates by degree proximity --------------------

    void sortByDegreeProximity(int* cands, int n, int qi) const {
        int qd = qdeg_[qi];
        for (int i = 1; i < n; ++i) {
            int key = cands[i];
            int keyDist = tdeg_[key] - qd;
            if (keyDist < 0) keyDist = -keyDist;
            int j = i - 1;
            while (j >= 0) {
                int d = tdeg_[cands[j]] - qd;
                if (d < 0) d = -d;
                if (d <= keyDist) break;
                cands[j+1] = cands[j]; --j;
            }
            cands[j+1] = key;
        }
    }

    // ----- VF3-style pivot: prefer candidate with most mapped-neighbor overlap

    void applyPivotHeuristic(int* out, int count, int qi) const {
        if (count <= 1) return;
        // Count mapped neighbors of qi — pivot only valuable with >= 2
        int mappedNbrs = 0;
        for (int nk = 0; nk < gq_.degree[qi]; ++nk)
            if (q2t_[gq_.neighbors[qi][nk]] != -1) mappedNbrs++;
        if (mappedNbrs < 2) return;
        // Find candidate with most adjacency overlap to mapped neighbors
        int bestPivot = 0, bestOverlap = 0;
        for (int c = 0; c < count; c++) {
            int tj = out[c];
            int overlap = 0;
            for (int nk = 0; nk < gq_.degree[qi]; ++nk) {
                int qk = gq_.neighbors[qi][nk];
                int tk = q2t_[qk];
                if (tk != -1) {
                    if (gt_.adjLong[tj][tk >> 6] & (uint64_t(1) << (tk & 63)))
                        overlap++;
                }
            }
            if (overlap > bestOverlap) { bestOverlap = overlap; bestPivot = c; }
        }
        if (bestPivot != 0) std::swap(out[0], out[bestPivot]);
    }

    // ----- Candidate selection (virtual, overridden by VF2/VF2PP) ----------

    virtual int selectCandidates(int qi, int* out) = 0;
    virtual void onMatch(int /*pos*/, int /*tj*/) {}
    virtual void onUnmatch(int /*pos*/, int /*tj*/) {}

    // ----- Backtracking (exists) -------------------------------------------

    void backtrack(const int* order, int pos) {
        if (tb_.expired()) { timedOut_ = true; return; }
        ++nodesVisited_;
        if (found_) return;
        if (pos == Nq_) { found_ = true; return; }
        int qi = order[pos];
        int nCands = selectCandidates(qi, candBufStack_[pos].data());
        for (int c = 0; c < nCands; ++c) {
            int tj = candBufStack_[pos][c];
            ++candidatesTried_;
            if (!feasible(qi, tj)) continue;
            q2t_[qi] = tj; t2q_[tj] = qi;
            usedMask_[tj >> 6] |= uint64_t(1) << (tj & 63);
            onMatch(pos, tj);
            backtrack(order, pos + 1);
            if (found_ || timedOut_) return;
            q2t_[qi] = -1; t2q_[tj] = -1;
            usedMask_[tj >> 6] &= ~(uint64_t(1) << (tj & 63));
            onUnmatch(pos, tj);
            ++backtracks_;
        }
    }

    // ----- Backtracking (enumerate all) ------------------------------------

    void enumerateRec(const int* order, int pos,
                      std::vector<std::vector<std::pair<int,int>>>& out,
                      int maxSolutions) {
        if (tb_.expired()) { timedOut_ = true; return; }
        ++nodesVisited_;
        if (static_cast<int>(out.size()) >= maxSolutions) return;
        if (pos == Nq_) {
            std::vector<std::pair<int,int>> map;
            map.reserve(Nq_);
            for (int k = 0; k < Nq_; ++k)
                map.emplace_back(order[k], q2t_[order[k]]);
            out.push_back(std::move(map));
            return;
        }
        int qi = order[pos];
        int nCands = selectCandidates(qi, candBufStack_[pos].data());
        for (int c = 0; c < nCands; ++c) {
            if (tb_.expired()) { timedOut_ = true; return; }
            int tj = candBufStack_[pos][c];
            ++candidatesTried_;
            if (!feasible(qi, tj)) continue;
            q2t_[qi] = tj; t2q_[tj] = qi;
            usedMask_[tj >> 6] |= uint64_t(1) << (tj & 63);
            onMatch(pos, tj);
            enumerateRec(order, pos + 1, out, maxSolutions);
            q2t_[qi] = -1; t2q_[tj] = -1;
            usedMask_[tj >> 6] &= ~(uint64_t(1) << (tj & 63));
            onUnmatch(pos, tj);
            ++backtracks_;
            if (static_cast<int>(out.size()) >= maxSolutions || timedOut_) return;
        }
    }

    // ----- Check if any query atom has empty domain ------------------------

    bool anyEmptyDomain() const {
        for (int i = 0; i < Nq_; ++i) {
            bool hasCandidate = false;
            for (int w = 0; w < tWords_; ++w) {
                if (domain_[i][w] != 0) { hasCandidate = true; break; }
            }
            if (!hasCandidate) return true;
        }
        return false;
    }
};

// ==========================================================================
// VF2Matcher -- classic VF2 with terminal-set candidate selection
// ==========================================================================

class VF2Matcher final : public AbstractVFMatcher {
    // Scratch for terminal mask computation
    std::vector<uint64_t> termMask_;
    std::vector<uint64_t> termAvail_;

public:
    VF2Matcher(const MolGraph& gq, const MolGraph& gt,
               const ChemOptions& C, int64_t timeoutMs)
        : AbstractVFMatcher(gq, gt, C, timeoutMs),
          termMask_(tWords_, 0),
          termAvail_(tWords_, 0)
    {}

    bool exists() {
        if (Nq_ == 0) return true;
        if (anyEmptyDomain()) return false;
        std::vector<int> order(Nq_);
        fastisoOrder(order.data());
        if (Nq_ <= 50 && greedyProbe(order.data())) { found_ = true; return true; }
        backtrack(order.data(), 0);
        return found_;
    }

    void enumerate(int maxSolutions,
                   std::vector<std::vector<std::pair<int,int>>>& out) {
        if (Nq_ == 0) { out.push_back({}); return; }
        std::vector<int> order(Nq_);
        fastisoOrder(order.data());
        enumerateRec(order.data(), 0, out, maxSolutions);
    }

    int selectCandidates(int qi, int* out) override {
        // Build terminal mask from mapped neighbors of qi
        std::memset(termMask_.data(), 0, tWords_ * sizeof(uint64_t));
        bool hasTerminal = false;
        for (int nk = 0; nk < gq_.degree[qi]; ++nk) {
            int qk = gq_.neighbors[qi][nk];
            int tk = q2t_[qk];
            if (tk != -1) {
                for (int w = 0; w < tWords_; ++w)
                    termMask_[w] |= gt_.adjLong[tk][w];
                hasTerminal = true;
            }
        }
        if (hasTerminal) {
            // Intersect domain with terminal mask
            bool hasAny = false;
            for (int w = 0; w < tWords_; ++w) {
                termAvail_[w] = domain_[qi][w] & ~usedMask_[w] & termMask_[w];
                if (termAvail_[w]) hasAny = true;
            }
            if (hasAny) {
                int count = 0;
                iterateBits(termAvail_.data(), tWords_, out, count);
                sortByDegreeProximity(out, count, qi);
                return count;
            }
        }
        // Fallback: all domain candidates
        int count = domainCandidates(qi, out);
        sortByDegreeProximity(out, count, qi);
        return count;
    }
};

// ==========================================================================
// VF2PPMatcher -- VF2++ with frontier mask and save/restore
// ==========================================================================

class VF2PPMatcher final : public AbstractVFMatcher {
    std::vector<uint64_t> tFrontierMask_;
    std::vector<uint64_t> candAvail_;
    std::vector<std::vector<uint64_t>> frontierStack_;
    bool pivotEnabled_ = false; // VF3-style pivot: only during exists()

public:
    VF2PPMatcher(const MolGraph& gq, const MolGraph& gt,
                 const ChemOptions& C, int64_t timeoutMs)
        : AbstractVFMatcher(gq, gt, C, timeoutMs),
          tFrontierMask_(tWords_, 0),
          candAvail_(tWords_, 0),
          frontierStack_(gq.n, std::vector<uint64_t>(((gt.n + 63) >> 6), 0))
    {}

    bool exists() {
        if (Nq_ == 0) return true;
        pivotEnabled_ = true;
        std::vector<int> order(Nq_);
        if (Nq_ > 30)
            vf3LightOrder(order.data());
        else
            fastisoOrder(order.data());
        if (Nq_ <= 50 && greedyProbe(order.data())) { found_ = true; pivotEnabled_ = false; return true; }
        std::fill(tFrontierMask_.begin(), tFrontierMask_.end(), uint64_t(0));
        backtrack(order.data(), 0);
        pivotEnabled_ = false;
        return found_;
    }

    void enumerate(int maxSolutions,
                   std::vector<std::vector<std::pair<int,int>>>& out) {
        if (Nq_ == 0) { out.push_back({}); return; }
        std::vector<int> order(Nq_);
        if (Nq_ > 30)
            vf3LightOrder(order.data());
        else
            fastisoOrder(order.data());
        std::fill(tFrontierMask_.begin(), tFrontierMask_.end(), uint64_t(0));
        enumerateRec(order.data(), 0, out, maxSolutions);
    }

    int selectCandidates(int qi, int* out) override {
        // Check if frontier is non-empty AND qi is connected to the mapped subgraph.
        // Without the connectivity check, disconnected query components (e.g.,
        // pharmacophore queries like [#6].[#8]) get incorrectly restricted to
        // the frontier of an unrelated mapped fragment, causing false negatives.
        bool hasFrontier = false;
        for (int w = 0; w < tWords_; ++w) {
            if (tFrontierMask_[w] != 0) { hasFrontier = true; break; }
        }
        if (hasFrontier) {
            bool qiConnected = false;
            for (int k = 0; k < gq_.degree[qi]; ++k)
                if (q2t_[gq_.neighbors[qi][k]] != -1) { qiConnected = true; break; }
            if (!qiConnected) hasFrontier = false;
        }
        if (hasFrontier) {
            bool hasAny = false;
            for (int w = 0; w < tWords_; ++w) {
                candAvail_[w] = domain_[qi][w] & ~usedMask_[w] & tFrontierMask_[w];
                if (candAvail_[w]) hasAny = true;
            }
            if (hasAny) {
                int count = 0;
                iterateBits(candAvail_.data(), tWords_, out, count);
                sortByDegreeProximity(out, count, qi);
                if (pivotEnabled_) applyPivotHeuristic(out, count, qi);
                return count;
            }
        }
        // Fallback: domain minus used
        for (int w = 0; w < tWords_; ++w)
            candAvail_[w] = domain_[qi][w] & ~usedMask_[w];
        int count = 0;
        iterateBits(candAvail_.data(), tWords_, out, count);
        sortByDegreeProximity(out, count, qi);
        if (pivotEnabled_) applyPivotHeuristic(out, count, qi);
        return count;
    }

    void onMatch(int pos, int tj) override {
        // Save frontier state
        std::memcpy(frontierStack_[pos].data(), tFrontierMask_.data(),
                    tWords_ * sizeof(uint64_t));
        // Add unmatched neighbors of tj to frontier
        for (int k = 0; k < gt_.degree[tj]; ++k) {
            int u = gt_.neighbors[tj][k];
            if (t2q_[u] == -1)
                tFrontierMask_[u >> 6] |= uint64_t(1) << (u & 63);
        }
        // Remove tj itself from frontier
        tFrontierMask_[tj >> 6] &= ~(uint64_t(1) << (tj & 63));
    }

    void onUnmatch(int pos, int /*tj*/) override {
        // Restore frontier state
        std::memcpy(tFrontierMask_.data(), frontierStack_[pos].data(),
                    tWords_ * sizeof(uint64_t));
    }
};

} // namespace detail

// ============================================================================
// Public API implementation
// ============================================================================

inline bool isSubstructure(const MolGraph& query, const MolGraph& target,
                           const ChemOptions& opts, int64_t timeoutMs) {
    if (query.n == 0) return true;
    if (query.n > target.n) return false;

    if (opts.matcherEngine == ChemOptions::MatcherEngine::VF2) {
        detail::VF2Matcher m(query, target, opts, timeoutMs);
        return m.exists();
    } else {
        detail::VF2PPMatcher m(query, target, opts, timeoutMs);
        return m.exists();
    }
}

inline std::vector<std::pair<int,int>> findSubstructure(
    const MolGraph& query, const MolGraph& target,
    const ChemOptions& opts, int64_t timeoutMs) {

    if (query.n == 0) return {};
    if (query.n > target.n) return {};

    std::vector<std::vector<std::pair<int,int>>> all;
    if (opts.matcherEngine == ChemOptions::MatcherEngine::VF2) {
        detail::VF2Matcher m(query, target, opts, timeoutMs);
        m.enumerate(1, all);
    } else {
        detail::VF2PPMatcher m(query, target, opts, timeoutMs);
        m.enumerate(1, all);
    }
    return all.empty() ? std::vector<std::pair<int,int>>{} : std::move(all[0]);
}

inline std::vector<std::vector<std::pair<int,int>>> findAllSubstructures(
    const MolGraph& query, const MolGraph& target,
    const ChemOptions& opts, int64_t timeoutMs) {

    if (query.n == 0) return {{}};
    if (query.n > target.n) return {};

    // Default max solutions: 10000
    constexpr int kMaxSolutions = 10000;
    std::vector<std::vector<std::pair<int,int>>> out;
    if (opts.matcherEngine == ChemOptions::MatcherEngine::VF2) {
        detail::VF2Matcher m(query, target, opts, timeoutMs);
        m.enumerate(kMaxSolutions, out);
    } else {
        detail::VF2PPMatcher m(query, target, opts, timeoutMs);
        m.enumerate(kMaxSolutions, out);
    }
    return out;
}

} // namespace smsd

#endif // SMSD_VF2PP_HPP
