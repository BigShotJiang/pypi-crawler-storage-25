"""Exception types raised by the client.

``EpaPmApiError`` carries the raw HTTP details *and* the structured EPA
error payload when the body parses as ``<response status="Error">``. The
flattened message string is preserved for backwards compatibility, but
production callers should prefer ``error_number`` / ``errors`` for
branching.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EpaErrorDetail:
    """One ``<error>`` element from an EPA error response."""

    error_number: int | None
    error_description: str | None


class EpaPmError(Exception):
    """Base exception for EPA PM API Wrapper."""


class EpaPmApiError(EpaPmError):
    """Exception raised for errors returned by the API.

    :ivar status_code: HTTP status code.
    :ivar response_text: Raw response body (XML or plain text).
    :ivar errors: Parsed list of EPA ``<error>`` entries when the body was
        a structured ``<response status="Error">`` payload; empty otherwise.
    :ivar error_number: Convenience accessor for the *first* EPA error
        number when there's exactly one error in the payload — handy for
        ``except EpaPmApiError as e: if e.error_number == 10: ...``. Use
        :attr:`errors` if multiple errors may be present.
    """

    def __init__(
        self,
        status_code: int,
        response_text: str,
        errors: list[EpaErrorDetail] | None = None,
    ):
        self.status_code = status_code
        self.response_text = response_text
        self.errors: list[EpaErrorDetail] = errors or []
        super().__init__(f"API error {status_code}: {response_text}")

    @property
    def error_number(self) -> int | None:
        """The EPA error number when exactly one error was reported, else ``None``."""
        if len(self.errors) == 1:
            return self.errors[0].error_number
        return None


class EpaPmAuthError(EpaPmApiError):
    """Exception raised for authentication errors."""

    def __init__(self, status_code: int, response_text: str):
        super().__init__(status_code, response_text)
        self.args = (
            "Authentication failed. Please check your credentials (username/password) and ensure "
            f"you are targeting the correct environment (live vs test). Details: {response_text}",
        )
