"""Link helpers — extract IDs from ``LinkType`` regardless of source quirks."""

from __future__ import annotations

import re

from .models import LinkType

_TAIL_RE = re.compile(r"/(\d+)/?$")


def link_id(link: LinkType) -> int | None:
    """Return the ID for a link, falling back to URL-tail parsing.

    Some EPA list/create responses populate ``LinkType@id`` directly;
    others embed the id only in the ``link`` URL (e.g.
    ``/meter/individual/2601``). This helper tries the attribute first,
    then the trailing-integer of the URL.
    """
    if link.id is not None:
        return link.id
    if link.link:
        match = _TAIL_RE.search(link.link)
        if match:
            return int(match.group(1))
    return None
