from __future__ import annotations

from dataclasses import dataclass

from .hierarchy_type import HierarchyType


@dataclass(kw_only=True)
class Hierarchy(HierarchyType):
    """
    Contains the identifiers of the entities that are above a particular
    entity in the Portfolio Manager hierarchy.
    """

    class Meta:
        name = "hierarchy"
