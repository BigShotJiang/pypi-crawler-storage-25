from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfLaundryHookupsInCommonArea(UseIntegerType):
    """
    The total number of laundry hookups in all common areas (counting
    hookups, whether or not there is a machine).
    """

    class Meta:
        name = "numberOfLaundryHookupsInCommonArea"
