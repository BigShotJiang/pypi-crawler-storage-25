from __future__ import annotations

from dataclasses import dataclass

from .manufacturing_industrial_plant_type import (
    ManufacturingIndustrialPlantType,
)


@dataclass(kw_only=True)
class ManufacturingIndustrialPlant(ManufacturingIndustrialPlantType):
    """
    Buildings used for manufacturing or assembling goods.
    """

    class Meta:
        name = "manufacturingIndustrialPlant"
