from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherUtility(OtherType):
    """
    Buildings used by a utility for some purpose other than general office
    or energy/power generation.
    """

    class Meta:
        name = "otherUtility"
