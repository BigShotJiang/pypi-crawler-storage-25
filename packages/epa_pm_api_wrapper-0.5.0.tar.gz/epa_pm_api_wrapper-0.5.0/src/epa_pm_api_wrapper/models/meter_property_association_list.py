from __future__ import annotations

from dataclasses import dataclass

from .meter_property_association_list_type import (
    MeterPropertyAssociationListType,
)


@dataclass(kw_only=True)
class MeterPropertyAssociationList(MeterPropertyAssociationListType):
    """
    Indicates the association you want to create for a set of meters and a
    specific property.
    """

    class Meta:
        name = "meterPropertyAssociationList"
