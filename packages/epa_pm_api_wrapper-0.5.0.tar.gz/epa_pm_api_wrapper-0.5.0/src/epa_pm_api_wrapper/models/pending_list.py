from __future__ import annotations

from dataclasses import dataclass

from .pending_list_type import PendingListType


@dataclass(kw_only=True)
class PendingList(PendingListType):
    """
    Contains the list of pending connection and share requests.
    """

    class Meta:
        name = "pendingList"
