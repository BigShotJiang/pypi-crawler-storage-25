from __future__ import annotations

from dataclasses import dataclass, field

from .meter_consumption_type import MeterConsumptionType


@dataclass(kw_only=True)
class HeyTypeMeterMeterData:
    class Meta:
        global_type = False

    meter_consumption: list[MeterConsumptionType] = field(
        default_factory=list,
        metadata={
            "name": "meterConsumption",
            "type": "Element",
            "namespace": "",
            "min_occurs": 1,
            "max_occurs": 120,
        },
    )
