from __future__ import annotations

from dataclasses import dataclass, field

from .additional_identifier_type import AdditionalIdentifierType


@dataclass(kw_only=True)
class AdditionalIdentifier:
    """
    The values associated to the additional property/meter identifier for a
    given property.

    This is used when you provide the values (update or add) to an
    additional property identifier for a specific property.

    :ivar additional_identifier_type:
    :ivar description: The description of the specific additional
        property identifier when values are provided for it.
    :ivar value: The value of the additional property identifier for a
        specific property.
    :ivar id: The id of the transaction when values are provided for a
        specific additional property identifier and property.
    """

    class Meta:
        name = "additionalIdentifier"

    additional_identifier_type: AdditionalIdentifierType = field(
        metadata={
            "name": "additionalIdentifierType",
            "type": "Element",
        }
    )
    description: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 1000,
        },
    )
    value: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 4000,
        },
    )
    id: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
