from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfSterilizationUnits(UseDecimalType):
    """
    Number of working autoclaves and sterilizers in the building.
    """

    class Meta:
        name = "numberOfSterilizationUnits"
