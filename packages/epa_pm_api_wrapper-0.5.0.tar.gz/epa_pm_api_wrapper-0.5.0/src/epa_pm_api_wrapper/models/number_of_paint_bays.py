from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfPaintBays(UseDecimalType):
    """
    The number of paint bays is the number of spaces in a contained booth
    for painting or painting preparatory work.
    """

    class Meta:
        name = "numberOfPaintBays"
