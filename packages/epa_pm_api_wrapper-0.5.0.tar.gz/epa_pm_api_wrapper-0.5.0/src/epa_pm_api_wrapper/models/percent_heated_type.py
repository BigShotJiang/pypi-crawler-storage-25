from __future__ import annotations

from dataclasses import dataclass, field

from .percent_heated_type_value import PercentHeatedTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class PercentHeatedType(UseAttributeBase):
    class Meta:
        name = "percentHeatedType"

    value: None | PercentHeatedTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
