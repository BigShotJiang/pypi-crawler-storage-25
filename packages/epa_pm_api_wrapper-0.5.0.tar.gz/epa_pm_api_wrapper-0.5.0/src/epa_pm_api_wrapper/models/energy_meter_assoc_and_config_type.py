from __future__ import annotations

from dataclasses import dataclass, field

from .meter_list_type import MeterListType
from .property_representation import PropertyRepresentation


@dataclass(kw_only=True)
class EnergyMeterAssocAndConfigType:
    class Meta:
        name = "energyMeterAssocAndConfigType"

    meters: MeterListType = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    property_representation: PropertyRepresentation = field(
        metadata={
            "name": "propertyRepresentation",
            "type": "Element",
        }
    )
