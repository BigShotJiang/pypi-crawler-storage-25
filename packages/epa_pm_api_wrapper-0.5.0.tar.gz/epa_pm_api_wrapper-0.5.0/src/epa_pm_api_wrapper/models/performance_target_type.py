from __future__ import annotations

from dataclasses import dataclass, field

from .performance_target_type_target_metric import (
    PerformanceTargetTypeTargetMetric,
)
from .performance_target_type_target_value import (
    PerformanceTargetTypeTargetValue,
)


@dataclass(kw_only=True)
class PerformanceTargetType:
    """
    :ivar target_metric: Target metric option
    :ivar target_value: Target metric value used for the selected target
        metric.  This is not required if a "No Target" metric is
        selected.  For target metric options of "Target % Better than
        Baseline" and "Target % Better than Median", the valid range is
        0-100.  For "Target ENERGY STAR Score", the valid range is
        1-100.
    """

    class Meta:
        name = "performanceTargetType"

    target_metric: PerformanceTargetTypeTargetMetric = field(
        metadata={
            "name": "targetMetric",
            "type": "Element",
            "namespace": "",
        }
    )
    target_value: None | PerformanceTargetTypeTargetValue = field(
        default=None,
        metadata={
            "name": "targetValue",
            "type": "Element",
            "namespace": "",
        },
    )
