from __future__ import annotations

from dataclasses import dataclass

from .non_refrigerated_warehouse_type import NonRefrigeratedWarehouseType


@dataclass(kw_only=True)
class NonRefrigeratedWarehouse(NonRefrigeratedWarehouseType):
    """
    Unrefrigerated Buildings that are used to store goods, manufactured
    products, merchandise or raw materials.
    """

    class Meta:
        name = "nonRefrigeratedWarehouse"
