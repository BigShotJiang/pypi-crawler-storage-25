from __future__ import annotations

from dataclasses import dataclass, field

from .renewable_generation_technology_enum import (
    RenewableGenerationTechnologyEnum,
)


@dataclass(kw_only=True)
class OnsiteRenewableOptionalInfoTypeRenewableGenerationTechnologies:
    class Meta:
        global_type = False

    technology: list[RenewableGenerationTechnologyEnum] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
