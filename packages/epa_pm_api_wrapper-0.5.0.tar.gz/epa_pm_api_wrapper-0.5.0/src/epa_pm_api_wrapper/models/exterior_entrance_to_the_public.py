from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class ExteriorEntranceToThePublic(UseYesNoType):
    """
    Whether there is an Exterior Entrance to the Public.
    """

    class Meta:
        name = "exteriorEntranceToThePublic"
