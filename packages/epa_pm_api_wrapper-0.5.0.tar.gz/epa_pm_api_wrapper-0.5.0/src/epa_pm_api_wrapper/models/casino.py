from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class Casino(OtherType):
    """
    Buildings primarily used to conduct gambling activities including both
    electronic and live table games.
    """

    class Meta:
        name = "casino"
