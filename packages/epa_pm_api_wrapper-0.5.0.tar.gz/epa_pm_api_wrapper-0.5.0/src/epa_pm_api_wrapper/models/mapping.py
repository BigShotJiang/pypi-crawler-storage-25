from __future__ import annotations

from dataclasses import dataclass

from .mapping_type import MappingType


@dataclass(kw_only=True)
class Mapping(MappingType):
    class Meta:
        name = "mapping"
