from __future__ import annotations

from dataclasses import dataclass

from .library_type import LibraryType


@dataclass(kw_only=True)
class Library(LibraryType):
    """
    Library refers to buildings used to store and manage collections of
    literary and artistic materials such as books, periodicals, newspapers,
    films, etc. that can be used for reference or lending.
    """

    class Meta:
        name = "library"
