from __future__ import annotations

from dataclasses import dataclass, field

from .license import License


@dataclass(kw_only=True)
class LicenseList:
    class Meta:
        name = "licenseList"

    license: list[License] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "max_occurs": 50,
        },
    )
