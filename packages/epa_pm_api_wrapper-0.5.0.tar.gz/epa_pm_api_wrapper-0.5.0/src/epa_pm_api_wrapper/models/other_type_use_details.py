from __future__ import annotations

from dataclasses import dataclass, field

from .number_of_computers import NumberOfComputers
from .number_of_workers import NumberOfWorkers
from .total_gross_floor_area import TotalGrossFloorArea
from .weekly_operating_hours import WeeklyOperatingHours


@dataclass(kw_only=True)
class OtherTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    weekly_operating_hours: None | WeeklyOperatingHours = field(
        default=None,
        metadata={
            "name": "weeklyOperatingHours",
            "type": "Element",
        },
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
