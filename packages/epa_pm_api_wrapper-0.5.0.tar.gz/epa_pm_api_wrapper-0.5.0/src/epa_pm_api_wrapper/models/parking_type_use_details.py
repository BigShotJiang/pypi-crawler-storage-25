from __future__ import annotations

from dataclasses import dataclass, field

from .completely_enclosed_footage import CompletelyEnclosedFootage
from .open_footage import OpenFootage
from .partially_enclosed_footage import PartiallyEnclosedFootage
from .supplemental_heating import SupplementalHeating


@dataclass(kw_only=True)
class ParkingTypeUseDetails:
    class Meta:
        global_type = False

    supplemental_heating: None | SupplementalHeating = field(
        default=None,
        metadata={
            "name": "supplementalHeating",
            "type": "Element",
        },
    )
    open_footage: OpenFootage = field(
        metadata={
            "name": "openFootage",
            "type": "Element",
        }
    )
    completely_enclosed_footage: CompletelyEnclosedFootage = field(
        metadata={
            "name": "completelyEnclosedFootage",
            "type": "Element",
        }
    )
    partially_enclosed_footage: PartiallyEnclosedFootage = field(
        metadata={
            "name": "partiallyEnclosedFootage",
            "type": "Element",
        }
    )
