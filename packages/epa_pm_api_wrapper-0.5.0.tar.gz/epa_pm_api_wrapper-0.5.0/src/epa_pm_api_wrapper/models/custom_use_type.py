from __future__ import annotations

from dataclasses import dataclass, field

from .custom_use_type_use_details import CustomUseTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class CustomUseType:
    class Meta:
        name = "customUseType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: CustomUseTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
