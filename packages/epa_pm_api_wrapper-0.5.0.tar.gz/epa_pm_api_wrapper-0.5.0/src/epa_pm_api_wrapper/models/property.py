from __future__ import annotations

from dataclasses import dataclass

from .property_type import PropertyType


@dataclass(kw_only=True)
class Property(PropertyType):
    class Meta:
        name = "property"
