from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class Prison(OtherType):
    """
    Prison/Incarceration federal, state, local, or private-sector Buildings
    used for the detention of persons awaiting trial or convicted of
    crimes.
    """

    class Meta:
        name = "prison"
