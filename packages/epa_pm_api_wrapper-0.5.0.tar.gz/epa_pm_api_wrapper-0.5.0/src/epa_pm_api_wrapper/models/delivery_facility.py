from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class DeliveryFacility(UseYesNoType):
    """
    Denotes if a facility delivers mail products directly from the building
    to offsite customers at their residence or place of business.
    """

    class Meta:
        name = "deliveryFacility"
