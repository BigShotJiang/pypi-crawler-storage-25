from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfResidentialLivingUnitsMidRiseSetting(UseDecimalType):
    """
    Number of units located in individual buildings that are 5 to 9 stories
    in height, as well as units located wings/portions of larger buildings
    that fall in this height range (e.g. if Wing A is 6 stories and Wing B
    is 3 stories, only units in Wing A would be counted here).
    """

    class Meta:
        name = "numberOfResidentialLivingUnitsMidRiseSetting"
