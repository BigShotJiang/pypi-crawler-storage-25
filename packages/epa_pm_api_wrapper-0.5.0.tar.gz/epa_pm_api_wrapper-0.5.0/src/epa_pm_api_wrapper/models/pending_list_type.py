from __future__ import annotations

from dataclasses import dataclass, field

from .links_type import LinksType
from .pending_accounts_type import PendingAccountsType
from .pending_meters_type import PendingMetersType
from .pending_properties_type import PendingPropertiesType


@dataclass(kw_only=True)
class PendingListType:
    """
    :ivar account: Indicates a pending connection request and detailed
        information.
    :ivar property: Indicates a pending property share request and
        detailed information.
    :ivar meter: Indicates a pending meter share request and detailed
        information
    :ivar links:
    """

    class Meta:
        name = "pendingListType"

    account: list[PendingAccountsType] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    property: list[PendingPropertiesType] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    meter: list[PendingMetersType] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    links: None | LinksType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
