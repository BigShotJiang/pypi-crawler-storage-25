from __future__ import annotations

from dataclasses import dataclass, field

from .all_meter_types import AllMeterTypes


@dataclass(kw_only=True)
class DataExchangeSettingsSupportedMeterTypes:
    class Meta:
        global_type = False

    meter_type: list[AllMeterTypes] = field(
        default_factory=list,
        metadata={
            "name": "meterType",
            "type": "Element",
            "namespace": "",
        },
    )
