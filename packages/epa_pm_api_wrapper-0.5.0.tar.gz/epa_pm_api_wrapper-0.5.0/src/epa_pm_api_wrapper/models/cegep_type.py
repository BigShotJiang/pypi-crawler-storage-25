from __future__ import annotations

from dataclasses import dataclass, field

from .cegep_type_use_details import CegepTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class CegepType:
    class Meta:
        name = "cegepType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: CegepTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
