from __future__ import annotations

from dataclasses import dataclass, field

from .barracks_type_use_details import BarracksTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class BarracksType:
    class Meta:
        name = "barracksType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: BarracksTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
