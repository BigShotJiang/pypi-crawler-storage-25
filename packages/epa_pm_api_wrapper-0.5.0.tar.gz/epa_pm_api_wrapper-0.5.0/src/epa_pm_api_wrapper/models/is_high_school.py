from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class IsHighSchool(UseYesNoType):
    """
    Presence of a High School, as indicated by education of grades 10, 11,
    and/or 12 (Yes/No).
    """

    class Meta:
        name = "isHighSchool"
