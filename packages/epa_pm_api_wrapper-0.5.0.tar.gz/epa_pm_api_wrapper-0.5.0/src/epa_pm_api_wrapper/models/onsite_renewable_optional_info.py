from __future__ import annotations

from dataclasses import dataclass

from .onsite_renewable_optional_info_type import (
    OnsiteRenewableOptionalInfoType,
)


@dataclass(kw_only=True)
class OnsiteRenewableOptionalInfo(OnsiteRenewableOptionalInfoType):
    class Meta:
        name = "onsiteRenewableOptionalInfo"
