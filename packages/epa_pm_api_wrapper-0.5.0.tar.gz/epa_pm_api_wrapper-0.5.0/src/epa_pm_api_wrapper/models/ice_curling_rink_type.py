from __future__ import annotations

from dataclasses import dataclass, field

from .ice_curling_rink_type_use_details import IceCurlingRinkTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class IceCurlingRinkType:
    class Meta:
        name = "iceCurlingRinkType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: IceCurlingRinkTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
