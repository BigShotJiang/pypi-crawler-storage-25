from __future__ import annotations

from dataclasses import dataclass

from .optional_floor_area_type import OptionalFloorAreaType


@dataclass(kw_only=True)
class EnclosedFloorArea(OptionalFloorAreaType):
    """
    Total enclosed floor area at a Stadium/Arena.
    """

    class Meta:
        name = "enclosedFloorArea"
