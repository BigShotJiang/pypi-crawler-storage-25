from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from xsdata.models.datatype import XmlDate

from .category_type import CategoryType
from .evaluation_period_type import EvaluationPeriodType
from .log_type import LogType


@dataclass(kw_only=True)
class EnergyPerformanceProjectType:
    """
    :ivar project_name: The name of the energy performance project.
    :ivar project_description: The description of the energy performance
        project.
    :ivar property_id: The id to the corresponding property.  This field
        is ignore if provided on a PUT or POST.
    :ivar property_name: The name of the corresponding property.  This
        field is ignore if provided on a PUT or POST.
    :ivar implementation_date: The date the project is going to be or
        was implemented.
    :ivar category: Indicates the category or stage the project fits
        within.
    :ivar category_other_description: If the category type is "Other,"
        then an additional description is required.
    :ivar investment_cost: The cost of the project (investment).
    :ivar estimated_savings_cost: The estimated cost savings of the
        project.
    :ivar evaluation_period: Providing evaluation periods will allow
        Portfolio Manager to show you energy metrics before and after
        you implemented your project. By default, these periods are set
        to one month prior to and 13 months after your implementation
        date.
    :ivar audit:
    """

    class Meta:
        name = "energyPerformanceProjectType"

    project_name: None | str = field(
        default=None,
        metadata={
            "name": "projectName",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 50,
        },
    )
    project_description: None | str = field(
        default=None,
        metadata={
            "name": "projectDescription",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 2000,
        },
    )
    property_id: None | int = field(
        default=None,
        metadata={
            "name": "propertyId",
            "type": "Element",
            "namespace": "",
        },
    )
    property_name: None | str = field(
        default=None,
        metadata={
            "name": "propertyName",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 80,
        },
    )
    implementation_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "implementationDate",
            "type": "Element",
            "namespace": "",
        },
    )
    category: None | CategoryType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    category_other_description: None | str = field(
        default=None,
        metadata={
            "name": "categoryOtherDescription",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 50,
        },
    )
    investment_cost: None | Decimal = field(
        default=None,
        metadata={
            "name": "investmentCost",
            "type": "Element",
            "namespace": "",
        },
    )
    estimated_savings_cost: None | Decimal = field(
        default=None,
        metadata={
            "name": "estimatedSavingsCost",
            "type": "Element",
            "namespace": "",
        },
    )
    evaluation_period: None | EvaluationPeriodType = field(
        default=None,
        metadata={
            "name": "evaluationPeriod",
            "type": "Element",
            "namespace": "",
        },
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
