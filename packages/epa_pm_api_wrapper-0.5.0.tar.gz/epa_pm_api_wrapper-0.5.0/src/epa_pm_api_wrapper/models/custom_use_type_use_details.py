from __future__ import annotations

from dataclasses import dataclass, field

from .custom_use_detail1 import CustomUseDetail1
from .custom_use_detail2 import CustomUseDetail2


@dataclass(kw_only=True)
class CustomUseTypeUseDetails:
    class Meta:
        global_type = False

    custom_use_detail1: None | CustomUseDetail1 = field(
        default=None,
        metadata={
            "name": "customUseDetail1",
            "type": "Element",
        },
    )
    custom_use_detail2: None | CustomUseDetail2 = field(
        default=None,
        metadata={
            "name": "customUseDetail2",
            "type": "Element",
        },
    )
