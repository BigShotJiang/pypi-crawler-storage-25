from __future__ import annotations

from dataclasses import dataclass

from .months_in_use_type import MonthsInUseType


@dataclass(kw_only=True)
class MonthsInUse(MonthsInUseType):
    """
    Number of months per year the property is in use.
    """

    class Meta:
        name = "monthsInUse"
