from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class LicensedBedCapacity(UseDecimalType):
    """
    Licensed Bed Capacity is the total number of beds that your hospital is
    licensed to have in operation.

    This may be more than your Staffed Beds, which are those that are set
    up and ready for use.
    """

    class Meta:
        name = "licensedBedCapacity"
