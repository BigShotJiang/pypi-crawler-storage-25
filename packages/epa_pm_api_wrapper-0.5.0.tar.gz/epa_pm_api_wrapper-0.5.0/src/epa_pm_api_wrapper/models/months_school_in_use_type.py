from __future__ import annotations

from dataclasses import dataclass, field

from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class MonthsSchoolInUseType(UseAttributeBase):
    class Meta:
        name = "monthsSchoolInUseType"

    value: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": 8,
            "max_inclusive": 12,
        },
    )
