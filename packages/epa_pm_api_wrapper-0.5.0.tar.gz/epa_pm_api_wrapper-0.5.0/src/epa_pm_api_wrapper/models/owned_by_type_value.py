from __future__ import annotations

from enum import Enum


class OwnedByTypeValue(Enum):
    FOR_PROFIT = "For Profit"
    NON_PROFIT = "Non Profit"
    GOVERNMENTAL = "Governmental"
