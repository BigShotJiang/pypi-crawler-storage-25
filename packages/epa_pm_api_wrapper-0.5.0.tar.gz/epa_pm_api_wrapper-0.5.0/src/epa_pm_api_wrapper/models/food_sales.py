from __future__ import annotations

from dataclasses import dataclass

from .food_sales_type import FoodSalesType


@dataclass(kw_only=True)
class FoodSales(FoodSalesType):
    """
    Buildings used for the sales of food on either a retail or wholesale
    basis, but which do not meet the definition of Supermarket/Grocery
    Store, Convenience Store, or Convenience Store with Gas Station.
    """

    class Meta:
        name = "foodSales"
