from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlDate

from .log_type import LogType
from .meter_type_unit_of_measure import MeterTypeUnitOfMeasure
from .share_level_type import ShareLevelType
from .type_of_meter import TypeOfMeter


@dataclass(kw_only=True)
class MeterType:
    """
    A service type used for representing a meter.

    :ivar id: The id of the meter.
    :ivar type_value: The type of meter (i.e. electric, natural gas,
        PDU, Indoor, etc.).
    :ivar name: The name of the meter.
    :ivar metered: Indicates if the meter is set up to be metered
        monthly or for bulk delivery.
    :ivar unit_of_measure: The units that measure the energy for the
        meter (Kbtu, KWh, Mbtu, MWh, ccf, gallons, etc.).
    :ivar first_bill_date: The date of the first bill.
    :ivar in_use: Is this meter in use?
    :ivar inactive_date: If the meter is no longer in use, this is the
        date that it went inactive.
    :ivar other_description: If the type of meter is "Other," this is
        the description of the meter's energy type.
    :ivar access_level: Current share level for the user calling the
        webservice.
    :ivar aggregate_meter: If the meter is aggregate meter or not.
    :ivar audit:
    """

    class Meta:
        name = "meterType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    type_value: TypeOfMeter = field(
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "",
        }
    )
    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 100,
        }
    )
    metered: None | bool = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    unit_of_measure: MeterTypeUnitOfMeasure = field(
        metadata={
            "name": "unitOfMeasure",
            "type": "Element",
            "namespace": "",
        }
    )
    first_bill_date: XmlDate = field(
        metadata={
            "name": "firstBillDate",
            "type": "Element",
            "namespace": "",
        }
    )
    in_use: bool = field(
        metadata={
            "name": "inUse",
            "type": "Element",
            "namespace": "",
        }
    )
    inactive_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "inactiveDate",
            "type": "Element",
            "namespace": "",
        },
    )
    other_description: None | str = field(
        default=None,
        metadata={
            "name": "otherDescription",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 100,
        },
    )
    access_level: None | ShareLevelType = field(
        default=None,
        metadata={
            "name": "accessLevel",
            "type": "Element",
            "namespace": "",
        },
    )
    aggregate_meter: None | bool = field(
        default=None,
        metadata={
            "name": "aggregateMeter",
            "type": "Element",
            "namespace": "",
        },
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
