from __future__ import annotations

from dataclasses import dataclass

from .refrigerated_warehouse_type import RefrigeratedWarehouseType


@dataclass(kw_only=True)
class RefrigeratedWarehouse(RefrigeratedWarehouseType):
    """
    Refrigerated buildings that are used to store perishable goods or
    merchandise under refrigeration at temperatures below 50 degrees
    Fahrenheit.
    """

    class Meta:
        name = "refrigeratedWarehouse"
