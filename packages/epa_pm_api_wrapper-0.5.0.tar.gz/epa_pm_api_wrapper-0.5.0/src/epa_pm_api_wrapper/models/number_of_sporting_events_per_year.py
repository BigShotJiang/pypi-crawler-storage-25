from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfSportingEventsPerYear(UseIntegerType):
    """
    Number of sporting/athletic events per year.
    """

    class Meta:
        name = "numberOfSportingEventsPerYear"
