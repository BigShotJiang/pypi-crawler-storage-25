from __future__ import annotations

from dataclasses import dataclass, field

from .energy_meter_assoc_and_config_type import EnergyMeterAssocAndConfigType
from .waste_meter_assoc_and_config_type import WasteMeterAssocAndConfigType
from .water_meter_assoc_and_config_type import WaterMeterAssocAndConfigType


@dataclass(kw_only=True)
class MeterPropertyAssociationListType:
    class Meta:
        name = "meterPropertyAssociationListType"

    energy_meter_association: None | EnergyMeterAssocAndConfigType = field(
        default=None,
        metadata={
            "name": "energyMeterAssociation",
            "type": "Element",
            "namespace": "",
        },
    )
    water_meter_association: None | WaterMeterAssocAndConfigType = field(
        default=None,
        metadata={
            "name": "waterMeterAssociation",
            "type": "Element",
            "namespace": "",
        },
    )
    waste_meter_association: None | WasteMeterAssocAndConfigType = field(
        default=None,
        metadata={
            "name": "wasteMeterAssociation",
            "type": "Element",
            "namespace": "",
        },
    )
