from __future__ import annotations

from dataclasses import dataclass, field

from .college_university_type_use_details import (
    CollegeUniversityTypeUseDetails,
)
from .log_type import LogType


@dataclass(kw_only=True)
class CollegeUniversityType:
    class Meta:
        name = "collegeUniversityType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: CollegeUniversityTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
