from __future__ import annotations

from dataclasses import dataclass, field

from .account_info import AccountInfo
from .custom_field_list import CustomFieldList
from .log_type import LogType


@dataclass(kw_only=True)
class PendingAccountsType:
    """
    :ivar account_id: The id of the Portfolio Manager Account requesting
        to connect with you.
    :ivar username: The username of the Portfolio Manager Account
        requesting to connect with you.
    :ivar custom_field_list:
    :ivar account_info:
    :ivar connection_audit:
    """

    class Meta:
        name = "pendingAccountsType"

    account_id: int = field(
        metadata={
            "name": "accountId",
            "type": "Element",
            "namespace": "",
        }
    )
    username: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    custom_field_list: None | CustomFieldList = field(
        default=None,
        metadata={
            "name": "customFieldList",
            "type": "Element",
        },
    )
    account_info: AccountInfo = field(
        metadata={
            "name": "accountInfo",
            "type": "Element",
        }
    )
    connection_audit: None | LogType = field(
        default=None,
        metadata={
            "name": "connectionAudit",
            "type": "Element",
            "namespace": "",
        },
    )
