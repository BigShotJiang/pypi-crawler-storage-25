from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class Laboratory(OtherType):
    """
    Buildings that provide controlled conditions in which scientific
    research, measurement, and experiments are performed or practical
    science is taught.
    """

    class Meta:
        name = "laboratory"
