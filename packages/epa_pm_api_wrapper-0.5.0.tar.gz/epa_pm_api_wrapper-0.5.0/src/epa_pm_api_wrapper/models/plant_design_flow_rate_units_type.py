from __future__ import annotations

from enum import Enum


class PlantDesignFlowRateUnitsType(Enum):
    MILLION_GALLONS_PER_DAY = "Million Gallons per Day"
    CUBIC_METERS_PER_DAY = "Cubic Meters per Day"
