from __future__ import annotations

from dataclasses import dataclass, field

from .number_of_annual_emergency_incidents import (
    NumberOfAnnualEmergencyIncidents,
)
from .number_of_computers import NumberOfComputers
from .number_of_emergency_vehicles import NumberOfEmergencyVehicles
from .number_of_fteworkers import NumberOfFteworkers
from .number_of_workers import NumberOfWorkers
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .total_gross_floor_area import TotalGrossFloorArea
from .weekly_building_occupied_hours import WeeklyBuildingOccupiedHours
from .weekly_operating_hours import WeeklyOperatingHours


@dataclass(kw_only=True)
class FireStationTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    weekly_operating_hours: None | WeeklyOperatingHours = field(
        default=None,
        metadata={
            "name": "weeklyOperatingHours",
            "type": "Element",
        },
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    number_of_fteworkers: None | NumberOfFteworkers = field(
        default=None,
        metadata={
            "name": "numberOfFTEWorkers",
            "type": "Element",
        },
    )
    number_of_emergency_vehicles: None | NumberOfEmergencyVehicles = field(
        default=None,
        metadata={
            "name": "numberOfEmergencyVehicles",
            "type": "Element",
        },
    )
    number_of_annual_emergency_incidents: None | NumberOfAnnualEmergencyIncidents = field(
        default=None,
        metadata={
            "name": "numberOfAnnualEmergencyIncidents",
            "type": "Element",
        },
    )
    weekly_building_occupied_hours: None | WeeklyBuildingOccupiedHours = field(
        default=None,
        metadata={
            "name": "weeklyBuildingOccupiedHours",
            "type": "Element",
        },
    )
