from __future__ import annotations

from dataclasses import dataclass, field

from .courthouse_type_use_details import CourthouseTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class CourthouseType:
    class Meta:
        name = "courthouseType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: CourthouseTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
