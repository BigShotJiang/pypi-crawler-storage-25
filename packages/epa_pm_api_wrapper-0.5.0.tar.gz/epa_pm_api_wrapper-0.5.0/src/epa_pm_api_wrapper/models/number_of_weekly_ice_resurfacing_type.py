from __future__ import annotations

from dataclasses import dataclass, field

from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class NumberOfWeeklyIceResurfacingType(UseAttributeBase):
    class Meta:
        name = "numberOfWeeklyIceResurfacingType"

    value: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": 1,
        },
    )
