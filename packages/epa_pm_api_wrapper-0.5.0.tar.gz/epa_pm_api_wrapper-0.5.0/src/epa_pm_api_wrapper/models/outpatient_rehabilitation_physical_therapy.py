from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OutpatientRehabilitationPhysicalTherapy(OtherType):
    """
    Buildings used to provide diagnosis and treatment for rehabilitation
    and physical therapy.
    """

    class Meta:
        name = "outpatientRehabilitationPhysicalTherapy"
