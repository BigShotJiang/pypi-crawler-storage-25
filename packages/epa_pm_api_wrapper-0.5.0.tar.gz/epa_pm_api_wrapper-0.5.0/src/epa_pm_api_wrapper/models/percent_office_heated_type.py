from __future__ import annotations

from dataclasses import dataclass, field

from .percent_office_heated_type_value import PercentOfficeHeatedTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class PercentOfficeHeatedType(UseAttributeBase):
    class Meta:
        name = "percentOfficeHeatedType"

    value: None | PercentOfficeHeatedTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
