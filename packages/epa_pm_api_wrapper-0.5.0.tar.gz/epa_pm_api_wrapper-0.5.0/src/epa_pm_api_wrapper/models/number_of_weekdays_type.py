from __future__ import annotations

from dataclasses import dataclass, field

from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class NumberOfWeekdaysType(UseAttributeBase):
    class Meta:
        name = "numberOfWeekdaysType"

    value: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": 0,
            "max_inclusive": 5,
        },
    )
