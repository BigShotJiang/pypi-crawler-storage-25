from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class LinkType:
    """
    :ivar id: Indicates the unique Portfolio Manager identifier used to
        define this entity.
    :ivar link_description: The description of the link.
    :ivar link: The URL to a web service call for subsequent processing.
    :ivar http_method: The HTTP method to the web service call.
    :ivar hint: A brief description of the information returned from the
        link.
    """

    class Meta:
        name = "linkType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    link_description: None | str = field(
        default=None,
        metadata={
            "name": "linkDescription",
            "type": "Attribute",
        },
    )
    link: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    http_method: None | str = field(
        default=None,
        metadata={
            "name": "httpMethod",
            "type": "Attribute",
        },
    )
    hint: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
