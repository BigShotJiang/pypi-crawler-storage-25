from __future__ import annotations

from dataclasses import dataclass

from .offsite_green_power_purchase_type import OffsiteGreenPowerPurchaseType


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchase(OffsiteGreenPowerPurchaseType):
    class Meta:
        name = "offsiteGreenPowerPurchase"
