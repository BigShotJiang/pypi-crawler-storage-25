from __future__ import annotations

from dataclasses import dataclass

from .hotel_type import HotelType


@dataclass(kw_only=True)
class Hotel(HotelType):
    """
    Buildings that sell overnight accommodations on a room/suite and
    nightly basis, and typically include a bath/shower and other facilities
    in guest rooms.
    """

    class Meta:
        name = "hotel"
