from __future__ import annotations

from dataclasses import dataclass, field

from .number_of_dc_fast_ev_charging_stations import (
    NumberOfDcFastEvChargingStations,
)
from .number_of_level_one_ev_charging_stations import (
    NumberOfLevelOneEvChargingStations,
)
from .number_of_level_two_ev_charging_stations import (
    NumberOfLevelTwoEvChargingStations,
)


@dataclass(kw_only=True)
class EvChargingStationTypeUseDetails:
    class Meta:
        global_type = False

    number_of_level_one_ev_charging_stations: None | NumberOfLevelOneEvChargingStations = field(
        default=None,
        metadata={
            "name": "numberOfLevelOneEvChargingStations",
            "type": "Element",
        },
    )
    number_of_level_two_ev_charging_stations: None | NumberOfLevelTwoEvChargingStations = field(
        default=None,
        metadata={
            "name": "numberOfLevelTwoEvChargingStations",
            "type": "Element",
        },
    )
    number_of_dc_fast_ev_charging_stations: None | NumberOfDcFastEvChargingStations = field(
        default=None,
        metadata={
            "name": "numberOfDcFastEvChargingStations",
            "type": "Element",
        },
    )
