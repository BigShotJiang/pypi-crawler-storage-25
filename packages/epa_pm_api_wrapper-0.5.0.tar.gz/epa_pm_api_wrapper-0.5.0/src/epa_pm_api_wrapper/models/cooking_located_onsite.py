from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class CookingLocatedOnsite(UseYesNoType):
    """
    Denotes if hot or cold food is prepared by cooking and assembling raw
    ingredients at the property location.
    """

    class Meta:
        name = "cookingLocatedOnsite"
