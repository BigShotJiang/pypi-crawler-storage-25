from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .length_units_type import LengthUnitsType
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class CeilingHeightUnitsType(UseAttributeBase):
    class Meta:
        name = "ceilingHeightUnitsType"

    value: None | Decimal = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": Decimal("1.0"),
        },
    )
    units: LengthUnitsType = field(
        metadata={
            "type": "Attribute",
        }
    )
