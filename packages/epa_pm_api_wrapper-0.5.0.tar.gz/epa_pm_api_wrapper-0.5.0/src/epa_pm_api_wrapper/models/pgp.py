from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class Pgp:
    """
    Power Generation Plant information.

    :ivar plant_code: The ORIS plant code.
    :ivar name: The name of PGP (power generation plant).
    :ivar selected: Whether the property is currently assigned to this
        PGP.
    :ivar e_grid_code: The code of the eGrid Subregion that the PGP
        belongs to.
    :ivar e_grid_name: The name of the eGrid Subregion that the PGP
        belongs to.
    """

    class Meta:
        name = "pgp"

    plant_code: None | int = field(
        default=None,
        metadata={
            "name": "plantCode",
            "type": "Attribute",
        },
    )
    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    selected: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    e_grid_code: None | str = field(
        default=None,
        metadata={
            "name": "eGridCode",
            "type": "Attribute",
        },
    )
    e_grid_name: None | str = field(
        default=None,
        metadata={
            "name": "eGridName",
            "type": "Attribute",
        },
    )
