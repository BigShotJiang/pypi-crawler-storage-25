from __future__ import annotations

from dataclasses import dataclass, field

from .floor_area_type_base import FloorAreaTypeBase


@dataclass(kw_only=True)
class GrossFloorAreaType(FloorAreaTypeBase):
    """
    The total gross floor area of all buildings at the property, measured
    at the exterior boundary of the enclosing walls, including all areas
    within the building (common, tenant, maintenance, etc).
    """

    class Meta:
        name = "grossFloorAreaType"

    value: int = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
