from __future__ import annotations

from dataclasses import dataclass

from .percent_office_cooled_type import PercentOfficeCooledType


@dataclass(kw_only=True)
class PercentOfficeCooled(PercentOfficeCooledType):
    class Meta:
        name = "percentOfficeCooled"
