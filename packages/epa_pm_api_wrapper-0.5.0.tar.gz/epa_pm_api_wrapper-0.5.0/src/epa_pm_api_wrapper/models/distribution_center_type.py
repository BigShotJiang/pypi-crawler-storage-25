from __future__ import annotations

from dataclasses import dataclass, field

from .distribution_center_type_use_details import (
    DistributionCenterTypeUseDetails,
)
from .log_type import LogType


@dataclass(kw_only=True)
class DistributionCenterType:
    class Meta:
        name = "distributionCenterType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: DistributionCenterTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
