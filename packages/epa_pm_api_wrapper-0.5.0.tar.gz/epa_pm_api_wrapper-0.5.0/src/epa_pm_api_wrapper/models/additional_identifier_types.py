from __future__ import annotations

from dataclasses import dataclass, field

from .additional_identifier_type import AdditionalIdentifierType
from .links_type import LinksType


@dataclass(kw_only=True)
class AdditionalIdentifierTypes:
    class Meta:
        name = "additionalIdentifierTypes"

    additional_identifier_type: list[AdditionalIdentifierType] = field(
        default_factory=list,
        metadata={
            "name": "additionalIdentifierType",
            "type": "Element",
        },
    )
    links: None | LinksType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
