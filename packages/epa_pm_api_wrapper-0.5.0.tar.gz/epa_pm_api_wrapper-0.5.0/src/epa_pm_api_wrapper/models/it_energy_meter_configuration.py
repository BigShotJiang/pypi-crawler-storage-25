from __future__ import annotations

from dataclasses import dataclass

from .it_energy_configuration_type import ItEnergyConfigurationType


@dataclass(kw_only=True)
class ItEnergyMeterConfiguration(ItEnergyConfigurationType):
    """
    The IT Energy Configuration/location of IT Energy meters at a data
    center.
    """

    class Meta:
        name = "itEnergyMeterConfiguration"
