from __future__ import annotations

from enum import Enum


class CustomFieldWhenToPrompt(Enum):
    """
    :cvar ONCE: Just ask once and apply it to every transaction
    :cvar PROPERTY: Ask for every property
    :cvar METER: Ask for every meter
    """

    ONCE = "Once"
    PROPERTY = "Property"
    METER = "Meter"
