from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherEntertainmentPublicAssembly(OtherType):
    """
    Buildings whose primary use is for entertainment or public gatherings
    and that do not meet the definition of any other property use defined
    in Portfolio Manager.
    """

    class Meta:
        name = "otherEntertainmentPublicAssembly"
