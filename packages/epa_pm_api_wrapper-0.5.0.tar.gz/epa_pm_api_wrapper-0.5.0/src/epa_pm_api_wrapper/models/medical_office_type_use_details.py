from __future__ import annotations

from dataclasses import dataclass, field

from .number_of_computers import NumberOfComputers
from .number_of_mri_machines import NumberOfMriMachines
from .number_of_surgical_operating_beds import NumberOfSurgicalOperatingBeds
from .number_of_workers import NumberOfWorkers
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .surgery_center_floor_area import SurgeryCenterFloorArea
from .total_gross_floor_area import TotalGrossFloorArea
from .weekly_operating_hours import WeeklyOperatingHours


@dataclass(kw_only=True)
class MedicalOfficeTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    weekly_operating_hours: None | WeeklyOperatingHours = field(
        default=None,
        metadata={
            "name": "weeklyOperatingHours",
            "type": "Element",
        },
    )
    number_of_surgical_operating_beds: None | NumberOfSurgicalOperatingBeds = field(
        default=None,
        metadata={
            "name": "numberOfSurgicalOperatingBeds",
            "type": "Element",
        },
    )
    surgery_center_floor_area: None | SurgeryCenterFloorArea = field(
        default=None,
        metadata={
            "name": "surgeryCenterFloorArea",
            "type": "Element",
        },
    )
    number_of_mri_machines: None | NumberOfMriMachines = field(
        default=None,
        metadata={
            "name": "numberOfMriMachines",
            "type": "Element",
        },
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
