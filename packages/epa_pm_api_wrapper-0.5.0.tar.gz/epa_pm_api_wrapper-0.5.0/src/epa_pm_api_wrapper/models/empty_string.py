from __future__ import annotations

from enum import Enum


class EmptyString(Enum):
    VALUE = ""
