from __future__ import annotations

from dataclasses import dataclass, field

from .gross_floor_area_type import GrossFloorAreaType


@dataclass(kw_only=True)
class HeyTypePropertyInfo:
    class Meta:
        global_type = False

    postal_code: str = field(
        metadata={
            "name": "postalCode",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 5,
        }
    )
    number_of_occupants: int = field(
        metadata={
            "name": "numberOfOccupants",
            "type": "Element",
            "namespace": "",
        }
    )
    gross_floor_area: GrossFloorAreaType = field(
        metadata={
            "name": "grossFloorArea",
            "type": "Element",
            "namespace": "",
        }
    )
