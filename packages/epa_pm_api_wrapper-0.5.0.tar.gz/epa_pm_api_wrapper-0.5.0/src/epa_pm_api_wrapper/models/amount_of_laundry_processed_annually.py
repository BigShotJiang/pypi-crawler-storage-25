from __future__ import annotations

from dataclasses import dataclass

from .amount_of_laundry_processed_annually_type import (
    AmountOfLaundryProcessedAnnuallyType,
)


@dataclass(kw_only=True)
class AmountOfLaundryProcessedAnnually(AmountOfLaundryProcessedAnnuallyType):
    """
    Quantity of laundry processed at the property.
    """

    class Meta:
        name = "amountOfLaundryProcessedAnnually"
