from __future__ import annotations

from dataclasses import dataclass, field

from .owned_by_type_value import OwnedByTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class OwnedByType(UseAttributeBase):
    class Meta:
        name = "ownedByType"

    value: None | OwnedByTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
