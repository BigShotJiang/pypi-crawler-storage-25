from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class PoliceStation(OtherType):
    """
    Buildings used for federal, state, or local police forces and their
    associated office space.
    """

    class Meta:
        name = "policeStation"
