from __future__ import annotations

from dataclasses import dataclass, field

from .custom_field_list import CustomFieldList
from .log_type import LogType
from .property_type import PropertyType
from .share_level_type import ShareLevelType


@dataclass(kw_only=True)
class PendingPropertiesType:
    """
    :ivar property_id: The ID number of the property.
    :ivar custom_field_list:
    :ivar access_level: The level of access for the property share
        request:  Read or Read Write.
    :ivar account_id: The id to the account requesting the property
        share.
    :ivar username: The username of the Portfolio Manager Account
        requesting the property share.
    :ivar property_info:
    :ivar share_audit:
    """

    class Meta:
        name = "pendingPropertiesType"

    property_id: int = field(
        metadata={
            "name": "propertyId",
            "type": "Element",
            "namespace": "",
        }
    )
    custom_field_list: None | CustomFieldList = field(
        default=None,
        metadata={
            "name": "customFieldList",
            "type": "Element",
        },
    )
    access_level: ShareLevelType = field(
        metadata={
            "name": "accessLevel",
            "type": "Element",
            "namespace": "",
        }
    )
    account_id: int = field(
        metadata={
            "name": "accountId",
            "type": "Element",
            "namespace": "",
        }
    )
    username: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    property_info: PropertyType = field(
        metadata={
            "name": "propertyInfo",
            "type": "Element",
            "namespace": "",
        }
    )
    share_audit: None | LogType = field(
        default=None,
        metadata={
            "name": "shareAudit",
            "type": "Element",
            "namespace": "",
        },
    )
