from __future__ import annotations

from dataclasses import dataclass

from .onsite_renewable_detail_type import OnsiteRenewableDetailType


@dataclass(kw_only=True)
class OnsiteRenewableDetail(OnsiteRenewableDetailType):
    class Meta:
        name = "onsiteRenewableDetail"
