from __future__ import annotations

from dataclasses import dataclass, field

from .additional_identifier import AdditionalIdentifier
from .links_type import LinksType


@dataclass(kw_only=True)
class AdditionalIdentifiers:
    class Meta:
        name = "additionalIdentifiers"

    additional_identifier: list[AdditionalIdentifier] = field(
        default_factory=list,
        metadata={
            "name": "additionalIdentifier",
            "type": "Element",
        },
    )
    links: None | LinksType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
