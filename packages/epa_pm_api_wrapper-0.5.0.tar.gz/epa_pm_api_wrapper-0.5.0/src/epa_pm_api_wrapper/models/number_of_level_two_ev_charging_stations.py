from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfLevelTwoEvChargingStations(UseDecimalType):
    """
    Number of Level Two electric vehicle charging stations.
    """

    class Meta:
        name = "numberOfLevelTwoEvChargingStations"
