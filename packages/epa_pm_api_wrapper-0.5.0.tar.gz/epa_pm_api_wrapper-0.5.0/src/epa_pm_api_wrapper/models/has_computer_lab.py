from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class HasComputerLab(UseYesNoType):
    """
    Whether there is a Computer Lab.
    """

    class Meta:
        name = "hasComputerLab"
