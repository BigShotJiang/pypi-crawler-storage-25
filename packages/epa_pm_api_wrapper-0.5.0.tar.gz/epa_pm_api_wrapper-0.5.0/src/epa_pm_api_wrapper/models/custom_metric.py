from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class CustomMetric:
    """
    :ivar name:
    :ivar numerator_metric_id:
    :ivar denominator_detail_type_id:
    :ivar id: The unique identifier of the custom metric.
    :ivar unit_of_measure:
    """

    class Meta:
        name = "customMetric"

    name: None | str = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    numerator_metric_id: int = field(
        metadata={
            "name": "numeratorMetricId",
            "type": "Element",
        }
    )
    denominator_detail_type_id: int = field(
        metadata={
            "name": "denominatorDetailTypeId",
            "type": "Element",
        }
    )
    id: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    unit_of_measure: None | str = field(
        default=None,
        metadata={
            "name": "unitOfMeasure",
            "type": "Attribute",
        },
    )
