from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlDateTime

from .data_request_locations import DataRequestLocations
from .data_request_requester_details import DataRequestRequesterDetails
from .data_request_status_type import DataRequestStatusType
from .timeframe_type import TimeframeType


@dataclass(kw_only=True)
class DataRequest:
    """
    :ivar name: The name of the data request.
    :ivar requester_details: The main point of contact for this data
        request.
    :ivar instructions: The details instructions of the data request.
    :ivar timeframe: The timeframe of the data request.
    :ivar locations: The locations of the data request.
    :ivar data_request_status: The status (OPEN or CLOSED) of the data
        request.
    :ivar data_request_accepted_by: The user who accepted the data
        request.
    :ivar data_request_accepted_date: The date when the data request was
        accepted.
    :ivar id: The unique identifier of the data request.
    """

    class Meta:
        name = "dataRequest"

    name: str = field(
        metadata={
            "type": "Element",
        }
    )
    requester_details: DataRequestRequesterDetails = field(
        metadata={
            "name": "requesterDetails",
            "type": "Element",
        }
    )
    instructions: None | str = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    timeframe: None | TimeframeType = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    locations: None | DataRequestLocations = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    data_request_status: DataRequestStatusType = field(
        metadata={
            "name": "dataRequestStatus",
            "type": "Element",
        }
    )
    data_request_accepted_by: None | str = field(
        default=None,
        metadata={
            "name": "dataRequestAcceptedBy",
            "type": "Element",
        },
    )
    data_request_accepted_date: None | XmlDateTime = field(
        default=None,
        metadata={
            "name": "dataRequestAcceptedDate",
            "type": "Element",
        },
    )
    id: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
