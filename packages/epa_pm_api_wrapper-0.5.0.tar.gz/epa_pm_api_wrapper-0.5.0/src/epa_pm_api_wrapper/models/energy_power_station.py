from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class EnergyPowerStation(OtherType):
    """
    Buildings containing machinery and/or associated equipment for
    generating electricity or district heat (steam, hot water, or chilled
    water) from a raw fuel, including fossil fuel power plants, traditional
    district heat power plants, combined heat and power plants, nuclear
    reactors, hydroelectric dams, or facilities associated with a solar or
    wind farm.
    """

    class Meta:
        name = "energyPowerStation"
