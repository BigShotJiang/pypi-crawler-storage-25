from __future__ import annotations

from enum import Enum


class RatedCapacityUomType(Enum):
    K_W = "kW"
    MW = "MW"
