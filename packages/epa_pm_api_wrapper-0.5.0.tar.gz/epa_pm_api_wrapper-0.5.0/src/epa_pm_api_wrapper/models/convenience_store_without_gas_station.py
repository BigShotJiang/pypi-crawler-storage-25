from __future__ import annotations

from dataclasses import dataclass

from .convenience_store_without_gas_station_type import (
    ConvenienceStoreWithoutGasStationType,
)


@dataclass(kw_only=True)
class ConvenienceStoreWithoutGasStation(ConvenienceStoreWithoutGasStationType):
    """
    Buildings used for the sale of a limited range of items such as
    groceries, toiletries, newspapers, soft drinks, tobacco products, and
    other everyday items, which are not co-located with a gas station.
    """

    class Meta:
        name = "convenienceStoreWithoutGasStation"
