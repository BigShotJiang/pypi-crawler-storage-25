from __future__ import annotations

from dataclasses import dataclass

from .custom_use_details_type import CustomUseDetailsType


@dataclass(kw_only=True)
class CustomUseDetail2(CustomUseDetailsType):
    """
    Custom Use Detail #2.
    """

    class Meta:
        name = "customUseDetail2"
