from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlDate

from .log_type import LogType
from .onsite_usage_detail_type import OnsiteUsageDetailType


@dataclass(kw_only=True)
class OnsiteRenewableDetailType:
    """
    :ivar id: The id of the onsite renewable detail.
    :ivar current_as_of: The time period of the onsite renewable detail.
    :ivar energy_used_onsite: The energy used onsite REC ownership
        details.
    :ivar energy_exported_to_grid: The energy exported to grid REC
        ownership details.
    :ivar audit:
    """

    class Meta:
        name = "onsiteRenewableDetailType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    current_as_of: XmlDate = field(
        metadata={
            "name": "currentAsOf",
            "type": "Element",
            "namespace": "",
        }
    )
    energy_used_onsite: OnsiteUsageDetailType = field(
        metadata={
            "name": "energyUsedOnsite",
            "type": "Element",
            "namespace": "",
        }
    )
    energy_exported_to_grid: OnsiteUsageDetailType = field(
        metadata={
            "name": "energyExportedToGrid",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
