from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfIndoorIceRinks(UseIntegerType):
    """
    Number of indoor ice rinks used for indoor hockey, ringette, public or
    figure skating.

    This does not include curling sheets.
    """

    class Meta:
        name = "numberOfIndoorIceRinks"
