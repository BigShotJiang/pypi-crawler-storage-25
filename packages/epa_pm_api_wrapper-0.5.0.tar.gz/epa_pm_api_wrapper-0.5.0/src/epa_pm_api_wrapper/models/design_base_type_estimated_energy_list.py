from __future__ import annotations

from dataclasses import dataclass, field

from .estimated_energy_list_type import EstimatedEnergyListType


@dataclass(kw_only=True)
class DesignBaseTypeEstimatedEnergyList:
    class Meta:
        global_type = False

    entries: EstimatedEnergyListType = field(
        metadata={
            "type": "Element",
        }
    )
