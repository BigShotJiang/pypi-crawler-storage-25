from __future__ import annotations

from dataclasses import dataclass

from .percent_cooled_type import PercentCooledType


@dataclass(kw_only=True)
class PercentCooled(PercentCooledType):
    """
    The percent of the property that can be cooled by mechanical cooling
    equipment.
    """

    class Meta:
        name = "percentCooled"
