from __future__ import annotations

from dataclasses import dataclass, field

from .gross_floor_area_used_for_food_preparation import (
    GrossFloorAreaUsedForFoodPreparation,
)
from .has_laboratory import HasLaboratory
from .is_tertiary_care import IsTertiaryCare
from .licensed_bed_capacity import LicensedBedCapacity
from .maximum_number_of_floors import MaximumNumberOfFloors
from .number_of_fteworkers import NumberOfFteworkers
from .number_of_mri_machines import NumberOfMriMachines
from .number_of_staffed_beds import NumberOfStaffedBeds
from .number_of_sterilization_units import NumberOfSterilizationUnits
from .number_of_workers import NumberOfWorkers
from .on_site_laundry_facility import OnSiteLaundryFacility
from .owned_by import OwnedBy
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .total_gross_floor_area import TotalGrossFloorArea


@dataclass(kw_only=True)
class HospitalTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    gross_floor_area_used_for_food_preparation: None | GrossFloorAreaUsedForFoodPreparation = field(
        default=None,
        metadata={
            "name": "grossFloorAreaUsedForFoodPreparation",
            "type": "Element",
        },
    )
    licensed_bed_capacity: None | LicensedBedCapacity = field(
        default=None,
        metadata={
            "name": "licensedBedCapacity",
            "type": "Element",
        },
    )
    number_of_staffed_beds: None | NumberOfStaffedBeds = field(
        default=None,
        metadata={
            "name": "numberOfStaffedBeds",
            "type": "Element",
        },
    )
    number_of_fteworkers: None | NumberOfFteworkers = field(
        default=None,
        metadata={
            "name": "numberOfFTEWorkers",
            "type": "Element",
        },
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    number_of_mri_machines: None | NumberOfMriMachines = field(
        default=None,
        metadata={
            "name": "numberOfMriMachines",
            "type": "Element",
        },
    )
    number_of_sterilization_units: None | NumberOfSterilizationUnits = field(
        default=None,
        metadata={
            "name": "numberOfSterilizationUnits",
            "type": "Element",
        },
    )
    on_site_laundry_facility: None | OnSiteLaundryFacility = field(
        default=None,
        metadata={
            "name": "onSiteLaundryFacility",
            "type": "Element",
        },
    )
    has_laboratory: None | HasLaboratory = field(
        default=None,
        metadata={
            "name": "hasLaboratory",
            "type": "Element",
        },
    )
    is_tertiary_care: None | IsTertiaryCare = field(
        default=None,
        metadata={
            "name": "isTertiaryCare",
            "type": "Element",
        },
    )
    maximum_number_of_floors: None | MaximumNumberOfFloors = field(
        default=None,
        metadata={
            "name": "maximumNumberOfFloors",
            "type": "Element",
        },
    )
    owned_by: None | OwnedBy = field(
        default=None,
        metadata={
            "name": "ownedBy",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
