from __future__ import annotations

from enum import Enum


class PercentCooledTypeValue(Enum):
    VALUE_0 = "0"
    VALUE_10 = "10"
    VALUE_20 = "20"
    VALUE_30 = "30"
    VALUE_40 = "40"
    VALUE_50 = "50"
    VALUE_60 = "60"
    VALUE_70 = "70"
    VALUE_80 = "80"
    VALUE_90 = "90"
    VALUE_100 = "100"
