from __future__ import annotations

from dataclasses import dataclass

from .hey_type import HeyType


@dataclass(kw_only=True)
class Hey(HeyType):
    class Meta:
        name = "hey"
