from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class FixedFilmTrickleFiltrationProcess(UseYesNoType):
    """
    Whether there is a Fixed Film Trickle Filtration Process.
    """

    class Meta:
        name = "fixedFilmTrickleFiltrationProcess"
