from __future__ import annotations

from dataclasses import dataclass, field

from .k12_school_type_use_details import K12SchoolTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class K12SchoolType:
    class Meta:
        name = "k12SchoolType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: K12SchoolTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
