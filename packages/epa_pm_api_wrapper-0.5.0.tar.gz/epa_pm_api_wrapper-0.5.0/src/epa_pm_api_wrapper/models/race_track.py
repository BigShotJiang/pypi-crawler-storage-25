from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class RaceTrack(OtherType):
    """
    Buildings used primarily to hold racing events such as vehicle races,
    track/field races, horse races, and/or dog-races.
    """

    class Meta:
        name = "raceTrack"
