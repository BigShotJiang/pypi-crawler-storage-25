from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlDate

from .report_error_missing_metrics_property_missing_metric_metric import (
    ReportErrorMissingMetricsPropertyMissingMetricMetric,
)


@dataclass(kw_only=True)
class ReportErrorMissingMetricsPropertyMissingMetric:
    class Meta:
        global_type = False

    year_ending_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "yearEndingDate",
            "type": "Element",
        },
    )
    metric: list[ReportErrorMissingMetricsPropertyMissingMetricMetric] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    property_id: None | int = field(
        default=None,
        metadata={
            "name": "propertyId",
            "type": "Attribute",
        },
    )
    property_name: None | str = field(
        default=None,
        metadata={
            "name": "propertyName",
            "type": "Attribute",
        },
    )
