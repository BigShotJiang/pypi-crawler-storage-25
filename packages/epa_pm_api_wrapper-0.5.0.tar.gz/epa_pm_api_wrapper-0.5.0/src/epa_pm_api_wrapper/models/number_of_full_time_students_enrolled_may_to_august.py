from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfFullTimeStudentsEnrolledMayToAugust(UseDecimalType):
    """
    Number of students enrolled at the campus in the indicated semester
    that are considered full time status by the school.
    """

    class Meta:
        name = "numberOfFullTimeStudentsEnrolledMayToAugust"
