from __future__ import annotations

from dataclasses import dataclass

from .account_type import AccountType


@dataclass(kw_only=True)
class Account(AccountType):
    """
    Contains information for a Portfolio Manager account.
    """

    class Meta:
        name = "account"
