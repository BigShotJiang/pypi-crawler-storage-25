from __future__ import annotations

from dataclasses import dataclass

from .optional_floor_area_type import OptionalFloorAreaType


@dataclass(kw_only=True)
class GrossFloorAreaUsedForFoodPreparation(OptionalFloorAreaType):
    """
    The Gross Floor Area Used for Food Preparation is the total size of all
    large/commercial kitchen areas used for the storage and preparation of
    food.

    This will be a subset of Gross Floor Area for the property.
    """

    class Meta:
        name = "grossFloorAreaUsedForFoodPreparation"
