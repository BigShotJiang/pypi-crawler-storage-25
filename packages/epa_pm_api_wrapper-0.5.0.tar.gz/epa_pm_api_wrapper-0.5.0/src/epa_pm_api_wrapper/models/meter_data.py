from __future__ import annotations

from dataclasses import dataclass

from .meter_data_type import MeterDataType


@dataclass(kw_only=True)
class MeterData(MeterDataType):
    class Meta:
        name = "meterData"
