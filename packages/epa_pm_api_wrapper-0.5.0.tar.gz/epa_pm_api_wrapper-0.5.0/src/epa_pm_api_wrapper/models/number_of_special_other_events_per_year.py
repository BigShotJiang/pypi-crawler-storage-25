from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfSpecialOtherEventsPerYear(UseIntegerType):
    """
    Number of special/other events per year at a stadium/arena (i.e. events
    that are neither concerts/shows nor athletic events).
    """

    class Meta:
        name = "numberOfSpecialOtherEventsPerYear"
