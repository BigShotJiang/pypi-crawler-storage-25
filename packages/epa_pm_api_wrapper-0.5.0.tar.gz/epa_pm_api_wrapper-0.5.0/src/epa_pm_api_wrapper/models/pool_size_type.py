from __future__ import annotations

from dataclasses import dataclass, field

from .pool_size_type_value import PoolSizeTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class PoolSizeType(UseAttributeBase):
    class Meta:
        name = "poolSizeType"

    value: None | PoolSizeTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
