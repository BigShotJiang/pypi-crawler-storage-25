from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfWorkers(UseDecimalType):
    """
    The total number of workers during the primary (largest shift) - this
    is only a total number of people in the building at a single time.
    """

    class Meta:
        name = "numberOfWorkers"
