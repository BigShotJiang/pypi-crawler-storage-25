from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from xsdata.models.datatype import XmlDate

from .demand_tracking_type import DemandTrackingType
from .empty_string import EmptyString
from .log_type import LogType


@dataclass(kw_only=True)
class MeterConsumptionType:
    """
    A service type used for representing a meter consumption entry.

    :ivar id: The id of the meter consumption entry.
    :ivar start_date: The first date of the meter consumption reading.
    :ivar end_date: The last date of the meter consumption reading.
    :ivar usage: The quantity of the meter consumption.
    :ivar cost: The cost of meter's consumption.
    :ivar energy_exported_off_site: The amount of energy exported off
        site from an on-site solar or on-site wind installation.
    :ivar percent_renewable_natural_gas: The percentage that is
        renewable Natural Gas.
    :ivar demand_tracking:
    :ivar audit:
    :ivar estimated_value: Whether the meter consumption is an estimated
        value.
    """

    class Meta:
        name = "meterConsumptionType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    start_date: XmlDate = field(
        metadata={
            "name": "startDate",
            "type": "Element",
            "namespace": "",
        }
    )
    end_date: XmlDate = field(
        metadata={
            "name": "endDate",
            "type": "Element",
            "namespace": "",
        }
    )
    usage: Decimal = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    cost: None | EmptyString | Decimal = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    energy_exported_off_site: None | Decimal = field(
        default=None,
        metadata={
            "name": "energyExportedOffSite",
            "type": "Element",
            "namespace": "",
        },
    )
    percent_renewable_natural_gas: None | Decimal = field(
        default=None,
        metadata={
            "name": "percentRenewableNaturalGas",
            "type": "Element",
            "namespace": "",
            "min_inclusive": Decimal("0"),
            "max_inclusive": Decimal("100"),
            "fraction_digits": 2,
        },
    )
    demand_tracking: None | DemandTrackingType = field(
        default=None,
        metadata={
            "name": "demandTracking",
            "type": "Element",
            "namespace": "",
        },
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    estimated_value: None | bool = field(
        default=None,
        metadata={
            "name": "estimatedValue",
            "type": "Attribute",
        },
    )
