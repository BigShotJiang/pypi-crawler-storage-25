from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .energy_uom_type import EnergyUomType


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchaseTypeCost:
    """
    :ivar value: The value of the cost.
    :ivar uom: The unit of measure of the cost.
    """

    class Meta:
        global_type = False

    value: Decimal = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_exclusive": Decimal("0"),
            "fraction_digits": 2,
        }
    )
    uom: EnergyUomType = field(
        metadata={
            "type": "Attribute",
        }
    )
