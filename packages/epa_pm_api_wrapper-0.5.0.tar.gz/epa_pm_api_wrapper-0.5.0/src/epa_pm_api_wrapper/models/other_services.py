from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherServices(OtherType):
    """
    Buildings in which primarily services are offered, but which does not
    fit into the Personal Services or Repair Services property types.
    """

    class Meta:
        name = "otherServices"
