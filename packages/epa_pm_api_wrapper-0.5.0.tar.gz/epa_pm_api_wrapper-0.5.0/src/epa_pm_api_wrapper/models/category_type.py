from __future__ import annotations

from enum import Enum


class CategoryType(Enum):
    """
    List of categories or stages for the project.
    """

    RECOMMISSIONING_STAGE_1 = "Recommissioning (Stage 1)"
    LIGHTING_STAGE_2 = "Lighting (Stage 2)"
    LOAD_REDUCTIONS_STAGE_3 = "Load Reductions (Stage 3)"
    FAN_SYSTEMS_STAGE_4 = "Fan Systems (Stage 4)"
    HEATING_COOLING_PLANT_STAGE_5 = "Heating & Cooling Plant (Stage 5)"
    BEHAVIORAL_OUTREACH = "Behavioral/Outreach"
    OTHER_TECHNOLOGIES_STRATEGIES = "Other Technologies/Strategies"
