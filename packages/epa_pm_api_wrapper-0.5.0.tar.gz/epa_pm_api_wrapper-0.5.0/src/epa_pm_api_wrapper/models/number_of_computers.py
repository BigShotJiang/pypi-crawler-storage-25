from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfComputers(UseDecimalType):
    """
    Number of computers and servers at the property.
    """

    class Meta:
        name = "numberOfComputers"
