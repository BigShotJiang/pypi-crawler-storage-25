from __future__ import annotations

from dataclasses import dataclass, field

from .agency_type_country import AgencyTypeCountry


@dataclass(kw_only=True)
class AgencyType:
    """
    :ivar id: The ID created within Portfolio Manager that uniquely
        defines the federal agency.
    :ivar code: The federal agency code or abbreviation.
    :ivar name: The federal agency name.
    :ivar country: The country which owns this agency.
    """

    id: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    code: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    country: None | AgencyTypeCountry = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
