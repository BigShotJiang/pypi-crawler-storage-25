from __future__ import annotations

from enum import Enum


class HighestAwardLevelTypeValue(Enum):
    DOCTORAL_DEGREE = "Doctoral Degree"
    MASTER_S_DEGREE = "Master's Degree"
    BACHELOR_S_DEGREE = "Bachelor's Degree"
    ASSOCIATE_S_DEGREE_OR_OTHER_2_3_YEAR_PROGRAM = "Associate's degree or other 2-3 year program"
    OTHER_PROGRAM_LESS_THAN_2_YEARS = "Other program less than 2 years"
