from __future__ import annotations

from dataclasses import dataclass, field

from .data_exchange_settings_supported_meter_types import (
    DataExchangeSettingsSupportedMeterTypes,
)
from .data_exchange_settings_terms_of_use import DataExchangeSettingsTermsOfUse


@dataclass(kw_only=True)
class DataExchangeSettings:
    """
    :ivar supported_meter_types: The list of meter types that you
        support.
    :ivar terms_of_use:
    """

    class Meta:
        name = "dataExchangeSettings"

    supported_meter_types: None | DataExchangeSettingsSupportedMeterTypes = field(
        default=None,
        metadata={
            "name": "supportedMeterTypes",
            "type": "Element",
            "namespace": "",
        },
    )
    terms_of_use: None | DataExchangeSettingsTermsOfUse = field(
        default=None,
        metadata={
            "name": "termsOfUse",
            "type": "Element",
            "namespace": "",
        },
    )
