from __future__ import annotations

from dataclasses import dataclass, field

from .links_type import LinksType
from .onsite_renewable_detail import OnsiteRenewableDetail


@dataclass(kw_only=True)
class OnsiteRenewableDetails:
    class Meta:
        name = "onsiteRenewableDetails"

    onsite_renewable_detail: list[OnsiteRenewableDetail] = field(
        default_factory=list,
        metadata={
            "name": "onsiteRenewableDetail",
            "type": "Element",
            "max_occurs": 1000,
        },
    )
    links: None | LinksType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
