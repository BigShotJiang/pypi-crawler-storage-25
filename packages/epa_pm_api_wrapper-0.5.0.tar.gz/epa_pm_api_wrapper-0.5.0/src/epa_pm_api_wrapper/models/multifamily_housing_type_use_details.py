from __future__ import annotations

from dataclasses import dataclass, field

from .common_entrance import CommonEntrance
from .government_subsidized_housing import GovernmentSubsidizedHousing
from .number_of_bedrooms import NumberOfBedrooms
from .number_of_laundry_hookups_in_all_units import (
    NumberOfLaundryHookupsInAllUnits,
)
from .number_of_laundry_hookups_in_common_area import (
    NumberOfLaundryHookupsInCommonArea,
)
from .number_of_residential_living_units import NumberOfResidentialLivingUnits
from .number_of_residential_living_units_high_rise_setting import (
    NumberOfResidentialLivingUnitsHighRiseSetting,
)
from .number_of_residential_living_units_low_rise_setting import (
    NumberOfResidentialLivingUnitsLowRiseSetting,
)
from .number_of_residential_living_units_mid_rise_setting import (
    NumberOfResidentialLivingUnitsMidRiseSetting,
)
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .resident_population import ResidentPopulation
from .total_gross_floor_area import TotalGrossFloorArea


@dataclass(kw_only=True)
class MultifamilyHousingTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    number_of_residential_living_units: None | NumberOfResidentialLivingUnits = field(
        default=None,
        metadata={
            "name": "numberOfResidentialLivingUnits",
            "type": "Element",
        },
    )
    number_of_bedrooms: None | NumberOfBedrooms = field(
        default=None,
        metadata={
            "name": "numberOfBedrooms",
            "type": "Element",
        },
    )
    number_of_residential_living_units_mid_rise_setting: None | NumberOfResidentialLivingUnitsMidRiseSetting = field(
        default=None,
        metadata={
            "name": "numberOfResidentialLivingUnitsMidRiseSetting",
            "type": "Element",
        },
    )
    number_of_laundry_hookups_in_all_units: None | NumberOfLaundryHookupsInAllUnits = field(
        default=None,
        metadata={
            "name": "numberOfLaundryHookupsInAllUnits",
            "type": "Element",
        },
    )
    number_of_laundry_hookups_in_common_area: None | NumberOfLaundryHookupsInCommonArea = field(
        default=None,
        metadata={
            "name": "numberOfLaundryHookupsInCommonArea",
            "type": "Element",
        },
    )
    number_of_residential_living_units_low_rise_setting: None | NumberOfResidentialLivingUnitsLowRiseSetting = field(
        default=None,
        metadata={
            "name": "numberOfResidentialLivingUnitsLowRiseSetting",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    number_of_residential_living_units_high_rise_setting: None | NumberOfResidentialLivingUnitsHighRiseSetting = field(
        default=None,
        metadata={
            "name": "numberOfResidentialLivingUnitsHighRiseSetting",
            "type": "Element",
        },
    )
    resident_population: None | ResidentPopulation = field(
        default=None,
        metadata={
            "name": "residentPopulation",
            "type": "Element",
        },
    )
    government_subsidized_housing: None | GovernmentSubsidizedHousing = field(
        default=None,
        metadata={
            "name": "governmentSubsidizedHousing",
            "type": "Element",
        },
    )
    common_entrance: None | CommonEntrance = field(
        default=None,
        metadata={
            "name": "commonEntrance",
            "type": "Element",
        },
    )
