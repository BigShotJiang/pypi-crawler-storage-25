from __future__ import annotations

from dataclasses import dataclass, field

from .estimated_energy_type import EstimatedEnergyType


@dataclass(kw_only=True)
class EstimatedEnergyListType:
    class Meta:
        name = "estimatedEnergyListType"

    design_entry: list[EstimatedEnergyType] = field(
        default_factory=list,
        metadata={
            "name": "designEntry",
            "type": "Element",
        },
    )
