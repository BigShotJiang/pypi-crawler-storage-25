from __future__ import annotations

from dataclasses import dataclass

from .fire_station_type import FireStationType


@dataclass(kw_only=True)
class FireStation(FireStationType):
    """
    Buildings used to provide emergency response services associated with
    fires.
    """

    class Meta:
        name = "fireStation"
