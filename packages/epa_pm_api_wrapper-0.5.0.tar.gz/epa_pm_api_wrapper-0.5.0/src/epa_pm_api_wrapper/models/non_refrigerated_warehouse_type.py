from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .non_refrigerated_warehouse_type_use_details import (
    NonRefrigeratedWarehouseTypeUseDetails,
)


@dataclass(kw_only=True)
class NonRefrigeratedWarehouseType:
    class Meta:
        name = "nonRefrigeratedWarehouseType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: NonRefrigeratedWarehouseTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
