from __future__ import annotations

from dataclasses import dataclass

from .preschool_daycare_type import PreschoolDaycareType


@dataclass(kw_only=True)
class PreschoolDaycare(PreschoolDaycareType):
    """
    Buildings used for educational programs or daytime
    supervision/recreation for young children before they attend
    Kindergarten.
    """

    class Meta:
        name = "preschoolDaycare"
