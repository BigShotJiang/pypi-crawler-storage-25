from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .medical_office_type_use_details import MedicalOfficeTypeUseDetails


@dataclass(kw_only=True)
class MedicalOfficeType:
    class Meta:
        name = "medicalOfficeType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: MedicalOfficeTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
