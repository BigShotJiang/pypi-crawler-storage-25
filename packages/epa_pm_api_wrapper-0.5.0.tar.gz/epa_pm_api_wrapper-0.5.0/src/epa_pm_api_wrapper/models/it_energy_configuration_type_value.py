from __future__ import annotations

from enum import Enum


class ItEnergyConfigurationTypeValue(Enum):
    UPS_SUPPORTS_ONLY_IT_EQUIPMENT = "UPS Supports Only IT Equipment"
    UPS_INCLUDE_NON_IT_LOAD_LESS_THAN_10 = "UPS Include Non IT Load Less Than 10%"
    UPS_INCLUDE_NON_IT_LOAD_GREATER_THAN_10_LOAD_SUBMETERED = "UPS Include Non-IT Load Greater Than 10% Load Submetered"
    UPS_INCLUDE_NON_IT_LOAD_GREATER_THAN_10_LOAD_NOT_SUBMETERED = (
        "UPS Include Non IT Load Greater Than 10% Load Not Submetered"
    )
    FACILITY_HAS_NO_UPS = "Facility Has No UPS"
    NO_IT_ENERGY_CONFIGURATION_SELECTED = "No IT Energy Configuration Selected"
