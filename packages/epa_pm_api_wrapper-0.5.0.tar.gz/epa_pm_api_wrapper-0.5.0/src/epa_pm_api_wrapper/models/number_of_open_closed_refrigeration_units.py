from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfOpenClosedRefrigerationUnits(UseDecimalType):
    """
    The Number of Open or Closed Refrigeration/Freezer Units is the count
    of open or closed cases that are used for the sale or storage of
    perishable goods.

    This includes display-type refrigerated open or closed cases and
    cabinets as well as display-type freezer units typically found on a
    sales floor. Each case or cabinet section, typically 4 to 12 feet in
    length, should be considered 1 unit. Include those cases located inside
    and immediately adjacent to the building. These units may be portable
    or permanent, and may have doors, plastic strips, or other flexible
    cover. This count should not include vending machines. If your property
    is in the design phase, use your best estimate for the intended
    conditions when the property is fully operational.
    """

    class Meta:
        name = "numberOfOpenClosedRefrigerationUnits"
