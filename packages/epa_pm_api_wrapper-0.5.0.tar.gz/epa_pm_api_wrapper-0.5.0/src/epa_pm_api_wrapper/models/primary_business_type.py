from __future__ import annotations

from enum import Enum


class PrimaryBusinessType(Enum):
    ARCHITECTURE_DESIGN_FIRM = "Architecture/Design Firm"
    BANKING_FINANCIAL = "Banking/Financial"
    COMMERCIAL_REAL_ESTATE = "Commercial Real Estate"
    CONGREGATION_FAITH_BASED_ORGANIZATION = "Congregation/Faith-Based Organization"
    DATA_CENTER = "Data Center"
    DRINKING_WATER_TREATMENT_DISTRIBUTION = "Drinking Water Treatment/Distribution"
    EDUCATION = "Education"
    ENERGY_EFFICIENCY_PROGRAM = "Energy Efficiency Program"
    ENTERTAINMENT_RECREATION = "Entertainment/Recreation"
    FOOD_SERVICE = "Food Service"
    GOVERNMENT_LOCAL_U_S = "Government: Local (U.S.)"
    GOVERNMENT_OUTSIDE_U_S = "Government: Outside U.S."
    GOVERNMENT_STATE_U_S = "Government: State (U.S.)"
    GOVERNMENT_FEDERAL_U_S = "Government: Federal (U.S.)"
    HEALTHCARE = "Healthcare"
    HOSPITALITY = "Hospitality"
    LEGAL_SERVICES = "Legal Services"
    MANUFACTURING_INDUSTRIAL = "Manufacturing/Industrial"
    MEDIA = "Media"
    MULTIFAMILY_HOUSING = "Multifamily Housing"
    RETAIL = "Retail"
    SENIOR_CARE = "Senior Care"
    SERVICE_AND_PRODUCT_PROVIDER_CONSULTANT = "Service and Product Provider/Consultant"
    TRANSPORTATION = "Transportation"
    UTILITY = "Utility"
    WASTEWATER_TREATMENT = "Wastewater Treatment"
    OTHER = "Other"
