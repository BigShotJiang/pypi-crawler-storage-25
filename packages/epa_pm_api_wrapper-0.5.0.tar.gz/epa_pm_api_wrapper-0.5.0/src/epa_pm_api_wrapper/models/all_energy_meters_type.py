from __future__ import annotations

from enum import Enum


class AllEnergyMetersType(Enum):
    ELECTRIC = "Electric"
    ELECTRIC_ON_SITE_SOLAR = "Electric on Site Solar"
    ELECTRIC_ON_SITE_WIND = "Electric on Site Wind"
    NATURAL_GAS = "Natural Gas"
    PROPANE = "Propane"
    DIESEL = "Diesel"
    DISTRICT_STEAM = "District Steam"
    DISTRICT_HOT_WATER = "District Hot Water"
    DISTRICT_CHILLED_WATER_ABSORPTION_CHILLER_USING_NATURAL_GAS = (
        "District Chilled Water - Absorption Chiller using Natural Gas"
    )
    DISTRICT_CHILLED_WATER_ELECTRIC_DRIVEN_CHILLER = "District Chilled Water - Electric-Driven Chiller"
    DISTRICT_CHILLED_WATER_ENGINE_DRIVEN_CHILLER_USING_NATURAL_GAS = (
        "District Chilled Water - Engine-Driven Chiller using Natural Gas"
    )
    DISTRICT_CHILLED_WATER_OTHER = "District Chilled Water - Other"
    FUEL_OIL_NO_1 = "Fuel Oil No 1"
    FUEL_OIL_NO_2 = "Fuel Oil No 2"
    FUEL_OIL_NO_4 = "Fuel Oil No 4"
    FUEL_OIL_NO_5_OR_6 = "Fuel Oil No 5 or 6"
    COAL_ANTHRACITE = "Coal Anthracite"
    COAL_BITUMINOUS = "Coal Bituminous"
    COKE = "Coke"
    WOOD = "Wood"
    KEROSENE = "Kerosene"
    OTHER_ENERGY = "Other (Energy)"
