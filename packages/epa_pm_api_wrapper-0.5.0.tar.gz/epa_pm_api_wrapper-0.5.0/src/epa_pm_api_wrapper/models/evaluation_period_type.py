from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlDate


@dataclass(kw_only=True)
class EvaluationPeriodType:
    """
    :ivar pre_implementation_date: The date the project is going to be
        or was implemented.
    :ivar post_implementation_date: The date the project is going to be
        or was implemented.
    """

    class Meta:
        name = "evaluationPeriodType"

    pre_implementation_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "preImplementationDate",
            "type": "Element",
            "namespace": "",
        },
    )
    post_implementation_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "postImplementationDate",
            "type": "Element",
            "namespace": "",
        },
    )
