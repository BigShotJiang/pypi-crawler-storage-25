from __future__ import annotations

from dataclasses import dataclass, field

from .community_center_and_social_meeting_hall_use_details import (
    CommunityCenterAndSocialMeetingHallUseDetails,
)
from .log_type import LogType


@dataclass(kw_only=True)
class CommunityCenterAndSocialMeetingHall:
    """
    Community Center and Social Meeting Hall refers to buildings primarily
    used for social interactions, recreational activities, learning, and
    community support services.

    This may include community group meetings, physical and fitness
    activities, seminars, and workshops.
    """

    class Meta:
        name = "communityCenterAndSocialMeetingHall"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: CommunityCenterAndSocialMeetingHallUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
