from __future__ import annotations

from enum import Enum


class CountryCode(Enum):
    """
    :cvar US: United States
    :cvar CA: Canada
    :cvar VALUE: Empty when designation type code are CEM, ASHRAE, OTHER
        and NPD.
    """

    US = "US"
    CA = "CA"
    VALUE = ""
