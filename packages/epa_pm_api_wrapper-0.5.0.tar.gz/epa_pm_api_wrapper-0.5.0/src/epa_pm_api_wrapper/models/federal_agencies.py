from __future__ import annotations

from dataclasses import dataclass, field

from .agency_type import AgencyType


@dataclass(kw_only=True)
class FederalAgencies:
    class Meta:
        name = "federalAgencies"

    agency: list[AgencyType] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
