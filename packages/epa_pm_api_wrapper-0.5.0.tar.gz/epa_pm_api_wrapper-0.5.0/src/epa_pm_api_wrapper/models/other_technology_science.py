from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherTechnologyScience(OtherType):
    """
    Buildings used for science and technology related services other than
    Laboratories and Data Centers.
    """

    class Meta:
        name = "otherTechnologyScience"
