from __future__ import annotations

from dataclasses import dataclass

from .gross_floor_area_type import GrossFloorAreaType


@dataclass(kw_only=True)
class PartiallyEnclosedFootage(GrossFloorAreaType):
    """
    Total area of all parking structures that are only partially enclosed
    (i.e. multi-level structures that only have partial walls).
    """

    class Meta:
        name = "partiallyEnclosedFootage"
