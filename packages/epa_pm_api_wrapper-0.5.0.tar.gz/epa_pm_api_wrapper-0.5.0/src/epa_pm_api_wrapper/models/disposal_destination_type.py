from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal


@dataclass(kw_only=True)
class DisposalDestinationType:
    """
    A service type used for representing a disposal destination entry.

    :ivar landfill_percentage: The percentage of the quantity that was
        disposed at a land fill.
    :ivar incineration_percentage: The percentage of the quantity that
        was disposed by incineration.
    :ivar waste_to_energy_percentage: The percentage of the quantity
        that was disposed at a waste to energy facility.
    :ivar unknown_dest_percentage: The percentage of the quantity
        disposed in another way or when the disposal method is unknown.
    """

    class Meta:
        name = "disposalDestinationType"

    landfill_percentage: None | Decimal = field(
        default=None,
        metadata={
            "name": "landfillPercentage",
            "type": "Element",
            "namespace": "",
            "min_inclusive": Decimal("0"),
        },
    )
    incineration_percentage: None | Decimal = field(
        default=None,
        metadata={
            "name": "incinerationPercentage",
            "type": "Element",
            "namespace": "",
            "min_inclusive": Decimal("0"),
        },
    )
    waste_to_energy_percentage: None | Decimal = field(
        default=None,
        metadata={
            "name": "wasteToEnergyPercentage",
            "type": "Element",
            "namespace": "",
            "min_inclusive": Decimal("0"),
        },
    )
    unknown_dest_percentage: None | Decimal = field(
        default=None,
        metadata={
            "name": "unknownDestPercentage",
            "type": "Element",
            "namespace": "",
            "min_inclusive": Decimal("0"),
        },
    )
