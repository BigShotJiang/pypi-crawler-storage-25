from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfCommercialWashingMachines(UseDecimalType):
    """
    Number of commercial-type washing machines. (This does not include
    residential or coin-operated machines).
    """

    class Meta:
        name = "numberOfCommercialWashingMachines"
