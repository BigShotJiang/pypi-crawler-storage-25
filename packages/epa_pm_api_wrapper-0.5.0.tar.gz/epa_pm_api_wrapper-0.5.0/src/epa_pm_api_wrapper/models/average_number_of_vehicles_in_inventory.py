from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class AverageNumberOfVehiclesInInventory(UseDecimalType):
    """
    The average number of vehicles in inventory, not including vehicles
    housed at off-site locations.
    """

    class Meta:
        name = "averageNumberOfVehiclesInInventory"
