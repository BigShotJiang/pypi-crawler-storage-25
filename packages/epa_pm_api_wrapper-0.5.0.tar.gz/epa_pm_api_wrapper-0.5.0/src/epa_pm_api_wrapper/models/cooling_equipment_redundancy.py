from __future__ import annotations

from dataclasses import dataclass

from .cooling_equipment_redundancy_type import CoolingEquipmentRedundancyType


@dataclass(kw_only=True)
class CoolingEquipmentRedundancy(CoolingEquipmentRedundancyType):
    """
    Level of redundancy for the cooling equipment in a Data Center.
    """

    class Meta:
        name = "coolingEquipmentRedundancy"
