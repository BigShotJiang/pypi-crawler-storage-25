from __future__ import annotations

from dataclasses import dataclass, field

from .indoor_arena_type_use_details import IndoorArenaTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class IndoorArenaType:
    class Meta:
        name = "indoorArenaType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: IndoorArenaTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
