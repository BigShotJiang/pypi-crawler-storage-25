from __future__ import annotations

from dataclasses import dataclass, field

from .account_info import AccountInfo
from .customer_language_preference import CustomerLanguagePreference


@dataclass(kw_only=True)
class Customer:
    """
    Contains information for a Portfolio Manager account.

    :ivar username: The username for your customer's account.
    :ivar include_test_properties_in_graphics: This indicates if the
        Test Property in the account is included in the graphs on My
        Portfolio page. If true then test property is included and if
        false then Test property is excluded.
    :ivar email_preference_canadian_account: Contact me with training
        opportunities, tool updates, program news and other information
        about the ENERGY STAR program.
    :ivar billboard_metric: Your saved billboard metric
    :ivar language_preference:
    :ivar account_info:
    """

    class Meta:
        name = "customer"

    username: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 60,
        },
    )
    include_test_properties_in_graphics: None | bool = field(
        default=None,
        metadata={
            "name": "includeTestPropertiesInGraphics",
            "type": "Element",
            "namespace": "",
        },
    )
    email_preference_canadian_account: None | bool = field(
        default=None,
        metadata={
            "name": "emailPreferenceCanadianAccount",
            "type": "Element",
            "namespace": "",
        },
    )
    billboard_metric: None | str = field(
        default=None,
        metadata={
            "name": "billboardMetric",
            "type": "Element",
            "namespace": "",
        },
    )
    language_preference: None | CustomerLanguagePreference = field(
        default=None,
        metadata={
            "name": "languagePreference",
            "type": "Element",
            "namespace": "",
        },
    )
    account_info: None | AccountInfo = field(
        default=None,
        metadata={
            "name": "accountInfo",
            "type": "Element",
        },
    )
