from __future__ import annotations

from enum import Enum


class CustomUseDetailsTypeDataType(Enum):
    NUMERIC = "numeric"
    STRING = "string"
