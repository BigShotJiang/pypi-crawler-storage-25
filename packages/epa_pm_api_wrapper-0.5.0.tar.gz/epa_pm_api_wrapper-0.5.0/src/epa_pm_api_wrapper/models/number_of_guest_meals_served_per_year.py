from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfGuestMealsServedPerYear(UseIntegerType):
    """
    Total number of guest meals (also called meal covers) served each year.
    """

    class Meta:
        name = "numberOfGuestMealsServedPerYear"
