from __future__ import annotations

from dataclasses import dataclass, field

from .license_list import LicenseList


@dataclass(kw_only=True)
class ProfessionalDesignationListProfessionalDesignation:
    """
    Professional Designation of the verifier.

    Designations include Professional Engineer, Registered Architect, CEM,
    ASHRAE, Other and No Professional Designation.

    :ivar license_list:
    :ivar id: Designation Code
    :ivar name: Designation code description
    """

    class Meta:
        global_type = False

    license_list: None | LicenseList = field(
        default=None,
        metadata={
            "name": "licenseList",
            "type": "Element",
        },
    )
    id: str = field(
        metadata={
            "type": "Attribute",
        }
    )
    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
