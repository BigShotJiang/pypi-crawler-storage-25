from __future__ import annotations

from dataclasses import dataclass

from .onsite_laundry_type import OnsiteLaundryType


@dataclass(kw_only=True)
class LaundryFacility(OnsiteLaundryType):
    """
    Type of laundry processed at the property (linens, Terry, Linens &amp;
    Terry).
    """

    class Meta:
        name = "laundryFacility"
