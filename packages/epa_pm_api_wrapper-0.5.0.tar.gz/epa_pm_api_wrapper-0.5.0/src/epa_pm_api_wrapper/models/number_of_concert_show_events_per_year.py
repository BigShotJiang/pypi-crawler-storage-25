from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfConcertShowEventsPerYear(UseIntegerType):
    """
    Number of concert/show events per year.
    """

    class Meta:
        name = "numberOfConcertShowEventsPerYear"
