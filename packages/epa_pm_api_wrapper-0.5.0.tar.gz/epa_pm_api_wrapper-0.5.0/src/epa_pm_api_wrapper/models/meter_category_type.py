from __future__ import annotations

from enum import Enum


class MeterCategoryType(Enum):
    ENERGY = "ENERGY"
    WATER = "WATER"
    WASTE = "WASTE"
