from __future__ import annotations

from dataclasses import dataclass, field

from .additional_identifier_type_group import AdditionalIdentifierTypeGroup


@dataclass(kw_only=True)
class AdditionalIdentifierType:
    """
    The additional property identifier that EPA has approved for use.

    This is used when you just want to get the complete static list of
    additional property identifiers. This set includes the unique
    identifier #1, #2, and #3 and the set that EPA is maintaining/approved.

    :ivar id: The id of the additional property identifier
    :ivar standard_approved: Whether the additional property identifier
        is from the standard list that EPA is maintaining (versus the
        generic set of 3 unique identifier fields that can be used)
    :ivar name: The name of the additional property identifier
    :ivar description: The description of the additional property
        identifier.
    :ivar group: The group of the additional property identifier.
    """

    class Meta:
        name = "additionalIdentifierType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    standard_approved: None | bool = field(
        default=None,
        metadata={
            "name": "standardApproved",
            "type": "Attribute",
        },
    )
    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    description: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    group: None | AdditionalIdentifierTypeGroup = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
