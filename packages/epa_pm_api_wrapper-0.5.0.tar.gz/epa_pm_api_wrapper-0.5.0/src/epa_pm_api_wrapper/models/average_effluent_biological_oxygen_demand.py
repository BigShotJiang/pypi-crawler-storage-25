from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class AverageEffluentBiologicalOxygenDemand(UseDecimalType):
    """
    The concentration of effluent Biological Oxygen Demand (BOD5) at a
    wastewater treatment plant.
    """

    class Meta:
        name = "averageEffluentBiologicalOxygenDemand"
