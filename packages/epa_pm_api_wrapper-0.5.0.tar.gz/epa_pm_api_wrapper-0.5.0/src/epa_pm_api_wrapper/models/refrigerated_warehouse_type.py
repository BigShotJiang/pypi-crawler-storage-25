from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .refrigerated_warehouse_type_use_details import (
    RefrigeratedWarehouseTypeUseDetails,
)


@dataclass(kw_only=True)
class RefrigeratedWarehouseType:
    class Meta:
        name = "refrigeratedWarehouseType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: RefrigeratedWarehouseTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
