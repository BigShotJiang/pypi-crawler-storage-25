from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfCurlingSheets(UseIntegerType):
    """
    Number of ice sheets specifically for the purpose of the game of
    curling.
    """

    class Meta:
        name = "numberOfCurlingSheets"
