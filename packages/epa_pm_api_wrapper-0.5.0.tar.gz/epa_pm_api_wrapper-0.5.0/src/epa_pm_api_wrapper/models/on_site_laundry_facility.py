from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class OnSiteLaundryFacility(UseYesNoType):
    """
    Presence of an on-site Laundry Facility (Yes/No).
    """

    class Meta:
        name = "onSiteLaundryFacility"
