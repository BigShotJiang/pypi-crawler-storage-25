from __future__ import annotations

from dataclasses import dataclass

from .percent_office_heated_type import PercentOfficeHeatedType


@dataclass(kw_only=True)
class PercentOfficeHeated(PercentOfficeHeatedType):
    class Meta:
        name = "percentOfficeHeated"
