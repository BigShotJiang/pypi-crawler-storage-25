from __future__ import annotations

from dataclasses import dataclass, field

from .target_type_percentage_type import TargetTypePercentageType
from .target_type_score_type import TargetTypeScoreType


@dataclass(kw_only=True)
class DesignBaseTypeTarget:
    """
    :ivar target_type_score: The ENERGY STAR Score that is your target
        score.
    :ivar target_type_percentage: The "% Better than the Median" that is
        your target.
    """

    class Meta:
        global_type = False

    target_type_score: None | TargetTypeScoreType = field(
        default=None,
        metadata={
            "name": "targetTypeScore",
            "type": "Element",
        },
    )
    target_type_percentage: None | TargetTypePercentageType = field(
        default=None,
        metadata={
            "name": "targetTypePercentage",
            "type": "Element",
        },
    )
