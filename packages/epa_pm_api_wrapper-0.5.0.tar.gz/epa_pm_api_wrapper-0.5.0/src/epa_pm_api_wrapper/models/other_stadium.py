from __future__ import annotations

from dataclasses import dataclass

from .other_stadium_type import OtherStadiumType


@dataclass(kw_only=True)
class OtherStadium(OtherStadiumType):
    """
    Buildings primarily used for sporting events that do not meet the
    definition of any other property use defined in Portfolio Manager.
    """

    class Meta:
        name = "otherStadium"
