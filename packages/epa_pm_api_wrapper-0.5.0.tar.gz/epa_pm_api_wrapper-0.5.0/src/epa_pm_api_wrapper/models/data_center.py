from __future__ import annotations

from dataclasses import dataclass

from .data_center_type import DataCenterType


@dataclass(kw_only=True)
class DataCenter(DataCenterType):
    """
    Buildings specifically designed and equipped to meet the needs of high
    density computing equipment, such as server racks, used for data
    storage and processing.
    """

    class Meta:
        name = "dataCenter"
