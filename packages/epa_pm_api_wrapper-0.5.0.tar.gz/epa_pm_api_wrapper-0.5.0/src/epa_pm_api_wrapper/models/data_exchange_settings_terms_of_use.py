from __future__ import annotations

from dataclasses import dataclass, field

from .empty_type import EmptyType


@dataclass(kw_only=True)
class DataExchangeSettingsTermsOfUse:
    """
    :ivar none: You do not have any Terms of Use to provide.
    :ivar text: The text that you want to use for your Terms of Use.
    :ivar url: The URL that customers can reference for the Terms of
        Use.
    """

    class Meta:
        global_type = False

    none: None | EmptyType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    text: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    url: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
