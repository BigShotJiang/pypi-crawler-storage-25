from __future__ import annotations

from dataclasses import dataclass

from .property_metrics_type import PropertyMetricsType


@dataclass(kw_only=True)
class PropertyMetrics(PropertyMetricsType):
    """
    All metrics reflect the 12 months ending on the given month and year.
    """

    class Meta:
        name = "propertyMetrics"
