from __future__ import annotations

from dataclasses import dataclass, field

from .primary_business_type import PrimaryBusinessType
from .type_of_energy_star_partner import TypeOfEnergyStarPartner


@dataclass(kw_only=True)
class OrganizationType:
    """
    :ivar primary_business: Your primary business.
    :ivar other_business_description: Describes other if you chose other
        as your primary business.
    :ivar energy_star_partner: Whether organization is an ENERGY STAR
        Partner.
    :ivar energy_star_partner_type: Whether organization is an ENERGY
        STAR SPP Partner. Only required if the organization is an ENERGY
        STAR Partner.
    :ivar other_partner_description: Describes other if you chose other
        as your energy star partner.
    :ivar name: Your Organization's name.
    """

    class Meta:
        name = "organizationType"

    primary_business: PrimaryBusinessType = field(
        metadata={
            "name": "primaryBusiness",
            "type": "Element",
            "namespace": "",
        }
    )
    other_business_description: None | str = field(
        default=None,
        metadata={
            "name": "otherBusinessDescription",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 1000,
        },
    )
    energy_star_partner: bool = field(
        metadata={
            "name": "energyStarPartner",
            "type": "Element",
            "namespace": "",
        }
    )
    energy_star_partner_type: None | TypeOfEnergyStarPartner = field(
        default=None,
        metadata={
            "name": "energyStarPartnerType",
            "type": "Element",
            "namespace": "",
        },
    )
    other_partner_description: None | str = field(
        default=None,
        metadata={
            "name": "otherPartnerDescription",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 100,
        },
    )
    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
            "min_length": 1,
            "max_length": 1000,
        },
    )
