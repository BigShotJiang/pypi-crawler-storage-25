from __future__ import annotations

from dataclasses import dataclass

from .drinking_water_treatment_and_distribution_type import (
    DrinkingWaterTreatmentAndDistributionType,
)


@dataclass(kw_only=True)
class DrinkingWaterTreatmentAndDistribution(DrinkingWaterTreatmentAndDistributionType):
    """
    Facilities designed to pump and distribute drinking water through a
    network of pipes.
    """

    class Meta:
        name = "drinkingWaterTreatmentAndDistribution"
