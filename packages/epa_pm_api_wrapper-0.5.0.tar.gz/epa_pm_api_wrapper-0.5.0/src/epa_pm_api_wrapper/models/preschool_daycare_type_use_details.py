from __future__ import annotations

from dataclasses import dataclass, field

from .gross_floor_area_used_for_food_preparation import (
    GrossFloorAreaUsedForFoodPreparation,
)
from .number_of_computers import NumberOfComputers
from .number_of_workers import NumberOfWorkers
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .total_gross_floor_area import TotalGrossFloorArea
from .weekly_operating_hours import WeeklyOperatingHours


@dataclass(kw_only=True)
class PreschoolDaycareTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    weekly_operating_hours: None | WeeklyOperatingHours = field(
        default=None,
        metadata={
            "name": "weeklyOperatingHours",
            "type": "Element",
        },
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
    gross_floor_area_used_for_food_preparation: None | GrossFloorAreaUsedForFoodPreparation = field(
        default=None,
        metadata={
            "name": "grossFloorAreaUsedForFoodPreparation",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
