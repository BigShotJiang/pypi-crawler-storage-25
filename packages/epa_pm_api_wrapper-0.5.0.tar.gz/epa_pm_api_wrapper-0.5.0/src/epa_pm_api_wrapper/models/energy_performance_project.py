from __future__ import annotations

from dataclasses import dataclass

from .energy_performance_project_type import EnergyPerformanceProjectType


@dataclass(kw_only=True)
class EnergyPerformanceProject(EnergyPerformanceProjectType):
    class Meta:
        name = "energyPerformanceProject"
