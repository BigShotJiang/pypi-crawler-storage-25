from __future__ import annotations

from dataclasses import dataclass, field

from .floor_area_type_base import FloorAreaTypeBase


@dataclass(kw_only=True)
class OptionalFloorAreaType(FloorAreaTypeBase):
    class Meta:
        name = "optionalFloorAreaType"

    value: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
