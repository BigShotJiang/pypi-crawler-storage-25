from __future__ import annotations

from enum import Enum


class PoolSizeTypeValue(Enum):
    RECREATIONAL_20_YARDS_X_15_YARDS = "Recreational (20 yards x 15 yards)"
    SHORT_COURSE_25_YARDS_X_20_YARDS = "Short Course (25 yards x 20 yards)"
    OLYMPIC_50_METERS_X_25_METERS = "Olympic (50 meters x 25 meters)"
