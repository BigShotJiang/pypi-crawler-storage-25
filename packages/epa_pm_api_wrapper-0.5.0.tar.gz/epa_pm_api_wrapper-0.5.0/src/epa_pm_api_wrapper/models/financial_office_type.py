from __future__ import annotations

from dataclasses import dataclass, field

from .financial_office_type_use_details import FinancialOfficeTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class FinancialOfficeType:
    class Meta:
        name = "financialOfficeType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: FinancialOfficeTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
