from __future__ import annotations

from dataclasses import dataclass, field

from .pgp import Pgp


@dataclass(kw_only=True)
class PgpList:
    class Meta:
        name = "pgpList"

    pgp: list[Pgp] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
