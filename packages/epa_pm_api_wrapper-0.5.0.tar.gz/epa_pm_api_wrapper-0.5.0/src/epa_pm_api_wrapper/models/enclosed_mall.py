from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class EnclosedMall(OtherType):
    """
    Buildings that house multiple stores, often “anchored” by one or more
    department stores, and with interior walkways.
    """

    class Meta:
        name = "enclosedMall"
