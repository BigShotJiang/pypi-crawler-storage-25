from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class MeterListType:
    """
    :ivar meter_id: Id of the meter to associate to the specific
        property or property use.
    """

    class Meta:
        name = "meterListType"

    meter_id: list[int] = field(
        default_factory=list,
        metadata={
            "name": "meterId",
            "type": "Element",
            "namespace": "",
        },
    )
