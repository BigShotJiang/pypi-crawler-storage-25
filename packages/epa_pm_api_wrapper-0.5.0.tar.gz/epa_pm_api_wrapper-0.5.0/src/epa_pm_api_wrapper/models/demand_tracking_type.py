from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .empty_string import EmptyString


@dataclass(kw_only=True)
class DemandTrackingType:
    """
    :ivar demand: Demand amount
    :ivar demand_cost: Demand cost
    """

    class Meta:
        name = "demandTrackingType"

    demand: None | EmptyString | Decimal = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": Decimal("0"),
            "fraction_digits": 2,
        },
    )
    demand_cost: None | EmptyString | Decimal = field(
        default=None,
        metadata={
            "name": "demandCost",
            "type": "Element",
            "namespace": "",
        },
    )
