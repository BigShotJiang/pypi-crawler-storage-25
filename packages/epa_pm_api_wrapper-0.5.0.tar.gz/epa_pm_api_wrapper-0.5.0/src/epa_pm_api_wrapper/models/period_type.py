from __future__ import annotations

from enum import Enum


class PeriodType(Enum):
    CURRENT = "CURRENT"
    BASELINE = "BASELINE"
