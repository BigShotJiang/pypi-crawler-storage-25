from __future__ import annotations

from dataclasses import dataclass

from .courthouse_type import CourthouseType


@dataclass(kw_only=True)
class Courthouse(CourthouseType):
    """
    Buildings used for federal, state, or local courts, and associated
    administrative office space.
    """

    class Meta:
        name = "courthouse"
