from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class Other(OtherType):
    """
    Buildings that do not fall within any of the available property use
    categories in Portfolio Manager.
    """

    class Meta:
        name = "other"
