from __future__ import annotations

from dataclasses import dataclass

from .optional_floor_area_type import OptionalFloorAreaType


@dataclass(kw_only=True)
class GrossFloorAreaHotelConferenceSpace(OptionalFloorAreaType):
    """
    The Gross Floor Area that is Hotel Conference Space is the total size
    of all conference spaces.

    This will be a subset of Gross Floor Area for the property.
    """

    class Meta:
        name = "grossFloorAreaHotelConferenceSpace"
