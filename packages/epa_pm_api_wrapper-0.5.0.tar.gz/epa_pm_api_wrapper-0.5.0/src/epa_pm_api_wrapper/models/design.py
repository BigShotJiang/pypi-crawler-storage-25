from __future__ import annotations

from dataclasses import dataclass

from .design_base_type import DesignBaseType


@dataclass(kw_only=True)
class Design(DesignBaseType):
    """
    The property design characteristics.
    """

    class Meta:
        name = "design"
