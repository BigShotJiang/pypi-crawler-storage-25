from __future__ import annotations

from dataclasses import dataclass, field

from .has_computer_lab import HasComputerLab
from .has_dining_hall import HasDiningHall
from .number_of_rooms import NumberOfRooms
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .total_gross_floor_area import TotalGrossFloorArea


@dataclass(kw_only=True)
class BarracksTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    has_computer_lab: None | HasComputerLab = field(
        default=None,
        metadata={
            "name": "hasComputerLab",
            "type": "Element",
        },
    )
    has_dining_hall: None | HasDiningHall = field(
        default=None,
        metadata={
            "name": "hasDiningHall",
            "type": "Element",
        },
    )
    number_of_rooms: None | NumberOfRooms = field(
        default=None,
        metadata={
            "name": "numberOfRooms",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
