from __future__ import annotations

from dataclasses import dataclass

from .gross_floor_area_type import GrossFloorAreaType


@dataclass(kw_only=True)
class OpenFootage(GrossFloorAreaType):
    """
    Total area of open parking lots/areas.
    """

    class Meta:
        name = "openFootage"
