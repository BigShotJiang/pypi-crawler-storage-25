from __future__ import annotations

from dataclasses import dataclass, field

from .generation_location_type import GenerationLocationType
from .green_power_type_enum import GreenPowerTypeEnum
from .rec_ownership_enum import RecOwnershipEnum


@dataclass(kw_only=True)
class OnsiteUsageDetailType:
    """
    :ivar rec_ownership: The REC ownership type.
    :ivar generation_location: The generation location of the REC,
        required when recOwnership is Arbitraged. Defaults to property's
        facility location when recOwnership is Owned. Not applicable
        when recOwnership is Not Owned/Sold or Unknown.
    :ivar green_power_type: The green power type, required when the
        recOwnership is Arbitraged, not applicable for other
        recOwnership types.
    :ivar meet_vintage_requirement: You must attest that the unbundled
        RECs meet the vintage requirement when green power type is
        Unbundled RECs.
    :ivar certified_by_greene: Flag indicate if certified by Green-e,
        required when the recOwnership is Arbitraged, not applicable for
        other recOwnership types.
    """

    class Meta:
        name = "onsiteUsageDetailType"

    rec_ownership: RecOwnershipEnum = field(
        metadata={
            "name": "recOwnership",
            "type": "Element",
            "namespace": "",
        }
    )
    generation_location: None | GenerationLocationType = field(
        default=None,
        metadata={
            "name": "generationLocation",
            "type": "Element",
            "namespace": "",
        },
    )
    green_power_type: None | GreenPowerTypeEnum = field(
        default=None,
        metadata={
            "name": "greenPowerType",
            "type": "Element",
            "namespace": "",
        },
    )
    meet_vintage_requirement: None | bool = field(
        default=None,
        metadata={
            "name": "meetVintageRequirement",
            "type": "Element",
            "namespace": "",
        },
    )
    certified_by_greene: None | bool = field(
        default=None,
        metadata={
            "name": "certifiedByGreene",
            "type": "Element",
            "namespace": "",
        },
    )
