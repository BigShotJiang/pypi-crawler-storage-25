from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlDateTime


@dataclass(kw_only=True)
class NotificationType:
    """
    :ivar notification_type_code: The notification type code of the
        notification.
    :ivar notification_id: The id number of the notification.
    :ivar description: The description of the notification.
    :ivar account_id: The id number of the account to the corresponding
        notification.
    :ivar username: The username of the Portfolio Manager Account to the
        corresponding notification.
    :ivar property_id: The id number of the property to the
        corresponding notification.
    :ivar meter_id: The id number of the meter to the corresponding
        notification.
    :ivar notification_created_date:
    :ivar notification_created_by: The account name of the user who
        created the corresponding notification.
    :ivar notification_created_by_account_id: The account id of the user
        who created the corresponding notification.
    """

    class Meta:
        name = "notificationType"

    notification_type_code: str = field(
        metadata={
            "name": "notificationTypeCode",
            "type": "Element",
            "namespace": "",
        }
    )
    notification_id: int = field(
        metadata={
            "name": "notificationId",
            "type": "Element",
            "namespace": "",
        }
    )
    description: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    account_id: None | int = field(
        default=None,
        metadata={
            "name": "accountId",
            "type": "Element",
            "namespace": "",
        },
    )
    username: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    property_id: None | int = field(
        default=None,
        metadata={
            "name": "propertyId",
            "type": "Element",
            "namespace": "",
        },
    )
    meter_id: None | int = field(
        default=None,
        metadata={
            "name": "meterId",
            "type": "Element",
            "namespace": "",
        },
    )
    notification_created_date: None | XmlDateTime = field(
        default=None,
        metadata={
            "name": "notificationCreatedDate",
            "type": "Element",
            "namespace": "",
        },
    )
    notification_created_by: None | str = field(
        default=None,
        metadata={
            "name": "notificationCreatedBy",
            "type": "Element",
            "namespace": "",
        },
    )
    notification_created_by_account_id: None | str = field(
        default=None,
        metadata={
            "name": "notificationCreatedByAccountId",
            "type": "Element",
            "namespace": "",
        },
    )
