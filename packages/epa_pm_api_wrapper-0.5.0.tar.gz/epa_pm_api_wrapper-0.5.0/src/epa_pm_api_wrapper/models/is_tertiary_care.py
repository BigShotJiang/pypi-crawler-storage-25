from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class IsTertiaryCare(UseYesNoType):
    """
    Presence of tertiary medical care, specialized care beyond a typical
    secondary level, such as Level 1 trauma centers, organ transplant, or
    prenatal intensive care units (Yes/No).
    """

    class Meta:
        name = "isTertiaryCare"
