from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .other_type_use_details import OtherTypeUseDetails


@dataclass(kw_only=True)
class OtherType:
    class Meta:
        name = "otherType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: OtherTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
