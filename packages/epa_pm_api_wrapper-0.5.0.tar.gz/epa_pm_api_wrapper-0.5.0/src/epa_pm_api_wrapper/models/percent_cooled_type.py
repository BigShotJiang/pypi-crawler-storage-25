from __future__ import annotations

from dataclasses import dataclass, field

from .percent_cooled_type_value import PercentCooledTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class PercentCooledType(UseAttributeBase):
    class Meta:
        name = "percentCooledType"

    value: None | PercentCooledTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
