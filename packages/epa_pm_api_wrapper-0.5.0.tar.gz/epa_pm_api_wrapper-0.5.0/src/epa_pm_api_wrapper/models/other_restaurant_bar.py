from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherRestaurantBar(OtherType):
    """
    Buildings used for preparation and sale of ready-to-eat food and
    beverages, but which does not fit into the fast food restaurant,
    restaurant, or bar/nightclub property types.
    """

    class Meta:
        name = "otherRestaurantBar"
