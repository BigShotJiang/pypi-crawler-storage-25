from __future__ import annotations

from dataclasses import dataclass, field

from .annual_research_expenditure_type_value import (
    AnnualResearchExpenditureTypeValue,
)
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class AnnualResearchExpenditureType(UseAttributeBase):
    class Meta:
        name = "annualResearchExpenditureType"

    value: None | AnnualResearchExpenditureTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
