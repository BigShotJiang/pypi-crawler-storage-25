from __future__ import annotations

from dataclasses import dataclass

from .custom_use_type import CustomUseType


@dataclass(kw_only=True)
class CustomUse(CustomUseType):
    """
    A user-defined property use with custom user-defined use details.
    """

    class Meta:
        name = "customUse"
