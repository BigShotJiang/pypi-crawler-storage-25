from __future__ import annotations

from dataclasses import dataclass, field

from .cooking_facilities import CookingFacilities
from .gross_floor_area_used_for_food_preparation import (
    GrossFloorAreaUsedForFoodPreparation,
)
from .gymnasium_floor_area import GymnasiumFloorArea
from .is_high_school import IsHighSchool
from .months_in_use import MonthsInUse
from .number_of_computers import NumberOfComputers
from .number_of_walk_in_refrigeration_units import (
    NumberOfWalkInRefrigerationUnits,
)
from .number_of_workers import NumberOfWorkers
from .open_on_weekends import OpenOnWeekends
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .school_district import SchoolDistrict
from .student_seating_capacity import StudentSeatingCapacity
from .total_gross_floor_area import TotalGrossFloorArea


@dataclass(kw_only=True)
class K12SchoolTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    open_on_weekends: None | OpenOnWeekends = field(
        default=None,
        metadata={
            "name": "openOnWeekends",
            "type": "Element",
        },
    )
    number_of_walk_in_refrigeration_units: None | NumberOfWalkInRefrigerationUnits = field(
        default=None,
        metadata={
            "name": "numberOfWalkInRefrigerationUnits",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
    cooking_facilities: None | CookingFacilities = field(
        default=None,
        metadata={
            "name": "cookingFacilities",
            "type": "Element",
        },
    )
    is_high_school: None | IsHighSchool = field(
        default=None,
        metadata={
            "name": "isHighSchool",
            "type": "Element",
        },
    )
    months_in_use: None | MonthsInUse = field(
        default=None,
        metadata={
            "name": "monthsInUse",
            "type": "Element",
        },
    )
    school_district: None | SchoolDistrict = field(
        default=None,
        metadata={
            "name": "schoolDistrict",
            "type": "Element",
        },
    )
    student_seating_capacity: None | StudentSeatingCapacity = field(
        default=None,
        metadata={
            "name": "studentSeatingCapacity",
            "type": "Element",
        },
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    gymnasium_floor_area: None | GymnasiumFloorArea = field(
        default=None,
        metadata={
            "name": "gymnasiumFloorArea",
            "type": "Element",
        },
    )
    gross_floor_area_used_for_food_preparation: None | GrossFloorAreaUsedForFoodPreparation = field(
        default=None,
        metadata={
            "name": "grossFloorAreaUsedForFoodPreparation",
            "type": "Element",
        },
    )
