from __future__ import annotations

from dataclasses import dataclass

from .meter_list_type import MeterListType


@dataclass(kw_only=True)
class MeterPropertyUseAssociationList(MeterListType):
    """
    Indicates the association you want to create for a set of meters and a
    specific property use.
    """

    class Meta:
        name = "meterPropertyUseAssociationList"
