from __future__ import annotations

from dataclasses import dataclass, field

from .data_center_type_use_details import DataCenterTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class DataCenterType:
    class Meta:
        name = "dataCenterType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: DataCenterTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
