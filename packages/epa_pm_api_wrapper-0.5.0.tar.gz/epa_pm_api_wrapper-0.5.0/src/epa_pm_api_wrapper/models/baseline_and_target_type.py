from __future__ import annotations

from dataclasses import dataclass, field

from .baseline_type import BaselineType
from .performance_target_type import PerformanceTargetType


@dataclass(kw_only=True)
class BaselineAndTargetType:
    class Meta:
        name = "baselineAndTargetType"

    baseline: None | BaselineType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    target: None | PerformanceTargetType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
