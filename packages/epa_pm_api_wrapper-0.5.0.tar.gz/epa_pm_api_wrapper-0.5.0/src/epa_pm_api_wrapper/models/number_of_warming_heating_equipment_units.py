from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfWarmingHeatingEquipmentUnits(UseIntegerType):
    """
    Number of warming/heating equipment units in a convenience store.
    """

    class Meta:
        name = "numberOfWarmingHeatingEquipmentUnits"
