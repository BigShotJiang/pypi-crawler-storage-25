from __future__ import annotations

from dataclasses import dataclass, field

from .billboard_metric_type import BillboardMetricType


@dataclass(kw_only=True)
class BillboardMetricsType:
    """
    List of billboard metrics that can be used.

    :ivar metric: Displays metric information.
    """

    class Meta:
        name = "billboardMetricsType"

    metric: list[BillboardMetricType] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_occurs": 1,
        },
    )
