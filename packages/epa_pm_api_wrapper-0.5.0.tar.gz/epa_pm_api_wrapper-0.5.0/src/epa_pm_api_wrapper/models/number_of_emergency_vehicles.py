from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfEmergencyVehicles(UseDecimalType):
    """
    The number of emergency vehicles is the count of vehicles that are
    housed at and deployed from a station.
    """

    class Meta:
        name = "numberOfEmergencyVehicles"
