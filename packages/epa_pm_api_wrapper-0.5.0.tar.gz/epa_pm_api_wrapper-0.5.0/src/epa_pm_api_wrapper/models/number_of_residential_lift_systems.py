from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfResidentialLiftSystems(UseDecimalType):
    """
    Number of residential electronic lift systems.
    """

    class Meta:
        name = "numberOfResidentialLiftSystems"
