from __future__ import annotations

from dataclasses import dataclass, field

from .hospital_type_use_details import HospitalTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class HospitalType:
    class Meta:
        name = "hospitalType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: HospitalTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
