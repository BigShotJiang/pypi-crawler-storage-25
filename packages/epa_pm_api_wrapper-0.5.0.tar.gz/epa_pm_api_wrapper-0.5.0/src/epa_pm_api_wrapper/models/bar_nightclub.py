from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class BarNightclub(OtherType):
    """
    Buildings used primarily for social/entertainment purposes, and is
    characterized by most of the revenue being generated from the sale of
    beverages instead of food.
    """

    class Meta:
        name = "barNightclub"
