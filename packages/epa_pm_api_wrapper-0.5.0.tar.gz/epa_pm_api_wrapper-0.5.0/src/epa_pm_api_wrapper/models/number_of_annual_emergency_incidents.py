from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfAnnualEmergencyIncidents(UseDecimalType):
    """
    The number of annual emergency incidents is the typical count of
    instances a station deploys equipment, personnel, or vehicles for its
    facility in a 12-month period.
    """

    class Meta:
        name = "numberOfAnnualEmergencyIncidents"
