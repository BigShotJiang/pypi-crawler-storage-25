from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfFteworkers(UseDecimalType):
    """
    Number of full-time equivalent workers (total number of hours worked by
    all workers, divided by the standard hours in a full time shift).
    """

    class Meta:
        name = "numberOfFTEWorkers"
