from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class IceEvents(UseYesNoType):
    """
    Are there ice-related events such as Hockey, Skating, Ice Capades?
    """

    class Meta:
        name = "iceEvents"
