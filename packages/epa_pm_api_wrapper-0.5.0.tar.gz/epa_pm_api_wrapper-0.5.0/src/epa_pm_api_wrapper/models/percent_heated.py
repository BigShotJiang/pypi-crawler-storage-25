from __future__ import annotations

from dataclasses import dataclass

from .percent_heated_type import PercentHeatedType


@dataclass(kw_only=True)
class PercentHeated(PercentHeatedType):
    """
    The percent of the property that can be heated by mechanical heating
    equipment.
    """

    class Meta:
        name = "percentHeated"
