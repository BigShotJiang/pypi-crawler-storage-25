from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class GenerationLocationType:
    """
    :ivar unknown: The location of the green power is unknown.
    :ivar postal_code: The postal code where the green power is
        generated.
    :ivar e_grid_sub_region: The eGrid subregion code of where the green
        power is generated.
    """

    class Meta:
        name = "generationLocationType"

    unknown: None | str = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    postal_code: None | str = field(
        default=None,
        metadata={
            "name": "postalCode",
            "type": "Element",
            "min_length": 1,
            "max_length": 20,
        },
    )
    e_grid_sub_region: None | str = field(
        default=None,
        metadata={
            "name": "eGridSubRegion",
            "type": "Element",
            "length": 4,
        },
    )
