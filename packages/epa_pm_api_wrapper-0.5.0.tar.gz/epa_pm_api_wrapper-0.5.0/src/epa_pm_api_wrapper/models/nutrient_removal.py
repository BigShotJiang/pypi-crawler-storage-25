from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class NutrientRemoval(UseYesNoType):
    """
    Presence of a nutrient removal system at a wastewater treatment plant
    (Yes/No).
    """

    class Meta:
        name = "nutrientRemoval"
