from __future__ import annotations

from enum import Enum


class CustomerLanguagePreference(Enum):
    EN_US = "en_US"
    FR_CA = "fr_CA"
    ES_US = "es_US"
