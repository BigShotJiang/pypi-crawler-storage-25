from __future__ import annotations

from dataclasses import dataclass, field

from .property_metrics import PropertyMetrics


@dataclass(kw_only=True)
class PropertyMetricsList:
    class Meta:
        name = "propertyMetricsList"

    property_metrics: list[PropertyMetrics] = field(
        default_factory=list,
        metadata={
            "name": "propertyMetrics",
            "type": "Element",
        },
    )
