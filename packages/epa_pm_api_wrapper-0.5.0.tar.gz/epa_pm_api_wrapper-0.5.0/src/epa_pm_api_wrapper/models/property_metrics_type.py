from __future__ import annotations

from dataclasses import dataclass, field

from .metric import Metric
from .period_type import PeriodType


@dataclass(kw_only=True)
class PropertyMetricsType:
    """
    :ivar metric:
    :ivar year: The year of the period ending date for the set of
        metrics.
    :ivar month: The month of the period ending date for the set of
        metrics.
    :ivar period_type: The predefined period type used to generate the
        report metric
    :ivar property_id: The id of the property.
    """

    class Meta:
        name = "propertyMetricsType"

    metric: list[Metric] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    year: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    month: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
            "min_inclusive": 1,
            "max_inclusive": 12,
        },
    )
    period_type: None | PeriodType = field(
        default=None,
        metadata={
            "name": "periodType",
            "type": "Attribute",
        },
    )
    property_id: None | int = field(
        default=None,
        metadata={
            "name": "propertyId",
            "type": "Attribute",
        },
    )
