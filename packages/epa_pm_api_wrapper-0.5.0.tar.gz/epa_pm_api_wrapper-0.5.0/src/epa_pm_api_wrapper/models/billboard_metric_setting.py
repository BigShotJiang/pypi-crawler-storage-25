from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class BillboardMetricSetting:
    """
    Settings to your billboard metric.
    """

    class Meta:
        name = "billboardMetricSetting"

    billboard_metric: str = field(
        metadata={
            "name": "billboardMetric",
            "type": "Element",
            "namespace": "",
        }
    )
