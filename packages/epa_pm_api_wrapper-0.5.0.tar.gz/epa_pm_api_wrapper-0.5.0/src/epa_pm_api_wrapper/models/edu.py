from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class Edu:
    """
    Electric Distribution Utility Information.

    :ivar edu_code: The code to the Electric Distribution Utility (EDU)
    :ivar name: The name of Electric Distribution Utility (EDU).
    :ivar preferred: This is the default EDU for a property if there are
        multiple EDU options.
    :ivar selected: Whether the property is currently assigned to this
        EDU.
    :ivar e_grid_code: The code of the eGrid Subregion that the EDU
        belongs to.
    :ivar e_grid_name: The name of the eGrid Subregion that the EDU
        belongs to.
    """

    class Meta:
        name = "edu"

    edu_code: None | str = field(
        default=None,
        metadata={
            "name": "eduCode",
            "type": "Attribute",
        },
    )
    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    preferred: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    selected: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    e_grid_code: None | str = field(
        default=None,
        metadata={
            "name": "eGridCode",
            "type": "Attribute",
        },
    )
    e_grid_name: None | str = field(
        default=None,
        metadata={
            "name": "eGridName",
            "type": "Attribute",
        },
    )
