from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfLettersPackagesPerYear(UseIntegerType):
    """
    The number of letters and packages per year is the typical sum of mail
    products (such as lettermail, flyers, packages, parcels etc.) processed
    for outbound delivery in this facility in a 12 month period.
    """

    class Meta:
        name = "numberOfLettersPackagesPerYear"
