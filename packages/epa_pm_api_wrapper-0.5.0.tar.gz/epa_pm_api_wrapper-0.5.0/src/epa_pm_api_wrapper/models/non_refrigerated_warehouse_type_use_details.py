from __future__ import annotations

from dataclasses import dataclass, field

from .clear_height import ClearHeight
from .number_of_walk_in_refrigeration_units import (
    NumberOfWalkInRefrigerationUnits,
)
from .number_of_workers import NumberOfWorkers
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .percent_used_for_cold_storage import PercentUsedForColdStorage
from .total_gross_floor_area import TotalGrossFloorArea
from .weekly_operating_hours import WeeklyOperatingHours


@dataclass(kw_only=True)
class NonRefrigeratedWarehouseTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    weekly_operating_hours: None | WeeklyOperatingHours = field(
        default=None,
        metadata={
            "name": "weeklyOperatingHours",
            "type": "Element",
        },
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    percent_used_for_cold_storage: None | PercentUsedForColdStorage = field(
        default=None,
        metadata={
            "name": "percentUsedForColdStorage",
            "type": "Element",
        },
    )
    number_of_walk_in_refrigeration_units: None | NumberOfWalkInRefrigerationUnits = field(
        default=None,
        metadata={
            "name": "numberOfWalkInRefrigerationUnits",
            "type": "Element",
        },
    )
    clear_height: None | ClearHeight = field(
        default=None,
        metadata={
            "name": "clearHeight",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
