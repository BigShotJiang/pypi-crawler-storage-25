from __future__ import annotations

from dataclasses import dataclass

from .length_of_use_detail_type import LengthOfUseDetailType


@dataclass(kw_only=True)
class LengthOfAllCommercialKitchenHoods(LengthOfUseDetailType):
    """
    This is the length of all commercial kitchen exhaust hoods in metres.

    Kitchen Exhaust hood is defined in ASHRAE Handbook - HVAC Applications
    Chapter: Kitchen Ventilation. Commercial kitchen exhaust hoods are used
    primarily to remove cooking effluent from kitchens.
    """

    class Meta:
        name = "lengthOfAllCommercialKitchenHoods"
