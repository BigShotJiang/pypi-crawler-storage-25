from __future__ import annotations

from dataclasses import dataclass

from .annual_research_expenditure_type import AnnualResearchExpenditureType


@dataclass(kw_only=True)
class AnnualResearchExpenditure(AnnualResearchExpenditureType):
    """
    The amount of money this campus spends on research and development in a
    typical year.
    """

    class Meta:
        name = "annualResearchExpenditure"
