from __future__ import annotations

from dataclasses import dataclass

from .log_type import LogType


@dataclass(kw_only=True)
class Log(LogType):
    class Meta:
        name = "log"
