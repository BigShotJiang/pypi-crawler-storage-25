from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .office_type_use_details import OfficeTypeUseDetails


@dataclass(kw_only=True)
class OfficeType:
    class Meta:
        name = "officeType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: OfficeTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
