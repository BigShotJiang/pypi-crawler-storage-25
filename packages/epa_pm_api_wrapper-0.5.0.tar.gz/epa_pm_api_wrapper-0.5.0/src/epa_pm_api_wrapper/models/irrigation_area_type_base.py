from __future__ import annotations

from dataclasses import dataclass, field

from .irrigation_area_units_type import IrrigationAreaUnitsType


@dataclass(kw_only=True)
class IrrigationAreaTypeBase:
    """
    :ivar default: Specifies whether to use the default value for
        Irrigated Area. Only applicable for Multi-Family Housing.
    :ivar units: The units of the Irrigated Area (Square Foot, Square
        Meter, or Acres).
    """

    class Meta:
        name = "irrigationAreaTypeBase"

    default: None | bool = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    units: IrrigationAreaUnitsType = field(
        metadata={
            "type": "Attribute",
        }
    )
