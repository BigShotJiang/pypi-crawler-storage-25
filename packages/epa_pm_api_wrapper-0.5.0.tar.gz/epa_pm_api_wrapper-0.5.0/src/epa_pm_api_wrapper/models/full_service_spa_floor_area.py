from __future__ import annotations

from dataclasses import dataclass

from .optional_floor_area_type import OptionalFloorAreaType


@dataclass(kw_only=True)
class FullServiceSpaFloorArea(OptionalFloorAreaType):
    """
    Floor area associated with a Full Service Spa.
    """

    class Meta:
        name = "fullServiceSpaFloorArea"
