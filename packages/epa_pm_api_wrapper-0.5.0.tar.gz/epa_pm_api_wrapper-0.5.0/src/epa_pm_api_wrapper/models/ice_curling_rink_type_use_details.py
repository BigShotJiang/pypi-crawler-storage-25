from __future__ import annotations

from dataclasses import dataclass, field

from .months_main_indoor_ice_rink_in_use import MonthsMainIndoorIceRinkInUse
from .number_of_curling_sheets import NumberOfCurlingSheets
from .number_of_fteworkers import NumberOfFteworkers
from .number_of_indoor_ice_rinks import NumberOfIndoorIceRinks
from .number_of_weekly_ice_resurfacing_for_all_rinks import (
    NumberOfWeeklyIceResurfacingForAllRinks,
)
from .spectator_seating_capacity import SpectatorSeatingCapacity
from .total_gross_floor_area import TotalGrossFloorArea
from .total_ice_rink_surface_area_for_all_rinks import (
    TotalIceRinkSurfaceAreaForAllRinks,
)


@dataclass(kw_only=True)
class IceCurlingRinkTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    number_of_indoor_ice_rinks: None | NumberOfIndoorIceRinks = field(
        default=None,
        metadata={
            "name": "numberOfIndoorIceRinks",
            "type": "Element",
        },
    )
    total_ice_rink_surface_area_for_all_rinks: None | TotalIceRinkSurfaceAreaForAllRinks = field(
        default=None,
        metadata={
            "name": "totalIceRinkSurfaceAreaForAllRinks",
            "type": "Element",
        },
    )
    months_main_indoor_ice_rink_in_use: None | MonthsMainIndoorIceRinkInUse = field(
        default=None,
        metadata={
            "name": "monthsMainIndoorIceRinkInUse",
            "type": "Element",
        },
    )
    number_of_weekly_ice_resurfacing_for_all_rinks: None | NumberOfWeeklyIceResurfacingForAllRinks = field(
        default=None,
        metadata={
            "name": "numberOfWeeklyIceResurfacingForAllRinks",
            "type": "Element",
        },
    )
    number_of_fteworkers: None | NumberOfFteworkers = field(
        default=None,
        metadata={
            "name": "numberOfFTEWorkers",
            "type": "Element",
        },
    )
    number_of_curling_sheets: None | NumberOfCurlingSheets = field(
        default=None,
        metadata={
            "name": "numberOfCurlingSheets",
            "type": "Element",
        },
    )
    spectator_seating_capacity: None | SpectatorSeatingCapacity = field(
        default=None,
        metadata={
            "name": "spectatorSeatingCapacity",
            "type": "Element",
        },
    )
