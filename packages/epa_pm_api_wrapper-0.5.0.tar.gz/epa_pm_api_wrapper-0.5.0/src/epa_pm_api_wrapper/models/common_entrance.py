from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class CommonEntrance(UseYesNoType):
    """
    Indicates presence of common entrance: Yes and No are 2 options and 1
    or 0 is used.
    """

    class Meta:
        name = "commonEntrance"
