from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .preschool_daycare_type_use_details import PreschoolDaycareTypeUseDetails


@dataclass(kw_only=True)
class PreschoolDaycareType:
    class Meta:
        name = "preschoolDaycareType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: PreschoolDaycareTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
