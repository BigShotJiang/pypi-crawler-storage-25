from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class DataRequestRequesterDetails:
    class Meta:
        global_type = False

    first_name: str = field(
        metadata={
            "name": "firstName",
            "type": "Element",
        }
    )
    last_name: str = field(
        metadata={
            "name": "lastName",
            "type": "Element",
        }
    )
    email: str = field(
        metadata={
            "type": "Element",
        }
    )
    phone: str = field(
        metadata={
            "type": "Element",
        }
    )
