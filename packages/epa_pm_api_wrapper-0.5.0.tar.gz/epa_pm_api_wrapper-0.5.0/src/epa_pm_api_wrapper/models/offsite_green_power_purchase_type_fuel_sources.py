from __future__ import annotations

from dataclasses import dataclass, field

from .offsite_green_power_purchase_type_fuel_sources_fuel_source import (
    OffsiteGreenPowerPurchaseTypeFuelSourcesFuelSource,
)


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchaseTypeFuelSources:
    class Meta:
        global_type = False

    fuel_source: list[OffsiteGreenPowerPurchaseTypeFuelSourcesFuelSource] = field(
        default_factory=list,
        metadata={
            "name": "fuelSource",
            "type": "Element",
            "namespace": "",
        },
    )
