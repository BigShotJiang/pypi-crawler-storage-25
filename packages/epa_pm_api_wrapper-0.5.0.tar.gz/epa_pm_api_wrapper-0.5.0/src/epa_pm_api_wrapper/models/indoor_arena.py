from __future__ import annotations

from dataclasses import dataclass

from .indoor_arena_type import IndoorArenaType


@dataclass(kw_only=True)
class IndoorArena(IndoorArenaType):
    """
    Enclosed structures used for professional or collegiate sports and
    entertainment events. (typically with a capacity of at least 5,000
    seats).
    """

    class Meta:
        name = "indoorArena"
