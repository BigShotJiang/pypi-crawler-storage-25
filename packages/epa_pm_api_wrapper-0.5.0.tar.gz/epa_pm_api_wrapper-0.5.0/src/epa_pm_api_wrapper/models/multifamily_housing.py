from __future__ import annotations

from dataclasses import dataclass

from .multifamily_housing_type import MultifamilyHousingType


@dataclass(kw_only=True)
class MultifamilyHousing(MultifamilyHousingType):
    """
    Residential Buildings that contain more than two residential living
    units.
    """

    class Meta:
        name = "multifamilyHousing"
