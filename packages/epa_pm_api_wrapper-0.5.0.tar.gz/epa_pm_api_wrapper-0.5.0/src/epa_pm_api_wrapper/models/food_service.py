from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class FoodService(OtherType):
    """
    Buildings used for preparation and sale of food and beverages, but
    which do not meet the definition of Restaurant, Cafeteria, or
    Bar/Nightclub.
    """

    class Meta:
        name = "foodService"
