from __future__ import annotations

from enum import Enum


class RenewableGenerationTechnologyEnum(Enum):
    SOLAR_PV_CARPORTS = "Solar PV- Carports"
    SOLAR_PV_GROUND_MOUNTED = "Solar PV- Ground-mounted"
    SOLAR_PV_ROOFTOP = "Solar PV- Rooftop"
    SOLAR_THERMAL_CONCENTRATING_SOLAR_POWER = "Solar Thermal- Concentrating Solar Power"
    OTHER = "Other"
