from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfLevelOneEvChargingStations(UseDecimalType):
    """
    Number of Level One electric vehicle charging stations.
    """

    class Meta:
        name = "numberOfLevelOneEvChargingStations"
