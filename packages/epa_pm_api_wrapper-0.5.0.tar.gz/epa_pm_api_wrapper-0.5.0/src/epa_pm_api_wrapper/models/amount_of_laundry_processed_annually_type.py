from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .amount_of_laundry_processed_annually_units_type import (
    AmountOfLaundryProcessedAnnuallyUnitsType,
)
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class AmountOfLaundryProcessedAnnuallyType(UseAttributeBase):
    class Meta:
        name = "amountOfLaundryProcessedAnnuallyType"

    value: None | Decimal = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    units: AmountOfLaundryProcessedAnnuallyUnitsType = field(
        metadata={
            "type": "Attribute",
        }
    )
