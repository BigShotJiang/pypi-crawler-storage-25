from __future__ import annotations

from dataclasses import dataclass, field

from .fire_station_type_use_details import FireStationTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class FireStationType:
    class Meta:
        name = "fireStationType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: FireStationTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
