from __future__ import annotations

from dataclasses import dataclass, field

from .pool_type_value import PoolTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class PoolType(UseAttributeBase):
    class Meta:
        name = "poolType"

    value: None | PoolTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
