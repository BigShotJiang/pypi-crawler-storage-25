from __future__ import annotations

from dataclasses import dataclass

from .hours_per_day_guests_onsite_type import HoursPerDayGuestsOnsiteType


@dataclass(kw_only=True)
class HoursPerDayGuestsOnsite(HoursPerDayGuestsOnsiteType):
    """
    Number of hours per day a typical guest spends at the property (Less
    Than 15, 15 To 19, More Than 20).
    """

    class Meta:
        name = "hoursPerDayGuestsOnsite"
