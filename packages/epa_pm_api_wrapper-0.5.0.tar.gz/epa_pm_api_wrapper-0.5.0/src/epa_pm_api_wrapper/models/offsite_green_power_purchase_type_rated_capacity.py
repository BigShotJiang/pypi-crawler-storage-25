from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .rated_capacity_uom_type import RatedCapacityUomType


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchaseTypeRatedCapacity:
    """
    :ivar value:
    :ivar uom: The unit of the value (kW or MW).
    """

    class Meta:
        global_type = False

    value: Decimal = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_exclusive": Decimal("0"),
            "fraction_digits": 1,
        }
    )
    uom: RatedCapacityUomType = field(
        metadata={
            "type": "Attribute",
        }
    )
