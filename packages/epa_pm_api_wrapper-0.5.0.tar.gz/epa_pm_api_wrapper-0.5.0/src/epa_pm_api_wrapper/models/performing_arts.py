from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class PerformingArts(OtherType):
    """
    Buildings used for public or private artistic or musical performances.
    """

    class Meta:
        name = "performingArts"
