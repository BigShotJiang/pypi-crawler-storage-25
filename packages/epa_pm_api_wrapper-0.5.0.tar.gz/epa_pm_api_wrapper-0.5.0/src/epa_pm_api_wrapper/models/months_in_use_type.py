from __future__ import annotations

from dataclasses import dataclass, field

from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class MonthsInUseType(UseAttributeBase):
    class Meta:
        name = "monthsInUseType"

    value: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": 1,
            "max_inclusive": 12,
        },
    )
