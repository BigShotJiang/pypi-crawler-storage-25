from __future__ import annotations

from dataclasses import dataclass

from .optional_floor_area_type import OptionalFloorAreaType


@dataclass(kw_only=True)
class GymCenterFloorArea(OptionalFloorAreaType):
    """
    Floor area associated with a Gym/Fitness Center.
    """

    class Meta:
        name = "gymCenterFloorArea"
