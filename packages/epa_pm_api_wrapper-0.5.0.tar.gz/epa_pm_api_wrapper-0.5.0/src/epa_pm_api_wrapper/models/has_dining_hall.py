from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class HasDiningHall(UseYesNoType):
    """
    Whether there is a Dining Hall.
    """

    class Meta:
        name = "hasDiningHall"
