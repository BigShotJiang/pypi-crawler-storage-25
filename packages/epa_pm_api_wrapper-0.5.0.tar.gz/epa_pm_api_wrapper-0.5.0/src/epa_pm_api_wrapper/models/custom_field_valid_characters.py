from __future__ import annotations

from enum import Enum


class CustomFieldValidCharacters(Enum):
    """
    :cvar ANY: Any character allowed
    :cvar ALPHANUMERIC: Alphanumeric Characters only
    :cvar NUMERIC: Numeric Characters only
    """

    ANY = "Any"
    ALPHANUMERIC = "Alphanumeric"
    NUMERIC = "Numeric"
