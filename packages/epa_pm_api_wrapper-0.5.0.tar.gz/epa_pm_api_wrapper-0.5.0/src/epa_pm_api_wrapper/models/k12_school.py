from __future__ import annotations

from dataclasses import dataclass

from .k12_school_type import K12SchoolType


@dataclass(kw_only=True)
class K12School(K12SchoolType):
    """
    Buildings or campuses used as a school for Kindergarten through 12th
    grade students.
    """

    class Meta:
        name = "k12School"
