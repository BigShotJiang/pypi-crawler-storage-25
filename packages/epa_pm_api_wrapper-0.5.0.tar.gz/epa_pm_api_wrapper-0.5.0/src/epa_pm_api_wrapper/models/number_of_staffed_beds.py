from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfStaffedBeds(UseDecimalType):
    """
    Number of beds set up and staffed for use at a hospital.
    """

    class Meta:
        name = "numberOfStaffedBeds"
