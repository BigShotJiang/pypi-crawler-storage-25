from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .design_base_type_estimated_energy_list import (
    DesignBaseTypeEstimatedEnergyList,
)
from .design_base_type_property_uses import DesignBaseTypePropertyUses
from .design_base_type_target import DesignBaseTypeTarget


@dataclass(kw_only=True)
class DesignBaseType:
    """
    :ivar property_uses: Most property use characteristics XML
        attributes (the id, currentAsOf, and temporary) are not
        applicable and will be ignored if provided.
    :ivar drinking_water_influent_flow: The planned average daily flow
        for a Water Treatment and Distribution Plant.  This value must
        be specified if one of the property uses is of the type Water
        Distribution.
    :ivar waste_water_influent_flow: The planned average daily flow of
        water through a Wastewater Treatment Plant.  This value must be
        specified if one of the property uses is of the type Waste Water
        Treatment Plant.
    :ivar it_site_energy: The amount of energy required by the server
        racks, storage silos, and other IT equipment in the Data Center
        at the output of UPS.  This value must be specified if one of
        the property uses is of the type Data Center.
    :ivar estimated_energy_list: If you can estimate how much energy
        your design property will use annually, provide it here to
        receive a score (if available) and energy metrics for your
        design.  You can then use these metrics to compare to your
        target and/or property's operation (in the future).  To get the
        most accurate metrics, provide estimates for total annual energy
        from each potential energy source.
    :ivar target: The Design Target can be either ENERGY STAR Score or
        "% Better than Median."
    """

    class Meta:
        name = "designBaseType"

    property_uses: DesignBaseTypePropertyUses = field(
        metadata={
            "name": "propertyUses",
            "type": "Element",
        }
    )
    drinking_water_influent_flow: None | Decimal = field(
        default=None,
        metadata={
            "name": "drinkingWaterInfluentFlow",
            "type": "Element",
        },
    )
    waste_water_influent_flow: None | Decimal = field(
        default=None,
        metadata={
            "name": "wasteWaterInfluentFlow",
            "type": "Element",
        },
    )
    it_site_energy: None | Decimal = field(
        default=None,
        metadata={
            "name": "itSiteEnergy",
            "type": "Element",
        },
    )
    estimated_energy_list: None | DesignBaseTypeEstimatedEnergyList = field(
        default=None,
        metadata={
            "name": "estimatedEnergyList",
            "type": "Element",
        },
    )
    target: DesignBaseTypeTarget = field(
        metadata={
            "type": "Element",
        }
    )
