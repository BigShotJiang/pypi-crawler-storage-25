from __future__ import annotations

from dataclasses import dataclass, field

from .drinking_water_treatment_and_distribution_type_use_details import (
    DrinkingWaterTreatmentAndDistributionTypeUseDetails,
)
from .log_type import LogType


@dataclass(kw_only=True)
class DrinkingWaterTreatmentAndDistributionType:
    class Meta:
        name = "drinkingWaterTreatmentAndDistributionType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: DrinkingWaterTreatmentAndDistributionTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
