from __future__ import annotations

from enum import Enum


class PropertyRepresentationPropertyRepresentationType(Enum):
    """
    :cvar WHOLE_PROPERTY: The energy meters are associated with the
        whole property.
    :cvar COMMON_AREA_ENERGY_CONSUMPTION_ONLY: The energy meters are
        associated with the common area only.
    :cvar TENANT_ENERGY_CONSUMPTION_ONLY: The energy meters are
        associated with a combination of the tenant and common areas.
    :cvar COMBINATION_OF_TENANT_AND_COMMON_AREA_CONSUMPTION: If
        selected, you must specify the energy uses with the
        "tenantCommonAreaEnergyUseList" XML element.
    :cvar OTHER: The energy meters are not associated with any of the
        given choices, you are specifiying "Other."
    :cvar NO_SELECTION_MADE:
    """

    WHOLE_PROPERTY = "Whole Property"
    COMMON_AREA_ENERGY_CONSUMPTION_ONLY = "Common Area Energy Consumption Only"
    TENANT_ENERGY_CONSUMPTION_ONLY = "Tenant Energy Consumption Only"
    COMBINATION_OF_TENANT_AND_COMMON_AREA_CONSUMPTION = "Combination of Tenant and Common Area Consumption"
    OTHER = "Other"
    NO_SELECTION_MADE = "No Selection Made"
