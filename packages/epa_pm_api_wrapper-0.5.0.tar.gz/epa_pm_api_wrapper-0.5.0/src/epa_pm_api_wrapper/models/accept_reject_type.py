from __future__ import annotations

from enum import Enum


class AcceptRejectType(Enum):
    """
    The response to the sharing request.
    """

    ACCEPT = "Accept"
    REJECT = "Reject"
