from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfRepairBays(UseDecimalType):
    """
    The number of repair bays is the count of designated spaces for a
    single vehicle to receive maintenance or repair.
    """

    class Meta:
        name = "numberOfRepairBays"
