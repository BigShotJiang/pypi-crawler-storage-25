from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfResidentialLivingUnitsHighRiseSetting(UseDecimalType):
    """
    Number of units located in individual buildings that are 10 or more
    stories in height, as well as units located in wings/portions of
    buildings that fall in this range (e.g. if Wing A is 10 stories and
    Wing B is 5 stories, only units in Wing A would be counted here).
    """

    class Meta:
        name = "numberOfResidentialLivingUnitsHighRiseSetting"
