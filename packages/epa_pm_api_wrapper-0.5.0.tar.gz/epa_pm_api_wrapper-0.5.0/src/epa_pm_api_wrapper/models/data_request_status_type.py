from __future__ import annotations

from enum import Enum


class DataRequestStatusType(Enum):
    """
    The status of the Data Request.
    """

    OPEN = "OPEN"
    CLOSED = "CLOSED"
    ALL = "ALL"
