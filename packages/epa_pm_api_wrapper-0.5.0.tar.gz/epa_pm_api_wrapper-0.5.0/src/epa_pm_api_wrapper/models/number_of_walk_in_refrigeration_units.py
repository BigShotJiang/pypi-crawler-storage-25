from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfWalkInRefrigerationUnits(UseDecimalType):
    """
    Number of walk-in refrigeration/freezer units - including only those
    commercial type units that you can completely enter to retrieve goods.
    """

    class Meta:
        name = "numberOfWalkInRefrigerationUnits"
