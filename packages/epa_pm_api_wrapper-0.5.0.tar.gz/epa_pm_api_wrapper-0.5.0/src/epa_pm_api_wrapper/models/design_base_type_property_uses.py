from __future__ import annotations

from dataclasses import dataclass, field

from .adult_education import AdultEducation
from .ambulatory_surgical_center import AmbulatorySurgicalCenter
from .aquarium import Aquarium
from .bank_branch import BankBranch
from .bar_nightclub import BarNightclub
from .barracks import Barracks
from .bowling_alley import BowlingAlley
from .casino import Casino
from .cegep import Cegep
from .college_university import CollegeUniversity
from .community_center_and_social_meeting_hall import (
    CommunityCenterAndSocialMeetingHall,
)
from .convenience_store_with_gas_station import ConvenienceStoreWithGasStation
from .convenience_store_without_gas_station import (
    ConvenienceStoreWithoutGasStation,
)
from .convention_center import ConventionCenter
from .courthouse import Courthouse
from .data_center import DataCenter
from .distribution_center import DistributionCenter
from .drinking_water_treatment_and_distribution import (
    DrinkingWaterTreatmentAndDistribution,
)
from .electric_vehicle_charging_station import ElectricVehicleChargingStation
from .enclosed_mall import EnclosedMall
from .energy_power_station import EnergyPowerStation
from .fast_food_restaurant import FastFoodRestaurant
from .financial_office import FinancialOffice
from .fire_station import FireStation
from .fitness_center_health_club_gym import FitnessCenterHealthClubGym
from .food_sales import FoodSales
from .food_service import FoodService
from .hospital import Hospital
from .hotel import Hotel
from .ice_curling_rink import IceCurlingRink
from .indoor_arena import IndoorArena
from .k12_school import K12School
from .laboratory import Laboratory
from .library import Library
from .lifestyle_center import LifestyleCenter
from .mailing_center_post_office import MailingCenterPostOffice
from .manufacturing_industrial_plant import ManufacturingIndustrialPlant
from .medical_office import MedicalOffice
from .movie_theater import MovieTheater
from .multifamily_housing import MultifamilyHousing
from .museum import Museum
from .non_refrigerated_warehouse import NonRefrigeratedWarehouse
from .office import Office
from .other import Other
from .other_education import OtherEducation
from .other_entertainment_public_assembly import (
    OtherEntertainmentPublicAssembly,
)
from .other_lodging_residential import OtherLodgingResidential
from .other_mall import OtherMall
from .other_public_services import OtherPublicServices
from .other_recreation import OtherRecreation
from .other_restaurant_bar import OtherRestaurantBar
from .other_services import OtherServices
from .other_speciality_hospital import OtherSpecialityHospital
from .other_stadium import OtherStadium
from .other_technology_science import OtherTechnologyScience
from .other_utility import OtherUtility
from .outpatient_rehabilitation_physical_therapy import (
    OutpatientRehabilitationPhysicalTherapy,
)
from .parking import Parking
from .performing_arts import PerformingArts
from .personal_services import PersonalServices
from .police_station import PoliceStation
from .preschool_daycare import PreschoolDaycare
from .prison import Prison
from .race_track import RaceTrack
from .refrigerated_warehouse import RefrigeratedWarehouse
from .residence_hall_dormitory import ResidenceHallDormitory
from .residential_care_facility import ResidentialCareFacility
from .restaurant import Restaurant
from .retail import Retail
from .roller_rink import RollerRink
from .self_storage_facility import SelfStorageFacility
from .senior_living_community import SeniorLivingCommunity
from .single_family_home import SingleFamilyHome
from .stadium_closed import StadiumClosed
from .stadium_open import StadiumOpen
from .strip_mall import StripMall
from .supermarket import Supermarket
from .swimming_pool import SwimmingPool
from .transportation_terminal_station import TransportationTerminalStation
from .urgent_care_clinic_other_outpatient import (
    UrgentCareClinicOtherOutpatient,
)
from .vehicle_dealership import VehicleDealership
from .vehicle_repair_services import VehicleRepairServices
from .veterinary_office import VeterinaryOffice
from .vocational_school import VocationalSchool
from .wastewater_treatment_plant import WastewaterTreatmentPlant
from .wholesale_club_supercenter import WholesaleClubSupercenter
from .worship_facility import WorshipFacility
from .zoo import Zoo


@dataclass(kw_only=True)
class DesignBaseTypePropertyUses:
    class Meta:
        global_type = False

    prison: list[Prison] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    refrigerated_warehouse: list[RefrigeratedWarehouse] = field(
        default_factory=list,
        metadata={
            "name": "refrigeratedWarehouse",
            "type": "Element",
        },
    )
    retail: list[Retail] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    hospital: list[Hospital] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    medical_office: list[MedicalOffice] = field(
        default_factory=list,
        metadata={
            "name": "medicalOffice",
            "type": "Element",
        },
    )
    data_center: list[DataCenter] = field(
        default_factory=list,
        metadata={
            "name": "dataCenter",
            "type": "Element",
        },
    )
    courthouse: list[Courthouse] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    single_family_home: list[SingleFamilyHome] = field(
        default_factory=list,
        metadata={
            "name": "singleFamilyHome",
            "type": "Element",
        },
    )
    non_refrigerated_warehouse: list[NonRefrigeratedWarehouse] = field(
        default_factory=list,
        metadata={
            "name": "nonRefrigeratedWarehouse",
            "type": "Element",
        },
    )
    multifamily_housing: list[MultifamilyHousing] = field(
        default_factory=list,
        metadata={
            "name": "multifamilyHousing",
            "type": "Element",
        },
    )
    office: list[Office] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    wholesale_club_supercenter: list[WholesaleClubSupercenter] = field(
        default_factory=list,
        metadata={
            "name": "wholesaleClubSupercenter",
            "type": "Element",
        },
    )
    self_storage_facility: list[SelfStorageFacility] = field(
        default_factory=list,
        metadata={
            "name": "selfStorageFacility",
            "type": "Element",
        },
    )
    senior_living_community: list[SeniorLivingCommunity] = field(
        default_factory=list,
        metadata={
            "name": "seniorLivingCommunity",
            "type": "Element",
        },
    )
    residential_care_facility: list[ResidentialCareFacility] = field(
        default_factory=list,
        metadata={
            "name": "residentialCareFacility",
            "type": "Element",
        },
    )
    swimming_pool: list[SwimmingPool] = field(
        default_factory=list,
        metadata={
            "name": "swimmingPool",
            "type": "Element",
        },
    )
    residence_hall_dormitory: list[ResidenceHallDormitory] = field(
        default_factory=list,
        metadata={
            "name": "residenceHallDormitory",
            "type": "Element",
        },
    )
    wastewater_treatment_plant: list[WastewaterTreatmentPlant] = field(
        default_factory=list,
        metadata={
            "name": "wastewaterTreatmentPlant",
            "type": "Element",
        },
    )
    distribution_center: list[DistributionCenter] = field(
        default_factory=list,
        metadata={
            "name": "distributionCenter",
            "type": "Element",
        },
    )
    worship_facility: list[WorshipFacility] = field(
        default_factory=list,
        metadata={
            "name": "worshipFacility",
            "type": "Element",
        },
    )
    financial_office: list[FinancialOffice] = field(
        default_factory=list,
        metadata={
            "name": "financialOffice",
            "type": "Element",
        },
    )
    drinking_water_treatment_and_distribution: list[DrinkingWaterTreatmentAndDistribution] = field(
        default_factory=list,
        metadata={
            "name": "drinkingWaterTreatmentAndDistribution",
            "type": "Element",
        },
    )
    parking: list[Parking] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    supermarket: list[Supermarket] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    barracks: list[Barracks] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    hotel: list[Hotel] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    k12_school: list[K12School] = field(
        default_factory=list,
        metadata={
            "name": "k12School",
            "type": "Element",
        },
    )
    bank_branch: list[BankBranch] = field(
        default_factory=list,
        metadata={
            "name": "bankBranch",
            "type": "Element",
        },
    )
    cegep: list[Cegep] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    college_university: list[CollegeUniversity] = field(
        default_factory=list,
        metadata={
            "name": "collegeUniversity",
            "type": "Element",
        },
    )
    indoor_arena: list[IndoorArena] = field(
        default_factory=list,
        metadata={
            "name": "indoorArena",
            "type": "Element",
        },
    )
    other_stadium: list[OtherStadium] = field(
        default_factory=list,
        metadata={
            "name": "otherStadium",
            "type": "Element",
        },
    )
    stadium_closed: list[StadiumClosed] = field(
        default_factory=list,
        metadata={
            "name": "stadiumClosed",
            "type": "Element",
        },
    )
    stadium_open: list[StadiumOpen] = field(
        default_factory=list,
        metadata={
            "name": "stadiumOpen",
            "type": "Element",
        },
    )
    manufacturing_industrial_plant: list[ManufacturingIndustrialPlant] = field(
        default_factory=list,
        metadata={
            "name": "manufacturingIndustrialPlant",
            "type": "Element",
        },
    )
    ambulatory_surgical_center: list[AmbulatorySurgicalCenter] = field(
        default_factory=list,
        metadata={
            "name": "ambulatorySurgicalCenter",
            "type": "Element",
        },
    )
    bowling_alley: list[BowlingAlley] = field(
        default_factory=list,
        metadata={
            "name": "bowlingAlley",
            "type": "Element",
        },
    )
    other_public_services: list[OtherPublicServices] = field(
        default_factory=list,
        metadata={
            "name": "otherPublicServices",
            "type": "Element",
        },
    )
    other_lodging_residential: list[OtherLodgingResidential] = field(
        default_factory=list,
        metadata={
            "name": "otherLodgingResidential",
            "type": "Element",
        },
    )
    casino: list[Casino] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    personal_services: list[PersonalServices] = field(
        default_factory=list,
        metadata={
            "name": "personalServices",
            "type": "Element",
        },
    )
    mailing_center_post_office: list[MailingCenterPostOffice] = field(
        default_factory=list,
        metadata={
            "name": "mailingCenterPostOffice",
            "type": "Element",
        },
    )
    library: list[Library] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    other_speciality_hospital: list[OtherSpecialityHospital] = field(
        default_factory=list,
        metadata={
            "name": "otherSpecialityHospital",
            "type": "Element",
        },
    )
    convention_center: list[ConventionCenter] = field(
        default_factory=list,
        metadata={
            "name": "conventionCenter",
            "type": "Element",
        },
    )
    veterinary_office: list[VeterinaryOffice] = field(
        default_factory=list,
        metadata={
            "name": "veterinaryOffice",
            "type": "Element",
        },
    )
    urgent_care_clinic_other_outpatient: list[UrgentCareClinicOtherOutpatient] = field(
        default_factory=list,
        metadata={
            "name": "urgentCareClinicOtherOutpatient",
            "type": "Element",
        },
    )
    energy_power_station: list[EnergyPowerStation] = field(
        default_factory=list,
        metadata={
            "name": "energyPowerStation",
            "type": "Element",
        },
    )
    other_services: list[OtherServices] = field(
        default_factory=list,
        metadata={
            "name": "otherServices",
            "type": "Element",
        },
    )
    bar_nightclub: list[BarNightclub] = field(
        default_factory=list,
        metadata={
            "name": "barNightclub",
            "type": "Element",
        },
    )
    other_utility: list[OtherUtility] = field(
        default_factory=list,
        metadata={
            "name": "otherUtility",
            "type": "Element",
        },
    )
    zoo: list[Zoo] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    vehicle_dealership: list[VehicleDealership] = field(
        default_factory=list,
        metadata={
            "name": "vehicleDealership",
            "type": "Element",
        },
    )
    museum: list[Museum] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    other_recreation: list[OtherRecreation] = field(
        default_factory=list,
        metadata={
            "name": "otherRecreation",
            "type": "Element",
        },
    )
    other_restaurant_bar: list[OtherRestaurantBar] = field(
        default_factory=list,
        metadata={
            "name": "otherRestaurantBar",
            "type": "Element",
        },
    )
    lifestyle_center: list[LifestyleCenter] = field(
        default_factory=list,
        metadata={
            "name": "lifestyleCenter",
            "type": "Element",
        },
    )
    police_station: list[PoliceStation] = field(
        default_factory=list,
        metadata={
            "name": "policeStation",
            "type": "Element",
        },
    )
    preschool_daycare: list[PreschoolDaycare] = field(
        default_factory=list,
        metadata={
            "name": "preschoolDaycare",
            "type": "Element",
        },
    )
    race_track: list[RaceTrack] = field(
        default_factory=list,
        metadata={
            "name": "raceTrack",
            "type": "Element",
        },
    )
    fast_food_restaurant: list[FastFoodRestaurant] = field(
        default_factory=list,
        metadata={
            "name": "fastFoodRestaurant",
            "type": "Element",
        },
    )
    laboratory: list[Laboratory] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    convenience_store_without_gas_station: list[ConvenienceStoreWithoutGasStation] = field(
        default_factory=list,
        metadata={
            "name": "convenienceStoreWithoutGasStation",
            "type": "Element",
        },
    )
    vehicle_repair_services: list[VehicleRepairServices] = field(
        default_factory=list,
        metadata={
            "name": "vehicleRepairServices",
            "type": "Element",
        },
    )
    other_technology_science: list[OtherTechnologyScience] = field(
        default_factory=list,
        metadata={
            "name": "otherTechnologyScience",
            "type": "Element",
        },
    )
    fire_station: list[FireStation] = field(
        default_factory=list,
        metadata={
            "name": "fireStation",
            "type": "Element",
        },
    )
    food_sales: list[FoodSales] = field(
        default_factory=list,
        metadata={
            "name": "foodSales",
            "type": "Element",
        },
    )
    performing_arts: list[PerformingArts] = field(
        default_factory=list,
        metadata={
            "name": "performingArts",
            "type": "Element",
        },
    )
    outpatient_rehabilitation_physical_therapy: list[OutpatientRehabilitationPhysicalTherapy] = field(
        default_factory=list,
        metadata={
            "name": "outpatientRehabilitationPhysicalTherapy",
            "type": "Element",
        },
    )
    strip_mall: list[StripMall] = field(
        default_factory=list,
        metadata={
            "name": "stripMall",
            "type": "Element",
        },
    )
    roller_rink: list[RollerRink] = field(
        default_factory=list,
        metadata={
            "name": "rollerRink",
            "type": "Element",
        },
    )
    other_education: list[OtherEducation] = field(
        default_factory=list,
        metadata={
            "name": "otherEducation",
            "type": "Element",
        },
    )
    fitness_center_health_club_gym: list[FitnessCenterHealthClubGym] = field(
        default_factory=list,
        metadata={
            "name": "fitnessCenterHealthClubGym",
            "type": "Element",
        },
    )
    aquarium: list[Aquarium] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    food_service: list[FoodService] = field(
        default_factory=list,
        metadata={
            "name": "foodService",
            "type": "Element",
        },
    )
    restaurant: list[Restaurant] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    enclosed_mall: list[EnclosedMall] = field(
        default_factory=list,
        metadata={
            "name": "enclosedMall",
            "type": "Element",
        },
    )
    ice_curling_rink: list[IceCurlingRink] = field(
        default_factory=list,
        metadata={
            "name": "iceCurlingRink",
            "type": "Element",
        },
    )
    adult_education: list[AdultEducation] = field(
        default_factory=list,
        metadata={
            "name": "adultEducation",
            "type": "Element",
        },
    )
    other_entertainment_public_assembly: list[OtherEntertainmentPublicAssembly] = field(
        default_factory=list,
        metadata={
            "name": "otherEntertainmentPublicAssembly",
            "type": "Element",
        },
    )
    movie_theater: list[MovieTheater] = field(
        default_factory=list,
        metadata={
            "name": "movieTheater",
            "type": "Element",
        },
    )
    transportation_terminal_station: list[TransportationTerminalStation] = field(
        default_factory=list,
        metadata={
            "name": "transportationTerminalStation",
            "type": "Element",
        },
    )
    vocational_school: list[VocationalSchool] = field(
        default_factory=list,
        metadata={
            "name": "vocationalSchool",
            "type": "Element",
        },
    )
    community_center_and_social_meeting_hall: list[CommunityCenterAndSocialMeetingHall] = field(
        default_factory=list,
        metadata={
            "name": "communityCenterAndSocialMeetingHall",
            "type": "Element",
        },
    )
    other_mall: list[OtherMall] = field(
        default_factory=list,
        metadata={
            "name": "otherMall",
            "type": "Element",
        },
    )
    convenience_store_with_gas_station: list[ConvenienceStoreWithGasStation] = field(
        default_factory=list,
        metadata={
            "name": "convenienceStoreWithGasStation",
            "type": "Element",
        },
    )
    other: list[Other] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    electric_vehicle_charging_station: list[ElectricVehicleChargingStation] = field(
        default_factory=list,
        metadata={
            "name": "electricVehicleChargingStation",
            "type": "Element",
        },
    )
