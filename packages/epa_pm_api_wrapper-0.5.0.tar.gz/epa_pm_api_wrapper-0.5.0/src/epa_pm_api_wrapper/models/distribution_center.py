from __future__ import annotations

from dataclasses import dataclass

from .distribution_center_type import DistributionCenterType


@dataclass(kw_only=True)
class DistributionCenter(DistributionCenterType):
    """
    Unrefrigerated Buildings that are used for the temporary storage and
    redistribution of goods, manufactured products, merchandise or raw
    materials.
    """

    class Meta:
        name = "distributionCenter"
