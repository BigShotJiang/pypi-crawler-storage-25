from __future__ import annotations

from dataclasses import dataclass, field

from .hotel_type_use_details import HotelTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class HotelType:
    """
    This xml type represents a property use type.

    If an element is missing it will be populated with a default value.
    """

    class Meta:
        name = "hotelType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: HotelTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
