from __future__ import annotations

from dataclasses import dataclass, field

from .amount_of_laundry_processed_annually import (
    AmountOfLaundryProcessedAnnually,
)
from .cooking_facilities import CookingFacilities
from .full_service_spa_floor_area import FullServiceSpaFloorArea
from .gross_floor_area_hotel_conference_space import (
    GrossFloorAreaHotelConferenceSpace,
)
from .gross_floor_area_used_for_food_preparation import (
    GrossFloorAreaUsedForFoodPreparation,
)
from .gym_center_floor_area import GymCenterFloorArea
from .hours_per_day_guests_onsite import HoursPerDayGuestsOnsite
from .laundry_facility import LaundryFacility
from .number_of_commercial_refrigeration_units import (
    NumberOfCommercialRefrigerationUnits,
)
from .number_of_guest_meals_served_per_year import (
    NumberOfGuestMealsServedPerYear,
)
from .number_of_hotel_rooms import NumberOfHotelRooms
from .number_of_workers import NumberOfWorkers
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .total_gross_floor_area import TotalGrossFloorArea


@dataclass(kw_only=True)
class HotelTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    full_service_spa_floor_area: None | FullServiceSpaFloorArea = field(
        default=None,
        metadata={
            "name": "fullServiceSpaFloorArea",
            "type": "Element",
        },
    )
    gym_center_floor_area: None | GymCenterFloorArea = field(
        default=None,
        metadata={
            "name": "gymCenterFloorArea",
            "type": "Element",
        },
    )
    hours_per_day_guests_onsite: None | HoursPerDayGuestsOnsite = field(
        default=None,
        metadata={
            "name": "hoursPerDayGuestsOnsite",
            "type": "Element",
        },
    )
    number_of_commercial_refrigeration_units: None | NumberOfCommercialRefrigerationUnits = field(
        default=None,
        metadata={
            "name": "numberOfCommercialRefrigerationUnits",
            "type": "Element",
        },
    )
    number_of_guest_meals_served_per_year: None | NumberOfGuestMealsServedPerYear = field(
        default=None,
        metadata={
            "name": "numberOfGuestMealsServedPerYear",
            "type": "Element",
        },
    )
    number_of_hotel_rooms: None | NumberOfHotelRooms = field(
        default=None,
        metadata={
            "name": "numberOfHotelRooms",
            "type": "Element",
        },
    )
    laundry_facility: None | LaundryFacility = field(
        default=None,
        metadata={
            "name": "laundryFacility",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    cooking_facilities: None | CookingFacilities = field(
        default=None,
        metadata={
            "name": "cookingFacilities",
            "type": "Element",
        },
    )
    amount_of_laundry_processed_annually: None | AmountOfLaundryProcessedAnnually = field(
        default=None,
        metadata={
            "name": "amountOfLaundryProcessedAnnually",
            "type": "Element",
        },
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    gross_floor_area_used_for_food_preparation: None | GrossFloorAreaUsedForFoodPreparation = field(
        default=None,
        metadata={
            "name": "grossFloorAreaUsedForFoodPreparation",
            "type": "Element",
        },
    )
    gross_floor_area_hotel_conference_space: None | GrossFloorAreaHotelConferenceSpace = field(
        default=None,
        metadata={
            "name": "grossFloorAreaHotelConferenceSpace",
            "type": "Element",
        },
    )
