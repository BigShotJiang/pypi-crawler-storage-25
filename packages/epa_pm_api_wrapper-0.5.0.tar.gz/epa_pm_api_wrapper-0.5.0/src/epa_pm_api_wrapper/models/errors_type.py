from __future__ import annotations

from dataclasses import dataclass, field

from .error_type import ErrorType


@dataclass(kw_only=True)
class ErrorsType:
    """
    A list of errors that caused this request to fail.

    :ivar error: The error of the web service call.
    """

    class Meta:
        name = "errorsType"

    error: list[ErrorType] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
