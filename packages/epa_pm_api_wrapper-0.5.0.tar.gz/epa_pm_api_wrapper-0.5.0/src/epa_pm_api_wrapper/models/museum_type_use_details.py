from __future__ import annotations

from dataclasses import dataclass, field

from .gross_floor_area_that_is_exhibit_space import (
    GrossFloorAreaThatIsExhibitSpace,
)
from .number_of_computers import NumberOfComputers
from .number_of_workers import NumberOfWorkers
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .precision_controls_for_temperature_and_humidity import (
    PrecisionControlsForTemperatureAndHumidity,
)
from .total_gross_floor_area import TotalGrossFloorArea
from .weekly_operating_hours import WeeklyOperatingHours


@dataclass(kw_only=True)
class MuseumTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    precision_controls_for_temperature_and_humidity: None | PrecisionControlsForTemperatureAndHumidity = field(
        default=None,
        metadata={
            "name": "precisionControlsForTemperatureAndHumidity",
            "type": "Element",
        },
    )
    gross_floor_area_that_is_exhibit_space: None | GrossFloorAreaThatIsExhibitSpace = field(
        default=None,
        metadata={
            "name": "grossFloorAreaThatIsExhibitSpace",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
    weekly_operating_hours: None | WeeklyOperatingHours = field(
        default=None,
        metadata={
            "name": "weeklyOperatingHours",
            "type": "Element",
        },
    )
