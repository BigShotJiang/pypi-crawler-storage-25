from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfPeople(UseIntegerType):
    """
    Number of people living in the home.
    """

    class Meta:
        name = "numberOfPeople"
