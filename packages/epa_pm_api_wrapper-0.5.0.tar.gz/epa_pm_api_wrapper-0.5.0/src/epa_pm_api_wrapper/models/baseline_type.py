from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlPeriod

from .system_determined_string import SystemDeterminedString


@dataclass(kw_only=True)
class BaselineType:
    """
    :ivar energy_baseline_date: The baseline date used for your
        property's energy consumption.  Must be in the format of YYYY-MM
        or "System Determined" to indicate for Portfolio Manager to
        automatically calculate the baseline date.
    :ivar water_baseline_date: The baseline date used for your
        property's water consumption.  Must be in the format of YYYY-MM
        or "System Determined" to indicate for Portfolio Manager to
        automatically calculate the baseline date.
    """

    class Meta:
        name = "baselineType"

    energy_baseline_date: None | SystemDeterminedString | XmlPeriod = field(
        default=None,
        metadata={
            "name": "energyBaselineDate",
            "type": "Element",
            "namespace": "",
        },
    )
    water_baseline_date: None | SystemDeterminedString | XmlPeriod = field(
        default=None,
        metadata={
            "name": "waterBaselineDate",
            "type": "Element",
            "namespace": "",
        },
    )
