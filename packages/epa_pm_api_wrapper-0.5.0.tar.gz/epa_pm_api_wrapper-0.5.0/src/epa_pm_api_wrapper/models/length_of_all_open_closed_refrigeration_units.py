from __future__ import annotations

from dataclasses import dataclass

from .length_of_use_detail_type import LengthOfUseDetailType


@dataclass(kw_only=True)
class LengthOfAllOpenClosedRefrigerationUnits(LengthOfUseDetailType):
    """
    Length of all open or closed Refrigeration or Freezer cases that are
    used for the sale or storage of perishable goods.

    Include display-type refrigerated open or closed cases and cabinets, as
    well as display-type freezer units. These are typically found on the
    sales floor. See numberOfOpenClosedRefrigerationUnits for more
    information.
    """

    class Meta:
        name = "lengthOfAllOpenClosedRefrigerationUnits"
