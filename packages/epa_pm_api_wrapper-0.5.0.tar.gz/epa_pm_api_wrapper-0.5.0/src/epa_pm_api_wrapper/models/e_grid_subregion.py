from __future__ import annotations

from dataclasses import dataclass, field

from .e_grid_subregion_country import EGridSubregionCountry


@dataclass(kw_only=True)
class EGridSubregion:
    """
    Electric Distribution Utility Information.

    :ivar code: The code of the eGrid Subregion.
    :ivar name: The name of the eGrid Subregion.
    :ivar country: The country in which the eGrid Subregion is located.
    """

    class Meta:
        name = "eGridSubregion"

    code: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    country: None | EGridSubregionCountry = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
