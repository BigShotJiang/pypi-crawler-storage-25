from __future__ import annotations

from enum import Enum


class AmountOfLaundryProcessedAnnuallyUnitsType(Enum):
    POUNDS = "pounds"
    KILOGRAM = "Kilogram"
    SHORT_TONS = "short tons"
