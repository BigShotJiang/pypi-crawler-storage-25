from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class AverageNumberOfResidents(UseDecimalType):
    """
    Annual average number of residents at the property.
    """

    class Meta:
        name = "averageNumberOfResidents"
