from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .empty_string import EmptyString
from .irrigation_area_type_base import IrrigationAreaTypeBase


@dataclass(kw_only=True)
class IrrigationAreaType(IrrigationAreaTypeBase):
    """
    Irrigated area is the amount of outdoor vegetated area that is supplied
    water regularly, measured in square feet, square meters, or acres.
    """

    class Meta:
        name = "irrigationAreaType"

    value: None | Decimal | EmptyString = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": Decimal("0"),
            "fraction_digits": 2,
        },
    )
