from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class CookingFacilities(UseYesNoType):
    """
    Whether there are Cooking Facilities.
    """

    class Meta:
        name = "cookingFacilities"
