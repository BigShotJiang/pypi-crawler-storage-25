from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfRooms(UseDecimalType):
    """
    Total number of rooms for a lodging type of property (hotel, dormitory,
    etc).
    """

    class Meta:
        name = "numberOfRooms"
