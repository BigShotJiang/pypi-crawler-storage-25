from __future__ import annotations

from dataclasses import dataclass

from .pool_size_type import PoolSizeType


@dataclass(kw_only=True)
class PoolSize(PoolSizeType):
    """
    Approximate size of a swimming pool (Short Course, Recreational,
    Olympic).
    """

    class Meta:
        name = "poolSize"
