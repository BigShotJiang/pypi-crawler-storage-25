from __future__ import annotations

from enum import Enum


class GrossFloorAreaUnitsType(Enum):
    SQUARE_FEET = "Square Feet"
    SQUARE_METERS = "Square Meters"
