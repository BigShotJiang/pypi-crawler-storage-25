from __future__ import annotations

from dataclasses import dataclass, field

from .data_type import DataType


@dataclass(kw_only=True)
class BillboardMetricType:
    """
    Settings to your billboard metric.

    :ivar name: The name of the metric.
    :ivar data_type: The data type of the value for the metric (i.e.,
        string, numeric, date).
    """

    class Meta:
        name = "billboardMetricType"

    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    data_type: None | DataType = field(
        default=None,
        metadata={
            "name": "dataType",
            "type": "Attribute",
        },
    )
