from __future__ import annotations

from dataclasses import dataclass

from .owned_by_type import OwnedByType


@dataclass(kw_only=True)
class OwnedBy(OwnedByType):
    """
    Indication of whether the property is owned by a private, not-for
    profit, or government organization.
    """

    class Meta:
        name = "ownedBy"
