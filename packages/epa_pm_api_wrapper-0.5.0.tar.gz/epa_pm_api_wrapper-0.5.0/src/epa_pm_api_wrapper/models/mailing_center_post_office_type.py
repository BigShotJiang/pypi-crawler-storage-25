from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .mailing_center_post_office_type_use_details import (
    MailingCenterPostOfficeTypeUseDetails,
)


@dataclass(kw_only=True)
class MailingCenterPostOfficeType:
    class Meta:
        name = "mailingCenterPostOfficeType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: MailingCenterPostOfficeTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
