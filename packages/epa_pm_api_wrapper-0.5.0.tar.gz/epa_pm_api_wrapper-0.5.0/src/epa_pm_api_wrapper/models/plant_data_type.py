from __future__ import annotations

from dataclasses import dataclass, field

from .plant_data_type_value import PlantDataTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class PlantDataType(UseAttributeBase):
    class Meta:
        name = "plantDataType"

    value: None | PlantDataTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    text_value: None | str = field(
        default=None,
        metadata={
            "name": "textValue",
            "type": "Element",
            "namespace": "",
        },
    )
