from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlDate

from .generation_location_type import GenerationLocationType
from .green_power_type_enum import GreenPowerTypeEnum
from .log_type import LogType
from .offsite_green_power_purchase_type_amount_purchased import (
    OffsiteGreenPowerPurchaseTypeAmountPurchased,
)
from .offsite_green_power_purchase_type_cost import (
    OffsiteGreenPowerPurchaseTypeCost,
)
from .offsite_green_power_purchase_type_fuel_sources import (
    OffsiteGreenPowerPurchaseTypeFuelSources,
)
from .offsite_green_power_purchase_type_rated_capacity import (
    OffsiteGreenPowerPurchaseTypeRatedCapacity,
)
from .offsite_green_power_purchase_type_renewable_generation_technologies import (
    OffsiteGreenPowerPurchaseTypeRenewableGenerationTechnologies,
)


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchaseType:
    """
    :ivar id: The id of the offsite green power purchase.
    :ivar rec_owned_and_retired: You must own and retire the RECs (or
        have them retired on your behalf) for them to count as green
        power in Portfolio Manager.
    :ivar start_date: The start date of the offsite green power
        purchase.
    :ivar end_date: The end date of the offsite green power purchase.
    :ivar amount_purchased:
    :ivar estimate: Flag to indicate if any of the amount purchased is
        estimate.
    :ivar generation_location: The location (power plant, eGrid
        subregion, or unknown) of where the green power was generated.
    :ivar type_value: The green power type of the offsite green power
        purchase.
    :ivar meet_vintage_requirement: You must attest that the unbundled
        RECs meet the vintage requirement when type is Unbundled RECs.
    :ivar certified_by_greene: Flag indicate whether this green power is
        certified by Green-e.
    :ivar provider: The green power provider/project owner.
    :ivar facility_name: The generation facility name.
    :ivar fuel_sources: The green power fuel sources.
    :ivar renewable_generation_technologies: The Renewable Generation
        Technology types.
    :ivar rated_capacity: The rated capacity of project/offtake.
    :ivar operation_date: The commercial operation date.
    :ivar contract_start_date: The contract start date.
    :ivar contract_end_date: The contract start date.
    :ivar cost: The cost of Green Power purchase.
    :ivar notes: Any other information about this purchase.
    :ivar audit:
    """

    class Meta:
        name = "offsiteGreenPowerPurchaseType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    rec_owned_and_retired: bool = field(
        metadata={
            "name": "recOwnedAndRetired",
            "type": "Element",
            "namespace": "",
        }
    )
    start_date: XmlDate = field(
        metadata={
            "name": "startDate",
            "type": "Element",
            "namespace": "",
        }
    )
    end_date: XmlDate = field(
        metadata={
            "name": "endDate",
            "type": "Element",
            "namespace": "",
        }
    )
    amount_purchased: OffsiteGreenPowerPurchaseTypeAmountPurchased = field(
        metadata={
            "name": "amountPurchased",
            "type": "Element",
            "namespace": "",
        }
    )
    estimate: bool = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    generation_location: GenerationLocationType = field(
        metadata={
            "name": "generationLocation",
            "type": "Element",
            "namespace": "",
        }
    )
    type_value: GreenPowerTypeEnum = field(
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "",
        }
    )
    meet_vintage_requirement: None | bool = field(
        default=None,
        metadata={
            "name": "meetVintageRequirement",
            "type": "Element",
            "namespace": "",
        },
    )
    certified_by_greene: bool = field(
        metadata={
            "name": "certifiedByGreene",
            "type": "Element",
            "namespace": "",
        }
    )
    provider: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        },
    )
    facility_name: None | str = field(
        default=None,
        metadata={
            "name": "facilityName",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        },
    )
    fuel_sources: None | OffsiteGreenPowerPurchaseTypeFuelSources = field(
        default=None,
        metadata={
            "name": "fuelSources",
            "type": "Element",
            "namespace": "",
        },
    )
    renewable_generation_technologies: None | OffsiteGreenPowerPurchaseTypeRenewableGenerationTechnologies = field(
        default=None,
        metadata={
            "name": "renewableGenerationTechnologies",
            "type": "Element",
            "namespace": "",
        },
    )
    rated_capacity: None | OffsiteGreenPowerPurchaseTypeRatedCapacity = field(
        default=None,
        metadata={
            "name": "ratedCapacity",
            "type": "Element",
            "namespace": "",
        },
    )
    operation_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "operationDate",
            "type": "Element",
            "namespace": "",
        },
    )
    contract_start_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "contractStartDate",
            "type": "Element",
            "namespace": "",
        },
    )
    contract_end_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "contractEndDate",
            "type": "Element",
            "namespace": "",
        },
    )
    cost: None | OffsiteGreenPowerPurchaseTypeCost = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    notes: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 4000,
        },
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
