from __future__ import annotations

from dataclasses import dataclass, field

from .cooling_equipment_redundancy_type_value import (
    CoolingEquipmentRedundancyTypeValue,
)
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class CoolingEquipmentRedundancyType(UseAttributeBase):
    class Meta:
        name = "coolingEquipmentRedundancyType"

    value: None | CoolingEquipmentRedundancyTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
