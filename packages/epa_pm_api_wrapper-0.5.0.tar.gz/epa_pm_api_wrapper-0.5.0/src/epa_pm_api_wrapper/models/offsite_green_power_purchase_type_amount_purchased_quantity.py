from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .energy_uom_type import EnergyUomType


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchaseTypeAmountPurchasedQuantity:
    """
    :ivar amount: The amount purchased.
    :ivar uom: The unit of measure of the amount purchased.
    """

    class Meta:
        global_type = False

    amount: Decimal = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": Decimal("0.1"),
            "fraction_digits": 1,
        }
    )
    uom: EnergyUomType = field(
        metadata={
            "type": "Attribute",
        }
    )
