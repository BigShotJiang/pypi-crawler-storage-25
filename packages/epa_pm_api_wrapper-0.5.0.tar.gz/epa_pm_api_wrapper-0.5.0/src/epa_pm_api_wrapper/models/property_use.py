from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class PropertyUse:
    """
    This is used to update property use name only.
    """

    class Meta:
        name = "propertyUse"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
