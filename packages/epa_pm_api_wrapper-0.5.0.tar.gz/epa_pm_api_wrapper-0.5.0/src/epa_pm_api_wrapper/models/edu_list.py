from __future__ import annotations

from dataclasses import dataclass, field

from .edu import Edu


@dataclass(kw_only=True)
class EduList:
    class Meta:
        name = "eduList"

    edu: list[Edu] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
