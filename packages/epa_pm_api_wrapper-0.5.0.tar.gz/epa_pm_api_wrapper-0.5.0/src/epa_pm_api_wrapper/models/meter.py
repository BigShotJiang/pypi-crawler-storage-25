from __future__ import annotations

from dataclasses import dataclass

from .meter_type import MeterType


@dataclass(kw_only=True)
class Meter(MeterType):
    class Meta:
        name = "meter"
