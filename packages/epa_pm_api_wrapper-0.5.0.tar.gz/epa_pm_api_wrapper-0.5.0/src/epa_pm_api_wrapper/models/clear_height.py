from __future__ import annotations

from dataclasses import dataclass

from .clear_height_units_type import ClearHeightUnitsType


@dataclass(kw_only=True)
class ClearHeight(ClearHeightUnitsType):
    """
    The distance measured from the floor to the lowest overhead obstruction
    for the majority of the warehouse space.
    """

    class Meta:
        name = "clearHeight"
