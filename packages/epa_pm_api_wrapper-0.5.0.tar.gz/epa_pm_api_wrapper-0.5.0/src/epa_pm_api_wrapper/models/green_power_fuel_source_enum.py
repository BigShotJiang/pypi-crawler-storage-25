from __future__ import annotations

from enum import Enum


class GreenPowerFuelSourceEnum(Enum):
    BIOGAS = "Biogas"
    BIOMASS = "Biomass"
    GEOTHERMAL = "Geothermal"
    SMALL_HYDROPOWER = "Small Hydropower"
    SOLAR = "Solar"
    WIND = "Wind"
    OTHER = "Other"
