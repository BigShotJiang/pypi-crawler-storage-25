from __future__ import annotations

from dataclasses import dataclass, field

from .bank_branch_type_use_details import BankBranchTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class BankBranchType:
    class Meta:
        name = "bankBranchType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: BankBranchTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
