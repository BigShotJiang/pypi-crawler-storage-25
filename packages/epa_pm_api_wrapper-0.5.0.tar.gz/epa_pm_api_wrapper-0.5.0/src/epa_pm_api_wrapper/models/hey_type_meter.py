from __future__ import annotations

from dataclasses import dataclass, field

from .all_energy_meters_type import AllEnergyMetersType
from .design_unit_of_measure import DesignUnitOfMeasure
from .hey_type_meter_meter_data import HeyTypeMeterMeterData


@dataclass(kw_only=True)
class HeyTypeMeter:
    class Meta:
        global_type = False

    type_value: AllEnergyMetersType = field(
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "",
        }
    )
    unit_of_measure: DesignUnitOfMeasure = field(
        metadata={
            "name": "unitOfMeasure",
            "type": "Element",
            "namespace": "",
        }
    )
    meter_data: HeyTypeMeterMeterData = field(
        metadata={
            "name": "meterData",
            "type": "Element",
            "namespace": "",
        }
    )
