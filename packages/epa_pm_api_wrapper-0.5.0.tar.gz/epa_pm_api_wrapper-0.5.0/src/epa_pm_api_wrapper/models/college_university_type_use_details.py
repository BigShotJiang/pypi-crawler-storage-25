from __future__ import annotations

from dataclasses import dataclass, field

from .annual_research_expenditure import AnnualResearchExpenditure
from .enrollment import Enrollment
from .grant_dollars import GrantDollars
from .highest_award_level import HighestAwardLevel
from .number_of_computers import NumberOfComputers
from .number_of_fteworkers import NumberOfFteworkers
from .number_of_full_time_students_enrolled_january_to_april import (
    NumberOfFullTimeStudentsEnrolledJanuaryToApril,
)
from .number_of_full_time_students_enrolled_may_to_august import (
    NumberOfFullTimeStudentsEnrolledMayToAugust,
)
from .number_of_full_time_students_enrolled_september_to_december import (
    NumberOfFullTimeStudentsEnrolledSeptemberToDecember,
)
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .percent_of_lab_floor_area import PercentOfLabFloorArea
from .total_gross_floor_area import TotalGrossFloorArea
from .weekly_operating_hours import WeeklyOperatingHours


@dataclass(kw_only=True)
class CollegeUniversityTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    number_of_full_time_students_enrolled_september_to_december: (
        None | NumberOfFullTimeStudentsEnrolledSeptemberToDecember
    ) = field(
        default=None,
        metadata={
            "name": "numberOfFullTimeStudentsEnrolledSeptemberToDecember",
            "type": "Element",
        },
    )
    number_of_full_time_students_enrolled_january_to_april: None | NumberOfFullTimeStudentsEnrolledJanuaryToApril = (
        field(
            default=None,
            metadata={
                "name": "numberOfFullTimeStudentsEnrolledJanuaryToApril",
                "type": "Element",
            },
        )
    )
    number_of_full_time_students_enrolled_may_to_august: None | NumberOfFullTimeStudentsEnrolledMayToAugust = field(
        default=None,
        metadata={
            "name": "numberOfFullTimeStudentsEnrolledMayToAugust",
            "type": "Element",
        },
    )
    annual_research_expenditure: None | AnnualResearchExpenditure = field(
        default=None,
        metadata={
            "name": "annualResearchExpenditure",
            "type": "Element",
        },
    )
    percent_of_lab_floor_area: None | PercentOfLabFloorArea = field(
        default=None,
        metadata={
            "name": "percentOfLabFloorArea",
            "type": "Element",
        },
    )
    highest_award_level: None | HighestAwardLevel = field(
        default=None,
        metadata={
            "name": "highestAwardLevel",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    weekly_operating_hours: None | WeeklyOperatingHours = field(
        default=None,
        metadata={
            "name": "weeklyOperatingHours",
            "type": "Element",
        },
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
    enrollment: None | Enrollment = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    grant_dollars: None | GrantDollars = field(
        default=None,
        metadata={
            "name": "grantDollars",
            "type": "Element",
        },
    )
    number_of_fteworkers: None | NumberOfFteworkers = field(
        default=None,
        metadata={
            "name": "numberOfFTEWorkers",
            "type": "Element",
        },
    )
