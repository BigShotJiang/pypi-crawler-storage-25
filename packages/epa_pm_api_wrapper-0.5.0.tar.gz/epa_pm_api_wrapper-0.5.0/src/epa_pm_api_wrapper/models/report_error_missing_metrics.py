from __future__ import annotations

from dataclasses import dataclass, field

from .report_error_missing_metrics_property_missing_metric import (
    ReportErrorMissingMetricsPropertyMissingMetric,
)


@dataclass(kw_only=True)
class ReportErrorMissingMetrics:
    class Meta:
        global_type = False

    property_missing_metric: list[ReportErrorMissingMetricsPropertyMissingMetric] = field(
        default_factory=list,
        metadata={
            "name": "propertyMissingMetric",
            "type": "Element",
        },
    )
