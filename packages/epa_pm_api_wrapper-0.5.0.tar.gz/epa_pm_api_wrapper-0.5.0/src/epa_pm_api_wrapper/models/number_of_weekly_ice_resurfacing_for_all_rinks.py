from __future__ import annotations

from dataclasses import dataclass

from .number_of_weekly_ice_resurfacing_type import (
    NumberOfWeeklyIceResurfacingType,
)


@dataclass(kw_only=True)
class NumberOfWeeklyIceResurfacingForAllRinks(NumberOfWeeklyIceResurfacingType):
    """
    Total number of floods in a week using ice resurfacing machines after
    typical ice rink use for all indoor hockey, ringette, public or figure
    skating ice rinks in the facility.

    This does not include curling sheet resurfacing or pebbling. For
    multiple rinks, sum the total number of weekly resurfacing for all
    rinks.
    """

    class Meta:
        name = "numberOfWeeklyIceResurfacingForAllRinks"
