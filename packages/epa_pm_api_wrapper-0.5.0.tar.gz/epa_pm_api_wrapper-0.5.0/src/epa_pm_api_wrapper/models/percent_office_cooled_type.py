from __future__ import annotations

from dataclasses import dataclass, field

from .percent_office_cooled_type_value import PercentOfficeCooledTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class PercentOfficeCooledType(UseAttributeBase):
    class Meta:
        name = "percentOfficeCooledType"

    value: None | PercentOfficeCooledTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
