from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class AmbulatorySurgicalCenter(OtherType):
    """
    Health care facilities that provide same-day surgical care, including
    diagnostic and preventive procedures.
    """

    class Meta:
        name = "ambulatorySurgicalCenter"
