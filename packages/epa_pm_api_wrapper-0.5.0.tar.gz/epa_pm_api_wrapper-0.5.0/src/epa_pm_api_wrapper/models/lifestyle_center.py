from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class LifestyleCenter(OtherType):
    """
    A mixed use commercial development that includes retail stores and
    leisure amenities, where individual retail stores typically contain an
    entrance accessible from the outside and are not connected by internal
    walkways.
    """

    class Meta:
        name = "lifestyleCenter"
