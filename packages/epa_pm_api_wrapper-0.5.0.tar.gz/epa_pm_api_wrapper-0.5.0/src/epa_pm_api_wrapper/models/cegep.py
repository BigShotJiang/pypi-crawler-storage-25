from __future__ import annotations

from dataclasses import dataclass

from .cegep_type import CegepType


@dataclass(kw_only=True)
class Cegep(CegepType):
    """
    A college that is unique to Quebec’s education system.
    """

    class Meta:
        name = "cegep"
