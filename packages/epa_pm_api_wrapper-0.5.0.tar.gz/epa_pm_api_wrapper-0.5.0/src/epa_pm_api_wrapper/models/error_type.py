from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class ErrorType:
    """
    :ivar error_number: The number of the error.
    :ivar error_description: The description of the error.
    """

    class Meta:
        name = "errorType"

    error_number: None | str = field(
        default=None,
        metadata={
            "name": "errorNumber",
            "type": "Attribute",
        },
    )
    error_description: None | str = field(
        default=None,
        metadata={
            "name": "errorDescription",
            "type": "Attribute",
        },
    )
