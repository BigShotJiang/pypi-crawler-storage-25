from __future__ import annotations

from dataclasses import dataclass

from .office_type import OfficeType


@dataclass(kw_only=True)
class Office(OfficeType):
    """
    Buildings used for the conduct of commercial or governmental business
    activities.
    """

    class Meta:
        name = "office"
