from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .plant_design_flow_rate_units_type import PlantDesignFlowRateUnitsType
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class PlantDesignFlowRateType(UseAttributeBase):
    value: Decimal = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    units: PlantDesignFlowRateUnitsType = field(
        metadata={
            "type": "Attribute",
        }
    )
