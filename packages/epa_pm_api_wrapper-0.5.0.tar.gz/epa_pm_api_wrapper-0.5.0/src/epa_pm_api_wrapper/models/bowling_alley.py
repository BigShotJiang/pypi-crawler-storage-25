from __future__ import annotations

from dataclasses import dataclass, field

from .bowling_alley_use_details import BowlingAlleyUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class BowlingAlley:
    """
    Buildings used for public or private, recreational or professional
    bowling.
    """

    class Meta:
        name = "bowlingAlley"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: BowlingAlleyUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
