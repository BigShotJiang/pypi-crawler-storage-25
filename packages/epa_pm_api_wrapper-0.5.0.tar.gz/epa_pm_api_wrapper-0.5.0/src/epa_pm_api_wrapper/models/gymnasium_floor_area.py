from __future__ import annotations

from dataclasses import dataclass

from .optional_floor_area_type import OptionalFloorAreaType


@dataclass(kw_only=True)
class GymnasiumFloorArea(OptionalFloorAreaType):
    """
    Floor area associated with a gymnasium at a K12 School.
    """

    class Meta:
        name = "gymnasiumFloorArea"
