from __future__ import annotations

from dataclasses import dataclass, field

from .highest_award_level_type_value import HighestAwardLevelTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class HighestAwardLevelType(UseAttributeBase):
    class Meta:
        name = "highestAwardLevelType"

    value: None | HighestAwardLevelTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
