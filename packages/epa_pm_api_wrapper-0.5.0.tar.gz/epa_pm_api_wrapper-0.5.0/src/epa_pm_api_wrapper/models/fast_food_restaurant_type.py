from __future__ import annotations

from dataclasses import dataclass, field

from .fast_food_restaurant_type_use_details import (
    FastFoodRestaurantTypeUseDetails,
)
from .log_type import LogType


@dataclass(kw_only=True)
class FastFoodRestaurantType:
    class Meta:
        name = "fastFoodRestaurantType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: FastFoodRestaurantTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
