from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class HasLaboratory(UseYesNoType):
    """
    Presence of a laboratory (Yes/No).
    """

    class Meta:
        name = "hasLaboratory"
