from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class DataResponseProperties:
    """
    :ivar id: The unique identifier for each property.
    """

    class Meta:
        global_type = False

    id: list[int] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
