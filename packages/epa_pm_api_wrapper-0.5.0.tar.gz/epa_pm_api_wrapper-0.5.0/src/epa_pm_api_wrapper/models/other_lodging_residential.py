from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherLodgingResidential(OtherType):
    """
    Buildings used for residential purposes other than those described in
    the available property uses in Portfolio Manager (i.e. residential
    other than multifamily residential, single family home, senior care
    community, residence hall/dormitory, barracks, prison/incarceration, or
    hotel).
    """

    class Meta:
        name = "otherLodgingResidential"
