from __future__ import annotations

from dataclasses import dataclass

from .ice_curling_rink_type import IceCurlingRinkType


@dataclass(kw_only=True)
class IceCurlingRink(IceCurlingRinkType):
    """
    Buildings that include one or more indoor ice sheets used for public or
    private, recreational or professional skating, hockey, or ringette.

    Buildings that are exclusively used for curling are not currently
    eligible to earn an ENERGY STAR score but can be benchmarked using this
    property use. Gross Floor Area should include all space within the
    building(s), including ice area, spectator areas, concession stands,
    restaurants, retail areas, locker rooms, administrative/office areas,
    employee break rooms, mechanical rooms, and storage areas.Larger
    facilities primarily serving professional or collegiate functions and
    with significant spectator seating (usually above 5,000 seats) should
    review the definition for Indoor Arena to determine the best
    classification.
    """

    class Meta:
        name = "iceCurlingRink"
