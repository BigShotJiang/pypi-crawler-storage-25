from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfResidentialWashingMachines(UseDecimalType):
    """
    Number of residential-type washing machines.
    """

    class Meta:
        name = "numberOfResidentialWashingMachines"
