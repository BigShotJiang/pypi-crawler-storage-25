from __future__ import annotations

from dataclasses import dataclass

from .barracks_type import BarracksType


@dataclass(kw_only=True)
class Barracks(BarracksType):
    """
    Residential buildings associated with military facilities or
    educational institutions which offer multiple accommodations for
    long-term residents.
    """

    class Meta:
        name = "barracks"
