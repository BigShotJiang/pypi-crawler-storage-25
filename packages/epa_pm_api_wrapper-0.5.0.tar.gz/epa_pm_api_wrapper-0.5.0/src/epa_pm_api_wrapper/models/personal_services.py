from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class PersonalServices(OtherType):
    """
    Buildings used to sell services rather than physical goods.

    Examples include dry cleaners, salons, spas, etc.
    """

    class Meta:
        name = "personalServices"
