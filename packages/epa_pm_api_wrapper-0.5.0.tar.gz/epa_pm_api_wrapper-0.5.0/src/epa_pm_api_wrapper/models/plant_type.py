from __future__ import annotations

from dataclasses import dataclass

from .plant_data_type import PlantDataType


@dataclass(kw_only=True)
class PlantType(PlantDataType):
    """
    Buildings used for manufacturing or assembling goods.

    Includes the plant type and sub type classification (if any).
    """

    class Meta:
        name = "plantType"
