from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class MaximumNumberOfFloors(UseIntegerType):
    """
    Maximum number of floors in the tallest building at the property.
    """

    class Meta:
        name = "maximumNumberOfFloors"
