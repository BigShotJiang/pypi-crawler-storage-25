from __future__ import annotations

from dataclasses import dataclass

from .museum_type import MuseumType


@dataclass(kw_only=True)
class Museum(MuseumType):
    """
    Museum refers to buildings that display collections to outside visitors
    for public viewing and enjoyment and for informational/educational
    purposes. <br xmlns=""/> <br xmlns=""/> Gross Floor Area should
    include all space within the building(s), including but not limited to
    public collection display areas, meeting rooms, restrooms, classrooms,
    gift shops, food service areas, administrative/office space, mechanical
    rooms, storage areas for collections, libraries, elevator shafts,
    stairwells, and movie theatre space inside the museum.

    Areas not in enclosed building such as outdoor exhibit, open-air
    theaters, walkways, and landscaped areas should not be included in the
    Gross Floor Area.
    """

    class Meta:
        name = "museum"
