from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfHotelRooms(UseDecimalType):
    """
    Total number of rooms for a lodging type of property (hotel).
    """

    class Meta:
        name = "numberOfHotelRooms"
