from __future__ import annotations

from dataclasses import dataclass

from .number_of_weekdays_type import NumberOfWeekdaysType


@dataclass(kw_only=True)
class NumberOfWeekdaysOpen(NumberOfWeekdaysType):
    """
    Number of weekdays (Monday through Friday) the property is open.

    This will be an number between 0 and 5.
    """

    class Meta:
        name = "numberOfWeekdaysOpen"
