from __future__ import annotations

from dataclasses import dataclass

from .bank_branch_type import BankBranchType


@dataclass(kw_only=True)
class BankBranch(BankBranchType):
    """
    A commercial banking outlet that offers banking services to walk-in
    customers.
    """

    class Meta:
        name = "bankBranch"
