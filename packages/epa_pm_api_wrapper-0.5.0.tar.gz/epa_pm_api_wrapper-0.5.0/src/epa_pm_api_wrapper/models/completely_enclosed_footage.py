from __future__ import annotations

from dataclasses import dataclass

from .gross_floor_area_type import GrossFloorAreaType


@dataclass(kw_only=True)
class CompletelyEnclosedFootage(GrossFloorAreaType):
    """
    Area of parking garage that is completely enclosed.
    """

    class Meta:
        name = "completelyEnclosedFootage"
