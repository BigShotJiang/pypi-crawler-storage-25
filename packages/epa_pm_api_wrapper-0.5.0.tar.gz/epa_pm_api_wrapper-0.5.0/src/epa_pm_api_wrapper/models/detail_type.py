from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class DetailType:
    class Meta:
        name = "detailType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
