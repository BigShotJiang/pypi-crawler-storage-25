from __future__ import annotations

from dataclasses import dataclass

from .meter_delivery_type import MeterDeliveryType


@dataclass(kw_only=True)
class MeterDelivery(MeterDeliveryType):
    class Meta:
        name = "meterDelivery"
