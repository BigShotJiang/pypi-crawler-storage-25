from __future__ import annotations

from enum import Enum


class PerformanceTargetTypeTargetMetric(Enum):
    NO_TARGET = "No Target"
    TARGET_ENERGY_STAR_SCORE = "Target ENERGY STAR Score"
    TARGET_BETTER_THAN_BASELINE = "Target % Better than Baseline"
    TARGET_BETTER_THAN_MEDIAN = "Target % Better than Median"
