from __future__ import annotations

from dataclasses import dataclass, field

from .ev_charging_station_type_use_details import (
    EvChargingStationTypeUseDetails,
)
from .log_type import LogType


@dataclass(kw_only=True)
class EvChargingStationType:
    class Meta:
        name = "evChargingStationType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: EvChargingStationTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
