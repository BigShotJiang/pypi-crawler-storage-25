from __future__ import annotations

from dataclasses import dataclass, field

from .cooking_located_onsite import CookingLocatedOnsite
from .exterior_entrance_to_the_public import ExteriorEntranceToThePublic
from .length_of_all_commercial_kitchen_hoods import (
    LengthOfAllCommercialKitchenHoods,
)
from .number_of_computers import NumberOfComputers
from .number_of_workers import NumberOfWorkers
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .total_gross_floor_area import TotalGrossFloorArea
from .weekly_operating_hours import WeeklyOperatingHours


@dataclass(kw_only=True)
class FastFoodRestaurantTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    weekly_operating_hours: None | WeeklyOperatingHours = field(
        default=None,
        metadata={
            "name": "weeklyOperatingHours",
            "type": "Element",
        },
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
    cooking_located_onsite: None | CookingLocatedOnsite = field(
        default=None,
        metadata={
            "name": "cookingLocatedOnsite",
            "type": "Element",
        },
    )
    exterior_entrance_to_the_public: None | ExteriorEntranceToThePublic = field(
        default=None,
        metadata={
            "name": "exteriorEntranceToThePublic",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    length_of_all_commercial_kitchen_hoods: None | LengthOfAllCommercialKitchenHoods = field(
        default=None,
        metadata={
            "name": "lengthOfAllCommercialKitchenHoods",
            "type": "Element",
        },
    )
