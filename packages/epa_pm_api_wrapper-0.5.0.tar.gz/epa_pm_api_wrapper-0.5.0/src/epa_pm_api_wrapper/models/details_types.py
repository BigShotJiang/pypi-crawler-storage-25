from __future__ import annotations

from dataclasses import dataclass, field

from .detail_type import DetailType


@dataclass(kw_only=True)
class DetailsTypes:
    class Meta:
        name = "detailsTypes"

    detail_type: list[DetailType] = field(
        default_factory=list,
        metadata={
            "name": "detailType",
            "type": "Element",
            "min_occurs": 1,
        },
    )
