from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class EstimatesApplied(UseYesNoType):
    """
    Whether Data Center IT energy estimates are applied.
    """

    class Meta:
        name = "estimatesApplied"
