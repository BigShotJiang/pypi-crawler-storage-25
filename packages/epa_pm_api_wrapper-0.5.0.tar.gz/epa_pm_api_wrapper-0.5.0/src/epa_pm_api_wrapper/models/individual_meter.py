from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlDate

from .log_type import LogType


@dataclass(kw_only=True)
class IndividualMeter:
    """
    :ivar id: The id of the individual meter.
    :ivar meter_id: The id of the aggregated/parent meter.
    :ivar custom_id: Custom Id of the individual meter
    :ivar custom_id_name: Custom Id Name of the individual meter
    :ivar service_address: Service address of the individual meter
    :ivar in_use: Is this individual meter in use?
    :ivar inactive_date: If the individual meter is no longer in use,
        this is the date that it went inactive.
    :ivar audit:
    """

    class Meta:
        name = "individualMeter"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    meter_id: None | int = field(
        default=None,
        metadata={
            "name": "meterId",
            "type": "Element",
        },
    )
    custom_id: None | str = field(
        default=None,
        metadata={
            "name": "customId",
            "type": "Element",
            "min_length": 1,
            "max_length": 200,
        },
    )
    custom_id_name: None | str = field(
        default=None,
        metadata={
            "name": "customIdName",
            "type": "Element",
            "min_length": 1,
            "max_length": 200,
        },
    )
    service_address: None | str = field(
        default=None,
        metadata={
            "name": "serviceAddress",
            "type": "Element",
            "min_length": 1,
            "max_length": 400,
        },
    )
    in_use: None | bool = field(
        default=None,
        metadata={
            "name": "inUse",
            "type": "Element",
        },
    )
    inactive_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "inactiveDate",
            "type": "Element",
        },
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
