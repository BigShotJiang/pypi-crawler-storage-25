from __future__ import annotations

from dataclasses import dataclass

from .plant_design_flow_rate_type import PlantDesignFlowRateType


@dataclass(kw_only=True)
class PlantDesignFlowRate(PlantDesignFlowRateType):
    """
    The designed flow rate of a wastewater treatment plant (e.g. the
    capacity of the plant) in million gallons per day (MGD).
    """

    class Meta:
        name = "plantDesignFlowRate"
