from __future__ import annotations

from dataclasses import dataclass, field

from .enclosed_floor_area import EnclosedFloorArea
from .ice_events import IceEvents
from .number_of_computers import NumberOfComputers
from .number_of_concert_show_events_per_year import (
    NumberOfConcertShowEventsPerYear,
)
from .number_of_special_other_events_per_year import (
    NumberOfSpecialOtherEventsPerYear,
)
from .number_of_sporting_events_per_year import NumberOfSportingEventsPerYear
from .number_of_walk_in_refrigeration_units import (
    NumberOfWalkInRefrigerationUnits,
)
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .size_of_electronic_score_boards import SizeOfElectronicScoreBoards
from .total_gross_floor_area import TotalGrossFloorArea


@dataclass(kw_only=True)
class IndoorArenaTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    enclosed_floor_area: None | EnclosedFloorArea = field(
        default=None,
        metadata={
            "name": "enclosedFloorArea",
            "type": "Element",
        },
    )
    number_of_sporting_events_per_year: None | NumberOfSportingEventsPerYear = field(
        default=None,
        metadata={
            "name": "numberOfSportingEventsPerYear",
            "type": "Element",
        },
    )
    number_of_concert_show_events_per_year: None | NumberOfConcertShowEventsPerYear = field(
        default=None,
        metadata={
            "name": "numberOfConcertShowEventsPerYear",
            "type": "Element",
        },
    )
    number_of_special_other_events_per_year: None | NumberOfSpecialOtherEventsPerYear = field(
        default=None,
        metadata={
            "name": "numberOfSpecialOtherEventsPerYear",
            "type": "Element",
        },
    )
    size_of_electronic_score_boards: None | SizeOfElectronicScoreBoards = field(
        default=None,
        metadata={
            "name": "sizeOfElectronicScoreBoards",
            "type": "Element",
        },
    )
    ice_events: None | IceEvents = field(
        default=None,
        metadata={
            "name": "iceEvents",
            "type": "Element",
        },
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
    number_of_walk_in_refrigeration_units: None | NumberOfWalkInRefrigerationUnits = field(
        default=None,
        metadata={
            "name": "numberOfWalkInRefrigerationUnits",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
