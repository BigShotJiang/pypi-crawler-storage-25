from __future__ import annotations

from enum import Enum


class RecOwnershipEnum(Enum):
    OWNED = "Owned"
    NOT_OWNED_SOLD = "Not Owned/Sold"
    ARBITRAGED = "Arbitraged"
    UNKNOWN = "Unknown"
