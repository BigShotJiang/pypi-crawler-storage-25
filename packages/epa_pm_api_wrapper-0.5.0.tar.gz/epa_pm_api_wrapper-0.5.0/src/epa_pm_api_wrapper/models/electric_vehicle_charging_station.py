from __future__ import annotations

from dataclasses import dataclass

from .ev_charging_station_type import EvChargingStationType


@dataclass(kw_only=True)
class ElectricVehicleChargingStation(EvChargingStationType):
    """
    Electric vehicle charging station area.
    """

    class Meta:
        name = "electricVehicleChargingStation"
