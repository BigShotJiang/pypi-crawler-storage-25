from __future__ import annotations

from dataclasses import dataclass, field

from .library_type_use_details import LibraryTypeUseDetails
from .log_type import LogType


@dataclass(kw_only=True)
class LibraryType:
    class Meta:
        name = "libraryType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: LibraryTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
