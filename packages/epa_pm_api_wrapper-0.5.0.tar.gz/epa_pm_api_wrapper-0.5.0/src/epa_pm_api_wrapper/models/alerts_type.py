from __future__ import annotations

from dataclasses import dataclass, field

from .alerts_type_alert import AlertsTypeAlert


@dataclass(kw_only=True)
class AlertsType:
    """
    :ivar alert:
    :ivar year: The year of the period ending date provided.
    :ivar month: The month of the period ending date provided.
    :ivar property_id: The id of the property.
    """

    class Meta:
        name = "alertsType"

    alert: list[AlertsTypeAlert] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    year: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    month: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
            "min_inclusive": 1,
            "max_inclusive": 12,
        },
    )
    property_id: None | int = field(
        default=None,
        metadata={
            "name": "propertyId",
            "type": "Attribute",
        },
    )
