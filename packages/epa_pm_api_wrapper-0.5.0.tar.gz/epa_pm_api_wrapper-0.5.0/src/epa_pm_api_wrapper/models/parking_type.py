from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .parking_type_use_details import ParkingTypeUseDetails


@dataclass(kw_only=True)
class ParkingType:
    class Meta:
        name = "parkingType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: ParkingTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
