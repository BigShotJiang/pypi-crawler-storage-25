from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class MappingType:
    """
    :ivar id: The id of the account, property, or meter needed to
        reference a customer, property, or meter for a given external
        identifier from ABS 2.5.
    """

    class Meta:
        name = "mappingType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
