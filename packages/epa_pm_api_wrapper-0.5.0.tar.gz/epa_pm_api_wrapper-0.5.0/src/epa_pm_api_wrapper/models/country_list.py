from __future__ import annotations

from enum import Enum


class CountryList(Enum):
    """
    :cvar US: United States
    :cvar AD: Andorra
    :cvar AE: United Arab Emirates (the)
    :cvar AF: Afghanistan
    :cvar AG: Antigua and Barbuda
    :cvar AI: Anguilla
    :cvar AL: Albania
    :cvar AM: Armenia
    :cvar AO: Angola
    :cvar AQ: Antarctica
    :cvar AR: Argentina
    :cvar AT: Austria
    :cvar AU: Australia
    :cvar AW: Aruba
    :cvar AX: Åland Islands
    :cvar AZ: Azerbaijan
    :cvar BA: Bosnia and Herzegovina
    :cvar BB: Barbados
    :cvar BD: Bangladesh
    :cvar BE: Belgium
    :cvar BF: Burkina Faso
    :cvar BG: Bulgaria
    :cvar BH: Bahrain
    :cvar BI: Burundi
    :cvar BJ: Benin
    :cvar BL: Saint Barthélemy
    :cvar BM: Bermuda
    :cvar BN: Brunei Darussalam
    :cvar BO: Bolivia (Plurinational State of)
    :cvar BQ: Bonaire, Sint Eustatius and Saba
    :cvar BR: Brazil
    :cvar BS: Bahamas (the)
    :cvar BT: Bhutan
    :cvar BV: Bouvet Island
    :cvar BW: Botswana
    :cvar BY: Belarus
    :cvar BZ: Belize
    :cvar CA: Canada
    :cvar CC: Cocos (Keeling) Islands (the)
    :cvar CD: Congo (the Democratic Republic of the)
    :cvar CF: Central African Republic (the)
    :cvar CG: Congo (the)
    :cvar CH: Switzerland
    :cvar CI: Côte d'Ivoire
    :cvar CK: Cook Islands (the)
    :cvar CL: Chile
    :cvar CM: Cameroon
    :cvar CN: China
    :cvar CO: Colombia
    :cvar CR: Costa Rica
    :cvar CU: Cuba
    :cvar CV: Cabo Verde
    :cvar CW: Curaçao
    :cvar CX: Christmas Island
    :cvar CY: Cyprus
    :cvar CZ: Czech Republic (the)
    :cvar DE: Germany
    :cvar DJ: Djibouti
    :cvar DK: Denmark
    :cvar DM: Dominica
    :cvar DO: Dominican Republic (the)
    :cvar DZ: Algeria
    :cvar EC: Ecuador
    :cvar EE: Estonia
    :cvar EG: Egypt
    :cvar EH: Western Sahara*
    :cvar ER: Eritrea
    :cvar ES: Spain
    :cvar ET: Ethiopia
    :cvar FI: Finland
    :cvar FJ: Fiji
    :cvar FK: Falkland Islands (the) [Malvinas]
    :cvar FM: Micronesia (Federated States of)
    :cvar FO: Faroe Islands (the)
    :cvar FR: France
    :cvar GA: Gabon
    :cvar GB: United Kingdom of Great Britain and Northern Ireland (the)
    :cvar GD: Grenada
    :cvar GE: Georgia
    :cvar GF: French Guiana
    :cvar GG: Guernsey
    :cvar GH: Ghana
    :cvar GI: Gibraltar
    :cvar GL: Greenland
    :cvar GM: Gambia (the)
    :cvar GN: Guinea
    :cvar GP: Guadeloupe
    :cvar GQ: Equatorial Guinea
    :cvar GR: Greece
    :cvar GS: South Georgia and the South Sandwich Islands
    :cvar GT: Guatemala
    :cvar GW: Guinea-Bissau
    :cvar GY: Guyana
    :cvar HK: Hong Kong
    :cvar HM: Heard Island and McDonald Islands
    :cvar HN: Honduras
    :cvar HR: Croatia
    :cvar HT: Haiti
    :cvar HU: Hungary
    :cvar ID: Indonesia
    :cvar IE: Ireland
    :cvar IL: Israel
    :cvar IM: Isle of Man
    :cvar IN: India
    :cvar IO: British Indian Ocean Territory (the)
    :cvar IQ: Iraq
    :cvar IR: Iran (Islamic Republic of)
    :cvar IS: Iceland
    :cvar IT: Italy
    :cvar JE: Jersey
    :cvar JM: Jamaica
    :cvar JO: Jordan
    :cvar JP: Japan
    :cvar KE: Kenya
    :cvar KG: Kyrgyzstan
    :cvar KH: Cambodia
    :cvar KI: Kiribati
    :cvar KM: Comoros (the)
    :cvar KN: Saint Kitts and Nevis
    :cvar KP: Korea (the Democratic People's Republic of)
    :cvar KR: Korea (the Republic of)
    :cvar KW: Kuwait
    :cvar KY: Cayman Islands (the)
    :cvar KZ: Kazakhstan
    :cvar LA: Lao People's Democratic Republic (the)
    :cvar LB: Lebanon
    :cvar LC: Saint Lucia
    :cvar LI: Liechtenstein
    :cvar LK: Sri Lanka
    :cvar LR: Liberia
    :cvar LS: Lesotho
    :cvar LT: Lithuania
    :cvar LU: Luxembourg
    :cvar LV: Latvia
    :cvar LY: Libya
    :cvar MA: Morocco
    :cvar MC: Monaco
    :cvar MD: Moldova (the Republic of)
    :cvar ME: Montenegro
    :cvar MF: Saint Martin (French part)
    :cvar MG: Madagascar
    :cvar MK: Macedonia (the former Yugoslav Republic of)
    :cvar ML: Mali
    :cvar MM: Myanmar
    :cvar MN: Mongolia
    :cvar MO: Macao
    :cvar MQ: Martinique
    :cvar MR: Mauritania
    :cvar MS: Montserrat
    :cvar MT: Malta
    :cvar MU: Mauritius
    :cvar MV: Maldives
    :cvar MW: Malawi
    :cvar MX: Mexico
    :cvar MY: Malaysia
    :cvar MZ: Mozambique
    :cvar NA: Namibia
    :cvar NC: New Caledonia
    :cvar NE: Niger (the)
    :cvar NF: Norfolk Island
    :cvar NG: Nigeria
    :cvar NI: Nicaragua
    :cvar NL: Netherlands (the)
    :cvar NO: Norway
    :cvar NP: Nepal
    :cvar NR: Nauru
    :cvar NU: Niue
    :cvar NZ: New Zealand
    :cvar OM: Oman
    :cvar PA: Panama
    :cvar PE: Peru
    :cvar PF: French Polynesia
    :cvar PG: Papua New Guinea
    :cvar PH: Philippines (the)
    :cvar PK: Pakistan
    :cvar PL: Poland
    :cvar PM: Saint Pierre and Miquelon
    :cvar PN: Pitcairn
    :cvar PS: Palestine, State of
    :cvar PT: Portugal
    :cvar PW: Palau
    :cvar PY: Paraguay
    :cvar QA: Qatar
    :cvar RE: Réunion
    :cvar RO: Romania
    :cvar RS: Serbia
    :cvar RU: Russian Federation (the)
    :cvar RW: Rwanda
    :cvar SA: Saudi Arabia
    :cvar SB: Solomon Islands
    :cvar SC: Seychelles
    :cvar SD: Sudan (the)
    :cvar SE: Sweden
    :cvar SG: Singapore
    :cvar SH: Saint Helena, Ascension and Tristan da Cunha
    :cvar SI: Slovenia
    :cvar SJ: Svalbard and Jan Mayen
    :cvar SK: Slovakia
    :cvar SL: Sierra Leone
    :cvar SM: San Marino
    :cvar SN: Senegal
    :cvar SO: Somalia
    :cvar SR: Suriname
    :cvar SS: South Sudan
    :cvar ST: Sao Tome and Principe
    :cvar SV: El Salvador
    :cvar SX: Sint Maarten (Dutch part)
    :cvar SY: Syrian Arab Republic
    :cvar SZ: Swaziland
    :cvar TC: Turks and Caicos Islands (the)
    :cvar TD: Chad
    :cvar TF: French Southern Territories (the)
    :cvar TG: Togo
    :cvar TH: Thailand
    :cvar TJ: Tajikistan
    :cvar TK: Tokelau
    :cvar TL: Timor-Leste
    :cvar TM: Turkmenistan
    :cvar TN: Tunisia
    :cvar TO: Tonga
    :cvar TR: Turkey
    :cvar TT: Trinidad and Tobago
    :cvar TV: Tuvalu
    :cvar TW: Taiwan (Province of China)
    :cvar TZ: Tanzania, United Republic of
    :cvar UA: Ukraine
    :cvar UG: Uganda
    :cvar UY: Uruguay
    :cvar UZ: Uzbekistan
    :cvar VA: Holy See (the)
    :cvar VC: Saint Vincent and the Grenadines
    :cvar VE: Venezuela (Bolivarian Republic of)
    :cvar VG: Virgin Islands (British)
    :cvar VN: Viet Nam
    :cvar VU: Vanuatu
    :cvar WF: Wallis and Futuna
    :cvar WS: Samoa
    :cvar YE: Yemen
    :cvar YT: Mayotte
    :cvar ZA: South Africa
    :cvar ZM: Zambia
    :cvar ZW: Zimbabwe
    """

    US = "US"
    AD = "AD"
    AE = "AE"
    AF = "AF"
    AG = "AG"
    AI = "AI"
    AL = "AL"
    AM = "AM"
    AO = "AO"
    AQ = "AQ"
    AR = "AR"
    AT = "AT"
    AU = "AU"
    AW = "AW"
    AX = "AX"
    AZ = "AZ"
    BA = "BA"
    BB = "BB"
    BD = "BD"
    BE = "BE"
    BF = "BF"
    BG = "BG"
    BH = "BH"
    BI = "BI"
    BJ = "BJ"
    BL = "BL"
    BM = "BM"
    BN = "BN"
    BO = "BO"
    BQ = "BQ"
    BR = "BR"
    BS = "BS"
    BT = "BT"
    BV = "BV"
    BW = "BW"
    BY = "BY"
    BZ = "BZ"
    CA = "CA"
    CC = "CC"
    CD = "CD"
    CF = "CF"
    CG = "CG"
    CH = "CH"
    CI = "CI"
    CK = "CK"
    CL = "CL"
    CM = "CM"
    CN = "CN"
    CO = "CO"
    CR = "CR"
    CU = "CU"
    CV = "CV"
    CW = "CW"
    CX = "CX"
    CY = "CY"
    CZ = "CZ"
    DE = "DE"
    DJ = "DJ"
    DK = "DK"
    DM = "DM"
    DO = "DO"
    DZ = "DZ"
    EC = "EC"
    EE = "EE"
    EG = "EG"
    EH = "EH"
    ER = "ER"
    ES = "ES"
    ET = "ET"
    FI = "FI"
    FJ = "FJ"
    FK = "FK"
    FM = "FM"
    FO = "FO"
    FR = "FR"
    GA = "GA"
    GB = "GB"
    GD = "GD"
    GE = "GE"
    GF = "GF"
    GG = "GG"
    GH = "GH"
    GI = "GI"
    GL = "GL"
    GM = "GM"
    GN = "GN"
    GP = "GP"
    GQ = "GQ"
    GR = "GR"
    GS = "GS"
    GT = "GT"
    GW = "GW"
    GY = "GY"
    HK = "HK"
    HM = "HM"
    HN = "HN"
    HR = "HR"
    HT = "HT"
    HU = "HU"
    ID = "ID"
    IE = "IE"
    IL = "IL"
    IM = "IM"
    IN = "IN"
    IO = "IO"
    IQ = "IQ"
    IR = "IR"
    IS = "IS"
    IT = "IT"
    JE = "JE"
    JM = "JM"
    JO = "JO"
    JP = "JP"
    KE = "KE"
    KG = "KG"
    KH = "KH"
    KI = "KI"
    KM = "KM"
    KN = "KN"
    KP = "KP"
    KR = "KR"
    KW = "KW"
    KY = "KY"
    KZ = "KZ"
    LA = "LA"
    LB = "LB"
    LC = "LC"
    LI = "LI"
    LK = "LK"
    LR = "LR"
    LS = "LS"
    LT = "LT"
    LU = "LU"
    LV = "LV"
    LY = "LY"
    MA = "MA"
    MC = "MC"
    MD = "MD"
    ME = "ME"
    MF = "MF"
    MG = "MG"
    MK = "MK"
    ML = "ML"
    MM = "MM"
    MN = "MN"
    MO = "MO"
    MQ = "MQ"
    MR = "MR"
    MS = "MS"
    MT = "MT"
    MU = "MU"
    MV = "MV"
    MW = "MW"
    MX = "MX"
    MY = "MY"
    MZ = "MZ"
    NA = "NA"
    NC = "NC"
    NE = "NE"
    NF = "NF"
    NG = "NG"
    NI = "NI"
    NL = "NL"
    NO = "NO"
    NP = "NP"
    NR = "NR"
    NU = "NU"
    NZ = "NZ"
    OM = "OM"
    PA = "PA"
    PE = "PE"
    PF = "PF"
    PG = "PG"
    PH = "PH"
    PK = "PK"
    PL = "PL"
    PM = "PM"
    PN = "PN"
    PS = "PS"
    PT = "PT"
    PW = "PW"
    PY = "PY"
    QA = "QA"
    RE = "RE"
    RO = "RO"
    RS = "RS"
    RU = "RU"
    RW = "RW"
    SA = "SA"
    SB = "SB"
    SC = "SC"
    SD = "SD"
    SE = "SE"
    SG = "SG"
    SH = "SH"
    SI = "SI"
    SJ = "SJ"
    SK = "SK"
    SL = "SL"
    SM = "SM"
    SN = "SN"
    SO = "SO"
    SR = "SR"
    SS = "SS"
    ST = "ST"
    SV = "SV"
    SX = "SX"
    SY = "SY"
    SZ = "SZ"
    TC = "TC"
    TD = "TD"
    TF = "TF"
    TG = "TG"
    TH = "TH"
    TJ = "TJ"
    TK = "TK"
    TL = "TL"
    TM = "TM"
    TN = "TN"
    TO = "TO"
    TR = "TR"
    TT = "TT"
    TV = "TV"
    TW = "TW"
    TZ = "TZ"
    UA = "UA"
    UG = "UG"
    UY = "UY"
    UZ = "UZ"
    VA = "VA"
    VC = "VC"
    VE = "VE"
    VG = "VG"
    VN = "VN"
    VU = "VU"
    WF = "WF"
    WS = "WS"
    YE = "YE"
    YT = "YT"
    ZA = "ZA"
    ZM = "ZM"
    ZW = "ZW"
