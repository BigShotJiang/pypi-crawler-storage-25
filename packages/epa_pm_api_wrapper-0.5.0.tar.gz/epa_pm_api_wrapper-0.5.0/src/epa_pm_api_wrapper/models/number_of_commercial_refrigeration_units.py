from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfCommercialRefrigerationUnits(UseDecimalType):
    """
    Number of Commercial Refrigeration/Freezer cases, including any open or
    closed commercial type case, and including any walk-in units.
    """

    class Meta:
        name = "numberOfCommercialRefrigerationUnits"
