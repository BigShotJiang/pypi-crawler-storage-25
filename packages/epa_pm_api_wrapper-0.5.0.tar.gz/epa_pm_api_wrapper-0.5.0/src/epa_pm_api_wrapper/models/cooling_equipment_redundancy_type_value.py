from __future__ import annotations

from enum import Enum


class CoolingEquipmentRedundancyTypeValue(Enum):
    N = "N"
    N_1 = "N+1"
    N_2 = "N+2"
    VALUE_2_N = "2N"
    GREATER_THAN_2_N = "Greater than 2N"
    NONE_OF_THE_ABOVE = "None of the Above"
