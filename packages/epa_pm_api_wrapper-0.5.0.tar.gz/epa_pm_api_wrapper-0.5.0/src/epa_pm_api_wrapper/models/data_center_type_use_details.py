from __future__ import annotations

from dataclasses import dataclass, field

from .cooling_equipment_redundancy import CoolingEquipmentRedundancy
from .estimates_applied import EstimatesApplied
from .it_energy_meter_configuration import ItEnergyMeterConfiguration
from .total_gross_floor_area import TotalGrossFloorArea
from .ups_system_redundancy import UpsSystemRedundancy


@dataclass(kw_only=True)
class DataCenterTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    estimates_applied: None | EstimatesApplied = field(
        default=None,
        metadata={
            "name": "estimatesApplied",
            "type": "Element",
        },
    )
    cooling_equipment_redundancy: None | CoolingEquipmentRedundancy = field(
        default=None,
        metadata={
            "name": "coolingEquipmentRedundancy",
            "type": "Element",
        },
    )
    it_energy_meter_configuration: None | ItEnergyMeterConfiguration = field(
        default=None,
        metadata={
            "name": "itEnergyMeterConfiguration",
            "type": "Element",
        },
    )
    ups_system_redundancy: None | UpsSystemRedundancy = field(
        default=None,
        metadata={
            "name": "upsSystemRedundancy",
            "type": "Element",
        },
    )
