from __future__ import annotations

from dataclasses import dataclass

from .mailing_center_post_office_type import MailingCenterPostOfficeType


@dataclass(kw_only=True)
class MailingCenterPostOffice(MailingCenterPostOfficeType):
    """
    Mailing Center/Post Office refers to buildings used as establishments
    dedicated to mail and mailing supplies.
    """

    class Meta:
        name = "mailingCenterPostOffice"
