from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class GovernmentSubsidizedHousing(UseYesNoType):
    """
    Whether this is housing that is subsidized by the local, state, or
    Federal government.
    """

    class Meta:
        name = "governmentSubsidizedHousing"
