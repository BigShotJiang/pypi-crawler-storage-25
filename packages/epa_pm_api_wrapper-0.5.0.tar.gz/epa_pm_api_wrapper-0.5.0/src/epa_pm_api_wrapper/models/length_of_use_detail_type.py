from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .length_units_type import LengthUnitsType
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class LengthOfUseDetailType(UseAttributeBase):
    class Meta:
        name = "lengthOfUseDetailType"

    value: None | Decimal = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    units: LengthUnitsType = field(
        metadata={
            "type": "Attribute",
        }
    )
