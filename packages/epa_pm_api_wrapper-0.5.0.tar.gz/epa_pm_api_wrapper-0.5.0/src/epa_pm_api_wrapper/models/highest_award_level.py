from __future__ import annotations

from dataclasses import dataclass

from .highest_award_level_type import HighestAwardLevelType


@dataclass(kw_only=True)
class HighestAwardLevel(HighestAwardLevelType):
    """
    The Highest Level of Award for higher education institutions is based
    on the highest level of degree, diploma, or certificate offered by the
    institution.
    """

    class Meta:
        name = "highestAwardLevel"
