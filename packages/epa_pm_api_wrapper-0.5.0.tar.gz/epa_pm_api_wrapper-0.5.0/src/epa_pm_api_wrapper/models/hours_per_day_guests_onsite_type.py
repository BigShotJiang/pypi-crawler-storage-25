from __future__ import annotations

from dataclasses import dataclass, field

from .hours_per_day_guests_onsite_type_value import (
    HoursPerDayGuestsOnsiteTypeValue,
)
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class HoursPerDayGuestsOnsiteType(UseAttributeBase):
    class Meta:
        name = "hoursPerDayGuestsOnsiteType"

    value: None | HoursPerDayGuestsOnsiteTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
