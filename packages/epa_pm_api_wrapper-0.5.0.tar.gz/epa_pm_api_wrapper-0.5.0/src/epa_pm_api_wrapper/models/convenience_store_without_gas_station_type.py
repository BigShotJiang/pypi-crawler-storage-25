from __future__ import annotations

from dataclasses import dataclass, field

from .convenience_store_without_gas_station_type_use_details import (
    ConvenienceStoreWithoutGasStationTypeUseDetails,
)
from .log_type import LogType


@dataclass(kw_only=True)
class ConvenienceStoreWithoutGasStationType:
    class Meta:
        name = "convenienceStoreWithoutGasStationType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: ConvenienceStoreWithoutGasStationTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
