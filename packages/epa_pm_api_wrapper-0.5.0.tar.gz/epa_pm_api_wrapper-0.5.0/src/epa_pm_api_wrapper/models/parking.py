from __future__ import annotations

from dataclasses import dataclass

from .parking_type import ParkingType


@dataclass(kw_only=True)
class Parking(ParkingType):
    """
    Buildings and lots used for parking vehicles.
    """

    class Meta:
        name = "parking"
