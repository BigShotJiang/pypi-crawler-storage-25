from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfSurgicalOperatingBeds(UseDecimalType):
    """
    Number of beds associated with surgical operation at a medial
    office/outpatient healthcare facility.
    """

    class Meta:
        name = "numberOfSurgicalOperatingBeds"
