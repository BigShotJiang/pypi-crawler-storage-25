from __future__ import annotations

from dataclasses import dataclass, field

from .links_type import LinksType
from .meter_consumption import MeterConsumption
from .meter_delivery import MeterDelivery


@dataclass(kw_only=True)
class MeterDataType:
    """
    A service type used for getting and receiving meter consumption data.
    """

    class Meta:
        name = "meterDataType"

    meter_consumption: list[MeterConsumption] = field(
        default_factory=list,
        metadata={
            "name": "meterConsumption",
            "type": "Element",
            "max_occurs": 120,
        },
    )
    meter_delivery: list[MeterDelivery] = field(
        default_factory=list,
        metadata={
            "name": "meterDelivery",
            "type": "Element",
            "max_occurs": 120,
        },
    )
    links: None | LinksType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
