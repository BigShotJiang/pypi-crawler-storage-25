from __future__ import annotations

from dataclasses import dataclass, field

from .account_type_language_preference import AccountTypeLanguagePreference
from .contact_type import ContactType
from .organization_type import OrganizationType


@dataclass(kw_only=True)
class AccountType:
    """
    :ivar id: The ID to the account.  This is ignored if specified in a
        XML request.  This is provided by Portfolio Manager only in a
        XML response.
    :ivar username: Your username.
    :ivar password: Your password.  The password must be at least 8
        characters in length and must contain 3 out of  4 of the
        following requirements: (i) uppercase characters, (ii) lowercase
        characters, (iii) base 10 digits (0 through 9), and (iv)
        nonalphanumeric characters:
        ~!@#$%^&amp;*_-+=`|\\(){}[]:;"'&lt;&gt;,.?/
    :ivar contact:
    :ivar organization:
    :ivar webservice_user: Whether you will be using web services.
    :ivar searchable: Whether you want people to be able to search for
        you.
    :ivar include_test_properties_in_graphics: Indicates whether
        properties marked as “Test Properties” in the account will be
        included in the charts and graphs on My Portfolio page.
    :ivar email_preference_canadian_account: This setting ONLY applies
        to accounts belonging to Canada.  NRCAN (Natural Resources of
        Canada) can contact you with training opportunities, tool
        updates, program news and other information about the ENERGY
        STAR program.
    :ivar billboard_metric: Your saved billboard metric
    :ivar language_preference:
    """

    class Meta:
        name = "accountType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    username: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 60,
        }
    )
    password: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 8,
            "max_length": 120,
        }
    )
    contact: ContactType = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    organization: OrganizationType = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    webservice_user: bool = field(
        metadata={
            "name": "webserviceUser",
            "type": "Element",
            "namespace": "",
        }
    )
    searchable: bool = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    include_test_properties_in_graphics: None | bool = field(
        default=None,
        metadata={
            "name": "includeTestPropertiesInGraphics",
            "type": "Element",
            "namespace": "",
        },
    )
    email_preference_canadian_account: None | bool = field(
        default=None,
        metadata={
            "name": "emailPreferenceCanadianAccount",
            "type": "Element",
            "namespace": "",
        },
    )
    billboard_metric: None | str = field(
        default=None,
        metadata={
            "name": "billboardMetric",
            "type": "Element",
            "namespace": "",
        },
    )
    language_preference: None | AccountTypeLanguagePreference = field(
        default=None,
        metadata={
            "name": "languagePreference",
            "type": "Element",
            "namespace": "",
        },
    )
