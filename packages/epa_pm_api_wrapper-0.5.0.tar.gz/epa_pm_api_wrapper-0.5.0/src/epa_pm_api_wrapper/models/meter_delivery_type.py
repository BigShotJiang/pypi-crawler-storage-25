from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from xsdata.models.datatype import XmlDate

from .empty_string import EmptyString
from .log_type import LogType


@dataclass(kw_only=True)
class MeterDeliveryType:
    """
    Delivery data used for a meter that is set up for bulk delivery.

    :ivar id: The id of the meter delivery entry.
    :ivar delivery_date: Indicates the date of the delivery.
    :ivar quantity: Indicates the quantity of energy delivered.
    :ivar cost: Indicates the cost associated with the energy delivered.
    :ivar audit:
    :ivar estimated_value:
    """

    class Meta:
        name = "meterDeliveryType"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    delivery_date: XmlDate = field(
        metadata={
            "name": "deliveryDate",
            "type": "Element",
            "namespace": "",
        }
    )
    quantity: Decimal = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    cost: None | EmptyString | Decimal = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    estimated_value: None | bool = field(
        default=None,
        metadata={
            "name": "estimatedValue",
            "type": "Attribute",
        },
    )
