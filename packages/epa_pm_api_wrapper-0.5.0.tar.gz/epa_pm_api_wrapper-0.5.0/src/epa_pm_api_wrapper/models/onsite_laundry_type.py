from __future__ import annotations

from dataclasses import dataclass, field

from .onsite_laundry_type_value import OnsiteLaundryTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class OnsiteLaundryType(UseAttributeBase):
    class Meta:
        name = "onsiteLaundryType"

    value: None | OnsiteLaundryTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
