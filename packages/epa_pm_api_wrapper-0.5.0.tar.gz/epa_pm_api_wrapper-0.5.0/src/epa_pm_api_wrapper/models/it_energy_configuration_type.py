from __future__ import annotations

from dataclasses import dataclass, field

from .it_energy_configuration_type_value import ItEnergyConfigurationTypeValue
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class ItEnergyConfigurationType(UseAttributeBase):
    class Meta:
        name = "itEnergyConfigurationType"

    value: None | ItEnergyConfigurationTypeValue = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
