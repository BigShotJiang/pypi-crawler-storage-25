from __future__ import annotations

from dataclasses import dataclass, field

from .address_type import AddressType


@dataclass(kw_only=True)
class ContactType:
    """
    :ivar first_name: Your first name
    :ivar last_name: Your last name
    :ivar email: Your email address
    :ivar address:
    :ivar job_title:
    :ivar phone:
    """

    class Meta:
        name = "contactType"

    first_name: str = field(
        metadata={
            "name": "firstName",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 100,
        }
    )
    last_name: str = field(
        metadata={
            "name": "lastName",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 100,
        }
    )
    email: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 100,
        }
    )
    address: AddressType = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    job_title: str = field(
        metadata={
            "name": "jobTitle",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 100,
        }
    )
    phone: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 30,
        }
    )
