from __future__ import annotations

from dataclasses import dataclass, field

from .links_type import LinksType
from .station import Station


@dataclass(kw_only=True)
class InternationalWeatherStationList:
    class Meta:
        name = "internationalWeatherStationList"

    station: list[Station] = field(
        default_factory=list,
        metadata={
            "type": "Element",
        },
    )
    links: None | LinksType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
