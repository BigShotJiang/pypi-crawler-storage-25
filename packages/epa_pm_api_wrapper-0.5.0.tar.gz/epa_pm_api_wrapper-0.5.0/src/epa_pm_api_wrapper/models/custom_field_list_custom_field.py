from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class CustomFieldListCustomField:
    class Meta:
        global_type = False

    value: str = field(default="")
    name: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
