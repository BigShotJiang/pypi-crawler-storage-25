from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchaseTypeAmountPurchasedPercentageMeters:
    """
    :ivar id: The unique identifier for each meter.
    """

    class Meta:
        global_type = False

    id: list[int] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
