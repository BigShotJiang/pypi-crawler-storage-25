from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class NumberOfCookingEquipmentUnits(UseIntegerType):
    """
    Number of cooking equipment units in a convenience store.
    """

    class Meta:
        name = "numberOfCookingEquipmentUnits"
