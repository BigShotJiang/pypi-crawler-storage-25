from __future__ import annotations

from enum import Enum


class AddressTypeState(Enum):
    """
    :cvar AK: Alaska in United States
    :cvar AL: Alabama in United States
    :cvar AR: Arkansas in United States
    :cvar AS: American Samoa in United States
    :cvar AZ: Arizona in United States
    :cvar CA: California in United States
    :cvar CO: Colorado in United States
    :cvar CT: Connecticut in United States
    :cvar DC: District of Columbia (D.C.) in United States
    :cvar DE: Delaware in United States
    :cvar FL: Florida in United States
    :cvar GA: Georgia in United States
    :cvar GU: Guam in United States
    :cvar HI: Hawaii in United States
    :cvar IA: Iowa in United States
    :cvar ID: Idaho in United States
    :cvar IL: Illinois in United States
    :cvar IN: Indiana in United States
    :cvar KS: Kansas in United States
    :cvar KY: Kentucky in United States
    :cvar LA: Louisiana in United States
    :cvar MA: Massachusetts in United States
    :cvar MD: Maryland in United States
    :cvar ME: Maine in United States
    :cvar MH: Marshall Islands in United States
    :cvar MI: Michigan in United States
    :cvar MN: Minnesota in United States
    :cvar MO: Missouri in United States
    :cvar MP: Northern Mariana Islands in United States
    :cvar MS: Mississippi in United States
    :cvar MT: Montana in United States
    :cvar NC: North Carolina in United States
    :cvar ND: North Dakota in United States
    :cvar NE: Nebraska in United States
    :cvar NH: New Hampshire in United States
    :cvar NJ: New Jersey in United States
    :cvar NM: New Mexico in United States
    :cvar NN: Navajo Nation in United States
    :cvar NV: Nevada in United States
    :cvar NY: New York in United States
    :cvar OH: Ohio in United States
    :cvar OK: Oklahoma in United States
    :cvar OR: Oregon in United States
    :cvar PA: Pennsylvania in United States
    :cvar PI: Pacific Islands in United States
    :cvar PR: Puerto Rico in United States
    :cvar RI: Rhode Island in United States
    :cvar SC: South Carolina in United States
    :cvar SD: South Dakota in United States
    :cvar TN: Tennessee in United States
    :cvar TT: Trust Territories in United States
    :cvar TX: Texas in United States
    :cvar UM: U.S. Minor Outlying Islands in United States
    :cvar UT: Utah in United States
    :cvar VA: Virginia in United States
    :cvar VI: Virgin Islands of the U.S. in United States
    :cvar VT: Vermont in United States
    :cvar WA: Washington in United States
    :cvar WI: Wisconsin in United States
    :cvar WQ: Wake Island in United States
    :cvar WV: West Virginia in United States
    :cvar WY: Wyoming in United States
    :cvar AB: Alberta province in Canada
    :cvar BC: British Columbia province in Canada
    :cvar MB: Manitoba province in Canada
    :cvar NB: New Brunswick province in Canada
    :cvar NL: Newfoundland and Labrador province in Canada
    :cvar NS: Nova Scotia province in Canada
    :cvar NT: Northwest Territories province in Canada
    :cvar NU: Nunavut province in Canada
    :cvar ON: Ontario province in Canada
    :cvar PE: Prince Edward Island province in Canada
    :cvar QC: Quebec province in Canada
    :cvar SK: Saskatchewan province in Canada
    :cvar YT: Yukon province in Canada
    """

    AK = "AK"
    AL = "AL"
    AR = "AR"
    AS = "AS"
    AZ = "AZ"
    CA = "CA"
    CO = "CO"
    CT = "CT"
    DC = "DC"
    DE = "DE"
    FL = "FL"
    GA = "GA"
    GU = "GU"
    HI = "HI"
    IA = "IA"
    ID = "ID"
    IL = "IL"
    IN = "IN"
    KS = "KS"
    KY = "KY"
    LA = "LA"
    MA = "MA"
    MD = "MD"
    ME = "ME"
    MH = "MH"
    MI = "MI"
    MN = "MN"
    MO = "MO"
    MP = "MP"
    MS = "MS"
    MT = "MT"
    NC = "NC"
    ND = "ND"
    NE = "NE"
    NH = "NH"
    NJ = "NJ"
    NM = "NM"
    NN = "NN"
    NV = "NV"
    NY = "NY"
    OH = "OH"
    OK = "OK"
    OR = "OR"
    PA = "PA"
    PI = "PI"
    PR = "PR"
    RI = "RI"
    SC = "SC"
    SD = "SD"
    TN = "TN"
    TT = "TT"
    TX = "TX"
    UM = "UM"
    UT = "UT"
    VA = "VA"
    VI = "VI"
    VT = "VT"
    WA = "WA"
    WI = "WI"
    WQ = "WQ"
    WV = "WV"
    WY = "WY"
    AB = "AB"
    BC = "BC"
    MB = "MB"
    NB = "NB"
    NL = "NL"
    NS = "NS"
    NT = "NT"
    NU = "NU"
    ON = "ON"
    PE = "PE"
    QC = "QC"
    SK = "SK"
    YT = "YT"
