from __future__ import annotations

from enum import Enum


class AnnualResearchExpenditureTypeValue(Enum):
    LESS_THAN_2_5_MILLION = "Less than 2.5 million"
    VALUE_2_5_MILLION_TO_5_MILLION = "2.5 million to 5 million"
    VALUE_5_MILLION_TO_50_MILLION = "5 million to 50 million"
    GREATER_THAN_50_MILLION = "Greater than 50 million"
