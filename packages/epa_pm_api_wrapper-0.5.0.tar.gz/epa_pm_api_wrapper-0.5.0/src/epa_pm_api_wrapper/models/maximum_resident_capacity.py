from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class MaximumResidentCapacity(UseDecimalType):
    """
    Maximum capacity of residents, based on the design of the facility.
    """

    class Meta:
        name = "maximumResidentCapacity"
