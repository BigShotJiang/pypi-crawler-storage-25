from __future__ import annotations

from dataclasses import dataclass, field

from .custom_field_valid_characters import CustomFieldValidCharacters
from .custom_field_when_to_prompt import CustomFieldWhenToPrompt


@dataclass(kw_only=True)
class CustomField:
    """
    Additional field (outside of Portfolio Manager) that you can prompt a
    user to provide data through the connection/share process.

    :ivar min_chars: The minimum number of characters allowed for input.
    :ivar max_chars: The maximum number of characters allowed for input.
    :ivar description: The description of the custom field that is
        displayed.
    :ivar example: Example of input.
    :ivar url: The URL of a web page with more information about this
        field.
    :ivar display_order: The display order if multiple custom fields
        have been created.
    :ivar name: The custom field name which will display to the PM user.
    :ivar required: Whether the field is required or not.
    :ivar valid_characters: The set of valid characters allowed for
        input.
    :ivar when_to_prompt: When the custom field should be prompted to
        the user (i.e., every account, every property, or every meter).
    """

    class Meta:
        name = "customField"

    min_chars: None | int = field(
        default=None,
        metadata={
            "name": "minChars",
            "type": "Element",
            "namespace": "",
        },
    )
    max_chars: None | int = field(
        default=None,
        metadata={
            "name": "maxChars",
            "type": "Element",
            "namespace": "",
        },
    )
    description: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 4000,
        },
    )
    example: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 100,
        },
    )
    url: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 1000,
        },
    )
    display_order: None | int = field(
        default=None,
        metadata={
            "name": "displayOrder",
            "type": "Element",
            "namespace": "",
        },
    )
    name: str = field(
        metadata={
            "type": "Attribute",
            "min_length": 1,
            "max_length": 100,
        }
    )
    required: bool = field(
        metadata={
            "type": "Attribute",
        }
    )
    valid_characters: CustomFieldValidCharacters = field(
        metadata={
            "name": "validCharacters",
            "type": "Attribute",
        }
    )
    when_to_prompt: CustomFieldWhenToPrompt = field(
        metadata={
            "name": "whenToPrompt",
            "type": "Attribute",
        }
    )
