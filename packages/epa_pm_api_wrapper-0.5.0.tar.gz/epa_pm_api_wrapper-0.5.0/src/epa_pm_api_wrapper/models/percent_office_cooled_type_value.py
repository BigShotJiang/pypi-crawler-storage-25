from __future__ import annotations

from enum import Enum


class PercentOfficeCooledTypeValue(Enum):
    VALUE_50_OR_MORE = "50% or more"
    LESS_THAN_50 = "Less than 50%"
    NOT_AIR_CONDITIONED = "Not Air Conditioned"
