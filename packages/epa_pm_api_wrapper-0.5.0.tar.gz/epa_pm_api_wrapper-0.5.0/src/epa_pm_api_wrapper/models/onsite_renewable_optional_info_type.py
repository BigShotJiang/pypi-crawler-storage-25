from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from xsdata.models.datatype import XmlDate

from .log_type import LogType
from .onsite_renewable_optional_info_type_rated_capacity import (
    OnsiteRenewableOptionalInfoTypeRatedCapacity,
)
from .onsite_renewable_optional_info_type_renewable_generation_technologies import (
    OnsiteRenewableOptionalInfoTypeRenewableGenerationTechnologies,
)


@dataclass(kw_only=True)
class OnsiteRenewableOptionalInfoType:
    """
    :ivar project_name: The project name.
    :ivar renewable_generation_technologies: The Renewable Generation
        Technology types.
    :ivar rated_capacity: The rated capacity of project/offtake.
    :ivar operation_date: The commercial operation date.
    :ivar number_of_inverters: The number of inverters.
    :ivar number_of_solar_panels: The number of solar panels.
    :ivar total_cost: the total investment cost of the project in $.
    :ivar incentive_or_rebate_amount: The amount of incentives or
        rebates obtained for the project in $.
    :ivar estimated_savings: The estimated cost savings of the project
        in $.
    :ivar notes: Any other information about the renewable energy.
    :ivar audit:
    """

    class Meta:
        name = "onsiteRenewableOptionalInfoType"

    project_name: None | str = field(
        default=None,
        metadata={
            "name": "projectName",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        },
    )
    renewable_generation_technologies: None | OnsiteRenewableOptionalInfoTypeRenewableGenerationTechnologies = field(
        default=None,
        metadata={
            "name": "renewableGenerationTechnologies",
            "type": "Element",
            "namespace": "",
        },
    )
    rated_capacity: None | OnsiteRenewableOptionalInfoTypeRatedCapacity = field(
        default=None,
        metadata={
            "name": "ratedCapacity",
            "type": "Element",
            "namespace": "",
        },
    )
    operation_date: None | XmlDate = field(
        default=None,
        metadata={
            "name": "operationDate",
            "type": "Element",
            "namespace": "",
        },
    )
    number_of_inverters: None | int = field(
        default=None,
        metadata={
            "name": "numberOfInverters",
            "type": "Element",
            "namespace": "",
        },
    )
    number_of_solar_panels: None | int = field(
        default=None,
        metadata={
            "name": "numberOfSolarPanels",
            "type": "Element",
            "namespace": "",
        },
    )
    total_cost: None | Decimal = field(
        default=None,
        metadata={
            "name": "totalCost",
            "type": "Element",
            "namespace": "",
            "min_exclusive": Decimal("0"),
            "fraction_digits": 2,
        },
    )
    incentive_or_rebate_amount: None | Decimal = field(
        default=None,
        metadata={
            "name": "incentiveOrRebateAmount",
            "type": "Element",
            "namespace": "",
            "min_exclusive": Decimal("0"),
            "fraction_digits": 2,
        },
    )
    estimated_savings: None | Decimal = field(
        default=None,
        metadata={
            "name": "estimatedSavings",
            "type": "Element",
            "namespace": "",
            "min_exclusive": Decimal("0"),
            "fraction_digits": 2,
        },
    )
    notes: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 4000,
        },
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
