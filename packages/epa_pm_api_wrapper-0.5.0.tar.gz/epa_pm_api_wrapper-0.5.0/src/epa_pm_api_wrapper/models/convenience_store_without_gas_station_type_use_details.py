from __future__ import annotations

from dataclasses import dataclass, field

from .area_of_all_walk_in_refrigeration_units import (
    AreaOfAllWalkInRefrigerationUnits,
)
from .cooking_facilities import CookingFacilities
from .length_of_all_open_closed_refrigeration_units import (
    LengthOfAllOpenClosedRefrigerationUnits,
)
from .number_of_cash_registers import NumberOfCashRegisters
from .number_of_computers import NumberOfComputers
from .number_of_cooking_equipment_units import NumberOfCookingEquipmentUnits
from .number_of_fteworkers import NumberOfFteworkers
from .number_of_open_closed_refrigeration_units import (
    NumberOfOpenClosedRefrigerationUnits,
)
from .number_of_walk_in_refrigeration_units import (
    NumberOfWalkInRefrigerationUnits,
)
from .number_of_warming_heating_equipment_units import (
    NumberOfWarmingHeatingEquipmentUnits,
)
from .number_of_workers import NumberOfWorkers
from .percent_cooled import PercentCooled
from .percent_heated import PercentHeated
from .total_gross_floor_area import TotalGrossFloorArea
from .weekly_operating_hours import WeeklyOperatingHours


@dataclass(kw_only=True)
class ConvenienceStoreWithoutGasStationTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
    weekly_operating_hours: None | WeeklyOperatingHours = field(
        default=None,
        metadata={
            "name": "weeklyOperatingHours",
            "type": "Element",
        },
    )
    number_of_workers: None | NumberOfWorkers = field(
        default=None,
        metadata={
            "name": "numberOfWorkers",
            "type": "Element",
        },
    )
    number_of_computers: None | NumberOfComputers = field(
        default=None,
        metadata={
            "name": "numberOfComputers",
            "type": "Element",
        },
    )
    cooking_facilities: None | CookingFacilities = field(
        default=None,
        metadata={
            "name": "cookingFacilities",
            "type": "Element",
        },
    )
    number_of_walk_in_refrigeration_units: None | NumberOfWalkInRefrigerationUnits = field(
        default=None,
        metadata={
            "name": "numberOfWalkInRefrigerationUnits",
            "type": "Element",
        },
    )
    number_of_open_closed_refrigeration_units: None | NumberOfOpenClosedRefrigerationUnits = field(
        default=None,
        metadata={
            "name": "numberOfOpenClosedRefrigerationUnits",
            "type": "Element",
        },
    )
    number_of_cash_registers: None | NumberOfCashRegisters = field(
        default=None,
        metadata={
            "name": "numberOfCashRegisters",
            "type": "Element",
        },
    )
    percent_cooled: None | PercentCooled = field(
        default=None,
        metadata={
            "name": "percentCooled",
            "type": "Element",
        },
    )
    percent_heated: None | PercentHeated = field(
        default=None,
        metadata={
            "name": "percentHeated",
            "type": "Element",
        },
    )
    area_of_all_walk_in_refrigeration_units: None | AreaOfAllWalkInRefrigerationUnits = field(
        default=None,
        metadata={
            "name": "areaOfAllWalkInRefrigerationUnits",
            "type": "Element",
        },
    )
    length_of_all_open_closed_refrigeration_units: None | LengthOfAllOpenClosedRefrigerationUnits = field(
        default=None,
        metadata={
            "name": "lengthOfAllOpenClosedRefrigerationUnits",
            "type": "Element",
        },
    )
    number_of_fteworkers: None | NumberOfFteworkers = field(
        default=None,
        metadata={
            "name": "numberOfFTEWorkers",
            "type": "Element",
        },
    )
    number_of_cooking_equipment_units: None | NumberOfCookingEquipmentUnits = field(
        default=None,
        metadata={
            "name": "numberOfCookingEquipmentUnits",
            "type": "Element",
        },
    )
    number_of_warming_heating_equipment_units: None | NumberOfWarmingHeatingEquipmentUnits = field(
        default=None,
        metadata={
            "name": "numberOfWarmingHeatingEquipmentUnits",
            "type": "Element",
        },
    )
