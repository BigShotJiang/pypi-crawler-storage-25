from __future__ import annotations

from enum import Enum


class OnsiteLaundryTypeValue(Enum):
    LINENS_ONLY = "Linens only"
    TERRY_ONLY = "Terry only"
    BOTH_LINENS_AND_TERRY = "Both linens and terry"
    NO_LAUNDRY_FACILITY = "No laundry facility"
