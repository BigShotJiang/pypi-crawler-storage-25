from __future__ import annotations

from enum import Enum


class EnergyUomType(Enum):
    GJ = "GJ"
    K_BTU_THOUSAND_BTU = "kBtu (thousand Btu)"
    K_WH_THOUSAND_WATT_HOURS = "kWh (thousand Watt-hours)"
    MBTU_MILLION_BTU = "MBtu (million Btu)"
    MWH_MILLION_WATT_HOURS = "MWh (million Watt-hours)"
