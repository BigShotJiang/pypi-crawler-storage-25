from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .all_energy_meters_type import AllEnergyMetersType
from .design_unit_of_measure import DesignUnitOfMeasure


@dataclass(kw_only=True)
class EstimatedEnergyType:
    """
    :ivar energy_type:
    :ivar energy_unit:
    :ivar estimated_annual_energy_usage:
    :ivar energy_rate_cost: The energy rate is the price of energy per
        unit.  This is the price. If provided, you must also provide the
        energyRateCostUnit.
    :ivar energy_rate_cost_unit: The energy rate is the price of energy
        per unit.  This is the unit. If provided, you must also provide
        the energyRateCost.
    """

    class Meta:
        name = "estimatedEnergyType"

    energy_type: AllEnergyMetersType = field(
        metadata={
            "name": "energyType",
            "type": "Element",
        }
    )
    energy_unit: DesignUnitOfMeasure = field(
        metadata={
            "name": "energyUnit",
            "type": "Element",
        }
    )
    estimated_annual_energy_usage: Decimal = field(
        metadata={
            "name": "estimatedAnnualEnergyUsage",
            "type": "Element",
        }
    )
    energy_rate_cost: None | Decimal = field(
        default=None,
        metadata={
            "name": "energyRateCost",
            "type": "Element",
        },
    )
    energy_rate_cost_unit: None | DesignUnitOfMeasure = field(
        default=None,
        metadata={
            "name": "energyRateCostUnit",
            "type": "Element",
        },
    )
