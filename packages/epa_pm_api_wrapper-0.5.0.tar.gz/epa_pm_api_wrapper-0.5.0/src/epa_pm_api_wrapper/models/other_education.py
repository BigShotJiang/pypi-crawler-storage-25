from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherEducation(OtherType):
    """
    Buildings used for religious, community, or other educational purposes
    not described in the available property uses in Portfolio Manager (i.e.
    educational purposes other than adult education, college/university,
    K-12 school, pre-school/daycare and vocational schools).
    """

    class Meta:
        name = "otherEducation"
