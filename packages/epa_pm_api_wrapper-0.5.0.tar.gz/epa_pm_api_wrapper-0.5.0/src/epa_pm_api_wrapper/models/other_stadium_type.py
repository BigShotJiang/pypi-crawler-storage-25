from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .other_stadium_type_use_details import OtherStadiumTypeUseDetails


@dataclass(kw_only=True)
class OtherStadiumType:
    class Meta:
        name = "otherStadiumType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: OtherStadiumTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
