from __future__ import annotations

from enum import Enum


class AdditionalIdentifierTypeGroup(Enum):
    CITY_TOWN = "CITY_TOWN"
    COUNTY_DISTRICT = "COUNTY_DISTRICT"
    STATE_PROVINCE = "STATE_PROVINCE"
    OTHER = "OTHER"
