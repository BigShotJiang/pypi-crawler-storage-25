from __future__ import annotations

from dataclasses import dataclass

from .medical_office_type import MedicalOfficeType


@dataclass(kw_only=True)
class MedicalOffice(MedicalOfficeType):
    """
    Medical Office Buildings used to provide diagnosis and treatment for
    medical, dental, or psychiatric outpatient care.
    """

    class Meta:
        name = "medicalOffice"
