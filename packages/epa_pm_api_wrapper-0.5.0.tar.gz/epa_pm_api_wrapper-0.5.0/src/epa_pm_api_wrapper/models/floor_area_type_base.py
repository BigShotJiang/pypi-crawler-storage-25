from __future__ import annotations

from dataclasses import dataclass, field

from .gross_floor_area_units_type import GrossFloorAreaUnitsType
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class FloorAreaTypeBase(UseAttributeBase):
    """
    :ivar units: The units of the Gross Floor Area (Square Foot or
        Square Meter).
    """

    class Meta:
        name = "floorAreaTypeBase"

    units: GrossFloorAreaUnitsType = field(
        metadata={
            "type": "Attribute",
        }
    )
