from __future__ import annotations

from dataclasses import dataclass

from .fast_food_restaurant_type import FastFoodRestaurantType


@dataclass(kw_only=True)
class FastFoodRestaurant(FastFoodRestaurantType):
    """
    Buildings used for the preparation and sale of ready-to-eat food.

    Also known as Quick Service Restaurant.
    """

    class Meta:
        name = "fastFoodRestaurant"
