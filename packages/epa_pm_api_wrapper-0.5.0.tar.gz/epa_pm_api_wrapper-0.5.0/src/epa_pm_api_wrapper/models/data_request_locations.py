from __future__ import annotations

from dataclasses import dataclass, field

from .data_request_locations_location import DataRequestLocationsLocation


@dataclass(kw_only=True)
class DataRequestLocations:
    class Meta:
        global_type = False

    location: list[DataRequestLocationsLocation] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "min_occurs": 1,
        },
    )
