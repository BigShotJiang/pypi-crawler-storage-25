from __future__ import annotations

from dataclasses import dataclass

from .ceiling_height_units_type import CeilingHeightUnitsType


@dataclass(kw_only=True)
class CeilingHeight(CeilingHeightUnitsType):
    """
    The maximum vertical distance measured from floor to ceiling.
    """

    class Meta:
        name = "ceilingHeight"
