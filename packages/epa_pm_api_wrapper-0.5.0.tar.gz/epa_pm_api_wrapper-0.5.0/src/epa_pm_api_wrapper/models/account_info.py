from __future__ import annotations

from dataclasses import dataclass, field

from .address_type import AddressType


@dataclass(kw_only=True)
class AccountInfo:
    class Meta:
        name = "accountInfo"

    first_name: str = field(
        metadata={
            "name": "firstName",
            "type": "Element",
            "namespace": "",
        }
    )
    last_name: str = field(
        metadata={
            "name": "lastName",
            "type": "Element",
            "namespace": "",
        }
    )
    email: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    address: AddressType = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    job_title: str = field(
        metadata={
            "name": "jobTitle",
            "type": "Element",
            "namespace": "",
        }
    )
    phone: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    organization: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
