from __future__ import annotations

from enum import Enum


class DataType(Enum):
    DATE = "date"
    NUMERIC = "numeric"
    STRING = "string"
