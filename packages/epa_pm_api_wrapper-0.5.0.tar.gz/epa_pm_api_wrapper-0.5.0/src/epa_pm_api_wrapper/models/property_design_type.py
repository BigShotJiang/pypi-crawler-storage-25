from __future__ import annotations

from dataclasses import dataclass, field

from .address_type import AddressType
from .gross_floor_area_type import GrossFloorAreaType
from .primary_function_type import PrimaryFunctionType


@dataclass(kw_only=True)
class PropertyDesignType:
    """
    :ivar name: The name of the property.
    :ivar primary_function: The primary function of the property.
    :ivar gross_floor_area: The Gross Floor Area of the property.  The
        id, currentAsOf, and temporary XML attributes are not applicable
        and will be ignored if provided. It is not needed by Target
        Finder.
    :ivar planned_construction_completion_year: The year planned for
        construction completion.
    :ivar address:
    :ivar number_of_buildings: The estimated number of buildings for
        this property.  Please note that this is only for informational
        purposes.
    """

    class Meta:
        name = "propertyDesignType"

    name: str = field(
        metadata={
            "type": "Element",
            "min_length": 1,
            "max_length": 80,
        }
    )
    primary_function: PrimaryFunctionType = field(
        metadata={
            "name": "primaryFunction",
            "type": "Element",
        }
    )
    gross_floor_area: GrossFloorAreaType = field(
        metadata={
            "name": "grossFloorArea",
            "type": "Element",
        }
    )
    planned_construction_completion_year: int = field(
        metadata={
            "name": "plannedConstructionCompletionYear",
            "type": "Element",
        }
    )
    address: AddressType = field(
        metadata={
            "type": "Element",
        }
    )
    number_of_buildings: int = field(
        metadata={
            "name": "numberOfBuildings",
            "type": "Element",
            "min_inclusive": 0,
        }
    )
