from __future__ import annotations

from dataclasses import dataclass

from .alerts_type import AlertsType


@dataclass(kw_only=True)
class Alerts(AlertsType):
    """
    All alerts that explain why the property cannot receive an ENERGY STAR
    score for the period ending date provided.
    """

    class Meta:
        name = "alerts"
