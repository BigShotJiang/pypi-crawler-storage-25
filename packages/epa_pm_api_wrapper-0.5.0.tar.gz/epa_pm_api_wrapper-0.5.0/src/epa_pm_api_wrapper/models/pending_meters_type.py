from __future__ import annotations

from dataclasses import dataclass, field

from .custom_field_list import CustomFieldList
from .log_type import LogType
from .meter_type import MeterType
from .property_type import PropertyType
from .share_level_type import ShareLevelType
from .type_of_waste_meter import TypeOfWasteMeter


@dataclass(kw_only=True)
class PendingMetersType:
    """
    :ivar meter_id: The id of the meter.
    :ivar property_id: The id of the corresponding property.
    :ivar account_id: The id to the account requesting the meter share.
    :ivar username: The username of the Portfolio Manager Account
        requesting the meter share.
    :ivar custom_field_list:
    :ivar access_level: The level of access for the meter share request:
        Read or Read Write
    :ivar property_info:
    :ivar meter_info:
    :ivar waste_meter_info:
    :ivar share_audit:
    """

    class Meta:
        name = "pendingMetersType"

    meter_id: int = field(
        metadata={
            "name": "meterId",
            "type": "Element",
            "namespace": "",
        }
    )
    property_id: int = field(
        metadata={
            "name": "propertyId",
            "type": "Element",
            "namespace": "",
        }
    )
    account_id: int = field(
        metadata={
            "name": "accountId",
            "type": "Element",
            "namespace": "",
        }
    )
    username: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
        }
    )
    custom_field_list: None | CustomFieldList = field(
        default=None,
        metadata={
            "name": "customFieldList",
            "type": "Element",
        },
    )
    access_level: ShareLevelType = field(
        metadata={
            "name": "accessLevel",
            "type": "Element",
            "namespace": "",
        }
    )
    property_info: PropertyType = field(
        metadata={
            "name": "propertyInfo",
            "type": "Element",
            "namespace": "",
        }
    )
    meter_info: None | MeterType = field(
        default=None,
        metadata={
            "name": "meterInfo",
            "type": "Element",
            "namespace": "",
        },
    )
    waste_meter_info: None | TypeOfWasteMeter = field(
        default=None,
        metadata={
            "name": "wasteMeterInfo",
            "type": "Element",
            "namespace": "",
        },
    )
    share_audit: None | LogType = field(
        default=None,
        metadata={
            "name": "shareAudit",
            "type": "Element",
            "namespace": "",
        },
    )
