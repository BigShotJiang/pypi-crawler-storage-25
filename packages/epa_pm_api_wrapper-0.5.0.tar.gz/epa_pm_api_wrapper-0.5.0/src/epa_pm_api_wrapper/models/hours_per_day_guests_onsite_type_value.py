from __future__ import annotations

from enum import Enum


class HoursPerDayGuestsOnsiteTypeValue(Enum):
    LESS_THAN_15 = "Less Than 15"
    VALUE_15_TO_19 = "15 To 19"
    MORE_THAN_20 = "More Than 20"
