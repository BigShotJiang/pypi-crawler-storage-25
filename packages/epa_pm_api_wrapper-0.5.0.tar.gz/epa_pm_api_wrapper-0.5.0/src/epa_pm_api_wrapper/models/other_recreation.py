from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherRecreation(OtherType):
    """
    Buildings primarily used for recreation that do not meet the definition
    of any other property use defined in Portfolio Manager.
    """

    class Meta:
        name = "otherRecreation"
