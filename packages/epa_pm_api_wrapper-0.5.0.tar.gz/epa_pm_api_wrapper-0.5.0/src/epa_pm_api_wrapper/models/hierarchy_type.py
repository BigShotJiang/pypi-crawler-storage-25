from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class HierarchyType:
    """
    :ivar account_id: Id of the Property Data Administrator
    :ivar username: Username of the Property Data Administrator
    :ivar property_id: Id of the property
    :ivar property_use_id: Id of the property use
    :ivar use_detail_id: Id of the use detail record
    :ivar meter_id: Id of the meter
    :ivar consumption_data_id: Id of the consumption data record
    :ivar waste_meter_data_id: Id of the waste meter data record
    """

    class Meta:
        name = "hierarchyType"

    account_id: None | int = field(
        default=None,
        metadata={
            "name": "accountId",
            "type": "Element",
            "namespace": "",
        },
    )
    username: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    property_id: None | int = field(
        default=None,
        metadata={
            "name": "propertyId",
            "type": "Element",
            "namespace": "",
        },
    )
    property_use_id: None | int = field(
        default=None,
        metadata={
            "name": "propertyUseId",
            "type": "Element",
            "namespace": "",
        },
    )
    use_detail_id: None | int = field(
        default=None,
        metadata={
            "name": "useDetailId",
            "type": "Element",
            "namespace": "",
        },
    )
    meter_id: None | int = field(
        default=None,
        metadata={
            "name": "meterId",
            "type": "Element",
            "namespace": "",
        },
    )
    consumption_data_id: None | int = field(
        default=None,
        metadata={
            "name": "consumptionDataId",
            "type": "Element",
            "namespace": "",
        },
    )
    waste_meter_data_id: None | int = field(
        default=None,
        metadata={
            "name": "wasteMeterDataId",
            "type": "Element",
            "namespace": "",
        },
    )
