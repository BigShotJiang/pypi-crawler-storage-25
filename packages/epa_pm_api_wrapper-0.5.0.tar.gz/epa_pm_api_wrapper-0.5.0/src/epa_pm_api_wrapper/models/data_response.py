from __future__ import annotations

from dataclasses import dataclass, field

from .data_response_properties import DataResponseProperties
from .timeframe_type import TimeframeType


@dataclass(kw_only=True)
class DataResponse:
    """
    :ivar data_request_id: The id of the corresponding data request.
    :ivar timeframe: The timeframe the data response will be run
        against.
    :ivar properties: The list of properties that the data response will
        be run for.
    :ivar id: The unique identifier of the data response.
    """

    class Meta:
        name = "dataResponse"

    data_request_id: None | int = field(
        default=None,
        metadata={
            "name": "dataRequestId",
            "type": "Element",
        },
    )
    timeframe: None | TimeframeType = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    properties: None | DataResponseProperties = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    id: None | int = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
