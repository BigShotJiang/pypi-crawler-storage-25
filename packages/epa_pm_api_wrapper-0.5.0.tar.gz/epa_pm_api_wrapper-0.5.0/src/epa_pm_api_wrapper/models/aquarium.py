from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class Aquarium(OtherType):
    """
    Buildings used to provide aquatic habitat primarily to live animals and
    which may include public or private viewing areas and educational
    programs.
    """

    class Meta:
        name = "aquarium"
