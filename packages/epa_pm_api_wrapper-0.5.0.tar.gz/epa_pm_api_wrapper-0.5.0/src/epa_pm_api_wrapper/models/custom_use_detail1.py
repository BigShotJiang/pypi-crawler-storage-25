from __future__ import annotations

from dataclasses import dataclass

from .custom_use_details_type import CustomUseDetailsType


@dataclass(kw_only=True)
class CustomUseDetail1(CustomUseDetailsType):
    """
    Custom Use Detail #1.
    """

    class Meta:
        name = "customUseDetail1"
