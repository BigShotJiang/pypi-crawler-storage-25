from __future__ import annotations

from dataclasses import dataclass

from .financial_office_type import FinancialOfficeType


@dataclass(kw_only=True)
class FinancialOffice(FinancialOfficeType):
    """
    Buildings used for financial services such as bank headquarters and
    securities and brokerage firms.
    """

    class Meta:
        name = "financialOffice"
