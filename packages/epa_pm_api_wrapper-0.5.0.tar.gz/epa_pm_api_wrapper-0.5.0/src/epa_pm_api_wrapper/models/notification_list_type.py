from __future__ import annotations

from dataclasses import dataclass, field

from .notification_type import NotificationType


@dataclass(kw_only=True)
class NotificationListType:
    class Meta:
        name = "notificationListType"

    notification: list[NotificationType] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
