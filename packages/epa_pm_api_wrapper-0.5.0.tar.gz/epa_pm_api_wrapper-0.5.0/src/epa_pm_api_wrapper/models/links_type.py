from __future__ import annotations

from dataclasses import dataclass, field

from .link_type import LinkType


@dataclass(kw_only=True)
class LinksType:
    class Meta:
        name = "linksType"

    link: list[LinkType] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
