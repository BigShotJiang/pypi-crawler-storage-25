from __future__ import annotations

from dataclasses import dataclass, field

from .custom_field_list_custom_field import CustomFieldListCustomField


@dataclass(kw_only=True)
class CustomFieldList:
    class Meta:
        name = "customFieldList"

    custom_field: list[CustomFieldListCustomField] = field(
        default_factory=list,
        metadata={
            "name": "customField",
            "type": "Element",
            "namespace": "",
        },
    )
