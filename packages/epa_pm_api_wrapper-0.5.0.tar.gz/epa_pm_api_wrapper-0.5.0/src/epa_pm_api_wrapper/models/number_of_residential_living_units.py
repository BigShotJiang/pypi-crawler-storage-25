from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class NumberOfResidentialLivingUnits(UseDecimalType):
    """
    Total number of residential living units (apartments or condominiums)
    at the property.

    This value must equal the sum of the number of residential living units
    in a low-rise setting, mid-rise setting, and high-rise setting. A 0.9
    tolerance is allowed.
    """

    class Meta:
        name = "numberOfResidentialLivingUnits"
