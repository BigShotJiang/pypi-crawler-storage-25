from __future__ import annotations

from dataclasses import dataclass

from .pool_type import PoolType


@dataclass(kw_only=True)
class PoolLocation(PoolType):
    """
    Indication of whether a pool is indoor or outdoor.
    """

    class Meta:
        name = "poolLocation"
