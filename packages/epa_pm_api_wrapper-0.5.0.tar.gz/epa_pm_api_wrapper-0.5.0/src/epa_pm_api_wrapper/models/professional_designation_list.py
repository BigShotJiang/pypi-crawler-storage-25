from __future__ import annotations

from dataclasses import dataclass, field

from .professional_designation_list_professional_designation import (
    ProfessionalDesignationListProfessionalDesignation,
)


@dataclass(kw_only=True)
class ProfessionalDesignationList:
    class Meta:
        name = "professionalDesignationList"

    professional_designation: list[ProfessionalDesignationListProfessionalDesignation] = field(
        default_factory=list,
        metadata={
            "name": "professionalDesignation",
            "type": "Element",
            "min_occurs": 1,
            "max_occurs": 6,
        },
    )
