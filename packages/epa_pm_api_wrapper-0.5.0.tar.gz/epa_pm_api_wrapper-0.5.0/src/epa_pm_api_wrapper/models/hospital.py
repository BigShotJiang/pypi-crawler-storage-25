from __future__ import annotations

from dataclasses import dataclass

from .hospital_type import HospitalType


@dataclass(kw_only=True)
class Hospital(HospitalType):
    """
    A general medical and surgical hospital (including critical access
    hospitals and children’s hospitals).

    These facilities provide acute care services intended to treat patients
    for short periods of time, including emergency medical care,
    physician's office services, diagnostic care, ambulatory care, surgical
    care, and limited specialty services such as rehabilitation and cancer
    care.
    """

    class Meta:
        name = "hospital"
