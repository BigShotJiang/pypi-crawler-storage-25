from __future__ import annotations

from dataclasses import dataclass, field

from .report_properties import ReportProperties
from .report_status_type import ReportStatusType
from .report_type import ReportType
from .timeframe_type import TimeframeType


@dataclass(kw_only=True)
class Report:
    """
    :ivar id: The unique identifier of the report.
    :ivar type_value: The type of report.
    :ivar timeframe: The timeframe the report will be run against.
    :ivar template_id: The id of the template.
    :ivar template_name: The name of the template.
    :ivar properties: The list of properties that the report will be run
        for. EPA does **not** treat an empty or missing ``properties`` as
        "all properties on the account" — generating such a report
        succeeds but produces ``<numberOfProperties>0</numberOfProperties>``
        and no per-property data. Populate ``properties.id`` explicitly
        before calling ``report.generate()``.
    :ivar report_generation_status: The current generation status of the
        report.
    """

    class Meta:
        name = "report"

    id: None | int = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    type_value: None | ReportType = field(
        default=None,
        metadata={
            "name": "type",
            "type": "Element",
        },
    )
    timeframe: TimeframeType = field(
        metadata={
            "type": "Element",
        }
    )
    template_id: None | int = field(
        default=None,
        metadata={
            "name": "templateId",
            "type": "Element",
        },
    )
    template_name: None | str = field(
        default=None,
        metadata={
            "name": "templateName",
            "type": "Element",
        },
    )
    properties: None | ReportProperties = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    report_generation_status: None | ReportStatusType = field(
        default=None,
        metadata={
            "name": "reportGenerationStatus",
            "type": "Element",
        },
    )
