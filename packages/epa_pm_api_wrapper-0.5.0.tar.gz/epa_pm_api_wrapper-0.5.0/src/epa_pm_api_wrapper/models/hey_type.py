from __future__ import annotations

from dataclasses import dataclass, field

from .hey_type_meter import HeyTypeMeter
from .hey_type_property_info import HeyTypePropertyInfo


@dataclass(kw_only=True)
class HeyType:
    class Meta:
        name = "heyType"

    property_info: HeyTypePropertyInfo = field(
        metadata={
            "name": "propertyInfo",
            "type": "Element",
            "namespace": "",
        }
    )
    meter: list[HeyTypeMeter] = field(
        default_factory=list,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_occurs": 1,
            "max_occurs": 10,
        },
    )
