from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class Ped:
    class Meta:
        name = "ped"

    month: int = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": 1,
            "max_inclusive": 12,
        }
    )
    year: int = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_inclusive": 1990,
            "max_inclusive": 2099,
        }
    )
