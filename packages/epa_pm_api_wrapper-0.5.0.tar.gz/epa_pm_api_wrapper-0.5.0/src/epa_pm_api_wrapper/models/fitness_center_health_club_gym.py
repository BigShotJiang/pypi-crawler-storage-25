from __future__ import annotations

from dataclasses import dataclass, field

from .fitness_center_health_club_gym_use_details import (
    FitnessCenterHealthClubGymUseDetails,
)
from .log_type import LogType


@dataclass(kw_only=True)
class FitnessCenterHealthClubGym:
    """
    Buildings used for recreational or professional athletic training and
    related activities.
    """

    class Meta:
        name = "fitnessCenterHealthClubGym"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: FitnessCenterHealthClubGymUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
