from __future__ import annotations

from dataclasses import dataclass, field

from .offsite_green_power_purchase_type_amount_purchased_percentage import (
    OffsiteGreenPowerPurchaseTypeAmountPurchasedPercentage,
)
from .offsite_green_power_purchase_type_amount_purchased_quantity import (
    OffsiteGreenPowerPurchaseTypeAmountPurchasedQuantity,
)


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchaseTypeAmountPurchased:
    class Meta:
        global_type = False

    quantity: None | OffsiteGreenPowerPurchaseTypeAmountPurchasedQuantity = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    percentage: None | OffsiteGreenPowerPurchaseTypeAmountPurchasedPercentage = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
