from __future__ import annotations

from dataclasses import dataclass

from .college_university_type import CollegeUniversityType


@dataclass(kw_only=True)
class CollegeUniversity(CollegeUniversityType):
    """
    Buildings used for the purpose of higher education.
    """

    class Meta:
        name = "collegeUniversity"
