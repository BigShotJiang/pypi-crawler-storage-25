from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .green_power_fuel_source_enum import GreenPowerFuelSourceEnum


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchaseTypeFuelSourcesFuelSource:
    """
    :ivar type_value: The type of the fuel sources.
    :ivar percentage: The percentage of the fuel source.
    """

    class Meta:
        global_type = False

    type_value: GreenPowerFuelSourceEnum = field(
        metadata={
            "name": "type",
            "type": "Element",
            "namespace": "",
        }
    )
    percentage: None | Decimal = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_exclusive": Decimal("0"),
            "max_inclusive": Decimal("100"),
            "fraction_digits": 1,
        },
    )
