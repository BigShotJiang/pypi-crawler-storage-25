from __future__ import annotations

from dataclasses import dataclass, field

from .property_type import PropertyType


@dataclass(kw_only=True)
class Building(PropertyType):
    class Meta:
        name = "building"

    # `numberOfBuildings` is inherited from PropertyType because the XSD
    # declares <building> as `propertyType` — but the EPA's runtime rejects
    # the element on a <building> with HTTP 400 ("unexpected element ...
    # numberOfBuildings"). Suppress it so the field can't reach the wire,
    # and remove it from __init__ so callers who try to set it fail loudly
    # instead of getting an opaque 400. `default=None` keeps response
    # parsing tolerant in case a future EPA release ever does include it.
    number_of_buildings: None | int = field(
        default=None,
        init=False,
        metadata={"type": "Ignore"},
    )
