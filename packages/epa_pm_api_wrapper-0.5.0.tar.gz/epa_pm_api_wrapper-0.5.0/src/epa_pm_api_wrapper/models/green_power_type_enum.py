from __future__ import annotations

from enum import Enum


class GreenPowerTypeEnum(Enum):
    COMMUNITY_CHOICE_AGGREGATION = "Community Choice Aggregation"
    COMMUNITY_SOLAR = "Community Solar"
    COMPETITIVE_PRODUCT_DIRECT_PURCHASE = "Competitive Product (direct purchase)"
    FINANCIAL_VIRTUAL_PPA = "Financial/Virtual PPA"
    PHYSICAL_PPA = "Physical PPA"
    UNBUNDLED_RECS = "Unbundled RECs"
    UTILITY_GREEN_TARIFF = "Utility Green Tariff"
    UTILITY_PRODUCT = "Utility Product"
    UNKNOWN = "Unknown"
