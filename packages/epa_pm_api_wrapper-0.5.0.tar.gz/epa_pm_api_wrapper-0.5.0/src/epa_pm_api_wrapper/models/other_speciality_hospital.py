from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherSpecialityHospital(OtherType):
    """
    Long-term acute care hospitals, inpatient rehabilitation facilities,
    including Cancer Centers and Psychiatric and Substance Abuse
    Hospitals/Facilities.
    """

    class Meta:
        name = "otherSpecialityHospital"
