from __future__ import annotations

from enum import Enum


class LengthUnitsType(Enum):
    FEET = "Feet"
    METERS = "Meters"
