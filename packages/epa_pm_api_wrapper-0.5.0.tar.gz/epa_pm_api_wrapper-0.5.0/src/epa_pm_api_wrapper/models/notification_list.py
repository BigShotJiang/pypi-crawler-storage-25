from __future__ import annotations

from dataclasses import dataclass

from .notification_list_type import NotificationListType


@dataclass(kw_only=True)
class NotificationList(NotificationListType):
    """
    Contains the list of notifications that indicate an account, property,
    or meter is no longer accessible.
    """

    class Meta:
        name = "notificationList"
