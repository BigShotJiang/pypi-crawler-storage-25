from __future__ import annotations

from dataclasses import dataclass, field

from .address_type import AddressType
from .agency_type import AgencyType
from .construction_status_type import ConstructionStatusType
from .country_list import CountryList
from .gross_floor_area_type import GrossFloorAreaType
from .irrigation_area_type import IrrigationAreaType
from .log_type import LogType
from .occupancy_type import OccupancyType
from .primary_function_type import PrimaryFunctionType
from .share_level_type import ShareLevelType


@dataclass(kw_only=True)
class PropertyType:
    """
    :ivar name: The name of the property.
    :ivar construction_status: The construction status (either existing,
        design or test project).
    :ivar primary_function: The primary function of the building.
    :ivar gross_floor_area: The Gross Floor Area
    :ivar irrigated_area: The Irrigated Area
    :ivar year_built: The year the property was built.
    :ivar address:
    :ivar number_of_buildings: The estimated number of buildings for
        this property.
    :ivar is_federal_property: Whether the property is federally owned.
    :ivar federal_owner: The property physical address - country.
    :ivar agency: The federal agency that owns or operates the building.
    :ivar agency_department_region: Optional additional information
        about the federal department or region.
    :ivar federal_campus: Name of the Federal Campus
    :ivar occupancy_percentage: The percentage occupancy of the
        property.
    :ivar notes: Notes about this property.
    :ivar is_institutional_property: Whether the property is
        institutional property.
    :ivar access_level: Current share level for the user calling the
        webservice.
    :ivar audit:
    """

    class Meta:
        name = "propertyType"

    name: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 80,
        },
    )
    construction_status: None | ConstructionStatusType = field(
        default=None,
        metadata={
            "name": "constructionStatus",
            "type": "Element",
            "namespace": "",
        },
    )
    primary_function: None | PrimaryFunctionType = field(
        default=None,
        metadata={
            "name": "primaryFunction",
            "type": "Element",
            "namespace": "",
        },
    )
    gross_floor_area: None | GrossFloorAreaType = field(
        default=None,
        metadata={
            "name": "grossFloorArea",
            "type": "Element",
            "namespace": "",
        },
    )
    irrigated_area: None | IrrigationAreaType = field(
        default=None,
        metadata={
            "name": "irrigatedArea",
            "type": "Element",
            "namespace": "",
        },
    )
    year_built: None | int = field(
        default=None,
        metadata={
            "name": "yearBuilt",
            "type": "Element",
            "namespace": "",
        },
    )
    address: None | AddressType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    number_of_buildings: None | int = field(
        default=None,
        metadata={
            "name": "numberOfBuildings",
            "type": "Element",
            "namespace": "",
        },
    )
    is_federal_property: bool = field(
        metadata={
            "name": "isFederalProperty",
            "type": "Element",
            "namespace": "",
        }
    )
    federal_owner: None | CountryList = field(
        default=None,
        metadata={
            "name": "federalOwner",
            "type": "Element",
            "namespace": "",
        },
    )
    agency: None | AgencyType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    agency_department_region: None | str = field(
        default=None,
        metadata={
            "name": "agencyDepartmentRegion",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 200,
        },
    )
    federal_campus: None | str = field(
        default=None,
        metadata={
            "name": "federalCampus",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 200,
        },
    )
    occupancy_percentage: OccupancyType = field(
        metadata={
            "name": "occupancyPercentage",
            "type": "Element",
            "namespace": "",
        }
    )
    notes: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
        },
    )
    is_institutional_property: None | bool = field(
        default=None,
        metadata={
            "name": "isInstitutionalProperty",
            "type": "Element",
            "namespace": "",
        },
    )
    access_level: None | ShareLevelType = field(
        default=None,
        metadata={
            "name": "accessLevel",
            "type": "Element",
            "namespace": "",
        },
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
