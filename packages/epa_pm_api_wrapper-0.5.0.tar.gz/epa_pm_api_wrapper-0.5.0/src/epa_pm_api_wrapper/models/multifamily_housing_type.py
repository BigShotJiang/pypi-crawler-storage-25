from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .multifamily_housing_type_use_details import (
    MultifamilyHousingTypeUseDetails,
)


@dataclass(kw_only=True)
class MultifamilyHousingType:
    class Meta:
        name = "multifamilyHousingType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: MultifamilyHousingTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
