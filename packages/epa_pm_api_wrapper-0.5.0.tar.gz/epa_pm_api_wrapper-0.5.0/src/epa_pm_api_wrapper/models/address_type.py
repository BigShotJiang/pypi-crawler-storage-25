from __future__ import annotations

from dataclasses import dataclass, field

from .address_type_state import AddressTypeState
from .country_list import CountryList


@dataclass(kw_only=True)
class AddressType:
    """
    :ivar address1: The property physical address  - line 1.
    :ivar address2: The property physical address  - line 2.
    :ivar city: The property physical address - city.
    :ivar county: The property physical address - county.
    :ivar postal_code: The property physical address - postal code/zip
        code.
    :ivar state: The property physical address - state or province.
    :ivar other_state: The property physical address - state or province
        (when not US/Canada).
    :ivar country: The property physical address - country.
    """

    class Meta:
        name = "addressType"

    address1: str = field(
        metadata={
            "type": "Attribute",
            "min_length": 1,
            "max_length": 100,
        }
    )
    address2: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
            "min_length": 1,
            "max_length": 100,
        },
    )
    city: str = field(
        metadata={
            "type": "Attribute",
            "min_length": 1,
            "max_length": 100,
        }
    )
    county: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
            "min_length": 1,
            "max_length": 40,
        },
    )
    postal_code: str = field(
        metadata={
            "name": "postalCode",
            "type": "Attribute",
            "min_length": 1,
            "max_length": 20,
        }
    )
    state: None | AddressTypeState = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    other_state: None | str = field(
        default=None,
        metadata={
            "name": "otherState",
            "type": "Attribute",
            "min_length": 1,
            "max_length": 50,
        },
    )
    country: CountryList = field(
        metadata={
            "type": "Attribute",
        }
    )
