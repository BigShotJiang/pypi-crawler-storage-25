from __future__ import annotations

from dataclasses import dataclass

from .meter_consumption_type import MeterConsumptionType


@dataclass(kw_only=True)
class MeterConsumption(MeterConsumptionType):
    """
    Consumption data used for a meter that is set up to be metered.
    """

    class Meta:
        name = "meterConsumption"
