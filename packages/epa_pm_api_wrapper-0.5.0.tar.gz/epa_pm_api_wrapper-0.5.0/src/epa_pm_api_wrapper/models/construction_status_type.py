from __future__ import annotations

from enum import Enum


class ConstructionStatusType(Enum):
    EXISTING = "Existing"
    PROJECT = "Project"
    TEST = "Test"
