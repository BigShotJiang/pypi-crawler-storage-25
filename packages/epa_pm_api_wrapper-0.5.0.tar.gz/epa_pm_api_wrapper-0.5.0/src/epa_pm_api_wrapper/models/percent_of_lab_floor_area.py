from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class PercentOfLabFloorArea(UseIntegerType):
    """
    The percentage of the floor area of this campus that is specialized
    instruction or research space that caters to specific uses.
    """

    class Meta:
        name = "percentOfLabFloorArea"
