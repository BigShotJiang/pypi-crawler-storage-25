from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .offsite_green_power_purchase_type_amount_purchased_percentage_meters import (
    OffsiteGreenPowerPurchaseTypeAmountPurchasedPercentageMeters,
)


@dataclass(kw_only=True)
class OffsiteGreenPowerPurchaseTypeAmountPurchasedPercentage:
    """
    :ivar value: The percentage purchased.
    :ivar include_all_meters: Flag to indicate if all electric meters
        are included.
    :ivar meters: The list of electric meters included if
        includeAllMeters is false.
    """

    class Meta:
        global_type = False

    value: Decimal = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_exclusive": Decimal("0"),
            "max_inclusive": Decimal("100"),
            "fraction_digits": 1,
        }
    )
    include_all_meters: bool = field(
        metadata={
            "name": "includeAllMeters",
            "type": "Element",
            "namespace": "",
        }
    )
    meters: None | OffsiteGreenPowerPurchaseTypeAmountPurchasedPercentageMeters = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
