from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherMall(OtherType):
    """
    Buildings containing a collection of stores whose purpose is the sale
    of goods, but which do not fit into the enclosed mall, lifestyle
    center, or strip mall property types.
    """

    class Meta:
        name = "otherMall"
