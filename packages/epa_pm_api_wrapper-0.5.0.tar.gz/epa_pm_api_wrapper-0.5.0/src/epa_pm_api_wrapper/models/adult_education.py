from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class AdultEducation(OtherType):
    """
    Buildings used primarily for providing adult students with continuing
    education, workforce development, or professional development outside
    of the college or university setting.
    """

    class Meta:
        name = "adultEducation"
