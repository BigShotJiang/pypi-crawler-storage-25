from __future__ import annotations

from dataclasses import dataclass

from .use_yes_no_type import UseYesNoType


@dataclass(kw_only=True)
class OpenOnWeekends(UseYesNoType):
    """
    Indication of regular activities that occur on either Saturday or
    Sunday (Yes/No).
    """

    class Meta:
        name = "openOnWeekends"
