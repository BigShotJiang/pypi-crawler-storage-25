from __future__ import annotations

from enum import Enum


class PoolTypeValue(Enum):
    INDOOR = "Indoor"
    OUTDOOR = "Outdoor"
