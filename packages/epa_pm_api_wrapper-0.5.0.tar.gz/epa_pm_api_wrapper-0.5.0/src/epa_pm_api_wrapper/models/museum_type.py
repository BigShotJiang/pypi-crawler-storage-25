from __future__ import annotations

from dataclasses import dataclass, field

from .log_type import LogType
from .museum_type_use_details import MuseumTypeUseDetails


@dataclass(kw_only=True)
class MuseumType:
    class Meta:
        name = "museumType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: MuseumTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
