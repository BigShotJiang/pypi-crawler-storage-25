from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class Enrollment(UseDecimalType):
    class Meta:
        name = "enrollment"
