from __future__ import annotations

from dataclasses import dataclass, field

from xsdata.models.datatype import XmlDateTime

from .report_error_missing_metrics import ReportErrorMissingMetrics


@dataclass(kw_only=True)
class ReportError:
    """
    :ivar report_id: The id of the report.
    :ivar template_name: The name of the template.
    :ivar date_generated: The timestamp when the report was generated
    :ivar number_of_properties: The total count of the properties in the
        report
    :ivar missing_metrics:
    """

    class Meta:
        name = "reportError"

    report_id: int = field(
        metadata={
            "name": "reportId",
            "type": "Element",
        }
    )
    template_name: str = field(
        metadata={
            "name": "templateName",
            "type": "Element",
        }
    )
    date_generated: XmlDateTime = field(
        metadata={
            "name": "dateGenerated",
            "type": "Element",
        }
    )
    number_of_properties: int = field(
        metadata={
            "name": "numberOfProperties",
            "type": "Element",
        }
    )
    missing_metrics: ReportErrorMissingMetrics = field(
        metadata={
            "name": "missingMetrics",
            "type": "Element",
        }
    )
