from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class DataRequestLocationsLocation:
    class Meta:
        global_type = False

    country: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    state: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
