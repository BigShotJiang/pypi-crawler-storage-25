from __future__ import annotations

from dataclasses import dataclass

from .convenience_store_with_gas_station_type import (
    ConvenienceStoreWithGasStationType,
)


@dataclass(kw_only=True)
class ConvenienceStoreWithGasStation(ConvenienceStoreWithGasStationType):
    """
    Buildings that are co-located with gas stations and are used for the
    sale of a limited range of items such as groceries, toiletries,
    newspapers, soft drinks, tobacco products, and other everyday items.
    """

    class Meta:
        name = "convenienceStoreWithGasStation"
