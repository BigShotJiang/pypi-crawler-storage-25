from __future__ import annotations

from dataclasses import dataclass, field

from .e_grid_subregion import EGridSubregion


@dataclass(kw_only=True)
class EGridSubregionList:
    class Meta:
        name = "eGridSubregionList"

    e_grid_subregion: list[EGridSubregion] = field(
        default_factory=list,
        metadata={
            "name": "eGridSubregion",
            "type": "Element",
        },
    )
