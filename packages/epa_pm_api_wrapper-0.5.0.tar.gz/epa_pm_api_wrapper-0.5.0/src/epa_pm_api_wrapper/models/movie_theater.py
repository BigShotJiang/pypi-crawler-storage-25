from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class MovieTheater(OtherType):
    """
    Buildings used for public or private film screenings.
    """

    class Meta:
        name = "movieTheater"
