from __future__ import annotations

from dataclasses import dataclass

from .use_decimal_type import UseDecimalType


@dataclass(kw_only=True)
class PercentOfGrossFloorAreaThatIsCommonSpaceOnly(UseDecimalType):
    """
    The percent of the Gross Floor Area that is common space (not
    individual tenant areas).
    """

    class Meta:
        name = "percentOfGrossFloorAreaThatIsCommonSpaceOnly"
