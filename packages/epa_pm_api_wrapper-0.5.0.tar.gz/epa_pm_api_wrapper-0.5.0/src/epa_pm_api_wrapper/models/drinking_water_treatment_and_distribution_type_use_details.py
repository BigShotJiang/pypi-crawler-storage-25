from __future__ import annotations

from dataclasses import dataclass, field

from .total_gross_floor_area import TotalGrossFloorArea


@dataclass(kw_only=True)
class DrinkingWaterTreatmentAndDistributionTypeUseDetails:
    class Meta:
        global_type = False

    total_gross_floor_area: TotalGrossFloorArea = field(
        metadata={
            "name": "totalGrossFloorArea",
            "type": "Element",
        }
    )
