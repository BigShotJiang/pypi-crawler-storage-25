from __future__ import annotations

from dataclasses import dataclass

from .optional_floor_area_type import OptionalFloorAreaType


@dataclass(kw_only=True)
class AreaOfAllWalkInRefrigerationUnits(OptionalFloorAreaType):
    """
    Area of all walk-in refrigeration/freezer units - include only
    commercial type units that a person actually walks into to retrieve
    goods.

    See numberOfWalkInRefrigerationUnits for more information.
    """

    class Meta:
        name = "areaOfAllWalkInRefrigerationUnits"
