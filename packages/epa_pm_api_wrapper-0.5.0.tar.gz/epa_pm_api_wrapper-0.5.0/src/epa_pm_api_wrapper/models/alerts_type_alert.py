from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(kw_only=True)
class AlertsTypeAlert:
    """
    :ivar name: The name of the alert.
    :ivar description: The description of the alert.
    """

    class Meta:
        global_type = False

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
        }
    )
    description: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
        }
    )
