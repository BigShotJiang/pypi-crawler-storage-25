from __future__ import annotations

from dataclasses import dataclass

from .baseline_and_target_type import BaselineAndTargetType


@dataclass(kw_only=True)
class BaselineAndTarget(BaselineAndTargetType):
    """
    Baseline dates and performance target settings can be updated for your
    property.
    """

    class Meta:
        name = "baselineAndTarget"
