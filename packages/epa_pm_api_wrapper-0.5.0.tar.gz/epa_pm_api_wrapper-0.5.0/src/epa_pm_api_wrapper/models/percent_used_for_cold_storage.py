from __future__ import annotations

from dataclasses import dataclass

from .use_integer_type import UseIntegerType


@dataclass(kw_only=True)
class PercentUsedForColdStorage(UseIntegerType):
    """
    The total percentage of your property that is enclosed insulated
    storage space intended for the cooling or freezing of goods,
    merchandise, raw materials, or manufactured products in buildings (or
    portions of buildings), at or less than 50 degrees F.
    """

    class Meta:
        name = "percentUsedForColdStorage"
