from __future__ import annotations

from dataclasses import dataclass, field

from .convenience_store_with_gas_station_type_use_details import (
    ConvenienceStoreWithGasStationTypeUseDetails,
)
from .log_type import LogType


@dataclass(kw_only=True)
class ConvenienceStoreWithGasStationType:
    class Meta:
        name = "convenienceStoreWithGasStationType"

    name: str = field(
        metadata={
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        }
    )
    use_details: ConvenienceStoreWithGasStationTypeUseDetails = field(
        metadata={
            "name": "useDetails",
            "type": "Element",
            "namespace": "",
        }
    )
    audit: None | LogType = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
