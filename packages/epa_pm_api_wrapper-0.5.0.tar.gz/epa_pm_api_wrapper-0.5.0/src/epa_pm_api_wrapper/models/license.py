from __future__ import annotations

from dataclasses import dataclass, field

from .country_code import CountryCode
from .state_code import StateCode


@dataclass(kw_only=True)
class License:
    """
    :ivar index: Index number of the stored license details
    :ivar country_code: License country code
    :ivar license_number: License Number for all professional
        designations.
    :ivar license_state: License State Code
    :ivar license_name: License Name for Other
    """

    class Meta:
        name = "license"

    index: None | str = field(
        default=None,
        metadata={
            "type": "Element",
        },
    )
    country_code: None | CountryCode = field(
        default=None,
        metadata={
            "name": "countryCode",
            "type": "Element",
        },
    )
    license_number: None | str = field(
        default=None,
        metadata={
            "name": "licenseNumber",
            "type": "Element",
            "min_length": 1,
            "max_length": 100,
        },
    )
    license_state: None | StateCode = field(
        default=None,
        metadata={
            "name": "licenseState",
            "type": "Element",
        },
    )
    license_name: None | str = field(
        default=None,
        metadata={
            "name": "licenseName",
            "type": "Element",
            "min_length": 1,
            "max_length": 100,
        },
    )
