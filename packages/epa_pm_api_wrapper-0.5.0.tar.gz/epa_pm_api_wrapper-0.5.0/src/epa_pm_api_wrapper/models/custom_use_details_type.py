from __future__ import annotations

from dataclasses import dataclass, field

from .custom_units_type import CustomUnitsType
from .custom_use_details_type_data_type import CustomUseDetailsTypeDataType
from .use_attribute_base import UseAttributeBase


@dataclass(kw_only=True)
class CustomUseDetailsType(UseAttributeBase):
    class Meta:
        name = "customUseDetailsType"

    value: None | str = field(
        default=None,
        metadata={
            "type": "Element",
            "namespace": "",
        },
    )
    custom_name: None | str = field(
        default=None,
        metadata={
            "name": "customName",
            "type": "Element",
            "namespace": "",
        },
    )
    custom_uom: None | str = field(
        default=None,
        metadata={
            "name": "customUom",
            "type": "Element",
            "namespace": "",
        },
    )
    units: None | CustomUnitsType = field(
        default=None,
        metadata={
            "type": "Attribute",
        },
    )
    data_type: None | CustomUseDetailsTypeDataType = field(
        default=None,
        metadata={
            "name": "dataType",
            "type": "Attribute",
        },
    )
