from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class ConventionCenter(OtherType):
    """
    Buildings used primarily for large conferences, exhibitions, and
    similar events.
    """

    class Meta:
        name = "conventionCenter"
