from __future__ import annotations

from dataclasses import dataclass

from .billboard_metrics_type import BillboardMetricsType


@dataclass(kw_only=True)
class BillboardMetrics(BillboardMetricsType):
    class Meta:
        name = "billboardMetrics"
