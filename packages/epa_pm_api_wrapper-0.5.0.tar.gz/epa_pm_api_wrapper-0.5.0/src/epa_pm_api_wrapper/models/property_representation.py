from __future__ import annotations

from dataclasses import dataclass, field

from .property_representation_property_representation_type import (
    PropertyRepresentationPropertyRepresentationType,
)
from .tenant_common_area_energy_use_information_type import (
    TenantCommonAreaEnergyUseInformationType,
)


@dataclass(kw_only=True)
class PropertyRepresentation:
    """
    Indication of what energy is covered by the energy meters you associate
    together for calculations.

    :ivar property_representation_type: Indication of what energy is
        covered by the energy meters you associate together for
        calculations
    :ivar tenant_common_area_energy_use_list: Indicates the various
        energy uses if a "Combination of Tenant and Common Area
        Consumption" property representation type is selected. This is
        only required when "Combination of Tenant and Common Area
        Consumption" is specified. At least one of the 8 options must be
        selected.
    :ivar property_representation_type_other_desc: If you chose "Other"
        for the property representation, this is the description.
    """

    class Meta:
        name = "propertyRepresentation"

    property_representation_type: PropertyRepresentationPropertyRepresentationType = field(
        metadata={
            "name": "propertyRepresentationType",
            "type": "Element",
            "namespace": "",
        }
    )
    tenant_common_area_energy_use_list: None | TenantCommonAreaEnergyUseInformationType = field(
        default=None,
        metadata={
            "name": "tenantCommonAreaEnergyUseList",
            "type": "Element",
            "namespace": "",
        },
    )
    property_representation_type_other_desc: None | str = field(
        default=None,
        metadata={
            "name": "propertyRepresentationTypeOtherDesc",
            "type": "Element",
            "namespace": "",
            "min_length": 1,
            "max_length": 500,
        },
    )
