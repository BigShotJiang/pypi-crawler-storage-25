from __future__ import annotations

from dataclasses import dataclass

from .other_type import OtherType


@dataclass(kw_only=True)
class OtherPublicServices(OtherType):
    """
    Buildings used by public-sector organizations to provide public
    services other than those described in the available property uses in
    Portfolio Manager (i.e. services other than offices, courthouses,
    drinking water treatment and distribution plants, fire stations,
    libraries, mailing centers or post offices, police stations, prisons or
    incarceration facilities, social or meeting halls, transportation
    terminals or stations, or wastewater treatment plants).
    """

    class Meta:
        name = "otherPublicServices"
