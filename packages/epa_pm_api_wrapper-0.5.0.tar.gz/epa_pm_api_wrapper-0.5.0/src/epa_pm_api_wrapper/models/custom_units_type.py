from __future__ import annotations

from enum import Enum


class CustomUnitsType(Enum):
    FEET = "Feet"
    GALLONS_US = "Gallons (US)"
    GALLONS_UK = "Gallons (UK)"
    KILOGRAM = "Kilogram"
    METERS = "Meters"
    TONNES_METRIC = "Tonnes (metric)"
    OTHER = "Other"
    POUNDS = "Pounds"
    SQUARE_FEET = "Square Feet"
    SQUARE_METERS = "Square Meters"
    TONS_SHORT = "Tons (short)"
    THERMS = "Therms"
    K_WH_THOUSAND_WATT_HOURS = "kWh (thousand Watt-hours)"
