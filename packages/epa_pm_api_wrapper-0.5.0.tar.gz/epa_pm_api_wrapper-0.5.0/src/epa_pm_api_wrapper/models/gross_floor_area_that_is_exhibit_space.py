from __future__ import annotations

from dataclasses import dataclass

from .optional_floor_area_type import OptionalFloorAreaType


@dataclass(kw_only=True)
class GrossFloorAreaThatIsExhibitSpace(OptionalFloorAreaType):
    """
    The Gross Floor Area refers to the total area used for public
    collection display areas.

    It is a subset of the total Gross Floor Area. It should not include
    outdoor public collection display areas.
    """

    class Meta:
        name = "grossFloorAreaThatIsExhibitSpace"
