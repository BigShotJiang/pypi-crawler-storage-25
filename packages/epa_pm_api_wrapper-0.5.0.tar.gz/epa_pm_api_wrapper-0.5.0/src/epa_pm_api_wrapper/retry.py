"""Retry transport for transient HTTP failures.

Wraps an underlying ``httpx`` transport with retry/backoff for the responses
EPA most commonly returns when the system is under stress: 429 (rate limited),
502/503/504 (gateway/upstream errors), and connection-level failures
(``httpx.ConnectError`` / ``httpx.ReadTimeout``). Auth (401) and client-side
4xx errors are *not* retried — they will not change on retry.

Two transports, sync and async, share the same :class:`RetryConfig` and the
same backoff math. The default schedule is exponential with full jitter:
``delay = uniform(0, base * 2**attempt)`` clamped to ``max_delay``. The HTTP
``Retry-After`` header (numeric seconds form) overrides the computed delay
when present.

Transports are stacked: the user-supplied ``transport`` (or the default
``httpx.HTTPTransport`` httpx builds for us) sits inside the retry transport.
This means proxies and other transport-layer customizations still apply.
"""

from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass, field

import httpx

logger = logging.getLogger(__name__)

DEFAULT_RETRY_STATUS_CODES = frozenset({429, 502, 503, 504})


@dataclass(frozen=True)
class RetryConfig:
    """Retry behavior for the client transport layer.

    Pass to ``EpaPmClient(retry=...)`` / ``EpaPmAsyncClient(retry=...)`` to
    override the defaults. Pass ``retries=0`` on the client to disable.

    :ivar max_retries: How many times to retry after the initial attempt
        (default 3 → up to 4 total requests).
    :ivar base_delay: Base for the exponential backoff in seconds.
    :ivar max_delay: Cap on a single backoff sleep, in seconds.
    :ivar retry_status_codes: HTTP status codes treated as transient.
    :ivar respect_retry_after: Honor ``Retry-After`` headers (numeric form)
        when the server provides them, capped at ``max_delay``.
    """

    max_retries: int = 3
    base_delay: float = 0.5
    max_delay: float = 30.0
    retry_status_codes: frozenset[int] = field(default_factory=lambda: DEFAULT_RETRY_STATUS_CODES)
    respect_retry_after: bool = True


def _retryable_status(response: httpx.Response, cfg: RetryConfig) -> bool:
    return response.status_code in cfg.retry_status_codes


def _retry_after_seconds(response: httpx.Response, cfg: RetryConfig) -> float | None:
    """Return the server-suggested delay in seconds, or ``None``.

    Only the numeric form of ``Retry-After`` is honored; HTTP-date form falls
    back to client-side backoff (it requires clock-correlation we'd rather
    not assume).
    """
    if not cfg.respect_retry_after:
        return None
    raw = response.headers.get("retry-after")
    if not raw:
        return None
    try:
        return min(float(raw), cfg.max_delay)
    except ValueError:
        return None


def _backoff_seconds(attempt: int, cfg: RetryConfig) -> float:
    """Exponential backoff with full jitter, capped at ``max_delay``.

    ``attempt`` is 0-indexed (first retry → attempt=0).
    """
    upper = min(cfg.max_delay, cfg.base_delay * (2**attempt))
    return random.uniform(0, upper)


def _delay_for(response: httpx.Response | None, attempt: int, cfg: RetryConfig) -> float:
    """Server-hint delay if available, else backoff."""
    if response is not None:
        hinted = _retry_after_seconds(response, cfg)
        if hinted is not None:
            return hinted
    return _backoff_seconds(attempt, cfg)


_RETRYABLE_EXCEPTIONS: tuple[type[Exception], ...] = (
    httpx.ConnectError,
    httpx.ReadTimeout,
    httpx.WriteTimeout,
    httpx.PoolTimeout,
    httpx.RemoteProtocolError,
)


class RetryTransport(httpx.BaseTransport):
    """Sync retry transport. Wrap an existing transport (or omit for the default)."""

    def __init__(self, wrapped: httpx.BaseTransport | None = None, config: RetryConfig | None = None):
        self._wrapped = wrapped if wrapped is not None else httpx.HTTPTransport()
        self._config = config or RetryConfig()

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        cfg = self._config
        last_exc: Exception | None = None
        for attempt in range(cfg.max_retries + 1):
            try:
                response = self._wrapped.handle_request(request)
            except _RETRYABLE_EXCEPTIONS as exc:
                last_exc = exc
                if attempt >= cfg.max_retries:
                    logger.warning("request to %s failed after %d attempts: %s", request.url, attempt + 1, exc)
                    raise
                delay = _delay_for(None, attempt, cfg)
                logger.info(
                    "retrying %s after %s (attempt %d/%d, sleep %.2fs)",
                    request.url,
                    type(exc).__name__,
                    attempt + 1,
                    cfg.max_retries,
                    delay,
                )
                time.sleep(delay)
                continue

            if attempt >= cfg.max_retries or not _retryable_status(response, cfg):
                return response

            # Drain the body so the connection can be released to the pool.
            response.read()
            response.close()
            delay = _delay_for(response, attempt, cfg)
            logger.info(
                "retrying %s after HTTP %d (attempt %d/%d, sleep %.2fs)",
                request.url,
                response.status_code,
                attempt + 1,
                cfg.max_retries,
                delay,
            )
            time.sleep(delay)

        # Should not be reachable — the loop returns or raises — but mypy/ty
        # want a definite outcome.
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("RetryTransport: unreachable")  # pragma: no cover

    def close(self) -> None:
        self._wrapped.close()


class AsyncRetryTransport(httpx.AsyncBaseTransport):
    """Async retry transport. Wrap an existing transport (or omit for the default)."""

    def __init__(
        self,
        wrapped: httpx.AsyncBaseTransport | None = None,
        config: RetryConfig | None = None,
    ):
        self._wrapped = wrapped if wrapped is not None else httpx.AsyncHTTPTransport()
        self._config = config or RetryConfig()

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        cfg = self._config
        last_exc: Exception | None = None
        for attempt in range(cfg.max_retries + 1):
            try:
                response = await self._wrapped.handle_async_request(request)
            except _RETRYABLE_EXCEPTIONS as exc:
                last_exc = exc
                if attempt >= cfg.max_retries:
                    logger.warning("request to %s failed after %d attempts: %s", request.url, attempt + 1, exc)
                    raise
                delay = _delay_for(None, attempt, cfg)
                logger.info(
                    "retrying %s after %s (attempt %d/%d, sleep %.2fs)",
                    request.url,
                    type(exc).__name__,
                    attempt + 1,
                    cfg.max_retries,
                    delay,
                )
                await asyncio.sleep(delay)
                continue

            if attempt >= cfg.max_retries or not _retryable_status(response, cfg):
                return response

            await response.aread()
            await response.aclose()
            delay = _delay_for(response, attempt, cfg)
            logger.info(
                "retrying %s after HTTP %d (attempt %d/%d, sleep %.2fs)",
                request.url,
                response.status_code,
                attempt + 1,
                cfg.max_retries,
                delay,
            )
            await asyncio.sleep(delay)

        if last_exc is not None:
            raise last_exc
        raise RuntimeError("AsyncRetryTransport: unreachable")  # pragma: no cover

    async def aclose(self) -> None:
        await self._wrapped.aclose()
