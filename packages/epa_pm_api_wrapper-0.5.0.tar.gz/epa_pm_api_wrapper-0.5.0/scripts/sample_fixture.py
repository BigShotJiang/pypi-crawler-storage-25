"""Create + populate + tear down sample properties on the EPA wstest environment.

Usage:
    uv run scripts/sample_fixture.py create [--country US] [--count 1] [--populate]
    uv run scripts/sample_fixture.py populate <property_id>
    uv run scripts/sample_fixture.py delete <property_id> [<property_id> ...]

`create` calls the EPA's server-side ``/createSampleProperties`` endpoint and
prints the new property IDs. With ``--populate``, each created property is then
augmented with extra resources (meters, consumption data, an energy-performance
project, an additional identifier) so a downstream test can exercise more of
the API surface than the EPA samples ship with by default.

`populate` skips the create step and adds the same extras to an existing
property — handy for re-running tests against a known property without
spawning new ones.

`delete` removes the listed properties via DELETE /property/{id}.

Always targets the test environment. Reads ``EPA_PM_USERNAME`` /
``EPA_PM_PASSWORD`` from the shell or a project-root ``.env``.
"""

from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime
from decimal import Decimal

from dotenv import load_dotenv
from xsdata.models.datatype import XmlDate

from epa_pm_api_wrapper import EpaPmApiError, EpaPmClient, MeterConsumption, MeterData
from epa_pm_api_wrapper.models import (
    AdditionalIdentifier,
    EnergyPerformanceProject,
    Meter,
    MeterTypeUnitOfMeasure,
    TypeOfMeter,
)


@dataclass
class PopulateReport:
    """Summary of resources added to one property by ``populate()``.

    Recorded so callers can correlate created IDs with what they sent (and so
    failures partway through don't lose the IDs that did succeed).
    """

    property_id: int
    meter_ids: list[int] = field(default_factory=list)
    consumption_ids: list[int] = field(default_factory=list)
    epp_id: int | None = None
    identifier_id: int | None = None
    failures: list[str] = field(default_factory=list)


def _required_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        print(f"missing required env var {name} — set it or populate .env")
        sys.exit(2)
    return value


def _build_client() -> EpaPmClient:
    load_dotenv(override=True)
    username = _required_env("EPA_PM_USERNAME")
    password = _required_env("EPA_PM_PASSWORD")
    return EpaPmClient(username=username, password=password, use_test_env=True)


def _consumption_records(months: int = 3) -> list[MeterConsumption]:
    """Build ``months`` of monthly consumption records starting Jan of last year.

    Uses fixed-but-non-round values so test assertions can spot rounding /
    precision issues without writing ad-hoc fixtures.
    """
    base_year = datetime.now(UTC).year - 1
    records: list[MeterConsumption] = []
    for i in range(months):
        month = i + 1
        # Dec edge handled by month=12 logic; we only go up to 12 months.
        end_day = 28 if month == 2 else 30
        records.append(
            MeterConsumption(
                start_date=XmlDate(base_year, month, 1),
                end_date=XmlDate(base_year, month, end_day),
                usage=Decimal(f"{1000 + i * 250}.{42 + i}"),
                cost=Decimal(f"{120 + i * 30}.5{i}"),
                estimated_value=False,
            )
        )
    return records


def _add_meter_with_consumption(
    client: EpaPmClient,
    property_id: int,
    name: str,
    meter_type: TypeOfMeter,
    unit: MeterTypeUnitOfMeasure,
    report: PopulateReport,
) -> None:
    """Create one meter and seed it with a few months of consumption.

    Failures are recorded on ``report`` rather than raised so a single bad
    sub-step doesn't take down the whole populate run.
    """
    try:
        create_resp = client.meter.create(
            property_id,
            Meter(
                type_value=meter_type,
                name=name,
                metered=True,
                unit_of_measure=unit,
                first_bill_date=XmlDate(datetime.now(UTC).year - 1, 1, 1),
                in_use=True,
            ),
        )
        meter_id = create_resp.id
        if meter_id is None:
            report.failures.append(f"meter '{name}': create returned no id")
            return
        report.meter_ids.append(meter_id)
        print(f"    + meter '{name}' id={meter_id}")
    except EpaPmApiError as exc:
        report.failures.append(f"meter '{name}': create failed — {exc}")
        return

    try:
        added = client.consumption_data.add(meter_id, MeterData(meter_consumption=_consumption_records(months=3)))
        ids = [r.id for r in (added.meter_consumption or []) if r.id is not None]
        report.consumption_ids.extend(ids)
        print(f"      + {len(ids)} consumption record(s)")
    except EpaPmApiError as exc:
        report.failures.append(f"meter {meter_id}: consumption add failed — {exc}")


def _add_energy_performance_project(client: EpaPmClient, property_id: int, report: PopulateReport) -> None:
    try:
        resp = client.property.energy_performance_project.create(
            property_id,
            EnergyPerformanceProject(
                project_name=f"Sample EPP {datetime.now(UTC).strftime('%Y%m%dT%H%M%S')}",
                project_description="Auto-generated by scripts/sample_fixture.py",
                implementation_date=XmlDate(datetime.now(UTC).year - 1, 6, 1),
            ),
        )
        report.epp_id = resp.id
        print(f"    + energy performance project id={resp.id}")
    except EpaPmApiError as exc:
        report.failures.append(f"epp create failed — {exc}")


def _add_identifier(client: EpaPmClient, property_id: int, report: PopulateReport) -> None:
    """Add an additional identifier, picking a valid type from the catalog."""
    try:
        catalog = client.identifier.types()
    except EpaPmApiError as exc:
        report.failures.append(f"identifier types lookup failed — {exc}")
        return

    types = catalog.additional_identifier_type or []
    if not types:
        report.failures.append("identifier types catalog returned no entries")
        return
    chosen = types[0]

    try:
        resp = client.identifier.add(
            property_id,
            AdditionalIdentifier(
                additional_identifier_type=chosen,
                value=f"sample-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S')}",
            ),
        )
        report.identifier_id = resp.id
        print(f"    + additional identifier id={resp.id} (type={chosen.name or chosen.id})")
    except EpaPmApiError as exc:
        report.failures.append(f"identifier add failed — {exc}")


def populate(client: EpaPmClient, property_id: int) -> PopulateReport:
    """Add a curated set of extra resources to ``property_id``.

    Each step is independent — failures are collected on the returned report
    rather than aborting the run. Designed to exercise the resource methods
    that round-trip-test the most error-prone parts of the wire format
    (meter create, consumption add, polymorphic identifier types, EPP).
    """
    report = PopulateReport(property_id=property_id)
    print(f"  populating property {property_id}")
    _add_meter_with_consumption(
        client,
        property_id,
        name="Sample Electric",
        meter_type=TypeOfMeter.ELECTRIC,
        unit=MeterTypeUnitOfMeasure.K_WH_THOUSAND_WATT_HOURS,
        report=report,
    )
    _add_meter_with_consumption(
        client,
        property_id,
        name="Sample Natural Gas",
        meter_type=TypeOfMeter.NATURAL_GAS,
        unit=MeterTypeUnitOfMeasure.THERMS,
        report=report,
    )
    _add_energy_performance_project(client, property_id, report)
    _add_identifier(client, property_id, report)
    return report


def cmd_create(args: argparse.Namespace) -> int:
    with _build_client() as client:
        try:
            response = client.property.create_samples(country_code=args.country, create_count=args.count)
        except EpaPmApiError as exc:
            print(f"FAIL — create_samples raised: {exc}")
            return 1

        links = (response.links.link if response.links else None) or []
        if not links:
            print("FAIL — create_samples returned no property links")
            return 1

        property_ids = [link.id for link in links if link.id is not None]
        print(f"Created {len(property_ids)} sample property(ies):")
        for pid in property_ids:
            print(f"  - {pid}")

        if args.populate:
            for pid in property_ids:
                report = populate(client, pid)
                if report.failures:
                    print(f"  ⚠ {len(report.failures)} step(s) failed on {pid}:")
                    for failure in report.failures:
                        print(f"    - {failure}")
        return 0


def cmd_populate(args: argparse.Namespace) -> int:
    with _build_client() as client:
        report = populate(client, args.property_id)
        if report.failures:
            print(f"⚠ {len(report.failures)} step(s) failed:")
            for failure in report.failures:
                print(f"  - {failure}")
            return 1
    return 0


def cmd_delete(args: argparse.Namespace) -> int:
    failures: list[tuple[int, str]] = []
    with _build_client() as client:
        for pid in args.property_ids:
            try:
                client.property.delete(pid)
                print(f"  deleted property {pid}")
            except EpaPmApiError as exc:
                failures.append((pid, str(exc)))
                print(f"  ⚠ failed to delete {pid}: {exc}")
    if failures:
        print(f"\nFAIL — {len(failures)} of {len(args.property_ids)} delete(s) failed")
        return 1
    print(f"\nOK — deleted {len(args.property_ids)} property(ies)")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Sample-property fixture builder for wstest.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_create = sub.add_parser("create", help="Create sample properties (and optionally populate them).")
    p_create.add_argument("--country", default="US", help="ISO country code (default: US)")
    p_create.add_argument("--count", type=int, default=1, help="Number of properties to spawn (default: 1)")
    p_create.add_argument("--populate", action="store_true", help="Populate each created property with extras")
    p_create.set_defaults(func=cmd_create)

    p_pop = sub.add_parser("populate", help="Add extras to an existing property.")
    p_pop.add_argument("property_id", type=int)
    p_pop.set_defaults(func=cmd_populate)

    p_del = sub.add_parser("delete", help="Delete properties by ID.")
    p_del.add_argument("property_ids", type=int, nargs="+")
    p_del.set_defaults(func=cmd_delete)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
