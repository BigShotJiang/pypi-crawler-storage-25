"""End-to-end smoke test for the new client methods against the test environment.

Read-only — no mutations. Loads creds from .env. Verifies that each new method
produces a parseable, well-typed response.
"""

from __future__ import annotations

import os

from dotenv import load_dotenv

from epa_pm_api_wrapper import EpaPmClient


def main() -> int:
    load_dotenv()
    use_test = os.environ.get("EPA_PM_TEST", "").lower() == "true"
    client = EpaPmClient(
        username=os.environ["EPA_PM_USERNAME"],
        password=os.environ["EPA_PM_PASSWORD"],
        use_test_env=use_test,
    )

    print(f"base: {client.base_url}")

    # Account
    acc = client.account.get()
    print(f"\naccount: id={acc.id} username={acc.username}")
    assert acc.id is not None

    # List properties for this account
    props = client.property.list(acc.id)
    assert props.links is not None
    print(f"\nproperties: {len(props.links.link)} total")
    for link in props.links.link[:3]:
        print(f"  {link.id}: {link.hint}")

    if not props.links.link:
        print("no properties — stopping")
        return 0

    prop_id = props.links.link[0].id
    assert prop_id is not None
    pid = int(prop_id)

    # Property hierarchy
    h = client.hierarchy.property(pid)
    print(f"\nproperty {pid} hierarchy: account_id={h.account_id} username={h.username}")

    # List meters
    meters = client.meter.list(pid)
    assert meters.links is not None
    print(f"\nmeters for {pid}: {len(meters.links.link)} total")
    for link in meters.links.link[:3]:
        print(f"  {link.id}: {link.hint}")

    if meters.links.link:
        meter_id = meters.links.link[0].id
        assert meter_id is not None
        mid = int(meter_id)

        meter = client.meter.get(mid)
        print(f"\nmeter {mid}: type={meter.type_value} unit={meter.unit_of_measure}")

        # Meter hierarchy
        mh = client.hierarchy.meter(mid)
        print(f"  hierarchy: account={mh.account_id} property={mh.property_id} meter={mh.meter_id}")

        # Consumption (paginated)
        cd = client.consumption_data.get(mid, page=1)
        records = cd.meter_consumption or []
        print(f"  consumption page 1: {len(records)} records")

    # List property uses
    uses = client.property_use.list(pid)
    assert uses.links is not None
    print(f"\nproperty uses for {pid}: {len(uses.links.link)} total")
    if uses.links.link:
        use_id = uses.links.link[0].id
        assert use_id is not None
        uid = int(use_id)
        use = client.property_use.get(uid)
        print(f"  propertyUse {uid}: name={use.name}")

    # Baseline & target
    bt = client.property.get_baseline_and_target(pid)
    print(
        f"\nbaseline+target for {pid}: "
        f"baseline={bt.baseline.energy_baseline_date if bt.baseline else 'n/a'} "
        f"target={bt.target.target_metric if bt.target else 'n/a'}"
    )

    # Customers + pending lists
    customers = client.customer.list()
    assert customers.links is not None
    print(f"\ncustomers: {len(customers.links.link)} total")

    pending = client.share.pending_property_shares()
    print(f"pending property shares: {len(pending.property)}")

    pending_meter = client.share.pending_meter_shares()
    print(f"pending meter shares: {len(pending_meter.meter)}")

    pending_conn = client.share.pending_connections()
    print(f"pending connections: {len(pending_conn.account)}")

    # ---- 0.2.0 additions ----
    # Static catalogs (no property/customer needed)
    fa = client.property.federal_agency.list()
    print(f"\nfederal agencies: {len(fa.agency)}")

    egrid = client.property.e_grid_subregion.list()
    print(f"eGrid subregions: {len(egrid.e_grid_subregion)}")

    bm = client.property.billboard.catalog()
    print(f"billboard metrics: {len(bm.metric)}")

    meter_id_types = client.meter.identifier.types()
    print(f"meter identifier types: {len(meter_id_types.additional_identifier_type)}")

    # Property-scoped reads we already have a property for
    edus = client.property.edu.list(pid)
    print(f"\nEDUs available for {pid}: {len(edus.edu)}")

    epp = client.property.energy_performance_project.list(pid)
    epp_links = epp.links.link if epp.links else []
    print(f"energy performance projects for {pid}: {len(epp_links)}")

    if meters.links.link:
        meter_id = meters.links.link[0].id
        assert meter_id is not None
        m_ids = client.meter.identifier.list(int(meter_id))
        print(f"meter {meter_id} identifiers: {len(m_ids.additional_identifier)}")

    associated_meters = client.association.property_meters.list(pid)
    count = 0
    if associated_meters.energy_meter_association:
        count += len(associated_meters.energy_meter_association.meters.meter_id)
    if associated_meters.water_meter_association:
        count += len(associated_meters.water_meter_association.meters.meter_id)
    if associated_meters.waste_meter_association:
        count += len(associated_meters.waste_meter_association.meters.meter_id)
    print(f"meters associated to property {pid}: {count}")

    print("\nall checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
