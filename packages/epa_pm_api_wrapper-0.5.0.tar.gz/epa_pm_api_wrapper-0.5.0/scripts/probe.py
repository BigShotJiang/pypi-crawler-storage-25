"""Probe EPA Portfolio Manager API endpoints to discover/confirm URL paths.

Loads credentials from .env (never prints them). Sends a single HTTP request
to a candidate path and prints status code + a truncated response body so we
can confirm an endpoint exists before wiring it into the client.

Usage:
    uv run python scripts/probe.py GET /account
    uv run python scripts/probe.py GET /account/{id}/property/list
    uv run python scripts/probe.py GET /property/{id}/meter/list

Multi-probe (one per line on stdin or via -f file):
    uv run python scripts/probe.py --batch <<EOF
    GET /account
    GET /account/{id}/property/list
    EOF
"""

from __future__ import annotations

import os
import sys
import time
from dataclasses import dataclass

import httpx
from dotenv import load_dotenv


@dataclass
class ProbeResult:
    method: str
    path: str
    status: int
    body_snippet: str
    content_type: str


def _client() -> tuple[httpx.Client, str]:
    load_dotenv()
    username = os.environ["EPA_PM_USERNAME"]
    password = os.environ["EPA_PM_PASSWORD"]
    use_test = os.environ.get("EPA_PM_TEST", "").lower() == "true"
    base = (
        "https://portfoliomanager.energystar.gov/wstest" if use_test else "https://portfoliomanager.energystar.gov/ws"
    )
    return (
        httpx.Client(auth=(username, password), timeout=30.0, follow_redirects=True),
        base,
    )


def probe(client: httpx.Client, base: str, method: str, path: str, snippet_len: int = 600) -> ProbeResult:
    url = f"{base}/{path.lstrip('/')}"
    resp = client.request(method.upper(), url)
    body = resp.text or ""
    snippet = body[:snippet_len]
    if len(body) > snippet_len:
        snippet += f"... [+{len(body) - snippet_len} bytes]"
    return ProbeResult(
        method=method.upper(),
        path=path,
        status=resp.status_code,
        body_snippet=snippet,
        content_type=resp.headers.get("content-type", ""),
    )


def _print_result(r: ProbeResult) -> None:
    print(f"\n=== {r.method} {r.path} ===")
    print(f"status: {r.status}  content-type: {r.content_type}")
    print(r.body_snippet)


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 2

    client, base = _client()
    print(f"base: {base}")

    if args[0] == "--batch":
        # Read "METHOD PATH" lines from stdin
        for raw in sys.stdin:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            method, _, path = line.partition(" ")
            if not path:
                print(f"skip (no path): {line}")
                continue
            try:
                _print_result(probe(client, base, method, path))
            except Exception as e:
                print(f"\n=== {method} {path} ===\nERROR: {e}")
            time.sleep(0.5)
        return 0

    method = args[0]
    path = args[1] if len(args) > 1 else "/"
    _print_result(probe(client, base, method, path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
