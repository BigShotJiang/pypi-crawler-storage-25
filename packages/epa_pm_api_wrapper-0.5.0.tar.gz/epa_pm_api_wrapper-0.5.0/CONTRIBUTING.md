# Contributing

Contributions are welcome, and they are greatly appreciated! Every little bit helps, and credit will always be given.

You can contribute in many ways:

## Types of Contributions

### Report Bugs

Report bugs at https://github.com/harryw1/EPA-PM-API-Wrapper/issues.

If you are reporting a bug, please include:

- Your operating system name and version.
- Any details about your local setup that might be helpful in troubleshooting.
- Detailed steps to reproduce the bug.

### Fix Bugs

Look through the GitHub issues for bugs. Anything tagged with "bug" and "help wanted" is open to whoever wants to implement it.

### Implement Features

Look through the GitHub issues for features. Anything tagged with "enhancement" and "help wanted" is open to whoever wants to implement it.

### Write Documentation

EPA PM API Wrapper could always use more documentation, whether as part of the official docs, in docstrings, or even on the web in blog posts, articles, and such.

To preview the docs locally:

```sh
just docs-serve
```

This starts a local server at http://localhost:8000 with live reload. Edit files in `docs/` or add docstrings to your code (the API reference page is auto-generated).

### Submit Feedback

The best way to send feedback is to file an issue at https://github.com/harryw1/EPA-PM-API-Wrapper/issues.

If you are proposing a feature:

- Explain in detail how it would work.
- Keep the scope as narrow as possible, to make it easier to implement.
- Remember that this is a volunteer-driven project, and that contributions are welcome :)

## Get Started!

Ready to contribute? Here's how to set up EPA-PM-API-Wrapper for local development.

1. Fork the EPA-PM-API-Wrapper repo on GitHub.
2. Clone your fork locally:

   ```sh
   git clone git@github.com:your_name_here/EPA-PM-API-Wrapper.git
   ```

3. Install your local copy with uv:

   ```sh
   cd EPA-PM-API-Wrapper/
   uv sync
   ```

   If `import epa_pm_api_wrapper` (or `pytest`) fails with
   `ModuleNotFoundError`, the editable install didn't register the package
   correctly. Re-run with `uv sync --reinstall` to force a clean
   re-registration.

4. Create a branch for local development:

   ```sh
   git checkout -b name-of-your-bugfix-or-feature
   ```

   Now you can make your changes locally.

5. When you're done making changes, check that your changes pass linting and the tests:

   ```sh
   just qa
   ```

   Or run the tests alone:

   ```sh
   just test
   ```

6. Commit your changes and push your branch to GitHub:

   ```sh
   git add .
   git commit -m "Your detailed description of your changes."
   git push origin name-of-your-bugfix-or-feature
   ```

7. Submit a pull request through the GitHub website.

## Generated models

The dataclasses in `src/epa_pm_api_wrapper/models/` are generated from the
2026 EPA Portfolio Manager XSD snapshot vendored under `schemas/` (rooted
at `schemas/main.xsd`) using [`xsdata`](https://xsdata.readthedocs.io/).
If the EPA publishes an updated schema, refresh `schemas/` from
[`portfoliomanager.energystar.gov/webservices`](https://portfoliomanager.energystar.gov/webservices)
and regenerate before editing the generated modules by hand.

## Pull Request Guidelines

Before you submit a pull request, check that it meets these guidelines:

1. The pull request should include tests.
2. If the pull request adds functionality, the docs should be updated. Put your new functionality into a function with a docstring, and add the feature to the list in README.md.
3. The pull request should work for Python 3.12, 3.13, and 3.14. Tests run in GitHub Actions on every pull request to the main branch, make sure that the tests pass for all supported Python versions.

## Tips

To run a subset of tests:

```sh
uv run pytest tests/
```

## Releasing a New Version

1. **Bump the version** and **write the changelog:**
   ```bash
   uv version <version>        # or: uv version --bump minor
   ```
   Then write `CHANGELOG/<version>.md`. See previous entries for the format.
2. **Commit:**
   ```bash
   git add pyproject.toml uv.lock CHANGELOG/
   git commit -m "Release <version>"
   ```
3. **Release:**
   ```bash
   just release
   ```
   This creates an annotated `v*` tag, pushes it to GitHub, and creates a
   GitHub Release with the changelog contents as release notes. The tag
   push triggers `.github/workflows/publish.yml`, which builds the package,
   generates SLSA provenance attestations, and publishes to PyPI via
   trusted publishing.

## Code of Conduct

Please note that this project is released with a [Contributor Code of Conduct](CODE_OF_CONDUCT.md). By participating in this project you agree to abide by its terms.
