# Metrics

The four `client.metrics.*` methods (`get`, `monthly`, `use_details`, `design`)
each take a `metrics: list[str] | str` argument that is a list of EPA-defined
metric *wire names* — e.g. `score`, `siteEnergyUseAdjustedToCurrentYear`,
`siteIntensity`. The wrapper joins them into the comma-separated `PM-Metrics`
HTTP header that the EPA Portfolio Manager API expects.

This page covers:

- where the canonical list of metric names lives,
- how to enumerate it at runtime,
- a reference of common metric names grouped the way EPA groups them,
- which metrics each endpoint accepts.

## Where the names come from

EPA publishes the catalog at the Portfolio Manager web services site:

- Index — <https://portfoliomanager.energystar.gov/webservices/home/test/api>
- The metrics catalog endpoint is documented under the **Reporting** section
  (`GET /reports/metrics`); the four metric value endpoints live under the
  **Property** section.

The catalog the wrapper sees is whatever the EPA test/production environment
returns at request time. The reference below was captured from the test
environment and is correct for current Portfolio Manager builds, but EPA can
add, rename, or retire metrics between releases — `client.report.metrics()`
is always the authoritative live source.

## Enumerating the catalog at runtime

`client.report.metrics()` returns the full live catalog, organized into the
same groups the Portfolio Manager UI uses (Energy Performance, Greenhouse
Gas Emissions, Water, Waste, …). Each metric exposes its wire name, friendly
description, data type, and unit of measure:

```python
from epa_pm_api_wrapper import EpaPmClient

with EpaPmClient(username, password) as client:
    catalog = client.report.metrics()
    for group in catalog.group:
        print(f"\n=== {group.name} ===")
        for m in group.metrics.metric:
            unit = m.uom or "—"
            print(f"  {m.name:50s} {m.description:60s} {unit}")
```

The model fields mirror EPA's XML attributes:

| Field                          | Meaning                                                              |
| ------------------------------ | -------------------------------------------------------------------- |
| `name`                         | The wire name to pass in `metrics=[...]`.                            |
| `description`                  | Friendly UI label.                                                   |
| `data_type`                    | `"numeric"`, `"string"`, or `"date"`.                                |
| `uom`                          | Unit of measure (`kBtu/ft²`, `Metric Tons CO2e`, `kgal`, …); may be empty. |
| `available_to_custom_metrics`  | Whether the metric can be referenced from a Custom Metric formula.   |

To narrow the catalog, pass filters:

```python
# Only metrics usable in a Custom Metric formula
custom_eligible = client.report.metrics(available_to_custom_metrics=True)

# Metrics in specific groups (comma-separated group IDs from the full listing)
energy_only = client.report.metrics(group_ids="4,5")
```

The current test environment exposes 17 groups and ~1,800 metrics:

| ID | Group                            | Metrics |
| -- | -------------------------------- | ------- |
| 1  | Data Accuracy                    |     254 |
| 2  | Data Center Metrics              |      11 |
| 3  | Property Design                  |     121 |
| 4  | Energy Performance Metrics       |      37 |
| 5  | Energy Use by Fuel Source        |      64 |
| 6  | Sustainable Buildings Checklist  |      45 |
| 7  | Cost Performance Metrics         |     134 |
| 8  | Greenhouse Gas Emissions         |      27 |
| 9  | Property Information             |      79 |
| 10 | Property Use Details             |     846 |
| 11 | Renewable Energy & Green Power   |      16 |
| 12 | Target Metrics                   |      22 |
| 13 | Water Performance Metrics        |      28 |
| 14 | ENERGY STAR/NextGen Certification|      14 |
| 15 | Property ID Numbers              |      31 |
| 16 | Waste Performance Metrics        |      92 |
| 17 | Meter Information                |      17 |

## Common metric names

The tables below list widely-used metrics, grouped by EPA's own category
structure. Wire names, descriptions, and units are taken directly from
`client.report.metrics()` against the EPA test environment. All counts
above are larger than what's shown here — the tables are curated for
day-to-day reporting use; reach for `client.report.metrics()` when you
need fuel-by-fuel breakdowns, per-use-type detail, or the data-accuracy
flags.

### Energy Performance Metrics (group 4)

| Wire name                              | Description                                              | UOM (EPA system) |
| -------------------------------------- | -------------------------------------------------------- | ---------------- |
| `score`                                | ENERGY STAR Score                                        | (unitless)       |
| `medianScore`                          | National Median ENERGY STAR Score                        | (unitless)       |
| `siteTotal`                            | Site Energy Use                                          | kBtu             |
| `siteIntensity`                        | Site EUI                                                 | kBtu/ft²         |
| `sourceTotal`                          | Source Energy Use                                        | kBtu             |
| `sourceIntensity`                      | Source EUI                                               | kBtu/ft²         |
| `siteTotalWN`                          | Weather Normalized Site Energy Use                       | kBtu             |
| `siteIntensityWN`                      | Weather Normalized Site EUI                              | kBtu/ft²         |
| `sourceTotalWN`                        | Weather Normalized Source Energy Use                     | kBtu             |
| `sourceIntensityWN`                    | Weather Normalized Source EUI                            | kBtu/ft²         |
| `siteEnergyUseAdjustedToCurrentYear`   | Site Energy Use - Adjusted to Current Year               | kBtu             |
| `sourceEnergyUseAdjustedToCurrentYear` | Source Energy Use - Adjusted to Current Year             | kBtu             |
| `siteIntensityAdjustedToCurrentYear`   | Site EUI - Adjusted to Current Year                      | kBtu/ft²         |
| `sourceIntensityAdjustedToCurrentYear` | Source EUI - Adjusted to Current Year                    | kBtu/ft²         |
| `medianSiteIntensity`                  | National Median Site EUI                                 | kBtu/ft²         |
| `medianSourceIntensity`                | National Median Source EUI                               | kBtu/ft²         |
| `percentBetterThanSiteIntensityMedian` | % Difference from National Median Site EUI               | (unitless)       |
| `percentBetterThanSourceIntensityMedian` | % Difference from National Median Source EUI           | (unitless)       |
| `annualMaximumDemand`                  | Annual Maximum Demand                                    | kW               |
| `scorePreview`                         | ENERGY STAR Score Preview for Model Updates              | (unitless)       |

### Energy Use by Fuel Source (group 5)

`siteEnergyUse*` returns kBtu by default; for the most common fuels EPA also
exposes a "native unit" alias (e.g. `*Kwh`, `*Therms`).

| Wire name                                | Description                                              | UOM      |
| ---------------------------------------- | -------------------------------------------------------- | -------- |
| `siteEnergyUseElectricityGridPurchase`   | Electricity Use - Grid Purchase                          | kBtu     |
| `siteEnergyUseElectricityGridPurchaseKwh`| Electricity Use - Grid Purchase                          | kWh      |
| `siteEnergyUseElectricityGridPurchaseAndOnsite` | Grid Purchase + Onsite Renewables                 | kBtu     |
| `siteEnergyUseNaturalGas`                | Natural Gas Use                                          | kBtu     |
| `siteEnergyUseNaturalGasTherms`          | Natural Gas Use                                          | therms   |
| `siteEnergyUseDistrictSteam`             | District Steam Use                                       | kBtu     |
| `siteEnergyUseDistrictHotWater`          | District Hot Water Use                                   | kBtu     |
| `siteEnergyUseDistrictChilledWater`      | District Chilled Water Use                               | kBtu     |
| `siteEnergyUsePropane`                   | Propane Use                                              | kBtu     |
| `siteEnergyUseFuelOil2`                  | Fuel Oil #2 Use                                          | kBtu     |
| `siteEnergyUseWood`                      | Wood Use                                                 | kBtu     |
| `siteElectricityTotalWN`                 | Weather Normalized Site Electricity Use                  | kWh      |
| `siteNaturalGasUseTotalWN`               | Weather Normalized Site Natural Gas Use                  | therms   |
| `percentElectricity`                     | Percent Electricity                                      | (unitless) |

### Greenhouse Gas Emissions (group 8)

| Wire name                                  | Description                                            | UOM              |
| ------------------------------------------ | ------------------------------------------------------ | ---------------- |
| `directGHGEmissions`                       | Direct GHG Emissions (on-site fuel combustion)         | Metric Tons CO2e |
| `directGHGEmissionsIntensity`              | Direct GHG Emissions Intensity                         | kgCO2e/ft²       |
| `indirectLocationBasedGHGEmissions`        | Indirect (Location-Based) GHG Emissions                | Metric Tons CO2e |
| `indirectLocationBasedGHGEmissionsIntensity` | Indirect (Location-Based) GHG Emissions Intensity    | kgCO2e/ft²       |
| `indirectMarketBasedGHGEmissions`          | Indirect (Market-Based) GHG Emissions                  | Metric Tons CO2e |
| `indirectMarketBasedGHGEmissionsIntensity` | Indirect (Market-Based) GHG Emissions Intensity        | kgCO2e/ft²       |
| `totalLocationBasedGHGEmissions`           | Total (Location-Based) GHG Emissions                   | Metric Tons CO2e |
| `totalLocationBasedGHGEmissionsIntensity`  | Total (Location-Based) GHG Emissions Intensity         | kgCO2e/ft²       |
| `totalMarketBasedGHGEmissions`             | Total (Market-Based) GHG Emissions                     | Metric Tons CO2e |
| `totalMarketBasedGHGEmissionsIntensity`    | Total (Market-Based) GHG Emissions Intensity           | kgCO2e/ft²       |
| `biomassGHGEmissions`                      | Biomass GHG Emissions (excluded from totals)           | Metric Tons CO2e |
| `medianTotalLocationBasedGHGEmissions`     | National Median Total (Location-Based) GHG Emissions   | Metric Tons CO2e |
| `regionalPowerGrid`                        | eGRID Subregion                                        | (text)           |
| `electricDistributionUtility`              | Electric Distribution Utility                          | (text)           |

### Water Performance Metrics (group 13)

| Wire name                                    | Description                                          | UOM      |
| -------------------------------------------- | ---------------------------------------------------- | -------- |
| `waterUseTotal`                              | Water Use (All Water Sources)                        | kgal     |
| `waterIntensityTotal`                        | Water Use Intensity (All Water Sources)              | gal/ft²  |
| `indoorWaterUseTotalAllWaterSources`         | Indoor Water Use (All Water Sources)                 | kgal     |
| `indoorWaterIntensityAllWaterSources`        | Indoor Water Use Intensity (All Water Sources)       | gal/ft²  |
| `outdoorWaterUseTotalAllWaterSources`        | Outdoor Water Use (All Water Sources)                | kgal     |
| `municipallySuppliedPotableWaterIndoorUse`   | Municipally Supplied Potable Water - Indoor Use      | kgal     |
| `municipallySuppliedPotableWaterOutdoorUse`  | Municipally Supplied Potable Water - Outdoor Use     | kgal     |
| `municipallySuppliedReclaimedWaterIndoorUse` | Municipally Supplied Reclaimed Water - Indoor Use    | kgal     |
| `wellWaterTotalUse`                          | Well Water - Total Use (All Meter Types)             | kgal     |
| `waterScore`                                 | Water Score (Multifamily Only)                       | (unitless) |

### Waste Performance Metrics (group 16)

| Wire name                              | Description                                                | UOM      |
| -------------------------------------- | ---------------------------------------------------------- | -------- |
| `totalWasteDisposedandDiverted`        | Total Waste (Disposed and Diverted)                        | Tons     |
| `totalWasteDisposedandDivertedIntensity` | Total Waste (Disposed and Diverted) - Intensity          | lbs/ft²  |
| `diversionRate`                        | Diversion Rate                                             | %        |
| `divertedMaterials`                    | Diverted Materials                                         | Tons     |
| `disposedWaste`                        | Disposed Waste                                             | Tons     |
| `recycledMaterials`                    | Recycled Materials                                         | Tons     |
| `compostedMaterials`                   | Composted Materials                                        | Tons     |
| `donatedReusedMaterials`               | Donated/Reused Materials                                   | Tons     |
| `disposedWasteLandfill`                | Disposed Waste - Landfill                                  | Tons     |
| `disposedWasteIncineration`            | Disposed Waste - Incineration                              | Tons     |
| `disposedWasteWastetoEnergy`           | Disposed Waste - Waste to Energy                           | Tons     |

### Cost Performance Metrics (group 7)

| Wire name                                          | Description                              | UOM    |
| -------------------------------------------------- | ---------------------------------------- | ------ |
| `energyCost`                                       | Energy Cost                              | $      |
| `energyCostIntensity`                              | Energy Cost Intensity                    | $/ft²  |
| `medianEnergyCost`                                 | National Median Energy Cost              | $      |
| `energyCostElectricityGridPurchase`                | Electricity (Grid Purchase) Cost         | $      |
| `energyCostNaturalGas`                             | Natural Gas Cost                         | $      |
| `energyCostDistrictSteam`                          | District Steam Cost                      | $      |
| `waterCost`                                        | Total Water Cost (All Water Sources)     | $      |
| `indoorWaterCostAllWaterSources`                   | Indoor Water Cost (All Water Sources)    | $      |
| `totalWasteDisposedandDivertedCost`                | Total Waste (Disposed and Diverted) Cost | $      |
| `investmentInEnergyProjectsCumulativeDollars`      | Investment in Energy Projects, Cumulative| $      |
| `estimatedSavingsFromUpgradesCumulativeDollars`    | Estimated Savings from Energy Projects   | $      |

### Renewable Energy & Green Power (group 11)

| Wire name                                       | Description                                              | UOM              |
| ----------------------------------------------- | -------------------------------------------------------- | ---------------- |
| `onSiteRenewableSystemGeneration`               | Electricity Use – Generated from Onsite Renewable Systems | kWh              |
| `onSiteRenewableSystemElectricityExported`      | Onsite Renewable Generation Used Onsite                  | kWh              |
| `electricitySourcedFromOnSiteRenewableSystems`  | % of Total Electricity Generated Onsite                  | (unitless)       |
| `greenPowerOnSite`                              | Green Power - Onsite                                     | kWh              |
| `greenPowerOffSite`                             | Green Power - Offsite                                    | kWh              |
| `greenPowerOnSiteAndOffSite`                    | Green Power - Onsite and Offsite                         | kWh              |
| `greenPowerOfTotalElectricityGridPurchaseAndOnSite` | Percent of Electricity that is Green Power           | (unitless)       |
| `avoidedEmissionsOnSiteGreenPower`              | Avoided Emissions - Onsite Green Power                   | Metric Tons CO2e |
| `avoidedEmissionsOffSiteGreenPower`             | Avoided Emissions - Offsite Green Power                  | Metric Tons CO2e |
| `avoidedEmissionsOnSiteAndOffSiteGreenPower`    | Avoided Emissions - Onsite and Offsite Green Power       | Metric Tons CO2e |
| `recsRetained`                                  | Percent of RECs Retained                                 | (unitless)       |

### Target Metrics (group 12)

| Wire name                                      | Description                                  | UOM              |
| ---------------------------------------------- | -------------------------------------------- | ---------------- |
| `targetScore`                                  | Target ENERGY STAR Score                     | (unitless)       |
| `targetSiteTotal`                              | Target Site Energy Use                       | kBtu             |
| `targetSiteIntensity`                          | Target Site EUI                              | kBtu/ft²         |
| `targetSourceTotal`                            | Target Source Energy Use                     | kBtu             |
| `targetSourceIntensity`                        | Target Source EUI                            | kBtu/ft²         |
| `targetEnergyCost`                             | Target Energy Cost                           | $                |
| `targetTotalLocationBasedGHGEmissions`         | Target Total (Location-Based) GHG Emissions  | Metric Tons CO2e |
| `targetPercentBetterThanSourceIntensityMedian` | Target % Better Than Median Source EUI       | (unitless)       |

### Property Design (group 3)

The full design-metric set lives here — all 121 names start with `design`.
These are the names accepted by `client.metrics.design()`.

| Wire name                                      | Description                                              | UOM              |
| ---------------------------------------------- | -------------------------------------------------------- | ---------------- |
| `designScore`                                  | Design ENERGY STAR Score                                 | (unitless)       |
| `designSiteTotal`                              | Design Site Energy Use                                   | kBtu             |
| `designSiteIntensity`                          | Design Site EUI                                          | kBtu/ft²         |
| `designSourceTotal`                            | Design Source Energy Use                                 | kBtu             |
| `designSourceIntensity`                        | Design Source EUI                                        | kBtu/ft²         |
| `designEnergyCost`                             | Design Energy Cost                                       | $                |
| `designEnergyCostIntensity`                    | Design Energy Cost Intensity                             | $/ft²            |
| `designDirectGHGEmissions`                     | Design Direct GHG Emissions                              | Metric Tons CO2e |
| `designIndirectLocationBasedGHGEmissions`      | Design Indirect (Location-Based) GHG Emissions           | Metric Tons CO2e |
| `designTotalLocationBasedGHGEmissions`         | Design Total (Location-Based) GHG Emissions              | Metric Tons CO2e |
| `designElectricityUseGridPurchase`             | Design Electricity Use - Grid Purchase                   | kBtu             |
| `designNaturalGasUse`                          | Design Natural Gas Use                                   | kBtu             |
| `designDistrictSteamUse`                       | Design District Steam Use                                | kBtu             |
| `designPUE`                                    | Design PUE (Data Center)                                 | (unitless)       |

### ENERGY STAR / NextGen Certification (group 14)

| Wire name                                              | Description                                       |
| ------------------------------------------------------ | ------------------------------------------------- |
| `energyStarCertificationEligibility`                   | Eligible for ENERGY STAR Certification (Y/N)      |
| `energyStarCertificationNumberOfYearsCertified`        | ENERGY STAR Certification - Number of Years       |
| `energyStarNextGenCertificationApplicationStatus`      | NextGen Certification Application Status          |
| `nextGenEligibleGreenPowerKwh`                         | NextGen - Eligible Green Power (kWh)              |
| `nextGenTargetDirectGhgIntensity`                      | NextGen Target - Direct GHG Emissions Intensity   |

## Monthly metrics

The catalog includes 25 metrics whose name ends in `Monthly`. They live
mostly in *Energy Use by Fuel Source* and *Water Performance Metrics*, and
each returns 12 trailing monthly values from `client.metrics.monthly()`.
There is **no `scoreMonthly`**: the ENERGY STAR Score is not exposed as a
monthly metric.

| Wire name                                          | Description                                          | UOM    |
| -------------------------------------------------- | ---------------------------------------------------- | ------ |
| `siteElectricityUseMonthly`                        | Electricity Use (Grid) - Monthly                     | kBtu   |
| `siteNaturalGasUseMonthly`                         | Natural Gas Use - Monthly                            | kBtu   |
| `siteEnergyUseDistrictSteamMonthly`                | District Steam Use - Monthly                         | kBtu   |
| `siteEnergyUseDistrictHotWaterMonthly`             | District Hot Water Use - Monthly                     | kBtu   |
| `siteEnergyUseDistrictChilledWaterMonthly`         | District Chilled Water Use - Monthly                 | kBtu   |
| `siteEnergyUsePropaneMonthly`                      | Propane Use - Monthly                                | kBtu   |
| `siteEnergyUseFuelOil2Monthly`                     | Fuel Oil #2 Use - Monthly                            | kBtu   |
| `siteElectricityUseOnsiteRenewablesMonthly`        | Electricity Use - Onsite Renewables - Monthly        | kBtu   |
| `indoorWaterUseTotalAllWaterSourcesMonthly`        | Indoor Water Use (All Water Sources) - Monthly       | kgal   |
| `outdoorWaterUseTotalAllWaterSourcesMonthly`       | Outdoor Water Use (All Water Sources) - Monthly      | kgal   |
| `mixedIndoorOutdoorWaterUseTotalAllWaterSourcesMonthly` | Mixed Indoor/Outdoor Water Use - Monthly        | kgal   |

## Property Use Details

The largest group at 846 metrics — every Property Use type's data fields
(gross floor area, weekly operating hours, number of computers, ...) are
exposed here. The wire-name convention is `<useType><DetailName>`:

| Wire name                              | Description                          | UOM      |
| -------------------------------------- | ------------------------------------ | -------- |
| `officeGrossFloorArea`                 | Office - Gross Floor Area            | ft²      |
| `officeWeeklyOperatingHours`           | Office - Weekly Operating Hours      | (number) |
| `officeNumberOfComputers`              | Office - Number of Computers         | (number) |
| `officeWorkerDensity`                  | Office - Worker Density              | per 1k ft² |
| `hotelGrossFloorArea`                  | Hotel - Gross Floor Area             | ft²      |
| `hotelNumberOfRooms`                   | Hotel - Number of Rooms              | (number) |
| `multifamilyHousingGrossFloorArea`     | Multifamily Housing - GFA            | ft²      |
| `k12SchoolGrossFloorArea`              | K-12 School - GFA                    | ft²      |
| `hospitalGeneralMedicalSurgicalGrossFloorArea` | Hospital (General/Medical/Surgical) - GFA | ft² |
| `dataCenterCoolingEquipmentRedundancy` | Data Center - Cooling Equip. Redundancy | (text) |

Because these names are tied to specific use types, the practical workflow
is: enumerate `client.property_use.list(property_id)` to find which use
types the property has, then filter `client.report.metrics(group_ids="10")`
by that prefix. A metric for a use type the property doesn't have will
return `null` rather than erroring.

## Which endpoint accepts which metric

Every endpoint validates its metric list server-side, so a metric that's
valid for one endpoint may be rejected by another with `EpaPmApiError(-200)`.
The catalog itself doesn't carry an endpoint-compatibility flag — these
rules are derived from name conventions and EPA's own UI groupings:

### `client.metrics.get(property_id, metrics, year, month, ...)`

Period-ending values for a year/month. Accepts most non-monthly,
non-design metrics from the groups above — `score`, `siteTotal`,
`sourceIntensity`, `directGHGEmissions`, `waterUseTotal`,
`totalWasteDisposedandDiverted`, `energyCost`, …. Rejects any name
ending in `Monthly` and any name starting with `design`.

### `client.metrics.monthly(property_id, metrics, year, month, ...)`

Twelve monthly values trailing the requested period. Accepts only the 25
metrics whose `name` ends in `Monthly` (see the section above). Passing
a non-monthly name (e.g. `siteTotal`) returns `EpaPmApiError(-200)`.

### `client.metrics.use_details(property_id, metrics, year, month, ...)`

Time-weighted values for *Property Use Details* — the 846 metrics in
group 10. Each name is keyed to a specific use type (`officeGrossFloorArea`,
`hotelNumberOfRooms`, `k12SchoolGrossFloorArea`, …) and is best discovered
from the live catalog rather than hard-coded.

### `client.metrics.design(property_id, metrics, ...)`

Modeled/intended performance for a property design — no `year`/`month`
parameter. Accepts the 121 metrics in the *Property Design* group, all of
which start with `design` (`designScore`, `designSiteTotal`,
`designEnergyCost`, …).

## `measurement_system`

All four endpoints take `measurement_system="EPA"` (US customary — kBtu,
ft², gal, $) or `"EU"` (metric — kWh, m², m³, EUR). The metric *names*
don't change between systems; only the units of the returned values do.

```python
us = client.metrics.get(prop_id, ["sourceIntensity"], 2025, 12)              # kBtu/ft²
eu = client.metrics.get(prop_id, ["sourceIntensity"], 2025, 12, "EU")        # kWh/m²
```

## Why a metric returns no value

`client.metrics.reasons_for_no_score(property_id, year, month)` and
`client.metrics.reasons_for_no_water_score(property_id, year, month)`
return `Alerts` describing why ENERGY STAR can't compute a score for a
period — usually missing 12 months of energy data, an unsupported primary
use type, or out-of-range values for some use detail.

```python
alerts = client.metrics.reasons_for_no_score(prop_id, 2025, 12)
for a in alerts.alert or []:
    print(a.name, "—", a.description)
```

### `client.metrics.blockers(property_id, year, month)`

Convenience aggregator that calls both `reasonsFor*` endpoints and returns
a `PropertyBlockers` with the alerts grouped by score type. The async client
fans the two requests out concurrently via `asyncio.gather`; the sync client
issues them sequentially. The result is truthy iff at least one blocker is
present, so the common "is this property unblocked?" check reads naturally:

```python
blockers = client.metrics.blockers(prop_id, 2025, 12)
if blockers:
    for a in blockers.energy:
        print("energy:", a.name, "—", a.description)
    for a in blockers.water:
        print("water:", a.name, "—", a.description)
```

`PropertyBlockers` is exported at the top level (`from epa_pm_api_wrapper
import PropertyBlockers`) for type annotations; it carries `property_id`,
`year`, `month`, and the `energy` / `water` alert lists.

## See also

- [API reference](api.md) — auto-generated signatures and per-method
  docstrings for `client.metrics` and `client.report` (which exposes
  `client.report.metrics()`, the catalog accessor).
