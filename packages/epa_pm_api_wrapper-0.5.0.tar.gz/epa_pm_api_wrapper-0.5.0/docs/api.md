# API Reference

The public surface is the items listed below, plus everything exported from
`epa_pm_api_wrapper.__all__`. Each resource is bound to `EpaPmClient` and
`EpaPmAsyncClient` under an attribute matching the snake-cased name (e.g.
the methods documented on `AccountResource` are reached via
`client.account.<method>`); async resources expose the same methods as
coroutines.

## Clients

::: epa_pm_api_wrapper.client.EpaPmClient
    options:
      heading_level: 3

::: epa_pm_api_wrapper.client.EpaPmAsyncClient
    options:
      heading_level: 3

## Exceptions

::: epa_pm_api_wrapper.exceptions
    options:
      heading_level: 3

## Retry configuration

::: epa_pm_api_wrapper.retry.RetryConfig
    options:
      heading_level: 3

## Resources

### Account — `client.account`

::: epa_pm_api_wrapper.resources.account

### Association — `client.association`

::: epa_pm_api_wrapper.resources.association

### Building — `client.building`

::: epa_pm_api_wrapper.resources.building

### Consumption data — `client.consumption_data`

::: epa_pm_api_wrapper.resources.consumption_data

### Custom metric — `client.custom_metric`

::: epa_pm_api_wrapper.resources.custom_metric

### Customer — `client.customer`

::: epa_pm_api_wrapper.resources.customer

### Data exchange — `client.data_exchange`

::: epa_pm_api_wrapper.resources.data_exchange

### Green power — `client.green_power`

::: epa_pm_api_wrapper.resources.green_power

### Home Energy Yardstick — `client.hey`

::: epa_pm_api_wrapper.resources.hey

### Hierarchy — `client.hierarchy`

::: epa_pm_api_wrapper.resources.hierarchy

### Identifier — `client.identifier`

::: epa_pm_api_wrapper.resources.identifier

### Meter — `client.meter`

::: epa_pm_api_wrapper.resources.meter

### Metrics — `client.metrics`

For the catalog of valid metric *names* — what to pass in
`metrics=[...]` — see the [Metrics guide](metrics.md), which covers
runtime discovery via `client.report.metrics()`, a curated reference
table, and which endpoint accepts which metric.

::: epa_pm_api_wrapper.resources.metrics

### Property — `client.property`

::: epa_pm_api_wrapper.resources.property

### Property use — `client.property_use`

::: epa_pm_api_wrapper.resources.property_use

### Report — `client.report`

::: epa_pm_api_wrapper.resources.report

### Share — `client.share`

::: epa_pm_api_wrapper.resources.share

### Target finder — `client.target_finder`

::: epa_pm_api_wrapper.resources.target_finder

### Verification — `client.verification`

::: epa_pm_api_wrapper.resources.verification

### Waste data — `client.waste_data`

::: epa_pm_api_wrapper.resources.waste_data
