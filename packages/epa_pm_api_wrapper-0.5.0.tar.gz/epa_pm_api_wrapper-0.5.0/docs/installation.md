# Installation

## Stable release

To install EPA PM API Wrapper, run this command in your terminal:

```sh
uv add EPA-PM-API-Wrapper
```

Or if you prefer to use `pip`:

```sh
pip install EPA-PM-API-Wrapper
```

## From source

The source files for EPA PM API Wrapper can be downloaded from the [Github repo](https://github.com/harryw1/EPA-PM-API-Wrapper).

You can either clone the public repository:

```sh
git clone https://github.com/harryw1/EPA-PM-API-Wrapper
```

Or download the [tarball](https://github.com/harryw1/EPA-PM-API-Wrapper/tarball/main):

```sh
curl -OJL https://github.com/harryw1/EPA-PM-API-Wrapper/tarball/main
```

Once you have a copy of the source, you can install it with:

```sh
cd EPA-PM-API-Wrapper
uv sync
```
