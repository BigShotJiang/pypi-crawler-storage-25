# EPA PM API Wrapper

Client wrapper for the EPA Portfolio Manager API.

## Getting started

- [Installation](installation.md) — how to install the wrapper.
- [Usage](usage.md) — quickstart, authentication, error handling, retries, an end-to-end onboarding walkthrough, and worked examples for the most common workflows.
- [Metrics](metrics.md) — metric-name catalog, runtime discovery, and which endpoint accepts which name.
- [CLI](cli.md) — the bundled `epa_pm_api_wrapper` exploration tool.
- [Errors](errors.md) — EPA error-number reference and how to branch on `EpaPmApiError`.
- [API Reference](api.md) — auto-generated reference for every client method, exception, and resource.

## What this library is

A thin, typed client over the ENERGY STAR Portfolio Manager web services
API. It signs requests with HTTP Basic Auth, serializes/deserializes the
EPA's XML payloads to and from `xsdata`-generated dataclasses, retries
transient transport errors, and exposes every published endpoint as a
method on either `EpaPmClient` (sync) or `EpaPmAsyncClient` (async).

## What this library is NOT

A few intentional non-goals — knowing these saves time:

- **Not a schema generator.** The `xsdata` dataclasses under
  `epa_pm_api_wrapper.models` are pre-generated from the EPA's XSDs.
  When EPA ships a new schema version you regenerate them from
  `schemas/` per [`CONTRIBUTING.md`](https://github.com/harryw1/EPA-PM-API-Wrapper/blob/main/CONTRIBUTING.md);
  the wrapper does not regenerate them at runtime.
- **Not an auth broker.** EPA exposes only HTTP Basic Auth; the client
  takes a username/password pair and forwards it. It does not refresh
  tokens, manage sessions, or integrate with SSO.
- **Not an async↔sync bridge.** `EpaPmClient` and `EpaPmAsyncClient`
  are separate classes backed by `httpx.Client` and `httpx.AsyncClient`
  respectively. Pick one for your runtime — the wrapper does not run
  one inside the other.
- **Not a metric-name validator.** Metric names passed to
  `client.metrics.*` are sent verbatim to EPA, which validates them
  server-side. See the [Metrics guide](metrics.md) for runtime
  discovery via `client.report.metrics()`.
- **Not a rate limiter.** The retry layer honors `Retry-After` and backs
  off on 429, but it does not pre-throttle outgoing requests; if you're
  fanning out concurrently you own the concurrency budget.
- **Not a caching layer.** Every call hits EPA. Cache property/metric
  reads in your application if your access pattern needs it.
