# Usage

The EPA PM API Wrapper exposes the entire ENERGY STAR Portfolio Manager web
services API through two clients with parallel surfaces:

- `EpaPmClient` — synchronous, backed by `httpx.Client`
- `EpaPmAsyncClient` — asynchronous, backed by `httpx.AsyncClient`

Resources are attribute-namespaced on both clients (`client.account`,
`client.property`, `client.meter`, etc.).

## Installation

```sh
uv add EPA-PM-API-Wrapper
# or: pip install EPA-PM-API-Wrapper
```

## Authentication and account setup

Portfolio Manager uses HTTP Basic Auth: a username and password belonging to
an account registered on the EPA's site. The wrapper sends them on every
request — there are no tokens, sessions, or refresh flows.

### Live vs. test environment

EPA runs two completely separate environments with separate user databases:

| Environment | Web UI                                            | Webservices base URL                                  | Wrapper flag        |
| ----------- | ------------------------------------------------- | ----------------------------------------------------- | ------------------- |
| Live        | `https://portfoliomanager.energystar.gov/pm`      | `https://portfoliomanager.energystar.gov/ws`          | (default)           |
| Test        | `https://portfoliomanager.energystar.gov/pmtest`  | `https://portfoliomanager.energystar.gov/wstest`      | `use_test_env=True` |

A live username does **not** authenticate against the test environment and
vice versa — register separately. There is no auto-promotion: data written
to the test environment never appears live.

To register accounts, use the "Create a New Account" link on either the
[live](https://portfoliomanager.energystar.gov/pm/login) or
[test](https://portfoliomanager.energystar.gov/pmtest/) login page. The
test environment is the right place to develop and run integration tests
against; data-exchange providers should also request a test data-exchange
relationship via [the EPA's webservices home](https://portfoliomanager.energystar.gov/webservices)
before going live.

### Programmatic credentials

Both clients take `username` and `password` positional args. The
`use_test_env` flag picks the base URL for you; alternatively, pass
`base_url=...` explicitly to point at a private mirror or a future EPA
endpoint.

```python
from epa_pm_api_wrapper import EpaPmClient

with EpaPmClient(username="alice", password="...", use_test_env=True) as client:
    account = client.account.get()
    print(account.id, account.username)
```

Wrong creds against the wrong environment surface as
[`EpaPmAuthError`](errors.md#authentication-errors) on the first request
the client makes — the message reminds you to check both the
username/password pair and the `use_test_env` flag.

### Environment variables and `.env`

The CLI (and any caller that wants the same convention) picks up:

| Variable          | Purpose                                                |
| ----------------- | ------------------------------------------------------ |
| `EPA_PM_USERNAME` | Account username for HTTP Basic Auth.                  |
| `EPA_PM_PASSWORD` | Account password.                                      |
| `EPA_PM_TEST`     | Set to `true` (case-insensitive) to use `wstest`.      |

A `.env` file in the current working directory is loaded automatically by
the CLI (via `python-dotenv`) and **overrides** any pre-set process
environment variables — handy for switching environments per project
checkout. See `.env.example` in the repo root for a template.

For programmatic use, environment variable handling is your call. A common
pattern:

```python
import os
from epa_pm_api_wrapper import EpaPmClient

with EpaPmClient(
    username=os.environ["EPA_PM_USERNAME"],
    password=os.environ["EPA_PM_PASSWORD"],
    use_test_env=os.environ.get("EPA_PM_TEST", "").lower() == "true",
) as client:
    ...
```

## Quickstart

```python
from epa_pm_api_wrapper import EpaPmClient

with EpaPmClient(username, password) as client:
    # Account info for the authenticated user
    account = client.account.get()

    # All properties under that account
    properties = client.property.list(account.id)
    for link in properties.links.link:
        print(link.id, link.hint)

    # One property in detail
    prop = client.property.get(19939329)

    # Score and site EUI for that property in Dec 2025
    metrics = client.metrics.get(
        19939329,
        metrics=["score", "siteEnergyUseAdjustedToCurrentYear"],
        year=2025,
        month=12,
    )
```

The metric names passed to `client.metrics.*` (`score`,
`siteEnergyUseAdjustedToCurrentYear`, …) come from EPA's catalog. See the
[Metrics guide](metrics.md) for runtime discovery via
`client.report.metrics()`, a curated reference of common names, and which
endpoint accepts which metric.

## Async usage

The async client mirrors the sync surface; methods are coroutines:

```python
import asyncio
from epa_pm_api_wrapper import EpaPmAsyncClient

async def main():
    async with EpaPmAsyncClient(username, password) as client:
        account = await client.account.get()
        properties = await client.property.list(account.id)
        for link in properties.links.link:
            prop = await client.property.get(link.id)
            print(prop.name)

asyncio.run(main())
```

For concurrent fan-out, gather the per-property fetches:

```python
async with EpaPmAsyncClient(username, password) as client:
    properties = await client.property.list(account.id)
    details = await asyncio.gather(
        *(client.property.get(link.id) for link in properties.links.link)
    )
```

## Pagination

Consumption and waste data are paged at 120 records per page. Use the
`iter()` helpers to walk all pages without bookkeeping:

```python
# Sync
for record in client.consumption_data.iter(meter_id, start_date="2024-01-01"):
    print(record.start_date, record.usage)

# Async
async for record in async_client.consumption_data.iter(meter_id):
    await persist(record)
```

Same pattern for waste data: `client.waste_data.iter(meter_id)`.

## Error handling

API errors surface as structured exceptions:

- `EpaPmApiError` — non-2xx response. Carries `status_code`, the raw
  `response_text`, a parsed `errors` list of `EpaErrorDetail`, and
  an `error_number` convenience accessor for single-error responses.
- `EpaPmAuthError` — subclass of `EpaPmApiError` raised on 401, with a
  human-friendly message reminding the caller to check credentials and
  environment.
- `EpaPmError` — base class for both, useful for blanket catches.

```python
from epa_pm_api_wrapper import EpaPmApiError

try:
    client.property.get(999)
except EpaPmApiError as e:
    if e.error_number == 10:
        # EPA error 10: invalid property ID
        return None
    raise
```

The flattened message is preserved for backwards compatibility (it appears
when you `str(e)`), but production code should branch on `error_number` /
inspect `e.errors` instead of regexing the message.

See the [Errors guide](errors.md) for a reference of the EPA error numbers
this client surfaces and suggested handling.

## Retries

Both clients retry transient failures by default (3 attempts on 429, 502,
503, 504, plus connection-level errors like `ConnectError` / `ReadTimeout`).
Backoff is exponential with full jitter; the server's `Retry-After` header
is honored when present.

```python
from epa_pm_api_wrapper import EpaPmClient, RetryConfig

# Disable retries entirely
EpaPmClient(username, password, retries=0)

# Just override the attempt count
EpaPmClient(username, password, retries=5)

# Full control
EpaPmClient(
    username, password,
    retry=RetryConfig(
        max_retries=5,
        base_delay=1.0,
        max_delay=60.0,
        retry_status_codes=frozenset({429, 503}),
    ),
)
```

## Configuring the underlying HTTP client

The clients accept three orthogonal knobs:

- `timeout` — float (seconds) or `httpx.Timeout`. Default 30s.
- `transport` — your own `httpx.BaseTransport` / `httpx.AsyncBaseTransport`
  (e.g. for proxies, SOCKS, or custom mounts). The retry layer wraps it
  automatically.
- `http_client` — pass your own pre-built `httpx.Client` /
  `httpx.AsyncClient` to fully control connection pooling, hooks, etc.
  When provided, `timeout`, `transport`, and `retries` are ignored —
  you own the client.

```python
import httpx
from epa_pm_api_wrapper import EpaPmClient

# Custom transport (proxy)
transport = httpx.HTTPTransport(proxy="http://corporate-proxy:3128")
EpaPmClient(username, password, transport=transport)

# Or take complete control
my_client = httpx.Client(proxies="http://corporate-proxy:3128", timeout=60.0)
EpaPmClient(username, password, http_client=my_client)
# my_client lifecycle is your responsibility now
```

## Logging

The package logs to the standard `logging` namespace and never installs
its own handlers — wire it into whatever your application already uses:

- `epa_pm_api_wrapper.client` — DEBUG: outgoing request method/URL/params.
  WARNING: non-2xx responses (with the parsed error message).
- `epa_pm_api_wrapper.retry` — INFO: retry decisions (status code or
  exception, attempt number, computed sleep). WARNING: terminal failure
  after exhausting retries.

```python
import logging

logging.getLogger("epa_pm_api_wrapper").setLevel(logging.INFO)
```

The library does not log credentials or response bodies.

## Common workflows

### Bulk-import consumption data

```python
from epa_pm_api_wrapper import EpaPmClient, MeterConsumption, MeterData
from xsdata.models.datatype import XmlDate
from decimal import Decimal

with EpaPmClient(username, password) as client:
    payload = MeterData(
        meter_consumption=[
            MeterConsumption(
                start_date=XmlDate(2024, 1, 1),
                end_date=XmlDate(2024, 1, 31),
                usage=Decimal("1234.5"),
            ),
            # …more records up to 120 per call…
        ],
    )
    created = client.consumption_data.add(meter_id, payload)
    # The EPA echoes back each record with its server-assigned id populated.
    for record in created.meter_consumption or []:
        print(record.id, record.start_date, record.usage)
```

### Poll a report to completion

```python
import time
from epa_pm_api_wrapper import EpaPmClient

with EpaPmClient(username, password) as client:
    client.report.generate(report_id)

    # Poll until the report is ready, then download.
    while True:
        status = client.report.status(report_id)
        if str(status.status) in {"DONE", "FAILED"}:
            break
        time.sleep(15)

    if str(status.status) == "DONE":
        result = client.report.download(report_id, report_format="XML")
        # EPA may return application/zip even for report_format="XML" when results
        # are large; use result.content_type / result.filename to pick an extension
        # rather than hardcoding .xml.
        save(result.content, content_type=result.content_type, filename=result.filename)
```

The async equivalent uses `asyncio.sleep`:

```python
import asyncio
from epa_pm_api_wrapper import EpaPmAsyncClient

async with EpaPmAsyncClient(username, password) as client:
    await client.report.generate(report_id)
    while True:
        status = await client.report.status(report_id)
        if str(status.status) in {"DONE", "FAILED"}:
            break
        await asyncio.sleep(15)
    result = await client.report.download(report_id, report_format="XML")
```

### Accept all pending property shares

```python
from epa_pm_api_wrapper import AcceptRejectType, EpaPmClient, SharingResponse

with EpaPmClient(username, password) as client:
    pending = client.share.pending_property_shares()
    for prop in pending.property:
        client.share.respond_to_property_share(
            prop.property_id,
            SharingResponse(action=AcceptRejectType.ACCEPT, note="approved"),
        )
```

### Polymorphic property-use lookup

`GET /propertyUse/{id}` returns one of ~50 use-specific element shapes
(`<office>`, `<hotel>`, `<vehicleDealership>`, …). The client auto-resolves
the response to the matching dataclass:

```python
use = client.property_use.get(13255076)
print(type(use).__name__)  # e.g. "VehicleDealership"
print(use.name)            # PropertyUse base attributes still apply
```

The declared return type is the abstract base (`PropertyUse`); the runtime
type is the concrete subtype.

### Bulk-import waste data

`waste_data.add()` requires the request body wrapped in a `WasteDataList`
(matching the EPA's wire format), not a bare record — even for one entry.
The response echoes the created records with server-assigned IDs:

```python
from epa_pm_api_wrapper import EpaPmClient
from epa_pm_api_wrapper.models import WasteData, WasteDataList
from xsdata.models.datatype import XmlDate
from decimal import Decimal

with EpaPmClient(username, password) as client:
    payload = WasteDataList(
        waste_data=[
            WasteData(
                start_date=XmlDate(2024, 1, 1),
                end_date=XmlDate(2024, 1, 31),
                quantity=Decimal("125.5"),
            ),
            # …more records up to 120 per call…
        ],
    )
    created = client.waste_data.add(meter_id, payload)
    for record in created.waste_data or []:
        print(record.id, record.start_date, record.quantity)
```

### Energy meters vs. waste meters

`GET /meter/{id}` returns either `<meter>` (energy, water, etc.) or
`<wasteMeter>` (trash, recycling, …) depending on the meter type, with
disjoint child schemas. `meter.get()` returns `Meter | WasteMeter` and
auto-resolves to the matching dataclass; disambiguate with `isinstance`:

```python
from epa_pm_api_wrapper.models import WasteMeter

m = client.meter.get(meter_id)
if isinstance(m, WasteMeter):
    print(m.data_entry_method, m.container_size)
else:
    print(m.type_value, m.unit_of_measure, m.metered)
```

## Onboarding a property (data-exchange providers)

A typical SaaS or service-provider integration covers the same chain
every time: the customer requests a connection from inside Portfolio
Manager, the provider accepts, the provider creates one or more
properties on the customer's behalf (or the customer shares an existing
property), meters get added, consumption rolls in, and metrics come back.
This section walks through that lifecycle with the wrapper's primitives.

The pattern below assumes you are the **provider** authenticated as your
own data-exchange account. The customer's account ID is exposed via the
share/connection objects — you don't ever authenticate as the customer.

### 1. Accept the customer connection

The customer kicks things off by clicking "Connect" against your provider
account in their Portfolio Manager UI. That request lands in
`client.share.pending_connections()`:

```python
from epa_pm_api_wrapper import (
    AcceptRejectType,
    EpaPmClient,
    SharingResponse,
)

with EpaPmClient(username, password) as client:
    pending = client.share.pending_connections()
    for account in pending.account:
        client.share.respond_to_connection(
            account.account_id,
            SharingResponse(
                action=AcceptRejectType.ACCEPT,
                note="Welcome — connected.",
            ),
        )
```

Once accepted, the customer shows up in `client.customer.list()` and you
can read their account info with `client.customer.get(customer_id)`.

### 2. Accept any property/meter shares

If the customer already has a property in Portfolio Manager and shares it
with you, accept it the same way:

```python
with EpaPmClient(username, password) as client:
    pending_props = client.share.pending_property_shares()
    for prop in pending_props.property:
        client.share.respond_to_property_share(
            prop.property_id,
            SharingResponse(action=AcceptRejectType.ACCEPT),
        )

    pending_meters = client.share.pending_meter_shares()
    for meter in pending_meters.meter:
        client.share.respond_to_meter_share(
            meter.meter_id,
            SharingResponse(action=AcceptRejectType.ACCEPT),
        )
```

Skip this step if you create the property yourself in step 3.

### 3. Create a property on the customer's account

Provider workflows typically own the property record. The body is a
`Property` dataclass; only a few fields are required, but `name`,
`primary_function`, `address`, `year_built`, `gross_floor_area`, and
`construction_status` cover most use cases. The newly created
property's ID comes back inside `Response.links` — use the exported
`link_id` helper to extract it:

```python
from epa_pm_api_wrapper import EpaPmClient, link_id
from epa_pm_api_wrapper.models import (
    AddressType,
    AddressTypeState,
    ConstructionStatusType,
    CountryList,
    GrossFloorAreaType,
    GrossFloorAreaUnitsType,
    OccupancyType,
    PrimaryFunctionType,
    Property,
)

new_property = Property(
    name="Acme HQ",
    primary_function=PrimaryFunctionType.OFFICE,
    address=AddressType(
        address1="123 Main St",
        city="Trenton",
        state=AddressTypeState.NJ,
        postal_code="08608",
        country=CountryList.US,
    ),
    year_built=2010,
    gross_floor_area=GrossFloorAreaType(
        units=GrossFloorAreaUnitsType.SQUARE_FEET,
        value=50_000,
    ),
    occupancy_percentage=OccupancyType.VALUE_95,
    construction_status=ConstructionStatusType.EXISTING,
)

with EpaPmClient(username, password) as client:
    customers = client.customer.list()
    # Pick the customer you just connected — usually you persist this id yourself.
    customer_id = customers.links.link[0].id

    resp = client.property.create(customer_id, new_property)
    assert resp.links and resp.links.link, "EPA response missing the new property link"
    property_id = link_id(resp.links.link[0])
    assert property_id is not None
```

`property.create` returns a `Response`; the new property ID lives at
`response.id` when EPA populates it directly, or in the trailing path
component of `response.links.link[0].link` (e.g. `/property/19939329`)
otherwise. The `link_id` helper exported from the package handles both
shapes.

### 4. Add the right property uses

A property's score depends on the property uses defined under it (an
office's gross floor area, a hotel's number of rooms, …). Each use is a
concrete subtype — `Office`, `Hotel`, `VehicleDealership`, etc. — and is
created via `client.property_use.create`:

```python
from decimal import Decimal
from epa_pm_api_wrapper.models import (
    GrossFloorAreaUnitsType,
    Office,
    OfficeTypeUseDetails,
    TotalGrossFloorArea,
    WeeklyOperatingHours,
)
from xsdata.models.datatype import XmlDate

office = Office(
    name="Acme HQ — Office",
    use_details=OfficeTypeUseDetails(
        total_gross_floor_area=TotalGrossFloorArea(
            units=GrossFloorAreaUnitsType.SQUARE_FEET,
            value=50_000,
            current_as_of=XmlDate(2024, 1, 1),
            temporary=False,
        ),
        weekly_operating_hours=WeeklyOperatingHours(
            value=Decimal("50"),
            current_as_of=XmlDate(2024, 1, 1),
            temporary=False,
        ),
    ),
)

with EpaPmClient(username, password) as client:
    use_resp = client.property_use.create(property_id, office)
    if use_resp.links and use_resp.links.link:
        use_id = link_id(use_resp.links.link[0])
```

Set `temporary=False` on each use detail — EPA rejects writes that omit
that flag even though the XSD permits it.

### 5. Add meters and consumption data

Energy and water meters use `Meter`; trash/recycling streams use
`WasteMeter`. After creation, attach consumption records (up to 120 per
call):

```python
from decimal import Decimal
from epa_pm_api_wrapper import MeterConsumption, MeterData
from epa_pm_api_wrapper.models import (
    Meter,
    MeterTypeUnitOfMeasure,
    TypeOfMeter,
)
from xsdata.models.datatype import XmlDate

electric_meter = Meter(
    type_value=TypeOfMeter.ELECTRIC,
    name="Acme HQ — Electric",
    unit_of_measure=MeterTypeUnitOfMeasure.K_WH_THOUSAND_WATT_HOURS,
    metered=True,
    first_bill_date=XmlDate(2024, 1, 1),
    in_use=True,
)

with EpaPmClient(username, password) as client:
    meter_resp = client.meter.create(property_id, electric_meter)
    assert meter_resp.links and meter_resp.links.link
    meter_id = link_id(meter_resp.links.link[0])
    assert meter_id is not None

    payload = MeterData(
        meter_consumption=[
            MeterConsumption(
                start_date=XmlDate(2024, 1, 1),
                end_date=XmlDate(2024, 1, 31),
                usage=Decimal("12345.6"),
            ),
            MeterConsumption(
                start_date=XmlDate(2024, 2, 1),
                end_date=XmlDate(2024, 2, 29),
                usage=Decimal("11000.0"),
            ),
        ],
    )
    created = client.consumption_data.add(meter_id, payload)
    for record in created.meter_consumption or []:
        print(record.id, record.start_date, record.usage)
```

EPA echoes each created record back with its server-assigned ID populated
on the `MeterData` envelope, so you don't need a follow-up GET to track
them.

### 6. Associate meters with the property

A meter created under a property still needs to be marked as part of the
property's energy/water/waste totals. The simplest path is one call per
meter:

```python
with EpaPmClient(username, password) as client:
    client.association.property_meters.add_one(property_id, meter_id)
```

Use `client.association.property_meters.set_many(property_id, ...)` (with a
`MeterPropertyAssociationList` body) to set the full association list in
one POST — useful when reconciling against a customer-supplied source of
truth. See the [API reference](api.md) for the full shape under
`client.association`.

### 7. Read metrics back

Once a property has at least 12 months of consumption against the
correct meters and use details, ENERGY STAR scores and EUIs become
available:

```python
with EpaPmClient(username, password) as client:
    metrics = client.metrics.get(
        property_id,
        metrics=["score", "siteEUI", "sourceEUI", "siteEnergyUseAdjustedToCurrentYear"],
        year=2024,
        month=12,
    )
    for m in metrics.metric:
        print(m.name, m.value, m.uom)
```

If `score` (or any other metric) comes back empty, ask
`client.metrics.reasons_for_no_score(property_id, year, month)` for a
list of `Alerts` explaining what's missing — usually under-12-months of
data, an unsupported primary function, or out-of-range use details. See
the [Metrics guide](metrics.md) for the full discovery story.

## Going deeper

Every endpoint in the EPA Portfolio Manager web services API is bound to
either a method or a sub-namespace on the client. See
[the API reference](api.md) for the full surface — clients, exceptions,
retry config, and one section per resource (`client.account`,
`client.property`, `client.meter`, …) generated from the docstrings on
each resource class.
