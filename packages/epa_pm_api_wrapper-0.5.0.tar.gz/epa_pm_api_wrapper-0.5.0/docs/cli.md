# Command-line interface

The package ships with a `typer`-based CLI for ad-hoc lookups against the
Portfolio Manager API. It is intentionally read-only and limited to the
most common exploration queries — for the full ~70-endpoint surface,
instantiate `EpaPmClient` directly from your application.

## Invocation

The console script is registered as `epa_pm_api_wrapper`:

```sh
epa_pm_api_wrapper --help
epa_pm_api_wrapper account
epa_pm_api_wrapper get-property 19939329 --test
```

If the script isn't on your `PATH`, fall back to module form (works the
same way):

```sh
uv run python -m epa_pm_api_wrapper account
```

## Authentication

Every command takes the same three options:

| Flag           | Env var            | Notes                                                         |
| -------------- | ------------------ | ------------------------------------------------------------- |
| `--username`   | `EPA_PM_USERNAME`  | EPA Portfolio Manager username.                               |
| `--password`   | `EPA_PM_PASSWORD`  | EPA password (input is hidden when prompted on the terminal). |
| `--test`       | `EPA_PM_TEST`      | Switch to `wstest`; default is the live environment.          |

Precedence:

1. **`.env` in the current working directory** — loaded by `python-dotenv`
   on startup with `override=True`, so `.env` wins over any matching
   variable already set in the shell environment. See `.env.example` in
   the repo root.
2. **Process environment variables** — used when `.env` is absent or
   doesn't define the variable.
3. **Explicit CLI flags** — `--username`, `--password`, `--test` override
   anything from the environment for that single invocation.
4. **Interactive prompt** — if `--username` / `--password` resolve to
   nothing after the previous steps, `typer` prompts on the terminal.

## Output

All commands print to the terminal via [`rich`](https://rich.readthedocs.io/) —
either a labelled details block (for single-resource fetches like
`account`, `get-property`, `get-meter`) or a `rich.Table` for list
endpoints. Tables are not machine-friendly; pipe through `tee` and parse
manually if needed, or call the API from Python for structured output.

## Exit codes

The CLI catches every exception inside each command and prints a red
`Error:` line, then returns the typer default exit code. It does **not**
currently propagate non-zero exit codes on failure — if you script around
the CLI, parse stderr/stdout for an `Error:` prefix or (better) use the
Python client and branch on `EpaPmApiError`.

## Commands

All commands are listed below. Run `epa_pm_api_wrapper <command> --help`
for the full per-command flag list.

### Account

`account`
:   Print the authenticated user's account ID, username, organization
    name, and primary business.

### Properties

`list-properties ACCOUNT_ID`
:   Tabulate properties under the given account ID.

`get-property PROPERTY_ID`
:   Print a single property's name, primary function, and address.

`list-property-uses PROPERTY_ID`
:   Tabulate property uses defined under a property.

`list-buildings PROPERTY_ID`
:   Tabulate buildings under a property.

### Meters and consumption

`list-meters PROPERTY_ID`
:   Tabulate meters on a property.

`get-meter METER_ID`
:   Print a single meter's name, type, unit, and in-use flag.
    Auto-detects energy vs. waste meters.

`get-consumption METER_ID [--page N] [--start-date YYYY-MM-DD] [--end-date YYYY-MM-DD]`
:   Tabulate consumption records for a meter (one page of up to 120
    records per call, default `--page 1`).

### Connections and shares

`list-customers`
:   Tabulate customers connected to your account.

`list-pending-shares`
:   Print counts of pending property shares, meter shares, and account
    connection requests waiting on your action.

### Catalogs

`list-edu PROPERTY_ID`
:   List Electric Distribution Utilities available for a property.

`list-federal-agencies`
:   List federal agencies (catalog).

`list-egrid-subregions`
:   List eGrid subregions (catalog).

### Reporting

`list-reports`
:   Tabulate reports in your account.

`list-report-templates`
:   Tabulate report templates available to your account.

## Going beyond the CLI

The CLI deliberately covers only the common cases. Anything not listed
above (creating properties or meters, accepting shares, polling reports
to completion, fetching metrics, bulk-importing data) is one or two
lines of Python through `EpaPmClient` — see [Usage](usage.md) for
worked examples.
