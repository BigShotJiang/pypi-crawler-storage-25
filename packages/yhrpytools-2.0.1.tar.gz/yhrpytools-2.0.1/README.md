
# yhrPyTools

## 描述
YuHaoran的python工具包
Python tools for climate data analysis.
主要用来做气候数据的数据处理工作。

## Modules
1. **ETCCDI** - Extreme climate indices calculation


## 联系方式
1. E-mail：yuhaoran251@mails.ucas.ac.cn
2. Wechat(username):@余浩然2002

## Installation

```bash
pip install yhrPyTools
```
