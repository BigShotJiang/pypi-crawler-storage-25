# yhrpyTools 文档

## 模块文档

1. [ETCCDI 操作文档](ETCCDI.md)
2. [CSM 操作文档](CSM.md)
3. [PRV 操作文档](PRV.md)
4. [NCtoTIFF 操作文档](NCtoTIFF.md)
5. [BCSD 操作文档](BCSD.md)

## 说明

1. `ETCCDI.md`：极端气候指数（降水+温度）的输入要求、函数说明与示例。
2. `CSM.md`：空间平均计算（含 shp 范围裁剪）的参数说明与示例。
3. `PRV.md`：降水变异系数（CV）计算的函数说明与示例。
4. `NCtoTIFF.md`：NetCDF 按时间裁剪并批量导出 GeoTIFF 的参数说明与示例。
5. `BCSD.md`：偏差校正与空间降尺度（BCSD）流程说明、参数解释与使用示例。
