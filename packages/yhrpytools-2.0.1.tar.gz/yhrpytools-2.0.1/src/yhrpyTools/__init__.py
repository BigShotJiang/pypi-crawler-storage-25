"""yhrpyTools 顶层包。

该文件统一暴露各子模块，并兼容历史拼写 `Precioitation_Varoablity`。
"""

from importlib.metadata import PackageNotFoundError, version

from . import BCSD, ETCCDI, Precioitation_Variablity, Supporting_Tools

# 历史兼容别名（旧拼写）
Precioitation_Varoablity = Precioitation_Variablity

try:
	__version__ = version("yhrPyTools")
except PackageNotFoundError:
	__version__ = "0+unknown"

__all__ = [
	"BCSD",
	"ETCCDI",
	"Precioitation_Variablity",
	"Precioitation_Varoablity",
	"Supporting_Tools",
	"__version__",
]
