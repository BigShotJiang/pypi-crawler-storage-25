"""降水变率子包导出入口。"""

from .precip_variability_netcdf import *  # noqa: F401,F403

# 向后兼容：若仓库中仍存在旧版 PRV.py，则继续导出其符号。
try:
	from .PRV import *  # type: ignore # noqa: F401,F403
except ImportError:
	pass

__all__ = [name for name in globals() if not name.startswith("_")]
