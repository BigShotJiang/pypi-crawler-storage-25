# 示例：调用BCSD主流程进行计算


import BCSD1

# 输入文件路径
obs_path = r"F:/Program/4EC/BCSD/CN05/CN051961-2023_region.nc"
hist_path = r"F:/Program/4EC/BCSD/Output/01Region/CMIP6/EC-Earth3-Veg_gr/pr_EC-Earth3-Veg_historical_r1i1p1f1_gr_19610101-20141231_region.nc"
fut_path = r"F:/Program/4EC/BCSD/Output/01Region/CMIP6/EC-Earth3-Veg_gr/pr_EC-Earth3-Veg_ssp585_r1i1p1f1_gr_20150101-21001231_region.nc"

# 输出目录
output_dir = r"e:/Haoran/Tools/Python/yhrPyTools/example/output"

# 运行BCSD完整流程
result = BCSD1.BCSD(
    obs_path=obs_path,
    gcm_hist_path=hist_path,
    gcm_fut_path=fut_path,
    model_name="EC-Earth3-Veg",
    output_dir=output_dir,
    ref_start_year=1961,
    ref_end_year=2014
)

print("BCSD运行结果：", result)
