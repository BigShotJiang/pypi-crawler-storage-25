import xarray as xr
import matplotlib.pyplot as plt

ds = xr.open_dataset('e:/Haoran/Tools/Python/yhrPyTools/example/output/EC-Earth3-Veg/EC-Earth3-Veg_future_BCSD.nc')

pr = ds['pr']
pr_year = pr.resample(Time='1Y').sum(dim='Time')  # 年总降水

pr_year_mean = pr_year.mean(dim=['Lat', 'Lon'])  # 空间平均

plt.figure(figsize=(10, 5))
pr_year_mean.plot(marker='o')
plt.title('年总降水量时间序列')
plt.xlabel('年份')
plt.ylabel('年总降水量 (mm)')
plt.grid(True)
plt.show()

