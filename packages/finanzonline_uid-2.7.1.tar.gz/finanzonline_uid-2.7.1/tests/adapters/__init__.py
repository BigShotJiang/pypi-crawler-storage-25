"""Adapters layer tests."""
