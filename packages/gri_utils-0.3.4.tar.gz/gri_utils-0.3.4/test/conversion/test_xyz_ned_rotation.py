import numpy as np
import pytest

from gri_utils import constants
from gri_utils.conversion import ned_xyz_rotation, xyz_ned_rotation

# Type aliases for readability
XYZ = tuple[float, float, float]
Matrix3x3 = tuple[tuple[float, float, float], ...]


@pytest.mark.parametrize(
    ("xyz", "expected_ned", "expected_xyz"),
    [
        # On X axis
        (
            (constants.ER_M, 0, 0),
            ((0, 0, -1), (0, 1, 0), (1, 0, 0)),
            ((0, 0, 1), (0, 1, 0), (-1, 0, 0)),
        ),
    ],
)
def test_transform_matrix(
    xyz: XYZ,
    expected_ned: Matrix3x3,
    expected_xyz: Matrix3x3,
) -> None:
    """Test NED/XYZ transform matrices with both array and sequence inputs."""
    # Test with sequence input
    tned_seq = ned_xyz_rotation(xyz)
    assert np.allclose(tned_seq, np.array(expected_ned))

    # Test with array input
    tned_arr = ned_xyz_rotation(np.array(xyz))
    assert np.allclose(tned_arr, np.array(expected_ned))

    # Test xyz_ned_transform (geocentric)
    txyz = xyz_ned_rotation(xyz, geocentric=True)
    assert np.allclose(txyz, np.array(expected_xyz))

    # Verify transpose relationship
    assert np.allclose(txyz, tned_arr.T)
