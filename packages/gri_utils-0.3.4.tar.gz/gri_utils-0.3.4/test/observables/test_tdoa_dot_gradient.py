"""Tests for TDOA-dot gradient computation.

Verifies analytical gradients of TDOA-dot w.r.t. emitter position and velocity
against central-difference numerical derivatives, plus structural identities.
"""

from collections.abc import Callable

import numpy as np
from numpy.typing import NDArray

from gri_utils.constants import C
from gri_utils.observables import (
    fdoa_with_gradient,
    get_tdoa_dot,
    tdoa_dot_with_gradient,
)


def _numerical_grad(
    func: Callable[[NDArray[np.floating]], float],
    x: NDArray[np.floating],
    eps: float = 1e-6,
) -> NDArray[np.floating]:
    grad = np.zeros_like(x, dtype=np.float64)
    for j in range(x.size):
        xp = x.copy()
        xp.flat[j] += eps
        xm = x.copy()
        xm.flat[j] -= eps
        grad.flat[j] = (func(xp) - func(xm)) / (2.0 * eps)
    return grad


def test_position_gradient_matches_finite_differences() -> None:
    """Analytical position gradient matches numerical finite differences."""
    emit_xyz = np.array([6378137.0, 500.0, 300.0])
    emit_vel = np.array([50.0, -100.0, 25.0])
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])
    c1_vel = np.array([10.0, 7500.0, 0.0])
    c2_vel = np.array([-5.0, 7400.0, 50.0])

    _, grad_pos, _ = tdoa_dot_with_gradient(
        emit_xyz,
        emit_vel,
        c1_xyz,
        c2_xyz,
        collector1_vel=c1_vel,
        collector2_vel=c2_vel,
    )

    numerical = _numerical_grad(
        lambda p: float(
            get_tdoa_dot(
                p,
                emit_vel,
                c1_xyz,
                c2_xyz,
                collector1_vel=c1_vel,
                collector2_vel=c2_vel,
            ),
        ),
        emit_xyz,
    )

    assert np.allclose(grad_pos, numerical, rtol=1e-3, atol=1e-14)


def test_velocity_gradient_matches_finite_differences() -> None:
    """Analytical velocity gradient matches numerical finite differences."""
    emit_xyz = np.array([6378137.0, 500.0, 300.0])
    emit_vel = np.array([50.0, -100.0, 25.0])
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])

    _, _, grad_vel = tdoa_dot_with_gradient(emit_xyz, emit_vel, c1_xyz, c2_xyz)

    numerical = _numerical_grad(
        lambda v: float(get_tdoa_dot(emit_xyz, v, c1_xyz, c2_xyz)),
        emit_vel,
    )

    assert np.allclose(grad_vel, numerical, rtol=1e-6, atol=1e-18)


def test_velocity_gradient_closed_form() -> None:
    """Velocity gradient equals (unit2 - unit1) / c."""
    emit_xyz = np.array([6378137.0, 0.0, 0.0])
    emit_vel = np.array([50.0, -100.0, 25.0])
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])

    _, _, grad_vel = tdoa_dot_with_gradient(emit_xyz, emit_vel, c1_xyz, c2_xyz)

    diff1 = c1_xyz - emit_xyz
    diff2 = c2_xyz - emit_xyz
    unit1 = diff1 / np.linalg.norm(diff1)
    unit2 = diff2 / np.linalg.norm(diff2)
    expected = (unit2 - unit1) / C

    assert np.allclose(grad_vel, expected, atol=1e-18)


def test_identity_with_fdoa_gradient() -> None:
    """tdoa_dot gradients equal -fdoa gradients / f0."""
    emit_xyz = np.array([6378137.0, 500.0, 300.0])
    emit_vel = np.array([50.0, -100.0, 25.0])
    c1_xyz = np.array([7000000.0, -300000.0, 100000.0])
    c2_xyz = np.array([7000000.0, 300000.0, 100000.0])
    c1_vel = np.array([0.0, 7500.0, 0.0])
    c2_vel = np.array([0.0, 7400.0, 100.0])
    freq_hz = 1.5e9

    td_val, td_gp, td_gv = tdoa_dot_with_gradient(
        emit_xyz,
        emit_vel,
        c1_xyz,
        c2_xyz,
        collector1_vel=c1_vel,
        collector2_vel=c2_vel,
    )
    f_val, f_gp, f_gv = fdoa_with_gradient(
        emit_xyz,
        emit_vel,
        c1_xyz,
        c2_xyz,
        freq_hz,
        collector1_vel=c1_vel,
        collector2_vel=c2_vel,
    )

    assert np.isclose(td_val, -f_val / freq_hz, rtol=1e-12, atol=1e-18)
    assert np.allclose(td_gp, -f_gp / freq_hz, rtol=1e-12, atol=1e-18)
    assert np.allclose(td_gv, -f_gv / freq_hz, rtol=1e-12, atol=1e-18)


def test_value_matches_non_gradient_function() -> None:
    """Gradient function returns identical TDOA-dot as get_tdoa_dot."""
    emit_xyz = np.array([6378137.0, 500.0, 300.0])
    emit_vel = np.array([50.0, -100.0, 25.0])
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])

    td_simple = get_tdoa_dot(emit_xyz, emit_vel, c1_xyz, c2_xyz)
    td_grad, _, _ = tdoa_dot_with_gradient(emit_xyz, emit_vel, c1_xyz, c2_xyz)

    assert np.isclose(td_simple, td_grad, atol=1e-18)


def test_batch_shapes() -> None:
    """Batch inputs give batched outputs of correct shape."""
    emits_xyz = np.array(
        [
            [6378137.0, 0.0, 0.0],
            [6378137.0, 500.0, 0.0],
            [6378137.0, 0.0, 1000.0],
        ],
    )
    emits_vel = np.array(
        [
            [0.0, -100.0, 0.0],
            [50.0, 50.0, 0.0],
            [0.0, 0.0, -50.0],
        ],
    )
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])

    tdoa_dots, grad_pos, grad_vel = tdoa_dot_with_gradient(
        emits_xyz,
        emits_vel,
        c1_xyz,
        c2_xyz,
    )

    assert tdoa_dots.shape == (3,)
    assert grad_pos.shape == (3, 3)
    assert grad_vel.shape == (3, 3)
