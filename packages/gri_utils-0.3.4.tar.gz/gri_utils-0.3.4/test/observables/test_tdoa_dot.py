"""Tests for TDOA-dot (time derivative of TDOA) observable computation.

TDOA-dot is the frequency-independent form of FDOA, related by:
    FDOA = -f0 * TDOA_dot
"""

import numpy as np

from gri_utils.constants import C
from gri_utils.observables import get_fdoa, get_tdoa_dot, get_tdoa_dot_residual


def test_stationary_emitter_and_collectors_gives_zero() -> None:
    """All zero velocities produce zero TDOA-dot."""
    emit_xyz = np.array([6378137.0, 0.0, 0.0])
    emit_vel = np.zeros(3)
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])

    tdoa_dot = get_tdoa_dot(emit_xyz, emit_vel, c1_xyz, c2_xyz)

    assert np.isclose(tdoa_dot, 0.0, atol=1e-15)


def test_perpendicular_velocity_gives_zero() -> None:
    """Velocity perpendicular to both unit vectors gives zero TDOA-dot."""
    emit_xyz = np.array([6378137.0, 0.0, 0.0])
    emit_vel = np.array([0.0, 0.0, 100.0])
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])

    tdoa_dot = get_tdoa_dot(emit_xyz, emit_vel, c1_xyz, c2_xyz)

    assert np.isclose(tdoa_dot, 0.0, atol=1e-15)


def test_matches_negative_fdoa_over_frequency() -> None:
    """Verify the identity TDOA_dot = -FDOA / f0 across a mixed geometry."""
    emit_xyz = np.array([6378137.0, 500.0, 300.0])
    emit_vel = np.array([50.0, -120.0, 25.0])
    c1_xyz = np.array([7000000.0, -300000.0, 100000.0])
    c2_xyz = np.array([7000000.0, 300000.0, 100000.0])
    c1_vel = np.array([0.0, 7500.0, 0.0])
    c2_vel = np.array([0.0, 7400.0, 100.0])
    freq_hz = 2.4e9

    tdoa_dot = get_tdoa_dot(
        emit_xyz,
        emit_vel,
        c1_xyz,
        c2_xyz,
        collector1_vel=c1_vel,
        collector2_vel=c2_vel,
    )
    fdoa = get_fdoa(
        emit_xyz,
        emit_vel,
        c1_xyz,
        c2_xyz,
        freq_hz,
        collector1_vel=c1_vel,
        collector2_vel=c2_vel,
    )

    assert np.isclose(tdoa_dot, -fdoa / freq_hz, rtol=1e-12, atol=1e-18)


def test_closed_form_geometry() -> None:
    """Emitter equidistant from collectors, moving toward c1 along Y."""
    # unit1 points from emit -> c1 = (0, -1, 0); unit2 = (0, 1, 0)
    # v_emit - v_coll = v_emit = (0, -100, 0)
    # v_radial1 = v_rel1 . unit1 = (0,-100,0) . (0,-1,0) = 100
    # v_radial2 = v_rel2 . unit2 = (0,-100,0) . (0,1,0) = -100
    # TDOA_dot = (v_radial2 - v_radial1) / c = -200 / c
    emit_xyz = np.array([6378137.0, 0.0, 0.0])
    emit_vel = np.array([0.0, -100.0, 0.0])
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])

    tdoa_dot = get_tdoa_dot(emit_xyz, emit_vel, c1_xyz, c2_xyz)

    assert np.isclose(tdoa_dot, -200.0 / C, rtol=1e-12)


def test_scales_linearly_with_velocity() -> None:
    """TDOA-dot is linear in emitter velocity."""
    emit_xyz = np.array([6378137.0, 0.0, 0.0])
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])

    td1 = get_tdoa_dot(emit_xyz, np.array([0.0, -100.0, 0.0]), c1_xyz, c2_xyz)
    td2 = get_tdoa_dot(emit_xyz, np.array([0.0, -300.0, 0.0]), c1_xyz, c2_xyz)

    assert np.isclose(td2, 3.0 * td1, rtol=1e-12)


def test_batch_emitters() -> None:
    """Batched emitter positions and velocities broadcast correctly."""
    emits_xyz = np.array(
        [
            [6378137.0, 0.0, 0.0],
            [6378137.0, 500.0, 0.0],
            [6378137.0, -500.0, 0.0],
        ],
    )
    emits_vel = np.array(
        [
            [0.0, -100.0, 0.0],
            [0.0, 100.0, 0.0],
            [0.0, 0.0, 100.0],
        ],
    )
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])

    tdoa_dots = get_tdoa_dot(emits_xyz, emits_vel, c1_xyz, c2_xyz)

    assert tdoa_dots.shape == (3,)
    # Emitter 0 moves toward c1 -> r1 shrinks faster than r2 -> TDOA_dot negative
    assert tdoa_dots[0] < 0
    # Emitter 1 moves toward c2 -> r2 shrinks faster -> TDOA_dot positive
    assert tdoa_dots[1] > 0


def test_single_returns_scalar_array() -> None:
    """Single emitter returns 0-d array."""
    tdoa_dot = get_tdoa_dot(
        np.array([6378137.0, 0.0, 0.0]),
        np.array([0.0, -100.0, 0.0]),
        np.array([6378137.0, -1000.0, 0.0]),
        np.array([6378137.0, 1000.0, 0.0]),
    )
    assert tdoa_dot.ndim == 0 or tdoa_dot.shape == ()


def test_accepts_lists() -> None:
    """Function accepts Python lists."""
    tdoa_dot = get_tdoa_dot(
        [6378137.0, 0.0, 0.0],
        [0.0, 0.0, 0.0],
        [6378137.0, -1000.0, 0.0],
        [6378137.0, 1000.0, 0.0],
    )
    assert np.isclose(tdoa_dot, 0.0, atol=1e-15)


def test_residual_zero_at_true_value() -> None:
    """Residual evaluates to zero when candidate position is the true emitter."""
    emit_xyz = np.array([6378137.0, 200.0, 50.0])
    emit_vel = np.array([0.0, -80.0, 10.0])
    c1_xyz = np.array([6378137.0, -1000.0, 0.0])
    c1_vel = np.array([0.0, 7500.0, 0.0])
    c2_xyz = np.array([6378137.0, 1000.0, 0.0])
    c2_vel = np.array([0.0, 7400.0, 0.0])

    true_tdoa_dot = get_tdoa_dot(
        emit_xyz,
        emit_vel,
        c1_xyz,
        c2_xyz,
        collector1_vel=c1_vel,
        collector2_vel=c2_vel,
    )
    residual = get_tdoa_dot_residual(
        c1_xyz,
        c1_vel,
        c2_xyz,
        c2_vel,
        float(true_tdoa_dot),
        emitter_vel=emit_vel,
    )

    assert np.isclose(residual(emit_xyz), 0.0, atol=1e-15)
