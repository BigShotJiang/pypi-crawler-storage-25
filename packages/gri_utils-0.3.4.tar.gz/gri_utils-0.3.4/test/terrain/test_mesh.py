import numpy as np
import pytest

from gri_utils.terrain.mesh import compute_vertex_normals


def test_single_triangle_normals():
    """All three vertices of a single triangle share the same normal."""
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=np.float64)
    faces = np.array([[0, 1, 2]], dtype=np.int32)
    normals = compute_vertex_normals(vertices, faces)
    expected = np.array([0, 0, 1], dtype=np.float64)
    for i in range(3):
        assert normals[i] == pytest.approx(expected, abs=1e-12)


def test_normals_are_unit_length():
    """All vertex normals should be unit length."""
    vertices = np.array(
        [[0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0]],
        dtype=np.float64,
    )
    faces = np.array([[0, 1, 2], [1, 3, 2]], dtype=np.int32)
    normals = compute_vertex_normals(vertices, faces)
    lengths = np.linalg.norm(normals, axis=1)
    assert lengths == pytest.approx(np.ones(4), abs=1e-12)


def test_shared_vertex_averages_faces():
    """A vertex shared by two angled faces gets the averaged normal."""
    # Two triangles meeting at a 90-degree dihedral along the x-axis
    vertices = np.array(
        [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]],
        dtype=np.float64,
    )
    # Triangle 1: XY plane (normal +Z), Triangle 2: XZ plane (normal +Y)
    faces = np.array([[0, 1, 2], [0, 3, 1]], dtype=np.int32)
    normals = compute_vertex_normals(vertices, faces)

    # Vertices 0 and 1 are shared -- their normals average +Z and +Y
    avg = np.array([0, 1, 1], dtype=np.float64)
    avg /= np.linalg.norm(avg)
    assert normals[0] == pytest.approx(avg, abs=1e-12)
    assert normals[1] == pytest.approx(avg, abs=1e-12)

    # Vertex 2 only in face 1 (XY plane)
    assert normals[2] == pytest.approx([0, 0, 1], abs=1e-12)

    # Vertex 3 only in face 2 (XZ plane)
    assert normals[3] == pytest.approx([0, 1, 0], abs=1e-12)


def test_quad_grid_flat():
    """A flat 2x2 quad grid should have all normals pointing up."""
    vertices = np.array(
        [[0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0]],
        dtype=np.float64,
    )
    faces = np.array([[0, 1, 2], [1, 3, 2]], dtype=np.int32)
    normals = compute_vertex_normals(vertices, faces)
    for i in range(4):
        assert normals[i] == pytest.approx([0, 0, 1], abs=1e-12)
