import math

import numpy as np
import pytest

from gri_utils.constants import ER_M
from gri_utils.conversion import lla_to_xyz, xyz_to_lla
from gri_utils.orbit.footprint import compute_footprint, compute_footprint_bounds


def test_footprint_points_on_surface():
    """All footprint points should be near the Earth's surface."""
    sat_xyz = lla_to_xyz([0.0, 0.0, 400_000.0])
    points = compute_footprint(sat_xyz, n_points=36)
    radii = np.linalg.norm(points, axis=1)
    # Should be close to Earth radius (within ~22km for WGS84 oblateness)
    assert radii == pytest.approx(np.full(36, ER_M), abs=22_000)


def test_footprint_centered_on_subsatellite():
    """Footprint center of mass should be near sub-satellite point."""
    sat_xyz = lla_to_xyz([30.0, -90.0, 800_000.0])
    points = compute_footprint(sat_xyz, n_points=360)
    centroid_xyz = points.mean(axis=0)
    centroid_lla = xyz_to_lla(centroid_xyz)
    assert centroid_lla[0] == pytest.approx(30.0, abs=2.0)
    assert centroid_lla[1] == pytest.approx(-90.0, abs=2.0)


def test_footprint_higher_is_larger():
    """A higher satellite should have a larger footprint."""
    low = lla_to_xyz([0.0, 0.0, 400_000.0])
    high = lla_to_xyz([0.0, 0.0, 2_000_000.0])
    fp_low = compute_footprint(low, n_points=36)
    fp_high = compute_footprint(high, n_points=36)

    # Compare average angular distance from sub-sat point
    def avg_angle(fp: np.ndarray, sat: np.ndarray) -> float:
        sub_lla = xyz_to_lla(sat)
        sub_xyz = lla_to_xyz([sub_lla[0], sub_lla[1], 0.0])
        sub_unit = sub_xyz / np.linalg.norm(sub_xyz)
        fp_unit = fp / np.linalg.norm(fp, axis=1, keepdims=True)
        dots = np.clip(fp_unit @ sub_unit, -1, 1)
        return float(np.mean(np.arccos(dots)))

    assert avg_angle(fp_high, high) > avg_angle(fp_low, low)


def test_fov_smaller_than_horizon():
    """A limited FOV should produce a smaller footprint than full horizon."""
    sat_xyz = lla_to_xyz([0.0, 0.0, 800_000.0])
    fp_full = compute_footprint(sat_xyz, n_points=36)
    fp_narrow = compute_footprint(sat_xyz, fov_half_angle_deg=30.0, n_points=36)

    # Compare mean angular distance from sub-satellite point
    sub_xyz = lla_to_xyz([0.0, 0.0, 0.0])
    sub_unit = sub_xyz / np.linalg.norm(sub_xyz)

    def mean_angle(fp: np.ndarray) -> float:
        fp_unit = fp / np.linalg.norm(fp, axis=1, keepdims=True)
        dots = np.clip(fp_unit @ sub_unit, -1, 1)
        return float(np.mean(np.arccos(dots)))

    assert mean_angle(fp_narrow) < mean_angle(fp_full)


def test_fov_larger_than_horizon_clamped():
    """An FOV wider than the horizon should produce the same footprint."""
    sat_xyz = lla_to_xyz([0.0, 0.0, 400_000.0])
    fp_full = compute_footprint(sat_xyz, n_points=36)
    fp_wide = compute_footprint(sat_xyz, fov_half_angle_deg=89.0, n_points=36)
    assert fp_wide == pytest.approx(fp_full, abs=1.0)


def test_n_points():
    """Output shape should match n_points."""
    sat_xyz = lla_to_xyz([0.0, 0.0, 400_000.0])
    assert compute_footprint(sat_xyz, n_points=100).shape == (100, 3)
    assert compute_footprint(sat_xyz, n_points=4).shape == (4, 3)


def test_low_altitude_midlatitude_observer():
    """Aircraft at 5 km, 37.5 deg lat (r_obs < ER_M) must still work.

    Regression for the old ER_M-based horizon angle that produced NaN when
    the observer's geocentric radius is less than the equatorial radius,
    even though it is physically above the ellipsoid at its own latitude.
    """
    aircraft = lla_to_xyz([37.5, -100.0, 5000.0])
    fp = compute_footprint(aircraft, n_points=36)

    assert np.isfinite(fp).all()
    assert fp.shape == (36, 3)


def test_observer_on_surface_raises():
    """Observer at altitude 0 has no horizon and should raise."""
    pos = lla_to_xyz([0.0, 0.0, 0.0])
    with pytest.raises(ValueError, match="surface"):
        compute_footprint(pos)


def test_polar_low_altitude_observer():
    """Observer near the pole at low altitude must produce a finite footprint.

    The polar surface radius is PR_M (smallest), so r_obs > PR_M holds for
    any positive altitude and the local-radius formula handles it.
    """
    near_pole = lla_to_xyz([89.5, 0.0, 2000.0])
    fp = compute_footprint(near_pole, n_points=36)

    assert np.isfinite(fp).all()


# compute_footprint_bounds


def test_bounds_equatorial_subobserver():
    """Equatorial sub-observer: lat bounds symmetric; lon tangent equals +/-ea."""
    sat_xyz = lla_to_xyz([0.0, 0.0, 800_000.0])
    lat_min, lat_max, lon_min, lon_max = compute_footprint_bounds(sat_xyz)

    assert lat_min == pytest.approx(-lat_max, abs=1e-9)
    assert lon_min == pytest.approx(-lon_max, abs=1e-9)
    # At equator, sin(Delta lon) = sin(ea), so Delta lon == earth_angle.
    assert lon_max == pytest.approx(lat_max, abs=1e-9)


def test_bounds_lat_extrema_match_polygon():
    """North/south bounds are exact across the polygon returned by compute_footprint."""
    sat_xyz = lla_to_xyz([35.0, -100.0, 550_000.0])
    lat_min, lat_max, _, _ = compute_footprint_bounds(sat_xyz)

    fp_lla = xyz_to_lla(compute_footprint(sat_xyz, n_points=10_000))
    assert lat_max == pytest.approx(fp_lla[:, 0].max(), abs=1e-3)
    assert lat_min == pytest.approx(fp_lla[:, 0].min(), abs=1e-3)


def test_bounds_lon_extrema_bracket_polygon():
    """East/west analytic bounds are tangent to the polygon (polygon never exceeds)."""
    sat_xyz = lla_to_xyz([35.0, -100.0, 550_000.0])
    _, _, lon_min, lon_max = compute_footprint_bounds(sat_xyz)

    fp_lla = xyz_to_lla(compute_footprint(sat_xyz, n_points=100_000))
    # The dense polygon's extremes approach but do not exceed the analytic bounds.
    assert fp_lla[:, 1].max() <= lon_max + 1e-6
    assert fp_lla[:, 1].min() >= lon_min - 1e-6
    # And a dense polygon gets within a small tolerance of the analytic bound.
    assert fp_lla[:, 1].max() == pytest.approx(lon_max, abs=1e-3)
    assert fp_lla[:, 1].min() == pytest.approx(lon_min, abs=1e-3)


def test_bounds_lon_offset_matches_closed_form():
    """lon_max - sub_lon == asin(sin(earth_angle) / cos(sub_lat)) in degrees."""
    sat_lla = [35.0, -100.0, 550_000.0]
    sat_xyz = lla_to_xyz(sat_lla)
    lat_min, lat_max, lon_min, lon_max = compute_footprint_bounds(sat_xyz)

    # Infer earth_angle from the (exact) lat range and closed form.
    earth_angle = math.radians((lat_max - lat_min) / 2.0)
    sub_lat = math.radians((lat_max + lat_min) / 2.0)
    expected_delta_lon = math.degrees(
        math.asin(math.sin(earth_angle) / math.cos(sub_lat)),
    )

    assert lon_max - sat_lla[1] == pytest.approx(expected_delta_lon, abs=1e-9)
    assert sat_lla[1] - lon_min == pytest.approx(expected_delta_lon, abs=1e-9)


def test_bounds_pole_wrap_opens_longitude():
    """When the footprint reaches a pole, lon bounds become [-180, 180]."""
    # GEO altitude over a polar sub-point to force pole coverage.
    polar = lla_to_xyz([85.0, 40.0, 35_786_000.0])
    _, lat_max, lon_min, lon_max = compute_footprint_bounds(polar)

    # Lat is clamped at 90
    assert lat_max == pytest.approx(90.0, abs=1e-9)
    # Longitude range opens fully
    assert (lon_min, lon_max) == (-180.0, 180.0)


def test_bounds_fov_narrower_than_horizon():
    """A narrower FOV produces strictly smaller bounds than the full horizon."""
    sat_xyz = lla_to_xyz([35.0, -100.0, 800_000.0])
    full = compute_footprint_bounds(sat_xyz)
    narrow = compute_footprint_bounds(sat_xyz, fov_half_angle_deg=30.0)

    assert narrow[0] > full[0]  # lat_min closer to sub_lat
    assert narrow[1] < full[1]  # lat_max closer to sub_lat
    assert narrow[2] > full[2]
    assert narrow[3] < full[3]


def test_bounds_observer_on_surface_raises():
    with pytest.raises(ValueError, match="surface"):
        compute_footprint_bounds(lla_to_xyz([0.0, 0.0, 0.0]))
