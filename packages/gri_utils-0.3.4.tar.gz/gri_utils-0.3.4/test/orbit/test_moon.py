import numpy as np
import pytest

from gri_utils.orbit.moon import moon_ecef

# Mean lunar distance ~384,400 km
_MEAN_LUNAR_DIST_M = 384_400_000.0


def test_moon_distance_reasonable():
    """Moon should be roughly at lunar distance."""
    # 2024-01-01 00:00:00 UTC
    unix_s = 1704067200.0
    pos = moon_ecef(unix_s)
    dist = np.linalg.norm(pos)
    # Within 10% of mean lunar distance
    assert dist == pytest.approx(_MEAN_LUNAR_DIST_M, rel=0.1)


def test_moon_moves_over_time():
    """Moon position should change over a day."""
    t0 = 1704067200.0
    t1 = t0 + 86400.0  # one day later
    pos0 = moon_ecef(t0)
    pos1 = moon_ecef(t1)
    # Should move significantly (Moon orbits ~13 deg/day)
    dot = np.dot(pos0, pos1)
    cos_a = dot / (np.linalg.norm(pos0) * np.linalg.norm(pos1))
    angle = np.arccos(np.clip(cos_a, -1, 1))
    assert np.degrees(angle) > 5


def test_moon_returns_3d():
    """Should return a 3-element array."""
    pos = moon_ecef(1704067200.0)
    assert pos.shape == (3,)
    assert pos.dtype == np.float64
