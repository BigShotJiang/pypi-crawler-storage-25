"""Tests for the GeoEllipsoid class and the WGS84 singleton."""

from __future__ import annotations

import numpy as np
import pytest

from gri_utils.constants import ER_M, PR_M, WGS84, GeoEllipsoid


def test_wgs84_axes_match_shared_constants() -> None:
    """WGS84 reuses ER_M and PR_M rather than redefining numbers."""
    assert WGS84.a == ER_M
    assert WGS84.b == PR_M


def test_flattening_and_eccentricity_squared() -> None:
    """Derived quantities match the textbook formulas."""
    assert WGS84.f == pytest.approx((ER_M - PR_M) / ER_M)
    assert WGS84.e2 == pytest.approx(1.0 - (PR_M / ER_M) ** 2)
    # Sanity: WGS84 flattening ~ 1 / 298.257
    assert WGS84.f == pytest.approx(1.0 / 298.257223563, rel=1e-6)


def test_radii_at_equator() -> None:
    """At the equator, N = a and M = a (1 - e^2)."""
    assert WGS84.n(0.0) == pytest.approx(WGS84.a)
    assert WGS84.m(0.0) == pytest.approx(WGS84.a * (1.0 - WGS84.e2))


def test_radii_at_pole() -> None:
    """At the pole, N = a / sqrt(1 - e^2) and M = a / (1 - e^2)^(1/2) * (1 - e^2)."""
    n_pole_expected = WGS84.a / np.sqrt(1.0 - WGS84.e2)
    m_pole_expected = WGS84.a * (1.0 - WGS84.e2) / (1.0 - WGS84.e2) ** 1.5
    assert WGS84.n(np.pi / 2) == pytest.approx(n_pole_expected)
    assert WGS84.m(np.pi / 2) == pytest.approx(m_pole_expected)
    # Both should equal a / sqrt(1 - e^2) at the pole (a known identity)
    assert n_pole_expected == pytest.approx(m_pole_expected)


def test_radii_are_vectorized() -> None:
    """N and m accept numpy arrays and return matching shapes."""
    lats = np.linspace(-np.pi / 2, np.pi / 2, 11)
    n_vals = WGS84.n(lats)
    m_vals = WGS84.m(lats)
    assert np.shape(n_vals) == lats.shape
    assert np.shape(m_vals) == lats.shape
    # M <= N everywhere (equal only at the poles)
    assert np.all(m_vals <= n_vals + 1e-9)


def test_meters_per_degree_latitude_sanity() -> None:
    """M(lat) * pi/180 gives meters per degree of latitude: ~110.6-111.7 km."""
    m_per_deg_eq = WGS84.m(0.0) * np.pi / 180.0
    m_per_deg_pole = WGS84.m(np.pi / 2) * np.pi / 180.0
    # Published values: 110.574 km at equator, 111.694 km at pole
    assert m_per_deg_eq == pytest.approx(110_574, rel=1e-4)
    assert m_per_deg_pole == pytest.approx(111_694, rel=1e-4)


def test_custom_ellipsoid_is_usable() -> None:
    """A non-WGS84 GeoEllipsoid (e.g. unit sphere) has the expected properties."""
    sphere = GeoEllipsoid(a=1.0, b=1.0)
    assert sphere.f == 0.0
    assert sphere.e2 == 0.0
    lats = np.array([0.0, 0.5, 1.0])
    assert np.allclose(sphere.n(lats), 1.0)
    assert np.allclose(sphere.m(lats), 1.0)


def test_frozen() -> None:
    """GeoEllipsoid instances are immutable."""
    with pytest.raises((AttributeError, Exception)):
        WGS84.a = 0.0  # type: ignore[misc]
