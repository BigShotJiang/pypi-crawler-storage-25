"""Transform XYZ (ECEF) covariance matrices <=> NED covariance matrices.

These functions handle 3x3 covariance matrices (or stacks of them) and transform
them between XYZ and NED coordinate frames using similarity transforms.

For single matrices:
    xyz_to_ned_cov(xyz_pos, xyz_cov) -> ned_cov
    ned_to_xyz_cov(xyz_pos, ned_cov) -> xyz_cov

For vectorized stacks of matrices (N, 3, 3):
    xyz_to_ned_cov(xyz_pos, xyz_covs) -> ned_covs
    ned_to_xyz_cov(xyz_pos, ned_covs) -> xyz_covs
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .xyz_ned_rotation import ned_xyz_rotation, xyz_ned_rotation

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def xyz_to_ned_cov(
    xyz_pos: NDArray[np.floating] | Sequence,
    xyz_matrix: NDArray[np.floating],
) -> NDArray[np.floating]:
    """Convert XYZ covariance matrix(s) to NED at the given position.

    Uses the similarity transform: ned_cov = T @ xyz_cov @ T.T
    where T is the XYZ->NED rotation matrix.

    Args:
        xyz_pos(np.ndarray|Sequence): XYZ reference location. Shape (3,).
        xyz_matrix(np.ndarray): XYZ covariance matrix(s). Shape (3, 3) for single
            matrix or (N, 3, 3) for N matrices.

    Returns:
        np.ndarray: NED covariance matrix(s). Shape (3, 3) or (N, 3, 3) matching
            xyz_matrix.
    """
    t_ned = xyz_ned_rotation(xyz_pos)
    xyz_matrix = np.asarray(xyz_matrix)
    single = xyz_matrix.ndim == 2  # noqa: PLR2004
    if single:
        xyz_matrix = xyz_matrix[np.newaxis, ...]

    # Vectorized: (N, 3, 3) -> use einsum for batch matrix multiplication
    # Result[i] = T @ xyz_matrix[i] @ T.T
    temp = np.einsum("ij,njk->nik", t_ned, xyz_matrix)
    result = np.einsum("nij,kj->nik", temp, t_ned)

    return result[0] if single else result


def ned_to_xyz_cov(
    xyz_pos: NDArray[np.floating] | Sequence,
    ned_matrix: NDArray[np.floating],
) -> NDArray[np.floating]:
    """Convert NED covariance matrix(s) to XYZ at the given position.

    Uses the similarity transform: xyz_cov = T @ ned_cov @ T.T
    where T is the NED->XYZ rotation matrix.

    Args:
        xyz_pos(np.ndarray|Sequence): XYZ reference location. Shape (3,).
        ned_matrix(np.ndarray): NED covariance matrix(s). Shape (3, 3) for single
            matrix or (N, 3, 3) for N matrices.

    Returns:
        np.ndarray: XYZ covariance matrix(s). Shape (3, 3) or (N, 3, 3) matching
            ned_matrix.
    """
    t_xyz = ned_xyz_rotation(xyz_pos)
    ned_matrix = np.asarray(ned_matrix)
    single = ned_matrix.ndim == 2  # noqa: PLR2004
    if single:
        ned_matrix = ned_matrix[np.newaxis, ...]

    # Vectorized: (N, 3, 3) -> use einsum for batch matrix multiplication
    # Result[i] = T @ ned_matrix[i] @ T.T
    temp = np.einsum("ij,njk->nik", t_xyz, ned_matrix)
    result = np.einsum("nij,kj->nik", temp, t_xyz)

    return result[0] if single else result
