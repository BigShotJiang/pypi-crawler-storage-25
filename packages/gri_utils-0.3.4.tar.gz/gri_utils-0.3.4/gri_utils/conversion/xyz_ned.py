"""Transform XYZ (ECEF) vectors <=> NED (North East Down) vectors.

Each of the following functions is unitless. EG: Pass in kilometers and the result is
in kilometers. Takes and returns numpy arrays.

# Get the NED vector between the two positions
get_ned(xyz_pos1,xyz_pos2) -> ned

# Get the new XYZ location shifted by this NED vector
translate_ned(xyz_pos, ned) -> xyz_pos

# Convert the XYZ vector to an NED vector
xyz_to_ned(xyz_pos, xyz_vec) -> ned

# Convert the NED vector to an XYZ vector
ned_to_xyz(xyz_pos, ned) -> xyz_vec
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .xyz_ned_rotation import ned_xyz_rotation, xyz_ned_rotation

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def get_ned(
    xyz_pos1: NDArray[np.floating] | Sequence,
    xyz_pos2: NDArray[np.floating] | Sequence,
) -> NDArray[np.floating]:
    """Return the NED vector from pos1 to pos2 in the plane of pos1.

    Args:
        xyz_pos1(np.ndarray|Sequence): XYZ reference location. Shape (3,).
        xyz_pos2(np.ndarray|Sequence): XYZ target location(s). Shape (3,) or (N, 3).

    Returns:
        np.ndarray: NED vector(s) in the plane of pos1, pointed to pos2. Units are the
            same as pos1/pos2. Shape (3,) or (N, 3) matching xyz_pos2.
    """
    xyz_pos1 = np.asarray(xyz_pos1)
    xyz_pos2 = np.asarray(xyz_pos2)
    t_ned = xyz_ned_rotation(xyz_pos1)
    diff = xyz_pos2 - xyz_pos1
    if diff.ndim == 1:
        return t_ned @ diff
    return (t_ned @ diff.T).T


def translate_ned(
    xyz_pos: NDArray[np.floating] | Sequence,
    ned: NDArray[np.floating] | Sequence,
) -> NDArray[np.floating]:
    """Return the XYZ location of pos shifted by this NED.

    Args:
        xyz_pos(np.ndarray|Sequence): XYZ reference location. Shape (3,).
        ned(np.ndarray|Sequence): NED vector(s) from pos. Shape (3,) or (N, 3).

    Returns:
        np.ndarray: XYZ location(s) pointed at by ned. Shape (3,) or (N, 3) matching
            ned.
    """
    xyz_pos = np.asarray(xyz_pos)
    ned = np.asarray(ned)
    t_xyz = ned_xyz_rotation(xyz_pos)
    if ned.ndim == 1:
        return t_xyz @ ned + xyz_pos
    return (t_xyz @ ned.T).T + xyz_pos


def xyz_to_ned(
    xyz_pos: NDArray[np.floating] | Sequence,
    xyz: NDArray[np.floating] | Sequence,
) -> NDArray[np.floating]:
    """Convert the XYZ vector(s) to NED in the plane of the XYZ position.

    Args:
        xyz_pos(np.ndarray|Sequence): XYZ reference location. Shape (3,).
        xyz(np.ndarray|Sequence): XYZ vector(s). Shape (3,) or (N, 3).

    Returns:
        np.ndarray: NED vector(s). Shape (3,) or (N, 3) matching input xyz.

    Note:
        For covariance matrix transformation, use xyz_to_ned_cov() instead.
    """
    xyz_pos = np.asarray(xyz_pos)
    xyz = np.asarray(xyz)
    t_ned = xyz_ned_rotation(xyz_pos)
    if xyz.ndim == 1:
        return t_ned @ xyz
    return (t_ned @ xyz.T).T


def ned_to_xyz(
    xyz_pos: NDArray[np.floating] | Sequence,
    ned: NDArray[np.floating] | Sequence,
) -> NDArray[np.floating]:
    """Convert the NED vector(s) to an XYZ vector.

    Args:
        xyz_pos(np.ndarray|Sequence): XYZ reference location. Shape (3,).
        ned(np.ndarray|Sequence): NED vector(s). Shape (3,) or (N, 3).

    Returns:
        np.ndarray: XYZ vector(s). Shape (3,) or (N, 3) matching input ned.

    Note:
        For covariance matrix transformation, use ned_to_xyz_cov() instead.
    """
    xyz_pos = np.asarray(xyz_pos)
    ned = np.asarray(ned)
    t_xyz = ned_xyz_rotation(xyz_pos)
    if ned.ndim == 1:
        return t_xyz @ ned
    return (t_xyz @ ned.T).T
