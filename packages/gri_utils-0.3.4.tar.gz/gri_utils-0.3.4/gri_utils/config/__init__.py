"""GRI FOSS ecosystem shared configuration.

Provides configuration management for all GRI packages via a shared TOML
config file at ~/.config/gri/config.toml.

Usage:
    from gri_utils import config

    # Get value with module-provided default
    cache_mb = config.get("gri-terrain.max_memory_cache_mb", 500.0)

    # Get path value
    cache_dir = config.get_path("gri-terrain.copernicus.cache_dir")

"""

from gri_utils.config.config import (
    get,
    get_path,
    set,  # noqa: A004 - mirrors stdlib naming convention
    set_config_path,
)

__all__ = [
    "get",
    "get_path",
    "set",
    "set_config_path",
]
