"""Line of sight visibility check through WGS84 Earth ellipsoid.

Determines if the straight line between two ECEF points intersects (is blocked by)
the WGS84 Earth ellipsoid.

This is useful for:
- Satellite-to-satellite visibility checks
- Satellite-to-ground visibility checks
- Any geometry where Earth occlusion matters

The algorithm scales coordinates to transform the WGS84 ellipsoid into a unit sphere,
then performs a simple ray-sphere intersection test. This is both fast and accurate
for the ellipsoid geometry.

Inputs may be single (3,) points or arrays of points broadcastable to (..., 3).
Scalar inputs return a plain bool; array inputs return a bool array.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_utils.constants import ER_M, PR_M

# Tolerance for detecting degenerate case (same point)
_SAME_POINT_TOL = 1e-30
# Tolerance for t-parameter bounds (handles floating point at surface endpoints)
_T_EPSILON = 1e-9

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def line_of_sight_clear(
    xyz1_m: NDArray[np.floating] | Sequence,
    xyz2_m: NDArray[np.floating] | Sequence,
) -> bool | NDArray[np.bool_]:
    """Check if line of sight between two ECEF points clears the WGS84 ellipsoid.

    Determines whether the straight line segment from xyz1 to xyz2 intersects
    the WGS84 Earth ellipsoid. Returns True if the path is clear (no intersection),
    False if the Earth blocks the line of sight.

    The test transforms coordinates to a unit sphere space (scaling x,y by 1/ER_M
    and z by 1/PR_M), then solves the quadratic ray-sphere intersection equation.

    Inputs are broadcast-compatible: either or both may be (..., 3) arrays.

    Args:
        xyz1_m: First ECEF position(s) in meters. Shape (..., 3).
        xyz2_m: Second ECEF position(s) in meters. Shape (..., 3).

    Returns:
        True if line of sight is clear (no Earth intersection).
        False if Earth blocks the line of sight.
        For array inputs, returns a bool array of the broadcast shape.

    Example:
        >>> import numpy as np
        >>> # Two satellites on opposite sides of Earth - blocked
        >>> sat1 = np.array([42164e3, 0.0, 0.0])  # GEO satellite
        >>> sat2 = np.array([-42164e3, 0.0, 0.0])  # Opposite side
        >>> line_of_sight_clear(sat1, sat2)
        False

        >>> # Satellite and ground station with clear view
        >>> sat = np.array([0.0, 0.0, 42164e3])  # Over north pole
        >>> ground = np.array([0.0, 0.0, 6378137.0])  # North pole surface
        >>> line_of_sight_clear(sat, ground)
        True

        >>> # Batch: one observer, many targets
        >>> obs = np.array([42164e3, 0.0, 0.0])
        >>> targets = np.array([[0.0, 0.0, 6378137.0],
        ...                     [-42164e3, 0.0, 0.0]])
        >>> line_of_sight_clear(obs, targets)
        array([ True, False])
    """
    p1 = np.asarray(xyz1_m, dtype=np.float64)
    p2 = np.asarray(xyz2_m, dtype=np.float64)

    # Scale factors to transform WGS84 ellipsoid to unit sphere
    # After scaling: x**2/ER**2 + y**2/ER**2 + z**2/PR**2 = 1
    # becomes x**2 + y**2 + z**2 = 1
    scale = np.array([1.0 / ER_M, 1.0 / ER_M, 1.0 / PR_M])

    # Transform points to unit sphere space
    p1s = p1 * scale
    p2s = p2 * scale

    # Ray from p1 to p2: P(t) = p1 + t * d, where t in [0, 1]
    d = p2s - p1s

    # Solve ||p1 + t*d||**2 = 1 for t
    # Expands to: (d.d)*t**2 + 2*(p1.d)*t + (p1.p1 - 1) = 0
    a = np.sum(d * d, axis=-1)
    b = 2.0 * np.sum(p1s * d, axis=-1)
    c = np.sum(p1s * p1s, axis=-1) - 1.0

    disc = b * b - 4.0 * a * c

    # Guard against division by zero when points coincide (a ~= 0).
    # Adding the tolerance to the denominator is safe: when a is tiny,
    # disc < 0 dominates and the t values are irrelevant.
    denom = 2.0 * a + _SAME_POINT_TOL
    sqrt_disc = np.sqrt(np.maximum(disc, 0.0))
    t1 = (-b - sqrt_disc) / denom
    t2 = (-b + sqrt_disc) / denom

    # Clear if: no intersection (disc < 0) or both hits outside (0, 1)
    clear = (disc < 0) | (t2 <= _T_EPSILON) | (t1 >= 1.0 - _T_EPSILON)

    return bool(clear) if clear.ndim == 0 else clear
