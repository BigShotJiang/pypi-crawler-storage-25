"""Mesh operations for triangle-mesh terrain and surface grids.

General-purpose mesh utilities that operate on vertices + faces arrays.
Currently focused on terrain mesh processing, but the operations are
geometry-generic and could support a broader mesh/sheet abstraction
in the future.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray

_NEAR_ZERO = 1e-30


def compute_vertex_normals(
    vertices: NDArray[np.floating],
    faces: NDArray[np.integer],
) -> NDArray[np.floating]:
    """Compute per-vertex normals by averaging adjacent face normals.

    For each face, computes the (unnormalized) face normal via cross product.
    Each vertex normal is the sum of normals of all faces sharing that vertex,
    then normalized to unit length.

    Args:
        vertices: Vertex positions, shape (V, 3).
        faces: Triangle face indices, shape (F, 3). Each row contains three
            indices into the vertices array.

    Returns:
        Per-vertex unit normals, shape (V, 3). Vertices with no adjacent
        faces get a zero normal.
    """
    v0 = vertices[faces[:, 0]]
    v1 = vertices[faces[:, 1]]
    v2 = vertices[faces[:, 2]]
    face_normals = np.cross(v1 - v0, v2 - v0)

    vertex_normals = np.zeros_like(vertices)
    for i in range(3):
        np.add.at(vertex_normals, faces[:, i], face_normals)

    norms = np.linalg.norm(vertex_normals, axis=1, keepdims=True)
    safe_norms = np.where(norms > _NEAR_ZERO, norms, 1.0)
    return vertex_normals / safe_norms
