# Utils/Resources

System resource measurement and threading utilities.

## Import and Use

```python
from gri_utils import resources

@resources.test_memory
def my_function():
    ...
```

## Module Overview

| Symbol | Purpose |
| ------ | ------- |
| `test_memory` | Decorator that measures CPU and memory usage of a function |

## Memory Testing

The `test_memory` decorator measures CPU time and memory consumption (including child processes) before, during, and after a function executes. It returns a `ResourceResult` NamedTuple with the measurements.

```python
from gri_utils import resources

@resources.test_memory
def allocate_large_array():
    import numpy as np
    return np.zeros((10000, 10000))

result = allocate_large_array()
# result is a ResourceResult with fields for CPU and memory usage
```

This is intended as a quick profiling tool for development, not production monitoring.

## Returnable Thread

The `ReturnableThread` class (in `returnable_thread.py`) extends `threading.Thread` to capture and return the result of the target function. It is not exported from the module `__init__` but can be imported directly:

```python
from gri_utils.resources.returnable_thread import ReturnableThread

def my_task():
    return 42

thread = ReturnableThread(target=my_task)
thread.start()
thread.join()
result = thread.result  # 42
```
