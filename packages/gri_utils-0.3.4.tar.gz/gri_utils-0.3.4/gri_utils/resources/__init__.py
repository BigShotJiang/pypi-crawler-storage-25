"""Utilities for hardware resources."""

from .memtest import test_memory

__all__ = ["test_memory"]
