"""Time Difference of Arrival rate (TDOA-dot) with gradient computation.

Provides TDOA-dot computation along with gradients (Jacobians) with respect to
both emitter position and velocity, for use in optimization and fitting
algorithms.

The bistatic TDOA-dot formula with moving collectors is:

    TDOA_dot = ((v_emit - v_coll2) . unit2 - (v_emit - v_coll1) . unit1) / c

Gradients are computed with respect to emitter position and velocity only
(collector positions/velocities are treated as fixed measurements).

For basic TDOA-dot computation without gradients, see tdoa_dot.py.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_utils.constants import C

from ._range_utils import _range_and_unit, _unit_vector_jacobian

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def tdoa_dot_with_gradient(  # noqa: PLR0913
    emit_xyz: NDArray[np.floating] | Sequence,
    emit_vel: NDArray[np.floating] | Sequence,
    collector1_xyz: NDArray[np.floating] | Sequence,
    collector2_xyz: NDArray[np.floating] | Sequence,
    collector1_vel: NDArray[np.floating] | Sequence | None = None,
    collector2_vel: NDArray[np.floating] | Sequence | None = None,
) -> tuple[NDArray[np.floating], NDArray[np.floating], NDArray[np.floating]]:
    """Compute TDOA-dot and gradients w.r.t. emitter position and velocity.

    Calculates TDOA-dot using the bistatic formula and its gradients:

        TDOA_dot = ((v_emit - v_coll2) . unit2 - (v_emit - v_coll1) . unit1) / c

        d(TDOA_dot)/d(emit_vel) = (unit2 - unit1) / c

        d(TDOA_dot)/d(emit_pos) = (v_rel1 . J1 - v_rel2 . J2) / c

    where v_rel_i = v_emit - v_coll_i, unit_i points from emitter to
    collector i, and J_i = (I - unit_i . unit_i^T) / r_i is the Jacobian of
    unit_i with respect to (collector_i - emit_pos). The chain-rule sign from
    d(collector_i - emit_pos)/d(emit_pos) = -I is folded into the expression
    above.

    Args:
        emit_xyz: Emitter position(s) in ECEF meters. Shape (3,) or (N, 3).
        emit_vel: Emitter velocity in ECEF meters/second. Shape (3,) or (N, 3).
        collector1_xyz: First collector position in ECEF meters. Shape (3,).
        collector2_xyz: Second collector position in ECEF meters. Shape (3,).
        collector1_vel: First collector velocity in ECEF m/s. Shape (3,).
            If None, collector is assumed stationary.
        collector2_vel: Second collector velocity in ECEF m/s. Shape (3,).
            If None, collector is assumed stationary.

    Returns:
        Tuple of (tdoa_dot, grad_pos, grad_vel):
            - tdoa_dot: TDOA_dot in s/s (dimensionless). Shape () or (N,).
            - grad_pos: Gradient w.r.t. emit_xyz in (s/s)/meter.
              Shape (3,) or (N, 3).
            - grad_vel: Gradient w.r.t. emit_vel in (s/s)/(m/s).
              Shape (3,) or (N, 3).
    """
    emit_xyz = np.asarray(emit_xyz)
    emit_vel = np.asarray(emit_vel)
    collector1_xyz = np.asarray(collector1_xyz)
    collector2_xyz = np.asarray(collector2_xyz)

    coll1_vel = np.zeros(3) if collector1_vel is None else np.asarray(collector1_vel)
    coll2_vel = np.zeros(3) if collector2_vel is None else np.asarray(collector2_vel)

    single_point = emit_xyz.ndim == 1

    range1, unit1 = _range_and_unit(emit_xyz, collector1_xyz)
    range2, unit2 = _range_and_unit(emit_xyz, collector2_xyz)

    v_rel1 = emit_vel - coll1_vel
    v_rel2 = emit_vel - coll2_vel

    if single_point:
        v_radial1 = np.dot(v_rel1, unit1)
        v_radial2 = np.dot(v_rel2, unit2)
    else:
        v_radial1 = np.sum(v_rel1 * unit1, axis=-1)
        v_radial2 = np.sum(v_rel2 * unit2, axis=-1)

    inv_c = 1.0 / C
    tdoa_dot = inv_c * (v_radial2 - v_radial1)

    grad_vel = inv_c * (unit2 - unit1)

    jac1 = _unit_vector_jacobian(unit1, range1)
    jac2 = _unit_vector_jacobian(unit2, range2)

    if single_point:
        grad_pos = -inv_c * (v_rel2 @ jac2 - v_rel1 @ jac1)
    else:
        grad_pos = -inv_c * (
            np.einsum("ni,nij->nj", v_rel2, jac2)
            - np.einsum("ni,nij->nj", v_rel1, jac1)
        )

    return np.asarray(tdoa_dot), np.asarray(grad_pos), np.asarray(grad_vel)
