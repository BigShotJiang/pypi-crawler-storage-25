"""Time Difference of Arrival rate (TDOA-dot) observable computation.

TDOA-dot is the time derivative of TDOA. From TDOA = (r1 - r2) / c:

    TDOA_dot = (r1_dot - r2_dot) / c

Expanding each range rate with unit vectors pointing from emitter to each
collector:

    r_i_dot = (v_coll_i - v_emit) . unit_i

Equivalent expression using relative velocities (v_emit - v_coll):

    TDOA_dot = ((v_emit - v_coll2) . unit2 - (v_emit - v_coll1) . unit1) / c

A positive value means r1 is growing faster than r2 (the signal's arrival-time
difference is increasing over time).

TDOA-dot is dimensionless (s / s) and frequency-independent. It is related to
FDOA by a simple scale:

    FDOA = -f0 * TDOA_dot
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_utils.constants import C

from ._range_utils import _range_and_unit

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from numpy.typing import NDArray


def get_tdoa_dot(  # noqa: PLR0913
    emit_xyz: NDArray[np.floating] | Sequence,
    emit_vel: NDArray[np.floating] | Sequence,
    collector1_xyz: NDArray[np.floating] | Sequence,
    collector2_xyz: NDArray[np.floating] | Sequence,
    collector1_vel: NDArray[np.floating] | Sequence | None = None,
    collector2_vel: NDArray[np.floating] | Sequence | None = None,
) -> NDArray[np.floating]:
    """Compute Time Difference of Arrival rate (d TDOA / d t).

    Calculates TDOA_dot using the bistatic formula that accounts for both
    emitter and collector motion:

        TDOA_dot = ((v_emit - v_coll2) . unit2 - (v_emit - v_coll1) . unit1) / c

    where unit_i points from the emitter to collector i.

    Args:
        emit_xyz: Emitter position(s) in ECEF meters. Shape (3,) or (N, 3).
        emit_vel: Emitter velocity in ECEF meters/second. Shape (3,) or (N, 3).
        collector1_xyz: First collector position in ECEF meters. Shape (3,).
        collector2_xyz: Second collector position in ECEF meters. Shape (3,).
        collector1_vel: First collector velocity in ECEF m/s. Shape (3,).
            If None, collector is assumed stationary.
        collector2_vel: Second collector velocity in ECEF m/s. Shape (3,).
            If None, collector is assumed stationary.

    Returns:
        TDOA_dot in seconds/second (dimensionless). Shape () if emit is (3,),
        or (N,) if emit is (N, 3). Positive means the TDOA value is increasing
        with time.
    """
    emit_xyz = np.asarray(emit_xyz)
    emit_vel = np.asarray(emit_vel)
    collector1_xyz = np.asarray(collector1_xyz)
    collector2_xyz = np.asarray(collector2_xyz)

    coll1_vel = np.zeros(3) if collector1_vel is None else np.asarray(collector1_vel)
    coll2_vel = np.zeros(3) if collector2_vel is None else np.asarray(collector2_vel)

    _, unit1 = _range_and_unit(emit_xyz, collector1_xyz)
    _, unit2 = _range_and_unit(emit_xyz, collector2_xyz)

    v_rel1 = emit_vel - coll1_vel
    v_rel2 = emit_vel - coll2_vel

    if emit_vel.ndim == 1:
        v_radial1 = np.dot(v_rel1, unit1)
        v_radial2 = np.dot(v_rel2, unit2)
    else:
        v_radial1 = np.sum(v_rel1 * unit1, axis=-1)
        v_radial2 = np.sum(v_rel2 * unit2, axis=-1)

    tdoa_dot = (v_radial2 - v_radial1) / C

    return np.asarray(tdoa_dot)


def get_tdoa_dot_residual(  # noqa: PLR0913
    collector1_xyz: NDArray[np.floating] | Sequence,
    collector1_vel: NDArray[np.floating] | Sequence,
    collector2_xyz: NDArray[np.floating] | Sequence,
    collector2_vel: NDArray[np.floating] | Sequence,
    tdoa_dot: float,
    *,
    emitter_vel: NDArray[np.floating] | Sequence | None = None,
) -> Callable[[NDArray[np.floating]], NDArray[np.floating]]:
    """Create a vectorized TDOA-dot residual function.

    Returns a function that computes the difference between observed TDOA-dot
    and the TDOA-dot predicted for candidate emitter positions. The
    zero-crossing defines the TDOA-dot iso-surface.

    Args:
        collector1_xyz: First collector position in ECEF meters. Shape (3,).
        collector1_vel: First collector velocity in ECEF m/s. Shape (3,).
        collector2_xyz: Second collector position in ECEF meters. Shape (3,).
        collector2_vel: Second collector velocity in ECEF m/s. Shape (3,).
        tdoa_dot: Measured TDOA_dot (dimensionless, s/s).
        emitter_vel: Emitter velocity in ECEF m/s. Shape (3,).
            If None, emitter is assumed stationary.

    Returns:
        Vectorized residual function: takes points (N, 3) or (3,), returns
        residual values (N,) or (). Zero where predicted TDOA_dot equals
        measured.
    """
    c1 = np.asarray(collector1_xyz, dtype=np.float64)
    c2 = np.asarray(collector2_xyz, dtype=np.float64)
    v1 = np.asarray(collector1_vel, dtype=np.float64)
    v2 = np.asarray(collector2_vel, dtype=np.float64)
    ev = (
        np.zeros(3, dtype=np.float64)
        if emitter_vel is None
        else np.asarray(emitter_vel, dtype=np.float64)
    )

    rel_vel1 = ev - v1
    rel_vel2 = ev - v2

    def residual(points: NDArray[np.floating]) -> NDArray[np.floating]:
        pts = np.asarray(points)
        vec1 = c1 - pts
        vec2 = c2 - pts

        r1 = np.linalg.norm(vec1, axis=-1, keepdims=True)
        r2 = np.linalg.norm(vec2, axis=-1, keepdims=True)

        u1 = vec1 / np.maximum(r1, 1e-12)
        u2 = vec2 / np.maximum(r2, 1e-12)

        doppler1 = np.sum(rel_vel1 * u1, axis=-1)
        doppler2 = np.sum(rel_vel2 * u2, axis=-1)

        computed = (doppler2 - doppler1) / C
        return np.asarray(computed - tdoa_dot)

    return residual
