"""Statistics constants."""

from __future__ import annotations

SIG_TO_95_1D = 3.841458820694124
"""Scaling 1D sigma to 95%, 3.841: for vectors use sqrt: ~1.9600"""
SIG_TO_95_2D = 5.991464547107979
"""Scaling 2D sigma to 95%, 5.991: for vectors use sqrt: ~2.4477"""
SIG_TO_95_3D = 7.814727903251179
"""Scaling 3D sigma to 95%, 7.815: for vectors use sqrt: ~2.7955"""
