"""Geodetic reference ellipsoid type and WGS84 instance."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from .geo import ER_M, PR_M

if TYPE_CHECKING:
    from numpy.typing import NDArray


@dataclass(frozen=True)
class GeoEllipsoid:
    """Geodetic reference ellipsoid defined by its two axes.

    Attributes:
        a: Semi-major (equatorial) radius in meters.
        b: Semi-minor (polar) radius in meters.
    """

    a: float
    b: float

    @property
    def f(self) -> float:
        """Flattening f = (a - b) / a."""
        return (self.a - self.b) / self.a

    @property
    def e2(self) -> float:
        """Eccentricity squared e^2 = 1 - (b / a)^2."""
        return 1.0 - (self.b / self.a) ** 2

    def n(self, lat_rad: float | NDArray) -> float | NDArray:
        """Prime vertical radius of curvature at geodetic latitude.

        N(lat) = a / sqrt(1 - e^2 sin^2(lat)). Meters per radian of
        longitude at sea level equals N(lat) * cos(lat).

        Args:
            lat_rad: Geodetic latitude in radians (scalar or array).

        Returns:
            N(lat) in meters, matching the input shape.
        """
        return self.a / np.sqrt(1.0 - self.e2 * np.sin(lat_rad) ** 2)

    def m(self, lat_rad: float | NDArray) -> float | NDArray:
        """Meridional radius of curvature at geodetic latitude.

        M(lat) = a (1 - e^2) / (1 - e^2 sin^2(lat))^(3/2). Meters per
        radian of latitude at sea level equals M(lat).

        Args:
            lat_rad: Geodetic latitude in radians (scalar or array).

        Returns:
            M(lat) in meters, matching the input shape.
        """
        s = np.sin(lat_rad) ** 2
        return self.a * (1.0 - self.e2) / (1.0 - self.e2 * s) ** 1.5


WGS84 = GeoEllipsoid(a=ER_M, b=PR_M)
"""WGS84 reference ellipsoid, sharing the ER_M / PR_M constants."""
