"""Compute the ground footprint (visibility boundary) of an observer.

Given an observer ECEF position and optional field-of-view half-angle,
traces the boundary on the Earth's surface where the observer can see.
Uses a local-radius spherical approximation for the angular geometry:
the radius at the observer's sub-point (geocentric ellipsoid radius in
the direction of the observer), computed analytically from the ECEF
coordinates and the WGS84 ellipsoid parameters. This keeps the math
closed-form while working at any latitude and any altitude above the
ellipsoid (including low-altitude aircraft, which have `r_obs < ER_M`
at mid / high latitudes).

Output boundary points are converted to WGS84 ECEF.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_utils.constants import ER_M, PR_M
from gri_utils.conversion import lla_to_xyz, xyz_to_lla

if TYPE_CHECKING:
    from numpy.typing import NDArray

POLE_DEG = 90.0
HALF_CIRCLE_DEG = 180.0


def _local_surface_radius(observer_xyz: NDArray[np.floating]) -> float:
    """Geocentric radius of the WGS84 ellipsoid in the direction of `observer_xyz`.

    Derivation: parametrize the ray from the origin through the observer as
    ``t * u`` where ``u = observer_xyz / r_obs``. Substituting into the WGS84
    ellipsoid equation ``(x/a)**2 + (y/a)**2 + (z/b)**2 = 1`` and solving for
    ``t`` gives ``t = r_obs / sqrt((x**2 + y**2)/a**2 + z**2/b**2)``. That
    ``t`` is the geocentric radius of the ellipsoid in the direction of the
    observer, which is what "local surface radius" means here.
    """
    x, y, z = float(observer_xyz[0]), float(observer_xyz[1]), float(observer_xyz[2])
    r_obs = float(np.linalg.norm(observer_xyz))
    p_sq = x * x + y * y
    return r_obs / np.sqrt(p_sq / ER_M**2 + z * z / PR_M**2)


def _nadir_angle_to_earth_angle(
    nadir_angle_rad: float,
    r_obs: float,
    r_surface: float,
) -> float:
    """Convert a nadir angle to the corresponding central angle on Earth.

    Uses ray-sphere intersection with a sphere of radius `r_surface` (the
    local geocentric ellipsoid radius at the sub-observer point).
    """
    cos_na = np.cos(nadir_angle_rad)
    sin_na = np.sin(nadir_angle_rad)
    dx, dy = -cos_na, sin_na

    # Quadratic: t^2 + 2*r_obs*dx*t + (r_obs^2 - r_surface^2) = 0
    b = 2 * r_obs * dx
    c = r_obs**2 - r_surface**2
    disc = b**2 - 4 * c
    if disc < 0:
        # No intersection (shouldn't happen if nadir_angle <= horizon)
        return np.pi / 2 - np.arcsin(r_surface / r_obs)

    t = (-b - np.sqrt(disc)) / 2  # nearest intersection
    px, py = r_obs + t * dx, t * dy

    return float(np.arctan2(py, px))


def _earth_angle(
    observer_xyz: NDArray[np.floating],
    fov_half_angle_deg: float | None,
) -> float:
    """Central angle on Earth from the sub-observer to the footprint boundary.

    Combines the local-surface-radius horizon math with the optional FOV
    clamp. Shared by `compute_footprint` and `compute_footprint_bounds`.
    """
    r_obs = float(np.linalg.norm(observer_xyz))
    r_surface = _local_surface_radius(observer_xyz)

    if r_obs <= r_surface:
        msg = (
            f"Observer at or below local ellipsoid surface "
            f"(r_obs={r_obs:.1f} m, r_surface={r_surface:.1f} m); "
            "no horizon is defined."
        )
        raise ValueError(msg)

    horizon_half_angle = np.arcsin(r_surface / r_obs)

    if fov_half_angle_deg is not None:
        nadir_angle = min(np.radians(fov_half_angle_deg), horizon_half_angle)
        return _nadir_angle_to_earth_angle(nadir_angle, r_obs, r_surface)
    return float(np.pi / 2 - horizon_half_angle)


def compute_footprint_bounds(
    observer_xyz: NDArray[np.floating],
    fov_half_angle_deg: float | None = None,
) -> tuple[float, float, float, float]:
    """Closed-form lat/lon bounds of an observer's ground footprint.

    Returns the (min_lat, max_lat, min_lon, max_lon) bounding box of the
    circle that `compute_footprint` would sample, in degrees. Uses the
    analytic tangent points of the small circle on a sphere rather than
    searching through polygon vertices:

        lat_max = sub_lat + earth_angle
        lat_min = sub_lat - earth_angle
        Δλ      = asin(sin(earth_angle) / cos(sub_lat))
        lon_max = sub_lon + Δλ
        lon_min = sub_lon - Δλ

    `lat_max` and `lat_min` are exact. `lon_min`/`lon_max` are also exact
    and correspond to the east/west tangent meridians of the footprint
    circle (the azimuths at which these occur are in general NOT pi/2 and
    3 pi/2; see the derivation in the module docstring).

    When the footprint reaches or crosses a pole (earth_angle >=
    90 deg - |sub_lat|), latitudes are clamped to [-90, 90] and the
    longitude bounds open to the full [-180, 180] range (all longitudes
    are visible).

    Args:
        observer_xyz: Observer position in ECEF meters, shape (3,).
        fov_half_angle_deg: Half-angle of the observer's field of view
            in degrees, measured from nadir. If None, uses the full
            horizon; otherwise capped to the geometric horizon.

    Returns:
        Tuple of four floats in degrees: (min_lat, max_lat, min_lon,
        max_lon). `min_lon` is always <= `max_lon`; the span may exceed
        360 deg and reach beyond +-180 deg only when the footprint
        contains a pole, in which case the returned range is [-180, 180].

    Raises:
        ValueError: If the observer is at or below the local ellipsoid
            surface (no horizon is defined).
    """
    observer_xyz = np.asarray(observer_xyz, dtype=np.float64)
    observer_lla = xyz_to_lla(observer_xyz)
    sub_lat_deg = float(observer_lla[0])
    sub_lon_deg = float(observer_lla[1])
    sub_lat = np.radians(sub_lat_deg)

    earth_angle = _earth_angle(observer_xyz, fov_half_angle_deg)

    lat_max = np.degrees(sub_lat + earth_angle)
    lat_min = np.degrees(sub_lat - earth_angle)

    # Pole-reaching footprint: all longitudes visible, latitudes clamped.
    if lat_max >= POLE_DEG or lat_min <= -POLE_DEG:
        return (
            max(lat_min, -POLE_DEG),
            min(lat_max, POLE_DEG),
            -HALF_CIRCLE_DEG,
            HALF_CIRCLE_DEG,
        )

    delta_lon = float(np.degrees(np.arcsin(np.sin(earth_angle) / np.cos(sub_lat))))
    return (lat_min, lat_max, sub_lon_deg - delta_lon, sub_lon_deg + delta_lon)


def compute_footprint(
    observer_xyz: NDArray[np.floating],
    fov_half_angle_deg: float | None = None,
    n_points: int = 360,
) -> NDArray[np.floating]:
    """Compute the ground visibility boundary for an observer.

    Traces a circle on the Earth's surface representing the boundary of
    the area visible from the observer. For a satellite, this is the
    horizon circle; for a collector with a limited field of view, it is
    the smaller circle defined by the FOV cone intersecting the surface.

    Uses a local-radius spherical approximation: the surface radius is
    taken as the geocentric radius of the WGS84 ellipsoid in the direction
    of the observer (closed-form from the ECEF coordinates; no conversion
    round-trip). Boundary points are returned in WGS84 ECEF.

    Args:
        observer_xyz: Observer position in ECEF meters, shape (3,).
        fov_half_angle_deg: Half-angle of the observer's field of view
            in degrees, measured from nadir. If None, uses the full
            horizon (maximum visible area). If provided, the footprint
            is capped to min(fov_half_angle, horizon_angle) so it never
            extends past the geometric horizon.
        n_points: Number of points around the boundary circle.

    Returns:
        Boundary points in ECEF meters, shape (n_points, 3).

    Raises:
        ValueError: If the observer is at or below the local ellipsoid
            surface (no horizon is defined).
    """
    observer_xyz = np.asarray(observer_xyz, dtype=np.float64)
    observer_lla = xyz_to_lla(observer_xyz)
    sub_lat = np.radians(observer_lla[0])
    sub_lon = np.radians(observer_lla[1])

    earth_angle = _earth_angle(observer_xyz, fov_half_angle_deg)

    # Trace great-circle points at angular distance earth_angle
    # from sub-observer point.
    azimuths = np.linspace(0, 2 * np.pi, n_points, endpoint=False)

    sin_sub = np.sin(sub_lat)
    cos_sub = np.cos(sub_lat)
    sin_ea = np.sin(earth_angle)
    cos_ea = np.cos(earth_angle)

    lats = np.arcsin(sin_sub * cos_ea + cos_sub * sin_ea * np.cos(azimuths))
    lons = sub_lon + np.arctan2(
        np.sin(azimuths) * sin_ea * cos_sub,
        cos_ea - sin_sub * np.sin(lats),
    )

    lla = np.column_stack([np.degrees(lats), np.degrees(lons), np.zeros(n_points)])
    return lla_to_xyz(lla)
