"""Simplified lunar position using Meeus approximation.

Provides a lightweight Moon ECEF position estimate (~1 degree accuracy)
without requiring external ephemeris data. Suitable for visualization,
rough geometry checks, and scene context -- not for precision work.

Reference: Meeus, J. "Astronomical Algorithms", 2nd ed., Chapter 47.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_utils.conversion.gmst import unix_to_gmst

if TYPE_CHECKING:
    from numpy.typing import NDArray


def moon_ecef(unix_s: float) -> NDArray[np.floating]:
    """Compute approximate lunar position in ECEF coordinates.

    Uses a simplified Meeus approximation for the Moon's ecliptic
    coordinates, then rotates through obliquity to ECI and through
    GMST to ECEF. Accuracy is roughly 1 degree in position, which
    corresponds to ~6700 km at lunar distance.

    Args:
        unix_s: Unix timestamp (seconds since 1970-01-01 UTC).

    Returns:
        Moon ECEF position in meters, shape (3,).
    """
    # Julian centuries from J2000.0
    jd = unix_s / 86400.0 + 2440587.5
    t = (jd - 2451545.0) / 36525.0

    # Mean longitude (deg)
    l0 = 218.3165 + 481267.8813 * t
    # Mean anomaly (deg)
    m = 134.9634 + 477198.8676 * t
    # Mean elongation (deg)
    d = 297.8502 + 445267.1115 * t

    m_rad = np.radians(m % 360)
    d_rad = np.radians(d % 360)

    # Ecliptic longitude (deg, simplified)
    lon_ecl = l0 + 6.2890 * np.sin(m_rad) + 1.274 * np.sin(2 * d_rad - m_rad)
    # Ecliptic latitude (deg, simplified)
    lat_ecl = 5.128 * np.sin(np.radians((93.272 + 483202.0175 * t) % 360))
    # Distance (km, simplified)
    dist_km = 385001 - 20905 * np.cos(m_rad)

    lon_rad = np.radians(lon_ecl % 360)
    lat_rad = np.radians(lat_ecl)
    dist_m = dist_km * 1000.0

    # Ecliptic to ECI (approximate obliquity of the ecliptic)
    eps = np.radians(23.4393)
    x_eci = dist_m * np.cos(lat_rad) * np.cos(lon_rad)
    y_ecl = dist_m * np.cos(lat_rad) * np.sin(lon_rad)
    z_ecl = dist_m * np.sin(lat_rad)
    y_eci = y_ecl * np.cos(eps) - z_ecl * np.sin(eps)
    z_eci = y_ecl * np.sin(eps) + z_ecl * np.cos(eps)

    # ECI to ECEF via GMST rotation
    theta = unix_to_gmst(unix_s)
    cos_t = np.cos(theta)
    sin_t = np.sin(theta)
    return np.array(
        [
            cos_t * x_eci + sin_t * y_eci,
            -sin_t * x_eci + cos_t * y_eci,
            z_eci,
        ],
    )
