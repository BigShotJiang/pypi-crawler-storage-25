"""Create OrbitalElements for a prograde circular orbit through an ECEF point.

This module provides a convenient way to define a circular orbit that passes
through a specific location on or above Earth at a given time. The orbit is
assumed to be prograde (eastward velocity).

The function determines the orbit radius from the point's distance from Earth's
center, and computes the appropriate inclination and RAAN based on where the
point is located.

References:
    - Vallado, D. "Fundamentals of Astrodynamics and Applications", 4th ed.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import numpy as np

from gri_utils.constants import GM_EARTH
from gri_utils.conversion import ecef_to_eci

from .from_state import from_position_velocity

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray

    from .orbital_elements import OrbitalElements

TOLERANCE = 1e-10
"""Numerical tolerance for near-zero checks to avoid division by zero."""


def from_circular(
    xyz_ecef_m: NDArray[np.floating] | Sequence,
    unix_s: float,
    azimuth_deg: float = 90.0,
) -> OrbitalElements:
    """Create a circular orbit passing through an ECEF point at a time.

    Given an Earth-fixed position, time, and velocity heading at that point,
    creates orbital elements for a circular orbit that passes through the
    position with velocity pointing at the specified compass azimuth.

    Args:
        xyz_ecef_m: Position in ECEF (Earth-Centered Earth-Fixed) coordinates
            in meters. Shape (3,). This defines both the orbital radius and
            the orbit plane orientation.
        unix_s: Unix timestamp in seconds when the orbit passes through this
            point. This becomes the epoch of the orbital elements.
        azimuth_deg: Compass azimuth of the velocity at the point, in degrees.
            Measured clockwise from local north in the local ENU (east, north,
            up) frame. 0 = north, 90 = east (default, prograde equatorward),
            180 = south, 270 = west. Values >= 180 produce retrograde orbits.

    Returns:
        OrbitalElements for a circular orbit through the specified point at
        the specified time, with velocity at the compass azimuth given.

    Raises:
        ValueError: If the position is at Earth's center (zero radius).

    Example:
        >>> import numpy as np
        >>> from gri_utils.orbit import from_circular
        >>> # Prograde circular orbit over a point at 400 km altitude
        >>> xyz_ecef = np.array([6_778_000.0, 0.0, 0.0])  # Equatorial point
        >>> elements = from_circular(xyz_ecef, unix_s=1704067200.0)
        >>> print(f"Eccentricity: {elements.eccentricity:.6f}")  # ~0 (circular)

    Note:
        For the default `azimuth_deg=90` (due east) the input point is the
        northernmost/southernmost point of the orbit, and the inclination is
        exactly |latitude| (minimum inclination to reach that latitude).

        In general, inclination satisfies
            cos(inclination) = cos(latitude) * sin(azimuth_deg)
        so `azimuth_deg=0` or `180` gives a polar orbit regardless of
        latitude, and `azimuth_deg` in (180, 360) produces retrograde orbits.
    """
    xyz_ecef = np.asarray(xyz_ecef_m, dtype=np.float64)

    # Convert ECEF to ECI at the given time
    xyz_eci = ecef_to_eci(xyz_ecef, unix_s)

    # Orbital radius
    r_mag = float(np.linalg.norm(xyz_eci))

    if r_mag < 1e-6:  # noqa: PLR2004
        msg = "Position cannot be at Earth's center (zero radius)"
        raise ValueError(msg)

    # Circular velocity magnitude: v = sqrt(mu/r)
    v_mag = math.sqrt(GM_EARTH / r_mag)

    # For a prograde circular orbit, velocity is perpendicular to position
    # and in the direction of increasing longitude (eastward).
    #
    # The velocity should be perpendicular to r and have a component in the
    # direction of increasing azimuth (prograde).
    #
    # In the orbit plane, velocity is perpendicular to position.
    # For prograde motion, we want angular momentum to point generally
    # toward celestial north (positive z component for inclinations < 90 deg).
    #
    # We compute velocity as: v = (h x r) / |r|^2 * |v|
    # where h is in the direction we want angular momentum.
    #
    # For prograde: h should be roughly aligned with +z (celestial north)
    # This means v = (h_unit x r) * v_mag / |r|
    #
    # Actually, simpler approach: for circular orbit velocity is perpendicular
    # to r. The velocity direction that gives prograde motion (h pointing
    # generally north) is:
    #
    # v_direction = (z_axis x r) / |z_axis x r|  if the result has the right sign
    # or we need to construct it more carefully.

    # Local ENU basis in ECI at the point.
    # up_eci points radially outward; east_eci is perpendicular to z and r
    # (the direction of increasing celestial longitude); north_eci completes
    # the right-handed triad: {east, north, up} with up x east = north.
    r_unit = xyz_eci / r_mag
    z_axis = np.array([0.0, 0.0, 1.0])

    z_cross_r = np.cross(z_axis, r_unit)
    z_cross_r_mag = float(np.linalg.norm(z_cross_r))

    az_rad = math.radians(azimuth_deg)
    if z_cross_r_mag < TOLERANCE:
        # Point is on the z-axis (polar), ENU is degenerate.
        # Pick any direction perpendicular to r as velocity direction; this
        # recovers the prior fallback behavior when the input is a pole.
        v_direction = np.array([1.0, 0.0, 0.0])
    else:
        east_unit = z_cross_r / z_cross_r_mag
        north_unit = np.cross(r_unit, east_unit)

        # Velocity unit direction in the local ENU tangent plane at this point:
        # v_hat = sin(az) * east + cos(az) * north
        v_direction = math.sin(az_rad) * east_unit + math.cos(az_rad) * north_unit

    # Compute velocity vector
    v_eci = v_direction * v_mag

    # Convert to orbital elements
    return from_position_velocity(xyz_eci, v_eci, unix_s)
