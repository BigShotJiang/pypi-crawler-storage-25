import os
import click
import uvicorn

@click.group()
def dragon():
    """🐉 KHP Dragon CLI - Manage your Dragon Empire"""
    pass

@dragon.command()
@click.argument('name')
def create(name):
    """Create a new dragon nest: khpdragon create <name>"""
    os.makedirs(name, exist_ok=True)
    main_code = f"""from khpdragon import KHP
from pydantic import BaseModel

khp = KHP()

class Warrior(BaseModel):
    name: str
    level: int

@khp.look("/")
async def home():
    return {{"message": "Welcome to {name}! The Dragon is watching over you. 🐉"}}

@khp.hit("/spawn")
async def spawn(warrior: Warrior):
    return {{"status": "Warrior Spawned", "data": warrior}}

if __name__ == "__main__":
    khp.fly()
"""
    with open(f"{name}/main.py", "w", encoding="utf-8") as f:
        f.write(main_code)
    click.echo(f"✅ Nest '{name}' is ready! Type 'cd {name}' and 'khpdragon fly' to start.")

@dragon.command()
@click.option('--host', default="127.0.0.1")
@click.option('--port', default=8000)
def fly(host, port):
    """Make the dragon fly (Run Server): khpdragon fly"""
    if not os.path.exists("main.py"):
        click.echo("❌ Error: main.py not found in this folder!")
        return
    uvicorn.run("main:khp.app", host=host, port=port, reload=True)