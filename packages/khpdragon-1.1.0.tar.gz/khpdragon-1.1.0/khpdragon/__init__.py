import uvicorn
import inspect
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route
from pydantic import BaseModel
from spectree import SpecTree

class KHP:
    def __init__(self, db_name="dragon_nest.db"):
        self.routes = []
        self.db_name = db_name
        # إعداد التوثيق الذاتي
        self.spec = SpecTree("starlette", title="KHP Dragon API", version="1.1.0", path="apidocs")
        # المحرك الأساسي
        self.app = Starlette(debug=True, routes=self.routes)

    def _add_route(self, path, func, methods):
        sig = inspect.signature(func)
        model = None
        for param in sig.parameters.values():
            if isinstance(param.annotation, type) and issubclass(param.annotation, BaseModel):
                model = param.annotation

        async def wrapper(request):
            kwargs = {}
            if 'request' in sig.parameters: kwargs['request'] = request
            
            if model:
                try:
                    body = await request.json()
                    kwargs[next(iter(sig.parameters))] = model(**body)
                except Exception as e:
                    return JSONResponse({"error": "Data Inconsistent", "details": str(e)}, status_code=422)

            try:
                response = await func(**kwargs)
                if isinstance(response, (dict, list)):
                    return JSONResponse(response)
                return response
            except Exception as e:
                return JSONResponse({"error": "Dragon Breath Failure", "reason": str(e)}, status_code=500)

        # دمج التوثيق مع الـ Route
        decorated_func = self.spec.validate()(wrapper)
        self.routes.append(Route(path, decorated_func, methods=methods))
        # تحديث الـ app بالمسارات الجديدة
        self.app.routes = self.routes

    # أوامر التحكم
    def look(self, path): return lambda f: self._add_route(path, f, ["GET"]) or f
    def hit(self, path): return lambda f: self._add_route(path, f, ["POST"]) or f
    def update(self, path): return lambda f: self._add_route(path, f, ["PUT"]) or f
    def burn(self, path): return lambda f: self._add_route(path, f, ["DELETE"]) or f

    def fly(self, host="127.0.0.1", port=8000):
        self.spec.register(self.app)
        print(f"🐉 KHP DRAGON IS FLYING at http://{host}:{port}")
        uvicorn.run(self.app, host=host, port=port)