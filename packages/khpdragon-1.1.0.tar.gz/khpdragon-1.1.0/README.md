# 🐉 KHP Dragon
**The Winged Web Framework.**
Fast, Async, and Powerful.

## Installation
```bash
pip install khpdragon