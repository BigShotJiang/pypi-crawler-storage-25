# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.0] - 2026-05-08

### Added — Smart Injection Engine (the "Write-Once, Fully-Visible" release)
- **`inject_knowledge` MCP tool**: Smart knowledge injection with dedup, section-level targeting,
  and automatic L0 index sync. Supports three modes: `upsert` (replace similar), `append` (always add),
  `merge` (combine unique parts). This is now the recommended write path for all agents.
- **`sync_l0_index` MCP tool**: Force regeneration of the L0 index from L1 knowledge files.
  Supports `dry_run` preview mode and two output formats (`hermes` / `generic`).
- **`validate_knowledge` MCP tool**: Health diagnosis of the knowledge base. Checks L0-L1
  consistency, file health (size/structure/age), and orphaned/stale entries.
- **`manage_l0_entry` MCP tool**: Fine-grained add/remove/replace of individual L0 index entries.
- **`l0_manager` module**: Read, write, sync the L0 index layer. Supports Hermes agent format
  (`[L0索引] domain: summary → knowledge/file.md`) and generic format.
- **`injector` module**: Smart knowledge write engine. Handles dedup (via `find_similar_knowledge`),
  section targeting (find or create `## headings`), file locking, size warnings, and provenance tracking.
- **Knowledge health validation**: `knowledge_health()` from `recall.py` now exposed via MCP as
  `validate_knowledge`, plus L0-L1 consistency checking.

### Changed — Auto L0 Sync
- **`create_knowledge_file`**: Now automatically syncs the L0 index after successful writes
  (configurable via `auto_sync_l0`).
- **`update_knowledge_file`**: Now automatically syncs the L0 index after successful writes.
- **`delete_knowledge_file`**: Now automatically syncs the L0 index after successful deletes
  (removes stale L0 entries).
- **`KnowledgeWatcher`**: In HTTP mode, file changes now trigger debounced L0 index sync
  (10s debounce window). Accepts `config` parameter for auto-sync control.
- **`knowledge_compression_prompt`**: Updated to recommend `inject_knowledge` over manual
  create/update for smarter writes.
- **`pyproject.toml`**: Bumped version to 0.5.0.

### Configuration (new)
- `auto_sync_l0` (bool, default `true`): Auto-sync L0 index after each write. Disable via
  `LAYERED_MEMORY_AUTO_SYNC_L0=0` environment variable.
- `dedup_threshold` (float, default `0.7`): Similarity threshold for dedup in `inject_knowledge`.
  Tune via `LAYERED_MEMORY_DEDUP_THRESHOLD` env var.
- `l0_format` (str, default `"hermes"`): L0 index output format. Tune via `LAYERED_MEMORY_L0_FORMAT` env var.

### Tests
- 12 new integration tests in `tests/test_v050.py` covering: L0 sync, entry management,
  consistency checks, smart injection (create/append/upsert/new sections), auto-sync pipeline,
  and recall integration. All 62 tests (50 original + 12 new) passing.

## [0.4.0] - 2026-05-04

### Breaking
- Removed `_version.py` — version is now defined only in `__init__.py` and `pyproject.toml`

### Security
- **[CRITICAL] Unified path validation**: All write tools (`create/update/delete`) now enforce `.md` suffix
  and path traversal protection through a single `_validate_knowledge_path()` function.
  Previously, `update` and `delete` accepted any file type (e.g. `dangerous.py`).
- **Session search concurrency**: Added `asyncio.Semaphore(10)` to prevent thread storms

### Fixed
- **Version duplication**: Eliminated `_version.py`, single source of truth in `__init__.py`
- **Heading parsing inconsistency**: `extract_relevant_sections` now matches h1-h6 headings
  (was only h2), aligned with `score_relevance` behavior
- **Division by zero**: `list_memory_stats` now handles empty knowledge directories gracefully
- **Config override**: `main()` no longer unconditionally overwrites global `_config`
- **Dead code**: Removed unreachable fallback branch in `_extract_heading_title`
- **Type syntax**: Unified all type hints to Python 3.10+ style (`X | Y` instead of `Optional[X]`)

### Added
- **Write MCP tools**: `create_knowledge_file`, `update_knowledge_file`, `delete_knowledge_file`
- **Cognitive Decision Framework**: New MCP prompt `cognitive_decision_prompt` + docs in all 4 READMEs
- 14 new tests (49 total, all passing)

## [0.3.0] - 2026-05-04

### Breaking
- `session_scanner.extract_session_summary()`: parameter `max_lines` renamed to `max_messages`

### Fixed
- **Hermes .json session support**: `session_scanner` now auto-detects JSON vs JSONL format.
  Previously only JSONL was supported, causing all Hermes `.json` sessions to fail silently.
- **Title extraction bug**: `recall.py` `lstrip("# ")` → `removeprefix("## ")` for correct heading parsing
- **Silent failures**: `recall.py` now logs unreadable files instead of swallowing exceptions
- **Async safety**: All MCP resource functions (`get_memory_status`, `list_knowledge_files`) now
  wrap blocking I/O in `asyncio.to_thread()` to prevent event loop blocking
- **Duplicate log handlers**: `_setup_logging()` now checks for existing handlers
- **Path traversal edge case**: `get_knowledge_file` now also checks `is_file()`

### Added
- `_detect_and_parse_file()`: Auto-detect Hermes JSON, JSONL, and generic session formats
- `_parse_messages_from_entry()`: Extract messages from Hermes `{"messages": [...]}` wrapper
- `MAX_SESSION_SIZE` (10MB) and `MAX_KNOWLEDGE_FILE_SIZE` (5MB) safety limits
- Expanded `JSON_EXCLUDE_NAMES` with lock files and pattern-based exclusion
- `.gitignore` to prevent `dist/` and cache files from being committed
- `config.py`: Validates `LAYERED_MEMORY_HOME` is an absolute path
- 4 new tests for JSON session format parsing (35 total, all passing)

## [0.2.0] - 2026-05-04

### Fixed
- **API consistency**: `get_knowledge_file` now always returns JSON with `success` field
- **Dead code**: Removed unused `import re` and `section_context_lines` parameter from `recall.py`
- **Import hygiene**: Moved function-level imports to module top in `server.py`
- **Config symmetry**: `home` directory is now auto-created alongside `knowledge_dir`

### Added
- **i18n README**: Chinese (`README.zh-CN.md`), Japanese (`README.ja.md`), Korean (`README.ko.md`)
- **PyPI badge** and **project URLs** in `pyproject.toml`
- **Dynamic version** in `__init__.py` (reads from package metadata)
- **pytest configuration** in `pyproject.toml` (`asyncio_mode = "auto"`)
- **CHANGELOG.md** (this file)
- **Expanded test suite**: server-level tool tests, edge cases, concurrent safety

### Changed
- `session_scanner.py`: Filter out non-session JSON files (package.json, config.json, etc.)
- `server.py`: Added `logging` module with `--verbose` flag
- `server.py`: Added path traversal protection in `get_knowledge_file`

## [0.1.0] - 2026-05-04

### Added
- Initial release
- 4-tier knowledge architecture (L0/L1/L2/L3)
- 5 MCP tools: `recall_knowledge`, `scan_recent_sessions`, `get_knowledge_file`, `list_memory_stats`, `search_sessions_by_keyword`
- 2 MCP resources: `memory://status`, `knowledge://files`
- 1 MCP prompt: `knowledge_compression_prompt`
- FastMCP 2.0 transport (stdio + HTTP)
- Zero external dependencies (core), only `fastmcp` for MCP transport
- MIT License

[0.4.0]: https://github.com/LAIguapi/layered-memory-mcp/releases/tag/v0.4.0
[0.3.0]: https://github.com/LAIguapi/layered-memory-mcp/releases/tag/v0.3.0
[0.2.0]: https://github.com/LAIguapi/layered-memory-mcp/releases/tag/v0.2.0
[0.1.0]: https://github.com/LAIguapi/layered-memory-mcp/releases/tag/v0.1.0
