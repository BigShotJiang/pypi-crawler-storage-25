"""
L0 Index Manager — Read, write, sync the L0 index layer.

L0 is the compact index injected into every agent turn. It maps domain names
to L1 knowledge files so the agent knows *what knowledge exists* without
loading all of it.

Two formats are supported:
  - "hermes":  [L0索引] domain: summary → knowledge/file.md
  - "generic": [file.md] Title → keyword1, keyword2
"""

import logging
import re
from pathlib import Path
from typing import Callable

from .recall import generate_l0_index, invalidate_scan_cache, scan_knowledge_files

logger = logging.getLogger("layered_memory_mcp.l0_manager")

# Regex patterns for parsing L0 entries
_HERMES_ENTRY_RE = re.compile(
    r"^\[L0索引\]\s*(?P<domain>[^:：]+)[：:]\s*(?P<summary>.+?)\s*→\s*(?P<path>.+)$"
)
_GENERIC_ENTRY_RE = re.compile(
    r"^\[(?P<file>[^\]]+)\]\s*(?P<title>.+?)(?:\s*→\s*(?P<keywords>.+))?$"
)


# ---------------------------------------------------------------------------
# Core sync
# ---------------------------------------------------------------------------

def sync_l0_index(
    config,  # MemoryConfig — avoid circular import
    dry_run: bool = False,
) -> dict:
    """Synchronise L0 index with actual L1 knowledge files.

    Returns a report regardless of dry_run.
    """
    knowledge_dir = str(config.knowledge_dir)
    l0_file = config.l0_index_file

    # Scan existing L1 files across all knowledge dirs (namespace + shared)
    kdirs = [str(d) for d in config.knowledge_dirs]
    if len(kdirs) > 1:
        from .recall import scan_knowledge_dirs
        l1_files = scan_knowledge_dirs(kdirs)
    else:
        l1_files = scan_knowledge_files(kdirs[0])
    l1_basenames = {name for name in l1_files}  # e.g. {"infra.md", "wechat.md"}

    # --- Generate fresh index content ---
    if config.l0_format == "hermes":
        new_lines = _generate_hermes_index(kdirs if len(kdirs) > 1 else kdirs[0], l1_files)
    else:
        new_content_raw = generate_l0_index(kdirs if len(kdirs) > 1 else kdirs[0])
        new_lines = new_content_raw.split("\n") if new_content_raw else []

    new_content = "\n".join(new_lines) + "\n" if new_lines else ""

    # --- Read existing L0 entries (for diff report) ---
    existing_entries: set[str] = set()
    if l0_file and l0_file.exists():
        try:
            existing_text = l0_file.read_text(encoding="utf-8")
            existing_entries = _parse_entry_domains(existing_text, config.l0_format)
        except Exception as e:
            logger.warning("Failed to read existing L0: %s", e)

    # Compute diff
    new_domains = _parse_entry_domains(new_content, config.l0_format)
    added = new_domains - existing_entries
    removed = existing_entries - new_domains
    unchanged = existing_entries & new_domains

    report = {
        "success": True,
        "l0_file": str(l0_file) if l0_file else None,
        "l0_format": config.l0_format,
        "l1_files_found": len(l1_files),
        "entries_added": len(added),
        "entries_removed": len(removed),
        "entries_unchanged": len(unchanged),
        "total_entries": len(new_domains),
        "added": sorted(added),
        "removed": sorted(removed),
    }

    if dry_run:
        report["preview"] = new_content
        return report

    # --- Write ---
    if l0_file:
        try:
            if new_content:
                l0_file.write_text(new_content, encoding="utf-8")
                logger.info("Synced L0 index: %d entries → %s", len(new_domains), l0_file)
            else:
                # No L1 files at all — write empty marker
                l0_file.write_text("# L0 Index (empty — no L1 knowledge files)\n", encoding="utf-8")
            report["bytes_written"] = len(new_content.encode("utf-8")) if new_content else 0
        except Exception as e:
            logger.error("Failed to write L0 index: %s", e)
            report["success"] = False
            report["error"] = str(e)
    else:
        report["l0_file"] = None
        report["note"] = "L0 index file not configured — sync skipped (L1 files are up to date)"

    return report




# ---------------------------------------------------------------------------
# Lightweight L0 consistency check for stdio mode (v0.6.0)
# ---------------------------------------------------------------------------

def quick_l0_consistency_check(config) -> dict | None:
    """Fast mtime-based check: is L0 index stale?

    Compares the mtime of the L0 index file against the latest mtime
    of all L1 knowledge files. If any L1 file is newer than L0, returns
    a report indicating staleness.

    Designed for stdio mode where the watcher thread doesn't run.
    Call this at the start of read operations (e.g., recall_knowledge).

    Returns:
        None if L0 is up-to-date or not configured.
        Dict with staleness info if L0 is stale.
    """
    if not config.l0_index_file or not config.l0_index_file.exists():
        return None

    try:
        l0_mtime = config.l0_index_file.stat().st_mtime
    except OSError:
        return None

    # v0.6.0: namespace-aware scanning
    kdirs = [str(d) for d in config.knowledge_dirs]
    if len(kdirs) > 1:
        from .recall import scan_knowledge_dirs
        l1_files = scan_knowledge_dirs(kdirs)
    else:
        l1_files = scan_knowledge_files(kdirs[0])

    stale_files = []
    newest_l1_mtime = 0.0
    for name, path_str in l1_files.items():
        try:
            mtime = Path(path_str).stat().st_mtime
            if mtime > newest_l1_mtime:
                newest_l1_mtime = mtime
            if mtime > l0_mtime:
                stale_files.append(name)
        except OSError:
            continue

    if not stale_files:
        return None

    return {
        "stale": True,
        "l0_mtime": l0_mtime,
        "newest_l1_mtime": newest_l1_mtime,
        "stale_files": stale_files[:10],
        "stale_count": len(stale_files),
        "suggestion": "L0 index is stale — call sync_l0_index to update",
    }

def auto_sync_if_enabled(config) -> dict | None:
    """Convenience wrapper: sync L0 if auto_sync_l0 is enabled.

    Returns the sync report, or None if skipped.
    """
    if not config.auto_sync_l0:
        return None
    return sync_l0_index(config, dry_run=False)


# ---------------------------------------------------------------------------
# Entry management (add / remove / replace individual entries)
# ---------------------------------------------------------------------------

def manage_entry(
    config,
    action: str,
    domain: str,
    summary: str | None = None,
    filename: str | None = None,
) -> dict:
    """Add, remove, or replace a single L0 entry.

    This is for fine-grained control when you don't want to regenerate
    the entire L0 index.
    """
    l0_file = config.l0_index_file
    if not l0_file:
        return {"success": False, "error": "L0 index file not configured"}

    if not l0_file.exists():
        # Create empty file
        l0_file.parent.mkdir(parents=True, exist_ok=True)
        l0_file.write_text("", encoding="utf-8")

    try:
        content = l0_file.read_text(encoding="utf-8")
    except Exception as e:
        return {"success": False, "error": str(e)}

    lines = [l for l in content.split("\n") if l.strip()]

    if action == "add":
        if not summary:
            return {"success": False, "error": "summary is required for 'add'"}
        fn = filename or f"{domain}.md"
        if config.l0_format == "hermes":
            new_line = f"[L0索引] {domain}: {summary} → knowledge/{fn}"
        else:
            new_line = f"[{fn}] {summary}"
        # Check if entry already exists
        for line in lines:
            if _entry_matches_domain(line, domain, config.l0_format):
                return {"success": False, "error": f"Entry for '{domain}' already exists. Use 'replace'."}
        lines.append(new_line)

    elif action == "remove":
        original_count = len(lines)
        lines = [l for l in lines if not _entry_matches_domain(l, domain, config.l0_format)]
        if len(lines) == original_count:
            return {"success": False, "error": f"No entry found for '{domain}'"}

    elif action == "replace":
        if not summary:
            return {"success": False, "error": "summary is required for 'replace'"}
        fn = filename or f"{domain}.md"
        if config.l0_format == "hermes":
            new_line = f"[L0索引] {domain}: {summary} → knowledge/{fn}"
        else:
            new_line = f"[{fn}] {summary}"
        found = False
        for i, line in enumerate(lines):
            if _entry_matches_domain(line, domain, config.l0_format):
                lines[i] = new_line
                found = True
                break
        if not found:
            lines.append(new_line)

    else:
        return {"success": False, "error": f"Unknown action: {action}"}

    new_content = "\n".join(lines) + "\n"
    try:
        l0_file.write_text(new_content, encoding="utf-8")
    except Exception as e:
        return {"success": False, "error": str(e)}

    return {
        "success": True,
        "action": action,
        "domain": domain,
        "l0_file": str(l0_file),
        "total_entries": len(lines),
    }


# ---------------------------------------------------------------------------
# L0 ↔ L1 consistency check
# ---------------------------------------------------------------------------

def check_l0_l1_consistency(config) -> dict:
    """Check that L0 index and L1 files are consistent.

    Returns orphaned L1 files (in L1 but not in L0) and stale L0 entries
    (in L0 but L1 file doesn't exist).
    """
    knowledge_dir = str(config.knowledge_dir)
    l0_file = config.l0_index_file

    # Always get fresh file listing for consistency checks
    invalidate_scan_cache(knowledge_dir)
    l1_files = scan_knowledge_files(knowledge_dir)
    l1_set = set(l1_files.keys())

    # Parse L0 entries to find referenced L1 files
    l0_referenced: set[str] = set()
    if l0_file and l0_file.exists():
        try:
            l0_text = l0_file.read_text(encoding="utf-8")
            l0_referenced = _extract_referenced_files(l0_text, config.l0_format)
        except Exception:
            pass

    orphaned_l1 = sorted(l1_set - l0_referenced)
    stale_l0 = sorted(l0_referenced - l1_set)
    consistent = sorted(l1_set & l0_referenced)

    return {
        "orphaned_l1": orphaned_l1,       # L1 files not referenced in L0
        "stale_l0_entries": stale_l0,       # L0 references to non-existent L1
        "consistent": consistent,
        "total_l1": len(l1_set),
        "total_l0_refs": len(l0_referenced),
        "health": "good" if not orphaned_l1 and not stale_l0 else
                  "fair" if len(orphaned_l1) <= 2 else "poor",
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _generate_hermes_index(knowledge_dir: str, l1_files: dict) -> list[str]:
    """Generate L0 index in Hermes format from L1 files.

    Uses generate_l0_index() for generic format, then we build hermes-specific
    lines by reading each file's first heading and top keywords.
    """
    # Reuse the generic generator — it already extracts title + keywords
    generic = generate_l0_index(knowledge_dir)
    if not generic:
        return []

    lines: list[str] = []
    for line in generic.split("\n"):
        if not line.strip():
            continue
        # Parse [file.md] Title → kw1, kw2
        m = _GENERIC_ENTRY_RE.match(line)
        if not m:
            continue
        gd = m.groupdict()
        filename = gd.get("file", "").strip()
        title = gd.get("title", "").strip()
        keywords = gd.get("keywords", "").strip()

        # Derive domain from filename (strip .md)
        domain = filename.removesuffix(".md")
        # Build summary from title + keywords
        summary_parts = [title] if title else []
        if keywords:
            summary_parts.append(keywords)
        summary = " — ".join(summary_parts) if summary_parts else domain

        lines.append(f"[L0索引] {domain}: {summary} → knowledge/{filename}")

    return lines


def _parse_entry_domains(content: str, fmt: str) -> set[str]:
    """Extract domain names from L0 index content."""
    domains: set[str] = set()
    for line in content.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if fmt == "hermes":
            m = _HERMES_ENTRY_RE.match(line)
            if m:
                domains.add(m.group("domain").strip())
        else:
            m = _GENERIC_ENTRY_RE.match(line)
            if m:
                domains.add(m.group("file").removesuffix(".md"))
    return domains


def _entry_matches_domain(line: str, domain: str, fmt: str) -> bool:
    """Check if an L0 entry line matches the given domain."""
    if fmt == "hermes":
        m = _HERMES_ENTRY_RE.match(line)
        return m is not None and m.group("domain").strip() == domain
    else:
        m = _GENERIC_ENTRY_RE.match(line)
        return m is not None and m.group("file").removesuffix(".md") == domain


def _extract_referenced_files(content: str, fmt: str) -> set[str]:
    """Extract L1 filenames referenced in L0 index."""
    files: set[str] = set()
    for line in content.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if fmt == "hermes":
            m = _HERMES_ENTRY_RE_SAFE.match(line)
            if m:
                path = m.group("path").strip()
                files.add(Path(path).name)
        else:
            m = _GENERIC_ENTRY_RE.match(line)
            if m:
                files.add(m.group("file"))
    return files


# Safe variant that's more permissive for path extraction
_HERMES_ENTRY_RE_SAFE = re.compile(
    r"^\[L0索引\]\s*[^:：]+[：:]\s*.+?\s*→\s*(?P<path>\S+)$"
)
