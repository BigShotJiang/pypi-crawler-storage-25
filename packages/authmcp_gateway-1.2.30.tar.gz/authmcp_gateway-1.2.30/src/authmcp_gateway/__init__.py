"""AuthMCP Gateway - Universal Authentication for MCP Servers."""

__version__ = "1.2.30"
__author__ = "loglux"
__license__ = "MIT"

# Lazy imports to avoid loading config when not needed
# from .app import app  # Import directly when needed
# from .config import load_config, get_config  # Import directly when needed

__all__ = ["__version__"]
