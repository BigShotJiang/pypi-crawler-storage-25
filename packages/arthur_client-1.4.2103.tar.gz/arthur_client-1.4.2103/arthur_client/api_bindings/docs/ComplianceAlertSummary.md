# ComplianceAlertSummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **str** | Description of the triggering alert. | 
**id** | **str** | The ID of the alert. | 

## Example

```python
from arthur_client.api_bindings.models.compliance_alert_summary import ComplianceAlertSummary

# TODO update the JSON string below
json = "{}"
# create an instance of ComplianceAlertSummary from a JSON string
compliance_alert_summary_instance = ComplianceAlertSummary.from_json(json)
# print the JSON string representation of the object
print(ComplianceAlertSummary.to_json())

# convert the object into a dict
compliance_alert_summary_dict = compliance_alert_summary_instance.to_dict()
# create an instance of ComplianceAlertSummary from a dict
compliance_alert_summary_from_dict = ComplianceAlertSummary.from_dict(compliance_alert_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


