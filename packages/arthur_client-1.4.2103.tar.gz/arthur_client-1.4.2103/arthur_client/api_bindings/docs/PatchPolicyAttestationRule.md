# PatchPolicyAttestationRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**validity_period_days** | **int** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.patch_policy_attestation_rule import PatchPolicyAttestationRule

# TODO update the JSON string below
json = "{}"
# create an instance of PatchPolicyAttestationRule from a JSON string
patch_policy_attestation_rule_instance = PatchPolicyAttestationRule.from_json(json)
# print the JSON string representation of the object
print(PatchPolicyAttestationRule.to_json())

# convert the object into a dict
patch_policy_attestation_rule_dict = patch_policy_attestation_rule_instance.to_dict()
# create an instance of PatchPolicyAttestationRule from a dict
patch_policy_attestation_rule_from_dict = PatchPolicyAttestationRule.from_dict(patch_policy_attestation_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


