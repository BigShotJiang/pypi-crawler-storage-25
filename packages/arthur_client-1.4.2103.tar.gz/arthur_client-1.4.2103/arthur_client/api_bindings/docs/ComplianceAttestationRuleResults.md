# ComplianceAttestationRuleResults


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compliant** | [**List[CompliantAttestationRuleStatus]**](CompliantAttestationRuleStatus.md) | Attestation rules with valid attestations. | [optional] 
**non_compliant** | [**List[NonCompliantAttestationRuleStatus]**](NonCompliantAttestationRuleStatus.md) | Attestation rules that are missing or lapsed. | [optional] 

## Example

```python
from arthur_client.api_bindings.models.compliance_attestation_rule_results import ComplianceAttestationRuleResults

# TODO update the JSON string below
json = "{}"
# create an instance of ComplianceAttestationRuleResults from a JSON string
compliance_attestation_rule_results_instance = ComplianceAttestationRuleResults.from_json(json)
# print the JSON string representation of the object
print(ComplianceAttestationRuleResults.to_json())

# convert the object into a dict
compliance_attestation_rule_results_dict = compliance_attestation_rule_results_instance.to_dict()
# create an instance of ComplianceAttestationRuleResults from a dict
compliance_attestation_rule_results_from_dict = ComplianceAttestationRuleResults.from_dict(compliance_attestation_rule_results_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


