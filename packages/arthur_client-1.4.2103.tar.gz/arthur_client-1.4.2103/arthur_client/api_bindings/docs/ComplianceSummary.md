# ComplianceSummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **int** | Total number of rule-assignment rows. | 
**compliant** | **int** | Number of compliant rows. | 
**non_compliant** | **int** | Number of non-compliant rows. | 

## Example

```python
from arthur_client.api_bindings.models.compliance_summary import ComplianceSummary

# TODO update the JSON string below
json = "{}"
# create an instance of ComplianceSummary from a JSON string
compliance_summary_instance = ComplianceSummary.from_json(json)
# print the JSON string representation of the object
print(ComplianceSummary.to_json())

# convert the object into a dict
compliance_summary_dict = compliance_summary_instance.to_dict()
# create an instance of ComplianceSummary from a dict
compliance_summary_from_dict = ComplianceSummary.from_dict(compliance_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


