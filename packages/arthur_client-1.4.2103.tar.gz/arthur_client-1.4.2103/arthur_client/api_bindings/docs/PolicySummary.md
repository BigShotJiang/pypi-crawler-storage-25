# PolicySummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The ID of the policy. | 
**name** | **str** | The name of the policy. | 
**description** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.policy_summary import PolicySummary

# TODO update the JSON string below
json = "{}"
# create an instance of PolicySummary from a JSON string
policy_summary_instance = PolicySummary.from_json(json)
# print the JSON string representation of the object
print(PolicySummary.to_json())

# convert the object into a dict
policy_summary_dict = policy_summary_instance.to_dict()
# create an instance of PolicySummary from a dict
policy_summary_from_dict = PolicySummary.from_dict(policy_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


