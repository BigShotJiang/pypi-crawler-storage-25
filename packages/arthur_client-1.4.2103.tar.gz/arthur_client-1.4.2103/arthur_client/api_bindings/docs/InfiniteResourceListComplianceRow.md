# InfiniteResourceListComplianceRow


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[ComplianceRow]**](ComplianceRow.md) | List of records. | 
**pagination** | [**InfinitePagination**](InfinitePagination.md) | Pagination information. | 

## Example

```python
from arthur_client.api_bindings.models.infinite_resource_list_compliance_row import InfiniteResourceListComplianceRow

# TODO update the JSON string below
json = "{}"
# create an instance of InfiniteResourceListComplianceRow from a JSON string
infinite_resource_list_compliance_row_instance = InfiniteResourceListComplianceRow.from_json(json)
# print the JSON string representation of the object
print(InfiniteResourceListComplianceRow.to_json())

# convert the object into a dict
infinite_resource_list_compliance_row_dict = infinite_resource_list_compliance_row_instance.to_dict()
# create an instance of InfiniteResourceListComplianceRow from a dict
infinite_resource_list_compliance_row_from_dict = InfiniteResourceListComplianceRow.from_dict(infinite_resource_list_compliance_row_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


