# PostPolicyAttestationRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of the attestation rule. | 
**description** | **str** |  | [optional] 
**validity_period_days** | **int** | The validity period in days for attestation. | 

## Example

```python
from arthur_client.api_bindings.models.post_policy_attestation_rule import PostPolicyAttestationRule

# TODO update the JSON string below
json = "{}"
# create an instance of PostPolicyAttestationRule from a JSON string
post_policy_attestation_rule_instance = PostPolicyAttestationRule.from_json(json)
# print the JSON string representation of the object
print(PostPolicyAttestationRule.to_json())

# convert the object into a dict
post_policy_attestation_rule_dict = post_policy_attestation_rule_instance.to_dict()
# create an instance of PostPolicyAttestationRule from a dict
post_policy_attestation_rule_from_dict = PostPolicyAttestationRule.from_dict(post_policy_attestation_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


