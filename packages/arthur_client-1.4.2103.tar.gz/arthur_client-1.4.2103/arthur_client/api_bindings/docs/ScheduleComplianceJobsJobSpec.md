# ScheduleComplianceJobsJobSpec


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_type** | **str** |  | [optional] [default to 'schedule_compliance_jobs']
**scope_model_id** | **str** | The id of the model to schedule compliance checks for. | 

## Example

```python
from arthur_client.api_bindings.models.schedule_compliance_jobs_job_spec import ScheduleComplianceJobsJobSpec

# TODO update the JSON string below
json = "{}"
# create an instance of ScheduleComplianceJobsJobSpec from a JSON string
schedule_compliance_jobs_job_spec_instance = ScheduleComplianceJobsJobSpec.from_json(json)
# print the JSON string representation of the object
print(ScheduleComplianceJobsJobSpec.to_json())

# convert the object into a dict
schedule_compliance_jobs_job_spec_dict = schedule_compliance_jobs_job_spec_instance.to_dict()
# create an instance of ScheduleComplianceJobsJobSpec from a dict
schedule_compliance_jobs_job_spec_from_dict = ScheduleComplianceJobsJobSpec.from_dict(schedule_compliance_jobs_job_spec_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


