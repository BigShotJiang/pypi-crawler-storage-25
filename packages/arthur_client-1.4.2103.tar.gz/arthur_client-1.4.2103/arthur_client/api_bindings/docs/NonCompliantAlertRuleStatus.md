# NonCompliantAlertRuleStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The ID of the alert rule. | 
**name** | **str** | The name of the alert rule. | 
**alert** | [**ComplianceAlertSummary**](ComplianceAlertSummary.md) | The alert that caused the violation. | 

## Example

```python
from arthur_client.api_bindings.models.non_compliant_alert_rule_status import NonCompliantAlertRuleStatus

# TODO update the JSON string below
json = "{}"
# create an instance of NonCompliantAlertRuleStatus from a JSON string
non_compliant_alert_rule_status_instance = NonCompliantAlertRuleStatus.from_json(json)
# print the JSON string representation of the object
print(NonCompliantAlertRuleStatus.to_json())

# convert the object into a dict
non_compliant_alert_rule_status_dict = non_compliant_alert_rule_status_instance.to_dict()
# create an instance of NonCompliantAlertRuleStatus from a dict
non_compliant_alert_rule_status_from_dict = NonCompliantAlertRuleStatus.from_dict(non_compliant_alert_rule_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


