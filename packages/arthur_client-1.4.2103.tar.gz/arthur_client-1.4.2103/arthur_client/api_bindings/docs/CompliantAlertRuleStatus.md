# CompliantAlertRuleStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The ID of the alert rule. | 
**name** | **str** | The name of the alert rule. | 

## Example

```python
from arthur_client.api_bindings.models.compliant_alert_rule_status import CompliantAlertRuleStatus

# TODO update the JSON string below
json = "{}"
# create an instance of CompliantAlertRuleStatus from a JSON string
compliant_alert_rule_status_instance = CompliantAlertRuleStatus.from_json(json)
# print the JSON string representation of the object
print(CompliantAlertRuleStatus.to_json())

# convert the object into a dict
compliant_alert_rule_status_dict = compliant_alert_rule_status_instance.to_dict()
# create an instance of CompliantAlertRuleStatus from a dict
compliant_alert_rule_status_from_dict = CompliantAlertRuleStatus.from_dict(compliant_alert_rule_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


