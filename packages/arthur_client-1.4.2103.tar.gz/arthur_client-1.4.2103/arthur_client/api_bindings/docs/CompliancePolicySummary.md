# CompliancePolicySummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The policy ID. | 
**name** | **str** | The policy name. | 

## Example

```python
from arthur_client.api_bindings.models.compliance_policy_summary import CompliancePolicySummary

# TODO update the JSON string below
json = "{}"
# create an instance of CompliancePolicySummary from a JSON string
compliance_policy_summary_instance = CompliancePolicySummary.from_json(json)
# print the JSON string representation of the object
print(CompliancePolicySummary.to_json())

# convert the object into a dict
compliance_policy_summary_dict = compliance_policy_summary_instance.to_dict()
# create an instance of CompliancePolicySummary from a dict
compliance_policy_summary_from_dict = CompliancePolicySummary.from_dict(compliance_policy_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


