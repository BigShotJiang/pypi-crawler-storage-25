# ComplianceStatusDetail


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ComplianceStatus**](ComplianceStatus.md) | The overall compliance status. | 
**alert_rules** | [**ComplianceAlertRuleResults**](ComplianceAlertRuleResults.md) | Alert rule compliance breakdown. | 
**attestation_rules** | [**ComplianceAttestationRuleResults**](ComplianceAttestationRuleResults.md) | Attestation rule compliance breakdown. | 

## Example

```python
from arthur_client.api_bindings.models.compliance_status_detail import ComplianceStatusDetail

# TODO update the JSON string below
json = "{}"
# create an instance of ComplianceStatusDetail from a JSON string
compliance_status_detail_instance = ComplianceStatusDetail.from_json(json)
# print the JSON string representation of the object
print(ComplianceStatusDetail.to_json())

# convert the object into a dict
compliance_status_detail_dict = compliance_status_detail_instance.to_dict()
# create an instance of ComplianceStatusDetail from a dict
compliance_status_detail_from_dict = ComplianceStatusDetail.from_dict(compliance_status_detail_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


