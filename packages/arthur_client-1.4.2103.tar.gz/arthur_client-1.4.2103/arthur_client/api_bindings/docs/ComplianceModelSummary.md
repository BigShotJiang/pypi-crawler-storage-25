# ComplianceModelSummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The model ID. | 
**name** | **str** | The model name. | 

## Example

```python
from arthur_client.api_bindings.models.compliance_model_summary import ComplianceModelSummary

# TODO update the JSON string below
json = "{}"
# create an instance of ComplianceModelSummary from a JSON string
compliance_model_summary_instance = ComplianceModelSummary.from_json(json)
# print the JSON string representation of the object
print(ComplianceModelSummary.to_json())

# convert the object into a dict
compliance_model_summary_dict = compliance_model_summary_instance.to_dict()
# create an instance of ComplianceModelSummary from a dict
compliance_model_summary_from_dict = ComplianceModelSummary.from_dict(compliance_model_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


