# CreatePolicyAssignmentsRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**model_ids** | **List[str]** | List of model IDs to apply the policy to. | 

## Example

```python
from arthur_client.api_bindings.models.create_policy_assignments_request import CreatePolicyAssignmentsRequest

# TODO update the JSON string below
json = "{}"
# create an instance of CreatePolicyAssignmentsRequest from a JSON string
create_policy_assignments_request_instance = CreatePolicyAssignmentsRequest.from_json(json)
# print the JSON string representation of the object
print(CreatePolicyAssignmentsRequest.to_json())

# convert the object into a dict
create_policy_assignments_request_dict = create_policy_assignments_request_instance.to_dict()
# create an instance of CreatePolicyAssignmentsRequest from a dict
create_policy_assignments_request_from_dict = CreatePolicyAssignmentsRequest.from_dict(create_policy_assignments_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


