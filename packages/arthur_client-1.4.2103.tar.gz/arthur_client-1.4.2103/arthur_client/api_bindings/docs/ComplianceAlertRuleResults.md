# ComplianceAlertRuleResults


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compliant** | [**List[CompliantAlertRuleStatus]**](CompliantAlertRuleStatus.md) | Alert rules that are passing. | [optional] 
**non_compliant** | [**List[NonCompliantAlertRuleStatus]**](NonCompliantAlertRuleStatus.md) | Alert rules that are in violation. | [optional] 

## Example

```python
from arthur_client.api_bindings.models.compliance_alert_rule_results import ComplianceAlertRuleResults

# TODO update the JSON string below
json = "{}"
# create an instance of ComplianceAlertRuleResults from a JSON string
compliance_alert_rule_results_instance = ComplianceAlertRuleResults.from_json(json)
# print the JSON string representation of the object
print(ComplianceAlertRuleResults.to_json())

# convert the object into a dict
compliance_alert_rule_results_dict = compliance_alert_rule_results_instance.to_dict()
# create an instance of ComplianceAlertRuleResults from a dict
compliance_alert_rule_results_from_dict = ComplianceAlertRuleResults.from_dict(compliance_alert_rule_results_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


