# AttestationRecord


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The ID of the attestation record. | 
**created_at** | **datetime** | Time of record creation. | 
**policy_attestation_rule_id** | **str** | The ID of the attestation rule. | 
**policy_model_assignment_id** | **str** | The ID of the policy assignment. | 
**model_id** | **str** | The ID of the model. | 
**attested_by_user** | [**User**](User.md) |  | [optional] 
**notes** | **str** | Notes from the reviewer. | 
**attested_at** | **datetime** | When the attestation was submitted. | 
**next_attestation_due** | **datetime** | When the next attestation is due. | 

## Example

```python
from arthur_client.api_bindings.models.attestation_record import AttestationRecord

# TODO update the JSON string below
json = "{}"
# create an instance of AttestationRecord from a JSON string
attestation_record_instance = AttestationRecord.from_json(json)
# print the JSON string representation of the object
print(AttestationRecord.to_json())

# convert the object into a dict
attestation_record_dict = attestation_record_instance.to_dict()
# create an instance of AttestationRecord from a dict
attestation_record_from_dict = AttestationRecord.from_dict(attestation_record_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


