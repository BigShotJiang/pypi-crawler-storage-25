# ModelSummary


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The ID of the model. | 
**name** | **str** | The name of the model. | 
**project_id** | **str** | The ID of the project the model belongs to. | 

## Example

```python
from arthur_client.api_bindings.models.model_summary import ModelSummary

# TODO update the JSON string below
json = "{}"
# create an instance of ModelSummary from a JSON string
model_summary_instance = ModelSummary.from_json(json)
# print the JSON string representation of the object
print(ModelSummary.to_json())

# convert the object into a dict
model_summary_dict = model_summary_instance.to_dict()
# create an instance of ModelSummary from a dict
model_summary_from_dict = ModelSummary.from_dict(model_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


