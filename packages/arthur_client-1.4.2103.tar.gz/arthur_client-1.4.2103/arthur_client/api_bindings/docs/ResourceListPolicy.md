# ResourceListPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**records** | [**List[Policy]**](Policy.md) | List of records. | 
**pagination** | [**Pagination**](Pagination.md) | Pagination information. | 

## Example

```python
from arthur_client.api_bindings.models.resource_list_policy import ResourceListPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of ResourceListPolicy from a JSON string
resource_list_policy_instance = ResourceListPolicy.from_json(json)
# print the JSON string representation of the object
print(ResourceListPolicy.to_json())

# convert the object into a dict
resource_list_policy_dict = resource_list_policy_instance.to_dict()
# create an instance of ResourceListPolicy from a dict
resource_list_policy_from_dict = ResourceListPolicy.from_dict(resource_list_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


