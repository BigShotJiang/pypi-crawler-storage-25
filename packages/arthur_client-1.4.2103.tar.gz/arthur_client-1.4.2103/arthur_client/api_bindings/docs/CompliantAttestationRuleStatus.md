# CompliantAttestationRuleStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The ID of the attestation rule. | 
**name** | **str** | The name of the attestation rule. | 
**notes** | **str** |  | [optional] 
**expires_at** | **datetime** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.compliant_attestation_rule_status import CompliantAttestationRuleStatus

# TODO update the JSON string below
json = "{}"
# create an instance of CompliantAttestationRuleStatus from a JSON string
compliant_attestation_rule_status_instance = CompliantAttestationRuleStatus.from_json(json)
# print the JSON string representation of the object
print(CompliantAttestationRuleStatus.to_json())

# convert the object into a dict
compliant_attestation_rule_status_dict = compliant_attestation_rule_status_instance.to_dict()
# create an instance of CompliantAttestationRuleStatus from a dict
compliant_attestation_rule_status_from_dict = CompliantAttestationRuleStatus.from_dict(compliant_attestation_rule_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


