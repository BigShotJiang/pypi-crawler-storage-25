# NonCompliantAttestationRuleStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | The ID of the attestation rule. | 
**name** | **str** | The name of the attestation rule. | 

## Example

```python
from arthur_client.api_bindings.models.non_compliant_attestation_rule_status import NonCompliantAttestationRuleStatus

# TODO update the JSON string below
json = "{}"
# create an instance of NonCompliantAttestationRuleStatus from a JSON string
non_compliant_attestation_rule_status_instance = NonCompliantAttestationRuleStatus.from_json(json)
# print the JSON string representation of the object
print(NonCompliantAttestationRuleStatus.to_json())

# convert the object into a dict
non_compliant_attestation_rule_status_dict = non_compliant_attestation_rule_status_instance.to_dict()
# create an instance of NonCompliantAttestationRuleStatus from a dict
non_compliant_attestation_rule_status_from_dict = NonCompliantAttestationRuleStatus.from_dict(non_compliant_attestation_rule_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


