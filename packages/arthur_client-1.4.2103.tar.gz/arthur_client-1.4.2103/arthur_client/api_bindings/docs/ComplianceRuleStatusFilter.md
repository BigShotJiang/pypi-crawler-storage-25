# ComplianceRuleStatusFilter


## Enum

* `COMPLIANT` (value: `'COMPLIANT'`)

* `NON_COMPLIANT` (value: `'NON_COMPLIANT'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


