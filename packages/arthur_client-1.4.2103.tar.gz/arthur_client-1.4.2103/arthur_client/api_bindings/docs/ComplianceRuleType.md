# ComplianceRuleType


## Enum

* `ALERT_RULE` (value: `'alert_rule'`)

* `ATTESTATION_RULE` (value: `'attestation_rule'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


