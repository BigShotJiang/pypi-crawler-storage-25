import logging
logger = logging.getLogger(__name__)


validators = {}


def validator(conn_type, cls=None):
    def validator(cls):
        validators[conn_type] = cls
        return cls

    if cls:
        validators[conn_type] = cls

    return validator


class ConnectionValidator:
    def validate(self, conn):
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
            cursor.close()
        except Exception:
            return False
        return True

    def before_release(self, conn):
        try:
            conn.rollback()
            return True
        except Exception:
            logger.exception(f"Could not roll back {conn!r}")
            return False


try:
    from psycopg import Connection as psycopg_conn
    from psycopg import pq
except ImportError:
    pass
else:
    @validator(psycopg_conn)
    class PsycopgConnectionValidator(ConnectionValidator):
        def validate(self, conn: psycopg_conn):
            if conn.closed:
                return False
            info = conn.info

            if info.status != pq.ConnStatus.OK:
                return False

            T = pq.TransactionStatus
            tstatus = info.transaction_status

            if tstatus == T.IDLE:
                return True

            elif tstatus == T.INTRANS or tstatus == T.INERROR:
                conn.rollback()
                return True

            return False

        def before_release(self, conn):
            if conn.closed:
                return False

            T = pq.TransactionStatus
            tstatus = conn.info.transaction_status

            if tstatus == T.INTRANS or tstatus == T.INERROR:
                conn.rollback()
                return True
            elif tstatus == pq.TransactionStatus.IDLE:
                return True
            return False


try:
    from psycopg2 import extensions as psycopg2_ext
    from psycopg2.extensions import connection as psycopg2_conn
except ImportError:
    pass
else:

    @validator(psycopg2_conn)
    class Psycopg2ConnectionValidator(ConnectionValidator):
        def validate(self, conn):
            try:
                conn.isolation_level
            except Exception:
                return False
            return True

        def before_release(self, conn):
            if conn.closed:
                return False
            status = conn.info.transaction_status
            if status == psycopg2_ext.TRANSACTION_STATUS_UNKNOWN:
                return False
            elif status != psycopg2_ext.TRANSACTION_STATUS_IDLE:
                conn.rollback()
                return True
            return True


class MysqlConnectionValidator(ConnectionValidator):
    def validate(self, conn):
        try:
            conn.ping()
        except Exception:
            return False
        return True


try:
    from pymysql.connections import Connection as pymysql_conn
except ImportError:
    pass
else:
    validator(pymysql_conn, MysqlConnectionValidator)

try:
    from MySQLdb.connections import Connection as mysqldb_conn
except ImportError:
    pass
else:
    validator(mysqldb_conn, MysqlConnectionValidator)
