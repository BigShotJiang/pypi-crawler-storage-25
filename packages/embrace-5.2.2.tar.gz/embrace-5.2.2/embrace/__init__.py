#  Copyright 2020 Oliver Cope
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

__all__ = [
    "Module",
    "Query",
    "joinone",
    "joinmany",
    "one_to_one",
    "one_to_many",
    "mapobject",
]

from .module import Module
from .query import Query
from .query import joinone
from .query import joinmany
from .query import one_to_one
from .query import one_to_many
from .mapobject import mapobject

__version__ = "5.2.2"
