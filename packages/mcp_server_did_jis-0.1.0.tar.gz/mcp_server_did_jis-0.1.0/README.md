# mcp-server-did-jis — DEPRECATED

This package is deprecated and no longer maintained.

Use [mcp-server-jis](https://pypi.org/project/mcp-server-jis/) instead:

```bash
pip install mcp-server-jis
```
