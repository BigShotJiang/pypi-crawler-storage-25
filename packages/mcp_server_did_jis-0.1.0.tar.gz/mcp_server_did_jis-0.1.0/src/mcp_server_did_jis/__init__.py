"""
mcp-server-did-jis — DEPRECATED
================================

This package is deprecated and no longer maintained.
Use 'mcp-server-jis' instead: pip install mcp-server-jis

See: https://humotica.com
"""

import warnings

warnings.warn(
    "mcp-server-did-jis is deprecated and no longer maintained. "
    "Use 'mcp-server-jis' instead: pip install mcp-server-jis",
    DeprecationWarning,
    stacklevel=2,
)

__version__ = "0.1.0"
