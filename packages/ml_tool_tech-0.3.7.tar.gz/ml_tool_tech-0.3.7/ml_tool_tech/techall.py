from ml_tool_tech._parser import PRACTICALS
from ml_tool_tech._core import _save_to_notebook
from IPython import get_ipython

_NOTEBOOK = "ml_practicals.ipynb"

# Save all practicals to notebook file (each as its own cell)
for prac_num, code in sorted(PRACTICALS.items(), key=lambda x: str(x[0])):
    _save_to_notebook(code, prac_num, _NOTEBOOK)

# Build one combined cell with all code separated by headers
combined = ""
for prac_num, code in sorted(PRACTICALS.items(), key=lambda x: str(x[0])):
    combined += f"# ==================== PRACTICAL {prac_num} ====================\n"
    combined += code.strip() + "\n\n"

ip = get_ipython()
if ip is not None:
    ip.set_next_input(combined.strip(), replace=False)
    print(f"[ml_tool_tech] All {len(PRACTICALS)} practicals injected into next cell and saved to '{_NOTEBOOK}'")
else:
    print(combined)
