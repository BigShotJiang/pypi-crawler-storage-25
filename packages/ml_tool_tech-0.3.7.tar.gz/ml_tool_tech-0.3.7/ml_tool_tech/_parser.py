import json
import os

_CODES_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "codes.json")

def _load_practicals():
    with open(_CODES_PATH, "r", encoding="utf-8") as f:
        raw = json.load(f)
    # Convert keys: numeric strings -> int, others stay as string (e.g. "4b")
    practicals = {}
    for k, v in raw.items():
        try:
            practicals[int(k)] = v
        except ValueError:
            practicals[k] = v
    return practicals

PRACTICALS = _load_practicals()
