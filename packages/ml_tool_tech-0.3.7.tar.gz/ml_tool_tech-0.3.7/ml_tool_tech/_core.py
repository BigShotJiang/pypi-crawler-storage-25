import json
import os
import datetime

def _is_colab():
    try:
        import google.colab
        return True
    except ImportError:
        return False

def _inject_to_colab(code: str, prac_num):
    """Inject code into the next cell of the current Colab notebook."""
    from IPython import get_ipython
    ip = get_ipython()
    if ip is None:
        print(code)
        return

    # Display the code in a new cell and auto-execute setup
    ip.set_next_input(code, replace=False)
    print(f"[ml_tool_tech] Code for Practical {prac_num} injected into next cell.")

def _save_to_notebook(code: str, prac_num, notebook_path: str):
    """Append/create a .ipynb notebook with the practical code as a cell."""
    if os.path.exists(notebook_path):
        with open(notebook_path, "r", encoding="utf-8") as f:
            nb = json.load(f)
    else:
        nb = {
            "nbformat": 4,
            "nbformat_minor": 5,
            "metadata": {
                "kernelspec": {
                    "display_name": "Python 3",
                    "language": "python",
                    "name": "python3"
                },
                "language_info": {"name": "python", "version": "3.x"}
            },
            "cells": []
        }

    # Add a markdown header cell
    header_cell = {
        "cell_type": "markdown",
        "metadata": {},
        "source": [f"## Practical {prac_num}"],
        "id": f"prac_{prac_num}_header"
    }

    # Add the code cell
    code_cell = {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": code.splitlines(keepends=True),
        "id": f"prac_{prac_num}_code"
    }

    # Avoid duplicate cells
    existing_ids = [c.get("id") for c in nb["cells"]]
    if header_cell["id"] not in existing_ids:
        nb["cells"].append(header_cell)
        nb["cells"].append(code_cell)

    with open(notebook_path, "w", encoding="utf-8") as f:
        json.dump(nb, f, indent=2)

    print(f"[ml_tool_tech] Practical {prac_num} saved to '{notebook_path}'")

def load_practical(prac_num, notebook_name="ml_practicals.ipynb"):
    from ml_tool_tech._parser import PRACTICALS

    code = PRACTICALS.get(prac_num)
    if code is None:
        available = list(PRACTICALS.keys())
        raise ValueError(f"Practical {prac_num} not found. Available: {available}")

    # Inject into Colab next cell
    _inject_to_colab(code, prac_num)

    # Save to notebook
    _save_to_notebook(code, prac_num, notebook_name)

    return code
