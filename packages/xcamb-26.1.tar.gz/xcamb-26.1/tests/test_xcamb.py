from datetime import datetime
from io import StringIO
from unittest import TestCase
from unittest.mock import patch
from contextlib import redirect_stdout

import xcamb
from xcamb._client import PtaxNotFoundError


USD_ROWS = {
    "value": [
        {
            "cotacaoVenda": 4.9922,
            "dataHoraCotacao": "2026-04-16 10:11:26.052",
            "tipoBoletim": "Abertura",
        },
        {
            "cotacaoVenda": 5.0007,
            "dataHoraCotacao": "2026-04-16 13:03:28.563",
            "tipoBoletim": "Fechamento PTAX",
        },
    ]
}


EUR_ROWS = {
    "value": [
        {
            "cotacaoVenda": 5.8823,
            "dataHoraCotacao": "2026-04-16 10:11:26.052",
            "tipoBoletim": "Abertura",
        },
        {
            "cotacaoVenda": 5.8923,
            "dataHoraCotacao": "2026-04-16 13:03:28.563",
            "tipoBoletim": "Fechamento PTAX",
        },
    ]
}


class XCambTests(TestCase):
    def test_help_returns_and_prints_usage(self):
        buffer = StringIO()
        with redirect_stdout(buffer):
            text = xcamb.help()

        self.assertIn("xcamb 26.1", text)
        self.assertIn("xcamb.cotacao", text)
        self.assertEqual(buffer.getvalue().strip(), text.strip())

    @patch("xcamb._client._request_json", return_value=USD_ROWS)
    def test_cotacao_returns_closing_sale_quote_for_usd(self, _mock_request):
        data = datetime(2026, 4, 16, 15, 0, 0)
        self.assertEqual(xcamb.cotacao("USD", data), 5.0007)

    @patch("xcamb._client._request_json", return_value=USD_ROWS)
    def test_cotacao_accepts_lowercase_currency(self, _mock_request):
        data = datetime(2026, 4, 16, 15, 0, 0)
        self.assertEqual(xcamb.cotacao("usd", data), 5.0007)

    @patch("xcamb._client._request_json", return_value=EUR_ROWS)
    def test_cotacao_accepts_currency_stored_in_variable(self, _mock_request):
        codigo = "eur"
        data = datetime(2026, 4, 16, 15, 0, 0)
        self.assertEqual(xcamb.cotacao(codigo, data), 5.8923)

    def test_raises_for_invalid_currency(self):
        data = datetime(2026, 4, 16, 15, 0, 0)
        with self.assertRaises(ValueError):
            xcamb.cotacao("BRL", data)

    @patch("xcamb._client._request_json", return_value={"value": []})
    def test_raises_when_no_quote_exists(self, _mock_request):
        with self.assertRaises(PtaxNotFoundError):
            xcamb.cotacao("USD", datetime(2026, 4, 19, 12, 0, 0))

    def test_raises_when_date_is_not_datetime(self):
        with self.assertRaises(TypeError):
            xcamb.cotacao("USD", "2026-04-16")
