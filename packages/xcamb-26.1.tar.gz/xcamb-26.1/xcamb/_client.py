"""Consulta cotacoes PTAX do Banco Central do Brasil."""

from datetime import date, datetime
import json
from typing import Any, Dict, Iterable, List
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


BASE_URL = (
    "https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/"
    "CotacaoMoedaDia(moeda=@moeda,dataCotacao=@dataCotacao)"
)

SUPPORTED_CURRENCIES = {"USD", "GBP", "EUR"}
SALE_FIELD = "cotacaoVenda"
CLOSING_TYPES = {"Fechamento PTAX", "Fechamento"}
HELP_TEXT = """xcamb 26.1

Uso:
from datetime import datetime
import xcamb

data = datetime(2026, 4, 16, 12, 0, 0)

xcamb.cotacao("USD", data)
xcamb.cotacao("gbp", data)

codigo = "EUR"
xcamb.cotacao(codigo, data)

Regras:
- moedas suportadas: USD, GBP, EUR
- a moeda deve ser uma string
- a data deve ser datetime.datetime
- o retorno e a cotacao de venda PTAX do Banco Central
"""


class XCambError(Exception):
    """Erro base da biblioteca."""


class PtaxNotFoundError(XCambError):
    """Lancado quando nao ha PTAX disponivel para a data informada."""


def cotacao(moeda: str, data: datetime) -> float:
    """Retorna a cotacao PTAX de venda para a moeda informada.

    Args:
        moeda: Codigo da moeda como ``USD``, ``GBP`` ou ``EUR``.
        data: Data desejada em ``datetime.datetime``.

    Returns:
        Valor da cotacao PTAX como ``float``.
    """

    normalized_currency = _normalize_currency(moeda)
    normalized_datetime = _normalize_datetime(data)
    rows = _fetch_quotes(normalized_currency, normalized_datetime.date())
    quote = _select_quote(rows)
    return float(quote[SALE_FIELD])


def help() -> str:
    """Mostra como usar a biblioteca."""

    print(HELP_TEXT)
    return HELP_TEXT


def _normalize_currency(value: str) -> str:
    if not isinstance(value, str):
        raise TypeError("A moeda deve ser uma string.")

    code = value.strip().upper()
    if not code:
        raise ValueError("A moeda informada esta vazia.")

    if code not in SUPPORTED_CURRENCIES:
        supported = ", ".join(sorted(SUPPORTED_CURRENCIES))
        raise ValueError(f"Moeda invalida. Use uma destas opcoes: {supported}.")

    return code


def _normalize_datetime(value: datetime) -> datetime:
    if not isinstance(value, datetime):
        raise TypeError("A data deve ser datetime.datetime.")

    return value


def _fetch_quotes(moeda: str, data_cotacao: date) -> List[Dict[str, Any]]:
    query = urlencode(
        {
            "@moeda": f"'{moeda}'",
            "@dataCotacao": f"'{data_cotacao.strftime('%m-%d-%Y')}'",
            "$format": "json",
        }
    )
    url = f"{BASE_URL}?{query}"
    payload = _request_json(url)
    rows = payload.get("value", [])

    if not rows:
        formatted_date = data_cotacao.strftime("%d/%m/%Y")
        raise PtaxNotFoundError(
            f"Nao ha cotacao PTAX disponivel para {moeda} em {formatted_date}. "
            "Isso pode acontecer em fins de semana e feriados."
        )

    return rows


def _request_json(url: str) -> Dict[str, Any]:
    request = Request(
        url,
        headers={
            "Accept": "application/json",
            "User-Agent": "xcamb/26.1",
        },
    )

    try:
        with urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        raise XCambError(f"Erro HTTP ao consultar PTAX: {exc.code}") from exc
    except URLError as exc:
        raise XCambError(f"Erro de rede ao consultar PTAX: {exc.reason}") from exc
    except json.JSONDecodeError as exc:
        raise XCambError("Resposta invalida recebida do servico PTAX.") from exc


def _select_quote(rows: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    items = list(rows)
    closing_quotes = [item for item in items if item.get("tipoBoletim") in CLOSING_TYPES]

    if closing_quotes:
        return max(closing_quotes, key=_quote_timestamp)

    return max(items, key=_quote_timestamp)


def _quote_timestamp(row: Dict[str, Any]) -> datetime:
    raw_value = row.get("dataHoraCotacao")
    if not raw_value:
        return datetime.min

    return datetime.strptime(str(raw_value), "%Y-%m-%d %H:%M:%S.%f")
