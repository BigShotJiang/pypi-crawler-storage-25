# xcamb

Biblioteca Python para consultar a PTAX oficial de USD, GBP e EUR usando o servico PTAX do Banco Central do Brasil.

## Instalacao

```bash
pip install .
```

## Uso

```python
from datetime import datetime
import xcamb

data = datetime(2026, 4, 16)

xcamb.cotacao("USD", data)
# 5.0007

moeda = "gbp"
xcamb.cotacao(moeda, data)
# cotacao da Libra esterlina no dia

xcamb.cotacao("EUR", data)
# 5.8923

xcamb.help()
# mostra um guia rapido de uso
```

## Regras da biblioteca

- `xcamb.cotacao(moeda, data)` retorna a cotacao de venda da moeda no dia informado.
- As moedas suportadas sao `USD`, `GBP` e `EUR`.
- O codigo da moeda pode ser informado em maiusculas ou minusculas.
- A moeda precisa ser uma `str`, inclusive quando vier de uma variavel.
- A data precisa ser um `datetime.datetime`.
- A biblioteca prioriza o boletim `Fechamento PTAX`. Se ele ainda nao existir no dia consultado, retorna o boletim mais recente disponivel.
- Compatibilidade minima: Python 3.8.

## Exemplo com variavel

```python
from datetime import datetime
import xcamb

codigo = "eur"
data = datetime(2026, 4, 16, 12, 0, 0)

valor = xcamb.cotacao(codigo, data)
```

## Fonte oficial

- Banco Central do Brasil, servico PTAX: <https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/documentacao>
