"""
database/connection.py
Менеджер подключения к MySQL + все запросы к БД.
autocommit=True — иначе MySQL (REPEATABLE READ) показывает устаревшие данные.
"""
import mysql.connector
from obuvstore import config

_connection = None


def get_connection():
    global _connection
    if _connection is None or not _connection.is_connected():
        _connection = mysql.connector.connect(
            host=config.DB_HOST,
            port=config.DB_PORT,
            user=config.DB_USER,
            password=config.DB_PASSWORD,
            database=config.DB_NAME,
            charset="utf8mb4",
            autocommit=True,          # ← ВАЖНО: свежие данные при каждом SELECT
        )
        print(f"[obuvstore] Подключено к MySQL: {config.DB_HOST}/{config.DB_NAME}")
    return _connection


def close_connection():
    global _connection
    if _connection and _connection.is_connected():
        _connection.close()
        _connection = None


def execute_query(sql: str, params: tuple = (), fetch: bool = False):
    """fetch=True → список строк (SELECT); иначе → lastrowid (INSERT/UPDATE/DELETE)."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute(sql, params)
        if fetch:
            return cursor.fetchall()
        conn.commit()
        return cursor.lastrowid
    finally:
        cursor.close()


# ═══════════════ ПОЛЬЗОВАТЕЛИ ═══════════════

def get_user_by_login(login: str, password: str):
    rows = execute_query(
        "SELECT u.*, r.role_name FROM users u "
        "JOIN roles r ON u.role_id = r.role_id "
        "WHERE u.login=%s AND u.password=%s LIMIT 1",
        (login, password), fetch=True
    )
    return rows[0] if rows else None


def get_all_clients():
    """Список авторизированных клиентов (для создания заказа)."""
    return execute_query(
        "SELECT u.user_id, u.full_name, u.login FROM users u "
        "JOIN roles r ON u.role_id = r.role_id "
        "WHERE r.role_name = 'Авторизированный клиент' "
        "ORDER BY u.full_name",
        fetch=True
    )


# ═══════════════ ТОВАРЫ ═══════════════

def get_all_categories():
    return execute_query(
        "SELECT category_id, category_name FROM categories ORDER BY category_name",
        fetch=True
    )


def get_all_products(search: str = "", sort_by: str = "name", sort_dir: str = "ASC"):
    conditions, params = ["p.is_active=1"], []
    if search:
        conditions.append("(p.name LIKE %s OR p.brand LIKE %s OR p.article LIKE %s)")
        like = f"%{search}%"
        params += [like, like, like]
    where = " AND ".join(conditions)
    allowed = {"name", "price", "discount", "stock", "brand", "article"}
    col = sort_by if sort_by in allowed else "name"
    direction = "DESC" if str(sort_dir).upper() == "DESC" else "ASC"
    sql = (f"SELECT p.*, c.category_name FROM products p "
           f"LEFT JOIN categories c ON p.category_id = c.category_id "
           f"WHERE {where} ORDER BY p.{col} {direction}")
    return execute_query(sql, tuple(params), fetch=True)


def add_product(article, name, category_id, brand, price, discount, stock):
    return execute_query(
        "INSERT INTO products (article,name,category_id,brand,price,discount,stock) "
        "VALUES (%s,%s,%s,%s,%s,%s,%s)",
        (article, name, category_id, brand, price, discount, stock)
    )


def update_product(product_id, article, name, category_id, brand, price, discount, stock):
    execute_query(
        "UPDATE products SET article=%s, name=%s, category_id=%s, brand=%s, "
        "price=%s, discount=%s, stock=%s WHERE product_id=%s",
        (article, name, category_id, brand, price, discount, stock, product_id)
    )


def delete_product(product_id: int):
    """Мягкое удаление — товар скрывается, но история заказов сохраняется."""
    execute_query("UPDATE products SET is_active=0 WHERE product_id=%s", (product_id,))


# ═══════════════ ПУНКТЫ ВЫДАЧИ ═══════════════

def get_all_pickup_points():
    return execute_query(
        "SELECT point_id, address FROM pickup_points ORDER BY point_id",
        fetch=True
    )


# ═══════════════ ЗАКАЗЫ ═══════════════

def get_all_orders():
    return execute_query(
        "SELECT o.*, u.full_name, u.login, pp.address AS point_address "
        "FROM orders o "
        "JOIN users u ON o.user_id = u.user_id "
        "LEFT JOIN pickup_points pp ON o.point_id = pp.point_id "
        "ORDER BY o.order_id DESC",
        fetch=True
    )


def get_next_order_num():
    rows = execute_query(
        "SELECT COALESCE(MAX(order_num), 0) + 1 AS n FROM orders",
        fetch=True
    )
    return rows[0]["n"] if rows else 1


def add_order(order_num, user_id, point_id, order_date,
              delivery_date, pickup_code, status):
    return execute_query(
        "INSERT INTO orders "
        "(order_num,user_id,point_id,order_date,delivery_date,pickup_code,status) "
        "VALUES (%s,%s,%s,%s,%s,%s,%s)",
        (order_num, user_id, point_id, order_date,
         delivery_date, pickup_code, status)
    )


def update_order(order_id, user_id, point_id, order_date,
                 delivery_date, pickup_code, status):
    execute_query(
        "UPDATE orders SET user_id=%s, point_id=%s, order_date=%s, "
        "delivery_date=%s, pickup_code=%s, status=%s WHERE order_id=%s",
        (user_id, point_id, order_date, delivery_date,
         pickup_code, status, order_id)
    )


def update_order_status(order_id: int, status: str):
    execute_query(
        "UPDATE orders SET status=%s WHERE order_id=%s",
        (status, order_id)
    )


def delete_order(order_id: int):
    execute_query("DELETE FROM orders WHERE order_id=%s", (order_id,))
