"""
ui/main_window.py — Главное окно ИС «ООО Обувь»

Разделение ролей (строго по ТЗ):
  Гость                    — товары БЕЗ фильтра/сортировки/поиска
  Авторизированный клиент  — товары БЕЗ фильтра/сортировки/поиска
  Менеджер                 — товары С фильтром/сортировкой/поиском; заказы (только просмотр)
  Администратор            — товары: просмотр+фильтр+CRUD; заказы: просмотр+CRUD
"""
import os
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget,
    QTableWidgetItem, QLabel, QLineEdit, QPushButton, QComboBox,
    QHeaderView, QAction, QToolBar, QStatusBar, QMessageBox,
    QDialog, QFormLayout, QDoubleSpinBox, QSpinBox, QTabWidget,
    QSizePolicy, QDateEdit, QAbstractItemView
)
from PyQt5.QtCore import Qt, QSize, QDate
from PyQt5.QtGui import QIcon, QColor, QPixmap

from obuvstore import config
from obuvstore.ui.styles import DISCOUNT_ROW_COLOR, DISCOUNT_ROW_TEXT
from obuvstore.database import connection as db

# Роли, которым доступны расширенные возможности
_ROLES_WITH_FILTER = ("Менеджер", "Администратор")
_ROLE_ADMIN = "Администратор"


# ═══════════════════════════════════════════════════════════════
#  ДИАЛОГ: добавление / редактирование ТОВАРА
# ═══════════════════════════════════════════════════════════════
class ProductDialog(QDialog):
    def __init__(self, product: dict = None, parent=None):
        super().__init__(parent)
        self.product = product
        self.setWindowTitle(
            "Новый товар" if not product
            else f"Редактирование товара: {product.get('name', '')}"
        )
        self.setMinimumWidth(420)
        self._categories = db.get_all_categories()
        self._build()

    def _build(self):
        layout = QFormLayout(self)
        layout.setSpacing(10)

        self.article_edit = QLineEdit(
            self.product.get("article", "") if self.product else ""
        )
        self.name_edit = QLineEdit(
            self.product.get("name", "") if self.product else ""
        )
        self.brand_edit = QLineEdit(
            self.product.get("brand", "") if self.product else ""
        )

        self.cat_combo = QComboBox()
        self.cat_combo.addItem("— не выбрана —", None)
        for c in self._categories:
            self.cat_combo.addItem(c["category_name"], c["category_id"])
        if self.product and self.product.get("category_id"):
            idx = self.cat_combo.findData(self.product["category_id"])
            if idx >= 0:
                self.cat_combo.setCurrentIndex(idx)

        self.price_spin = QDoubleSpinBox()
        self.price_spin.setRange(0, 9999999)
        self.price_spin.setDecimals(2)
        self.price_spin.setSuffix(" ₽")
        self.price_spin.setValue(
            float(self.product["price"]) if self.product else 0.0
        )

        self.disc_spin = QDoubleSpinBox()
        self.disc_spin.setRange(0, 100)
        self.disc_spin.setDecimals(1)
        self.disc_spin.setSuffix(" %")
        self.disc_spin.setValue(
            float(self.product["discount"]) if self.product else 0.0
        )

        self.stock_spin = QSpinBox()
        self.stock_spin.setRange(0, 999999)
        self.stock_spin.setValue(
            int(self.product["stock"]) if self.product else 0
        )

        layout.addRow("Артикул:",   self.article_edit)
        layout.addRow("Название:",  self.name_edit)
        layout.addRow("Бренд:",     self.brand_edit)
        layout.addRow("Категория:", self.cat_combo)
        layout.addRow("Цена:",      self.price_spin)
        layout.addRow("Скидка:",    self.disc_spin)
        layout.addRow("Остаток:",   self.stock_spin)

        btn_row = QHBoxLayout()
        btn_ok = QPushButton("Сохранить")
        btn_ok.setObjectName("btnAccent")
        btn_ok.clicked.connect(self._on_save)
        btn_cancel = QPushButton("Отмена")
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_ok)
        btn_row.addWidget(btn_cancel)
        layout.addRow(btn_row)

    def _on_save(self):
        if not self.article_edit.text().strip():
            QMessageBox.warning(self, "Проверка", "Укажите артикул.")
            return
        if not self.name_edit.text().strip():
            QMessageBox.warning(self, "Проверка", "Укажите название товара.")
            return
        self.accept()

    def get_data(self) -> dict:
        return {
            "article":     self.article_edit.text().strip(),
            "name":        self.name_edit.text().strip(),
            "brand":       self.brand_edit.text().strip(),
            "category_id": self.cat_combo.currentData(),
            "price":       self.price_spin.value(),
            "discount":    self.disc_spin.value(),
            "stock":       self.stock_spin.value(),
        }


# ═══════════════════════════════════════════════════════════════
#  ДИАЛОГ: добавление / редактирование ЗАКАЗА
# ═══════════════════════════════════════════════════════════════
class OrderDialog(QDialog):
    STATUSES = ["Новый", "В обработке", "Выполнен", "Завершен", "Отменён"]

    def __init__(self, order: dict = None, parent=None):
        super().__init__(parent)
        self.order = order
        self.setWindowTitle(
            "Новый заказ" if not order
            else f"Редактирование заказа №{order.get('order_num', '')}"
        )
        self.setMinimumWidth(460)
        self._clients = db.get_all_clients()
        self._points = db.get_all_pickup_points()
        self._build()

    def _build(self):
        layout = QFormLayout(self)
        layout.setSpacing(10)

        # Клиент
        self.client_combo = QComboBox()
        for c in self._clients:
            self.client_combo.addItem(c["full_name"], c["user_id"])
        if self.order and self.order.get("user_id"):
            idx = self.client_combo.findData(self.order["user_id"])
            if idx >= 0:
                self.client_combo.setCurrentIndex(idx)

        # Пункт выдачи
        self.point_combo = QComboBox()
        self.point_combo.addItem("— не выбран —", None)
        for p in self._points:
            self.point_combo.addItem(p["address"], p["point_id"])
        if self.order and self.order.get("point_id"):
            idx = self.point_combo.findData(self.order["point_id"])
            if idx >= 0:
                self.point_combo.setCurrentIndex(idx)

        # Дата заказа
        self.order_date = QDateEdit()
        self.order_date.setCalendarPopup(True)
        self.order_date.setDisplayFormat("yyyy-MM-dd")
        self.order_date.setDate(self._parse_date(
            self.order.get("order_date") if self.order else None
        ))

        # Дата доставки
        self.delivery_date = QDateEdit()
        self.delivery_date.setCalendarPopup(True)
        self.delivery_date.setDisplayFormat("yyyy-MM-dd")
        self.delivery_date.setDate(self._parse_date(
            self.order.get("delivery_date") if self.order else None
        ))

        # Код получения
        self.code_edit = QLineEdit(
            str(self.order.get("pickup_code", "")) if self.order else ""
        )

        # Статус
        self.status_combo = QComboBox()
        self.status_combo.addItems(self.STATUSES)
        if self.order and self.order.get("status"):
            idx = self.status_combo.findText(self.order["status"])
            if idx >= 0:
                self.status_combo.setCurrentIndex(idx)

        layout.addRow("Клиент:",        self.client_combo)
        layout.addRow("Пункт выдачи:",  self.point_combo)
        layout.addRow("Дата заказа:",   self.order_date)
        layout.addRow("Дата доставки:", self.delivery_date)
        layout.addRow("Код получения:", self.code_edit)
        layout.addRow("Статус:",        self.status_combo)

        btn_row = QHBoxLayout()
        btn_ok = QPushButton("Сохранить")
        btn_ok.setObjectName("btnAccent")
        btn_ok.clicked.connect(self._on_save)
        btn_cancel = QPushButton("Отмена")
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_ok)
        btn_row.addWidget(btn_cancel)
        layout.addRow(btn_row)

    @staticmethod
    def _parse_date(value):
        """Преобразует значение из БД в QDate. По умолчанию — сегодня."""
        if value is None:
            return QDate.currentDate()
        try:
            s = str(value)[:10]
            qd = QDate.fromString(s, "yyyy-MM-dd")
            return qd if qd.isValid() else QDate.currentDate()
        except Exception:
            return QDate.currentDate()

    def _on_save(self):
        if self.client_combo.currentData() is None:
            QMessageBox.warning(self, "Проверка", "Выберите клиента.")
            return
        self.accept()

    def get_data(self) -> dict:
        return {
            "user_id":       self.client_combo.currentData(),
            "point_id":      self.point_combo.currentData(),
            "order_date":    self.order_date.date().toString("yyyy-MM-dd"),
            "delivery_date": self.delivery_date.date().toString("yyyy-MM-dd"),
            "pickup_code":   self.code_edit.text().strip(),
            "status":        self.status_combo.currentText(),
        }


# ═══════════════════════════════════════════════════════════════
#  ВКЛАДКА: ТОВАРЫ
# ═══════════════════════════════════════════════════════════════
class ProductsTab(QWidget):
    COLUMNS = ["ID", "Артикул", "Название", "Бренд",
               "Категория", "Цена", "Скидка %", "Остаток"]

    def __init__(self, role: str, parent=None):
        super().__init__(parent)
        self.role = role
        self.products = []
        self.search_edit = None
        self.sort_combo = None
        self._build()
        self.refresh()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        # Заголовок формы (требование ТЗ)
        title = QLabel("Каталог товаров")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        # Фильтр / сортировка / поиск — только менеджер и администратор
        if self.role in _ROLES_WITH_FILTER:
            flt = QHBoxLayout()
            self.search_edit = QLineEdit()
            self.search_edit.setPlaceholderText("Поиск по названию, бренду, артикулу…")
            self.search_edit.textChanged.connect(self.refresh)

            self.sort_combo = QComboBox()
            self.sort_combo.addItems([
                "Название (А-Я)", "Название (Я-А)",
                "Цена (возр.)", "Цена (убыв.)",
                "Скидка (убыв.)",
            ])
            self.sort_combo.currentIndexChanged.connect(self.refresh)

            flt.addWidget(QLabel("Поиск:"))
            flt.addWidget(self.search_edit, 3)
            flt.addWidget(QLabel("Сортировка:"))
            flt.addWidget(self.sort_combo, 2)
            layout.addLayout(flt)

        # Таблица
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(self.table)

        # Кнопки CRUD — только администратор
        if self.role == _ROLE_ADMIN:
            btns = QHBoxLayout()
            btn_add  = QPushButton("Добавить")
            btn_edit = QPushButton("Редактировать")
            btn_del  = QPushButton("Удалить")
            btn_del.setObjectName("btnDanger")
            btn_add.clicked.connect(self._add)
            btn_edit.clicked.connect(self._edit)
            btn_del.clicked.connect(self._delete)
            btns.addWidget(btn_add)
            btns.addWidget(btn_edit)
            btns.addWidget(btn_del)
            btns.addStretch()
            layout.addLayout(btns)

    def refresh(self):
        search = ""
        sort_by, sort_dir = "name", "ASC"
        if self.role in _ROLES_WITH_FILTER and self.search_edit is not None:
            search = self.search_edit.text()
            mapping = [
                ("name", "ASC"), ("name", "DESC"),
                ("price", "ASC"), ("price", "DESC"),
                ("discount", "DESC"),
            ]
            idx = self.sort_combo.currentIndex()
            if 0 <= idx < len(mapping):
                sort_by, sort_dir = mapping[idx]

        try:
            self.products = db.get_all_products(
                search=search, sort_by=sort_by, sort_dir=sort_dir
            )
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", f"Не удалось загрузить товары:\n{e}")
            self.products = []

        self.table.setRowCount(0)
        for row_idx, p in enumerate(self.products):
            self.table.insertRow(row_idx)
            values = [
                str(p.get("product_id", "")),
                str(p.get("article") or ""),
                str(p.get("name") or ""),
                str(p.get("brand") or ""),
                str(p.get("category_name") or ""),
                f"{float(p.get('price') or 0):.2f} ₽",
                f"{float(p.get('discount') or 0):.1f}%",
                str(p.get("stock") or 0),
            ]
            for col, val in enumerate(values):
                item = QTableWidgetItem(val)
                item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(row_idx, col, item)

            # Подсветка строки при скидке > 15% (требование ТЗ)
            if float(p.get("discount") or 0) > 15:
                for col in range(len(self.COLUMNS)):
                    cell = self.table.item(row_idx, col)
                    cell.setBackground(QColor(DISCOUNT_ROW_COLOR))
                    cell.setForeground(QColor(DISCOUNT_ROW_TEXT))

    def _selected_product(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.products):
            QMessageBox.warning(self, "Выбор", "Выберите товар в таблице.")
            return None
        return self.products[row]

    def _add(self):
        dlg = ProductDialog(parent=self)
        if dlg.exec_() == QDialog.Accepted:
            d = dlg.get_data()
            try:
                db.add_product(d["article"], d["name"], d["category_id"],
                               d["brand"], d["price"], d["discount"], d["stock"])
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось добавить товар:\n{e}")
                return
            self.refresh()

    def _edit(self):
        p = self._selected_product()
        if not p:
            return
        dlg = ProductDialog(product=p, parent=self)
        if dlg.exec_() == QDialog.Accepted:
            d = dlg.get_data()
            try:
                db.update_product(p["product_id"], d["article"], d["name"],
                                  d["category_id"], d["brand"], d["price"],
                                  d["discount"], d["stock"])
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить:\n{e}")
                return
            self.refresh()

    def _delete(self):
        p = self._selected_product()
        if not p:
            return
        reply = QMessageBox.question(
            self, "Подтверждение удаления",
            f"Удалить товар «{p.get('name', '')}»?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            try:
                db.delete_product(p["product_id"])
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось удалить:\n{e}")
                return
            self.refresh()


# ═══════════════════════════════════════════════════════════════
#  ВКЛАДКА: ЗАКАЗЫ
# ═══════════════════════════════════════════════════════════════
class OrdersTab(QWidget):
    COLUMNS = ["№", "Клиент", "Статус", "Пункт выдачи",
               "Дата заказа", "Дата доставки", "Код"]

    def __init__(self, role: str, parent=None):
        super().__init__(parent)
        self.role = role
        self.orders = []
        self._build()
        self.refresh()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        title = QLabel("Заказы")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(self.table)

        # CRUD заказов — только администратор. Менеджер видит таблицу без кнопок.
        if self.role == _ROLE_ADMIN:
            btns = QHBoxLayout()
            btn_add  = QPushButton("Добавить")
            btn_edit = QPushButton("Редактировать")
            btn_del  = QPushButton("Удалить")
            btn_del.setObjectName("btnDanger")
            btn_add.clicked.connect(self._add)
            btn_edit.clicked.connect(self._edit)
            btn_del.clicked.connect(self._delete)
            btns.addWidget(btn_add)
            btns.addWidget(btn_edit)
            btns.addWidget(btn_del)
            btns.addStretch()
            layout.addLayout(btns)

    def refresh(self):
        try:
            self.orders = db.get_all_orders()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", f"Не удалось загрузить заказы:\n{e}")
            self.orders = []

        self.table.setRowCount(0)
        for i, o in enumerate(self.orders):
            self.table.insertRow(i)
            vals = [
                str(o.get("order_num") or o.get("order_id", "—")),
                str(o.get("full_name") or o.get("login") or "—"),
                str(o.get("status") or "—"),
                str(o.get("point_address") or "—"),
                str(o.get("order_date") or "—"),
                str(o.get("delivery_date") or "—"),
                str(o.get("pickup_code") or "—"),
            ]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(val)
                item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i, col, item)

    def _selected_order(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.orders):
            QMessageBox.warning(self, "Выбор", "Выберите заказ в таблице.")
            return None
        return self.orders[row]

    def _add(self):
        dlg = OrderDialog(parent=self)
        if dlg.exec_() == QDialog.Accepted:
            d = dlg.get_data()
            try:
                num = db.get_next_order_num()
                db.add_order(num, d["user_id"], d["point_id"],
                             d["order_date"], d["delivery_date"],
                             d["pickup_code"], d["status"])
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось создать заказ:\n{e}")
                return
            self.refresh()

    def _edit(self):
        o = self._selected_order()
        if not o:
            return
        dlg = OrderDialog(order=o, parent=self)
        if dlg.exec_() == QDialog.Accepted:
            d = dlg.get_data()
            try:
                db.update_order(o["order_id"], d["user_id"], d["point_id"],
                                d["order_date"], d["delivery_date"],
                                d["pickup_code"], d["status"])
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить заказ:\n{e}")
                return
            self.refresh()

    def _delete(self):
        o = self._selected_order()
        if not o:
            return
        reply = QMessageBox.question(
            self, "Подтверждение удаления",
            f"Удалить заказ №{o.get('order_num', '')}?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            try:
                db.delete_order(o["order_id"])
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось удалить заказ:\n{e}")
                return
            self.refresh()


# ═══════════════════════════════════════════════════════════════
#  ГЛАВНОЕ ОКНО
# ═══════════════════════════════════════════════════════════════
class MainWindow(QMainWindow):
    def __init__(self, user: dict = None):
        super().__init__()
        self.user = user
        self.role = user["role_name"] if user else "Гость"
        self.setWindowTitle(f"{config.WINDOW_TITLE} — {self.role}")
        self.setMinimumSize(config.WINDOW_MIN_W, config.WINDOW_MIN_H)
        if os.path.exists(config.ICON_APP):
            self.setWindowIcon(QIcon(config.ICON_APP))
        self._build_menu()
        self._build_toolbar()
        self._build_central()
        self._build_statusbar()

    def _build_menu(self):
        menubar = self.menuBar()

        file_menu = menubar.addMenu("Файл")
        act_exit = QAction("Выход", self)
        act_exit.setShortcut("Ctrl+Q")
        act_exit.triggered.connect(self.close)
        file_menu.addAction(act_exit)

        if self.role != "Гость":
            data_menu = menubar.addMenu("Данные")
            act_refresh = QAction("Обновить", self)
            act_refresh.setShortcut("F5")
            act_refresh.triggered.connect(self._refresh_current)
            data_menu.addAction(act_refresh)

        help_menu = menubar.addMenu("Справка")
        act_about = QAction("О программе", self)
        act_about.triggered.connect(self._show_about)
        help_menu.addAction(act_about)

    def _build_toolbar(self):
        tb = QToolBar("Главная панель")
        tb.setIconSize(QSize(24, 24))
        tb.setMovable(False)
        self.addToolBar(tb)

        # Логотип на главной форме (требование ТЗ — не искажать пропорции)
        if os.path.exists(config.LOGO_FILE):
            logo = QLabel()
            pix = QPixmap(config.LOGO_FILE).scaledToHeight(
                32, Qt.SmoothTransformation
            )
            logo.setPixmap(pix)
            logo.setStyleSheet("padding: 0 10px;")
            tb.addWidget(logo)
            tb.addSeparator()

        if self.role != "Гость":
            act_refresh = QAction("Обновить", self)
            act_refresh.triggered.connect(self._refresh_current)
            tb.addAction(act_refresh)
            tb.addSeparator()

        act_exit = QAction("Выход", self)
        act_exit.triggered.connect(self.close)
        tb.addAction(act_exit)

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)

        name = self.user["full_name"] if self.user else "Гость"
        user_label = QLabel(f"{name}   |   {self.role}")
        user_label.setStyleSheet("padding-right: 12px; font-weight: bold;")
        tb.addWidget(user_label)

    def _build_central(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # Товары — доступны всем (гость, клиент, менеджер, администратор)
        self.products_tab = ProductsTab(role=self.role)
        self.tabs.addTab(self.products_tab, "Товары")

        # Заказы — только менеджер и администратор
        if self.role in _ROLES_WITH_FILTER:
            self.orders_tab = OrdersTab(role=self.role)
            self.tabs.addTab(self.orders_tab, "Заказы")
        else:
            self.orders_tab = None

    def _build_statusbar(self):
        sb = QStatusBar()
        self.setStatusBar(sb)
        sb.addPermanentWidget(QLabel(f"Роль: {self.role}"))
        sb.showMessage("Добро пожаловать в ИС «ООО Обувь»", 5000)

    def _refresh_current(self):
        widget = self.tabs.currentWidget()
        if widget is not None and hasattr(widget, "refresh"):
            widget.refresh()

    def _show_about(self):
        QMessageBox.information(
            self, "О программе",
            f"{config.WINDOW_TITLE}\n"
            "Информационная система магазина обуви\n\n"
            f"Текущая роль: {self.role}\n"
            f"Сервер БД: {config.DB_HOST}:{config.DB_PORT}\n"
            f"База данных: {config.DB_NAME}"
        )
