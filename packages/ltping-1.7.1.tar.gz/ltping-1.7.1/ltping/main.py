# -*- coding: utf-8 -*-
"""
ltping OSS — CLI entry point.

PRO features (Prometheus, CDN, MTU, MOS, TLS inspect, traceroute detail,
webhook alerting, baseline comparison, histogram merge):
    pip install ltping-pro  —  https://latencetech.com
"""
import argparse
import sys
import time
from datetime import datetime, timezone
from tqdm import tqdm
from ltping import config, __version__
from ltping.i18n import get_translator
from ltping.core import (
    mesurer_site, sauvegarder_csv,
    creer_histogramme, hdr_enregistrer, hdr_stats,
    verifier_slo,
    est_adresse_ip,
    SLO_UNITES,
)

# HTTP assertions are a PRO feature — available when ltping-engine is installed
try:
    from ltping_engine.http import verifier_assertions as _verifier_assertions
except ImportError:
    _verifier_assertions = None

# ── ANSI colours (disabled when not a TTY) ────────────────────────────────────
def _ansi(code): return "\033[" + code + "m" if sys.stdout.isatty() else ""
VERT   = _ansi("92")
ORANGE = _ansi("33")
ROUGE  = _ansi("91")
RESET  = _ansi("0")

t = get_translator(config.LANGUAGE)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _heure_scan():
    local = datetime.now().astimezone()
    utc   = datetime.now(timezone.utc)
    return f"{local.strftime('%H:%M')} {local.strftime('%Z')} / {utc.strftime('%H:%M')} UTC"


def _couleur_slo(ok: bool) -> str:
    return VERT if ok else ROUGE


# ── Output ────────────────────────────────────────────────────────────────────

def afficher_resultat(r: dict, slo: dict, asserts: dict, args) -> None:
    """Print a single site result."""
    url = r["url"]

    if r["erreur"]:
        print(f"\n{ROUGE}✗ {url}{RESET}")
        print(f"  [{r.get('type_erreur', '?')}] {r.get('message', '')}")
        return

    # SLO checks
    slo_checks = verifier_slo(r, slo) if slo else {}
    slo_ok     = all(c["ok"] for c in slo_checks.values()) if slo_checks else True
    badge      = f"{VERT}✓{RESET}" if slo_ok else f"{ROUGE}✗{RESET}"

    print(f"\n{badge} {url}")

    # HTTP percentiles
    print(f"  HTTP  p50={r['p50']}ms  p95={r['p95']}ms  p99={r['p99']}ms  "
          f"max={r['max']}ms  avg={r['moyenne']}ms")

    # DNS — reuse existing i18n key
    if r.get("dns_moyenne") is not None:
        print(t('dns', v=r['dns_moyenne'],
                min=r.get('dns_min') or '?', max=r.get('dns_max') or '?'))

    # SLO violations
    if slo_checks:
        for cle, c in slo_checks.items():
            unite = SLO_UNITES.get(cle, "ms")
            couleur = VERT if c["ok"] else ROUGE
            symbol  = "✓" if c["ok"] else "✗"
            print(f"  {couleur}{symbol} SLO {cle}: {c['valeur']}{unite} {c['op']} {c['seuil']}{unite}{RESET}")

    # Assertion checks (PRO feature — requires ltping-engine)
    if asserts:
        if _verifier_assertions is None:
            print(f"  {ORANGE}ℹ HTTP assertions require ltping-pro → pip install ltping-pro{RESET}")
        else:
            checks = _verifier_assertions(url, asserts)
            if "_erreur" in checks:
                print(f"  {ROUGE}⚠ assert error: {checks['_erreur']}{RESET}")
            else:
                for cle, c in checks.items():
                    couleur = VERT if c["ok"] else ROUGE
                    symbol  = "✓" if c["ok"] else "✗"
                    print(f"  {couleur}{symbol} assert {cle}: got {c['recu']} (expected {c['attendu']}){RESET}")

    # PRO upsell hint (shown once per run, not per site)
    if args.verbose:
        print(f"  {ORANGE}ℹ PRO: --prometheus --cdn --mtu --traceroute-detail --webhook → ltping-pro{RESET}")


def afficher_resume(resultats: list, slo_global: dict) -> None:
    """Print a summary table."""
    ok_count  = sum(1 for r in resultats if not r.get("erreur"))
    err_count = len(resultats) - ok_count
    print(f"\n{'─'*60}")
    print(f"  {len(resultats)} site(s)  "
          f"{VERT}{ok_count} OK{RESET}  {ROUGE if err_count else ''}{err_count} error(s){RESET}")
    if slo_global:
        viol = sum(
            1 for r in resultats
            if not r.get("erreur") and
            any(not c["ok"] for c in verifier_slo(r, slo_global).values())
        )
        if viol:
            print(f"  {ROUGE}⚠ {viol} SLO violation(s){RESET}")
    print(f"{'─'*60}")


# ── Argument parsing ──────────────────────────────────────────────────────────

def parse_arguments():
    pre = argparse.ArgumentParser(add_help=False)
    pre.add_argument("--config-file", default=None)
    pre_args, _ = pre.parse_known_args()
    cfg = config.charger(pre_args.config_file)

    parser = argparse.ArgumentParser(
        prog="ltping",
        description="HTTP/DNS latency tool with SLO validation — OSS edition (AGPL-3.0)\n"
                    "PRO: pip install ltping-pro  |  https://latencetech.com",
    )
    parser.add_argument("--version", action="version", version=f"ltping {__version__}")
    parser.add_argument("--config-file", default=None, metavar="FILE",
                        help=f"YAML config file (default: {config.FICHIER_DEFAUT})")
    parser.add_argument("sites", nargs="*",
                        help="Sites to measure (e.g. https://example.com)")
    parser.add_argument("-n", "--nombre", type=int, default=cfg["nb_measures"],
                        help="Measurements per site (default: %(default)s)")
    parser.add_argument("--sites-file", default=None, metavar="FILE",
                        help=f"YAML file with site list (default: {config.FICHIER_SITES_DEFAUT})")
    parser.add_argument("--csv", action="store_true",
                        help="Save results to CSV")
    parser.add_argument("--timeout", type=int, default=cfg["timeout"],
                        help="Request timeout in seconds (default: %(default)s)")
    parser.add_argument("--interval", type=int, default=None, metavar="SECONDS",
                        help="Repeat measurements every N seconds (Ctrl-C to stop)")
    parser.add_argument("--language", default=cfg.get("language", "EN"),
                        choices=["FR", "EN", "ES", "DE", "JA", "ZH", "PT"],
                        help="Output language (default: %(default)s)")
    parser.add_argument("--verbose", action="store_true",
                        help="Show PRO feature hints")
    return parser.parse_args()


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    global t
    args = parse_arguments()
    cfg  = config.charger(args.config_file)
    t    = get_translator(args.language.upper())

    # Sites loading priority: CLI args > --sites-file > sites.yaml > config sites:
    if args.sites:
        sites = [{"url": u} for u in args.sites]
    else:
        sites = config.charger_sites(args.sites_file)
        if not sites:
            sites = cfg.get("sites", config.SITES_DEFAUT)

    if not sites:
        print(f"{ROUGE}No sites to measure. Add URLs in sites.yaml or pass them as arguments.{RESET}")
        sys.exit(1)

    nb      = args.nombre
    timeout = args.timeout
    scan    = 0

    print(t("header", ver=__version__, n=nb, cfg=args.config_file or config.FICHIER_DEFAUT))

    try:
        while True:
            scan += 1
            if args.interval:
                print(f"\n{'═'*60}")
                print(f"  Scan #{scan}  —  {_heure_scan()}")
                print(f"{'═'*60}")

            resultats = []
            for site in tqdm(sites, desc="Measuring", unit="site", leave=False):
                url    = site["url"] if isinstance(site, dict) else site
                slo    = site.get("slo", {}) if isinstance(site, dict) else {}
                asserts = site.get("assert", {}) if isinstance(site, dict) else {}

                r = mesurer_site(url, nb_mesures=nb, timeout=timeout)

                # Attach SLO checks to result for summary
                r["slo_checks"] = verifier_slo(r, slo) if slo and not r["erreur"] else {}

                afficher_resultat(r, slo, asserts, args)
                resultats.append(r)

            afficher_resume(resultats, {})

            if args.csv:
                fichier = sauvegarder_csv(resultats)
                print(f"  CSV saved → {fichier}")

            if not args.interval:
                break

            print(f"\n  Next scan in {args.interval}s — Ctrl-C to stop")
            time.sleep(args.interval)

    except KeyboardInterrupt:
        print(f"\n\n{ORANGE}Stopped by user.{RESET}")
        if scan >= 2:
            print(f"  {scan} scans completed.")


if __name__ == "__main__":
    main()
