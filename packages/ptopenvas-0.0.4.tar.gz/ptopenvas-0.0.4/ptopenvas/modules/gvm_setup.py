import os
import json
import secrets
import string
import subprocess
import sys
import grp

from gvm.transforms import EtreeCheckCommandTransform
from gvm.connections import UnixSocketConnection
from gvm.protocols.gmp import Gmp
from gvm.errors import GvmError

from ptlibs.app_dirs import AppDirs
from ptlibs import ptjsonlib
from ptlibs.ptprinthelper import ptprint

class GVMSetup:
    
    PASSWORD_FILE = os.path.join(AppDirs("ptopenvas").get_base_dir(), "gvm.pass")
    USERNAME = "penterep"
    REQUIRED_SERVICES = ("gvmd", "ospd-openvas")
    OPTIONAL_SERVICES = ("notus-scanner",)
    WEB_SERVICE = "gsad"
    WEB_URL = "https://127.0.0.1:9392"
    
    def __init__(self, args={}) -> None:    
        self.args = args

    def _json_output(self) -> bool:
        return bool(getattr(self.args, "json", False))

    def _print(self, message: str):
        if not self._json_output():
            print(message)

    def _subprocess_output_kwargs(self) -> dict:
        if self._json_output():
            return {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
        return {}

    def run(self) -> bool:
        """
        Main function to ensure dependencies and GVM setup.
        Returns True if everything is ready.
        """
        # 1. Install GVM and ensure initialization
        self.install_gvm() # ensure gvm is installed
        self.ensure_gvmd_initialized() # run gvm-setup

        # 2. Ensure GVMD service is running
        self.run_gvmd_daemon()
        self.run_web_daemon()

        # 3. Finalize permissions
        self.finalize_permissions()
        
        # 4. Ensure penterep user exists (creates with random password if needed)
        self.ensure_penterep_user()

        return True
    
    def install_gvm(self) -> bool:
        """
        Verifies if the 'gvm' package is installed.
        Installs it if missing.
        """

        # Check installation state
        try:
            subprocess.run(
                ["dpkg", "-s", "gvm"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=True
            )
            return True

        except subprocess.CalledProcessError:
            #print("Package 'gvm' is missing. Installing...")
            try:
                ptprint('Run "apt update"', "INFO", condition=not getattr(self.args, "json", False), colortext=True)
                subprocess.run(["sudo", "apt", "update"], check=True, **self._subprocess_output_kwargs())
                ptprint('Run "apt install -y gvm"', "INFO", condition=not getattr(self.args, "json", False), colortext=True)
                subprocess.run(["sudo", "apt", "install", "-y", "gvm"], check=True, **self._subprocess_output_kwargs())
                #print("Package 'gvm' installed successfully.")
                return True

            except subprocess.CalledProcessError as e:
                self._print(f"Failed to install 'gvm': {e}")
                return False

    def ensure_gvmd_initialized(self) -> bool:
        """
        Ensure GVMD is initialized by running `gvm-setup` if needed.

        This checks for the GVMD Unix socket at `/run/gvmd/gvmd.sock` and
        runs `gvm-setup` only when initialization appears required.
        """
        # 1) Check if GVMD database exists
        try:
            db_check = subprocess.run(
                ["sudo", "-u", "postgres", "psql", "-tAc", "SELECT 1 FROM pg_database WHERE datname='gvmd'"],
                #["-u", "postgres", "psql", "-tAc", "SELECT 1 FROM pg_database WHERE datname='gvmd'"],
                capture_output=True, text=True, check=True
            )
            if db_check.stdout.strip() == "1":
                #print("GVM setup was already completed previously.")
                return True
        except Exception:
            pass

        # If database missing -> setup never ran
        try:
            ptprint("First run - preparing environment", "INFO", condition=not getattr(self.args, "json", False), colortext=True)
            ptprint('Run "gvm-setup"', "INFO", condition=not getattr(self.args, "json", False), colortext=True)
            subprocess.run(["sudo", "gvm-setup"], check=True, **self._subprocess_output_kwargs())
            self._print("GVMD initialization completed successfully.")
            return True
        except subprocess.CalledProcessError as e:
            self._print(f"GVMD initialization failed: {e}")
            return False

    def run_gvmd_daemon(self):
        """
        Ensure that the GVM backend services are running.
        Starts only services required for GMP/OpenVAS scans, without gsad/web UI.
        """
        try:
            services_to_start = []
            for service in self.REQUIRED_SERVICES:
                status = subprocess.run(["systemctl", "is-active", "--quiet", service])
                if status.returncode != 0:
                    services_to_start.append(service)
            for service in self.OPTIONAL_SERVICES:
                if self._systemd_service_exists(service):
                    status = subprocess.run(["systemctl", "is-active", "--quiet", service])
                    if status.returncode != 0:
                        services_to_start.append(service)

            if services_to_start:
                ptprint(f"Start GVM backend services: {', '.join(self.REQUIRED_SERVICES)}", "INFO", condition=not getattr(self.args, "json", False), colortext=True)
                self._print("GVM backend services are not running. Starting required services...")
                subprocess.run(
                    ["sudo", "systemctl", "start", *self.REQUIRED_SERVICES],
                    check=True,
                    **self._subprocess_output_kwargs()
                )
                self._start_optional_services()
                self._print("GVM backend services started.")
        except subprocess.CalledProcessError as e:
            self._print(f"Failed to start GVM backend services: {e}")
            sys.exit(1)

    def _start_optional_services(self):
        for service in self.OPTIONAL_SERVICES:
            if self._systemd_service_exists(service):
                try:
                    ptprint(f"Start optional GVM service: {service}", "INFO", condition=not getattr(self.args, "json", False), colortext=True)
                    subprocess.run(
                        ["sudo", "systemctl", "start", service],
                        check=True,
                        **self._subprocess_output_kwargs()
                    )
                except subprocess.CalledProcessError as e:
                    self._print(f"Optional GVM service '{service}' was not started: {e}")

    def run_web_daemon(self):
        """
        Start the GVM web UI service only when explicitly requested.
        """
        if not getattr(self.args, "with_web", False):
            return
        if not self._systemd_service_exists(self.WEB_SERVICE):
            self._print(f"GVM web service '{self.WEB_SERVICE}' is not available.")
            return
        try:
            ptprint(f"Start GVM web service: {self.WEB_SERVICE}", "INFO", condition=not getattr(self.args, "json", False), colortext=True)
            subprocess.run(
                ["sudo", "systemctl", "start", self.WEB_SERVICE],
                check=True,
                **self._subprocess_output_kwargs()
            )
            self._print("GVM web service started.")
            self._open_web_ui()
        except subprocess.CalledProcessError as e:
            self._print(f"Failed to start GVM web service: {e}")

    def _open_web_ui(self):
        try:
            subprocess.Popen(
                ["xdg-open", self.WEB_URL],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception as e:
            self._print(f"Failed to open GVM web UI: {e}")

    def _systemd_service_exists(self, service):
        status = subprocess.run(
            ["systemctl", "show", "-p", "LoadState", "--value", f"{service}.service"],
            capture_output=True,
            text=True,
        )
        return status.returncode == 0 and status.stdout.strip() not in ("", "not-found")

    def ensure_penterep_user(self):
        """
        Ensure gvmd service is running and the 'penterep' admin user exists.
        If the user does not exist, create it with a random password stored in PASSWORD_FILE.
        If the provided admin password is wrong, it will be reset automatically.
        """

        # 1. Define admin username and get password
        USERNAME = self.USERNAME
        PASSWORD = self.get_password() # "admin"

        self._create_user_if_needed(username=USERNAME, password=PASSWORD)

        # 2. Determine password for penterep
        if not PASSWORD:
            alphabet = string.ascii_letters + string.digits
            PASSWORD = ''.join(secrets.choice(alphabet) for _ in range(24))
            with open(self.PASSWORD_FILE, "w") as f:
                f.write(PASSWORD)

        # 3. Connect to gvmd and create user if missing
        conn = UnixSocketConnection(path="/run/gvmd/gvmd.sock")
        try:
            with Gmp(conn, transform=EtreeCheckCommandTransform()) as gmp:
                try:
                    gmp.authenticate(USERNAME, PASSWORD)
                except GvmError as e:
                    try:
                        subprocess.run([
                            "sudo", "-u", "_gvm", "gvmd",
                            "--user=penterep",
                            f"--new-password={PASSWORD}"
                        ], check=True, capture_output=True)
                        #print(f"Reset penterep password to '{PASSWORD}'")
                    except Exception as e:
                        self._print(f"Failed to reset penterep password: {e}")
                        sys.exit(1)


        except PermissionError:
            self._print("Please reset your shell (log out and log back in) before running scripts that access GVMD.")
            sys.exit(1)
        except GvmError as e:
            self._print(f"Failed to create user: {e}")
            sys.exit(1)


    def _create_user_if_needed(self, username, password):
        r = subprocess.run([
            "sudo", "-u", "_gvm", "gvmd",
            "--get-users"
            ], check=True, capture_output=True)

        available_users = [u for u in r.stdout.decode().split("\n") if u]
        #print("Available_users:\n   ", '\n    '.join(available_users))

        if username not in available_users:
            try:
                # Create admin user
                subprocess.run([
                    "sudo", "-u", "_gvm", "gvmd",
                    "--create-user="+username,
                    "--password="+password,
                ], check=True, capture_output=True)
                self._print(f"Created admin user '{username}' with password '{password}'")
            except Exception as e:
                self._print(f"Failed to create user '{username}': {e}")
                return


    def get_password(self, generate: bool = False) -> str:
        """
        Return the stored password from PASSWORD_FILE.
        If the file is missing or empty, or generate=True, create a new password, save it, and return it.
        """
        def generate_password() -> str:
            charset = string.ascii_letters + string.digits
            new_pass = ''.join(secrets.choice(charset) for _ in range(32))
            with open(self.PASSWORD_FILE, "w") as f:
                f.write(new_pass)
            return new_pass

        # Generate a new password if requested or if the file is missing/empty
        if generate or not os.path.exists(self.PASSWORD_FILE):
            return generate_password()

        # Read existing password
        with open(self.PASSWORD_FILE, "r") as f:
            existing_pass = f.read().strip()

        # If file is empty, generate a new password
        if not existing_pass:
            return generate_password()

        return existing_pass

    def _get_stored_password(self):
        if not os.path.exists(self.PASSWORD_FILE):
            return None
        with open(self.PASSWORD_FILE, "r") as f:
            password = f.read().strip()
        return password or None

    def print_credentials(self):
        password = self._get_stored_password()
        if not password:
            message = f"Password file does not exist or is empty: {self.PASSWORD_FILE}"
            if self._json_output():
                ptjsonlib.PtJsonLib().end_error(message, True)
            else:
                print(message)
            return False

        credentials = {
            "username": self.USERNAME,
            "password": password,
            "passwordFile": self.PASSWORD_FILE,
        }
        if self._json_output():
            result_json = ptjsonlib.PtJsonLib()
            result_json.add_properties(credentials)
            result_json.set_status("finished")
            print(result_json.get_result_json())
        else:
            print(f"Username: {credentials['username']}")
            print(f"Password: {credentials['password']}")
            print(f"Password file: {credentials['passwordFile']}")
        return True

    def reset_environment(self):
        if self._json_output():
            ptjsonlib.PtJsonLib().end_error("Reset requires interactive confirmation and cannot run with --json.", True)

        answer = input(
            "Are you sure? This will stop GVM services, drop PostgreSQL database "
            f"\"gvmd\", and remove password file \"{self.PASSWORD_FILE}\". [y/N] "
        )
        if answer.lower() != "y":
            print("Reset cancelled.")
            return False

        services = (self.WEB_SERVICE, *self.REQUIRED_SERVICES, *self.OPTIONAL_SERVICES)
        for service in services:
            if self._systemd_service_exists(service):
                ptprint(f'Stop GVM service: {service}', "INFO", condition=not getattr(self.args, "json", False), colortext=True)
                try:
                    subprocess.run(["sudo", "systemctl", "stop", service], check=True)
                except subprocess.CalledProcessError as e:
                    print(f"Failed to stop GVM service '{service}': {e}")
                    return False

        ptprint('Drop PostgreSQL database "gvmd"', "INFO", condition=not getattr(self.args, "json", False), colortext=True)
        try:
            subprocess.run(["sudo", "-u", "postgres", "dropdb", "--if-exists", "gvmd"], check=True)
        except subprocess.CalledProcessError as e:
            print(f"Failed to drop PostgreSQL database 'gvmd': {e}")
            return False

        if os.path.exists(self.PASSWORD_FILE):
            ptprint(f'Remove password file: {self.PASSWORD_FILE}', "INFO", condition=not getattr(self.args, "json", False), colortext=True)
            try:
                os.remove(self.PASSWORD_FILE)
            except OSError as e:
                print(f"Failed to remove password file '{self.PASSWORD_FILE}': {e}")
                return False

        print("Reset finished. Next normal run should execute first-run setup again.")
        return True


    def finalize_permissions(self):
        """
        Add the current user to the _gvm group so the Python script can access the GVMD socket.
        The user must reset their shell for the group change to take effect.
        """
        user = os.environ.get("USER")
        if not user:
            self._print("Could not determine the current user.")
            return

        # Check membership
        try:
            group = grp.getgrnam("_gvm")
        except KeyError:
            self._print("Group '_gvm' does not exist.")
            return
        
        if user in group.gr_mem:
            #print(f"User '{user}' is already a member of the _gvm group. No action taken.")
            return

        try:
            subprocess.run(["sudo", "usermod", "-aG", "_gvm", user], check=True, **self._subprocess_output_kwargs())
            self._print(f"User '{user}' has been added to the _gvm group.")
        except subprocess.CalledProcessError as e:
            self._print(f"Failed to add user to _gvm group: {e}")


if __name__ == "__main__":
    gvm = GVMSetup(args={})
    gvm.run()
