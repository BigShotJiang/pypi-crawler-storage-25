# Copyright 2018-2026 contributors to the OpenLineage project
# SPDX-License-Identifier: Apache-2.0


import attr
from openlineage.client.facet_v2 import (
    BaseFacet,
    JobFacet,
    parent_run,
)
from openlineage.common.schema import GITHUB_LOCATION  # type: ignore[attr-defined]


@attr.define
class ParentRunMetadata:
    run_id: str
    job_name: str
    job_namespace: str
    root_parent_job_name: str | None = attr.field(default=None)
    root_parent_job_namespace: str | None = attr.field(default=None)
    root_parent_run_id: str | None = attr.field(default=None)

    def to_openlineage(self) -> parent_run.ParentRunFacet:
        root = None
        if self.root_parent_run_id and self.root_parent_job_namespace and self.root_parent_job_name:
            root = parent_run.Root(
                run=parent_run.RootRun(runId=self.root_parent_run_id),
                job=parent_run.RootJob(
                    namespace=self.root_parent_job_namespace, name=self.root_parent_job_name
                ),
            )

        return parent_run.ParentRunFacet(
            run=parent_run.Run(runId=self.run_id),
            job=parent_run.Job(namespace=self.job_namespace, name=self.job_name),
            root=root,
        )


@attr.define
class DbtVersionRunFacet(BaseFacet):
    version: str

    @staticmethod
    def _get_schema() -> str:
        return GITHUB_LOCATION + "dbt-version-run-facet.json"


@attr.define
class DbtRunRunFacet(BaseFacet):
    invocation_id: str
    project_name: str | None = attr.field(default=None)
    dbt_runtime: str | None = attr.field(default=None)
    project_version: str | None = attr.field(default=None)
    profile_name: str | None = attr.field(default=None)
    account_id: str | None = attr.field(default=None)

    @staticmethod
    def _get_schema() -> str:
        return GITHUB_LOCATION + "dbt-run-run-facet.json"


@attr.define
class DbtNodeJobFacet(JobFacet):
    """Job facet containing dbt node metadata.

    This facet embeds information from the dbt manifest schema, specifically from the node
    properties as defined in the dbt manifest specification:
    https://schemas.getdbt.com/dbt/manifest/v12/index.html#nodes_additionalProperties

    The fields in this facet correspond to properties found in dbt manifest nodes, providing
    context about the dbt model/node being executed.
    """

    original_file_path: str | None = attr.field(default=None)
    database: str | None = attr.field(default=None)
    schema: str | None = attr.field(default=None)
    alias: str | None = attr.field(default=None)
    unique_id: str | None = attr.field(default=None)
    test_type: str | None = attr.field(default=None)

    @staticmethod
    def _get_schema() -> str:
        return GITHUB_LOCATION + "dbt-node-job-facet.json"
