# Copyright 2018-2026 contributors to the OpenLineage project
# SPDX-License-Identifier: Apache-2.0

import logging
import traceback
from typing import Any

import attr
from openlineage.client.facet_v2 import (
    BaseFacet,
    error_message_run,
    output_statistics_output_dataset,
)
from openlineage.common.dataset import Dataset, Source
from openlineage.common.models import DbColumn, DbTableSchema
from openlineage.common.sql import DbTableMeta


@attr.define
class RedshiftFacets:
    run_facets: dict[str, BaseFacet]
    inputs: list[Dataset]
    output: list[Dataset]


class RedshiftDataDatasetsProvider:
    def __init__(
        self,
        client,
        connection_details: dict[str, Any],
        logger: logging.Logger | None = None,
    ):
        if logger is None:
            self.logger: logging.Logger = logging.getLogger(__name__)
        else:
            self.logger = logger
        self.connection_details = connection_details
        self.client = client

    def get_facets(
        self, job_id: str, inputs: list[DbTableMeta], outputs: list[DbTableMeta]
    ) -> RedshiftFacets:
        ds_inputs: list[Dataset] = []
        ds_outputs: list[Dataset] = []
        run_facets: dict[str, BaseFacet] = {}
        dataset_stat_facet = None

        source = Source(
            scheme="redshift",
            authority=self._get_authority(),
        )
        try:
            properties = self.client.describe_statement(Id=job_id)
            dataset_stat_facet = self._get_output_statistics(properties)
        except Exception as e:
            self.logger.error(
                f"Cannot retrieve job details from Redshift Data client. {e}",
                exc_info=True,
            )
            run_facets.update(
                {
                    "errorMessage": error_message_run.ErrorMessageRunFacet(
                        message=f"Cannot retrieve job details from Redshift Data client. {e}",
                        programmingLanguage="PYTHON",
                        stackTrace=f"{e}: {traceback.format_exc()}",
                    )
                }
            )

        ds_inputs = self._get_dataset_from_tables(inputs, source)
        ds_outputs = self._get_dataset_from_tables(outputs, source)

        if dataset_stat_facet:
            for ds_output in ds_outputs:
                ds_output.custom_facets.update({"stats": dataset_stat_facet})

        return RedshiftFacets(run_facets, ds_inputs, ds_outputs)

    def _get_output_statistics(
        self, properties
    ) -> output_statistics_output_dataset.OutputStatisticsOutputDatasetFacet:
        return output_statistics_output_dataset.OutputStatisticsOutputDatasetFacet(
            rowCount=properties.get("ResultRows"),
            size=properties.get("ResultSize"),
        )

    def _get_dataset_from_tables(self, tables: list[DbTableMeta], source: Source) -> list[Dataset]:
        try:
            return [
                Dataset.from_table_schema(
                    source=source,
                    table_schema=table_schema,
                    database_name=self.connection_details.get("database"),
                )
                for table_schema in self._get_table_schemas(tables)
                if table_schema is not None
            ]
        except Exception as e:
            self.logger.warning(f"Could not extract schema from redshift. {e}")
            return [Dataset.from_table(source, table.name) for table in tables]

    def _get_authority(self) -> str:
        return f"{self.connection_details['cluster_identifier']}.{self.connection_details.get('region')}:5439"

    def _get_table_safely(self, output_table_name):
        try:
            return self._get_table(output_table_name)
        except Exception as e:
            self.logger.warning(f"Could not extract output schema from redshift. {e}")
        return None

    def _get_table_schemas(self, tables: list[DbTableMeta]) -> list[DbTableSchema]:
        if not tables:
            return []
        return [schema for table in tables if (schema := self._get_table(table)) is not None]

    def _get_table(self, table: DbTableMeta) -> DbTableSchema | None:
        kwargs: dict[str, Any] = {
            "ClusterIdentifier": self.connection_details.get("cluster_identifier"),
            "Database": table.database or self.connection_details.get("database"),
            "Table": table.name,
            "DbUser": self.connection_details.get("db_user"),
            "SecretArn": self.connection_details.get("secret_arn"),
            "Schema": table.schema,
        }
        filter_values = {key: val for key, val in kwargs.items() if val is not None}
        redshift_table = self.client.describe_table(**filter_values)
        fields = redshift_table.get("ColumnList")
        if not fields:
            return None
        schema_name = fields[0]["schemaName"]
        columns = [
            DbColumn(
                name=fields[i].get("name"),
                type=fields[i].get("typeName"),
                ordinal_position=i,
            )
            for i in range(len(fields))
        ]

        return DbTableSchema(
            schema_name=schema_name,
            table_name=DbTableMeta(redshift_table.get("TableName")),
            columns=columns,
        )
