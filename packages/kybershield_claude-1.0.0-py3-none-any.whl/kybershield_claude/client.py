"""KyberShield Claude SDK — screen Claude prompts/responses through KyberShield gateway."""

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import requests


@dataclass
class CheckResult:
    """Result from a KyberShield security check."""
    verdict: str                     # "allow" or "blocked"
    risk_score: int                  # 0-100
    reason: str
    quantum_signature: Optional[str] = None
    threats: List[str] = field(default_factory=list)
    timestamp: Optional[str] = None

    @property
    def allowed(self) -> bool:
        return self.verdict == "allow"

    @property
    def blocked(self) -> bool:
        return self.verdict == "blocked"

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "CheckResult":
        return cls(
            verdict=d.get("verdict", "allow"),
            risk_score=d.get("riskScore", 0),
            reason=d.get("reason", ""),
            quantum_signature=d.get("quantumSignature"),
            threats=d.get("threats", []),
            timestamp=d.get("timestamp"),
        )


@dataclass
class SecurityEvent:
    """A logged security event."""
    event_type: str
    details: Dict[str, Any]
    severity: str = "medium"
    event_id: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "SecurityEvent":
        return cls(
            event_type=d.get("eventType", ""),
            details=d.get("details", {}),
            severity=d.get("severity", "medium"),
            event_id=d.get("eventId"),
        )


class KyberShieldBlocked(Exception):
    """Raised when KyberShield blocks a prompt or response."""
    def __init__(self, message: str, result: CheckResult):
        super().__init__(message)
        self.result = result


class KyberShieldClaude:
    """
    KyberShield integration for Claude and Anthropic SDK.

    Wraps Claude API calls with KyberShield security checks on prompts and responses.

    Usage::

        from kybershield_claude import KyberShieldClaude
        import anthropic

        ks = KyberShieldClaude(agent_key="ks_your_key")
        client = anthropic.Anthropic()

        # Screen the prompt before sending to Claude
        ks.check_prompt("What is the schema of the users table?")

        message = client.messages.create(
            model="claude-opus-4-5",
            max_tokens=1024,
            messages=[{"role": "user", "content": "What is the schema of the users table?"}]
        )

        # Screen Claude's response before returning to user
        ks.check_response(message.content[0].text)
    """

    DEFAULT_GATEWAY_URL = "https://app.kybershield.ai"

    def __init__(
        self,
        agent_key: Optional[str] = None,
        gateway_url: Optional[str] = None,
        timeout: int = 10,
        raise_on_block: bool = True,
    ):
        self.agent_key = agent_key or os.environ.get("KYBERSHIELD_AGENT_KEY", "")
        self.gateway_url = (
            gateway_url or os.environ.get("KYBERSHIELD_GATEWAY_URL", self.DEFAULT_GATEWAY_URL)
        ).rstrip("/")
        self.timeout = timeout
        self.raise_on_block = raise_on_block
        self._session = requests.Session()
        self._session.headers.update(
            {"Content-Type": "application/json", "X-Agent-Key": self.agent_key}
        )
        if not self.agent_key:
            raise ValueError(
                "agent_key is required. Pass it or set KYBERSHIELD_AGENT_KEY env var."
            )

    def _post(self, endpoint: str, payload: Dict[str, Any]) -> CheckResult:
        resp = self._session.post(
            f"{self.gateway_url}/api/gateway/{endpoint}",
            json=payload,
            timeout=self.timeout,
        )
        data = resp.json()
        result = CheckResult.from_dict(data)
        if result.blocked and self.raise_on_block:
            raise KyberShieldBlocked(result.reason or "Blocked by KyberShield policy", result)
        return result

    def check_prompt(
        self,
        prompt: str,
        agent_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> CheckResult:
        """
        Screen a prompt before sending it to Claude.

        :raises KyberShieldBlocked: If the prompt is blocked (and raise_on_block=True).
        """
        return self._post(
            "check_prompt",
            {"prompt": prompt, "agentId": agent_id, "context": context},
        )

    def check_tool_call(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        agent_id: Optional[str] = None,
    ) -> CheckResult:
        """Validate a Claude tool_use call before executing it."""
        return self._post(
            "check_tool_call",
            {"toolName": tool_name, "arguments": arguments, "agentId": agent_id},
        )

    def check_response(
        self,
        response: str,
        agent_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> CheckResult:
        """
        Inspect a Claude response before delivering it to the user.

        :raises KyberShieldBlocked: If the response contains a policy violation.
        """
        return self._post(
            "check_response",
            {"response": response, "agentId": agent_id, "context": context},
        )

    def log_event(
        self,
        event_type: str,
        details: Dict[str, Any],
        severity: str = "medium",
    ) -> SecurityEvent:
        """Log a security event to the immutable KyberShield audit log."""
        resp = self._session.post(
            f"{self.gateway_url}/api/gateway/log_event",
            json={"eventType": event_type, "details": details, "severity": severity},
            timeout=self.timeout,
        )
        return SecurityEvent.from_dict(resp.json())

    def ping(self) -> bool:
        """Return True if the KyberShield gateway is reachable and healthy."""
        try:
            resp = self._session.get(f"{self.gateway_url}/api/gateway/health", timeout=5)
            return resp.json().get("status") == "healthy"
        except Exception:
            return False

    def __enter__(self) -> "KyberShieldClaude":
        return self

    def __exit__(self, *args: Any) -> None:
        self._session.close()
