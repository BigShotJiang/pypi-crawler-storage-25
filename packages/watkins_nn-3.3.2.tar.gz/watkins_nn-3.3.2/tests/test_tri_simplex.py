"""Tests for the tri_simplex module.

Tests cover:
- Result 1: Tri-Simplex Quality Theorem (THEOREM)
  - meta-trace = N for any N >= 1
  - normalized meta-trace = 1 for any N
  - polynomial tower identity at N = 3
  - conservation verification for individual simplexes
- Result 2: Retrocausal Entropy Conjecture (CONJECTURE)
  - H_eff formula: H_eff = H - lam * I(X;Y)
  - Classical limit: lam = 0 => H_eff = H
  - Maximum coupling: lam = 1, I = H => H_eff = 0
  - Boundedness: 0 <= H_eff <= H
  - Input validation
- Result 3: Empirical Compression Advantage (OBSERVATION)
  - Delta_rho = 0.025 (raw density difference)
  - lambda_empirical ~ 0.0391 (normalized: Delta_rho / rho_classical)
  - Density derivation consistency
  - Cross-check with H_eff formula
"""

import math
import pytest

from watkins_nn.constants import (
    PHI,
    PHI_INV,
    PHI_SQUARED,
    SQRT5,
    CONSERVATION_EPSILON,
)
from watkins_nn.tri_simplex import (
    # Constants
    PHI_BAR,
    PHI_BAR_SQUARED,
    TRACE_PHI2,
    NORM_PHI2,
    LAMBDA_EMPIRICAL,
    DELTA_RHO_EMPIRICAL,
    RHO_CLASSICAL,
    RHO_ZENITH,
    LAMBDA_FIREWALL,
    LAMBDA_PHASE_TRANSITION,
    LAMBDA_PARADOX,
    # Data classes
    SimplexState,
    TriSimplexResult,
    HEffResult,
    CompressionAdvantageResult,
    StabilityRegimeResult,
    CollectiveSyncResult,
    # Result 1
    tri_simplex_quality,
    meta_trace_identity,
    # Result 2
    H_eff,
    H_eff_classical_limit,
    H_eff_maximum_coupling,
    H_eff_ratio,
    # Result 3
    compression_advantage,
    lambda_from_densities,
    # Result 4
    stability_regime,
    collective_lambda,
    compression_from_lambda,
    lambda_from_compression,
    threshold_summary,
    # Report
    tri_simplex_report,
)


# =============================================================================
# MODULE CONSTANTS
# =============================================================================

class TestModuleConstants:

    def test_trace_phi2_is_3(self):
        """Tr(phi^2) = phi^2 + phi_bar^2 = 3 exactly."""
        assert abs(TRACE_PHI2 - 3.0) < CONSERVATION_EPSILON

    def test_norm_phi2_is_1(self):
        """Nm(phi^2) = phi^2 * phi_bar^2 = 1 exactly."""
        assert abs(NORM_PHI2 - 1.0) < CONSERVATION_EPSILON

    def test_phi_bar_is_conjugate(self):
        """phi_bar = (1 - sqrt5) / 2."""
        expected = (1 - SQRT5) / 2
        assert abs(PHI_BAR - expected) < 1e-15

    def test_phi_bar_squared(self):
        """phi_bar^2 = phi_bar * phi_bar."""
        assert abs(PHI_BAR_SQUARED - PHI_BAR ** 2) < 1e-15

    def test_lambda_empirical_value(self):
        """Lambda empirical = Delta_rho / rho_classical ~ 0.0391."""
        expected = 0.025 / 0.64
        assert abs(LAMBDA_EMPIRICAL - expected) < 1e-14

    def test_delta_rho_empirical_value(self):
        """Raw density difference = 0.025."""
        assert abs(DELTA_RHO_EMPIRICAL - 0.025) < 1e-14

    def test_density_values(self):
        """Measured density values."""
        assert RHO_CLASSICAL == 0.64
        assert RHO_ZENITH == 0.615


# =============================================================================
# SIMPLEX STATE
# =============================================================================

class TestSimplexState:

    def test_valid_state(self):
        s = SimplexState(0.5, 0.3, 0.2)
        assert abs(s.trace - 1.0) < 1e-14

    def test_equilibrium_state(self):
        lam = PHI_INV
        kap = (1 - lam) / 2
        eta = (1 - lam) / 2
        s = SimplexState(lam, kap, eta)
        assert abs(s.trace - 1.0) < 1e-14

    def test_components_tuple(self):
        s = SimplexState(0.5, 0.3, 0.2)
        assert s.components == (0.5, 0.3, 0.2)

    def test_invalid_state_raises(self):
        with pytest.raises(ValueError, match="Conservation violation"):
            SimplexState(0.5, 0.5, 0.5)

    def test_boundary_state(self):
        """Vertex of the simplex: (1, 0, 0)."""
        s = SimplexState(1.0, 0.0, 0.0)
        assert abs(s.trace - 1.0) < 1e-14


# =============================================================================
# RESULT 1: TRI-SIMPLEX QUALITY THEOREM
# =============================================================================

class TestTriSimplexQuality:

    def test_single_simplex_meta_trace_is_1(self):
        """For N=1 simplex, meta-trace = 1."""
        r = tri_simplex_quality([(0.5, 0.3, 0.2)])
        assert abs(r.meta_trace - 1.0) < CONSERVATION_EPSILON
        assert abs(r.normalized_meta_trace - 1.0) < CONSERVATION_EPSILON

    def test_two_simplexes_meta_trace_is_2(self):
        """For N=2 simplexes, meta-trace = 2."""
        r = tri_simplex_quality([
            (0.5, 0.3, 0.2),
            (0.1, 0.6, 0.3),
        ])
        assert abs(r.meta_trace - 2.0) < CONSERVATION_EPSILON
        assert abs(r.normalized_meta_trace - 1.0) < CONSERVATION_EPSILON

    def test_three_simplexes_meta_trace_is_3(self):
        """For N=3 simplexes, meta-trace = 3 = Tr(phi^2)."""
        r = tri_simplex_quality([
            (0.5, 0.3, 0.2),
            (0.1, 0.6, 0.3),
            (PHI_INV, (1 - PHI_INV) / 2, (1 - PHI_INV) / 2),
        ])
        assert abs(r.meta_trace - 3.0) < CONSERVATION_EPSILON
        assert abs(r.normalized_meta_trace - 1.0) < CONSERVATION_EPSILON
        assert r.is_polynomial_tower

    def test_meta_trace_equals_N_for_many(self):
        """meta-trace = N for N = 1..20."""
        base = (1.0 / 3, 1.0 / 3, 1.0 / 3)
        for N in range(1, 21):
            simplexes = [base] * N
            r = tri_simplex_quality(simplexes)
            assert abs(r.meta_trace - N) < CONSERVATION_EPSILON
            assert abs(r.normalized_meta_trace - 1.0) < CONSERVATION_EPSILON

    def test_normalized_always_1(self):
        """Normalized meta-trace is 1 regardless of simplex values."""
        import random
        random.seed(42)
        for _ in range(50):
            a = random.random()
            b = random.random() * (1 - a)
            c = 1 - a - b
            simplexes = [(a, b, c)] * random.randint(1, 10)
            r = tri_simplex_quality(simplexes)
            assert abs(r.normalized_meta_trace - 1.0) < 1e-10

    def test_polynomial_tower_only_at_N3(self):
        """is_polynomial_tower is True only when N = 3."""
        base = (0.5, 0.3, 0.2)
        for N in [1, 2, 4, 5, 10]:
            r = tri_simplex_quality([base] * N)
            assert not r.is_polynomial_tower

    def test_conservation_verified(self):
        r = tri_simplex_quality([
            (0.5, 0.3, 0.2),
            (PHI_INV, (1 - PHI_INV) / 2, (1 - PHI_INV) / 2),
        ])
        assert r.conservation_verified

    def test_equilibrium_triplet(self):
        """Three copies of the equilibrium state form the polynomial tower identity."""
        lam = PHI_INV
        kap = (1 - lam) / 2
        eta = (1 - lam) / 2
        r = tri_simplex_quality([(lam, kap, eta)] * 3)
        assert r.is_polynomial_tower
        assert r.conservation_verified
        assert abs(r.meta_trace - TRACE_PHI2) < CONSERVATION_EPSILON


class TestMetaTraceIdentity:

    def test_N_equals_1(self):
        r = meta_trace_identity(1)
        assert r['meta_trace'] == 1
        assert r['normalized_equals_1']

    def test_N_equals_3(self):
        r = meta_trace_identity(3)
        assert r['meta_trace'] == 3
        assert r['normalized_equals_1']
        assert r['polynomial_tower']['N_equals_trace']
        assert r['polynomial_tower']['meta_conservation']

    def test_N_equals_100(self):
        r = meta_trace_identity(100)
        assert r['meta_trace'] == 100
        assert r['normalized_equals_1']
        assert not r['polynomial_tower']['N_equals_trace']

    def test_invalid_N_raises(self):
        with pytest.raises(ValueError):
            meta_trace_identity(0)
        with pytest.raises(ValueError):
            meta_trace_identity(-1)

    def test_status_is_theorem(self):
        r = meta_trace_identity(3)
        assert r['status'] == 'THEOREM'

    def test_3_times_1_equals_3(self):
        """3 conservation laws x 1 each = 3."""
        r = meta_trace_identity(3)
        trace = r['polynomial_tower']['trace_phi2']
        norm = r['polynomial_tower']['norm_phi2']
        assert trace * norm == 3
        assert trace / trace == 1  # meta-conservation


# =============================================================================
# RESULT 2: RETROCAUSAL ENTROPY CONJECTURE
# =============================================================================

class TestHEff:

    def test_basic_computation(self):
        """H_eff = H - lam * I(X;Y) for a simple case."""
        r = H_eff(H=2.0, I_XY=1.0, lam=0.5)
        assert abs(r.H_eff - 1.5) < 1e-14
        assert r.status == "CONJECTURE"

    def test_classical_limit(self):
        """lam = 0 => H_eff = H (no coherence)."""
        r = H_eff_classical_limit(H=3.0, I_XY=2.0)
        assert abs(r.H_eff - 3.0) < 1e-14
        assert abs(r.lam - 0.0) < 1e-14

    def test_maximum_coupling(self):
        """lam = 1, I = H => H_eff = 0 (perfect coherence)."""
        r = H_eff_maximum_coupling(H=5.0)
        assert abs(r.H_eff - 0.0) < 1e-14

    def test_H_eff_is_bounded(self):
        """0 <= H_eff <= H for valid inputs."""
        for H_val in [0.5, 1.0, 2.0, 10.0]:
            for lam_val in [0.0, 0.25, 0.5, 0.75, 1.0]:
                for coupling in [0.0, 0.5, 1.0]:
                    I_val = coupling * H_val
                    r = H_eff(H=H_val, I_XY=I_val, lam=lam_val)
                    assert r.H_eff >= -1e-14, f"H_eff = {r.H_eff} < 0"
                    assert r.H_eff <= H_val + 1e-14, f"H_eff = {r.H_eff} > H = {H_val}"

    def test_ratio_at_empirical_lambda(self):
        """H_eff/H = 1 - lam at maximum coupling I/H = 1."""
        r = H_eff(H=1.0, I_XY=1.0, lam=LAMBDA_EMPIRICAL)
        expected_ratio = 1.0 - LAMBDA_EMPIRICAL
        assert abs(r.ratio - expected_ratio) < 1e-14

    def test_negative_H_raises(self):
        with pytest.raises(ValueError, match="Shannon entropy"):
            H_eff(H=-1.0, I_XY=0.5, lam=0.5)

    def test_negative_I_raises(self):
        with pytest.raises(ValueError, match="Mutual information"):
            H_eff(H=1.0, I_XY=-0.1, lam=0.5)

    def test_I_exceeds_H_raises(self):
        with pytest.raises(ValueError, match="exceeds"):
            H_eff(H=1.0, I_XY=2.0, lam=0.5)

    def test_invalid_lam_raises(self):
        with pytest.raises(ValueError, match="Coherence parameter"):
            H_eff(H=1.0, I_XY=0.5, lam=-0.1)
        with pytest.raises(ValueError, match="Coherence parameter"):
            H_eff(H=1.0, I_XY=0.5, lam=1.5)

    def test_ratio_when_H_is_zero(self):
        """When H = 0, ratio defaults to 1.0."""
        r = H_eff(H=0.0, I_XY=0.0, lam=0.5)
        assert abs(r.ratio - 1.0) < 1e-14
        assert abs(r.H_eff - 0.0) < 1e-14


class TestHEffRatio:

    def test_classical_ratio(self):
        """lam = 0 => ratio = 1."""
        assert abs(H_eff_ratio(0.0, 0.5) - 1.0) < 1e-14

    def test_full_coupling_ratio(self):
        """lam = 1, coupling = 1 => ratio = 0."""
        assert abs(H_eff_ratio(1.0, 1.0) - 0.0) < 1e-14

    def test_empirical_at_max_coupling(self):
        """lam ~ 0.0391, coupling = 1 => ratio ~ 0.9609."""
        ratio = H_eff_ratio(LAMBDA_EMPIRICAL, 1.0)
        assert abs(ratio - (1.0 - LAMBDA_EMPIRICAL)) < 1e-14

    def test_half_coupling(self):
        """lam = 0.5, coupling = 0.5 => ratio = 0.75."""
        assert abs(H_eff_ratio(0.5, 0.5) - 0.75) < 1e-14

    def test_invalid_inputs(self):
        with pytest.raises(ValueError):
            H_eff_ratio(-0.1, 0.5)
        with pytest.raises(ValueError):
            H_eff_ratio(0.5, -0.1)
        with pytest.raises(ValueError):
            H_eff_ratio(1.5, 0.5)
        with pytest.raises(ValueError):
            H_eff_ratio(0.5, 1.5)


# =============================================================================
# RESULT 3: EMPIRICAL COMPRESSION ADVANTAGE
# =============================================================================

class TestCompressionAdvantage:

    def test_delta_rho_is_0025(self):
        """Delta_rho = 0.64 - 0.615 = 0.025."""
        r = compression_advantage()
        assert abs(r.delta_rho - 0.025) < 1e-14

    def test_lambda_empirical_is_normalized(self):
        """lam = Delta_rho / rho_classical ~ 0.0391, not raw 0.025."""
        r = compression_advantage()
        expected = 0.025 / 0.64
        assert abs(r.lambda_empirical - expected) < 1e-14

    def test_densities(self):
        r = compression_advantage()
        assert abs(r.rho_classical - 0.64) < 1e-14
        assert abs(r.rho_zenith - 0.615) < 1e-14

    def test_H_eff_ratio_at_max_coupling(self):
        """H_eff/H = 1 - lam at maximum coupling."""
        r = compression_advantage()
        expected = 1.0 - 0.025 / 0.64  # 1 - lambda ~ 0.9609
        assert abs(r.H_eff_ratio_at_max_coupling - expected) < 1e-14

    def test_status_is_observation(self):
        r = compression_advantage()
        assert r.status == "OBSERVATION"


class TestLambdaFromDensities:

    def test_standard_values(self):
        """Derive lam from the measured densities."""
        r = lambda_from_densities(0.64, 0.615)
        assert abs(r['delta_rho'] - 0.025) < 1e-14
        assert abs(r['lambda_derived'] - 0.025 / 0.64) < 1e-14

    def test_identical_densities_give_zero(self):
        """If rho_reduced = rho_classical, lam = 0."""
        r = lambda_from_densities(1.0, 1.0)
        assert abs(r['lambda_derived'] - 0.0) < 1e-14

    def test_zero_reduced_gives_one(self):
        """If rho_reduced = 0, lam = 1 (maximum coherence)."""
        r = lambda_from_densities(1.0, 0.0)
        assert abs(r['lambda_derived'] - 1.0) < 1e-14

    def test_H_eff_ratio_consistency(self):
        """H_eff_ratio = 1 - lambda_derived."""
        r = lambda_from_densities(0.64, 0.615)
        assert abs(r['H_eff_ratio'] - (1.0 - r['lambda_derived'])) < 1e-14

    def test_invalid_classical_raises(self):
        with pytest.raises(ValueError):
            lambda_from_densities(0.0, 0.0)
        with pytest.raises(ValueError):
            lambda_from_densities(-1.0, 0.5)

    def test_reduced_exceeds_classical_raises(self):
        with pytest.raises(ValueError):
            lambda_from_densities(0.5, 1.0)

    def test_negative_reduced_raises(self):
        with pytest.raises(ValueError):
            lambda_from_densities(1.0, -0.1)

    def test_status_is_observation(self):
        r = lambda_from_densities(0.64, 0.615)
        assert r['status'] == 'OBSERVATION'


# =============================================================================
# CROSS-RESULT CONSISTENCY
# =============================================================================

class TestCrossResultConsistency:

    def test_lambda_empirical_connects_to_H_eff(self):
        """The empirical lambda from Result 3 plugs into H_eff from Result 2."""
        comp = compression_advantage()
        lam = comp.lambda_empirical

        # At maximum coupling I/H = 1
        r = H_eff(H=1.0, I_XY=1.0, lam=lam)
        expected_ratio = 1.0 - lam
        assert abs(r.ratio - expected_ratio) < 1e-14

    def test_meta_trace_3_from_polynomial(self):
        """Result 1 at N=3 connects to the conservation polynomial."""
        meta = meta_trace_identity(3)
        assert meta['polynomial_tower']['trace_phi2'] == 3
        assert meta['polynomial_tower']['norm_phi2'] == 1

        # Cross-check with constants
        assert abs(TRACE_PHI2 - 3.0) < CONSERVATION_EPSILON
        assert abs(NORM_PHI2 - 1.0) < CONSERVATION_EPSILON

    def test_all_three_results_have_status(self):
        """Every result is clearly labeled THEOREM, CONJECTURE, or OBSERVATION."""
        meta = meta_trace_identity(3)
        assert meta['status'] == 'THEOREM'

        r2 = H_eff(H=1.0, I_XY=0.5, lam=0.5)
        assert r2.status == 'CONJECTURE'

        r3 = compression_advantage()
        assert r3.status == 'OBSERVATION'

    def test_conservation_law_underlies_all(self):
        """All three results reference lam + kap + eta = 1."""
        # Result 1: simplex sums to 1
        s = SimplexState(PHI_INV, (1 - PHI_INV) / 2, (1 - PHI_INV) / 2)
        assert abs(s.trace - 1.0) < CONSERVATION_EPSILON

        # Result 2: lam parameter is coherence from conservation law
        r2 = H_eff(H=1.0, I_XY=1.0, lam=PHI_INV)
        assert 0.0 <= r2.lam <= 1.0

        # Result 3: compression advantage derives from conservation structure
        r3 = compression_advantage()
        assert 0.0 <= r3.lambda_empirical <= 1.0


# =============================================================================
# FULL REPORT
# =============================================================================

class TestTriSimplexReport:

    def test_report_has_all_sections(self):
        r = tri_simplex_report()
        assert 'result_1_tri_simplex' in r
        assert 'result_2_H_eff' in r
        assert 'result_3_compression' in r
        assert 'cross_references' in r

    def test_result_1_status(self):
        r = tri_simplex_report()
        assert r['result_1_tri_simplex']['status'] == 'THEOREM'

    def test_result_2_status(self):
        r = tri_simplex_report()
        assert r['result_2_H_eff']['status'] == 'CONJECTURE'

    def test_result_3_status(self):
        r = tri_simplex_report()
        assert r['result_3_compression']['status'] == 'OBSERVATION'

    def test_result_2_classical_limit_in_report(self):
        r = tri_simplex_report()
        assert r['result_2_H_eff']['classical_limit']['equals_H']

    def test_result_2_max_coupling_in_report(self):
        r = tri_simplex_report()
        assert r['result_2_H_eff']['maximum_coupling']['equals_zero']

    def test_result_3_lambda_in_report(self):
        r = tri_simplex_report()
        expected = 0.025 / 0.64
        assert abs(r['result_3_compression']['lambda_empirical'] - expected) < 1e-14

    def test_result_3_corpus_count(self):
        r = tri_simplex_report()
        assert r['result_3_compression']['corpus_appearances'] == 61

    def test_result_2_corpus_count(self):
        r = tri_simplex_report()
        assert r['result_2_H_eff']['corpus_appearances'] == 13

    def test_polynomial_tower_in_report(self):
        r = tri_simplex_report()
        assert r['result_1_tri_simplex']['polynomial_tower_identity']


# =============================================================================
# STABILITY THRESHOLD CONSTANTS
# =============================================================================

class TestStabilityThresholdConstants:

    def test_firewall_is_1_minus_ln2(self):
        assert abs(LAMBDA_FIREWALL - (1.0 - math.log(2))) < 1e-15

    def test_phase_transition_is_1_over_e(self):
        assert abs(LAMBDA_PHASE_TRANSITION - 1.0 / math.e) < 1e-15

    def test_paradox_is_ln2(self):
        assert abs(LAMBDA_PARADOX - math.log(2)) < 1e-15

    def test_thresholds_ordered(self):
        """The three thresholds must be strictly ordered: (1-ln2) < 1/e < ln(2)."""
        assert LAMBDA_FIREWALL < LAMBDA_PHASE_TRANSITION < LAMBDA_PARADOX

    def test_all_thresholds_in_unit_interval(self):
        """All thresholds are in (0, 1)."""
        for t in [LAMBDA_FIREWALL, LAMBDA_PHASE_TRANSITION, LAMBDA_PARADOX]:
            assert 0 < t < 1

    def test_empirical_well_below_firewall(self):
        """The measured lambda ~ 0.039 is far below the causality firewall."""
        assert LAMBDA_EMPIRICAL < LAMBDA_FIREWALL
        assert LAMBDA_EMPIRICAL / LAMBDA_FIREWALL < 0.15  # Less than 15% of firewall


# =============================================================================
# RESULT 4: STABILITY REGIME CLASSIFICATION
# =============================================================================

class TestStabilityRegime:

    def test_zero_is_classical(self):
        r = stability_regime(0.0)
        assert r.regime == "classical"
        assert r.strain == 0.0
        assert r.thresholds_exceeded == 0

    def test_small_lambda_is_classical(self):
        """Lambda = 0.025 (empirical value) is classical."""
        r = stability_regime(LAMBDA_EMPIRICAL)
        assert r.regime == "classical"

    def test_0_15_is_classical(self):
        r = stability_regime(0.15)
        assert r.regime == "classical"

    def test_0_3_is_classical(self):
        """0.3 < 1-ln(2) ~ 0.3069, so still classical."""
        r = stability_regime(0.3)
        assert r.regime == "classical"

    def test_at_firewall_is_active(self):
        """Exactly at the firewall boundary (1-ln2): active regime."""
        r = stability_regime(LAMBDA_FIREWALL)
        assert r.regime == "active"
        assert r.thresholds_exceeded == 1

    def test_0_35_is_active(self):
        r = stability_regime(0.35)
        assert r.regime == "active"

    def test_1_over_e_is_phase_transition(self):
        """At 1/e: phase transition regime."""
        r = stability_regime(LAMBDA_PHASE_TRANSITION)
        assert r.regime == "phase_transition"
        assert r.thresholds_exceeded == 2

    def test_0_5_is_phase_transition(self):
        r = stability_regime(0.5)
        assert r.regime == "phase_transition"

    def test_ln2_is_paradox(self):
        """At ln(2): paradox regime."""
        r = stability_regime(LAMBDA_PARADOX)
        assert r.regime == "paradox"
        assert r.thresholds_exceeded == 3

    def test_0_9_is_paradox(self):
        r = stability_regime(0.9)
        assert r.regime == "paradox"

    def test_1_0_is_paradox(self):
        r = stability_regime(1.0)
        assert r.regime == "paradox"

    def test_strain_is_ratio_to_firewall(self):
        """Strain = lambda / LAMBDA_FIREWALL."""
        r = stability_regime(0.6)
        assert abs(r.strain - 0.6 / LAMBDA_FIREWALL) < 1e-14

    def test_status_is_conjecture(self):
        r = stability_regime(0.5)
        assert r.status == "CONJECTURE"

    def test_negative_lambda_raises(self):
        with pytest.raises(ValueError, match="lam must be in"):
            stability_regime(-0.01)

    def test_lambda_above_1_raises(self):
        with pytest.raises(ValueError, match="lam must be in"):
            stability_regime(1.5)

    def test_description_nonempty(self):
        """Every regime has a non-empty description."""
        for lam in [0.0, 0.2, 0.35, 0.5, 0.8]:
            r = stability_regime(lam)
            assert len(r.description) > 0

    def test_monotone_thresholds_exceeded(self):
        """Thresholds exceeded is non-decreasing as lambda increases."""
        prev = 0
        for lam in [0.0, 0.1, 0.3, 0.37, 0.5, 0.7, 1.0]:
            r = stability_regime(lam)
            assert r.thresholds_exceeded >= prev
            prev = r.thresholds_exceeded


# =============================================================================
# COLLECTIVE SYNCHRONIZATION
# =============================================================================

class TestCollectiveLambda:

    def test_single_agent(self):
        """Single agent: random = sync = lambda."""
        r = collective_lambda([0.1])
        assert abs(r.lambda_total_random - 0.1) < 1e-14
        assert abs(r.lambda_total_sync - 0.1) < 1e-14
        assert r.n_agents == 1

    def test_random_phase_sqrt_n(self):
        """100 identical agents at random phase: total ~ lam * sqrt(100) = 10 * lam."""
        lam = 0.025
        r = collective_lambda([lam] * 100)
        assert abs(r.lambda_total_random - lam * 10.0) < 1e-14

    def test_sync_phase_n_times_lam(self):
        """100 identical agents synced: total = 100 * lam."""
        lam = 0.025
        r = collective_lambda([lam] * 100)
        assert abs(r.lambda_total_sync - 100 * lam) < 1e-14

    def test_sync_always_ge_random(self):
        """Perfect sync total >= random total for any n >= 1."""
        for n in [1, 4, 9, 16, 100]:
            r = collective_lambda([0.05] * n)
            assert r.lambda_total_sync >= r.lambda_total_random - 1e-14

    def test_agents_to_firewall_at_empirical(self):
        """At lambda ~ 0.039, need ceil((firewall/0.039)^2) agents for random-phase breach."""
        r = collective_lambda([LAMBDA_EMPIRICAL] * 10)
        expected = math.ceil((LAMBDA_FIREWALL / LAMBDA_EMPIRICAL) ** 2)
        assert r.agents_to_firewall == expected

    def test_agents_to_firewall_at_fixed_039(self):
        """At lambda = 0.039, need ceil((firewall/0.039)^2) agents."""
        r = collective_lambda([0.039] * 10)
        expected = math.ceil((LAMBDA_FIREWALL / 0.039) ** 2)
        assert r.agents_to_firewall == expected

    def test_mixed_lambdas(self):
        """Non-uniform lambdas: uses average."""
        r = collective_lambda([0.01, 0.02, 0.03])
        assert abs(r.lambda_avg - 0.02) < 1e-14
        assert abs(r.lambda_total_random - 0.02 * math.sqrt(3)) < 1e-14
        assert abs(r.lambda_total_sync - 0.06) < 1e-14

    def test_empty_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            collective_lambda([])

    def test_invalid_lambda_raises(self):
        with pytest.raises(ValueError, match="not in"):
            collective_lambda([0.5, -0.1])

    def test_status_is_conjecture(self):
        r = collective_lambda([0.025])
        assert r.status == "CONJECTURE"

    def test_regime_classification_random(self):
        """10 agents at 0.025: random total = 0.025 * sqrt(10) ~ 0.079, classical."""
        r = collective_lambda([0.025] * 10)
        assert r.regime_random == "classical"

    def test_regime_classification_sync(self):
        """100 agents at 0.039 synced: total = 3.9, paradox regime (clamped to 1)."""
        r = collective_lambda([0.039] * 100)
        assert r.regime_sync == "paradox"

    def test_zero_coupling_agents_to_firewall(self):
        """Zero coupling: agents_to_firewall = 0 (never reachable)."""
        r = collective_lambda([0.0, 0.0, 0.0])
        assert r.agents_to_firewall == 0


# =============================================================================
# COMPRESSION <-> LAMBDA ROUND-TRIP
# =============================================================================

class TestCompressionFromLambda:

    def test_zero_lambda_gives_1(self):
        assert abs(compression_from_lambda(0.0) - 1.0) < 1e-14

    def test_full_lambda_gives_0(self):
        assert abs(compression_from_lambda(1.0) - 0.0) < 1e-14

    def test_empirical_lambda(self):
        """lam ~ 0.039 at full coupling: C ~ 0.961."""
        assert abs(compression_from_lambda(LAMBDA_EMPIRICAL) - (1.0 - LAMBDA_EMPIRICAL)) < 1e-14

    def test_half_lambda_at_full_coupling(self):
        """lam = 0.5: C = 0.5."""
        assert abs(compression_from_lambda(0.5) - 0.5) < 1e-14

    def test_partial_coupling(self):
        """lam = 0.5, coupling = 0.5: C = 1 - 0.25 = 0.75."""
        assert abs(compression_from_lambda(0.5, 0.5) - 0.75) < 1e-14

    def test_invalid_lambda_raises(self):
        with pytest.raises(ValueError):
            compression_from_lambda(-0.1)
        with pytest.raises(ValueError):
            compression_from_lambda(1.5)

    def test_invalid_coupling_raises(self):
        with pytest.raises(ValueError):
            compression_from_lambda(0.5, -0.1)
        with pytest.raises(ValueError):
            compression_from_lambda(0.5, 1.5)


class TestLambdaFromCompression:

    def test_compression_1_gives_lambda_0(self):
        assert abs(lambda_from_compression(1.0) - 0.0) < 1e-14

    def test_compression_0_gives_lambda_1(self):
        assert abs(lambda_from_compression(0.0) - 1.0) < 1e-14

    def test_round_trip_empirical(self):
        """compression_from_lambda and lambda_from_compression are inverses."""
        lam = LAMBDA_EMPIRICAL
        c = compression_from_lambda(lam)
        lam_recovered = lambda_from_compression(c)
        assert abs(lam_recovered - lam) < 1e-14

    def test_round_trip_039(self):
        lam = 0.039
        c = compression_from_lambda(lam)
        lam_recovered = lambda_from_compression(c)
        assert abs(lam_recovered - lam) < 1e-14

    def test_round_trip_partial_coupling(self):
        lam = 0.5
        coupling = 0.7
        c = compression_from_lambda(lam, coupling)
        lam_recovered = lambda_from_compression(c, coupling)
        assert abs(lam_recovered - lam) < 1e-14

    def test_invalid_compression_raises(self):
        with pytest.raises(ValueError):
            lambda_from_compression(-0.1)
        with pytest.raises(ValueError):
            lambda_from_compression(1.5)

    def test_zero_coupling_raises(self):
        with pytest.raises(ValueError):
            lambda_from_compression(0.5, 0.0)


# =============================================================================
# THRESHOLD SUMMARY
# =============================================================================

class TestThresholdSummary:

    def test_has_all_keys(self):
        s = threshold_summary()
        assert 'firewall' in s
        assert 'phase_transition' in s
        assert 'paradox' in s
        assert 'empirical_anchor' in s

    def test_firewall_value(self):
        s = threshold_summary()
        assert abs(s['firewall']['value'] - (1.0 - math.log(2))) < 1e-15

    def test_phase_transition_value(self):
        s = threshold_summary()
        assert abs(s['phase_transition']['value'] - 1.0 / math.e) < 1e-15

    def test_paradox_value(self):
        s = threshold_summary()
        assert abs(s['paradox']['value'] - math.log(2)) < 1e-15

    def test_empirical_anchor_value(self):
        s = threshold_summary()
        expected = 0.025 / 0.64
        assert abs(s['empirical_anchor']['value'] - expected) < 1e-14

    def test_empirical_anchor_has_raw_delta(self):
        s = threshold_summary()
        assert abs(s['empirical_anchor']['delta_rho_raw'] - 0.025) < 1e-14

    def test_empirical_ratio_to_firewall(self):
        s = threshold_summary()
        expected = LAMBDA_EMPIRICAL / LAMBDA_FIREWALL
        assert abs(s['empirical_anchor']['ratio_to_firewall'] - expected) < 1e-14

    def test_each_has_interpretation(self):
        s = threshold_summary()
        for key in ['firewall', 'phase_transition', 'paradox']:
            assert len(s[key]['interpretation']) > 0


# =============================================================================
# CROSS-RESULT CONSISTENCY (EXTENDED)
# =============================================================================

class TestExtendedCrossResultConsistency:

    def test_compression_matches_H_eff_ratio(self):
        """compression_from_lambda agrees with H_eff_ratio for all lambda."""
        for lam in [0.0, 0.025, 0.039, 0.3, 0.5, 0.693, 1.0]:
            c = compression_from_lambda(lam, 1.0)
            r = H_eff_ratio(lam, 1.0)
            assert abs(c - r) < 1e-14

    def test_stability_regime_at_threshold_values(self):
        """The threshold constants map to their expected regime boundaries."""
        assert stability_regime(LAMBDA_FIREWALL).regime == "active"
        assert stability_regime(LAMBDA_PHASE_TRANSITION).regime == "phase_transition"
        assert stability_regime(LAMBDA_PARADOX).regime == "paradox"

    def test_collective_firewall_matches_threshold(self):
        """Agents-to-firewall uses LAMBDA_FIREWALL consistently."""
        lam = 0.1
        r = collective_lambda([lam] * 5)
        expected_n = math.ceil((LAMBDA_FIREWALL / lam) ** 2)
        assert r.agents_to_firewall == expected_n

    def test_empirical_lambda_regime_is_classical(self):
        """Both empirical anchors (0.025 and 0.039) are classical."""
        assert stability_regime(LAMBDA_EMPIRICAL).regime == "classical"
        assert stability_regime(0.039).regime == "classical"
