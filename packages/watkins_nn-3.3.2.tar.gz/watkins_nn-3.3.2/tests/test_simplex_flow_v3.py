"""Tests for simplex_flow_v3 module.

Requires torch -- all tests skipped if torch unavailable.
"""

import numpy as np
import pytest

torch = pytest.importorskip("torch", reason="torch required for simplex_flow_v3 tests")

from watkins_nn.algosignal_v2 import AlgoSignal
from watkins_nn.simplex_flow_v3 import (
    ConvergenceMetrics,
    SimplexFlowEngineV3,
    compute_F_raw,
    multi_start_convergence_test,
)
from watkins_nn.constants import WATKINS_LAMBDA, WATKINS_KAPPA, WATKINS_ETA

PHI = (1 + np.sqrt(5)) / 2


class TestConvergenceMetrics:
    """ConvergenceMetrics dataclass."""

    def test_to_dict_keys(self):
        m = ConvergenceMetrics(
            converged=True,
            steps=10,
            final_state=[0.618, 0.191, 0.191],
            final_F=0.5,
            gradient_norm=1e-9,
            conservation_error=1e-15,
            watkins_distance=1e-6,
            at_watkins=True,
            wall_time_ms=5.0,
            method="test",
        )
        d = m.to_dict()
        expected_keys = {
            'converged', 'steps', 'final_state', 'final_F',
            'gradient_norm', 'conservation_error', 'watkins_distance',
            'at_watkins', 'wall_time_ms', 'method',
        }
        assert set(d.keys()) == expected_keys

    def test_default_lists_empty(self):
        m = ConvergenceMetrics(
            converged=True, steps=0, final_state=[], final_F=0.0,
            gradient_norm=0.0, conservation_error=0.0, watkins_distance=0.0,
            at_watkins=True, wall_time_ms=0.0, method="x",
        )
        assert m.trajectory_subsample == []
        assert m.F_history == []
        assert m.grad_history == []


class TestProjectedGradientNorm:
    """Static utility: projected gradient norm on simplex tangent plane."""

    def test_constant_gradient_projects_to_zero(self):
        """A gradient proportional to [1,1,1] is normal to the simplex -- projection = 0."""
        g = np.array([3.0, 3.0, 3.0])
        norm = SimplexFlowEngineV3.projected_gradient_norm(g)
        assert np.allclose(norm, 0.0, atol=1e-10)

    def test_tangent_gradient_unchanged(self):
        """A gradient orthogonal to [1,1,1] lives in tangent plane -- norm preserved."""
        g = np.array([1.0, -1.0, 0.0])
        norm = SimplexFlowEngineV3.projected_gradient_norm(g)
        expected = np.linalg.norm(g)
        assert np.allclose(norm, expected, rtol=1e-8, atol=1e-10)

    def test_zero_gradient(self):
        g = np.array([0.0, 0.0, 0.0])
        norm = SimplexFlowEngineV3.projected_gradient_norm(g)
        assert np.allclose(norm, 0.0, atol=1e-10)


class TestSimplexFlowEngineV3Step:
    """Single-step and low-level mechanics."""

    def test_step_returns_nonnegative_norm(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEngineV3(signal, adaptive=False)
        gn = engine.step()
        assert gn >= 0.0

    def test_step_records_trajectory(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEngineV3(signal, adaptive=False)
        engine.step()
        assert len(engine._trajectory) == 1
        assert len(engine._F_values) == 1
        assert len(engine._grad_norms) == 1

    def test_adaptive_step_decreases_F(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEngineV3(signal, adaptive=True)
        F_before = engine._compute_F_from_unconstrained().item()
        engine.step()
        F_after = engine._F_values[-1]
        # Armijo guarantees decrease (or equality at minimum)
        assert F_after <= F_before + 1e-10

    def test_euler_step_conservation(self):
        signal = AlgoSignal(lambda_init=0.4, kappa_init=0.35, eta_init=0.25)
        engine = SimplexFlowEngineV3(signal, adaptive=False)
        engine.step()
        state = signal.state_vector().detach().cpu().numpy()
        assert np.allclose(state.sum(), 1.0, rtol=1e-8, atol=1e-10)


class TestSimplexFlowEngineV3Convergence:
    """Full convergence runs."""

    def test_adaptive_convergence(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEngineV3(signal, max_steps=8000, tolerance=1e-7)
        metrics = engine.run_to_convergence(verbose=False)
        assert metrics.converged
        assert np.allclose(sum(metrics.final_state), 1.0, rtol=1e-8, atol=1e-10)
        assert metrics.conservation_error < 1e-10

    def test_euler_convergence(self):
        signal = AlgoSignal(lambda_init=0.4, kappa_init=0.4, eta_init=0.2)
        engine = SimplexFlowEngineV3(signal, max_steps=8000, tolerance=1e-6, adaptive=False)
        metrics = engine.run_to_convergence(verbose=False)
        assert metrics.converged
        assert metrics.conservation_error < 1e-10

    def test_lbfgs_convergence(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEngineV3(signal, max_steps=5000, tolerance=1e-7)
        metrics = engine.run_to_convergence_lbfgs(verbose=False)
        assert metrics.converged
        assert metrics.method == 'lbfgs_v3'
        assert metrics.conservation_error < 1e-10

    def test_converges_to_watkins(self):
        signal = AlgoSignal(lambda_init=0.33, kappa_init=0.33, eta_init=0.34)
        engine = SimplexFlowEngineV3(signal, max_steps=8000, tolerance=1e-7)
        metrics = engine.run_to_convergence(verbose=False)
        assert metrics.converged
        assert metrics.at_watkins
        expected = np.array([WATKINS_LAMBDA, WATKINS_KAPPA, WATKINS_ETA])
        assert np.allclose(metrics.final_state, expected, rtol=1e-3, atol=1e-4)

    def test_random_init_engine(self):
        """Engine with signal=None creates random start and reaches equilibrium."""
        engine = SimplexFlowEngineV3(signal=None)  # use engine defaults
        metrics = engine.run_to_convergence(verbose=False)
        assert np.allclose(sum(metrics.final_state), 1.0, rtol=1e-8, atol=1e-10)
        assert metrics.watkins_distance < 1e-4, (
            f"Final state too far from equilibrium: d={metrics.watkins_distance:.2e}"
        )

    def test_metrics_wall_time_positive(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEngineV3(signal, max_steps=100, tolerance=1e-20)
        metrics = engine.run_to_convergence(verbose=False)
        assert metrics.wall_time_ms > 0

    def test_metrics_trajectory_subsample(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEngineV3(signal, max_steps=200, tolerance=1e-20)
        metrics = engine.run_to_convergence(verbose=False)
        assert len(metrics.trajectory_subsample) > 0
        # Each entry is [lam, kap, eta]
        assert len(metrics.trajectory_subsample[0]) == 3


class TestComputeFRaw:
    """Module-level compute_F_raw helper."""

    def test_returns_finite(self):
        F = compute_F_raw(0.6, 0.2, 0.2)
        assert np.isfinite(F)

    def test_equilibrium_value(self):
        F_eq = compute_F_raw(WATKINS_LAMBDA, WATKINS_KAPPA, WATKINS_ETA)
        assert np.isfinite(F_eq)


class TestMultiStartConvergence:
    """multi_start_convergence_test function."""

    def test_small_multi_start(self):
        result = multi_start_convergence_test(
            n_starts=3, max_steps=8000, tolerance=1e-6, verbose=False
        )
        assert result['n_starts'] == 3
        assert result['convergence_rate'] >= 0.0  # Validates structure, not 100% rate
        assert result['max_conservation_error'] < 1e-8
        assert len(result['per_run']) == 3
