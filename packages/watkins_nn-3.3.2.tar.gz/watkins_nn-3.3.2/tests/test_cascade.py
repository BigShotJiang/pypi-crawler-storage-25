"""Tests for cascade.py — E₈ exceptional cascade.

Covers: root system construction, cascade chain, BCC grids,
eigenvalues, structural laws. This module was previously untested
despite being friction-prone (index errors at boundaries).
"""

import numpy as np
import pytest

from watkins_nn.cascade import (
    e8_roots,
    cascade_chain,
    bcc_grid,
    bcc_eigenvalues,
    bcc_perron_alpha,
)


# ── Root system construction ──────────────────────────────────────────

class TestE8Roots:
    def test_e8_root_count(self):
        """E₈ has exactly 240 roots."""
        assert e8_roots().shape[0] == 240

    def test_e8_root_dimension(self):
        """E₈ roots live in R⁸."""
        assert e8_roots().shape[1] == 8

    def test_e8_roots_are_unit_or_half(self):
        """Each E₈ root has norm 1 (integer) or √2 (half-integer)."""
        norms = np.linalg.norm(e8_roots(), axis=1)
        # Integer roots have norm √2, half-integer roots have norm √2
        assert np.allclose(norms, np.sqrt(2), atol=1e-10)

    def test_e8_roots_negation_closed(self):
        """If r is a root, -r is also a root."""
        root_set = set(map(tuple, e8_roots().tolist()))
        for r in list(root_set):
            neg = tuple(-x for x in r)
            assert neg in root_set, f"-{r} not in root set"

    def test_e8_roots_cached(self):
        """Second call returns same object (caching works)."""
        r1 = e8_roots()
        r2 = e8_roots()
        assert r1 is r2


# ── Cascade chain ─────────────────────────────────────────────────────

class TestCascadeChain:
    @pytest.fixture
    def chain(self):
        return cascade_chain()

    def test_chain_length(self, chain):
        """Chain has 7 steps: E₈→E₇, E₇→E₆, ..., A₂→A₁."""
        assert len(chain) == 7

    def test_chain_step_names(self, chain):
        expected = ["E8→E7", "E7→E6", "E6→D5", "D5→D4", "D4→D3", "D3→A2", "A2→A1"]
        actual = [step["step"] for step in chain]
        assert actual == expected

    def test_layer_sizes_sum_to_238(self, chain):
        """Layers partition E₈\\A₁ = 240 - 2 = 238 roots."""
        total = sum(step["layer_size"] for step in chain)
        assert total == 238

    def test_e8_e7_layer_is_114(self, chain):
        """The E₈→E₇ complement has 114 roots (240 - 126)."""
        assert chain[0]["layer_size"] == 114

    def test_trace_e8_is_126(self, chain):
        """tr(BCC_{E₈}) = |E₇| = 126 — the branching identity."""
        # The trace of the full E₈ BCC grid should be 126
        g = bcc_grid("E8")
        assert int(np.trace(g)) == 126

    def test_null_vector_cascade(self, chain):
        """(1,0,-1) is null for all layers except D₃→A₂."""
        for step in chain:
            if step["step"] == "D3→A2":
                assert not step["null_eigenvalue"], "D₃→A₂ should NOT be null"
            else:
                assert step["null_eigenvalue"], f"{step['step']} should be null"

    def test_spinor_corner_law(self, chain):
        """Only E-type layers have nonzero BCC corners; total = 16."""
        corner_total = 0
        for step in chain:
            co = step["bcc_corner"]
            if step["above"].startswith("E"):
                corner_total += co
            else:
                assert co == 0, f"{step['step']} has nonzero corner {co}"
        assert corner_total == 16  # 8 + 4 + 4

    def test_edge_saturation_law(self, chain):
        """Only D₃→A₂ has nonzero BCC edge population."""
        for step in chain:
            if step["step"] == "D3→A2":
                assert step["bcc_edge"] > 0, "D₃→A₂ should have edge roots"
            else:
                assert step["bcc_edge"] == 0, f"{step['step']} has unexpected edge roots"

    def test_bcc_grid_shape(self, chain):
        """Each step's 2D grid is 3×3."""
        for step in chain:
            assert step["grid_2d"].shape == (3, 3)

    def test_eigenvalues_real(self, chain):
        """All 2D BCC eigenvalues are real."""
        for step in chain:
            for ev in step["eigenvalues_2d"]:
                assert np.isreal(ev), f"{step['step']} has complex eigenvalue {ev}"


# ── BCC grids for individual root systems ──────────────────────────────

class TestBCCGrid:
    def test_e8_grid_trace(self):
        assert int(np.trace(bcc_grid("E8"))) == 126

    def test_e7_root_count(self):
        g = bcc_grid("E7")
        assert int(g.sum()) == 126

    def test_e6_root_count(self):
        g = bcc_grid("E6")
        assert int(g.sum()) == 72

    def test_d5_root_count(self):
        g = bcc_grid("D5")
        assert int(g.sum()) == 40

    def test_d4_root_count(self):
        g = bcc_grid("D4")
        assert int(g.sum()) == 24

    def test_d3_root_count(self):
        g = bcc_grid("D3")
        assert int(g.sum()) == 12

    def test_a2_root_count(self):
        g = bcc_grid("A2")
        assert int(g.sum()) == 6

    def test_a1_root_count(self):
        g = bcc_grid("A1")
        assert int(g.sum()) == 2

    def test_f4_root_count(self):
        g = bcc_grid("F4")
        assert int(g.sum()) == 48

    def test_grid_is_3x3(self):
        for sys in ["E8", "E7", "E6", "D5", "D4", "D3", "A2", "A1"]:
            g = bcc_grid(sys)
            assert g.shape == (3, 3), f"{sys} grid is {g.shape}"

    def test_grid_nonnegative(self):
        for sys in ["E8", "E7", "D4", "A2"]:
            g = bcc_grid(sys)
            assert (g >= 0).all(), f"{sys} has negative entries"

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown"):
            bcc_grid("XYZ")


# ── Eigenvalues ───────────────────────────────────────────────────────

class TestBCCEigenvalues:
    def test_e6_eigenvalues(self):
        evals = bcc_eigenvalues("E6")
        assert np.isclose(evals[0], 24, atol=1e-8)
        assert np.isclose(evals[1], 6, atol=1e-8)
        assert np.isclose(evals[2], 0, atol=1e-8)

    def test_e7_eigenvalues(self):
        evals = bcc_eigenvalues("E7")
        assert np.isclose(evals[0], 42, atol=1e-8)
        assert np.isclose(evals[1], 18, atol=1e-8)
        assert np.isclose(evals[2], 0, atol=1e-8)

    def test_e8_eigenvalues_contain_sqrt33(self):
        """E₈ BCC eigenvalues involve √33."""
        evals = bcc_eigenvalues("E8")
        sqrt33 = np.sqrt(33)
        expected_large = 63 + 3 * sqrt33
        expected_small = 63 - 3 * sqrt33
        assert np.isclose(evals[0], expected_large, atol=1e-6)
        assert np.isclose(evals[1], expected_small, atol=1e-6)

    def test_eigenvalues_sorted_descending(self):
        for sys in ["E8", "E7", "E6", "D5"]:
            evals = bcc_eigenvalues(sys)
            assert evals[0] >= evals[1] >= evals[2], f"{sys} not sorted"


# ── Perron eigenvector ────────────────────────────────────────────────

class TestPerronAlpha:
    def test_e8_alpha(self):
        alpha, disc = bcc_perron_alpha("E8")
        assert alpha > 0, "Perron alpha must be positive"

    def test_d4_symmetric(self):
        """D₄ has triality → alpha should reflect symmetry."""
        alpha, disc = bcc_perron_alpha("D4")
        assert alpha > 0

    def test_a2_alpha(self):
        alpha, disc = bcc_perron_alpha("A2")
        assert alpha > 0
