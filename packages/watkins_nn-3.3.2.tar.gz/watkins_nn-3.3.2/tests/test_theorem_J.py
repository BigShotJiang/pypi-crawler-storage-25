"""Tests for Theorem J: Spectral Backbone Multiplicativity.

seq9(m) * seq9(n) = seq9(m+n) + seq9(|m-n|)

This is the Chebyshev product-sum identity for L(2k) evaluated at cosh(t) = 3/2.
"""
import pytest
from watkins_nn.kaleidoscope import seq9_weight_moments, lucas


class TestTheoremJ:
    """Theorem J: seq9(m)*seq9(n) = seq9(m+n) + seq9(|m-n|)."""

    @pytest.mark.parametrize("m,n", [
        (1, 1), (2, 1), (3, 2), (5, 3), (7, 4), (10, 6),
        (1, 0), (5, 5), (8, 3), (12, 7), (15, 10), (20, 13),
    ])
    def test_multiplicativity(self, m, n):
        lhs = seq9_weight_moments(m) * seq9_weight_moments(n)
        rhs = seq9_weight_moments(m + n) + seq9_weight_moments(abs(m - n))
        assert lhs == rhs, f"J failed: seq9({m})*seq9({n}) = {lhs} != {rhs}"

    def test_multiplicativity_exhaustive(self):
        """Verify for all 1 <= n <= m <= 20 (210 cases)."""
        for m in range(1, 21):
            for n in range(1, m + 1):
                lhs = seq9_weight_moments(m) * seq9_weight_moments(n)
                rhs = seq9_weight_moments(m + n) + seq9_weight_moments(abs(m - n))
                assert lhs == rhs

    def test_seq9_equals_lucas_bisection(self):
        """seq9(k) = L(2k) for all k."""
        for k in range(30):
            assert seq9_weight_moments(k) == lucas(2 * k)

    def test_doubling_formula(self):
        """Theorem K: seq9(2n) = seq9(n)^2 - 2 (special case of J with m=n)."""
        for n in range(1, 15):
            assert seq9_weight_moments(2 * n) == seq9_weight_moments(n) ** 2 - 2
