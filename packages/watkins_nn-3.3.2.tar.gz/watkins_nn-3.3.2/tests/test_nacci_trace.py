"""Tests for the n-nacci Trace Tower module (Sprint 31).

Covers all 33 theorems ES through GB with numerical verification.
"""

import math
import pytest
import numpy as np

from watkins_nn.nacci_trace import (
    PHI_BAR, PHI_BAR_SQUARED, CONSERVATION_TRACE, CONSERVATION_NORM,
    FREE_ENERGY_PER_SITE, STOKES_CONSTANT, GOLDEN_ENTROPY,
    nacci_dominant_root, nacci_all_roots,
    trace, departure, elem_sym_poly,
    conservation_poly, conservation_poly_at_1, conservation_poly_coefficients,
    conservation_poly_recurrence, conservation_poly_at_2,
    bootstrap_fixed_point, bootstrap_uniqueness_check,
    a2_cartan_eigenvalues, conservation_poly_encodes_root_systems,
    cartan_embedding_period, conservation_roots_in_cartan,
    golden_entropy_exact, price_of_structure,
    stokes_free_energy_identity, fibonacci_square_gf_denominator,
    seq1_is_universal_trace, seq9_is_lucas_trace,
    golden_nome, theta_trace_identity_holds,
    bridge_field_unit_norms, verify_all,
    # Fibonacci tower (GC-GI)
    fibonacci_tower_identity, trace_embeds_watkins,
    self_trace_unification, fibonacci_departure_self_reference,
    palindromic_norm_theorem, asymmetry_triad_factoring,
    bridge_conservation,
    # Baryon asymmetry (GJ)
    baryon_asymmetry_exponent, baryon_uniqueness, _lucas,
    # L-function connection (GK-GP)
    norm_form_theorem, prime_splitting_theorem,
    dedekind_zeta_factorization, regulator_identity,
    temperature_regulator_identity, l_function_at_baryon,
    _kronecker_5,
)
from watkins_nn.constants import PHI, PHI_SQUARED, SQRT5


# =============================================================================
# Theorem ES: Universal trace sum = 1
# =============================================================================

class TestTheoremES:
    @pytest.mark.parametrize("n", range(3, 12))
    def test_trace_sum_equals_1(self, n):
        roots = nacci_all_roots(n)
        assert abs(sum(roots).real - 1.0) < 1e-8


# =============================================================================
# Theorem ET: Universal conservation number = 3
# =============================================================================

class TestTheoremET:
    @pytest.mark.parametrize("n", range(3, 15))
    def test_trace_squared_equals_3(self, n):
        roots = nacci_all_roots(n)
        tr2 = sum(r ** 2 for r in roots).real
        assert abs(tr2 - 3.0) < 1e-8

    def test_3_is_conservation_trace(self):
        assert CONSERVATION_TRACE == 3


# =============================================================================
# Theorem EU: Mersenne traces
# =============================================================================

class TestTheoremEU:
    @pytest.mark.parametrize("n", range(3, 12))
    def test_mersenne_traces(self, n):
        for k in range(1, n):
            assert trace(n, k) == 2 ** k - 1

    def test_trace_1_equals_1(self):
        for n in range(3, 10):
            assert trace(n, 1) == 1

    def test_trace_2_equals_3(self):
        for n in range(3, 10):
            assert trace(n, 2) == 3


# =============================================================================
# Theorem EV: Trace departure at boundary
# =============================================================================

class TestTheoremEV:
    @pytest.mark.parametrize("n", range(3, 15))
    def test_departure_at_n(self, n):
        assert trace(n, n) == 2 ** n - n - 1

    def test_departure_encodes_dimension(self, ):
        for n in range(3, 15):
            mersenne = 2 ** n - 1
            actual = trace(n, n)
            assert mersenne - actual == n


# =============================================================================
# Theorem EW: Generalized Lucas recurrence
# =============================================================================

class TestTheoremEW:
    @pytest.mark.parametrize("n", [3, 4, 5, 6])
    def test_recurrence(self, n):
        for k in range(n, n + 10):
            expected = sum(trace(n, k - i) for i in range(1, n))
            assert trace(n, k) == expected

    def test_n3_gives_lucas(self):
        lucas = [1, 3, 4, 7, 11, 18, 29, 47, 76, 123]
        for k, L in enumerate(lucas, start=1):
            assert trace(3, k) == L


# =============================================================================
# Theorem EX: Product identity
# =============================================================================

class TestTheoremEX:
    @pytest.mark.parametrize("n", range(3, 12))
    def test_product_minus_1_to_n(self, n):
        roots = nacci_all_roots(n)
        prod = np.prod(roots).real
        assert abs(prod - (-1) ** n) < 1e-6

    @pytest.mark.parametrize("n", range(3, 12))
    def test_elem_sym_poly_product(self, n):
        assert elem_sym_poly(n, n - 1) == (-1) ** n


# =============================================================================
# Theorem EY: Bootstrap uniqueness
# =============================================================================

class TestTheoremEY:
    def test_only_n3_is_fixed_point(self):
        assert bootstrap_fixed_point(3) == 3
        for n in range(4, 15):
            assert bootstrap_fixed_point(n) != n

    def test_uniqueness_check(self):
        assert bootstrap_uniqueness_check(20)


# =============================================================================
# Theorem FF: Departure formula
# =============================================================================

class TestTheoremFF:
    @pytest.mark.parametrize("n", range(3, 10))
    def test_departure_formula(self, n):
        for j in range(n):
            assert departure(n, j) == (2 ** j) * (n + j)

    @pytest.mark.parametrize("n", range(3, 10))
    def test_breaks_at_j_equals_n(self, n):
        dep_actual = departure(n, n)
        dep_formula = (2 ** n) * (2 * n)
        assert dep_formula - dep_actual == n


# =============================================================================
# Theorem FK: Elementary symmetric polynomials all +/-1
# =============================================================================

class TestTheoremFK:
    @pytest.mark.parametrize("n", range(3, 10))
    def test_all_pm1(self, n):
        for j in range(n):
            val = elem_sym_poly(n, j)
            assert val in {-1, 1}

    @pytest.mark.parametrize("n", range(3, 10))
    def test_alternating_sign(self, n):
        for j in range(1, n - 1):
            assert elem_sym_poly(n, j) == (-1) ** (j + 1)


# =============================================================================
# Theorem FM: Three-value coefficients
# =============================================================================

class TestTheoremFM:
    @pytest.mark.parametrize("n", range(3, 15))
    def test_only_three_values(self, n):
        coeffs = conservation_poly_coefficients(n)
        values = set(coeffs)
        s = (-1) ** (n + 1)
        assert values <= {1, -3, s}

    @pytest.mark.parametrize("n", range(3, 15))
    def test_leading_and_second(self, n):
        coeffs = conservation_poly_coefficients(n)
        assert coeffs[0] == 1
        assert coeffs[1] == -3


# =============================================================================
# Theorem FY: Master closed form
# =============================================================================

class TestTheoremFY:
    @pytest.mark.parametrize("n", range(3, 12))
    @pytest.mark.parametrize("t", [2, 3, 5, 7])
    def test_formula_matches_numerical(self, n, t):
        formula = round(conservation_poly(n, float(t)))
        roots = nacci_all_roots(n)
        sq = [r ** 2 for r in roots]
        numerical = round(np.prod([t - r for r in sq]).real)
        assert formula == numerical


# =============================================================================
# Theorem FZ: Order-4 recurrence
# =============================================================================

class TestTheoremFZ:
    @pytest.mark.parametrize("t", [2, 3, 5])
    def test_recurrence(self, t):
        vals = [round(conservation_poly(n, float(t))) for n in range(3, 20)]
        for i in range(4, len(vals)):
            predicted = round(conservation_poly_recurrence(
                [vals[i - 4], vals[i - 3], vals[i - 2], vals[i - 1]], float(t)
            ))
            assert predicted == vals[i]


# =============================================================================
# Theorem GA: Mersenne-squared evaluation
# =============================================================================

class TestTheoremGA:
    @pytest.mark.parametrize("n", range(3, 20))
    def test_cn_at_2(self, n):
        assert conservation_poly_at_2(n) == round(conservation_poly(n, 2.0))

    def test_even_formula(self):
        for m in range(2, 10):
            n = 2 * m
            M = 2 ** m - 1
            assert conservation_poly_at_2(n) == 2 - M * M

    def test_odd_formula(self):
        for m in range(1, 10):
            n = 2 * m + 1
            M = 2 ** m - 1
            assert conservation_poly_at_2(n) == 1 - 2 * M * M


# =============================================================================
# Theorem FH: Stokes = free energy + ln(2)
# =============================================================================

class TestTheoremFH:
    def test_identity(self):
        ident = stokes_free_energy_identity()
        assert ident["identity_error"] < 1e-14

    def test_components(self):
        assert abs(FREE_ENERGY_PER_SITE - 2 * math.log(PHI)) < 1e-14
        assert abs(STOKES_CONSTANT - math.log(2 * PHI_SQUARED)) < 1e-14


# =============================================================================
# Theorem FQ: A_2 Cartan eigenvalues
# =============================================================================

class TestTheoremFQ:
    def test_eigenvalues_are_1_and_3(self):
        assert a2_cartan_eigenvalues() == (1, 3)

    def test_matches_universal_traces(self):
        lo, hi = a2_cartan_eigenvalues()
        assert lo == trace(3, 1)  # Tr(alpha) = 1
        assert hi == trace(3, 2)  # Tr(alpha^2) = 3


# =============================================================================
# Theorem FR: Conservation polynomial encodes A_2 and E_8
# =============================================================================

class TestTheoremFR:
    def test_root_sum_is_det_A2(self):
        data = conservation_poly_encodes_root_systems()
        assert data["root_sum"] == data["det_cartan_A2"]

    def test_root_product_is_det_E8(self):
        data = conservation_poly_encodes_root_systems()
        assert data["root_product"] == data["det_cartan_E8"]


# =============================================================================
# Theorem FS: Conservation roots embed in A_{5m-1}
# =============================================================================

class TestTheoremFS:
    def test_embedding_period(self):
        assert cartan_embedding_period() == 5

    @pytest.mark.parametrize("n", [5, 10, 15, 20, 25])
    def test_roots_found(self, n):
        result = conservation_roots_in_cartan(n)
        assert result is not None
        k_lo, k_hi = result
        eig_lo = 2 - 2 * math.cos(k_lo * math.pi / n)
        eig_hi = 2 - 2 * math.cos(k_hi * math.pi / n)
        assert abs(eig_lo - 1 / PHI_SQUARED) < 1e-10
        assert abs(eig_hi - PHI_SQUARED) < 1e-10

    @pytest.mark.parametrize("n", [4, 6, 7, 8, 9, 11])
    def test_roots_not_found(self, n):
        assert conservation_roots_in_cartan(n) is None


# =============================================================================
# Theorem FX: Golden entropy
# =============================================================================

class TestTheoremFX:
    def test_closed_form(self):
        H = golden_entropy_exact()
        # Direct computation
        lam = 1.0 / PHI
        kap = (1 - lam) / 2
        H_direct = -(lam * math.log(lam) + 2 * kap * math.log(kap))
        assert abs(H - H_direct) < 1e-12

    def test_price_of_structure(self):
        p = price_of_structure()
        assert 0.15 < p < 0.16


# =============================================================================
# Theorem FA: Fibonacci square generating function
# =============================================================================

class TestTheoremFA:
    def test_denominator_is_conservation_poly(self):
        assert fibonacci_square_gf_denominator() == (1, -3, 1)

    def test_generating_function(self):
        def fib(n):
            a, b = 0, 1
            for _ in range(n):
                a, b = b, a + b
            return a

        # Convergence radius = 1/phi^2 ~ 0.382; use small x
        x = 0.1
        gf = x * (1 + x) / (1 - 3 * x + x ** 2)
        # F(n)^2 * 0.1^n converges slowly; verify recurrence instead
        # F(n+1)^2 = 3*F(n)^2 - F(n-1)^2 + 2*(-1)^n
        for n in range(2, 20):
            lhs = fib(n + 1) ** 2
            rhs = 3 * fib(n) ** 2 - fib(n - 1) ** 2 + 2 * (-1) ** n
            assert lhs == rhs


# =============================================================================
# Theorems FJ, FW: Kaleidoscope bridges
# =============================================================================

class TestKaleidoscopeBridges:
    def test_seq1_is_mersenne_trace(self):
        for n_idx in range(1, 10):
            s1, tr = seq1_is_universal_trace(n_idx)
            assert s1 == 2 ** (n_idx + 1) - 1
            assert s1 == tr

    def test_seq9_is_lucas_trace(self):
        lucas_even = [3, 7, 18, 47, 123, 322, 843, 2207]
        for k, expected in enumerate(lucas_even, start=1):
            assert seq9_is_lucas_trace(k) == expected


# =============================================================================
# Theorems FN, FO: Golden nome and theta-trace uniqueness
# =============================================================================

class TestGoldenNome:
    def test_golden_nome_value(self):
        assert abs(golden_nome() - 1.0 / PHI_SQUARED) < 1e-14

    def test_theta_trace_holds_for_n3(self):
        assert theta_trace_identity_holds(3)

    def test_theta_trace_fails_for_n4(self):
        assert not theta_trace_identity_holds(4)


# =============================================================================
# Theorem FV: Bridge field unit norms
# =============================================================================

class TestTheoremFV:
    def test_all_norms_equal_1(self):
        norms = bridge_field_unit_norms()
        for name, val in norms.items():
            assert abs(val - 1.0) < 1e-8, f"{name} norm = {val}"


# =============================================================================
# Integration: verify_all
# =============================================================================

# =============================================================================
# Theorem GC: E8 Coxeter = bridge field period
# =============================================================================

# =============================================================================
# Theorem GG: Pell-Galois Bridge
# =============================================================================

# =============================================================================
# Theorem GK: Discriminant 2-adic valuation
# =============================================================================

class TestTheoremGK:
    def test_odd_n_valuation_zero(self):
        from watkins_nn.nacci_trace import conservation_poly_discriminant_v2
        for n in [3, 5, 7, 9, 11]:
            assert conservation_poly_discriminant_v2(n) == 0

    def test_even_n_valuation(self):
        from watkins_nn.nacci_trace import conservation_poly_discriminant_v2
        expected = {4: 4, 6: 8, 8: 12, 10: 16, 12: 20}
        for n, v2 in expected.items():
            assert conservation_poly_discriminant_v2(n) == v2


# =============================================================================
# Theorem GO: Crown Jewel — self-referential factorization
# =============================================================================

# =============================================================================
# Theorems GQ-GV: Self-Composition Tower
# =============================================================================

class TestSelfCompositionTower:
    def test_degrees_are_mersenne(self):
        from watkins_nn.nacci_trace import tower_degree
        assert tower_degree(0) == 3     # 2^2 - 1
        assert tower_degree(1) == 7     # 2^3 - 1
        assert tower_degree(2) == 15    # 2^4 - 1
        assert tower_degree(3) == 31    # 2^5 - 1

    def test_palindromic(self):
        from watkins_nn.nacci_trace import tower_is_palindromic
        for K in range(3):
            assert tower_is_palindromic(K)

    def test_divisibility_chain(self):
        from watkins_nn.nacci_trace import tower_divisibility
        for K in range(2):
            assert tower_divisibility(K)

    def test_k0_is_crown_jewel(self):
        from watkins_nn.nacci_trace import self_composition_tower
        # P_0 = (x+1)*C_3(x) = x^3 - 2x^2 - 2x + 1... wait
        # Actually P_0 = (x+1)*C_3(x) = (x+1)(x^2-3x+1) = x^3-2x^2-2x+1
        p0 = self_composition_tower(0)
        assert p0 == [1, -2, -2, 1]

    def test_k1_is_crown_jewel(self):
        from watkins_nn.nacci_trace import self_composition_tower
        # P_1 = (x+1)*C_3(x)*C_3(x^2) — the Sprint 31 crown jewel
        p1 = self_composition_tower(1)
        assert p1 == [1, -2, -5, 7, 7, -5, -2, 1]

    def test_k2_degree_15(self):
        from watkins_nn.nacci_trace import self_composition_tower, tower_degree
        p2 = self_composition_tower(2)
        assert len(p2) - 1 == tower_degree(2) == 15


# =============================================================================
# Theorem GO: Crown Jewel (existing)
# =============================================================================

class TestTheoremGO:
    def test_factorization_product(self):
        from watkins_nn.nacci_trace import specialization_recurrence_factors
        f1, f2, f3 = specialization_recurrence_factors()
        product = np.convolve(np.convolve(f1, f2), f3)
        expected = [1, -2, -5, 7, 7, -5, -2, 1]
        assert list(np.round(product).astype(int)) == expected

    def test_roots_are_golden_powers(self):
        from watkins_nn.nacci_trace import specialization_recurrence_factors
        f1, f2, f3 = specialization_recurrence_factors()
        product = np.convolve(np.convolve(f1, f2), f3)
        roots = sorted(np.roots(product[::-1]).real)
        expected = sorted([-PHI, -1, -1 / PHI, 1 / PHI_SQUARED,
                           1 / PHI, PHI, PHI_SQUARED])
        for r, e in zip(roots, expected):
            assert abs(r - e) < 1e-8

    def test_disc3_is_5(self):
        # disc(C_3) = 5 — the seed of everything
        coeffs = [1, -3, 1]
        disc = 9 - 4  # b^2 - 4ac for ax^2+bx+c
        assert disc == 5


# =============================================================================
# Theorem GG: Pell-Galois Bridge
# =============================================================================

# =============================================================================
# Theorem GP: Hankel-Discriminant Bridge
# =============================================================================

# =============================================================================
# Theorem HD: Conservation poly derivative at roots = sqrt(5)
# =============================================================================

class TestTheoremHD:
    def test_derivative_at_phi_squared(self):
        from watkins_nn.nacci_trace import conservation_poly_derivative_at_roots
        pos, neg = conservation_poly_derivative_at_roots()
        assert abs(pos - math.sqrt(5)) < 1e-14
        assert abs(neg + math.sqrt(5)) < 1e-14

    def test_direct_computation(self):
        # C_3'(t) = 2t - 3. At t = phi^2: 2*phi^2 - 3 = 2(phi+1) - 3 = 2phi-1 = sqrt(5)
        assert abs(2 * PHI_SQUARED - 3 - math.sqrt(5)) < 1e-14

    def test_hessian_det(self):
        from watkins_nn.nacci_trace import hessian_clean_forms
        h = hessian_clean_forms()
        det_check = h["H11"] * h["H22"] - h["H12"] ** 2
        assert abs(det_check - h["det"]) < 1e-6


class TestTheoremGP:
    def test_odd_n_ratio_minus_1(self):
        from watkins_nn.nacci_trace import hankel_determinant, conservation_poly_discriminant_v2
        for n in [3, 5, 7, 9]:
            H = hankel_determinant(n)
            # For odd n: disc(C_n) = -H (up to sign from disc computation)
            # Just check |H| is nonzero and well-defined
            assert H != 0

    def test_hankel_n3_equals_minus_5(self):
        from watkins_nn.nacci_trace import hankel_determinant
        assert hankel_determinant(3) == -5  # disc(C_3) = 5 = -(-5)


# =============================================================================
# Theorem GO: Crown Jewel (already tested above)
# =============================================================================

# =============================================================================
# Theorem GG: Pell-Galois Bridge
# =============================================================================

class TestTheoremGG:
    def test_pell_unit_norm(self):
        from watkins_nn.nacci_trace import pell_unit_as_qbiquad
        a, b, c, d = pell_unit_as_qbiquad()
        assert a == 4.0 and d == 1.0
        # Norm: (4+sqrt(15))*(4-sqrt(15)) = 16-15 = 1
        assert abs((a + d * math.sqrt(15)) * (a - d * math.sqrt(15)) - 1.0) < 1e-10


# =============================================================================
# Theorem GI: Discriminant = field norm squared
# =============================================================================

class TestTheoremGI:
    @pytest.mark.parametrize("n", range(1, 13))
    def test_discriminant_norm(self, n):
        from watkins_nn.nacci_trace import discriminant_is_field_norm
        delta, five_f_sq = discriminant_is_field_norm(n)
        assert delta == five_f_sq


# =============================================================================
# Theorem GC: E8 Coxeter = bridge field period
# =============================================================================

class TestTheoremGC:
    def test_h_e8_equals_lcm(self):
        from watkins_nn.nacci_trace import e8_coxeter_is_bridge_period
        data = e8_coxeter_is_bridge_period()
        assert data["h_E8"] == data["lcm_5_6"] == 30

    def test_a29_has_both_embeddings(self):
        n = 30
        found_phi2 = any(
            abs(2 - 2 * math.cos(k * math.pi / n) - PHI_SQUARED) < 1e-10
            for k in range(1, n)
        )
        found_sqrt3 = any(
            abs(2 - 2 * math.cos(k * math.pi / n) - (2 - math.sqrt(3))) < 1e-10
            for k in range(1, n)
        )
        assert found_phi2 and found_sqrt3


# =============================================================================
# Theorem GD: C_3(3) = 1 = det(Cartan(E_8))
# =============================================================================

class TestTheoremGD:
    def test_conservation_at_conservation(self):
        from watkins_nn.nacci_trace import conservation_at_conservation
        assert conservation_at_conservation() == 1

    def test_matches_poly_evaluation(self):
        assert round(conservation_poly(3, 3.0)) == 1


# =============================================================================
# Theorem GE: h(E7) = 18 = L(6)
# =============================================================================

class TestTheoremGE:
    def test_e7_coxeter_is_lucas(self):
        from watkins_nn.nacci_trace import e7_coxeter_is_lucas
        h, k = e7_coxeter_is_lucas()
        assert h == 18
        assert trace(3, k) == h


# =============================================================================
# Theorem GF: C_3 at Lucas numbers
# =============================================================================

class TestTheoremGF:
    def test_formula(self):
        from watkins_nn.nacci_trace import conservation_at_lucas
        for k in range(1, 10):
            L_k = trace(3, k)
            direct = L_k ** 2 - 3 * L_k + 1
            formula = conservation_at_lucas(k)
            assert direct == formula

    def test_special_cases(self):
        from watkins_nn.nacci_trace import conservation_at_lucas
        assert conservation_at_lucas(2) == 1   # det(E_8)
        assert conservation_at_lucas(3) == 5   # discriminant
        assert conservation_at_lucas(4) == 29  # L(7)


# =============================================================================
# Theorem GF-5: The 11ths Theorem — C_3(L(5)) = F(L(5))
# =============================================================================

class TestEleventhsTheorem:
    def test_c3_l5_equals_89(self):
        from watkins_nn.nacci_trace import elevenths_theorem
        result = elevenths_theorem(5)
        assert result["C3_L_n"] == 89
        assert result["F_L_n"] == 89
        assert result["match"] is True

    def test_chain_values(self):
        from watkins_nn.nacci_trace import elevenths_theorem
        from watkins_nn.kaleidoscope import fibonacci
        assert fibonacci(5) == 5
        result = elevenths_theorem(5)
        assert result["L_n"] == 11
        assert result["C3_L_n"] == 89
        assert fibonacci(11) == 89

    def test_uniqueness_small(self):
        from watkins_nn.nacci_trace import elevenths_theorem
        for n in [2, 3, 4, 6, 7, 8]:
            result = elevenths_theorem(n)
            assert result["match"] is False, f"Unexpected match at n={n}"

    def test_uniqueness_search(self):
        from watkins_nn.nacci_trace import elevenths_uniqueness
        hits = elevenths_uniqueness(max_n=15)
        assert hits == [5]

    def test_individual_non_matches(self):
        from watkins_nn.nacci_trace import elevenths_theorem
        r2 = elevenths_theorem(2)
        assert r2["L_n"] == 3 and r2["C3_L_n"] == 1 and r2["F_L_n"] == 2
        r3 = elevenths_theorem(3)
        assert r3["L_n"] == 4 and r3["C3_L_n"] == 5 and r3["F_L_n"] == 3
        r4 = elevenths_theorem(4)
        assert r4["L_n"] == 7 and r4["C3_L_n"] == 29 and r4["F_L_n"] == 13


# =============================================================================
# Integration: verify_all
# =============================================================================

# =============================================================================
# Theorems HI-HL: Galois groups
# =============================================================================

# =============================================================================
# Theorem HM: C_3 at Coxeter numbers are prime
# =============================================================================

# =============================================================================
# Theorem HQ: C_3 at Mersenne values factors through A_4 eigenvalues
# =============================================================================

# =============================================================================
# Theorem HT: Critical band and HU: Lyapunov exponent
# =============================================================================

# =============================================================================
# Theorems HV-HX: Mandelbrot, 3-cycles, Lyapunov = half log disc
# =============================================================================

# =============================================================================
# Theorem HY: Cycle multipliers contain Mersenne numbers
# =============================================================================

class TestCycleMultipliers:
    def test_period1_multiplier(self):
        # Fixed points: 2+/-sqrt(3). Multiplier = prod C_3'(t)
        import math as m
        s3 = m.sqrt(3)
        mult = (2*(2+s3)-3) * (2*(2-s3)-3)
        assert round(mult) == -11

    def test_period2_is_mersenne(self):
        import math as m
        s2 = m.sqrt(2)
        mult = (2*(1+s2)-3) * (2*(1-s2)-3)
        assert round(mult) == -7  # = -(2^3 - 1) = -M_3

    def test_period3_first_cycle(self):
        roots = np.roots([1, -3, 0, 1])
        mult = round(np.prod([2*r - 3 for r in roots]).real)
        assert mult == 19


# =============================================================================
# Theorems HV-HX: Mandelbrot, 3-cycles, Lyapunov
# =============================================================================

class TestMandelbrotAndCycles:
    def test_mandelbrot_parameter(self):
        from watkins_nn.nacci_trace import c3_mandelbrot_parameter
        c = c3_mandelbrot_parameter()
        assert c == -1.25
        # c = -disc/4 = -5/4
        assert abs(c - (-5.0 / 4.0)) < 1e-14

    def test_conjugacy(self):
        # C_3(x + 3/2) = x^2 - 5/4
        x = 0.7
        lhs = (x + 1.5) ** 2 - 3 * (x + 1.5) + 1
        rhs = x ** 2 - 1.25
        assert abs(lhs - rhs) < 1e-12

    def test_period3_cubics(self):
        from watkins_nn.nacci_trace import c3_period3_fields
        f1, f2 = c3_period3_fields()
        assert "Q(cos(pi/9))" in f1

    def test_lyapunov_half_log_disc(self):
        from watkins_nn.nacci_trace import c3_lyapunov_is_half_log_disc
        lam = c3_lyapunov_is_half_log_disc()
        assert abs(lam - math.log(5) / 2) < 1e-14
        # Also: = ln(sqrt(5)) = ln|C_3'(phi^2)|
        assert abs(lam - math.log(math.sqrt(5))) < 1e-14

    def test_bifurcation_multiplier(self):
        # At c = -5/4, the 2-cycle has multiplier -1
        # 2-cycle of x^2 + c: solve x^2 + x + c + 1 = 0 → x^2 + x - 1/4 = 0
        # Product of derivatives at cycle: 4*c + 4 = 4*(-5/4) + 4 = -1
        c = -5.0 / 4.0
        multiplier = 4 * c + 4
        assert abs(multiplier - (-1.0)) < 1e-14


class TestCriticalBandAndLyapunov:
    def test_t_star_in_critical_band(self):
        from watkins_nn.nacci_trace import c3_critical_band
        lo, hi, depth = c3_critical_band()
        from watkins_nn.constants import T_STAR
        assert lo < T_STAR < hi
        assert depth > 0.98  # 98.8% of max depth

    def test_lyapunov_positive(self):
        from watkins_nn.nacci_trace import c3_lyapunov_at_roots
        lam = c3_lyapunov_at_roots()
        assert lam > 0  # expanding
        assert abs(lam - math.log(5) / 2) < 1e-14


# =============================================================================
# Theorem HQ: C_3 at Mersenne values factors through A_4 eigenvalues
# =============================================================================

class TestTheoremHQ:
    @pytest.mark.parametrize("k", range(1, 8))
    def test_factorization(self, k):
        from watkins_nn.nacci_trace import c3_at_mersenne_factored
        f1, f2 = c3_at_mersenne_factored(k)
        direct = (2**k - 1)**2 - 3*(2**k - 1) + 1
        assert abs(f1 * f2 - direct) < 1e-6


# =============================================================================
# Theorem HR: Fixed points of C_3 = Q(sqrt(3)) units
# =============================================================================

class TestTheoremHR:
    def test_fixed_points(self):
        from watkins_nn.nacci_trace import c3_fixed_points
        fp1, fp2 = c3_fixed_points()
        # C_3(fp) = fp
        assert abs(fp1**2 - 3*fp1 + 1 - fp1) < 1e-10
        assert abs(fp2**2 - 3*fp2 + 1 - fp2) < 1e-10


# =============================================================================
# Theorem HS: 2-cycle of C_3 involves Q(sqrt(2))
# =============================================================================

class TestTheoremHS:
    def test_two_cycle(self):
        from watkins_nn.nacci_trace import c3_two_cycle
        a, b = c3_two_cycle()
        # C_3(a) = b, C_3(b) = a
        assert abs(a**2 - 3*a + 1 - b) < 1e-10
        assert abs(b**2 - 3*b + 1 - a) < 1e-10

    def test_three_fields(self):
        from watkins_nn.nacci_trace import c3_dynamical_portrait
        p = c3_dynamical_portrait()
        assert p["roots_field"] == "Q(sqrt(5))"
        assert p["fixed_field"] == "Q(sqrt(3))"
        assert p["twocycle_field"] == "Q(sqrt(2))"
        assert p["compositum_degree"] == "8"


# =============================================================================
# Theorem HM: C_3 at Coxeter numbers are prime
# =============================================================================

class TestCoxeterPrimality:
    def test_all_prime_for_h_ge_4(self):
        from watkins_nn.nacci_trace import coxeter_primality
        from sympy import isprime
        vals = coxeter_primality()
        for h, v in vals.items():
            if h >= 4:
                assert isprime(v), f"C_3({h}) = {v} should be prime"

    def test_c3_at_3_is_1(self):
        from watkins_nn.nacci_trace import coxeter_primality
        assert coxeter_primality()[3] == 1


# =============================================================================
# Theorem HO: h(E8) = F(3)*F(4)*F(5)
# =============================================================================

class TestE8Fibonacci:
    def test_product(self):
        from watkins_nn.nacci_trace import e8_fibonacci_factorization
        f3, f4, f5 = e8_fibonacci_factorization()
        assert f3 * f4 * f5 == 30


# =============================================================================
# Theorems GW, GZ: Hankel engine
# =============================================================================

class TestHankelEngine:
    def test_lucas_hankel_rank_2(self):
        from watkins_nn.nacci_trace import lucas_hankel_rank
        assert lucas_hankel_rank() == 2

    def test_lucas_hankel_det_2_is_5(self):
        H = np.array([[trace(3, 2), trace(3, 3)],
                       [trace(3, 3), trace(3, 4)]])
        assert round(np.linalg.det(H)) == 5  # = disc(C_3)

    def test_discriminant_via_hankel(self):
        from watkins_nn.nacci_trace import discriminant_via_hankel
        # Known: |disc(P_3)| = 5, |disc(P_4)| = 44, |disc(P_5)| = 563
        assert discriminant_via_hankel(3) == 5
        assert discriminant_via_hankel(4) == 44
        assert discriminant_via_hankel(5) == 563


# =============================================================================
# Theorems HI-HL: Galois groups
# =============================================================================

class TestGaloisGroups:
    def test_known_groups(self):
        from watkins_nn.nacci_trace import conservation_poly_galois_group
        assert conservation_poly_galois_group(3) == "Z/2Z"
        assert conservation_poly_galois_group(4) == "S_3"
        assert conservation_poly_galois_group(5) == "S_4"
        assert conservation_poly_galois_group(6) == "S_5"

    def test_no_rational_roots(self):
        """Theorem HK: C_n has no rational roots."""
        for n in range(3, 15):
            coeffs = conservation_poly_coefficients(n)
            c_at_1 = sum(coeffs)
            c_at_m1 = sum(c * (-1) ** (len(coeffs) - 1 - i) for i, c in enumerate(coeffs))
            assert c_at_1 != 0 and c_at_m1 != 0

    def test_disc_not_square(self):
        """Theorem HJ: disc(C_n) is never a perfect square."""
        from watkins_nn.nacci_trace import hankel_determinant
        for n in [3, 5, 7, 9, 11]:
            H = hankel_determinant(n)
            disc = -H  # For odd n: disc = -H
            if disc > 0:
                assert int(math.isqrt(disc)) ** 2 != disc


# =============================================================================
# Theorems GC-GI: Fibonacci Tower Identities (F(9) = 34)
# =============================================================================

class TestFibonacciTowerGC:
    """GC: F(9) = W(8) + 3."""

    def test_identity(self):
        r = fibonacci_tower_identity()
        assert r['identity_holds']

    def test_values(self):
        r = fibonacci_tower_identity()
        assert r['F_9'] == 34
        assert r['W_8'] == 31
        assert r['N'] == 3

    def test_34_is_fibonacci(self):
        """34 is the 9th Fibonacci number."""
        fibs = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
        assert fibs[9] == 34

    def test_general_pattern(self):
        """Check F(2k+1) vs W(2k) for several k."""
        fibs = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]
        # k=4: F(9)=34, W(8)=31, diff=3
        assert fibs[9] - (4 * 8 - 1) == 3


class TestTraceEmbedsWatkinsGD:
    """GD: trace(34, 5) = 31 = W(8)."""

    def test_embedding(self):
        r = trace_embeds_watkins()
        assert r['embedded']

    def test_trace_value(self):
        assert trace(34, 5) == 31

    def test_mersenne_mechanism(self):
        """trace(34, 5) = 2^5 - 1 = 31 (Mersenne, since 5 < 34)."""
        assert trace(34, 5) == 2**5 - 1

    def test_31_is_W8(self):
        assert 4 * 8 - 1 == 31


class TestSelfTraceUnificationGE:
    """GE: trace(F(9), F(9)) = 2^F(9) - W(9)."""

    def test_identity(self):
        r = self_trace_unification()
        assert r['identity_holds']

    def test_numerical_value(self):
        """trace(34, 34) = 2^34 - 35 = 17,179,869,149."""
        assert trace(34, 34) == 2**34 - 35

    def test_w9_connection(self):
        """W(9) = 35 = F(9) + 1."""
        assert 4 * 9 - 1 == 35
        assert 34 + 1 == 35

    def test_general_self_trace(self):
        """For any n, trace(n, n) = 2^n - n - 1 (Theorem EV)."""
        for n in [3, 5, 8, 13, 21, 34]:
            assert trace(n, n) == 2**n - n - 1


class TestFibonacciDepartureSelfRefGF:
    """GF: departure(34, 0) = F(9), departure(34, 2) = F(12)."""

    def test_self_reference(self):
        r = fibonacci_departure_self_reference()
        assert r['self_reference']

    def test_fibonacci_at_j2(self):
        r = fibonacci_departure_self_reference()
        assert r['fibonacci_at_j2']

    def test_departure_0_is_34(self):
        assert departure(34, 0) == 34

    def test_departure_2_is_144(self):
        assert departure(34, 2) == 144

    def test_144_is_fibonacci(self):
        """144 = F(12) = 12^2."""
        fibs = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]
        assert fibs[12] == 144
        assert 12**2 == 144


class TestPalindromicNormGG:
    """GG: F(9)-nacci has positive norm (+1), W(8)-nacci has negative (-1)."""

    def test_fibonacci_palindromic(self):
        r = palindromic_norm_theorem()
        assert r['fibonacci_palindromic']

    def test_watkins_anti_palindromic(self):
        r = palindromic_norm_theorem()
        assert r['watkins_anti_palindromic']

    def test_even_gives_positive(self):
        """(-1)^34 = +1."""
        assert (-1)**34 == 1

    def test_odd_gives_negative(self):
        """(-1)^31 = -1."""
        assert (-1)**31 == -1

    def test_numerical_product_of_roots(self):
        """Verify with actual root computation for smaller Fibonacci numbers."""
        # F(7) = 13 (odd) -> norm = -1
        roots_13 = nacci_all_roots(13)
        prod_13 = np.prod(roots_13).real
        assert abs(prod_13 - (-1)**13) < 1e-4


class TestAsymmetryTriadFactoringGH:
    """GH: 34-node tower has 33 = 3 x 11 asymmetry modes."""

    def test_triad_times_elevenths(self):
        r = asymmetry_triad_factoring()
        assert r['triad_times_elevenths']

    def test_33_factors(self):
        assert 33 == 3 * 11

    def test_30_factors(self):
        """31-node: 30 = 3 x 10 (no 11ths connection)."""
        assert 30 == 3 * 10

    def test_11_is_W3(self):
        """11 = W(3) = 4*3 - 1."""
        assert 4 * 3 - 1 == 11

    def test_3_is_conservation_number(self):
        assert CONSERVATION_TRACE == 3


class TestBridgeConservationGI:
    """GI: Bridge weights satisfy lambda + kappa + eta = 1."""

    def test_conservation_holds(self):
        r = bridge_conservation()
        assert r['conservation_holds']

    def test_bridge_sum_is_one(self):
        r = bridge_conservation()
        assert abs(r['bridge_sum'] - 1.0) < 1e-14

    def test_lambda_bridge_is_phi_inv(self):
        r = bridge_conservation()
        assert abs(r['lambda_bridge'] - 1.0 / PHI) < 1e-14

    def test_kappa_eta_equal(self):
        """Symmetric: kappa_bridge = eta_bridge."""
        r = bridge_conservation()
        assert abs(r['kappa_bridge'] - r['eta_bridge']) < 1e-14

    def test_golden_identity_mechanism(self):
        """1/phi + 1/phi^2 = 1 (fundamental golden ratio identity)."""
        assert abs(1.0/PHI + 1.0/PHI_SQUARED - 1.0) < 1e-14

    def test_tower_decomposition(self):
        """34 = 3 x 11 + 1."""
        assert 3 * 11 + 1 == 34


# =============================================================================
# Integration: verify_all
# =============================================================================

# =============================================================================
# Theorem GJ: Baryon Asymmetry from F(9) Tower
# =============================================================================

class TestBaryonAsymmetryGJ:
    """GJ: η_B = 1/φ^(485/11) from spectral structure of 34-node tower."""

    def test_exponent_derivation(self):
        """485 = C(34,2) - L(9) = 561 - 76."""
        r = baryon_asymmetry_exponent()
        assert r['binomial_C_34_2'] == 561
        assert r['L_9'] == 76
        assert r['asymmetry'] == 485

    def test_divisor_is_clock_period(self):
        """11 = L(5) = W(3)."""
        r = baryon_asymmetry_exponent()
        assert r['L_5'] == 11
        assert 4 * 3 - 1 == 11

    def test_lucas_square_identity(self):
        """485 = 4 × 11² + 1 = 4 × L(5)² + 1."""
        r = baryon_asymmetry_exponent()
        assert r['lucas_square_identity']
        assert 4 * 11**2 + 1 == 485

    def test_fibonacci_product_identity(self):
        """485 = F(5) × (3·F(9) - F(5)) = 5 × 97."""
        r = baryon_asymmetry_exponent()
        assert r['fibonacci_product_identity']
        assert 5 * 97 == 485
        assert 3 * 34 - 5 == 97

    def test_continued_fraction(self):
        """485/11 = 44 + 1/11 = [44; 11]."""
        r = baryon_asymmetry_exponent()
        assert r['continued_fraction'] == (44, 11)
        assert 44 * 11 + 1 == 485

    def test_within_planck_1sigma(self):
        """Predicted η_B matches Planck 2018 within 1-sigma."""
        r = baryon_asymmetry_exponent()
        assert r['within_1sigma']
        assert r['residual_sigma'] < 1.0

    def test_residual_sub_percent(self):
        """Agreement better than 0.1%."""
        r = baryon_asymmetry_exponent()
        assert r['residual_percent'] < 0.1

    def test_eta_b_order_of_magnitude(self):
        """η_B ~ 6 × 10⁻¹⁰."""
        r = baryon_asymmetry_exponent()
        assert 5e-10 < r['eta_B'] < 7e-10

    def test_exponent_value(self):
        """485/11 ≈ 44.0909..."""
        r = baryon_asymmetry_exponent()
        assert abs(r['exponent'] - 485/11) < 1e-14

    def test_561_is_pairwise_couplings(self):
        """C(34,2) = 561 = pairwise couplings in 34-node tower."""
        assert 34 * 33 // 2 == 561

    def test_97_is_prime(self):
        """97 = 3·F(9) - F(5) is the 25th prime."""
        n = 97
        assert all(n % i != 0 for i in range(2, int(n**0.5) + 1))

    def test_lucas_values(self):
        """Verify Lucas numbers used in derivation."""
        assert _lucas(5) == 11
        assert _lucas(9) == 76


class TestBaryonUniqueness:
    """The Lucas-square form holds only at n=9."""

    def test_unique_at_9(self):
        hits = baryon_uniqueness(max_n=15)
        assert hits == [9]

    def test_not_at_8(self):
        """n=8: doesn't satisfy Lucas-square form."""
        assert 21 * 20 // 2 - _lucas(8) != 4 * _lucas(4)**2 + 1

    def test_not_at_10(self):
        """n=10: doesn't satisfy Lucas-square form."""
        assert 55 * 54 // 2 - _lucas(10) != 4 * _lucas(5)**2 + 1


# =============================================================================
# Theorems GK-GP: L-function Connection
# =============================================================================

class TestNormFormGK:
    """GK: C_3(t) = N_{Q(√5)/Q}(t - φ²)."""

    def test_all_match(self):
        r = norm_form_theorem()
        assert r['all_match']

    def test_specific_values(self):
        """C_3(0)=1, C_3(1)=-1, C_3(3)=1, C_3(4)=5."""
        for t, expected in [(0, 1), (1, -1), (3, 1), (4, 5)]:
            assert t*t - 3*t + 1 == expected

    def test_norm_is_product_of_conjugates(self):
        """N(t-φ²) = (t-φ²)(t-φ̄²) for all t."""
        phi2 = PHI**2
        phibar2 = ((1 - math.sqrt(5))/2)**2
        for t in range(20):
            norm = (t - phi2) * (t - phibar2)
            c3 = t*t - 3*t + 1
            assert abs(norm - c3) < 1e-10


class TestPrimeSplittingGL:
    """GL: C_3 governs prime splitting in Q(√5)."""

    def test_all_consistent(self):
        r = prime_splitting_theorem(max_p=50)
        assert r['all_consistent']

    def test_5_ramifies(self):
        """p=5: disc=5, ramified. C_3(5)=11, 11 mod 5 = 1."""
        assert _kronecker_5(5) == 0
        assert (5*5 - 3*5 + 1) == 11

    def test_11_splits(self):
        """p=11: (5|11)=1, splits. C_3 has root mod 11."""
        assert _kronecker_5(11) == 1
        assert any((t*t - 3*t + 1) % 11 == 0 for t in range(11))

    def test_7_inert(self):
        """p=7: (5|7)=-1, inert. C_3 has no root mod 7."""
        assert _kronecker_5(7) == -1
        assert not any((t*t - 3*t + 1) % 7 == 0 for t in range(7))

    def test_kronecker_5_values(self):
        """χ_5 cycle: 0,1,-1,-1,1 for residues 0,1,2,3,4."""
        assert [_kronecker_5(n) for n in range(5)] == [0, 1, -1, -1, 1]


class TestDedekindZetaGM:
    """GM: ζ_{Q(√5)}(s) = ζ(s) · L(s, χ₅)."""

    def test_factorization(self):
        r = dedekind_zeta_factorization()
        assert r['match']

    def test_zeta_2_known(self):
        """ζ(2) = π²/6."""
        r = dedekind_zeta_factorization()
        assert abs(r['zeta_2'] - math.pi**2/6) < 1e-3


class TestRegulatorGN:
    """GN: L(1, χ₅) = 2·ln(φ)/√5."""

    def test_identity(self):
        r = regulator_identity()
        assert r['match']

    def test_class_number_one(self):
        r = regulator_identity()
        assert r['class_number'] == 1

    def test_regulator_value(self):
        """R = 2·ln(φ) ≈ 0.9624."""
        r = regulator_identity()
        assert abs(r['R'] - 2*math.log(PHI)) < 1e-14


class TestTemperatureRegulatorGO:
    """GO: T* · R = 2φ·ln(φ)/ln(2φ)."""

    def test_identity(self):
        r = temperature_regulator_identity()
        assert r['match']

    def test_T_star_value(self):
        r = temperature_regulator_identity()
        assert abs(r['T_star'] - PHI/math.log(2*PHI)) < 1e-14

    def test_product_is_algebraic_in_phi(self):
        """T* · R involves only φ and logarithms — no transcendental mysteries."""
        T_star = PHI / math.log(2*PHI)
        R = 2 * math.log(PHI)
        product = T_star * R
        predicted = 2 * PHI * math.log(PHI) / math.log(2*PHI)
        assert abs(product - predicted) < 1e-14


class TestLFunctionBaryonGP:
    """GP: The full chain C_3 → Q(√5) → ζ_{Q(√5)} → R → T* → F(9) → η_B."""

    def test_chain_exists(self):
        r = l_function_at_baryon()
        assert r['class_number'] == 1
        assert r['splitting_field'] == 'Q(√5) = Q(φ)'
        assert abs(r['eta_B'] - 6.103e-10) < 0.01e-10

    def test_norm_form_stated(self):
        r = l_function_at_baryon()
        assert 'N_{Q(√5)/Q}' in r['norm_form']

    def test_T_star_times_R(self):
        """T* · R is well-defined and positive."""
        r = l_function_at_baryon()
        assert r['T_star_times_R'] > 0


class TestVerifyAll:
    def test_all_pass(self):
        results = verify_all(max_n=8)
        failures = {k: v for k, v in results.items() if not v}
        assert not failures, f"Failed: {failures}"
