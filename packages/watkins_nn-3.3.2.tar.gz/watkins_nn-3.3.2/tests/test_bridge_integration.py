"""Tests for the bridge_integration module.

Tests cover:
- Bilateral network construction (Theorem IA prerequisites)
- Automorphism group computation and V₄ identification
- Bipartition enumeration and orbit decomposition
- Mutual information computation (Gaussian)
- Theorem IA: V₄ structure of bilateral networks (n=1,2,3)
- Theorem IB: MI ordering (sweep + specific cases)
- Theorem IC: Galois correspondence with bridge_field.py
- Universality criterion (classification of bridge systems)
- Full analysis pipeline
"""

import math
import numpy as np
import pytest

from watkins_nn.bridge_integration import (
    make_bilateral_network,
    compute_automorphisms,
    identify_group,
    enumerate_bipartitions,
    even_bipartitions,
    gaussian_mutual_information,
    partition_orbits,
    theorem_ia_v4_structure,
    theorem_ib_mi_ordering,
    theorem_ic_galois_correspondence,
    verify_mi_ordering_sweep,
    classify_bridge_system,
    run_full_analysis,
    MAX_NODES,
)
from watkins_nn.bridge_field import QBiquad, PHI_Q, SQRT15_Q


EPS = 1e-8


# -- Network Construction ---------------------------------------------------

class TestBilateralNetwork:

    def test_shape(self):
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        assert A.shape == (4, 4)

    def test_row_stochastic(self):
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        for i in range(4):
            assert abs(A[i].sum() - 1.0) < EPS

    def test_bilateral_symmetry(self):
        """A[L_i, L_j] = A[R_i, R_j] for corresponding nodes."""
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        # L1->L2 should equal R1->R2
        assert abs(A[0, 1] - A[2, 3]) < EPS
        # L1->R1 (callosal) should equal R1->L1
        assert abs(A[0, 2] - A[2, 0]) < EPS

    def test_no_diagonal_connections(self):
        """No heterotopic callosal connections (L1-R2, L2-R1) before normalisation."""
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        # L1 (0) should not directly connect to R2 (3), and vice versa
        # After normalisation the entry should be 0
        assert abs(A[0, 3]) < EPS
        assert abs(A[1, 2]) < EPS

    def test_max_nodes_enforced(self):
        with pytest.raises(ValueError, match="MAX_NODES"):
            make_bilateral_network(5, 0.3, 0.15, 0.1)  # N=10 > 8

    def test_n3_shape(self):
        A = make_bilateral_network(3, 0.3, 0.15, 0.1)
        assert A.shape == (6, 6)
        for i in range(6):
            assert abs(A[i].sum() - 1.0) < EPS


# -- Automorphism Group -----------------------------------------------------

class TestAutomorphisms:

    def test_identity_always_present(self):
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        auts = compute_automorphisms(A)
        assert (0, 1, 2, 3) in auts

    def test_four_automorphisms_bilateral_n2(self):
        """n=2 bilateral network should have exactly 4 automorphisms."""
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        auts = compute_automorphisms(A)
        assert len(auts) == 4

    def test_v4_identified(self):
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        auts = compute_automorphisms(A)
        group = identify_group(auts)
        assert group["is_V4"]
        assert group["group_name"] == "V_4 (Klein four-group)"

    def test_all_orders_at_most_2(self):
        """All non-identity V₄ elements have order 2."""
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        auts = compute_automorphisms(A)
        group = identify_group(auts)
        assert all(o <= 2 for o in group["orders"])

    def test_abelian(self):
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        auts = compute_automorphisms(A)
        group = identify_group(auts)
        assert group["is_abelian"]

    def test_multiplication_table_closes(self):
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        auts = compute_automorphisms(A)
        group = identify_group(auts)
        assert group["multiplication_table_valid"]

    def test_n1_gives_z2(self):
        """2-node bilateral (n=1) should be Z₂, not V₄."""
        A = make_bilateral_network(1, 0.3, 0.15, 0.1)
        auts = compute_automorphisms(A)
        group = identify_group(auts)
        assert group["size"] == 2
        assert not group["is_V4"]
        assert group["group_name"] == "Z_2"

    def test_isotropic_inflates_group(self):
        """When w_cal = w_intra, extra symmetry appears (group > V₄)."""
        A = make_bilateral_network(2, 0.4, 0.4, 0.1)
        auts = compute_automorphisms(A)
        group = identify_group(auts)
        assert group["size"] > 4


# -- Bipartitions ------------------------------------------------------------

class TestBipartitions:

    def test_count_n4(self):
        """4 nodes: 2^(4-1) - 1 = 7 non-trivial bipartitions."""
        bips = enumerate_bipartitions(4)
        assert len(bips) == 7

    def test_even_count_n4(self):
        """4 nodes: C(4,2)/2 = 3 even bipartitions."""
        evens = even_bipartitions(4)
        assert len(evens) == 3

    def test_even_sizes(self):
        for M, C in even_bipartitions(4):
            assert len(M) == 2
            assert len(C) == 2

    def test_canonical_form(self):
        """Node 0 is always in the first part."""
        for M, C in enumerate_bipartitions(4):
            assert 0 in M

    def test_no_evens_for_odd_n(self):
        assert even_bipartitions(3) == []


# -- MI Computation ----------------------------------------------------------

class TestMutualInformation:

    def test_mi_nonnegative(self):
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        from watkins_nn.bridge_integration import _solve_lyapunov
        Sigma = _solve_lyapunov(A)
        for M, C in enumerate_bipartitions(4):
            mi = gaussian_mutual_information(Sigma, M, C)
            assert mi >= -EPS

    def test_mi_symmetric(self):
        """MI(M; C) = MI(C; M)."""
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        from watkins_nn.bridge_integration import _solve_lyapunov
        Sigma = _solve_lyapunov(A)
        M = frozenset([0, 1])
        C = frozenset([2, 3])
        assert abs(
            gaussian_mutual_information(Sigma, M, C)
            - gaussian_mutual_information(Sigma, C, M)
        ) < EPS

    def test_mi_constant_on_orbits(self):
        """MI is constant within V₄ orbits (Theorem IA, claim d)."""
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        from watkins_nn.bridge_integration import _solve_lyapunov
        Sigma = _solve_lyapunov(A)
        auts = compute_automorphisms(A)
        bips = enumerate_bipartitions(4)
        orbits = partition_orbits(auts, bips)

        for orbit in orbits:
            mis = [gaussian_mutual_information(Sigma, M, C) for M, C in orbit]
            for mi in mis:
                assert abs(mi - mis[0]) < 1e-10, f"MI spread in orbit: {max(mis) - min(mis)}"


# -- Orbit Decomposition ----------------------------------------------------

class TestOrbits:

    def test_three_singleton_even_orbits(self):
        """V₄ action on 4-node even bipartitions gives 3 singleton orbits."""
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        auts = compute_automorphisms(A)
        evens = even_bipartitions(4)
        orbits = partition_orbits(auts, evens)
        assert len(orbits) == 3
        assert all(len(o) == 1 for o in orbits)

    def test_four_total_orbits(self):
        """All 7 bipartitions decompose into 4 orbits: [4, 1, 1, 1]."""
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        auts = compute_automorphisms(A)
        bips = enumerate_bipartitions(4)
        orbits = partition_orbits(auts, bips)
        assert len(orbits) == 4
        sizes = sorted(len(o) for o in orbits)
        assert sizes == [1, 1, 1, 4]


# -- Theorem IA --------------------------------------------------------------

class TestTheoremIA:

    def test_n2_is_v4(self):
        result = theorem_ia_v4_structure(2)
        assert result.is_v4
        assert result.even_partition_orbits == 3
        assert result.orbit_sizes == [1, 1, 1]

    def test_n2_different_weights(self):
        """V₄ holds across the non-degenerate weight range."""
        for w_i, w_c in [(0.4, 0.1), (0.5, 0.05), (0.2, 0.12)]:
            result = theorem_ia_v4_structure(2, w_intra=w_i, w_cal=w_c)
            assert result.is_v4, f"Failed for w_intra={w_i}, w_cal={w_c}"

    def test_n1_not_v4(self):
        result = theorem_ia_v4_structure(1)
        assert not result.is_v4

    def test_n3_full_symmetry_exceeds_v4(self):
        """n=3 with full intra-hemispheric symmetry gives |Aut| > 4."""
        result = theorem_ia_v4_structure(3)
        assert not result.is_v4
        assert result.group_info["size"] > 4


# -- Theorem IB --------------------------------------------------------------

class TestTheoremIB:

    def test_ordering_default_weights(self):
        """MI(hetero) < MI(hemi) < MI(homo) at default weights."""
        result = theorem_ib_mi_ordering()
        assert result.condition_met
        assert result.ordering_holds
        assert result.mi_heterotopic < result.mi_hemispheric < result.mi_homotopic

    def test_ordering_various_weights(self):
        """Ordering holds across the biological regime w_self < w_cal < w_intra."""
        cases = [
            (0.3, 0.15, 0.05),
            (0.4, 0.2, 0.1),
            (0.5, 0.3, 0.1),
            (0.25, 0.12, 0.05),
        ]
        for w_i, w_c, w_s in cases:
            result = theorem_ib_mi_ordering(w_i, w_c, w_s)
            assert result.condition_met, f"Condition not met: {w_s} < {w_c} < {w_i}"
            assert result.ordering_holds, (
                f"Ordering failed at w_i={w_i}, w_c={w_c}, w_s={w_s}: "
                f"MI(hetero)={result.mi_heterotopic:.6f}, "
                f"MI(hemi)={result.mi_hemispheric:.6f}, "
                f"MI(homo)={result.mi_homotopic:.6f}"
            )

    def test_three_distinct_mi_values(self):
        """The three even bipartitions have generically distinct MI."""
        result = theorem_ib_mi_ordering()
        assert abs(result.mi_hemispheric - result.mi_homotopic) > 0.01
        assert abs(result.mi_hemispheric - result.mi_heterotopic) > 0.01
        assert abs(result.mi_homotopic - result.mi_heterotopic) > 0.01

    def test_claim_b_mi_ordering_vs_w_cal_w_self(self):
        """MI(sigma_1) > MI(sigma_3) iff w_cal > w_self."""
        # Case 1: w_cal > w_self
        r1 = theorem_ib_mi_ordering(0.4, 0.2, 0.1)  # 0.2 > 0.1
        assert r1.mi_hemispheric > r1.mi_heterotopic

        # Case 2: w_cal < w_self
        r2 = theorem_ib_mi_ordering(0.4, 0.05, 0.15)  # 0.05 < 0.15
        assert r2.mi_hemispheric < r2.mi_heterotopic

    def test_degenerate_w_cal_equals_w_intra(self):
        """When w_cal = w_intra, MI(hemi) = MI(homo) (extra symmetry)."""
        result = theorem_ib_mi_ordering(0.4, 0.4, 0.1)
        assert abs(result.mi_hemispheric - result.mi_homotopic) < 1e-8


# -- Theorem IB Sweep --------------------------------------------------------

class TestTheoremIBSweep:

    def test_ordering_sweep(self):
        """Full parameter sweep: 0 violations under correct condition."""
        result = verify_mi_ordering_sweep()
        assert result["ordering_holds"], (
            f"Ordering violations: {result['ordering_violations']}/{result['ordering_tests']}"
        )
        assert result["ordering_tests"] > 100

    def test_claim_b_sweep(self):
        """Claim (b): MI(σ₁) > MI(σ₃) iff w_cal > w_self — zero violations."""
        result = verify_mi_ordering_sweep()
        assert result["claim_b_holds"], (
            f"Claim (b) violations: {result['claim_b_violations']}/{result['claim_b_tests']}"
        )
        assert result["claim_b_tests"] > 300


# -- Theorem IC --------------------------------------------------------------

class TestTheoremIC:

    def test_correspondence_verified(self):
        result = theorem_ic_galois_correspondence()
        assert result.correspondence_verified

    def test_sigma_fb_is_diagonal_swap(self):
        result = theorem_ic_galois_correspondence()
        assert result.sigma_FB == (3, 2, 1, 0)

    def test_algebraic_sigma2_fixes_phi(self):
        """sigma_2 (negates sqrt3) fixes phi which lives in Q(sqrt5)."""
        orbit = PHI_Q.galois_orbit
        assert abs(orbit[0] - orbit[1]) < 1e-12  # sigma2(phi) = phi

    def test_algebraic_sigma4_fixes_sqrt15(self):
        """sigma_4 (negates both sqrt3, sqrt5) fixes sqrt15."""
        orbit = SQRT15_Q.galois_orbit
        assert abs(orbit[0] - orbit[3]) < 1e-12  # sigma4(sqrt15) = sqrt15

    def test_algebraic_sigma3_fixes_sqrt3(self):
        """sigma_3 (negates sqrt5) fixes elements of Q(sqrt3)."""
        s3 = QBiquad(0, 1, 0, 0)  # sqrt(3)
        orbit = s3.galois_orbit
        assert abs(orbit[0] - orbit[2]) < 1e-12  # sigma3(sqrt3) = sqrt3

    def test_sigma_f_is_functional_swap(self):
        """sigma_F = (L1<->L2)(R1<->R2): swaps within hemispheres."""
        result = theorem_ic_galois_correspondence()
        sigma_F = result.sigma_F
        assert sigma_F == (1, 0, 3, 2)

    def test_sigma_b_is_bilateral_swap(self):
        """sigma_B = (L1<->R1)(L2<->R2): swaps between hemispheres."""
        result = theorem_ic_galois_correspondence()
        sigma_B = result.sigma_B
        assert sigma_B == (2, 3, 0, 1)


# -- Universality Criterion --------------------------------------------------

class TestClassification:

    def test_bilateral_n2_is_v4(self):
        A = make_bilateral_network(2, 0.3, 0.15, 0.1)
        result = classify_bridge_system(A)
        assert result["bridge_type"] == "V_4"
        assert result["is_bridge_system"]

    def test_directed_pipeline_is_trivial(self):
        """Directed pipeline has no symmetry."""
        A = np.array([
            [0.3, 0.0, 0.0],
            [0.5, 0.2, 0.0],
            [0.0, 0.5, 0.3],
        ])
        for i in range(3):
            A[i] /= A[i].sum()
        result = classify_bridge_system(A)
        assert result["bridge_type"] == "trivial"

    def test_symmetric_pair_is_z2(self):
        """Two symmetric nodes: Z₂, not V₄."""
        A = np.array([[0.3, 0.7], [0.7, 0.3]])
        result = classify_bridge_system(A)
        assert result["bridge_type"] == "Z_2"

    def test_ring_4_is_larger(self):
        """4-cycle ring has D₄ symmetry (size 8), contains V₄."""
        A = np.zeros((4, 4))
        for i in range(4):
            A[i, i] = 0.2
            A[i, (i + 1) % 4] = 0.4
            A[i, (i - 1) % 4] = 0.4
        for i in range(4):
            A[i] /= A[i].sum()
        result = classify_bridge_system(A)
        assert result["bridge_type"] == "larger_contains_V4"
        assert result["group"]["size"] == 8

    def test_asymmetric_bilateral_is_z2(self):
        """Breaking bilateral symmetry by different intra-hemispheric weights."""
        A = np.zeros((4, 4))
        A[0] = [0.1, 0.5, 0.15, 0]
        A[1] = [0.5, 0.1, 0, 0.15]
        A[2] = [0.15, 0, 0.1, 0.2]  # weaker R intra
        A[3] = [0, 0.15, 0.2, 0.1]
        for i in range(4):
            A[i] /= A[i].sum()
        result = classify_bridge_system(A)
        assert result["bridge_type"] == "Z_2"


# -- Full Analysis -----------------------------------------------------------

class TestFullAnalysis:

    def test_all_pass_default(self):
        result = run_full_analysis()
        assert result["all_pass"]

    def test_all_pass_various_weights(self):
        """Full analysis passes across the biological regime."""
        for w_i, w_c, w_s in [(0.4, 0.2, 0.1), (0.5, 0.3, 0.05)]:
            result = run_full_analysis(w_i, w_c, w_s)
            assert result["all_pass"], f"Failed at w_i={w_i}, w_c={w_c}, w_s={w_s}"

    def test_theorem_ia_in_result(self):
        result = run_full_analysis()
        assert result["theorem_ia"]["is_v4"]
        assert result["theorem_ia"]["even_partition_orbits"] == 3

    def test_theorem_ib_in_result(self):
        result = run_full_analysis()
        assert result["theorem_ib"]["ordering_holds"]
        assert result["theorem_ib"]["condition_met"]

    def test_theorem_ic_in_result(self):
        result = run_full_analysis()
        assert result["theorem_ic"]["correspondence_verified"]
