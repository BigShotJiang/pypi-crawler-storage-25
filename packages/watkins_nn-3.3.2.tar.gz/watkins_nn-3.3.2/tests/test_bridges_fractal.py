"""Tests for watkins_nn.bridges_fractal — Sprint 14: The Fractal Bloom (BT-BX).

Tests cover:
  - Hessian eigenvalues at symmetric projections (BT)
  - Free energy quadratic scaling (BU)
  - Two-phase flow universality (BV)
  - Coupling cascade monotonicity (BW)
  - Curvature landscape along manifold (BX)
"""

import math

import numpy as np
import pytest

from watkins_nn.bridges_fractal import (
    hessian_at_symmetric_projections,
    free_energy_quadratic_scaling,
    two_phase_flow_universality,
    coupling_cascade_monotonicity,
    curvature_landscape_along_manifold,
)

PHI = (1 + np.sqrt(5)) / 2
LAM_STAR = 1.0 / PHI
KAP_STAR = (1 - LAM_STAR) / 2
T_STAR = PHI / np.log(2 * PHI)


class TestHessianAtSymmetricProjections:
    """Tests for Theorem BT: Hessian spectrum at symmetric projections."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = hessian_at_symmetric_projections()

    def test_returns_four_systems(self):
        assert len(self.result['systems']) == 4

    def test_system_names(self):
        names = [s['system'] for s in self.result['systems']]
        assert names == ['F4', 'E6', 'E7', 'E8']

    def test_eigenvalues_positive(self):
        for s in self.result['systems']:
            assert s['mu_slow'] > 0
            assert s['mu_fast'] > 0

    def test_mu_fast_greater_than_mu_slow(self):
        for s in self.result['systems']:
            assert s['mu_fast'] > s['mu_slow']

    def test_e8_nearest_to_equilibrium(self):
        assert self.result['e8_nearest'] == True

    def test_slow_eigenvalue_monotone_decreasing(self):
        assert self.result['slow_monotone_decreasing'] == True

    def test_fast_eigenvalue_monotone_decreasing(self):
        assert self.result['fast_monotone_decreasing'] == True

    def test_condition_number_monotone_decreasing(self):
        assert self.result['condition_monotone_decreasing'] == True

    def test_equilibrium_values_positive(self):
        assert self.result['equilibrium_mu_slow'] > 0
        assert self.result['equilibrium_mu_fast'] > 0

    def test_e8_mu_slow_error_small(self):
        assert self.result['e8_mu_slow_error'] < 0.01

    def test_e8_mu_fast_error_small(self):
        assert self.result['e8_mu_fast_error'] < 0.05

    def test_condition_numbers_greater_than_one(self):
        for s in self.result['systems']:
            assert s['condition_number'] > 1.0


class TestFreeEnergyQuadraticScaling:
    """Tests for Theorem BU: quadratic scaling of symmetric manifold excess."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = free_energy_quadratic_scaling()

    def test_returns_four_systems(self):
        assert len(self.result['systems']) == 4

    def test_positive_universal_prefactor(self):
        assert self.result['universal_prefactor'] > 0

    def test_e8_in_quadratic_regime(self):
        assert self.result['e8_in_quadratic_regime'] == True

    def test_e8_quadratic_error_small(self):
        assert self.result['e8_quadratic_error'] < 0.01

    def test_far_field_deviation_larger_than_near(self):
        assert self.result['far_field_deviation'] > self.result['near_field_plateau']

    def test_delta_lambda_signs(self):
        """F4 has largest delta_lambda, E8 smallest (all positive)."""
        deltas = [s['delta_lambda'] for s in self.result['systems']]
        assert all(d > 0 for d in deltas)
        assert deltas[0] > deltas[-1]

    def test_delta_sym_actual_positive(self):
        for s in self.result['systems']:
            assert s['delta_sym_actual'] > 0

    def test_second_derivative_consistent(self):
        """F_sym'' should be approximately 2 * prefactor."""
        np.testing.assert_allclose(
            self.result['F_sym_second_derivative'],
            2 * self.result['universal_prefactor'],
            rtol=1e-8, atol=1e-10,
        )


class TestTwoPhaseFlowUniversality:
    """Tests for Theorem BV: two-phase flow universality."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = two_phase_flow_universality()

    def test_all_systems_converge(self):
        assert self.result['all_converged'] == True

    def test_all_exhibit_two_phase(self):
        assert self.result['all_two_phase'] == True

    def test_time_ordering(self):
        """tau(E8) < tau(E7) < tau(E6) < tau(F4)."""
        assert self.result['time_ordering_correct'] == True

    def test_crossover_detected(self):
        for s in self.result['systems']:
            assert s['crossover_step'] is not None

    def test_final_distances_small(self):
        for s in self.result['systems']:
            assert s['final_distance'] < 1e-4

    def test_eta_crossover_threshold_positive(self):
        assert self.result['eta_crossover_threshold'] > 0


class TestCouplingCascadeMonotonicity:
    """Tests for Theorem BW: coupling cascade monotonicity."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = coupling_cascade_monotonicity()

    def test_monotone_increasing(self):
        assert self.result['monotone_increasing'] == True

    def test_gamma_star_positive(self):
        expected = KAP_STAR / LAM_STAR
        np.testing.assert_allclose(
            self.result['gamma_star'], expected,
            rtol=1e-8, atol=1e-10,
        )

    def test_bracket_systems(self):
        """Equilibrium gamma* sits between E6 and E7."""
        bracket = self.result['bracket']
        assert bracket[0] == 'E6'
        assert bracket[1] == 'E7'

    def test_under_over_partition(self):
        assert self.result['n_under_coupled'] == 2
        assert self.result['n_over_coupled'] == 2

    def test_four_systems_returned(self):
        assert len(self.result['systems']) == 4

    def test_gammas_positive(self):
        for s in self.result['systems']:
            assert s['gamma'] > 0

    def test_closest_delta_small(self):
        assert self.result['closest_delta'] < 0.1


class TestCurvatureLandscapeAlongManifold:
    """Tests for Theorem BX: free energy curvature landscape."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = curvature_landscape_along_manifold(n_points=100)

    def test_landscape_size(self):
        assert self.result['landscape_size'] == 100

    def test_lambda_range(self):
        lo, hi = self.result['lambda_range']
        assert lo > 1.0 / 3
        assert hi < 1.0

    def test_slow_monotone_above_equilibrium(self):
        assert self.result['slow_monotone_above_eq'] == True

    def test_fast_monotone_above_equilibrium(self):
        assert self.result['fast_monotone_above_eq'] == True

    def test_condition_monotone_above_equilibrium(self):
        assert self.result['condition_monotone_above_eq'] == True

    def test_markers_present(self):
        markers = self.result['markers']
        for name in ['F4', 'E6', 'E7', 'E8']:
            assert name in markers
            assert 'lambda_R' in markers[name]

    def test_equilibrium_index_valid(self):
        idx = self.result['equilibrium_index']
        assert 0 <= idx < self.result['landscape_size']

    def test_min_condition_below_equilibrium(self):
        """Minimum condition number lambda is below lambda*."""
        assert self.result['min_condition_below_equilibrium'] == True
