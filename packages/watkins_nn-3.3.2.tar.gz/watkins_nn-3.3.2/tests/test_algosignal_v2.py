"""Tests for algosignal_v2 module.

Covers AlgoSignal, SimplexFlowEnginePyTorch, AlgoSignalV1Compatible,
and ConservationCertificate.
"""

import numpy as np
import pytest
import torch

from watkins_nn.algosignal_v2 import (
    AlgoSignal,
    AlgoSignalV1Compatible,
    AlgoSignal_v1,
    ConservationCertificate,
    SimplexFlowEnginePyTorch,
)
from watkins_nn.constants import WATKINS_LAMBDA, WATKINS_KAPPA, WATKINS_ETA, T_STAR

PHI = (1 + np.sqrt(5)) / 2


class TestAlgoSignalInit:
    """Initialization and basic state access."""

    def test_default_init_conservation(self):
        signal = AlgoSignal()
        state = signal.state_vector()
        total = state.sum().item()
        assert np.allclose(total, 1.0, rtol=1e-8, atol=1e-10)

    def test_default_init_near_watkins(self):
        signal = AlgoSignal()
        s = signal.to_numpy()
        expected = np.array([WATKINS_LAMBDA, WATKINS_KAPPA, WATKINS_ETA])
        assert np.allclose(s, expected, rtol=1e-4, atol=1e-6)

    def test_custom_init_normalised(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        state = signal.state_vector()
        total = state.sum().item()
        assert np.allclose(total, 1.0, rtol=1e-8, atol=1e-10)

    def test_auto_normalise_when_sum_not_one(self):
        """Values that don't sum to 1 get auto-normalised before log-space init."""
        signal = AlgoSignal(lambda_init=2.0, kappa_init=1.0, eta_init=1.0)
        state = signal.state_vector()
        total = state.sum().item()
        assert np.allclose(total, 1.0, rtol=1e-8, atol=1e-10)

    def test_dtype_float64(self):
        signal = AlgoSignal(dtype=torch.float64)
        assert signal.unconstrained.dtype == torch.float64

    def test_forward_returns_three_tensors(self):
        signal = AlgoSignal()
        lam, kap, eta = signal()
        total = (lam + kap + eta).item()
        assert np.allclose(total, 1.0, rtol=1e-8, atol=1e-10)


class TestAlgoSignalF:
    """Generating functional F and its derivatives."""

    def test_compute_F_returns_scalar(self):
        signal = AlgoSignal()
        F = signal.compute_F()
        assert F.ndim == 0

    def test_compute_F_at_equilibrium_finite(self):
        signal = AlgoSignal()
        F = signal.compute_F().item()
        assert np.isfinite(F)

    def test_compute_F_with_external_state(self):
        signal = AlgoSignal()
        state = torch.tensor([0.6, 0.2, 0.2], dtype=torch.float64)
        F = signal.compute_F(state)
        assert np.isfinite(F.item())

    def test_grad_F_shape(self):
        signal = AlgoSignal()
        grad = signal.grad_F()
        assert grad.shape == (3,)

    def test_hessian_F_shape(self):
        signal = AlgoSignal()
        H = signal.hessian_F()
        assert H.shape == (3, 3)

    def test_hessian_eigenvalues_sorted(self):
        signal = AlgoSignal()
        ev = signal.hessian_eigenvalues()
        vals = ev.detach().cpu().numpy()
        assert np.all(np.diff(vals) >= -1e-12), "eigenvalues should be ascending"

    def test_is_positive_definite_at_default(self):
        signal = AlgoSignal()
        assert signal.is_positive_definite() is True


class TestAlgoSignalChecks:
    """Equilibrium, conservation, certificate, serialisation."""

    def test_is_at_equilibrium_default(self):
        signal = AlgoSignal()
        assert signal.is_at_equilibrium(tolerance=1e-3)

    def test_is_at_equilibrium_false_for_far_state(self):
        signal = AlgoSignal(lambda_init=0.8, kappa_init=0.1, eta_init=0.1)
        assert not signal.is_at_equilibrium(tolerance=1e-4)

    def test_conservation_law_check(self):
        signal = AlgoSignal()
        assert signal.conservation_law_check(tolerance=1e-10)

    def test_to_numpy(self):
        signal = AlgoSignal()
        arr = signal.to_numpy()
        assert isinstance(arr, np.ndarray)
        assert arr.shape == (3,)
        assert np.allclose(arr.sum(), 1.0, rtol=1e-8, atol=1e-10)

    def test_from_numpy_roundtrip(self):
        original = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        arr = original.to_numpy()
        restored = AlgoSignal.from_numpy(arr)
        arr2 = restored.to_numpy()
        assert np.allclose(arr, arr2, rtol=1e-4, atol=1e-6)

    def test_to_dict_keys(self):
        signal = AlgoSignal()
        d = signal.to_dict()
        assert set(d.keys()) == {'lambda', 'kappa', 'eta'}
        total = d['lambda'] + d['kappa'] + d['eta']
        assert np.allclose(total, 1.0, rtol=1e-8, atol=1e-10)

    def test_conservation_certificate(self):
        signal = AlgoSignal()
        cert = signal.get_conservation_certificate()
        assert isinstance(cert, ConservationCertificate)
        assert cert.verified
        assert cert.error_bound < 1e-10

    def test_conservation_certificate_lean4_skipped(self):
        """Lean 4 not available in test env -- should return False gracefully."""
        signal = AlgoSignal()
        cert = signal.get_conservation_certificate(verify_lean4=True)
        assert cert.lean4_verified is False

    def test_repr_contains_values(self):
        signal = AlgoSignal()
        r = repr(signal)
        assert 'AlgoSignal' in r
        assert 'F=' in r


class TestSimplexFlowEnginePyTorch:
    """SimplexFlowEnginePyTorch (v2 engine) convergence."""

    def test_euler_step_records_trajectory(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEnginePyTorch(signal, adaptive=False)
        engine.step_euler()
        assert len(engine.trajectory) == 1
        assert len(engine.F_values) == 1
        assert len(engine.gradient_norms) == 1

    def test_adaptive_step_returns_positive_dt(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEnginePyTorch(signal, adaptive=True)
        dt = engine.step_adaptive()
        assert dt > 0

    def test_run_to_convergence_euler(self):
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEnginePyTorch(
            signal, max_steps=5000, tolerance=1e-6, adaptive=False
        )
        result = engine.run_to_convergence(verbose=False)
        assert result['converged']
        final = result['final_state']
        assert np.allclose(final.sum(), 1.0, rtol=1e-8, atol=1e-10)

    def test_run_to_convergence_adaptive(self):
        # v2 engine has gradient-space mismatch; use generous budget + tolerance
        signal = AlgoSignal(lambda_init=0.5, kappa_init=0.3, eta_init=0.2)
        engine = SimplexFlowEnginePyTorch(
            signal, max_steps=10000, tolerance=1e-4, adaptive=True
        )
        result = engine.run_to_convergence(verbose=False)
        # Even if not converged by tight tolerance, F should decrease
        assert result['final_F'] < engine.F_values[0] + 1e-6
        # Conservation always holds due to softmax
        assert np.allclose(result['final_state'].sum(), 1.0, rtol=1e-8, atol=1e-10)

    def test_random_init_engine(self):
        """Engine with no initial_state creates random start. Conservation holds regardless."""
        engine = SimplexFlowEnginePyTorch(initial_state=None, max_steps=3000, tolerance=1e-4)
        result = engine.run_to_convergence(verbose=False)
        # Conservation always holds via softmax projection
        assert np.allclose(result['final_state'].sum(), 1.0, rtol=1e-8, atol=1e-10)


class TestAlgoSignalV1Compatible:
    """Backward-compatible v1 wrapper."""

    def test_properties_sum_to_one(self):
        v1 = AlgoSignalV1Compatible()
        total = v1.lambda_ + v1.kappa + v1.eta
        assert np.allclose(total, 1.0, rtol=1e-8, atol=1e-10)

    def test_compute_F_returns_float(self):
        v1 = AlgoSignalV1Compatible()
        F = v1.compute_F()
        assert isinstance(F, float)

    def test_grad_F_returns_numpy(self):
        v1 = AlgoSignalV1Compatible()
        g = v1.grad_F()
        assert isinstance(g, np.ndarray)
        assert g.shape == (3,)

    def test_hessian_eigenvalues_returns_numpy(self):
        v1 = AlgoSignalV1Compatible()
        ev = v1.hessian_eigenvalues()
        assert isinstance(ev, np.ndarray)
        assert ev.shape == (3,)

    def test_to_dict_keys(self):
        v1 = AlgoSignalV1Compatible()
        d = v1.to_dict()
        assert set(d.keys()) == {'lambda', 'kappa', 'eta'}

    def test_repr(self):
        v1 = AlgoSignalV1Compatible()
        r = repr(v1)
        assert 'AlgoSignal' in r

    def test_alias_AlgoSignal_v1(self):
        assert AlgoSignal_v1 is AlgoSignalV1Compatible
