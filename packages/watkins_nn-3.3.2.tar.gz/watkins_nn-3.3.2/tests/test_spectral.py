"""Tests for watkins_nn.spectral module."""

import torch
import pytest


def test_hessian_positive_definite():
    from watkins_nn.spectral import hessian_at_equilibrium, verify_positive_definite
    H = hessian_at_equilibrium()
    is_pd, eigvals = verify_positive_definite(H)
    assert is_pd
    assert float(eigvals[0]) > 5.9   # MU_SLOW ~ 5.934
    assert float(eigvals[1]) > 20.5  # MU_FAST ~ 20.556


def test_hessian_shape():
    from watkins_nn.spectral import hessian_at_equilibrium
    H = hessian_at_equilibrium(dim=3)
    assert H.shape == (2, 2)
    assert H.dtype == torch.float64


def test_spectral_gap():
    from watkins_nn.spectral import spectral_gap, SPECTRAL_GAP
    mu = spectral_gap()
    assert mu > 0
    assert abs(mu - SPECTRAL_GAP) < 0.1


def test_mixing_time():
    from watkins_nn.spectral import mixing_time_bound, MIXING_TIME
    tau = mixing_time_bound()
    assert tau > 0
    assert abs(tau - MIXING_TIME) < 0.01


def test_convergence_rate():
    from watkins_nn.spectral import exponential_convergence_rate
    rate = exponential_convergence_rate(torch.tensor([0.4, 0.3, 0.3]), t=1.0)
    assert float(rate) < 0.01  # Should decay rapidly


def test_unsupported_dim():
    from watkins_nn.spectral import hessian_at_equilibrium
    with pytest.raises(NotImplementedError):
        hessian_at_equilibrium(dim=5)
