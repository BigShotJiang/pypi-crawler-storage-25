"""Theorem GQ: C_odd does not arise as an L-function special value.

Three independent obstructions are verified:
1. C_odd is algebraic (degree 2 over Q) — L-function values are transcendental
2. D(n) is non-multiplicative — no Euler product exists
3. C_odd = cos(pi/5) * (1-1/3)^2 — arithmetic origin, not automorphic
"""

import math
import numpy as np
import pytest

from watkins_nn import c_odd_algebraicity_obstruction

PHI = (1 + math.sqrt(5)) / 2


class TestTheoremGQ:
    """C_odd algebraicity obstruction — L-function connection is blocked."""

    @pytest.fixture
    def result(self):
        return c_odd_algebraicity_obstruction()

    def test_c_odd_is_algebraic(self, result):
        """C_odd satisfies 81t^2 - 18t - 4 = 0."""
        assert result['is_algebraic']
        assert abs(result['poly_residual']) < 1e-12

    def test_minimal_polynomial(self, result):
        """Verify the minimal polynomial coefficients."""
        a, b, c = result['minimal_polynomial']
        assert (a, b, c) == (81, -18, -4)
        # Discriminant = b^2 - 4ac = 324 + 1296 = 1620 = 4*405 = 4*81*5
        disc = b**2 - 4*a*c
        assert disc == 1620
        # sqrt(disc) = sqrt(1620) = 18*sqrt(5)
        assert abs(math.sqrt(disc) - 18*math.sqrt(5)) < 1e-10

    def test_d_n_non_multiplicative(self, result):
        """D(n) violates multiplicativity for substantial fraction of coprime pairs."""
        assert result['multiplicativity_violations'] > 0
        assert result['multiplicativity_rate'] > 0.2  # >20% violation rate

    def test_cos_pi5_decomposition(self, result):
        """C_odd = cos(pi/5) * (1 - 1/3)^2 exactly."""
        assert result['decomposition']['match']
        assert np.isclose(
            result['decomposition']['product'],
            result['C_odd'],
            rtol=1e-14,
        )

    def test_c_odd_value(self, result):
        """C_odd = 2*phi/9."""
        assert np.isclose(result['C_odd'], 2 * PHI / 9, rtol=1e-14)

    def test_euler_factor_squared(self, result):
        """The 4/9 factor is (1 - 1/3)^2 = (2/3)^2."""
        ef_sq = result['decomposition']['euler_factor_sq']
        assert np.isclose(ef_sq, 4/9, rtol=1e-14)

    def test_conclusion_present(self, result):
        """Result includes clear conclusion statement."""
        assert 'algebraic' in result['conclusion'].lower()
        assert 'transcendental' in result['conclusion'].lower()
