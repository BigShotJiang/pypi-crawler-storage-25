"""Tests for watkins_nn.bridges_hyperbolic — Sprints 15, 20-23, 30.

Tests cover:
  - Root system complex invariant (BY)
  - Bloch-Wigner volume landscape (BZ)
  - Negative budget scaling (CA)
  - Volume-coupling bridge (CB)
  - Root system quantum channel (CC)
  - Quantum relative entropy (DE-DG)
  - BW vanishing dichotomy (DB)
  - A_n BW landscape (DC-DD)
  - Entropy landscape analysis (DK-DM)
  - Quantum channel capacity (DH-DJ)
  - Quantum sigma bridge (EJ-EM)
"""

import math

import numpy as np
import pytest

from watkins_nn.bridges_hyperbolic import (
    _bloch_wigner,
    root_system_complex_invariant,
    bloch_wigner_volume_landscape,
    negative_budget_scaling,
    volume_coupling_bridge,
    root_system_quantum_channel,
    quantum_relative_entropy,
    _bloch_wigner_extended,
    bw_vanishing_dichotomy,
    an_bw_landscape,
    entropy_landscape_analysis,
    quantum_channel_capacity,
    quantum_sigma_bridge,
)

PHI = (1 + np.sqrt(5)) / 2
LAM_STAR = 1.0 / PHI
KAP_STAR = (1 - LAM_STAR) / 2
T_STAR = PHI / np.log(2 * PHI)


class TestBlochWigner:
    """Tests for the _bloch_wigner helper function."""

    def test_vanishes_at_zero(self):
        np.testing.assert_allclose(_bloch_wigner(0.0 + 0j), 0.0, atol=1e-10)

    def test_vanishes_at_one(self):
        np.testing.assert_allclose(_bloch_wigner(1.0 + 0j), 0.0, atol=1e-10)

    def test_vanishes_on_real_axis(self):
        """D(z) = 0 for real z."""
        for x in [0.1, 0.5, 0.9]:
            np.testing.assert_allclose(_bloch_wigner(complex(x, 0)), 0.0, atol=1e-10)

    def test_positive_for_upper_half_plane(self):
        """D(z) > 0 for z with positive imaginary part and |z| < 1."""
        z = complex(0.5, 0.3)
        assert _bloch_wigner(z) > 0

    def test_bloch_wigner_extended_functional_equation(self):
        """D(z) = -D(1/z) for the extended version."""
        z = complex(0.4, 0.3)
        D_z = _bloch_wigner_extended(z)
        D_inv = _bloch_wigner_extended(1.0 / z)
        np.testing.assert_allclose(D_z, -D_inv, rtol=1e-8, atol=1e-10)


class TestRootSystemComplexInvariant:
    """Tests for Theorem BY: root system complex invariant."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = root_system_complex_invariant()

    def test_four_systems(self):
        assert len(self.result['systems']) == 4

    def test_modulus_decreasing(self):
        assert self.result['modulus_decreasing'] == True

    def test_argument_increasing(self):
        assert self.result['argument_increasing'] == True

    def test_multi_optimality(self):
        """No single system is universally closest."""
        assert self.result['multi_optimal'] == True

    def test_closest_by_complex_distance_not_e8(self):
        assert self.result['closest_by_complex_distance'] != 'E8'

    def test_equilibrium_modulus(self):
        z_eq = complex(LAM_STAR, KAP_STAR)
        np.testing.assert_allclose(
            self.result['z_equilibrium']['modulus'], abs(z_eq),
            rtol=1e-8, atol=1e-10,
        )

    def test_arguments_positive(self):
        for s in self.result['systems']:
            assert s['argument'] > 0

    def test_complex_distances_positive(self):
        for s in self.result['systems']:
            assert s['complex_distance'] > 0


class TestBlochWignerVolumeLandscape:
    """Tests for Theorem BZ: Bloch-Wigner volume landscape."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = bloch_wigner_volume_landscape()

    def test_volume_coupling_monotone(self):
        assert self.result['volume_coupling_monotone'] == True

    def test_e7_near_sqrt2(self):
        assert self.result['e7_near_sqrt2'] == True

    def test_e7_not_exact_sqrt2(self):
        assert self.result['e7_not_exact_sqrt2'] == True

    def test_f4_near_two_thirds(self):
        assert self.result['f4_near_two_thirds'] == True

    def test_equilibrium_volume_positive(self):
        assert self.result['D_equilibrium'] > 0

    def test_volume_ratios_positive(self):
        for s in self.result['systems']:
            assert s['D_volume'] > 0


class TestNegativeBudgetScaling:
    """Tests for Theorem CA: negative budget scaling."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = negative_budget_scaling(n_max=100)

    def test_a_approaches_2(self):
        assert self.result['A_approaches_2'] == True

    def test_b_approaches_1(self):
        assert self.result['B_approaches_1'] == True

    def test_langlands_b_equals_c(self):
        assert self.result['langlands_B_equals_C'] == True

    def test_a_double_bcd(self):
        assert self.result['A_double_BCD'] == True

    def test_four_families_present(self):
        fam = self.result['families']
        for key in ['A', 'B', 'C', 'D']:
            assert key in fam
            assert len(fam[key]) > 0


class TestVolumeCouplingBridge:
    """Tests for Theorem CB: volume-coupling bridge."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = volume_coupling_bridge()

    def test_all_five_monotone(self):
        assert self.result['all_five_monotone'] == True

    def test_lambda_decreasing(self):
        assert self.result['lambda_decreasing'] == True

    def test_gamma_increasing(self):
        assert self.result['gamma_increasing'] == True

    def test_volume_increasing(self):
        assert self.result['volume_increasing'] == True

    def test_four_systems_returned(self):
        assert len(self.result['systems']) == 4


class TestRootSystemQuantumChannel:
    """Tests for Theorem CC: root system quantum channel."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = root_system_quantum_channel()

    def test_entropy_monotone(self):
        assert self.result['entropy_monotone'] == True

    def test_fidelity_non_monotone(self):
        assert self.result['fidelity_non_monotone'] == True

    def test_multi_optimal(self):
        assert self.result['multi_optimal'] == True

    def test_best_entropy_is_e8(self):
        assert self.result['best_entropy_system'] == 'E8'

    def test_fidelities_in_range(self):
        for s in self.result['systems']:
            assert 0 < s['fidelity'] <= 1.0

    def test_entropies_positive(self):
        for s in self.result['systems']:
            assert s['entropy'] > 0


class TestQuantumRelativeEntropy:
    """Tests for Theorems DE-DG: relative entropy, duality, Pinsker."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = quantum_relative_entropy()

    def test_f4_furthest_kl(self):
        assert self.result['f4_furthest_kl'] == True

    def test_e6_closest_kl(self):
        assert self.result['e6_closest_kl'] == True

    def test_kl_non_monotone(self):
        assert self.result['kl_non_monotone'] == True

    def test_residual_decreasing(self):
        assert self.result['residual_decreasing'] == True

    def test_duality_converges(self):
        assert self.result['duality_converges'] == True

    def test_pinsker_satisfied(self):
        assert self.result['pinsker_satisfied'] == True

    def test_pinsker_ratio_decreasing(self):
        assert self.result['pinsker_ratio_decreasing'] == True

    def test_kl_divergences_non_negative(self):
        for s in self.result['systems']:
            assert s['kl_divergence'] >= 0


class TestBWVanishingDichotomy:
    """Tests for Theorem DB: BW vanishing dichotomy."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = bw_vanishing_dichotomy()

    def test_dichotomy_verified(self):
        assert self.result['dichotomy_verified'] == True

    def test_all_exceptional_carry_volume(self):
        assert self.result['all_exceptional_carry_volume'] == True

    def test_all_an_carry_volume(self):
        assert self.result['all_an_carry_volume'] == True

    def test_all_bcd_zero(self):
        assert self.result['all_bcd_zero'] == True

    def test_equilibrium_volume_positive(self):
        assert self.result['D_equilibrium'] > 0


class TestAnBWLandscape:
    """Tests for Theorems DC-DD: A_n exact curvature and BW asymptotic."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = an_bw_landscape(n_max=15)

    def test_curvature_formula_verified(self):
        assert self.result['curvature_formula_verified'] == True

    def test_ratios_monotone_decreasing(self):
        assert self.result['ratios_monotone_decreasing'] == True

    def test_rescaled_bounded(self):
        assert self.result['rescaled_bounded'] == True

    def test_entries_count(self):
        assert len(self.result['entries']) == 13  # A_3 through A_15


class TestEntropyLandscapeAnalysis:
    """Tests for Theorems DK-DM: entropy deficit, gradient balance, concurrence."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = entropy_landscape_analysis()

    def test_deficit_ordering(self):
        assert self.result['deficit_ordering'] == True

    def test_all_deficits_positive(self):
        assert self.result['all_deficits_positive'] == True

    def test_gradients_balanced(self):
        assert self.result['gradients_balanced'] == True

    def test_free_energy_stationary(self):
        assert self.result['free_energy_stationary'] == True

    def test_entropy_toward_uniform(self):
        assert self.result['entropy_toward_uniform'] == True

    def test_golden_concurrence_identity(self):
        assert self.result['golden_concurrence_identity'] == True

    def test_concurrence_decreasing(self):
        assert self.result['concurrence_decreasing'] == True

    def test_cs_product_not_constant(self):
        """Honest: C*S is NOT a conservation law."""
        assert self.result['cs_product_constant'] == False

    def test_e6_e7_cs_near_equal(self):
        assert self.result['e6_e7_cs_near_equal'] == True


class TestQuantumChannelCapacity:
    """Tests for Theorems DH-DJ: capacity hierarchy, entanglement breaking, complementarity."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = quantum_channel_capacity()

    def test_capacity_decreasing(self):
        assert self.result['capacity_decreasing'] == True

    def test_entropy_increasing(self):
        assert self.result['entropy_increasing'] == True

    def test_capacity_lambda_co_decrease(self):
        assert self.result['capacity_lambda_co_decrease'] == True

    def test_complementarity_exact(self):
        assert self.result['complementarity_exact'] == True

    def test_golden_derivative(self):
        """dC/dlam at equilibrium equals ln(phi)."""
        assert self.result['golden_derivative'] == True

    def test_coherent_info_universal(self):
        assert self.result['I_c_replacement_universal'] == True

    def test_quantum_capacity_zero(self):
        assert self.result['quantum_capacity_zero'] == True

    def test_entropy_equals_h_binary(self):
        """For on-simplex systems (eta=0), entropy equals binary entropy."""
        assert self.result['entropy_equals_h_binary'] == True


class TestQuantumSigmaBridge:
    """Tests for Theorems EJ-EM: quantum metrics in sigma variables."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = quantum_sigma_bridge()

    def test_entropy_identity(self):
        assert self.result['ej_verified'] == True

    def test_capacity_identity(self):
        assert self.result['ek_verified'] == True

    def test_complementarity_sigma(self):
        assert self.result['complementarity_sigma'] == True

    def test_kl_formula_verified(self):
        assert self.result['el_all_kl_match'] == True

    def test_capacity_sensitivity_sigma(self):
        assert self.result['em_verified'] == True

    def test_algebraic_foundation(self):
        assert self.result['identity_2_minus_phi'] == True
        assert self.result['kap_as_inv_phi_sq'] == True
