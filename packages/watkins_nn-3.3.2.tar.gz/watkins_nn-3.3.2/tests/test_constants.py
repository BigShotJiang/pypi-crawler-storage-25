"""Tests for constants.py — golden-ratio constants and critical thresholds.

This module was previously untested despite being friction-prone
(golden-ratio precision issues). Tests use rtol=1e-8 per project conventions.
"""

import math

import numpy as np
import pytest

from watkins_nn.constants import (
    # Golden ratio
    SQRT5, PHI, PHI_INV, PHI_SQUARED,
    # Watkins Temperature Theorem
    T_STAR, LAM_STAR, KAP_STAR, ETA_STAR, F_STAR, T_STAR3,
    # Spectral and flow
    W_SQUARED, BETA_STAR, M_PHI,
    RHO_STAR, PHI_MAX,
    # Spectral eigenvalues
    MU_SLOW, MU_FAST, MU_COH, MU_ASYM, TAU_COH, TAU_ASYM,
    MU_SLOW_4BODY, MU_FAST_4BODY,
    # Qualia
    LN2, C_STAR_QUALIA,
    # Triality
    OMEGA_IDENTITY, OMEGA_CENTER, OMEGA_MAX,
    # Conservation
    CONSERVATION_EPSILON,
    # Backward compat
    WATKINS_LAMBDA, WATKINS_KAPPA, WATKINS_ETA,
)


# ── Golden ratio fundamentals ────────────────────────────────────────

class TestGoldenRatio:
    def test_sqrt5(self):
        assert np.isclose(SQRT5, math.sqrt(5), rtol=1e-14)

    def test_phi_definition(self):
        """phi = (1 + sqrt(5)) / 2."""
        assert np.isclose(PHI, (1 + SQRT5) / 2, rtol=1e-14)

    def test_phi_approximate_value(self):
        assert np.isclose(PHI, 1.6180339887, rtol=1e-8)

    def test_phi_inv_is_reciprocal(self):
        assert np.isclose(PHI_INV, 1 / PHI, rtol=1e-14)

    def test_phi_inv_equals_phi_minus_1(self):
        """The golden ratio satisfies 1/phi = phi - 1."""
        assert np.isclose(PHI_INV, PHI - 1, rtol=1e-14)

    def test_phi_squared(self):
        assert np.isclose(PHI_SQUARED, PHI ** 2, rtol=1e-14)

    def test_phi_squared_equals_phi_plus_1(self):
        """phi^2 = phi + 1."""
        assert np.isclose(PHI_SQUARED, PHI + 1, rtol=1e-14)


# ── Watkins Temperature Theorem ───────────────────────────────────────

class TestWatkinsTemperature:
    def test_t_star_definition(self):
        """T* = phi / ln(2*phi)."""
        assert np.isclose(T_STAR, PHI / math.log(2 * PHI), rtol=1e-12)

    def test_t_star_value(self):
        assert np.isclose(T_STAR, 1.3778018315, rtol=1e-8)

    def test_lam_star_is_phi_inv(self):
        assert np.isclose(LAM_STAR, PHI_INV, rtol=1e-14)

    def test_conservation_at_equilibrium(self):
        """lambda* + kappa* + eta* = 1 (conservation law)."""
        assert np.isclose(LAM_STAR + KAP_STAR + ETA_STAR, 1.0, atol=1e-14)

    def test_kap_eta_symmetric(self):
        """At equilibrium with Z2 symmetry, kappa* = eta*."""
        assert np.isclose(KAP_STAR, ETA_STAR, rtol=1e-14)

    def test_kap_star_value(self):
        expected = (1 - LAM_STAR) / 2
        assert np.isclose(KAP_STAR, expected, rtol=1e-14)

    def test_t_star3_definition(self):
        """T*₃ = phi / ln(3*phi) for the 3-simplex."""
        assert np.isclose(T_STAR3, PHI / math.log(3 * PHI), rtol=1e-12)

    def test_t_star3_less_than_t_star(self):
        """Higher-dimensional simplex has lower critical temperature."""
        assert T_STAR3 < T_STAR


# ── Free energy ───────────────────────────────────────────────────────

class TestFreeEnergy:
    def test_f_star_finite(self):
        assert math.isfinite(F_STAR)

    def test_f_star_computation(self):
        """Verify F* from its definition."""
        expected = (
            -math.log(LAM_STAR)
            + T_STAR * (
                LAM_STAR * math.log(LAM_STAR)
                + KAP_STAR * math.log(KAP_STAR)
                + ETA_STAR * math.log(ETA_STAR)
            )
        )
        assert np.isclose(F_STAR, expected, rtol=1e-12)


# ── Spectral constants ────────────────────────────────────────────────

class TestSpectralConstants:
    def test_w_squared_definition(self):
        """W² = ln(phi) / ln(2)."""
        assert np.isclose(W_SQUARED, math.log(PHI) / math.log(2), rtol=1e-12)

    def test_beta_star_definition(self):
        """beta* = 3W²/2 (K_{1,n-1}/cycle stabilizer-threshold ratio; corrected 2026-05-23)."""
        assert np.isclose(BETA_STAR, 3 * W_SQUARED / 2, rtol=1e-12)

    def test_m_phi_positive(self):
        assert M_PHI > 0

    def test_rho_star_4body(self):
        """rho* = (1 - lam*) / 3 for Z3 symmetry."""
        assert np.isclose(RHO_STAR, (1 - LAM_STAR) / 3, rtol=1e-12)

    def test_4body_conservation(self):
        """lam* + kap* + eta* + rho* should NOT equal 1 (different simplex)."""
        # In 4-body, kap and eta take different values than 2-simplex
        # But rho* is defined with LAM_STAR from 2-simplex
        # Just check rho is well-defined
        assert 0 < RHO_STAR < 1


# ── Eigenvalues ───────────────────────────────────────────────────────

class TestEigenvalues:
    def test_mu_slow_less_than_mu_fast(self):
        """Coordinate eigenvalue ordering."""
        assert MU_SLOW < MU_FAST

    def test_mu_coh_less_than_mu_asym(self):
        """Riemannian eigenvalue ordering: coherence mode slower than asymmetry."""
        assert MU_COH < MU_ASYM

    def test_mu_coh_closed_form(self):
        """mu_coh = (2/3) phi^2 (1 + T* phi)."""
        expected = (2 / 3) * PHI_SQUARED * (1 + T_STAR * PHI)
        assert np.isclose(MU_COH, expected, rtol=1e-12)

    def test_mu_asym_closed_form(self):
        """mu_asym = 2 T* phi^2."""
        expected = 2 * T_STAR * PHI_SQUARED
        assert np.isclose(MU_ASYM, expected, rtol=1e-12)

    def test_eigenvalues_positive(self):
        for name, val in [("MU_SLOW", MU_SLOW), ("MU_FAST", MU_FAST),
                          ("MU_COH", MU_COH), ("MU_ASYM", MU_ASYM)]:
            assert val > 0, f"{name} should be positive"

    def test_tau_coh_is_reciprocal(self):
        assert np.isclose(TAU_COH, 1 / MU_COH, rtol=1e-14)

    def test_tau_asym_is_reciprocal(self):
        assert np.isclose(TAU_ASYM, 1 / MU_ASYM, rtol=1e-14)

    def test_4body_ordering(self):
        assert MU_SLOW_4BODY < MU_FAST_4BODY

    def test_mu_coh_approximate_value(self):
        assert np.isclose(MU_COH, 5.636, atol=0.01)

    def test_mu_asym_approximate_value(self):
        assert np.isclose(MU_ASYM, 7.214, atol=0.01)


# ── Qualia and triality constants ─────────────────────────────────────

class TestQualiaTriality:
    def test_ln2(self):
        assert np.isclose(LN2, math.log(2), rtol=1e-14)

    def test_c_star_qualia(self):
        assert np.isclose(C_STAR_QUALIA, 2 / (PHI ** 1.5), rtol=1e-12)

    def test_omega_identity(self):
        assert OMEGA_IDENTITY == 1.0

    def test_omega_center_is_beta_star(self):
        assert np.isclose(OMEGA_CENTER, BETA_STAR, rtol=1e-14)

    def test_omega_max(self):
        assert np.isclose(OMEGA_MAX, BETA_STAR ** 2, rtol=1e-12)

    def test_omega_ordering(self):
        assert OMEGA_IDENTITY < OMEGA_CENTER < OMEGA_MAX


# ── Backward compatibility ────────────────────────────────────────────

class TestBackwardCompat:
    def test_watkins_lambda(self):
        assert WATKINS_LAMBDA == LAM_STAR

    def test_watkins_kappa(self):
        assert WATKINS_KAPPA == KAP_STAR

    def test_watkins_eta(self):
        assert WATKINS_ETA == ETA_STAR


# ── Conservation epsilon ──────────────────────────────────────────────

class TestConservation:
    def test_epsilon_tiny(self):
        assert CONSERVATION_EPSILON < 1e-10
        assert CONSERVATION_EPSILON > 0
