"""Tests for Sprint 25: Flow Universality (Theorems DP-DS)."""

import pytest
from watkins_nn.flow_universality import (
    universal_lyapunov,
    modal_fingerprint,
    flow_geodesic_efficiency,
    nonlinear_mode_coupling,
)


class TestTheoremDP:
    """Theorem DP: Universal Lyapunov Exponent."""

    def test_universal_rate(self):
        r = universal_lyapunov(n_starts=20)
        assert r['all_rates_near_mu_coh']

    def test_rate_value(self):
        r = universal_lyapunov(n_starts=20)
        assert abs(r['mean_rate'] - 5.636) < 0.5


class TestTheoremDQ:
    """Theorem DQ: Modal Fingerprint Classification."""

    def test_f4_coherence_dominated(self):
        r = modal_fingerprint()
        assert r['f4_coherence_dominated']

    def test_e8_asymmetry_dominated(self):
        r = modal_fingerprint()
        assert r['e8_asymmetry_dominated']

    def test_cascade_transition(self):
        r = modal_fingerprint()
        assert r['transition_at_e6_e7']


class TestTheoremDR:
    """Theorem DR: Near-Geodesic Flow."""

    def test_near_geodesic(self):
        r = flow_geodesic_efficiency()
        assert r['all_near_geodesic']

    def test_mean_efficiency(self):
        r = flow_geodesic_efficiency()
        assert 1.0 < r['mean_efficiency'] < 1.05


class TestTheoremDS:
    """Theorem DS: Nonlinear Mode Coupling."""

    def test_coupling_coefficient(self):
        r = nonlinear_mode_coupling()
        assert 0.1 < r['alpha'] < 0.5

    def test_quadratic_scaling(self):
        r = nonlinear_mode_coupling()
        assert r['quadratic_fit_r2'] > 0.95
