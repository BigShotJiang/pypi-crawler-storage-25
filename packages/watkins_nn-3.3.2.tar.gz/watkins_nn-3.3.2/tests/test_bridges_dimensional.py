"""Tests for watkins_nn.bridges_dimensional — Sprints 16-18, 24, 26, 28, 30.

Tests cover:
  - 3-simplex free energy (CD)
  - 3-simplex Hessian (CE)
  - Dimensional reduction map (CF)
  - 3-simplex gradient flow (CG)
  - Symmetry-breaking landscape (CH)
  - Dimensional free energy cost (CI)
  - Cross-dimensional conditioning (CJ)
  - 3-simplex root flow (CK)
  - Dimensional stability ordering (CL)
  - n-simplex temperature sequence (CM)
  - Exchange-coherence algebra (CS-CU)
  - Sigma unification (DN-DO)
  - Sigma weaving (DT-DW)
  - Deep structure identities (EB-EE)
"""

import math

import numpy as np
import pytest

from watkins_nn.bridges_dimensional import (
    three_simplex_free_energy,
    three_simplex_hessian,
    dimensional_reduction_map,
    three_simplex_flow,
    symmetry_breaking_landscape,
    dimensional_free_energy_cost,
    cross_dimensional_conditioning,
    three_simplex_root_flow,
    dimensional_stability_ordering,
    n_simplex_temperature_sequence,
    exchange_coherence_algebra,
    sigma_unification,
    deep_structure_identities,
)

PHI = (1 + np.sqrt(5)) / 2
LAM_STAR = 1.0 / PHI
KAP_STAR = (1 - LAM_STAR) / 2
RHO_STAR = (1 - LAM_STAR) / 3
T_STAR = PHI / np.log(2 * PHI)
T_STAR3 = PHI / np.log(3 * PHI)


class TestThreeSimplexFreeEnergy:
    """Tests for Theorem CD: 3-simplex free energy foundation."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = three_simplex_free_energy()

    def test_conservation(self):
        np.testing.assert_allclose(
            self.result['conservation'], 1.0,
            rtol=1e-8, atol=1e-10,
        )

    def test_conservation_exact(self):
        assert self.result['conservation_exact'] == True

    def test_f3_above_f2(self):
        """Adding a dimension raises the equilibrium free energy."""
        assert self.result['F3_above_F2'] == True

    def test_temperature_ratio(self):
        """T3 < T* (3-simplex is cooler)."""
        np.testing.assert_allclose(
            self.result['T3'], T_STAR3,
            rtol=1e-8, atol=1e-10,
        )
        assert self.result['T_ratio'] < 1.0

    def test_lambda_star_is_phi_inv(self):
        np.testing.assert_allclose(
            self.result['lambda_star'], LAM_STAR,
            rtol=1e-8, atol=1e-10,
        )

    def test_rho_star_value(self):
        np.testing.assert_allclose(
            self.result['rho_star'], RHO_STAR,
            rtol=1e-8, atol=1e-10,
        )


class TestThreeSimplexHessian:
    """Tests for Theorem CE: 3-simplex Hessian spectrum."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = three_simplex_hessian()

    def test_coherence_slowest(self):
        assert self.result['coherence_slowest'] == True

    def test_exchange_degenerate(self):
        assert self.result['exchange_degenerate'] == True

    def test_scale_separation_greater_than_one(self):
        assert self.result['scale_separation'] > 1.0

    def test_eigenvalues_positive(self):
        assert self.result['mu_coherence'] > 0
        assert self.result['mu_exchange'] > 0

    def test_timescales_positive(self):
        assert self.result['tau_coherence'] > 0
        assert self.result['tau_exchange'] > 0

    def test_coordinate_eigenvalues_sorted(self):
        eigs = self.result['coordinate_eigenvalues']
        assert eigs == sorted(eigs)


class TestDimensionalReductionMap:
    """Tests for Theorem CF: dimensional reduction map."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = dimensional_reduction_map()

    def test_kappa_ratio_is_two_thirds(self):
        assert self.result['kappa_ratio_is_two_thirds'] == True

    def test_kappa_ratio_value(self):
        np.testing.assert_allclose(
            self.result['kappa_ratio'], 2.0 / 3.0,
            rtol=1e-8, atol=1e-10,
        )

    def test_temperature_decreasing(self):
        assert self.result['temperature_decreasing'] == True

    def test_eta_effective(self):
        np.testing.assert_allclose(
            self.result['eta_effective'], 2 * RHO_STAR,
            rtol=1e-8, atol=1e-10,
        )

    def test_temperature_sequence_length(self):
        assert len(self.result['temperature_sequence']) == 7


class TestThreeSimplexFlow:
    """Tests for Theorem CG: 3-simplex gradient flow."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = three_simplex_flow()

    def test_converged(self):
        assert self.result['converged'] == True

    def test_z3_symmetric_final(self):
        assert self.result['z3_symmetric_final'] == True

    def test_z3_faster_than_convergence(self):
        """Z3 symmetry achieved before full convergence."""
        assert self.result['z3_faster_than_convergence'] == True

    def test_final_distance_small(self):
        assert self.result['final_distance'] < 1e-4

    def test_final_state_conservation(self):
        s = self.result['final_state']
        total = s['lambda'] + s['kappa'] + s['eta_s'] + s['eta_d']
        np.testing.assert_allclose(total, 1.0, rtol=1e-8, atol=1e-6)


class TestSymmetryBreakingLandscape:
    """Tests for Theorem CH: symmetry-breaking landscape."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = symmetry_breaking_landscape()

    def test_no_spontaneous_breaking(self):
        assert self.result['no_spontaneous_breaking'] == True

    def test_exchange_stiffer(self):
        assert self.result['exchange_stiffer'] == True

    def test_curvature_match(self):
        assert self.result['curvature_match'] == True

    def test_stiffness_ratio_value(self):
        assert self.result['stiffness_ratio'] > 1.0

    def test_landscape_points_generated(self):
        assert self.result['n_landscape_points'] > 50


class TestDimensionalFreeEnergyCost:
    """Tests for Theorem CI: dimensional free energy cost."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = dimensional_free_energy_cost()

    def test_cost_monotone_increasing(self):
        assert self.result['cost_monotone_increasing'] == True

    def test_e8_matches_equilibrium(self):
        assert self.result['e8_matches_equilibrium'] == True

    def test_e8_delta_positive(self):
        assert self.result['e8_delta'] > 0

    def test_delta_equilibrium_positive(self):
        assert self.result['delta_equilibrium'] > 0

    def test_four_systems(self):
        assert len(self.result['systems']) == 4


class TestCrossDimensionalConditioning:
    """Tests for Theorem CJ: cross-dimensional conditioning."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = cross_dimensional_conditioning()

    def test_all_improved(self):
        """3-simplex condition number lower than 2-simplex for all."""
        assert self.result['all_improved'] == True

    def test_reduction_monotone_increasing(self):
        assert self.result['reduction_monotone_increasing'] == True

    def test_e8_reduction_largest(self):
        assert self.result['e8_reduction'] > self.result['min_reduction']

    def test_reductions_positive(self):
        for s in self.result['systems']:
            assert s['reduction_fraction'] > 0


class TestThreeSimplexRootFlow:
    """Tests for Theorem CK: 3-simplex root system flow."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = three_simplex_root_flow()

    def test_all_converged(self):
        assert self.result['all_converged'] == True

    def test_all_z3_preserved(self):
        assert self.result['all_z3_preserved'] == True

    def test_time_ordering(self):
        assert self.result['time_ordering_correct'] == True

    def test_four_systems(self):
        assert len(self.result['systems']) == 4


class TestDimensionalStabilityOrdering:
    """Tests for Theorem CL: dimensional stability ordering."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = dimensional_stability_ordering()

    def test_sigma_monotone_increasing(self):
        assert self.result['sigma_monotone_increasing'] == True

    def test_e8_most_stable(self):
        assert self.result['e8_most_stable'] == True

    def test_e8_sigma_less_than_one(self):
        """Sigma < 1 means eigenvalue decreases across dimensions."""
        assert self.result['e8_sigma'] < 1.0

    def test_f4_least_stable(self):
        assert self.result['f4_sigma'] < self.result['e8_sigma']


class TestNSimplexTemperatureSequence:
    """Tests for Theorem CM: n-simplex temperature sequence."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = n_simplex_temperature_sequence(n_max=10)

    def test_temperature_decreasing(self):
        assert self.result['temperature_decreasing'] == True

    def test_f_increasing(self):
        assert self.result['F_increasing'] == True

    def test_t2_matches_constant(self):
        np.testing.assert_allclose(
            self.result['T_2'], T_STAR,
            rtol=1e-8, atol=1e-10,
        )

    def test_t3_matches_constant(self):
        np.testing.assert_allclose(
            self.result['T_3'], T_STAR3,
            rtol=1e-8, atol=1e-10,
        )

    def test_sequence_length(self):
        assert len(self.result['sequence']) == 10


class TestExchangeCoherenceAlgebra:
    """Tests for Theorems CS-CU: exchange-coherence algebra."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = exchange_coherence_algebra()

    def test_r_formula_matches_numerical(self):
        assert self.result['R_formula_matches_numerical'] == True

    def test_r_alt_matches(self):
        assert self.result['R_alt_matches'] == True

    def test_all_d_verified(self):
        assert self.result['all_d_verified'] == True

    def test_r_monotone(self):
        assert self.result['R_monotone'] == True

    def test_curvature_ratio_exact(self):
        assert self.result['curvature_ratio_exact'] == True

    def test_t_ratio_matches(self):
        assert self.result['T_ratio_matches'] == True

    def test_kappa_3_over_2(self):
        np.testing.assert_allclose(
            self.result['kappa_3_over_2'], 2.0 / 3.0,
            rtol=1e-8, atol=1e-10,
        )


class TestSigmaUnification:
    """Tests for Theorems DN-DO: sigma parametrization and number field classification."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = sigma_unification()

    def test_all_representations_verified(self):
        assert self.result['all_representations_verified'] == True

    def test_telescope_verified(self):
        assert self.result['telescope_verified'] == True

    def test_e6_e7_rational(self):
        assert self.result['e6_e7_rational'] == True

    def test_f4_e8_irrational(self):
        assert self.result['f4_e8_irrational'] == True

    def test_number_field_classification(self):
        assert self.result['number_field_classification'] == True

    def test_sigma_1_value(self):
        expected = np.log(PHI) / PHI
        np.testing.assert_allclose(
            self.result['sigma_1'], expected,
            rtol=1e-8, atol=1e-10,
        )


class TestDeepStructureIdentities:
    """Tests for Theorems EB-EE: beta function, zeta link, phi-cube, Z2 symmetry."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.result = deep_structure_identities()

    def test_beta_function_verified(self):
        assert self.result['beta_all_checks'] == True

    def test_beta_coefficient(self):
        np.testing.assert_allclose(
            self.result['beta_coefficient'], -1.0 / PHI,
            rtol=1e-8, atol=1e-10,
        )

    def test_zeta_link_verified(self):
        assert self.result['zeta_link_verified'] == True

    def test_phi_cube_decomposition(self):
        assert self.result['hessian_is_phi_cube'] == True

    def test_fisher_rao_is_phi(self):
        assert self.result['fisher_rao_is_phi'] == True

    def test_coherence_is_phi_squared(self):
        assert self.result['coherence_is_phi_squared'] == True

    def test_decomposition_exact(self):
        assert self.result['decomposition_exact'] == True

    def test_z2_symmetry_exact(self):
        assert self.result['z2_symmetry_exact'] == True

    def test_breaking_chain(self):
        assert self.result['breaking_chain'] == 'S3 -> Z2 -> {1}'
