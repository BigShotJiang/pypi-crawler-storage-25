"""Root system completeness: conservation law on ALL 9 Killing-Cartan families.

The Killing-Cartan classification gives exactly 9 families of irreducible
root systems: A_n, B_n, C_n, D_n, E6, E7, E8, F4, G2. The conservation
law lambda + kappa + eta = 1 holds for all of them through the unified
BCC grid pipeline (bcc_grid -> eigenvalues -> normalization).

Conservation is trivially true by construction (eigenvalue sum / trace = 1).
The real mathematical content is that the BCC grid is well-defined for
every irreducible root system and the trace is nonzero (except A2).
"""

import numpy as np
import pytest

from watkins_nn import (
    root_system_conservation,
    bcc_grid,
    bcc_eigenvalues,
    bn_bcc_formula,
    cn_bcc_formula,
    langlands_dual_check,
    g2_bcc_formula,
)
from watkins_nn.bridges import _ALL_SYSTEMS, g2_analysis


# --- Completeness: all 9 families ---

class TestKillingCartanCompleteness:
    """Verify all 9 Killing-Cartan families are in the unified pipeline."""

    NINE_FAMILIES = ['A3', 'B3', 'C3', 'D4', 'E6', 'E7', 'E8', 'F4', 'G2']

    def test_all_nine_families_conservation(self):
        """lambda + kappa + eta = 1 for one instance per family."""
        for name in self.NINE_FAMILIES:
            r = root_system_conservation(name)
            assert not r['degenerate'], f"{name} unexpectedly degenerate"
            assert r['conservation_error'] < 1e-10, (
                f"{name}: conservation error {r['conservation_error']}"
            )

    def test_killing_cartan_exhaustive(self):
        """_ALL_SYSTEMS covers all 9 families."""
        families_found = set()
        for name in _ALL_SYSTEMS:
            if name.startswith('A'):
                families_found.add('A')
            elif name.startswith('B'):
                families_found.add('B')
            elif name.startswith('C'):
                families_found.add('C')
            elif name.startswith('D'):
                families_found.add('D')
            elif name in ('E6', 'E7', 'E8', 'F4', 'G2'):
                families_found.add(name)
        expected = {'A', 'B', 'C', 'D', 'E6', 'E7', 'E8', 'F4', 'G2'}
        assert families_found == expected

    def test_all_systems_have_valid_bcc_grid(self):
        """bcc_grid() succeeds for every system in _ALL_SYSTEMS."""
        for name in _ALL_SYSTEMS:
            grid = bcc_grid(name)
            assert grid.shape == (3, 3), f"{name}: wrong grid shape {grid.shape}"

    def test_invalid_system_raises(self):
        """Unknown system name raises ValueError, not RecursionError."""
        with pytest.raises(ValueError, match="Unknown root system"):
            bcc_grid("XYZ")


# --- B_n conservation ---

class TestBnConservation:
    """B_n root systems through unified conservation path."""

    @pytest.mark.parametrize("n", [3, 4, 5, 6, 7, 8])
    def test_bn_conservation(self, n):
        r = root_system_conservation(f"B{n}")
        assert r['conservation_error'] < 1e-10
        assert not r['degenerate']

    @pytest.mark.parametrize("n", [3, 4, 5, 6, 7, 8])
    def test_bn_not_on_simplex(self, n):
        r = root_system_conservation(f"B{n}")
        assert not r['on_simplex'], f"B{n} unexpectedly on simplex"

    @pytest.mark.parametrize("n", [3, 4, 5, 6, 7, 8])
    def test_bn_null_eigenvalue_zero(self, n):
        """B_n bisymmetric grids have null eigenvalue = 0."""
        r = root_system_conservation(f"B{n}")
        assert np.isclose(r['kappa_R'], 0.0, atol=1e-10)

    @pytest.mark.parametrize("n", [3, 4, 5, 6, 7, 8])
    def test_bn_grid_matches_formula(self, n):
        """bcc_grid('B{n}') must match bn_bcc_formula(n) exactly."""
        assert np.array_equal(bcc_grid(f"B{n}"), bn_bcc_formula(n))


# --- C_n conservation ---

class TestCnConservation:
    """C_n root systems through unified conservation path."""

    @pytest.mark.parametrize("n", [3, 4, 5, 6, 7, 8])
    def test_cn_conservation(self, n):
        r = root_system_conservation(f"C{n}")
        assert r['conservation_error'] < 1e-10
        assert not r['degenerate']

    @pytest.mark.parametrize("n", [3, 4, 5, 6, 7, 8])
    def test_cn_grid_matches_formula(self, n):
        """bcc_grid('C{n}') must match cn_bcc_formula(n) exactly."""
        assert np.array_equal(bcc_grid(f"C{n}"), cn_bcc_formula(n))


# --- Langlands duality B_n = C_n ---

class TestLanglandsDuality:
    """B_n and C_n have identical BCC grids and conservation triples."""

    @pytest.mark.parametrize("n", [3, 4, 5, 6, 7, 8])
    def test_bn_equals_cn_grid(self, n):
        assert np.array_equal(bcc_grid(f"B{n}"), bcc_grid(f"C{n}"))

    @pytest.mark.parametrize("n", [3, 4, 5, 6, 7, 8])
    def test_bn_equals_cn_conservation(self, n):
        b = root_system_conservation(f"B{n}")
        c = root_system_conservation(f"C{n}")
        assert np.isclose(b['lambda_R'], c['lambda_R'], rtol=1e-12)
        assert np.isclose(b['kappa_R'], c['kappa_R'], atol=1e-12)
        assert np.isclose(b['eta_R'], c['eta_R'], rtol=1e-12)

    @pytest.mark.parametrize("n", [3, 4, 5, 6, 7, 8])
    def test_langlands_dual_check(self, n):
        assert langlands_dual_check(n)


# --- G2 conservation ---

class TestG2Conservation:
    """G2 through unified conservation path matches dedicated g2_analysis."""

    def test_g2_conservation_unified(self):
        r = root_system_conservation('G2')
        assert r['conservation_error'] < 1e-10
        assert not r['degenerate']

    def test_g2_matches_analysis(self):
        """root_system_conservation('G2') matches g2_analysis() lambda."""
        cons = root_system_conservation('G2')
        anal = g2_analysis()
        assert np.isclose(cons['lambda_R'], anal['lambda_R'], rtol=1e-10)

    def test_g2_not_on_simplex(self):
        r = root_system_conservation('G2')
        assert not r['on_simplex']
        assert r['eta_R'] < -0.5  # G2 eta = -1.0, deepest off-simplex

    def test_g2_grid_matches_constant(self):
        from watkins_nn.cascade import G2_BCC_GRID
        assert np.array_equal(bcc_grid('G2'), G2_BCC_GRID)


# --- A2 degeneracy ---

class TestA2Degeneracy:
    """A2 has trace 0 and is the only degenerate system."""

    def test_a2_is_degenerate(self):
        r = root_system_conservation('A2')
        assert r['degenerate']
        assert abs(r['trace']) < 1e-12
