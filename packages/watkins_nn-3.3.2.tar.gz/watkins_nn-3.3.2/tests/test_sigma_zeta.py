"""Tests for Theorems EN-EP: Sigma-Zeta special values.

Theorem EN (Sigma-Zeta at s=2):
    S(2) = (pi^2/(6*phi)) * [12*ln(A) - gamma - ln(2*pi/phi)]
    where A = Glaisher-Kinkelin constant, gamma = Euler-Mascheroni.

Theorem EO (Sigma-Zeta at s=0):
    S(0) = ln(2*pi/phi) / (2*phi)

Theorem EP (Sigma at Trivial Zeros -- Odd Zeta Values):
    S(-2n) = (-1)^(n+1) * (2n)! * zeta(2n+1) / (2*(2*pi)^(2n)*phi)
"""

import math
import pytest

from watkins_nn.bridges_dimensional import sigma_zeta_special_values
from watkins_nn.constants import PHI


class TestSigmaZetaSpecialValues:
    """Verify exact closed forms for the sigma Dirichlet series."""

    @pytest.fixture(scope="class")
    def result(self):
        return sigma_zeta_special_values()

    # ---- Theorem EN: S(2) ----

    def test_en_identity(self, result):
        """S(2) = (pi^2/(6*phi)) * [12*ln(A) - gamma - ln(2*pi/phi)]."""
        assert result['en_identity_verified'], (
            "EN identity: S(2) formula disagrees with numerical zeta derivative"
        )

    def test_en_zeta_prime_2_subidentity(self, result):
        """zeta'(2) = (pi^2/6)*(gamma + ln(2*pi) - 12*ln(A))."""
        assert result['zeta_prime_2_subidentity']

    def test_en_s2_positive(self, result):
        """S(2) is positive (all sigma_n > 0)."""
        assert result['S2_formula'] > 0

    def test_en_golden_log_argument(self, result):
        """The argument 2*pi/phi appears in the formula."""
        expected = 2 * math.pi / PHI
        assert abs(result['golden_log_argument'] - expected) < 1e-12

    def test_en_formula_value(self, result):
        """S(2) ~ 1.0687 to 4 decimal places."""
        assert abs(result['S2_formula'] - 1.0687) < 0.001

    # ---- Theorem EO: S(0) ----

    def test_eo_identity(self, result):
        """S(0) = ln(2*pi/phi) / (2*phi)."""
        assert result['eo_identity_verified']

    def test_eo_formula_vs_direct(self, result):
        """Formula matches direct computation from known zeta(0), zeta'(0)."""
        assert abs(result['S0_formula'] - result['S0_direct']) < 1e-12

    def test_eo_positive(self, result):
        """S(0) > 0 since 2*pi/phi > 1."""
        assert result['S0_formula'] > 0

    def test_eo_golden_2pi(self, result):
        """The golden-modified 2*pi is 2*pi/phi ~ 3.883."""
        assert abs(result['golden_2pi'] - 3.883) < 0.001

    def test_eo_ln_golden_2pi(self, result):
        """ln(2*pi/phi) ~ 1.357."""
        assert abs(result['ln_golden_2pi'] - 1.357) < 0.001

    # ---- Theorem EP: S(-2n) at trivial zeros ----

    def test_ep_n1(self, result):
        """S(-2) = zeta(3)/(4*pi^2*phi)."""
        assert result['ep_n1_verified']

    def test_ep_apery_link(self, result):
        """S(-2) links to the Apery constant."""
        zeta_3 = 1.2020569031595943
        expected = zeta_3 / (4 * math.pi**2 * PHI)
        assert abs(result['S_neg2'] - expected) < 1e-12

    def test_ep_s_neg2_positive(self, result):
        """S(-2) > 0 (n=1 gives (-1)^2 = +1)."""
        assert result['S_neg2'] > 0

    def test_ep_simplification(self, result):
        """The n=2 formula simplifies to -3*zeta(5)/(4*pi^4*phi)."""
        assert result['ep_simplify_check']

    def test_ep_general_formula(self, result):
        """General formula verified for n=1,2,3."""
        assert result['ep_general_verified']

    def test_ep_s_neg4_negative(self, result):
        """S(-4) < 0 (n=2 gives (-1)^3 = -1)."""
        assert result['S_neg4'] < 0

    # ---- Honest negatives ----

    def test_dirichlet_twist_tautological(self, result):
        """The Dirichlet character twist is algebraically tautological."""
        assert result['dirichlet_twist_tautological']

    def test_bcc_lie_bridge_not_found(self, result):
        """No clean BCC-Lie theory bridge was found for exceptionals."""
        assert not result['bcc_lie_bridge_found']

    def test_odd_zeta_encoded(self, result):
        """The sigma series encodes all odd zeta values at trivial zeros."""
        assert result['odd_zeta_encoded']


class TestSigmaZetaNumericalConsistency:
    """Cross-check sigma-zeta values by independent computation."""

    def test_s2_from_partial_sums(self):
        """S(2) from 10k partial sums is within 1% of the formula."""
        phi = PHI
        ln_phi = math.log(phi)
        gamma_em = 0.5772156649015328606
        ln_A = 0.24875447703378426255

        S2_formula = (math.pi**2 / (6 * phi)) * (
            12 * ln_A - gamma_em - math.log(2 * math.pi / phi)
        )
        S2_partial = sum(
            (math.log(n * phi) / phi) / n**2 for n in range(1, 10001)
        )
        # With 10k terms, tail is O(1/N) ~ 1e-4
        assert abs(S2_formula - S2_partial) / abs(S2_formula) < 0.01

    def test_s0_from_known_zeta_values(self):
        """S(0) computed from zeta(0)=-1/2 and zeta'(0)=-ln(2*pi)/2."""
        phi = PHI
        zeta_0 = -0.5
        zeta_prime_0 = -0.5 * math.log(2 * math.pi)
        S0 = (1 / phi) * (-zeta_prime_0 + math.log(phi) * zeta_0)
        expected = math.log(2 * math.pi / phi) / (2 * phi)
        assert abs(S0 - expected) < 1e-14

    def test_s_neg2_from_functional_equation(self):
        """S(-2) from the functional equation derivative."""
        phi = PHI
        zeta_3 = 1.2020569031595943
        # zeta'(-2) = -zeta(3)/(4*pi^2) from functional equation
        zp_neg2 = -zeta_3 / (4 * math.pi**2)
        # S(-2) = -zp_neg2/phi since zeta(-2)=0
        S_neg2 = -zp_neg2 / phi
        expected = zeta_3 / (4 * math.pi**2 * phi)
        assert abs(S_neg2 - expected) < 1e-14

    def test_alternating_signs_at_trivial_zeros(self):
        """S(-2n) alternates sign: +, -, +, -, ... for n=1,2,3,..."""
        phi = PHI
        odd_zetas = {
            3: 1.2020569031595943,
            5: 1.0369277551433699,
            7: 1.0083492773819228,
        }
        for n in [1, 2, 3]:
            z_odd = odd_zetas[2 * n + 1]
            fac = math.factorial(2 * n)
            S_val = (-1)**(n + 1) * fac * z_odd / (2 * (2 * math.pi)**(2 * n) * phi)
            expected_positive = (n % 2 == 1)
            assert (S_val > 0) == expected_positive, f"n={n}: expected sign {'+'if expected_positive else '-'}"

    def test_golden_modified_2pi(self):
        """2*pi/phi is the recurring quantity in both EN and EO."""
        golden_2pi = 2 * math.pi / PHI
        # It appears in S(2) as ln(2*pi/phi)
        # It appears in S(0) as ln(2*pi/phi) / (2*phi)
        assert abs(golden_2pi - 3.883222) < 0.001
        # And ln(golden_2pi) = ln(2*pi) - ln(phi)
        assert abs(math.log(golden_2pi) - (math.log(2*math.pi) - math.log(PHI))) < 1e-14
