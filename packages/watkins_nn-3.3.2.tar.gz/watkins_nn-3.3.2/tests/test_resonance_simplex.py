"""Tests for the resonance_simplex module.

Tests cover:
- Part I: n-Simplex Extension with Resonance Coordinate rho
  - Watkins temperature for various n
  - Golden equilibrium extension (THEOREM)
  - 2-simplex cross-check against constants.py
  - 3-simplex equilibrium properties
  - Free energy minimum verification
  - Riemannian eigenspectrum (THEOREM)
  - Coordinate eigenvalues
  - Asymptotic saturation (large n)
  - Cascade and triality connections
- Part II: Threshold Derivations
  - Entropy phase transition at 1/e (THEOREM)
  - Causality firewall at 1 - ln(2) (THEOREM | H_eff)
  - Information paradox at ln(2) (THEOREM | H_eff)
  - Complement theorem: firewall + paradox = 1
  - Equilibrium regime classification
  - Threshold report consistency
"""

import math
import pytest

from watkins_nn.constants import (
    PHI, PHI_INV, PHI_SQUARED, SQRT5,
    T_STAR, T_STAR3, LAM_STAR, KAP_STAR, ETA_STAR, RHO_STAR,
    MU_COH, MU_ASYM, MU_SLOW, MU_FAST,
    CONSERVATION_EPSILON,
)
from watkins_nn.resonance_simplex import (
    # Constants
    T_STAR_3, LAM_STAR_3, KAP_STAR_3, ETA_STAR_3, RHO_STAR_3,
    MU_COH_3, MU_ASYM_3, TAU_COH_3, TAU_ASYM_3,
    MU_SLOW_COORD_3, MU_ASYM_COORD_3, MU_FAST_COORD_3,
    LAMBDA_NAT_BIT, LAMBDA_UNIT_INFO, LAMBDA_BIT_CAPACITY,
    # Classes
    ResonanceSimplexState, SimplexEquilibrium,
    EigenspectrumResult, CoordinateEigenvalues, ThresholdDerivation,
    # Equilibrium
    watkins_temperature, n_simplex_equilibrium,
    resonance_equilibrium, free_energy, free_energy_gradient,
    # Eigenspectrum
    riemannian_eigenspectrum, coordinate_eigenvalues,
    eigenspectrum_asymptotics,
    # Connections
    cascade_connection, triality_connection,
    # Threshold derivations
    derive_entropy_phase_transition, derive_causality_firewall,
    derive_information_paradox, equilibrium_regime_theorem,
    complement_theorem, threshold_report,
    # Report
    resonance_simplex_report,
)


# =============================================================================
# WATKINS TEMPERATURE
# =============================================================================

class TestWatkinsTemperature:

    def test_n1(self):
        """T_1* = phi/ln(phi) ~ 3.359."""
        T1 = watkins_temperature(1)
        assert abs(T1 - PHI / math.log(PHI)) < 1e-12

    def test_n2_matches_constants(self):
        """T_2* = phi/ln(2*phi) must match T_STAR from constants.py."""
        T2 = watkins_temperature(2)
        assert abs(T2 - T_STAR) < 1e-12

    def test_n3_matches_constants(self):
        """T_3* = phi/ln(3*phi) must match T_STAR3 from constants.py."""
        T3 = watkins_temperature(3)
        assert abs(T3 - T_STAR3) < 1e-12

    def test_decreasing_in_n(self):
        """T_n* is strictly decreasing in n."""
        temps = [watkins_temperature(n) for n in range(1, 20)]
        for i in range(len(temps) - 1):
            assert temps[i] > temps[i + 1]

    def test_approaches_zero(self):
        """T_n* -> 0 as n -> infinity."""
        T1000 = watkins_temperature(1000)
        assert T1000 < 0.25

    def test_always_positive(self):
        """T_n* > 0 for all n >= 1."""
        for n in [1, 2, 3, 10, 100, 1000]:
            assert watkins_temperature(n) > 0

    def test_invalid_n(self):
        with pytest.raises(ValueError):
            watkins_temperature(0)


# =============================================================================
# N-SIMPLEX EQUILIBRIUM
# =============================================================================

class TestNSimplexEquilibrium:

    def test_n2_lam_star(self):
        """n=2: lam* = 1/phi."""
        eq = n_simplex_equilibrium(2)
        assert abs(eq.lam_star - PHI_INV) < 1e-12

    def test_n2_symmetric_star(self):
        """n=2: x_i* = (1-1/phi)/2 must match KAP_STAR."""
        eq = n_simplex_equilibrium(2)
        assert abs(eq.symmetric_star - KAP_STAR) < 1e-12

    def test_n3_lam_star(self):
        """n=3: lam* = 1/phi (same as n=2)."""
        eq = n_simplex_equilibrium(3)
        assert abs(eq.lam_star - PHI_INV) < 1e-12

    def test_n3_symmetric_star(self):
        """n=3: x_i* = (1-1/phi)/3 must match RHO_STAR."""
        eq = n_simplex_equilibrium(3)
        assert abs(eq.symmetric_star - RHO_STAR) < 1e-12

    def test_conservation_n2(self):
        """n=2: lam* + 2*x* = 1."""
        eq = n_simplex_equilibrium(2)
        assert abs(eq.lam_star + 2 * eq.symmetric_star - 1.0) < 1e-12

    def test_conservation_n3(self):
        """n=3: lam* + 3*x* = 1."""
        eq = n_simplex_equilibrium(3)
        assert abs(eq.lam_star + 3 * eq.symmetric_star - 1.0) < 1e-12

    def test_conservation_general(self):
        """lam* + n*x* = 1 for all n."""
        for n in range(1, 10):
            eq = n_simplex_equilibrium(n)
            assert abs(eq.lam_star + n * eq.symmetric_star - 1.0) < 1e-12

    def test_lam_star_universal(self):
        """lam* = 1/phi for all n (universal)."""
        for n in range(1, 10):
            eq = n_simplex_equilibrium(n)
            assert abs(eq.lam_star - PHI_INV) < 1e-12

    def test_symmetric_star_formula(self):
        """x_i* = 1/(n*phi^2) for all n."""
        for n in range(1, 10):
            eq = n_simplex_equilibrium(n)
            expected = 1 / (n * PHI_SQUARED)
            assert abs(eq.symmetric_star - expected) < 1e-10

    def test_status_is_theorem(self):
        eq = n_simplex_equilibrium(3)
        assert eq.status == "THEOREM"

    def test_invalid_n(self):
        with pytest.raises(ValueError):
            n_simplex_equilibrium(0)


# =============================================================================
# RESONANCE EQUILIBRIUM (3-SIMPLEX)
# =============================================================================

class TestResonanceEquilibrium:

    def test_conservation(self):
        """lam + kap + eta + rho = 1."""
        eq = resonance_equilibrium()
        assert abs(sum(eq.components) - 1.0) < 1e-12

    def test_z3_symmetric(self):
        """Equilibrium is Z_3 symmetric: kap = eta = rho."""
        eq = resonance_equilibrium()
        assert eq.is_z3_symmetric

    def test_lam_is_golden(self):
        eq = resonance_equilibrium()
        assert abs(eq.lam - PHI_INV) < 1e-12

    def test_rho_star_value(self):
        eq = resonance_equilibrium()
        assert abs(eq.rho - RHO_STAR) < 1e-12

    def test_simplex_entropy_positive(self):
        eq = resonance_equilibrium()
        assert eq.simplex_entropy > 0


# =============================================================================
# FREE ENERGY
# =============================================================================

class TestFreeEnergy:

    def test_equilibrium_is_minimum(self):
        """Free energy at equilibrium < nearby points."""
        eq = resonance_equilibrium()
        F_eq = free_energy(eq)

        # Perturb lambda slightly
        eps = 0.01
        for delta in [eps, -eps]:
            lam = LAM_STAR + delta
            s = (1 - lam) / 3
            perturbed = ResonanceSimplexState(lam, s, s, s)
            F_perturbed = free_energy(perturbed)
            assert F_perturbed > F_eq

    def test_gradient_zero_at_equilibrium(self):
        """dF/dlam = 0 at lam* = 1/phi."""
        grad = free_energy_gradient(LAM_STAR, n=3)
        assert abs(grad) < 1e-10

    def test_gradient_negative_below(self):
        """dF/dlam < 0 for lam < lam* (drives lam up)."""
        grad = free_energy_gradient(0.3, n=3)
        assert grad < 0

    def test_gradient_positive_above(self):
        """dF/dlam > 0 for lam > lam* (drives lam down)."""
        grad = free_energy_gradient(0.8, n=3)
        assert grad > 0

    def test_gradient_zero_n2(self):
        """dF/dlam = 0 at lam* for n=2 as well."""
        grad = free_energy_gradient(LAM_STAR, n=2)
        assert abs(grad) < 1e-10

    def test_free_energy_finite(self):
        eq = resonance_equilibrium()
        assert math.isfinite(free_energy(eq))


# =============================================================================
# RESONANCE SIMPLEX STATE
# =============================================================================

class TestResonanceSimplexState:

    def test_valid_state(self):
        s = ResonanceSimplexState(0.5, 0.2, 0.2, 0.1)
        assert abs(sum(s.components) - 1.0) < 1e-12

    def test_conservation_violation(self):
        with pytest.raises(ValueError, match="Conservation violation"):
            ResonanceSimplexState(0.5, 0.5, 0.5, 0.5)

    def test_negative_component(self):
        with pytest.raises(ValueError):
            ResonanceSimplexState(1.1, -0.1, 0.0, 0.0)

    def test_boundary_state(self):
        """Pure states at simplex vertices."""
        s = ResonanceSimplexState(1.0, 0.0, 0.0, 0.0)
        assert abs(s.lam - 1.0) < 1e-12

    def test_z3_symmetric_true(self):
        s = ResonanceSimplexState(0.5, 1 / 6, 1 / 6, 1 / 6)
        assert s.is_z3_symmetric

    def test_z3_symmetric_false(self):
        s = ResonanceSimplexState(0.5, 0.3, 0.1, 0.1)
        assert not s.is_z3_symmetric

    def test_simplex_entropy_uniform(self):
        """Entropy is maximized at the uniform distribution."""
        uniform = ResonanceSimplexState(0.25, 0.25, 0.25, 0.25)
        eq = resonance_equilibrium()
        assert uniform.simplex_entropy > eq.simplex_entropy


# =============================================================================
# RIEMANNIAN EIGENSPECTRUM
# =============================================================================

class TestRiemannianEigenspectrum:

    def test_n2_matches_constants(self):
        """n=2: mu_coh must match MU_COH from constants.py."""
        spec = riemannian_eigenspectrum(2)
        assert abs(spec.mu_coh - MU_COH) < 1e-10

    def test_n2_asym_matches_constants(self):
        """n=2: mu_asym must match MU_ASYM from constants.py."""
        spec = riemannian_eigenspectrum(2)
        assert abs(spec.mu_asym - MU_ASYM) < 1e-10

    def test_n2_degeneracy(self):
        spec = riemannian_eigenspectrum(2)
        assert spec.asym_degeneracy == 1

    def test_n3_degeneracy(self):
        spec = riemannian_eigenspectrum(3)
        assert spec.asym_degeneracy == 2

    def test_n3_eigenvalues_positive(self):
        spec = riemannian_eigenspectrum(3)
        assert spec.mu_coh > 0
        assert spec.mu_asym > 0

    def test_n3_coherence_slower_than_asymmetry(self):
        """mu_coh < mu_asym for all n >= 2."""
        for n in range(2, 10):
            spec = riemannian_eigenspectrum(n)
            assert spec.mu_coh < spec.mu_asym

    def test_n3_closed_form(self):
        """Verify closed-form expression for n=3."""
        spec = riemannian_eigenspectrum(3)
        expected_coh = (3 / 4) * PHI_SQUARED * (1 + T_STAR3 * PHI)
        expected_asym = 3 * T_STAR3 * PHI_SQUARED
        assert abs(spec.mu_coh - expected_coh) < 1e-12
        assert abs(spec.mu_asym - expected_asym) < 1e-12

    def test_n3_matches_module_constants(self):
        """Module constants MU_COH_3, MU_ASYM_3 match function output."""
        spec = riemannian_eigenspectrum(3)
        assert abs(spec.mu_coh - MU_COH_3) < 1e-12
        assert abs(spec.mu_asym - MU_ASYM_3) < 1e-12

    def test_timescales_inverse(self):
        spec = riemannian_eigenspectrum(3)
        assert abs(spec.tau_coh - 1 / spec.mu_coh) < 1e-12
        assert abs(spec.tau_asym - 1 / spec.mu_asym) < 1e-12

    def test_general_closed_form(self):
        """mu_coh(n) = (n/(n+1)) * phi^2 * (1 + T_n* * phi) for all n."""
        for n in range(1, 15):
            spec = riemannian_eigenspectrum(n)
            T_n = watkins_temperature(n)
            expected = (n / (n + 1)) * PHI_SQUARED * (1 + T_n * PHI)
            assert abs(spec.mu_coh - expected) < 1e-10

    def test_mu_asym_formula(self):
        """mu_asym(n) = n * T_n* * phi^2 for all n."""
        for n in range(1, 15):
            spec = riemannian_eigenspectrum(n)
            T_n = watkins_temperature(n)
            expected = n * T_n * PHI_SQUARED
            assert abs(spec.mu_asym - expected) < 1e-10

    def test_status(self):
        spec = riemannian_eigenspectrum(3)
        assert spec.status == "THEOREM"

    def test_invalid_n(self):
        with pytest.raises(ValueError):
            riemannian_eigenspectrum(0)


# =============================================================================
# COORDINATE EIGENVALUES
# =============================================================================

class TestCoordinateEigenvalues:

    def test_n2_matches_constants(self):
        """n=2 coordinate eigenvalues must match MU_SLOW, MU_FAST."""
        coord = coordinate_eigenvalues(2)
        assert abs(coord.eigenvalues[0] - MU_SLOW) < 1e-6
        assert abs(coord.eigenvalues[-1] - MU_FAST) < 1e-6

    def test_n3_count(self):
        """n=3 should have 3 eigenvalues."""
        coord = coordinate_eigenvalues(3)
        assert len(coord.eigenvalues) == 3

    def test_n3_sorted(self):
        coord = coordinate_eigenvalues(3)
        assert coord.eigenvalues == sorted(coord.eigenvalues)

    def test_n3_all_positive(self):
        coord = coordinate_eigenvalues(3)
        assert all(ev > 0 for ev in coord.eigenvalues)

    def test_n3_asym_matches_riemannian(self):
        """The middle eigenvalue (asymmetry) should match Riemannian mu_asym."""
        coord = coordinate_eigenvalues(3)
        spec = riemannian_eigenspectrum(3)
        # The asymmetry eigenvalue appears in both
        assert abs(MU_ASYM_COORD_3 - spec.mu_asym) < 1e-10

    def test_n3_module_constants(self):
        """Module constants match function output."""
        coord = coordinate_eigenvalues(3)
        assert abs(coord.eigenvalues[0] - MU_SLOW_COORD_3) < 1e-10
        assert abs(coord.eigenvalues[1] - MU_ASYM_COORD_3) < 1e-10
        assert abs(coord.eigenvalues[-1] - MU_FAST_COORD_3) < 1e-10

    def test_timescales(self):
        coord = coordinate_eigenvalues(3)
        for ev, tau in zip(coord.eigenvalues, coord.timescales):
            assert abs(tau - 1.0 / ev) < 1e-12

    def test_invalid_n(self):
        with pytest.raises(ValueError):
            coordinate_eigenvalues(1)


# =============================================================================
# ASYMPTOTIC BEHAVIOR
# =============================================================================

class TestAsymptotics:

    def test_mu_coh_above_phi_squared(self):
        """mu_coh(n) > phi^2 for all finite n (approaches from above)."""
        for n in [2, 5, 10, 100, 1000]:
            spec = riemannian_eigenspectrum(n)
            assert spec.mu_coh > PHI_SQUARED

    def test_mu_coh_approaches_phi_squared(self):
        """mu_coh(n) gets closer to phi^2 for large n (log convergence)."""
        r100 = riemannian_eigenspectrum(100).mu_coh / PHI_SQUARED
        r1000 = riemannian_eigenspectrum(1000).mu_coh / PHI_SQUARED
        assert r1000 < r100  # ratio shrinks toward 1

    def test_mu_asym_grows(self):
        """mu_asym(n) grows with n."""
        a10 = eigenspectrum_asymptotics(10)
        a100 = eigenspectrum_asymptotics(100)
        assert a100['mu_asym'] > a10['mu_asym']

    def test_mu_coh_monotone_decreasing(self):
        """mu_coh decreases toward phi^2 for n >= 2."""
        prev = riemannian_eigenspectrum(2).mu_coh
        for n in [3, 5, 10, 50, 100]:
            current = riemannian_eigenspectrum(n).mu_coh
            assert current < prev
            prev = current

    def test_asymptotic_formula(self):
        """mu_coh(n) = (n/(n+1)) * phi^2 * (1 + phi^2/ln(n*phi))."""
        for n in [100, 500, 1000]:
            spec = riemannian_eigenspectrum(n)
            approx = (n / (n + 1)) * PHI_SQUARED * (1 + PHI_SQUARED / math.log(n * PHI))
            assert abs(spec.mu_coh - approx) / spec.mu_coh < 1e-10


# =============================================================================
# THRESHOLD CONSTANTS
# =============================================================================

class TestThresholdConstants:

    def test_nat_bit_value(self):
        """1 - ln(2) ~ 0.3069."""
        assert abs(LAMBDA_NAT_BIT - (1 - math.log(2))) < 1e-15

    def test_unit_info_value(self):
        """1/e ~ 0.3679."""
        assert abs(LAMBDA_UNIT_INFO - 1.0 / math.e) < 1e-15

    def test_bit_capacity_value(self):
        """ln(2) ~ 0.6931."""
        assert abs(LAMBDA_BIT_CAPACITY - math.log(2)) < 1e-15

    def test_ordering(self):
        """0 < firewall < phase_transition < equilibrium < paradox < 1."""
        assert 0 < LAMBDA_NAT_BIT
        assert LAMBDA_NAT_BIT < LAMBDA_UNIT_INFO
        assert LAMBDA_UNIT_INFO < LAM_STAR
        assert LAM_STAR < LAMBDA_BIT_CAPACITY
        assert LAMBDA_BIT_CAPACITY < 1

    def test_complement(self):
        """firewall + paradox = 1."""
        assert abs(LAMBDA_NAT_BIT + LAMBDA_BIT_CAPACITY - 1.0) < 1e-15

    def test_firewall_refines_030(self):
        """1 - ln(2) ~ 0.3069, close to but not equal to 0.3."""
        assert abs(LAMBDA_NAT_BIT - 0.3) > 0.005  # not 0.3
        assert abs(LAMBDA_NAT_BIT - 0.3) < 0.01   # close to 0.3


# =============================================================================
# THRESHOLD DERIVATIONS
# =============================================================================

class TestEntropyPhaseTransition:

    def test_classification(self):
        d = derive_entropy_phase_transition()
        assert d.classification == "THEOREM"

    def test_value(self):
        d = derive_entropy_phase_transition()
        assert abs(d.value - 1 / math.e) < 1e-15

    def test_f_maximum_at_1_over_e(self):
        """f(x) = -x*ln(x) is maximized at x = 1/e."""
        x_max = 1 / math.e
        f_max = -x_max * math.log(x_max)
        # Check nearby points are smaller
        for dx in [0.01, -0.01, 0.05, -0.05]:
            x = x_max + dx
            f_x = -x * math.log(x)
            assert f_x < f_max

    def test_f_value_at_maximum(self):
        """f(1/e) = 1/e."""
        f = -(1 / math.e) * math.log(1 / math.e)
        assert abs(f - 1 / math.e) < 1e-15

    def test_equilibrium_past_transition(self):
        """lam* = 1/phi > 1/e."""
        assert LAM_STAR > LAMBDA_UNIT_INFO

    def test_no_h_eff_assumption(self):
        d = derive_entropy_phase_transition()
        assert "H_eff" not in d.assumptions[0]


class TestCausalityFirewall:

    def test_classification(self):
        d = derive_causality_firewall()
        assert "conditional" in d.classification.lower()

    def test_value(self):
        d = derive_causality_firewall()
        assert abs(d.value - (1 - math.log(2))) < 1e-15

    def test_h_eff_ratio_at_firewall(self):
        """At lam = 1-ln(2), H_eff/H = ln(2)."""
        ratio = 1 - LAMBDA_NAT_BIT
        assert abs(ratio - math.log(2)) < 1e-15

    def test_requires_h_eff(self):
        d = derive_causality_firewall()
        assert any("H_eff" in a for a in d.assumptions)


class TestInformationParadox:

    def test_classification(self):
        d = derive_information_paradox()
        assert "conditional" in d.classification.lower()

    def test_value(self):
        d = derive_information_paradox()
        assert abs(d.value - math.log(2)) < 1e-15

    def test_coupling_equals_1_bit(self):
        """ln(2) nats = 1 bit."""
        assert abs(LAMBDA_BIT_CAPACITY / math.log(2) - 1.0) < 1e-15

    def test_equilibrium_below_paradox(self):
        """lam* < ln(2): equilibrium is below the paradox."""
        assert LAM_STAR < LAMBDA_BIT_CAPACITY


class TestEquilibriumRegime:

    def test_inequality(self):
        """1/e < 1/phi < ln(2)."""
        regime = equilibrium_regime_theorem()
        assert regime['values']['1/e'] < regime['values']['1/phi']
        assert regime['values']['1/phi'] < regime['values']['ln(2)']

    def test_e_gt_phi(self):
        """e > phi (needed for 1/e < 1/phi)."""
        assert math.e > PHI

    def test_1_over_ln2_lt_phi(self):
        """1/ln(2) < phi (needed for 1/phi < ln(2))."""
        assert 1 / math.log(2) < PHI

    def test_regime_is_phase_transition(self):
        regime = equilibrium_regime_theorem()
        assert regime['regime'] == 'phase_transition'

    def test_position_in_regime(self):
        """The position (lam* - 1/e) / (ln2 - 1/e) should be in (0, 1)."""
        regime = equilibrium_regime_theorem()
        pos = regime['position_in_regime']
        assert 0 < pos < 1

    def test_status(self):
        regime = equilibrium_regime_theorem()
        assert "THEOREM" in regime['status']


class TestComplementTheorem:

    def test_sum_is_1(self):
        result = complement_theorem()
        assert result['sum_equals_1']

    def test_equilibrium_in_middle(self):
        result = complement_theorem()
        assert result['equilibrium_in_middle']

    def test_duality(self):
        """H_eff/H at paradox = firewall value."""
        h_eff_ratio = 1 - LAMBDA_BIT_CAPACITY
        assert abs(h_eff_ratio - LAMBDA_NAT_BIT) < 1e-15


# =============================================================================
# REPORTS
# =============================================================================

class TestThresholdReport:

    def test_all_thresholds_present(self):
        report = threshold_report()
        assert 'firewall' in report['thresholds']
        assert 'phase_transition' in report['thresholds']
        assert 'paradox' in report['thresholds']

    def test_firewall_note(self):
        report = threshold_report()
        assert '0.3' in report['thresholds']['firewall']['note']

    def test_from_axioms_includes_1_e(self):
        report = threshold_report()
        assert '1/e' in report['summary']['from_axioms'][0]


class TestResonanceSimplexReport:

    def test_report_runs(self):
        report = resonance_simplex_report()
        assert 'part_1_resonance_simplex' in report
        assert 'part_2_threshold_derivations' in report

    def test_equilibrium_status(self):
        report = resonance_simplex_report()
        eq = report['part_1_resonance_simplex']['equilibrium']
        assert eq['status'] == 'THEOREM'

    def test_eigenspectrum_status(self):
        report = resonance_simplex_report()
        spec = report['part_1_resonance_simplex']['riemannian_eigenspectrum']
        assert spec['status'] == 'THEOREM'

    def test_golden_concurrence_status(self):
        report = resonance_simplex_report()
        gc = report['golden_concurrence']
        assert gc['status'] == 'CONJECTURE (no derivation from axioms)'

    def test_golden_concurrence_value(self):
        report = resonance_simplex_report()
        gc = report['golden_concurrence']
        expected = 2 / PHI**1.5
        assert abs(gc['value'] - expected) < 1e-10


# =============================================================================
# CONNECTIONS
# =============================================================================

class TestCascadeConnection:

    def test_returns_dict(self):
        conn = cascade_connection()
        assert isinstance(conn, dict)

    def test_root_systems(self):
        conn = cascade_connection()
        assert conn['2_simplex']['root_system'] == 'A2'
        assert 'D3' in conn['3_simplex']['root_system']


class TestTrialityConnection:

    def test_returns_dict(self):
        conn = triality_connection()
        assert isinstance(conn, dict)

    def test_three_domains(self):
        conn = triality_connection()
        assert len(conn['mapping']) == 3

    def test_27_modes(self):
        conn = triality_connection()
        assert conn['triality_modes'] == 27


# =============================================================================
# MODULE CONSTANTS
# =============================================================================

class TestModuleConstants:

    def test_3simplex_conservation(self):
        """lam* + kap* + eta* + rho* = 1."""
        total = LAM_STAR_3 + KAP_STAR_3 + ETA_STAR_3 + RHO_STAR_3
        assert abs(total - 1.0) < 1e-12

    def test_3simplex_z3_symmetry(self):
        """kap* = eta* = rho*."""
        assert abs(KAP_STAR_3 - ETA_STAR_3) < 1e-12
        assert abs(ETA_STAR_3 - RHO_STAR_3) < 1e-12

    def test_mu_coh_3_positive(self):
        assert MU_COH_3 > 0

    def test_mu_asym_3_positive(self):
        assert MU_ASYM_3 > 0

    def test_mu_coh_3_lt_mu_asym_3(self):
        """Coherence mode is slower than asymmetry mode."""
        assert MU_COH_3 < MU_ASYM_3

    def test_tau_values(self):
        assert abs(TAU_COH_3 - 1 / MU_COH_3) < 1e-12
        assert abs(TAU_ASYM_3 - 1 / MU_ASYM_3) < 1e-12

    def test_coord_eigenvalues_sorted(self):
        assert MU_SLOW_COORD_3 < MU_ASYM_COORD_3 < MU_FAST_COORD_3

    def test_coord_asym_matches_riemannian(self):
        """Coordinate asymmetry eigenvalue = Riemannian asymmetry eigenvalue."""
        assert abs(MU_ASYM_COORD_3 - MU_ASYM_3) < 1e-10
