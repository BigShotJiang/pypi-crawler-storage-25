"""V₄ Bridge Integration: Graph-Theoretic Extension of the Bridge Field.

The biquadratic field Q(sqrt(3), sqrt(5)) has Galois group V₄ = Z₂ × Z₂,
with three non-trivial automorphisms corresponding to three quadratic
subfields.  This module proves that the SAME V₄ structure governs the
automorphism group of bilateral networks — weighted graphs with two
commuting involutory symmetries.

Three theorems:

    Theorem IA (Graph-Theoretic V₄):
        A weighted graph with two commuting fixed-point-free involutions
        and non-degenerate weights has Aut(G) = V₄.  Even bipartitions
        decompose into 3 singleton orbits bijecting V₄ \\ {e}.

    Theorem IB (MI Ordering):
        For bilateral-redundant networks with Aut(G) = V₄ and Gaussian
        dynamics, the even-bipartition MI spectrum satisfies:
            MI(sigma_3) < MI(sigma_1) < MI(sigma_2)
        whenever w_self < w_cal < w_intra (strict).
        The heterotopic partition (the "sqrt(15) element") is the system's
        most vulnerable integration mode.

    Theorem IC (Galois Correspondence):
        The bijection
            {sigma_F, sigma_B, sigma_F*sigma_B} <-> {P_hemi, P_homo, P_hetero}
        on even bipartitions is isomorphic to the subfield lattice
            {Q(sqrt5), Q(sqrt3), Q(sqrt15)} <-> Gal(Q(sqrt3,sqrt5)/Q)
        via the stabiliser map.  Both are instances of V₄ acting on
        its own non-trivial elements.

Connection to bridge_field.py:
    sigma_F  (functional swap L_i<->L_j, R_i<->R_j)  <->  sigma_2  (negates sqrt3)
    sigma_B  (bilateral swap L_i<->R_i)               <->  sigma_3  (negates sqrt5)
    sigma_FB (composite, heterotopic diagonal)         <->  sigma_4  (preserves sqrt15)

Limitations:
    - Automorphism search is O(N!) so we cap at N <= 8 nodes (4 per hemisphere).
    - MI values are computed for Gaussian VAR(1) processes.  The MI ORDERING
      is robust to noise scale, but absolute MI values are not meaningful.
"""

import math
import numpy as np
from itertools import combinations, permutations
from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass

from .bridge_field import QBiquad, PHI_Q, SQRT15_Q


# =============================================================================
# 1. BILATERAL NETWORK CONSTRUCTION
# =============================================================================

MAX_NODES = 8  # O(N!) automorphism search; N=8 is the practical limit


def make_bilateral_network(
    n_per_side: int,
    w_intra: float,
    w_cal: float,
    w_self: float = 0.1,
) -> np.ndarray:
    """Build a bilateral-redundant transition matrix.

    Nodes 0..n-1 form the left hemisphere, n..2n-1 the right.
    Connections: intrahemispheric (w_intra), callosal homotopic (w_cal),
    self-loops (w_self).  Rows are normalised to sum to 1.

    Parameters
    ----------
    n_per_side : int
        Nodes per hemisphere.  Total nodes = 2 * n_per_side.
    w_intra : float
        Intrahemispheric coupling weight (before normalisation).
    w_cal : float
        Callosal (inter-hemispheric homotopic) weight.
    w_self : float
        Self-coupling weight.

    Returns
    -------
    np.ndarray of shape (2n, 2n)
        Row-stochastic transition matrix.
    """
    n = n_per_side
    N = 2 * n
    if N > MAX_NODES:
        raise ValueError(
            f"Total nodes {N} exceeds MAX_NODES={MAX_NODES}. "
            f"Automorphism search is O(N!) and would be prohibitively slow."
        )
    A = np.zeros((N, N))
    for i in range(N):
        A[i, i] = w_self
    # Intrahemispheric: full connectivity within each hemisphere
    for i in range(n):
        for j in range(n):
            if i != j:
                A[i, j] = w_intra
                A[n + i, n + j] = w_intra
    # Callosal homotopic: L_i <-> R_i
    for i in range(n):
        A[i, n + i] = w_cal
        A[n + i, i] = w_cal
    # Normalise rows
    for i in range(N):
        s = A[i].sum()
        if s > 0:
            A[i] /= s
    return A


# =============================================================================
# 2. AUTOMORPHISM GROUP COMPUTATION
# =============================================================================

def compute_automorphisms(A: np.ndarray, tol: float = 1e-10) -> List[Tuple[int, ...]]:
    """Find all automorphisms of a weighted directed graph.

    An automorphism is a permutation pi of {0,...,N-1} such that
    A[pi(i), pi(j)] = A[i, j] for all i, j.

    Parameters
    ----------
    A : np.ndarray
        N x N transition/adjacency matrix.
    tol : float
        Tolerance for weight comparison.

    Returns
    -------
    List of permutation tuples.
    """
    n = A.shape[0]
    if n > MAX_NODES:
        raise ValueError(f"N={n} exceeds MAX_NODES={MAX_NODES}")
    auts = []
    for perm in permutations(range(n)):
        ok = True
        for i in range(n):
            for j in range(n):
                if abs(A[perm[i], perm[j]] - A[i, j]) > tol:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            auts.append(perm)
    return auts


def _compose(p1: Tuple[int, ...], p2: Tuple[int, ...]) -> Tuple[int, ...]:
    """Compose two permutations: (p1 o p2)(i) = p1[p2[i]]."""
    return tuple(p1[p2[k]] for k in range(len(p1)))


def _order(perm: Tuple[int, ...]) -> int:
    """Order of a permutation element."""
    identity = tuple(range(len(perm)))
    if perm == identity:
        return 1
    cur = perm
    for o in range(2, len(perm) + 2):
        cur = _compose(cur, perm)
        if cur == identity:
            return o
    return -1  # should not happen for valid permutations


def identify_group(automorphisms: List[Tuple[int, ...]]) -> Dict[str, Any]:
    """Identify the automorphism group structure.

    Computes orders, multiplication table, checks V₄ properties.

    Returns
    -------
    Dict with keys: size, orders, is_abelian, is_V4, group_name,
    multiplication_table_valid.
    """
    n_auts = len(automorphisms)
    n_nodes = len(automorphisms[0])
    identity = tuple(range(n_nodes))

    orders = [_order(p) for p in automorphisms]

    # Multiplication table closure check
    perm_set = set(automorphisms)
    perm_to_idx = {p: i for i, p in enumerate(automorphisms)}
    table_valid = True
    is_abelian = True

    for i, p1 in enumerate(automorphisms):
        for j, p2 in enumerate(automorphisms):
            c12 = _compose(p1, p2)
            c21 = _compose(p2, p1)
            if c12 not in perm_set or c21 not in perm_set:
                table_valid = False
            if c12 != c21:
                is_abelian = False

    is_v4 = (
        n_auts == 4
        and is_abelian
        and table_valid
        and all(o <= 2 for o in orders)
    )

    if n_auts == 1:
        name = "Trivial {e}"
    elif n_auts == 2:
        name = "Z_2"
    elif is_v4:
        name = "V_4 (Klein four-group)"
    elif n_auts == 4 and is_abelian and any(o == 4 for o in orders):
        name = "Z_4"
    else:
        name = f"|Aut|={n_auts}"

    return {
        "size": n_auts,
        "orders": orders,
        "is_abelian": is_abelian,
        "is_V4": is_v4,
        "group_name": name,
        "multiplication_table_valid": table_valid,
    }


# =============================================================================
# 3. BIPARTITION ENUMERATION AND MI COMPUTATION
# =============================================================================

def enumerate_bipartitions(n: int) -> List[Tuple[frozenset, frozenset]]:
    """All non-trivial bipartitions of {0,...,n-1}.

    Canonical form: 0 is always in the first part (avoids duplicates).
    """
    parts = []
    for sz in range(1, n):
        for sub in combinations(range(n), sz):
            M = frozenset(sub)
            C = frozenset(range(n)) - M
            if 0 in M:
                parts.append((M, C))
    return parts


def even_bipartitions(n: int) -> List[Tuple[frozenset, frozenset]]:
    """Even bipartitions: both parts have size n/2 (requires even n)."""
    if n % 2 != 0:
        return []
    return [(M, C) for M, C in enumerate_bipartitions(n) if len(M) == len(C)]


def _solve_lyapunov(A: np.ndarray, noise_scale: float = 0.1,
                    max_iter: int = 2000, tol: float = 1e-14) -> np.ndarray:
    """Solve discrete Lyapunov equation Sigma = A @ Sigma @ A.T + Q."""
    n = A.shape[0]
    Q = np.eye(n) * noise_scale
    S = np.eye(n)
    for _ in range(max_iter):
        S2 = A @ S @ A.T + Q
        if np.max(np.abs(S2 - S)) < tol:
            return S2
        S = S2
    return S


def gaussian_mutual_information(
    Sigma: np.ndarray,
    M: frozenset,
    C: frozenset,
) -> float:
    """Gaussian MI: I(X_M; X_C) = 0.5 * ln(det(Sigma_M) * det(Sigma_C) / det(Sigma)).

    This is the information loss when cutting the system at partition {M, C}.
    """
    M_idx = list(M)
    C_idx = list(C)
    det_M = np.linalg.det(Sigma[np.ix_(M_idx, M_idx)])
    det_C = np.linalg.det(Sigma[np.ix_(C_idx, C_idx)])
    det_full = np.linalg.det(Sigma)
    if det_full <= 0 or det_M <= 0 or det_C <= 0:
        return 0.0
    return max(0.0, 0.5 * math.log(det_M * det_C / det_full))


# =============================================================================
# 4. PARTITION ORBIT ANALYSIS
# =============================================================================

def _apply_perm_to_partition(
    perm: Tuple[int, ...],
    M: frozenset,
    C: frozenset,
) -> Tuple[frozenset, frozenset]:
    """Apply a permutation to a bipartition, return canonical form."""
    M_new = frozenset(perm[i] for i in M)
    C_new = frozenset(perm[i] for i in C)
    return (M_new, C_new) if 0 in M_new else (C_new, M_new)


def partition_orbits(
    automorphisms: List[Tuple[int, ...]],
    bipartitions: List[Tuple[frozenset, frozenset]],
) -> List[List[Tuple[frozenset, frozenset]]]:
    """Compute orbits of bipartitions under the automorphism group action."""
    visited = set()
    orbits = []
    for M, C in bipartitions:
        if (M, C) in visited:
            continue
        orbit = []
        for perm in automorphisms:
            result = _apply_perm_to_partition(perm, M, C)
            if result not in visited:
                visited.add(result)
                orbit.append(result)
        orbits.append(orbit)
    return orbits


# =============================================================================
# 5. THEOREM IA — V₄ STRUCTURE OF BILATERAL NETWORKS
# =============================================================================

@dataclass(frozen=True)
class V4Result:
    """Result of Theorem IA verification for a bilateral network."""
    n_per_side: int
    total_nodes: int
    group_info: Dict[str, Any]
    is_v4: bool
    even_partition_orbits: int
    orbit_sizes: List[int]
    automorphisms: List[Tuple[int, ...]]


def theorem_ia_v4_structure(
    n_per_side: int = 2,
    w_intra: float = 0.3,
    w_cal: float = 0.15,
    w_self: float = 0.1,
) -> V4Result:
    """Theorem IA: Bilateral-redundant networks have Aut(G) = V₄.

    For a weighted graph with two commuting fixed-point-free involutions
    (bilateral symmetry sigma_B and functional redundancy sigma_F) and
    non-degenerate weights (w_cal != w_intra), the automorphism group is
    the Klein four-group V₄ = Z₂ × Z₂.

    The even bipartitions decompose into exactly 3 singleton orbits under
    V₄, in bijection with V₄ \\ {e} via the stabiliser map.

    Parameters
    ----------
    n_per_side : int
        Nodes per hemisphere (default 2 for the minimal V₄ case).
    w_intra, w_cal, w_self : float
        Network weights.  V₄ requires w_cal != w_intra.

    Returns
    -------
    V4Result with group identification and orbit decomposition.
    """
    N = 2 * n_per_side
    A = make_bilateral_network(n_per_side, w_intra, w_cal, w_self)
    auts = compute_automorphisms(A)
    group = identify_group(auts)

    # Orbit analysis on even bipartitions
    evens = even_bipartitions(N)
    orbits = partition_orbits(auts, evens)

    return V4Result(
        n_per_side=n_per_side,
        total_nodes=N,
        group_info=group,
        is_v4=group["is_V4"],
        even_partition_orbits=len(orbits),
        orbit_sizes=sorted(len(o) for o in orbits),
        automorphisms=auts,
    )


# =============================================================================
# 6. THEOREM IB — MI ORDERING
# =============================================================================

@dataclass(frozen=True)
class MIOrderingResult:
    """Result of Theorem IB verification."""
    mi_hemispheric: float   # MI at {L1,L2}|{R1,R2}  (sigma_1 / sigma_F)
    mi_homotopic: float     # MI at {L1,R1}|{L2,R2}  (sigma_2 / sigma_B)
    mi_heterotopic: float   # MI at {L1,R2}|{L2,R1}  (sigma_3 / sigma_FB)
    ordering_holds: bool    # mi_hetero < mi_hemi < mi_homo
    w_self: float
    w_cal: float
    w_intra: float
    condition_met: bool     # w_self < w_cal < w_intra


def theorem_ib_mi_ordering(
    w_intra: float = 0.3,
    w_cal: float = 0.15,
    w_self: float = 0.1,
) -> MIOrderingResult:
    """Theorem IB: MI ordering for bilateral-redundant networks.

    For a 4-node bilateral network with Aut(G) = V₄ and Gaussian dynamics:

        MI(sigma_3) < MI(sigma_1) < MI(sigma_2)

    whenever w_self < w_cal < w_intra (strict inequalities).

    The three even bipartitions and their V₄ correspondences:
        sigma_F  -> {L1,L2}|{R1,R2}  (hemispheric)  : MI(sigma_1)
        sigma_B  -> {L1,R1}|{L2,R2}  (homotopic)    : MI(sigma_2)
        sigma_FB -> {L1,R2}|{L2,R1}  (heterotopic)  : MI(sigma_3)

    The heterotopic partition (the sqrt(15) element) has the LOWEST MI
    in the biological regime — it is the system's most vulnerable
    integration mode.
    """
    A = make_bilateral_network(2, w_intra, w_cal, w_self)
    Sigma = _solve_lyapunov(A)

    # Three even bipartitions for 4 nodes {0=L1, 1=L2, 2=R1, 3=R2}
    p_hemi = (frozenset([0, 1]), frozenset([2, 3]))     # {L1,L2}|{R1,R2}
    p_homo = (frozenset([0, 2]), frozenset([1, 3]))     # {L1,R1}|{L2,R2}
    p_hetero = (frozenset([0, 3]), frozenset([1, 2]))   # {L1,R2}|{L2,R1}

    mi_hemi = gaussian_mutual_information(Sigma, *p_hemi)
    mi_homo = gaussian_mutual_information(Sigma, *p_homo)
    mi_hetero = gaussian_mutual_information(Sigma, *p_hetero)

    condition = w_self < w_cal < w_intra
    ordering = mi_hetero < mi_hemi < mi_homo

    return MIOrderingResult(
        mi_hemispheric=mi_hemi,
        mi_homotopic=mi_homo,
        mi_heterotopic=mi_hetero,
        ordering_holds=ordering,
        w_self=w_self,
        w_cal=w_cal,
        w_intra=w_intra,
        condition_met=condition,
    )


def verify_mi_ordering_sweep(
    n_samples: int = 200,
) -> Dict[str, Any]:
    """Sweep parameter space to verify Theorem IB holds universally.

    Tests the MI ordering MI(sigma_3) < MI(sigma_1) < MI(sigma_2) over
    a grid of (w_self, w_cal, w_intra) satisfying w_self < w_cal < w_intra.

    Also verifies the subsidiary claim:
        MI(sigma_1) > MI(sigma_3) iff w_cal > w_self
    (zero violations expected in any parameter regime with w_cal < w_intra).
    """
    violations_ordering = 0
    violations_claim_b = 0
    tests_ordering = 0
    tests_claim_b = 0

    for w_i in np.arange(0.10, 0.55, 0.05):
        for w_c in np.arange(0.02, w_i - 0.01, 0.02):
            for w_s in [0.05, 0.10, 0.15, 0.20]:
                A = make_bilateral_network(2, float(w_i), float(w_c), float(w_s))
                Sigma = _solve_lyapunov(A)

                mi1 = gaussian_mutual_information(
                    Sigma, frozenset([0, 1]), frozenset([2, 3]))
                mi2 = gaussian_mutual_information(
                    Sigma, frozenset([0, 2]), frozenset([1, 3]))
                mi3 = gaussian_mutual_information(
                    Sigma, frozenset([0, 3]), frozenset([1, 2]))

                # Claim (b): MI(σ₁) > MI(σ₃) iff w_cal > w_self
                tests_claim_b += 1
                if w_c > w_s + 1e-10:
                    if not (mi1 > mi3 + 1e-10):
                        violations_claim_b += 1
                elif w_c < w_s - 1e-10:
                    if not (mi1 < mi3 - 1e-10):
                        violations_claim_b += 1

                # Full ordering: strict three-way condition
                if w_s < w_c < w_i:
                    tests_ordering += 1
                    # Allow equality at boundary w_cal = w_intra
                    if not (mi3 < mi1 - 1e-12 and mi1 < mi2 - 1e-12):
                        violations_ordering += 1

    return {
        "ordering_tests": tests_ordering,
        "ordering_violations": violations_ordering,
        "ordering_holds": violations_ordering == 0,
        "claim_b_tests": tests_claim_b,
        "claim_b_violations": violations_claim_b,
        "claim_b_holds": violations_claim_b == 0,
    }


# =============================================================================
# 7. THEOREM IC — GALOIS CORRESPONDENCE
# =============================================================================

@dataclass(frozen=True)
class GaloisCorrespondenceResult:
    """Result of Theorem IC: the V₄-set isomorphism."""
    # Graph-theoretic V₄ elements (permutations of {0,1,2,3})
    sigma_F: Tuple[int, ...]     # functional swap (L1<->L2, R1<->R2)
    sigma_B: Tuple[int, ...]     # bilateral swap (L1<->R1, L2<->R2)
    sigma_FB: Tuple[int, ...]    # composite (L1<->R2, L2<->R1)
    # Their fixed even bipartitions
    partition_F: str             # hemispheric
    partition_B: str             # homotopic
    partition_FB: str            # heterotopic
    # Algebraic V₄ elements (QBiquad automorphisms)
    algebraic_sigma2_fixes: str  # Q(sqrt5)
    algebraic_sigma3_fixes: str  # Q(sqrt3)
    algebraic_sigma4_fixes: str  # Q(sqrt15)
    # Correspondence verified
    correspondence_verified: bool


def theorem_ic_galois_correspondence() -> GaloisCorrespondenceResult:
    """Theorem IC: The V₄-set isomorphism between graph partitions and subfields.

    The bijection:
        sigma_F  <-> {L1,L2}|{R1,R2} <-> Q(sqrt5)  [sigma_2 fixes Q(sqrt5)]
        sigma_B  <-> {L1,R1}|{L2,R2} <-> Q(sqrt3)  [sigma_3 fixes Q(sqrt3)]
        sigma_FB <-> {L1,R2}|{L2,R1} <-> Q(sqrt15) [sigma_4 fixes Q(sqrt15)]

    is an isomorphism of V₄-sets.

    Verification: check that the algebraic automorphisms have the correct
    fixed-field behaviour using QBiquad from bridge_field.py.
    """
    # Graph-theoretic V₄ elements for {0=L1, 1=L2, 2=R1, 3=R2}
    sigma_F = (1, 0, 3, 2)    # L1<->L2, R1<->R2
    sigma_B = (2, 3, 0, 1)    # L1<->R1, L2<->R2
    sigma_FB = _compose(sigma_F, sigma_B)  # should be (3,2,1,0): L1<->R2, L2<->R1

    # Verify sigma_FB = expected
    assert sigma_FB == (3, 2, 1, 0), f"sigma_FB = {sigma_FB}, expected (3,2,1,0)"

    # Fixed even bipartitions:
    # sigma_F fixes {L1,L2}|{R1,R2} because it maps {0,1}->{1,0} and {2,3}->{3,2}
    # sigma_B fixes {L1,R1}|{L2,R2} because it maps {0,2}->{2,0} and {1,3}->{3,1}
    # sigma_FB fixes {L1,R2}|{L2,R1} because it maps {0,3}->{3,0} and {1,2}->{2,1}

    # Verify algebraic correspondence via QBiquad
    # phi lives in Q(sqrt5): sigma2 should fix it (sigma2 negates sqrt3, fixes sqrt5)
    phi_orbit = PHI_Q.galois_orbit
    sigma2_fixes_phi = abs(phi_orbit[0] - phi_orbit[1]) < 1e-12  # sigma2(phi) = phi

    # sqrt(15) lives in Q(sqrt15): sigma4 should fix it
    s15_orbit = SQRT15_Q.galois_orbit
    sigma4_fixes_s15 = abs(s15_orbit[0] - s15_orbit[3]) < 1e-12  # sigma4(sqrt15) = sqrt15

    # Verify the Galois correspondence:
    # sigma_F (within-hemisphere swap) corresponds to sigma_2 (negates sqrt3)
    #   because: sigma_F preserves the L|R distinction (like sqrt5/phi)
    # sigma_B (bilateral swap) corresponds to sigma_3 (negates sqrt5)
    #   because: sigma_B breaks the L|R distinction but preserves functional roles
    # sigma_FB (diagonal) corresponds to sigma_4 (the bridge automorphism)
    #   because: sigma_FB mixes both contrasts, like sqrt(15) = sqrt(3)*sqrt(5)

    verified = sigma2_fixes_phi and sigma4_fixes_s15

    return GaloisCorrespondenceResult(
        sigma_F=sigma_F,
        sigma_B=sigma_B,
        sigma_FB=sigma_FB,
        partition_F="{L1,L2}|{R1,R2}",
        partition_B="{L1,R1}|{L2,R2}",
        partition_FB="{L1,R2}|{L2,R1}",
        algebraic_sigma2_fixes="Q(sqrt5)",
        algebraic_sigma3_fixes="Q(sqrt3)",
        algebraic_sigma4_fixes="Q(sqrt15)",
        correspondence_verified=verified,
    )


# =============================================================================
# 8. UNIVERSALITY CRITERION
# =============================================================================

def classify_bridge_system(A: np.ndarray) -> Dict[str, Any]:
    """Classify a weighted graph's bridge structure.

    V₄ bridge structure occurs iff the system has EXACTLY two independent
    Z₂ symmetries with distinct coupling strengths.

    Returns classification:
        "V_4"      : exactly two independent involutions
        "Z_2"      : only one involution
        "trivial"  : no non-trivial automorphisms
        "larger"   : group strictly contains V₄
    """
    if A.shape[0] > MAX_NODES:
        raise ValueError(f"N={A.shape[0]} exceeds MAX_NODES={MAX_NODES}")

    auts = compute_automorphisms(A)
    group = identify_group(auts)

    if group["is_V4"]:
        bridge_type = "V_4"
    elif group["size"] == 1:
        bridge_type = "trivial"
    elif group["size"] == 2:
        bridge_type = "Z_2"
    else:
        # Check if V₄ is a subgroup
        n = A.shape[0]
        identity = tuple(range(n))
        involutions = [p for p in auts if p != identity and _order(p) == 2]
        has_v4_subgroup = False
        for i, p1 in enumerate(involutions):
            for p2 in involutions[i + 1:]:
                if _compose(p1, p2) == _compose(p2, p1):
                    p3 = _compose(p1, p2)
                    if p3 in set(auts) and _order(p3) == 2:
                        has_v4_subgroup = True
                        break
            if has_v4_subgroup:
                break
        bridge_type = "larger_contains_V4" if has_v4_subgroup else "larger_no_V4"

    return {
        "group": group,
        "bridge_type": bridge_type,
        "is_bridge_system": group["is_V4"],
    }


# =============================================================================
# 9. COMPREHENSIVE ANALYSIS
# =============================================================================

def run_full_analysis(
    w_intra: float = 0.3,
    w_cal: float = 0.15,
    w_self: float = 0.1,
) -> Dict[str, Any]:
    """Run the complete bridge integration analysis.

    Executes Theorems IA, IB, IC and returns all results.
    """
    ia = theorem_ia_v4_structure(2, w_intra, w_cal, w_self)
    ib = theorem_ib_mi_ordering(w_intra, w_cal, w_self)
    ic = theorem_ic_galois_correspondence()

    return {
        "theorem_ia": {
            "is_v4": ia.is_v4,
            "group_name": ia.group_info["group_name"],
            "even_partition_orbits": ia.even_partition_orbits,
            "orbit_sizes": ia.orbit_sizes,
        },
        "theorem_ib": {
            "mi_hemispheric": ib.mi_hemispheric,
            "mi_homotopic": ib.mi_homotopic,
            "mi_heterotopic": ib.mi_heterotopic,
            "ordering_holds": ib.ordering_holds,
            "condition_met": ib.condition_met,
        },
        "theorem_ic": {
            "correspondence_verified": ic.correspondence_verified,
            "sigma_FB": ic.sigma_FB,
        },
        "all_pass": ia.is_v4 and ib.ordering_holds and ic.correspondence_verified,
    }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Network construction
    "make_bilateral_network",
    "MAX_NODES",
    # Group computation
    "compute_automorphisms",
    "identify_group",
    # Bipartition and MI
    "enumerate_bipartitions",
    "even_bipartitions",
    "gaussian_mutual_information",
    "partition_orbits",
    # Theorem results
    "V4Result",
    "MIOrderingResult",
    "GaloisCorrespondenceResult",
    # Theorem functions
    "theorem_ia_v4_structure",
    "theorem_ib_mi_ordering",
    "theorem_ic_galois_correspondence",
    "verify_mi_ordering_sweep",
    # Classification
    "classify_bridge_system",
    # Full analysis
    "run_full_analysis",
]
