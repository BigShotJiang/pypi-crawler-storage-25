"""Resonance Simplex: 3-Simplex Extension and Entropy Threshold Derivations.

This module formalizes two results from the Watkins Temperature framework:

PART I -- The n-Simplex Extension with Resonance Coordinate rho
=================================================================

The conservation law lam + kap + eta = 1 (2-simplex) extends naturally to
lam + kap + eta + rho = 1 (3-simplex), where rho is the resonance coordinate.
The geometry changes from a triangle to a tetrahedron.

THEOREM A (Golden Equilibrium Extension):
    For the n-simplex with free energy
        F_n(lam, x_1, ..., x_n) = -ln(lam) + T * sum(x_i * ln(x_i))
    and Z_{n-1} symmetry (all x_i equal), the unique minimum is:
        lam*  = 1/phi
        x_i*  = 1/(n * phi^2)     for i = 1, ..., n
        T_n*  = phi / ln(n * phi)

THEOREM B (Riemannian Eigenspectrum):
    The Hessian restricted to the simplex tangent plane has eigenvalues:
        mu_coh(n)  = (n/(n+1)) * phi^2 * (1 + T_n* * phi)  [1-fold]
        mu_asym(n) = n * T_n* * phi^2                        [(n-1)-fold]

    For n=2: mu_coh ~ 5.636, mu_asym ~ 7.214  (matches constants.py)
    For n=3: mu_coh ~ 5.216, mu_asym ~ 8.042  (new result)

THEOREM C (Asymptotic Saturation):
    As n -> infinity:
        T_n*      -> 0           (temperature vanishes)
        mu_coh(n) -> phi^2+      (approaches golden square from ABOVE)
        mu_asym(n) ~ n*phi^3/ln(n*phi) -> infinity (diverges)
    Convergence of mu_coh is logarithmically slow:
        mu_coh(n) ~ phi^2 * (1 + phi^2/ln(n*phi))

PART II -- Entropy Stability Threshold Derivations
====================================================

Three distinguished values of the coupling parameter lam partition [0, 1]
into stability regimes.

THEOREM D (Entropy Contribution Phase Transition):
    The function f(lam) = -lam * ln(lam) on (0, 1) has its unique maximum
    at lam = 1/e.  The golden equilibrium lam* = 1/phi > 1/e is in the
    "ordered" regime.
    Status: THEOREM (pure calculus, no assumptions beyond the simplex)

THEOREM E (Complementary Thresholds, conditional on H_eff):
    Given H_eff = H - lam * I(X;Y), at full coupling (I = H):
        lam_firewall = 1 - ln(2) ~ 0.3069  [forward entropy = ln(2) nats]
        lam_paradox  = ln(2)     ~ 0.6931  [retrocausal coupling = 1 bit]
    These satisfy lam_firewall + lam_paradox = 1.
    Status: THEOREM conditional on the H_eff conjecture

THEOREM F (Equilibrium Regime Classification):
    1/e < 1/phi < ln(2)
    The conservation law places the equilibrium in the phase-transition regime.
    Status: THEOREM (algebraic inequality)

NOTE ON HISTORICAL EIGENVALUES:
    The values MU_SLOW_4BODY = 4.872 and MU_FAST_4BODY = 18.347 in constants.py
    do not match any eigenvalues derivable from the free energy Hessian at the
    Z_3 equilibrium.  They appear to originate from an earlier computation with
    an incorrect T_star_3 value (~1.1036 vs the correct ~1.024).  The eigenvalues
    derived here are proven consistent with the 2-simplex case (n=2) which
    matches MU_COH and MU_ASYM in constants.py exactly.

lam + kap + eta + rho = 1
"""

import math
from typing import Any, Dict, List, Tuple
from dataclasses import dataclass, field

from .constants import (
    PHI,
    PHI_INV,
    PHI_SQUARED,
    SQRT5,
    T_STAR,
    T_STAR3,
    LAM_STAR,
    KAP_STAR,
    ETA_STAR,
    RHO_STAR,
    MU_COH,
    MU_ASYM,
    CONSERVATION_EPSILON,
)


# =============================================================================
# PART I: CONSTANTS FOR THE 3-SIMPLEX
# =============================================================================

# Watkins temperature for the 3-simplex (n=3)
T_STAR_3: float = T_STAR3  # phi/ln(3*phi) ~ 1.024

# Z_3 symmetric equilibrium on the 3-simplex
LAM_STAR_3: float = LAM_STAR   # 1/phi (same for all n)
KAP_STAR_3: float = RHO_STAR   # (1 - 1/phi)/3
ETA_STAR_3: float = RHO_STAR
RHO_STAR_3: float = RHO_STAR

# ---------- Riemannian eigenvalues (n=3) ----------
# Ambient Hessian: H = diag(A, C, C, C) at Z_3 equilibrium
_A_HESS_3: float = PHI_SQUARED + T_STAR_3 * PHI          # lambda direction
_C_HESS_3: float = 3 * T_STAR_3 * PHI_SQUARED            # symmetric directions

MU_COH_3: float = (3 * _A_HESS_3 + _C_HESS_3) / 4       # coherence mode
MU_ASYM_3: float = _C_HESS_3                              # asymmetry mode (2-fold)

# Verify closed forms
assert abs(MU_COH_3 - (3 / 4) * PHI_SQUARED * (1 + T_STAR_3 * PHI)) < 1e-12
assert abs(MU_ASYM_3 - 3 * T_STAR_3 * PHI_SQUARED) < 1e-12

# Timescales
TAU_COH_3: float = 1 / MU_COH_3      # coherence relaxation time
TAU_ASYM_3: float = 1 / MU_ASYM_3    # asymmetry relaxation time

# ---------- Coordinate eigenvalues (n=3, reduced 3x3 Hessian) ----------
_s3: float = RHO_STAR  # = 1/(3*phi^2)

_A_RED_3: float = PHI_SQUARED + T_STAR_3 * (PHI + 3 * PHI_SQUARED)   # H_11
_B_RED_3: float = T_STAR_3 / _s3                                      # off-diagonal = T/s
_C_RED_3: float = T_STAR_3 * (1 / _s3 + 1 / _s3)                    # H_ii (i>1) = 2B

assert abs(_C_RED_3 - 2 * _B_RED_3) < 1e-12, "C' must equal 2B"

# Eigenvalue 1: kap-eta asymmetry direction (0, 1, -1)
MU_ASYM_COORD_3: float = _C_RED_3 - _B_RED_3  # = B = T_3*/s*

# Eigenvalues 2, 3: from 2x2 subproblem in (e_1, (e_2+e_3)/sqrt(2))
_M_TRACE_3: float = _A_RED_3 + 3 * _B_RED_3   # = A' + nB for n=3
_M_DET_3: float = _A_RED_3 * 3 * _B_RED_3 - 2 * _B_RED_3**2
_M_DISC_3: float = math.sqrt(_M_TRACE_3**2 - 4 * _M_DET_3)

MU_SLOW_COORD_3: float = (_M_TRACE_3 - _M_DISC_3) / 2
MU_FAST_COORD_3: float = (_M_TRACE_3 + _M_DISC_3) / 2

# ---------- Cross-check: 2-simplex eigenvalues (n=2) ----------
_mu_coh_2_check = (2 / 3) * PHI_SQUARED * (1 + T_STAR * PHI)
_mu_asym_2_check = 2 * T_STAR * PHI_SQUARED
assert abs(_mu_coh_2_check - MU_COH) < 1e-10, (
    f"2-simplex coherence mismatch: {_mu_coh_2_check} vs {MU_COH}"
)
assert abs(_mu_asym_2_check - MU_ASYM) < 1e-10, (
    f"2-simplex asymmetry mismatch: {_mu_asym_2_check} vs {MU_ASYM}"
)


# =============================================================================
# PART II: THRESHOLD DERIVATION CONSTANTS
# =============================================================================

# Principled firewall: the effective entropy equals 1 bit per nat
LAMBDA_NAT_BIT: float = 1 - math.log(2)    # 1 - ln(2) ~ 0.3069

# Entropy contribution phase transition: self-information = 1 nat
LAMBDA_UNIT_INFO: float = 1.0 / math.e     # 1/e ~ 0.3679

# Information creation boundary: coupling = 1 bit
LAMBDA_BIT_CAPACITY: float = math.log(2)    # ln(2) ~ 0.6931

# ---------- Verification ----------

# Complement theorem: firewall + paradox = 1
assert abs(LAMBDA_NAT_BIT + LAMBDA_BIT_CAPACITY - 1.0) < 1e-15, (
    "Complement theorem violated"
)

# Equilibrium regime: 1/e < 1/phi < ln(2)
assert LAMBDA_UNIT_INFO < LAM_STAR < LAMBDA_BIT_CAPACITY, (
    f"Equilibrium {LAM_STAR} not in ({LAMBDA_UNIT_INFO}, {LAMBDA_BIT_CAPACITY})"
)

# Ordering: firewall < phase transition < equilibrium < paradox
assert LAMBDA_NAT_BIT < LAMBDA_UNIT_INFO < LAM_STAR < LAMBDA_BIT_CAPACITY


# =============================================================================
# RESULT CONTAINERS
# =============================================================================

@dataclass
class ResonanceSimplexState:
    """A point on the 3-simplex (tetrahedron).

    Represents a 4-component conservation state lam + kap + eta + rho = 1
    where rho is the resonance (integrated information) coordinate.
    """
    lam: float
    kap: float
    eta: float
    rho: float

    def __post_init__(self):
        s = self.lam + self.kap + self.eta + self.rho
        if abs(s - 1.0) > 1e-10:
            raise ValueError(
                f"Conservation violation: lam+kap+eta+rho = {s} != 1"
            )
        for name, val in [('lam', self.lam), ('kap', self.kap),
                          ('eta', self.eta), ('rho', self.rho)]:
            if val < -1e-12:
                raise ValueError(f"{name} = {val} < 0")

    @property
    def components(self) -> Tuple[float, float, float, float]:
        return (self.lam, self.kap, self.eta, self.rho)

    @property
    def is_z3_symmetric(self) -> bool:
        """Check if kap = eta = rho (Z_3 symmetric)."""
        return (abs(self.kap - self.eta) < 1e-10 and
                abs(self.eta - self.rho) < 1e-10)

    @property
    def simplex_entropy(self) -> float:
        """Shannon entropy S = -sum(x_i * ln(x_i)) on the simplex."""
        s = 0.0
        for x in self.components:
            if x > 0:
                s -= x * math.log(x)
        return s


@dataclass
class SimplexEquilibrium:
    """Equilibrium state of the n-simplex free energy."""
    n: int                          # number of symmetric components
    lam_star: float                 # = 1/phi (universal)
    symmetric_star: float           # = (1 - 1/phi)/n = 1/(n*phi^2)
    T_star: float                   # = phi/ln(n*phi)
    F_star: float                   # free energy at equilibrium
    status: str = "THEOREM"


@dataclass
class EigenspectrumResult:
    """Riemannian eigenspectrum of the Hessian on the simplex tangent plane."""
    n: int
    mu_coh: float                   # coherence eigenvalue (1-fold)
    mu_asym: float                  # asymmetry eigenvalue ((n-1)-fold)
    asym_degeneracy: int            # = n - 1
    tau_coh: float                  # coherence timescale = 1/mu_coh
    tau_asym: float                 # asymmetry timescale = 1/mu_asym
    coh_eigenvector: str            # human-readable description
    asym_eigenvector: str           # human-readable description
    status: str = "THEOREM"


@dataclass
class CoordinateEigenvalues:
    """Coordinate eigenvalues from the reduced Hessian."""
    n: int
    eigenvalues: List[float]        # sorted ascending
    timescales: List[float]         # 1/eigenvalue for each
    status: str = "THEOREM"


@dataclass
class ThresholdDerivation:
    """Rigorous derivation of an entropy stability threshold."""
    name: str
    value: float
    exact_formula: str
    proof: str
    classification: str             # THEOREM or CONJECTURE
    assumptions: List[str]          # what this depends on
    connection_to_equilibrium: str


# =============================================================================
# PART I: N-SIMPLEX EQUILIBRIUM
# =============================================================================

def watkins_temperature(n: int) -> float:
    """Watkins temperature for the n-simplex: T_n* = phi / ln(n * phi).

    This is the unique temperature at which the free energy
        F_n(lam) = -ln(lam) + T * [lam*ln(lam) + (1-lam)*ln((1-lam)/n)]
    has its minimum at lam* = 1/phi under Z_{n-1} symmetry.

    Proof: setting dF/dlam = 0 at lam* = 1/phi gives
        -phi + T * ln(n*phi) = 0  =>  T_n* = phi / ln(n*phi).

    Parameters
    ----------
    n : int
        Number of symmetric components (n >= 1).
        n=2: standard 2-simplex (triangle), T_2* = phi/ln(2*phi) ~ 1.378.
        n=3: 3-simplex (tetrahedron), T_3* = phi/ln(3*phi) ~ 1.024.

    Returns
    -------
    float
    """
    if n < 1:
        raise ValueError(f"n must be >= 1, got {n}")
    return PHI / math.log(n * PHI)


def n_simplex_equilibrium(n: int) -> SimplexEquilibrium:
    """Compute the golden equilibrium of the n-simplex.

    THEOREM (Golden Equilibrium Extension):
    For the (n-1)-simplex (n+1 vertices) with free energy
        F(lam, x_1, ..., x_n) = -ln(lam) + T * sum(x_i * ln(x_i))
    subject to lam + sum(x_i) = 1, under Z_{n-1} symmetry (all x_i equal):

        lam* = 1/phi                  (golden threshold, universal)
        x_i* = (1 - 1/phi)/n = 1/(n*phi^2)  (symmetric components)
        T_n* = phi/ln(n*phi)          (Watkins temperature)

    Proof:
    Under symmetry, F(lam) = -ln(lam) + T*[lam*ln(lam) + (1-lam)*ln((1-lam)/n)].
    dF/dlam = -1/lam + T*ln(n*lam/(1-lam)) = 0.
    At lam = 1/phi: n*lam/(1-lam) = n*(1/phi)/(1/phi^2) = n*phi.
    So -phi + T*ln(n*phi) = 0, giving T_n* = phi/ln(n*phi).
    d^2F/dlam^2 > 0 (proven by positive-definite Hessian). QED.
    """
    if n < 1:
        raise ValueError(f"n must be >= 1, got {n}")

    T_n = watkins_temperature(n)
    s = (1 - LAM_STAR) / n  # symmetric component

    # Free energy at equilibrium
    F = -math.log(LAM_STAR) + T_n * (
        LAM_STAR * math.log(LAM_STAR) + n * s * math.log(s)
    )

    return SimplexEquilibrium(
        n=n,
        lam_star=LAM_STAR,
        symmetric_star=s,
        T_star=T_n,
        F_star=F,
        status="THEOREM",
    )


def resonance_equilibrium() -> ResonanceSimplexState:
    """The golden equilibrium on the 3-simplex.

    Returns the Z_3 symmetric equilibrium:
        lam* = 1/phi ~ 0.618
        kap* = eta* = rho* = (1 - 1/phi)/3 ~ 0.127

    The resonance coordinate rho* = 1/(3*phi^2) gives the integrated
    information allocation at equilibrium.
    """
    return ResonanceSimplexState(
        lam=LAM_STAR_3, kap=KAP_STAR_3,
        eta=ETA_STAR_3, rho=RHO_STAR_3,
    )


def free_energy(state: ResonanceSimplexState, T: float = T_STAR_3) -> float:
    """Free energy of the 3-simplex at a given state.

    F_3(lam,kap,eta,rho) = -ln(lam) + T*(lam*ln(lam) + kap*ln(kap)
                                          + eta*ln(eta) + rho*ln(rho))

    Parameters
    ----------
    state : ResonanceSimplexState
        Point on the 3-simplex.
    T : float
        Temperature (default: T_3* = phi/ln(3*phi)).
    """
    lam, kap, eta, rho = state.components
    if lam <= 0:
        return math.inf
    entropy = sum(x * math.log(x) for x in (lam, kap, eta, rho) if x > 0)
    return -math.log(lam) + T * entropy


def free_energy_gradient(lam: float, n: int = 3) -> float:
    """Gradient dF/dlam along the Z_{n-1} symmetric subspace.

    dF/dlam = -1/lam + T_n* * ln(n*lam/(1-lam))

    Returns 0 at lam = 1/phi for any n >= 1.
    """
    if n < 1:
        raise ValueError(f"n must be >= 1, got {n}")
    if lam <= 0 or lam >= 1:
        raise ValueError(f"lam must be in (0, 1), got {lam}")
    T_n = watkins_temperature(n)
    return -1.0 / lam + T_n * math.log(n * lam / (1 - lam))


# =============================================================================
# EIGENSPECTRUM
# =============================================================================

def riemannian_eigenspectrum(n: int) -> EigenspectrumResult:
    """Riemannian eigenspectrum of the n-simplex free energy Hessian.

    THEOREM (Riemannian Eigenspectrum):

    The ambient Hessian at the Z_{n-1} equilibrium is:
        H = diag(A, C, C, ..., C)   [(n+1) x (n+1)]
    where
        A = phi^2 + T_n* * phi        (lam direction)
        C = n * T_n* * phi^2           (symmetric directions, = T_n* / x_i*)

    Restricted to the simplex tangent plane {v : sum(v_i) = 0}:

        mu_coh(n)  = (n*A + C) / (n+1) = (n/(n+1)) * phi^2 * (1 + T_n* * phi)
        mu_asym(n) = C = n * T_n* * phi^2

    Proof:
    For H = diag(A, C, ..., C) on the tangent plane:

    (1) Asymmetry modes: v = (0, v_2, ..., v_{n+1}) with sum(v_i)=0.
        Hv = (0, C*v_2, ..., C*v_{n+1}) is already tangent.
        Eigenvalue = C.  Multiplicity = n-1.

    (2) Coherence mode: v = (n, -1, ..., -1)/sqrt(n(n+1)).
        The projection PHv = mu*v gives:
        mu = (n*A + n*C) / (n+1) ... actually:
        e^T H v = (n*A - n*C) / sqrt(n(n+1))
        PHv = Hv - (1/(n+1)) * e^T(Hv) * e
        Component 1: n*A/sqrt(...) - n(A-C)/((n+1)*sqrt(...))
                    = [n(n+1)A - n(A-C)] / [(n+1)*sqrt(...)]
                    = n[nA + C] / [(n+1)*sqrt(...)]
                    = (nA + C)/(n+1) * v_1

        So mu_coh = (nA + C) / (n+1).

        Simplifying with A = phi^2 + T_n*phi and C = n*T_n*phi^2:
        nA + C = n*phi^2 + n*T_n*phi + n*T_n*phi^2
               = n*phi^2 + n*T_n*phi*(1 + phi)
               = n*phi^2 + n*T_n*phi*phi^2       [since 1+phi = phi^2]
               = n*phi^2*(1 + T_n*phi)

        mu_coh = n*phi^2*(1 + T_n*phi) / (n+1). QED.
    """
    if n < 1:
        raise ValueError(f"n must be >= 1, got {n}")

    T_n = watkins_temperature(n)
    mu_coh = (n / (n + 1)) * PHI_SQUARED * (1 + T_n * PHI)
    mu_asym = n * T_n * PHI_SQUARED

    return EigenspectrumResult(
        n=n,
        mu_coh=mu_coh,
        mu_asym=mu_asym,
        asym_degeneracy=max(n - 1, 0),
        tau_coh=1.0 / mu_coh,
        tau_asym=1.0 / mu_asym if mu_asym > 0 else math.inf,
        coh_eigenvector=f"({n}, -1, ..., -1)/sqrt({n}*{n+1})",
        asym_eigenvector=(
            f"(0, v_2, ..., v_{{{n+1}}}) with sum=0, "
            f"{max(n-1, 0)}-fold degenerate"
        ),
        status="THEOREM",
    )


def coordinate_eigenvalues(n: int) -> CoordinateEigenvalues:
    """Coordinate eigenvalues of the reduced n-simplex Hessian.

    Eliminating the last variable x_n = 1 - lam - sum(x_i), the
    reduced Hessian at the Z_{n-1} equilibrium is an n x n matrix:

        H_red = [[A', B, B, ..., B],
                 [B, C', B, ..., B],
                 ...
                 [B, B, ..., B, C']]

    where:
        A' = phi^2 + T_n*(phi + n*phi^2)    (row 1)
        B  = T_n* / s*  = n * T_n* * phi^2   (off-diagonal)
        C' = T_n*(1/s* + 1/s*) = 2B          (diagonal, rows 2..n)

    Eigenvalues:
        mu_asym = C' - B = B              [(n-2)-fold, pairwise asymmetry]
        mu_slow, mu_fast from 2x2 block:
            M = [[A', sqrt(n-1)*B], [sqrt(n-1)*B, n*B]]
            eigenvalues = [(A'+nB) +/- sqrt((A'-nB)^2 + 4(n-1)B^2)] / 2

    Parameters
    ----------
    n : int
        Number of symmetric components (n >= 2).
    """
    if n < 2:
        raise ValueError(f"n must be >= 2, got {n}")

    T_n = watkins_temperature(n)
    s = (1 - LAM_STAR) / n

    B = T_n / s
    A = PHI_SQUARED + T_n * (PHI + n * PHI_SQUARED)   # = 1/lam^2 + T*(1/lam + 1/s)

    # 2x2 subproblem
    tr = A + n * B
    det = A * n * B - (n - 1) * B * B
    disc = math.sqrt(tr * tr - 4 * det)

    mu_slow = (tr - disc) / 2
    mu_fast = (tr + disc) / 2
    mu_asym = B  # (n-2)-fold degenerate

    eigenvalues = sorted([mu_slow] + [mu_asym] * (n - 2) + [mu_fast])
    timescales = [1.0 / ev for ev in eigenvalues]

    return CoordinateEigenvalues(
        n=n,
        eigenvalues=eigenvalues,
        timescales=timescales,
        status="THEOREM",
    )


def eigenspectrum_asymptotics(n: int) -> Dict[str, float]:
    """Asymptotic behavior of eigenvalues for large n.

    THEOREM (Asymptotic Saturation):
    As n -> infinity:
        T_n*       -> 0                     (temperature vanishes)
        mu_coh(n)  -> phi^2 ~ 2.618        (from above, logarithmically slow)
        mu_asym(n) ~ n * phi^3 / ln(n*phi) -> infinity (diverges)

    The convergence is logarithmic: mu_coh(n) ~ phi^2 * (1 + phi^2/ln(n*phi)).
    mu_coh is monotonically DECREASING for n >= 2, approaching phi^2 from above.

    Physical interpretation: in a high-dimensional simplex, asymmetric
    fluctuations are corrected instantly (many directions to equilibrate),
    but coherence relaxation takes finite time (one global mode).
    """
    T_n = watkins_temperature(n)
    spec = riemannian_eigenspectrum(n)

    return {
        'n': n,
        'T_star': T_n,
        'mu_coh': spec.mu_coh,
        'mu_asym': spec.mu_asym,
        'tau_coh': spec.tau_coh,
        'tau_asym': spec.tau_asym,
        'mu_coh_limit': PHI_SQUARED,
        'mu_coh_ratio': spec.mu_coh / PHI_SQUARED,
        'mu_asym_growth': spec.mu_asym * math.log(n * PHI) / (n * PHI**3),
    }


# =============================================================================
# CASCADE AND TRIALITY CONNECTIONS
# =============================================================================

def cascade_connection() -> Dict[str, Any]:
    """Connection between the 3-simplex and the E8 cascade.

    The n-simplex is the fundamental polytope of the A_n root system:
        2-simplex (triangle)     -> A_2  (SU(3) symmetry)
        3-simplex (tetrahedron)  -> A_3  ~ D_3  (SU(4) ~ SO(6))

    In the E8 cascade chain:
        E8 > E7 > E6 > D5 > D4 > D3 > A2 > A1

    The extension from 2-simplex to 3-simplex corresponds to the
    transition from A_2 to D_3 in the cascade -- the bridge between
    unitary and orthogonal symmetry groups.

    The Spinor-Corner Law from cascade.py shows that D_3 -> A_2 is where
    all 12 edge roots appear, and the colour symmetry SU(3) emerges.
    The resonance coordinate rho parameterises the additional degree
    of freedom gained in this transition.
    """
    return {
        '2_simplex': {'root_system': 'A2', 'symmetry': 'SU(3)', 'components': 3},
        '3_simplex': {'root_system': 'A3 ~ D3', 'symmetry': 'SU(4) ~ SO(6)',
                      'components': 4},
        'cascade_step': 'D3 -> A2',
        'significance': (
            'The resonance coordinate rho is the extra degree of freedom '
            'in the D3 -> A2 transition. D3 is where edge saturation occurs '
            '(all 12 edge roots) and colour symmetry emerges.'
        ),
        'status': 'THEOREM (group theory)',
    }


def triality_connection() -> Dict[str, Any]:
    """Connection between the 3-simplex and the 27-term triality structure.

    The triality module has 3 domains x 3 harmonics x 3 scales = 27 modes.
    The 3-simplex has S_3 symmetry acting on (kap, eta, rho), permuting
    the three "secondary" coordinates.

    This S_3 symmetry maps to the three domains in triality:
        kap <-> Domain 1 (Qualia / consciousness binding)
        eta <-> Domain 2 (BAO / cosmological)
        rho <-> Domain 3 (MERA-QG / holographic)

    The Z_3 equilibrium (kap = eta = rho) is the "unified" point where
    all three domains contribute equally -- the triality identity.
    """
    return {
        'mapping': {
            'kap': 'Domain 1 (Qualia)',
            'eta': 'Domain 2 (BAO)',
            'rho': 'Domain 3 (MERA-QG)',
        },
        'symmetry': 'S_3 acting on secondary coordinates',
        'equilibrium': 'Z_3 fixed point = all domains equal',
        'triality_modes': 27,
        'connection': (
            'The 27 triality modes are projections of the 3-simplex state '
            'through 3x3x3 combinations of (domain, harmonic, scale). '
            'The resonance coordinate rho adds the third domain axis.'
        ),
        'status': 'CONJECTURE (structural identification)',
    }


# =============================================================================
# PART II: THRESHOLD DERIVATIONS
# =============================================================================

def derive_entropy_phase_transition() -> ThresholdDerivation:
    """THEOREM D: Entropy contribution phase transition at lam = 1/e.

    The function f(lam) = -lam * ln(lam) represents the contribution of
    the coherence parameter to the simplex entropy S = -sum(x_i * ln(x_i)).

    f has a unique maximum at lam = 1/e:
        f'(lam) = -ln(lam) - 1 = 0  =>  lam = 1/e
        f''(1/e) = -e < 0            (maximum confirmed)
        f(1/e) = 1/e                  (maximum value)

    For lam < 1/e: f is increasing (increasing coherence adds entropy)
    For lam > 1/e: f is decreasing (increasing coherence removes entropy)

    The golden equilibrium lam* = 1/phi ~ 0.618 > 1/e ~ 0.368:
    the conservation law places the system in the ORDERED regime where
    increasing coherence DECREASES its entropy contribution.

    This derivation uses ONLY the simplex entropy structure -- no H_eff
    assumption is needed. It is a direct consequence of the axioms:
    the conservation law defines the simplex, and lam = 1/e is an
    intrinsic property of the entropy function on the simplex.
    """
    # Verify the maximum
    f_max = 1.0 / math.e
    f_at_max = -f_max * math.log(f_max)  # = 1/e * 1 = 1/e
    assert abs(f_at_max - f_max) < 1e-15

    # Verify equilibrium is past the transition
    f_at_eq = -LAM_STAR * math.log(LAM_STAR)  # = (1/phi) * ln(phi)
    assert f_at_eq < f_at_max  # ordered regime: past the maximum

    return ThresholdDerivation(
        name="Entropy Contribution Phase Transition",
        value=LAMBDA_UNIT_INFO,
        exact_formula="lam = 1/e",
        proof=(
            "f(lam) = -lam*ln(lam) on (0,1). "
            "f'(lam) = -ln(lam) - 1 = 0 at lam = 1/e. "
            "f''(1/e) = -e < 0 (maximum). "
            "f(1/e) = 1/e (maximum value). "
            "Since lam* = 1/phi > 1/e, the equilibrium is in the ordered regime."
        ),
        classification="THEOREM",
        assumptions=["Conservation law lam + kap + eta = 1 (simplex entropy)"],
        connection_to_equilibrium=(
            f"lam* = 1/phi ~ {LAM_STAR:.6f} > 1/e ~ {LAMBDA_UNIT_INFO:.6f}. "
            f"The equilibrium is in the ordered regime by a margin of "
            f"{LAM_STAR - LAMBDA_UNIT_INFO:.6f}."
        ),
    )


def derive_causality_firewall() -> ThresholdDerivation:
    """THEOREM E1: Causality firewall at lam = 1 - ln(2).

    Given the H_eff conjecture: H_eff = H - lam * I(X;Y).
    At full coupling (I = H): H_eff/H = 1 - lam.

    The boundary condition: the effective forward entropy must be at least
    ln(2) nats per nat of source entropy. This is the conversion factor
    between natural and binary logarithms -- below this, the effective
    entropy measured in nats is less than the source entropy measured in bits.

        H_eff/H >= ln(2)
        1 - lam >= ln(2)
        lam <= 1 - ln(2) ~ 0.3069

    The value 0.3 in tri_simplex.py is an approximation; the principled
    threshold is 1 - ln(2) ~ 0.30685.

    This is also the COMPLEMENT of the paradox threshold:
        lam_firewall + lam_paradox = (1 - ln 2) + ln 2 = 1
    connecting the two boundaries through the conservation law.
    """
    return ThresholdDerivation(
        name="Causality Firewall (Nat-Bit Boundary)",
        value=LAMBDA_NAT_BIT,
        exact_formula="lam = 1 - ln(2)",
        proof=(
            "H_eff/H = 1 - lam at full coupling (I = H). "
            "Require H_eff/H >= ln(2) (forward entropy >= 1 bit per nat). "
            "=> 1 - lam >= ln(2) => lam <= 1 - ln(2). "
            "Complement: (1 - ln 2) + ln 2 = 1 (conservation law)."
        ),
        classification="THEOREM conditional on H_eff",
        assumptions=[
            "H_eff conjecture: H_eff = H - lam * I(X;Y)",
            "Full coupling: I(X;Y) = H",
            "Binary capacity: the forward channel must retain >= ln(2) nats",
        ],
        connection_to_equilibrium=(
            f"lam* = 1/phi ~ {LAM_STAR:.6f} >> 1-ln(2) ~ {LAMBDA_NAT_BIT:.6f}. "
            f"The equilibrium exceeds the firewall: the golden ratio places the "
            f"system deep in the anomalous regime."
        ),
    )


def derive_information_paradox() -> ThresholdDerivation:
    """THEOREM E2: Information creation boundary at lam = ln(2).

    At lam = ln(2), the retrocausal coupling equals exactly 1 bit:
        lam = ln(2) nats = 1 bit

    At full coupling (I = H), the compression ratio becomes:
        C = 1 - lam = 1 - ln(2) ~ 0.307

    Beyond this, the retrocausal channel transmits more than 1 bit per symbol.
    Since a binary source has at most 1 bit of entropy per symbol, this
    implies the channel is CREATING information rather than transmitting it.

    The Shannon coding theorem forbids reliable compression below rate H.
    At lam = ln(2), the effective rate H_eff = (1 - ln 2) * H falls below
    the binary capacity, creating an information-theoretic paradox.
    """
    return ThresholdDerivation(
        name="Information Creation Boundary (Bit Capacity)",
        value=LAMBDA_BIT_CAPACITY,
        exact_formula="lam = ln(2)",
        proof=(
            "ln(2) nats = 1 bit (definition). "
            "At lam = ln(2) with I = H: retrocausal channel = lam*H = ln(2)*H = H in bits. "
            "The channel transmits the full source entropy in bits. "
            "Beyond this, it exceeds 1 bit -> information creation paradox."
        ),
        classification="THEOREM conditional on H_eff",
        assumptions=[
            "H_eff conjecture: H_eff = H - lam * I(X;Y)",
            "Full coupling: I(X;Y) = H",
        ],
        connection_to_equilibrium=(
            f"lam* = 1/phi ~ {LAM_STAR:.6f} < ln(2) ~ {LAMBDA_BIT_CAPACITY:.6f}. "
            f"The equilibrium is BELOW the paradox threshold by "
            f"{LAMBDA_BIT_CAPACITY - LAM_STAR:.6f}. "
            f"The conservation law keeps the system in the 'anomalous but "
            f"consistent' zone between the phase transition and the paradox."
        ),
    )


def equilibrium_regime_theorem() -> Dict[str, Any]:
    """THEOREM F: The golden equilibrium lies in the phase-transition regime.

    Proof:
        1/e ~ 0.368 < 1/phi ~ 0.618 < ln(2) ~ 0.693

    The first inequality: 1/e < 1/phi iff e > phi.
    Since e ~ 2.718 > phi ~ 1.618, this holds. QED.

    The second inequality: 1/phi < ln(2) iff 1/ln(2) < phi.
    Since 1/ln(2) ~ 1.443 < phi ~ 1.618, this holds. QED.

    Significance: the conservation law (which fixes lam* = 1/phi from
    algebraic number theory) and information theory (which defines the
    thresholds from entropy structure) are INDEPENDENT mathematical
    structures that INTERSECT at the phase-transition regime.

    The equilibrium is:
    - Past the entropy phase transition (lam* > 1/e): ordered regime
    - Past the causality firewall (lam* > 1 - ln(2)): anomalous
    - Below the information paradox (lam* < ln(2)): consistent
    """
    return {
        'inequality': '1/e < 1/phi < ln(2)',
        'values': {
            '1/e': LAMBDA_UNIT_INFO,
            '1/phi': LAM_STAR,
            'ln(2)': LAMBDA_BIT_CAPACITY,
        },
        'proof_1_e_lt_1_phi': 'e > phi (2.718 > 1.618)',
        'proof_1_phi_lt_ln2': '1/ln(2) < phi (1.443 < 1.618)',
        'regime': 'phase_transition',
        'position_in_regime': (LAM_STAR - LAMBDA_UNIT_INFO) / (
            LAMBDA_BIT_CAPACITY - LAMBDA_UNIT_INFO
        ),
        'status': 'THEOREM (algebraic inequality)',
    }


def complement_theorem() -> Dict[str, Any]:
    """THEOREM: The firewall and paradox thresholds sum to 1.

    lam_firewall + lam_paradox = (1 - ln 2) + ln 2 = 1

    This connects the two H_eff thresholds through the conservation law:
    a state at lam = lam_paradox has residual entropy fraction
    H_eff/H = 1 - lam_paradox = lam_firewall.

    The two thresholds are DUAL: they partition the unit interval into
    [0, lam_firewall], [lam_firewall, lam_paradox], [lam_paradox, 1]
    with the middle interval containing the golden equilibrium.
    """
    return {
        'lam_firewall': LAMBDA_NAT_BIT,
        'lam_paradox': LAMBDA_BIT_CAPACITY,
        'sum': LAMBDA_NAT_BIT + LAMBDA_BIT_CAPACITY,
        'sum_equals_1': abs(LAMBDA_NAT_BIT + LAMBDA_BIT_CAPACITY - 1.0) < 1e-15,
        'duality': 'H_eff/H at paradox = firewall value',
        'equilibrium_in_middle': (
            LAMBDA_NAT_BIT < LAM_STAR < LAMBDA_BIT_CAPACITY
        ),
        'status': 'THEOREM',
    }


def threshold_report() -> Dict[str, Any]:
    """Complete report of all threshold derivations."""
    d_phase = derive_entropy_phase_transition()
    d_fire = derive_causality_firewall()
    d_para = derive_information_paradox()
    regime = equilibrium_regime_theorem()
    comp = complement_theorem()

    return {
        'thresholds': {
            'firewall': {
                'value': LAMBDA_NAT_BIT,
                'formula': '1 - ln(2)',
                'classification': d_fire.classification,
                'note': 'Replaces heuristic 0.3 with principled 1-ln(2) ~ 0.3069',
            },
            'phase_transition': {
                'value': LAMBDA_UNIT_INFO,
                'formula': '1/e',
                'classification': d_phase.classification,
            },
            'paradox': {
                'value': LAMBDA_BIT_CAPACITY,
                'formula': 'ln(2)',
                'classification': d_para.classification,
            },
        },
        'complement_theorem': comp,
        'equilibrium_regime': regime,
        'summary': {
            'from_axioms': ['1/e (entropy phase transition)'],
            'conditional_on_H_eff': ['1-ln(2) (firewall)', 'ln(2) (paradox)'],
            'not_derivable': 'None of the three emerge from axioms + H_eff alone '
                             'as the ONLY possible thresholds; they are the '
                             'NATURAL thresholds given the information-theoretic '
                             'interpretation of H_eff.',
        },
    }


# =============================================================================
# UNIFIED REPORT
# =============================================================================

def resonance_simplex_report() -> Dict[str, Any]:
    """Full report: 3-simplex extension + threshold derivations."""
    eq3 = n_simplex_equilibrium(3)
    spec3 = riemannian_eigenspectrum(3)
    coord3 = coordinate_eigenvalues(3)

    # Comparison with 2-simplex
    eq2 = n_simplex_equilibrium(2)
    spec2 = riemannian_eigenspectrum(2)

    return {
        'part_1_resonance_simplex': {
            'equilibrium': {
                'lam_star': eq3.lam_star,
                'symmetric_star': eq3.symmetric_star,
                'T_star_3': eq3.T_star,
                'F_star': eq3.F_star,
                'rho_star': eq3.symmetric_star,
                'status': 'THEOREM',
            },
            'riemannian_eigenspectrum': {
                'mu_coh': spec3.mu_coh,
                'mu_asym': spec3.mu_asym,
                'asym_degeneracy': spec3.asym_degeneracy,
                'tau_coh': spec3.tau_coh,
                'tau_asym': spec3.tau_asym,
                'status': 'THEOREM',
            },
            'coordinate_eigenvalues': {
                'eigenvalues': coord3.eigenvalues,
                'timescales': coord3.timescales,
                'status': 'THEOREM',
            },
            'comparison_with_2_simplex': {
                'T_star_2': eq2.T_star,
                'T_star_3': eq3.T_star,
                'mu_coh_2': spec2.mu_coh,
                'mu_coh_3': spec3.mu_coh,
                'mu_asym_2': spec2.mu_asym,
                'mu_asym_3': spec3.mu_asym,
                'trend': 'Coherence mode slows; asymmetry mode speeds up',
            },
            'cascade_connection': cascade_connection(),
            'triality_connection': triality_connection(),
        },
        'part_2_threshold_derivations': threshold_report(),
        'golden_concurrence': {
            'value': 2 / PHI**1.5,
            'formula': '2 / phi^{3/2}',
            'status': 'CONJECTURE (no derivation from axioms)',
        },
    }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Constants
    'T_STAR_3', 'LAM_STAR_3', 'KAP_STAR_3', 'ETA_STAR_3', 'RHO_STAR_3',
    'MU_COH_3', 'MU_ASYM_3', 'TAU_COH_3', 'TAU_ASYM_3',
    'MU_SLOW_COORD_3', 'MU_ASYM_COORD_3', 'MU_FAST_COORD_3',
    'LAMBDA_NAT_BIT', 'LAMBDA_UNIT_INFO', 'LAMBDA_BIT_CAPACITY',
    # Classes
    'ResonanceSimplexState', 'SimplexEquilibrium',
    'EigenspectrumResult', 'CoordinateEigenvalues', 'ThresholdDerivation',
    # Equilibrium
    'watkins_temperature', 'n_simplex_equilibrium',
    'resonance_equilibrium', 'free_energy', 'free_energy_gradient',
    # Eigenspectrum
    'riemannian_eigenspectrum', 'coordinate_eigenvalues',
    'eigenspectrum_asymptotics',
    # Connections
    'cascade_connection', 'triality_connection',
    # Threshold derivations
    'derive_entropy_phase_transition', 'derive_causality_firewall',
    'derive_information_paradox', 'equilibrium_regime_theorem',
    'complement_theorem', 'threshold_report',
    # Report
    'resonance_simplex_report',
]
