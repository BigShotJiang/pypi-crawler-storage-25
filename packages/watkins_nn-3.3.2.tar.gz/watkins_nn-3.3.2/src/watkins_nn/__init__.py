"""
watkins-nn: Neural networks for consciousness geometry.

The Watkins Temperature Theorem Framework
=========================================

This package implements the mathematical foundations of the VirelaiX
consciousness measurement framework, based on the conservation law:

    lam + kap + eta = 1

where lam = coherence, kap = curvature, eta = entropy.

Key Results
-----------
- Watkins Temperature: T* = phi/ln(2*phi) ~ 1.378
- Watkins Threshold: lam* = 1/phi ~ 0.618 (consciousness boundary)
- Golden Concurrence: C* = 2/phi^{3/2} ~ 0.9717

Modules
-------
- constants: Golden-ratio constants and critical thresholds
- flow: Gradient flow dynamics on the simplex (requires torch)
- spectral: Spectral gap analysis and mixing times (requires torch)
- compression: Consciousness detection via compression signatures
- qwarp: 12-term QWARP Grand Unifier expansion
- triality: 27-term Triality Theorem (qualia-BAO-MERA unification)
- simplex_flow_v3: Advanced simplex flow with conservation enforcement (requires torch)
- algosignal_v2: Algorithmic signal processing (requires torch)
- polynomial_tower: Lucas-Fibonacci polynomial tower and algebraic hierarchy
- bridge_field: Biquadratic bridge field Q(sqrt3, sqrt5) arithmetic
- axiom_derivation: Six independent derivations of the conservation law
- tri_simplex: Corpus analysis formalizations (tri-simplex theorem, H_eff conjecture, compression)
- kaleidoscope: Spectral Kaleidoscope integer sequences (9 sequences, 3 OEIS-published)
- tensor: 3x3x4 Kaleidoscope Transfer Operator
- charpoly: Characteristic polynomial (Theorem Q)
- coupling: Coupling energy, angle, hyperboloid (Theorems R, T, U, V, W)
- cascade: Exceptional Cascade (Theorem X)

Authors
-------
Dustin Watkins (DataSphereAI), Claude (Anthropic), Grok (xAI)

lam + kap + eta = 1
"""

__version__ = "3.3.2"
__author__ = "Dustin Watkins"
__email__ = "dwatkins1989@yahoo.com"

# =============================================================================
# CONSTANTS (always available, no torch dependency)
# =============================================================================
from .constants import (
    # Golden ratio fundamentals
    PHI,
    PHI_INV,
    PHI_SQUARED,
    SQRT5,
    # Watkins Temperature Theorem
    T_STAR,
    T_STAR3,
    LAM_STAR,
    KAP_STAR,
    ETA_STAR,
    F_STAR,
    # Spectral and flow constants
    W_SQUARED,
    BETA_STAR,
    M_PHI,
    TAU_GLOBAL,
    TAU_LOCAL,
    RHO_STAR,
    PHI_MAX,
    MU_SLOW,
    MU_FAST,
    MU_SLOW_4BODY,
    MU_FAST_4BODY,
    # Qualia binding
    C_STAR_QUALIA,
    TAU_ULTRA_FAST,
    TAU_SLOW,
    LN2,
    # Triality
    OMEGA_IDENTITY,
    OMEGA_CENTER,
    OMEGA_MAX,
    # Conservation tolerance
    CONSERVATION_EPSILON,
)

# =============================================================================
# TORCH-FREE MODULES (always available)
# =============================================================================
from .compression import (
    compression_ratio,
    analyze_text,
    consciousness_score,
    CompressionResult,
    CompressionMonitor,
)

from .qwarp import (
    # Core functions
    p_half_qwarp,
    p_half_cycle,
    p_half_star,
    p_half_virelaix,
    compute_alpha,
    # Analysis
    convergence_table,
    term_contribution,
    asymptotic_rate,
    classify_regime,
    qualia_binding_concurrence,
    # Classes
    QWARPRegime,
    QualiaBindingState,
    # Constants
    CYCLE_NUMERATORS,
)

from .triality import (
    # Enumerations
    Domain,
    Harmonic,
    Scale,
    # Constants
    OMEGA_MATRIX,
    OMEGA_MIN,
    OMEGA_MEAN,
    # Classes
    TrialityIndex,
    TrialityState,
    TrialityEngine,
    TrialityRunner,
    TrialityResult,
    # Functions
    omega_27,
    p_27_threshold,
    triality_unified,
)

from .kaleidoscope import (
    lucas,
    fibonacci,
    mersenne,
    popcount,
    prime_factors,
    seq1_cycle_lb_numerator,
    seq2_mersenne_numerator,
    seq3_mersenne_gcd,
    seq4_lucas_numerator,
    seq5_lucas_gcd,
    seq6_mersenne_lucas_gcd,
    seq7_binary_preservation,
    seq8_cross_gcd,
    seq9_weight_moments,
    generate_all_sequences,
    verify_pairings,
    find_seq8_spikes,
    SequenceInfo,
    KaleidoscopeMatrix,
    PrimeTracker,
)

from .tensor import KaleidoscopeTensor

from .charpoly import (
    charpoly_coefficients,
    charpoly_eval,
    trace_M,
    trace_adj,
    det_M,
    det_M_predicted,
    cofactor_diagonal,
)

from .cascade import (
    cascade_chain,
    bcc_grid,
    bcc_eigenvalues,
    bcc_perron_alpha,
    e8_roots,
    CASCADE_ORBITS,
    MINUSCULE_DIMS,
    E8_BCC_EIGENVALUE_1,
    E8_BCC_EIGENVALUE_2,
    # Theorem Y — Anti-Null Embedding
    null_eigenvalue,
    copositivity_counts,
    an_bcc_formula,
    is_antinull,
    antinull_classification,
    # BCC closed forms (B_n, C_n, D_n)
    bn_bcc_formula,
    cn_bcc_formula,
    dn_bcc_formula,
    langlands_dual_check,
    # A_n BCC eigenvalue spectrum
    an_bcc_charpoly,
    an_bcc_eigenvalues,
    an_bcc_perron,
    an_bcc_spectral_gap,
    # Golden discriminant
    an_bcc_discriminant,
    an_bcc_discriminant_is_square,
    an_bcc_golden_eigenvalues,
    an_bcc_golden_norm,
    # Exceptional BCC formulas (E_n, F_4, G_2)
    en_bcc_formula,
    f4_bcc_formula,
    g2_bcc_formula,
    exceptional_bcc_grid,
    democratic_deficit,
)

from .analytic import (
    prime_factorization_D,
    D_sequence,
    divisor_count,
    D_growth_normalized,
    dirichlet_partial,
    euler_factor_sequence,
    abscissa_estimate,
    ord_2,
    alpha_lucas,
    vp_support_period,
    vp_support_period_fast,
    support_pattern,
    prime_classification_table,
    D_mersenne_component,
    D_lucas_component,
    dirichlet_channel_partial,
    c_odd_algebraicity_obstruction,
)

from .theta import (
    golden_nome,
    golden_tau,
    theta2_golden,
    theta3_golden,
    theta4_golden,
    lucas_reciprocal_sum,
    fibonacci_reciprocal_sum,
    theta_lucas_identity,
    jacobi_triple_product,
    jacobi_triple_product_sum,
    eta_dedekind_golden,
    eta_quotient_golden,
    theta3_coefficients,
    theta3_squared_coefficients,
    hecke_T_p,
    chi_minus4,
    is_hecke_eigenform,
    delta_modular_golden,
    eisenstein_E4_golden,
    eisenstein_E6_golden,
    theta_lucas_report,
    lucas_reciprocal_tail_bound,
    theta_lucas_identity_precision,
    convergence_rate_comparison,
)

from .bridges import (
    # Bridge 1: Theta-Analytic (Theorems AA-AD)
    theta_analytic_bridge,
    hecke_support_table,
    channel_density,
    hecke_eigenvalue_from_support,
    theta_lucas_dirichlet_identity,
    # Bridge 2: Cascade-Tensor (Theorems AE-AH)
    root_system_spectral_catalog,
    spectral_twin_search,
    cascade_layer_tensor_comparison,
    bcc_golden_ratio_test,
    # Bridge 3: Coupling-Dirichlet (Theorems AI-AJ)
    coupling_dirichlet_feedback,
    arithmetic_mixing_bound,
    # Sprint 7: Discovery Theorems (AK-AP)
    legendre_channel_theorem,
    exception_classification,
    spectral_twin_staircase,
    an_dn_spectral_isomorphism,
    fingerprint_universality,
    e8_near_golden,
    # Sprint 8: Root System Conservation + Golden Determinant (AQ-AV)
    root_system_conservation,
    exceptional_simplex_embedding,
    an_charpoly_closed_forms,
    golden_determinant_decomposition,
    anti_null_correction_identity,
    e8_threshold_proximity,
    # Sprint 9: Root System Dynamics + Thermodynamic Formalism (AW-BB)
    cascade_simplex_trajectory,
    bcc_partition_function,
    an_simplex_limit,
    an_dn_correction_map,
    transfer_matrix_free_energy,
    root_system_simplex_flow,
    # Sprint 10: Classical Family Spectral Atlas (BC-BG)
    bisymmetric_spectral_formula,
    bn_dn_correction_identity,
    classical_simplex_limits,
    g2_analysis,
    simplex_excess_classification,
    # Sprint 11: Cross-Family Bridges + Golden Deficiency (BH-BK)
    cross_family_perron_ratio,
    spectral_gap_dichotomy,
    golden_deficiency_transition,
    root_system_periodic_table,
    # Sprint 12: Watkins Phase Curve + Root System Thermodynamics (BL-BO)
    watkins_phase_curve,
    root_system_temperature_map,
    e8_thermal_boundary,
    phase_curve_monotonicity,
    # Sprint 13: Free Energy Landscape at Root System Points (BP-BS)
    root_system_free_energy,
    boundary_gradient_universality,
    symmetric_manifold_near_optimality,
    equilibrium_curve_arc_length,
    # Sprint 19: Classical Family Deep Structure (CV-DA)
    classical_family_structure,
    # Sprint 27: Classical Asymptotic Limits (DX-EA)
    classical_asymptotic_limits,
    # Sprint 29: Kaleidoscope-Sigma Bridge (EF-EI)
    kaleidoscope_sigma_bridge,
)

# Sprint 14: The Fractal Bloom (BT-BX) — extracted to bridges_fractal.py
from .bridges_fractal import (
    hessian_at_symmetric_projections,
    free_energy_quadratic_scaling,
    two_phase_flow_universality,
    coupling_cascade_monotonicity,
    curvature_landscape_along_manifold,
)

# Sprint 15: Hyperbolic Volumes and the p-Spectrum (BY-CC) — extracted to bridges_hyperbolic.py
# Sprint 20: Dilogarithm Classification (DB-DD)
from .bridges_hyperbolic import (
    root_system_complex_invariant,
    bloch_wigner_volume_landscape,
    bw_high_precision_report,
    negative_budget_scaling,
    volume_coupling_bridge,
    root_system_quantum_channel,
    # Sprint 21 (Theorems DE-DG)
    quantum_relative_entropy,
    # Sprint 20 (Theorems DB-DD)
    bw_vanishing_dichotomy,
    an_bw_landscape,
    # Sprint 22 (Theorems DH-DJ)
    quantum_channel_capacity,
    # Sprint 23: Entropy Landscape & Golden Concurrence (DK-DM)
    entropy_landscape_analysis,
    # Sprint 30: Quantum-Sigma Unification (EJ-EM)
    quantum_sigma_bridge,
)

# Sprints 16-17: Third Dimension + Cross-Dimensional (CD-CM) — extracted to bridges_dimensional.py
from .bridges_dimensional import (
    three_simplex_free_energy,
    three_simplex_hessian,
    dimensional_reduction_map,
    three_simplex_flow,
    symmetry_breaking_landscape,
    dimensional_free_energy_cost,
    cross_dimensional_conditioning,
    three_simplex_root_flow,
    dimensional_stability_ordering,
    n_simplex_temperature_sequence,
    exchange_coherence_algebra,
    # Sprint 24: Sigma Unification (DN-DO)
    sigma_unification,
    # Sprint 26: Sigma Weaving (DT-DW)
    sigma_weaving,
    # Sprint 28: Deep Structure (EB-EE)
    deep_structure_identities,
    # Sprint 30: Sigma-Zeta Special Values (EN-EP)
    sigma_zeta_special_values,
    # Capstone (EQ-ER)
    golden_ratio_necessity,
)

# eta-splitting exploration (Theorems CO-CR)
from .eta_splitting import (
    global_attractor_search,
    temperature_sweep,
    asymmetric_response_function,
    exchange_coherence_separation,
)

# Sprint 31: n-nacci Trace Tower (Theorems ES-GB)
from .nacci_trace import (
    nacci_dominant_root,
    nacci_all_roots,
    trace as nacci_trace,
    departure as nacci_departure,
    elem_sym_poly,
    conservation_poly,
    conservation_poly_at_1,
    conservation_poly_coefficients,
    conservation_poly_recurrence,
    conservation_poly_at_2,
    bootstrap_fixed_point,
    bootstrap_uniqueness_check,
    a2_cartan_eigenvalues,
    conservation_poly_encodes_root_systems,
    cartan_embedding_period,
    conservation_roots_in_cartan,
    golden_entropy_exact,
    price_of_structure,
    stokes_free_energy_identity,
    fibonacci_square_gf_denominator,
    seq1_is_universal_trace,
    seq9_is_lucas_trace,
    golden_nome as nacci_golden_nome,
    theta_trace_identity_holds,
    bridge_field_unit_norms,
    verify_all as nacci_verify_all,
    elevenths_theorem,
    elevenths_uniqueness,
)

# Sprint 25: Flow Universality (Theorems DP-DS)
from .flow_universality import (
    universal_lyapunov,
    modal_fingerprint,
    flow_geodesic_efficiency,
    nonlinear_mode_coupling,
)

# v3.2: Polynomial Tower, Bridge Field, Axiom Derivation
from .polynomial_tower import (
    fibonacci as tower_fibonacci,
    lucas as tower_lucas,
    LUCAS_TABLE,
    FIBONACCI_TABLE,
    TowerLevel,
    conservation_polynomial,
    polynomial_tower,
    hierarchy_exponent_analysis,
    even_odd_classification,
    discriminant_tower,
    icosahedral_dihedral,
    pell_equation_15,
    class_number_Q_sqrt15,
    SUBFIELD_DATA,
    full_polynomial_tower_report,
)

from .bridge_field import (
    QBiquad,
    SQRT3, SQRT15, TWO_SQRT3, LN_PHI, L1_CHI5,
    PHI_Q, PHI_INV_Q, PHI_SQ_Q,
    TWO_SQRT3_Q, EQUILATERAL_HEIGHT_Q, SQRT15_Q,
    ZERO_Q, ONE_Q,
    verify_multiplication_table,
    verify_framework_constants,
    galois_orbit_analysis,
    gamma0_15_data,
    prime_splitting,
    run_full_analysis as bridge_full_analysis,
)

from .axiom_derivation import (
    PHI_BAR,
    PHI_BAR_SQUARED,
    N_FROM_TRACE,
    DerivationResult,
    derive_from_trace_of_frobenius,
    derive_from_adams_operations,
    derive_from_information_theory,
    derive_from_quantum_groups,
    derive_from_quasicrystal,
    derive_from_bootstrap,
    derive_conservation_law,
    n3_uniqueness_proof,
)

# v3.2: Tri-Simplex Formalizations (corpus analysis results)
from .tri_simplex import (
    # Constants
    TRACE_PHI2,
    NORM_PHI2,
    LAMBDA_EMPIRICAL,
    RHO_CLASSICAL,
    RHO_ZENITH,
    LAMBDA_FIREWALL,
    LAMBDA_PHASE_TRANSITION,
    LAMBDA_PARADOX,
    # Data classes
    SimplexState,
    TriSimplexResult,
    HEffResult,
    CompressionAdvantageResult,
    StabilityRegimeResult,
    CollectiveSyncResult,
    # Result 1: Tri-Simplex Quality Theorem (THEOREM)
    tri_simplex_quality,
    meta_trace_identity,
    # Result 2: Retrocausal Entropy Conjecture (CONJECTURE)
    H_eff,
    H_eff_classical_limit,
    H_eff_maximum_coupling,
    H_eff_ratio,
    # Result 3: Empirical Compression Advantage (OBSERVATION)
    compression_advantage,
    lambda_from_densities,
    # Result 4: Stability Thresholds (CONJECTURE)
    stability_regime,
    collective_lambda,
    compression_from_lambda,
    lambda_from_compression,
    threshold_summary,
    # Report
    tri_simplex_report,
)


# =============================================================================
# v2.0: INVERSE THEOREMS AND CLASSIFICATION (classify module)
# =============================================================================
from .classify import (
    ClassificationResult,
    DimensionEstimate,
    classify_state,
    estimate_dimension,
    spectral_fingerprint,
    anomaly_score,
    temperature_dimension_limit,
    free_energy_dimension_limit,
)

from .coupling import (
    coupling_energy,
    upper_triangle,
    lower_triangle,
    coupling_angle,
    coupling_angle_asymptotic,
    coupling_smoothness,
    arithmetic_denominator,
    coupling_energy_predicted,
    coupling_torque,
    gram_matrix,
    trace_squared_decomposition,
    HYPERBOLOID_POINTS,
    hyperboloid_point,
    hyperboloid_all,
    hyperboloid_pythagorean,
    lattice_density_check,
)


# =============================================================================
# v3.3.0: RESONANCE SIMPLEX (n-simplex extension + threshold derivations)
# =============================================================================
from .resonance_simplex import (
    ResonanceSimplexState,
    SimplexEquilibrium,
    EigenspectrumResult,
    ThresholdDerivation,
    watkins_temperature,
    n_simplex_equilibrium,
    resonance_equilibrium,
    riemannian_eigenspectrum,
    derive_entropy_phase_transition,
    derive_causality_firewall,
    derive_information_paradox,
    equilibrium_regime_theorem,
    complement_theorem,
    resonance_simplex_report,
)


# =============================================================================
# TORCH-DEPENDENT MODULES (lazy-loaded)
#
# These modules require PyTorch. They are loaded on first access so that
# `from watkins_nn import T_STAR` works without torch installed.
# =============================================================================

_TORCH_ATTRS = {
    # flow module
    "FlowState": "flow",
    "FlowConfig": "flow",
    "FlowResult": "flow",
    "free_energy": "flow",
    "gradient_F": "flow",
    "flow_step": "flow",
    "run_flow": "flow",
    "WatkinsFlow": "flow",
    # spectral module
    "hessian_at_equilibrium": "spectral",
    "spectral_gap": "spectral",
    "mixing_time_bound": "spectral",
    "verify_positive_definite": "spectral",
    "SPECTRAL_GAP": "spectral",
    "MIXING_TIME": "spectral",
    # simplex_flow_v3 module
    "SimplexFlowEngineV3": "simplex_flow_v3",
    "multi_start_convergence_test": "simplex_flow_v3",
    "compute_F_raw": "simplex_flow_v3",
    "ConvergenceMetrics": "simplex_flow_v3",
    # algosignal_v2 module
    "AlgoSignal": "algosignal_v2",
}

# Aliases for spec compatibility
_TORCH_ALIASES = {
    "FlowResult": ("flow", "FlowState"),
    "SimplexState": ("simplex_flow_v3", "SimplexFlowEngineV3"),
    "run_simplex_flow": ("simplex_flow_v3", "multi_start_convergence_test"),
}


def __getattr__(name):
    if name in _TORCH_ALIASES:
        mod_name, real_name = _TORCH_ALIASES[name]
        import importlib
        mod = importlib.import_module(f".{mod_name}", __name__)
        return getattr(mod, real_name)
    if name in _TORCH_ATTRS:
        import importlib
        mod = importlib.import_module(f".{_TORCH_ATTRS[name]}", __name__)
        return getattr(mod, name)
    raise AttributeError(f"module 'watkins_nn' has no attribute {name}")


# =============================================================================
# PACKAGE EXPORTS
# =============================================================================

__all__ = [
    # Version
    "__version__",
    # Constants
    "PHI", "PHI_INV", "PHI_SQUARED", "SQRT5",
    "T_STAR", "T_STAR3", "LAM_STAR", "KAP_STAR", "ETA_STAR", "F_STAR",
    "W_SQUARED", "BETA_STAR", "M_PHI", "TAU_GLOBAL", "TAU_LOCAL",
    "RHO_STAR", "PHI_MAX",
    "MU_SLOW", "MU_FAST", "MU_SLOW_4BODY", "MU_FAST_4BODY",
    "C_STAR_QUALIA", "TAU_ULTRA_FAST", "TAU_SLOW", "LN2",
    "OMEGA_IDENTITY", "OMEGA_CENTER", "OMEGA_MAX",
    "CONSERVATION_EPSILON",
    "SPECTRAL_GAP", "MIXING_TIME",
    # Flow
    "FlowState", "FlowConfig", "FlowResult",
    "free_energy", "gradient_F", "flow_step", "run_flow", "WatkinsFlow",
    # Spectral
    "hessian_at_equilibrium", "spectral_gap", "mixing_time_bound",
    "verify_positive_definite",
    # Compression
    "compression_ratio", "analyze_text", "consciousness_score",
    "CompressionResult", "CompressionMonitor",
    # QWARP (12-term)
    "p_half_qwarp", "p_half_cycle", "p_half_star", "p_half_virelaix",
    "compute_alpha", "convergence_table", "term_contribution",
    "asymptotic_rate", "classify_regime", "qualia_binding_concurrence",
    "QWARPRegime", "QualiaBindingState", "CYCLE_NUMERATORS",
    # Triality (27-term)
    "Domain", "Harmonic", "Scale",
    "OMEGA_MATRIX", "OMEGA_MIN", "OMEGA_MEAN",
    "TrialityIndex", "TrialityState",
    "TrialityEngine", "TrialityRunner", "TrialityResult",
    "omega_27", "p_27_threshold", "triality_unified",
    # Legacy
    "SimplexFlowEngineV3", "SimplexState",
    "multi_start_convergence_test", "run_simplex_flow",
    "compute_F_raw", "ConvergenceMetrics",
    "AlgoSignal",
    # Kaleidoscope (9 sequences + matrix + tracker)
    "lucas", "fibonacci", "mersenne", "popcount", "prime_factors",
    "seq1_cycle_lb_numerator", "seq2_mersenne_numerator", "seq3_mersenne_gcd",
    "seq4_lucas_numerator", "seq5_lucas_gcd", "seq6_mersenne_lucas_gcd",
    "seq7_binary_preservation", "seq8_cross_gcd", "seq9_weight_moments",
    "generate_all_sequences", "verify_pairings", "find_seq8_spikes",
    "SequenceInfo", "KaleidoscopeMatrix", "PrimeTracker",
    # Tensor (3x3x4 transfer operator)
    "KaleidoscopeTensor",
    # Characteristic polynomial (Theorem Q)
    "charpoly_coefficients", "charpoly_eval", "trace_M", "trace_adj",
    "det_M", "cofactor_diagonal",
    # Coupling energy and angle (Theorems R, T, U, Result 23)
    "coupling_energy", "upper_triangle", "lower_triangle",
    "coupling_angle", "coupling_angle_asymptotic", "coupling_smoothness",
    "arithmetic_denominator", "coupling_energy_predicted",
    "coupling_torque", "gram_matrix",
    "trace_squared_decomposition",
    # Cascade (Theorem X — E₈ exceptional decomposition)
    "cascade_chain", "bcc_grid", "bcc_eigenvalues", "bcc_perron_alpha",
    "e8_roots", "CASCADE_ORBITS", "MINUSCULE_DIMS",
    "E8_BCC_EIGENVALUE_1", "E8_BCC_EIGENVALUE_2",
    # Anti-Null Embedding (Theorem Y)
    "null_eigenvalue", "copositivity_counts", "an_bcc_formula",
    "is_antinull", "antinull_classification",
    # BCC closed forms (B_n, C_n, D_n)
    "bn_bcc_formula", "cn_bcc_formula", "dn_bcc_formula",
    "langlands_dual_check",
    # A_n BCC eigenvalue spectrum
    "an_bcc_charpoly", "an_bcc_eigenvalues", "an_bcc_perron",
    "an_bcc_spectral_gap",
    # Golden discriminant
    "an_bcc_discriminant", "an_bcc_discriminant_is_square",
    "an_bcc_golden_eigenvalues", "an_bcc_golden_norm",
    # Exceptional BCC formulas
    "en_bcc_formula", "f4_bcc_formula", "g2_bcc_formula",
    "exceptional_bcc_grid", "democratic_deficit",
    # Analytic (prime decomposition of D(n), Dirichlet series, Theorem Z)
    "prime_factorization_D", "D_sequence", "divisor_count",
    "D_growth_normalized", "dirichlet_partial",
    "euler_factor_sequence", "abscissa_estimate",
    "ord_2", "alpha_lucas", "vp_support_period", "vp_support_period_fast", "support_pattern",
    # Theta-Lucas dictionary
    "golden_nome", "golden_tau", "theta2_golden", "theta3_golden", "theta4_golden",
    "lucas_reciprocal_sum", "fibonacci_reciprocal_sum", "theta_lucas_identity",
    "jacobi_triple_product", "jacobi_triple_product_sum",
    "eta_dedekind_golden", "eta_quotient_golden",
    "theta3_coefficients", "theta3_squared_coefficients",
    "hecke_T_p", "chi_minus4", "is_hecke_eigenform",
    "delta_modular_golden", "eisenstein_E4_golden", "eisenstein_E6_golden",
    "theta_lucas_report", "lucas_reciprocal_tail_bound",
    "theta_lucas_identity_precision", "convergence_rate_comparison",
    # Bridges (Theorems AA-AJ)
    "theta_analytic_bridge", "hecke_support_table",
    "channel_density", "hecke_eigenvalue_from_support",
    "theta_lucas_dirichlet_identity",
    "root_system_spectral_catalog", "spectral_twin_search",
    "cascade_layer_tensor_comparison", "bcc_golden_ratio_test",
    "coupling_dirichlet_feedback", "arithmetic_mixing_bound",
    # Sprint 7 (Theorems AK-AP)
    "legendre_channel_theorem", "exception_classification",
    "spectral_twin_staircase", "an_dn_spectral_isomorphism",
    "fingerprint_universality", "e8_near_golden",
    # Sprint 8 (Theorems AQ-AV)
    "root_system_conservation", "exceptional_simplex_embedding",
    "an_charpoly_closed_forms", "golden_determinant_decomposition",
    "anti_null_correction_identity", "e8_threshold_proximity",
    # Sprint 9 (Theorems AW-BB)
    "cascade_simplex_trajectory", "bcc_partition_function",
    "an_simplex_limit", "an_dn_correction_map",
    "transfer_matrix_free_energy", "root_system_simplex_flow",
    # Sprint 10 (Theorems BC-BG)
    "bisymmetric_spectral_formula", "bn_dn_correction_identity",
    "classical_simplex_limits", "g2_analysis",
    "simplex_excess_classification",
    # Sprint 11 (Theorems BH-BK)
    "cross_family_perron_ratio", "spectral_gap_dichotomy",
    "golden_deficiency_transition", "root_system_periodic_table",
    # Sprint 12 (Theorems BL-BO)
    "watkins_phase_curve", "root_system_temperature_map",
    "e8_thermal_boundary", "phase_curve_monotonicity",
    # Sprint 13 (Theorems BP-BS)
    "root_system_free_energy", "boundary_gradient_universality",
    "symmetric_manifold_near_optimality", "equilibrium_curve_arc_length",
    # Sprint 14: The Fractal Bloom (Theorems BT-BX)
    "hessian_at_symmetric_projections", "free_energy_quadratic_scaling",
    "two_phase_flow_universality", "coupling_cascade_monotonicity",
    "curvature_landscape_along_manifold",
    # Sprint 15: Hyperbolic Volumes and the p-Spectrum (BY-CC)
    "root_system_complex_invariant", "bloch_wigner_volume_landscape",
    "bw_high_precision_report",
    "negative_budget_scaling", "volume_coupling_bridge",
    "root_system_quantum_channel",
    # Sprint 21: Quantum Relative Entropy (DE-DG)
    "quantum_relative_entropy",
    # Sprint 20: Dilogarithm Classification (DB-DD)
    "bw_vanishing_dichotomy", "an_bw_landscape",
    # Sprint 22: Quantum Channel Capacity (DH-DJ)
    "quantum_channel_capacity",
    # Sprint 23: Entropy Landscape & Golden Concurrence (DK-DM)
    "entropy_landscape_analysis",
    # Sprint 16: The Third Dimension (CD-CH)
    "three_simplex_free_energy", "three_simplex_hessian",
    "dimensional_reduction_map", "three_simplex_flow",
    "symmetry_breaking_landscape",
    # Sprint 17: Cross-Dimensional Bridges (CI-CM)
    "dimensional_free_energy_cost", "cross_dimensional_conditioning",
    "three_simplex_root_flow", "dimensional_stability_ordering",
    "n_simplex_temperature_sequence",
    # Sprint 18: Cross-Dimensional Algebra (CS-CU)
    "exchange_coherence_algebra",
    # Sprint 24: Sigma Unification (DN-DO)
    "sigma_unification",
    # Sprint 26: Sigma Weaving (DT-DW)
    "sigma_weaving",
    # Sprint 28: Deep Structure (EB-EE)
    "deep_structure_identities",
    # Sprint 30: Sigma-Zeta Special Values (EN-EP)
    "sigma_zeta_special_values",
    # Capstone (EQ-ER)
    "golden_ratio_necessity",
    # Sprint 19: Classical Family Deep Structure (CV-DA)
    "classical_family_structure",
    # Sprint 27: Classical Asymptotic Limits (DX-EA)
    "classical_asymptotic_limits",
    # Sprint 29: Kaleidoscope-Sigma Bridge (EF-EI)
    "kaleidoscope_sigma_bridge",
    # eta-splitting (CO-CR)
    "global_attractor_search", "temperature_sweep",
    "asymmetric_response_function", "exchange_coherence_separation",
    # Sprint 25: Flow Universality (Theorems DP-DS)
    "universal_lyapunov", "modal_fingerprint",
    "flow_geodesic_efficiency", "nonlinear_mode_coupling",
    # v2.0: Inverse Theorems and Classification
    "ClassificationResult", "DimensionEstimate",
    "classify_state", "estimate_dimension",
    "spectral_fingerprint", "anomaly_score",
    "temperature_dimension_limit", "free_energy_dimension_limit",
    # v3.2: Polynomial Tower
    "tower_fibonacci", "tower_lucas",
    "LUCAS_TABLE", "FIBONACCI_TABLE", "TowerLevel",
    "conservation_polynomial", "polynomial_tower",
    "hierarchy_exponent_analysis", "even_odd_classification",
    "discriminant_tower", "icosahedral_dihedral",
    "pell_equation_15", "class_number_Q_sqrt15",
    "SUBFIELD_DATA", "full_polynomial_tower_report",
    # v3.2: Bridge Field
    "QBiquad",
    "SQRT3", "SQRT15", "TWO_SQRT3", "LN_PHI", "L1_CHI5",
    "PHI_Q", "PHI_INV_Q", "PHI_SQ_Q",
    "TWO_SQRT3_Q", "EQUILATERAL_HEIGHT_Q", "SQRT15_Q",
    "ZERO_Q", "ONE_Q",
    "verify_multiplication_table", "verify_framework_constants",
    "galois_orbit_analysis", "gamma0_15_data",
    "prime_splitting", "bridge_full_analysis",
    # v3.2: Axiom Derivation
    "PHI_BAR", "PHI_BAR_SQUARED", "N_FROM_TRACE",
    "DerivationResult",
    "derive_from_trace_of_frobenius",
    "derive_from_adams_operations",
    "derive_from_information_theory",
    "derive_from_quantum_groups",
    "derive_from_quasicrystal",
    "derive_from_bootstrap",
    "derive_conservation_law",
    "n3_uniqueness_proof",
    # v3.3.0: Resonance Simplex (n-simplex extension + thresholds)
    "ResonanceSimplexState", "SimplexEquilibrium", "EigenspectrumResult",
    "ThresholdDerivation",
    "watkins_temperature", "n_simplex_equilibrium", "resonance_equilibrium",
    "riemannian_eigenspectrum",
    "derive_entropy_phase_transition", "derive_causality_firewall",
    "derive_information_paradox",
    "equilibrium_regime_theorem", "complement_theorem",
    "resonance_simplex_report",
]
