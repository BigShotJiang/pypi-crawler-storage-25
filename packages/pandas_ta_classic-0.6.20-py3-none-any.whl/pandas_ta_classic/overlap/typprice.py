# Typical Price (TYPPRICE)
from typing import Any, Optional
from pandas import Series
from pandas_ta_classic import Imports
from pandas_ta_classic.utils import apply_fill, apply_offset, get_offset, verify_series


def typprice(
    high: Series,
    low: Series,
    close: Series,
    talib: Optional[bool] = None,
    offset: Optional[int] = None,
    **kwargs: Any,
) -> Optional[Series]:
    """Indicator: Typical Price (TYPPRICE)

    Per-bar (High + Low + Close) / 3.  Equivalent to ta.hlc3.
    TA-Lib name: TYPPRICE.
    """
    high = verify_series(high)
    low = verify_series(low)
    close = verify_series(close)
    offset = get_offset(offset)
    mode_talib = bool(talib) if isinstance(talib, bool) else False

    if high is None or low is None or close is None:
        return None

    if Imports["talib"] and mode_talib:
        from talib import TYPPRICE

        result = Series(TYPPRICE(high, low, close), index=close.index)
    else:
        result = (high + low + close) / 3.0

    # Offset
    result = apply_offset(result, offset)
    result = apply_fill(result, **kwargs)

    result.name = "TYPPRICE"
    result.category = "overlap"
    return result


typprice.__doc__ = """Typical Price (TYPPRICE)

TYPPRICE = (High + Low + Close) / 3

Equivalent to ta.hlc3.  TA-Lib name: TYPPRICE.

Args:
    high (pd.Series): Series of 'high' prices
    low (pd.Series): Series of 'low' prices
    close (pd.Series): Series of 'close' prices
    talib (bool): If TA Lib is installed and talib is True, Returns the TA Lib
        version. Default: True
    offset (int): Periods to offset. Default: 0

Kwargs:
    fillna (value, optional): pd.DataFrame.fillna(value)
    fill_method (value, optional): Type of fill method

Returns:
    pd.Series
"""
