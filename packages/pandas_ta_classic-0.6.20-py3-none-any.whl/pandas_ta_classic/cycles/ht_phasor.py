# Hilbert Transform - Phasor Components (HT_PHASOR)
from typing import Any, Optional
from pandas import DataFrame, Series
from pandas_ta_classic.cycles._hilbert import hilbert_result
from pandas_ta_classic.utils import apply_fill, apply_offset, get_offset, verify_series


def ht_phasor(
    close: Series,
    offset: Optional[int] = None,
    **kwargs: Any,
) -> Optional[DataFrame]:
    """Indicator: Hilbert Transform - Phasor Components"""
    # Validate Arguments
    close = verify_series(close)
    offset = get_offset(offset)

    if close is None:
        return None

    # Calculate Result
    ht = hilbert_result(close)
    inphase = Series(ht["in_phase"], index=close.index)
    quadrature = Series(ht["quadrature"], index=close.index)

    # Offset
    inphase, quadrature = apply_offset([inphase, quadrature], offset)

    # Handle fills
    inphase, quadrature = apply_fill([inphase, quadrature], **kwargs)

    # Name and Categorize it
    inphase.name = "HT_PHASOR_INPHASE"
    quadrature.name = "HT_PHASOR_QUAD"

    data = {inphase.name: inphase, quadrature.name: quadrature}
    df = DataFrame(data)
    df.name = "HT_PHASOR"
    df.category = "cycles"

    return df


ht_phasor.__doc__ = """Hilbert Transform - Phasor Components (HT_PHASOR)

Returns the InPhase and Quadrature components of the Hilbert Transform,
which together form a phasor representation of the dominant cycle.

Sources:
    John F. Ehlers, "Rocket Science for Traders"

Args:
    close (pd.Series): Series of 'close's
    offset (int): How many periods to offset the result. Default: 0

Kwargs:
    fillna (value, optional): pd.DataFrame.fillna(value)
    fill_method (value, optional): Type of fill method

Returns:
    pd.DataFrame: inphase and quadrature columns.
"""
