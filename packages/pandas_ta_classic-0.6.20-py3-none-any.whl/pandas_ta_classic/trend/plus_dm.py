# Plus Directional Movement (PLUS_DM)
from typing import Any, Optional
from pandas import Series
from pandas_ta_classic import Imports
from pandas_ta_classic.utils import (
    apply_fill,
    apply_offset,
    get_drift,
    get_offset,
    verify_series,
    zero,
)


def plus_dm(
    high: Series,
    low: Series,
    length: Optional[int] = None,
    talib: Optional[bool] = None,
    drift: Optional[int] = None,
    offset: Optional[int] = None,
    **kwargs: Any,
) -> Optional[Series]:
    """Indicator: Plus Directional Movement (+DM, PLUS_DM)

    Raw Wilder-smoothed positive directional movement.
    TA-Lib name: PLUS_DM.
    """
    length = int(length) if length and length > 0 else 14
    high = verify_series(high, length)
    low = verify_series(low, length)
    drift = get_drift(drift)
    offset = get_offset(offset)
    mode_talib = bool(talib) if isinstance(talib, bool) else False

    if high is None or low is None:
        return None

    if Imports["talib"] and mode_talib:
        from talib import PLUS_DM as _PLUS_DM

        result = _PLUS_DM(high, low, timeperiod=length)
    else:
        from pandas_ta_classic.overlap.ma import ma

        up = high - high.shift(drift)
        dn = low.shift(drift) - low
        pos_ = ((up > dn) & (up > 0)) * up
        pos_ = pos_.apply(zero)
        result = ma("rma", pos_, length=length)
        if result is None:
            return None
        result = result * length  # Wilder's raw DM

    # Offset
    result = apply_offset(result, offset)
    result = apply_fill(result, **kwargs)

    result.name = f"PLUS_DM_{length}"
    result.category = "trend"
    return result


plus_dm.__doc__ = """Plus Directional Movement (+DM, PLUS_DM)

Raw Wilder-smoothed positive directional movement before conversion to DI+.

TA-Lib name: PLUS_DM.

Args:
    high (pd.Series): Series of 'high' prices
    low (pd.Series): Series of 'low' prices
    length (int): Lookback period. Default: 14
    talib (bool): Use TA-Lib C library if installed. Default: False
    drift (int): Difference period. Default: 1
    offset (int): Periods to offset. Default: 0

Kwargs:
    fillna (value, optional): pd.DataFrame.fillna(value)
    fill_method (value, optional): Type of fill method

Returns:
    pd.Series
"""
