# Bollinger Bands (BBANDS)
from typing import Any, Optional
from pandas import DataFrame, Series
from pandas_ta_classic import Imports
from pandas_ta_classic.overlap.ma import ma
from pandas_ta_classic.statistics import stdev
from pandas_ta_classic.utils import (
    apply_fill,
    apply_offset,
    get_offset,
    non_zero_range,
    tal_ma,
    verify_series,
)


def _bbands_native(close, length, std, ddof, mamode, kwargs):
    """Compute Bollinger Bands without TA-Lib.

    Args:
        close (Series): Close price series.
        length (int): Look-back period.
        std (float): Standard deviation multiplier.
        ddof (int): Delta degrees-of-freedom for stdev.
        mamode (str): MA type for the middle band.
        kwargs (dict): Extra kwargs forwarded to the MA call.

    Returns:
        tuple[Series, Series, Series] | None: ``(lower, mid, upper)`` or
        *None* when any intermediate result is unavailable.
    """
    standard_deviation = stdev(close=close, length=length, ddof=ddof)
    if standard_deviation is None:
        return None
    deviations = std * standard_deviation
    mid = ma(mamode, close, length=length, **kwargs)
    if mid is None:
        return None
    lower = mid - deviations
    upper = mid + deviations
    return lower, mid, upper


def bbands(
    close: Series,
    length: Optional[int] = None,
    std: Optional[float] = None,
    ddof: int = 0,
    mamode: Optional[str] = None,
    talib: Optional[bool] = None,
    offset: Optional[int] = None,
    **kwargs: Any,
) -> Optional[DataFrame]:
    """Indicator: Bollinger Bands (BBANDS)"""
    # Validate arguments
    length = int(length) if length and length > 1 else 5
    std = float(std) if std and std > 0 else 2.0
    mamode = mamode if isinstance(mamode, str) else "sma"
    ddof = int(ddof) if ddof >= 0 and ddof < length else 1
    close = verify_series(close, length)
    offset = get_offset(offset)
    mode_talib = bool(talib) if isinstance(talib, bool) else False

    if close is None:
        return None

    # Calculate Result
    if Imports["talib"] and mode_talib:
        from talib import BBANDS

        upper, mid, lower = BBANDS(close, length, std, std, tal_ma(mamode))
    else:
        result = _bbands_native(close, length, std, ddof, mamode, kwargs)
        if result is None:
            return None
        lower, mid, upper = result

    ulr = non_zero_range(upper, lower)
    bandwidth = 100 * ulr / mid
    percent = non_zero_range(close, lower) / ulr

    # Offset
    lower, mid, upper, bandwidth, percent = apply_offset(
        [lower, mid, upper, bandwidth, percent], offset
    )

    lower, mid, upper, bandwidth, percent = apply_fill(
        [lower, mid, upper, bandwidth, percent], **kwargs
    )

    # Name and Categorize it
    lower.name = f"BBL_{length}_{std}"
    mid.name = f"BBM_{length}_{std}"
    upper.name = f"BBU_{length}_{std}"
    bandwidth.name = f"BBB_{length}_{std}"
    percent.name = f"BBP_{length}_{std}"
    upper.category = lower.category = "volatility"
    mid.category = bandwidth.category = upper.category

    # Prepare DataFrame to return
    data = {
        lower.name: lower,
        mid.name: mid,
        upper.name: upper,
        bandwidth.name: bandwidth,
        percent.name: percent,
    }
    bbandsdf = DataFrame(data)
    bbandsdf.name = f"BBANDS_{length}_{std}"
    bbandsdf.category = mid.category

    return bbandsdf


bbands.__doc__ = """Bollinger Bands (BBANDS)

A popular volatility indicator by John Bollinger.

Sources:
    https://www.tradingview.com/wiki/Bollinger_Bands_(BB)

Calculation:
    Default Inputs:
        length=5, std=2, mamode="sma", ddof=0
    EMA = Exponential Moving Average
    SMA = Simple Moving Average
    STDEV = Standard Deviation
    stdev = STDEV(close, length, ddof)
    if "ema":
        MID = EMA(close, length)
    else:
        MID = SMA(close, length)

    LOWER = MID - std * stdev
    UPPER = MID + std * stdev

    BANDWIDTH = 100 * (UPPER - LOWER) / MID
    PERCENT = (close - LOWER) / (UPPER - LOWER)

Args:
    close (pd.Series): Series of 'close's
    length (int): The short period. Default: 5
    std (int): The long period. Default: 2
    ddof (int): Degrees of Freedom to use. Default: 0
    mamode (str): See ```help(ta.ma)```. Default: 'sma'
    talib (bool): If TA Lib is installed and talib is True, Returns the TA Lib
        version. Default: True
    offset (int): How many periods to offset the result. Default: 0

Kwargs:
    fillna (value, optional): pd.DataFrame.fillna(value)
    fill_method (value, optional): Type of fill method

Returns:
    pd.DataFrame: lower, mid, upper, bandwidth, and percent columns.
"""
