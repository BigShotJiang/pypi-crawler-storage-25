"""Pisama CLI."""
