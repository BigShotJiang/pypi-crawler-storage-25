"""
Aggregate RPV vs quality metrics across multiple datasets.

Run bombcell (distance metrics + drift + raw waveforms) on each dataset, pool
all high-FR units, and analyse which metrics correlate with RPV contamination.
Suggests thresholds at RPV cutoffs of 10%, 15%, 20%.

The RPV estimator used as the "ground-truth" contamination label is
selectable via RPV_METHOD below. Supported values:

    "sliding+dcisiv" (default): Steinmetz-lab sliding-RP blended 70/30 with
        DCISIv (Vincent & Economo 2024). Read from `combined_contamination`.
    "sliding":  sliding-RP alone. Read from `fractionRPVs_estimatedTauR`.
    "dcisiv":   DCISIv per-unit FDR alone (homogeneous model).
    "hill":     Hill et al. contamination at a fixed tauR.
    "llobet":   Llobet et al. contamination at a fixed tauR.

Usage:
    python BC_aggregate_rpv_vs_metrics.py

Edit the DATASETS list below to point at your recordings.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from scipy import stats

import bombcell as bc
from bombcell.quality_metrics import get_quality_unit_type

# ──────────────────────────────────────────────────────────────────────
# EDIT HERE: one entry per dataset
# ──────────────────────────────────────────────────────────────────────
DATASETS = [
    {
        "ks_dir": "/path/to/dataset1/kilosort4",
        "raw_file": None,      # path to .ap.bin (None if unavailable)
        "meta_file": None,     # path to .meta or .oebin (None to auto-detect)
        "ks_version": 4,
    },
    {
        "ks_dir": "/path/to/dataset2/kilosort4",
        "raw_file": None,
        "meta_file": None,
        "ks_version": 4,
    },
    # add more entries …
]

FR_THRESHOLD = 10          # Hz – high-FR cutoff
RPV_CUTOFFS = [0.1, 0.15, 0.2]
FORCE_RERUN = False        # set True to recompute even if cached results exist

# RPV estimator used as the contamination label. One of:
#   "sliding" (default), "dcisiv", "hill", "llobet", "sliding+dcisiv".
# See module docstring for details. "sliding+dcisiv" is an exploratory
# hard-coded 0.7/0.3 blend (see warning in RPV_METHOD_SPECS below).
RPV_METHOD = "sliding"

OUTPUT_DIR = Path("aggregate_rpv_vs_metrics") / RPV_METHOD.replace("+", "_")

# ── Per-method bombcell settings, save-path tag, parquet field, plot label ──
# bombcell_kwargs: passed into param.update() before run_bombcell.
# field: key in the saved quality_metrics dict that holds the contamination
#        estimate used for the "ground truth" RPV label in this analysis.
#        (For sliding+dcisiv, bombcell stores the 70/30 blend under
#        `combined_contamination`; everything else uses the standard
#        `fractionRPVs_estimatedTauR` entry — see quality_metrics.py:2170.)
# label: short human-readable label used in plot titles/axes.
# tag:   string embedded in the per-dataset save_path so caches for different
#        methods do not collide.
_SLIDING_SWEEP = {
    "tauR_valuesMin": 1 / 1000,
    "tauR_valuesMax": 5 / 1000,
    "tauR_valuesStep": 0.5 / 1000,
}
_FIXED_2MS = {
    "tauR_valuesMin": 2 / 1000,
    "tauR_valuesMax": 2 / 1000,
    "tauR_valuesStep": 0.5 / 1000,
}
RPV_METHOD_SPECS = {
    # WARNING: this mode reads `combined_contamination`, which bombcell
    # computes as a hardcoded 0.7*sliding_RP + 0.3*DCISIv blend (see
    # py_bombcell/bombcell/dscisi.py:491-509). The weights are ad-hoc and
    # exploratory — not calibrated or published — so thresholds optimised
    # against this label are hard to interpret. Prefer "sliding" for a
    # principled default.
    "sliding+dcisiv": {
        "bombcell_kwargs": {"rpvMethod": "sliding", "computeDCISI": True,
                            **_SLIDING_SWEEP},
        "field": "combined_contamination",
        "label": "Sliding RP + DCISIv (70/30 blend, exploratory)",
        "xlabel": "Contamination (sliding RP + DCISIv blend)",
        "tag": "sliding_dcisiv",
    },
    "sliding": {
        "bombcell_kwargs": {"rpvMethod": "sliding", "computeDCISI": False,
                            **_SLIDING_SWEEP},
        "field": "fractionRPVs_estimatedTauR",
        "label": "Sliding RP",
        "xlabel": "Contamination (sliding RP)",
        "tag": "sliding",
    },
    "dcisiv": {
        "bombcell_kwargs": {"rpvMethod": "dcisiv", "computeDCISI": False,
                            **_SLIDING_SWEEP},
        "field": "fractionRPVs_estimatedTauR",
        "label": "DCISIv (per-unit)",
        "xlabel": "DCISIv FDR (per-unit)",
        "tag": "dcisiv",
    },
    "hill": {
        "bombcell_kwargs": {"rpvMethod": "hill", "computeDCISI": False,
                            **_FIXED_2MS},
        "field": "fractionRPVs_estimatedTauR",
        "label": "Hill 2 ms",
        "xlabel": "RPV contamination (Hill 2 ms)",
        "tag": "hill_2ms",
    },
    "llobet": {
        "bombcell_kwargs": {"rpvMethod": "llobet", "computeDCISI": False,
                            **_FIXED_2MS},
        "field": "fractionRPVs_estimatedTauR",
        "label": "Llobet 2 ms",
        "xlabel": "RPV contamination (Llobet 2 ms)",
        "tag": "llobet_2ms",
    },
}

if RPV_METHOD not in RPV_METHOD_SPECS:
    raise ValueError(
        f"RPV_METHOD={RPV_METHOD!r} not supported. "
        f"Choose one of: {sorted(RPV_METHOD_SPECS)}"
    )

_SPEC = RPV_METHOD_SPECS[RPV_METHOD]
RPV_BOMBCELL_KWARGS = _SPEC["bombcell_kwargs"]
RPV_FIELD = _SPEC["field"]
RPV_LABEL = _SPEC["label"]
RPV_XLABEL = _SPEC["xlabel"]
RPV_TAG = _SPEC["tag"]

# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────

METRIC_COLS = [
    "isolation_distance", "l_ratio", "amplitude",
    "snr", "max_drift", "presence_ratio",
]
METRIC_LABELS = {
    "isolation_distance": "Isolation distance",
    "l_ratio": "L-ratio",
    "amplitude": "Raw amplitude (uV)",
    "snr": "SNR",
    "max_drift": "Max drift (um)",
    "presence_ratio": "Presence ratio",
}
HIGHER_IS_CLEANER = {"isolation_distance", "amplitude", "snr", "presence_ratio"}


def _parquet_missing_raw_amp(qm_parquet, save_path):
    """True if cached parquet has rawAmplitude all-NaN but raw waveform .npy
    files exist on disk — i.e. a stale parquet from a previous broken run that
    can be repaired by re-running bombcell (which will load the cached .npy
    waveforms via the helper_functions.py fix)."""
    try:
        df = pd.read_parquet(qm_parquet, columns=["rawAmplitude"])
    except Exception:
        return False
    if "rawAmplitude" not in df.columns:
        return True
    if not df["rawAmplitude"].isna().all():
        return False
    raw_wf_npy = Path(save_path) / "templates._bc_rawWaveforms.npy"
    return raw_wf_npy.exists()


def run_dataset(ds, force_rerun=False):
    """Run bombcell on one dataset, return per-unit DataFrame."""
    ks_dir = ds["ks_dir"]
    save_path = Path(ks_dir).parent / "bombcell_full"
    qm_parquet = save_path / "templates._bc_qMetrics.parquet"
    param_parquet = save_path / "_bc_parameters._bc_qMetrics.parquet"

    # ── Try loading cached results ──
    if qm_parquet.exists() and param_parquet.exists() and not force_rerun:
        print(f"  Loading cached: {ks_dir}")
        df = pd.read_parquet(qm_parquet)
        param_df = pd.read_parquet(param_parquet)
        param_out = param_df.iloc[0].to_dict()
        qm = {col: df[col].values for col in df.columns}
        ut, ut_str = get_quality_unit_type(param_out, qm)
    else:
        print(f"  Running bombcell: {ks_dir}")
        param = bc.get_default_parameters(
            ks_dir,
            raw_file=ds.get("raw_file"),
            meta_file=ds.get("meta_file"),
            kilosort_version=ds.get("ks_version", 4),
        )
        param.update({
            "computeDistanceMetrics": True,
            "computeDrift": True,
            "extractRaw": True,
            "plotGlobal": False,
            "verbose": True,
            **RPV_BOMBCELL_KWARGS,  # rpvMethod, computeDCISI, tauR sweep
        })
        qm, param_out, ut, ut_str = bc.run_bombcell(ks_dir, save_path, param)

    # ── Compute firing rate ──
    fs = param_out["ephys_sample_rate"]
    (spike_times_samples, spike_clusters,
     *_rest) = bc.load_ephys_data(ks_dir)
    spike_times_sec = spike_times_samples / fs

    cluster_ids = np.array(qm["phy_clusterID"]).flatten()
    n_units = len(cluster_ids)
    firing_rate = np.full(n_units, np.nan)

    t_starts = np.array(qm["useTheseTimesStart"]).flatten()
    t_stops = np.array(qm["useTheseTimesStop"]).flatten()

    for i, uid in enumerate(cluster_ids):
        t0, t1 = t_starts[i], t_stops[i]
        if np.isnan(t0) or np.isnan(t1) or t1 <= t0:
            continue
        mask = spike_clusters == uid
        spks = spike_times_sec[mask]
        spks = spks[(spks >= t0) & (spks < t1)]
        firing_rate[i] = spks.size / (t1 - t0)

    # ── Build per-unit row ──
    def _flat(key):
        v = qm.get(key)
        if v is None:
            return np.full(n_units, np.nan)
        v = np.array(v)
        if v.ndim == 2:
            return np.nanmin(v, axis=1)
        return v.flatten()

    # Read RPV from the field matching the selected method. If the requested
    # field is missing (e.g. cached parquet predates this branch), fall back
    # to fractionRPVs_estimatedTauR and warn.
    rpv_vals = _flat(RPV_FIELD)
    if np.all(np.isnan(rpv_vals)) and RPV_FIELD != "fractionRPVs_estimatedTauR":
        print(f"  WARNING: '{RPV_FIELD}' not found or all-NaN in cached output "
              f"for {ks_dir}; falling back to 'fractionRPVs_estimatedTauR'. "
              f"Delete the cache and rerun to get {RPV_METHOD} values.")
        rpv_vals = _flat("fractionRPVs_estimatedTauR")

    unit_df = pd.DataFrame({
        "dataset": Path(ks_dir).name,
        "cluster_id": cluster_ids,
        "firing_rate": firing_rate,
        "unit_type": ut,
        "rpv": rpv_vals,
        "isolation_distance": _flat("isolationDistance"),
        "l_ratio": _flat("Lratio"),
        "amplitude": _flat("rawAmplitude"),
        "snr": _flat("signalToNoiseRatio"),
        "max_drift": _flat("maxDriftEstimate"),
        "presence_ratio": _flat("presenceRatio"),
    })
    return unit_df


# ──────────────────────────────────────────────────────────────────────
# 1. Run all datasets and aggregate
# ──────────────────────────────────────────────────────────────────────
print("=" * 60)
print("Processing datasets")
print("=" * 60)

all_dfs = []
for ds in DATASETS:
    try:
        unit_df = run_dataset(ds, force_rerun=FORCE_RERUN)
        all_dfs.append(unit_df)
        print(f"    {len(unit_df)} units")
    except Exception as e:
        print(f"    FAILED: {e}")

df = pd.concat(all_dfs, ignore_index=True)
print(f"\nTotal: {len(df)} units from {df['dataset'].nunique()} datasets")

noise_mask = df["unit_type"] == 0
high_fr = df["firing_rate"] > FR_THRESHOLD
df_hfr = df[high_fr & ~noise_mask].copy()
print(f"High-FR (>{FR_THRESHOLD} Hz) non-noise units: {len(df_hfr)}")

OUTPUT_DIR.mkdir(exist_ok=True)

# ──────────────────────────────────────────────────────────────────────
# 2. Firing rate distributions per dataset
# ──────────────────────────────────────────────────────────────────────
print("\nPlotting firing rate distributions...")

datasets = df["dataset"].unique()
n_ds = len(datasets)
fig, axes = plt.subplots(1, n_ds + 1, figsize=(4 * (n_ds + 1), 4), squeeze=False)
axes = axes[0]

fr_bins = np.logspace(-1, 3, 60)  # 0.1 to 1000 Hz

for i, ds_name in enumerate(datasets):
    ax = axes[i]
    fr = df.loc[(df["dataset"] == ds_name) & ~noise_mask, "firing_rate"].dropna()
    ax.hist(fr, bins=fr_bins, color="#3498db", alpha=0.7, edgecolor="white", linewidth=0.3)
    ax.set_xscale("log")
    ax.axvline(FR_THRESHOLD, color="#e74c3c", ls="--", lw=1.2, label=f"{FR_THRESHOLD} Hz")
    ax.set_xlabel("Firing rate (Hz)")
    ax.set_ylabel("Unit count")
    ax.set_title(f"{ds_name}\n(n={len(fr)}, >{FR_THRESHOLD}Hz: {(fr > FR_THRESHOLD).sum()})")
    ax.legend(fontsize=8)

# Pooled
ax = axes[-1]
fr_all = df.loc[~noise_mask, "firing_rate"].dropna()
ax.hist(fr_all, bins=fr_bins, color="#2c3e50", alpha=0.7, edgecolor="white", linewidth=0.3)
ax.set_xscale("log")
ax.axvline(FR_THRESHOLD, color="#e74c3c", ls="--", lw=1.2, label=f"{FR_THRESHOLD} Hz")
ax.set_xlabel("Firing rate (Hz)")
ax.set_title(f"Pooled\n(n={len(fr_all)}, >{FR_THRESHOLD}Hz: {(fr_all > FR_THRESHOLD).sum()})")
ax.legend(fontsize=8)

plt.suptitle("Firing rate distributions (non-noise units)", fontsize=13)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "firing_rate_distributions.png", dpi=150, bbox_inches="tight")
plt.show()

# ──────────────────────────────────────────────────────────────────────
# 3. Correlation matrix (high-FR units)
# ──────────────────────────────────────────────────────────────────────
print("\nComputing correlations (high-FR units)...")

corr_rows = []
for met_col in METRIC_COLS:
    valid = df_hfr[["rpv", met_col]].dropna()
    if len(valid) < 10:
        corr_rows.append({"metric": METRIC_LABELS[met_col], "rho": np.nan,
                          "p": np.nan, "n": len(valid)})
        continue
    rho, p = stats.spearmanr(valid["rpv"], valid[met_col])
    corr_rows.append({"metric": METRIC_LABELS[met_col], "rho": rho, "p": p,
                      "n": len(valid)})

corr_df = pd.DataFrame(corr_rows)
print(f"\nSpearman rho ({RPV_LABEL} vs metric):")
print(corr_df.to_string(index=False))
corr_df.to_csv(OUTPUT_DIR / "spearman_correlations.csv", index=False)

# Heatmap
fig, ax = plt.subplots(figsize=(5, 4))
rhos = corr_df["rho"].values
im = ax.imshow(rhos.reshape(-1, 1), cmap="RdBu_r", vmin=-1, vmax=1, aspect=0.4)
ax.set_yticks(range(len(METRIC_COLS)))
ax.set_yticklabels([METRIC_LABELS[m] for m in METRIC_COLS])
ax.set_xticks([0])
ax.set_xticklabels([RPV_LABEL])
for i, (r, p) in enumerate(zip(corr_df["rho"], corr_df["p"])):
    stars = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else ""
    color = "white" if abs(r) > 0.5 else "black"
    ax.text(0, i, f"{r:.2f}{stars}", ha="center", va="center", fontsize=11, color=color)
plt.colorbar(im, ax=ax, label="Spearman rho")
ax.set_title(f"RPV vs quality metrics\n(pooled high-FR, n={len(df_hfr)})")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "correlation_heatmap.png", dpi=150, bbox_inches="tight")
plt.show()

# ──────────────────────────────────────────────────────────────────────
# 4. Scatter plots (high-FR)
# ──────────────────────────────────────────────────────────────────────
print("\nPlotting scatters...")

LOG_Y_METRICS = {"isolation_distance", "l_ratio"}

fig, axes = plt.subplots(2, 3, figsize=(15, 9))
for idx, met_col in enumerate(METRIC_COLS):
    ax = axes[idx // 3, idx % 3]
    valid = df_hfr[["rpv", met_col, "dataset"]].dropna()
    if met_col in LOG_Y_METRICS:
        # log scale needs strictly positive values
        valid = valid[valid[met_col] > 0]
    if len(valid) < 5:
        ax.text(0.5, 0.5, "insufficient data", transform=ax.transAxes, ha="center")
        continue

    for ds_name in valid["dataset"].unique():
        sub = valid[valid["dataset"] == ds_name]
        ax.scatter(sub["rpv"], sub[met_col], s=10, alpha=0.4, label=ds_name)

    if met_col in LOG_Y_METRICS:
        ax.set_yscale("log")
        # use Spearman on raw values (rank-based, invariant to log)
        rho, p = stats.spearmanr(valid["rpv"], valid[met_col])
    else:
        rho, p = stats.spearmanr(valid["rpv"], valid[met_col])
    stars = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else ""
    log_tag = " (log y)" if met_col in LOG_Y_METRICS else ""
    ax.set_title(f"{METRIC_LABELS[met_col]}{log_tag}  rho={rho:.2f}{stars}")
    ax.set_xlabel(RPV_XLABEL)
    ax.set_ylabel(METRIC_LABELS[met_col])

    if len(valid["dataset"].unique()) <= 8:
        ax.legend(fontsize=6, markerscale=2)

plt.suptitle(f"RPV vs quality metrics (pooled, FR > {FR_THRESHOLD} Hz, n={len(df_hfr)})",
             fontsize=13)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "scatter_rpv_vs_metrics.png", dpi=150, bbox_inches="tight")
plt.show()

# ──────────────────────────────────────────────────────────────────────
# 5. Threshold suggestions
# ──────────────────────────────────────────────────────────────────────
print("\nComputing threshold suggestions...")

threshold_rows = []
for met_col in METRIC_COLS:
    higher_is_cleaner = met_col in HIGHER_IS_CLEANER
    for rpv_cut in RPV_CUTOFFS:
        sub = df_hfr[["rpv", met_col]].dropna()
        if len(sub) < 10:
            threshold_rows.append({
                "metric": METRIC_LABELS[met_col], "rpv_cutoff": rpv_cut,
                "threshold_median": np.nan, "threshold_logistic": np.nan,
                "accuracy": np.nan, "n_clean": 0, "n_dirty": 0,
            })
            continue

        is_clean = sub["rpv"] <= rpv_cut
        clean_vals = sub.loc[is_clean, met_col].values
        dirty_vals = sub.loc[~is_clean, met_col].values

        # Median-based threshold
        if len(clean_vals) >= 3 and len(dirty_vals) >= 3:
            thresh_median = (np.median(clean_vals) + np.median(dirty_vals)) / 2
        else:
            thresh_median = np.nan

        # Logistic regression threshold
        thresh_logistic = np.nan
        if len(clean_vals) >= 3 and len(dirty_vals) >= 3:
            from sklearn.linear_model import LogisticRegression
            X = sub[met_col].values.reshape(-1, 1)
            y = is_clean.astype(int).values
            lr = LogisticRegression(solver="lbfgs", max_iter=1000)
            lr.fit(X, y)
            if lr.coef_[0, 0] != 0:
                thresh_logistic = -lr.intercept_[0] / lr.coef_[0, 0]

        # Accuracy at median threshold
        if not np.isnan(thresh_median):
            if higher_is_cleaner:
                pred_clean = sub[met_col] >= thresh_median
            else:
                pred_clean = sub[met_col] <= thresh_median
            acc = np.mean(pred_clean == is_clean)
        else:
            acc = np.nan

        threshold_rows.append({
            "metric": METRIC_LABELS[met_col],
            "rpv_cutoff": rpv_cut,
            "threshold_median": thresh_median,
            "threshold_logistic": thresh_logistic,
            "accuracy": acc,
            "n_clean": int(is_clean.sum()),
            "n_dirty": int((~is_clean).sum()),
        })

thresh_df = pd.DataFrame(threshold_rows)
thresh_df.to_csv(OUTPUT_DIR / "suggested_thresholds.csv", index=False)

print(f"\nSuggested thresholds (pooled high-FR units, n={len(df_hfr)}):")
print(f"'Clean' = RPV <= cutoff, 'Dirty' = RPV > cutoff\n")
print(thresh_df.round(3).to_string(index=False))

# ──────────────────────────────────────────────────────────────────────
# 6. Threshold visualisation
# ──────────────────────────────────────────────────────────────────────
fig, axes = plt.subplots(len(METRIC_COLS), len(RPV_CUTOFFS), figsize=(14, 20))

for i, met_col in enumerate(METRIC_COLS):
    for j, rpv_cut in enumerate(RPV_CUTOFFS):
        ax = axes[i, j]
        sub = df_hfr[["rpv", met_col]].dropna()
        if len(sub) < 5:
            ax.text(0.5, 0.5, "insufficient data", transform=ax.transAxes, ha="center")
            continue

        is_clean = sub["rpv"] <= rpv_cut
        ax.scatter(sub.loc[is_clean, "rpv"], sub.loc[is_clean, met_col],
                   s=12, alpha=0.4, color="#2ecc71", label="clean")
        ax.scatter(sub.loc[~is_clean, "rpv"], sub.loc[~is_clean, met_col],
                   s=12, alpha=0.4, color="#e74c3c", label="dirty")

        ax.axvline(rpv_cut, color="gray", ls="--", lw=0.8)

        row = thresh_df[(thresh_df["metric"] == METRIC_LABELS[met_col]) &
                        (thresh_df["rpv_cutoff"] == rpv_cut)]
        if len(row) > 0:
            t_med = row["threshold_median"].values[0]
            t_log = row["threshold_logistic"].values[0]
            if not np.isnan(t_med):
                ax.axhline(t_med, color="#3498db", ls="-", lw=1.2,
                           label=f"median={t_med:.2f}")
            if not np.isnan(t_log):
                ax.axhline(t_log, color="#9b59b6", ls="-", lw=1.2,
                           label=f"logistic={t_log:.2f}")

        if i == 0:
            ax.set_title(f"RPV cutoff = {rpv_cut}", fontsize=11)
            ax.legend(fontsize=6, loc="best")
        if j == 0:
            ax.set_ylabel(METRIC_LABELS[met_col])
        if i == len(METRIC_COLS) - 1:
            ax.set_xlabel(RPV_XLABEL)

plt.suptitle(f"Metric thresholds at RPV cutoffs (pooled, FR > {FR_THRESHOLD} Hz, n={len(df_hfr)})",
             fontsize=13, y=1.01)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "threshold_scatter.png", dpi=150, bbox_inches="tight")
plt.show()

# ──────────────────────────────────────────────────────────────────────
# 7. Correlation by firing rate band
# ──────────────────────────────────────────────────────────────────────
print("\nCorrelation by firing rate band...")

fr_bands = [(0, 2, "<2"), (2, 5, "2-5"), (5, 10, "5-10"),
            (10, 20, "10-20"), (20, 50, "20-50"), (50, np.inf, "50+")]

fig, axes = plt.subplots(2, 3, figsize=(14, 8))
for idx, met_col in enumerate(METRIC_COLS):
    ax = axes[idx // 3, idx % 3]
    rhos, ns, labels = [], [], []
    for lo, hi, label in fr_bands:
        band = df[(df["firing_rate"] > lo) & (df["firing_rate"] <= hi) & ~noise_mask]
        sub = band[["rpv", met_col]].dropna()
        if len(sub) >= 10:
            rho, _ = stats.spearmanr(sub["rpv"], sub[met_col])
        else:
            rho = np.nan
        rhos.append(rho)
        ns.append(len(sub))
        labels.append(label)

    colors = ["#e74c3c" if n < 10 else "#3498db" for n in ns]
    ax.bar(range(len(labels)), rhos, color=colors)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels([f"{l}\n(n={n})" for l, n in zip(labels, ns)], fontsize=7)
    ax.set_ylabel("Spearman rho")
    ax.set_title(METRIC_LABELS[met_col])
    ax.axhline(0, color="gray", lw=0.5)
    ax.set_ylim(-1, 1)

plt.suptitle("Spearman rho (RPV vs metric) by firing rate band (pooled)", fontsize=13)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "correlation_by_fr_band.png", dpi=150, bbox_inches="tight")
plt.show()

# ──────────────────────────────────────────────────────────────────────
# 8. Combined-metric classification
# ──────────────────────────────────────────────────────────────────────
# Question: if we use isolation_distance + L-ratio + amplitude + presence_ratio
# as features, do we recover RPV-defined "clean vs dirty" labels well?
# Compare 5-fold CV ROC AUC of the combined logistic model against each
# single-metric classifier.
# ──────────────────────────────────────────────────────────────────────
print("\nCombined-metric classification (clean = RPV <= cutoff)...")

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_auc_score, roc_curve

COMBO_FEATURES = ["isolation_distance", "l_ratio", "amplitude", "presence_ratio"]
FEATURE_COLORS = {
    "isolation_distance": "#3498db",
    "l_ratio":            "#9b59b6",
    "amplitude":          "#e67e22",
    "presence_ratio":     "#1abc9c",
}

combo_rows = []
roc_data = {}  # rpv_cut -> dict of feature/"combo" -> (fpr, tpr, auc)

for rpv_cut in RPV_CUTOFFS:
    sub = df_hfr[["rpv"] + COMBO_FEATURES].dropna()
    if len(sub) < 20:
        print(f"  RPV cutoff {rpv_cut}: insufficient data ({len(sub)} units)")
        continue

    y = (sub["rpv"] <= rpv_cut).astype(int).values  # 1 = clean, 0 = dirty
    n_clean, n_dirty = int(y.sum()), int((1 - y).sum())
    if n_clean < 5 or n_dirty < 5:
        print(f"  RPV cutoff {rpv_cut}: too few in one class "
              f"(clean={n_clean}, dirty={n_dirty})")
        continue

    n_splits = min(5, n_clean, n_dirty)
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=0)
    pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("lr", LogisticRegression(solver="lbfgs", max_iter=1000)),
    ])

    roc_data[rpv_cut] = {}

    # ---- Combined classifier ----
    X = sub[COMBO_FEATURES].values
    proba = cross_val_predict(pipe, X, y, cv=cv, method="predict_proba")[:, 1]
    auc = roc_auc_score(y, proba)
    acc = np.mean((proba >= 0.5).astype(int) == y)
    fpr, tpr, _ = roc_curve(y, proba)
    roc_data[rpv_cut]["combo"] = (fpr, tpr, auc)
    combo_rows.append({
        "rpv_cutoff": rpv_cut,
        "feature": "COMBINED (" + "+".join(COMBO_FEATURES) + ")",
        "auc": auc, "accuracy": acc,
        "n_clean": n_clean, "n_dirty": n_dirty,
    })

    # Fit on full data once for interpretable standardised coefficients
    pipe.fit(X, y)
    coefs = pipe.named_steps["lr"].coef_[0]
    print(f"\nRPV cutoff {rpv_cut}: combined AUC={auc:.3f}, acc={acc:.3f} "
          f"(n_clean={n_clean}, n_dirty={n_dirty}, cv={n_splits}-fold)")
    for feat, c in zip(COMBO_FEATURES, coefs):
        print(f"    {feat:20s} std-coef = {c:+.3f}")

    # ---- Single-feature baselines ----
    for feat in COMBO_FEATURES:
        Xf = sub[[feat]].values
        proba_f = cross_val_predict(pipe, Xf, y, cv=cv, method="predict_proba")[:, 1]
        auc_f = roc_auc_score(y, proba_f)
        acc_f = np.mean((proba_f >= 0.5).astype(int) == y)
        fpr_f, tpr_f, _ = roc_curve(y, proba_f)
        roc_data[rpv_cut][feat] = (fpr_f, tpr_f, auc_f)
        combo_rows.append({
            "rpv_cutoff": rpv_cut,
            "feature": feat,
            "auc": auc_f, "accuracy": acc_f,
            "n_clean": n_clean, "n_dirty": n_dirty,
        })

combo_df = pd.DataFrame(combo_rows)
combo_df.to_csv(OUTPUT_DIR / "combined_classification.csv", index=False)

print("\nClassification performance (5-fold CV):")
print(combo_df.round(3).to_string(index=False))

# ---- ROC curves ----
if roc_data:
    n_cuts = len(roc_data)
    fig, axes = plt.subplots(1, n_cuts, figsize=(5 * n_cuts, 4.5), squeeze=False)
    axes = axes[0]
    for ax, (rpv_cut, curves) in zip(axes, sorted(roc_data.items())):
        for feat in COMBO_FEATURES:
            fpr, tpr, auc = curves[feat]
            ax.plot(fpr, tpr, color=FEATURE_COLORS[feat], lw=1.2, alpha=0.85,
                    label=f"{feat} (AUC={auc:.2f})")
        fpr, tpr, auc = curves["combo"]
        ax.plot(fpr, tpr, color="black", lw=2.4,
                label=f"COMBINED (AUC={auc:.2f})")
        ax.plot([0, 1], [0, 1], color="gray", ls="--", lw=0.8)
        ax.set_xlabel("False positive rate")
        ax.set_ylabel("True positive rate")
        ax.set_title(f"RPV cutoff = {rpv_cut}")
        ax.legend(fontsize=7, loc="lower right")
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1.02)

    plt.suptitle(
        f"Predicting clean (RPV <= cutoff) from combined quality metrics\n"
        f"(pooled high-FR units, n={len(df_hfr)}, 5-fold CV logistic regression)",
        fontsize=12,
    )
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "roc_combined_classifier.png", dpi=150, bbox_inches="tight")
    plt.show()

    # ---- AUC bar chart ----
    fig, ax = plt.subplots(figsize=(7, 4))
    width = 0.18
    x = np.arange(len(roc_data))
    cuts_sorted = sorted(roc_data.keys())
    for i, feat in enumerate(COMBO_FEATURES):
        aucs = [roc_data[c][feat][2] for c in cuts_sorted]
        ax.bar(x + (i - 2) * width, aucs, width, color=FEATURE_COLORS[feat], label=feat)
    aucs_combo = [roc_data[c]["combo"][2] for c in cuts_sorted]
    ax.bar(x + 2 * width, aucs_combo, width, color="black", label="COMBINED")
    ax.axhline(0.5, color="gray", lw=0.8, ls="--")
    ax.set_xticks(x)
    ax.set_xticklabels([f"RPV <= {c}" for c in cuts_sorted])
    ax.set_ylabel("ROC AUC (5-fold CV)")
    ax.set_ylim(0.4, 1.0)
    ax.set_title("Single-metric vs combined-metric classification of RPV labels")
    ax.legend(fontsize=8, loc="lower right")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "auc_combined_vs_single.png", dpi=150, bbox_inches="tight")
    plt.show()

# ──────────────────────────────────────────────────────────────────────
# 9. Optimal joint AND-thresholds (Youden's J)
# ──────────────────────────────────────────────────────────────────────
# Find per-metric thresholds that, applied jointly with AND, best predict
# RPV-defined "clean vs dirty". Optimisation criterion: Youden's J =
# sensitivity + specificity − 1, which balances false positives and false
# negatives. Search method: coordinate descent on per-metric quantile grids,
# initialised from each metric's individually-optimal threshold.
#
# A unit is predicted CLEAN iff:
#     isolation_distance >= T_iso  AND  L_ratio        <= T_lratio
# AND amplitude          >= T_amp  AND  presence_ratio >= T_pres
# ──────────────────────────────────────────────────────────────────────
print("\nOptimising joint AND-thresholds (Youden's J)...")


def _confusion(y_true_clean, y_pred_clean):
    """Return (TP, FP, FN, TN) where positive = clean."""
    tp = int(np.sum(y_pred_clean & y_true_clean))
    fp = int(np.sum(y_pred_clean & ~y_true_clean))
    fn = int(np.sum(~y_pred_clean & y_true_clean))
    tn = int(np.sum(~y_pred_clean & ~y_true_clean))
    return tp, fp, fn, tn


def _metrics_from_conf(tp, fp, fn, tn):
    sens = tp / (tp + fn) if (tp + fn) else 0.0
    spec = tn / (tn + fp) if (tn + fp) else 0.0
    acc = (tp + tn) / (tp + fp + fn + tn) if (tp + fp + fn + tn) else 0.0
    return sens, spec, acc, sens + spec - 1.0  # last = Youden's J


def _apply_joint(X, thresholds, higher_is_cleaner):
    """X: (n_samples, n_features) ndarray. thresholds: list of n_features.
    higher_is_cleaner: list of bools. Returns boolean array (True = clean)."""
    pred = np.ones(X.shape[0], dtype=bool)
    for j in range(X.shape[1]):
        if higher_is_cleaner[j]:
            pred &= X[:, j] >= thresholds[j]
        else:
            pred &= X[:, j] <= thresholds[j]
    return pred


def _best_single_threshold(values, y_clean, higher_is_cleaner):
    """Best single-metric threshold by Youden's J on dense quantile grid."""
    grid = np.unique(np.quantile(values, np.linspace(0.0, 1.0, 101)))
    best_j, best_t = -np.inf, float(np.median(values))
    for t in grid:
        if higher_is_cleaner:
            pred = values >= t
        else:
            pred = values <= t
        tp, fp, fn, tn = _confusion(y_clean, pred)
        _, _, _, j = _metrics_from_conf(tp, fp, fn, tn)
        if j > best_j:
            best_j, best_t = j, float(t)
    return best_t, best_j


def _coord_descent_joint(
    X, y_clean, higher_is_cleaner, init_thresholds, max_passes=20
):
    """Cycle through features; for each, sweep its quantile grid holding
    others fixed; keep the threshold that maximises joint Youden's J."""
    thresholds = list(init_thresholds)
    n_feat = X.shape[1]
    best_j = _metrics_from_conf(*_confusion(y_clean, _apply_joint(X, thresholds, higher_is_cleaner)))[3]
    for _ in range(max_passes):
        improved = False
        for j_feat in range(n_feat):
            grid = np.unique(np.quantile(X[:, j_feat], np.linspace(0.0, 1.0, 101)))
            for t in grid:
                trial = list(thresholds)
                trial[j_feat] = float(t)
                pred = _apply_joint(X, trial, higher_is_cleaner)
                tp, fp, fn, tn = _confusion(y_clean, pred)
                _, _, _, j_val = _metrics_from_conf(tp, fp, fn, tn)
                if j_val > best_j + 1e-9:
                    best_j = j_val
                    thresholds[j_feat] = float(t)
                    improved = True
        if not improved:
            break
    return thresholds, best_j


HIGHER_IS_CLEANER_LIST = [m in HIGHER_IS_CLEANER for m in COMBO_FEATURES]

joint_rows = []
joint_results = {}  # rpv_cut -> dict

for rpv_cut in RPV_CUTOFFS:
    sub = df_hfr[["rpv"] + COMBO_FEATURES].dropna()
    if len(sub) < 20:
        continue
    y_clean = (sub["rpv"].values <= rpv_cut)
    n_clean, n_dirty = int(y_clean.sum()), int((~y_clean).sum())
    if n_clean < 5 or n_dirty < 5:
        continue

    X = sub[COMBO_FEATURES].values

    # ---- 5-fold CV: optimise on train, evaluate on held-out test ----
    n_splits = min(5, n_clean, n_dirty)
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=0)
    fold_test_metrics = []  # rows: (sens, spec, acc, J)
    for train_idx, test_idx in cv.split(X, y_clean):
        X_tr, y_tr = X[train_idx], y_clean[train_idx]
        X_te, y_te = X[test_idx], y_clean[test_idx]
        if y_tr.sum() < 2 or (~y_tr).sum() < 2:
            continue
        init_t_fold = [
            _best_single_threshold(X_tr[:, j], y_tr, HIGHER_IS_CLEANER_LIST[j])[0]
            for j in range(len(COMBO_FEATURES))
        ]
        joint_t_fold, _ = _coord_descent_joint(
            X_tr, y_tr, HIGHER_IS_CLEANER_LIST, init_t_fold
        )
        pred_te = _apply_joint(X_te, joint_t_fold, HIGHER_IS_CLEANER_LIST)
        tp, fp, fn, tn = _confusion(y_te, pred_te)
        fold_test_metrics.append(_metrics_from_conf(tp, fp, fn, tn))

    fold_test_metrics = np.array(fold_test_metrics)  # (n_folds, 4)
    cv_mean = fold_test_metrics.mean(axis=0)
    cv_std = fold_test_metrics.std(axis=0)

    # ---- Final fit on full data → reported thresholds ----
    init_t = [
        _best_single_threshold(X[:, j], y_clean, HIGHER_IS_CLEANER_LIST[j])[0]
        for j in range(len(COMBO_FEATURES))
    ]
    final_t, _ = _coord_descent_joint(X, y_clean, HIGHER_IS_CLEANER_LIST, init_t)
    pred_final = _apply_joint(X, final_t, HIGHER_IS_CLEANER_LIST)
    tp_f, fp_f, fn_f, tn_f = _confusion(y_clean, pred_final)
    sens_f, spec_f, acc_f, j_f = _metrics_from_conf(tp_f, fp_f, fn_f, tn_f)

    joint_results[rpv_cut] = {
        "thresholds": dict(zip(COMBO_FEATURES, final_t)),
        "cv_mean": cv_mean, "cv_std": cv_std, "n_splits": int(n_splits),
        "final": dict(sens=sens_f, spec=spec_f, acc=acc_f, j=j_f,
                      tp=tp_f, fp=fp_f, fn=fn_f, tn=tn_f),
        "n_clean": n_clean, "n_dirty": n_dirty,
    }

    print(f"\nRPV cutoff = {rpv_cut}   "
          f"(n_clean={n_clean}, n_dirty={n_dirty}, {n_splits}-fold CV)")
    print(f"  Optimised AND-rule thresholds (final fit on full data):")
    for feat, t in zip(COMBO_FEATURES, final_t):
        op = ">=" if feat in HIGHER_IS_CLEANER else "<="
        print(f"    {feat:20s} {op} {t:>10.3f}")
    print(f"  Test-set performance (mean ± std across folds):")
    print(f"    sensitivity   {cv_mean[0]:.3f} ± {cv_std[0]:.3f}")
    print(f"    specificity   {cv_mean[1]:.3f} ± {cv_std[1]:.3f}")
    print(f"    accuracy      {cv_mean[2]:.3f} ± {cv_std[2]:.3f}")
    print(f"    Youden's J    {cv_mean[3]:+.3f} ± {cv_std[3]:.3f}")

    joint_rows.append({
        "rpv_cutoff": rpv_cut,
        **{f"T_{feat}": final_t[i] for i, feat in enumerate(COMBO_FEATURES)},
        "cv_sensitivity_mean": cv_mean[0], "cv_sensitivity_std": cv_std[0],
        "cv_specificity_mean": cv_mean[1], "cv_specificity_std": cv_std[1],
        "cv_accuracy_mean":    cv_mean[2], "cv_accuracy_std":    cv_std[2],
        "cv_youden_j_mean":    cv_mean[3], "cv_youden_j_std":    cv_std[3],
        "n_splits": int(n_splits),
        "n_clean": n_clean, "n_dirty": n_dirty,
    })

joint_df = pd.DataFrame(joint_rows)
joint_df.to_csv(OUTPUT_DIR / "joint_thresholds.csv", index=False)

print("\n" + "=" * 60)
print("Joint AND-rule threshold summary")
print("=" * 60)
print(joint_df.round(3).to_string(index=False))

# ---- Plot: per metric, distributions of clean vs dirty + final threshold ----
if joint_results:
    n_cuts = len(joint_results)
    fig, axes = plt.subplots(
        len(COMBO_FEATURES), n_cuts,
        figsize=(4.2 * n_cuts, 2.6 * len(COMBO_FEATURES)),
        squeeze=False,
    )
    cuts_sorted = sorted(joint_results.keys())
    for col, rpv_cut in enumerate(cuts_sorted):
        sub = df_hfr[["rpv"] + COMBO_FEATURES].dropna()
        y_clean = sub["rpv"].values <= rpv_cut
        thr = joint_results[rpv_cut]["thresholds"]
        cv_mean = joint_results[rpv_cut]["cv_mean"]
        cv_std = joint_results[rpv_cut]["cv_std"]
        for row, feat in enumerate(COMBO_FEATURES):
            ax = axes[row, col]
            vals = sub[feat].values
            v_clean = vals[y_clean]
            v_dirty = vals[~y_clean]
            lo, hi = np.nanpercentile(vals, [1, 99])
            bins = np.linspace(lo, hi, 40)
            ax.hist(v_clean, bins=bins, color="#2ecc71", alpha=0.55,
                    label=f"clean (n={len(v_clean)})")
            ax.hist(v_dirty, bins=bins, color="#e74c3c", alpha=0.55,
                    label=f"dirty (n={len(v_dirty)})")
            ax.axvline(thr[feat], color="black", lw=1.6,
                       label=f"T={thr[feat]:.2f}")
            if row == 0:
                ax.set_title(
                    f"RPV ≤ {rpv_cut}\n"
                    f"CV J={cv_mean[3]:+.2f}±{cv_std[3]:.2f}  "
                    f"acc={cv_mean[2]:.2f}±{cv_std[2]:.2f}",
                    fontsize=10,
                )
            if col == 0:
                ax.set_ylabel(METRIC_LABELS[feat], fontsize=9)
            ax.legend(fontsize=6, loc="upper right")
            ax.tick_params(labelsize=7)

    plt.suptitle(
        "Joint AND-rule thresholds (5-fold CV; black line = final fit)",
        fontsize=12,
    )
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "joint_thresholds_distributions.png",
                dpi=150, bbox_inches="tight")
    plt.show()

# ──────────────────────────────────────────────────────────────────────
# 8b. Summary: combined AND-rule as a replacement for RPV
# ──────────────────────────────────────────────────────────────────────
# If we used the optimised combined AND-rule INSTEAD of RPV to label
# clean/dirty units, how would the labels compare? Confusion matrices and
# breakdown of which units would be kept/rejected differently.
# ──────────────────────────────────────────────────────────────────────
print("\n" + "=" * 64)
print("Summary: replacing RPV with the optimised combined AND-rule")
print("=" * 64)

for rpv_cut in sorted(joint_results.keys()):
    r = joint_results[rpv_cut]
    f = r["final"]
    cv_mean, cv_std = r["cv_mean"], r["cv_std"]
    n_total = r["n_clean"] + r["n_dirty"]
    print(f"\nRPV cutoff = {rpv_cut}   "
          f"(N={n_total}: {r['n_clean']} RPV-clean, {r['n_dirty']} RPV-dirty)")
    print(f"  AND-rule (final fit on full data):")
    print(f"    correctly kept clean:    {f['tp']:>4d} / {r['n_clean']:<4d}  "
          f"({100*f['sens']:5.1f}%)   ← sensitivity")
    print(f"    correctly rejected dirty: {f['tn']:>4d} / {r['n_dirty']:<4d}  "
          f"({100*f['spec']:5.1f}%)   ← specificity")
    print(f"    overall agreement:        {f['tp']+f['tn']:>4d} / {n_total:<4d}  "
          f"({100*f['acc']:5.1f}%)")
    print(f"  Errors:")
    print(f"    'leaks through' (kept dirty):   {f['fp']:>4d} / {r['n_dirty']:<4d}  "
          f"({100*(1-f['spec']):5.1f}%)")
    print(f"    'over-rejects' (drops clean):   {f['fn']:>4d} / {r['n_clean']:<4d}  "
          f"({100*(1-f['sens']):5.1f}%)")
    print(f"  Held-out {r['n_splits']}-fold CV:")
    print(f"    agreement  = {100*cv_mean[2]:5.1f}% ± {100*cv_std[2]:.1f}%")
    print(f"    Youden's J = {cv_mean[3]:+.3f} ± {cv_std[3]:.3f}")

# ---- Confusion-matrix figure ----
if joint_results:
    cuts_sorted = sorted(joint_results.keys())
    n_cuts = len(cuts_sorted)
    fig, axes = plt.subplots(1, n_cuts, figsize=(4.2 * n_cuts, 4.0), squeeze=False)
    axes = axes[0]
    for ax, rpv_cut in zip(axes, cuts_sorted):
        r = joint_results[rpv_cut]
        f = r["final"]
        cm = np.array([[f["tp"], f["fp"]],
                       [f["fn"], f["tn"]]], dtype=int)
        # Column-normalised (each column = one ground-truth class)
        col_norm = np.array([[r["n_clean"], r["n_dirty"]],
                             [r["n_clean"], r["n_dirty"]]], dtype=float)
        cm_pct = cm / np.where(col_norm > 0, col_norm, 1)
        im = ax.imshow(cm_pct, cmap="Blues", vmin=0, vmax=1, aspect="equal")
        ax.set_xticks([0, 1])
        ax.set_xticklabels(["RPV\nCLEAN", "RPV\nDIRTY"], fontsize=10)
        ax.set_yticks([0, 1])
        ax.set_yticklabels(["AND-rule\nKEEP", "AND-rule\nREJECT"], fontsize=10)
        for i in range(2):
            for j in range(2):
                count = cm[i, j]
                pct = cm_pct[i, j]
                color = "white" if pct > 0.55 else "black"
                ax.text(
                    j, i, f"{count}\n({pct*100:.0f}%)",
                    ha="center", va="center", color=color, fontsize=12,
                )
        ax.set_title(
            f"RPV ≤ {rpv_cut}\n"
            f"agreement = {100*f['acc']:.1f}%   J = {f['j']:+.2f}\n"
            f"CV: {100*r['cv_mean'][2]:.1f}% ± {100*r['cv_std'][2]:.1f}%",
            fontsize=10,
        )

    plt.suptitle(
        "If we replaced RPV with the optimised combined AND-rule:\n"
        "how do the labels compare?  (column-normalised; correct on diagonal)",
        fontsize=12,
    )
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "and_rule_vs_rpv_confusion.png",
                dpi=150, bbox_inches="tight")
    plt.show()

    # ---- Performance bar chart (held-out CV mean ± std across folds) ----
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    width = 0.20
    x = np.arange(len(cuts_sorted))

    # cv_mean / cv_std rows: [sens, spec, acc, J]
    cv_means = np.array([joint_results[c]["cv_mean"] for c in cuts_sorted])
    cv_stds  = np.array([joint_results[c]["cv_std"]  for c in cuts_sorted])
    n_folds  = np.array([joint_results[c]["n_splits"] for c in cuts_sorted])
    cv_sems  = cv_stds / np.sqrt(n_folds)[:, None]  # SEM, broadcast over 4 metrics

    metric_specs = [
        ("sensitivity (clean kept)",     0, "#2ecc71", -1.5),
        ("specificity (dirty rejected)", 1, "#3498db", -0.5),
        ("accuracy (agreement)",         2, "#2c3e50",  0.5),
        ("Youden's J",                   3, "#e67e22",  1.5),
    ]
    for label, idx, color, offset in metric_specs:
        ax.bar(
            x + offset * width,
            cv_means[:, idx],
            width,
            yerr=cv_sems[:, idx],          # SEM error bars (use cv_stds for SD)
            color=color,
            label=label,
            capsize=3,
            error_kw=dict(lw=0.9, ecolor="black"),
        )

    ax.axhline(0, color="gray", lw=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels(
        [f"RPV ≤ {c}\n({n}-fold)" for c, n in zip(cuts_sorted, n_folds)]
    )
    ax.set_ylim(-0.05, 1.05)
    ax.set_ylabel("score (held-out CV mean)")
    ax.set_title(
        "Combined AND-rule performance vs RPV labels\n"
        "bars = mean across CV folds, error bars = SEM"
    )
    ax.legend(fontsize=8, loc="lower right")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "and_rule_vs_rpv_summary_bars.png",
                dpi=150, bbox_inches="tight")
    plt.show()

# ──────────────────────────────────────────────────────────────────────
# Done
# ──────────────────────────────────────────────────────────────────────
df.to_csv(OUTPUT_DIR / "all_units.csv", index=False)
df_hfr.to_csv(OUTPUT_DIR / "high_fr_units.csv", index=False)

print(f"\nAll outputs saved to {OUTPUT_DIR.resolve()}")
print("Done.")
