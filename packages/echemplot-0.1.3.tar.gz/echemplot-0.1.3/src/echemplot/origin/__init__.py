"""Origin adapter subpackage.

`originpro` is shipped with OriginLab's embedded Python; it is NOT listed as a
PyPI dependency. Importing this subpackage outside Origin is fine — calling
:func:`push_to_origin` (which routes through :func:`_require_originpro`) is
what raises ``ImportError`` at runtime.

The package is split into three small modules so the helpers can be unit
tested against a mocked ``originpro`` module without importing the top-level
:func:`push_to_origin` orchestrator:

* :mod:`._worksheets` — DataFrame → Origin worksheet helpers.
* :mod:`._plots` — template-backed graph creation.
* :mod:`.templates` — the bundled ``.otpu`` asset directory.

For the end-user "default install only" path inside Origin, this module
also exposes :func:`launch_gui`, a thin wrapper around
:func:`echemplot.gui.launch_gui` that injects an ``on_complete``
callback routing the loaded cells through :func:`push_to_origin`. That
keeps the Tk view (in :mod:`echemplot.gui.tk_app`) free of any
``originpro`` coupling.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

from echemplot.origin._plots import (
    compute_global_ranges,
    create_cell_plots,
    create_comparison_plots,
)
from echemplot.origin._worksheets import write_cell_sheets, write_stat_table

if TYPE_CHECKING:
    from matplotlib.figure import Figure

    from echemplot.core.cell import Cell


def _require_originpro() -> object:
    try:
        import originpro as op
    except ImportError as e:
        raise ImportError(
            "echemplot.origin requires `originpro`, which is provided by "
            "OriginLab's embedded Python. Run this module from Origin's Python."
        ) from e
    return op


_DEFAULT_SG_WINDOW = 21
_DEFAULT_SG_POLYORDER = 2


def push_to_origin(
    cells: Sequence[Cell],
    *,
    project_path: str | None = None,
    stat_cycles: Sequence[int] = (10, 50),
    sg_window: int = _DEFAULT_SG_WINDOW,
    sg_polyorder: int = _DEFAULT_SG_POLYORDER,
) -> None:
    """Populate the current Origin project with per-cell sheets + plots + stats.

    For every cell in ``cells`` this creates three worksheets
    (``{cell.name}_chdis``, ``{cell.name}_cycle``, ``{cell.name}_dqdv``)
    populated from ``cell.chdis_df``, ``cell.cap_df``, and ``cell.dqdv_df``
    respectively, then three graphs instantiated from the v2.01 ``.otpu``
    templates (``charge_discharge.otpu``, ``cycle_efficiency.otpu``,
    ``dqdv.otpu``). When ``len(cells) > 1`` a further three overlay-style
    comparison graphs are produced. Finally a ``stat_table`` worksheet is
    written from :func:`echemplot.core.stats.stat_table`.

    Parameters
    ----------
    cells
        One or more :class:`echemplot.core.cell.Cell` instances.
    project_path
        If provided, ``op.open(project_path)`` is called at the start and
        ``op.save(project_path)`` at the end. When ``None`` the function
        operates on the current in-memory project without touching disk.
    stat_cycles
        Cycle numbers forwarded to
        :func:`echemplot.core.stats.stat_table` as ``target_cycles``.
    sg_window, sg_polyorder
        Savitzky-Golay parameters for the dQ/dV worksheet. At the defaults
        (``21`` / ``2``) the cached :attr:`Cell.dqdv_df` is reused verbatim;
        any override triggers a one-off :func:`echemplot.core.dqdv.get_dqdv_df`
        recompute per cell so the worksheet values reflect the caller's
        choice. ``Cell`` instances are not mutated. ``sg_window`` must be a
        positive odd integer.

    Raises
    ------
    ImportError
        From :func:`_require_originpro` when ``originpro`` is not available
        (i.e. when the caller is not running inside Origin).
    ValueError
        If ``sg_window`` is not a positive odd integer.
    FileNotFoundError
        When a required ``.otpu`` template cannot be located under the
        package ``templates/`` directory or
        ``$ECHEMPLOT_ORIGIN_TEMPLATE_DIR``. The message names both remediation
        paths.
    """
    if sg_window < 1 or sg_window % 2 == 0:
        raise ValueError(f"sg_window must be a positive odd integer, got {sg_window}")

    op = _require_originpro()

    # Import inside the function so users who only ever call the helpers
    # directly don't pay the stats-import cost. ``stat_table`` pulls in
    # scipy.integrate at import time.
    from echemplot.core.stats import stat_table

    # Only recompute when the caller actually wants non-default SG
    # parameters; at the defaults the cached ``Cell.dqdv_df`` suffices and
    # we avoid paying the scipy interp/savgol cost a second time.
    sg_is_default = sg_window == _DEFAULT_SG_WINDOW and sg_polyorder == _DEFAULT_SG_POLYORDER
    if not sg_is_default:
        from echemplot.core.dqdv import get_dqdv_df

    if project_path is not None:
        op.open(project_path)  # type: ignore[attr-defined]

    # Compute one shared axis range over the full cell sequence, applied
    # uniformly to every per-cell graph AND the comparison overlays. With
    # a single cell this collapses to "autoscale to that cell's data";
    # with multiple cells every graph shares a directly-comparable scale
    # (issue #61).
    ranges = compute_global_ranges(cells)

    per_cell_sheets: list[dict[str, object]] = []
    for cell in cells:
        if sg_is_default:
            sheets = write_cell_sheets(op, cell)
        else:
            dqdv_df = get_dqdv_df(
                cell.chdis_df,
                window_length=sg_window,
                polyorder=sg_polyorder,
                column_lang=cell.column_lang,
            )
            sheets = write_cell_sheets(op, cell, dqdv_df=dqdv_df)
        create_cell_plots(op, cell, sheets, ranges=ranges)
        per_cell_sheets.append(sheets)

    if len(cells) > 1:
        create_comparison_plots(op, cells, per_cell_sheets, ranges=ranges)

    stat_df = stat_table(cells, target_cycles=list(stat_cycles))
    write_stat_table(op, stat_df)

    if project_path is not None:
        op.save(project_path)  # type: ignore[attr-defined]


def launch_gui(
    *,
    project_path: str | None = None,
    stat_cycles: Sequence[int] = (10, 50),
) -> None:
    """Launch the Tk GUI from inside Origin and push results to the project.

    This is the one-liner entry point for the "Origin default install only"
    workflow: after ``pip install echemplot[origin]`` inside Origin's
    embedded Python, ``from echemplot.origin import launch_gui;
    launch_gui()`` brings up the existing Tk directory picker, and Run
    forwards the loaded :class:`Cell` list to :func:`push_to_origin` —
    populating the active Origin project with worksheets, template-backed
    graphs, and a ``stat_table`` sheet without writing any PNG/CSV
    intermediates.

    The Tk GUI is launched with ``origin_mode=True``, which greys out
    the options that have no effect on the Origin push path (plot-kind
    checkboxes, cycles entry, and the voltage/capacity/dQ-dV range
    entries) and shows an inline note; only ``SG window_length`` stays
    editable because it flows into the dQ/dV worksheet written by
    :func:`push_to_origin`.

    The originpro check runs **before** Tk is constructed so a missing
    embedded-Python build fails fast with the canonical
    :func:`_require_originpro` message rather than after the user has
    spent time selecting directories.

    Parameters
    ----------
    project_path
        Forwarded to :func:`push_to_origin` for each Run. ``None`` (the
        default) operates on the in-memory project.
    stat_cycles
        Forwarded to :func:`push_to_origin` as ``stat_cycles``.

    Raises
    ------
    ImportError
        From :func:`_require_originpro` when ``originpro`` is not
        importable (i.e. not running inside Origin), or from
        ``import tkinter`` when the host Python lacks ``_tkinter`` (some
        older OriginLab releases — see issue #16). Both errors propagate
        unmodified so the failure mode is obvious from the traceback.
    """
    _require_originpro()
    # Imported lazily so this module stays importable on hosts without
    # Tk / matplotlib (the standalone ``push_to_origin`` path needs
    # neither). ``Figure`` is annotation-only; the runtime ``plt.close``
    # call below resolves it via ``matplotlib.pyplot``.
    from echemplot.gui import launch_gui as _launch_tk_gui

    def _push(cells: Sequence[Cell], figures: Sequence[Figure], sg_window: int) -> None:
        # ``sg_window`` is forwarded so the dQ/dV worksheet reflects the
        # value the user typed in the GUI. ``Cell.dqdv_df`` is cached at
        # defaults and can't surface per-run overrides on its own (see
        # issue #60), so ``push_to_origin`` recomputes the frame when the
        # caller supplies a non-default window.
        push_to_origin(
            cells,
            project_path=project_path,
            stat_cycles=stat_cycles,
            sg_window=sg_window,
        )
        # Close the figures the controller built. The Origin path
        # bypasses ``_show_figure`` (which would otherwise own the close
        # via ``WM_DELETE_WINDOW``), so without an explicit close a long
        # session of repeated Run clicks accumulates figures in pyplot's
        # global registry and eventually trips ``max_open_warning``.
        import matplotlib.pyplot as plt

        for fig in figures:
            plt.close(fig)

    _launch_tk_gui(on_complete=_push, origin_mode=True)


__all__ = [
    "_require_originpro",
    "launch_gui",
    "push_to_origin",
]
