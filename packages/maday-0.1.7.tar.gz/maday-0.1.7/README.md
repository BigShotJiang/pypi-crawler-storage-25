# Maday - Android Code Snippets Generator

A Python package that provides 18 ready-to-use Android development code snippets. Easily generate, copy, and reference Android code for various UI components and functionalities.

## Features

✨ **18 Android Code Snippets** including:
- Alert Dialog
- TimePicker & DatePicker
- Radio Button, CheckBox, ToggleButton
- Progress Bar
- AutoComplete TextView
- Shape Drawing
- Spinner
- Shared Preferences
- Intent (with examples)
- Popup Menu & Context Menu
- Animation (Basic & Advanced)
- SQLite Database
- Custom Toast Messages

Each snippet includes:
- ✅ Complete XML layout files
- ✅ Full Kotlin/Java code
- ✅ File paths and locations
- ✅ Ready-to-copy format

## Installation

Install from PyPI:
```bash
pip install maday
```

Or install from source:
```bash
git clone https://github.com/yourusername/maday.git
cd maday
pip install -e .
```

## Quick Start

### Interactive Menu (Recommended)
```bash
python -c "from maday import android_snippets; android_snippets()"
```

Or in Python:
```python
from maday import android_snippets

# Launch the interactive menu
android_snippets()

# Follow the prompts to select a snippet
# Your selected code will be saved to output.txt
```

### Quick Examples

```python
from maday import hello_world, show_help

# Get info about available commands
show_help()

# Quick test
print(hello_world())
```

## Usage

1. **Run the Android Snippets Generator:**
   ```bash
   python -c "from maday import android_snippets; android_snippets()"
   ```

2. **Select a snippet** (1-18) from the menu
3. **Copy the generated code** from `output.txt`
4. **Paste into your Android project**

## Snippets Available

| # | Snippet | Files |
|---|---------|-------|
| 1 | Alert Dialog | activity_main.xml, MainActivity.kt |
| 2 | TimePicker | activity_main.xml, MainActivity.kt |
| 3 | Date Picker | activity_main.xml, MainActivity.kt |
| 4 | Radio Button | activity_main.xml, MainActivity.kt |
| 5 | Check Box | activity_main.xml, MainActivity.kt |
| 6 | Toggle Button | activity_main.xml, MainActivity.kt |
| 7 | Progress Bar | activity_main.xml, MainActivity.kt |
| 8 | AutoComplete TextView | activity_main.xml, MainActivity.kt |
| 9 | Shape Drawing | activity_main.xml, MainActivity.kt |
| 10 | Spinner | activity_main.xml, MainActivity.kt |
| 11 | Shared Preferences | activity_main.xml, MainActivity.kt |
| 12 | Intent | activity_main.xml, MainActivity.kt, activity_second.xml, SecondActivity.kt |
| 13 | Popup Menu | activity_main.xml, popup_menu.xml, MainActivity.kt |
| 14 | Context Menu | activity_main.xml, context_menu.xml, MainActivity.kt |
| 15 | Animation (Basic) | activity_main.xml, MainActivity.kt |
| 16 | Animation (Advanced) | activity_main.xml, MainActivity.kt, 8 Animation XML files |
| 17 | SQLite Database | activity_main.xml, DBHelper.kt, MainActivity.kt |
| 18 | Toast Messages | activity_main.xml, custom_toast.xml, MainActivity.kt |

## Development

Install development dependencies:
```bash
pip install -e ".[dev]"
```

Run tests:
```bash
pytest
```

## Example Output

When you select a snippet, you'll get:

```
================================================================================
1. ALERT DIALOG
================================================================================

FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    ...
    
FILE: MainActivity.kt
================================================================================
package com.example.alertdialogapp
import android.os.Bundle
...
```

Each file is clearly labeled with its path and purpose.

## Tips

- 💡 All code is production-ready
- 📋 Copy directly from `output.txt`
- 🔗 Each snippet is self-contained
- 🎨 Customizable for your project
- ⚙️ Works with latest Android API levels

## Requirements

- Python 3.8+
- No external dependencies!

## License

MIT License - see LICENSE file for details

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

For issues, suggestions, or questions, please visit the [GitHub Issues](https://github.com/yourusername/maday/issues) page.

---

Made with ❤️ for Android Developers
