"""
Main module for maday package

This module contains utility functions and helpers for the maday package.
For Android snippet generation, use: maday.android_snippets()
"""


def hello_world():
    """Example function"""
    return "Hello from maday!"


def show_help():
    """Show available maday commands"""
    help_text = """
    ╔════════════════════════════════════════════════╗
    ║          MADAY - Code Snippets Generator      ║
    ║              Available Commands               ║
    ╚════════════════════════════════════════════════╝
    
    1. Android Code Snippets:
       >>> from maday import android_snippets
       >>> android_snippets()
       
       This will show 18 Android development snippets including:
       - Alert Dialog, TimePicker, DatePicker
       - Radio Button, CheckBox, ToggleButton
       - Progress Bar, AutoComplete, Shape Drawing
       - Spinner, Shared Preferences, Intent
       - Popup Menu, Context Menu, Animation
       - SQLite Database, Toast Messages
       
    2. Hello World:
       >>> from maday import hello_world
       >>> hello_world()
    
    For more info, visit: https://github.com/yourusername/maday
    """
    print(help_text)


# Add your code below:
