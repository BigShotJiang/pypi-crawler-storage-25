"""
Allow the maday package to be run as a module: python -m maday
"""
from maday.cli import cli_main

if __name__ == "__main__":
    cli_main()
