#!/usr/bin/env python
"""
Command-line interface for maday Android Snippets Generator

This script can be run directly from the command line:
    python -m maday.cli
    or
    maday-snippets (after pip install)
"""

import sys
from .android_snippets import main


def cli_main():
    """Main CLI entry point"""
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nExiting... Thanks for using maday!")
        sys.exit(0)
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    cli_main()
