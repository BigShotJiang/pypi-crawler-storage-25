"""
Android Code Snippets Generator
A tool to generate Android development code snippets in various categories
"""
import os

ANDROID_SNIPPETS = {
    "1": {
        "name": "Alert Dialog",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
1. ALERT DIALOG
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    tools:context=".MainActivity">
    <Button
        android:id="@+id/exitButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Exit App"
        android:textSize="20sp"
        android:padding="10dp" />
</LinearLayout>

LOCATION: java/com/example/alertdialogapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
package com.example.alertdialogapp
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    private lateinit var exitButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        exitButton = findViewById(R.id.exitButton)
        exitButton.setOnClickListener {
            exit(it)
        }
    }
    fun exit(view: View) {
        val alert = AlertDialog.Builder(this)
        alert.setTitle("Confirm Exit")
        alert.setIcon(R.drawable.ic_launcher_foreground)
        alert.setMessage("Are you sure you want to exit?")
        alert.setCancelable(false)
        alert.setPositiveButton("Yes") { _, _ ->
            Toast.makeText(this,"Exiting App",Toast.LENGTH_LONG).show()
            finish()
        }
        alert.setNegativeButton("No") { _, _ ->
            Toast.makeText(this,"You clicked on No",Toast.LENGTH_LONG).show()
        }
        alert.setNeutralButton("Cancel") { _, _ ->
            Toast.makeText(this,"You clicked on Cancel",Toast.LENGTH_LONG).show()
        }
        alert.create().show()
    }
}
"""
    },
    "2": {
        "name": "TimePicker",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
2. TIMEPICKER
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="20dp">
    <!-- Button to show XML TimePicker -->
    <Button
        android:id="@+id/showButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Show XML TimePicker" />
    <!-- Button to open TimePickerDialog -->
    <Button
        android:id="@+id/dialogButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="Open Dialog TimePicker" />
    <!-- TimePicker already present in XML -->
    <TimePicker
        android:id="@+id/simpleTimePicker"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:timePickerMode="spinner"
        android:visibility="gone"
        android:background="#DDDDDD"
        android:padding="10dp" />
</LinearLayout>

LOCATION: java/com/example/timepickerapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
package com.example.timepickerapp
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
class MainActivity : AppCompatActivity() {
    private lateinit var timePicker: TimePicker
    private lateinit var showButton: Button
    private lateinit var dialogButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        timePicker = findViewById(R.id.simpleTimePicker)
        showButton = findViewById(R.id.showButton)
        dialogButton = findViewById(R.id.dialogButton)

        timePicker.hour = 10
        timePicker.minute = 30
        timePicker.setIs24HourView(true)
        timePicker.visibility = View.GONE

        showButton.setOnClickListener {
            timePicker.visibility = View.VISIBLE
            val hour = timePicker.hour
            val minute = timePicker.minute
            val mode = timePicker.is24HourView
            Toast.makeText(this,"XML TimePicker\\nHour: $hour\\nMinute: $minute\\n24HourMode: $mode",Toast.LENGTH_LONG).show()
        }
        timePicker.setOnTimeChangedListener {_,hourOfDay,minute ->
            Toast.makeText(this,"Changed Time: $hourOfDay : $minute",Toast.LENGTH_SHORT).show()
        }

        dialogButton.setOnClickListener {
            val calendar = Calendar.getInstance()
            val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
            val currentMinute = calendar.get(Calendar.MINUTE)
            val timePickerDialog = TimePickerDialog(this,
                { _, selectedHour, selectedMinute ->
                    Toast.makeText(this,"Dialog TimePicker\\nSelected Time: $selectedHour : $selectedMinute",Toast.LENGTH_LONG).show()
                },
                currentHour,
                currentMinute,
                true
            )
            timePickerDialog.show()
        }
    }
}
"""
    },
    "3": {
        "name": "Date Picker",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
3. DATE PICKER
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="20dp">
    <Button
        android:id="@+id/showButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Show XML DatePicker" />
    <Button
        android:id="@+id/dialogButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="Open Dialog DatePicker" />
    <DatePicker
        android:id="@+id/simpleDatePicker"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:background="#DDDDDD"
        android:padding="10dp"
        android:datePickerMode="spinner"
        android:calendarViewShown="false"
        android:spinnersShown="true"
        android:visibility="gone" />
</LinearLayout>

LOCATION: java/com/example/datepickerapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
package com.example.datepickerapp
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.DatePicker
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
class MainActivity : AppCompatActivity() {
    private lateinit var datePicker: DatePicker
    private lateinit var showButton: Button
    private lateinit var dialogButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        datePicker = findViewById(R.id.simpleDatePicker)
        showButton = findViewById(R.id.showButton)
        dialogButton = findViewById(R.id.dialogButton)
        datePicker.spinnersShown = true
        datePicker.calendarViewShown = false
        datePicker.visibility = View.GONE

        showButton.setOnClickListener {
            datePicker.visibility = View.VISIBLE
            val day = datePicker.dayOfMonth
            val month = datePicker.month + 1
            val year = datePicker.year
            Toast.makeText(this,"XML DatePicker\\nDay: $day\\nMonth: $month\\nYear: $year",Toast.LENGTH_LONG).show()
        }

        datePicker.init(datePicker.year,datePicker.month,datePicker.dayOfMonth) {
                _,year, monthOfYear,dayOfMonth ->
            Toast.makeText(this,"Dialog DatePicker\\nDate: $selectedDay/${selectedMonth + 1}/$selectedYear",Toast.LENGTH_LONG).show()
        }

        dialogButton.setOnClickListener {
            val calendar = Calendar.getInstance()
            val currentDay = calendar.get(Calendar.DAY_OF_MONTH)
            val currentMonth =calendar.get(Calendar.MONTH)
            val currentYear =calendar.get(Calendar.YEAR)
            val datePickerDialog = DatePickerDialog(
                this,
                android.R.style.Theme_Holo_Light_Dialog_NoActionBar,
                { _,
                  selectedYear,
                  selectedMonth,
                  selectedDay ->
                    Toast.makeText(
                        this,
                        "Dialog DatePicker\\nDate: $selectedDay/${selectedMonth + 1}/$selectedYear",
                        Toast.LENGTH_LONG
                    ).show()
                },
                currentYear,
                currentMonth,
                currentDay
            )
            datePickerDialog.datePicker.calendarViewShown = false
            datePickerDialog.datePicker.spinnersShown = true
            datePickerDialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            datePickerDialog.show()
        }
    }
}
"""
    },
    "4": {
        "name": "Radio Button",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
4. RADIO BUTTON
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="20dp">
    <RadioGroup
        android:id="@+id/radioGroup"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:orientation="vertical">
        <RadioButton
            android:id="@+id/rbMale"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Male"
            android:textSize="20sp"
            android:checked="true"/>
        <RadioButton
            android:id="@+id/rbFemale"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Female"
            android:textSize="20sp"/>
        <RadioButton
            android:id="@+id/rbOther"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Other"
            android:textSize="20sp"/>
    </RadioGroup>
    <Button
        android:id="@+id/submitButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="Submit"/>
</LinearLayout>

LOCATION: java/com/example/radiobuttonapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
package com.example.radiobuttonapp
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    private lateinit var radioGroup: RadioGroup
    private lateinit var rbMale: RadioButton
    private lateinit var rbFemale: RadioButton
    private lateinit var rbOther: RadioButton
    private lateinit var submitButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        radioGroup = findViewById(R.id.radioGroup)
        rbMale = findViewById(R.id.rbMale)
        rbFemale = findViewById(R.id.rbFemale)
        rbOther = findViewById(R.id.rbOther)
        submitButton = findViewById(R.id.submitButton)
        submitButton.setOnClickListener {
            val selectedId = radioGroup.checkedRadioButtonId
            val selectedRadioButton = findViewById<RadioButton>(selectedId)
            Toast.makeText(this,"Selected: ${selectedRadioButton.text}",Toast.LENGTH_LONG).show()
        }
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val radioButton = findViewById<RadioButton>(checkedId)
            Toast.makeText(this,"Changed To: ${radioButton.text}",Toast.LENGTH_SHORT).show()
        }
    }
}
"""
    },
    "5": {
        "name": "Check Box",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
5. CHECK BOX
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="20dp">
    <CheckBox
        android:id="@+id/cbCricket"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Cricket"
        android:textSize="20sp"/>
    <CheckBox
        android:id="@+id/cbFootball"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Football"
        android:textSize="20sp"/>
    <CheckBox
        android:id="@+id/cbMusic"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Music"
        android:textSize="20sp"/>
    <Button
        android:id="@+id/submitButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="Submit"/>
</LinearLayout>

LOCATION: java/com/example/checkboxapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
package com.example.checkboxapp
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    private lateinit var cbCricket: CheckBox
    private lateinit var cbFootball: CheckBox
    private lateinit var cbMusic: CheckBox
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cbCricket = findViewById(R.id.cbCricket)
        cbFootball = findViewById(R.id.cbFootball)
        cbMusic = findViewById(R.id.cbMusic)
        submitButton = findViewById(R.id.submitButton)

        cbCricket.isChecked = true
        submitButton.setOnClickListener {
            var selected = ""
            if (cbCricket.isChecked)
                selected += "${cbCricket.text}\\n"
            if (cbFootball.isChecked)
                selected += "${cbFootball.text}\\n"
            if (cbMusic.isChecked)
                selected += "${cbMusic.text}"
            Toast.makeText(this,"Selected:\\n$selected",Toast.LENGTH_LONG).show()
        }
        cbCricket.setOnCheckedChangeListener { _, isChecked ->
            Toast.makeText(this,"Cricket: $isChecked",Toast.LENGTH_SHORT).show()
        }
        cbFootball.setOnCheckedChangeListener { _, isChecked ->
            Toast.makeText(this,"Football: $isChecked",Toast.LENGTH_SHORT).show()
        }
        cbMusic.setOnCheckedChangeListener { _, isChecked ->
            Toast.makeText(this,"Music: $isChecked",Toast.LENGTH_SHORT).show()
        }
    }
}
"""
    },
    "6": {
        "name": "Toggle Button",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
6. TOGGLE BUTTON
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:paddingTop="@dimen/activity_vertical_margin"
    android:paddingBottom="@dimen/activity_vertical_margin"
    android:paddingLeft="@dimen/activity_horizontal_margin"
    android:paddingRight="@dimen/activity_horizontal_margin"
    tools:context=".MainActivity">
    <LinearLayout
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="center_horizontal"
        android:orientation="horizontal">
        <ToggleButton
            android:id="@+id/simpleToggleButton1"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_gravity="center_horizontal"
            android:checked="false"
            android:drawableRight="@drawable/ic_launcher_background"
            android:drawablePadding="20dp"
            android:textOff="WiFi OFF"
            android:textOn="WiFi ON"
            android:textColor="#000" />
        <ToggleButton
            android:id="@+id/simpleToggleButton2"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_gravity="center_horizontal"
            android:layout_marginLeft="50dp"
            android:checked="true"
            android:drawableLeft="@drawable/ic_launcher_background"
            android:drawablePadding="20dp"
            android:textOff="Bluetooth OFF"
            android:textOn="Bluetooth ON"
            android:textColor="#000" />
    </LinearLayout>
    <Button
        android:id="@+id/submitButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="center"
        android:layout_marginTop="50dp"
        android:background="#0f0"
        android:padding="10dp"
        android:text="Submit"
        android:textColor="#fff"
        android:textSize="20sp"
        android:textStyle="bold" />
</LinearLayout>

LOCATION: java/com/example/togglebuttonapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
package com.example.togglebuttonapp
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.widget.ToggleButton
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    private lateinit var tb1: ToggleButton
    private lateinit var tb2: ToggleButton
    private lateinit var submit: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tb1 = findViewById(R.id.simpleToggleButton1)
        tb2 = findViewById(R.id.simpleToggleButton2)
        submit = findViewById(R.id.submitButton)
        submit.setOnClickListener {
            val state1 = tb1.isChecked
            val state2 = tb2.isChecked
            val status ="Toggle1: ${tb1.text}  State: $state1\\n" +"Toggle2: ${tb2.text}  State: $state2"
            Toast.makeText(applicationContext,status,Toast.LENGTH_SHORT).show()
        }
    }
}
"""
    },
    "7": {
        "name": "Progress Bar",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
7. PROGRESS BAR
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="20dp">
    <ProgressBar
        android:id="@+id/determinateBar"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="250dp"
        android:layout_height="wrap_content"
        android:max="100"
        android:progress="0"
        android:visibility="invisible"/>
    <ProgressBar
        android:id="@+id/indeterminateBar"
        style="?android:attr/progressBarStyle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:indeterminate="true"
        android:visibility="invisible"/>
    <TextView
        android:id="@+id/textView"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:textSize="20sp"
        android:layout_marginTop="20dp"/>
    <Button
        android:id="@+id/showButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="Start Progress"/>
</LinearLayout>

LOCATION: java/com/example/progressbarapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
package com.example.progressbarapp
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {

    private lateinit var determinateBar: ProgressBar
    private lateinit var indeterminateBar: ProgressBar
    private lateinit var textView: TextView
    private lateinit var showButton: Button
    private var i = 0
    private val handler = Handler(Looper.getMainLooper())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        determinateBar = findViewById(R.id.determinateBar)
        indeterminateBar = findViewById(R.id.indeterminateBar)
        textView = findViewById(R.id.textView)
        showButton = findViewById(R.id.showButton)
        showButton.setOnClickListener {
            determinateBar.visibility = View.VISIBLE
            indeterminateBar.visibility = View.VISIBLE
            i = determinateBar.progress
            Toast.makeText(this,"Progress Started",Toast.LENGTH_SHORT).show()
            Thread {
                while (i < 100) {
                    i += 1
                    handler.post {
                        determinateBar.progress = i
                        textView.text = "$i/${determinateBar.max}"
                        if (i == 100) {
                            determinateBar.visibility = View.INVISIBLE
                            indeterminateBar.visibility = View.INVISIBLE
                            Toast.makeText(this,"Progress Completed",Toast.LENGTH_SHORT).show()
                        }
                    }

                    try {
                        Thread.sleep(100)
                    } catch (e: InterruptedException) {
                        e.printStackTrace()
                    }
                }
            }.start()
        }
    }
}
"""
    },
    "8": {
        "name": "AutoComplete TextView",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
8. AUTOCOMPLETE TEXTVIEW
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:orientation="vertical"
    android:padding="16dp"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <AutoCompleteTextView
        android:id="@+id/autoText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="Enter a fruit"
        android:textSize="18sp"/>

</LinearLayout>

LOCATION: java/com/example/autocompleteapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val autoText = findViewById<AutoCompleteTextView>(R.id.autoText)

        val fruits = arrayOf(
            "Apple", "Banana", "Mango", "Orange",
            "Grapes", "Pineapple", "Watermelon"
        )

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            fruits
        )

        autoText.threshold = 1
        autoText.setAdapter(adapter)
    }
}
"""
    },
    "9": {
        "name": "Shape Drawing",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
9. SHAPE DRAWING
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:gravity="center"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <ImageView
        android:id="@+id/imageV"
        android:layout_width="300dp"
        android:layout_height="400dp"/>
</LinearLayout>

LOCATION: java/com/example/shapedrawingapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bitmap = Bitmap.createBitmap(700, 1000, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Rectangle
        val rect = ShapeDrawable(RectShape())
        rect.setBounds(100, 100, 600, 400)
        rect.paint.color = Color.RED
        rect.draw(canvas)

        // Circle (oval)
        val oval = ShapeDrawable(OvalShape())
        oval.setBounds(100, 500, 600, 900)
        oval.paint.color = Color.BLUE
        oval.draw(canvas)

        val imageView = findViewById<ImageView>(R.id.imageV)
        imageView.background = BitmapDrawable(resources, bitmap)
    }
}
"""
    },
    "10": {
        "name": "Spinner",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
10. SPINNER
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="20dp">
    <Spinner
        android:id="@+id/spinner"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"/>
    <Button
        android:id="@+id/showButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="Show Selected"/>
</LinearLayout>

LOCATION: java/com/example/spinnerapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
package com.example.spinnerapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var showButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        spinner = findViewById(R.id.spinner)
        showButton = findViewById(R.id.showButton)
        val fruits = arrayOf("Apple","Mango","Orange","Banana","Grapes")
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            fruits
        )
        spinner.adapter = adapter
        showButton.setOnClickListener {
            val selectedItem = spinner.selectedItem.toString()
            val selectedPosition = spinner.selectedItemPosition
            Toast.makeText(this,"Selected: $selectedItem\\nPosition: $selectedPosition",Toast.LENGTH_LONG).show()
        }
    }
}
"""
    },
    "11": {
        "name": "Shared Preferences",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
11. SHARED PREFERENCES
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:orientation="vertical"
    android:padding="16dp"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <EditText
        android:id="@+id/etName"
        android:hint="Username"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

    <EditText
        android:id="@+id/etPass"
        android:hint="Password"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

    <Button
        android:id="@+id/btnSave"
        android:text="Save"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

    <Button
        android:id="@+id/btnLoad"
        android:text="Load"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

    <Button
        android:id="@+id/btnDelete"
        android:text="Delete"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

</LinearLayout>

FILE: MainActivity.kt
================================================================================
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val name = findViewById<EditText>(R.id.etName)
        val pass = findViewById<EditText>(R.id.etPass)

        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnLoad = findViewById<Button>(R.id.btnLoad)
        val btnDelete = findViewById<Button>(R.id.btnDelete)

        val sharedPref = getSharedPreferences("MyPrefs", MODE_PRIVATE)

        // SAVE
        btnSave.setOnClickListener {
            val editor = sharedPref.edit()

            editor.putString("username", name.text.toString())
            editor.putString("password", pass.text.toString())

            editor.apply()

            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        // LOAD
        btnLoad.setOnClickListener {
            val username = sharedPref.getString("username", "No Name")
            val password = sharedPref.getString("password", "No Pass")

            Toast.makeText(this, "$username $password", Toast.LENGTH_LONG).show()
        }

        // DELETE
        btnDelete.setOnClickListener {
            val editor = sharedPref.edit()
            editor.clear()
            editor.apply()

            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
        }
    }
}
"""
    },
    "12": {
        "name": "Intent",
        "files": ["activity_main.xml", "MainActivity.kt", "activity_second.xml", "SecondActivity.kt"],
        "content": """
================================================================================
12. INTENT
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:orientation="vertical"
    android:padding="16dp"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <Button
        android:id="@+id/btnNext"
        android:text="Go to Second Page"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

    <Button
        android:id="@+id/btnWeb"
        android:text="Open Website"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

    <Button
        android:id="@+id/btnDial"
        android:text="Open Dialer"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

    <Button
        android:id="@+id/btnShare"
        android:text="Share Text"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

</LinearLayout>

LOCATION: java/com/example/intentapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnNext = findViewById<Button>(R.id.btnNext)
        val btnWeb = findViewById<Button>(R.id.btnWeb)
        val btnDial = findViewById<Button>(R.id.btnDial)
        val btnShare = findViewById<Button>(R.id.btnShare)

        // Explicit Intent (go to next screen)
        btnNext.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            intent.putExtra("name", "John")
            startActivity(intent)
        }

        // Open website
        btnWeb.setOnClickListener {
            val webIntent = Intent(Intent.ACTION_VIEW)
            webIntent.data = Uri.parse("https://www.google.com")
            startActivity(webIntent)
        }

        // Open dialer
        btnDial.setOnClickListener {
            val dialIntent = Intent(Intent.ACTION_DIAL)
            dialIntent.data = Uri.parse("tel:1234567890")
            startActivity(dialIntent)
        }

        // Share text
        btnShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_TEXT, "Hello this is shared text")

            startActivity(Intent.createChooser(shareIntent, "Share via"))
        }
    }
}

LOCATION: res/layout/activity_second.xml
FILE: activity_second.xml
================================================================================
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:gravity="center"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <TextView
        android:id="@+id/textView"
        android:textSize="24sp"
        android:text="Welcome"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"/>

</LinearLayout>

LOCATION: java/com/example/intentapp/SecondActivity.kt
FILE: SecondActivity.kt
================================================================================
class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val name = intent.getStringExtra("name")

        val textView = findViewById<TextView>(R.id.textView)
        textView.text = "Welcome $name"
    }
}
"""
    },
    "13": {
        "name": "Popup Menu",
        "files": ["activity_main.xml", "popup_menu.xml", "MainActivity.kt"],
        "content": """
================================================================================
13. POPUP MENU
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:gravity="center"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <Button
        android:id="@+id/btnPopup"
        android:text="Show Menu"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"/>

</LinearLayout>

FILE: res/menu/popup_menu.xml
================================================================================
<menu xmlns:android="http://schemas.android.com/apk/res/android">

    <item
        android:id="@+id/item1"
        android:title="Item 1"/>

    <item
        android:id="@+id/item2"
        android:title="Item 2"/>

</menu>

LOCATION: java/com/example/popupapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
class MainActivity : AppCompatActivity(), PopupMenu.OnMenuItemClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.btnPopup)

        button.setOnClickListener {
            val popup = PopupMenu(this, button)
            popup.inflate(R.menu.popup_menu)
            popup.setOnMenuItemClickListener(this)
            popup.show()
        }
    }

    override fun onMenuItemClick(item: MenuItem): Boolean {

        if (item.itemId == R.id.item1) {
            Toast.makeText(this, "Item 1 selected", Toast.LENGTH_SHORT).show()
        }

        if (item.itemId == R.id.item2) {
            Toast.makeText(this, "Item 2 selected", Toast.LENGTH_SHORT).show()
        }

        return true
    }
}
"""
    },
    "14": {
        "name": "Context Menu",
        "files": ["activity_main.xml", "context_menu.xml", "MainActivity.kt"],
        "content": """
================================================================================
14. CONTEXT MENU
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:gravity="center"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <TextView
        android:id="@+id/textView"
        android:text="Long Press Me"
        android:textSize="24sp"
        android:padding="20dp"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"/>

</LinearLayout>

FILE: res/menu/context_menu.xml
================================================================================
<menu xmlns:android="http://schemas.android.com/apk/res/android">

    <item
        android:id="@+id/option1"
        android:title="Option 1"/>

    <item
        android:id="@+id/option2"
        android:title="Option 2"/>

</menu>

LOCATION: java/com/example/contextmenuapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textView = findViewById<TextView>(R.id.textView)

        registerForContextMenu(textView)
    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)

        menu.setHeaderTitle("Choose option")
        menuInflater.inflate(R.menu.context_menu, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        if (item.itemId == R.id.option1) {
            Toast.makeText(this, "Option 1 selected", Toast.LENGTH_SHORT).show()
        }

        if (item.itemId == R.id.option2) {
            Toast.makeText(this, "Option 2 selected", Toast.LENGTH_SHORT).show()
        }

        return true
    }
}
"""
    },
    "15": {
        "name": "Animation (Basic)",
        "files": ["activity_main.xml", "MainActivity.kt"],
        "content": """
================================================================================
15. ANIMATION (BASIC)
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <ImageView
        android:id="@+id/imageV"
        android:layout_width="315dp"
        android:layout_height="526dp"
        android:layout_marginTop="100dp"
        android:layout_marginEnd="50dp"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

</android.support.constraint.ConstraintLayout>

LOCATION: java/com/example/animationbasicapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val bitmap: Bitmap = Bitmap.createBitmap(700, 1000, Bitmap.Config.ARGB_8888)
        val canvas: Canvas = Canvas(bitmap)
        var shapeDrawable: ShapeDrawable
        var left = 100
        var top = 100
        var right = 600
        var bottom = 400
        shapeDrawable = ShapeDrawable(RectShape())
        shapeDrawable.setBounds( left, top, right, bottom)
        shapeDrawable.getPaint().setColor(Color.parseColor("#009944"))
        shapeDrawable.draw(canvas)
        shapeDrawable = ShapeDrawable(OvalShape())
        shapeDrawable.setBounds( 100, 500, 600, 800)
        shapeDrawable.getPaint().setColor(Color.parseColor("#009191"))
        shapeDrawable.draw(canvas)
        val iv = findViewById<ImageView>(R.id.imageV)
        iv.background = BitmapDrawable(getResources(), bitmap)
    }
}
"""
    },
    "16": {
        "name": "Animation (Advanced)",
        "files": ["activity_main.xml", "MainActivity.kt", "Animation XML files"],
        "content": """
================================================================================
16. ANIMATION (ADVANCED)
================================================================================

FILE: activity_main.xml (ConstraintLayout)
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <Button android:id="@+id/button10" android:layout_width="wrap_content" 
        android:layout_height="wrap_content" android:text="zoom in" />
    <Button android:id="@+id/button" android:layout_width="wrap_content" 
        android:layout_height="wrap_content" android:text="bounce" />
    <Button android:id="@+id/button2" android:layout_width="wrap_content" 
        android:layout_height="wrap_content" android:text="rotate" />
    <Button android:id="@+id/button3" android:layout_width="wrap_content" 
        android:layout_height="wrap_content" android:text="fade in" />
    <Button android:id="@+id/button4" android:layout_width="wrap_content" 
        android:layout_height="wrap_content" android:text="fade out" />
    <Button android:id="@+id/button5" android:layout_width="wrap_content" 
        android:layout_height="wrap_content" android:text="slide up" />
    <Button android:id="@+id/button9" android:layout_width="wrap_content" 
        android:layout_height="wrap_content" android:text="slide down" />
    <Button android:id="@+id/button11" android:layout_width="wrap_content" 
        android:layout_height="wrap_content" android:text="zoom out" />
    <ImageView android:id="@+id/imageView" android:layout_width="315dp" 
        android:layout_height="137dp" tools:srcCompat="@tools:sample/backgrounds/scenic" />

</android.support.constraint.ConstraintLayout>

FILE: res/anim/bounce.xml
================================================================================
<set xmlns:android="http://schemas.android.com/apk/res/android"
    android:interpolator="@android:anim/linear_interpolator"
    android:fillAfter="true">
    <translate android:fromYDelta="100%" android:toYDelta="-20%" android:duration="300" />
    <translate android:startOffset="500" android:fromYDelta="-20%" android:toYDelta="10%" android:duration="150" />
    <translate android:startOffset="1000" android:fromYDelta="10%" android:toYDelta="0" android:duration="100" />
</set>

FILE: res/anim/fade_in.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<set xmlns:android="http://schemas.android.com/apk/res/android"
    android:interpolator="@android:anim/linear_interpolator">
    <alpha android:duration="1000" android:fromAlpha="0.1" android:toAlpha="1.0" />
</set>

FILE: res/anim/fade_out.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<set xmlns:android="http://schemas.android.com/apk/res/android"
    android:interpolator="@android:anim/linear_interpolator">
    <alpha android:duration="1000" android:fromAlpha="1.0" android:toAlpha="0.1" />
</set>

FILE: res/anim/rotate.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<rotate xmlns:android="http://schemas.android.com/apk/res/android"
    android:duration="1000" android:fromDegrees="0" android:interpolator="@android:anim/linear_interpolator"
    android:pivotX="50%" android:pivotY="50%" android:startOffset="0" android:toDegrees="360" />

FILE: res/anim/slide_down.xml
================================================================================
<set xmlns:android="http://schemas.android.com/apk/res/android">
    <translate android:duration="1000" android:fromYDelta="0" android:toYDelta="-100%" />
</set>

FILE: res/anim/slide_up.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<set xmlns:android="http://schemas.android.com/apk/res/android"></set>

FILE: res/anim/zoom_in.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<set xmlns:android="http://schemas.android.com/apk/res/android" android:fillAfter="true">
    <scale xmlns:android="http://schemas.android.com/apk/res/android" android:duration="1000"
        android:fromXScale="1" android:fromYScale="1" android:pivotX="50%" android:pivotY="50%"
        android:toXScale="1.5" android:toYScale="1.5" />
</set>

FILE: res/anim/zoom_out.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<set xmlns:android="http://schemas.android.com/apk/res/android" android:fillAfter="true" >
    <scale xmlns:android="http://schemas.android.com/apk/res/android" android:duration="1000"
        android:fromXScale="1.0" android:fromYScale="1.0" android:pivotX="50%" android:pivotY="50%"
        android:toXScale="0.5" android:toYScale="0.5" />
</set>

LOCATION: java/com/example/animationadvancedapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var fade_in=findViewById<Button>(R.id.button3)
        var fade_out=findViewById<Button>(R.id.button4)
        var bounce=findViewById<Button>(R.id.button)
        var rotate=findViewById<Button>(R.id.button2)
        var slide_down=findViewById<Button>(R.id.button9)
        var slide_up=findViewById<Button>(R.id.button5)
        var zoom_in=findViewById<Button>(R.id.button10)
        var zoom_out=findViewById<Button>(R.id.button11)
        var textView=findViewById<ImageView>(R.id.imageView)

        fade_in.setOnClickListener {
            textView.visibility = View.VISIBLE
            val animation = AnimationUtils.loadAnimation(this, R.anim.fade_in)
            textView.startAnimation(animation)
        }
        fade_out.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(this, R.anim.fade_out)
            textView.startAnimation(animation)
            Handler().postDelayed({ textView.visibility = View.GONE }, 1000)
        }
        zoom_in.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(this, R.anim.zoom_in)
            textView.startAnimation(animation)
        }
        zoom_out.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(this, R.anim.zoom_out)
            textView.startAnimation(animation)
        }
        slide_down.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(this, R.anim.slide_down)
            textView.startAnimation(animation)
        }
        slide_up.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(this, R.anim.slide_up)
            textView.startAnimation(animation)
        }
        bounce.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(this, R.anim.bounce)
            textView.startAnimation(animation)
        }
        rotate.setOnClickListener {
            val animation = AnimationUtils.loadAnimation(this, R.anim.rotate)
            textView.startAnimation(animation)
        }
    }
}
"""
    },
    "17": {
        "name": "SQLite Database",
        "files": ["activity_main.xml", "DBHelper.kt", "MainActivity.kt"],
        "content": """
================================================================================
17. SQLITE DATABASE
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="20dp">
    <EditText android:id="@+id/editId" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:hint="Enter ID"/>
    <EditText android:id="@+id/editName" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:hint="Enter Name"/>
    <EditText android:id="@+id/editAge" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:hint="Enter Age" android:inputType="number"/>
    <Button android:id="@+id/insertButton" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:text="Insert Data"/>
    <Button android:id="@+id/updateButton" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:text="Update Data"/>
    <Button android:id="@+id/deleteButton" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:text="Delete Data"/>
    <Button android:id="@+id/viewButton" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:text="View Data"/>
    <TextView android:id="@+id/textView" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:textSize="18sp"/>
</LinearLayout>

LOCATION: java/com/example/sqliteapp/DBHelper.kt
FILE: DBHelper.kt
================================================================================
package com.example.sqliteapp
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(context,"StudentDB",null,1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,age INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS students")
        onCreate(db)
    }

    fun insertData(name: String, age: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name",name)
        values.put("age",age)
        val result = db.insert("students",null,values)
        return result != -1L
    }

    fun updateData(id: String, name: String, age: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name",name)
        values.put("age",age)
        val result = db.update("students",values,"id=?",arrayOf(id))
        return result > 0
    }

    fun deleteData(id: String): Boolean {
        val db = writableDatabase
        val result = db.delete("students","id=?",arrayOf(id))
        return result > 0
    }

    fun getData(): String {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM students", null)
        var data = ""
        while (cursor.moveToNext()) {
            val id = cursor.getString(0)
            val name = cursor.getString(1)
            val age = cursor.getString(2)
            data += "ID: $id\\nName: $name\\nAge: $age\\n\\n"
        }
        cursor.close()
        return data
    }
}

LOCATION: java/com/example/sqliteapp/MainActivity.kt
FILE: MainActivity.kt
================================================================================
package com.example.sqliteapp
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var editId: EditText
    private lateinit var editName: EditText
    private lateinit var editAge: EditText
    private lateinit var insertButton: Button
    private lateinit var updateButton: Button
    private lateinit var deleteButton: Button
    private lateinit var viewButton: Button
    private lateinit var textView: TextView
    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editId = findViewById(R.id.editId)
        editName = findViewById(R.id.editName)
        editAge = findViewById(R.id.editAge)
        insertButton = findViewById(R.id.insertButton)
        updateButton = findViewById(R.id.updateButton)
        deleteButton = findViewById(R.id.deleteButton)
        viewButton = findViewById(R.id.viewButton)
        textView = findViewById(R.id.textView)
        dbHelper = DBHelper(this)

        insertButton.setOnClickListener {
            val name = editName.text.toString()
            val age = editAge.text.toString()
            val inserted = dbHelper.insertData(name,age)
            Toast.makeText(this,if(inserted)"Data Inserted" else "Insertion Failed",Toast.LENGTH_SHORT).show()
        }

        updateButton.setOnClickListener {
            val id = editId.text.toString()
            val name = editName.text.toString()
            val age = editAge.text.toString()
            val updated = dbHelper.updateData(id,name,age)
            Toast.makeText(this,if(updated)"Data Updated" else "Update Failed",Toast.LENGTH_SHORT).show()
        }

        deleteButton.setOnClickListener {
            val id = editId.text.toString()
            val deleted = dbHelper.deleteData(id)
            Toast.makeText(this,if(deleted)"Data Deleted" else "Delete Failed",Toast.LENGTH_SHORT).show()
        }

        viewButton.setOnClickListener {
            val data = dbHelper.getData()
            textView.text = data
        }
    }
}
"""
    },
    "18": {
        "name": "Toast Messages",
        "files": ["activity_main.xml", "custom_toast.xml", "MainActivity.kt"],
        "content": """
================================================================================
18. TOAST MESSAGES (CUSTOM)
================================================================================

LOCATION: res/layout/activity_main.xml
FILE: activity_main.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical">

    <Button
        android:id="@+id/toastButton"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Show Custom Toast"/>

</LinearLayout>

LOCATION: res/layout/custom_toast.xml
FILE: custom_toast.xml
================================================================================
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:orientation="horizontal"
    android:padding="15dp"
    android:background="#222222">

    <ImageView
        android:layout_width="40dp"
        android:layout_height="40dp"
        android:src="@mipmap/ic_launcher"/>

    <TextView
        android:id="@+id/toastText"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Custom Toast"
        android:textColor="#FFFFFF"
        android:textSize="18sp"
        android:layout_marginStart="10dp"/>

</LinearLayout>

FILE: MainActivity.kt
================================================================================
package com.example.customtoast

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var toastButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toastButton = findViewById(R.id.toastButton)

        toastButton.setOnClickListener {

            val layout = layoutInflater.inflate(R.layout.custom_toast,null)

            val toastText = layout.findViewById<TextView>(R.id.toastText)

            toastText.text = "Hello from Custom Toast"

            val toast = Toast(this)

            toast.duration = Toast.LENGTH_LONG
            toast.view = layout
            toast.setGravity(Gravity.BOTTOM,0,150)

            toast.show()
        }
    }
}
"""
    }
}


def display_menu():
    """Display the menu of Android snippets"""
    print("\n" + "="*70)
    print(" ANDROID CODE SNIPPETS GENERATOR - maday".center(70))
    print("="*70)
    print("\nSelect a snippet to generate:\n")
    
    for key, value in ANDROID_SNIPPETS.items():
        print(f"  {key}. {value['name']}")
    
    print(f"\n  0. Exit")
    print("="*70)


def generate_snippet(choice):
    """Generate the selected snippet to output file in home directory"""
    if choice == "0":
        print("\nThank you for using maday Android Snippets! Goodbye!")
        return False
    
    if choice not in ANDROID_SNIPPETS:
        print("\n[ERROR] Invalid choice! Please try again.")
        return True
    
    snippet = ANDROID_SNIPPETS[choice]
    
    # Write to current working directory
    output_path = "a.txt"
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(snippet["content"])
    
    print(f"\n[SUCCESS] Generated: {snippet['name']}")
    print(f"[FILES] {', '.join(snippet['files'])}")
    print(f"[OUTPUT] {output_path}")
    
    return False


def main():
    """Main function"""
    while True:
        display_menu()
        choice = input("\nEnter your choice (0-18): ").strip()
        
        should_continue = generate_snippet(choice)
        if not should_continue:
            break
        
        input("\nPress Enter to continue...")


if __name__ == "__main__":
    main()
