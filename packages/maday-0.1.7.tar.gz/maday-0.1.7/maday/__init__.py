"""
Maday - Android Code Snippets & Utilities Generator
"""

__version__ = "0.1.0"
__author__ = "Your Name"

# Import main functionality
from .android_snippets import main as android_snippets
from .main import hello_world, show_help

__all__ = ["android_snippets", "hello_world", "show_help"]
