from __future__ import annotations

import argparse
from collections.abc import Iterator

from .client import DEFAULT_PUB_ENDPOINT
from .client import DEFAULT_SUB_ENDPOINT
from .client import NimbusClient
from .client import ReceivedMessage


def arm_main() -> None:
    parser = argparse.ArgumentParser(description="Publish a Nimbus arm-state command.")
    parser.add_argument(
        "--disarm",
        action="store_true",
        help="Publish disarmed instead of armed.",
    )
    parser.add_argument("--pub-endpoint", default=DEFAULT_PUB_ENDPOINT)
    args = parser.parse_args()

    armed = not args.disarm
    with NimbusClient(pub_endpoint=args.pub_endpoint) as client:
        client.publish_arm_state(armed)

    print("published arm state:", f"armed={str(armed).lower()}")


def guidance_request_main() -> None:
    parser = argparse.ArgumentParser(description="Publish a Nimbus guidance request.")
    parser.add_argument(
        "type",
        choices=["go", "land", "relative_waypoint", "return_home"],
        help="Guidance request type to publish.",
    )
    parser.add_argument("--forward", type=float, default=0.0)
    parser.add_argument("--right", type=float, default=0.0)
    parser.add_argument("--down", type=float, default=0.0)
    parser.add_argument("--hold-time", type=float, default=0.0)
    parser.add_argument("--pub-endpoint", default=DEFAULT_PUB_ENDPOINT)
    args = parser.parse_args()

    with NimbusClient(pub_endpoint=args.pub_endpoint) as client:
        client.publish_guidance_request(
            args.type,
            forward=args.forward,
            right=args.right,
            down=args.down,
            hold_time_s=args.hold_time,
        )

    print(
        "published guidance request:",
        f"type={args.type}",
        f"forward={args.forward:.2f}m",
        f"right={args.right:.2f}m",
        f"down={args.down:.2f}m",
        f"hold_time={args.hold_time:.2f}s",
    )


def waypoint_command_main() -> None:
    parser = argparse.ArgumentParser(description="Publish one Nimbus waypoint command.")
    parser.add_argument(
        "--mode",
        choices=["override", "queue"],
        default="override",
        help="Replace the active waypoint or append to the queue.",
    )
    parser.add_argument("--forward", type=float, required=True, help="Meters forward/back.")
    parser.add_argument("--right", type=float, required=True, help="Meters right/left.")
    parser.add_argument(
        "--down",
        type=float,
        required=True,
        help="Absolute local-frame down target.",
    )
    parser.add_argument(
        "--hold-time",
        type=float,
        default=0.0,
        help="Seconds to hold after reaching the waypoint.",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.05,
        help="Meters from target that counts as reached.",
    )
    parser.add_argument("--pub-endpoint", default=DEFAULT_PUB_ENDPOINT)
    args = parser.parse_args()

    with NimbusClient(pub_endpoint=args.pub_endpoint) as client:
        client.publish_waypoint_command(
            forward=args.forward,
            right=args.right,
            down=args.down,
            mode=args.mode,
            threshold_m=args.threshold,
            hold_time_s=args.hold_time,
        )

    print(
        "published waypoint command:",
        f"mode={args.mode}",
        f"forward={args.forward:.2f}m",
        f"right={args.right:.2f}m",
        f"down={args.down:.2f}m",
        f"threshold={args.threshold:.2f}m",
        f"hold_time={args.hold_time:.2f}s",
    )


def subscribe_main() -> None:
    parser = argparse.ArgumentParser(description="Subscribe to one Nimbus V1 SDK topic.")
    parser.add_argument("topic", choices=["telemetry", "state", "camera"])
    parser.add_argument("--limit", type=int, default=0, help="Stop after N messages.")
    parser.add_argument("--timeout", type=float, default=None, help="Stop after N seconds.")
    parser.add_argument("--sub-endpoint", default=DEFAULT_SUB_ENDPOINT)
    args = parser.parse_args()

    if args.limit < 0:
        raise ValueError("--limit must be zero or positive")

    count = 0
    with NimbusClient(sub_endpoint=args.sub_endpoint) as client:
        for message in _subscribe(client, args.topic, timeout_sec=args.timeout):
            print(_format_message(message))
            count += 1
            if args.limit and count >= args.limit:
                return


def _subscribe(
    client: NimbusClient,
    topic: str,
    *,
    timeout_sec: float | None,
) -> Iterator[ReceivedMessage]:
    if topic == "telemetry":
        return client.subscribe_telemetry(timeout_sec=timeout_sec)
    if topic == "state":
        return client.subscribe_state(timeout_sec=timeout_sec)
    if topic == "camera":
        return client.subscribe_camera(timeout_sec=timeout_sec)
    raise ValueError(f"unsupported SDK subscription topic: {topic}")


def _format_message(message: ReceivedMessage) -> str:
    parts = [
        message.topic,
        f"bytes={len(message.payload)}",
        f"type={message.root_type}",
    ]
    if message.seq is not None:
        parts.append(f"seq={message.seq}")
    if message.t_ns is not None:
        parts.append(f"t_ns={message.t_ns}")
    return " ".join(parts)
