"""Athena SDK - Python SDK for building blocks."""

from athena.config import (
    CustomObjectSpec,
    ObjectSpec,
    Registry,
    instantiate,
    load_config,
    objects,
)
from athena.context import BlockContext, RegisteredArtifact
from athena.decorators import (
    block,
    get_block_spec,
    get_config_class,
)
from athena.types import (
    ArtifactRef,
    BlockConfig,
    BlockSpec,
    StorageBackend,
)

__all__ = [
    # Config
    "Registry",
    "objects",
    "ObjectSpec",
    "CustomObjectSpec",
    "load_config",
    "instantiate",
    # Context
    "BlockContext",
    "RegisteredArtifact",
    # Decorators
    "block",
    "get_block_spec",
    "get_config_class",
    # Types
    "ArtifactRef",
    "BlockConfig",
    "BlockSpec",
    "StorageBackend",
]

__version__ = "0.3.10"
