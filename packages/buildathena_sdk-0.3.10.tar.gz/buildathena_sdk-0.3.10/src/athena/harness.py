"""Python block harness for subprocess execution.

This module is the bridge between the daemon's process pool and the SDK's
@block decorator. It runs as a warm worker process, polling the Block API
for tasks and executing block functions.

Usage (invoked by daemon, never by users):
    python -m athena.harness blocks/train.py

The daemon passes ATHENA_WORKER_ID, ATHENA_BLOCK_API, and ATHENA_ARTIFACTS_DIR
as env vars.

Key design principle: The harness materializes data outputs to storage before
returning to the daemon. Plain returns are wrapped in OutputHandle internally,
and the daemon only receives storage references, never actual data. This keeps
the daemon lean (orchestration only) and ensures data is persisted immediately
after block completion.
"""

from __future__ import annotations

import asyncio
import importlib.util
import json as _json
import logging
import os
import sys
import traceback
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, cast

import httpx

from athena._generated_schemas import (
    ArtifactRef,
    BlockApiWorkerDoneFailure,
    BlockApiWorkerDoneSuccess,
    BlockApiWorkerTask,
    BlockArtifactRef,
    BlockDataRef,
)
from athena.context import BlockContext, RegisteredArtifact, _ArtifactDataDelivery
from athena.decorators import get_config_class
from athena.output_handle import OutputHandle
from athena.storage import LocalStorageBackend

if TYPE_CHECKING:
    from athena.storage import StorageBackend

logger = logging.getLogger(__name__)

# Environment variable for artifacts directory
ATHENA_ARTIFACTS_DIR_ENV = "ATHENA_ARTIFACTS_DIR"

# Poll interval when idle (seconds)
POLL_INTERVAL = 0.1

# How long to keep polling before checking if we should exit
MAX_IDLE_POLL_SECONDS = 600

_STORAGE_FORMATS = {"json", "pickle", "bytes"}


def _storage_format_literal(
    value: str | None,
) -> Literal["json", "pickle", "bytes"] | None:
    if value in _STORAGE_FORMATS:
        return cast(Literal["json", "pickle", "bytes"], value)
    return None


def _load_block(block_path: str, block_id: str) -> tuple[Any, Any]:
    """Load a block function from a file path.

    block_id must be the Python function name (e.g., "train_vae"), not the
    display name from @block(name="...").

    Returns (block_func, config_class).
    """
    full_path = Path(block_path)
    if not full_path.exists():
        raise FileNotFoundError(f"Block file not found: {full_path}")

    module_name = f"athena_block_{full_path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, full_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module from {full_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    # Primary lookup: block_id as Python function name (the correct usage)
    if hasattr(module, block_id):
        block_func = getattr(module, block_id)
        config_class = get_config_class(block_func)
        return block_func, config_class

    raise AttributeError(f"Block '{block_id}' not found in {block_path}")


async def _execute_task(
    _client: httpx.AsyncClient,
    _block_api_url: str,
    task: BlockApiWorkerTask | dict[str, Any],
    storage: StorageBackend | None,
) -> dict[str, Any]:
    """Execute a single block task.

    Returns dict with 'outputs' on success, or raises on failure.
    The storage backend is used to materialize OutputHandles before returning.
    """
    parsed_task = (
        task if isinstance(task, BlockApiWorkerTask) else BlockApiWorkerTask.model_validate(task)
    )
    block_path = parsed_task.block_path
    block_id = parsed_task.block_id
    config = parsed_task.config
    inputs = parsed_task.inputs
    run_id = parsed_task.run_id
    step_id = parsed_task.step_id
    secrets = parsed_task.secrets

    # Load block
    block_func, config_class = _load_block(block_path, block_id)

    # Parse config
    parsed_config = config_class(**config) if config_class else config

    # Build input handles from task input refs
    block_inputs: dict[str, Any] = {}
    for name, ref in inputs.items():
        if isinstance(ref, dict) and ref.get("__artifact_ref__") is True:
            artifact_ref = BlockArtifactRef.model_validate(ref)
            block_inputs[name] = ArtifactRef(
                artifact_id=artifact_ref.artifact_id,
                schema_type=artifact_ref.schema_type,
                name=artifact_ref.name,
                uri=artifact_ref.uri,
            )
        elif isinstance(ref, dict) and "storage_key" in ref and "content_hash" in ref:
            # Storage reference from upstream block in same run —
            # reconstruct OutputHandle and eagerly load data so blocks
            # can access ctx.inputs synchronously
            data_ref = BlockDataRef.model_validate(ref)
            handle = OutputHandle.from_storage(
                storage_key=data_ref.storage_key,
                content_hash=data_ref.content_hash,
                name=data_ref.name,
                schema_type=data_ref.schema_type,
                format=_storage_format_literal(data_ref.format),
            )
            if storage:
                await handle.load_data(storage)
            block_inputs[name] = handle
        else:
            block_inputs[name] = ref

    # Create context and run block
    async with BlockContext(
        run_id=run_id,
        step_id=step_id,
        inputs=block_inputs,
        config=config,
        secrets=secrets,
    ) as ctx:
        if config_class is not None:
            result = await block_func(ctx, parsed_config)
        else:
            result = await block_func(ctx)

    # Process outputs - materialize OutputHandles to storage before returning
    # This is critical: daemon only receives storage refs, never actual data
    outputs: dict[str, Any] = {}
    if result and isinstance(result, dict):
        for name, value in result.items():
            outputs[name] = await _serialize_output(value, storage)

    return outputs


async def _serialize_output(value: Any, storage: StorageBackend | None) -> dict[str, Any]:
    """Serialize block output - materialize to storage before returning.

    Handles both return styles:
    - OutputHandle: already wrapped, materialize and return storage ref
    - Any other value: wrap in OutputHandle, materialize, return storage ref

    This ensures the daemon only receives storage references, never actual data.

    Args:
        value: The output value (OutputHandle or any Python object)
        storage: Storage backend for materializing

    Returns:
        Dict containing storage references
    """
    if isinstance(value, RegisteredArtifact):
        raise ValueError(
            "Blocks must return artifact.as_ref() or artifact.as_data(), "
            "not a bare RegisteredArtifact."
        )

    if isinstance(value, _ArtifactDataDelivery):
        artifact = value.artifact
        if artifact.storage_key is None or artifact.content_hash is None or artifact.format is None:
            raise ValueError(
                "Artifact data delivery requires managed storage metadata and a loadable format. "
                "Return artifact.as_ref() instead."
            )
        return BlockDataRef(
            storage_key=artifact.storage_key,
            content_hash=artifact.content_hash,
            artifact_id=str(artifact.artifact_id),
            format=artifact.format,
            schema_type=artifact.schema_type,
            mime_type=artifact.mime_type,
            name=artifact.name,
            tags=artifact.tags,
            metadata=artifact.metadata,
        ).model_dump(mode="json", exclude_none=True)

    if isinstance(value, ArtifactRef):
        return BlockArtifactRef(
            artifact_id=value.artifact_id,
            schema_type=value.schema_type,
            name=value.name,
            uri=value.uri,
        ).model_dump(mode="json", by_alias=True, exclude_none=True)

    # Wrap plain values in OutputHandle for consistent materialization.
    # Default to JSON for language-agnostic interop; fall back to pickle
    # for complex Python objects (numpy, torch, sklearn, etc.).
    if not isinstance(value, OutputHandle):
        fmt: Literal["json", "pickle"] = "json"
        try:
            _json.dumps(value)
        except (TypeError, ValueError, OverflowError):
            fmt = "pickle"
            import warnings

            warnings.warn(
                f"Block output is not JSON-serializable — falling back to pickle. "
                f"For large objects (models, tensors), save to disk with torch.save() "
                f"and return a registered artifact instead. "
                f"Type: {type(value).__name__}",
                stacklevel=2,
            )
        value = OutputHandle.from_data(value, format=fmt)

    # Materialize to storage if has data and not already materialized
    if value.has_data and storage and not value.is_materialized:
        await value.materialize(storage)

    # Verify materialization succeeded
    if not value.is_materialized:
        raise ValueError(
            "Cannot return output without materializing to storage. "
            "Ensure ATHENA_ARTIFACTS_DIR is set."
        )
    if value.storage_key is None or value.content_hash is None:
        raise ValueError("Materialized output is missing storage metadata")

    # Return only storage reference - no actual data
    return BlockDataRef(
        storage_key=value.storage_key,
        content_hash=value.content_hash,
        format=value._format,
        schema_type=value.schema_type,
        mime_type=value.mime_type,
        name=value.name,
        step_id=value.step_id,
        tags=value.tags,
        metadata=value.metadata,
    ).model_dump(mode="json", exclude_none=True)


async def _run_worker(_block_file: str) -> None:
    """Main worker loop: poll for tasks, execute blocks, report results."""
    worker_id = os.environ.get("ATHENA_WORKER_ID")
    block_api_url = os.environ.get("ATHENA_BLOCK_API")
    artifacts_dir = os.environ.get(ATHENA_ARTIFACTS_DIR_ENV)

    if not worker_id:
        print("ERROR: ATHENA_WORKER_ID not set", file=sys.stderr)
        sys.exit(1)
    if not block_api_url:
        print("ERROR: ATHENA_BLOCK_API not set", file=sys.stderr)
        sys.exit(1)

    # Initialize storage backend for artifact materialization
    # This is required for OutputHandles to be persisted before returning to daemon
    storage: StorageBackend | None = None
    if artifacts_dir:
        storage = LocalStorageBackend(Path(artifacts_dir))
        logger.info("Worker %s using storage at %s", worker_id, artifacts_dir)
    else:
        logger.warning(
            "ATHENA_ARTIFACTS_DIR not set - OutputHandles cannot be materialized. "
            "Blocks returning OutputHandles will fail."
        )

    logger.info("Worker %s starting, polling %s", worker_id, block_api_url)

    async with httpx.AsyncClient(timeout=30.0) as client:
        next_url = f"{block_api_url}/api/workers/{worker_id}/next"
        done_url = f"{block_api_url}/api/workers/{worker_id}/done"

        while True:
            # Poll for next task
            try:
                resp = await client.get(next_url)
            except httpx.HTTPError as e:
                logger.warning("Failed to poll for task: %s", e)
                await asyncio.sleep(POLL_INTERVAL)
                continue

            if resp.status_code == 410:
                # Daemon says shut down
                logger.info("Worker %s received shutdown signal", worker_id)
                break

            if resp.status_code == 204:
                # No task, poll again
                await asyncio.sleep(POLL_INTERVAL)
                continue

            if resp.status_code != 200:
                logger.warning("Unexpected status %d from /next", resp.status_code)
                await asyncio.sleep(POLL_INTERVAL)
                continue

            task = BlockApiWorkerTask.model_validate(resp.json())
            logger.info(
                "Worker %s executing block %s (step=%s)",
                worker_id,
                task.block_id,
                task.step_id,
            )

            # Execute the block with storage for artifact materialization
            try:
                outputs = await _execute_task(client, block_api_url, task, storage)
                await client.post(
                    done_url,
                    json=BlockApiWorkerDoneSuccess(outputs=outputs).model_dump(mode="json"),
                )
            except Exception as e:
                tb = traceback.format_exc()
                logger.error("Block execution failed: %s", e)
                try:
                    await client.post(
                        done_url,
                        json=BlockApiWorkerDoneFailure(
                            error=str(e),
                            traceback=tb,
                        ).model_dump(mode="json", exclude_none=True),
                    )
                except httpx.HTTPError:
                    logger.warning("Failed to report error to daemon")


def _configure_worker_logging() -> None:
    """Keep normal worker stderr focused on actionable block failures."""
    logging.basicConfig(
        level=logging.WARNING,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        stream=sys.stderr,
        force=True,
    )
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def main() -> None:
    """Entry point: python -m athena.harness <block_file>"""
    if len(sys.argv) < 2:
        print("Usage: python -m athena.harness <block_file>", file=sys.stderr)
        sys.exit(1)

    block_file = sys.argv[1]

    _configure_worker_logging()
    asyncio.run(_run_worker(block_file))


if __name__ == "__main__":
    main()
