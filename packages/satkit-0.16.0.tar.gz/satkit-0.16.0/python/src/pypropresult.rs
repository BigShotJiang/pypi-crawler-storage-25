use pyo3::prelude::*;

use crate::pyinstant::{PyInstant, ToTimeVec};
use crate::pyutils::*;

use pyo3::types::{PyBytes, PyDict, PyTuple};
use pyo3::IntoPyObjectExt;

use numpy::PyArrayMethods;
use numpy::{self as np, ToPyArray};

use satkit::mathtypes::*;
use satkit::orbitprop::PropagationResult;
use satkit::Instant;

use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum PyPropResultType {
    R1(Box<PropagationResult<1>>),
    R7(Box<PropagationResult<7>>),
}

/// Propagation statistics
///
/// This class holds statistics about the result of a high-precision orbit propagation
///
#[pyclass(name = "propstats", module = "satkit")]
pub struct PyPropStats {
    /// Number of function evaluations
    ///
    /// Returns:
    ///     int: number of derivative function evalations used in propagation
    #[pyo3(get)]
    num_eval: u32,

    /// Number of accepted steps
    ///
    /// Returns:
    ///     int: number of accepted steps in propagation
    #[pyo3(get)]
    num_accept: u32,

    /// Number of rejected steps
    ///
    /// Returns:
    ///    int: number of rejected steps in propagation
    #[pyo3(get)]
    num_reject: u32,
}

#[pymethods]
impl PyPropStats {
    fn __str__(&self) -> String {
        format!("Propagation Statistics:\n  Function Evals: {}\n  Accepted Steps: {}\n  Rejected Steps: {}",
    self.num_eval, self.num_accept, self.num_reject)
    }
}

/// Propagation result
///
/// This class holds the result of a high-precision orbit propagation
///
/// The result includes the final state of the satellite, the time at which the state was computed,
/// and statistics about the propagation
///
/// The result may also include a dense ODE solution that can be used for interpolation of states
/// between the begin and end times
///
/// Attributes:
///
///    time_begin: satkit.time object representing the time at which the propagation began
///          time: satkit.time object representing the time at which the propagation ended
///         stats: satkit.propstats object with statistics about the propagation
///           pos: 3-element numpy array representing the final position of the satellite in GCRF meters
///           vel: 3-element numpy array representing the final velocity of the satellite in GCRF m/s
///         state: 6-element numpy array representing the final state of the satellite in GCRF,
///                a concatenation of pos and vel
///           phi: 6x6 numpy array representing the state transition matrix between
///                the begin and end times, if requested
///    can_interp: boolean indicating whether the result includes a dense ODE
///                solution that can be used for interpolation
///                of states between the begin and end times
///
#[pyclass(name = "propresult", module = "satkit", from_py_object)]
#[derive(Debug, Clone)]
pub struct PyPropResult(pub PyPropResultType);

fn to_string<const T: usize>(r: &PropagationResult<T>) -> String {
    let se = r.state_end.as_slice();
    let mut s = "Propagation Results\n".to_string();
    s.push_str(format!("  Time: {}\n", r.time_end).as_str());
    s.push_str(
        format!(
            "   Pos: [{:.3}, {:.3}, {:.3}] km\n",
            se[0] * 1.0e-3,
            se[1] * 1.0e-3,
            se[2] * 1.0e-3
        )
        .as_str(),
    );
    s.push_str(
        format!(
            "   Vel: [{:.3}, {:.3}, {:.3}] m/s\n",
            se[3], se[4], se[5]
        )
        .as_str(),
    );
    s.push_str("  Stats:\n");
    s.push_str(format!("       Function Evaluations: {}\n", r.num_eval).as_str());
    s.push_str(format!("             Accepted Steps: {}\n", r.accepted_steps).as_str());
    s.push_str(format!("             Rejected Steps: {}\n", r.rejected_steps).as_str());
    s.push_str(format!("   Can Interp: {}\n", r.odesol.is_some()).as_str());
    if r.odesol.is_some() {
        s.push_str(format!("        Begin Time: {}", r.time_begin).as_str());
    }
    s
}

#[pymethods]
impl PyPropResult {
    #[new]
    /// This should never be called and is here only for pickle support
    #[allow(clippy::new_without_default)]
    pub fn new() -> Self {
        Self(PyPropResultType::R1(Box::new(PropagationResult::<1> {
            time_begin: Instant::INVALID,
            state_begin: Vector::<6>::zeros(),
            time_end: Instant::INVALID,
            state_end: Vector::<6>::zeros(),
            num_eval: 0,
            accepted_steps: 0,
            rejected_steps: 0,
            odesol: None,
            gj_dense: None,
            integrator: satkit::orbitprop::Integrator::default(),
        })))
    }

    // Get begin time
    #[getter]
    fn time_begin(&self) -> PyInstant {
        PyInstant(match &self.0 {
            PyPropResultType::R1(r) => r.time_begin,
            PyPropResultType::R7(r) => r.time_begin,
        })
    }

    /// Get the end time
    #[getter]
    fn time(&self) -> PyInstant {
        PyInstant(match &self.0 {
            PyPropResultType::R1(r) => r.time_end,
            PyPropResultType::R7(r) => r.time_end,
        })
    }

    /// Get the end time
    #[getter]
    fn time_end(&self) -> PyInstant {
        PyInstant(match &self.0 {
            PyPropResultType::R1(r) => r.time_end,
            PyPropResultType::R7(r) => r.time_end,
        })
    }

    #[getter]
    fn stats(&self) -> PyPropStats {
        match &self.0 {
            PyPropResultType::R1(r) => PyPropStats {
                num_eval: r.num_eval,
                num_accept: r.accepted_steps,
                num_reject: r.rejected_steps,
            },
            PyPropResultType::R7(r) => PyPropStats {
                num_eval: r.num_eval,
                num_accept: r.accepted_steps,
                num_reject: r.rejected_steps,
            },
        }
    }

    #[getter]
    fn pos(&self) -> PyResult<Py<PyAny>> {
        pyo3::Python::attach(|py| -> PyResult<Py<PyAny>> {
            match &self.0 {
                PyPropResultType::R1(r) => np::ndarray::arr1(&r.state_end.as_slice()[0..3])
                    .to_pyarray(py)
                    .into_py_any(py),
                PyPropResultType::R7(r) => np::ndarray::arr1(&r.state_end.as_slice()[0..3])
                    .to_pyarray(py)
                    .into_py_any(py),
            }
        })
    }

    #[getter]
    fn vel(&self) -> PyResult<Py<PyAny>> {
        pyo3::Python::attach(|py| -> PyResult<Py<PyAny>> {
            match &self.0 {
                PyPropResultType::R1(r) => np::ndarray::arr1(&r.state_end.as_slice()[3..6])
                    .to_pyarray(py)
                    .into_py_any(py),
                PyPropResultType::R7(r) => {
                    let col0 = r.state_end.col(0);
                    np::ndarray::arr1(&col0.as_slice()[3..6])
                        .to_pyarray(py)
                        .into_py_any(py)
                }
            }
        })
    }

    #[getter]
    fn state(&self) -> PyResult<Py<PyAny>> {
        pyo3::Python::attach(|py| -> PyResult<Py<PyAny>> {
            match &self.0 {
                PyPropResultType::R1(r) => np::ndarray::arr1(r.state_end.as_slice())
                    .to_pyarray(py)
                    .into_py_any(py),
                PyPropResultType::R7(r) => np::ndarray::arr1(&r.state_end.as_slice()[0..6])
                    .to_pyarray(py)
                    .into_py_any(py),
            }
        })
    }

    #[getter]
    fn state_end(&self) -> PyResult<Py<PyAny>> {
        pyo3::Python::attach(|py| -> PyResult<Py<PyAny>> {
            match &self.0 {
                PyPropResultType::R1(r) => np::ndarray::arr1(r.state_end.as_slice())
                    .to_pyarray(py)
                    .into_py_any(py),
                PyPropResultType::R7(r) => np::ndarray::arr1(&r.state_end.as_slice()[0..6])
                    .to_pyarray(py)
                    .into_py_any(py),
            }
        })
    }

    #[getter]
    fn state_begin(&self) -> PyResult<Py<PyAny>> {
        pyo3::Python::attach(|py| -> PyResult<Py<PyAny>> {
            match &self.0 {
                PyPropResultType::R1(r) => np::ndarray::arr1(r.state_begin.as_slice())
                    .to_pyarray(py)
                    .into_py_any(py),
                PyPropResultType::R7(r) => np::ndarray::arr1(&r.state_begin.as_slice()[0..6])
                    .to_pyarray(py)
                    .into_py_any(py),
            }
        })
    }

    #[getter]
    fn phi(&self) -> PyResult<Py<PyAny>> {
        pyo3::Python::attach(|py| -> PyResult<Py<PyAny>> {
            match &self.0 {
                PyPropResultType::R1(_r) => Ok(py.None()),
                PyPropResultType::R7(r) => {
                    let phi = unsafe { np::PyArray2::<f64>::new(py, [6, 6], false) };
                    let rsphi = r.state_end.block::<6, 6>(0, 1).transpose();
                    unsafe {
                        std::ptr::copy_nonoverlapping(
                            rsphi.as_slice().as_ptr(),
                            phi.as_raw_array_mut().as_mut_ptr(),
                            36,
                        );
                    }
                    phi.into_py_any(py)
                }
            }
        })
    }

    fn __str__(&self) -> String {
        match &self.0 {
            PyPropResultType::R1(r) => to_string::<1>(r),
            PyPropResultType::R7(r) => to_string::<7>(r),
        }
    }

    #[getter]
    const fn can_interp(&self) -> bool {
        match &self.0 {
            PyPropResultType::R1(r) => r.odesol.is_some() || r.gj_dense.is_some(),
            PyPropResultType::R7(r) => r.odesol.is_some() || r.gj_dense.is_some(),
        }
    }

    fn __getnewargs_ex__<'a>(&self, py: Python<'a>) -> (Bound<'a, PyTuple>, Bound<'a, PyDict>) {
        let d = PyDict::new(py);
        let tp = PyTuple::empty(py);
        (tp, d)
    }

    fn __setstate__(&mut self, py: Python, state: Py<PyBytes>) -> PyResult<()> {
        let s = state.as_bytes(py);

        self.0 = serde_pickle::from_slice(s, serde_pickle::DeOptions::default()).unwrap();
        Ok(())
    }

    fn __getstate__(&mut self, py: Python) -> PyResult<Py<PyAny>> {
        let p = serde_pickle::to_vec(&self.0, serde_pickle::SerOptions::default()).unwrap();
        PyBytes::new(py, p.as_slice()).into_py_any(py)
    }

    #[pyo3(signature=(time, output_phi=false))]
    fn interp(&self, time: Bound<'_, PyAny>, output_phi: bool) -> PyResult<Py<PyAny>> {
        let is_list = time.is_instance_of::<pyo3::types::PyList>()
            || time.is_instance_of::<numpy::PyArray1<Py<PyAny>>>();

        let times = (&time).to_time_vec()?;

        if is_list && !output_phi {
            // Batch interpolation — returns Nx6 numpy array
            match &self.0 {
                PyPropResultType::R1(r) => {
                    let results = r.interp_batch(&times)
                        .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
                    pyo3::Python::attach(|py| {
                        let n = results.len();
                        let flat: Vec<f64> = results.iter().flat_map(|r| r.as_slice().iter().copied().take(6)).collect();
                        slice2py2d(py, &flat, n, 6)
                    })
                }
                PyPropResultType::R7(r) => {
                    let results = r.interp_batch(&times)
                        .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?;
                    pyo3::Python::attach(|py| {
                        let n = results.len();
                        let flat: Vec<f64> = results.iter().flat_map(|r| r.as_slice().iter().copied().take(6)).collect();
                        slice2py2d(py, &flat, n, 6)
                    })
                }
            }
        } else if is_list {
            // Fallback for output_phi=true — need per-element processing
            let results: PyResult<Vec<Py<PyAny>>> =
                times.iter().map(|t| self.interp_at(t, output_phi)).collect();
            pyo3::Python::attach(|py| results?.into_py_any(py))
        } else {
            self.interp_at(&times[0], output_phi)
        }
    }
}

impl PyPropResult {
    fn interp_at(&self, time: &Instant, output_phi: bool) -> PyResult<Py<PyAny>> {
        match &self.0 {
            PyPropResultType::R1(r) => match r.interp(time) {
                Ok(res) => pyo3::Python::attach(|py| -> PyResult<Py<PyAny>> { vec2py(py, &res) }),
                Err(e) => Err(pyo3::exceptions::PyValueError::new_err(e.to_string())),
            },
            PyPropResultType::R7(r) => match r.interp(time) {
                Ok(res) => {
                    if !output_phi {
                        pyo3::Python::attach(|py| -> PyResult<Py<PyAny>> {
                            slice2py1d(py, &res.as_slice()[0..6])
                        })
                    } else {
                        let rsphi = res.block::<6, 6>(0, 1).transpose();
                        pyo3::Python::attach(|py| -> PyResult<Py<PyAny>> {
                            (
                                slice2py1d(py, &res.as_slice()[0..6])?,
                                slice2py2d(py, rsphi.as_slice(), 6, 6)?,
                            )
                                .into_py_any(py)
                        })
                    }
                }
                Err(e) => Err(pyo3::exceptions::PyValueError::new_err(e.to_string())),
            },
        }
    }
}

#[cfg(test)]
mod test {
    use super::*;

    #[test]
    fn test_ser() {
        let sol = PyPropResult::new();
        println!("sol = {:?}", sol);
        let v = serde_pickle::to_vec(&sol.0, serde_pickle::SerOptions::default()).unwrap();
        let sol2 = PyPropResult(
            serde_pickle::from_slice(v.as_slice(), serde_pickle::DeOptions::default()).unwrap(),
        );
        println!("sol2 = {:?}", sol2);
    }
}
