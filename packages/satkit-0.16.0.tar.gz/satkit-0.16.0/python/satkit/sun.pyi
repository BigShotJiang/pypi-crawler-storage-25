"""
Astrodynamic calculations related to the sun
"""

from __future__ import annotations
import typing
import numpy.typing as npt
import numpy as np

import satkit

@typing.overload
def pos_gcrf(time: satkit.time) -> npt.NDArray[np.float64]:
    """
    Sun position in the Geocentric Celestial Reference Frame (GCRF)

    Algorithm 29 from Vallado for sun in Mean of Date (MOD), then rotated
    from MOD to GCRF via Equations 3-88 and 3-89 in Vallado

    Args:
        time (satkit.time): time at which to compute position

    Returns:
        npt.NDArray[np.float64]: 3-element numpy array representing sun position in GCRF frame
        at given time.  Units are meters

    Notes:
        From Vallado: Valid with accuracy of .01 degrees from 1950 to 2050

    Example:
        ```python
        import numpy as np
        t = satkit.time(2024, 6, 21)
        sun = satkit.sun.pos_gcrf(t)
        print(f"Sun distance: {np.linalg.norm(sun)/1e9:.3f} million km")
        ```
    """
    ...

@typing.overload
def pos_gcrf(
    time: npt.ArrayLike | list[satkit.time],
) -> npt.NDArray[np.float64]:
    """
    Sun position in the Geocentric Celestial Reference Frame (GCRF)

    Algorithm 29 from Vallado for sun in Mean of Date (MOD), then rotated
    from MOD to GCRF via Equations 3-88 and 3-89 in Vallado

    Args:
        time (npt.ArrayLike | list[satkit.time]): list or numpy array of satkit.time objects
            representing times at which to compute position

    Returns:
        npt.NDArray[np.float64]: Nx3 numpy array representing sun position in GCRF frame
        at the "N" given times.  Units are meters

    Notes:
        From Vallado: Valid with accuracy of .01 degrees from 1950 to 2050
    """
    ...

def pos_gcrf(*args, **kwargs):
    """
    Sun position in the Geocentric Celestial Reference Frame (GCRF)

    Algorithm 29 from Vallado for sun in Mean of Date (MOD), then rotated
    from MOD to GCRF via Equations 3-88 and 3-89 in Vallado

    Args:
        time (satkit.time): time at which to compute position

    Returns:
        3-element numpy array representing sun position in GCRF frame
        at given time.  Units are meters

    Notes:
        From Vallado: Valid with accuracy of .01 degrees from 1950 to 2050

    Example:
        ```python
        import numpy as np
        t = satkit.time(2024, 6, 21)
        sun = satkit.sun.pos_gcrf(t)
        print(f"Sun distance: {np.linalg.norm(sun)/1e9:.3f} million km")
        ```
    """
    ...

@typing.overload
def pos_mod(time: satkit.time) -> npt.NDArray[np.float64]:
    """
    Sun position in the Mean-of-Date Frame

    Algorithm 29 from Vallado for sun in Mean of Date (MOD)

    Args:
        time (satkit.time): time at which to compute position

    Returns:
        npt.NDArray[np.float64]: 3-element numpy array representing sun position in MOD frame
        at given time.  Units are meters

    Notes:
        From Vallado: Valid with accuracy of .01 degrees from 1950 to 2050
    """
    ...

@typing.overload
def pos_mod(
    time: npt.ArrayLike | list[satkit.time],
) -> npt.NDArray[np.float64]:
    """
    Sun position in the Mean-of-Date Frame

    Algorithm 29 from Vallado for sun in Mean of Date (MOD)

    Args:
        time (npt.ArrayLike | list[satkit.time]): list or numpy array of satkit.time objects,
             representing times at which to compute positions

    Returns:
        npt.NDArray[np.float64]: Nx3 numpy array representing sun position in MOD frame
        at given times.  Units are meters

    Notes:
        From Vallado: Valid with accuracy of .01 degrees from 1950 to 2050
    """
    ...

def pos_mod(*args, **kwargs):
    """
    Sun position in the Mean-of-Date Frame

    Algorithm 29 from Vallado for sun in Mean of Date (MOD)

    Args:
        time (satkit.time): time at which to compute position

    Returns:
        3-element numpy array representing sun position in MOD frame
        at given time.  Units are meters

    Notes:
        From Vallado: Valid with accuracy of .01 degrees from 1950 to 2050
    """
    ...

def rise_set(
    time: satkit.time, coord: satkit.itrfcoord, sigma: float = 90.0 + 50.0 / 60.0
) -> tuple[satkit.time, satkit.time]:
    """
    Sunrise and sunset times on the day given by input time
    and at the given location.

    Time is a "date" at location, and should have hours, minutes, and seconds
    set to zero

    Vallado Algorithm 30

    Args:
        time (satkit.time): date for which to compute sunrise & sunset
        coord (satkit.itrfcoord): location for which to compute sunrise & sunset
        sigma (float, optional): angle in degrees between noon & rise/set.
            Common Values:
                        "Standard": 90 deg, 50 arcmin (90.0+50.0/60.0)
                    "Civil Twilight": 96 deg
                "Nautical Twilight": 102 deg
            "Astronomical Twilight": 108 deg

            If not passed in, "Standard" is used (90.0 + 50.0/60.0)

    Returns:
        tuple[satkit.time, satkit.time]: (sunrise, sunset)

    Example:
        ```python
        coord = satkit.itrfcoord(latitude_deg=42.36, longitude_deg=-71.06, altitude=0)
        t = satkit.time.from_date(2024, 6, 21)
        sunrise, sunset = satkit.sun.rise_set(t, coord)
        print(f"Sunrise: {sunrise}")
        print(f"Sunset:  {sunset}")
        ```
    """
    ...

def shadowfunc(
    sunpos: npt.NDArray[np.float64], satpos: npt.NDArray[np.float64]
) -> float:
    """
    Is satellite in Earth shadow given sun position

    Args:
        sunpos (npt.NDArray[np.float64]): geocentric Sun position, meters
        satpos (npt.NDArray[np.float64]): geocentric satellite position, meters

    Notes:
        - See algorithm in Section 3.4.2 of Montenbruck and Gill for calculation

    Returns:
        float: number in range [0,1] indicating no sun or full sun (no occlusion) hitting satellite

    Example:
        ```python
        t = satkit.time(2024, 1, 1)
        sun = satkit.sun.pos_gcrf(t)
        sat_pos = np.array([6.781e6, 0, 0])  # satellite position, GCRF, meters
        shadow = satkit.sun.shadowfunc(sun, sat_pos)
        if shadow < 0.01:
            print("Satellite is in Earth shadow")
        else:
            print(f"Illumination fraction: {shadow:.2f}")
        ```
    """
    ...
