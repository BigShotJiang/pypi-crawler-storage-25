from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.widgets import CustomTemplateWidget

from ..config import DbPurgeConfig
from ..service import inspect_tables

router = APIRouter()


@router.get("/", response_class=HTMLResponse, name="db_purge_dashboard")
async def dashboard(
    request: Request,
    hide_excluded: bool = Query(False),
    view_builder=Depends(get_view_builder),
    db=Depends(get_db),
):
    tables = inspect_tables(db, show_excluded=not hide_excluded)

    # Always count excluded from the full list so the toggle stays visible
    if hide_excluded:
        all_tables = inspect_tables(db, show_excluded=True)
        excluded_count = sum(1 for t in all_tables if t["excluded"])
    else:
        excluded_count = sum(1 for t in tables if t["excluded"])
    active_count = sum(1 for t in tables if t["has_rule"] and t["enabled"])

    config = DbPurgeConfig()
    base_url = str(request.url_for("db_purge_dashboard")).rstrip("/")
    return view_builder.generate(
        request,
        title="DB Purge",
        widgets=[
            CustomTemplateWidget(
                template_name="db_purge/index.html.j2",
                context={
                    "tables": tables,
                    "base_url": base_url,
                    "excluded_count": excluded_count,
                    "active_count": active_count,
                    "hide_excluded": hide_excluded,
                    "global_retention_days": config.default_retention_days,
                    "global_batch_size": config.batch_size,
                    "auto_purge_enabled": config.auto_purge_enabled,
                    "auto_purge_cron": config.auto_purge_cron,
                },
            )
        ],
    )
