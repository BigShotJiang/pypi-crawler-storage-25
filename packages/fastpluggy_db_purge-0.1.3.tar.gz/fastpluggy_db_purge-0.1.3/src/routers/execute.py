from fastapi import APIRouter, Depends, Request, Form, Query
from fastapi.responses import HTMLResponse, RedirectResponse
from starlette import status

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.widgets import CustomTemplateWidget

from ..config import DbPurgeConfig
from ..models import PurgeRuleDB, PurgeLogDB
from ..service import execute_purge, get_declared_targets

router = APIRouter()


@router.post("/purge", name="db_purge_execute")
async def purge(
    request: Request,
    table_name: str = Form(...),
    dry_run: bool = Form(True),
    db=Depends(get_db),
):
    config = DbPurgeConfig()
    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == table_name).first()

    # Enforce disabled rule at endpoint level
    if rule and not rule.enabled:
        FlashMessage.add(request, message=f"Purge rule for {table_name} is disabled", category="warning")
        return RedirectResponse(
            url=request.url_for("db_purge_dashboard"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    if rule and rule.excluded:
        FlashMessage.add(request, message=f"Table {table_name} is excluded from purge", category="warning")
        return RedirectResponse(
            url=request.url_for("db_purge_dashboard"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    # Resolve retention_days and timestamp_column: rule > plugin-declared > global default
    declared = get_declared_targets()
    decl = declared.get(table_name)

    timestamp_column = (
        (rule.timestamp_column if rule and rule.timestamp_column else None)
        or (decl["timestamp_column"] if decl else None)
        or "updated_at"
    )
    retention_days = (
        (rule.retention_days if rule and rule.retention_days is not None else None)
        or (decl["default_retention_days"] if decl else None)
        or config.default_retention_days
    )

    result = execute_purge(
        db=db,
        table_name=table_name,
        retention_days=retention_days,
        timestamp_column=timestamp_column,
        batch_size=config.batch_size,
        dry_run=dry_run,
        executed_by="admin",
    )

    if result["status"] == "success":
        action = "Would delete" if dry_run else "Deleted"
        deleted = result["rows_deleted"]
        total = result.get("total_rows")
        msg = f"{action} {deleted:,} rows from {table_name}"
        if total is not None and total > 0:
            pct = deleted / total * 100
            keeping = total - deleted
            msg += f" ({pct:.1f}% of {total:,} — keeping {keeping:,})"
        msg += f" ({result['duration_ms']}ms)"
        FlashMessage.add(
            request,
            message=msg,
            category="info" if dry_run else "success",
        )
    else:
        FlashMessage.add(request, message=f"Purge failed: {result['error_message']}", category="danger")

    return RedirectResponse(
        url=request.url_for("db_purge_dashboard"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/purge-all", name="db_purge_execute_all")
async def purge_all(
    request: Request,
    db=Depends(get_db),
):
    config = DbPurgeConfig()
    rules = db.query(PurgeRuleDB).filter(PurgeRuleDB.enabled == True).all()
    if not rules:
        FlashMessage.add(request, message="No active purge rules", category="warning")
        return RedirectResponse(
            url=request.url_for("db_purge_dashboard"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    total_deleted = 0
    errors = 0
    for rule in rules:
        result = execute_purge(
            db=db,
            table_name=rule.table_name,
            retention_days=rule.retention_days,
            timestamp_column=rule.timestamp_column,
            batch_size=config.batch_size,
            dry_run=False,
            executed_by="admin-bulk",
        )
        total_deleted += result["rows_deleted"]
        if result["status"] != "success":
            errors += 1

    msg = f"Purged {total_deleted:,} rows across {len(rules)} tables"
    if errors:
        msg += f" ({errors} errors)"
    FlashMessage.add(request, message=msg, category="success" if not errors else "warning")
    return RedirectResponse(
        url=request.url_for("db_purge_dashboard"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/toggle-auto-purge", name="db_purge_toggle_auto")
async def toggle_auto_purge(
    request: Request,
    db=Depends(get_db),
):
    from fastpluggy.core.repository.app_settings import set_app_setting

    config = DbPurgeConfig()
    new_value = not config.auto_purge_enabled
    set_app_setting(db, config, "auto_purge_enabled", new_value)

    state = "enabled" if new_value else "disabled"
    FlashMessage.add(request, message=f"Auto-purge {state}", category="success")
    return RedirectResponse(
        url=request.url_for("db_purge_dashboard"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get("/history", response_class=HTMLResponse, name="db_purge_history")
async def history(
    request: Request,
    table_name: str = Query(None),
    view_builder=Depends(get_view_builder),
    db=Depends(get_db),
):
    query = db.query(PurgeLogDB).order_by(PurgeLogDB.executed_at.desc())
    if table_name:
        query = query.filter(PurgeLogDB.table_name == table_name)
    logs = query.limit(100).all()

    base_url = str(request.url_for("db_purge_dashboard")).rstrip("/")
    return view_builder.generate(
        request,
        title="Purge History",
        widgets=[
            CustomTemplateWidget(
                template_name="db_purge/history.html.j2",
                context={
                    "logs": logs,
                    "filter_table": table_name,
                    "base_url": base_url,
                },
            )
        ],
    )
