from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from starlette import status

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.flash import FlashMessage
from fastpluggy.core.widgets import CustomTemplateWidget

from ..models import PurgeRuleDB

router = APIRouter()


@router.get("/rules/{table_name}", response_class=HTMLResponse, name="db_purge_rule_edit")
async def rule_edit(
    table_name: str,
    request: Request,
    view_builder=Depends(get_view_builder),
    db=Depends(get_db),
):
    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == table_name).first()
    base_url = str(request.url_for("db_purge_dashboard")).rstrip("/")
    return view_builder.generate(
        request,
        title=f"Purge Rule — {table_name}",
        widgets=[
            CustomTemplateWidget(
                template_name="db_purge/rule_form.html.j2",
                context={
                    "table_name": table_name,
                    "rule": rule,
                    "base_url": base_url,
                },
            )
        ],
    )


@router.post("/rules/{table_name}", name="db_purge_rule_save")
async def rule_save(
    table_name: str,
    request: Request,
    timestamp_column: str = Form(...),
    retention_days: int = Form(30),
    enabled: bool = Form(False),
    db=Depends(get_db),
):
    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == table_name).first()
    if rule:
        rule.timestamp_column = timestamp_column
        rule.retention_days = retention_days
        rule.enabled = enabled
    else:
        rule = PurgeRuleDB(
            table_name=table_name,
            timestamp_column=timestamp_column,
            retention_days=retention_days,
            enabled=enabled,
        )
        db.add(rule)
    db.commit()
    FlashMessage.add(request, message=f"Rule saved for {table_name}", category="success")
    return RedirectResponse(
        url=request.url_for("db_purge_dashboard"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/rules/{table_name}/delete", name="db_purge_rule_delete")
async def rule_delete(
    table_name: str,
    request: Request,
    db=Depends(get_db),
):
    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == table_name).first()
    if rule:
        db.delete(rule)
        db.commit()
        FlashMessage.add(request, message=f"Rule deleted for {table_name}", category="success")
    return RedirectResponse(
        url=request.url_for("db_purge_dashboard"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/exclude/{table_name}", name="db_purge_exclude_toggle")
async def exclude_toggle(
    table_name: str,
    request: Request,
    exclude: str = Form("true"),
    db=Depends(get_db),
):
    should_exclude = exclude.lower() in ("true", "1", "yes")
    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == table_name).first()
    if should_exclude:
        if rule:
            rule.excluded = True
        else:
            rule = PurgeRuleDB(table_name=table_name, excluded=True, enabled=False)
            db.add(rule)
        db.commit()
        FlashMessage.add(request, message=f"Table {table_name} excluded", category="info")
    else:
        if rule:
            rule.excluded = False
            db.commit()
        FlashMessage.add(request, message=f"Table {table_name} included", category="success")
    return RedirectResponse(
        url=request.url_for("db_purge_dashboard"),
        status_code=status.HTTP_303_SEE_OTHER,
    )
