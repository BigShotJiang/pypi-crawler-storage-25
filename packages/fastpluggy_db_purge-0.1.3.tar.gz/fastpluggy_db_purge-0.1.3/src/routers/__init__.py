from fastapi import APIRouter, Depends

from fastpluggy.core.auth import require_authentication
from .dashboard import router as dashboard_router
from .rules import router as rules_router
from .execute import router as execute_router

db_purge_router = APIRouter(dependencies=[Depends(require_authentication)])
db_purge_router.include_router(dashboard_router)
db_purge_router.include_router(rules_router)
db_purge_router.include_router(execute_router)
