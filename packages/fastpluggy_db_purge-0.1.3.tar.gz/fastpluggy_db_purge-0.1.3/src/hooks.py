"""
Hook system for fp_purge_targets.

Plugins declare purgeable tables by calling register_purge_target() during
their on_load_complete(). The db_purge plugin reads these via GlobalRegistry.

Example usage in another plugin's on_load_complete():

    from fastpluggy_plugin.db_purge.hooks import register_purge_target
    register_purge_target("task_reports", "end_time", default_retention_days=30)

Or directly via GlobalRegistry:

    from fastpluggy.core.global_registry import GlobalRegistry
    GlobalRegistry.extend_globals("purge_targets", [{
        "table": "task_reports",
        "timestamp_column": "end_time",
        "default_retention_days": 30,
    }])
"""

from fastpluggy.core.global_registry import GlobalRegistry


def register_purge_target(
    table: str,
    timestamp_column: str,
    default_retention_days: int = 30,
) -> None:
    """Register a table as purgeable. Called by plugins during load."""
    GlobalRegistry.extend_globals("purge_targets", [{
        "table": table,
        "timestamp_column": timestamp_column,
        "default_retention_days": default_retention_days,
    }])
