from fastpluggy.core.config import BaseDatabaseSettings


class DbPurgeConfig(BaseDatabaseSettings):
    default_retention_days: int = 30
    batch_size: int = 5000
    dry_run_by_default: bool = True
    auto_purge_enabled: bool = False
    auto_purge_cron: str = "0 4 * * *"
