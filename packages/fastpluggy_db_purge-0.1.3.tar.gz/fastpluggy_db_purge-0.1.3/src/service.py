import logging
import time
from datetime import datetime, timedelta, timezone

from sqlalchemy import text
from sqlalchemy.orm import Session

from .config import DbPurgeConfig
from .models import PurgeRuleDB, PurgeLogDB

logger = logging.getLogger(__name__)


def get_declared_targets() -> dict[str, dict]:
    """Collect purge targets declared by plugins via GlobalRegistry."""
    try:
        from fastpluggy.core.global_registry import GlobalRegistry
        targets = GlobalRegistry.get_global("purge_targets", [])
    except ImportError:
        targets = []
    return {t["table"]: t for t in targets if "table" in t}


def inspect_tables(db: Session, *, show_excluded: bool = False) -> list[dict]:
    """List all user tables with row counts, sizes, and policy status.

    Tables marked as excluded are hidden unless show_excluded is True.
    """
    query = text("""
        SELECT
            t.table_name,
            t.table_type,
            COALESCE(
                pg_total_relation_size(quote_ident(t.table_name)::regclass), 0
            ) AS total_bytes
        FROM information_schema.tables t
        WHERE t.table_schema = 'public'
          AND t.table_type = 'BASE TABLE'
        ORDER BY t.table_name
    """)
    try:
        rows = db.execute(query).mappings().all()
    except Exception:
        # Fallback for SQLite (no pg_total_relation_size)
        query = text("""
            SELECT name AS table_name, 'BASE TABLE' AS table_type, 0 AS total_bytes
            FROM sqlite_master
            WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
            ORDER BY name
        """)
        rows = db.execute(query).mappings().all()

    rules = {r.table_name: r for r in db.query(PurgeRuleDB).all()}
    declared = get_declared_targets()

    # Get last purge date per table
    last_purge_query = (
        db.query(PurgeLogDB.table_name, PurgeLogDB.executed_at, PurgeLogDB.rows_deleted)
        .filter(PurgeLogDB.dry_run == False, PurgeLogDB.status == "success")
        .order_by(PurgeLogDB.executed_at.desc())
        .all()
    )
    last_purge = {}
    for lp in last_purge_query:
        if lp.table_name not in last_purge:
            last_purge[lp.table_name] = {
                "executed_at": lp.executed_at,
                "rows_deleted": lp.rows_deleted,
            }

    # Get row counts per table
    tables = []
    for row in rows:
        table_name = row["table_name"]
        rule = rules.get(table_name)

        # Filter excluded tables
        if rule and rule.excluded and not show_excluded:
            continue

        try:
            count_result = db.execute(
                text(f"SELECT COUNT(*) AS cnt FROM {_quote_identifier(table_name)}")
            ).scalar()
        except Exception:
            count_result = None

        lp_info = last_purge.get(table_name)
        decl = declared.get(table_name)

        # Merge: admin rule overrides plugin-declared defaults
        timestamp_col = (rule.timestamp_column if rule and rule.timestamp_column
                         else decl["timestamp_column"] if decl else None)
        retention = (rule.retention_days if rule and rule.retention_days is not None
                     else decl["default_retention_days"] if decl else None)
        enabled = rule.enabled if rule else False

        tables.append({
            "table_name": table_name,
            "row_count": count_result,
            "total_bytes": row["total_bytes"],
            "size_display": _format_bytes(row["total_bytes"]),
            "has_rule": rule is not None,
            "declared_by_plugin": decl is not None,
            "retention_days": retention,
            "timestamp_column": timestamp_col,
            "enabled": enabled,
            "excluded": rule.excluded if rule else False,
            "last_purge_at": lp_info["executed_at"] if lp_info else None,
            "last_purge_rows": lp_info["rows_deleted"] if lp_info else None,
        })

    return tables


def estimate_purge(db: Session, table_name: str, retention_days: int, timestamp_column: str) -> int:
    """Estimate how many rows would be deleted."""
    cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
    query = text(
        f"SELECT COUNT(*) FROM {_quote_identifier(table_name)} "
        f"WHERE {_quote_identifier(timestamp_column)} < :cutoff"
    )
    result = db.execute(query, {"cutoff": cutoff}).scalar()
    return result or 0


def execute_purge(
    db: Session,
    table_name: str,
    retention_days: int,
    timestamp_column: str,
    batch_size: int = 5000,
    dry_run: bool = True,
    executed_by: str = "admin",
) -> dict:
    """Execute a purge on a table. Returns purge result dict."""
    config = DbPurgeConfig()
    if batch_size <= 0:
        batch_size = config.batch_size

    cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
    total_deleted = 0
    start = time.monotonic()
    status = "success"
    error_message = None

    # Total row count (for dry-run reporting: % deleted, rows kept)
    try:
        total_rows = db.execute(
            text(f"SELECT COUNT(*) FROM {_quote_identifier(table_name)}")
        ).scalar() or 0
    except Exception:
        total_rows = None

    try:
        if dry_run:
            total_deleted = estimate_purge(db, table_name, retention_days, timestamp_column)
        else:
            while True:
                # Batched delete
                delete_query = text(
                    f"DELETE FROM {_quote_identifier(table_name)} "
                    f"WHERE {_quote_identifier(timestamp_column)} < :cutoff "
                    f"LIMIT :batch_size"
                )
                try:
                    result = db.execute(delete_query, {"cutoff": cutoff, "batch_size": batch_size})
                except Exception:
                    # PostgreSQL doesn't support LIMIT in DELETE — use ctid subquery
                    delete_query = text(
                        f"DELETE FROM {_quote_identifier(table_name)} "
                        f"WHERE ctid IN ("
                        f"  SELECT ctid FROM {_quote_identifier(table_name)} "
                        f"  WHERE {_quote_identifier(timestamp_column)} < :cutoff "
                        f"  LIMIT :batch_size"
                        f")"
                    )
                    result = db.execute(delete_query, {"cutoff": cutoff, "batch_size": batch_size})

                deleted = result.rowcount
                db.commit()
                total_deleted += deleted
                logger.info("Purge %s: deleted %d rows (total: %d)", table_name, deleted, total_deleted)
                if deleted < batch_size:
                    break
    except Exception as e:
        status = "error"
        error_message = str(e)
        logger.error("Purge %s failed: %s", table_name, e)

    duration_ms = int((time.monotonic() - start) * 1000)

    # Record in audit log
    log_entry = PurgeLogDB(
        table_name=table_name,
        rows_deleted=total_deleted,
        dry_run=dry_run,
        duration_ms=duration_ms,
        executed_by=executed_by,
        status=status,
        error_message=error_message,
    )
    db.add(log_entry)
    db.commit()

    return {
        "table_name": table_name,
        "rows_deleted": total_deleted,
        "total_rows": total_rows,
        "dry_run": dry_run,
        "duration_ms": duration_ms,
        "status": status,
        "error_message": error_message,
    }


def _quote_identifier(name: str) -> str:
    """Sanitize a SQL identifier to prevent injection."""
    if not name.isidentifier() and not all(c.isalnum() or c == '_' for c in name):
        raise ValueError(f"Invalid identifier: {name}")
    return f'"{name}"'


def _format_bytes(num_bytes: int) -> str:
    """Format bytes into human-readable string."""
    if num_bytes == 0:
        return "0 B"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(num_bytes) < 1024:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.1f} PB"
