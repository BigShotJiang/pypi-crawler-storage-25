from typing import Annotated, Any

from fastpluggy.core.module_base import FastPluggyBaseModule
from fastpluggy.core.tools.inspect_tools import InjectDependency

from .config import DbPurgeConfig


def get_db_purge_router():
    from .routers import db_purge_router
    return db_purge_router


class DbPurgePlugin(FastPluggyBaseModule):
    module_name: str = "db_purge"
    module_version: str = "0.1.0"

    module_menu_name: str = "DB Purge"
    module_menu_icon: str = "ti ti-trash"
    module_menu_type: str = "admin"

    module_settings: Any = DbPurgeConfig
    module_router: Any = get_db_purge_router

    depends_on: dict = {}

    optional_dependencies: dict = {
        "tasks_worker": ">=0.1.0",
    }

    def on_load_complete(self, fast_pluggy: Annotated["FastPluggy", InjectDependency]) -> None:
        from fastpluggy.core.database import create_table_if_not_exist
        from .models import PurgeRuleDB, PurgeLogDB
        create_table_if_not_exist(PurgeRuleDB)
        create_table_if_not_exist(PurgeLogDB)

        # Register scheduled purge task if tasks_worker is available
        config = DbPurgeConfig()
        if config.auto_purge_enabled:
            try:
                from .tasks import db_purge_all
                from fastpluggy_plugin.tasks_worker import TaskWorker
                TaskWorker.add_scheduled_task(
                    function=db_purge_all,
                    task_name="db_purge_all",
                    cron=config.auto_purge_cron,
                )
            except ImportError:
                pass
