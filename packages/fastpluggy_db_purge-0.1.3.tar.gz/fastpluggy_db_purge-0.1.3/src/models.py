from sqlalchemy import Column, String, Integer, Boolean, DateTime, Text, func

from fastpluggy.core.database import Base


class PurgeRuleDB(Base):
    """Per-table retention configuration (admin-managed)."""
    __tablename__ = "fp_purge_rules"
    __table_args__ = {"extend_existing": True}

    table_name = Column(String(200), unique=True, nullable=False, index=True)
    timestamp_column = Column(String(200), nullable=True)
    retention_days = Column(Integer, nullable=True, default=30)
    enabled = Column(Boolean, nullable=False, default=True)
    excluded = Column(Boolean, nullable=False, default=False)


class PurgeLogDB(Base):
    """Audit trail of purge runs."""
    __tablename__ = "fp_purge_logs"
    __table_args__ = {"extend_existing": True}

    table_name = Column(String(200), nullable=False, index=True)
    rows_deleted = Column(Integer, nullable=False, default=0)
    dry_run = Column(Boolean, nullable=False, default=False)
    duration_ms = Column(Integer, nullable=True)
    executed_at = Column(DateTime, nullable=False, default=func.now())
    executed_by = Column(String(200), nullable=True)
    status = Column(String(50), nullable=False, default="success")
    error_message = Column(Text, nullable=True)
