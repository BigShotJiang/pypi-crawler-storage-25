import pytest
from sqlalchemy import text

from fastpluggy.core.global_registry import GlobalRegistry
from fastpluggy_plugin.db_purge.models import PurgeRuleDB
from fastpluggy_plugin.db_purge.service import (
    _format_bytes,
    _quote_identifier,
    get_declared_targets,
    inspect_tables,
)


# ---------------------------------------------------------------------------
# _quote_identifier
# ---------------------------------------------------------------------------

class TestQuoteIdentifier:
    def test_valid_simple(self):
        assert _quote_identifier("users") == '"users"'

    def test_valid_with_underscore(self):
        assert _quote_identifier("my_table") == '"my_table"'

    def test_valid_single_char(self):
        assert _quote_identifier("x") == '"x"'

    def test_invalid_with_spaces(self):
        with pytest.raises(ValueError, match="Invalid identifier"):
            _quote_identifier("bad table")

    def test_invalid_with_semicolon(self):
        with pytest.raises(ValueError, match="Invalid identifier"):
            _quote_identifier("users; DROP TABLE")

    def test_invalid_with_dash(self):
        with pytest.raises(ValueError, match="Invalid identifier"):
            _quote_identifier("my-table")

    def test_empty_string_passes(self):
        # Empty string: isidentifier() is False, but all() on empty is True
        # so the implementation allows it through (vacuous truth).
        assert _quote_identifier("") == '""'


# ---------------------------------------------------------------------------
# _format_bytes
# ---------------------------------------------------------------------------

class TestFormatBytes:
    def test_zero(self):
        assert _format_bytes(0) == "0 B"

    def test_bytes(self):
        assert _format_bytes(500) == "500.0 B"

    def test_kilobytes(self):
        assert _format_bytes(1024) == "1.0 KB"

    def test_megabytes(self):
        assert _format_bytes(1048576) == "1.0 MB"

    def test_gigabytes(self):
        assert _format_bytes(1073741824) == "1.0 GB"

    def test_terabytes(self):
        assert _format_bytes(1099511627776) == "1.0 TB"

    def test_petabytes(self):
        assert _format_bytes(1125899906842624) == "1.0 PB"

    def test_fractional(self):
        result = _format_bytes(1536)
        assert result == "1.5 KB"


# ---------------------------------------------------------------------------
# get_declared_targets
# ---------------------------------------------------------------------------

class TestGetDeclaredTargets:
    def setup_method(self):
        GlobalRegistry.clear_globals_key("purge_targets")

    def test_empty(self):
        result = get_declared_targets()
        assert result == {}

    def test_with_data(self):
        GlobalRegistry.extend_globals("purge_targets", [
            {
                "table": "foo",
                "timestamp_column": "ts",
                "default_retention_days": 7,
            },
        ])
        result = get_declared_targets()
        assert "foo" in result
        assert result["foo"]["timestamp_column"] == "ts"
        assert result["foo"]["default_retention_days"] == 7

    def test_multiple_targets(self):
        GlobalRegistry.extend_globals("purge_targets", [
            {"table": "alpha", "timestamp_column": "created_at", "default_retention_days": 30},
            {"table": "beta", "timestamp_column": "logged_at", "default_retention_days": 14},
        ])
        result = get_declared_targets()
        assert len(result) == 2
        assert "alpha" in result
        assert "beta" in result

    def test_entry_without_table_key_is_skipped(self):
        GlobalRegistry.extend_globals("purge_targets", [
            {"no_table_key": True, "timestamp_column": "ts"},
            {"table": "valid", "timestamp_column": "ts", "default_retention_days": 7},
        ])
        result = get_declared_targets()
        assert len(result) == 1
        assert "valid" in result


# ---------------------------------------------------------------------------
# inspect_tables
# ---------------------------------------------------------------------------

class TestInspectTables:
    def test_lists_tables(self, db):
        """Tables created by the test fixtures should appear in the listing."""
        tables = inspect_tables(db)
        table_names = [t["table_name"] for t in tables]
        assert "fp_purge_rules" in table_names
        assert "fp_purge_logs" in table_names

    def test_row_count_zero_on_empty_table(self, db):
        tables = inspect_tables(db)
        rules_table = next(t for t in tables if t["table_name"] == "fp_purge_rules")
        assert rules_table["row_count"] == 0

    def test_excludes_hidden_tables(self, db):
        """A table marked excluded=True is hidden when show_excluded=False."""
        # Create a test table so it shows up in sqlite_master
        db.execute(text("CREATE TABLE some_table (id INTEGER PRIMARY KEY, val TEXT)"))
        db.commit()

        # Mark it excluded via a PurgeRuleDB entry
        rule = PurgeRuleDB(table_name="some_table", excluded=True, enabled=False)
        db.add(rule)
        db.commit()

        tables = inspect_tables(db, show_excluded=False)
        assert not any(t["table_name"] == "some_table" for t in tables)

    def test_show_excluded_includes_hidden(self, db):
        """When show_excluded=True the excluded table should appear."""
        db.execute(text("CREATE TABLE hidden_table (id INTEGER PRIMARY KEY)"))
        db.commit()

        rule = PurgeRuleDB(table_name="hidden_table", excluded=True, enabled=False)
        db.add(rule)
        db.commit()

        tables = inspect_tables(db, show_excluded=True)
        assert any(t["table_name"] == "hidden_table" for t in tables)

    def test_table_without_rule_has_defaults(self, db):
        """A table with no PurgeRuleDB entry should report has_rule=False."""
        tables = inspect_tables(db)
        logs_table = next(t for t in tables if t["table_name"] == "fp_purge_logs")
        assert logs_table["has_rule"] is False
        assert logs_table["enabled"] is False
        assert logs_table["excluded"] is False

    def test_custom_table_appears(self, db):
        """A dynamically created table should be discovered."""
        db.execute(text("CREATE TABLE my_events (id INTEGER PRIMARY KEY, ts TEXT)"))
        db.commit()

        tables = inspect_tables(db)
        table_names = [t["table_name"] for t in tables]
        assert "my_events" in table_names
