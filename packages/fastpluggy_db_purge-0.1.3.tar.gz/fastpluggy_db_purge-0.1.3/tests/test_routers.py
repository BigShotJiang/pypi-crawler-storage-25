import pytest
from unittest.mock import patch
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.orm import Session

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy_plugin.db_purge.routers import db_purge_router
from fastpluggy_plugin.db_purge.models import PurgeRuleDB, PurgeLogDB


class MockViewBuilder:
    """Capture widget context for assertions."""

    def __init__(self):
        self.last_title = None
        self.last_context = None

    def generate(self, request, title, widgets, context=None):
        self.last_title = title
        if widgets:
            self.last_context = getattr(widgets[0], "context", {})
        return HTMLResponse(content=f"<html><body><h1>{title}</h1></body></html>")


@pytest.fixture
def view_builder():
    return MockViewBuilder()


@pytest.fixture
def app(db, view_builder):
    app = FastAPI()
    app.include_router(db_purge_router)
    app.dependency_overrides[get_db] = lambda: db

    app.dependency_overrides[get_view_builder] = lambda: view_builder

    from fastpluggy.core.auth import require_authentication
    app.dependency_overrides[require_authentication] = lambda: True

    return app


@pytest.fixture
def client(app):
    return TestClient(app)


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


def test_dashboard_returns_200(client):
    response = client.get("/")
    assert response.status_code == 200
    assert "DB Purge" in response.text


def test_dashboard_passes_tables_context(client, view_builder, db):
    # Create a real table so inspect_tables finds something
    db.execute(text("CREATE TABLE IF NOT EXISTS demo_tbl (id INTEGER PRIMARY KEY)"))
    db.commit()

    client.get("/")
    ctx = view_builder.last_context
    assert "tables" in ctx
    assert "hide_excluded" in ctx
    assert "active_count" in ctx
    assert "excluded_count" in ctx


def test_dashboard_hide_excluded_filter(client, view_builder, db):
    db.execute(text("CREATE TABLE IF NOT EXISTS hidden_tbl (id INTEGER PRIMARY KEY)"))
    db.commit()

    rule = PurgeRuleDB(table_name="hidden_tbl", excluded=True, enabled=False)
    db.add(rule)
    db.commit()

    # Without filter — excluded tables still in list
    client.get("/")
    table_names = [t["table_name"] for t in view_builder.last_context["tables"]]
    assert "hidden_tbl" in table_names

    # With filter
    client.get("/?hide_excluded=true")
    table_names = [t["table_name"] for t in view_builder.last_context["tables"]]
    assert "hidden_tbl" not in table_names


def test_dashboard_active_count(client, view_builder, db):
    db.execute(text("CREATE TABLE IF NOT EXISTS active_tbl (id INTEGER PRIMARY KEY)"))
    db.commit()
    db.add(PurgeRuleDB(table_name="active_tbl", timestamp_column="id", enabled=True))
    db.commit()

    client.get("/")
    assert view_builder.last_context["active_count"] == 1


# ---------------------------------------------------------------------------
# Rules CRUD
# ---------------------------------------------------------------------------


def test_rule_edit_renders_form(client, view_builder):
    response = client.get("/rules/some_table")
    assert response.status_code == 200
    assert view_builder.last_title == "Purge Rule — some_table"
    assert view_builder.last_context["table_name"] == "some_table"


def test_rule_edit_includes_existing_rule(client, view_builder, db):
    db.add(PurgeRuleDB(table_name="cfg_tbl", timestamp_column="ts", retention_days=7, enabled=True))
    db.commit()

    client.get("/rules/cfg_tbl")
    rule = view_builder.last_context["rule"]
    assert rule is not None
    assert rule.retention_days == 7
    assert rule.timestamp_column == "ts"


def test_rule_save_creates_new(client, db):
    response = client.post(
        "/rules/brand_new",
        data={"timestamp_column": "created_at", "retention_days": "60", "enabled": "true"},
    )
    assert response.status_code == 200  # follows redirect

    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == "brand_new").first()
    assert rule is not None
    assert rule.timestamp_column == "created_at"
    assert rule.retention_days == 60
    assert rule.enabled is True


def test_rule_save_updates_existing(client, db):
    db.add(PurgeRuleDB(table_name="upd_tbl", timestamp_column="old_col", retention_days=10))
    db.commit()

    client.post(
        "/rules/upd_tbl",
        data={"timestamp_column": "new_col", "retention_days": "90", "enabled": "true"},
    )

    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == "upd_tbl").first()
    assert rule.timestamp_column == "new_col"
    assert rule.retention_days == 90


def test_rule_delete_removes_rule(client, db):
    db.add(PurgeRuleDB(table_name="del_tbl", timestamp_column="ts"))
    db.commit()

    response = client.post("/rules/del_tbl/delete")
    assert response.status_code == 200

    assert db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == "del_tbl").first() is None


def test_rule_delete_nonexistent_is_noop(client, db):
    """Deleting a rule that doesn't exist should redirect without error."""
    response = client.post("/rules/ghost_table/delete")
    assert response.status_code == 200


# ---------------------------------------------------------------------------
# Exclude toggle
# ---------------------------------------------------------------------------


def test_exclude_toggle_creates_rule_if_missing(client, db):
    response = client.post("/exclude/new_excl", data={"exclude": "true"})
    assert response.status_code == 200

    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == "new_excl").first()
    assert rule is not None
    assert rule.excluded is True
    assert rule.enabled is False


def test_exclude_toggle_sets_existing_rule(client, db):
    db.add(PurgeRuleDB(table_name="exist_excl", timestamp_column="ts", enabled=True))
    db.commit()

    client.post("/exclude/exist_excl", data={"exclude": "true"})
    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == "exist_excl").first()
    assert rule.excluded is True


def test_exclude_toggle_include_back(client, db):
    db.add(PurgeRuleDB(table_name="incl_tbl", excluded=True, enabled=False))
    db.commit()

    client.post("/exclude/incl_tbl", data={"exclude": "false"})
    rule = db.query(PurgeRuleDB).filter(PurgeRuleDB.table_name == "incl_tbl").first()
    assert rule.excluded is False


# ---------------------------------------------------------------------------
# Purge execution
# ---------------------------------------------------------------------------


def test_purge_dry_run(client, db):
    db.execute(text("CREATE TABLE purge_dry (id INTEGER PRIMARY KEY, ts DATETIME)"))
    db.commit()

    response = client.post("/purge", data={"table_name": "purge_dry", "dry_run": "true"})
    assert response.status_code == 200

    # Should create audit log entry
    log = db.query(PurgeLogDB).filter(PurgeLogDB.table_name == "purge_dry").first()
    assert log is not None
    assert log.dry_run is True


def test_purge_disabled_rule_is_rejected(client, db):
    db.add(PurgeRuleDB(table_name="disabled_tbl", enabled=False))
    db.commit()

    response = client.post("/purge", data={"table_name": "disabled_tbl", "dry_run": "true"})
    assert response.status_code == 200  # redirects to dashboard


def test_purge_excluded_table_is_rejected(client, db):
    db.add(PurgeRuleDB(table_name="excluded_tbl", excluded=True, enabled=True))
    db.commit()

    response = client.post("/purge", data={"table_name": "excluded_tbl", "dry_run": "true"})
    assert response.status_code == 200


def test_purge_actual_delete(client, db):
    from datetime import datetime, timedelta, timezone

    db.execute(text("CREATE TABLE purge_real (id INTEGER PRIMARY KEY, updated_at DATETIME)"))
    old_date = (datetime.now(timezone.utc) - timedelta(days=365)).isoformat()
    db.execute(text(f"INSERT INTO purge_real (id, updated_at) VALUES (1, '{old_date}')"))
    db.execute(text(f"INSERT INTO purge_real (id, updated_at) VALUES (2, '{old_date}')"))
    db.commit()

    # Need a rule that's enabled
    db.add(PurgeRuleDB(table_name="purge_real", timestamp_column="updated_at", retention_days=30, enabled=True))
    db.commit()

    # dry_run defaults to True in the endpoint — must explicitly send "false"
    response = client.post("/purge", data={"table_name": "purge_real", "dry_run": "false"})
    assert response.status_code == 200

    # Rows should be deleted
    count = db.execute(text("SELECT COUNT(*) FROM purge_real")).scalar()
    assert count == 0


# ---------------------------------------------------------------------------
# Purge all
# ---------------------------------------------------------------------------


def test_purge_all_no_rules(client, db):
    """No active rules → warning redirect, no error."""
    response = client.post("/purge-all")
    assert response.status_code == 200


def test_purge_all_executes_enabled_rules(client, db):
    from datetime import datetime, timedelta, timezone

    db.execute(text("CREATE TABLE pa_tbl (id INTEGER PRIMARY KEY, ts DATETIME)"))
    old = (datetime.now(timezone.utc) - timedelta(days=100)).isoformat()
    db.execute(text(f"INSERT INTO pa_tbl (id, ts) VALUES (1, '{old}')"))
    db.commit()

    db.add(PurgeRuleDB(table_name="pa_tbl", timestamp_column="ts", retention_days=30, enabled=True))
    db.commit()

    response = client.post("/purge-all")
    assert response.status_code == 200

    count = db.execute(text("SELECT COUNT(*) FROM pa_tbl")).scalar()
    assert count == 0

    log = db.query(PurgeLogDB).filter(PurgeLogDB.table_name == "pa_tbl").first()
    assert log is not None
    assert log.rows_deleted >= 1


# ---------------------------------------------------------------------------
# Auto-purge toggle
# ---------------------------------------------------------------------------


def test_toggle_auto_purge(client, db):
    with patch("fastpluggy.core.repository.app_settings.set_app_setting") as mock_set:
        response = client.post("/toggle-auto-purge")
    assert response.status_code == 200
    mock_set.assert_called_once()


# ---------------------------------------------------------------------------
# History
# ---------------------------------------------------------------------------


def test_history_returns_200(client, view_builder):
    response = client.get("/history")
    assert response.status_code == 200
    assert view_builder.last_title == "Purge History"


def test_history_shows_logs(client, view_builder, db):
    from datetime import datetime, timezone

    db.add(PurgeLogDB(
        table_name="hist_tbl",
        rows_deleted=42,
        dry_run=False,
        duration_ms=123,
        executed_at=datetime.now(timezone.utc),
        executed_by="test",
        status="success",
    ))
    db.commit()

    client.get("/history")
    logs = view_builder.last_context["logs"]
    assert len(logs) == 1
    assert logs[0].table_name == "hist_tbl"
    assert logs[0].rows_deleted == 42


def test_history_filters_by_table(client, view_builder, db):
    from datetime import datetime, timezone

    for tbl in ("tbl_a", "tbl_b"):
        db.add(PurgeLogDB(
            table_name=tbl, rows_deleted=1, dry_run=False,
            duration_ms=10, executed_at=datetime.now(timezone.utc),
            executed_by="test", status="success",
        ))
    db.commit()

    client.get("/history?table_name=tbl_a")
    logs = view_builder.last_context["logs"]
    assert all(l.table_name == "tbl_a" for l in logs)
    assert view_builder.last_context["filter_table"] == "tbl_a"
