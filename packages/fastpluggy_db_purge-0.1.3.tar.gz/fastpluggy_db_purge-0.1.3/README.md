# fastpluggy-db-purge

![DB Purge](https://img.shields.io/badge/FastPluggy-DB%20Purge-blue)
[![Release](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/db_purge/-/badges/release.svg)](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/db_purge/-/releases)
[![Pipeline Status](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/db_purge/badges/main/pipeline.svg?key_text=CI)](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/db_purge/-/pipelines?ignore_skipped=true)
[![Coverage](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/db_purge/badges/main/coverage.svg)](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/db_purge/-/pipelines)

Centralized database retention management and purge plugin for FastPluggy.

## Features

- Auto-discover all database tables with row counts and sizes
- Per-table retention policies via admin UI
- Plugin-declared purge targets via `fp_purge_targets` hook
- Manual and scheduled purge with batched deletes
- Full audit trail of purge operations

## Installation

```bash
pip install fastpluggy-db-purge
```

## Configuration

| Setting | Default | Description |
|---------|---------|-------------|
| `default_retention_days` | 30 | Global fallback retention |
| `batch_size` | 5000 | Rows per DELETE batch |
| `dry_run_by_default` | True | Safety default for manual purges |
| `auto_purge_enabled` | False | Enable scheduled purge |
| `auto_purge_cron` | `0 4 * * *` | Cron schedule (daily 4am UTC) |
