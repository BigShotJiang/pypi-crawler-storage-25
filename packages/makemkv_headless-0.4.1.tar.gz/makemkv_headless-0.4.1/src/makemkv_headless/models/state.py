
from typing import Literal

from pydantic import BaseModel

from makemkv_headless.models.tmdb import TMDBMovieSearchResultModel, TMDBShowSearchResultModel
from makemkv_headless.models.toc import TocStateModel

type StatusMessage = Literal[
  "Scanning CD-ROM devices",
  "Opening DVD disc",
  "Processing title sets",
  "Scanning contents",
  "Processing titles",
  "Decrypting data",
  "Saving all titles to MKV files",
  "Analyzing seamless segments",
  "Saving to MKV file"
]

class RipDestinationModel(BaseModel):
  library: str = None
  media: str = None
  content: str = None

class RipSortInfoModel(BaseModel):
  name: str = None
  id: str = None
  main_indexes: list[int] = None 
  extra_indexes: list[int] = None
  split_segments: list[int] = []
  id_db: str = "tmdbid"

class RipShowInfoModel(RipSortInfoModel):
  first_episode: int = None
  season_number: int = None

class RipStateModel(BaseModel):
  destination: RipDestinationModel = None
  sort_info: RipSortInfoModel | RipShowInfoModel = None
  rip_all: bool = None
  tmdb_selection: TMDBShowSearchResultModel | TMDBMovieSearchResultModel | None = None

class ProgressStateModel(BaseModel):
  buffer: float | None = None
  progress: float = 0

class SocketStateRipModel(BaseModel):
  current_title: int | None = None
  current_progress: list[ProgressStateModel] = []
  total_progress: ProgressStateModel = ProgressStateModel()
  current_status: StatusMessage | None = None
  total_status: StatusMessage | None = None
  started: bool = False

class SocketStateModel(BaseModel):
  rip: SocketStateRipModel = SocketStateRipModel()
  connected: bool = False
  message: list[str] = []

class ErrorStateModel(BaseModel):
  path: str
  message: str | BaseModel | None = None
  traceback: list[str] | None = None

class StateModel(BaseModel):
  rip: RipStateModel = RipStateModel()
  toc: TocStateModel = TocStateModel()
  socket: SocketStateModel = SocketStateModel()
  error: ErrorStateModel | None = None