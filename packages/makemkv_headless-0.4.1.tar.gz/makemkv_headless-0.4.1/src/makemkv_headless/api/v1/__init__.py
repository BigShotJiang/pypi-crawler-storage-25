from fastapi import APIRouter

from . import config
from . import disc
from . import rip
from . import socket
from . import state
from . import tmdb
from . import toc
from . import error

router = APIRouter(prefix="/v1")
router.include_router(config.router)
router.include_router(disc.router)
router.include_router(rip.router)
router.include_router(socket.router)
router.include_router(state.router)
router.include_router(tmdb.router)
router.include_router(toc.router)
router.include_router(error.router)