from argparse import ArgumentParser, Namespace
import json
import logging
import yaml

from os.path import abspath

from makemkv_headless.models.config import ConfigModel

class Config(ConfigModel):
  _parser: ArgumentParser

  def __str__(self):
    return f'{super().model_dump(mode='json')}'

  def __init__(self, *args, **kwargs):
    super().__init__(*args, **kwargs)

  @staticmethod
  def initialize_parser(parser: ArgumentParser, opts: list[str] | None = None):
    for (key, value) in ConfigModel.model_fields.items():
      if opts is not None and key not in opts:
        continue
      args = value.json_schema_extra['cli_argument']['args']
      kwargs = value.json_schema_extra['cli_argument']['kwargs']
      parser.add_argument(*args, **{key: value for key, value in kwargs.items() if value is not None})

  def load(self, opts: Namespace):
    # Load config file into opts
    if ('config_file' in opts and opts.config_file is not None):
      self.config_file = opts.config_file

    self.update_from_file(self.config_file)

    for key in self.__class__.model_fields:
      try:
        opt = getattr(opts, key)
      except AttributeError:
        continue

      if opt is not None:
        setattr(CONFIG, key, opt)

  def update(
      self, /, *, config_model: ConfigModel = None, **kwargs: dict | ConfigModel
  ) -> bool:
    '''
    Sets the specified config values.  Returns true if the update requires a
    server restart
    '''
    require_restart = False
    if config_model is not None:
      for key, value in config_model.model_dump().items():
        if value != ConfigModel.model_fields[key].default:
          if ConfigModel.model_fields[key].json_schema_extra['requires_restart']:
            require_restart = True
          setattr(self, key, value)
    else:
      for key in kwargs:
        self.__dict__[key] = kwargs[key]

    return require_restart

  def update_from_file(self, config_file: str = None):
    if (config_file == None):
      config_file = self.config_file
    else:
      self.config_file = config_file

    try:
      if self.config_file is not None:
        if config_file.endswith('.json'):
          self.update_from_json(self.config_file)
        elif config_file.endswith('.yaml'):
          self.update_from_yaml(self.config_file)
    except FileNotFoundError:
      print(f'Could not load config file {self.config_file}, continuing...')

  def update_from_json(self, config_file: str):
    with open(config_file, 'r') as file:
      self.update(**json.loads(file.read()))

  def update_from_yaml(self, config_file: str):
    with open(config_file, 'r') as file:
      self.update(**yaml.safe_load(file)) 

  def get_log_level(self) -> int:
    if self.log_level == 'ERROR':
      return logging.ERROR

    if self.log_level == 'WARN' or self.log_level == 'WARNING':
      return logging.WARNING

    if self.log_level == 'INFO':
      return logging.INFO

    if self.log_level == 'DEBUG':
      return logging.DEBUG

    return logging.INFO

  def normalize_paths(self):
    if self.temp_prefix is not None and self.temp_prefix.startswith('.'):
      self.temp_prefix = abspath(self.temp_prefix) + "/"

    if self.destination is not None and self.destination.startswith('.'):
      self.destination = abspath(self.destination) + "/"

  def write_config_file(self):
    self.normalize_paths()
    logging.info(f"Writing config file with data {self.model_dump()}")
    with open(self.config_file, 'w') as file:
      if self.config_file.endswith('.json'):
        print(self.model_dump(mode='json'), file=file)
      elif self.config_file.endswith('.yaml'):
        print(yaml.dump(self.model_dump()), file=file)

CONFIG = Config()