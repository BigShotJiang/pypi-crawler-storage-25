# cm-qa-integration

Integração em tempo real entre o **Robot Framework** e a plataforma **QA Manager** via API REST.

Um listener Robot Framework v3 captura cada resultado de teste no momento em que ocorre e o envia automaticamente para o QA Manager — sem necessidade de alterar os arquivos `.robot` existentes.

---

## Como funciona

```
Robot Framework
  └─ start_suite  ──► POST /integration/test-runs                  (cria o Test Run, recebe integration_token)
  └─ end_test     ──► POST /integration/test-runs/{id}/results     (envia resultado de cada teste)
  └─ end_suite    ──► POST /integration/test-runs/{id}/complete    (marca a execução como concluída)
```

Dois tokens são usados:
- **API Token** (`qm_...`) — gerado no perfil do usuário no QA Manager, usado para criar o Test Run
- **Integration Token** (retornado pela API) — usado para todos os envios de resultados subsequentes

---

## Instalação

```bash
pip install cm-qa-integration
```

Para desenvolvimento local:

```bash
git clone <url-do-repo> cm-qa-integration
cd cm-qa-integration
pip install -e .
```

---

## Quick Start

### 1. Configurar

```bash
cm-qa-integration setup
```

O comando interativo solicita:
- URL da API do QA Manager
- API Token (gerado em **Meu Perfil → API Tokens**)
- Código do projeto

E salva em `.qamanager.json`.

### 2. Executar testes

```bash
robot --listener cm_qa_integration.listener tests/
```

Os resultados são enviados automaticamente para o QA Manager em tempo real.

### 3. Verificar configuração

```bash
cm-qa-integration check
```

---

## Configuração (`.qamanager.json`)

```json
{
  "api_url": "http://localhost:3001/api",
  "token": "qm_abc123...",
  "project_code": "ROQ",
  "default_type": "AUTOMATED"
}
```

### Hierarquia de prioridade

A configuração é carregada de múltiplas fontes (a mais alta vence):

1. **Variáveis de ambiente** (`QA_MANAGER_*`)
2. **`.qamanager.json` no diretório do projeto** (local)
3. **`~/.qamanager.json` no home** (global)

### Variáveis de ambiente

| Variável | Descrição |
|---|---|
| `QA_MANAGER_TOKEN` | API Token (alternativa ao `.qamanager.json`) |
| `QA_MANAGER_URL` | URL base da API (padrão: `http://localhost:3001/api`) |
| `QA_MANAGER_PROJECT_CODE` | Código de integração do projeto |

---

## Uso do Listener

```bash
# Com .qamanager.json configurado (recomendado):
robot --listener cm_qa_integration.listener tests/

# Especificando sprint via argumento:
robot --listener cm_qa_integration.listener:SPRINT_ID tests/

# Modo legado (project + sprint como argumentos):
robot --listener cm_qa_integration.listener:PROJECT_CODE:SPRINT_ID tests/
```

---

## Comandos CLI

| Comando | Descrição |
|---|---|
| `cm-qa-integration setup` | Configuração interativa — gera `.qamanager.json` |
| `cm-qa-integration check` | Valida configuração e testa conectividade |

---

## Uso programático

```python
from cm_qa_integration import QAManagerListener, QAManagerClient, load_config

config = load_config()
client = QAManagerClient(config["api_url"], config["token"])
ok, msg = client.check_connection()
```

---

## Pré-requisitos

- Python 3.10+
- Robot Framework 7.x
- Acesso à API do QA Manager

---

## Licença

MIT
