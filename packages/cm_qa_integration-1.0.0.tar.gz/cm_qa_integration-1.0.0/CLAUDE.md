# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

This repo contains the `cm-qa-integration` Python package — a Robot Framework listener and CLI that integrates automated test execution with the QA Manager platform in real-time. Published on PyPI as `pip install cm-qa-integration`.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate.fish   # Fish shell
# or: source .venv/bin/activate  # Bash/Zsh

pip install -e .
cm-qa-integration setup
```

## Running Tests with Integration

```bash
# With .qamanager.json configured (recommended):
robot --listener cm_qa_integration.listener tests/

# With sprint override:
robot --listener cm_qa_integration.listener:SPRINT_ID tests/

# Legacy mode (project + sprint as args):
robot --listener cm_qa_integration.listener:PROJECT_CODE:SPRINT_ID tests/

# Without integration (local only):
robot --outputdir results tests/
```

## Package Structure

```
src/cm_qa_integration/
├── __init__.py    — Package exports: QAManagerListener, QAManagerClient, load_config
├── listener.py    — Robot Framework Listener v3 (lifecycle hooks)
├── client.py      — HTTP client for QA Manager API
├── config.py      — Config loader (.qamanager.json hierarchy)
└── cli.py         — CLI: cm-qa-integration setup/check
```

## Architecture

**`listener.py`** — Robot Framework Listener v3 that hooks into the test lifecycle:
- `start_suite` (depth=1): calls `POST /integration/test-runs` with API token, receives back `test_run_id` and `integration_token`
- `end_test`: calls `POST /integration/test-runs/{id}/results` with integration token (3 retries with 1s backoff)
- `end_suite` (depth=0): calls `POST /integration/test-runs/{id}/complete`

**`client.py`** — HTTP client using `requests.Session` with JWT Bearer auth. Methods: `check_connection()`, `list_projects()`, `create_test_run()`, `send_results()`, `complete_test_run()`.

**`config.py`** — Loads `.qamanager.json` with hierarchy:
1. Environment variables `QA_MANAGER_*` (highest priority)
2. `.qamanager.json` in project directory
3. `~/.qamanager.json` in home directory

**`cli.py`** — Two commands:
- `cm-qa-integration setup` — Interactive configuration wizard
- `cm-qa-integration check` — Validates config and tests API connectivity

## Key Configuration

Configuration via `.qamanager.json`:

```json
{
  "api_url": "http://localhost:3001/api",
  "token": "qm_...",
  "project_code": "ROQ",
  "default_type": "AUTOMATED"
}
```

Two auth tokens are used: API token (`qm_...`, generated in user profile, used to create the run) and `integration_token` (returned by the API, used for all subsequent result submissions).

## Key Environment Variables

| Variable | Default | Description |
|---|---|---|
| `QA_MANAGER_URL` | `http://localhost:3001/api` | API base URL |
| `QA_MANAGER_TOKEN` | — | API token (overrides .qamanager.json) |
| `QA_MANAGER_PROJECT_CODE` | — | Project integration code |

## Building and Publishing

```bash
pip install build twine
python3 -m build
twine upload dist/*
```
