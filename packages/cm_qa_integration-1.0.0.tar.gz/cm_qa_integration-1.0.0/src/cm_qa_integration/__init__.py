"""
cm-qa-integration — Robot Framework ↔ QA Manager integration.

Uso:
    robot --listener cm_qa_integration.listener tests/
"""

__version__ = "1.0.0"

from .listener import QAManagerListener
from .client import QAManagerClient
from .config import load_config

__all__ = ["QAManagerListener", "QAManagerClient", "load_config"]
