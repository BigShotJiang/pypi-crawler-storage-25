"""
CLI do cm-qa-integration.

Comandos:
    cm-qa-integration setup   — Configuração interativa do .qamanager.json
    cm-qa-integration check   — Valida configuração e conectividade
"""

import argparse
import json
import sys
from pathlib import Path

from .config import (
    CONFIG_FILENAME,
    DEFAULT_API_URL,
    load_config,
    save_config,
    validate_config,
)
from .client import QAManagerClient


def cmd_setup(args):
    """Configuração interativa que gera .qamanager.json."""
    print("╔═══════════════════════════════════════════════╗")
    print("║     cm-qa-integration — Configuração           ║")
    print("╚═══════════════════════════════════════════════╝")
    print()

    # Carrega config existente como defaults
    existing = load_config()

    # 1. URL da API
    default_url = existing.get("api_url", DEFAULT_API_URL)
    api_url = input(f"URL da API [{default_url}]: ").strip() or default_url

    # 2. Token
    default_token = existing.get("token", "")
    token_display = f"{default_token[:16]}..." if default_token and len(default_token) > 16 else default_token
    print()
    print("  Gere um API token no QA Manager:")
    print("  → Meu Perfil → API Tokens → Criar Token")
    print()
    token = input(f"API Token [{token_display or 'obrigatório'}]: ").strip() or default_token

    if not token:
        print("\n❌ Token é obrigatório. Gere um no QA Manager primeiro.")
        sys.exit(1)

    # 3. Validar token antes de continuar
    print("\n🔍 Validando conexão...")
    client = QAManagerClient(api_url, token)
    ok, msg = client.check_connection()
    if not ok:
        print(f"❌ Falha na validação: {msg}")
        proceed = input("Salvar mesmo assim? [s/N]: ").strip().lower()
        if proceed not in ("s", "sim", "y", "yes"):
            sys.exit(1)
    else:
        print(f"✅ {msg}")

    # 4. Project code
    print()
    if ok:
        try:
            projects = client.list_projects()
            if projects:
                print("  Projetos disponíveis:")
                for p in projects:
                    code = p.get("integration_code", "-")
                    name = p.get("name", "?")
                    print(f"    {code:12s} — {name}")
                print()
        except Exception:
            pass

    default_project = existing.get("project_code", "")
    project_code = input(f"Código do projeto [{default_project or 'obrigatório'}]: ").strip().upper() or default_project

    if not project_code:
        print("\n❌ Código do projeto é obrigatório.")
        sys.exit(1)

    # 5. Onde salvar
    print()
    print("  Onde salvar a configuração?")
    print(f"  [1] Projeto atual: {Path.cwd() / CONFIG_FILENAME}")
    print(f"  [2] Global (home): {Path.home() / CONFIG_FILENAME}")
    choice = input("  Escolha [1]: ").strip() or "1"

    if choice == "2":
        config_path = Path.home() / CONFIG_FILENAME
    else:
        config_path = Path.cwd() / CONFIG_FILENAME

    # Monta config
    config_data = {
        "api_url": api_url,
        "token": token,
        "project_code": project_code,
        "default_type": "AUTOMATED",
    }

    save_config(config_path, config_data)

    print(f"\n✅ Configuração salva em: {config_path}")
    print()
    print("  Uso:")
    print("    robot --listener cm_qa_integration.listener tests/")
    print()
    print("  Com sprint específico:")
    print("    robot --listener cm_qa_integration.listener:SPRINT_ID tests/")
    print()
    print(f"  ⚠️  Adicione '{CONFIG_FILENAME}' ao seu .gitignore!")


def cmd_check(args):
    """Valida configuração e testa conectividade."""
    print("🔍 Verificando configuração...")
    print()

    config = load_config()
    source = config.get("_source", "nenhum arquivo encontrado")
    print(f"  Fonte:        {source}")
    print(f"  API URL:      {config.get('api_url', '-')}")
    token = config.get("token", "")
    if token:
        print(f"  Token:        {token[:12]}...")
    else:
        print("  Token:        (não configurado)")
    print(f"  Projeto:      {config.get('project_code', '-')}")
    print()

    errors = validate_config(config)
    if errors:
        print("❌ Problemas encontrados:")
        for err in errors:
            print(f"   • {err}")
        print()
        print("Execute 'cm-qa-integration setup' para configurar.")
        sys.exit(1)

    # Testa conectividade
    print("📡 Testando conexão...")
    client = QAManagerClient(config["api_url"], config["token"])
    ok, msg = client.check_connection()
    if ok:
        print(f"✅ {msg}")
    else:
        print(f"❌ {msg}")
        sys.exit(1)

    # Verifica se o project_code existe
    print()
    print("📋 Verificando projeto...")
    try:
        projects = client.list_projects()
        project_code = config["project_code"].upper()
        found = next((p for p in projects if p.get("integration_code") == project_code), None)
        if found:
            print(f"✅ Projeto encontrado: {found.get('name', '?')} ({project_code})")
        else:
            print(f"⚠️  Projeto com código '{project_code}' não encontrado.")
            print("   Verifique o código de integração no QA Manager.")
    except Exception as exc:
        print(f"⚠️  Não foi possível verificar projeto: {exc}")

    print()
    print("🎉 Tudo pronto! Use:")
    print("    robot --listener cm_qa_integration.listener tests/")


def main():
    parser = argparse.ArgumentParser(
        prog="cm-qa-integration",
        description="Robot Framework ↔ QA Manager integration CLI",
    )
    subparsers = parser.add_subparsers(dest="command", help="Comando")

    subparsers.add_parser("setup", help="Configuração interativa do .qamanager.json")
    subparsers.add_parser("check", help="Valida configuração e conectividade")

    args = parser.parse_args()

    if args.command == "setup":
        cmd_setup(args)
    elif args.command == "check":
        cmd_check(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
