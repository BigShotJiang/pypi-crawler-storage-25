"""
Cliente HTTP para a API do QA Manager.
"""

import sys
import requests


class QAManagerClient:
    """Cliente para interagir com a API do QA Manager."""

    def __init__(self, api_url, token, timeout=15):
        self.api_url = api_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        })

    def check_connection(self):
        """Verifica conectividade e autenticação. Retorna (ok, message)."""
        try:
            resp = self._session.get(
                f"{self.api_url}/auth/validate",
                timeout=self.timeout,
            )
            if resp.status_code == 200:
                data = resp.json()
                user = data.get("user", {})
                return True, f"Autenticado como {user.get('name', '?')} ({user.get('email', '?')})"
            return False, f"HTTP {resp.status_code}: {resp.text[:200]}"
        except requests.ConnectionError:
            return False, f"Não foi possível conectar em {self.api_url}"
        except Exception as exc:
            return False, str(exc)

    def list_projects(self):
        """Lista projetos disponíveis."""
        resp = self._session.get(f"{self.api_url}/projects", timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()

    def list_sprints(self, project_id):
        """Lista sprints de um projeto."""
        resp = self._session.get(
            f"{self.api_url}/sprints",
            params={"project_id": project_id},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def create_test_run(self, payload):
        """Cria um test run via endpoint de integração."""
        resp = self._session.post(
            f"{self.api_url}/integration/test-runs",
            json=payload,
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def send_results(self, test_run_id, integration_token, results):
        """Envia resultados para um test run."""
        resp = self._session.post(
            f"{self.api_url}/integration/test-runs/{test_run_id}/results",
            json={"results": results},
            headers={
                "Authorization": f"Bearer {integration_token}",
                "Content-Type": "application/json",
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def complete_test_run(self, test_run_id, integration_token):
        """Marca um test run como concluído."""
        resp = self._session.post(
            f"{self.api_url}/integration/test-runs/{test_run_id}/complete",
            json={},
            headers={
                "Authorization": f"Bearer {integration_token}",
                "Content-Type": "application/json",
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    @staticmethod
    def log(msg):
        print(f"[QA Manager] {msg}", file=sys.stderr)

    @staticmethod
    def log_error(msg):
        print(f"[QA Manager] ERRO: {msg}", file=sys.stderr)
