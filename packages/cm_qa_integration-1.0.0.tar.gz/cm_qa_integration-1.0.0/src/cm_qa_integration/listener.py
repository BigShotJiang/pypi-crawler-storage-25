"""
Robot Framework Listener v3 para integração automática com QA Manager.

Lê configuração do .qamanager.json (ou variáveis de ambiente) e envia
resultados em tempo real para a API.

Uso:
    # Com .qamanager.json configurado (recomendado):
    robot --listener cm_qa_integration.listener tests/

    # Especificando sprint via argumento:
    robot --listener cm_qa_integration.listener:SPRINT_ID tests/

    # Modo legado (project como argumento):
    robot --listener cm_qa_integration.listener:PROJECT_CODE:SPRINT_ID tests/
"""

import sys
import time
from datetime import datetime

from .config import load_config, validate_config
from .client import QAManagerClient


class QAManagerListener:
    ROBOT_LISTENER_VERSION = 3

    def __init__(self, *args):
        config = load_config()

        # Argumentos do listener (compatibilidade com modo legado)
        if len(args) >= 2:
            # Modo legado: listener:PROJECT:SPRINT
            project_arg, sprint_arg = args[0], args[1]
            try:
                config["_project_id"] = int(project_arg)
            except ValueError:
                config["project_code"] = project_arg.upper()
            config["_sprint_id"] = int(sprint_arg)
        elif len(args) == 1:
            # Modo novo: listener:SPRINT_ID (project vem do config)
            config["_sprint_id"] = int(args[0])

        errors = validate_config(config)
        if errors:
            for err in errors:
                self._log_error(err)
            self._log_error("Use 'cm-qa-integration setup' para configurar.")
            self._disabled = True
            return

        self._disabled = False
        self.api_url = config["api_url"]
        self.token = config["token"]
        self.project_code = config.get("project_code")
        self.project_id = config.get("_project_id")
        self.sprint_id = config.get("_sprint_id")
        self.default_type = config.get("default_type", "AUTOMATED")
        self.metadata = config.get("metadata", {})

        self.client = QAManagerClient(self.api_url, self.token)
        self.test_run_id = None
        self.integration_token = None
        self._suite_depth = 0
        self._sent_ok = 0
        self._sent_fail = 0

        project_info = self.project_code or f"id={self.project_id}"
        source = config.get("_source", "?")
        self._log(f"Listener iniciado — api={self.api_url} project={project_info} config={source}")

    # ------------------------------------------------------------------
    # Eventos Robot Framework v3
    # ------------------------------------------------------------------

    def start_suite(self, data, result):
        if getattr(self, "_disabled", True):
            return

        self._suite_depth += 1
        if self._suite_depth != 1:
            return

        date_str = datetime.now().strftime("%d/%m/%Y %H:%M")
        project_label = self.project_code or str(self.project_id)
        run_name = f"Execução {project_label} - {date_str}"

        def count_tests(suite):
            count = len(list(suite.tests))
            for s in suite.suites:
                count += count_tests(s)
            return count

        total_tests = count_tests(data)

        payload = {
            "name": run_name,
            "description": "Execução automatizada via cm-qa-integration.",
            "total_tests": total_tests,
        }
        if self.sprint_id:
            payload["sprint_id"] = self.sprint_id
        if self.project_code:
            payload["project_code"] = self.project_code
        elif self.project_id:
            payload["project_id"] = self.project_id

        try:
            body = self.client.create_test_run(payload)
            self.test_run_id = body["id"]
            self.integration_token = body["integration_token"]
            self._log(f"Test run criado: ID={self.test_run_id} — {run_name} ({total_tests} testes)")
        except Exception as exc:
            self._log_error(f"Falha ao criar test run: {exc}")

    def end_test(self, data, result):
        if getattr(self, "_disabled", True) or not self.integration_token:
            return

        status_map = {"PASS": "passed", "FAIL": "failed", "SKIP": "blocked"}
        status = status_map.get(result.status, "failed")
        duration = round(result.elapsed_time.total_seconds(), 3)
        message = result.message or None
        if message and len(message) > 500:
            message = message[:500] + "..."

        # Deriva o caminho de suites a partir do full_name
        suite_path = []
        if data.full_name and data.name:
            suffix = "." + data.name
            if data.full_name.endswith(suffix):
                suite_str = data.full_name[: -len(suffix)]
                suite_path = suite_str.split(".")

        tags = list(data.tags) if hasattr(data, "tags") else []

        result_payload = {
            "testCaseIdentifier": data.full_name,
            "title": data.name,
            "suitePath": suite_path,
            "tags": tags,
            "status": status,
            "duration": duration,
            "message": message,
        }

        for attempt in range(3):
            try:
                self.client.send_results(self.test_run_id, self.integration_token, [result_payload])
                icons = {"passed": "✓", "failed": "✗", "blocked": "⊘"}
                self._log(f"{icons.get(status, '?')} {data.full_name} → {status}")
                self._sent_ok += 1
                break
            except Exception as exc:
                if attempt == 2:
                    self._sent_fail += 1
                    error_detail = str(exc)
                    if hasattr(exc, "response") and exc.response is not None:
                        try:
                            error_detail = f"HTTP {exc.response.status_code}: {exc.response.text[:300]}"
                        except Exception:
                            pass
                    self._log_error(f"Falha ao enviar '{data.full_name}' (3 tentativas): {error_detail}")
                else:
                    time.sleep(1)

    def end_suite(self, data, result):
        if getattr(self, "_disabled", True):
            return

        self._suite_depth -= 1
        if self._suite_depth != 0 or not self.integration_token:
            return

        self._log(f"Execução finalizada — ID={self.test_run_id} | enviados={self._sent_ok} falhas={self._sent_fail}")
        try:
            self.client.complete_test_run(self.test_run_id, self.integration_token)
            self._log("Status atualizado para CONCLUÍDO")
        except Exception as exc:
            error_detail = str(exc)
            if hasattr(exc, "response") and exc.response is not None:
                try:
                    error_detail = f"HTTP {exc.response.status_code}: {exc.response.text[:500]}"
                except Exception:
                    pass
            self._log_error(f"Falha ao concluir test run: {error_detail}")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _log(msg):
        print(f"\n[QA Manager] {msg}", file=sys.stderr)

    @staticmethod
    def _log_error(msg):
        print(f"\n[QA Manager] ERRO: {msg}", file=sys.stderr)
