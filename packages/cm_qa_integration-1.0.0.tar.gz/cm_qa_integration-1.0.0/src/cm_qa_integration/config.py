"""
Loader de configuração .qamanager.json com hierarquia de busca.

Prioridade (mais alto vence):
  1. Variáveis de ambiente QA_MANAGER_*
  2. .qamanager.json no diretório corrente (projeto)
  3. ~/.qamanager.json no home do usuário (global)
"""

import json
import os
from pathlib import Path

CONFIG_FILENAME = ".qamanager.json"

SCHEMA_KEYS = {
    "api_url": str,
    "token": str,
    "project_code": str,
    "default_type": str,
    "metadata": dict,
}

ENV_MAP = {
    "QA_MANAGER_URL": "api_url",
    "QA_MANAGER_TOKEN": "token",
    "QA_MANAGER_PROJECT_CODE": "project_code",
}

DEFAULT_API_URL = "http://localhost:3001/api"


def find_config_files():
    """Retorna lista de caminhos de .qamanager.json encontrados (projeto, home)."""
    found = []

    # 1. Diretório corrente (projeto)
    project_config = Path.cwd() / CONFIG_FILENAME
    if project_config.is_file():
        found.append(project_config)

    # 2. Home do usuário (global)
    home_config = Path.home() / CONFIG_FILENAME
    if home_config.is_file():
        found.append(home_config)

    return found


def load_config_file(path):
    """Carrega e retorna o conteúdo de um .qamanager.json."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_config():
    """
    Carrega configuração mesclando todas as fontes.
    Retorna dict com as configurações resolvidas.
    """
    config = {
        "api_url": DEFAULT_API_URL,
        "token": None,
        "project_code": None,
        "default_type": "AUTOMATED",
        "metadata": {},
        "_source": None,  # de onde veio a config principal
    }

    # Camada base: arquivo global (~/.qamanager.json)
    home_config = Path.home() / CONFIG_FILENAME
    if home_config.is_file():
        try:
            data = load_config_file(home_config)
            _merge(config, data)
            config["_source"] = str(home_config)
        except (json.JSONDecodeError, OSError):
            pass

    # Camada projeto: .qamanager.json no diretório corrente
    project_config = Path.cwd() / CONFIG_FILENAME
    if project_config.is_file():
        try:
            data = load_config_file(project_config)
            _merge(config, data)
            config["_source"] = str(project_config)
        except (json.JSONDecodeError, OSError):
            pass

    # Camada mais alta: variáveis de ambiente
    for env_key, config_key in ENV_MAP.items():
        value = os.environ.get(env_key)
        if value:
            config[config_key] = value
            config["_source"] = "env"

    # Normaliza api_url (remove trailing slash)
    if config["api_url"]:
        config["api_url"] = config["api_url"].rstrip("/")

    return config


def validate_config(config):
    """
    Valida se a configuração tem os campos obrigatórios.
    Retorna lista de erros (vazia = válido).
    """
    errors = []

    if not config.get("token"):
        errors.append("'token' não configurado. Gere um API token no QA Manager (Meu Perfil → API Tokens).")

    if not config.get("api_url"):
        errors.append("'api_url' não configurado.")

    if not config.get("project_code"):
        errors.append("'project_code' não configurado. Informe o código de integração do projeto.")

    return errors


def save_config(path, config):
    """Salva configuração em arquivo .qamanager.json."""
    data = {}
    for key in ("api_url", "token", "project_code", "default_type", "metadata"):
        if config.get(key) is not None:
            data[key] = config[key]

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def _merge(target, source):
    """Mescla source em target (apenas chaves conhecidas)."""
    for key in SCHEMA_KEYS:
        if key in source and source[key] is not None:
            if key == "metadata" and isinstance(target.get(key), dict) and isinstance(source[key], dict):
                target[key].update(source[key])
            else:
                target[key] = source[key]
