"""mnemonexus MCP server.

Exposes the mnemonexus REST API (/api/v1/*) as MCP tools so any MCP-compatible
agent (Claude Desktop, Cursor, Hermes, ...) can recall, remember, extract facts,
log decisions/lessons and traverse the entity graph.

Env vars:
    MNEMONEXUS_URL    — base URL (default: http://localhost:8080)
    MNEMONEXUS_TOKEN  — Sanctum bearer token (required for write tools)
    MNEMONEXUS_TIMEOUT — HTTP timeout seconds (default: 30)
"""
from __future__ import annotations

import asyncio
import json
import os
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool


SERVER_NAME = "mnemonexus"
BASE_URL = os.environ.get("MNEMONEXUS_URL", "http://localhost:8080").rstrip("/")
TOKEN = os.environ.get("MNEMONEXUS_TOKEN", "")
TIMEOUT = float(os.environ.get("MNEMONEXUS_TIMEOUT", "30"))


def _headers() -> dict[str, str]:
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    if TOKEN:
        headers["Authorization"] = f"Bearer {TOKEN}"
    return headers


async def _request(method: str, path: str, **kwargs: Any) -> dict[str, Any]:
    url = f"{BASE_URL}/api/v1{path}"
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.request(method, url, headers=_headers(), **kwargs)
        if resp.status_code >= 400:
            return {
                "error": True,
                "status": resp.status_code,
                "body": _safe_json(resp.text),
                "url": url,
            }
        return _safe_json(resp.text)


def _safe_json(text: str) -> Any:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"raw": text}


def _ok(payload: Any) -> list[TextContent]:
    return [TextContent(type="text", text=json.dumps(payload, ensure_ascii=False, indent=2))]


TOOLS: list[Tool] = [
    Tool(
        name="nexus_recall",
        description=(
            "Recall memories from mnemonexus via hybrid search (Meilisearch FTS + "
            "pgvector semantic). Use this whenever you need prior context: past "
            "decisions, lessons, project facts, people info."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Natural language question."},
                "domain": {
                    "type": "string",
                    "enum": ["wiki", "memory", "rules", "insights", "sources", "skills"],
                    "description": "Filter by knowledge domain.",
                },
                "limit": {"type": "integer", "minimum": 1, "maximum": 20, "default": 5},
                "mode": {
                    "type": "string",
                    "enum": ["wiki", "semantic", "hybrid"],
                    "default": "hybrid",
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="nexus_remember",
        description=(
            "Persist a new memory (text, decision, lesson, insight). Async-indexed "
            "into Postgres+pgvector+Meilisearch. Use for facts you want to recall later."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The memory content."},
                "title": {"type": "string", "description": "Optional title (auto if omitted)."},
                "domain": {
                    "type": "string",
                    "enum": ["wiki", "memory", "rules", "insights", "sources", "skills"],
                    "default": "memory",
                },
                "source_type": {
                    "type": "string",
                    "enum": ["markdown", "text", "url", "code", "decision", "lesson"],
                    "default": "text",
                },
                "metadata": {"type": "object", "description": "Free-form key/value."},
            },
            "required": ["content"],
        },
    ),
    Tool(
        name="nexus_extract",
        description=(
            "Extract structured facts, entities and relations from free text using "
            "the FactExtractor pipeline (LLM-backed). Returns facts ready to be stored."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "text": {"type": "string", "minLength": 5, "maxLength": 50000},
                "context_entity": {"type": "string", "description": "Optional anchor entity slug."},
                "sync": {
                    "type": "boolean",
                    "default": True,
                    "description": "Run synchronously and return facts inline.",
                },
            },
            "required": ["text"],
        },
    ),
    Tool(
        name="nexus_lesson",
        description=(
            "Record a lesson learned. Applies the twice-rule: if a similar lesson "
            "exists, its occurrence counter is incremented and prevention is auto-generated."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "title": {"type": "string", "maxLength": 500},
                "body": {"type": "string"},
                "prevention": {"type": "string"},
                "severity": {"type": "string", "enum": ["info", "warning", "critical"], "default": "info"},
                "category": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["title", "body"],
        },
    ),
    Tool(
        name="nexus_decision",
        description="Log an architectural/process/tooling/data decision with rationale and alternatives.",
        inputSchema={
            "type": "object",
            "properties": {
                "title": {"type": "string", "maxLength": 500},
                "description": {"type": "string"},
                "rationale": {"type": "string"},
                "alternatives": {"type": "string"},
                "category": {
                    "type": "string",
                    "enum": ["architecture", "process", "tooling", "data"],
                },
                "tags": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["title", "description"],
        },
    ),
    Tool(
        name="nexus_compact_session",
        description=(
            "Close and compact a session. Triggers SessionSummaryJob → durable summary, "
            "drops volatile messages. Irreversible."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "session_id": {"type": "integer"},
                "status": {"type": "string", "default": "closed"},
            },
            "required": ["session_id"],
        },
    ),
    Tool(
        name="nexus_history",
        description=(
            "Return the version chain of a knowledge page (via superseded_by_id). "
            "Use to inspect how a fact evolved over time."
        ),
        inputSchema={
            "type": "object",
            "properties": {"slug": {"type": "string"}},
            "required": ["slug"],
        },
    ),
    Tool(
        name="nexus_search_entity",
        description="Search the entity graph (people, projects, concepts) by name or slug.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 50, "default": 10},
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="nexus_card",
        description=(
            "Return the compact card for an entity (slug): name, kind, summary, "
            "top relations. Cheap, prefer over a full graph traversal when possible."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "slug": {"type": "string"},
                "with_graph": {"type": "boolean", "default": False},
            },
            "required": ["slug"],
        },
    ),
]


app: Server = Server(SERVER_NAME)


@app.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    args = arguments or {}

    if name == "nexus_recall":
        payload = {"query": args["query"], "limit": args.get("limit", 5), "mode": args.get("mode", "hybrid")}
        if "domain" in args:
            payload["domain"] = args["domain"]
        return _ok(await _request("POST", "/query", json=payload))

    if name == "nexus_remember":
        payload = {"content": args["content"], "domain": args.get("domain", "memory"), "source_type": args.get("source_type", "text")}
        if "title" in args:
            payload["title"] = args["title"]
        if "metadata" in args:
            payload["metadata"] = args["metadata"]
        return _ok(await _request("POST", "/ingest", json=payload))

    if name == "nexus_extract":
        payload = {"text": args["text"], "sync": args.get("sync", True)}
        if "context_entity" in args:
            payload["context_entity"] = args["context_entity"]
        return _ok(await _request("POST", "/facts/extract", json=payload))

    if name == "nexus_lesson":
        payload = {k: v for k, v in args.items() if k in {"title", "body", "prevention", "severity", "category", "tags"}}
        return _ok(await _request("POST", "/lessons", json=payload))

    if name == "nexus_decision":
        payload = {k: v for k, v in args.items() if k in {"title", "description", "rationale", "alternatives", "category", "tags"}}
        return _ok(await _request("POST", "/decisions", json=payload))

    if name == "nexus_compact_session":
        sid = args["session_id"]
        payload = {"status": args.get("status", "closed")}
        return _ok(await _request("PUT", f"/sessions/{sid}", json=payload))

    if name == "nexus_history":
        return _ok(await _request("GET", f"/pages/{args['slug']}"))

    if name == "nexus_search_entity":
        params = {"q": args["query"], "limit": args.get("limit", 10)}
        return _ok(await _request("GET", "/entities", params=params))

    if name == "nexus_card":
        slug = args["slug"]
        entity = await _request("GET", f"/entities/{slug}")
        if args.get("with_graph"):
            entity = {"entity": entity, "graph": await _request("GET", f"/entities/{slug}/graph")}
        return _ok(entity)

    return _ok({"error": True, "message": f"unknown tool: {name}"})


async def _run() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
