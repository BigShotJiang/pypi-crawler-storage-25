"""mnemonexus MCP server — exposes mnemonexus memory tools to MCP-compatible agents."""
__version__ = "0.1.0"
