# mnemonexus-mcp-server

MCP server pro [mnemonexus](https://github.com/lrdeoliveira/nexus-ai-memory) — memória pra agentes de IA, open source, em português.

Plug em **Claude Desktop**, **Cursor**, **Hermes** ou qualquer cliente MCP. Em <2min seu agente lembra de conversas, decisões, lições e fatos entre sessões — sem mais "alzheimer digital".

## Instalação

```bash
pip install mnemonexus-mcp-server
```

ou direto do repo:

```bash
pip install git+https://github.com/lrdeoliveira/mnemonexus-mcp-server
```

## Configuração

Variáveis de ambiente:

| Var | Default | Descrição |
|---|---|---|
| `MNEMONEXUS_URL` | `http://localhost:8080` | Base URL da API mnemonexus |
| `MNEMONEXUS_TOKEN` | _(vazio)_ | Token Sanctum (Bearer) — obrigatório pra writes |
| `MNEMONEXUS_TIMEOUT` | `30` | Timeout HTTP em segundos |

Gere o token via:

```bash
curl -X POST http://localhost:8080/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","password":"..."}'
```

## Claude Desktop

Adicione ao `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) ou `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "mnemonexus": {
      "command": "mnemonexus-mcp-server",
      "env": {
        "MNEMONEXUS_URL": "http://localhost:8080",
        "MNEMONEXUS_TOKEN": "seu-token-sanctum"
      }
    }
  }
}
```

Reinicia o Claude Desktop. Você verá as tools `nexus_recall`, `nexus_remember`, etc. disponíveis.

## Tools

| Tool | O que faz |
|---|---|
| `nexus_recall` | Busca híbrida (FTS + vetor) — pergunte qualquer coisa |
| `nexus_remember` | Adiciona memória nova (texto, decisão, lição) |
| `nexus_extract` | Extrai facts/entidades/relações via FactExtractor |
| `nexus_lesson` | Registra lição (twice-rule automático) |
| `nexus_decision` | Loga decisão com rationale e alternativas |
| `nexus_compact_session` | Fecha + compacta uma sessão |
| `nexus_history` | Cadeia de versões de uma página |
| `nexus_search_entity` | Busca no grafo de entidades |
| `nexus_card` | Card compacto de uma entidade |

## Dev local

```bash
git clone https://github.com/lrdeoliveira/mnemonexus-mcp-server
cd mnemonexus-mcp-server
pip install -e .
mnemonexus-mcp-server  # roda como stdio MCP server
```

Pra inspecionar interativamente:

```bash
npx @modelcontextprotocol/inspector mnemonexus-mcp-server
```

## Licença

MIT.
