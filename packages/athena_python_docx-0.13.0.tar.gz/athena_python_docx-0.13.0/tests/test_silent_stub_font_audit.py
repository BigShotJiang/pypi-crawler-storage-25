"""Lock-in tests for the silent-stub audit of :class:`Font` /
:class:`_ColorProxy` in ``docx/text/run.py``.

Four prior silent gaps that this file pins:

1. ``Font.subscript = None`` (and ``superscript = None``) used to be a
   silent early-return. python-docx's ``CT_RPr.subscript.setter``
   removes ``vertAlign`` entirely on ``None``; the SDK now mirrors
   that by emitting ``format.apply`` with ``vertAlign: null``.

2. ``Font.subscript = False`` on a run that is currently *super*scripted
   used to clobber the value by sending ``vertAlign: "baseline"``.
   python-docx only clears ``vertAlign`` when the current value
   matches (``False`` on a superscript run is a no-op upstream). The
   SDK now reads-then-conditionally-clears.

3. ``Font.highlight_color = "not_a_real_color"`` used to silently
   ``str(...)``-cast onto the wire. python-docx's
   ``highlight_val.setter`` raises ``ValueError`` for any value that
   is not a known ``WD_COLOR_INDEX`` member. The SDK now mirrors that.

4. ``Font.color.rgb = "#FF0000"`` (or any non-``RGBColor``) used to
   silently ``str(...)``-cast onto the wire. python-docx's
   ``ColorFormat.rgb.setter`` raises ``ValueError`` with the message
   ``rgb color value must be RGBColor object``. The SDK now mirrors
   that.

5. ``Font.bold = "true"`` (or any non-bool truthy/falsey input on the
   shared ``_bool_set`` helper for ``strike``, ``double_strike``, etc.)
   used to silently coerce via ``bool(value)``, turning ``"false"``
   into ``True``. python-docx's ``ST_OnOff`` validator raises
   ``TypeError("only True or False (and possibly None) may be
   assigned, got '%s'")``. The SDK now mirrors that for the
   ``_bool_set``-routed properties (``strike``, ``double_strike``,
   ``all_caps``, ``small_caps``, ``math``, ``shadow``, ``outline``,
   ``emboss``, ``imprint``, ``hidden``, ``web_hidden``,
   ``spec_vanish``, ``rtl``, ``cs_bold``, ``cs_italic``,
   ``complex_script``, ``no_proof``, ``snap_to_grid``).
"""

from __future__ import annotations

from typing import Any

import pytest

from docx.enum.text import WD_COLOR_INDEX
from docx.shared import RGBColor
from docx.text.run import Run


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------


def _format_apply_calls(fake_sd_methods: Any) -> list[dict]:
    """Return only the ``inline`` payloads from the recorded
    ``format.apply`` calls, in order."""
    return [
        params["inline"]
        for op, params in fake_sd_methods.calls
        if op == "format.apply" and isinstance(params, dict)
    ]


def _make_run(mock_session: Any) -> Run:
    return Run(session=mock_session, block_id="p-audit", range_=(0, 5))


# ---------------------------------------------------------------------
# Gap 1: subscript / superscript = None must clear vertAlign
# ---------------------------------------------------------------------


def test_subscript_none_clears_vertAlign(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.font.subscript = None
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines, (
        "font.subscript = None must emit format.apply, not silently no-op"
    )
    assert inlines[0]["vertAlign"] is None, (
        f"font.subscript = None must send vertAlign: null, "
        f"got {inlines[0].get('vertAlign')!r}"
    )


def test_superscript_none_clears_vertAlign(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.font.superscript = None
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines, (
        "font.superscript = None must emit format.apply, not silently no-op"
    )
    assert inlines[0]["vertAlign"] is None


# ---------------------------------------------------------------------
# Gap 2: subscript = False on a superscript run must NOT clobber
# ---------------------------------------------------------------------


def test_subscript_false_on_superscript_is_no_op(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """python-docx: ``font.subscript = False`` only clears
    ``vertAlign`` when the current value is ``"subscript"``. On a
    superscript run it must leave the existing value untouched —
    otherwise it silently demotes the run to baseline."""
    run = _make_run(mock_session)
    # Pre-seed the inline snapshot so the live read sees "superscript"
    # without hitting the network.
    run._inline_snapshot = {"vertAlign": "superscript"}
    fake_sd_methods.calls.clear()
    run.font.subscript = False
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines == [], (
        "font.subscript = False on a superscript run must NOT emit "
        f"format.apply (would clobber). Got {inlines!r}"
    )


def test_superscript_false_on_subscript_is_no_op(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run._inline_snapshot = {"vertAlign": "subscript"}
    fake_sd_methods.calls.clear()
    run.font.superscript = False
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines == [], (
        "font.superscript = False on a subscript run must NOT emit "
        f"format.apply (would clobber). Got {inlines!r}"
    )


def test_subscript_false_on_subscript_clears(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``font.subscript = False`` on a run that *is* subscript should
    clear ``vertAlign`` (the value matches, so upstream removes it)."""
    run = _make_run(mock_session)
    run._inline_snapshot = {"vertAlign": "subscript"}
    fake_sd_methods.calls.clear()
    run.font.subscript = False
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines, (
        "font.subscript = False on a subscript run must emit format.apply"
    )
    assert inlines[0]["vertAlign"] is None


def test_subscript_true_sets_vertAlign(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.font.subscript = True
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines
    assert inlines[0]["vertAlign"] == "subscript"


def test_superscript_true_sets_vertAlign(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.font.superscript = True
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines
    assert inlines[0]["vertAlign"] == "superscript"


# ---------------------------------------------------------------------
# Gap 3: highlight_color rejects non-WD_COLOR_INDEX
# ---------------------------------------------------------------------


def test_highlight_color_rejects_garbage_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    with pytest.raises(ValueError, match="WD_COLOR_INDEX"):
        run.font.highlight_color = "NOT_A_REAL_COLOR"
    assert _format_apply_calls(fake_sd_methods) == [], (
        "highlight_color rejection must happen BEFORE the wire call so "
        "the bus never sees the invalid value."
    )


def test_highlight_color_rejects_non_string_non_enum(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    with pytest.raises(ValueError, match="WD_COLOR_INDEX"):
        run.font.highlight_color = 12345  # type: ignore[assignment]
    assert _format_apply_calls(fake_sd_methods) == []


def test_highlight_color_accepts_wd_color_index(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.font.highlight_color = WD_COLOR_INDEX.YELLOW
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines
    assert inlines[0]["highlight"] == "yellow"


def test_highlight_color_accepts_matching_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Strings matching a ``WD_COLOR_INDEX`` member value are accepted
    (callers that pre-serialise — e.g. ``"yellow"`` from a config
    dict — still work)."""
    run = _make_run(mock_session)
    run.font.highlight_color = "yellow"
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines
    assert inlines[0]["highlight"] == "yellow"


def test_highlight_color_none_still_clears(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.font.highlight_color = None
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines
    assert inlines[0]["highlight"] is None


# ---------------------------------------------------------------------
# Gap 4: Font.color.rgb rejects non-RGBColor
# ---------------------------------------------------------------------


def test_color_rgb_rejects_hex_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    with pytest.raises(ValueError, match="must be RGBColor"):
        run.font.color.rgb = "#FF0000"  # type: ignore[assignment]
    assert _format_apply_calls(fake_sd_methods) == []


def test_color_rgb_rejects_int(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    with pytest.raises(ValueError, match="must be RGBColor"):
        run.font.color.rgb = 0xFF0000  # type: ignore[assignment]
    assert _format_apply_calls(fake_sd_methods) == []


def test_color_rgb_accepts_rgbcolor(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.font.color.rgb = RGBColor(0xFF, 0x00, 0x00)
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines
    assert inlines[0]["color"] == "FF0000"


def test_color_rgb_none_still_clears(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """The ``None`` clear path must remain wired — see
    ``test_run_color_rgb_none_clears`` in ``test_parity_round2.py``;
    this is a duplicate guard so the audit-test file fails loudly if
    a future refactor breaks both paths together."""
    run = _make_run(mock_session)
    run.font.color.rgb = None
    inlines = _format_apply_calls(fake_sd_methods)
    assert inlines
    assert inlines[0]["color"] is None


# ---------------------------------------------------------------------
# Gap 5: Bool setters reject non-bool (mirrors ST_OnOff.validate)
# ---------------------------------------------------------------------


# Properties routed through ``_bool_set``. ``bold`` and ``italic`` go
# through ``Run.bold.setter`` / ``Run.italic.setter`` which already
# ``bool(value)``-coerce — they predate this audit and are kept
# permissive for now. The audit fixes the shared helper instead.
BOOL_SET_PROPS: list[str] = [
    "strike",
    "double_strike",
    "all_caps",
    "small_caps",
    "math",
    "shadow",
    "outline",
    "emboss",
    "imprint",
    "hidden",
    "web_hidden",
    "spec_vanish",
    "rtl",
    "cs_bold",
    "cs_italic",
    "complex_script",
    "no_proof",
    "snap_to_grid",
]


@pytest.mark.parametrize("prop", BOOL_SET_PROPS)
def test_bool_setter_rejects_string(
    prop: str, mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    with pytest.raises(TypeError, match="True or False"):
        setattr(run.font, prop, "true")
    assert _format_apply_calls(fake_sd_methods) == [], (
        f"font.{prop} = 'true' must reject BEFORE emitting format.apply"
    )


@pytest.mark.parametrize("prop", BOOL_SET_PROPS)
def test_bool_setter_accepts_true_false_none(
    prop: str, mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    setattr(run.font, prop, True)
    setattr(run.font, prop, False)
    setattr(run.font, prop, None)
    # Three writes, three format.apply calls.
    inlines = _format_apply_calls(fake_sd_methods)
    assert len(inlines) == 3, (
        f"Expected 3 wire writes for True/False/None on font.{prop}, "
        f"got {len(inlines)}"
    )


def test_bool_setter_accepts_int_one_zero(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """python-docx accepts integer ``1``/``0`` because
    ``1 == True`` / ``0 == False`` make them members of
    ``(True, False)``. Mirror that — caller code in the wild does
    ``font.bold = int(flag)``."""
    run = _make_run(mock_session)
    run.font.strike = 1  # type: ignore[assignment]
    run.font.strike = 0  # type: ignore[assignment]
    inlines = _format_apply_calls(fake_sd_methods)
    assert len(inlines) == 2
    assert inlines[0]["strike"] is True
    assert inlines[1]["strike"] is False
