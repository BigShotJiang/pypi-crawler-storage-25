"""Lock-in tests for ``_Cell.add_paragraph`` text + style validation.

Same silent-stub pattern as the other ``add_paragraph`` factories
(``Document.add_paragraph``, ``_HeaderFooter.add_paragraph``,
``Paragraph.insert_paragraph_before``):

- ``text`` was unvalidated — any value shipped to the wire's
  ``create.paragraph({"text": value})``. SuperDoc's permissive parser
  swallowed or rejected silently.
- ``style`` had a catch-all ``str(style)`` which shipped garbage like
  ``"<MyStyle object at 0x...>"`` as a style id. Word silently fell
  back to Normal.

Now both raise ``TypeError`` upfront when not ``str`` (text) or not
``str | ParagraphStyle | None`` (style).
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_cell(mock_session: Any) -> Any:
    from docx.table import Table, _Cell

    table = Table(session=mock_session, node_id="tbl-1")
    return _Cell(table=table, row=0, col=0)


@pytest.mark.parametrize("value", [42, 1.5, None, [1, 2], {"a": "b"}])
def test_cell_add_paragraph_rejects_non_str_text(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    cell = _make_cell(mock_session)
    with pytest.raises(TypeError, match="text requires str"):
        cell.add_paragraph(text=value)


@pytest.mark.parametrize("value", [42, 1.5, [1, 2], {"a": "b"}, object()])
def test_cell_add_paragraph_rejects_invalid_style_type(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    cell = _make_cell(mock_session)
    with pytest.raises(TypeError, match="ParagraphStyle"):
        cell.add_paragraph(text="hi", style=value)
