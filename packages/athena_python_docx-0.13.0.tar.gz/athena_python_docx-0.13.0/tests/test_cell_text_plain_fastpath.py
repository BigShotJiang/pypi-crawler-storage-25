"""Lock-in test for the ``_Cell.text`` plain-text fast path (0.8.0).

Before 0.8.0 every ``cell.text = value`` assignment did two eager
HTTP round-trips: one to ``doc.markdownToFragment`` (a query, since
the SDK needs the structural fragment shape SuperDoc requires inside
a ``tableCell``) and one to ``doc.insert``. With ``Insert`` now
buffered (see ``test_insert_deferred.py``) and the plain-text fast
path building the fragment locally, plain-text cell assignments are
now ONE batched command instead of two roundtrips.

The fast path triggers when ``value`` contains no markdown control
characters (``*_~`#>[]<|\\``); anything with formatting syntax falls
back to the server-side ``markdownToFragment`` query.
"""

from __future__ import annotations

import pytest

from docx.table import _is_plain_text


class TestIsPlainText:
    @pytest.mark.parametrize(
        "value",
        [
            "",
            "Hello",
            "Q1 2026",
            "$1,234.56",
            "1,234,567.89",
            "(-3.4%)",
            "John Doe",
            "Revenue: 12.4B (-3% YoY)",  # parens, %, : — none are markdown
            "Note. Includes one-time items.",  # periods, hyphens fine
            "100°C / 212°F",
            "—",  # em dash
            "Café",  # unicode fine
        ],
    )
    def test_plain_text_values_skip_markdown(self, value: str) -> None:
        assert _is_plain_text(value) is True

    @pytest.mark.parametrize(
        "value",
        [
            "**bold**",
            "_italic_",
            "~strike~",
            "`code`",
            "# Heading",
            "> blockquote",
            "[link](url)",
            "<html>",
            "with | pipes",
            "back\\slash",
        ],
    )
    def test_markdown_special_chars_force_query(self, value: str) -> None:
        assert _is_plain_text(value) is False
