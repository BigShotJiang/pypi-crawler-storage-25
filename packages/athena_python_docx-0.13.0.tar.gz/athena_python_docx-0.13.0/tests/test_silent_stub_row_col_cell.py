"""Lock-in tests for ``_Row`` / ``_Column`` / ``_Cell`` setter
None-clear silent-stubs.

Five setters previously early-returned on ``None`` with no signal,
losing the python-docx-1.x "clear back to inherited" intent:

- ``_Row.height``
- ``_Row.height_rule``
- ``_Column.width``
- ``_Cell.vertical_alignment``
- ``_Cell.width``

SuperDoc 1.8 has no clear-ops for these (``set_row_height`` /
``set_column_width`` / ``set_cell_properties`` all require explicit
values), so the wire still can't represent the clear-intent. We now
emit ``PendingTableClearWarning`` to surface the divergence.

Also adds enum-coercion strictness for ``_Row.height_rule.setter``:
non-enum strings raise ``ValueError`` (was ``str(value)`` ship-anything).
"""

from __future__ import annotations

import warnings
from typing import Any

import pytest


def _make_table(mock_session: Any, *, node_id: str = "tbl-1") -> Any:
    from docx.table import Table

    return Table(session=mock_session, node_id=node_id)


def _make_row(mock_session: Any, *, index: int = 0) -> Any:
    from docx.table import _Row

    return _Row(table=_make_table(mock_session), index=index)


def _make_column(mock_session: Any, *, index: int = 0) -> Any:
    from docx.table import _Column

    return _Column(table=_make_table(mock_session), index=index)


def _make_cell(mock_session: Any, *, row: int = 0, col: int = 0) -> Any:
    from docx.table import _Cell

    return _Cell(table=_make_table(mock_session), row=row, col=col)


# ---------------------------------------------------------------------
# _Row.height / _Row.height_rule
# ---------------------------------------------------------------------


def test_row_height_none_emits_clear_warning(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.table import PendingTableClearWarning

    row = _make_row(mock_session)
    before = sum(
        1 for c in fake_sd_methods.calls if c[0] == "tables.set_row_height"
    )
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        row.height = None
    after = sum(
        1 for c in fake_sd_methods.calls if c[0] == "tables.set_row_height"
    )
    pending = [
        w for w in recorded if issubclass(w.category, PendingTableClearWarning)
    ]
    assert len(pending) == 1
    assert "_Row" in str(pending[0].message)
    assert "height" in str(pending[0].message)
    assert after - before == 0


def test_row_height_rule_none_emits_clear_warning(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.table import PendingTableClearWarning

    row = _make_row(mock_session)
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        row.height_rule = None
    pending = [
        w for w in recorded if issubclass(w.category, PendingTableClearWarning)
    ]
    assert len(pending) == 1
    assert "height_rule" in str(pending[0].message)


def test_row_height_rule_rejects_bogus_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Was: ``row.height_rule = "bogus"`` shipped ``"bogus"`` to wire.
    Now: ValueError listing valid WD_ROW_HEIGHT_RULE members."""
    row = _make_row(mock_session)
    with pytest.raises(ValueError, match="WD_ROW_HEIGHT_RULE"):
        row.height_rule = "not-a-real-rule"


def test_row_height_rule_rejects_non_str_non_enum(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    row = _make_row(mock_session)
    with pytest.raises(TypeError, match="WD_ROW_HEIGHT_RULE"):
        row.height_rule = 42


# ---------------------------------------------------------------------
# _Column.width
# ---------------------------------------------------------------------


def test_column_width_none_emits_clear_warning(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.table import PendingTableClearWarning

    col = _make_column(mock_session)
    before = sum(
        1 for c in fake_sd_methods.calls if c[0] == "tables.set_column_width"
    )
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        col.width = None
    after = sum(
        1 for c in fake_sd_methods.calls if c[0] == "tables.set_column_width"
    )
    pending = [
        w for w in recorded if issubclass(w.category, PendingTableClearWarning)
    ]
    assert len(pending) == 1
    assert "_Column" in str(pending[0].message)
    assert after - before == 0


# ---------------------------------------------------------------------
# _Cell.vertical_alignment / _Cell.width
# ---------------------------------------------------------------------


def test_cell_vertical_alignment_none_emits_clear_warning(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.table import PendingTableClearWarning

    cell = _make_cell(mock_session)
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        cell.vertical_alignment = None
    pending = [
        w for w in recorded if issubclass(w.category, PendingTableClearWarning)
    ]
    assert len(pending) == 1
    assert "_Cell" in str(pending[0].message)
    assert "vertical_alignment" in str(pending[0].message)


def test_cell_width_none_emits_clear_warning(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.table import PendingTableClearWarning

    cell = _make_cell(mock_session)
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        cell.width = None
    pending = [
        w for w in recorded if issubclass(w.category, PendingTableClearWarning)
    ]
    assert len(pending) == 1
    assert "_Cell" in str(pending[0].message)
    assert "width" in str(pending[0].message)
