"""Lock-in test for ``Insert`` no longer being response-bearing (0.8.0).

Before 0.8.0, ``Paragraph.add_run`` / ``Run.add_text`` / ``_Cell.text``
each triggered an eager HTTP flush because ``Insert`` sat in
:data:`docx.commands._RESPONSE_BEARING_TYPES`. The Kraft Heinz trace
(31-minute tool call, 236 commands, mostly ``add_run`` + cell-text
setters) showed the cost: one HTTP round-trip per text-inserting call,
serially.

0.8.0 removes ``Insert`` from the response-bearing set. In-tree callers
ignore the response (the Run proxy wraps a known client-side range, so
it doesn't need the server's echoed nodeId), and follow-up formatters
(``Run.bold`` / ``Run.italic`` / etc.) ride the next eager flush in the
same batch.

This test fails fast if a future refactor reintroduces ``Insert`` to
``_RESPONSE_BEARING_TYPES`` without converting the call sites to
client-side ids first.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import patch

from docx._http_doc import HttpClient, HttpDocHandle
from docx.commands import (
    _RESPONSE_BEARING_TYPES,
    Insert,
    is_response_bearing,
)


def test_insert_is_not_response_bearing() -> None:
    """Pin the contract — ``Insert`` is buffered, not eager. Re-adding
    it to ``_RESPONSE_BEARING_TYPES`` requires a parallel migration of
    the three call sites in ``paragraph.py`` / ``run.py`` / ``table.py``
    to pre-mint a client-side id (same as the 0.7.0 Create* fix)."""
    assert "Insert" not in _RESPONSE_BEARING_TYPES, (
        "Insert was removed from response-bearing in 0.8.0 to let "
        "add_run text-inserts ride the same HTTP batch as the format "
        "setters that follow them. See PERFORMANCE_BATCHING_ANALYSIS.md."
    )
    sample = Insert(target={"kind": "selection"})
    assert not is_response_bearing(sample)


def _ok_body(applied: list[dict[str, Any]]) -> bytes:
    return json.dumps(
        {"assetId": "asset_test", "applied": applied},
    ).encode("utf-8")


class _FakeResponse:
    def __init__(self, *, status_code: int, body: bytes) -> None:
        self.status_code = status_code
        self._body_text = body.decode("utf-8", errors="replace")

    @property
    def text(self) -> str:
        return self._body_text

    def json(self) -> Any:
        return json.loads(self._body_text)


def test_insert_buffers_with_subsequent_format_apply() -> None:
    """A typical styled-run sequence — Insert text, then apply bold /
    italic / color — must ship in **one** HTTP POST, not three.

    Pre-0.8.0 this took 2 POSTs (one for the eager Insert, one for the
    buffered FormatApply triplet). The whole point of 0.8.0 is that
    deferred Insert collapses that into a single POST."""
    import asyncio

    posts: list[dict[str, Any]] = []

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        body = json.loads(kwargs["data"].decode("utf-8"))
        posts.append(body)
        applied: list[dict[str, Any]] = []
        for i, cmd in enumerate(body["commands"]):
            applied.append({"index": i, "type": cmd["type"], "result": {}})
        return _FakeResponse(status_code=200, body=_ok_body(applied))

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        doc = HttpDocHandle(client, "asset_test")

        async def _drive() -> None:
            # Insert (text segment) followed by two format applies on the
            # same target range. Pre-0.8.0 this was 2 HTTP POSTs because
            # Insert flushed eagerly; 0.8.0 should keep them all buffered.
            await doc.insert(
                {
                    "target": {
                        "kind": "selection",
                        "start": {"kind": "text", "blockId": "p1", "offset": 0},
                        "end": {"kind": "text", "blockId": "p1", "offset": 0},
                    },
                    "value": "Hello",
                    "type": "text",
                },
            )
            await doc.format.apply(
                {
                    "target": {
                        "kind": "text",
                        "blockId": "p1",
                        "range": {"start": 0, "end": 5},
                    },
                    "inline": {"bold": True},
                },
            )
            await doc.format.apply(
                {
                    "target": {
                        "kind": "text",
                        "blockId": "p1",
                        "range": {"start": 0, "end": 5},
                    },
                    "inline": {"italic": True},
                },
            )

        asyncio.run(_drive())
        # Force the flush so the assertion below has something to check.
        doc.buffer.flush()

    # All three commands must have shipped in a SINGLE POST.
    assert len(posts) == 1, (
        f"Expected 1 HTTP POST for Insert + 2 format applies, got {len(posts)}. "
        "This regresses the 0.8.0 transparent-batching guarantee."
    )
    types = [c["type"] for c in posts[0]["commands"]]
    assert types == ["Insert", "FormatApply", "FormatApply"]
