"""Lock-in tests for ``Table.alignment`` / ``Table.direction`` /
``Table.autofit`` setter validation.

Previously these three setters silently no-op'd on ``None`` (with no
signal that the wire couldn't represent the clear-intent) AND
silently passed bogus strings through to ``tables.setLayout`` via
``str(value).lower()`` (SuperDoc's permissive parser swallowed
unknowns, producing an apparent success without any state change).

Now:
- ``None`` emits ``PendingTableClearWarning`` (no clear-op on wire).
- Non-enum strings raise ``ValueError`` listing valid members.
- Non-bool/non-str/non-enum input raises ``TypeError``.
- Valid enum / string input still ships to ``tables.setLayout``.
"""

from __future__ import annotations

import warnings
from typing import Any

import pytest


def _make_table(mock_session: Any, *, node_id: str = "tbl-1") -> Any:
    from docx.table import Table

    return Table(session=mock_session, node_id=node_id)


# ---------------------------------------------------------------------
# None → PendingTableClearWarning
# ---------------------------------------------------------------------


@pytest.mark.parametrize("prop", ["alignment", "direction", "autofit"])
def test_table_setter_none_emits_clear_warning(
    mock_session: Any, fake_sd_methods: Any, prop: str
) -> None:
    """Each of the three Table layout setters emits exactly one
    ``PendingTableClearWarning`` on ``None`` and issues no
    ``tables.set_layout`` call."""
    from docx.table import PendingTableClearWarning

    table = _make_table(mock_session)
    before = sum(
        1 for c in fake_sd_methods.calls if c[0] == "tables.set_layout"
    )
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        setattr(table, prop, None)
    after = sum(
        1 for c in fake_sd_methods.calls if c[0] == "tables.set_layout"
    )

    pending = [
        w for w in recorded if issubclass(w.category, PendingTableClearWarning)
    ]
    assert len(pending) == 1, f"{prop} = None should emit 1 warning"
    assert prop in str(pending[0].message)
    assert after - before == 0


# ---------------------------------------------------------------------
# Bogus strings → ValueError
# ---------------------------------------------------------------------


def test_alignment_rejects_bogus_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Was: ``table.alignment = "bogus"`` → str(value).lower() shipped
    ``"bogus"`` to the wire and SuperDoc silently swallowed it. Now:
    ``ValueError`` listing valid WD_TABLE_ALIGNMENT values."""
    table = _make_table(mock_session)
    with pytest.raises(ValueError, match="WD_TABLE_ALIGNMENT"):
        table.alignment = "bogus"


def test_direction_rejects_bogus_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Same for direction."""
    table = _make_table(mock_session)
    with pytest.raises(ValueError, match="WD_TABLE_DIRECTION"):
        table.direction = "rtl-bogus"


# ---------------------------------------------------------------------
# Non-string / non-enum / non-bool → TypeError
# ---------------------------------------------------------------------


@pytest.mark.parametrize(
    "prop,value",
    [
        ("alignment", 42),
        ("direction", [1, 2, 3]),
    ],
)
def test_table_setter_rejects_non_str_non_enum(
    mock_session: Any, fake_sd_methods: Any, prop: str, value: object
) -> None:
    table = _make_table(mock_session)
    with pytest.raises(TypeError):
        setattr(table, prop, value)


def test_autofit_rejects_non_bool(mock_session: Any, fake_sd_methods: Any) -> None:
    """``bool`` is the only valid non-None autofit input. Was: ``str``
    truthy values like ``"yes"`` would have hit the ``True``-branch
    silently (via the implicit ``if value`` check). Now: TypeError."""
    table = _make_table(mock_session)
    with pytest.raises(TypeError, match="bool"):
        table.autofit = "yes"
    with pytest.raises(TypeError, match="bool"):
        table.autofit = 1


# ---------------------------------------------------------------------
# Happy paths still ship to wire
# ---------------------------------------------------------------------


def test_alignment_with_enum_member_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.enum.table import WD_TABLE_ALIGNMENT

    table = _make_table(mock_session)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    layout_calls = [
        c for c in fake_sd_methods.calls if c[0] == "tables.set_layout"
    ]
    assert layout_calls
    assert layout_calls[-1][1]["alignment"] == "center"


def test_autofit_with_bool_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    table = _make_table(mock_session)
    table.autofit = True
    layout_calls = [
        c for c in fake_sd_methods.calls if c[0] == "tables.set_layout"
    ]
    assert layout_calls
    assert layout_calls[-1][1]["autoFitMode"] == "fitContents"
    table.autofit = False
    layout_calls = [
        c for c in fake_sd_methods.calls if c[0] == "tables.set_layout"
    ]
    assert layout_calls[-1][1]["autoFitMode"] == "fixedWidth"
