"""Lock-in tests for ``Paragraph.add_run`` ``text`` / ``style``
parameter validation.

Two silent-stub paths in the factory method:

1. ``text`` was passed through ``text or ""`` — coerced falsy values
   (0, [], False) to empty string silently and let truthy non-strings
   (42, [1, 2]) flow into ``_insert_run_text_segments`` where they
   crashed with confusing ``'int' object is not subscriptable`` errors
   deep in the segment walk.

2. ``style`` was passed through
   ``style.style_id if isinstance(style, CharacterStyle) else str(style)``
   — any non-CharacterStyle non-string shipped ``str(value)`` as a
   style id (``"42"``, ``"<MyStyle object at 0x...>"``).

Now both raise ``TypeError`` upfront. ``None`` and the documented
types still work as before.
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_paragraph(mock_session: Any) -> Any:
    from docx.text.paragraph import Paragraph

    return Paragraph(
        session=mock_session,
        node_id="p1",
        node_type="paragraph",
    )


# ---------------------------------------------------------------------
# text parameter validation
# ---------------------------------------------------------------------


@pytest.mark.parametrize("value", [42, 1.5, [1, 2, 3], {"a": "b"}, object()])
def test_add_run_rejects_non_str_text(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    para = _make_paragraph(mock_session)
    with pytest.raises(TypeError, match="str or None"):
        para.add_run(text=value)


def test_add_run_accepts_none_text(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``add_run(text=None)`` is a no-text run (python-docx default)."""
    para = _make_paragraph(mock_session)
    run = para.add_run(text=None)
    assert run is not None


def test_add_run_accepts_str_text(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Real str input still works."""
    para = _make_paragraph(mock_session)
    run = para.add_run(text="hello")
    assert run is not None


# ---------------------------------------------------------------------
# style parameter validation
# ---------------------------------------------------------------------


@pytest.mark.parametrize("value", [42, 1.5, [1, 2], {"a": "b"}, object()])
def test_add_run_rejects_invalid_style_type(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    para = _make_paragraph(mock_session)
    with pytest.raises(TypeError, match="CharacterStyle"):
        para.add_run(text="hi", style=value)


def test_add_run_accepts_str_style(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Real str style still works — was the documented happy path."""
    para = _make_paragraph(mock_session)
    run = para.add_run(text="hi", style="Emphasis")
    assert run is not None
