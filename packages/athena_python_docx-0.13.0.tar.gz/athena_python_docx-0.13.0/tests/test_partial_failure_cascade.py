"""Lock-in tests for the partial-failure cascade fix (0.9.0).

Preview-session ``thread_bafba02b`` showed how one cell-paragraph
mistake snowballed into thirteen downstream errors plus a
``DOCUMENT_IDENTITY_CONFLICT``. Root cause: when an HTTP batch raised,
the SDK threw away the ``proxy_id_refs`` rewrite for every Create that
DID commit before the failure — so the next batch shipped dead client
UUIDs straight to SuperDoc.

These tests pin the recovery path: the partial-failure exceptions
(``DocxError`` / ``NotFoundError`` / ``BlockNotFoundError``) now carry
a ``partial_applied`` list of ``{index, type, result}`` entries from
the server, and the buffer's flush paths drain those into
``proxy_id_refs`` rewrites before re-raising.

Plus the new ``_TABLE_CLIENT_ID_HINT`` shape for
``TablesGet`` / ``TablesGetCells`` etc. ``BlockNotFoundError``s — the
table-query case is distinct from the cell-paragraph one and gets a
different actionable hint.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import patch

import pytest

from docx._buffer import CommandBuffer
from docx._http_doc import HttpClient
from docx.commands import CreateParagraph
from docx.errors import (
    BlockNotFoundError,
    DocxError,
    NotFoundError,
)


class _FakeResponse:
    def __init__(self, *, status_code: int, body: bytes) -> None:
        self.status_code = status_code
        self._body_text = body.decode("utf-8", errors="replace")

    @property
    def text(self) -> str:
        return self._body_text

    def json(self) -> Any:
        return json.loads(self._body_text)


def _partial_failure_body(
    *,
    applied: list[dict[str, Any]],
    err_cmd_type: str,
    err_message: str,
    err_index: int | None = None,
) -> bytes:
    """Build the 207-Multi-Status body docx-studio returns on a
    partial-batch failure."""
    if err_index is None:
        err_index = len(applied)
    return json.dumps(
        {
            "assetId": "asset_test",
            "applied": applied,
            "error": {
                "index": err_index,
                "type": err_cmd_type,
                "error": "SuperDocCliError",
                "message": err_message,
            },
        },
    ).encode("utf-8")


class _Proxy:
    """Minimal stand-in for a ``Paragraph`` / ``Table`` SDK proxy that
    holds a mutable ``_node_id``. The buffer's rewrite path uses
    ``setattr(proxy, '_node_id', real_id)`` to swing the proxy from
    its client UUID to the real SuperDoc id."""

    def __init__(self, client_id: str) -> None:
        self._node_id = client_id


def test_partial_applied_propagates_through_block_not_found_error() -> None:
    """When the server's 207 body lists an ``applied`` prefix, the
    raised :class:`BlockNotFoundError` MUST expose those entries on
    ``.partial_applied`` so the buffer can replay the rewrite path."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                applied=[
                    {
                        "index": 0,
                        "type": "CreateParagraph",
                        "result": {
                            "client_node_id": "p_aaaa",
                            "real_node_id": "para_real_1",
                        },
                    },
                    {
                        "index": 1,
                        "type": "CreateParagraph",
                        "result": {
                            "client_node_id": "p_bbbb",
                            "real_node_id": "para_real_2",
                        },
                    },
                ],
                err_cmd_type="SetParagraphAlignment",
                err_message='Block "paragraph:phantom-cell-id" was not found.',
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError) as exc_info:
            client.execute_batch(
                "asset_test",
                [
                    CreateParagraph(
                        text="A",
                        at={"kind": "documentEnd"},
                        client_node_id="p_aaaa",
                    ),
                    CreateParagraph(
                        text="B",
                        at={"kind": "documentEnd"},
                        client_node_id="p_bbbb",
                    ),
                ],
            )

    applied = exc_info.value.partial_applied
    assert len(applied) == 2, (
        "Partial-failure rewrites depend on this list being non-empty for "
        "the committed prefix; if applied is dropped during the raise, the "
        "cascade returns and one bad paragraph drag every following "
        "table query into a 'Block not found' loop."
    )
    assert applied[0]["result"]["real_node_id"] == "para_real_1"
    assert applied[1]["result"]["real_node_id"] == "para_real_2"


def test_partial_applied_propagates_through_docxerror() -> None:
    """Non-block-not-found partial failures (a validation error, etc.)
    also need to carry ``applied`` so the buffer can rewrite proxies for
    commands that ran before the bad one."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                applied=[
                    {
                        "index": 0,
                        "type": "CreateParagraph",
                        "result": {
                            "client_node_id": "p_x",
                            "real_node_id": "para_real_x",
                        },
                    },
                ],
                err_cmd_type="CreateParagraph",
                err_message="ValidationError: at.kind must be one of …",
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(DocxError) as exc_info:
            client.execute_batch(
                "asset_test",
                [
                    CreateParagraph(
                        text="A",
                        at={"kind": "documentEnd"},
                        client_node_id="p_x",
                    ),
                ],
            )

    # The first commit DID land — make sure that prefix flows through.
    assert not isinstance(exc_info.value, NotFoundError), (
        "Validation-style failures must NOT be classified as NotFound."
    )
    assert exc_info.value.partial_applied == [
        {
            "index": 0,
            "type": "CreateParagraph",
            "result": {
                "client_node_id": "p_x",
                "real_node_id": "para_real_x",
            },
        },
    ]


def test_buffer_flush_rewrites_proxy_ids_for_partial_applied_prefix() -> None:
    """The cascade-buster: even when ``execute_batch`` raises on a 207,
    the buffer's flush MUST rewrite proxies for the commands that
    succeeded before the failure. Otherwise the next eager flush ships
    dead client UUIDs and the cascade restarts.

    Pinned because the legacy code's ``except Exception: raise`` skipped
    every rewrite, which is exactly what preview-session
    ``thread_bafba02b`` got bitten by."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                applied=[
                    {
                        "index": 0,
                        "type": "CreateParagraph",
                        "result": {
                            "client_node_id": "p_first",
                            "real_node_id": "real_para_id",
                        },
                    },
                ],
                err_cmd_type="Insert",
                err_message='Block "phantom-cell-id" not found.',
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")
    buffer = CommandBuffer(client, "asset_test")

    proxy = _Proxy(client_id="p_first")
    buffer.register_proxy_id_ref("p_first", proxy, attr="_node_id")
    buffer.call(
        CreateParagraph(
            text="A",
            at={"kind": "documentEnd"},
            client_node_id="p_first",
        ),
    )

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError):
            buffer.flush()

    assert proxy._node_id == "real_para_id", (
        "Even though the batch raised on Insert, the CreateParagraph that "
        "preceded it DID commit server-side. The buffer must rewrite the "
        "proxy from its client UUID to the real id before the next batch "
        "fires — otherwise that next batch ships 'p_first' to the server, "
        "the server says 'Block not found', and the cascade restarts."
    )


def test_buffer_flush_succeeds_when_partial_applied_is_empty() -> None:
    """The cascade-fix path must be a no-op when the partial-applied
    list is empty (e.g. the batch's *first* command failed). Used to
    pin that we don't accidentally swallow the original exception."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                applied=[],
                err_cmd_type="CreateParagraph",
                err_message='Block "phantom-cell-id" not found.',
                err_index=0,
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")
    buffer = CommandBuffer(client, "asset_test")
    proxy = _Proxy(client_id="p_orphan")
    buffer.register_proxy_id_ref("p_orphan", proxy, attr="_node_id")
    buffer.call(
        CreateParagraph(
            text="A",
            at={"kind": "documentEnd"},
            client_node_id="p_orphan",
        ),
    )

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError):
            buffer.flush()

    # Nothing committed → proxy stays on its client UUID. The applier's
    # per-batch ``clientIdMap`` rewrite will still resolve it on the
    # NEXT request as long as the agent re-issues both ops together.
    assert proxy._node_id == "p_orphan"


def test_table_query_block_not_found_carries_table_hint() -> None:
    """``BlockNotFoundError`` on a ``TablesGet`` (or ``TablesGetCells``,
    etc.) must NOT carry the cell-paragraph hint — the failure mode is
    different (stale client-table-UUID from an earlier failed batch),
    and the workaround is different (``doc.save()`` to drain pending +
    re-anchor proxies). Pinned because preview-session
    ``thread_bafba02b`` hit this shape and the cell-paragraph hint
    would have been a red herring."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                applied=[],
                err_cmd_type="TablesGet",
                err_message='Block with nodeId "t_cee14bdf2038" was not found.',
                err_index=0,
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError) as exc_info:
            client.execute_batch(
                "asset_test",
                [
                    CreateParagraph(
                        text="placeholder so the batch isn't empty",
                        at={"kind": "documentEnd"},
                    ),
                ],
            )

    msg = str(exc_info.value)
    assert "cell.text" not in msg, (
        "Cell-paragraph hint must NOT fire for table queries — wrong "
        "workaround for the wrong failure mode."
    )
    assert "doc.save()" in msg, (
        "Table-query block-not-found should point at the actual "
        "recovery: drain pending mutations + re-anchor proxies via "
        "doc.save() before retrying."
    )
    assert "client-side table UUID" in msg or "t_xxxxxxxxxxxx" in msg, (
        "Hint should name the client-UUID shape so the agent recognizes "
        "what they're holding."
    )
