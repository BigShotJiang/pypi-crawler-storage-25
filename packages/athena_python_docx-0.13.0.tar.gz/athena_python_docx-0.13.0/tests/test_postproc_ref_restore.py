"""Unit tests for §18 REF-field round-trip preservation in
``docx._postproc``.

Pins the capture-on-template + restore-on-export contract for REF
field codes that SuperDoc 1.23.1 / SDK 1.8.1 strips on import. See
``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 18.
"""
from __future__ import annotations

import io
import zipfile
from xml.etree import ElementTree as ET

from docx._postproc import (
    PostExportOps,
    _count_ref_fields,
)


W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
W_NS = f"{{{W}}}"


_CONTENT_TYPES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>
"""

_ROOT_RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>
"""


def _make_docx(*, document_xml: str) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", _CONTENT_TYPES_XML)
        z.writestr("_rels/.rels", _ROOT_RELS_XML)
        z.writestr("word/document.xml", document_xml)
    return buf.getvalue()


def _extract_document_xml(docx_bytes: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as z:
        return z.read("word/document.xml").decode("utf-8")


# A single-paragraph body with one REF field of the shape SuperDoc strips.
_DOC_WITH_REF = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t xml:space="preserve">See </w:t></w:r>
      <w:r><w:fldChar w:fldCharType="begin"/></w:r>
      <w:r><w:instrText xml:space="preserve"> REF _Ref140079640 \\h \\w \\* MERGEFORMAT </w:instrText></w:r>
      <w:r><w:fldChar w:fldCharType="separate"/></w:r>
      <w:r><w:t>Section 3.02(b)</w:t></w:r>
      <w:r><w:fldChar w:fldCharType="end"/></w:r>
      <w:r><w:t xml:space="preserve"> for context.</w:t></w:r>
    </w:p>
  </w:body>
</w:document>""".format(ns=W)


# The same paragraph as it'd appear AFTER SuperDoc round-trip: REF stripped,
# result text gone, "See " and " for context." linger as orphans.
_DOC_WITH_REF_STRIPPED = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t xml:space="preserve">See </w:t></w:r>
      <w:r><w:t xml:space="preserve"> for context.</w:t></w:r>
    </w:p>
  </w:body>
</w:document>""".format(ns=W)


# Body with TWO REF fields in the same paragraph (Paul Weiss "Section X and
# Section Y" pattern).
_DOC_WITH_TWO_REFS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t xml:space="preserve">See </w:t></w:r>
      <w:r><w:fldChar w:fldCharType="begin"/></w:r>
      <w:r><w:instrText xml:space="preserve"> REF _A </w:instrText></w:r>
      <w:r><w:fldChar w:fldCharType="separate"/></w:r>
      <w:r><w:t>Section 1</w:t></w:r>
      <w:r><w:fldChar w:fldCharType="end"/></w:r>
      <w:r><w:t xml:space="preserve"> and </w:t></w:r>
      <w:r><w:fldChar w:fldCharType="begin"/></w:r>
      <w:r><w:instrText xml:space="preserve"> REF _B </w:instrText></w:r>
      <w:r><w:fldChar w:fldCharType="separate"/></w:r>
      <w:r><w:t>Section 2</w:t></w:r>
      <w:r><w:fldChar w:fldCharType="end"/></w:r>
    </w:p>
  </w:body>
</w:document>""".format(ns=W)


# Body with PAGEREF (preserved by SuperDoc) — capture should skip it.
_DOC_WITH_PAGEREF = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t xml:space="preserve">See page </w:t></w:r>
      <w:r><w:fldChar w:fldCharType="begin"/></w:r>
      <w:r><w:instrText xml:space="preserve"> PAGEREF _Ref1 </w:instrText></w:r>
      <w:r><w:fldChar w:fldCharType="separate"/></w:r>
      <w:r><w:t>12</w:t></w:r>
      <w:r><w:fldChar w:fldCharType="end"/></w:r>
    </w:p>
  </w:body>
</w:document>""".format(ns=W)


def test_count_ref_fields_recognizes_ref_with_space():
    p = ET.fromstring(_DOC_WITH_REF).find(f"{W_NS}body/{W_NS}p")
    assert _count_ref_fields(p) == 1


def test_count_ref_fields_counts_two_in_one_paragraph():
    p = ET.fromstring(_DOC_WITH_TWO_REFS).find(f"{W_NS}body/{W_NS}p")
    assert _count_ref_fields(p) == 2


def test_count_ref_fields_excludes_pageref():
    """PAGEREF starts with REF too but no trailing space; the count
    excludes it."""
    p = ET.fromstring(_DOC_WITH_PAGEREF).find(f"{W_NS}body/{W_NS}p")
    assert _count_ref_fields(p) == 0


def test_capture_refs_from_template_finds_ref_paragraph():
    ops = PostExportOps()
    template_bytes = _make_docx(document_xml=_DOC_WITH_REF)
    captured_count = ops.capture_refs_from_template(template_bytes)
    assert captured_count == 1
    assert len(ops._captured_refs) == 1
    entry = ops._captured_refs[0]
    assert entry.source_paragraph_index == 0
    assert entry.ref_count == 1
    # Fingerprint deliberately EXCLUDES REF result text so source and
    # stripped versions hash to the same value — what survives is the
    # surrounding "See " and " for context." literal text.
    assert "section 3.02(b)" not in entry.fingerprint.lower()
    assert "see" in entry.fingerprint.lower()
    assert "for context" in entry.fingerprint.lower()


def test_capture_skips_paragraphs_without_refs():
    """Body with PAGEREF only — no REF captures."""
    ops = PostExportOps()
    template_bytes = _make_docx(document_xml=_DOC_WITH_PAGEREF)
    captured_count = ops.capture_refs_from_template(template_bytes)
    assert captured_count == 0
    assert not ops.has_pending()


def test_capture_handles_invalid_bytes_gracefully():
    """Non-zip bytes should produce 0 captures, not raise."""
    ops = PostExportOps()
    assert ops.capture_refs_from_template(b"definitely-not-a-zip") == 0
    assert ops.capture_refs_from_template(b"") == 0


def test_apply_to_docx_restores_stripped_ref_paragraph():
    """The full end-to-end: capture from source, then apply against
    the SuperDoc-round-tripped (stripped) version."""
    source_bytes = _make_docx(document_xml=_DOC_WITH_REF)
    stripped_bytes = _make_docx(document_xml=_DOC_WITH_REF_STRIPPED)

    ops = PostExportOps()
    ops.capture_refs_from_template(source_bytes)
    restored_bytes = ops.apply_to_docx(stripped_bytes)

    restored_root = ET.fromstring(_extract_document_xml(restored_bytes))
    restored_p = restored_root.find(f"{W_NS}body/{W_NS}p")
    assert _count_ref_fields(restored_p) == 1
    # The visible "Section 3.02(b)" text is back.
    plain = "".join(
        t.text or "" for t in restored_p.iter(f"{W_NS}t")
    )
    assert "Section 3.02(b)" in plain
    # And the surrounding " for context." also survived because the
    # whole paragraph was restored.
    assert "for context" in plain


def test_apply_to_docx_idempotent():
    """Running the restore against bytes that already have the REFs
    is a no-op."""
    source_bytes = _make_docx(document_xml=_DOC_WITH_REF)

    ops = PostExportOps()
    ops.capture_refs_from_template(source_bytes)
    # apply against source — should be unchanged
    restored = ops.apply_to_docx(source_bytes)
    # The bytes may not be byte-identical (zip metadata varies), but
    # the document.xml content should keep its 1 REF.
    p = ET.fromstring(_extract_document_xml(restored)).find(f"{W_NS}body/{W_NS}p")
    assert _count_ref_fields(p) == 1


def test_apply_to_docx_skips_paragraph_when_fingerprint_diverges():
    """If the user edited the paragraph text materially, the
    fingerprint won't match the capture and we skip rather than
    overwriting the user's edit."""
    source_bytes = _make_docx(document_xml=_DOC_WITH_REF)

    # An "exported" version where the user edited the paragraph
    # heavily — REF is stripped AND text changed:
    edited_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t>Totally different content here, you bet.</w:t></w:r>
    </w:p>
  </w:body>
</w:document>""".format(ns=W)
    edited_bytes = _make_docx(document_xml=edited_xml)

    ops = PostExportOps()
    ops.capture_refs_from_template(source_bytes)
    after = ops.apply_to_docx(edited_bytes)

    after_p = ET.fromstring(_extract_document_xml(after)).find(f"{W_NS}body/{W_NS}p")
    # The user's edit is preserved — the REF restoration is skipped.
    plain = "".join(t.text or "" for t in after_p.iter(f"{W_NS}t"))
    assert "Totally different" in plain
    # And no REF was injected over it.
    assert _count_ref_fields(after_p) == 0


def test_apply_to_docx_handles_index_drift():
    """If SuperDoc reorders paragraphs (rare but possible), the
    by-index lookup may miss. We skip rather than blow up."""
    source_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t>Intro paragraph.</w:t></w:r>
    </w:p>
    <w:p>
      <w:r><w:t xml:space="preserve">See </w:t></w:r>
      <w:r><w:fldChar w:fldCharType="begin"/></w:r>
      <w:r><w:instrText xml:space="preserve"> REF _A </w:instrText></w:r>
      <w:r><w:fldChar w:fldCharType="separate"/></w:r>
      <w:r><w:t>Section X</w:t></w:r>
      <w:r><w:fldChar w:fldCharType="end"/></w:r>
    </w:p>
  </w:body>
</w:document>""".format(ns=W)
    # Exported: only ONE paragraph (intro got dropped), so the REF
    # paragraph is now at index 0 instead of 1. Our by-index lookup
    # at index 1 misses; the captured REF can't be restored. The
    # exported bytes round-trip unchanged.
    exported_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t xml:space="preserve">See </w:t></w:r>
      <w:r><w:t xml:space="preserve"></w:t></w:r>
    </w:p>
  </w:body>
</w:document>""".format(ns=W)

    ops = PostExportOps()
    ops.capture_refs_from_template(_make_docx(document_xml=source_xml))
    after = ops.apply_to_docx(_make_docx(document_xml=exported_xml))
    after_root = ET.fromstring(_extract_document_xml(after))
    ps = after_root.findall(f"{W_NS}body/{W_NS}p")
    # Only one paragraph survives. Index 1 capture missed silently.
    # (Fingerprint at index 0 doesn't match the source's idx-1
    # fingerprint, so restore is skipped.)
    assert len(ps) == 1
    assert _count_ref_fields(ps[0]) == 0


def test_apply_to_docx_restores_paragraph_with_two_refs():
    source_bytes = _make_docx(document_xml=_DOC_WITH_TWO_REFS)
    stripped_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t xml:space="preserve">See </w:t></w:r>
      <w:r><w:t xml:space="preserve"> and </w:t></w:r>
    </w:p>
  </w:body>
</w:document>""".format(ns=W)
    stripped_bytes = _make_docx(document_xml=stripped_xml)

    ops = PostExportOps()
    ops.capture_refs_from_template(source_bytes)
    restored_bytes = ops.apply_to_docx(stripped_bytes)
    restored_p = ET.fromstring(
        _extract_document_xml(restored_bytes)
    ).find(f"{W_NS}body/{W_NS}p")
    assert _count_ref_fields(restored_p) == 2
    plain = "".join(t.text or "" for t in restored_p.iter(f"{W_NS}t"))
    assert "Section 1" in plain
    assert "Section 2" in plain


def test_apply_to_docx_combines_cell_format_and_ref_restoration():
    """Both rewrites in one ``apply_to_docx`` call — they don't
    interfere with each other."""
    from docx._postproc import CellAddress

    # Source: doc with one REF paragraph + one table with one cell.
    source_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t xml:space="preserve">Intro </w:t></w:r>
      <w:r><w:fldChar w:fldCharType="begin"/></w:r>
      <w:r><w:instrText xml:space="preserve"> REF _A </w:instrText></w:r>
      <w:r><w:fldChar w:fldCharType="separate"/></w:r>
      <w:r><w:t>Section X</w:t></w:r>
      <w:r><w:fldChar w:fldCharType="end"/></w:r>
    </w:p>
    <w:tbl><w:tr><w:tc>
      <w:p><w:r><w:t>cell text</w:t></w:r></w:p>
    </w:tc></w:tr></w:tbl>
  </w:body>
</w:document>""".format(ns=W)
    # Exported: REF stripped from paragraph 0; cell paragraph
    # untouched.
    exported_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:p>
      <w:r><w:t xml:space="preserve">Intro </w:t></w:r>
    </w:p>
    <w:tbl><w:tr><w:tc>
      <w:p><w:r><w:t>cell text</w:t></w:r></w:p>
    </w:tc></w:tr></w:tbl>
  </w:body>
</w:document>""".format(ns=W)

    ops = PostExportOps()
    ops.capture_refs_from_template(_make_docx(document_xml=source_xml))
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        alignment="right",
    )

    after = ops.apply_to_docx(_make_docx(document_xml=exported_xml))
    after_root = ET.fromstring(_extract_document_xml(after))

    # REF was restored on paragraph 0.
    p0 = after_root.findall(f"{W_NS}body/{W_NS}p")[0]
    assert _count_ref_fields(p0) == 1

    # Cell-inner paragraph got the alignment.
    cell_p = after_root.find(f"{W_NS}body/{W_NS}tbl/{W_NS}tr/{W_NS}tc/{W_NS}p")
    pPr = cell_p.find(f"{W_NS}pPr")
    assert pPr is not None
    assert pPr.find(f"{W_NS}jc").get(f"{W_NS}val") == "right"


def test_has_pending_true_when_only_refs_captured():
    """``has_pending`` should fire on either kind of pending state."""
    ops = PostExportOps()
    assert not ops.has_pending()
    source_bytes = _make_docx(document_xml=_DOC_WITH_REF)
    ops.capture_refs_from_template(source_bytes)
    assert ops.has_pending()


def test_captured_paragraph_xml_has_no_inter_element_whitespace():
    """Pretty-printed source XML has indentation/newlines between child
    elements; ET preserves those as text nodes inside the parent.
    Word's strict validator rejects text content directly inside
    ``<w:p>``/``<w:r>``/etc. (text must live in ``<w:t>``), so we
    strip inter-element whitespace at capture time.

    Regression test for the "Word found unreadable content" error
    surfaced by the PR #20805 comprehensive probe.
    """
    ops = PostExportOps()
    # _DOC_WITH_REF is pretty-printed across multiple lines.
    template_bytes = _make_docx(document_xml=_DOC_WITH_REF)
    ops.capture_refs_from_template(template_bytes)
    assert len(ops._captured_refs) == 1
    captured_xml = ops._captured_refs[0].paragraph_xml.decode("utf-8")
    # No whitespace text nodes between <w:p> and its first child
    import re

    assert (
        re.search(r"<[^>]*\bp\b[^>]*>\s+<", captured_xml) is None
    ), f"inter-element whitespace inside <w:p>: {captured_xml[:200]!r}"
    # No whitespace between sibling <w:r> elements
    assert (
        re.search(r"</[^>]*\br\b[^>]*>\s+<[^>]*\br\b[^>]*>", captured_xml) is None
    ), f"whitespace between sibling <w:r>: {captured_xml[:200]!r}"
    # But the actual <w:t> text content IS preserved
    assert "Section 3.02(b)" in captured_xml
    assert "REF _Ref140079640" in captured_xml


def test_namespace_declarations_survive_round_trip():
    """SuperDoc-exported ``word/document.xml`` declares ~40 OOXML
    namespaces on the root (``wpc``, ``cx``, ``cx1``..``cx8``,
    ``aink``, ``am3d``, ``w14``..``w16du``, etc). Many of these
    aren't USED by any element — they're declared because
    ``mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh
    w16sdtfl w16du wp14"`` references them by name.

    Python's stdlib ElementTree only emits ``xmlns:`` declarations
    for prefixes that ACTUALLY appear in element tags or attribute
    names — so a vanilla parse + serialize drops every unused
    declaration. The ``Ignorable`` attribute then references
    undeclared prefixes, which Word's strict validator surfaces as
    "unreadable content" on open.

    This test pins the regression: post-rewrite ``word/document.xml``
    must still declare every namespace the source declared.
    """
    # Build a doc with several declared-but-unused namespaces.
    docx_in = _make_docx(
        document_xml=(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:document '
            'xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas" '
            'xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex" '
            'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" '
            'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
            'xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml" '
            'xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml" '
            'mc:Ignorable="w14 w15 wpc cx">'
            '<w:body><w:p><w:r><w:t>Hello</w:t></w:r></w:p></w:body>'
            '</w:document>'
        ),
    )
    # Force the rewrite path (need at least one pending op so
    # apply_to_docx actually re-serializes the document).
    ops = PostExportOps()
    ref_template = _make_docx(document_xml=_DOC_WITH_REF)
    ops.capture_refs_from_template(ref_template)
    out = ops.apply_to_docx(docx_in)

    xml_out = _extract_document_xml(out)
    import re as _re

    # Find root xmlns declarations
    m = _re.search(r"<w:document([^>]*)>", xml_out)
    assert m is not None
    declared = set(
        _re.findall(r'xmlns:([A-Za-z][\w.-]*)=', m.group(1))
    )
    # All source-declared prefixes survived.
    for prefix in ["wpc", "cx", "mc", "w", "w14", "w15"]:
        assert prefix in declared, (
            f"prefix {prefix!r} dropped during rewrite; declared={sorted(declared)}"
        )
    # mc:Ignorable references must all be declared.
    mi = _re.search(r'mc:Ignorable="([^"]+)"', xml_out)
    assert mi is not None
    ignorable = mi.group(1).split()
    for prefix in ignorable:
        assert prefix in declared, (
            f"Ignorable prefix {prefix!r} not declared on root; declared={sorted(declared)}"
        )


def test_restored_xml_in_exported_doc_has_no_inter_element_whitespace():
    """End-to-end: after a capture + restore cycle, the
    word/document.xml in the output zip has no whitespace text nodes
    inside any paragraph that came from the captured template."""
    source_bytes = _make_docx(document_xml=_DOC_WITH_REF)
    stripped_bytes = _make_docx(document_xml=_DOC_WITH_REF_STRIPPED)
    ops = PostExportOps()
    ops.capture_refs_from_template(source_bytes)
    restored_bytes = ops.apply_to_docx(stripped_bytes)
    xml = _extract_document_xml(restored_bytes)
    import re

    assert (
        re.search(r"<[^>]*\bp\b[^>]*>\s+<[^>]*\br\b", xml) is None
    ), f"restored doc.xml has whitespace inside <w:p>: {xml[:500]!r}"
    assert (
        re.search(r"</[^>]*\br\b[^>]*>\s+<[^>]*\br\b[^>]*>", xml) is None
    ), f"restored doc.xml has whitespace between </w:r><w:r>: {xml[:500]!r}"
