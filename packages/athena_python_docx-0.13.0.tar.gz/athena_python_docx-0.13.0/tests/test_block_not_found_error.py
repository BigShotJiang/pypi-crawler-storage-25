"""Lock-in tests for :class:`BlockNotFoundError` and the cell-paragraph hint.

Background: SuperDoc 1.8.1 cannot apply paragraph-format ops (alignment,
style, indentation, spacing) or ``doc.insert`` with a paragraph-block
target when the target paragraph is nested inside a table cell. The
SDK detects the ``Block "paragraph:<uuid>" was not found`` shape in
the partial-failure payload and rewraps it as :class:`BlockNotFoundError`
with an actionable hint so agent code doesn't burn retries discovering
the limitation.

These tests pin the typed-error path and the hint message so a future
refactor of ``_http_post_json`` can't silently regress to the generic
:class:`DocxError`.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import patch

import pytest

from docx._http_doc import HttpClient, HttpDocHandle
from docx.errors import BlockNotFoundError, DocxError, NotFoundError


class _FakeResponse:
    def __init__(self, *, status_code: int, body: bytes | str) -> None:
        self.status_code = status_code
        if isinstance(body, bytes):
            self._body_text = body.decode("utf-8", errors="replace")
        else:
            self._body_text = body

    @property
    def text(self) -> str:
        return self._body_text

    def json(self) -> Any:
        return json.loads(self._body_text)


def _partial_failure_body(*, cmd_type: str, message: str, applied: list[Any] | None = None) -> bytes:
    """Serialize the 207-Multi-Status body docx-studio returns on a
    partial-batch failure."""
    return json.dumps(
        {
            "assetId": "asset_test",
            "applied": applied or [],
            "error": {
                "index": 0,
                "type": cmd_type,
                "error": "SuperDocCliError",
                "message": message,
            },
        },
    ).encode("utf-8")


def _execute_setalignment(client: HttpClient) -> None:
    """Drive a single SetParagraphAlignment through the buffer + HTTP path
    so the partial-failure branch executes against a real command shape."""
    import asyncio

    doc = HttpDocHandle(client, "asset_test")
    asyncio.run(
        doc.format.paragraph.set_alignment(
            {
                "target": {
                    "kind": "block",
                    "nodeType": "paragraph",
                    "nodeId": "phantom-cell-paragraph-uuid",
                },
                "alignment": "center",
            },
        ),
    )
    # SetParagraphAlignment is buffered; force the flush so the 207
    # actually fires.
    doc.buffer.flush()


def test_insert_block_not_found_carries_cell_hint() -> None:
    """A ``Block "<bare-uuid>" not found`` miss on an ``Insert`` command
    is the dominant form of the cell-paragraph addressing bug — the
    SuperDoc CLI emits ``Block "<uuid>" not found.`` (no type prefix)
    when ``doc.insert`` can't find a paragraph nested inside a cell. The
    hint must fire here even though the message lacks the ``paragraph:``
    prefix; gating on the failing command type (``Insert``) lets us
    catch it.

    Pinned because the prefix-only gate in the first pass of this
    work (post-Greptile #20555) silently skipped the hint on the
    bare-UUID shape, costing the agent four retries on preview-
    session thread_b952794f."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                cmd_type="Insert",
                message='Block "c0698253-2720-453d-8f7e-1872146ea5d0" not found.',
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError) as exc_info:
            _execute_setalignment(client)

    msg = str(exc_info.value)
    assert "cell.add_paragraph" in msg, (
        "Insert + bare-UUID Block-not-found is the most common shape "
        "of the SuperDoc cell-paragraph addressing bug; the hint MUST "
        "fire for it and MUST recommend ``cell.add_paragraph(...)`` as "
        "the workaround (0.11.4+ updated the hint to drop the "
        "``cell.text = '...'; paragraphs[0]`` advice which was subtly "
        "wrong about list indexing). If you're refactoring the gate, "
        "key on the failing command type (err_obj['type']), not on a "
        "message substring."
    )


def test_non_paragraph_command_block_not_found_skips_hint() -> None:
    """A ``Block ... not found`` miss on a non-paragraph-targeting
    command (a stale image id from ``SetImageSize``, a deleted list
    node from ``ListsAttach``, etc.) must still raise
    :class:`BlockNotFoundError` but must NOT carry the cell-paragraph
    workaround hint — those failure modes don't benefit from the
    ``cell.add_paragraph(...)`` workaround and the wrong-hint cost is
    a wasted retry."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                cmd_type="SetImageSize",
                message='Block "img-deleted-id" not found.',
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError) as exc_info:
            _execute_setalignment(client)

    msg = str(exc_info.value)
    assert "cell.add_paragraph" not in msg, (
        "Block-not-found on non-paragraph-targeting commands "
        "(SetImageSize, ListsAttach, etc.) must NOT carry the "
        "cell-paragraph hint — these have nothing to do with the "
        "cell-inner-paragraph addressing gap and the wrong hint costs "
        "the next retry."
    )


def test_block_not_found_raises_typed_error() -> None:
    """SuperDoc's ``Block "paragraph:<uuid>" was not found`` must raise
    :class:`BlockNotFoundError`, not the generic :class:`DocxError`.
    Subclass check confirms typed-error subclass chain stays consistent
    (``BlockNotFoundError`` ▶ ``NotFoundError`` ▶ ``DocxError``)."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                cmd_type="SetParagraphAlignment",
                message='Block "paragraph:f3fd7e05-f4a3-4054-897a-87439ca8bc4a" was not found.',
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError) as exc_info:
            _execute_setalignment(client)

    err = exc_info.value
    assert isinstance(err, NotFoundError)
    assert isinstance(err, DocxError)
    # The hint must point at the ``cell.add_paragraph(...)`` workaround
    # so agents don't repeat the same failed pattern. It must also
    # explicitly call out that ``cell.paragraphs[0]`` is the broken
    # pattern (the cell's original inner paragraph isn't addressable).
    assert "cell.add_paragraph" in str(err)
    assert "cell.paragraphs[0]" in str(err)
    # Structured payload preserved for programmatic callers.
    assert err.payload["type"] == "SetParagraphAlignment"
    assert err.payload["error"] == "SuperDocCliError"


def test_block_not_found_id_extraction() -> None:
    """``BlockNotFoundError.block_id`` parses the bare UUID out of the
    SuperDoc-formatted ``Block "<type>:<uuid>" was not found`` message
    so programmatic callers can match a known proxy id."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                cmd_type="Insert",
                message='Block "c0698253-2720-453d-8f7e-1872146ea5d0" not found.',
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError) as exc_info:
            _execute_setalignment(client)

    assert exc_info.value.block_id == "c0698253-2720-453d-8f7e-1872146ea5d0"


def test_block_not_found_id_extraction_with_type_prefix() -> None:
    """The SuperDoc CLI's quoted-id format ``<type>:<uuid>`` is also
    supported — the prefix gets stripped so ``block_id`` returns the bare
    UUID."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                cmd_type="SetParagraphStyle",
                message='Block "paragraph:a3b27fb8-4df4-4778-9067-75dc7b285d7c" was not found.',
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError) as exc_info:
            _execute_setalignment(client)

    assert exc_info.value.block_id == "a3b27fb8-4df4-4778-9067-75dc7b285d7c"


def test_generic_not_found_still_raises_notfounderror() -> None:
    """Non-block "not found" misses (a missing comment id, e.g.) keep
    the generic :class:`NotFoundError` path. Otherwise speculative
    ``Comments.get`` reads would suddenly start raising
    :class:`BlockNotFoundError`."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                cmd_type="CommentsGet",
                message='Comment "c-missing" does not exist.',
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(NotFoundError) as exc_info:
            _execute_setalignment(client)

    # Same typed class — but NOT the BlockNotFoundError narrower one.
    assert type(exc_info.value) is NotFoundError, (
        "Generic comment misses must keep the wider NotFoundError type, "
        "not the BlockNotFoundError narrower one — call sites that "
        "speculatively read comments need this distinction to coerce "
        "to None correctly."
    )


def test_invalid_target_tablecell_routes_through_block_not_found() -> None:
    """SuperDoc's newer cell-paragraph addressing-error shape

        ``INVALID_TARGET - Expected paragraph:<uuid> but found tableCell:<id>.``

    must surface as :class:`BlockNotFoundError` with the cell-paragraph
    hint, same as the older ``Block "paragraph:<uuid>" was not found``
    form. Both error shapes share the same root cause (SUPERDOC_UPSTREAM_
    REQUESTS § 13) — agents shouldn't have to learn which variant fired
    to find the recovery path."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                cmd_type="SetParagraphAlignment",
                message=(
                    "INVALID_TARGET - Expected paragraph:"
                    "2d58567b-e933-4f72-bfde-674e7b552f8a but found "
                    "tableCell:cell-auto-38f799d7."
                ),
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError) as exc_info:
            _execute_setalignment(client)

    msg = str(exc_info.value)
    assert "cell.add_paragraph" in msg, (
        "INVALID_TARGET ... but found tableCell is the new variant of "
        "the cell-paragraph addressing gap (SUPERDOC_UPSTREAM_REQUESTS "
        "§ 13). The hint MUST fire here just like the older 'Block "
        "not found' form."
    )


def test_invalid_target_create_paragraph_routes_through_block_not_found() -> None:
    """``CreateParagraph`` against a cell-inner paragraph anchor (the
    pre-0.11.x ``_Cell.add_paragraph`` shape) raises the INVALID_TARGET
    form. ``_Cell.add_paragraph`` now routes through ``doc.insert``
    instead, but other call sites that build a Create with a cell-inner
    target should still get the hint instead of a generic DocxError."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                cmd_type="CreateParagraph",
                message=(
                    "INVALID_TARGET - Expected paragraph:"
                    "2d58567b-e933-4f72-bfde-674e7b552f8a but found "
                    "tableCell:cell-auto-38f799d7."
                ),
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(BlockNotFoundError) as exc_info:
            _execute_setalignment(client)

    msg = str(exc_info.value)
    assert "cell.add_paragraph" in msg


def test_transport_error_unchanged() -> None:
    """A genuine 5xx or validation error must NOT be reclassified as
    :class:`BlockNotFoundError`. Only the "Block ... not found" shape
    routes there."""

    def _capture(url: str, **kwargs: Any) -> _FakeResponse:  # noqa: ARG001
        return _FakeResponse(
            status_code=207,
            body=_partial_failure_body(
                cmd_type="CreateParagraph",
                message="ValidationError: at.kind must be one of documentEnd|before|after",
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    with patch.object(client._session, "post", side_effect=_capture):
        with pytest.raises(DocxError) as exc_info:
            _execute_setalignment(client)

    assert not isinstance(exc_info.value, BlockNotFoundError)
    assert not isinstance(exc_info.value, NotFoundError)
