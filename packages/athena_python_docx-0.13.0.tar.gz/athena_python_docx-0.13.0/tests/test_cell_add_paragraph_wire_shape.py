"""Wire-shape lock-in for ``_Cell.add_paragraph``.

Pre-fix: the SDK anchored ``create.paragraph`` after the cell's last
inner paragraph (``at: {kind: "after", target: paragraph(<inner-id>)}``).
SuperDoc 1.8.1 cannot resolve that anchor for cell-inner paragraphs
and raises ``INVALID_TARGET - Expected paragraph:<id> but found
tableCell:<id>``. See ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 13.

Post-fix: the SDK routes through ``doc.insert`` with the cell itself
as target and ``placement: "insideEnd"`` — the same wire path that
``_Cell.text`` already uses successfully.
"""

from __future__ import annotations

from typing import Any


def _make_cell(mock_session: Any, fake_sd_methods: Any) -> Any:
    from docx.table import Table, _Cell

    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [
            {
                "nodeId": "cell-auto-abc123",
                "rowIndex": 0,
                "columnIndex": 0,
                "text": "existing content",
            },
        ],
    }
    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "kind": "tableCell",
            "id": "cell-auto-abc123",
            "tableCell": {
                "paragraphs": [
                    {"kind": "paragraph", "id": "para-existing-1"},
                    {"kind": "paragraph", "id": "para-new-2"},
                ],
            },
        },
    }

    table = Table(session=mock_session, node_id="tbl-1")
    return _Cell(table=table, row=0, col=0)


def test_cell_add_paragraph_routes_through_insert(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``cell.add_paragraph('hi')`` MUST NOT call ``create.paragraph``
    with a cell-inner-paragraph anchor.

    The pre-fix wire shape was:
        create.paragraph({
            text: "hi",
            at: {kind: "after",
                 target: {nodeType: "paragraph", nodeId: <inner-id>}},
        })

    That shape provokes SuperDoc 1.8.1's INVALID_TARGET error on every
    cell loaded from a real .docx (every such cell has at least one
    inner paragraph). The post-fix shape uses ``doc.insert`` against
    the cell with ``placement: insideEnd``.
    """
    cell = _make_cell(mock_session, fake_sd_methods)

    cell.add_paragraph("hi")

    insert_calls = [c for c in fake_sd_methods.calls if c[0] == "insert"]
    assert insert_calls, (
        "Expected _Cell.add_paragraph to call doc.insert, but only saw "
        f"{[c[0] for c in fake_sd_methods.calls]}"
    )
    _, params = insert_calls[-1]
    assert params["target"] == {
        "kind": "block",
        "nodeType": "tableCell",
        "nodeId": "cell-auto-abc123",
    }, f"target must be the cell itself, not its inner paragraph; got {params['target']!r}"
    assert params["placement"] == "insideEnd"
    content = params["content"]
    assert isinstance(content, dict)
    assert content["kind"] == "paragraph"
    inlines = content["paragraph"]["inlines"]
    assert inlines == [{"kind": "run", "run": {"text": "hi"}}]

    create_para_calls = [
        c for c in fake_sd_methods.calls if c[0] == "create.paragraph"
    ]
    for _, p in create_para_calls:
        at = p.get("at") or {}
        target = at.get("target") or {}
        assert target.get("nodeType") != "paragraph" or not str(
            target.get("nodeId", "")
        ).startswith("para-"), (
            "create.paragraph must not anchor to a cell-inner "
            f"paragraph (got at={at!r})"
        )


def test_cell_add_paragraph_empty_text_emits_empty_inlines(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``cell.add_paragraph()`` (no text) inserts a paragraph fragment
    with an empty inlines list — the same shape ``_Cell.text = ''``
    produces."""
    cell = _make_cell(mock_session, fake_sd_methods)

    cell.add_paragraph()

    insert_calls = [c for c in fake_sd_methods.calls if c[0] == "insert"]
    assert insert_calls
    _, params = insert_calls[-1]
    assert params["content"]["paragraph"]["inlines"] == []


def test_cell_add_paragraph_returns_paragraph_with_node_id(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """The returned ``Paragraph`` proxy must carry a real node_id so
    follow-up operations (``para.style = ...``, ``para.add_run(...)``)
    address the new paragraph rather than its containing cell.
    """
    cell = _make_cell(mock_session, fake_sd_methods)

    para = cell.add_paragraph("hi")

    from docx.text.paragraph import Paragraph

    assert isinstance(para, Paragraph)
    assert para._node_id, "Paragraph proxy must carry a non-empty node_id"
