"""Compare two package surface snapshots and emit a structured gap report.

Inputs are two JSON files produced by ``introspect.py`` — typically
``upstream_python_docx_<version>.json`` (the canonical reference) and
``athena_latest.json`` (the live SDK).

The report is emitted as both:

  * a Python ``GapReport`` dataclass (importable by the pytest harness),
  * a markdown rendering written to ``--out FILE``.

Gap categories produced:

  1. ``module_missing``     — module present upstream, absent in athena
  2. ``class_missing``      — class present in some upstream module,
                              absent in the corresponding athena module
                              and absent everywhere in athena
  3. ``member_missing``     — class present, but a public method /
                              property / classmethod / staticmethod is
                              missing
  4. ``member_kind_drift``  — same name on both sides but different kind
                              (e.g., property vs. method)
  5. ``signature_drift``    — same callable on both sides but different
                              parameter names / kinds / defaults
  6. ``ctor_signature_drift`` — class constructor signatures differ
  7. ``return_annotation_drift`` — return annotations differ (informational)

Findings are filtered through ``intentional_deviations.json`` so the
deliberate, documented divergences from python-docx (see
``python-sdk/CLAUDE.md`` § "Intentionally omitted") don't appear as
gaps.
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterable, Literal

GapKind = Literal[
    "module_missing",
    "class_missing",
    "member_missing",
    "member_kind_drift",
    "signature_drift",
    "ctor_signature_drift",
    "return_annotation_drift",
]


@dataclass
class Finding:
    kind: GapKind
    location: str  # dotted path to the missing/drifted member
    detail: dict[str, Any] = field(default_factory=dict)
    severity: str = "important"  # critical / important / minor — heuristic
    intentional: bool = False  # filtered against allowlist


@dataclass
class GapReport:
    upstream_version: str | None
    upstream_modules: int
    athena_version: str | None
    athena_modules: int
    findings: list[Finding] = field(default_factory=list)
    deviations_file: str | None = None

    @property
    def actionable(self) -> list[Finding]:
        return [f for f in self.findings if not f.intentional]

    @property
    def intentional(self) -> list[Finding]:
        return [f for f in self.findings if f.intentional]

    def by_kind(self, kind: GapKind) -> list[Finding]:
        return [f for f in self.findings if f.kind == kind]

    def to_dict(self) -> dict[str, Any]:
        return {
            "upstream_version": self.upstream_version,
            "upstream_modules": self.upstream_modules,
            "athena_version": self.athena_version,
            "athena_modules": self.athena_modules,
            "deviations_file": self.deviations_file,
            "findings": [asdict(f) for f in self.findings],
        }


_CALLABLE_KINDS = {"method", "function", "classmethod", "staticmethod"}

# Class members that are introspection artifacts of `collections.abc` /
# `enum` / dataclasses bookkeeping. Hide them from the report — they
# carry no parity signal.
_NOISE_MEMBERS = {
    "_abc_impl",      # collections.abc.Sequence registers ABC private state
    "_member_names_", # enum bookkeeping
    "_member_map_",
    "_value2member_map_",
    "_unhashable_values_",
    "_use_args_",
    "_member_type_",
    "_value_repr_",
    "_generate_next_value_",
    "_missing_",
    "_ignore_",
    "_sort_order_",
    "_hashable_values_",
}


_ENUM_REPR_RE = re.compile(r"^<([\w.]+\.[\w]+):.*>$")


_FORWARD_REF_RE = re.compile(r"'([A-Za-z_][\w.]*)'")


def _normalize_annotation(ann: str | None) -> str | None:
    """Strip both outer and inline forward-reference quote chars.

    Under ``from __future__ import annotations``, ``-> Paragraph`` and
    ``-> "Paragraph"`` both produce string annotations at runtime — but
    the second carries literal quote characters in its source text.
    Same goes for nested refs like ``list['_Cell']`` vs ``list[_Cell]``.
    All refer to the same forward reference; treat them as equal.
    """
    if not isinstance(ann, str):
        return ann
    s = ann.strip()
    # Outer quotes
    if (s.startswith("'") and s.endswith("'") and len(s) >= 2) or (
        s.startswith('"') and s.endswith('"') and len(s) >= 2
    ):
        s = s[1:-1]
    # Inline forward-ref quotes around identifier-like tokens
    s = _FORWARD_REF_RE.sub(r"\1", s)
    return s


def _normalize_default(default: str) -> str:
    """Normalize default-value reprs so the same enum member compares
    equal regardless of its underlying int/str value.

    ``<WD_SECTION_START.NEW_PAGE: 2>`` and
    ``<WD_SECTION_START.NEW_PAGE: 'nextPage'>`` both normalize to
    ``<WD_SECTION_START.NEW_PAGE>`` — the *member identity* is what
    matters for parity, not the underlying value the SDK assigns.
    """
    if not isinstance(default, str):
        return default
    m = _ENUM_REPR_RE.match(default)
    if m:
        return f"<{m.group(1)}>"
    return default


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def _index_classes(snapshot: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Map ``module.ClassName`` → class entry, resolving re-exports.

    Both canonical declarations and re-exports are indexed so a lookup
    of either path resolves.
    """
    index: dict[str, dict[str, Any]] = {}
    for mod_name, mod in snapshot["modules"].items():
        for member_name, entry in mod.get("members", {}).items():
            if entry.get("kind") == "class":
                index[f"{mod_name}.{member_name}"] = entry
            elif entry.get("kind") == "class_reexport":
                # Resolve via canonical path on a second pass below.
                pass
    # Second pass: copy re-exports → canonical
    for mod_name, mod in snapshot["modules"].items():
        for member_name, entry in mod.get("members", {}).items():
            if entry.get("kind") == "class_reexport":
                canon = entry["canonical"]
                if canon in index:
                    index[f"{mod_name}.{member_name}"] = index[canon]
    return index


def _all_class_qualnames(snapshot: dict[str, Any]) -> set[str]:
    """Set of canonical ``module.QualName`` for every class defined in
    the snapshot (canonical, not re-export)."""
    out: set[str] = set()
    for mod_name, mod in snapshot["modules"].items():
        for member_name, entry in mod.get("members", {}).items():
            if entry.get("kind") == "class":
                out.add(f"{entry['module']}.{entry['qualname']}")
    return out


def _signatures_equal(a: dict[str, Any] | None, b: dict[str, Any] | None) -> bool:
    """Compare two serialized signatures for parity-relevant equality.

    Equal means: same parameter list (names + kinds + defaults). Return
    annotations and per-param annotations are tracked separately because
    typing drift is informational, not breaking, for runtime callers.
    """
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    pa = a.get("params", [])
    pb = b.get("params", [])
    if len(pa) != len(pb):
        return False
    for x, y in zip(pa, pb):
        if x["name"] != y["name"]:
            return False
        if x["kind"] != y["kind"]:
            return False
        if _normalize_default(x["default"]) != _normalize_default(y["default"]):
            return False
    return True


def _signature_diff_detail(
    a: dict[str, Any] | None, b: dict[str, Any] | None
) -> dict[str, Any]:
    return {
        "upstream": a,
        "athena": b,
    }


def _matches_allowlist_pattern(needle: str, patterns: Iterable[str]) -> bool:
    """A pattern is either a literal dotted path or a glob with `*` (which
    becomes ``[^.]*``) or `**` (which becomes ``.*``). Anchored at both
    ends. Empty/whitespace-only patterns and ``_comment*`` rationale
    pseudo-entries are ignored."""
    for pat in patterns:
        if not pat or not pat.strip():
            continue
        if pat.startswith("_comment"):
            continue
        regex = re.escape(pat).replace(r"\*\*", ".*").replace(r"\*", "[^.]*")
        if re.fullmatch(regex, needle):
            return True
    return False


def _filter_comment_keys(data: dict[str, Any]) -> dict[str, Any]:
    """Drop top-level comment keys (``_README``, ``_comment*``)."""
    return {
        k: v
        for k, v in data.items()
        if not (k.startswith("_README") or k.startswith("_comment"))
    }


def _classify_severity(kind: GapKind, detail: dict[str, Any]) -> str:
    """Heuristic severity. Used only for sorting/grouping in the report.

    - critical: top-level facade gone (Document, Table, Paragraph) or
      a constructor signature changed
    - important: missing public method/property or signature drift on
      a public API surface
    - minor: return-annotation-only drift, or missing internal helper
    """
    if kind == "ctor_signature_drift":
        return "critical"
    if kind in ("module_missing", "class_missing"):
        loc = detail.get("location", "") or ""
        # Top-level facade modules / classes are critical
        critical_classes = {
            "Document", "Paragraph", "Run", "Table", "_Cell", "_Row",
            "_Column", "Section", "Sections", "Font", "Hyperlink",
            "ParagraphFormat", "InlineShape", "InlineShapes",
            "Styles", "BaseStyle", "ParagraphStyle", "CharacterStyle",
            "TableStyle", "CoreProperties",
        }
        leaf = loc.rsplit(".", 1)[-1]
        if leaf in critical_classes:
            return "critical"
        return "important"
    if kind == "return_annotation_drift":
        return "minor"
    return "important"


def _enumerate_classes_with_module(
    snapshot: dict[str, Any],
) -> list[tuple[str, dict[str, Any]]]:
    """Yield ``(dotted_path, class_entry)`` for canonical class definitions
    only (no re-exports). The dotted path is the path the class was
    *defined* at, e.g., ``docx.text.run.Run``."""
    out = []
    for mod_name, mod in snapshot["modules"].items():
        for member_name, entry in mod.get("members", {}).items():
            if entry.get("kind") != "class":
                continue
            if entry.get("module") != mod_name:
                # Re-export disguised as a class (rare). Skip.
                continue
            out.append((f"{mod_name}.{member_name}", entry))
    return out


def compare(
    upstream: dict[str, Any],
    athena: dict[str, Any],
    deviations: dict[str, Any] | None = None,
) -> GapReport:
    deviations = _filter_comment_keys(deviations or {})
    miss_modules: list[str] = list(deviations.get("missing_modules", []))
    miss_classes: list[str] = list(deviations.get("missing_classes", []))
    miss_members: dict[str, list[str]] = {
        k: v
        for k, v in dict(deviations.get("missing_members", {})).items()
        if not k.startswith("_comment")
    }
    sig_drift: dict[str, list[str]] = {
        k: v
        for k, v in dict(deviations.get("signature_drift", {})).items()
        if not k.startswith("_comment")
    }
    # ``universal_missing_members`` applies to *every* class. Members like
    # ``part`` (package-part access) and ``element`` (lxml node access)
    # are XML-layer concepts that no athena class can sensibly expose.
    universal_miss: list[str] = [
        m for m in deviations.get("universal_missing_members", [])
        if m and not m.startswith("_comment")
    ]

    athena_classes_by_path = _index_classes(athena)
    athena_class_qualnames = _all_class_qualnames(athena)

    findings: list[Finding] = []

    # ── 1. Modules present upstream, absent in athena ─────────────────
    upstream_mods = set(upstream["modules"])
    athena_mods = set(athena["modules"])
    for mod_name in sorted(upstream_mods - athena_mods):
        intentional = _matches_allowlist_pattern(mod_name, miss_modules)
        findings.append(
            Finding(
                kind="module_missing",
                location=mod_name,
                detail={
                    "upstream_member_count": len(
                        upstream["modules"][mod_name].get("members", {})
                    ),
                },
                severity=_classify_severity("module_missing", {"location": mod_name}),
                intentional=intentional,
            )
        )

    # ── 2-5. Per-class checks (only for canonical class declarations) ─
    for cls_path, up_cls in _enumerate_classes_with_module(upstream):
        ath_cls = athena_classes_by_path.get(cls_path)

        canonical_qualname = f"{up_cls['module']}.{up_cls['qualname']}"
        if ath_cls is None:
            # The class might be defined elsewhere in athena. Check by
            # qualname before declaring it missing.
            if canonical_qualname in athena_class_qualnames:
                # Defined under a different module path — count as a
                # member-level concern, but not a missing class.
                continue
            intentional = _matches_allowlist_pattern(
                cls_path, miss_classes
            ) or _matches_allowlist_pattern(canonical_qualname, miss_classes)
            findings.append(
                Finding(
                    kind="class_missing",
                    location=cls_path,
                    detail={
                        "qualname": up_cls["qualname"],
                        "bases": up_cls["bases"],
                        "upstream_member_count": len(up_cls["members"]),
                    },
                    severity=_classify_severity(
                        "class_missing", {"location": cls_path}
                    ),
                    intentional=intentional,
                )
            )
            continue

        # Class found on both sides — diff its members & ctor.
        # 6. Constructor signature
        if not _signatures_equal(
            up_cls.get("ctor_signature"), ath_cls.get("ctor_signature")
        ):
            intentional = _matches_allowlist_pattern(
                cls_path, sig_drift.get("__ctor__", [])
            )
            findings.append(
                Finding(
                    kind="ctor_signature_drift",
                    location=cls_path,
                    detail=_signature_diff_detail(
                        up_cls.get("ctor_signature"), ath_cls.get("ctor_signature")
                    ),
                    severity=_classify_severity(
                        "ctor_signature_drift", {"location": cls_path}
                    ),
                    intentional=intentional,
                )
            )

        up_members = up_cls.get("members", {})
        ath_members = ath_cls.get("members", {})
        cls_miss_allow = miss_members.get(cls_path, []) + miss_members.get(
            canonical_qualname, []
        )

        for mname, up_m in up_members.items():
            up_kind = up_m.get("kind", "")
            # Skip module_attr / nested_class — not parity-relevant
            if up_kind not in _CALLABLE_KINDS and up_kind != "property":
                continue
            if mname in _NOISE_MEMBERS:
                continue
            mloc = f"{cls_path}.{mname}"
            intentional = _matches_allowlist_pattern(
                mname, cls_miss_allow
            ) or _matches_allowlist_pattern(mname, universal_miss)
            ath_m = ath_members.get(mname)
            if ath_m is None:
                findings.append(
                    Finding(
                        kind="member_missing",
                        location=mloc,
                        detail={
                            "upstream_kind": up_kind,
                            "signature": up_m.get("signature"),
                            "upstream_doc": up_m.get("doc_first_line"),
                        },
                        severity=_classify_severity(
                            "member_missing", {"location": mloc}
                        ),
                        intentional=intentional,
                    )
                )
                continue

            ath_kind = ath_m.get("kind", "")
            if up_kind != ath_kind:
                # property vs method, classmethod vs staticmethod, etc.
                findings.append(
                    Finding(
                        kind="member_kind_drift",
                        location=mloc,
                        detail={
                            "upstream_kind": up_kind,
                            "athena_kind": ath_kind,
                        },
                        severity="important",
                        intentional=intentional,
                    )
                )
                continue

            # Both callables: compare signatures
            if up_kind in _CALLABLE_KINDS:
                up_sig = up_m.get("signature")
                ath_sig = ath_m.get("signature")
                if not _signatures_equal(up_sig, ath_sig):
                    sig_allow = sig_drift.get(cls_path, []) + sig_drift.get(
                        canonical_qualname, []
                    )
                    sig_intentional = (
                        intentional
                        or _matches_allowlist_pattern(mname, sig_allow)
                    )
                    findings.append(
                        Finding(
                            kind="signature_drift",
                            location=mloc,
                            detail=_signature_diff_detail(up_sig, ath_sig),
                            severity="important",
                            intentional=sig_intentional,
                        )
                    )
                    continue

                # Return annotation drift (informational)
                up_ret = _normalize_annotation((up_sig or {}).get("return_annotation"))
                ath_ret = _normalize_annotation((ath_sig or {}).get("return_annotation"))
                if up_ret != ath_ret and up_ret and ath_ret:
                    findings.append(
                        Finding(
                            kind="return_annotation_drift",
                            location=mloc,
                            detail={"upstream": up_ret, "athena": ath_ret},
                            severity="minor",
                            intentional=intentional,
                        )
                    )

            # Property kind/setter/deleter parity
            if up_kind == "property":
                up_setter = up_m.get("has_setter")
                ath_setter = ath_m.get("has_setter")
                if up_setter and not ath_setter:
                    findings.append(
                        Finding(
                            kind="member_kind_drift",
                            location=mloc + " (setter)",
                            detail={
                                "issue": "upstream property has setter, athena does not",
                                "upstream_setter": up_setter,
                                "athena_setter": ath_setter,
                            },
                            severity="important",
                            intentional=intentional,
                        )
                    )

    # Stable sort: actionable first, then by severity & location
    severity_order = {"critical": 0, "important": 1, "minor": 2}
    findings.sort(
        key=lambda f: (f.intentional, severity_order.get(f.severity, 99), f.location)
    )

    return GapReport(
        upstream_version=upstream.get("package_version"),
        upstream_modules=len(upstream["modules"]),
        athena_version=athena.get("package_version"),
        athena_modules=len(athena["modules"]),
        findings=findings,
        deviations_file=(deviations.get("__source__") if deviations else None),
    )


# ──────────────────────────────────────────────────────────────────────
# Markdown renderer
# ──────────────────────────────────────────────────────────────────────


def _render_signature(sig: dict[str, Any] | None) -> str:
    if not sig:
        return "<no signature>"
    parts: list[str] = []
    for p in sig.get("params", []):
        nm = p["name"]
        kind = p["kind"]
        default = p.get("default")
        ann = p.get("annotation")
        token = nm
        if ann:
            token += f": {ann}"
        if default and default != "<NO_DEFAULT>":
            token += f" = {default}"
        if kind == "VAR_POSITIONAL":
            token = f"*{nm}"
        elif kind == "VAR_KEYWORD":
            token = f"**{nm}"
        elif kind == "KEYWORD_ONLY" and not any(
            pp["kind"] == "VAR_POSITIONAL" for pp in sig.get("params", [])[: parts.__len__()]
        ):
            # Indicate kw-only boundary if first kw-only encountered
            if "*" not in "".join(parts):
                parts.append("*")
        parts.append(token)
    rendered = "(" + ", ".join(parts) + ")"
    ret = sig.get("return_annotation")
    if ret:
        rendered += f" -> {ret}"
    return rendered


def render_markdown(report: GapReport) -> str:
    lines: list[str] = []
    lines.append("# athena-python-docx — python-docx parity gap analysis")
    lines.append("")
    lines.append(
        f"Comparing **athena-python-docx {report.athena_version}** "
        f"({report.athena_modules} modules) against **python-docx "
        f"{report.upstream_version}** ({report.upstream_modules} modules)."
    )
    lines.append("")

    actionable = report.actionable
    intentional = report.intentional

    summary = {
        "module_missing": len(report.by_kind("module_missing")),
        "class_missing": len(report.by_kind("class_missing")),
        "member_missing": len(report.by_kind("member_missing")),
        "member_kind_drift": len(report.by_kind("member_kind_drift")),
        "signature_drift": len(report.by_kind("signature_drift")),
        "ctor_signature_drift": len(report.by_kind("ctor_signature_drift")),
        "return_annotation_drift": len(report.by_kind("return_annotation_drift")),
    }

    lines.append("## Summary")
    lines.append("")
    lines.append("| Gap kind | Total | Actionable | Intentional |")
    lines.append("|---|---:|---:|---:|")
    for k in [
        "module_missing",
        "class_missing",
        "member_missing",
        "member_kind_drift",
        "ctor_signature_drift",
        "signature_drift",
        "return_annotation_drift",
    ]:
        total = summary[k]
        act = sum(1 for f in actionable if f.kind == k)
        intnl = total - act
        lines.append(f"| `{k}` | {total} | {act} | {intnl} |")
    lines.append(
        f"| **TOTAL** | **{len(report.findings)}** | "
        f"**{len(actionable)}** | **{len(intentional)}** |"
    )
    lines.append("")

    by_severity = {"critical": [], "important": [], "minor": []}
    for f in actionable:
        by_severity.setdefault(f.severity, []).append(f)

    for sev in ("critical", "important", "minor"):
        bucket = by_severity.get(sev, [])
        if not bucket:
            continue
        lines.append(f"## Actionable — {sev} ({len(bucket)})")
        lines.append("")
        for f in bucket:
            lines.append(f"### `{f.location}` — {f.kind}")
            lines.append("")
            if f.kind == "module_missing":
                lines.append(
                    f"- Upstream module exposes "
                    f"{f.detail.get('upstream_member_count', '?')} members."
                )
            elif f.kind == "class_missing":
                bases = f.detail.get("bases") or []
                lines.append(f"- Upstream qualname: `{f.detail.get('qualname')}`")
                if bases:
                    lines.append(f"- Upstream bases: {', '.join(bases)}")
                lines.append(
                    f"- Upstream class exposes "
                    f"{f.detail.get('upstream_member_count', '?')} members."
                )
            elif f.kind == "member_missing":
                up_kind = f.detail.get("upstream_kind")
                lines.append(f"- Upstream kind: `{up_kind}`")
                if up_kind in _CALLABLE_KINDS:
                    sig = f.detail.get("signature")
                    lines.append(f"- Upstream signature: `{_render_signature(sig)}`")
                doc = f.detail.get("upstream_doc")
                if doc:
                    lines.append(f"- Upstream doc: _{doc}_")
            elif f.kind == "signature_drift":
                lines.append(
                    f"- Upstream: `{_render_signature(f.detail.get('upstream'))}`"
                )
                lines.append(
                    f"- Athena:   `{_render_signature(f.detail.get('athena'))}`"
                )
            elif f.kind == "ctor_signature_drift":
                lines.append(
                    f"- Upstream ctor: `{_render_signature(f.detail.get('upstream'))}`"
                )
                lines.append(
                    f"- Athena ctor:   `{_render_signature(f.detail.get('athena'))}`"
                )
            elif f.kind == "member_kind_drift":
                if "issue" in f.detail:
                    lines.append(f"- {f.detail['issue']}")
                else:
                    lines.append(
                        f"- Upstream kind: `{f.detail.get('upstream_kind')}`, "
                        f"athena kind: `{f.detail.get('athena_kind')}`"
                    )
            elif f.kind == "return_annotation_drift":
                lines.append(f"- Upstream return: `{f.detail.get('upstream')}`")
                lines.append(f"- Athena return:   `{f.detail.get('athena')}`")
            lines.append("")

    if intentional:
        lines.append("## Intentional deviations (filtered out)")
        lines.append("")
        lines.append(
            "These are documented as intentional in "
            "`tests/parity/intentional_deviations.json` and tracked here "
            "for visibility only."
        )
        lines.append("")
        for f in intentional:
            lines.append(f"- `{f.location}` ({f.kind})")
        lines.append("")

    lines.append("---")
    lines.append("")
    lines.append(
        "_Generated by `tests/parity/compare.py`. Re-run with "
        "`uv run pytest tests/parity/test_parity_gap.py -v` (or "
        "`tests/parity/run_parity.py refresh && tests/parity/run_parity.py compare`)._"
    )

    return "\n".join(lines) + "\n"


# ──────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--upstream", required=True, help="upstream snapshot JSON")
    ap.add_argument("--athena", required=True, help="athena snapshot JSON")
    ap.add_argument(
        "--deviations",
        default=None,
        help="path to intentional_deviations.json (optional)",
    )
    ap.add_argument("--out-md", default=None, help="markdown report output")
    ap.add_argument("--out-json", default=None, help="JSON report output")
    ap.add_argument(
        "--allow-actionable",
        type=int,
        default=None,
        help=(
            "exit 1 if more than this many actionable findings remain. "
            "Useful in CI to assert no NEW gaps."
        ),
    )
    args = ap.parse_args()

    upstream = _load(Path(args.upstream))
    athena = _load(Path(args.athena))
    deviations: dict[str, Any] | None = None
    if args.deviations:
        try:
            deviations = json.loads(Path(args.deviations).read_text())
            # Stash a python-sdk-relative path so the committed
            # report doesn't churn on every contributor's machine.
            # ``compare.py`` lives at ``tests/parity/compare.py`` under
            # the SDK package, so ``parents[2]`` is the package root and
            # gives us the friendly ``tests/parity/<file>`` form. Falls
            # back to the absolute string for paths outside the SDK
            # (e.g. an integrator running compare.py against a
            # non-standard deviations file).
            deviations_path = Path(args.deviations).resolve()
            try:
                sdk_root = Path(__file__).resolve().parents[2]
                deviations["__source__"] = str(
                    deviations_path.relative_to(sdk_root),
                )
            except ValueError:
                deviations["__source__"] = str(deviations_path)
        except FileNotFoundError:
            deviations = None

    report = compare(upstream, athena, deviations)

    if args.out_md:
        Path(args.out_md).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out_md).write_text(render_markdown(report))
    if args.out_json:
        Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out_json).write_text(
            json.dumps(report.to_dict(), indent=2, sort_keys=True) + "\n"
        )

    print(
        f"actionable={len(report.actionable)} "
        f"intentional={len(report.intentional)} "
        f"total={len(report.findings)}"
    )

    if args.allow_actionable is not None:
        if len(report.actionable) > args.allow_actionable:
            return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
