"""Contract tests for Athena extensions beyond python-docx 1.x.

These tests verify the *presence and shape* of the surfaces added in
v0.11.0+ for python-docx's most-requested features (hyperlink-add,
bookmarks, footnotes/endnotes, TOC, fields, captions, cross-references,
charts, math, content controls, watermarks, cell borders/shading,
floating images, multi-column layouts, find/replace, list numbering
reads, PDF export, image alt-text).

The surfaces here are documented under "Athena extensions for most-
requested upstream features" in ``python-sdk/CLAUDE.md``. The parity
ratchet at ``tests/parity/`` is one-directional (upstream → athena)
and doesn't surface these as findings — but if a contributor
accidentally renames or removes one of these methods, these tests
catch it.

Tests assert attribute existence and signature shape (parameter names,
kw-only-ness) but do NOT exercise the wire — those tests live under
``tests/test_silent_stub_*.py`` / ``tests/fidelity/``.
"""

from __future__ import annotations

import inspect

import pytest


def _params(callable_obj: object) -> list[inspect.Parameter]:
    return list(inspect.signature(callable_obj).parameters.values())


def _param_names(callable_obj: object) -> list[str]:
    return [p.name for p in _params(callable_obj)]


# ── Hyperlink ADD (python-docx issue #74) ──────────────────────────────


def test_paragraph_add_hyperlink_exists():
    from docx.text.paragraph import Paragraph

    assert hasattr(Paragraph, "add_hyperlink")
    sig = inspect.signature(Paragraph.add_hyperlink)
    names = list(sig.parameters)
    assert "text" in names
    assert "address" in names
    assert "fragment" in names
    assert "tooltip" in names


def test_run_add_hyperlink_exists():
    from docx.text.run import Run

    assert hasattr(Run, "add_hyperlink")


# ── Bookmarks (python-docx issue #425) ─────────────────────────────────


def test_bookmarks_module():
    from docx.bookmarks import Bookmark, Bookmarks

    assert hasattr(Bookmark, "name")
    assert hasattr(Bookmark, "bookmark_id")
    assert hasattr(Bookmark, "delete")
    assert hasattr(Bookmarks, "add")
    assert hasattr(Bookmarks, "get")
    assert hasattr(Bookmarks, "__iter__")


def test_document_bookmarks_property():
    from docx.document import Document

    assert isinstance(inspect.getattr_static(Document, "bookmarks"), property)


def test_paragraph_add_bookmark_exists():
    from docx.text.paragraph import Paragraph

    assert hasattr(Paragraph, "add_bookmark")


# ── Fields (python-docx issues #498, #31) ──────────────────────────────


def test_fields_module():
    from docx.fields import Field, Fields

    assert hasattr(Field, "field_id")
    assert hasattr(Field, "kind")
    assert hasattr(Field, "refresh")
    assert hasattr(Fields, "refresh_all")


def test_run_add_field_signature():
    from docx.text.run import Run

    assert hasattr(Run, "add_field")
    names = _param_names(Run.add_field)
    assert "kind" in names
    assert "args" in names


# ── Footnotes / Endnotes (python-docx issue #1) ────────────────────────


def test_footnotes_module():
    from docx.footnotes import Endnote, Endnotes, Footnote, Footnotes

    for cls in (Footnote, Endnote):
        assert hasattr(cls, "text")
        assert hasattr(cls, "delete")
    for cls in (Footnotes, Endnotes):
        assert hasattr(cls, "__iter__")
        assert hasattr(cls, "get")


def test_run_add_footnote_endnote_exists():
    from docx.text.run import Run

    assert hasattr(Run, "add_footnote")
    assert hasattr(Run, "add_endnote")


def test_document_footnotes_endnotes_properties():
    from docx.document import Document

    assert isinstance(inspect.getattr_static(Document, "footnotes"), property)
    assert isinstance(inspect.getattr_static(Document, "endnotes"), property)


# ── TOC (python-docx issues #36, #1403) ────────────────────────────────


def test_toc_module():
    from docx.toc import TableOfContents

    assert hasattr(TableOfContents, "refresh")
    assert hasattr(TableOfContents, "levels")


def test_document_add_toc_signature():
    from docx.document import Document

    assert hasattr(Document, "add_toc")
    sig = inspect.signature(Document.add_toc)
    names = list(sig.parameters)
    for expected in ("levels", "style_id", "include_hyperlinks", "title", "tab_leader"):
        assert expected in names


# ── Captions (python-docx issue #676) ──────────────────────────────────


def test_paragraph_add_caption_exists():
    from docx.text.paragraph import Paragraph

    assert hasattr(Paragraph, "add_caption")
    names = _param_names(Paragraph.add_caption)
    assert "text" in names
    assert "label" in names
    assert "bookmark" in names


# ── Cross-references (python-docx issue #97) ───────────────────────────


def test_run_add_cross_reference_exists():
    from docx.text.run import Run

    assert hasattr(Run, "add_cross_reference")
    names = _param_names(Run.add_cross_reference)
    assert "target" in names
    assert "reference_kind" in names
    assert "hyperlink" in names


# ── Cell borders + shading (python-docx issues #201, #146, #1238) ──────


def test_cell_borders_and_shading():
    from docx.table import _Cell

    assert hasattr(_Cell, "set_borders")
    assert hasattr(_Cell, "set_shading")
    assert isinstance(inspect.getattr_static(_Cell, "borders"), property)
    assert isinstance(inspect.getattr_static(_Cell, "shading"), property)


def test_table_set_borders_exists():
    from docx.table import Table

    assert hasattr(Table, "set_borders")


# ── Merged-cell detection (python-docx issues #1312, #1434, #1458) ─────


def test_cell_merge_introspection():
    from docx.table import _Cell

    for prop in ("v_merge", "is_merge_continuation", "is_merge_origin"):
        assert isinstance(inspect.getattr_static(_Cell, prop), property), prop


# ── add_row(copy_format_from=) (python-docx issue #205) ────────────────


def test_table_add_row_copy_format_from_kwarg():
    from docx.table import Table

    sig = inspect.signature(Table.add_row)
    assert "copy_format_from" in sig.parameters
    p = sig.parameters["copy_format_from"]
    assert p.kind == inspect.Parameter.KEYWORD_ONLY
    assert p.default is None


# ── Image alt-text + decorative + anchor (PR #1530, issue #159) ────────


def test_inline_shape_alt_text_title_decorative():
    from docx.shape import InlineShape, Picture

    for prop in ("alt_text", "title", "decorative"):
        assert isinstance(inspect.getattr_static(InlineShape, prop), property), prop
        assert isinstance(inspect.getattr_static(Picture, prop), property), prop


def test_inline_shape_anchor_exists():
    from docx.shape import InlineShape

    assert hasattr(InlineShape, "anchor")
    names = _param_names(InlineShape.anchor)
    for expected in (
        "wrap",
        "position_x_pt",
        "position_y_pt",
        "relative_from_x",
        "relative_from_y",
        "behind_text",
    ):
        assert expected in names, expected


# ── Watermarks (python-docx issue #845) ────────────────────────────────


def test_document_add_watermark_exists():
    from docx.document import Document

    assert hasattr(Document, "add_watermark")
    names = _param_names(Document.add_watermark)
    for expected in (
        "text",
        "image_path",
        "font_family",
        "font_size_pt",
        "color",
        "opacity",
        "angle",
        "scale",
    ):
        assert expected in names, expected


# ── Charts (python-docx issues #179, #1141) ────────────────────────────


def test_charts_module():
    from docx.charts import Chart, Charts

    assert hasattr(Chart, "data")
    assert hasattr(Chart, "chart_type")
    assert hasattr(Charts, "__iter__")
    assert hasattr(Charts, "get")


def test_document_add_chart_signature():
    from docx.document import Document

    assert hasattr(Document, "add_chart")
    assert hasattr(Document, "charts")


# ── Math (python-docx issue #320) ──────────────────────────────────────


def test_math_module():
    from docx.math import MathEquation

    assert hasattr(MathEquation, "content")
    assert hasattr(MathEquation, "format")
    assert hasattr(MathEquation, "display")


def test_run_add_math_signature():
    from docx.text.run import Run

    assert hasattr(Run, "add_math")
    names = _param_names(Run.add_math)
    for expected in ("content", "format", "display"):
        assert expected in names, expected


# ── SDT / Content Controls (python-docx issues #155, #224, #1417) ──────


def test_sdt_module():
    from docx.sdt import ContentControl, ContentControls

    for prop in ("sdt_id", "control_kind", "tag", "alias", "value", "locked"):
        assert hasattr(ContentControl, prop), prop
    assert hasattr(ContentControls, "__iter__")
    assert hasattr(ContentControls, "filter")


def test_document_add_content_control_exists():
    from docx.document import Document

    assert hasattr(Document, "add_content_control")
    assert hasattr(Document, "content_controls")


# ── Multi-column section layout (python-docx issue #167) ───────────────


def test_section_set_columns_exists():
    from docx.section import Section

    assert hasattr(Section, "set_columns")
    assert isinstance(inspect.getattr_static(Section, "column_count"), property)
    assert isinstance(inspect.getattr_static(Section, "column_widths"), property)


# ── Find & Replace (python-docx issues #30, #980) ──────────────────────


def test_document_find_replace_signature():
    from docx.document import Document

    assert hasattr(Document, "find_replace")
    names = _param_names(Document.find_replace)
    for expected in (
        "pattern",
        "replacement",
        "regex",
        "match_case",
        "whole_word",
        "in_",
        "max_replacements",
    ):
        assert expected in names, expected


# ── List-numbering reads (python-docx issue #471) ──────────────────────


def test_paragraph_list_metadata_properties():
    from docx.text.paragraph import Paragraph

    for prop in ("list_id", "list_level", "list_format", "list_number"):
        assert isinstance(inspect.getattr_static(Paragraph, prop), property), prop


# ── PDF Export (python-docx issue #113) ────────────────────────────────


def test_document_to_pdf_exists():
    from docx.document import Document

    assert hasattr(Document, "to_pdf")
    names = _param_names(Document.to_pdf)
    for expected in ("quality", "destination", "include_revisions"):
        assert expected in names, expected


# ── Command bus registration ───────────────────────────────────────────


@pytest.mark.parametrize(
    "command_name",
    [
        "CreateHyperlink",
        "RemoveHyperlink",
        "CreateField",
        "FieldsRefresh",
        "FieldsList",
        "CreateBookmark",
        "DeleteBookmark",
        "BookmarksList",
        "BookmarksGet",
        "CreateFootnote",
        "CreateEndnote",
        "FootnotesList",
        "EndnotesList",
        "FootnotesGet",
        "EndnotesGet",
        "FootnotesPatch",
        "EndnotesPatch",
        "FootnotesDelete",
        "EndnotesDelete",
        "CreateTOC",
        "RefreshTOC",
        "CreateCaption",
        "CreateCrossReference",
        "SetCellBorders",
        "SetCellShading",
        "SetTableBorders",
        "SetImageAnchor",
        "CreateWatermark",
        "DeleteWatermark",
        "CreateChart",
        "SetChartData",
        "SetChartType",
        "ChartsList",
        "ChartsGet",
        "CreateMath",
        "MathPatch",
        "CreateContentControl",
        "ContentControlsList",
        "ContentControlsGet",
        "ContentControlsPatch",
        "ContentControlsDelete",
        "SetSectionColumns",
        "FindReplace",
        "IterRuns",
        "ExportPDF",
        "NumberingGet",
        "NumberingList",
    ],
)
def test_athena_extension_command_registered(command_name: str) -> None:
    """Each Athena-extension command must be exported from docx.commands
    so the wire layer can serialize it."""
    import docx.commands as cmds

    cls = getattr(cmds, command_name, None)
    assert cls is not None, (
        f"{command_name} missing from docx.commands — every Athena-"
        f"extension command must be exported so the wire layer can "
        f"serialize it."
    )
    assert command_name in cmds.__all__, (
        f"{command_name} present but not re-exported from "
        f"docx.commands.__all__"
    )
