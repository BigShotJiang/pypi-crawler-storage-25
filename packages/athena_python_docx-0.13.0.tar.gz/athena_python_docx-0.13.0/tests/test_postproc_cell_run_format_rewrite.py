"""Unit tests for cell-inner run-level format ops and hyperlink ops in
``docx._postproc.PostExportOps``.

Pins the OOXML rewrite contract for ``run.bold`` / ``run.italic`` /
``run.font.size`` / ``run.font.color.rgb`` / ``run.font.name`` /
``run.font.highlight_color`` / ``run.style`` / ``run.font.strike``
/ ``run.underline`` on cell-inner runs, plus
``paragraph.add_hyperlink`` on cell-inner paragraphs.

Each test constructs a minimal ``.docx`` zip with a single one-row,
one-cell table whose cell paragraph already has ``<w:r><w:t>``
content (matches the post-``cell.text = ...`` shape), applies the
rewrite, and asserts the expected ``<w:rPr>`` / ``<w:hyperlink>``
shape in the rewritten ``word/document.xml`` (plus the rels file
for external hyperlinks).
"""
from __future__ import annotations

import io
import zipfile
from xml.etree import ElementTree as ET

from docx._postproc import CellAddress, PostExportOps


W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
W_NS = f"{{{W}}}"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
R_NS = f"{{{R}}}"
PKG_RELS = "http://schemas.openxmlformats.org/package/2006/relationships"
PKG_RELS_NS = f"{{{PKG_RELS}}}"

_CONTENT_TYPES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>
"""

_ROOT_RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>
"""

_DEFAULT_DOC_RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>
"""


def _make_minimal_docx(
    *,
    document_xml: str,
    document_rels_xml: str = _DEFAULT_DOC_RELS_XML,
) -> bytes:
    """Pack a 4-part .docx zip around ``document_xml`` (the rels file
    is included so ``cell.add_hyperlink`` rewrites have a real rels
    target to mint into)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", _CONTENT_TYPES_XML)
        z.writestr("_rels/.rels", _ROOT_RELS_XML)
        z.writestr("word/document.xml", document_xml)
        z.writestr("word/_rels/document.xml.rels", document_rels_xml)
    return buf.getvalue()


def _extract_document_xml(docx_bytes: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as z:
        return z.read("word/document.xml").decode("utf-8")


def _extract_rels_xml(docx_bytes: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as z:
        return z.read("word/_rels/document.xml.rels").decode("utf-8")


def _single_table_doc(*, cell_text: str = "Hello") -> str:
    """Render a minimal ``word/document.xml`` with one 1x1 table whose
    cell holds a single paragraph with ``cell_text`` (one ``<w:r>``).
    """
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}" xmlns:r="{R}">
  <w:body>
    <w:tbl>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r><w:t>{cell_text}</w:t></w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>
  </w:body>
</w:document>
"""


def _parse(doc_xml: str) -> ET.Element:
    return ET.fromstring(doc_xml)


def _first_cell_runs(root: ET.Element) -> list[ET.Element]:
    tbl = root.find(f".//{W_NS}body/{W_NS}tbl")
    assert tbl is not None
    tc = tbl.find(f"{W_NS}tr/{W_NS}tc")
    assert tc is not None
    p = tc.find(f"{W_NS}p")
    assert p is not None
    return p.findall(f"{W_NS}r")


def _first_cell_paragraph(root: ET.Element) -> ET.Element:
    tbl = root.find(f".//{W_NS}body/{W_NS}tbl")
    assert tbl is not None
    tc = tbl.find(f"{W_NS}tr/{W_NS}tc")
    assert tc is not None
    p = tc.find(f"{W_NS}p")
    assert p is not None
    return p


def _addr_0_0_0_0() -> CellAddress:
    return CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)


# ---- cell-inner run format ops ---------------------------------------


def test_bold_injects_b_flag_on_all_runs_in_cell():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), bold=True)
    docx_out = ops.apply_to_docx(docx_in)
    runs = _first_cell_runs(_parse(_extract_document_xml(docx_out)))
    assert len(runs) == 1
    rPr = runs[0].find(f"{W_NS}rPr")
    assert rPr is not None
    b = rPr.find(f"{W_NS}b")
    assert b is not None
    # Presence-means-true: no w:val attribute on the enabled flag.
    assert b.get(f"{W_NS}val") is None


def test_bold_false_emits_val_zero_to_override_inherited():
    """``run.bold = False`` is the explicit override path — the agent
    wants to disable an inherited style-level bold. The OOXML
    representation is ``<w:b w:val="0"/>`` (removing the element would
    fall back to inheritance, which isn't what the agent asked for)."""
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), bold=False)
    docx_out = ops.apply_to_docx(docx_in)
    runs = _first_cell_runs(_parse(_extract_document_xml(docx_out)))
    rPr = runs[0].find(f"{W_NS}rPr")
    assert rPr is not None
    b = rPr.find(f"{W_NS}b")
    assert b is not None
    assert b.get(f"{W_NS}val") == "0"


def test_italic_strike_underline_flags():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(
        _addr_0_0_0_0(),
        italic=True,
        strike=True,
        underline="single",
    )
    docx_out = ops.apply_to_docx(docx_in)
    runs = _first_cell_runs(_parse(_extract_document_xml(docx_out)))
    rPr = runs[0].find(f"{W_NS}rPr")
    assert rPr is not None
    assert rPr.find(f"{W_NS}i") is not None
    assert rPr.find(f"{W_NS}strike") is not None
    u = rPr.find(f"{W_NS}u")
    assert u is not None
    assert u.get(f"{W_NS}val") == "single"


def test_underline_bool_normalizes_to_single_and_none():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), underline=True)
    docx_out = ops.apply_to_docx(docx_in)
    u = (
        _first_cell_runs(_parse(_extract_document_xml(docx_out)))[0]
        .find(f"{W_NS}rPr")
        .find(f"{W_NS}u")
    )
    assert u is not None
    assert u.get(f"{W_NS}val") == "single"

    ops2 = PostExportOps()
    ops2.add_cell_run_format(_addr_0_0_0_0(), underline=False)
    out2 = ops2.apply_to_docx(docx_in)
    u2 = (
        _first_cell_runs(_parse(_extract_document_xml(out2)))[0]
        .find(f"{W_NS}rPr")
        .find(f"{W_NS}u")
    )
    assert u2 is not None
    assert u2.get(f"{W_NS}val") == "none"


def test_font_size_pt_emits_half_points_in_w_sz():
    """Word stores font size in half-points; the SDK accepts points."""
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), font_size_pt=11.0)
    docx_out = ops.apply_to_docx(docx_in)
    rPr = _first_cell_runs(_parse(_extract_document_xml(docx_out)))[0].find(
        f"{W_NS}rPr",
    )
    assert rPr is not None
    sz = rPr.find(f"{W_NS}sz")
    sz_cs = rPr.find(f"{W_NS}szCs")
    assert sz is not None and sz.get(f"{W_NS}val") == "22"
    assert sz_cs is not None and sz_cs.get(f"{W_NS}val") == "22"


def test_font_color_strips_leading_hash_and_emits_w_color():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), font_color_hex="#0A1F44")
    docx_out = ops.apply_to_docx(docx_in)
    rPr = _first_cell_runs(_parse(_extract_document_xml(docx_out)))[0].find(
        f"{W_NS}rPr",
    )
    assert rPr is not None
    col = rPr.find(f"{W_NS}color")
    assert col is not None
    assert col.get(f"{W_NS}val") == "0A1F44"


def test_font_name_emits_rFonts_with_ascii_hAnsi_cs_eastAsia():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), font_name="Calibri")
    docx_out = ops.apply_to_docx(docx_in)
    rPr = _first_cell_runs(_parse(_extract_document_xml(docx_out)))[0].find(
        f"{W_NS}rPr",
    )
    assert rPr is not None
    rfonts = rPr.find(f"{W_NS}rFonts")
    assert rfonts is not None
    assert rfonts.get(f"{W_NS}ascii") == "Calibri"
    assert rfonts.get(f"{W_NS}hAnsi") == "Calibri"
    assert rfonts.get(f"{W_NS}cs") == "Calibri"
    assert rfonts.get(f"{W_NS}eastAsia") == "Calibri"


def test_font_highlight_emits_w_highlight():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), font_highlight="yellow")
    docx_out = ops.apply_to_docx(docx_in)
    rPr = _first_cell_runs(_parse(_extract_document_xml(docx_out)))[0].find(
        f"{W_NS}rPr",
    )
    assert rPr is not None
    hl = rPr.find(f"{W_NS}highlight")
    assert hl is not None
    assert hl.get(f"{W_NS}val") == "yellow"


def test_r_style_emits_w_rStyle():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), r_style="Emphasis")
    docx_out = ops.apply_to_docx(docx_in)
    rPr = _first_cell_runs(_parse(_extract_document_xml(docx_out)))[0].find(
        f"{W_NS}rPr",
    )
    assert rPr is not None
    rs = rPr.find(f"{W_NS}rStyle")
    assert rs is not None
    assert rs.get(f"{W_NS}val") == "Emphasis"


def test_multiple_format_props_merge_into_one_rPr():
    """Bold + size + color + name in one stash → one ``<w:rPr>`` with
    all children present. Mirrors the agent's typical pattern:
    ``r.bold = True; r.font.size = Pt(11); r.font.color.rgb = …;
    r.font.name = 'Calibri'``."""
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(
        _addr_0_0_0_0(),
        bold=True,
        font_size_pt=11.0,
        font_color_hex="1F4E9C",
        font_name="Calibri",
    )
    docx_out = ops.apply_to_docx(docx_in)
    rPr = _first_cell_runs(_parse(_extract_document_xml(docx_out)))[0].find(
        f"{W_NS}rPr",
    )
    assert rPr is not None
    assert rPr.find(f"{W_NS}b") is not None
    assert rPr.find(f"{W_NS}sz") is not None
    assert rPr.find(f"{W_NS}color") is not None
    assert rPr.find(f"{W_NS}rFonts") is not None


def test_repeat_set_last_write_wins():
    """Setting bold=True then bold=False on the same cell paragraph
    should leave the LAST write in effect (``<w:b w:val="0"/>``)."""
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), bold=True)
    ops.add_cell_run_format(_addr_0_0_0_0(), bold=False)
    docx_out = ops.apply_to_docx(docx_in)
    rPr = _first_cell_runs(_parse(_extract_document_xml(docx_out)))[0].find(
        f"{W_NS}rPr",
    )
    assert rPr is not None
    b = rPr.find(f"{W_NS}b")
    assert b is not None
    assert b.get(f"{W_NS}val") == "0"


def test_empty_target_paragraph_walks_forward_to_next_visible_paragraph():
    """``cell.text = "Value"`` materializes alongside the cell's
    template-default empty ``<w:p>`` → cell has 2 paragraphs.
    ``cell.paragraphs[0]`` (empty) format ops should resolve forward
    to the first non-empty paragraph — matches agent intent."""
    document_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}">
  <w:body>
    <w:tbl>
      <w:tr>
        <w:tc>
          <w:p/>
          <w:p>
            <w:r><w:t>Real content</w:t></w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>
  </w:body>
</w:document>
"""
    docx_in = _make_minimal_docx(document_xml=document_xml)
    ops = PostExportOps()
    ops.add_cell_run_format(_addr_0_0_0_0(), bold=True)
    docx_out = ops.apply_to_docx(docx_in)
    root = _parse(_extract_document_xml(docx_out))
    tc = root.find(f".//{W_NS}body/{W_NS}tbl/{W_NS}tr/{W_NS}tc")
    assert tc is not None
    paragraphs = tc.findall(f"{W_NS}p")
    assert len(paragraphs) == 2
    # First (empty) paragraph still has no runs.
    assert paragraphs[0].findall(f"{W_NS}r") == []
    # Bold landed on the second (visible) paragraph.
    rPr2 = paragraphs[1].find(f"{W_NS}r").find(f"{W_NS}rPr")
    assert rPr2 is not None
    assert rPr2.find(f"{W_NS}b") is not None


def test_no_pending_does_not_touch_runs():
    """Sanity: with no cell-run ops staged, ``<w:r>`` elements pass
    through unmodified — same `<w:rPr>` (or lack thereof) as input."""
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    docx_out = ops.apply_to_docx(docx_in)
    runs = _first_cell_runs(_parse(_extract_document_xml(docx_out)))
    assert len(runs) == 1
    assert runs[0].find(f"{W_NS}rPr") is None


# ---- cell-inner hyperlink ops ----------------------------------------


def test_cell_hyperlink_appends_hyperlink_element_with_visible_text():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_hyperlink(
        _addr_0_0_0_0(),
        text="Insight Partners",
        url="https://www.insightpartners.com",
    )
    docx_out = ops.apply_to_docx(docx_in)
    p = _first_cell_paragraph(_parse(_extract_document_xml(docx_out)))
    hyperlink = p.find(f"{W_NS}hyperlink")
    assert hyperlink is not None
    # Visible text must round-trip.
    inner_t = hyperlink.find(f"{W_NS}r/{W_NS}t")
    assert inner_t is not None
    assert inner_t.text == "Insight Partners"
    # Should reference the Hyperlink character style for blue+underline.
    rs = hyperlink.find(f"{W_NS}r/{W_NS}rPr/{W_NS}rStyle")
    assert rs is not None
    assert rs.get(f"{W_NS}val") == "Hyperlink"


def test_cell_hyperlink_mints_external_rels_relationship():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_hyperlink(
        _addr_0_0_0_0(),
        text="ref",
        url="https://example.com/source",
        tooltip="Source",
    )
    docx_out = ops.apply_to_docx(docx_in)
    rels_out = _extract_rels_xml(docx_out)
    rels_root = ET.fromstring(rels_out)
    hyperlinks = [
        rel
        for rel in rels_root.findall(f"{PKG_RELS_NS}Relationship")
        if rel.get("Type", "").endswith("/hyperlink")
    ]
    assert len(hyperlinks) == 1
    rel = hyperlinks[0]
    assert rel.get("Target") == "https://example.com/source"
    assert rel.get("TargetMode") == "External"
    # The <w:hyperlink> must reference the minted Id.
    p_xml = _extract_document_xml(docx_out)
    p_root = ET.fromstring(p_xml)
    hl_el = p_root.find(f".//{W_NS}hyperlink")
    assert hl_el is not None
    assert hl_el.get(f"{R_NS}id") == rel.get("Id")
    # Tooltip threads through.
    assert hl_el.get(f"{W_NS}tooltip") == "Source"


def test_cell_hyperlink_dedupes_repeated_urls_to_one_rels_entry():
    """The agent's typical IB-memo pattern peppers the same source URL
    across many cells (Pitchbook, S&P, Cambridge Associates). One
    ``Relationship`` entry is enough — the rels file should not grow
    unboundedly."""
    docx_in = _make_minimal_docx(
        document_xml=f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}" xmlns:r="{R}">
  <w:body>
    <w:tbl>
      <w:tr>
        <w:tc><w:p><w:r><w:t>row0</w:t></w:r></w:p></w:tc>
        <w:tc><w:p><w:r><w:t>row1</w:t></w:r></w:p></w:tc>
      </w:tr>
    </w:tbl>
  </w:body>
</w:document>
""",
    )
    ops = PostExportOps()
    ops.add_cell_hyperlink(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        text="Pitchbook",
        url="https://pitchbook.com",
    )
    ops.add_cell_hyperlink(
        CellAddress(table_doc_index=0, row=0, col=1, paragraph_index=0),
        text="Pitchbook",
        url="https://pitchbook.com",
    )
    docx_out = ops.apply_to_docx(docx_in)
    rels_root = ET.fromstring(_extract_rels_xml(docx_out))
    hyperlinks = [
        rel
        for rel in rels_root.findall(f"{PKG_RELS_NS}Relationship")
        if rel.get("Type", "").endswith("/hyperlink")
    ]
    assert len(hyperlinks) == 1
    # Both <w:hyperlink> reference the same rId.
    doc_root = ET.fromstring(_extract_document_xml(docx_out))
    rids = [
        hl.get(f"{R_NS}id") for hl in doc_root.findall(f".//{W_NS}hyperlink")
    ]
    assert rids[0] == rids[1] == hyperlinks[0].get("Id")


def test_cell_hyperlink_internal_anchor_uses_w_anchor_no_rels_entry():
    """Internal bookmark jumps (``fragment="MyBookmark"`` with no
    external URL) use ``w:anchor`` and don't add a rels entry."""
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_hyperlink(
        _addr_0_0_0_0(),
        text="See Glossary",
        url="",
        fragment="Glossary",
    )
    docx_out = ops.apply_to_docx(docx_in)
    doc_root = ET.fromstring(_extract_document_xml(docx_out))
    hl = doc_root.find(f".//{W_NS}hyperlink")
    assert hl is not None
    assert hl.get(f"{W_NS}anchor") == "Glossary"
    assert hl.get(f"{R_NS}id") is None
    rels_root = ET.fromstring(_extract_rels_xml(docx_out))
    hyperlinks = [
        rel
        for rel in rels_root.findall(f"{PKG_RELS_NS}Relationship")
        if rel.get("Type", "").endswith("/hyperlink")
    ]
    assert hyperlinks == []


def test_cell_hyperlink_empty_text_is_skipped():
    """An empty ``text`` would produce a hyperlink with no clickable
    region — skip silently rather than emitting unrenderable OOXML."""
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_hyperlink(_addr_0_0_0_0(), text="", url="https://example.com")
    docx_out = ops.apply_to_docx(docx_in)
    p = _first_cell_paragraph(_parse(_extract_document_xml(docx_out)))
    assert p.find(f"{W_NS}hyperlink") is None


def test_has_pending_includes_run_format_and_hyperlink_ops():
    """``PostExportOps.has_pending`` is the gate for whether the
    Document.export_docx path runs apply_to_docx; it must return True
    when either of the new collectors has entries."""
    ops_run = PostExportOps()
    assert ops_run.has_pending() is False
    ops_run.add_cell_run_format(_addr_0_0_0_0(), bold=True)
    assert ops_run.has_pending() is True

    ops_hl = PostExportOps()
    ops_hl.add_cell_hyperlink(
        _addr_0_0_0_0(),
        text="x",
        url="https://example.com",
    )
    assert ops_hl.has_pending() is True
