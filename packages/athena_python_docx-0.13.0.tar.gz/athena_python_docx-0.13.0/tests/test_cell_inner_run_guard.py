"""Pins the cell-inner Run guards added in 0.11.7.

Pre-fix, the SDK's cell-inner protection only fired for Paragraph
setters (``alignment``, ``style``, ``paragraph_format.*``). Run-level
ops created from a cell-inner Paragraph (``Paragraph.add_run`` and the
subsequent ``Run.add_text`` / ``Run.font.size = X`` / etc.) shipped to
SuperDoc with a target.blockId that resolved to a cell-inner paragraph
— and SuperDoc rejected those ops with ``Block <id> not found``,
cascade-failing the whole batch with ``applied: []``.

The fix:
  - Run constructor gains ``in_cell: bool = False``.
  - Paragraph.add_run / Paragraph.runs / Paragraph.iter_inner_content
    propagate the paragraph's ``_in_cell`` to the new Run.
  - Paragraph.add_run short-circuits the ``doc.insert`` when
    ``_in_cell=True`` and returns a stub Run with ``in_cell=True``.
  - Run.text setter / add_text / add_tab / add_break / add_field /
    _apply_inline (which catches bold/italic/font.size/font.color/etc.)
    warn-and-skip when ``_in_cell=True``.

Together these eliminate the cascade for the agent pattern:

    cell.text = ""
    lp = cell.paragraphs[0]
    lr = lp.add_run("Hello")     # would have done a wire Insert -> cascade
    lr.font.size = Pt(11)        # would have done a wire FormatApply -> cascade
"""
from __future__ import annotations

import warnings
from typing import Any


from docx.text.paragraph import CellInnerFormatNotSupportedWarning


def _make_cell_inner_paragraph(mock_session: Any) -> Any:
    from docx.text.paragraph import Paragraph

    return Paragraph(
        session=mock_session,
        node_id="p-cell-inner",
        in_cell=True,
    )


def _make_body_paragraph(mock_session: Any) -> Any:
    from docx.text.paragraph import Paragraph

    return Paragraph(
        session=mock_session,
        node_id="p-body",
        in_cell=False,
    )


# ---- Paragraph.add_run propagates _in_cell ----


def test_paragraph_add_run_propagates_in_cell_to_new_run(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    p = _make_cell_inner_paragraph(mock_session)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r = p.add_run("hello")
    assert getattr(r, "_in_cell", False) is True


def test_paragraph_add_run_no_in_cell_for_body_paragraph(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    p = _make_body_paragraph(mock_session)
    r = p.add_run("hello")
    assert getattr(r, "_in_cell", False) is False


def test_paragraph_add_run_warns_on_cell_inner(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    p = _make_cell_inner_paragraph(mock_session)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        p.add_run("hello")
        warned = [
            x
            for x in w
            if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    assert len(warned) == 1
    msg = str(warned[0].message)
    assert "cell.text" in msg or "cell.add_paragraph" in msg


# ---- Run text-mutating ops short-circuit when in_cell ----


def _make_in_cell_run(mock_session: Any) -> Any:
    from docx.text.run import Run

    return Run(
        session=mock_session,
        block_id="p-cell-inner",
        range_=(0, 0),
        in_cell=True,
    )


def test_run_text_setter_short_circuits_when_in_cell(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    r = _make_in_cell_run(mock_session)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        r.text = "new content"
        warned = [
            x for x in w if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    assert len(warned) == 1
    # No-op: doc.replace was NOT called.
    replace_ops = [c for c in fake_sd_methods.calls if c[0] == "replace"]
    assert replace_ops == []


def test_run_add_text_short_circuits_when_in_cell(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    r = _make_in_cell_run(mock_session)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r_new = r.add_text(" world")
    # Returned a Run (not None), still marked in_cell so chained ops
    # also short-circuit.
    assert r_new is not None
    assert getattr(r_new, "_in_cell", False) is True
    insert_ops = [c for c in fake_sd_methods.calls if c[0] == "insert"]
    assert insert_ops == []


def test_run_add_tab_short_circuits_when_in_cell(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    r = _make_in_cell_run(mock_session)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r.add_tab()


def test_run_add_break_short_circuits_when_in_cell(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    from docx.enum.text import WD_BREAK

    r = _make_in_cell_run(mock_session)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r.add_break(WD_BREAK.LINE)


def test_run_apply_inline_short_circuits_when_in_cell(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    """bold/italic/font.size/font.color/etc. setters all go through
    ``Run._apply_inline``. Guarding that one method covers every
    inline-format setter at once."""
    r = _make_in_cell_run(mock_session)
    # Give the run a non-collapsed range so it doesn't hit the
    # pending-inline stash branch — it should still short-circuit on
    # the in_cell check BEFORE checking the collapsed branch.
    r._range = (0, 5)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        r.bold = True
        r.italic = True
        warned = [
            x for x in w if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    assert len(warned) == 2
    # No wire call happened.
    format_apply_ops = [c for c in fake_sd_methods.calls if c[0] == "format.apply"]
    assert format_apply_ops == []


# ---- Defensive: tests that bypass __init__ still work ----


def test_run_default_in_cell_when_constructed_via_new(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    """``Run.__new__(Run)`` skips ``__init__`` — _in_cell is unset.
    ``_check_cell_inner`` must default to False so existing tests
    (which use this pattern) continue to flow through the wire.
    """
    from docx.text.run import Run

    r = Run.__new__(Run)
    # No _in_cell attr at all
    assert "_in_cell" not in r.__dict__
    # Should NOT raise — defaults to False (treats as body paragraph).
    assert r._check_cell_inner("any_op") is False


# ---- End-to-end: in_cell propagates through chained ops ----


def test_run_chained_ops_all_short_circuit_when_starting_in_cell(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    """The most common agent pattern:

        lr = lp.add_run("Hello")
        lr.font.size = Pt(11)
        lr.bold = True
        lr.add_text(" world")
    """
    from docx.shared import Pt

    p = _make_cell_inner_paragraph(mock_session)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        lr = p.add_run("Hello")
        lr.font.size = Pt(11)
        lr.bold = True
        lr2 = lr.add_text(" world")
        # And on lr2 — should also be in_cell
        lr2.font.color.rgb = None  # would normally call font.apply
        warned = [
            x for x in w if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    # add_run + font.size + bold + add_text — all warned
    assert len(warned) >= 4
    # No wire ops fired.
    format_apply_ops = [c for c in fake_sd_methods.calls if c[0] == "format.apply"]
    insert_ops = [c for c in fake_sd_methods.calls if c[0] == "insert"]
    assert format_apply_ops == []
    assert insert_ops == []
