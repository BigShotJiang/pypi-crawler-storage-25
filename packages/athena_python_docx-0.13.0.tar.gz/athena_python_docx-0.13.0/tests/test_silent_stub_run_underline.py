"""Lock-in tests for ``Run.underline`` setter type validation.

The previous setter had a permissive catch-all
``self._apply_inline(underline=value)`` that shipped any unknown
type (dict, int, list, custom class) straight to the wire — SuperDoc
either silently dropped it or round-tripped a garbage value. The
``str`` path was never exercised at all.

python-docx 1.x's ``Font.underline.setter`` accepts
``bool | WD_UNDERLINE | None`` and raises ``TypeError`` (via
``BaseEnumProperty``) on anything else. Strings that match a
WD_UNDERLINE member value are accepted as a python-docx-style
convenience (Pillow-style enum coercion).

Now:
- ``None`` → ships null (clears the mark).
- ``bool`` → ships verbatim (True / False).
- ``WD_UNDERLINE`` → ships ``.value``.
- ``str`` matching a member value → coerced through enum + ships.
- Bogus ``str`` → ``ValueError`` listing valid values.
- Anything else → ``TypeError``.
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_run(mock_session: Any, *, block_id: str = "p1") -> Any:
    from docx.text.run import Run

    return Run(
        session=mock_session,
        block_id=block_id,
        range_=(0, 5),
        inline={"text": "hello"},
    )


# ---------------------------------------------------------------------
# Happy paths
# ---------------------------------------------------------------------


def test_underline_bool_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.underline = True
    inline_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.apply"
    ]
    assert inline_calls
    assert inline_calls[-1][1]["inline"]["underline"] is True


def test_underline_none_ships_null_clear(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.underline = None
    inline_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.apply"
    ]
    assert inline_calls
    assert inline_calls[-1][1]["inline"]["underline"] is None


def test_underline_enum_member_ships_value(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.enum.text import WD_UNDERLINE

    run = _make_run(mock_session)
    run.underline = WD_UNDERLINE.DOUBLE
    inline_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.apply"
    ]
    assert inline_calls
    assert inline_calls[-1][1]["inline"]["underline"] == "double"


def test_underline_enum_string_ships_coerced(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """python-docx-style convenience: a string matching a
    WD_UNDERLINE member value coerces through the enum."""
    run = _make_run(mock_session)
    run.underline = "wavy"
    inline_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.apply"
    ]
    assert inline_calls
    assert inline_calls[-1][1]["inline"]["underline"] == "wavy"


# ---------------------------------------------------------------------
# Rejection paths
# ---------------------------------------------------------------------


def test_underline_rejects_bogus_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Bogus strings no longer ship to wire — was silent in the prior
    catch-all path."""
    run = _make_run(mock_session)
    with pytest.raises(ValueError, match="WD_UNDERLINE"):
        run.underline = "not-a-real-underline"


@pytest.mark.parametrize("value", [42, [1, 2], {"k": "v"}, object()])
def test_underline_rejects_non_str_non_enum_non_bool(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    """All non-string, non-bool, non-enum, non-None inputs raise
    TypeError — was the silent ship-to-wire path in the original
    catch-all."""
    run = _make_run(mock_session)
    with pytest.raises(TypeError, match="bool, WD_UNDERLINE"):
        run.underline = value
