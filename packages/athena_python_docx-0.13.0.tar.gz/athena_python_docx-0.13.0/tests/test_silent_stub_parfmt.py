"""Lock-in tests for ``ParagraphFormat`` and ``TabStops`` silent-stub
audit (parity loop iteration after Phase J).

Previously these setters silently no-op'd or accepted garbage:

- ``line_spacing = True`` hit the ``1 <= int <= 4`` branch and produced
  a 1× multiplier; ``line_spacing = False`` produced 0-EMU exact spacing.
- ``line_spacing_rule = None`` returned silently (callers had no way to
  clear the rule).
- ``line_spacing_rule = <unknown member>`` fell through the cascading
  elif and silently no-op'd.
- ``keep_together``/``keep_with_next``/``widow_control``/``page_break_before``
  setters with ``None`` returned silently; with non-bool truthy values
  they used ``bool(value)`` coercion (``"yes"`` → True silently).
- ``TabStop.alignment`` / ``leader`` setters and ``TabStops.add_tab_stop``
  accepted any string via ``str(value)``, shipping bogus values to the
  wire (SuperDoc silently fell back to defaults).

Each gap is pinned with a test so a future refactor that re-introduces
the silent path fails loudly.
"""

from __future__ import annotations

import warnings
from typing import Any

import pytest


# ---------------------------------------------------------------------
# ParagraphFormat — line_spacing
# ---------------------------------------------------------------------


def test_line_spacing_rejects_bool(mock_session: Any, fake_sd_methods: Any) -> None:
    """``bool`` is a subclass of ``int`` — without an explicit reject,
    ``line_spacing = True`` silently sets 1× multiplier (hits the
    ``1 <= int <= 4`` branch). Pin the rejection."""
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    with pytest.raises(TypeError, match="bool"):
        para.paragraph_format.line_spacing = True
    with pytest.raises(TypeError, match="bool"):
        para.paragraph_format.line_spacing = False


# ---------------------------------------------------------------------
# ParagraphFormat — line_spacing_rule
# ---------------------------------------------------------------------


def test_line_spacing_rule_none_clears(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``line_spacing_rule = None`` now issues a clear op (was silent
    no-op)."""
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    before = sum(
        1 for c in fake_sd_methods.calls if c[0] == "format.paragraph.clear_spacing"
    )
    para.paragraph_format.line_spacing_rule = None
    after = sum(
        1 for c in fake_sd_methods.calls if c[0] == "format.paragraph.clear_spacing"
    )
    assert after - before == 1, (
        "line_spacing_rule = None should call clear_spacing, not no-op"
    )


def test_line_spacing_rule_rejects_unknown_member(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A non-WD_LINE_SPACING input now raises (was silent no-op via
    cascading elif fallthrough)."""
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    with pytest.raises(ValueError, match="WD_LINE_SPACING"):
        para.paragraph_format.line_spacing_rule = "single"  # str, not enum
    with pytest.raises(ValueError, match="WD_LINE_SPACING"):
        para.paragraph_format.line_spacing_rule = 1


def test_line_spacing_rule_multiple_without_value_raises(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``MULTIPLE`` alone is meaningless — must come with a numeric
    ``line_spacing`` instead. python-docx 1.x also raises here."""
    from docx.enum.text import WD_LINE_SPACING
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    with pytest.raises(ValueError, match="MULTIPLE"):
        para.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE


# ---------------------------------------------------------------------
# ParagraphFormat — keep_together / keep_with_next / widow_control /
# page_break_before (trivalent on/off)
# ---------------------------------------------------------------------


@pytest.mark.parametrize(
    "prop",
    ["keep_together", "keep_with_next", "widow_control", "page_break_before"],
)
def test_keep_setters_emit_warning_on_none_clear(
    mock_session: Any, fake_sd_methods: Any, prop: str
) -> None:
    """python-docx 1.x treats ``None`` as "inherit from style" — clears
    the underlying OOXML attribute. SuperDoc 1.8 has no clear op for
    these, so we emit ``PendingParfmtClearWarning`` to surface the
    silent-inheritance divergence to agent runs."""
    from docx.text.paragraph import Paragraph
    from docx.text.parfmt import PendingParfmtClearWarning

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        setattr(para.paragraph_format, prop, None)
    pending = [w for w in recorded if issubclass(w.category, PendingParfmtClearWarning)]
    assert len(pending) == 1, (
        f"{prop} = None should emit exactly 1 PendingParfmtClearWarning"
    )
    assert prop in str(pending[0].message)


@pytest.mark.parametrize(
    "prop",
    ["keep_together", "keep_with_next", "widow_control", "page_break_before"],
)
def test_keep_setters_reject_non_bool(
    mock_session: Any, fake_sd_methods: Any, prop: str
) -> None:
    """Strict bool requirement — ``bool("yes")`` was silently True,
    masking a typo or wrong-value passed by the caller."""
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    with pytest.raises(TypeError, match="bool"):
        setattr(para.paragraph_format, prop, "yes")
    with pytest.raises(TypeError, match="bool"):
        setattr(para.paragraph_format, prop, 1)


@pytest.mark.parametrize(
    "prop,wire_field",
    [
        ("keep_together", "keepLines"),
        ("keep_with_next", "keepNext"),
        ("widow_control", "widowControl"),
    ],
)
def test_keep_setters_with_real_bool_ship_to_wire(
    mock_session: Any, fake_sd_methods: Any, prop: str, wire_field: str
) -> None:
    """Real bool input still works — the strict-bool gate doesn't break
    the happy path."""
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    setattr(para.paragraph_format, prop, True)
    # Find the set_keep_options call we just issued
    keep_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.paragraph.set_keep_options"
    ]
    assert keep_calls, f"expected at least one set_keep_options call for {prop}"
    payload = keep_calls[-1][1]
    assert payload[wire_field] is True


@pytest.mark.parametrize("value", [True, False])
def test_page_break_before_ships_to_set_flow_options(
    mock_session: Any, fake_sd_methods: Any, value: bool
) -> None:
    """``page_break_before`` is the odd-one-out in the trivalent OnOff
    setters: it routes through ``set_flow_options`` instead of
    ``set_keep_options``. The happy path needs its own pin so a future
    refactor that drops the ``run_sync`` call or renames the wire key
    (``pageBreakBefore``) is caught — the negative-path tests
    (TypeError / PendingParfmtClearWarning) would otherwise still
    pass and hide the regression (Greptile P2 on PR #20291)."""
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    para.paragraph_format.page_break_before = value
    flow_calls = [
        c
        for c in fake_sd_methods.calls
        if c[0] == "format.paragraph.set_flow_options"
    ]
    assert flow_calls, (
        "page_break_before should issue at least one set_flow_options call"
    )
    payload = flow_calls[-1][1]
    assert payload["pageBreakBefore"] is value


# ---------------------------------------------------------------------
# TabStops — enum validation
# ---------------------------------------------------------------------


def test_add_tab_stop_rejects_bogus_alignment_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Before: ``add_tab_stop(Inches(1), alignment="bogus")`` silently
    shipped ``"bogus"`` on the wire. Now: raises ``ValueError`` listing
    the valid WD_TAB_ALIGNMENT values."""
    from docx.shared import Inches
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    with pytest.raises(ValueError, match="WD_TAB_ALIGNMENT"):
        para.paragraph_format.tab_stops.add_tab_stop(Inches(1), alignment="bogus")


def test_add_tab_stop_rejects_bogus_leader_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Same coercion path for ``leader``."""
    from docx.shared import Inches
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    with pytest.raises(ValueError, match="WD_TAB_LEADER"):
        para.paragraph_format.tab_stops.add_tab_stop(Inches(1), leader="invalid")


def test_add_tab_stop_rejects_non_string_non_enum(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Numeric input for an enum-typed arg used to be ``str(value)``-ed
    onto the wire. Now: ``TypeError``."""
    from docx.shared import Inches
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    with pytest.raises(TypeError, match="WD_TAB_ALIGNMENT"):
        para.paragraph_format.tab_stops.add_tab_stop(Inches(1), alignment=42)
    with pytest.raises(TypeError, match="WD_TAB_LEADER"):
        para.paragraph_format.tab_stops.add_tab_stop(Inches(1), leader=42)


def test_add_tab_stop_accepts_canonical_enum_strings(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Strings that match an enum member's ``value`` still work — the
    coercion converts them to the SuperDoc wire form. Pin so we don't
    regress the python-docx-style ``alignment="center"`` calling form."""
    from docx.enum.text import WD_TAB_ALIGNMENT
    from docx.shared import Inches
    from docx.text.paragraph import Paragraph

    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    # Any one canonical enum string round-trips to wire — verifies that
    # _coerce_alignment honours the str path for valid inputs.
    enum_string = WD_TAB_ALIGNMENT.LEFT.value
    para.paragraph_format.tab_stops.add_tab_stop(Inches(1), alignment=enum_string)
    set_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.paragraph.set_tab_stop"
    ]
    assert set_calls, "add_tab_stop should have issued a set_tab_stop call"


# ---------------------------------------------------------------------
# Enum-coercion warnings: WD_ALIGN_PARAGRAPH + WD_TAB_ALIGNMENT
# ---------------------------------------------------------------------


@pytest.mark.parametrize(
    "member",
    [
        "DISTRIBUTE",
        "JUSTIFY_MED",
        "JUSTIFY_HI",
        "JUSTIFY_LOW",
        "THAI_JUSTIFY",
    ],
)
def test_align_paragraph_unmapped_to_superdoc_warns_and_falls_back(
    member: str,
) -> None:
    """``WD_ALIGN_PARAGRAPH`` members that SuperDoc can't natively
    represent (Thai/Arabic/distributed justification variants) emit
    ``PendingEnumCoercionWarning`` and serialize to ``"justify"``.

    Previously the fallback was silent — a caller setting
    ``paragraph.alignment = WD_ALIGN_PARAGRAPH.THAI_JUSTIFY`` got
    plain justification with no signal that the wire intent was
    downgraded."""
    from docx.enum.text import PendingEnumCoercionWarning, WD_ALIGN_PARAGRAPH

    enum_member = getattr(WD_ALIGN_PARAGRAPH, member)
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        wire = enum_member.to_superdoc()
    assert wire == "justify"
    pending = [w for w in recorded if issubclass(w.category, PendingEnumCoercionWarning)]
    assert len(pending) == 1, (
        f"{member}.to_superdoc() should emit 1 PendingEnumCoercionWarning"
    )


@pytest.mark.parametrize(
    "member",
    ["LEFT", "CENTER", "RIGHT", "JUSTIFY"],
)
def test_align_paragraph_mapped_to_superdoc_does_not_warn(member: str) -> None:
    """The four members SuperDoc natively supports must NOT emit a
    coercion warning — they map cleanly."""
    from docx.enum.text import PendingEnumCoercionWarning, WD_ALIGN_PARAGRAPH

    enum_member = getattr(WD_ALIGN_PARAGRAPH, member)
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        enum_member.to_superdoc()
    pending = [w for w in recorded if issubclass(w.category, PendingEnumCoercionWarning)]
    assert not pending, (
        f"{member} maps cleanly; should NOT emit PendingEnumCoercionWarning"
    )


@pytest.mark.parametrize(
    "member",
    ["LIST", "CLEAR", "END", "NUM", "START"],
)
def test_tab_alignment_unmapped_to_superdoc_warns_and_falls_back(
    member: str,
) -> None:
    """``WD_TAB_ALIGNMENT`` members SuperDoc doesn't surface (list,
    clear, end, num, start) emit ``PendingEnumCoercionWarning`` and
    serialize to ``"left"``."""
    from docx.enum.text import PendingEnumCoercionWarning, WD_TAB_ALIGNMENT

    enum_member = getattr(WD_TAB_ALIGNMENT, member)
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        wire = enum_member.to_superdoc()
    assert wire == "left"
    pending = [w for w in recorded if issubclass(w.category, PendingEnumCoercionWarning)]
    assert len(pending) == 1, (
        f"{member}.to_superdoc() should emit 1 PendingEnumCoercionWarning"
    )


@pytest.mark.parametrize(
    "member",
    ["LEFT", "CENTER", "RIGHT", "DECIMAL", "BAR"],
)
def test_tab_alignment_mapped_to_superdoc_does_not_warn(member: str) -> None:
    """SuperDoc-supported tab alignments must NOT emit a coercion
    warning — these map cleanly."""
    from docx.enum.text import PendingEnumCoercionWarning, WD_TAB_ALIGNMENT

    enum_member = getattr(WD_TAB_ALIGNMENT, member)
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        enum_member.to_superdoc()
    pending = [w for w in recorded if issubclass(w.category, PendingEnumCoercionWarning)]
    assert not pending, (
        f"{member} maps cleanly; should NOT emit PendingEnumCoercionWarning"
    )
