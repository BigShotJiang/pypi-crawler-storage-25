"""Lock-in tests for ``Paragraph.text`` and ``Paragraph.alignment``
strict-type validation.

Previously two silent-stub paths:

1. ``Paragraph.text = <non-str>``: shipped any value through
   ``replace({text: value})``. SuperDoc's permissive parser silently
   coerced or rejected it. python-docx 1.x raises ``TypeError`` via
   lxml's ``_element_text.text = value`` validation.

2. ``Paragraph.alignment = "bogus"``: ``str(value).lower()`` shipped
   any string to wire. python-docx coerces through the enum and
   raises ``ValueError`` on misses.

Now both raise immediately; valid input still ships to wire.
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_paragraph(mock_session: Any, *, node_id: str = "p1") -> Any:
    from docx.text.paragraph import Paragraph

    return Paragraph(session=mock_session, node_id=node_id, node_type="paragraph")


# ---------------------------------------------------------------------
# Paragraph.text = <non-str>
# ---------------------------------------------------------------------


@pytest.mark.parametrize("value", [42, 1.5, [1, 2, 3], {"a": "b"}, None])
def test_paragraph_text_rejects_non_str(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    """python-docx 1.x raises TypeError for non-str via lxml. Mirror
    that — previously these all silently shipped to wire."""
    para = _make_paragraph(mock_session)
    with pytest.raises(TypeError, match="str"):
        para.text = value


def test_paragraph_text_with_string_still_works(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """The happy path: a real string still issues a ``replace`` call."""
    para = _make_paragraph(mock_session)
    para.text = "hello world"
    replace_calls = [
        c for c in fake_sd_methods.calls if c[0] == "replace"
    ]
    assert replace_calls
    assert replace_calls[-1][1]["text"] == "hello world"


# ---------------------------------------------------------------------
# Paragraph.alignment = "bogus"
# ---------------------------------------------------------------------


def test_paragraph_alignment_rejects_bogus_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Was: ``para.alignment = "BOGUS"`` shipped ``"bogus"`` to wire.
    Now: ValueError listing valid WD_ALIGN_PARAGRAPH values."""
    para = _make_paragraph(mock_session)
    with pytest.raises(ValueError, match="WD_ALIGN_PARAGRAPH"):
        para.alignment = "BOGUS"


def test_paragraph_alignment_rejects_non_str_non_enum(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Lists / dicts / objects → TypeError. Note: ints are accepted as
    python-docx-style aliases (LEFT=0, CENTER=1, ...) — see
    ``test_paragraph_alignment_accepts_int_alias`` for that path."""
    para = _make_paragraph(mock_session)
    with pytest.raises(TypeError, match="WD_ALIGN_PARAGRAPH"):
        para.alignment = [1, 2, 3]


def test_paragraph_alignment_accepts_int_alias(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """python-docx 1.x's WD_ALIGN_PARAGRAPH is keyed on int (LEFT=0,
    CENTER=1, RIGHT=2, JUSTIFY=3). Real callers rely on this
    convenience (e.g. ``paragraph.alignment = 1``). Pin so the
    strict-type fix doesn't regress mega08_product_catalog
    fidelity."""
    para = _make_paragraph(mock_session)
    para.alignment = 1  # CENTER in python-docx int mapping
    align_calls = [
        c
        for c in fake_sd_methods.calls
        if c[0] == "format.paragraph.set_alignment"
    ]
    assert align_calls
    assert align_calls[-1][1]["alignment"] == "center"


def test_paragraph_alignment_rejects_bool(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``bool`` is a Python ``int`` subclass — without an explicit
    guard, ``paragraph.alignment = True`` would coerce to CENTER.
    Reject to preserve caller intent."""
    para = _make_paragraph(mock_session)
    with pytest.raises(TypeError, match="bool"):
        para.alignment = True


def test_paragraph_alignment_rejects_bogus_int(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Ints outside the python-docx mapping (LEFT=0, CENTER=1, ..., 9)
    raise ValueError."""
    para = _make_paragraph(mock_session)
    with pytest.raises(ValueError, match="WD_ALIGN_PARAGRAPH"):
        para.alignment = 99


def test_paragraph_alignment_with_enum_member_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    para = _make_paragraph(mock_session)
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    align_calls = [
        c
        for c in fake_sd_methods.calls
        if c[0] == "format.paragraph.set_alignment"
    ]
    assert align_calls
    assert align_calls[-1][1]["alignment"] == "center"


def test_paragraph_alignment_with_canonical_string_works(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """python-docx-style string coercion: ``"center"`` matches a
    WD_ALIGN_PARAGRAPH value and coerces through the enum."""
    para = _make_paragraph(mock_session)
    para.alignment = "center"
    align_calls = [
        c
        for c in fake_sd_methods.calls
        if c[0] == "format.paragraph.set_alignment"
    ]
    assert align_calls
    assert align_calls[-1][1]["alignment"] == "center"


def test_paragraph_alignment_none_still_clears(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``None`` still issues a clear-op (already correct semantics
    before this PR; pin so future refactor doesn't regress)."""
    para = _make_paragraph(mock_session)
    para.alignment = None
    clear_calls = [
        c
        for c in fake_sd_methods.calls
        if c[0] == "format.paragraph.clear_alignment"
    ]
    assert clear_calls
