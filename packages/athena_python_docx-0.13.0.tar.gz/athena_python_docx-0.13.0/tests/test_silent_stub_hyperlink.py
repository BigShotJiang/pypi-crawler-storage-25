"""Lock-in tests for the previously-silent-stub properties on
``Hyperlink``: ``fragment``, ``runs``, and ``contains_page_break``.

Each property used to return an empty / falsy default regardless of the
underlying run shape. They now mirror python-docx 1.x behavior for the
common single-run hyperlink case:

* ``fragment`` parses the URL fragment via :mod:`urllib.parse`.
* ``runs`` returns a one-element ``Run`` list when ``range_`` is provided
  (legacy callers that don't thread ``range_`` keep the empty-list
  behavior).
* ``contains_page_break`` checks the wrapped run's text for the ``\\f``
  form-feed sentinel (matches ``Run.contains_page_break`` /
  ``Paragraph.contains_page_break``).
"""

from __future__ import annotations

from typing import Any


class _FakeParagraph:
    """Minimal paragraph stand-in.

    ``Hyperlink.runs`` only reads ``paragraph._session`` and
    ``paragraph._node_id`` to construct the underlying ``Run``, so we
    don't need a real Session/Document round-trip here.
    """

    def __init__(self, *, session: Any = None, node_id: str = "p_fake") -> None:
        self._session = session
        self._node_id = node_id


# ---------------------------------------------------------------------
# fragment
# ---------------------------------------------------------------------


def test_fragment_returns_anchor_after_hash() -> None:
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://x.com/path#section1",
        run={"text": "click"},
        range_=(0, 5),
    )
    assert hl.fragment == "section1"


def test_fragment_empty_when_url_has_no_fragment() -> None:
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://x.com/path",
        run={"text": "click"},
        range_=(0, 5),
    )
    assert hl.fragment == ""


def test_fragment_does_not_include_hash_character() -> None:
    """The fragment-separator character ('#') is NOT part of the
    returned value — python-docx 1.x contract."""
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://example.com/doc#glossary",
        run={"text": "see glossary"},
        range_=(0, 12),
    )
    assert "#" not in hl.fragment
    assert hl.fragment == "glossary"


# ---------------------------------------------------------------------
# address vs url — python-docx 1.x contract: `address` is the URL
# without the fragment; `url` joins them via '#'.
# ---------------------------------------------------------------------


def test_address_strips_fragment() -> None:
    """``Hyperlink.address`` returns the URL portion without ``#frag``,
    even when ``self._target`` carries the full URL inline."""
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://x.com/path#section1",
        run={"text": "click"},
        range_=(0, 5),
    )
    assert hl.address == "https://x.com/path"


def test_address_unchanged_when_no_fragment() -> None:
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://x.com/path",
        run={"text": "click"},
        range_=(0, 5),
    )
    assert hl.address == "https://x.com/path"


def test_url_joins_address_and_fragment_with_hash() -> None:
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://x.com/path#section1",
        run={"text": "click"},
        range_=(0, 5),
    )
    assert hl.url == "https://x.com/path#section1"


def test_url_internal_jump_link_has_only_fragment() -> None:
    """Internal-bookmark links (no address, just a fragment) — ``url``
    must include the leading ``#`` so the value distinguishes
    external URLs from internal jumps, matching python-docx 1.x."""
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="#_Toc147925734",
        run={"text": "Jump to TOC"},
        range_=(0, 11),
    )
    # urlparse treats "#bookmark" as a fragment-only URL with empty scheme + netloc + path.
    assert hl.fragment == "_Toc147925734"
    assert hl.address == ""
    assert hl.url == "#_Toc147925734"


# ---------------------------------------------------------------------
# contains_page_break
# ---------------------------------------------------------------------


def test_contains_page_break_true_when_run_text_has_form_feed() -> None:
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://example.com",
        run={"text": "before\fafter"},
        range_=(0, 12),
    )
    assert hl.contains_page_break is True


def test_contains_page_break_false_when_run_text_has_no_form_feed() -> None:
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://example.com",
        run={"text": "plain text"},
        range_=(0, 10),
    )
    assert hl.contains_page_break is False


def test_contains_page_break_false_when_run_is_none() -> None:
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://example.com",
        run=None,
        range_=None,
    )
    assert hl.contains_page_break is False


# ---------------------------------------------------------------------
# runs
# ---------------------------------------------------------------------


def test_runs_returns_single_element_list_when_range_provided() -> None:
    """A single-run hyperlink materializes its wrapped Run via the
    recorded ``range_``. SuperDoc models the hyperlink as a mark on a
    single run, so we always emit a one-element list."""
    from docx.text.hyperlink import Hyperlink
    from docx.text.run import Run

    para = _FakeParagraph(session=None, node_id="p_fake")
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://example.com",
        run={"text": "click here"},
        range_=(3, 13),
    )
    runs = hl.runs
    assert isinstance(runs, list)
    assert len(runs) == 1
    assert isinstance(runs[0], Run)


def test_runs_returns_empty_list_when_range_is_none() -> None:
    """Legacy callers that don't yet thread ``range_`` get an empty
    list — this preserves the pre-fix behavior so callers that worked
    against the silent stub don't regress."""
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://example.com",
        run={"text": "click here"},
        range_=None,
    )
    assert hl.runs == []


def test_runs_returns_empty_list_when_run_dict_missing() -> None:
    """No run dict means we can't synthesize a Run — empty list."""
    from docx.text.hyperlink import Hyperlink

    para = _FakeParagraph()
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://example.com",
        run=None,
        range_=(0, 5),
    )
    assert hl.runs == []


def test_runs_uses_paragraph_session_and_node_id() -> None:
    """The synthesized Run carries the paragraph's session + node_id
    so subsequent ``.text`` / formatting reads target the same block."""
    from docx.text.hyperlink import Hyperlink

    sentinel_session = object()
    para = _FakeParagraph(session=sentinel_session, node_id="p_xyz")
    hl = Hyperlink(
        paragraph=para,  # type: ignore[arg-type]
        target="https://example.com",
        run={"text": "click"},
        range_=(0, 5),
    )
    [run] = hl.runs
    assert run._session is sentinel_session
    assert run._block_id == "p_xyz"
    assert run._range == (0, 5)
