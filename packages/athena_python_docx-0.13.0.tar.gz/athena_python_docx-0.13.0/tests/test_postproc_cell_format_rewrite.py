"""Unit tests for ``docx._postproc.PostExportOps``.

Pins the OOXML rewrite contract for cell-inner paragraph format ops.
Each test constructs a minimal ``.docx`` zip with a single one-row,
one-cell table, applies the rewrite, and asserts the expected
``<w:pPr>`` shape in the rewritten ``word/document.xml``.
"""
from __future__ import annotations

import io
import zipfile
from xml.etree import ElementTree as ET

import pytest

from docx._postproc import (
    CellAddress,
    CellOnlyAddress,
    PostExportOps,
    normalize_alignment,
    normalize_line_rule,
    to_twips,
)


W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
W_NS = f"{{{W}}}"

# Minimal Word package shape — three required parts:
#   [Content_Types].xml
#   _rels/.rels
#   word/document.xml
#
# All three must be present for Word to consider the package valid;
# tests only assert against word/document.xml.
_CONTENT_TYPES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>
"""

_ROOT_RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>
"""


def _make_minimal_docx(*, document_xml: str) -> bytes:
    """Pack a 3-part .docx zip around ``document_xml``."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", _CONTENT_TYPES_XML)
        z.writestr("_rels/.rels", _ROOT_RELS_XML)
        z.writestr("word/document.xml", document_xml)
    return buf.getvalue()


def _extract_document_xml(docx_bytes: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as z:
        return z.read("word/document.xml").decode("utf-8")


def _single_table_doc(*, cell_text: str = "Hello") -> str:
    """Render a minimal ``word/document.xml`` with one 1x1 table whose
    cell holds a single paragraph with ``cell_text``."""
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}">
  <w:body>
    <w:tbl>
      <w:tr>
        <w:tc>
          <w:p>
            <w:r><w:t>{cell_text}</w:t></w:r>
          </w:p>
        </w:tc>
      </w:tr>
    </w:tbl>
  </w:body>
</w:document>
"""


def _parse(doc_xml: str) -> ET.Element:
    return ET.fromstring(doc_xml)


def _first_cell_pPr(root: ET.Element) -> "ET.Element | None":
    """Return ``<w:pPr>`` of the first table's first cell's first paragraph."""
    tbl = root.find(f".//{W_NS}body/{W_NS}tbl")
    assert tbl is not None
    tc = tbl.find(f"{W_NS}tr/{W_NS}tc")
    assert tc is not None
    p = tc.find(f"{W_NS}p")
    assert p is not None
    return p.find(f"{W_NS}pPr")


def test_no_pending_leaves_document_content_unchanged():
    """Pre-fix this asserted byte-identity, but
    ``_convert_section_breaks_to_page_breaks`` now always runs at
    export and the re-serialize-then-re-zip path can produce
    byte-different (but content-equivalent) output even when no
    stashes are present and no section breaks need rewriting. Assert
    logical equivalence instead: no spurious ``<w:sectPr>``, no
    spurious ``<w:br w:type="page">``, no paragraphs added/removed.
    """
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    docx_out = ops.apply_to_docx(docx_in)

    in_root = _parse(_extract_document_xml(docx_in))
    out_root = _parse(_extract_document_xml(docx_out))
    in_body = in_root.find(f"{W_NS}body")
    out_body = out_root.find(f"{W_NS}body")
    assert in_body is not None and out_body is not None

    # No section breaks were added or removed.
    in_sect = len(in_body.findall(f".//{W_NS}sectPr"))
    out_sect = len(out_body.findall(f".//{W_NS}sectPr"))
    assert in_sect == out_sect

    # No inline page breaks were injected (the input has no section
    # breaks to convert).
    page_breaks = [
        br for br in out_body.iter(f"{W_NS}br")
        if br.get(f"{W_NS}type") == "page"
    ]
    assert page_breaks == []

    # Top-level paragraph count is preserved (no spurious anchor
    # removal when there's nothing to anchor).
    in_paras = [el for el in in_body if el.tag == f"{W_NS}p"]
    out_paras = [el for el in out_body if el.tag == f"{W_NS}p"]
    assert len(in_paras) == len(out_paras)


def test_alignment_right_injects_jc():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        alignment="right",
    )
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    assert pPr is not None
    jc = pPr.find(f"{W_NS}jc")
    assert jc is not None
    assert jc.get(f"{W_NS}val") == "right"


def test_style_injects_pStyle():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        style="Heading2",
    )
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    assert pPr is not None
    pStyle = pPr.find(f"{W_NS}pStyle")
    assert pStyle is not None
    assert pStyle.get(f"{W_NS}val") == "Heading2"


def test_indentation_left_right_first_line_hanging():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        left_twips=720,
        right_twips=240,
        first_line_twips=360,
        hanging_twips=120,
    )
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    assert pPr is not None
    ind = pPr.find(f"{W_NS}ind")
    assert ind is not None
    assert ind.get(f"{W_NS}left") == "720"
    assert ind.get(f"{W_NS}right") == "240"
    assert ind.get(f"{W_NS}firstLine") == "360"
    assert ind.get(f"{W_NS}hanging") == "120"


def test_spacing_before_after_line_rule():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        before_twips=120,
        after_twips=240,
        line_twips=360,
        line_rule="auto",
    )
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    assert pPr is not None
    sp = pPr.find(f"{W_NS}spacing")
    assert sp is not None
    assert sp.get(f"{W_NS}before") == "120"
    assert sp.get(f"{W_NS}after") == "240"
    assert sp.get(f"{W_NS}line") == "360"
    assert sp.get(f"{W_NS}lineRule") == "auto"


def test_keep_flags_presence_means_true():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        keep_next=True,
        keep_lines=True,
        page_break_before=True,
    )
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    assert pPr is not None
    assert pPr.find(f"{W_NS}keepNext") is not None
    assert pPr.find(f"{W_NS}keepLines") is not None
    assert pPr.find(f"{W_NS}pageBreakBefore") is not None


def test_keep_next_false_removes_element():
    pre = """<?xml version="1.0" encoding="UTF-8"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:tbl><w:tr><w:tc>
      <w:p><w:pPr><w:keepNext/></w:pPr><w:r><w:t>X</w:t></w:r></w:p>
    </w:tc></w:tr></w:tbl>
  </w:body>
</w:document>""".format(ns=W)
    docx_in = _make_minimal_docx(document_xml=pre)
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        keep_next=False,
    )
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    assert pPr is not None
    assert pPr.find(f"{W_NS}keepNext") is None


def test_widow_control_false_emits_zero_val():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        widow_control=False,
    )
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    assert pPr is not None
    wc = pPr.find(f"{W_NS}widowControl")
    assert wc is not None
    assert wc.get(f"{W_NS}val") == "0"


def test_multiple_props_merge_into_single_pPr():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    ops.add_cell_format(addr, alignment="center")
    ops.add_cell_format(addr, style="Heading1")
    ops.add_cell_format(addr, before_twips=200)
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    assert pPr is not None
    assert pPr.find(f"{W_NS}jc").get(f"{W_NS}val") == "center"
    assert pPr.find(f"{W_NS}pStyle").get(f"{W_NS}val") == "Heading1"
    assert pPr.find(f"{W_NS}spacing").get(f"{W_NS}before") == "200"


def test_preserves_existing_pPr_children_we_dont_touch():
    pre = """<?xml version="1.0" encoding="UTF-8"?>
<w:document xmlns:w="{ns}">
  <w:body>
    <w:tbl><w:tr><w:tc>
      <w:p>
        <w:pPr>
          <w:pStyle w:val="Normal"/>
          <w:ind w:left="0"/>
        </w:pPr>
        <w:r><w:t>X</w:t></w:r>
      </w:p>
    </w:tc></w:tr></w:tbl>
  </w:body>
</w:document>""".format(ns=W)
    docx_in = _make_minimal_docx(document_xml=pre)
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        alignment="right",
    )
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    assert pPr is not None
    # The previous pStyle survives untouched (we only set jc).
    pStyle = pPr.find(f"{W_NS}pStyle")
    assert pStyle is not None
    assert pStyle.get(f"{W_NS}val") == "Normal"
    # jc was added.
    assert pPr.find(f"{W_NS}jc").get(f"{W_NS}val") == "right"


def test_address_mismatch_is_a_noop():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    # Out-of-range table — first table is index 0, not 5.
    ops.add_cell_format(
        CellAddress(table_doc_index=5, row=0, col=0, paragraph_index=0),
        alignment="right",
    )
    docx_out = ops.apply_to_docx(docx_in)
    pPr = _first_cell_pPr(_parse(_extract_document_xml(docx_out)))
    # The original .docx had no pPr; rewrite should not have added one.
    assert pPr is None


def test_other_parts_round_trip_byte_identical():
    """Non-document.xml parts must come out byte-identical."""
    extra = b"sentinel-bytes-not-changed-by-rewrite"
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", _CONTENT_TYPES_XML)
        z.writestr("_rels/.rels", _ROOT_RELS_XML)
        z.writestr("word/document.xml", _single_table_doc())
        z.writestr("word/theme/theme1.xml", extra)
    docx_in = buf.getvalue()

    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        alignment="right",
    )
    docx_out = ops.apply_to_docx(docx_in)
    with zipfile.ZipFile(io.BytesIO(docx_out), "r") as z:
        assert z.read("word/theme/theme1.xml") == extra


# ---- normalize_alignment ----------------------------------------------


@pytest.mark.parametrize(
    "value,expected",
    [
        (None, None),
        ("left", "left"),
        ("LEFT", "left"),
        ("center", "center"),
        ("centre", "center"),
        ("right", "right"),
        ("both", "both"),
        ("justify", "both"),
        ("distribute", "distribute"),
        ("nope", None),
        (0, "left"),
        (1, "center"),
        (2, "right"),
        (3, "both"),
        (4, "distribute"),
        (99, None),
    ],
)
def test_normalize_alignment(value, expected):
    assert normalize_alignment(value) == expected


@pytest.mark.parametrize(
    "value,expected",
    [
        (None, None),
        ("auto", "auto"),
        ("exact", "exact"),
        ("at_least", "atLeast"),
        ("AT_LEAST", "atLeast"),
        ("at-least", "atLeast"),
        ("garbage", None),
    ],
)
def test_normalize_line_rule(value, expected):
    assert normalize_line_rule(value) == expected


def test_to_twips_handles_none_and_length_and_int():
    from docx.shared import Pt

    assert to_twips(None) is None
    assert to_twips(Pt(10)) == 200  # 10 pt × 20 twips/pt
    # Plain int EMU: 12700 EMU = 1 pt = 20 twips.
    assert to_twips(12700) == 20


# ---- Empty-leading-paragraph skip (0.11.8 fix) ---------------------


def _two_paragraph_cell_doc() -> str:
    """Mirrors the shape ``_Cell.text = "X"`` produces — the cell has
    an empty template-default paragraph at index 0 plus the new text
    paragraph at index 1."""
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}">
  <w:body>
    <w:tbl><w:tr><w:tc>
      <w:p />
      <w:p><w:r><w:t>X</w:t></w:r></w:p>
    </w:tc></w:tr></w:tbl>
  </w:body>
</w:document>
"""


def test_empty_leading_paragraph_skip_applies_to_first_non_empty():
    """``_Cell.text = "X"`` leaves the template-default empty paragraph
    at index 0 and adds the text at index 1. When the agent does
    ``cell.paragraphs[0].alignment = RIGHT``, the §13 stash records
    paragraph_index=0 (the empty one). The rewrite should walk forward
    to the first non-empty paragraph (index 1) and apply alignment
    there — that's where the agent's intent is."""
    docx_in = _make_minimal_docx(document_xml=_two_paragraph_cell_doc())
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        alignment="right",
    )
    docx_out = ops.apply_to_docx(docx_in)
    root = _parse(_extract_document_xml(docx_out))
    cell = root.find(f".//{W_NS}body/{W_NS}tbl/{W_NS}tr/{W_NS}tc")
    paragraphs = cell.findall(f"{W_NS}p")
    assert len(paragraphs) == 2
    # Empty paragraph at index 0 still has no pPr / no jc.
    assert paragraphs[0].find(f"{W_NS}pPr") is None
    # Index 1 (the visible "X") got the alignment.
    pPr = paragraphs[1].find(f"{W_NS}pPr")
    assert pPr is not None
    jc = pPr.find(f"{W_NS}jc")
    assert jc is not None
    assert jc.get(f"{W_NS}val") == "right"


def test_empty_leading_paragraph_skip_handles_style_too():
    docx_in = _make_minimal_docx(document_xml=_two_paragraph_cell_doc())
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        style="Heading2",
    )
    docx_out = ops.apply_to_docx(docx_in)
    cell = _parse(_extract_document_xml(docx_out)).find(
        f".//{W_NS}body/{W_NS}tbl/{W_NS}tr/{W_NS}tc",
    )
    paragraphs = cell.findall(f"{W_NS}p")
    # Style landed on index 1 (the "X" paragraph), not index 0 (empty).
    assert paragraphs[0].find(f"{W_NS}pPr") is None
    pStyle = paragraphs[1].find(f"{W_NS}pPr/{W_NS}pStyle")
    assert pStyle is not None
    assert pStyle.get(f"{W_NS}val") == "Heading2"


def test_empty_leading_paragraph_skip_falls_back_when_no_non_empty():
    """If every following paragraph is also empty, fall back to the
    original target (the empty one). Avoids silently no-ooping when
    the agent applied a format to an entirely-empty cell."""
    only_empty_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}">
  <w:body>
    <w:tbl><w:tr><w:tc>
      <w:p />
      <w:p />
    </w:tc></w:tr></w:tbl>
  </w:body>
</w:document>
"""
    docx_in = _make_minimal_docx(document_xml=only_empty_xml)
    ops = PostExportOps()
    ops.add_cell_format(
        CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0),
        alignment="right",
    )
    docx_out = ops.apply_to_docx(docx_in)
    cell = _parse(_extract_document_xml(docx_out)).find(
        f".//{W_NS}body/{W_NS}tbl/{W_NS}tr/{W_NS}tc",
    )
    paragraphs = cell.findall(f"{W_NS}p")
    # Fallback target: index 0 (original) gets the alignment.
    pPr = paragraphs[0].find(f"{W_NS}pPr")
    assert pPr is not None
    assert pPr.find(f"{W_NS}jc").get(f"{W_NS}val") == "right"


# ---- Cell-shading post-export rewrite (0.11.8 fix) ------------------


def test_cell_shading_injects_shd_into_tcPr():
    """SuperDoc 1.8.1 drops cell shading on export. The rewrite injects
    ``<w:shd>`` into ``<w:tcPr>`` at export time."""
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_shading(
        CellOnlyAddress(table_doc_index=0, row=0, col=0),
        fill="F6EBE5",
    )
    docx_out = ops.apply_to_docx(docx_in)
    tc = _parse(_extract_document_xml(docx_out)).find(
        f".//{W_NS}body/{W_NS}tbl/{W_NS}tr/{W_NS}tc",
    )
    tcPr = tc.find(f"{W_NS}tcPr")
    assert tcPr is not None
    shd = tcPr.find(f"{W_NS}shd")
    assert shd is not None
    assert shd.get(f"{W_NS}fill") == "F6EBE5"
    # OOXML requires w:val and w:color too — defaults to clear + auto.
    assert shd.get(f"{W_NS}val") == "clear"
    assert shd.get(f"{W_NS}color") == "auto"


def test_cell_shading_strips_hash_prefix():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    ops.add_cell_shading(
        CellOnlyAddress(table_doc_index=0, row=0, col=0),
        fill="#F6EBE5",
    )
    docx_out = ops.apply_to_docx(docx_in)
    shd = _parse(_extract_document_xml(docx_out)).find(
        f".//{W_NS}body/{W_NS}tbl/{W_NS}tr/{W_NS}tc/{W_NS}tcPr/{W_NS}shd",
    )
    assert shd is not None
    # ``#`` stripped — OOXML expects bare hex.
    assert shd.get(f"{W_NS}fill") == "F6EBE5"


def test_cell_shading_replaces_existing_shd():
    pre = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}">
  <w:body>
    <w:tbl><w:tr><w:tc>
      <w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="AAAAAA" /></w:tcPr>
      <w:p><w:r><w:t>X</w:t></w:r></w:p>
    </w:tc></w:tr></w:tbl>
  </w:body>
</w:document>"""
    docx_in = _make_minimal_docx(document_xml=pre)
    ops = PostExportOps()
    ops.add_cell_shading(
        CellOnlyAddress(table_doc_index=0, row=0, col=0),
        fill="F6EBE5",
    )
    docx_out = ops.apply_to_docx(docx_in)
    tcPr = _parse(_extract_document_xml(docx_out)).find(
        f".//{W_NS}body/{W_NS}tbl/{W_NS}tr/{W_NS}tc/{W_NS}tcPr",
    )
    shds = tcPr.findall(f"{W_NS}shd")
    # Old shading replaced — exactly one shd remains.
    assert len(shds) == 1
    assert shds[0].get(f"{W_NS}fill") == "F6EBE5"


def test_cell_shading_address_mismatch_is_noop():
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    # Out-of-range row.
    ops.add_cell_shading(
        CellOnlyAddress(table_doc_index=0, row=5, col=0),
        fill="F6EBE5",
    )
    docx_out = ops.apply_to_docx(docx_in)
    tc = _parse(_extract_document_xml(docx_out)).find(
        f".//{W_NS}body/{W_NS}tbl/{W_NS}tr/{W_NS}tc",
    )
    # No tcPr created — no shading.
    tcPr = tc.find(f"{W_NS}tcPr")
    if tcPr is not None:
        assert tcPr.find(f"{W_NS}shd") is None


def test_has_pending_true_for_shading_only():
    ops = PostExportOps()
    assert not ops.has_pending()
    ops.add_cell_shading(
        CellOnlyAddress(table_doc_index=0, row=0, col=0),
        fill="F6EBE5",
    )
    assert ops.has_pending()


def test_add_cell_shading_with_all_none_is_noop():
    ops = PostExportOps()
    ops.add_cell_shading(
        CellOnlyAddress(table_doc_index=0, row=0, col=0),
    )
    assert not ops.has_pending()


# ---- section break → inline page break conversion -------------------


def _doc_with_section_break(*, n_anchors: int = 2) -> str:
    """Render the SuperDoc-emitted shape for one ``add_page_break()``.

    ``add_page_break`` ships an ``add_paragraph("")`` (one anchor) plus
    a ``create.section_break`` call; SuperDoc 1.8.1's export adds a
    second empty default paragraph before the section-break-bearing
    paragraph. The ``n_anchors`` knob lets tests reproduce both the
    1-anchor and 2-anchor variants the SDK has been observed
    emitting.
    """
    anchors = "".join("<w:p />" for _ in range(n_anchors))
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}">
  <w:body>
    <w:p><w:r><w:t>Before break</w:t></w:r></w:p>
    {anchors}
    <w:p>
      <w:pPr>
        <w:sectPr>
          <w:type w:val="nextPage"/>
        </w:sectPr>
      </w:pPr>
    </w:p>
    <w:p><w:r><w:t>After break</w:t></w:r></w:p>
    <w:sectPr><w:pgSz w:w="12240" w:h="15840"/></w:sectPr>
  </w:body>
</w:document>
"""


def _body(root: ET.Element) -> ET.Element:
    body = root.find(f"{W_NS}body")
    assert body is not None
    return body


def test_section_break_rewritten_to_inline_page_break():
    """The in-paragraph ``<w:sectPr w:type='nextPage'/>`` must be
    replaced by ``<w:r><w:br w:type='page'/></w:r>`` in the same
    paragraph; ``<w:pPr>`` is removed once empty."""
    docx_in = _make_minimal_docx(document_xml=_doc_with_section_break())
    ops = PostExportOps()
    docx_out = ops.apply_to_docx(docx_in)
    body = _body(_parse(_extract_document_xml(docx_out)))

    # No in-paragraph sectPr remains. The document-level sectPr
    # (direct child of <w:body>, not inside any <w:pPr>) is preserved.
    # ET doesn't expose .getparent(), so walk the body's <w:p>
    # children manually.
    in_para_count = 0
    for p in body:
        if p.tag != f"{W_NS}p":
            continue
        pPr = p.find(f"{W_NS}pPr")
        if pPr is not None and pPr.find(f"{W_NS}sectPr") is not None:
            in_para_count += 1
    assert in_para_count == 0

    # The document-level final sectPr is still there.
    doc_level_sectPrs = [el for el in body if el.tag == f"{W_NS}sectPr"]
    assert len(doc_level_sectPrs) == 1

    # Exactly one inline page break landed.
    page_breaks = [
        br for br in body.iter(f"{W_NS}br")
        if br.get(f"{W_NS}type") == "page"
    ]
    assert len(page_breaks) == 1


def test_section_break_rewrite_removes_empty_anchor_paragraphs():
    """The 2 empty self-closing ``<w:p/>`` paragraphs ``add_page_break``
    injects before the section break MUST be removed by the rewrite.
    Otherwise they take vertical space and push content onto an orphan
    page."""
    docx_in = _make_minimal_docx(
        document_xml=_doc_with_section_break(n_anchors=2),
    )
    ops = PostExportOps()
    docx_out = ops.apply_to_docx(docx_in)
    body = _body(_parse(_extract_document_xml(docx_out)))

    paragraphs = [el for el in body if el.tag == f"{W_NS}p"]
    # Before: <p>Before break</p>, 2x <p/>, <p w/sectPr>, <p>After</p>
    # After:  <p>Before break</p>,           <p w/page-break>, <p>After</p>
    assert len(paragraphs) == 3
    # First paragraph still has the "Before break" content.
    first_text = "".join(t.text or "" for t in paragraphs[0].iter(f"{W_NS}t"))
    assert first_text == "Before break"
    # Middle paragraph carries the page break.
    br = paragraphs[1].find(f".//{W_NS}br")
    assert br is not None
    assert br.get(f"{W_NS}type") == "page"
    # Trailing paragraph survives.
    last_text = "".join(t.text or "" for t in paragraphs[2].iter(f"{W_NS}t"))
    assert last_text == "After break"


def test_section_break_rewrite_preserves_text_spacer_paragraphs():
    """``doc.add_paragraph(" ")`` spacers contain ``<w:r><w:t> </w:t></w:r>``
    — those are user-intent and MUST survive the rewrite. Only the
    truly-empty self-closing anchors ``add_page_break`` injects get
    removed."""
    document_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}">
  <w:body>
    <w:p><w:r><w:t>Section 1 content</w:t></w:r></w:p>
    <w:p><w:r><w:t xml:space="preserve"> </w:t></w:r></w:p>
    <w:p />
    <w:p />
    <w:p>
      <w:pPr>
        <w:sectPr><w:type w:val="nextPage"/></w:sectPr>
      </w:pPr>
    </w:p>
    <w:p><w:r><w:t>Section 2 content</w:t></w:r></w:p>
    <w:sectPr/>
  </w:body>
</w:document>
"""
    docx_in = _make_minimal_docx(document_xml=document_xml)
    ops = PostExportOps()
    docx_out = ops.apply_to_docx(docx_in)
    body = _body(_parse(_extract_document_xml(docx_out)))
    paragraphs = [el for el in body if el.tag == f"{W_NS}p"]
    # Section 1 content, spacer (preserved), page-break paragraph, Section 2
    assert len(paragraphs) == 4
    texts = [
        "".join(t.text or "" for t in p.iter(f"{W_NS}t"))
        for p in paragraphs
    ]
    assert texts[0] == "Section 1 content"
    assert texts[1] == " "  # spacer preserved
    assert texts[3] == "Section 2 content"
    # The page break is on paragraph index 2 (after Section 1 + spacer).
    br = paragraphs[2].find(f".//{W_NS}br")
    assert br is not None
    assert br.get(f"{W_NS}type") == "page"


def test_non_nextpage_section_breaks_are_left_alone():
    """``continuous`` / ``evenPage`` / ``oddPage`` section breaks have
    distinct intent that an inline page break can't encode — the
    rewrite must NOT touch them."""
    document_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}">
  <w:body>
    <w:p>
      <w:pPr>
        <w:sectPr><w:type w:val="continuous"/></w:sectPr>
      </w:pPr>
    </w:p>
    <w:sectPr/>
  </w:body>
</w:document>
"""
    docx_in = _make_minimal_docx(document_xml=document_xml)
    ops = PostExportOps()
    docx_out = ops.apply_to_docx(docx_in)
    body = _body(_parse(_extract_document_xml(docx_out)))

    # The continuous section break survives intact.
    in_para_p = body.find(f"{W_NS}p")
    assert in_para_p is not None
    pPr = in_para_p.find(f"{W_NS}pPr")
    assert pPr is not None
    sectPr = pPr.find(f"{W_NS}sectPr")
    assert sectPr is not None
    type_el = sectPr.find(f"{W_NS}type")
    assert type_el is not None
    assert type_el.get(f"{W_NS}val") == "continuous"

    # No inline page breaks were injected.
    page_breaks = [
        br for br in body.iter(f"{W_NS}br")
        if br.get(f"{W_NS}type") == "page"
    ]
    assert page_breaks == []


def test_document_level_sectPr_is_preserved():
    """The final ``<w:sectPr>`` (direct child of ``<w:body>``, NOT
    inside a ``<w:pPr>``) defines the document's default section
    settings. The rewrite must NOT remove or alter it."""
    document_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="{W}">
  <w:body>
    <w:p><w:r><w:t>Hi</w:t></w:r></w:p>
    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="1440" w:bottom="1440" w:left="1440" w:right="1440"/>
    </w:sectPr>
  </w:body>
</w:document>
"""
    docx_in = _make_minimal_docx(document_xml=document_xml)
    ops = PostExportOps()
    docx_out = ops.apply_to_docx(docx_in)
    body = _body(_parse(_extract_document_xml(docx_out)))

    sectPrs = [el for el in body if el.tag == f"{W_NS}sectPr"]
    assert len(sectPrs) == 1
    # Page size + margins survive.
    pgSz = sectPrs[0].find(f"{W_NS}pgSz")
    pgMar = sectPrs[0].find(f"{W_NS}pgMar")
    assert pgSz is not None
    assert pgMar is not None
    assert pgSz.get(f"{W_NS}w") == "12240"
    assert pgMar.get(f"{W_NS}top") == "1440"


def test_no_section_breaks_no_page_breaks():
    """A doc with no in-paragraph section breaks must not gain any
    inline page breaks."""
    docx_in = _make_minimal_docx(document_xml=_single_table_doc())
    ops = PostExportOps()
    docx_out = ops.apply_to_docx(docx_in)
    body = _body(_parse(_extract_document_xml(docx_out)))
    page_breaks = [
        br for br in body.iter(f"{W_NS}br")
        if br.get(f"{W_NS}type") == "page"
    ]
    assert page_breaks == []
