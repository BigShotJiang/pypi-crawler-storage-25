"""Lock-in test for ``Paragraph.style.setter`` catch-all rejection.

The setter previously had a catch-all branch:

    else:
        style_id = str(value)

If the caller passed an object without ``.style_id`` / ``.name``
attributes, ``str(value)`` produced garbage like
``"<__main__.MyObject object at 0x1035be400>"`` which then shipped
as a style id to the wire. SuperDoc silently swallowed it.

python-docx 1.x's ``Paragraph.style.setter`` raises ``TypeError`` for
non-``str``, non-``BaseStyle`` input. Mirror that — now anything that
isn't ``str | None`` and doesn't have a ``style_id`` or ``name``
attribute raises ``TypeError``.
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_paragraph(mock_session: Any) -> Any:
    from docx.text.paragraph import Paragraph

    return Paragraph(
        session=mock_session,
        node_id="p1",
        node_type="paragraph",
    )


@pytest.mark.parametrize("value", [42, 1.5, [1, 2], {"a": "b"}, object()])
def test_paragraph_style_setter_rejects_invalid_type(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    """Was: silent ``str(value)`` ship-to-wire. Now: TypeError."""
    para = _make_paragraph(mock_session)
    with pytest.raises(TypeError, match="BaseStyle"):
        para.style = value


def test_paragraph_style_setter_str_still_works(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Happy path."""
    para = _make_paragraph(mock_session)
    para.style = "Heading 1"
    set_calls = [
        c
        for c in fake_sd_methods.calls
        if c[0] == "styles.paragraph.set_style"
    ]
    assert set_calls
    assert set_calls[-1][1]["styleId"] == "Heading 1"


def test_paragraph_style_setter_none_uses_normal(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """None resolves to 'Normal' (python-docx default)."""
    para = _make_paragraph(mock_session)
    para.style = None
    set_calls = [
        c
        for c in fake_sd_methods.calls
        if c[0] == "styles.paragraph.set_style"
    ]
    assert set_calls
    assert set_calls[-1][1]["styleId"] == "Normal"


def test_paragraph_style_setter_duck_typed_style_id_works(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Objects with a ``style_id`` attribute still work (duck-typing
    convenience for BaseStyle subclasses)."""
    para = _make_paragraph(mock_session)

    class FakeStyle:
        style_id = "MyStyle"

    para.style = FakeStyle()
    set_calls = [
        c
        for c in fake_sd_methods.calls
        if c[0] == "styles.paragraph.set_style"
    ]
    assert set_calls
    assert set_calls[-1][1]["styleId"] == "MyStyle"
