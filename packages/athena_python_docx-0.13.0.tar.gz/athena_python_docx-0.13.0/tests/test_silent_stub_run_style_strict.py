"""Lock-in test for ``Run.style.setter`` catch-all rejection.

Same pattern as ``Paragraph.style.setter`` (fixed in PR #20310). The
setter previously had:

    else:
        style_id = str(value)

If the caller passed an object without ``.style_id``/``.name``,
``str(value)`` produced garbage like
``"<__main__.MyObject object at 0x1035be400>"`` which shipped as a
run-level character-style id. SuperDoc silently swallowed it.

Now: ``TypeError`` listing the accepted shapes. Duck-typed objects
with ``.style_id`` or ``.name`` still work (parity with
CharacterStyle subclasses).
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_run(mock_session: Any) -> Any:
    from docx.text.run import Run

    return Run(
        session=mock_session,
        block_id="p1",
        range_=(0, 5),
        inline={"text": "hello"},
    )


@pytest.mark.parametrize("value", [42, 1.5, [1, 2], {"a": "b"}, object()])
def test_run_style_setter_rejects_invalid_type(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    run = _make_run(mock_session)
    with pytest.raises(TypeError, match="CharacterStyle"):
        run.style = value


def test_run_style_setter_str_still_works(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.style = "Emphasis"
    apply_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.apply"
    ]
    assert apply_calls
    assert apply_calls[-1][1]["inline"]["rStyle"] == "Emphasis"


def test_run_style_setter_duck_typed_works(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)

    class FakeStyle:
        style_id = "MyCharStyle"

    run.style = FakeStyle()
    apply_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.apply"
    ]
    assert apply_calls
    assert apply_calls[-1][1]["inline"]["rStyle"] == "MyCharStyle"
