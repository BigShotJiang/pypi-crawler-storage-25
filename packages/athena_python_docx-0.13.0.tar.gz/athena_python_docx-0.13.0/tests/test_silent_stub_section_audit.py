"""Lock-in tests for ``Section`` setter validation (silent-stub audit).

python-docx 1.2.0 raises ``ValueError`` when ``Section.start_type`` or
``Section.orientation`` is assigned a value that isn't a member of the
corresponding enum (the upstream setters defer to lxml/enum coercion
which validates). Our setters previously accepted any ``str`` / ``int``
and shipped it raw to SuperDoc, where the ``AnyDoc``-typed applier
silently accepted garbage — a behavioral parity gap the introspection
ratchet can't see.

``Section.orientation`` also has a subtle ``None`` semantics gap:
python-docx falls back to ``WD_ORIENTATION.PORTRAIT`` for ``None``
(``pgSz.orient = value if value else WD_ORIENTATION.PORTRAIT``), but
our setter used to silently no-op. ``Section.start_type`` collapses
``None`` and ``WD_SECTION_START.NEW_PAGE`` to the same reset branch
upstream (``self._remove_type()``); we now mirror that.

When SuperDoc adds strict-typed section setters (so a bogus value
would 4xx on the wire instead of being silently accepted), these
tests should be updated, but the user-facing contract — invalid
input raises ``ValueError`` synchronously — should not change.
"""

from __future__ import annotations

from typing import Any

import pytest

from docx.enum.section import WD_ORIENTATION, WD_SECTION_START
from docx.section import Section


def _make_section(mock_session: Any, *, section_id: str = "sec-1") -> Section:
    return Section(
        session=mock_session,
        address={"kind": "section", "sectionId": section_id},
    )


# ---------------------------------------------------------------------
# Section.start_type setter
# ---------------------------------------------------------------------


def test_start_type_rejects_unknown_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Bogus string must raise ``ValueError`` (python-docx parity)."""
    section = _make_section(mock_session)
    with pytest.raises(ValueError, match="WD_SECTION_START"):
        section.start_type = "BOGUS_VALUE"  # type: ignore[assignment]
    # And critically: no wire call should have been made.
    assert not any(
        op == "sections.set_break_type" for op, _ in fake_sd_methods.calls
    ), "set_break_type should NOT be called for invalid input"


def test_start_type_rejects_unknown_int(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    section = _make_section(mock_session)
    with pytest.raises(ValueError, match="WD_SECTION_START"):
        section.start_type = 99  # type: ignore[assignment]
    assert not any(
        op == "sections.set_break_type" for op, _ in fake_sd_methods.calls
    )


def test_start_type_accepts_enum_value(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Valid enum value still flows to the wire — sanity check."""
    section = _make_section(mock_session)
    section.start_type = WD_SECTION_START.CONTINUOUS
    calls = [c for c in fake_sd_methods.calls if c[0] == "sections.set_break_type"]
    assert len(calls) == 1
    assert calls[0][1]["breakType"] == "continuous"


def test_start_type_none_resets_to_new_page(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """python-docx collapses ``None`` to the NEW_PAGE reset branch.

    Previously this was a silent no-op; now it sends the explicit
    ``nextPage`` break type to keep state coherent with upstream.
    """
    section = _make_section(mock_session)
    section.start_type = None
    calls = [c for c in fake_sd_methods.calls if c[0] == "sections.set_break_type"]
    assert len(calls) == 1
    assert calls[0][1]["breakType"] == "nextPage"


def test_start_type_accepts_string_alias(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Enum-value-as-string still works (parity with enum coercion)."""
    section = _make_section(mock_session)
    section.start_type = "evenPage"  # type: ignore[assignment]
    calls = [c for c in fake_sd_methods.calls if c[0] == "sections.set_break_type"]
    assert len(calls) == 1
    assert calls[0][1]["breakType"] == "evenPage"


# ---------------------------------------------------------------------
# Section.orientation setter
# ---------------------------------------------------------------------


def test_orientation_rejects_unknown_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    section = _make_section(mock_session)
    with pytest.raises(ValueError, match="WD_ORIENTATION"):
        section.orientation = "BOGUS_ORIENT"  # type: ignore[assignment]
    assert not any(
        op == "sections.set_page_setup" for op, _ in fake_sd_methods.calls
    )


def test_orientation_rejects_unknown_int(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    section = _make_section(mock_session)
    with pytest.raises(ValueError, match="WD_ORIENTATION"):
        section.orientation = 99  # type: ignore[assignment]
    assert not any(
        op == "sections.set_page_setup" for op, _ in fake_sd_methods.calls
    )


def test_orientation_none_falls_back_to_portrait(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """python-docx behavior: ``None`` → ``WD_ORIENTATION.PORTRAIT``.

    Upstream: ``pgSz.orient = value if value else WD_ORIENTATION.PORTRAIT``.
    Previously a silent no-op here; now we explicitly send portrait.
    """
    section = _make_section(mock_session)
    section.orientation = None
    calls = [c for c in fake_sd_methods.calls if c[0] == "sections.set_page_setup"]
    assert len(calls) == 1
    assert calls[0][1]["orientation"] == "portrait"


def test_orientation_accepts_enum_value(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    section = _make_section(mock_session)
    section.orientation = WD_ORIENTATION.LANDSCAPE
    calls = [c for c in fake_sd_methods.calls if c[0] == "sections.set_page_setup"]
    assert len(calls) == 1
    assert calls[0][1]["orientation"] == "landscape"


def test_orientation_accepts_string_alias(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    section = _make_section(mock_session)
    section.orientation = "landscape"  # type: ignore[assignment]
    calls = [c for c in fake_sd_methods.calls if c[0] == "sections.set_page_setup"]
    assert len(calls) == 1
    assert calls[0][1]["orientation"] == "landscape"
