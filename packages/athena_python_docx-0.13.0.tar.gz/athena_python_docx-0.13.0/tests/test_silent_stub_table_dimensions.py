"""Lock-in tests for negative-dimension rejection on _Row.height / _Cell.width.

Earlier audit (iter 9 fan-out) tightened ``_Column.width`` to raise
``ValueError`` for negatives, mirroring python-docx's unsigned-twips
storage. The corresponding setters on ``_Row.height`` and
``_Cell.width`` still silently round-tripped negatives to the wire,
where SuperDoc would either reject them or produce a degenerate
dimension. This iteration tightens both to match the column setter.
"""

from __future__ import annotations

from typing import Any

import pytest

from docx.shared import Emu, Length, Pt


def _scripted_get(rows: int, cols: int) -> dict:
    return {"rows": rows, "cols": cols, "styleId": "TableGrid"}


def _make_table(mock_session: Any, *, node_id: str = "tbl-1"):
    from docx.table import Table

    return Table(session=mock_session, node_id=node_id)


def test_row_height_accepts_positive(mock_session: Any, fake_sd_methods: Any) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 2)
    table = _make_table(mock_session)
    row = table.rows[0]
    row.height = Pt(18)


def test_row_height_accepts_zero(mock_session: Any, fake_sd_methods: Any) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 2)
    table = _make_table(mock_session)
    row = table.rows[0]
    row.height = Length(0)


def test_row_height_accepts_none_as_noop(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 2)
    table = _make_table(mock_session)
    row = table.rows[0]
    row.height = None


def test_row_height_rejects_negative(mock_session: Any, fake_sd_methods: Any) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 2)
    table = _make_table(mock_session)
    row = table.rows[0]
    with pytest.raises(ValueError) as excinfo:
        row.height = Emu(-1000)
    assert "_Row.height" in str(excinfo.value)
    assert "non-negative" in str(excinfo.value)


def test_cell_width_accepts_positive(mock_session: Any, fake_sd_methods: Any) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 2)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    cell.width = Pt(72)


def test_cell_width_accepts_zero(mock_session: Any, fake_sd_methods: Any) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 2)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    cell.width = Length(0)


def test_cell_width_rejects_negative(mock_session: Any, fake_sd_methods: Any) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 2)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    with pytest.raises(ValueError) as excinfo:
        cell.width = Emu(-100)
    assert "_Cell.width" in str(excinfo.value)
    assert "non-negative" in str(excinfo.value)


def test_cell_height_delegates_to_row_height_validation(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``_Cell.height = ...`` delegates to ``_Row.height``, so the same
    negative-rejection contract applies."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 2)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    with pytest.raises(ValueError) as excinfo:
        cell.height = Emu(-50)
    assert "_Row.height" in str(excinfo.value)
