"""Tests for multi-run hyperlink coalescing.

SuperDoc models a hyperlink as a mark on each run, so a logical
``<w:hyperlink>`` wrapping two consecutive runs (e.g. bold + non-bold
sharing one URL) arrives as two inlines with the same ``hyperlink``
field. python-docx 1.x emits ONE :class:`Hyperlink` for that wrapper
with both runs underneath.

The coalescing logic lives in
:attr:`docx.text.paragraph.Paragraph.hyperlinks` and
:meth:`docx.text.paragraph.Paragraph.iter_inner_content`. Resolves
``§ 9`` in ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` (single-run
fallback was correct; multi-run was under-counted before this change).
"""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock


def _make_paragraph(inlines: list[dict]) -> Any:
    """Build a :class:`Paragraph` whose ``get_node_by_id`` returns the
    given inlines list.

    The fake mirrors SuperDoc's actual response shape:
    ``{"node": {"paragraph": {"inlines": [...]}}}``.
    """
    from docx.client import Session
    from docx.text.paragraph import Paragraph

    response = {"node": {"paragraph": {"inlines": inlines}}}

    session = MagicMock(spec=Session)
    session.asset_id = "asset_fake"
    session.is_open = True
    session.doc = MagicMock()
    session.doc.get_node_by_id = AsyncMock(return_value=response)

    return Paragraph(session=session, node_id="p1", node_type="paragraph")


def test_two_consecutive_same_target_runs_coalesce_into_one_hyperlink() -> None:
    """A logical ``<w:hyperlink>`` wrapping two runs (e.g. mixed
    bold/non-bold) must collapse to a single :class:`Hyperlink`.
    """
    from docx.text.hyperlink import Hyperlink

    p = _make_paragraph([
        {"run": {"text": "click ", "hyperlink": "https://example.com"}},
        {"run": {"text": "here", "hyperlink": "https://example.com", "bold": True}},
    ])
    links = p.hyperlinks
    assert len(links) == 1
    [link] = links
    assert isinstance(link, Hyperlink)
    assert link.address == "https://example.com"
    assert link.text == "click here"
    assert len(link.runs) == 2
    assert link.runs[0]._range == (0, 6)
    assert link.runs[1]._range == (6, 10)


def test_different_targets_emit_separate_hyperlinks() -> None:
    """Two consecutive runs with different hyperlink targets stay
    separate — they correspond to two distinct ``<w:hyperlink>``
    wrappers in OOXML.
    """
    p = _make_paragraph([
        {"run": {"text": "a", "hyperlink": "https://x.com"}},
        {"run": {"text": "b", "hyperlink": "https://y.com"}},
    ])
    links = p.hyperlinks
    assert len(links) == 2
    assert links[0].address == "https://x.com"
    assert links[1].address == "https://y.com"


def test_non_link_run_between_links_breaks_coalesce() -> None:
    """A plain run between two same-target hyperlinked runs terminates
    the first wrapper; the third run starts a new wrapper.
    """
    p = _make_paragraph([
        {"run": {"text": "see ", "hyperlink": "https://example.com"}},
        {"run": {"text": "this and "}},
        {"run": {"text": "that", "hyperlink": "https://example.com"}},
    ])
    links = p.hyperlinks
    assert len(links) == 2
    assert links[0].text == "see "
    assert len(links[0].runs) == 1
    assert links[1].text == "that"
    assert len(links[1].runs) == 1


def test_tab_break_between_links_breaks_coalesce() -> None:
    """Tab inlines can't live inside ``<w:hyperlink>`` so they end the
    wrapper.
    """
    p = _make_paragraph([
        {"run": {"text": "part1", "hyperlink": "https://example.com"}},
        {"type": "tab"},
        {"run": {"text": "part2", "hyperlink": "https://example.com"}},
    ])
    links = p.hyperlinks
    assert len(links) == 2


def test_single_run_hyperlink_still_emits_one_hyperlink_with_one_run() -> None:
    """Backwards-compat: the common single-run case stays one
    :class:`Hyperlink` carrying one :class:`Run`.
    """
    p = _make_paragraph([
        {"run": {"text": "click", "hyperlink": "https://example.com"}},
    ])
    links = p.hyperlinks
    assert len(links) == 1
    assert links[0].text == "click"
    assert len(links[0].runs) == 1


def test_hyperlink_runs_inherit_paragraph_session_and_node_id() -> None:
    """Each materialized :class:`Run` carries the paragraph's session
    + node_id so subsequent ``.text`` / format reads target the right
    block.
    """
    p = _make_paragraph([
        {"run": {"text": "abc", "hyperlink": "https://example.com"}},
        {"run": {"text": "def", "hyperlink": "https://example.com"}},
    ])
    [link] = p.hyperlinks
    for run in link.runs:
        assert run._session is p._session
        assert run._block_id == "p1"


def test_iter_inner_content_coalesces_consecutive_same_target_runs() -> None:
    """``Paragraph.iter_inner_content`` yields one :class:`Hyperlink`
    per logical wrapper, matching python-docx 1.x.
    """
    from docx.text.hyperlink import Hyperlink
    from docx.text.run import Run

    p = _make_paragraph([
        {"run": {"text": "see ", "hyperlink": "https://example.com"}},
        {"run": {"text": "the docs", "hyperlink": "https://example.com"}},
        {"run": {"text": " for more"}},
    ])
    items = list(p.iter_inner_content())
    assert len(items) == 2
    link, tail = items
    assert isinstance(link, Hyperlink)
    assert link.text == "see the docs"
    assert len(link.runs) == 2
    assert isinstance(tail, Run)


def test_iter_inner_content_flushes_trailing_hyperlink_at_end() -> None:
    """A paragraph that ends on a hyperlinked run must still yield the
    wrapper — earlier impl could drop it because the flush only ran
    inside the main loop.
    """
    from docx.text.hyperlink import Hyperlink

    p = _make_paragraph([
        {"run": {"text": "lead in "}},
        {"run": {"text": "tail", "hyperlink": "https://example.com"}},
    ])
    items = list(p.iter_inner_content())
    assert any(isinstance(i, Hyperlink) for i in items)
    last = items[-1]
    assert isinstance(last, Hyperlink)
    assert last.text == "tail"


def test_hyperlink_contains_page_break_across_segments() -> None:
    """``Hyperlink.contains_page_break`` checks every segment, not just
    the first run — a page break in any wrapped run counts.
    """
    p = _make_paragraph([
        {"run": {"text": "before", "hyperlink": "https://example.com"}},
        {"run": {"text": "after\fnext page", "hyperlink": "https://example.com"}},
    ])
    [link] = p.hyperlinks
    assert link.contains_page_break is True


def test_hyperlink_text_joins_all_segment_text() -> None:
    """``Hyperlink.text`` matches python-docx: the visible anchor text
    is the concatenation of every wrapped run's text.
    """
    p = _make_paragraph([
        {"run": {"text": "abc", "hyperlink": "https://example.com"}},
        {"run": {"text": "DEF", "hyperlink": "https://example.com"}},
        {"run": {"text": "ghi", "hyperlink": "https://example.com"}},
    ])
    [link] = p.hyperlinks
    assert link.text == "abcDEFghi"
    assert len(link.runs) == 3
