"""Regression tests for the paragraph text-length cache.

Before the cache, every ``Paragraph.add_run(...)`` issued an extra
``get_node_by_id`` HTTP round-trip to compute the insertion offset.
For an agent script with 30 paragraphs and 50 runs, that's 50 wasted
round-trips on top of the inserts. The staging session that prompted
this fix took ~6 min per ``execute_word_document_code`` call building
an investment-memo doc.

The cache lives on ``Paragraph._text_len`` and is initialized by:
- ``Document.add_paragraph(text=X)`` / ``add_heading(text=X)`` (set to ``len(X)``)
- ``Paragraph.runs`` access (refreshed from the walked inlines)

It's updated by:
- ``Paragraph.add_run(text=X)`` (increments by ``len(X)``)
- ``Paragraph.text = X`` (resets to ``len(X)``)
- Run mutations on a Run created with ``paragraph=self`` back-ref
  (``Run.text``, ``Run.add_text``, ``Run.add_tab``, ``Run.add_break``)
"""

from __future__ import annotations

from typing import Any


def _count_op(fake_sd_methods: Any, op_name: str) -> int:
    return sum(1 for op, _ in fake_sd_methods.calls if op == op_name)


def test_paragraph_constructed_with_text_len_skips_query_on_add_run(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``Document.add_paragraph(text=X)`` constructs the paragraph
    with ``text_len=len(X)``; the next ``p.add_run(...)`` reads the
    cache instead of issuing a ``get_node_by_id`` query — that was
    the single biggest source of round-trip amplification in the
    failing investment-memo script."""
    from docx.text.paragraph import Paragraph

    p = Paragraph(
        session=mock_session,
        node_id="p-1",
        node_type="paragraph",
        text_len=len("hello world"),
    )
    assert p._text_len == 11

    p.add_run(" more")

    # ``add_run`` should NOT have queried get_node_by_id — the cache
    # gave it the offset directly.
    assert _count_op(fake_sd_methods, "get_node_by_id") == 0
    # The cache reflects the new length: "hello world" + " more" = 16.
    assert p._text_len == 16


def test_paragraph_runs_property_refreshes_cache(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``p.runs`` walks the server-side inlines anyway — refresh the
    cache so the follow-up ``add_run`` skips its query."""
    from docx.text.paragraph import Paragraph

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "paragraph": {
                "inlines": [
                    {"run": {"text": "hello"}},
                    {"type": "tab"},
                    {"run": {"text": "world"}},
                ],
            },
        },
    }

    p = Paragraph(session=mock_session, node_id="p-1", node_type="paragraph")
    runs = p.runs
    # "hello" (5) + tab (1) + "world" (5) = 11
    assert p._text_len == 11
    assert len(runs) == 2

    # Subsequent add_run uses the cached length — no extra query.
    before = _count_op(fake_sd_methods, "get_node_by_id")
    p.add_run("!")
    after = _count_op(fake_sd_methods, "get_node_by_id")
    assert after == before


def test_run_add_text_keeps_paragraph_cache_in_sync(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A Run created via ``Paragraph.add_run`` carries a back-ref to
    its paragraph. When the Run mutates the paragraph's text-address
    space (here via ``add_text``), the paragraph's ``_text_len``
    updates so the NEXT ``add_run`` still skips its query."""
    from docx.text.paragraph import Paragraph

    p = Paragraph(
        session=mock_session, node_id="p-1", node_type="paragraph", text_len=0
    )

    r = p.add_run("hello")
    assert p._text_len == 5
    r.add_text(" more")
    assert p._text_len == 10

    # No queries — cache stayed valid through both mutations.
    assert _count_op(fake_sd_methods, "get_node_by_id") == 0


def test_run_text_setter_updates_cache_via_delta(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``r.text = "longer"`` over a run that was "hi" must update the
    paragraph cache by +4, not blow it away."""
    from docx.text.paragraph import Paragraph

    p = Paragraph(
        session=mock_session, node_id="p-1", node_type="paragraph", text_len=0
    )

    r = p.add_run("hi")
    assert p._text_len == 2
    r.text = "longer"  # replaces 2 chars with 6 → delta = +4
    assert p._text_len == 6


def test_paragraph_text_setter_resets_cache(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.paragraph import Paragraph

    p = Paragraph(
        session=mock_session, node_id="p-1", node_type="paragraph", text_len=10
    )

    p.text = "new"
    assert p._text_len == 3


def test_paragraph_with_no_cache_still_works(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A Paragraph constructed without ``text_len`` (e.g., loaded from
    a server query) falls back to ``_node_text`` — no regression for
    read paths that don't pre-cache."""
    from docx.text.paragraph import Paragraph

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {"paragraph": {"inlines": [{"run": {"text": "hi"}}]}},
    }

    p = Paragraph(session=mock_session, node_id="p-1", node_type="paragraph")
    # Cache starts unset.
    assert p._text_len is None

    p.add_run(" there")
    # One get_node_by_id query (the fallback path), no more after the
    # cache is populated.
    assert _count_op(fake_sd_methods, "get_node_by_id") == 1
    assert p._text_len == 8
