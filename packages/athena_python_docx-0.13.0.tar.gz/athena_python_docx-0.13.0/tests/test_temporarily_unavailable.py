"""Lock-in tests for :class:`DocxStudioTemporarilyUnavailable`.

docx-studio 502/503/504 responses (after the SDK retry budget is
exhausted) must surface as a typed transient-failure exception rather
than a generic :class:`DocxError`. Agents catching the typed exception
can distinguish a studio-down state ("retry later, possibly with a
larger sleep at the agent level") from a permanent script error.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import patch

import pytest

from docx._http_doc import HttpClient
from docx.commands import Info
from docx.errors import (
    DocxError,
    DocxStudioTemporarilyUnavailable,
    SessionError,
)


class _FakeResponse:
    def __init__(
        self,
        *,
        status_code: int,
        body: bytes | str = b"",
        headers: dict[str, str] | None = None,
    ) -> None:
        self.status_code = status_code
        if isinstance(body, bytes):
            self._body_text = body.decode("utf-8", errors="replace")
        else:
            self._body_text = body
        self.headers = headers or {}

    @property
    def text(self) -> str:
        return self._body_text

    def json(self) -> Any:
        return json.loads(self._body_text)


def _execute_one_query(client: HttpClient) -> None:
    """Drive a single Info query (eager-flush) through the HTTP path
    so the post-retry status branch executes."""
    client.execute_batch("asset_test", [Info()])


@pytest.mark.parametrize("status_code", [502, 503, 504])
def test_5xx_after_retries_raises_typed_transient(status_code: int) -> None:
    """502/503/504 (post-retry) raises DocxStudioTemporarilyUnavailable."""
    client = HttpClient(base_url="https://docx-studio.test", api_key="k")
    nginx_503 = (
        b"<html><head><title>503 Service Temporarily Unavailable</title></head>"
        b"<body><center><h1>503 Service Temporarily Unavailable</h1></center></body></html>"
    )
    fake = _FakeResponse(status_code=status_code, body=nginx_503)
    with patch.object(client._session, "post", return_value=fake):
        with pytest.raises(DocxStudioTemporarilyUnavailable) as excinfo:
            _execute_one_query(client)
    assert excinfo.value.http_status == status_code
    assert excinfo.value.retry_after_seconds is None
    # Must remain a SessionError (and therefore DocxError) for legacy
    # broad-catch sites; only the typed subclass narrows further.
    assert isinstance(excinfo.value, SessionError)
    assert isinstance(excinfo.value, DocxError)


def test_503_with_retry_after_header_surfaces_seconds() -> None:
    """A Retry-After: 30 header is parsed into retry_after_seconds."""
    client = HttpClient(base_url="https://docx-studio.test", api_key="k")
    fake = _FakeResponse(
        status_code=503,
        body=b"upstream cold start",
        headers={"Retry-After": "30"},
    )
    with patch.object(client._session, "post", return_value=fake):
        with pytest.raises(DocxStudioTemporarilyUnavailable) as excinfo:
            _execute_one_query(client)
    assert excinfo.value.http_status == 503
    assert excinfo.value.retry_after_seconds == 30.0


def test_500_does_not_raise_temporarily_unavailable() -> None:
    """500 is NOT in the transient set — it stays as plain DocxError so
    we don't tell agents to retry on a real server-side bug."""
    client = HttpClient(base_url="https://docx-studio.test", api_key="k")
    fake = _FakeResponse(status_code=500, body=b"internal server error")
    with patch.object(client._session, "post", return_value=fake):
        with pytest.raises(DocxError) as excinfo:
            _execute_one_query(client)
    assert not isinstance(excinfo.value, DocxStudioTemporarilyUnavailable)
