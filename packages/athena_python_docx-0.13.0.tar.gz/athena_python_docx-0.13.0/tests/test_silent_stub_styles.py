"""Lock-in tests for the silent-stub warnings on ``Styles`` and ``_LatentStyles``.

Three operations used to be silent no-ops:

1. ``Styles.add_style(...)`` — stored the new style in ``self._added``
   but never persisted to the document.
2. ``Styles.delete_style(name)`` — popped the local entry but never
   persisted (Athena extension; not in upstream python-docx).
3. ``_LatentStyles`` metadata reads (``__getitem__``,
   ``default_priority``, ``default_to_locked``) — silently returned
   empty/None values without signaling that SuperDoc's
   ``DocInfoResult.styles`` doesn't expose latentStyles.

These are now warn-and-no-op. Iteration / ``__len__`` on
``_LatentStyles`` remain warning-free because they're legitimate
empty-collection responses, not silent stubs.

When SuperDoc lands the missing ops, these tests should flip to assert
real wire-bus calls.
"""

from __future__ import annotations

import warnings

import pytest

from docx.enum.style import WD_STYLE_TYPE
from docx.styles.style import BaseStyle
from docx.styles.styles import (
    PendingLatentStylesReadWarning,
    PendingStyleRegistryMutationWarning,
    Styles,
    _LatentStyles,
)


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------


def _make_styles() -> Styles:
    """Construct a ``Styles`` collection without a real session.

    ``add_style`` and ``delete_style`` don't actually call the session,
    so ``session=None`` (cast through the kw-only API) is acceptable
    here. The constructor stashes the value without dereferencing it.
    """
    return Styles(session=None)  # type: ignore[arg-type]


# ---------------------------------------------------------------------
# Styles.add_style / delete_style
# ---------------------------------------------------------------------


def test_add_style_warns_once_and_returns_base_style_shape() -> None:
    styles = _make_styles()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        result = styles.add_style("Custom", WD_STYLE_TYPE.PARAGRAPH)

    pending = [w for w in captured if issubclass(w.category, PendingStyleRegistryMutationWarning)]
    assert len(pending) == 1, f"expected exactly one warning, got {len(pending)}"
    assert "add_style" in str(pending[0].message)
    assert "Custom" in str(pending[0].message)
    assert isinstance(result, BaseStyle)
    assert result.name == "Custom"


def test_delete_style_warns_once() -> None:
    styles = _make_styles()
    # Pre-populate so delete_style has something to pop (still warns
    # even when there is no entry).
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", PendingStyleRegistryMutationWarning)
        styles.add_style("Custom", WD_STYLE_TYPE.PARAGRAPH)

    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        styles.delete_style("Custom")

    pending = [w for w in captured if issubclass(w.category, PendingStyleRegistryMutationWarning)]
    assert len(pending) == 1
    assert "delete_style" in str(pending[0].message)
    assert "Custom" in str(pending[0].message)


def test_delete_style_warns_even_when_name_missing() -> None:
    """Warning should fire regardless of whether the style exists —
    the mutation intent (which is what won't persist) is what we're
    signaling."""
    styles = _make_styles()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        styles.delete_style("Nonexistent")

    pending = [w for w in captured if issubclass(w.category, PendingStyleRegistryMutationWarning)]
    assert len(pending) == 1


def test_registry_warning_message_points_to_superdoc_constraint() -> None:
    """The warning text should name the upstream constraint so users
    understand it's a SuperDoc gap, not an athena bug."""
    styles = _make_styles()
    with pytest.warns(PendingStyleRegistryMutationWarning) as captured:
        styles.add_style("Custom", WD_STYLE_TYPE.PARAGRAPH)
    assert len(captured) == 1
    msg = str(captured[0].message)
    assert "SuperDoc" in msg
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in msg


# ---------------------------------------------------------------------
# _LatentStyles metadata reads
# ---------------------------------------------------------------------


def test_latent_styles_getitem_warns_then_raises_key_error() -> None:
    latent = _LatentStyles()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        with pytest.raises(KeyError):
            latent["anything"]

    pending = [w for w in captured if issubclass(w.category, PendingLatentStylesReadWarning)]
    assert len(pending) == 1
    assert "__getitem__" in str(pending[0].message)


def test_latent_styles_default_priority_warns() -> None:
    latent = _LatentStyles()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        value = latent.default_priority

    pending = [w for w in captured if issubclass(w.category, PendingLatentStylesReadWarning)]
    assert len(pending) == 1
    assert "default_priority" in str(pending[0].message)
    assert value is None


def test_latent_styles_default_to_locked_warns() -> None:
    latent = _LatentStyles()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        value = latent.default_to_locked

    pending = [w for w in captured if issubclass(w.category, PendingLatentStylesReadWarning)]
    assert len(pending) == 1
    assert "default_to_locked" in str(pending[0].message)
    assert value is False


def test_latent_styles_iter_does_not_warn() -> None:
    """Iteration over an empty collection is a legitimate response,
    not a silent stub — should not emit a warning."""
    latent = _LatentStyles()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        items = list(iter(latent))

    pending = [w for w in captured if issubclass(w.category, PendingLatentStylesReadWarning)]
    assert pending == []
    assert items == []


def test_latent_styles_len_does_not_warn() -> None:
    """``len()`` over an empty collection is a legitimate response,
    not a silent stub — should not emit a warning."""
    latent = _LatentStyles()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        length = len(latent)

    pending = [w for w in captured if issubclass(w.category, PendingLatentStylesReadWarning)]
    assert pending == []
    assert length == 0


def test_latent_warning_message_points_to_superdoc_constraint() -> None:
    """The latent-styles warning text should name the upstream
    constraint so users understand it's a SuperDoc gap."""
    latent = _LatentStyles()
    with pytest.warns(PendingLatentStylesReadWarning) as captured:
        _ = latent.default_priority
    assert len(captured) == 1
    msg = str(captured[0].message)
    assert "SuperDoc" in msg
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in msg
