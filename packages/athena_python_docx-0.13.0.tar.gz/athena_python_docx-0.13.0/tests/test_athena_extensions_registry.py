"""Coverage audit for the ``@athena_extension`` marker.

The decorator + walker live in :mod:`docx._athena_extension`. This test
verifies:

1. **Discovery works** — the walker enumerates every marked surface.
2. **Coverage is exhaustive** — every surface documented in
   ``python-sdk/CLAUDE.md`` § "Athena extensions for most-requested
   upstream features" carries the marker. If someone adds a new
   surface without the decorator, this test catches it.
3. **Metadata is well-formed** — every marker carries a non-empty
   ``since`` value, and the ``issue`` reference (when set) follows
   the ``python-docx#<n>`` or ``PR#<n>`` form.
4. **No false positives** — surfaces that are 1:1 with python-docx
   (e.g. ``Paragraph.add_run``, ``Document.add_paragraph``,
   ``Table.cell``) must NOT carry the marker.

If a surface needs to be added/removed from the expected set, update
:data:`_EXPECTED_LOCATIONS` below. Drift between the registry walker
and the expected set is a signal: either the docstring documentation
or the marker is out of date.

Run with::

    uv run pytest tests/test_athena_extensions_registry.py -v
"""

from __future__ import annotations

import re

from docx._athena_extension import (
    ATHENA_EXTENSION_ATTR,
    athena_extension_metadata,
    is_athena_extension,
    iter_athena_extensions,
)


# Every surface listed here MUST be discovered by ``iter_athena_extensions``
# AND match the documentation in ``python-sdk/CLAUDE.md`` § "Athena
# extensions for most-requested upstream features (v0.11.0+)". If you add
# a surface, document it in CLAUDE.md and add it here.
_EXPECTED_LOCATIONS: set[str] = {
    # Module-level markers — entire module is an Athena extension.
    "docx.bookmarks",
    "docx.charts",
    "docx.fields",
    "docx.footnotes",
    "docx.math",
    "docx.revisions",
    "docx.sdt",
    "docx.toc",
    # Classes.
    "docx.bookmarks.Bookmark",
    "docx.bookmarks.Bookmarks",
    "docx.charts.Chart",
    "docx.charts.Charts",
    "docx.fields.Field",
    "docx.fields.Fields",
    "docx.footnotes.Footnote",
    "docx.footnotes.Footnotes",
    "docx.footnotes.Endnote",
    "docx.footnotes.Endnotes",
    "docx.math.MathEquation",
    "docx.revisions.Revision",
    "docx.revisions.Revisions",
    "docx.sdt.ContentControl",
    "docx.sdt.ContentControls",
    "docx.toc.TableOfContents",
    # Document methods / properties (Athena-only).
    "docx.document.Document.create",
    "docx.document.Document.asset_id",
    "docx.document.Document.track_revisions",
    "docx.document.Document.tracked_revisions",
    "docx.document.Document.user_name",
    "docx.document.Document.user_email",
    "docx.document.Document.revisions",
    "docx.document.Document.bookmarks",
    "docx.document.Document.footnotes",
    "docx.document.Document.endnotes",
    "docx.document.Document.fields",
    "docx.document.Document.charts",
    "docx.document.Document.content_controls",
    "docx.document.Document.add_toc",
    "docx.document.Document.add_chart",
    "docx.document.Document.add_watermark",
    "docx.document.Document.add_content_control",
    "docx.document.Document.find_replace",
    "docx.document.Document.to_pdf",
    "docx.document.Document.export_docx",
    "docx.document.Document.add_bookmark",
    # Paragraph methods / properties.
    "docx.text.paragraph.Paragraph.add_hyperlink",
    "docx.text.paragraph.Paragraph.add_bookmark",
    "docx.text.paragraph.Paragraph.add_caption",
    "docx.text.paragraph.Paragraph.list_id",
    "docx.text.paragraph.Paragraph.list_level",
    "docx.text.paragraph.Paragraph.list_format",
    "docx.text.paragraph.Paragraph.list_number",
    # Run methods.
    "docx.text.run.Run.add_field",
    "docx.text.run.Run.add_footnote",
    "docx.text.run.Run.add_endnote",
    "docx.text.run.Run.add_cross_reference",
    "docx.text.run.Run.add_math",
    "docx.text.run.Run.add_hyperlink",
    # InlineShape / Picture properties + methods.
    "docx.shape.InlineShape.alt_text",
    "docx.shape.InlineShape.title",
    "docx.shape.InlineShape.decorative",
    "docx.shape.InlineShape.anchor",
    "docx.shape.Picture.ext",
    "docx.shape.Picture.alt_text",
    "docx.shape.Picture.title",
    "docx.shape.Picture.decorative",
    # Section column-layout surface.
    "docx.section.Section.column_count",
    "docx.section.Section.column_widths",
    "docx.section.Section.set_columns",
    # Table / _Cell additions.
    "docx.table.Table.set_borders",
    "docx.table._Cell.v_merge",
    "docx.table._Cell.is_merge_continuation",
    "docx.table._Cell.is_merge_origin",
    "docx.table._Cell.set_borders",
    "docx.table._Cell.borders",
    "docx.table._Cell.set_shading",
    "docx.table._Cell.shading",
}


def _all_records() -> list[dict]:
    return list(iter_athena_extensions("docx"))


def _location_set() -> set[str]:
    return {r["location"] for r in _all_records()}


def test_registry_walker_finds_marked_surfaces() -> None:
    """The walker must enumerate non-trivially. If this fails, the
    walker is broken or NO surface carries the marker."""
    records = _all_records()
    assert len(records) > 50, (
        f"Athena-extension registry walker returned {len(records)} "
        f"records; expected >50. Either the walker is broken or the "
        f"markers were stripped from the codebase."
    )


def test_every_expected_location_is_marked() -> None:
    """Every surface in :data:`_EXPECTED_LOCATIONS` must be discovered
    by the walker. Drift here means a documented Athena extension is
    missing its ``@athena_extension`` decorator."""
    actual = _location_set()
    missing = _EXPECTED_LOCATIONS - actual
    assert not missing, (
        "These surfaces are documented in CLAUDE.md § 'Athena extensions "
        "for most-requested upstream features' but are MISSING the "
        "@athena_extension marker:\n  " + "\n  ".join(sorted(missing)),
    )


def test_no_unexpected_marked_surfaces() -> None:
    """Inverse check: anything carrying the marker that ISN'T in the
    expected set is either undocumented or a bug. Update
    :data:`_EXPECTED_LOCATIONS` (and CLAUDE.md) when adding new
    extensions.

    Allowlist: per-command bulk-marked dataclasses (``docx.commands.*``)
    are stamped programmatically in ``docx/commands.py`` and don't need
    individual expected-set entries — there are 40+ of them and the bulk
    stamping is itself a single piece of code to review. Walker filter
    below excludes that namespace.
    """
    actual = _location_set()
    # Filter out the bulk-marked commands and known-marked private
    # types like _NoteBase that show up via class introspection but are
    # internal helpers.
    extra = {
        loc
        for loc in actual
        if not loc.startswith("docx.commands.")
        and not loc.endswith("._NoteBase")
        and not loc.endswith("._NotesCollection")
        and loc not in _EXPECTED_LOCATIONS
    }
    assert not extra, (
        "These surfaces carry @athena_extension but aren't in the "
        "expected set:\n  " + "\n  ".join(sorted(extra)) + "\n\n"
        "Either:\n"
        "  (a) document the extension in python-sdk/CLAUDE.md § "
        "'Athena extensions for most-requested upstream features' and "
        "add the location to _EXPECTED_LOCATIONS here, OR\n"
        "  (b) remove the @athena_extension decorator if the surface "
        "actually has python-docx upstream parity."
    )


_VALID_ISSUE_PATTERN = re.compile(r"^(python-docx#\d+|PR#\d+|python-openxml/.*#\d+)$")


def test_marker_metadata_is_well_formed() -> None:
    """Every marker's metadata must:
    - carry a non-empty ``since`` string
    - either have ``issue=None`` or match ``python-docx#<n>`` /
      ``PR#<n>`` form
    - either have an empty description or one short enough to fit on
      a docstring marker line (<160 chars).
    """
    for record in _all_records():
        loc = record["location"]
        since = record.get("since")
        issue = record.get("issue")
        description = record.get("description", "")
        assert isinstance(since, str) and since, f"{loc}: missing or empty `since` value"
        if issue is not None:
            assert _VALID_ISSUE_PATTERN.match(issue), (
                f"{loc}: issue={issue!r} doesn't match python-docx#<n> "
                f"or PR#<n> form"
            )
        assert len(description) < 160, (
            f"{loc}: description longer than 160 chars; trim to a "
            f"one-line summary."
        )


def test_no_false_positives_on_python_docx_parity_surfaces() -> None:
    """1:1 python-docx parity surfaces must NOT carry the marker.

    If this fails, someone marked an upstream-parity surface as
    Athena-extension — the SDK's parity contract is broken.
    """
    from docx.document import Document
    from docx.table import Table, _Cell
    from docx.text.paragraph import Paragraph
    from docx.text.run import Run

    # A representative spread of upstream-parity methods. Each one
    # exists 1:1 in python-docx 1.x and must not be marked.
    parity_surfaces = [
        Document.add_paragraph,
        Document.add_heading,
        Document.add_table,
        Document.add_picture,
        Document.add_page_break,
        Paragraph.add_run,
        Paragraph.insert_paragraph_before,
        Run.add_break,
        Run.add_text,
        Run.add_picture,
        Run.add_tab,
        Table.add_column,
        Table.cell,
        _Cell.merge,
    ]
    falsely_marked = [
        m
        for m in parity_surfaces
        if getattr(m, ATHENA_EXTENSION_ATTR, False)
    ]
    assert not falsely_marked, (
        "These python-docx upstream-parity surfaces are incorrectly "
        f"marked as Athena extensions: {falsely_marked!r}. Remove the "
        "@athena_extension decorator — they have 1:1 upstream parity."
    )


def test_is_athena_extension_helper() -> None:
    """``is_athena_extension`` must correctly identify both function
    markers AND property-wrapped markers (read from ``prop.fget`` /
    ``prop.fset``)."""
    from docx.bookmarks import Bookmark
    from docx.document import Document
    from docx.text.paragraph import Paragraph

    # Class with marker.
    assert is_athena_extension(Bookmark)
    # Method with marker.
    assert is_athena_extension(Paragraph.add_hyperlink)
    # Property with marker on fget.
    bookmarks_prop = Document.__dict__.get("bookmarks")
    assert bookmarks_prop is not None
    assert is_athena_extension(bookmarks_prop)
    # Plain upstream-parity method — must NOT be flagged.
    assert not is_athena_extension(Paragraph.add_run)


def test_metadata_lookup_returns_issue_and_description() -> None:
    """``athena_extension_metadata`` should pull back the recorded
    metadata for a marked surface."""
    from docx.text.paragraph import Paragraph

    meta = athena_extension_metadata(Paragraph.add_hyperlink)
    assert meta is not None
    assert meta["issue"] == "python-docx#74"
    assert "hyperlink" in (meta["description"] or "").lower()
    assert meta["since"]
