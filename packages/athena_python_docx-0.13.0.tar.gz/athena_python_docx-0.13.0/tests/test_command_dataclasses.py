"""Tests for the typed Command dataclasses + serializer.

Locks the wire-format contract that ``apps/api/src/commands/types.ts``
expects: ``type`` discriminator (PascalCase class name) plus camelCase
field names, with ``None``-valued fields dropped.
"""

from __future__ import annotations

import pytest

from docx.commands import (
    BlocksList,
    Command,
    CreateParagraph,
    Find,
    FormatApply,
    Insert,
    SetSectionPageMargins,
    TablesInsertRow,
    is_query,
    is_response_bearing,
    must_flush_immediately,
)


def test_to_dict_includes_type_discriminator() -> None:
    cmd = CreateParagraph(text="hello", at={"kind": "documentEnd"})
    d = cmd.to_dict()
    assert d["type"] == "CreateParagraph"


def test_to_dict_camelcases_fields() -> None:
    cmd = TablesInsertRow(
        node_id="t1",
        row_index=2,
        position="below",
        count=1,
    )
    d = cmd.to_dict()
    assert d == {
        "type": "TablesInsertRow",
        "nodeId": "t1",
        "rowIndex": 2,
        "position": "below",
        "count": 1,
    }


def test_to_dict_drops_none_optional_fields() -> None:
    """Server applies schema defaults; sending ``null`` would override them."""
    cmd = SetSectionPageMargins(
        target={"kind": "section", "sectionId": "s1"},
        left=72.0,
        # right/top/bottom/gutter all None
    )
    d = cmd.to_dict()
    assert d == {
        "type": "SetSectionPageMargins",
        "target": {"kind": "section", "sectionId": "s1"},
        "left": 72.0,
    }


def test_to_dict_preserves_dict_leaves_verbatim() -> None:
    """Anchor / target / inline shapes pass through untouched.

    The server treats them as ``passthrough()`` — no key renaming.
    """
    target = {"kind": "block", "nodeType": "paragraph", "nodeId": "p1"}
    inline = {"bold": True, "fontSize": 14, "rStyle": "MyRun"}
    cmd = FormatApply(target=target, inline=inline)
    d = cmd.to_dict()
    assert d["target"] is target
    assert d["inline"] is inline


def test_query_classes_are_classified_as_queries() -> None:
    assert is_query(BlocksList())
    assert is_query(Find(node_type="table"))
    assert not is_query(CreateParagraph(text="", at={"kind": "documentEnd"}))


def test_creates_are_response_bearing() -> None:
    assert is_response_bearing(
        CreateParagraph(text="x", at={"kind": "documentEnd"}),
    )


def test_insert_is_not_response_bearing_post_0_8_0() -> None:
    """``Insert`` was removed from the response-bearing set in 0.8.0
    so ``Paragraph.add_run`` text-inserts ride the same HTTP batch as
    the format setters that follow them. See
    ``tests/test_insert_deferred.py`` for the wire-level pin and
    ``docx-studio/PERFORMANCE_BATCHING_ANALYSIS.md`` for the rationale.
    """
    assert not is_response_bearing(Insert(target={"kind": "documentEnd"}))


def test_must_flush_unions_query_and_response_bearing() -> None:
    # Query: must flush
    assert must_flush_immediately(BlocksList())
    # Response-bearing: must flush
    assert must_flush_immediately(
        CreateParagraph(text="x", at={"kind": "documentEnd"}),
    )
    # Pure mutation: may buffer
    assert not must_flush_immediately(
        FormatApply(target={"kind": "block"}, inline={"bold": True}),
    )


def test_each_concrete_subclass_emits_its_classname_as_type() -> None:
    """Belt-and-braces: every Command subclass uses class name as type."""
    # Sample a few across the file
    samples: list[Command] = [
        BlocksList(),
        Find(node_type="paragraph"),
        TablesInsertRow(node_id="t", row_index=0, position="above"),
    ]
    for s in samples:
        assert s.to_dict()["type"] == type(s).__name__


def test_every_sdk_call_site_op_has_a_command_class() -> None:
    """Audit the _OP_TO_COMMAND lookup in _http_doc.py against the set of
    ops the SDK actually invokes. Catches Phase-1-style regressions where
    a new op is added to the SDK but not registered in the typed bus.
    """
    import re
    from pathlib import Path

    from docx._http_doc import _OP_TO_COMMAND

    sdk_root = Path(__file__).resolve().parents[1] / "docx"
    pat = re.compile(r"_session\.doc\.([a-zA-Z_.]+)\(")
    found: set[str] = set()
    for f in sdk_root.rglob("*.py"):
        for m in pat.finditer(f.read_text()):
            op = m.group(1)
            # Strip trailing _ that could come from `range_=` etc.
            op = op.rstrip("_")
            found.add(op)
    missing = sorted(found - set(_OP_TO_COMMAND.keys()))
    assert not missing, f"SDK invokes ops with no Command class: {missing}"


def test_invalid_dataclass_construction_raises_typeerror() -> None:
    """Required fields are required; the path proxy relies on this so a
    missing key fails fast with a clear error rather than silently sending
    a malformed body."""
    with pytest.raises(TypeError):
        CreateParagraph(text="x")  # type: ignore[call-arg]
