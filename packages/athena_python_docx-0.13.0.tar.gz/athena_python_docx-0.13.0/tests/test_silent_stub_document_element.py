"""Tests pinning Document.element / Document.part silent-stub behavior.

python-docx upstream surfaces both as lxml-element / OPC-part proxies.
The athena-python-docx SDK is HTTP-only and doesn't expose lxml or
package parts, so both must raise ``AttributeError`` instead of
silently returning ``None`` — callers should fail loudly rather than
crash on ``NoneType.append`` further downstream.

See ``python-sdk/CLAUDE.md`` § 'Intentionally omitted'.
"""

from __future__ import annotations

import pytest

from docx.document import Document


def test_document_element_raises_attribute_error() -> None:
    """``Document.element`` raises ``AttributeError`` rather than
    silently returning ``None``. ``Document.element`` doesn't call
    ``_ensure_open()``, so this works without a real session — we can
    construct a ``Document`` with bare-minimum args and access the
    property directly.
    """
    doc = Document(asset_id="test")
    with pytest.raises(AttributeError, match="Document.element"):
        _ = doc.element


def test_document_part_raises_attribute_error() -> None:
    """``Document.part`` raises ``AttributeError`` rather than aliasing
    ``element``. Previously ``part = element`` captured the property
    object so the two surfaces shared a return value; now both are
    distinct properties that each raise with their own message.
    """
    doc = Document(asset_id="test")
    with pytest.raises(AttributeError, match="Document.part"):
        _ = doc.part
