"""Regression test for the ``Document.asset_id`` public property.

Without this property, agents that follow the docx executor readable
fail with ``AttributeError: 'Document' object has no attribute
'_asset_id'``. The readable tells the agent to do
``print(doc.asset_id)`` after ``Document.create(...)`` so the next
tool call can reopen the same asset; the failure mode is brittle and
silent (the agent runs out of retries instead of recovering).

Mirrors the parallel public id accessors on the other studios:
- ``Workbook.workbook_id`` (xlsx)
- ``Presentation.deck_id`` (pptx)
"""

from __future__ import annotations

from typing import Any
from unittest.mock import patch

from docx.document import Document as _Document


def test_document_asset_id_returns_session_asset_id() -> None:
    """``doc.asset_id`` must round-trip the value passed at construction."""
    with patch("docx.document.Session") as MockSession:
        instance: Any = MockSession.return_value
        instance.asset_id = "asset_3a9328bc-9c1c-4498-be8f-bda3883276f5"
        doc = _Document(asset_id="asset_3a9328bc-9c1c-4498-be8f-bda3883276f5")
        assert doc.asset_id == "asset_3a9328bc-9c1c-4498-be8f-bda3883276f5"


def test_document_asset_id_is_read_only() -> None:
    """The property should be read-only — assigning to it should not
    silently mutate the underlying session state (would mask bugs)."""
    with patch("docx.document.Session") as MockSession:
        instance: Any = MockSession.return_value
        instance.asset_id = "asset_abc"
        doc = _Document(asset_id="asset_abc")

        # ``doc.asset_id = "asset_xyz"`` should raise AttributeError since
        # we declared it via ``@property`` with no setter.
        try:
            doc.asset_id = "asset_xyz"  # type: ignore[misc]
        except AttributeError:
            return
        # If we got here, assignment silently succeeded — that's the bug.
        msg = (
            "Document.asset_id silently accepted assignment — the property "
            "must be read-only so accidental mutation of the bound asset "
            "raises loudly."
        )
        raise AssertionError(msg)
