"""Pinning test for ``_Cell.add_table`` raising
:class:`NestedTableNotSupportedError`.

SuperDoc 1.8.1 has no addressable shape for "create new table inside
this cell" — ``create.table`` rejects a cell-inner paragraph anchor
with ``INVALID_TARGET - Expected paragraph:<id> but found
tableCell:<id>``, and the ``doc.insert``-based workaround used by
``_Cell.add_paragraph`` (paragraph fragment + ``placement: insideEnd``)
has no analog for table content fragments wired through the
docx-studio command bus. So ``_Cell.add_table`` raises a typed
``NestedTableNotSupportedError`` rather than silently corrupting the
document (the pre-0.11.2 implementation either failed with the
cryptic INVALID_TARGET when the cell had content or silently wrote
the table to documentEnd when the cell was empty).

Tracked at ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 13.
"""

from __future__ import annotations

from typing import Any

import pytest

from docx.errors import NestedTableNotSupportedError, ValidationError


def _make_cell(mock_session: Any, fake_sd_methods: Any) -> Any:
    from docx.table import Table, _Cell

    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [
            {
                "nodeId": "cell-auto-x1",
                "rowIndex": 0,
                "columnIndex": 0,
                "text": "",
            },
        ],
    }
    table = Table(session=mock_session, node_id="tbl-1")
    return _Cell(table=table, row=0, col=0)


def test_cell_add_table_raises_nested_table_not_supported(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    cell = _make_cell(mock_session, fake_sd_methods)
    with pytest.raises(NestedTableNotSupportedError) as exc_info:
        cell.add_table(2, 2)
    msg = str(exc_info.value)
    assert "SUPERDOC_UPSTREAM_REQUESTS.md § 13" in msg
    assert "Document.add_table" in msg


def test_cell_add_table_still_validates_dimensions_first(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``ValidationError`` for bad dimensions must still fire BEFORE the
    NotImplementedError. Lets agents catch the more specific error
    type without first reasoning about why the method is unsupported.
    """
    cell = _make_cell(mock_session, fake_sd_methods)
    with pytest.raises(ValidationError, match="rows/cols"):
        cell.add_table(0, 2)
    with pytest.raises(ValidationError, match="rows/cols"):
        cell.add_table(2, 0)


def test_nested_table_error_is_a_notimplementederror(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``NestedTableNotSupportedError`` subclasses ``NotImplementedError``
    so generic ``except NotImplementedError`` (a common pattern) catches
    it without needing to import the typed class.
    """
    cell = _make_cell(mock_session, fake_sd_methods)
    with pytest.raises(NotImplementedError):
        cell.add_table(2, 2)
