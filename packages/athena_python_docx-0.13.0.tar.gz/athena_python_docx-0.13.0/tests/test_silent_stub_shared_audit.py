"""Lock-in tests for silent stubs / partial implementations in docx/shared.py.

Each test pins behavior against verified python-docx 1.2.0 upstream output.
See conversation audit notes for the specific upstream commands run.
"""

from __future__ import annotations

import pytest

from docx.shared import Inches, Length, RGBColor


class TestLengthEmuReturnType:
    """`Length.emu` must return the Length itself (subtype-preserving), not a plain int.

    Upstream: `return self`. Subtype is preserved so chained accessors (.inches,
    .pt) keep working on the result.
    """

    def test_emu_returns_length_instance(self) -> None:
        L = Length(914400)
        assert isinstance(L.emu, Length)

    def test_emu_returns_self_identity(self) -> None:
        length = Length(914400)
        assert length.emu is length

    def test_inches_emu_preserves_subtype(self) -> None:
        # The result of .emu must still expose Length accessors.
        one_inch = Inches(1)
        assert isinstance(one_inch.emu, Length)
        # Chained accessor on .emu still works.
        assert one_inch.emu.inches == 1.0


class TestLengthTwipsBankersRounding:
    """`Length.twips` must use banker's rounding (`int(round(self / 635))`), not
    floor-division (`self // 635`).

    Verified against upstream python-docx 1.2.0:
      emu=318 -> twips=1 (upstream)   floor would give 0
      emu=953 -> twips=2 (upstream)   floor would give 1
    """

    @pytest.mark.parametrize(
        ("emu", "expected"),
        [
            (0, 0),
            (317, 0),  # below half: rounds down
            (318, 1),  # at half: rounds up (banker's still rounds to even in some
            # cases, but 0.5009... rounds up)
            (634, 1),
            (635, 1),
            (952, 1),
            (953, 2),
            (1269, 2),
            (1270, 2),
        ],
    )
    def test_twips_matches_upstream_rounding(self, emu: int, expected: int) -> None:
        assert Length(emu).twips == expected

    def test_twips_returns_int(self) -> None:
        assert isinstance(Length(914400).twips, int)


class TestRGBColorTypeValidation:
    """`RGBColor(r, g, b)` must raise TypeError on non-int args, before range check.

    Upstream message: "RGBColor() takes three integer values 0-255"
    Athena previously accepted floats silently (the range check `0 <= v <= 255` is
    True for floats), then crashed later in `__str__` with a confusing format error.
    """

    def test_float_raises_type_error(self) -> None:
        with pytest.raises(TypeError, match="RGBColor"):
            RGBColor(1.5, 2, 3)

    def test_float_raises_type_error_other_position(self) -> None:
        with pytest.raises(TypeError, match="RGBColor"):
            RGBColor(0, 0.5, 0)

    def test_string_raises_type_error(self) -> None:
        # Upstream: TypeError. (Athena previously also rejected, but verify.)
        with pytest.raises(TypeError):
            RGBColor("ff", "00", "00")  # type: ignore[arg-type]

    def test_out_of_range_still_value_error(self) -> None:
        # Range check still applies after the type check.
        with pytest.raises(ValueError):
            RGBColor(256, 0, 0)
        with pytest.raises(ValueError):
            RGBColor(-1, 0, 0)

    def test_valid_int_still_works(self) -> None:
        c = RGBColor(0x3C, 0x2F, 0x80)
        assert str(c) == "3C2F80"
        assert c == (0x3C, 0x2F, 0x80)

    def test_bool_accepted_parity(self) -> None:
        # bool is a subclass of int, so upstream's `isinstance(val, int)` accepts
        # True/False. We mirror upstream behavior — `True` becomes 0x01.
        c = RGBColor(True, False, False)  # type: ignore[arg-type]
        assert str(c) == "010000"
