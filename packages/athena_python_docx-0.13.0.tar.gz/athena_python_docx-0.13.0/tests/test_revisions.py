"""Track-changes (revisions) behavioral tests.

Verifies that the Athena-extension surface — ``Document.track_revisions``,
``Document.user_name``/``user_email``, ``Document.tracked_revisions()``,
and ``Document.revisions`` — translates to the right SuperDoc
``doc.trackChanges.*`` ops, and that the buffer's envelope-level
``changeMode`` / ``user`` propagation lands on the wire.

The test surface mirrors ``test_comments.py`` (the closest precedent
since both are Athena extensions wired through the typed command bus).
"""

from __future__ import annotations

import threading
from datetime import datetime, timezone
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from docx._buffer import CommandBuffer
from docx.commands import (
    Command,
    CreateParagraph,
    FormatApply,
    Replace,
    TrackChangesDecide,
    TrackChangesGet,
    TrackChangesList,
)
from docx.errors import ValidationError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _find_call(calls: list[tuple[str, Any]], op_name: str) -> tuple[str, Any] | None:
    for call in calls:
        if call[0] == op_name:
            return call
    return None


def _all_calls(
    calls: list[tuple[str, Any]], op_name: str
) -> list[tuple[str, Any]]:
    return [c for c in calls if c[0] == op_name]


def _make_doc(mock_session: Any):
    """Construct a Document bypassing the asset-creation HTTP call."""
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False
    doc._pending_user_name = None
    doc._pending_user_email = None
    doc._pending_track_revisions = False
    return doc


class _FakeClient:
    """Records every batch handed to ``execute_batch``, including the
    envelope-level ``changeMode`` / ``user`` fields. Tests assert
    against the recorded envelopes to confirm propagation."""

    def __init__(self) -> None:
        self.batches: list[list[Command]] = []
        self.envelopes: list[dict[str, Any]] = []
        self._lock = threading.Lock()

    def execute_batch(
        self,
        asset_id: str,  # noqa: ARG002
        commands: list[Command],
        *,
        change_mode: str | None = None,
        user: dict[str, str] | None = None,
    ) -> list[Any]:
        with self._lock:
            self.batches.append(list(commands))
            self.envelopes.append(
                {"changeMode": change_mode, "user": user},
            )
        return [{"index": i, "ok": True} for i, _ in enumerate(commands)]


# ---------------------------------------------------------------------------
# Wire dataclass tests — TrackChangesList / Get / Decide
# ---------------------------------------------------------------------------


def test_track_changes_list_serializes_with_pascal_discriminator() -> None:
    """``TrackChangesList`` serializes ``type: "TrackChangesList"`` and
    drops ``None`` optional fields. The Python-side field name is
    ``change_type`` (renamed from wire ``type`` to avoid colliding with
    our discriminator); ``_snake_to_camel`` produces ``changeType`` on
    the wire."""
    cmd = TrackChangesList(change_type="insert", limit=10)
    d = cmd.to_dict()
    assert d == {
        "type": "TrackChangesList",
        "changeType": "insert",
        "limit": 10,
    }


def test_track_changes_list_in_field_round_trips_keyword_collision() -> None:
    """The ``in`` keyword collision: dataclass field is ``in_`` (trailing
    underscore), wire serializes back to ``in``. Same trick used by
    create.* ops."""
    cmd = TrackChangesList(in_={"kind": "story", "storyType": "body"})
    d = cmd.to_dict()
    assert "in" in d
    assert "in_" not in d
    assert d["in"] == {"kind": "story", "storyType": "body"}


def test_track_changes_get_serializes_id_and_optional_story() -> None:
    cmd = TrackChangesGet(
        id="tc-7", story={"kind": "story", "storyType": "body"}
    )
    d = cmd.to_dict()
    assert d == {
        "type": "TrackChangesGet",
        "id": "tc-7",
        "story": {"kind": "story", "storyType": "body"},
    }


def test_track_changes_decide_default_target_is_emptydict() -> None:
    """Default-factory ``target=dict()`` matches python-docx's pattern
    of "give me a fresh empty dict on each construction"."""
    a = TrackChangesDecide(decision="accept", target={"id": "tc-1"})
    b = TrackChangesDecide(decision="accept", target={"id": "tc-2"})
    a.target["mutated"] = True
    assert "mutated" not in b.target


def test_track_changes_decide_accept_per_change() -> None:
    cmd = TrackChangesDecide(
        decision="accept", target={"id": "tc-7"}
    )
    d = cmd.to_dict()
    assert d == {
        "type": "TrackChangesDecide",
        "decision": "accept",
        "target": {"id": "tc-7"},
    }


def test_track_changes_decide_reject_all() -> None:
    cmd = TrackChangesDecide(
        decision="reject", target={"scope": "all"}
    )
    d = cmd.to_dict()
    assert d == {
        "type": "TrackChangesDecide",
        "decision": "reject",
        "target": {"scope": "all"},
    }


def test_track_changes_decide_carries_per_call_change_mode() -> None:
    """Per-call ``change_mode`` overrides the batch-level mode for
    accept/reject — useful when the SDK is in tracked mode globally
    but the user wants the decide itself to land directly."""
    cmd = TrackChangesDecide(
        decision="accept",
        target={"id": "tc-1"},
        change_mode="direct",
        force=True,
        expected_revision=42,
    )
    d = cmd.to_dict()
    assert d["changeMode"] == "direct"
    assert d["force"] is True
    assert d["expectedRevision"] == 42


def test_track_changes_classify_list_get_as_query_decide_as_response_bearing() -> None:
    """Read-only ops must be classified as queries (must flush);
    Decide is a mutation that returns the affected entities and
    therefore must flush immediately too."""
    from docx.commands import (
        is_query,
        is_response_bearing,
        must_flush_immediately,
    )

    assert is_query(TrackChangesList())
    assert is_query(TrackChangesGet(id="tc-1"))
    assert not is_query(TrackChangesDecide(decision="accept", target={"id": "x"}))

    assert is_response_bearing(
        TrackChangesDecide(decision="accept", target={"id": "x"})
    )
    assert not is_response_bearing(TrackChangesList())

    # Must-flush union: queries + response-bearing.
    assert must_flush_immediately(TrackChangesList())
    assert must_flush_immediately(
        TrackChangesDecide(decision="accept", target={"id": "x"})
    )


# ---------------------------------------------------------------------------
# Path-proxy → Command translation
# ---------------------------------------------------------------------------


def test_path_proxy_routes_track_changes_list() -> None:
    """``track_changes.list`` resolves to ``TrackChangesList`` in the
    op-to-command lookup, with the ``type`` → ``change_type`` rename
    applied so SuperDoc-shaped fixtures round-trip cleanly."""
    from docx._http_doc import _OP_TO_COMMAND, _build_command

    assert _OP_TO_COMMAND["track_changes.list"] is TrackChangesList
    assert _OP_TO_COMMAND["track_changes.get"] is TrackChangesGet
    assert _OP_TO_COMMAND["track_changes.decide"] is TrackChangesDecide

    # Path-proxy receives camelCase wire fields; the rename map handles
    # the `type` → `change_type` mapping for `track_changes.list`.
    cmd = _build_command(
        "track_changes.list",
        {"type": "insert", "limit": 25},
    )
    assert isinstance(cmd, TrackChangesList)
    assert cmd.change_type == "insert"
    assert cmd.limit == 25


def test_path_proxy_track_changes_decide_round_trip() -> None:
    from docx._http_doc import _build_command

    cmd = _build_command(
        "track_changes.decide",
        {"decision": "accept", "target": {"id": "tc-1"}},
    )
    assert isinstance(cmd, TrackChangesDecide)
    assert cmd.decision == "accept"
    assert cmd.target == {"id": "tc-1"}


# ---------------------------------------------------------------------------
# Buffer-level changeMode / user propagation
# ---------------------------------------------------------------------------


def test_buffer_set_change_mode_validates_value() -> None:
    """Only 'direct', 'tracked', or None are valid. Pre-validating at
    the buffer is the cheapest place to catch typos before they hit
    SuperDoc."""
    buf = CommandBuffer(_FakeClient(), "asset_x", auto_flush_seconds=0.0)
    buf.set_change_mode("tracked")
    assert buf.change_mode == "tracked"
    buf.set_change_mode("direct")
    assert buf.change_mode == "direct"
    buf.set_change_mode(None)
    assert buf.change_mode is None
    with pytest.raises(ValueError, match="change_mode"):
        buf.set_change_mode("typo")
    buf.close()


def test_buffer_set_change_mode_flushes_pending_first() -> None:
    """Switching modes must flush prior pending ops *under the old mode*
    so semantics don't retro-actively change. Otherwise a race between
    ``track_revisions=True`` and an in-flight buffered ``FormatApply``
    would silently re-tag the format as tracked."""
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_x", auto_flush_seconds=0.0)

    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    assert buf.pending_count == 1

    # Switch mode — should flush the pending FormatApply with mode=None.
    buf.set_change_mode("tracked")
    assert buf.pending_count == 0
    assert len(fake.batches) == 1
    assert fake.envelopes[0]["changeMode"] is None  # OLD mode

    # Subsequent ops land in a new batch under the new mode.
    buf.call(Replace(target={"kind": "selection"}, text="hi"))
    buf.flush()
    assert len(fake.batches) == 2
    assert fake.envelopes[1]["changeMode"] == "tracked"  # NEW mode

    buf.close()


def test_buffer_set_change_mode_idempotent_when_unchanged() -> None:
    """Setting the same mode is a no-op — no flush, no extra batch.
    Otherwise a tight ``track_revisions=True`` re-assignment would
    fragment the buffer."""
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_x", auto_flush_seconds=0.0)
    buf.set_change_mode("tracked")
    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    buf.set_change_mode("tracked")  # no-op
    assert buf.pending_count == 1  # not flushed
    buf.flush()
    assert len(fake.batches) == 1
    assert fake.envelopes[0]["changeMode"] == "tracked"
    buf.close()


def test_buffer_set_user_lands_on_envelope() -> None:
    """The user identity is sent on every batch — SuperDoc honors it
    only at session-open, but we always include it so a freshly-opened
    pool entry picks it up."""
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_x", auto_flush_seconds=0.0)
    buf.set_user("Alice", "alice@example.com")
    assert buf.user == {"name": "Alice", "email": "alice@example.com"}
    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    buf.flush()
    assert fake.envelopes[0]["user"] == {
        "name": "Alice",
        "email": "alice@example.com",
    }
    buf.close()


def test_buffer_set_user_email_optional() -> None:
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_x", auto_flush_seconds=0.0)
    buf.set_user("Bob")
    assert buf.user == {"name": "Bob"}
    # email omitted entirely — SuperDoc doesn't require it.
    buf.set_user(None)
    assert buf.user is None
    buf.close()


def test_buffer_set_user_rejects_empty_name() -> None:
    """Empty-string names are pre-validated — passing one would have
    SuperDoc record changes under the empty-string author, which is
    silently confusing in the UI."""
    buf = CommandBuffer(_FakeClient(), "asset_x", auto_flush_seconds=0.0)
    with pytest.raises(ValueError, match="non-empty"):
        buf.set_user("")
    buf.close()


def test_buffer_change_mode_persists_across_eager_flushes() -> None:
    """The ``_eager_flush_with`` path (used by queries / creates) must
    also include the envelope-level ``changeMode`` so a single
    ``CreateParagraph`` under track-changes mode lands on SuperDoc as
    a tracked insert."""
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_x", auto_flush_seconds=0.0)
    buf.set_change_mode("tracked")
    buf.call(CreateParagraph(text="hi", at={"kind": "documentEnd"}))
    # CreateParagraph is response-bearing → flushes immediately.
    assert len(fake.batches) == 1
    assert fake.envelopes[0]["changeMode"] == "tracked"
    buf.close()


def test_buffer_user_persists_across_eager_flushes() -> None:
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_x", auto_flush_seconds=0.0)
    buf.set_user("Charlie", "charlie@example.com")
    buf.call(CreateParagraph(text="x", at={"kind": "documentEnd"}))
    assert fake.envelopes[0]["user"] == {
        "name": "Charlie",
        "email": "charlie@example.com",
    }
    buf.close()


# ---------------------------------------------------------------------------
# Document — track_revisions, user_name/email, context manager
# ---------------------------------------------------------------------------


def test_document_track_revisions_default_false(mock_session: Any) -> None:
    doc = _make_doc(mock_session)
    assert doc.track_revisions is False
    assert doc.user_name is None
    assert doc.user_email is None


def test_document_track_revisions_setter_accepts_bool(
    mock_session: Any,
) -> None:
    """Toggling reflects on read; the value coerces to ``bool`` so
    truthy non-bools (``1``, ``"yes"``) work without surprise."""
    doc = _make_doc(mock_session)
    doc.track_revisions = True
    assert doc.track_revisions is True
    doc.track_revisions = False
    assert doc.track_revisions is False
    doc.track_revisions = 1  # type: ignore[assignment]
    assert doc.track_revisions is True


def test_document_user_name_setter_validates_type(mock_session: Any) -> None:
    """Non-string values raise rather than silently round-tripping
    through ``str(...)`` — the upstream SuperDoc field is typed
    ``string`` and we want to catch coercion bugs at the boundary."""
    doc = _make_doc(mock_session)
    doc.user_name = "Alice"
    assert doc.user_name == "Alice"
    doc.user_name = None
    assert doc.user_name is None
    with pytest.raises(ValidationError, match="user_name"):
        doc.user_name = 123  # type: ignore[assignment]


def test_document_user_email_setter_validates_type(mock_session: Any) -> None:
    doc = _make_doc(mock_session)
    doc.user_email = "alice@example.com"
    assert doc.user_email == "alice@example.com"
    with pytest.raises(ValidationError, match="user_email"):
        doc.user_email = []  # type: ignore[assignment]


def test_document_tracked_revisions_context_manager_restores(
    mock_session: Any,
) -> None:
    """``with doc.tracked_revisions():`` enters track-changes mode and
    restores the previous value on exit — even on exception."""
    doc = _make_doc(mock_session)
    assert doc.track_revisions is False

    with doc.tracked_revisions():
        assert doc.track_revisions is True

    assert doc.track_revisions is False


def test_document_tracked_revisions_context_manager_restores_on_exception(
    mock_session: Any,
) -> None:
    """Exception inside the with-block must still restore the previous
    value — otherwise a buggy edit leaves the document permanently in
    track-changes mode."""
    doc = _make_doc(mock_session)

    with pytest.raises(RuntimeError, match="boom"):
        with doc.tracked_revisions():
            assert doc.track_revisions is True
            raise RuntimeError("boom")

    assert doc.track_revisions is False


def test_document_tracked_revisions_nested_preserves_outer(
    mock_session: Any,
) -> None:
    """Nested ``with`` blocks restore to the *previous* value, not the
    default. Useful when the outer caller has already toggled
    track-changes on and a helper wants to scope it for itself."""
    doc = _make_doc(mock_session)

    doc.track_revisions = True
    with doc.tracked_revisions():
        assert doc.track_revisions is True
        with doc.tracked_revisions():
            assert doc.track_revisions is True
        assert doc.track_revisions is True
    assert doc.track_revisions is True

    doc.track_revisions = False
    with doc.tracked_revisions():
        assert doc.track_revisions is True
    assert doc.track_revisions is False


# ---------------------------------------------------------------------------
# Document.settings.track_revisions alias
# ---------------------------------------------------------------------------


def test_settings_track_revisions_proxies_to_document(
    mock_session: Any,
) -> None:
    """``Document.settings.track_revisions`` is a python-docx-style
    alias — both sides must read/write the same value."""
    doc = _make_doc(mock_session)
    assert doc.settings.track_revisions is False

    doc.settings.track_revisions = True
    assert doc.track_revisions is True
    assert doc.settings.track_revisions is True

    doc.track_revisions = False
    assert doc.settings.track_revisions is False


def test_settings_without_document_track_revisions_setter_raises() -> None:
    """A bare Settings (no ``document=``) intentionally errors on the
    setter — there's no Document to forward to. Reads still work and
    return ``False`` as a safe default."""
    from docx.settings import Settings

    s = Settings(session=MagicMock())
    assert s.track_revisions is False
    with pytest.raises(RuntimeError, match="no Document"):
        s.track_revisions = True


# ---------------------------------------------------------------------------
# Document.revisions — the Athena extension collection
# ---------------------------------------------------------------------------


def test_revisions_iter_yields_revision_proxies(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """``for rev in doc.revisions`` yields :class:`Revision` proxies
    parsed from the SuperDoc ``items`` payload."""
    from docx.revisions import Revision, Revisions

    fake_sd_methods.scripted_returns["track_changes.list"] = {
        "evaluatedRevision": "r1",
        "total": 2,
        "items": [
            {
                "id": "tc-1",
                "type": "insert",
                "author": "Alice",
                "authorEmail": "alice@example.com",
                "date": "2026-05-01T12:00:00Z",
                "excerpt": "new sentence",
                "address": {
                    "kind": "entity",
                    "entityType": "trackedChange",
                    "entityId": "tc-1",
                },
            },
            {
                "id": "tc-2",
                "type": "delete",
                "author": "Bob",
                "date": "2026-05-02T09:30:00Z",
                "excerpt": "old text",
                "address": {
                    "kind": "entity",
                    "entityType": "trackedChange",
                    "entityId": "tc-2",
                },
            },
        ],
        "page": {"limit": 50, "offset": 0, "returned": 2},
    }
    revs = Revisions(session=mock_session)
    seen = list(revs)
    assert len(seen) == 2
    assert all(isinstance(r, Revision) for r in seen)
    assert seen[0].id == "tc-1"
    assert seen[0].type == "insert"
    assert seen[0].author == "Alice"
    assert seen[0].author_email == "alice@example.com"
    assert seen[0].excerpt == "new sentence"
    assert seen[1].id == "tc-2"
    assert seen[1].type == "delete"


def test_revisions_len_uses_total_field(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``len(doc.revisions)`` reads SuperDoc's authoritative ``total``
    even when the items page is short. Otherwise paged reads would
    return the wrong size."""
    from docx.revisions import Revisions

    fake_sd_methods.scripted_returns["track_changes.list"] = {
        "evaluatedRevision": "r1",
        "total": 47,  # full population
        "items": [{"id": f"tc-{i}", "type": "insert"} for i in range(10)],
        "page": {"limit": 10, "offset": 0, "returned": 10},
    }
    revs = Revisions(session=mock_session)
    assert len(revs) == 47


def test_revisions_get_returns_proxy_or_none(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.revisions import Revisions

    fake_sd_methods.scripted_returns["track_changes.get"] = {
        "id": "tc-9",
        "type": "format",
        "author": "Reviewer",
        "date": "2026-05-04T08:15:30+00:00",
        "excerpt": "bold span",
        "address": {
            "kind": "entity",
            "entityType": "trackedChange",
            "entityId": "tc-9",
        },
    }
    revs = Revisions(session=mock_session)
    rev = revs.get("tc-9")
    assert rev is not None
    assert rev.id == "tc-9"
    assert rev.type == "format"
    assert rev.author == "Reviewer"


def test_revisions_list_passes_filter_args(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``Revisions.list(change_type=, limit=, offset=)`` threads each
    arg into the right wire param."""
    from docx.revisions import Revisions

    fake_sd_methods.scripted_returns["track_changes.list"] = {
        "evaluatedRevision": "r1",
        "total": 0,
        "items": [],
        "page": {"limit": 5, "offset": 10, "returned": 0},
    }
    revs = Revisions(session=mock_session)
    revs.list(change_type="insert", limit=5, offset=10)

    call = _find_call(fake_sd_methods.calls, "track_changes.list")
    assert call is not None
    _, params = call
    # Wire field for filter is `type` (renamed from `change_type` in
    # the Command dataclass at construction; the path-proxy receives
    # the camelCase form). Here we're calling the proxy directly which
    # uses snake_case → so verify the snake_case key.
    assert params == {"type": "insert", "limit": 5, "offset": 10}


def test_revisions_list_validates_change_type(mock_session: Any) -> None:
    from docx.revisions import Revisions

    revs = Revisions(session=mock_session)
    with pytest.raises(ValidationError, match="change_type must be"):
        revs.list(change_type="bogus")


def test_revisions_accept_calls_decide_with_id(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``revisions.accept("tc-1")`` ships a Decide command with the
    expected target shape — single-id, no scope."""
    from docx.revisions import Revisions

    revs = Revisions(session=mock_session)
    revs.accept("tc-7")
    call = _find_call(fake_sd_methods.calls, "track_changes.decide")
    assert call is not None
    _, params = call
    assert params == {"decision": "accept", "target": {"id": "tc-7"}}


def test_revisions_reject_calls_decide_with_id(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.revisions import Revisions

    revs = Revisions(session=mock_session)
    revs.reject(42)  # int auto-coerced to str
    call = _find_call(fake_sd_methods.calls, "track_changes.decide")
    assert call is not None
    _, params = call
    assert params == {"decision": "reject", "target": {"id": "42"}}


def test_revisions_accept_all_uses_scope_sentinel(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Bulk accept sends ``target: {scope: "all"}`` — SuperDoc's
    sentinel for "all changes in the doc"."""
    from docx.revisions import Revisions

    revs = Revisions(session=mock_session)
    revs.accept_all()
    call = _find_call(fake_sd_methods.calls, "track_changes.decide")
    assert call is not None
    _, params = call
    assert params == {"decision": "accept", "target": {"scope": "all"}}


def test_revisions_reject_all_uses_scope_sentinel(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.revisions import Revisions

    revs = Revisions(session=mock_session)
    revs.reject_all()
    call = _find_call(fake_sd_methods.calls, "track_changes.decide")
    assert call is not None
    _, params = call
    assert params == {"decision": "reject", "target": {"scope": "all"}}


def test_revisions_accept_proxy_object_routes_through_revision(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Passing a :class:`Revision` to ``accept()`` should preserve any
    ``story`` locator the revision was loaded with, rather than
    flattening to just an id."""
    from docx.revisions import Revision, Revisions

    rev = Revision(
        session=mock_session,
        info={
            "id": "tc-h1",
            "type": "insert",
            "address": {
                "kind": "entity",
                "entityType": "trackedChange",
                "entityId": "tc-h1",
                "story": {
                    "kind": "story",
                    "storyType": "headerFooterSlot",
                    "section": {"kind": "section", "sectionId": "sec-1"},
                    "headerFooterKind": "header",
                    "variant": "default",
                },
            },
        },
    )
    revs = Revisions(session=mock_session)
    revs.accept(rev)

    call = _find_call(fake_sd_methods.calls, "track_changes.decide")
    assert call is not None
    _, params = call
    assert params["decision"] == "accept"
    assert params["target"]["id"] == "tc-h1"
    assert params["target"]["story"] == {
        "kind": "story",
        "storyType": "headerFooterSlot",
        "section": {"kind": "section", "sectionId": "sec-1"},
        "headerFooterKind": "header",
        "variant": "default",
    }


def test_revision_accept_method_calls_decide(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``rev.accept()`` is a convenience that routes through
    ``Revisions.accept`` — confirm the wire payload matches."""
    from docx.revisions import Revision

    rev = Revision(
        session=mock_session,
        info={"id": "tc-3", "type": "delete", "author": "Alice"},
    )
    rev.accept()
    call = _find_call(fake_sd_methods.calls, "track_changes.decide")
    assert call is not None
    _, params = call
    assert params == {"decision": "accept", "target": {"id": "tc-3"}}


def test_revision_reject_method_calls_decide(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.revisions import Revision

    rev = Revision(session=mock_session, info={"id": "tc-x", "type": "insert"})
    rev.reject()
    call = _find_call(fake_sd_methods.calls, "track_changes.decide")
    assert call is not None
    _, params = call
    assert params == {"decision": "reject", "target": {"id": "tc-x"}}


def test_revision_accept_without_id_raises(mock_session: Any) -> None:
    """A revision proxy with no id can't be resolved — fail loudly
    rather than send an empty-id Decide that SuperDoc would 400 on."""
    from docx.revisions import Revision

    rev = Revision(session=mock_session, info={"type": "insert"})
    with pytest.raises(ValidationError, match="id"):
        rev.accept()


def test_revision_date_parses_iso_with_z(mock_session: Any) -> None:
    """SuperDoc returns ``date`` as ISO-8601 with a trailing ``Z`` for
    UTC. Our ``date`` property should produce a tz-aware datetime."""
    from docx.revisions import Revision

    rev = Revision(
        session=mock_session,
        info={"id": "tc-1", "type": "insert", "date": "2026-05-01T12:00:00Z"},
    )
    d = rev.date
    assert d is not None
    assert d == datetime(2026, 5, 1, 12, 0, 0, tzinfo=timezone.utc)


def test_revision_date_returns_none_for_unparseable(mock_session: Any) -> None:
    """Garbage-in returns ``None`` rather than raising — the raw string
    is still available via ``raw_date``."""
    from docx.revisions import Revision

    rev = Revision(
        session=mock_session,
        info={"id": "tc-1", "type": "insert", "date": "yesterday afternoon"},
    )
    assert rev.date is None
    assert rev.raw_date == "yesterday afternoon"


def test_revision_repr_includes_id_type_author(mock_session: Any) -> None:
    """``repr`` is used in pytest failure output and Jupyter notebook
    cells — make sure it surfaces the most useful fields."""
    from docx.revisions import Revision

    rev = Revision(
        session=mock_session,
        info={"id": "tc-9", "type": "insert", "author": "Alice"},
    )
    r = repr(rev)
    assert "tc-9" in r
    assert "insert" in r
    assert "Alice" in r


# ---------------------------------------------------------------------------
# End-to-end: Document properties → buffer envelope
# ---------------------------------------------------------------------------


def _make_doc_with_real_buffer():
    """Construct a Document with a real CommandBuffer so we can assert
    on envelope-level changeMode/user propagation."""
    from docx.client import Session
    from docx.document import Document

    fake_client = _FakeClient()

    # Minimal fake doc handle that exposes `.buffer` to match HttpDocHandle.
    class _FakeHandle:
        def __init__(self, client: _FakeClient, asset_id: str) -> None:
            self.buffer = CommandBuffer(client, asset_id, auto_flush_seconds=0.0)

    handle = _FakeHandle(fake_client, "asset_test")

    session = MagicMock(spec=Session)
    session.asset_id = "asset_test"
    session.is_open = True
    session._doc_handle = handle
    session.open = AsyncMock()
    session.save = AsyncMock()
    session.close = AsyncMock()

    doc = Document.__new__(Document)
    doc._session = session
    doc._saved = False
    doc._closed = False
    doc._pending_user_name = None
    doc._pending_user_email = None
    doc._pending_track_revisions = False

    return doc, fake_client, handle.buffer


def test_document_track_revisions_flag_propagates_to_buffer() -> None:
    """End-to-end: setting ``Document.track_revisions = True`` flushes
    pending and switches the buffer to ``changeMode='tracked'``. The
    next batch's envelope carries the new mode."""
    doc, fake, buf = _make_doc_with_real_buffer()

    # Sanity: nothing in the buffer, mode unset.
    assert buf.change_mode is None

    doc.track_revisions = True
    assert buf.change_mode == "tracked"

    # Issue a buffered mutation, flush, assert envelope.
    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    buf.flush()
    assert fake.envelopes[-1]["changeMode"] == "tracked"

    # Flip back, confirm the next batch goes out as direct.
    doc.track_revisions = False
    buf.call(FormatApply(target={"kind": "block"}, inline={"italic": True}))
    buf.flush()
    assert fake.envelopes[-1]["changeMode"] is None  # cleared


def test_document_user_name_propagates_to_buffer() -> None:
    """End-to-end: ``Document.user_name = "Alice"`` lands on the
    envelope as ``user.name``; ``user_email`` rides alongside."""
    doc, fake, buf = _make_doc_with_real_buffer()

    doc.user_name = "Alice"
    doc.user_email = "alice@example.com"

    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    buf.flush()
    assert fake.envelopes[-1]["user"] == {
        "name": "Alice",
        "email": "alice@example.com",
    }


def test_document_tracked_revisions_block_drains_each_boundary() -> None:
    """A ``with doc.tracked_revisions():`` block produces three batches:
    one before (any pending), one inside (mode=tracked), one after
    (mode reverts). Buffer flushes at each mode-change boundary."""
    doc, fake, buf = _make_doc_with_real_buffer()

    # Pre: a non-tracked mutation.
    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))

    with doc.tracked_revisions():
        buf.call(Replace(target={"kind": "selection"}, text="tracked"))

    # Post: another non-tracked mutation.
    buf.call(FormatApply(target={"kind": "block"}, inline={"italic": True}))
    buf.flush()

    # Three batches: pre (mode=None), inside (mode=tracked), post (mode=None).
    assert len(fake.batches) == 3
    assert fake.envelopes[0]["changeMode"] is None
    assert fake.envelopes[1]["changeMode"] == "tracked"
    assert fake.envelopes[2]["changeMode"] is None


# ---------------------------------------------------------------------------
# Document.create / Document(...) factory pass-through
# ---------------------------------------------------------------------------


def test_document_factory_accepts_user_name_and_track_revisions(
    monkeypatch: Any,
) -> None:
    """The top-level ``Document(asset_id, ...)`` factory accepts the
    new track-changes kwargs and threads them into the underlying
    Document instance. Verifies the public API is wired end-to-end."""
    from docx.api import Document as DocumentFactory
    from docx.document import Document as _Document

    captured: dict[str, Any] = {}

    def fake_init(self, **kwargs: Any) -> None:
        captured.update(kwargs)
        # Don't actually open a session — bypass the asset-creation HTTP.
        self._session = None
        self._saved = False
        self._closed = False
        self._pending_user_name = kwargs.get("user_name")
        self._pending_user_email = kwargs.get("user_email")
        self._pending_track_revisions = kwargs.get("track_revisions", False)

    monkeypatch.setattr(_Document, "__init__", fake_init)
    DocumentFactory(
        "asset_xyz",
        user_name="Author",
        user_email="author@example.com",
        track_revisions=True,
    )
    assert captured["asset_id"] == "asset_xyz"
    assert captured["user_name"] == "Author"
    assert captured["user_email"] == "author@example.com"
    assert captured["track_revisions"] is True
