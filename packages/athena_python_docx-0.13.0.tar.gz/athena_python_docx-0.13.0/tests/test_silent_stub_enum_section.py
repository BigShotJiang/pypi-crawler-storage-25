"""Lock-in tests for WD_SECTION_START.to_superdoc() coercion warning.

``WD_SECTION_START.NEW_COLUMN`` previously fell through the cascading
``if`` chain in ``to_superdoc()`` and silently returned ``"nextPage"``.
A caller asking for a column break got a page break with no signal.

Now the collapse emits :class:`PendingEnumCoercionWarning` (mirroring
the warn-on-coerce pattern set up for WD_ALIGN_PARAGRAPH and
WD_TAB_ALIGNMENT in ``enum/text.py``), so divergent behavior surfaces
at agent-run time instead of being lost.
"""

from __future__ import annotations

import warnings

import pytest


def test_new_column_warns_and_falls_back_to_next_page() -> None:
    """The one section-start member SuperDoc can't represent emits a
    coercion warning AND ships ``"nextPage"`` on the wire."""
    from docx.enum.section import WD_SECTION_START
    from docx.enum.text import PendingEnumCoercionWarning

    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        wire = WD_SECTION_START.NEW_COLUMN.to_superdoc()

    assert wire == "nextPage"
    pending = [w for w in recorded if issubclass(w.category, PendingEnumCoercionWarning)]
    assert len(pending) == 1, (
        "WD_SECTION_START.NEW_COLUMN.to_superdoc() should emit exactly "
        "1 PendingEnumCoercionWarning"
    )
    assert "NEW_COLUMN" in str(pending[0].message)


@pytest.mark.parametrize(
    "member,expected",
    [
        ("CONTINUOUS", "continuous"),
        ("NEW_PAGE", "nextPage"),
        ("EVEN_PAGE", "evenPage"),
        ("ODD_PAGE", "oddPage"),
    ],
)
def test_supported_section_starts_do_not_warn(
    member: str, expected: str
) -> None:
    """The four section starts SuperDoc supports must NOT emit a
    coercion warning — they map cleanly."""
    from docx.enum.section import WD_SECTION_START
    from docx.enum.text import PendingEnumCoercionWarning

    enum_member = getattr(WD_SECTION_START, member)
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        wire = enum_member.to_superdoc()

    assert wire == expected
    pending = [w for w in recorded if issubclass(w.category, PendingEnumCoercionWarning)]
    assert not pending, (
        f"{member} maps cleanly; should NOT emit PendingEnumCoercionWarning"
    )


def test_orientation_never_warns() -> None:
    """WD_ORIENTATION maps both members cleanly — neither should
    emit a coercion warning."""
    from docx.enum.section import WD_ORIENTATION
    from docx.enum.text import PendingEnumCoercionWarning

    for member in (WD_ORIENTATION.PORTRAIT, WD_ORIENTATION.LANDSCAPE):
        with warnings.catch_warnings(record=True) as recorded:
            warnings.simplefilter("always")
            member.to_superdoc()
        pending = [
            w for w in recorded if issubclass(w.category, PendingEnumCoercionWarning)
        ]
        assert not pending, (
            f"{member.name} should not emit PendingEnumCoercionWarning"
        )
