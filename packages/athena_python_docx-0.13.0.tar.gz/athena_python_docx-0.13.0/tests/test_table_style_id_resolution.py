"""Friendly-name → styleId resolution for Word built-in table styles.

The exported ``.docx`` writes the styleId from the Y.Doc into
``<w:tblStyle w:val="..."/>``. Word's ``styles.xml`` uses internal
styleIds (e.g. ``LightGrid-Accent1``), not friendly names
(``"Light Grid Accent 1"``). If the SDK ships the friendly name to
the wire, Word can't find the style definition and renders the table
with no borders, no header fill, and no banding.
"""

from __future__ import annotations

from typing import Any

import pytest

from docx._table_styles import (
    BUILTIN_TABLE_STYLE_IDS,
    resolve_table_style_id,
)


class TestBuiltinTableStyleMap:
    """Pin the size and a representative sample of the built-in map."""

    def test_map_covers_word_2007_plus_word_2013_table_styles(self) -> None:
        """Word's default ``styles.xml`` declares 204 built-in table
        styles across the Word 2007 and Word 2013+ catalogs:

        * 2 Word 2007 irregulars (Normal Table, Table Grid)
        * 14 Word 2007 base styles × 7 variants (base + 6 accents) = 98
        * 1 Word 2013+ irregular (Grid Table Light)
        * 5 Word 2013+ Plain Table entries (no accents)
        * 14 Word 2013+ base styles × 7 variants (base + 6 accents) = 98
        """
        assert len(BUILTIN_TABLE_STYLE_IDS) == 2 + 14 * 7 + 1 + 5 + 14 * 7

    @pytest.mark.parametrize(
        "friendly,style_id",
        [
            # Word 2007 catalog
            ("Normal Table", "TableNormal"),
            ("Table Grid", "TableGrid"),
            ("Light Shading", "LightShading"),
            ("Light Grid", "LightGrid"),
            ("Light Grid Accent 1", "LightGrid-Accent1"),
            ("Light Grid Accent 6", "LightGrid-Accent6"),
            ("Medium Shading 1 Accent 2", "MediumShading1-Accent2"),
            ("Medium Grid 3 Accent 5", "MediumGrid3-Accent5"),
            ("Dark List", "DarkList"),
            ("Dark List Accent 4", "DarkList-Accent4"),
            ("Colorful Shading Accent 1", "ColorfulShading-Accent1"),
            ("Colorful Grid Accent 6", "ColorfulGrid-Accent6"),
            # Word 2013+ catalog
            ("Plain Table 1", "PlainTable1"),
            ("Plain Table 5", "PlainTable5"),
            ("Grid Table Light", "GridTableLight"),
            ("Grid Table 1 Light", "GridTable1Light"),
            ("Grid Table 1 Light Accent 3", "GridTable1Light-Accent3"),
            ("Grid Table 4 Accent 2", "GridTable4-Accent2"),
            ("Grid Table 5 Dark", "GridTable5Dark"),
            ("Grid Table 5 Dark Accent 6", "GridTable5Dark-Accent6"),
            ("Grid Table 7 Colorful Accent 1", "GridTable7Colorful-Accent1"),
            ("List Table 2", "ListTable2"),
            ("List Table 4 Accent 5", "ListTable4-Accent5"),
            ("List Table 7 Colorful Accent 3", "ListTable7Colorful-Accent3"),
        ],
    )
    def test_canonical_pairs(self, friendly: str, style_id: str) -> None:
        assert BUILTIN_TABLE_STYLE_IDS[friendly] == style_id


class TestResolveTableStyleId:
    def test_friendly_name_resolves_to_canonical(self) -> None:
        assert resolve_table_style_id("Light Grid Accent 1") == "LightGrid-Accent1"

    def test_canonical_id_passes_through_unchanged(self) -> None:
        """Already-canonical styleIds must be idempotent under the
        resolver — they aren't friendly names so they miss the map
        and fall through.
        """
        assert resolve_table_style_id("LightGrid-Accent1") == "LightGrid-Accent1"
        assert resolve_table_style_id("TableGrid") == "TableGrid"

    def test_unknown_style_passes_through(self) -> None:
        """Custom user-defined styles aren't in our built-in map; we
        pass them through so callers with bespoke styleIds keep
        working.
        """
        assert resolve_table_style_id("MyCustomStyle") == "MyCustomStyle"

    def test_normal_table_irregular_mapping(self) -> None:
        """``Normal Table`` is the one Word built-in whose styleId
        (``TableNormal``) doesn't follow the strip-spaces rule.
        """
        assert resolve_table_style_id("Normal Table") == "TableNormal"


class TestAddTableWritePath:
    """End-to-end: ``Document.add_table(style=...)`` must ship the
    canonical styleId to ``tables.set_style``.
    """

    def _make_doc(self, mock_session: Any) -> Any:
        from docx.document import Document

        doc = Document.__new__(Document)
        doc._session = mock_session
        doc._saved = False
        doc._closed = False
        return doc

    def _find_call(self, calls: list[tuple[str, Any]], op: str) -> tuple[str, Any] | None:
        for call in calls:
            if call[0] == op:
                return call
        return None

    def test_add_table_with_friendly_name_ships_canonical_style_id(
        self, mock_session: Any, fake_sd_methods: Any
    ) -> None:
        """The original bug: ``style="Light Grid Accent 1"`` shipped
        ``Light Grid Accent 1`` to OOXML, which Word can't resolve.
        """
        doc = self._make_doc(mock_session)
        doc.add_table(rows=2, cols=3, style="Light Grid Accent 1")

        set_style = self._find_call(fake_sd_methods.calls, "tables.set_style")
        assert set_style is not None
        _, params = set_style
        assert params["styleId"] == "LightGrid-Accent1"

    def test_add_table_with_canonical_id_passes_through(
        self, mock_session: Any, fake_sd_methods: Any
    ) -> None:
        doc = self._make_doc(mock_session)
        doc.add_table(rows=2, cols=3, style="LightGrid-Accent1")

        set_style = self._find_call(fake_sd_methods.calls, "tables.set_style")
        assert set_style is not None
        _, params = set_style
        assert params["styleId"] == "LightGrid-Accent1"


class TestTableStyleSetterWritePath:
    """End-to-end: ``Table.style = "..."`` setter must normalize too."""

    def test_setter_friendly_name_ships_canonical_style_id(
        self, mock_session: Any, fake_sd_methods: Any
    ) -> None:
        from docx.table import Table

        tbl = Table(session=mock_session, node_id="tbl-1")
        tbl.style = "Medium Shading 1 Accent 2"

        # Most recent tables.set_style call.
        set_style_calls = [c for c in fake_sd_methods.calls if c[0] == "tables.set_style"]
        assert set_style_calls
        _, params = set_style_calls[-1]
        assert params["styleId"] == "MediumShading1-Accent2"

    def test_setter_none_falls_back_to_table_grid(
        self, mock_session: Any, fake_sd_methods: Any
    ) -> None:
        from docx.table import Table

        tbl = Table(session=mock_session, node_id="tbl-1")
        tbl.style = None

        set_style_calls = [c for c in fake_sd_methods.calls if c[0] == "tables.set_style"]
        assert set_style_calls
        _, params = set_style_calls[-1]
        assert params["styleId"] == "TableGrid"
