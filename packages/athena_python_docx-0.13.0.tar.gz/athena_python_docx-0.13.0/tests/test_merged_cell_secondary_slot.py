"""Regression tests for ``_Cell`` on the secondary slot of a horizontal
merge.

FakeSession in ``tests/fidelity/fake_session.py`` resolves any
(rowIndex, columnIndex) inside a merge group back to the master cell
— that's convenient for fidelity testing, but real Superdoc 1.8.1 does
NOT do that resolution. Its ``tables.getCells`` only returns the
master cell when queried by its top-left position; querying any other
position inside the merge returns an empty ``cells: []`` array.

Before the 2026-05-17 fix, the SDK's ``_Cell._cell_info`` had no
fallback for that case — so ``cell.text`` on any secondary slot raised
``ValidationError: Cell (r, c) not found in table …``. This broke the
naive ``for cell in row.cells: text = cell.text`` loop on every PW
firm template (each has at least one banner/title row with
``gridSpan=2``).

These tests pin the post-fix behaviour: secondary slots resolve to the
master's info via a row-walk-back, mirroring python-docx's
``<w:tc>``-sharing semantics.
"""

from __future__ import annotations


class _GetCellsStub:
    """A minimal async callable that mimics Superdoc's ``tables.getCells``.

    Returns the master cell entry only when queried by the master's
    top-left position. Any other ``(rowIndex, columnIndex)`` inside the
    merge returns an empty cells list — matching real Superdoc 1.8.1.
    Out-of-merge body rows return a normal one-cell-per-column entry.
    """

    def __init__(
        self,
        *,
        rows: int,
        cols: int,
        merge_at: tuple[int, int],
        merge_colspan: int,
        master_id: str,
        master_text: str,
    ) -> None:
        self.rows = rows
        self.cols = cols
        self.merge_r, self.merge_c = merge_at
        self.colspan = merge_colspan
        self.master_id = master_id
        self.master_text = master_text
        self.calls: list[dict] = []

    async def __call__(self, params: dict | None = None) -> dict:
        params = params or {}
        self.calls.append(dict(params))
        r = params.get("rowIndex")
        c = params.get("columnIndex")
        if r == self.merge_r and c == self.merge_c:
            return {
                "nodeId": "table_under_test",
                "cells": [
                    {
                        "nodeId": self.master_id,
                        "rowIndex": self.merge_r,
                        "columnIndex": self.merge_c,
                        "colspan": self.colspan,
                        "rowspan": 1,
                        "text": self.master_text,
                    },
                ],
            }
        if r == self.merge_r and c is not None and self.merge_c < c < self.merge_c + self.colspan:
            # Secondary slot inside the merge — real Superdoc returns
            # an empty cells list for these positions.
            return {"nodeId": "table_under_test", "cells": []}
        if r is not None and 0 <= r < self.rows and c is not None and 0 <= c < self.cols and r != self.merge_r:
            return {
                "nodeId": "table_under_test",
                "cells": [
                    {
                        "nodeId": f"cell_body_{r}_{c}",
                        "rowIndex": r,
                        "columnIndex": c,
                        "colspan": 1,
                        "rowspan": 1,
                        "text": f"r{r}c{c}",
                    },
                ],
            }
        return {"nodeId": "table_under_test", "cells": []}


class _DocStub:
    """Stub for ``session.doc`` — exposes ``tables.get_cells`` only."""

    def __init__(self, get_cells: _GetCellsStub) -> None:
        self.tables = type("_TablesStub", (), {"get_cells": get_cells})()


class _SessionStub:
    def __init__(self, doc: _DocStub) -> None:
        self.doc = doc


class _TableStub:
    def __init__(self, session: _SessionStub, node_id: str = "table_under_test") -> None:
        self._session = session
        self._node_id = node_id

    def _fresh_node_id(self) -> str:
        return self._node_id


def _make_table(*, rows: int, cols: int, merge_at: tuple[int, int], merge_colspan: int,
                master_id: str = "cell_master", master_text: str = "header"):
    stub = _GetCellsStub(
        rows=rows, cols=cols, merge_at=merge_at, merge_colspan=merge_colspan,
        master_id=master_id, master_text=master_text,
    )
    doc = _DocStub(stub)
    session = _SessionStub(doc)
    table = _TableStub(session)
    return table, stub


def test_cell_info_for_secondary_slot_resolves_to_master() -> None:
    """``_Cell._cell_info()`` on (0, 1) of a row with ``colspan=2`` at
    (0, 0) should return the master's info, not ``None``."""
    from docx.table import _Cell

    table, stub = _make_table(
        rows=2, cols=2, merge_at=(0, 0), merge_colspan=2, master_id="cell_master",
    )
    primary = _Cell(table=table, row=0, col=0)  # type: ignore[arg-type]
    secondary = _Cell(table=table, row=0, col=1)  # type: ignore[arg-type]

    primary_info = primary._cell_info()
    assert primary_info is not None
    assert primary_info["nodeId"] == "cell_master"
    assert primary_info["colspan"] == 2

    # Pre-fix: this returned None and downstream raised. Post-fix:
    # walks back to (0, 0), finds colspan=2 covering position 1,
    # returns the master's info.
    secondary_info = secondary._cell_info()
    assert secondary_info is not None, (
        "Secondary slot of a horizontal merge must resolve to the master's "
        "info, not return None. See _Cell._cell_info walk-back."
    )
    assert secondary_info["nodeId"] == "cell_master"
    assert secondary_info["colspan"] == 2


def test_cell_id_for_secondary_slot_returns_master_id() -> None:
    """``_Cell._cell_id`` on the secondary slot must NOT raise — it
    should return the master's nodeId so downstream ops route to the
    same ``<w:tc>``."""
    from docx.table import _Cell

    table, _stub = _make_table(
        rows=2, cols=2, merge_at=(0, 0), merge_colspan=2, master_id="cell_master",
    )
    secondary = _Cell(table=table, row=0, col=1)  # type: ignore[arg-type]
    assert secondary._cell_id() == "cell_master"


def test_cell_grid_span_for_secondary_slot_returns_master_span() -> None:
    """``_Cell.grid_span`` on the secondary slot returns the master's
    span, mirroring python-docx's ``<w:tc>``-sharing model."""
    from docx.table import _Cell

    table, _stub = _make_table(
        rows=2, cols=3, merge_at=(0, 0), merge_colspan=3, master_id="cell_master",
    )
    primary = _Cell(table=table, row=0, col=0)  # type: ignore[arg-type]
    s1 = _Cell(table=table, row=0, col=1)  # type: ignore[arg-type]
    s2 = _Cell(table=table, row=0, col=2)  # type: ignore[arg-type]
    assert primary.grid_span == 3
    assert s1.grid_span == 3, "secondary slot should mirror master's span"
    assert s2.grid_span == 3


def test_cell_info_returns_none_when_truly_missing() -> None:
    """When a row has no cell at (r, c) and no preceding cell with a
    matching colspan, ``_cell_info`` should return ``None`` — NOT walk
    arbitrarily far left and return an unrelated cell."""
    from docx.table import _Cell

    # Row 0 has a colspan=1 cell at (0, 0). (0, 1) is genuinely empty
    # (not covered by any merge). Walk-back should find (0, 0)'s
    # colspan=1, determine it doesn't reach column 1, and return None.
    table, _stub = _make_table(
        rows=1, cols=2, merge_at=(0, 0), merge_colspan=1, master_id="cell_only",
    )
    secondary = _Cell(table=table, row=0, col=1)  # type: ignore[arg-type]
    assert secondary._cell_info() is None


def test_grid_span_off_truly_missing_cell_is_one() -> None:
    """When the cell is genuinely missing (no merge covers it),
    ``grid_span`` falls back to the python-docx default of 1 rather
    than raising."""
    from docx.table import _Cell

    table, _stub = _make_table(
        rows=1, cols=2, merge_at=(0, 0), merge_colspan=1,
    )
    secondary = _Cell(table=table, row=0, col=1)  # type: ignore[arg-type]
    assert secondary.grid_span == 1


def test_cell_info_colspan_helper_reads_all_known_keys() -> None:
    """Real Superdoc returns ``colspan``; FakeSession + older internal
    docs alias as ``gridSpan`` / ``grid_span``. The helper must read
    any of the three."""
    from docx.table import _cell_info_colspan

    assert _cell_info_colspan({"colspan": 3}) == 3
    assert _cell_info_colspan({"gridSpan": 4}) == 4
    assert _cell_info_colspan({"grid_span": 5}) == 5
    # All present → first key wins (real Superdoc's `colspan`).
    assert _cell_info_colspan({"colspan": 2, "gridSpan": 99}) == 2
    # Missing / bogus → defaults to 1.
    assert _cell_info_colspan({}) == 1
    assert _cell_info_colspan({"colspan": "not-a-number"}) == 1
    # Zero or negative → clamped to 1 (Word rejects 0-span).
    assert _cell_info_colspan({"colspan": 0}) == 1
    assert _cell_info_colspan({"colspan": -3}) == 1


def test_walk_back_stops_at_first_existing_predecessor() -> None:
    """Walk-back should stop at the FIRST existing predecessor — it
    should not walk through gaps to find a far-left cell. Otherwise a
    typo or sparse row could pick up arbitrary cells from earlier in
    the row.

    Setup: row 0 has a regular cell at (0, 0) (no merge), and an
    out-of-bounds query for (0, 2). The walk-back encounters (0, 1)
    (empty), then (0, 0) (colspan=1, doesn't reach column 2). The
    correct answer is None — NOT (0, 0).
    """
    from docx.table import _Cell

    table, _stub = _make_table(
        rows=1, cols=3, merge_at=(0, 0), merge_colspan=1,
    )
    out_of_bounds = _Cell(table=table, row=0, col=2)  # type: ignore[arg-type]
    info = out_of_bounds._cell_info()
    # (0, 1) is empty (not in stub's response set); walk reaches (0, 0)
    # which has colspan=1 and doesn't cover column 2 → None.
    assert info is None
