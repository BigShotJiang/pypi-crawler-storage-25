"""Locks the ``docx.api.Document(...)`` asset-id validation contract.

The factory must reject anything that isn't a canonical SuperDocument
asset id (matching ``^asset_[A-Za-z0-9_-]+$``) so an agent passing a
document TITLE — the common failure mode — gets a clear error before
any HTTP round-trip is attempted.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from docx import Document


class TestDocumentFactoryValidation:
    @pytest.mark.parametrize(
        "bad_id",
        [
            "Q1 Report Draft",  # human-readable title
            "Final Word Doc",
            "document.docx",
            "MyDocument",
            "8a2c5a48-4a85-4c6e-8a10-0ceccd1d2ca7",  # bare UUID isn't canonical
            "wb_123",  # wrong studio prefix
            "deck_abc",  # wrong studio prefix
        ],
    )
    def test_rejects_non_asset_ids(self, bad_id: str) -> None:
        with pytest.raises(ValueError, match=r"not a valid SuperDocument asset id"):
            Document(bad_id)

    @pytest.mark.parametrize(
        "good_id",
        [
            "asset_3a9328bc-9c1c-4498-be8f-bda3883276f5",
            "asset_abc",
            "asset_abc-def-ghi",
            "asset_with_underscores_123",
        ],
    )
    def test_accepts_canonical_asset_ids(self, good_id: str) -> None:
        # Patch the underlying ``_Document`` so we don't try to open a
        # real Session — the validation must accept the id before any
        # HTTP construction happens.
        with patch("docx.api._Document") as MockDocument:
            MockDocument.return_value.__class__.__name__ = "Document"
            Document(good_id)
            MockDocument.assert_called_once()
            assert MockDocument.call_args.kwargs["asset_id"] == good_id
