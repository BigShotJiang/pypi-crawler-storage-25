"""End-to-end test for the partial-failure cascade fix.

Drives a multi-batch agent-style flow through the HTTP transport with
an intentional mid-batch failure and verifies the next batch ships
**real** SuperDoc ids (not client UUIDs) for every Create that DID
commit before the failure. Complements
``tests/test_partial_failure_cascade.py`` (which pins the buffer-level
contract with a hand-built ``CreateParagraph``) by exercising the same
recovery through the Document/Paragraph public API.

Why this is "E2E": it goes Document → CommandBuffer →
``_http_post_json`` → mocked transport → and verifies the SDK's
high-level proxies (``Paragraph._node_id``) are correctly re-anchored
after the partial failure. The bug being pinned — preview-session
``thread_bafba02b``'s thirteen-error cascade — manifested at exactly
this layer.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import patch

import pytest

from docx._http_doc import HttpClient, HttpDocHandle
from docx.commands import CreateParagraph, SetParagraphAlignment
from docx.errors import BlockNotFoundError


class _ScriptedResponse:
    def __init__(self, *, status_code: int, body: bytes) -> None:
        self.status_code = status_code
        self._body_text = body.decode("utf-8", errors="replace")

    @property
    def text(self) -> str:
        return self._body_text

    def json(self) -> Any:
        return json.loads(self._body_text)


def _ok_body(applied_results: list[dict[str, Any]]) -> bytes:
    return json.dumps(
        {"assetId": "asset_test", "applied": applied_results},
    ).encode("utf-8")


def _partial_failure_body(
    *,
    applied: list[dict[str, Any]],
    err_cmd_type: str,
    err_message: str,
) -> bytes:
    return json.dumps(
        {
            "assetId": "asset_test",
            "applied": applied,
            "error": {
                "index": len(applied),
                "type": err_cmd_type,
                "error": "SuperDocCliError",
                "message": err_message,
            },
        },
    ).encode("utf-8")


def test_paragraph_proxy_id_survives_a_mid_batch_failure() -> None:
    """End-to-end recovery: two CreateParagraphs queue, the second
    batch flushes them WITH a doomed SetParagraphAlignment behind, and
    we verify the FIRST CreateParagraph's proxy id was correctly
    swung from its client UUID to the real SuperDoc id even though
    the batch raised.

    Before the cascade fix, this test's proxy would have stayed on
    ``p_<client>`` and the next batch would have shipped that dead id
    to SuperDoc, getting another ``Block not found``.
    """
    posts: list[dict[str, Any]] = []

    def _scripted(url: str, **kwargs: Any) -> _ScriptedResponse:  # noqa: ARG001
        body = json.loads(kwargs["data"].decode("utf-8"))
        posts.append(body)
        # Compose ``applied`` for the prefix that succeeds, then fail on
        # the first SetParagraphAlignment we see. SuperDoc returns
        # ``client_node_id`` / ``real_node_id`` echoes for every Create
        # that commits — that's what the buffer's rewrite path reads.
        applied_results: list[dict[str, Any]] = []
        for idx, cmd in enumerate(body["commands"]):
            cmd_type = cmd["type"]
            if cmd_type == "SetParagraphAlignment":
                # Doomed command — partial-failure response.
                return _ScriptedResponse(
                    status_code=207,
                    body=_partial_failure_body(
                        applied=applied_results,
                        err_cmd_type="SetParagraphAlignment",
                        err_message='Block "paragraph:phantom-id" was not found.',
                    ),
                )
            if cmd_type == "CreateParagraph":
                client = cmd.get("clientNodeId")
                real = f"real_para_{len(applied_results)}"
                result = (
                    {"paragraph": {"nodeId": real},
                     "client_node_id": client,
                     "real_node_id": real}
                    if client
                    else {"paragraph": {"nodeId": real}}
                )
                applied_results.append({"index": idx, "type": cmd_type, "result": result})
                continue
            applied_results.append({"index": idx, "type": cmd_type, "result": {}})
        return _ScriptedResponse(status_code=200, body=_ok_body(applied_results))

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    # Mimic what ``Document.add_paragraph`` does — pre-mint client_node_ids
    # and register proxies so we can verify the rewrite landed on them.
    class _Proxy:
        def __init__(self, client_id: str) -> None:
            self._node_id = client_id

    proxy_a = _Proxy("p_first_client")
    proxy_b = _Proxy("p_second_client")

    with patch.object(client._session, "post", side_effect=_scripted):
        doc = HttpDocHandle(client, "asset_test")
        doc.buffer.register_proxy_id_ref("p_first_client", proxy_a, attr="_node_id")
        doc.buffer.register_proxy_id_ref("p_second_client", proxy_b, attr="_node_id")
        doc.buffer._pending.append(
            CreateParagraph(
                text="A",
                at={"kind": "documentEnd"},
                client_node_id="p_first_client",
            ),
        )
        doc.buffer._pending.append(
            CreateParagraph(
                text="B",
                at={"kind": "documentEnd"},
                client_node_id="p_second_client",
            ),
        )
        doc.buffer._pending.append(
            SetParagraphAlignment(
                target={
                    "kind": "block",
                    "nodeType": "paragraph",
                    "nodeId": "phantom-id",
                },
                alignment="center",
            ),
        )

        with pytest.raises(BlockNotFoundError):
            doc.buffer.flush()

    # Both proxies should now hold REAL SuperDoc ids, NOT client UUIDs.
    # This is the cascade fix in action: the partial-failure response's
    # ``applied`` array carried two CreateParagraph echoes, and the
    # buffer's exception path drained them through the same rewrite
    # the success path uses.
    assert proxy_a._node_id == "real_para_0", (
        "Pre-fix this would still be 'p_first_client' — the next batch "
        "would ship the dead client UUID and SuperDoc would say 'Block "
        "not found', restarting the cascade."
    )
    assert proxy_b._node_id == "real_para_1"


def test_next_batch_after_partial_failure_uses_real_ids() -> None:
    """End-to-end follow-through: after the partial-failure recovery
    rewrites the proxy, the SUBSEQUENT batch's wire format uses the
    real ids — confirming the cascade is genuinely broken, not just
    that the in-memory proxy got updated."""
    posts: list[dict[str, Any]] = []

    call_count = [0]

    def _scripted(url: str, **kwargs: Any) -> _ScriptedResponse:  # noqa: ARG001
        call_count[0] += 1
        body = json.loads(kwargs["data"].decode("utf-8"))
        posts.append(body)
        if call_count[0] == 1:
            # First batch: a CreateParagraph commits, then a doomed
            # SetParagraphAlignment fails. Server echoes
            # client_node_id → real_node_id for the survivor.
            return _ScriptedResponse(
                status_code=207,
                body=_partial_failure_body(
                    applied=[
                        {
                            "index": 0,
                            "type": "CreateParagraph",
                            "result": {
                                "paragraph": {"nodeId": "real_para_1"},
                                "client_node_id": "p_first_client",
                                "real_node_id": "real_para_1",
                            },
                        },
                    ],
                    err_cmd_type="SetParagraphAlignment",
                    err_message='Block "paragraph:phantom-id" was not found.',
                ),
            )
        # Second batch should ship the REAL id, not the client UUID.
        return _ScriptedResponse(
            status_code=200,
            body=_ok_body(
                [{"index": 0, "type": "SetParagraphAlignment", "result": {}}],
            ),
        )

    client = HttpClient(base_url="https://example.com", api_key="bg_key")

    class _Proxy:
        def __init__(self, client_id: str) -> None:
            self._node_id = client_id

    proxy = _Proxy("p_first_client")

    with patch.object(client._session, "post", side_effect=_scripted):
        doc = HttpDocHandle(client, "asset_test")
        doc.buffer.register_proxy_id_ref("p_first_client", proxy, attr="_node_id")
        doc.buffer._pending.append(
            CreateParagraph(
                text="A",
                at={"kind": "documentEnd"},
                client_node_id="p_first_client",
            ),
        )
        doc.buffer._pending.append(
            SetParagraphAlignment(
                target={
                    "kind": "block",
                    "nodeType": "paragraph",
                    "nodeId": "phantom-id",
                },
                alignment="center",
            ),
        )

        # Batch 1 raises — but rewrites proxy.
        with pytest.raises(BlockNotFoundError):
            doc.buffer.flush()

        assert proxy._node_id == "real_para_1"

        # Batch 2: agent uses the proxy's current id (the cascade fix
        # gave it the real one). Mimic what
        # ``Paragraph.alignment = X`` would do at this point.
        doc.buffer._pending.append(
            SetParagraphAlignment(
                target={
                    "kind": "block",
                    "nodeType": "paragraph",
                    "nodeId": proxy._node_id,
                },
                alignment="left",
            ),
        )
        doc.buffer.flush()

    # Verify the second batch's wire format shipped the REAL id,
    # not the client UUID. Pre-fix, ``proxy._node_id`` would still
    # be 'p_first_client' and SuperDoc would have rejected this
    # batch too.
    assert call_count[0] == 2
    second_batch = posts[1]
    assert second_batch["commands"][0]["target"]["nodeId"] == "real_para_1", (
        "If this is still 'p_first_client', the cascade isn't broken — "
        "the cascade fix's proxy_id_refs rewrite must produce a wire "
        "format that uses real ids on the NEXT batch."
    )
