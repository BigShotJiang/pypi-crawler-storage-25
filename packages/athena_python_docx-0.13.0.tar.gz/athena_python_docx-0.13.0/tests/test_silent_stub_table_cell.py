"""Lock-in tests for ``Table.cell(row_idx, col_idx)`` bounds validation.

Previously ``Table.cell`` would silently construct a ``_Cell`` proxy
for any pair of indices — including out-of-range ones — and the
proxy would only fail later when its address resolved on the wire.
python-docx 1.x raises ``IndexError`` immediately because the
upstream implementation indexes into a fixed-size list (``self._cells``).

These tests pin the new eager-validation behavior so a future
refactor can't silently re-introduce the "fail late" path.
"""

from __future__ import annotations

from typing import Any

import pytest


def _scripted_get(rows: int, cols: int) -> dict:
    return {"rows": rows, "cols": cols, "styleId": "TableGrid"}


def _make_table(mock_session: Any, *, node_id: str = "tbl-1"):
    from docx.table import Table

    return Table(session=mock_session, node_id=node_id)


def test_cell_accepts_valid_indices(mock_session: Any, fake_sd_methods: Any) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 3)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    # All in-range pairs should construct a Cell without raising.
    for row in range(2):
        for col in range(3):
            table.cell(row, col)


def test_cell_raises_index_error_for_row_out_of_range(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 3)
    table = _make_table(mock_session)
    with pytest.raises(IndexError) as excinfo:
        table.cell(5, 0)
    assert "row_idx" in str(excinfo.value)
    assert "2 rows" in str(excinfo.value)


def test_cell_raises_index_error_for_col_out_of_range(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 3)
    table = _make_table(mock_session)
    with pytest.raises(IndexError) as excinfo:
        table.cell(0, 99)
    assert "col_idx" in str(excinfo.value)
    assert "3 columns" in str(excinfo.value)


def test_cell_negative_indices_python_style(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Python-style negative indices: ``-1`` is the last row/column."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 3)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-last"}],
    }
    table = _make_table(mock_session)
    # ``table.cell(-1, -1)`` should resolve to the bottom-right cell
    # without raising. We verify by checking ``_row``/``_col`` on the
    # returned proxy — they should have been normalized.
    cell = table.cell(-1, -1)
    assert cell._row == 1
    assert cell._col == 2


def test_cell_negative_index_out_of_range_still_raises(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A negative index larger than the dimension still raises after
    normalization."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(2, 3)
    table = _make_table(mock_session)
    with pytest.raises(IndexError):
        table.cell(-5, 0)
    with pytest.raises(IndexError):
        table.cell(0, -10)
