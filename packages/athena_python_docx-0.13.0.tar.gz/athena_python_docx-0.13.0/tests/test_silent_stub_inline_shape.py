"""Lock-in tests for InlineShape.width/height None-clear semantics.

python-docx 1.x lets a caller clear an image's explicit dimensions
by assigning ``None`` — the image then renders at its natural size.
Our setters previously early-returned on ``None`` with no signal,
so ``shape.width = None`` was a silent no-op. SuperDoc 1.8 has no
clear-op for ``images.setSize``, so the wire still can't represent
the intent, but we now emit :class:`PendingInlineShapeClearWarning`
so the divergence isn't silent.
"""

from __future__ import annotations

import warnings
from typing import Any


def _make_shape(mock_session: Any, *, node_id: str = "img-1") -> Any:
    from docx.shape import InlineShape

    return InlineShape(
        session=mock_session,
        info={"nodeId": node_id, "size": {"width": 100, "height": 80}},
    )


def test_width_none_emits_warning_and_is_a_no_op(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Setting ``InlineShape.width = None`` emits exactly one
    ``PendingInlineShapeClearWarning`` and issues no ``images.setSize``
    call (the wire can't represent a clear)."""
    from docx.shape import PendingInlineShapeClearWarning

    shape = _make_shape(mock_session)
    before = sum(
        1 for c in fake_sd_methods.calls if c[0] == "images.set_size"
    )
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        shape.width = None
    after = sum(
        1 for c in fake_sd_methods.calls if c[0] == "images.set_size"
    )

    pending = [
        w for w in recorded if issubclass(w.category, PendingInlineShapeClearWarning)
    ]
    assert len(pending) == 1
    assert "width" in str(pending[0].message)
    assert after - before == 0, "None should not trigger images.set_size"


def test_height_none_emits_warning_and_is_a_no_op(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Same contract for ``InlineShape.height = None``."""
    from docx.shape import PendingInlineShapeClearWarning

    shape = _make_shape(mock_session)
    before = sum(
        1 for c in fake_sd_methods.calls if c[0] == "images.set_size"
    )
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        shape.height = None
    after = sum(
        1 for c in fake_sd_methods.calls if c[0] == "images.set_size"
    )

    pending = [
        w for w in recorded if issubclass(w.category, PendingInlineShapeClearWarning)
    ]
    assert len(pending) == 1
    assert "height" in str(pending[0].message)
    assert after - before == 0


def test_width_with_explicit_length_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """The happy path: an explicit ``Length`` still issues an
    ``images.setSize`` call. Pin so the strict-None gate doesn't
    accidentally swallow real assignments."""
    from docx.shape import PendingInlineShapeClearWarning
    from docx.shared import Pt

    shape = _make_shape(mock_session)
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        shape.width = Pt(120)

    size_calls = [
        c for c in fake_sd_methods.calls if c[0] == "images.set_size"
    ]
    assert size_calls, "explicit Length should still issue images.set_size"
    payload = size_calls[-1][1]
    assert payload["imageId"] == "img-1"
    assert payload["size"]["width"] == 120.0
    assert payload["size"]["unit"] == "pt"
    # And no spurious clear-warning on the happy path
    pending = [
        w for w in recorded if issubclass(w.category, PendingInlineShapeClearWarning)
    ]
    assert not pending
