"""Lock-in tests for the silent-stub warnings on ``_HeaderFooter``.

Four operations used to be silent no-ops:

1. ``_HeaderFooter.add_table(rows, cols, width)`` — accepted ``width``
   but never propagated it to SuperDoc (header/footer parts take width
   from layout). The ``_ = width`` placeholder was a silent discard.
2. ``_HeaderFooter.paragraphs`` — returned ``[]`` always (SuperDoc 1.8.1
   has no ``blocks.list({in: {storyType: "headerFooterSlot"}})`` op).
3. ``_HeaderFooter.tables`` — same as ``paragraphs``.
4. ``_HeaderFooter.iter_inner_content`` — same as ``paragraphs``.

These are now warn-and-no-op. ``add_table`` only warns when a
meaningful width is passed (non-None, > 0) — None / 0 callers aren't
expressing intent, so we don't shout at them.

When SuperDoc lands the missing ops, these tests should flip to assert
real wire-bus calls.
"""

from __future__ import annotations

import warnings
from typing import Any

from docx.section import (
    PendingHeaderFooterReadWarning,
    PendingHeaderFooterTableWidthWarning,
    Section,
)
from docx.shared import Emu


# ---------------------------------------------------------------------
# Helpers — mirrors tests/test_phase_b_headers_footers.py
# ---------------------------------------------------------------------


def _make_section(mock_session: Any, *, section_id: str = "sec-1") -> Section:
    return Section(
        session=mock_session,
        address={"kind": "section", "sectionId": section_id},
    )


# ---------------------------------------------------------------------
# add_table width warning
# ---------------------------------------------------------------------


def test_add_table_with_nonzero_width_warns_once(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``add_table(rows, cols, width=Emu(914400))`` should emit
    :class:`PendingHeaderFooterTableWidthWarning` exactly once."""
    fake_sd_methods.scripted_returns["create.table"] = {
        "success": True,
        "table": {"nodeId": "t-1"},
    }
    section = _make_section(mock_session, section_id="sec-1")
    header = section.header

    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        header.add_table(rows=2, cols=2, width=Emu(914400))

    pending = [
        w
        for w in captured
        if issubclass(w.category, PendingHeaderFooterTableWidthWarning)
    ]
    assert len(pending) == 1, f"expected exactly one warning, got {len(pending)}"
    msg = str(pending[0].message)
    assert "add_table" in msg
    assert "rows=2" in msg
    assert "cols=2" in msg
    assert "width" in msg
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in msg


def test_add_table_with_none_width_raises_type_error(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``add_table(rows, cols, width=None)`` MUST raise ``TypeError`` —
    mirrors python-docx 1.x where ``CT_Tbl.new_tbl(rows, cols, None)``
    fails inside the ``CT_TblW`` setter. The previous athena impl
    silently accepted None, which was the only path through
    ``_HeaderFooter.add_table`` that had neither warning nor error
    — a true silent stub.
    """
    import pytest

    fake_sd_methods.scripted_returns["create.table"] = {
        "success": True,
        "table": {"nodeId": "t-1"},
    }
    section = _make_section(mock_session, section_id="sec-1")
    header = section.header

    with pytest.raises(TypeError) as excinfo:
        header.add_table(rows=2, cols=2, width=None)  # type: ignore[arg-type]
    assert "width" in str(excinfo.value).lower()
    assert "none" in str(excinfo.value).lower()


# ---------------------------------------------------------------------
# paragraphs / tables / iter_inner_content read warnings
# ---------------------------------------------------------------------


def test_paragraphs_returns_empty_and_warns_once(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    section = _make_section(mock_session)
    header = section.header

    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        result = header.paragraphs

    assert result == []
    pending = [
        w
        for w in captured
        if issubclass(w.category, PendingHeaderFooterReadWarning)
    ]
    assert len(pending) == 1, f"expected exactly one warning, got {len(pending)}"
    assert "paragraphs" in str(pending[0].message)
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in str(pending[0].message)


def test_tables_returns_empty_and_warns_once(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    section = _make_section(mock_session)
    header = section.header

    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        result = header.tables

    assert result == []
    pending = [
        w
        for w in captured
        if issubclass(w.category, PendingHeaderFooterReadWarning)
    ]
    assert len(pending) == 1, f"expected exactly one warning, got {len(pending)}"
    assert "tables" in str(pending[0].message)
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in str(pending[0].message)


def test_iter_inner_content_returns_empty_and_warns_once(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    section = _make_section(mock_session)
    header = section.header

    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        iterator = header.iter_inner_content()
        items = list(iterator)

    assert items == []
    pending = [
        w
        for w in captured
        if issubclass(w.category, PendingHeaderFooterReadWarning)
    ]
    assert len(pending) == 1, f"expected exactly one warning, got {len(pending)}"
    assert "iter_inner_content" in str(pending[0].message)
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in str(pending[0].message)
