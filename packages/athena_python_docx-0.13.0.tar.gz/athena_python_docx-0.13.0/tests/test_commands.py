"""Unit tests for SDK→Superdoc op translation.

Uses a fake Superdoc SDK surface (see conftest.py) to assert the exact
ops each python-docx call translates into.
"""

from __future__ import annotations

from typing import Any

import pytest

from docx.shared import Pt, RGBColor


def _find_call(calls: list[tuple[str, Any]], op_name: str) -> tuple[str, Any] | None:
    for call in calls:
        if call[0] == op_name:
            return call
    return None


def test_add_paragraph_uses_create_paragraph(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """doc.add_paragraph('hi') → create.paragraph({text: 'hi', at: documentEnd})."""
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False

    doc.add_paragraph("hi")

    call = _find_call(fake_sd_methods.calls, "create.paragraph")
    assert call is not None
    _, params = call
    # add_paragraph pre-mints a client-side UUID for transparent
    # batching (0.7.0+). The UUID is opaque to the test, so we assert
    # the static fields exactly and the UUID by prefix only.
    assert params["text"] == "hi"
    assert params["at"] == {"kind": "documentEnd"}
    assert isinstance(params["client_node_id"], str)
    assert params["client_node_id"].startswith("p_")


def test_add_heading_level_2_uses_create_heading(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False

    doc.add_heading("Section", level=2)

    call = _find_call(fake_sd_methods.calls, "create.heading")
    assert call is not None
    _, params = call
    assert params["text"] == "Section"
    assert params["level"] == 2


def test_add_heading_level_0_uses_title_style(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """level=0 → create.paragraph + style=Title."""
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False

    doc.add_heading("Big Title", level=0)

    call = _find_call(fake_sd_methods.calls, "create.paragraph")
    assert call is not None
    _, params = call
    assert params["text"] == "Big Title"


def test_add_heading_out_of_range_raises(mock_session: Any) -> None:
    from docx.document import Document
    from docx.errors import ValidationError

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False

    with pytest.raises(ValidationError):
        doc.add_heading("bad", level=10)
    with pytest.raises(ValidationError):
        doc.add_heading("bad", level=-1)


def test_add_table_dimensions_validate(mock_session: Any) -> None:
    from docx.document import Document
    from docx.errors import ValidationError

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False

    with pytest.raises(ValidationError):
        doc.add_table(rows=0, cols=3)
    with pytest.raises(ValidationError):
        doc.add_table(rows=3, cols=0)


def test_add_table_calls_create_table_and_optionally_set_style(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False

    doc.add_table(rows=2, cols=3, style="TableGrid")

    create_call = _find_call(fake_sd_methods.calls, "create.table")
    assert create_call is not None
    _, params = create_call
    assert params["rows"] == 2
    assert params["columns"] == 3
    assert params["at"] == {"kind": "documentEnd"}
    assert isinstance(params["client_node_id"], str)
    assert params["client_node_id"].startswith("t_")

    set_style = _find_call(fake_sd_methods.calls, "tables.set_style")
    assert set_style is not None


def test_add_page_break_uses_section_break(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False

    doc.add_page_break()

    call = _find_call(fake_sd_methods.calls, "create.section_break")
    assert call is not None
    _, params = call
    assert params["breakType"] == "nextPage"


def test_run_bold_applies_inline_format(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    from docx.text.run import Run

    r = Run(session=mock_session, block_id="blk", range_=(0, 5))
    r.bold = True

    call = _find_call(fake_sd_methods.calls, "format.apply")
    assert call is not None
    _, params = call
    assert params["target"]["blockId"] == "blk"
    assert params["target"]["range"] == {"start": 0, "end": 5}
    assert params["inline"] == {"bold": True}


def test_run_bold_none_clears_via_null(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """python-docx semantics: ``run.bold = None`` clears the bold mark
    (revert to inherited / unset). The earlier impl silently no-op'd
    on None — broken parity. Now we pass ``None`` through as JSON
    ``null`` on the FormatApply.inline bag so SuperDoc sees the intent."""
    from docx.text.run import Run

    r = Run(session=mock_session, block_id="blk", range_=(0, 5))
    r.bold = None

    call = _find_call(fake_sd_methods.calls, "format.apply")
    assert call is not None, (
        "font.bold = None must emit a format.apply with bold=null, "
        "not silently no-op (was the bug fixed in Phase G round 2)."
    )
    _, params = call
    assert params["inline"]["bold"] is None


def test_run_font_size_converts_pt(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    from docx.text.run import Run

    r = Run(session=mock_session, block_id="blk", range_=(0, 5))
    r.font.size = Pt(14)

    call = _find_call(fake_sd_methods.calls, "format.apply")
    assert call is not None
    _, params = call
    assert params["inline"]["fontSize"] == 14.0


def test_run_color_rgb_applies_hex(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    from docx.text.run import Run

    r = Run(session=mock_session, block_id="blk", range_=(0, 5))
    r.font.color.rgb = RGBColor(0x00, 0x80, 0x00)

    call = _find_call(fake_sd_methods.calls, "format.apply")
    assert call is not None
    _, params = call
    assert params["inline"]["color"] == "008000"


def test_document_factory_rejects_empty() -> None:
    from docx import Document

    with pytest.raises(ValueError):
        Document("")
    with pytest.raises(ValueError):
        Document(None)


def test_extract_inserted_node_id_shapes() -> None:
    from docx.document import _extract_inserted_node_id

    # Canonical shape
    r1 = {
        "result": {
            "insertedNodes": [
                {"nodeId": "n1", "type": "paragraph"},
            ],
        },
    }
    assert _extract_inserted_node_id(r1, expected_type="paragraph") == "n1"

    # Alternate shape ("nodes" instead of "insertedNodes")
    r2 = {
        "result": {
            "nodes": [{"nodeId": "n2", "type": "paragraph"}],
        },
    }
    assert _extract_inserted_node_id(r2, expected_type="paragraph") == "n2"

    # No match — falls back to last node
    r3 = {
        "result": {
            "insertedNodes": [{"nodeId": "nX", "type": "heading"}],
        },
    }
    assert _extract_inserted_node_id(r3, expected_type="paragraph") == "nX"

    # Unparseable — returns empty string
    assert _extract_inserted_node_id({}, expected_type="paragraph") == ""
    assert _extract_inserted_node_id("not a dict", expected_type="paragraph") == ""  # type: ignore[arg-type]


def test_rgbcolor_roundtrip() -> None:
    c = RGBColor(0x12, 0x34, 0x56)
    assert str(c) == "123456"
    assert RGBColor.from_string("#123456") == (0x12, 0x34, 0x56)
    assert RGBColor.from_string("123456") == (0x12, 0x34, 0x56)

    with pytest.raises(ValueError):
        RGBColor(256, 0, 0)
    with pytest.raises(ValueError):
        RGBColor.from_string("abc")


def test_pt_to_emu_conversion() -> None:
    from docx.shared import Emu, Inches, Pt

    assert Inches(1) == Emu(914400)
    assert Pt(12) == Emu(152400)
    assert Pt(12).pt == 12.0
    assert Inches(1).inches == 1.0


def test_run_sync_bridges_coroutine() -> None:
    """The async→sync bridge should run a coroutine and return its result."""
    import asyncio

    from docx._batching import run_sync

    async def _inner() -> int:
        await asyncio.sleep(0.01)
        return 42

    assert run_sync(_inner()) == 42
    # Re-use of loop
    assert run_sync(_inner()) == 42


def test_run_sync_propagates_exception() -> None:
    from docx._batching import run_sync

    async def _raising() -> None:
        raise ValueError("boom")

    with pytest.raises(ValueError, match="boom"):
        run_sync(_raising())
