"""Lock-in tests for ``Run.text`` / ``Run.add_text`` str validation.

Previously both accepted any value and shipped it to wire:

- ``Run.text = 42`` → ``replace({text: 42})`` to wire; SuperDoc's
  permissive parser silently coerced or rejected.
- ``Run.add_text(42)`` → same pattern via ``insert({value: 42})``.

python-docx 1.x routes both through lxml's ``_element_text.text =
value`` which raises ``TypeError`` on non-str. Mirror that.
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_run(mock_session: Any) -> Any:
    from docx.text.run import Run

    return Run(
        session=mock_session,
        block_id="p1",
        range_=(0, 5),
        inline={"text": "hello"},
    )


@pytest.mark.parametrize("value", [42, 1.5, None, [1, 2, 3], {"a": "b"}])
def test_run_text_setter_rejects_non_str(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    run = _make_run(mock_session)
    with pytest.raises(TypeError, match="str"):
        run.text = value


@pytest.mark.parametrize("value", [42, 1.5, None, [1, 2, 3], {"a": "b"}])
def test_run_add_text_rejects_non_str(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    run = _make_run(mock_session)
    with pytest.raises(TypeError, match="str"):
        run.add_text(value)


def test_run_text_setter_with_str_still_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Strict-str gate doesn't break the happy path."""
    run = _make_run(mock_session)
    run.text = "new"
    replace_calls = [
        c for c in fake_sd_methods.calls if c[0] == "replace"
    ]
    assert replace_calls
    assert replace_calls[-1][1]["text"] == "new"


def test_run_add_text_with_str_still_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.add_text("appended")
    insert_calls = [
        c for c in fake_sd_methods.calls if c[0] == "insert"
    ]
    assert insert_calls
    assert insert_calls[-1][1]["value"] == "appended"
