"""Lock-in tests for ``Section.different_first_page_header_footer``
setter — closing the OnOff silent-stub.

Previously this trivalent (``None`` / ``True`` / ``False``) setter
had two silent paths:

1. ``None`` → silent return. python-docx 1.x semantics: clear the
   OOXML ``<w:titlePg/>`` element. SuperDoc 1.8 has no clear-op for
   ``sections.set_title_page``, so the wire can't represent the
   clear-intent. We now emit ``PendingSectionOnOffClearWarning``.

2. Non-bool truthy values went through ``bool(value)``: ``"yes"``
   silently became True. Now: ``TypeError`` (mirrors python-docx's
   ``_OnOff`` strict-bool semantics).
"""

from __future__ import annotations

import warnings
from typing import Any

import pytest


def _make_section(mock_session: Any) -> Any:
    from docx.section import Section

    return Section(
        session=mock_session,
        address={"kind": "section", "sectionIndex": 0},
    )


def test_different_first_page_none_emits_clear_warning(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.section import PendingSectionOnOffClearWarning

    section = _make_section(mock_session)
    before = sum(
        1 for c in fake_sd_methods.calls if c[0] == "sections.set_title_page"
    )
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        section.different_first_page_header_footer = None
    after = sum(
        1 for c in fake_sd_methods.calls if c[0] == "sections.set_title_page"
    )

    pending = [
        w
        for w in recorded
        if issubclass(w.category, PendingSectionOnOffClearWarning)
    ]
    assert len(pending) == 1
    assert "different_first_page_header_footer" in str(pending[0].message)
    assert after - before == 0


def test_different_first_page_rejects_non_bool(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Was: ``section.different_first_page_header_footer = "yes"`` →
    bool() coerced to True. Now: TypeError."""
    section = _make_section(mock_session)
    with pytest.raises(TypeError, match="bool"):
        section.different_first_page_header_footer = "yes"
    with pytest.raises(TypeError, match="bool"):
        section.different_first_page_header_footer = 1


def test_different_first_page_true_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Real bool input still works (the strict-bool gate doesn't
    break the happy path)."""
    section = _make_section(mock_session)
    section.different_first_page_header_footer = True
    title_page_calls = [
        c for c in fake_sd_methods.calls if c[0] == "sections.set_title_page"
    ]
    assert title_page_calls
    assert title_page_calls[-1][1]["enabled"] is True
