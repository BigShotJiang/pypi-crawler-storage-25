"""Lock-in tests for ``Run.add_break`` break_type validation.

Previously two silent paths:

1. ``run.add_break("bogus")`` silently fell through to
   ``insert_line_break`` — caller asked for an unknown break type
   and got a LINE break with no signal.
2. ``run.add_break(42)`` (non-WD_BREAK, non-str) same fallthrough.

python-docx 1.x raises ``KeyError`` on unknown ``break_type`` via
its lookup table. Mirror that with ``ValueError`` (for bogus
strings) and ``TypeError`` (for non-WD_BREAK / non-str).

Happy paths (real WD_BREAK members + canonical string aliases) still
work.
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_run(mock_session: Any) -> Any:
    from docx.text.run import Run

    return Run(
        session=mock_session,
        block_id="p1",
        range_=(0, 5),
        inline={"text": "hello"},
    )


def test_add_break_rejects_bogus_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Was: silent LINE-break fallback. Now: ValueError listing valid
    WD_BREAK member names."""
    run = _make_run(mock_session)
    with pytest.raises(ValueError, match="WD_BREAK"):
        run.add_break("not-a-real-break")


@pytest.mark.parametrize("value", [42, 1.5, None, [1, 2], {"a": "b"}, object()])
def test_add_break_rejects_non_str_non_enum(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    run = _make_run(mock_session)
    with pytest.raises(TypeError, match="WD_BREAK"):
        run.add_break(value)


def test_add_break_accepts_enum_member(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Real WD_BREAK input still works (happy path)."""
    from docx.enum.text import WD_BREAK

    run = _make_run(mock_session)
    run.add_break(WD_BREAK.PAGE)
    section_calls = [
        c
        for c in fake_sd_methods.calls
        if c[0] == "create.section_break"
    ]
    assert section_calls
    assert section_calls[-1][1]["breakType"] == "nextPage"


def test_add_break_accepts_canonical_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """python-docx-style convenience: string matching a member name
    coerces through the enum (case-insensitive)."""
    run = _make_run(mock_session)
    run.add_break("LINE")
    line_calls = [
        c for c in fake_sd_methods.calls if c[0] == "insert_line_break"
    ]
    assert line_calls
