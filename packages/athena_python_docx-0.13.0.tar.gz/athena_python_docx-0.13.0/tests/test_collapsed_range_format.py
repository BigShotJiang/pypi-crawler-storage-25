"""Regression tests for the FormatApply collapsed-range guard.

Repro case (staging session
``thread_39d12733-eef9-4db6-a575-d3c039538468``): the agent wrote::

    p = doc.add_paragraph("Disclaimer text...")
    r = p.add_run("")
    r.italic = True

The ``r.bold/italic/font.color.rgb = ...`` setters used to ship a
``FormatApply`` whose ``target.range`` was ``{start: N, end: N}``
(collapsed) — SuperDoc rejects that batch-wide with
``"format.apply requires a non-collapsed target range."``, the
``execute_word_document_code`` tool returned a ``DocxError``
partial-failure, and the agent then re-ran the whole script.

The guard in ``Run._apply_inline`` now stashes inline attrs in
``_pending_inline`` while the range is collapsed and flushes them on
the next text mutation that gives the run a non-empty range (text
setter, ``add_text``, ``add_tab``, ``add_break``).
"""

from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------
# Empty run: format setters must not ship a collapsed FormatApply.
# ---------------------------------------------------------------------


def test_bold_on_empty_run_does_not_ship_format_apply(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 0))
    run.bold = True

    # Wire-side: no format.apply should have fired — the range is
    # collapsed and SuperDoc would reject it.
    assert not any(
        op == "format.apply" for op, _ in fake_sd_methods.calls
    ), fake_sd_methods.calls

    # Side-band: the inline attrs are stashed and waiting for a
    # subsequent text mutation.
    assert run._pending_inline == {"bold": True}


def test_italic_on_empty_run_does_not_ship_format_apply(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Same guard as bold — reproduces the exact production code path
    that triggered the SuperDocCliError on line 254 of the failing
    investment-memo script."""
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 0))
    run.italic = True

    assert not any(op == "format.apply" for op, _ in fake_sd_methods.calls)
    assert run._pending_inline == {"italic": True}


def test_color_rgb_on_empty_run_does_not_ship_format_apply(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``run.font.color.rgb = RGBColor(...)`` goes through the same
    ``_apply_inline`` helper, so the collapsed-range guard covers it
    too."""
    from docx.shared import RGBColor
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 0))
    run.font.color.rgb = RGBColor(0xC0, 0x00, 0x00)

    assert not any(op == "format.apply" for op, _ in fake_sd_methods.calls)
    assert run._pending_inline == {"color": "C00000"}


def test_multiple_pending_attrs_coalesce(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 0))
    run.bold = True
    run.italic = True

    assert not any(op == "format.apply" for op, _ in fake_sd_methods.calls)
    assert run._pending_inline == {"bold": True, "italic": True}


# ---------------------------------------------------------------------
# Pending attrs flush when text gives the run a non-empty range.
# ---------------------------------------------------------------------


def test_text_setter_flushes_pending_inline(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``r = p.add_run(""); r.bold = True; r.text = "hello"`` —
    mirrors python-docx's "stash on <w:rPr>, apply when text added"
    OOXML semantics."""
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 0))
    run.bold = True
    run.text = "hello"

    # Now the range is (0, 5) — pending bold flushes as a single
    # FormatApply against the non-collapsed range.
    format_calls = [
        (op, params) for op, params in fake_sd_methods.calls if op == "format.apply"
    ]
    assert len(format_calls) == 1, fake_sd_methods.calls
    op, params = format_calls[0]
    assert params is not None
    assert params["inline"] == {"bold": True}
    assert params["target"]["range"] == {"start": 0, "end": 5}
    assert run._pending_inline == {}


def test_add_text_flushes_pending_inline(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 0))
    run.italic = True
    run.add_text("world")

    format_calls = [
        (op, params) for op, params in fake_sd_methods.calls if op == "format.apply"
    ]
    assert len(format_calls) == 1, fake_sd_methods.calls
    op, params = format_calls[0]
    assert params is not None
    assert params["inline"] == {"italic": True}
    # add_text expands the parent run's range to cover the new text.
    assert params["target"]["range"] == {"start": 0, "end": 5}
    assert run._pending_inline == {}


def test_add_tab_flushes_pending_inline(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 0))
    run.bold = True
    run.add_tab()

    format_calls = [
        (op, params) for op, params in fake_sd_methods.calls if op == "format.apply"
    ]
    assert len(format_calls) == 1, fake_sd_methods.calls
    _, params = format_calls[0]
    assert params is not None
    assert params["inline"] == {"bold": True}
    # add_tab adds one offset position, so the range is (0, 1).
    assert params["target"]["range"] == {"start": 0, "end": 1}
    assert run._pending_inline == {}


# ---------------------------------------------------------------------
# Non-collapsed range: behavior unchanged.
# ---------------------------------------------------------------------


def test_bold_on_non_collapsed_run_ships_format_apply_immediately(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 5))
    run.bold = True

    format_calls = [
        (op, params) for op, params in fake_sd_methods.calls if op == "format.apply"
    ]
    assert len(format_calls) == 1
    _, params = format_calls[0]
    assert params is not None
    assert params["inline"] == {"bold": True}
    assert params["target"]["range"] == {"start": 0, "end": 5}
    # Nothing stashed for later — the FormatApply already fired.
    assert run._pending_inline == {}
