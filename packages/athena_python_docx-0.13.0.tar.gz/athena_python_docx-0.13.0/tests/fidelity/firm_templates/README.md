# Firm-template fidelity corpus

Round-trip regression tests against real customer-template DOCX files
that exercise the long-tail OOXML surface — custom themes, anchored
(floating) drawings, floating tables (``tblpPr``), SDT picture controls,
three-way headers/footers, bookmarks, and custom paragraph/character
style hierarchies. These features are the headline value that
``athena-python-docx`` + Olympus's Superdoc renderer deliver over a
"plain-ish" rendered surface, so the fidelity bar against them must
be enforced explicitly.

## What this directory does

Each ``test_*.py`` in this directory drives a single real-world DOCX
through Superdoc's headless round-trip (the same ``Editor.open`` →
``editor.exportDocx()`` path Olympus's
``SuperDocumentYjsRendererCore`` uses), then asserts a per-file
**feature scorecard** against the exported ``.docx``. The harness is
the same bun script production uses:

```
agora/converter-olympus/src/superdoc/fidelity-roundtrip.ts
```

A scorecard diff (e.g. ``anchored drawings: 1 -> 0``) is an immediate
fail — the failure mode we're guarding against is a Superdoc upgrade
silently dropping a feature.

## Why the corpus isn't committed

The corpus files originate from production customer uploads and are
covered by the same data-handling rules as anything else in the
``PaulWeiss`` (and similar) workspaces — they're not shipped in source
control. The tests skip when the corpus dir is empty, so this is a
no-op for everyday CI and a hard regression check when the corpus is
mounted (manual local runs, the ``docx-fidelity`` integration runner,
etc.).

## Corpus layout

Default lookup path: ``$ATHENA_PW_CORPUS_DIR`` (override) →
``$HOME/Downloads/pw-docx`` (developer default).

Expected files (per ``docs/pw-docx/MANIFEST.md`` in the upload bundle):

```
$ATHENA_PW_CORPUS_DIR/
├── MANIFEST.md
├── cgalerman_paulweisscom/
│   ├── Debt_Report_Non_US_Fortune_500_Eligible__1.docx
│   ├── Final_List__1.docx
│   └── …
├── dwuchenich_paulweisscom/
│   └── Harvey_Demo_-_Purchase_Agreement_PW_Draft_07.30.2025_-_sent_to_Opposing_Counsel_28159607.1.docx
├── mdumont_paulweisscom/
│   └── AI_Research_Digest_122225_1.docx          ← golden case (see test_pw_research_digest.py)
├── mlross_paulweisscom/
│   ├── 02_Template_Detailed_Case_Study.docx
│   ├── 03_Template_One_Pager.docx
│   ├── 04_Template_Snippets_Inserts.docx
│   └── Client_Requests.docx
└── scrider_paulweisscom/
    ├── PW_Model_Discovery_Plan_ESI_Protocol__1.docx
    ├── sample_ESI_protocol_28349375.1__3.docx
    └── …
```

If the corpus is mounted at a different location, set
``ATHENA_PW_CORPUS_DIR`` and the tests will pick it up.

## Running locally

From the repo root:

```bash
# All firm-template scorecards
cd docx-studio/python-sdk && uv run pytest tests/fidelity/firm_templates/ -v

# Just the AI Research Digest
cd docx-studio/python-sdk && \
  uv run pytest tests/fidelity/firm_templates/test_pw_research_digest.py -v

# With a custom corpus path
ATHENA_PW_CORPUS_DIR=/path/to/corpus \
  uv run pytest tests/fidelity/firm_templates/ -v
```

The tests need ``bun`` on ``PATH`` (to drive the headless Superdoc
script) and ``node_modules`` installed at the repo root (``bun
install``). Tests skip cleanly when either is missing.

## Adding a new firm-template case

1. Drop the DOCX into the corpus dir under the right sub-folder.
2. Run the helper to print the current feature scorecard:

   ```bash
   uv run python tests/fidelity/firm_templates/extractor.py \
     "$ATHENA_PW_CORPUS_DIR/sub_folder/file.docx"
   ```

3. Copy a new ``test_*.py`` from
   ``test_pw_research_digest.py`` as the template and paste the
   scorecard's exact counts into ``EXPECTED_SCORECARD``.
4. Tighten / loosen any tolerances that legitimately drift (image
   extent rounding is currently +/-2% per
   ``SUPERDOC_UPSTREAM_REQUESTS.md`` § 16).
