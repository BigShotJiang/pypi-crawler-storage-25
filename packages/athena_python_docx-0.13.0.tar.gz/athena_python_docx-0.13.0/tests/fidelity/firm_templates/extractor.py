"""Feature scorecard extractor for DOCX files.

Counts OOXML features in ``word/document.xml`` plus a handful of other
parts (styles, theme, headers/footers). The output is the dict that
:mod:`test_pw_research_digest` and siblings assert against.

The shape of the scorecard intentionally favors features that *changes
to the renderer* are likely to regress — high-fidelity preservation
features like anchored drawings, ``tblpPr`` floating tables, SDT
content controls, multi-page header/footer wiring, bookmarks, and the
custom-style universe a firm template carries.

CLI usage:

.. code:: bash

    python tests/fidelity/firm_templates/extractor.py path/to/file.docx
"""

from __future__ import annotations

import re
import sys
import zipfile
from typing import TypedDict


class Scorecard(TypedDict):
    """Per-file OOXML feature counts.

    All counts come from string-level regex over the relevant parts;
    we do not parse the namespaced XML to keep the extractor dependency-
    free. Names mirror OOXML element / attribute names so the failure
    message is grep-able against ``word/document.xml``.
    """

    paragraphs: int
    tables: int
    table_rows: int
    table_cells: int
    drawings: int
    anchored_drawings: int
    inline_drawings: int
    hyperlinks: int
    bookmarks: int
    sdt_controls: int
    page_breaks: int
    tabs: int
    line_breaks: int
    sections: int
    section_props: int
    floating_tables: int
    custom_pstyle_names: tuple[str, ...]
    custom_rstyle_names: tuple[str, ...]
    custom_tblstyle_names: tuple[str, ...]
    header_count: int
    footer_count: int
    paragraph_style_defs: int
    character_style_defs: int
    table_style_defs: int
    custom_style_defs: int
    image_files: int


def _read(zf: zipfile.ZipFile, name: str) -> str:
    try:
        return zf.read(name).decode("utf-8", errors="replace")
    except KeyError:
        return ""


def extract(path: str) -> Scorecard:
    """Open ``path`` and return its feature scorecard."""

    with zipfile.ZipFile(path) as zf:
        document = _read(zf, "word/document.xml")
        styles = _read(zf, "word/styles.xml")
        names = zf.namelist()

    # Count <w:hyperlink> elements plus fldChar-style HYPERLINK fields
    # so the total survives Superdoc's fldChar -> <w:hyperlink>
    # normalization on round-trip — both forms encode the same logical
    # hyperlink. Other field codes (PAGE, REF, …) sharing the fldChar
    # surface are filtered out by matching only ``HYPERLINK`` in
    # ``<w:instrText>``.
    hyperlink_elem_count = len(re.findall(r"<w:hyperlink\b", document))
    fld_hyperlink_count = len(
        re.findall(r"<w:instrText[^>]*>\s*HYPERLINK\b", document)
    )

    custom_pstyles = tuple(
        sorted(set(re.findall(r'<w:pStyle w:val="([^"]+)"', document)))
    )
    custom_rstyles = tuple(
        sorted(set(re.findall(r'<w:rStyle w:val="([^"]+)"', document)))
    )
    custom_tblstyles = tuple(
        sorted(set(re.findall(r'<w:tblStyle w:val="([^"]+)"', document)))
    )

    header_count = sum(1 for n in names if re.match(r"word/header\d+\.xml", n))
    footer_count = sum(1 for n in names if re.match(r"word/footer\d+\.xml", n))
    # Filter out the zero-byte ``word/media/`` directory entry Superdoc
    # emits on export (Bun / yauzl writes the dir as a member; the
    # original Word save does not). Real image files always carry an
    # extension.
    image_files = sum(
        1
        for n in names
        if n.startswith("word/media/") and "." in n.rsplit("/", 1)[-1]
    )

    return Scorecard(
        # Match ``<w:p>`` (no attrs) AND ``<w:p ...>`` AND ``<w:p/>`` (self-closing).
        # An earlier draft used ``<w:p\b[^>]`` which dropped attribute-less
        # paragraphs (``<w:p>``) — common in cells whose rsids never
        # ratcheted, so heavily table-based templates undercounted by
        # 30-80%. Match on the canonical pattern instead.
        paragraphs=len(re.findall(r"<w:p[\s/>]", document)),
        tables=len(re.findall(r"<w:tbl>", document)),
        table_rows=len(re.findall(r"<w:tr\b", document)),
        table_cells=len(re.findall(r"<w:tc[\s>]", document)),
        drawings=len(re.findall(r"<w:drawing>", document)),
        anchored_drawings=len(re.findall(r"<wp:anchor", document)),
        inline_drawings=len(re.findall(r"<wp:inline", document)),
        hyperlinks=hyperlink_elem_count + fld_hyperlink_count,
        bookmarks=len(re.findall(r"<w:bookmarkStart\b", document)),
        sdt_controls=len(re.findall(r"<w:sdt>", document)),
        page_breaks=len(re.findall(r'w:type="page"', document)),
        tabs=len(re.findall(r"<w:tab(?:\s|/)", document)),
        line_breaks=len(re.findall(r"<w:br(?:\s|/|>)", document)),
        sections=len(re.findall(r"<w:sectPr\b", document)),
        section_props=len(re.findall(r"<w:sectPr\b", document)),
        floating_tables=len(re.findall(r"<w:tblpPr\b", document)),
        custom_pstyle_names=custom_pstyles,
        custom_rstyle_names=custom_rstyles,
        custom_tblstyle_names=custom_tblstyles,
        header_count=header_count,
        footer_count=footer_count,
        paragraph_style_defs=len(
            re.findall(r'<w:style[^>]*w:type="paragraph"', styles)
        ),
        character_style_defs=len(
            re.findall(r'<w:style[^>]*w:type="character"', styles)
        ),
        table_style_defs=len(re.findall(r'<w:style[^>]*w:type="table"', styles)),
        custom_style_defs=len(
            re.findall(r'<w:style[^>]*w:customStyle="1"', styles)
        ),
        image_files=image_files,
    )


def diff(
    expected: Scorecard, actual: Scorecard
) -> list[tuple[str, object, object]]:
    """Return list of ``(field, expected, actual)`` mismatches."""
    mismatches: list[tuple[str, object, object]] = []
    for key in expected.keys():
        if expected[key] != actual[key]:
            mismatches.append((key, expected[key], actual[key]))
    return mismatches


def _print(path: str) -> None:
    """CLI helper: print the scorecard as a copy-pasteable dict."""
    sc = extract(path)
    print(f"# Scorecard for {path}")
    print("EXPECTED_SCORECARD: Scorecard = Scorecard(")
    for k, v in sc.items():
        if isinstance(v, tuple):
            inner = ", ".join(f'"{x}"' for x in v)
            print(f"    {k}=({inner},),")
        else:
            print(f"    {k}={v!r},")
    print(")")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python extractor.py path/to/file.docx", file=sys.stderr)
        sys.exit(2)
    _print(sys.argv[1])
