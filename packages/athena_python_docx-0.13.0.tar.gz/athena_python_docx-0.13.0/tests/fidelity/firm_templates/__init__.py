"""Firm-template fidelity corpus.

Round-trip regression tests against real customer-template DOCX files
that exercise the long-tail OOXML surface (custom themes, anchored
drawings, floating tables, SDT controls, three-way headers/footers,
bookmarks, …).

The actual ``.docx`` files are NOT committed — they originate from
production customer workspaces and are loaded from a local corpus dir
at test time. See ``README.md`` for layout and how to populate.
"""
