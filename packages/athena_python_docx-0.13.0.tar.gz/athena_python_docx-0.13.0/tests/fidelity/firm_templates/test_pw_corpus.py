"""Corpus-wide round-trip fidelity regression for the Paul Weiss firm
templates.

Parameterizes the headless Superdoc round-trip
(``agora/converter-olympus/src/superdoc/fidelity-roundtrip.ts``) over
every doc in the PW corpus and pins the per-doc OOXML scorecard. A
scorecard diff (e.g. ``anchored_drawings: 1 → 0``) fails the test —
that's the failure mode we're guarding against: a Superdoc upgrade
silently dropping a feature that one of the docs relies on.

Each entry maps a stable label to:
  * the corpus-relative path
  * an ``EXPECTED_SCORECARD`` captured 2026-05-17 from the source doc
    (used as the lock-in baseline AND as the round-trip target)
  * an ``xfail_reason`` if Superdoc currently regresses the doc on
    round-trip; the test is marked ``xfail(strict=True)`` so the
    regression is visible without making CI red — and so a fix on
    the Superdoc side flips the test to UNEXPECTED PASS and we know
    to unmark it.

Source DOCX bytes are NOT committed (they're production customer
content). The tests skip cleanly when the corpus is missing — see
``README.md`` for layout.

For the golden case (``test_pw_research_digest.py``) we keep a
separate test file because it has the most thorough doc-level
narrative; this file is the corpus-wide sweep.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pytest

from tests.fidelity.firm_templates._runner import require_case, run_round_trip
from tests.fidelity.firm_templates.extractor import Scorecard, diff, extract


@dataclass(frozen=True)
class CorpusDoc:
    label: str
    rel_path: str
    expected: Scorecard
    # Reason the round-trip is currently expected to fail. None when
    # the doc round-trips cleanly. When set, ``test_round_trip`` is
    # xfailed (strict) so a Superdoc upgrade that fixes the regression
    # surfaces as UNEXPECTED PASS rather than silently flipping.
    xfail_reason: str | None = None


# Per-doc captured scorecards. Captured 2026-05-17 from the corpus
# source files via ``extractor.py``; these values pin the round-trip
# output too (the bytes-in == bytes-out guarantee for everything
# except Purchase_Agreement, which is xfailed below).
CORPUS: list[CorpusDoc] = [
    CorpusDoc(
        label="AI_Research_Digest",
        rel_path="mdumont_paulweisscom/AI_Research_Digest_122225_1.docx",
        expected=Scorecard(
            paragraphs=71, tables=1, table_rows=4, table_cells=5,
            drawings=1, anchored_drawings=1, inline_drawings=0,
            hyperlinks=11, bookmarks=1, sdt_controls=1, page_breaks=1,
            tabs=2, line_breaks=4, sections=1, section_props=1,
            floating_tables=1,
            custom_pstyle_names=("BodyText", "ContactInfo", "DraftText", "Footer", "GrouporPracticeName", "Title"),
            custom_rstyle_names=("Hyperlink",),
            custom_tblstyle_names=("SimpleTable",),
            header_count=3, footer_count=3,
            paragraph_style_defs=57, character_style_defs=57,
            table_style_defs=6, custom_style_defs=85, image_files=1,
        ),
    ),
    CorpusDoc(
        label="ESI_Protocol_sample",
        rel_path="scrider_paulweisscom/sample_ESI_protocol_28349375.1__3.docx",
        expected=Scorecard(
            paragraphs=420, tables=7, table_rows=53, table_cells=141,
            drawings=0, anchored_drawings=0, inline_drawings=0,
            hyperlinks=0, bookmarks=3, sdt_controls=0, page_breaks=1,
            tabs=92, line_breaks=6, sections=3, section_props=3,
            floating_tables=0,
            custom_pstyle_names=(
                "BodyText", "BodyTextIndent", "Exactly12-Signature",
                "Heading2", "ListNumber", "ListNumber3", "ListNumber4",
                "ListParagraph", "SingleSpacing",
            ),
            custom_rstyle_names=("FootnoteReference", "Heading2Char"),
            custom_tblstyle_names=("TableGrid",),
            header_count=3, footer_count=5,
            paragraph_style_defs=39, character_style_defs=24,
            table_style_defs=2, custom_style_defs=31, image_files=0,
        ),
    ),
    CorpusDoc(
        label="Client_Requests",
        rel_path="mlross_paulweisscom/Client_Requests.docx",
        expected=Scorecard(
            paragraphs=83, tables=3, table_rows=23, table_cells=58,
            drawings=0, anchored_drawings=0, inline_drawings=0,
            hyperlinks=0, bookmarks=0, sdt_controls=0, page_breaks=0,
            tabs=0, line_breaks=3, sections=1, section_props=1,
            floating_tables=0,
            custom_pstyle_names=("BodyText",),
            custom_rstyle_names=(),
            custom_tblstyle_names=(),
            header_count=3, footer_count=3,
            paragraph_style_defs=59, character_style_defs=47,
            table_style_defs=1, custom_style_defs=75, image_files=0,
        ),
    ),
    CorpusDoc(
        label="Final_List",
        rel_path="cgalerman_paulweisscom/Final_List__1.docx",
        expected=Scorecard(
            paragraphs=190, tables=1, table_rows=27, table_cells=189,
            drawings=0, anchored_drawings=0, inline_drawings=0,
            hyperlinks=0, bookmarks=0, sdt_controls=0, page_breaks=0,
            tabs=0, line_breaks=0, sections=1, section_props=1,
            floating_tables=0,
            custom_pstyle_names=(),
            custom_rstyle_names=(),
            custom_tblstyle_names=(),
            header_count=1, footer_count=0,
            paragraph_style_defs=14, character_style_defs=6,
            table_style_defs=1, custom_style_defs=4, image_files=0,
        ),
    ),
    CorpusDoc(
        label="Template_Snippets",
        rel_path="mlross_paulweisscom/04_Template_Snippets_Inserts.docx",
        expected=Scorecard(
            paragraphs=84, tables=8, table_rows=12, table_cells=17,
            drawings=0, anchored_drawings=0, inline_drawings=0,
            hyperlinks=0, bookmarks=0, sdt_controls=0, page_breaks=3,
            tabs=0, line_breaks=3, sections=1, section_props=1,
            floating_tables=0,
            custom_pstyle_names=("Heading1", "Heading3"),
            custom_rstyle_names=(),
            custom_tblstyle_names=(),
            header_count=0, footer_count=0,
            paragraph_style_defs=13, character_style_defs=3,
            table_style_defs=0, custom_style_defs=0, image_files=0,
        ),
    ),
    CorpusDoc(
        label="Debt_Report",
        rel_path="cgalerman_paulweisscom/Debt_Report_Non_US_Fortune_500_Eligible__1.docx",
        expected=Scorecard(
            paragraphs=81, tables=1, table_rows=27, table_cells=81,
            drawings=0, anchored_drawings=0, inline_drawings=0,
            hyperlinks=0, bookmarks=0, sdt_controls=0, page_breaks=0,
            tabs=0, line_breaks=0, sections=1, section_props=1,
            floating_tables=0,
            custom_pstyle_names=(),
            custom_rstyle_names=(),
            custom_tblstyle_names=(),
            header_count=0, footer_count=0,
            paragraph_style_defs=10, character_style_defs=3,
            table_style_defs=0, custom_style_defs=0, image_files=0,
        ),
    ),
    CorpusDoc(
        label="PW_ESI_Protocol",
        rel_path="scrider_paulweisscom/PW_Model_Discovery_Plan_ESI_Protocol__1.docx",
        expected=Scorecard(
            paragraphs=274, tables=1, table_rows=45, table_cells=135,
            drawings=0, anchored_drawings=0, inline_drawings=0,
            hyperlinks=0, bookmarks=0, sdt_controls=0, page_breaks=3,
            tabs=72, line_breaks=4, sections=1, section_props=1,
            floating_tables=0,
            custom_pstyle_names=(
                "BodyText", "BodyTextHang", "BodyTextIndent3",
                "CenterSingle", "Heading1", "Heading2", "Heading3",
                "Heading4", "LeftSingle", "Signature",
            ),
            custom_rstyle_names=(),
            custom_tblstyle_names=(),
            header_count=3, footer_count=3,
            paragraph_style_defs=62, character_style_defs=43,
            table_style_defs=1, custom_style_defs=73, image_files=0,
        ),
    ),
    CorpusDoc(
        label="Template_One_Pager",
        rel_path="mlross_paulweisscom/03_Template_One_Pager.docx",
        expected=Scorecard(
            paragraphs=37, tables=5, table_rows=7, table_cells=11,
            drawings=0, anchored_drawings=0, inline_drawings=0,
            hyperlinks=0, bookmarks=0, sdt_controls=0, page_breaks=0,
            tabs=0, line_breaks=0, sections=1, section_props=1,
            floating_tables=0,
            custom_pstyle_names=("Heading2",),
            custom_rstyle_names=(),
            custom_tblstyle_names=(),
            header_count=0, footer_count=0,
            paragraph_style_defs=12, character_style_defs=3,
            table_style_defs=0, custom_style_defs=0, image_files=0,
        ),
    ),
    CorpusDoc(
        label="Template_Case_Study",
        rel_path="mlross_paulweisscom/02_Template_Detailed_Case_Study.docx",
        expected=Scorecard(
            paragraphs=117, tables=3, table_rows=9, table_cells=23,
            drawings=0, anchored_drawings=0, inline_drawings=0,
            hyperlinks=0, bookmarks=0, sdt_controls=0, page_breaks=1,
            tabs=0, line_breaks=1, sections=1, section_props=1,
            floating_tables=0,
            custom_pstyle_names=("Heading1", "Heading2", "Heading3"),
            custom_rstyle_names=(),
            custom_tblstyle_names=(),
            header_count=0, footer_count=0,
            paragraph_style_defs=13, character_style_defs=3,
            table_style_defs=0, custom_style_defs=0, image_files=0,
        ),
    ),
    CorpusDoc(
        label="Purchase_Agreement",
        rel_path=(
            "dwuchenich_paulweisscom/"
            "Harvey_Demo_-_Purchase_Agreement_PW_Draft_07.30.2025_"
            "-_sent_to_Opposing_Counsel_28159607.1.docx"
        ),
        expected=Scorecard(
            paragraphs=776, tables=4, table_rows=4, table_cells=8,
            drawings=0, anchored_drawings=0, inline_drawings=0,
            hyperlinks=102, bookmarks=1989, sdt_controls=0,
            page_breaks=3, tabs=242, line_breaks=59, sections=5,
            section_props=5, floating_tables=0,
            custom_pstyle_names=(
                "Article2L3", "BodyFirstLine1", "BodyFirstLine5",
                "BodyIndent", "BodyIndent1", "BodyIndent15",
                "BodyText", "BodyTextjustified", "Center",
                "CenterBold", "Date", "Heading1", "Heading2",
                "Heading3", "Heading4", "SingleParaAlt", "TOC1",
                "TOC2", "Title", "TitleRight",
            ),
            custom_rstyle_names=(
                "DTPunctuation", "DefinedTerm", "FootnoteReference",
                "HeadingBody2Char", "Hyperlink", "IntenseReference",
            ),
            custom_tblstyle_names=("TableGrid",),
            header_count=10, footer_count=12,
            paragraph_style_defs=119, character_style_defs=54,
            table_style_defs=2, custom_style_defs=118, image_files=0,
        ),
        xfail_reason=(
            "Superdoc § 18 strips REF field codes on import: 1989 → 1974 "
            "bookmarks (15 _9kMxxx co-author bookmarks dropped) AND every "
            "REF cross-reference's visible result text disappears, leaving "
            'definitions like "Estimated Cash shall have the meaning set forth in" '
            "without their trailing Section reference. Pinned strict so a Superdoc "
            "fix surfaces as UNEXPECTED PASS. See docs/PW_CORPUS_FIDELITY_ASSESSMENT.md "
            "§ 3 and SUPERDOC_UPSTREAM_REQUESTS.md § 18."
        ),
    ),
]


_LABELS_TO_IDS = [doc.label for doc in CORPUS]


# Style-table cosmetics that Superdoc routinely adds on export (default
# styles like ``Normal`` / ``DefaultParagraphFont`` that get re-emitted
# even if the source already had them). Verified across the PW corpus:
# adds 1-2 entries in 5 of 10 docs without any visible-output change.
# Excluded from the round-trip comparison because they're benign — but
# the source-baseline test still pins them, so a real corpus-file
# replacement still fails.
_ROUND_TRIP_COSMETIC_FIELDS: frozenset[str] = frozenset({
    "paragraph_style_defs",
    "character_style_defs",
})


def _format_diff(header: str, mismatches: list[tuple[str, object, object]]) -> str:
    lines = [header, ""]
    for field, expected, actual in mismatches:
        lines.append(f"  {field}: expected={expected!r}, actual={actual!r}")
    return "\n".join(lines)


@pytest.mark.parametrize("doc", CORPUS, ids=_LABELS_TO_IDS)
def test_source_scorecard_matches_baseline(doc: CorpusDoc) -> None:
    """The source doc itself must still match the captured scorecard.

    Fails first if a corpus file has been replaced or updated — that
    way we know to refresh ``EXPECTED_SCORECARD`` before chasing a
    phantom Superdoc regression.
    """
    source = require_case(doc.rel_path)
    actual = extract(str(source))
    mismatches = diff(doc.expected, actual)
    assert not mismatches, _format_diff(
        f"Source {doc.label} no longer matches its captured scorecard",
        mismatches,
    )


@pytest.fixture(scope="module")
def _corpus_round_trip_outputs(
    tmp_path_factory: pytest.TempPathFactory,
) -> dict[str, Path]:
    """Round-trip every corpus doc once and cache the outputs.

    Per-test setup of a fresh round-trip would multiply Superdoc
    import time by N (the Harvey Purchase Agreement alone is ~10s),
    so we share one output per doc across the parametrized tests.
    Skips per-doc if its source is missing — the parametrized test
    body then skips with the same reason.
    """
    out_dir = tmp_path_factory.mktemp("pw_corpus")
    outputs: dict[str, Path] = {}
    for doc in CORPUS:
        source = Path.home() / "Downloads" / "pw-docx" / doc.rel_path
        import os
        env = os.environ.get("ATHENA_PW_CORPUS_DIR")
        if env:
            source = Path(env) / doc.rel_path
        if not source.is_file():
            continue
        out = out_dir / f"{doc.label}.rt.docx"
        run_round_trip(source, out)
        outputs[doc.label] = out
    return outputs


@pytest.mark.parametrize("doc", CORPUS, ids=_LABELS_TO_IDS)
def test_round_trip_preserves_scorecard(
    doc: CorpusDoc,
    _corpus_round_trip_outputs: dict[str, Path],
    request: pytest.FixtureRequest,
) -> None:
    """The Superdoc round-trip must preserve the per-doc scorecard.

    Docs in the ``xfail_reason`` regime are marked ``xfail(strict=True)``
    — currently only the Harvey Purchase Agreement, which loses all 301
    REF field result texts (see Superdoc upstream § 18).
    """
    # Make sure bun + corpus are available; otherwise skip with a clean
    # reason. ``require_case`` raises a pytest.skip on missing source.
    require_case(doc.rel_path)

    if doc.xfail_reason is not None:
        request.applymarker(
            pytest.mark.xfail(reason=doc.xfail_reason, strict=True)
        )

    out_path = _corpus_round_trip_outputs.get(doc.label)
    if out_path is None:
        pytest.skip(
            f"No round-trip output for {doc.label} — source missing in corpus dir."
        )
    actual = extract(str(out_path))
    mismatches = [
        d for d in diff(doc.expected, actual)
        if d[0] not in _ROUND_TRIP_COSMETIC_FIELDS
    ]
    assert not mismatches, _format_diff(
        f"Superdoc round-trip regressed {doc.label}",
        mismatches,
    )
