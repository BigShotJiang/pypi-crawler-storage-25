"""Shared helpers for firm-template round-trip tests.

Drives the production headless Superdoc round-trip
(``agora/converter-olympus/src/superdoc/fidelity-roundtrip.ts``) via
``bun`` and returns the exported ``.docx`` for downstream scorecard
extraction. Tests use this so each ``test_*.py`` is just a corpus
filename + an ``EXPECTED_SCORECARD``.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import TypedDict

import pytest


# Walk up from this file:
#   docx-studio/python-sdk/tests/fidelity/firm_templates/_runner.py
#   parents: [firm_templates, fidelity, tests, python-sdk, docx-studio, <repo>]
_REPO_ROOT = Path(__file__).resolve().parents[5]
_ROUND_TRIP_SCRIPT = (
    _REPO_ROOT
    / "agora"
    / "converter-olympus"
    / "src"
    / "superdoc"
    / "fidelity-roundtrip.ts"
)


def corpus_dir() -> Path:
    """Resolve the firm-template corpus directory.

    Honors ``ATHENA_PW_CORPUS_DIR`` if set; otherwise falls back to the
    developer default at ``$HOME/Downloads/pw-docx``. The path may or
    may not exist — callers should ``pytest.skip`` when the requested
    case isn't present.
    """
    env = os.environ.get("ATHENA_PW_CORPUS_DIR")
    if env:
        return Path(env)
    return Path.home() / "Downloads" / "pw-docx"


def require_case(rel_path: str) -> Path:
    """Return the corpus path or skip the test cleanly.

    ``rel_path`` is the path relative to the corpus dir (e.g.
    ``mdumont_paulweisscom/AI_Research_Digest_122225_1.docx``).
    """
    full = corpus_dir() / rel_path
    if not full.is_file():
        pytest.skip(
            f"Firm-template corpus file not present: {full}. "
            "See tests/fidelity/firm_templates/README.md."
        )
    return full


def require_bun() -> str:
    bun = shutil.which("bun")
    if not bun:
        pytest.skip("bun not on PATH; required for Superdoc headless round-trip.")
    if not _ROUND_TRIP_SCRIPT.is_file():
        pytest.skip(f"Round-trip script missing: {_ROUND_TRIP_SCRIPT}")
    if not (_REPO_ROOT / "node_modules").exists():
        pytest.skip(
            "node_modules not installed at repo root; run `bun install` first."
        )
    return bun


class RoundTripReport(TypedDict):
    input: str
    output: str
    bytesOut: int
    importMs: int
    exportMs: int
    loadedCounts: dict


@dataclass(frozen=True)
class RoundTripResult:
    input_path: Path
    output_path: Path
    report: RoundTripReport


def run_round_trip(input_path: Path, output_path: Path) -> RoundTripResult:
    """Execute the headless Superdoc round-trip and parse the JSON report.

    The script writes one JSON line to stdout. Anything else (e.g.
    ``[super-editor] Telemetry: enabled``) is logged to stderr.
    """
    bun = require_bun()
    result = subprocess.run(
        [
            bun,
            "run",
            str(_ROUND_TRIP_SCRIPT),
            str(input_path),
            str(output_path),
        ],
        cwd=str(_REPO_ROOT),
        capture_output=True,
        text=True,
        timeout=120,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"Superdoc round-trip failed (exit={result.returncode}).\n"
            f"stdout: {result.stdout!r}\n"
            f"stderr: {result.stderr!r}"
        )

    # Pull the last JSON line out of stdout — the script prints exactly
    # one JSON object plus arbitrary stderr/telemetry lines.
    payload: RoundTripReport | None = None
    for line in reversed(result.stdout.splitlines()):
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            try:
                payload = json.loads(line)
                break
            except json.JSONDecodeError:
                continue
    if payload is None:
        raise RuntimeError(
            "Superdoc round-trip did not emit a JSON report.\n"
            f"stdout: {result.stdout!r}\n"
            f"stderr: {result.stderr!r}"
        )

    return RoundTripResult(
        input_path=input_path,
        output_path=output_path,
        report=payload,
    )
