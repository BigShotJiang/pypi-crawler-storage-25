"""Round-trip fidelity regression for the Paul Weiss AI Research Digest.

This file is the **golden case** for the firm-template corpus. It
drives the production headless Superdoc round-trip on
``mdumont_paulweisscom/AI_Research_Digest_122225_1.docx`` and asserts
the resulting ``.docx`` preserves the long-tail OOXML surface the
Paul Weiss firm template depends on:

* anchored (floating) drawing with ``behindDoc`` + ``wrapNone`` for the
  banner image at the top of the deck
* floating table (``tblpPr``) hosting the title block
* three-way header/footer (first / even / default)
* SDT picture content control (Word smart-bookmark for the banner)
* fldChar HYPERLINK + ``<w:hyperlink>`` mix (Superdoc normalizes the
  fldChar form on export — we still expect the same logical hyperlink
  count)
* the 85-style custom-style universe and the Paul Weiss theme

If a Superdoc upgrade silently drops one of these, this test fails
with a precise scorecard diff. The corpus file is loaded from
``$ATHENA_PW_CORPUS_DIR`` (default ``~/Downloads/pw-docx``); the test
skips cleanly when the file isn't present so CI without the corpus
doesn't fail.

The two known Superdoc imperfections — anchored-drawing extent
rounding (~1.5%) and theme color attribute normalization to literal
colors — are tracked in ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md``
§ 16 / § 17 and do not affect the scorecard fields below.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.fidelity.firm_templates._runner import require_case, run_round_trip
from tests.fidelity.firm_templates.extractor import Scorecard, diff, extract


CORPUS_REL_PATH = "mdumont_paulweisscom/AI_Research_Digest_122225_1.docx"


# Captured 2026-05-17 from the original PW upload. Counts come from
# ``tests/fidelity/firm_templates/extractor.py`` on the source file;
# they are byte-for-byte identical on the Superdoc 1.23.1 / SDK 1.8.1
# round-trip output.
EXPECTED_SCORECARD: Scorecard = Scorecard(
    paragraphs=71,
    tables=1,
    table_rows=4,
    table_cells=5,
    drawings=1,
    anchored_drawings=1,
    inline_drawings=0,
    hyperlinks=11,
    bookmarks=1,
    sdt_controls=1,
    page_breaks=1,
    tabs=2,
    line_breaks=4,
    sections=1,
    section_props=1,
    floating_tables=1,
    custom_pstyle_names=(
        "BodyText",
        "ContactInfo",
        "DraftText",
        "Footer",
        "GrouporPracticeName",
        "Title",
    ),
    custom_rstyle_names=("Hyperlink",),
    custom_tblstyle_names=("SimpleTable",),
    header_count=3,
    footer_count=3,
    paragraph_style_defs=57,
    character_style_defs=57,
    table_style_defs=6,
    custom_style_defs=85,
    image_files=1,
)


@pytest.fixture(scope="module")
def round_trip_artifact(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Run the headless Superdoc round-trip once and reuse the output."""
    input_path = require_case(CORPUS_REL_PATH)
    out_dir = tmp_path_factory.mktemp("pw_research_digest")
    output_path = out_dir / "round_tripped.docx"
    run_round_trip(input_path, output_path)
    return output_path


def test_source_scorecard_matches_expected() -> None:
    """The source file itself must match ``EXPECTED_SCORECARD``.

    Lock-in for the captured baseline — if someone updates the corpus
    file in place (e.g. re-downloads with a different upload), this
    test fails *before* the round-trip test, so we know to refresh
    ``EXPECTED_SCORECARD`` rather than chase a phantom Superdoc
    regression.
    """
    source = require_case(CORPUS_REL_PATH)
    actual = extract(str(source))
    mismatches = diff(EXPECTED_SCORECARD, actual)
    assert not mismatches, _format_diff(
        "Source PW Research Digest no longer matches EXPECTED_SCORECARD",
        mismatches,
    )


def test_round_trip_preserves_scorecard(round_trip_artifact: Path) -> None:
    """The Superdoc round-trip must preserve every feature count."""
    actual = extract(str(round_trip_artifact))
    mismatches = diff(EXPECTED_SCORECARD, actual)
    assert not mismatches, _format_diff(
        "Superdoc round-trip regressed the PW Research Digest scorecard",
        mismatches,
    )


def _format_diff(
    header: str, mismatches: list[tuple[str, object, object]]
) -> str:
    lines = [header, ""]
    for field, expected, actual in mismatches:
        lines.append(f"  {field}: expected={expected!r}, actual={actual!r}")
    return "\n".join(lines)
