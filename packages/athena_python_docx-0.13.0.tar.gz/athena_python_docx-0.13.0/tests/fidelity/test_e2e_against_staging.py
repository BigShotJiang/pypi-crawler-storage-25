"""End-to-end fidelity harness: athena-python-docx 0.6.1 against staging.

For each test case, this:

1. Runs the script through **stock python-docx** locally and writes a
   ``gold.docx``.
2. Runs the *same* script through **athena-python-docx 0.6.1** pointed
   at staging docx-studio — creating a fresh asset and writing its
   content over Keryx.
3. Uses the ``keryx-to-docx`` bun CLI to open the asset over the
   collaborative Keryx session (same path docx-studio uses in prod) and
   write the rendered ``pulled.docx``.
4. Extracts structural features from both files via
   ``tests/fidelity/extract.py`` (paragraph text/style/runs, table
   geometry + cell text).
5. Diffs and reports.

This validates the **full production pipeline**: SDK import → docx-
studio HTTP → Keryx Y.Doc → SuperDoc SDK export. The original failing
session (``thread_39d12733-…``) crashed in step 2 with
``SuperDocCliError: format.apply requires a non-collapsed target
range.`` 0.6.1 ships the guard for that case, and this harness re-
runs the exact pattern.

Prerequisites:
- ``athena-python-docx==0.6.1`` installed in a venv at
  ``$ATHENA_SDK_VENV`` (defaults to ``/tmp/docx_fidelity_venv``).
- Stock ``python-docx`` installed at ``$PURE_DOCX_VENV`` (defaults to
  ``/tmp/docx_pure_venv``).
- ``$BG_STAGING_API_KEY``, ``$KERYX_TOKEN``, ``$KERYX_WS_URL`` set
  in the environment (the wrapper shell script populates them from
  ``infisical run --env staging``).
- ``bun`` on PATH for the keryx-to-docx CLI.

Run via the wrapper:
    cd docx-studio/python-sdk
    python3 tests/fidelity/test_e2e_against_staging.py [case_id ...]

This is an integration test that hits staging, so it's not part of the
default pytest collection.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

THIS_DIR = Path(__file__).parent
SDK_ROOT = THIS_DIR.parent.parent
REPO_ROOT = SDK_ROOT.parent.parent
KERYX_CLI = (
    REPO_ROOT
    / "agora"
    / "converter-olympus"
    / "src"
    / "superdoc"
    / "keryx-to-docx.ts"
)


@dataclass
class Case:
    """A single fidelity test case.

    ``script`` is run as the *body* of a generated file: a python-docx
    prelude (``from docx import Document; doc = Document()``) precedes
    it for the gold run, and an athena-python-docx prelude
    (``Document.create``) for the athena run.
    """

    name: str
    script: str


# Test corpus — the production crash + a handful of representatives
# that exercise the new SDK code paths (collapsed-range FormatApply
# guard, Paragraph._text_len cache, transparent always-on batching).
CASES: list[Case] = [
    Case(
        name="repro_investment_memo_failing_pattern",
        script=(
            "from docx.shared import RGBColor\n"
            "\n"
            "doc.add_heading('Series D Investment Memorandum', level=1)\n"
            "\n"
            "# Cover\n"
            "p = doc.add_paragraph()\n"
            "r = p.add_run('CONFIDENTIAL — FOR DISCUSSION PURPOSES ONLY')\n"
            "r.bold = True\n"
            "r.font.color.rgb = RGBColor(0xC0, 0x00, 0x00)\n"
            "\n"
            "doc.add_paragraph('Prepared by: [Investment Bank Name]')\n"
            "doc.add_paragraph('Date: May 2026')\n"
            "\n"
            "# Bullets with bold prefix — exercises the text-length cache\n"
            "doc.add_heading('Investment Highlights', level=2)\n"
            "highlights = [\n"
            "    ('Large TAM',  'Operates in $X B+ TAM.'),\n"
            "    ('Proven Traction', 'ARR of $X M, Y% YoY growth.'),\n"
            "    ('Capital-Efficient', 'LTV/CAC of X, Y-month payback.'),\n"
            "]\n"
            "for title, body in highlights:\n"
            "    p = doc.add_paragraph()\n"
            "    rb = p.add_run(title + ': ')\n"
            "    rb.bold = True\n"
            "    p.add_run(body)\n"
            "\n"
            "# Table — exercises Document.add_table + cell.text setter\n"
            "t = doc.add_table(rows=3, cols=2)\n"
            "rows = [('Pre-Money Valuation', '$1.8B'),\n"
            "        ('Total Raise', '$150M - $200M'),\n"
            "        ('Use of Proceeds', 'Product / GTM / Intl')]\n"
            "for i, (k, v) in enumerate(rows):\n"
            "    t.cell(i, 0).text = k\n"
            "    t.cell(i, 1).text = v\n"
            "\n"
            "# Disclaimer paragraph with the EXACT empty-run italic pattern\n"
            "# that crashed the original session at line 254 of the agent's\n"
            "# script. 0.6.1's guard defers the FormatApply on collapsed\n"
            "# ranges; this used to throw SuperDocCliError.\n"
            "doc.add_heading('Disclaimer', level=2)\n"
            "p = doc.add_paragraph('This memorandum is confidential.')\n"
            "r = p.add_run('')\n"
            "r.italic = True\n"
        ),
    ),
    Case(
        name="simple_heading_and_paragraphs",
        script=(
            "doc.add_heading('Title', level=1)\n"
            "doc.add_paragraph('Para 1.')\n"
            "doc.add_paragraph('Para 2.')\n"
            "doc.add_paragraph('Para 3.')\n"
        ),
    ),
    Case(
        name="bold_italic_color_runs",
        script=(
            "from docx.shared import RGBColor\n"
            "\n"
            "p = doc.add_paragraph()\n"
            "r1 = p.add_run('Bold ')\n"
            "r1.bold = True\n"
            "r2 = p.add_run('Italic ')\n"
            "r2.italic = True\n"
            "r3 = p.add_run('Red')\n"
            "r3.font.color.rgb = RGBColor(0xFF, 0x00, 0x00)\n"
            "p.add_run(' plain.')\n"
        ),
    ),
    Case(
        name="table_with_formatted_cells",
        script=(
            "doc.add_paragraph('Above table.')\n"
            "t = doc.add_table(rows=3, cols=3)\n"
            "for i in range(3):\n"
            "    for j in range(3):\n"
            "        t.cell(i, j).text = f'r{i}c{j}'\n"
            "doc.add_paragraph('Below table.')\n"
        ),
    ),
]


# ── orchestration helpers ──────────────────────────────────────────────


def _run(cmd: list[str], **kw: Any) -> subprocess.CompletedProcess[str]:
    """Run a subprocess and surface stderr on failure."""
    res = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        check=False,
        **kw,
    )
    if res.returncode != 0:
        print(
            f"[harness] command failed: {' '.join(cmd)}\n"
            f"  stdout: {res.stdout[-500:]}\n"
            f"  stderr: {res.stderr[-500:]}",
            file=sys.stderr,
        )
    return res


def _run_stock_python_docx(*, case: Case, out_path: Path, pure_venv: Path) -> None:
    """Drive stock python-docx in its isolated venv to produce a .docx."""
    code = (
        "from docx import Document\n"
        "doc = Document()\n"
        f"{case.script}"
        f"\ndoc.save({str(out_path)!r})\n"
    )
    pyfile = out_path.with_suffix(".gen.py")
    pyfile.write_text(code)
    py = pure_venv / "bin" / "python3"
    res = _run([str(py), str(pyfile)])
    if res.returncode != 0:
        raise RuntimeError(f"stock python-docx run failed for {case.name}")


def _run_athena_sdk_against_staging(
    *,
    case: Case,
    sdk_venv: Path,
    docx_base_url: str,
    docx_api_key: str,
) -> str:
    """Drive athena-python-docx in its venv against staging. Returns
    the newly-created ``asset_id``."""
    # ``Document.create`` mints a fresh asset; the script runs against
    # that asset; ``save()`` + ``close()`` drain the SDK buffer to
    # docx-studio (which fans out to Keryx).
    code = (
        "import sys, json\n"
        "from docx import Document\n"
        "import os\n"
        "doc = Document.create(\n"
        "    name='e2e-fidelity-' + os.urandom(4).hex(),\n"
        f"    base_url={docx_base_url!r},\n"
        f"    api_key={docx_api_key!r},\n"
        ")\n"
        "asset_id = doc._session.asset_id\n"
        f"{case.script}"
        "\n"
        "doc.save()\n"
        "doc.close()\n"
        "print('ASSET_ID=' + asset_id)\n"
    )
    pyfile = Path("/tmp/docx_fidelity") / f"{case.name}.athena.py"
    pyfile.write_text(code)
    py = sdk_venv / "bin" / "python3"
    res = _run([str(py), str(pyfile)])
    if res.returncode != 0:
        raise RuntimeError(f"athena-python-docx run failed for {case.name}")
    for line in res.stdout.splitlines():
        if line.startswith("ASSET_ID="):
            return line.split("=", 1)[1].strip()
    raise RuntimeError(
        f"athena run did not print ASSET_ID for {case.name}\nstdout: {res.stdout}"
    )


def _resolve_workspace_id(asset_id: str) -> str:
    """Look up the asset's workspace via agora's collab routing service.

    Runs in the agora venv (uv-managed) so it has access to
    ``agora.utils.collab_routing``.
    """
    py = (
        "import asyncio, sys\n"
        "from agora.utils.collab_routing import get_collab_routing\n"
        "async def main():\n"
        f"    r = await get_collab_routing(asset_id={asset_id!r})\n"
        "    print('WORKSPACE=' + r['workspace_id'])\n"
        "asyncio.run(main())\n"
    )
    res = _run(
        [
            "infisical",
            "run",
            "--env",
            "staging",
            "--",
            "uv",
            "run",
            "python",
            "-c",
            py,
        ],
        cwd=str(REPO_ROOT / "agora"),
    )
    for line in res.stdout.splitlines():
        if line.startswith("WORKSPACE="):
            return line.split("=", 1)[1].strip()
    raise RuntimeError(
        f"could not resolve workspace for {asset_id}\nstdout: {res.stdout}"
    )


def _pull_via_keryx_cli(
    *,
    asset_id: str,
    workspace_id: str,
    keryx_ws_url: str,
    keryx_token: str,
    out_path: Path,
) -> None:
    """Invoke the bun keryx-to-docx CLI to render the asset to .docx."""
    if out_path.exists():
        out_path.unlink()
    res = _run(
        [
            "bun",
            "run",
            str(KERYX_CLI),
            keryx_ws_url,
            workspace_id,
            asset_id,
            keryx_token,
            str(out_path),
        ],
        cwd=str(REPO_ROOT),
    )
    if res.returncode != 0:
        raise RuntimeError(f"keryx-to-docx CLI failed for {asset_id}")


def _extract_features(docx_path: Path, pure_venv: Path) -> dict:
    """Use the pure venv's python-docx to extract structural features."""
    py_code = (
        "import json, sys\n"
        "import docx\n"
        f"d = docx.Document({str(docx_path)!r})\n"
        "paragraphs = []\n"
        "for p in d.paragraphs:\n"
        "    runs = []\n"
        "    for r in p.runs:\n"
        "        rgb = None\n"
        "        try:\n"
        "            if r.font.color and r.font.color.rgb:\n"
        "                rgb = str(r.font.color.rgb)\n"
        "        except Exception:\n"
        "            pass\n"
        "        runs.append({\n"
        "            'text': r.text,\n"
        "            'bold': bool(r.bold) if r.bold is not None else False,\n"
        "            'italic': bool(r.italic) if r.italic is not None else False,\n"
        "            'color': rgb,\n"
        "        })\n"
        "    style = p.style.name if p.style else ''\n"
        "    paragraphs.append({'text': p.text, 'style': style, 'runs': runs})\n"
        "tables = []\n"
        "for t in d.tables:\n"
        "    rows = len(t.rows)\n"
        "    cols = len(t.rows[0].cells) if rows else 0\n"
        "    cells = [[c.text for c in row.cells] for row in t.rows]\n"
        "    tables.append({'rows': rows, 'cols': cols, 'cells': cells})\n"
        "print(json.dumps({\n"
        "    'paragraphs': paragraphs,\n"
        "    'tables': tables,\n"
        "    'paragraph_count': len(paragraphs),\n"
        "    'table_count': len(tables),\n"
        "}))\n"
    )
    py = pure_venv / "bin" / "python3"
    # Run from /tmp so the cwd-local ``docx/`` (athena-python-docx
    # source) doesn't shadow stock python-docx via sys.path[0] = '.'.
    # Stock python-docx is what the pure_venv installed; we want
    # *that* import to win, not the editable SDK source.
    res = _run([str(py), "-c", py_code], cwd="/tmp")
    if res.returncode != 0:
        raise RuntimeError(f"feature extraction failed for {docx_path}")
    # The last non-empty stdout line is our JSON payload (python-docx
    # sometimes emits its own warnings before our print).
    for line in reversed(res.stdout.splitlines()):
        if line.strip().startswith("{"):
            return json.loads(line)
    raise RuntimeError(f"no JSON in extractor output for {docx_path}")


def _diff(gold: dict, athena: dict) -> list[str]:
    """Compare extracted features and return human-readable diffs.

    Tolerates SuperDoc's trailing empty paragraph (the .docx default
    template) — we compare non-empty paragraphs.
    """
    diffs: list[str] = []

    def _nonempty(paras: list[dict]) -> list[dict]:
        return [p for p in paras if p["text"] or p["runs"]]

    gold_paras = _nonempty(gold["paragraphs"])
    athena_paras = _nonempty(athena["paragraphs"])
    if len(gold_paras) != len(athena_paras):
        diffs.append(
            f"paragraph count mismatch: gold={len(gold_paras)} athena={len(athena_paras)}"
        )

    n = min(len(gold_paras), len(athena_paras))
    for i in range(n):
        g, a = gold_paras[i], athena_paras[i]
        if g["text"] != a["text"]:
            diffs.append(
                f"paragraph[{i}].text mismatch:\n  gold:   {g['text']!r}\n  athena: {a['text']!r}"
            )
        # Style mismatch is informational only — SuperDoc may
        # normalize 'Normal' to '' or apply theme styles
        if g["style"] and a["style"] and g["style"].lower() != a["style"].lower():
            diffs.append(
                f"paragraph[{i}].style: gold={g['style']!r} athena={a['style']!r}"
            )

    if gold["table_count"] != athena["table_count"]:
        diffs.append(
            f"table count mismatch: gold={gold['table_count']} athena={athena['table_count']}"
        )
    nt = min(gold["table_count"], athena["table_count"])
    for ti in range(nt):
        gt, at = gold["tables"][ti], athena["tables"][ti]
        if gt["rows"] != at["rows"] or gt["cols"] != at["cols"]:
            diffs.append(
                f"table[{ti}] geometry: gold={gt['rows']}x{gt['cols']} "
                f"athena={at['rows']}x{at['cols']}"
            )
        else:
            for r in range(gt["rows"]):
                for c in range(gt["cols"]):
                    g_cell = gt["cells"][r][c]
                    a_cell = at["cells"][r][c]
                    if g_cell != a_cell:
                        diffs.append(
                            f"table[{ti}].cell({r},{c}): gold={g_cell!r} athena={a_cell!r}"
                        )
    return diffs


# ── main ───────────────────────────────────────────────────────────────


def main() -> int:
    pure_venv = Path(os.environ.get("PURE_DOCX_VENV", "/tmp/docx_pure_venv"))
    sdk_venv = Path(os.environ.get("ATHENA_SDK_VENV", "/tmp/docx_fidelity_venv"))
    docx_base_url = os.environ.get(
        "ATHENA_DOCX_BASE_URL",
        "https://docx-studio.stg.athenaintel.com",
    )
    docx_api_key = os.environ["BG_STAGING_API_KEY"]
    keryx_ws_url = os.environ["KERYX_WS_URL"]
    keryx_token = os.environ["KERYX_TOKEN"]

    out_root = Path("/tmp/docx_fidelity/e2e")
    if out_root.exists():
        shutil.rmtree(out_root)
    out_root.mkdir(parents=True)

    requested = sys.argv[1:]
    cases = [c for c in CASES if not requested or c.name in requested]

    summary: list[dict] = []
    for case in cases:
        print(f"\n=== {case.name} ===")
        case_dir = out_root / case.name
        case_dir.mkdir()

        gold = case_dir / "gold.docx"
        athena = case_dir / "athena_pulled.docx"

        # 1) stock python-docx → gold
        _run_stock_python_docx(case=case, out_path=gold, pure_venv=pure_venv)
        print(f"  [1/4] gold.docx written ({gold.stat().st_size} bytes)")

        # 2) athena-python-docx → asset on staging
        asset_id = _run_athena_sdk_against_staging(
            case=case,
            sdk_venv=sdk_venv,
            docx_base_url=docx_base_url,
            docx_api_key=docx_api_key,
        )
        print(f"  [2/4] asset created: {asset_id}")

        # 3) resolve workspace + pull via keryx CLI
        workspace_id = _resolve_workspace_id(asset_id)
        _pull_via_keryx_cli(
            asset_id=asset_id,
            workspace_id=workspace_id,
            keryx_ws_url=keryx_ws_url,
            keryx_token=keryx_token,
            out_path=athena,
        )
        print(f"  [3/4] pulled via keryx CLI ({athena.stat().st_size} bytes)")

        # 4) compare features
        gold_feats = _extract_features(gold, pure_venv)
        athena_feats = _extract_features(athena, pure_venv)
        diffs = _diff(gold_feats, athena_feats)
        print(
            f"  [4/4] gold: {gold_feats['paragraph_count']} paras, "
            f"{gold_feats['table_count']} tables | "
            f"athena: {athena_feats['paragraph_count']} paras, "
            f"{athena_feats['table_count']} tables"
        )
        if diffs:
            print(f"  ❌ {len(diffs)} diff(s):")
            for d in diffs:
                for line in d.splitlines():
                    print(f"     {line}")
        else:
            print("  ✅ structurally identical")
        summary.append({
            "case": case.name,
            "asset_id": asset_id,
            "workspace_id": workspace_id,
            "diffs": diffs,
            "gold_paragraphs": gold_feats["paragraph_count"],
            "gold_tables": gold_feats["table_count"],
            "athena_paragraphs": athena_feats["paragraph_count"],
            "athena_tables": athena_feats["table_count"],
        })

    # Final summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    passed = sum(1 for s in summary if not s["diffs"])
    failed = len(summary) - passed
    for s in summary:
        status = "✅" if not s["diffs"] else f"❌ ({len(s['diffs'])})"
        print(f"  {status}  {s['case']:50s}  asset={s['asset_id']}")
    print(f"\n{passed}/{len(summary)} cases structurally identical, "
          f"{failed} with diffs.")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
