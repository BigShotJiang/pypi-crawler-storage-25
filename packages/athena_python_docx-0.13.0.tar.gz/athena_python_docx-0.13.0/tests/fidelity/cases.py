"""Fidelity test cases.

Each case is a snippet that operates on a pre-bound ``doc`` (the Document
instance). The same snippet runs against stock python-docx and against
athena-python-docx via Daytona.

Conventions
-----------
- Use only the python-docx public API — no private `_element` access, no
  imports beyond what's in the preamble.
- Keep cases minimal (one surface per case where possible) so a failure
  pinpoints the SDK gap.
- Mark known-stubbed operations with ``expected_exc`` — the case passes
  if the stub actually raises (regression detection).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Case:
    name: str
    description: str
    script: str
    # When set, the athena-python-docx run is expected to raise this exception
    # type. The local python-docx run is never expected to raise — if it does,
    # the case is broken and reported as an infrastructure error.
    expected_athena_exc: str | None = None
    # If True, the athena side is not compared against stock — only asserted
    # to succeed. Use when the op has no content-level effect worth diffing
    # (e.g. add_page_break), or when the stock and Superdoc template diverge
    # too much for a meaningful diff.
    skip_content_diff: bool = False
    # Optional tags for filtering.
    tags: tuple[str, ...] = field(default_factory=tuple)


CASES: list[Case] = [
    # ---- Core append ops -----------------------------------------------------
    Case(
        name="add_paragraph_with_text",
        description="One plain paragraph containing a short string.",
        script='doc.add_paragraph("hello world")',
        tags=("paragraph",),
    ),
    Case(
        name="add_paragraph_empty",
        description="A paragraph with no text (docx.add_paragraph()).",
        script="doc.add_paragraph()",
        tags=("paragraph",),
    ),
    Case(
        name="add_heading_level_1",
        description="Heading 1 with text.",
        script='doc.add_heading("H1 heading", level=1)',
        tags=("heading",),
    ),
    Case(
        name="add_heading_level_2",
        description="Heading 2 with text.",
        script='doc.add_heading("H2 heading", level=2)',
        tags=("heading",),
    ),
    Case(
        name="add_heading_level_3",
        description="Heading 3 with text.",
        script='doc.add_heading("H3 heading", level=3)',
        tags=("heading",),
    ),
    Case(
        name="add_paragraph_style_title",
        description=(
            "add_paragraph(style='Title') — routes through add_heading(level=0). "
            "Regression for devin #3115708111 / greptile #3115709241."
        ),
        script='doc.add_paragraph("The Title", style="Title")',
        tags=("paragraph", "heading", "title"),
    ),
    Case(
        name="add_run_on_heading",
        description=(
            "Add two runs to a heading — exercises _node_text heading-key "
            "support. Regression for greptile #3119401124."
        ),
        script=(
            'h = doc.add_heading("", level=2)\n'
            'h.add_run("first ")\n'
            'h.add_run("second")'
        ),
        tags=("heading", "run"),
    ),
    # ---- Runs + inline formatting --------------------------------------------
    Case(
        name="add_run_bold_italic",
        description="Paragraph with two runs, bold + italic.",
        script=(
            "p = doc.add_paragraph()\n"
            'r1 = p.add_run("bold run")\n'
            "r1.bold = True\n"
            'r2 = p.add_run("italic run")\n'
            "r2.italic = True"
        ),
        tags=("run", "formatting"),
    ),
    Case(
        name="add_run_colored",
        description="Paragraph with a run colored green via RGBColor.",
        script=(
            "from docx.shared import RGBColor\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("green text")\n'
            "r.font.color.rgb = RGBColor(0x00, 0x66, 0x00)"
        ),
        tags=("run", "formatting", "color"),
    ),
    Case(
        name="add_run_font_size",
        description="Paragraph with a run set to 18pt.",
        script=(
            "from docx.shared import Pt\n"
            "p = doc.add_paragraph()\n"
            'r = p.add_run("sized 18pt")\n'
            "r.font.size = Pt(18)"
        ),
        tags=("run", "formatting", "font"),
    ),
    # ---- Tables --------------------------------------------------------------
    Case(
        name="add_table_2x2_empty",
        description="Create an empty 2x2 table; verify row/col count.",
        script="doc.add_table(rows=2, cols=2)",
        tags=("table",),
    ),
    Case(
        name="add_table_3x3_with_style",
        description="Create a 3x3 TableGrid table.",
        script='doc.add_table(rows=3, cols=3, style="TableGrid")',
        tags=("table", "style"),
    ),
    Case(
        name="cell_text_setter",
        description="Set cell(0,0).text on a 2x2 table — now supported via 3-strategy fallback.",
        script=(
            "t = doc.add_table(rows=2, cols=2)\n"
            't.cell(0, 0).text = "A1"'
        ),
        tags=("table",),
    ),
    # ---- Structural ops ------------------------------------------------------
    Case(
        name="add_page_break",
        description="Append a page break; content-diff skipped (template differs).",
        script="doc.add_page_break()",
        skip_content_diff=True,
        tags=("structural",),
    ),
    # ---- Multi-op combo ------------------------------------------------------
    Case(
        name="combo_heading_paragraph_table",
        description="Heading + paragraph with formatted runs + 2x2 table (no cell text).",
        script=(
            "from docx.shared import RGBColor\n"
            'doc.add_heading("Report", level=1)\n'
            "p = doc.add_paragraph()\n"
            'r1 = p.add_run("Revenue grew ")\n'
            'r2 = p.add_run("12%")\n'
            "r2.bold = True\n"
            "r2.font.color.rgb = RGBColor(0x00, 0x66, 0x00)\n"
            'p.add_run(" YoY.")\n'
            'doc.add_table(rows=2, cols=2, style="TableGrid")'
        ),
        tags=("combo",),
    ),
    # =========================================================================
    # Athena extensions for most-requested upstream features (v0.11.0+)
    # =========================================================================
    # These cases exercise Athena-only surfaces that have no python-docx
    # upstream parity. ``skip_content_diff=True`` for every case — stock
    # python-docx can't run them, so there's nothing to diff against.
    # See ``python-sdk/CLAUDE.md`` § "Athena extensions for most-requested
    # upstream features (v0.11.0+)" for per-feature design rationale.

    # ---- Hyperlink ADD (closes #74) -----------------------------------------
    Case(
        name="athena_paragraph_add_hyperlink",
        description="Paragraph.add_hyperlink — closes python-docx #74.",
        script=(
            'p = doc.add_paragraph("See the docs: ")\n'
            'p.add_hyperlink("here", "https://docs.example.com")'
        ),
        skip_content_diff=True,
        tags=("athena", "hyperlinks"),
    ),

    # ---- Bookmarks + cross-references (closes #425, #97) ---------------------
    Case(
        name="athena_bookmarks_and_cross_reference",
        description="Add bookmark + cross-reference targeting it.",
        script=(
            'p1 = doc.add_paragraph("Section heading")\n'
            'p1.add_bookmark("section_top")\n'
            'p2 = doc.add_paragraph("See ")\n'
            'r = p2.add_run("section above")\n'
            'r.add_cross_reference("section_top", reference_kind="text", hyperlink=True)'
        ),
        skip_content_diff=True,
        tags=("athena", "bookmarks", "cross-references"),
    ),

    # ---- Fields — PAGE / NUMPAGES / DATE (closes #498, #31) -----------------
    Case(
        name="athena_run_add_field_page_numpages",
        description="Run.add_field with PAGE and NUMPAGES.",
        script=(
            'p = doc.add_paragraph("Page ")\n'
            'p.add_run().add_field("PAGE")\n'
            'p.add_run(" of ")\n'
            'p.add_run().add_field("NUMPAGES")'
        ),
        skip_content_diff=True,
        tags=("athena", "fields"),
    ),
    Case(
        name="athena_run_add_field_date",
        description="Run.add_field DATE with format args.",
        script=(
            'p = doc.add_paragraph("Last updated: ")\n'
            'p.add_run().add_field("DATE", args={"format": "MMMM d, yyyy"})'
        ),
        skip_content_diff=True,
        tags=("athena", "fields"),
    ),

    # ---- Footnotes / Endnotes (closes #1) -----------------------------------
    Case(
        name="athena_run_add_footnote",
        description="Run.add_footnote — closes Issue #1 (open since 2014).",
        script=(
            'p = doc.add_paragraph("Theorem: ")\n'
            "p.add_run(\"Fermat's Last\").add_footnote(\"Proved by Wiles in 1995.\")"
        ),
        skip_content_diff=True,
        tags=("athena", "footnotes"),
    ),
    Case(
        name="athena_run_add_endnote",
        description="Run.add_endnote — twin of add_footnote.",
        script=(
            'p = doc.add_paragraph("Sources: ")\n'
            'p.add_run("primary").add_endnote("Smith (2024), p. 42.")'
        ),
        skip_content_diff=True,
        tags=("athena", "endnotes"),
    ),

    # ---- Caption + auto-numbered SEQ (closes #676) --------------------------
    Case(
        name="athena_paragraph_add_caption",
        description="Paragraph.add_caption — SEQ-numbered Figure caption.",
        script=(
            'p = doc.add_paragraph("Diagram below.")\n'
            'p.add_caption("Architecture overview", label="Figure", bookmark="fig_arch")'
        ),
        skip_content_diff=True,
        tags=("athena", "captions"),
    ),

    # ---- TOC (closes #36, #1403) --------------------------------------------
    Case(
        name="athena_document_add_toc",
        description="Document.add_toc — closes python-docx #36.",
        script=(
            'doc.add_heading("Introduction", level=1)\n'
            'doc.add_heading("Background", level=2)\n'
            'doc.add_heading("Method", level=1)\n'
            'doc.add_toc(levels=(1, 2), include_hyperlinks=True)'
        ),
        skip_content_diff=True,
        tags=("athena", "toc"),
    ),

    # ---- Cell borders + shading (closes #201, #146, #1238) ------------------
    Case(
        name="athena_cell_borders_and_shading",
        description="_Cell.set_borders + set_shading + table-wide borders.",
        script=(
            "t = doc.add_table(rows=2, cols=2)\n"
            't.cell(0, 0).text = "Header A"\n'
            't.cell(0, 1).text = "Header B"\n'
            't.cell(0, 0).set_shading(fill="DDDDDD")\n'
            't.cell(0, 1).set_shading(fill="DDDDDD")\n'
            't.cell(0, 0).set_borders(\n'
            '    top={"style": "single", "size_pt": 1.0, "color": "000000"},\n'
            '    bottom={"style": "double", "size_pt": 1.5, "color": "000000"},\n'
            ')\n'
            't.set_borders(\n'
            '    inside_horizontal={"style": "single", "size_pt": 0.5},\n'
            '    inside_vertical={"style": "single", "size_pt": 0.5},\n'
            ')'
        ),
        skip_content_diff=True,
        tags=("athena", "tables", "borders"),
    ),

    # ---- add_row(copy_format_from=) (closes #205) ---------------------------
    Case(
        name="athena_table_add_row_copy_format_from",
        description="Table.add_row preserves formatting from a source row.",
        script=(
            "t = doc.add_table(rows=2, cols=3)\n"
            't.cell(0, 0).text = "Col 1"\n'
            't.cell(0, 1).text = "Col 2"\n'
            't.cell(0, 2).text = "Col 3"\n'
            't.cell(1, 0).set_shading(fill="EEEEEE")\n'
            "t.add_row(copy_format_from=1)"
        ),
        skip_content_diff=True,
        tags=("athena", "tables"),
    ),

    # ---- Image alt-text / decorative (PR #1530) -----------------------------
    Case(
        name="athena_image_alt_text_and_decorative",
        description="InlineShape.alt_text / .title / .decorative.",
        script=(
            "import base64, io\n"
            "png = base64.b64decode(\n"
            '    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="\n'
            ")\n"
            "shape = doc.add_picture(io.BytesIO(png), width=72)\n"
            'shape.alt_text = "Company logo"\n'
            'shape.title = "Acme Inc. logo"\n'
            "shape.decorative = False"
        ),
        skip_content_diff=True,
        tags=("athena", "images", "accessibility"),
    ),

    # ---- Charts (closes #179, #1141) ----------------------------------------
    Case(
        name="athena_document_add_chart_column",
        description="Document.add_chart — column chart with categorical data.",
        script=(
            "doc.add_chart(\n"
            '    "column",\n'
            "    [\n"
            '        ["", "Q1", "Q2", "Q3", "Q4"],\n'
            '        ["Revenue", 100, 120, 110, 130],\n'
            '        ["Cost", 60, 70, 65, 75],\n'
            "    ],\n"
            '    title="Quarterly Performance",\n'
            ")"
        ),
        skip_content_diff=True,
        tags=("athena", "charts"),
    ),

    # ---- Math (closes #320) -------------------------------------------------
    Case(
        name="athena_run_add_math_inline",
        description="Run.add_math — inline equation via MathML.",
        script=(
            'p = doc.add_paragraph("Inline math: ")\n'
            'p.add_run().add_math(\n'
            '    "<math><mi>x</mi><mo>=</mo><mfrac><mn>1</mn><mn>2</mn></mfrac></math>",\n'
            '    format="mathml",\n'
            "    display=False,\n"
            ")"
        ),
        skip_content_diff=True,
        tags=("athena", "math"),
    ),

    # ---- Content controls (closes #155, #1417) ------------------------------
    Case(
        name="athena_document_add_content_control_checkbox",
        description="Document.add_content_control — checkbox SDT.",
        script=(
            'doc.add_paragraph("Accept terms:")\n'
            'doc.add_content_control(\n'
            '    "checkbox",\n'
            '    tag="accept_terms",\n'
            '    alias="Accept the Terms",\n'
            ")"
        ),
        skip_content_diff=True,
        tags=("athena", "sdt"),
    ),

    # ---- Multi-column section layout (closes #167) --------------------------
    Case(
        name="athena_section_set_columns",
        description="Section.set_columns — 2-column layout with separator.",
        script=(
            "section = doc.sections[0]\n"
            "section.set_columns(count=2, equal_width=True, space_pt=18.0, separator=True)"
        ),
        skip_content_diff=True,
        tags=("athena", "sections", "columns"),
    ),

    # ---- Watermark (closes #845) --------------------------------------------
    Case(
        name="athena_document_add_watermark_text",
        description="Document.add_watermark — DRAFT diagonal text watermark.",
        script=(
            "doc.add_watermark(\n"
            '    text="DRAFT",\n'
            '    font_family="Calibri",\n'
            "    font_size_pt=72.0,\n"
            '    color="808080",\n'
            "    opacity=0.5,\n"
            "    angle=-45.0,\n"
            ")"
        ),
        skip_content_diff=True,
        tags=("athena", "watermarks"),
    ),

    # ---- Find & replace (closes #30, #980) ----------------------------------
    Case(
        name="athena_document_find_replace",
        description="Document.find_replace preserves run formatting.",
        script=(
            'p = doc.add_paragraph()\n'
            'p.add_run("Hello, ").bold = True\n'
            'p.add_run("DRAFT").italic = True\n'
            'p.add_run("!")\n'
            'doc.find_replace("DRAFT", "FINAL")'
        ),
        skip_content_diff=True,
        tags=("athena", "find-replace"),
    ),

    # ---- List numbering reads (closes #471) ---------------------------------
    Case(
        name="athena_paragraph_list_numbering_reads",
        description="Paragraph.list_id / list_level / list_format reads.",
        script=(
            "items = []\n"
            "for label in (\"First\", \"Second\", \"Third\"):\n"
            '    items.append(doc.add_paragraph(label, style="List Number"))\n'
            "for p in items:\n"
            "    _ = (p.list_id, p.list_level, p.list_format, p.list_number)"
        ),
        skip_content_diff=True,
        tags=("athena", "lists", "numbering"),
    ),

    # ---- Floating image anchor (closes #159) --------------------------------
    Case(
        name="athena_inline_shape_anchor",
        description="InlineShape.anchor — promote inline to floating image.",
        script=(
            "import base64, io\n"
            "png = base64.b64decode(\n"
            '    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="\n'
            ")\n"
            "shape = doc.add_picture(io.BytesIO(png), width=144)\n"
            "shape.anchor(\n"
            '    wrap="square",\n'
            "    position_x_pt=36.0,\n"
            "    position_y_pt=72.0,\n"
            '    relative_from_x="margin",\n'
            '    relative_from_y="paragraph",\n'
            ")"
        ),
        skip_content_diff=True,
        tags=("athena", "images", "floating"),
    ),
]
