"""Fake Superdoc session for local fidelity testing.

Records every op invocation and returns deterministic responses matching
the real Superdoc contract shapes. Use this to drive the full SDK surface
through complex python-docx scripts without spinning up a Daytona sandbox.
"""

from __future__ import annotations

import itertools
from typing import Any


class FakeSDKMethods:
    """Callable-proxy namespace that records every op."""

    def __init__(self, state: "FakeDocState") -> None:
        self._state: "FakeDocState" = state

    def __getattr__(self, name: str) -> "FakeNamespace":
        return FakeNamespace(self._state, [name])


class FakeNamespace:
    def __init__(self, state: "FakeDocState", path: list[str]) -> None:
        self._state: "FakeDocState" = state
        self._path: list[str] = path

    def __getattr__(self, name: str) -> "FakeNamespace":
        return FakeNamespace(self._state, [*self._path, name])

    async def __call__(self, params: dict | None = None) -> Any:
        # Snake-case the path: "format.paragraph.set_alignment" -> "format.paragraph.setAlignment"
        op_parts: list[str] = []
        for seg in self._path:
            if "_" in seg:
                head, *tail = seg.split("_")
                camel = head + "".join(p.capitalize() for p in tail)
                op_parts.append(camel)
            else:
                op_parts.append(seg)
        op_name: str = ".".join(op_parts)
        self._state.calls.append((op_name, params or {}))
        return self._state.respond(op_name, params or {})


class _Block:
    def __init__(self, node_id: str, node_type: str, text: str = "") -> None:
        self.node_id: str = node_id
        self.node_type: str = node_type
        self.text: str = text
        self.style_id: str | None = None
        self.alignment: str | None = None
        self.attrs: dict[str, Any] = {}
        self.inlines: list[dict] = [{"run": {"text": text}}] if text else []


class _Table:
    def __init__(self, node_id: str, rows: int, cols: int, style: str = "TableGrid") -> None:
        self.node_id: str = node_id
        self.rows: int = rows
        self.cols: int = cols
        self.style_id: str = style
        self.alignment: str | None = None
        self.direction: str | None = None
        self.auto_fit_mode: str = "fitContents"
        # Parent cell info (when nested). None when top-level.
        self.parent_cell: tuple[str, int, int] | None = None
        # Merge groups: each merged region is stored as a set of (r,c) tuples.
        self.merge_groups: list[set[tuple[int, int]]] = []
        # Each cell has one empty paragraph
        self.cells: list[list[_Block]] = []
        # Extra paragraphs added after the initial one, keyed by (r, c)
        self.cell_extra_paragraphs: dict[tuple[int, int], list[_Block]] = {}
        # Nested tables keyed by (r, c)
        self.cell_nested_tables: dict[tuple[int, int], list["_Table"]] = {}
        for r in range(rows):
            row: list[_Block] = []
            for c in range(cols):
                pid = f"tp_{node_id}_{r}_{c}"
                p = _Block(pid, "paragraph", "")
                row.append(p)
            self.cells.append(row)
        # Column/row sizing
        self.row_heights: list[tuple[float, str]] = [(0.0, "auto")] * rows
        self.col_widths: list[float] = [0.0] * cols
        self.cell_verticals: list[list[str]] = [["top"] * cols for _ in range(rows)]
        self.cell_widths: list[list[float]] = [[0.0] * cols for _ in range(rows)]


class _Section:
    def __init__(self, section_id: str) -> None:
        self.id: str = section_id
        self.break_type: str = "nextPage"
        self.page_setup: dict[str, Any] = {
            "width": 612.0,  # 8.5" in pt
            "height": 792.0,  # 11" in pt
            "orientation": "portrait",
        }
        # Word's blank-document template defaults (verified against stock
        # python-docx 1.2.0): 1in top/bottom, 1.25in left/right (= 90pt).
        self.margins: dict[str, Any] = {
            "top": 72.0,
            "right": 90.0,
            "bottom": 72.0,
            "left": 90.0,
            "gutter": 0.0,
        }
        self.header_footer_margins: dict[str, Any] = {"header": 36.0, "footer": 36.0}
        self.title_page: bool = False


class FakeDocState:
    """Holds a minimal in-memory model of the document for the fake session."""

    _ids = itertools.count(1)

    def __init__(self) -> None:
        self.blocks: list[_Block] = []
        self.tables: list[_Table] = []
        self.sections: list[_Section] = [_Section("sec_1")]
        self.images: list[dict] = []
        self.calls: list[tuple[str, dict]] = []

    def _new_id(self, prefix: str) -> str:
        return f"{prefix}_{next(self._ids)}"

    def _find_block(self, node_id: str) -> _Block | None:
        for b in self.blocks:
            if b.node_id == node_id:
                return b
        for t in self.tables:
            for r_idx, row in enumerate(t.cells):
                for c_idx, c in enumerate(row):
                    if c.node_id == node_id:
                        return c
                    for extra in t.cell_extra_paragraphs.get((r_idx, c_idx), []):
                        if extra.node_id == node_id:
                            return extra
        return None

    def _find_cell_owner(self, paragraph_node_id: str) -> tuple[_Table, int, int] | None:
        """Given a paragraph's nodeId, find the (table, row, col) it belongs to."""
        for t in self.tables:
            for r_idx, row in enumerate(t.cells):
                for c_idx, cell in enumerate(row):
                    if cell.node_id == paragraph_node_id:
                        return (t, r_idx, c_idx)
                    for extra in t.cell_extra_paragraphs.get((r_idx, c_idx), []):
                        if extra.node_id == paragraph_node_id:
                            return (t, r_idx, c_idx)
        return None

    def _find_table(self, node_id: str) -> _Table | None:
        for t in self.tables:
            if t.node_id == node_id:
                return t
        return None

    def respond(self, op: str, params: dict) -> Any:
        # ---- lifecycle ----
        if op in ("open", "close", "save", "getText", "info"):
            if op == "getText":
                return "\n".join(b.text for b in self.blocks)
            if op == "info":
                return {"styles": {"paragraphStyles": []}}
            return {"ok": True}

        # ---- create.* ----
        # Honor an explicit ``client_node_id`` from the SDK (always set in
        # 0.7.0+ for transparent batching) by using it as the new block's
        # id, so the SDK's proxy and the fake state stay in sync without
        # needing a separate clientIdMap echo. Falls back to the legacy
        # ``_new_id`` path for callers that don't pre-mint.
        if op == "create.paragraph":
            nid = params.get("client_node_id") or self._new_id("p")
            b = _Block(nid, "paragraph", params.get("text", ""))
            self._place_block(params.get("at"), b)
            return {"success": True, "paragraph": {"nodeId": nid}}
        if op == "create.heading":
            nid = params.get("client_node_id") or self._new_id("h")
            level = params.get("level", 1)
            b = _Block(nid, "heading", params.get("text", ""))
            b.attrs["level"] = level
            self._place_block(params.get("at"), b)
            return {"success": True, "heading": {"nodeId": nid, "level": level}}
        if op == "create.table":
            rows = params.get("rows", 1)
            cols = params.get("columns") or params.get("cols") or 1
            tid = params.get("client_node_id") or self._new_id("t")
            t = _Table(tid, rows, cols)
            # Check if the anchor points inside a cell — make this nested.
            at = params.get("at") or {}
            if at.get("kind") in ("before", "after"):
                tgt = at.get("target") or {}
                tgt_nid = tgt.get("nodeId")
                if tgt_nid:
                    owner = self._find_cell_owner(str(tgt_nid))
                    if owner is not None:
                        parent_t, r_idx, c_idx = owner
                        t.parent_cell = (parent_t.node_id, r_idx, c_idx)
                        parent_t.cell_nested_tables.setdefault(
                            (r_idx, c_idx), []
                        ).append(t)
                        self.tables.append(t)
                        return {"success": True, "table": {"nodeId": tid}}
            self.tables.append(t)
            return {"success": True, "table": {"nodeId": tid}}
        if op == "create.image":
            iid = params.get("client_node_id") or self._new_id("img")
            info = {
                "nodeId": iid,
                "size": params.get("size", {"width": 576, "height": 432}),
                "src": params.get("src", ""),
            }
            self.images.append(info)
            return {"success": True, "image": {"nodeId": iid}}
        if op == "create.sectionBreak":
            sid = self._new_id("sec")
            s = _Section(sid)
            s.break_type = params.get("breakType", "nextPage")
            self.sections.append(s)
            return {"success": True}

        # ---- reading ----
        if op == "getNodeById":
            nid = params.get("id") or params.get("nodeId")
            # Paragraph / heading
            b = self._find_block(str(nid))
            if b is not None:
                block_data: dict = {
                    "inlines": list(b.inlines),
                    "alignment": b.alignment,
                    "attrs": b.attrs,
                    "styleId": b.style_id,
                }
                if b.alignment:
                    block_data["alignment"] = b.alignment
                node: dict = {
                    "nodeType": b.node_type,
                    "styleId": b.style_id,
                    b.node_type: block_data,
                }
                return {"node": node, "address": {"kind": "block", "nodeType": b.node_type, "nodeId": b.node_id}}
            # Table cell
            for t in self.tables:
                for r_idx, row in enumerate(t.cells):
                    for c_idx, cell in enumerate(row):
                        if cell.node_id == nid or (
                            params.get("nodeType") == "tableCell"
                            and nid == f"cell_{t.node_id}_{r_idx}_{c_idx}"
                        ):
                            # Return a tree containing the inner paragraph
                            inner = {
                                "type": "paragraph",
                                "attrs": {"nodeId": cell.node_id},
                                "content": [{"type": "text", "text": cell.text}] if cell.text else [],
                            }
                            return {
                                "node": {
                                    "nodeType": "tableCell",
                                    "tableCell": {"content": [inner]},
                                },
                                "address": {
                                    "kind": "block",
                                    "nodeType": "tableCell",
                                    "nodeId": cell.node_id,
                                },
                            }
            return {"node": {}, "address": {}}

        if op == "blocks.list":
            types = params.get("nodeTypes") or None
            out_blocks: list[dict] = []
            for b in self.blocks:
                if types and b.node_type not in types:
                    continue
                entry = {
                    "nodeId": b.node_id,
                    "nodeType": b.node_type,
                    "textPreview": b.text,
                    "styleId": b.style_id,
                    "alignment": b.alignment,
                }
                out_blocks.append(entry)
            # Mirror real SuperDoc: when "table" is in the requested
            # nodeTypes, top-level tables come back too. The fake doesn't
            # track precise document position, so tables append in
            # creation order — sufficient for parity-shape tests.
            if types is None or "table" in types:
                for t in self.tables:
                    if t.parent_cell is not None:
                        continue  # nested tables aren't top-level
                    out_blocks.append(
                        {"nodeId": t.node_id, "nodeType": "table"},
                    )
            return {"blocks": out_blocks, "total": len(out_blocks), "revision": "r0"}

        if op == "find":
            if params.get("type") == "table":
                # Only top-level (non-nested) tables match python-docx's
                # Document.tables semantics.
                return {
                    "items": [
                        {
                            "address": {
                                "kind": "block",
                                "nodeType": "table",
                                "nodeId": t.node_id,
                            },
                        }
                        for t in self.tables
                        if t.parent_cell is None
                    ],
                }
            return {"items": []}

        # ---- mutations ----
        if op == "replace":
            target = params.get("target") or {}
            text = params.get("text", "")
            def _apply_to_block(b: _Block, s: int, e: int, new: str) -> None:
                result = b.text[:s] + new + b.text[e:]
                b.text = result
                b.inlines = [{"run": {"text": result}}] if result else []
                # Propagate to merged siblings, if this block is a cell's
                # first paragraph in a merge group.
                for t in self.tables:
                    for r_idx, row in enumerate(t.cells):
                        for c_idx, cell in enumerate(row):
                            if cell is b:
                                # Find merge group containing (r_idx, c_idx)
                                for group in t.merge_groups:
                                    if (r_idx, c_idx) in group:
                                        for gr, gc in group:
                                            sib = t.cells[gr][gc]
                                            if sib is not b:
                                                sib.text = result
                                                sib.inlines = (
                                                    [{"run": {"text": result}}]
                                                    if result
                                                    else []
                                                )
                                        return
            if target.get("kind") == "selection":
                start = target.get("start", {})
                blk_id = start.get("blockId")
                b = self._find_block(str(blk_id)) if blk_id else None
                if b is not None:
                    s = int(start.get("offset", 0))
                    end_info = target.get("end", {}) or {}
                    e = int(end_info.get("offset", len(b.text)))
                    _apply_to_block(b, s, e, text)
                    return {"ok": True}
            if target.get("kind") == "text":
                blk_id = target.get("blockId")
                b = self._find_block(str(blk_id)) if blk_id else None
                if b is not None:
                    rng = target.get("range", {}) or {}
                    s = int(rng.get("start", 0))
                    e = int(rng.get("end", len(b.text)))
                    _apply_to_block(b, s, e, text)
            return {"ok": True}

        if op == "insert":
            target = params.get("target") or {}
            value = params.get("value", "")
            # Text-mode: selection target with blockId + cursor offset
            blk_id: str | None = None
            offset: int | None = None
            if target.get("kind") == "selection":
                start = target.get("start") or {}
                if start.get("kind") == "text":
                    blk_id = start.get("blockId")
                    raw = start.get("offset")
                    if isinstance(raw, int):
                        offset = raw
            if blk_id:
                b = self._find_block(str(blk_id))
                if b is not None:
                    # Insert as a NEW inline at the requested offset
                    # rather than merging into a single run. Real SuperDoc
                    # / ProseMirror keeps inserted text as a separate inline
                    # so format.apply on the new range can split & mark
                    # without affecting the surrounding text. Without this,
                    # multiple add_run() calls in the same paragraph
                    # collapse and per-run marks bleed across runs.
                    if offset is None:
                        offset = len(b.text)
                    new_inline = {"run": {"text": value}}
                    if not b.inlines:
                        # Empty paragraph: just place the new inline.
                        b.inlines = [new_inline] if value else []
                    else:
                        # Walk inlines accumulating their text length;
                        # split the one whose range straddles the offset.
                        new_inlines: list[dict] = []
                        cursor = 0
                        placed = False
                        for inl in b.inlines:
                            txt = (inl.get("run") or {}).get("text", "") if isinstance(inl, dict) else ""
                            ilen = len(txt)
                            if placed:
                                new_inlines.append(inl)
                                continue
                            if offset <= cursor:
                                new_inlines.append(new_inline)
                                new_inlines.append(inl)
                                placed = True
                            elif offset >= cursor + ilen:
                                new_inlines.append(inl)
                                if offset == cursor + ilen:
                                    new_inlines.append(new_inline)
                                    placed = True
                            else:
                                # Mid-inline split: pre / new / post.
                                rel = offset - cursor
                                run0 = dict(inl.get("run") or {})
                                run0["text"] = txt[:rel]
                                run1 = dict(inl.get("run") or {})
                                run1["text"] = txt[rel:]
                                new_inlines.append({"run": run0})
                                new_inlines.append(new_inline)
                                new_inlines.append({"run": run1})
                                placed = True
                            cursor += ilen
                        if not placed:
                            new_inlines.append(new_inline)
                        # Drop empty-text inlines that came out of splits.
                        b.inlines = [
                            i
                            for i in new_inlines
                            if (i.get("run") or {}).get("text", "") != ""
                        ]
                    b.text = "".join(
                        (i.get("run") or {}).get("text", "")
                        for i in b.inlines
                        if isinstance(i, dict)
                    )
                return {"ok": True}
            # Structural mode: target is a BlockNodeAddress (incl. tableCell)
            # with content = paragraph fragment, placement = insideStart/End.
            if target.get("kind") == "block" and target.get("nodeType") == "tableCell":
                cell_nid = target.get("nodeId")
                content = params.get("content") or {}
                # Extract text from either a prosemirror `{type:"paragraph",
                # content:[{type:"text",text:"…"}]}` fragment OR a Superdoc
                # native `{kind:"paragraph", paragraph:{inlines:[{run:...}]}}`
                # fragment.
                appended: str = ""
                if isinstance(content, dict):
                    inline_list = content.get("content")
                    if isinstance(inline_list, list):
                        for inl in inline_list:
                            if isinstance(inl, dict) and inl.get("type") == "text":
                                t = inl.get("text")
                                if isinstance(t, str):
                                    appended += t
                    # Superdoc native shape
                    para = content.get("paragraph")
                    if isinstance(para, dict):
                        inlines = para.get("inlines") or []
                        if isinstance(inlines, list):
                            for inl in inlines:
                                if isinstance(inl, dict):
                                    run = inl.get("run")
                                    if isinstance(run, dict):
                                        t = run.get("text")
                                        if isinstance(t, str):
                                            appended += t
                # Find cell and append to its first paragraph.
                for t in self.tables:
                    for r_idx, row in enumerate(t.cells):
                        for c_idx, cell in enumerate(row):
                            expected_ids = {
                                f"cell_{t.node_id}_{r_idx}_{c_idx}",
                                cell.node_id,
                            }
                            if cell_nid in expected_ids:
                                cell.text = cell.text + appended
                                cell.inlines = (
                                    [{"run": {"text": cell.text}}]
                                    if cell.text
                                    else []
                                )
            return {"ok": True}

        # TableSetCell: address a cell by (tableNodeId, row, col) and
        # append its content. Mirrors the apps/api applier's behavior
        # (resolve cell server-side, then ``insert`` with placement=
        # insideEnd). For merged regions, find the master cell whose
        # group contains (row, col) and write there — same aliasing
        # semantics that ``tables.getCells`` + ``insert(tableCell)``
        # produced in the legacy path.
        if op == "tables.setCell":
            tnid = str(params.get("tableNodeId", ""))
            r = params.get("rowIndex")
            c = params.get("columnIndex")
            content = params.get("content") or {}
            if not isinstance(r, int) or not isinstance(c, int):
                return {"ok": True}
            # Extract appended text from the SuperDoc native paragraph
            # fragment shape (matches the SDK's plain-text fast path).
            appended: str = ""
            if isinstance(content, dict):
                para = content.get("paragraph")
                if isinstance(para, dict):
                    inlines = para.get("inlines") or []
                    if isinstance(inlines, list):
                        for inl in inlines:
                            if isinstance(inl, dict):
                                run = inl.get("run")
                                if isinstance(run, dict):
                                    t = run.get("text")
                                    if isinstance(t, str):
                                        appended += t
                # Prosemirror-flavored fallback shape used by some markdown
                # responses: ``{type:"paragraph", content:[{type:"text", text}]}``.
                inline_list = content.get("content")
                if isinstance(inline_list, list):
                    for inl in inline_list:
                        if isinstance(inl, dict) and inl.get("type") == "text":
                            t = inl.get("text")
                            if isinstance(t, str):
                                appended += t
            # Resolve the table; fall back to the only table when the
            # node id isn't a hit (the fake doesn't model clientIdMap
            # rewriting — the SDK's setter passes ``self._table._node_id``
            # which may be a client UUID at first add_table).
            table = None
            for t in self.tables:
                if t.node_id == tnid:
                    table = t
                    break
            if table is None and len(self.tables) == 1:
                table = self.tables[0]
            if table is None:
                return {"ok": True}
            # Map (r, c) through any merge groups: the master cell is the
            # top-left of the group, and writes go there for every aliased
            # position.
            target_rc = (r, c)
            for group in table.merge_groups:
                if (r, c) in group:
                    target_rc = min(group)  # top-left
                    break
            tr, tc = target_rc
            if 0 <= tr < len(table.cells) and 0 <= tc < len(table.cells[tr]):
                cell = table.cells[tr][tc]
                cell.text = cell.text + appended
                cell.inlines = (
                    [{"run": {"text": cell.text}}] if cell.text else []
                )
            return {"ok": True}

        # markdown_to_fragment: return a minimal-valid Superdoc fragment.
        if op == "markdownToFragment":
            md = params.get("markdown", "")
            return {
                "fragment": {
                    "kind": "paragraph",
                    "paragraph": {
                        "inlines": (
                            [{"kind": "run", "run": {"text": md}}]
                            if md else []
                        ),
                    },
                },
                "lossy": False,
                "diagnostics": [],
            }

        if op in ("insertLineBreak", "insertTab"):
            blk_id = params.get("blockId")
            if blk_id:
                b = self._find_block(str(blk_id))
                if b is not None:
                    char = "\n" if op == "insertLineBreak" else "\t"
                    raw_off = params.get("offset")
                    offset = raw_off if isinstance(raw_off, int) else len(b.text)
                    new_inline = {"run": {"text": char}}
                    if not b.inlines:
                        b.inlines = [new_inline]
                    else:
                        new_inlines: list[dict] = []
                        cursor = 0
                        placed = False
                        for inl in b.inlines:
                            txt = (inl.get("run") or {}).get("text", "") if isinstance(inl, dict) else ""
                            ilen = len(txt)
                            if placed:
                                new_inlines.append(inl)
                                continue
                            if offset <= cursor:
                                new_inlines.append(new_inline)
                                new_inlines.append(inl)
                                placed = True
                            elif offset >= cursor + ilen:
                                new_inlines.append(inl)
                                if offset == cursor + ilen:
                                    new_inlines.append(new_inline)
                                    placed = True
                            else:
                                rel = offset - cursor
                                run0 = dict(inl.get("run") or {})
                                run0["text"] = txt[:rel]
                                run1 = dict(inl.get("run") or {})
                                run1["text"] = txt[rel:]
                                new_inlines.append({"run": run0})
                                new_inlines.append(new_inline)
                                new_inlines.append({"run": run1})
                                placed = True
                            cursor += ilen
                        if not placed:
                            new_inlines.append(new_inline)
                        b.inlines = [
                            i
                            for i in new_inlines
                            if (i.get("run") or {}).get("text", "") != ""
                        ]
                    b.text = "".join(
                        (i.get("run") or {}).get("text", "")
                        for i in b.inlines
                        if isinstance(i, dict)
                    )
            return {"ok": True}

        # ---- format.apply (inline) ----
        if op == "format.apply":
            target = params.get("target") or {}
            inline = params.get("inline") or {}
            blk_id = target.get("blockId")
            if blk_id:
                b = self._find_block(str(blk_id))
                if b is not None and b.inlines:
                    rng = target.get("range") or {}
                    start = rng.get("start", 0)
                    end = rng.get("end", len(b.text))
                    # Walk inlines, splitting any whose offsets straddle
                    # `start` or `end`, then apply marks to inlines fully
                    # inside [start, end). Mirrors how real SuperDoc /
                    # ProseMirror surfaces a marked text range — the run
                    # under the cursor is split so the new mark doesn't
                    # bleed into adjacent text.
                    new_inlines: list[dict] = []
                    cursor = 0
                    for inl in b.inlines:
                        if not isinstance(inl, dict):
                            new_inlines.append(inl)
                            continue
                        run = inl.get("run") or {}
                        txt = run.get("text", "")
                        if not isinstance(txt, str) or txt == "":
                            new_inlines.append(inl)
                            continue
                        ilen = len(txt)
                        s_in = max(start - cursor, 0)
                        e_in = min(end - cursor, ilen)
                        # Whole inline is outside the range — keep as-is.
                        if e_in <= 0 or s_in >= ilen:
                            new_inlines.append(inl)
                            cursor += ilen
                            continue
                        # Pre-segment (before the range)
                        if s_in > 0:
                            pre = dict(run)
                            pre["text"] = txt[:s_in]
                            new_inlines.append({"run": pre})
                        # Marked segment (inside the range): copy run +
                        # apply mark keys.
                        marked = dict(run)
                        marked["text"] = txt[s_in:e_in]
                        for kind, val in inline.items():
                            marked[kind] = val
                        new_inlines.append({"run": marked})
                        # Post-segment (after the range)
                        if e_in < ilen:
                            post = dict(run)
                            post["text"] = txt[e_in:]
                            new_inlines.append({"run": post})
                        cursor += ilen
                    b.inlines = [
                        i
                        for i in new_inlines
                        if (i.get("run") or {}).get("text", "") != ""
                    ]
            return {"ok": True}

        # ---- paragraph format ----
        if op == "format.paragraph.setAlignment":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.alignment = params.get("alignment")
                b.attrs["textAlign"] = params.get("alignment")
            return {"ok": True}
        if op == "format.paragraph.clearAlignment":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.alignment = None
                b.attrs.pop("textAlign", None)
            return {"ok": True}
        if op == "format.paragraph.setIndentation":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                indent = b.attrs.setdefault("indent", {})
                for k in ("left", "right", "firstLine", "hanging"):
                    if k in params:
                        indent[k] = params[k]
            return {"ok": True}
        if op == "format.paragraph.clearIndentation":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.attrs.pop("indent", None)
            return {"ok": True}
        if op == "format.paragraph.setSpacing":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                sp = b.attrs.setdefault("spacing", {})
                for k in ("before", "after", "line", "lineRule"):
                    if k in params:
                        sp[k] = params[k]
            return {"ok": True}
        if op == "format.paragraph.clearSpacing":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.attrs.pop("spacing", None)
            return {"ok": True}
        if op == "format.paragraph.setKeepOptions":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                for k in ("keepNext", "keepLines", "widowControl"):
                    if k in params:
                        b.attrs[k] = params[k]
            return {"ok": True}
        if op == "format.paragraph.setFlowOptions":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                if "pageBreakBefore" in params:
                    b.attrs["pageBreakBefore"] = params["pageBreakBefore"]
            return {"ok": True}
        if op.startswith("format.paragraph."):
            return {"ok": True}

        # ---- styles ----
        if op == "styles.paragraph.setStyle":
            t = params.get("target") or {}
            b = self._find_block(str(t.get("nodeId")))
            if b is not None:
                b.style_id = params.get("styleId")
            return {"ok": True}
        if op.startswith("styles."):
            return {"ok": True}

        # ---- lists ----
        # lists.create / lists.attach return ``{success, item: {nodeId, ...}}``.
        # The fake doesn't model the ProseMirror list tree faithfully — it
        # only mints a deterministic listItem id keyed off the paragraph id
        # so consecutive ``add_paragraph(style="List Bullet")`` calls in
        # ``Document._convert_paragraph_to_list_item`` produce the chained
        # ``lists.create → lists.attach → lists.attach`` op sequence that
        # the op-snapshot tests pin.
        if op == "lists.create":
            target = params.get("target") or {}
            pid = str(target.get("nodeId") or "")
            return {
                "success": True,
                "listId": f"list-{pid}",
                "item": {
                    "kind": "block",
                    "nodeType": "listItem",
                    "nodeId": f"li-{pid}",
                },
            }
        if op == "lists.attach":
            target = params.get("target") or {}
            pid = str(target.get("nodeId") or "")
            return {
                "success": True,
                "item": {
                    "kind": "block",
                    "nodeType": "listItem",
                    "nodeId": f"li-{pid}",
                },
            }
        if op.startswith("lists."):
            return {"ok": True}

        # ---- tables ----
        if op == "tables.get":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                return {
                    "nodeId": t.node_id,
                    "rows": t.rows,
                    "columns": t.cols,
                    "styleId": t.style_id,
                    "columnInfo": [{"widthPt": w} for w in t.col_widths],
                    "rowInfo": [{"heightPt": h, "rule": rule} for h, rule in t.row_heights],
                }
            return {"rows": 0, "columns": 0}
        if op == "tables.getProperties":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                return {
                    "nodeId": t.node_id,
                    "styleId": t.style_id,
                    "alignment": t.alignment,
                    "direction": t.direction,
                    "autoFitMode": t.auto_fit_mode,
                }
            return {}
        if op == "tables.getCells":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is None:
                return {"cells": []}
            r = params.get("rowIndex")
            c = params.get("columnIndex")

            # Build a (r,c) → master-cell-position map from merge groups.
            # Master is the top-left of each group; any non-master position
            # in the group resolves to the master, which is how
            # ProseMirror/OOXML grids work and what python-docx mirrors at
            # the API level (cell(r,c).text returns master text for any
            # position in the merge).
            master_of: dict[tuple[int, int], tuple[int, int]] = {}
            colspans: dict[tuple[int, int], int] = {}
            rowspans: dict[tuple[int, int], int] = {}
            for group in t.merge_groups:
                if not group:
                    continue
                top = min(group, key=lambda rc: (rc[0], rc[1]))
                rows_in = {rc[0] for rc in group}
                cols_in = {rc[1] for rc in group}
                for rc in group:
                    master_of[rc] = top
                colspans[top] = len(cols_in)
                rowspans[top] = len(rows_in)

            def cell_entry(r_idx: int, c_idx: int) -> dict:
                # Resolve grid position → master.
                master = master_of.get((r_idx, c_idx), (r_idx, c_idx))
                m_r, m_c = master
                cell = t.cells[m_r][m_c]
                cs = colspans.get(master, 1)
                rs = rowspans.get(master, 1)
                return {
                    "nodeId": f"cell_{t.node_id}_{m_r}_{m_c}",
                    "address": {
                        "kind": "block",
                        "nodeType": "tableCell",
                        "nodeId": f"cell_{t.node_id}_{m_r}_{m_c}",
                    },
                    "rowIndex": m_r,
                    "columnIndex": m_c,
                    "colspan": cs,
                    "rowspan": rs,
                    "text": cell.text,
                    "preferredWidthPt": t.cell_widths[m_r][m_c] or None,
                    "verticalAlign": t.cell_verticals[m_r][m_c],
                }

            cells: list[dict] = []
            seen_masters: set[tuple[int, int]] = set()
            for r_idx, row in enumerate(t.cells):
                for c_idx in range(len(row)):
                    if r is not None and r_idx != r:
                        continue
                    if c is not None and c_idx != c:
                        continue
                    master = master_of.get((r_idx, c_idx), (r_idx, c_idx))
                    # When iterating without a specific column, dedupe by
                    # master so callers don't see duplicate entries for
                    # the same merged region.
                    if (r is None or c is None) and master in seen_masters:
                        continue
                    seen_masters.add(master)
                    cells.append(cell_entry(r_idx, c_idx))
            return {
                "nodeId": t.node_id,
                "address": {"kind": "block", "nodeType": "table", "nodeId": t.node_id},
                "cells": cells,
            }
        if op == "tables.insertRow":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                t.rows += 1
                new_row = []
                for c in range(t.cols):
                    nid = f"tp_{t.node_id}_{t.rows - 1}_{c}"
                    new_row.append(_Block(nid, "paragraph", ""))
                t.cells.append(new_row)
                t.row_heights.append((0.0, "auto"))
                t.cell_verticals.append(["top"] * t.cols)
                t.cell_widths.append([0.0] * t.cols)
            return {"ok": True}
        if op == "tables.insertColumn":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                t.cols += 1
                for r_idx, row in enumerate(t.cells):
                    nid = f"tp_{t.node_id}_{r_idx}_{t.cols - 1}"
                    row.append(_Block(nid, "paragraph", ""))
                    t.cell_verticals[r_idx].append("top")
                    t.cell_widths[r_idx].append(0.0)
                t.col_widths.append(0.0)
            return {"ok": True}
        if op == "tables.setStyle":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                t.style_id = params.get("styleId") or t.style_id
            return {"ok": True}
        if op == "tables.setRowHeight":
            tid = params.get("nodeId") or (params.get("target", {}) or {}).get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                r = params.get("rowIndex", 0)
                if 0 <= r < t.rows:
                    t.row_heights[r] = (params.get("heightPt", 0.0), params.get("rule", "auto"))
            return {"ok": True}
        if op == "tables.setColumnWidth":
            tid = params.get("nodeId") or (params.get("target", {}) or {}).get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                c = params.get("columnIndex", 0)
                if 0 <= c < t.cols:
                    t.col_widths[c] = params.get("widthPt", 0.0)
            return {"ok": True}
        if op == "tables.setCellProperties":
            target = params.get("target") or {}
            nid = target.get("nodeId") or params.get("nodeId")
            # Find the cell
            for t in self.tables:
                for r_idx, row in enumerate(t.cells):
                    for c_idx, _cell in enumerate(row):
                        if nid == f"cell_{t.node_id}_{r_idx}_{c_idx}":
                            if "verticalAlign" in params:
                                t.cell_verticals[r_idx][c_idx] = params["verticalAlign"]
                            if "preferredWidthPt" in params:
                                t.cell_widths[r_idx][c_idx] = params["preferredWidthPt"]
            return {"ok": True}
        if op == "tables.setTableOptions":
            # Per SuperDoc 1.8.1 setTableOptions only handles
            # default-cell-margins and cell-spacing — alignment and
            # direction live on setLayout. Accept the args for
            # robustness even though the canonical caller routes
            # alignment/direction through setLayout now.
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                if "alignment" in params:
                    t.alignment = params["alignment"]
                if "direction" in params:
                    t.direction = params["direction"]
            return {"ok": True}
        if op == "tables.setLayout":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                # SuperDoc's wire field is autoFitMode (not autoFit).
                # Accept both for backward-compat with old fixture
                # data; the canonical caller now sends autoFitMode.
                if "autoFitMode" in params:
                    t.auto_fit_mode = params["autoFitMode"]
                elif "autoFit" in params:
                    t.auto_fit_mode = params["autoFit"]
                if "alignment" in params:
                    t.alignment = params["alignment"]
                if "tableDirection" in params:
                    t.direction = params["tableDirection"]
            return {"ok": True}
        if op == "tables.mergeCells":
            tid = params.get("nodeId")
            t = self._find_table(str(tid))
            if t is not None:
                start = params.get("start") or {}
                end = params.get("end") or {}
                r0 = start.get("rowIndex", 0)
                c0 = start.get("columnIndex", 0)
                r1 = end.get("rowIndex", r0)
                c1 = end.get("columnIndex", c0)
                group: set[tuple[int, int]] = set()
                for r_i in range(min(r0, r1), max(r0, r1) + 1):
                    for c_i in range(min(c0, c1), max(c0, c1) + 1):
                        if 0 <= r_i < t.rows and 0 <= c_i < t.cols:
                            group.add((r_i, c_i))
                if group:
                    t.merge_groups.append(group)
            return {"ok": True}
        if op.startswith("tables."):
            return {"ok": True}

        # ---- sections ----
        if op == "sections.list":
            return {
                "total": len(self.sections),
                "items": [
                    {
                        "id": s.id,
                        "address": {"kind": "section", "sectionId": s.id},
                        "index": i,
                        "range": {"startParagraphIndex": 0, "endParagraphIndex": 0},
                        "breakType": s.break_type,
                        "pageSetup": s.page_setup,
                    }
                    for i, s in enumerate(self.sections)
                ],
            }
        if op == "sections.get":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), self.sections[0] if self.sections else None)
            if s is None:
                return {}
            return {
                "address": target,
                "index": 0,
                "range": {"startParagraphIndex": 0, "endParagraphIndex": 0},
                "breakType": s.break_type,
                "pageSetup": s.page_setup,
                "margins": s.margins,
                "headerFooterMargins": s.header_footer_margins,
                "titlePage": s.title_page,
            }
        if op == "sections.setPageMargins":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                for k in ("top", "right", "bottom", "left", "gutter"):
                    if k in params:
                        s.margins[k] = params[k]
            return {"ok": True}
        if op == "sections.setPageSetup":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                for k in ("width", "height", "orientation", "paperSize"):
                    if k in params:
                        s.page_setup[k] = params[k]
            return {"ok": True}
        if op == "sections.setHeaderFooterMargins":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                for k in ("header", "footer"):
                    if k in params:
                        s.header_footer_margins[k] = params[k]
            return {"ok": True}
        if op == "sections.setBreakType":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                s.break_type = params.get("breakType", s.break_type)
            return {"ok": True}
        if op == "sections.setTitlePage":
            target = params.get("target") or {}
            sec_id = target.get("sectionId")
            s = next((x for x in self.sections if x.id == sec_id), None)
            if s is not None:
                # SuperDoc renamed the field to `enabled` — accept both
                # names so the fake doesn't drift from the real wire.
                if "enabled" in params:
                    s.title_page = bool(params["enabled"])
                elif "titlePage" in params:
                    s.title_page = bool(params["titlePage"])
            return {"ok": True}
        if op.startswith("sections."):
            return {"ok": True}

        # ---- images ----
        if op == "images.list":
            return {"items": list(self.images)}
        if op == "images.setSize":
            # SuperDoc shape: {imageId, size: {width, height, unit?}}.
            # Accept the legacy {nodeId, widthPt, heightPt} shape too
            # so the fake doesn't drift from older callers during the
            # cutover.
            iid = params.get("imageId") or params.get("nodeId")
            size = params.get("size") if isinstance(params.get("size"), dict) else None
            for im in self.images:
                if im.get("nodeId") == iid:
                    if size is not None:
                        im["size"] = {
                            "width": size.get("width", im["size"].get("width")),
                            "height": size.get("height", im["size"].get("height")),
                        }
                    else:
                        im["size"] = {
                            "width": params.get("widthPt", im["size"].get("width")),
                            "height": params.get("heightPt", im["size"].get("height")),
                        }
            return {"ok": True}
        if op.startswith("images."):
            return {"ok": True}

        # ---- fallthrough ----
        return {"ok": True}

    def _place_block(self, at: dict | None, block: _Block) -> None:
        if not at or at.get("kind") == "documentEnd":
            self.blocks.append(block)
            return
        if at.get("kind") == "documentStart":
            self.blocks.insert(0, block)
            return
        target = at.get("target") or {}
        target_id = target.get("nodeId")
        # Target at top level?
        for i, b in enumerate(self.blocks):
            if b.node_id == target_id:
                if at.get("kind") == "before":
                    self.blocks.insert(i, block)
                else:
                    self.blocks.insert(i + 1, block)
                return
        # Target inside a cell?
        if target_id:
            owner = self._find_cell_owner(str(target_id))
            if owner is not None:
                t, r_idx, c_idx = owner
                # Append to the cell's extra-paragraph list.
                extras = t.cell_extra_paragraphs.setdefault((r_idx, c_idx), [])
                extras.append(block)
                return
        self.blocks.append(block)


class FakeSession:
    """Drop-in replacement for docx.client.Session used in fidelity tests."""

    def __init__(
        self,
        *,
        asset_id: str,
        user_info: dict | None = None,  # noqa: ARG002
        bundle: dict[str, str] | None = None,  # noqa: ARG002
        transport: str = "direct",  # noqa: ARG002
        http_base_url: str | None = None,  # noqa: ARG002
        http_api_key: str | None = None,  # noqa: ARG002
    ) -> None:
        self._asset_id: str = asset_id
        self._state: FakeDocState = FakeDocState()
        self._opened: bool = True
        self._closed: bool = False
        self._methods: FakeSDKMethods = FakeSDKMethods(self._state)

    @property
    def asset_id(self) -> str:
        return self._asset_id

    @property
    def is_open(self) -> bool:
        return self._opened and not self._closed

    @property
    def doc(self) -> FakeSDKMethods:
        return self._methods

    async def open(self) -> None:
        self._opened = True

    async def save(self, *, in_place: bool = True) -> None:  # noqa: ARG002
        return None

    async def close(self) -> None:
        self._closed = True

    def calls(self) -> list[tuple[str, dict]]:
        return self._state.calls

    def state(self) -> FakeDocState:
        return self._state


def install_fake_session() -> None:
    """Monkey-patch docx.client.Session globally so Document() uses the fake."""
    import docx.client
    import docx.document

    docx.client.Session = FakeSession  # type: ignore[misc]
    docx.document.Session = FakeSession  # type: ignore[misc]
