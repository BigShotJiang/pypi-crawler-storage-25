"""Tests for Document.create(docx=...) — seeding from a local .docx.

Covers the new template kwarg without hitting a real server:
- agora URL derivation from docx-studio URL
- explicit agora_base_url override
- upload routing through agora's /api/super-docs/create-from-upload
"""

from __future__ import annotations

import json
import os
import tempfile
from typing import Any
from unittest.mock import patch

import pytest

from docx import Document
from docx._http import _derive_agora_base_url, upload_document
from docx.errors import AuthenticationError, DocxError, SessionError


_FAKE_UPLOAD_RESPONSE: dict[str, Any] = {
    "id": "asset_aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    "title": "My Template Seeded Doc",
}


class _FakeResponse:
    def __init__(self, body: bytes, status: int = 201) -> None:
        self._body = body
        self.status = status

    def __enter__(self) -> "_FakeResponse":
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def read(self) -> bytes:
        return self._body


def _make_docx_tmpfile() -> str:
    fd, path = tempfile.mkstemp(suffix=".docx")
    os.close(fd)
    with open(path, "wb") as f:
        f.write(b"PK\x03\x04fake-docx-bytes")
    return path


def test_derive_agora_base_url_substitutes_studio_host() -> None:
    """docx-studio → agora across staging / prod / preview hosts."""
    assert (
        _derive_agora_base_url("https://docx-studio.stg.athenaintel.com")
        == "https://agora.stg.athenaintel.com"
    )
    assert (
        _derive_agora_base_url("https://docx-studio.prd.athenaintel.com")
        == "https://agora.prd.athenaintel.com"
    )
    assert (
        _derive_agora_base_url(
            "https://docx-studio-pr20654-preview.previews.athenaintel.com"
        )
        == "https://agora-pr20654-preview.previews.athenaintel.com"
    )


def test_derive_agora_base_url_returns_none_for_unrelated_hosts() -> None:
    """Local URLs (localhost:4100) don't follow the studio convention,
    so derivation returns None and the caller must supply agora_base_url
    explicitly."""
    assert _derive_agora_base_url("http://localhost:4100") is None
    assert _derive_agora_base_url("https://unrelated.example.com") is None


def test_upload_document_posts_to_agora_with_multipart(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """upload_document() should POST multipart to agora's
    /api/super-docs/create-from-upload with is_template=false in the
    query string."""
    monkeypatch.setenv("ATHENA_DOCX_API_KEY", "bg_test_key")
    monkeypatch.setenv("ATHENA_DOCX_BASE_URL", "https://docx-studio.stg.athenaintel.com")

    captured: dict[str, Any] = {}

    def _fake_urlopen(req, timeout):  # noqa: ANN001 - urllib.Request type
        captured["url"] = req.full_url
        captured["method"] = req.get_method()
        captured["content_type"] = req.get_header("Content-type")
        captured["auth"] = req.get_header("Authorization")
        captured["body_starts_with"] = bytes(req.data)[:200]
        return _FakeResponse(json.dumps(_FAKE_UPLOAD_RESPONSE).encode("utf-8"))

    path = _make_docx_tmpfile()
    try:
        with patch("docx._http.urllib.request.urlopen", side_effect=_fake_urlopen):
            result = upload_document(docx_path=path, name="My Template Seeded Doc")
    finally:
        os.unlink(path)

    assert result["asset_id"] == _FAKE_UPLOAD_RESPONSE["id"]
    assert result["name"] == _FAKE_UPLOAD_RESPONSE["title"]
    # Verify URL routes to agora (not docx-studio) and carries query params.
    assert captured["url"].startswith(
        "https://agora.stg.athenaintel.com/api/super-docs/create-from-upload",
    )
    assert "is_template=false" in captured["url"]
    assert "title=My+Template+Seeded+Doc" in captured["url"]
    assert captured["method"] == "POST"
    assert "multipart/form-data" in captured["content_type"]
    assert captured["auth"] == "Bearer bg_test_key"


def test_upload_document_explicit_agora_base_url_overrides_derivation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Explicit agora_base_url kwarg wins over both env var and host
    derivation — needed for local dev where the derivation rule doesn't
    apply."""
    monkeypatch.setenv("ATHENA_DOCX_API_KEY", "bg_test_key")
    monkeypatch.setenv(
        "ATHENA_AGORA_BASE_URL", "https://agora-from-env.example.com",
    )

    captured: dict[str, Any] = {}

    def _fake_urlopen(req, timeout):  # noqa: ANN001
        captured["url"] = req.full_url
        return _FakeResponse(json.dumps(_FAKE_UPLOAD_RESPONSE).encode("utf-8"))

    path = _make_docx_tmpfile()
    try:
        with patch("docx._http.urllib.request.urlopen", side_effect=_fake_urlopen):
            upload_document(
                docx_path=path,
                docx_base_url="http://localhost:4100",
                agora_base_url="http://localhost:8000",
                name="x",
            )
    finally:
        os.unlink(path)

    assert captured["url"].startswith(
        "http://localhost:8000/api/super-docs/create-from-upload",
    )


def test_upload_document_uses_ATHENA_AGORA_BASE_URL_env_var(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ATHENA_DOCX_API_KEY", "bg_test_key")
    monkeypatch.setenv("ATHENA_AGORA_BASE_URL", "https://agora.example.com")
    monkeypatch.delenv("ATHENA_DOCX_BASE_URL", raising=False)

    captured: dict[str, Any] = {}

    def _fake_urlopen(req, timeout):  # noqa: ANN001
        captured["url"] = req.full_url
        return _FakeResponse(json.dumps(_FAKE_UPLOAD_RESPONSE).encode("utf-8"))

    path = _make_docx_tmpfile()
    try:
        with patch("docx._http.urllib.request.urlopen", side_effect=_fake_urlopen):
            upload_document(docx_path=path, name="x")
    finally:
        os.unlink(path)

    assert captured["url"].startswith(
        "https://agora.example.com/api/super-docs/create-from-upload",
    )


def test_upload_document_rejects_non_docx_files() -> None:
    fd, path = tempfile.mkstemp(suffix=".txt")
    os.close(fd)
    try:
        with pytest.raises(SessionError, match="Only .docx files"):
            upload_document(
                docx_path=path,
                agora_base_url="https://agora.example.com",
                api_key="bg_test_key",
            )
    finally:
        os.unlink(path)


def test_upload_document_missing_agora_base_url_raises_clear_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If we can't resolve an agora URL from any of the inputs, fail
    early with a message that names the env vars to set."""
    monkeypatch.setenv("ATHENA_DOCX_API_KEY", "bg_test_key")
    monkeypatch.delenv("ATHENA_DOCX_BASE_URL", raising=False)
    monkeypatch.delenv("ATHENA_AGORA_BASE_URL", raising=False)

    path = _make_docx_tmpfile()
    try:
        with pytest.raises(SessionError, match="ATHENA_AGORA_BASE_URL"):
            upload_document(docx_path=path, name="x")
    finally:
        os.unlink(path)


def test_upload_document_missing_api_key_raises_authentication_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("ATHENA_DOCX_API_KEY", raising=False)

    path = _make_docx_tmpfile()
    try:
        with pytest.raises(AuthenticationError, match="ATHENA_DOCX_API_KEY"):
            upload_document(
                docx_path=path,
                agora_base_url="https://agora.example.com",
                name="x",
            )
    finally:
        os.unlink(path)


def test_document_create_with_docx_kwarg_routes_to_upload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Document.create(docx=...) must call upload_document, NOT
    create_empty_document — the latter would create a blank doc and
    ignore the template entirely."""
    captured: dict[str, Any] = {}

    def _fake_upload_document(**kwargs: Any) -> dict[str, Any]:
        captured.update(kwargs)
        return {"asset_id": "asset_new_from_template", "name": "x"}

    def _fake_create_empty(**_: Any) -> dict[str, Any]:
        raise AssertionError(
            "create_empty_document should NOT be called when docx= is set",
        )

    monkeypatch.setattr("docx._http.upload_document", _fake_upload_document)
    monkeypatch.setattr("docx._http.create_empty_document", _fake_create_empty)

    path = _make_docx_tmpfile()
    try:
        doc = Document.create(
            name="My Doc",
            base_url="https://docx-studio.stg.athenaintel.com",
            api_key="bg_test_key",
            docx=path,
        )
    finally:
        os.unlink(path)

    assert doc.asset_id == "asset_new_from_template"
    assert captured["docx_path"] == path
    assert captured["name"] == "My Doc"
    assert captured["agora_base_url"] is None
    assert captured["docx_base_url"] == "https://docx-studio.stg.athenaintel.com"


def test_document_create_with_docx_and_workspace_id_fails_fast() -> None:
    """The agora upload endpoint doesn't accept workspace_id. Passing both
    docx= and workspace_id= must raise rather than silently drop the
    workspace target — that's a contract divergence from the non-docx
    path, which does honor workspace_id."""
    path = _make_docx_tmpfile()
    try:
        with pytest.raises(DocxError, match="workspace_id is not supported"):
            Document.create(
                name="My Doc",
                base_url="https://docx-studio.stg.athenaintel.com",
                api_key="bg_test_key",
                docx=path,
                workspace_id="ws_other",
            )
    finally:
        os.unlink(path)


def test_document_create_without_docx_uses_empty_endpoint(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Default path: no docx= kwarg → blank doc via /docs/empty."""

    def _fake_create_empty(**_: Any) -> dict[str, Any]:
        return {
            "asset_id": "asset_blank",
            "name": "x",
            "workspace_id": "ws_x",
            "collab": {
                "token": "t",
                "ws_url": "wss://k",
                "workspace_id": "ws_x",
            },
        }

    def _fake_upload(**_: Any) -> dict[str, Any]:
        raise AssertionError(
            "upload_document should NOT be called when docx= is unset",
        )

    monkeypatch.setattr("docx._http.create_empty_document", _fake_create_empty)
    monkeypatch.setattr("docx._http.upload_document", _fake_upload)

    doc = Document.create(
        name="My Doc",
        base_url="https://docx-studio.stg.athenaintel.com",
        api_key="bg_test_key",
    )
    assert doc.asset_id == "asset_blank"
