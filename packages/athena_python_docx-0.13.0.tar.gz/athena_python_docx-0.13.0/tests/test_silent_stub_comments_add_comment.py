"""Lock-in tests for ``Comments.add_comment`` str validation.

Previously the three parameters were typed ``str`` but not validated:
- ``text`` shipped to wire via ``comments.create({"text": value})``;
  SuperDoc's permissive parser silently coerced or rejected.
- ``author`` and ``initials`` were stashed on the local info dict
  as-is, so reads after a non-str write would return whatever was
  passed in (parity-breaking).

python-docx 1.x routes these through lxml setters that TypeError on
non-str. Mirror that.
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_comments(mock_session: Any) -> Any:
    from docx.comments import Comments

    return Comments(session=mock_session)


@pytest.mark.parametrize("value", [42, 1.5, None, [1, 2], {"a": "b"}, object()])
def test_add_comment_rejects_non_str_text(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    comments = _make_comments(mock_session)
    with pytest.raises(TypeError, match="text requires str"):
        comments.add_comment(text=value)


@pytest.mark.parametrize("value", [42, 1.5, None, [1, 2], {"a": "b"}, object()])
def test_add_comment_rejects_non_str_author(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    comments = _make_comments(mock_session)
    with pytest.raises(TypeError, match="author requires str"):
        comments.add_comment(text="ok", author=value)


@pytest.mark.parametrize("value", [42, 1.5, [1, 2], {"a": "b"}, object()])
def test_add_comment_rejects_non_str_initials(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    """Note: ``initials=None`` is valid (clears). Only non-str
    non-None inputs raise."""
    comments = _make_comments(mock_session)
    with pytest.raises(TypeError, match="initials requires str"):
        comments.add_comment(text="ok", author="A", initials=value)


def test_add_comment_accepts_valid_strings(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Happy path."""
    comments = _make_comments(mock_session)
    comment = comments.add_comment(text="hello", author="Alice", initials="A")
    assert comment is not None


def test_add_comment_accepts_none_initials(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``initials=None`` should still work (matches the type hint)."""
    comments = _make_comments(mock_session)
    comment = comments.add_comment(text="hi", author="A", initials=None)
    assert comment is not None
