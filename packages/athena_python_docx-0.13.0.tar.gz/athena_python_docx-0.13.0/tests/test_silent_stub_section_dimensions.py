"""Lock-in tests for ``Section`` dimension setters that previously
silently no-op'd on ``None``.

python-docx 1.2.0 routes ``Section.<dim> = value`` through
``Emu(value).twips``, which raises ``TypeError`` on ``None`` (because
``int(None)`` fails). Our setters early-returned with no signal, so
``section.page_width = None`` was a silent no-op that lost the
caller's intent.

The eight setters now raise ``TypeError`` to match upstream behavior.
Callers who want to zero a dimension must pass an explicit ``Length``
like ``Inches(0)``.
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_section(mock_session: Any) -> Any:
    from docx.section import Section

    return Section(
        session=mock_session,
        address={"kind": "section", "sectionIndex": 0},
    )


@pytest.mark.parametrize(
    "prop",
    [
        "page_width",
        "page_height",
        "left_margin",
        "right_margin",
        "top_margin",
        "bottom_margin",
        "gutter",
        "header_distance",
        "footer_distance",
    ],
)
def test_section_dimension_setter_rejects_none(
    mock_session: Any, fake_sd_methods: Any, prop: str
) -> None:
    """``Section.<dim> = None`` raises ``TypeError`` (mirrors python-docx
    1.2.0's ``Emu(None).twips``) — was a silent no-op."""
    section = _make_section(mock_session)
    with pytest.raises(TypeError, match=prop):
        setattr(section, prop, None)


def test_page_width_with_length_still_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """The happy path: an explicit ``Length`` still issues a
    ``sections.setPageSetup`` (or equivalent) call. Pin so the
    strict-None gate doesn't accidentally break real assignments."""
    from docx.shared import Inches

    section = _make_section(mock_session)
    before = sum(
        1
        for c in fake_sd_methods.calls
        if c[0] == "sections.set_page_setup"
    )
    section.page_width = Inches(8.5)
    after = sum(
        1
        for c in fake_sd_methods.calls
        if c[0] == "sections.set_page_setup"
    )
    assert after - before == 1


def test_left_margin_with_length_still_ships_to_wire(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Margin happy-path pin."""
    from docx.shared import Inches

    section = _make_section(mock_session)
    before = sum(
        1
        for c in fake_sd_methods.calls
        if c[0] == "sections.set_page_margins"
    )
    section.left_margin = Inches(1)
    after = sum(
        1
        for c in fake_sd_methods.calls
        if c[0] == "sections.set_page_margins"
    )
    assert after - before == 1
