"""Lock-in tests for ``Paragraph.insert_paragraph_before`` ``text`` /
``style`` validation.

Same silent-stub pattern as ``Paragraph.add_run`` (fixed in
``c049996dce``): ``text or ""`` silently coerced falsy non-string
values, ``style`` passed through to ``Paragraph.style.setter`` which
itself had a catch-all ``str(value)`` for unknown types.

Now both raise ``TypeError`` upfront when not ``str | None`` (text)
or ``str | ParagraphStyle | None`` (style).
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_paragraph(mock_session: Any) -> Any:
    from docx.text.paragraph import Paragraph

    return Paragraph(
        session=mock_session,
        node_id="p1",
        node_type="paragraph",
    )


@pytest.mark.parametrize("value", [42, 1.5, [1, 2], {"a": "b"}, object()])
def test_insert_paragraph_before_rejects_non_str_text(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    para = _make_paragraph(mock_session)
    with pytest.raises(TypeError, match="str or None"):
        para.insert_paragraph_before(text=value)


@pytest.mark.parametrize("value", [42, 1.5, [1, 2], {"a": "b"}, object()])
def test_insert_paragraph_before_rejects_invalid_style_type(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    para = _make_paragraph(mock_session)
    with pytest.raises(TypeError, match="ParagraphStyle"):
        para.insert_paragraph_before(text="hi", style=value)


def test_insert_paragraph_before_accepts_none(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Default args (no text, no style) still work."""
    para = _make_paragraph(mock_session)
    # We just want this not to raise — output binding requires more
    # mock setup than is useful here.
    try:
        para.insert_paragraph_before()
    except RuntimeError:
        # RuntimeError when the fake session doesn't return a nodeId
        # is fine — we're verifying the validation gate doesn't fire,
        # not the full wire round-trip.
        pass
