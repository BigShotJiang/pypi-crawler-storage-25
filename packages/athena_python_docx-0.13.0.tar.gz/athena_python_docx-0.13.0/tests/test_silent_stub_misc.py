"""Lock-in tests for the silent-stub warnings on
``RenderedPageBreak`` fragment accessors, ``_ColorProxy.type``, and
``Comment.author`` / ``Comment.initials`` setters.

These four operations used to be silent no-ops / silent-None reads:

1. ``RenderedPageBreak.preceding_paragraph_fragment`` returned ``None``
   without signaling that SuperDoc's flat model can't materialize the
   pre-break fragment.
2. ``RenderedPageBreak.following_paragraph_fragment`` — same.
3. ``Font.color.type`` returned ``None`` without flagging that
   SuperDoc inline runs don't expose MSO_COLOR_TYPE / theme-color
   metadata.
4. ``Comment.author`` / ``Comment.initials`` setters stashed the
   value on ``self._info`` without persisting via ``comments.patch``
   (SuperDoc derives attribution from session credentials).

These are now warn-and-no-op (or warn-and-stash). When the matching
SuperDoc ops land, the warnings can be removed and the tests should
flip to assert real wire-bus calls. Tracked in
``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` §§ 7, 10, 11.
"""

from __future__ import annotations

import warnings
from typing import Any

import pytest

from docx.comments import (
    Comment,
    PendingCommentBlockSurfaceWarning,
    PendingCommentMetadataWarning,
)
from docx.text.pagebreak import (
    PendingPageBreakFragmentWarning,
    RenderedPageBreak,
)
from docx.text.run import PendingColorTypeWarning, Run


# ---------------------------------------------------------------------
# RenderedPageBreak fragment accessors
# ---------------------------------------------------------------------


def _make_rendered_page_break() -> RenderedPageBreak:
    """Construct a RenderedPageBreak without a real paragraph.

    The fragment accessors don't dereference ``_paragraph``, so a
    plain ``object()`` stand-in is enough to satisfy the kw-only ctor.
    """
    return RenderedPageBreak(
        paragraph=object(),  # type: ignore[arg-type]
        offset=5,
        preceding_text="hello",
    )


def test_preceding_paragraph_fragment_returns_none_and_warns() -> None:
    rpb = _make_rendered_page_break()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        value = rpb.preceding_paragraph_fragment

    assert value is None
    pending = [
        w for w in captured if issubclass(w.category, PendingPageBreakFragmentWarning)
    ]
    assert len(pending) == 1
    assert "preceding_paragraph_fragment" in str(pending[0].message)


def test_following_paragraph_fragment_returns_none_and_warns() -> None:
    rpb = _make_rendered_page_break()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        value = rpb.following_paragraph_fragment

    assert value is None
    pending = [
        w for w in captured if issubclass(w.category, PendingPageBreakFragmentWarning)
    ]
    assert len(pending) == 1
    assert "following_paragraph_fragment" in str(pending[0].message)


def test_preceding_paragraph_text_does_not_warn() -> None:
    """The athena-specific ``preceding_paragraph_text`` property is
    fully supported — accessing it must NOT emit the upstream-gap
    warning."""
    rpb = _make_rendered_page_break()
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        text = rpb.preceding_paragraph_text

    pending = [
        w for w in captured if issubclass(w.category, PendingPageBreakFragmentWarning)
    ]
    assert pending == []
    assert text == "hello"


def test_pagebreak_fragment_warning_points_to_superdoc_constraint() -> None:
    """The warning text should name the upstream constraint so users
    understand it's a SuperDoc gap, not an athena bug."""
    rpb = _make_rendered_page_break()
    with pytest.warns(PendingPageBreakFragmentWarning) as captured:
        _ = rpb.preceding_paragraph_fragment
    assert len(captured) == 1
    msg = str(captured[0].message)
    assert "SuperDoc" in msg
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in msg


# ---------------------------------------------------------------------
# _ColorProxy.type
# ---------------------------------------------------------------------


def test_color_type_returns_none_and_warns(mock_session: Any) -> None:
    """``Font.color.type`` returns None (SuperDoc doesn't expose
    color-type metadata) and emits a warning so callers know the
    value isn't a real upstream None."""
    run = Run(session=mock_session, block_id="p1", range_=(0, 5))
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        value = run.font.color.type

    assert value is None
    pending = [w for w in captured if issubclass(w.category, PendingColorTypeWarning)]
    assert len(pending) == 1
    msg = str(pending[0].message)
    assert "Font.color.type" in msg
    assert "SuperDoc" in msg
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in msg


# ---------------------------------------------------------------------
# Comment.author / Comment.initials setters
# ---------------------------------------------------------------------


def _make_comment(mock_session: Any) -> Comment:
    return Comment(
        session=mock_session,
        info={
            "id": "c-1",
            "commentId": "c-1",
            "text": "hi",
            "creatorName": "Original",
            "initials": "O",
        },
    )


def test_comment_author_setter_warns_once(mock_session: Any) -> None:
    c = _make_comment(mock_session)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        c.author = "Alice"

    pending = [
        w for w in captured if issubclass(w.category, PendingCommentMetadataWarning)
    ]
    assert len(pending) == 1
    assert "author" in str(pending[0].message)
    # Local stash still happens so read-back parity holds.
    assert c.author == "Alice"


def test_comment_initials_setter_warns_once(mock_session: Any) -> None:
    c = _make_comment(mock_session)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        c.initials = "AB"

    pending = [
        w for w in captured if issubclass(w.category, PendingCommentMetadataWarning)
    ]
    assert len(pending) == 1
    assert "initials" in str(pending[0].message)
    assert c.initials == "AB"


def test_comment_author_read_does_not_warn(mock_session: Any) -> None:
    """Reading ``Comment.author`` without assigning is a legitimate
    no-op — the warning is keyed to the mutation intent, not the
    read."""
    c = _make_comment(mock_session)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        author = c.author

    pending = [
        w for w in captured if issubclass(w.category, PendingCommentMetadataWarning)
    ]
    assert pending == []
    assert author == "Original"


def test_comment_metadata_warning_points_to_superdoc_constraint(
    mock_session: Any,
) -> None:
    """The warning text should name the upstream constraint so users
    understand it's a SuperDoc gap."""
    c = _make_comment(mock_session)
    with pytest.warns(PendingCommentMetadataWarning) as captured:
        c.author = "Alice"
    assert len(captured) == 1
    msg = str(captured[0].message)
    assert "SuperDoc" in msg
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in msg


# ---------------------------------------------------------------------
# Comment.paragraphs / Comment.tables block surface
# ---------------------------------------------------------------------


def test_comment_paragraphs_returns_empty_and_warns_once(mock_session: Any) -> None:
    """``Comment.paragraphs`` returns ``[]`` (SuperDoc models a comment
    as a single text body, not a BlockItemContainer) and emits a
    :class:`PendingCommentBlockSurfaceWarning` so callers learn the
    surface is lossy rather than discovering it via a quietly-empty
    iteration."""
    c = _make_comment(mock_session)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        value = c.paragraphs

    assert value == []
    pending = [
        w
        for w in captured
        if issubclass(w.category, PendingCommentBlockSurfaceWarning)
    ]
    assert len(pending) == 1
    assert "paragraphs" in str(pending[0].message)


def test_comment_tables_returns_empty_and_warns_once(mock_session: Any) -> None:
    c = _make_comment(mock_session)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        value = c.tables

    assert value == []
    pending = [
        w
        for w in captured
        if issubclass(w.category, PendingCommentBlockSurfaceWarning)
    ]
    assert len(pending) == 1
    assert "tables" in str(pending[0].message)


def test_comment_block_surface_warning_points_to_superdoc_constraint(
    mock_session: Any,
) -> None:
    c = _make_comment(mock_session)
    with pytest.warns(PendingCommentBlockSurfaceWarning) as captured:
        _ = c.paragraphs
    msg = str(captured[0].message)
    assert "SuperDoc" in msg
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in msg
    assert "comment.text" in msg.lower()
