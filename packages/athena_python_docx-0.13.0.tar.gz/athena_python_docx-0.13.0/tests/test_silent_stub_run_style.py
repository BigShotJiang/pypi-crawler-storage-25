"""Lock-in test for ``Run.style = None`` semantics.

The setter previously had ``if value is None: return`` — a silent
no-op that documented its own divergence from python-docx as
"intentional". python-docx 1.x's ``Run.style.setter`` clears the
underlying ``<w:rStyle>`` OOXML element when passed None, so the
caller's clear-intent was silently dropped.

Now ``None`` ships JSON ``null`` on the wire via ``_apply_inline``,
matching the pattern set by ``Run.bold = None``. The agora applier
forwards the null to SuperDoc, which can interpret it as a clear (or
ignore it — but at least the intent reaches the wire).
"""

from __future__ import annotations

from typing import Any


def _make_run(mock_session: Any) -> Any:
    from docx.text.run import Run

    return Run(
        session=mock_session,
        block_id="p1",
        range_=(0, 5),
        inline={"text": "hello"},
    )


def test_run_style_none_ships_null_clear(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``Run.style = None`` issues a ``format.apply`` call with
    ``rStyle: null`` on the wire — was a silent no-op pre-fix."""
    run = _make_run(mock_session)
    run.style = None
    apply_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.apply"
    ]
    assert apply_calls
    payload = apply_calls[-1][1]
    assert "rStyle" in payload["inline"]
    assert payload["inline"]["rStyle"] is None


def test_run_style_string_still_ships(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Happy path — explicit style id still ships to wire."""
    run = _make_run(mock_session)
    run.style = "Emphasis"
    apply_calls = [
        c for c in fake_sd_methods.calls if c[0] == "format.apply"
    ]
    assert apply_calls
    assert apply_calls[-1][1]["inline"]["rStyle"] == "Emphasis"
