"""Integration tests for the 0.13.0 ``Paragraph.add_run`` cell-inner
routing path.

Pre-0.13.0 contract:
    p = cell.add_paragraph("")
    r = p.add_run("Hello")   # silently drops text, returns stub Run

0.13.0 contract:
    p = cell.add_paragraph("")
    r = p.add_run("Hello")   # ships doc.insert(target=cell,
                              # placement="insideEnd", content=
                              # paragraph-fragment) — text lands live

The key wire-call assertion: ``add_run`` on a cell-inner Paragraph
WITH a back-reference to the parent ``_Cell`` issues a ``doc.insert``
call whose ``target.nodeType == "tableCell"`` and
``placement == "insideEnd"``. The returned Run carries the new
cell-paragraph's exported OOXML address so subsequent run-format
setters stash to the correct cell location.

Fallback path: paragraphs constructed without a ``_cell`` back-ref
(e.g. by tests that bypass _Cell.* construction) still warn-and-stub
so existing pre-0.13.0 tests continue to pass.
"""
from __future__ import annotations

import warnings
from typing import Any

from docx.text.paragraph import CellInnerFormatNotSupportedWarning


def _make_table_and_cell(mock_session: Any, *, doc_index: int = 0):
    """Construct a Table + _Cell that share a session.

    The Table is built with ``doc_index`` so the cell carries a
    stable OOXML address through to any Paragraph proxies it
    creates.
    """
    from docx.table import Table, _Cell

    table = Table(
        session=mock_session,
        node_id="tbl-1",
        doc_index=doc_index,
    )
    cell = _Cell(table=table, row=0, col=0)
    # Stub the addressing helpers so cell.add_paragraph doesn't
    # round-trip to the fake on every call.
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    cell._inner_paragraph_ids = lambda: ["p-cell-template"]  # type: ignore[method-assign]
    cell._count_exported_paragraphs = lambda: 1  # type: ignore[method-assign]
    return table, cell


# ---- live-text materialization --------------------------------------


def test_add_run_on_cell_paragraph_ships_doc_insert_to_cell(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """The agent's ``p = cell.add_paragraph("")`` + ``p.add_run(text)``
    pattern should issue a ``doc.insert`` against the parent cell
    (NOT the cell-inner paragraph block id, which SuperDoc rejects)."""
    _, cell = _make_table_and_cell(mock_session)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p = cell.add_paragraph("")
        # Reset the recorder so we only see the add_run wire calls.
        fake_sd_methods.calls.clear()
        r = p.add_run("Hello world")

    inserts = [c for c in fake_sd_methods.calls if c[0] == "insert"]
    assert len(inserts) == 1
    op_name, params = inserts[0]
    assert isinstance(params, dict)
    target = params["target"]
    assert target["nodeType"] == "tableCell"
    assert target["nodeId"] == "cell-1"
    assert params["placement"] == "insideEnd"
    inlines = params["content"]["paragraph"]["inlines"]
    assert inlines == [{"kind": "run", "run": {"text": "Hello world"}}]

    # Run is a real Run (not a collapsed stub) with the new text range.
    assert r._in_cell is True
    assert r._range == (0, len("Hello world"))


def test_add_run_returns_run_carrying_new_cell_ooxml_address(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """After materialization, the new Run's ``cell_ooxml_address``
    should point at the new exported paragraph index (not the
    pre-existing template paragraph)."""
    _, cell = _make_table_and_cell(mock_session, doc_index=3)
    # Track exported-paragraph count so the new run's address index
    # is computed as count-1 (the freshly-inserted paragraph).
    counter = [0]

    def _count() -> int:
        counter[0] += 1
        return counter[0]

    cell._count_exported_paragraphs = _count  # type: ignore[method-assign]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p = cell.add_paragraph("")  # consumes counter -> 1, addr_idx 0
        r = p.add_run("Hello")       # consumes counter -> 2, addr_idx 1

    assert r._cell_ooxml_address == (3, 0, 0, 1)


def test_add_run_then_bold_stashes_to_new_runs_cell_address(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``r = p.add_run(text); r.bold = True`` should stash the bold
    format prop on the NEW run's address — not on the parent
    paragraph's pre-add_run address. Otherwise the format would
    land on the template paragraph instead of the new visible content."""
    from docx._postproc import CellAddress, PostExportOps

    ops = PostExportOps()
    mock_session._post_export_ops = ops
    _, cell = _make_table_and_cell(mock_session, doc_index=2)
    counter = [0]

    def _count() -> int:
        counter[0] += 1
        return counter[0]

    cell._count_exported_paragraphs = _count  # type: ignore[method-assign]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p = cell.add_paragraph("")  # counter -> 1
        r = p.add_run("Total: $20B")  # counter -> 2
        r.bold = True

    # The bold stash lands at the NEW paragraph index (1), not at
    # the parent paragraph's index (0).
    expected_addr = CellAddress(
        table_doc_index=2, row=0, col=0, paragraph_index=1,
    )
    assert expected_addr in ops._cell_run_format_ops
    assert ops._cell_run_format_ops[expected_addr] == {"bold": True}


def test_add_run_empty_text_falls_back_to_warn_and_stub(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``p.add_run("")`` has no visible content to materialize — the
    old warn-and-stub path is preserved so the surrounding batch
    isn't disturbed. No doc.insert fires."""
    _, cell = _make_table_and_cell(mock_session)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        p = cell.add_paragraph("")
        fake_sd_methods.calls.clear()
        r = p.add_run("")
        warned = [
            x
            for x in w
            if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    # Warn fires (so the agent sees the live-state limitation).
    assert len(warned) == 1
    # No wire call for empty text.
    inserts = [c for c in fake_sd_methods.calls if c[0] == "insert"]
    assert inserts == []
    # Return value is still a Run carrying the parent paragraph's
    # cell address (so subsequent format stashes still land
    # somewhere addressable).
    assert r._in_cell is True


def test_add_run_without_cell_backref_falls_back_to_warn_and_stub(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Paragraphs constructed outside ``_Cell.add_paragraph`` /
    ``_Cell.paragraphs`` won't have a ``_cell`` back-reference. The
    pre-0.13.0 warn-and-stub fallback applies so existing call sites
    keep working."""
    from docx.text.paragraph import Paragraph

    p = Paragraph(
        session=mock_session,
        node_id="p-orphan",
        in_cell=True,
        cell_ooxml_address=(0, 0, 0, 0),
        # cell= deliberately omitted
    )
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        r = p.add_run("Hello")
        warned = [
            x
            for x in w
            if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    assert len(warned) == 1
    # No materialization wire call (no cell to target).
    inserts = [c for c in fake_sd_methods.calls if c[0] == "insert"]
    assert inserts == []
    # Stub Run returned (collapsed range, in_cell=True).
    assert r._in_cell is True
    assert r._range == (0, 0)


def test_add_run_on_body_paragraph_unaffected_by_cell_routing(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Body (non-cell) paragraphs MUST NOT route through the cell
    insert path — they go through the normal text-insert wire call.
    The 0.13.0 routing change is gated on ``_in_cell`` and ``_cell``
    both being set."""
    from docx.text.paragraph import Paragraph

    # Stub the resolve_text_len query so add_run on a fresh body
    # paragraph doesn't query get_node_by_id.
    p = Paragraph(
        session=mock_session,
        node_id="p-body",
        in_cell=False,
        text_len=0,
    )
    r = p.add_run("Hello")
    # The body path uses the segments insert directly, not
    # target.nodeType=tableCell.
    inserts = [c for c in fake_sd_methods.calls if c[0] == "insert"]
    assert len(inserts) == 1
    target = inserts[0][1]["target"]
    # Body insert targets a text range on the paragraph, not a cell.
    assert target.get("kind") != "block" or target.get("nodeType") != "tableCell"
    assert r._in_cell is False


# ---- cell.paragraphs + iter_inner_content propagation ---------------


def test_paragraphs_iterator_propagates_cell_backref(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``cell.paragraphs`` Paragraph proxies must carry ``_cell``
    back-refs so ``cell.paragraphs[0].add_run(text)`` also takes the
    new live-text path."""
    _, cell = _make_table_and_cell(mock_session)
    cell._inner_paragraph_ids = lambda: ["p-cell-template"]  # type: ignore[method-assign]
    paragraphs = cell.paragraphs
    assert len(paragraphs) == 1
    assert paragraphs[0]._cell is cell


def test_add_paragraph_propagates_cell_backref(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``cell.add_paragraph(text)`` returns a Paragraph carrying the
    ``_cell`` back-ref."""
    _, cell = _make_table_and_cell(mock_session)
    p = cell.add_paragraph("First")
    assert p._cell is cell


def test_add_run_wire_failure_falls_back_silently(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """If the cell-targeted materialization raises inside
    ``_cell_inner_add_run_via_cell_insert`` (server unreachable, bad
    response shape, etc.), ``add_run`` should fall back to warn-and-
    stub so the surrounding agent script's batch isn't taken down by
    one add_run failure.

    Simulated by patching ``cell._cell_id`` to raise — that's inside
    the helper's ``try`` block and is the cheapest failure-shape to
    inject without rebuilding the fake session.
    """
    _, cell = _make_table_and_cell(mock_session)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p = cell.add_paragraph("")
        # Pre-cache the paragraph's text length so ``add_run`` doesn't
        # round-trip get_node_by_id first.
        p._text_len = 0

    def _raise_cell_id() -> str:
        raise RuntimeError("simulated wire failure inside cell._cell_id")

    cell._cell_id = _raise_cell_id  # type: ignore[method-assign]

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        r = p.add_run("Hello")
        warned = [
            x
            for x in w
            if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    # Warn fires from the fallback path (live state can't materialize
    # the text, agent should know).
    assert len(warned) == 1
    # Stub Run returned (collapsed range, in_cell=True). The
    # surrounding batch survives — no exception propagated.
    assert r._in_cell is True
    assert r._range == (0, 0)
