"""Lock-in tests for the ``Paragraph.style`` setter style-id resolution.

Previously the setter resolved a style object via ``value.name`` (the
display name), which for built-in styles diverges from the wire-side
``style_id`` (``"Heading 1"`` vs ``"Heading1"``). The new behavior
prefers ``value.style_id`` when present, falling back to ``.name``
only when the duck-typed value lacks a style_id attribute.

This matches python-docx 1.x where
``self.part.get_style_id(style_or_name, ...)`` always resolves to the
canonical wire-side id.
"""

from __future__ import annotations

from typing import Any


class _FakeStyleWithBothFields:
    """Stand-in for ``ParagraphStyle`` with a name distinct from style_id."""

    def __init__(self, name: str, style_id: str) -> None:
        self.name = name
        self.style_id = style_id


class _FakeStyleNameOnly:
    """Stand-in for a duck-typed style that only exposes ``name``."""

    def __init__(self, name: str) -> None:
        self.name = name


def _captured_style_ids(fake_sd_methods: Any) -> list[str]:
    """Pull the ``styleId`` from every ``styles.paragraph.set_style`` call
    recorded on the fake SDK.

    The fake session at ``tests/conftest.py`` records every path-proxy
    invocation in ``calls: list[(op_name, params)]``. We filter for the
    style-apply op and project the wire-side id field."""
    out: list[str] = []
    for op_name, params in fake_sd_methods.calls:
        if op_name == "styles.paragraph.set_style" and isinstance(params, dict):
            out.append(str(params.get("styleId", "")))
    return out


def _make_paragraph(mock_session: Any, *, node_id: str = "p-1"):
    from docx.text.paragraph import Paragraph

    return Paragraph(session=mock_session, node_id=node_id)


def test_paragraph_style_setter_uses_style_id_when_provided(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """When given a style object that exposes both ``name`` and
    ``style_id``, the setter must use ``style_id``."""
    para = _make_paragraph(mock_session)
    para.style = _FakeStyleWithBothFields(name="Heading 1", style_id="Heading1")
    assert _captured_style_ids(fake_sd_methods) == ["Heading1"]


def test_paragraph_style_setter_falls_back_to_name(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Duck-typed style objects without ``style_id`` fall back to ``.name``."""
    para = _make_paragraph(mock_session)
    para.style = _FakeStyleNameOnly(name="CustomCallout")
    assert _captured_style_ids(fake_sd_methods) == ["CustomCallout"]


def test_paragraph_style_setter_accepts_plain_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    para = _make_paragraph(mock_session)
    para.style = "Heading2"
    assert _captured_style_ids(fake_sd_methods) == ["Heading2"]


def test_paragraph_style_setter_none_restores_normal(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``paragraph.style = None`` is documented as restoring 'Normal'."""
    para = _make_paragraph(mock_session)
    para.style = None
    assert _captured_style_ids(fake_sd_methods) == ["Normal"]


# ---------------------------------------------------------------------
# Run.style setter — same style_id-vs-name contract as Paragraph.style
# ---------------------------------------------------------------------


def _captured_inline_rstyle(fake_sd_methods: Any) -> list:
    """Pull the rStyle value from every ``format.apply`` call recorded
    on the fake SDK. ``Run.style.setter`` plumbs through
    ``self._apply_inline(rStyle=...)`` which lands on the bus as
    ``format.apply({inline: {rStyle: ...}, target: ...})``.

    Preserves the raw value (None vs string) so callers can
    distinguish a clear (``None``) from an explicit style id.
    """
    out: list = []
    for op_name, params in fake_sd_methods.calls:
        if op_name == "format.apply" and isinstance(params, dict):
            inline = params.get("inline") or {}
            if isinstance(inline, dict) and "rStyle" in inline:
                out.append(inline["rStyle"])
    return out


def _make_run(mock_session: Any, *, block_id: str = "p-1"):
    from docx.text.run import Run

    return Run(session=mock_session, block_id=block_id, range_=(0, 5))


def test_run_style_setter_uses_style_id_when_provided(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Run.style accepts a CharacterStyle instance and must resolve to
    its ``style_id`` (not display name) — same contract as
    ``Paragraph.style``."""
    run = _make_run(mock_session)
    run.style = _FakeStyleWithBothFields(name="Intense Quote", style_id="IntenseQuote")
    assert _captured_inline_rstyle(fake_sd_methods) == ["IntenseQuote"]


def test_run_style_setter_falls_back_to_name(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.style = _FakeStyleNameOnly(name="CustomCharStyle")
    assert _captured_inline_rstyle(fake_sd_methods) == ["CustomCharStyle"]


def test_run_style_setter_accepts_plain_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    run = _make_run(mock_session)
    run.style = "Emphasis"
    assert _captured_inline_rstyle(fake_sd_methods) == ["Emphasis"]


def test_run_style_setter_none_ships_null_clear(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``run.style = None`` ships ``rStyle: null`` on the wire — was a
    silent no-op in the prior implementation, but python-docx 1.x
    clears the ``<w:rStyle>`` OOXML element when passed None. Fixed
    to match upstream + the ``Run.bold = None`` pattern. See also
    ``test_silent_stub_run_style.py`` for the canonical pin."""
    run = _make_run(mock_session)
    run.style = None
    inline_calls = _captured_inline_rstyle(fake_sd_methods)
    # Was: 0 calls (silent no-op). Now: 1 call with rStyle=None.
    assert inline_calls == [None]


# ---------------------------------------------------------------------
# Styles.__contains__ — should match name OR style_id, like __getitem__
# ---------------------------------------------------------------------


def test_styles_contains_matches_by_style_id(mock_session: Any) -> None:
    """``styles.__contains__`` previously only matched by name, so
    ``"Heading1" in styles`` was False while ``styles["Heading1"]``
    succeeded. The new behavior matches either name OR style_id, so
    membership and indexing agree."""
    from docx.styles.styles import Styles

    styles = Styles(session=mock_session)
    # Every built-in paragraph style is keyed by name in the builtin
    # list. Since BaseStyle.style_id defaults to the name, both checks
    # should succeed today. The contract being pinned is that
    # __contains__ MUST also accept style_id once the two diverge.
    # We construct a custom added style with diverging name/style_id
    # to exercise the lookup-by-id path.
    import warnings

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        style = styles.add_style(
            "Custom Display", __import__("docx.enum.style", fromlist=["WD_STYLE_TYPE"]).WD_STYLE_TYPE.PARAGRAPH,
        )
        style._overrides["style_id"] = "CustomDisplay"

    assert "Custom Display" in styles  # by name
    assert "CustomDisplay" in styles  # by style_id (the new check)
    assert "NonExistent" not in styles


def test_styles_contains_rejects_non_string(mock_session: Any) -> None:
    from docx.styles.styles import Styles

    styles = Styles(session=mock_session)
    assert (42 in styles) is False
    assert (None in styles) is False
