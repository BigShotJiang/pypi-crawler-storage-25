"""Tests pinning Settings behavior.

These verify that ``Settings.odd_and_even_pages_header_footer`` now
persists through the wire (SuperDoc 1.8.1 added
``DocSectionsSetOddEvenHeadersFooters``; previously it warned + stashed
in-process only) and that ``Settings.element`` still raises
``AttributeError`` instead of silently returning ``None`` — callers
should fail loudly rather than crash on ``NoneType.append`` further
downstream.

See ``python-sdk/CLAUDE.md`` § 'Intentionally omitted' and
``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 8 (resolved).
"""

from __future__ import annotations

from typing import Any

import pytest

from docx.settings import PendingSettingsMutationWarning, Settings


def test_odd_and_even_pages_header_footer_setter_calls_wire_op(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """Setting the flag emits ``sections.set_odd_even_headers_footers``
    on the wire (SuperDoc 1.8.1's ``DocSectionsSetOddEvenHeadersFooters``)
    and stores the value in-process so reads round-trip in the same session.
    """
    s = Settings(session=mock_session)
    s.odd_and_even_pages_header_footer = True

    matching = [
        (op, params)
        for op, params in fake_sd_methods.calls
        if op == "sections.set_odd_even_headers_footers"
    ]
    assert matching == [("sections.set_odd_even_headers_footers", {"enabled": True})]
    assert s.odd_and_even_pages_header_footer is True


def test_odd_and_even_pages_header_footer_round_trips_false(
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """Toggling the flag off issues a second wire call with ``enabled=False``."""
    s = Settings(session=mock_session)
    s.odd_and_even_pages_header_footer = True
    s.odd_and_even_pages_header_footer = False
    assert s.odd_and_even_pages_header_footer is False
    toggles = [
        params for op, params in fake_sd_methods.calls
        if op == "sections.set_odd_even_headers_footers"
    ]
    assert toggles == [{"enabled": True}, {"enabled": False}]


def test_pending_settings_mutation_warning_still_importable() -> None:
    """The warning class stays exported for backwards compat with
    callers that registered handlers via ``warnings.simplefilter``.
    Nothing in the SDK raises it as of 0.6.3+.
    """
    assert issubclass(PendingSettingsMutationWarning, UserWarning)


def test_settings_element_raises_attribute_error(mock_session: Any) -> None:
    """``Settings.element`` raises ``AttributeError`` rather than
    silently returning ``None``. python-docx upstream returns the
    underlying lxml element; we don't expose lxml so callers must fail
    loudly."""
    s = Settings(session=mock_session)
    with pytest.raises(AttributeError, match="Settings.element"):
        _ = s.element
