"""Integration tests for the cell-inner format-op → ``PostExportOps``
stash path.

Verifies that:
- Setting ``alignment`` / ``style`` / ``paragraph_format.*`` on a
  cell-inner paragraph emits the warning AND records the OOXML-shaped
  format props on ``session._post_export_ops``.
- The recorded op carries the cell's OOXML positional address
  ``(table_doc_index, row, col, paragraph_index)``.
- The wire call is still short-circuited (cascade-failure prevention).
- When the parent table has no ``_doc_index`` (template-seeded read),
  the warning fires but no op is recorded (live-session unchanged).
"""
from __future__ import annotations

import warnings
from typing import Any


from docx._postproc import CellAddress, PostExportOps


def _attach_real_post_export_ops(mock_session: Any) -> PostExportOps:
    """Replace the MagicMock-typed ``_post_export_ops`` on a fixture
    session with a real :class:`PostExportOps` so the stash path
    actually records ops."""
    ops = PostExportOps()
    mock_session._post_export_ops = ops
    return ops


def _make_cell_in_table_with_doc_index(
    mock_session: Any, *, doc_index: int, row: int, col: int
) -> Any:
    from docx.table import Table, _Cell

    table = Table(
        session=mock_session,
        node_id="tbl-1",
        doc_index=doc_index,
    )
    return _Cell(table=table, row=row, col=col)


# ---- alignment ------------------------------------------------------


def test_alignment_right_stashes_ooxml_op(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.text.paragraph import CellInnerFormatNotSupportedWarning

    ops = _attach_real_post_export_ops(mock_session)
    cell = _make_cell_in_table_with_doc_index(
        mock_session, doc_index=2, row=0, col=1,
    )
    # ``cell.paragraphs`` triggers ``_inner_paragraph_ids`` (HTTP query
    # via the fake). Stub it to return one id so the OOXML address is
    # stable.
    cell._inner_paragraph_ids = lambda: ["para-1"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    paragraphs = cell.paragraphs
    assert len(paragraphs) == 1
    p = paragraphs[0]
    assert p._in_cell is True
    assert p._cell_ooxml_address == (2, 0, 1, 0)

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        warned = [
            x
            for x in w
            if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    assert len(warned) == 1
    # Op recorded with OOXML-shaped alignment value.
    assert ops.has_pending()
    expected_addr = CellAddress(
        table_doc_index=2, row=0, col=1, paragraph_index=0,
    )
    assert ops._cell_format_ops[expected_addr] == {"alignment": "right"}


def test_alignment_string_left_stashes_op(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.paragraph import CellInnerFormatNotSupportedWarning

    ops = _attach_real_post_export_ops(mock_session)
    cell = _make_cell_in_table_with_doc_index(
        mock_session, doc_index=0, row=3, col=2,
    )
    cell._inner_paragraph_ids = lambda: ["para-x"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-x"  # type: ignore[method-assign]
    p = cell.paragraphs[0]

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p.alignment = "center"

    addr = CellAddress(table_doc_index=0, row=3, col=2, paragraph_index=0)
    assert ops._cell_format_ops[addr] == {"alignment": "center"}


def test_alignment_none_does_not_stash_op(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``alignment = None`` is a *clear*. There's no OOXML attribute
    that represents "remove alignment" (Word inherits from style by
    default), so the op is informational only — we still emit the
    warning but don't stash."""
    from docx.text.paragraph import CellInnerFormatNotSupportedWarning

    ops = _attach_real_post_export_ops(mock_session)
    cell = _make_cell_in_table_with_doc_index(
        mock_session, doc_index=0, row=0, col=0,
    )
    cell._inner_paragraph_ids = lambda: ["para-1"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    p = cell.paragraphs[0]

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p.alignment = None

    # No usable OOXML rewrite for clear ⇒ no stashed op.
    assert not ops.has_pending()


# ---- style ----------------------------------------------------------


def test_style_stashes_op_with_style_id(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.paragraph import CellInnerFormatNotSupportedWarning

    ops = _attach_real_post_export_ops(mock_session)
    cell = _make_cell_in_table_with_doc_index(
        mock_session, doc_index=5, row=2, col=1,
    )
    cell._inner_paragraph_ids = lambda: ["para-1"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    p = cell.paragraphs[0]

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p.style = "Heading2"

    addr = CellAddress(table_doc_index=5, row=2, col=1, paragraph_index=0)
    assert ops._cell_format_ops[addr] == {"style": "Heading2"}


# ---- paragraph_format setters --------------------------------------


def test_left_indent_stashes_left_twips(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.shared import Pt
    from docx.text.paragraph import CellInnerFormatNotSupportedWarning

    ops = _attach_real_post_export_ops(mock_session)
    cell = _make_cell_in_table_with_doc_index(
        mock_session, doc_index=1, row=0, col=0,
    )
    cell._inner_paragraph_ids = lambda: ["para-1"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    p = cell.paragraphs[0]

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p.paragraph_format.left_indent = Pt(36)  # 36 pt = 720 twips

    addr = CellAddress(table_doc_index=1, row=0, col=0, paragraph_index=0)
    assert ops._cell_format_ops[addr] == {"left_twips": 720}


def test_space_before_after_merge_into_single_entry(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.shared import Pt
    from docx.text.paragraph import CellInnerFormatNotSupportedWarning

    ops = _attach_real_post_export_ops(mock_session)
    cell = _make_cell_in_table_with_doc_index(
        mock_session, doc_index=0, row=0, col=0,
    )
    cell._inner_paragraph_ids = lambda: ["para-1"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    p = cell.paragraphs[0]

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(12)

    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    assert ops._cell_format_ops[addr] == {
        "before_twips": 120,
        "after_twips": 240,
    }


def test_keep_with_next_stashes_keep_next_true(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.paragraph import CellInnerFormatNotSupportedWarning

    ops = _attach_real_post_export_ops(mock_session)
    cell = _make_cell_in_table_with_doc_index(
        mock_session, doc_index=0, row=0, col=0,
    )
    cell._inner_paragraph_ids = lambda: ["para-1"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    p = cell.paragraphs[0]

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p.paragraph_format.keep_with_next = True

    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    assert ops._cell_format_ops[addr] == {"keep_next": True}


def test_page_break_before_stashes(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.text.paragraph import CellInnerFormatNotSupportedWarning

    ops = _attach_real_post_export_ops(mock_session)
    cell = _make_cell_in_table_with_doc_index(
        mock_session, doc_index=0, row=0, col=0,
    )
    cell._inner_paragraph_ids = lambda: ["para-1"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    p = cell.paragraphs[0]

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        p.paragraph_format.page_break_before = True

    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    assert ops._cell_format_ops[addr] == {"page_break_before": True}


# ---- template-seeded table (no _doc_index) ------------------------


def test_template_seeded_table_emits_warning_but_no_stash(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """When the parent Table has no ``_doc_index`` (e.g. read from a
    template-seeded asset), we can't form a stable OOXML address. The
    warning still fires but the stash is skipped."""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.table import Table, _Cell
    from docx.text.paragraph import CellInnerFormatNotSupportedWarning

    ops = _attach_real_post_export_ops(mock_session)
    table = Table(session=mock_session, node_id="tbl-template")
    # No doc_index supplied — emulates a template-seeded table read.
    assert table._doc_index is None
    cell = _Cell(table=table, row=0, col=0)
    cell._inner_paragraph_ids = lambda: ["para-x"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-x"  # type: ignore[method-assign]
    p = cell.paragraphs[0]
    assert p._in_cell is True
    assert p._cell_ooxml_address is None

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        warned = [
            x
            for x in w
            if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    assert len(warned) == 1
    # No stash — same as pre-0.11.5 behavior for template tables.
    assert not ops.has_pending()


# ---- multiple paragraphs in same cell -------------------------------


def test_paragraph_index_increments_within_cell(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    _attach_real_post_export_ops(mock_session)
    cell = _make_cell_in_table_with_doc_index(
        mock_session, doc_index=0, row=0, col=0,
    )
    cell._inner_paragraph_ids = lambda: ["p-0", "p-1", "p-2"]  # type: ignore[method-assign]
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    paragraphs = cell.paragraphs
    assert paragraphs[0]._cell_ooxml_address == (0, 0, 0, 0)
    assert paragraphs[1]._cell_ooxml_address == (0, 0, 0, 1)
    assert paragraphs[2]._cell_ooxml_address == (0, 0, 0, 2)


# ---- _count_non_empty_runs helper -----------------------------------


def test_count_non_empty_runs_skips_empty_text() -> None:
    """``_count_non_empty_runs`` MUST skip ``{kind: run, run: {text: ""}}``
    entries — SuperDoc emits an empty leading inline run on cell-text
    writes and the exporter does NOT promote it to a non-empty
    ``<w:p>`` (it lands as the leading self-closing ``<w:p/>``)."""
    from docx.table import _count_non_empty_runs

    info = {
        "node": {
            "kind": "paragraph",
            "id": "8579e48c-5295-47b4-bdf6-04df07cc84c1",
            "paragraph": {
                "inlines": [
                    {"kind": "run", "run": {"text": ""}},
                    {"kind": "run", "run": {"text": "Direct API"}},
                    {"kind": "run", "run": {"text": "body"}},
                    {"kind": "run", "run": {"text": "bullet1"}},
                ],
            },
        },
    }
    assert _count_non_empty_runs(info) == 3


def test_count_non_empty_runs_handles_whitespace_only() -> None:
    """A run with only whitespace text is treated as empty — the
    exporter doesn't promote whitespace-only runs to ``<w:p>``."""
    from docx.table import _count_non_empty_runs

    info = {
        "inlines": [
            {"kind": "run", "run": {"text": "   "}},
            {"kind": "run", "run": {"text": "real content"}},
            {"kind": "run", "run": {"text": "\t\n  "}},
        ],
    }
    assert _count_non_empty_runs(info) == 1


# ---- sequential add_paragraph paragraph_index regression ------------


def test_sequential_add_paragraph_with_style_stashes_distinct_indices(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """The PR #20805 follow-up bug: pre-fix every cell-inner
    ``cell.add_paragraph(text, style="...")`` stashed
    ``CellAddress(..., paragraph_index=0)`` because
    ``_inner_paragraph_ids()`` always reports a single SuperDoc
    cell-inner paragraph (SuperDoc 1.8.1 collapses every
    ``placement: insideEnd`` insert into an inline run on that one
    paragraph). The last write won, so:

    * three ``add_paragraph(bullet, style="List Bullet")`` calls
      after a ``Heading4`` stash overwrote Heading4 with
      "List Bullet" at index 0 and never tagged the bullets;
    * "Direct API" / "Cloud Marketplace" headers in the
      ``recreate_openai_pdf`` test ended up rendered as plain text
      with no style instead of the intended Heading4.

    The fix routes through ``_count_exported_paragraphs`` which
    matches the post-export ``<w:p>`` count (``non_empty_runs + 1``)
    so each sequential add gets a unique index that aligns with the
    exported paragraph's position.
    """
    from docx.table import Table, _Cell

    ops = _attach_real_post_export_ops(mock_session)
    table = Table(session=mock_session, node_id="tbl-1", doc_index=5)
    cell = _Cell(table=table, row=0, col=0)
    cell._cell_id = lambda: "cell-comparison"  # type: ignore[method-assign]
    cell._inner_paragraph_ids = lambda: ["p-direct-api"]  # type: ignore[method-assign]

    # Simulate the cell.text + 3 add_paragraph(style=...) sequence by
    # walking _count_exported_paragraphs through the empirically-
    # observed values (cell.text="X" exports 2 <w:p>; each subsequent
    # add adds 1).
    counts = iter([3, 4, 5])  # post-insert counts for the 3 adds
    cell._count_exported_paragraphs = lambda: next(counts)  # type: ignore[method-assign]

    p1 = cell.add_paragraph("Native access", style="List Bullet")
    p2 = cell.add_paragraph("Direct support", style="List Bullet")
    p3 = cell.add_paragraph("Fastest access", style="List Bullet")

    # Each Paragraph proxy was constructed with a DISTINCT
    # paragraph_index; pre-fix all three got 0.
    assert p1._cell_ooxml_address == (5, 0, 0, 2)
    assert p2._cell_ooxml_address == (5, 0, 0, 3)
    assert p3._cell_ooxml_address == (5, 0, 0, 4)

    # Three stash entries, one per paragraph (pre-fix this was 1 entry).
    stash_keys = sorted(
        addr.paragraph_index for addr in ops._cell_format_ops
    )
    assert stash_keys == [2, 3, 4]
    for addr, props in ops._cell_format_ops.items():
        assert props == {"style": "List Bullet"}, (
            f"{addr}: expected List Bullet, got {props}"
        )


def test_add_paragraph_paragraph_index_uses_exported_count_minus_1(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``_Cell.add_paragraph`` MUST compute the new paragraph's
    ``_cell_ooxml_address`` from ``_count_exported_paragraphs() - 1``,
    NOT from ``len(_inner_paragraph_ids()) - 1``. The latter is
    always 0 for cell-inner inserts (SuperDoc collapses them) and
    causes the bug pinned by
    ``test_sequential_add_paragraph_with_style_stashes_distinct_indices``.
    """
    from docx.table import Table, _Cell

    _attach_real_post_export_ops(mock_session)
    table = Table(session=mock_session, node_id="tbl-1", doc_index=0)
    cell = _Cell(table=table, row=0, col=0)
    cell._cell_id = lambda: "cell-1"  # type: ignore[method-assign]
    cell._inner_paragraph_ids = lambda: ["p-original"]  # type: ignore[method-assign]
    # Stub the exported-paragraph counter to a known value so we can
    # assert what the new Paragraph proxy is anchored at.
    cell._count_exported_paragraphs = lambda: 4  # type: ignore[method-assign]

    p = cell.add_paragraph("new content")
    # paragraph_index = exported_count - 1 = 3
    assert p._cell_ooxml_address == (0, 0, 0, 3), p._cell_ooxml_address
