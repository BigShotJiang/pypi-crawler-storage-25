"""Lock-in tests for the silent-stub warnings on ``BaseStyle.delete``
and ``ParagraphStyle.paragraph_format``.

Two operations used to be silent no-ops:

1. ``BaseStyle.delete()`` returned ``None`` and did nothing. Upstream
   actually removes the style definition.
2. ``ParagraphStyle.paragraph_format`` returned ``None``. Upstream
   returns a ``ParagraphFormat`` object so e.g.
   ``style.paragraph_format.left_indent = Inches(0.5)`` works.

These are now warn-and-no-op (delete) / warn-on-mutation
(paragraph_format proxy). When SuperDoc lands per-style metadata /
paragraph-format mutation ops, these tests should flip to assert real
wire-bus calls.
"""

from __future__ import annotations

import warnings

import pytest

from docx.enum.style import WD_STYLE_TYPE
from docx.styles.style import (
    BaseStyle,
    CharacterStyle,
    ParagraphStyle,
    PendingParagraphFormatStyleMutationWarning,
    PendingStyleDeleteWarning,
    _StyleParagraphFormat,
    _StyleTabStops,
)


def _make_paragraph_style(name: str = "Heading 1") -> ParagraphStyle:
    return ParagraphStyle(
        name=name, style_type=WD_STYLE_TYPE.PARAGRAPH, session=None,  # type: ignore[arg-type]
    )


# ---------------------------------------------------------------------
# BaseStyle.delete()
# ---------------------------------------------------------------------


def test_base_style_delete_warns_once_and_marks_deleted() -> None:
    s = BaseStyle(
        name="Foo", style_type=WD_STYLE_TYPE.PARAGRAPH, session=None,  # type: ignore[arg-type]
    )
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        s.delete()

    pending = [w for w in captured if issubclass(w.category, PendingStyleDeleteWarning)]
    assert len(pending) == 1, f"expected exactly one warning, got {len(pending)}"
    msg = str(pending[0].message)
    assert "delete" in msg
    assert "SuperDoc" in msg
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in msg
    # The in-process flag is set so callers can introspect.
    assert s._overrides.get("_deleted") is True


def test_character_style_delete_warns_and_uses_subclass_name_in_message() -> None:
    s = CharacterStyle(
        name="Strong", style_type=WD_STYLE_TYPE.CHARACTER, session=None,  # type: ignore[arg-type]
    )
    with pytest.warns(PendingStyleDeleteWarning) as captured:
        s.delete()
    assert "CharacterStyle.delete" in str(captured[0].message)


# ---------------------------------------------------------------------
# ParagraphStyle.paragraph_format
# ---------------------------------------------------------------------


def test_paragraph_format_returns_proxy_not_none() -> None:
    """python-docx contract: ``style.paragraph_format`` returns a
    ``ParagraphFormat``-shaped object so ``.left_indent`` etc. work."""
    pf = _make_paragraph_style().paragraph_format
    assert pf is not None
    assert isinstance(pf, _StyleParagraphFormat)


def test_paragraph_format_setter_warns_and_round_trips() -> None:
    style = _make_paragraph_style()
    pf = style.paragraph_format

    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        pf.left_indent = 720
        pf.alignment = "center"
        pf.space_before = 100

    pending = [
        w
        for w in captured
        if issubclass(w.category, PendingParagraphFormatStyleMutationWarning)
    ]
    assert len(pending) == 3
    # Reads return the stashed value (single-process parity).
    assert pf.left_indent == 720
    assert pf.alignment == "center"
    assert pf.space_before == 100


def test_paragraph_format_unset_property_reads_none() -> None:
    pf = _make_paragraph_style().paragraph_format
    # Never assigned → reads None, mirroring python-docx for an
    # un-customized style.
    assert pf.right_indent is None
    assert pf.line_spacing is None
    assert pf.keep_together is None


def test_paragraph_format_proxy_is_cached_per_style() -> None:
    """Repeated access returns the same backing object so callers can
    chain writes: ``style.paragraph_format.left_indent = ...`` followed
    by ``style.paragraph_format.left_indent`` reads back the same value
    without surprises."""
    style = _make_paragraph_style()
    pf1 = style.paragraph_format
    pf2 = style.paragraph_format
    assert pf1 is pf2


def test_paragraph_format_tab_stops_is_empty_proxy() -> None:
    pf = _make_paragraph_style().paragraph_format
    ts = pf.tab_stops
    assert isinstance(ts, _StyleTabStops)
    assert list(ts) == []
    assert len(ts) == 0


def test_paragraph_format_tab_stops_add_warns() -> None:
    pf = _make_paragraph_style().paragraph_format
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        pf.tab_stops.add_tab_stop(720)

    pending = [
        w
        for w in captured
        if issubclass(w.category, PendingParagraphFormatStyleMutationWarning)
    ]
    assert len(pending) == 1


def test_paragraph_format_warning_message_points_to_superdoc_constraint() -> None:
    pf = _make_paragraph_style().paragraph_format
    with pytest.warns(PendingParagraphFormatStyleMutationWarning) as captured:
        pf.left_indent = 100
    msg = str(captured[0].message)
    assert "SuperDoc" in msg
    assert "SUPERDOC_UPSTREAM_REQUESTS.md" in msg
