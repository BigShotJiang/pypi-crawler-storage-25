"""Unit tests for the ``Paragraph._p`` / ``Run._r`` / ``Document.element``
``__getattr__`` guard added in 0.11.6.

Pre-fix: ``paragraph._p`` returned a bare ``AttributeError: 'Paragraph'
object has no attribute '_p'`` with no pointer at the high-level API.
Post-fix: the same call raises ``AttributeError`` with an actionable
message that names the symbol, explains why athena-python-docx omits
the lxml-element surface, and points at the high-level alternatives.

The error type stays ``AttributeError`` (not the typed
``OxmlNotAvailableError``) because CPython rejects multi-inheritance
from both ImportError and AttributeError at class-creation time
(instance layout conflict). The message carries the typed-error
framing so the actionable content is preserved.
"""
from __future__ import annotations

from typing import Any

import pytest


# ---- Paragraph._p / _r / _element / part ----


def _make_paragraph(mock_session: Any, fake_sd_methods: Any) -> Any:
    from docx.text.paragraph import Paragraph

    return Paragraph(session=mock_session, node_id="p-test")


@pytest.mark.parametrize("attr", ["_p", "_element", "element"])
def test_paragraph_xml_element_attrs_raise_actionable_error(
    mock_session: Any, fake_sd_methods: Any, attr: str,
) -> None:
    p = _make_paragraph(mock_session, fake_sd_methods)
    with pytest.raises(AttributeError) as excinfo:
        getattr(p, attr)
    msg = str(excinfo.value)
    assert "athena-python-docx" in msg
    assert "HTTP-only" in msg
    assert ".text" in msg or ".add_run" in msg or ".paragraph_format" in msg


def test_paragraph_part_raises_actionable_error(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    p = _make_paragraph(mock_session, fake_sd_methods)
    with pytest.raises(AttributeError) as excinfo:
        p.part
    msg = str(excinfo.value)
    assert "no local package parts" in msg
    assert "core_properties" in msg


def test_paragraph_unknown_attribute_still_normal_attribute_error(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    """The guard only fires for the known XML/part attribute names —
    everything else still gets the default ``AttributeError`` shape."""
    p = _make_paragraph(mock_session, fake_sd_methods)
    with pytest.raises(AttributeError) as excinfo:
        p.some_random_attr_that_does_not_exist
    # Default-shape message; no high-level-API pointer.
    msg = str(excinfo.value)
    assert "Paragraph" in msg
    assert "athena-python-docx" not in msg


def test_paragraph_hasattr_xml_element_is_false(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    """``hasattr`` probes via AttributeError, so it must return False
    for ``_p`` (which would otherwise look like a missing attribute)."""
    p = _make_paragraph(mock_session, fake_sd_methods)
    assert hasattr(p, "_p") is False
    assert hasattr(p, "element") is False
    assert hasattr(p, "part") is False


# ---- Run._r / _element / part ----


def _make_run(mock_session: Any, fake_sd_methods: Any) -> Any:
    from docx.text.run import Run

    return Run(
        session=mock_session, block_id="block-test", range_=(0, 5),
    )


@pytest.mark.parametrize("attr", ["_r", "_element", "element"])
def test_run_xml_element_attrs_raise_actionable_error(
    mock_session: Any, fake_sd_methods: Any, attr: str,
) -> None:
    r = _make_run(mock_session, fake_sd_methods)
    with pytest.raises(AttributeError) as excinfo:
        getattr(r, attr)
    msg = str(excinfo.value)
    assert "athena-python-docx" in msg
    assert "HTTP-only" in msg


def test_run_part_raises_actionable_error(
    mock_session: Any, fake_sd_methods: Any,
) -> None:
    r = _make_run(mock_session, fake_sd_methods)
    with pytest.raises(AttributeError) as excinfo:
        r.part
    assert "no local package parts" in str(excinfo.value)


# ---- Document.element / .part (existing behavior, message refinement) ----


def test_document_element_raises_actionable_error() -> None:
    from docx.document import Document

    doc = object.__new__(Document)
    with pytest.raises(AttributeError) as excinfo:
        doc.element
    msg = str(excinfo.value)
    assert "athena-python-docx" in msg
    assert "Document.add_paragraph" in msg


def test_document_part_raises_actionable_error() -> None:
    from docx.document import Document

    doc = object.__new__(Document)
    with pytest.raises(AttributeError) as excinfo:
        doc.part
    msg = str(excinfo.value)
    assert "core_properties" in msg
    assert "asset_id" in msg


# ---- guard_xml_attr unit-level ----


@pytest.mark.parametrize(
    "name", ["_p", "_r", "_tc", "_tbl", "_tr", "element", "_element"],
)
def test_guard_xml_attr_raises_for_known_xml_attrs(name: str) -> None:
    from docx.oxml import guard_xml_attr

    with pytest.raises(AttributeError) as excinfo:
        guard_xml_attr("Paragraph", name)
    assert "athena-python-docx" in str(excinfo.value)


def test_guard_xml_attr_raises_for_part_attr() -> None:
    from docx.oxml import guard_xml_attr

    with pytest.raises(AttributeError) as excinfo:
        guard_xml_attr("Document", "part")
    assert "no local package parts" in str(excinfo.value)


def test_guard_xml_attr_silent_for_unknown_names() -> None:
    """The guard only fires for the known XML/part attribute names —
    everything else returns silently (caller continues with default
    AttributeError)."""
    from docx.oxml import guard_xml_attr

    # Should NOT raise
    guard_xml_attr("Paragraph", "some_other_method")
    guard_xml_attr("Run", "text")
    guard_xml_attr("Document", "asset_id")


def test_oxml_not_available_error_is_importerror() -> None:
    """OxmlNotAvailableError remains an ImportError subclass so
    ``from docx.oxml import X; except ImportError`` patterns still
    catch it."""
    from docx.oxml import OxmlNotAvailableError

    assert issubclass(OxmlNotAvailableError, ImportError)
