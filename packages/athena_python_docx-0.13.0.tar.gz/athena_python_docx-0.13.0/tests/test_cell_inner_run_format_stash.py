"""Integration tests for the cell-inner ``Run`` format-op stash path
(``run.bold = True`` / ``run.font.size = Pt(11)`` / etc. on a cell-
inner Run records ops on ``session._post_export_ops`` for the
post-export OOXML rewrite).

Verifies that:
- Setting ``run.bold`` / ``italic`` / ``strike`` / ``underline`` /
  ``font.size`` / ``font.color.rgb`` / ``font.name`` /
  ``font.highlight_color`` / ``style`` on a cell-inner Run emits the
  warning AND records ops on ``session._post_export_ops._cell_run_format_ops``.
- The recorded op carries the parent paragraph's OOXML positional
  address ``(table_doc_index, row, col, paragraph_index)``.
- The keys match the post-export rewrite schema (``bold``,
  ``font_size_pt``, ``font_color_hex``, etc.).
- The wire call is still short-circuited (cascade-failure prevention).
- Runs constructed without a ``cell_ooxml_address`` (template-seeded
  reads where ``Table._doc_index`` is None) warn but don't stash.

End-to-end pairing with ``test_postproc_cell_run_format_rewrite.py``:
this file verifies the SDK-side stash; that one verifies the
post-export OOXML rewrite reads the stash and produces the expected
``<w:rPr>``.
"""
from __future__ import annotations

import warnings
from typing import Any

from docx._postproc import CellAddress, PostExportOps
from docx.text.paragraph import CellInnerFormatNotSupportedWarning


def _attach_real_post_export_ops(mock_session: Any) -> PostExportOps:
    ops = PostExportOps()
    mock_session._post_export_ops = ops
    return ops


def _make_cell_inner_run(
    mock_session: Any,
    *,
    cell_ooxml_address: tuple[int, int, int, int] | None,
) -> Any:
    from docx.text.run import Run

    return Run(
        session=mock_session,
        block_id="p-cell-inner",
        range_=(0, 5),  # non-collapsed so we hit the in_cell branch first
        in_cell=True,
        cell_ooxml_address=cell_ooxml_address,
    )


# ---- bold / italic / strike / underline -----------------------------


def test_run_bold_stashes_and_short_circuits(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    ops = _attach_real_post_export_ops(mock_session)
    r = _make_cell_inner_run(mock_session, cell_ooxml_address=(0, 1, 2, 0))
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        r.bold = True
        warned = [
            x
            for x in w
            if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    assert len(warned) == 1
    # Op recorded.
    addr = CellAddress(table_doc_index=0, row=1, col=2, paragraph_index=0)
    assert ops._cell_run_format_ops[addr] == {"bold": True}
    # No wire call.
    format_apply_ops = [c for c in fake_sd_methods.calls if c[0] == "format.apply"]
    assert format_apply_ops == []


def test_run_italic_strike_underline_each_stash_distinct_keys(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    ops = _attach_real_post_export_ops(mock_session)
    r = _make_cell_inner_run(mock_session, cell_ooxml_address=(0, 0, 0, 0))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r.italic = True
        # strike-through is on the Font proxy, not directly on Run
        # (matches python-docx 1.x — ``run.font.strike``).
        r.font.strike = True
        # underline uses WD_UNDERLINE enum or bool; True is stored
        # verbatim on the stash and normalized to "single" by the
        # post-export rewriter (verified in
        # test_postproc_cell_run_format_rewrite.py).
        r.underline = True
    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    props = ops._cell_run_format_ops[addr]
    assert props["italic"] is True
    assert props["strike"] is True
    assert props["underline"] is True


# ---- font.size / font.color / font.name / highlight ----------------


def test_run_font_size_stashes_font_size_pt(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.shared import Pt

    ops = _attach_real_post_export_ops(mock_session)
    r = _make_cell_inner_run(mock_session, cell_ooxml_address=(0, 0, 0, 0))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r.font.size = Pt(11)
    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    assert ops._cell_run_format_ops[addr]["font_size_pt"] == 11.0


def test_run_font_color_rgb_stashes_font_color_hex(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.shared import RGBColor

    ops = _attach_real_post_export_ops(mock_session)
    r = _make_cell_inner_run(mock_session, cell_ooxml_address=(0, 0, 0, 0))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r.font.color.rgb = RGBColor(0x0A, 0x1F, 0x44)
    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    # RGBColor.__str__ returns 6-digit hex without leading '#'.
    assert ops._cell_run_format_ops[addr]["font_color_hex"] == "0A1F44"


def test_run_font_name_stashes_font_name(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    ops = _attach_real_post_export_ops(mock_session)
    r = _make_cell_inner_run(mock_session, cell_ooxml_address=(0, 0, 0, 0))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r.font.name = "Calibri"
    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    assert ops._cell_run_format_ops[addr]["font_name"] == "Calibri"


def test_run_font_highlight_color_stashes_font_highlight(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    from docx.enum.text import WD_COLOR_INDEX

    ops = _attach_real_post_export_ops(mock_session)
    r = _make_cell_inner_run(mock_session, cell_ooxml_address=(0, 0, 0, 0))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r.font.highlight_color = WD_COLOR_INDEX.YELLOW
    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    assert ops._cell_run_format_ops[addr]["font_highlight"] == "yellow"


# ---- style ----------------------------------------------------------


def test_run_style_stashes_r_style(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    ops = _attach_real_post_export_ops(mock_session)
    r = _make_cell_inner_run(mock_session, cell_ooxml_address=(0, 0, 0, 0))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r.style = "Emphasis"
    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    assert ops._cell_run_format_ops[addr]["r_style"] == "Emphasis"


# ---- merging --------------------------------------------------------


def test_multiple_format_setters_merge_into_one_op(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``r.bold = True; r.font.size = Pt(11); r.font.color.rgb = …;
    r.font.name = 'Calibri'`` — the agent's typical IB-table pattern —
    should result in ONE recorded op carrying all four props."""
    from docx.shared import Pt, RGBColor

    ops = _attach_real_post_export_ops(mock_session)
    r = _make_cell_inner_run(mock_session, cell_ooxml_address=(0, 0, 0, 0))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r.bold = True
        r.font.size = Pt(11)
        r.font.color.rgb = RGBColor(0x1F, 0x4E, 0x9C)
        r.font.name = "Calibri"
    addr = CellAddress(table_doc_index=0, row=0, col=0, paragraph_index=0)
    props = ops._cell_run_format_ops[addr]
    assert props["bold"] is True
    assert props["font_size_pt"] == 11.0
    assert props["font_color_hex"] == "1F4E9C"
    assert props["font_name"] == "Calibri"


# ---- no-address fallback -------------------------------------------


def test_run_without_cell_ooxml_address_warns_but_does_not_stash(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Cell-inner runs whose parent paragraph has no stable OOXML
    address (typically template-seeded cells where Table._doc_index
    is None) still warn-and-skip but don't record any post-export
    op. Otherwise the rewrite would target the wrong cell."""
    ops = _attach_real_post_export_ops(mock_session)
    r = _make_cell_inner_run(mock_session, cell_ooxml_address=None)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", CellInnerFormatNotSupportedWarning)
        r.bold = True
        warned = [
            x
            for x in w
            if issubclass(x.category, CellInnerFormatNotSupportedWarning)
        ]
    assert len(warned) == 1
    # No op recorded.
    assert ops._cell_run_format_ops == {}
    # No wire call either.
    format_apply_ops = [c for c in fake_sd_methods.calls if c[0] == "format.apply"]
    assert format_apply_ops == []


# ---- end-to-end: paragraph.runs propagates cell_ooxml_address ------


def test_paragraph_runs_propagates_cell_ooxml_address_to_runs(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``cell.paragraphs[0]`` carries ``_cell_ooxml_address``; the
    resulting Run proxies returned from ``.runs`` must inherit it so
    ``runs[0].bold = True`` can stash to the right cell address."""
    from docx.text.paragraph import Paragraph

    p = Paragraph(
        session=mock_session,
        node_id="p-cell-inner",
        in_cell=True,
        cell_ooxml_address=(3, 0, 0, 0),
    )
    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "paragraph": {
                "inlines": [
                    {"kind": "run", "run": {"text": "Hello"}},
                ],
            },
        },
    }
    runs = p.runs
    assert len(runs) == 1
    assert runs[0]._in_cell is True
    assert runs[0]._cell_ooxml_address == (3, 0, 0, 0)


def test_paragraph_add_run_returns_run_carrying_cell_ooxml_address(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """The stub ``Run`` returned from ``cell.add_paragraph("...").add_run
    (text)`` (the agent's ``fill_cell`` workaround pattern) must
    carry the cell address so subsequent ``run.bold = True`` setters
    stash to the right cell — even though the text itself never
    materializes at the wire layer."""
    from docx.text.paragraph import Paragraph

    p = Paragraph(
        session=mock_session,
        node_id="p-cell-inner",
        in_cell=True,
        cell_ooxml_address=(5, 2, 1, 0),
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", CellInnerFormatNotSupportedWarning)
        r = p.add_run("hello")
    assert r._in_cell is True
    assert r._cell_ooxml_address == (5, 2, 1, 0)
