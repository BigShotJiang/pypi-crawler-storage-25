"""Lock-in tests for ``Run.bold`` / ``Run.italic`` bool strictness.

The Font audit (iter 8) tightened ``_bool_set`` for the 18 bool
properties delegated through it (strike, all_caps, …). The two
"older" Run-level setters (``Run.bold``, ``Run.italic``) bypassed
that helper and still did ``bool(value)``, so truthy strings like
``"false"`` (truthy!) silently became ``True``. This iteration
mirrors the strict-bool contract on Run.bold/Run.italic so the
behavior is consistent across all bool font marks.

``Run.underline`` is intentionally NOT tightened here — upstream
accepts ``bool | WD_UNDERLINE | str`` for that property.
"""

from __future__ import annotations

from typing import Any

import pytest


def _make_run(mock_session: Any, *, block_id: str = "p-1"):
    from docx.text.run import Run

    return Run(session=mock_session, block_id=block_id, range_=(0, 5))


# ---------------------------------------------------------------------
# Run.bold
# ---------------------------------------------------------------------


def test_run_bold_accepts_true(mock_session: Any) -> None:
    run = _make_run(mock_session)
    run.bold = True


def test_run_bold_accepts_false(mock_session: Any) -> None:
    run = _make_run(mock_session)
    run.bold = False


def test_run_bold_accepts_none_for_clear(mock_session: Any) -> None:
    run = _make_run(mock_session)
    run.bold = None


def test_run_bold_accepts_int_1_and_0(mock_session: Any) -> None:
    """python-docx's ST_OnOff treats ``1 == True`` and ``0 == False``
    — match that for compat."""
    run = _make_run(mock_session)
    run.bold = 1  # type: ignore[assignment]
    run.bold = 0  # type: ignore[assignment]


def test_run_bold_rejects_string(mock_session: Any) -> None:
    """``run.bold = "false"`` is the canonical landmine: ``"false"``
    is TRUTHY in Python, so ``bool("false")`` is True, and the run
    used to silently become bold. Reject strings outright."""
    run = _make_run(mock_session)
    with pytest.raises(TypeError) as excinfo:
        run.bold = "false"  # type: ignore[assignment]
    assert "True, False, or None" in str(excinfo.value)


def test_run_bold_rejects_other_int(mock_session: Any) -> None:
    run = _make_run(mock_session)
    with pytest.raises(TypeError):
        run.bold = 42  # type: ignore[assignment]


def test_run_bold_rejects_float(mock_session: Any) -> None:
    run = _make_run(mock_session)
    with pytest.raises(TypeError):
        run.bold = 1.0  # type: ignore[assignment]


# ---------------------------------------------------------------------
# Run.italic — same contract
# ---------------------------------------------------------------------


def test_run_italic_accepts_true_false_none(mock_session: Any) -> None:
    run = _make_run(mock_session)
    run.italic = True
    run.italic = False
    run.italic = None


def test_run_italic_rejects_string(mock_session: Any) -> None:
    run = _make_run(mock_session)
    with pytest.raises(TypeError):
        run.italic = "true"  # type: ignore[assignment]


def test_run_italic_rejects_object(mock_session: Any) -> None:
    run = _make_run(mock_session)
    with pytest.raises(TypeError):
        run.italic = object()  # type: ignore[assignment]
