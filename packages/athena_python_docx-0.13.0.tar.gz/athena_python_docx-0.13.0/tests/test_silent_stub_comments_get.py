"""Lock-in tests for ``Comments.get`` exception narrowing.

Previously ``except Exception: return None`` swallowed *every* error
from the wire layer, so a 500-from-docx-studio looked identical to a
bare "no such comment" miss. The new behavior catches a typed
:class:`NotFoundError` (raised by ``_http_post_json`` after inspecting
the server's structured error payload). Bare :class:`DocxError`s
propagate so callers can distinguish transport failure from a
legitimate miss (matches python-docx 1.x semantics where ``None``
strictly means "comment not in the document").
"""

from __future__ import annotations

from typing import Any

import pytest


def test_comments_get_returns_none_for_not_found(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Wire layer raising :class:`NotFoundError` → ``get`` returns
    ``None`` (mirrors upstream)."""
    from docx.comments import Comments
    from docx.errors import NotFoundError

    def _raise_not_found(params: dict):
        raise NotFoundError(
            "comments.get: comment c-missing not found",
            payload={"status": 404},
        )

    # The fake SDK records calls via __call__; we monkey-patch the
    # specific path to raise on invocation.
    class _RaisingProxy:
        def __init__(self, fn):
            self._fn = fn

        async def __call__(self, params: dict | None = None):
            return self._fn(params or {})

    fake_sd_methods.scripted_returns["comments.get"] = None

    # Override the path-proxy chain for comments.get to raise.
    import functools

    original_getattr = type(fake_sd_methods).__getattr__

    @functools.wraps(original_getattr)
    def _patched(self, name):
        if name == "comments":
            class _CommentsProxy:
                def __getattr__(self_inner, op):
                    if op == "get":
                        return _RaisingProxy(_raise_not_found)
                    return original_getattr(self, "comments").__getattr__(op)
            return _CommentsProxy()
        return original_getattr(self, name)

    type(fake_sd_methods).__getattr__ = _patched
    try:
        comments = Comments(session=mock_session)
        result = comments.get("c-missing")
        assert result is None
    finally:
        type(fake_sd_methods).__getattr__ = original_getattr


def test_comments_get_propagates_transport_errors(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A non-"not found" DocxError must propagate so callers can
    distinguish transport / server failures from a legitimate miss."""
    from docx.comments import Comments
    from docx.errors import DocxError

    def _raise_500(params: dict):
        raise DocxError("HTTP 500: docx-studio returned a server error")

    class _RaisingProxy:
        def __init__(self, fn):
            self._fn = fn

        async def __call__(self, params: dict | None = None):
            return self._fn(params or {})

    original_getattr = type(fake_sd_methods).__getattr__

    def _patched(self, name):
        if name == "comments":
            class _CommentsProxy:
                def __getattr__(self_inner, op):
                    if op == "get":
                        return _RaisingProxy(_raise_500)
                    return original_getattr(self, "comments").__getattr__(op)
            return _CommentsProxy()
        return original_getattr(self, name)

    type(fake_sd_methods).__getattr__ = _patched
    try:
        comments = Comments(session=mock_session)
        with pytest.raises(DocxError) as excinfo:
            comments.get("c-anything")
        assert "500" in str(excinfo.value)
    finally:
        type(fake_sd_methods).__getattr__ = original_getattr


def test_comments_get_returns_none_for_empty_payload(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Empty dict response (no id, no commentId, no address) → None.

    Defensive — older SuperDoc versions sometimes returned ``{}`` for
    a missing comment instead of erroring. We treat that as "not found"
    rather than emitting a Comment with no id."""
    from docx.comments import Comments

    fake_sd_methods.scripted_returns["comments.get"] = {}
    comments = Comments(session=mock_session)
    assert comments.get("c-empty") is None


# ---------------------------------------------------------------------------
# Structured not-found classification (Greptile P2 — replaces substring match)
# ---------------------------------------------------------------------------


def test_looks_like_not_found_matches_typed_error_name() -> None:
    """Server reports a structured ``error.name == 'NotFoundError'``
    (or known synonyms) → classified as not-found regardless of the
    message phrasing."""
    from docx._http_doc import _looks_like_not_found

    assert _looks_like_not_found(
        {"error": {"name": "NotFoundError"}, "message": "Quasimodo"},
    )
    assert _looks_like_not_found(
        {"error": {"name": "EntityNotFoundError"}, "message": ""},
    )
    assert _looks_like_not_found({"error": "node_not_found"})
    assert _looks_like_not_found({"code": "comment-not-found"})


def test_looks_like_not_found_matches_404_status_code() -> None:
    """A typed 404 status field is classified as not-found."""
    from docx._http_doc import _looks_like_not_found

    assert _looks_like_not_found({"status": 404, "message": "irrelevant"})
    assert _looks_like_not_found({"statusCode": 404})


def test_looks_like_not_found_matches_broader_message_substrings() -> None:
    """Fallback path: matches phrasing variants the original 3-string
    heuristic missed (\"entity does not exist\", \"unknown id\", \"missing
    entity\"), so a backend rename of the error message doesn't silently
    re-route a miss into a transport error."""
    from docx._http_doc import _looks_like_not_found

    assert _looks_like_not_found({"message": "Entity does not exist"})
    assert _looks_like_not_found({"message": "Unknown id c-9"})
    assert _looks_like_not_found({"message": "Missing entity c-9"})
    assert _looks_like_not_found({"message": "no such comment"})
    assert _looks_like_not_found({"message": "HTTP 404"})


def test_looks_like_not_found_rejects_unrelated_errors() -> None:
    """Real transport / validation failures must NOT match — that was
    the whole point of replacing the substring heuristic."""
    from docx._http_doc import _looks_like_not_found

    assert not _looks_like_not_found({"message": "internal server error"})
    assert not _looks_like_not_found({"message": "validation failed"})
    assert not _looks_like_not_found({"error": "AuthenticationError"})
    assert not _looks_like_not_found({"status": 500})
    assert not _looks_like_not_found({})
