"""Lock-in tests for ``Document.add_paragraph`` /
``_HeaderFooter.add_paragraph`` style-argument validation.

Both factory methods previously accepted any value for the ``style``
parameter:

- ``Document.add_paragraph(text, style)``: code was
  ``style_str = style.style_id if isinstance(style, ParagraphStyle) else style``
  — anything non-ParagraphStyle was used as-is. ``style=42`` shipped
  ``42`` as the style id; ``style={"name": "x"}`` shipped the dict.
- ``_HeaderFooter.add_paragraph(text, style)``: same pattern but with
  an explicit ``str(style)`` coercion — ``style=42`` shipped ``"42"``;
  ``style=<some_object>`` shipped ``"<__main__.X object at 0x...>"``.

SuperDoc's permissive parser swallowed unknowns or rejected them
without a clear signal. python-docx 1.x raises ``TypeError`` at the
style-lookup layer.

Now both raise ``TypeError`` upfront when ``style`` is not
``str | ParagraphStyle | None``.
"""

from __future__ import annotations

from typing import Any

import pytest


# ---------------------------------------------------------------------
# Document.add_paragraph
# ---------------------------------------------------------------------


@pytest.mark.parametrize("value", [42, 1.5, [1, 2], {"a": "b"}, object()])
def test_document_add_paragraph_rejects_invalid_style_type(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    from docx.document import Document

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False

    with pytest.raises(TypeError, match="ParagraphStyle"):
        doc.add_paragraph("hello", style=value)


# ---------------------------------------------------------------------
# _HeaderFooter.add_paragraph
# ---------------------------------------------------------------------


@pytest.mark.parametrize("value", [42, 1.5, [1, 2], {"a": "b"}, object()])
def test_header_footer_add_paragraph_rejects_invalid_style_type(
    mock_session: Any, fake_sd_methods: Any, value: object
) -> None:
    from docx.section import Section, _HeaderFooter

    section = Section(
        session=mock_session,
        address={"kind": "section", "sectionIndex": 0},
    )
    header = _HeaderFooter(section=section, kind="header")
    with pytest.raises(TypeError, match="ParagraphStyle"):
        header.add_paragraph("hello", style=value)
