"""Lock-in tests for ``add_picture`` empty-bytes validation.

Previously ``Document.add_picture`` and ``Run.add_picture`` silently
accepted empty payloads (closed file, empty ``BytesIO``, stream
already exhausted). The resulting ``data:image/png;base64,`` URI
created a broken placeholder image at render time. The new behavior
raises :class:`ValueError` at the call site so the failure is visible
where the bug actually is.
"""

from __future__ import annotations

import io
import os
import tempfile
from typing import Any

import pytest


def _make_doc(mock_session: Any):
    """Return a ``Document`` bound to the fake session via direct
    construction (skipping the ``Document(asset_id)`` factory which
    would open a real session). The session has ``is_open=True``
    pre-set on the fake."""
    from docx.document import Document as DocClass

    d = DocClass.__new__(DocClass)
    d._session = mock_session
    d._saved = False
    d._closed = False
    d._pending_user_name = None
    d._pending_user_email = None
    d._pending_track_revisions = False
    return d


def test_document_add_picture_empty_stream_raises(mock_session: Any) -> None:
    doc = _make_doc(mock_session)
    empty_stream = io.BytesIO()
    with pytest.raises(ValueError) as excinfo:
        doc.add_picture(empty_stream)
    assert "empty" in str(excinfo.value).lower()


def test_document_add_picture_exhausted_stream_raises(mock_session: Any) -> None:
    doc = _make_doc(mock_session)
    stream = io.BytesIO(b"\x89PNG\r\n\x1a\nfake")
    stream.read()  # exhaust it
    with pytest.raises(ValueError) as excinfo:
        doc.add_picture(stream)
    assert "empty" in str(excinfo.value).lower()


def test_document_add_picture_empty_file_raises(mock_session: Any) -> None:
    doc = _make_doc(mock_session)
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        path = f.name
    try:
        with pytest.raises(ValueError) as excinfo:
            doc.add_picture(path)
        assert "empty" in str(excinfo.value).lower()
    finally:
        os.unlink(path)


def test_run_add_picture_empty_stream_raises(mock_session: Any) -> None:
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 0))
    with pytest.raises(ValueError) as excinfo:
        run.add_picture(io.BytesIO())
    assert "empty" in str(excinfo.value).lower()


def test_run_add_picture_wrong_type_raises_type_error(mock_session: Any) -> None:
    """Non-str non-IOBase still raises TypeError (existing contract)."""
    from docx.text.run import Run

    run = Run(session=mock_session, block_id="p-1", range_=(0, 0))
    with pytest.raises(TypeError):
        run.add_picture(12345)  # type: ignore[arg-type]
