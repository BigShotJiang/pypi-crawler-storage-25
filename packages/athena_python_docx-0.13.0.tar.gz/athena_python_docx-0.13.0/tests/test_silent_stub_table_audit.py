"""Lock-in tests for silent-stub gaps discovered in the Table audit.

These tests pin behavior that previously failed silently — the SDK
shipped through invalid values to the wire (negative widths, invalid
enum strings, non-string text) instead of raising the way python-docx
1.2.0 does. A regression here would re-introduce the silent path.

The gaps fixed in this PR:

1. ``_Cell.text`` setter: rejected non-``str`` types (``int``, ``None``)
   are now ``TypeError`` to match upstream's ``"".join(value)`` failure.
2. ``_Cell.vertical_alignment`` setter: invalid enum strings now raise
   ``ValueError``; previously any ``.lower()``-able value was shipped
   to the wire.
3. ``_Column.width`` setter / ``Table.add_column(width=…)``: negative
   widths now raise ``ValueError`` (parity with upstream's
   ``Emu(value)``).
"""

from __future__ import annotations

from typing import Any

import pytest


def _scripted_get(rows: int, cols: int) -> dict:
    return {"rows": rows, "cols": cols, "styleId": "TableGrid"}


def _make_table(mock_session: Any, *, node_id: str = "tbl-audit"):
    from docx.table import Table

    return Table(session=mock_session, node_id=node_id)


# ---------------------------------------------------------------------------
# _Cell.text setter — non-string values
# ---------------------------------------------------------------------------


def test_cell_text_setter_rejects_int(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Setting ``cell.text = 123`` raises ``TypeError`` (parity with
    upstream — ``"".join(123)`` is not iterable)."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    with pytest.raises(TypeError) as excinfo:
        cell.text = 123  # type: ignore[assignment]
    assert "str" in str(excinfo.value).lower()


def test_cell_text_setter_rejects_none(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Setting ``cell.text = None`` raises ``TypeError`` (parity with
    upstream — ``"".join(None)`` is not iterable). Previously the
    setter coerced ``None`` to ``""`` via ``value or ""``."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    with pytest.raises(TypeError) as excinfo:
        cell.text = None  # type: ignore[assignment]
    assert "str" in str(excinfo.value).lower()


def test_cell_text_setter_accepts_empty_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Sanity: empty string remains valid — only non-strings raise."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    # Should not raise.
    cell.text = ""


def test_cell_text_setter_accepts_str(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Sanity: a normal string still works."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    cell.text = "hello"  # Should not raise.


# ---------------------------------------------------------------------------
# _Cell.vertical_alignment setter — invalid enum values
# ---------------------------------------------------------------------------


def test_cell_vertical_alignment_rejects_invalid_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Setting a bogus alignment string raises ``ValueError`` instead
    of silently shipping it to the wire."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    with pytest.raises(ValueError) as excinfo:
        cell.vertical_alignment = "banana"
    assert "WD_ALIGN_VERTICAL" in str(excinfo.value)


def test_cell_vertical_alignment_accepts_enum_member(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A proper ``WD_ALIGN_VERTICAL`` member is accepted and forwarded."""
    from docx.enum.table import WD_ALIGN_VERTICAL

    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER  # No raise.
    # Confirm we did ship a set_cell_properties call with the mapped value.
    sent = [c for c in fake_sd_methods.calls if c[0] == "tables.set_cell_properties"]
    assert sent, "expected tables.set_cell_properties to be called"
    assert sent[-1][1]["verticalAlign"] == "center"


def test_cell_vertical_alignment_accepts_valid_string(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A string matching a valid enum value (post lower-casing) is
    accepted. This is intentionally more permissive than upstream's
    enum-only setter — it makes the SDK happier for agents writing
    pure strings — but invalid strings still raise."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    cell.vertical_alignment = "top"  # No raise.
    sent = [c for c in fake_sd_methods.calls if c[0] == "tables.set_cell_properties"]
    assert sent and sent[-1][1]["verticalAlign"] == "top"


def test_cell_vertical_alignment_none_is_noop(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Setting ``None`` is a documented no-op — does not emit a wire op."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 1)
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1"}],
    }
    table = _make_table(mock_session)
    cell = table.cell(0, 0)
    cell.vertical_alignment = None
    sent = [c for c in fake_sd_methods.calls if c[0] == "tables.set_cell_properties"]
    assert sent == []


# ---------------------------------------------------------------------------
# _Column.width setter — negative widths
# ---------------------------------------------------------------------------


def test_column_width_rejects_negative_int(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Negative EMU width raises ``ValueError`` (parity with upstream's
    ``Emu(value)`` which clamps to the unsigned-int range)."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 2)
    table = _make_table(mock_session)
    col = table.columns[0]
    with pytest.raises(ValueError) as excinfo:
        col.width = -100
    assert ">= 0" in str(excinfo.value) or "negative" in str(excinfo.value).lower()


def test_column_width_rejects_negative_length(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Negative ``Length`` (via raw EMU subclass) also rejected."""
    from docx.shared import Length

    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 2)
    table = _make_table(mock_session)
    col = table.columns[0]
    # Length subclasses int — constructing one with a negative value works,
    # but the setter must still reject it.
    neg = Length.__new__(Length, -914400)
    with pytest.raises(ValueError):
        col.width = neg


def test_column_width_accepts_zero(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Zero is accepted — only strictly-negative values raise.

    Upstream python-docx allows ``Emu(0)`` (the unsigned range starts
    at 0). Zero-width columns are a real OOXML construct (cells inside
    a hidden column).
    """
    from docx.shared import Length

    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 2)
    table = _make_table(mock_session)
    col = table.columns[0]
    col.width = Length(0)  # Should not raise.
    sent = [c for c in fake_sd_methods.calls if c[0] == "tables.set_column_width"]
    assert sent, "expected tables.set_column_width to be called"


# ---------------------------------------------------------------------------
# Table.add_column — eager width validation
# ---------------------------------------------------------------------------


def test_add_column_rejects_negative_width_eagerly(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``Table.add_column(width=-100)`` raises before issuing any wire
    op. Previously the insert_column call landed first and only the
    follow-up width setter failed — leaving a phantom column behind."""
    fake_sd_methods.scripted_returns["tables.get"] = _scripted_get(1, 2)
    table = _make_table(mock_session)
    with pytest.raises(ValueError):
        table.add_column(width=-100)  # type: ignore[arg-type]
    # No insert_column op should have been emitted.
    insert_ops = [c for c in fake_sd_methods.calls if c[0] == "tables.insert_column"]
    assert insert_ops == [], (
        f"add_column(width=-100) should not emit insert_column; got {insert_ops!r}"
    )
