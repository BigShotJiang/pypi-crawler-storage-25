"""Lock-in tests for the ``docx.oxml`` stub package.

``docx.oxml`` is intentionally unavailable in athena-python-docx —
agent code that imports ``docx.oxml.ns``, ``docx.oxml.parser``, etc.
used to fail with the stdlib's generic ``ModuleNotFoundError: No
module named 'docx.oxml'`` and had to retry to discover the gap.

The 0.8.0 stub package replaced that with a single typed
:class:`OxmlNotAvailableError` that named the high-level python-docx
surface the caller should use instead — but the 0.8.0 stub raised
on attribute access, which is what ``from docx.oxml.ns import qn``
triggers. That meant the import statement itself crashed before any
line of the agent's actual logic ran. The common python-docx
convention of declaring ``qn`` / ``OxmlElement`` at the top of every
script "just in case" killed scripts that only used the high-level
API.

As of 0.11.3 the stub is **lazy**:

1. Every common upstream submodule (``ns``, ``parser``, ``element``,
   ``xmlchemy``, …) is importable — same as 0.8.0.
2. Attribute access on those modules now returns a sentinel proxy
   rather than raising — ``from docx.oxml.ns import qn`` succeeds,
   ``qn`` is bound to a :class:`_LazyRaisingProxy`.
3. The typed :class:`OxmlNotAvailableError` fires only when the
   imported symbol is actually used — called (``qn(...)``),
   attribute-accessed (``OxmlElement.tag``), or written-to
   (``OxmlElement.tag = "..."``).

These tests pin all three contracts so a future refactor can't
regress to the 0.8.0 import-time failure or to a totally-permissive
no-op stub.
"""

from __future__ import annotations

import importlib
import pytest


def test_oxml_not_available_error_is_importerror_subclass() -> None:
    """Code that uses ``try / except ImportError`` to detect missing
    oxml support must still catch :class:`OxmlNotAvailableError`."""
    from docx.oxml import OxmlNotAvailableError

    assert issubclass(OxmlNotAvailableError, ImportError)


@pytest.mark.parametrize(
    "submodule",
    [
        "ns",
        "parser",
        "element",
        "xmlchemy",
        "exceptions",
        "coreprops",
        "document",
        "text",
        "table",
        "comments",
        "header_footer",
        "section",
        "settings",
        "styles",
        "numbering",
    ],
)
def test_submodule_import_succeeds(submodule: str) -> None:
    """``import docx.oxml.<X>`` must resolve to a stub module without
    raising. Same contract as 0.8.0."""
    mod = importlib.import_module(f"docx.oxml.{submodule}")
    assert mod is not None
    assert mod.__name__ == f"docx.oxml.{submodule}"


def test_top_level_import_succeeds_lazy() -> None:
    """``from docx.oxml import OxmlElement`` (and friends) must
    succeed and bind a sentinel proxy. The 0.8.0 stub raised at
    import time; 0.11.3 defers the error until the symbol is used.
    """
    from docx.oxml import OxmlElement  # must NOT raise

    assert OxmlElement is not None
    # repr should reveal the lazy nature so debugging is easy.
    assert "docx.oxml.OxmlElement" in repr(OxmlElement)


def test_submodule_import_succeeds_lazy() -> None:
    """``from docx.oxml.ns import qn`` must succeed and bind a sentinel
    proxy. This is the most common python-docx import pattern."""
    from docx.oxml.ns import qn, nsmap  # must NOT raise

    assert qn is not None
    assert nsmap is not None
    assert "docx.oxml.ns.qn" in repr(qn)


def test_call_on_imported_symbol_raises() -> None:
    """The typed error fires when the imported symbol is actually
    invoked. ``qn("w:tcW")`` raises :class:`OxmlNotAvailableError`
    with the educated message pointing at the high-level surface."""
    from docx.oxml import OxmlNotAvailableError
    from docx.oxml.ns import qn

    with pytest.raises(OxmlNotAvailableError) as exc_info:
        qn("w:tcW")
    msg = str(exc_info.value)
    assert "docx.oxml.ns.qn" in msg
    assert "Document.add_paragraph" in msg


def test_attribute_access_on_imported_symbol_raises() -> None:
    """``OxmlElement.tag`` and similar attribute lookups on the
    sentinel proxy raise the typed error with the full dotted path."""
    from docx.oxml import OxmlElement, OxmlNotAvailableError

    with pytest.raises(OxmlNotAvailableError) as exc_info:
        _ = OxmlElement.tag
    msg = str(exc_info.value)
    assert "docx.oxml.OxmlElement.tag" in msg
    assert "Document.add_paragraph" in msg


def test_attribute_write_on_imported_symbol_raises() -> None:
    """Writes against the sentinel (``OxmlElement.tag = "..."``) also
    raise — otherwise the assignment silently succeeds and the next
    read of ``OxmlElement.tag`` returns the cached value, masking the
    fact that no XML element actually exists."""
    from docx.oxml import OxmlElement, OxmlNotAvailableError

    with pytest.raises(OxmlNotAvailableError):
        OxmlElement.tag = "w:foo"


def test_call_on_module_level_symbol_raises() -> None:
    """``oxml.OxmlElement(...)`` (without a from-import) follows the
    same path — the package-level ``__getattr__`` returns the lazy
    proxy, the proxy raises on call."""
    import docx.oxml as oxml
    from docx.oxml import OxmlNotAvailableError

    with pytest.raises(OxmlNotAvailableError):
        oxml.OxmlElement()


def test_repeated_attribute_access_returns_same_proxy() -> None:
    """``ns.qn`` accessed twice returns the same proxy instance so
    callers that bind it to a local then re-fetch (e.g. assignments
    in different functions) don't get diverging sentinels."""
    import docx.oxml.ns as ns

    first = ns.qn
    second = ns.qn
    assert first is second


def test_repeated_package_level_access_returns_same_proxy() -> None:
    """Same identity invariant at the package level: ``oxml.OxmlElement``
    accessed twice returns the same proxy. The PEP 562 module-level
    ``__getattr__`` caches into module globals so a second access
    skips the hook entirely."""
    import docx.oxml as oxml

    first = oxml.OxmlSomethingNew  # arbitrary fresh name, no prior cache
    second = oxml.OxmlSomethingNew
    assert first is second


def test_isinstance_against_proxy_raises_typeerror() -> None:
    """``isinstance(x, OxmlElement)`` where ``OxmlElement`` is the
    proxy raises Python's native ``TypeError`` — CPython validates
    arg 2 is a type before consulting ``__instancecheck__``, so the
    proxy never sees the call. Pinned so future "make the proxy a
    type" refactors don't silently change behavior."""
    from docx.oxml import OxmlElement

    with pytest.raises(TypeError, match="isinstance"):
        isinstance(object(), OxmlElement)


def test_dunder_attribute_access_falls_through() -> None:
    """Dunder access (``__path__``, ``__loader__``, etc.) must NOT
    return a proxy — the import machinery probes those during
    submodule resolution. Treating them as user attribute access
    would break the import path."""
    import docx.oxml.ns as ns

    with pytest.raises(AttributeError):
        _ = ns.__nonexistent_dunder__


def test_from_submodule_import_succeeds_lazy() -> None:
    """``from docx.oxml.parser import OxmlElement`` must succeed
    under the lazy contract — 0.8.0 raised here, but the agent's
    actual mistake is the call site, not the import."""
    # Should not raise.
    exec("from docx.oxml.parser import OxmlElement", {})
