"""Regression tests for fixes from PR #19766 review feedback.

Each test pins a specific issue surfaced by Greptile / CodeRabbit /
Devin so a future regression makes the gap visible again instead of
silently re-introducing the bug.
"""

from __future__ import annotations

from typing import Any

import pytest

# ---------------------------------------------------------------------------
# Critical fix: `in` → `in_` rename in _FIELD_RENAMES
# ---------------------------------------------------------------------------


def test_build_command_create_paragraph_remaps_in_to_in_() -> None:
    """``_build_command("create.paragraph", {"in": …, "text": …, "at": …})``
    must remap ``in`` → ``in_`` before calling the dataclass ctor —
    otherwise ``CreateParagraph(**params)`` raises ``TypeError`` at
    runtime when the path-proxy threads the canonical SuperDoc shape.

    Devin + CodeRabbit both flagged this on PR #19766; the
    fixture-based tests don't exercise the path-proxy so the bug was
    invisible until production traffic.
    """
    from docx._http_doc import _build_command
    from docx.commands import CreateParagraph

    cmd = _build_command(
        "create.paragraph",
        {
            "text": "hello",
            "at": {"kind": "documentEnd"},
            "in": {
                "kind": "story",
                "storyType": "headerFooterSlot",
                "section": {"kind": "section", "sectionId": "sec-1"},
                "headerFooterKind": "header",
                "variant": "default",
            },
        },
    )
    assert isinstance(cmd, CreateParagraph)
    assert cmd.in_ is not None
    assert cmd.in_["storyType"] == "headerFooterSlot"
    # And on the wire the field round-trips back as `in`.
    wire = cmd.to_dict()
    assert "in" in wire
    assert "in_" not in wire


def test_build_command_create_table_and_heading_remap_in() -> None:
    """create.heading and create.table must also remap ``in`` → ``in_``."""
    from docx._http_doc import _build_command
    from docx.commands import CreateHeading, CreateTable

    h = _build_command(
        "create.heading",
        {
            "text": "H",
            "level": 1,
            "at": {"kind": "documentEnd"},
            "in": {"kind": "story", "storyType": "body"},
        },
    )
    assert isinstance(h, CreateHeading)
    assert h.in_ == {"kind": "story", "storyType": "body"}

    t = _build_command(
        "create.table",
        {
            "rows": 1,
            "columns": 1,
            "at": {"kind": "documentEnd"},
            "in": {"kind": "story", "storyType": "body"},
        },
    )
    assert isinstance(t, CreateTable)
    assert t.in_ == {"kind": "story", "storyType": "body"}


# ---------------------------------------------------------------------------
# ProseMirror flat-text inline shape (regression I introduced in Phase A)
# ---------------------------------------------------------------------------


def test_iter_inner_content_yields_run_for_prosemirror_flat_text(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Inlines in ProseMirror's flat shape ``{type: text, text: ...}``
    must yield a Run, not get silently dropped (regression I introduced
    in the Phase A iter_inner_content rewrite — caught by CodeRabbit)."""
    from docx.text.paragraph import Paragraph
    from docx.text.run import Run

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "paragraph": {
                "inlines": [
                    {"type": "text", "text": "flat-shape text"},
                ],
            },
        },
    }
    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    items = list(para.iter_inner_content())
    assert len(items) == 1
    assert isinstance(items[0], Run)
    assert items[0].text == "flat-shape text"


def test_iter_inner_content_handles_mixed_inline_shapes(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """A paragraph mixing both wrapper-shape and flat-shape inlines
    yields a Run for each in document order."""
    from docx.text.paragraph import Paragraph
    from docx.text.run import Run

    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "paragraph": {
                "inlines": [
                    {"run": {"text": "wrapped"}},
                    {"type": "text", "text": "flat"},
                ],
            },
        },
    }
    para = Paragraph(session=mock_session, node_id="p1", node_type="paragraph")
    items = list(para.iter_inner_content())
    assert [type(i).__name__ for i in items] == ["Run", "Run"]
    assert [i.text for i in items if isinstance(i, Run)] == ["wrapped", "flat"]


# ---------------------------------------------------------------------------
# _Cell.iter_inner_content now yields nested tables interleaved
# ---------------------------------------------------------------------------


def test_cell_iter_inner_content_yields_paragraphs_and_tables_in_order(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Greptile + CodeRabbit both flagged that
    ``_Cell.iter_inner_content`` previously yielded only paragraphs.
    Upstream yields ``Iterator[Paragraph | Table]`` interleaved.
    """
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    fake_sd_methods.scripted_returns["tables.get"] = {
        "rows": 1,
        "cols": 1,
        "styleId": "TableGrid",
    }
    fake_sd_methods.scripted_returns["tables.get_cells"] = {
        "cells": [{"nodeId": "c-1", "text": "x"}],
    }
    fake_sd_methods.scripted_returns["get_node_by_id"] = {
        "node": {
            "tableCell": {
                "blocks": [
                    {"nodeType": "paragraph", "nodeId": "p-1"},
                    {"nodeType": "table", "nodeId": "t-nested"},
                    {"nodeType": "paragraph", "nodeId": "p-2"},
                ],
            },
        },
    }
    table = Table(session=mock_session, node_id="parent")
    cell = table.cell(0, 0)
    items = list(cell.iter_inner_content())
    kinds = [type(i).__name__ for i in items]
    assert kinds == ["Paragraph", "Table", "Paragraph"]
    assert items[0]._node_id == "p-1"  # type: ignore[attr-defined]
    nested_table = items[1]
    assert isinstance(nested_table, Table)
    assert nested_table._node_id == "t-nested"
    p2 = items[2]
    assert isinstance(p2, Paragraph)
    assert p2._node_id == "p-2"  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Style application surfaces failures (no more bare except)
# ---------------------------------------------------------------------------


def test_document_add_paragraph_propagates_setstyle_failure(
    monkeypatch: pytest.MonkeyPatch,
    mock_session: Any,
    fake_sd_methods: Any,
) -> None:
    """If ``Paragraph.style = ...`` raises, ``Document.add_paragraph``
    no longer silently swallows it (Greptile P1)."""
    from docx.document import Document
    from docx.text import paragraph as paragraph_mod

    fake_sd_methods.scripted_returns["create.paragraph"] = {
        "success": True,
        "paragraph": {"nodeId": "p-1"},
    }

    class Boom(Exception):
        pass

    def raising_setter(self: Any, value: Any) -> None:
        raise Boom("simulated SuperDoc 4xx")

    # Replace Paragraph.style.setter so we can prove failures propagate.
    monkeypatch.setattr(
        paragraph_mod.Paragraph,
        "style",
        property(lambda self: None, raising_setter),
    )

    doc = Document.__new__(Document)
    doc._session = mock_session
    doc._saved = False
    doc._closed = False

    with pytest.raises(Boom):
        doc.add_paragraph("hi", style="Quote")


# ---------------------------------------------------------------------------
# _Row caches its rowInfo across grid_cols_before / grid_cols_after
# ---------------------------------------------------------------------------


def test_row_caches_row_info_across_grid_cols_reads(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """Reading ``grid_cols_before`` then ``grid_cols_after`` should
    issue a SINGLE ``tables.get`` round-trip via ``_row_info`` — not
    two (Greptile P2)."""
    from docx.table import _Row

    fake_sd_methods.scripted_returns["tables.get"] = {
        "rows": 2,
        "cols": 4,
        "styleId": "TableGrid",
        "rowInfo": [{"gridBefore": 1, "gridAfter": 2}, {}],
    }
    # Construct _Row directly to bypass Table.rows' tables.get call so
    # we can isolate _row_info caching.
    row = _Row.__new__(_Row)
    from unittest.mock import MagicMock

    table = MagicMock()
    table._fresh_node_id.return_value = "t1"

    def _fake_fresh_node_info():
        # Mirror Table._fresh_node_info: one tables.get RPC, returns (id, info).
        from docx._batching import run_sync as _run_sync

        info = _run_sync(mock_session.doc.tables.get({"nodeId": "t1"}))
        return "t1", info if isinstance(info, dict) else {}

    table._fresh_node_info.side_effect = _fake_fresh_node_info
    table._session = mock_session
    row._table = table
    row._index = 0
    row._row_info_cache = None
    row._row_info_loaded = False

    before_first = sum(1 for c in fake_sd_methods.calls if c[0] == "tables.get")
    _ = row.grid_cols_before
    after_first = sum(1 for c in fake_sd_methods.calls if c[0] == "tables.get")
    _ = row.grid_cols_after
    after_second = sum(1 for c in fake_sd_methods.calls if c[0] == "tables.get")

    assert after_first - before_first == 1, "first read should fetch rowInfo"
    assert after_second - after_first == 0, (
        "second read should hit cache, not re-fetch"
    )


# ---------------------------------------------------------------------------
# Table.cell() issues a SINGLE tables.get for bounds (Greptile P2)
# ---------------------------------------------------------------------------


def test_table_cell_issues_single_tables_get_for_bounds(
    mock_session: Any, fake_sd_methods: Any
) -> None:
    """``Table.cell(r, c)`` should issue exactly ONE ``tables.get`` RPC
    for bounds checking — previously ``_fresh_node_id`` + ``cell()``
    each issued one for 2× the round-trips per cell access. For a
    3×3 cell-iteration loop this was 18 RPCs; the fix takes it to 9."""
    from docx.table import Table

    fake_sd_methods.scripted_returns["tables.get"] = {
        "rows": 3,
        "cols": 3,
        "styleId": "TableGrid",
        "nodeId": "tbl-1",
    }
    table = Table(session=mock_session, node_id="tbl-1")

    before = sum(1 for c in fake_sd_methods.calls if c[0] == "tables.get")
    table.cell(0, 0)
    after = sum(1 for c in fake_sd_methods.calls if c[0] == "tables.get")
    assert after - before == 1, (
        f"Table.cell should issue exactly 1 tables.get, got {after - before}"
    )


# ---------------------------------------------------------------------------
# Underscore-class introspector exemption is narrow
# ---------------------------------------------------------------------------


def test_underscore_class_exemption_allowlist_is_narrow() -> None:
    """The introspector should only promote a small documented set of
    underscore-prefixed classes — not every class with a leading
    underscore (CodeRabbit caught the over-broad blanket)."""
    from tests.parity.introspect import _PUBLIC_UNDERSCORE_CLASS_NAMES

    expected = {
        "_Cell",
        "_Column",
        "_Columns",
        "_Footer",
        "_Header",
        "_NumberingStyle",
        "_Row",
        "_Rows",
        "_TableStyle",
    }
    assert set(_PUBLIC_UNDERSCORE_CLASS_NAMES) == expected, (
        "Public-underscore-class set drifted; review intent before "
        "adding/removing entries — every name here promotes its class "
        "into the parity surface."
    )


def test_table_style_alias_is_importable() -> None:
    """``_TableStyle`` is the canonical upstream name for the
    table-style class; athena's ``TableStyle`` aliases it for parity."""
    from docx.styles.style import TableStyle, _TableStyle

    assert _TableStyle is TableStyle
