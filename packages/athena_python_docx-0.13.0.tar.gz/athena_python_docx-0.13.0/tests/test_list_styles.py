"""Behavioral coverage for ``add_paragraph(style="List Bullet" | "List Number")``.

Locks in the SDK contract that a list-styled paragraph is structurally
promoted to a real list item via SuperDoc's ``doc.lists.create`` /
``doc.lists.attach`` rather than left as a flat paragraph with a style
attribute. Setting the style alone makes Word/OOXML render bullets via
the style's embedded ``<w:numPr/>``, but SuperDoc's ProseMirror schema
needs a real ``bulletList > listItem > paragraph`` tree — these tests
pin the wire-op sequence that produces it.

Why these tests matter:
- Catches regression of the docx-studio UI/UX investigation where the
  agent's generated report had every "bullet item" land as plain Normal
  paragraphs (see ``op_snapshots/rw02_paragraph_style_list.json``).
- Documents the chain semantics: consecutive same-kind list items
  attach to the previous list (one ``lists.create`` + N-1
  ``lists.attach``), while any non-list block (heading, table, …)
  breaks the chain so the next list starts fresh.
"""

from __future__ import annotations

import pytest

from docx import Document, flush_all
from docx.document import _classify_list_style
from tests.fidelity.fake_session import install_fake_session


def _ops_from_script(script: str) -> list[str]:
    """Run ``script`` against a fake session and return the wire-op trace."""
    install_fake_session()
    doc = Document("asset_fake")
    local_ns: dict = {"doc": doc}
    exec(compile(script, "<test>", "exec"), local_ns, local_ns)
    flush_all()
    return [op for op, _ in doc._session.calls()]  # type: ignore[attr-defined]


class TestClassifyListStyle:
    """Unit-level: ``_classify_list_style`` is the pure mapping behind the
    routing logic. Keep coverage tight so the public ``add_paragraph``
    contract can't drift from the styles python-docx documents."""

    @pytest.mark.parametrize(
        "style_id, expected",
        [
            ("List Bullet", ("bullet", 0)),
            ("List Bullet 2", ("bullet", 1)),
            ("List Bullet 3", ("bullet", 2)),
            ("List Bullet 4", ("bullet", 3)),
            ("List Bullet 5", ("bullet", 4)),
            # python-docx ships style ids in two flavors — the display
            # name (with spaces) and the OOXML id (without). Both must
            # land on the same (kind, level) pair.
            ("ListBullet", ("bullet", 0)),
            ("ListBullet2", ("bullet", 1)),
            ("List Number", ("ordered", 0)),
            ("List Number 2", ("ordered", 1)),
            ("ListNumber5", ("ordered", 4)),
        ],
    )
    def test_recognized_list_styles(
        self, style_id: str, expected: tuple[str, int],
    ) -> None:
        assert _classify_list_style(style_id) == expected

    @pytest.mark.parametrize(
        "style_id",
        [
            None,
            "",
            "Normal",
            "Heading 1",
            "Title",
            # "List Paragraph" / "List Continue" are body-text styles, not
            # bullet/number lists — they should NOT be promoted to a
            # bulletList node.
            "List Paragraph",
            "List Continue",
            "List Continue 2",
            # Bogus level suffix — don't silently coerce to 0.
            "List Bullet abc",
            # Out-of-range level — refuse rather than guess.
            "List Bullet 0",
            "List Bullet 99",
        ],
    )
    def test_non_list_styles(self, style_id: str | None) -> None:
        assert _classify_list_style(style_id) is None


class TestSingleListItem:
    """The smallest possible promotion: one bullet, one wire chain."""

    def test_single_bullet_creates_a_new_list(self) -> None:
        ops = _ops_from_script(
            "doc.add_paragraph('one', style='List Bullet')"
        )
        # Expected sequence: paragraph created, styled, then promoted
        # into a fresh list (no previous list to attach to).
        assert ops == [
            "create.paragraph",
            "styles.paragraph.setStyle",
            "lists.create",
        ], f"unexpected wire ops: {ops}"

    def test_single_numbered_item_creates_an_ordered_list(self) -> None:
        ops = _ops_from_script(
            "doc.add_paragraph('one', style='List Number')"
        )
        assert ops == [
            "create.paragraph",
            "styles.paragraph.setStyle",
            "lists.create",
        ], f"unexpected wire ops: {ops}"


class TestListChain:
    """Consecutive same-kind list items must share one list."""

    def test_consecutive_bullets_chain_via_attach(self) -> None:
        ops = _ops_from_script(
            "for i in range(3):\n"
            "    doc.add_paragraph(f'item {i}', style='List Bullet')\n"
        )
        # First item starts the list; subsequent items attach.
        assert ops == [
            "create.paragraph",
            "styles.paragraph.setStyle",
            "lists.create",
            "create.paragraph",
            "styles.paragraph.setStyle",
            "lists.attach",
            "create.paragraph",
            "styles.paragraph.setStyle",
            "lists.attach",
        ], f"unexpected wire ops: {ops}"

    def test_kind_switch_starts_a_new_list(self) -> None:
        # Switching from bullet to ordered (or vice-versa) is a list
        # boundary — each kind gets its own ``lists.create``.
        ops = _ops_from_script(
            "doc.add_paragraph('b1', style='List Bullet')\n"
            "doc.add_paragraph('b2', style='List Bullet')\n"
            "doc.add_paragraph('n1', style='List Number')\n"
            "doc.add_paragraph('n2', style='List Number')\n"
        )
        list_ops = [op for op in ops if op.startswith("lists.")]
        assert list_ops == [
            "lists.create",
            "lists.attach",
            "lists.create",  # kind switch → new list
            "lists.attach",
        ], f"unexpected list ops: {list_ops}"


class TestChainResets:
    """Any non-list block between items must break the chain so the next
    list item starts a fresh list (otherwise we'd attach across an
    intervening heading/table/etc., producing nonsense structure)."""

    def test_plain_paragraph_resets_chain(self) -> None:
        ops = _ops_from_script(
            "doc.add_paragraph('item 1', style='List Bullet')\n"
            "doc.add_paragraph('a paragraph between lists')\n"
            "doc.add_paragraph('item 2', style='List Bullet')\n"
        )
        list_ops = [op for op in ops if op.startswith("lists.")]
        # Both bullets start their own list — no attach across the
        # plain paragraph.
        assert list_ops == ["lists.create", "lists.create"], (
            f"plain paragraph should reset chain; got {list_ops}"
        )

    def test_heading_resets_chain(self) -> None:
        ops = _ops_from_script(
            "doc.add_paragraph('item 1', style='List Bullet')\n"
            "doc.add_heading('A Heading', level=2)\n"
            "doc.add_paragraph('item 2', style='List Bullet')\n"
        )
        list_ops = [op for op in ops if op.startswith("lists.")]
        assert list_ops == ["lists.create", "lists.create"], (
            f"heading should reset chain; got {list_ops}"
        )

    def test_table_resets_chain(self) -> None:
        ops = _ops_from_script(
            "doc.add_paragraph('item 1', style='List Bullet')\n"
            "doc.add_table(rows=1, cols=1)\n"
            "doc.add_paragraph('item 2', style='List Bullet')\n"
        )
        list_ops = [op for op in ops if op.startswith("lists.")]
        assert list_ops == ["lists.create", "lists.create"], (
            f"table should reset chain; got {list_ops}"
        )


class TestNonListStylesUnchanged:
    """Regression guard: non-list styles must NOT emit list ops. A bug
    in the classifier that returned (kind, level) for, say, "Heading 1"
    would silently produce ``lists.create`` calls on every heading."""

    def test_heading_emits_no_list_ops(self) -> None:
        ops = _ops_from_script(
            "doc.add_paragraph('a heading', style='Heading 1')"
        )
        assert not any(op.startswith("lists.") for op in ops), (
            f"heading produced list ops: {ops}"
        )

    def test_normal_paragraph_emits_no_list_ops(self) -> None:
        ops = _ops_from_script("doc.add_paragraph('plain')")
        assert not any(op.startswith("lists.") for op in ops), (
            f"plain paragraph produced list ops: {ops}"
        )

    def test_intense_quote_style_emits_no_list_ops(self) -> None:
        # 'Intense Quote' was the offender in the python-docx
        # quickstart that triggered the initial UI/UX investigation.
        ops = _ops_from_script(
            "doc.add_paragraph('quoted', style='Intense Quote')"
        )
        assert not any(op.startswith("lists.") for op in ops), (
            f"Intense Quote produced list ops: {ops}"
        )
