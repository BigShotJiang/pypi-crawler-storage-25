"""Perf contract for ``_Cell.text =`` cell writes (athena-python-docx 0.10.0+).

The contract this pins: a 30-cell table assignment ships in exactly
ONE HTTP batch with zero ``tables.get`` / ``tables.get_cells`` queries.
Pre-0.10.0 the SDK eager-flushed two queries per cell
(``Table._fresh_node_info`` → ``tables.get`` + ``_Cell._cell_id`` →
``tables.get_cells``), making a 30-cell table 60+ sequential HTTP
round-trips and producing the "edits stream in one-by-one" UI symptom
documented in
``docx-studio/PERFORMANCE_BATCHING_ANALYSIS.md`` § *Cell writes*.

The fix routes ``_Cell.text =`` through a new ``TableSetCell`` command
that addresses the cell by ``(table_node_id, row, col)``. The apps/api
applier resolves the cell server-side against a per-batch cache.
"""

from __future__ import annotations

from tests.fidelity.fake_session import install_fake_session


def test_30_cell_table_assignment_is_one_batch_with_no_eager_queries() -> None:
    """Headline perf test. Mirrors the agent code that triggered the
    investigation: ``for i,j,v in rows: tbl.cell(i,j).text = v`` for a
    5x6 = 30-cell table. We assert:

    1. No ``tables.get`` calls (would mean ``Table._fresh_node_info``
       round-tripped for every cell — the pre-0.10.0 perf bug).
    2. No ``tables.getCells`` calls (would mean ``_Cell._cell_id``
       round-tripped — the other half of the perf bug).
    3. 30 ``TableSetCell`` commands were issued through the path
       proxy as ``tables.setCell`` — bug fix is wired up.

    The FakeSession records every namespace call regardless of whether
    it was sent to the (fake) HTTP transport, so this asserts the
    Python-side contract without needing a real apps/api.
    """
    install_fake_session()
    from docx import Document

    doc = Document("asset_perf")
    tbl = doc.add_table(rows=5, cols=6)
    # The 30-cell write loop — identical shape to the agent code that
    # produced the slow 80s session.
    for r in range(5):
        for c in range(6):
            tbl.cell(r, c).text = f"r{r}c{c}"

    # Inspect every call routed through the SDK fakes.
    session = doc._session
    assert hasattr(session, "calls"), (
        "FakeSession must expose .calls() for this perf test"
    )
    ops = [name for name, _ in session.calls()]

    # Pre-0.10.0 perf bug: tables.get fired per cell.
    table_get_calls = [op for op in ops if op == "tables.get"]
    assert table_get_calls == [], (
        f"_Cell.text MUST NOT trigger tables.get; saw "
        f"{len(table_get_calls)} call(s) — perf regression. ops={ops!r}"
    )

    # Pre-0.10.0 perf bug: tables.getCells fired per cell.
    table_get_cells_calls = [op for op in ops if op == "tables.getCells"]
    assert table_get_cells_calls == [], (
        f"_Cell.text MUST NOT trigger tables.getCells; saw "
        f"{len(table_get_cells_calls)} call(s) — perf regression. "
        f"ops={ops!r}"
    )

    # Bug fix: every cell write becomes a tables.setCell.
    set_cell_calls = [op for op in ops if op == "tables.setCell"]
    assert len(set_cell_calls) == 30, (
        f"expected 30 tables.setCell calls (one per cell); got "
        f"{len(set_cell_calls)}. ops={ops!r}"
    )


def test_table_set_cell_payload_carries_addressing_fields() -> None:
    """Wire shape: each ``tables.setCell`` call carries
    ``tableNodeId``, ``rowIndex``, ``columnIndex``, ``content``. Pin
    so a future refactor that drops one of these silently breaks the
    server applier's per-batch cell-id cache."""
    install_fake_session()
    from docx import Document

    doc = Document("asset_payload")
    tbl = doc.add_table(rows=1, cols=1)
    tbl.cell(0, 0).text = "hello"

    session = doc._session
    set_cell = [(op, p) for op, p in session.calls() if op == "tables.setCell"]
    assert len(set_cell) == 1
    _, params = set_cell[0]
    assert "tableNodeId" in params and isinstance(params["tableNodeId"], str)
    assert params.get("rowIndex") == 0
    assert params.get("columnIndex") == 0
    content = params.get("content")
    assert isinstance(content, dict), f"content must be a dict; got {content!r}"
    # The plain-text fast path produces a SuperDoc native paragraph
    # fragment with the cell text as a single run.
    para = content.get("paragraph")
    assert isinstance(para, dict), f"expected paragraph fragment; got {content!r}"
    inlines = para.get("inlines")
    assert isinstance(inlines, list) and len(inlines) == 1
    run_text = (inlines[0].get("run") or {}).get("text")
    assert run_text == "hello"


def test_empty_string_cell_assignment_produces_empty_inlines() -> None:
    """``cell.text = ""`` must produce a fragment with an empty
    ``inlines`` list (not a run with empty text) so the applier's
    insert is a no-op on cells that already exist. Mirrors the
    pre-0.10.0 plain-text fast-path branch (``[ ] if value else []``)."""
    install_fake_session()
    from docx import Document

    doc = Document("asset_empty")
    tbl = doc.add_table(rows=1, cols=1)
    tbl.cell(0, 0).text = ""

    session = doc._session
    set_cell = [(op, p) for op, p in session.calls() if op == "tables.setCell"]
    assert len(set_cell) == 1
    _, params = set_cell[0]
    inlines = (params["content"]["paragraph"] or {}).get("inlines")
    assert inlines == [], f"empty cell text must emit empty inlines; got {inlines!r}"
