"""ParagraphFormat — python-docx docx.text.parfmt.ParagraphFormat parity.

Accessed via `paragraph.paragraph_format`. Values are persisted with
Superdoc's `doc.format.paragraph.*` operations, which take twips.

Setters accept:
    - Length/Emu/Pt/Inches/Cm/Mm/Twips instances — converted via .twips
    - raw int/float — treated as EMU and converted to twips
    - None — clears the property (where the underlying clear op exists)
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.shared import Length, Twips

if TYPE_CHECKING:
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
    from docx.text.paragraph import Paragraph
    from docx.text.tabstops import TabStops


class PendingParfmtClearWarning(UserWarning):
    """Emitted when a ``ParagraphFormat`` setter is asked to clear a
    trivalent (None/True/False) property whose SuperDoc wire op
    doesn't expose a clear primitive.

    Behavior pinned for parity with python-docx 1.x semantics
    (``None`` means "inherit from style") even though SuperDoc 1.8 can
    only set explicit values. The setter is a no-op at the wire level
    but emits this warning so silent inheritance-vs-set divergence
    surfaces during agent runs. Tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md``.
    """


def _warn_parfmt_clear(prop: str) -> None:
    warnings.warn(
        f"ParagraphFormat.{prop} = None was IGNORED — SuperDoc 1.8 "
        f"has no clear-op for this trivalent attribute. The value "
        f"stays whatever it was last set to (or inherited from the "
        f"paragraph style). Tracked in "
        f"docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md.",
        PendingParfmtClearWarning,
        stacklevel=3,
    )


def _require_bool(prop: str, value: object) -> bool:
    """Reject non-bool input for trivalent on/off properties.

    ``bool`` is a Python ``int`` subclass, so a bare ``True``/``False``
    would otherwise hit any ``isinstance(value, int)`` branch first
    and produce surprising semantics (e.g. ``line_spacing = True``
    setting a 1× multiplier). Callers must pass real bools.
    """
    if not isinstance(value, bool):
        raise TypeError(
            f"ParagraphFormat.{prop} requires bool (True/False/None); "
            f"got {type(value).__name__} {value!r}. python-docx 1.x "
            f"rejects truthy non-bool input here too.",
        )
    return value


def _to_twips(value: object) -> int:
    """Coerce a length-ish input to twips (int)."""
    if value is None:
        return 0
    if isinstance(value, Length):
        return value.twips
    if isinstance(value, (int, float)):
        # Bare numbers: assume EMU (python-docx convention for Length ints).
        return int(float(value) / 635)
    if hasattr(value, "twips"):
        return int(value.twips)  # type: ignore[attr-defined]
    raise TypeError(f"Cannot convert {type(value).__name__} to twips: {value!r}")


# Map SuperDoc wire kwargs (``set_indentation`` / ``set_spacing`` /
# ``set_keep_options`` / ``set_flow_options`` parameter names) to the
# OOXML-shape vocabulary the post-export rewrite consumes
# (``docx._postproc.PostExportOps``). Kept as a flat dict so unmapped
# keys fall through unchanged.
_WIRE_TO_OOXML_PROP_NAMES: dict[str, str] = {
    "left": "left_twips",
    "right": "right_twips",
    "firstLine": "first_line_twips",
    "hanging": "hanging_twips",
    "before": "before_twips",
    "after": "after_twips",
    "line": "line_twips",
    "lineRule": "line_rule",
    "keepNext": "keep_next",
    "keepLines": "keep_lines",
    "widowControl": "widow_control",
    "pageBreakBefore": "page_break_before",
}


def _wire_to_ooxml_props(wire_kwargs: dict[str, object]) -> dict[str, object]:
    """Re-key SuperDoc wire kwargs into OOXML-rewrite kwargs."""
    return {
        _WIRE_TO_OOXML_PROP_NAMES.get(k, k): v for k, v in wire_kwargs.items()
    }


class ParagraphFormat:
    """Paragraph-level formatting. Accessed via ``paragraph.paragraph_format``."""

    def __init__(self, paragraph: "Paragraph") -> None:
        self._paragraph: "Paragraph" = paragraph

    # ---- Helpers ----
    def _target(self) -> dict:
        return self._paragraph._block_target()

    def _guard_cell(self, op: str, **wire_kwargs: object) -> bool:
        """Short-circuit a setter if the paragraph is inside a table cell.

        Returns ``True`` when the caller should bail (paragraph is
        cell-inner; a warning was emitted). The format command would
        otherwise be queued and then cascade-fail the whole batch on
        the next flush.

        When ``wire_kwargs`` are passed (the SuperDoc wire shape — e.g.
        ``left=720``, ``lineRule="auto"``), they're mapped to the
        OOXML-shaped post-export rewrite vocabulary and stashed on the
        session's ``_post_export_ops``. ``Document.export_docx`` applies
        the stash against the bytes returned by docx-studio, so the
        exported ``.docx`` carries the formatting even though the wire
        op never lands on the live Y.Doc.
        """
        ooxml_props = _wire_to_ooxml_props(wire_kwargs)
        return self._paragraph._check_cell_inner(
            f"paragraph_format.{op}",
            **ooxml_props,
        )

    def _set_indent(self, _op: str, **kwargs: int) -> None:
        if self._guard_cell(_op, **kwargs):
            return
        run_sync(
            self._paragraph._session.doc.format.paragraph.set_indentation(
                {"target": self._target(), **kwargs},
            ),
        )

    def _clear_indent(self, _op: str) -> None:
        if self._guard_cell(_op):
            return
        run_sync(
            self._paragraph._session.doc.format.paragraph.clear_indentation(
                {"target": self._target()},
            ),
        )

    def _set_spacing(self, _op: str, **kwargs: object) -> None:
        if self._guard_cell(_op, **kwargs):
            return
        run_sync(
            self._paragraph._session.doc.format.paragraph.set_spacing(
                {"target": self._target(), **kwargs},
            ),
        )

    def _clear_spacing(self, _op: str) -> None:
        if self._guard_cell(_op):
            return
        run_sync(
            self._paragraph._session.doc.format.paragraph.clear_spacing(
                {"target": self._target()},
            ),
        )

    def _set_keep(self, _op: str, **kwargs: bool) -> None:
        if self._guard_cell(_op, **kwargs):
            return
        run_sync(
            self._paragraph._session.doc.format.paragraph.set_keep_options(
                {"target": self._target(), **kwargs},
            ),
        )

    def _set_flow_options(self, _op: str, **kwargs: object) -> None:
        if self._guard_cell(_op, **kwargs):
            return
        run_sync(
            self._paragraph._session.doc.format.paragraph.set_flow_options(
                {"target": self._target(), **kwargs},
            ),
        )

    def _read_node_attrs(self) -> dict:
        info: object = run_sync(
            self._paragraph._session.doc.get_node_by_id(
                {"id": self._paragraph._node_id},
            ),
        )
        if not isinstance(info, dict):
            return {}
        node: object = info.get("node")
        if not isinstance(node, dict):
            return {}
        block: object = node.get("paragraph") or node.get("heading") or node
        if isinstance(block, dict):
            attrs: object = block.get("attrs")
            if isinstance(attrs, dict):
                return attrs
            # Top-level fields on the block
            return block
        return {}

    # ---- alignment (mirrors Paragraph.alignment) ----
    @property
    def alignment(self) -> "WD_ALIGN_PARAGRAPH | None":
        return self._paragraph.alignment

    @alignment.setter
    def alignment(self, value: "WD_ALIGN_PARAGRAPH | str | None") -> None:
        self._paragraph.alignment = value

    # ---- indents ----
    @property
    def left_indent(self) -> "Length | None":
        attrs: dict = self._read_node_attrs()
        indent: object = attrs.get("indent") or attrs.get("indentation")
        if isinstance(indent, dict):
            v: object = indent.get("left")
            if isinstance(v, (int, float)):
                return Twips(float(v))
        return None

    @left_indent.setter
    def left_indent(self, value: "Length | int | None") -> None:
        if value is None:
            self._clear_indent("left_indent")
            return
        self._set_indent("left_indent", left=_to_twips(value))

    @property
    def right_indent(self) -> "Length | None":
        attrs: dict = self._read_node_attrs()
        indent: object = attrs.get("indent") or attrs.get("indentation")
        if isinstance(indent, dict):
            v: object = indent.get("right")
            if isinstance(v, (int, float)):
                return Twips(float(v))
        return None

    @right_indent.setter
    def right_indent(self, value: "Length | int | None") -> None:
        if value is None:
            self._clear_indent("right_indent")
            return
        self._set_indent("right_indent", right=_to_twips(value))

    @property
    def first_line_indent(self) -> "Length | None":
        attrs: dict = self._read_node_attrs()
        indent: object = attrs.get("indent") or attrs.get("indentation")
        if isinstance(indent, dict):
            first: object = indent.get("firstLine")
            hanging: object = indent.get("hanging")
            if isinstance(first, (int, float)) and float(first) > 0:
                return Twips(float(first))
            if isinstance(hanging, (int, float)) and float(hanging) > 0:
                return Twips(-float(hanging))
        return None

    @first_line_indent.setter
    def first_line_indent(self, value: "Length | int | None") -> None:
        if value is None:
            self._clear_indent("first_line_indent")
            return
        twips: int = _to_twips(value)
        if twips >= 0:
            self._set_indent("first_line_indent", firstLine=twips)
        else:
            self._set_indent("first_line_indent", hanging=-twips)

    # ---- spacing ----
    @property
    def space_before(self) -> "Length | None":
        attrs: dict = self._read_node_attrs()
        sp: object = attrs.get("spacing")
        if isinstance(sp, dict):
            v: object = sp.get("before")
            if isinstance(v, (int, float)):
                return Twips(float(v))
        return None

    @space_before.setter
    def space_before(self, value: "Length | int | None") -> None:
        if value is None:
            self._clear_spacing("space_before")
            return
        self._set_spacing("space_before", before=_to_twips(value))

    @property
    def space_after(self) -> "Length | None":
        attrs: dict = self._read_node_attrs()
        sp: object = attrs.get("spacing")
        if isinstance(sp, dict):
            v: object = sp.get("after")
            if isinstance(v, (int, float)):
                return Twips(float(v))
        return None

    @space_after.setter
    def space_after(self, value: "Length | int | None") -> None:
        if value is None:
            self._clear_spacing("space_after")
            return
        self._set_spacing("space_after", after=_to_twips(value))

    @property
    def line_spacing(self) -> "float | Length | None":
        attrs: dict = self._read_node_attrs()
        sp: object = attrs.get("spacing")
        if isinstance(sp, dict):
            line: object = sp.get("line")
            rule: object = sp.get("lineRule")
            if isinstance(line, (int, float)):
                # "auto" rule encodes multiple-of-single as 240 twips = 1.0
                if rule == "auto":
                    return float(line) / 240.0
                return Twips(float(line))
        return None

    @line_spacing.setter
    def line_spacing(self, value: "float | Length | int | None") -> None:
        if value is None:
            self._clear_spacing("line_spacing")
            return
        # ``bool`` is a subclass of ``int`` in Python, so ``True``/``False``
        # would otherwise silently hit the ``1 <= value <= 4`` branch
        # (1× multiplier) or the EMU fallthrough (0). Reject upfront —
        # python-docx 1.x raises ``TypeError`` for non-Length/numeric.
        if isinstance(value, bool):
            raise TypeError(
                f"line_spacing requires float/int/Length, not bool; "
                f"got {value!r}. Pass 1.0 / 1.5 / 2.0 for "
                f"single/1.5×/double, or a Length for exact spacing.",
            )
        if isinstance(value, Length):
            self._set_spacing("line_spacing", line=value.twips, lineRule="exact")
            return
        if isinstance(value, float):
            # Float multiplier — Single=1.0, 1.5=1.5, Double=2.0
            self._set_spacing("line_spacing", line=int(round(value * 240)), lineRule="auto")
            return
        if isinstance(value, int):
            # Bare int with a range around 1-4 is interpreted as multiplier,
            # larger ints are treated as EMU (python-docx convention).
            if 1 <= value <= 4:
                self._set_spacing("line_spacing", line=value * 240, lineRule="auto")
            else:
                self._set_spacing("line_spacing", line=_to_twips(value), lineRule="exact")
            return
        raise TypeError(f"line_spacing: unsupported type {type(value).__name__}")

    @property
    def line_spacing_rule(self) -> "WD_LINE_SPACING | None":
        from docx.enum.text import WD_LINE_SPACING

        attrs: dict = self._read_node_attrs()
        sp: object = attrs.get("spacing")
        if isinstance(sp, dict):
            rule: object = sp.get("lineRule")
            line: object = sp.get("line")
            if rule == "auto" and isinstance(line, (int, float)):
                if abs(float(line) - 240) < 1:
                    return WD_LINE_SPACING.SINGLE
                if abs(float(line) - 360) < 1:
                    return WD_LINE_SPACING.ONE_POINT_FIVE
                if abs(float(line) - 480) < 1:
                    return WD_LINE_SPACING.DOUBLE
                return WD_LINE_SPACING.MULTIPLE
            if rule == "exact":
                return WD_LINE_SPACING.EXACTLY
            if rule == "atLeast":
                return WD_LINE_SPACING.AT_LEAST
        return None

    @line_spacing_rule.setter
    def line_spacing_rule(self, value: "WD_LINE_SPACING | None") -> None:
        from docx.enum.text import WD_LINE_SPACING

        if value is None:
            self._clear_spacing("line_spacing_rule")
            return
        if not isinstance(value, WD_LINE_SPACING):
            raise ValueError(
                f"line_spacing_rule: expected WD_LINE_SPACING, got "
                f"{type(value).__name__} {value!r}",
            )
        if value == WD_LINE_SPACING.SINGLE:
            self._set_spacing("line_spacing_rule", line=240, lineRule="auto")
        elif value == WD_LINE_SPACING.ONE_POINT_FIVE:
            self._set_spacing("line_spacing_rule", line=360, lineRule="auto")
        elif value == WD_LINE_SPACING.DOUBLE:
            self._set_spacing("line_spacing_rule", line=480, lineRule="auto")
        elif value == WD_LINE_SPACING.EXACTLY:
            self._set_spacing("line_spacing_rule", line=240, lineRule="exact")
        elif value == WD_LINE_SPACING.AT_LEAST:
            self._set_spacing("line_spacing_rule", line=240, lineRule="atLeast")
        elif value == WD_LINE_SPACING.MULTIPLE:
            # MULTIPLE without an explicit numeric value is meaningless;
            # python-docx 1.x raises ``ValueError`` for the same reason.
            raise ValueError(
                "line_spacing_rule = WD_LINE_SPACING.MULTIPLE is not "
                "settable on its own — set line_spacing to a float "
                "multiplier (e.g. 1.5) instead, which implicitly uses "
                "the MULTIPLE rule via lineRule='auto'.",
            )
        else:
            # Defensive: any new enum member we haven't mapped to a wire
            # primitive should surface as ValueError, not silently no-op.
            raise ValueError(
                f"line_spacing_rule: unsupported WD_LINE_SPACING "
                f"member {value!r} — no wire mapping in athena-python-docx.",
            )

    # ---- keep / widow ----
    @property
    def keep_together(self) -> bool | None:
        attrs: dict = self._read_node_attrs()
        v: object = attrs.get("keepLines")
        return bool(v) if isinstance(v, bool) else None

    @keep_together.setter
    def keep_together(self, value: bool | None) -> None:
        if value is None:
            _warn_parfmt_clear("keep_together")
            return
        self._set_keep("keep_together", keepLines=_require_bool("keep_together", value))

    @property
    def keep_with_next(self) -> bool | None:
        attrs: dict = self._read_node_attrs()
        v: object = attrs.get("keepNext")
        return bool(v) if isinstance(v, bool) else None

    @keep_with_next.setter
    def keep_with_next(self, value: bool | None) -> None:
        if value is None:
            _warn_parfmt_clear("keep_with_next")
            return
        self._set_keep("keep_with_next", keepNext=_require_bool("keep_with_next", value))

    @property
    def widow_control(self) -> bool | None:
        attrs: dict = self._read_node_attrs()
        v: object = attrs.get("widowControl")
        return bool(v) if isinstance(v, bool) else None

    @widow_control.setter
    def widow_control(self, value: bool | None) -> None:
        if value is None:
            _warn_parfmt_clear("widow_control")
            return
        self._set_keep("widow_control", widowControl=_require_bool("widow_control", value))

    @property
    def page_break_before(self) -> bool | None:
        attrs: dict = self._read_node_attrs()
        v: object = attrs.get("pageBreakBefore")
        return bool(v) if isinstance(v, bool) else None

    @page_break_before.setter
    def page_break_before(self, value: bool | None) -> None:
        if value is None:
            _warn_parfmt_clear("page_break_before")
            return
        # Superdoc's setFlowOptions handles pageBreakBefore.
        # Reject non-bool to keep parity with python-docx 1.x's strict
        # ``_OnOff`` handling — ``bool(non_bool_value)`` silently coerces
        # garbage to True.
        coerced: bool = _require_bool("page_break_before", value)
        self._set_flow_options("page_break_before", pageBreakBefore=coerced)

    # ---- tab stops ----
    @property
    def tab_stops(self) -> "TabStops":
        from docx.text.tabstops import TabStops

        return TabStops(self)
