"""Tab stops — python-docx ``docx.text.tabstops`` parity.

A :class:`TabStops` collection lives at
``paragraph.paragraph_format.tab_stops`` and contains zero or more
:class:`TabStop` entries describing how Tab characters in the
paragraph should align relative to the page margins.

Athena persists these via Superdoc's
``doc.format.paragraph.{set_tab_stop,clear_all_tab_stops,get_tabs}``
operations. Positions round-trip in twips on the wire (Word's native
unit for tab offsets).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.enum.text import WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.shared import Length, Twips

if TYPE_CHECKING:
    from docx.text.parfmt import ParagraphFormat


def _coerce_alignment(value: object) -> str:
    """Coerce ``WD_TAB_ALIGNMENT`` or its string form to the SuperDoc
    wire value, rejecting anything else.

    Previously the setter / factory accepted ``str(value)`` for any
    input, shipping bogus alignment strings to the wire (SuperDoc
    silently fell back to ``left``). python-docx 1.x validates against
    the enum at the XML serialization layer.
    """
    if isinstance(value, WD_TAB_ALIGNMENT):
        return value.to_superdoc()
    if isinstance(value, str):
        try:
            return WD_TAB_ALIGNMENT(value).to_superdoc()
        except ValueError as e:
            raise ValueError(
                f"Tab stop alignment {value!r} is not a valid "
                f"WD_TAB_ALIGNMENT value. Expected one of "
                f"{[m.value for m in WD_TAB_ALIGNMENT]} or a "
                f"WD_TAB_ALIGNMENT enum member.",
            ) from e
    raise TypeError(
        f"Tab stop alignment must be WD_TAB_ALIGNMENT or str; "
        f"got {type(value).__name__} {value!r}",
    )


def _coerce_leader(value: object) -> str:
    """Coerce ``WD_TAB_LEADER`` or its string form to the SuperDoc
    wire value, rejecting anything else.

    Same rationale as :func:`_coerce_alignment` — the prior
    ``str(value)`` accept-anything path silently shipped bogus leader
    values that SuperDoc swallowed.
    """
    if isinstance(value, WD_TAB_LEADER):
        return value.to_superdoc()
    if isinstance(value, str):
        try:
            return WD_TAB_LEADER(value).to_superdoc()
        except ValueError as e:
            raise ValueError(
                f"Tab stop leader {value!r} is not a valid "
                f"WD_TAB_LEADER value. Expected one of "
                f"{[m.value for m in WD_TAB_LEADER]} or a "
                f"WD_TAB_LEADER enum member.",
            ) from e
    raise TypeError(
        f"Tab stop leader must be WD_TAB_LEADER or str; "
        f"got {type(value).__name__} {value!r}",
    )


class TabStop:
    """A single tab stop entry. Returned by :class:`TabStops` iteration
    and by :meth:`TabStops.add_tab_stop`.

    Athena materializes ``TabStop`` from the SuperDoc paragraph-format
    payload (a dict with ``position`` / ``alignment`` / ``leader``
    keys). Mutating an existing tab stop's ``position`` / ``alignment``
    / ``leader`` rewrites the parent paragraph's tab list — there is
    no per-stop wire op in SuperDoc.
    """

    def __init__(self, *, parent: "TabStops", data: dict) -> None:
        self._parent: "TabStops" = parent
        self._data: dict = dict(data)

    # ---- read ----
    @property
    def position(self) -> Length:
        pos = self._data.get("position", 0)
        if isinstance(pos, (int, float)):
            return Twips(int(pos))
        return Twips(0)

    @position.setter
    def position(self, value: "Length | int") -> None:
        self._data["position"] = _to_twips(value)
        self._parent._rewrite_from_data([s._data for s in self._parent._stops()])

    @property
    def alignment(self) -> "WD_TAB_ALIGNMENT":
        from docx.enum.text import WD_TAB_ALIGNMENT

        v = self._data.get("alignment", "left")
        try:
            return WD_TAB_ALIGNMENT(v) if isinstance(v, str) else v
        except ValueError:
            return WD_TAB_ALIGNMENT.LEFT

    @alignment.setter
    def alignment(self, value: "WD_TAB_ALIGNMENT | str") -> None:
        self._data["alignment"] = _coerce_alignment(value)
        self._parent._rewrite_from_data([s._data for s in self._parent._stops()])

    @property
    def leader(self) -> "WD_TAB_LEADER":
        from docx.enum.text import WD_TAB_LEADER

        v = self._data.get("leader", "none")
        try:
            return WD_TAB_LEADER(v) if isinstance(v, str) else v
        except ValueError:
            return WD_TAB_LEADER.SPACES

    @leader.setter
    def leader(self, value: "WD_TAB_LEADER | str") -> None:
        self._data["leader"] = _coerce_leader(value)
        self._parent._rewrite_from_data([s._data for s in self._parent._stops()])


class TabStops:
    """Sequence-like collection of :class:`TabStop`.

    python-docx exposes this as ``paragraph.paragraph_format.tab_stops``.
    Iteration yields ``TabStop`` instances in left-to-right position
    order.
    """

    def __init__(self, parfmt: "ParagraphFormat") -> None:
        self._parfmt: "ParagraphFormat" = parfmt

    def _stops(self) -> list[TabStop]:
        """Read the live tab list off the parent paragraph node.

        SuperDoc 1.7 exposes tabs as a paragraph attribute
        (``tabStops: Array<{tab: {tabType, pos, leader}}>``) rather
        than via a dedicated ``getTabs`` op, so we read them out of
        the same ``getNodeById`` payload the rest of the parfmt code
        uses. Returns an empty list for paragraphs that don't have
        tabs declared (which is the common case).
        """
        para = self._parfmt._paragraph
        info: object = run_sync(
            para._session.doc.get_node_by_id({"id": para._node_id}),
        )
        attrs: dict = {}
        if isinstance(info, dict):
            node = info.get("node")
            if isinstance(node, dict):
                block = node.get("paragraph") or node.get("heading")
                if isinstance(block, dict):
                    a = block.get("attrs")
                    if isinstance(a, dict):
                        attrs = a
        raw_tabs = attrs.get("tabStops")
        items: list[dict] = []
        if isinstance(raw_tabs, list):
            for entry in raw_tabs:
                if not isinstance(entry, dict):
                    continue
                # SuperDoc nests the actual fields under `tab`; flatten so
                # TabStop.position/.alignment/.leader read through cleanly.
                tab = entry.get("tab", entry)
                if not isinstance(tab, dict):
                    continue
                items.append(
                    {
                        "position": tab.get("pos") or tab.get("position") or 0,
                        "alignment": tab.get("tabType") or tab.get("alignment") or "left",
                        "leader": tab.get("leader") or "none",
                    }
                )
        return [TabStop(parent=self, data=t) for t in items]

    def __iter__(self):
        return iter(self._stops())

    def __len__(self) -> int:
        return len(self._stops())

    def __getitem__(self, index: int) -> TabStop:
        return self._stops()[index]

    def __delitem__(self, index: int) -> None:
        stops = [s._data for s in self._stops()]
        del stops[index]
        self._rewrite_from_data(stops)

    def add_tab_stop(
        self,
        position: "Length | int",
        alignment: "WD_TAB_ALIGNMENT" = WD_TAB_ALIGNMENT.LEFT,
        leader: "WD_TAB_LEADER" = WD_TAB_LEADER.SPACES,
    ) -> TabStop:
        """Append a tab stop and return its :class:`TabStop` proxy.

        ``alignment`` defaults to ``WD_TAB_ALIGNMENT.LEFT``, ``leader``
        defaults to ``WD_TAB_LEADER.SPACES`` — matching python-docx.
        Bogus enum-equivalent strings now raise ``ValueError``; a
        non-enum/non-str input raises ``TypeError``. Previously any
        ``str(value)`` was shipped to the wire and SuperDoc silently
        fell back to defaults.
        """
        align_val: str = _coerce_alignment(alignment)
        leader_val: str = _coerce_leader(leader)
        pos_twips: int = _to_twips(position)
        run_sync(
            self._parfmt._paragraph._session.doc.format.paragraph.set_tab_stop(
                {
                    "target": self._parfmt._target(),
                    "position": pos_twips,
                    "alignment": align_val,
                    "leader": leader_val,
                },
            ),
        )
        return TabStop(
            parent=self,
            data={
                "position": pos_twips,
                "alignment": align_val,
                "leader": leader_val,
            },
        )

    def clear_all(self) -> None:
        run_sync(
            self._parfmt._paragraph._session.doc.format.paragraph.clear_all_tab_stops(
                {"target": self._parfmt._target()},
            ),
        )

    def _rewrite_from_data(self, items: list[dict]) -> None:
        """Replace the entire tab list with ``items``.

        Used by individual TabStop setters and ``__delitem__``. Goes
        through clear_all + set_tab_stop loop because SuperDoc has no
        bulk-replace primitive yet.
        """
        self.clear_all()
        for item in items:
            run_sync(
                self._parfmt._paragraph._session.doc.format.paragraph.set_tab_stop(
                    {
                        "target": self._parfmt._target(),
                        "position": item.get("position", 0),
                        "alignment": item.get("alignment", "left"),
                        "leader": item.get("leader", "none"),
                    },
                ),
            )


def _to_twips(value: object) -> int:
    if isinstance(value, Length):
        return value.twips
    if isinstance(value, (int, float)):
        return int(value)
    raise TypeError(f"position must be Length or int, got {type(value).__name__}")


__all__ = ["TabStop", "TabStops"]
