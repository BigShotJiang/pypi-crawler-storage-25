"""``RenderedPageBreak`` — python-docx ``docx.text.pagebreak`` parity.

A :class:`RenderedPageBreak` is the read-only proxy for a "rendered"
hard page break — the kind that appears mid-paragraph because Word's
layout engine flowed the paragraph across pages, OR because the user
inserted an explicit page break inside a run.

Upstream's class lives at ``docx.text.pagebreak.RenderedPageBreak`` and
is yielded by :meth:`Paragraph.iter_inner_content` between text runs
that span the page boundary. SuperDoc encodes the same break with a
form-feed (``\\f``) sentinel in the run text — :meth:`Run.contains_page_break`
detects this. :meth:`Paragraph.rendered_page_breaks` returns the list
of breaks inside a paragraph.

The ``preceding_paragraph_fragment`` / ``following_paragraph_fragment``
properties return *fragmentary* :class:`Paragraph` proxies on either
side of the break in upstream; SuperDoc's flat document model doesn't
yet preserve that fragmentation, so both return ``None``. Users who
just want to detect breaks via ``isinstance(item, RenderedPageBreak)``
get full parity; users who want to introspect either side of a break
should fall back to :attr:`preceding_paragraph_text`.
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from docx.text.paragraph import Paragraph


class PendingPageBreakFragmentWarning(UserWarning):
    """Emitted when ``RenderedPageBreak.preceding_paragraph_fragment``
    or ``.following_paragraph_fragment`` is accessed.

    SuperDoc's flat document model doesn't preserve per-break
    paragraph fragments — the run text contains a ``\\f`` sentinel
    but the pre/post-break halves aren't separate nodes. Both
    properties return ``None``. Tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 11.
    """


def _warn_pagebreak_fragment(prop: str) -> None:
    warnings.warn(
        f"RenderedPageBreak.{prop} returns None — SuperDoc's flat "
        f"model doesn't preserve mid-paragraph fragments. Use "
        f".preceding_paragraph_text or the parent paragraph for the "
        f"full text. Tracked in docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md § 11.",
        PendingPageBreakFragmentWarning,
        stacklevel=3,
    )


class RenderedPageBreak:
    """A hard page break inside a paragraph, as Word would render it.

    Constructed by :meth:`Paragraph.rendered_page_breaks` and yielded
    by :meth:`Paragraph.iter_inner_content`; not intended for direct
    user instantiation.
    """

    __slots__ = ("_paragraph", "_offset", "_preceding_text")

    def __init__(
        self,
        *,
        paragraph: "Paragraph",
        offset: int = 0,
        preceding_text: str = "",
    ) -> None:
        self._paragraph: "Paragraph" = paragraph
        self._offset: int = offset
        self._preceding_text: str = preceding_text

    # ---- python-docx canonical surface ----
    @property
    def preceding_paragraph_fragment(self) -> "Paragraph | None":
        """The portion of the paragraph that flowed onto the page
        *before* the break.

        SuperDoc's flat model doesn't preserve mid-paragraph fragments;
        returns ``None``. Use :attr:`preceding_paragraph_text` for the
        plain-text equivalent or the parent paragraph for full text.
        """
        _warn_pagebreak_fragment("preceding_paragraph_fragment")
        return None

    @property
    def following_paragraph_fragment(self) -> "Paragraph | None":
        """The portion of the paragraph that flowed onto the page
        *after* the break. See :attr:`preceding_paragraph_fragment`."""
        _warn_pagebreak_fragment("following_paragraph_fragment")
        return None

    # ---- athena-specific extensions (kept for compat) ----
    @property
    def offset(self) -> int:
        """Character offset of the page break inside the paragraph text.

        athena-specific; not present on the upstream class. Useful when
        manipulating SuperDoc's ``\\f`` sentinels directly.
        """
        return self._offset

    @property
    def preceding_paragraph_text(self) -> str:
        """Plain text content of the paragraph before the break.

        athena-specific. Upstream exposes
        :attr:`preceding_paragraph_fragment` (a Paragraph) instead;
        SuperDoc can't yet materialize that fragment, so the plain
        text is the closest practical substitute.
        """
        return self._preceding_text

    def __repr__(self) -> str:
        return f"<RenderedPageBreak offset={self._offset}>"


__all__ = ["PendingPageBreakFragmentWarning", "RenderedPageBreak"]
