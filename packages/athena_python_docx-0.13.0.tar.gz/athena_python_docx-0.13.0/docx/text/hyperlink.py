"""Hyperlink — python-docx docx.text.hyperlink.Hyperlink parity.

Exposed via `Paragraph.hyperlinks`. Wraps one or more consecutive runs
that share a hyperlink target. SuperDoc 1.8.x models hyperlinks as a
mark on each run rather than a wrapper around a run sequence — we
coalesce same-target consecutive runs client-side so multi-run
hyperlinks (e.g. mixed bold/non-bold spans pointing at one URL) round
trip as a single :class:`Hyperlink` carrying multiple :class:`Run`
children, matching python-docx 1.x semantics.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from docx.text.paragraph import Paragraph


class Hyperlink:
    def __init__(
        self,
        *,
        paragraph: "Paragraph",
        target: str,
        run: dict | None = None,
        range_: tuple[int, int] | None = None,
        segments: list[tuple[dict, tuple[int, int]]] | None = None,
    ) -> None:
        """Construct a Hyperlink proxy.

        Two construction modes:

        * Single-run (legacy): pass ``run=<dict>`` + ``range_=(start,end)``.
          The constructor synthesizes a one-element ``_segments`` list so
          downstream code uniformly walks segments.
        * Multi-run (coalesced): pass ``segments=[(run_dict, (start,end)), ...]``.
          ``run`` / ``range_`` are derived from the first segment for
          backwards-compat callers that still read those attributes.

        The two modes are mutually exclusive in practice; if ``segments``
        is provided it wins.
        """
        self._paragraph: "Paragraph" = paragraph
        self._target: str = target

        if segments is not None and len(segments) > 0:
            self._segments: list[tuple[dict, tuple[int, int]]] = list(segments)
        elif run is not None and range_ is not None:
            self._segments = [(run, range_)]
        else:
            self._segments = []

        # Single-run accessors (`_run`, `_range`) preserved so callers
        # that read them keep working. They reflect the FIRST segment in
        # the multi-run case.
        if self._segments:
            self._run: dict | None = self._segments[0][0]
            self._range: tuple[int, int] | None = self._segments[0][1]
        else:
            self._run = run
            self._range = range_

    @property
    def address(self) -> str:
        """The hyperlink address — the URL portion **without** the
        fragment (the part after ``#``).

        Mirrors python-docx 1.x: for ``"https://x.com/path#section1"``
        the address is ``"https://x.com/path"``. Internal "jump"
        hyperlinks (e.g. from a TOC pointing at an in-document
        bookmark) carry an empty address; the bookmark name lives in
        :attr:`fragment` instead.
        """
        from urllib.parse import urlparse, urlunparse

        try:
            parsed = urlparse(self._target)
        except (ValueError, TypeError):
            return self._target
        if not parsed.fragment:
            return self._target
        # Strip fragment, rebuild.
        return urlunparse(parsed._replace(fragment=""))

    @property
    def url(self) -> str:
        """The full hyperlink URL — ``address`` joined with ``fragment``
        via ``#`` when both are present.

        Mirrors python-docx 1.x. Empty string when there is no
        address portion (so its boolean value distinguishes external
        URLs from internal jumps).
        """
        address = self.address
        fragment = self.fragment
        if not address:
            return f"#{fragment}" if fragment else ""
        return f"{address}#{fragment}" if fragment else address

    @property
    def fragment(self) -> str:
        """Reference like `#glossary` at end of URL. Does NOT include
        the fragment-separator character ('#').

        Mirrors python-docx 1.x. For SuperDoc-stored URLs the fragment
        lives in the URL string itself rather than a separate XML
        attribute; we parse it out via urllib.parse.
        """
        from urllib.parse import urlparse
        try:
            return urlparse(self._target).fragment or ""
        except (ValueError, TypeError):
            return ""

    @property
    def text(self) -> str:
        """Concatenated text of all runs inside this hyperlink wrapper.

        Mirrors python-docx 1.x: a hyperlink's ``text`` is the visible
        anchor text, which for a multi-run hyperlink is the
        concatenation of every child run's text.
        """
        parts: list[str] = []
        for run_data, _ in self._segments:
            t = run_data.get("text")
            if isinstance(t, str):
                parts.append(t)
        return "".join(parts)

    @property
    def runs(self) -> list:
        """List of :class:`Run` instances inside this hyperlink wrapper.

        SuperDoc models hyperlinks as a mark on each run, so the SDK
        coalesces consecutive same-target runs at enumeration time
        (in :attr:`docx.text.paragraph.Paragraph.hyperlinks`). The
        coalesced segments live on ``self._segments`` and materialize
        one :class:`Run` per segment here.
        """
        from docx.text.run import Run

        if not self._segments:
            return []
        return [
            Run(
                session=self._paragraph._session,
                block_id=self._paragraph._node_id,
                range_=segment_range,
                inline=segment_run,
            )
            for segment_run, segment_range in self._segments
        ]

    @property
    def contains_page_break(self) -> bool:
        """True when the text of this hyperlink contains a hard page break.

        Mirrors python-docx 1.x. Detection uses SuperDoc's ``\\f`` form-
        feed sentinel inside any wrapped run's text (matching
        ``Run.contains_page_break`` / ``Paragraph.contains_page_break``).
        """
        for run_data, _ in self._segments:
            text = run_data.get("text", "")
            if isinstance(text, str) and "\f" in text:
                return True
        return False
