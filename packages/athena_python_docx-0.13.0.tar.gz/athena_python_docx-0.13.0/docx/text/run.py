"""Run and Font — mirrors python-docx's run.Run and text.font.Font."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, BinaryIO

from docx._athena_extension import athena_extension
from docx._batching import run_sync
from docx.enum.text import WD_BREAK
from docx.shared import Length, Pt, RGBColor  # noqa: F401


class PendingBreakDegradationWarning(UserWarning):
    """Emitted when ``Run.add_break`` is called with a break type that
    SuperDoc has no dedicated wire op for (``COLUMN``,
    ``LINE_CLEAR_*``). The break is recorded as a regular line break
    so the document still saves cleanly, but Word fidelity is lossy.
    Tracked as upstream-blocked in ``PYTHON_DOCX_PARITY_GAPS.md``.
    """


class PendingColorTypeWarning(UserWarning):
    """Emitted when ``Font.color.type`` is accessed.

    SuperDoc inline runs only carry an explicit hex ``color``;
    there's no metadata distinguishing RGB / theme / auto. Returns
    ``None``. Tracked in ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 10.
    """


if TYPE_CHECKING:
    from docx.client import Session
    from docx.fields import Field
    from docx.footnotes import Endnote, Footnote
    from docx.math import MathEquation
    from docx.shape import InlineShape
    from docx.text.hyperlink import Hyperlink


def _block_text(session: "Session", block_id: str) -> str:
    from docx.text.paragraph import _node_text

    return _node_text(session, block_id)


def _build_inline_shape_info(
    create_response: object, *, width: float, height: float
) -> dict:
    """Synthesize an :class:`InlineShape` info dict from a
    ``doc.create.image`` response, falling back to the requested size
    when the response is opaque.

    ``InlineShape`` reads ``nodeId`` (or ``id``) and ``size`` from its
    info dict; older transports return only an ack rather than the new
    node, in which case we record the request-side size so callers can
    still inspect ``shape.width`` / ``.height`` immediately.
    """
    info: dict = {"size": {"width": width, "height": height}}
    if isinstance(create_response, dict):
        nid: object = (
            create_response.get("nodeId")
            or create_response.get("id")
            or create_response.get("node", {}).get("nodeId")
            if isinstance(create_response.get("node"), dict)
            else None
        )
        if nid:
            info["nodeId"] = str(nid)
        size: object = create_response.get("size")
        if isinstance(size, dict):
            info["size"] = size
    return info


class Run:
    """A text run — a contiguous span with uniform formatting."""

    def __init__(
        self,
        *,
        session: "Session",
        block_id: str,
        range_: tuple[int, int],
        inline: dict | None = None,
        paragraph: "object | None" = None,
        in_cell: bool = False,
        cell_ooxml_address: "tuple[int, int, int, int] | None" = None,
    ) -> None:
        self._session: "Session" = session
        self._block_id: str = block_id
        self._range: tuple[int, int] = range_
        # Snapshot of inline marks at construction time (if available).
        self._inline_snapshot: dict = inline or {}
        # Inline formatting set on the run while its text range is still
        # collapsed (empty). SuperDoc's ``format.apply`` rejects a
        # collapsed target with ``"format.apply requires a non-collapsed
        # target range."`` — and a wire-side FormatApply on an empty
        # range has no visible effect anyway. We stash the attrs here
        # and flush them on the next text mutation that gives the run
        # a non-empty range (``.text``, ``add_text``, ``add_tab``,
        # ``add_break``). Mirrors python-docx semantics where setting
        # bold on an empty run records it on ``<w:rPr>`` and the next
        # text added picks it up.
        self._pending_inline: dict = {}
        # Optional back-reference to the owning Paragraph proxy. Set
        # when the run is constructed during a write path
        # (``Paragraph.add_run``, ``Run.add_text``) so this run can
        # keep the paragraph's ``_text_len`` cache in sync when it
        # mutates the paragraph's text-address space. ``None`` for
        # read-only runs returned by ``paragraph.runs`` — those don't
        # carry the back-ref so we don't accidentally update an
        # unrelated proxy.
        self._paragraph: object | None = paragraph
        # True for runs whose parent paragraph is cell-inner. SuperDoc
        # 1.8.1 rejects ``doc.insert`` / ``doc.format.apply`` ops whose
        # target.blockId resolves to a paragraph nested inside a
        # ``tableCell`` — the cascade pattern that takes down the whole
        # batch with ``applied: []``. Run text-mutating and
        # format-applying methods short-circuit when this flag is set;
        # see :meth:`_check_cell_inner`.
        self._in_cell: bool = in_cell
        # OOXML positional address of the parent paragraph when
        # ``in_cell`` is True. ``(table_doc_index, row, col, para_idx)``.
        # Drives the post-export OOXML rewrite path that applies
        # cell-inner run-format ops (bold / italic / size / color /
        # font name / highlight / strike / rStyle) at
        # ``Document.export_docx`` time. Set by ``Paragraph.runs`` and
        # ``Paragraph.add_run`` when the parent paragraph itself
        # carries an address; defaults to ``None`` when the parent is
        # a non-cell paragraph (no stash needed; wire path always
        # works) OR when the parent is a cell paragraph whose origin
        # is a SuperDoc round-trip rather than ``Document.add_table``
        # (no stable OOXML address, same caveat as the cell-paragraph
        # format stash — see ``_postproc.PostExportOps``).
        self._cell_ooxml_address: tuple[int, int, int, int] | None = (
            cell_ooxml_address
        )

    def _check_cell_inner(self, op: str) -> bool:
        """Return ``True`` if this run is inside a cell-inner paragraph
        and the caller should short-circuit the wire op rather than
        ship a command SuperDoc will reject.

        For text-mutating ops (``Run.text``, ``add_text``, ``add_tab``,
        ``add_break``) this still warns-and-skips — there's no
        post-export rescue path for inserting new text into a
        cell-inner range (the agent's intent is "add this text" but
        with no live cell-inner ``doc.insert`` target, we can't
        materialize it client-side).

        For format-applying ops (``bold``, ``italic``, ``font.size``,
        ``font.color``, etc.) the caller should use
        :meth:`_stash_cell_inner_run_format` instead — those have a
        post-export rescue path via the OOXML rewrite in
        :mod:`docx._postproc`. This method continues to handle the
        warn-and-skip side; format setters check it AFTER stashing
        so the warning still fires for visibility.

        Defensive: tests sometimes build a ``Run`` via ``__new__``
        (bypassing ``__init__``) — those don't have ``_in_cell`` set,
        so ``getattr`` with a ``False`` default keeps them flowing
        through the live wire path.
        """
        if not getattr(self, "_in_cell", False):
            return False
        from docx.text.paragraph import (  # local import: avoid cycle
            CellInnerFormatNotSupportedWarning,
        )
        import warnings

        warnings.warn(
            f"Run.{op} on a cell-inner paragraph: SuperDoc 1.8.1 "
            f"rejects ``doc.insert`` / ``doc.format.apply`` ops whose "
            f"target.blockId resolves to a paragraph nested inside a "
            f"tableCell. The op was skipped at the wire layer to keep "
            f"the surrounding batch from being rejected. "
            f"Workaround: use ``cell.text = '...'`` for plain cell "
            f"content, or ``cell.add_paragraph(text, style='Heading X')`` "
            f"for paragraph-level styled content. Run-level formatting "
            f"(bold, font.size, font.color, font.name, highlight, "
            f"rStyle, strike, underline) IS preserved in the exported "
            f"``.docx`` via post-export OOXML rewrite as of athena-"
            f"python-docx 0.13.0 for tables created via "
            f"``Document.add_table`` (the live Olympus rendering still "
            f"doesn't reflect it). Tracked at "
            f"docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md § 13.",
            CellInnerFormatNotSupportedWarning,
            stacklevel=3,
        )
        return True

    _FORMAT_KEY_TO_POSTPROC: dict[str, str] = {  # type: ignore[misc]
        # _apply_inline kwargs → CellRunFormat post-proc keys (see
        # docx/_postproc.py :meth:`PostExportOps.add_cell_run_format`).
        "bold": "bold",
        "italic": "italic",
        "strike": "strike",
        "underline": "underline",
        "fontFamily": "font_name",
        "fontSize": "font_size_pt",
        "color": "font_color_hex",
        "highlight": "font_highlight",
        "rStyle": "r_style",
    }

    def _stash_cell_inner_run_format(self, kwargs: dict) -> None:
        """Convert ``_apply_inline`` kwargs into the post-export
        OOXML-rewrite schema and stash them on the session's
        ``PostExportOps``.

        Only fires when ``self._in_cell`` AND
        ``self._cell_ooxml_address`` is set; otherwise it's a no-op
        (caller falls back to the warn-and-skip path). Cell-inner runs
        whose parent paragraph has no stable OOXML address (typically
        cells in tables loaded from a SuperDoc round-trip, where
        ``_doc_index`` rotation tracking isn't available) silently
        skip stashing — same caveat as the cell-paragraph format
        stash path.
        """
        addr = getattr(self, "_cell_ooxml_address", None)
        if addr is None:
            return
        ops = getattr(self._session, "_post_export_ops", None)
        if ops is None:
            return
        from docx._postproc import CellAddress

        post_props: dict[str, object] = {}
        for in_key, value in kwargs.items():
            post_key = type(self)._FORMAT_KEY_TO_POSTPROC.get(in_key)
            if post_key is None:
                # Unsupported in the post-export schema (vertAlign,
                # rare attrs). Quietly skip rather than emit a
                # warning — the agent already saw the
                # CellInnerFormatNotSupportedWarning from
                # ``_check_cell_inner``.
                continue
            post_props[post_key] = value
        if not post_props:
            return
        tbl_idx, row, col, para_idx = addr
        ops.add_cell_run_format(
            CellAddress(
                table_doc_index=tbl_idx,
                row=row,
                col=col,
                paragraph_index=para_idx,
            ),
            **post_props,
        )

    def __getattr__(self, name: str) -> Any:
        """Intercept ``_r`` / ``_element`` / ``part`` access with a
        typed :class:`docx.oxml.OxmlNotAvailableError` that points at
        the high-level API. Default ``AttributeError`` for everything
        else.
        """
        from docx.oxml import guard_xml_attr

        guard_xml_attr("Run", name)
        raise AttributeError(f"'Run' object has no attribute {name!r}")

    def _note_paragraph_len_delta(self, delta: int) -> None:
        """Update the parent paragraph's text-length cache by ``delta``.

        Best-effort: silently no-op if there's no back-reference or
        the parent has invalidated its cache. Run mutations that change
        the paragraph's text-address length call this so the next
        ``add_run`` on the same paragraph can skip the
        ``get_node_by_id`` round-trip.

        Defensive against tests that build a ``Run`` via ``__new__``
        (skipping ``__init__``) — those don't have ``_paragraph`` set,
        so we read via ``getattr`` rather than direct attribute access.
        """
        para = getattr(self, "_paragraph", None)
        if para is None:
            return
        current = getattr(para, "_text_len", None)
        if current is None:
            return
        # mypy: we intentionally write through to a Paragraph attribute
        para._text_len = current + delta  # type: ignore[attr-defined]

    @property
    def _text_range(self) -> dict:
        return {
            "kind": "text",
            "blockId": self._block_id,
            "range": {"start": self._range[0], "end": self._range[1]},
        }

    @property
    def _is_collapsed_range(self) -> bool:
        return self._range[0] == self._range[1]

    def _flush_pending_inline(self) -> None:
        """Apply any inline formatting stashed while the run was empty.

        Called from text-mutation paths that expand the run's range
        (``text`` setter, ``add_text``, ``add_tab``, ``add_break``).
        Safe to call when there's nothing pending — no-op.

        Defensive against tests that build a ``Run`` via ``__new__``
        (skipping ``__init__``) — those don't have ``_pending_inline``
        set, so we ``getattr`` it.
        """
        pending = getattr(self, "_pending_inline", None)
        if not pending or self._is_collapsed_range:
            return
        self._pending_inline = {}
        run_sync(
            self._session.doc.format.apply(
                {"target": self._text_range, "inline": pending},
            ),
        )

    # ---- text ----
    @property
    def text(self) -> str:
        full: str = _block_text(self._session, self._block_id)
        return full[self._range[0] : self._range[1]]

    def iter_inner_content(self):
        """Yield each inline content item in document order.

        python-docx 1.x signature: ``Iterator[str | Drawing | RenderedPageBreak]``.

        Mirrors upstream behavior: contiguous text segments are yielded
        as a single ``str``, and rendered page breaks are yielded as
        :class:`docx.text.pagebreak.RenderedPageBreak` instances so
        ``isinstance(item, RenderedPageBreak)`` matches the way
        upstream callers expect. ``Drawing`` items are not yielded —
        we don't surface per-run inline drawings yet; that surface is
        tracked in ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md``.
        """
        from docx.text.pagebreak import RenderedPageBreak

        text = self.text
        # Fast path — no page breaks, yield the whole run as one string.
        if "\f" not in text:
            if text:
                yield text
            return
        # Split on hard page-break sentinel; yield text segments and
        # RenderedPageBreak proxies between them. The proxy carries the
        # parent paragraph plus the offset of the break inside the
        # paragraph's text-address space, so callers can introspect
        # which break this corresponds to via
        # ``Paragraph.rendered_page_breaks``.
        from docx.text.paragraph import Paragraph

        parent_para = Paragraph(session=self._session, node_id=self._block_id)
        # `run_start` is the run's left edge inside the paragraph;
        # break_offset = run_start + chars-so-far-into-the-run.
        run_start = self._range[0]
        consumed = 0
        parts = text.split("\f")
        for i, part in enumerate(parts):
            if part:
                yield part
                consumed += len(part)
            if i < len(parts) - 1:
                yield RenderedPageBreak(
                    paragraph=parent_para,
                    offset=run_start + consumed,
                    preceding_text="".join(parts[: i + 1]),
                )
                consumed += 1  # account for the \f itself

    @text.setter
    def text(self, value: str) -> None:
        # python-docx 1.x routes Run.text through lxml's
        # ``_element_text.text = value`` which TypeErrors on non-str.
        # Was: any value (int, None, list) shipped to wire via
        # ``replace({text: value})``; SuperDoc's permissive parser
        # silently coerced or rejected. Reject at the call site.
        if not isinstance(value, str):
            raise TypeError(
                f"Run.text requires str; got {type(value).__name__} "
                f"{value!r}",
            )
        if self._check_cell_inner("text"):
            return
        old_len: int = self._range[1] - self._range[0]
        run_sync(
            self._session.doc.replace(
                {"target": self._text_range, "text": value},
            ),
        )
        new_end: int = self._range[0] + len(value)
        self._range = (self._range[0], new_end)
        self._note_paragraph_len_delta(len(value) - old_len)
        # Range may have expanded from collapsed → non-collapsed; flush
        # any pending inline formatting now that there's text to mark.
        self._flush_pending_inline()

    def add_text(self, text: str) -> "Run":
        """python-docx: append text to the run. Returns a new Run for the added text."""
        if not isinstance(text, str):
            raise TypeError(
                f"Run.add_text requires str; got {type(text).__name__} "
                f"{text!r}",
            )
        if self._check_cell_inner("add_text"):
            # Return a stub Run with the same in_cell flag so chained
            # ops on the result also short-circuit cleanly.
            return Run(
                session=self._session,
                block_id=self._block_id,
                range_=(self._range[1], self._range[1]),
                paragraph=self._paragraph,
                in_cell=True,
            )
        end: int = self._range[1]
        cursor: dict = {"kind": "text", "blockId": self._block_id, "offset": end}
        run_sync(
            self._session.doc.insert(
                {
                    "target": {"kind": "selection", "start": cursor, "end": cursor},
                    "value": text,
                    "type": "text",
                },
            ),
        )
        new_range = (end, end + len(text))
        self._range = (self._range[0], end + len(text))
        self._note_paragraph_len_delta(len(text))
        # Range may have expanded from collapsed → non-collapsed; flush
        # any pending inline formatting now that there's text to mark.
        self._flush_pending_inline()
        return Run(
            session=self._session,
            block_id=self._block_id,
            range_=new_range,
            paragraph=self._paragraph,
            in_cell=self._in_cell,
        )

    @property
    def contains_page_break(self) -> bool:
        """python-docx 1.x: True if the run contains a hard page break.

        A run contains a page break iff its text segment includes the
        Form Feed sentinel ``\\f`` — that's how SuperDoc marks a hard
        page break inside an inline run, mirroring Word's `<w:br
        w:type="page"/>`.
        """
        return "\f" in self.text

    def add_tab(self) -> None:
        """Insert a tab character at the end of the run."""
        if self._check_cell_inner("add_tab"):
            return
        end: int = self._range[1]
        run_sync(
            self._session.doc.insert_tab({"blockId": self._block_id, "offset": end}),
        )
        self._range = (self._range[0], end + 1)
        self._note_paragraph_len_delta(1)
        # Range may have expanded from collapsed → non-collapsed; flush
        # any pending inline formatting now that there's text to mark.
        self._flush_pending_inline()

    def add_break(self, break_type: "WD_BREAK" = WD_BREAK.LINE) -> None:
        """Insert a break at the end of the run.

        python-docx inserts a real Word break element that does not appear
        in the paragraph's `.text` output. We mirror that by routing through
        Superdoc primitives:

        - ``PAGE`` and ``SECTION_NEXT_PAGE`` → ``doc.create.sectionBreak``
          (``breakType='nextPage'``)
        - ``SECTION_CONTINUOUS`` / ``SECTION_EVEN_PAGE`` /
          ``SECTION_ODD_PAGE`` → ``doc.create.sectionBreak`` with the
          matching ``breakType``
        - ``LINE`` and ``TEXT_WRAPPING`` → ``doc.insertLineBreak`` (a
          real Word line-break node — Word treats text-wrapping as a
          synonym for line)
        - ``COLUMN`` / ``LINE_CLEAR_LEFT`` / ``LINE_CLEAR_RIGHT`` /
          ``LINE_CLEAR_ALL`` — SuperDoc has no dedicated wire op for
          these, so they degrade to a line break and emit
          :class:`PendingBreakDegradationWarning` so callers know the
          fidelity was lossy.
        """
        import warnings

        if self._check_cell_inner("add_break"):
            return
        end: int = self._range[1]
        # Normalize string aliases like "page" / "line" the same way
        # python-docx does for back-compat callers. python-docx 1.x
        # ``Run.add_break`` raises ``KeyError`` on an unknown
        # break_type via its lookup table — was: unknown values
        # silently fell through to ``insert_line_break`` (returning
        # without a signal that the requested break type wasn't
        # honored). Mirror upstream by raising ``ValueError`` for
        # bogus strings and ``TypeError`` for non-WD_BREAK / non-str
        # input.
        bt: WD_BREAK
        if isinstance(break_type, WD_BREAK):
            bt = break_type
        elif isinstance(break_type, str):
            try:
                bt = WD_BREAK[break_type.upper()]
            except KeyError as exc:
                raise ValueError(
                    f"Run.add_break({break_type!r}): not a valid "
                    f"WD_BREAK member. Expected one of "
                    f"{[m.name for m in WD_BREAK]}.",
                ) from exc
        else:
            raise TypeError(
                f"Run.add_break break_type requires WD_BREAK or str; "
                f"got {type(break_type).__name__} {break_type!r}",
            )

        section_break_map: dict[WD_BREAK, str] = {
            WD_BREAK.PAGE: "nextPage",
            WD_BREAK.SECTION_NEXT_PAGE: "nextPage",
            WD_BREAK.SECTION_CONTINUOUS: "continuous",
            WD_BREAK.SECTION_EVEN_PAGE: "evenPage",
            WD_BREAK.SECTION_ODD_PAGE: "oddPage",
        }
        degraded_to_line: tuple[WD_BREAK, ...] = (
            WD_BREAK.COLUMN,
            WD_BREAK.LINE_CLEAR_LEFT,
            WD_BREAK.LINE_CLEAR_RIGHT,
            WD_BREAK.LINE_CLEAR_ALL,
        )

        if bt in section_break_map:
            run_sync(
                self._session.doc.create.section_break(
                    {
                        "at": {"kind": "documentEnd"},
                        "breakType": section_break_map[bt],
                    },
                ),
            )
            return

        if bt in degraded_to_line:
            warnings.warn(
                f"add_break({bt.name}) degraded to a line break — SuperDoc "
                "has no wire op for column / line-clear breaks. The Y.Doc "
                "will record a regular line break instead. Track the gap in "
                "docx-studio/PYTHON_DOCX_PARITY_GAPS.md § 'What unblocks the "
                "remaining work'.",
                PendingBreakDegradationWarning,
                stacklevel=2,
            )

        # LINE / TEXT_WRAPPING / unknown alias / degraded-to-line all
        # fall through to insertLineBreak.
        run_sync(
            self._session.doc.insert_line_break(
                {"blockId": self._block_id, "offset": end},
            ),
        )
        # The line-break consumes one offset position in the
        # paragraph's text address space — without advancing the
        # run's right edge, a subsequent add_text() would reuse the
        # pre-break offset and overwrite/push the break to the
        # paragraph end. (Mirrors add_tab's bookkeeping.)
        self._range = (self._range[0], end + 1)
        self._note_paragraph_len_delta(1)
        # Range may have expanded from collapsed → non-collapsed; flush
        # any pending inline formatting now that there's text to mark.
        self._flush_pending_inline()

    def add_picture(
        self,
        image_path_or_stream: str | BinaryIO,
        width: "int | Length | None" = None,
        height: "int | Length | None" = None,
    ) -> "InlineShape":
        """Insert an inline picture at the end of this run.

        Returns an :class:`InlineShape` proxy for the newly-inserted
        image, matching python-docx ``Run.add_picture``.
        """
        from docx._image_utils import sniff_content_type
        from docx.document import _emu_to_px
        from docx.shape import InlineShape
        import base64
        import io

        image_bytes: bytes
        fallback_path: str = ""
        if isinstance(image_path_or_stream, str):
            with open(image_path_or_stream, "rb") as f:
                image_bytes = f.read()
            fallback_path = image_path_or_stream
        elif isinstance(image_path_or_stream, io.IOBase):
            image_bytes = image_path_or_stream.read()
        else:
            raise TypeError(
                "Expected path str or binary stream, "
                f"got {type(image_path_or_stream).__name__}",
            )
        # Empty payload would silently round-trip as
        # ``data:image/png;base64,`` (broken placeholder image). Fail
        # at the call site instead of at render time. Matches the
        # validation added in :meth:`docx.document.Document.add_picture`.
        if not image_bytes:
            raise ValueError(
                "Cannot add_picture from empty bytes — the file at "
                f"{image_path_or_stream!r} was empty or the stream was "
                "exhausted before .add_picture was called. Pass a fresh "
                "stream or a non-empty file path."
            )
        # Sniff by magic bytes first; fall back to extension only when
        # the bytes don't match a known signature. python-docx 1.x uses
        # Pillow for the same purpose; we avoid the dep by hand-rolling
        # the four signatures SuperDoc accepts inline.
        content_type: str = sniff_content_type(
            image_bytes, fallback_path=fallback_path
        )
        b64: str = base64.b64encode(image_bytes).decode("ascii")
        data_uri: str = f"data:{content_type};base64,{b64}"
        w_px: float = _emu_to_px(width) if width is not None else 576.0
        h_px: float = _emu_to_px(height) if height is not None else 432.0
        result: object = run_sync(
            self._session.doc.create.image(
                {
                    "src": data_uri,
                    "size": {"width": w_px, "height": h_px},
                    "at": {"kind": "documentEnd"},
                },
            ),
        )
        info: dict = _build_inline_shape_info(result, width=w_px, height=h_px)
        return InlineShape(session=self._session, info=info)

    @athena_extension(
        issue=498,
        description="Run.add_field — generic Word field (PAGE, DATE, REF, SEQ, TOC, ...).",
    )
    def add_field(
        self,
        kind: str,
        *,
        args: dict | None = None,
        cached_result: str | None = None,
    ) -> "Field":
        """Insert a Word field at the end of this run.

        Athena extension beyond python-docx 1.x — issue #498 (page
        numbers) and #31 (generic add_field) demand this. ``kind`` is
        one of ``"PAGE"``, ``"NUMPAGES"``, ``"DATE"``, ``"TIME"``,
        ``"AUTHOR"``, ``"FILENAME"``, ``"NUMWORDS"``, ``"REF"``,
        ``"SEQ"``, ``"TOC"``, or the generic ``"FIELD"`` (provide an
        ``instr`` in ``args``). ``args`` is kind-specific — e.g.
        ``{format: "MMMM d, yyyy"}`` for DATE.
        """
        from docx.commands import CreateField
        from docx.fields import Field

        if self._check_cell_inner("add_field"):
            return Field(
                session=self._session,
                field_id="",
                kind=kind,
                instr="",
            )
        end: int = self._range[1]
        # SuperDoc's ``doc.fields.insert`` anchor schema (verified
        # empirically against staging on 2026-05-18):
        #   { kind: "text", segments: [{ blockId, range: {start, end} }] }
        # Required: ``kind == "text"`` AND ``segments`` populated with
        # at least one ``{blockId, range}`` entry.
        # Disallowed: top-level ``blockId`` / ``offset`` / ``start`` /
        # ``end`` (the cursor envelope used by other create-ops).
        # Pre-0.11.4 the SDK sent ``{kind: "selection", start, end}``
        # and the call cascade-failed with
        # ``fields insert:at.segments is required``. Then walking the
        # error chain on staging: ``at.kind must equal "text"`` (had
        # to switch kind), then ``at.blockId is not allowed`` (had to
        # drop the cursor-envelope keys), then
        # ``at.segments[0].range is required`` (had to wrap start/end
        # in a ``range`` sub-object).
        # NOTE: the CLI itself currently rejects valid-shape calls
        # with ``fields insert: missing required --mode-json`` — that's
        # a SuperDoc-internal CLI argument the apps/api applier doesn't
        # pass through to ``anyDoc.fields.insert`` yet. The SDK shape
        # below is correct; when apps/api forwards ``modeJson: true``
        # (or the SuperDoc CLI grows a default for it) this call path
        # starts succeeding without further SDK changes.
        cmd = CreateField(
            kind=kind,
            args=args,
            at={
                "kind": "text",
                "segments": [
                    {
                        "blockId": self._block_id,
                        "range": {"start": end, "end": end},
                    }
                ],
            },
            cached_result=cached_result,
        )
        result = run_sync(self._session.send_command(cmd))
        field_id = ""
        if isinstance(result, dict):
            field_id = str(result.get("id") or result.get("fieldId") or "")
        return Field(
            session=self._session,
            field_id=field_id,
            kind=kind,
            instr=None,
            result=cached_result,
        )

    @athena_extension(
        issue=1,
        description="Run.add_footnote — closes python-docx Issue #1 (open since 2014).",
    )
    def add_footnote(self, text: str, *, custom_mark: str | None = None) -> "Footnote":
        """Insert a footnote reference at the end of this run.

        Athena extension beyond python-docx 1.x — Issue #1 (the first
        issue ever filed) demands this. ``text`` is the footnote body;
        ``custom_mark`` overrides the auto-numbered reference (e.g.
        ``"*"`` for a custom mark).
        """
        from docx.commands import CreateFootnote
        from docx.footnotes import Footnote

        end: int = self._range[1]
        cursor: dict = {
            "kind": "text",
            "blockId": self._block_id,
            "offset": end,
        }
        cmd = CreateFootnote(
            at={"kind": "selection", "start": cursor, "end": cursor},
            text=text,
            custom_mark=custom_mark,
        )
        result = run_sync(self._session.send_command(cmd))
        footnote_id = ""
        if isinstance(result, dict):
            footnote_id = str(
                result.get("id") or result.get("footnoteId") or "",
            )
        # Reference mark is one character in the address space.
        self._range = (self._range[0], end + 1)
        self._note_paragraph_len_delta(1)
        return Footnote(
            session=self._session,
            footnote_id=footnote_id,
            text=text,
            custom_mark=custom_mark,
        )

    @athena_extension(issue=1, description="Run.add_endnote — endnote reference.")
    def add_endnote(self, text: str, *, custom_mark: str | None = None) -> "Endnote":
        """Insert an endnote reference at the end of this run.

        Athena extension beyond python-docx 1.x. Twin of
        :meth:`add_footnote` but renders end-of-section."""
        from docx.commands import CreateEndnote
        from docx.footnotes import Endnote

        end: int = self._range[1]
        cursor: dict = {
            "kind": "text",
            "blockId": self._block_id,
            "offset": end,
        }
        cmd = CreateEndnote(
            at={"kind": "selection", "start": cursor, "end": cursor},
            text=text,
            custom_mark=custom_mark,
        )
        result = run_sync(self._session.send_command(cmd))
        endnote_id = ""
        if isinstance(result, dict):
            endnote_id = str(
                result.get("id") or result.get("endnoteId") or "",
            )
        self._range = (self._range[0], end + 1)
        self._note_paragraph_len_delta(1)
        return Endnote(
            session=self._session,
            endnote_id=endnote_id,
            text=text,
            custom_mark=custom_mark,
        )

    @athena_extension(
        issue=97,
        description="Run.add_cross_reference — REF field targeting a bookmark or SEQ.",
    )
    def add_cross_reference(
        self,
        target: str,
        *,
        reference_kind: str = "text",
        hyperlink: bool = True,
    ) -> "Field":
        """Insert a cross-reference (REF field) targeting a bookmark or
        sequence at the end of this run.

        Athena extension beyond python-docx 1.x — issue #97 demands
        this. ``target`` is the bookmark name or SEQ ref-mark.
        ``reference_kind`` selects which property of the target to
        surface (``"text"``, ``"number"``, ``"page"``, ``"label-number"``,
        ``"above-below"``, ``"paragraph"``). When ``hyperlink=True``
        the reference is a clickable internal link.
        """
        from docx.commands import CreateCrossReference
        from docx.fields import Field

        end: int = self._range[1]
        cursor: dict = {
            "kind": "text",
            "blockId": self._block_id,
            "offset": end,
        }
        cmd = CreateCrossReference(
            target=target,
            reference_kind=reference_kind,
            hyperlink=hyperlink,
            at={"kind": "selection", "start": cursor, "end": cursor},
        )
        result = run_sync(self._session.send_command(cmd))
        field_id = ""
        if isinstance(result, dict):
            field_id = str(result.get("id") or result.get("fieldId") or "")
        return Field(
            session=self._session,
            field_id=field_id,
            kind="REF",
            instr=f"REF {target}",
            result=None,
        )

    @athena_extension(
        issue=320,
        description="Run.add_math — MathML / OMML / LaTeX equation.",
    )
    def add_math(
        self,
        content: str,
        *,
        format: str = "mathml",
        display: bool = False,
    ) -> "MathEquation":
        """Insert a math equation at the end of this run.

        Athena extension beyond python-docx 1.x — issue #320 demands
        this. ``format`` is ``"omml"`` (Office MathML, native),
        ``"mathml"`` (W3C MathML, server-converted), or ``"latex"``.
        ``display=True`` produces a centered display equation; default
        is inline.
        """
        from docx.commands import CreateMath
        from docx.math import MathEquation

        end: int = self._range[1]
        cursor: dict = {
            "kind": "text",
            "blockId": self._block_id,
            "offset": end,
        }
        kwargs: dict = {
            "at": {"kind": "selection", "start": cursor, "end": cursor},
            "format": format if format != "latex" else "mathml",
            "display": display,
        }
        if format == "latex":
            kwargs["latex"] = content
        else:
            kwargs["content"] = content
        result = run_sync(self._session.send_command(CreateMath(**kwargs)))
        math_id = ""
        if isinstance(result, dict):
            math_id = str(result.get("id") or result.get("mathId") or "")
        return MathEquation(
            session=self._session,
            math_id=math_id,
            format=format,
            content=content,
            display=display,
        )

    @athena_extension(
        issue=74,
        description="Run.add_hyperlink — convenience wrapper around Paragraph.add_hyperlink.",
    )
    def add_hyperlink(
        self,
        text: str,
        address: str,
        *,
        fragment: str | None = None,
        tooltip: str | None = None,
    ) -> "Hyperlink":
        """Append a hyperlinked text segment to the end of this run.

        Athena extension beyond python-docx 1.x — issue #74 has been
        open since 2014. Convenience wrapper that defers to
        :meth:`docx.text.paragraph.Paragraph.add_hyperlink` against
        the paragraph that owns this run.
        """
        from docx.text.paragraph import Paragraph

        paragraph = getattr(self, "_paragraph", None)
        if not isinstance(paragraph, Paragraph):
            paragraph = Paragraph(
                session=self._session,
                node_id=self._block_id,
            )
        return paragraph.add_hyperlink(
            text=text,
            address=address,
            fragment=fragment,
            tooltip=tooltip,
        )

    def clear(self) -> "Run":
        """Clear the run's text content."""
        self.text = ""
        return self

    def mark_comment_range(self, last_run: "Run", comment_id: int) -> None:
        """Anchor an existing comment to the run range ``[self, last_run]``.

        Mirrors python-docx
        ``Run.mark_comment_range(last_run, comment_id)``. Both runs
        must live in the same block — Word can't anchor a single
        comment to disjoint blocks; we raise ``ValueError`` if they
        don't match. SuperDoc's ``doc.comments.patch`` accepts the
        new ``target`` and rewires the anchor.
        """
        if self._block_id != last_run._block_id:
            raise ValueError(
                "mark_comment_range: start and end runs must belong to "
                f"the same paragraph (got {self._block_id!r} and "
                f"{last_run._block_id!r})"
            )
        start = min(self._range[0], last_run._range[0])
        end = max(self._range[1], last_run._range[1])
        target = {
            "kind": "text",
            "blockId": self._block_id,
            "range": {"start": start, "end": end},
        }
        run_sync(
            self._session.doc.comments.patch(
                {"id": str(comment_id), "target": target},
            ),
        )

    # ---- formatting helpers ----
    def _apply_inline(self, **kwargs: object) -> None:
        # SuperDoc's ``format.apply`` rejects a collapsed target range
        # with ``SuperDocCliError: format.apply requires a non-collapsed
        # target range.`` Stash the attrs and apply them once the run
        # has text — see ``_pending_inline`` in ``__init__`` for the
        # python-docx parity rationale.
        if getattr(self, "_in_cell", False):
            # Cell-inner runs cannot apply formatting at the live wire
            # layer (SuperDoc 1.8.1 rejects ``doc.format.apply`` for
            # paragraphs nested inside ``tableCell``). Stash for the
            # post-export OOXML rewrite BEFORE we emit the warning so
            # the formatting still lands in the exported ``.docx``.
            self._stash_cell_inner_run_format(kwargs)
            self._check_cell_inner(
                "font/format (bold/italic/font.size/etc.)",
            )
            return
        if self._is_collapsed_range:
            pending = getattr(self, "_pending_inline", None)
            if pending is None:
                self._pending_inline = dict(kwargs)
            else:
                pending.update(kwargs)
            return
        run_sync(
            self._session.doc.format.apply(
                {"target": self._text_range, "inline": kwargs},
            ),
        )

    def _read_inline_attr(self, key: str) -> object:
        """Read an inline attribute from the snapshot or live node walk."""
        if key in self._inline_snapshot:
            return self._inline_snapshot[key]
        marks: object = self._inline_snapshot.get("marks")
        if isinstance(marks, list):
            for m in marks:
                if isinstance(m, dict) and m.get("type") == key:
                    return True
                if isinstance(m, dict) and isinstance(m.get("attrs"), dict):
                    if key in m["attrs"]:
                        return m["attrs"][key]
        # Live walk: re-fetch paragraph and find this run's inline.
        from docx.text.paragraph import _walk_inlines

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._block_id}),
        )
        inlines: list[dict] = _walk_inlines(info)
        offset: int = 0
        for inline in inlines:
            run_data: object = inline.get("run")
            if isinstance(run_data, dict):
                text: object = run_data.get("text", "")
                length: int = len(text) if isinstance(text, str) else 0
                if offset == self._range[0] and (offset + length) == self._range[1]:
                    if key in run_data:
                        return run_data[key]
                    return None
                offset += length
        return None

    # ---- bold / italic / underline ----
    @property
    def bold(self) -> bool | None:
        v = self._read_inline_attr("bold")
        return bool(v) if isinstance(v, bool) else None

    @bold.setter
    def bold(self, value: bool | None) -> None:
        # python-docx semantics: ``None`` clears the mark (revert to
        # inherited / unset). Non-None must be True/False — upstream's
        # ``ST_OnOff`` raises ``TypeError`` for strings, ints other
        # than 0/1, etc. We mirror that so ``run.bold = "true"``
        # (truthy string!) no longer silently round-trips as True.
        if value is not None and not isinstance(value, bool):
            # int 0/1 is treated as bool by python-docx's ST_OnOff too
            # (``1 == True``), but anything else is rejected.
            if isinstance(value, int) and value in (0, 1):
                value = bool(value)
            else:
                raise TypeError(
                    f"Run.bold only accepts True, False, or None; got "
                    f"{type(value).__name__}: {value!r}",
                )
        self._apply_inline(bold=None if value is None else bool(value))

    @property
    def italic(self) -> bool | None:
        v = self._read_inline_attr("italic")
        return bool(v) if isinstance(v, bool) else None

    @italic.setter
    def italic(self, value: bool | None) -> None:
        # Same bool-strictness as ``Run.bold`` — see that setter's
        # docstring. ``"false"`` is truthy and would silently round-trip
        # as True without this check.
        if value is not None and not isinstance(value, bool):
            if isinstance(value, int) and value in (0, 1):
                value = bool(value)
            else:
                raise TypeError(
                    f"Run.italic only accepts True, False, or None; got "
                    f"{type(value).__name__}: {value!r}",
                )
        self._apply_inline(italic=None if value is None else bool(value))

    @property
    def underline(self) -> bool | object | None:
        v = self._read_inline_attr("underline")
        if isinstance(v, bool):
            return v
        if isinstance(v, str):
            from docx.enum.text import WD_UNDERLINE

            try:
                return WD_UNDERLINE(v)
            except ValueError:
                return True if v and v != "none" else False
        return None

    @underline.setter
    def underline(self, value: object) -> None:
        from docx.enum.text import WD_UNDERLINE

        # python-docx allows ``None`` to clear the underline; pass
        # through as ``null`` on the wire (see bold.setter docstring).
        if value is None:
            self._apply_inline(underline=None)
            return
        if isinstance(value, bool):
            self._apply_inline(underline=value)
            return
        if isinstance(value, WD_UNDERLINE):
            self._apply_inline(underline=value.value)
            return
        # python-docx 1.x ``Font.underline.setter`` accepts ``bool |
        # WD_UNDERLINE | None`` and raises ``TypeError`` (via its
        # ``BaseEnumProperty`` validator) on anything else. The
        # previous catch-all ``self._apply_inline(underline=value)``
        # silently shipped dicts, ints, custom classes — SuperDoc's
        # permissive parser would either drop them or round-trip a
        # garbage value. Strings that happen to match a WD_UNDERLINE
        # member value are accepted as a python-docx-style convenience.
        if isinstance(value, str):
            try:
                self._apply_inline(underline=WD_UNDERLINE(value).value)
                return
            except (ValueError, KeyError) as exc:
                raise ValueError(
                    f"Run.underline = {value!r}: not a valid "
                    f"WD_UNDERLINE value. Expected one of "
                    f"{[m.value for m in WD_UNDERLINE]} or a bool / "
                    f"WD_UNDERLINE enum member / None.",
                ) from exc
        raise TypeError(
            f"Run.underline requires bool, WD_UNDERLINE, str, or "
            f"None; got {type(value).__name__} {value!r}",
        )

    # ---- style ----
    @property
    def style(self) -> str | None:
        v = self._read_inline_attr("rStyle") or self._read_inline_attr("styleId")
        return str(v) if v else None

    @style.setter
    def style(self, value: "str | object | None") -> None:
        """Apply a character style to the run.

        Mirrors python-docx 1.x ``Run.style.setter`` which accepts
        ``str | CharacterStyle | None``. A ``CharacterStyle`` instance
        is resolved to its ``style_id`` (NOT its display name) so
        built-in style names that diverge from ids (``"Emphasis"`` vs
        ``"Emphasis"``, ``"Intense Quote"`` vs ``"IntenseQuote"``) end
        up using the wire-side id rather than the human label.

        ``None`` clears the ``<w:rStyle>`` mark, reverting the run to
        the default character style. Was: ``if value is None: return``
        silent no-op — python-docx removes the OOXML element when
        passed None, so the prior behavior lost caller intent. Ship
        ``null`` on the wire (same pattern as ``Run.bold = None``).
        """
        if value is None:
            self._apply_inline(rStyle=None)
            return
        if isinstance(value, str):
            style_id = value
        elif hasattr(value, "style_id"):
            style_id = str(value.style_id)
        elif hasattr(value, "name"):
            style_id = str(value.name)
        else:
            # python-docx 1.x rejects non-str/non-BaseStyle here. Was:
            # catch-all ``str(value)`` shipped garbage like
            # ``"<MyObject object at 0x...>"`` as a style id, which
            # SuperDoc silently swallowed.
            raise TypeError(
                f"Run.style requires str, CharacterStyle (with "
                f"``.style_id``/``.name``), or None; got "
                f"{type(value).__name__} {value!r}",
            )
        self._apply_inline(rStyle=style_id)

    # ---- font proxy ----
    @property
    def font(self) -> "Font":
        return Font(self)


class Font:
    """Font properties of a Run. Accessed via `run.font`; do not instantiate."""

    def __init__(self, run: Run) -> None:
        self._run: Run = run

    # ---- identity ----
    @property
    def name(self) -> str | None:
        v = self._run._read_inline_attr("fontFamily")
        if not v:
            v = self._run._read_inline_attr("rFonts")
            if isinstance(v, dict):
                return v.get("ascii") or v.get("hAnsi")
            return None
        return str(v) if v else None

    @name.setter
    def name(self, value: str | None) -> None:
        # python-docx semantics: ``None`` clears the explicit font.
        # See ``Run.bold.setter`` for the wire-layer rationale.
        self._run._apply_inline(fontFamily=None if value is None else str(value))

    @property
    def size(self) -> "Pt | None":
        v = self._run._read_inline_attr("fontSize")
        if isinstance(v, (int, float)):
            return Pt(float(v))
        return None

    @size.setter
    def size(self, value: "Pt | int | None") -> None:
        # python-docx semantics: ``None`` clears the explicit size.
        if value is None:
            self._run._apply_inline(fontSize=None)
            return
        pt_value: float = (
            float(value.pt) if hasattr(value, "pt") else float(value)
        )
        self._run._apply_inline(fontSize=pt_value)

    @property
    def color(self) -> "_ColorProxy":
        return _ColorProxy(self._run)

    @property
    def highlight_color(self) -> "object | None":
        from docx.enum.text import WD_COLOR_INDEX

        v = self._run._read_inline_attr("highlight")
        if isinstance(v, str):
            try:
                return WD_COLOR_INDEX(v)
            except ValueError:
                return v
        return None

    @highlight_color.setter
    def highlight_color(self, value: object) -> None:
        from docx.enum.text import WD_COLOR_INDEX

        # python-docx: ``None`` removes the highlight mark. Pass
        # through as ``null`` rather than silently no-op'ing.
        if value is None:
            self._run._apply_inline(highlight=None)
            return
        # Reject non-``WD_COLOR_INDEX`` values rather than silently
        # ``str(...)``-casting them onto the wire. python-docx's
        # ``highlight_val.setter`` runs the value through the
        # ``WD_COLOR_INDEX`` validator which raises ``ValueError`` for
        # anything that isn't a known member (or a string matching one
        # of the member values). The earlier ``str(value)`` would
        # silently round-trip e.g. ``highlight_color="not_a_color"`` to
        # the bus — a downstream sink would then either ignore or
        # mis-render. We accept ``WD_COLOR_INDEX`` instances directly
        # and accept their string ``.value`` for parity with callers
        # that pre-serialise (``"yellow"`` etc.); everything else
        # raises.
        if isinstance(value, WD_COLOR_INDEX):
            val_str: str = value.value
        elif isinstance(value, str):
            try:
                val_str = WD_COLOR_INDEX(value).value
            except ValueError as exc:
                raise ValueError(
                    f"{value!r} is not a valid WD_COLOR_INDEX"
                ) from exc
        else:
            raise ValueError(
                f"{value!r} is not a valid WD_COLOR_INDEX"
            )
        self._run._apply_inline(highlight=val_str)

    # ---- boolean character properties ----
    def _bool_get(self, key: str) -> bool | None:
        v = self._run._read_inline_attr(key)
        return bool(v) if isinstance(v, bool) else None

    def _bool_set(self, key: str, value: bool | None) -> None:
        # python-docx parity: ``None`` clears the mark. Pass ``None``
        # through as JSON ``null`` rather than early-returning — the
        # earlier silent no-op broke every ``font.<bool_attr> = None``
        # caller. See ``Run.bold.setter`` for the wire-layer rationale.
        #
        # Reject non-bool (and non-None) input rather than silently
        # coercing via ``bool(value)``. python-docx's ``ST_OnOff``
        # validator raises ``TypeError("only True or False (and
        # possibly None) may be assigned, got '%s'")`` for anything
        # else; mirror that so ``font.bold = "true"`` doesn't silently
        # round-trip as ``True`` (truthy string).
        if value is not None and value not in (True, False):
            raise TypeError(
                "only True or False (and possibly None) may be "
                f"assigned, got '{value}'"
            )
        self._run._apply_inline(**{key: None if value is None else bool(value)})

    # Mirrored on Run
    @property
    def bold(self) -> bool | None:
        return self._run.bold

    @bold.setter
    def bold(self, value: bool | None) -> None:
        self._run.bold = value

    @property
    def italic(self) -> bool | None:
        return self._run.italic

    @italic.setter
    def italic(self, value: bool | None) -> None:
        self._run.italic = value

    @property
    def underline(self) -> bool | object | None:
        return self._run.underline

    @underline.setter
    def underline(self, value: object) -> None:
        self._run.underline = value

    # strike-through
    @property
    def strike(self) -> bool | None:
        return self._bool_get("strike")

    @strike.setter
    def strike(self, value: bool | None) -> None:
        self._bool_set("strike", value)

    @property
    def double_strike(self) -> bool | None:
        return self._bool_get("dstrike")

    @double_strike.setter
    def double_strike(self, value: bool | None) -> None:
        self._bool_set("dstrike", value)

    @property
    def all_caps(self) -> bool | None:
        return self._bool_get("caps")

    @all_caps.setter
    def all_caps(self, value: bool | None) -> None:
        self._bool_set("caps", value)

    @property
    def small_caps(self) -> bool | None:
        return self._bool_get("smallCaps")

    @small_caps.setter
    def small_caps(self, value: bool | None) -> None:
        self._bool_set("smallCaps", value)

    @property
    def math(self) -> bool | None:
        """python-docx 1.x: True iff this run is marked as math.

        Word stores this as the ``<w:rMath/>`` element on the run; SuperDoc
        carries it as the ``math`` inline mark.
        """
        return self._bool_get("math")

    @math.setter
    def math(self, value: bool | None) -> None:
        self._bool_set("math", value)

    @property
    def shadow(self) -> bool | None:
        return self._bool_get("shadow")

    @shadow.setter
    def shadow(self, value: bool | None) -> None:
        self._bool_set("shadow", value)

    @property
    def outline(self) -> bool | None:
        return self._bool_get("outline")

    @outline.setter
    def outline(self, value: bool | None) -> None:
        self._bool_set("outline", value)

    @property
    def emboss(self) -> bool | None:
        return self._bool_get("emboss")

    @emboss.setter
    def emboss(self, value: bool | None) -> None:
        self._bool_set("emboss", value)

    @property
    def imprint(self) -> bool | None:
        return self._bool_get("imprint")

    @imprint.setter
    def imprint(self, value: bool | None) -> None:
        self._bool_set("imprint", value)

    @property
    def hidden(self) -> bool | None:
        return self._bool_get("vanish")

    @hidden.setter
    def hidden(self, value: bool | None) -> None:
        self._bool_set("vanish", value)

    @property
    def web_hidden(self) -> bool | None:
        return self._bool_get("webHidden")

    @web_hidden.setter
    def web_hidden(self, value: bool | None) -> None:
        self._bool_set("webHidden", value)

    @property
    def spec_vanish(self) -> bool | None:
        return self._bool_get("specVanish")

    @spec_vanish.setter
    def spec_vanish(self, value: bool | None) -> None:
        self._bool_set("specVanish", value)

    @property
    def rtl(self) -> bool | None:
        return self._bool_get("rtl")

    @rtl.setter
    def rtl(self, value: bool | None) -> None:
        self._bool_set("rtl", value)

    @property
    def cs_bold(self) -> bool | None:
        return self._bool_get("bCs")

    @cs_bold.setter
    def cs_bold(self, value: bool | None) -> None:
        self._bool_set("bCs", value)

    @property
    def cs_italic(self) -> bool | None:
        return self._bool_get("iCs")

    @cs_italic.setter
    def cs_italic(self, value: bool | None) -> None:
        self._bool_set("iCs", value)

    @property
    def complex_script(self) -> bool | None:
        return self._bool_get("cs")

    @complex_script.setter
    def complex_script(self, value: bool | None) -> None:
        self._bool_set("cs", value)

    @property
    def no_proof(self) -> bool | None:
        # python-docx uses proofing flag; map to vanish-like.
        return self._bool_get("noProof")

    @no_proof.setter
    def no_proof(self, value: bool | None) -> None:
        self._bool_set("noProof", value)

    @property
    def snap_to_grid(self) -> bool | None:
        return self._bool_get("snapToGrid")

    @snap_to_grid.setter
    def snap_to_grid(self, value: bool | None) -> None:
        self._bool_set("snapToGrid", value)

    # subscript / superscript — mapped to vertAlign
    @property
    def subscript(self) -> bool | None:
        v = self._run._read_inline_attr("vertAlign")
        if isinstance(v, str):
            return v == "subscript"
        return None

    @subscript.setter
    def subscript(self, value: bool | None) -> None:
        # python-docx parity (``CT_RPr.subscript.setter``):
        #   - ``None`` removes ``vertAlign`` outright
        #   - ``True`` sets ``vertAlign = "subscript"``
        #   - ``False`` removes ``vertAlign`` **only if** it is
        #     currently ``"subscript"``. Otherwise it leaves the
        #     existing value alone (so ``font.subscript = False``
        #     on a superscript run is a no-op, not a clobber).
        # The earlier code silently swallowed ``None`` and naively
        # forced ``"baseline"`` on ``False`` — both broke parity.
        if value is None:
            self._run._apply_inline(vertAlign=None)
            return
        if value:
            self._run._apply_inline(vertAlign="subscript")
            return
        # value is False — only clear if currently subscript.
        current = self._run._read_inline_attr("vertAlign")
        if isinstance(current, str) and current == "subscript":
            self._run._apply_inline(vertAlign=None)

    @property
    def superscript(self) -> bool | None:
        v = self._run._read_inline_attr("vertAlign")
        if isinstance(v, str):
            return v == "superscript"
        return None

    @superscript.setter
    def superscript(self, value: bool | None) -> None:
        # python-docx parity (``CT_RPr.superscript.setter``): see
        # ``subscript.setter`` for the full semantics — ``False`` only
        # clears ``vertAlign`` when it is currently ``"superscript"``;
        # ``None`` removes ``vertAlign`` outright.
        if value is None:
            self._run._apply_inline(vertAlign=None)
            return
        if value:
            self._run._apply_inline(vertAlign="superscript")
            return
        current = self._run._read_inline_attr("vertAlign")
        if isinstance(current, str) and current == "superscript":
            self._run._apply_inline(vertAlign=None)

    # style
    @property
    def style(self) -> str | None:
        return self._run.style

    @style.setter
    def style(self, value: str | None) -> None:
        self._run.style = value


class _ColorProxy:
    """Matches python-docx's `run.font.color` — has .rgb / .type get/set."""

    def __init__(self, run: Run) -> None:
        self._run: Run = run

    @property
    def rgb(self) -> "RGBColor | None":
        v = self._run._read_inline_attr("color")
        if isinstance(v, str) and len(v) in (6, 7):
            try:
                return RGBColor.from_string(v)
            except ValueError:
                return None
        return None

    @rgb.setter
    def rgb(self, value: "RGBColor | None") -> None:
        # python-docx semantics: ``None`` clears the explicit color
        # (revert to inherited). The earlier early-return silently
        # no-op'd, breaking parity. Pass ``null`` through as for the
        # other inline attrs — see ``Run.bold.setter``.
        #
        # Reject anything other than ``RGBColor`` (or ``None``).
        # python-docx's ``ColorFormat.rgb.setter`` runs the value
        # through ``ST_HexColorRGB`` which raises
        # ``ValueError("rgb color value must be RGBColor object, got
        # <class 'X'> ...")`` for any non-``RGBColor``. The earlier
        # ``str(value)`` would silently round-trip e.g. a raw hex
        # string ``"#FF0000"`` (note the leading ``#``, which
        # ``RGBColor.from_string`` rejects on read), making writes and
        # reads disagree.
        if value is not None and not isinstance(value, RGBColor):
            raise ValueError(
                "rgb color value must be RGBColor object, got "
                f"{type(value)} {value}"
            )
        self._run._apply_inline(
            color=None if value is None else str(value),
        )

    @property
    def type(self) -> None:
        import warnings
        warnings.warn(
            "Font.color.type is unavailable — SuperDoc inline runs don't "
            "expose color-type metadata (MSO_COLOR_TYPE / theme refs). "
            "Tracked in docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md § 10.",
            PendingColorTypeWarning,
            stacklevel=2,
        )
        return None
