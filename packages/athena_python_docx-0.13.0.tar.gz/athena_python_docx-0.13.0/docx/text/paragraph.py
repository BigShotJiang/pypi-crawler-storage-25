"""Paragraph — mirrors python-docx's Paragraph class."""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING, Any

from docx._athena_extension import athena_extension
from docx._batching import run_sync

if TYPE_CHECKING:
    from docx.bookmarks import Bookmark
    from docx.client import Session
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.styles.style import CharacterStyle, ParagraphStyle
    from docx.text.hyperlink import Hyperlink
    from docx.text.parfmt import ParagraphFormat
    from docx.text.run import Run


class CellInnerFormatNotSupportedWarning(UserWarning):
    """Cell-inner paragraph format ops are not supported by SuperDoc 1.8.1.

    Emitted when ``Paragraph.style``, ``Paragraph.alignment``, any
    ``ParagraphFormat`` setter (``space_before``, ``space_after``,
    indents, keep options, …), or ``Paragraph.add_hyperlink`` is called
    on a paragraph that lives inside a table cell.

    SuperDoc 1.8.1 returns the cell-inner paragraph's nodeId from
    ``cell.getNodeById`` but doesn't accept it as the ``target`` of
    ``SetParagraphAlignment``, ``SetParagraphStyle``,
    ``SetParagraphIndentation``, ``SetParagraphSpacing``,
    ``CreateHyperlink``, or ``doc.insert`` with a paragraph-block
    target — every one of those raises
    ``BlockNotFoundError: Block "<uuid>" was not found.`` from the
    apps/api applier, and because the command bus rejects the entire
    batch on the first failure (``applied: []``), one cell-inner
    format setter silently nukes every other create/format command
    queued before it in the same flush.

    Pre-0.11.4 the SDK forwarded the broken command anyway and the
    user discovered the cascade only when ``doc.save()`` raised
    ``BlockNotFoundError`` from a stack frame far removed from the
    actual culprit. As of 0.11.4 the SDK refuses to queue the broken
    command, emits this warning, and lets the surrounding script
    continue — at the cost of the format silently not being applied.

    Workaround: materialize the cell paragraph through
    ``cell.text = "value"`` first, then re-read ``cell.paragraphs[0]``
    and apply format ops to that proxy — the post-materialization
    paragraph is addressable. Tracked upstream at
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 13.
    """


_CELL_INNER_WORKAROUND = (
    "SuperDoc 1.8.1 cannot apply this format op to a paragraph nested "
    "inside a table cell at the live wire layer; the setter was "
    "skipped to keep the surrounding batch from being rejected. "
    "For tables created via ``Document.add_table`` (which carry a "
    "stable OOXML address), the format IS preserved in the exported "
    "``.docx`` via a post-export OOXML rewrite — paragraph alignment, "
    "style, indent, spacing, and run-level formatting (bold/italic/"
    "font.size/font.color/font.name/highlight/strike/underline/rStyle) "
    "all land at export time. The live Olympus rendering still won't "
    "reflect cell-inner formatting until SuperDoc lands a wire op for "
    "it; ``Document.export_docx`` is the source of truth. If you "
    "need text to materialize in the live document, use "
    "``cell.text = 'value'`` for plain content or "
    "``cell.add_paragraph(text, style='Heading X')`` for styled "
    "paragraphs. Tracked at "
    "docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md § 13."
)


def _node_text(session: "Session", node_id: str) -> str:
    """Fetch a block's full text via doc.get_node_by_id.

    The response shape nests inlines under a node-type key — ``paragraph``
    for paragraphs, ``heading`` for headings:
        {"node": {"paragraph": {"inlines": [{"run": {"text": "..."}}, ...]}}}
    """
    info: object = run_sync(
        session.doc.get_node_by_id({"id": node_id}),
    )
    return _extract_text(info)


def _extract_text(info: object) -> str:
    """Concatenate the text content of a paragraph, mirroring
    python-docx ``Paragraph.text`` semantics:

    - Runs contribute their ``text``
    - ``<w:tab/>`` (SuperDoc inline ``{type: "tab"}``) becomes ``\\t``
    - ``<w:br/>`` line breaks (SuperDoc inline ``{type: "lineBreak"}``)
      become ``\\n``
    - Page-break inlines and other non-text inlines are skipped, same
      as python-docx's behavior

    The earlier impl silently dropped tabs and line breaks, so any
    paragraph with mixed content returned a string that didn't match
    what python-docx returns for the same source — broken parity.
    """
    if not isinstance(info, dict):
        return ""
    node: object = info.get("node")
    if not isinstance(node, dict):
        return ""
    block: object = node.get("paragraph") or node.get("heading")
    if not isinstance(block, dict):
        return ""
    inlines: object = block.get("inlines")
    if not isinstance(inlines, list):
        return ""
    parts: list[str] = []
    for inline in inlines:
        if not isinstance(inline, dict):
            continue
        run: object = inline.get("run")
        if isinstance(run, dict):
            text: object = run.get("text")
            if isinstance(text, str):
                parts.append(text)
            continue
        # ProseMirror-style inlines come through as flat ``{type:
        # "text"|"tab"|"lineBreak", …}`` shapes.
        t: object = inline.get("type")
        if t == "text":
            text2: object = inline.get("text")
            if isinstance(text2, str):
                parts.append(text2)
        elif t == "tab":
            parts.append("\t")
        elif t == "lineBreak":
            parts.append("\n")
    return "".join(parts)


def _walk_inlines(info: object) -> list[dict]:
    """Return the inlines array (runs) from a getNodeById paragraph response."""
    if not isinstance(info, dict):
        return []
    node: object = info.get("node")
    if not isinstance(node, dict):
        return []
    block: object = node.get("paragraph") or node.get("heading")
    if not isinstance(block, dict):
        return []
    inlines: object = block.get("inlines")
    if isinstance(inlines, list):
        return [i for i in inlines if isinstance(i, dict)]
    return []


class Paragraph:
    """A paragraph block in a Word document."""

    def __init__(
        self,
        *,
        session: "Session",
        node_id: str,
        node_type: str = "paragraph",
        text_len: int | None = None,
        in_cell: bool = False,
        cell_ooxml_address: "tuple[int, int, int, int] | None" = None,
        cell: "object | None" = None,
    ) -> None:
        self._session: "Session" = session
        self._node_id: str = node_id
        # Track node_type at creation so paragraph-level ops can skip a
        # getNodeById round-trip (which raced against Superdoc mutation
        # commits and raised "Block X was not found" for freshly-created
        # blocks). "paragraph" | "heading" | "listItem".
        self._node_type: str = node_type
        # Optional local cache of the paragraph's text length in the
        # SuperDoc address space (1 char per visible char, 1 per tab,
        # 1 per line-break). When ``None`` we don't trust a local value
        # and fall back to ``_node_text`` queries. Callers that just
        # created the paragraph with a known body (``Document.add_paragraph
        # (text=...)``) or that just inserted/appended text pass the
        # length explicitly — every cached value avoids one
        # ``get_node_by_id`` HTTP round-trip in ``add_run``. See
        # ``docx-studio/PERFORMANCE_BATCHING_ANALYSIS.md``.
        self._text_len: int | None = text_len
        # True for paragraphs returned by ``_Cell.add_paragraph`` or
        # iterated from ``cell.paragraphs``. Drives the cell-inner
        # format-op guard in :meth:`_check_cell_inner` — format setters
        # short-circuit with a typed warning instead of forwarding a
        # command the server would reject (see
        # :class:`CellInnerFormatNotSupportedWarning`).
        self._in_cell: bool = in_cell
        # OOXML positional address of this paragraph when ``in_cell`` is
        # True: ``(table_doc_index, row, col, paragraph_index)``. Set by
        # ``_Cell.paragraphs`` / ``_Cell.add_paragraph``. Drives the
        # post-export OOXML rewrite path that applies cell-inner format
        # ops at ``Document.export_docx`` time (since SuperDoc rejects
        # them on the wire — see ``docx._postproc``).
        self._cell_ooxml_address: tuple[int, int, int, int] | None = (
            cell_ooxml_address
        )
        # Back-reference to the parent ``_Cell`` when ``in_cell=True``.
        # Set by ``_Cell.paragraphs`` / ``_Cell.add_paragraph`` /
        # ``_Cell.iter_inner_content``. Drives the cell-inner
        # ``add_run(text)`` materialization path (0.13.0+) — instead of
        # warn-and-skipping the text insertion, ``Paragraph.add_run``
        # routes through ``doc.insert(target=cell, placement="insideEnd",
        # content=paragraph-fragment-with-text)`` so the text actually
        # lands in the live document. Without this back-ref the
        # pre-0.13.0 fallback (return stub Run, drop text) still applies
        # — defensive for paragraph proxies built outside the _Cell
        # construction paths.
        self._cell: object | None = cell

    def _check_cell_inner(self, op: str, **format_props: Any) -> bool:
        """Return ``True`` if this paragraph is inside a table cell and
        the caller should short-circuit a format setter rather than
        forwarding a command the server can't apply.

        Emits :class:`CellInnerFormatNotSupportedWarning` once per call
        site (via the ``stacklevel=4`` hop through the property
        descriptor + the ParagraphFormat method) so users see exactly
        which setter the SDK refused.

        When ``format_props`` are passed and this paragraph has a known
        OOXML cell address, the props are stashed in
        ``session._post_export_ops`` so :meth:`docx.document.Document.export_docx`
        applies them as an OOXML rewrite on the bytes returned by
        docx-studio. Live-session state remains unchanged (the format
        op never reaches SuperDoc), but the exported ``.docx`` carries
        the formatting the caller asked for.
        """
        if not self._in_cell:
            return False
        warnings.warn(
            f"Paragraph.{op} on a cell-inner paragraph: "
            + _CELL_INNER_WORKAROUND,
            CellInnerFormatNotSupportedWarning,
            stacklevel=4,
        )
        if format_props and self._cell_ooxml_address is not None:
            from docx._postproc import CellAddress

            ops = getattr(self._session, "_post_export_ops", None)
            if ops is not None:
                tbl_idx, row, col, para_idx = self._cell_ooxml_address
                ops.add_cell_format(
                    CellAddress(
                        table_doc_index=tbl_idx,
                        row=row,
                        col=col,
                        paragraph_index=para_idx,
                    ),
                    **format_props,
                )
        return True

    def __getattr__(self, name: str) -> Any:
        """Intercept ``_p`` / ``_element`` / ``part`` access with a
        typed :class:`docx.oxml.OxmlNotAvailableError` that points at
        the high-level API. Default ``AttributeError`` for everything
        else.
        """
        from docx.oxml import guard_xml_attr

        guard_xml_attr("Paragraph", name)
        raise AttributeError(
            f"'Paragraph' object has no attribute {name!r}",
        )

    def _invalidate_text_len(self) -> None:
        """Forget the cached text length. Use when a mutation lands
        but we can't cheaply compute the new value."""
        self._text_len = None

    def _resolve_text_len(self) -> int:
        """Return the paragraph's text length, querying the server iff
        we don't have a cached value.

        Mutations that know how the length changed (``add_run``,
        ``Run.text``, ``Run.add_text``, ``Run.add_tab``, ``Run.add_break``)
        update the cache directly to avoid the round-trip on the next
        call.
        """
        if self._text_len is not None:
            return self._text_len
        text: str = _node_text(self._session, self._node_id)
        self._text_len = len(text)
        return self._text_len

    @property
    def text(self) -> str:
        """Return the plain-text content of this paragraph."""
        return _node_text(self._session, self._node_id)

    @text.setter
    def text(self, value: str) -> None:
        """Replace the paragraph's text. Preserves the paragraph itself.

        python-docx 1.x raises ``TypeError`` for non-str input via lxml's
        ``_element_text.text = value`` validation. Previously this
        setter shipped any value through ``replace({text: value})``
        and SuperDoc's permissive parser silently coerced or rejected
        it. Reject non-str at the call site so callers learn at the
        mutation, not on render.
        """
        if not isinstance(value, str):
            raise TypeError(
                f"Paragraph.text requires str; got {type(value).__name__} "
                f"{value!r}. Pass ``str(value)`` explicitly if you "
                f"want to coerce.",
            )
        current_len: int = self._resolve_text_len()
        run_sync(
            self._session.doc.replace(
                {
                    "target": {
                        "kind": "selection",
                        "start": {
                            "kind": "text",
                            "blockId": self._node_id,
                            "offset": 0,
                        },
                        "end": {
                            "kind": "text",
                            "blockId": self._node_id,
                            "offset": current_len,
                        },
                    },
                    "text": value,
                },
            ),
        )
        # We just replaced the entire paragraph contents with ``value``;
        # the new text-address length is simply ``len(value)``.
        self._text_len = len(value)

    @property
    def runs(self) -> list["Run"]:
        """Return the runs in this paragraph (in document order).

        Run offsets are computed against SuperDoc's text-address space,
        which counts tab and lineBreak inlines as 1 character each
        (so ``insert_tab({offset})`` and the run-range arithmetic stay
        consistent). The visible text of those inlines (``\\t`` and
        ``\\n``) is what :func:`_extract_text` emits, so ``Run.text``
        slicing of ``paragraph.text`` still aligns.
        """
        from docx.text.run import Run

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        inlines: list[dict] = _walk_inlines(info)
        runs: list["Run"] = []
        offset: int = 0
        for inline in inlines:
            run_data: object = inline.get("run")
            if isinstance(run_data, dict):
                text: object = run_data.get("text")
                if not isinstance(text, str):
                    continue
                start: int = offset
                end: int = offset + len(text)
                offset = end
                runs.append(
                    Run(
                        session=self._session,
                        block_id=self._node_id,
                        range_=(start, end),
                        inline=run_data,
                        in_cell=self._in_cell,
                        cell_ooxml_address=self._cell_ooxml_address,
                    ),
                )
                continue
            t: object = inline.get("type")
            if t == "text":
                text2: object = inline.get("text")
                if isinstance(text2, str):
                    start = offset
                    end = offset + len(text2)
                    offset = end
                    runs.append(
                        Run(
                            session=self._session,
                            block_id=self._node_id,
                            range_=(start, end),
                            inline=inline,
                            in_cell=self._in_cell,
                            cell_ooxml_address=self._cell_ooxml_address,
                        ),
                    )
            elif t in ("tab", "lineBreak"):
                # Tab/lineBreak occupy one position in SuperDoc's address
                # space. Don't yield as a Run (matches python-docx —
                # tabs/breaks are part of a Run's text, not separate
                # Run objects), but DO advance the offset so subsequent
                # runs land on the right index.
                offset += 1
        # We just walked the whole paragraph — refresh the text-length
        # cache for free (avoids a follow-up ``get_node_by_id`` if the
        # caller does ``p.runs[...]; p.add_run(...)``).
        self._text_len = offset
        return runs

    @property
    def style(self):
        """Return a ParagraphStyle-like object whose .name == styleId.

        For python-docx parity, comparing the returned object to a string
        works via `.name` (not == string), matching stock behavior.
        """
        from docx.styles.style import ParagraphStyle
        from docx.enum.style import WD_STYLE_TYPE

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        if not isinstance(info, dict):
            return None
        node: object = info.get("node")
        if not isinstance(node, dict):
            return None
        style_id: object = node.get("styleId") or node.get("style")
        if not style_id:
            return None
        return ParagraphStyle(
            name=str(style_id),
            style_type=WD_STYLE_TYPE.PARAGRAPH,
            session=self._session,
        )

    @style.setter
    def style(self, value) -> None:
        """Set paragraph style. Accepts a style name, a style object, or ``None``.

        Mirrors python-docx 1.x:
        - ``None`` → restore the default ("Normal").
        - ``str`` → used verbatim as the style id.
        - ``ParagraphStyle`` / other ``BaseStyle`` subclass → use its
          ``style_id`` (NOT its display name). For built-in styles
          ``style_id`` and ``name`` diverge (``"Heading 1"`` vs
          ``"Heading1"``); the wire format wants the id.

        Anything else raises ``TypeError`` — was: catch-all
        ``str(value)`` silently shipped ``<MyObject object at 0x...>``
        as a style id.
        """
        style_id: str
        if value is None:
            style_id = "Normal"
        elif isinstance(value, str):
            style_id = value
        elif hasattr(value, "style_id"):
            style_id = str(value.style_id)
        elif hasattr(value, "name"):
            style_id = str(value.name)
        else:
            raise TypeError(
                f"Paragraph.style requires str, BaseStyle (with "
                f"``.style_id``/``.name``), or None; got "
                f"{type(value).__name__} {value!r}",
            )
        if self._check_cell_inner("style", style=style_id):
            return
        run_sync(
            self._session.doc.styles.paragraph.set_style(
                {
                    "target": self._block_target(),
                    "styleId": style_id,
                },
            ),
        )

    @property
    def alignment(self) -> "WD_ALIGN_PARAGRAPH | None":
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        if not isinstance(info, dict):
            return None
        node: object = info.get("node")
        if not isinstance(node, dict):
            return None
        block: object = node.get("paragraph") or node.get("heading")
        if isinstance(block, dict):
            raw: object = (
                block.get("alignment")
                or (block.get("attrs", {}) or {}).get("textAlign")
            )
            if isinstance(raw, str) and raw:
                return WD_ALIGN_PARAGRAPH.from_superdoc(raw)
        return None

    @alignment.setter
    def alignment(self, value: "WD_ALIGN_PARAGRAPH | str | None") -> None:
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        if value is None:
            if self._check_cell_inner("alignment", alignment=None):
                return
            run_sync(
                self._session.doc.format.paragraph.clear_alignment(
                    {"target": self._block_target()},
                ),
            )
            return
        if isinstance(value, WD_ALIGN_PARAGRAPH):
            alignment_str: str = value.to_superdoc()
        elif isinstance(value, bool):
            # ``bool`` is a subclass of ``int`` — without this guard
            # ``paragraph.alignment = True`` would coerce to CENTER
            # (since CENTER=1 in upstream's int mapping). That's a
            # truthy footgun python-docx itself avoids by typing the
            # setter as ``WD_ALIGN_PARAGRAPH | int``.
            raise TypeError(
                f"Paragraph.alignment requires WD_ALIGN_PARAGRAPH, "
                f"int, str, or None; got bool {value!r}",
            )
        elif isinstance(value, int):
            # python-docx 1.x convenience: integer values map through
            # upstream's int-keyed enum (LEFT=0, CENTER=1, ...). Pin
            # because real callers rely on it (mega08_product_catalog
            # fidelity case uses ``alignment = 1`` for CENTER).
            coerced = WD_ALIGN_PARAGRAPH.from_int(value)
            if coerced is None:
                raise ValueError(
                    f"Paragraph.alignment = {value!r}: not a valid "
                    f"WD_ALIGN_PARAGRAPH integer. Expected one of "
                    f"{sorted([0, 1, 2, 3, 4, 5, 7, 8, 9])}.",
                )
            alignment_str = coerced.to_superdoc()
        elif isinstance(value, str):
            # python-docx coerces strings through the enum and raises
            # on misses. Was: ``str(value).lower()`` shipped any value
            # to wire — SuperDoc's permissive parser swallowed unknowns
            # silently, producing apparent success with no state
            # change.
            try:
                alignment_str = WD_ALIGN_PARAGRAPH(value).to_superdoc()
            except (ValueError, KeyError) as exc:
                raise ValueError(
                    f"Paragraph.alignment = {value!r}: not a valid "
                    f"WD_ALIGN_PARAGRAPH. Expected one of "
                    f"{[m.value for m in WD_ALIGN_PARAGRAPH]}."
                ) from exc
        else:
            raise TypeError(
                f"Paragraph.alignment requires WD_ALIGN_PARAGRAPH, "
                f"int, str, or None; got {type(value).__name__}",
            )
        from docx._postproc import normalize_alignment

        ooxml_align = normalize_alignment(alignment_str)
        if self._check_cell_inner("alignment", alignment=ooxml_align):
            return
        run_sync(
            self._session.doc.format.paragraph.set_alignment(
                {
                    "target": self._block_target(),
                    "alignment": alignment_str,
                },
            ),
        )

    @property
    def paragraph_format(self) -> "ParagraphFormat":
        from docx.text.parfmt import ParagraphFormat

        return ParagraphFormat(self)

    @staticmethod
    def _extract_hyperlink_target(run_data: dict) -> str | None:
        """Extract the URL/anchor target from a SuperDoc run dict.

        Accepts both legacy (``href`` string) and current
        (``hyperlink`` object with ``url``/``target``) shapes. Returns
        the resolved target string or ``None`` if the run has no link.
        """
        hl = run_data.get("hyperlink") or run_data.get("href")
        if isinstance(hl, str) and hl:
            return hl
        if isinstance(hl, dict):
            maybe = hl.get("url") or hl.get("target")
            if isinstance(maybe, str) and maybe:
                return maybe
        return None

    @property
    def hyperlinks(self) -> list:
        """Return the hyperlinks in this paragraph.

        python-docx 1.x exposes one :class:`Hyperlink` per logical
        ``<w:hyperlink>`` element — i.e. a *wrapper* around the run
        sequence that shares a target. SuperDoc 1.8.x models a
        hyperlink as a mark on each run (no wrapper node), so the SDK
        coalesces consecutive same-target runs into one
        :class:`Hyperlink` carrying multiple segments. Offsets are
        computed against SuperDoc's text-address space (same rules as
        :attr:`Paragraph.runs`).

        Coalescing groups *consecutive* same-target runs only.
        Hyperlinks that are split by a non-link run (or a different-
        target run) appear as separate :class:`Hyperlink` instances,
        matching the OOXML wrapper semantics.
        """
        from docx.text.hyperlink import Hyperlink

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        out: list[Hyperlink] = []
        # Accumulator for the in-flight hyperlink span. None when we're
        # not currently inside a hyperlink. (target, segments)
        current: tuple[str, list[tuple[dict, tuple[int, int]]]] | None = None
        offset: int = 0
        for inline in _walk_inlines(info):
            run_data: dict | None = None
            text: str = ""
            maybe_run = inline.get("run")
            if isinstance(maybe_run, dict):
                maybe_text = maybe_run.get("text")
                if isinstance(maybe_text, str):
                    run_data = maybe_run
                    text = maybe_text
            elif inline.get("type") == "text":
                maybe_text = inline.get("text")
                if isinstance(maybe_text, str):
                    run_data = inline
                    text = maybe_text
            elif inline.get("type") in ("tab", "lineBreak"):
                # Tab / line-break inlines break a hyperlink run sequence
                # in OOXML (they can't live inside <w:hyperlink>), so flush
                # any in-flight span before advancing the offset.
                if current is not None:
                    target, segments = current
                    out.append(
                        Hyperlink(
                            paragraph=self,
                            target=target,
                            segments=segments,
                        ),
                    )
                    current = None
                offset += 1
                continue

            if run_data is None:
                # Unknown inline shape — terminate any in-flight span.
                if current is not None:
                    target, segments = current
                    out.append(
                        Hyperlink(
                            paragraph=self,
                            target=target,
                            segments=segments,
                        ),
                    )
                    current = None
                continue

            target = self._extract_hyperlink_target(run_data)
            start = offset
            end = offset + len(text)
            offset = end

            if target is None:
                # Plain run — terminate any in-flight span.
                if current is not None:
                    cur_target, cur_segments = current
                    out.append(
                        Hyperlink(
                            paragraph=self,
                            target=cur_target,
                            segments=cur_segments,
                        ),
                    )
                    current = None
                continue

            # Hyperlinked run. Extend the current span if it shares a
            # target, otherwise close it and start a new one.
            if current is not None and current[0] == target:
                current[1].append((run_data, (start, end)))
            else:
                if current is not None:
                    cur_target, cur_segments = current
                    out.append(
                        Hyperlink(
                            paragraph=self,
                            target=cur_target,
                            segments=cur_segments,
                        ),
                    )
                current = (target, [(run_data, (start, end))])

        if current is not None:
            target, segments = current
            out.append(
                Hyperlink(
                    paragraph=self,
                    target=target,
                    segments=segments,
                ),
            )
        return out

    @property
    def contains_page_break(self) -> bool:
        """python-docx 1.x: True if the paragraph contains a hard page break."""
        return "\f" in self.text

    @property
    def rendered_page_breaks(self) -> "list[RenderedPageBreak]":
        """Return a list of :class:`RenderedPageBreak` proxies for each
        hard page break in this paragraph.

        python-docx 1.x exposes this for inspecting Word's rendered
        page-break positions inside a paragraph. We surface a minimal
        proxy with a ``preceding_paragraph_text`` property so the
        common ``len(p.rendered_page_breaks)`` pattern works. The
        underlying break is detected via the ``\\f`` sentinel in the
        paragraph text.
        """
        text = self.text
        if "\f" not in text:
            return []
        out: list[RenderedPageBreak] = []
        offset = 0
        for segment in text.split("\f")[:-1]:
            offset += len(segment)
            out.append(RenderedPageBreak(
                paragraph=self,
                offset=offset,
                preceding_text=segment,
            ))
            offset += 1  # account for the \f itself
        return out

    def iter_inner_content(self):
        """Yield each inline child of the paragraph in document order.

        python-docx 1.x signature:
        ``Iterator[Run | Hyperlink | RenderedPageBreak]``.

        Order matches SuperDoc's inline list. Hyperlinks group their
        underlying runs, so a hyperlinked span yields a single
        :class:`Hyperlink` rather than the wrapped runs. Plain text
        runs yield :class:`Run` instances; runs whose text contains
        the form-feed (``\\f``) page-break sentinel split into their
        text-before-break and text-after-break halves, with a
        :class:`RenderedPageBreak` yielded between them. Items with
        no text content are skipped, matching python-docx behaviour.
        """
        from docx.text.hyperlink import Hyperlink
        from docx.text.pagebreak import RenderedPageBreak
        from docx.text.run import Run

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        inlines = _walk_inlines(info)
        offset: int = 0
        # Accumulator for the in-flight hyperlink span. Mirrors the
        # coalesce logic in ``Paragraph.hyperlinks`` — yields a single
        # :class:`Hyperlink` per logical OOXML ``<w:hyperlink>``
        # wrapper, even when SuperDoc stored it as multiple
        # consecutive same-target runs.
        current: tuple[str, list[tuple[dict, tuple[int, int]]]] | None = None

        def _flush_current():
            nonlocal current
            if current is None:
                return None
            target, segments = current
            current = None
            return Hyperlink(
                paragraph=self,
                target=target,
                segments=segments,
            )

        for inline in inlines:
            if not isinstance(inline, dict):
                continue
            # Two SuperDoc inline shapes are accepted by the rest of the
            # paragraph code (``_extract_text``, ``runs``):
            #   1. typed-wrapper:    {"run": {"text": "...", ...}}
            #   2. ProseMirror flat: {"type": "text", "text": "...", ...}
            # Both must yield runs from iter_inner_content. The flat
            # shape was dropped in an earlier rewrite — restore it.
            run_data: dict | None = None
            text: object = None
            maybe_run = inline.get("run")
            if isinstance(maybe_run, dict):
                maybe_text = maybe_run.get("text")
                if isinstance(maybe_text, str):
                    run_data = maybe_run
                    text = maybe_text
            elif inline.get("type") == "text":
                maybe_text = inline.get("text")
                if isinstance(maybe_text, str):
                    run_data = inline
                    text = maybe_text
            if run_data is None or not isinstance(text, str):
                # Unknown inline shape — close any in-flight hyperlink span.
                flushed = _flush_current()
                if flushed is not None:
                    yield flushed
                continue
            target = self._extract_hyperlink_target(run_data)
            if target:
                start = offset
                offset += len(text)
                segment = (run_data, (start, start + len(text)))
                if current is not None and current[0] == target:
                    current[1].append(segment)
                else:
                    flushed = _flush_current()
                    if flushed is not None:
                        yield flushed
                    current = (target, [segment])
                continue
            # Non-link run — close any in-flight hyperlink before yielding.
            flushed = _flush_current()
            if flushed is not None:
                yield flushed
            # Split the run on `\f` page-break sentinels and yield a
            # RenderedPageBreak for each. Multiple breaks in the same
            # run produce multiple proxies.
            if "\f" not in text:
                start = offset
                offset += len(text)
                yield Run(
                    session=self._session,
                    block_id=self._node_id,
                    range_=(start, offset),
                    inline=run_data,
                    in_cell=self._in_cell,
                )
                continue
            parts = text.split("\f")
            for i, part in enumerate(parts):
                if part:
                    start = offset
                    offset += len(part)
                    yield Run(
                        session=self._session,
                        block_id=self._node_id,
                        range_=(start, offset),
                        inline=run_data,
                        in_cell=self._in_cell,
                    )
                if i < len(parts) - 1:
                    preceding = "".join(parts[: i + 1])
                    yield RenderedPageBreak(
                        paragraph=self,
                        offset=offset,
                        preceding_text=preceding,
                    )
                    offset += 1  # the \f itself

        # Tail-flush: a paragraph that ends on a hyperlinked run leaves
        # the in-flight span open. Yield it now so the wrapper isn't lost.
        flushed = _flush_current()
        if flushed is not None:
            yield flushed

    def _block_target(self) -> dict:
        """Build a {kind, nodeType, nodeId} target for paragraph-level ops.

        Uses the node_type cached at construction. This avoids an extra
        getNodeById round-trip that previously raced with Superdoc's
        mutation-commit pipeline and raised "Block X was not found" for
        blocks that had just been created by the same session.
        """
        return {
            "kind": "block",
            "nodeType": self._node_type,
            "nodeId": self._node_id,
        }

    def _cell_inner_add_run_via_cell_insert(
        self, text: str,
    ) -> "Run | None":
        """Materialize ``text`` in the parent cell via the
        ``_Cell.add_paragraph`` wire path, then return a fresh Run
        proxy carrying the new exported-paragraph address.

        This is the 0.13.0 fallback that closes the gap behind the
        agent's common ``fill_cell`` pattern:

        .. code-block:: python

            p = cell.add_paragraph("")     # in_cell=True, empty
            r = p.add_run("Hello world")   # text now lands in the cell
            r.bold = True                  # stashes to post-export

        Pre-0.13.0 the ``add_run`` returned a stub and the text was
        silently dropped. As of 0.13.0, when ``self._cell`` is set we
        ship a ``doc.insert(target=cell, placement=insideEnd,
        content=paragraph-fragment)`` instead — the same wire path
        ``_Cell.add_paragraph(text)`` uses. SuperDoc collapses the new
        paragraph into the cell's single template paragraph as an
        inline run; the exported DOCX expands each non-empty inline
        run into its own ``<w:p>``, so the agent ends up with one
        paragraph per ``add_run(text)`` call in the export.

        Returns ``None`` on failure (caller falls back to the
        warn-and-stub path so the surrounding batch survives).
        """
        from docx.document import _extract_inserted_node_id
        from docx.table import _Cell
        from docx.text.run import Run

        cell = self._cell
        if not isinstance(cell, _Cell):
            return None

        fragment: dict = {
            "kind": "paragraph",
            "paragraph": {
                "inlines": [{"kind": "run", "run": {"text": text}}],
            },
        }
        try:
            cell_id = cell._cell_id()
            result: object = run_sync(
                self._session.doc.insert(
                    {
                        "target": {
                            "kind": "block",
                            "nodeType": "tableCell",
                            "nodeId": cell_id,
                        },
                        "placement": "insideEnd",
                        "content": fragment,
                    },
                ),
            )
        except Exception:
            # Any wire failure: fall back to warn-and-stub so the
            # surrounding batch isn't taken down. ``add_run`` is a hot
            # path the agent calls many times per cell; one failure
            # cascading would be worse than the original behavior.
            return None

        node_id: str = ""
        if isinstance(result, dict):
            node_id = _extract_inserted_node_id(
                result, expected_type="paragraph",
            )
        # Same fallback as ``_Cell.add_paragraph``: SuperDoc may have
        # collapsed the new paragraph into the cell's template
        # paragraph, in which case the response shape doesn't carry a
        # fresh nodeId — borrow the cell's last inner paragraph id so
        # the Run proxy still anchors somewhere sensible.
        if not node_id:
            ids_after = cell._inner_paragraph_ids()
            if ids_after:
                node_id = ids_after[-1]
        if not node_id:
            return None

        ooxml_base = cell._ooxml_address_base()
        # ``new_para_idx`` follows the same logic as
        # ``_Cell.add_paragraph``: the exported DOCX expands each
        # non-empty inline run into its own ``<w:p>``, so the new
        # run's exported position is ``count_exported_paragraphs() - 1``.
        new_para_idx = max(0, cell._count_exported_paragraphs() - 1)
        ooxml_addr: tuple[int, int, int, int] | None = (
            (*ooxml_base, new_para_idx) if ooxml_base is not None else None
        )

        return Run(
            session=self._session,
            block_id=node_id,
            range_=(0, len(text)),
            paragraph=self,
            in_cell=True,
            cell_ooxml_address=ooxml_addr,
        )

    def add_run(
        self,
        text: "str | None" = None,
        style: "str | CharacterStyle | None" = None,
    ) -> "Run":
        """Append a run to this paragraph.

        Mirrors python-docx: ``text`` defaults to ``None`` (treated as
        empty), ``style`` accepts either a style id string or a
        :class:`CharacterStyle` instance. Per python-docx 1.2.0
        contract, ``text`` may include tab (``\\t``), newline
        (``\\n``), and carriage-return (``\\r``) characters; each
        becomes a real Word tab / line-break element rather than a
        literal character. The earlier impl sent the raw string to
        SuperDoc's text-insert which stored ``\\t`` and ``\\n`` as
        literal characters — broken parity.
        """
        from docx.styles.style import CharacterStyle
        from docx.text.run import Run

        # python-docx 1.x: ``text`` is ``str | None`` and raises
        # ``TypeError`` via lxml's ``_element_text.text = value`` for
        # non-str. Was: ``text or ""`` silently coerced 0/[]/False
        # to empty string and any truthy non-str (42, [1,2]) flowed
        # through into ``_insert_run_text_segments`` which would fail
        # with a confusing ``'int' object is not subscriptable`` deep
        # in the segment walk.
        if text is not None and not isinstance(text, str):
            raise TypeError(
                f"Paragraph.add_run text requires str or None; got "
                f"{type(text).__name__} {text!r}",
            )
        # python-docx 1.x's ``style`` argument: ``str | CharacterStyle
        # | None``. Was: ``str(style)`` silently shipped garbage like
        # ``"42"`` or ``"<__main__.MyStyle object at 0x...>"`` to wire.
        if (
            style is not None
            and not isinstance(style, str)
            and not isinstance(style, CharacterStyle)
        ):
            raise TypeError(
                f"Paragraph.add_run style requires str, CharacterStyle, "
                f"or None; got {type(style).__name__} {style!r}",
            )

        # Use the cached paragraph text length when known — every
        # avoided ``_node_text`` here drops one ``get_node_by_id`` HTTP
        # round-trip. Linear ``doc.add_paragraph(); p.add_run(...);
        # p.add_run(...)`` flows used to issue 2 queries plus 2 inserts
        # for those two runs; now it's just the 2 inserts.
        start: int = self._resolve_text_len()
        text_str: str = text or ""

        if self._in_cell:
            # SuperDoc 1.8.1 rejects ``doc.insert`` targeting a
            # text-range inside a cell-inner paragraph
            # (``Block <id> not found`` cascade-failure). But the
            # SAME ``doc.insert`` with ``target.nodeType="tableCell"``
            # and ``placement="insideEnd"`` works — it appends a new
            # paragraph fragment that SuperDoc collapses into the
            # cell's single template paragraph as an inline run.
            #
            # As of 0.13.0, when we have a back-ref to the parent
            # cell AND non-empty text, we materialize the text via
            # that cell-targeted insert path. The agent's
            # ``fill_cell``-style helper (``p = cell.add_paragraph
            # (""); r = p.add_run(text); r.bold = True``) now lands
            # the text in the live document, NOT just at export.
            #
            # Without text (``add_run("")``) or without a cell back-
            # ref (paragraph constructed outside _Cell), we fall back
            # to the pre-0.13.0 warn-and-stub behavior. The empty-
            # text case has no visible content to materialize, and
            # the no-cell-back-ref case can't address the cell
            # without one.
            if text_str and self._cell is not None:
                run_obj = self._cell_inner_add_run_via_cell_insert(text_str)
                if run_obj is not None:
                    if style is not None:
                        from docx.styles.style import CharacterStyle

                        style_id_inner: str = (
                            style.style_id
                            if isinstance(style, CharacterStyle)
                            else style
                        )
                        run_obj.style = style_id_inner
                    return run_obj
                # Fall through to the warn-and-stub path on failure
                # so the surrounding batch is preserved.
            if self._check_cell_inner("add_run"):
                return Run(
                    session=self._session,
                    block_id=self._node_id,
                    range_=(start, start),
                    paragraph=self,
                    in_cell=True,
                    cell_ooxml_address=self._cell_ooxml_address,
                )

        if text_str:
            self._insert_run_text_segments(text_str, start)
            self._text_len = start + len(text_str)

        run_obj: "Run" = Run(
            session=self._session,
            block_id=self._node_id,
            range_=(start, start + len(text_str)),
            paragraph=self,
            in_cell=self._in_cell,
            cell_ooxml_address=self._cell_ooxml_address,
        )
        if style is not None:
            style_id: str = (
                style.style_id if isinstance(style, CharacterStyle) else style
            )
            run_obj.style = style_id
        return run_obj

    def _insert_run_text_segments(self, text: str, start_offset: int) -> None:
        """Insert ``text`` at ``start_offset``, splitting tab and
        newline characters into separate inline ops so they round-trip
        as Word ``<w:tab/>`` / ``<w:br/>`` elements rather than
        literal characters.

        Each ``\\t`` advances the offset by one and emits an
        ``insert_tab``; each ``\\n`` or ``\\r`` advances by one and
        emits an ``insert_line_break``. Between control characters
        the literal text segments go through ``doc.insert`` with the
        text type.
        """
        offset = start_offset
        i = 0
        n = len(text)
        while i < n:
            j = i
            while j < n and text[j] not in ("\t", "\n", "\r"):
                j += 1
            segment = text[i:j]
            if segment:
                cursor: dict = {
                    "kind": "text",
                    "blockId": self._node_id,
                    "offset": offset,
                }
                run_sync(
                    self._session.doc.insert(
                        {
                            "target": {
                                "kind": "selection",
                                "start": cursor,
                                "end": cursor,
                            },
                            "value": segment,
                            "type": "text",
                        },
                    ),
                )
                offset += len(segment)
            if j >= n:
                break
            ch = text[j]
            if ch == "\t":
                run_sync(
                    self._session.doc.insert_tab(
                        {"blockId": self._node_id, "offset": offset},
                    ),
                )
            else:
                run_sync(
                    self._session.doc.insert_line_break(
                        {"blockId": self._node_id, "offset": offset},
                    ),
                )
            offset += 1
            i = j + 1

    @athena_extension(
        issue=74,
        description="Paragraph.add_hyperlink — appends a hyperlinked run.",
    )
    def add_hyperlink(
        self,
        text: str,
        address: str,
        *,
        fragment: str | None = None,
        tooltip: str | None = None,
    ) -> "Hyperlink":
        """Append a hyperlinked text run to this paragraph.

        Athena extension beyond python-docx 1.x. Upstream's
        ``docx.text.hyperlink.Hyperlink`` is read-only — issue #74
        ("Paragraph.add_hyperlink()") has been open since 2014 and is
        the single most-requested missing feature. See
        ``python-sdk/CLAUDE.md`` § *Intentional deviations (additions /
        different semantics)*.

        - ``address`` is the URL portion (``""`` for an internal
          jump that names a bookmark via ``fragment``).
        - ``fragment`` is the anchor portion (``"glossary"`` for
          ``#glossary``). For internal jumps, ``address=""`` +
          ``fragment="MyBookmark"`` produces a Word-style cross-document
          reference.
        - ``tooltip`` is the hover text Word shows on the link.

        Returns a :class:`Hyperlink` proxy whose ``runs`` includes the
        newly appended run.
        """
        from docx.commands import CreateHyperlink
        from docx.text.hyperlink import Hyperlink

        if not isinstance(text, str):
            raise TypeError(
                f"Paragraph.add_hyperlink text requires str; got "
                f"{type(text).__name__} {text!r}",
            )
        if not isinstance(address, str):
            raise TypeError(
                f"Paragraph.add_hyperlink address requires str; got "
                f"{type(address).__name__} {address!r}",
            )
        if fragment is not None and not isinstance(fragment, str):
            raise TypeError(
                f"Paragraph.add_hyperlink fragment requires str or None; "
                f"got {type(fragment).__name__} {fragment!r}",
            )

        start: int = self._resolve_text_len()
        end_offset: int = start + len(text)
        url = address
        if fragment:
            url = f"{address}#{fragment}" if address else f"#{fragment}"

        # CreateHyperlink against a cell-inner paragraph hits the same
        # addressing gap as the format setters (BlockNotFoundError
        # with ``applied: []`` on flush). Empirically, ``add_run(text)``
        # on the same paragraph also fails — the cell-inner paragraph's
        # block id is a valid ``target`` for the ``doc.insert`` that
        # just created it but NOT a valid target for subsequent
        # ``Insert`` ops.
        #
        # As of athena-python-docx 0.13.0 we stash the URL + visible
        # text in :class:`docx._postproc.PostExportOps` so the
        # post-export OOXML rewrite can append a real
        # ``<w:hyperlink>`` (plus a matching rels-file
        # ``Relationship`` for external URLs) at export time. The
        # live Olympus rendering still won't show the hyperlink (no
        # wire op committed), but the exported ``.docx`` carries
        # both the clickable link AND the visible text — closing
        # the per-run dropped-content gap the agent's IB-style memo
        # patterns hit when peppering reference URLs into table
        # cells.
        if self._in_cell:
            warnings.warn(
                "Paragraph.add_hyperlink on a cell-inner paragraph: "
                + _CELL_INNER_WORKAROUND
                + " The hyperlink text + URL are preserved at "
                "``Document.export_docx`` time via a post-export "
                "OOXML rewrite (a real ``<w:hyperlink>`` is "
                "appended to the cell paragraph plus a matching "
                "rels-file entry). The live Olympus rendering "
                "still won't show the link until SuperDoc lands a "
                "cell-inner hyperlink wire op.",
                CellInnerFormatNotSupportedWarning,
                stacklevel=2,
            )
            if self._cell_ooxml_address is not None:
                from docx._postproc import CellAddress

                ops = getattr(self._session, "_post_export_ops", None)
                if ops is not None:
                    tbl_idx, row, col, para_idx = self._cell_ooxml_address
                    ops.add_cell_hyperlink(
                        CellAddress(
                            table_doc_index=tbl_idx,
                            row=row,
                            col=col,
                            paragraph_index=para_idx,
                        ),
                        text=text,
                        url=url,
                        fragment=fragment,
                        tooltip=tooltip,
                    )
            # Return a stub Hyperlink whose ``runs`` is empty (the
            # text never lands at the wire layer, so there's no
            # addressable Run proxy to surface). Callers that
            # inspect the returned object see the target — useful
            # for chained ``.tooltip = ...`` access — but reads
            # against the live document state won't find the link
            # until export.
            run_dict = {"text": text, "hyperlink": {"url": url, "target": url}}
            return Hyperlink(
                paragraph=self,
                target=url,
                run=run_dict,
                range_=(start, start),
            )

        cursor: dict = {
            "kind": "text",
            "blockId": self._node_id,
            "offset": start,
        }
        cmd = CreateHyperlink(
            address=address,
            fragment=fragment,
            tooltip=tooltip,
            text=text,
            at={"kind": "selection", "start": cursor, "end": cursor},
        )
        run_sync(self._session.send_command(cmd))
        self._text_len = end_offset

        run_dict = {"text": text, "hyperlink": {"url": url, "target": url}}
        return Hyperlink(
            paragraph=self,
            target=url,
            run=run_dict,
            range_=(start, end_offset),
        )

    @athena_extension(
        issue=425,
        description="Paragraph.add_bookmark — zero-width anchor at paragraph end.",
    )
    def add_bookmark(self, name: str) -> "Bookmark":
        """Wrap a zero-width bookmark anchor at the *end* of this
        paragraph. To wrap an existing range use
        :meth:`Document.add_bookmark` with a ``runs`` argument.

        Athena extension beyond python-docx 1.x — see
        ``python-sdk/CLAUDE.md`` § *Intentional deviations*. Bookmarks
        anchor cross-references (REF fields), hyperlinks (``#name``),
        captions, and TOC entries. python-docx upstream has no
        bookmark API (issue #425, open since 2017).
        """
        from docx.bookmarks import Bookmark
        from docx.commands import CreateBookmark

        if not isinstance(name, str) or not name:
            raise ValueError(
                f"add_bookmark requires a non-empty string name; got {name!r}",
            )
        offset = self._resolve_text_len()
        cursor: dict = {
            "kind": "text",
            "blockId": self._node_id,
            "offset": offset,
        }
        cmd = CreateBookmark(
            name=name,
            at={"kind": "selection", "start": cursor, "end": cursor},
        )
        result = run_sync(self._session.send_command(cmd))
        bookmark_id = ""
        if isinstance(result, dict):
            bookmark_id = str(result.get("id") or result.get("bookmarkId") or "")
        return Bookmark(
            session=self._session,
            bookmark_id=bookmark_id,
            name=name,
        )

    @athena_extension(
        issue=676,
        description="Paragraph.add_caption — auto-numbered caption (SEQ field).",
    )
    def add_caption(
        self,
        text: str,
        *,
        label: str = "Figure",
        bookmark: str | None = None,
        style: "str | ParagraphStyle | None" = None,
    ) -> "Paragraph":
        """Insert a caption paragraph after this paragraph.

        Athena extension beyond python-docx 1.x — issue #676 has been
        open since 2018. The caption is a paragraph styled with
        ``"Caption"`` containing ``"{label} {SEQ}: {text}"`` where the
        ``SEQ`` field auto-numbers per-label. When ``bookmark`` is
        provided, the caption is wrapped with a bookmark of that name
        so cross-references can target it.
        """
        from docx.commands import CreateCaption
        from docx.document import _extract_inserted_node_id

        if not isinstance(text, str):
            raise TypeError(
                f"Paragraph.add_caption text requires str; got "
                f"{type(text).__name__} {text!r}",
            )
        cmd = CreateCaption(
            label=label,
            text=text,
            at={"kind": "after", "target": self._block_target()},
            bookmark=bookmark,
            style_id=(
                style.style_id if hasattr(style, "style_id") else (
                    style if isinstance(style, str) else None
                )
            ),
        )
        result = run_sync(self._session.send_command(cmd))
        node_id = ""
        if isinstance(result, dict):
            node_id = _extract_inserted_node_id(result, expected_type="paragraph")
        if not node_id:
            raise RuntimeError(
                f"SuperDoc did not return nodeId for add_caption: {result!r}",
            )
        return Paragraph(
            session=self._session, node_id=node_id, node_type="paragraph",
        )

    @property
    @athena_extension(issue=471, description="Paragraph.list_id (numbering numId).")
    def list_id(self) -> str | None:
        """Return the OOXML ``numId`` (numbering definition id) when
        this paragraph is a list item.

        Athena extension beyond python-docx 1.x — issue #471 (13 👍)
        demands access to list metadata. ``None`` for non-list
        paragraphs. Pair with :attr:`list_level` and
        :attr:`list_format` for full inspection.
        """
        info = self._list_info()
        return info.get("numId") if info else None

    @property
    @athena_extension(issue=471, description="Paragraph.list_level (zero-indexed nesting depth).")
    def list_level(self) -> int | None:
        """Zero-indexed list nesting level (``ilvl``) when this
        paragraph is a list item, else ``None``.

        Athena extension beyond python-docx 1.x — see
        ``python-sdk/CLAUDE.md`` § *Intentional deviations*.
        """
        info = self._list_info()
        if not info:
            return None
        v = info.get("level")
        return int(v) if isinstance(v, (int, float)) else None

    @property
    @athena_extension(issue=471, description="Paragraph.list_format (decimal/lowerLetter/bullet/...).")
    def list_format(self) -> str | None:
        """Numbering format (``"decimal"``, ``"lowerLetter"``,
        ``"upperRoman"``, ``"bullet"``, …) when this paragraph is a
        list item.

        Athena extension beyond python-docx 1.x.
        """
        info = self._list_info()
        return info.get("format") if info else None

    @property
    @athena_extension(issue=471, description="Paragraph.list_number (Word's rendered display number).")
    def list_number(self) -> str | None:
        """Current list-item display number (e.g. ``"3"``, ``"III"``,
        ``"c"``) — Word's rendered value, accounting for restarts and
        skipped items.

        Athena extension beyond python-docx 1.x. ``None`` for
        non-list paragraphs.
        """
        info = self._list_info()
        if not info:
            return None
        v = info.get("display") or info.get("value")
        return str(v) if v is not None else None

    def _list_info(self) -> dict | None:
        """Cache-then-fetch the numbering record for this paragraph."""
        cache = getattr(self, "_list_info_cache", None)
        if cache is not None:
            return cache or None
        from docx.commands import NumberingGet
        try:
            result = run_sync(
                self._session.send_command(NumberingGet(block_id=self._node_id))
            )
        except Exception:
            self._list_info_cache = {}
            return None
        info = result if isinstance(result, dict) else {}
        self._list_info_cache = info
        return info or None

    def clear(self) -> "Paragraph":
        """Clear the paragraph's text content."""
        self.text = ""
        return self

    def insert_paragraph_before(
        self,
        text: str | None = None,
        style: "str | ParagraphStyle | None" = None,
    ) -> "Paragraph":
        """Insert a new paragraph directly before this one."""
        from docx.styles.style import ParagraphStyle

        # python-docx 1.x: ``text`` is ``str | None`` and raises
        # ``TypeError`` via lxml on non-str. Was: ``text or ""``
        # silently coerced falsy values to empty string and let truthy
        # non-strings (42, [1, 2]) flow to wire.
        if text is not None and not isinstance(text, str):
            raise TypeError(
                f"Paragraph.insert_paragraph_before text requires str "
                f"or None; got {type(text).__name__} {text!r}",
            )
        # ``style`` is ``str | ParagraphStyle | None``. Was: any value
        # got passed to ``Paragraph.style = style`` later, which has
        # its own catch-all str() coercion. Reject up-front.
        if (
            style is not None
            and not isinstance(style, str)
            and not isinstance(style, ParagraphStyle)
        ):
            raise TypeError(
                f"Paragraph.insert_paragraph_before style requires "
                f"str, ParagraphStyle, or None; got "
                f"{type(style).__name__} {style!r}",
            )
        result: object = run_sync(
            self._session.doc.create.paragraph(
                {
                    "text": text or "",
                    "at": {"kind": "before", "target": self._block_target()},
                },
            ),
        )
        from docx.document import _extract_inserted_node_id

        if isinstance(result, dict):
            node_id: str = _extract_inserted_node_id(
                result, expected_type="paragraph",
            )
        else:
            node_id = ""
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return nodeId for insert_paragraph_before: {result!r}",
            )
        new_para = Paragraph(
            session=self._session, node_id=node_id, node_type="paragraph",
        )
        if style:
            new_para.style = style
        return new_para


from docx.text.pagebreak import RenderedPageBreak as RenderedPageBreak  # noqa: E402,F401

