"""Exception types for athena-python-docx."""

from __future__ import annotations


class DocxError(Exception):
    """Base class for all athena-python-docx errors.

    When the underlying failure is a 207 partial-batch failure, the
    exception carries the ``applied`` array from the server response
    on ``self.partial_applied``. Buffer-level code uses this to rewrite
    ``proxy_id_refs`` for the successful prefix even when the batch
    raises — without that, every Create that succeeded server-side
    leaves its Python proxy stuck on the client UUID, and the next
    batch ships the dead id to the server. That cascade is what turned
    one cell-paragraph mistake into thirteen ``Block not found`` errors
    in the preview-session thread_bafba02b. See
    ``docx-studio/PERFORMANCE_BATCHING_ANALYSIS.md`` § "Partial-failure
    cascade" for the full investigation.

    The field is a list of ``{index, type, result}`` dicts that mirror
    the server's ``applied`` shape; empty when no commands committed
    before the failure or when the response wasn't a 207.

    We *don't* take ``partial_applied`` as a constructor kwarg because
    ``docx.exceptions.InvalidSpanError`` (a parity stub) multiply-
    inherits from this class plus ``PythonDocxError`` and would pick
    up the drifted signature — failing the parity comparator's
    ``ctor_signature_drift`` check against upstream
    ``python-docx``'s no-arg ``InvalidSpanError(Exception)``. Use the
    :meth:`with_partial_applied` factory helper at raise sites instead.
    """

    def __getattr__(self, name: str) -> list[dict]:
        """Lazy default for ``partial_applied`` — returns an empty list
        when the attribute hasn't been set via :meth:`with_partial_applied`.

        Using ``__getattr__`` (only called when ordinary attribute
        lookup misses) instead of a class-level mutable default avoids
        the footgun where ``exc.partial_applied.append(x)`` on a
        legacy-raised error would mutate a shared list and make every
        subsequent ``DocxError`` look partially applied. Each call here
        returns a fresh empty list; mutating it has no cross-instance
        effect.
        """
        if name == "partial_applied":
            return []
        # Match Python's default ``AttributeError`` for unknown attrs.
        raise AttributeError(
            f"{type(self).__name__!r} object has no attribute {name!r}",
        )

    def with_partial_applied(
        self,
        applied: list[dict] | None,
    ) -> "DocxError":
        """Attach a ``partial_applied`` prefix and return ``self``.

        Designed to chain at the raise site so the constructor
        signature stays upstream-compatible::

            raise DocxError("...").with_partial_applied(prefix)
        """
        if applied:
            # Writes to ``self.__dict__`` — subsequent reads bypass
            # ``__getattr__`` entirely and see the per-instance list.
            self.partial_applied = list(applied)
        return self


class SessionError(DocxError):
    """Raised when the Superdoc SDK session cannot be established or used."""


class AuthenticationError(SessionError):
    """Raised when Keryx rejects the collab token."""


class UnsupportedProviderError(SessionError):
    """Raised when the asset is on ysweet instead of yhub.

    Phase 1 only supports yhub; ysweet-routed assets must be migrated first.
    """


class DocxStudioTemporarilyUnavailable(SessionError):
    """Raised when docx-studio returns 502/503/504 after the SDK's retry
    budget is exhausted.

    Distinct from generic :class:`DocxError` / :class:`SessionError` so
    agent code can identify a transient upstream failure (the studio is
    down or restarting — retry the whole tool call later) vs. a permanent
    error in the script or document state. The ``http_status`` attribute
    carries the underlying status code; ``retry_after_seconds`` is the
    server's ``Retry-After`` hint when present.
    """

    def __init__(
        self,
        message: str,
        *,
        http_status: int,
        retry_after_seconds: float | None = None,
    ) -> None:
        super().__init__(message)
        self.http_status: int = http_status
        self.retry_after_seconds: float | None = retry_after_seconds


class DocumentClosedError(DocxError):
    """Raised when operating on a closed Document."""


class LocalSaveTargetNotSupportedError(DocxError, NotImplementedError):
    """Raised when ``Document.save(path_or_stream=...)`` is called with a
    non-None argument.

    The SDK is asset-backed: edits flush in place against the Y.Doc, so
    there is no local file or stream to write to. The bare ``doc.save()``
    no-arg form remains supported as the documented deviation from stock
    python-docx (see :meth:`docx.document.Document.save`). To get a
    ``.docx`` file out, use Olympus's Export DOCX action — the SuperDoc
    session already has the bytes the caller wanted.

    Subclasses :class:`NotImplementedError` so a generic
    ``except NotImplementedError`` catches it without importing the
    typed class.
    """


class NestedTableNotSupportedError(DocxError, NotImplementedError):
    """Raised when ``_Cell.add_table(...)`` is called.

    SuperDoc 1.8.1 cannot place a new top-level block inside an
    existing ``tableCell`` — ``create.table`` rejects a cell-inner
    paragraph anchor with ``INVALID_TARGET - Expected paragraph:<id>
    but found tableCell:<id>``, and there is no ``create.table``
    anchor shape ("inside this cell") that addresses cell content
    directly. The ``doc.insert``-based workaround used by
    ``_Cell.text`` / ``_Cell.add_paragraph`` requires a
    ``nestingPolicy: {tables: "allow"}`` flag and a table content
    fragment that aren't yet plumbed through the docx-studio command
    bus, so this entire method is unsupported until upstream
    SuperDoc lands the cell-inner addressing fix tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 13.

    Subclasses :class:`NotImplementedError` so a generic
    ``except NotImplementedError`` catches it without importing the
    typed class.
    """


class ValidationError(DocxError):
    """Raised when SDK-level validation fails (bad args, out-of-range indices)."""


class NotFoundError(DocxError):
    """Raised when a server-side lookup determines that the addressed
    entity does not exist (comment id, node id, …).

    Distinct from :class:`DocxError` so callers can speculatively read
    (``Comments.get``, future ``find_by_id`` patterns) and coerce a
    typed miss to ``None`` without swallowing real transport/auth
    failures.
    """

    def __init__(self, message: str, payload: dict | None = None) -> None:
        super().__init__(message)
        self.payload: dict = payload or {}


class BlockNotFoundError(NotFoundError):
    """Raised when SuperDoc reports ``Block "<type>:<id>" was not found``.

    Most commonly fires when paragraph-format operations target a
    paragraph node nested inside a table cell. SuperDoc 1.8.1's
    ``format.paragraph.setAlignment`` / ``setStyle`` / ``setIndentation``
    / ``setSpacing`` and ``doc.insert``-into-block-target ops don't
    traverse into table cells: the inner paragraph's id is returned by
    ``cell.getNodeById`` but isn't a valid top-level addressable block.

    The agent-facing workaround is:

        cell.text = "value"     # materializes the cell's paragraph as
                                # a real block once content lands.
        p = cell.paragraphs[0]  # the *post-materialization* paragraph
        p.alignment = ...       # now resolves.

    See ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § "cell-inner
    paragraph addressing" for the upstream ask.
    """

    @property
    def block_id(self) -> str | None:
        """Best-effort extraction of the missing block id from the SuperDoc
        error message. Returns ``None`` when the prefix can't be parsed.
        """
        msg = self.payload.get("message")
        if not isinstance(msg, str):
            return None
        # SuperDoc formats the message as ``Block "<type>:<uuid>" was not
        # found.`` (or ``Block "<uuid>" not found.`` for some shapes) —
        # extract whatever sits between the quotes, then strip an optional
        # ``<type>:`` prefix so callers can compare against bare ids.
        start = msg.find('"')
        end = msg.find('"', start + 1) if start >= 0 else -1
        if start < 0 or end <= start:
            return None
        quoted = msg[start + 1 : end]
        if ":" in quoted:
            return quoted.split(":", 1)[1]
        return quoted
