"""athena-python-docx — drop-in replacement for python-docx.

Calls translate into Superdoc SDK operations against a Keryx Y.Doc.
See CLAUDE.md for the API parity contract.
"""

from __future__ import annotations

__version__ = "0.13.0"

from docx.api import Document
from docx._buffer import flush_all
# Re-exports python-docx ships at docx top-level for convenience.
from docx.shared import Emu, Inches, Pt, Cm, Mm, Twips, Length, RGBColor

__all__ = [
    "Document",
    "Emu",
    "Inches",
    "Pt",
    "Cm",
    "Mm",
    "Twips",
    "Length",
    "RGBColor",
    "flush_all",
    "__version__",
]


# ---------------------------------------------------------------------------
# Athena-extension modules (no python-docx upstream parity surface). These
# are documented in python-sdk/CLAUDE.md § "Intentional deviations (additions
# / different semantics)" so the parity ratchet at tests/parity/ doesn't
# regress them. We don't auto-import them here because every one adds
# import-time cost for the common ``Document(asset_id)`` path; import the
# specific module you need:
#
#     from docx.bookmarks import Bookmark
#     from docx.fields import Field
#     from docx.footnotes import Footnote, Endnote
#     from docx.toc import TableOfContents
#     from docx.charts import Chart
#     from docx.math import MathEquation
#     from docx.sdt import ContentControl
# ---------------------------------------------------------------------------
