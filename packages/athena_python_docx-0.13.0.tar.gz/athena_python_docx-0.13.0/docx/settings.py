"""Document Settings — python-docx ``docx.settings.Settings``.

Most Word app settings are not surfaced by SuperDoc, so this proxy is
intentionally minimal. The fields that ARE exposed have one-to-one
SuperDoc semantics:

  * ``odd_and_even_pages_header_footer`` — toggles the document-level
    ``<w:evenAndOddHeaders/>`` flag via SuperDoc 1.8.1's
    ``doc.sections.setOddEvenHeadersFooters`` (doc-level despite its
    namespace — see ``commands.SetSectionsOddEvenHeadersFooters``).
  * ``track_revisions`` — alias for :attr:`docx.document.Document.track_revisions`.
    python-docx upstream stores this as ``<w:trackChanges/>`` on
    ``<w:settings>``; we keep the same property name so user code that
    does ``doc.settings.track_revisions = True`` works against either
    implementation.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._batching import run_sync

if TYPE_CHECKING:
    from docx.client import Session
    from docx.document import Document


class PendingSettingsMutationWarning(UserWarning):
    """Retained for backwards compatibility with code that catches
    this warning. As of SDK 0.6.3 / SuperDoc 1.8.1 the setters that
    used to emit this warning now persist through the wire, so the
    class is no longer raised by the SDK. Kept exported so handlers
    using ``warnings.catch_warnings(record=True)`` don't see import
    errors. New persistence-pending warnings should subclass
    :class:`UserWarning` directly with their own class.
    """


class Settings:
    def __init__(
        self,
        *,
        session: "Session",
        document: "Document | None" = None,
    ) -> None:
        self._session: "Session" = session
        self._document: "Document | None" = document
        self._odd_and_even_pages_header_footer: bool = False

    @property
    def odd_and_even_pages_header_footer(self) -> bool:
        return self._odd_and_even_pages_header_footer

    @odd_and_even_pages_header_footer.setter
    def odd_and_even_pages_header_footer(self, value: bool) -> None:
        enabled = bool(value)
        run_sync(
            self._session.doc.sections.set_odd_even_headers_footers(
                {"enabled": enabled},
            ),
        )
        self._odd_and_even_pages_header_footer = enabled

    # --- Track changes alias (Athena: forwards to Document.track_revisions) ---

    @property
    def track_revisions(self) -> bool:
        """Whether the document is currently in track-changes mode.

        Mirrors python-docx 1.x's planned property — upstream stores
        the flag as a child element on ``<w:settings>``; we proxy
        directly to :attr:`docx.document.Document.track_revisions` so
        the two surfaces stay in sync.
        """
        if self._document is None:
            return False
        return self._document.track_revisions

    @track_revisions.setter
    def track_revisions(self, value: bool) -> None:
        if self._document is None:
            raise RuntimeError(
                "Settings.track_revisions has no Document to forward to. "
                "This Settings proxy was constructed without a `document=` "
                "reference; access Document.track_revisions directly.",
            )
        self._document.track_revisions = bool(value)

    @property
    def element(self) -> None:
        raise AttributeError(
            "Settings.element is not surfaced by athena-python-docx — "
            "the SDK is HTTP-only and doesn't expose lxml elements. "
            "See python-sdk/CLAUDE.md § 'Intentionally omitted'."
        )


__all__ = ["Settings", "PendingSettingsMutationWarning"]
