"""``docx.comments`` — python-docx parity module for comments.

A *comment* in Word is a ``BlockItemContainer`` (paragraphs + tables)
attached to one or more :class:`Run` ranges via
``<w:commentRangeStart>`` / ``<w:commentRangeEnd>`` markers. Upstream
exposes:

  * :class:`Comment` — a single comment thread (with author, initials,
    timestamp, comment_id, and the same paragraph/table surface as
    ``Document``).
  * :class:`Comments` — collection. ``doc.comments`` returns one;
    iterable; supports ``add_comment(text, author, initials)`` and
    ``get(comment_id)``.
  * :meth:`Document.add_comment` — convenience wrapper that resolves
    a runs-anchored target before forwarding to
    :meth:`Comments.add_comment`.
  * :meth:`Run.mark_comment_range` — patches an existing comment to
    include the run pair as its anchor target.

athena-python-docx wires these to SuperDoc 1.7's ``doc.comments.*``
ops via the typed Command bus (``CommentsCreate``, ``CommentsList``,
``CommentsGet``, ``CommentsPatch``, ``CommentsDelete``). The
multi-paragraph "comment is a BlockItemContainer" surface (where a
single comment can contain multiple paragraphs / tables) isn't
supported — SuperDoc models a comment as a single ``text`` body, so
``Comment.add_paragraph`` / ``Comment.add_table`` /
``Comment.iter_inner_content`` raise
:class:`CommentsNotImplementedError`. Single-text-body comments work
end-to-end.
"""

from __future__ import annotations

import warnings
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.errors import DocxError, NotFoundError

if TYPE_CHECKING:
    from collections.abc import Iterator, Sequence

    from docx.client import Session
    from docx.shared import Length
    from docx.styles.style import ParagraphStyle
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    from docx.text.run import Run


class PendingCommentMetadataWarning(UserWarning):
    """Emitted when ``Comment.author`` or ``Comment.initials`` is set.

    SuperDoc treats author/initials as immutable metadata derived
    from the session credentials at create-time. The assignment is
    stashed on the in-process instance for read-back parity but is
    NOT persisted via comments.patch. Tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 7.
    """


def _warn_comment_metadata(prop: str) -> None:
    warnings.warn(
        f"Comment.{prop} = ... was stashed in-process but NOT "
        f"persisted. SuperDoc derives comment attribution from the "
        f"session credentials at create-time — the change won't survive "
        f"document re-open. Tracked in "
        f"docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md § 7.",
        PendingCommentMetadataWarning,
        stacklevel=3,
    )


class PendingCommentBlockSurfaceWarning(UserWarning):
    """Emitted when ``Comment.paragraphs`` or ``Comment.tables`` is
    accessed.

    SuperDoc models a comment as a single text body, not a
    :class:`BlockItemContainer`. Reads return an empty list so
    iteration parity (``for p in comment.paragraphs: …``) holds, but
    a fresh open will never have children to enumerate. Use
    :attr:`Comment.text` for the body. The mutation surface
    (:meth:`add_paragraph`, :meth:`add_table`,
    :meth:`iter_inner_content`) raises
    :class:`CommentsNotImplementedError`. Tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 7.
    """


def _warn_comment_block_surface(prop: str) -> None:
    warnings.warn(
        f"Comment.{prop} returns an empty list — SuperDoc models a "
        f"comment as a single text body, not a BlockItemContainer. "
        f"Use comment.text to read the body. Tracked in "
        f"docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md § 7.",
        PendingCommentBlockSurfaceWarning,
        stacklevel=3,
    )


class CommentsNotImplementedError(DocxError, NotImplementedError):
    """Raised for the multi-paragraph / table-bearing surface of
    :class:`Comment` that python-docx exposes but SuperDoc doesn't.

    Subclasses both :class:`docx.errors.DocxError` (so existing athena
    error handlers catch it) and :class:`NotImplementedError` (so it
    matches Python's idiom for "this method exists but isn't wired up
    yet"). Single-text-body operations are fully supported and do not
    raise.
    """

    def __init__(self, feature: str = "Multi-paragraph comments") -> None:
        super().__init__(
            f"{feature} are not yet supported in athena-python-docx. "
            "SuperDoc models a comment as a single text body — use "
            "the comment's `text` property instead. Tracked in "
            "docx-studio/PYTHON_DOCX_PARITY_GAPS.md § 3.1."
        )


def _build_target(runs: "Run | Sequence[Run]") -> dict | None:
    """Coerce a single run or run sequence into the SuperDoc
    ``target = {kind: 'text', blockId, range: {start, end}}`` shape.

    Multi-block run sequences fall back to ``None`` (an unanchored
    comment) — Word can't anchor a single comment to disjoint blocks.
    """
    seq: list = list(runs) if hasattr(runs, "__iter__") else [runs]
    if not seq:
        return None
    block_id: str | None = None
    start: int | None = None
    end: int | None = None
    for r in seq:
        bid = getattr(r, "_block_id", None)
        rng = getattr(r, "_range", None)
        if not isinstance(bid, str) or not isinstance(rng, tuple):
            return None
        if block_id is None:
            block_id = bid
            start, end = rng
            continue
        if bid != block_id:
            # Disjoint blocks — bail to unanchored.
            return None
        if start is None or end is None:
            start, end = rng
        else:
            start = min(start, rng[0])
            end = max(end, rng[1])
    if block_id is None or start is None or end is None:
        return None
    return {
        "kind": "text",
        "blockId": block_id,
        "range": {"start": start, "end": end},
    }


def _extract_entity_id(create_response: object) -> str:
    """Pull the new comment's entityId out of a ``CommentsCreate`` response.

    SuperDoc returns ``{success, inserted: [{kind, entityType, entityId}, ...]}``.
    """
    if isinstance(create_response, dict):
        inserted = create_response.get("inserted")
        if isinstance(inserted, list):
            for entry in inserted:
                if (
                    isinstance(entry, dict)
                    and entry.get("entityType") == "comment"
                    and isinstance(entry.get("entityId"), str)
                ):
                    return entry["entityId"]
    return ""


def _coerce_timestamp(raw: object) -> datetime | None:
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw
    if isinstance(raw, (int, float)):
        # SuperDoc returns createdTime as milliseconds since epoch.
        return datetime.fromtimestamp(raw / 1000.0, tz=timezone.utc)
    return None


class Comment:
    """A single Word comment thread."""

    def __init__(
        self,
        *,
        session: "Session",
        info: dict | None = None,
    ) -> None:
        self._session: "Session" = session
        self._info: dict = dict(info or {})

    # ---- identity / metadata ----
    @property
    def comment_id(self) -> str:
        cid = self._info.get("id") or self._info.get("commentId") or ""
        return str(cid)

    @property
    def author(self) -> str:
        return str(self._info.get("creatorName") or "")

    @author.setter
    def author(self, value: str) -> None:
        # SuperDoc treats author as immutable (set at create time);
        # reflect locally so reads after assignment match upstream.
        _warn_comment_metadata("author")
        self._info["creatorName"] = value

    @property
    def initials(self) -> str:
        return str(self._info.get("initials") or "")

    @initials.setter
    def initials(self, value: str) -> None:
        _warn_comment_metadata("initials")
        self._info["initials"] = value

    @property
    def timestamp(self) -> datetime | None:
        return _coerce_timestamp(self._info.get("createdTime"))

    # ---- body ----
    @property
    def text(self) -> str:
        return str(self._info.get("text") or "")

    @text.setter
    def text(self, value: str) -> None:
        from docx.commands import CommentsPatch

        run_sync(self._session.doc.comments.patch({"id": self.comment_id, "text": value}))
        self._info["text"] = value
        # CommentsPatch is a Command type — referenced for clarity / parity
        # with the bus dispatch path.
        del CommentsPatch

    # ---- BlockItemContainer surface (not supported by SuperDoc) ----
    @property
    def paragraphs(self) -> "list[Paragraph]":
        # SuperDoc comments have a single text body, not a paragraph list.
        # Return an empty list so iteration parity holds; callers that need
        # the body should read `comment.text`. Emit a warning so callers
        # that *expected* block children learn that the surface is lossy
        # rather than discovering it via an unexpectedly empty loop.
        _warn_comment_block_surface("paragraphs")
        return []

    @property
    def tables(self) -> "list[Table]":
        _warn_comment_block_surface("tables")
        return []

    def add_paragraph(
        self, text: str = "", style: "str | ParagraphStyle | None" = None
    ) -> "Paragraph":
        raise CommentsNotImplementedError("Comment.add_paragraph")

    def add_table(self, rows: int, cols: int, width: "Length") -> "Table":
        raise CommentsNotImplementedError("Comment.add_table")

    def iter_inner_content(self) -> "Iterator[Paragraph | Table]":
        raise CommentsNotImplementedError("Comment.iter_inner_content")


class Comments:
    """Collection of all comments in the document.

    Iterable / sized. ``add_comment`` creates an unanchored comment;
    use :meth:`Document.add_comment` to thread a run-anchored target.
    """

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self) -> list[dict]:
        result: object = run_sync(self._session.doc.comments.list({}))
        if isinstance(result, dict):
            items = result.get("items")
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        return []

    def __iter__(self) -> "Iterator[Comment]":
        for item in self._items():
            yield Comment(session=self._session, info=item)

    def __len__(self) -> int:
        return len(self._items())

    def add_comment(
        self,
        text: str = "",
        author: str = "",
        initials: "str | None" = "",
    ) -> Comment:
        """Add a new comment to the document and return it.

        Mirrors python-docx's
        ``Comments.add_comment(text, author, initials)``. SuperDoc
        derives the author from the session credentials, so the
        ``author`` and ``initials`` arguments are stored on the
        returned :class:`Comment` for read-back parity but are not
        forwarded to SuperDoc (which ignores client-supplied identity).
        Use :meth:`Document.add_comment` to thread a run-anchored
        target — this method creates an unanchored comment.
        """
        # python-docx 1.x routes ``text`` / ``author`` / ``initials``
        # through lxml's element setters which TypeError on non-str.
        # Was: any value shipped to wire (text) or stashed as-is on
        # the local info dict (author/initials) — caller's intent was
        # lost when they passed a wrong type.
        if not isinstance(text, str):
            raise TypeError(
                f"Comments.add_comment text requires str; got "
                f"{type(text).__name__} {text!r}",
            )
        if not isinstance(author, str):
            raise TypeError(
                f"Comments.add_comment author requires str; got "
                f"{type(author).__name__} {author!r}",
            )
        if initials is not None and not isinstance(initials, str):
            raise TypeError(
                f"Comments.add_comment initials requires str or None; "
                f"got {type(initials).__name__} {initials!r}",
            )
        result: object = run_sync(
            self._session.doc.comments.create({"text": text}),
        )
        cid = _extract_entity_id(result)
        info = {
            "id": cid,
            "commentId": cid,
            "text": text,
            "creatorName": author,
            "initials": initials,
            "status": "open",
        }
        return Comment(session=self._session, info=info)

    def get(self, comment_id: str | int) -> "Comment | None":
        """Return the comment with ``comment_id``, or ``None`` if not found.

        Mirrors python-docx 1.x semantics: ``None`` signals "no
        matching comment", not "lookup failed". Transport / auth /
        server errors propagate through as :class:`DocxError` rather
        than being silently coerced to ``None`` (the previous
        ``except Exception: return None`` swallowed everything, so
        a 500 from docx-studio looked identical to a missing comment).

        "Not found" is detected via :class:`NotFoundError`, which the
        HTTP layer raises after inspecting the server's structured
        error payload (preferred) or a broadened message-substring
        fallback. Bare ``DocxError`` instances are NOT coerced to
        ``None`` — that's a transport failure, not a miss.
        """
        try:
            result: object = run_sync(
                self._session.doc.comments.get({"id": str(comment_id)}),
            )
        except NotFoundError:
            return None
        if isinstance(result, dict):
            # SuperDoc may surface the id under ``id`` or ``commentId`` —
            # or the response may embed the id in a nested ``address``
            # entity wrapper. As long as we have any of those, we have
            # a real comment.
            has_id = bool(
                result.get("id")
                or result.get("commentId")
                or (
                    isinstance(result.get("address"), dict)
                    and result["address"].get("entityId")
                )
            )
            if has_id:
                return Comment(session=self._session, info=result)
        return None


def _create_anchored_comment(
    session: "Session",
    runs: "Run | Sequence[Run]",
    *,
    text: str,
    author: str,
    initials: str,
) -> Comment:
    """Internal helper backing :meth:`Document.add_comment`. Resolves
    ``runs`` to a SuperDoc ``target`` and creates the comment in one
    shot, returning a :class:`Comment` proxy."""
    target = _build_target(runs)
    payload: dict = {"text": text}
    if target is not None:
        payload["target"] = target
    result: object = run_sync(session.doc.comments.create(payload))
    cid = _extract_entity_id(result)
    info = {
        "id": cid,
        "commentId": cid,
        "text": text,
        "target": target,
        "creatorName": author,
        "initials": initials,
        "status": "open",
    }
    return Comment(session=session, info=info)


__all__ = [
    "Comment",
    "Comments",
    "CommentsNotImplementedError",
    "PendingCommentMetadataWarning",
    "PendingCommentBlockSurfaceWarning",
]
