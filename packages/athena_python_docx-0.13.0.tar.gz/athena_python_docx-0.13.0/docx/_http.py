"""HTTP bootstrap for Document.create().

The SDK's primary transport is y-websocket via Superdoc; this module is
the *only* HTTP client in the package. It exists solely so that
``Document.create()`` can hit ``POST /docs/empty`` on docx-studio to
provision a new SuperDocument asset and receive a collab bundle to open
the document with.

We use ``urllib`` from stdlib to avoid pulling ``httpx`` / ``requests``
into the runtime — this code runs in Daytona sandboxes where every MB
matters, and the existing SDK already keeps its dep tree tight.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import TypedDict

from docx.errors import (
    AuthenticationError,
    DocxError,
    SessionError,
)


class _CollabBundle(TypedDict):
    """The collab credentials returned alongside a freshly-created asset.

    Note: env-var-shape (matches what ``Session`` reads), even though
    the wire format from docx-studio uses different key names. The
    keys are renamed at parse time.
    """

    SUPERDOC_COLLAB_TOKEN: str
    KERYX_WS_URL: str
    ATHENA_WORKSPACE_ID: str


class CreateAssetResult(TypedDict):
    """Parsed response from ``POST /docs/empty``."""

    asset_id: str
    name: str
    workspace_id: str
    collab: _CollabBundle


_BASE_URL_ENV = "ATHENA_DOCX_BASE_URL"
_API_KEY_ENV = "ATHENA_DOCX_API_KEY"  # noqa: S105
_AGORA_BASE_URL_ENV = "ATHENA_AGORA_BASE_URL"


def _derive_agora_base_url(docx_base_url: str) -> str | None:
    """Best-effort derive an Agora base URL from a docx-studio base URL.

    The Athena hosts follow a parallel ``<service>.<env>.athenaintel.com``
    convention, so substituting ``docx-studio`` → ``agora`` lands on the
    matching Agora service. Returns ``None`` when the substitution
    doesn't apply (e.g. ``http://localhost:4100``), in which case the
    caller must provide ``agora_base_url`` explicitly.
    """
    if "docx-studio" not in docx_base_url:
        return None
    return docx_base_url.replace("docx-studio", "agora")


def create_empty_document(
    *,
    base_url: str | None = None,
    api_key: str | None = None,
    name: str | None = None,
    parent_folder_id: str | None = None,
    workspace_id: str | None = None,
    timeout: float = 30.0,
) -> CreateAssetResult:
    """Call ``POST {base_url}/docs/empty`` and parse the response.

    Args:
        base_url: docx-studio API base, e.g. ``https://docx-studio.stg.athenaintel.com``.
            Falls back to ``$ATHENA_DOCX_BASE_URL``.
        api_key: Athena API key (PropelAuth user API key) or PropelAuth
            access token. Sent as ``Authorization: Bearer <api_key>``.
            Falls back to ``$ATHENA_DOCX_API_KEY``.
        name: Optional display title.
        parent_folder_id: Optional parent folder; defaults to workspace root.
        workspace_id: Optional workspace UUID; defaults to caller's
            current workspace.
        timeout: Request timeout in seconds.

    Returns:
        Parsed response dict with the new asset_id and a collab bundle
        ready to feed into ``Session(..., bundle=...)``.

    Raises:
        SessionError: missing base_url or unparseable response.
        AuthenticationError: missing api_key, or the server returned 401/403.
        DocxError: any other 4xx/5xx from the server.
    """
    resolved_base: str | None = base_url or os.environ.get(_BASE_URL_ENV)
    resolved_key: str | None = api_key or os.environ.get(_API_KEY_ENV)

    if not resolved_base:
        raise SessionError(
            f"Missing base_url and {_BASE_URL_ENV} env var. "
            "Pass base_url= to Document.create() or set the env var.",
        )
    if not resolved_key:
        raise AuthenticationError(
            f"Missing api_key and {_API_KEY_ENV} env var. "
            "Pass api_key= to Document.create() or set the env var.",
        )

    url: str = resolved_base.rstrip("/") + "/docs/empty"
    body: dict[str, str] = {}
    if name is not None:
        body["name"] = name
    if parent_folder_id is not None:
        body["parentFolderId"] = parent_folder_id
    if workspace_id is not None:
        body["workspaceId"] = workspace_id

    # Lazy import — _http is loaded lazily by Document.create(), so the
    # package is fully initialized by the time we reach this code.
    from docx import __version__

    payload: bytes = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(  # noqa: S310
        url,
        data=payload,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {resolved_key}",
            "Accept": "application/json",
            "User-Agent": f"athena-python-docx/{__version__}",
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
            raw: bytes = resp.read()
    except urllib.error.HTTPError as e:
        err_body: str = ""
        try:
            err_body = e.read().decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
        if e.code in (401, 403):
            raise AuthenticationError(
                f"docx-studio rejected the API key (HTTP {e.code}): {err_body}",
            ) from e
        raise DocxError(
            f"docx-studio /docs/empty returned HTTP {e.code}: {err_body}",
        ) from e
    except urllib.error.URLError as e:
        raise SessionError(
            f"Unable to reach docx-studio at {url}: {e.reason}",
        ) from e

    try:
        parsed: dict = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise SessionError(
            f"docx-studio returned non-JSON response: {raw[:200]!r}",
        ) from e

    asset_id_obj = parsed.get("assetId")
    name_obj = parsed.get("name")
    ws_obj = parsed.get("workspaceId")
    collab_obj = parsed.get("collab")
    if not (
        isinstance(asset_id_obj, str)
        and isinstance(name_obj, str)
        and isinstance(ws_obj, str)
        and isinstance(collab_obj, dict)
    ):
        raise SessionError(
            f"docx-studio response is missing required fields: {parsed!r}",
        )
    token_obj = collab_obj.get("token")
    ws_url_obj = collab_obj.get("wsUrl")
    bundle_ws_obj = collab_obj.get("workspaceId")
    if not (
        isinstance(token_obj, str)
        and isinstance(ws_url_obj, str)
        and isinstance(bundle_ws_obj, str)
    ):
        raise SessionError(
            f"docx-studio collab bundle is malformed: {collab_obj!r}",
        )

    return CreateAssetResult(
        asset_id=asset_id_obj,
        name=name_obj,
        workspace_id=ws_obj,
        collab=_CollabBundle(
            SUPERDOC_COLLAB_TOKEN=token_obj,
            KERYX_WS_URL=ws_url_obj,
            ATHENA_WORKSPACE_ID=bundle_ws_obj,
        ),
    )


class UploadAssetResult(TypedDict):
    """Parsed response from agora's ``POST /api/super-docs/create-from-upload``."""

    asset_id: str
    name: str


def upload_document(
    *,
    docx_path: str,
    docx_base_url: str | None = None,
    agora_base_url: str | None = None,
    api_key: str | None = None,
    name: str | None = None,
    parent_folder_id: str | None = None,
    timeout: float = 120.0,
) -> UploadAssetResult:
    """Upload a local ``.docx`` to agora and create a new SuperDocument asset.

    The endpoint lives on agora (``POST /api/super-docs/create-from-upload``),
    not docx-studio, because the upload + Y.Doc-seed path is implemented
    server-side in agora. The SDK still talks to docx-studio for command
    application; this function only handles the initial create.

    Args:
        docx_path: Filesystem path to the ``.docx`` to upload.
        docx_base_url: docx-studio base URL — used as a fallback to derive
            the agora URL when ``agora_base_url`` is not supplied. Falls
            back to ``$ATHENA_DOCX_BASE_URL``.
        agora_base_url: Explicit Agora base URL. Falls back to
            ``$ATHENA_AGORA_BASE_URL`` and finally to a host substitution
            of ``docx-studio`` → ``agora`` against ``docx_base_url``.
        api_key: Athena API key. Falls back to ``$ATHENA_DOCX_API_KEY``.
        name: Optional asset title (defaults to the file's stem).
        parent_folder_id: Optional parent folder for the new asset.
        timeout: Request timeout in seconds (uploads can be slow for big
            decks/templates).

    Returns:
        Dict with the new asset_id and the resolved title.

    Raises:
        SessionError: missing base URLs / unreachable agora.
        AuthenticationError: missing api_key, or 401/403 from server.
        DocxError: any other 4xx/5xx, or a malformed response.
    """
    import io
    import mimetypes
    import os
    import uuid

    resolved_docx_base: str | None = docx_base_url or os.environ.get(_BASE_URL_ENV)
    resolved_key: str | None = api_key or os.environ.get(_API_KEY_ENV)
    resolved_agora_base: str | None = (
        agora_base_url
        or os.environ.get(_AGORA_BASE_URL_ENV)
        or (_derive_agora_base_url(resolved_docx_base) if resolved_docx_base else None)
    )

    if not resolved_agora_base:
        raise SessionError(
            f"Missing agora_base_url, {_AGORA_BASE_URL_ENV}, and {_BASE_URL_ENV} "
            "(or the docx-studio URL doesn't follow the docx-studio↔agora "
            "host pattern). Pass agora_base_url= to Document.create() or set "
            f"the {_AGORA_BASE_URL_ENV} env var.",
        )
    if not resolved_key:
        raise AuthenticationError(
            f"Missing api_key and {_API_KEY_ENV} env var. "
            "Pass api_key= to Document.create() or set the env var.",
        )

    if not os.path.exists(docx_path):
        raise SessionError(f"DOCX file not found: {docx_path}")
    if not docx_path.lower().endswith(".docx"):
        raise SessionError(
            f"Only .docx files are accepted by the upload endpoint (got {docx_path})",
        )

    title = name
    if title is None:
        base = os.path.basename(docx_path)
        title = base[:-5] if base.lower().endswith(".docx") else base

    # Build the agora URL with query-string params (FastAPI binds non-body
    # args from the query string for multipart routes).
    from urllib.parse import urlencode

    qs: dict[str, str] = {"is_template": "false", "title": title}
    if parent_folder_id is not None:
        qs["parent_folder_id"] = parent_folder_id

    url: str = (
        resolved_agora_base.rstrip("/")
        + "/api/super-docs/create-from-upload?"
        + urlencode(qs)
    )

    # Build a minimal multipart/form-data body without pulling in
    # `requests` — keep the urllib-only dep profile.
    with open(docx_path, "rb") as f:
        file_bytes: bytes = f.read()
    content_type: str = (
        mimetypes.guess_type(docx_path)[0]
        or "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
    boundary: str = f"----athenaDocxBoundary{uuid.uuid4().hex}"
    filename = os.path.basename(docx_path)
    body_parts: list[bytes] = []
    body_parts.append(f"--{boundary}\r\n".encode("utf-8"))
    body_parts.append(
        (
            'Content-Disposition: form-data; name="file"; '
            f'filename="{filename}"\r\n'
            f"Content-Type: {content_type}\r\n\r\n"
        ).encode("utf-8"),
    )
    body_parts.append(file_bytes)
    body_parts.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))
    body: bytes = b"".join(body_parts)

    from docx import __version__

    req = urllib.request.Request(  # noqa: S310
        url,
        data=body,
        method="POST",
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Authorization": f"Bearer {resolved_key}",
            "Accept": "application/json",
            "User-Agent": f"athena-python-docx/{__version__}",
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
            raw: bytes = resp.read()
    except urllib.error.HTTPError as e:
        err_body: str = ""
        try:
            err_body = e.read().decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
        if e.code in (401, 403):
            raise AuthenticationError(
                f"agora rejected the API key (HTTP {e.code}): {err_body}",
            ) from e
        raise DocxError(
            f"agora /api/super-docs/create-from-upload returned HTTP {e.code}: {err_body}",
        ) from e
    except urllib.error.URLError as e:
        raise SessionError(
            f"Unable to reach agora at {url}: {e.reason}",
        ) from e

    # Avoid unused import warning when io isn't otherwise referenced.
    _ = io
    try:
        parsed: dict = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise SessionError(
            f"agora returned non-JSON response: {raw[:200]!r}",
        ) from e

    asset_id_obj = parsed.get("id")
    name_obj = parsed.get("title")
    if not (isinstance(asset_id_obj, str) and isinstance(name_obj, str)):
        raise SessionError(
            f"agora response is missing required fields: {parsed!r}",
        )

    return UploadAssetResult(asset_id=asset_id_obj, name=name_obj)
