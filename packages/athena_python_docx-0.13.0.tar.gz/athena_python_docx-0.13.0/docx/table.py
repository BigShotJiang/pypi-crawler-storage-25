"""Table, _Row, _Column, _Cell — python-docx parity."""

from __future__ import annotations

import sys
import warnings
from typing import TYPE_CHECKING

from docx._athena_extension import athena_extension
from docx._batching import run_sync
from docx.errors import ValidationError
from docx.shared import Length, Pt


class PendingTableClearWarning(UserWarning):
    """Emitted when a ``Table`` / ``_Row`` / ``_Column`` / ``_Cell``
    setter is asked to clear a property (``None`` assignment) that
    python-docx 1.x supports but SuperDoc 1.8 has no clear-op for.

    Covers: ``Table.alignment / direction / autofit``,
    ``_Row.height / height_rule``, ``_Column.width``,
    ``_Cell.width / vertical_alignment``. SuperDoc's
    ``tables.set_layout`` / ``set_row_height`` / ``set_column_width``
    / ``set_cell_properties`` require explicit values — the wire
    can't represent the python-docx "revert to inherited" intent.
    The warning surfaces the silent-divergence so agent runs see
    the gap. Tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md``.
    """


def _warn_table_clear(prop: str, *, cls: str = "Table") -> None:
    warnings.warn(
        f"{cls}.{prop} = None was IGNORED — SuperDoc 1.8 has no "
        f"clear-op for this property. The {cls.lower()} keeps its "
        f"previous value. Tracked in "
        f"docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md.",
        PendingTableClearWarning,
        stacklevel=3,
    )


_BORDER_STYLES: frozenset[str] = frozenset({
    "single", "double", "dashed", "dotted", "thick", "thin", "wave",
    "dot-dash", "dot-dot-dash", "triple", "none",
})


def _normalize_border_spec(spec: "dict | str | None", *, edge: str) -> "dict | None":
    """Normalize a border spec into the wire-format ``{style, size_pt, color}``
    dict the docx-studio apps/api applier expects.

    Accepts three forms:

    - ``None`` — leave the edge untouched.
    - ``dict`` — already in wire format; passed through unchanged.
    - ``str`` — a shorthand like ``"single 0.5pt #DDDDDD"`` or
      ``"thick 2pt #000"``. Tokens are ``<style>``, ``<float>pt``,
      ``#<hex>`` / bare hex; any combination is accepted in any order.

    The string form is the syntax the SKILL doc has shown since the API
    landed; accepting it removes a trap where the documented example
    produced an immediate HTTP 400 from the Zod ``BorderEdgeSchema``.
    """
    if spec is None:
        return None
    if isinstance(spec, dict):
        return dict(spec)
    if isinstance(spec, str):
        tokens = spec.strip().split()
        if not tokens:
            raise ValueError(f"Border spec for edge {edge!r} is empty")
        out: dict = {}
        for tok in tokens:
            if tok.endswith("pt"):
                try:
                    out["size_pt"] = float(tok[:-2])
                except ValueError as e:
                    raise ValueError(
                        f"Border spec for edge {edge!r}: cannot parse "
                        f"size token {tok!r}: {e}"
                    ) from None
            elif tok.startswith("#"):
                out["color"] = tok
            elif tok in _BORDER_STYLES:
                out["style"] = tok
            elif len(tok) in (3, 6) and all(c in "0123456789abcdefABCDEF" for c in tok):
                out["color"] = "#" + tok
            else:
                raise ValueError(
                    f"Border spec for edge {edge!r}: cannot parse token "
                    f"{tok!r}. Expected ``<style> <float>pt #RRGGBB``."
                )
        out.setdefault("style", "single")
        return out
    raise TypeError(
        f"Border spec for edge {edge!r} must be None, dict, or str; "
        f"got {type(spec).__name__}"
    )

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.table import (
        WD_ALIGN_VERTICAL,
        WD_ROW_HEIGHT_RULE,
        WD_TABLE_ALIGNMENT,
        WD_TABLE_DIRECTION,
    )
    from docx.styles.style import ParagraphStyle
    from docx.text.paragraph import Paragraph


def _log_warn(msg: str) -> None:
    print(f"[docx-sdk] WARN: {msg}", file=sys.stderr)


def _log_debug(msg: str) -> None:
    """Print a DEBUG-level diagnostic to stderr when ``DOCX_SDK_DEBUG`` is set.

    The SDK uses stderr-based ``print`` rather than the ``logging``
    module to stay consistent with :func:`_log_warn` and avoid imposing
    a logger config on call sites. Off by default so the chatty path
    doesn't pollute Daytona stderr in normal runs; flip it on when
    chasing silent-failure regressions.
    """
    import os

    if os.environ.get("DOCX_SDK_DEBUG"):
        print(f"[docx-sdk] DEBUG: {msg}", file=sys.stderr)


# Characters that, when present, force ``_Cell.text``'s setter to round-
# trip through the server-side ``doc.markdownToFragment`` op so any
# inline markdown gets rendered into structural runs. Plain-text values
# (the common case for tabular data — numbers, labels, names) skip the
# query entirely and build the fragment locally, saving one HTTP
# round-trip per cell assignment. The set is conservative on purpose:
# ``-``, ``.``, ``,``, parentheses, currency symbols, and percent are
# considered plain so that ``cell.text = "$1,234.56 (-3.4%)"`` doesn't
# eat a round-trip.
_MARKDOWN_SPECIAL_CHARS: frozenset[str] = frozenset(
    "*_~`#>[]<|\\"
)


def _is_plain_text(value: str) -> bool:
    """Return True iff ``value`` contains no markdown control characters.

    Used by ``_Cell.text`` to decide whether to construct the SuperDoc
    paragraph fragment locally (plain text) or to defer to the
    server-side ``doc.markdownToFragment`` op (anything that might
    contain bold/italic/code/header/list/link/blockquote/html syntax).
    """
    if not value:
        return True
    return not any(ch in _MARKDOWN_SPECIAL_CHARS for ch in value)


def _find_first_paragraph_id(obj: object) -> str:
    """Walk a getNodeById result to find the first paragraph nodeId."""
    if isinstance(obj, dict):
        t: object = obj.get("type")
        if isinstance(t, str) and t in ("paragraph", "heading"):
            attrs: object = obj.get("attrs")
            if isinstance(attrs, dict):
                nid: object = attrs.get("nodeId") or attrs.get("id")
                if isinstance(nid, str) and nid:
                    return nid
            top_nid: object = obj.get("nodeId")
            if isinstance(top_nid, str) and top_nid:
                return top_nid
        for key in ("paragraph", "heading"):
            if key in obj and isinstance(obj[key], dict):
                nid_o: object = obj.get("nodeId")
                if isinstance(nid_o, str) and nid_o:
                    return nid_o
                inner = _find_first_paragraph_id(obj[key])
                if inner:
                    return inner
        for v in obj.values():
            found: str = _find_first_paragraph_id(v)
            if found:
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = _find_first_paragraph_id(item)
            if found:
                return found
    return ""


def _collect_paragraph_ids(obj: object, out: list[str]) -> None:
    """Walk a node tree and collect all paragraph/heading nodeIds in order.

    Tolerates multiple shapes Superdoc emits:
      - cell getNodeById:  {"node": {"kind": "paragraph", "id": "UUID",
                                      "paragraph": {"inlines": [...]}}}
        (the cell's inner paragraph — server reports `id` as a bare UUID
         that the addressing layer expects as `paragraph:UUID`)
      - prosemirror-style: {"type": "paragraph", "attrs": {"nodeId": ...}}
      - typed-wrapper:     {"paragraph": {...}, "nodeId": "..."}
      - flat-address:      {"kind": "block", "nodeType": "paragraph", "nodeId": ...}
      - block-list shape:  {"nodeType": "paragraph", "nodeId": ...}
    """
    seen: set[str] = set(out)

    def _add(nid: object) -> None:
        if not isinstance(nid, str) or not nid:
            return
        # Superdoc uses bare UUIDs (or short hashes) — no `paragraph:`
        # prefix. Pass the value through verbatim.
        if nid in seen:
            return
        seen.add(nid)
        out.append(nid)

    if isinstance(obj, dict):
        # Cell getNodeById shape: {kind: "paragraph", id: "<UUID>", paragraph: {...}}
        kind: object = obj.get("kind")
        if kind == "paragraph" and isinstance(obj.get("id"), str):
            _add(obj.get("id"))
            # Some responses also put the wrapper's id at nodeId.
            _add(obj.get("nodeId"))
        # Prosemirror-style
        t: object = obj.get("type")
        if isinstance(t, str) and t in ("paragraph", "heading"):
            attrs: object = obj.get("attrs")
            if isinstance(attrs, dict):
                _add(attrs.get("nodeId") or attrs.get("id"))
            _add(obj.get("nodeId"))
            _add(obj.get("id"))
        # Flat-address / block-list
        node_type: object = obj.get("nodeType")
        if isinstance(node_type, str) and node_type in ("paragraph", "heading"):
            _add(obj.get("nodeId"))
        # Typed-wrapper
        for key in ("paragraph", "heading"):
            if key in obj and isinstance(obj[key], dict):
                _add(obj.get("nodeId"))
                inner = obj[key]
                if isinstance(inner, dict):
                    _add(inner.get("nodeId"))
        # Recurse
        for v in obj.values():
            _collect_paragraph_ids(v, out)
    elif isinstance(obj, list):
        for item in obj:
            _collect_paragraph_ids(item, out)


def _count_non_empty_runs(obj: object) -> int:
    """Count ``{"kind": "run", "run": {"text": "..."}}`` entries with
    non-empty text anywhere in a SuperDoc cell-node response.

    Why this exists: SuperDoc 1.8.1 collapses every cell-inner
    ``cell.add_paragraph(text)`` insert into an inline run on the
    cell's single template paragraph rather than creating new
    paragraph blocks. ``doc.getNodeById`` for a tableCell therefore
    returns ONE paragraph regardless of how many ``add_paragraph``
    calls have been made — so :func:`_collect_paragraph_ids` (which
    walks for paragraph nodeIds) always returns a list of length 1.

    On ``doc.save({out})`` SuperDoc's exporter splits each non-empty
    inline run back into its own ``<w:p>``, so the exported DOCX
    paragraph count for a cell equals the count of non-empty inline
    runs in the live cell-node response. This helper is the count
    ``_Cell.add_paragraph`` should use when computing the new
    paragraph's exported OOXML index (the value that ends up keying
    the ``_post_export_ops._cell_format_ops`` stash). Using
    ``len(_inner_paragraph_ids())`` instead caused every cell-inner
    ``style="..."`` op to collide on ``paragraph_index=0``, so the
    last write wins and earlier styles were silently overwritten —
    e.g. three ``cell.add_paragraph(bullet, style="List Bullet")``
    calls after a Heading4 stash would overwrite Heading4 with
    "List Bullet" at index 0 and never apply the style to the
    actual bullet paragraphs.
    """
    count = 0
    if isinstance(obj, dict):
        if obj.get("kind") == "run":
            run = obj.get("run")
            if isinstance(run, dict) and (run.get("text") or "").strip():
                count += 1
        for v in obj.values():
            count += _count_non_empty_runs(v)
    elif isinstance(obj, list):
        for item in obj:
            count += _count_non_empty_runs(item)
    return count


def _collect_block_ids(
    obj: object, out: list[tuple[str, str]], seen: set[str]
) -> None:
    """Walk an arbitrary getNodeById/getNode payload and collect every
    block child as ``(nodeId, nodeType)`` in document order.

    Type-aware variant of :func:`_collect_paragraph_ids` — recognizes
    paragraphs, headings, AND tables. Used by
    :meth:`_Cell.iter_inner_content` to yield ``Paragraph | Table`` in
    upstream order.

    Tolerates the same shapes ``_collect_paragraph_ids`` does:

    * flat-address: ``{nodeType, nodeId}``
    * typed-wrapper: ``{paragraph: {…}, nodeId}`` or
      ``{heading: {…}, nodeId}`` or ``{table: {…}, nodeId}``
    * prosemirror-style: ``{type: …, attrs: {nodeId}}``
    """
    BLOCK_TYPES: dict[str, str] = {
        "paragraph": "paragraph",
        "heading": "heading",
        "listItem": "paragraph",
        "table": "table",
    }

    def _add(nid: object, kind: str) -> None:
        if isinstance(nid, str) and nid and nid not in seen:
            seen.add(nid)
            out.append((nid, kind))

    if isinstance(obj, dict):
        # 1. Flat-address: {nodeType: "...", nodeId: "..."}
        nt = obj.get("nodeType")
        if isinstance(nt, str) and nt in BLOCK_TYPES:
            _add(obj.get("nodeId"), BLOCK_TYPES[nt])
        # 2. ProseMirror-style {type: "...", attrs: {nodeId}}
        pmt = obj.get("type")
        if isinstance(pmt, str) and pmt in BLOCK_TYPES:
            attrs = obj.get("attrs")
            if isinstance(attrs, dict):
                _add(attrs.get("nodeId"), BLOCK_TYPES[pmt])
        # 3. Typed-wrapper {paragraph: {...}, nodeId} (and table/heading variants)
        for key, kind in BLOCK_TYPES.items():
            wrapped = obj.get(key)
            if isinstance(wrapped, dict):
                _add(obj.get("nodeId"), kind)
                _add(wrapped.get("nodeId"), kind)
        # Recurse — but for table-wrappers, do NOT walk their inner
        # rows/cells because that would surface deeply-nested
        # paragraphs that are inside the nested table, not at the
        # parent cell's level.
        for key, value in obj.items():
            if key == "table" and isinstance(value, dict):
                continue
            _collect_block_ids(value, out, seen)
    elif isinstance(obj, list):
        for item in obj:
            _collect_block_ids(item, out, seen)


class Table:
    def __init__(
        self,
        *,
        session: "Session",
        node_id: str,
        rows: int | None = None,
        columns: int | None = None,
        doc_index: int | None = None,
    ) -> None:
        self._session: "Session" = session
        self._node_id: str = node_id
        # Locally-cached grid dimensions. Populated by
        # ``Document.add_table`` (which knows the rows/cols up-front)
        # so ``Table.cell()`` can validate bounds without round-tripping
        # to ``tables.get``. Stays ``None`` for Tables resolved later
        # via ``find`` / iteration; ``cell()`` falls back to
        # ``_fresh_node_info()`` in that case. ``tables.insert_row`` /
        # ``tables.insert_column`` invalidate this cache so the next
        # access re-fetches authoritative counts.
        self._cached_rows: int | None = rows
        self._cached_cols: int | None = columns
        # Stable position among top-level tables in document order. Set
        # by ``Document.add_table`` (each new table appends to documentEnd
        # so its document-order index is deterministic at creation time).
        # Drives the rotation fallback in ``_fresh_node_info`` — when
        # SuperDoc rotates ``self._node_id`` between saves, the SDK has
        # no other stable handle on this specific table among siblings.
        # Pre-0.11.4 the fallback always picked the *last* table in
        # ``doc.find({type:"table"})``, which silently re-pointed every
        # rotated proxy at the same target — observed as multiple
        # ``WARN: table nodeId rotated`` lines collapsing onto one
        # ``table-auto-…`` id, followed by ``ValidationError: Cell (r,c)
        # not found`` when a cell access hit the wrong table.
        self._doc_index: int | None = doc_index

    def _fresh_node_info(self) -> tuple[str, dict]:
        """Resolve the live nodeId and return ``(node_id, info_dict)``.

        ``info_dict`` is the ``tables.get`` payload that the fast path
        already fetched, so callers that need row/col counts can reuse
        it instead of issuing a second identical RPC. The fallback path
        (find + rotate) re-fetches the info for the rotated id.
        """
        # Drain any pending buffer FIRST so a freshly-minted client UUID
        # (``t_xxx``) has been rewritten to the real server-side id via
        # the proxy_id_refs mechanism. Pre-0.11.4 the fast-path captured
        # ``self._node_id`` at expression-evaluation time and sent it as
        # the ``nodeId`` arg — but the eager flush triggered by the
        # query rewrote ``self._node_id`` to the real id AFTER the arg
        # dict was built, so the server received the (now-stale) client
        # UUID and returned an empty payload. We then fell through into
        # the find-based fallback, which only sees committed tables and
        # mistook the absence as a rotation.
        try:
            handle = getattr(self._session, "_doc_handle", None)
            buf = getattr(handle, "buffer", None) if handle is not None else None
            if buf is not None:
                buf.flush()
        except Exception as exc:  # noqa: BLE001
            # Silent fallback on purpose — the fast-path ``tables.get``
            # below will still try with the proxy's current ``_node_id``,
            # and the find-based rotation lookup further down is the
            # backstop. But emit a DEBUG diagnostic when ``DOCX_SDK_DEBUG``
            # is set so the silent-skip is visible in traces. The
            # ``_doc_handle.buffer`` attribute chain is private (set up
            # by ``client.Session.open``); if it's renamed or absent
            # in some future refactor we want the regression to be
            # discoverable instead of hiding behind a stale-client-UUID
            # cascade.
            _log_debug(
                f"_fresh_node_info pre-flush skipped: "
                f"{type(exc).__name__}: {exc}"
            )

        # Fast-path: ask for this table directly. If the server finds it,
        # we're done — no rotation needed.
        try:
            info: object = run_sync(
                self._session.doc.tables.get({"nodeId": self._node_id}),
            )
            if isinstance(info, dict) and (
                info.get("nodeId") == self._node_id or info
            ):
                return self._node_id, info
        except Exception:
            pass
        # Fallback: scan top-level tables via doc.find. The find result is
        # in document order, so a Table created by ``Document.add_table``
        # — which always appends to ``documentEnd`` — can be located by
        # its stored ``_doc_index`` (the position it had at creation
        # time, captured from the in-session counter at append time).
        # That preserves the 1:1 mapping between proxy and server table
        # across rotations, instead of the pre-0.11.4 "take the last
        # item" heuristic that collapsed N rotated proxies onto one
        # target.
        find_result: object = run_sync(
            self._session.doc.find({"type": "table"}),
        )
        items_obj: object = (
            find_result.get("items", []) if isinstance(find_result, dict) else []
        )
        items: list = items_obj if isinstance(items_obj, list) else []
        for item in items:
            if not isinstance(item, dict):
                continue
            addr = item.get("address", {})
            if isinstance(addr, dict) and addr.get("nodeId") == self._node_id:
                info_obj = run_sync(
                    self._session.doc.tables.get({"nodeId": self._node_id}),
                )
                return self._node_id, info_obj if isinstance(info_obj, dict) else {}

        # Disambiguate the rotated proxy.
        # ``_doc_index`` is session-relative (0-based among tables this
        # Document handle created). To map it back to a position in the
        # find result we compute
        #   pos = len(items) - session_count + _doc_index
        # where ``session_count`` is the live count of tables created
        # in this session, stashed on the session by
        # ``Document._next_table_doc_index``. Tables created via
        # ``Document.add_table`` always append to ``documentEnd``, so
        # mine occupy the last ``session_count`` slots of the find
        # result in creation order. For ``Document.create()`` docs
        # (no pre-existing tables) the offset is 0 and the math
        # degenerates to ``items[_doc_index]``.
        rotated_addr: "dict | None" = None
        session_count_obj = getattr(
            self._session, "_table_session_count", None
        )
        session_count = (
            int(session_count_obj)
            if isinstance(session_count_obj, int)
            else None
        )
        if (
            self._doc_index is not None
            and session_count is not None
            and 0 <= self._doc_index < session_count
            and session_count <= len(items)
        ):
            pos = len(items) - session_count + self._doc_index
            cand = items[pos]
            if isinstance(cand, dict):
                ca = cand.get("address", {})
                if isinstance(ca, dict) and ca.get("nodeId"):
                    rotated_addr = ca
        elif len(items) == 1:
            # Unambiguous: only one table in the doc.
            cand = items[0]
            if isinstance(cand, dict):
                ca = cand.get("address", {})
                if isinstance(ca, dict) and ca.get("nodeId"):
                    rotated_addr = ca
        else:
            # Multi-table doc, ``_doc_index`` unknown (proxy resolved
            # via iteration / find rather than ``Document.add_table``)
            # or session count missing (e.g., constructed via
            # ``Document.__new__`` in a unit test). Surface the
            # ambiguity loudly so callers don't silently pick up the
            # wrong table.
            raise ValidationError(
                f"Table node_id {self._node_id!r} could not be resolved "
                f"after SuperDoc rotation, and there are {len(items)} "
                f"top-level tables in the document — the SDK can't tell "
                f"which one this proxy belonged to. Re-anchor by "
                f"iterating ``doc.tables`` instead of holding the stale "
                f"proxy. Pre-0.11.4 the fallback silently picked the "
                f"last table in document order, which produced "
                f"``ValidationError: Cell (r, c) not found`` further "
                f"down the script."
            )

        if rotated_addr is not None:
            new_id = str(rotated_addr.get("nodeId", ""))
            if new_id and new_id != self._node_id:
                _log_warn(
                    f"table nodeId rotated: {self._node_id} -> {new_id} "
                    f"(matched by doc_index={self._doc_index})",
                )
                self._node_id = new_id
        info_obj = run_sync(
            self._session.doc.tables.get({"nodeId": self._node_id}),
        )
        return self._node_id, info_obj if isinstance(info_obj, dict) else {}

    def _fresh_node_id(self) -> str:
        """Return the live nodeId — thin wrapper over :meth:`_fresh_node_info`."""
        return self._fresh_node_info()[0]

    def _address(self) -> dict:
        return {"kind": "block", "nodeType": "table", "nodeId": self._fresh_node_id()}

    @property
    def rows(self) -> "_Rows":
        _, info_dict = self._fresh_node_info()
        row_count: int = int(
            info_dict.get("rows")
            or info_dict.get("rowCount")
            or (info_dict.get("table", {}) or {}).get("rows")
            or 0,
        )
        return _Rows([_Row(table=self, index=i) for i in range(row_count)], table=self)

    @property
    def columns(self) -> "_Columns":
        _, info_dict = self._fresh_node_info()
        col_count: int = int(
            info_dict.get("columns")
            or info_dict.get("cols")
            or info_dict.get("columnCount")
            or (info_dict.get("table", {}) or {}).get("columns")
            or 0,
        )
        return _Columns(
            [_Column(table=self, index=j) for j in range(col_count)],
            table=self,
        )

    def cell(self, row_idx: int, col_idx: int) -> "_Cell":
        """Return the :class:`_Cell` at ``(row_idx, col_idx)``.

        Mirrors python-docx: ``(0, 0)`` is the top-left cell. Bounds
        are validated eagerly — out-of-range indices raise
        :class:`IndexError` immediately rather than producing a proxy
        that fails later when its address is resolved.

        Negative indices are accepted Python-style (``-1`` is the last
        row/column).

        Fast path: when the Table proxy was constructed with known
        dimensions (``Document.add_table`` and ``Table.insert_row`` /
        ``insert_column`` keep this cache current), bounds-check
        against the local cache without round-tripping to
        ``tables.get``. This is what keeps a 30-cell write loop at
        zero query-shaped HTTP calls — pre-cache this was one
        ``tables.get`` per ``cell()`` access.
        """
        row_count: int
        col_count: int
        if self._cached_rows is not None and self._cached_cols is not None:
            row_count = self._cached_rows
            col_count = self._cached_cols
        else:
            _, info_dict = self._fresh_node_info()
            row_count = int(
                info_dict.get("rows")
                or info_dict.get("rowCount")
                or (info_dict.get("table", {}) or {}).get("rows")
                or 0,
            )
            col_count = int(
                info_dict.get("columns")
                or info_dict.get("cols")
                or info_dict.get("columnCount")
                or (info_dict.get("table", {}) or {}).get("columns")
                or 0,
            )
        # Normalize negative indices the same way list[] does.
        if row_idx < 0:
            row_idx += row_count
        if col_idx < 0:
            col_idx += col_count
        if not (0 <= row_idx < row_count):
            raise IndexError(
                f"row_idx {row_idx!r} out of range for table with "
                f"{row_count} rows",
            )
        if not (0 <= col_idx < col_count):
            raise IndexError(
                f"col_idx {col_idx!r} out of range for table with "
                f"{col_count} columns",
            )
        return _Cell(table=self, row=row_idx, col=col_idx)

    def row_cells(self, row_idx: int) -> list["_Cell"]:
        """Return a list of cells in the row at *row_idx*.

        Mirrors python-docx 1.x. Behaviour for merged cells follows
        python-docx: the same _Cell may appear at multiple positions in
        the returned list when a horizontal merge spans them.
        """
        return self.rows[row_idx].cells

    def column_cells(self, column_idx: int) -> list["_Cell"]:
        """Return a list of cells in the column at *column_idx*."""
        return self.columns[column_idx].cells

    @property
    def table(self) -> "Table":
        """Return ``self`` — mirrors python-docx where ``Table.table`` is
        defined for symmetry with ``_Cell.table`` so block iteration code
        can look up the enclosing table without checking type."""
        return self

    def add_row(self, *, copy_format_from: "int | _Row | None" = None) -> "_Row":
        """Append a new row to the table.

        ``copy_format_from`` (Athena extension beyond python-docx 1.x —
        issue #205) selects a source row whose cell formatting (height,
        borders, shading, vertical alignment, text run formatting) is
        copied onto the new row. Pass an integer row index or a
        ``_Row`` instance.
        """
        nid: str = self._fresh_node_id()
        row_count: int = len(self.rows)
        if row_count < 1:
            raise ValidationError(f"Cannot add row to empty table {nid}")

        source_index: int | None = None
        if copy_format_from is not None:
            if isinstance(copy_format_from, _Row):
                source_index = copy_format_from._index
            elif isinstance(copy_format_from, int):
                source_index = copy_format_from
            else:
                raise TypeError(
                    f"copy_format_from must be int or _Row; got "
                    f"{type(copy_format_from).__name__}",
                )

        params: dict = {
            "nodeId": nid,
            "rowIndex": row_count - 1,
            "position": "below",
            "count": 1,
        }
        if source_index is not None:
            params["copyFormatFrom"] = source_index
        run_sync(self._session.doc.tables.insert_row(params))
        # Keep the bounds-check cache current so the next ``cell()``
        # access still hits the fast path.
        if self._cached_rows is not None:
            self._cached_rows += 1
        return _Row(table=self, index=row_count)

    @athena_extension(
        issue=201,
        description="Table.set_borders — table-wide border control.",
    )
    def set_borders(
        self,
        *,
        top: "dict | str | None" = None,
        bottom: "dict | str | None" = None,
        left: "dict | str | None" = None,
        right: "dict | str | None" = None,
        inside_horizontal: "dict | str | None" = None,
        inside_vertical: "dict | str | None" = None,
    ) -> None:
        """Set table-wide default borders (outer frame + inside grid).

        Athena extension beyond python-docx 1.x — issue #201 has been
        open for years. Each edge accepts a wire-format
        ``{style, size_pt, color}`` dict OR a shorthand string like
        ``"single 0.5pt #DDDDDD"``; ``style`` ∈ {``"single"``,
        ``"double"``, ``"dashed"``, ``"dotted"``, ``"thick"``,
        ``"none"``, …}. ``None`` leaves the edge untouched.
        """
        from docx.commands import SetTableBorders

        run_sync(
            self._session.send_command(
                SetTableBorders(
                    node_id=self._fresh_node_id(),
                    top=_normalize_border_spec(top, edge="top"),
                    bottom=_normalize_border_spec(bottom, edge="bottom"),
                    left=_normalize_border_spec(left, edge="left"),
                    right=_normalize_border_spec(right, edge="right"),
                    inside_horizontal=_normalize_border_spec(
                        inside_horizontal, edge="inside_horizontal"
                    ),
                    inside_vertical=_normalize_border_spec(
                        inside_vertical, edge="inside_vertical"
                    ),
                ),
            ),
        )

    def add_column(self, width: "Length") -> "_Column":
        """Add a new column to the table at the rightmost position.

        ``width`` is required to match python-docx; columns without a
        width produce malformed Word output and are rejected upstream.
        """
        # Validate width eagerly. Upstream's ``Emu(-100)`` raises
        # ``ValueError`` so the column is never created. Previously this
        # method silently inserted the column first and only failed
        # later (or not at all, on a permissive backend), leaving a
        # phantom column in the table.
        if width is not None:
            raw_emu = int(width)
            if raw_emu < 0:
                raise ValueError(
                    f"value must be >= 0, got {raw_emu}",
                )
        nid: str = self._fresh_node_id()
        col_count: int = len(self.columns)
        if col_count < 1:
            raise ValidationError(f"Cannot add column to empty table {nid}")
        run_sync(
            self._session.doc.tables.insert_column(
                {
                    "nodeId": nid,
                    "columnIndex": col_count - 1,
                    "position": "right",
                    "count": 1,
                },
            ),
        )
        # Keep the bounds-check cache current.
        if self._cached_cols is not None:
            self._cached_cols += 1
        new_col = _Column(table=self, index=col_count)
        new_col.width = width
        return new_col

    @property
    def style(self) -> str | None:
        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            sid: object = info.get("styleId")
            if isinstance(sid, str) and sid:
                return sid
        return None

    @style.setter
    def style(self, value: str | None) -> None:
        from docx._table_styles import resolve_table_style_id

        nid: str = self._fresh_node_id()
        style_id = resolve_table_style_id(value) if value else "TableGrid"
        run_sync(
            self._session.doc.tables.set_style(
                {"nodeId": nid, "styleId": style_id},
            ),
        )

    @property
    def alignment(self) -> "WD_TABLE_ALIGNMENT | None":
        from docx.enum.table import WD_TABLE_ALIGNMENT

        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            a: object = info.get("alignment")
            if isinstance(a, str):
                for member in WD_TABLE_ALIGNMENT:
                    if member.value == a:
                        return member
        return None

    @alignment.setter
    def alignment(self, value: "WD_TABLE_ALIGNMENT | str | None") -> None:
        from docx.enum.table import WD_TABLE_ALIGNMENT

        if value is None:
            _warn_table_clear("alignment")
            return
        if isinstance(value, WD_TABLE_ALIGNMENT):
            v: str = value.to_superdoc()
        elif isinstance(value, str):
            # python-docx coerces strings through the enum and raises
            # ``ValueError`` for non-member values. Mirror that here
            # instead of shipping bogus ``str(value).lower()`` to
            # SuperDoc, which would silently swallow unknowns.
            try:
                v = WD_TABLE_ALIGNMENT(value).to_superdoc()
            except (ValueError, KeyError) as exc:
                raise ValueError(
                    f"Table.alignment = {value!r}: not a valid "
                    f"WD_TABLE_ALIGNMENT. Expected one of "
                    f"{[m.value for m in WD_TABLE_ALIGNMENT]}."
                ) from exc
        else:
            raise TypeError(
                f"Table.alignment requires WD_TABLE_ALIGNMENT, str, "
                f"or None; got {type(value).__name__}",
            )
        # SuperDoc 1.8.1: alignment is a setLayout field, not a
        # setTableOptions field. The earlier setTableOptions call
        # silently dropped the value (Zod validated, AnyDoc punt let
        # the wire pass, SuperDoc's permissive parser ignored unknowns).
        run_sync(
            self._session.doc.tables.set_layout(
                {"nodeId": self._fresh_node_id(), "alignment": v},
            ),
        )

    @property
    def direction(self) -> "WD_TABLE_DIRECTION | None":
        from docx.enum.table import WD_TABLE_DIRECTION

        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            d: object = info.get("direction")
            if isinstance(d, str):
                for member in WD_TABLE_DIRECTION:
                    if member.value == d:
                        return member
        return None

    @direction.setter
    def direction(self, value: "WD_TABLE_DIRECTION | str | None") -> None:
        from docx.enum.table import WD_TABLE_DIRECTION

        if value is None:
            _warn_table_clear("direction")
            return
        if isinstance(value, WD_TABLE_DIRECTION):
            v: str = value.to_superdoc()
        elif isinstance(value, str):
            try:
                v = WD_TABLE_DIRECTION(value).to_superdoc()
            except (ValueError, KeyError) as exc:
                raise ValueError(
                    f"Table.direction = {value!r}: not a valid "
                    f"WD_TABLE_DIRECTION. Expected one of "
                    f"{[m.value for m in WD_TABLE_DIRECTION]}."
                ) from exc
        else:
            raise TypeError(
                f"Table.direction requires WD_TABLE_DIRECTION, str, "
                f"or None; got {type(value).__name__}",
            )
        # SuperDoc's setLayout takes ``tableDirection`` (not
        # ``direction``). Same diagnostic as alignment above —
        # setTableOptions silently swallowed the field.
        run_sync(
            self._session.doc.tables.set_layout(
                {"nodeId": self._fresh_node_id(), "tableDirection": v},
            ),
        )

    # python-docx aliases
    table_direction = direction

    @property
    def autofit(self) -> bool | None:
        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            mode: object = info.get("autoFitMode")
            if isinstance(mode, str):
                return mode != "fixedWidth"
        return None

    @autofit.setter
    def autofit(self, value: bool | None) -> None:
        if value is None:
            _warn_table_clear("autofit")
            return
        if not isinstance(value, bool):
            raise TypeError(
                f"Table.autofit requires bool or None; got "
                f"{type(value).__name__} {value!r}. python-docx 1.x "
                f"is a ``_OnOff`` setter and rejects truthy non-bool "
                f"here too.",
            )
        run_sync(
            self._session.doc.tables.set_layout(
                {
                    "nodeId": self._fresh_node_id(),
                    # Wire field is ``autoFitMode``, not ``autoFit``.
                    # The earlier ``autoFit`` payload was rejected
                    # silently, so ``Table.autofit = …`` was a no-op.
                    "autoFitMode": "fitContents" if value else "fixedWidth",
                },
            ),
        )

    allow_autofit = autofit

    @property
    def _cells(self) -> list["_Cell"]:
        """Flat list of cells in row-major order."""
        out: list[_Cell] = []
        for r in self.rows:
            out.extend(r.cells)
        return out


class _Row:
    def __init__(self, *, table: Table, index: int) -> None:
        self._table: Table = table
        self._index: int = index
        # Cache for the rowInfo dict — populated lazily on first access
        # and reused across grid_cols_before / grid_cols_after / height
        # / height_rule. Cleared by callers that mutate the row.
        self._row_info_cache: dict | None = None
        self._row_info_loaded: bool = False

    @property
    def cells(self) -> list["_Cell"]:
        col_count: int = len(self._table.columns)
        return [
            _Cell(table=self._table, row=self._index, col=j)
            for j in range(col_count)
        ]

    @property
    def table(self) -> Table:
        return self._table

    def _row_info(self) -> dict | None:
        """Pull the row entry from ``tables.get`` for the parent table.

        Cached per-instance — adjacent reads (``grid_cols_before`` +
        ``grid_cols_after`` + ``height`` etc.) all share the same
        ``tables.get`` round-trip rather than re-fetching N times.
        """
        if self._row_info_loaded:
            return self._row_info_cache
        self._row_info_loaded = True
        _, info = self._table._fresh_node_info()
        if isinstance(info, dict):
            rows = info.get("rowInfo") or info.get("rowsInfo")
            if isinstance(rows, list) and 0 <= self._index < len(rows):
                entry = rows[self._index]
                if isinstance(entry, dict):
                    self._row_info_cache = entry
                    return entry
        return None

    @property
    def grid_cols_before(self) -> int:
        """Count of unpopulated grid-columns before the first cell.

        Mirrors python-docx ``_Row.grid_cols_before``. Word allows a
        row to "start late" — grid columns 0..N-1 are unpopulated and
        the first real cell sits at column N. Defaults to 0; SuperDoc
        may report under several keys depending on payload version.
        """
        entry = self._row_info()
        if isinstance(entry, dict):
            v = (
                entry.get("gridBefore")
                or entry.get("gridColsBefore")
                or entry.get("grid_cols_before")
                or 0
            )
            try:
                return max(0, int(v))
            except (TypeError, ValueError):
                return 0
        return 0

    @property
    def grid_cols_after(self) -> int:
        """Count of unpopulated grid-columns after the last cell.

        Mirrors python-docx ``_Row.grid_cols_after`` — the dual of
        :attr:`grid_cols_before`.
        """
        entry = self._row_info()
        if isinstance(entry, dict):
            v = (
                entry.get("gridAfter")
                or entry.get("gridColsAfter")
                or entry.get("grid_cols_after")
                or 0
            )
            try:
                return max(0, int(v))
            except (TypeError, ValueError):
                return 0
        return 0

    @property
    def height(self) -> "Length | None":
        _, info = self._table._fresh_node_info()
        if isinstance(info, dict):
            rows: object = info.get("rowInfo") or info.get("rowsInfo")
            if isinstance(rows, list) and 0 <= self._index < len(rows):
                entry = rows[self._index]
                if isinstance(entry, dict):
                    h: object = entry.get("heightPt")
                    if isinstance(h, (int, float)):
                        return Pt(float(h))
        return None

    @height.setter
    def height(self, value: "Length | int | None") -> None:
        if value is None:
            _warn_table_clear("height", cls="_Row")
            return
        # Mirror python-docx: row height is stored as unsigned twips
        # (``ST_TwipsMeasure``), so negative inputs raise ``ValueError``
        # at the type-coercion layer. Previously this setter would ship a
        # negative ``heightPt`` to the wire silently, and SuperDoc would
        # either reject it or round-trip a degenerate row height.
        raw_emu = int(value)
        if raw_emu < 0:
            raise ValueError(
                f"_Row.height must be non-negative; got EMU={raw_emu}. "
                f"Pass Length(0) (or None) to clear instead of a negative."
            )
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        run_sync(
            self._table._session.doc.tables.set_row_height(
                {
                    "nodeId": self._table._fresh_node_id(),
                    "rowIndex": self._index,
                    "heightPt": pt,
                    "rule": "atLeast",
                },
            ),
        )

    @property
    def height_rule(self) -> "WD_ROW_HEIGHT_RULE | None":
        from docx.enum.table import WD_ROW_HEIGHT_RULE

        nid = self._table._fresh_node_id()
        info: object = run_sync(
            self._table._session.doc.tables.get({"nodeId": nid}),
        )
        if isinstance(info, dict):
            rows: object = info.get("rowInfo") or info.get("rowsInfo")
            if isinstance(rows, list) and 0 <= self._index < len(rows):
                entry = rows[self._index]
                if isinstance(entry, dict):
                    r: object = entry.get("rule")
                    if isinstance(r, str):
                        for member in WD_ROW_HEIGHT_RULE:
                            if member.value == r:
                                return member
        return None

    @height_rule.setter
    def height_rule(self, value: "WD_ROW_HEIGHT_RULE | str | None") -> None:
        from docx.enum.table import WD_ROW_HEIGHT_RULE

        if value is None:
            _warn_table_clear("height_rule", cls="_Row")
            return
        if isinstance(value, WD_ROW_HEIGHT_RULE):
            rule: str = value.to_superdoc()
        elif isinstance(value, str):
            # python-docx coerces strings through the enum and raises
            # on misses. Was: ``str(value)`` shipped any value to the
            # wire (SuperDoc swallowed unknowns silently).
            try:
                rule = WD_ROW_HEIGHT_RULE(value).to_superdoc()
            except (ValueError, KeyError) as exc:
                raise ValueError(
                    f"_Row.height_rule = {value!r}: not a valid "
                    f"WD_ROW_HEIGHT_RULE. Expected one of "
                    f"{[m.value for m in WD_ROW_HEIGHT_RULE]}."
                ) from exc
        else:
            raise TypeError(
                f"_Row.height_rule requires WD_ROW_HEIGHT_RULE, str, "
                f"or None; got {type(value).__name__}",
            )
        h = self.height
        h_pt: float = float(h.pt) if isinstance(h, Length) else 12.0
        run_sync(
            self._table._session.doc.tables.set_row_height(
                {
                    "nodeId": self._table._fresh_node_id(),
                    "rowIndex": self._index,
                    "heightPt": h_pt,
                    "rule": rule,
                },
            ),
        )


class _Column:
    def __init__(self, *, table: Table, index: int) -> None:
        self._table: Table = table
        self._index: int = index

    @property
    def cells(self) -> list["_Cell"]:
        row_count: int = len(self._table.rows)
        return [
            _Cell(table=self._table, row=i, col=self._index)
            for i in range(row_count)
        ]

    @property
    def table(self) -> Table:
        return self._table

    @property
    def width(self) -> "Length | None":
        nid = self._table._fresh_node_id()
        info: object = run_sync(
            self._table._session.doc.tables.get({"nodeId": nid}),
        )
        if isinstance(info, dict):
            cols: object = info.get("columnInfo") or info.get("columnsInfo")
            if isinstance(cols, list) and 0 <= self._index < len(cols):
                entry = cols[self._index]
                if isinstance(entry, dict):
                    w: object = entry.get("widthPt")
                    if isinstance(w, (int, float)):
                        return Pt(float(w))
        return None

    @width.setter
    def width(self, value: "Length | int | None") -> None:
        if value is None:
            _warn_table_clear("width", cls="_Column")
            return
        # Mirror python-docx: width must be non-negative. Upstream
        # uses Emu which raises ``ValueError`` for negatives. Previously
        # this setter shipped negative widths to the wire silently, where
        # SuperDoc would either reject them or round-trip a garbage
        # column width.
        if isinstance(value, Length):
            raw_emu = int(value)
        else:
            raw_emu = int(value)
        if raw_emu < 0:
            raise ValueError(
                f"value must be >= 0, got {raw_emu}",
            )
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        run_sync(
            self._table._session.doc.tables.set_column_width(
                {
                    "nodeId": self._table._fresh_node_id(),
                    "columnIndex": self._index,
                    "widthPt": pt,
                },
            ),
        )


class _Rows(list):
    """Sequence of :class:`_Row` instances. Subclasses ``list`` so all
    standard list operations work, plus exposes ``.table`` for parity
    with python-docx's :class:`docx.table._Rows`.
    """

    def __init__(self, items: list, *, table: Table) -> None:
        super().__init__(items)
        self._table: Table = table

    @property
    def table(self) -> Table:
        return self._table


class _Columns(list):
    """Sequence of :class:`_Column` instances; the column dual of
    :class:`_Rows`. Subclasses ``list``."""

    def __init__(self, items: list, *, table: Table) -> None:
        super().__init__(items)
        self._table: Table = table

    @property
    def table(self) -> Table:
        return self._table


def _cell_info_colspan(info: dict) -> int:
    """Read a cell's horizontal span from a Superdoc ``getCells`` entry.

    Superdoc's wire field is ``colspan`` (see
    ``DocTablesGetCellsResult`` in ``@superdoc-dev/sdk``'s
    ``client.d.ts``). Older internal docs and FakeSession alias it as
    ``gridSpan``/``grid_span``; accept all three so the function works
    on both real and faked transport. Defaults to 1, clamped to at
    least 1 (Word treats a 0/negative span as invalid).
    """
    raw = info.get("colspan") or info.get("gridSpan") or info.get("grid_span") or 1
    try:
        return max(1, int(raw))
    except (TypeError, ValueError):
        return 1


class _Cell:
    def __init__(self, *, table: Table, row: int, col: int) -> None:
        self._table: Table = table
        self._row: int = row
        self._col: int = col

    def _cell_info_at(self, row: int, col: int) -> dict | None:
        """Raw ``tables.getCells`` for (row, col). Returns ``None`` when
        Superdoc reports no cell at that grid position — either an
        out-of-bounds query or a secondary slot covered by a colspan."""
        nid: str = self._table._fresh_node_id()
        result: object = run_sync(
            self._table._session.doc.tables.get_cells(
                {
                    "nodeId": nid,
                    "rowIndex": row,
                    "columnIndex": col,
                },
            ),
        )
        if not isinstance(result, dict):
            return None
        cells_obj: object = result.get("cells", result.get("items", []))
        cells: list = cells_obj if isinstance(cells_obj, list) else []
        if not cells or not isinstance(cells[0], dict):
            return None
        return cells[0]

    def _cell_info(self) -> dict | None:
        """Return the cell info backing ``(self._row, self._col)``.

        When ``self`` is the secondary slot of a horizontal merge, real
        Superdoc returns an empty cell list (only the master is
        addressable by its top-left position). Mirror python-docx's
        ``_Cell``-on-merge semantics by walking back along the row to
        find the first cell whose ``colspan`` covers our grid column,
        and return its info — multiple ``_Cell`` objects at different
        grid columns within the merge all share the master's ``<w:tc>``
        in the upstream model. Without this walk-back, simple
        ``for cell in row.cells: text = cell.text`` loops crash on
        every PW firm template (each one has at least one banner or
        title row with ``gridSpan=2``).
        """
        info = self._cell_info_at(self._row, self._col)
        if info is not None:
            return info
        # Walk back along the row to find a predecessor whose colspan
        # covers our column. Stop at the first existing cell — if its
        # colspan doesn't reach us, this grid position is truly empty
        # (out-of-bounds or skipped by ``<w:gridBefore>``) and we keep
        # the ``None`` so callers can decide what to do.
        for sibling_col in range(self._col - 1, -1, -1):
            sibling_info = self._cell_info_at(self._row, sibling_col)
            if sibling_info is None:
                continue
            span = _cell_info_colspan(sibling_info)
            if sibling_col + span > self._col:
                return sibling_info
            # Sibling exists but doesn't reach us — accept that this
            # position is genuinely empty rather than searching further
            # left across an unrelated cell.
            return None
        return None

    def _cell_id(self) -> str:
        info = self._cell_info()
        if info is None:
            raise ValidationError(
                f"Cell ({self._row}, {self._col}) not found in "
                f"table {self._table._fresh_node_id()}",
            )
        nid: object = info.get("nodeId")
        if not isinstance(nid, str) or not nid:
            raise ValidationError(
                f"Cell ({self._row}, {self._col}) has no nodeId",
            )
        return nid

    def _cell_address(self) -> dict:
        return {"kind": "block", "nodeType": "tableCell", "nodeId": self._cell_id()}

    def _ooxml_address_base(self) -> "tuple[int, int, int] | None":
        """Return ``(table_doc_index, row, col)`` for this cell, or
        ``None`` when the parent table's document-order position isn't
        known.

        Drives the post-export OOXML rewrite path
        (``docx._postproc.PostExportOps``) for cell-inner format ops.
        When the parent ``Table._doc_index`` is unset (template-seeded
        tables read from the asset rather than created via
        ``Document.add_table``), the cell can't be addressed positionally
        in the exported ``.docx`` and the rewrite falls back to
        warn-and-skip semantics (same as pre-0.11.5).
        """
        tbl_idx = self._table._doc_index
        if tbl_idx is None:
            return None
        return (tbl_idx, self._row, self._col)

    def _inner_paragraph_ids(self) -> list[str]:
        """Locate the paragraph nodeIds inside this cell, trying multiple
        Superdoc response shapes.

        Strategies (in order):
          1. doc.getNodeById with explicit nodeType=tableCell
          2. doc.getNodeById with just {id: ...}
          3. doc.getNode with target=tableCell address
          4. doc.blocks.list filtered to paragraph/heading + location match
        """
        cell_id = self._cell_id()
        session = self._table._session
        ids: list[str] = []

        # Strategy 1: with explicit nodeType
        try:
            info = run_sync(
                session.doc.get_node_by_id(
                    {"id": cell_id, "nodeType": "tableCell"},
                ),
            )
            _collect_paragraph_ids(info, ids)
            if ids:
                return ids
        except Exception:
            pass

        # Strategy 2: without nodeType (some sdk versions expect only id)
        try:
            info = run_sync(session.doc.get_node_by_id({"id": cell_id}))
            _collect_paragraph_ids(info, ids)
            if ids:
                return ids
        except Exception:
            pass

        # Strategy 3: doc.getNode with target address
        try:
            info = run_sync(
                session.doc.get_node(
                    {
                        "target": {
                            "kind": "block",
                            "nodeType": "tableCell",
                            "nodeId": cell_id,
                        },
                    },
                ),
            )
            _collect_paragraph_ids(info, ids)
            if ids:
                return ids
        except Exception:
            pass

        return ids

    def _count_exported_paragraphs(self) -> int:
        """Return the count of ``<w:p>`` elements the SuperDoc export
        will emit for this cell.

        Empirically verified against stg docx-studio at
        ``docx-studio.stg.athenaintel.com`` (2026-05-19):

        =========================== ===================
        Cell state                  Exported ``<w:p>``
        =========================== ===================
        empty cell                  1
        ``cell.text = "X"``         2
        ``cell.text = "X"`` + 1 add 3
        ``cell.text = "X"`` + 2 add 4
        2 ``add_paragraph`` only    3
        =========================== ===================

        Formula: ``non_empty_inline_runs + 1``. The ``+1`` covers the
        leading empty ``<w:p/>`` SuperDoc always preserves at the top
        of a cell's export (even for cells where SuperDoc's live
        state contains no leading-empty inline run — the export
        emits it regardless).

        Returns 1 for cells that fail every query (the minimum any
        cell exports — never produce a smaller number than reality).
        """
        cell_id = self._cell_id()
        session = self._table._session
        for payload in (
            {"id": cell_id, "nodeType": "tableCell"},
            {"id": cell_id},
        ):
            try:
                info = run_sync(session.doc.get_node_by_id(payload))
            except Exception:
                continue
            return _count_non_empty_runs(info) + 1
        return 1

    @property
    def text(self) -> str:
        """Return the combined text of direct-child paragraphs in the cell.

        Mirrors python-docx's `_Cell.text`, which is:
            "\\n".join(p.text for p in self.paragraphs)

        Note: this is NOT recursive — nested-table content is not included
        (stock python-docx's _Cell.text has that same shallow semantic).
        """
        from docx.text.paragraph import _node_text

        ids = self._inner_paragraph_ids()
        if ids:
            return "\n".join(_node_text(self._table._session, pid) for pid in ids)
        info = self._cell_info()
        if info is not None:
            t: object = info.get("text")
            if isinstance(t, str):
                return t
        return ""

    @text.setter
    def text(self, value: str) -> None:
        """Set the cell's text content.

        The cell's single inner paragraph is addressed indirectly — Superdoc
        doesn't expose a paragraph ref that's usable as a `blockId` for text
        selections. The apps/api applier wraps a `tables.getCells` lookup +
        a `doc.insert` with placement=insideEnd, which APPENDS inline runs
        to the cell's existing paragraph. For a freshly-created (empty)
        cell this produces `cell.text == value` on read-back.

        For cells that already contain text, callers who truly want "replace"
        semantics should first resolve the cell's paragraph via `doc.find`
        and delete it — see _Cell.clear() (Phase 3).
        """
        # Mirror python-docx: passing a non-string raises ``TypeError``
        # there (the upstream implementation does ``"".join(value)`` and
        # ints/None aren't iterable). Previously this setter accepted
        # any type and ``or ""`` masked ``None``, while ``int`` values
        # were passed through to ``markdown_to_fragment`` where they
        # round-tripped as ``str(value)`` — a silent type coercion.
        if not isinstance(value, str):
            raise TypeError(
                f"_Cell.text must be a str; got {type(value).__name__}",
            )
        # As of 0.10.0 the setter buffers a ``TableSetCell`` command
        # addressed by ``(table_node_id, row, col)`` and skips both
        # eager queries that used to fire per cell — the
        # ``Table._fresh_node_info()`` call (``tables.get`` query)
        # AND the ``_cell_info()`` call (``tables.get_cells`` query).
        # The apps/api applier resolves the cell nodeId server-side
        # against a per-batch cache so N cell writes against one table
        # share one ``tables.getCells`` call.
        #
        # Pre-0.10.0 a 30-cell table assignment was ~60 HTTP round-
        # trips (one ``tables.get`` + one ``tables.get_cells`` per
        # cell); post-0.10.0 it's a single ``POST /commands`` batch
        # containing the 30 TableSetCell commands plus whatever else
        # was already buffered. See
        # ``docx-studio/PERFORMANCE_BATCHING_ANALYSIS.md``.
        #
        # For plain text we build the fragment client-side. For
        # markdown content we still need one eager
        # ``markdown_to_fragment`` query (the parsed fragment isn't
        # something the apps/api applier can build for us yet).
        session = self._table._session
        try:
            fragment: dict
            if _is_plain_text(value):
                fragment = {
                    "kind": "paragraph",
                    "paragraph": {
                        "inlines": (
                            [{"kind": "run", "run": {"text": value}}]
                            if value
                            else []
                        ),
                    },
                }
            else:
                frag_result: object = run_sync(
                    session.doc.markdown_to_fragment({"markdown": value}),
                )
                resolved: object = (
                    frag_result.get("fragment")
                    if isinstance(frag_result, dict)
                    else None
                )
                if isinstance(resolved, dict):
                    fragment = resolved
                else:
                    # Server didn't return a fragment — fall back to the
                    # hand-built shape so we still land text rather than
                    # raising.
                    fragment = {
                        "kind": "paragraph",
                        "paragraph": {
                            "inlines": [
                                {"kind": "run", "run": {"text": value}},
                            ],
                        },
                    }
            # ``self._table._node_id`` is the raw client-or-server id
            # the Table proxy currently holds. The applier resolves it
            # through the per-batch clientIdMap so a freshly-created
            # table (still on its client UUID locally) routes to the
            # real id without forcing a flush here.
            #
            # Routed via the standard path-proxy (``tables.set_cell`` →
            # ``TableSetCell`` per ``_OP_TO_COMMAND``) so test fakes
            # that intercept at the namespace level see the call the
            # same way they see every other op.
            run_sync(
                session.doc.tables.set_cell(
                    {
                        "tableNodeId": self._table._node_id,
                        "rowIndex": self._row,
                        "columnIndex": self._col,
                        "content": fragment,
                    },
                ),
            )
            return
        except Exception as e:
            raise RuntimeError(
                f"Failed to set _Cell.text on cell ({self._row}, {self._col}) "
                f"of table {self._table._node_id}: {e!r}",
            ) from e

    @property
    def paragraphs(self) -> list["Paragraph"]:
        from docx.text.paragraph import Paragraph

        # Mark each Paragraph proxy as cell-inner so downstream format
        # ops that hit a SuperDoc ``Block not found`` miss can correlate
        # back to the well-known cell-paragraph addressing gap (see
        # ``BlockNotFoundError`` and ``SUPERDOC_UPSTREAM_REQUESTS.md``).
        # The flag is informational — no setter changes behavior based
        # on it yet — but it makes the connection inspectable from a
        # debugger and gives ``_apply_inline`` and friends something
        # stable to consult when we eventually add a materialization
        # fallback at the SDK layer.
        pids = self._inner_paragraph_ids()
        # Resolve the cell address ONCE and re-use it for every
        # paragraph; the original draft called ``self._cell_address()``
        # inside the loop, which hits ``_cell_id`` → ``_cell_info`` →
        # ``tables.get_cells`` per iteration. A 10-paragraph cell would
        # have eaten 10 redundant ``tables.get_cells`` round-trips just
        # to stamp identical metadata — defeats the whole point of the
        # 0.8.0 round-trip-reduction work. ``addr`` is ``None`` for an
        # empty cell so we don't issue a no-op address query in that case.
        addr = self._cell_address() if pids else None
        ooxml_base = self._ooxml_address_base()
        out: list[Paragraph] = []
        for para_idx, pid in enumerate(pids):
            ooxml_addr: tuple[int, int, int, int] | None = (
                (*ooxml_base, para_idx) if ooxml_base is not None else None
            )
            p = Paragraph(
                session=self._table._session,
                node_id=pid,
                node_type="paragraph",
                in_cell=True,
                cell_ooxml_address=ooxml_addr,
                cell=self,
            )
            # ``_cell_inner`` is the pre-0.11.4 informational marker.
            # ``in_cell`` (constructor kwarg) is the real behavior switch.
            p._cell_inner = True  # type: ignore[attr-defined]
            p._cell_address = addr  # type: ignore[attr-defined]
            out.append(p)
        return out

    @property
    def tables(self) -> list[Table]:
        cell_id = self._cell_id()
        info: object = run_sync(
            self._table._session.doc.get_node_by_id(
                {"id": cell_id, "nodeType": "tableCell"},
            ),
        )
        nested: list[Table] = []

        def walk(obj: object) -> None:
            if isinstance(obj, dict):
                t = obj.get("type") or obj.get("nodeType")
                if t == "table":
                    nid = obj.get("nodeId") or (
                        obj.get("attrs", {}).get("nodeId")
                        if isinstance(obj.get("attrs"), dict)
                        else None
                    )
                    if isinstance(nid, str) and nid:
                        nested.append(Table(session=self._table._session, node_id=nid))
                for v in obj.values():
                    walk(v)
            elif isinstance(obj, list):
                for item in obj:
                    walk(item)

        walk(info)
        return nested

    def add_paragraph(
        self,
        text: str = "",
        style: "str | ParagraphStyle | None" = None,
    ) -> "Paragraph":
        """Append a paragraph to the cell.

        Mirrors python-docx ``_Cell.add_paragraph(text, style)``. The
        ``style`` argument accepts either a style id string or a
        :class:`docx.styles.style.ParagraphStyle` instance; previously
        only ``str`` was honored and passing a ``ParagraphStyle`` got
        ``repr()``'d into the style id slot, silently producing a
        paragraph with a garbage style reference.

        Routes through ``doc.insert`` with the cell itself as the
        target and ``placement: 'insideEnd'`` — mirroring the wire
        path that ``_Cell.text`` uses. SuperDoc 1.8.1 cannot resolve a
        ``create.paragraph`` ``at`` anchor that points at a cell-inner
        paragraph (SUPERDOC_UPSTREAM_REQUESTS.md § 13); attempting it
        raises ``INVALID_TARGET - Expected paragraph:<id> but found
        tableCell:<id>``.
        """
        from docx.document import _extract_inserted_node_id
        from docx.styles.style import ParagraphStyle
        from docx.text.paragraph import Paragraph

        if not isinstance(text, str):
            raise TypeError(
                f"_Cell.add_paragraph text requires str; got "
                f"{type(text).__name__} {text!r}",
            )
        style_id: str | None
        if style is None:
            style_id = None
        elif isinstance(style, ParagraphStyle):
            style_id = style.style_id
        elif isinstance(style, str):
            style_id = style
        else:
            raise TypeError(
                f"_Cell.add_paragraph style requires str, "
                f"ParagraphStyle, or None; got "
                f"{type(style).__name__} {style!r}",
            )

        fragment: dict = {
            "kind": "paragraph",
            "paragraph": {
                "inlines": (
                    [{"kind": "run", "run": {"text": text}}]
                    if text
                    else []
                ),
            },
        }

        session = self._table._session
        cell_id = self._cell_id()
        result: object = run_sync(
            session.doc.insert(
                {
                    "target": {
                        "kind": "block",
                        "nodeType": "tableCell",
                        "nodeId": cell_id,
                    },
                    "placement": "insideEnd",
                    "content": fragment,
                },
            ),
        )

        node_id: str = ""
        if isinstance(result, dict):
            node_id = _extract_inserted_node_id(
                result, expected_type="paragraph",
            )
        # node_id should be set from ``_extract_inserted_node_id`` on
        # the insert response; fall back to ``_inner_paragraph_ids()``
        # only when the response shape changes.  This fallback can't
        # actually return the new paragraph's id (SuperDoc collapses
        # cell-inner inserts into inline runs on a single template
        # paragraph, so the cell always has just one paragraph node)
        # but it preserves the existing safety net for ``Run`` proxies.
        if not node_id:
            ids_after = self._inner_paragraph_ids()
            if ids_after:
                node_id = ids_after[-1]
        if not node_id:
            raise RuntimeError(
                f"docx-studio did not return nodeId for "
                f"_Cell.add_paragraph (cell={cell_id!r}): {result!r}",
            )
        ooxml_base = self._ooxml_address_base()
        # ``new_para_idx`` is the new paragraph's position in the
        # exported DOCX, NOT in SuperDoc's live state. SuperDoc's live
        # state shows 1 cell-inner paragraph with multiple inline
        # runs; the exported DOCX expands each non-empty inline run
        # into its own ``<w:p>``. Use the non-empty-run count for the
        # OOXML address so the ``_post_export_ops`` stash keys match
        # the rewrite walker's enumeration. Pre-fix this used
        # ``len(_inner_paragraph_ids()) - 1`` which always evaluated
        # to 0 for cell-inner adds, so sequential ``add_paragraph
        # (text, style=...)`` calls all stashed
        # ``CellAddress(..., paragraph_index=0)`` and the last write
        # silently overwrote every earlier cell-format op on that
        # cell. See ``_count_non_empty_runs`` for the upstream gap.
        new_para_idx = max(0, self._count_exported_paragraphs() - 1)
        ooxml_addr: tuple[int, int, int, int] | None = (
            (*ooxml_base, new_para_idx) if ooxml_base is not None else None
        )
        para = Paragraph(
            session=session,
            node_id=node_id,
            node_type="paragraph",
            in_cell=True,
            cell_ooxml_address=ooxml_addr,
            cell=self,
        )
        if style_id:
            # SuperDoc 1.8.1 cannot apply SetParagraphStyle to a
            # cell-inner paragraph. The setter on a Paragraph constructed
            # with in_cell=True emits CellInnerFormatNotSupportedWarning
            # and short-circuits, so the style is dropped but the
            # surrounding batch survives.
            para.style = style_id
        return para

    def add_table(self, rows: int, cols: int) -> Table:
        """Append a nested table inside the cell.

        Mirrors python-docx ``_Cell.add_table(rows, cols) -> Table``
        at the API surface, but raises
        :class:`docx.errors.NestedTableNotSupportedError` at runtime
        — SuperDoc 1.8.1 has no addressable shape for "create table
        inside this cell" (every available anchor either targets a
        cell-inner paragraph SuperDoc can't resolve, or promotes the
        new block to the cell's parent row level). The unblock is
        tracked at ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 13;
        the same gap was the proximate cause of the
        ``_Cell.add_paragraph`` failure fixed in 0.11.1 (#20745), and
        that fix worked only because ``doc.insert`` accepts a paragraph
        content fragment against a ``tableCell`` target — there is no
        analogous table-content fragment path through the current
        docx-studio command bus.

        ``rows`` and ``cols`` are still validated upfront so callers
        get the same ``ValidationError`` they would have hit before, in
        case they were branching on it.

        Note that upstream's ``_Cell.add_table`` does not take a
        ``width`` parameter — Word inherits cell-table widths from
        layout. ``Document.add_table`` and ``Section.header.add_table``
        DO take ``width`` because they're block-level.
        """
        from docx.errors import NestedTableNotSupportedError

        if rows < 1 or cols < 1:
            raise ValidationError(f"rows/cols must be >=1; got {rows}/{cols}")
        raise NestedTableNotSupportedError(
            "_Cell.add_table is unsupported on SuperDoc 1.8.1. The cell "
            "addressing gap (SUPERDOC_UPSTREAM_REQUESTS.md § 13) means "
            "no anchor or content-fragment shape currently lets the SDK "
            "place a new table inside an existing tableCell. Workarounds: "
            "(a) build the table at document or section level via "
            "Document.add_table and reference it from cell text, or "
            "(b) include the nested table in the original template "
            "document and address its cells directly. This method will "
            "be reinstated once SuperDoc exposes either recursive "
            "paragraph-anchor lookup or a cell-scoped create.table "
            "variant.",
        )

    def merge(self, other_cell: "_Cell") -> "_Cell":
        """Return a merged cell created by spanning the rectangular
        region having this cell and ``other_cell`` as diagonal corners.

        Mirrors python-docx ``_Cell.merge(other_cell)``. Returns the
        **top-left** cell of the merged region so the result is
        addressable consistently regardless of which corner the caller
        started from. The earlier impl always returned ``self``, which
        was wrong when ``self`` was the bottom-right corner.
        """
        if other_cell._table is not self._table:
            raise ValidationError(
                "Cannot merge cells from different tables.",
            )
        # Normalize to top-left / bottom-right so the merge_cells op
        # always receives a well-formed rectangle (start ≤ end). Some
        # SuperDoc validators reject inverted ranges.
        top_row = min(self._row, other_cell._row)
        bot_row = max(self._row, other_cell._row)
        left_col = min(self._col, other_cell._col)
        right_col = max(self._col, other_cell._col)
        nid: str = self._table._fresh_node_id()
        run_sync(
            self._table._session.doc.tables.merge_cells(
                {
                    "nodeId": nid,
                    "start": {"rowIndex": top_row, "columnIndex": left_col},
                    "end": {
                        "rowIndex": bot_row,
                        "columnIndex": right_col,
                    },
                },
            ),
        )
        # Return the top-left cell. If self is already the top-left,
        # return self so we keep cached state; otherwise build a fresh
        # _Cell at the top-left address.
        if self._row == top_row and self._col == left_col:
            return self
        return type(self)(table=self._table, row=top_row, col=left_col)

    @property
    def grid_span(self) -> int:
        """Number of layout-grid columns this cell spans horizontally.

        Mirrors python-docx ``_Cell.grid_span``. A "normal" cell has
        ``grid_span == 1``; a horizontally-merged cell that covers
        three logical columns has ``grid_span == 3``. Vertical merges
        do NOT affect ``grid_span``.

        For secondary-slot ``_Cell`` objects (positions covered by a
        preceding cell's colspan), this returns the master's span — so
        ``cell(0,0).grid_span == cell(0,1).grid_span == 2`` for a row
        with one merged cell spanning two grid columns, matching
        python-docx's ``<w:tc>``-sharing model.
        """
        info = self._cell_info()
        if isinstance(info, dict):
            return _cell_info_colspan(info)
        return 1

    def _inner_block_ids(self) -> list[tuple[str, str]]:
        """Walk the cell's ``getNodeById`` payload and collect every
        block child as ``(nodeId, nodeType)`` in document order.

        Mirrors :func:`_collect_paragraph_ids` but is type-aware —
        paragraph/heading/table blocks all show up. Used by
        :meth:`iter_inner_content`.
        """
        cell_id = self._cell_id()
        session = self._table._session
        # Try the same strategy ladder as _inner_paragraph_ids; whichever
        # response returns blocks wins.
        info: object = None
        for params in (
            {"id": cell_id, "nodeType": "tableCell"},
            {"id": cell_id},
        ):
            try:
                info = run_sync(session.doc.get_node_by_id(params))
                break
            except Exception:
                info = None
        if info is None:
            try:
                info = run_sync(
                    session.doc.get_node(
                        {
                            "target": {
                                "kind": "block",
                                "nodeType": "tableCell",
                                "nodeId": cell_id,
                            },
                        },
                    ),
                )
            except Exception:
                info = None
        out: list[tuple[str, str]] = []
        seen: set[str] = set()
        _collect_block_ids(info, out, seen)
        return out

    def iter_inner_content(self):
        """Yield each paragraph or table inside this cell in order.

        Mirrors python-docx ``_Cell.iter_inner_content() ->
        Iterator[Paragraph | Table]``. Tables nested inside the cell
        appear interleaved with paragraphs at their actual position.
        """
        from docx.text.paragraph import Paragraph

        ooxml_base = self._ooxml_address_base()
        para_idx = 0
        for nid, ntype in self._inner_block_ids():
            if ntype == "table":
                yield Table(session=self._table._session, node_id=nid)
            else:
                # paragraph / heading / listItem all flow through Paragraph
                # — python-docx exposes them all as Paragraph instances.
                ooxml_addr: tuple[int, int, int, int] | None = (
                    (*ooxml_base, para_idx) if ooxml_base is not None else None
                )
                yield Paragraph(
                    session=self._table._session,
                    node_id=nid,
                    node_type=ntype if ntype else "paragraph",
                    in_cell=True,
                    cell_ooxml_address=ooxml_addr,
                    cell=self,
                )
                para_idx += 1

    @property
    def vertical_alignment(self) -> "WD_ALIGN_VERTICAL | None":
        from docx.enum.table import WD_ALIGN_VERTICAL

        info = self._cell_info()
        if info and isinstance(info, dict):
            va = info.get("verticalAlign")
            if isinstance(va, str):
                for m in WD_ALIGN_VERTICAL:
                    if m.value == va:
                        return m
        return None

    @vertical_alignment.setter
    def vertical_alignment(self, value: "WD_ALIGN_VERTICAL | str | None") -> None:
        from docx.enum.table import WD_ALIGN_VERTICAL

        if value is None:
            _warn_table_clear("vertical_alignment", cls="_Cell")
            return
        if isinstance(value, WD_ALIGN_VERTICAL):
            v: str = value.to_superdoc()
        else:
            # Mirror python-docx: assigning an unknown vertical-align
            # value raises ``ValueError`` upstream. Previously this
            # setter silently lower-cased any string and shipped it to
            # the wire, where SuperDoc's permissive parser would either
            # drop it or round-trip a garbage value.
            candidate = str(value).lower()
            if not any(m.value == candidate for m in WD_ALIGN_VERTICAL):
                valid = sorted(m.value for m in WD_ALIGN_VERTICAL)
                raise ValueError(
                    f"{value!r} is not a valid WD_ALIGN_VERTICAL; "
                    f"expected one of {valid}",
                )
            v = candidate
        run_sync(
            self._table._session.doc.tables.set_cell_properties(
                {"target": self._cell_address(), "verticalAlign": v},
            ),
        )

    @property
    def width(self) -> "Length | None":
        info = self._cell_info()
        if info and isinstance(info, dict):
            w = info.get("preferredWidthPt") or info.get("widthPt")
            if isinstance(w, (int, float)):
                return Pt(float(w))
        return None

    @width.setter
    def width(self, value: "Length | int | None") -> None:
        if value is None:
            _warn_table_clear("width", cls="_Cell")
            return
        # Mirror python-docx + ``_Column.width``: cell width is unsigned
        # twips; negative widths previously round-tripped to the wire
        # silently. Reject at the call site so callers learn at the
        # mutation, not on render.
        raw_emu = int(value)
        if raw_emu < 0:
            raise ValueError(
                f"_Cell.width must be non-negative; got EMU={raw_emu}. "
                f"Pass Length(0) (or None) to clear instead of a negative."
            )
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        run_sync(
            self._table._session.doc.tables.set_cell_properties(
                {"target": self._cell_address(), "preferredWidthPt": pt},
            ),
        )

    @property
    def height(self) -> "Length | None":
        # python-docx: Cell has no 'height' directly; row does. Return the row's height.
        row = _Row(table=self._table, index=self._row)
        return row.height

    @height.setter
    def height(self, value: "Length | int | None") -> None:
        row = _Row(table=self._table, index=self._row)
        row.height = value

    @property
    @athena_extension(
        issue=1312,
        description="_Cell.v_merge — vertical-merge state introspection.",
    )
    def v_merge(self) -> str | None:
        """Vertical-merge state of this cell.

        Athena extension beyond python-docx 1.x — issues #1312, #1434,
        #1458 demand robust merged-cell inspection. Returns
        ``"restart"`` if this cell starts a vertical merge, ``"continue"``
        if it continues one, or ``None`` if it's not vertically merged.
        """
        info = self._cell_info()
        if isinstance(info, dict):
            v = info.get("vMerge") or info.get("v_merge")
            if isinstance(v, str):
                return v
            if v is True:
                return "continue"
            if v is False:
                return "restart"
        return None

    @property
    @athena_extension(
        issue=1434,
        description="_Cell.is_merge_continuation — True for vmerge=continue cells.",
    )
    def is_merge_continuation(self) -> bool:
        """``True`` when this cell is a vertical-merge continuation
        (i.e. visually part of the master cell above). Athena extension."""
        return self.v_merge == "continue"

    @property
    @athena_extension(
        issue=1458,
        description="_Cell.is_merge_origin — True for visual master of merged rectangle.",
    )
    def is_merge_origin(self) -> bool:
        """``True`` when this cell is the visual master of a merged
        rectangle (vertical or horizontal). Athena extension."""
        if self.v_merge == "restart":
            return True
        if self.v_merge == "continue":
            return False
        return self.grid_span > 1

    @athena_extension(
        issue=201,
        description="_Cell.set_borders — per-edge cell border control.",
    )
    def set_borders(
        self,
        *,
        top: "dict | str | None" = None,
        bottom: "dict | str | None" = None,
        left: "dict | str | None" = None,
        right: "dict | str | None" = None,
        inside_horizontal: "dict | str | None" = None,
        inside_vertical: "dict | str | None" = None,
    ) -> None:
        """Set per-edge borders on this cell.

        Athena extension beyond python-docx 1.x — issue #201 (5 👍) +
        #1238 demand a cell-borders API. Each edge accepts a wire-format
        ``{style, size_pt, color}`` dict OR a shorthand string like
        ``"single 0.5pt #DDDDDD"``. ``None`` leaves an edge untouched.
        """
        from docx.commands import SetCellBorders

        top = _normalize_border_spec(top, edge="top")
        bottom = _normalize_border_spec(bottom, edge="bottom")
        left = _normalize_border_spec(left, edge="left")
        right = _normalize_border_spec(right, edge="right")
        inside_horizontal = _normalize_border_spec(
            inside_horizontal, edge="inside_horizontal"
        )
        inside_vertical = _normalize_border_spec(
            inside_vertical, edge="inside_vertical"
        )
        run_sync(
            self._table._session.send_command(
                SetCellBorders(
                    target=self._cell_address(),
                    top=top,
                    bottom=bottom,
                    left=left,
                    right=right,
                    inside_horizontal=inside_horizontal,
                    inside_vertical=inside_vertical,
                ),
            ),
        )

    @property
    @athena_extension(issue=201, description="_Cell.borders snapshot.")
    def borders(self) -> dict:
        """Cell borders as a snapshot dict. Athena extension."""
        info = self._cell_info()
        if isinstance(info, dict):
            b = info.get("borders") or info.get("tcBorders")
            if isinstance(b, dict):
                return dict(b)
        return {}

    @borders.setter
    @athena_extension(issue=201, description="_Cell.borders bulk setter.")
    def borders(self, value: dict | None) -> None:
        if value is None or not value:
            self.set_borders(
                top={"style": "none"},
                bottom={"style": "none"},
                left={"style": "none"},
                right={"style": "none"},
            )
            return
        if not isinstance(value, dict):
            raise TypeError(
                f"_Cell.borders requires dict; got {type(value).__name__}",
            )
        self.set_borders(
            top=value.get("top"),
            bottom=value.get("bottom"),
            left=value.get("left"),
            right=value.get("right"),
            inside_horizontal=value.get("inside_horizontal"),
            inside_vertical=value.get("inside_vertical"),
        )

    @athena_extension(issue=146, description="_Cell.set_shading — fill/pattern control.")
    def set_shading(
        self,
        *,
        fill: str | None = None,
        pattern: str | None = None,
        color: str | None = None,
    ) -> None:
        """Set cell fill / shading.

        Athena extension beyond python-docx 1.x — issue #146 (12
        comments) demands cell-shading. ``fill`` is a hex color or
        ``"auto"`` / ``"none"``. ``pattern`` and ``color`` add a
        secondary pattern overlay.

        Wire behavior + post-export rewrite: SuperDoc 1.8.1's
        ``tables.setShading`` accepts the call but drops the shading
        on ``doc.save({out})`` — the exported OOXML has no
        ``<w:shd>`` element (verified against PR #20805 preview).
        We still issue the wire call (so Olympus collaborators see
        the shading live in the Y.Doc state) AND stash the props
        on ``session._post_export_ops`` so :class:`docx._postproc`
        can inject ``<w:shd>`` into the cell's ``<w:tcPr>`` during
        ``Document.export_docx``. Tables created via
        ``Document.add_table`` (which have ``_doc_index`` set)
        participate in the stash; template-seeded tables without
        ``_doc_index`` warn-and-skip the stash but still issue the
        live wire call.
        """
        from docx.commands import SetCellShading

        run_sync(
            self._table._session.send_command(
                SetCellShading(
                    target=self._cell_address(),
                    fill=fill,
                    pattern=pattern,
                    color=color,
                ),
            ),
        )
        # Also stash for the post-export rewrite — see docstring.
        ooxml_base = self._ooxml_address_base()
        if ooxml_base is not None:
            from docx._postproc import CellOnlyAddress

            ops = getattr(self._table._session, "_post_export_ops", None)
            if ops is not None:
                ops.add_cell_shading(
                    CellOnlyAddress(
                        table_doc_index=ooxml_base[0],
                        row=ooxml_base[1],
                        col=ooxml_base[2],
                    ),
                    fill=fill,
                    pattern=pattern,
                    color=color,
                )

    @property
    @athena_extension(issue=146, description="_Cell.shading snapshot.")
    def shading(self) -> dict:
        """Cell shading as a snapshot dict. Athena extension."""
        info = self._cell_info()
        if isinstance(info, dict):
            s = info.get("shading") or info.get("shd")
            if isinstance(s, dict):
                return dict(s)
        return {}

    @shading.setter
    @athena_extension(issue=146, description="_Cell.shading bulk setter.")
    def shading(self, value: str | dict | None) -> None:
        if value is None:
            self.set_shading(fill="auto")
            return
        if isinstance(value, str):
            self.set_shading(fill=value)
            return
        if not isinstance(value, dict):
            raise TypeError(
                f"_Cell.shading requires str hex, dict, or None; got "
                f"{type(value).__name__}",
            )
        self.set_shading(
            fill=value.get("fill"),
            pattern=value.get("pattern"),
            color=value.get("color"),
        )
