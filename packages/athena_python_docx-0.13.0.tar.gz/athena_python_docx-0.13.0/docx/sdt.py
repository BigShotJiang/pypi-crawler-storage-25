"""SDT / Content Controls — Athena extension beyond python-docx 1.x.

python-docx upstream surfaces some read-only SDT support but no add or
update API. Issues #155, #224 (checkboxes), #1417 (text form fields +
checkboxes) demand it. SuperDoc treats SDTs as a typed wrapper node.

Supported kinds:
* ``"rich-text"`` — any inline content
* ``"plain-text"`` — single-paragraph or multi-paragraph plain text
* ``"picture"`` — single image placeholder
* ``"checkbox"`` — Word 2010+ checkbox SDT
* ``"date"`` — date picker
* ``"dropdown"`` — drop-down list (user can only pick listed values)
* ``"combobox"`` — combo box (user can pick or type)
* ``"repeating-section"`` — Word 2013+ repeating container
* ``"group"`` — a group of locked SDTs

See ``python-sdk/CLAUDE.md`` § *Intentional deviations (additions /
different semantics)*.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Iterator

from docx._athena_extension import athena_extension
from docx._batching import run_sync

__athena_extension_module__: bool = True
__athena_extension_issue__: str = "python-docx#155"
__athena_extension_description__: str = "Structured-document-tag (SDT) / content controls."
__athena_extension_since__: str = "0.11.0"

if TYPE_CHECKING:
    from docx.client import Session


@athena_extension(issue=155, description="One content control (SDT).")
class ContentControl:
    """One structured-document-tag (content control) instance."""

    def __init__(
        self,
        *,
        session: "Session",
        sdt_id: str,
        control_kind: str,
        tag: str | None = None,
        alias: str | None = None,
        value: Any = None,
        placeholder: str | None = None,
        properties: dict | None = None,
        locked: bool | None = None,
    ) -> None:
        self._session: "Session" = session
        self._sdt_id: str = sdt_id
        self._control_kind: str = control_kind
        self._tag: str | None = tag
        self._alias: str | None = alias
        self._value: Any = value
        self._placeholder: str | None = placeholder
        self._properties: dict = properties or {}
        self._locked: bool | None = locked

    @property
    def sdt_id(self) -> str:
        return self._sdt_id

    @property
    def control_kind(self) -> str:
        return self._control_kind

    @property
    def tag(self) -> str | None:
        return self._tag

    @property
    def alias(self) -> str | None:
        return self._alias

    @property
    def value(self) -> Any:
        return self._value

    @value.setter
    def value(self, new_value: Any) -> None:
        from docx.commands import ContentControlsPatch

        run_sync(
            self._session.send_command(
                ContentControlsPatch(id=self._sdt_id, value=new_value),
            ),
        )
        self._value = new_value

    @property
    def placeholder(self) -> str | None:
        return self._placeholder

    @placeholder.setter
    def placeholder(self, text: str | None) -> None:
        from docx.commands import ContentControlsPatch

        run_sync(
            self._session.send_command(
                ContentControlsPatch(id=self._sdt_id, placeholder=text),
            ),
        )
        self._placeholder = text

    @property
    def locked(self) -> bool:
        return bool(self._locked)

    @locked.setter
    def locked(self, value: bool) -> None:
        from docx.commands import ContentControlsPatch

        run_sync(
            self._session.send_command(
                ContentControlsPatch(id=self._sdt_id, locked=bool(value)),
            ),
        )
        self._locked = bool(value)

    @property
    def properties(self) -> dict:
        return dict(self._properties)

    def delete(self, *, keep_content: bool = True) -> None:
        """Remove the SDT wrapper. With ``keep_content=True`` (default)
        the wrapped content stays in the document; with ``False`` the
        content is removed too."""
        from docx.commands import ContentControlsDelete

        run_sync(
            self._session.send_command(
                ContentControlsDelete(
                    id=self._sdt_id, keep_content=keep_content,
                ),
            ),
        )


@athena_extension(issue=155, description="Collection of content controls.")
class ContentControls:
    """Collection of content controls in the document."""

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self, *, control_kind: str | None = None) -> list[dict]:
        from docx.commands import ContentControlsList

        result = run_sync(
            self._session.send_command(
                ContentControlsList(control_kind=control_kind),
            ),
        )
        if isinstance(result, dict):
            items = result.get("items") or result.get("controls") or []
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        elif isinstance(result, list):
            return [i for i in result if isinstance(i, dict)]
        return []

    def __iter__(self) -> Iterator[ContentControl]:
        for info in self._items():
            yield self._wrap(info)

    def __len__(self) -> int:
        return len(self._items())

    def __getitem__(self, index_or_tag: int | str) -> ContentControl:
        if isinstance(index_or_tag, str):
            for info in self._items():
                if info.get("tag") == index_or_tag:
                    return self._wrap(info)
            raise KeyError(f"No content control with tag {index_or_tag!r}")
        return self._wrap(self._items()[index_or_tag])

    def get(self, sdt_id: str) -> ContentControl | None:
        for info in self._items():
            if info.get("id") == sdt_id or info.get("sdtId") == sdt_id:
                return self._wrap(info)
        return None

    def filter(self, control_kind: str) -> Iterator[ContentControl]:
        """Yield only controls of a given kind."""
        for info in self._items(control_kind=control_kind):
            yield self._wrap(info)

    def _wrap(self, info: dict) -> ContentControl:
        return ContentControl(
            session=self._session,
            sdt_id=str(info.get("id") or info.get("sdtId") or ""),
            control_kind=str(info.get("controlKind") or info.get("kind") or "rich-text"),
            tag=info.get("tag") if isinstance(info.get("tag"), str) else None,
            alias=info.get("alias") if isinstance(info.get("alias"), str) else None,
            value=info.get("value"),
            placeholder=(
                info.get("placeholder")
                if isinstance(info.get("placeholder"), str)
                else None
            ),
            properties=(
                info.get("properties")
                if isinstance(info.get("properties"), dict)
                else None
            ),
            locked=info.get("locked"),
        )


__all__ = ["ContentControl", "ContentControls"]
