"""Image format / content-type helpers shared by ``Run.add_picture``
and ``Document.add_picture``.

The previous implementations sniffed only by file extension, which
silently mistyped streams (default ``image/png``) and was wrong on
files with mismatched extensions (e.g. ``screenshot.png`` containing
JPEG bytes — common from OS screen-capture flows).

We sniff by **magic bytes** for the four formats SuperDoc accepts as
inline image data URIs (PNG, JPEG, GIF, WebP), with extension as a
secondary fallback for unknown / off-format streams.
"""

from __future__ import annotations

# Magic-byte signatures for the formats SuperDoc accepts inline.
# (mime, signature_bytes, signature_offset). Most are at offset 0;
# WebP needs a two-part check (RIFF header + WEBP marker at offset 8).
_PNG_MAGIC: bytes = b"\x89PNG\r\n\x1a\n"
_JPEG_MAGIC: bytes = b"\xff\xd8\xff"
_GIF87_MAGIC: bytes = b"GIF87a"
_GIF89_MAGIC: bytes = b"GIF89a"
_WEBP_RIFF: bytes = b"RIFF"
_WEBP_MARKER: bytes = b"WEBP"
_BMP_MAGIC: bytes = b"BM"
_TIFF_LE_MAGIC: bytes = b"II*\x00"
_TIFF_BE_MAGIC: bytes = b"MM\x00*"
_SVG_HINT_DECL: bytes = b"<?xml"
_SVG_HINT_TAG: bytes = b"<svg"


def sniff_content_type(image_bytes: bytes, *, fallback_path: str = "") -> str:
    """Return a SuperDoc-acceptable image MIME for ``image_bytes``.

    Magic-byte detection in priority order; if no signature matches,
    fall back to the file extension on ``fallback_path``; if that
    also fails, default to ``"image/png"`` (matches the prior
    silent-default behavior so callers that previously got away with
    it keep working).

    Athena extension beyond python-docx 1.x: also detects SVG, BMP,
    and TIFF. python-docx upstream supports PNG/JPEG/GIF/BMP/TIFF; SVG
    and WEBP are missing from upstream (issues #651, #717, #1399).
    """
    if image_bytes.startswith(_PNG_MAGIC):
        return "image/png"
    if image_bytes.startswith(_JPEG_MAGIC):
        return "image/jpeg"
    if image_bytes.startswith(_GIF87_MAGIC) or image_bytes.startswith(_GIF89_MAGIC):
        return "image/gif"
    if (
        len(image_bytes) >= 12
        and image_bytes.startswith(_WEBP_RIFF)
        and image_bytes[8:12] == _WEBP_MARKER
    ):
        return "image/webp"
    if image_bytes.startswith(_BMP_MAGIC):
        return "image/bmp"
    if image_bytes.startswith(_TIFF_LE_MAGIC) or image_bytes.startswith(_TIFF_BE_MAGIC):
        return "image/tiff"
    # SVG: probe first ~1KB for either an XML declaration or a literal
    # ``<svg`` tag. Case-insensitive on the tag because legitimate SVG
    # files sometimes carry ``<SVG`` after author tools.
    head = image_bytes[:1024]
    if _SVG_HINT_TAG in head or _SVG_HINT_TAG in head.lower():
        return "image/svg+xml"
    if head.startswith(_SVG_HINT_DECL) and b"<svg" in head.lower():
        return "image/svg+xml"

    if fallback_path:
        lower = fallback_path.lower()
        if lower.endswith((".jpg", ".jpeg")):
            return "image/jpeg"
        if lower.endswith(".gif"):
            return "image/gif"
        if lower.endswith(".webp"):
            return "image/webp"
        if lower.endswith(".png"):
            return "image/png"
        if lower.endswith(".svg"):
            return "image/svg+xml"
        if lower.endswith(".bmp"):
            return "image/bmp"
        if lower.endswith((".tif", ".tiff")):
            return "image/tiff"

    return "image/png"


__all__ = ["sniff_content_type"]
