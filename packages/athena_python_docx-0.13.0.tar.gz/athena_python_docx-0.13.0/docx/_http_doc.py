"""HTTP-backed Superdoc document handle.

Wire format (matches ``apps/api/src/commands/types.ts``):

    POST /docs/:id/commands
    {
      "client": {"type": "python-sdk", "version": "<x.y.z>"},
      "commands": [
        {"type": "CreateParagraph", "text": "Hi", "at": {"kind": "documentEnd"}},
        ...
      ],
      "return": {"snapshot": false}
    }

The path-proxy at the bottom of this file is the SDK's internal call surface
— call sites still use ``self._session.doc.create.paragraph({...})`` for
historical reasons. The proxy converts the dotted path + camelCase params
dict into a typed :class:`docx.commands.Command`, then routes it through
:class:`docx._buffer.CommandBuffer` so:

* queries / creates flush eagerly (and drain pending mutations in the same
  HTTP request),
* pure mutations buffer and auto-flush on a short idle window.

Removing the path-proxy facade and rewriting call sites to construct
:class:`Command` instances directly is a deliberate follow-up — the wire
format is now typed end-to-end either way.
"""

from __future__ import annotations

import json
import os
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from docx._buffer import CommandBuffer
from docx.commands import (
    BlocksList,
    BookmarksGet,
    BookmarksList,
    ChartsGet,
    ChartsList,
    ClearParagraphAlignment,
    ClearParagraphIndentation,
    ClearParagraphSpacing,
    ClearParagraphTabStops,
    Command,
    CommentsCreate,
    CommentsDelete,
    CommentsGet,
    CommentsList,
    CommentsPatch,
    ContentControlsDelete,
    ContentControlsGet,
    ContentControlsList,
    ContentControlsPatch,
    CreateBookmark,
    CreateCaption,
    CreateChart,
    CreateContentControl,
    CreateCrossReference,
    CreateEndnote,
    CreateField,
    CreateFootnote,
    CreateHeading,
    CreateHyperlink,
    CreateImage,
    CreateMath,
    CreateParagraph,
    CreateSectionBreak,
    CreateTable,
    CreateTOC,
    CreateWatermark,
    DeleteBookmark,
    DeleteWatermark,
    EndnotesDelete,
    EndnotesGet,
    EndnotesList,
    EndnotesPatch,
    ExportPDF,
    FieldsList,
    FieldsRefresh,
    Find,
    FindReplace,
    FootnotesDelete,
    FootnotesGet,
    FootnotesList,
    FootnotesPatch,
    FormatApply,
    GetNode,
    GetNodeById,
    HeaderFootersGet,
    HeaderFootersList,
    HeaderFootersRefsSetLinkedToPrevious,
    HeaderFootersResolve,
    ImagesGet,
    ImagesList,
    Info,
    Insert,
    InsertLineBreak,
    InsertTab,
    IterRuns,
    ListsAttach,
    ListsCreate,
    ListsMerge,
    ListsSplit,
    MarkdownToFragment,
    MathPatch,
    NumberingGet,
    NumberingList,
    RefreshTOC,
    RemoveHyperlink,
    Replace,
    SectionsGet,
    SectionsList,
    SelectionCurrent,
    SetCellBorders,
    SetCellShading,
    SetChartData,
    SetChartType,
    SetImageAltText,
    SetImageAnchor,
    SetImageDecorative,
    SetImageSize,
    SetParagraphAlignment,
    SetParagraphFlowOptions,
    SetParagraphIndentation,
    SetParagraphKeepOptions,
    SetParagraphSpacing,
    SetParagraphStyle,
    SetParagraphTabStop,
    SetSectionBreakType,
    SetSectionColumns,
    SetSectionHeaderFooterMargins,
    SetSectionLinkToPrevious,
    SetSectionPageMargins,
    SetSectionPageSetup,
    SetSectionTitlePage,
    SetSectionsOddEvenHeadersFooters,
    SetTableBorders,
    TablesGet,
    TablesGetCells,
    TablesGetProperties,
    TablesInsertColumn,
    TablesInsertRow,
    TablesMergeCells,
    TablesSetCellProperties,
    TablesSetColumnWidth,
    TablesSetLayout,
    TablesSetRowHeight,
    TablesSetStyle,
    TablesSetTableOptions,
    TableSetCell,
    TrackChangesDecide,
    TrackChangesGet,
    TrackChangesList,
)
from docx.errors import (
    AuthenticationError,
    BlockNotFoundError,
    DocxError,
    DocxStudioTemporarilyUnavailable,
    NotFoundError,
    SessionError,
)


_NOT_FOUND_ERROR_NAMES: frozenset[str] = frozenset(
    {
        "notfound",
        "notfounderror",
        "entitynotfound",
        "entitynotfounderror",
        "commentnotfound",
        "commentnotfounderror",
        "nodenotfound",
        "nodenotfounderror",
        "missingnode",
        "missingnodeerror",
    }
)


def _looks_like_block_not_found(err_obj: dict) -> bool:
    """Detect SuperDoc's cell-inner-paragraph addressing failures.

    SuperDoc emits two shapes for the same underlying gap
    (``SUPERDOC_UPSTREAM_REQUESTS.md`` § 13):

    * ``Block "paragraph:<uuid>" was not found.`` — older "not found" form.
    * ``INVALID_TARGET - Expected paragraph:<uuid> but found tableCell:<id>.``
      — newer type-mismatch form, surfaced when the supplied paragraph
      anchor resolves to its containing ``tableCell`` instead.

    Both surface as :class:`BlockNotFoundError` so agent code can route
    them through the same cell-paragraph hint path.
    """
    msg = err_obj.get("message")
    if not isinstance(msg, str):
        return False
    lower = msg.lower()
    if "not found" in lower:
        return 'block "' in lower or (
            'block ' in lower and ' was not found' in lower
        )
    if "invalid_target" in lower or "invalid target" in lower:
        # "Expected paragraph:<id> but found tableCell:<id>" — the new
        # variant of the § 13 cell-inner-paragraph addressing gap.
        return "but found tablecell" in lower
    return False


# Commands that target a paragraph block (or its inline range) and
# therefore trip the SuperDoc 1.8.1 cell-paragraph addressing gap when
# the target paragraph is nested inside a ``tableCell``. Used by the
# ``BlockNotFoundError`` hint logic to decide whether to surface the
# materialization workaround. Membership is checked against the
# ``err_obj["type"]`` field that ``apps/api`` echoes back on partial
# failure, so the gate covers both error-message shapes the SuperDoc
# CLI emits:
#
# * ``Block "paragraph:<uuid>" was not found.`` (SetParagraph*, etc.)
# * ``Block "<uuid>" not found.``                (Insert)
#
# Without this gate, the hint either fired for stale-id misses on
# unrelated command types (Greptile #20555) or skipped the Insert form
# entirely (preview session
# thread_b952794f, where 3 of 4 failures were bare-UUID Inserts and
# the agent burned 4 retries without ever seeing the workaround).
_PARAGRAPH_TARGETING_COMMANDS: frozenset[str] = frozenset(
    {
        "Insert",
        "FormatApply",
        "SetParagraphAlignment",
        "ClearParagraphAlignment",
        "SetParagraphStyle",
        "SetParagraphIndentation",
        "ClearParagraphIndentation",
        "SetParagraphSpacing",
        "ClearParagraphSpacing",
        "SetParagraphKeepOptions",
        "SetParagraphFlowOptions",
        "SetParagraphTabStop",
        "ClearParagraphTabStops",
        "Replace",
        "InsertLineBreak",
        "InsertTab",
        # Create-* anchor-into-cell-inner-paragraph variant of § 13.
        "CreateParagraph",
        "CreateHeading",
        "CreateTable",
        "CreateImage",
    }
)


_CELL_PARAGRAPH_HINT: str = (
    "\n\nHint: SuperDoc 1.8.1 cannot format paragraphs nested inside "
    "table cells via SetParagraphAlignment / SetParagraphStyle / "
    "SetParagraphIndentation / SetParagraphSpacing / doc.insert with "
    "a paragraph-block target. The cell's original inner paragraph id "
    "(returned by ``cell.paragraphs[0]`` on a freshly-loaded cell) "
    "isn't a top-level addressable block.\n\nWorkaround: create a "
    "fresh paragraph in the cell via ``para = cell.add_paragraph(text)`` "
    "— 0.11.1+ routes that through ``doc.insert`` against the cell "
    "with ``placement: 'insideEnd'``, so the returned ``Paragraph`` "
    "proxy points at an addressable block. Apply format ops to that "
    "proxy:\n\n"
    '    para = cell.add_paragraph("MAY 2026")\n'
    "    para.alignment = WD_ALIGN_PARAGRAPH.RIGHT  # works\n"
    "    para.add_run(...).bold = True             # also works\n\n"
    "Do NOT use ``cell.paragraphs[0].alignment = X`` on a freshly-"
    "loaded cell — that targets the original cell-inner paragraph "
    "which can't be addressed for format ops. If the cell already "
    "has agent-authored content, use ``cell.paragraphs[-1]`` (the "
    "most-recently-inserted paragraph, which is addressable). "
    "Tracked upstream at docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md "
    "§ 'cell-inner paragraph addressing'."
)


# ``tables.get`` / ``tables.getCells`` / ``tables.getProperties`` carry
# the table id at the top-level ``nodeId`` field — and the agent code
# that triggers them (``table.cell(0, 0)``, ``table.rows``, etc.) runs
# *immediately* after ``doc.add_table(...)``. The first such query
# triggers an eager flush that drains the buffered CreateTable in the
# same HTTP batch, so the applier's per-batch ``clientIdMap`` rewrite
# normally catches it. But when an EARLIER batch (e.g. a doomed cell-
# paragraph mutation a few lines up in the user script) raised before
# the SDK could rewrite ``proxy_id_refs``, the Table proxy still holds
# the client UUID. The next batch ships the dead id straight to SuperDoc
# and we land here. The hint points the agent at the canonical recovery
# pattern (force a save() to reseat the proxy refs, or split the
# offending mutation into its own execution).
_TABLE_QUERY_COMMANDS: frozenset[str] = frozenset(
    {
        "TablesGet",
        "TablesGetCells",
        "TablesGetProperties",
        "TablesSetStyle",
        "TablesSetLayout",
        "TablesSetTableOptions",
        "TablesSetCellProperties",
        "TablesSetColumnWidth",
        "TablesSetRowHeight",
        "TablesInsertRow",
        "TablesInsertColumn",
        "TablesMergeCells",
    }
)


_TABLE_CLIENT_ID_HINT: str = (
    "\n\nHint: this looks like a stale client-side table UUID "
    '(``t_xxxxxxxxxxxx``). Either an earlier batch in this execution '
    "raised before the SDK could rewrite the Table proxy's id from the "
    "client UUID to the real SuperDoc id, OR the table belongs to a "
    "prior execution whose state has been discarded. Recover by calling "
    "``doc.save()`` to drain pending mutations + re-anchor live "
    "proxies, then re-query via ``doc.tables`` to get fresh proxies "
    "with real ids. If you saw a cell-paragraph error in the same "
    "execution, address that first — its partial-failure is what "
    "abandoned the rewrite."
)


def _looks_like_not_found(parsed: dict) -> bool:
    """Inspect a docx-studio partial-failure dict and decide whether it
    describes a "no such entity" miss (vs. a real transport / validation
    failure).

    Prefers a structured signal (the server-side error class name, or a
    typed ``code`` field) and falls back to a broadened set of message
    substrings so phrasing changes upstream don't silently re-route a
    miss into a transport error.
    """
    if not isinstance(parsed, dict):
        return False
    err_obj = parsed.get("error")
    code = parsed.get("code")
    name_candidates: list[str] = []
    if isinstance(err_obj, str):
        name_candidates.append(err_obj)
    elif isinstance(err_obj, dict):
        for key in ("name", "code", "type", "kind"):
            v = err_obj.get(key)
            if isinstance(v, str):
                name_candidates.append(v)
    if isinstance(code, str):
        name_candidates.append(code)
    for name in name_candidates:
        if name.replace("_", "").replace("-", "").lower() in _NOT_FOUND_ERROR_NAMES:
            return True
    if parsed.get("status") == 404 or parsed.get("statusCode") == 404:
        return True
    # Broad substring fallback (case-insensitive) — covers phrasing
    # variants the server (or SuperDoc) may use before a typed error
    # code lands. Includes the original 3 patterns plus additional
    # common phrasings.
    msg_parts: list[str] = []
    for key in ("message", "detail", "error"):
        v = parsed.get(key)
        if isinstance(v, str):
            msg_parts.append(v)
        elif isinstance(v, dict):
            inner = v.get("message")
            if isinstance(inner, str):
                msg_parts.append(inner)
    haystack = " ".join(msg_parts).lower()
    if not haystack:
        return False
    return any(
        needle in haystack
        for needle in (
            "not found",
            "no such",
            "does not exist",
            "doesn't exist",
            "doesnt exist",
            "404",
            "unknown id",
            "missing entity",
        )
    )


def _user_agent() -> str:
    # Lazy import — docx/__init__.py imports api.py at package load, but
    # _http_doc is only imported lazily from client.py at session-open
    # time, so the package is fully initialized by the time this runs.
    from docx import __version__

    return f"athena-python-docx/{__version__}"


def _sdk_version() -> str:
    from docx import __version__

    return __version__


def _build_retry_session() -> requests.Session:
    """A requests.Session with status-only retry for transient failures.

    Retries up to 3 times with exponential backoff on 429/502/503/504.
    With ``backoff_factor=2.0`` the delays are ~2s, ~4s, ~8s — total
    budget ~14s. Jitter (``backoff_jitter=0.5``) is added when urllib3
    supports it (≥2.0) so concurrent retries don't synchronize and
    thunder-herd a recovering pod.

    Connect/read retries are explicitly disabled: the server's batch
    handler leaves the doc in an undefined state on partial failure, so
    a connection drop *after* the server processed the request would
    risk double-applying the successful prefix on a transport-level
    retry. Status-code retries are safe — the server explicitly signaled
    "try again" and didn't commit the work.
    """
    s = requests.Session()
    retry_kwargs: dict[str, Any] = {
        "total": None,
        "status": 3,
        "connect": 0,
        "read": 0,
        "other": 0,
        "backoff_factor": 2.0,
        "status_forcelist": (429, 502, 503, 504),
        "allowed_methods": frozenset(["POST"]),
        "raise_on_status": False,
        "respect_retry_after_header": True,
    }
    # urllib3 ≥2.0 supports `backoff_jitter` and `backoff_max` as
    # constructor params; older releases will reject them with a TypeError.
    import inspect

    retry_params = inspect.signature(Retry).parameters
    if "backoff_jitter" in retry_params:
        retry_kwargs["backoff_jitter"] = 0.5
    if "backoff_max" in retry_params:
        retry_kwargs["backoff_max"] = 10.0
    retry = Retry(**retry_kwargs)
    adapter = HTTPAdapter(max_retries=retry)
    s.mount("http://", adapter)
    s.mount("https://", adapter)
    return s


def _parse_retry_after(value: str | None) -> float | None:
    """Best-effort parse of an HTTP ``Retry-After`` header value.

    The spec allows either seconds (an integer) or an HTTP-date. We only
    surface the seconds form to the typed error — agents reading
    ``retry_after_seconds`` get a number they can sleep on without
    parsing dates. Returns ``None`` for absent / unparseable values.
    """
    if not value:
        return None
    try:
        return float(value.strip())
    except (ValueError, AttributeError):
        return None


def _http_post_json(
    *,
    session: requests.Session,
    url: str,
    api_key: str,
    body: dict,
    timeout: float = 60.0,
) -> dict:
    """POST JSON, parse JSON, raise typed errors on non-2xx."""
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
        "User-Agent": _user_agent(),
    }
    custom_attr = os.environ.get("ATHENA_DOCX_CUSTOM_ATTRIBUTIONS")
    if custom_attr:
        headers["X-Custom-Attributions"] = custom_attr
    try:
        resp = session.post(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers=headers,
            timeout=timeout,
        )
    except requests.ConnectionError as e:
        # ``RemoteDisconnected`` (server closed the TCP connection
        # without a response) and ``ProtocolError`` (connection
        # aborted mid-response) typically surface on long-running
        # batches — the docx-studio nginx ingress idle-timeout or
        # the SuperDoc CLI worker watchdog can both kill an
        # in-flight request after a few minutes. We don't
        # auto-retry these because the server may have already
        # committed the work; a transport-level retry would risk
        # double-applying the prefix that succeeded server-side.
        # Instead, surface a typed error with actionable guidance
        # so the agent can split the work into smaller batches.
        # Identify the underlying error class without importing it
        # — ``urllib3.exceptions.ProtocolError`` /
        # ``http.client.RemoteDisconnected`` sit several wrap-layers
        # deep and the import paths are version-sensitive.
        err_chain = repr(e)
        is_remote_disconnect = (
            "RemoteDisconnected" in err_chain
            or "ProtocolError" in err_chain
            or "Connection aborted" in err_chain
        )
        if is_remote_disconnect:
            n_commands = (
                len(body.get("commands", []))
                if isinstance(body, dict)
                and isinstance(body.get("commands"), list)
                else 0
            )
            hint = (
                "docx-studio dropped the connection before sending a "
                f"response (RemoteDisconnected) on a batch of "
                f"~{n_commands} commands. The most common cause is an "
                "idle-timeout on the docx-studio nginx ingress (~60s "
                "wall clock) firing on a long-running SuperDoc CLI "
                "operation. The server may or may not have committed "
                "the work — the SDK cannot safely retry because that "
                "would risk double-applying the successful prefix.\n"
                "Recovery options:\n"
                "  1. Re-open the document (``doc = Document(asset_id)``) "
                "and continue the work in smaller chunks — flush every "
                "~30 commands via ``doc.save()`` so each batch fits "
                "comfortably under the ingress idle window.\n"
                "  2. Break paragraph-heavy sections into separate "
                "tool calls. Each ``execute_word_document_code`` "
                "invocation starts a fresh HTTP connection.\n"
                "  3. If the document already contains everything you "
                "expected, the connection drop happened AFTER the "
                "server committed — re-open and inspect "
                "``len(doc.paragraphs)`` / ``len(doc.tables)`` before "
                "retrying."
            )
            raise SessionError(f"{hint}\n\nOriginal error: {e}") from e
        raise SessionError(
            f"Unable to reach docx-studio at {url}: {e}",
        ) from e
    except requests.Timeout as e:
        raise SessionError(
            f"docx-studio timed out at {url}: {e}. Split the work "
            "into smaller batches (~30 commands per ``doc.save()``) "
            "to fit under the ingress idle window.",
        ) from e

    # 207 (Multi-Status) is the server's signal for partial-batch
    # failure: some commands succeeded, some failed. We surface it as a
    # DocxError so callers can't silently consume a short `applied`
    # array and act on the wrong command's result. Must come BEFORE the
    # 2xx success path because 207 ∈ [200, 300).
    if resp.status_code == 207:
        body = resp.text
        try:
            parsed = json.loads(body) if body else {}
        except json.JSONDecodeError:
            parsed = {"raw": body}
        # Extract the ``applied`` prefix so callers can rewrite
        # ``proxy_id_refs`` for commands that DID succeed before the
        # batch hit its first failure. Without this, the SDK throws
        # away every successful Create's client-UUID → real-id mapping
        # the moment ONE command fails, and the next batch keeps
        # shipping dead client UUIDs. That cascade turned the preview-
        # session thread_bafba02b's first cell-paragraph mistake into
        # thirteen downstream "Block not found" errors and finally a
        # ``DOCUMENT_IDENTITY_CONFLICT``. The structure is wire-shape:
        # ``[{index, type, result: {client_node_id, real_node_id, …}}]``.
        applied_raw = parsed.get("applied") if isinstance(parsed, dict) else None
        partial_applied: list[dict] = []
        if isinstance(applied_raw, list):
            partial_applied = [a for a in applied_raw if isinstance(a, dict)]
        # If the failing command's error looks like "no such entity",
        # raise a typed :class:`NotFoundError` so speculative-read call
        # sites (``Comments.get``) can coerce it to ``None`` without
        # swallowing real transport / validation failures.
        err_obj = parsed.get("error") if isinstance(parsed, dict) else None
        if isinstance(err_obj, dict):
            base_msg = f"docx-studio batch reported a partial failure: {parsed!r}"
            # ``BlockNotFoundError`` is the narrower miss — caller is most
            # likely targeting a cell-inner paragraph or stale-session
            # block id. Surface the typed exception plus an agent-readable
            # workaround so the next attempt doesn't repeat the same
            # mistake.
            #
            # The cell-paragraph hint applies when the failing command is
            # a paragraph-targeting op (Insert, FormatApply, SetParagraph*,
            # …). We can't gate on the ``paragraph:`` prefix alone — the
            # bare-UUID ``Block "<uuid>" not found.`` shape that SuperDoc's
            # CLI emits for ``Insert`` failures is the dominant form of
            # this bug in practice (preview-session thread_b952794f hit
            # it 3 of 4 times without ever seeing the workaround under the
            # prefix-only gate).
            if _looks_like_block_not_found(err_obj):
                cmd_type = err_obj.get("type")
                paragraph_targeting = (
                    isinstance(cmd_type, str)
                    and cmd_type in _PARAGRAPH_TARGETING_COMMANDS
                )
                table_query = (
                    isinstance(cmd_type, str)
                    and cmd_type in _TABLE_QUERY_COMMANDS
                )
                if paragraph_targeting:
                    hint = _CELL_PARAGRAPH_HINT
                elif table_query:
                    hint = _TABLE_CLIENT_ID_HINT
                else:
                    hint = ""
                raise BlockNotFoundError(
                    base_msg + hint,
                    payload=err_obj,
                ).with_partial_applied(partial_applied)
            if _looks_like_not_found(err_obj):
                raise NotFoundError(
                    base_msg,
                    payload=err_obj,
                ).with_partial_applied(partial_applied)
        raise DocxError(
            f"docx-studio batch reported a partial failure: {parsed!r}",
        ).with_partial_applied(partial_applied)

    if 200 <= resp.status_code < 300:
        try:
            return resp.json()
        except ValueError as e:
            raise DocxError(
                f"docx-studio returned non-JSON body: {resp.text[:200]!r}",
            ) from e

    err_body: str = resp.text
    if resp.status_code in (401, 403):
        raise AuthenticationError(
            f"docx-studio rejected the request (HTTP {resp.status_code}): {err_body}",
        )
    if resp.status_code == 404:
        raise NotFoundError(
            f"docx-studio returned HTTP 404: {err_body}",
            payload={"status": 404, "body": err_body},
        )
    if resp.status_code in (502, 503, 504):
        # Retries already exhausted by the Retry adapter; surface a typed
        # transient-failure exception so agent code can distinguish a
        # studio-down state from a script/document error and decide
        # whether to back off at the agent level.
        raise DocxStudioTemporarilyUnavailable(
            f"docx-studio returned HTTP {resp.status_code}: {err_body}",
            http_status=resp.status_code,
            retry_after_seconds=_parse_retry_after(resp.headers.get("Retry-After")),
        )
    raise DocxError(
        f"docx-studio returned HTTP {resp.status_code}: {err_body}",
    )


# ---------------------------------------------------------------------------
# HttpClient — the bare HTTP transport. Stateless wrt batching.
# ---------------------------------------------------------------------------


class HttpClient:
    """Owns the HTTP transport for a Document.

    One HttpClient per Document; one shared :class:`requests.Session` per
    HttpClient (so connection pooling + retry strategy is reused across
    consecutive batches). Stateless wrt batching — the
    :class:`CommandBuffer` sitting in front of it owns the queue.
    """

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        session: requests.Session | None = None,
    ) -> None:
        self._base_url: str = base_url.rstrip("/")
        self._api_key: str = api_key
        self._session: requests.Session = session or _build_retry_session()

    def close(self) -> None:
        """Release the pooled HTTP connections held by ``requests.Session``.

        Idempotent — ``requests.Session.close`` tolerates being called
        multiple times. Long-lived workers that open and close many
        documents will leak sockets without this.
        """
        try:
            self._session.close()
        except Exception:  # noqa: BLE001
            pass

    def execute_batch(
        self,
        asset_id: str,
        commands: list[Command],
        *,
        change_mode: str | None = None,
        user: dict[str, str] | None = None,
    ) -> list[Any]:
        """POST a batch of typed commands, return per-command result dicts.

        Envelope fields:
            change_mode: ``"direct"`` | ``"tracked"`` | ``None``. When
                set, the server injects this into every mutation
                forwarded to SuperDoc — tracked edits land as
                ``<w:ins>`` / ``<w:del>`` revisions instead of replacing
                the underlying text.
            user: ``{"name": ..., "email": ...}`` identity for
                tracked-change attribution. Honored only when SuperDoc
                opens the per-asset session for the first time; ignored
                on subsequent batches against the same pooled session.

        On success, length matches len(commands). On 207 partial-failure,
        the server returns 207 with `applied` (the successful prefix) plus
        an `error` for the failing command — :func:`_http_post_json`
        translates that to a :class:`DocxError`. We don't pad partial
        results because the doc state is undefined.
        """
        if not commands:
            return []

        url: str = f"{self._base_url}/docs/{asset_id}/commands"
        body: dict[str, Any] = {
            "client": {"type": "python-sdk", "version": _sdk_version()},
            "commands": [c.to_dict() for c in commands],
            "return": {"snapshot": False},
        }
        if change_mode is not None:
            body["changeMode"] = change_mode
        if user is not None:
            body["user"] = user
        resp: dict = _http_post_json(
            session=self._session,
            url=url,
            api_key=self._api_key,
            body=body,
        )
        applied = resp.get("applied")
        # An empty applied list paired with an `error` field is the
        # 'all-commands-failed' shape — surface it rather than returning
        # an empty result list to a caller that's about to index [-1].
        if not isinstance(applied, list) or (not applied and resp.get("error")):
            err = resp.get("error")
            if err:
                raise DocxError(f"docx-studio batch failed: {err!r}")
            raise DocxError(
                f"docx-studio response missing applied[]: {resp!r}",
            )

        if len(applied) != len(commands):
            raise DocxError(
                f"docx-studio applied {len(applied)} of {len(commands)} commands",
            )

        results: list[Any] = []
        for entry in applied:
            if isinstance(entry, dict):
                result = entry.get("result")
                results.append(result if isinstance(result, dict) else {})
            else:
                results.append({})
        return results


# ---------------------------------------------------------------------------
# Path proxy — translates dotted paths + camelCase param dicts into typed
# Command instances and ships them through the buffer.
# ---------------------------------------------------------------------------


# Map snake_case dotted paths (the "op" name as the SDK constructs it via
# attribute walking) to Command classes. Centralized here so adding a new
# op = adding a row to this table + a Command subclass + a Zod schema.
_OP_TO_COMMAND: dict[str, type[Command]] = {
    # Block creation
    "create.paragraph": CreateParagraph,
    "create.heading": CreateHeading,
    "create.table": CreateTable,
    "create.image": CreateImage,
    "create.section_break": CreateSectionBreak,
    # Inline mutations
    "insert": Insert,
    "replace": Replace,
    "insert_line_break": InsertLineBreak,
    "insert_tab": InsertTab,
    "format.apply": FormatApply,
    "format.paragraph.set_alignment": SetParagraphAlignment,
    "format.paragraph.clear_alignment": ClearParagraphAlignment,
    "format.paragraph.set_indentation": SetParagraphIndentation,
    "format.paragraph.clear_indentation": ClearParagraphIndentation,
    "format.paragraph.set_spacing": SetParagraphSpacing,
    "format.paragraph.clear_spacing": ClearParagraphSpacing,
    "format.paragraph.set_keep_options": SetParagraphKeepOptions,
    "format.paragraph.set_flow_options": SetParagraphFlowOptions,
    "format.paragraph.set_tab_stop": SetParagraphTabStop,
    "format.paragraph.clear_all_tab_stops": ClearParagraphTabStops,
    "styles.paragraph.set_style": SetParagraphStyle,
    # Sections
    "sections.set_page_margins": SetSectionPageMargins,
    "sections.set_page_setup": SetSectionPageSetup,
    "sections.set_header_footer_margins": SetSectionHeaderFooterMargins,
    "sections.set_break_type": SetSectionBreakType,
    "sections.set_title_page": SetSectionTitlePage,
    "sections.set_odd_even_headers_footers": SetSectionsOddEvenHeadersFooters,
    "sections.set_link_to_previous": SetSectionLinkToPrevious,
    # Tables (mutations)
    "tables.insert_row": TablesInsertRow,
    "tables.insert_column": TablesInsertColumn,
    "tables.merge_cells": TablesMergeCells,
    "tables.set_style": TablesSetStyle,
    "tables.set_layout": TablesSetLayout,
    "tables.set_table_options": TablesSetTableOptions,
    "tables.set_cell_properties": TablesSetCellProperties,
    "tables.set_column_width": TablesSetColumnWidth,
    "tables.set_row_height": TablesSetRowHeight,
    "tables.set_cell": TableSetCell,
    # Images (mutations)
    "images.set_size": SetImageSize,
    "images.set_alt_text": SetImageAltText,
    "images.set_decorative": SetImageDecorative,
    "images.get": ImagesGet,
    # Queries
    "blocks.list": BlocksList,
    "find": Find,
    "get_node_by_id": GetNodeById,
    "get_node": GetNode,
    "images.list": ImagesList,
    "info": Info,
    "sections.list": SectionsList,
    "sections.get": SectionsGet,
    "tables.get": TablesGet,
    "tables.get_cells": TablesGetCells,
    "tables.get_properties": TablesGetProperties,
    "markdown_to_fragment": MarkdownToFragment,
    # Comments
    "comments.create": CommentsCreate,
    "comments.patch": CommentsPatch,
    "comments.delete": CommentsDelete,
    "comments.get": CommentsGet,
    "comments.list": CommentsList,
    # Headers & Footers
    "header_footers.list": HeaderFootersList,
    "header_footers.get": HeaderFootersGet,
    "header_footers.resolve": HeaderFootersResolve,
    "header_footers.refs.set_linked_to_previous": HeaderFootersRefsSetLinkedToPrevious,
    # Lists & Selection. ``lists.create`` and ``lists.attach`` are
    # consumed internally by ``Document.add_paragraph`` to make
    # ``style="List Bullet" | "List Number"`` produce real list
    # structure (not just a style attribute on a flat paragraph).
    # ``lists.merge``/``lists.split`` stay typed-bus-only — no
    # python-docx parity surface for them.
    "lists.create": ListsCreate,
    "lists.attach": ListsAttach,
    "lists.merge": ListsMerge,
    "lists.split": ListsSplit,
    "selection.current": SelectionCurrent,
    # Track Changes (Athena extension — see docx.revisions.Revisions).
    # python-docx upstream has no track-changes API; the SDK exposes
    # this as Document.revisions and Document.track_revisions.
    "track_changes.list": TrackChangesList,
    "track_changes.get": TrackChangesGet,
    "track_changes.decide": TrackChangesDecide,

    # --- Athena-extension ops (v0.11.0) -----------------------------------
    # Mirror the dotted-path style of the upstream-parity routes above:
    # ``hyperlinks.create`` matches SuperDoc's ``doc.hyperlinks.create``.
    "hyperlinks.create": CreateHyperlink,
    "hyperlinks.remove": RemoveHyperlink,
    "fields.insert": CreateField,
    "fields.refresh": FieldsRefresh,
    "fields.list": FieldsList,
    "bookmarks.create": CreateBookmark,
    "bookmarks.delete": DeleteBookmark,
    "bookmarks.list": BookmarksList,
    "bookmarks.get": BookmarksGet,
    "footnotes.create": CreateFootnote,
    "footnotes.list": FootnotesList,
    "footnotes.get": FootnotesGet,
    "footnotes.patch": FootnotesPatch,
    "footnotes.delete": FootnotesDelete,
    "endnotes.create": CreateEndnote,
    "endnotes.list": EndnotesList,
    "endnotes.get": EndnotesGet,
    "endnotes.patch": EndnotesPatch,
    "endnotes.delete": EndnotesDelete,
    "toc.create": CreateTOC,
    "toc.refresh": RefreshTOC,
    "captions.create": CreateCaption,
    "cross_references.create": CreateCrossReference,
    "tables.set_cell_borders": SetCellBorders,
    "tables.set_cell_shading": SetCellShading,
    "tables.set_borders": SetTableBorders,
    "images.set_anchor": SetImageAnchor,
    "watermarks.create": CreateWatermark,
    "watermarks.delete": DeleteWatermark,
    "charts.create": CreateChart,
    "charts.set_data": SetChartData,
    "charts.set_type": SetChartType,
    "charts.list": ChartsList,
    "charts.get": ChartsGet,
    "math.create": CreateMath,
    "math.patch": MathPatch,
    "sdt.create": CreateContentControl,
    "sdt.list": ContentControlsList,
    "sdt.get": ContentControlsGet,
    "sdt.patch": ContentControlsPatch,
    "sdt.delete": ContentControlsDelete,
    "sections.set_columns": SetSectionColumns,
    "find_replace": FindReplace,
    "iter_runs": IterRuns,
    "export_pdf": ExportPDF,
    "numbering.get": NumberingGet,
    "numbering.list": NumberingList,
}


def _camel_to_snake(s: str) -> str:
    out: list[str] = []
    for i, ch in enumerate(s):
        if ch.isupper() and i > 0:
            out.append("_")
        out.append(ch.lower())
    return "".join(out)


# Wire-level field renames per op. The Python SDK passes some keys whose
# names collide with our discriminator (`type`); we route them through
# differently-named dataclass fields and rename back in the server applier.
_FIELD_RENAMES: dict[str, dict[str, str]] = {
    "find": {"type": "node_type"},
    "insert": {"type": "value_type"},
    # `in` is a Python reserved keyword; the Command dataclass field is
    # `in_` (trailing underscore). When callers thread the canonical wire
    # name `in` (e.g., header/footer story locators on create.* ops) the
    # path-proxy → snake-case transform leaves it as `in`, which then
    # clashes at `cls(**snake_params)` since the dataclass declares
    # `in_`. Rename here so SuperDoc-shaped payloads round-trip cleanly.
    "create.paragraph": {"in": "in_"},
    "create.heading": {"in": "in_"},
    "create.table": {"in": "in_"},
    # SuperDoc's track-changes-list filter is named `type:` on the wire
    # (matching the rest of its API), but `type` is our Command
    # discriminator. Rename to `change_type` on the Python side; the
    # server applier renames back when calling SuperDoc.
    "track_changes.list": {"type": "change_type", "in": "in_"},
    # Athena-extension ops that accept an `in:` story-scope param. The
    # path-proxy snake-case transform leaves `in` as a Python keyword
    # collision; rename to `in_` here so the dataclass accepts it.
    "find_replace": {"in": "in_"},
    "iter_runs": {"in": "in_"},
    "numbering.list": {"in": "in_"},
}


def _build_command(op: str, params: dict[str, Any]) -> Command:
    """Construct a typed Command from the legacy op-name + params-dict shape."""
    cls = _OP_TO_COMMAND.get(op)
    if cls is None:
        raise DocxError(
            f"Unknown docx-studio op: {op!r}. "
            f"Add a Command subclass + lookup entry in docx/_http_doc.py.",
        )

    # Convert param keys camelCase → snake_case to match dataclass fields.
    snake_params: dict[str, Any] = {
        _camel_to_snake(k): v for k, v in params.items()
    }

    # Apply per-op renames (e.g. find: type → node_type).
    renames = _FIELD_RENAMES.get(op)
    if renames:
        for src, dst in renames.items():
            if src in snake_params:
                snake_params[dst] = snake_params.pop(src)

    try:
        return cls(**snake_params)
    except TypeError as e:
        raise DocxError(
            f"Invalid params for op {op!r}: {e}. params={params!r}",
        ) from e


class _PathProxy:
    """Lazy attribute walker.

    ``doc.create.paragraph(p)`` accumulates the path ``"create.paragraph"``;
    the terminal ``__call__`` translates ``(op, p)`` into a typed
    :class:`Command` and ships it through the buffer.
    """

    __slots__ = ("_buffer", "_path")

    def __init__(self, buffer: CommandBuffer, path: str) -> None:
        self._buffer: CommandBuffer = buffer
        self._path: str = path

    def __getattr__(self, name: str) -> "_PathProxy":
        if name.startswith("__"):
            raise AttributeError(name)
        new_path: str = f"{self._path}.{name}" if self._path else name
        return _PathProxy(self._buffer, new_path)

    async def __call__(self, params: dict | None = None) -> Any:
        # The existing SDK is async-style (calls go through run_sync);
        # __call__ is async to match. The work inside is synchronous —
        # _http_post_json blocks — but it runs on a persistent event-loop
        # thread, so the calling thread is fine.
        cmd = _build_command(self._path, params or {})
        result = self._buffer.call(cmd)
        # Buffered (non-eager) calls return None; existing call sites
        # typically don't read the result of pure mutations, but a few do
        # check `if result:` defensively. Return an empty dict to keep
        # them happy.
        return result if result is not None else {}


class HttpDocHandle:
    """Drop-in replacement for ``superdoc.AsyncSuperDocClient.open()``'s
    return value. Existing SDK call sites use ``self._session.doc.<X>(p)``
    where ``X`` is a dotted path on the bound doc API; this object
    forwards every such access to the HTTP transport via _PathProxy +
    CommandBuffer.
    """

    __slots__ = ("_buffer", "_asset_id", "_client")

    def __init__(self, client: HttpClient, asset_id: str) -> None:
        self._asset_id: str = asset_id
        self._client: HttpClient = client
        self._buffer: CommandBuffer = CommandBuffer(client, asset_id)

    @property
    def buffer(self) -> CommandBuffer:
        return self._buffer

    @property
    def client(self) -> HttpClient:
        return self._client

    def __getattr__(self, name: str) -> _PathProxy:
        if name.startswith("__"):
            raise AttributeError(name)
        return _PathProxy(self._buffer, name)
