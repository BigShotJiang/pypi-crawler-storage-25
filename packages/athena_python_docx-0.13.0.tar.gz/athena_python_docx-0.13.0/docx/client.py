"""Session lifecycle for the docx-studio HTTP transport.

A :class:`Session` owns the per-asset :class:`HttpClient` + :class:`HttpDocHandle`
(which wraps a :class:`CommandBuffer`) for one Document. Lifecycle:

    create → first op triggers open() → ops route through buffer → save() drains → close() disposes

There is no Keryx WebSocket from Python anymore — every primitive is an HTTP
round-trip to docx-studio's API, which owns the Y.Doc connection server-side.
The legacy ``transport="direct"`` path was removed in 0.5.0; a Python pod no
longer embeds Superdoc.

Thread safety: a Session is not thread-safe. Each Document gets its own.
The sync façade serializes every call through the persistent event-loop
thread in ``_batching.py``, so the path proxy's async ``__call__`` is run
on a dedicated thread and the calling thread blocks.
"""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from docx.errors import (
    AuthenticationError,
    DocumentClosedError,
    SessionError,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator


def _log_info(msg: str) -> None:
    """Minimal stderr logger; we avoid loguru to keep the SDK runtime
    dependency tree small (this code runs inside Daytona sandboxes)."""
    import sys

    print(f"[docx-sdk] {msg}", file=sys.stderr)


def _log_warning(msg: str) -> None:
    import sys

    print(f"[docx-sdk] WARN: {msg}", file=sys.stderr)


class Session:
    """Owns the HTTP transport for one Document.

    The buffer + HTTP client are constructed in :meth:`open`. Calling
    :meth:`save` drains pending mutations; :meth:`close` does the same and
    then disables further calls.
    """

    def __init__(
        self,
        *,
        asset_id: str,
        user_info: dict[str, str] | None = None,
        bundle: dict[str, str] | None = None,  # accepted for back-compat; ignored
        http_base_url: str | None = None,
        http_api_key: str | None = None,
    ) -> None:
        self._asset_id: str = asset_id
        self._user_info: dict[str, str] = user_info or {
            "name": "Athena Agent",
            "email": "agent@athenaintel.com",
        }
        # ``bundle`` previously carried a pre-minted Keryx JWT for the
        # legacy direct transport. We swallow it for back-compat with
        # callers (Document.create) that still pass it; the HTTP path
        # doesn't use it because the API service mints its own JWT
        # server-side from KERYX_AUTH_PRIVATE_KEY.
        del bundle  # explicitly unused
        self._http_base_url: str | None = http_base_url
        self._http_api_key: str | None = http_api_key
        self._client: Any | None = None
        self._doc_handle: Any | None = None
        self._opened: bool = False
        self._closed: bool = False
        # Collector for post-export OOXML rewrites (cell-inner format
        # ops + REF-field restorations + future Tier-B fidelity fixes).
        # Lives here so every proxy that reaches the session can stash;
        # ``Document.export_docx`` drains it against the bytes returned
        # by docx-studio's ``ExportDocx`` command.
        from docx._postproc import PostExportOps

        self._post_export_ops: PostExportOps = PostExportOps()

    @property
    def asset_id(self) -> str:
        return self._asset_id

    @property
    def is_open(self) -> bool:
        return self._opened and not self._closed

    async def open(self) -> None:
        """Construct the HTTP client + buffered doc handle.

        No network call here — the first command-level call (which the
        SDK fires lazily from getter properties or mutation methods) hits
        docx-studio, which performs the ownership check and acquires the
        Superdoc session server-side.

        Raises:
            AuthenticationError: missing or invalid api_key.
            SessionError: missing base_url or downstream open failure.
        """
        if self._closed:
            raise DocumentClosedError(
                f"Session for asset {self._asset_id} was already closed.",
            )
        if self._opened:
            return

        from docx._http_doc import HttpClient, HttpDocHandle

        base_url: str | None = self._http_base_url or os.environ.get(
            "ATHENA_DOCX_BASE_URL",
        )
        api_key: str | None = self._http_api_key or os.environ.get(
            "ATHENA_DOCX_API_KEY",
        )
        if not base_url:
            raise SessionError(
                "Missing base_url. Pass base_url= to Document(...) or set "
                "ATHENA_DOCX_BASE_URL.",
            )
        if not api_key:
            raise AuthenticationError(
                "Missing api_key. Pass api_key= to Document(...) or set "
                "ATHENA_DOCX_API_KEY.",
            )
        client = HttpClient(base_url=base_url, api_key=api_key)
        self._client = client
        self._doc_handle = HttpDocHandle(client, self._asset_id)
        self._opened = True
        _log_info(f"Opened {self._asset_id}")

    @property
    def doc(self) -> Any:
        """Return the opened doc handle (the path-proxy entry point)."""
        if not self._opened:
            raise SessionError(
                "Session not yet opened; call await session.open() first "
                "or use the sync facade via Document().",
            )
        if self._closed:
            raise DocumentClosedError(
                f"Session for asset {self._asset_id} is closed.",
            )
        return self._doc_handle

    async def send_command(self, cmd: Any) -> Any:
        """Route a pre-built :class:`docx.commands.Command` through the
        buffer.

        Bypasses the ``_OP_TO_COMMAND`` path-proxy translation layer so
        Athena-extension commands (Hyperlink/Field/Bookmark/Footnote/
        Caption/Cross-reference/TOC/Chart/Math/SDT/Watermark/etc.) can
        be issued directly from call sites without having to round-trip
        through camelCase params dicts. Mutating commands buffer;
        response-bearing commands (queries + the ``Create*`` family)
        flush eagerly and return the per-command result dict.

        Async to match the existing ``self._session.doc.<op>(params)``
        call shape that the rest of the SDK uses; in practice every
        SDK call site wraps this in :func:`docx._batching.run_sync`.
        """
        if not self._opened:
            raise SessionError(
                "Session not yet opened; call await session.open() first "
                "or use the sync facade via Document().",
            )
        if self._closed:
            raise DocumentClosedError(
                f"Session for asset {self._asset_id} is closed.",
            )
        handle = self._doc_handle
        buffer = getattr(handle, "buffer", None) if handle is not None else None
        if buffer is None:
            raise SessionError(
                f"Session {self._asset_id} has no buffer (open never completed?)",
            )
        result = buffer.call(cmd)
        return result if result is not None else {}

    async def save(self, *, in_place: bool = True) -> None:  # noqa: ARG002
        """Drain pending buffered mutations.

        ``in_place`` is accepted for back-compat with the legacy direct
        transport; writes are always against the asset's Y.Doc.
        """
        if not self._opened:
            raise SessionError("Cannot save a session that was never opened.")
        if self._closed:
            raise DocumentClosedError(f"Session {self._asset_id} is closed.")

        handle = self._doc_handle
        buffer = getattr(handle, "buffer", None) if handle is not None else None
        if buffer is not None:
            buffer.flush()
        _log_info(f"Saved {self._asset_id} (buffer drained)")

    async def close(self) -> None:
        """Close the session. Idempotent."""
        if self._closed:
            return

        handle = self._doc_handle
        buffer = getattr(handle, "buffer", None) if handle is not None else None
        if buffer is not None:
            try:
                buffer.close()
            except Exception as e:  # noqa: BLE001
                _log_warning(
                    f"Buffer close failed for {self._asset_id}: {e}",
                )

        # Release the HttpClient's pooled connections too — without this,
        # long-lived workers leak sockets each time a Document is closed.
        client = getattr(handle, "client", None) if handle is not None else None
        if client is not None:
            try:
                client.close()
            except Exception as e:  # noqa: BLE001
                _log_warning(
                    f"HttpClient close failed for {self._asset_id}: {e}",
                )

        self._closed = True
        _log_info(f"Closed {self._asset_id}")


@asynccontextmanager
async def open_session(
    *,
    asset_id: str,
    user_info: dict[str, str] | None = None,
) -> "AsyncIterator[Session]":
    """Async context manager for a Session. Yields an opened session."""
    session = Session(asset_id=asset_id, user_info=user_info)
    try:
        await session.open()
        yield session
    finally:
        await session.close()
