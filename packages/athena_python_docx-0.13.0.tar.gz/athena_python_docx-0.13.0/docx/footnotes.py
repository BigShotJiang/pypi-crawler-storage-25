"""Footnotes & Endnotes — Athena extension beyond python-docx 1.x.

python-docx upstream has no footnote/endnote API. Issue #1 (the first
issue ever filed, open since 2014) demands footnotes; it drove the
`bayoo-docx` fork. SuperDoc models footnotes as a separate story with
reference marks in the body. Endnotes mirror the same machinery but
render end-of-section.

See ``python-sdk/CLAUDE.md`` § *Intentional deviations (additions /
different semantics)*.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._athena_extension import athena_extension
from docx._batching import run_sync

# Module-level marker — entire module is an Athena extension.
__athena_extension_module__: bool = True
__athena_extension_issue__: str = "python-docx#1"
__athena_extension_description__: str = (
    "Footnotes & Endnotes — closes the first issue ever filed against "
    "python-docx (open since 2014)."
)
__athena_extension_since__: str = "0.11.0"

if TYPE_CHECKING:
    from docx.client import Session


class _NoteBase:
    """Shared surface for :class:`Footnote` / :class:`Endnote`. Both
    expose the same reference-mark + body API."""

    _LIST_CMD: str = ""
    _GET_CMD: str = ""
    _PATCH_CMD: str = ""
    _DELETE_CMD: str = ""

    def __init__(
        self,
        *,
        session: "Session",
        note_id: str,
        text: str | None = None,
        custom_mark: str | None = None,
    ) -> None:
        self._session: "Session" = session
        self._note_id: str = note_id
        self._text: str | None = text
        self._custom_mark: str | None = custom_mark

    @property
    def note_id(self) -> str:
        return self._note_id

    @property
    def custom_mark(self) -> str | None:
        return self._custom_mark

    @property
    def text(self) -> str:
        if self._text is not None:
            return self._text
        from docx import commands as _commands

        cmd_cls = getattr(_commands, self._GET_CMD, None)
        if cmd_cls is None:
            return ""
        info = run_sync(self._session.send_command(cmd_cls(id=self._note_id)))
        if isinstance(info, dict):
            v = info.get("text")
            if isinstance(v, str):
                self._text = v
                return v
        return ""

    @text.setter
    def text(self, value: str) -> None:
        from docx import commands as _commands

        cmd_cls = getattr(_commands, self._PATCH_CMD, None)
        if cmd_cls is None:
            return
        run_sync(
            self._session.send_command(cmd_cls(id=self._note_id, text=value)),
        )
        self._text = value

    def delete(self) -> None:
        from docx import commands as _commands

        cmd_cls = getattr(_commands, self._DELETE_CMD, None)
        if cmd_cls is None:
            return
        run_sync(self._session.send_command(cmd_cls(id=self._note_id)))


@athena_extension(issue=1, description="One footnote (reference + body).")
class Footnote(_NoteBase):
    """One footnote — reference mark in the body + paragraph(s) in the
    footnote story."""

    _LIST_CMD = "FootnotesList"
    _GET_CMD = "FootnotesGet"
    _PATCH_CMD = "FootnotesPatch"
    _DELETE_CMD = "FootnotesDelete"

    def __init__(
        self,
        *,
        session: "Session",
        footnote_id: str,
        text: str | None = None,
        custom_mark: str | None = None,
    ) -> None:
        super().__init__(
            session=session,
            note_id=footnote_id,
            text=text,
            custom_mark=custom_mark,
        )

    @property
    def footnote_id(self) -> str:
        return self._note_id


@athena_extension(issue=1, description="One endnote (reference + body).")
class Endnote(_NoteBase):
    """One endnote — reference mark in the body + paragraph(s) in the
    endnote story."""

    _LIST_CMD = "EndnotesList"
    _GET_CMD = "EndnotesGet"
    _PATCH_CMD = "EndnotesPatch"
    _DELETE_CMD = "EndnotesDelete"

    def __init__(
        self,
        *,
        session: "Session",
        endnote_id: str,
        text: str | None = None,
        custom_mark: str | None = None,
    ) -> None:
        super().__init__(
            session=session,
            note_id=endnote_id,
            text=text,
            custom_mark=custom_mark,
        )

    @property
    def endnote_id(self) -> str:
        return self._note_id


class _NotesCollection:
    """Shared sequence-like collection for footnotes/endnotes."""

    _LIST_CMD: str = ""
    _GET_CMD: str = ""
    _WRAP_CLS: type = _NoteBase

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self) -> list[dict]:
        from docx import commands as _commands

        cmd_cls = getattr(_commands, self._LIST_CMD, None)
        if cmd_cls is None:
            return []
        result = run_sync(self._session.send_command(cmd_cls()))
        if isinstance(result, dict):
            items = (
                result.get("items")
                or result.get("footnotes")
                or result.get("endnotes")
                or []
            )
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        elif isinstance(result, list):
            return [i for i in result if isinstance(i, dict)]
        return []

    def __iter__(self):
        for info in self._items():
            yield self._wrap(info)

    def __len__(self) -> int:
        return len(self._items())

    def __getitem__(self, index: int):
        return self._wrap(self._items()[index])

    def get(self, note_id: str):
        for info in self._items():
            if (
                info.get("id") == note_id
                or info.get("footnoteId") == note_id
                or info.get("endnoteId") == note_id
            ):
                return self._wrap(info)
        return None

    def _wrap(self, info: dict):
        return self._WRAP_CLS(
            session=self._session,
            **{
                self._note_id_kwarg(): str(
                    info.get("id")
                    or info.get("footnoteId")
                    or info.get("endnoteId")
                    or "",
                ),
            },
            text=info.get("text") if isinstance(info.get("text"), str) else None,
            custom_mark=info.get("customMark") if isinstance(info.get("customMark"), str) else None,
        )

    def _note_id_kwarg(self) -> str:
        return "footnote_id" if self._WRAP_CLS is Footnote else "endnote_id"


@athena_extension(issue=1, description="Collection of footnotes.")
class Footnotes(_NotesCollection):
    """Collection of footnotes in the document."""

    _LIST_CMD = "FootnotesList"
    _GET_CMD = "FootnotesGet"
    _WRAP_CLS = Footnote


@athena_extension(issue=1, description="Collection of endnotes.")
class Endnotes(_NotesCollection):
    """Collection of endnotes in the document."""

    _LIST_CMD = "EndnotesList"
    _GET_CMD = "EndnotesGet"
    _WRAP_CLS = Endnote


__all__ = ["Footnote", "Endnote", "Footnotes", "Endnotes"]
