"""Word fields (Athena extension beyond python-docx 1.x).

python-docx upstream has no field-add or field-read API — issue #498
(page numbers in headers/footers) and #31 (generic ``add_field``) have
been open for years. Word fields are the OOXML construct behind
``PAGE``, ``NUMPAGES``, ``DATE``, ``TIME``, ``AUTHOR``, ``REF``
(cross-references), ``SEQ`` (auto-numbered captions), ``TOC``, and ~100
other instructions.

This module exposes:

* :class:`Field` — read-only proxy for one field in the document.
* :class:`Fields` — sequence-like collection accessed via
  :attr:`docx.document.Document.fields`.

Inserting fields is done through the Run-level :meth:`docx.text.run.
Run.add_field` shortcut or the lower-level :class:`docx.commands.
CreateField` typed command.

See ``python-sdk/CLAUDE.md`` § *Intentional deviations (additions /
different semantics)*.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Iterator

from docx._athena_extension import athena_extension
from docx._batching import run_sync

# Module-level marker — entire module is an Athena extension.
__athena_extension_module__: bool = True
__athena_extension_issue__: str = "python-docx#498"
__athena_extension_description__: str = (
    "Word fields — PAGE, NUMPAGES, DATE, REF, SEQ, TOC, etc."
)
__athena_extension_since__: str = "0.11.0"

if TYPE_CHECKING:
    from docx.client import Session


@athena_extension(issue=498, description="One Word field.")
class Field:
    """One Word field. Read-only proxy.

    The ``kind`` attribute names the high-level field type (``"PAGE"``,
    ``"NUMPAGES"``, ``"DATE"``, ``"REF"``, ``"SEQ"``, ``"TOC"``, …).
    The full Word field instruction is in :attr:`instr`. :attr:`result`
    is the cached display result Word wrote on its last refresh — call
    :meth:`Field.refresh` to recompute.
    """

    def __init__(
        self,
        *,
        session: "Session",
        field_id: str,
        kind: str,
        instr: str | None = None,
        result: str | None = None,
        cached: dict | None = None,
    ) -> None:
        self._session: "Session" = session
        self._field_id: str = field_id
        self._kind: str = kind
        self._instr: str | None = instr
        self._result: str | None = result
        self._cached: dict = cached or {}

    @property
    def field_id(self) -> str:
        return self._field_id

    @property
    def kind(self) -> str:
        return self._kind

    @property
    def instr(self) -> str | None:
        return self._instr

    @property
    def result(self) -> str | None:
        return self._result

    def refresh(self) -> None:
        """Recompute this field's cached display result."""
        from docx.commands import FieldsRefresh

        run_sync(
            self._session.send_command(FieldsRefresh(scope=None)),
        )


@athena_extension(issue=498, description="Collection of fields.")
class Fields:
    """Collection of fields in the document. Athena extension."""

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self) -> list[dict]:
        from docx.commands import FieldsList

        result = run_sync(self._session.send_command(FieldsList()))
        if isinstance(result, dict):
            items = result.get("items") or result.get("fields") or []
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        elif isinstance(result, list):
            return [i for i in result if isinstance(i, dict)]
        return []

    def __iter__(self) -> Iterator[Field]:
        for info in self._items():
            yield self._wrap(info)

    def __len__(self) -> int:
        return len(self._items())

    def __getitem__(self, index: int) -> Field:
        items = self._items()
        return self._wrap(items[index])

    def get(self, field_id: str) -> Field | None:
        """Find a field by id, or ``None`` if it's been deleted."""
        for info in self._items():
            if info.get("id") == field_id or info.get("fieldId") == field_id:
                return self._wrap(info)
        return None

    def refresh_all(self, *, scope: str | None = None) -> None:
        """Force-refresh every field result. ``scope`` narrows to a
        family (``"toc"``, ``"ref"``, ``"seq"``, ``"page"``)."""
        from docx.commands import FieldsRefresh

        run_sync(self._session.send_command(FieldsRefresh(scope=scope)))

    def _wrap(self, info: dict) -> Field:
        return Field(
            session=self._session,
            field_id=str(info.get("id") or info.get("fieldId") or ""),
            kind=str(info.get("kind") or info.get("fieldKind") or "FIELD"),
            instr=info.get("instr") if isinstance(info.get("instr"), str) else None,
            result=info.get("result") if isinstance(info.get("result"), str) else None,
            cached=info,
        )


__all__ = ["Field", "Fields"]
