"""Table of Contents (TOC) — Athena extension beyond python-docx 1.x.

python-docx upstream has no TOC API. Issue #36 (closed-without-action),
#1207, and #1403 (auto-refresh) demand both creation and refresh.
Word's TOC is a field whose cached result is rebuilt on open or on
explicit refresh; the SDK exposes:

* :meth:`docx.document.Document.add_toc` — insert a TOC at a position.
* :class:`TableOfContents` — proxy returned by ``add_toc`` for
  refresh-on-demand.

See ``python-sdk/CLAUDE.md`` § *Intentional deviations (additions /
different semantics)*.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._athena_extension import athena_extension
from docx._batching import run_sync

__athena_extension_module__: bool = True
__athena_extension_issue__: str = "python-docx#36"
__athena_extension_description__: str = "Table of Contents (TOC field)."
__athena_extension_since__: str = "0.11.0"

if TYPE_CHECKING:
    from docx.client import Session


@athena_extension(issue=36, description="TOC field proxy.")
class TableOfContents:
    """Proxy for a TOC field in the document."""

    def __init__(
        self,
        *,
        session: "Session",
        toc_id: str,
        levels: tuple[int, int] = (1, 3),
        style_id: str | None = None,
        include_hyperlinks: bool = True,
    ) -> None:
        self._session: "Session" = session
        self._toc_id: str = toc_id
        self._levels: tuple[int, int] = levels
        self._style_id: str | None = style_id
        self._include_hyperlinks: bool = include_hyperlinks

    @property
    def toc_id(self) -> str:
        return self._toc_id

    @property
    def levels(self) -> tuple[int, int]:
        return self._levels

    @property
    def style_id(self) -> str | None:
        return self._style_id

    @property
    def include_hyperlinks(self) -> bool:
        return self._include_hyperlinks

    def refresh(self) -> None:
        """Recompute the TOC's cached result.

        Equivalent to opening the document in Word and clicking
        Refresh on the TOC. Word also refreshes on open when the
        document's settings carry ``<w:updateFields w:val="true"/>``.
        """
        from docx.commands import RefreshTOC

        run_sync(self._session.send_command(RefreshTOC(id=self._toc_id)))


__all__ = ["TableOfContents"]
