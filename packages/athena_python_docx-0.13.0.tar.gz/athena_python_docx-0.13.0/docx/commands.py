"""Typed command dataclasses for the docx-studio HTTP wire format.

Mirrors `apps/api/src/commands/types.ts`. Every command serializes to a flat
JSON object with a `type` discriminator (PascalCase, matching the class name)
and the rest of its fields converted from snake_case to camelCase.

Design notes:
- These are internal — they aren't part of the python-docx parity surface
  and aren't re-exported from `docx.__init__`. Call sites construct them
  directly and hand them to the session, which serializes + ships them.
- Anchor / target / inline-format leaves are typed as `dict[str, Any]` on
  purpose. SuperDoc owns those vocabularies; we transit them.
- `None`-valued fields are dropped on the wire so the server can apply
  schema defaults (e.g. `count=1` for InsertRow).
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import Any


def _snake_to_camel(s: str) -> str:
    """snake_case → camelCase. Trailing underscore is treated as no-op
    so Python keyword-collision suffixes (``in_`` → ``in``) round-trip
    cleanly on the wire."""
    parts = s.rstrip("_").split("_")
    return parts[0] + "".join(p[:1].upper() + p[1:] for p in parts[1:])


@dataclass
class Command:
    """Base class for all wire commands.

    Subclasses are dataclasses; their class name is used verbatim as the
    `type` discriminator. `to_dict()` walks the dataclass fields, converts
    names to camelCase, and drops `None` values.
    """

    @property
    def type(self) -> str:
        return self.__class__.__name__

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"type": self.type}
        for f in dataclasses.fields(self):
            value = getattr(self, f.name)
            if value is None:
                continue
            out[_snake_to_camel(f.name)] = value
        return out


# ---------------------------------------------------------------------------
# Block-creation commands
# ---------------------------------------------------------------------------


# --- Create* commands carry an optional client-assigned node id ---
#
# The SDK pre-generates a UUID for every new Paragraph/Heading/Table/
# Image and stamps the proxy with it. The applier translates
# ``client_node_id`` → real SuperDoc nodeId in a per-batch map (see
# ``apps/api/src/commands/applier.ts``), so subsequent commands in the
# same batch can target the new block by its client-side id before the
# response has even returned. After flush, the buffer reads the
# resolved ``real_node_id`` out of each Create's response and updates
# the proxy in-place.
#
# Direct internal callers that bypass ``Document`` (legacy helpers,
# fidelity tests) may leave the field unset; the buffer then eager-
# flushes the Create immediately so callers that read the response
# still see real data.
#
# The field is ``client_node_id`` on the Python side and arrives at
# the server as ``clientNodeId`` via ``_snake_to_camel`` — matches the
# Zod schema's ``clientNodeId`` field.


@dataclass
class CreateParagraph(Command):
    text: str
    at: dict[str, Any]
    # Optional `in` story locator for targeting header/footer slots.
    # Renamed ``in_`` on the Python side to avoid the keyword collision;
    # ``_snake_to_camel`` strips the trailing underscore so ``in_``
    # serialises as ``in`` on the wire (see top-of-module helper).
    in_: dict[str, Any] | None = None
    client_node_id: str | None = None


@dataclass
class CreateHeading(Command):
    text: str
    level: int
    at: dict[str, Any]
    # See CreateParagraph.in_ comment above.
    in_: dict[str, Any] | None = None
    client_node_id: str | None = None


@dataclass
class CreateTable(Command):
    rows: int
    columns: int
    at: dict[str, Any]
    in_: dict[str, Any] | None = None
    client_node_id: str | None = None


@dataclass
class CreateImage(Command):
    src: str
    size: dict[str, Any]
    at: dict[str, Any]
    client_node_id: str | None = None


@dataclass
class CreateSectionBreak(Command):
    break_type: str
    at: dict[str, Any]


# ---------------------------------------------------------------------------
# Inline mutations
# ---------------------------------------------------------------------------


@dataclass
class Insert(Command):
    target: dict[str, Any]
    value: str | None = None
    # `value_type` becomes `valueType` on the wire and is mapped to `type`
    # on the SuperDoc call (renamed in transit so it doesn't collide with our
    # discriminator).
    value_type: str | None = None
    placement: str | None = None
    content: dict[str, Any] | None = None


@dataclass
class TableSetCell(Command):
    """Address a single table cell by ``(table_node_id, row, col)`` and insert
    ``content`` into it. The applier resolves the cell's real nodeId
    server-side (via one batch-wide ``tables.getCells`` call cached per
    table), so the SDK doesn't need a prior ``tables.get_cells`` query —
    each ``_Cell.text = …`` skips 1 HTTP round-trip and the whole table
    flushes in one batch.

    Buffered, not response-bearing. Placement defaults to ``insideEnd``
    on the apps/api side (matches the prior ``_Cell.text`` setter
    semantics: APPEND into the cell's existing paragraph, which produces
    ``cell.text == value`` for a freshly created empty cell).

    ``table_node_id`` may be a client-side UUID — the applier resolves
    it through the per-batch ``clientIdMap`` set by the preceding
    ``CreateTable``, so a freshly created table can be populated in the
    same flush.
    """

    table_node_id: str
    row_index: int
    column_index: int
    content: dict[str, Any]
    placement: str | None = None


@dataclass
class Replace(Command):
    target: dict[str, Any]
    text: str


@dataclass
class InsertLineBreak(Command):
    block_id: str
    offset: int


@dataclass
class InsertTab(Command):
    block_id: str
    offset: int


@dataclass
class FormatApply(Command):
    target: dict[str, Any]
    inline: dict[str, Any]


@dataclass
class SetParagraphAlignment(Command):
    target: dict[str, Any]
    alignment: str  # "left" | "center" | "right" | "justify" | "start" | "end"


@dataclass
class ClearParagraphAlignment(Command):
    target: dict[str, Any]


@dataclass
class SetParagraphStyle(Command):
    target: dict[str, Any]
    style_id: str


@dataclass
class SetParagraphIndentation(Command):
    target: dict[str, Any]
    left: float | None = None
    right: float | None = None
    first_line: float | None = None
    hanging: float | None = None


@dataclass
class ClearParagraphIndentation(Command):
    target: dict[str, Any]


@dataclass
class SetParagraphSpacing(Command):
    target: dict[str, Any]
    before: float | None = None
    after: float | None = None
    line: float | None = None
    line_rule: str | None = None


@dataclass
class ClearParagraphSpacing(Command):
    target: dict[str, Any]


@dataclass
class SetParagraphKeepOptions(Command):
    target: dict[str, Any]
    keep_next: bool | None = None
    keep_lines: bool | None = None
    widow_control: bool | None = None


@dataclass
class SetParagraphFlowOptions(Command):
    target: dict[str, Any]
    page_break_before: bool | None = None


@dataclass
class SetParagraphTabStop(Command):
    target: dict[str, Any]
    position: float
    alignment: str | None = None
    leader: str | None = None


@dataclass
class ClearParagraphTabStops(Command):
    target: dict[str, Any]


# ---------------------------------------------------------------------------
# Sections
# ---------------------------------------------------------------------------


@dataclass
class SetSectionPageMargins(Command):
    target: dict[str, Any]
    left: float | None = None
    right: float | None = None
    top: float | None = None
    bottom: float | None = None
    gutter: float | None = None


@dataclass
class SetSectionPageSetup(Command):
    target: dict[str, Any]
    width: float | None = None
    height: float | None = None
    orientation: str | None = None  # "portrait" | "landscape"


@dataclass
class SetSectionHeaderFooterMargins(Command):
    target: dict[str, Any]
    header: float | None = None
    footer: float | None = None


@dataclass
class SetSectionBreakType(Command):
    target: dict[str, Any]
    break_type: str


@dataclass
class SetSectionTitlePage(Command):
    """Toggle the ``different first page header/footer`` flag.

    SuperDoc's ``DocSectionsSetTitlePageParams`` requires ``enabled``,
    not ``titlePage``. The earlier dataclass field name made every
    call silently land no-op'd at SuperDoc.
    """

    target: dict[str, Any]
    enabled: bool


@dataclass
class SetSectionsOddEvenHeadersFooters(Command):
    """Toggle the document-level ``<w:evenAndOddHeaders/>`` setting.

    Despite living under the ``sections.*`` namespace on the SuperDoc
    bound-doc API, this op carries no ``target`` — it sets a single
    doc-level flag that applies to every section. Word stores the
    underlying value on ``word/settings.xml`` as
    ``<w:evenAndOddHeaders/>``, which is what python-docx's
    ``Settings.odd_and_even_pages_header_footer`` writes to.

    Available since SuperDoc 1.8.1 (``DocSectionsSetOddEvenHeadersFooters``).
    """

    enabled: bool


@dataclass
class SetSectionLinkToPrevious(Command):
    """Toggle the section-side ``linked-to-previous`` flag for one
    header/footer slot.

    SuperDoc's ``DocSectionsSetLinkToPreviousParams`` requires
    ``target`` (a ``{kind: section, sectionId}``), ``kind`` (``"header"
    | "footer"``), ``variant`` (``"default" | "first" | "even"``), and
    ``linked`` (the boolean). The previous version of this dataclass
    used ``linked_to_previous`` (which serialised as
    ``linkedToPrevious``) and didn't carry ``variant`` at all — so
    every call was silently malformed against SuperDoc's wire schema.
    """

    target: dict[str, Any]
    kind: str  # "header" | "footer"
    variant: str  # "default" | "first" | "even"
    linked: bool


# ---------------------------------------------------------------------------
# Tables (mutations)
# ---------------------------------------------------------------------------


@dataclass
class TablesInsertRow(Command):
    node_id: str
    row_index: int
    position: str  # "above" | "below"
    count: int = 1


@dataclass
class TablesInsertColumn(Command):
    node_id: str
    column_index: int
    position: str  # "left" | "right"
    count: int = 1


@dataclass
class TablesMergeCells(Command):
    node_id: str
    start: dict[str, Any]  # {rowIndex, columnIndex}
    end: dict[str, Any]


@dataclass
class TablesSetStyle(Command):
    node_id: str
    style_id: str


@dataclass
class TablesSetLayout(Command):
    """Table-level layout properties.

    Mirrors SuperDoc's ``DocTablesSetLayoutParams``. ``alignment``
    (left|center|right) and ``table_direction`` (ltr|rtl) live here,
    NOT on ``TablesSetTableOptions`` — the previous split was wrong
    and silently dropped both fields at SuperDoc.

    ``auto_fit_mode`` was previously named ``auto_fit``; SuperDoc's
    wire field is ``autoFitMode``, so calls were silently rejected
    until now.
    """

    node_id: str
    auto_fit_mode: str | None = None  # "fitContents" | "fixedWidth"
    alignment: str | None = None  # "left" | "center" | "right"
    table_direction: str | None = None  # "ltr" | "rtl"
    preferred_width: float | None = None
    left_indent_pt: float | None = None


@dataclass
class TablesSetTableOptions(Command):
    """Table-wide *cell-spacing* and default cell-margin overrides.

    Mirrors SuperDoc's ``DocTablesSetTableOptionsParams`` — alignment
    and direction were moved to :class:`TablesSetLayout` to match
    SuperDoc's actual surface.
    """

    node_id: str
    default_cell_margins: dict[str, Any] | None = None
    cell_spacing_pt: float | None = None


@dataclass
class TablesSetCellProperties(Command):
    target: dict[str, Any]
    vertical_align: str | None = None
    preferred_width_pt: float | None = None


@dataclass
class TablesSetColumnWidth(Command):
    node_id: str
    column_index: int
    width_pt: float


@dataclass
class TablesSetRowHeight(Command):
    node_id: str
    row_index: int
    height_pt: float
    rule: str | None = None  # "auto" | "exact" | "atLeast"


# ---------------------------------------------------------------------------
# Images (mutations)
# ---------------------------------------------------------------------------


@dataclass
class SetImageSize(Command):
    """Resize an inline image.

    Mirrors SuperDoc's ``DocImagesSetSizeParams``. Earlier shape
    (``nodeId, widthPt, heightPt``) was silently rejected — the wire
    schema needs ``imageId`` and a nested ``size: {width, height,
    unit?}`` object. ``unit`` defaults to ``"pt"`` to match athena's
    convention; pass ``"px"`` or ``"twip"`` to override.
    """

    image_id: str
    size: dict[str, Any]


@dataclass
class SetImageAltText(Command):
    """Set alt-text on an inline image. Mirrors SuperDoc's
    ``doc.images.setAltText``. Used by accessibility flows that need
    a text alternative for screen readers."""

    image_id: str
    alt_text: str


@dataclass
class SetImageDecorative(Command):
    """Mark an image as purely decorative so it's skipped by screen
    readers. Mirrors SuperDoc's ``doc.images.setDecorative``."""

    image_id: str
    decorative: bool


@dataclass
class ImagesGet(Command):
    """Read an image's binary / metadata payload by its node id.
    Mirrors SuperDoc's ``doc.images.get``. Backs
    :class:`docx.shape.Picture` accessors."""

    image_id: str


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------


@dataclass
class BlocksList(Command):
    node_types: list[str] | None = None
    include_text: bool | None = None


@dataclass
class Find(Command):
    # `node_type` on the wire is `nodeType`; mapped to `type` on the
    # SuperDoc call by the server (renamed in transit to avoid colliding
    # with our discriminator).
    node_type: str


@dataclass
class GetNodeById(Command):
    id: str
    node_type: str | None = None


@dataclass
class GetNode(Command):
    target: dict[str, Any]


@dataclass
class ImagesList(Command):
    pass


@dataclass
class Info(Command):
    pass


@dataclass
class SectionsList(Command):
    pass


@dataclass
class SectionsGet(Command):
    target: dict[str, Any]


@dataclass
class TablesGet(Command):
    node_id: str


@dataclass
class TablesGetCells(Command):
    node_id: str
    row_index: int
    column_index: int


@dataclass
class TablesGetProperties(Command):
    node_id: str


@dataclass
class MarkdownToFragment(Command):
    markdown: str


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


@dataclass
class CommentsCreate(Command):
    """Create a new comment, optionally anchored to a text range.

    Mirrors SuperDoc's ``doc.comments.create`` — ``target`` is the
    optional ``{kind: "text", blockId, range}`` anchor, ``text`` is the
    comment body. ``parentId`` threads a reply onto an existing comment.
    """

    text: str | None = None
    target: dict[str, Any] | None = None
    parent_id: str | None = None
    # Optional client-assigned entity id for transparent-batched
    # CommentsCreate (parallel to ``client_node_id`` on Create*; the
    # server applier resolves UUIDs via the same per-batch
    # ``clientIdMap``). ``Comments.add_comment`` currently leaves this
    # unset, so CommentsCreate eager-flushes — left in place for
    # future callers that want to defer comment creates alongside
    # other ops.
    client_entity_id: str | None = None


@dataclass
class CommentsPatch(Command):
    """Update an existing comment's text and/or anchor target."""

    id: str = ""
    text: str | None = None
    target: dict[str, Any] | None = None


@dataclass
class CommentsDelete(Command):
    id: str = ""


@dataclass
class CommentsGet(Command):
    id: str = ""


@dataclass
class CommentsList(Command):
    include_resolved: bool | None = None
    limit: int | None = None
    offset: int | None = None


# ---------------------------------------------------------------------------
# Headers & Footers
# ---------------------------------------------------------------------------


@dataclass
class HeaderFootersList(Command):
    """List header/footer parts in the document, optionally scoped to
    a section or filtered by header/footer kind."""

    kind: str | None = None  # "header" | "footer"
    section: dict[str, Any] | None = None
    limit: int | None = None
    offset: int | None = None


@dataclass
class HeaderFootersGet(Command):
    """Get a specific header/footer slot by section + kind + variant.

    ``target = {kind: "headerFooterSlot", section: {sectionId}, headerFooterKind, variant}``.
    """

    target: dict[str, Any] = dataclasses.field(default_factory=dict)


@dataclass
class HeaderFootersResolve(Command):
    """Resolve a slot to the actual header/footer part — handles
    "linked to previous" inheritance to land on the part that owns
    the rendered content."""

    target: dict[str, Any] = dataclasses.field(default_factory=dict)


@dataclass
class HeaderFootersRefsSetLinkedToPrevious(Command):
    """Toggle the "linked to previous" flag on a header/footer slot."""

    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    linked: bool = True


# ---------------------------------------------------------------------------
# Lists & Selection (SuperDoc 1.8.1 additions)
# ---------------------------------------------------------------------------

# These ops have no direct python-docx parity surface (python-docx
# doesn't expose list-manipulation primitives — list items are just
# paragraphs with "List Bullet"/"List Number" styles). The typed
# Command dataclasses are registered here for bus completeness and so
# advanced callers reaching for ``doc.lists.merge`` / ``doc.lists.split``
# / ``doc.selection.current`` go through the same retry-aware path as
# every other op.


@dataclass
class ListsCreate(Command):
    """Create a new list — either an empty list at an anchor, or by
    converting an existing paragraph (range) into a list.

    SuperDoc: ``doc.lists.create``.

    - ``mode="empty"`` requires ``at`` (BlockAddress).
    - ``mode="fromParagraphs"`` requires ``target`` (BlockAddressOrRange).
    - ``kind`` is ``"bullet"`` or ``"ordered"``.
    """

    mode: str = "fromParagraphs"
    at: dict[str, Any] | None = None
    target: dict[str, Any] | None = None
    kind: str | None = None
    level: int | None = None
    preset: str | None = None


@dataclass
class ListsAttach(Command):
    """Attach an existing paragraph to an existing list as a new item.

    SuperDoc: ``doc.lists.attach``. ``attach_to`` is the list item to
    attach next to (defines list membership); ``target`` is the
    paragraph being converted.
    """

    attach_to: dict[str, Any] = dataclasses.field(default_factory=dict)
    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    level: int | None = None


@dataclass
class ListsMerge(Command):
    """Merge a list item with an adjacent list / list item.

    SuperDoc 1.8.1: ``doc.lists.merge``. ``direction`` selects the
    sibling to merge into ("previous" | "next" | "list").
    """

    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    direction: str = "previous"


@dataclass
class ListsSplit(Command):
    """Split a list at a list item, optionally restarting numbering."""

    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    restart_numbering: bool | None = None


@dataclass
class SelectionCurrent(Command):
    """Read the current selection. Returns a snapshot dict including
    cursor/range info; pass ``include_text=True`` for the selection's
    plain text."""

    include_text: bool | None = None


# ---------------------------------------------------------------------------
# Track Changes
# ---------------------------------------------------------------------------


@dataclass
class TrackChangesList(Command):
    """List tracked changes (insertions, deletions, formatting marks).

    Mirrors SuperDoc's ``doc.trackChanges.list``. The wire field for
    "filter by change type" is ``type`` on SuperDoc's side; we send
    ``changeType`` instead and the server applier renames in transit so
    it doesn't collide with our top-level Command discriminator
    (``type: "TrackChangesList"``).

    ``in_`` accepts either the literal string ``"all"`` (apply across
    every story — body, headers, footnotes, ...) or a story locator
    dict ``{kind: "story", storyType, ...}``. Trailing-underscore on
    the field name avoids the Python keyword collision; the
    ``_snake_to_camel`` helper strips it for the wire.
    """

    change_type: str | None = None  # "insert" | "delete" | "format"
    limit: int | None = None
    offset: int | None = None
    in_: dict[str, Any] | str | None = None


@dataclass
class TrackChangesGet(Command):
    """Read a single tracked change by id.

    Returns ``{address, id, type, author, authorEmail, date, excerpt,
    wordRevisionIds?}``. ``story`` narrows the lookup to a specific
    body/header/footnote scope when the change id might collide across
    stories (rare, but supported).
    """

    id: str = ""
    story: dict[str, Any] | None = None


@dataclass
class TrackChangesDecide(Command):
    """Accept or reject one or all tracked changes.

    Mirrors SuperDoc's ``doc.trackChanges.decide``. ``decision`` is
    ``"accept"`` or ``"reject"``. ``target`` is either a single change
    address (``{id, story?}``) or the bulk sentinel
    (``{scope: "all"}``).

    ``change_mode`` overrides the batch-level mode for *this one
    decide* — useful when you want to decide a change that itself was
    made under tracked mode without recursively producing more
    changes. Default behaviour: omit and let SuperDoc apply ``direct``.
    """

    decision: str = "accept"  # "accept" | "reject"
    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    force: bool | None = None
    expected_revision: int | None = None
    change_mode: str | None = None


# ---------------------------------------------------------------------------
# Hyperlinks (Athena extension — python-docx 1.x has Hyperlink reads but
# no public add API; PR #74 has been open since 2014. Mirrors SuperDoc's
# ``doc.hyperlinks.create`` / ``doc.hyperlinks.remove``.)
# ---------------------------------------------------------------------------


@dataclass
class CreateHyperlink(Command):
    """Wrap a text range — or insert new text — with a hyperlink mark.

    Either ``target`` (an existing text range) is wrapped, or ``at``
    + ``text`` inserts new text already bound to the hyperlink. Exactly
    one must be set. ``address`` is the URL; ``fragment`` is the
    optional anchor (``#name``). Internal "jump" links carry an empty
    ``address`` and a ``fragment`` that names a bookmark.
    """

    address: str = ""
    fragment: str | None = None
    target: dict[str, Any] | None = None
    at: dict[str, Any] | None = None
    text: str | None = None
    tooltip: str | None = None
    client_entity_id: str | None = None


@dataclass
class RemoveHyperlink(Command):
    """Remove the hyperlink mark from a text range without deleting the
    underlying runs. SuperDoc: ``doc.hyperlinks.remove``."""

    target: dict[str, Any] = dataclasses.field(default_factory=dict)


# ---------------------------------------------------------------------------
# Fields (Athena extension — python-docx has no field-add API. PAGE,
# NUMPAGES, DATE, TIME, FILENAME, AUTHOR, NUMWORDS, REF, SEQ, TOC. The
# server treats SDK-supplied field kinds as a typed enum, falling back
# to a generic FIELD instruction for unknown kinds. Bookmarks (REF),
# captions (SEQ), TOC, and page-numbers all ride this primitive.)
# ---------------------------------------------------------------------------


@dataclass
class CreateField(Command):
    """Insert a Word field at a cursor position or replace a range.

    Mirrors SuperDoc's ``doc.fields.insert``. ``kind`` selects the field
    type (e.g. ``"PAGE"``, ``"NUMPAGES"``, ``"DATE"``, ``"REF"``,
    ``"SEQ"``, ``"TOC"``); ``instr`` is the raw Word field instruction
    string when ``kind == "FIELD"`` (escape hatch for niche fields).
    ``args`` is a kind-specific dict — e.g. ``{format: "MMMM d, yyyy"}``
    for DATE, ``{bookmark: "MyBookmark"}`` for REF, ``{sequence:
    "Figure"}`` for SEQ.
    """

    kind: str = "PAGE"
    args: dict[str, Any] | None = None
    instr: str | None = None
    at: dict[str, Any] | None = None
    target: dict[str, Any] | None = None
    cached_result: str | None = None
    client_entity_id: str | None = None


@dataclass
class FieldsRefresh(Command):
    """Recompute field results document-wide (TOC, REF, PAGE, SEQ, …).

    Mirrors SuperDoc's ``doc.fields.refresh``. Word also refreshes on
    open if ``settings.xml`` carries ``<w:updateFields w:val="true"/>``;
    this op forces refresh synchronously."""

    scope: str | None = None  # "all" | "toc" | "ref" | "seq" | "page"


@dataclass
class FieldsList(Command):
    """List fields in the document, optionally filtered by kind."""

    kind: str | None = None
    limit: int | None = None
    offset: int | None = None


# ---------------------------------------------------------------------------
# Bookmarks (Athena extension — python-docx has no bookmark API.
# Bookmarks are anchor points referenced by hyperlinks (#name), cross-
# references (REF), TOC entries, and captions. Each bookmark has a
# unique name and a start/end anchor pair.)
# ---------------------------------------------------------------------------


@dataclass
class CreateBookmark(Command):
    """Insert a bookmark anchoring a text range or cursor position.

    Mirrors SuperDoc's ``doc.bookmarks.create``. ``name`` must be
    unique (Word silently overwrites duplicates; the server emits an
    error instead). When ``target`` covers a non-collapsed range the
    bookmark wraps that range; with ``at`` it's a zero-width anchor.
    """

    name: str = ""
    target: dict[str, Any] | None = None
    at: dict[str, Any] | None = None
    client_entity_id: str | None = None


@dataclass
class DeleteBookmark(Command):
    """Remove a bookmark by id or name."""

    id: str | None = None
    name: str | None = None


@dataclass
class BookmarksList(Command):
    """List all bookmarks. Returns ``{items: [{id, name, target}]}``."""

    limit: int | None = None
    offset: int | None = None


@dataclass
class BookmarksGet(Command):
    """Read one bookmark by id or name."""

    id: str | None = None
    name: str | None = None


# ---------------------------------------------------------------------------
# Footnotes & Endnotes (Athena extension — python-docx has no
# footnote/endnote API; Issue #1 — first issue ever filed — has been
# open since 2014 and drove the `bayoo-docx` fork. SuperDoc models
# footnotes as a separate story with reference marks in the body.)
# ---------------------------------------------------------------------------


@dataclass
class CreateFootnote(Command):
    """Insert a footnote reference at a cursor position; the footnote
    body lives in a separate story.

    Mirrors SuperDoc's ``doc.footnotes.create``. ``text`` is the
    footnote body (single-paragraph shorthand); use ``CreateFootnote``
    + later ``footnote.add_paragraph(...)`` for multi-block bodies.
    ``custom_mark`` overrides the auto-numbered reference mark (e.g.
    use ``"*"`` instead of ``"1"``).
    """

    at: dict[str, Any] = dataclasses.field(default_factory=dict)
    text: str | None = None
    custom_mark: str | None = None
    client_entity_id: str | None = None


@dataclass
class CreateEndnote(Command):
    """Same as :class:`CreateFootnote` but for endnotes (end-of-section
    notes). SuperDoc: ``doc.endnotes.create``."""

    at: dict[str, Any] = dataclasses.field(default_factory=dict)
    text: str | None = None
    custom_mark: str | None = None
    client_entity_id: str | None = None


@dataclass
class FootnotesList(Command):
    limit: int | None = None
    offset: int | None = None


@dataclass
class EndnotesList(Command):
    limit: int | None = None
    offset: int | None = None


@dataclass
class FootnotesGet(Command):
    id: str = ""


@dataclass
class EndnotesGet(Command):
    id: str = ""


@dataclass
class FootnotesDelete(Command):
    id: str = ""


@dataclass
class EndnotesDelete(Command):
    id: str = ""


@dataclass
class FootnotesPatch(Command):
    id: str = ""
    text: str | None = None


@dataclass
class EndnotesPatch(Command):
    id: str = ""
    text: str | None = None


# ---------------------------------------------------------------------------
# TOC, Captions, Cross-References (Athena extension — built on fields
# and bookmarks. TOC = TOC field; Caption = SEQ field + Bookmark;
# CrossReference = REF field referencing a bookmark or sequence.)
# ---------------------------------------------------------------------------


@dataclass
class CreateTOC(Command):
    """Insert a table-of-contents field at a cursor position.

    Mirrors SuperDoc's ``doc.toc.create``. ``levels`` is ``(min, max)``
    pair selecting the heading level range; ``style_id`` selects the
    in-document style whose paragraphs participate (defaults to all
    ``Heading N`` styles). ``include_hyperlinks`` toggles whether each
    entry is a clickable internal link.
    """

    at: dict[str, Any] = dataclasses.field(default_factory=dict)
    levels: list[int] | None = None  # [min, max]
    style_id: str | None = None
    include_hyperlinks: bool | None = None
    use_outline_levels: bool | None = None
    title: str | None = None
    tab_leader: str | None = None  # "dot" | "underscore" | "hyphen" | "none"
    client_entity_id: str | None = None


@dataclass
class RefreshTOC(Command):
    """Recompute the TOC field's cached result. Equivalent to opening
    the document in Word and clicking Refresh on the TOC."""

    id: str | None = None


@dataclass
class CreateCaption(Command):
    """Insert a caption paragraph (e.g. ``Figure 3: Diagram``).

    Mirrors SuperDoc's ``doc.captions.create``. ``label`` is the caption
    family (``"Figure"``, ``"Table"``, ``"Equation"``, or any custom
    name); the SEQ field auto-numbers per-label. ``text`` is the
    descriptive text after the number. ``bookmark`` (optional) creates
    a bookmark wrapping the caption so cross-references can target it.
    """

    label: str = "Figure"
    text: str = ""
    at: dict[str, Any] = dataclasses.field(default_factory=dict)
    bookmark: str | None = None
    style_id: str | None = None
    client_entity_id: str | None = None


@dataclass
class CreateCrossReference(Command):
    """Insert a cross-reference (REF field) pointing at a bookmark, a
    SEQ caption, a heading, or a numbered list item.

    Mirrors SuperDoc's ``doc.crossReferences.create``. ``reference_kind``
    selects which property of the target to surface: ``"text"``
    (paragraph body), ``"number"`` (auto-numbered sequence value),
    ``"page"`` (page number), ``"label-number"`` (e.g. "Figure 3"),
    ``"above-below"`` (positional adverb), or ``"paragraph"`` (entire
    paragraph). ``hyperlink=True`` makes the reference a clickable
    internal link.
    """

    target: str = ""  # bookmark name or SEQ ref-mark name
    reference_kind: str = "text"
    hyperlink: bool | None = None
    at: dict[str, Any] = dataclasses.field(default_factory=dict)
    client_entity_id: str | None = None


# ---------------------------------------------------------------------------
# Cell borders & shading (Athena extension — python-docx exposes cells
# but provides no API for the OOXML ``<w:tcBorders>`` / ``<w:shd>``
# properties. Issues #146, #201, #1238 have been open for years.
# Borders accept top/bottom/left/right + insideH/insideV; shading
# accepts fill color, pattern, and pattern color.)
# ---------------------------------------------------------------------------


@dataclass
class SetCellBorders(Command):
    """Set per-edge border properties on a single table cell.

    Mirrors SuperDoc's ``doc.tables.setCellBorders``. Each edge accepts
    ``{style, size_pt, color}``; pass ``None`` to leave an edge
    untouched, or ``{style: "none"}`` to remove it. ``style`` values:
    ``"single"``, ``"double"``, ``"dashed"``, ``"dotted"``, ``"thick"``,
    ``"none"`` (plus the rest of OOXML's ``ST_Border``).
    """

    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    top: dict[str, Any] | None = None
    bottom: dict[str, Any] | None = None
    left: dict[str, Any] | None = None
    right: dict[str, Any] | None = None
    inside_horizontal: dict[str, Any] | None = None
    inside_vertical: dict[str, Any] | None = None


@dataclass
class SetCellShading(Command):
    """Set cell fill (shading).

    Mirrors SuperDoc's ``doc.tables.setCellShading``. ``fill`` is a
    hex color (``"FFFF00"``) or ``"auto"`` / ``"none"``. ``pattern``
    is one of OOXML's ``ST_Shd`` values (``"clear"``, ``"solid"``,
    ``"pct25"``, ``"diagStripe"``, …). ``color`` is the pattern color
    when ``pattern`` is set.
    """

    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    fill: str | None = None
    pattern: str | None = None
    color: str | None = None


@dataclass
class SetTableBorders(Command):
    """Set table-wide default borders (the outer frame + the inside
    grid). Same envelope as :class:`SetCellBorders` but scoped to one
    table node. Mirrors SuperDoc's ``doc.tables.setBorders``."""

    node_id: str = ""
    top: dict[str, Any] | None = None
    bottom: dict[str, Any] | None = None
    left: dict[str, Any] | None = None
    right: dict[str, Any] | None = None
    inside_horizontal: dict[str, Any] | None = None
    inside_vertical: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Floating images & wrap (Athena extension — python-docx is inline-only,
# issue #159 has been open since 2017. SuperDoc models anchored images
# with a wrap mode + relative-from anchor.)
# ---------------------------------------------------------------------------


@dataclass
class SetImageAnchor(Command):
    """Promote an inline image to a floating/anchored image with a
    position and wrap mode.

    ``wrap`` is ``"inline"`` (revert), ``"square"``, ``"tight"``,
    ``"through"``, ``"top-bottom"``, ``"behind"``, or ``"in-front"``.
    ``position_x`` / ``position_y`` are offsets in points from the
    relative-from anchor (page, margin, column, paragraph).
    """

    image_id: str = ""
    wrap: str = "square"
    position_x_pt: float | None = None
    position_y_pt: float | None = None
    relative_from_x: str | None = None  # "page" | "margin" | "column"
    relative_from_y: str | None = None  # "page" | "margin" | "paragraph"
    behind_text: bool | None = None


# ---------------------------------------------------------------------------
# Watermarks (Athena extension — issue #845. SuperDoc treats watermarks
# as a header-level image or text element with a fixed position.)
# ---------------------------------------------------------------------------


@dataclass
class CreateWatermark(Command):
    """Insert a watermark on every page (header-level).

    Mirrors SuperDoc's ``doc.watermarks.create``. ``kind`` is
    ``"text"`` or ``"image"``. For text: ``text``, ``font_family``,
    ``font_size_pt``, ``color``, ``opacity`` (0..1), ``angle`` (degrees,
    typically ``-45`` for diagonal). For image: ``src`` (data URI or
    asset id), ``scale`` (0..1 of page width).
    """

    kind: str = "text"
    text: str | None = None
    src: str | None = None
    font_family: str | None = None
    font_size_pt: float | None = None
    color: str | None = None
    opacity: float | None = None
    angle: float | None = None
    scale: float | None = None
    section: dict[str, Any] | None = None
    client_entity_id: str | None = None


@dataclass
class DeleteWatermark(Command):
    """Remove watermark(s). With ``id`` removes one; without, clears
    every watermark in the document (or scoped section)."""

    id: str | None = None
    section: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Charts (Athena extension — python-docx surfaces InlineShape.chart but
# provides no add API; issues #179, #1141 demand both creation and
# data-editing. SuperDoc embeds chart.xml + a workbook part.)
# ---------------------------------------------------------------------------


@dataclass
class CreateChart(Command):
    """Insert a chart at a cursor position.

    Mirrors SuperDoc's ``doc.charts.create``. ``chart_type`` is one of
    Word's families: ``"bar"``, ``"column"``, ``"line"``, ``"pie"``,
    ``"doughnut"``, ``"area"``, ``"scatter"``, ``"radar"``,
    ``"surface"``, ``"stock"``, ``"bubble"``, ``"combo"``,
    ``"waterfall"``, ``"funnel"``, ``"treemap"``, ``"sunburst"``,
    ``"histogram"``, ``"box_whisker"``. ``data`` is a 2D table:
    first row = category labels, first column = series labels, body
    cells = numeric values.
    """

    chart_type: str = "column"
    data: list[list[Any]] = dataclasses.field(default_factory=list)
    at: dict[str, Any] = dataclasses.field(default_factory=dict)
    title: str | None = None
    width_pt: float | None = None
    height_pt: float | None = None
    style: int | None = None  # Word's built-in chart style 1..48
    client_entity_id: str | None = None


@dataclass
class SetChartData(Command):
    """Replace the chart's underlying data table."""

    chart_id: str = ""
    data: list[list[Any]] = dataclasses.field(default_factory=list)


@dataclass
class SetChartType(Command):
    """Change an existing chart's type."""

    chart_id: str = ""
    chart_type: str = "column"


@dataclass
class ChartsList(Command):
    pass


@dataclass
class ChartsGet(Command):
    chart_id: str = ""


# ---------------------------------------------------------------------------
# Math / Equations (Athena extension — python-docx has no math API;
# issue #320 demands both display and inline equations. SuperDoc accepts
# both Office MathML (OMML) and standard MathML.)
# ---------------------------------------------------------------------------


@dataclass
class CreateMath(Command):
    """Insert a math equation at a cursor position.

    Mirrors SuperDoc's ``doc.math.create``. ``format`` is ``"omml"``
    (Office Math Markup, the native Word format) or ``"mathml"``
    (W3C MathML, converted server-side). ``display`` is ``True`` for
    a centered display equation, ``False`` for an inline equation.
    ``latex`` is an optional convenience — server converts via
    a pandoc-style pipeline.
    """

    at: dict[str, Any] = dataclasses.field(default_factory=dict)
    format: str = "mathml"
    content: str | None = None
    latex: str | None = None
    display: bool = False
    client_entity_id: str | None = None


@dataclass
class MathPatch(Command):
    """Replace an existing equation's content."""

    id: str = ""
    format: str = "mathml"
    content: str | None = None
    latex: str | None = None


# ---------------------------------------------------------------------------
# SDT / Content Controls (Athena extension — python-docx surfaces some
# read-only support; issues #155, #224, #1417 demand write. SuperDoc
# treats SDTs as a typed wrapper node.)
# ---------------------------------------------------------------------------


@dataclass
class CreateContentControl(Command):
    """Insert a structured-document-tag (content control).

    Mirrors SuperDoc's ``doc.sdt.create``. ``control_kind`` is one of
    ``"rich-text"``, ``"plain-text"``, ``"picture"``, ``"checkbox"``,
    ``"date"``, ``"dropdown"``, ``"combobox"``, ``"repeating-section"``,
    ``"group"``. ``tag`` is the OOXML ``<w:tag>`` (machine identifier);
    ``alias`` is the friendly name shown in the Word UI. ``placeholder``
    is the prompt text when empty. ``properties`` is kind-specific —
    e.g. ``{items: [{display, value}, ...]}`` for dropdown.
    """

    control_kind: str = "rich-text"
    at: dict[str, Any] | None = None
    target: dict[str, Any] | None = None
    tag: str | None = None
    alias: str | None = None
    placeholder: str | None = None
    properties: dict[str, Any] | None = None
    locked: bool | None = None
    client_entity_id: str | None = None


@dataclass
class ContentControlsList(Command):
    control_kind: str | None = None


@dataclass
class ContentControlsGet(Command):
    id: str = ""


@dataclass
class ContentControlsPatch(Command):
    id: str = ""
    value: Any = None
    alias: str | None = None
    placeholder: str | None = None
    locked: bool | None = None


@dataclass
class ContentControlsDelete(Command):
    id: str = ""
    keep_content: bool | None = None


# ---------------------------------------------------------------------------
# Multi-column section layout (Athena extension — issue #167. SuperDoc
# stores per-section column geometry as part of ``sectPr``.)
# ---------------------------------------------------------------------------


@dataclass
class SetSectionColumns(Command):
    """Set the multi-column layout for a section.

    Mirrors SuperDoc's ``doc.sections.setColumns``. ``count`` is the
    number of columns (1 = single-column). ``equal_width`` makes them
    auto-balance; pass ``widths`` (list of pt floats) for an explicit
    per-column width. ``space_pt`` is the inter-column gutter.
    ``separator`` toggles the vertical separator line.
    """

    target: dict[str, Any] = dataclasses.field(default_factory=dict)
    count: int = 1
    equal_width: bool | None = None
    widths: list[float] | None = None
    space_pt: float | None = None
    separator: bool | None = None


# ---------------------------------------------------------------------------
# Search & Replace (Athena extension — python-docx has no run-isolation
# primitive; issues #30, #980 demand formatting-preserving replace.
# SuperDoc's ``doc.findReplace`` walks every story with the same regex
# and rewrites text in place without flattening run boundaries.)
# ---------------------------------------------------------------------------


@dataclass
class FindReplace(Command):
    """Run a find-and-replace across the document, preserving run
    formatting where possible.

    Mirrors SuperDoc's ``doc.findReplace``. ``pattern`` is a string
    (literal) or, when ``regex=True``, a Python-style regex.
    ``replacement`` may include ``\\1``, ``\\2`` backrefs when regex
    mode is on. ``match_case`` and ``whole_word`` mirror Word's
    find-dialog toggles. ``in_`` scopes the operation: ``"all"``
    (default — every story), ``"body"``, ``"headers"``, ``"footers"``,
    ``"footnotes"``, ``"endnotes"``, ``"comments"``.
    """

    pattern: str = ""
    replacement: str = ""
    regex: bool | None = None
    match_case: bool | None = None
    whole_word: bool | None = None
    in_: str | dict[str, Any] | None = None
    max_replacements: int | None = None


@dataclass
class IterRuns(Command):
    """Stream runs across the document (with story locator + offset)
    so callers can inspect them without paginating ``BlocksList``."""

    in_: str | dict[str, Any] | None = None
    limit: int | None = None
    offset: int | None = None


# ---------------------------------------------------------------------------
# PDF Export (Athena extension — python-docx issue #113 keeps getting
# re-asked despite being closed wontfix. SuperDoc renders via Daytona
# (LibreOffice headless) to bytes the client can download or persist.)
# ---------------------------------------------------------------------------


@dataclass
class ExportPDF(Command):
    """Render the document to a PDF byte stream, optionally storing it
    under ``destination`` (an asset id, S3 URL, or path).

    Returns ``{bytes_base64, asset_id?, page_count}``.
    """

    quality: str | None = None  # "draft" | "standard" | "high"
    destination: str | None = None
    include_revisions: bool | None = None


@dataclass
class ExportDocx(Command):
    """Export the document as a ``.docx`` byte stream, optionally storing
    it under ``destination`` (an asset id, S3 URL, or path).

    Returns ``{bytes_base64, asset_id?}``. The docx-studio applier
    routes through SuperDoc's ``exportDocx`` SDK call when available;
    when the server build doesn't expose it, the command returns an
    empty payload and the Python SDK raises a clear ``DocxError``
    rather than silently writing zero bytes.

    Athena extension beyond python-docx 1.x — closes the gap left by
    ``Document.save(path)`` rejecting local targets (an asset-backed
    SDK can't fulfill the implied "write bytes to disk" contract from
    the buffer alone). Parity test harnesses against upstream
    ``python-docx`` need a byte-for-byte export to diff against, and
    pointing users at Olympus's Export DOCX action breaks every CI
    workflow that runs headless.
    """

    destination: str | None = None
    include_revisions: bool | None = None


# ---------------------------------------------------------------------------
# Numbering / List metadata reads (Athena extension — python-docx
# issue #471 demands ``Paragraph.get_listnum()``-style access. The
# server surfaces SuperDoc's per-paragraph numbering state.)
# ---------------------------------------------------------------------------


@dataclass
class NumberingGet(Command):
    """Read the numbering state for a paragraph.

    Returns ``{numId, ilvl, format, value, restart}`` or ``None`` if
    the paragraph isn't part of a list. ``format`` is one of OOXML's
    ``ST_NumberFormat`` values (``"decimal"``, ``"lowerLetter"``,
    ``"upperRoman"``, ``"bullet"``, ``"chicago"``, …).
    """

    block_id: str = ""


@dataclass
class NumberingList(Command):
    """Enumerate every numbered/bulleted paragraph in document order."""

    in_: str | dict[str, Any] | None = None
    limit: int | None = None
    offset: int | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Set of commands that mutate the doc. Inverse is "queries". Used by the
# CommandBuffer to decide whether to flush before issuing (queries always
# flush; pure mutations may be buffered).
_QUERY_TYPES: frozenset[str] = frozenset(
    {
        "BlocksList",
        "Find",
        "GetNodeById",
        "GetNode",
        "ImagesList",
        "Info",
        "SectionsList",
        "SectionsGet",
        "TablesGet",
        "TablesGetCells",
        "TablesGetProperties",
        "MarkdownToFragment",
        "CommentsGet",
        "CommentsList",
        "HeaderFootersList",
        "HeaderFootersGet",
        "HeaderFootersResolve",
        "SelectionCurrent",
        # Track-changes reads — never mutate, always flush.
        "TrackChangesList",
        "TrackChangesGet",
        # Athena-extension reads.
        "FieldsList",
        "BookmarksList",
        "BookmarksGet",
        "FootnotesList",
        "EndnotesList",
        "FootnotesGet",
        "EndnotesGet",
        "ChartsList",
        "ChartsGet",
        "ContentControlsList",
        "ContentControlsGet",
        "NumberingGet",
        "NumberingList",
        "IterRuns",
    }
)

# Mutating commands whose response carries data the caller needs (a new
# node id, typically). These must be flushed immediately rather than
# deferred — the caller is about to read the response.
_RESPONSE_BEARING_TYPES: frozenset[str] = frozenset(
    {
        "CreateParagraph",
        "CreateHeading",
        "CreateTable",
        # CreateImage returns {image: {nodeId}}; SetImageSize and the
        # InlineShape proxy both need that nodeId, so it must flush.
        "CreateImage",
        # Insert is INTENTIONALLY not here as of 0.8.0. All in-tree
        # callers (``Paragraph._insert_run_text_segments``, ``Run.add_text``,
        # ``_Cell.text``) wrap a known client-side range/cell target and
        # never read Insert's response; deferring it lets a styled
        # ``add_run`` flow ship its text-insert in the same HTTP batch
        # as the format setters that follow it. If a future caller needs
        # the Insert response, route it through ``CommandBuffer._eager_flush_with``
        # at the call site rather than re-adding Insert here, so the
        # batched path isn't penalized for the one outlier.
        # CreateSectionBreak intentionally NOT here — it returns no node id;
        # the caller resolves the new section via sections.list afterwards.
        # CommentsCreate returns the new comment's entityId — caller wraps
        # it in a Comment proxy.
        "CommentsCreate",
        "CommentsPatch",
        # TrackChangesDecide returns {success, inserted, updated, removed}
        # describing the entities affected by accept/reject — callers
        # need that synchronously to invalidate their Revision proxies.
        "TrackChangesDecide",
        # ListsCreate / ListsAttach return {item: {nodeId: <listItemId>}}.
        # Document.add_paragraph reads listItemId to (1) update the
        # Paragraph proxy's node_id so subsequent ops target the
        # listItem, and (2) chain the next list item via lists.attach.
        "ListsCreate",
        "ListsAttach",
        # Athena-extension response-bearing creates — each returns an
        # entity id the caller wraps in a proxy.
        "CreateHyperlink",
        "CreateField",
        "CreateBookmark",
        "CreateFootnote",
        "CreateEndnote",
        "CreateTOC",
        "CreateCaption",
        "CreateCrossReference",
        "CreateWatermark",
        "CreateChart",
        "CreateMath",
        "CreateContentControl",
        # ExportPDF returns bytes the caller needs synchronously.
        "ExportPDF",
        # ExportDocx returns .docx bytes the caller needs synchronously.
        "ExportDocx",
        # FindReplace returns a replacement count for the caller.
        "FindReplace",
    }
)


def is_query(cmd: Command) -> bool:
    return cmd.type in _QUERY_TYPES


def is_response_bearing(cmd: Command) -> bool:
    return cmd.type in _RESPONSE_BEARING_TYPES


def must_flush_immediately(cmd: Command) -> bool:
    """A command that can't be buffered — caller will read the response."""
    return is_query(cmd) or is_response_bearing(cmd)


# ---------------------------------------------------------------------------
# Athena-extension command marking
# ---------------------------------------------------------------------------
#
# Bulk-stamp the v0.11.0 Athena-extension command dataclasses with the
# ``__athena_extension__`` marker. Doing it here (rather than per-class
# with the decorator) keeps the dataclass definitions terse — the
# attribute is set on the class after definition, which is equivalent
# to a class-decorator stamping. The walker in
# ``docx/_athena_extension.py`` picks these up alongside the
# explicit @athena_extension marked classes.

from docx._athena_extension import (  # noqa: E402 — local circular import safety
    ATHENA_EXTENSION_ATTR,
    ATHENA_EXTENSION_DESCRIPTION_ATTR,
    ATHENA_EXTENSION_ISSUE_ATTR,
    ATHENA_EXTENSION_SINCE_ATTR,
)


def _mark_athena_extension_command(
    cls: type, issue: "str | None", description: str
) -> None:
    setattr(cls, ATHENA_EXTENSION_ATTR, True)
    # ``issue`` is ``None`` for additions that don't have a 1:1 upstream
    # python-docx issue — typically things that are *not* missing from
    # python-docx but that our asset-backed SDK has to surface differently
    # (e.g. ``Document.export_docx`` because ``Document.save(path)``
    # rejects local targets in this SDK).
    setattr(cls, ATHENA_EXTENSION_ISSUE_ATTR, issue)
    setattr(cls, ATHENA_EXTENSION_DESCRIPTION_ATTR, description)
    setattr(cls, ATHENA_EXTENSION_SINCE_ATTR, "0.11.0")


for _cls, _issue, _desc in [
    (CreateHyperlink, "python-docx#74", "Hyperlink add"),
    (RemoveHyperlink, "python-docx#74", "Hyperlink remove"),
    (CreateField, "python-docx#498", "Field insert"),
    (FieldsRefresh, "python-docx#498", "Field refresh"),
    (FieldsList, "python-docx#498", "Field enumeration"),
    (CreateBookmark, "python-docx#425", "Bookmark create"),
    (DeleteBookmark, "python-docx#425", "Bookmark delete"),
    (BookmarksList, "python-docx#425", "Bookmark enumeration"),
    (BookmarksGet, "python-docx#425", "Bookmark read"),
    (CreateFootnote, "python-docx#1", "Footnote create"),
    (CreateEndnote, "python-docx#1", "Endnote create"),
    (FootnotesList, "python-docx#1", "Footnote enumeration"),
    (EndnotesList, "python-docx#1", "Endnote enumeration"),
    (FootnotesGet, "python-docx#1", "Footnote read"),
    (EndnotesGet, "python-docx#1", "Endnote read"),
    (FootnotesPatch, "python-docx#1", "Footnote update"),
    (EndnotesPatch, "python-docx#1", "Endnote update"),
    (FootnotesDelete, "python-docx#1", "Footnote delete"),
    (EndnotesDelete, "python-docx#1", "Endnote delete"),
    (CreateTOC, "python-docx#36", "TOC insert"),
    (RefreshTOC, "python-docx#1403", "TOC refresh"),
    (CreateCaption, "python-docx#676", "Caption insert (SEQ field)"),
    (CreateCrossReference, "python-docx#97", "Cross-reference (REF field)"),
    (SetCellBorders, "python-docx#201", "Per-edge cell borders"),
    (SetCellShading, "python-docx#146", "Cell fill / shading"),
    (SetTableBorders, "python-docx#201", "Table-wide borders"),
    (SetImageAnchor, "python-docx#159", "Floating-image anchor"),
    (CreateWatermark, "python-docx#845", "Watermark create"),
    (DeleteWatermark, "python-docx#845", "Watermark delete"),
    (CreateChart, "python-docx#179", "Chart create"),
    (SetChartData, "python-docx#1141", "Chart data setter"),
    (SetChartType, "python-docx#179", "Chart type swap"),
    (ChartsList, "python-docx#179", "Chart enumeration"),
    (ChartsGet, "python-docx#179", "Chart read"),
    (CreateMath, "python-docx#320", "Math equation create"),
    (MathPatch, "python-docx#320", "Math equation update"),
    (CreateContentControl, "python-docx#155", "Content control (SDT) create"),
    (ContentControlsList, "python-docx#155", "SDT enumeration"),
    (ContentControlsGet, "python-docx#155", "SDT read"),
    (ContentControlsPatch, "python-docx#155", "SDT update"),
    (ContentControlsDelete, "python-docx#155", "SDT delete"),
    (SetSectionColumns, "python-docx#167", "Section multi-column layout"),
    (FindReplace, "python-docx#30", "Formatting-preserving find/replace"),
    (IterRuns, "python-docx#980", "Run stream for run-isolation"),
    (ExportPDF, "python-docx#113", "PDF export"),
    (ExportDocx, None, "DOCX export — local file roundtrip"),
    (NumberingGet, "python-docx#471", "Numbering metadata read"),
    (NumberingList, "python-docx#471", "Numbering enumeration"),
]:
    _mark_athena_extension_command(_cls, _issue, _desc)

# Pre-existing Athena-extension commands (track-changes) — surface them
# too so the registry is complete.
for _cls, _issue, _desc in [
    (TrackChangesList, "python-docx#340", "Track-changes enumeration"),
    (TrackChangesGet, "python-docx#340", "Track-changes read"),
    (TrackChangesDecide, "python-docx#340", "Track-changes accept/reject"),
]:
    setattr(_cls, ATHENA_EXTENSION_ATTR, True)
    setattr(_cls, ATHENA_EXTENSION_ISSUE_ATTR, _issue)
    setattr(_cls, ATHENA_EXTENSION_DESCRIPTION_ATTR, _desc)
    setattr(_cls, ATHENA_EXTENSION_SINCE_ATTR, "0.9.0")


__all__ = [
    "Command",
    # Block creation
    "CreateParagraph",
    "CreateHeading",
    "CreateTable",
    "CreateImage",
    "CreateSectionBreak",
    # Inline mutations
    "Insert",
    "Replace",
    "InsertLineBreak",
    "InsertTab",
    "FormatApply",
    "SetParagraphAlignment",
    "ClearParagraphAlignment",
    "SetParagraphStyle",
    "SetParagraphIndentation",
    "ClearParagraphIndentation",
    "SetParagraphSpacing",
    "ClearParagraphSpacing",
    "SetParagraphKeepOptions",
    "SetParagraphFlowOptions",
    "SetParagraphTabStop",
    "ClearParagraphTabStops",
    # Sections
    "SetSectionPageMargins",
    "SetSectionPageSetup",
    "SetSectionHeaderFooterMargins",
    "SetSectionBreakType",
    "SetSectionTitlePage",
    "SetSectionsOddEvenHeadersFooters",
    "SetSectionLinkToPrevious",
    # Tables (mutations)
    "TablesInsertRow",
    "TablesInsertColumn",
    "TablesMergeCells",
    "TablesSetStyle",
    "TablesSetLayout",
    "TablesSetTableOptions",
    "TablesSetCellProperties",
    "TablesSetColumnWidth",
    "TablesSetRowHeight",
    "TableSetCell",
    # Images (mutations)
    "SetImageSize",
    # Queries
    "BlocksList",
    "Find",
    "GetNodeById",
    "GetNode",
    "ImagesList",
    "Info",
    "SectionsList",
    "SectionsGet",
    "TablesGet",
    "TablesGetCells",
    "TablesGetProperties",
    "MarkdownToFragment",
    # Track Changes
    "TrackChangesList",
    "TrackChangesGet",
    "TrackChangesDecide",
    # Athena-extension surface (no python-docx upstream parity — see
    # python-sdk/CLAUDE.md § Intentional deviations (additions / different
    # semantics))
    "CreateHyperlink",
    "RemoveHyperlink",
    "CreateField",
    "FieldsRefresh",
    "FieldsList",
    "CreateBookmark",
    "DeleteBookmark",
    "BookmarksList",
    "BookmarksGet",
    "CreateFootnote",
    "CreateEndnote",
    "FootnotesList",
    "EndnotesList",
    "FootnotesGet",
    "EndnotesGet",
    "FootnotesDelete",
    "EndnotesDelete",
    "FootnotesPatch",
    "EndnotesPatch",
    "CreateTOC",
    "RefreshTOC",
    "CreateCaption",
    "CreateCrossReference",
    "SetCellBorders",
    "SetCellShading",
    "SetTableBorders",
    "SetImageAnchor",
    "SetImageAltText",
    "SetImageDecorative",
    "CreateWatermark",
    "DeleteWatermark",
    "CreateChart",
    "SetChartData",
    "SetChartType",
    "ChartsList",
    "ChartsGet",
    "CreateMath",
    "MathPatch",
    "CreateContentControl",
    "ContentControlsList",
    "ContentControlsGet",
    "ContentControlsPatch",
    "ContentControlsDelete",
    "SetSectionColumns",
    "FindReplace",
    "IterRuns",
    "ExportPDF",
    "ExportDocx",
    "NumberingGet",
    "NumberingList",
    # Helpers
    "is_query",
    "is_response_bearing",
    "must_flush_immediately",
]
