"""InlineShape / InlineShapes — python-docx image shapes.

Enumerates images in the document via `doc.images.list`. Read access
to image binary / metadata round-trips through `doc.images.get`.
"""

from __future__ import annotations

import base64
import warnings
from typing import TYPE_CHECKING

from docx._athena_extension import athena_extension
from docx._batching import run_sync
from docx.shared import Length, Pt

if TYPE_CHECKING:
    from docx.client import Session


class PendingInlineShapeClearWarning(UserWarning):
    """Emitted when ``InlineShape.width`` or ``.height`` is set to
    ``None`` (python-docx semantics: "revert to natural sizing").

    SuperDoc 1.8 has no clear-op for image dimensions — its
    ``images.setSize`` requires explicit ``width`` and ``height``. The
    SDK can't represent a "revert to natural" intent on the wire, so
    ``image.width = None`` is a no-op. The warning surfaces the
    silent-divergence pattern so agent runs see the gap. Tracked in
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md``.
    """


def _warn_inline_shape_clear(prop: str) -> None:
    warnings.warn(
        f"InlineShape.{prop} = None was IGNORED — SuperDoc 1.8 has no "
        f"clear-op for image dimensions. The image keeps its previous "
        f"size. Tracked in docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md.",
        PendingInlineShapeClearWarning,
        stacklevel=3,
    )


def _strip_data_uri(src: str) -> tuple[bytes, str | None]:
    """If ``src`` is a ``data:`` URI, return (decoded_bytes, mime).
    Otherwise return ``(b"", None)``."""
    if not src.startswith("data:"):
        return b"", None
    try:
        head, b64 = src.split(",", 1)
    except ValueError:
        return b"", None
    mime: str | None = None
    if head.startswith("data:"):
        meta = head[len("data:") :]
        # meta = "image/png;base64" or just "image/png"
        if ";" in meta:
            mime = meta.split(";", 1)[0]
        elif meta:
            mime = meta
    try:
        return base64.b64decode(b64), mime
    except (ValueError, TypeError):
        return b"", mime


class InlineShape:
    """An inline image/shape in the document."""

    def __init__(self, *, session: "Session", info: dict) -> None:
        self._session: "Session" = session
        self._info: dict = info

    @property
    def _node_id(self) -> str:
        nid = self._info.get("nodeId") or self._info.get("id")
        return str(nid) if nid else ""

    @property
    def width(self) -> "Length | None":
        size = self._info.get("size") or {}
        if isinstance(size, dict):
            w = size.get("width") or size.get("widthPt")
            if isinstance(w, (int, float)):
                return Pt(float(w))
        return None

    @width.setter
    def width(self, value: "Length | int | None") -> None:
        if value is None:
            _warn_inline_shape_clear("width")
            return
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        h = self.height
        h_pt: float = float(h.pt) if isinstance(h, Length) else 72.0
        # SuperDoc's DocImagesSetSizeParams: imageId + size:{width,
        # height, unit}. The earlier {nodeId, widthPt, heightPt} shape
        # was silently rejected (the apps/api applier punts SuperDoc
        # types via AnyDoc) — image resize was a no-op.
        run_sync(
            self._session.doc.images.set_size(
                {
                    "imageId": self._node_id,
                    "size": {"width": pt, "height": h_pt, "unit": "pt"},
                },
            ),
        )

    @property
    def height(self) -> "Length | None":
        size = self._info.get("size") or {}
        if isinstance(size, dict):
            h = size.get("height") or size.get("heightPt")
            if isinstance(h, (int, float)):
                return Pt(float(h))
        return None

    @height.setter
    def height(self, value: "Length | int | None") -> None:
        if value is None:
            _warn_inline_shape_clear("height")
            return
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        w = self.width
        w_pt: float = float(w.pt) if isinstance(w, Length) else 72.0
        run_sync(
            self._session.doc.images.set_size(
                {
                    "imageId": self._node_id,
                    "size": {"width": w_pt, "height": pt, "unit": "pt"},
                },
            ),
        )

    @property
    def type(self) -> int:
        # python-docx enum: WD_INLINE_SHAPE.PICTURE = 3. Return PICTURE for all.
        return 3

    @property
    def picture(self) -> "Picture":
        """Return a :class:`Picture` proxy for binary / metadata reads.

        Mirrors python-docx ``InlineShape.picture``. The Picture lazily
        fetches via ``doc.images.get`` on first access of its byte- or
        filename-bearing properties.
        """
        return Picture(self)

    @property
    @athena_extension(issue="PR#1530", description="InlineShape.alt_text — image alt text.")
    def alt_text(self) -> str:
        """Alt text (Word's "Alternative text · Description" field).

        Athena extension beyond python-docx 1.x. Upstream PR #1530 is
        in flight but unreleased. python-docx has no public alt-text
        API. See ``python-sdk/CLAUDE.md`` § *Intentional deviations*.
        """
        info = self._info
        for key in ("altText", "alt_text", "descr", "description"):
            v = info.get(key)
            if isinstance(v, str):
                return v
        return ""

    @alt_text.setter
    @athena_extension(issue="PR#1530", description="InlineShape.alt_text setter.")
    def alt_text(self, value: str | None) -> None:
        from docx.commands import SetImageAltText

        text = "" if value is None else str(value)
        run_sync(
            self._session.send_command(
                SetImageAltText(image_id=self._node_id, alt_text=text),
            ),
        )
        self._info["altText"] = text

    @property
    @athena_extension(issue="PR#1530", description="InlineShape.title — image title.")
    def title(self) -> str:
        """Image title (Word's "Alternative text · Title" field).

        Athena extension beyond python-docx 1.x — pairs with
        :attr:`alt_text` for accessibility metadata.
        """
        info = self._info
        v = info.get("title")
        return v if isinstance(v, str) else ""

    @title.setter
    @athena_extension(issue="PR#1530", description="InlineShape.title setter.")
    def title(self, value: str | None) -> None:
        from docx.commands import SetImageAltText

        text = "" if value is None else str(value)
        run_sync(
            self._session.send_command(
                SetImageAltText(image_id=self._node_id, alt_text=text),
            ),
        )
        self._info["title"] = text

    @property
    @athena_extension(issue="PR#1530", description="InlineShape.decorative flag.")
    def decorative(self) -> bool:
        """``True`` when the image is marked decorative (screen readers
        skip it).

        Athena extension beyond python-docx 1.x.
        """
        v = self._info.get("decorative")
        return bool(v) if v is not None else False

    @decorative.setter
    @athena_extension(issue="PR#1530", description="InlineShape.decorative setter.")
    def decorative(self, value: bool) -> None:
        from docx.commands import SetImageDecorative

        run_sync(
            self._session.send_command(
                SetImageDecorative(image_id=self._node_id, decorative=bool(value)),
            ),
        )
        self._info["decorative"] = bool(value)

    @athena_extension(
        issue=159,
        description="InlineShape.anchor — promote inline to floating image.",
    )
    def anchor(
        self,
        *,
        wrap: str = "square",
        position_x_pt: float | None = None,
        position_y_pt: float | None = None,
        relative_from_x: str | None = None,
        relative_from_y: str | None = None,
        behind_text: bool | None = None,
    ) -> None:
        """Promote an inline image to a floating image with the given
        wrap mode and absolute position.

        Athena extension beyond python-docx 1.x. python-docx is
        inline-only; issue #159 has been open since 2017. ``wrap``
        values: ``"inline"`` (revert to inline), ``"square"``,
        ``"tight"``, ``"through"``, ``"top-bottom"``, ``"behind"``,
        ``"in-front"``. ``relative_from_x`` ∈ {``"page"``, ``"margin"``,
        ``"column"``}; ``relative_from_y`` ∈ {``"page"``, ``"margin"``,
        ``"paragraph"``}.
        """
        from docx.commands import SetImageAnchor

        run_sync(
            self._session.send_command(
                SetImageAnchor(
                    image_id=self._node_id,
                    wrap=wrap,
                    position_x_pt=position_x_pt,
                    position_y_pt=position_y_pt,
                    relative_from_x=relative_from_x,
                    relative_from_y=relative_from_y,
                    behind_text=behind_text,
                ),
            ),
        )


class InlineShapes:
    """Collection of inline shapes (images) in the document."""

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self) -> list[dict]:
        info: object = run_sync(self._session.doc.images.list({}))
        if isinstance(info, dict):
            items: object = info.get("items") or info.get("images") or []
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        elif isinstance(info, list):
            return [i for i in info if isinstance(i, dict)]
        return []

    def __len__(self) -> int:
        return len(self._items())

    def __iter__(self):
        for info in self._items():
            yield InlineShape(session=self._session, info=info)

    def __getitem__(self, index: int) -> InlineShape:
        return InlineShape(session=self._session, info=self._items()[index])


# python-docx also exposes Shape (non-inline) and Picture; minimal stubs below.
class Shape:
    """Floating/positioned shape — minimal python-docx parity stub."""

    def __init__(self, *, session: "Session", info: dict) -> None:
        self._session: "Session" = session
        self._info: dict = info


class Picture:
    """Picture accessor — mirrors python-docx's InlineShape.picture.

    Lazily fetches binary / metadata via ``doc.images.get`` on first
    access. SuperDoc's typed return is ``Record<string, unknown>`` so
    we probe a small set of common keys (``src``, ``url``,
    ``contentType``, ``mime``, ``name``, ``filename``) and decode
    ``data:`` URIs inline. If the asset's source is an external URL
    (not a data URI), :attr:`image_bytes` returns ``b""`` because the
    SDK is HTTP-only and doesn't fetch external bytes; check
    :attr:`content_type` first to disambiguate "no image" from "image
    not inlined".
    """

    def __init__(self, inline_shape: InlineShape) -> None:
        self._inline_shape: InlineShape = inline_shape
        self._fetched: dict | None = None

    def _fetch(self) -> dict:
        if self._fetched is not None:
            return self._fetched
        nid = self._inline_shape._node_id
        if not nid:
            self._fetched = {}
            return self._fetched
        result: object = run_sync(
            self._inline_shape._session.doc.images.get({"imageId": nid}),
        )
        self._fetched = result if isinstance(result, dict) else {}
        return self._fetched

    @property
    def image_bytes(self) -> bytes:
        """Decoded image bytes. Returns ``b""`` when the source is an
        external URL (the SDK doesn't fetch external assets) or when
        SuperDoc returns no payload for the image."""
        info = self._fetch()
        for key in ("src", "url", "data", "image"):
            v = info.get(key)
            if isinstance(v, str):
                payload, _mime = _strip_data_uri(v)
                if payload:
                    return payload
        return b""

    @property
    def content_type(self) -> str | None:
        info = self._fetch()
        for key in ("contentType", "mime", "mimeType"):
            v = info.get(key)
            if isinstance(v, str) and v:
                return v
        # Fall back to the data-URI MIME on the source.
        for key in ("src", "url"):
            v = info.get(key)
            if isinstance(v, str):
                _payload, mime = _strip_data_uri(v)
                if mime:
                    return mime
        return None

    @property
    def filename(self) -> str | None:
        info = self._fetch()
        for key in ("name", "filename", "fileName"):
            v = info.get(key)
            if isinstance(v, str) and v:
                return v
        return None

    @property
    @athena_extension(description="Picture.ext — file extension shortcut.")
    def ext(self) -> str | None:
        """File extension (no leading dot) derived from :attr:`filename`
        or :attr:`content_type`. Athena extension."""
        fn = self.filename
        if fn and "." in fn:
            return fn.rsplit(".", 1)[-1].lower()
        ct = self.content_type
        if isinstance(ct, str) and ct.startswith("image/"):
            return ct.split("/", 1)[1].lower()
        return None

    @property
    @athena_extension(issue="PR#1530", description="Picture.alt_text mirror.")
    def alt_text(self) -> str:
        """Alt text — mirror of :attr:`InlineShape.alt_text`. Athena
        extension; python-docx upstream has no public alt-text API."""
        return self._inline_shape.alt_text

    @alt_text.setter
    @athena_extension(issue="PR#1530", description="Picture.alt_text setter.")
    def alt_text(self, value: str | None) -> None:
        self._inline_shape.alt_text = value

    @property
    @athena_extension(issue="PR#1530", description="Picture.title mirror.")
    def title(self) -> str:
        """Title — mirror of :attr:`InlineShape.title`. Athena
        extension."""
        return self._inline_shape.title

    @title.setter
    @athena_extension(issue="PR#1530", description="Picture.title setter.")
    def title(self, value: str | None) -> None:
        self._inline_shape.title = value

    @property
    @athena_extension(issue="PR#1530", description="Picture.decorative mirror.")
    def decorative(self) -> bool:
        """Mirror of :attr:`InlineShape.decorative`. Athena extension."""
        return self._inline_shape.decorative

    @decorative.setter
    @athena_extension(issue="PR#1530", description="Picture.decorative setter.")
    def decorative(self, value: bool) -> None:
        self._inline_shape.decorative = value
