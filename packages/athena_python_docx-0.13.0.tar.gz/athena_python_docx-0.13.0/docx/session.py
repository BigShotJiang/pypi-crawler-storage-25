"""Discoverability alias — re-exports the public batching surface.

Agents repeatedly try ``from docx.session import run_sync`` (verified
in LangSmith thread ``thread_28dae56c-…`` on PR #20788 preview, where
the model burned a tool-call iteration on
``ModuleNotFoundError: No module named 'docx.session'`` before falling
back to ``inspect.getsource``). The canonical home is the private
``docx._batching`` module, but the leading-underscore prefix isn't a
signal LLMs read reliably. This shim exists to fail less surprisingly.

Stable surface — these are also exported from :mod:`docx._batching`
and either path is supported:

* :func:`run_sync` — drive an async coroutine from a sync call site.
* :data:`DEFAULT_OP_TIMEOUT_SECONDS` — the timeout the ``run_sync``
  shim applies before raising ``concurrent.futures.TimeoutError``.

Anything else inside :mod:`docx._batching` is implementation detail
and may move without a deprecation cycle; this module deliberately
re-exports only the surface agents have a legitimate reason to call.
"""

from __future__ import annotations

from docx._batching import DEFAULT_OP_TIMEOUT_SECONDS, run_sync

__all__ = ["run_sync", "DEFAULT_OP_TIMEOUT_SECONDS"]
