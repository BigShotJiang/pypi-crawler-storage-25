"""Math equations — Athena extension beyond python-docx 1.x.

python-docx upstream has no math API. Issue #320 demands MathML
insertion; the wider community uses Office Math Markup (OMML, Word's
native format) and LaTeX heavily. SuperDoc accepts both OMML and W3C
MathML (server-converted) and offers a LaTeX → MathML pipeline.

See ``python-sdk/CLAUDE.md`` § *Intentional deviations (additions /
different semantics)*.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._athena_extension import athena_extension
from docx._batching import run_sync

__athena_extension_module__: bool = True
__athena_extension_issue__: str = "python-docx#320"
__athena_extension_description__: str = "Math equations (MathML / OMML / LaTeX)."
__athena_extension_since__: str = "0.11.0"

if TYPE_CHECKING:
    from docx.client import Session


@athena_extension(issue=320, description="Math equation proxy.")
class MathEquation:
    """One math equation in the document. Both inline and display
    equations are represented; ``display`` selects between them."""

    def __init__(
        self,
        *,
        session: "Session",
        math_id: str,
        format: str = "mathml",
        content: str | None = None,
        display: bool = False,
    ) -> None:
        self._session: "Session" = session
        self._math_id: str = math_id
        self._format: str = format
        self._content: str | None = content
        self._display: bool = display

    @property
    def math_id(self) -> str:
        return self._math_id

    @property
    def format(self) -> str:
        return self._format

    @property
    def content(self) -> str:
        return self._content or ""

    @content.setter
    def content(self, value: str) -> None:
        from docx.commands import MathPatch

        wire_format = self._format if self._format != "latex" else "mathml"
        kwargs: dict = {
            "id": self._math_id,
            "format": wire_format,
        }
        if self._format == "latex":
            kwargs["latex"] = value
        else:
            kwargs["content"] = value
        run_sync(self._session.send_command(MathPatch(**kwargs)))
        self._content = value

    @property
    def display(self) -> bool:
        return self._display


__all__ = ["MathEquation"]
