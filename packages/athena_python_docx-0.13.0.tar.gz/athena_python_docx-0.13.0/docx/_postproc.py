"""Post-export OOXML rewrites applied to ``.docx`` bytes returned by
``Document.export_docx``.

Some user-facing surfaces are blocked on SuperDoc binary ops that don't
exist yet — for example, cell-inner paragraph format ops
(``SetParagraphAlignment`` / ``SetParagraphStyle`` /
``SetParagraphIndentation`` / ``SetParagraphSpacing``) reject targets
that resolve into ``tableCell`` children, and there's no
``tables.setCellContent`` op that takes a paragraph-property payload.

The mitigation here is: when the SDK sees a format op that would cascade-
fail at the SuperDoc layer, it records the user's intent in the
session's :class:`PostExportOps` collector and short-circuits the wire
call. ``Document.export_docx`` runs :meth:`PostExportOps.apply_to_docx`
against the bytes it gets back from docx-studio — that opens the
``.docx`` zip, rewrites ``word/document.xml`` with the recorded format
ops + REF-field restorations, and re-packs the zip.

Live-session behavior is unchanged (Olympus collaborators don't see the
formatting until export). The visible result is correct for the most
common workflow: agent generates a document, user exports to send.
"""
from __future__ import annotations

import io
import re as _re
import zipfile
from dataclasses import dataclass, field
from typing import Any, Iterable
from xml.etree import ElementTree as ET


WORD_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
W_NS = f"{{{WORD_NS}}}"


# Every well-known OOXML namespace that may appear in a SuperDoc-exported
# ``word/document.xml``. We register all of them with their canonical
# prefix BEFORE parsing so ``ET.tostring`` re-emits the same prefixes
# the input used. Without this, ET assigns auto-generated ``ns0`` /
# ``ns1`` / ``ns2`` prefixes for every namespace except ``w``, which
# breaks the ``mc:Ignorable="w14 w15 w16se …"`` attribute (the prefixes
# listed there reference namespace bindings that no longer exist by
# those names). Word's strict validator surfaces this as "unreadable
# content" / recovery dialog on open.
_OOXML_NAMESPACE_PREFIXES: dict[str, str] = {
    "w": WORD_NS,
    "w14": "http://schemas.microsoft.com/office/word/2010/wordml",
    "w15": "http://schemas.microsoft.com/office/word/2012/wordml",
    "w16cid": "http://schemas.microsoft.com/office/word/2016/wordml/cid",
    "w16cex": "http://schemas.microsoft.com/office/word/2018/wordml/cex",
    "w16": "http://schemas.microsoft.com/office/word/2018/wordml",
    "w16se": "http://schemas.microsoft.com/office/word/2015/wordml/symex",
    "w16sdtdh": "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash",
    "w16sdtfl": "http://schemas.microsoft.com/office/word/2024/wordml/sdtFormulas",
    "w16du": "http://schemas.microsoft.com/office/word/2023/wordml/word16du",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "wp14": "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "m": "http://schemas.openxmlformats.org/officeDocument/2006/math",
    "v": "urn:schemas-microsoft-com:vml",
    "o": "urn:schemas-microsoft-com:office:office",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "pic": "http://schemas.openxmlformats.org/drawingml/2006/picture",
    "xml": "http://www.w3.org/XML/1998/namespace",
}


def _register_ooxml_namespaces() -> None:
    """Bind every well-known OOXML namespace to its canonical prefix.

    Idempotent — safe to call repeatedly. Must be called BEFORE any
    ``ET.fromstring`` / ``ET.tostring`` cycle that handles a
    SuperDoc-exported ``word/document.xml``.
    """
    for prefix, uri in _OOXML_NAMESPACE_PREFIXES.items():
        ET.register_namespace(prefix, uri)


def _find_root_open_tag(text: str) -> "tuple[int, int] | None":
    """Locate the opening root tag of an XML document — returns
    ``(start, end)`` indices spanning ``<name attr=... >``.

    Skips the optional ``<?xml ...?>`` declaration. Handles unquoted
    forward slashes inside attribute values (e.g.
    ``xmlns:wpc="http://wpc"``) — those would defeat a naive
    ``<[^/>]*>`` regex, which is why we tokenize the tag manually.
    """
    # Skip the XML declaration if present.
    i = 0
    n = len(text)
    while i < n and text[i].isspace():
        i += 1
    if text.startswith("<?xml", i):
        end = text.find("?>", i)
        if end == -1:
            return None
        i = end + 2
    # Skip any subsequent whitespace + comments / DOCTYPE.
    while i < n:
        while i < n and text[i].isspace():
            i += 1
        if text.startswith("<!--", i):
            end = text.find("-->", i)
            if end == -1:
                return None
            i = end + 3
            continue
        if text.startswith("<!DOCTYPE", i):
            end = text.find(">", i)
            if end == -1:
                return None
            i = end + 1
            continue
        break
    # Expect ``<NAME`` here.
    if i >= n or text[i] != "<":
        return None
    start = i
    # Walk forward to the matching ``>``, respecting quoted attribute
    # values so embedded slashes don't trip us up.
    j = i + 1
    in_quote: str | None = None
    while j < n:
        ch = text[j]
        if in_quote:
            if ch == in_quote:
                in_quote = None
        else:
            if ch in '"\'':
                in_quote = ch
            elif ch == ">":
                return (start, j + 1)
        j += 1
    return None


def _extract_xmlns_declarations(xml_bytes: bytes) -> dict[str, str]:
    """Parse the root element's ``xmlns:prefix="..."`` declarations from
    a raw XML byte string. Returns ``{prefix: uri}``.

    Done at the byte level (not via ET) so we capture every namespace
    declared on the source root, including ones ET would later drop
    because no element uses them.
    """
    text = xml_bytes.decode("utf-8", errors="replace")
    span = _find_root_open_tag(text)
    if span is None:
        return {}
    root_open = text[span[0] : span[1]]
    decls: dict[str, str] = {}
    for prefix, uri in _re.findall(
        r'xmlns:([A-Za-z][\w.-]*)="([^"]+)"', root_open,
    ):
        decls[prefix] = uri
    return decls


def _ensure_xmlns_declarations(
    xml_bytes: bytes, required: dict[str, str],
) -> bytes:
    """Ensure every ``prefix → uri`` mapping in ``required`` appears as
    an ``xmlns:prefix="uri"`` attribute on the new root element.

    ET only serializes namespace declarations for prefixes that appear
    in element tags or attribute names. ``mc:Ignorable="w14 w15 w16se …"``
    references prefixes by name — when those prefixes aren't used by
    any element, ET drops them and Word's strict validator surfaces it
    as "unreadable content" on open.

    Re-injects the missing declarations into the root element tag
    via a string-level edit. Idempotent: already-present declarations
    are left alone.
    """
    if not required:
        return xml_bytes
    text = xml_bytes.decode("utf-8", errors="replace")
    span = _find_root_open_tag(text)
    if span is None:
        return xml_bytes
    root_open = text[span[0] : span[1]]
    existing = {
        prefix: uri
        for prefix, uri in _re.findall(
            r'xmlns:([A-Za-z][\w.-]*)="([^"]+)"', root_open,
        )
    }
    additions: list[str] = []
    for prefix, uri in required.items():
        if prefix in existing:
            continue
        additions.append(f'xmlns:{prefix}="{uri}"')
    if not additions:
        return xml_bytes
    # Insert before the closing ``>`` of the root tag.
    insertion_point = span[1] - 1  # before ``>``
    new_text = (
        text[:insertion_point]
        + " "
        + " ".join(additions)
        + text[insertion_point:]
    )
    return new_text.encode("utf-8")


@dataclass(frozen=True)
class CellAddress:
    """OOXML positional address of a cell-inner paragraph.

    ``table_doc_index`` is 0-based across all ``<w:tbl>`` elements
    surfaced by the document's main body story in document order (matches
    the SDK's :attr:`Table._doc_index`). ``row`` and ``col`` are 0-based
    within the table grid (post-merge — ``col`` is the OOXML
    ``<w:tc>`` index, NOT the logical merge-aware grid position).
    ``paragraph_index`` is 0-based within the cell.
    """

    table_doc_index: int
    row: int
    col: int
    paragraph_index: int


@dataclass(frozen=True)
class CellOnlyAddress:
    """OOXML positional address of a cell — without a paragraph index.

    Used for cell-level format ops (shading, borders) that target the
    ``<w:tcPr>`` element rather than a specific ``<w:p>`` inside the
    cell.
    """

    table_doc_index: int
    row: int
    col: int


@dataclass(frozen=True)
class CapturedRefParagraph:
    """A source paragraph whose REF fields would be stripped by a
    round-trip through SuperDoc.

    SuperDoc 1.23.1 / SDK 1.8.1 strips ``REF`` field codes on import
    (verified empirically against the Paul Weiss Purchase Agreement —
    301 REF fields lost on round-trip; see
    ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 18). The
    restoration strategy here is paragraph-wholesale: capture the
    source paragraph's XML on ``Document.create(docx=template)``,
    and on ``Document.export_docx`` replace the corresponding
    exported paragraph in place when its REF count drops. The
    trade-off is that any in-paragraph edits SuperDoc made are lost
    when restoration fires — but for round-trip preservation (the
    primary use case driving this gap), the source paragraph IS the
    source of truth.
    """

    source_paragraph_index: int
    """0-based index among ``<w:p>`` children of ``<w:body>`` in the
    source ``word/document.xml``."""

    paragraph_xml: bytes
    """The serialized ``<w:p>`` element (XML declaration omitted),
    ready to be parsed and substituted on restore."""

    ref_count: int
    """Number of REF field-instructions in this paragraph. The
    restore path replaces the exported paragraph only if its REF
    count is strictly less than ``ref_count`` (so re-runs are
    idempotent and SuperDoc improvements don't trigger pointless
    rewrites)."""

    fingerprint: str
    """First ~60 chars of the source paragraph's plain text content
    (post-REF, so the result text shows). Used as a defensive
    cross-check: if the exported paragraph at
    ``source_paragraph_index`` doesn't fingerprint-match, the
    restoration is skipped to avoid stomping on edited content."""


@dataclass(frozen=True)
class CellHyperlinkOp:
    """A pending cell-inner hyperlink injection.

    SuperDoc 1.8.1 rejects ``CreateHyperlink`` whose target resolves
    to a cell-inner paragraph (BlockNotFoundError, see § 13). The
    SDK now captures the call here and the post-export OOXML rewrite
    appends a real ``<w:hyperlink>`` element (plus a matching rels
    entry for external URLs) at export time.
    """

    text: str
    """Visible link text to inject."""

    url: str
    """Target URL (or empty string for an internal anchor)."""

    fragment: str | None
    """Optional bookmark fragment (anchor portion). ``None`` for plain
    external links. When set, the rendered ``<w:hyperlink>`` uses
    ``w:anchor`` instead of ``r:id`` for internal jumps."""

    tooltip: str | None
    """Optional hover-text Word renders on the link."""


@dataclass
class PostExportOps:
    """Collector for per-asset post-export OOXML rewrites.

    Lives on :class:`docx.client.Session` so every proxy can stash to
    the same instance. :meth:`apply_to_docx` is called once from
    :meth:`docx.document.Document.export_docx` on the bytes returned by
    docx-studio's ``ExportDocx`` command — the entry point for every
    rewrite path.
    """

    _cell_format_ops: dict[CellAddress, dict[str, Any]] = field(default_factory=dict)
    _cell_run_format_ops: dict[CellAddress, dict[str, Any]] = field(default_factory=dict)
    _cell_hyperlink_ops: dict[CellAddress, list[CellHyperlinkOp]] = field(
        default_factory=dict,
    )
    _cell_shading_ops: dict[CellOnlyAddress, dict[str, Any]] = field(default_factory=dict)
    _captured_refs: list[CapturedRefParagraph] = field(default_factory=list)

    def has_pending(self) -> bool:
        return (
            bool(self._cell_format_ops)
            or bool(self._cell_run_format_ops)
            or bool(self._cell_hyperlink_ops)
            or bool(self._cell_shading_ops)
            or bool(self._captured_refs)
        )

    def add_cell_format(
        self,
        address: CellAddress,
        **props: Any,
    ) -> None:
        """Record (or merge into) a pending format-op for one cell-inner paragraph.

        Multiple format ops on the same paragraph (alignment + style +
        spacing) merge into a single rewrite. The last-write-wins for
        identical keys. ``None``-valued props are dropped (clear-ops
        like ``alignment = None`` have no OOXML attribute that
        represents "remove" — Word inherits from the style instead).
        Calls where every prop is ``None`` are no-ops.
        """
        usable = {k: v for k, v in props.items() if v is not None}
        if not usable:
            return
        existing = self._cell_format_ops.setdefault(address, {})
        existing.update(usable)

    def add_cell_run_format(
        self,
        address: CellAddress,
        **props: Any,
    ) -> None:
        """Record (or merge into) a pending run-level format-op for one
        cell-inner paragraph.

        SuperDoc 1.8.1 rejects ``doc.format.apply`` whose target.blockId
        resolves to a paragraph nested inside a ``tableCell`` —
        cell-inner ``run.bold = True`` / ``run.font.size = Pt(11)`` /
        ``run.font.color.rgb = …`` setters silently nuke the
        surrounding batch with ``applied: []`` if forwarded. The SDK
        captures the prop here and the post-export OOXML rewrite
        injects matching ``<w:rPr>`` elements on every ``<w:r>`` inside
        the targeted paragraph at export time.

        Apply-to-all-runs semantics: the rewrite walker sets the props
        on ALL ``<w:r>`` children of the cell paragraph because run
        addressing inside a cell isn't recoverable at OOXML time
        (SuperDoc collapses cell-inner inserts into a single inline
        sequence — see ``_Cell.add_paragraph``). The common cell
        pattern (``cell.text = "Value"; cell.paragraphs[0].runs[0]
        .bold = True``) renders correctly because there's exactly one
        ``<w:r>`` in the exported paragraph. Multi-run cells with
        partial run formatting are a documented limitation — agents
        should use one run per format intent.

        Accepted props (mirrors ``Run._apply_inline`` keys, normalized
        before reaching this method): ``bold``, ``italic``,
        ``underline`` (bool/str), ``strike`` (bool), ``font_name``
        (str), ``font_size_pt`` (number, points), ``font_color_hex``
        (6-digit hex without ``#``), ``font_highlight`` (Word
        highlight color name), ``r_style`` (character style id).
        """
        usable = {k: v for k, v in props.items() if v is not None}
        if not usable:
            return
        existing = self._cell_run_format_ops.setdefault(address, {})
        existing.update(usable)

    def add_cell_hyperlink(
        self,
        address: CellAddress,
        *,
        text: str,
        url: str,
        fragment: str | None = None,
        tooltip: str | None = None,
    ) -> None:
        """Record a pending cell-inner hyperlink injection.

        SuperDoc 1.8.1 rejects ``CreateHyperlink`` whose target resolves
        to a cell-inner paragraph; pre-0.13.0 the SDK dropped both the
        URL AND the link text on the floor. This collector lets the
        post-export OOXML rewrite append a real ``<w:hyperlink>`` plus
        a matching rels entry so the exported ``.docx`` carries both
        the visible text and the clickable link.

        Multiple hyperlinks on the same cell paragraph append in call
        order (each becomes a separate ``<w:hyperlink>`` element).
        """
        if not isinstance(text, str) or not text:
            # The agent's intent was to surface a link; an empty text
            # would produce a hyperlink with no clickable region. Skip
            # rather than emit unrenderable OOXML.
            return
        if not isinstance(url, str) and fragment is None:
            return
        entries = self._cell_hyperlink_ops.setdefault(address, [])
        entries.append(
            CellHyperlinkOp(
                text=text,
                url=url or "",
                fragment=fragment,
                tooltip=tooltip,
            ),
        )

    def add_cell_shading(
        self,
        address: CellOnlyAddress,
        *,
        fill: str | None = None,
        pattern: str | None = None,
        color: str | None = None,
    ) -> None:
        """Record (or merge into) a pending cell-shading op.

        SuperDoc 1.8.1's ``tables.setShading`` accepts the wire call
        but the shading doesn't survive ``doc.save({out})`` —
        ``<w:shd>`` is missing from the exported OOXML. Verified
        empirically against PR #20805 preview (asset_d2e80625): three
        consecutive ``cell.set_shading(fill=...)`` calls returned OK
        but produced 0 ``<w:shd>`` elements in the exported XML.

        Stash here so :meth:`apply_to_docx` can inject the
        ``<w:shd>`` element into the cell's ``<w:tcPr>`` block during
        the post-export rewrite.
        """
        normalized = _normalize_shading_props(
            fill=fill, pattern=pattern, color=color,
        )
        if not normalized:
            return
        existing = self._cell_shading_ops.setdefault(address, {})
        existing.update(normalized)

    def capture_refs_from_template(self, template_bytes: bytes) -> int:
        """Scan ``template_bytes`` (a ``.docx`` zip) for ``<w:p>``
        children that contain at least one ``REF`` field. Stash them
        as :class:`CapturedRefParagraph` entries so a later
        :meth:`apply_to_docx` can restore them when SuperDoc round-trip
        stripping is detected.

        Returns the number of paragraphs captured. Safe to call on
        bytes that don't look like a Word package (returns 0 without
        raising) — common in test paths and for non-template
        ``Document.create()``.
        """
        # Register OOXML namespaces BEFORE the parse + serialize cycle
        # so captured paragraph XML keeps the canonical ``w:``/``w14:``/…
        # prefixes when it gets stitched back into a (possibly
        # differently-bound) exported doc.
        _register_ooxml_namespaces()
        try:
            with zipfile.ZipFile(io.BytesIO(template_bytes), "r") as src:
                xml = src.read("word/document.xml")
        except (zipfile.BadZipFile, KeyError):
            return 0
        try:
            root = ET.fromstring(xml)
        except ET.ParseError:
            return 0
        body = root.find(f"{W_NS}body")
        if body is None:
            return 0
        captured = list(_iter_captured_ref_paragraphs(body))
        # Replace any prior capture wholesale — Document.create is
        # called once per asset, but a defensive replacement ensures
        # re-creates with a fresh template don't pile up stale captures.
        self._captured_refs = captured
        return len(captured)

    def apply_to_docx(self, docx_bytes: bytes) -> bytes:
        """Return ``docx_bytes`` with every recorded rewrite applied.

        ``_convert_section_breaks_to_page_breaks`` always runs (it is
        a blanket export-time conversion — see the function docstring),
        so this method never short-circuits even when the
        per-Document op stashes are empty.
        """
        return _rewrite_word_document_xml(
            docx_bytes,
            cell_format_ops=self._cell_format_ops,
            cell_run_format_ops=self._cell_run_format_ops,
            cell_hyperlink_ops=self._cell_hyperlink_ops,
            cell_shading_ops=self._cell_shading_ops,
            captured_refs=self._captured_refs,
        )


RELATIONSHIPS_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
HYPERLINK_REL_TYPE = (
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink"
)
RELS_NS = f"{{{RELATIONSHIPS_NS}}}"


def _rewrite_word_document_xml(
    docx_bytes: bytes,
    *,
    cell_format_ops: dict[CellAddress, dict[str, Any]],
    cell_run_format_ops: dict[CellAddress, dict[str, Any]],
    cell_hyperlink_ops: dict[CellAddress, list[CellHyperlinkOp]],
    cell_shading_ops: dict[CellOnlyAddress, dict[str, Any]],
    captured_refs: list[CapturedRefParagraph],
) -> bytes:
    """Unzip the ``.docx``, apply rewrites to ``word/document.xml``,
    re-zip and return the result.

    Preserves every other part byte-identical — only the parts we
    actively rewrite get replaced. This matters for fidelity: theme
    files, custom XML, embedded media, etc. all round-trip untouched.

    When ``cell_hyperlink_ops`` is non-empty the rels file
    (``word/_rels/document.xml.rels``) is ALSO rewritten so newly
    injected ``<w:hyperlink r:id="...">`` elements resolve against a
    real ``Relationship`` entry. Word renders a hyperlink as plain
    text (no jump, no styling) when the ``r:id`` doesn't resolve.
    """
    _register_ooxml_namespaces()
    with zipfile.ZipFile(io.BytesIO(docx_bytes), "r") as src:
        try:
            document_xml = src.read("word/document.xml")
        except KeyError:
            return docx_bytes
        try:
            tree = ET.ElementTree(ET.fromstring(document_xml))
        except ET.ParseError:
            return docx_bytes

        body = tree.getroot().find(f"{W_NS}body")
        if body is None:
            return docx_bytes

        # Pre-load the rels file when cell hyperlinks are pending so we
        # can mint new ``rId<N>`` entries. Falls back to ``None`` when
        # no rels file exists (rare — exported SuperDoc bundles always
        # include one) or when the part is unparseable; the hyperlink
        # injector falls back to bookmark/anchor-only links in that
        # case.
        rels_xml_path = "word/_rels/document.xml.rels"
        rels_tree: ET.ElementTree | None = None
        rels_root_local: ET.Element | None = None
        rels_existing: dict[str, str] = {}
        if cell_hyperlink_ops:
            try:
                rels_raw = src.read(rels_xml_path)
            except KeyError:
                rels_raw = None
            if rels_raw is not None:
                try:
                    parsed_rels = ET.fromstring(rels_raw)
                except ET.ParseError:
                    parsed_rels = None
                if parsed_rels is not None:
                    rels_tree = ET.ElementTree(parsed_rels)
                    rels_root_local = parsed_rels
                    rels_existing = _index_existing_hyperlink_rels(parsed_rels)

        if cell_format_ops:
            _apply_cell_format_ops(body, cell_format_ops)

        if cell_run_format_ops:
            _apply_cell_run_format_ops(body, cell_run_format_ops)

        if cell_hyperlink_ops:
            _apply_cell_hyperlink_ops(
                body,
                cell_hyperlink_ops,
                rels_root=rels_root_local,
                rels_existing=rels_existing,
            )

        if cell_shading_ops:
            _apply_cell_shading_ops(body, cell_shading_ops)

        if captured_refs:
            _restore_stripped_refs(body, captured_refs)

        # Always: convert in-paragraph nextPage section breaks into
        # inline page breaks (python-docx-parity output for
        # ``Document.add_page_break`` / ``Run.add_break(WD_BREAK.PAGE)``).
        _convert_section_breaks_to_page_breaks(body)

        # Capture the source root's namespace declarations BEFORE we
        # re-serialize so we can re-inject any that ET drops (it only
        # emits xmlns attrs for prefixes that appear in some element's
        # tag; prefixes referenced from ``mc:Ignorable`` but unused
        # elsewhere get silently dropped, which makes Word's strict
        # validator complain).
        original_xmlns = _extract_xmlns_declarations(document_xml)

        buf = io.BytesIO()
        tree.write(buf, encoding="utf-8", xml_declaration=True)
        new_document_xml = buf.getvalue()
        new_document_xml = _ensure_xmlns_declarations(
            new_document_xml, original_xmlns,
        )

        new_rels_xml: bytes | None = None
        if cell_hyperlink_ops and rels_tree is not None:
            rels_buf = io.BytesIO()
            rels_tree.write(rels_buf, encoding="utf-8", xml_declaration=True)
            new_rels_xml = rels_buf.getvalue()

        out = io.BytesIO()
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
            for info in src.infolist():
                if info.filename == "word/document.xml":
                    dst.writestr(info, new_document_xml)
                elif new_rels_xml is not None and info.filename == rels_xml_path:
                    dst.writestr(info, new_rels_xml)
                else:
                    dst.writestr(info, src.read(info.filename))
        return out.getvalue()


_FINGERPRINT_LEN = 60


def _iter_body_paragraphs(body: ET.Element) -> list[ET.Element]:
    """Return the top-level ``<w:p>`` children of ``<w:body>`` (paragraphs
    inside tables are NOT included — REFs nested in tables are out of
    scope for §18 today)."""
    return body.findall(f"{W_NS}p")


def _paragraph_plain_text(p: ET.Element, *, skip_field_results: bool = False) -> str:
    """Concatenate every ``<w:t>`` text content in document order. Tabs
    and line breaks render as a single space — good enough for
    fingerprint matching.

    When ``skip_field_results=True``, text between ``<w:fldChar
    separate>`` and ``<w:fldChar end>`` is ignored. This makes the
    fingerprint stable across a SuperDoc round-trip that strips REF
    fields (the result text is exactly what disappears on the strip;
    the surrounding "See …" / "… for context." text is what survives).
    """
    parts: list[str] = []
    inside_field_result = 0  # nesting depth — nested fields rare but possible
    for el in p.iter():
        tag = el.tag
        if tag == f"{W_NS}fldChar":
            ftype = el.get(f"{W_NS}fldCharType")
            if ftype == "separate":
                inside_field_result += 1
                continue
            if ftype == "end" and inside_field_result > 0:
                inside_field_result -= 1
                continue
            continue
        if skip_field_results and inside_field_result > 0:
            continue
        if tag == f"{W_NS}t":
            if el.text:
                parts.append(el.text)
        elif tag == f"{W_NS}tab" or tag == f"{W_NS}br":
            parts.append(" ")
    return "".join(parts)


def _paragraph_fingerprint(p: ET.Element) -> str:
    """First N chars of the paragraph's plain-text content (with field
    result runs excluded), lowercased and whitespace-collapsed.

    Skipping field result runs is what makes the source and the
    SuperDoc-stripped versions fingerprint identically — the
    "See REF-result for context." source has the same fingerprint as
    the "See  for context." stripped version once the result text is
    removed from both."""
    text = " ".join(
        _paragraph_plain_text(p, skip_field_results=True).split(),
    ).lower()
    return text[:_FINGERPRINT_LEN]


def _count_ref_fields(p: ET.Element) -> int:
    """Count ``REF`` field-instructions in this paragraph.

    A REF field is identified by an ``<w:instrText>`` whose stripped
    text content STARTS with ``REF`` followed by whitespace (case
    sensitive — Word always emits uppercase ``REF``). This count
    drives the restore decision: only paragraphs whose exported REF
    count is strictly less than the captured count get replaced.

    ``PAGEREF`` and ``REFLINK`` start with ``REF`` too but with no
    space — so the prefix check naturally excludes them. (PAGEREF is
    preserved by SuperDoc already; see § 18.)
    """
    count = 0
    for instr in p.iter(f"{W_NS}instrText"):
        text = (instr.text or "").lstrip()
        # Must be REF followed by whitespace (excludes PAGEREF / REFLINK
        # which share the prefix but no trailing space).
        if text.startswith("REF ") or text.startswith("REF\t"):
            count += 1
    return count


def _iter_captured_ref_paragraphs(
    body: ET.Element,
) -> "Iterable[CapturedRefParagraph]":
    """Yield a :class:`CapturedRefParagraph` for every body paragraph
    that contains 1+ REF fields."""
    for idx, p in enumerate(_iter_body_paragraphs(body)):
        n_refs = _count_ref_fields(p)
        if n_refs == 0:
            continue
        # Strip inter-element whitespace BEFORE capturing. The source
        # template may have been pretty-printed (newlines + indent
        # between ``<w:p>`` and its ``<w:r>`` children); preserving that
        # whitespace as text nodes inside the paragraph makes Word's
        # strict validator flag "unreadable content" because OOXML
        # requires text content inside ``<w:p>`` to live in ``<w:r>``,
        # not as bare text nodes between runs. Strip on a deep copy so
        # the source body itself is untouched.
        clean = _clone_element_stripped(p)
        xml = ET.tostring(clean, encoding="utf-8")
        yield CapturedRefParagraph(
            source_paragraph_index=idx,
            paragraph_xml=xml,
            ref_count=n_refs,
            fingerprint=_paragraph_fingerprint(p),
        )


# OOXML elements whose direct text content IS load-bearing (carry the
# actual visible text) — must NOT be stripped during whitespace
# normalization. Everything else with children is treated as a
# structural element and its ``text``/``tail`` is dropped when whitespace.
_TEXT_CARRYING_TAGS: frozenset[str] = frozenset(
    {
        f"{W_NS}t",
        f"{W_NS}instrText",
        f"{W_NS}delText",
        f"{W_NS}delInstrText",
    },
)


def _clone_element_stripped(el: ET.Element) -> ET.Element:
    """Return a deep copy of ``el`` with whitespace-only ``text`` /
    ``tail`` removed on every non-text-carrying element.

    OOXML schemas reject text content directly inside structural
    elements like ``<w:p>``, ``<w:r>``, ``<w:pPr>``, etc. — content
    must be wrapped in ``<w:r><w:t>...</w:t></w:r>``. Pretty-printed
    source documents include newlines + indent between child elements;
    when ET re-serializes the tree, that whitespace becomes a text
    node attached to the parent element (or as a ``tail`` on a child),
    which Word's strict validator surfaces as "unreadable content."
    """
    import copy

    clone = copy.deepcopy(el)
    _strip_structural_whitespace(clone)
    return clone


def _strip_structural_whitespace(el: ET.Element) -> None:
    """Recursively clear whitespace-only ``text``/``tail`` on every
    non-text-carrying element."""
    if el.tag not in _TEXT_CARRYING_TAGS:
        if el.text is not None and not el.text.strip():
            el.text = None
    for child in el:
        if child.tail is not None and not child.tail.strip():
            # Tail attaches to the PARENT (or previous sibling)'s
            # whitespace — drop if it's purely whitespace AND the parent
            # isn't a text-carrying element.
            if el.tag not in _TEXT_CARRYING_TAGS:
                child.tail = None
        _strip_structural_whitespace(child)


def _restore_stripped_refs(
    body: ET.Element,
    captured: list[CapturedRefParagraph],
) -> None:
    """Walk every captured ref-paragraph; if the exported paragraph at
    the same body-index has a lower REF count AND fingerprint-matches,
    swap the exported ``<w:p>`` element for the captured XML.

    Idempotent: a second call against the already-restored body sees
    the same REF count and no-ops.

    Fail-soft: paragraphs whose fingerprint diverges (user edited the
    paragraph) are skipped silently. Out-of-range indices are skipped
    silently too — SuperDoc rarely reorders body paragraphs, but
    nothing about the rewrite path assumes it never happens.
    """
    paragraphs = _iter_body_paragraphs(body)
    for entry in captured:
        idx = entry.source_paragraph_index
        if idx < 0 or idx >= len(paragraphs):
            continue
        exported = paragraphs[idx]
        if _count_ref_fields(exported) >= entry.ref_count:
            # SuperDoc kept the REFs; nothing to do.
            continue
        if _paragraph_fingerprint(exported) != entry.fingerprint:
            # The paragraph diverged on round-trip — user edited it or
            # SuperDoc materially changed its text. Skip rather than
            # stomp on the edit.
            continue
        restored = ET.fromstring(entry.paragraph_xml)
        # Replace in-place to preserve the paragraph's position in
        # the body's children list.
        body_children = list(body)
        body_position = body_children.index(exported)
        body.remove(exported)
        body.insert(body_position, restored)


def _index_existing_hyperlink_rels(rels_root: ET.Element) -> dict[str, str]:
    """Map ``Target`` URL → ``Id`` for every existing ``Relationship``
    whose ``Type`` is the OOXML hyperlink type.

    Used to coalesce duplicate hyperlinks: when the agent inserts the
    same URL multiple times across cells, every reference shares one
    ``rId``. Word doesn't strictly require coalescing, but it keeps
    the exported rels file readable and avoids unbounded growth.
    """
    out: dict[str, str] = {}
    for rel in rels_root.findall(f"{RELS_NS}Relationship"):
        rel_type = rel.get("Type")
        if rel_type != HYPERLINK_REL_TYPE:
            continue
        rid = rel.get("Id")
        target = rel.get("Target")
        if isinstance(rid, str) and isinstance(target, str):
            out[target] = rid
    return out


def _next_unused_rel_id(rels_root: ET.Element) -> int:
    """Return the next free ``rIdN`` integer suffix.

    Scans every ``Id`` attribute on every ``Relationship`` and returns
    ``max(existing) + 1``. Falls back to ``1`` when no rels exist.
    """
    max_n = 0
    for rel in rels_root.findall(f"{RELS_NS}Relationship"):
        rid = rel.get("Id") or ""
        if rid.startswith("rId"):
            try:
                n = int(rid[3:])
            except ValueError:
                continue
            if n > max_n:
                max_n = n
    return max_n + 1


def _mint_hyperlink_rel(
    rels_root: ET.Element,
    rels_existing: dict[str, str],
    url: str,
) -> str:
    """Return an ``rId`` for ``url``, creating a fresh ``Relationship``
    entry if the URL hasn't been seen before. Idempotent against
    repeated calls for the same URL within one rewrite pass.
    """
    if url in rels_existing:
        return rels_existing[url]
    n = _next_unused_rel_id(rels_root)
    rid = f"rId{n}"
    rel = ET.SubElement(rels_root, f"{RELS_NS}Relationship")
    rel.set("Id", rid)
    rel.set("Type", HYPERLINK_REL_TYPE)
    rel.set("Target", url)
    rel.set("TargetMode", "External")
    rels_existing[url] = rid
    return rid


def _apply_cell_run_format_ops(
    body: ET.Element,
    cell_run_format_ops: dict[CellAddress, dict[str, Any]],
) -> None:
    """Walk every ``<w:tbl>`` in body order; inject ``<w:rPr>`` props
    into every ``<w:r>`` of the targeted ``<w:p>``.

    Apply-to-all-runs semantics: SuperDoc collapses cell-inner inserts
    into a single inline sequence inside the cell's template
    paragraph, so distinguishing which ``<w:r>`` carries which agent
    intent isn't possible after export. The common case — one ``<w:r>``
    per cell paragraph, agent sets bold/size/color once — renders
    correctly. Multi-run cells with partial run formatting are a
    documented limitation.
    """
    tables = body.findall(f"{W_NS}tbl")
    for tbl_idx, tbl in enumerate(tables):
        rows = tbl.findall(f"{W_NS}tr")
        for row_idx, tr in enumerate(rows):
            cells = tr.findall(f"{W_NS}tc")
            for col_idx, tc in enumerate(cells):
                paragraphs = tc.findall(f"{W_NS}p")
                for para_idx, p in enumerate(paragraphs):
                    address = CellAddress(
                        table_doc_index=tbl_idx,
                        row=row_idx,
                        col=col_idx,
                        paragraph_index=para_idx,
                    )
                    props = cell_run_format_ops.get(address)
                    if props is None:
                        continue
                    target = _resolve_cell_format_target(
                        paragraphs, para_idx,
                    )
                    runs = target.findall(f"{W_NS}r")
                    if not runs:
                        continue
                    for r in runs:
                        _apply_run_props(r, props)


def _apply_run_props(r: ET.Element, props: dict[str, Any]) -> None:
    """Inject ``<w:rPr>`` children for each pending run-format prop.

    ``<w:rPr>`` is the first child of ``<w:r>`` (before any ``<w:t>``).
    Existing per-key elements get replaced so the agent's last write
    wins. ``None``-valued props were already filtered out at stash
    time (see :meth:`PostExportOps.add_cell_run_format`).
    """
    rPr = r.find(f"{W_NS}rPr")
    if rPr is None:
        rPr = ET.SubElement(r, f"{W_NS}rPr")
        # Re-order: rPr must come first inside <w:r>.
        r.remove(rPr)
        r.insert(0, rPr)

    if "bold" in props:
        _replace_run_flag(rPr, "b", bool(props["bold"]))
    if "italic" in props:
        _replace_run_flag(rPr, "i", bool(props["italic"]))
    if "strike" in props:
        _replace_run_flag(rPr, "strike", bool(props["strike"]))
    if "underline" in props:
        u_val = props["underline"]
        for existing in rPr.findall(f"{W_NS}u"):
            rPr.remove(existing)
        u_el = ET.SubElement(rPr, f"{W_NS}u")
        u_str = "single" if u_val is True else (
            "none" if u_val is False else str(u_val)
        )
        u_el.set(f"{W_NS}val", u_str)
    if "font_size_pt" in props:
        # OOXML ``<w:sz>`` takes a value in HALF-points; multiply pt by 2.
        try:
            half_pts = int(round(float(props["font_size_pt"]) * 2))
        except (TypeError, ValueError):
            half_pts = None
        if half_pts is not None:
            for existing in rPr.findall(f"{W_NS}sz"):
                rPr.remove(existing)
            for existing in rPr.findall(f"{W_NS}szCs"):
                rPr.remove(existing)
            sz = ET.SubElement(rPr, f"{W_NS}sz")
            sz.set(f"{W_NS}val", str(half_pts))
            sz_cs = ET.SubElement(rPr, f"{W_NS}szCs")
            sz_cs.set(f"{W_NS}val", str(half_pts))
    if "font_color_hex" in props:
        color_str = _coerce_hex_color(str(props["font_color_hex"]))
        for existing in rPr.findall(f"{W_NS}color"):
            rPr.remove(existing)
        col = ET.SubElement(rPr, f"{W_NS}color")
        col.set(f"{W_NS}val", color_str)
    if "font_highlight" in props:
        hl_val = str(props["font_highlight"])
        for existing in rPr.findall(f"{W_NS}highlight"):
            rPr.remove(existing)
        hl = ET.SubElement(rPr, f"{W_NS}highlight")
        hl.set(f"{W_NS}val", hl_val)
    if "font_name" in props:
        name_val = str(props["font_name"])
        for existing in rPr.findall(f"{W_NS}rFonts"):
            rPr.remove(existing)
        rfonts = ET.SubElement(rPr, f"{W_NS}rFonts")
        rfonts.set(f"{W_NS}ascii", name_val)
        rfonts.set(f"{W_NS}hAnsi", name_val)
        rfonts.set(f"{W_NS}cs", name_val)
        rfonts.set(f"{W_NS}eastAsia", name_val)
    if "r_style" in props:
        style_val = str(props["r_style"])
        for existing in rPr.findall(f"{W_NS}rStyle"):
            rPr.remove(existing)
        rs = ET.SubElement(rPr, f"{W_NS}rStyle")
        rs.set(f"{W_NS}val", style_val)


def _replace_run_flag(rPr: ET.Element, local_name: str, enabled: bool) -> None:
    """Toggle a presence-means-true OOXML run flag element.

    ``<w:b/>`` / ``<w:i/>`` / ``<w:strike/>`` follow the same
    presence-means-true pattern. To EXPLICITLY disable an inherited
    bold (e.g. style-level bold the agent wants to override locally),
    emit ``<w:b w:val="0"/>``. Removing the element falls back to the
    style default, which isn't what the agent asked for when they
    explicitly assigned ``False``.
    """
    tag = f"{W_NS}{local_name}"
    for existing in rPr.findall(tag):
        rPr.remove(existing)
    el = ET.SubElement(rPr, tag)
    if not enabled:
        el.set(f"{W_NS}val", "0")


def _apply_cell_hyperlink_ops(
    body: ET.Element,
    cell_hyperlink_ops: dict[CellAddress, list["CellHyperlinkOp"]],
    *,
    rels_root: ET.Element | None,
    rels_existing: dict[str, str],
) -> None:
    """Walk every ``<w:tbl>`` in body order; append a real ``<w:hyperlink>``
    structure (plus a matching rels entry for external links) to the
    targeted cell paragraph.

    Each captured hyperlink renders as:

    .. code-block:: xml

        <w:hyperlink r:id="rIdN" w:tooltip="...">
          <w:r>
            <w:rPr>
              <w:rStyle w:val="Hyperlink"/>
            </w:rPr>
            <w:t>Visible text</w:t>
          </w:r>
        </w:hyperlink>

    The ``<w:rStyle w:val="Hyperlink"/>`` reference gives the text its
    blue + underline appearance via the document's built-in
    ``Hyperlink`` character style. Most templates (including the
    Athena default) ship with it; Word falls back to plain styling
    when the style doesn't resolve.

    Internal-anchor hyperlinks (``fragment != None`` and no ``url``)
    use ``w:anchor`` instead of ``r:id`` and don't add a rels entry.
    """
    tables = body.findall(f"{W_NS}tbl")
    for tbl_idx, tbl in enumerate(tables):
        rows = tbl.findall(f"{W_NS}tr")
        for row_idx, tr in enumerate(rows):
            cells = tr.findall(f"{W_NS}tc")
            for col_idx, tc in enumerate(cells):
                paragraphs = tc.findall(f"{W_NS}p")
                for para_idx, p in enumerate(paragraphs):
                    address = CellAddress(
                        table_doc_index=tbl_idx,
                        row=row_idx,
                        col=col_idx,
                        paragraph_index=para_idx,
                    )
                    pending = cell_hyperlink_ops.get(address)
                    if not pending:
                        continue
                    target = _resolve_cell_format_target(
                        paragraphs, para_idx,
                    )
                    for entry in pending:
                        _append_hyperlink_to_paragraph(
                            target,
                            entry,
                            rels_root=rels_root,
                            rels_existing=rels_existing,
                        )


def _append_hyperlink_to_paragraph(
    p: ET.Element,
    entry: "CellHyperlinkOp",
    *,
    rels_root: ET.Element | None,
    rels_existing: dict[str, str],
) -> None:
    """Append one ``<w:hyperlink>`` child to ``p`` carrying ``entry``."""
    hyperlink = ET.SubElement(p, f"{W_NS}hyperlink")

    if entry.url and rels_root is not None:
        rid = _mint_hyperlink_rel(rels_root, rels_existing, entry.url)
        hyperlink.set(
            "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id",
            rid,
        )
    if entry.fragment:
        hyperlink.set(f"{W_NS}anchor", entry.fragment)
    if entry.tooltip:
        hyperlink.set(f"{W_NS}tooltip", entry.tooltip)

    r = ET.SubElement(hyperlink, f"{W_NS}r")
    rPr = ET.SubElement(r, f"{W_NS}rPr")
    rs = ET.SubElement(rPr, f"{W_NS}rStyle")
    rs.set(f"{W_NS}val", "Hyperlink")
    t = ET.SubElement(r, f"{W_NS}t")
    t.text = entry.text
    if entry.text != entry.text.strip():
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")


def _apply_cell_format_ops(
    body: ET.Element,
    cell_format_ops: dict[CellAddress, dict[str, Any]],
) -> None:
    """Walk every ``<w:tbl>`` in body order; apply format ops to the
    targeted ``<w:p>``.

    Empty-leading-paragraph fix: ``_Cell.text = "X"`` doesn't replace
    the cell's template-default empty paragraph — it ADDS a new
    paragraph with the text, leaving the cell with
    ``[<w:p/>, <w:p><w:r><w:t>X</w:t></w:r></w:p>]``. When the
    agent does ``cell.paragraphs[0].alignment = RIGHT`` they're
    targeting the empty paragraph at index 0, but visually they
    expect the alignment to land on "X" at index 1. The agent's
    intent is "format the cell's first VISIBLE paragraph" — not
    literally "format paragraph index 0."

    Fix: when the targeted ``<w:p>`` is empty (no ``<w:t>`` text
    content), walk forward to the first non-empty ``<w:p>`` in the
    same cell and apply the format ops there instead. Falls back to
    the original target if no non-empty paragraph follows.
    """
    tables = body.findall(f"{W_NS}tbl")
    for tbl_idx, tbl in enumerate(tables):
        rows = tbl.findall(f"{W_NS}tr")
        for row_idx, tr in enumerate(rows):
            cells = tr.findall(f"{W_NS}tc")
            for col_idx, tc in enumerate(cells):
                paragraphs = tc.findall(f"{W_NS}p")
                for para_idx, p in enumerate(paragraphs):
                    address = CellAddress(
                        table_doc_index=tbl_idx,
                        row=row_idx,
                        col=col_idx,
                        paragraph_index=para_idx,
                    )
                    props = cell_format_ops.get(address)
                    if props is None:
                        continue
                    target = _resolve_cell_format_target(
                        paragraphs, para_idx,
                    )
                    _apply_paragraph_props(target, props)


def _paragraph_is_empty(p: ET.Element) -> bool:
    """True when the paragraph has no visible text content
    (no ``<w:t>`` / ``<w:tab>`` / ``<w:br>`` / ``<w:fldChar>`` elements
    that would render in the layout). ``<w:pPr>`` is ignored — a
    paragraph with only paragraph properties is still empty.
    """
    for el in p.iter():
        tag = el.tag
        if tag == f"{W_NS}t":
            if (el.text or "").strip():
                return False
            return False  # empty <w:t> still counts as no visible text
        if tag in (
            f"{W_NS}tab",
            f"{W_NS}br",
            f"{W_NS}fldChar",
            f"{W_NS}drawing",
            f"{W_NS}object",
        ):
            return False
    return True


def _normalize_shading_props(
    *,
    fill: str | None,
    pattern: str | None,
    color: str | None,
) -> dict[str, str]:
    """Coerce ``_Cell.set_shading(fill=..., pattern=..., color=...)``
    args into the OOXML ``<w:shd>`` attribute set
    (``w:val``, ``w:fill``, ``w:color``). Returns an empty dict when
    every input is ``None`` so the caller can no-op cleanly.

    Color normalization mirrors the border path:
    - strip a leading ``#`` (OOXML expects ``F6EBE5``, not ``#F6EBE5``)
    - map ``"auto"`` to the OOXML sentinel ``auto`` (no normalization)
    - leave any other 6-digit hex untouched
    """
    out: dict[str, str] = {}
    if fill is not None:
        out["fill"] = _coerce_hex_color(fill)
    if pattern is not None:
        out["val"] = str(pattern)
    elif fill is not None:
        # ``<w:shd>`` requires ``w:val`` for Word to render; "clear"
        # means "solid fill" (the most common cell-background use case).
        out["val"] = "clear"
    if color is not None:
        out["color"] = _coerce_hex_color(color)
    elif "color" not in out and "fill" in out:
        # ``<w:shd>`` requires ``w:color`` too (the pattern overlay
        # color). ``auto`` defers to Word's theme.
        out["color"] = "auto"
    return out


def _coerce_hex_color(value: str) -> str:
    """Strip a leading ``#`` and pass ``auto``/``none`` through."""
    s = (value or "").strip()
    if not s:
        return "auto"
    if s.lower() in {"auto", "none"}:
        return s.lower()
    return s[1:] if s.startswith("#") else s


def _apply_cell_shading_ops(
    body: ET.Element,
    cell_shading_ops: dict[CellOnlyAddress, dict[str, Any]],
) -> None:
    """Walk every ``<w:tbl>`` in body order; inject ``<w:shd>`` into the
    targeted cell's ``<w:tcPr>``.

    SuperDoc 1.8.1's ``tables.setShading`` wire call accepts the
    request but drops the shading on ``doc.save({out})`` — verified
    against PR #20805 preview: three ``cell.set_shading(fill=...)``
    calls returned OK but produced 0 ``<w:shd>`` in the exported XML.
    This rewrite restores the shading client-side at export time.
    """
    tables = body.findall(f"{W_NS}tbl")
    for tbl_idx, tbl in enumerate(tables):
        rows = tbl.findall(f"{W_NS}tr")
        for row_idx, tr in enumerate(rows):
            cells = tr.findall(f"{W_NS}tc")
            for col_idx, tc in enumerate(cells):
                address = CellOnlyAddress(
                    table_doc_index=tbl_idx,
                    row=row_idx,
                    col=col_idx,
                )
                attrs = cell_shading_ops.get(address)
                if not attrs:
                    continue
                _inject_shd_into_tcPr(tc, attrs)


def _inject_shd_into_tcPr(tc: ET.Element, attrs: dict[str, str]) -> None:
    """Replace any existing ``<w:shd>`` in the cell's ``<w:tcPr>``
    with a fresh one carrying ``attrs``. Creates ``<w:tcPr>`` if missing
    (must be the FIRST child of ``<w:tc>``)."""
    tcPr = tc.find(f"{W_NS}tcPr")
    if tcPr is None:
        tcPr = ET.SubElement(tc, f"{W_NS}tcPr")
        tc.remove(tcPr)
        tc.insert(0, tcPr)
    # Remove any existing shading.
    for existing in tcPr.findall(f"{W_NS}shd"):
        tcPr.remove(existing)
    shd = ET.SubElement(tcPr, f"{W_NS}shd")
    for key, val in attrs.items():
        shd.set(f"{W_NS}{key}", val)


def _convert_section_breaks_to_page_breaks(body: ET.Element) -> None:
    """Convert each in-paragraph ``nextPage`` section break into an
    inline ``<w:br w:type="page"/>``.

    SuperDoc 1.8.1 has no wire op for inline page breaks; both
    :meth:`docx.document.Document.add_page_break` and
    :meth:`docx.text.run.Run.add_break` (with ``WD_BREAK.PAGE``) route
    through ``doc.create.section_break`` with
    ``breakType: "nextPage"``. SuperDoc's export then emits:

    .. code-block:: xml

        <w:p />
        <w:p />
        <w:p>
          <w:pPr>
            <w:sectPr>
              <w:type w:val="nextPage"/>
            </w:sectPr>
          </w:pPr>
        </w:p>

    Two empty anchor paragraphs (the ``add_paragraph("")`` call inside
    ``add_page_break`` plus an extra trailing default paragraph
    SuperDoc inserts before the section-break-bearing paragraph),
    followed by the section break paragraph itself.

    python-docx by contrast emits a single empty paragraph carrying an
    inline page break:

    .. code-block:: xml

        <w:p>
          <w:r>
            <w:br w:type="page"/>
          </w:r>
        </w:p>

    The two shapes are semantically similar (Word starts a new page
    in both cases) but the section-break version has two important
    differences agents trip over:

    1. The extra empty anchor paragraphs take vertical space, so
       a tight section (typical for a 4-page brief built via
       ``add_page_break`` between sections) can spill content onto
       an orphan page just by adding those anchors.
    2. Section breaks define section boundaries; Word may apply
       section-level formatting (different headers, different
       column counts, etc.) when one is present, even though the
       SDK doesn't expose any way to customize the section.

    This rewrite restores python-docx-parity:

    * Each in-paragraph nextPage section break paragraph is rewritten
      to carry an inline page break (``<w:r><w:br w:type="page"/></w:r>``)
      with no ``<w:pPr><w:sectPr>``.
    * The leading empty-anchor paragraphs immediately preceding it
      are removed. "Empty" here means a ``<w:p>`` with no child
      elements at all — typically a self-closing ``<w:p/>`` ET emits
      as ``<w:p />``. Spacer paragraphs that contain an explicit
      ``<w:r><w:t> </w:t></w:r>`` (from ``doc.add_paragraph(" ")``)
      are NOT removed — those are user-intent.

    The document-level final ``<w:sectPr>`` (a DIRECT child of
    ``<w:body>``, not inside a ``<w:pPr>``) is left alone — that's
    the document's default section settings (page size, margins,
    headers), not a break marker. Section breaks of other types
    (``continuous`` / ``evenPage`` / ``oddPage``) are also left
    alone since they have specific intent (column flow,
    left/right-page asymmetry) that an inline page break cannot
    encode.
    """
    # Snapshot the body's <w:p> children up front. We mutate paragraph
    # internals during the loop but defer body-level removals until
    # after — modifying body while iterating it would skip elements.
    paragraphs = [el for el in body if el.tag == f"{W_NS}p"]
    pending_removals: list[ET.Element] = []

    for p in paragraphs:
        pPr = p.find(f"{W_NS}pPr")
        if pPr is None:
            continue
        sectPr = pPr.find(f"{W_NS}sectPr")
        if sectPr is None:
            continue
        type_el = sectPr.find(f"{W_NS}type")
        if type_el is None or type_el.get(f"{W_NS}val") != "nextPage":
            continue

        # Found an in-paragraph nextPage section break. Strip the
        # sectPr (and the wrapping pPr if it's now empty) and append
        # an inline page break run.
        pPr.remove(sectPr)
        if len(pPr) == 0:
            p.remove(pPr)
        r = ET.SubElement(p, f"{W_NS}r")
        br = ET.SubElement(r, f"{W_NS}br")
        br.set(f"{W_NS}type", "page")

        # Walk backward from this paragraph removing the empty-anchor
        # paragraphs ``add_page_break`` injected. Stop at the first
        # non-empty paragraph so user-intent spacers (with text or
        # runs) survive.
        body_children = list(body)
        idx = body_children.index(p)
        for k in range(idx - 1, -1, -1):
            prev = body_children[k]
            if prev.tag != f"{W_NS}p":
                break
            # Anchor paragraphs are completely empty — no children at
            # all (not even <w:pPr>). add_paragraph(" ") spacers have
            # at least one <w:r><w:t> child, so they survive this test.
            if len(prev) > 0:
                break
            pending_removals.append(prev)

    for el in pending_removals:
        body.remove(el)


def _resolve_cell_format_target(
    paragraphs: list[ET.Element], para_idx: int,
) -> ET.Element:
    """Given a list of a cell's ``<w:p>`` children and an agent-recorded
    paragraph index, return the actual paragraph the format ops should
    land on.

    If the targeted paragraph is empty (the common case of
    ``_Cell.text`` appending alongside an empty template-default), walk
    forward to the first non-empty paragraph and apply there instead —
    that matches the agent's likely intent of "format the cell's first
    visible content."

    Falls back to the original targeted paragraph if no non-empty
    paragraph follows.
    """
    targeted = paragraphs[para_idx]
    if not _paragraph_is_empty(targeted):
        return targeted
    for forward in paragraphs[para_idx + 1 :]:
        if not _paragraph_is_empty(forward):
            return forward
    return targeted


def _apply_paragraph_props(p: ET.Element, props: dict[str, Any]) -> None:
    """Inject ``<w:pPr>`` children for each pending format prop.

    Existing ``<w:pPr>`` children of the same kind get replaced (e.g.
    a pending ``alignment=right`` overrides whatever the cell-default
    paragraph had). Missing ``<w:pPr>`` is created as the first child
    of ``<w:p>``.
    """
    pPr = p.find(f"{W_NS}pPr")
    if pPr is None:
        pPr = ET.SubElement(p, f"{W_NS}pPr")
        p.remove(pPr)
        p.insert(0, pPr)

    if "style" in props:
        _replace_child(pPr, "pStyle", {"val": props["style"]})

    if "alignment" in props:
        _replace_child(pPr, "jc", {"val": props["alignment"]})

    ind_attrs: dict[str, str] = {}
    if "left_twips" in props:
        ind_attrs["left"] = str(int(props["left_twips"]))
    if "right_twips" in props:
        ind_attrs["right"] = str(int(props["right_twips"]))
    if "first_line_twips" in props:
        ind_attrs["firstLine"] = str(int(props["first_line_twips"]))
    if "hanging_twips" in props:
        ind_attrs["hanging"] = str(int(props["hanging_twips"]))
    if ind_attrs:
        _merge_child(pPr, "ind", ind_attrs)

    spacing_attrs: dict[str, str] = {}
    if "before_twips" in props:
        spacing_attrs["before"] = str(int(props["before_twips"]))
    if "after_twips" in props:
        spacing_attrs["after"] = str(int(props["after_twips"]))
    if "line_twips" in props:
        spacing_attrs["line"] = str(int(props["line_twips"]))
    if "line_rule" in props:
        spacing_attrs["lineRule"] = str(props["line_rule"])
    if spacing_attrs:
        _merge_child(pPr, "spacing", spacing_attrs)

    if "keep_next" in props:
        _replace_flag(pPr, "keepNext", bool(props["keep_next"]))
    if "keep_lines" in props:
        _replace_flag(pPr, "keepLines", bool(props["keep_lines"]))
    if "page_break_before" in props:
        _replace_flag(pPr, "pageBreakBefore", bool(props["page_break_before"]))
    if "widow_control" in props:
        _replace_flag(
            pPr,
            "widowControl",
            bool(props["widow_control"]),
            zero_val_when_false=True,
        )


def _replace_child(pPr: ET.Element, local_name: str, attrs: dict[str, str]) -> None:
    """Replace (or insert) the single ``<w:{local_name}>`` child with one
    carrying ``attrs`` as ``w:*`` attributes."""
    tag = f"{W_NS}{local_name}"
    for existing in pPr.findall(tag):
        pPr.remove(existing)
    new = ET.SubElement(pPr, tag)
    for k, v in attrs.items():
        new.set(f"{W_NS}{k}", v)


def _merge_child(pPr: ET.Element, local_name: str, attrs: dict[str, str]) -> None:
    """Merge ``attrs`` into the existing ``<w:{local_name}>`` (or create
    one). Unlike :func:`_replace_child`, attributes not in ``attrs`` are
    preserved on the existing element."""
    tag = f"{W_NS}{local_name}"
    existing = pPr.find(tag)
    if existing is None:
        existing = ET.SubElement(pPr, tag)
    for k, v in attrs.items():
        existing.set(f"{W_NS}{k}", v)


def _replace_flag(
    pPr: ET.Element,
    local_name: str,
    enabled: bool,
    *,
    zero_val_when_false: bool = False,
) -> None:
    """Toggle a boolean OOXML flag element.

    Most flags (``keepNext``, ``keepLines``, ``pageBreakBefore``) follow
    the *presence-means-true* pattern — an empty element enables the
    feature, removing the element disables it. ``widowControl`` is
    different: it defaults to enabled, and ``<w:widowControl w:val="0"/>``
    is required to disable it. ``zero_val_when_false`` flips the
    semantics for those.
    """
    tag = f"{W_NS}{local_name}"
    for existing in pPr.findall(tag):
        pPr.remove(existing)
    if enabled:
        ET.SubElement(pPr, tag)
    elif zero_val_when_false:
        elem = ET.SubElement(pPr, tag)
        elem.set(f"{W_NS}val", "0")


def normalize_alignment(value: Any) -> str | None:
    """Convert a python-docx ``WD_ALIGN_PARAGRAPH`` value (or string) to
    the OOXML ``w:jc`` value (``left`` / ``center`` / ``right`` /
    ``both`` / ``distribute``).

    Returns ``None`` for unrecognized inputs so the caller can skip the
    pending op rather than emitting an invalid attribute.
    """
    if value is None:
        return None
    if isinstance(value, str):
        s = value.strip().lower()
        if s in {"left", "start", "leading"}:
            return "left"
        if s in {"center", "centre"}:
            return "center"
        if s in {"right", "end", "trailing"}:
            return "right"
        if s in {"both", "justify", "justified"}:
            return "both"
        if s in {"distribute"}:
            return "distribute"
        return None

    # WD_ALIGN_PARAGRAPH enum values (int-like).
    name = getattr(value, "name", None)
    if isinstance(name, str):
        return normalize_alignment(name)
    try:
        as_int = int(value)
    except (TypeError, ValueError):
        return None
    return _WD_ALIGN_INT_TO_OOXML.get(as_int)


# Mapping derived from python-docx's WD_ALIGN_PARAGRAPH enum (matches
# OOXML w:jc values).
_WD_ALIGN_INT_TO_OOXML: dict[int, str] = {
    0: "left",
    1: "center",
    2: "right",
    3: "both",
    4: "distribute",
}


def normalize_line_rule(value: Any) -> str | None:
    """Convert a python-docx ``WD_LINE_SPACING`` value (or string) to
    the OOXML ``w:lineRule`` value."""
    if value is None:
        return None
    if isinstance(value, str):
        s = value.strip().lower()
        if s in {"auto", "multiple", "single", "1.5 lines", "double"}:
            return "auto"
        if s == "exact" or s == "exactly":
            return "exact"
        if s == "at_least" or s == "atleast" or s == "at-least":
            return "atLeast"
        return None
    name = getattr(value, "name", None)
    if isinstance(name, str):
        return normalize_line_rule(name)
    return None


_EMU_PER_TWIP = 635.0


def to_twips(value: Any) -> int | None:
    """Coerce a python-docx ``Length`` (EMU-backed int) or a number to
    twips. Returns ``None`` for ``None``.

    Mirrors :func:`docx.text.parfmt._to_twips` semantics: ``Length``
    instances use their ``.twips`` property; bare ints/floats are
    treated as raw EMU (python-docx ``Length`` is always EMU under the
    hood).
    """
    if value is None:
        return None
    twips_attr = getattr(value, "twips", None)
    if isinstance(twips_attr, (int, float)):
        return int(twips_attr)
    if isinstance(value, (int, float)):
        return int(float(value) / _EMU_PER_TWIP)
    return None
