"""Text-related enums — python-docx parity (docx.enum.text).

Values map to Superdoc primitives where supported; unmapped values
(e.g. Thai/Arabic justification variants) still parse but serialize to
their best Superdoc equivalent and emit
:class:`PendingEnumCoercionWarning` so the caller knows the wire-level
intent was downgraded.
"""

from __future__ import annotations

import warnings
from enum import Enum


_INT_TO_ALIGN: "dict[int, str]" = {
    0: "LEFT",
    1: "CENTER",
    2: "RIGHT",
    3: "JUSTIFY",
    4: "DISTRIBUTE",
    5: "JUSTIFY_MED",
    7: "JUSTIFY_HI",
    8: "JUSTIFY_LOW",
    9: "THAI_JUSTIFY",
}


class PendingEnumCoercionWarning(UserWarning):
    """Emitted when an enum member's :meth:`to_superdoc` collapses the
    value to a different SuperDoc-supported primitive.

    Examples:
    - ``WD_ALIGN_PARAGRAPH.THAI_JUSTIFY.to_superdoc()`` returns
      ``"justify"`` because SuperDoc 1.8's ``set_alignment`` rejects
      ``thaiJustify``.
    - ``WD_TAB_ALIGNMENT.CLEAR.to_superdoc()`` returns ``"left"``
      because SuperDoc has no equivalent clear/end/num/start tab
      vocabulary.

    Tracked in ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md``. Pin so a
    future SuperDoc that lands the full vocabulary can flip the
    coercion off and these warnings disappear.
    """


def _warn_enum_coercion(enum_member: object, fallback: str) -> None:
    """Emit a single warning identifying which enum member got
    coerced to which SuperDoc primitive."""
    warnings.warn(
        f"{enum_member!r}.to_superdoc() returns {fallback!r} — "
        f"SuperDoc 1.8 doesn't surface this value, so the wire ships "
        f"the closest supported primitive. The visual result may "
        f"differ from python-docx. Tracked in "
        f"docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md.",
        PendingEnumCoercionWarning,
        stacklevel=3,
    )


class WD_ALIGN_PARAGRAPH(Enum):
    """Paragraph alignment (justification)."""

    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"
    JUSTIFY = "justify"
    DISTRIBUTE = "distribute"
    JUSTIFY_MED = "justifyMed"
    JUSTIFY_HI = "justifyHi"
    JUSTIFY_LOW = "justifyLow"
    THAI_JUSTIFY = "thaiJustify"

    @classmethod
    def from_int(cls, value: int) -> "WD_ALIGN_PARAGRAPH | None":
        """Coerce a python-docx-style int alignment to the enum.

        python-docx 1.x's ``WD_ALIGN_PARAGRAPH`` is keyed on int (its
        ``BaseXmlEnum`` mapping: LEFT=0, CENTER=1, RIGHT=2, JUSTIFY=3,
        DISTRIBUTE=4, JUSTIFY_MED=5, JUSTIFY_HI=7, JUSTIFY_LOW=8,
        THAI_JUSTIFY=9). Callers passing ``paragraph.alignment = 1``
        get CENTER. We mirror that without changing our enum's
        string-valued definition.
        """
        name = _INT_TO_ALIGN.get(value)
        return getattr(cls, name) if name is not None else None

    def to_superdoc(self) -> str:
        # Superdoc only supports left/center/right/justify; coerce the
        # distributed/thai variants to "justify" so set_alignment doesn't
        # reject them. Emit PendingEnumCoercionWarning so the caller
        # learns the wire-level intent was downgraded (silently shipping
        # "justify" when the user asked for thaiJustify is the silent
        # stub the parity loop is hunting).
        if self in (
            WD_ALIGN_PARAGRAPH.DISTRIBUTE,
            WD_ALIGN_PARAGRAPH.JUSTIFY_MED,
            WD_ALIGN_PARAGRAPH.JUSTIFY_HI,
            WD_ALIGN_PARAGRAPH.JUSTIFY_LOW,
            WD_ALIGN_PARAGRAPH.THAI_JUSTIFY,
        ):
            _warn_enum_coercion(self, "justify")
            return "justify"
        return self.value

    @classmethod
    def from_superdoc(cls, s: str) -> "WD_ALIGN_PARAGRAPH | None":
        try:
            return cls(s)
        except ValueError:
            pass
        try:
            return cls(s.lower())
        except ValueError:
            return None


class WD_LINE_SPACING(Enum):
    """Line-spacing rule."""

    SINGLE = "single"
    ONE_POINT_FIVE = "onePointFive"
    DOUBLE = "double"
    AT_LEAST = "atLeast"
    EXACTLY = "exactly"
    MULTIPLE = "multiple"

    def to_superdoc(self) -> str:
        # Superdoc's lineRule enum: "auto" | "exact" | "atLeast"
        if self == WD_LINE_SPACING.EXACTLY:
            return "exact"
        if self == WD_LINE_SPACING.AT_LEAST:
            return "atLeast"
        # SINGLE/1.5/DOUBLE/MULTIPLE all map to "auto" with a line value
        return "auto"


class WD_TAB_ALIGNMENT(Enum):
    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"
    DECIMAL = "decimal"
    BAR = "bar"
    LIST = "list"
    CLEAR = "clear"
    END = "end"
    NUM = "num"
    START = "start"

    def to_superdoc(self) -> str:
        # Superdoc only supports left/center/right/decimal/bar for tab
        # alignment. ``LIST`` / ``CLEAR`` / ``END`` / ``NUM`` / ``START``
        # are upstream-only — emit PendingEnumCoercionWarning so callers
        # learn the wire-level intent was downgraded to ``"left"``.
        if self in (
            WD_TAB_ALIGNMENT.LIST,
            WD_TAB_ALIGNMENT.CLEAR,
            WD_TAB_ALIGNMENT.END,
            WD_TAB_ALIGNMENT.NUM,
            WD_TAB_ALIGNMENT.START,
        ):
            _warn_enum_coercion(self, "left")
            return "left"
        return self.value


class WD_TAB_LEADER(Enum):
    SPACES = "none"
    DOTS = "dot"
    DASHES = "hyphen"
    LINES = "underscore"
    HEAVY = "heavy"
    MIDDLE_DOT = "middleDot"

    def to_superdoc(self) -> str:
        return self.value


class WD_BREAK_TYPE(Enum):
    """Break types for ``Run.add_break``.

    The canonical class name in python-docx 1.x is ``WD_BREAK_TYPE``;
    ``WD_BREAK`` is an exported alias used by most callers. We mirror
    that naming so ``repr(WD_BREAK.LINE)`` produces
    ``<WD_BREAK_TYPE.LINE: ...>`` to match python-docx exactly.
    """

    LINE = "line"
    PAGE = "page"
    COLUMN = "column"
    LINE_CLEAR_LEFT = "lineClearLeft"
    LINE_CLEAR_RIGHT = "lineClearRight"
    LINE_CLEAR_ALL = "lineClearAll"
    TEXT_WRAPPING = "textWrapping"
    # python-docx 1.x also exposes section breaks via WD_BREAK
    SECTION_CONTINUOUS = "sectionContinuous"
    SECTION_EVEN_PAGE = "sectionEvenPage"
    SECTION_NEXT_PAGE = "sectionNextPage"
    SECTION_ODD_PAGE = "sectionOddPage"


# python-docx exports both names; the canonical class is WD_BREAK_TYPE
# and WD_BREAK is the alias most user code reaches for.
WD_BREAK = WD_BREAK_TYPE


class WD_UNDERLINE(Enum):
    INHERITED = -1
    NONE = "none"
    SINGLE = "single"
    WORDS = "words"
    DOUBLE = "double"
    DOTTED = "dotted"
    THICK = "thick"
    DASH = "dash"
    DOT_DASH = "dotDash"
    DOT_DOT_DASH = "dotDotDash"
    WAVY = "wavy"
    DOTTED_HEAVY = "dottedHeavy"
    DASH_HEAVY = "dashHeavy"
    DOT_DASH_HEAVY = "dotDashHeavy"
    DOT_DOT_DASH_HEAVY = "dotDotDashHeavy"
    WAVY_HEAVY = "wavyHeavy"
    DASH_LONG = "dashLong"
    DASH_LONG_HEAVY = "dashLongHeavy"
    WAVY_DOUBLE = "wavyDouble"


class WD_COLOR_INDEX(Enum):
    INHERITED = "inherit"
    AUTO = "default"
    BLACK = "black"
    BLUE = "blue"
    BRIGHT_GREEN = "green"
    DARK_BLUE = "darkBlue"
    DARK_RED = "darkRed"
    DARK_YELLOW = "darkYellow"
    GRAY_25 = "lightGray"
    GRAY_50 = "darkGray"
    GREEN = "darkGreen"
    PINK = "magenta"
    RED = "red"
    TEAL = "darkCyan"
    TURQUOISE = "cyan"
    VIOLET = "darkMagenta"
    WHITE = "white"
    YELLOW = "yellow"


# Aliases used by python-docx as well
WD_COLOR = WD_COLOR_INDEX
WD_PARAGRAPH_ALIGNMENT = WD_ALIGN_PARAGRAPH


# python-docx 1.x base class that WD_* enums inherit from — we don't need
# the real base, just a name users can subclass-check against.
class BaseXmlEnum(Enum):
    pass
