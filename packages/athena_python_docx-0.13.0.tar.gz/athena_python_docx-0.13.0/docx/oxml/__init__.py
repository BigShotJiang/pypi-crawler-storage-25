"""Stub package — ``docx.oxml`` is intentionally unavailable in
athena-python-docx.

python-docx upstream exposes raw OOXML element classes (``OxmlElement``,
``CT_*``, ``qn``, ``nsmap``, …) for advanced users who manipulate
Word's XML directly. athena-python-docx is backed by a SuperDoc Y.Doc
+ Keryx pipeline, not a local OOXML tree, so there is no XML element
to manipulate.

Before 0.8.0 attempts to ``from docx.oxml.ns import qn`` failed with
the stdlib's generic ``ModuleNotFoundError: No module named
'docx.oxml'`` — agent code had to discover the gap by retry. 0.8.0
turned this package into a typed stub, but the stub raised
``OxmlNotAvailableError`` on attribute access — which is what
``from docx.oxml.ns import qn`` triggers, so the import statement
itself crashed before any line of the agent's actual logic ran. Common
python-docx convention is to declare ``qn`` / ``OxmlElement`` at the
top of every script "just in case," and that preamble killed scripts
that only used the high-level API.

As of 0.11.3 the stub is **lazy**: ``from docx.oxml.ns import qn``
succeeds and returns a sentinel proxy that defers the typed error
until the symbol is actually called or further-attribute-accessed.
Scripts that import for parity but never use the symbol now run
cleanly; scripts that reach for ``qn("w:tcW")`` still get the
actionable error pointing at the high-level alternative.

The gap is documented in ``docx-studio/python-sdk/CLAUDE.md`` § "Intentionally
omitted" and locked into the parity matrix via
``tests/parity/intentional_deviations.json`` (``docx.oxml**``).
"""

from __future__ import annotations

import sys
import types
from typing import Any


class OxmlNotAvailableError(ImportError):
    """Raised when a ``docx.oxml.*`` symbol is actually used.

    Inherits :class:`ImportError` so callers using
    ``try: from docx.oxml import X / except ImportError`` still match
    after 0.11.3's lazy-stub change (the import itself succeeds, but
    the first call site against the imported name raises this — and
    code that uses ``except ImportError`` around a use-site still
    catches it).

    Use ``except OxmlNotAvailableError`` to distinguish a "no oxml
    surface" miss from a real import-resolution failure or other
    ``ImportError`` cause.

    Note: high-level proxies' ``__getattr__`` paths (``Paragraph._p``,
    ``Run._r``) raise :class:`AttributeError` directly (CPython
    forbids multi-inheritance from both ImportError and AttributeError
    due to C-level instance layout conflicts) — see
    :func:`guard_xml_attr`. The error message points at the same
    high-level alternative this class describes.
    """


_MESSAGE: str = (
    "docx.oxml is not available in athena-python-docx — the SuperDoc "
    "backend doesn't expose raw OOXML elements. Use the high-level "
    "python-docx API (Document.add_paragraph, Run.bold, _Cell.text, …) "
    "or the typed command surface in docx.commands for any mutation "
    "the high-level API doesn't cover. "
    "See docx-studio/python-sdk/CLAUDE.md § 'Intentionally omitted' for "
    "the parity rationale."
)


# Attribute names commonly used by upstream python-docx code to reach
# the raw lxml element backing a proxy: ``Paragraph._p`` (the ``<w:p>``
# element), ``Run._r`` (the ``<w:r>`` element), ``Document.element``,
# ``Paragraph.part`` / ``Run.part`` / ``Document.part`` (the package
# part), etc.
#
# athena-python-docx has no local XML tree — every primitive ships
# through HTTP to docx-studio, which delegates to a SuperDoc Y.Doc.
# Reaching for ``_p`` returns a vanilla ``AttributeError`` from
# Python's default attribute resolution, which doesn't tell the agent
# what to do instead. The high-level proxies surface
# :func:`guard_xml_attr` in their ``__getattr__`` to convert that into
# the typed :class:`OxmlNotAvailableError` with a pointer at the
# high-level API alternative.
_XML_ELEMENT_ATTRS: frozenset[str] = frozenset(
    {
        "_p",          # Paragraph._p
        "_r",          # Run._r
        "_tc",         # _Cell._tc
        "_tbl",        # Table._tbl
        "_tr",         # _Row._tr
        "element",     # Run.element / Paragraph.element / Document.element
        "_element",    # private alias used by some python-docx forks
    },
)

_PART_ATTRS: frozenset[str] = frozenset(
    {
        "part",        # Document.part / Paragraph.part / Run.part
    },
)


def guard_xml_attr(proxy_class: str, name: str) -> None:
    """Raise :class:`AttributeError` for ``_p`` / ``_r`` /
    ``element`` / ``part`` / etc. attribute access on high-level
    proxies, with a message that mirrors
    :class:`OxmlNotAvailableError`'s and points at the high-level
    alternative.

    Returns silently when ``name`` isn't a known XML/part attribute
    (caller continues with the default ``AttributeError`` flow).

    ``proxy_class`` is the proxy's class name (``Paragraph``, ``Run``,
    ``_Cell``, …) — used in the error message so the agent knows
    which symbol triggered the gap.

    Raises :class:`AttributeError` (not :class:`OxmlNotAvailableError`)
    so ``hasattr(p, "_p") is False`` and ``try: paragraph._p except
    AttributeError`` still behave as Python's attribute-resolution
    semantics demand. Inheriting OxmlNotAvailableError from both
    ImportError and AttributeError is rejected by CPython at
    class-creation time (instance layout conflict).
    """
    if name in _XML_ELEMENT_ATTRS:
        raise AttributeError(
            f"{proxy_class}.{name} — athena-python-docx has no local "
            f"OOXML element tree (the SDK is HTTP-only against "
            f"SuperDoc). Use the high-level API on the proxy instead: "
            f"``.text`` to read/write text, ``.add_run()`` / ``.runs`` "
            f"to manipulate runs, ``.paragraph_format`` / ``.style`` "
            f"for paragraph properties, ``.font`` / ``.bold`` etc. on "
            f"runs. See ``python-sdk/CLAUDE.md`` § 'Intentionally "
            f"omitted' for the full list of omitted XML-element "
            f"surface."
        )
    if name in _PART_ATTRS:
        raise AttributeError(
            f"{proxy_class}.{name} — athena-python-docx has no local "
            f"package parts (the SDK targets a SuperDoc Y.Doc, not a "
            f".docx zip). ``Document.core_properties`` and "
            f"``Document.styles`` are the high-level analogues for "
            f"document metadata; ``Document.asset_id`` returns the "
            f"Athena asset identifier."
        )


class _LazyRaisingProxy:
    """Sentinel returned by the ``docx.oxml`` stub for any imported name.

    Behaves as a callable, an attribute-accessible namespace, and an
    awaitable for the union of common python-docx patterns:

    * ``from docx.oxml.ns import qn`` → ``qn`` is a _LazyRaisingProxy.
      Just importing it is a no-op. ``qn("w:tcW")`` raises with the
      educated message.
    * ``from docx.oxml import OxmlElement`` → same. ``OxmlElement(...)``
      raises; ``OxmlElement.something`` raises.
    * ``isinstance(x, OxmlElement)`` → raises Python's native
      ``TypeError: isinstance() arg 2 must be a type, a tuple of
      types, or a union`` (CPython validates the second argument is a
      type before consulting ``__instancecheck__``, so the proxy never
      sees the call). Agents who reach for it land in the same
      "this surface isn't real" place via a different error class —
      the message names ``isinstance`` so the typed
      :class:`OxmlNotAvailableError` route isn't required to surface
      the gap.

    The proxy carries the full dotted path so the error message points
    at exactly the offending symbol — ``docx.oxml.ns.qn`` rather than a
    generic "docx.oxml".
    """

    __slots__ = ("_path",)

    def __init__(self, path: str) -> None:
        # Bypass __setattr__ guard.
        object.__setattr__(self, "_path", path)

    def _raise(self, suffix: str = "") -> None:
        path = object.__getattribute__(self, "_path")
        target = f"{path}{suffix}" if suffix else path
        raise OxmlNotAvailableError(f"{target} — {_MESSAGE}")

    def __call__(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ANN401
        self._raise()

    def __getattr__(self, name: str) -> Any:  # noqa: ANN401
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)
        self._raise(f".{name}")

    def __setattr__(self, name: str, value: Any) -> None:  # noqa: ANN401
        # Block writes to the proxy so agents that try
        # ``OxmlElement.tag = "..."`` get the typed error rather than a
        # silent attribute set on the sentinel.
        if name == "_path":
            object.__setattr__(self, name, value)
            return
        self._raise(f".{name}")

    def __repr__(self) -> str:
        path = object.__getattribute__(self, "_path")
        return f"<docx.oxml lazy stub {path!r} — call to raise>"


class _OxmlStubModule(types.ModuleType):
    """ModuleType subclass that returns :class:`_LazyRaisingProxy`
    sentinels for any attribute access.

    Installed into :data:`sys.modules` at package-init time so
    qualified imports like ``from docx.oxml.ns import qn`` find a real
    module object (avoiding ``ModuleNotFoundError``). The proxy
    returned defers the typed error until the symbol is actually
    invoked, letting top-level python-docx import blocks succeed.

    No ``__slots__`` — ``types.ModuleType`` itself carries a
    ``__dict__``, so a slots declaration on a subclass is a no-op.
    """

    def __getattr__(self, name: str) -> Any:  # noqa: ANN401
        if name.startswith("__") and name.endswith("__"):
            # Dunder access (e.g. ``__path__`` during submodule import)
            # must fall through to AttributeError so Python's import
            # machinery can probe without triggering our typed error.
            raise AttributeError(name)
        path = self.__name__
        proxy = _LazyRaisingProxy(f"{path}.{name}")
        # Cache so repeated `getattr` returns the same proxy and so
        # `from X import Y` followed by another `from X import Y`
        # gives the same instance.
        object.__setattr__(self, name, proxy)
        return proxy


# Common upstream submodule paths. Listed explicitly rather than wild-
# carded so adding a new one is a visible diff. Every entry maps to a
# single sentinel module; no per-submodule state.
_SUBMODULES: tuple[str, ...] = (
    "ns",
    "parser",
    "element",
    "xmlchemy",
    "exceptions",
    "ooxml",
    "coreprops",
    "document",
    "text",
    "table",
    "comments",
    "header_footer",
    "footnote",
    "endnote",
    "shared",
    "shape",
    "section",
    "settings",
    "styles",
    "numbering",
)


def _install_stub_submodules() -> None:
    """Pre-populate :data:`sys.modules` with stub entries for every
    well-known ``docx.oxml.*`` submodule.

    Idempotent — re-running is a no-op for entries already installed
    (covers the rare case of a test that reloads the package).
    """
    for short in _SUBMODULES:
        full = f"docx.oxml.{short}"
        if full in sys.modules:
            continue
        sys.modules[full] = _OxmlStubModule(full)


_install_stub_submodules()


def __getattr__(name: str) -> Any:  # noqa: ANN401
    """PEP 562 attribute hook for ``from docx.oxml import X``.

    Submodule names (handled via :data:`sys.modules` injection in
    :func:`_install_stub_submodules`) and dunder names fall through
    normally. Everything else returns a :class:`_LazyRaisingProxy` so
    the import succeeds and the typed error fires only on actual use.

    The proxy is cached into module globals so a second access skips
    ``__getattr__`` and returns the same instance — matches the
    per-submodule caching done by :meth:`_OxmlStubModule.__getattr__`.
    """
    if name.startswith("__") and name.endswith("__"):
        raise AttributeError(name)
    if name in _SUBMODULES:
        # Should already be present in sys.modules; defensive fallback
        # so we never leak ModuleNotFoundError if the caller reloaded
        # the package between calls.
        full = f"docx.oxml.{name}"
        mod = sys.modules.get(full)
        if mod is None:
            mod = _OxmlStubModule(full)
            sys.modules[full] = mod
        return mod
    proxy = _LazyRaisingProxy(f"docx.oxml.{name}")
    globals()[name] = proxy
    return proxy


__all__ = ["OxmlNotAvailableError"]
