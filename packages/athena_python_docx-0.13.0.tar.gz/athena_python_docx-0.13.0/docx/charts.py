"""Charts — Athena extension beyond python-docx 1.x.

python-docx surfaces :attr:`InlineShape.chart` but has no add or data-
edit API. Issues #179 (add charts, 12 👍) and #1141 (edit data) demand
both. SuperDoc embeds ``chart.xml`` + a small workbook part; the
Python SDK ships only the data + chart-type contract.

Supported chart families:

* ``"bar"``, ``"column"`` — bar/column (stacked / percent-stacked / clustered)
* ``"line"``, ``"area"`` — line / area (stacked variants)
* ``"pie"``, ``"doughnut"`` — pie / doughnut
* ``"scatter"`` — XY scatter
* ``"radar"``, ``"surface"``, ``"stock"``, ``"bubble"``
* ``"combo"`` — multi-type chart (one type per series)
* ``"waterfall"``, ``"funnel"``, ``"treemap"``, ``"sunburst"``,
  ``"histogram"``, ``"box_whisker"`` — Word 2016+ chart families

See ``python-sdk/CLAUDE.md`` § *Intentional deviations (additions /
different semantics)*.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Iterator

from docx._athena_extension import athena_extension
from docx._batching import run_sync

__athena_extension_module__: bool = True
__athena_extension_issue__: str = "python-docx#179"
__athena_extension_description__: str = "Charts — add, edit data, swap type."
__athena_extension_since__: str = "0.11.0"

if TYPE_CHECKING:
    from docx.client import Session


@athena_extension(issue=179, description="One chart proxy.")
class Chart:
    """One chart embedded in the document."""

    def __init__(
        self,
        *,
        session: "Session",
        chart_id: str,
        chart_type: str = "column",
        data: list[list[Any]] | None = None,
        title: str | None = None,
    ) -> None:
        self._session: "Session" = session
        self._chart_id: str = chart_id
        self._chart_type: str = chart_type
        self._data: list[list[Any]] = data or []
        self._title: str | None = title

    @property
    def chart_id(self) -> str:
        return self._chart_id

    @property
    def chart_type(self) -> str:
        return self._chart_type

    @chart_type.setter
    def chart_type(self, value: str) -> None:
        from docx.commands import SetChartType

        run_sync(
            self._session.send_command(
                SetChartType(chart_id=self._chart_id, chart_type=value),
            ),
        )
        self._chart_type = value

    @property
    def data(self) -> list[list[Any]]:
        return [list(row) for row in self._data]

    @data.setter
    def data(self, value: list[list[Any]]) -> None:
        from docx.commands import SetChartData

        run_sync(
            self._session.send_command(
                SetChartData(chart_id=self._chart_id, data=value),
            ),
        )
        self._data = [list(row) for row in value]

    @property
    def title(self) -> str | None:
        return self._title


@athena_extension(issue=179, description="Collection of charts.")
class Charts:
    """Collection of charts in the document."""

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self) -> list[dict]:
        from docx.commands import ChartsList

        result = run_sync(self._session.send_command(ChartsList()))
        if isinstance(result, dict):
            items = result.get("items") or result.get("charts") or []
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        elif isinstance(result, list):
            return [i for i in result if isinstance(i, dict)]
        return []

    def __iter__(self) -> Iterator[Chart]:
        for info in self._items():
            yield self._wrap(info)

    def __len__(self) -> int:
        return len(self._items())

    def __getitem__(self, index: int) -> Chart:
        return self._wrap(self._items()[index])

    def get(self, chart_id: str) -> Chart | None:
        for info in self._items():
            if info.get("id") == chart_id or info.get("chartId") == chart_id:
                return self._wrap(info)
        return None

    def _wrap(self, info: dict) -> Chart:
        return Chart(
            session=self._session,
            chart_id=str(info.get("id") or info.get("chartId") or ""),
            chart_type=str(info.get("chartType") or info.get("type") or "column"),
            data=info.get("data") if isinstance(info.get("data"), list) else None,
            title=info.get("title") if isinstance(info.get("title"), str) else None,
        )


__all__ = ["Chart", "Charts"]
