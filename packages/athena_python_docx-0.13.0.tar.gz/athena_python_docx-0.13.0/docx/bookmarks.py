"""Bookmarks — Athena extension beyond python-docx 1.x.

python-docx upstream has no bookmark API. Bookmarks are anchor points
in the document referenced by hyperlinks (``#name``), cross-references
(REF fields), TOC entries, and captions. Each bookmark has a unique
name and a start/end anchor pair. Issue #425 has been open since 2017.

See ``python-sdk/CLAUDE.md`` § *Intentional deviations (additions /
different semantics)*.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Iterator

from docx._athena_extension import athena_extension
from docx._batching import run_sync

# Module-level marker — entire module is an Athena extension.
__athena_extension_module__: bool = True
__athena_extension_issue__: str = "python-docx#425"
__athena_extension_description__: str = (
    "Bookmarks — named anchor points referenced by hyperlinks, "
    "cross-references, TOC entries, and captions."
)
__athena_extension_since__: str = "0.11.0"

if TYPE_CHECKING:
    from docx.client import Session


@athena_extension(issue=425, description="One named bookmark.")
class Bookmark:
    """One named bookmark. Read-only proxy.

    Bookmarks can wrap a range or be zero-width anchors. Word allows
    overlapping bookmarks; the SDK exposes each as a separate
    ``Bookmark`` instance.
    """

    def __init__(
        self,
        *,
        session: "Session",
        bookmark_id: str,
        name: str,
        target: dict | None = None,
    ) -> None:
        self._session: "Session" = session
        self._bookmark_id: str = bookmark_id
        self._name: str = name
        self._target: dict = target or {}

    @property
    def bookmark_id(self) -> str:
        return self._bookmark_id

    @property
    def name(self) -> str:
        return self._name

    @property
    def target(self) -> dict:
        """Where the bookmark is anchored. The shape mirrors SuperDoc's
        ``{kind: "text", blockId, range: {start, end}}`` for ranges and
        ``{kind: "text", blockId, offset}`` for collapsed anchors."""
        return dict(self._target)

    def delete(self) -> None:
        """Remove the bookmark (the wrapped content is preserved)."""
        from docx.commands import DeleteBookmark

        run_sync(
            self._session.send_command(DeleteBookmark(id=self._bookmark_id)),
        )


@athena_extension(issue=425, description="Collection of bookmarks.")
class Bookmarks:
    """Collection of bookmarks in the document.

    Accessed via :attr:`docx.document.Document.bookmarks`. Use
    :meth:`add` to create a new bookmark wrapping a paragraph or
    paragraph range; for zero-width anchors at a paragraph end, use
    :meth:`docx.text.paragraph.Paragraph.add_bookmark`.
    """

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(self) -> list[dict]:
        from docx.commands import BookmarksList

        result = run_sync(self._session.send_command(BookmarksList()))
        if isinstance(result, dict):
            items = result.get("items") or result.get("bookmarks") or []
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        elif isinstance(result, list):
            return [i for i in result if isinstance(i, dict)]
        return []

    def __iter__(self) -> Iterator[Bookmark]:
        for info in self._items():
            yield self._wrap(info)

    def __len__(self) -> int:
        return len(self._items())

    def __getitem__(self, index_or_name: int | str) -> Bookmark:
        if isinstance(index_or_name, str):
            for info in self._items():
                if info.get("name") == index_or_name:
                    return self._wrap(info)
            raise KeyError(f"No bookmark named {index_or_name!r}")
        return self._wrap(self._items()[index_or_name])

    def __contains__(self, name: object) -> bool:
        if not isinstance(name, str):
            return False
        return any(info.get("name") == name for info in self._items())

    def get(self, name: str) -> Bookmark | None:
        """Find a bookmark by name."""
        from docx.commands import BookmarksGet

        result = run_sync(
            self._session.send_command(BookmarksGet(name=name)),
        )
        if isinstance(result, dict) and (result.get("id") or result.get("bookmarkId")):
            return self._wrap(result)
        return None

    def add(
        self,
        name: str,
        *,
        paragraph: object | None = None,
        run: object | None = None,
    ) -> Bookmark:
        """Create a new bookmark.

        If ``paragraph`` is given the bookmark wraps that paragraph's
        full text range; if ``run`` is given it wraps the run's range;
        otherwise the bookmark anchors at document end (zero-width).
        """
        from docx.commands import CreateBookmark

        cmd_kwargs: dict = {"name": name}
        if run is not None:
            block_id = getattr(run, "_block_id", None)
            range_ = getattr(run, "_range", None)
            if block_id and range_:
                cmd_kwargs["target"] = {
                    "kind": "text",
                    "blockId": block_id,
                    "range": {"start": range_[0], "end": range_[1]},
                }
        elif paragraph is not None:
            block_id = getattr(paragraph, "_node_id", None)
            if block_id:
                resolve = getattr(paragraph, "_resolve_text_len", None)
                length = resolve() if callable(resolve) else 0
                cmd_kwargs["target"] = {
                    "kind": "text",
                    "blockId": block_id,
                    "range": {"start": 0, "end": length},
                }
        else:
            cmd_kwargs["at"] = {"kind": "documentEnd"}

        result = run_sync(
            self._session.send_command(CreateBookmark(**cmd_kwargs)),
        )
        bookmark_id = ""
        if isinstance(result, dict):
            bookmark_id = str(result.get("id") or result.get("bookmarkId") or "")
        return Bookmark(
            session=self._session,
            bookmark_id=bookmark_id,
            name=name,
            target=cmd_kwargs.get("target", {}),
        )

    def _wrap(self, info: dict) -> Bookmark:
        return Bookmark(
            session=self._session,
            bookmark_id=str(info.get("id") or info.get("bookmarkId") or ""),
            name=str(info.get("name") or ""),
            target=info.get("target") if isinstance(info.get("target"), dict) else None,
        )


__all__ = ["Bookmark", "Bookmarks"]
