"""Marker decorator + audit helpers for Athena extensions beyond
python-docx 1.x.

This SDK MUST be a 1:1 replica of python-docx (see ``CLAUDE.md`` § *API
Parity Rule*). Anything that is NOT in upstream python-docx is an
**Athena extension** and must be:

1. Documented in ``CLAUDE.md`` § *Intentional deviations (additions /
   different semantics)* — for the human-readable rationale.
2. Marked at runtime with :func:`athena_extension` — so introspection
   tooling (parity audits, docs generation, IDE plugins) can identify
   the addition without grepping prose, and so the
   :func:`iter_athena_extensions` walker can enumerate every addition
   in one place.

The decorator stamps the wrapped object with introspectable attributes:

* ``__athena_extension__`` — always ``True``
* ``__athena_extension_issue__`` — upstream python-docx issue ref, e.g.
  ``"python-docx#74"``
* ``__athena_extension_description__`` — one-line summary
* ``__athena_extension_since__`` — athena-python-docx SDK version that
  introduced the surface

Apply at every Athena-extension layer:

* **Class** — decorator on the ``class`` statement::

    @athena_extension(issue=1, description="Footnote proxy")
    class Footnote: ...

* **Method / function** — decorator on the ``def`` statement::

    @athena_extension(issue=74, description="Paragraph.add_hyperlink")
    def add_hyperlink(self, ...): ...

* **Property** — decorator on the **getter** (before ``@property``)::

    @property
    @athena_extension(issue=471)
    def list_id(self): ...

  When the property has a setter, mark the setter's underlying function
  too (so writes are auditable independently of reads)::

    @list_id.setter
    @athena_extension(issue=471)
    def list_id(self, value): ...

* **Module-level constant** — for whole modules that are entirely
  Athena extensions, set at top of file::

    __athena_extension_module__ = True
    __athena_extension_issue__ = "python-docx#1"
    __athena_extension_description__ = "Footnotes / Endnotes"

  The walker picks these up alongside per-member markers.

The decorator is import-time-cheap, has no runtime overhead at call
sites (it returns the original object after stamping), and never
modifies docstrings or signatures. The introspectable attributes are
parity-neutral — the upstream-vs-athena comparator in
``tests/parity/compare.py`` only looks at signatures + kinds, not at
function ``__dict__`` keys.
"""

from __future__ import annotations

import importlib
import pkgutil
from typing import Any, Callable, Iterator, TypeVar


# Attribute names — kept as module constants so audits and tests can
# reference them without re-typing the string everywhere.
ATHENA_EXTENSION_ATTR: str = "__athena_extension__"
ATHENA_EXTENSION_ISSUE_ATTR: str = "__athena_extension_issue__"
ATHENA_EXTENSION_DESCRIPTION_ATTR: str = "__athena_extension_description__"
ATHENA_EXTENSION_SINCE_ATTR: str = "__athena_extension_since__"

ATHENA_EXTENSION_MODULE_ATTR: str = "__athena_extension_module__"

# Default ``since`` value — overridable per-marker. Bumped when a new
# wave of additions lands; pre-existing extensions (Document.create,
# Document.revisions, etc.) carry their original since values.
_DEFAULT_SINCE: str = "0.11.0"


T = TypeVar("T")


def athena_extension(
    *,
    issue: int | str | None = None,
    description: str = "",
    since: str = _DEFAULT_SINCE,
) -> Callable[[T], T]:
    """Decorator that marks a class / function / method as an Athena
    extension beyond python-docx 1.x.

    Stamps four introspectable attributes on the wrapped object:

    - ``__athena_extension__`` — always ``True``
    - ``__athena_extension_issue__`` — ``"python-docx#<n>"`` when
      ``issue`` is an int; passed through verbatim when a string;
      ``None`` when omitted
    - ``__athena_extension_description__`` — ``description``
    - ``__athena_extension_since__`` — ``since``

    Returns the original object unchanged (apart from the new
    attributes), so call sites pay zero runtime cost.

    Args:
        issue: python-docx upstream issue / PR number that this
            extension addresses. ``int`` (e.g. ``74``) is auto-formatted
            as ``"python-docx#74"``; ``str`` is used verbatim.
        description: One-line human summary. Optional but recommended
            for non-obvious additions.
        since: The athena-python-docx SDK version that first shipped
            this surface. Defaults to the current default-since
            (``0.11.0``).

    Example::

        @athena_extension(issue=74, description="Add hyperlink (closes issue #74)")
        def add_hyperlink(self, text, address, *, fragment=None, tooltip=None):
            ...

    For properties, decorate the underlying getter (and setter) BEFORE
    ``@property`` so the markers stick to ``prop.fget`` /
    ``prop.fset``::

        @property
        @athena_extension(issue=471)
        def list_id(self): ...
    """
    issue_value: str | None
    if issue is None:
        issue_value = None
    elif isinstance(issue, int):
        issue_value = f"python-docx#{issue}"
    else:
        issue_value = str(issue)

    def decorator(obj: T) -> T:
        # ``setattr`` instead of ``obj.__athena_extension__ = …`` so the
        # decorator works on classes, plain functions, lambdas, and any
        # object whose namespace accepts attribute assignment. Built-in
        # ``property`` descriptors don't (which is why callers must
        # decorate the underlying getter, not the property itself).
        try:
            setattr(obj, ATHENA_EXTENSION_ATTR, True)
            if issue_value is not None:
                setattr(obj, ATHENA_EXTENSION_ISSUE_ATTR, issue_value)
            if description:
                setattr(obj, ATHENA_EXTENSION_DESCRIPTION_ATTR, description)
            setattr(obj, ATHENA_EXTENSION_SINCE_ATTR, since)
        except (AttributeError, TypeError):
            # E.g. someone applied the decorator directly to a
            # ``property`` object (which rejects setattr). Re-raise with
            # a hint so the fix is obvious.
            raise TypeError(
                f"@athena_extension cannot be applied to "
                f"{type(obj).__name__} — built-in descriptor rejects "
                f"setattr. For properties, decorate the underlying "
                f"getter/setter function BEFORE @property:\n\n"
                f"    @property\n"
                f"    @athena_extension(...)\n"
                f"    def my_prop(self): ...\n",
            )
        return obj

    return decorator


def is_athena_extension(obj: Any) -> bool:
    """Return ``True`` if ``obj`` is marked as an Athena extension.

    Handles the property-wrapping case: a ``property`` descriptor
    proxies to its ``fget`` (and ``fset``) — either marker counts.
    """
    if getattr(obj, ATHENA_EXTENSION_ATTR, False):
        return True
    if isinstance(obj, property):
        if obj.fget is not None and getattr(obj.fget, ATHENA_EXTENSION_ATTR, False):
            return True
        if obj.fset is not None and getattr(obj.fset, ATHENA_EXTENSION_ATTR, False):
            return True
    return False


def athena_extension_metadata(obj: Any) -> dict[str, Any] | None:
    """Return a dict of marker attributes for ``obj``, or ``None`` if
    it isn't an Athena extension."""
    target: Any = obj
    if isinstance(obj, property):
        if obj.fget is not None and getattr(obj.fget, ATHENA_EXTENSION_ATTR, False):
            target = obj.fget
        elif obj.fset is not None and getattr(obj.fset, ATHENA_EXTENSION_ATTR, False):
            target = obj.fset
        else:
            return None
    if not getattr(target, ATHENA_EXTENSION_ATTR, False):
        return None
    return {
        "issue": getattr(target, ATHENA_EXTENSION_ISSUE_ATTR, None),
        "description": getattr(target, ATHENA_EXTENSION_DESCRIPTION_ATTR, ""),
        "since": getattr(target, ATHENA_EXTENSION_SINCE_ATTR, None),
    }


# Module-level helpers should NOT pull these in transitively at SDK
# import time — keep the walker lazy.
def iter_athena_extensions(package: str = "docx") -> Iterator[dict[str, Any]]:
    """Walk every submodule of ``package`` and yield one record per
    Athena extension found.

    Records have shape::

        {
            "kind": "module" | "class" | "function" | "method" |
                    "property" | "command",
            "location": "docx.bookmarks.Bookmarks.add",
            "issue": "python-docx#74",
            "description": "Append a hyperlinked text run",
            "since": "0.11.0",
        }

    The walker:

    * Imports every module under ``package`` (it tolerates import
      errors gracefully — a broken module is skipped, not fatal).
    * Yields a ``"module"`` record for any submodule with
      ``__athena_extension_module__ = True`` at module scope.
    * Yields one record per top-level callable / class with the
      marker.
    * For each marked class, walks the class body and yields a
      ``"method"`` / ``"property"`` record per marked member.

    Used by ``tests/test_athena_extensions_registry.py`` to verify
    coverage stays in sync with the surfaces documented in CLAUDE.md.
    """
    try:
        root = importlib.import_module(package)
    except ImportError:
        return

    # The root package itself may carry the module-level marker.
    if getattr(root, ATHENA_EXTENSION_MODULE_ATTR, False):
        yield {
            "kind": "module",
            "location": package,
            "issue": getattr(root, ATHENA_EXTENSION_ISSUE_ATTR, None),
            "description": getattr(root, ATHENA_EXTENSION_DESCRIPTION_ATTR, ""),
            "since": getattr(root, ATHENA_EXTENSION_SINCE_ATTR, None),
        }
    yield from _iter_module_members(root, package)

    if not hasattr(root, "__path__"):
        return

    for _finder, sub_name, _ispkg in pkgutil.walk_packages(
        root.__path__, prefix=f"{package}.",
    ):
        try:
            sub = importlib.import_module(sub_name)
        except Exception:  # noqa: BLE001 — broken submodule, skip.
            continue
        if getattr(sub, ATHENA_EXTENSION_MODULE_ATTR, False):
            yield {
                "kind": "module",
                "location": sub_name,
                "issue": getattr(sub, ATHENA_EXTENSION_ISSUE_ATTR, None),
                "description": getattr(sub, ATHENA_EXTENSION_DESCRIPTION_ATTR, ""),
                "since": getattr(sub, ATHENA_EXTENSION_SINCE_ATTR, None),
            }
        yield from _iter_module_members(sub, sub_name)


def _iter_module_members(
    module: Any, module_name: str,
) -> Iterator[dict[str, Any]]:
    """Walk ``vars(module)`` and yield extension records for top-level
    callables / classes. For each class, recurse into its members.

    Underscore-prefixed *classes* (``_Cell``, ``_Row``, ``_Column``,
    ``_NoteBase``, etc.) ARE walked — python-docx uses leading-
    underscore class names for collection types that are part of the
    public API. Underscore-prefixed *functions* / module attrs are
    treated as private and skipped.
    """
    seen_classes: set[int] = set()
    for attr_name, attr in vars(module).items():
        is_class = isinstance(attr, type)
        if attr_name.startswith("_") and not is_class:
            continue
        # Top-level marked function / dataclass.
        if (
            not is_class
            and getattr(attr, ATHENA_EXTENSION_ATTR, False)
        ):
            kind = "command" if attr_name[0:1].isupper() else "function"
            meta = athena_extension_metadata(attr) or {}
            yield {
                "kind": kind,
                "location": f"{module_name}.{attr_name}",
                **meta,
            }
        # Class: emit the class record (if marked) then recurse.
        if is_class:
            qual = getattr(attr, "__qualname__", attr_name)
            mod_of_class = getattr(attr, "__module__", "")
            # Skip re-exports — only emit the canonical definition's
            # members. (E.g. ``docx.shape.Picture`` is re-exported from
            # ``docx.shape``; emit once.)
            if mod_of_class and mod_of_class != module_name:
                continue
            if id(attr) in seen_classes:
                continue
            seen_classes.add(id(attr))
            if getattr(attr, ATHENA_EXTENSION_ATTR, False):
                meta = athena_extension_metadata(attr) or {}
                yield {
                    "kind": "class",
                    "location": f"{module_name}.{qual}",
                    **meta,
                }
            yield from _iter_class_members(attr, module_name, qual)


def _iter_class_members(
    cls: type, module_name: str, class_qualname: str,
) -> Iterator[dict[str, Any]]:
    """Yield records for marked methods / properties on ``cls``.

    Handles three wrapped-callable cases the bare
    ``getattr(member, ATTR, False)`` check would miss:

    * ``property`` — read marker from ``fget`` / ``fset``.
    * ``classmethod`` — marker lives on ``__func__``.
    * ``staticmethod`` — marker lives on ``__func__``.
    """
    for member_name, member in vars(cls).items():
        if member_name.startswith("_"):
            continue
        # Peek into classmethod / staticmethod descriptors — the
        # decorator wraps the underlying function, so the marker
        # attribute lives on ``descriptor.__func__``.
        probe: Any = member
        if isinstance(member, (classmethod, staticmethod)):
            probe = member.__func__
        meta = athena_extension_metadata(probe)
        if meta is None and probe is not member:
            # Fall back to checking the descriptor itself (covers any
            # marker explicitly applied to the wrapper).
            meta = athena_extension_metadata(member)
        if meta is None:
            continue
        if isinstance(member, property):
            kind = "property"
        elif isinstance(member, classmethod):
            kind = "classmethod"
        elif isinstance(member, staticmethod):
            kind = "staticmethod"
        else:
            kind = "method"
        yield {
            "kind": kind,
            "location": f"{module_name}.{class_qualname}.{member_name}",
            **meta,
        }


__all__ = [
    "athena_extension",
    "is_athena_extension",
    "athena_extension_metadata",
    "iter_athena_extensions",
    "ATHENA_EXTENSION_ATTR",
    "ATHENA_EXTENSION_ISSUE_ATTR",
    "ATHENA_EXTENSION_DESCRIPTION_ATTR",
    "ATHENA_EXTENSION_SINCE_ATTR",
    "ATHENA_EXTENSION_MODULE_ATTR",
]
