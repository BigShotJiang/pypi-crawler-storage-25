"""Friendly-name → OOXML styleId resolution for Word's built-in table styles.

Word stores built-in table styles in ``word/styles.xml`` with internal
styleIds like ``LightGrid-Accent1`` and friendly display names like
``"Light Grid Accent 1"``. python-docx accepts the friendly name and
resolves it against the loaded document's styles collection at write
time. Our SDK ships commands over HTTP and never sees ``styles.xml``,
so we keep an in-process map and resolve the friendly form to the
canonical styleId before the value reaches the
``<w:tblStyle w:val="..."/>`` element in the exported ``.docx``.

Without this resolution Word can't find the style definition in
``styles.xml`` and silently falls back to ``Normal Table`` — i.e.
no borders, no header fill, no banding.
"""

from __future__ import annotations


def _build_builtin_table_style_map() -> dict[str, str]:
    """Build the friendly-name → styleId map for all Word built-in table styles.

    Mirrors every ``<w:lsdException w:name="...">`` table-style
    declaration in Word's default ``styles.xml`` for Word 2007 and
    Word 2013+. Pattern: friendly names use spaces; styleIds collapse
    spaces in the base and join the optional ``Accent N`` suffix with
    a hyphen.
    """
    table: dict[str, str] = {
        "Normal Table": "TableNormal",
        "Table Grid": "TableGrid",
        # Word 2013+ added a single un-numbered "Grid Table Light"
        # alongside the numbered 1–7 series.
        "Grid Table Light": "GridTableLight",
    }
    # Word 2007 era — 14 bases × (base + 6 accents) = 98 entries.
    bases_2007: tuple[tuple[str, str], ...] = (
        ("Light Shading", "LightShading"),
        ("Light List", "LightList"),
        ("Light Grid", "LightGrid"),
        ("Medium Shading 1", "MediumShading1"),
        ("Medium Shading 2", "MediumShading2"),
        ("Medium List 1", "MediumList1"),
        ("Medium List 2", "MediumList2"),
        ("Medium Grid 1", "MediumGrid1"),
        ("Medium Grid 2", "MediumGrid2"),
        ("Medium Grid 3", "MediumGrid3"),
        ("Dark List", "DarkList"),
        ("Colorful Shading", "ColorfulShading"),
        ("Colorful List", "ColorfulList"),
        ("Colorful Grid", "ColorfulGrid"),
    )
    # Word 2013+ Plain Table — 5 entries, no accents.
    for n in range(1, 6):
        table[f"Plain Table {n}"] = f"PlainTable{n}"
    # Word 2013+ Grid Table / List Table — 7 bases × (base + 6 accents) = 49
    # entries per series. The "Light"/"Dark"/"Colorful" suffix on some
    # bases is part of the styleId, not a separate "Accent N" axis.
    bases_2013: tuple[tuple[str, str], ...] = (
        ("Grid Table 1 Light", "GridTable1Light"),
        ("Grid Table 2", "GridTable2"),
        ("Grid Table 3", "GridTable3"),
        ("Grid Table 4", "GridTable4"),
        ("Grid Table 5 Dark", "GridTable5Dark"),
        ("Grid Table 6 Colorful", "GridTable6Colorful"),
        ("Grid Table 7 Colorful", "GridTable7Colorful"),
        ("List Table 1 Light", "ListTable1Light"),
        ("List Table 2", "ListTable2"),
        ("List Table 3", "ListTable3"),
        ("List Table 4", "ListTable4"),
        ("List Table 5 Dark", "ListTable5Dark"),
        ("List Table 6 Colorful", "ListTable6Colorful"),
        ("List Table 7 Colorful", "ListTable7Colorful"),
    )
    for friendly, style_id in (*bases_2007, *bases_2013):
        table[friendly] = style_id
        for n in range(1, 7):
            table[f"{friendly} Accent {n}"] = f"{style_id}-Accent{n}"
    return table


BUILTIN_TABLE_STYLE_IDS: dict[str, str] = _build_builtin_table_style_map()


def resolve_table_style_id(style: str) -> str:
    """Return the OOXML styleId for a Word built-in table style friendly name.

    Custom user-defined style names pass through unchanged so that
    callers that already supply canonical styleIds (or non-built-in
    style names defined elsewhere) keep working.
    """
    return BUILTIN_TABLE_STYLE_IDS.get(style, style)
