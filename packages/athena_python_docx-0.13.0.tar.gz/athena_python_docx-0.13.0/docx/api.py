"""The `Document` factory — matches python-docx's `docx.Document(path)`.

python-docx signature:
    Document(docx=None) -> Document

Our signature deviates from the path-based one because we don't open
.docx files from disk — we open Y.Doc assets from Keryx. The parameter
is reused: pass an asset_id string where python-docx would take a file
path. The id MUST be ``asset_<uuid>``; anything else (a title, a file
path, etc.) raises ``ValueError`` before any HTTP request. To mint a
new asset, call ``Document.create(name=...)`` and reuse the returned
``doc.asset_id`` on subsequent ``Document(...)`` opens.

For net-new asset creation, use the classmethod ``Document.create()``
(see ``docx.document``). Stock python-docx returns a blank document
when ``Document(None)`` is called, but our SDK can't fabricate a
SuperDocument asset out of thin air — there's an Athena-side asset
write that has to happen first. ``Document.create()`` handles that via
``POST /docs/empty`` on docx-studio.
"""

from __future__ import annotations

import re

from docx.document import Document as _Document

# Asset-id shape validation. Athena SuperDocument assets are
# ``asset_<uuid>``. Rejecting anything else up front prevents the
# common agent failure mode of passing a document TITLE
# (``Document("Q4 Report Draft")``) instead of its id, which would
# otherwise round-trip through the docx-studio session and fail with
# an opaque server error.
_ASSET_ID_PATTERN = re.compile(r"^asset_[A-Za-z0-9_-]+$")


def Document(
    docx: str | None = None,
    *,
    base_url: str | None = None,
    api_key: str | None = None,
    user_name: str | None = None,
    user_email: str | None = None,
    track_revisions: bool = False,
) -> _Document:
    """Open a Word document for editing.

    Args:
        docx: Athena asset_id of the SuperDoc document to open. In
              python-docx this takes a file path; here it takes an
              asset_id. To create a NEW document instead of opening
              an existing one, call ``Document.create(...)`` (a
              classmethod on the Document class).
        base_url: docx-studio API base URL. Falls back to
              ``$ATHENA_DOCX_BASE_URL``.
        api_key: Athena API key / PropelAuth bearer. Falls back to
              ``$ATHENA_DOCX_API_KEY``.
        user_name: (Athena extension) author identity for tracked
              changes. Threaded through to SuperDoc on session-open;
              ignored on subsequent requests against a pooled session.
        user_email: (Athena extension) optional email for the
              tracked-change author tooltip.
        track_revisions: (Athena extension) start the document with
              track-changes mode enabled. Equivalent to setting
              :attr:`Document.track_revisions` to ``True`` after
              construction.

    Returns:
        A Document instance bound to the asset.

    Raises:
        ValueError: if ``docx`` is None or empty. Use ``Document.create()``
            to make a fresh asset.
    """
    if not docx:
        raise ValueError(
            "athena-python-docx requires an asset_id. "
            "Pass the SuperDoc asset ID as the first argument: "
            "Document('asset_xxx...'). "
            "To create a brand-new document, call "
            "Document.create(name=..., base_url=..., api_key=...).",
        )
    if not _ASSET_ID_PATTERN.match(docx):
        raise ValueError(
            f"Document({docx!r}) is not a valid SuperDocument asset id. "
            f"Asset ids look like 'asset_<uuid>' "
            f"(e.g., 'asset_3a9328bc-9c1c-4498-be8f-bda3883276f5'). To "
            f"open an existing document, pass its asset id — NOT its "
            f"title. To create a new document titled {docx!r}, call "
            f"Document.create(name={docx!r}) and reuse the returned "
            f"document's asset id on subsequent calls in the same "
            f"conversation."
        )

    # PTC: surface document open as its own sub-tool-card so the
    # frontend can react (e.g., auto-open the asset tab). The paired
    # ``Document.create()`` path emits ``CreateDocument``; this open
    # path emits ``OpenDocument`` with the asset id.
    from docx import _ptc

    call_id = _ptc.emit_begin("OpenDocument", {"assetId": docx})
    try:
        doc = _Document(
            asset_id=docx,
            http_base_url=base_url,
            http_api_key=api_key,
            user_name=user_name,
            user_email=user_email,
            track_revisions=track_revisions,
        )
    except Exception as exc:
        _ptc.emit_end(
            call_id=call_id,
            tool_name="OpenDocument",
            result={"ok": False, "error": str(exc)},
            is_error=True,
        )
        raise
    _ptc.emit_end(
        call_id=call_id,
        tool_name="OpenDocument",
        result={"ok": True, "assetId": docx},
        is_error=False,
    )
    return doc


# Re-export the classmethod factories at module level so callers can
# write either:
#     from docx import Document
#     Document.create(name=...)
# or:
#     from docx.api import Document
#     Document.create(name=...)
# (matching python-docx's flat API surface.)
Document.create = _Document.create  # type: ignore[attr-defined]
