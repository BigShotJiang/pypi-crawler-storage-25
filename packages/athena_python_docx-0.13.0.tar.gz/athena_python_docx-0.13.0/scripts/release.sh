#!/usr/bin/env bash
# Tag + push a new athena-python-docx release. CI handles the additive
# pipeline: PyPI publish, Docker image rebuild, Daytona snapshot
# creation. The Infisical flip + settings.py default bump are NOT
# automatic — author a follow-up PR after the snapshot is created.
# See .github/workflows/athena-python-docx-release.yml for the full flow.
#
# Usage:
#   ./scripts/release.sh <version>
#
# e.g. ./scripts/release.sh 0.2.3 — releases athena-python-docx==0.2.3
# by:
#   1. Updating pyproject.toml + docx/__init__.py
#   2. Committing the version bump
#   3. Tagging athena-python-docx-v<version>
#   4. Pushing the commit + tag to origin
#
# CI trigger fires on the tag push and runs the full release pipeline.

set -euo pipefail

if [ $# -ne 1 ]; then
  echo "Usage: $0 <version> (e.g., 0.2.3)" >&2
  exit 1
fi

VERSION="$1"
if ! [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+(\.(dev|rc|a|b)[0-9]+)?$ ]]; then
  echo "ERROR: version '$VERSION' is not a valid semver-ish" >&2
  exit 1
fi

SDK_DIR="$(cd "$(dirname "$0")/.." && pwd)"
REPO_ROOT="$(git -C "$SDK_DIR" rev-parse --show-toplevel)"

# Require clean working tree so the commit captures only the version bump.
if ! git -C "$REPO_ROOT" diff --quiet || ! git -C "$REPO_ROOT" diff --cached --quiet; then
  echo "ERROR: working tree is dirty. Commit or stash first." >&2
  git -C "$REPO_ROOT" status --short >&2
  exit 1
fi

# Bump pyproject.toml
sed -i.bak "s/^version = \".*\"/version = \"$VERSION\"/" "$SDK_DIR/pyproject.toml"
rm -f "$SDK_DIR/pyproject.toml.bak"

# Bump docx/__init__.py
sed -i.bak "s/^__version__ = \".*\"/__version__ = \"$VERSION\"/" "$SDK_DIR/docx/__init__.py"
rm -f "$SDK_DIR/docx/__init__.py.bak"

# Show the diff so the operator sees what will be committed.
echo "=== Version bump diff ==="
git -C "$REPO_ROOT" diff "$SDK_DIR/pyproject.toml" "$SDK_DIR/docx/__init__.py"
echo "========================="

TAG="athena-python-docx-v$VERSION"

# Commit + tag + push.
git -C "$REPO_ROOT" add "$SDK_DIR/pyproject.toml" "$SDK_DIR/docx/__init__.py"
git -C "$REPO_ROOT" commit -m "chore(docx-sdk): bump version to $VERSION"
git -C "$REPO_ROOT" tag "$TAG"
git -C "$REPO_ROOT" push
git -C "$REPO_ROOT" push origin "$TAG"

cat <<EOF

Tagged $TAG and pushed. CI is now running the additive release pipeline:

  1. PyPI publish         → https://pypi.org/project/athena-python-docx/$VERSION/
  2. Docker image rebuild → athenaintel/daytona-document:$VERSION
  3. Daytona snapshot     → document-exec:$VERSION

Watch the run:
  https://github.com/Athena-Intel/demo-app-monorepo/actions/workflows/athena-python-docx-release.yml

After CI completes, open a PR that pins the new snapshot in code:

  - agora/agora/settings.py::daytona_document_exec_snapshot
      → "document-exec:$VERSION"

That ships via the normal staging → prod deploy pipeline. The release
workflow no longer writes to Infisical — settings.py is the source of
truth. If a single environment needs an override (e.g., pin staging to
an older snapshot), set Infisical DAYTONA_DOCUMENT_EXEC_SNAPSHOT on
that environment by hand.

EOF
