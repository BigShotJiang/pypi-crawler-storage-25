"""Round-trip smoke test against a live docx-studio API + SuperDocument asset.

Drives a representative scenario through the SDK (mutations + reads)
and asserts on the read-back shape. Designed to catch the
``SDK → docx-studio → Keryx → SuperDoc`` class of regression that
unit tests with FakeSession + the cross-language Zod contract test
can't see — namely, "the wire format we send is technically valid
but SuperDoc doesn't apply it the way we expect."

Per-PR usage in CI (after ``Deploy DOCX Studio Preview`` succeeds):

    ASSET_ID=asset_ci_round_trip_test \\
    DOCX_STUDIO_BASE_URL=https://docx-studio-pr19782-preview... \\
    ATHENA_DOCX_API_KEY=$CI_DOCX_TEST_API_KEY \\
    python scripts/round_trip_smoke.py

Manual usage (against staging, with a personal API key):

    ASSET_ID=asset_49b963a4-... \\
    ATHENA_DOCX_API_KEY=$BG_STAGING_API_KEY \\
    python scripts/round_trip_smoke.py

Exit codes:
- 0  — all checks passed
- 1  — at least one check failed (treat as a real regression)
- 2  — environment / network unavailability (treat as infra flake;
        callers can soft-fail in CI)
"""

from __future__ import annotations

import os
import sys
import time
import traceback
from dataclasses import dataclass
from typing import Callable


def _emit(name: str, ok: bool, detail: str = "") -> None:
    glyph = "[ok]" if ok else "[FAIL]"
    line = f"{glyph} {name}"
    if detail:
        line += f"  — {detail}"
    print(line, flush=True)


@dataclass
class CheckResult:
    name: str
    ok: bool
    detail: str = ""


def main() -> int:
    asset_id = os.environ.get("ASSET_ID")
    if not asset_id:
        print(
            "ERROR: set ASSET_ID env var to a SuperDocument asset id the "
            "test API key has write access to. Skipping with exit 2 so "
            "callers can soft-fail in CI.",
            file=sys.stderr,
        )
        return 2

    base_url = os.environ.get("DOCX_STUDIO_BASE_URL")
    api_key = os.environ.get("ATHENA_DOCX_API_KEY")
    if not api_key:
        print(
            "ERROR: ATHENA_DOCX_API_KEY missing. Skipping with exit 2.",
            file=sys.stderr,
        )
        return 2

    # Insert local SDK first so this script always exercises the
    # just-built code (when run from the repo) rather than whatever
    # version is on the PYTHONPATH.
    sdk_root = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "..",
    )
    sys.path.insert(0, os.path.abspath(sdk_root))

    try:
        from docx import Document
        from docx.errors import DocxError
    except ImportError as e:
        print(f"ERROR: failed to import SDK from {sdk_root}: {e}", file=sys.stderr)
        return 2

    print(f"[setup] base_url={base_url or '<default>'}")
    print(f"[setup] asset_id={asset_id}")
    print(f"[setup] sdk_root={sdk_root}")

    # Tag every paragraph with a unique suffix so re-runs against a
    # long-lived asset stay debuggable (we can grep the asset for the
    # token and find the run that wrote it).
    run_token = f"ci-{int(time.time())}"

    try:
        kwargs: dict = {"api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url
        doc = Document(asset_id, **kwargs)
    except DocxError as e:
        print(f"ERROR: failed to open document: {e}", file=sys.stderr)
        # Network / auth / 502 — caller treats as infra flake.
        return 2

    results: list[CheckResult] = []

    def run_check(name: str, fn: Callable[[], None]) -> None:
        try:
            fn()
            results.append(CheckResult(name, True))
            _emit(name, True)
        except AssertionError as e:
            results.append(CheckResult(name, False, str(e)))
            _emit(name, False, str(e))
        except Exception as e:  # noqa: BLE001
            results.append(CheckResult(name, False, f"{type(e).__name__}: {e}"))
            _emit(name, False, f"{type(e).__name__}: {e}")
            traceback.print_exc()

    # -----------------------------------------------------------------
    # Check 1 (Round 3 #2): Document.add_paragraph segments tabs/newlines
    # -----------------------------------------------------------------
    expected_text_1 = f"[{run_token}] hello\tworld\nfoo"

    def check_paragraph_segments_tabs_and_newlines() -> None:
        p = doc.add_paragraph(expected_text_1)
        # Read-back: paragraph.text must include the tab and newline as
        # \t and \n (Round 2 #1: _extract_text now renders these).
        # Drain any pending writes to make sure SuperDoc has applied
        # them before we read.
        doc.save()
        text_back = p.text
        assert text_back == expected_text_1, (
            f"add_paragraph + paragraph.text round-trip diverged: "
            f"sent {expected_text_1!r}, got {text_back!r}"
        )

    run_check(
        "round-3 #2: Document.add_paragraph segments \\t / \\n into inlines",
        check_paragraph_segments_tabs_and_newlines,
    )

    # -----------------------------------------------------------------
    # Check 2 (Round 3 #3): Document.add_heading segments tabs/newlines
    # -----------------------------------------------------------------
    expected_heading = f"[{run_token}] heading\twith-tab"

    def check_heading_segments_tab() -> None:
        h = doc.add_heading(expected_heading, level=2)
        doc.save()
        text_back = h.text
        assert text_back == expected_heading, (
            f"add_heading + paragraph.text round-trip diverged: "
            f"sent {expected_heading!r}, got {text_back!r}"
        )

    run_check(
        "round-3 #3: Document.add_heading segments \\t into inline",
        check_heading_segments_tab,
    )

    # -----------------------------------------------------------------
    # Check 3 (Round 1 + Round 2 #1): bold=True applies, paragraph.text
    # ignores the mark, runs[0].text holds the segment
    # -----------------------------------------------------------------
    expected_bold = f"[{run_token}] this is bold"

    def check_bold_round_trip() -> None:
        p = doc.add_paragraph(expected_bold)
        doc.save()
        runs = list(p.runs)
        assert runs, "add_paragraph produced no runs"
        runs[0].bold = True
        doc.save()
        # Re-fetch and verify bold mark stuck. Live read goes through
        # _read_inline_attr which re-fetches the paragraph node.
        runs2 = list(p.runs)
        assert runs2 and runs2[0].bold is True, (
            f"bold=True did not persist; got runs[0].bold={runs2 and runs2[0].bold}"
        )

    run_check(
        "round-1: Run.bold=True persists via FormatApply",
        check_bold_round_trip,
    )

    # -----------------------------------------------------------------
    # Check 4 (Round 2 #1): paragraph.text reads tabs/newlines verbatim
    # — covered by checks 1 + 2 already, but pin the expected sequence
    # -----------------------------------------------------------------
    def check_paragraph_text_renders_control_chars() -> None:
        # Use a dedicated paragraph so we don't depend on read order.
        sentinel = f"[{run_token}] tab=\there\nbreak=line"
        p = doc.add_paragraph(sentinel)
        doc.save()
        assert p.text == sentinel, (
            f"paragraph.text dropped control chars: {p.text!r} vs {sentinel!r}"
        )

    run_check(
        "round-2 #1: paragraph.text renders \\t and \\n verbatim",
        check_paragraph_text_renders_control_chars,
    )

    # -----------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------
    failed = [r for r in results if not r.ok]
    print()
    print(f"=== Summary: {len(results) - len(failed)}/{len(results)} passed ===")
    for r in failed:
        print(f"  [FAIL] {r.name} — {r.detail}")
    if failed:
        return 1
    print("All round-trip checks passed.")
    return 0


if __name__ == "__main__":
    try:
        rc = main()
    except KeyboardInterrupt:
        rc = 130
    except Exception:
        traceback.print_exc()
        rc = 1
    raise SystemExit(rc)
