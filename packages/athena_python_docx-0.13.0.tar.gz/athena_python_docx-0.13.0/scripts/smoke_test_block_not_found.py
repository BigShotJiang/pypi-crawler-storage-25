#!/usr/bin/env python3
"""Manual smoke test: BlockNotFoundError fires + carries the cell-paragraph hint.

Runs against a live docx-studio API (preview, staging, or prod) and
asserts that the typed exception path the cascade-fix work depends on
is still wired through end-to-end:

1. SDK raises :class:`BlockNotFoundError` (not bare :class:`DocxError`).
2. Exception carries the cell-paragraph hint text when the failing
   command is paragraph-targeting (``Insert`` / ``SetParagraph*`` /
   ``FormatApply``).
3. Exception carries ``partial_applied`` data on partial failures so
   the next batch can ship real ids.

# Why this exists

In-tree unit tests (``tests/test_block_not_found_error.py``,
``tests/test_partial_failure_cascade.py``) cover the contracts with
mocked responses. They CAN'T catch the kind of drift that breaks the
SDK's error classification in production:

- A SuperDoc upgrade that changes the message phrasing from
  ``Block "paragraph:<id>" was not found`` to
  ``BlockMissing: paragraph <id>`` would silently demote
  :class:`BlockNotFoundError` to generic :class:`DocxError` (the
  ``_looks_like_block_not_found`` substring match would fail). Agent
  code would lose the typed-exception path and the hint message.
- A change to ``apps/api``'s 207 response shape that drops the
  ``applied`` array would silently disable the cascade fix —
  ``partial_applied`` would always be empty, every Create's proxy
  would stay on its client UUID, and the cascade would return.

A live smoke test catches both classes of drift faster than waiting
for an agent to bump into them in a real session.

# Environment

Set these env vars before running:

    export ATHENA_DOCX_BASE_URL=https://docx-studio-pr20575-preview.previews.athenaintel.com
    export ATHENA_DOCX_API_KEY=...                  # your athena api key
    export ATHENA_TEST_ASSET_ID=asset_...           # a real existing SuperDoc asset_id
    export SUPERDOC_COLLAB_TOKEN=...                # keryx token for that asset
    export KERYX_WS_URL=...                          # keryx ws url
    export ATHENA_WORKSPACE_ID=workspace_...

The asset doesn't need a table — the script creates one in the asset
as part of the smoke test (and the cell-paragraph format op against
it is what triggers the typed error).

# Run

    cd docx-studio/python-sdk
    uv run python scripts/smoke_test_block_not_found.py

Exit code 0 on success, 1 if any assertion failed. Designed to be
called from a workflow (``.github/workflows/docx-preview-smoke.yml``,
not yet added).
"""

from __future__ import annotations

import os
import sys


def _require_env(name: str) -> str:
    val = os.environ.get(name)
    if not val:
        print(
            f"FAIL: ${name} is not set. See the docstring of this script "
            "for the full env-var list.",
            file=sys.stderr,
        )
        sys.exit(1)
    return val


def main() -> int:
    base_url = _require_env("ATHENA_DOCX_BASE_URL")
    api_key = _require_env("ATHENA_DOCX_API_KEY")
    asset_id = _require_env("ATHENA_TEST_ASSET_ID")
    # The session env vars are read by ``Document.open`` indirectly —
    # we just need to make sure they're present.
    for v in ("SUPERDOC_COLLAB_TOKEN", "KERYX_WS_URL", "ATHENA_WORKSPACE_ID"):
        _require_env(v)

    # Defer the SDK imports so the env-var error path runs first
    # without needing the package installed.
    from docx import Document
    from docx.errors import BlockNotFoundError, DocxError

    print(f"[smoke] target: {base_url}")
    print(f"[smoke] asset:  {asset_id}")

    # The SDK reads ATHENA_DOCX_BASE_URL / ATHENA_DOCX_API_KEY from the
    # process env at HttpClient construction time.
    os.environ["ATHENA_DOCX_BASE_URL"] = base_url
    os.environ["ATHENA_DOCX_API_KEY"] = api_key

    failures: list[str] = []

    # Trigger the cell-paragraph addressing bug: add a fresh table and
    # try to format its first cell's paragraph BEFORE materializing
    # the cell content. This is exactly the shape that hit
    # ``BlockNotFoundError`` in preview-session thread_bafba02b.
    try:
        with Document(asset_id) as doc:
            table = doc.add_table(rows=2, cols=2)
            cell = table.cell(0, 0)
            # ``cell.paragraphs[0].alignment = X`` is the documented
            # tripwire: SuperDoc can't find the cell-inner paragraph
            # via a top-level block target. Pre-cascade-fix this would
            # have surfaced as a raw DocxError without a hint.
            from docx.enum.text import WD_ALIGN_PARAGRAPH

            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            # We don't expect to reach here. doc.save() forces the
            # batch out if the buffer hasn't flushed yet.
            doc.save()
        failures.append(
            "Expected BlockNotFoundError on cell-paragraph alignment "
            "but the call completed cleanly. Either SuperDoc fixed § 13 "
            "upstream (good — update tests), or the SDK regressed and "
            "is no longer surfacing the wire-format error.",
        )
    except BlockNotFoundError as exc:
        print(f"[smoke] ✓ BlockNotFoundError raised: {type(exc).__name__}")
        msg = str(exc)
        if "cell.text" not in msg:
            failures.append(
                "BlockNotFoundError fired but the cell-paragraph hint "
                "is MISSING. Expected 'cell.text' in the message; got: "
                f"{msg[:300]}",
            )
        else:
            print("[smoke] ✓ cell-paragraph hint present")
        # The partial-failure path attaches the server's ``applied``
        # prefix; for this specific shape (SetParagraphAlignment as
        # the first/only command) the prefix is empty, but the
        # attribute itself must exist and be a list.
        if not hasattr(exc, "partial_applied") or not isinstance(
            exc.partial_applied,
            list,
        ):
            failures.append(
                "BlockNotFoundError missing the ``partial_applied: list`` "
                "attribute introduced by the cascade fix — agora-side "
                "rewrite path won't work for partial failures.",
            )
        else:
            print(
                f"[smoke] ✓ partial_applied attribute present "
                f"(len={len(exc.partial_applied)})",
            )
    except DocxError as exc:
        failures.append(
            f"Wire-format drift: expected BlockNotFoundError, got "
            f"{type(exc).__name__}. The substring matcher in "
            f"``_looks_like_block_not_found`` no longer recognizes "
            f"SuperDoc's error message. First 300 chars: {str(exc)[:300]}",
        )

    if failures:
        print(f"\n[smoke] FAIL — {len(failures)} assertion(s) failed:")
        for i, f in enumerate(failures, start=1):
            print(f"  {i}. {f}")
        return 1

    print("\n[smoke] all assertions passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
