# athena-python-docx SDK — Claude Instructions

## API Parity Rule (MANDATORY)

**This SDK MUST be a 100% exact replica of the standard [python-docx](https://python-docx.readthedocs.io/) API.**

Every class, method, property, and parameter name must match python-docx exactly. The goal is that any code written for python-docx works identically with this SDK — no surprises, no differences.

### What this means in practice

- **Do NOT add new methods** that don't exist in python-docx
- **Do NOT add new properties** that don't exist in python-docx
- **Do NOT rename parameters** — use the exact same parameter names as python-docx
- **Do NOT change method signatures** — if python-docx's `add_heading()` takes `(text, level=1)`, ours must too
- **Do NOT change return types** — if python-docx's `paragraph.runs` returns `list[Run]`, ours must too

### How to verify parity

Before adding or modifying any API surface:

1. Check the [python-docx documentation](https://python-docx.readthedocs.io/)
2. Check the [python-docx source code](https://github.com/python-openxml/python-docx)
3. Confirm the method/property/parameter exists with the same name and signature
4. If it doesn't exist in python-docx, **do not add it** without explicit user approval

Run `uv run pytest tests/test_python_docx_api_parity.py -v -s` to verify parity.

### Intentionally omitted (Superdoc SDK limitations)

These standard python-docx members don't apply to a Superdoc-backed SDK:

- `Paragraph._p`, `Run._r` — XML element access (no local XML)
- `Document.part`, `Paragraph.part`, `Run.part` — package part access
- `Document.core_properties.last_modified_by` — we use Keryx attribution instead
- `Document.settings` — Word app settings (not surfaced by Superdoc)
- `InlineShape.chart` — charts (Phase 2+)
- `Comment.add_paragraph` / `Comment.add_table` /
  `Comment.iter_inner_content` / `Comment.paragraphs` /
  `Comment.tables` — SuperDoc models a comment as a single text body,
  not a `BlockItemContainer`. Use `Comment.text` instead. The
  paragraph/table-bearing surface raises `CommentsNotImplementedError`.
- **`_Cell.add_table(rows, cols)`** — surface preserved for parity
  (signature matches python-docx, no `width` kwarg) but raises
  :class:`docx.errors.NestedTableNotSupportedError` (subclass of
  `NotImplementedError`) at runtime since 0.11.2. SuperDoc 1.8.1 has
  no anchor or content-fragment shape that places a new table inside
  an existing `tableCell` — `create.table` rejects cell-inner
  paragraph anchors with `INVALID_TARGET`, and the `doc.insert`
  workaround used by `_Cell.add_paragraph` doesn't generalize
  because the apps/api `Insert` schema doesn't yet forward
  `nestingPolicy: {tables: "allow"}` and the SuperDoc table-content
  fragment shape isn't documented. Tracked at
  `docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md` § 13.
- **`docx.oxml.*`** — the entire raw-OOXML module tree (``ns.qn``,
  ``OxmlElement``, ``CT_*`` classes, etc.) is unavailable because the
  SDK is HTTP-only against a SuperDoc Y.Doc; there is no local lxml
  tree to manipulate. As of 0.8.0, ``docx.oxml`` is a real stub
  package that raises a typed
  :class:`docx.oxml.OxmlNotAvailableError` (subclass of
  ``ImportError``) on any attribute access, with an inline pointer at
  the high-level API (``Document.add_paragraph``, ``Run.bold``,
  ``_Cell.text``, …) or the typed command surface in
  ``docx.commands``. Pre-0.8.0 this used to fail with the stdlib's
  generic ``ModuleNotFoundError: No module named 'docx.oxml'`` and
  agents had to retry to discover the gap.

### Phase-3b upstream-blocked surface

These are *shipped at the surface* but partially or fully no-op at
runtime, pending SuperDoc SDK changes outside this repo. The
upstream constraints have been verified against
[SuperDoc's published docs](https://docs.superdoc.dev/document-api/reference/styles/apply)
and the bundled TypeScript types in
`node_modules/@superdoc-dev/sdk/dist/generated/client.d.ts`. See
`docx-studio/PYTHON_DOCX_PARITY_GAPS.md` § *What unblocks the
remaining work* for the exact wire-op shape needed to unblock each.

- **24 setters on `BaseStyle` / `CharacterStyle` / `ParagraphStyle`**
  (`name`, `style_id`, `hidden`, `locked`, `priority`, `quick_style`,
  `unhide_when_used`, `base_style`, `next_paragraph_style`) emit
  `PendingStyleMutationWarning` and stash on `_overrides`.
  SuperDoc 1.7's `doc.styles.apply` is constrained to
  `target.scope: "docDefaults"` — no per-style metadata variant.
  Behavior pinned by `tests/test_style_setters_contract.py` (11
  tests); when SuperDoc lands a metadata op, those tests will need
  to flip to assert real bus calls.
- **`Styles.latent_styles`** returns an empty `_LatentStyles` —
  `DocInfoResult.styles` only surfaces `paragraphStyles[]` (a flat
  usage-count list), not the OOXML `<w:latentStyles>` block.

### Intentional deviations (additions / different semantics)

These differ from stock python-docx because the SDK is asset-backed,
not file-backed. Each is documented in the relevant docstring.

- **Built-in table style friendly names resolve to OOXML styleIds.**
  Word's ``styles.xml`` ships built-in table styles whose styleIds
  (``LightGrid-Accent1``, ``MediumShading1-Accent2``, …) differ from
  their display names (``"Light Grid Accent 1"``, …). Stock
  python-docx resolves the friendly form against the loaded
  document's styles collection at write time. We can't read
  ``styles.xml`` over HTTP, so ``Document.add_table(style=...)`` /
  ``Table.style`` setter consult an in-process map
  (``docx._table_styles.BUILTIN_TABLE_STYLE_IDS``) covering every
  Word 2007 and Word 2013+ built-in table style (204 entries) before
  the value reaches ``<w:tblStyle w:val="..."/>``. Without this
  mapping Word can't resolve the friendly name in ``styles.xml``
  and silently falls back to ``Normal Table`` (no borders, no
  header fill, no banding). Custom user-defined style names pass
  through unchanged. Whether Word actually renders a Word 2013+
  style after resolution also depends on SuperDoc's exported
  ``styles.xml`` containing the matching ``<w:style w:type="table">``
  definition — at SuperDoc 1.8.1 the exported ``styles.xml`` only
  carries the Word 2007 set, so Word 2013+ styleIds resolve in the
  ``<w:tblStyle>`` element but still fall back to ``Normal Table``
  until SuperDoc upstream ships an expanded ``styles.xml``.

- **`Document.create(name=, base_url=, api_key=, parent_folder_id=, workspace_id=, docx=, agora_base_url=)`**
  classmethod. Stock python-docx returns a blank in-memory document
  for `Document(None)`; we can't fabricate a SuperDocument asset
  client-side, so net-new asset creation is a separate factory that
  hits `POST {base_url}/docs/empty`. The constructor positional-arg
  shape (`Document(asset_id)`) is preserved for parity.
  - **`docx=path`** mirrors the upstream `Document(docx="template.docx")`
    constructor kwarg: when provided, the local `.docx` is uploaded to
    agora's `/api/super-docs/create-from-upload` and used as the seed
    for the new SuperDocument. The bytes are mirrored to S3 server-side
    so subsequent template-asset reuse is fast. Without `docx=`, the
    default Athena template is applied as today.
  - **`agora_base_url=`** is a transport-detail kwarg only required when
    the SDK can't derive the agora host from `base_url` (or from
    `$ATHENA_AGORA_BASE_URL`). The default substitution rule replaces
    `docx-studio` with `agora` in the docx-studio host; explicit
    `agora_base_url` is required for local development or unusual
    deployment topologies.

- **`Document.asset_id: str`** read-only property — the Athena asset
  id this Document is bound to (`asset_<uuid>`). Agent-callable so
  the typical pattern `doc = Document.create(...); print(doc.asset_id)`
  works without reaching into `doc._session._asset_id`. Stock
  python-docx has no analogue (it operates on local files), so this
  is an Athena-only addition. Mirrors the parallel public accessors
  on the other studios: `Workbook.workbook_id` (xlsx) and
  `Presentation.deck_id` (pptx).

- **`Document.save(path_or_stream=None)`** — argument is optional and,
  when supplied, raises
  :class:`docx.errors.LocalSaveTargetNotSupportedError`. Stock
  python-docx requires it and `TypeError`s on no-arg, but in an
  asset-backed SDK there is no local file to write — writes are always
  in-place against the Y.Doc. Forcing the upstream signature broke
  every agent invocation that reflexively called `doc.save()` (a
  near-universal Python pattern), so the no-arg form is supported.
  When a path or stream IS supplied, the SDK cannot fulfill the
  implied "write bytes to this target" contract, so the call raises
  loudly rather than silently flushing — agents must use Olympus's
  Export DOCX (which goes through the SuperDoc session that already
  has the bytes) instead of expecting a local file.

- **`Document.track_revisions: bool`** — when `True`, all subsequent
  mutations are recorded as tracked revisions instead of direct edits.
  python-docx upstream has no top-level toggle (the closest is
  hand-edited `<w:trackChanges/>` on `Document.settings.element`).
  We expose this as a Document-level property because every SuperDoc
  mutation accepts a per-call `changeMode` envelope field. The
  python-docx-parity alias `Document.settings.track_revisions` reads
  and writes the same flag so call sites that walk `doc.settings`
  see consistent state.

- **`Document.tracked_revisions()` context manager** — scope
  `track_revisions=True` to a `with` block; restores the previous
  value on exit (even on exception). Block-scoped track-changes is a
  Pythonic ergonomic that doesn't exist in upstream python-docx
  because the upstream package has no track-changes API at all.

- **`Document.user_name: str | None` / `Document.user_email: str |
  None`** — author identity threaded through to SuperDoc on session-
  open for tracked-change attribution. python-docx's
  `Document.core_properties.last_modified_by` is the closest upstream
  surface; we use the SuperDoc-native fields directly because SuperDoc
  bakes them into the change records.

- **`Document.revisions: Revisions`** — collection of tracked changes
  with iteration, `get(id)`, `accept_all()`, `reject_all()`,
  `accept(id)`, `reject(id)`. Per-revision `Revision.accept()` /
  `Revision.reject()` resolve a single change. python-docx upstream
  has zero track-changes API, so this entire surface is an Athena
  extension wired to SuperDoc's `doc.trackChanges.{list,get,decide}`.

### Athena extensions for most-requested upstream features (v0.11.0+)

These surfaces are **additions** to python-docx, not deviations from
existing behavior — every upstream class, method, property, and
parameter remains 1:1 with python-docx 1.2.0. The parity ratchet at
`tests/parity/` is one-directional (upstream → athena) so Athena
extensions do not produce findings; they're listed here for human
review and so future contributors can find the rationale.

Each item below corresponds to a long-standing upstream feature gap.
Issue numbers reference `python-openxml/python-docx`.

- **`Paragraph.add_hyperlink(text, address, *, fragment=None,
  tooltip=None) -> Hyperlink`** — appends a hyperlinked run.
  python-docx surfaces `Hyperlink` as read-only; PR #74 has been open
  since 2014 and is the single most-requested missing feature. Routes
  through `CreateHyperlink` (SuperDoc `doc.hyperlinks.create`). Returns
  the same `Hyperlink` class the read path already exposes. Also
  available as `Run.add_hyperlink` for convenience.

- **`Run.add_field(kind, *, args=None, cached_result=None) -> Field`**
  + **`Document.fields: Fields`** — generic Word field insertion.
  Supports `"PAGE"`, `"NUMPAGES"`, `"DATE"`, `"TIME"`, `"AUTHOR"`,
  `"FILENAME"`, `"NUMWORDS"`, `"REF"`, `"SEQ"`, `"TOC"`, and the
  generic `"FIELD"` escape hatch. python-docx has no field API
  whatsoever; issue #498 (page numbers) and #31 (23 comments) demand
  this. `Fields` is sequence-like; `Fields.refresh_all(scope?)`
  forces a recompute. Routes through `CreateField` / `FieldsRefresh`
  / `FieldsList`.

- **`Document.bookmarks: Bookmarks`** + **`Paragraph.add_bookmark
  (name)`** + **`Document.add_bookmark(name, *, paragraph=None,
  run=None) -> Bookmark`** — named anchors for cross-references,
  TOC entries, captions, and internal hyperlinks. python-docx
  upstream has no bookmark API; issue #425 (35 comments) has been
  open since 2017. Routes through `CreateBookmark` /
  `DeleteBookmark` / `BookmarksList` / `BookmarksGet`.

- **`Document.footnotes: Footnotes`** + **`Run.add_footnote(text, *,
  custom_mark=None) -> Footnote`** — footnote references with a
  separate body story. python-docx Issue #1 (the first issue ever
  filed, open since 2014) demands this; it drove the `bayoo-docx`
  fork. Routes through `CreateFootnote` / `FootnotesList` /
  `FootnotesGet` / `FootnotesPatch` / `FootnotesDelete`. The
  parallel **`Document.endnotes: Endnotes`** + **`Run.add_endnote
  (text, *, custom_mark=None)`** mirrors the same machinery for
  end-of-section notes.

- **`Document.add_toc(*, levels=(1, 3), style_id=None,
  include_hyperlinks=True, title=None, tab_leader="dot", at=None)
  -> TableOfContents`** — inserts a TOC field at the cursor.
  python-docx issue #36 (closed-without-action), #1207, #1403 demand
  this. The returned `TableOfContents` proxy exposes `refresh()` to
  recompute the cached result. Routes through `CreateTOC` /
  `RefreshTOC`.

- **`Paragraph.add_caption(text, *, label="Figure", bookmark=None,
  style=None) -> Paragraph`** — adds a caption paragraph with a SEQ
  field for auto-numbering. python-docx issue #676 (11 👍). Routes
  through `CreateCaption`.

- **`Run.add_cross_reference(target, *, reference_kind="text",
  hyperlink=True) -> Field`** — REF field pointing at a bookmark or
  SEQ. python-docx issue #97 (33 comments). Reference kinds:
  `"text"`, `"number"`, `"page"`, `"label-number"`, `"above-below"`,
  `"paragraph"`. Routes through `CreateCrossReference`.

- **`_Cell.set_borders(*, top=, bottom=, left=, right=,
  inside_horizontal=, inside_vertical=)`** + **`_Cell.borders`**
  property + **`Table.set_borders(...)`** — per-edge border control.
  python-docx issue #201 (5 👍), #1238 demand a cell-borders API.
  Routes through `SetCellBorders` / `SetTableBorders`.

- **`_Cell.set_shading(*, fill=, pattern=, color=)`** +
  **`_Cell.shading`** property — cell fill / shading. python-docx
  issue #146 (12 comments) demands this. Routes through
  `SetCellShading`.

- **`_Cell.v_merge` / `_Cell.is_merge_continuation` /
  `_Cell.is_merge_origin`** — robust merged-cell detection.
  python-docx surfaces `_Cell.grid_span` (horizontal) but the
  vertical merge state and master detection are issue #1312, #1434,
  #1458. Pure derived properties from existing `tables.getCells`
  data.

- **`Table.add_row(*, copy_format_from=None)`** — when `copy_format_from`
  is provided (int row index or `_Row`), the new row inherits height,
  borders, shading, vertical alignment, and run formatting from the
  source row. python-docx issue #205 (9 👍). The no-arg form is
  unchanged.

- **`InlineShape.alt_text` / `InlineShape.title` /
  `InlineShape.decorative`** + mirrors on `Picture` — accessibility
  metadata. python-docx PR #1530 is in flight but unreleased; the
  feature has been requested for years. Routes through
  `SetImageAltText` / `SetImageDecorative` (already wired in
  SuperDoc).

- **`InlineShape.anchor(*, wrap="square", position_x_pt=,
  position_y_pt=, relative_from_x=, relative_from_y=,
  behind_text=)`** — promote an inline image to a floating
  (anchored) image. python-docx is inline-only; issue #159 has been
  open since 2017. Wrap modes: `"inline"`, `"square"`, `"tight"`,
  `"through"`, `"top-bottom"`, `"behind"`, `"in-front"`. Routes
  through `SetImageAnchor`.

- **`Document.add_watermark(*, text=None, image_path=None, ...)
  -> str`** — page-watermark on every page. python-docx issue #845
  (9 👍). Pass either `text` or `image_path`. Routes through
  `CreateWatermark`. `Document.delete_watermark` is available via
  the lower-level `DeleteWatermark` command.

- **`Document.charts: Charts`** + **`Document.add_chart(chart_type,
  data, *, title=None, width_pt=None, height_pt=None, at=None)
  -> Chart`** — chart insertion + data editing. python-docx issue
  #179 (12 👍, 19 comments) demands creation, #1141 demands editing.
  `chart_type` covers all Word 2016+ families. `Chart.data` setter
  replaces the underlying table; `Chart.chart_type` setter switches
  family. Routes through `CreateChart` / `SetChartData` /
  `SetChartType` / `ChartsList` / `ChartsGet`.

- **`Run.add_math(content, *, format="mathml", display=False)
  -> MathEquation`** — math equations. python-docx issue #320 (23
  comments). Formats: `"mathml"`, `"omml"` (Word native), `"latex"`
  (server-converted). Routes through `CreateMath` / `MathPatch`.

- **`Document.content_controls: ContentControls`** +
  **`Document.add_content_control(control_kind, ...) -> ContentControl`**
  — structured-document-tag (SDT) wrappers. python-docx issues #155,
  #224 (15 comments), #1417 demand write support. Kinds:
  `"rich-text"`, `"plain-text"`, `"picture"`, `"checkbox"`,
  `"date"`, `"dropdown"`, `"combobox"`, `"repeating-section"`,
  `"group"`. Routes through `CreateContentControl` /
  `ContentControlsList` / `ContentControlsGet` /
  `ContentControlsPatch` / `ContentControlsDelete`.

- **`Section.set_columns(*, count, equal_width=None, widths=None,
  space_pt=None, separator=None)`** + **`Section.column_count`** +
  **`Section.column_widths`** — multi-column section layout.
  python-docx issue #167 (12 comments). Routes through
  `SetSectionColumns`.

- **`Document.find_replace(pattern, replacement, *, regex=False,
  match_case=False, whole_word=False, in_=None, max_replacements=None)
  -> int`** — formatting-preserving find-and-replace primitive.
  python-docx issues #30 (39 comments), #980 (12 👍) demand the
  run-isolation primitive this provides. `in_` scopes to
  `"body"` / `"headers"` / `"footers"` / `"footnotes"` /
  `"endnotes"` / `"comments"` / `"all"`. Routes through
  `FindReplace`.

- **`Paragraph.list_id` / `Paragraph.list_level` /
  `Paragraph.list_format` / `Paragraph.list_number`** — list-item
  numbering reads. python-docx issue #471 (13 👍) demands access to
  list metadata. Routes through `NumberingGet`.

- **`Document.to_pdf(*, quality=None, destination=None,
  include_revisions=False) -> bytes`** — render to PDF via the
  Daytona-hosted LibreOffice. python-docx issue #113 was closed as
  wontfix upstream but the request keeps recurring. Routes through
  `ExportPDF` (SuperDoc handles the actual conversion).

- **`Document.export_docx(path=None, *, include_revisions=False)
  -> bytes`** (0.11.4+) — export the document's current state as
  ``.docx`` bytes, optionally writing to ``path``. Closes the gap
  left by ``Document.save(path)`` raising
  ``LocalSaveTargetNotSupportedError`` in this SDK: parity test
  harnesses and CI workflows need a programmatic .docx export to
  diff against ``python-docx`` output that doesn't require a
  human-driven Olympus UI action. Routes through ``ExportDocx`` →
  apps/api → SuperDoc's official ``doc.save({out: <tmp>})`` (the
  recommended backend export path per the SuperDoc team — Document
  API, not the browser-side ``editor.exportDocx`` shim). apps/api
  writes the session state to a temp ``.docx``, reads bytes back,
  base64-encodes for the wire, and unlinks the temp in a
  ``finally`` block. The SDK decodes and writes to ``path``.
  ``include_revisions=True`` raises ``DocxError`` pre-flight:
  ``@superdoc-dev/sdk@1.8.1``'s ``DocSaveParams`` has no
  ``includeRevisions`` field, so honoring the flag isn't possible
  through ``doc.save({out})``.

  Template seeding: ``Document.create()`` (no ``docx=``) already
  produces an exportable asset because ``POST /docs/empty`` seeds
  from the default Athena template, so ``export_docx`` works
  out-of-the-box. Pass ``docx='template.docx'`` only when you need
  brand-specific scaffolding (styles, numbering, headers, rels,
  media) baked in — not as a workaround for empty rooms.

### 0.11.4 behavior fixes for cell-inner paragraphs

Format ops on cell-inner paragraphs (`paragraph.alignment`,
`paragraph.style`, every `paragraph_format` setter, and
`paragraph.add_hyperlink`) used to cascade-fail the entire HTTP
batch. SuperDoc 1.8.1's
``SetParagraphAlignment``/``SetParagraphStyle``/``SetParagraphIndentation``/``SetParagraphSpacing``/``CreateHyperlink``
reject cell-inner block targets with ``BlockNotFoundError``, and the
applier's all-or-nothing batch model meant one cell-paragraph
mistake mid-script nuked every other unrelated create/format command
queued before it (``applied: []``).

As of 0.11.4 these setters check the paragraph proxy's ``_in_cell``
flag (set by ``_Cell.add_paragraph`` and ``_Cell.paragraphs``) and
emit ``docx.text.paragraph.CellInnerFormatNotSupportedWarning``
instead of forwarding the broken command. The format op is dropped,
the surrounding batch survives, and the workaround pointer (
``cell.text = 'value'`` to materialize, then ``cell.paragraphs[0]``
for the addressable proxy) is in the warning text. Tracked at
``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 13.

**0.11.5 follow-up: post-export OOXML rewrite.** When the parent
table was created via ``Document.add_table`` in this session
(``Table._doc_index`` set), the format setters also stash the
OOXML-shaped props (``alignment``, ``style``, ``left_twips``,
``before_twips``, etc.) on ``Session._post_export_ops`` (a
:class:`docx._postproc.PostExportOps` collector). ``Document.export_docx``
applies them via an OOXML rewrite of ``word/document.xml`` before
returning bytes — so the **exported ``.docx`` carries the formatting
the agent asked for** even though SuperDoc never accepted the wire
op. Live-session state is unchanged (Olympus collaborators don't
see the formatting until export). Template-seeded tables where
``_doc_index`` is ``None`` still warn-and-skip (no stable OOXML
address). Behavior pinned by ``tests/test_cell_inner_format_stash.py``
+ ``tests/test_postproc_cell_format_rewrite.py``.

**0.13.0: cell-inner ``Paragraph.add_run(text)`` now materializes the
text live (not just at export).** The agent's standard ``fill_cell``
helper pattern —

.. code-block:: python

    p = cell.add_paragraph("")
    r = p.add_run("Hello world")
    r.bold = True

— used to silently drop both the ``Hello world`` text AND the bold
format because ``Paragraph.add_run`` on a cell-inner paragraph
returned a stub Run with collapsed range, and SuperDoc 1.8.1
rejected the wire-level ``doc.insert`` against the cell-inner
paragraph's blockId with ``Block <id> not found``. The 0.13.0 fix
adds a ``_cell`` back-reference to every cell-inner Paragraph proxy
(set by ``_Cell.add_paragraph`` / ``_Cell.paragraphs`` /
``_Cell.iter_inner_content``). When ``Paragraph.add_run(text)`` is
called on a cell-inner paragraph with non-empty text AND the
back-ref is set, the SDK ships ``doc.insert(target=cell,
placement="insideEnd", content=paragraph-fragment-with-text)``
instead — the SAME wire path ``_Cell.add_paragraph(text)`` already
uses. SuperDoc collapses the new paragraph into the cell's single
template paragraph as an inline run; the exported DOCX expands each
non-empty inline run into its own ``<w:p>``. The returned Run is
real (non-collapsed range) and carries the new exported-paragraph
OOXML address, so subsequent ``r.bold = True``-style setters stash
to the correct cell location for the post-export OOXML rewrite.

Fallback: empty text (``add_run("")``) and paragraphs without a
``_cell`` back-ref (constructed outside the ``_Cell`` paths) still
hit the warn-and-stub fallback so the surrounding batch survives.
Wire failures inside the materialization path also fall back
silently — one ``add_run`` failure should never cascade-fail a
whole agent script.

**0.13.0: cell-inner per-run formatting + cell-inner ``add_hyperlink``
land at export time.** When a cell-inner ``Run`` has a stable OOXML
address (parent paragraph came from a ``Document.add_table`` table —
same ``_doc_index`` tracking as the cell-paragraph format stash),
every per-run setter (``run.bold = True``, ``run.italic``,
``run.font.size = Pt(11)``, ``run.font.color.rgb = …``,
``run.font.name``, ``run.font.highlight_color``,
``run.font.strike``, ``run.underline``, ``run.style``) stashes the
prop on ``Session._post_export_ops._cell_run_format_ops`` instead
of dropping it silently at the wire layer. The post-export rewrite
walks every ``<w:r>`` in the targeted cell paragraph and injects
``<w:rPr>`` carrying the props — so ``cell.text = "Total"; cell.
paragraphs[0].runs[0].bold = True`` produces a bold ``Total`` in
the exported ``.docx`` even though SuperDoc never committed the
format wire op. Apply-to-all-runs semantics: the rewrite targets
every ``<w:r>`` in the cell paragraph, because run-level addressing
inside a cell isn't recoverable after SuperDoc collapses cell-
inner inserts. Multi-run cell paragraphs with partial-run
formatting are a documented limitation — agents should use one
run per format intent.

Same export-time machinery rescues ``paragraph.add_hyperlink`` on a
cell-inner paragraph. Pre-0.13.0 the call dropped both the URL AND
the visible link text (the SDK returned a stub ``Hyperlink`` with
an empty range because ``Insert`` on a cell-inner paragraph also
fails with ``BlockNotFoundError``). As of 0.13.0 the URL + visible
text + optional tooltip + optional bookmark fragment are stashed
on ``Session._post_export_ops._cell_hyperlink_ops`` and the post-
export OOXML rewrite appends a real ``<w:hyperlink>`` to the cell
paragraph plus a matching ``Relationship`` entry in
``word/_rels/document.xml.rels``. External URLs use ``r:id`` and
get the document's built-in ``Hyperlink`` character style for the
standard blue + underline appearance; internal bookmark anchors
(``fragment="MyBookmark"`` with no ``url``) use ``w:anchor`` and
don't add a rels entry. Repeated same-URL inserts coalesce to one
rels entry so the rels file doesn't grow unboundedly. Behavior
pinned by ``tests/test_postproc_cell_run_format_rewrite.py``.

Live Olympus rendering still won't show cell-inner formatting or
hyperlinks until SuperDoc lands the corresponding wire ops —
``Document.export_docx`` is the source of truth for the
deliverable until then.

### 0.11.4 behavior fixes elsewhere

- **`Sections.__getitem__` short-circuits on empty docs.**
  ``Document.create()`` doesn't materialize a section client-side,
  so ``sections.list`` returns ``[]`` or times out at the full
  command-budget. Pre-0.11.4 ``doc.sections[0]`` either raised an
  un-contextualized ``IndexError`` from ``items[index]`` or hung
  for ~60s. The cache-then-raise path now fails fast with a clear
  workaround pointer and avoids re-issuing the slow query.
- **`Table._fresh_node_info` rotation tracking.** Each ``Table``
  created via ``Document.add_table`` records its document-order
  position as ``_doc_index``. When SuperDoc rotates the table's
  nodeId between saves, the fallback resolves the rotated address
  by position instead of always picking the last ``doc.find`` item.
  Pre-0.11.4 the "take the last" heuristic silently mapped N
  rotated proxies onto a single target, surfacing as
  ``ValidationError: Cell (r,c) not found in table table-auto-…``
  on the next cell access.
- **`set_borders` accepts string and dict.** Both
  ``cell.set_borders(top="single 0.5pt #DDDDDD")`` and
  ``cell.set_borders(top={"style": "single", "size_pt": 0.5,
  "color": "#DDDDDD"})`` work; the string form is normalized via
  ``_normalize_border_spec`` to the wire shape the server's Zod
  validator expects. Pre-0.11.4 only the dict was accepted —
  the string variant documented in the skill produced an immediate
  HTTP 400 from the server's validator.
- **`Run.add_field` segments shape.** ``run.add_field("PAGE")`` (and
  every other field kind) now emits ``at.segments`` with
  ``[{blockId, start, end}]`` instead of the ``{kind: "selection",
  start, end}`` cursor envelope used by other create-ops.
  SuperDoc's ``doc.fields.insert`` rejects the cursor form with
  ``SuperDocCliError: fields insert:at.segments is required``;
  pre-0.11.4 the call took down the whole batch on every flush.

### 0.11.5 — `REF` field round-trip preservation (post-export rewrite)

SuperDoc 1.23.1 / SDK 1.8.1 strips ``REF`` field codes
(``<w:fldChar>`` / ``<w:instrText REF …>`` / result-runs / end
``<w:fldChar>``) on import. On the Paul Weiss Purchase Agreement
this loses all 301 cross-references — readers see chains of empty
commas instead of "Section 3.02(b)" cross-refs. Tracked at
``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 18.

As of 0.11.5, ``Document.create(docx=template.docx)`` scans the
local template bytes with a stdlib zipfile + xml.etree parser and
captures every ``<w:p>`` containing 1+ REF fields. Captures are
stashed on ``Session._post_export_ops._captured_refs`` (list of
:class:`docx._postproc.CapturedRefParagraph`). On
``Document.export_docx``, the post-export OOXML rewrite walks the
exported body; if any captured paragraph's exported counterpart has
fewer REFs AND fingerprint-matches (plain-text content excluding
field result runs), the exported ``<w:p>`` element is replaced
wholesale with the captured XML. Behavior pinned by
``tests/test_postproc_ref_restore.py``.

Limitations: (1) restoration is in-process only — works when the
same Python process that called ``Document.create(docx=...)`` also
calls ``export_docx``. Cross-process flows (agent A creates, agent
B exports) need agora-side persistence (separate follow-up). (2)
Paragraph-wholesale replacement preserves the source paragraph but
overwrites any SuperDoc in-paragraph edits — for round-trip
preservation (the primary use case) this is exactly right. (3) Only
top-level body paragraphs are scanned; cell-inner REFs aren't
captured (rare for legal cross-references).

These additions are surfaced under their natural python-docx-shaped
names. When python-docx upstream eventually ships any of them
natively, the SDK should swap to the upstream signature in place;
this section is the canonical reference for what each Athena
extension wires up.

### If you need a deviation

If there is a genuine technical reason why a deviation from python-docx is necessary:

1. **Stop and ask the user** before implementing
2. Explain what the deviation is and why it's needed
3. Get explicit confirmation that the deviation is acceptable
4. Document the deviation in the "Intentionally omitted" list above

## Architecture (0.5.0+)

This is a **thin HTTP client** that mimics the sync python-docx API.

- Sync façade (matches python-docx) — `doc.save()`, `paragraph.add_run()`
- Every internal call constructs a typed `Command` dataclass
  (`docx.commands`) and ships it through a `CommandBuffer`
  (`docx._buffer`) which POSTs to docx-studio's `/docs/:id/commands`.
- HTTP transport: `requests.Session` with a Retry (3 attempts, exponential
  backoff `factor=2.0` plus 0.5s jitter when urllib3 ≥2.0 supports it,
  ~14s total budget, 429/502/503/504). Once retries are exhausted on
  502/503/504, the SDK raises `DocxStudioTemporarilyUnavailable`
  (a `SessionError`) carrying `http_status` and an optional
  `retry_after_seconds` parsed from the server's `Retry-After` header.
  Agent code can catch this typed error to back off at the agent level
  vs. treating it as a script bug. The legacy `transport="direct"`
  (embedded Superdoc CLI + y-websocket from Python) was removed in
  0.5.0; agent pods no longer embed Superdoc.
- **Transparent batching (0.7.0+):** Create* commands
  (`CreateParagraph`, `CreateHeading`, `CreateTable`, `CreateImage`)
  ALWAYS pre-mint a client-side UUID (`client_node_id`) and defer
  through the buffer. The applier resolves UUIDs to real SuperDoc
  ids via per-batch `clientIdMap` on flush, and the buffer rewrites
  each proxy's `_node_id` in-place. Net result: 30 `add_paragraph`
  calls = 1 HTTP request, with no explicit `batch()` context manager
  in the public API (1:1 python-docx parity).
- Flush triggers: queries (`BlocksList`, `Find`, `GetNodeById`, …)
  drain pending ops before running; the 100 ms idle timer fires on
  inactivity so collab updates stream live; `Document.save()` and
  the context-manager exit drain explicitly; `docx.flush_all()` is
  the Daytona-prelude hook that flushes every live buffer in the
  process.
- **Insert deferral (0.8.0+):** `Insert` was removed from the
  response-bearing set because every in-tree caller
  (`Paragraph._insert_run_text_segments`, `Run.add_text`, `_Cell.text`)
  ignores the response — the Run proxy wraps a known client-side range
  and doesn't need the server's echoed node id. Net result: a styled
  run (one `add_run` + 6 format setters) ships as 1 HTTP request
  instead of 2. The remaining response-bearing ops without a client id
  (`ListsCreate`, `ListsAttach`, `CommentsCreate`, `CommentsPatch`,
  `TrackChangesDecide`) keep their eager-flush semantics so callers
  reading back ids still see real data. A `Document.add_paragraph`
  with `style="List Bullet"` flushes the queued CreateParagraph in
  the same batch as the follow-up `ListsCreate` — still one HTTP
  request per logical operation.
- **Plain-text cell fast path (0.8.0+):** `_Cell.text = value` skips
  the eager `doc.markdownToFragment` query when ``value`` contains no
  markdown control characters (the dominant case for tabular data —
  numbers, labels, currency strings). The fragment is built locally
  and the follow-up `doc.insert` is buffered, so plain cell
  assignments are 0 HTTP requests until the next flush. See
  ``docx.table._is_plain_text`` for the trigger predicate.
- **Partial-failure cascade fix (0.9.0+):** when an HTTP batch raises
  on a 207 partial-failure (e.g. one cell-paragraph mistake mid-script),
  the SDK now rewrites ``proxy_id_refs`` for the ``applied`` prefix
  the server reports as successful — BEFORE re-raising. Pre-0.9.0 the
  rewrite was inside the success-path-only branch, so every Create that
  committed server-side left its Python proxy stuck on the client UUID;
  the next batch shipped dead client UUIDs and the cascade restarted.
  Preview-session ``thread_bafba02b`` turned one cell-paragraph error
  into thirteen downstream "Block not found" failures + a
  ``DOCUMENT_IDENTITY_CONFLICT`` before this fix. The path goes
  ``_http_post_json`` (attaches ``applied[]`` via
  ``DocxError.with_partial_applied``) → ``CommandBuffer.flush`` /
  ``_eager_flush_with`` (catches ``DocxError``, drains the prefix
  through ``_apply_proxy_id_rewrites``, re-raises). See
  ``tests/test_partial_failure_cascade.py`` for the contract.
- **Table-query hint (0.9.0+):** ``BlockNotFoundError`` on
  ``TablesGet`` / ``TablesGetCells`` / etc. used to fall through with
  no hint (the cell-paragraph workaround doesn't apply). Now carries
  a dedicated "stale client-table-UUID" hint pointing at the actual
  recovery (``doc.save()`` to drain pending + re-anchor proxies). See
  ``_TABLE_CLIENT_ID_HINT`` in ``docx/_http_doc.py``.
- The path-proxy in `_http_doc.py` is an internal translation layer:
  call sites that look like `await self._session.doc.create.paragraph(p)`
  resolve to `CommandBuffer.call(CreateParagraph(**p))`. Rewriting call
  sites to construct `Command` dataclasses directly is a possible
  follow-up — the wire format is typed end-to-end either way.
- **Programmatic Tool Calling (PTC):** every `CommandBuffer.call` and
  `flush` emits begin/end events to agora via `docx/_ptc.py` when run
  inside a Daytona sandbox with `ATHENA_PTC_URL` set. Each method call
  surfaces as a nested sub-tool-card under the parent
  `run_python_code` tool. See
  [`docs/PROGRAMMATIC_TOOL_CALLING_GUIDE.md`](../../docs/PROGRAMMATIC_TOOL_CALLING_GUIDE.md)
  at the monorepo root.

## Development

```bash
uv venv
uv pip install -e ".[dev]"
uv run pytest tests/ -x -q
uv run pytest tests/test_python_docx_api_parity.py -v
```
