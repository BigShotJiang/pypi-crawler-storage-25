"""Main client entrypoint for the free Qanuni SDK distribution."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any, Literal

import yaml  # type: ignore[import-untyped]

from qanuni.catalog import ToolAccessStatus, ToolMetadata, list_tools
from qanuni.core.config import QanuniConfig
from qanuni.providers.base_provider import BaseProvider
from qanuni.providers.openai_provider import OpenAIProvider
from qanuni.tools.compliance import ComplianceTools
from qanuni.tools.contracts import ContractTools
from qanuni.tools.drafting import DraftingTools
from qanuni.tools.labor import LaborTools
from qanuni.tools.policies import PolicyTools


class LegalClient:
    """Expose the public SDK namespaces used by application developers.

    Args:
        provider_factory: Optional zero-argument callable that returns a provider instance.
        **kwargs: Direct configuration overrides forwarded into `QanuniConfig`.

    Returns:
        None.

    Raises:
        QanuniConfigError: If the provided configuration is invalid.
    """

    def __init__(
        self,
        *,
        provider_factory: Callable[[], BaseProvider] | None = None,
        **kwargs: Any,
    ) -> None:
        """Create a Qanuni client from direct keyword configuration.

        Args:
            provider_factory: Optional zero-argument callable that returns a provider instance.
            **kwargs: Direct configuration overrides forwarded into `QanuniConfig`.

        Returns:
            None.

        Raises:
            QanuniConfigError: If the provided configuration is invalid.
        """
        self._config = QanuniConfig(**kwargs)
        self._provider_factory: Callable[[], BaseProvider] | None = provider_factory
        self._provider: BaseProvider | None = None
        self._labor: LaborTools | None = None
        self._contracts: ContractTools | None = None
        self._compliance: ComplianceTools | None = None
        self._drafting: DraftingTools | None = None
        self._policies: PolicyTools | None = None

    @classmethod
    def from_config(cls, path: str | Path) -> LegalClient:
        """Create a client from a YAML configuration file.

        Args:
            path: File-system path to a `.qanuni.yaml`-style configuration file.

        Returns:
            A fully initialized `LegalClient`.

        Raises:
            OSError: If the configuration file cannot be read.
            yaml.YAMLError: If the configuration file contains invalid YAML.
        """
        config_path = Path(path)
        raw: dict[str, Any] = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}

        data: dict[str, Any] = {
            "api_key": raw.get("openai", {}).get("api_key") or raw.get("api_key"),
            "legal_reference_catalog_dir": (
                raw.get("qanuni", {}).get("legal_reference_catalog_dir")
                or raw.get("legal_reference_catalog_dir")
            ),
            "model": raw.get("openai", {}).get("model", raw.get("model", "gpt-5.5")),
            "language": raw.get("locale", {}).get("language", raw.get("language", "ar")),
            "jurisdiction": raw.get("locale", {}).get(
                "jurisdiction", raw.get("jurisdiction", "SA")
            ),
            "timeout": raw.get("performance", {}).get("timeout", raw.get("timeout", 90)),
            "max_retries": raw.get("performance", {}).get(
                "max_retries", raw.get("max_retries", 2)
            ),
            "max_output_tokens": raw.get("openai", {}).get(
                "max_tokens", raw.get("max_output_tokens", 2500)
            ),
            "reasoning_effort": raw.get("openai", {}).get(
                "reasoning_effort", raw.get("reasoning_effort", "medium")
            ),
            "verbosity": raw.get("openai", {}).get(
                "verbosity", raw.get("verbosity", "medium")
            ),
            "verbose": raw.get("logging", {}).get("verbose", raw.get("verbose", False)),
            "log_level": raw.get("logging", {}).get("level", raw.get("log_level", "WARNING")),
            "tool_overrides": raw.get("tools", {}),
        }
        return cls(**data)

    @property
    def config(self) -> QanuniConfig:
        """Return the effective resolved SDK configuration.

        Args:
            None.

        Returns:
            The resolved SDK configuration object.

        Raises:
            None.
        """
        return self._config

    def get_provider(self) -> BaseProvider:
        """Lazily construct and reuse the configured provider instance.

        Args:
            None.

        Returns:
            The configured provider instance.

        Raises:
            QanuniConfigError: If the provider cannot be created from current settings.
        """
        if self._provider is None:
            if self._provider_factory is not None:
                self._provider = self._provider_factory()
            else:
                self._provider = OpenAIProvider(self._config)
        return self._provider

    def list_tools(
        self,
        *,
        tier: Literal["free", "pro"] | None = None,
        namespace: str | None = None,
        category: str | None = None,
    ) -> list[ToolMetadata]:
        """List implemented tools available in the current SDK build.

        Args:
            tier: Optional commercial tier filter.
            namespace: Optional top-level namespace filter.
            category: Optional product-category filter.

        Returns:
            A list of implemented tool metadata records.

        Raises:
            None.
        """
        return list_tools(tier=tier, namespace=namespace, category=category)

    def list_tool_access(
        self,
        *,
        tier: Literal["free", "pro"] | None = None,
        namespace: str | None = None,
        category: str | None = None,
    ) -> list[ToolAccessStatus]:
        """List implemented tools together with current access availability.

        Args:
            tier: Optional commercial tier filter.
            namespace: Optional top-level namespace filter.
            category: Optional product-category filter.

        Returns:
            A list of tool records annotated with current access status.

        Raises:
            None.
        """
        return [
            ToolAccessStatus(
                tool_id=tool_record.tool_id,
                namespace=tool_record.namespace,
                category=tool_record.category,
                tier=tool_record.tier,
                description=tool_record.description,
                implementation=tool_record.implementation,
                available=True,
                reason=None,
            )
            for tool_record in list_tools(
                tier=tier,
                namespace=namespace,
                category=category,
            )
        ]

    @property
    def labor(self) -> LaborTools:
        """Access labor-law tools.

        Args:
            None.

        Returns:
            The lazily initialized labor namespace.

        Raises:
            QanuniConfigError: If provider construction fails during lazy initialization.
        """
        if self._labor is None:
            self._labor = LaborTools(self._config, self.get_provider)
        return self._labor

    @property
    def contracts(self) -> ContractTools:
        """Access contract and commercial tools.

        Args:
            None.

        Returns:
            The lazily initialized contracts namespace.

        Raises:
            QanuniConfigError: If provider construction fails during lazy initialization.
        """
        if self._contracts is None:
            self._contracts = ContractTools(self._config, self.get_provider)
        return self._contracts

    @property
    def compliance(self) -> ComplianceTools:
        """Access compliance and regulatory tools.

        Args:
            None.

        Returns:
            The lazily initialized compliance namespace.

        Raises:
            QanuniConfigError: If provider construction fails during lazy initialization.
        """
        if self._compliance is None:
            self._compliance = ComplianceTools(self._config, self.get_provider)
        return self._compliance

    @property
    def drafting(self) -> DraftingTools:
        """Access legal drafting and analysis tools.

        Args:
            None.

        Returns:
            The lazily initialized drafting namespace.

        Raises:
            QanuniConfigError: If provider construction fails during lazy initialization.
        """
        if self._drafting is None:
            self._drafting = DraftingTools(self._config, self.get_provider)
        return self._drafting

    @property
    def policies(self) -> PolicyTools:
        """Access policies and HR-document tools.

        Args:
            None.

        Returns:
            The lazily initialized policies namespace.

        Raises:
            QanuniConfigError: If provider construction fails during lazy initialization.
        """
        if self._policies is None:
            self._policies = PolicyTools(self._config, self.get_provider)
        return self._policies
