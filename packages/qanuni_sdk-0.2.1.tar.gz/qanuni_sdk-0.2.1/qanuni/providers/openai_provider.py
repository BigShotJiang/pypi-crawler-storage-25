"""OpenAI-backed provider implementation."""

from __future__ import annotations

import json
from typing import Any, cast

from openai import APIError as OpenAIAPIError
from openai import AsyncOpenAI, OpenAI
from openai.lib._parsing._responses import type_to_text_format_param
from pydantic import BaseModel

from qanuni.core.config import QanuniConfig
from qanuni.core.exceptions import (
    ErrorCode,
    QanuniAPIError,
    QanuniConfigError,
    QanuniOutputError,
    QanuniParseError,
)
from qanuni.core.output_parser import OutputParser
from qanuni.models.common import ToolRuntimeConfig
from qanuni.providers.base_provider import BaseProvider, ProviderResponse, ProviderUsage


class OpenAIProvider(BaseProvider):
    """Implement the provider interface using the OpenAI Responses API.

    Args:
        config: Resolved SDK configuration used to initialize OpenAI clients.

    Returns:
        None.

    Raises:
        QanuniConfigError: If the configuration does not include a usable API key.
    """

    def __init__(self, config: QanuniConfig) -> None:
        """Create sync and async OpenAI clients from the resolved SDK configuration.

        Args:
            config: Resolved SDK configuration used to initialize OpenAI clients.

        Returns:
            None.

        Raises:
            QanuniConfigError: If the configuration does not include a usable API key.
        """
        api_key: str | None = config.api_key_value()
        if api_key is None:
            raise QanuniConfigError(
                "OpenAIProvider requires an API key.",
                error_code=ErrorCode.CONFIG_API_KEY_MISSING,
                details={"provider": "openai"},
            )
        self._config = config
        self._client = OpenAI(
            api_key=api_key,
            timeout=config.timeout,
            max_retries=config.max_retries,
        )
        self._aclient = AsyncOpenAI(
            api_key=api_key,
            timeout=config.timeout,
            max_retries=config.max_retries,
        )

    def generate_structured(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        response_model: type[BaseModel],
        runtime: ToolRuntimeConfig,
    ) -> ProviderResponse[Any]:
        """Generate structured output using the sync OpenAI client.

        Args:
            system_prompt: Rendered system prompt sent to the provider.
            user_prompt: Rendered user prompt sent to the provider.
            response_model: Structured response model expected from the provider.
            runtime: Runtime provider overrides for the current call.

        Returns:
            A normalized structured provider response.

        Raises:
            QanuniAPIError: If the upstream OpenAI call fails.
            QanuniOutputError: If the provider returns unusable structured output.
        """
        try:
            if hasattr(self._client.responses, "create"):
                return self._generate_via_native_structured_output(
                    client=self._client,
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                    response_model=response_model,
                    runtime=runtime,
                )

            return self._generate_via_json_fallback(
                client=self._client,
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                response_model=response_model,
                runtime=runtime,
            )
        except OpenAIAPIError as exc:
            raise QanuniAPIError(
                str(exc),
                status_code=getattr(exc, "status_code", None),
                error_code=ErrorCode.API_PROVIDER_FAILURE,
                details={"provider": "openai", "operation": "generate_structured"},
            ) from exc

    async def agenerate_structured(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        response_model: type[BaseModel],
        runtime: ToolRuntimeConfig,
    ) -> ProviderResponse[Any]:
        """Generate structured output using the async OpenAI client.

        Args:
            system_prompt: Rendered system prompt sent to the provider.
            user_prompt: Rendered user prompt sent to the provider.
            response_model: Structured response model expected from the provider.
            runtime: Runtime provider overrides for the current call.

        Returns:
            A normalized structured provider response.

        Raises:
            QanuniAPIError: If the upstream OpenAI call fails.
            QanuniOutputError: If the provider returns unusable structured output.
        """
        try:
            if hasattr(self._aclient.responses, "create"):
                return await self._agenerate_via_native_structured_output(
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                    response_model=response_model,
                    runtime=runtime,
                )

            return await self._agenerate_via_json_fallback(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                response_model=response_model,
                runtime=runtime,
            )
        except OpenAIAPIError as exc:
            raise QanuniAPIError(
                str(exc),
                status_code=getattr(exc, "status_code", None),
                error_code=ErrorCode.API_PROVIDER_FAILURE,
                details={"provider": "openai", "operation": "agenerate_structured"},
            ) from exc

    def _generate_via_native_structured_output(
        self,
        *,
        client: OpenAI,
        system_prompt: str,
        user_prompt: str,
        response_model: type[BaseModel],
        runtime: ToolRuntimeConfig,
    ) -> ProviderResponse[Any]:
        """Call Responses.create with strict structured output and recover once on truncation.

        Args:
            client: Sync OpenAI client used for the request.
            system_prompt: Rendered system prompt sent to the provider.
            user_prompt: Rendered user prompt sent to the provider.
            response_model: Structured response model expected from the provider.
            runtime: Runtime provider overrides for the current call.

        Returns:
            A normalized structured provider response.

        Raises:
            QanuniParseError: If the model returns invalid JSON after retry logic.
            QanuniOutputError: If the model output still cannot satisfy the schema.
        """
        request_runtime: ToolRuntimeConfig
        for attempt_index, request_runtime in enumerate(
            self._structured_runtime_attempts(runtime),
            start=1,
        ):
            response = client.responses.create(
                **self._structured_request_kwargs(
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                    response_model=response_model,
                    runtime=request_runtime,
                )
            )
            raw_text: str | None = getattr(response, "output_text", None)
            if raw_text is None:
                raise QanuniOutputError(
                    "OpenAI structured response did not include output_text.",
                    error_code=ErrorCode.API_OUTPUT_TEXT_MISSING,
                    details={
                        "provider": "openai",
                        "model": request_runtime.model or self._config.model,
                        "response_model": response_model.__name__,
                        "response_status": getattr(response, "status", None),
                    },
                )

            try:
                data = OutputParser.parse(raw_text, response_model)
            except (QanuniParseError, QanuniOutputError) as exc:
                if self._should_retry_structured_response(
                    error=exc,
                    response=response,
                    attempt_index=attempt_index,
                    total_attempts=2,
                ):
                    continue
                raise self._enrich_structured_error(
                    error=exc,
                    raw_text=raw_text,
                    response=response,
                    response_model=response_model,
                    runtime=request_runtime,
                ) from exc

            return ProviderResponse(
                data=data,
                model=request_runtime.model or self._config.model,
                usage=self._usage_from_response(response),
                raw_text=raw_text,
            )

        raise QanuniOutputError(
            "OpenAI structured output retry logic exhausted unexpectedly.",
            error_code=ErrorCode.OUTPUT_SCHEMA_MISMATCH,
            details={"provider": "openai", "response_model": response_model.__name__},
        )

    async def _agenerate_via_native_structured_output(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        response_model: type[BaseModel],
        runtime: ToolRuntimeConfig,
    ) -> ProviderResponse[Any]:
        """Async counterpart to sync structured-output recovery logic.

        Args:
            system_prompt: Rendered system prompt sent to the provider.
            user_prompt: Rendered user prompt sent to the provider.
            response_model: Structured response model expected from the provider.
            runtime: Runtime provider overrides for the current call.

        Returns:
            A normalized structured provider response.

        Raises:
            QanuniParseError: If the model returns invalid JSON after retry logic.
            QanuniOutputError: If the model output still cannot satisfy the schema.
        """
        request_runtime: ToolRuntimeConfig
        for attempt_index, request_runtime in enumerate(
            self._structured_runtime_attempts(runtime),
            start=1,
        ):
            response = await self._aclient.responses.create(
                **self._structured_request_kwargs(
                    system_prompt=system_prompt,
                    user_prompt=user_prompt,
                    response_model=response_model,
                    runtime=request_runtime,
                )
            )
            raw_text: str | None = getattr(response, "output_text", None)
            if raw_text is None:
                raise QanuniOutputError(
                    "OpenAI structured response did not include output_text.",
                    error_code=ErrorCode.API_OUTPUT_TEXT_MISSING,
                    details={
                        "provider": "openai",
                        "model": request_runtime.model or self._config.model,
                        "response_model": response_model.__name__,
                        "response_status": getattr(response, "status", None),
                    },
                )

            try:
                data = OutputParser.parse(raw_text, response_model)
            except (QanuniParseError, QanuniOutputError) as exc:
                if self._should_retry_structured_response(
                    error=exc,
                    response=response,
                    attempt_index=attempt_index,
                    total_attempts=2,
                ):
                    continue
                raise self._enrich_structured_error(
                    error=exc,
                    raw_text=raw_text,
                    response=response,
                    response_model=response_model,
                    runtime=request_runtime,
                ) from exc

            return ProviderResponse(
                data=data,
                model=request_runtime.model or self._config.model,
                usage=self._usage_from_response(response),
                raw_text=raw_text,
            )

        raise QanuniOutputError(
            "OpenAI structured output retry logic exhausted unexpectedly.",
            error_code=ErrorCode.OUTPUT_SCHEMA_MISMATCH,
            details={"provider": "openai", "response_model": response_model.__name__},
        )

    def _generate_via_json_fallback(
        self,
        *,
        client: OpenAI,
        system_prompt: str,
        user_prompt: str,
        response_model: type[BaseModel],
        runtime: ToolRuntimeConfig,
    ) -> ProviderResponse[Any]:
        """Fallback to JSON-schema prompting when direct parsing helpers are unavailable.

        Args:
            client: Sync OpenAI client used for the fallback request.
            system_prompt: Rendered system prompt sent to the provider.
            user_prompt: Rendered user prompt sent to the provider.
            response_model: Structured response model expected from the provider.
            runtime: Runtime provider overrides for the current call.

        Returns:
            A normalized structured provider response.

        Raises:
            QanuniOutputError: If fallback output text is missing or invalid.
        """
        schema: str = json.dumps(response_model.model_json_schema(), ensure_ascii=False)
        response = client.responses.create(
            model=runtime.model or self._config.model,
            input=cast(
                Any,
                self._input_messages(
                    (
                        f"{system_prompt}\n\n"
                        "Return valid JSON only. It must match this schema exactly:\n"
                        f"{schema}"
                    ),
                    user_prompt,
                ),
            ),
            max_output_tokens=runtime.max_output_tokens or self._config.max_output_tokens,
        )
        raw_text: str | None = getattr(response, "output_text", None)
        if raw_text is None:
            raise QanuniOutputError(
                "OpenAI fallback response did not include output_text.",
                error_code=ErrorCode.API_OUTPUT_TEXT_MISSING,
                details={"provider": "openai", "model": runtime.model or self._config.model},
            )
        data = OutputParser.parse(raw_text, response_model)
        return ProviderResponse(
            data=data,
            model=runtime.model or self._config.model,
            usage=self._usage_from_response(response),
            raw_text=raw_text,
        )

    async def _agenerate_via_json_fallback(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        response_model: type[BaseModel],
        runtime: ToolRuntimeConfig,
    ) -> ProviderResponse[Any]:
        """Async fallback to JSON-schema prompting when direct parsing helpers are unavailable.

        Args:
            system_prompt: Rendered system prompt sent to the provider.
            user_prompt: Rendered user prompt sent to the provider.
            response_model: Structured response model expected from the provider.
            runtime: Runtime provider overrides for the current call.

        Returns:
            A normalized structured provider response.

        Raises:
            QanuniOutputError: If fallback output text is missing or invalid.
        """
        schema: str = json.dumps(response_model.model_json_schema(), ensure_ascii=False)
        response = await self._aclient.responses.create(
            model=runtime.model or self._config.model,
            input=cast(
                Any,
                self._input_messages(
                    (
                        f"{system_prompt}\n\n"
                        "Return valid JSON only. It must match this schema exactly:\n"
                        f"{schema}"
                    ),
                    user_prompt,
                ),
            ),
            max_output_tokens=runtime.max_output_tokens or self._config.max_output_tokens,
        )
        raw_text: str | None = getattr(response, "output_text", None)
        if raw_text is None:
            raise QanuniOutputError(
                "OpenAI fallback response did not include output_text.",
                error_code=ErrorCode.API_OUTPUT_TEXT_MISSING,
                details={"provider": "openai", "model": runtime.model or self._config.model},
            )
        data = OutputParser.parse(raw_text, response_model)
        return ProviderResponse(
            data=data,
            model=runtime.model or self._config.model,
            usage=self._usage_from_response(response),
            raw_text=raw_text,
        )

    def _structured_request_kwargs(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        response_model: type[BaseModel],
        runtime: ToolRuntimeConfig,
    ) -> dict[str, Any]:
        """Build request kwargs for strict structured output generation.

        Args:
            system_prompt: Rendered system prompt content.
            user_prompt: Rendered user prompt content.
            response_model: Structured response model expected from the provider.
            runtime: Runtime provider overrides for the current call.

        Returns:
            A dictionary ready to pass into `responses.create`.

        Raises:
            None.
        """
        request_kwargs: dict[str, Any] = {
            "model": runtime.model or self._config.model,
            "input": cast(Any, self._input_messages(system_prompt, user_prompt)),
            "max_output_tokens": runtime.max_output_tokens or self._config.max_output_tokens,
            "text": {
                "format": type_to_text_format_param(response_model),
                "verbosity": runtime.verbosity or self._config.verbosity,
            },
        }
        if runtime.reasoning_effort is not None:
            request_kwargs["reasoning"] = {"effort": runtime.reasoning_effort}
        return request_kwargs

    def _structured_runtime_attempts(
        self,
        runtime: ToolRuntimeConfig,
    ) -> tuple[ToolRuntimeConfig, ...]:
        """Build the initial runtime and a single larger retry budget.

        Args:
            runtime: Runtime provider overrides for the current call.

        Returns:
            A tuple containing the initial runtime and one retry runtime.

        Raises:
            None.
        """
        base_tokens: int = runtime.max_output_tokens or self._config.max_output_tokens
        retry_tokens: int = min(max(base_tokens * 2, base_tokens + 1000), 6000)
        retry_runtime: ToolRuntimeConfig = runtime.model_copy(
            update={
                "max_output_tokens": retry_tokens,
                "verbosity": "low",
            }
        )
        if retry_tokens == base_tokens and (runtime.verbosity or self._config.verbosity) == "low":
            return (runtime,)
        return (runtime, retry_runtime)

    def _should_retry_structured_response(
        self,
        *,
        error: QanuniParseError | QanuniOutputError,
        response: Any,
        attempt_index: int,
        total_attempts: int,
    ) -> bool:
        """Decide whether a structured-response failure looks recoverable.

        Args:
            error: The parse or schema error raised for the current response.
            response: Raw OpenAI response object.
            attempt_index: One-based attempt number currently being processed.
            total_attempts: Total number of allowed attempts.

        Returns:
            `True` when the provider should retry once with a larger token budget.

        Raises:
            None.
        """
        if attempt_index >= total_attempts:
            return False
        incomplete_reason: str | None = self._incomplete_reason(
            getattr(response, "incomplete_details", None)
        )
        if incomplete_reason == "max_output_tokens":
            return True
        return isinstance(error, QanuniParseError) and self._looks_like_truncated_json(error)

    def _enrich_structured_error(
        self,
        *,
        error: QanuniParseError | QanuniOutputError,
        raw_text: str,
        response: Any,
        response_model: type[BaseModel],
        runtime: ToolRuntimeConfig,
    ) -> QanuniParseError | QanuniOutputError:
        """Attach provider context to structured-output failures.

        Args:
            error: Original parse or schema error raised by the parser.
            raw_text: Raw text returned by the provider.
            response: Raw OpenAI response object.
            response_model: Structured response model expected from the provider.
            runtime: Runtime provider overrides used for the failing request.

        Returns:
            An enriched Qanuni parse or output error.

        Raises:
            None.
        """
        details: dict[str, Any] = {
            **error.details,
            "provider": "openai",
            "model": runtime.model or self._config.model,
            "response_model": response_model.__name__,
            "response_status": getattr(response, "status", None),
            "incomplete_reason": self._incomplete_reason(
                getattr(response, "incomplete_details", None)
            ),
            "max_output_tokens": runtime.max_output_tokens or self._config.max_output_tokens,
            "suggestion": (
                "Increase max_output_tokens or reduce verbosity for large structured outputs."
            ),
        }
        if isinstance(error, QanuniParseError):
            return QanuniParseError(
                "OpenAI returned invalid structured JSON for the requested schema.",
                raw_response=raw_text,
                error_code=error.error_code,
                details=details,
            )
        return QanuniOutputError(
            "OpenAI returned structured output that did not satisfy the requested schema.",
            error_code=error.error_code,
            details=details,
        )

    @staticmethod
    def _incomplete_reason(incomplete_details: Any) -> str | None:
        """Extract the incomplete reason from OpenAI response metadata.

        Args:
            incomplete_details: The provider's incomplete-details payload.

        Returns:
            The incomplete reason if present, otherwise `None`.

        Raises:
            None.
        """
        if incomplete_details is None:
            return None
        if isinstance(incomplete_details, dict):
            value: Any = incomplete_details.get("reason")
            return value if isinstance(value, str) else None
        reason: Any = getattr(incomplete_details, "reason", None)
        return reason if isinstance(reason, str) else None

    @staticmethod
    def _looks_like_truncated_json(error: QanuniParseError) -> bool:
        """Heuristically detect JSON that was likely cut off mid-generation.

        Args:
            error: Parsing error raised from a raw provider response.

        Returns:
            `True` when the payload looks truncated rather than fundamentally malformed.

        Raises:
            None.
        """
        message: str = str(error)
        raw_text: str = error.raw_response or ""
        return (
            "EOF while parsing" in message
            or "Unterminated string" in message
            or (bool(raw_text) and raw_text.rstrip()[-1:] not in {"}", "]"})
        )

    @staticmethod
    def _input_messages(system_prompt: str, user_prompt: str) -> list[dict[str, str]]:
        """Build the minimal Responses API input message payload.

        Args:
            system_prompt: Rendered system prompt content.
            user_prompt: Rendered user prompt content.

        Returns:
            A list of provider message payload dictionaries.

        Raises:
            None.
        """
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    @staticmethod
    def _usage_from_response(response: Any) -> ProviderUsage:
        """Normalize provider usage information from the OpenAI response object.

        Args:
            response: OpenAI response object returned by the SDK.

        Returns:
            A normalized provider-usage object.

        Raises:
            None.
        """
        usage: Any = getattr(response, "usage", None)
        if usage is None:
            return ProviderUsage()
        return ProviderUsage(
            input_tokens=getattr(usage, "input_tokens", None),
            output_tokens=getattr(usage, "output_tokens", None),
            total_tokens=getattr(usage, "total_tokens", None),
        )
