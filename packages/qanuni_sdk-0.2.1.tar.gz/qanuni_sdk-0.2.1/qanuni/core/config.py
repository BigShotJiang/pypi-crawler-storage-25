"""Configuration model for the free Qanuni distribution."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

from qanuni.models.common import ToolRuntimeConfig


class QanuniConfig(BaseSettings):
    """Store resolved SDK configuration for the free edition.

    Args:
        None.

    Returns:
        None.

    Raises:
        None.
    """

    api_key: SecretStr | None = Field(default=None, alias="OPENAI_API_KEY")
    legal_reference_catalog_dir: Path | None = Field(
        default=None,
        alias="QANUNI_LEGAL_REFERENCE_CATALOG_DIR",
    )

    model: str = Field(default="gpt-5.5", alias="QANUNI_MODEL")
    language: str = Field(default="ar", alias="QANUNI_LANGUAGE")
    jurisdiction: str = Field(default="SA", alias="QANUNI_JURISDICTION")

    timeout: int = Field(default=90, alias="QANUNI_TIMEOUT")
    max_retries: int = Field(default=2, alias="QANUNI_MAX_RETRIES")
    max_output_tokens: int = Field(default=2500, alias="QANUNI_MAX_OUTPUT_TOKENS")
    reasoning_effort: Literal["low", "medium", "high"] = Field(
        default="medium",
        alias="QANUNI_REASONING_EFFORT",
    )
    verbosity: Literal["low", "medium", "high"] = Field(
        default="medium",
        alias="QANUNI_VERBOSITY",
    )

    verbose: bool = Field(default=False, alias="QANUNI_VERBOSE")
    log_level: str = Field(default="WARNING", alias="QANUNI_LOG_LEVEL")
    tool_overrides: dict[str, ToolRuntimeConfig] = Field(default_factory=dict)

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
        populate_by_name=True,
    )

    def api_key_value(self) -> str | None:
        """Return the decrypted API key value when configured.

        Args:
            None.

        Returns:
            The decrypted API key value, or `None` when no key is configured.

        Raises:
            None.
        """
        if self.api_key is None:
            return None
        return self.api_key.get_secret_value()
