"""Base abstractions shared by all tools."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from datetime import UTC, datetime
from time import perf_counter
from typing import Any, ClassVar, Generic, TypeVar

from pydantic import BaseModel, ValidationError

from qanuni.core.config import QanuniConfig
from qanuni.core.exceptions import ErrorCode, QanuniError, QanuniValidationError
from qanuni.core.prompt_loader import PromptLoader, PromptRender
from qanuni.legal_references import LegalReferenceLoader
from qanuni.legal_references.models import LegalReferenceMode, LegalReferenceProfile
from qanuni.models.common import BaseResult, ToolRuntimeConfig
from qanuni.providers.base_provider import BaseProvider, ProviderResponse

InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT", bound=BaseResult)


class BaseTool(ABC, Generic[InputT, OutputT]):
    """Provide shared execution behavior for all SDK tools.

    Args:
        config: Resolved SDK configuration object.
        provider_factory: Zero-argument callable that returns a provider instance.

    Returns:
        None.

    Raises:
        None.
    """

    TOOL_ID: ClassVar[str]
    TIER: ClassVar[str] = "free"
    INPUT_MODEL: ClassVar[type[InputT]]
    OUTPUT_MODEL: ClassVar[type[OutputT]]
    PROMPT_FILE: ClassVar[str | None] = None
    LEGAL_REFERENCE_FILE: ClassVar[str | None] = None

    def __init__(
        self,
        config: QanuniConfig,
        provider_factory: Callable[[], BaseProvider],
    ) -> None:
        """Store shared configuration and the deferred provider factory.

        Args:
            config: Resolved SDK configuration object.
            provider_factory: Zero-argument callable that returns a provider instance.

        Returns:
            None.

        Raises:
            None.
        """
        self._config = config
        self._provider_factory = provider_factory
        self._legal_reference_profile: LegalReferenceProfile | None = None
        self._legal_reference_profile_loaded: bool = False

    def run(
        self,
        data: InputT | dict[str, Any] | None = None,
        /,
        *,
        runtime: ToolRuntimeConfig | None = None,
        **kwargs: Any,
    ) -> OutputT:
        """Validate input, execute the tool, and attach shared result metadata.

        Args:
            data: Optional input model instance or plain dictionary payload.
            runtime: Optional per-call runtime overrides for the provider.
            **kwargs: Keyword arguments used to build the input model when `data` is omitted.

        Returns:
            The finalized structured tool result.

        Raises:
            QanuniValidationError: If the input payload is invalid.
            QanuniConfigError: If provider access is required but not configured.
        """
        self._enforce_access()
        input_data = self._coerce_input(data, kwargs)
        self.validate_input(input_data)

        started = perf_counter()
        result = self._run(input_data, runtime)
        elapsed_ms = int((perf_counter() - started) * 1000)
        return self._finalize(result, elapsed_ms)

    async def arun(
        self,
        data: InputT | dict[str, Any] | None = None,
        /,
        *,
        runtime: ToolRuntimeConfig | None = None,
        **kwargs: Any,
    ) -> OutputT:
        """Run the tool asynchronously.

        Args:
            data: Optional input model instance or plain dictionary payload.
            runtime: Optional per-call runtime overrides for the provider.
            **kwargs: Keyword arguments used to build the input model when `data` is omitted.

        Returns:
            The finalized structured tool result.

        Raises:
            QanuniValidationError: If the input payload is invalid.
            QanuniConfigError: If provider access is required but not configured.
        """
        self._enforce_access()
        input_data = self._coerce_input(data, kwargs)
        self.validate_input(input_data)

        started = perf_counter()
        result = await self._arun(input_data, runtime)
        elapsed_ms = int((perf_counter() - started) * 1000)
        return self._finalize(result, elapsed_ms)

    def validate_input(self, input_data: InputT) -> None:
        """Validate business or legal constraints beyond model parsing.

        Args:
            input_data: Parsed input model ready for tool-specific validation.

        Returns:
            None.

        Raises:
            QanuniValidationError: If tool-specific validation fails.
        """

    def _coerce_input(
        self,
        data: InputT | dict[str, Any] | None,
        kwargs: dict[str, Any],
    ) -> InputT:
        """Normalize positional model/dict input and keyword input into the tool model.

        Args:
            data: Optional input model instance or plain dictionary payload.
            kwargs: Keyword arguments supplied directly to the tool method.

        Returns:
            A validated input model instance for the tool.

        Raises:
            QanuniValidationError: If mutually exclusive input styles are mixed or unsupported.
        """
        if data is not None and kwargs:
            raise QanuniValidationError(
                "Pass either an input model/dict or keyword arguments, not both.",
                error_code=ErrorCode.VALIDATION_INPUT_CONFLICT,
                details={"tool_id": self.TOOL_ID},
            )
        if isinstance(data, self.INPUT_MODEL):
            return data
        if data is None:
            payload: dict[str, Any] = kwargs
        elif isinstance(data, dict):
            payload = data
        else:
            raise QanuniValidationError(
                f"Expected {self.INPUT_MODEL.__name__} or dict input for {self.TOOL_ID}.",
                error_code=ErrorCode.VALIDATION_INPUT_TYPE,
                details={"tool_id": self.TOOL_ID, "input_model": self.INPUT_MODEL.__name__},
            )
        try:
            return self.INPUT_MODEL.model_validate(payload)
        except ValidationError as exc:
            error_code: ErrorCode = ErrorCode.VALIDATION_FAILED
            error_messages: list[str] = [
                str(error.get("msg", ""))
                for error in exc.errors(include_url=False)
            ]
            if any(
                message.endswith("Provide either contract_text or contract_file.")
                or message.endswith("Provide either document_text or document_file.")
                for message in error_messages
            ):
                error_code = ErrorCode.VALIDATION_DOCUMENT_SOURCE_MISSING
            raise QanuniValidationError(
                "The supplied tool input is invalid.",
                error_code=error_code,
                details={
                    "tool_id": self.TOOL_ID,
                    "input_model": self.INPUT_MODEL.__name__,
                    "errors": exc.errors(include_url=False),
                },
            ) from exc

    def _enforce_access(self) -> None:
        """Retain a compatibility hook for future access policies.

        Args:
            None.

        Returns:
            None.

        Raises:
            None.
        """
        return None

    def _require_provider(self) -> BaseProvider:
        """Return the configured provider or fail loudly if provider setup fails.

        Args:
            None.

        Returns:
            A configured provider instance.

        Raises:
            QanuniConfigError: If the configured provider cannot be created.
        """
        return self._provider_factory()

    def _load_prompt(self) -> PromptRender:
        """Load a prompt without any user context.

        Args:
            None.

        Returns:
            A rendered prompt object with empty context.

        Raises:
            QanuniValidationError: If the tool does not declare a prompt file.
        """
        if self.PROMPT_FILE is None:
            raise QanuniValidationError(
                f"Tool '{self.TOOL_ID}' does not define a prompt file.",
                error_code=ErrorCode.PROMPT_FILE_MISSING,
                details={"tool_id": self.TOOL_ID},
            )
        return self._render_prompt({})

    def _build_prompt(self, context: dict[str, Any]) -> PromptRender:
        """Render the tool prompt with runtime input context.

        Args:
            context: Template variables used to render the configured prompt file.

        Returns:
            A rendered prompt object ready for provider submission.

        Raises:
            QanuniValidationError: If the tool does not declare a prompt file.
        """
        if self.PROMPT_FILE is None:
            raise QanuniValidationError(
                f"Tool '{self.TOOL_ID}' does not define a prompt file.",
                error_code=ErrorCode.PROMPT_FILE_MISSING,
                details={"tool_id": self.TOOL_ID},
            )
        return self._render_prompt(context)

    def _render_prompt(self, context: dict[str, Any]) -> PromptRender:
        """Render the configured prompt and enforce legal-reference consistency.

        Args:
            context: Template variables used to render the configured prompt file.

        Returns:
            A rendered prompt object ready for provider submission.

        Raises:
            QanuniValidationError: If strict legal-reference prompt metadata is misconfigured.
        """
        if self.PROMPT_FILE is None:
            raise QanuniValidationError(
                f"Tool '{self.TOOL_ID}' does not define a prompt file.",
                error_code=ErrorCode.PROMPT_FILE_MISSING,
                details={"tool_id": self.TOOL_ID},
            )

        prompt_template = PromptLoader.load(self.PROMPT_FILE)
        legal_reference_profile = self._get_legal_reference_profile()
        if (
            prompt_template.legal_reference_mode != LegalReferenceMode.DISABLED
            and legal_reference_profile is None
        ):
            raise QanuniValidationError(
                f"Tool '{self.TOOL_ID}' requires a legal reference profile.",
                error_code=ErrorCode.LEGAL_REFERENCE_REQUIRED,
                details={
                    "tool_id": self.TOOL_ID,
                    "prompt_file": self.PROMPT_FILE,
                    "legal_reference_mode": prompt_template.legal_reference_mode.value,
                },
            )

        return prompt_template.render(
            context,
            legal_reference_profile=legal_reference_profile,
        )

    def _build_prompt_context(self, input_data: InputT) -> dict[str, Any]:
        """Build the final prompt-rendering context from input data and legal references.

        Args:
            input_data: Parsed input model instance for the current call.

        Returns:
            A render context containing input fields and optional legal-reference metadata.

        Raises:
            QanuniValidationError: If the configured legal-reference file is invalid or missing.
        """
        context: dict[str, Any] = input_data.model_dump(mode="json")
        legal_reference_profile: LegalReferenceProfile | None = self._get_legal_reference_profile()
        if legal_reference_profile is None:
            return context

        context.update(
            {
                "legal_reference_profile_id": legal_reference_profile.profile_id,
                "legal_reference_mode": legal_reference_profile.mode.value,
                "legal_reference_source_ids": list(legal_reference_profile.source_ids()),
                "legal_reference_rule_ids": list(legal_reference_profile.rule_ids()),
                "legal_reference_mandatory_rule_ids": list(
                    legal_reference_profile.mandatory_rule_ids()
                ),
                "legal_reference_system_block": legal_reference_profile.render_system_block(),
                "legal_reference_user_block": legal_reference_profile.render_user_block(),
            }
        )
        return context

    def _merge_runtime(
        self,
        prompt_defaults: dict[str, Any],
        runtime: ToolRuntimeConfig | None,
    ) -> ToolRuntimeConfig:
        """Merge global config, prompt defaults, tool overrides, and per-call overrides.

        Args:
            prompt_defaults: Provider defaults defined in the prompt file.
            runtime: Optional per-call runtime overrides.

        Returns:
            A merged runtime configuration object for provider execution.

        Raises:
            None.
        """
        override = self._config.tool_overrides.get(self.TOOL_ID, ToolRuntimeConfig())
        merged = ToolRuntimeConfig(
            model=override.model or prompt_defaults.get("model") or self._config.model,
            max_output_tokens=(
                runtime.max_output_tokens
                if runtime and runtime.max_output_tokens is not None
                else override.max_output_tokens
                if override.max_output_tokens is not None
                else prompt_defaults.get("max_output_tokens", self._config.max_output_tokens)
            ),
            reasoning_effort=(
                runtime.reasoning_effort
                if runtime and runtime.reasoning_effort is not None
                else override.reasoning_effort
                if override.reasoning_effort is not None
                else prompt_defaults.get("reasoning_effort", self._config.reasoning_effort)
            ),
            verbosity=(
                runtime.verbosity
                if runtime and runtime.verbosity is not None
                else override.verbosity
                if override.verbosity is not None
                else prompt_defaults.get("verbosity", self._config.verbosity)
            ),
        )
        return merged

    def _call_structured_model(
        self,
        input_data: InputT,
        *,
        runtime: ToolRuntimeConfig | None,
    ) -> ProviderResponse[OutputT]:
        """Render the prompt and call the provider synchronously.

        Args:
            input_data: Parsed input model instance.
            runtime: Optional per-call runtime overrides.

        Returns:
            The provider response containing structured tool output.

        Raises:
            QanuniConfigError: If provider access is unavailable.
            QanuniAPIError: If the provider request fails.
            QanuniOutputError: If the provider cannot produce valid structured output.
        """
        prompt = self._build_prompt(self._build_prompt_context(input_data))
        provider = self._require_provider()
        runtime_config = self._merge_runtime(prompt.defaults, runtime)
        return provider.generate_structured(
            system_prompt=prompt.system_prompt,
            user_prompt=prompt.user_prompt,
            response_model=self.OUTPUT_MODEL,
            runtime=runtime_config,
        )

    async def _acall_structured_model(
        self,
        input_data: InputT,
        *,
        runtime: ToolRuntimeConfig | None,
    ) -> ProviderResponse[OutputT]:
        """Render the prompt and call the provider asynchronously.

        Args:
            input_data: Parsed input model instance.
            runtime: Optional per-call runtime overrides.

        Returns:
            The provider response containing structured tool output.

        Raises:
            QanuniConfigError: If provider access is unavailable.
            QanuniAPIError: If the provider request fails.
            QanuniOutputError: If the provider cannot produce valid structured output.
        """
        prompt = self._build_prompt(self._build_prompt_context(input_data))
        provider = self._require_provider()
        runtime_config = self._merge_runtime(prompt.defaults, runtime)
        return await provider.agenerate_structured(
            system_prompt=prompt.system_prompt,
            user_prompt=prompt.user_prompt,
            response_model=self.OUTPUT_MODEL,
            runtime=runtime_config,
        )

    def _finalize(self, result: OutputT, elapsed_ms: int) -> OutputT:
        """Attach standardized result metadata before returning the tool output.

        Args:
            result: Raw structured tool result produced by the implementation.
            elapsed_ms: Execution duration in milliseconds.

        Returns:
            The structured result with standard metadata fields populated.

        Raises:
            None.
        """
        legal_reference_profile: LegalReferenceProfile | None = self._get_legal_reference_profile()
        return result.model_copy(
            update={
                "tool_id": self.TOOL_ID,
                "execution_time_ms": elapsed_ms,
                "model_used": result.model_used or "deterministic",
                "timestamp": datetime.now(UTC),
                "legal_reference_profile_id": (
                    legal_reference_profile.profile_id
                    if legal_reference_profile is not None
                    else None
                ),
                "legal_reference_source_ids": (
                    list(legal_reference_profile.source_ids())
                    if legal_reference_profile is not None
                    else []
                ),
                "legal_reference_rule_ids": (
                    list(legal_reference_profile.rule_ids())
                    if legal_reference_profile is not None
                    else []
                ),
            }
        )

    def _get_legal_reference_profile(self) -> LegalReferenceProfile | None:
        """Load and cache the tool-specific legal-reference profile when configured.

        Args:
            None.

        Returns:
            The configured legal-reference profile, or `None` when the tool has no packet.

        Raises:
            QanuniValidationError: If the configured legal-reference file is invalid or missing.
        """
        if self._legal_reference_profile_loaded:
            return self._legal_reference_profile

        if self.LEGAL_REFERENCE_FILE is None:
            self._legal_reference_profile_loaded = True
            self._legal_reference_profile = None
            return None

        self._legal_reference_profile = LegalReferenceLoader.load(
            self.LEGAL_REFERENCE_FILE,
            external_catalog_dir=self._config.legal_reference_catalog_dir,
        )
        if self._legal_reference_profile.tool_ids and self.TOOL_ID not in set(
            self._legal_reference_profile.tool_ids
        ):
            raise QanuniValidationError(
                (
                    "Legal reference profile "
                    f"'{self._legal_reference_profile.profile_id}' does not apply "
                    f"to '{self.TOOL_ID}'."
                ),
                error_code=ErrorCode.LEGAL_REFERENCE_INVALID,
                details={
                    "tool_id": self.TOOL_ID,
                    "profile_id": self._legal_reference_profile.profile_id,
                    "allowed_tool_ids": list(self._legal_reference_profile.tool_ids),
                },
            )
        self._legal_reference_profile_loaded = True
        return self._legal_reference_profile

    @abstractmethod
    def _run(self, input_data: InputT, runtime: ToolRuntimeConfig | None) -> OutputT:
        """Execute the tool synchronously.

        Args:
            input_data: Parsed input model instance.
            runtime: Optional per-call runtime overrides.

        Returns:
            The structured tool result.

        Raises:
            QanuniError: If tool execution fails.
        """

    async def _arun(self, input_data: InputT, runtime: ToolRuntimeConfig | None) -> OutputT:
        """Raise unless subclasses implement async execution explicitly.

        Args:
            input_data: Parsed input model instance.
            runtime: Optional per-call runtime overrides.

        Returns:
            The structured tool result.

        Raises:
            QanuniError: If the tool does not implement async execution.
        """
        raise QanuniError(
            f"Tool '{self.TOOL_ID}' does not implement async execution.",
            error_code=ErrorCode.FEATURE_NOT_READY,
            details={"tool_id": self.TOOL_ID, "feature": "async_execution"},
        )
