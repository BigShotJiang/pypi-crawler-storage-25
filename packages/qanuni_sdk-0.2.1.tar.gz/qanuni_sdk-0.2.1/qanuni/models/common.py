"""Shared model primitives used across tool categories."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class ToolRuntimeConfig(BaseModel):
    """Per-call provider overrides."""

    model: str | None = None
    max_output_tokens: int | None = None
    reasoning_effort: Literal["low", "medium", "high"] | None = None
    verbosity: Literal["low", "medium", "high"] | None = None


class BaseResult(BaseModel):
    """Shared metadata attached to every tool result."""

    tool_id: str = ""
    execution_time_ms: int = 0
    tokens_used: int | None = None
    model_used: str | None = None
    timestamp: datetime | None = None
    legal_reference_profile_id: str | None = None
    legal_reference_source_ids: list[str] = Field(default_factory=list)
    legal_reference_rule_ids: list[str] = Field(default_factory=list)


class CalculationStep(BaseModel):
    """Represents a single monetary calculation step."""

    description: str
    amount: float = Field(ge=0)


class LegalIssue(BaseModel):
    """Describes a legal issue identified by a tool."""

    title: str
    severity: Literal["low", "medium", "high", "critical"]
    explanation: str
    recommendation: str


class ContractGap(BaseModel):
    """Represents a specific gap in a contract."""

    clause: str
    severity: Literal["low", "medium", "high", "critical"]
    recommendation: str


class AmbiguousClause(BaseModel):
    """Captures wording that needs clarification or rewrite."""

    excerpt: str
    reason: str
    suggested_rewrite: str


class TextChange(BaseModel):
    """Represents a before-and-after drafting improvement."""

    original: str
    improved: str
    reason: str


class KeyDate(BaseModel):
    """Represents a date surfaced from a legal document."""

    label: str
    value: str


class PDPLRight(BaseModel):
    """Represents whether a PDPL right is covered in a document."""

    right_name: str
    covered: bool
    note: str
