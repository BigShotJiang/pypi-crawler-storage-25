"""Models for compliance tools."""

from __future__ import annotations

from pydantic import BaseModel, Field

from qanuni.models.common import BaseResult


class PrivacyPolicyInput(BaseModel):
    """Input for generating an Arabic privacy policy."""

    company_name: str
    service_type: str
    data_collected: list[str] = Field(default_factory=list)
    data_purposes: list[str] = Field(default_factory=list)
    third_party_sharing: bool
    international_transfers: bool
    dpo_contact: str | None = None


class PrivacyPolicyResult(BaseResult):
    """Structured privacy-policy generation response."""

    policy_text: str
    pdpl_compliance_score: float
    sections_included: list[str]
    legal_notes: list[str]


class DemandLetterInput(BaseModel):
    """Input for generating a legal demand letter."""

    sender_name: str
    recipient_name: str
    claim_type: str
    claim_amount: float | None = None
    incident_description: str
    deadline_days: int
    threat_of_action: str


class DemandLetterResult(BaseResult):
    """Structured legal demand-letter response."""

    letter_text: str
    legal_notice_elements: list[str]
    strategic_notes: list[str]
