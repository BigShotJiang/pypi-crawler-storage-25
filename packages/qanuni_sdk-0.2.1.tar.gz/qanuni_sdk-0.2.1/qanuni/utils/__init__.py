"""General utilities."""
