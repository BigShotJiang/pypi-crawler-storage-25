"""Public package exports for Qanuni."""

from qanuni._version import __version__
from qanuni.client import LegalClient
from qanuni.core.config import QanuniConfig

__all__ = ["LegalClient", "QanuniConfig", "__version__"]
