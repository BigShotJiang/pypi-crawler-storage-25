# Qanuni SDK Free Edition

Qanuni is an Arabic-first Python SDK for Saudi legal workflows. This folder packages the current toolset as a **fully free distribution**: no activation, no license token, no seat control, and no premium gate. If a user has their own OpenAI key, they can use the prompt-backed tools immediately. Deterministic tools work even without OpenAI.

## What Makes This Edition Different?

- all shipped tools are free
- async usage is also free
- no `client.license` surface
- no activation flow
- no owner-side licensing service
- same package name for publishing: `qanuni-sdk`

## Included Guides

- full walkthrough: [FullReadme.md](FullReadme.md)
- user guide: [docs/guides/README_USERS.md](docs/guides/README_USERS.md)
- publishing guide: [docs/guides/README_PUBLISHING.md](docs/guides/README_PUBLISHING.md)
- prompt authoring notes: [docs/08_PROMPT_AUTHORING.md](docs/08_PROMPT_AUTHORING.md)

## Shipped Toolset

- `labor.end_of_service`
- `labor.probation_check`
- `contracts.gap_analysis`
- `contracts.generate_nda`
- `contracts.generate_mou`
- `drafting.improve`
- `drafting.summarize`
- `drafting.simplify`
- `compliance.generate_privacy_policy`
- `compliance.demand_letter`
- `policies.generate_hr_policy`
- `policies.job_description`

## Quickstart

If you are using the published package:

```bash
python -m pip install --upgrade qanuni-sdk
```

If you are validating this repository locally before publishing, install the source
from [free_edition](/E:/Private/Nawaf/BandAI_SDK/free_edition) instead:

```bash
cd free_edition
python -m pip install -e .
```

```python
from qanuni import LegalClient

client = LegalClient()

benefit = client.labor.end_of_service(
    monthly_salary=12000,
    years_of_service=7.5,
    termination_reason="resignation",
    contract_type="indefinite",
)

print(benefit.total_amount)
```

```python
import os

from dotenv import load_dotenv
from qanuni import LegalClient

load_dotenv()
client = LegalClient(api_key=os.getenv("OPENAI_API_KEY"))

result = client.drafting.improve(
    original_text="يدفع الطرف الأول عند الإنجاز.",
    improvement_goals=["precision", "clarity"],
    context="service agreement",
)

print(result.improved_text)
```

## Bundled Commands

```bash
qanuni-examples --list
qanuni-examples --category mocked_local
qanuni-release-check --allow-dirty
```

## Configuration

Minimal `.env`:

```bash
OPENAI_API_KEY=sk-...
QANUNI_MODEL=gpt-5.5
QANUNI_LANGUAGE=ar
QANUNI_JURISDICTION=SA
QANUNI_TIMEOUT=90
QANUNI_MAX_OUTPUT_TOKENS=2500
```

In notebooks, prefer:

```python
%pip install --upgrade qanuni-sdk
```

Then restart the kernel and verify:

```python
import qanuni

print(qanuni.__version__)
print(qanuni.__file__)
```

YAML config loading still works:

```python
from qanuni import LegalClient

client = LegalClient.from_config(".qanuni.yaml")
```

## Publishing Note

This free edition is designed to be published under the **same project name** `qanuni-sdk`, but as a **new version** such as `0.2.1`. The publishing checklist lives in [docs/guides/README_PUBLISHING.md](docs/guides/README_PUBLISHING.md).
