# Qanuni Prompt Authoring Guide

This file defines the house standard for prompt quality inside the SDK.

## Why This Exists

Qanuni is not a generic text-generation package. The main product value lives in:

- legal framing
- jurisdiction awareness
- output discipline
- business-safe wording

Short prompts may sometimes work in demos, but they decay quickly in production. For that reason, every new prompt in `qanuni/prompts/` must be written as a structured prompt contract.

## Required Structure

Every prompt file must include:

```yaml
version: "0.x.y"
tool_id: "namespace.tool_name"
metadata:
  prompt_style: "sectioned"
  jurisdiction: "SA"
  language: "ar"
  legal_reference_mode: "strict"
defaults:
  model: "gpt-5.5"
  reasoning_effort: "medium"
  verbosity: "medium"
  max_output_tokens: 2200
system_sections:
  - title: "Role"
    body: |
      ...
user_sections:
  - title: "Request"
    body: |
      ...
```

## System Section Expectations

The `system_sections` area should usually cover:

1. `Role`
2. `Drafting Priorities` or `Analysis Priorities`
3. `Guardrails`

Optional additions:

- `Saudi Legal Context`
- `Scoring Rules`
- `Refusal Boundaries`
- `Output Discipline`
- `Mandatory Legal Reference Packet`

## Legal Reference Packets

When a tool depends on strict legal or policy baselines, its prompt metadata must declare:

```yaml
metadata:
  legal_reference_mode: "strict"
```

This enables prompt-time injection of a structured legal-reference packet loaded from
`qanuni/legal_references_data/` or an external override catalog configured through
`QANUNI_LEGAL_REFERENCE_CATALOG_DIR`.

Use these modes intentionally:

- `disabled`: no legal-reference packet is appended.
- `advisory`: references are provided as strong guidance but may allow more flexibility.
- `strict`: mandatory rules inside the packet are treated as binding constraints.

Strict packets are the default choice for production legal workflows whenever the output
must stay inside mandatory drafting rules, internal policy baselines, or curated regulatory
checklists.

## User Section Expectations

The `user_sections` area should usually cover:

1. the business request
2. the factual or contractual inputs
3. any configurable assumptions
4. the exact output contract

The last section should almost always be called `Output Contract` and must make the expected structured response unmistakable.

## Prompt Writing Rules

- Prefer explicit duties over vague aspirations.
- Prefer enforceable wording over ceremonial legal tone.
- Assume the caller wants something usable inside software, not a legal essay.
- State assumptions in notes instead of silently inventing facts.
- Avoid fake certainty about litigation, government approval, or enforceability.
- If the prompt must balance legal and business outcomes, say so directly.

## Good Smell vs Bad Smell

Good:

- The prompt makes the model’s job narrow and specific.
- The prompt distinguishes legal requirements from best practice.
- The output contract is clear enough to test.

Bad:

- “Improve this text.”
- “Generate a contract.”
- “Check compliance.”
- Any prompt that leaves severity scoring or document structure undefined.

## Testing Standard

Prompt files are part of the codebase contract. They must remain:

- section-based
- long enough to express real constraints
- loadable by `PromptLoader`
- covered by unit tests where practical

If a prompt is materially changed, its `version` field must be bumped.
