# Qanuni Free Edition User Guide

This guide is for end users of the **free Qanuni SDK distribution**.

## What You Need

- Python `3.11+`
- your own `OPENAI_API_KEY` for prompt-backed tools

You do **not** need:

- activation key
- license token
- public signing keys
- paid entitlement setup

## Install

If you are using the published package:

```bash
python -m pip install --upgrade qanuni-sdk
```

If you are testing this repository locally before publication, install the source from
`free_edition` instead:

```bash
cd free_edition
python -m pip install -e .
```

Inside Jupyter, prefer:

```python
%pip install --upgrade qanuni-sdk
```

If you are testing the local repository copy inside Jupyter instead:

```python
%pip install -e .
```

## Create a Client

For deterministic labor tools:

```python
from qanuni import LegalClient

client = LegalClient()
```

For prompt-backed tools:

```python
import os

from dotenv import load_dotenv
from qanuni import LegalClient

load_dotenv()
client = LegalClient(api_key=os.getenv("OPENAI_API_KEY"))
```

## Environment Variables

```bash
OPENAI_API_KEY=sk-...
QANUNI_MODEL=gpt-5.5
QANUNI_LANGUAGE=ar
QANUNI_JURISDICTION=SA
QANUNI_TIMEOUT=90
QANUNI_MAX_RETRIES=2
QANUNI_MAX_OUTPUT_TOKENS=2500
QANUNI_REASONING_EFFORT=medium
QANUNI_VERBOSITY=medium
QANUNI_LOG_LEVEL=WARNING
```

## Explore the Catalog

```python
for tool in client.list_tools():
    print(tool.tool_id, tool.description)
```

```python
for tool in client.list_tool_access():
    print(tool.tool_id, tool.available)
```

## Typical Usage

### Deterministic

```python
result = client.labor.end_of_service(
    monthly_salary=9000,
    years_of_service=5,
    termination_reason="termination_by_employer",
    contract_type="indefinite",
)
```

### Prompt-backed

```python
result = client.drafting.improve(
    original_text="يدفع الطرف الأول عند الإنجاز.",
    improvement_goals=["precision", "clarity", "formality"],
    context="service agreement",
)
```

Sanity check after installing in Jupyter:

```python
import qanuni

print(qanuni.__version__)
print(qanuni.__file__)
```

If the path or version is not what you expect, restart the kernel before
continuing.

### Async

```python
import asyncio


async def main() -> None:
    result = await client.contracts.agap_analysis(
        contract_text="يتم السداد لاحقًا ويجوز الإنهاء عند الحاجة.",
        contract_type="service_agreement",
    )
    print(result.summary)


asyncio.run(main())
```

## Mocked Local Examples

```bash
qanuni-examples --category mocked_local
```

## Common Errors

### No OpenAI key for a live tool

- likely cause: `OPENAI_API_KEY` is missing
- fix: provide the key in code or `.env`

### Mixed dict and kwargs

- likely cause: you passed both a payload dict and keyword arguments
- error code: `QANUNI_VALIDATION_INPUT_CONFLICT`

### Missing document text

- likely cause: you called a document-analysis tool without text or file
- error code: `QANUNI_VALIDATION_DOCUMENT_SOURCE_MISSING`

## Config File

```yaml
openai:
  api_key: "sk-..."
  model: "gpt-5.5"

locale:
  language: "ar"
  jurisdiction: "SA"

performance:
  timeout: 90

tools:
  drafting.improve:
    max_output_tokens: 1800
```

```python
from qanuni import LegalClient

client = LegalClient.from_config(".qanuni.yaml")
```
