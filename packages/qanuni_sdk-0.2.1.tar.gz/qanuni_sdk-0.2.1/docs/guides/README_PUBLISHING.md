# Publishing Qanuni Free Edition

This guide explains how to publish the **free edition** that lives in this folder.

## Important Rule

The project name stays:

```text
qanuni-sdk
```

But publishing must happen as a **new version** such as `0.2.0`. Do not try to reuse an already uploaded version number.

## 1. Move Into the Free Edition Folder

```bash
cd free_edition
```

## 2. Update the Version

Edit:

```text
qanuni/_version.py
```

Example:

```python
__version__ = "0.2.0"
```

## 3. Create a Clean Virtual Environment

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -e .[dev,release]
```

## 4. Run Quality Checks

```bash
ruff check qanuni tests examples.py
mypy qanuni
pytest -q
qanuni-release-check --allow-dirty
```

## 5. Build the Package

```bash
python -m build
python -m twine check dist/*
```

## 6. Install the Built Wheel in a Fresh Environment

```bash
python -m venv .venv-smoke
.venv-smoke\Scripts\activate
pip install dist/qanuni_sdk-0.2.0-py3-none-any.whl
qanuni-examples --list
qanuni-examples --category mocked_local
deactivate
```

Replace the wheel filename if the version changes.

## 7. Publish to TestPyPI First

```bash
python -m twine upload --repository testpypi dist/*
```

## 8. Publish to PyPI

```bash
python -m twine upload dist/*
```

## 9. After Publishing

Verify:

- project name is still `qanuni-sdk`
- PyPI page renders `README_PYPI.md`
- install command works
- `qanuni-examples --list` works from the published wheel

## Suggested Maintainer Checklist

- version bumped
- changelog updated
- tests passing
- build passing
- wheel smoke-tested
- uploaded to TestPyPI
- uploaded to PyPI
