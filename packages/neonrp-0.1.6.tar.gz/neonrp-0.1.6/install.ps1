# WorldLines / NeonRP bootstrap installer — PowerShell edition
#
# Usage (from PowerShell):
#   irm https://worldlines.gg/install.ps1 | iex
#
# Or via WorldLines.bat which chains into this script.
#
# What it does:
#   1. Ensures `uv` is installed (fetches from astral.sh if missing).
#   2. Installs `worldlines` (pulls the pinned `neonrp` runtime too).
#   3. Prints a next-step hint.
#
# Env hooks (same semantics as install.sh):
#   $env:CHINA_MIRROR = "1"   route uv through Tsinghua PyPI mirror
#   $env:UV_DEFAULT_INDEX     user override — always wins if set

$ErrorActionPreference = "Stop"

$package = if ($env:WORLDLINES_PACKAGE) { $env:WORLDLINES_PACKAGE } else { "worldlines" }

function Log($msg)  { Write-Host "==> $msg" -ForegroundColor Cyan }
function Warn($msg) { Write-Host "!!  $msg" -ForegroundColor Yellow }
function Die($msg)  { Write-Host "xx  $msg" -ForegroundColor Red; exit 1 }

# Step 1 — ensure uv (astral's Python/tool installer).
if (Get-Command uv -ErrorAction SilentlyContinue) {
    Log "uv already installed ($(uv --version))"
} else {
    Log "installing uv from astral.sh"
    try {
        powershell -ExecutionPolicy ByPass -Command "irm https://astral.sh/uv/install.ps1 | iex"
    } catch {
        Die "failed to install uv: $_"
    }
    # uv's Windows installer drops the binary under %USERPROFILE%\.local\bin
    # or %CARGO_HOME%\bin — make sure this shell sees it.
    $extra = @(
        "$env:USERPROFILE\.local\bin",
        "$env:CARGO_HOME\bin",
        "$env:USERPROFILE\.cargo\bin"
    ) | Where-Object { Test-Path $_ }
    if ($extra) {
        $env:PATH = ($extra -join ';') + ';' + $env:PATH
    }
    if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
        Die "uv installed but not found on PATH; open a new PowerShell and re-run this script"
    }
}

# Step 1.5 — optional China PyPI mirror.
if ($env:CHINA_MIRROR -eq "1" -and -not $env:UV_DEFAULT_INDEX) {
    $env:UV_DEFAULT_INDEX = "https://pypi.tuna.tsinghua.edu.cn/simple"
    Log "CHINA_MIRROR=1 -> using Tsinghua PyPI mirror"
}

# Step 2 — install the CLI via uv tool.
Log "installing $package"
uv tool install --force $package

# Step 3 — quick-start hint.
Write-Host ""
Write-Host "✓ $package installed" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:"
Write-Host "  $package              # launch the guided world picker"
Write-Host "  neonrp --help         # full engine CLI"
Write-Host "  neonrp self-update    # check for updates"
Write-Host ""
Write-Host "Docs: https://github.com/LudicDynamics/WorldLines"
Write-Host ""
