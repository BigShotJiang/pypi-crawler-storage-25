# Releases — neonrp & worldlines

> Authoritative notes on the L14 release pipeline: architecture, PyPI
> trusted publishing setup, the auto-update protocol, and a one-time
> click-path runbook for bootstrapping a fresh publish pipeline.
>
> Related: `docs/L14_AUTO_UPDATE_SCHEME.md` for the design rationale.

---

## What ships

We publish **two** PyPI distributions from one repository, at the same
version, for every tag:

| PyPI project | What it is | CLI entry point |
|---|---|---|
| `neonrp` | Full runtime — engine, TUI, MCP server, skills | `neonrp` |
| `worldlines` | Thin shim that pins `neonrp==<same-version>` | `worldlines` |

Users can install either:

```bash
uv tool install neonrp         # full CLI
uv tool install worldlines     # guided launcher (still pulls neonrp)
```

Both provide a `worldlines` command because `neonrp` itself declares the
entry point (`pyproject.toml:project.scripts.worldlines`). The `worldlines`
PyPI project exists mainly so `uv tool install worldlines` works as a
discoverable alias.

---

## Two-repo split (private source + public releases)

| Role | Repo | Visibility |
|---|---|---|
| Source + release workflow | `LudicDynamics/NeonRP` | **Private** |
| Public release surface | `LudicDynamics/WorldLines` | Public |

Source + PyPI publishing run from the **private** repo. But
`releases.json` + `install.sh` must be served **unauthenticated** via
worldlines.gg, and private-repo GitHub Release assets require a token.
The workflow therefore creates the public-facing Release on the public
docs repo `LudicDynamics/WorldLines` via a fine-grained PAT.

```
LudicDynamics/NeonRP (private)                  LudicDynamics/WorldLines (public)
──────────────────                              ─────────────────────
git push origin v0.1.0                          ← tag v0.1.0 mirrored here
├─ build + publish-neonrp → PyPI                ← Release created on main
├─ publish-worldlines     → PyPI                  with assets attached:
└─ publish-release-manifest ──────────────┐         releases.json
   (uses WORLDLINES_RELEASE_TOKEN PAT) ◄──┘         install.sh
```

---

## Repository layout

```
NeonRP/
├── pyproject.toml                     # neonrp (main)
├── src/neonrp/
│   └── __init__.py                    # __version__ = "X.Y.Z"
├── packaging/
│   └── worldlines/
│       ├── pyproject.toml             # worldlines (shim)
│       ├── README.md
│       └── worldlines_shim/
│           └── __init__.py
├── install.sh                         # bootstrap script (curl|sh)
└── .github/workflows/
    ├── test.yml                       # PR + push CI
    └── release.yml                    # tag-triggered publish
```

At release time the workflow rewrites both `pyproject.toml` files to the
tag version and rewrites the pinned `neonrp==X.Y.Z` dependency inside the
worldlines shim before building.

---

## Versioning

- Tag format: `vX.Y.Z` (e.g. `v0.3.0`).
- The tag is the **source of truth**; the workflow uses the stripped
  version (`X.Y.Z`) for both PyPI projects.
- `src/neonrp/__init__.py:__version__` should be bumped before tagging
  so local installs report the right number.

## Channels

| Channel | Notes |
|---|---|
| `stable` | Default. Only flagged regressions back out. |
| `preview` | Early access, may contain L14/L15 work-in-progress. |
| `nightly` | (Optional) daily builds; no stability promise. |

User-level config:

```json
{
  "updates": {
    "enabled": true,
    "channel": "stable",
    "mode": "prompt-and-update",
    "check_on_launch": true,
    "last_skipped_version": "0.3.4"
  }
}
```

Saved at `~/.neonrp/config.json`. Managed via the TUI
`/update channel <name>` command or `neonrp self-update channel <name>`.

---

## Release manifest

Every tag push generates `releases.json` (see `release.yml:publish-release-manifest`):

```json
{
  "product": "neonrp",
  "latest": { "stable": "0.3.4" },
  "releases": {
    "0.3.4": {
      "channel": "stable",
      "published_at": "2026-04-20T10:30:00Z",
      "notes_url": "https://github.com/LudicDynamics/WorldLines/releases/tag/v0.3.4",
      "artifacts": {
        "python-wheel": {
          "kind": "pypi",
          "version": "0.3.4",
          "packages": ["neonrp", "worldlines"]
        }
      }
    }
  }
}
```

The updater (see `src/neonrp/core/updater.py`) looks at two URLs, in order:

1. `https://worldlines.gg/releases.json` — the canonical mirror
2. `https://api.github.com/repos/LudicDynamics/WorldLines/releases/latest` —
   fallback when (1) is unreachable.

If you change the GitHub owner, update `GITHUB_LATEST_RELEASE_URL` in
`src/neonrp/core/updater.py`.

### worldlines.gg hosting — S3 primary + GitHub Release fallback

Both `releases.json` and `install.sh` are uploaded to two places on every
tag push, so users have an automatic fallback path when either side is
unreachable (mainland-China networks frequently throttle Cloudflare or
GitHub Release downloads):

```
Primary:   S3 bucket                              (Cloudflare → S3)
Fallback:  LudicDynamics/WorldLines GitHub Release asset
```

Stable URLs:

```
Primary (S3 via Cloudflare):
  https://worldlines.gg/releases.json
  https://worldlines.gg/install.sh

Fallback (GitHub latest-asset URL):
  https://github.com/LudicDynamics/WorldLines/releases/latest/download/releases.json
  https://github.com/LudicDynamics/WorldLines/releases/latest/download/install.sh
```

The updater (`src/neonrp/core/updater.py`) already tries the `worldlines.gg`
URL first and falls back to the GitHub REST API on failure — no special
client-side logic needed. For `install.sh` users in restricted networks
the README documents the direct GitHub URL as the manual fallback.

**Cloudflare redirect rules** — point to S3 primary (change the
destination to your bucket's virtual-hosted URL):

| Source | Destination | Status |
|---|---|---|
| `worldlines.gg/releases.json` | `https://worldlines-releases.s3.<region>.amazonaws.com/releases.json` | 302 |
| `worldlines.gg/install.sh`    | `https://worldlines-releases.s3.<region>.amazonaws.com/install.sh`    | 302 |

302 (not 301) keeps clients re-querying Cloudflare, so swapping the
origin later (e.g. to CloudFront / a CN-specific mirror) doesn't leave
clients pinned to the old target.

Before S3 is configured — or if the S3 upload step fails mid-release —
point the Cloudflare rules at the GitHub latest-asset URLs instead:

```
worldlines.gg/releases.json → github.com/LudicDynamics/WorldLines/releases/latest/download/releases.json
worldlines.gg/install.sh    → github.com/LudicDynamics/WorldLines/releases/latest/download/install.sh
```

---

## Trusted Publishing (OIDC)

No PyPI API tokens are stored in the repo or in GitHub Secrets. PyPI
authenticates us via GitHub's OIDC provider. Each release workflow run
gets a short-lived token that PyPI verifies against the "pending
publisher" entries registered on the PyPI project pages.

PyPI's pending-publisher table is unique by `(owner, repo, workflow,
environment)` — two projects publishing from the **same** workflow
must use **distinct environment names** (that's why the workflow has
`pypi-neonrp` and `pypi-worldlines`, not a shared `pypi`).

---

## The release workflow

`.github/workflows/release.yml` has four jobs:

1. `build` — checkout, install uv + Python, sync version into both
   `pyproject.toml` files, run `uv build` twice (once at repo root for
   `neonrp`, once in `packaging/worldlines/` for the shim), upload
   artifacts.
2. `publish-neonrp` — downloads artifacts, publishes via
   `pypa/gh-action-pypi-publish@release/v1` against PyPI project
   `neonrp` with `environment: pypi-neonrp`. Requires
   `id-token: write` for OIDC.
3. `publish-worldlines` — same shape against PyPI project `worldlines`
   with `environment: pypi-worldlines`; runs after `publish-neonrp` so
   the pinned dependency exists.
4. `publish-release-manifest` — generates `releases.json` and
   dual-publishes it plus `install.sh`:
   - Creates a Release on the PUBLIC repo `LudicDynamics/WorldLines`
     with both files attached. Uses `WORLDLINES_RELEASE_TOKEN` (PAT
     scoped to the public repo).
   - If the `S3_RELEASE_*` repo variables are set, also uploads both
     files to the configured S3 bucket via OIDC (no static AWS keys).
     Skips cleanly when the vars are unset.

### Testing a release without publishing

Trigger the workflow manually via **Actions → release → Run workflow**
with `dry_run=true`. The `build` job still runs and uploads artifacts,
but the publish jobs are skipped.

---

## One-time setup checklist

> Concrete click-path runbook for wiring up OIDC / PyPI / the
> cross-repo PAT / worldlines.gg **before** the first `v*` tag is
> pushed. Everything here is one-time — after this, releases are just
> `git tag vX.Y.Z && git push origin vX.Y.Z`.

### 1. PyPI — reserve project names via pending publishers

1. Log in to https://pypi.org
2. Open https://pypi.org/manage/account/publishing/
3. Scroll to **"Add a new pending publisher"**.
4. **Add the first entry** — reserves `neonrp`:

   | Field | Value |
   |---|---|
   | PyPI Project Name | `neonrp` |
   | Owner | `LudicDynamics` |
   | Repository name | `NeonRP` |
   | Workflow name | `release.yml` |
   | Environment name | `pypi-neonrp` |

5. Click **Add**. A pending publisher appears in the list.

6. **Add the second entry** — reserves `worldlines`:

   | Field | Value |
   |---|---|
   | PyPI Project Name | `worldlines` |
   | Owner | `LudicDynamics` |
   | Repository name | `NeonRP` |
   | Workflow name | `release.yml` |
   | Environment name | `pypi-worldlines` |

   > ⚠ The Environment name **must differ from the first entry** —
   > PyPI's trusted-publisher table is unique by
   > `(owner, repo, workflow, environment)`, not by project name.

7. Both names appear in Pending publishers list. Names lock once the
   first tag publish succeeds.

### 2. GitHub — NeonRP repo environments

For each of the two PyPI environments above, create a matching
environment on the source repo.

1. Open https://github.com/LudicDynamics/NeonRP/settings/environments
2. **New environment** → name: `pypi-neonrp` → Configure environment.
3. **Deployment branches and tags** → `Selected branches and tags` →
   Add rule → **Ref type: Tag**, **Pattern: `v*`**.
4. (optional) **Required reviewers** → add yourself for a manual
   approval gate on each publish.
5. Leave Secrets and Variables empty — OIDC doesn't use secrets.
6. Save.
7. Repeat steps 2–6 for environment `pypi-worldlines`.

### 3. GitHub — fine-grained PAT for cross-repo Release publishing

Creates the public-facing Release on `LudicDynamics/WorldLines` from
the private workflow.

1. Open https://github.com/settings/personal-access-tokens/new
2. **Token name**: `NeonRP → WorldLines release publisher`
3. **Expiration**: pick a policy (90 days / 1 year / custom). Renewal
   is manual — calendar a reminder.
4. **Resource owner**: `LudicDynamics`. If you don't see it, you're
   not an org member/owner with PAT permissions.
5. **Repository access**: `Only select repositories` → tick
   `WorldLines`.
6. Scroll down to **Permissions** → **Repository permissions**. This
   is a long list — `Actions`, `Administration`, `Attestations`,
   `Codespaces`, `Contents`, `Custom properties`, `Deployments`, ...
7. Find the **Contents** row → change its `Access` dropdown from
   `No access` to **`Read and write`**. (Unlocks creating tags,
   releases, and uploading assets.) Leave every other row at
   `No access`.
8. (Metadata: Read-only is auto-added — don't uncheck.)
9. Bottom of page → **Generate token**.
10. **Copy the token now** — you can't see it again after navigating
    away.

Store the token as a secret on the source repo:

1. Open https://github.com/LudicDynamics/NeonRP/settings/secrets/actions
2. **New repository secret**:
   - Name: **`WORLDLINES_RELEASE_TOKEN`** (exact spelling — the
     workflow reads this name).
   - Value: paste the PAT.
3. Save.

### 4. AWS — S3 bucket + OIDC role (optional, skip for first release)

The release workflow uploads `releases.json` + `install.sh` to S3 as
primary hosting with GitHub Release as fallback. OIDC means **no
long-lived AWS keys** in GitHub Secrets.

**Skip this entire section if you want to launch with GitHub-only
hosting — the workflow handles that automatically.** Come back when you
need better reachability (e.g. mainland-China users reporting slow
installs).

1. Create the S3 bucket (e.g. `worldlines-releases`) in a
   region close to your users. `ap-northeast-1` (Tokyo) has decent
   reachability from both US/EU and mainland China.

2. Enable **Block Public Access: OFF** on the bucket so Cloudflare can
   fetch objects without auth. Then add this bucket policy so only
   GET is public:
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Sid": "PublicRead",
         "Effect": "Allow",
         "Principal": "*",
         "Action": "s3:GetObject",
         "Resource": "arn:aws:s3:::worldlines-releases/*"
       }
     ]
   }
   ```

3. **IAM → Identity providers → Add provider**:
   - Provider type: OpenID Connect
   - Provider URL: `https://token.actions.githubusercontent.com`
   - Audience: `sts.amazonaws.com`

4. **IAM → Roles → Create role** — Web identity:
   - Identity provider: the one you just created
   - Audience: `sts.amazonaws.com`
   - Trust policy (click "Edit trust policy" after initial creation
     and replace with this — scopes the role to only accept tokens
     from your NeonRP repo on `v*` tags):
     ```json
     {
       "Version": "2012-10-17",
       "Statement": [{
         "Effect": "Allow",
         "Principal": {
           "Federated": "arn:aws:iam::<YOUR-ACCT>:oidc-provider/token.actions.githubusercontent.com"
         },
         "Action": "sts:AssumeRoleWithWebIdentity",
         "Condition": {
           "StringEquals": {
             "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
           },
           "StringLike": {
             "token.actions.githubusercontent.com:sub":
               "repo:LudicDynamics/NeonRP:ref:refs/tags/v*"
           }
         }
       }]
     }
     ```
   - Permissions: attach an inline policy granting just `s3:PutObject`
     on the bucket:
     ```json
     {
       "Version": "2012-10-17",
       "Statement": [{
         "Effect": "Allow",
         "Action": ["s3:PutObject", "s3:PutObjectAcl"],
         "Resource": "arn:aws:s3:::worldlines-releases/*"
       }]
     }
     ```
   - Save. Copy the Role ARN (e.g.
     `arn:aws:iam::123456789012:role/NeonRP-ReleasePublisher`).

5. On GitHub → `LudicDynamics/NeonRP` → Settings → **Secrets and
   variables → Actions → Variables** (not Secrets — these values
   aren't sensitive). Add three repo variables:

   | Name | Value |
   |---|---|
   | `S3_RELEASE_ROLE_ARN` | `arn:aws:iam::123456789012:role/NeonRP-ReleasePublisher` |
   | `S3_RELEASE_BUCKET` | `worldlines-releases` |
   | `S3_RELEASE_REGION` | `ap-northeast-1` |

   (Role ARN is scoped via trust policy — even if leaked, nobody else
   can assume it, so `vars` is correct.)

6. After the next tag push, check that the S3 step in the workflow
   ran green and the bucket has `releases.json` + `install.sh` +
   `v0.1.0/releases.json`.

### 5. worldlines.gg — Cloudflare redirect rules

Point the domain at Cloudflare (already done if DNS resolves through
Cloudflare nameservers), then add two 302 redirects.

1. Log in to Cloudflare → select the `worldlines.gg` zone.
2. **Rules → Redirect Rules → Create rule**.
3. Rule 1 — **`releases.json`**:
   - Rule name: `releases.json → S3 primary`
   - When incoming requests match: `URI Path` equals `/releases.json`
   - Then: Static redirect, Status `302`, URL:
     - If S3 configured:
       `https://worldlines-releases.s3.ap-northeast-1.amazonaws.com/releases.json`
     - Otherwise (GitHub-only):
       `https://github.com/LudicDynamics/WorldLines/releases/latest/download/releases.json`
   - Preserve query string: ✓
   - Deploy.
4. Rule 2 — **`install.sh`** (same shape as above, target the
   corresponding `/install.sh` path on S3 or GitHub).
5. (optional) Rule 3 — root `/` redirect to the docs repo landing
   page. Not required for the updater / installer to work.

### 6. Smoke-test before the first tag

```bash
# Local build sanity check:
uv run pytest -q
rm -rf dist packaging/worldlines/dist
uv build
cd packaging/worldlines && uv build && cd -
uv run --with twine twine check dist/* packaging/worldlines/dist/*

# Workflow dry-run (no real publish):
# Actions → release → Run workflow → dry_run: true
```

All tests green + 4 artifacts `PASSED` → ready to tag.

---

## Release checklist (per release)

Before tagging:

- [ ] Bump `src/neonrp/__init__.py:__version__`.
- [ ] Bump `pyproject.toml:project.version`.
- [ ] Bump `packaging/worldlines/pyproject.toml:project.version` and
      the pinned `neonrp==X.Y.Z` dependency line.
      *(The release workflow also does this for safety, but keeping
      local state consistent avoids drift between dev and release.)*
- [ ] `uv run ruff check src/ tests/`
- [ ] `uv run pytest -q`
- [ ] Commit and push to a release branch; merge to `main`.
- [ ] From `main`: `git tag vX.Y.Z && git push origin vX.Y.Z`
- [ ] Watch Actions → `release`. Confirm publishes succeed.
- [ ] (optional) Check `https://worldlines.gg/releases.json` returns
      the new version.

---

## Auto-update protocol (client side)

When `worldlines` or `neonrp` starts, `src/neonrp/cli.py` calls
`_launch_time_update_check()`, which:

1. Loads `~/.neonrp/config.json.updates` settings.
2. If `enabled && check_on_launch`, runs
   `updater.check_for_update_cached()` (6-hour cache).
3. If a newer version exists for the current channel, prints a one-line
   notice and asks `[y / s / n]`:
   - `y` → calls `uv tool upgrade neonrp` (falls back to `pipx` or
     `pip` on PATH), prints upgrade output, exits so user can restart.
   - `s` → records `last_skipped_version`; won't prompt for that
     version again.
   - `n` → continues launch.
4. If the install is **editable / source checkout**, the prompt is
   skipped entirely — only a notice is shown. This is intentional: we
   never overwrite a developer's working tree.

Inside the TUI:

```
/update            → check
/update check      → fetch manifest and report
/update status     → show version + install mode (no network)
/update apply      → run the upgrade command
/update channel <stable|preview|nightly>
```

CLI:

```
neonrp self-update check
neonrp self-update status
neonrp self-update apply [--package neonrp|worldlines] [--yes]
neonrp self-update channel <stable|preview|nightly>
neonrp self-update skip <version>
```

---

## Rolling back a bad release

- You cannot overwrite a version on PyPI — yank it instead
  (PyPI project → Manage releases → Yank). Clients that already
  installed it are unaffected; new installs fall back to the previous
  good version.
- Tag `v0.X.(Y+1)` with the fix. Do not retry the same version.
- If the manifest is incorrect, edit the GitHub Release asset — the
  cache on clients expires every 6 hours.

---

## Recurring maintenance

- **PAT renewal**: `WORLDLINES_RELEASE_TOKEN` expires per the policy
  you picked in the setup checklist §3. Before expiry, mint a new PAT
  and update the secret value in place (same name — the workflow
  doesn't change).
- **PyPI pending → trusted transition**: happens automatically after
  the first successful publish. Nothing for you to do.
- **Adding a new maintainer**: add them to the `LudicDynamics` org with
  write access to `NeonRP` (recommended — existing PAT / OIDC keeps
  working). Only register a second pending publisher with a different
  user owner if the project later moves to a personal account.

---

## Owner handoff

PyPI trust is bound to `(owner, repo, release.yml, environment)`. If the
project ever moves out of the `LudicDynamics` org:

1. Register the new owner as an additional pending publisher on BOTH
   PyPI projects BEFORE pushing the first tag from there. You can keep
   the old owner registered simultaneously — PyPI accepts any
   configured trusted publisher.
2. Update `GITHUB_LATEST_RELEASE_URL` in `src/neonrp/core/updater.py`
   so auto-update fallback still resolves the latest release.
3. Update the project URLs in `packaging/worldlines/pyproject.toml`
   and `packaging/worldlines/README.md`.
4. Mint a new PAT under the new owner for cross-repo Release
   publishing and replace `WORLDLINES_RELEASE_TOKEN`.
5. Update the Cloudflare Redirect Rules on worldlines.gg to point at
   the new WorldLines-equivalent repo's `releases/latest/download/`
   URLs.

---

## Known limitations (Phase 1)

- No staged "download now, apply on next launch" mode. Upgrade is
  foreground and exits the current process.
- No SHA256 hash verification on the upgrade — we trust `uv tool
  upgrade`'s own TLS/signature checks against PyPI.
- No signed release notes. The `notes_url` simply points at the
  GitHub Release page.
- No platform-native installer (macOS `.dmg`, Windows MSI). See
  `docs/L14_AUTO_UPDATE_SCHEME.md` Phase 4 for the plan.
