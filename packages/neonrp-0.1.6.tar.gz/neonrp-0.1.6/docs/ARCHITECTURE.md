# NeonRP CLI — Architecture Overview

> NeonRP is a **file-first**, **auditable**, **resumeable** RPG CLI.
> It treats "game state" as a versioned artifact (like a repo), and treats "LLM/agents" as *proposal generators* whose writes must pass validation & permissions.

This document is the **project-level architecture**: components, invariants, and the lifecycle of state changes.

## 1. Product framing

### What NeonRP is
A command-line engine for building/playing text RPGs where:
- **Game data / player / quests** are stored as structured files.
- Every turn is appended to an **event log**.
- State changes are applied through a **Plan → Diff → Validate → Apply** pipeline.
- You can **save/load/undo/redo/branch**, and **sandbox/replay**.

### What problems it solves
- **Long-running continuity**: stable "resume/undo/branch" even when model context drifts.
- **Safety**: prevent LLM "creative writes" from corrupting saves via staging + validation + permissions.
- **Scale**: minimal context retrieval (`index`/`find`/`context`) avoids re-loading the entire game data each time.
- **Debuggability**: every agent/tool/patch is logged so failures are reproducible.

### Non-goals (by design)
- NeonRP is **not** a front-end chat UI (that's where SillyTavern shines).
- NeonRP is **not** a full deterministic combat engine yet; it provides hooks/contracts.
- NeonRP does **not** require vector search/embeddings; retrieval works fuzzy-only by default.

---

## 2. Core concepts (glossary)

- **Project**: a directory containing `.neonrp/` (system metadata) and `game/` (game data).
- **Entity**: a structured JSON file under `game/<kind>/<id>.json` (e.g., town, dungeon, character).
- **Event**: append-only log entry representing a turn or a system/agent action.
- **Save**: a snapshot of the project state + metadata to restore/replay later.
- **Branch**: a timeline pointer (like git branch) to isolate story lines.
- **Sandbox**: an isolated workspace derived from a save, used for experimentation. Implemented as a special branch (`kind: "sandbox"`).
- **Proposal**: a structured plan from an agent/LLM describing intended changes (not applied yet).
- **System Proposal**: a proposal generated internally by commands like `import` and `game new`, using `agent_id="system"`. Ensures all game-state mutations are auditable and replayable.
- **Diff/Patch**: a previewable set of file operations computed from a proposal.
- **Apply**: the atomic, validated commit of patches into the real game state.

---

## 3. Repository & on-disk layout

NeonRP follows "files as the database". A typical project:

```
my-game/
  .neonrp/
    manifest.json          # single source of truth: pointers, branches, entity index
    config.json            # project config (provider, model, CLI defaults)
    events/                # append-only event log(s), one file per branch
      main.jsonl
    saves/                 # snapshots + metadata
      <save_id>/
        game/             # game directory copy
        meta.json          # save_id, branch, head_event, game_hash, created
        events.jsonl       # event log copy at save time
    branches/              # per-branch game data storage (for sandbox switch)
      <branch_name>/
        game/
    logs/
      agents/<run_id>/     # agent input/output/proposal/diff/validation/apply traces
      skills/<run_id>.jsonl# tool registry calls (audited)
    embeddings.json        # optional vector index cache for retrieval
    staging/               # temporary workspace for apply pipeline (safe to delete)
    schema/                # JSON schema for data validation
    index/                 # retrieval index / caches
    mods/                  # mod installation (M5+)
  agents/
    <agent_id>/
      agent.json           # agent spec (permissions, system prompt)
  game/
    town/<id>.json
    dungeon/<id>.json
    character/<id>.json
    ...
```

### Game entity conventions
- Path: `game/<kind>/<id>.json`
- Required fields: `id`, `kind`, `name`
- Optional fields: `tags`, `summary`
- Rules: `id` is globally unique; `kind` must match path folder.

---

## 4. High-level architecture (layers)

NeonRP is intentionally layered so "creative" parts can't bypass "deterministic" parts.

```
┌─────────────────────────────────────────────────────────────┐
│ CLI Layer (click commands)                                   │
│ init/run/save/load/undo/branch/validate/index/find/context  │
│ agent/* import/* game/* sandbox/* replay/*                   │
└───────────────────────────┬─────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────┐
│ Orchestration Layer (Turn / Agent runner)                    │
│ - builds minimal context (context command + heuristics)      │
│ - calls LLM provider (or deterministic stub)                 │
│ - parses proposal → requests diff/apply                      │
│ - system proposals for import/game commands                  │
└───────────────────────────┬─────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────┐
│ Core Engine (deterministic)                                  │
│ - proposal/op schema + validators                            │
│ - permissions (deny-first, path globs)                       │
│ - diff builder (stable output)                               │
│ - apply pipeline (staging → validate → atomic swap)          │
│ - indexing/retrieval contracts                                │
└───────────────────────────┬─────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────┐
│ Storage & Audit (file-first)                                 │
│ - atomic writes (write-to-temp-then-rename)                  │
│ - event append                                               │
│ - snapshot save/load                                         │
│ - game hashing for replay                                   │
│ - branch/sandbox management                                  │
└─────────────────────────────────────────────────────────────┘
```

---

## 5. Invariants (must always hold)

These are the "non-negotiables" that keep the system stable:

1) **Append-only event log**
   - `run` and any successful apply MUST append an event.
   - Events include an `actor` field (player/system/agent_id).

2) **No direct writes from LLM/agent to game data**
   - All writes go through the apply pipeline (staging → validate → atomic swap).
   - Commands that mutate game data (`import`, `game new`) generate system proposals.

3) **Apply is atomic and auditable**
   - If validation/permission fails, the real `game/` remains unchanged.
   - On success, patch details and origin are logged.

4) **Index is derived, not authoritative**
   - `manifest.entities` is a convenience cache; source of truth is `game/`.
   - Index build/update may skip invalid entities (warn, don't crash whole index).
   - Sandbox switch invalidates the index; user must `index build` after switch.

5) **Determinism hooks exist**
   - Replay/verify relies on stable event ordering, stable patch application, and optional seeds.

6) **Event completeness**
   - All game-state mutations MUST produce an event record. This includes agent applies, imports, and game scaffolding.
   - Every event with game-state changes has a `run_id` that locates the full proposal/diff/apply logs.

7) **Path safety**
   - Branch/sandbox names are validated: no `/`, `\`, `..`, drive letters; must match `^[a-zA-Z0-9][a-zA-Z0-9._-]*$`; max 128 chars.
   - Proposal op paths must be relative with no traversal (`..`).

---

## 6. Manifest structure (current: v0.3)

```json
{
  "version": "0.3",
  "created": "2026-01-29T12:00:00+00:00",
  "current_branch": "main",
  "branches": {
    "main": {
      "head_event": 5,
      "created": "2026-01-29T12:00:00+00:00",
      "kind": "main"
    },
    "test-sandbox": {
      "head_event": 3,
      "created": "2026-01-31T10:00:00+00:00",
      "kind": "sandbox",
      "parent": "main",
      "fork_event": 2,
      "base_save": "20260131-100000"
    }
  },
  "entities": { }
}
```

**BranchMetadata fields** (M4):
- `head_event`: seq number of the latest event on this branch
- `created`: branch creation timestamp
- `kind`: `"main"` or `"sandbox"`
- `parent`: parent branch name (sandbox only)
- `fork_event`: event id at which the sandbox was forked (sandbox only)
- `base_save`: save id used to create the sandbox (sandbox only)

---

## 7. Command surface (by milestone)

### Lifecycle (M0)
- `neonrp init` : initialize `.neonrp/` structure
- `neonrp run "<text>"` : append a turn event
- `neonrp save [name]` / `neonrp load <id>` : snapshot and restore
- `neonrp undo` / `neonrp redo` : navigate turn history
- `neonrp branch <name>` : branch timeline

### Validation & retrieval (M1)
- `neonrp validate [--json]` : schema + constraints; exit codes 0/1/2
- `neonrp index build|update [--json]` : maintain `manifest.entities`
- `neonrp find [--id|--tag|--kind|keyword] [--json]` : entity search
- `neonrp context "<query>" --limit N [--json]` : minimal context retrieval

### Agents & controlled writes (M2)
- `neonrp agent new|list|show|path [--json]` : agent lifecycle
- `neonrp agent run <id> --proposal <file> [--apply] [--json]` : proposal apply
- `neonrp agent logs <run_id>` : view run logs
- `neonrp agent context <id> --query "..." [--json]` : agent-scoped retrieval

### LLM + skills + import (M3)
- `neonrp agent run <id> --query "..." [--provider stub|glm|openai] [--apply] [--json]` : LLM-driven proposal
- `neonrp import sillytavern-card <file> [--id <id>] [--json]` : character card import (JSON and PNG)
- `neonrp game new [--template <name>] [--force] [--json]` : scaffold starter game state

### Sandbox & replay (M4)
- `neonrp sandbox new <name> --from <save_id> [--switch] [--json]` : create sandbox from save
- `neonrp sandbox list [--json]` : list all branches
- `neonrp sandbox switch <name> [--json]` : switch active branch
- `neonrp sandbox drop <name> [--force] [--json]` : delete sandbox
- `neonrp replay verify --from <save_id> [--to <event_id>] [--branch <b>] [--json]` : verify determinism
- `neonrp replay checkout --from <save_id> --to <event_id> --to-branch <name> [--json]` : materialize replay as sandbox

---

## 8. Event model

Events are append-only JSONL records, one file per branch (`.neonrp/events/<branch>.jsonl`).

**Fields**:
| Field | Type | Description |
|-------|------|-------------|
| `id` | `int` | Monotonically increasing per branch |
| `timestamp` | `datetime` | ISO-8601 UTC |
| `type` | `str` | `"user"`, `"agent"`, or `"system"` |
| `actor` | `str?` | `"player"`, `"system"`, or `<agent_id>` |
| `payload` | `dict` | Type-dependent data |

**Payload by type**:
- `user`: `{"text": "..."}` — raw player input
- `agent`: `{"run_id": "...", "agent_id": "...", "applied_ops": [...], "game_hash": "..."}` — agent apply result
- `system`: `{"run_id": "...", "command": "import"|"game_new", "applied_ops": [...], "game_hash": "..."}` — system proposal result

**Why it matters**:
- Replay uses the event chain + `run_id` to locate proposals and reconstruct state.
- Audit uses actor/type/payload to attribute changes.

---

## 9. Plan → Diff → Validate → Apply pipeline

### 9.1 Proposal (structured intent)
Agents/LLM output a proposal describing:
- `agent_id`, `run_id`, `branch`, `base_head_event`
- operations: `upsert_text` (path + content) or `delete` (path)
- `rationale` (optional but helpful for review)
- `plan` steps (optional structured plan)

Op paths are **relative to `game/`** (e.g., `character/hero.json`, not `game/character/hero.json`).

### 9.2 Diff (preview)
NeonRP computes a stable unified diff:
- list of file ops with before/after content
- standard unified diff format
- ordering is deterministic (sorted by path)

### 9.3 Validate (gate)
Before apply:
- Schema validation for any touched game entities
- Constraints (id/kind/path consistency, required fields)
- Permission checks (deny-first glob matching)
- `base_head_event` freshness check (rejects stale proposals)

### 9.4 Apply (atomic commit)
- Write into `.neonrp/staging/` first
- Re-validate staged tree
- Atomically swap into real `game/` (rename old → rename new → cleanup old)
- Append event + write audit logs

---

## 10. Permissions model (deny-first)

Each agent has an **allowed write set** (glob patterns in `agent.json`):
- `write_globs`: paths the agent may write (relative to `game/`)
- `deny_globs`: paths explicitly denied (takes priority over allow)

Default is **deny** unless explicitly allowed. Violations produce actionable errors: agent_id + blocked path + matching glob + suggestion.

System proposals use `deny_globs: [".neonrp/**", "agents/**"]` — they can write anywhere in `game/` but cannot modify system metadata or agent specs.

---

## 11. Indexing & minimal context retrieval

### 11.1 `manifest.entities` index
Each indexed entry includes: `id`, `kind`, `name`, `tags`, `summary`, `path`, `mtime`, `hash`.

`index build` is full rebuild; `index update` is incremental.
When `embedding.enabled=true`, `index build` also precomputes vectors and writes `.neonrp/embeddings.json`.

**Partial failure strategy**: invalid entities are skipped with warnings. Indexing never hides validation errors; it prevents total failure.

**Sandbox interaction**: switching branches invalidates `manifest.entities` (cleared + stderr warning). User must `index build` after switch.

### 11.2 `context` retrieval
Returns a limited set of entity snippets with explainable score breakdown:
- `{"tags": float, "name": float, "summary": float, "content": float}`
- Fuzzy ranking heuristic: tags > name > summary > content snippet
- Optional hybrid mode: blends fuzzy score with cosine similarity from embedding vectors
- `read_context` and `context` auto-read embedding config; if vector path fails, they fall back to fuzzy-only

### 11.3 Embedding configuration (optional)
- Config lives under top-level `embedding`.
- Recommended minimal config:
  - `embedding.enabled=true`
  - `embedding.model_ref=<name>` (references `models.<name>`)
- Runtime resolves provider/auth/base_url/model from `models[model_ref]`.
- Optional overrides in `embedding`: `model`, `provider`, `base_url`, `api_key_env`, `api_key`, `dimensions`, `vector_weight`.

---

## 12. Agents & skills

### 12.1 Agent lifecycle
An agent is a spec (`agents/<id>/agent.json`) with:
- `agent_id`, `name`, `description`
- `system_prompt` (template for LLM)
- `write_globs` / `deny_globs` (permission boundaries)
- `retrieval_profile` (how to call `context`)

### 12.2 LLM adapter
Python Protocol interface (`core/llm.py`):
```python
class LLMAdapter(Protocol):
    def generate(self, system_prompt: str, user_prompt: str,
                 tools: list[dict] | None = None) -> LLMResponse: ...
    def chat(self, messages: list[Message],
             tools: list[dict] | None = None) -> LLMTurnResult: ...
    def chat_stream(self, messages: list[Message],
                    tools: list[dict] | None = None) -> Iterator[StreamChunk]: ...
```

Implementations: `stub` (deterministic, fixture-based), `openai` (OpenAI-compatible), `glm` (Zhipu AI via OpenAI-compatible endpoint).

M6 introduced **multi-turn agentic loop**: the agent runner calls `chat()` in a loop (up to `MAX_AGENTIC_TURNS=20`), processing tool calls (read_file, find, list_entities, read_context) each turn, until the LLM calls `submit_proposal` or exhausts turns. `chat_stream()` supports token-by-token rendering (M6-T7).

### 12.3 Skills (tool registry)
Skills are controlled helper tools exposed to an agent runner:
- Built-in: `read_context`, `find`, `read_file`, `list_entities`
- Every call is logged to `.neonrp/logs/skills/<run_id>.jsonl`
- File access respects per-file deny-first permission checks

---

## 13. Sandbox & Replay

### 13.1 Sandbox
A sandbox is a branch with `kind: "sandbox"`, derived from a save:
- Create/switch/drop without touching mainline.
- Branch names validated for path safety (no traversal attacks).
- Switch uses atomic rename strategy for `game/` replacement.
- No merge-back in M4 (future work).

### 13.2 Replay verify
Replay is a debugging/verification tool:
- Start from a baseline save's `game/` snapshot
- Re-apply proposals (located via `run_id` in events) in a staging area
- Compute game hash after each event and compare with recorded hashes
- Report first divergent event id + file path + expected/actual hash
- **Non-destructive by default** — does not write to real `game/`

### 13.3 Replay checkout
Materializes a replay result as a new sandbox:
- Replays events to target point in staging
- Creates a new sandbox branch with the resulting game state
- Crash-safe via staging + atomic swap

### 13.4 Game hash
Deterministic tree hash computed by `core/hashing.py`:
- Sort all file paths under `game/` lexicographically
- For each file: `sha256(file_bytes)`
- Concatenate: `"{relative_path}\t{file_hash}\n"` for all files
- Final hash: `sha256(concatenated_string)`

Same content always produces the same hash regardless of filesystem metadata.

---

## 14. Write atomicity & crash recovery

All file writes follow the **write-to-temp-then-rename** pattern:

1. Write content to a temporary file in the same directory
2. Call `os.replace(tmp_path, target_path)` (atomic on POSIX and NTFS)
3. On failure, the temp file is cleaned up; the original remains intact

**Directory-level atomicity** (for `game/` replacement):
1. Copy to `game.new/`
2. Rename `game/` → `game.old/`
3. Rename `game.new/` → `game/`
4. Remove `game.old/`

Used by: `apply`, `load`, `sandbox switch`, `replay checkout`.

---

## 15. Observability (logs)

NeonRP is designed so "what happened?" is always answerable:
- `.neonrp/logs/agents/<run_id>/` contains:
  - `input.json` — context bundle sent to LLM
  - `proposal.json` — parsed proposal
  - `diff.patch` — computed diff
  - `validation.json` — validation results
  - `apply.json` — apply summary
  - (agent runs also include `llm_input.json`, `llm_raw.txt`)
- `.neonrp/logs/skills/<run_id>.jsonl` — skill/tool call audit trail

---

## 16. Testing strategy & quality gates

### Test layers
- **Unit**: storage core, permissions, hashing, proposal parsing, event filtering, PNG extraction
- **Integration**: CLI chains (`init → run → save → load → undo → branch`; `import → validate → index build`; `sandbox new → apply → switch → verify isolation`)
- **E2E**: subprocess invocation of `neonrp` commands

### Quality gates (per task)
1. `ruff format .`
2. `ruff check .`
3. `pytest`
4. `opencode run` code review → save to `reviews/`
5. Apply review fixes (or document non-adoption)
6. `pytest` again
7. Log ALL review findings in `docs/PROGRESS.md` (with disposition)
8. Update `docs/ROADMAP.md` + `docs/PROGRESS.md`

---

## 17. Extension points

- New entity kinds: add `game/<kind>/...` + schema rules.
- New commands: extend CLI group (keep deterministic core separate).
- New agents: add agent spec + permissions (never bypass apply pipeline).
- New LLM providers: implement adapter Protocol; keep deterministic stub for tests.
- Future: mods/plugin mechanism (M5), sandbox merge (post-M4).

---

## 18. Relationship to other docs

- `docs/REQUIREMENTS.md` : product goals and design constraints
- `docs/ROADMAP.md` : milestone plans + acceptance criteria
- `docs/QUALITY_GATES.md` : Definition of Done / process
- `docs/PROGRESS.md` : changelog + evidence + review findings
- `docs/M*_DESIGN.md` : per-milestone design specs
- `docs/M*_TASK_CARDS.md` : per-milestone implementation task cards
- `docs/ADRs/` : Architecture Decision Records


