# M7 Task Cards — LLM Robustness + MVP Rules Engine + Docs + TUI Streaming

---

## M7-T0: Specs + ADRs (doc-first)

**Goal**: Establish design decisions before coding.

**Deliverables**:
- ADR 0019: LLM Error Handling and Retry Strategy
- ADR 0020: Game Rules Engine and Entity Schema Extension
- M7 section in ROADMAP.md
- This task cards document

**Design decisions resolved**:
1. Retry: exponential backoff 1s/2s/4s + jitter for 429/5xx/timeout; max 3; config `llm.max_retries`
2. Error categories: RetryableError, AuthError, InvalidResponseError, BudgetExhaustedError
3. Per-kind schema: JSON Schema `if/then` with kind discriminator; fields RECOMMENDED not required
4. Post-staging hook: `validate_game_rules(staged_world, proposal) -> list[RuleViolation]`
5. Streaming: `on_chunk` callback on `run_agent_agentic()`; uses `chat_stream()` when present

**Acceptance**: All ADRs accepted. Task cards created. ROADMAP updated.

**Documentation**: ROADMAP.md, ADR 0019, ADR 0020, this file.

---

## M7-T1: LLM Retry Logic + Error Categories

**Goal**: Make OpenAIAdapter resilient to transient API failures.

**Root cause**: `llm_openai.py` catch-all `except Exception` treats all errors identically — no retry, no distinction between rate-limit (transient) and auth failure (permanent).

**Changes**:
- New `core/llm_errors.py`: error hierarchy (LLMError base → RetryableError, AuthError, InvalidResponseError, BudgetExhaustedError)
- `llm_openai.py` `chat()` and `chat_stream()`: retry loop with exponential backoff (1s/2s/4s + jitter), map openai exceptions to typed errors
- `config.py`: add `llm.max_retries: int = 3`
- `agent_runner.py`: pass max_retries to adapter, log retry attempts

**Files**: `core/llm_errors.py` (new), `core/llm_openai.py`, `core/config.py`, `core/agent_runner.py`

**Acceptance**:
- 429 triggers retry with backoff (up to 3 attempts)
- 401 fails immediately with "Check API key" message
- Timeout triggers retry
- Success after transient failure → run continues normally
- All retries logged in conversation.json

**Tests** (12-15):
- Mock `openai.RateLimitError` → verify retry count and backoff
- Mock `openai.AuthenticationError` → verify immediate failure
- Mock `openai.APITimeoutError` → verify retry
- Mock success after 2 failures → verify eventual success
- Mock 3 consecutive failures → verify final error returned
- Verify config `max_retries` respected
- Verify `chat_stream()` retry on connection error

**Documentation**: Update PROGRESS.md, ROADMAP.md checkbox.

---

## M7-T2: Tool Argument Validation + submit_proposal Schema

**Goal**: Validate tool arguments before execution; tighten submit_proposal ops schema.

**Root cause**: `skills.py:116-119` defines ops items as `"type": "object"` with no structure. `_execute_tool()` passes arguments directly without validation.

**Changes**:
- `skills.py`: tighten submit_proposal ops items schema (require `op` enum, `path` minLength, optional `content`)
- New `validate_tool_arguments(name, args) -> (bool, error_msg)` function
- `agent_runner.py:_execute_tool()`: validate before dispatch, return error tool_result on failure

**Files**: `core/skills.py`, `core/agent_runner.py`

**Acceptance**:
- `read_file` with empty path → error tool_result (not crash)
- `submit_proposal` with invalid ops → error tool_result with specific message
- LLM can self-correct after receiving validation error
- All skill schemas have explicit property constraints

**Tests** (10-12):
- `validate_tool_arguments()` with valid/invalid args for each skill
- `_execute_tool()` with malformed submit_proposal → returns error
- `_execute_tool()` with missing required field → returns error
- Stub adapter sends invalid tool args → agentic loop recovers

**Documentation**: Update PROGRESS.md, ROADMAP.md checkbox.

---

## M7-T3: System Prompt Enrichment + Token Budget

**Goal**: Replace one-line fallback prompt; prevent context explosion.

**Root cause**: Fallback prompt is one sentence (`agent_runner.py:428-429`). No mechanism to detect or limit context growth across turns.

**Changes**:
- Replace fallback prompt with structured template (tools, rules, entity format, context metadata)
- New `_estimate_tokens(messages) -> int` (chars // 4 approximation)
- New config `llm.max_context_chars: int = 100000`
- Agentic loop: budget warning at 80%, termination at 100%
- Add `last_message` field to `AgentRunResult` for debugging refusal-to-submit

**Files**: `core/agent_runner.py`, `core/config.py`

**Acceptance**:
- Default prompt includes tool list + rules + context metadata
- Budget warning injected when context exceeds 80%
- Loop terminates cleanly at 100% with BudgetExhaustedError
- Refusal-to-submit error includes LLM's last response text

**Tests** (8-10):
- `_estimate_tokens()` with known message sizes
- Budget warning injected at 80%
- Budget exceeded → loop terminates
- LLM finishes without submit_proposal → error includes last message
- Token estimate matches expected range

**Documentation**: Update PROGRESS.md, ROADMAP.md checkbox.

---

## M7-T4: Real LLM E2E Test Harness

**Goal**: Infrastructure for testing with real LLM providers (not CI, locally reproducible).

**Root cause**: All 424 tests use StubAdapter. Zero real provider coverage.

**Changes**:
- New `tests/test_llm_e2e.py` with `@pytest.mark.e2e_llm` marker
- Skipped unless `NEONRP_E2E_LLM=1` env var set
- 5 scenarios: simple read+submit, create entity, invalid proposal recovery, multi-tool-call, token budget
- Assert structure (result.success, proposal not None, turns, logs exist) — not specific LLM text
- `pyproject.toml`: register `e2e_llm` marker

**Files**: `tests/test_llm_e2e.py` (new), `pyproject.toml`

**Acceptance**:
- `pytest -m e2e_llm` passes with real API key
- `pytest` (no marker) skips e2e tests
- At least 5 scenarios documented and passing
- Cost per full run < $0.10

**Tests**: 5 conditional e2e tests.

**Documentation**: Update PROGRESS.md, ROADMAP.md checkbox.

---

## M7-T5: Entity Schema Extension per Kind

**Goal**: Per-kind recommended fields in entity JSON schema.

**Root cause**: `game_entity.schema.json` has `additionalProperties: true` with no per-kind structure. LLM can write any fields with any types.

**Changes**:
- `game_entity.schema.json`: add `if/then` blocks for character (hp, max_hp, gold, inventory, location, level), item (value, weight, quantity, effects), location (connections, npcs, items_available)
- Fields RECOMMENDED not required (backward compat)
- `commands/game.py`: update template with per-kind fields

**Files**: `src/neonrp/schema/game_entity.schema.json`, `src/neonrp/commands/game.py`

**Acceptance**:
- Old entities without per-kind fields still validate
- New entities with per-kind fields validate
- `hp: -1` fails validation (minimum: 0)
- `game new` produces enriched entities with per-kind fields

**Tests** (8-10):
- Character with hp/gold/inventory → passes
- Character without hp → passes (not required)
- Character with hp=-1 → fails
- Item with value/weight → passes
- Location with connections → passes
- Backward compat: old-format entities validate

**Documentation**: Update PROGRESS.md, ROADMAP.md checkbox.

---

## M7-T6: Rules Engine — Post-staging Validation + resolve_action Skill

**Goal**: Pluggable game rules hook + mechanical outcome resolution.

**Root cause**: No enforcement of game logic constraints. LLM can set HP to -999 or gold to -100 and the proposal will pass if JSON schema validates.

**Changes**:
1. New `core/rules.py`: `RuleViolation` dataclass, `validate_game_rules()` function, MVP rules (hp_non_negative, gold_non_negative, inventory_item_valid, location_exists)
2. `apply.py`: call `validate_game_rules()` after schema validation, violations block apply
3. `skills.py`: new `resolve_action` skill (damage, heal, buy, sell, move)
4. `agent_runner.py`: add resolve_action to default prompt template

**Files**: `core/rules.py` (new), `core/apply.py`, `core/skills.py`, `core/agent_runner.py`

**Acceptance**:
- Proposal setting hp: -10 rejected with actionable error
- Proposal setting gold: -100 rejected
- `resolve_action("damage", actor="player", target="goblin", amount=20)` returns computed result
- Agent can use resolve_action results to build correct ops
- Rules run on both dry_run and real apply

**Tests** (12-15):
- `validate_game_rules()` with hp < 0 → violation
- `validate_game_rules()` with gold < 0 → violation
- `validate_game_rules()` with valid state → no violations
- `resolve_action("damage")` → correct hp calculation
- `resolve_action("heal")` → respects max_hp cap
- `resolve_action("buy")` with insufficient gold → success: false
- `resolve_action("move")` with invalid destination → valid: false
- Integration: proposal with negative hp → apply rejects
- Integration: proposal with valid state → apply succeeds

**Documentation**: Update PROGRESS.md, ROADMAP.md checkbox.

---

## M7-T7: User Documentation + Examples

**Goal**: Make NeonRP approachable to new users.

**Root cause**: README has 7-line quickstart but no tutorial. TUI undocumented. No example agents or rich worlds.

**Deliverables**:
- `docs/TUTORIAL.md`: "Your first game" walkthrough (init → game new → validate → agent new → run → TUI)
- `docs/CLI_REFERENCE.md`: all 14+ commands with synopsis, options, examples, exit codes
- `docs/TUI_GUIDE.md`: layout, keybindings, `:commands`, auto-apply, session persistence
- `README.md`: add TUI section, documentation links
- `examples/starter-game/`: rich game template (3 locations, 2 NPCs, player, items)

**Files**: `docs/TUTORIAL.md` (new), `docs/CLI_REFERENCE.md` (new), `docs/TUI_GUIDE.md` (new), `README.md`, `examples/` (new dir)

**Acceptance**:
- New user can follow tutorial zero-to-first-turn
- All 14+ commands documented with examples
- TUI keybindings and commands documented
- Example world passes `validate` + `index build`

**Tests**: None (docs). Validate example world files.

**Documentation**: All deliverables ARE documentation.

---

## M7-T8: TUI Streaming Integration

**Goal**: Connect chat_stream() to TUI transcript for real-time rendering.

**Root cause**: LLM layer has `chat_stream()` (M6-T7), but TUI still calls `chat()` and renders all-at-once.

**Changes**:
- `agent_runner.py`: add `on_chunk: Callable[[str], None] | None` to `run_agent_agentic()`
- When `on_chunk` present: use `chat_stream()`, call callback for each delta
- During tool rounds: call `on_chunk("[using tools...]\n")`
- `dispatcher.py`: pass `on_chunk` through
- `tui/app.py`: define callback with `call_from_thread`, use `run_worker()`, show `[thinking...]`

**Files**: `core/agent_runner.py`, `core/dispatcher.py`, `tui/app.py`

**Acceptance**:
- TUI shows tokens incrementally (not all-at-once)
- Tool call rounds show indicator
- Non-streaming providers unaffected (callback=None)
- Ctrl+C during streaming terminates cleanly

**Tests** (6-8):
- `run_agent_agentic()` with on_chunk → callback called with delta text
- Without on_chunk → falls back to `chat()` (existing behavior)
- Streaming with tool calls → callback receives tool indicator
- Stub adapter streaming → TUI test verifies incremental updates

**Documentation**: Update PROGRESS.md, ROADMAP.md checkbox.

---

## M7-T9: Review Gate

**Process**:
1. `ruff format .` + `ruff check .`
2. `pytest` (all tests green)
3. `opencode run` code review → `reviews/M7_review_YYYYMMDD.md`, delete tmp.txt
4. Apply review fixes
5. `pytest` again
6. PROGRESS.md entries for all tasks
7. ROADMAP.md checkboxes all checked
8. Documentation completeness: TUTORIAL, CLI_REFERENCE, TUI_GUIDE exist
9. Session handoff note

**Documentation**: PROGRESS.md entry with all review findings.

