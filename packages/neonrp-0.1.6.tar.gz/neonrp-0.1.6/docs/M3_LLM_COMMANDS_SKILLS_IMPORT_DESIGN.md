# M3 Design: LLM Integration + Commands/Skills + Import

This document specifies M3 (LLM integration + commands/skills + import) to guide implementation and acceptance (see `docs/ROADMAP.md` M3-T0~T7).

## Goals (M3)
- **End-to-end agent execution**: `neonrp agent run <id>` invokes an LLM to produce a `proposal.json`, then uses the M2 pipeline to preview/apply.
- **Skill tool registry**: tools callable by the LLM/agent, with auditing and permission-aware enforcement.
- **Import**: `neonrp import sillytavern-card <file>` maps character cards into `game/` entities.
- **Game scaffolding**: `neonrp game new` creates a playable starter world (player + starting location + minimal entities).

## Non-goals (M3)
- No multi-agent scheduler / concurrency.
- No embedding/vector index.
- No sandbox/merge workflows (M4).
- No agentic loop (multi-turn tool calls → LLM → tool calls). M3 is single-shot: LLM produces one proposal per invocation. Agentic loop deferred to M3.5+.
- No PNG-based SillyTavern card extraction (deferred to M3.5+; see Resolved Questions).

## Configuration

### Project config file
Add a project-level config file under `.neonrp/`:
- `.neonrp/config.json`

Minimal fields:
- `llm.provider`: string (e.g. `openai`, `anthropic`, `local`, `stub`)
- `llm.model`: string
- `llm.temperature`: number
- `llm.max_output_tokens`: number
- `llm.seed`: optional number (when supported)

Design notes:
- The config file is optional; CLI flags override config.
- Secrets (API keys) are NOT stored in repo; use env vars (`NEONRP_LLM_API_KEY` or provider-specific like `OPENAI_API_KEY`).

## LLM Adapter Interface

### Purpose
Provide a small, testable abstraction so `agent run` can work with multiple providers, while tests use a deterministic stub provider.

### Python interface

```python
from typing import Protocol

class LLMResponse:
    """Response from an LLM adapter."""
    proposal_text: str | None  # Raw proposal JSON text (to be parsed)
    raw_output: str            # Full raw LLM output (for logging)
    usage: dict                # Token usage info (prompt_tokens, completion_tokens)

class LLMAdapter(Protocol):
    """Interface for LLM providers."""
    def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        tools: list[dict] | None = None,  # JSON schema for available skills
    ) -> LLMResponse:
        """Generate a response from the LLM.

        Args:
            system_prompt: Agent's system.md content
            user_prompt: Constructed from query + context items
            tools: Skill tool schemas (M3 passes but does NOT process tool calls)

        Returns:
            LLMResponse with proposal text and raw output
        """
        ...
```

### Calling model (M3)
M3 uses **single-shot** calling: one `generate()` call per `agent run`. The LLM must return a complete proposal in one response. Multi-turn tool call loops are deferred to M3.5+.

### Stub provider
The `stub` provider is for tests and CI (no network required):
- Constructor accepts an optional `fixture_path: Path` parameter
- If `fixture_path` is provided: load proposal JSON from that file and return it as `proposal_text`
- If no fixture: return a hardcoded minimal valid proposal (empty ops, matching agent_id/branch/base_head_event from the user prompt)
- Always deterministic: same input → same output

### Error handling
- LLM output that cannot be parsed as valid proposal JSON → log raw output to `llm_raw.txt`, exit code 1 with parsing error details
- LLM API errors (auth, rate limit, network) → exit code 2 with error message
- No retries in M3 (caller can rerun manually)

### Logging
All LLM I/O is logged under `.neonrp/logs/agents/<run_id>/`:
- `llm_input.json`: system prompt, user prompt, tool schemas
- `llm_raw.txt`: raw LLM output (before parsing)
- `proposal.json`: parsed proposal (if successful)

## Skill Tool Registry

### What is a skill
A skill is a controlled tool callable by the LLM/agent runner. Skills are NOT free-form file writes. All mutations still go through proposal → apply.

### Built-in skills (initial set)
- `read_context(query, limit)` → wraps M1 `context` core logic
- `find(query, filters...)` → wraps M1 `find`
- `read_file(path)` → reads a file within agent `read_globs`
- `list_entities(filters...)` → reads `manifest.entities`

Optional (M3.5+):
- `validate_game_data()` → run M1 validation

### Permission model
Permission checks are enforced **per file accessed**, not per skill:
- `read_file(path)`: check `path` against agent's `read_globs` and `deny_globs` (deny first)
- `read_context(query)`: each returned entity's `path` is checked; denied paths are filtered out silently (logged as warning)
- `find(query)`: same as `read_context` — filter denied paths
- `list_entities()`: reads `manifest.entities` — covered by default `read_globs` including `.neonrp/manifest.json`

When a skill access is denied:
- The skill returns an error result to the caller (not a crash)
- The denial is logged in the skill audit log
- The agent run does NOT abort — the LLM can handle the error in its response

### Auditing
Every skill invocation writes a record:
- `.neonrp/logs/skills/<run_id>.jsonl`

Record fields:
- `timestamp`, `run_id`, `agent_id`
- `skill_name`, `args`
- `result_summary` (bounded to 500 chars), `error` (if any)
- `duration_ms`
- `denied_paths` (list of paths filtered due to permission, if any)

## Agent Run Flow (M3)

### Pipeline
1) Load agent spec (`agents/<id>/agent.json` + system prompt)
2) Retrieve context (M1 `context`, honoring `context_limit`)
3) Build user prompt from query + context items
4) Call LLM adapter (`generate()`) — single-shot
5) Parse LLM output into `proposal.json` (validate proposal schema)
6) Render plan + diff (M2 `render_diff`)
7) If `--apply`: call existing `apply_proposal()` from `core/apply.py` (M2 pipeline)
8) Log everything under `.neonrp/logs/agents/<run_id>/`

### Relationship with existing M2 commands
- `neonrp agent run <id> --query "..."` is the **new** M3 entry point (LLM-driven)
- `neonrp agent apply <id> --proposal <path>` remains as the **manual** entry point (no LLM, loads pre-built proposal)
- `agent run --apply` internally calls the same `apply_proposal()` that `agent apply` uses
- `agent run` without `--apply` is dry-run: shows plan + diff, saves logs, does not write to game/

### Output contracts
- Default: human-readable (plan + diff summary + where logs are saved)
- `--json`: machine-readable payload including `run_id`, `proposal_path`, `diff_path`, `validation` summary

### Failure modes
- LLM output invalid proposal → exit code 1, include parsing errors and suggestion
- Permission denied (skill read / write ops) → exit code 1
- System errors (IO/config/LLM API) → exit code 2

## SillyTavern Character Card Import

### Supported inputs (M3)
- JSON character card exports (`.json`)
- PNG-based cards: deferred to M3.5+ (see Resolved Questions)

### Output mapping
Create a `game/character/<id>.json` entity with:
- `id`, `kind = "character"`, `name`
- `summary` (derived from `description` field; truncated to 200 chars if longer)
- `tags` (if present in source; otherwise empty list)
- `meta.source = "sillytavern"`
- `meta.raw`: full original imported payload (embedded, not sidecar; see Resolved Questions)

### ID strategy
- If user passes `--id`, use it.
- Else derive from name (kebab-case: lowercase, replace spaces/special chars with `-`, strip leading/trailing `-`).
- Uniqueness: if derived ID conflicts with existing entity, append `-2`, `-3`, etc.

### CLI
- `neonrp import sillytavern-card <file> [--id <id>] [--json]`
- Exit codes: `0` success, `1` invalid input/validation failure, `2` system error

## Game Scaffolding

### Command
- `neonrp game new [--template <name>] [--force] [--json]`
- `--force`: overwrite existing game/ files (without --force, refuses if game/ has entities)
- Exit codes: `0` success, `1` conflict/validation failure, `2` system error

### Minimal template output

Templates are **hardcoded in code** (a function that generates entity dicts). Custom template directories deferred to M5.

**Default template entities:**

`game/player/player.json`:
```json
{
  "id": "player",
  "kind": "player",
  "name": "Player",
  "tags": ["player"],
  "summary": "The player character."
}
```

`game/town/start-town.json`:
```json
{
  "id": "start-town",
  "kind": "town",
  "name": "Starting Town",
  "tags": ["town", "starting-area"],
  "summary": "A small town where the adventure begins."
}
```

`game/npc/old-sage.json`:
```json
{
  "id": "old-sage",
  "kind": "npc",
  "name": "Old Sage",
  "tags": ["npc", "quest-giver"],
  "summary": "A wise elder who guides new adventurers."
}
```

The template must pass `neonrp validate` and work with `index build`.

## Testing & Acceptance
- Unit: LLM adapter stub determinism; skill registry permission enforcement (per-file); import mapping deterministic; game template validation
- Integration: init → validate → index build → agent run (stub) → diff → apply → find/context sees changes
- E2E: subprocess `neonrp agent run --provider stub` verifies exit codes, logs, and world changes

## Resolved Questions
The following questions were identified during review and have been decided:

1. **PNG card extraction**: Deferred to M3.5+. M3 guarantees JSON card import only. PNG format drift makes extraction unreliable without ongoing maintenance.
2. **Raw imported card data storage**: Use `meta.raw` (embedded in the entity JSON). Single-file-per-entity is simpler than sidecar management and avoids orphaned files.
3. **Command plugin mechanism**: M3 continues using explicit click group registration in `cli.py` (current pattern). Click entry points or a `commands/registry.py` are deferred to M5 when mods need dynamic command loading.

