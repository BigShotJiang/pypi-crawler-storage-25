# NeonRP TUI Guide

The NeonRP Terminal User Interface (TUI) provides a rich, interactive experience for playing and developing text RPGs.

## Launching the TUI

```bash
neonrp tui
```

### Options

| Option | Description |
|--------|-------------|
| `--branch` | Branch to use (default: current branch) |
| `--provider` | LLM provider override |
| `--continue` | Continue the previous branch session |
| `--new` | Start a fresh session (default) |
| `--import-card` | Import a SillyTavern JSON/PNG card on startup |
| `--import-id` | Override imported entity ID for `--import-card` |
| `--verbose` | Enable verbose diagnostics |

### Examples

```bash
# Default launch
neonrp tui

# Launch with specific branch
neonrp tui --branch experiment

# Launch with provider override
neonrp tui --provider openai

# Import a Tavern card before the first turn
neonrp tui --import-card character.png --import-id my-character
```

Fresh directories can be opened in TUI before scaffolding a game. Run `/init` and start working in build mode immediately; `/game new` is only needed when you want the default starter world and play-agent scaffold.

## Layout

The TUI uses a 4-pane layout:

```
┌─────────────────────────────────────────────────────────────────┐
│ Status Bar: project │ branch │ event │ turn │ [AUTO]/[manual]   │
├──────────┬────────────────────────────────┬─────────────────────┤
│          │                                │                     │
│Navigator │         Transcript             │      Details        │
│          │                                │                     │
│ 📁 Files │  Query and response history    │  Diff preview,      │
│ 📂 game │                                │  file contents      │
│ 📂 agents│                                │                     │
│ 📂 logs  │                                │                     │
│          │                                │                     │
├──────────┴────────────────────────────────┴─────────────────────┤
│ Input: Enter query for agent, or /command...                    │
├─────────────────────────────────────────────────────────────────┤
│ Footer: q Quit │ Ctrl+K Commands │ Ctrl+Enter Submit │ t Auto   │
└─────────────────────────────────────────────────────────────────┘
```

### Panes

| Pane | Description |
|------|-------------|
| **Status Bar** | Shows project name, branch, head event, turn count, and auto-apply status |
| **Navigator** | File tree browser for `game/`, `agents/`, and `.neonrp/logs/` |
| **Transcript** | Chat-style log of queries, responses, and command output |
| **Details** | Displays diff previews, file contents, and context information |
| **Input** | Text input for agent queries and `/` commands |
| **Footer** | Shows available keybindings |

## Keybindings

### Global Keybindings

| Key | Action | Description |
|-----|--------|-------------|
| `q` | Quit | Exit the TUI |
| `Ctrl+K` | Commands | Open command palette |
| `Ctrl+P` | Commands | Open command palette (alternative) |
| `Ctrl+Enter` | Submit | Submit current input |
| `t` | Auto | Toggle auto-apply mode |
| `a` | Apply | Apply pending proposal |
| `u` | Undo | Undo last change |
| `s` | Save | Create save snapshot |
| `g` | Recent Run | Show most recent agent run |
| `Tab` | Next Pane | Focus next pane |

### Input Field

| Key | Action |
|-----|--------|
| `Enter` | Submit query or command |
| `Ctrl+Enter` | Submit (alternative) |

## Input Modes

### Agent Queries

Type a natural language query and press Enter:

```
look around
```

The dispatcher will:
1. Select an appropriate agent
2. Retrieve relevant context
3. Generate a proposal
4. Show diff preview in Details pane

### TUI Commands

Prefix commands with `/` for TUI-specific operations:

```
/validate
/save my-checkpoint
/undo
```

## TUI Commands Reference

### Validation & Indexing

| Command | Description |
|---------|-------------|
| `/validate` | Validate game data against schema |
| `/index build` | Full rebuild of entity index |
| `/index update` | Incremental index update |

### Search

| Command | Description |
|---------|-------------|
| `/find <keyword>` | Search entities by keyword |
| `/context <query>` | Get ranked context for a query |

### State Management

| Command | Description |
|---------|-------------|
| `/save [name]` | Create save snapshot (includes current branch session) |
| `/load [name]` | Load a save snapshot, or open a picker when omitted |
| `/undo` | Undo last change |

### WorldLines

| Command | Description |
|---------|-------------|
| `/worldlines` | Open the guided WorldLines world picker |
| `/worlds` | Browse available worlds and scaffold the selected template |

### Sandbox Management

| Command | Description |
|---------|-------------|
| `/sandbox list` | List all sandboxes |
| `/sandbox new <name> [--from <save_id>]` | Create new sandbox |

### Replay

| Command | Description |
|---------|-------------|
| `/replay verify --from <save_id>` | Verify replay determinism |

### Utility

| Command | Description |
|---------|-------------|
| `/init` | Initialize the current directory as a NeonRP project |
| `/import sillytavern-card <file> [--id <id>]` | Import a SillyTavern JSON/PNG card into the project |
| `/help` or `/?` | Show available commands |
| `/quit` or `/q` | Exit TUI |

## Auto-Apply Mode

Auto-apply mode automatically applies proposals after generation, enabling a seamless gameplay loop.

### Toggle Auto-Apply

Press `t` to toggle auto-apply mode. The status bar shows:
- `[AUTO]` (red) - Auto-apply enabled
- `[manual]` (dim) - Manual apply required

### Manual Apply

When auto-apply is off:
1. Run a query
2. Review the diff in the Details pane
3. Press `a` to apply, or run another query to discard

### Persistence

Auto-apply state is persisted across TUI sessions.

## Session Persistence

The TUI automatically saves and restores session state:

### What's Saved

- Turn count
- Recent transcript entries (last 20 messages)
- Auto-apply preference

### Session Restore

When launching the TUI, previous session entries are restored with a visual separator:

```
── Restored session ──
> look around
The town square is bustling with activity...
> talk to the sage
The old sage greets you warmly...
── 4 message(s) restored ──
```

## File Browser

The Navigator pane shows a tree view of:

- `📂 game/` - Game entities
- `📂 agents/` - Agent definitions
- `📂 .neonrp/logs/` - Agent run logs

### Viewing Files

Click or select a file to view its contents in the Details pane.

Supported file types:
- `.json` - Entity and configuration files
- `.md` - Markdown files (system prompts)
- `.txt` - Text files (diffs, logs)

## Workflow Examples

### Basic Gameplay Loop

1. Launch TUI: `neonrp tui`
2. Enable auto-apply: Press `t`
3. Enter queries: `look around`, `talk to the sage`, etc.
4. Changes are automatically applied
5. Save progress: Press `s` or `/save checkpoint`

### Experimental Workflow

1. Create a save: `/save before-experiment`
2. Create sandbox: `/sandbox new experiment --from before-experiment`
3. Try risky actions with auto-apply
4. If unhappy, switch back: `/sandbox switch main`

### Review Workflow

1. Disable auto-apply: Press `t` (ensure `[manual]` shown)
2. Run query
3. Review diff in Details pane
4. Press `a` to apply, or enter new query to discard
5. Use `/undo` if needed

## Streaming Output

The TUI supports streaming LLM responses. As the agent generates content, you'll see incremental output in the Transcript pane:

```
Query: describe the marketplace
Running dispatcher (provider: openai, agentic: True)...
Thinking...
Assistant:
The marketplace is alive with...
vendors calling out their wares...
colorful stalls line the cobblestone...
✓ Agent run complete (agent: narrator, run_id: 20240115-143022)
```

## Troubleshooting

### "Not in a NeonRP project"

Run `neonrp init` in your project directory before launching the TUI.

### "No pending proposal to apply"

Run an agent query first. The proposal is cleared after applying or when running a new query.

### Slow Response

- Check your LLM provider configuration
- Use `--provider stub` for testing without LLM calls
- Reduce context limit in agent configuration

### Session Not Restoring

Session files are stored per-branch in `.neonrp/sessions/`. Ensure the branch exists and has previous activity.

## Tips

1. **Use auto-apply for immersive gameplay** - Toggle with `t` for seamless turns
2. **Review diffs for important decisions** - Disable auto-apply when stakes are high
3. **Save frequently** - Use `s` or `/save` before risky actions
4. **Use sandboxes for experimentation** - Create branches to try different paths
5. **Check the Details pane** - It shows diffs, file contents, and helpful context
