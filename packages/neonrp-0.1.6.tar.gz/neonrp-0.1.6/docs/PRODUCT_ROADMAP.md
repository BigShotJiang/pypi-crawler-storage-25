# Product Roadmap — NeonRP / WorldLines

> User-facing release-level direction. For engineering-level milestone
> tracking (M0–M15, L14, …) see [`ROADMAP.md`](ROADMAP.md).
> For per-release changelogs see [`releases/`](releases/).

## Release overview

| Version | Theme | Status |
|---|---|---|
| [v0.1.0](releases/v0.1.0.md) | First public release — engine + TUI + MCP + Worldlines launcher | Shipped |
| [v0.1.5](releases/v0.1.5.md) | Discord bridge, i18n, launcher polish, multi-select saved-run delete | Shipped |
| [v0.1.6](releases/v0.1.6.md) | **Dark Train** template + HUD narrative spec + install UX | **Current** |
| v0.2    | Agent + game-data standards · stable orchestrator · narrative visualization · multi-agent mode · character agent · App | **Next** |
| v0.3    | Sandbox · World platform · Character platform · multi-platform · richer gameplay | Planned |
| v1.0    | Community template marketplace · 1.0 protocol · hardened agent engine | Planned |

---

## v0.2 — Agent & game-data contracts, stable orchestration, multi-agent

The v0.1.x line shipped the first playable templates and Discord
bridge. v0.2 is about making the authoring + execution surface
**stable enough** that a third party can write a new world template
without reading the engine source.

### 1. Agent & game-data standards

- Frozen `agent.json` schema: `id`, `name`, `description`, `tools`,
  `model`, `presentation_hidden`, `task_model`, prompt source, MCP
  entries.
- Frozen `runtime_contract.json`: execution modes (`fast` /
  `orchestrator`), startup entry agent, routing declarations.
- Frozen `game/` data contract: entity kinds, path convention
  `game/<kind>/<id>.json`, required fields, relationship declarations.
- `neonrp validate` covers all three, with actionable errors.

### 2. Stable agent orchestration

- Orchestrator mode: one world-agent does every turn's top-level loop;
  `presentation_hidden` specialists are called via `task()` and
  return structured beats the world-agent weaves into prose.
- Reproducible routing: no more "sometimes the wrong agent narrates."
- Hidden-agent output is never surfaced to the player unless the
  world-agent explicitly forwards a quoted beat.
- Regression suite of canonical scenarios that catch routing drift.

### 3. Narrative visualization polish

- Per-turn HUD line (already shipped for `dark-train`) becomes a
  general-purpose pattern: agents declare an optional `hud_renderer`
  that the TUI picks up.
- Speaker-header suppression / collapsing unified across TUI, session
  replay, and Discord.
- Semantic folding of tool-heavy turns so the transcript stays
  narrative-first.

### 4. Multi-agent mode

- Two or more player-facing agents taking turns within a single
  session, coordinated by the orchestrator.
- Handoff protocol that doesn't leak routing into the prose.

### 5. Character agent

- First-class `character-agent` concept (distinct from `npc-mind`):
  persistent per-character memory, inventory, relationship graph, and
  dialogue style card.
- Authoring flow in the TUI: `/character new`, `/character edit`,
  import-from-tavern.

### 6. App correspondence

- Desktop App (Electron-ish shell wrapping the TUI) targeted at users
  who won't install a terminal toolchain.
- Feature parity with the curl-installed CLI / launcher.
- First-run experience: pick template, pick model, play — no config
  files.

---

## v0.3 — Sandbox, platforms, richer gameplay

v0.2 stabilizes the authoring contract. v0.3 turns that contract into
a distribution surface.

- **Sandbox** — promoted from engineering feature to user-facing
  flow: branch your save, try a risky path, commit / revert from the
  TUI or App without shell commands.
- **World platform** — a browsable catalog of worlds (first-party +
  imported), with install / update / delta previews.
- **Character platform** — same shape as the world platform, scoped to
  characters: import from tavern cards, share custom ones, attach to
  any compatible world.
- **Multi-platform support** — serious story mode on mobile (read the
  transcript, answer `ask_user` prompts) alongside the desktop App.
- **Richer gameplay design** — deterministic game-mechanic tools (roll
  checks, inventory transactions, time-of-day systems), more complex
  world content, clearer tool taxonomy.

Exact scope is TBD and will be sharpened during the v0.2 cycle.

---

## v1.0 — Community marketplace, protocol freeze

- **Community template marketplace** — anyone can publish a world /
  character pack; the App / launcher can install from it.
- **1.0 protocol** — agent, game-data, and runtime-contract schemas
  frozen with backwards-compat guarantees. Breaking changes require
  v2.0.
- **Hardened agent engine** — long-session reliability, context
  compression, persistent sub-agent mailboxes, resumable turn loops
  (the M13 engineering milestone feeds this).
- **TBD** — specific marketplace mechanics, moderation model, revenue
  share (if any) deferred to the v0.3 → v1.0 transition.

---

## Where things live

- **Engineering milestones (M0–M15, L14):** [`ROADMAP.md`](ROADMAP.md)
- **Per-release changelogs:** [`releases/`](releases/)
- **Auto-update + release pipeline:** [`releases.md`](releases.md)
- **TUI spec:** [`TUI_GUIDE.md`](TUI_GUIDE.md),
  [`L14_UNIFIED_TUI_SPEC.md`](L14_UNIFIED_TUI_SPEC.md)
