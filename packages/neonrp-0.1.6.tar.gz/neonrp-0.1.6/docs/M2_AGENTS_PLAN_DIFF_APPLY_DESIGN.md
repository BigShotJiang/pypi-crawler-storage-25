# M2 Design: Agents + Plan/Diff/Apply

本文件定义 M2（Agents + Plan/Diff/Apply）的设计规格，用于指导实现与验收（见 `docs/ROADMAP.md` 的 M2-T0~T6）。

## Goals (M2 必达)
- **Agent lifecycle**：支持 agent 的创建/列出/查看/运行/测试/日志/重跑（rerun）。
- **Plan→Diff→Validate→Apply**：所有写入必须走可审计流程，且能在失败时给出可修复的错误。
- **Permission boundaries**：agent 只能写入它声明的 owned paths；越权必须失败。
- **Retrieval integration**：agent run 默认使用 M1 的 `context` 结果作为最小上下文。
- **Event log integration**：agent apply 成功后追加事件日志，与 undo/replay 体系联通。

## Non-goals (M2 不做)
- 不做完整 skill registry / marketplace（放到 M3）。
- 不做并行多 agent 调度（先串行 + 可重放）。
- 不做复杂 merge/cherry-pick（沙盒/合并放到 M4）。
- 不要求接入真实 LLM：实现与测试可以使用 stub agent（确定性输出 proposal）。

## Agent Packaging

### Directory layout
Agent 作为"项目资产"，放在项目根目录的 `agents/`（而不是 `.neonrp/`），便于版本控制与协作：

- `agents/<agent_id>/agent.json` — agent 定义（权限、提示词入口、默认参数）
- `agents/<agent_id>/system.md` — system prompt
- `agents/<agent_id>/README.md` — 可选：该 agent 的职责与使用说明

`.neonrp/` 仅存放运行态输出：
- `.neonrp/logs/agents/<run_id>/...` — agent 调用与应用日志

### Agent spec (agent.json)
M2 最小字段（示例）：

```json
{
  "id": "town-master",
  "name": "Town Master",
  "description": "Maintains town entities and quests.",
  "version": "0.1",
  "system_prompt": "agents/town-master/system.md",
  "permissions": {
    "read_globs": ["game/**", ".neonrp/manifest.json"],
    "write_globs": ["game/town/**"],
    "deny_globs": [".neonrp/**", "agents/**"]
  },
  "defaults": {
    "context_limit": 8
  }
}
```

约定：
- `id` 必须与目录名一致。
- `deny_globs` 默认应包含 `.neonrp/**`（避免篡改控制目录）和 `agents/**`（避免 agent 互相篡改定义）。

## Proposal Format

### Overview
M2 的核心交付是"结构化提案（proposal）"，它是 Plan→Diff→Apply 的输入。

推荐：`proposal_version = "0.1"`，并在未来通过版本字段做迁移。

### Minimal schema (proposal.json)

```json
{
  "proposal_version": "0.1",
  "agent_id": "town-master",
  "run_id": "20260129T235900Z_a1b2c3",
  "branch": "main",
  "base_head_event": 12,
  "query": "Add a new shop in Tokyo.",
  "context": {
    "items": [
      {"entity_key": "town:tokyo", "path": "game/town/tokyo.json"}
    ]
  },
  "plan": [
    {"step": 1, "title": "Update town inventory", "rationale": "Add shop metadata"}
  ],
  "ops": [
    {
      "op": "upsert_text",
      "path": "game/town/tokyo.json",
      "content": "{ ... }",
      "content_type": "application/json"
    }
  ]
}
```

### Ops vocabulary (M2)

| op | 语义 | 必需字段 | 行为 |
|----|------|---------|------|
| `upsert_text` | 创建或替换整个文件 | `path`, `content` | path 不存在则创建（含父目录）；存在则替换全部内容 |
| `delete` | 删除文件 | `path` | path 不存在时视为 no-op（幂等），输出 warning |

所有 op 的公共约束：
- `path` 必须是相对项目根目录的路径，使用 `/` 分隔
- `path` 不允许包含 `..`（路径逃逸）
- `content`（upsert_text）为 UTF-8 文本
- `content_type`（可选）默认 `application/json`，M2 不消费此字段，为 M3 JSON patch 预留

> M3+ 可扩展：`json_patch`、`append_text` 等，但不改变 proposal 的"版本化 + 可验证"原则。

### run_id format
格式：`{ISO8601 compact UTC}_{6字符 hex random}`

示例：`20260129T235900Z_a1b2c3`

- 由 CLI 在 `agent run` 启动时生成
- 写入 proposal.json 和日志目录名
- rerun 时生成新的 run_id，在 input.json 中记录 `rerun_of: <original_run_id>`

## Permission Boundaries

### Rules
- 每个 op 的目标 `path` 必须：
  1) 不匹配 agent 的 `deny_globs`（deny 优先）
  2) 至少匹配一个 `write_globs`
- 读权限：M2 soft enforce — 记录 agent 实际读取的文件清单到 `input.json` 的 `read_files` 字段，但不阻止读取。M2.5+ 可硬隔离。

### Error reporting
越权错误必须包含：
- agent_id
- 目标 path
- 命中/未命中的 glob
- 修复建议（例如：调整 permissions.write_globs 或移动文件到 owned path）

## Plan → Diff → Validate → Apply

### Pipeline
1) **Plan**：展示 `proposal.plan`（人类可读）
2) **Diff**：对 `ops` 生成 unified diff（或逐文件 before/after 摘要）
3) **Validate**：对"应用后的世界状态"执行：
   - M1 schema validation（结构层）
   - M1 constraints（id 唯一、kind/path 一致）
4) **Apply**：仅当 validate 通过才写入，写入必须使用 atomic write（temp→rename）
5) **Log**：落盘 proposal、diff、validation 结果、apply 结果
6) **Event**：追加事件日志（见 Event log integration）

### Staging strategy
M2 使用全量复制 `game/` 到临时 staging 目录：
- 把整个 `game/` 复制到临时目录
- 在 staging 上 apply ops
- 在 staging 上执行 validate
- validate 通过后用 atomic_write_dir 将 staging 写回真实 `game/`
- validate 失败时清理 staging，真实 `game/` 不被污染

> 与 ADR 0003（save 全量复制）策略一致，正确性优先。后续可优化为只复制受影响文件。

## Event Log Integration

### Agent apply 与事件日志的关系
Agent apply 成功后，必须向 `.neonrp/events/<branch>.jsonl` 追加一条事件：

```json
{
  "id": 13,
  "timestamp": "2026-01-29T23:59:00+00:00",
  "type": "agent",
  "actor": "town-master",
  "payload": {
    "run_id": "20260129T235900Z_a1b2c3",
    "query": "Add a new shop in Tokyo.",
    "ops_count": 1,
    "applied_paths": ["game/town/tokyo.json"]
  }
}
```

### 规则
- `type` 设为 `"agent"`
- `actor` 填入 `agent_id`（需要 Pre-M2 housekeeping 在 GameEvent 中添加 actor 字段）
- `payload` 包含 `run_id`、`query`、`ops_count`、`applied_paths`
- `manifest.branches[current].head_event` 同步递增
- 如果 `proposal.base_head_event != manifest.branches[current].head_event`，拒绝 apply 并报错（过期提案，需要 rerun）

### 与 undo/replay 的关系
- `undo` 可回退 agent apply（回退到上一个 head_event 对应的状态）
- M4 replay 可通过事件日志中的 `run_id` 定位对应的日志目录，重放 agent 操作

## CLI Surface (M2)

### Commands
- `neonrp agent new <id>`：创建 agent 模板目录（agent.json + system.md）
- `neonrp agent list [--json]`：列出 agent
- `neonrp agent show <id> [--json]`：打印 agent.json
- `neonrp agent path <id>`：打印 agent 目录路径（供用户手动编辑）
- `neonrp agent run <id> --query "..." [--proposal <path>] [--apply] [--json]`：运行 agent
- `neonrp agent test <id>`：使用 fixtures 做一次确定性测试
- `neonrp agent logs [--tail N] [--json]`：查看最近的 agent runs
- `neonrp agent rerun --last`：重跑最近一次 run

> 注意：不使用 `neonrp run --agent`。`neonrp run` 保持 M0 的 echo placeholder，`neonrp agent run` 是 agent 的唯一入口。

### `--proposal <path>` 参数
`agent run` 接受 `--proposal <path>` 直接加载 proposal JSON 文件，跳过 LLM 调用。用途：
- 测试：使用预定义的 proposal fixture
- 调试：手动构造 proposal 验证 apply 流程
- stub agent：fixture 中放置固定 proposal

### Output format convention
延续 M1 约定：所有 agent 子命令支持 `--json` 输出标志（list/show/run/logs）。

### Exit codes
- `0`: success
- `1`: user input / proposal invalid / permission denied / validation failed / base_head_event mismatch
- `2`: system error (IO, missing config, corrupt manifest)

## Logging

### Layout
- `.neonrp/logs/agents/<run_id>/input.json`
- `.neonrp/logs/agents/<run_id>/proposal.json`
- `.neonrp/logs/agents/<run_id>/diff.patch`
- `.neonrp/logs/agents/<run_id>/validation.json`
- `.neonrp/logs/agents/<run_id>/apply.json`

### input.json minimal fields
- run_id, agent_id, branch, base_head_event
- query
- context_items (来自 M1 context 的结果)
- read_files（agent 实际读取的文件清单，soft enforce 日志）
- rerun_of（如果是 rerun，记录原始 run_id）

### apply.json minimal fields
- success: bool
- applied_paths: list[str]
- event_id: int（追加的事件 id）
- error: string | null

## Stub Agent Testing Strategy

### Fixture location
- `tests/fixtures/agents/stub-agent/agent.json` — 定义 `write_globs: ["game/town/**"]`
- `tests/fixtures/agents/stub-agent/system.md` — 占位 system prompt

### 测试方式
1. **`--proposal <path>` 参数**：`agent run stub-agent --proposal tests/fixtures/proposals/add-shop.json --apply`
2. 测试不依赖 LLM，直接加载预定义 proposal
3. 验证：权限检查 → diff 预览 → validate → apply → event 追加 → 日志落盘

### 越权测试
- `tests/fixtures/proposals/bad-permission.json` — ops 目标路径超出 write_globs
- 验证：exit code = 1，错误信息包含路径和 glob

## Testing & Acceptance
- 单测：权限判定（glob 匹配、deny 优先、路径逃逸拒绝）、proposal 解析与规范化、diff 生成稳定性、event 追加
- 集成：init → index build → agent run (stub + --proposal) → diff preview → validate+apply → event log 包含 agent 事件 → find/context 能看到变更
- E2E：subprocess 调 CLI，检查 exit code 与日志落盘

## Resolved Questions
以下问题已在审查中决定（原 Open Questions）：

1. **读权限硬隔离**：M2 soft enforce — 记录读取文件清单到 input.json，不阻止。M2.5+ 再硬隔离。
2. **proposal ops 支持 delete**：支持。ops 词汇表：`upsert_text`（创建/替换）+ `delete`（幂等删除）。deny_globs 兜底安全。
3. **staging 粒度**：M2 全量复制 `game/`（与 ADR 0003 一致，正确性优先）。后续可优化。
4. **CLI 入口**：`neonrp agent run` 作为唯一入口。`neonrp run` 保持 M0 echo placeholder 不变。
5. **deny_globs 默认范围**：默认包含 `.neonrp/**` 和 `agents/**`，防止 agent 篡改控制目录或其他 agent 定义。
