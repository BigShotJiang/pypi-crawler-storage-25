# Play Mode 运行偏慢诊断（2026-02-23）

## 目标
- 先确认当前链路是否按既定设计运行。
- 再定位“等待时间长”的主因是程序缺陷、架构成本，还是模型侧行为。
- 形成可执行的分层优化方案（短期/中期/系统性）。

## 结论摘要
- 结论 1：当前链路**基本按计划运行**（active-agent sticky 生效、路由正确）。
- 结论 2：当前“慢”主要来自**多轮 LLM 往返 + 子代理探索式工具调用 + 长文本输出**，不是单一死循环 bug。
- 结论 3：存在一个会放大体感延迟的程序侧问题：CLI 默认 DEBUG + 流式 tool delta 逐片段日志，导致日志量爆炸和额外 I/O 压力。

## 证据与观察

### A. 是否按计划运行
- active-agent 锁定后的回合，`run_id` 已直接落在 `town-agent_*`，说明进入 sticky 路由后不是每回合都先跑 narrator 主推理。
- 对应链路代码：
  - narrator 下 active-agent 直路由：`src/neonrp/core/conversation.py:1096`
  - 直路由封装 task 参数：`src/neonrp/core/conversation.py:1113`
  - 子代理 turn 上限读取：`src/neonrp/core/conversation.py:1795`
  - 子代理禁用 ask_user（要求返回选项文本）：`src/neonrp/core/conversation.py:1916`, `src/neonrp/core/conversation.py:1955`

### B. 本地实测耗时（同一项目样本）
- `narrator_20260222_125042_6bffd70b`：16.5s（开场）
- `narrator_20260222_125116_5c601153`：60.5s（含一次 town-agent task）
  - 其中单段空档约 42.2s（task 发出到 task 返回）
- `narrator_20260222_194205_e98fe557`：38.4s（sticky 后已直走 town-agent）

解释：
- sticky 生效后，确实减少了 narrator 层往返，但子代理本身仍有 4-5 turn 与长文本输出，等待仍明显。

### C. 子代理工具行为
- 事件记录显示某些回合有大量探索性工具调用（如连续多次 `find`），会增加回合数与 token/时延。
- 示例：`my-rpg-gpt-5-2-2/.neonrp/events/main.jsonl` 中 `town-agent_20260222_125122_c0480b28` 出现多次 `find`。
- 当前模板 agent 工具集合偏宽（`find/list_entities/glob/grep` 同时开放）：
  - `src/neonrp/templates/default/agents/town-agent/agent.json:6`
  - `src/neonrp/templates/default/agents/dungeon-agent/agent.json:6`

### D. 日志链路对性能的影响
- CLI 启动时将 `neonrp` logger 设为 DEBUG：
  - `src/neonrp/cli.py:40`
- OpenAI 适配器在流式工具参数阶段有高频 debug（逐 delta）：
  - `src/neonrp/core/llm_openai.py:796`
- 这会导致 `neonrp.log` 极长，且在工具参数碎片多时放大 I/O 成本。

## 判定：哪些是程序问题，哪些是模型/配置问题

### 程序问题（可控）
- 默认日志级别过高（DEBUG）+ 高频流式 delta 日志，增加 I/O 并干扰排障信噪比。
- 子代理工具面过宽，导致模型在“不确定路径”时倾向做探测式调用。
- 子代理回合预算偏松（模板 `max_task_turns=10`），给了模型“多轮试探”空间。

### 模型/配置侧（部分可控）
- 模型本身推理/生成速度（特别是长中文叙事）是硬成本。
- reasoning 输出与长文本风格会显著拉长每轮（即使逻辑正确）。
- 不同 provider 对工具调用的稳定性差异会造成额外恢复轮。

## 系统性优化方案（建议）

## 第一层：低风险快速优化（建议先做）
- 1) 调整默认日志策略：
  - 默认 `INFO`；
  - `stream tc_delta` 仅在显式诊断开关下开启（如环境变量）。
- 2) 收紧模板子代理预算：
  - `max_task_turns` 从 10 下调到 4-6；
  - 明确每回合“最多 N 个工具调用”。
- 3) 缩短输出目标：
  - 子代理默认输出改为“短叙事 + 2-3 个选项”，限制段落长度。
- 4) 收窄工具暴露面：
  - town/dungeon 默认移除 `grep`，谨慎保留 `glob/list_entities`；
  - 优先 `read_file + edit_file + resolve_action + find` 的最小闭环。

## 第二层：结构优化（中期）
- 1) 上下文预注入（Context Pack）：
  - narrator 在委派前把必需实体快照直接塞进 task prompt，减少子代理二次 read/find。
- 2) 实体路径注册表（Entity Path Registry）：
  - 运行时提供 `id -> canonical path` 映射，减少路径猜测与 find 探测。
- 3) 回合内预算控制器：
  - 达到工具/时间预算后，强制“停止探测，基于现有信息回答并给选项”。

## 第三层：系统方案（长期）
- 1) 引入 play 性能档位（fast/balanced/rich）：
  - fast：低 reasoning、短输出、低 turn budget；
  - rich：高叙事但允许更长时延。
- 2) 可观测性标准化：
  - 每个 run 写入结构化性能摘要（总时长、LLM等待、工具耗时、turn 数、token）；
  - 支持回放与横向对比，避免体感判断。

## 建议的下一步实施顺序
- 1) 先改日志级别和流式 delta 日志开关（立竿见影，低风险）。
- 2) 调整默认模板：子代理 `max_task_turns`、工具清单、输出长度约束。
- 3) 增加 run 级性能摘要日志（用于持续验证是否“真的变快”）。
- 4) 评估 Context Pack + Entity Path Registry 的实现成本，决定是否纳入 M12 后续卡片。

