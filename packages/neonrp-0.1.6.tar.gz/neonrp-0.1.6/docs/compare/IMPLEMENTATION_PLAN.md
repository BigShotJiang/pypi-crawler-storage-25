# CC → NeonRP 実装計画 — Feature-by-Feature Gap Analysis & Plan

> **目的：** Claude Code (CC) reference にあって NeonRP に無い機能を全て列挙し、実装計画にする
> **方針：** CC のコードを読んで、NeonRP に必要なものだけを NeonRP 流に実装する
> **Created:** 2026-04-09
> **Status:** Active — 各項目は独立に実装可能

---

## 規模比較

| | CC | NeonRP |
|---|---|---|
| 言語 | TypeScript | Python |
| LOC | ~512k | ~26k |
| ファイル数 | 1,884 | ~74 core modules |
| ツール数 | 42+ | 13 |
| Loop | queryLoop() AsyncGenerator | run_agent_agentic() while loop |

---

## カテゴリ一覧

| # | カテゴリ | CC ソース | NeonRP 対応 | Priority |
|---|---------|----------|-------------|----------|
| 1 | Context Compression | utils/messages.ts | ❌ なし | 🔴 P0 |
| 2 | Persistent Sub-Agent | tools/AgentTool/ | ❌ one-shot のみ | 🔴 P0 |
| 3 | Dynamic Turn Management | query.ts | ❌ 固定20 turn | 🔴 P0 |
| 4 | Plan Mode | tools/EnterPlanModeTool/ | ❌ なし | 🟡 P1 |
| 5 | Worktree Isolation | tools/EnterWorktreeTool/ | ❌ なし | 🟡 P1 |
| 6 | Task Management | tools/TaskCreateTool/ etc. | ❌ なし | 🟡 P1 |
| 7 | Interactive Permission | (permission system) | ❌ 静的 only | 🟡 P1 |
| 8 | Web Tools | tools/WebFetchTool/, WebSearchTool/ | ❌ なし | 🟡 P1 |
| 9 | MCP Full Primitives | services/mcp/client.ts | ⚠️ tools only | 🟡 P1 |
| 10 | Notebook Support | tools/NotebookEditTool/ | ❌ なし | 🟢 P2 |
| 11 | Cron/Scheduled Tasks | tools/ScheduleCronTool/ | ❌ なし | 🟢 P2 |
| 12 | LSP Integration | tools/LSPTool/ | ❌ なし | 🟢 P2 |
| 13 | Voice Input | voice/ | ❌ なし | 🟢 P2 |
| 14 | Cost Tracking | cost-tracker.ts | ❌ なし | 🟡 P1 |
| 15 | Hooks System | hooks/ | ❌ なし | 🟡 P1 |
| 16 | Skills/Slash Commands | skills/ | ⚠️ 部分的 | 🟡 P1 |
| 17 | REPL Tool | tools/REPLTool/ | ❌ なし | 🟢 P2 |
| 18 | Vim Mode | vim/ | ❌ なし | 🟢 P2 |
| 19 | Remote Agent | remote/ | ❌ なし | 🟢 P2 |
| 20 | Plugin System | plugins/ | ❌ なし | 🟢 P2 |

---

## P0: 必須実装（開源前 or 直後）

### 1. Context Compression — reactiveCompact 相当

**CC の実装:**
- `utils/messages.ts` に `reactiveCompact()` 
- 会話が context window の一定割合を超えたら semantic summary に圧縮
- 古いメッセージを要約で置き換え、重要なツール結果は保持
- `normalizeMessagesForAPI()` で API 送信前に整形

**NeonRP の現状:**
- `agent_runner.py` の `_estimate_tokens()` で chars//4 概算
- 80% 警告、100% 強制終了
- 圧縮なし → 長い会話が不可能

**実装計画:**

```
ファイル: core/context_compact.py (新規)
─────────────────────────────────
1. compact_messages(messages, max_tokens, strategy="semantic")
   - messages を受け取り、max_tokens 以内に圧縮した messages を返す
   - strategy:
     a. "truncate" — 最古メッセージから削除（現状の延長）
     b. "summarize" — LLM で古い部分を要約に置き換え
     c. "semantic" — 重要度スコアリング + 選択的圧縮

2. _score_message_importance(msg) → float
   - tool_result は高スコア（状態情報）
   - submit_proposal は最高スコア
   - 直近 N turn は高スコア
   - user メッセージは中スコア

3. _summarize_messages(messages) → Message
   - LLM に "以下の会話を要約して" で圧縮
   - 元のメッセージ数 + 要約後 token 数をログ

変更: agent_runner.py
─────────────────────
- BUDGET_WARNING_THRESHOLD で圧縮を試行
- 圧縮成功 → 続行、失敗 → 従来通り終了

テスト: tests/test_context_compact.py
─────────────────────────────────────
- 100 メッセージ → 圧縮後 token 数が target 以下
- 重要メッセージ（proposal系）が保持される
- summarize strategy で内容が保持される
```

**工数見積:** 2-3 日
**依存:** なし
**参考 CC コード:** `utils/messages.ts:reactiveCompact`

---

### 2. Persistent Sub-Agent — one-shot → long-lived

**CC の実装:**
- `tools/AgentTool/` — InProcessTeammateTaskState
- Sub-agent は独立した会話 context を持ち、複数 turn 跨いで生存
- `SendMessageTool` でメッセージ送受信
- File-based Mailbox で agent 間通信

**NeonRP の現状:**
- `task()` tool → `run_agent_agentic()` 再帰呼び出し
- One-shot: sub-agent は proposal 提出後に死亡
- `SubAgentState` dataclass はあるが、実際には resume されない
- max_depth=2 で深さ制限

**実装計画:**

```
ファイル: core/agent_pool.py (新規)
─────────────────────────────────
1. AgentPool
   - active_agents: dict[str, AgentInstance]
   - spawn(agent_id, prompt) → run_id
   - send_message(run_id, message) → response
   - kill(run_id)
   - list_active() → list[AgentInstance]

2. AgentInstance
   - run_id, agent_id, messages, state
   - is_alive: bool
   - last_active: datetime
   - inbox: list[Message]  # mailbox

3. resume(run_id, new_prompt) → AgentRunResult
   - 既存の messages に追加して再開
   - SubAgentState を利用

ファイル: core/mailbox.py (新規)
──────────────────────────────
1. Mailbox (file-based)
   - send(from_agent, to_agent, content)
   - receive(agent_id) → list[Message]
   - .neonrp/mailbox/{agent_id}.jsonl

変更: agent_runner.py
─────────────────────
- task() の処理を AgentPool 経由に変更
- delegation_mode: "one-shot" | "sticky" | "persistent"
  - one-shot: 現状維持
  - sticky: active_agent として保持
  - persistent: pool に入り、mailbox で通信

変更: skills.py
───────────────
- send_message tool 追加
  - send_message(target_agent, message) → response

テスト:
- sub-agent spawn → message → resume → message → kill
- mailbox read/write
- depth limit 遵守
```

**工数見積:** 3-5 日
**依存:** なし
**参考 CC コード:** `tools/AgentTool/`, `tools/SendMessageTool/`

---

### 3. Dynamic Turn Management — 固定 20 → adaptive

**CC の実装:**
- `query.ts::queryLoop()` は AsyncGenerator、明示的な turn limit なし
- Token budget で暗黙的に制御
- Context compact で延命

**NeonRP の現状:**
- `MAX_AGENTIC_TURNS = 20` 固定
- 20 turn 超えたら強制終了
- 単純だが柔軟性がない

**実装計画:**

```
変更: agent_runner.py
─────────────────────
1. MAX_AGENTIC_TURNS を config 化
   - config.yaml: max_agentic_turns: 50 (default)
   - agent.json: max_turns override（per-agent）

2. Adaptive turn management:
   - context compact 成功 → turn カウンタを延長可能
   - proposal 提出進捗による動的調整:
     a. 情報収集中（read 系ツール）→ 寛容
     b. proposal 提出失敗 → 残り turn 警告強化
     c. idle（何もしない turn が 3 連続）→ 強制終了

3. Budget-aware turn limit:
   - token_budget_remaining / avg_tokens_per_turn = remaining_turns_estimate
   - 残り turn が 3 以下 → 強制 "submit now" 指示

テスト:
- 30 turn 対話が完走する
- idle detection で早期終了する
- budget 警告後に compact → 延命
```

**工数見積:** 1-2 日
**依存:** P0-1 (Context Compression)
**参考 CC コード:** `query.ts:queryLoop`

---

## P1: 重要機能（開源後 Phase 1）

### 4. Plan Mode — 計画の提示と承認

**CC の実装:**
- `tools/EnterPlanModeTool/` — agent がプランを提示
- ユーザーが承認/修正してから実行
- state: "plan" | "execute"

**NeonRP への適用:**
- 世界変更の前にプランを表示（"これからこう変えます"）
- ユーザーが OK/NG/修正を選択
- 現在の ask_user を拡張して plan 表示に利用

```
ファイル: core/plan_mode.py (新規)
─────────────────────────────────
1. PlanProposal
   - steps: list[PlanStep]
   - estimated_ops: list[ProposalOp]
   - user_approval: bool

2. enter_plan_mode() → PlanProposal
3. execute_plan(plan) → AgentRunResult

変更: skills.py — plan_proposal tool 追加
```

**工数見積:** 2-3 日

---

### 5. Worktree Isolation — ブランチ隔離実行

**CC の実装:**
- `tools/EnterWorktreeTool/` — git worktree で隔離された環境
- agent が自由に変更 → 問題なければ merge

**NeonRP への適用:**
- NeonRP には既に branch 機能がある
- branch 上で proposal を試行 → preview → merge

```
変更: agent_runner.py + core/checkpoint.py
──────────────────────────────────────────
1. run_in_sandbox(agent_id, query):
   - 自動で temp branch 作成
   - agent run → proposal apply on temp branch
   - diff preview → user approval → merge to main branch
   - 失敗時は branch 削除
```

**工数見積:** 1-2 日（既存 branch 機能を活用）

---

### 6. Task Management — タスク分解と追跡

**CC の実装:**
- `TaskCreateTool`, `TaskUpdateTool`, `TaskListTool`, `TaskGetTool`, `TaskOutputTool`, `TaskStopTool`
- Agent が自分のタスクを管理
- 進捗 spinner 表示

**NeonRP への適用:**
- Agent が複雑なクエストを step に分解
- 各 step の完了状態を追跡
- TUI に進捗表示

```
ファイル: core/todo.py (既存を拡張)
────────────────────────────────────
- 現在の todo.py を task management に拡張
- create_task(subject, description) → task_id
- update_task(task_id, status)
- list_tasks() → list[Task]

新規 skills: create_task, update_task, list_tasks
```

**工数見積:** 2-3 日

---

### 7. Interactive Permission — 動的権限管理

**CC の実装:**
- per-tool permission mode: bypass, plan, auto, default
- ユーザーが実行時に承認/拒否
- CLAUDE.md で事前設定

**NeonRP への適用:**
- 現在は agent.json で静的に設定
- ask_user を利用して "この操作を許可しますか？" を実装

```
変更: core/permissions.py
─────────────────────────
1. PermissionPolicy:
   - auto_approve: list[str]  # 自動許可パターン
   - require_approval: list[str]  # 要承認パターン
   - deny: list[str]  # 拒否パターン

2. check_permission_interactive(path, op, callback) → bool
   - require_approval にマッチ → callback で ask_user
   - ユーザー回答で許可/拒否

変更: agent_runner.py
─────────────────────
- _execute_tool() で write 系操作前に permission check
```

**工数見積:** 2-3 日

---

### 8. Web Tools — WebFetch + WebSearch

**CC の実装:**
- `tools/WebFetchTool/` — URL のコンテンツ取得
- `tools/WebSearchTool/` — Web 検索

**NeonRP への適用:**
- Agent が外部情報を取得してゲーム世界に反映
- 例: "実際の東京の天気を世界に反映して"

```
ファイル: skills/ (外部 skill plugin)
───────────────────────────────────
1. web_fetch(url, max_chars) → content
2. web_search(query, max_results) → list[result]

- httpx で実装
- permissions.yaml で URL whitelist
```

**工数見積:** 1-2 日

---

### 9. MCP Full Primitives — resources + prompts

**CC の実装:**
- `services/mcp/client.ts` — tools, resources, prompts 全サポート
- `tools/ListMcpResourcesTool/`, `tools/ReadMcpResourceTool/`

**NeonRP の現状:**
- `mcp_client.py` + `mcp_pool.py` — tools のみ
- resources, prompts 未実装

```
変更: core/mcp_client.py
────────────────────────
1. list_resources(server) → list[Resource]
2. read_resource(server, uri) → content
3. list_prompts(server) → list[Prompt]
4. get_prompt(server, name, args) → messages

新規 skills: list_mcp_resources, read_mcp_resource
```

**工数見積:** 2-3 日

---

### 14. Cost Tracking — トークン消費追跡

**CC の実装:**
- `cost-tracker.ts` — per-session, per-model のコスト計算
- `costHook.ts` — 実行後のコスト表示

**NeonRP への適用:**
- RP セッションのコストが重要（長時間プレイ）
- per-turn, per-session のコスト計算

```
ファイル: core/cost_tracker.py (新規)
─────────────────────────────────────
1. CostTracker
   - add_usage(model, input_tokens, output_tokens)
   - get_session_cost() → float
   - get_turn_cost(turn) → float
   - pricing: dict[model, PricingInfo]

変更: agent_runner.py — chat/chat_stream 後に add_usage
変更: tui/app.py — session cost 表示
```

**工数見積:** 1 日

---

### 15. Hooks System — イベントフック

**CC の実装:**
- `hooks/` — tool 呼び出し前後にカスタムコマンド実行
- ユーザーが .claude/hooks.json で設定

**NeonRP への適用:**
- proposal apply 前後のフック
- session 開始/終了のフック
- カスタム検証ロジック

```
ファイル: core/hooks.py (新規)
──────────────────────────────
1. HookRegistry
   - register(event, callback)
   - fire(event, context)
   
2. 対応イベント:
   - pre_proposal_apply
   - post_proposal_apply
   - session_start
   - session_end
   - tool_call (before/after)

設定: .neonrp/hooks.yaml
```

**工数見積:** 1-2 日

---

### 16. Skills/Slash Commands — 拡張コマンド

**CC の実装:**
- `skills/` — /commit, /review-pr 等のスラッシュコマンド
- Skill 定義ファイル + プロンプト展開

**NeonRP の現状:**
- `skill_loader.py` — 外部 skill ファイル読み込み
- skills/ ディレクトリにカスタム skill

```
変更: core/skill_loader.py
──────────────────────────
1. Slash command 対応:
   - /save — 即座にセーブ
   - /branch — ブランチ作成
   - /undo — 最後の proposal を取り消し
   - /status — 現在の世界状態サマリ
   - /replay — セッションリプレイ

2. カスタム skill 定義:
   - skills/*.yaml で定義
   - prompt template + tool chain
```

**工数見積:** 2-3 日

---

## P2: 将来機能（Q2-Q3）

### 10. Notebook Support
- Jupyter notebook 内から NeonRP を操作
- 研究用途（実験データ収集）

### 11. Cron/Scheduled Tasks  
- "毎日朝8時に世界を自動進行" 的な機能
- 無人運行モードの基盤

### 12. LSP Integration
- IDE から NeonRP の世界データを補完/検証

### 13. Voice Input
- 音声で RP する（TUI voice mode）

### 17. REPL Tool
- Python REPL で世界データを直接操作（開発者向け）

### 18. Vim Mode
- TUI に vim キーバインディング

### 19. Remote Agent
- リモート実行（クラウドで agent を走らせる）

### 20. Plugin System
- サードパーティ skill/tool のインストール機構

---

## 実装順序（推奨）

```
Phase 0 — 開源前 (4/9-4/17)
├── P0-1: Context Compression (2-3日) ← 最優先
├── P0-3: Dynamic Turn Management (1-2日) ← P0-1 依存
└── P1-14: Cost Tracking (1日) ← 簡単で開源時に見栄え

Phase 1 — 開源後 Week 1-2
├── P0-2: Persistent Sub-Agent (3-5日)
├── P1-4: Plan Mode (2-3日)
└── P1-7: Interactive Permission (2-3日)

Phase 2 — 開源後 Week 3-4
├── P1-5: Worktree Isolation (1-2日)
├── P1-6: Task Management (2-3日)
├── P1-8: Web Tools (1-2日)
└── P1-9: MCP Full Primitives (2-3日)

Phase 3 — Q2
├── P1-15: Hooks System (1-2日)
├── P1-16: Skills/Slash Commands (2-3日)
└── P2 items as needed
```

**合計工数:**
- Phase 0: ~5 日（4/9-4/13 で完了可能）
- Phase 1: ~10 日
- Phase 2: ~10 日
- Phase 3: ~5 日 + P2

---

## CC コード読む順序（この計画を実装する場合）

```
必読:
1. utils/messages.ts — reactiveCompact の実装 (P0-1)
2. query.ts — queryLoop の turn 管理 (P0-3)
3. tools/AgentTool/ — sub-agent spawn (P0-2)
4. cost-tracker.ts — コスト計算 (P1-14)

参考読み:
5. tools/EnterPlanModeTool/ — plan mode (P1-4)
6. tools/EnterWorktreeTool/ — worktree (P1-5)
7. tools/TaskCreateTool/ — task management (P1-6)
8. services/mcp/client.ts — MCP full (P1-9)
9. hooks/ — hooks system (P1-15)
10. skills/ — slash commands (P1-16)
```

---

> **この文書は実装の進行に合わせて更新する。**
> 各項目の「実装計画」セクションがそのまま実装のガイドになる。
