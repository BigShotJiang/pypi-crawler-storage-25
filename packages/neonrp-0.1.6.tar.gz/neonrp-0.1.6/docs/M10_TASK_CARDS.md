# M10 Task Cards — M9 Review 修复 + TUI 改进

---

## M10-T0: Specs + Design Doc (doc-first)

**Goal**: 根据 `reviews/M9_gap_assessment.md` 和 `reviews/M9_review_20260207.md` 确定修复范围。

**背景**：M9 完成了核心对话循环，评分 87/100。差距评估识别出以下问题：

| 优先级 | 问题 | 来源 | 严重度 |
|--------|------|------|--------|
| P0 | ask_user 在 TUI 返回空字符串 | gap_assessment | 高 |
| P1 | 无 markdown 渲染 | gap_assessment + review #5 | 中 |
| P1 | 无 /stats /compact 命令 | gap_assessment | 中 |
| Bug | SkillLoader.get_description(name) 缺失 | `/skills` 命令路径调用但方法不存在 | 中 |
| Review #2 | SkillLoader reload 每次重新解析 | M9_review | 低 |
| Review #3 | TodoManager 验证错误信息缺少实际值 | M9_review | 已在 M9 修复 |
| Review #1 | Todo status mismatch (done vs completed) | M9_review | 已在 M9 修复 |

**设计决策**：
1. ask_user: 使用 Textual `ModalScreen` + `threading.Event` 阻塞 worker 线程等待用户响应
2. markdown 渲染: ConversationView 从 `RichLog` 重构为 `VerticalScroll` 容器 + `Markdown`/`Syntax` 分段渲染（文本与代码块分层）
3. /stats: 在 `ConversationSession` 追踪 `total_turns` / `total_usage`
4. /compact: 保留 system prompt + 最近 N 条消息 + 压缩标记
5. SkillLoader mtime 缓存: 记录文件 mtime，跳过未变更文件

**Deliverables**:
- `docs/M10_TASK_CARDS.md` — 本文档
- M10 section in `docs/ROADMAP.md`

**Acceptance**: 任务卡创建。ROADMAP 更新。

---

## M10-T1: ask_user 模态对话 (`AskUserScreen`)

**Goal**: 代理通过 ask_user 工具向玩家提问时，TUI 弹出模态窗口收集回答。

**问题**：M9 的 `on_ask_user` 回调直接返回空字符串，代理问题得不到回答。

**实现**：
- `AskUserScreen(ModalScreen[str])`: 显示问题文本 + 选项按钮列表 + 自由输入框
- 选项点击: `on_button_pressed` → `dismiss(option_text)`
- 自由输入: `on_input_submitted` → `dismiss(text)`
- Escape 取消: `dismiss("")`
- Worker 线程阻塞: `threading.Event.wait(timeout=300)` 等待用户响应
- `call_from_thread(_show_modal)` 在主线程推入 ModalScreen

**Changes**:
- `tui/app_v2.py`: 新增 `AskUserScreen` 类 (~70 行)；重写 `on_ask_user` 回调 (~15 行)
- 新增导入: `threading`, `Button`, `Vertical`

**Tests**: 无新增（需手动交互测试；现有 mock 测试覆盖回调路径）

**Files**: `tui/app_v2.py`

---

## M10-T2: ConversationView 重构 + Markdown 渲染

**Goal**: 对话面板从 RichLog 迁移到分段渲染视图，启用 markdown 与代码块高亮。

**问题**：M9 的 ConversationView 基于 RichLog，叙事输出为纯文本，RPG 场景可读性差。

**实现**：
- `ConversationView(VerticalScroll)`: 替代 `RichLog`，使用结构化消息块渲染
- `write()/write_markdown()`: 将 rich markup 归一为纯文本并保留 markdown 渲染
- 文本段落使用 `Markdown`，代码围栏使用 `Syntax`（按语言高亮）
- `clear()`: 移除子组件并清空 plain transcript 缓冲
- `get_plain_text()`: 从内部 plain buffer 导出完整可复制文本
- `add_markdown_message()`: 完整 assistant 消息按 “header + body segments” 渲染
- `action_copy_selection()`: `y` 键复制 transcript
- Session restore 和 non-streaming fallback 使用 `add_markdown_message()`

**Changes**:
- `tui/app_v2.py`: ConversationView 基类更换为 `VerticalScroll` + markdown/code 分段渲染
- 移除 `RichLog` 依赖，统一 transcript 复制与渲染路径

**Tests**: 更新 `test_app_v2.py` 中受影响的测试 (~20 行改动)
- `test_handle_result_renders_assistant_message_without_stream`: 断言从 `add_assistant_chunk` 改为 `add_markdown_message`

**Files**: `tui/app_v2.py`, `tests/test_app_v2.py`

---

## M10-T3: /stats + /compact 命令

**Goal**: 用户可查看对话统计和手动压缩历史。

**问题**：M9 无 turn count / token usage 可见性，长对话无手动压缩手段。

### /stats 实现
- `ConversationSession`: 新增 `total_turns: int` 和 `total_usage: dict`，在 `send()` 中累加
- `_cmd_stats()`: 显示 mode、agent、消息计数（user/assistant/tool）、LLM turns、token usage、files modified

### /compact 实现
- `ConversationSession.compact(keep_recent=10)`:
  - 保留 system prompt（index 0）
  - 保留最近 10 条消息
  - 中间插入压缩标记: `[Previous conversation compacted]` + `Understood.`
  - 返回移除的消息数
- `_cmd_compact()`: 调用 `session.compact()`，显示压缩结果
- **持久化契约**: compact 仅影响运行时内存中的消息列表，不主动持久化压缩后的历史。下次 `send()` 时新消息会正常追加到 session JSONL；重启后 `resume()` 加载完整未压缩历史。compact 设计为**会话运行时瞬态优化**，不改变持久化存储。

### 命令注册
- `tui/commands.py`: COMMANDS dict 新增 `stats`、`compact`、`mode`、`clear`、`files`、`skills`
- `tui/app_v2.py`: slash command 分发新增 `stats` 和 `compact` 分支
- `/help` 输出更新

**Changes**:
- `core/conversation.py`: `total_turns`/`total_usage` 字段 + `compact()` 方法 (~25 行)
- `tui/app_v2.py`: `_cmd_stats()` + `_cmd_compact()` (~40 行)
- `tui/commands.py`: 6 个新命令注册 (~6 行)

**Tests**: 无新增（已有命令分发测试覆盖路径）

**Files**: `core/conversation.py`, `tui/app_v2.py`, `tui/commands.py`

---

## M10-T4: SkillLoader 修复

**Goal**: 修复 TUI 中 `/skills` 命令崩溃，优化重复加载性能。

### Bug: get_description(name) 缺失
- `/skills` 命令调用 `self.skill_loader.get_description(name)` 但方法不存在
- 新增 `SkillLoader.get_description(name) -> str | None`: 返回单个 skill 的 description

### Review #2: mtime 缓存
- `SkillLoader.__init__`: 新增 `self._mtimes: dict[Path, float]`
- `reload()`: 检查 `path.stat().st_mtime`，跳过未变更文件
- 删除已移除 skill 文件对应的缓存条目

**Changes**:
- `core/skill_loader.py`: `get_description()` 方法 (~4 行) + mtime 缓存逻辑 (~20 行)

**Tests**: 无新增（已有 SkillLoader 测试覆盖 reload/list_skills/get_content 路径）

**Files**: `core/skill_loader.py`

---

## M10-T5: Review Gate

**Process**:
1. `ruff format` + `ruff check` — all clean
2. `pytest` — all 744+ tests pass
3. 文档更新: `docs/ROADMAP.md` M10 section
4. 差距评估更新

**Acceptance**: 所有 lint/test 通过。文档更新完成。

---

## M10-T6: TUI 体验打磨（后续增量）

**Goal**: 在 M10-T5 之后继续优化对话体验与可观测性，降低“能用但不顺手”的摩擦。

**实现**：
- 发送链路稳定性修复：修复 `run_worker(..., text=...)` 参数不兼容导致的崩溃，改为兼容调用方式
- 运行状态可见性：输入区新增等待/流式状态提示，响应阶段可见 Thinking 文本
- 工具调用展示增强：工具调用条目支持“单行摘要 + 可展开详情”，并在流式阶段保持顺序稳定
- transcript 渲染优化：用户输入 / Thinking / 工具调用 / Narrator 输出分层渲染，代码块高亮保留
- 输入交互增强：`/` 命令候选和上下方向键历史回放可用
- 配置体验优化：支持用户级配置落盘（`~/.neonrp/config.json`），并在缺失 endpoint/API key 时给出引导

**Changes**:
- `src/neonrp/tui/app_v2.py`: 工具状态卡片、Thinking 渲染、输入历史、状态提示、发送路径修复
- `src/neonrp/core/conversation.py`: 对话结果与统计字段配合展示
- `src/neonrp/core/llm_openai.py`: provider 输出兼容性与体验相关适配
- `tests/test_app_v2.py`, `tests/test_tui_commands.py`: 回归测试更新

**Evidence**:
- `uv run pytest tests/test_app_v2.py tests/test_tui_commands.py -q` → 113 passed
- `uv run pytest -q` → 752 passed, 5 skipped

---

## M10-T7: 斜杠命令交互对齐 Claude Code

**Goal**: 统一斜杠命令补全/提交行为，减少两步操作和误触发。

**实现**：
- Enter：选中建议后直接执行（不再 fill 后再二次回车）
- Tab：补全后自动追加空格；无子命令时隐藏 popup，有子命令时显示子命令建议
- 子命令参数提示：新增 `SlashCommandSuggester` ghost text（例如 `/auth set <provider> ...`）
- 命令参数 hint：`COMMANDS` 增加 `sub_args_hint` 字段
- 异步时序修复：`_suppress_input_change` 由 `on_input_changed` 消费重置，修复 popup 闪回/race condition

**Changes**:
- `src/neonrp/tui/app_v2.py`: 新增 `SlashCommandSuggester` 与交互规则更新
- `src/neonrp/tui/commands.py`: `COMMANDS` 新增 `sub_args_hint`
- `tests/test_app_v2.py`: Tab/Enter/历史相关断言同步

**Evidence**:
- `uv run pytest tests/ -x -q -k "slash or tui"` → 51 passed
- `uv run pytest -q` → 752 passed, 5 skipped

---

## File Summary

| File | Action | Est. Lines |
|------|--------|-----------|
| `src/neonrp/tui/app_v2.py` | MODIFY | ~300+ 行改动 |
| `src/neonrp/core/conversation.py` | MODIFY | ~26 行新增 |
| `src/neonrp/core/llm_openai.py` | MODIFY | 少量兼容性改动 |
| `src/neonrp/core/skill_loader.py` | MODIFY | ~30 行改动 |
| `src/neonrp/tui/commands.py` | MODIFY | 新增 `sub_args_hint` |
| `tests/test_app_v2.py` | MODIFY | ~100+ 行改动 |
| `tests/test_tui_commands.py` | MODIFY | 命令解析/建议断言更新 |

## Dependency Order

```
M10-T0 (doc-first)
  ├── M10-T1 (ask_user modal)   ← 独立
  ├── M10-T2 (ConversationView markdown/code 分段渲染) ← 独立
  ├── M10-T3 (/stats + /compact) ← 独立
  └── M10-T4 (SkillLoader fixes)  ← 独立
M10-T5 (review gate) ← requires T1-T4
  └── M10-T6 (TUI polish)
       └── M10-T7 (slash UX alignment)
```

T1-T4 为首轮并行修复；T6/T7 为 T5 后的增量体验打磨。

## Acceptance Criteria

1. ask_user: 代理提问 → TUI 弹出模态窗口 → 用户回答 → 回答注入对话
2. Markdown: 对话面板支持 markdown + 代码块高亮，消息分段渲染稳定
3. /stats: 显示 mode/agent/消息数/LLM turns/token usage/文件数
4. /compact: 压缩长对话，保留最近 10 条 + 压缩标记
5. /skills: 不再崩溃，正确显示 skill 描述
6. 输入 `hello` 不再触发 `run_worker` 参数错误崩溃
7. 流式阶段可见等待状态与 Thinking；工具调用顺序稳定
8. 斜杠命令：Enter 选中即执行、Tab 补全带空格并按规则隐藏/展开 popup
9. ghost text 可显示命令/子命令参数提示
10. Regression: 所有现有测试通过（752 passed, 5 skipped）

## 评分影响

| 维度 | M9 评分 | M10 预期 | 说明 |
|------|--------|---------|------|
| 对话循环 | 18/20 | **20/20** | ask_user 补全 |
| TUI 体验 | 13/15 | **15/15** | markdown + /stats + /compact + T6/T7 交互打磨 |
| **总分** | **87/100** | **92/100** | P0 + P1 全修 |
