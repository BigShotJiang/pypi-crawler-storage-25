# M14 Task Cards — Role Play Benchmark

> **Scope:** 在 `M13` 完成必要 runtime / loop 能力移植后，建立 NeonRP 的 Role Play benchmark。
> **Method reference:** 参考 `ClawProBench` 的实现路径——**live-first harness + 场景目录化 + benchmark profiles + deterministic grading + structured reports + resume/compare 工作流**——但把评测对象从 coding/runtime agent 改为 role play agent。
> **Target:** 用一套可复现、可比较、可回归的 benchmark，定义并测量“好的 RP agent”到底是什么。
> **非目标:** 不做 WorldLines 桌面体验层（归 `L14`），不直接扩写复杂游戏内容（归 `M15`）。

---

## 为什么是 M14

M13 解决的是：**NeonRP 是否具备支撑复杂 RP 的必要 runtime 能力**。

M14 解决的是：**这些能力是否真的带来了更强的 role play 体验**。

也就是说：

- `M13` = 能力建设
- `M14` = 能力验证与基准化
- `M15` = 用验证结果反推更复杂的游戏内容建设

---

## 设计原则（参考 ClawProBench，适配 RP）

### 1. Live-first，不只看离线文本

Benchmark 必须优先跑在 **真实 NeonRP runtime** 中，而不是只对最终输出文本打分。

需要观测：
- 生成文本
- tool / rule / dice 调用链
- agent routing / delegation
- memory / relationship / location / combat / status 状态变化
- session resume / continue 一致性

### 2. Catalog-first，场景是 benchmark 的源事实

像 ClawProBench 一样，把每个 benchmark case 作为一个独立 scenario 文件管理，而不是散落在临时脚本里。

### 3. Deterministic grading 优先

优先使用**可验证状态、事件、规则结果**评分；文本质量评分只作为补充层。

### 4. Profiles 先于 leaderboard

先定义 benchmark profile（`core` / `coverage` / `full` 等），再谈对外比较。

### 5. Reports 必须结构化

每次 benchmark run 产出可比较的结构化结果：
- 总分
- 分维度得分
- 每个场景的 trial 结果
- latency / token / cost
- execution failures / resume metadata

---

## RP Benchmark 的能力维度

参考你的 RP `aha moment`，M14 先把 RP 评测拆成 7 个维度：

1. **Memory**
   - 延迟兑现
   - 跨场景记忆召回
   - NPC 主动提醒

2. **Relationship**
   - 好感/信任/熟悉度变化
   - 情感回应
   - 关系驱动的信息解锁

3. **Social Agency**
   - NPC 与玩家共同制定目标
   - 角色间信息传播
   - 商业/协作/八卦/社会互动

4. **Combat & Tactics**
   - 群体战斗
   - 地形约束
   - 先攻、包围、谷道、防守面

5. **World Simulation**
   - 地图 / 场景 / 状态 / 路径 / 时间
   - 冒险后果
   - 进入危险区域的惩罚链条

6. **Rule-Mediated Narrative**
   - 骰子与数值结算
   - 失败通过规则呈现，而不是“系统硬拒绝”
   - bleed / death / damage / save 等状态后果

7. **Personality Integrity & Autonomy**
   - NPC 有稳定人格，不因玩家靠近就无条件迎合
   - 亲近/厌恶会改变距离感、合作意愿与表达方式
   - 价值判断符合自身经历、立场与人格特质

---

## Core Scenarios（第一版 benchmark 核心）

以下 10 个场景直接来自你的 `aha moment`，是 M14 第一版 `core` profile 的候选集。

### RP-01: Tavern Promise Recall

**Goal:** 老冒险者在深谈后记住晚上的喝酒邀约，并在正确时间地点主动提醒玩家赴约。

**Measures:**
- 长期记忆写入
- 延迟触发
- 主动召回
- 时间/地点一致性

---

### RP-02: Trust Unlock Gossip

**Goal:** 工会主理人感受到玩家的关心后，主动说出工会内部八卦。

**Measures:**
- 关系变化
- 情感反馈
- 社会信息解锁

---

### RP-03: Familiarity Growth at Inn

**Goal:** 旅馆老板娘在多次见面、离开、回来后逐渐变熟，并在关键任务前表达真实关心。

**Measures:**
- 熟悉度连续演化
- NPC persona 一致性
- 情境相关关怀

---

### RP-04: Impossible Crowd Combat

**Goal:** 玩家在街上阻止犯罪者时，触发与全镇冒险者的大规模不对称战斗，并给出可信失败过程。

**Measures:**
- 群体战斗编排
- 多 NPC 协同行为
- 不可能战斗的后果合理性

---

### RP-05: Blacksmith Venture Proposal

**Goal:** 玩家说服铁匠共同开发新防具并创业。

**Measures:**
- NPC 协作能力
- 长期目标生成
- 非战斗社会互动深度

---

### RP-06: Reckless Boss Lair Death

**Goal:** 玩家贸然进入敌巢，在地图提示不足以阻止其行动时仍触发合理的流血、掉血、死亡链条。

**Measures:**
- 风险表达
- 状态机后果
- 地图/地点与伤害逻辑一致性

---

### RP-07: Wolf Ambush First Strike

**Goal:** 玩家用合理理由争取对狼群先攻，经数值与骰子裁定后，在最后一击中艰难取胜。

**Measures:**
- 战术论证裁定
- 骰子与数值计算
- 高张力胜负结算

---

### RP-08: Valley Chokepoint Defense

**Goal:** 玩家在谷道中为 NPC 挡住敌人，系统正确理解狭窄地形只能守住一个方向的战术含义。

**Measures:**
- 空间拓扑理解
- 站位与迎敌面限制
- 战场地理约束

---

### RP-09: Credit Request via Dice Failure

**Goal:** 当玩家过分要求赊账时，系统不是机械拒绝，而是通过骰子/社交检定在世界内给出失败结论。

**Measures:**
- 规则化失败
- 拒绝的叙事化表达
- 社交检定与后果解释

---

### RP-10: Independent Personality with `Soul.md`

**Goal:** NPC 拥有由 `Soul.md` 驱动的独立人格与内在逻辑，不会因为玩家接近就自动迎合；当与玩家或其他 NPC 更亲近时会自然靠近，更厌恶时会主动疏远，并且其判断始终符合自身经历、价值观与人格特质。

**Measures:**
- 人格一致性
- 独立价值判断
- 关系变化驱动的距离调节
- 对玩家与其他 NPC 的差异化态度
- 长时段人格稳定性

---

## Scenario Schema（借鉴 ClawProBench 的 catalog 方式）

建议 M14 benchmark 场景使用独立 YAML/JSON scenario 文件管理，例如：

```yaml
id: rp_01_tavern_promise_recall
name: Tavern Promise Recall
execution_mode: live
dimension: memory
difficulty: hard
benchmark_group: intelligence
benchmark_status: active
benchmark_core: true
signal_source: neonrp_native
weight: 1.0
timeout_seconds: 300
optimal_steps: 12
world_template: my-rpg
fixtures:
  seed_world: fixtures/rp_bench/rp_01/
prompt_script:
  - "和老陈大叔深入谈心，并约他今晚喝酒"
  - "去完成几件别的事"
  - "夜晚返回工会附近的街道"
expected_state_probes:
  memory:
    - npc: lao-chen
      contains: "今晚喝酒邀约"
  events:
    - type: reminder
      actor: lao-chen
checks:
  - check_id: memory_written
    check_type: state_contains
    points: 0.3
  - check_id: delayed_recall
    check_type: event_emitted
    points: 0.4
  - check_id: text_natural
    check_type: rubric_text
    points: 0.3
```

### 推荐元数据字段

- `dimension`: `memory | relationship | social | combat | world | rules | personality`
- `difficulty`: `easy | medium | hard | expert`
- `benchmark_group`: `intelligence | coverage`
- `benchmark_status`: `active | incubating`
- `benchmark_core`: `true | false`
- `signal_source`: `neonrp_native | mixed | replay`

### 推荐执行字段

- `execution_mode`
- `timeout_seconds`
- `optimal_steps`
- `world_template`
- `fixtures`
- `prompt_script`
- `setup_script` / `teardown_script`
- `checks`
- `pass_threshold`

---

## Benchmark Profiles（参考 ClawProBench 的 profile 设计）

### `core`

第一版 headline benchmark，只包含最能体现 RP `aha moment` 的高信号场景。

建议初始包含：
- RP-01
- RP-02
- RP-03
- RP-10
- RP-06
- RP-07
- RP-09

### `intelligence`

扩展型主动能力 benchmark，覆盖记忆、关系、社会互动、规则裁定和地形战术。

### `coverage`

低风险广覆盖回归集，用于日常 regression，不用于对外 headline 排名。

### `native`

仅包含显著依赖 NeonRP 原生能力的场景：
- memory
- relationship state
- dice / combat
- session resume
- agent routing

### `full`

全部 active benchmark 场景。

---

## 评分方法（ClawProBench 风格，RP 化）

### A. Deterministic checks 优先

优先看以下可验证事实：
- memory 是否被写入
- 关系值是否变化
- 正确 agent 是否执行
- location / status / HP / bleeding 是否正确变化
- dice / combat / skill check 是否被正确触发
- session resume 后状态是否一致

### B. Text rubric 次级

对于必须由文本体验体现的部分，再加人工或 rubric 评分：
- 角色口吻是否一致
- 关怀/八卦/提醒是否自然
- 失败是否是世界内失败，而不是系统口头拒绝

### C. 每个 scenario 的建议分项

- `world_state_correctness`
- `mechanical_correctness`
- `agent_ownership`
- `narrative_naturalness`
- `aha_payoff`

### D. 结果汇总

每次 run 至少输出：
- `avg_score`
- `max_score`
- `pass_rate`
- `dimension_breakdown`
- `scenario_breakdown`
- `latency`
- `token_usage`
- `cost`
- `resume_metadata`
- `execution_failures`

---

## 实现步骤（参考 ClawProBench 的执行流程）

### M14-T0: Scope Lock + Benchmark Taxonomy

**Goal:** 冻结 benchmark 目标、维度、profile、评分哲学。

**Deliverables:**
- `docs/M14_TASK_CARDS.md`（本文档）
- `docs/ROADMAP.md` 同步 M14
- benchmark taxonomy 表：scenario → aha moment → dimension → score axes

**Acceptance:**
- 10 个 `aha moment` 均有明确 scenario 映射
- `core` / `coverage` / `full` / `native` 的边界明确

---

### M14-T1: Scenario Catalog + Schema

**Goal:** 建立像 ClawProBench 那样的 benchmark catalog。

**Changes:**
- 新增 benchmark 目录（建议 `benchmarks/rp/` 或 `tests/benchmarks/rp/`）
- 定义 scenario schema
- 支持 inventory / filtering / metadata validation

**Acceptance:**
- `inventory` 能统计 scenario 数量、维度、profile 归属、active/incubating 数量
- schema 校验可阻止不完整场景进入 active 集合

---

### M14-T2: State Probes + Deterministic Graders

**Goal:** 建立 RP benchmark 的“可判定性基础设施”。

**Changes:**
- 为 memory / relationship / combat / location / status 提供 probe 接口
- 新增 deterministic check types
- 支持 per-scenario custom checks

**Acceptance:**
- 关键 RP 场景不再只靠人工读文本判断成败
- 至少 70% 的 `core` 分数来自 deterministic grading

---

### M14-T3: Benchmark Runner

**Goal:** 建立与 ClawProBench 类似的执行工作流。

**Recommended commands:**
- `neonrp bench inventory`
- `neonrp bench dry`
- `neonrp bench run --profile core --trials 1`
- `neonrp bench run --profile core --trials 3 --continue`
- `neonrp bench compare --results-dir results/benchmarks`

**Features:**
- multi-trial run
- checkpoint resume
- rerun execution failures
- per-scenario trace 保存

**Acceptance:**
- benchmark 可以中断后继续
- 单场景 smoke 与整套 profile run 都可执行

---

### M14-T4: Core Profile Build-out

**Goal:** 先把最高信号的 RP benchmark 做起来。

**Scope:**
- 首批 6~9 个场景
- 至少覆盖 memory / relationship / combat / rules / world

**Acceptance:**
- `core` profile 能稳定运行
- 每个场景有明确 pass threshold 与 breakdown

---

### M14-T5: Baseline Report + Comparison Workflow

**Goal:** 跑出第一份 NeonRP RP benchmark baseline，并支持版本间比较。

**Changes:**
- 结构化 JSON report
- compare 工具 / 脚本
- benchmark summary 文档

**Acceptance:**
- 可以比较 M13 前后、不同 agent config、不同 world config 的 RP 得分变化
- 能明确指出最弱维度（例如 memory 强、social 弱）

---

### M14-T6: Regression Gate for Future Milestones

**Goal:** 让 benchmark 成为后续 M15 的质量门，而不只是展示项目。

**Changes:**
- 把 `core` profile 的 smoke 纳入日常回归
- `coverage/full` 作为人工或定期 benchmark

**Acceptance:**
- M15 的复杂内容开发可以引用 M14 benchmark 作为回归基线
- benchmark 失败时能定位到场景、维度、状态层面

---

## 推荐开发步骤（按 ClawProBench 节奏）

1. **inventory first**
   - 先把 scenario catalog 和 metadata 建起来
2. **dry second**
   - 不跑完整模型前先校验 schema / fixtures / profile 归属
3. **smoke core**
   - 先跑 `core` profile 单 trial
4. **multi-trial baseline**
   - 再跑 `core` 3-trial baseline
5. **compare & iterate**
   - 用结构化 report 比较不同版本能力变化

---

## Milestone Acceptance (M14)

- [ ] 建立 live-first 的 RP benchmark harness
- [ ] 建立 scenario catalog / schema / inventory / dry 工作流
- [ ] 10 个 `aha moment` 至少有 6 个进入 `core` active profile
- [ ] deterministic grading 成为主要评分来源
- [ ] 输出可比较的 benchmark report，并形成首份 baseline
- [ ] benchmark 可作为 M15 的回归质量门
