# M1 Task Cards (Validation + Index)

这些 task cards 面向"让 Codex/自动化代理按卡片逐个推进"。每张卡片都尽量控制在一次小 PR 的规模内。

质量门（每张卡片收尾必跑）：见 `docs/QUALITY_GATES.md`。

## Task dependency graph
```
M1-T0 (doc-only)
  └→ M1-T1 (validate CLI) ──→ M1-T3 (inverted index, optional)
  └→ M1-T2 (index CLI)    ──→ M1-T4 (find) ──→ M1-T5 (context)
                                                     └→ M1-T6 (review gate)
```
注：M1-T2 的核心逻辑（`scan_entities`）内部调用 `validate_game_data()`，因此 T2 实质依赖 T1 的核心模块（但不依赖 T1 的 CLI 命令）。

## Output format convention (all M1 commands)
- 默认：人类可读文本
- `--json`：结构化 JSON 输出到 stdout（便于管道和 agent 消费）
- 所有 M1 CLI 命令（validate / index / find / context）必须支持 `--json` 标志

---

## M1-T0 — World 数据约定（Doc-only）

**Goal**
- 固化 `game/` 的最小实体规范与路径约定，为 validate/index/find/context 提供稳定前提。

**Primary docs**
- `docs/ADRs/0004-world-entity-conventions.md`
- `docs/M1_VALIDATION_INDEX_DESIGN.md`

**Acceptance**
- 文档明确：必填字段（id/kind/name）、可选字段（tags/summary）、路径约定 `game/<kind>/<id>.json`
- 文档明确：id 唯一性与 kind/path 一致性规则

---

## M1-T1 — `neonrp validate`（schema + 约束层）

**Goal**
- 提供可重复、可审计的校验入口，并把错误信息做成"可修复"的形式。

**Existing code (from M0)**
- `src/neonrp/core/validation.py` — 完整的核心逻辑：`load_schema()`（优先项目 schema → 内置 schema）、`validate_game_data()`（结构层 + 约束层）、`ValidationIssue` dataclass
- `src/neonrp/schema/game_entity.schema.json` — 内置 JSON Schema Draft 7
- 核心逻辑已实现且 lint 通过，本 task 侧重 CLI 包装与测试。

**New work**
- 新增命令：`src/neonrp/commands/validate.py`（调用已有 `validate_game_data`，格式化输出）
- CLI 注册：`src/neonrp/cli.py` 添加 `validate` 命令
- 支持 `--json` 输出标志
- 编写测试（核心逻辑 + CLI 两层）

**Acceptance**
- `neonrp validate` 在存在坏数据时 exit code = 1，且每条错误包含文件路径与字段路径
- schema 缺失/IO 错误时 exit code = 2
- `--json` 输出结构化错误列表

**Tests**
- 单测：schema pass/fail（fixtures），覆盖结构层与约束层
- CLI：`CliRunner` 覆盖 exit code 0/1/2 与 `--json` 输出

---

## M1-T2 — `manifest.entities` + `neonrp index build|update`

**Goal**
- 扫描 `game/`，把实体元数据写入 manifest，为 find/context 提供常量时间定位与增量更新基础。

**Existing code (from M0)**
- `src/neonrp/core/manifest.py` — `EntityRecord` 模型已定义（id/kind/name/tags/summary/path/mtime/hash），`Manifest.entities` 字段已添加
- `src/neonrp/core/indexing.py` — `scan_entities()`、`update_entities()`、`compute_file_hash()`、`records_to_map()` 已实现
- 核心逻辑已实现且 lint 通过，本 task 侧重 CLI 包装、修复 scan_entities 行为、测试。

**New work**
- **修复 `scan_entities()` 全有全无行为**：当前任何校验错误都返回空记录。改为：跳过校验不通过的实体，索引合法实体，收集并返回警告列表。
- 新增命令：`src/neonrp/commands/index.py`（`index build|update` 子命令）
- CLI 注册：`src/neonrp/cli.py` 添加 `index` 命令组
- `manifest.version` bump 到 `"0.2"`
- 支持 `--json` 输出标志
- 编写测试

**Acceptance**
- build 后 `manifest.entities` 可稳定重建（幂等）
- build 跳过无效实体并输出警告（不因单个坏文件导致整体失败）
- update 只更新变更条目，并移除已删除文件对应条目
- `--json` 输出索引统计

**Tests**
- 单测：扫描、去重、hash/mtime 更新策略、部分失败场景（混合有效/无效实体）
- 集成：temp 项目 root 下 init → index build → index update

---

## M1-T3 — 可选：倒排关键词索引（`.neonrp/index/`）

**Goal**
- 为 keyword 搜索加速（避免每次都全盘扫描文件内容）。

**Decision**
- 使用 JSON 文件（`.neonrp/index/inverted.json`），不引入 SQLite（见 ADR 0005）。

**Acceptance**
- `find` keyword 在 100+ 实体时响应 < 1s（基准测试）
- 增量更新正确（新增/删除/修改能反映到索引）

---

## M1-T4 — `neonrp find`

**Goal**
- 按 id/tag/kind/keyword 定位实体，并输出路径与摘要。

**Suggested changes**
- 新增命令：`src/neonrp/commands/find.py`
- 默认基于 `manifest.entities`；manifest.entities 为空时提示用户执行 `index build`（不做降级扫描，避免双代码路径）
- 纯 id 查询：维持"全局唯一"规则，直接按 id 精确匹配
- 支持 `--json` 输出标志

**Acceptance**
- `--id` 精确定位；`--tag/--kind` 过滤；keyword 给出 Top-N（可配置）
- manifest.entities 为空时输出提示而非报错
- `--json` 输出实体列表

**Tests**
- CLI：`CliRunner` 覆盖多种查询模式 + 空索引场景

---

## M1-T5 — `neonrp context`

**Goal**
- 把 query 变成"最小上下文集合"（path + snippet），并提供可解释打分（用于调参与后续 agent）。

**Suggested changes**
- 新增命令：`src/neonrp/commands/context.py`
- ranker：基于 tags/name/summary（必要时轻量内容 token）打分
- 支持 `--json` 输出标志

**Snippet specification**
- 优先使用 `summary` 字段原文
- 缺失时截取文件内容前 200 字符（截断处标记 `...`）
- snippet 最大长度上限：200 字符

**Score breakdown format**
输出结构（`--json` 模式下每条结果包含）：
```json
{
  "entity_key": "town:tokyo",
  "path": "game/town/tokyo.json",
  "name": "Tokyo",
  "snippet": "A dense neon city with countless alleys.",
  "score": 0.85,
  "score_breakdown": {
    "tags": 0.4,
    "name": 0.3,
    "summary": 0.15,
    "content": 0.0
  }
}
```

**Stability definition**
- "结果顺序稳定"：相同 query + 相同 manifest.entities → 相同排序结果。分数相同时按 entity_key 字典序排序。

**Acceptance**
- `--limit N` 返回 N 条以内结果；结果顺序稳定
- `--json` 输出包含 score breakdown
- snippet 不超过 200 字符

**Tests**
- 单测：ranker 排序与过滤、snippet 截断逻辑
- CLI：`CliRunner` 覆盖 `--limit` 与 `--json`

---

## M1-T6 — 阶段 Review Gate

**Goal**
- 跑一次 `opencode run` 审查并落盘到 `reviews/`，按意见修复后保持 `pytest` 全绿。

**Acceptance**
- `reviews/` 下存在阶段审查文件（命名见 `docs/QUALITY_GATES.md`）
- 修复后二次 `pytest` 全绿
- `docs/ROADMAP.md` 勾选完成项，`docs/PROGRESS.md` 追加记录

