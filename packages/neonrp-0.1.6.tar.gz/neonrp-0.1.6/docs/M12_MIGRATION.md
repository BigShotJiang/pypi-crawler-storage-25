# M12 Migration Notes

This note documents the compatibility contract introduced by M12.

## Routing files

- `game-start.json` = bootstrap contract
- `active-agent.json` = live routing contract

Do not mix these responsibilities.

## Router execution modes

- `fast`: 保留原有语义。sticky specialist 可以直接成为本回合前台输出者。
- `orchestrator`: narrator/orchestrator 永远是前台输出者；`active-agent` 仅表示后台领域 owner，`delegated_to` 表示本回合实际调用的 specialist。
- `multi-agent`: 预留给未来更复杂的协作模式。

建议：
- 旧项目默认按 `fast` 兼容。
- 新模板默认切到 `orchestrator`。

## Old projects without `active-agent.json`

- Missing `game/meta/active-agent.json` is treated as normal.
- Runtime falls back to the configured top-level router agent.
- Conventional router ids support both `narrator` and `orchestrator`, with `narrator` preferred when both exist.

## Old agent templates without `direct_write_globs`

- In play mode, if `direct_write_globs` is empty or absent, NeonRP falls back to `write_globs`.

## Old agent templates with `max_task_turns`

- Agent-level `max_task_turns` is ignored at runtime.
- Session/config-level `max_turns` is the source of truth.
- Existing projects should remove `max_task_turns` to avoid confusion.

## Suggested migration checklist

1. Ensure the project has a valid top-level router agent (`narrator` or `orchestrator`).
2. Add `game/meta/active-agent.json` if you want sticky delegation to persist across turns.
3. Keep startup instructions in `game/meta/game-start.json` only.
4. Remove stale `max_task_turns` from specialist agents.
5. Prefer explicit `direct_write_globs` for play-mode specialists.
