# Issue: Ollama 远程服务器工具调用参数丢失

**状态**: 调查中 (暂停)
**日期**: 2026-02-17
**影响**: 远程 Ollama 服务器 (Mac via VPN, `100.92.195.7:11434`) 工具调用不可靠

## 问题描述

远程 Ollama 服务器通过 VPN 连接时，LLM 工具调用参数经常丢失或返回空 `{}`。
本地 LM Studio (`127.0.0.7:1234`) 在修复 `to_api_dict` 后工作正常。

## 已完成的修复

### 1. `to_api_dict` content 字段 (已解决本地问题)
- **文件**: `src/neonrp/core/llm.py:64-65`
- **问题**: assistant 消息带 tool_calls 但 `content=None` 时，序列化时缺少 `content` 键
- **修复**: assistant 角色始终包含 `content: ""`
- **效果**: 修复了本地 LM Studio 的问题，远程 Ollama 仍有问题

### 2. ask_user 提示词强化
- **文件**: `src/neonrp/core/prompts.py`, `src/neonrp/core/skills.py`
- **修复**: 将 ask_user 描述从建议性改为强制性 (MUST/NEVER 语言)

### 3. 空参数断路器
- **文件**: `src/neonrp/core/conversation.py:282-509`
- **修复**: 连续 3 次空参数工具调用后注入系统消息，强制模型用纯文本回复

### 4. 日志基础设施
- **文件**: `src/neonrp/cli.py` (`_setup_logging`)
- **修复**: 配置文件日志到 `.neonrp/logs/neonrp.log`

### 5. `disable_streaming` 配置选项
- **文件**: `src/neonrp/core/config.py:88`, `src/neonrp/core/conversation.py:294-302`
- **修复**: 模型配置中添加 `disable_streaming: bool`，设为 true 时即使 TUI 有回调也用非串流 `chat()`
- **配置示例**:
  ```json
  "openai-100-xxx": {
      "provider": "openai",
      "base_url": "http://100.92.195.7:11434/v1",
      "disable_streaming": true,
      ...
  }
  ```

### 6. 诊断日志增强
- **文件**: `src/neonrp/core/llm_openai.py`
- 添加了 `chat()` 发送消息摘要日志、响应摘要日志、串流 delta 日志

## 当前调查进展

### 串流模式 (disable_streaming=false)
日志显示 Ollama 的两段式 chunk 模式：
- Chunk 1: `id=xxx name='read_file' args=''` (名称，空参数)
- Chunk 2: `id=None name=None args='{"path":"..."}'` (参数，无名称)

两个 chunk 都用 `key=0` 合并。本地 LM Studio 正常工作，远程 Ollama 有时丢失 Chunk 2。

### 非串流模式 (disable_streaming=true) — 当前卡点
用户测试了 `disable_streaming=true`，日志显示：

```
18:54:28 INFO  Streaming disabled for this provider
18:54:34 DEBUG chat() raw tool_call: id=477402481 name=read_file args='{"path":"game/meta/game-start.json"}' content='我来帮您开始游戏！'
```

**第一次 `chat()` 调用成功**，正确返回了 `read_file` 工具调用。
但执行工具后，**第二次 `chat()` 返回了空内容 `""` 且无工具调用**，对话就此结束。

Session JSONL 确认：
```jsonl
{"role": "assistant", "content": "我来帮您开始游戏！...", "tool_calls": [{"name": "read_file", ...}]}
{"role": "tool", "content": "{\"status\":\"success\",...}", "tool_call_id": "477402481"}
{"role": "assistant", "content": ""}  ← 第二次调用返回空
```

### 待调查方向

1. **非串流空响应原因**: 第二次 `chat()` 为什么返回空？新增的日志（消息摘要 + 响应摘要）在下次测试时会提供更多信息
2. **消息格式兼容性**: 检查发送给 Ollama 的消息格式是否完全兼容（特别是 tool role 消息的格式）
3. **Ollama 版本/配置**: 远程 Ollama 的版本可能有已知的工具调用 bug
4. **上下文长度**: 第二次请求可能超过模型上下文限制导致截断

## 相关日志位置

- 运行日志: `my-rpg/.neonrp/logs/neonrp.log`
- Session 文件: `my-rpg/.neonrp/sessions/main.jsonl`

## 测试矩阵

| 服务器 | 串流 | 第一次调用 | 后续调用 | 状态 |
|--------|------|-----------|---------|------|
| 本地 LM Studio | on | OK | OK | 正常 |
| 本地 LM Studio | off | OK | OK | 正常 |
| 远程 Ollama | on | OK (有时) | 参数丢失 | 有问题 |
| 远程 Ollama | off | OK | 返回空 | 有问题 |
