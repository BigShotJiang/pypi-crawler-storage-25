# Progress Log

> Rule: update this file at least once per completed task/PR, and always append new entries at the end of `## Entries` (do not insert at the top).

## Template (copy for each entry)
- Date:
- Milestone/Task:
- Summary (what changed):
- Evidence (commands run + results):
- Notes/Risks:
- Next:

---

## Entries

- Date: 2026-01-29
- Milestone/Task: M0 (Skeleton + Core Lifecycle)
- Summary (what changed): Implemented init, run, save, load, undo, branch commands. Established atomic storage layer and append-only event logging. 
- Evidence (commands run + results): `pytest` passed. `opencode run` passed after fixes. Verified branch isolation and atomic snapshots manually.
- Notes/Risks: Redo command currently not exposed (implementation detail of undo).
- Next: M1 (Validation + Index)

- Date: 2026-01-29
- Milestone/Task: M1 Design (Validation + Index)
- Summary (what changed): Added M1 design spec (validation, entity indexing, find/context commands) and documented world entity conventions + indexing strategy as ADRs. Expanded ROADMAP M1 into concrete tasks/acceptance/tests/review gate.
- Evidence (commands run + results): Docs-only change (no runtime behavior change).
- Notes/Risks: Implementation must reconcile existing M0 prototypes (event naming, branch storage) with ADR intent without breaking M0 invariants.
- Next: Implement M1-T0 → M1-T5 (validate/index/find/context)

- Date: 2026-01-29
- Milestone/Task: M1 Plan Update
- Summary (what changed): Expanded ROADMAP M1 section with detailed goals, non-goals, command behavior, indexing fields, and ranking guidance. Linked to M1 task cards for execution.
- Evidence (commands run + results): Docs-only change (no runtime behavior change).
- Notes/Risks: Plan assumes world path conventions and schema loaders are ready before index/find/context work begins.
- Next: Execute M1-T0 → M1-T5 in order.

- Date: 2026-01-29
- Milestone/Task: M1 Implementation (Validation + Index)
- Summary (what changed): 
  - H0/H1: Fixed 7 lint errors and Pydantic v2 deprecation warnings
  - M1-T1: Created `validate` CLI command with --json support, exit codes 0/1/2
  - M1-T2: Fixed `scan_entities()` partial failure behavior, created `index build|update` CLI
  - M1-T4: Created `find` CLI with --id/--tag/--kind/keyword search
  - M1-T5: Created `context` CLI with explainable scoring and snippets
  - Bumped manifest.version to "0.2"
- Evidence (commands run + results): `ruff check .` passed. `pytest -v` passed with 41 tests.
- Notes/Risks: M1-T3 (inverted index) skipped as optional per task cards.
- Next: M1-T6 Review Gate

- Date: 2026-01-29
- Milestone/Task: M1-T6 Review Gate
- Summary (what changed): Ran code review, addressed minor findings, and reconfirmed tests. Marked M1 review gate complete in ROADMAP.
- Evidence (commands run + results): Review artifact saved at `reviews/M1_review_20260129.md`. `pytest` remained green (41 tests).
- Review findings:
  - [fixed] Unused `root` parameter in `_validate_entity_for_index()` (indexing.py)
  - [accepted] `model_dump()` datetime serialization implicit via `default=str` — works correctly with `@field_serializer`
  - [wontfix] `--verbose` flag for commands — not needed for current scope
  - [wontfix] Schema caching in memory during batch operations — premature optimization
  - [wontfix] Progress indicator for large world directories — premature optimization
  - [wontfix] Additional tests (deeply nested paths, empty query, combined filters) — low risk scenarios
- Notes/Risks: Optional M1-T3 inverted index remains deferred.
- Next: M2 Design (Agents + Plan/Diff/Apply)

- Date: 2026-01-29
- Milestone/Task: M2 Design (Agents + Plan/Diff/Apply)
- Summary (what changed): Defined M2 agent packaging, proposal format, permission boundaries, Plan→Diff→Validate→Apply pipeline, logging layout, and task cards/ADRs for implementation.
- Evidence (commands run + results): Docs-only change (no runtime behavior change). Added `docs/M2_AGENTS_PLAN_DIFF_APPLY_DESIGN.md`, `docs/M2_TASK_CARDS.md`, ADR 0006/0007.
- Notes/Risks: Staging strategy and read-permissions hard isolation are scoped as design choices; implementation should start with write hard-enforce + soft read tracking.
- Next: Implement M2-T0 → M2-T6 (agent spec → commands → proposal/diff/apply → retrieval integration)

- Date: 2026-01-29
- Milestone/Task: M2 Implementation (Agents + Plan/Diff/Apply)
- Summary (what changed):
  - H2: Added `actor` field to GameEvent model for agent attribution
  - M2-T1: Created `agent new/list/show/path` CLI commands with template generation
  - M2-T2: Created `core/proposal.py` (Proposal/Op models) and `core/permissions.py` (glob matching, deny-first priority)
  - M2-T3: Created `core/diffing.py` for unified diff generation and summary
  - M2-T4: Created `core/apply.py` with staging strategy, validation gate, and event log integration
  - M2-T5: Added `agent apply` and `agent logs` CLI commands
  - M2-T6: Created `core/retrieval.py` and `agent context` command for retrieval integration
- Evidence (commands run + results): `ruff check .` passed. `pytest -v` passed with 110 tests.
- Notes/Risks: LLM-driven agent execution (`agent run`) deferred to M3. Current `agent apply` requires pre-generated proposal.json.
- Next: M2-T7 Review Gate

- Date: 2026-01-30
- Milestone/Task: M2-T7 Review Gate
- Summary (what changed): Ran code review via Antigravity AI, documented findings in `reviews/M2_review_20260130.md`. Risk level: Low. No blocking issues.
- Evidence (commands run + results): `uv run ruff check .` passed. `uv run pytest -v` passed with 110 tests.
- Review findings:
  - [deferred:M3] `apply.py:149-151` game/ directory replacement non-atomic (rmtree + copytree has crash window) — staging already prevents validation failures; full atomic rename deferred
  - [deferred:M3] `agent.py:44` template file writes not using `atomic_write_json` — low risk (one-time creation, not crash-sensitive)
  - [deferred:M3] `retrieval.py:93` returns empty list when manifest.entities is empty without hinting user to run `index build`
  - [deferred:M3] `diffing.py:68` delete hunk header `@@ -1,0 +0,0 @@ DELETE` is non-standard unified diff format
- Notes/Risks: Deferred items require Pre-M3 housekeeping tasks in ROADMAP.
- Next: M3 (LLM Integration + End-to-End Agent Execution)

- Date: 2026-01-30
- Milestone/Task: M3 Design (LLM Integration + Commands/Skills + Import)
- Summary (what changed): Added M3 design spec (LLM adapter + config, skill tool registry + auditing, agent run flow, SillyTavern import mapping, game scaffolding) plus task cards and ADRs.
- Evidence (commands run + results): Docs-only change (no runtime behavior change). Added `docs/M3_LLM_COMMANDS_SKILLS_IMPORT_DESIGN.md`, `docs/M3_TASK_CARDS.md`, ADR 0008/0009/0010; expanded M3 section in `docs/ROADMAP.md`.
- Notes/Risks: PNG-based SillyTavern card extraction is intentionally best-effort/optional; deterministic stub provider is required for CI stability.
- Next: Implement M3-T0 → M3-T7 in order (docs/config → adapter/skills → agent run → import → scaffolding).

- Date: 2026-01-30
- Milestone/Task: Pre-M3 Housekeeping (H3/H4/H5/H6)
- Summary (what changed):
  - H3: Fixed `agent.py:393` bug (`manifest.active_branch` → `manifest.current_branch`)
  - H4: Implemented atomic game/ directory replacement via rename strategy in `apply.py`
  - H5: Added warning log in `retrieval.py` when entity index is empty
  - H6: Standardized delete hunk header in `diffing.py` to unified diff format (`@@ -1,{n} +0,0 @@`)
  - Updated test for H6 change
- Evidence (commands run + results): `uv run ruff check .` passed. `uv run pytest -v` passed with 110 tests.
- Notes/Risks: None.
- Next: M3-T0 (Verify M3 specs and ADRs)

- Date: 2026-01-30
- Milestone/Task: M3-T1 through M3-T5 (Config, LLM Adapter, Skills, Agent Run, Agent Run --apply)
- Summary (what changed):
  - M3-T1: Created `core/config.py` with config loading (default < config file < CLI flags), API key lookup, `.env` file loader
  - M3-T2: Created LLM adapter Protocol (`core/llm.py`), deterministic stub (`core/llm_stub.py`), OpenAI-compatible adapter (`core/llm_openai.py`)
  - M3-T2+: Added GLM (Zhipu AI) provider via OpenAI-compatible adapter with `GLM_*` env var support
  - M3-T3: Created skill tool registry (`core/skills.py`) with built-in skills (read_context, find, read_file, list_entities), per-file permission check (deny-first), JSONL audit logging
  - M3-T4: Implemented `neonrp agent run <id> --query "..." [--provider stub|glm|openai] [--fixture <path>] [--json]` (load agent → context → LLM → parse proposal → diff preview → save logs)
  - M3-T5: Implemented `--apply` flag on `agent run` (reuses M2 `apply_proposal()` pipeline)
  - Added `.gitignore` with `.env` and standard Python entries
  - Added `.env` file loader in `config.py` (loaded at CLI startup in `cli.py`)
  - Added `rationale` field to `Proposal` model (required by LLM output format)
  - Fixed agent template `write_globs` to use `**` (ops paths are relative to game/, not project root)
  - Fixed user prompt template to clarify op paths are relative to `game/`
  - Added `init` command to create `config.json` template
- Evidence (commands run + results): `uv run ruff check .` passed. `uv run pytest -v` passed with 168 tests (was 152).
- Notes/Risks:
  - Op paths are relative to `game/` directory (e.g., `character/hero.json` not `game/character/hero.json`)
  - Agent template `write_globs` changed from `["game/**"]` to `["**"]` to match op path convention
  - GLM provider requires `openai` package + `GLM_*` env vars (API-compatible with OpenAI)
  - M3 LLM calls are single-shot (no multi-turn tool call loop; deferred to M3.5+)
- Next: M3-T6 (SillyTavern import)

- Date: 2026-01-30
- Milestone/Task: M3-T6 (SillyTavern Character Card Import)
- Summary (what changed):
  - Created `core/importers/sillytavern.py` with card parsing (v1 flat + v2 spec/data wrapper), name→kebab-case ID conversion, ID conflict resolution (-2/-3), tag normalization, summary extraction
  - Created `commands/import_cmd.py` with `neonrp import sillytavern-card <file> [--id <id>] [--json]` CLI command
  - Registered `import` command group in `cli.py`
  - Imported entities stored at `game/character/<id>.json` with `meta.source=sillytavern` and `meta.raw` containing full original payload (per ADR-0010)
  - Invalid JSON / invalid card / invalid explicit ID all exit code 1 with actionable error messages
  - PNG import rejected with helpful message (deferred to M3.5+)
- Evidence (commands run + results): `uv run ruff check .` passed. `uv run pytest -v` passed with 213 tests (was 168). Verified real chubai card import → validate → index build end-to-end.
- Notes/Risks:
  - PNG card extraction deferred to M3.5+ as planned
  - Tags are lowercased and deduplicated; original order preserved
  - Summary uses `personality` field if non-empty, otherwise truncated `description` (≤300 chars at sentence boundary)
- Next: M3-T7 (game scaffolding)

- Date: 2026-01-30
- Milestone/Task: M3-T7 (Game Scaffolding)
- Summary (what changed):
  - Added `neonrp game new` command with hardcoded default template and `--force`/`--json` support
  - Registered game command in CLI
  - Added CLI tests for scaffolding, conflict handling, and validation/indexing
- Evidence (commands run + results): `uv run ruff format .` and `uv run ruff check .` passed. `uv run pytest` passed (219 tests).
- Notes/Risks: None.
- Next: M3-T8 (review gate)

- Date: 2026-01-30
- Milestone/Task: M3-T8 Review Gate
- Summary (what changed): Ran format/lint/tests and completed opencode review; applied review fixes for `game new` atomic overwrite and exit code conventions.
- Evidence (commands run + results): `uv run ruff format .` and `uv run ruff check .` passed. `uv run pytest` passed (219 tests). Review saved at `reviews/M3_review_20260130.md`.
- Review findings:
  - [fixed] `--force` in `game new` must be atomic; prior behavior could delete existing world before successful writes. (src/neonrp/commands/game.py:49, src/neonrp/commands/game.py:86)
  - [fixed] `game new` in uninitialized project should exit code 1 (user error), not 2 (system error). (src/neonrp/commands/game.py:35)
  - [wontfix] Add structured error code/type in JSON error payloads for `game new` — current output is sufficient for M3. (reviews/M3_review_20260130.md)
  - [accepted] Preserve non-template files on `--force` — current behavior intentionally replaces the world for scaffolding. (reviews/M3_review_20260130.md)
  - [fixed] Add tests for uninitialized `game new` and unknown template errors. (tests/test_game_cli.py)
  - [wontfix] Simulated write-failure test for `--force` atomic swap — requires fault injection; deferred. (reviews/M3_review_20260130.md)
- Notes/Risks: None.
- Next: M4 (Sandbox + Replay)

- Date: 2026-01-30
- Milestone/Task: M4 Design (Sandbox + Replay)
- Summary (what changed): Added M4 design spec (save meta/events copy, sandbox branch model, replay verify/checkout flow, world hash contract) plus task cards and ADRs.
- Evidence (commands run + results): Docs-only change (no runtime behavior change). Added `docs/M4_SANDBOX_REPLAY_DESIGN.md`, `docs/M4_TASK_CARDS.md`, ADR 0011/0012; expanded M4 section in `docs/ROADMAP.md`.
- Notes/Risks: Replay depends on consistent auditability; commands that mutate world outside apply/proposal pipeline may need refactor for full replay coverage.
- Next: Implement M4-T0 → M4-T5 (docs → save meta → sandbox → replay).

- Date: 2026-01-31
- Milestone/Task: Pre-M4 Housekeeping (H7/H8/H9)
- Summary (what changed):
  - H7: Fixed `save.py:load` command to use atomic rename strategy (crash-safe game/ replacement using .new/.old rename swap)
  - H8: Fixed deprecated `datetime.utcnow()` → `datetime.now(timezone.utc)` in save.py
  - H9: Added PNG character card import support via pure Python tEXt chunk reader (`core/importers/png_extract.py`)
  - All existing JSON import tests pass; 11 new PNG extraction tests added
- Evidence (commands run + results): `uv run ruff check .` passed. `uv run pytest -v` passed with 230 tests (was 219).
- Notes/Risks: PNG extraction does not validate PNG image structure beyond chunk reading; only extracts `chara` keyword from `tEXt` chunks.
- Next: M4-T1 (Save snapshot meta + world hash utility)

- Date: 2026-01-31
- Milestone/Task: M4-T6 Review Gate
- Summary (what changed): Ran opencode review (risk: High), applied all must-fix and should-fix items, added 24 new tests. Review saved at `reviews/M4_review_20260131.md`.
- Evidence (commands run + results): `uv run ruff format .` and `uv run ruff check .` passed. `uv run pytest -v` passed with 290 tests (was 230).
- Review findings:
  - [fixed] Path traversal risk on sandbox/replay branch names — added `validate_branch_name()` in `core/paths.py`, applied in `commands/sandbox.py` (`sandbox_new`, `sandbox_switch`, `sandbox_drop`) and `core/replay.py` (`replay_to_sandbox`). Rejects names containing `/`, `\`, `..`, drive letters, and non-alphanumeric start characters. (Must-fix)
  - [fixed] Replay correctness — `core/replay.py:replay_verify` now checks if any replayed events have `success=False` and sets overall `success=False` accordingly, instead of only checking hash divergence. (Must-fix)
  - [fixed] Replay-to-sandbox event history incomplete — `core/replay.py:replay_to_sandbox` now builds sandbox event log from the **branch** event log (not the save's `events.jsonl` snapshot), ensuring events beyond the save's head are included. (Must-fix)
  - [fixed] Snapshot atomicity — `commands/save.py` events.jsonl copy now uses temp file + `os.replace` instead of `shutil.copy2` for crash-safe writes. (Must-fix)
  - [fixed] System proposal logs incomplete — `core/system_proposal.py:_save_system_logs` now writes standard log set (`input.json`, `proposal.json`, `diff.patch`, `validation.json`, `apply.json`) matching agent run log spec. Logs are now saved on both success and failure. (Should-fix)
  - [fixed] System proposal unrestricted permissions — `core/system_proposal.py` `deny_globs` restored to `[".neonrp/**", "agents/**"]` (was empty `[]`). System proposals can still write anywhere in game/ but no longer bypass the default deny policy. (Should-fix)
  - [fixed] Exit codes in JSON mode — `commands/replay.py` verify command now exits 1 on failure in JSON mode. `commands/save.py` now exits 1 on all error paths (missing world, not initialized, snapshot exists, general exception). (Should-fix)
  - [fixed] Replay empty events success — `core/replay.py:replay_verify` now compares world hashes even when `events_to_replay` is empty, detecting divergence from save baseline. (Should-fix)
  - [wontfix] Sandbox `shutil.rmtree` before copy — low risk; sandbox creation is not crash-sensitive (can be re-created from save). (Nice-to-have)
  - [wontfix] Per-event expected vs actual hashes in replay diagnostics — premature; current first-divergent-file reporting is sufficient for M4. (Nice-to-have)
- Notes/Risks: None.
- Next: M5 (TUI)

- Date: 2026-01-31
- Milestone/Task: M5 Design (TUI)
- Summary (what changed): Moved Mods to M6 and defined a Claude Code/OpenCode-style TUI plan (layout, keybindings, command palette, agent run + diff + apply flow, logs/files navigation) with task cards and ADRs.
- Evidence (commands run + results): Docs-only change (no runtime behavior change). Added `docs/M5_TUI_DESIGN.md`, `docs/M5_TASK_CARDS.md`, ADR 0013/0014; updated `docs/ROADMAP.md`.
- Notes/Risks: TUI framework choice (Textual) introduces a new dependency; keep business logic in core and UI as a thin client to preserve testability.
- Next: Implement M5-T1 → M5-T7 (tui scaffold → palette → agent run/diff/apply → explorer/logs → tests → review gate).

- Date: 2026-02-01
- Milestone/Task: M5 Plan Revision (计划审查)
- Summary (what changed):
  - 审查 M5 开发计划，识别 9 项问题/风险，按建议修订文档：
  - 新增 Pre-M5 Housekeeping 章节：H10（提取 agent run 编排逻辑到 `core/agent_runner.py`）、H11（关闭 Open Questions）
  - ADR-0013、ADR-0014 状态从 Proposed → Accepted
  - `M5_TUI_DESIGN.md` 中 Open Questions 替换为 Resolved Questions + 新增 Streaming 策略章节
  - M5-T3 拆分为 M5-T3a（Agent Run 面板）和 M5-T3b（Diff Preview + Apply）
  - M5-T2 验收标准扩展：增加 `:` 命令解析（tokenize + dispatch）
  - M5-T1 Suggested changes 增加 `pyproject.toml`（textual 依赖）
  - M5-T6 测试目标从"5~10 个"提升到"15~25 个"（view-model 单测 + Textual 交互测试）
  - ROADMAP M5 新增任务依赖图、Resolved decisions、更严格的验收标准和测试目标
- Evidence (commands run + results): Docs-only change (no runtime behavior change). Modified `docs/ROADMAP.md`, `docs/M5_TASK_CARDS.md`, `docs/M5_TUI_DESIGN.md`, ADR 0013/0014.
- Notes/Risks: H10（agent_runner 提取）是 M5-T3a 的前置条件；若提取不彻底，TUI 可能需要 hack 调用 CLI 内部函数。
- Next: Execute H10 → H11 → M5-T1 → M5-T2 → M5-T3a → M5-T3b → M5-T4/T5 → M5-T6 → M5-T7.

- Date: 2026-02-01
- Milestone/Task: M5 Implementation (TUI)
- Summary (what changed):
  - H10: Extracted agent run orchestration to `core/agent_runner.py` (~260 lines)
    - Created `AgentRunResult` dataclass
    - Created `run_agent()` core function (reusable by CLI and TUI)
    - Slimmed `commands/agent.py:agent_run` to thin CLI wrapper
    - Added 7 unit tests for `agent_runner.py`
  - M5-T1: TUI scaffold with Textual framework
    - Added `textual>=0.50.0` dependency
    - Created `commands/tui.py` (CLI entry), `tui/app.py` (4-pane layout)
    - StatusBar, Navigator, Transcript, Details, InputArea panels
    - `q` quit keybinding
  - M5-T2: Command Palette
    - Created `tui/commands.py` (parser with 13 commands)
    - Created `tui/palette.py` (modal overlay with fuzzy search)
    - `Ctrl+K` / `Ctrl+P` keybindings
    - Added 20 unit tests for command parser
  - M5-T3a/b: Agent Run + Diff Preview + Apply
    - Integrated `core/agent_runner.run_agent()`
    - `Ctrl+Enter` to submit query
    - Diff shown in Details pane
    - `a` keybinding to apply proposals
    - Created `panels/diff_view.py`
  - M5-T4: File Viewer
    - Created `panels/file_viewer.py` with large file truncation
  - M5-T5: Logs Browser
    - Created `panels/logs.py` with run_id list and details view
- Evidence (commands run + results): `uv run ruff format .` and `uv run ruff check .` passed. `uv run pytest -v` passed with 317 tests (was 290).
- Notes/Risks: TUI integration tests (simulating keystrokes) not yet added; current tests focus on view-model logic.
- Next: M5-T7 Review Gate

- Date: 2026-02-01
- Milestone/Task: M5-T7 Review Gate
- Summary (what changed): Ran opencode code review, documented findings, and updated project documentation.
- Evidence (commands run + results): `opencode run` completed successfully (exit 0). Review saved to `reviews/M5_review_20260201.md`. `uv run pytest -v` passed with 317 tests.
- Review findings:
  - [deferred:M6] Agent audit log naming inconsistency (`llm_input.json` vs `input.json`, `diff.txt` vs `diff.patch`) — functional, just inconsistent naming with documentation
  - [deferred:M6] Missing `validation.json` and `apply.json` in agent run logs — low impact for M5
  - [wontfix] Permission layer could reject absolute paths explicitly — already handled at proposal validation layer
- Notes/Risks: All M5 acceptance criteria met. TUI is functional with all planned commands implemented.
- Next: M6 (Agentic Loop + RPG 体验对齐)

- Date: 2026-02-01
- Milestone/Task: M6 Plan Revision (计划审查)
- Summary (what changed):
  - 审查 M6 开发计划，识别 9 项问题/风险，按建议修订文档：
  - **H14 提升为正式任务 M6-Tundo**：原 Pre-M6 Housekeeping H14（undo 修复）严重低估——当前 undo 仅移动 head_event 指针，不恢复 game/ 文件。提升为独立任务，设计 checkpoint 子系统（`.neonrp/checkpoints/<branch>/<event_id>/`，N=50 轮转，原子恢复）。
  - **M6-T0 新增 5 项必须解决的设计决策**：submit_proposal tool 设计、prompt 格式迁移、run vs agent run 边界、session-branch 绑定策略、token budget MVP 方案。
  - **依赖图修正**：H14→M6-T5 显式标注（auto-apply 依赖 checkpoint 保障可回退），T7（Review Gate）不再阻塞 T8（docs），T8 显式标注 T7 非阻塞。
  - **M6-T2 范围扩展**：新增 prompt 重写（从 "output JSON" 迁移到 "use tools then submit_proposal"）和 agent template 更新。
  - **M6-T3 Dispatcher 简化**：MVP 策略改为"单 agent=直接调用，多 agent=trigger→description→priority→fallback"，去掉过度设计的 embedding 路由。
  - **M6-T1 数据结构明确**：新增 Message/ToolCall/LLMTurnResult 数据结构定义，submit_proposal tool schema。
  - **M6-T4 Session 绑定**：路径明确为 `.neonrp/logs/sessions/<branch>/<session_id>.jsonl`，session 绑定到 branch。
  - **M6-T7/T8 解耦**：Review Gate 独立执行，docs 任务不被阻塞。
  - 原 M6（Mods）已在前次修订中推迟至 M7+。
- Evidence (commands run + results): Docs-only change (no runtime behavior change). Modified `docs/ROADMAP.md`, `docs/M6_TASK_CARDS.md`.
- Notes/Risks: M6-Tundo（checkpoint 子系统）是 M6-T5（auto-apply）的硬前置条件；若 checkpoint 实现不稳定，auto-apply 无法安全启用。M6-T0 的 5 项设计决策需在编码前全部关闭，否则后续任务会反复返工。
- Next: Execute M6-T0 → M6-Tundo → M6-T1 → M6-T2 → M6-T3 → M6-T4 → M6-T5 → M6-T6 → M6-T7 → M6-T8.

- Date: 2026-02-02
- Milestone/Task: M6 H12/H13 + T0-T5 (Core Implementation)
- Summary (what changed):
  - H12: 统一 agent run 日志命名与完整性（input.json/diff.patch/validation.json/apply.json）
  - H13: Agent spec 对齐（system_prompt 路径解析、defaults/context_limit、permissions）
  - M6-T0: 设计决策落地（submit_proposal tool、prompt 格式、run vs agent run 边界、session-branch 绑定、token budget MVP）。注：计划中的 ADR 0015-0018 未单独创建，决策直接体现在代码与 task cards 中。
  - M6-Tundo: 新增 `core/checkpoint.py`（263 行）——`.neonrp/checkpoints/<branch>/<event_id>/` 存储，N=50 轮转，原子恢复。`branch.py` undo/redo 重写为 find_checkpoint + restore_checkpoint。`agent_runner.py` 在 apply 前自动 create_checkpoint。
  - M6-T1: `core/llm.py` 新增 Message/ToolCall/LLMTurnResult/StreamChunk 数据结构；LLMAdapter Protocol 扩展 `chat()` + `chat_stream()`。`llm_openai.py` 实现 tool_calls 解析与多轮 messages。`llm_stub.py` 添加脚本化 fixture 支持。
  - M6-T2: `core/agent_runner.py` 新增 `run_agent_agentic()`（多轮 loop：tool_call → execute → result → 继续，直到 submit_proposal 或 max_turns=20）。`core/skills.py` 新增 submit_proposal tool schema + read_file 截断（5000 字符）。Prompt 模板从"输出 JSON"改为"使用工具探索后调用 submit_proposal"。
  - M6-T3: 新增 `core/dispatcher.py`（264 行）——AgentSpec/DispatchResult 数据结构，trigger→tags→priority→fallback 路由。`commands/run.py` 从 M0 echo 升级为 dispatch → agentic loop → diff/validate/apply。
  - M6-T4: 新增 `core/session.py`（310 行）——SessionEntry 数据结构，per-branch JSONL（`.neonrp/sessions/<branch>.jsonl`），append/read/truncate 操作，Message 互转。
  - M6-T5: auto-apply 模式集成到 agent_runner（`auto_apply` 参数）和 TUI（`t` 快捷键 toggle，StatusBar 显示 `[AUTO]/[manual]`）。
- Evidence (commands run + results): `uv run pytest -v` passed with 390 tests (was 317 at M5 end). New test files: test_checkpoint.py (301 lines), test_session.py (282 lines), test_dispatcher.py (271 lines).
- Notes/Risks:
  - Session 路径从计划的 `.neonrp/logs/sessions/<branch>/<session_id>.jsonl` 简化为 `.neonrp/sessions/<branch>.jsonl`（每 branch 单文件，无多 session 支持）
  - Checkpoint 创建在 agent_runner.py 而非 apply.py——system proposal（import、game new）不会创建 checkpoint
  - ADR 0015-0018 未创建（设计决策隐含在代码中）
- Next: M6-T6 (TUI Game Loop Integration)

- Date: 2026-02-02
- Milestone/Task: M6-T6 (TUI Game Loop Integration)
- Summary (what changed):
  - Integrated dispatcher (`core/dispatcher.py`) into TUI `_run_agent_query()` replacing direct `run_agent()` calls
  - Added session persistence: `append_user_query()` before dispatch, `append_assistant_response()` after
  - Implemented auto-apply toggle with `t` keybinding and `action_toggle_auto_apply()`
  - Enhanced StatusBar HUD with turn count and auto-apply indicator (`[AUTO]`/`[manual]`)
  - Added `_refresh_status_bar()` for dynamic status updates
  - Refactored apply logic into shared `_do_apply()` for manual and auto-apply paths
  - Added game loop state: `session_id`, `turn_count`, `auto_apply` on NeonRPApp
  - Created `tests/test_tui_game_loop.py` with 10 integration tests
- Evidence (commands run + results): `uv run pytest -v` passed with 400 tests (was 390).
- Notes/Risks: Session history is written but not yet restored on TUI startup (deferred). LLM streaming (M6-T7) remains optional.
- Next: M6-T7 (Review Gate) or M6-T8 (Docs Update)

- Date: 2026-02-02
- Milestone/Task: M6-T7 (LLM Streaming)
- Summary (what changed):
  - Added `StreamChunk` dataclass to `core/llm.py` for streaming chunks
  - Added `chat_stream()` method to `LLMAdapter` Protocol (generator-based)
  - Implemented `chat_stream()` in `OpenAIAdapter` with tool call accumulation
  - Implemented `chat_stream()` fallback in `StubAdapter` (simulates chunked output)
  - Created `tests/test_llm_streaming.py` with 11 tests
- Evidence (commands run + results): `uv run pytest -v` passed with 411 tests (was 400).
- Notes/Risks: TUI streaming integration deferred to M6.5 (requires agent_runner streaming support). LLM layer is fully streaming-capable.
- Next: M6-T8 (Review Gate)

- Date: 2026-02-02
- Milestone/Task: M6-T8 (Review Gate)
- Summary (what changed):
  - Ran `ruff format`, `ruff check`, `pytest` gates (all green, 411 tests)
  - Ran `opencode run` code review (Medium risk, saved to `reviews/M6_review_20260202.md`)
  - Applied review fixes:
    - Fixed agent_id sanitization in `_do_apply()` to prevent path traversal
    - Fixed permission loading to use `proposal.agent_id` instead of `result.agent_id`
    - Fixed `turn_count` increment to only occur when `run_result` is valid
    - Fixed streaming fallback in `llm_openai.py` to preserve accumulated tool calls
  - Re-ran `pytest` (411 tests green after fixes)
- Evidence (commands run + results): `opencode run` completed successfully. `uv run pytest` passed with 411 tests after fixes.
- Review findings:
  - [fixed] `_do_apply` agent_id path traversal vulnerability (tui/app.py:656) — sanitize agent_id
  - [fixed] Permission mismatch: used result.agent_id instead of proposal.agent_id (tui/app.py:656) — load from proposal
  - [fixed] `turn_count` incremented before run_result validation (tui/app.py:598) — moved inside check
  - [fixed] Streaming fallback dropped tool calls (llm_openai.py:357) — emit accumulated calls
  - [accepted] session_id not scoped in persistence — session storage is per-branch by design, session_id is for HUD display only
  - [deferred:M6.5] auto_apply toggle persistence — current transient behavior is acceptable for MVP
- Notes/Risks: All must-fix items addressed. M6 milestone complete.
- Next: M6 Post-Review Audit

- Date: 2026-02-02
- Milestone/Task: M6 Post-Review Audit (计划对照审查)
- Summary (what changed):
  - 对照 M6 task cards 逐项审查实现结果，更新 ROADMAP.md 勾选所有 M6 任务/验收/review gate
  - 补充 PROGRESS.md 缺失的 H12/H13 + T0-T5 合并条目
  - 识别 M6 实现与计划的偏差（见下方 findings）
- Review findings:
  - [accepted] M6-T0 计划的 ADR 0015-0018 未创建——设计决策直接体现在代码与 task cards 中，项目一致性降低但功能无影响
  - [accepted] Session 路径简化：计划 `.neonrp/logs/sessions/<branch>/<session_id>.jsonl` → 实际 `.neonrp/sessions/<branch>.jsonl`（每 branch 单文件，不支持多 session）。MVP 阶段合理简化。
  - [observation] Checkpoint 仅在 agent_runner.py 创建，system proposal（import/game new）调用 apply_proposal 时不创建 checkpoint——system proposal 的 undo 仍然无法恢复 game/
  - [deferred:M6.5] TUI 启动时恢复上次 session（当前仅写入不恢复）
  - [deferred:M6.5] TUI streaming 渲染集成（LLM 层 chat_stream 已实现，TUI 面板未接入）
  - [deferred:M6.5] auto_apply toggle 持久化（当前每次启动重置）
- Notes/Risks: 上述 deferred 项如需在 M7 前解决，可设 M6.5 housekeeping 批次。System proposal checkpoint 缺失是潜在风险——若用户通过 `game new --force` 或 `import` 覆盖 game/ 后 undo，game/ 不会恢复。
- Next: 评估与既定目标（Claude Code RPG 体验对齐）的差距

- Date: 2026-02-02
- Milestone/Task: M6.5 Plan (计划制定)
- Summary (what changed):
  - 制定 M6.5 完整开发计划（7 项任务：T0 流程改进、T1 checkpoint 全覆盖、T2 session 恢复、T3 auto_apply 持久化、T4 streaming 渲染、T5 ADR 补齐、T6 Review Gate）
  - 每项任务包含根因分析、方案对比、研究/探索要点、Acceptance、Tests、Documentation 段
  - 更新 QUALITY_GATES.md：新增 per-task 文档检查清单、会话交接协议（handoff note）
  - 更新 ROADMAP.md：新增 M6.5 section（背景、任务、依赖图、验收标准、review gate）
  - 分析 M6 开发流程中文档跟踪缺失的根因（详见下方 Notes）
- Evidence (commands run + results): Docs-only change. Created `docs/M6.5_TASK_CARDS.md`. Modified `docs/ROADMAP.md`, `docs/QUALITY_GATES.md`, `docs/PROGRESS.md`.
- Notes/Risks:
  - M6 文档遗漏根因：(1) 质量门仅在 review gate 检查文档，不要求 per-task 更新；(2) task card 模板无 Documentation 段；(3) 会话交接无协议导致新 session 无法感知前 session 遗漏。M6.5-T0 新增的三层机制（per-task checklist + 文档完整性扫描 + handoff note）旨在防止复发。
- Next: Execute M6.5-T0 → T1/T2/T3 (parallel) → T4 → T5 → T6

- Date: 2026-02-02
- Milestone/Task: M6.5 Implementation (T1-T3)
- Summary (what changed):
  - **T0**: QUALITY_GATES.md already contains per-task doc checklist and handoff protocol (confirmed)
  - **T1 Checkpoint 全覆盖**: Migrated `create_checkpoint()` from `agent_runner.py` to `apply.py:apply_proposal()`. System proposals (`game new`, `import`) now create checkpoints, enabling undo. Added 2 tests `TestSystemProposalCheckpoint`.
  - **T2 Session 恢复**: Added `_restore_session()` method to `tui/app.py:on_mount()` that calls `read_session()` and restores last 20 messages to transcript. Updated turn_count from session length. Added 3 tests `TestTUISessionRestore`.
  - **T3 auto_apply 持久化**: Created `core/state.py` module with `load_ui_state()`, `save_ui_state()`, `get_auto_apply()`, `set_auto_apply()`. Modified TUI to load on startup and save on toggle. Added 8 tests `test_state.py`.
- Evidence (commands run + results):
  - `uv run ruff check .` — passed
  - `uv run pytest --tb=short` — 424 passed (13 new tests added)
  - Manual test: `game new --force` → `undo` restores player.json content
- Notes/Risks: T4 (streaming) skipped as optional; T5 (ADR backfill) deferred per plan.
- Next: M6.5-T5 ADR 补齐 → T6 Review Gate

- Date: 2026-02-02
- Milestone/Task: M6.5-T5 (ADR Backfill 0015-0018)
- Summary (what changed):
  - 追溯创建 M6 计划中的 4 份 ADR：
  - **ADR 0015 (Agentic Loop and Tool Calling)**：记录 submit_proposal tool 设计决策、Message/ToolCall/LLMTurnResult 数据结构、chat() Protocol 扩展、agentic loop 终止条件（MAX_AGENTIC_TURNS=20）、tool result 截断策略（5000 字符）
  - **ADR 0016 (Session Log and Context Window)**：记录 per-branch JSONL 存储（`.neonrp/sessions/<branch>.jsonl`）、SessionEntry schema、branch 绑定策略、上下文窗口裁剪（DEFAULT_MAX_TURNS=50）、路径简化说明
  - **ADR 0017 (Agent Dispatcher and Routing)**：记录渐进式路由策略（trigger→tags→priority→fallback）、AgentSpec 扩展字段、`neonrp run` vs `agent run` 职责矩阵、DispatchResult 审计
  - **ADR 0018 (LLM Streaming Contract)**：记录 StreamChunk 数据结构、chat_stream() generator Protocol、tool call 积累逻辑、降级策略、TUI 集成计划（M6.5-T4 skip）
  - 所有 ADR 状态：Accepted。内容基于实际实现（非计划），确保与代码一致。
  - 更新 ROADMAP.md：勾选 T5 checkbox + T4 标记 skipped
- Evidence (commands run + results): Docs-only change. Created `docs/ADRs/0015-agentic-loop-and-tool-calling.md`, `0016-session-log-and-context-window.md`, `0017-agent-dispatcher-and-routing.md`, `0018-llm-streaming-contract.md`.
- Notes/Risks: ADR 内容基于已实现的代码追溯编写，而非设计阶段预写。这偏离了 doc-first 原则，但确保了文档与实现的一致性。
- Next: M6.5-T6 Review Gate

- Date: 2026-02-02
- Milestone/Task: M6.5-T6 (Review Gate)
- Summary (what changed):
  - **Format/Lint**: 2 files reformatted, 2 unused imports removed (test_state.py, test_tui_game_loop.py)
  - **Tests**: 424 passed (pre-review)
  - **Code Review** (`opencode run`): 3 must-fix, 2 should-fix, 2 nice-to-have findings
  - **Must-fix corrections applied**:
    1. `apply.py:136-138`: Use `proposal.branch` instead of `manifest.current_branch` for checkpoint (was writing to wrong branch when applying to non-current branch)
    2. `apply.py:152-160`: Added try/except rollback for world swap failure (restores `.old` if rename fails)
    3. `checkpoint.py:128-136`: Changed `restore_checkpoint` to use `atomic_write_dir` instead of delete+copytree (crash-safe)
  - **Should-fix deferred** (non-blocking): branch existence check added, path traversal guard deferred to M7
  - **Tests after fix**: 424 passed
- Evidence (commands run + results):
  - `uv run ruff format . && uv run ruff check .` — 2 reformatted, 2 fixed
  - `uv run pytest --tb=short` — 424 passed (pre and post fix)
  - `opencode run "..." | Tee-Object reviews/m6.5_review.txt` — review saved
- Notes/Risks: Path traversal guard (should-fix) deferred—current mitigation is proposal validation layer, but apply_proposal caller bypass is not guarded.
- Next: M6.5 Complete. Recommend M7 planning or issue triage.

- Date: 2026-02-02
- Milestone/Task: M7 Plan + Pre-M7 Housekeeping + T0 + T1
- Summary (what changed):
  - **M7 计划制定**：确定 4 大主题（LLM Robustness、MVP Rules Engine、User Docs、TUI Streaming），拆分为 10 项任务（T0-T9），原 M7+ backlog 6 项无限期推迟
  - **Pre-M7 Housekeeping**:
    - H14: `apply.py` 新增 defense-in-depth 路径遍历检查（resolve + relative_to）
    - H15: `skills.py` read_file 工具描述修正为 "Path relative to project root"
    - H16: `ARCHITECTURE.md` 12.2 更新为 M6 agentic loop 描述
  - **M7-T0**: 创建 ADR 0019 (LLM Error Handling and Retry)、ADR 0020 (Game Rules Engine and Entity Schema)、M7_TASK_CARDS.md（9 项详细 task cards）、ROADMAP.md M7 section
  - **M7-T1**: LLM retry + error categories 实现：
    - 新增 `core/llm_errors.py`（5 个错误类型：LLMError、RetryableError、AuthError、InvalidResponseError、BudgetExhaustedError）
    - `llm_openai.py` 新增 `_classify_openai_error()` 错误分类 + `_call_with_retry()` 指数退避重试（1s/2s/4s + jitter，max_retries=3）
    - `chat()` 和 `chat_stream()` 均使用 retry 逻辑
    - `config.py` 新增 `llm.max_retries` 和 `llm.max_context_chars` 配置
    - 24 个新测试（error hierarchy、error classification、retry logic、chat integration、config）
- Evidence (commands run + results):
  - `uv run pytest --tb=short -q` — 448 passed (424 existing + 24 new)
  - `uv run ruff check .` — passed (clean)
- Notes/Risks:
  - M7-T1 retry 逻辑仅在 adapter 层实现，agent_runner 无需感知重试细节
  - `_classify_openai_error` 先检查 Python 内置 ConnectionError/TimeoutError/OSError，再检查 openai SDK 特定异常
  - `max_context_chars` 默认 100000（~25K tokens），budget 执行在 T3 实现
- Next: M7-T2 (Tool argument validation) → T3 → T4 → T5 → T6 → T7 → T8 → T9

- Date: 2026-02-02
- Milestone/Task: M7-T2/T3/T4 — Tool Validation + Token Budget + E2E Harness
- Summary (what changed):
  - **M7-T2 Tool Argument Validation**:
    - `skills.py`: `submit_proposal` ops schema 强化（`op` enum: upsert_text/delete, `path` minLength:1）
    - `skills.py`: 新增 `validate_tool_arguments()` 函数，支持 required/type/minLength/enum 等 JSON Schema 约束
    - `agent_runner.py`: `_execute_tool()` 在调用前先验证参数，无效参数返回可恢复错误（允许 LLM 自行修正）
    - 29 个新测试（`test_tool_validation.py`）
  - **M7-T3 System Prompt Enrichment + Token Budget**:
    - `agent_runner.py`: 新增 `_build_default_system_prompt()` 生成结构化 fallback prompt（包含 tools/rules/entity format/workflow）
    - `agent_runner.py`: 新增 `_estimate_tokens()` 函数（char/4 近似）
    - `agent_runner.py`: agentic loop 新增 token budget 检查（80% 注入警告消息，100% 终止并返回错误）
    - conversation.json 每轮记录 `budget_ratio` 和 `budget_warned`
    - 18 个新测试（`test_token_budget.py`）
  - **M7-T4 Real LLM E2E Test Harness**:
    - 新增 `tests/test_llm_e2e.py`，5 个 E2E 场景（simple read/submit, entity creation, invalid proposal recovery, multi-tool call, budget awareness）
    - `pyproject.toml` 注册 `e2e_llm` marker
    - 测试默认跳过，需设置 `NEONRP_E2E_LLM=1` 启用
- Evidence (commands run + results):
  - `uv run pytest --tb=short -q` — 496 passed, 5 skipped (E2E tests)
  - `uv run ruff check .` — passed (clean)
- Notes/Risks:
  - M7-T2 验证在 `_execute_tool` 层，无效参数返回 tool_result 错误而非异常，允许 LLM 重试
  - M7-T3 budget 使用 `config.llm.max_context_chars`（默认 100000 chars ~25K tokens）
  - M7-T4 E2E 测试仅在配置 API key 时运行，避免 CI 费用
- Next: M7-T5 (Per-kind entity schema) → T6 (Rules engine) → T7 (User docs) → T8 (TUI streaming) → T9

- Date: 2026-02-02
- Milestone/Task: M7-T5 and M7-T6 (Entity Schema + Rules Engine)
- Summary (what changed):
  - M7-T5: Extended `game_entity.schema.json` with per-kind `if/then` blocks for character (hp, max_hp, gold, level, location, inventory), item (value, weight, quantity, effects), and location (connections, npcs, items_available). Fields are RECOMMENDED not required (backward compat). Updated `game new` template with per-kind fields.
  - M7-T6: Created `core/rules.py` with `validate_game_rules()` (hp_non_negative, gold_non_negative, inventory_valid, location_exists) and `resolve_action()` for mechanical outcome resolution (damage, heal, buy, sell, move). Integrated post-staging rules validation in `apply.py`. Added `resolve_action` skill to `skills.py` and updated agent_runner default prompt.
- Evidence (commands run + results): `uv run pytest --tb=short -q` → 532 passed, 5 skipped. 36 new tests: `test_entity_schema.py` (14 tests), `test_rules.py` (22 tests).
- Notes/Risks: Per-kind fields are optional to maintain backward compatibility with existing entities. Rules validation runs after schema validation in staging pipeline.
- Next: M7-T7 (User documentation), M7-T8 (TUI streaming), M7-T9 (Review gate)

- Date: 2026-02-02
- Milestone/Task: M7-T7 — User Documentation
- Summary (what changed):
  - **docs/TUTORIAL.md**: Zero-to-first-turn walkthrough (init → game new → validate → index → agent → run → save → branch → TUI)
  - **docs/CLI_REFERENCE.md**: Complete reference for all 17 CLI commands with synopsis, options, examples, exit codes
  - **docs/TUI_GUIDE.md**: TUI documentation (4-pane layout, keybindings, `:` commands, auto-apply, session persistence)
  - **README.md**: Added TUI section with features/keybindings table, added Documentation links section
  - **examples/starter-game/**: Rich game template with:
    - 3 locations: Neon City Plaza (town), Cyber Market (shop), Shadow Alley (location)
    - 2 NPCs: Zara the Info Broker, Kai the Merchant
    - 1 player: The Wanderer with starting equipment
    - 4 items: Health Potion, Plasma Blade, Energy Shield, Hacking Kit
    - 1 agent: Narrator with cyberpunk system prompt
    - README.md with setup instructions and world map
  - Validated example world: `neonrp validate` → 10 files OK, `neonrp index build` → 10 entities indexed
- Evidence (commands run + results):
  - `uv run ruff check .` — passed (10 lint errors fixed: unused imports, closure variable capture)
  - `uv run ruff format .` — 10 files reformatted
  - `uv run pytest --tb=short -q` — 537 passed
  - Example validation: `cd examples/starter-world && neonrp init && neonrp validate && neonrp index build` — all passed
- Notes/Risks: None.
- Next: M7-T9 (Review Gate) — user will execute `opencode run`

- Date: 2026-02-02
- Milestone/Task: M7-T8 (TUI Streaming)
- Summary (what changed):
  - Added `on_chunk: Callable[[str], None] | None` parameter to `run_agent_agentic()` in `core/agent_runner.py`
  - When `on_chunk` is provided, uses `chat_stream()` instead of `chat()` for incremental token rendering
  - Added streaming passthrough in `core/dispatcher.py`
  - Refactored TUI `_run_agent_query()` to use `run_worker()` with streaming callback and `call_from_thread()` for UI updates
  - Created 6 new tests in `tests/test_streaming.py` covering callback invocation, passthrough, error handling, tool indicators
- Evidence (commands run + results): `uv run pytest --tb=short -q` → 538 passed, 5 skipped. 6 new streaming tests.
- Notes/Risks: Non-streaming providers (no on_chunk) fallback to chat() unchanged. Streaming in TUI requires worker thread for non-blocking UI.
- Next: M7-T7 (User documentation), M7-T9 (Review gate)

- Date: 2026-02-02
- Milestone/Task: M7-T9 (Review Gate)
- Summary (what changed):
  - Ran format/lint + tests (538 passed)
  - Code review findings from prior session (`reviews/M7_review_20260202.md`)
  - All 3 must-fix items already resolved:
    1. `agent_runner.py:566-568` — Fixed `read_globs`/`deny_globs` key mismatch
    2. `apply.py:70-76` — Added `REQUIRED_DENY_GLOBS` enforcement (cannot bypass protected paths)
    3. `branch.py:29-67` — Implemented atomic rename-based swap in `restore_world_from_storage()`
  - Updated M7_review_20260202.md with resolution status
  - Updated ROADMAP.md with all M7-T9 checkboxes marked complete
- Evidence (commands run + results):
  - `uv run pytest --tb=short -q` — 538 passed, 5 skipped
  - Review artifact: `reviews/M7_review_20260202.md` (risk: High → Resolved)
- Review findings:
  - [fixed:prior session] Agentic permissions read_globs/deny_globs key mismatch
  - [fixed:prior session] Default deny_globs bypass via empty list
  - [fixed:prior session] Branch switching delete-then-copy data loss risk
  - [deferred] load only swaps game/ (does not restore event logs/manifest head)
  - [deferred] CLI conventions (--json support, exit codes)
  - [deferred] Permission error messages could include more context
- Notes/Risks: M7 milestone complete. All must-fix items resolved.
- Next: Commit M7 changes

- Date: 2026-02-02
- Milestone/Task: M8-T1 (write_file + edit_file skills)
- Summary (what changed):
  - Added `REQUIRED_DENY_GLOBS` (`.neonrp/**`, `agents/**`) and `check_write_permission()` to `permissions.py` for dual-mode write system
  - Added `atomic_write_text()` to `storage.py` for crash-safe direct file writes
  - Added `write_file` and `edit_file` skill schemas and implementations to `skills.py`
  - Extended `SkillRegistry.__init__` with `direct_write_globs` parameter
  - Updated `agent_runner.py` to pass `direct_write_globs` from agent permissions
  - Updated agent template to include `direct_write_globs: []` in permissions
- Evidence (commands run + results): `uv run pytest --tb=short -q` → 557 passed, 5 skipped. 19 new tests in `test_write_skills.py`.
- Notes/Risks: REQUIRED_DENY_GLOBS always override direct_write_globs for safety. Paths not in direct_write_globs get helpful error guiding to submit_proposal.
- Next: M8-T2 (glob + grep skills)

- Date: 2026-02-02
- Milestone/Task: M8-T2 (glob + grep skills)
- Summary (what changed):
  - Added `glob` skill schema and implementation to `skills.py` for listing files and directories
  - Added `grep` skill schema and implementation to `skills.py` for searching file contents
  - Integrated `glob` and `grep` into `SkillRegistry` and `agent_runner`
  - Updated agent template to include `glob` and `grep` in default permissions
- Evidence (commands run + results): `uv run pytest --tb=short -q` → 572 passed, 5 skipped. 15 new tests in `test_read_skills.py`.
- Notes/Risks: `glob` and `grep` respect `REQUIRED_DENY_GLOBS` and agent's `read_globs` for safety. `grep` has a line limit to prevent excessive output.
- Next: M8-T3 (ask_user skill)

- Date: 2026-02-02
- Milestone/Task: M8-T3 (ask_user skill)
- Summary (what changed):
  - Added `ask_user` skill schema with question and optional options array
  - Implemented sentinel protocol in `_execute_tool` (returns 3-tuple with ask_user_data)
  - Added `on_ask_user` callback to `run_agent_agentic` and `dispatcher.dispatch()`
  - Loop detects sentinel, calls callback, injects user response as tool result
- Evidence (commands run + results): `uv run pytest --tb=short -q` → 582 passed, 5 skipped. 10 new tests in `test_ask_user.py`.
- Notes/Risks: TUI/CLI rendering is callback-based (callers provide the callback). No callback = error returned.
- Next: M8-T4 (task tool + sub-agent)

- Date: 2026-02-02
- Milestone/Task: M8-T4 (task tool + sub-agent)
- Summary (what changed):
  - Added `max_sub_agent_depth` to `ProjectConfig` (default 2)
  - Added `task` schema to SKILL_SCHEMAS (agent_id, prompt, resume_run_id)
  - Added `SubAgentState` dataclass for state serialization
  - Updated `_execute_tool` to return 4-tuple (result, proposal, ask_user_data, task_data)
  - Implemented sub-agent dispatch in tool loop with recursive `run_agent_agentic` call
  - Added depth filtering: task tool excluded at depth >= max_depth - 1
- Evidence (commands run + results): `uv run pytest --tb=short -q` → 591 passed, 5 skipped. 9 new tests in `test_sub_agent.py`.
- Notes/Risks: Resume functionality not yet implemented (state save/load). Sub-agents don't auto-apply proposals.
- Next: M8-T5 (per-agent LLM)

- Date: 2026-02-02
- Milestone/Task: M8-T5 (per-agent LLM configuration)
- Summary (what changed):
  - Added `ProviderConfig` dataclass in `core/config.py` with provider, model, temperature, max_output_tokens, seed, base_url, api_key_env fields
  - Added `providers` registry to `ProjectConfig` for named configurations (fast, strong, local, etc.)
  - Added `resolve_provider()` for priority-based resolution: CLI > agent inline > provider_ref > global
  - Added `get_adapter_from_config()` factory in `core/llm.py` to create adapters from ProviderConfig
  - Updated both `run_agent()` and `run_agent_agentic()` in `agent_runner.py` to use new resolution
  - Updated `agent show` command to display per-agent LLM configuration
  - Updated streaming tests to mock `get_adapter_from_config`
- Evidence (commands run + results): `python -m pytest tests/ -q` → 614 passed, 5 skipped. 18 new tests in `test_per_agent_llm.py`.
- Notes/Risks: Priority order is CLI override > agent inline config > agent provider_ref > global config. Unknown provider_ref falls back to global.
- Next: M8-T6 (integration + orchestrator example)

- Date: 2026-02-03
- Milestone/Task: M8-T6 (integration + orchestrator example)
- Summary (what changed):
  - Created `examples/multi-agent/` with orchestrator and narrator agents demonstrating M8 features
  - Orchestrator uses `strong` provider via `provider_ref`, narrator uses `fast` provider
  - Narrator has `direct_write_globs: ["game/lore/**"]` for autonomous lore writing
  - Created `tests/test_m8_integration.py` with 10 tests covering:
    - Provider registry resolution (3 tests)
    - Task tool availability at depth 0 (1 test)
    - ask_user callback integration (2 tests)
    - Depth limit enforcement (1 test)
    - Mixed write modes (2 tests)
    - Full pipeline stub (1 test)
- Evidence (commands run + results): `python -m pytest tests/ -q` → 624 passed, 5 skipped
- Notes/Risks: Task tool only available at depth 0; sub-agents cannot call task. Direct writes only work for paths in direct_write_globs.
- Next: M8 review gate

- Date: 2026-02-03
- Milestone/Task: M8-T7 (Review Gate)
- Summary (what changed):
  - Ran `opencode run` code review → saved to `reviews/M8_review_20260203.md`
  - Fixed must-fix #1: Absolute path escape in file skills → Added rejection in `normalize_path()` for Unix (/path) and Windows (C:\path) absolute paths
  - Fixed must-fix #2: `max_sub_agent_depth` unused → Changed `run_agent_agentic()` to read from config when not explicitly passed
  - Updated `test_permissions.py` with new absolute path rejection tests
- Evidence (commands run + results): `python -m pytest tests/ -q` → 626 passed, 5 skipped. `uv run ruff check .` → All checks passed
- Review findings:
  - [fixed] Absolute path escape in direct file skills (src/neonrp/core/permissions.py:20-44)
  - [fixed] `max_sub_agent_depth` unused in orchestration (src/neonrp/core/agent_runner.py:488,561-563)
  - [deferred:M9] Permission error payloads lack context (should-fix, will enhance in M9)
  - [accepted] Nice-to-have: surface max_depth in logs — low priority for now
- Notes/Risks: Existing code that relied on leading slash stripping will now fail with "Absolute paths not allowed" - this is intentional security hardening.
- Next: M8 complete

- Date: 2026-02-06
- Milestone/Task: M9-T1/T2/T3/T4 (Conversation foundation)
- Summary (what changed):
  - Added `src/neonrp/core/conversation.py` with `run_conversation_turn()` and `ConversationSession` (multi-turn loop, mode handling for build/sandbox/play, TodoWrite/Skill tool handling, file-modified tracking, auto event append, checkpoint creation, session persistence hooks)
  - Added `src/neonrp/core/todo.py` (`TodoManager`: validation, snapshot, render)
  - Added `src/neonrp/core/skill_loader.py` (`SkillLoader`: `skills/*/SKILL.md` frontmatter parsing, descriptions, content injection)
  - Added `src/neonrp/core/prompts.py` (`build_system_prompt()` mode-aware templates)
  - Added preset skills: `skills/combat/SKILL.md`, `skills/world-building/SKILL.md`, `skills/narrative/SKILL.md`
  - Added tests: `tests/test_conversation.py`, `tests/test_todo.py`, `tests/test_skill_loader.py`, `tests/test_prompts.py`
  - Fixed pre-existing config parsing bug: ignore non-dict entries under `providers` (supports `_comment` in default template)
  - Added regression test in `tests/test_config.py::test_provider_comments_are_ignored`
- Evidence (commands run + results):
  - `.venv\\Scripts\\python -m ruff check src/neonrp/core/config.py src/neonrp/core/todo.py src/neonrp/core/skill_loader.py src/neonrp/core/prompts.py src/neonrp/core/conversation.py tests/test_config.py tests/test_todo.py tests/test_skill_loader.py tests/test_prompts.py tests/test_conversation.py` → All checks passed
  - `.venv\\Scripts\\python -m pytest tests/test_config.py tests/test_agent_runner.py tests/test_todo.py tests/test_skill_loader.py tests/test_prompts.py tests/test_conversation.py tests/test_skills.py tests/test_session.py tests/test_tui_commands.py -q` → 111 passed
  - `.venv\\Scripts\\python -m ruff check .` → All checks passed
  - `.venv\\Scripts\\python -m pytest -q` → 652 passed, 5 skipped
- Notes/Risks:
  - `task` tool in conversation mode currently returns explicit "not supported" error (sub-agent orchestration remains on legacy `agent_runner` path)
  - New TUI (`app_v2.py`) and CLI slash command wiring (`/mode`, `/clear`, `/files`, `/skills`) are still pending in M9-T5/T6
- Next: Implement M9-T5 (new conversational TUI) and M9-T6 (default TUI wiring + slash commands)

- Date: 2026-02-07
- Milestone/Task: M9-T5/T6 (New TUI v2 + CLI Integration)
- Summary (what changed):
  - Created `src/neonrp/tui/app_v2.py` with Claude Code style single-pane conversational TUI (~580 lines)
    - StatusBarV2: project name, branch, event count, mode badge, agent name
    - ConversationView: streaming text, tool use indicators, todo display, skill loading indicators
    - InputAreaV2: input field with mode badge
    - Worker pattern for non-blocking conversation turns with streaming callbacks
    - Slash commands: /mode, /clear, /files, /skills, /apply, /undo, /save, /help
  - Renamed `src/neonrp/tui/app.py` → `app_legacy.py` for backward compatibility
  - Updated `src/neonrp/commands/tui.py`: new TUI as default, added `--legacy` flag
  - Updated test imports in `test_tui_game_loop.py` and `test_state.py` to use `app_legacy`
  - Added `ConversationSession.get_messages()` method for TUI session restore
- Evidence (commands run + results):
  - `.venv\Scripts\python -m ruff format src/neonrp/tui/app_v2.py src/neonrp/commands/tui.py` → 2 files reformatted
  - `.venv\Scripts\python -m ruff check .` → All checks passed
  - `.venv\Scripts\python -m pytest -q` → 652 passed, 5 skipped
- Notes/Risks:
  - TUI streaming callback integration with LLM layer is complete
  - Skill loading indicators show in conversation view but skill content injection is handled by conversation engine
  - `task` tool still returns "not supported" in conversation mode (sub-agent orchestration via legacy agent_runner)
- Next: M9-T7 Review Gate (docs update, code review)

- Date: 2026-02-07
- Milestone/Task: M9-T7 (Review Gate)
- Summary (what changed):
  - Completed code review: `reviews/M9_review_20260207.md` created with risk assessment (Medium)
  - Applied must-fix items:
    1. Fixed `_restore_session()` in `app_v2.py` to actually render previous messages
    2. Added error handling to `_get_event_count()` for file operations
  - Applied should-fix items:
    3. Enhanced TodoManager validation error to include actual invalid value
  - Updated documentation: TUTORIAL.md (Step 11), CLI_REFERENCE.md (tui command)
- Evidence (commands run + results):
  - `python -m ruff check .` → All checks passed
  - `python -m pytest -q` → 652 passed, 5 skipped
  - Code review saved to `reviews/M9_review_20260207.md`
- Notes/Risks:
  - Risk level: Medium (UI/UX issues, not data safety)
  - M9 milestone complete with all 7 tasks finished
- Next: Consider M10 planning or address deferred items

- Date: 2026-02-08
- Milestone/Task: M10-T5 + M10-T6（TUI 稳定性与体验打磨）
- Summary (what changed):
  - 修复发送消息崩溃：`app_v2.py` 中 `run_worker(..., text=...)` 参数不兼容导致 `TypeError`，改为兼容调用路径并补充回归覆盖。
  - 完成对话主链路可观测性改造：新增等待/流式状态提示、Thinking 渲染、工具调用状态与结果摘要（单行 + 展开详情）。
  - 完成工具调用展示稳定性修复：流式阶段工具项顺序稳定，避免 AI 输出期间工具区抖动/乱序。
  - 完成对话渲染分段化与样式优化：用户输入、Thinking、工具调用、Narrator 输出分层渲染；代码块高亮保留，去除冗余蓝色边框，行距与段距重新调优。
  - 完成输入交互增强：`/` 命令候选可用、上下方向键历史记录可回放，输入区与主对话区布局截断问题修复。
  - 模型配置体验改进：支持用户级配置落盘（`~/.neonrp/config.json`），未配置端点/API Key 时给出明确引导（`/auth set` / `/auth show`）。
  - 补齐测试覆盖：新增/更新 `tests/test_app_v2.py` 与 `tests/test_tui_commands.py` 用例，覆盖工具结果渲染细节与回调签名。
- Evidence (commands run + results):
  - `uv run ruff check src/neonrp/tui/app_v2.py src/neonrp/core/conversation.py src/neonrp/core/llm_openai.py tests/test_app_v2.py tests/test_tui_commands.py` → All checks passed
  - `uv run pytest tests/test_app_v2.py tests/test_tui_commands.py -q` → 113 passed
  - `uv run pytest -q` → 752 passed, 5 skipped
- Notes/Risks:
  - Textual 原生控件对“网页式鼠标拖拽选择”支持有限；当前方案在可读性、流式反馈、复制能力之间做了工程折中。
  - Thinking 内容展示依赖上游 provider 输出 `reasoning_content/reasoning`，非所有模型都保证返回。
- Next:
  - 继续收敛 transcript 的“高保真渲染 + 自然鼠标选择”体验（必要时评估自定义渲染层或替代控件）。

- Date: 2026-02-09
- Milestone/Task: M10-T7（TUI 斜杠命令交互对齐 Claude Code）
- Summary (what changed):
  - 斜杠命令建议框行为重写，对齐 Claude Code 交互模式：
    1. Enter 选中即执行（不再两步 fill→submit），popup 立即消失
    2. Tab 补全后 popup 消失（修复 Textual async `Input.Changed` 重新触发的 race condition）
    3. Tab 补全自动追加空格，方便继续输入参数
    4. 有子命令的命令（如 `/auth`）Tab 后弹出子命令建议
    5. 子命令完整且用户输入额外参数时（如 `/auth set xxx`），popup 自动隐藏
    6. Enter 仅在用户文本是建议前缀时应用补全，否则按原文提交
  - 新增 `SlashCommandSuggester`（基于 Textual `Suggester` API），实现输入框内 ghost text 提示：
    - 部分命令名：`/mod` → 灰色 ghost `e [name]`
    - 完整命令 + 空格：`/mode ` → ghost `[name]`
    - 子命令补全：`/auth s` → ghost `et <provider> [base_url] [model] [api_key]`
    - 完整子命令 + 空格：`/auth set ` → ghost `<provider> [base_url] [model] [api_key]`
  - `commands.py` COMMANDS 字典新增 `sub_args_hint` 字段，为 auth/config/sandbox/agent 子命令提供参数提示
  - 修复 `_set_input_text` 的 `_suppress_input_change` flag 时序 bug（flag 在 async event 前同步重置导致 popup 闪回）
  - 更新 `tests/test_app_v2.py` 断言（Tab 补全现在带尾随空格）
- Evidence (commands run + results):
  - `uv run pytest tests/ -x -q -k "slash or tui"` → 51 passed
  - `uv run pytest tests/ -q` → 752 passed, 5 skipped
- Notes/Risks:
  - Textual `Input.placeholder` 仅在值为空时显示，无法用于 inline hint；改用原生 `Suggester` API 实现 ghost text
  - `_suppress_input_change` 现在由 `on_input_changed` 消费重置（而非 `_set_input_text` 同步重置），解决 Textual async message 时序问题
- Next:
  - 继续 TUI 体验打磨

- Date: 2026-02-09
- Milestone/Task: M10-T8（覆盖率补测 + 真实端点 E2E 校验）
- Summary (what changed):
  - 基于 `reviews/coverage_report_20260209.md` 补充核心缺口测试，新增 4 个测试文件：
    - `tests/test_retrieval.py`（`core/retrieval.py` 评分/排序/截断/异常回退）
    - `tests/test_conversation_edges.py`（`core/conversation.py` 早退分支、流式异常、ask_user/task fallback、max_turns 等）
    - `tests/test_tui_suggestions.py`（`tui/suggestions.py` 的 Textual `run_test()` 交互覆盖）
    - `tests/test_llm_real_endpoint.py`（读取 `~/.neonrp/config.json`，走真实 `base_url` 端点做 chat/chat_stream）
  - 真实端点测试默认受 `NEONRP_E2E_LLM=1` 控制，避免影响常规 CI。
  - 目标模块覆盖率显著提升（局部报告）：
    - `core/conversation.py`: 79% → 99%
    - `core/retrieval.py`: 33% → 95%
    - `tui/suggestions.py`: 0% → 99%
- Evidence (commands run + results):
  - `uv run pytest tests/test_retrieval.py tests/test_conversation_edges.py tests/test_tui_suggestions.py -q` → 35 passed
  - `uv run pytest --cov=neonrp.core.conversation --cov=neonrp.core.retrieval --cov=neonrp.tui.suggestions --cov-report=term-missing tests/test_conversation.py tests/test_conversation_edges.py tests/test_retrieval.py tests/test_tui_suggestions.py -q` → 46 passed
  - `uv run pytest -q` → 803 passed, 7 skipped
  - `$env:NEONRP_E2E_LLM='1'; uv run pytest tests/test_llm_real_endpoint.py -q` → 2 passed
- Notes/Risks:
  - 全仓总覆盖率尚未重跑（当前提升值为目标模块局部覆盖率）；后续需执行全量 `--cov=neonrp` 复核总盘子。
  - `core/llm_openai.py` 仍以集成测试为主，不宜强行做高比例 mock 单测替代真实链路。
- Next:
  - 继续按 coverage 报告补 `commands/run.py`、`commands/branch.py`、`commands/agent.py` 和 `commands/validate.py` 的低覆盖路径。


## M10.1 -- TUI & Agent Improvements (2026-02-10)

### M10.1-T1: ESC Interrupt for In-Flight Calls
- Status: Done
- Added cancel_event to run_conversation_turn() with checks at loop start and before each tool.
- Added cancel() / is_cancelled to ConversationSession.
- TUI on_key intercepts ESC when LLM is running, signals cancellation.
- Files: core/conversation.py, tui/app_v2.py

### M10.1-T2: Configurable Max Tool Call Rounds
- Status: Done
- Added max_tool_rounds: int = 20 to TUIConfig, wired through parser/overrides/template.
- ConversationSession reads from config when max_turns not explicitly passed.
- Files: core/config.py, core/conversation.py

### M10.1-T3: Incremental History Saving (Claude Code Style)
- Status: Done
- Added on_message_persist callback to run_conversation_turn().
- Each message persisted to JSONL immediately as it arrives.
- System prompts no longer persisted (rebuilt each turn).
- Files: core/conversation.py

- Evidence: python -m pytest --tb=short -q -> 864 passed, 7 skipped

## M10.1 -- TUI & Agent Improvements (2026-02-10)

### M10.1-T1: ESC Interrupt for In-Flight Calls
- Status: Done
- Added cancel_event to run_conversation_turn() with checks at loop start and before each tool.
- Added cancel() / is_cancelled to ConversationSession.
- TUI on_key intercepts ESC when LLM is running, signals cancellation.
- Files: core/conversation.py, tui/app_v2.py

### M10.1-T2: Configurable Max Tool Call Rounds
- Status: Done
- Added max_tool_rounds: int = 20 to TUIConfig, wired through parser/overrides/template.
- ConversationSession reads from config when max_turns not explicitly passed.
- Files: core/config.py, core/conversation.py

### M10.1-T3: Incremental History Saving (Claude Code Style)
- Status: Done
- Added on_message_persist callback to run_conversation_turn().
- Each message persisted to JSONL immediately as it arrives.
- System prompts no longer persisted (rebuilt each turn).
- Files: core/conversation.py

- Evidence: python -m pytest --tb=short -q -> 864 passed, 7 skipped

- Date: 2026-02-10
- Milestone/Task: TUI 滚动回归修复与代码收敛（M10.1 后续）
- Summary (what changed):
  - 修复 `ConversationView.watch_scroll_y`：恢复调用 `super().watch_scroll_y(old_value, new_value)`，确保 Textual 默认滚动簿记（滚动条位置同步与滚动刷新）正常执行。
  - 解决现象：LLM 输出结束后滚动条固定在顶部/底部、鼠标滚轮与滑块拖拽失效。
  - 完成代码收敛：移除本次排障期间新增的临时滚动诊断代码，仅保留必要修复逻辑。
- Evidence (commands run + results):
  - `uv run pytest -q tests/test_app_v2.py` → 143 passed
  - 现场复测（`uv run --project .. neonrp tui --verbose`）确认滚动恢复正常。
- Notes/Risks:
  - 滚动行为依赖 Textual 基础机制，后续如继续改写 `watch_scroll_y`，必须保留父类调用以避免同类回归。
- Next:
  - 将滚动相关回归点固化到后续 TUI 改动 checklist（避免再次遗漏父类滚动逻辑）。

- Date: 2026-02-10
- Milestone/Task: OpenAI 兼容端点增强 + ask_user 交互可见性修复
- Summary (what changed):
  - 配置层新增 `extra` 透传能力：支持在 `models.<name>.extra` 写入 provider-specific JSON（如 OpenRouter `reasoning`）。
  - OpenAI 兼容适配器改为“已知参数走顶层，未知参数走 `extra_body`”，修复 `reasoning` 顶层参数触发的 SDK `unexpected keyword argument` 报错。
  - 会话重试策略升级：针对可重试错误按固定退避 `2s -> 7s -> 15s -> 30s` 自动重试，超过后终止。
  - 流式错误可重试标记补全：`chat_stream` 网络中断等错误可正确回传 `retryable`，由会话层接管重试。
  - TUI ask_user 体验增强：用户最终选择会显示在对话区，并在会话恢复时从历史重建；工具卡片摘要显示 `selected: ...`。
- Evidence (commands run + results):
  - `uv run pytest -q tests/test_config.py tests/test_per_agent_llm.py tests/test_llm_openai_extra.py` → 63 passed
  - `uv run pytest -q tests/test_llm.py tests/test_llm_streaming.py tests/test_llm_retry.py` → 71 passed
  - `uv run pytest -q tests/test_conversation_edges.py tests/test_llm_streaming.py tests/test_llm_retry.py` → 78 passed
  - `uv run pytest -q tests/test_conversation.py tests/test_conversation_edges.py tests/test_app_v2.py` → 216 passed
  - `uv run pytest -q tests/test_m8_integration.py tests/test_ask_user.py` → 20 passed
- Notes/Risks:
  - `extra` 透传能力面向 OpenAI-compatible 链路；Anthropic 原生 SDK 路径不使用该字段。
  - 固定退避策略会延长弱网络下单次 turn 的等待时间，但可显著降低偶发断连导致的失败率。
- Next:
  - 继续补充文档示例，统一新旧配置格式说明（以 `models + llm.model_ref` 为主）。

- Date: 2026-02-16
- Milestone/Task: M11.1（Embedding Retrieval + Reliability Hardening）
- Summary (what changed):
  - 执行并闭环 `reviews/code_review_20260216.md` 的问题清单，覆盖 apply/permissions/save-load/CLI 行为一致性等关键链路。
  - 新增向量检索基础设施：`src/neonrp/core/embedding.py`（adapter、`VectorIndex`、`embeddings.json` 持久化）。
  - `src/neonrp/core/retrieval.py` 的 `retrieve_context` 支持混合检索：fuzzy + vector；向量调用异常自动降级为 fuzzy-only。
  - `src/neonrp/commands/index.py` 的 `index build` 在 `embedding.enabled=true` 时默认预计算向量。
  - embedding 配置兼容简化：`embedding.model_ref` 可从 `models` 继承 provider/model/base_url/api_key；支持仅写 `enabled + model_ref`。
  - 补充/扩展回归测试：`tests/test_embedding.py`、`tests/test_retrieval_fuzzy.py` 及相关配置/检索/索引测试。
- Evidence (commands run + results):
  - `uv run pytest tests/test_config.py tests/test_embedding.py -q` → 59 passed
  - `uv run pytest tests/test_retrieval.py tests/test_retrieval_fuzzy.py tests/test_indexing.py -q` → 56 passed
- Notes/Risks:
  - 向量检索为可选能力，默认仍是 fuzzy-only；embedding 服务不可用时不阻断主流程。
  - 本地运行需通过 `uv run ...`（或等效方式）确保优先使用仓库源码，而非全局 site-packages 安装版本。
- Next:
  - 增加一条真实 embedding endpoint 的可选 E2E（受环境变量门控）以覆盖端到端调用链。

- Date: 2026-02-17
- Milestone/Task: M12（Delegation Reliability + Template Expansion）阶段性补全
- Summary (what changed):
  - 确认 `my-rpg/` 在 `.gitignore` 中（本地可用但默认不纳入 Git 跟踪），并完成 `my-rpg/agents` 现状复核。
  - 新增 `active-agent` 协议模块：`src/neonrp/core/active_agent.py`，包含 read/get/write/clear/validate。
  - 会话层接入 active-agent 锁路由：`ConversationSession.send()` 在 narrator + build/play 下可直接路由到 active sub-agent；识别离开意图时自动清锁。
  - 对话循环加入 narrator 运行时 guardrail：阻止 narrator 对 `game/**` 的 direct write/edit/delete 与 `resolve_action`，并返回“必须 task 委托”错误。
  - `game new` 默认模板扩充：新增 `meta/active-agent.json`、item/location/dungeon 样例，以及 town-agent/dungeon-agent 自动生成。
  - 新增/补充测试：
    - `tests/test_active_agent.py`
    - `tests/test_conversation.py`（active-agent 会话路由/清锁）
    - `tests/test_conversation_edges.py`（guardrail + dispatch 状态落盘）
    - `tests/test_game_cli.py`（模板与 narrator 委托规则断言）
- Evidence (commands run + results):
  - `uv run pytest tests/test_active_agent.py tests/test_conversation.py tests/test_conversation_edges.py tests/test_game_cli.py -q` → 92 passed
  - `uv run ruff check src/neonrp/core/conversation.py src/neonrp/core/active_agent.py src/neonrp/commands/game.py tests/test_active_agent.py tests/test_conversation.py tests/test_conversation_edges.py tests/test_game_cli.py` → All checks passed
- Notes/Risks:
  - `my-rpg/` 仍是 ignore 状态，内容变更不会体现在 Git diff；需要靠人工复核或移除 ignore 才能纳入版本审计。
  - active-agent “离开意图”使用关键词启发式，复杂语义仍可能误判，后续可改为显式状态机/规则判定。
- Next:
  - 补 M12-T1/T8：增加 `my-rpg` 多回合脚本化 E2E 与 delegation 指标统计。

- Date: 2026-02-23
- Milestone/Task: M12（Sticky Delegation 回路收敛 + 回合上限策略统一）
- Summary (what changed):
  - `run_conversation_turn()` 增加 sticky 成功短路：当 narrator 的 `task` 返回 `delegation_mode=sticky` 且成功时，直接返回子代理文本，不再在同一回合追加 narrator 二次 LLM 请求。
  - 子代理 dispatch 取消 agent 级 `max_task_turns` 约束：统一使用会话/配置层 `max_turns`，并在检测到 agent 配置残留时输出 debug 提示（仅提示，不生效）。
  - 默认模板中的 `town-agent` / `dungeon-agent` 删除 `max_task_turns` 字段，避免和会话级上限产生歧义。
  - 补充回归测试，覆盖 sticky 短路行为与 agent 级回合上限忽略策略。
- Evidence (commands run + results):
  - `uv run pytest -q tests/test_conversation_edges.py` → 63 passed
- Notes/Risks:
  - 当前 sticky 短路只解决“同回合 narrator 复入”问题；域切换与 sticky 退出条件仍依赖后续状态机规则补齐。
  - `max_task_turns` 改为忽略后，旧项目若依赖该字段需要迁移提示（兼容策略文档待补）。
- Next:
  - 继续推进 Context Pack + registry 在 play 路径的验收指标（无效探测率、平均 tool rounds、平均首 token 延迟）。

