# NeonRP CLI Reference

Complete reference for all NeonRP CLI commands.

## Global Options

All commands support:
- `--help`: Show command help

## Commands Overview

| Command | Description |
|---------|-------------|
| `init` | Initialize a new NeonRP project |
| `run` | Run a query through the agent dispatcher |
| `save` | Save game state to a snapshot |
| `load` | Restore game state from a snapshot |
| `branch` | Create or switch branches |
| `undo` | Undo the last change |
| `redo` | Redo a previously undone change |
| `validate` | Validate game data against schema |
| `index` | Manage entity index |
| `find` | Search entities |
| `context` | Get ranked context for a query |
| `agent` | Agent lifecycle commands |
| `import` | Import external content |
| `game` | Game scaffolding commands |
| `sandbox` | Sandbox management |
| `replay` | Replay and determinism verification |
| `tui` | Launch Terminal User Interface |

---

## init

Initialize a new NeonRP project in the current directory.

### Synopsis

```bash
neonrp init
```

### Description

Creates the `.neonrp/` directory structure with:
- `manifest.json`: Project state and entity index
- `config.json`: LLM provider configuration template

After `init`, TUI build mode can already operate in the directory. Packaged builtin skills are available even before local `skills/` files or `agents/` are created. Use `game new` only when you want the default starter world and play-agent scaffold.

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |

### Example

```bash
mkdir my-game && cd my-game
neonrp init
```

---

## run

Run a query through the agent dispatcher.

### Synopsis

```bash
neonrp run <QUERY> [OPTIONS]
```

### Arguments

| Argument | Description |
|----------|-------------|
| `QUERY` | The query/instruction to process |

### Options

| Option | Short | Description |
|--------|-------|-------------|
| `--agent` | `-a` | Specific agent ID to run |
| `--provider` | `-p` | LLM provider override |
| `--fixture` | | Path to fixture file for stub provider |
| `--apply` | | Apply the proposal after generation |
| `--agentic` | | Use multi-turn agentic loop |
| `--json` | | Output as JSON |

### Description

The dispatcher selects an agent based on:
1. Explicit `--agent` flag (direct selection)
2. Trigger patterns in `agent.json` (regex matching)
3. Tags in `agent.json` (keyword matching)
4. Priority (when multiple agents match)

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (not initialized, agent not found, etc.) |

### Examples

```bash
# Basic query
neonrp run "look around"

# Specify agent
neonrp run "create a quest" --agent narrator

# With auto-apply
neonrp run "add an item" --apply

# Multi-turn agentic mode
neonrp run "build a dungeon" --agentic --apply

# JSON output
neonrp run "describe the town" --json
```

---

## save

Save the current game state to a snapshot.

### Synopsis

```bash
neonrp save [NAME] [OPTIONS]
```

### Arguments

| Argument | Description |
|----------|-------------|
| `NAME` | Optional snapshot name (default: timestamp) |

### Options

| Option | Description |
|--------|-------------|
| `--json` | Output as JSON |

### Description

Creates a complete snapshot including:
- `game/` directory copy
- `meta.json` (save metadata)
- `events.jsonl` (event log copy)

Snapshots are stored in `.neonrp/saves/<name>/`.

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (game data not found, snapshot exists, etc.) |

### Examples

```bash
# Auto-named snapshot
neonrp save

# Named snapshot
neonrp save before-boss-fight

# JSON output
neonrp save checkpoint-1 --json
```

---

## load

Restore the game state from a snapshot.

### Synopsis

```bash
neonrp load <SNAPSHOT_ID>
```

### Arguments

| Argument | Description |
|----------|-------------|
| `SNAPSHOT_ID` | The snapshot name to restore |

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Snapshot not found |

### Example

```bash
neonrp load before-boss-fight
```

---

## branch

Create a new branch or switch to an existing branch.

### Synopsis

```bash
neonrp branch <NAME>
```

### Arguments

| Argument | Description |
|----------|-------------|
| `NAME` | Branch name to create or switch to |

### Description

- If branch doesn't exist: creates new branch from current state
- If branch exists: switches to that branch

Branch data is stored in `.neonrp/branches/<name>/`.

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Not initialized |

### Examples

```bash
# Create new branch
neonrp branch try-stealing-route

# Switch to existing branch
neonrp branch main
```

---

## undo

Undo the last change by restoring from checkpoint.

### Synopsis

```bash
neonrp undo
```

### Description

Restores the game state to the previous checkpoint and decrements the head event pointer.

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Nothing to undo or not initialized |

### Example

```bash
neonrp undo
```

---

## redo

Redo a previously undone change.

### Synopsis

```bash
neonrp redo
```

### Description

Restores the game state to the next checkpoint after an undo operation.

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Nothing to redo |

### Example

```bash
neonrp redo
```

---

## validate

Validate game data against schema and constraints.

### Synopsis

```bash
neonrp validate [OPTIONS]
```

### Options

| Option | Description |
|--------|-------------|
| `--json` | Output as JSON |

### Description

Validates all JSON files in `game/` against:
1. JSON schema (`game_entity.schema.json`)
2. Game rules (hp >= 0, gold >= 0, valid locations, etc.)

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Validation passed |
| 1 | Validation failed |
| 2 | System error (schema missing, IO error) |

### Examples

```bash
# Human-readable output
neonrp validate

# JSON output for CI
neonrp validate --json
```

---

## index

Manage entity index in manifest.

### Synopsis

```bash
neonrp index <SUBCOMMAND> [OPTIONS]
```

### Subcommands

#### index build

Full rebuild of entity index from `game/` directory.

```bash
neonrp index build [--json]
```

#### index update

Incremental update of entity index (only changed files).

```bash
neonrp index update [--json]
```

### Options

| Option | Description |
|--------|-------------|
| `--json` | Output as JSON |

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 2 | Not initialized |

### Examples

```bash
# Full rebuild
neonrp index build

# Incremental update
neonrp index update --json
```

---

## find

Find entities by id, tag, kind, or keyword.

### Synopsis

```bash
neonrp find [QUERY] [OPTIONS]
```

### Arguments

| Argument | Description |
|----------|-------------|
| `QUERY` | Optional keyword to search |

### Options

| Option | Description |
|--------|-------------|
| `--id` | Exact id match |
| `--tag` | Filter by tag |
| `--kind` | Filter by kind |
| `--json` | Output as JSON |

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 2 | Not initialized |

### Examples

```bash
# List all entities
neonrp find

# Keyword search
neonrp find "sage"

# Filter by kind
neonrp find --kind npc

# Filter by tag
neonrp find --tag quest-giver

# Exact id match
neonrp find --id old-sage

# Combined filters
neonrp find "town" --kind location --json
```

---

## context

Find relevant context for a query with ranked results.

### Synopsis

```bash
neonrp context <QUERY> [OPTIONS]
```

### Arguments

| Argument | Description |
|----------|-------------|
| `QUERY` | The query to find context for |

### Options

| Option | Short | Description |
|--------|-------|-------------|
| `--limit` | `-n` | Maximum number of results (default: 10) |
| `--json` | | Output as JSON |

### Description

Returns top-N entities ranked by relevance with:
- Score breakdown (tags, name, summary, content)
- Snippets for each result

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 2 | Not initialized |

### Examples

```bash
# Basic context retrieval
neonrp context "starting area"

# Limit results
neonrp context "neon city" --limit 5

# JSON output
neonrp context "quest giver" --json
```

---

## agent

Agent lifecycle commands.

### Synopsis

```bash
neonrp agent <SUBCOMMAND> [OPTIONS]
```

### Subcommands

#### agent new

Create a new agent.

```bash
neonrp agent new <AGENT_ID>
```

Creates `agents/<agent_id>/` with:
- `agent.json`: Agent configuration
- `system.md`: System prompt template

#### agent list

List all agents in the project.

```bash
neonrp agent list [--json]
```

#### agent show

Show details of an agent.

```bash
neonrp agent show <AGENT_ID> [--json]
```

#### agent path

Print the directory path of an agent.

```bash
neonrp agent path <AGENT_ID>
```

#### agent apply

Apply a proposal for an agent.

```bash
neonrp agent apply <AGENT_ID> --proposal <PATH> [--dry-run] [--json]
```

| Option | Description |
|--------|-------------|
| `--proposal` | Path to proposal.json (required) |
| `--dry-run` | Show what would happen without applying |
| `--json` | Output as JSON |

#### agent logs

Show recent agent run logs.

```bash
neonrp agent logs [--tail N] [--json]
```

| Option | Description |
|--------|-------------|
| `--tail` | Number of recent runs to show (default: 10) |
| `--json` | Output as JSON |

#### agent context

Retrieve context for an agent using a query.

```bash
neonrp agent context <AGENT_ID> --query <QUERY> [--limit N] [--output PATH] [--json]
```

| Option | Short | Description |
|--------|-------|-------------|
| `--query` | `-q` | Query for context retrieval (required) |
| `--limit` | `-n` | Max context items (default: 8) |
| `--output` | `-o` | Path to write input.json |
| `--json` | | Output as JSON |

#### agent run

Run an agent with LLM to generate and optionally apply a proposal.

```bash
neonrp agent run <AGENT_ID> --query <QUERY> [OPTIONS]
```

| Option | Description |
|--------|-------------|
| `--query`, `-q` | Query/instruction for the agent (required) |
| `--provider` | LLM provider (default: from config or 'stub') |
| `--fixture` | Proposal fixture file for stub provider |
| `--apply` | Apply the proposal after preview |
| `--json` | Output as JSON |

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (agent not found, invalid proposal, etc.) |
| 2 | LLM adapter initialization failed |

### Stub Fixture Format

When using `--provider stub --fixture <file>`, the fixture file must be a complete proposal JSON object. The stub provider reads this file directly and submits it as the agent's proposal.

**Required fields:**

| Field | Type | Description |
|-------|------|-------------|
| `run_id` | string | Unique run identifier (e.g., `"20240115-143022"`) |
| `agent_id` | string | Must match the agent being run |
| `branch` | string | Current branch name (e.g., `"main"`) |
| `base_head_event` | integer | Current head event number (from manifest) |
| `query` | string | The query that triggered this proposal |
| `rationale` | string | Explanation of what changes are being made |
| `ops` | array | List of file operations |

**Ops format:**

Each op in the `ops` array is an object with:

| Op Type | Fields | Description |
|---------|--------|-------------|
| `upsert_text` | `path`, `content` | Create or overwrite a file |
| `delete` | `path` | Delete a file |

Paths are **relative to `game/`** (e.g., `"npc/merchant.json"`, not `"game/npc/merchant.json"`).

**Example fixture file:**

```json
{
  "run_id": "test-001",
  "agent_id": "narrator",
  "branch": "main",
  "base_head_event": 1,
  "query": "Add a merchant to the town",
  "rationale": "Adding a merchant NPC to start-town",
  "ops": [
    {
      "op": "upsert_text",
      "path": "npc/merchant.json",
      "content": "{\"id\": \"merchant\", \"kind\": \"npc\", \"name\": \"Town Merchant\", \"tags\": [\"shopkeeper\"], \"summary\": \"A friendly merchant.\", \"location\": \"start-town\"}"
    }
  ]
}
```

**Tip:** To get the current `base_head_event` value, check `.neonrp/manifest.json` or run `neonrp agent context <agent_id> --query "test" --json` and look at the `base_head_event` field.

### Examples

```bash
# Create agent
neonrp agent new narrator

# List agents
neonrp agent list --json

# Show agent details
neonrp agent show narrator

# Run agent with LLM
neonrp agent run narrator --query "describe the town square"

# Run with auto-apply
neonrp agent run narrator --query "add a merchant" --apply

# Use stub provider with fixture
neonrp agent run narrator --query "test" --provider stub --fixture test.json

# Full stub test with apply
neonrp agent run narrator --query "add merchant" --provider stub --fixture fixture.json --apply
```

---

## import

Import external content into NeonRP game data.

### Synopsis

```bash
neonrp import <SUBCOMMAND> [OPTIONS]
```

### Subcommands

#### import sillytavern-card

Import a SillyTavern character card.

```bash
neonrp import sillytavern-card <FILE> [--id ENTITY_ID] [--json]
```

| Argument/Option | Description |
|-----------------|-------------|
| `FILE` | Path to character card (JSON or PNG) |
| `--id` | Override entity ID (kebab-case) |
| `--json` | Output as JSON |

Supports:
- JSON character card files
- PNG files with embedded `chara` tEXt chunk

Notes:
- If the card title is non-ASCII and `--id` is omitted, NeonRP generates a stable ASCII entity ID automatically.
- This command imports a card as a NeonRP entity only. Converting imported Tavern content into a full playable project is a later build-mode step.

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (not initialized, invalid card, etc.) |

### Examples

```bash
# Import JSON card
neonrp import sillytavern-card character.json

# Import PNG card
neonrp import sillytavern-card character.png

# Override entity ID
neonrp import sillytavern-card card.json --id my-character

# JSON output
neonrp import sillytavern-card card.png --json
```

---

## game

Game scaffolding commands.

### Synopsis

```bash
neonrp game <SUBCOMMAND> [OPTIONS]
```

### Subcommands

#### game new

Create a starter game state from a template.

```bash
neonrp game new [--template NAME] [--force] [--json]
```

| Option | Description |
|--------|-------------|
| `--template` | Template name (default: "default") |
| `--force` | Overwrite existing game entities |
| `--json` | Output as JSON |

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (not initialized, game data exists) |
| 2 | Apply failed |

### Examples

```bash
# Create default starter game state
neonrp game new

# Force overwrite
neonrp game new --force

# JSON output
neonrp game new --json
```

`game new` copies the default play scaffold as part of the template:
- `agents/narrator/`
- `agents/town-agent/`
- `agents/dungeon-agent/`
- `.neonrp/runtime_contract.json`

---

## sandbox

Sandbox management commands.

### Synopsis

```bash
neonrp sandbox <SUBCOMMAND> [OPTIONS]
```

### Subcommands

#### sandbox new

Create a new sandbox from a save.

```bash
neonrp sandbox new <NAME> --from <SAVE_ID> [--switch] [--json]
```

| Option | Description |
|--------|-------------|
| `--from` | Save ID to create sandbox from (required) |
| `--switch` | Switch to the new sandbox after creation |
| `--json` | Output as JSON |

#### sandbox list

List all sandboxes.

```bash
neonrp sandbox list [--json]
```

#### sandbox switch

Switch to a sandbox.

```bash
neonrp sandbox switch <NAME> [--json]
```

#### sandbox drop

Delete a sandbox.

```bash
neonrp sandbox drop <NAME> [--force] [--json]
```

| Option | Description |
|--------|-------------|
| `--force` | Skip confirmation |
| `--json` | Output as JSON |

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error |

### Examples

```bash
# Create sandbox from save
neonrp save my-checkpoint
neonrp sandbox new experiment --from my-checkpoint --switch

# List sandboxes
neonrp sandbox list

# Switch sandbox
neonrp sandbox switch main

# Drop sandbox
neonrp sandbox drop experiment --force
```

---

## replay

Replay commands for determinism verification.

### Synopsis

```bash
neonrp replay <SUBCOMMAND> [OPTIONS]
```

### Subcommands

#### replay verify

Verify determinism by replaying events from a save.

```bash
neonrp replay verify --from <SAVE_ID> [--branch NAME] [--to EVENT_ID] [--json]
```

| Option | Description |
|--------|-------------|
| `--from` | Save ID to replay from (required) |
| `--branch` | Branch to replay on (default: save's branch) |
| `--to` | Target event ID (default: head) |
| `--json` | Output as JSON |

Does NOT modify the real `game/` directory.

#### replay checkout

Replay events to a target point and create a sandbox.

```bash
neonrp replay checkout --from <SAVE_ID> --to <EVENT_ID> --to-branch <NAME> [--json]
```

| Option | Description |
|--------|-------------|
| `--from` | Save ID to replay from (required) |
| `--to` | Target event ID (required) |
| `--to-branch` | New sandbox branch name (required) |
| `--json` | Output as JSON |

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success (verification passed) |
| 1 | Error or divergence detected |

### Examples

```bash
# Verify replay determinism
neonrp replay verify --from my-checkpoint

# Verify to specific event
neonrp replay verify --from my-checkpoint --to 5 --json

# Checkout to a past state
neonrp replay checkout --from my-checkpoint --to 5 --to-branch rollback
```

---

## tui

Launch the NeonRP Terminal User Interface.

### Synopsis

```bash
neonrp tui [OPTIONS]
```

### Options

| Option | Description |
|--------|-------------|
| `--branch` | Branch to use (default: current branch) |
| `--provider` | LLM provider override |
| `--continue` | Continue the previous session on startup |
| `--new` | Start a brand new session on startup (default) |
| `--import-card` | Import a SillyTavern JSON/PNG card on startup |
| `--import-id` | Override imported entity ID for `--import-card` |
| `--verbose` | Enable verbose debug mode |

### Description

The TUI (M9+) provides a conversational interface similar to Claude Code:
- Natural language input with streaming responses
- Three conversation modes: `build`, `sandbox`, `play`
- Real-time tool use indicators and todo list display
- Slash commands: `/mode`, `/clear`, `/files`, `/skills`, `/import`, `/help`
- Session persistence across restarts

Fresh `init`-only directories can use build mode immediately. `game new` is optional unless you want the default starter world/play scaffold.

**Conversation Modes:**
- `build` (default): Direct file operations, natural narrative responses
- `sandbox`: Proposal pipeline for safe experimentation
- `play`: Game Master mode for immersive gameplay

See [TUI_GUIDE.md](TUI_GUIDE.md) for detailed usage.

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Normal exit |
| 1 | Invalid option combination or runtime command error |

### Examples

```bash
# Launch TUI (conversational interface)
neonrp tui

# Launch with specific branch
neonrp tui --branch experiment

# Launch with provider override
neonrp tui --provider openai

# Continue previous session
neonrp tui --continue

# Import a Tavern card before the first turn
neonrp tui --import-card world.png --import-id world-card

# Enable verbose diagnostics
neonrp tui --verbose
```

---

## Exit Code Summary

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | General error (validation failed, not found, etc.) |
| 2 | System error (not initialized, IO error, adapter error) |

## Environment Variables

| Variable | Description |
|----------|-------------|
| `OPENAI_API_KEY` | OpenAI API key |
| `GLM_API_KEY` | GLM API key |
| `ANTHROPIC_API_KEY` | Anthropic API key |

Environment variables can also be set in a `.env` file in the project root.


