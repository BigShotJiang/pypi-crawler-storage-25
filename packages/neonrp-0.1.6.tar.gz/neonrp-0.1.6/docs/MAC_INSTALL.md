# NeonRP Mac 安装与启动（简版）

面向全新克隆仓库的 Mac 用户。

## 1. 准备

```bash
# 安装 uv（若未安装）
curl -LsSf https://astral.sh/uv/install.sh | sh
```

```bash
# 克隆仓库
git clone <your-repo-url> NeonRP
cd NeonRP
```

## 2. 从游戏目录启动（你现在这种方式）

如果目录结构是：

```text
NeonRP/
my-rpg/
```

在 `my-rpg` 里执行（Mac 下与 Windows 相同）：

```bash
uv run --project .. neonrp tui
```

也可省略 `tui`（默认就是 Claude Code 风格 TUI）：

```bash
uv run --project .. neonrp
```

## 3. 其他可用启动方式

```bash
# 在仓库根目录直接运行
uv run neonrp

# 或先安装命令再运行
uv tool install -e /absolute/path/to/NeonRP
neonrp
neonrp tui
```

## 4. 配置文件位置（重点）

- Windows 常见路径：`C:\Users\fangs\.neonrp\config.json`
- Mac 对应路径：`/Users/<你的用户名>/.neonrp/config.json`（即 `~/.neonrp/config.json`）

NeonRP 启动时会读取用户级配置（默认 `~/.neonrp/config.json`）。  
如需自定义路径，可设置环境变量 `NEONRP_HOME`。

## 5. 首次进入 TUI 后操作

启动后默认是类 Claude Code 的 TUI。首次请按顺序输入：

```text
/init
/game new
/mode play
```

然后直接输入自然语言开始游玩（例如：`look around`）。
