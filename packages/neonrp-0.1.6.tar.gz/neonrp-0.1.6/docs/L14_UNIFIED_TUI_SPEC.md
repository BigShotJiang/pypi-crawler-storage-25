# L14 — Unified WorldLines TUI Spec

> **Status:** Active spec
> **Supersedes:** legacy `docs/L13_TASK_CARDS.md`, legacy `docs/L14_TASK_CARDS.md`
> **Positioning:** This L14 defines the unified `worldlines + neonrp` experience layer on top of the existing runtime.
> **Related draft:** `docs/L14_AUTO_UPDATE_SCHEME.md`

## Product framing

- `neonrp` is the unified runtime and transcript-first TUI surface.
- `worldlines` is the guided launcher / onboarding entry into the same runtime.
- Current execution stays **single-controller first**: for this version, `orchestrator ≈ world-agent`.
- The UI reflects **presentation roles**, not internal orchestration topology.

## L14 goals

- Ship a Claude Code-style single-pane TUI shell.
- Merge `worldlines` onboarding into the TUI instead of maintaining a separate product mental model.
- Move transcript rendering from procedural tool logs to narrative semantic folding.
- Make Claude Code / MCP / built-in `.claude/agents` a first-class workspace setup path.
- Make hosted provider onboarding easy, with **OpenRouter as a first-class guided option**.

## Non-goals

- No default multi-agent control-room UI.
- No Tauri / `.dmg` / `.exe` desktop client scope in this version.
- No top-level exposure of raw orchestrator routing and handoff mechanics.
- No debug-first transcript experience.

## TUI shell

### Layout

- Main area: narrative transcript only.
- Bottom area: text input.
- Input bottom-right: compact inline status metadata.
- No traditional top status bar.
- No heavy pane / box layout.

### Visual language

- Claude Code-inspired.
- Low chrome, weak borders, mostly monochrome.
- Color is reserved for rendered content, warnings, errors, and a few semantic labels.
- Input area uses a blinking green `>` prompt with dark gray divider lines.
- Input hint copy lives inside the text field as a localized placeholder.

### Inline status metadata

Displayed in the input area's bottom-right region:

- `mode`
- `model`
- `mcp / discord`
- `↑ / ↓` token counters

World time and location are displayed on a second line below the model row.

### Localization

- TUI copy should support lightweight locale switching.
- Initial scope: inline input hint and compact mode labels.
- Config knob: `tui.language = auto | en | zh`
- `auto` falls back to environment locale.

Fallback rule:

- If world time or location is unavailable, render `-`.

Examples:

- `play · claude-code · Day 2 06:45 · 石津镇・河灯旅店 · mcp:on discord:- · ↑1.2k ↓380`
- `setup · openrouter:moonshotai/kimi-k2 · - · - · mcp:off discord:- · ↑0 ↓0`

## Onboarding hub

`worldlines` becomes a guided entry path inside the same TUI.

### Entry detection

- Existing project / save
- Template project
- Engine / root workspace
- Empty workspace

### Guided actions

- Continue an existing save/project
- Start from a template
- Create character
- Import character
- Create world
- Import world
- Configure provider / install runtime prerequisites
- Confirm MCP / Claude workspace bootstrap
- Connect Discord

### Built-in creation/import tools

- Character create / import are built-in workflow tools
- World create / import are built-in workflow tools
- These flows should be guided, but the user remains inside the same TUI surface

## Provider setup

### Provider positioning

- `Claude Code + MCP` is the local premium workflow path.
- `OpenRouter` is the recommended hosted-provider path for low-friction setup.
- Other providers remain supported, but do not define the primary onboarding path.

### OpenRouter requirements

- OpenRouter must be a first-class option in onboarding.
- Setup flow should support:
  - API key input / validation path
  - recommended starter models
  - provider-specific `extra` passthrough support when needed
- Docs and setup copy should treat OpenRouter as a practical default for users without Claude / OpenAI direct access.

### Initial provider choices

- `Claude Code`
- `OpenRouter`
- `Anthropic`
- `OpenAI`
- `Stub / local test`

## Claude workspace bootstrap

### `.claude/agents`

- Canonical built-ins live in the Python package.
- Runtime sync writes them into project-local `.claude/agents/worldlines/`.
- Project-local files can override built-ins.

### MCP bootstrap

When MCP mode is enabled, L14 should ensure:

- `.mcp.json` exists and is updated
- `.claude/agents/worldlines/*` is synced into the project
- `CLAUDE.md` is present / refreshed
- the TUI can confirm the workspace is ready for Claude Code

## Presentation model

The UI should render semantic presentation roles instead of raw internal executors:

- `world-agent`
- `character-agent:<id>`
- `rules-referee`
- `system`

`orchestrator` is not a first-class transcript speaker in the default view.

## Transcript model

### Core rule

- Users see **story first**.
- Agents show **semantic summaries first**.
- Tools / files / thinking appear only after expansion.

### Three display levels

#### L1 — Narrative layer

- Scene header
- Character dialogue
- Inner monologue
- World narration
- Rule outcomes
- State updates
- Awaiting player action

#### L2 — Semantic execution summary

- Why an action happened
- What state or rules were consulted
- What the meaningful outcome was

#### L3 — Raw execution trace

- tool calls
- file reads
- thinking
- routing / trace details

### Event schema direction

The UI should move toward semantic events rather than rendering raw tool lines directly:

- `scene_header`
- `world_utterance`
- `character_utterance`
- `inner_monologue`
- `rule_check`
- `state_update`
- `transaction`
- `awaiting_player_action`
- `execution_summary`
- `raw_trace`

## Current execution model

- L14 assumes a **single-controller runtime** for the default UX.
- Current mental model: `orchestrator ≈ world-agent`.
- Multi-agent persistence / control-room visualization is deferred.
- The transcript schema must stay stable even if the underlying runtime becomes more multi-agent later.

## Orchestrator Contract

### Core role

- `orchestrator` is the fixed root entry for player turns.
- `orchestrator` owns routing, aggregation, player interaction pacing, and final player-facing output.
- `orchestrator` may recursively delegate to domain or specialist agents, but recursion always returns to `orchestrator` before the turn finishes.

### Do

- Receive every player input first.
- Decide whether the turn needs delegation.
- Decide which agent should be called next.
- Gather and merge returned results from sub-agents.
- Normalize the final output into a single coherent player-facing response.
- Own `ask_user` and final choice presentation.
- Maintain continuity of voice, pacing, and scene framing across multiple delegated calls.

### Do Not

- Do not surrender final output ownership to a domain agent.
- Do not let sub-agents directly own player choice capture in orchestrator mode.
- Do not skip routing simply because a prompt already contains narrative instructions.
- Do not invent domain facts when a domain agent should first ground them.
- Do not expose raw routing mechanics, handoff chatter, or internal control flow to the player transcript.

### Delegation expectation

`orchestrator` should prefer delegation when the turn requires domain truth, deterministic rules, or scene-specific grounding, especially for:

- entering a new domain or environment
- town / dungeon / combat domain actions
- rule-heavy or consequence-heavy actions
- any situation where the current world facts are not yet grounded

`orchestrator` may handle lightweight connective narration itself, but should avoid becoming the primary domain worker.

## Domain Agent Contract

### Purpose

Domain agents are workers that ground and resolve domain-specific state. They are not the final transcript owner in L14 orchestrator mode.

### Shared behavior

- Ground domain facts before narrating confidently.
- Read the minimum canonical files needed to confirm the current state.
- Use search/discovery tools when file paths or entity locations are uncertain.
- Prefer confirmed world facts over improvisation.
- Return concise, useful results that help `orchestrator` continue the turn.

### Do

- Resolve domain-local actions.
- Confirm local facts from files/tools before presenting them as true.
- Return a compact domain packet that `orchestrator` can integrate.
- Surface uncertainty explicitly when required information is missing.
- Suggest concrete next actions when helpful.

### Do Not

- Do not directly own the full player transcript in orchestrator mode.
- Do not directly call `ask_user` in orchestrator mode.
- Do not over-expand into unrelated domains.
- Do not fabricate environment details, NPC state, or rules outcomes that were not grounded.

### Return contract

Each domain/specialist agent should conceptually return a compact internal packet to `orchestrator` containing most or all of:

- `summary`: what this agent completed
- `grounded_facts`: the important confirmed facts it relied on
- `state_updates`: state changes it produced or recommends
- `suggested_next_actions`: concrete next actions the player can take
- `missing_info`: what could not be confirmed and should not be overstated
- `player_facing_text`: optional concise phrasing the orchestrator may reuse

The exact transport format may remain implementation-defined for now, but the semantic shape should stay consistent.

### Domain-specific emphasis

- **`town-agent`**: primarily a town context builder and local action resolver; it should ground place/facility/NPC/shop context before confident narration.
- **`dungeon-agent`**: primarily an exploration and encounter context builder; it should ground room/layout/state before describing progression.
- **`combat` / `combat-referee`**: primarily a rules-and-resolution worker; it should return outcomes and consequences clearly enough for orchestrator to narrate the scene.

## Discord

- Discord is part of onboarding, not a separate product surface.
- Initial L14 scope is bootstrap / connect / confirm, with implementation informed by `../buddy-bot`.
- Discord status belongs to the same inline metadata model as MCP.

## Acceptance

- The default TUI surface is single-pane and transcript-first.
- The old top status bar is replaced by inline input-area metadata.
- `worldlines` onboarding routes into the same TUI rather than a separate product path.
- Character / world create-import flows are accessible as guided built-ins.
- OpenRouter is a first-class guided setup path.
- MCP / Claude workspace bootstrap is visible and confirmable from the TUI.
- Default transcript output is narrative-first with semantic folding.

## Initial implementation order

1. Claude-style TUI shell
2. Unified onboarding hub
3. Narrative semantic folding
4. `.claude/agents` + MCP bootstrap
5. Discord bootstrap integration
