# M5 Task Cards (TUI)

这些 task cards 面向"让 Codex/自动化代理按卡片逐个推进"。每张卡片尽量控制在一次小 PR 的规模内。

质量门（每张卡片收尾必跑）：见 `docs/QUALITY_GATES.md`。

---

## Pre-M5 — H10: 提取 Agent Run 编排逻辑到 core 层

**Goal**
- 将 `commands/agent.py:agent_run` 中的编排逻辑（~200 行）提取到 `core/agent_runner.py`，使 CLI 和 TUI 共享同一入口函数。

**Suggested changes**
- `src/neonrp/core/agent_runner.py`（新增）
- `src/neonrp/commands/agent.py`（瘦身为 CLI 层调用）

**Scope**
- 提取的函数签名建议：
  ```python
  def run_agent(
      root: Path,
      agent_id: str,
      query: str,
      provider: str | None = None,
      fixture_path: str | None = None,
      do_apply: bool = False,
  ) -> AgentRunResult:
  ```
- `AgentRunResult` 应包含：`run_id`, `success`, `proposal`, `diff_content`, `summary`, `apply_result`, `error`, `logs_dir`
- CLI `agent_run` 命令瘦身为：参数解析 → 调用 `run_agent()` → 格式化输出
- 现有测试不应 break（行为不变，仅提取）

**Acceptance**
- `core/agent_runner.py` 中的 `run_agent()` 可被独立调用（不依赖 Click）
- `commands/agent.py:agent_run` 改为调用 `core/agent_runner.run_agent()`
- 现有 `pytest` 全绿

**Tests**
- Unit：直接调用 `run_agent()` + stub provider + fixture proposal，验证返回结果
- 现有 CLI integration tests 不需修改（行为不变）

---

## Pre-M5 — H11: 关闭 M5 Open Questions

**Goal**
- 在 `docs/M5_TUI_DESIGN.md` 中将三个 Open Questions 转为 Resolved decisions。

**Scope**
- Session 概念：M5 不做独立 session 落盘；transcript 仅内存维持。
- 内置 editor：M5 仅只读 viewer；外部编辑器通过 `$EDITOR`。
- Windows 快捷键：`Ctrl+K` + `Ctrl+P` 双注册；单字母快捷键非输入焦点时激活。
- 补充 Streaming 策略：M5 不改造 LLMAdapter，使用进度指示 + 完成后渲染。

**Acceptance**
- `docs/M5_TUI_DESIGN.md` 中 Open Questions 替换为 Resolved Questions，含具体决策。
- 新增 Streaming 策略章节。

---

## M5-T0 — TUI 规格 + ADR（Doc-first）

**Goal**
- 固化 TUI 框架选型、布局、交互模型、快捷键与测试策略，避免实现期反复改接口。

**Primary docs**
- `docs/M5_TUI_DESIGN.md`
- `docs/ADRs/0013-tui-framework-and-architecture.md`
- `docs/ADRs/0014-tui-interaction-model-and-keybindings.md`

**Acceptance**
- 文档明确：pane 布局、command palette、输入模型、核心 workflows（agent run + diff + apply + logs）
- 文档明确：TUI 与 core 的边界（不走 subprocess）
- ADR 状态为 Accepted

---

## M5-T1 — `neonrp tui` 脚手架 + 基础布局

**Goal**
- 跑起来一个可用的 TUI shell：status bar / navigator / transcript / details / input。

**Suggested changes**
- `pyproject.toml`（添加 `textual` 依赖）
- `src/neonrp/commands/tui.py`（Click 命令入口）
- `src/neonrp/tui/app.py`（Textual App 主类）
- `src/neonrp/tui/__init__.py`

**Acceptance**
- `neonrp tui` 能启动并检测项目是否 init（未 init 时显示错误提示并退出）
- 显示当前 branch/head_event/provider/model（status bar）
- 四区域布局可见（即使内容为 placeholder）
- `q` 退出

**Tests**
- Smoke test：Textual test mode 可启动并渲染基本控件
- Unit：项目状态检测逻辑（init check、manifest 读取）

---

## M5-T2 — Command Palette + Command Runner + `:` 命令解析

**Goal**
- 实现 Claude Code 风格 palette：模糊搜索 + 一键触发。
- 实现 `:` 命令模式：输入框以 `:` 开头时解析为 TUI 内命令。

**Acceptance**
- `Ctrl+K` 或 `Ctrl+P` 打开 palette；输入可过滤；Enter 执行动作
- 至少覆盖：validate/index build/find/context/save/undo/sandbox list/replay verify
- 输入框中 `:validate`、`:index build`、`:find <keyword>` 等可直接执行对应命令
- `:` 命令支持的最小集合：`:validate`, `:index build`, `:index update`, `:find <keyword>`, `:context <query>`, `:save [name]`, `:undo`, `:sandbox list`, `:sandbox new <name> --from <save_id>`, `:replay verify --from <save_id>`
- 未知 `:` 命令显示错误提示

**Tests**
- Textual：模拟按键打开 palette 并执行一个动作，验证 UI 状态更新
- Unit：`:` 命令解析器（tokenize + dispatch），含正常/异常/未知命令用例

---

## M5-T3a — Agent Run 面板（输入 → core → 渲染）

**Goal**
- 在 TUI 内完成"输入自然语言 → 调用 core/agent_runner → 渲染结果到 transcript"。

**前置**
- H10（core/agent_runner.py 提取）已完成

**Acceptance**
- 输入自然语言并 `Ctrl+Enter` 发送后，TUI 调用 `core.agent_runner.run_agent()`
- 运行期间显示 "Running agent…" 进度指示
- 完成后将 agent 输出（rationale + proposal summary）渲染到 transcript 面板
- 错误时在 transcript 中显示可操作的错误信息
- 支持 stub provider（可通过 config 或 TUI 启动参数指定）

**Tests**
- Integration：stub provider + fixture proposal，验证 transcript 面板内容更新

---

## M5-T3b — Diff Preview + Apply

**Goal**
- 在 Details 面板中展示 diff preview，并支持一键 apply。

**前置**
- M5-T3a 已完成

**Acceptance**
- Agent run 完成后，diff 自动显示在 Details 面板（右侧）
- diff preview 可滚动浏览
- 按 `a`（焦点在 diff 视图 + proposal 已通过校验时）触发 apply
- apply 调用 M2 `apply_proposal()` pipeline，成功后更新 head_event 并在 transcript 中提示用户 save/undo
- apply 失败时显示 validation errors

**Tests**
- Integration：stub provider + fixture proposal，验证 diff 渲染与 apply 结果

---

## M5-T4 — File Explorer + Viewer + Open-in-editor

**Goal**
- 像 OpenCode 一样快速浏览项目文件与 world 变化。

**Acceptance**
- 左侧文件树可浏览 `game/`、`agents/`、`.neonrp/logs/`
- 右侧 viewer 可预览文件内容（只读）
- 大文件截断（>500 行显示前 200 行 + 截断提示）
- 支持"在外部编辑器打开"（尊重 `$EDITOR`，缺失时回退到平台默认）

**Tests**
- Unit：路径选择与 viewer 渲染边界（大文件截断策略、编码处理）

---

## M5-T5 — Logs Browser（run_id 导航）

**Goal**
- 快速定位 `agent run` / `system proposal` 的审计链与错误。

**Acceptance**
- 可按 run_id 列出 runs，打开后看到 input/proposal/diff/validation/apply
- 错误时直接跳转到 validation/errors 视图
- `g` 快捷键跳转到最近一次 run

**Tests**
- Integration：运行一次 stub apply，TUI 能在 logs 列表中发现并打开

---

## M5-T6 — TUI 测试 + 可用性收尾

**Goal**
- 让 TUI 在 Windows Terminal 等常见环境稳定可用，并具备基础可测试性。

**Acceptance**
- 关键快捷键不冲突（或可配置）；在 Windows Terminal / PowerShell / CMD 下实测并记录已知冲突
- 错误信息可操作；退出有确认（若存在未应用 proposal）
- `Help: Keybindings` 可在 palette 中发现

**Tests**
- 增加 15~25 个测试覆盖核心流程：
  - view-model 纯函数单测（命令路由、状态转换、palette 过滤、`:` 命令解析）：~10 个
  - Textual 交互测试（启动、palette 开关、agent run、diff apply、file explorer、logs browser）：~8 个
  - agent_runner core 函数单测（已在 H10 中部分覆盖）：~5 个

---

## M5-T7 — 阶段 Review Gate

**Goal**
- 跑一次 `opencode run` 审查并落盘到 `reviews/`，按意见修复后保持 `pytest` 全绿。

**Acceptance**
- `reviews/` 下存在阶段审查文件
- 修复后二次 `pytest` 全绿
- `docs/ROADMAP.md` 勾选完成项，`docs/PROGRESS.md` 追加记录
- 所有 review findings 记录在 `docs/PROGRESS.md` 中
