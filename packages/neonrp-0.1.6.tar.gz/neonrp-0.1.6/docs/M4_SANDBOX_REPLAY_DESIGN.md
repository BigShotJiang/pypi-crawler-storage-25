# M4 Design: Sandbox + Replay

本文件定义 M4（Sandbox + Replay）的设计规格，用于指导实现与验收（见 `docs/ROADMAP.md` 的 M4-T0~T6）。

## Goals (M4 必达)
- **Sandbox**：提供 `sandbox new/list/switch/drop`，让玩家从任意 save 派生出“试玩空间”，且不影响主线。
- **Replay (debug determinism)**：提供 `replay verify`，从某个 save 作为基线重放事件到目标点（默认 head），用于定位“哪一步开始崩”。
- **Crash safety**：任何 world 级替换都必须 staging + 原子 swap；失败不得污染现有 world。
- **Metadata**：save 必须包含足够元信息（branch/head_event/world hash/事件日志副本）以支撑 sandbox 与 replay。

## Non-goals (M4 不做)
- 不做 sandbox merge/cherry-pick 回主线（P2）。
- 不做并行多 agent 调度。
- 不要求引擎层战斗/掷骰完全实现；但 replay 需要预留 seed/rolls 记录接口。

## Concepts

### 1) Save snapshot (with meta)
M4 将把 save 从“仅复制 world”升级为“可用于 replay 的快照”：

```
.neonrp/saves/<save_id>/
  game/
  events.jsonl
  meta.json
```

`meta.json` 最小字段（示例）：

```json
{
  "save_id": "20260130-235959",
  "created": "2026-01-30T23:59:59Z",
  "branch": "main",
  "head_event": 123,
  "game_hash": "sha256:...",
  "events_file": "events.jsonl",
  "manifest_version": "0.2"
}
```

说明：
- `events.jsonl` 为保存当时分支事件日志的副本（用于审计；replay 主要仍读取当前分支 events 以获取 save 之后的新事件）。
- `game_hash` 用于快速验证 replay 结果。

### 2) Sandbox = special branch
Sandbox 是一个特殊标记的 branch：
- 有自己的 world 存储（建议复用 `.neonrp/branches/<branch>/world`）
- 有自己的事件日志（`.neonrp/events/<branch>.jsonl`）
- manifest 中可识别为 sandbox（用于 list/drop 过滤与保护 main）

建议扩展 `BranchMetadata`（manifest version bump 到 `0.3`）：

```json
{
  "head_event": 123,
  "created": "...",
  "kind": "sandbox",
  "parent": "main",
  "fork_event": 123,
  "base_save": "20260130-235959"
}
```

> 注：如果不想 bump manifest.version，也可将 sandbox 元数据放在 `.neonrp/sandboxes.json`；但更推荐 manifest 统一承载。

### 3) Replay
Replay 是一个“只读默认”的调试器：
- 输入：`--from <save_id>` + `--branch <branch>` + `--to <event_id|head>`
- 输出：是否重放一致；若不一致，给出第一处差异（event id + path）

Replay 的重放对象：
- **world 变更事件**（M4 最小）：`type in {"agent", "apply", "import", "game"}`
- 其中 `agent/apply` 事件通过 `payload.run_id` 定位到 `.neonrp/logs/agents/<run_id>/proposal.json`，并按 ops 重放。

## Data Contracts

### World hash
建议采用稳定且可移植的 tree hash：
- 遍历 `game/` 下所有文件（递归）
- 相对路径统一为 `/`
- 每个文件计算 `sha256(file_bytes)`
- 最终 hash = `sha256( joinlines(sorted(f"{path}\t{sha256}")) )`，并前缀 `sha256:`

### Event requirements
为了让 replay 可用，事件日志至少需要：
- monotonic `id`（或 `seq`）
- `type`
- `timestamp`
- `actor`
- 对 world 变更事件：必须能定位到可重放的变更输入（至少 `run_id` → proposal 日志）

> 现状：M2/M3 的 agent apply 事件 payload 已包含 `run_id`。M4 需要把 `import`、`game new` 等 world 变更也纳入同一审计链（建议：用 system proposal 方式落 event）。

## CLI Surface (M4)

### `neonrp sandbox`
- `neonrp sandbox new <name> --from <save_id> [--switch] [--json]`
- `neonrp sandbox list [--json]`
- `neonrp sandbox switch <name> [--json]`
- `neonrp sandbox drop <name> [--force] [--json]`

行为要点：
- `new` 默认从 save 创建并可选自动切换。
- `drop` 禁止删除 main；若删除当前 branch，需先 switch 到 main（或要求 `--force`）。
- 任意切换都会使 `manifest.entities` 失效：要么自动重建索引，要么清空并提示用户 `index build`。

### `neonrp replay`
- `neonrp replay verify --from <save_id> [--branch <branch>] [--to <event_id|head>] [--json]`
- `neonrp replay checkout --from <save_id> --to <event_id> --to-branch <branch> [--json]`

默认行为：
- verify 不写入真实 world
- checkout 只在显式参数下写入，并且必须 crash-safe

## Event Type Specification

为了让 replay 能覆盖所有 world 变更，事件类型扩展如下：

| type | actor | 触发来源 | payload 必含字段 |
|------|-------|---------|----------------|
| `user` | `player` | `neonrp run` | `input` |
| `agent` | `<agent_id>` | `agent run --apply` | `run_id`, `query`, `ops_count`, `applied_paths` |
| `system` | `system` | `import` / `game new` | `command` (`import` 或 `game_new`), `run_id`, `ops_count`, `applied_paths` |

说明：
- `import` 和 `game new` 在 M4-T5 重构后生成 system proposal 并走 apply pipeline，因此自动写 event。
- `command` 字段用于 replay 区分 system 事件的来源。
- replay 目标 event type: `{"agent", "system"}`（通过 `run_id` 定位 proposal 日志重放）。
- `user` 事件不重放（无 world 变更语义）。

## World Hash Utility

world hash 的计算逻辑封装为 `core/hashing.py`，供 save meta 和 replay verify 共用：

```python
def compute_game_hash(world_dir: Path) -> str:
    """Compute a stable tree hash for the world directory.

    Algorithm:
    1. Enumerate all files under world_dir recursively
    2. Normalize paths to forward slash
    3. Compute sha256 of each file's bytes
    4. Sort entries by normalized path
    5. Final hash = sha256(join_lines(sorted("{path}\t{file_hash}")))
    6. Return "sha256:{hex_digest}"
    """
```

## Implementation Notes (for later)
- 复用 `apply_proposal` 的 ops 执行逻辑；replay 只需要"在 staging 上 apply ops"这一段。
- 保存与切换 world 必须复用同一套原子 swap 工具，避免 rmtree + copytree 的崩溃窗口。
- 对已有 saves（没有 meta.json 的历史快照），replay/sandbox 需要给出可操作报错（提示重新 save）。

## Replay Verify Output Format

### 人类可读（默认）
```
Replay from save 'my-save' to event #42 on branch 'main':
✓ Event #38 (agent:narrator) — OK
✓ Event #39 (system:import) — OK
✗ Event #40 (agent:narrator) — MISMATCH
  First divergent file: character/hero.json
  Expected hash: sha256:abc123...
  Actual hash:   sha256:def456...
Replay stopped at event #40. 2/4 events replayed successfully.
```

### JSON (`--json`)
```json
{
  "success": false,
  "from_save": "my-save",
  "branch": "main",
  "target_event": 42,
  "events_total": 4,
  "events_replayed": 2,
  "divergent_event": {
    "event_id": 40,
    "type": "agent",
    "actor": "narrator",
    "first_divergent_file": "character/hero.json",
    "expected_hash": "sha256:abc123...",
    "actual_hash": "sha256:def456..."
  }
}
```

## Testing & Acceptance
- Unit: tree hash 稳定性；save meta 解析；事件选择（from/to）；system proposal 生成
- Integration: init → game new → save → sandbox new(from save) → agent run --apply → switch back → verify isolation
- Replay: save → apply 1-2 个 deterministic proposal（stub/fixture）→ replay verify 应通过；手动改一个文件 → replay verify 应报告差异
- PNG import: import PNG card → validate → index build（与 JSON import 结果一致）

## Resolved Questions
以下问题在计划审查中已决定：

1. **import/game new 是否改为 system proposal + apply pipeline？** — 是（方案 A）。所有 world 变更走 apply pipeline，确保 event 完整性和 replay 覆盖。在 M4-T5 实现。
2. **manifest.entities 是否 per-branch？** — M4 不做。sandbox switch 时 manifest.entities 失效，CLI 提示用户运行 `index build`。优化推迟到后续里程碑。

