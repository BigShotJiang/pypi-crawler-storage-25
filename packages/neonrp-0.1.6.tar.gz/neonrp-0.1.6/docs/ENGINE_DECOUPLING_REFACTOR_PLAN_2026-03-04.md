# Engine Decoupling Refactor Plan (M12+)

## 1. Problem Statement

当前引擎把默认示例游戏语义（`town/dungeon`、`start-town`、`game-start` 等）写进了运行时代码和系统提示词。
结果是：

- `/game new` 之外的项目也被默认世界观绑死。
- 路由策略依赖字符串猜测（agent id 含 `town`/`dungeon`）而不是数据契约。
- 迁移到新模板或新领域时，需要改核心代码而不是改配置/模板。

这与 NeonRP 的目标（引擎只约束协议和元数据格式）冲突。

## 2. Audit Findings (Runtime Coupling)

以下是“引擎层耦合”，不是模板内容本身：

1. `src/neonrp/core/conversation.py:1724`  
`_preferred_kinds_for_agent()` 按 agent_id 字符串包含 `town`/`dungeon` 返回偏好 kind。

2. `src/neonrp/core/conversation.py:1753`  
`_select_context_pack_entity_ids()` 固定注入 `player`、`active-agent`、`game-start`。

3. `src/neonrp/core/conversation.py:2073`  
`_get_agent_sticky_domain_kinds()` 在缺配置时回退到 `town`/`dungeon` 字符串猜测。

4. `src/neonrp/core/conversation.py:2094`  
`_read_player_location_state()` 固定读取 `player/player.json` 的 `location`，并固定扫描 `town/dungeon/location` 三种目录。

5. `src/neonrp/core/conversation.py:2187`  
`_select_router_target_agent()` 用 `town/dungeon/location` + `cave/forest/wild` 关键字做路由兜底猜测。

6. `src/neonrp/core/conversation.py:357`  
narrator guardrail 通过匹配文案字符串 `"directly handle town/dungeon operations"` 生效，属于脆弱协议。

7. `src/neonrp/core/prompts.py:184`  
系统提示词硬编码开局流程：`game/meta/game-start.json`，fallback 到 `game/player/player.json` + `game/town/start-town.json`。

8. `src/neonrp/core/prompts.py:209`  
系统提示词硬编码路由门控文件：`game/meta/active-agent.json` + `game/player/player.json`。

9. `src/neonrp/core/skills.py:64`  
工具描述文案含 `game/meta/game-start.json` 示例，继续强化固定路径心智。

10. `src/neonrp/core/active_agent.py:7`  
`active-agent` 状态文件路径写死为 `game/meta/active-agent.json`（协议位置不可配置）。

11. `src/neonrp/core/paths.py:8`  
`GAME_DIR_NAME = "game"`，`get_data_dir_name()` 固定返回 `game`，数据目录不可项目化配置。

12. `src/neonrp/core/indexing.py:60` 与 `src/neonrp/core/validation.py:109`  
实体路径校验写死 `game/<kind>/<id>.json`。

13. `src/neonrp/core/rules.py:25`  
默认规则 profile 内置 `location/town/dungeon/shop` 语义集合。

14. `src/neonrp/commands/game.py:28`  
`_DEFAULT_SUB_AGENTS = ("town-agent", "dungeon-agent")`，`game new` 默认强绑定两类专家。

## 3. Refactor Objectives

1. 引擎层不再包含任何业务域关键词（如 `town/dungeon/start-town`）的行为判断。  
2. 路由、开局、sticky 退出全部由“项目配置/模板配置”驱动。  
3. 保持老项目可运行（自动迁移或兼容回退），但新逻辑不再依赖硬编码猜测。  
4. 模板可以自由扩展世界观，不需要修改 `src/neonrp/core`。

## 4. Target Architecture (Data-Driven)

新增项目运行时契约文件：`.neonrp/runtime_contract.json`（建议名，可调整）。

最小字段建议：

```json
{
  "data_dir": "game",
  "router": {
    "agent_id": "narrator",
    "state_file": "meta/active-agent.json",
    "startup_file": "meta/game-start.json"
  },
  "routing": {
    "location_source": {
      "entity_id": "player",
      "field": "location"
    },
    "domain_agent_map": {
      "town": "town-agent",
      "dungeon": "dungeon-agent"
    },
    "fallback_agent": "narrator"
  },
  "context_pack": {
    "seed_entity_ids": ["player", "active-agent", "game-start"],
    "max_entities": 6
  }
}
```

关键原则：

- 核心代码只读契约，不猜测业务词。
- 模板负责提供契约默认值。
- 项目可覆盖契约实现不同玩法。

## 5. Execution Plan

### Phase A: Protocol Extraction (High Priority)

1. 引入 `runtime_contract` 读取层（带默认值与校验）。
2. 替换 `conversation.py` 中所有 `town/dungeon/location` 字符串判断为契约读取。
3. 移除 agent_id 关键字猜测回退；缺配置时只走“安全中立策略”（交还 router 或提示配置缺失）。
4. narrator guardrail 从“字符串匹配”改为结构化字段（例如 `agent.json.policy.role = "router"` + `policy.disallow_tools`）。

### Phase B: Path & State Decoupling

1. `paths.py` 的 `data_dir` 改为可配置（从 `runtime_contract` 或 manifest 读取）。
2. `active_agent.py` 的状态文件路径改成契约字段（不再写死 `game/meta/active-agent.json`）。
3. `indexing.py` / `validation.py` 路径规则改为 `<data_dir>/<kind>/<id>.json`（错误文案同步）。

### Phase C: Prompt/Tool Text Neutralization

1. `prompts.py` 去除 `start-town`、`town/dungeon` 硬编码文案。
2. 开局与路由提示改成“读取 contract 指定文件/字段”。
3. `skills.py` 工具说明示例改为变量路径示例（不再固定 `game/meta/game-start.json`）。

### Phase D: Template and CLI Generalization

1. `game new` 改为按模板清单生成 agent（删除 `_DEFAULT_SUB_AGENTS`）。
2. 模板内声明 `runtime_contract` 初始值（或映射到 `.neonrp` 下配置）。
3. 允许模板定义任意 domain-agent 组合，不要求 `town-agent/dungeon-agent` 存在。

### Phase E: Compatibility & Migration

1. 提供一次性迁移命令：`neonrp migrate-runtime-contract`（建议）。
2. 对旧项目自动生成兼容 contract（读取现有 `active-agent.json`、agent 配置）。
3. 兼容窗口内保留 legacy fallback，但记录 warning；下一个里程碑移除 fallback。

## 6. Acceptance Criteria

满足以下全部条件才算完成：

1. 在 `src/neonrp/core` 与 `src/neonrp/commands` 中，除模板拷贝逻辑外，不再有 `town/dungeon/start-town` 驱动分支判断。
2. 新建一个无 `town/dungeon` 概念的模板（例如 `ship/station/wilderness`）无需改核心代码即可跑通路由。
3. sticky 子代理进入/退出仅由 contract + agent 配置决定，不依赖 agent id 文本。
4. `data_dir` 可改名（非 `game`）且索引、校验、提示词、工具说明全部工作正常。
5. 旧项目不改文件也能运行；日志明确提示 legacy fallback 使用情况。

## 7. Test Plan

1. 单元测试  
- `runtime_contract` 读写、默认值、坏配置恢复。  
- `conversation` 路由在自定义 domain 名下正确工作。  
- `active_agent` 在自定义状态路径下正常读写。  

2. 集成测试  
- `game new --template custom` 生成非 `town/dungeon` 模板并跑一轮 play。  
- `/sessions`、`/continue` 恢复后 sticky 状态与 speaker 正确。  

3. 回归测试  
- 旧 `my-rpg` 模板仍可运行。  
- 当前 M12 的 sticky + handoff 关键流程不退化。  

## 8. Risks and Mitigation

1. 风险：改动面大，易引入路由回归。  
缓解：分 Phase 合并，每 Phase 先加测试后替换逻辑。

2. 风险：旧项目配置不全导致不可路由。  
缓解：提供自动生成 contract + warning，不直接硬失败。

3. 风险：提示词调整后模型行为波动。  
缓解：保持“结构化策略 + 明确工具职责”，并提供 A/B prompt fixture 回归。

## 9. Immediate Next Actions

1. 先落地 Phase A（只做协议抽取，不动模板内容）。  
2. 同步补齐 contract schema 与校验。  
3. 完成后再推进 Phase B（路径层改造），避免一次性大爆炸改动。

