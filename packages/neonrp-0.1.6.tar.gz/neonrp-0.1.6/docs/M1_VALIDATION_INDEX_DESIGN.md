# M1 Design: Validation + Index

本文件定义 M1（Validation + Index）的设计规格，用于指导实现与验收（见 `docs/ROADMAP.md` 的 M1-T0~T5）。

## Goals (M1 必达)
- **Schema validation**：对 `game/` 数据做结构校验与基础约束校验，并给出可操作的错误信息。
- **Entity index**：在 `manifest.json` 中建立实体索引（id/tag/keyword 友好），支撑快速定位与增量更新。
- **Find**：提供 `find` 命令，按 id/tag/kind/keyword 查询实体。
- **Minimal context retrieval**：提供可解释的关键词/规则检索器，输出“最小上下文集合”，为 M2 agent 做铺垫。

## Non-goals (M1 不做)
- 不引入向量 embedding（可在 M3+ 做）
- 不做跨实体引用完整性（可分阶段做：M1.5/M2）
- 不做权限边界（M2 才落地），但必须为其预留索引结构

## World Data Conventions
详见 ADR：`docs/ADRs/0004-world-entity-conventions.md`。

### Minimal example
```json
{
  "id": "tokyo",
  "kind": "town",
  "name": "Tokyo",
  "tags": ["market", "capital"],
  "summary": "A dense neon city with countless alleys."
}
```

## Validation

### Command
新增：`neonrp validate`

默认行为：
- 扫描 `game/**/*.json`
- 对每个文件做 JSON 解析 + schema 校验
- 汇总并输出：
  - 文件级错误列表（path、错误码、json path、消息、建议）
  - 总体统计（files_ok / files_failed）

### Exit codes
- `0`: 全部通过
- `1`: 有校验失败（可恢复/可修复的输入错误）
- `2`: 系统错误（schema 缺失、权限问题、IO 错误等）

### Schema sources & override
校验 schema 的加载优先级（高→低）：
1) 项目内 `.neonrp/schema/`（允许用户/模组覆盖）
2) CLI 内置 schema（随包发布）

M0 已创建 `.neonrp/schema/`，M1 将在实现阶段补齐默认 schema 文件与加载逻辑。

### Validation layers
M1 将校验拆成两层（输出时标记层级）：
1) **Structure**：必填字段、类型、基本格式（由 JSON Schema 覆盖）
2) **Constraints**：跨文件约束（最小集合：id 全局唯一、kind 与路径一致、kind 值合法）

## Indexing

### Manifest extension
`manifest.json` 顶层新增：
- `entities`: map[`entity_key` → `EntityRecord`]

其中 `entity_key = "{kind}:{id}"`（详见 ADR：`docs/ADRs/0005-indexing-strategy.md`）。

`EntityRecord`（M1 最小字段）：
- `id`, `kind`, `name`
- `tags`（可选）
- `summary`（可选）
- `path`（相对项目根）
- `mtime`（用于增量更新）
- `hash`（用于变更检测；建议 `sha256:` 前缀）

### Commands
新增命令组（建议）：`neonrp index build|update`

行为：
- `build`: 全量扫描 `game/`，重建 `entities`
- `update`: 仅重建变更实体（基于 mtime/hash），并清理已删除文件对应的 entries

## Find

### Command
新增：`neonrp find <query>`

支持：
- `--id <id>`：精确定位（可允许 `kind:id` 或纯 id，纯 id 需在唯一性规则下解析）
- `--tag <tag>`：按 tag 过滤
- `--kind <kind>`：按 kind 过滤
- 默认模式：keyword 搜索（基于 name/tags/summary，可选包含文件内容 token）

输出（人类友好）最小包含：
- entity_key
- path
- name
- tags（若有）
- summary（若有）

## Minimal Context Retrieval

### Command
新增（debug/未来 agent 入口）：`neonrp context "<query>" --limit N`

返回：
- Top-N entities（按可解释规则打分），并附上：
  - path
  - snippet
  - score breakdown

### Snippet specification
- 优先使用 `summary` 字段原文
- 缺失时截取文件内容前 200 字符（截断处标记 `...`）
- snippet 最大长度上限：200 字符

### Score breakdown format
`--json` 模式下每条结果包含：
```json
{
  "entity_key": "town:tokyo",
  "path": "game/town/tokyo.json",
  "name": "Tokyo",
  "snippet": "A dense neon city with countless alleys.",
  "score": 0.85,
  "score_breakdown": {
    "tags": 0.4,
    "name": 0.3,
    "summary": 0.15,
    "content": 0.0
  }
}
```

### Ranking (explainable heuristic)
建议权重（可在实现阶段调参）：
- `tags` 命中：高权重
- `name` 命中：中高
- `summary` 命中：中
- 文件内容 token 命中：低（且要有上限，避免全文件扫描）

### Stability
"结果顺序稳定"定义：相同 query + 相同 manifest.entities → 相同排序结果。分数相同时按 entity_key 字典序排序。

## Output format convention (all M1 commands)
- 默认：人类可读文本
- `--json`：结构化 JSON 输出到 stdout（便于管道和 agent 消费）
- 所有 M1 CLI 命令（validate / index / find / context）必须支持 `--json` 标志

## Index interaction with save/load
M1 不自动在 `load`/`undo` 后触发 `index update`（保持简单）。`find`/`context` 在 `manifest.entities` 为空时提示用户执行 `index build`。

## Testing & Acceptance
以 `docs/QUALITY_GATES.md` 为总门槛，M1 重点补齐：
- 单测：schema loader、validator（pass/fail）、entity scanner、增量更新策略、tokenize/rank
- 集成：temp project root 下的 init → validate → index build → find/context
- E2E：subprocess 调 CLI，检查 exit code 与关键输出

## Resolved Questions
以下问题已在审查中决定（原 Open Questions）：

1. **倒排索引**：M1-T3（可选），若实施使用 JSON 文件（`.neonrp/index/inverted.json`），不引入 SQLite。
2. **纯 id 查询**：维持"全局唯一"规则，纯 id 直接精确匹配。
3. **manifest.version**：M1 bump 到 `"0.2"`。Pydantic 默认值已处理缺失的 `entities` 字段，无额外迁移逻辑。
4. **scan_entities 部分失败**：跳过校验不通过的实体，索引合法实体，收集并返回警告列表（不再全有全无）。

