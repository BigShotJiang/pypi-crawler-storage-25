# NeonRP CLI — 需求审查与规格草案（v0.1）

> 目标：做一个**专门用来玩/开发文本RPG的CLI**，核心优势是：可续玩、可回滚、可审计、可扩展、快。

---

## 0. 产品定位（你的第0条）
**需求**：新程序名 *NeonRP cli*，从零做一个专门玩RPG的CLI。  
**审查结论**：✅保留。建议补一条“胜利条件”作为所有功能取舍标准：

- **胜利条件（建议加入）**：比 Gemini 网页版更好用的关键在于：  
  1) *断点续玩/回滚*（save/undo/branch），  
  2) *结构化命令+快速响应*（少喂上下文/少重复读文件），  
  3) *可审计*（每回合清晰变更与校验），  
  4) *可扩展*（模组/内容包/脚本）。

---

## 1. 子代理系统：创建/编辑/调试/调用
**需求**：子代理负责城镇、地下城、战斗等；体验要像 opencode/claude code。  
**审查结论**：✅保留，但建议把“子代理”拆成三层，避免做成“人格扮演”。

### 1.1 子代理三层架构（建议）
- **Agent（子代理）**：提出“意图/计划/要改哪些文件”。  
- **Rules/Engine（规则引擎）**：结算战斗、交易、掷骰、经济守恒等（确定性）。  
- **Storage（数据层）**：负责读写、索引、校验、回滚、diff。

> 这样子代理的错误不会直接污染存档；坏写入会被校验器拦住。

### 1.2 必备能力（MVP可交付）
- `agent new|edit|list|run|test|logs`
- **权限边界**：每个代理只能写它负责的目录（例如 shop 代理只能写 `game/shops/...`）
- **调试**：回放最近 N 次调用的输入上下文、输出、diff、校验结果

### 1.3 体验对标 opencode/claude code 的点
- 清晰的“计划→差异→应用”（Plan/Diff/Apply）
- 错误时给出可操作的修复建议（schema failed → 指出字段与路径）
- 一键重跑：`agent rerun --last` / `agent rerun --id <call_id>`

---

## 2. command / skill 体系（导入角色卡、创建新游戏等）
**需求**：支持 command 与 skill；例如导入 SillyTavern 角色卡、一键创建游戏。  
**审查结论**：✅保留。建议定义两类扩展点，避免混淆：

- **Command（命令）**：用户在 CLI 输入的操作（确定行为）。例：`import character`、`game new`。
- **Skill（技能/工具）**：给 AI/代理调用的“受控能力”（带权限、可审计）。例：`skill.search_lore`、`skill.create_town`。

### 2.1 命令建议（最小集合）
- `game new|load|save|status|undo|redo|branch|replay`
- `import sillytavern-card <file>`
- `export`（导出存档/世界数据包）
- `run`（跑一回合：解析玩家输入→调用代理→应用变更→输出叙事）

### 2.2 Skill 建议（第一批）
- `read_context`（按位置/任务检索最小上下文）
- `propose_changes`（产出结构化变更提案）
- `validate`（schema/规则校验）
- `apply_patch`（受控写入）
- `roll`（掷骰，写入事件日志）

---

## 3. 文件管理系统（类似 .git 的 meta/index）
**需求**：有类似 `.git` 的目录或每文件 meta，帮助 AI 快速找到数据。  
**审查结论**：✅强烈保留（这是 CLI 碾压网页版的核心之一）。

### 3.1 建议目录结构
- `.neonrp/`
  - `manifest.json`（全局索引：文件类型、id、标签、所属城镇/地下城）
  - `index/`（倒排索引/embedding/缓存）
  - `schema/`（json schema）
  - `events/`（append-only 事件日志）
  - `saves/`（快照/分支）
  - `logs/`（代理调用日志、校验报告）
  - `mods/`（模组安装区）

### 3.2 meta 方案（二选一，建议先做A）
A. **集中 manifest**：在 `.neonrp/manifest.json` 里维护所有实体索引（更快更可控）。  
B. **文件 sidecar**：`town.json` + `town.meta.json`（更分散，易碎片化）。

### 3.3 必备能力（MVP）
- `neonrp index build|update`
- `neonrp find <keyword|id|tag>`
- 引擎每回合只喂“与玩家当前状态相关”的最小片段

---

## 4. 完整游戏数据管理 + 沙盒测试
**需求**：完整的数据管理，支持沙盒游玩测试。  
**审查结论**：✅保留，但要明确“沙盒”定义，建议用**分支+快照**实现：

### 4.1 沙盒定义（建议）
- 沙盒=不影响主线存档的试玩空间
- 可从任意 save 创建：`sandbox new --from save_0021`
- 沙盒可销毁：`sandbox drop`
- 沙盒可合并（可选后期）：把沙盒某些变更 cherry-pick 回主线

### 4.2 数据一致性与可复现（建议纳入）
- 每回合记录：输入、seed、掷骰、规则版本、代理版本、变更 diff
- `replay`：从某 save 重放到最新定位问题

---

## 5. 重新审查之前建议：保留哪些？
下面是我之前给你的建议，按“对体验提升”排序，并标注保留级别：

### 必须保留（P0）
- ✅ **Resume/Undo/Branch**：断点续玩+回滚+分支（直接碾压网页版）
- ✅ **Plan→Diff→Apply + 校验器**：可审计、可控写入（防瞎改）
- ✅ **索引/最小上下文**：速度与稳定性（减少重复读文件）
- ✅ **事件日志（append-only）+ 快照**：可复现与排错

### 建议保留（P1）
- ✅ **TUI 面板/快捷命令**：更像游戏（可先做纯 CLI，后做 TUI）
- ✅ **权限边界/协议化多代理**：让多代理不是噱头（先做最小权限）

### 后期再做（P2）
- ⏳ **模组生态（mod manager）**：很强但可晚点
- ⏳ **沙盒合并（cherry-pick/merge）**：复杂，先有分支即可
- ⏳ **并行世界模拟**：等基础稳定再上

---

## 需求清单（带验收标准）

### R0 基础
- [ ] 初始化项目：`neonrp init`
- [ ] 运行回合：`neonrp run "<player input>"`
- [ ] 存档/读档：`save/load`
- [ ] undo/redo/branch

**验收**：任意回合可回滚到之前状态；分支不互相污染。

### R1 子代理
- [ ] agent 生命周期：new/edit/run/test/logs
- [ ] 每次 agent run 输出结构化提案 + diff
- [ ] 权限边界与校验拦截

**验收**：代理试图写越权文件会失败并报告原因。

### R2 命令与技能
- [ ] 命令系统（command registry）
- [ ] skill 系统（受控工具+审计）
- [ ] 导入 SillyTavern 角色卡
- [ ] 一键创建新游戏

**验收**：导入后角色出现在玩家可选列表；新游戏生成完整目录结构。

### R3 数据索引与 meta
- [ ] `.neonrp/manifest.json`
- [ ] `find` 能按 id/tag/关键词定位实体
- [ ] 每回合检索最小上下文

**验收**：大型世界（>1000文件）下，run 仍稳定且上下文不爆炸。

### R4 沙盒
- [ ] sandbox new/drop
- [ ] sandbox 与主线隔离

**验收**：沙盒内造成的变更不会影响主线 save。

---

## 变更记录（Changelog）
- v0.1：首次整理与分级（P0/P1/P2）

