# M11 Task Cards — MCP Protocol Integration

---

## M11-T0: Specs + ADR Freeze (doc-first)

**Goal**: 在编码前冻结 M11 的范围、兼容策略和架构边界。

**Deliverables**:
- `docs/M11_TASK_CARDS.md`（本文档）
- `docs/ROADMAP.md` 的 M11 段落
- ADR:
  - `docs/ADRs/0024-mcp-integration-scope-and-compatibility.md`
  - `docs/ADRs/0025-mcp-tool-router-and-permission-model.md`

**Decisions locked**:
1. M11 先做 MCP **Tools**，Resources/Prompts 延后。
2. 使用官方 `mcp` Python SDK，不自实现 JSON-RPC/传输层。
3. ToolRouter 是统一路由层，不替代 `SkillRegistry`。
4. 默认向后兼容：未配置 `mcp_servers` 时行为与 M10.1 一致。

**Acceptance**:
- 任务卡结构与执行顺序明确。
- ROADMAP 与 ADR 引用一致。

---

## M11-T1: Config Model for MCP Servers

**Goal**: 在配置层支持 MCP server 声明与权限策略。

**Changes**:
- `core/config.py`
  - 新增 `MCPServerConfig`（建议字段：`command`/`args`/`env`/`url`/`transport`/`enabled`/`permission`/`tool_permissions`/`timeout_s`）
  - 扩展 `ProjectConfig`：增加 `mcp_servers: dict[str, MCPServerConfig]`
  - 完成用户级与项目级配置的 merge 行为（保持现有策略）
- `create_default_config_template()` 增加 MCP 模板段

**Tests**:
- `tests/test_config.py`
  - mcp_servers 解析
  - 默认值与 merge 行为
  - 非法字段与回退行为

**Acceptance**:
- 配置可声明 stdio/remote server。
- 未配置时无行为变化。

---

## M11-T2: MCP Client Core (Single Server, stdio first)

**Goal**: 能连接一个 MCP server 并完成 `initialize → list_tools → call_tool`。

**Changes**:
- 新增 `core/mcp_client.py`
  - Server 启动/连接
  - 初始化握手
  - 工具枚举与调用
  - 超时与错误包装
- 可选新增 `core/mcp_types.py`（若 SDK 类型不足以直接使用）

**Tests**:
- 新增 `tests/test_mcp_client.py`
  - 最小 echo fixture server 端到端
  - 初始化失败、超时、返回非预期 payload

**Acceptance**:
- stdio server 可稳定调用。
- 错误信息可诊断，不崩主循环。

---

## M11-T3: MCP Pool + Lifecycle Management

**Goal**: 管理多个 MCP servers 的生命周期与健康状态。

**Changes**:
- 新增 `core/mcp_pool.py`
  - 按配置懒加载/启动 client
  - stop/restart/health 状态
  - 基础重连策略（建议 1 次自动重连）

**Tests**:
- 新增 `tests/test_mcp_pool.py`
  - 多 server 并存
  - server crash 后状态转移
  - restart 路径可恢复

**Acceptance**:
- 多 server 可并存且可控。
- 异常 server 不影响其他 server。

---

## M11-T4: ToolRouter Integration (Builtin + MCP)

**Goal**: 统一 tool schema 与 dispatch 入口，让 LLM 同时可见内置工具与 MCP 工具。

**Changes**:
- 新增 `core/tool_router.py`
  - `get_all_schemas()`：合并 builtin + MCP schemas
  - `dispatch()`：按命名空间路由到 builtin 或 MCP
  - 命名空间策略：`{server_name}__{tool_name}`
- 修改 `core/agent_runner.py`、`core/conversation.py`
  - `_get_tool_schemas()` 接入 ToolRouter
  - tool 执行入口接入 ToolRouter

**Tests**:
- 新增 `tests/test_tool_router.py`
  - schema 合并与去冲突
  - 路由 builtin 与 MCP tool
  - 未知 tool 错误路径

**Acceptance**:
- LLM 可看到并调用 MCP tools。
- 内置工具行为保持不变。

---

## M11-T5: Permission + Audit for MCP Calls

**Goal**: MCP 工具调用可控、可审计。

**Permission model**:
- server-level: `auto | confirm | deny`
- tool-level override: `tool_permissions`

**Changes**:
- `core/tool_router.py`
  - 集成权限判定（可复用现有权限风格）
  - `confirm` 模式对接 ask_user（或返回可确认错误，按实现阶段选择）
- 日志落盘：
  - `.neonrp/logs/mcp/<server>/<run_id>.jsonl`
  - 记录请求参数、结果摘要、耗时、权限决策

**Tests**:
- `tests/test_tool_router.py` / 新增 `tests/test_mcp_permissions.py`
  - auto/confirm/deny
  - tool-level override
  - audit log 内容与字段完整性

**Acceptance**:
- 权限策略生效。
- MCP 调用可追踪可回放。

---

## M11-T6: CLI/TUI Integration

**Goal**: 用户可在 CLI/TUI 中查看与运维 MCP servers。

**Changes**:
- 新增 `commands/mcp.py`
  - `neonrp mcp list|status|restart`
- `cli.py` 注册 `mcp` command group
- `tui/commands.py` 增加 `/mcp`
- `tui/app_v2.py` 增加 `/mcp` 分发与简要状态输出（可选 HUD 指示）

**Tests**:
- 新增 `tests/test_mcp_cli.py`
- 扩展 `tests/test_tui_commands.py` 与 `tests/test_app_v2.py`

**Acceptance**:
- CLI/TUI 都能查看 MCP server 状态。
- restart 可用且错误可见。

---

## M11-T7: Review Gate + Regression

**Goal**: 完成 M11 交付质量门禁并保证向后兼容。

**Checklist**:
- 格式/静态检查通过
- 全量测试通过
- 新增 MCP 相关测试通过
- 未配置 `mcp_servers` 的回归路径通过（行为与 M10.1 一致）
- 评审报告落地到 `reviews/`
- 文档更新：
  - `README.md`（若有用户可见命令）
  - `docs/TUTORIAL.md`（若有使用步骤变化）
  - `CHANGELOG.md`
  - `docs/PROGRESS.md`

**Acceptance**:
- M11 新能力可用。
- 无 MCP 配置时零破坏。

---

## Dependency Order

```
M11-T0 (doc-first)
  └── M11-T1 (config model)
       └── M11-T2 (single-server mcp client)
            └── M11-T3 (mcp pool lifecycle)
                 └── M11-T4 (tool router integration)
                      └── M11-T5 (permission + audit)
                           └── M11-T6 (cli/tui integration)
                                └── M11-T7 (review gate)
```

---

## Out of Scope (M11)

- MCP Resources/Prompts/Sampling 的完整落地
- MCP marketplace/registry
- 远程 OAuth/认证系统
- 编写具体业务 MCP servers（骰子/地图等）

---

## Milestone Acceptance (M11)

1. 配置层可声明 MCP servers（stdio first）。
2. LLM 能在工具列表中看到 MCP tools 并成功调用。
3. MCP 调用有权限控制与审计日志。
4. CLI/TUI 可查看 server 状态并进行基本运维。
5. 未配置 MCP 时行为与 M10.1 保持一致。
