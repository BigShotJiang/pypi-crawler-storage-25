# M3 Task Cards (LLM Integration + Skills + Import)

These task cards are sized for small PRs and for automation. Each card must pass `docs/QUALITY_GATES.md`.

质量门（每张卡片收尾必跑）：见 `docs/QUALITY_GATES.md`。

## Task dependency graph
```
H3/H4/H5/H6 (Pre-M3 housekeeping)
  └→ M3-T0 (docs/ADRs)
       └→ M3-T1 (config) ──→ M3-T2 (LLM adapter + stub)
                                └→ M3-T3 (skills) ──→ M3-T4 (agent run preview) ──→ M3-T5 (agent run --apply)
       └→ M3-T6 (import) ──→ M3-T7 (game scaffolding)
                                       └→ M3-T8 (review gate)
```
注：M3-T1（config）和 M3-T6（import）可并行开发，两者都依赖 M3-T0。

## Output format convention
延续 M1/M2 约定：所有 M3 CLI 命令支持 `--json` 输出标志（agent run/import/game new）。

---

## H3 — 修复 `agent.py:393` active_branch bug（Pre-M3 Housekeeping）

**Goal**
- 修复 `neonrp agent context` 命令中引用不存在的 `manifest.active_branch` 属性。

**Existing code**
- `src/neonrp/commands/agent.py:393` — `branch = manifest.active_branch`（应为 `manifest.current_branch`）
- `src/neonrp/core/manifest.py:32` — `current_branch: str = "main"`

**New work**
- 将 `agent.py:393` 的 `manifest.active_branch` 改为 `manifest.current_branch`
- 确认 `neonrp agent context` 命令不再报 AttributeError

**Acceptance**
- `neonrp agent context <id> --query "..."` 正常运行
- 现有测试通过

**Tests**
- 验证 `agent context` 命令的集成测试覆盖此路径

---

## H4 — `apply.py` game/ 原子替换（Pre-M3 Housekeeping）

**Goal**
- 将 `apply.py` 中的 game/ 目录替换从 rmtree + copytree 改为原子 rename 策略。

**Existing code**
- `src/neonrp/core/apply.py:149-151` — `shutil.rmtree(world_root)` + `shutil.copytree(staging_world, world_root)`
- `src/neonrp/core/storage.py` — `atomic_write_json`（已有 temp+rename 模式可参考）

**New work**
- 替换为 rename 策略：
  1. `shutil.copytree(staging_world, world_root.with_suffix('.new'))`
  2. `world_root.rename(world_root.with_suffix('.old'))`
  3. `world_root.with_suffix('.new').rename(world_root)`
  4. `shutil.rmtree(world_root.with_suffix('.old'))`
- 在 init/load 时清理可能残留的 `.new`/`.old` 目录

**Acceptance**
- 崩溃窗口内不会丢失 game/（旧目录在 rename 前仍存在）
- 现有 apply 测试通过

**Tests**
- 单测：验证 rename 策略的正常路径
- 单测：模拟中途失败后清理残留目录

---

## H5 — `retrieval.py` 空索引提示（Pre-M3 Housekeeping）

**Goal**
- 当 manifest.entities 为空时，提示用户运行 `index build`。

**Existing code**
- `src/neonrp/core/retrieval.py:93-94` — `if not manifest.entities: return []`

**New work**
- 返回空列表前记录 warning 日志
- `retrieve_context()` 返回值增加 `warning` 字段或使用 Python `logging.warning()`

**Acceptance**
- 索引为空时 stderr 或 log 包含 "index build" 提示
- 现有测试通过

**Tests**
- 单测：manifest.entities 为空时验证 warning 输出

---

## H6 — `diffing.py` delete hunk header 标准化（Pre-M3 Housekeeping）

**Goal**
- 将 delete 操作的 hunk header 改为标准 unified diff 格式。

**Existing code**
- `src/neonrp/core/diffing.py:68` — `"@@ -1,0 +0,0 @@ DELETE"`

**New work**
- 改为标准格式，例如 `@@ -1,{n} +0,0 @@`（n = 旧文件行数）

**Acceptance**
- delete diff 输出的 hunk header 符合 unified diff 规范
- 现有 diff 测试更新通过

**Tests**
- 单测：验证 delete 操作的 hunk header 格式

---

## M3-T0 — M3 Specs + ADRs (Doc-first)

**Goal**
- 冻结 M3 架构：LLM adapter Protocol、skill registry、agent run flow、import mapping、game scaffolding。

**Primary docs**
- `docs/M3_LLM_COMMANDS_SKILLS_IMPORT_DESIGN.md`
- `docs/ADRs/0008-llm-adapter-and-config.md`
- `docs/ADRs/0009-skill-tool-registry-and-auditing.md`
- `docs/ADRs/0010-sillytavern-import-mapping.md`

**Acceptance**
- 文档精确定义：LLM adapter Protocol 方法签名、stub provider 行为、skill 权限模型（per-file deny-first）
- 文档精确定义：`agent run` CLI surface、`import` CLI surface、`game new` CLI surface（含 --json）
- config + env var 约定（no secrets in repo）
- ADR 0010 更新：raw payload 使用 `meta.raw`（非 sidecar）

---

## M3-T1 — Project config: `.neonrp/config.json`

**Goal**
- 支持 provider/model 设置，不硬编码。

**Existing code**
- `src/neonrp/commands/init.py` — init 命令创建 `.neonrp/` 结构
- `src/neonrp/core/paths.py` — 路径工具函数

**New work**
- `src/neonrp/core/config.py` — 配置加载（default < config file < CLI flags）
- config 字段：`llm.provider`, `llm.model`, `llm.temperature`, `llm.max_output_tokens`, `llm.seed`
- `neonrp init` 创建空 config.json 模板（可选）
- 环境变量：`NEONRP_LLM_API_KEY` 或 provider-specific

**Acceptance**
- CLI flags override config file
- Missing config is non-fatal（使用默认值）
- config 不包含 secrets

**Tests**
- 单测：config 加载优先级（default < config < flags）
- 单测：config 文件缺失时使用默认值
- 单测：无效 config JSON 报错可操作

---

## M3-T2 — LLM adapter interface + deterministic stub provider

**Goal**
- 提供 LLM 调用的抽象层和用于测试的确定性 stub provider。

**Existing code**
- `src/neonrp/core/config.py`（M3-T1 产出）
- `src/neonrp/core/proposal.py` — Proposal 模型（stub 需要生成符合此格式的输出）

**New work**
- `src/neonrp/core/llm.py` — `LLMAdapter` Protocol + `LLMResponse` dataclass
- `src/neonrp/core/llm_stub.py` — `StubAdapter`（支持 `fixture_path` 参数；无 fixture 时返回 hardcoded 最小 proposal）
- `src/neonrp/core/llm_openai.py`（或其他 provider）— 真实 provider 实现（可选，M3 至少一个）
- 所有 LLM I/O 记录到 `llm_input.json` + `llm_raw.txt`

**Acceptance**
- `--provider stub` 始终返回确定性 proposal
- `--provider stub --fixture <path>` 加载指定 proposal fixture
- 所有 LLM I/O 记录到 `.neonrp/logs/agents/<run_id>/`
- 真实 provider API 错误返回 exit code 2

**Tests**
- 单测：stub adapter 确定性（同输入同输出）
- 单测：stub fixture 加载
- 单测：LLM response 解析（valid/invalid proposal text）

---

## M3-T3 — Skill tool registry (permission-aware) + logging

**Goal**
- 实现 LLM/agent runner 可调用的受控工具，带权限检查和审计。

**Existing code**
- `src/neonrp/core/permissions.py` — glob 匹配、deny 优先逻辑
- `src/neonrp/commands/context.py` / `src/neonrp/core/retrieval.py` — context 核心逻辑
- `src/neonrp/commands/find.py` — find 核心逻辑

**New work**
- `src/neonrp/core/skills.py` — skill registry + built-in skills（read_context, find, read_file, list_entities）
- 每个 skill 的 JSON schema（供 LLM tool calling 使用）
- 权限检查：per-file deny-first；被拒路径静默过滤，记录 warning
- 审计日志：`.neonrp/logs/skills/<run_id>.jsonl`

**Acceptance**
- 权限检查按文件粒度执行（deny_globs 优先）
- 被拒路径在 skill 返回结果中过滤，不中止运行
- 每次 skill 调用记录到 JSONL（timestamp, run_id, agent_id, skill_name, args, result_summary, error, duration_ms, denied_paths）
- 所有 built-in skills 有 JSON schema 定义

**Tests**
- 单测：deny-first + read_globs 权限检查（per file）
- 单测：被拒路径过滤行为
- 单测：JSONL 审计日志格式

---

## M3-T4 — `neonrp agent run` (LLM → proposal → diff preview)

**Goal**
- 将 query 转为经过验证的 proposal 并预览。

**Existing code**
- `src/neonrp/commands/agent.py` — agent 命令组（已有 apply/logs/context）
- `src/neonrp/core/apply.py` — `generate_run_id()`, `save_run_logs()`
- `src/neonrp/core/diffing.py` — `render_diff()`, `render_diff_summary()`
- `src/neonrp/core/retrieval.py` — `retrieve_context()`
- `src/neonrp/core/llm.py` — LLM adapter（M3-T2 产出）
- `src/neonrp/core/skills.py` — skill registry（M3-T3 产出）

**New work**
- `agent.py` 新增 `run` 子命令：`neonrp agent run <id> --query "..." [--provider <name>] [--json]`
- Pipeline: load agent → retrieve context → build user prompt → call LLM → parse proposal → render diff → save logs
- 不带 `--apply` 时为 dry-run（显示 plan + diff，不写入）
- 日志：llm_input.json, llm_raw.txt, proposal.json, diff.patch

**Acceptance**
- 产出 `proposal.json` + `diff.patch` 到 `.neonrp/logs/agents/<run_id>/`
- `--json` 输出 run_id, proposal_path, diff_path, summary
- LLM 返回无效 proposal 时 exit code 1，包含解析错误详情
- `--provider stub` 模式可完成完整流程

**Tests**
- 集成：`CliRunner` 覆盖 agent run (stub provider)
- 集成：无效 LLM 输出的错误处理

---

## M3-T5 — `neonrp agent run --apply` (end-to-end)

**Goal**
- 将 `agent run` 连接到 M2 apply pipeline，实现完整闭环。

**Existing code**
- `src/neonrp/core/apply.py` — `apply_proposal()`（M2 已实现）
- `src/neonrp/commands/agent.py` — `agent run`（M3-T4 产出）

**New work**
- `agent run` 增加 `--apply` flag
- `--apply` 时调用已有的 `apply_proposal()` 完成 staging → validate → commit → event append
- apply 成功后更新 logs（apply.json）

**Acceptance**
- Apply 产出 event（type=agent, actor=agent_id）
- `find`/`context` 能观测到 apply 后的新/更新实体
- 日志包含完整链：llm_input → llm_raw → proposal → diff → validation → apply

**Tests**
- E2E：subprocess 调 `neonrp agent run --provider stub --apply`，验证 exit code + game/ 变更 + event log
- 集成：stub provider + apply → find 能查到新实体

---

## M3-T6 — `neonrp import sillytavern-card <file>`

**Goal**
- 将 SillyTavern 角色卡导入为 `game/character/<id>.json` 实体。

**Existing code**
- `src/neonrp/core/validation.py` — `validate_game_data()` 用于验证导入结果
- `src/neonrp/core/indexing.py` — `scan_entities()` 用于索引导入的实体
- `src/neonrp/schema/game_entity.schema.json` — 实体 schema

**New work**
- `src/neonrp/commands/import_cmd.py` — `neonrp import sillytavern-card <file> [--id <id>] [--json]`
- `src/neonrp/core/importers/sillytavern.py` — 映射逻辑（JSON card → world entity）
- 输出：`game/character/<id>.json`（id/kind/name/summary/tags/meta.source/meta.raw）
- ID 策略：`--id` > name kebab-case > 冲突追加 `-2`, `-3`
- M3 仅支持 JSON 格式；PNG 推迟到 M3.5+

**Acceptance**
- 导入的实体通过 `neonrp validate`
- 导入的实体可被 `index build` 索引
- `meta.raw` 包含完整原始 payload
- ID 冲突自动解决
- 无效输入文件 exit code 1

**Tests**
- 单测：mapping 稳定性（同输入同输出）
- 单测：ID kebab-case 转换 + 冲突解决
- 集成：import → validate → index build

---

## M3-T7 — `neonrp game new` scaffolding

**Goal**
- 创建可玩的 starter world。

**Existing code**
- `src/neonrp/core/validation.py` — 验证生成的实体
- `src/neonrp/core/storage.py` — atomic write 工具

**New work**
- `src/neonrp/commands/game.py` — `neonrp game new [--template <name>] [--force] [--json]`
- hardcoded 默认模板：player.json, start-town.json, old-sage.json（至少 3 个实体）
- `--force` 覆盖已有 game/ 文件（无 --force 时拒绝覆盖）

**Acceptance**
- 输出通过 `neonrp validate`
- 输出可被 `index build` 索引
- `--force` 可覆盖已有实体
- 无 `--force` 时已有实体 → exit code 1
- `--json` 输出创建的文件列表

**Tests**
- 集成：init → game new → validate → index build
- 单测：--force 覆盖 vs 无 --force 拒绝

---

## M3-T8 — Review Gate

**Goal**
- 运行 `opencode run` 审查并落盘到 `reviews/`。

**Acceptance**
- Review saved under `reviews/`
- ALL review findings 记录到 `docs/PROGRESS.md`（含 disposition）
- Tests green after fixes
- ROADMAP + PROGRESS updated

