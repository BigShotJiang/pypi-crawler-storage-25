# M15 Task Cards — More Complex Game Content + Narrative-Oriented Tools

> **Scope:** 在 M13 完成必要 runtime / loop 能力移植之后，推进更复杂的游戏内容与叙事工具集扩展
> **Core Insight:** 工具数量 ≠ 游戏体验好坏。决定体验的是"工具能否伪装成角色行为"
> **Target:** 让 NeonRP 能支持更复杂的游戏内容（神乐岛级别），同时保持角色一致性
> **非目标:** 不做开源发布包装（归 `L13`），不做 WorldLines 体验层（归 `L14`），不加通用开发者工具（Bash/REPL/WebFetch 永久不加）

> **Status:** 本文档包含上一版里程碑拆分前的历史草案。按新命名体系，偏 runtime / core loop 的基础能力将逐步迁移到 `M13`，M15 聚焦更复杂的游戏内容与叙事能力。

---

## M15 的两条主线 + 一个高规格 NPC 分支

```
主线 A: 🔧 Core Loop 基础设施（从 CC 学）
├── Context compression（让长 session 不崩）
├── Dynamic turn management（不再是死板的 20 turn）
├── Persistent sub-agent + mailbox（NPC 后台存活）
└── turn_sequence 执行器（神乐岛 loop_config 实装）

主线 B: 🎭 Narrative Tool Expansion（游戏体验导向）
├── 工具设计原则确立
├── 叙事类新工具实装
├── Tool Design Principles 文档
└── 4 本子全部迁移到新工具集

分支 C: 🫀 Soul NPC / Heroine System（高规格 NPC）
├── 参考 `llm-rpg-starter` heroine 设计思路
├── `Soul.md` + memory + relationship + stance 的人格层
├── 独立价值判断与非迎合性（不是舔狗）
└── 用于关键 NPC，而非所有 NPC 默认启用
```

---

## M15 分支 C：Soul NPC / Heroine System（建议在 M15 主线稳定后启动）

> **Positioning:** 这是 M15 下的一个高规格 NPC 分支，不是所有 NPC 的默认实现。
> **Reference:** 参考 `llm-rpg-starter` 的 heroine 设计思路：用更细的人格层维护角色长期一致性，但在 NeonRP 中收敛为更可审计、可状态化、可 benchmark 的结构。
> **Recommended timing:** 建议在 M15 主线（复杂内容、叙事工具、关键世界迁移）基本稳定后启动，可视为 `M15.x`。

### Goal

让关键 NPC 拥有稳定且可推导的人格内核：
- 会因为亲近而靠近，但不会无条件迎合玩家
- 会因为厌恶或价值冲突而主动疏远
- 对玩家与其他 NPC 有差异化态度
- 行为符合其经历、创伤、欲望、底线与价值观

### Suggested design

**核心文件层：**
- `Soul.md`：身份、经历、价值排序、底线、欲望、创伤、表达风格
- `memory.json`：关键记忆与召回线索
- `relationship.json`：trust / warmth / respect / fear / disgust / dependency 等维度
- `stance.json`：对当前议题、人物、目标的立场
- `scene_state.json`：当前场景的情绪、距离感、合作意愿

**逻辑分层：**
- `mind`：内在判断，不直接对玩家输出
- `memory`：写入、召回、冲突解决
- `action`：靠近、拒绝、协作、疏远、保护、试探
- `dialogue`：说什么、怎么说、什么时候不说
- `narrative`：由 narrator / orchestration 层整合进世界叙事

### Why this belongs after M15 mainline

- 依赖 M13 的 runtime / loop 能力（persistent sub-agent、turn orchestration、context management）
- 依赖 M14 的 `RP-10` benchmark 作为验收基线
- 依赖 M15 主线提供更复杂的世界内容与长时互动场景

### Acceptance (branch-level)

- 至少 1 个关键 NPC 使用 `Soul.md` 高规格结构落地
- NPC 亲近 ≠ 服从，疏远 ≠ 失去人格一致性
- 行为能从 `Soul.md` 与状态层推导
- `RP-10: Independent Personality with Soul.md` 可作为主要验收 benchmark

---

## 核心原则（所有 M15 任务都要遵守）

### Tool Design Principles

**每个新工具都必须满足：**

1. **能伪装成角色行为** — 工具调用对玩家来说像一个游戏动作
   - ✅ `roll_check(stat, difficulty)` → 玩家看到 "GM 投骰子"
   - ❌ `random_int(1, 100)` → 玩家看到 "系统生成随机数"

2. **名称用游戏术语，不用技术术语**
   - ✅ `recall_memory`, `lore_lookup`, `time_passage`
   - ❌ `grep_session`, `read_md`, `update_clock`

3. **返回值对叙事有用**
   - ✅ `{"memory": "三天前你在酒馆见过 Elena", "confidence": 0.9}`
   - ❌ `{"files": ["tavern_0312.json", "elena.json"], "matches": 2}`

4. **不能暴露底层实现**
   - ✅ `time_passage(hours=3)` → 世界推进
   - ❌ `update_field("run_state.time", "+3h")` → 直接改数据

5. **永久禁止通用工具** — 破坏 "LLM 是游戏角色" 的幻觉
   - ❌ Bash / Shell
   - ❌ Python REPL
   - ❌ WebFetch / curl / HTTP
   - ❌ git operations
   - ❌ 任何"跳出游戏世界"的工具

**Why:** LLM 的工具箱决定它的内隐人设。给它 coding 工具 → 它变成 coding assistant。给它叙事工具 → 它变成 narrator。

---

## Phase A: Core Loop 基础设施

### M15-T1: Context Compression (P0)

**Goal:** 解决 RP session 50+ turns 后 context 溢出的问题。

**Current state:**
- `agent_runner.py` L891-918: 只有 `_estimate_tokens()` (chars//4) + BUDGET_TERMINATION_THRESHOLD
- 无压缩，到 100% budget 直接终止
- RP 长 session 常见（50-100 turns），当前设计不可用

**Changes:**

```
新文件: src/neonrp/core/context_compact.py
──────────────────────────────────────────
class ContextCompactor:
    def compact(messages, max_tokens, strategy) → messages
    
    Strategies:
    1. "truncate" — 删最老（当前行为的封装）
    2. "summarize" — LLM 压缩旧消息为要约
    3. "semantic" — 重要性打分 + 选择性保留
```

**Phase 1 (Day 1-2)**: truncate strategy 重构
- 把现有 budget check 逻辑抽出来
- 加个 config: `context_strategy: "truncate" | "summarize" | "semantic"`
- default 改为 `truncate`，向后兼容

**Phase 2 (Day 3-5)**: summarize strategy
- 触发条件：context 达到 80%
- 找最老的 N 个 turn（保留最近 10 turn 不动）
- 对这些 turn 调 LLM："把这段对话要约为 200 token"
- 替换成 `Message(role="system", content="[Earlier summary]: ...")`
- 测试：100 turn session 能跑完，要约后能继续叙事

**Phase 3 (Day 6-10)**: semantic strategy
- 给每个 message 打重要性分数:
  - `submit_proposal` 结果: 1.0（最高）
  - `ask_user` + 回答: 0.9
  - 角色情绪变化: 0.8
  - 读文件返回: 0.4
  - 一般对话: 0.5
- 按分数保留 top K，剩下的 summarize
- 保证事件连续性（重要转折点不能丢）

**Tests:**
- `tests/test_context_compact.py` 新增
- 100 turn session 完走（不被 budget 终止）
- 要约后叙事连贯（人类评估）
- 重要 proposal 结果必须保留（assert）

**Acceptance:**
- 100 turn Stone Ford Town session 能跑完
- 50 turn tokyo-science-university session 无丢失重要事件
- config 可切换三种 strategy

---

### M15-T2: Dynamic Turn Management (P0)

**Goal:** 20 turn 固定限制改为智能管理。

**Current state:**
- `MAX_AGENTIC_TURNS = 20` 硬编码
- 已经在 L13-T1 config 化（default 50）
- 但仍然是死板的上限，没有智能管理

**Changes:**

```
变更: core/agent_runner.py run_agent_agentic()

1. 从 config 读 max_turns（已完成 in L13-T1）

2. Adaptive turn adjustment:
   - 信息收集阶段（连续 read 工具）→ 宽容
   - Proposal 提交失败 → 加强警告
   - Idle 检测：3 连续无意义 turn → 早期终止
   - Context compact 成功 → 解锁更多 turn

3. Budget-aware remaining turn estimate:
   remaining_turns_est = (max_budget - current) / avg_per_turn
   if est < 3: 注入 "[URGENT: submit proposal now]"
```

**Tests:**
- `tests/test_dynamic_turns.py` 新增
- 30 turn 对话完走
- Idle detection 工作（3 连续 read → early terminate）
- Budget 警告后 compact → 延命

**Acceptance:**
- 30 turn 的复杂场景能跑完
- 无意义循环能早停
- 与 context compact 协作正常

---

### M15-T3: Persistent Sub-Agent + Mailbox (P1)

**Goal:** NPC 能"后台存活"，玩家不在时 agent 也能有活动。

**Current state:**
- `task()` tool → 递归调用 `run_agent_agentic()` → proposal 后死亡
- `active_agent.json` 只追踪当前控制权，不保存 messages
- 无 agent 间通信

**Design:**

```
新文件: src/neonrp/core/agent_pool.py
────────────────────────────────────
class AgentPool:
    active_agents: dict[run_id, AgentInstance]
    
    spawn(agent_id, prompt) → run_id
    resume(run_id, new_input) → result
    kill(run_id)
    list_alive() → list[AgentInstance]
    
class AgentInstance:
    run_id, agent_id
    messages: list[Message]  # 跨 turn 保留
    last_active: datetime
    state: running | waiting | completed

新文件: src/neonrp/core/mailbox.py
───────────────────────────────────
class Mailbox:
    send(from_agent, to_agent, message)
    receive(agent_id) → list[Message]
    # 存储: .neonrp/mailbox/{agent_id}.jsonl

新 skills:
  send_message(target_agent, content)
  read_inbox() → list[messages]
```

**Changes:**
- `agent.json` 新字段: `delegation_mode: "one-shot" | "sticky" | "persistent"`
- `persistent` 模式: sub-agent 存入 AgentPool，不死亡
- `task()` tool 支持 resume_run_id（已有但未实装）
- narrator 可以 "激活" 一个 NPC 作为后台 agent

**Game experience:**
- 玩家在酒馆和 Mara 聊完离开
- Mara 作为 persistent agent 继续 "存活"，有自己的 mailbox
- 玩家 10 turn 后回酒馆 → Mara 还记得之前的对话，且可能已经发生了新事（被其他 agent send_message 触发）

**Tests:**
- `tests/test_agent_pool.py` 新增
- spawn → 跨 turn 存活 → resume → messages 保留
- mailbox send/receive
- max_pool_size 限制（避免无限增长）

**Acceptance:**
- 10 turn 后 sub-agent 仍能被 resume 并记得上下文
- NPC 间能通过 mailbox 通信
- 性能：pool 支持至少 20 个并发 agent instance

---

### M15-T4: turn_sequence 执行器（神乐岛修复）(P1)

**Goal:** 把 kagura `loop_config.turn_sequence` 真正跑起来。

**Current state:**
- `agents/game-master/agent.json` 定义了 9 个 agent 的 turn_sequence
- 但 `dispatcher.py` 只做 trigger 匹配，完全忽略 sequence
- 结果：神乐岛看起来有 game loop，实际上 agents 乱切

**Design:**

```
新文件: src/neonrp/core/game_loop.py
────────────────────────────────────
class GameLoopExecutor:
    phases: list[Phase]
    
    async def execute_turn(user_input):
        # Phase 1: Route (deterministic)
        target_phases = self.match_phases(user_input)
        
        # Phase 2: Execute agents by phase
        for phase in target_phases:
            if phase.parallel:
                results = await asyncio.gather(*[
                    run_agent(aid, user_input) for aid in phase.agents
                ])
            else:
                results = [
                    run_agent(aid, user_input) 
                    for aid in phase.agents
                ]
        
        # Phase 3: Merge proposals
        merged = self.merge_proposals(results)
        apply_proposal(merged)
        
        # Phase 4: Narrate (narrator always last)
        narrative = run_agent("narrator", merged.summary)
        
        return narrative
```

**Changes:**
- `conversation.py` 新增 game_loop 模式开关（from config）
- `loop_config.turn_sequence` 被 GameLoopExecutor 读取
- `required: true` 的 agent 如果失败 → 整个 turn 失败
- `required: false` 的 agent 失败 → warning + 继续
- Proposal merge 策略：后面的 agent 覆盖前面的（同一文件的情况下）

**Tests:**
- `tests/test_game_loop.py` 新增
- kagura-island 能用 GameLoopExecutor 完走 5 turn
- 并行 agent 执行正确
- Proposal merge 冲突解决

**Acceptance:**
- 神乐岛的 9 agent turn_sequence 能按顺序/并行执行
- narrator 最后运行，能看到所有其他 agent 的结果
- 与现有 dispatcher 模式（单 agent）共存（config 切换）

---

## Phase B: Narrative Tool Expansion

### M15-T5: Tool Design Principles Doc (Day 1)

**Goal:** 文档化工具设计原则，作为后续工具的评审标准。

**Deliverable:**
- `docs/TOOL_DESIGN_PRINCIPLES.md` 新增

**Content outline:**
1. Affordance Theory — 为什么工具决定 LLM 人设
2. 5 条核心原则（见文档顶部）
3. 永久禁止清单（Bash/REPL/WebFetch/git）
4. 工具分类: SANDBOXED / GAME_STATE / NARRATIVE / COMPUTATIONAL
5. 添加新工具的 checklist
6. 对比案例:
   - ✅ `resolve_action` — 符合所有原则
   - ❌ `generic_eval` — 违反原则 1, 2, 4
   - ✅ `recall_memory` — 新工具示例
   - ❌ `grep_files` — 太暴露底层

**Acceptance:**
- 所有 M15-T6 之后的工具设计必须引用这个文档
- 现有工具的"合规性评估表"

---

### M15-T6: `recall_memory` Tool (Day 2-3)

**Goal:** Agent 能"回忆"之前的对话/事件，像角色有记忆。

**Current state:**
- Session JSONL 存了所有历史，但 agent 无法显式查询
- `read_context` 只查 entity，不查 session 历史

**Design:**

```python
SKILL_SCHEMAS["recall_memory"] = {
    "name": "recall_memory",
    "description": (
        "Recall a specific memory from earlier in the story. "
        "Use this when you need to remember what happened before, "
        "what a character said, or how the player reacted to something. "
        "This mimics a character 'remembering' something."
    ),
    "parameters": {
        "query": "natural language memory query",
        "max_turns_back": "optional, default 50",
        "semantic": "bool, use embedding search if true"
    }
}

# Implementation:
def recall_memory(query, max_turns_back=50, semantic=False):
    session = read_session(max_turns=max_turns_back)
    if semantic:
        # embedding-based retrieval
        matches = embed_search(query, session)
    else:
        # keyword match
        matches = keyword_search(query, session)
    
    # Return in narrative-friendly format
    return {
        "memories": [
            {
                "when": "3 turns ago",
                "content": "Player said 'I don't trust Elena'",
                "confidence": 0.85
            }
        ]
    }
```

**Key design:**
- 返回值是 "memory style"，不是 "file style"
- `when` 用相对时间（"3 turns ago"）而不是 turn 编号
- `confidence` 让 narrator 知道该不该 100% 相信

**Tests:**
- tokyo-science-university: player 修改 X 帖子后，narrator recall_memory → 能找到之前的对话
- 神乐岛: 多 agent 通过 recall_memory 保持跨 turn 一致性

---

### M15-T7: `roll_check` Tool (Day 4-5)

**Goal:** 伪装成 GM 投骰子的确定性计算工具。

**Spec source of truth:**
- `docs/ADRs/0027-deterministic-check-tools.md`

**Current state:**
- `resolve_action` 只有 5 个固定动作（damage/heal/buy/sell/move）
- 无法做一般的技能检定

**Minimum implementation (Phase 1):**

```python
SKILL_SCHEMAS["roll_check"] = {
    "name": "roll_check",
    "description": (
        "Roll dice for a skill check or contested action. "
        "Use this when a character attempts something with uncertain outcome. "
        "Narrate the roll as if you (the GM) are rolling physical dice."
    ),
    "parameters": {
        "character_id": "who is making the check",
        "stat": "which stat (STR/DEX/INT/CHA/...)",
        "difficulty": "integer 1-30 or preset (easy=10, medium=15, hard=20, epic=25)",
        "modifier": "optional situational modifier",
        "description": "what they're trying to do (for log)"
    }
}

def roll_check(character_id, stat, difficulty, modifier=0, description=""):
    char = load_character(character_id)
    stat_value = char["stats"]["attributes"].get(stat, 10)
    
    # Deterministic roll using run_id + turn hash (reproducible)
    roll = deterministic_d20(run_id, character_id, turn)
    
    total = roll + stat_value + modifier
    success = total >= difficulty
    
    return {
        "roll": roll,
        "stat_bonus": stat_value,
        "modifier": modifier,
        "total": total,
        "difficulty": difficulty,
        "success": success,
        "narration_hint": (
            "critical success" if roll == 20 else
            "critical failure" if roll == 1 else
            "success" if success else "failure"
        )
    }
```

**Key design:**
- 这是 tool，不是 specialist
- Phase 1 只实现 `roll_check`
- 确定性优先：显式 `seed` 优先，否则用 `run_id + agent_id + normalized args + call index` 派生种子
- 返回值包含 `narration_hint`，narrator/orchestrator 知道该怎么描述
- 不是真随机，是伪装成随机的可重现计算

**Tests:**
- 相同输入 → 相同 roll（reproducibility）
- `undo` 后 roll 一致（不会漂移）
- Critical hit/miss 叙事提示正确

---

### M15-T8: `time_passage` Tool (Day 6)

**Goal:** 让游戏时间可控地流逝，并触发对应的 NPC 行为。

**Design:**

```python
SKILL_SCHEMAS["time_passage"] = {
    "name": "time_passage",
    "description": (
        "Advance game time and trigger scheduled events. "
        "Use this for rest, travel, waiting, or montage sequences. "
        "Other characters may act during this passage of time."
    ),
    "parameters": {
        "hours": "how many game hours pass",
        "player_activity": "what player is doing (sleeping, traveling, waiting)"
    }
}

def time_passage(hours, player_activity):
    # Advance world clock
    current_time = load_timeline()
    new_time = current_time + timedelta(hours=hours)
    
    # Fire scheduled events
    events = load_scheduled_events(current_time, new_time)
    
    # Send wake-up signal to persistent NPC agents (if M15-T3 done)
    for npc in active_npcs():
        mailbox.send("time-master", npc, 
            f"{hours} hours passed. You were: {npc.last_action}")
    
    return {
        "new_time": new_time.isoformat(),
        "events_fired": [e.id for e in events],
        "npc_changes": [{"id": npc.id, "status": npc.status_after(hours)}]
    }
```

**Tests:**
- 睡觉 8 小时 → HP/MP 恢复、时间推进、早晨事件触发
- NPC 在时间流逝期间有变化（需要 M15-T3）

---

### M15-T9: `lore_lookup` Tool (Day 7)

**Goal:** Agent 能查世界观/背景信息，像角色"知道这些事"。

**Design:**

```python
SKILL_SCHEMAS["lore_lookup"] = {
    "name": "lore_lookup",
    "description": (
        "Look up lore, history, or background info about the game world. "
        "Use this when a character would plausibly know something. "
        "Returns lore in a narrative-friendly format."
    ),
    "parameters": {
        "topic": "what to look up",
        "character_knowledge_level": "optional, 'common' | 'rare' | 'secret'"
    }
}

def lore_lookup(topic, character_knowledge_level="common"):
    # Search game/lore/*.md and game/world/*.json
    matches = search_lore(topic)
    
    # Filter by knowledge level
    filtered = [m for m in matches 
                if m.level <= character_knowledge_level]
    
    return {
        "lore": [
            {
                "topic": m.topic,
                "content": m.content,
                "commonly_known": m.level == "common"
            }
            for m in filtered
        ]
    }
```

---

### M15-T10: `npc_memory_access` Tool (Day 8)

**Goal:** 访问 NPC 的记忆/情绪/关系状态（character-agent 数据）。

**Design:**

```python
SKILL_SCHEMAS["npc_memory_access"] = {
    "name": "npc_memory_access",
    "description": (
        "Access an NPC's memory, emotions, or relationships. "
        "Use this before having an NPC speak to reflect their current state. "
        "Returns data formatted as 'what the NPC is feeling/remembering'."
    ),
    "parameters": {
        "npc_id": "which NPC",
        "aspect": "memory | emotion | relationship | goals"
    }
}

def npc_memory_access(npc_id, aspect):
    npc = load_character(npc_id)
    agent_data = npc.get("agent", {})
    
    if aspect == "memory":
        return {
            "short_term": agent_data["memory"]["short_term"][-5:],
            "recent_impression_of_player": 
                find_player_related(agent_data["memory"])
        }
    elif aspect == "emotion":
        return {
            "current_mood": agent_data["emotional_model"]["mood"],
            "affection_to_player": agent_data["emotional_model"]["affection"].get("player-001")
        }
    # ... etc
```

---

### M15-T11: `world_tick` Tool (Day 9-10)

**Goal:** 模拟世界中其他地方发生的事（"同时其他 NPC 在做什么"）。

**Design:**

```python
SKILL_SCHEMAS["world_tick"] = {
    "name": "world_tick",
    "description": (
        "Simulate what happens elsewhere in the world during this turn. "
        "Other NPCs act, events progress, the world lives on. "
        "Use sparingly - only for significant time passages or location changes."
    ),
    "parameters": {
        "duration_hours": "how much world time to simulate",
        "location_focus": "optional, which locations to tick"
    }
}

def world_tick(duration_hours, location_focus=None):
    # For each active NPC agent (M15-T3 persistent agents)
    # Fire async tasks to let them act
    
    tick_results = []
    for npc in active_npcs(location_focus):
        result = npc.tick(duration_hours)  # Uses persistent agent
        tick_results.append(result)
    
    # Aggregate into narrative summary
    return {
        "world_events": tick_results,
        "summary": llm_summarize(tick_results)
    }
```

**Depends on:** M15-T3 (persistent sub-agents)

---

## Phase C: Migration

### M15-T12: 4 本子迁移到新工具集 (Day 11-14)

**Goal:** 把 4 个现有本子的 agent 定义更新，使用新工具。

**Scope:**
- 神乐岛 → 用 game_loop + 所有新工具
- 列车本子 → 加 recall_memory + roll_check
- 常暗之厢 → 加 time_passage
- 石津岛 → 加 lore_lookup

**Per-world checklist:**
- [ ] agent.json 更新 tools 白名单（加新工具）
- [ ] system.md 更新（说明何时用新工具）
- [ ] 完整 play-through 测试（10+ turns）
- [ ] 记录体验改善 → `reviews/m15-world-migration.md`

**Acceptance:**
- 神乐岛能跑通完整 game loop（不再乱切）
- 列车本子 narrator 能主动 recall player 的 X 帖子
- 所有本子在 50+ turn session 中稳定

---

## M15 Acceptance (整体)

### 功能指标
- [ ] 100 turn session 不被 context 溢出（compression 工作）
- [ ] 神乐岛 game_loop 跑通 10 turn
- [ ] Persistent sub-agent 支持 10 turn 后 resume
- [ ] 5 个新叙事工具全部实装 + test 覆盖

### 体验指标
- [ ] 50 turn tokyo-science-university 无角色漂移
- [ ] 神乐岛 9 agent 按 turn_sequence 正确运行
- [ ] 新工具在体验测试中无 "破绽"（不会让玩家感觉到底层实现）

### 合规指标
- [ ] 所有新工具通过 Tool Design Principles 检查
- [ ] 无 Bash/REPL/WebFetch 类工具被添加

---

## 时间线估算

| Phase | 任务 | 工期 |
|-------|------|------|
| A | Context compression | 10 天 |
| A | Dynamic turn management | 2 天 |
| A | Persistent sub-agent + mailbox | 7 天 |
| A | turn_sequence 执行器 | 5 天 |
| B | Tool Design Principles doc | 1 天 |
| B | 5 个新叙事工具 | 8 天 |
| C | 4 本子迁移 | 4 天 |
| **合计** | | **~37 天（约 5-6 周）** |

**推荐开始时间：** 待 M13 完成后（建议在能力迁移复盘后立即启动）
**推荐结束时间：** 6/05（Phase A + B + C 完整交付）
**并行建议：** Phase A 和 Phase B 可并行（T1-T4 + T5-T11 同时进行）

---

## 不做清单（M15 明确不做）

- ❌ 通用 Bash/REPL/WebFetch 工具（永久不做）
- ❌ Team mode 完整实装 → M16
- ❌ WorldLines Tauri 桌面客户端 → L14
- ❌ BGM/文生图 → L14
- ❌ NeurIPS 论文完整版 → 另一条线
- ❌ 大重构 core loop → 只改 compact + turn management，不动主流程

---

## 与其他 Milestone 的关系

```
L13 (发布) → M13 (Claude Code 必要能力移植) → M15 (更复杂游戏内容)
                                              ↓
L14 (体验层) 并行，不冲突                        ↓
                                              M16 (Team mode)
```
