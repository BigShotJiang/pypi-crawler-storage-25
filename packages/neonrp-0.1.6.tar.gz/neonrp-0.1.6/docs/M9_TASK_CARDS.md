# M9 Task Cards — 对话循环 + TodoManager + Skills

---

## M9-T0: Specs + Design Doc (doc-first)

**Goal**: Establish design decisions and task breakdown before coding.

**Deliverables**:
- `docs/M9_TASK_CARDS.md` — this document
- M9 section in `docs/ROADMAP.md`
- Diagnostic report: `reviews/diagnostic_report.md`

**Design decisions resolved**:
1. Three modes: Build (default, direct r/w), Sandbox (Proposal pipeline), Play (direct r/w, game focus)
2. Build/Play stop condition: model natural end (`stop_reason=end_turn`), not `submit_proposal`
3. Conversation history: full messages list passed to LLM each turn, managed by `ConversationSession`
4. Auto event+checkpoint: after each turn with `files_modified`, reuse `event_log.py` + `checkpoint.py`
5. TodoManager: max 20 items, up to 1 in_progress; tool injected as `TodoWrite`
6. SkillLoader: YAML frontmatter + markdown body; Layer 1 (descriptions) in system prompt, Layer 2 (content) as tool_result
7. New TUI replaces current as default; old TUI accessible via `--legacy`
8. SkillRegistry `direct_write_globs` already supported — no changes to `skills.py`

**Acceptance**: Task cards created. ROADMAP updated. Diagnostic report reviewed.

---

## M9-T1: Conversation Engine (`conversation.py`)

**Goal**: Persistent conversation loop with cumulative message history, replacing one-shot `run_agent_agentic()` for interactive use.

**Core difference from `agent_runner.py`**:
- Receives **full message history** from caller (not single query)
- Build/Play: stops when `result.finished == True` (model natural end)
- Sandbox: stops on `submit_proposal` (existing behavior)
- Tracks `files_modified` from write_file/edit_file calls
- New `on_tool_use` callback for TUI tool indicators

**Changes**:
- `core/conversation.py` (CREATE ~450 lines):
  - `ConversationTurnResult` dataclass: success, assistant_message, files_modified, tool_calls_made, turns_used, todo_snapshot, error, usage
  - `run_conversation_turn(root, agent_id, messages, mode, provider, max_turns, on_chunk, on_tool_use, on_ask_user, todo_manager, skill_loader)`: single-turn engine extracting `agent_runner.py` loop pattern
  - `ConversationSession` class: manages messages list, mode, todo, skills; `send()` orchestrates turn + persistence + auto-event; `set_mode()`, `clear()`, `resume()`
  - Build mode SkillRegistry: `direct_write_globs=["game/**"]`, no `submit_proposal`, adds `TodoWrite` + `Skill`
  - Sandbox mode SkillRegistry: `direct_write_globs=[]`, keeps `submit_proposal`
  - Auto-event on files_modified: `append_event(type="build")` + `create_checkpoint()` + manifest update
  - Context management: `truncate_session()` when approaching token limit (preserve system + recent N turns)

**Reused code**:
- Streaming loop: `agent_runner.py` L713-748
- Tool execution: `agent_runner.py:_execute_tool()` L197-247
- Budget control: `agent_runner.py` L688-710
- SkillRegistry creation: `agent_runner.py` L616-620
- Session persistence: `session.py` (append_message, read_session_messages, truncate_session)
- Event/checkpoint: `event_log.py`, `checkpoint.py`, `apply.py` L166-217

**Tests** (`tests/test_conversation.py`): ~25
- Turn execution with stub LLM (text reply, tool call, multi-turn)
- Build mode: direct write succeeds, submit_proposal absent
- Sandbox mode: submit_proposal required, direct write blocked
- files_modified tracking
- Auto event + checkpoint creation after file modifications
- ConversationSession.send() full flow (persist + event + checkpoint)
- ConversationSession.clear() / set_mode()
- Message history accumulation across multiple sends
- Context truncation when history exceeds limit
- on_chunk / on_tool_use / on_ask_user callback invocation
- Error handling (LLM failure, tool failure, budget exceeded)

**Files**: `core/conversation.py`, `tests/test_conversation.py`

---

## M9-T2: TodoManager (`todo.py`)

**Goal**: Task planning tool for agents, ported from learn-claude-code v2.

**TodoManager behavior**:
- `update(items)`: validate + replace task list; constraints: max 20 items, at most 1 `in_progress`, required fields (content, status), optional `activeForm` (falls back to content)
- `render()`: text output `[x] done / [>] working / [ ] pending`
- Tool schema: `TodoWrite` with `items` array parameter

**Changes**:
- `core/todo.py` (CREATE ~80 lines): `TodoManager` class with `update()`, `render()`, validation
- `core/conversation.py`: Handle `TodoWrite` tool call in tool dispatch, call `todo_manager.update()`, return rendered result

**Tests** (`tests/test_todo.py`): ~12
- Valid update with all states
- Max 20 items constraint
- At most 1 in_progress constraint
- Required fields validation (missing content/status), optional `activeForm`
- Invalid status value
- render() output format
- Empty list
- Update replaces previous list
- Integration with conversation turn (TodoWrite tool call → rendered result)

**Files**: `core/todo.py`, `tests/test_todo.py`

---

## M9-T3: Skills System (`skill_loader.py` + preset skills)

**Goal**: Knowledge injection system for agents, ported from learn-claude-code v4.

**SkillLoader behavior**:
- Scans `skills/*/SKILL.md` files; parses YAML frontmatter (name, description, tags) + markdown body
- `get_descriptions()`: Layer 1 — name+description list, ~100 tokens/skill (injected into system prompt)
- `get_content(name)`: Layer 2 — full SKILL.md body wrapped in `<skill-loaded>...</skill-loaded>` (returned as tool_result to preserve prompt cache)
- `list_skills()`: available skill names

**Tool schema**: `Skill` with `skill` parameter; description dynamically includes available skill list

**Changes**:
- `core/skill_loader.py` (CREATE ~120 lines): `SkillLoader` class
- `core/conversation.py`: Handle `Skill` tool call, call `skill_loader.get_content()`, return as tool_result
- `skills/combat/SKILL.md` (CREATE ~80 lines): D20 combat rules, initiative, damage, status effects
- `skills/world-building/SKILL.md` (CREATE ~60 lines): Entity format, map structure, NPC design guidelines
- `skills/narrative/SKILL.md` (CREATE ~50 lines): Scene description, dialogue style, atmosphere creation

**Tests** (`tests/test_skill_loader.py`): ~14
- Scan directory with valid SKILL.md files
- YAML frontmatter parsing (name, description, tags)
- get_descriptions() output format
- get_content() returns full body + wrapping tags
- get_content() for nonexistent skill → None
- list_skills() returns all names
- Empty skills directory
- Malformed YAML frontmatter handling
- Missing SKILL.md in subdirectory (skipped)
- Integration with conversation turn (Skill tool call → content injected)

**Files**: `core/skill_loader.py`, `skills/combat/SKILL.md`, `skills/world-building/SKILL.md`, `skills/narrative/SKILL.md`, `tests/test_skill_loader.py`

---

## M9-T4: System Prompt Templates (`prompts.py`)

**Goal**: Mode-aware system prompt generation replacing static `system.md`.

**Changes**:
- `core/prompts.py` (CREATE ~100 lines):
  - `build_system_prompt(agent_name, project_name, branch, mode, skill_descriptions)` → complete system prompt string
  - Build mode rules: direct file ops, text output is primary, no submit_proposal
  - Sandbox mode rules: use submit_proposal, system validates and applies
  - Play mode rules: game master role, direct file ops, maintain immersion
  - Tool list section (mode-dependent: Build/Play exclude submit_proposal, include TodoWrite+Skill; Sandbox includes submit_proposal)
  - Entity format section
  - Project context section

**Tests** (`tests/test_prompts.py`): ~8
- Build mode: contains direct write rules, no submit_proposal mention
- Sandbox mode: contains submit_proposal rules
- Play mode: contains game master rules
- Skill descriptions injected
- All modes contain tool list, entity format, project info
- Agent name / project name / branch substitution

**Files**: `core/prompts.py`, `tests/test_prompts.py`

---

## M9-T5: New TUI — Claude Code Style (`app_v2.py`)

**Goal**: Single-pane conversational TUI replacing 4-pane layout as default.

**Layout**:
```
+--------------------------------------------------+
| my-rpg | main | ev:3 | build | narrator          |  ← StatusBar
+--------------------------------------------------+
|                                                    |
|  > 用户输入内容                                     |
|                                                    |
|  流式叙事输出...                                    |  ← on_chunk
|                                                    |
|  ◐ read_file game/town/start-town.json           |  ← on_tool_use
|  ◐ write_file game/town/start-town.json          |
|                                                    |
|  [x] Read town data                               |  ← TodoManager
|  [>] Updating town description                    |
|  [ ] Add market district NPCs                     |
|                                                    |
|  ▶ Loading skill: world-building                  |  ← Skill indicator
|                                                    |
+--------------------------------------------------+
| > 输入消息...                          [build ●]  |
+--------------------------------------------------+
```

**Changes**:
- `tui/app.py` → `tui/app_legacy.py` (RENAME)
- `tui/app_v2.py` (CREATE ~500 lines):
  - `NeonRPAppV2(App)`: main app class
  - `StatusBarV2(Static)`: project name, branch, event count, mode, agent
  - `ConversationView(RichLog)`: main panel — user messages, streaming text, tool indicators, todo display, skill loading indicators
  - `InputAreaV2(Container)`: input field + mode badge
  - Worker pattern: `_send_worker()` uses `ConversationSession.send()` with callbacks
  - Streaming: `on_chunk` → `call_from_thread` → append to RichLog
  - Tool indicators: `on_tool_use` → `call_from_thread` → dimmed tool line
  - ask_user: `on_ask_user` → `call_from_thread` → modal input
  - Slash commands dispatched to `commands.py`
  - Enter submits (not Ctrl+Enter)

**Reused**: `tui/commands.py` COMMANDS dict, `tui/palette.py` color scheme, worker pattern from `app.py`

**Tests** (`tests/test_tui_v2.py`): ~10
- App mounts without error
- StatusBar displays correct info
- Input submission triggers worker
- Streaming chunks appear in conversation view
- Tool use indicators displayed
- Todo updates displayed
- Slash command dispatch (e.g. /help, /mode, /clear)
- Mode badge updates on /mode change

**Files**: `tui/app_legacy.py` (renamed), `tui/app_v2.py`, `tests/test_tui_v2.py`

---

## M9-T6: CLI Entry + Commands

**Goal**: Wire new TUI as default; add conversation commands.

**Changes**:
- `commands/tui.py` (MODIFY ~15 lines):
  - Add `--legacy` flag
  - Default: import `NeonRPAppV2` from `tui/app_v2.py`
  - `--legacy`: import `NeonRPApp` from `tui/app_legacy.py`
- `tui/commands.py` (MODIFY ~30 lines):
  - `/mode build|sandbox|play` — switch conversation mode
  - `/clear` — clear conversation history
  - `/files` — list recently modified files
  - `/skills` — list available skills

**Tests** (`tests/test_tui_commands.py`): ~6
- /mode switches session mode
- /clear resets conversation
- /files returns recent modifications
- /skills lists loaded skills
- --legacy flag loads old TUI class

**Files**: `commands/tui.py`, `tui/commands.py`, `tests/test_tui_commands.py`

---

## M9-T7: Review Gate

**Process**:
1. `ruff format` + `ruff check` — all clean
2. `pytest` — all 720+ tests pass (626 existing + ~75 new)
3. Code review using `codex review 'prompt'` with `prompts/code_review.md`, save result to `reviews/M9_review_<date>.md`
4. Fix must-fix items from review
5. Re-run format + lint + tests
6. Documentation update: `docs/TUTORIAL.md` (conversation mode section), `docs/CLI_REFERENCE.md` (new commands)
7. Update `docs/ROADMAP.md` checkboxes

**Target**: ~75 new tests, 700+ total

---

## File Summary

| File | Action | Est. Lines |
|------|--------|-----------|
| `src/neonrp/core/conversation.py` | CREATE | ~450 |
| `src/neonrp/core/todo.py` | CREATE | ~80 |
| `src/neonrp/core/skill_loader.py` | CREATE | ~120 |
| `src/neonrp/core/prompts.py` | CREATE | ~100 |
| `src/neonrp/tui/app_v2.py` | CREATE | ~500 |
| `src/neonrp/tui/app.py` → `app_legacy.py` | RENAME | 0 |
| `src/neonrp/commands/tui.py` | MODIFY | ~15 |
| `src/neonrp/tui/commands.py` | MODIFY | ~30 |
| `skills/combat/SKILL.md` | CREATE | ~80 |
| `skills/world-building/SKILL.md` | CREATE | ~60 |
| `skills/narrative/SKILL.md` | CREATE | ~50 |
| `tests/test_conversation.py` | CREATE | ~400 |
| `tests/test_todo.py` | CREATE | ~150 |
| `tests/test_skill_loader.py` | CREATE | ~180 |
| `tests/test_prompts.py` | CREATE | ~100 |
| `tests/test_tui_v2.py` | CREATE | ~120 |
| `tests/test_tui_commands.py` | CREATE | ~80 |

**Unchanged (fully reused)**:
- `core/skills.py` — SkillRegistry already supports `direct_write_globs`
- `core/session.py` — session persistence complete
- `core/agent_runner.py` — Sandbox mode continues to use
- `core/llm.py` / `core/llm_openai.py` — LLM adapters unchanged
- `core/checkpoint.py` / `core/event_log.py` / `core/manifest.py` — reused directly

## Dependency Order

```
T0 (doc-first)
T1 (conversation.py)  ← core engine, blocks all others
  ├── T2 (todo.py)     ← can parallel with T3, T4
  ├── T3 (skill_loader.py + skills/)  ← can parallel with T2, T4
  ├── T4 (prompts.py)  ← can parallel with T2, T3
  └── T5 (app_v2.py)   ← requires T1-T4
       └── T6 (tui.py + commands.py) ← requires T5
T7 (review gate) ← requires all above
```

## Acceptance Criteria

1. **Basic conversation**: Launch TUI → type "描述起始城镇" → see streaming narrative output
2. **File modification**: Type "给玩家添加铁剑" → see write_file indicator + narrative → verify event/checkpoint created
3. **TodoManager**: Type "设计一个完整的地下城" → model uses TodoWrite → steps displayed
4. **Skills**: Model loads `combat` skill during battle → gains D20 rules knowledge
5. **Undo**: `/undo` → changes rolled back
6. **Mode switch**: `/mode sandbox` → requires submit_proposal
7. **Legacy TUI**: `--legacy` flag launches old 4-pane TUI
8. **Regression**: All 626 existing tests still pass
