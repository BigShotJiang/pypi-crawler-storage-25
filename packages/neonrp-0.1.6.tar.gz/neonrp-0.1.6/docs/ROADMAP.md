# Roadmap

This roadmap is driven by `docs/REQUIREMENTS.md`.

## M0 — Skeleton + Core Lifecycle (P0)
Goal: a minimal closed loop that is **resumeable**, **undoable**, and **auditable**.

### Tasks
- [x] T0: Repo skeleton (pyproject, ruff, pytest, CI), `neonrp --help` works 【R0】
- [x] T1: `neonrp init` creates `.neonrp/` structure + `manifest.json` (minimal: version + branch pointer, 不含实体索引) 【R0, R3(结构预留)】
- [x] T2: `neonrp run "<text>"` appends an event (placeholder echo loop, 不接入 LLM) 【R0】
- [x] T3: `neonrp save` / `neonrp load <id>` snapshot & restore 【R0】
- [x] T4a: `neonrp undo` / `neonrp redo` (基于 auto-save 的状态回退与前进) 【R0】
- [x] T4b: `neonrp branch <name>` (从当前状态分叉新时间线) 【R0】

### Acceptance
- [x] init is idempotent and non-destructive
- [x] every run produces an append-only event entry
- [x] save/load restores identical file tree (hash or content check)
- [x] undo returns to previous turn state
- [x] branches do not cross-contaminate

### Test requirements (per task)
- **Unit tests**: Storage layer core functions (save/load state transitions, event append, manifest read/write)
- **Integration tests**: CLI command end-to-end flow (init → run → save → load → undo → branch)
- **E2E tests**: subprocess invocation of `neonrp` commands, verifying actual CLI behavior

### Review Gate (mandatory after T4b; optionally after any task)
- [x] Run format/lint + tests
- [x] Run `opencode run` code review and save output to `reviews/`
  - **If `opencode run` encounters an unrecoverable error (e.g. opencode itself crashes), stop development immediately and resolve before continuing.**
- [x] Apply review fixes (or document non-adoption)
- [x] Run tests again
- [x] Update `docs/PROGRESS.md` and checkboxes here

## Pre-M1 — Housekeeping

M0 代码审查发现以下遗留问题，须在 M1 编码前修复。

### Tasks
- [x] H0: 修复 M0 遗留 lint 错误（6 个未使用导入：run.py, paths.py, storage.py, test_core.py）
- [x] H1: 修复 Pydantic v2 弃用警告（`class Config` → `model_config = ConfigDict`; `json_encoders` → `@field_serializer`; `datetime.utcnow()` → `datetime.now(UTC)`）

### Known M0 deviations (记录，不阻塞 M1)
- ADR 0002 定义事件字段为 `seq/ts/actor/data`，实际 GameEvent 使用 `id/timestamp/type/payload`，且缺少 `actor` 字段。需在 M2 前统一。
- `redo` 命令未实现（ROADMAP T4a 标记完成但 cli.py 未注册 redo）。
- `undo` 仅移动 head_event 指针，不恢复 game/ 目录状态（与 ADR 0003 auto-save 设计不符）。

## M1 — Validation + Index (P0)
- Schema validation for world data
- `manifest.json` entity indexing
- `find` command to locate entities by id/tag/keyword
- minimal context retrieval (keyword/rule-based)

### Plan (Detailed)
**Goals（必达）**
- Schema validation：结构层 + 约束层，错误可修复、可追踪
- Entity index：`manifest.entities` 作为单一真相，支持增量更新
- Find：支持 id/tag/kind/keyword 检索
- Context：返回最小上下文集合（path + snippet + 可解释打分）

**Non-goals（M1 不做）**
- 向量检索/embedding
- 跨实体引用完整性校验
- 权限边界（仅预留结构，M2 实现）

**World 约定**
- 路径：`game/<kind>/<id>.json`
- 必填字段：`id`, `kind`, `name`
- 可选字段：`tags`, `summary`
- 规则：id 全局唯一；kind 与路径一致

**Validate 命令**
- `neonrp validate`
- Exit codes：`0` 全部通过；`1` 校验失败；`2` 系统错误（schema/IO）
- 输出：人类可读 + `--json`（每条错误含 file + json path）

**Index 命令**
- `neonrp index build|update`
- `entities` 记录字段：`id`, `kind`, `name`, `tags`, `summary`, `path`, `mtime`, `hash`
- `build` 全量重建；`update` 仅更新变化项并清理删除项
- **部分失败策略**：index 跳过校验不通过的实体，仅索引合法实体，输出警告。不因单个坏文件导致整体索引失败。
- **与 save/load 的交互**：M1 不自动触发 index update。`find`/`context` 在 manifest.entities 为空时提示用户执行 `index build`。

**Find / Context**
- `find`：`--id` 精确、`--tag/--kind` 过滤、keyword 给出 Top‑N
- `context`：`--limit N`，结果稳定且可解释
- Ranking（建议权重）：tags > name > summary > content snippet
- **snippet 规格**：优先使用 summary；缺失时截取文件内容前 200 字符。
- **score breakdown 格式**：`{"tags": float, "name": float, "summary": float, "content": float}`

**输出格式约定（全部 M1 命令）**
- 默认：人类可读文本
- `--json`：结构化 JSON 输出到 stdout（便于管道和 agent 消费）

**Resolved decisions**
- `manifest.version` M1 bump 到 `"0.2"`（Pydantic 默认值已处理缺失的 entities 字段，迁移无额外逻辑）
- 倒排索引（M1-T3）若实施，使用 JSON 文件（`.neonrp/index/inverted.json`），不引入 SQLite
- 纯 id 查询：维持"全局唯一"规则，纯 id 直接精确匹配

**执行拆分（参考 task cards）**
- 详见：`docs/M1_TASK_CARDS.md`

> **M0 须保证**：
> - manifest.json 结构可扩展（预留 `entities` 字段位置）
> - game/ 下的数据文件遵循统一的 id 字段约定
> - schema/ 目录在 init 时创建（即使 M0 不写入 schema 文件）

### Task dependencies
```
M1-T0 (doc-only)
  └→ M1-T1 (validate CLI) ──→ M1-T3 (inverted index, optional)
  └→ M1-T2 (index CLI)    ──→ M1-T4 (find) ──→ M1-T5 (context)
                                                     └→ M1-T6 (review gate)
```
注：M1-T2 的核心逻辑（scan_entities）内部调用 validate_game_data()，因此 T2 实质依赖 T1 的核心模块（但不依赖 T1 的 CLI 命令）。

### Tasks
- [x] H0: 修复 M0 遗留 lint 错误 【前置】
- [x] H1: 修复 Pydantic v2 弃用警告 【前置】
- [x] M1-T0: World data conventions (entity minimal fields + path conventions) 【R3】
- [x] M1-T1: `neonrp validate` CLI wrapper + tests (core logic exists in `core/validation.py`) 【R3】
- [x] M1-T2: `neonrp index build|update` CLI wrapper + tests + fix scan_entities partial failure (core logic exists in `core/indexing.py`) 【R3】
- [ ] M1-T3: (Optional) inverted keyword index under `.neonrp/index/` 【R3】 (skipped)
- [x] M1-T4: `neonrp find <query>` (id/tag/kind/keyword) + `--json` 【R3】
- [x] M1-T5: `neonrp context "<query>" --limit N` (rule/keyword-based retrieval) + `--json` 【R3】

### Acceptance
- [x] `validate` passes good fixtures; fails bad fixtures with actionable, file-scoped errors
- [x] `index build` produces stable `manifest.entities`; skips invalid entities with warnings (not all-or-nothing)
- [x] `index update` updates only changed entities (mtime/hash), leaving unchanged entries untouched
- [x] `find` resolves exact id, filters by tag/kind, and returns ranked keyword hits
- [x] `context` returns a minimal, explainable set of entity snippets with score breakdown
- [x] all M1 commands support `--json` output

### Test requirements (per task)
- **Unit tests**: schema loader + validator, entity scanner, tokenizer/ranker, manifest migration hooks
- **Integration tests**: init → validate → index build → find/context in a temp project root
- **E2E tests**: CLI subprocess calls validating exit codes and stdout/stderr behavior

### Review Gate (mandatory after M1-T5; optionally after any task)
- [x] Run format/lint + tests
- [x] Code review saved to `reviews/M1_review_20260129.md`
- [x] Apply review fixes (removed unused parameter)
- [x] Run tests again (41 passed)
- [x] Update `docs/PROGRESS.md` and checkboxes here

## Pre-M2 — Housekeeping

M0/M1 遗留问题，须在 M2 编码前修复。

### Tasks
- [x] H2: GameEvent 添加 `actor` 字段（可选 string，默认 None；agent 事件填入 agent_id）。同步更新 `append_event` 和 `read_events`。更新相关测试。

> 注：ADR 0002 与实际 GameEvent 的其他字段命名差异（id vs seq, timestamp vs ts, payload vs data）暂不统一，仅添加 actor 字段满足 M2 需求。完整统一可在 M4 replay 前处理。

## M2 — Agents + Plan/Diff/Apply (P0/P1)
- agent lifecycle: new/list/show/run/test/logs
- permission boundaries enforced by storage layer
- structured proposals + patches, validated then applied
- event log integration: agent apply → event append

> **M0 须保证**：
> - 事件日志格式包含 `actor` 字段（后续用于标识代理来源）→ 由 Pre-M2 H2 修复
> - 文件写入通过集中函数（便于后续加权限检查）→ M0 已满足（storage.py）
> - Plan→Diff→Apply 流程在 Storage 层留有扩展点 → M2 落地

### Plan (Detailed)
**Goals（必达）**
- 建立最小 Agent 系统：创建/查看/运行/测试/日志
- 落地 Plan→Diff→Validate→Apply 的"可审计写入"流程
- 权限边界：agent 写入必须受控（owned paths），越权必须失败且可修复
- 与 M1 检索对接：agent run 使用 `context` 结果作为最小上下文
- event log integration：agent apply 成功后追加事件日志，与 undo/replay 体系联通

**Non-goals（M2 不做）**
- 不做完整 skill registry / marketplace（放到 M3）
- 不做并行多 agent 调度（先串行 + 可重放）
- 不做复杂 merge/cherry-pick（沙盒/合并放到 M4）

**Primary docs**
- `docs/M2_AGENTS_PLAN_DIFF_APPLY_DESIGN.md`
- `docs/M2_TASK_CARDS.md`
- ADR: `docs/ADRs/0006-agent-spec-and-permissions.md`, `docs/ADRs/0007-proposal-format-plan-diff-apply.md`

### Task dependencies
```
H2 (GameEvent actor field) ──→ M2-T0 (doc/ADR)
                                  └→ M2-T1 (agent CLI)
                                  └→ M2-T2 (proposal + permissions) ──→ M2-T3 (diff)
                                                                          └→ M2-T4 (apply engine)
                                                                                └→ M2-T5 (logs/rerun)
                                                                                └→ M2-T6 (integration)
                                                                                      └→ M2-T7 (review gate)
```

### Tasks
- [x] H2: GameEvent 添加 `actor` 字段 【前置】
- [x] M2-T0: Agent spec + permissions + logs (Doc/ADR first) 【R1】
- [x] M2-T1: `neonrp agent` command group (new/list/show/path) + `--json` 【R1】
- [x] M2-T2: Proposal format + validator + ops vocabulary (upsert_text/delete) + permissions engine 【R1】
- [x] M2-T3: Diff rendering (proposal preview: plan + unified diff) 【R1】
- [x] M2-T4: Apply engine w/ staging + permission boundaries + validation gate + event log append (atomic writes) 【R1】
- [x] M2-T5: Agent run (--proposal/--apply/--json) + test + logs + rerun 【R1】
- [x] M2-T6: Integrate retrieval: `context` → agent input via `neonrp agent run <id> --query "..."` (tests via stub agent + --proposal) 【R1】

### Acceptance
- [x] `agent new` 创建的模板包含合法 agent.json（id/permissions/system_prompt）
- [x] `agent list/show` 输出正确且支持 `--json`
- [x] proposal 缺字段或路径逃逸（`..`）时拒绝并给出可操作错误（exit code = 1）
- [x] Agent can only write to owned paths; violations fail with actionable errors (agent_id + path + glob + suggestion)
- [x] diff 输出稳定（同输入同输出）
- [x] validate 失败时不污染真实 `game/`（staging 策略）
- [x] Every apply is audited: proposal + diff + validation result + applied patch is logged under `.neonrp/logs/agents/<run_id>/`
- [x] Agent apply 成功后追加事件日志（type=agent, actor=agent_id），head_event 递增
- [x] base_head_event 与当前 head_event 不匹配时拒绝 apply（过期提案）
- [x] Deterministic rerun: given same inputs (context + proposal), apply results are reproducible

### Test requirements (per task)
- **Unit tests**: 权限判定（glob 匹配、deny 优先、路径逃逸拒绝）、proposal parse/normalize、diff 稳定性、event append with actor
- **Integration tests**: init → index build → agent run (stub + --proposal) → diff preview → validate+apply → event log → find/context
- **E2E tests**: subprocess 调 CLI，检查 exit code、日志落盘、game/ 文件变更

### Review Gate (mandatory after M2-T6; optionally after any task)
- [x] Run format/lint + tests
- [x] Run `opencode run` code review and save output to `reviews/`
- [x] Apply review fixes (or document non-adoption)
- [x] Run tests again
- [x] Update `docs/PROGRESS.md` and checkboxes here

## Pre-M3 — Housekeeping

M2 代码审查及 M3 计划审查发现的遗留问题，须在 M3 编码前修复。

### Tasks
- [x] H3: 修复 `agent.py:393` 的 `manifest.active_branch` bug（应为 `manifest.current_branch`）
- [x] H4: `apply.py:149-151` game/ 目录替换改为原子 rename 策略（rename old → rename new → delete old）
- [x] H5: `retrieval.py` 在 `manifest.entities` 为空时提示用户运行 `index build`
- [x] H6: `diffing.py:68` delete hunk header 改为标准 unified diff 格式

> 注：M2 review nice-to-have "`agent.py` 模板写入非原子" 评估后为 wontfix（一次性创建，非崩溃敏感）。

## M3 — LLM Integration + Skills + Import (P1)
- LLM adapter interface + deterministic stub provider
- skill tool registry (audited, permission-aware)
- end-to-end `agent run` (LLM → proposal → diff preview → optional apply)
- SillyTavern character card import (JSON only; PNG deferred)
- game scaffolding command

> **M0 须保证**：
> - CLI 命令注册使用 click group 的可扩展机制（不硬编码子命令）
> - game/ 目录结构支持新增实体类型（不假定固定的子目录集合）

### Plan (Detailed)
**Goals（必达）**
- `agent run`：LLM（单次调用）→ proposal.json → diff preview；可选 `--apply` 复用 M2 的 `apply_proposal()`
- skill registry：给 LLM/agent runner 的受控工具（read-only），权限按文件粒度检查（deny 优先），带审计日志
- import：SillyTavern JSON 角色卡导入到 `game/character/<id>.json`，raw payload 嵌入 `meta.raw`
- game scaffolding：`game new` 生成可验证、可索引的 starter world（hardcoded 模板）

**Non-goals（M3 不做）**
- 不做多 agent 并行调度
- 不做向量检索/embedding
- 不做沙盒/合并（M4）
- 不做 agentic loop（多轮 tool call → LLM）；M3 为单次调用
- 不做 PNG 角色卡提取（推迟到 M3.5+）
- 不做命令插件机制（继续用 cli.py 显式注册；推迟到 M5）

**Primary docs**
- `docs/M3_LLM_COMMANDS_SKILLS_IMPORT_DESIGN.md`
- `docs/M3_TASK_CARDS.md`
- ADR: `docs/ADRs/0008-llm-adapter-and-config.md`, `docs/ADRs/0009-skill-tool-registry-and-auditing.md`, `docs/ADRs/0010-sillytavern-import-mapping.md`

**Resolved decisions**
- LLM adapter 使用 Python Protocol 接口；M3 实现 `stub` 和一个真实 provider
- stub provider 支持 `fixture_path` 参数加载预定义 proposal
- skill 权限按文件粒度检查，被拒路径静默过滤并记录
- 角色卡 raw payload 嵌入 `meta.raw`（非 sidecar 文件）
- game new 模板 hardcoded（自定义模板目录推迟到 M5）
- `agent run --apply` 复用 M2 的 `apply_proposal()`；`agent apply` 保留为手动入口

### Task dependencies
```
H3/H4/H5/H6 (Pre-M3 housekeeping)
  └→ M3-T0 (docs/ADRs)
       └→ M3-T1 (config) ──→ M3-T2 (LLM adapter + stub)
                                └→ M3-T3 (skills) ──→ M3-T4 (agent run preview) ──→ M3-T5 (agent run --apply)
       └→ M3-T6 (import) ──→ M3-T7 (game scaffolding)
                                       └→ M3-T8 (review gate)
```
注：M3-T1（config）和 M3-T6（import）可并行开发，两者都依赖 M3-T0。

### Tasks
- [x] H3: 修复 `agent.py:393` active_branch bug 【前置】
- [x] H4: `apply.py` game/ 替换改为原子 rename 策略 【前置】
- [x] H5: `retrieval.py` 索引为空时提示 `index build` 【前置】
- [x] H6: `diffing.py` delete hunk header 标准化 【前置】
- [x] M3-T0: M3 specs + ADRs (Doc-first) 【R1, R2】
- [x] M3-T1: Project config `.neonrp/config.json` (CLI flags override; no secrets) 【R2】
- [x] M3-T2: LLM adapter Protocol + deterministic `stub` provider + one real provider (OpenAI + GLM) 【R2】
- [x] M3-T3: Skill tool registry (per-file permission check, deny-first) + JSONL auditing 【R2】
- [x] M3-T4: `neonrp agent run <id> --query "..." [--provider stub] [--json]` (LLM → proposal → diff preview) 【R1, R2】
- [x] M3-T5: `neonrp agent run --apply` end-to-end (reuses `apply_proposal()` from M2) + tests 【R1】
- [x] M3-T6: `neonrp import sillytavern-card <file> [--id <id>] [--json]` (JSON only) 【R2】
- [x] M3-T7: `neonrp game new [--template <name>] [--force] [--json]` (hardcoded templates) 【R2】

### Acceptance
- [x] Pre-M3 housekeeping 全部修复
- [x] `agent run --provider stub` 产出有效 proposal + 稳定 diff 预览；日志保存到 `.neonrp/logs/agents/<run_id>/`
- [x] `agent run --provider stub --apply` 完成完整 proposal → apply → event 流程
- [x] LLM adapter stub 确定性（同输入同输出）；fixture_path 模式可加载自定义 proposal
- [x] LLM I/O 完整记录（llm_input.json, llm_raw.txt, proposal.json）
- [x] skill calls 按文件粒度权限检查；被拒路径记录到审计日志而非中止运行
- [x] 每次 skill 调用记录到 `.neonrp/logs/skills/<run_id>.jsonl`
- [x] imported JSON 角色卡通过 `validate` 且可被 `index build` 索引；`meta.raw` 包含原始 payload
- [x] import ID 冲突解决：自动追加 `-2`, `-3`
- [x] `game new` 输出通过 `validate`，`index build` 可索引，`--force` 可覆盖
- [x] 所有新命令支持 `--json` 输出

### Test requirements (per task)
- **Unit tests**: LLM adapter stub 确定性、skill 权限按文件检查（deny 优先）、import mapping 稳定、game template 验证
- **Integration tests**: init → config → agent run (stub) → diff → apply → event log → find/context；init → import → validate → index build
- **E2E tests**: subprocess 调 CLI，验证 exit code、日志落盘、game/ 变更

### Review Gate (mandatory after M3-T7; optionally after any task)
- [x] Run format/lint + tests
- [x] Run `opencode run` code review and save output to `reviews/`
- [x] Apply review fixes (or document non-adoption)
- [x] Log ALL review findings in `docs/PROGRESS.md` (per Review findings tracking)
- [x] Run tests again
- [x] Update `docs/PROGRESS.md` and checkboxes here

## Pre-M4 — Housekeeping

M3 审查及 M4 计划审查发现的遗留问题，须在 M4 编码前修复。

### Tasks
- [x] H7: `save.py:64-68` load 命令使用 rmtree+copytree 替换 game/，存在崩溃窗口。改为原子 rename 策略（与 H4 apply.py 修复一致）。
- [x] H8: `save.py:28` 使用已弃用的 `datetime.utcnow()`，改为 `datetime.now(timezone.utc)`。
- [x] H9: PNG 角色卡导入——扩展 `import sillytavern-card` 支持 PNG 格式（从 tEXt chunk 提取 Base64 编码的 JSON）。

> 注：H9 是从 M3 推迟的功能需求（原 "M3.5+"），现纳入 Pre-M4。

## M4 — Sandbox + Replay (P1)
- sandbox new/drop from any save
- replay for debugging determinism
- import/game world 变更纳入事件审计链

### Plan (Detailed)
**Goals（必达）**
- **Sandbox**：提供 `sandbox new/list/switch/drop`，沙盒与主线隔离；可从任意 save 创建；默认不支持合并回主线（后续里程碑）。
- **Replay**：提供 `replay verify`（默认不写入真实 world），能从某个 save 作为基线重放事件到目标点，并输出可定位的差异报告。
- **Metadata**：save 必须记录足够的元信息（branch/head_event/world hash），以支撑 sandbox 与 replay 的可用性。
- **Event completeness**：所有 world 变更命令（import、game new）生成 system proposal 并走 apply pipeline，确保事件日志完整可重放。

**Non-goals（M4 不做）**
- 不做 sandbox merge/cherry-pick 回主线（P2）。
- 不做并行调度/多进程写入（仍以单进程为主）。
- 不要求引擎层战斗/掷骰完全落地；但 replay 需要为"确定性"留钩子（seed/rolls/event schema）。
- manifest.entities 不做 per-branch（切换即失效 + 提示 index build）。

**Primary docs**
- `docs/M4_SANDBOX_REPLAY_DESIGN.md`
- `docs/M4_TASK_CARDS.md`
- ADR: `docs/ADRs/0011-sandbox-branch-model.md`, `docs/ADRs/0012-replay-and-determinism-contract.md`

**Resolved decisions**
- import/game new 改为生成 system proposal + 走 apply pipeline（方案 A）。这样所有 world 变更都有 event 记录，replay 可覆盖。
- manifest.entities：M4 先做"sandbox switch 时失效 + 提示 index build"，per-branch 索引推迟。
- Event type 新增 `system` 类型用于 import/game 事件，payload 包含 `command` 字段标识来源（`import`, `game_new`）。
- world hash 工具函数在 M4-T1 中创建（`core/hashing.py`），供 save meta 和 replay verify 共用。

**Key invariants**
- sandbox = 特殊标记的 branch（manifest 中可识别），且默认不允许覆盖/删除 main。
- replay 默认只在 staging 中运行；除非显式 `--checkout` 或 `--to-branch`，否则不得写入真实 `game/`。
- 写入安全：任何 world 级替换必须使用 staging + 原子 swap（rename old → rename new → cleanup old）。
- 事件日志必须包含足够信息用于重放：至少包含 monotonic event id、type、actor、ts，以及可定位 proposal 的 run_id（对 agent/system apply 事件）。

### Task dependencies
```
H7/H8/H9 (Pre-M4 housekeeping)
  └→ M4-T0 (docs/ADRs)
       └→ M4-T1 (save meta + world hash utility)
            ├→ M4-T2 (sandbox commands) ──→ M4-T4 (replay checkout / sandbox from event)
            └→ M4-T3 (replay verify)    ──┘
                                              └→ M4-T5 (event schema hardening: import/game → system proposal)
                                                    └→ M4-T6 (review gate)
```
注：M4-T4 依赖 M4-T2（sandbox 基础设施）和 M4-T3（replay 核心逻辑）。

### Tasks
- [x] H7: `save.py` load 命令改为原子 rename 策略 【前置】
- [x] H8: `save.py` datetime.utcnow() → datetime.now(UTC) 【前置】
- [x] H9: PNG 角色卡导入（tEXt chunk Base64 提取）【前置，R2】
- [x] M4-T0: M4 specs + ADRs (Doc-first) 【R4】
- [x] M4-T1: Save snapshot meta + event log copy + world hash utility (`core/hashing.py`) 【R4】
- [x] M4-T2: `neonrp sandbox` command group (new/list/switch/drop) + index invalidation + `--json` 【R4】
- [x] M4-T3: `neonrp replay verify` (staging rebuild + world hash compare) + `--json` 【R4】
- [x] M4-T4: `neonrp replay checkout` (restore world or create sandbox at event/save) + `--json` 【R4】
- [x] M4-T5: Event schema hardening: import/game new → system proposal + apply pipeline + event 【R4】
- [x] M4-T6: Review Gate (opencode review + fixes + tests + findings tracking) 【R4】

### Acceptance
- [x] Pre-M4 housekeeping 全部修复（load 原子替换、utcnow 修复、PNG 导入）
- [x] PNG 角色卡导入：`import sillytavern-card <file.png>` 自动检测格式，提取 tEXt chunk 中的 JSON
- [x] save 包含 meta.json（branch/head_event/game_hash/created）和 events.jsonl 副本
- [x] world hash 确定性（同文件同内容同 hash；路径排序稳定）
- [x] `sandbox new --from <save_id>` 创建隔离沙盒；`sandbox drop` 安全清理
- [x] sandbox switch 不跨污染 game/；切换后 manifest.entities 失效并提示 `index build`
- [x] `replay verify --from <save_id>` 确定性重放；mismatch 时报告第一个 divergent event id + file path
- [x] replay 默认不写入真实 game/；checkout 需显式 flag 且 crash-safe
- [x] import/game new 改为 system proposal + event，replay 可覆盖
- [x] 所有新命令支持 `--json` 输出

### Test requirements (per task)
- **Unit tests**: world hash 稳定性、save meta 解析、event 选择/范围、PNG tEXt chunk 提取、system proposal 生成
- **Integration tests**: init → save → sandbox new(from save) → apply changes → switch back → verify isolation；replay verify on controlled event stream；import PNG → validate → index build
- **E2E tests**: subprocess `neonrp sandbox` / `neonrp replay` verifies exit codes, stdout, and filesystem side effects

### Review Gate (mandatory after M4-T5; optionally after any task)
- [x] Run format/lint + tests
- [x] Run `opencode run` code review and save output to `reviews/`
- [x] Apply review fixes (or document non-adoption)
- [x] Log ALL review findings in `docs/PROGRESS.md` (per Review findings tracking)
- [x] Run tests again
- [x] Update `docs/PROGRESS.md` and checkboxes here

## Pre-M5 — Housekeeping

M4 审查及 M5 计划审查发现的遗留问题，须在 M5 编码前修复。

### Tasks
- [x] H10: 提取 `agent run` 编排逻辑到 `core/agent_runner.py`。当前 `commands/agent.py:agent_run` 函数（~200 行）将 LLM 调用、proposal 解析、diff 生成、apply、日志保存等编排逻辑耦合在 Click 命令中。TUI 需要直接调用 core 模块（ADR-0013），因此须将核心编排流程提取为可复用的 `run_agent()` 函数，CLI 和 TUI 共享同一入口。
- [x] H11: 关闭 M5 Open Questions。在 `docs/M5_TUI_DESIGN.md` 中将三个 Open Questions 转为 Resolved decisions：
  - Session 概念：M5 不做独立 session 落盘，TUI transcript 仅在内存中维持，退出即丢弃。session 持久化推迟到 M6+。
  - 内置 editor vs 外部 `$EDITOR`：M5 仅提供只读 viewer；"在外部编辑器打开"功能尊重 `$EDITOR` 环境变量（可选实现）。
  - Windows Terminal 快捷键冲突：`Ctrl+K` 在部分终端有冲突；M5 同时注册 `Ctrl+P` 作为备选；单字母快捷键（a/u/s/q）仅在非输入焦点时激活。

> 注：H10 是 M5-T1/T3a 的前置条件。H11 是 M5-T0 的收尾。

## M5 — TUI (Claude Code/OpenCode-style) (P2)
- keyboard-first terminal UI
- integrated agent run (plan/diff/apply), file explorer, logs, and command palette
- keeps CLI available; TUI is an optional front-end

### Plan (Detailed)
**Goals（必达）**
- **Claude Code/OpenCode-style workflow**：一个界面内完成“输入 → agent run → 预览 diff → apply/undo → 查看文件/日志”。  
- **Keyboard-first**：以 command palette + 少量固定快捷键为主（无需鼠标）。  
- **Audit-first**：默认先展示 plan/diff，再允许 apply；所有动作可追踪到 `.neonrp/logs/`。  
- **Fast navigation**：文件树、搜索（find/context）、最近 runs/saves/sandboxes 一键跳转。  

**Non-goals（M5 不做）**
- 不做 mod manager（移至 M7+）。  
- 不做向量检索/embedding。  
- 不做多 agent 并行调度。  

**Primary docs**
- `docs/M5_TUI_DESIGN.md`
- `docs/M5_TASK_CARDS.md`
- ADR: `docs/ADRs/0013-tui-framework-and-architecture.md`, `docs/ADRs/0014-tui-interaction-model-and-keybindings.md`

**Resolved decisions**
- Streaming：M5 不改造 `LLMAdapter` Protocol；stub provider 返回完整响应后一次性渲染到 transcript。真正的 token-level streaming 推迟到 M5.5+，当前 TUI 仅需显示"running…"进度指示 + 完成后渲染结果。
- `:` 命令解析：纳入 M5-T2（Command Palette + Command Runner），输入框以 `:` 开头时解析为 TUI 内命令。
- Session 概念：M5 不做独立 session 落盘；TUI transcript 仅在内存中维持。
- 内置 editor：M5 仅提供只读 viewer；外部编辑器通过 `$EDITOR` 打开（可选）。
- Windows 快捷键：`Ctrl+K` 同时注册 `Ctrl+P` 备选；单字母快捷键仅在非输入焦点时激活。

### Task dependencies
```
H10/H11 (Pre-M5 housekeeping)
  └→ M5-T0 (已完成)
       └→ M5-T1 (scaffold + layout + textual dep)
            └→ M5-T2 (command palette + `:` commands)
                 ├→ M5-T3a (agent run panel + result display)
                 │    └→ M5-T3b (diff preview + apply)
                 ├→ M5-T4 (file explorer + viewer)
                 └→ M5-T5 (logs browser)
                           └→ M5-T6 (tests + polish)
                                └→ M5-T7 (review gate)
```
注：M5-T3a 依赖 H10（core/agent_runner.py 提取）。M5-T3b 依赖 M5-T3a。M5-T4 和 M5-T5 可与 M5-T3a/T3b 并行开发。

### Tasks
- [x] H10: 提取 `agent run` 编排逻辑到 `core/agent_runner.py` 【前置】
- [x] H11: 关闭 M5 Open Questions 【前置】
- [x] M5-T0: M5 specs + ADRs (Doc-first)
- [x] M5-T1: `neonrp tui` scaffold + basic layout (panes + status bar + input) + `textual` 依赖
- [x] M5-T2: Command palette + command runner + `:` 命令解析
- [x] M5-T3a: Agent run 面板（输入 → 调用 core/agent_runner → 渲染结果到 transcript）
- [x] M5-T3b: Diff preview 面板 + apply 快捷键（调用 M2 apply pipeline）
- [x] M5-T4: File explorer + file viewer + open-in-editor integration
- [x] M5-T5: Logs browser (agents/skills/events) + quick jump to run_id
- [x] M5-T6: TUI tests + accessibility + error handling polish
- [x] M5-T7: Review Gate (opencode review + fixes + tests)

### Acceptance
- [x] Pre-M5 housekeeping 全部修复（agent_runner 提取、Open Questions 关闭）
- [x] `neonrp tui` starts and shows: status bar + input + at least two panes (chat + side panel)
- [x] Can run an agent query from TUI, preview diff, and apply safely (reusing core/agent_runner + M2 pipeline)
- [x] Can browse files and open recent run logs from within TUI
- [x] Keybindings documented and stable; command palette + `:` commands are discoverable
- [x] `:validate`, `:index build`, `:find` 等内联命令可在输入框中直接执行

### Test requirements (per task)
- **Unit tests**: TUI view-model logic (selection/routing), command palette filtering, `:` command parsing, log path resolution, agent_runner core function
- **Integration tests**: run TUI in Textual test mode to simulate keystrokes and verify visible state; agent_runner end-to-end with stub provider
- **E2E tests**: optional, best-effort (TUI is interactive); focus on unit/integration
- **目标**: 15-25 个新测试（view-model 纯函数单测 + Textual 交互测试）

### Review Gate (mandatory after M5-T6; optionally after any task)
- [x] Run format/lint + tests
- [x] Run `opencode run` code review and save output to `reviews/`
- [x] Apply review fixes (or document non-adoption)
- [x] Log ALL review findings in `docs/PROGRESS.md` (per Review findings tracking)
- [x] Run tests again
- [x] Update `docs/PROGRESS.md` and checkboxes here

## M6 — Agentic Loop + RPG 体验对齐 (P1)

M5 完成后，NeonRP 在数据管理/审计/回滚方面远超 Claude Code，但交互式 RPG 体验显著不足。M6 的目标是补齐与 Claude Code 式 RPG 工作流的核心差距，使 NeonRP 成为真正可用的 RPG 引擎终端，而非仅仅是数据管理工具。

### 背景：M5 后的关键差距分析

**对比基线**：用户当前在 Claude Code 中使用多个子代理（城镇管理员、商店管理员、地下城管理员等），所有角色/怪物/地图/背包数据以 JSON 管理，规则写在代理 prompt 或 markdown 中。Claude Code 提供多轮 tool call 循环、动态路由、会话上下文连续性，游戏节奏流畅。

| 差距 | 影响程度 | 说明 |
|------|---------|------|
| 单次 LLM 调用 vs 多轮 agentic loop | **致命** | NeonRP M3/M5 的 agent run 是一次调用：query → LLM → proposal。Agent 无法在一次 run 中先读取背包、再查看地图、再决定战斗结果、最后更新多个文件。Claude Code 的模型可以反复调用工具（读文件/搜索/写入）直到任务完成。这是体验差距的根本原因。 |
| 无 agent 自动路由 | **严重** | 用户有多个子代理（城镇/商店/地下城管理员），在 Claude Code 中主模型自主判断调用谁。NeonRP 中用户需手动 `agent run <id>`，打破沉浸感。 |
| 会话不连续 | **严重** | M5 TUI transcript 仅在内存中，无跨轮次上下文。无法做"上一轮你说了什么"式的连续对话。RPG 需要叙事连贯性。 |
| Apply 摩擦过大 | **中等** | 每次变更都要 proposal → diff preview → 手动 apply。对审计好，对游戏节奏是减速带。需要 auto-apply 模式。 |
| 无游戏循环 | **中等** | 缺少"输入 → 路由 → agent run → apply → 等待下一轮输入"的连续循环。当前每次 agent run 是独立的一次性操作。 |
| 无 streaming | **轻微** | M5 推迟了 token-level streaming。对叙事体验有影响（等待完整响应 vs 逐字显示），但不阻塞核心功能。 |

### 需要解决的核心问题（M6 规划输入）

#### 1. 多轮 Agentic Loop（最高优先级）

**问题**：当前 `LLMAdapter.generate()` 是单次调用，agent 只能基于预检索的 context 一次性生成所有变更。

**需要实现**：
- 扩展 `LLMAdapter` Protocol，增加多轮对话支持（tool_call → tool_result → 继续生成）
- Agent runner 循环：LLM 输出 → 检查是否有 tool calls → 执行 skill → 将结果喂回 LLM → 重复，直到 LLM 输出最终 proposal 或达到 max_turns
- Token 预算控制（避免无限循环或超出 context window）
- 每轮 tool call 都记录审计日志（已有 skills JSONL 基础设施）
- 循环终止条件：LLM 输出 proposal（正常结束）/ max_turns / token 预算耗尽 / 用户中断

**复杂度**：高。这是架构级变更，影响 `core/llm.py`、`core/agent_runner.py`、`core/skills.py`、TUI agent run 面板。

**典型 RPG 场景**：
```
用户: "我进入商店，想买一把铁剑"
Agent（多轮）:
  → tool_call: read_file("game/location/shop.json")    # 查看商店库存
  → tool_call: read_file("game/character/player.json")  # 查看玩家金币
  → 判断: 铁剑 50 金币，玩家有 120 金币，可以购买
  → 输出 proposal: 更新 player.json（金币 -50）+ 更新 shop.json（库存 -1）+ 更新 inventory
```

#### 2. Agent 自动路由 / Dispatcher

**问题**：用户输入"我去商店"时，需要手动指定 `agent run shop-manager`。

**需要实现**：
- Dispatcher 层：接受自然语言输入 → 分析意图 → 选择最合适的 agent → 执行
- 路由策略选项：
  - (A) 基于关键词/规则匹配 agent 的 `tags`/`description`（简单，确定性强）
  - (B) 用一次轻量 LLM 调用做意图分类（灵活，但增加延迟和成本）
  - (C) 主 agent（orchestrator）统一接收所有输入，自行决定调用哪个子 agent（最接近 Claude Code 体验）
- 回退机制：无法匹配时使用默认 agent 或提示用户选择
- Agent 间上下文传递：上一个 agent 的输出是否作为下一个 agent 的输入

**复杂度**：中。核心是路由函数 + agent spec 扩展（增加 `tags`/`triggers` 字段）。

#### 3. Session 持久化 + 跨轮上下文

**问题**：每次 agent run 是独立的，无叙事连贯性。

**需要实现**：
- Session log：`.neonrp/logs/sessions/<session_id>.jsonl`，记录每轮的 user input + agent output + applied changes
- 上下文窗口：将最近 N 轮 session 历史注入 LLM prompt（滑动窗口）
- 上下文裁剪策略：总结旧轮次 / 截断 / 按 token 预算裁剪
- TUI 中 session 的生命周期：TUI 启动时创建/恢复 session，退出时保存
- Session 与 branch 的关系：切换 branch 是否创建新 session

**复杂度**：中。主要是 session JSONL 读写 + prompt 组装逻辑。

#### 4. Auto-apply 模式

**问题**：每次变更都要手动确认 diff，打断游戏节奏。

**需要实现**：
- `auto-apply` 配置项（config.json 或 TUI 启动参数）
- 开启后：agent run → proposal → validate → 自动 apply（跳过 diff 确认）
- 安全阀：validation 失败时仍然中断并显示错误
- TUI 中的开关：可随时 toggle（例如探索时开 auto-apply，关键决策时关闭）
- 与 undo/save 的配合：auto-apply 后自动提示"已应用，按 u 撤回"

**复杂度**：低。在现有 agent_runner + TUI 基础上加一个 flag。

#### 5. 游戏循环（Game Loop）

**问题**：缺少连续的"输入 → 处理 → 输出 → 等待"循环。

**需要实现**：
- TUI 中的持续对话模式：用户输入 → dispatcher 路由 → agent run → auto-apply → 渲染叙事 → 等待下一轮输入
- 叙事渲染：将 agent 的 rationale/描述文本格式化为游戏叙事（而非纯 JSON diff）
- Turn 计数 / 状态指示：当前在第几回合、当前位置、生命值等 HUD 信息
- 这实际上是 TUI + agentic loop + dispatcher + auto-apply + session 的整合层

**复杂度**：中。依赖上述 1-4 全部完成后的整合。

#### 6. LLM Streaming（补充体验）

**问题**：等待完整响应才显示结果，叙事体验不佳。

**需要实现**：
- `LLMAdapter` Protocol 增加 `stream()` 方法，yield token/chunk
- TUI transcript 面板支持逐 token 渲染
- Streaming 与 tool call 的交互：tool call 期间暂停 streaming，执行完后继续

**复杂度**：中。Protocol 扩展 + TUI 渲染逻辑。

### Tasks（M6 计划）

详细 task cards：见 `docs/M6_TASK_CARDS.md`。

**M6-T0 必须解决的设计决策**（纳入 ADR）
- Proposal 提交方式：text JSON vs `submit_proposal` tool call（建议后者：解析更可靠，与 tool calling 流程统一，终止条件更清晰）
- Prompt 格式变更：从"直接输出 proposal.json"改为"先用工具收集信息、最后调用 submit_proposal 提交"
- `neonrp run` vs `neonrp agent run` 职责边界：前者为 dispatcher 路由的游戏主入口，后者为指定 agent 的专家/调试模式，两者共享 `core.agent_runner`
- Session 与 branch 绑定策略：MVP 做 session 绑定 branch，切换 branch 时创建新 session 或恢复该 branch 上一个 session
- Token 预算 MVP 策略：不做精确 token 计数，仅用 `max_turns` + `max_tool_calls` + tool result 字符截断（如 read_file 最多 5000 字符）

### Task dependencies
```
H12/H13 (Pre-M6 housekeeping)
  └→ M6-T0 (docs/ADRs)
       └→ M6-Tundo (undo/redo checkpoint 子系统)
       └→ M6-T1 (LLM tool-calling, non-streaming)
            └→ M6-T2 (agent_runner agentic loop + prompt rewrite)
                 ├→ M6-T3 (dispatcher + neonrp run)
                 ├→ M6-T4 (session persistence + context window)
                 └─── M6-Tundo + M6-T2 ──→ M6-T5 (auto-apply + safety/undo)
                                                 └→ M6-T6 (TUI game loop integration)
                                                      └→ M6-T8 (review gate)
M6-T7 (LLM streaming) — 独立可选，不阻塞 review gate
```
注：
- M6-T3/T4 可与 M6-T5 并行，但 M6-T5（auto-apply）**强依赖** M6-Tundo（undo checkpoint）。
- M6-T6（TUI game loop）依赖 M6-T3 + T4 + T5 全部完成。
- M6-T7（streaming）独立于 review gate，可在 M6.5 实现。

#### Pre-M6 — Housekeeping
- [x] H12: 统一 agent run 日志命名与完整性（对齐 input.json/diff.patch/validation.json/apply.json；修复 M5 review deferred）
- [x] H13: Agent spec 对齐（system_prompt 路径、defaults/context_limit、permissions 字段读取一致）

#### Milestone tasks
- [x] M6-T0: M6 Specs + ADRs（agentic loop/tool calling、dispatcher、session、streaming；含上述必须解决的设计决策）†
- [x] M6-Tundo: Undo/Redo checkpoint 子系统（自动 checkpoint + 原子恢复 game/ + 轮转策略）
- [x] M6-T1: LLMAdapter tool calling（非 streaming 版本）
- [x] M6-T2: `core/agent_runner` agentic loop（skills 执行 + 审计 + 终止条件 + prompt 模板重写 + agent template 更新）
- [x] M6-T3: Dispatcher / 自动路由 + `neonrp run` 升级（不再是 M0 echo）
- [x] M6-T4: Session 持久化 + 跨轮上下文窗口（`.neonrp/sessions/<branch>.jsonl`）
- [x] M6-T5: Auto-apply 模式（含安全阀 + undo 提示；依赖 M6-Tundo）
- [x] M6-T6: TUI game loop 整合（持续对话模式 + HUD）
- [x] M6-T7: LLM streaming（LLM 层完成；TUI 渲染集成推迟到 M6.5）
- [x] M6-T8: Review Gate

† M6-T0: 设计决策已在代码和 task cards 中落地，但计划中的 ADR 0015-0018 未单独创建。

### Acceptance
- [x] 默认输入自然语言即可完成：dispatcher 路由 → agentic loop（可多轮 tool call）→ diff/validate →（可选）apply
- [x] session 可落盘并可恢复；下一轮 prompt 注入最近 N 轮 session history（可在 trace 日志验证）‡
- [x] auto-apply=on 时，validation 通过即自动 apply；失败时不写入 game/，但保留审计日志并给出可操作错误
- [x] TUI 持续对话可用：两轮以上输入/输出连贯；HUD 显示 session_id/turn/auto-apply 状态
- [x] `neonrp run "<text>"` 从 M0 placeholder 升级为可用的一回合执行入口（与 TUI 走同一 core 路径）

‡ Session 写入已完成；TUI 启动时恢复上次 session 的功能推迟到 M6.5。

### Test requirements (per task)
- **Unit tests**: tool calling 协议解析、agentic loop 终止条件、dispatcher 路由评分、session 裁剪/注入、auto-apply 决策
- **Integration tests**: stub provider 驱动“tool_call → tool_result → proposal”完整链；apply/undo/redo 端到端
- **TUI tests**: Textual test mode 模拟按键发送两轮输入，验证 transcript 与 session log 更新

### Review Gate (mandatory after M6-T6; optionally after any task)
- [x] Run format/lint + tests
- [x] Run `opencode run` code review and save output to `reviews/`
- [x] Apply review fixes (or document non-adoption)
- [x] Log ALL review findings in `docs/PROGRESS.md` (per Review findings tracking)
- [x] Run tests again
- [x] Update `docs/PROGRESS.md` and checkboxes here

## M6.5 — Polish + 流程改进

> M6 后审查发现 6 项推迟/偏差，外加开发流程中暴露的文档跟踪缺失问题。M6.5 集中解决这些问题，使 RPG 体验从"管线可跑通"进化到"可持续游玩"。

### 背景（M6 Post-Review Audit 发现）

| 编号 | 问题 | 根因 | 严重度 |
|------|------|------|--------|
| P1 | System proposal（import/game new）undo 无法恢复 game/ | `create_checkpoint()` 仅在 `agent_runner.py` 调用，`system_proposal.py` 调用 `apply_proposal()` 时不经过 checkpoint | 中 |
| P2 | TUI 启动不恢复上次 session | `session.py` 有 read 函数，但 `tui/app.py:on_mount()` 不调用 | 中 |
| P3 | auto_apply 每次启动重置 | `auto_apply` 是 `NeonRPApp` 的内存状态，无持久化路径 | 低 |
| P4 | TUI 无 streaming 渲染 | `run_agent_agentic()` 用阻塞式 `chat()`，TUI 一次性渲染完整响应 | 低 |
| P5 | ADR 0015-0018 缺失 | M6-T0 计划创建但实际跳过，设计决策隐含在代码中 | 低 |
| P6 | 开发流程文档跟踪缺失 | 无自动化检查，agent 批量完成任务后遗漏 PROGRESS/ROADMAP 更新 | 流程 |

### Task dependencies
```
M6.5-T0 (流程改进, docs-only)
  ├→ M6.5-T1 (checkpoint 全覆盖)
  ├→ M6.5-T2 (session 恢复)
  ├→ M6.5-T3 (auto_apply 持久化)
  └→ M6.5-T5 (ADR 补齐, docs-only)
       └→ M6.5-T4 (streaming 渲染, 依赖 T2 完成后再接入)
            └→ M6.5-T6 (Review Gate)
```
注：T1/T2/T3 互相独立，可并行。T4（streaming）建议在 T2 之后做（session 恢复正常后再叠加 streaming 复杂度）。

#### Milestone tasks
- [x] M6.5-T0: 开发流程改进（质量门增强 + task card 模板 + 会话交接协议）
- [x] M6.5-T1: Checkpoint 全覆盖（apply_proposal 层面创建 checkpoint，覆盖 system proposal）
- [x] M6.5-T2: TUI Session 恢复（启动时加载上次 session + 注入 transcript）
- [x] M6.5-T3: auto_apply 持久化（保存到 state.json + 启动时加载）
- [~] M6.5-T4: TUI Streaming 渲染（**skipped**——可选，推迟到需要时再实现。LLM 层已就绪，见 ADR-0018）
- [x] M6.5-T5: ADR 补齐（0015-0018 retroactive creation）
- [x] M6.5-T6: Review Gate

### Acceptance
- [x] `game new --force` → undo → game/ 恢复（checkpoint 覆盖 system proposal）
- [x] TUI 退出后再进入：transcript 显示上次对话内容，turn count 正确
- [x] auto_apply toggle 跨 TUI session 保持
- [~] agentic loop 响应逐字显示在 transcript 面板（**skipped**——M6.5-T4 skip，LLM 层就绪，TUI 接入推迟）
- [x] ADR 0015-0018 存在且状态 Accepted

### Review Gate
- [x] Run format/lint + tests
- [x] Run `opencode run` code review and save output to `reviews/`
- [x] Apply review fixes (or document non-adoption)
- [x] Log ALL review findings in `docs/PROGRESS.md`
- [x] Run tests again
- [x] **（新增）执行文档完整性检查**：确认 PROGRESS.md 有每项任务的条目，ROADMAP.md checkbox 全部勾选
- [x] Update `docs/PROGRESS.md` and checkboxes here

---

## M7 — LLM Robustness + MVP Rules Engine + Docs + TUI Streaming

> M6/M6.5 delivered a working agentic loop, dispatcher, session, and TUI game loop — all tested with StubAdapter only. M7 makes NeonRP actually usable with real LLM providers, adds basic game mechanics enforcement, user-facing documentation, and TUI streaming.

### Background

| Gap | Root cause | File(s) |
|-----|-----------|---------|
| No retry for API errors (429, timeout) | `llm_openai.py` catch-all `Exception`, no retry | `core/llm_openai.py` |
| Tool arguments not validated | `_execute_tool()` passes args directly to skill | `core/agent_runner.py` |
| `submit_proposal` ops schema too loose | `skills.py:116-119` items is `"type":"object"` | `core/skills.py` |
| System prompt is one sentence | Fallback at `agent_runner.py:428-429` | `core/agent_runner.py` |
| No token budget tracking | Multi-turn loop accumulates unbounded context | `core/agent_runner.py` |
| Entity schema purely generic | `additionalProperties: true`, no per-kind fields | `game_entity.schema.json` |
| Zero game mechanics | HP/gold/inventory all LLM-improvised | — |
| No user documentation beyond quickstart | README has no tutorial, TUI undocumented | `README.md` |
| TUI renders one-shot | LLM layer has `chat_stream()`, TUI uses `chat()` | `tui/app.py` |

### Pre-M7 Housekeeping

- [x] H14: Path traversal defense-in-depth in `apply_proposal()` (resolve + relative_to check)
- [x] H15: `read_file` skill path description clarified ("relative to project root")
- [x] H16: `ARCHITECTURE.md` section 12.2 updated for M6 agentic loop

### Task Dependencies

```
H14/H15/H16
  └→ T0 (Specs + ADRs)
       ├→ T1 (Retry + error) → T2 (Tool validation) → T3 (Prompt + budget) → T4 (E2E harness)
       ├→ T5 (Per-kind schema) → T6 (Rules engine + resolve_action)
       ├→ T7 (User docs)  ← waits for T5/T6 examples
       └→ T8 (TUI streaming)
       └→ T9 (Review gate)
```

### Tasks

- [x] **M7-T0**: Specs + ADRs — task cards, ADR 0019 (LLM Error Handling), ADR 0020 (Rules Engine), ROADMAP update
- [x] **M7-T1**: LLM retry + error categories — `core/llm_errors.py` (new), retry loop in `llm_openai.py`, `config.llm.max_retries`
- [x] **M7-T2**: Tool argument validation — `validate_tool_arguments()` in `skills.py`, tighten submit_proposal ops schema
- [x] **M7-T3**: System prompt enrichment + token budget — structured default prompt, `_estimate_tokens()`, budget warning/termination
- [x] **M7-T4**: Real LLM E2E test harness — `tests/test_llm_e2e.py` with `@pytest.mark.e2e_llm`, 5 scenarios
- [x] **M7-T5**: Entity schema per kind — `if/then` blocks for character/item/location, `game new` template update
- [x] **M7-T6**: Rules engine — `core/rules.py` (new), post-staging validation hook, `resolve_action` skill
- [x] **M7-T7**: User documentation — `TUTORIAL.md`, `CLI_REFERENCE.md`, `TUI_GUIDE.md`, example world
- [x] **M7-T8**: TUI streaming — `on_chunk` callback, `chat_stream()` in agentic loop, incremental transcript rendering
- [x] **M7-T9**: Review gate

### Acceptance Criteria

- [x] OpenAI adapter retries 429/timeout with exponential backoff (up to 3 retries)
- [x] Tool argument validation prevents crashes from malformed LLM calls
- [x] `submit_proposal` ops have enforced structure (op enum, required path)
- [x] Default system prompt includes tool descriptions, rules, context
- [x] Token budget tracking prevents unbounded context growth
- [x] At least 5 real LLM e2e tests exist (conditional on API key)
- [x] Entity schema supports per-kind fields (character/item/location)
- [x] Post-staging rules validation catches negative hp/gold, invalid inventory
- [x] `resolve_action` skill provides mechanical outcome resolution
- [x] `TUTORIAL.md` enables zero-to-first-turn walkthrough
- [x] All CLI commands documented in `CLI_REFERENCE.md`
- [x] TUI documented in `TUI_GUIDE.md`
- [x] TUI renders LLM responses token-by-token (streaming)
- [x] All 532+ existing tests remain green
- [x] 60-70 new tests added (538 total)

### Review Gate

- [x] Run format/lint + tests
- [x] Run `opencode run` code review and save output to `reviews/`
- [x] Apply review fixes (all must-fix items resolved)
- [x] Log ALL review findings in `docs/PROGRESS.md`
- [x] Run tests again (538 passed)
- [x] 执行文档完整性检查
- [x] Update `docs/PROGRESS.md` and checkboxes here

---

## M8 — Universal Tools + Sub-Agents + Per-Agent LLM

> M7 delivered a robust, tested engine. M8 transforms NeonRP from a "read-and-propose" engine into a full agent platform with Claude Code-level capabilities: direct file manipulation, sub-agent orchestration, structured user interaction, and per-agent model routing.

### Background: M7 Post-Review Gap Analysis

| Gap | Severity | Description |
|-----|----------|-------------|
| No sub-agent orchestration | **CRITICAL** | Dispatcher routes to single agent; no agent-calls-agent pattern |
| Tool set too limited | **CRITICAL** | Only 6 skills; missing Write/Edit/Glob/Grep/Task/AskUser |
| No structured interaction | **CRITICAL** | No AskUserQuestion; free text only |
| All agents share one LLM | **MAJOR** | No per-agent model/provider customization |

### Pre-M8 — Housekeeping

(None identified — M7 review gate clean)

### Task Dependencies

```
M8-T0 (Specs + ADRs)
 ├→ M8-T1 (write_file + edit_file)  ─┐
 ├→ M8-T2 (glob + grep)             ─┤── parallel
 │                                    │
 ├→ M8-T3 (ask_user + TUI)    ←──────┘ (depends on T1 SkillRegistry pattern)
 │
 ├→ M8-T4 (task + sub-agent + resume)  ← depends on T1-T3
 │
 ├→ M8-T5 (per-agent LLM config)       ← depends on T4
 │
 ├→ M8-T6 (integration + orchestrator)  ← depends on T5
 │
 └→ M8-T7 (review gate)
```

### Tasks

- [x] M8-T0: Specs + ADRs — ADR 0021 (Universal Tools), ADR 0022 (Sub-Agent Task), ADR 0023 (Per-Agent LLM), M8 task cards, ROADMAP update
- [x] M8-T1: write_file + edit_file skills — dual-mode write (proposal vs direct), `check_write_permission()`, `atomic_write_text()`
- [x] M8-T2: glob + grep skills — file discovery and content search with permission filtering
- [x] M8-T3: ask_user skill + TUI/CLI rendering — sentinel protocol, `on_ask_user` callback
- [x] M8-T4: task tool + sub-agent + resume — 2-layer depth, recursive dispatch, SubAgentState
- [x] M8-T5: per-agent LLM configuration — `ProviderConfig`, provider registry, `resolve_provider()`, `get_adapter_from_config()`
- [ ] M8-T6: integration + orchestrator example — end-to-end tests, `examples/multi-agent/`, doc updates
- [ ] M8-T7: Review Gate

### Acceptance

- [x] `write_file` writes to `direct_write_globs` paths; errors on game/ paths guiding to `submit_proposal`
- [x] `edit_file` does exact string replacement with safety checks (0/N match errors)
- [x] `glob` and `grep` discover files/content with permission filtering and bounded results
- [x] `ask_user` pauses agentic loop, surfaces question to TUI/CLI, resumes with response
- [x] `task` delegates to sub-agent at depth 0; sub-agents (depth 1) cannot call `task`
- [ ] Sub-agent state can be saved and resumed via `resume_run_id`
- [ ] Each agent can specify its own LLM via `llm.provider_ref` or inline `llm` block
- [ ] Provider registry in `config.json` supports named provider configurations
- [ ] CLI `--provider` flag overrides per-agent config
- [ ] Orchestrator → sub-agent pipeline works end-to-end with stub provider
- [ ] All 538+ existing tests remain green; 91+ new tests added (target: 629+)

### Test Requirements

- **Unit tests**: Permission checks (write/read), skill execution, depth limiting, provider resolution, state serialization
- **Integration tests**: Orchestrator → task(narrator) pipeline, ask_user in loop, per-agent LLM, mixed write modes
- **TUI tests**: ask_user rendering, option selection

### Review Gate (mandatory after M8-T6)

- [ ] Run format/lint + tests
- [ ] Code review → `reviews/M8_review_<date>.md`
- [ ] Apply review fixes
- [ ] Log findings in `docs/PROGRESS.md`
- [ ] Run tests again
- [ ] Documentation completeness check
- [ ] Update `docs/PROGRESS.md` and checkboxes here

---

## M9 — 对话循环 + TodoManager + Skills

> M8 建成了完整的 agent 平台（通用工具、子代理、per-agent LLM），但核心缺陷是：没有持续对话循环。每次 agent run 是独立的一次性调用，无历史累积，模型必须通过 submit_proposal 结束。M9 参照 ../learn-claude-code 项目，实现 v1（对话循环）+ v2（TodoManager 任务规划）+ v4（Skills 知识注入），同时集成 NeonRP 已有的 RPG 管理功能。

### Background: M8 Post-Diagnostic Analysis

| Gap | Severity | Description |
|-----|----------|-------------|
| No conversation loop | **FATAL** | No persistent input→response→input cycle; each run is isolated |
| No conversation history to LLM | **FATAL** | Model has no memory of previous turns |
| Narrative output swallowed | **FATAL** | User sees JSON diff, not story text |
| Proposal-only file ops | **FATAL** | Model cannot directly read/write game files in Build mode |
| Default stub provider | **MAJOR** | First-time user gets no AI response |
| No game loop state machine | **MAJOR** | Missing scope/location/time routing |

### Three Modes

| Mode | File Ops | Stop Condition | Event Recording | Use Case |
|------|---------|---------------|----------------|----------|
| **Build** (default) | Direct read/write/edit | Model natural end | Auto event + checkpoint | World building |
| **Sandbox** | Proposal → validate → apply | submit_proposal | Existing apply pipeline | What-if testing |
| **Play** | Direct read/write/edit | Model natural end | Auto event + checkpoint | Gameplay |

### Task Dependencies

```
M9-T0 (doc-first)
M9-T1 (conversation.py)  ← core engine, blocks all others
  ├── M9-T2 (todo.py)     ← can parallel with T3, T4
  ├── M9-T3 (skill_loader.py + skills/)  ← can parallel with T2, T4
  ├── M9-T4 (prompts.py)  ← can parallel with T2, T3
  └── M9-T5 (app_v2.py)   ← requires T1-T4
       └── M9-T6 (tui.py + commands.py) ← requires T5
M9-T7 (review gate) ← requires all above
```

### Tasks

- [x] M9-T0: Specs + Design Doc — diagnostic report, M9 task cards, ROADMAP update
- [x] M9-T1: Conversation engine (`core/conversation.py`) — `run_conversation_turn()` + `ConversationSession` + auto event/checkpoint
- [x] M9-T2: TodoManager (`core/todo.py`) — task planning tool, ported from learn-claude-code v2
- [x] M9-T3: Skills system (`core/skill_loader.py` + preset skills) — knowledge injection, ported from learn-claude-code v4
- [x] M9-T4: System prompt templates (`core/prompts.py`) — mode-aware prompt generation
- [x] M9-T5: New TUI — Claude Code style (`tui/app_v2.py`) — single-pane conversational TUI
- [x] M9-T6: CLI entry + commands — wire new TUI as default, add `/mode`, `/clear`, `/files`, `/skills`
- [x] M9-T7: Review Gate (ruff + pytest + opencode review + doc update)

### Acceptance

- [x] Launch TUI → type natural language → see streaming narrative output (not JSON diff)
- [x] File modifications create auto event + checkpoint (Build/Play modes)
- [x] Conversation history persists across turns (model remembers previous exchanges)
- [x] TodoManager: model uses TodoWrite for multi-step planning
- [x] Skills: model loads specialized knowledge via Skill tool
- [x] `/mode sandbox` switches to Proposal pipeline
- [x] `--legacy` flag launches old 4-pane TUI
- [x] All 626 existing tests still pass; ~75 new tests added (700+ total)

### Test Requirements

- **Unit tests**: Conversation turn execution, TodoManager validation, SkillLoader parsing, prompt generation
- **Integration tests**: ConversationSession full flow (send → persist → event → checkpoint), mode switching
- **TUI tests**: Textual test mode — app mount, streaming display, slash commands, tool indicators

### Review Gate (mandatory after M9-T6)

- [x] Run format/lint + tests
- [x] Code review via opencode → `reviews/M9_review_20260207.md`
- [x] Apply review fixes
- [x] Log findings in `docs/PROGRESS.md`
- [x] Run tests again
- [x] Documentation update (TUTORIAL.md, CLI_REFERENCE.md)
- [x] Update `docs/PROGRESS.md` and checkboxes here

---

## M10 — M9 Review 修复 + TUI 改进

> M9 评分 87/100。M10 修复差距评估（`reviews/M9_gap_assessment.md`）和代码审查（`reviews/M9_review_20260207.md`）中识别的 P0/P1 问题，目标 92/100。

### Tasks

- [x] M10-T0: Specs + Design Doc — 差距评估分析，M10 任务卡，ROADMAP 更新
- [x] M10-T1: ask_user 模态对话 — `AskUserScreen(ModalScreen)` + `threading.Event` 阻塞等待
- [x] M10-T2: ConversationView 重构 + Markdown 渲染 — `RichLog` → `VerticalScroll` + `Markdown`/`Syntax` 分段渲染
- [x] M10-T3: /stats + /compact 命令 — 对话统计 + 手动压缩
- [x] M10-T4: SkillLoader 修复 — `get_description(name)` + mtime 缓存
- [x] M10-T5: Review Gate (ruff + pytest + doc update)
- [x] M10-T6: TUI 体验打磨（流式状态/Thinking 展示、工具调用单行摘要+详情、输入历史与命令候选、渲染间距/样式修复）
- [x] M10-T7: 斜杠命令交互对齐 Claude Code（Enter 即执行、Tab 补全+隐藏、ghost text 参数提示、子命令 args hint、async flag 时序修复）
- [x] M10-T8: 覆盖率补测 + 真实端点 E2E（conversation/retrieval/suggestions 补齐；新增基于 `~/.neonrp/config.json` 的真实端点测试）

### Acceptance

- [x] ask_user: 代理提问 → 模态窗口 → 用户回答 → 注入对话
- [x] Markdown: 对话面板原生 markdown 高亮
- [x] /stats 显示对话统计
- [x] /compact 压缩长对话
- [x] /skills 不崩溃
- [x] 输入 `hello` 不再触发 `run_worker` 参数错误崩溃
- [x] 未配置端点/API Key 时给出明确配置引导（含用户级配置路径 `~/.neonrp/config.json`）
- [x] 流式阶段可见等待状态与 Thinking 文本；工具调用顺序稳定且支持单行摘要
- [x] 斜杠命令：Enter 选中即执行、Tab 补全带空格+隐藏 popup、Suggester ghost text 显示参数提示
- [x] 覆盖率补测完成：`core/conversation.py`、`core/retrieval.py`、`tui/suggestions.py` 关键缺口已补并具备回归用例
- [x] 真实端点验证：`NEONRP_E2E_LLM=1` 下可通过用户配置端点完成 `chat/chat_stream` 测试
- [x] Regression: 所有测试通过 (803 passed, 7 skipped)

### Review Gate (mandatory after M10-T4)

- [x] Run format/lint + tests
- [x] Update gap assessment
- [x] Update `docs/PROGRESS.md` and checkboxes here

---


---

## M10.1 -- TUI & Agent Improvements (completed 2026-02-10)

### M10.1-T1: ESC Interrupt for In-Flight Calls [x]
### M10.1-T2: Configurable Max Tool Call Rounds [x]
### M10.1-T3: Incremental History Saving (Claude Code Style) [x]
### M10.1-T4: Session UX Controls (`/sessions`, `/continue`, `/new`, startup flags) [x]
### M10.1-T5: Verbose Debug Mode (`--verbose`, `/verbose`) [x]
### M10.1-T6: TUI Reliability & UX Fixes (todo rendering, autoscroll, continue restore) [x]

### M10.1 Acceptance

- [x] ESC can safely interrupt in-flight turns without breaking subsequent requests.
- [x] `tui.max_tool_rounds` is configurable and enforced by conversation loop.
- [x] Session history is incrementally persisted; startup policy supports `--continue` and `--new`.
- [x] `/sessions` shows branch history picker and can load archived sessions.
- [x] Verbose mode writes structured debug logs and supports on/off/status commands.
- [x] Todo list behavior and rendering are stable across normal runs and `/continue` restores.

---

## M11 — MCP Protocol Integration (Core Completed, P1)

> 设计与审查基线：`docs/M11_TASK_CARDS.md`
> ADR:
> - `docs/ADRs/0024-mcp-integration-scope-and-compatibility.md`
> - `docs/ADRs/0025-mcp-tool-router-and-permission-model.md`

### Tasks

- [x] M11-T0: 规格冻结 + ADR（MCP 集成边界与兼容策略）— ADR 0024, 0025 promoted to Accepted
- [x] M11-T1: Config Model — `MCPServerConfig` dataclass + `mcp_servers` in `ProjectConfig`
- [x] M11-T2: MCP Client Core — `MCPClient` sync wrapper for stdio transport (14 tests)
- [x] M11-T3: MCP Pool — `MCPPool` multi-server management with lazy start/health/restart (18 tests)
- [x] M11-T4: ToolRouter — schema merge + namespace dispatch + conversation wiring (23 tests)
- [x] M11-T5: Permission + Audit — deny/confirm/auto + tool-level overrides + JSONL audit
- [x] M11-T6: TUI `/mcp` command — status/restart subcommands

### Acceptance

- [x] 未配置 `mcp_servers` 时，行为与 M10.1 完全一致
- [x] 已配置 MCP server 时，LLM 可稳定看到并调用 MCP tools
- [x] MCP tool 调用受权限策略控制，并记录审计日志
- [x] TUI/CLI 可查看 MCP server 状态并执行基本运维动作

---

## M11.1 — Embedding Retrieval + Reliability Hardening (completed 2026-02-16)

### Tasks

- [x] M11.1-T1: 代码审查执行与修复落地 — `reviews/code_review_20260216.md` findings closed in code
- [x] M11.1-T2: 向量检索基础设施 — 新增 `core/embedding.py`（adapter + `VectorIndex` + 持久化）
- [x] M11.1-T3: `read_context` 混合检索 — fuzzy + vector blending，vector 失败自动降级
- [x] M11.1-T4: `index build` 默认预计算向量（当 `embedding.enabled=true`）
- [x] M11.1-T5: embedding 配置简化兼容 — 支持 `embedding.model_ref` 从 `models` 继承 provider/model/auth/base_url
- [x] M11.1-T6: 覆盖率与回归测试 — 新增 `tests/test_embedding.py`、`tests/test_retrieval_fuzzy.py`，并补强既有测试

### Acceptance

- [x] 启用 embedding 后，`context` / `read_context` 默认走混合检索；禁用时保持 fuzzy-only
- [x] `index build` 在 embedding 启用时会生成/刷新 `.neonrp/embeddings.json`
- [x] 新配置格式 `embedding: { enabled, model_ref }` 可直接生效，不要求重复填写 provider/model/base_url
- [x] 代码审查报告中的阻断问题已修复并有回归测试覆盖
- [x] 回归测试通过（本轮最小验证：`uv run pytest tests/test_config.py tests/test_embedding.py tests/test_retrieval.py tests/test_retrieval_fuzzy.py tests/test_indexing.py -q`）

### Review Gate

- [x] Code review report created and archived
- [x] Findings fixed
- [x] Tests rerun
- [x] `docs/PROGRESS.md` and architecture docs updated

---

## M12 — Sub-Agent Delegation Reliability + `game new` Template Expansion (In Progress)

> 计划基线：`docs/M12_TASK_CARDS.md`  
> 问题诊断：`docs/ISSUE_SUB_AGENT_AUTO_EXIT.md`
> 关键契约：`docs/ADRs/0026-sub-agent-delegation-contract.md`

### Tasks

- [x] M12-T0: Specs Freeze + Scope Lock（任务卡与范围冻结）
- [ ] M12-T1: Repro Harness + Baseline Metrics
- [~] M12-T2: Narrator Prompt Contract v2（强制委托规则）
- [~] M12-T3: `my-rpg` Agent Audit + Rewrite（职责/边界/交接）
- [~] M12-T4: Active-Agent State Protocol
- [~] M12-T5: Runtime Guardrails in Conversation Loop
- [x] M12-T5b: Router Execution Modes（`fast` / `orchestrator` / `multi-agent` placeholder）
- [~] M12-T6: Expand `/game new` Default Template from `my-rpg`
- [ ] M12-T7: Migration + Backward Compatibility
- [ ] M12-T8: Scenario E2E + Metrics
- [ ] M12-T9: Review Gate

### Current Acceptance Snapshot

- [~] `active-agent` 文件协议已接入核心代码路径（读写/校验 + 会话路由）
- [~] narrator 越权保护已加入运行时 guardrail（阻止直接 game 实体写操作）
- [x] sticky 子代理成功回合已短路：narrator 在同一回合不再二次发起 LLM 请求
- [x] 子代理回合上限已统一到会话/配置 `max_turns`（agent 级 `max_task_turns` 在运行时忽略）
- [~] `/game new` 默认模板已扩充为多代理 RPG 基线（含 narrator/town-agent/dungeon-agent）
- [x] 路由职责边界固定：`game-start.json` 仅作为 bootstrap contract，`active-agent.json` 仅作为 live routing contract
- [x] router execution mode 已分层：`fast` 保留当前前台 specialist 语义；`orchestrator` 采用 narrator/orchestrator 永远前台输出、单个顶层 loop 且禁止 self-recursive re-entry 的新语义
- [ ] `my-rpg` 的完整场景 E2E 结果与指标（delegation correctness / wrong-owner op）待补

---

## L14 — Unified WorldLines TUI (Planned)

> 计划基线：`docs/L14_UNIFIED_TUI_SPEC.md`

### Tasks

- [ ] L14-T1: Claude-style single-pane TUI shell
- [ ] L14-T2: Inline input-area status metadata
- [ ] L14-T3: Unified onboarding hub inside TUI
- [ ] L14-T4: Character create/import built-ins
- [ ] L14-T5: World create/import built-ins
- [ ] L14-T6: OpenRouter-first hosted provider onboarding
- [ ] L14-T7: Claude workspace bootstrap (`.mcp.json`, `.claude/agents`, `CLAUDE.md`)
- [ ] L14-T8: Narrative semantic folding
- [ ] L14-T9: Discord bootstrap integration

### Acceptance

- [ ] TUI default surface is transcript-first and single-pane
- [ ] Top status bar is replaced by inline input-area metadata
- [ ] `worldlines` and `neonrp` share the same TUI experience
- [ ] Character/world onboarding flows are available in-TUI
- [ ] OpenRouter is a first-class setup option
- [ ] MCP / Claude workspace bootstrap is visible and confirmable
- [ ] Default transcript view is narrative-first with foldable execution detail

---

## M13 — Claude Code 必要能力移植到 NeonRP (Planned)

> 计划基线：`docs/M13_TASK_CARDS.md`

### Goal

把 Claude Code 中对长时会话、复杂 agent loop、可靠委托与恢复真正必要的能力移植到 NeonRP，为更复杂的游戏内容打基础。

### Tasks

- [ ] M13-T0: Scope Lock + Capability Audit
- [ ] M13-T1: Context Compression + Budget Policy
- [ ] M13-T2: Dynamic Turn Management
- [ ] M13-T3: Persistent Sub-Agent + Mailbox
- [ ] M13-T4: Turn Sequence / Loop Orchestration
- [ ] M13-T5: Runtime Hardening Borrowed from Claude Code
- [ ] M13-T6: Review Gate

### Acceptance

- [ ] 长会话运行能力形成闭环
- [ ] 多代理 loop 的持久化、排序、恢复能力稳定
- [ ] 至少一个复杂世界场景能稳定跑通，为 M15 铺路

---

## M14 — Role Play Benchmark (Planned)

> 计划基线：`docs/M14_TASK_CARDS.md`
> 方法参考：`ClawProBench` 风格的 live-first benchmark harness、scenario catalog、profiles、deterministic grading、resume/compare workflow

### Goal

把你定义的 RP `aha moment` 抽象成可复现、可比较、可回归的 benchmark，用于验证 NeonRP 的 role play agent 能力。

### Tasks

- [ ] M14-T0: Scope Lock + Benchmark Taxonomy
- [ ] M14-T1: Scenario Catalog + Schema
- [ ] M14-T2: State Probes + Deterministic Graders
- [ ] M14-T3: Benchmark Runner
- [ ] M14-T4: Core Profile Build-out
- [ ] M14-T5: Baseline Report + Comparison Workflow
- [ ] M14-T6: Regression Gate for Future Milestones

### Acceptance

- [ ] 建立 live-first 的 RP benchmark harness
- [ ] 建立 scenario catalog / schema / inventory / dry 工作流
- [ ] 10 个 `aha moment` 至少有 6 个进入 `core` active profile
- [ ] deterministic grading 成为主要评分来源
- [ ] 形成首份可比较的 benchmark baseline report
- [ ] benchmark 可作为 M15 的回归质量门

---

## M15 — More Complex Game Content (Planned)

> 当前基线：`docs/M15_TASK_CARDS.md`（待按新命名体系继续重构）

### Goal

在 M13 打好引擎/runtime 基础后，推进更复杂的游戏内容、叙事工具、世界规则与多世界迁移能力。

### Expected scope

- [ ] 更复杂的叙事工具与世界交互工具
- [ ] 确定性 game-mechanic tools（如 `roll_check` / `resolve_check`）
- [ ] 支持神乐岛级别的复杂世界内容
- [ ] `M15.x` 分支：参考 `llm-rpg-starter` heroine 的 `Soul.md` 高规格 NPC 系统
- [ ] 复杂世界迁移、验证与体验闭环

---

## Backlog — 无限期推迟

以下功能无限期推迟，不设时间线：

- **Mods**：mod manager (install/enable/disable)、mods directory layout + dependency/compat rules、packaging/export
- **多 agent 并行调度**：多个 agent 同时运行，合并 proposals
- **Sandbox merge / Cherry-pick**：沙盒变更合并回主线
- **自定义模板目录**：`game new --template` 支持用户自定义模板
- **命令插件机制**：第三方命令注册
