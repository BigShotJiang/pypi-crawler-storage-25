# 问题诊断：子代理（Sub-Agent）自动退出

> **日期**: 2026-02-17
> **来源**: `my-rpg` 项目对话日志分析
> **严重度**: 高 — 破坏了多代理协作的核心设计意图

---

## 1. 问题描述

在 `my-rpg` 中，narrator 应将城镇操作委托给 `town-agent`，由后者全权负责直到玩家离开城镇。
实际表现为：**narrator 通过 `task` 工具委托后，town-agent 处理完一个 prompt 就立即退出，
控制权回到 narrator，narrator 随后自己接管城镇操作。**

### 期望行为

```
玩家输入 → narrator → task(town-agent) → town-agent 持续处理所有城镇交互
                                         → 玩家说"离开城镇"时 town-agent 退出
                                         → 控制权返回 narrator
```

### 实际行为

```
玩家输入 → narrator → task(town-agent, "处理购物")
                      → town-agent 完成购物后返回结果（one-shot）
                      → narrator 拿到结果后自己继续处理后续城镇交互 ❌
```

---

## 2. 对话日志证据

**Session 文件**: `my-rpg/.neonrp/sessions/main.jsonl`（158 条消息）

### Run 1: `narrator_20260217_101637_0cf70b41`

- narrator 独自处理森林探索、任务完成、奖励发放
- **从未调用 `task` 工具**，完全绕过了子代理机制

### Run 2: `narrator_20260217_102323_3c90dd04`

| 消息 # | 事件 | 问题 |
|---------|------|------|
| 121 | 用户要求 narrator 路由给城镇代理 | — |
| 122–135 | narrator 编辑 `town-agent/agent.json` 写入系统提示 | 前置修复 |
| **136** | **narrator 调用 `task(town-agent, ...)`** | ✅ 首次正确委托 |
| **137** | **town-agent 完成，返回 `success`，`turns_used: 10`** | ✅ 子代理工作正常 |
| **138** | **narrator 自己调用 `ask_user` 继续城镇购物** | ❌ 没有再次委托 |
| 139–150 | narrator 自己调 `resolve_action`、`read_file`、`glob` 处理购物 | ❌ 完全接管 |

> **关键**：消息 137→138 的转换 — town-agent 正常退出后，narrator 没有再次 `task` 委托，
> 而是自己继续处理城镇事务。

### Run 3: `narrator_20260217_102532_425daaf1`

- 用户再次指出问题后，narrator 正确使用 `task` 委托（5 turns），本次正常

---

## 3. 根本原因分析

### 3.1 `task` 工具的 One-Shot 设计

`_dispatch_sub_agent()`（`conversation.py:1022-1139`）调用 `run_conversation_turn()` 处理
一个 prompt。当 LLM 产生无 tool_call 的纯文本回复时，函数正常返回（`conversation.py:358-375`）。

```python
# conversation.py:358-375
if not turn_result.tool_calls:
    return _finalize_turn(...)  # ← 子代理在此退出
```

**这是设计意图，不是 bug。** `task` 等同于 Claude Code 的子代理 `task` 工具 — 每次调用是
一个独立的、有限范围的子任务。

### 3.2 Narrator 系统提示词缺乏强制委托规则

`agents/narrator/system.md` 的路由规则只是描述性指南：

```markdown
## Agent Routing Rules
| Action Type | Target Agent |
| Town interactions | Town Agent |
...
## Communication Protocol
3. **Delegate**: Use task() to delegate to target agent
```

**缺失的关键约束**：
- 没有说"必须为**每个**城镇操作都调用 `task`"
- 没有说"narrator 自己绝对不能处理城镇/地下城操作"
- 没有说"当 task 返回后，如果玩家仍在城镇，后续操作必须再次 `task`"

### 3.3 缺乏"活跃代理"状态追踪

系统中没有记录"当前应由哪个代理处理交互"的状态。narrator 每次接收用户消息时都从零判断
是否需要委托，容易遗忘。

---

## 4. 推荐修改方案

### 方案 A：增强 System Prompt（最小改动，立即可用）

**改动范围**: `agents/narrator/system.md`

在 **Important Rules** 部分加入严格的委托规则：

```markdown
## Mandatory Delegation Rules

> ⚠️ CRITICAL: You are the NARRATOR. You MUST NOT directly handle game operations.
> ALL game operations MUST be delegated to the appropriate agent via the task() tool.

1. **Every** player action in a town location → `task(town-agent, ...)`
2. **Every** player action in a dungeon location → `task(dungeon-agent, ...)`
3. **After** a task() returns, if the player is still in the same location type,
   the NEXT action MUST also be delegated via task()
4. You may ONLY directly handle:
   - Pure narrative descriptions (scene transitions)
   - Routing decisions (determining which agent handles a request)
   - Reading game state for routing decisions
5. If you catch yourself calling read_file/write_file/edit_file/resolve_action
   for game entity operations — STOP and delegate via task() instead
```

**优点**: 零代码改动，几分钟完成
**缺点**: 依赖 LLM 遵循指令，不完全可靠

### 方案 B：引入"活跃代理"状态（中等改动）

在 game state 中记录当前应由哪个代理处理交互：

**改动范围**: `game/meta/` + `conversation.py` + `narrator/system.md`

1. 新增 `game/meta/active-agent.json`:
```json
{
  "active_agent": "town-agent",
  "reason": "player is in start-town",
  "exit_condition": "player leaves town location"
}
```

2. `narrator/system.md` 添加规则：
```markdown
## Active Agent Protocol
- At the start of each turn, read `game/meta/active-agent.json`
- If active_agent is set and not "narrator", you MUST delegate via task()
- Only clear active_agent when the exit_condition is met
- When delegating, instruct the sub-agent to update active-agent.json
  with the appropriate exit condition
```

3. Town-agent 的 system prompt 添加：
```markdown
- When the player says they want to leave town, update active-agent.json
  to set active_agent back to "narrator"
- Until then, continue handling all town operations
```

**优点**: 更可靠，状态持久化
**缺点**: 仍依赖 LLM 正确更新状态文件

### 方案 C：代码层面实现持续委托（大改动，最可靠）

**改动范围**: `conversation.py` + `agent_runner.py` + agent configs

在 `task` 工具增加 `persistent: true` 选项，使子代理进入"持续模式"：

```python
# task tool schema 新增参数
{
    "persistent": {
        "type": "boolean",
        "description": "If true, the sub-agent stays active and receives
                       subsequent user messages until it calls exit_task()"
    }
}
```

**实现要点**:

1. `ConversationSession` 新增 `_active_sub_agent: str | None` 状态
2. 当 `persistent=true` 时，`send()` 方法将后续用户消息直接路由给子代理的
   `run_conversation_turn()`，而非返回 narrator
3. 子代理获得新工具 `exit_task(reason: str)` — 调用后清除持续委托状态
4. 子代理的对话历史在持续模式中保持（不是每次 one-shot）

```
send("买药水") → session._active_sub_agent = "town-agent"
  → town-agent 处理购物，不调用 exit_task → 保持活跃

send("买铁剑") → session 检测 _active_sub_agent = "town-agent"
  → 直接路由给 town-agent（跳过 narrator）

send("离开城镇") → town-agent 调用 exit_task("player leaving town")
  → session._active_sub_agent = None
  → 控制权返回 narrator
```

**优点**: 代码层面保证，不依赖 LLM 遵循指令
**缺点**: 改动量大，需要改 `ConversationSession`、`task` schema、工具执行逻辑、
子代理消息持久化等

---

## 5. 推荐实施路径

```
阶段 1（立即）: 方案 A — 增强 narrator system prompt
阶段 2（M12）:  方案 B — 引入 active-agent.json 状态
阶段 3（M13+）: 方案 C — 代码层面持续委托（如果 A+B 仍不够可靠）
```

**优先级**: 阶段 1 是必做项，可以在几分钟内完成。阶段 2/3 根据实际游戏体验决定。

---

## 6. 相关文件

| 文件 | 角色 |
|------|------|
| `src/neonrp/core/conversation.py` | `_dispatch_sub_agent()` — task 工具入口 |
| `src/neonrp/core/conversation.py:358-375` | 子代理退出条件（无 tool_call 时返回） |
| `src/neonrp/core/agent_runner.py:38` | `_build_task_tool_schema()` — task schema |
| `my-rpg/agents/narrator/system.md` | narrator 系统提示词 |
| `my-rpg/agents/town-agent/agent.json` | town-agent 配置 |
| `my-rpg/.neonrp/sessions/main.jsonl` | 问题现场对话记录 |
