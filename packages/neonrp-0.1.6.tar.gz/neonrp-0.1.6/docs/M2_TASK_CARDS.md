# M2 Task Cards (Agents + Plan/Diff/Apply)

这些 task cards 面向"让 Codex/自动化代理按卡片逐个推进"。每张卡片尽量控制在一次小 PR 的规模内。

质量门（每张卡片收尾必跑）：见 `docs/QUALITY_GATES.md`。

## Task dependency graph
```
H2 (GameEvent actor field) ──→ M2-T0 (doc/ADR)
                                  └→ M2-T1 (agent CLI)
                                  └→ M2-T2 (proposal + permissions) ──→ M2-T3 (diff)
                                                                          └→ M2-T4 (apply engine)
                                                                                └→ M2-T5 (logs/rerun)
                                                                                └→ M2-T6 (integration)
                                                                                      └→ M2-T7 (review gate)
```
注：M2-T1（agent CLI）和 M2-T2（proposal + permissions）可并行开发，两者都依赖 M2-T0（doc/ADR）。

## Output format convention
延续 M1 约定：所有 M2 CLI 命令支持 `--json` 输出标志（agent list/show/run/logs）。

---

## H2 — GameEvent 添加 `actor` 字段（Pre-M2 Housekeeping）

**Goal**
- 在 GameEvent 模型中添加 `actor` 字段，满足 M2 event log integration 需求。

**Existing code**
- `src/neonrp/core/event_log.py` — GameEvent 模型（当前只有 id/timestamp/type/payload）
- `src/neonrp/commands/run.py` — 调用 `append_event`

**New work**
- GameEvent 添加 `actor: Optional[str] = None`
- 更新 `run.py` 中现有事件（`actor=None` 或 `actor="player"`/`"system"`）
- 更新相关测试

**Acceptance**
- GameEvent 序列化/反序列化正确包含 actor 字段
- 已有事件（无 actor）能正确反序列化（向后兼容）

**Tests**
- 单测：GameEvent 带/不带 actor 的序列化与反序列化

---

## M2-T0 — Agent 规格 + 权限边界（Doc/ADR first）

**Goal**
- 固化 agent 的目录结构、定义文件格式、权限模型与日志落盘约定。

**Primary docs**
- `docs/M2_AGENTS_PLAN_DIFF_APPLY_DESIGN.md`
- `docs/ADRs/0006-agent-spec-and-permissions.md`
- `docs/ADRs/0007-proposal-format-plan-diff-apply.md`

**Acceptance**
- 明确：agent 放在 `agents/<id>/`；运行日志放在 `.neonrp/logs/agents/<run_id>/`
- 明确：write_globs/deny_globs 的语义与优先级（deny 优先）
- 明确：deny_globs 默认包含 `.neonrp/**` 和 `agents/**`
- 明确：proposal.json 的最小 schema、ops 词汇表（upsert_text/delete）与版本字段
- 明确：run_id 格式（`{ISO8601}_{6hex}`）

---

## M2-T1 — `neonrp agent` 命令组（new/list/show/path）

**Goal**
- 提供 agent 生命周期的基础命令（不要求接入真实 LLM）。

**Existing code**
- `src/neonrp/cli.py` — click group 注册模式（参考 M1 index 子命令组）
- `src/neonrp/core/paths.py` — 路径工具函数

**New work**
- `src/neonrp/commands/agent.py`（click group：new/list/show/path）
- `src/neonrp/cli.py` 注册 agent 命令组
- `agent new <id>` 生成模板目录（agent.json + system.md），deny_globs 默认含 `.neonrp/**` 和 `agents/**`
- `list/show` 支持 `--json`

**Acceptance**
- `neonrp agent new <id>` 创建 `agents/<id>/` 目录与模板文件
- `neonrp agent list [--json]` / `show <id> [--json]` / `path <id>` 可用，错误信息可操作
- id 包含非法字符时 exit code = 1

**Tests**
- CLI：`CliRunner` 覆盖 new/list/show/path + 错误场景

---

## M2-T2 — Proposal 格式与校验器 + 权限引擎

**Goal**
- 让"结构化提案"可被机器检查并作为 apply 的唯一输入。
- 实现权限检查逻辑。

**Existing code**
- `src/neonrp/core/validation.py` — `ValidationIssue` dataclass 可参考错误格式

**New work**
- `src/neonrp/core/proposal.py` — Proposal/Op Pydantic 模型（proposal_version, agent_id, run_id, branch, base_head_event, query, context, plan, ops）
- `src/neonrp/core/permissions.py` — glob 匹配、deny 优先、路径规范化（拒绝 `..`）
- Ops 校验：upsert_text 必须有 content；delete 不允许有 content；path 必须相对且无 `..`

**Acceptance**
- proposal 缺字段/路径不合法时：exit code=1，输出包含 json path + 建议
- 路径逃逸（`..`）被拒绝
- deny_globs 优先于 write_globs

**Tests**
- 单测：proposal parse/normalize、ops 校验、越权检测（多种 glob 场景）、路径逃逸拒绝

---

## M2-T3 — Diff 预览（Plan + Unified Diff）

**Goal**
- 把 proposal 变成"人类可读、可审计"的预览输出。

**New work**
- `src/neonrp/core/diffing.py` — 逐文件 diff 生成（unified diff 格式），稳定排序（按 path 字典序）
- 支持 upsert_text（新文件 vs 已有文件 diff）和 delete（显示删除标记）

**Acceptance**
- diff 输出稳定（同输入同输出）
- 变更文件列表清晰（新增/修改/删除标记）

**Tests**
- 单测：diff 的稳定性与边界（空文件/新文件/删除文件/无变更文件）

---

## M2-T4 — Apply 引擎（Staging + Permission + Validate Gate + Event Append）

**Goal**
- 实现 Plan→Diff→Validate→Apply→Event 的主闭环。

**Existing code**
- `src/neonrp/core/storage.py` — `atomic_write_json`/`atomic_write_dir`（staging 写入和原子替换）
- `src/neonrp/core/validation.py` — `validate_game_data`（validate gate）
- `src/neonrp/core/event_log.py` — `append_event`（event append）

**New work**
- `src/neonrp/core/apply.py` — staging apply 引擎：
  1. 复制 `game/` 到临时 staging 目录
  2. 在 staging 上执行 ops（权限检查 → apply → validate）
  3. validate 通过后 atomic_write_dir 写回
  4. 追加事件日志（type=agent, actor=agent_id）
  5. 更新 manifest head_event
  6. validate 失败时清理 staging，game/ 不被污染
- `base_head_event` 冲突检测：proposal.base_head_event != current head_event → 拒绝

**Acceptance**
- validate 失败时不污染真实 `game/`
- apply 成功后落盘 `.neonrp/logs/agents/<run_id>/...`
- apply 成功后事件日志包含 type=agent, actor=agent_id 事件
- base_head_event 不匹配时 exit code = 1

**Tests**
- 集成：构造坏 proposal（越权/无效 schema/base_head_event 不匹配）确保不写入
- 集成：好 proposal 能写入并通过 validate，事件日志正确追加
- 单测：staging 生命周期（创建→apply→cleanup）

---

## M2-T5 — Agent run/test/logs + rerun（可重放）

**Goal**
- 让 agent 调用过程可追踪、可回放、可诊断。

**New work**
- `neonrp agent run <id> --query "..." [--proposal <path>] [--apply] [--json]`
  - `--proposal <path>`：直接加载 proposal JSON，跳过 LLM 调用
  - 不带 `--proposal` 时：M2 输出"LLM integration not implemented"提示（真实 LLM 调用留给 M3+）
  - 不带 `--apply` 时：dry-run 模式（显示 plan + diff，不写入）
- `neonrp agent test <id>`：使用 test fixtures 跑确定性验证
- `neonrp agent logs [--tail N] [--json]`：列出 `.neonrp/logs/agents/` 下的 run 记录
- `neonrp agent rerun --last`：读取最近一次 run 的 input.json 和 proposal.json 重新执行
  - 生成新 run_id，记录 `rerun_of: <original_run_id>`

**Acceptance**
- `--proposal` 模式可完成完整的 proposal → diff → validate → apply 流程
- `rerun` 不依赖外部状态（使用日志中的 proposal）
- 输出包含 run_id 与日志路径
- `logs` 命令显示最近的 run 记录

**Tests**
- CLI：`CliRunner` 覆盖 run (--proposal + --apply) / logs / rerun
- E2E：rerun 复现同样的 diff 和 apply 结果

---

## M2-T6 — 与检索对接：context → agent input

**Goal**
- 把 M1 的 `context` 结果作为 agent 输入，完成最小"检索→提案→应用"闭环。

**Existing code**
- `src/neonrp/commands/context.py` — context 命令（--json 输出可被 agent runner 消费）
- `src/neonrp/core/indexing.py` — 实体索引

**New work**
- `neonrp agent run <id> --query "..."` 内部自动调用 context 引擎获取最小上下文
- context 结果写入 `input.json` 的 `context_items`
- read_files 列表记录到 input.json（soft enforce 日志）

**Acceptance**
- 运行时能看到 context 命中与提案预览
- apply 后 `find/context` 能观测到变更
- input.json 包含 context_items 和 read_files

**Tests**
- E2E：subprocess 调 CLI，验证 exit code、日志落盘与最终文件内容
- 集成：init → 创建 world 实体 → index build → agent run (stub + --proposal) → apply → find 能查到新实体

---

## M2-T7 — 阶段 Review Gate

**Goal**
- 跑一次 `opencode run` 审查并落盘到 `reviews/`，按意见修复后保持 `pytest` 全绿。

**Acceptance**
- `reviews/` 下存在阶段审查文件
- 修复后二次 `pytest` 全绿
- `docs/ROADMAP.md` 勾选完成项，`docs/PROGRESS.md` 追加记录

