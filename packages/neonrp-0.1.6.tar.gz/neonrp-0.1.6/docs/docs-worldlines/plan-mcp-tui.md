# WorldLines MCP + TUI 扩展计划

## 核心思路

用户已有 Claude Code 订阅（Opus/Sonnet），WorldLines 不需要自己的 LLM。
把 WorldLines 做成 MCP server 内嵌在 TUI 里，Claude Code 作为 AI 引擎，TUI 负责渲染游戏界面。

```
用户打字
  ↓
Claude Code（独立终端）
  ↓  调用 MCP tools
WorldLines TUI
  ├── 内嵌 MCP server 线程（SSE, localhost）
  ├── tool 被调用 → 更新 reactive 变量
  └── Textual 实时渲染游戏界面
```

对比 Pencil 的架构：Pencil 用 Electron，WorldLines 用 Textual TUI，原理完全相同。

---

## 与现有架构的关系

| | 现有 NeonRP Kernel | MCP + TUI 模式 |
|--|---|---|
| AI 来源 | 用户自己的 API key（openai/anthropic） | Claude Code 订阅（Opus/Sonnet） |
| 游戏控制 | NeonRP ConversationSession | Claude 原生 tool-use |
| 界面 | Textual TUI（独立）| Textual TUI（嵌 MCP server） |
| 需要配置 | API key | Claude Code 已登录即可 |

两种模式可以共存。`worldlines` 命令启动时让用户选择。

---

## Phase A：MCP Server 核心工具

### 工具列表（最小可行集）

```
worldlines_get_state()          → 返回当前游戏完整状态（world + player + location）
worldlines_narrate(text)        → 将 AI 生成的叙述文本推送到 TUI 显示
worldlines_update_entity(id, patch) → 更新 game entity（player HP、location 等）
worldlines_save()               → 保存当前游戏进度
worldlines_load(save_id)        → 加载存档
worldlines_init(world_id)       → 初始化新游戏（从模板）
worldlines_list_worlds()        → 返回可用世界列表
```

### MCP server 实现方式

```python
# NeonRP/src/neonrp/mcp_server.py
# 使用 Python MCP SDK (mcp>=1.0)

from mcp.server import Server
from mcp.server.sse import SseServerTransport
import asyncio

class WorldLinesMCPServer:
    """MCP server 运行在 TUI 内部的独立线程。

    通过 asyncio queue 与 TUI 主线程通信：
    - tool 调用 → put to queue → TUI worker 消费 → 更新 reactive 变量
    """
    def __init__(self, game_root, tui_callback):
        self.game_root = game_root
        self.on_event = tui_callback   # 线程安全回调
        self.server = Server("worldlines")
        self._register_tools()

    def _register_tools(self):
        @self.server.tool()
        def worldlines_narrate(text: str):
            """推送叙述文本到游戏界面。"""
            self.on_event("narrate", text)
            return {"ok": True}

        @self.server.tool()
        def worldlines_get_state():
            """返回当前游戏状态供 Claude 参考。"""
            return _read_game_state(self.game_root)

        @self.server.tool()
        def worldlines_update_entity(entity_id: str, patch: dict):
            """更新 entity 并通知 TUI 刷新。"""
            _apply_entity_patch(self.game_root, entity_id, patch)
            self.on_event("refresh", None)
            return {"ok": True}

        @self.server.tool()
        def worldlines_save():
            """保存游戏进度。"""
            _save_game(self.game_root)
            self.on_event("saved", None)
            return {"ok": True}
```

---

## Phase B：TUI 内嵌 MCP Server

### 架构

```
NeonRPApp (Textual App)
├── compose()
│   ├── GameView          ← 显示叙述文本流
│   ├── StatusPanel       ← 玩家状态、地点、HP
│   └── HintBar           ← "在 Claude Code 里输入指令开始游戏"
├── on_mount()
│   └── 启动 MCP server worker 线程
└── _on_mcp_event(event, data)  ← 线程安全回调
    ├── "narrate" → GameView.append(data)
    ├── "refresh" → StatusPanel.reload()
    └── "saved"   → HintBar.flash("已保存")
```

### TUI 代码骨架

```python
# tui/app.py 新增 MCP 模式分支

class NeonRPApp(App):

    def on_mount(self) -> None:
        if self.mode == "mcp":
            self._start_mcp_server()

    def _start_mcp_server(self) -> None:
        """在后台线程启动 MCP server，监听 localhost:PORT。"""
        from neonrp.mcp_server import WorldLinesMCPServer

        port = self._find_free_port()
        server = WorldLinesMCPServer(
            game_root=self.root,
            tui_callback=self._on_mcp_event,  # 线程安全
        )
        thread = threading.Thread(
            target=server.run_sse, args=(port,), daemon=True
        )
        thread.start()
        self._show_connection_hint(port)

    def _on_mcp_event(self, event: str, data) -> None:
        """MCP server 线程 → TUI 主线程（call_from_thread）。"""
        self.call_from_thread(self._handle_mcp_event, event, data)

    def _handle_mcp_event(self, event: str, data) -> None:
        match event:
            case "narrate":
                self.query_one(GameView).append_text(data)
            case "refresh":
                self.query_one(StatusPanel).reload()
            case "saved":
                self.notify("游戏已保存")
```

---

## Phase C：Claude Code 侧的配置

用户在 Claude Code 的 `.mcp.json`（或全局配置）里添加：

```json
{
  "mcpServers": {
    "worldlines": {
      "type": "sse",
      "url": "http://localhost:7842/sse"
    }
  }
}
```

或通过命令自动注册：
```bash
worldlines --register-mcp   # 自动写入 ~/.claude/claude_desktop_config.json
```

### Claude Code 侧的 system prompt（可选）

WorldLines TUI 启动时在 MCP server 的 `instructions` 字段注入游戏背景，
让 Claude 开箱即用地理解当前世界状态和叙述风格。

---

## Phase D：双模式启动

```bash
worldlines            # 标准模式（现有 NeonRP kernel，需要 API key）
worldlines --mcp      # MCP 模式（等待 Claude Code 连接，不需要 API key）
```

`--mcp` 模式：
1. 初始化游戏目录（如已有存档则加载）
2. 启动 TUI（MCP 模式界面）
3. 显示连接地址：`MCP server 已就绪：localhost:7842`
4. 用户在 Claude Code 里 `/add-mcp worldlines sse localhost:7842`
5. 对话开始，TUI 实时渲染

---

## 文件清单

| 文件 | 操作 |
|------|------|
| `src/neonrp/mcp_server.py` | 新建 — WorldLinesMCPServer |
| `src/neonrp/tui/app.py` | 修改 — 新增 mcp 模式分支 |
| `src/neonrp/tui/widgets/game_view.py` | 新建 — 叙述文本渲染组件 |
| `src/neonrp/tui/widgets/status_panel.py` | 新建 — 玩家状态面板 |
| `src/neonrp/cli.py` | 修改 — 添加 `--mcp` flag |
| `pyproject.toml` | 修改 — 添加 `mcp` 依赖 |

依赖：`mcp>=1.0`（Anthropic 官方 Python MCP SDK）

---

## 实施顺序

```
1. mcp_server.py — 核心工具定义（不依赖 TUI）
2. 单独测试：用 curl/mcp inspector 验证 tools 可被调用
3. TUI mcp 模式 — 内嵌 server + reactive 更新
4. CLI --mcp flag
5. worldlines --register-mcp 自动配置 Claude Code
6. 端到端测试：Claude Code + worldlines --mcp + 一局石津镇
```

---

## 与 Phase 1-3 的关系

Phase 1-3（已完成）是 WorldLines 的独立 LLM 模式，对没有 Claude Code 的用户仍然有效。
本计划是额外的"Claude Code 增强模式"，两者并存，用户根据自身情况选择。
