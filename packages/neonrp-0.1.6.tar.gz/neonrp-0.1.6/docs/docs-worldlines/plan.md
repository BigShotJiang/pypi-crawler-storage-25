# WorldLines = NeonRP：基本游玩流程 Plan

## Context

NeonRP 就是 rp-core，就是 WorldLines。不再创建 wrapper 包，直接深度修改 NeonRP。rp-core 目录可以删除。

**目标：** 安装 → 选世界 → 开始玩 → 存档 → 下次继续

**三个关键决策：**
1. 直接修改 NeonRP，不创建新包
2. 世界模板用英文 JSON，游玩时 narrator prompt 自动适配语言
3. MVP 需要 3 个可测试模板：石津镇（已有）、异世界转生、常暗之箱

---

## Phase 1: Agent-First 入口 + 世界选择（最高优先）

### 1.1 修改 CLI 入口：`neonrp` → `worldlines`

**修改文件：** `NeonRP/pyproject.toml`
- 添加 `worldlines` 作为新的 console script entry point（保留 `neonrp` 兼容）

**修改文件：** `NeonRP/src/neonrp/cli.py`
- 当 `worldlines` 命令无参数调用时：
  1. 检查 `~/.worldlines/games/` 是否有已有存档
  2. 如果有 → 显示"继续游戏"或"新游戏"选择
  3. 如果没有 → 直接进入世界选择

```
$ worldlines

🌍 WorldLines

  [继续] 石津镇 - 存档 3月7日
  [新游戏]

> 新游戏

  1. Stone Ford Town (石津镇) — Classic fantasy RPG
  2. Isekai Reincarnation (异世界转生) — Re:Zero inspired
  3. Dark Train (常暗之箱) — 7-carriage mystery

> 1

⚙️ Model:
  1. GLM (推荐/免费)
  2. Claude Opus

> 1

Initializing...
[进入 TUI]
```

### 1.2 世界注册和游戏目录管理

**新建文件：** `NeonRP/src/neonrp/worlds.py`

```python
WORLDS = {
    "stone-ford": {"name": "Stone Ford Town (石津镇)", "template": "default", "desc": "Classic fantasy RPG"},
    "isekai": {"name": "Isekai Reincarnation (異世界転生)", "template": "isekai", "desc": "Re:Zero inspired"},
    "dark-train": {"name": "Dark Train (常暗之箱)", "template": "dark-train", "desc": "7-carriage mystery"},
}

GAME_HOME = Path.home() / ".worldlines" / "games"
```

- 每个游戏存档存在 `~/.worldlines/games/<world-id>-<timestamp>/`
- 该目录就是一个标准 NeonRP 项目（`.neonrp/`, `game/`, `agents/`）

### 1.3 模型预设配置

**新建文件：** `NeonRP/src/neonrp/presets.py`

Phase 1 只有两个（NeonRP kernel）：
| 预设 | provider | model | 说明 |
|------|----------|-------|------|
| glm | openai | glm-4-flash | VPN 连接的 GLM，免费 |
| opus | anthropic | claude-opus-4-6 | Anthropic API Key |

生成的 `.neonrp/config.json` 直接兼容现有 NeonRP config 系统（`config.py` 的 `models` registry + `model_ref`），零修改。

### 1.4 初始化流程

WorldLines 选择世界后自动执行（用户无感）：
1. `mkdir ~/.worldlines/games/stone-ford-20260308/`
2. `cd` 到该目录
3. 调用 NeonRP `init` 逻辑（创建 `.neonrp/`）
4. 调用 `game new --template <template>` 逻辑（铺设 game entities + agents）
5. 写入 `.neonrp/config.json`（根据选择的模型预设）
6. 启动 `run_tui(root=...)`

**关键：** 这些步骤全部调用 NeonRP 现有内部函数，不需要 subprocess。

### Phase 1 关键修改文件清单

| 文件 | 操作 |
|------|------|
| `NeonRP/pyproject.toml` | 修改 — 添加 `worldlines` entry point |
| `NeonRP/src/neonrp/cli.py` | 修改 — 添加世界选择 + 模型选择流程 |
| `NeonRP/src/neonrp/worlds.py` | 新建 — 世界注册表 + 游戏目录管理 |
| `NeonRP/src/neonrp/presets.py` | 新建 — 模型预设配置 |

---

## Phase 2: 创建 2 个新世界模板

### 模板位置

放在 NeonRP 的标准 templates 目录：
```
NeonRP/src/neonrp/templates/
  default/        # 石津镇（已有）
  isekai/         # 异世界转生（新建）
  dark-train/     # 常暗之箱（新建）
```

### 模板语言策略

JSON entity 用英文（id、kind、name、description 全英文）。narrator 的 `system.md` 里加语言适配指令：

```markdown
## Language Adaptation
Detect the player's language from their first message.
Respond in the same language throughout the session.
Entity names should be transliterated naturally (e.g., "Elder Sage" → "贤者长老" in Chinese).
```

### World 2: Isekai Reincarnation (異世界転生)

```
templates/isekai/
  game/
    meta/game-start.json        # 开场：卡车撞击→异世界醒来
    meta/active-agent.json      # 路由状态初始化
    meta/quest-first-mission.json
    player/player.json           # HP 100, 特殊能力：时间回溯 (Gift of Return)
    town/starter-village.json    # kind=town, 起始村庄
    town/guild-hall.json         # kind=town, 冒险者公会
    dungeon/first-dungeon.json   # kind=dungeon, 史莱姆洞穴
    npc/guild-master.json
    npc/merchant.json
    npc/companion.json
    item/starter-sword.json
    item/health-potion.json
  agents/
    narrator/
      agent.json
      system.md                  # Isekai 专属 prompt（轻小说风叙事 + Language Adaptation）
    town-agent/
      agent.json                 # 村庄/公会交互
    dungeon-agent/
      agent.json                 # 战斗/地下城
  .neonrp/
    runtime_contract.json        # routing: town→town-agent, dungeon→dungeon-agent
```

game-start.json 的 `opening_scene`:
```
"You wake up on grass. The sky is impossibly blue. The last thing you remember is headlights.
A floating translucent window appears before your eyes: [Welcome, Traveler. You have been granted the Gift of Return.]"
```

### World 3: Dark Train (常暗之箱)

```
templates/dark-train/
  game/
    meta/game-start.json        # 开场：在第6节车厢醒来
    meta/active-agent.json
    meta/quest-reach-carriage-1.json
    player/player.json           # 没有战斗属性，以调查/推理为主
    location/carriage-6.json     # 起始车厢 (The Sleeper)
    location/carriage-5.json     # The Dining Car
    location/carriage-4.json     # The Library
    location/carriage-3.json     # The Observation Deck
    location/carriage-2.json     # The Conductor's Office
    location/carriage-1.json     # The Engine (终点)
    location/connector-passage.json  # 车厢间连接通道
    npc/mysterious-conductor.json
    npc/nervous-woman.json
    npc/sleeping-old-man.json
    npc/child-with-bear.json
    item/torn-ticket.json
    item/key-fragment.json
  agents/
    narrator/
      agent.json
      system.md                  # 悬疑推理风格 prompt + Language Adaptation
    puzzle-agent/
      agent.json                 # 每节车厢的谜题判定 + NPC对话 + 物品发现
  .neonrp/
    runtime_contract.json        # routing: location→puzzle-agent
```

game-start.json 的 `opening_scene`:
```
"The rhythmic clatter of wheels on tracks. You open your eyes to dim emergency lighting.
You're sitting in a worn leather seat. Carriage 6 — the number is stenciled on the wall.
You don't remember boarding this train. You don't remember your name."
```

**特殊机制：** 每节车厢有一个 `puzzle` 字段定义锁定条件，puzzle-agent 负责判定是否可以前进到下一节车厢。

### Phase 2 关键修改文件清单

| 文件 | 操作 |
|------|------|
| `NeonRP/src/neonrp/templates/isekai/` | 新建整个目录 (17 files) |
| `NeonRP/src/neonrp/templates/dark-train/` | 新建整个目录 (21 files) |

---

## Phase 3: Agent-First 控制器

### 3.1 目标架构

```
用户输入
  ↓
WorldLines Agent Controller (新)
  ├── /model <preset>  → 直接切换 config，不需要 LLM
  ├── /save, /load     → 直接调用 NeonRP save/load
  ├── /worlds          → 显示世界列表
  ├── /new             → 新建游戏
  ├── 普通文字         → 转发给 NeonRP ConversationSession
  └── 格式错误命令     → 自动纠正后执行
```

### 3.2 修改 TUI 层

**修改文件：** `NeonRP/src/neonrp/tui/app.py`

在现有 TUI 的 `handle_user_input()` 之前加一层 WorldLines 拦截：
- 新增 slash commands: `/model`, `/worlds`, `/new`
- `/model` 切换后重新加载 config（不需要重启 TUI）

### 3.3 Dual-Kernel 设计（为 Phase 4 Claude 做准备）

**新建文件：** `NeonRP/src/neonrp/kernel.py`

```python
class GameKernel(Protocol):
    def send_turn(self, root, text, callbacks) -> TurnResult

class NeonRPKernel(GameKernel):
    # 调用现有 ConversationSession

class ClaudeKernel(GameKernel):  # Phase 4
    # 调用 Claude API + 自定义 tool-calling
```

TUI 持有一个 `kernel` 实例，`/model` 可以切换。

---

## Phase 4: Claude Code Kernel + 额外世界（延后）

- Claude kernel 实现
- 解锁 `claude-glm` 和 `claude-opus` 预设
- 创建剩余 2 个世界（东京大学、神乐岛）
- Claude Code skill 发布

---

## Phase 5: 发布和监控（延后）

- `pip install worldlines` 发布
- `curl` 一键安装脚本
- VPN GLM 模型对接（初期硬编码 base_url）
- 简单 analytics endpoint

---

## 实施顺序（精确）

```
1. NeonRP/pyproject.toml — 添加 worldlines entry point           ✅ 完成
2. NeonRP/src/neonrp/worlds.py — 世界注册 + 游戏目录              ✅ 完成
3. NeonRP/src/neonrp/presets.py — 模型预设                        ✅ 完成
4. NeonRP/src/neonrp/cli.py — 世界选择 + 模型选择 + 初始化 + TUI  ✅ 完成
5. 测试：worldlines → 选石津镇 → 选 GLM → 进入游戏               ✅ 验证通过
6. NeonRP/src/neonrp/templates/isekai/ — 异世界转生模板            ✅ 完成 (17 files)
7. NeonRP/src/neonrp/templates/dark-train/ — 常暗之箱模板          ✅ 完成 (21 files)
8. 测试：3 个世界都能正常初始化                                    ✅ 验证通过
9. NeonRP/src/neonrp/tui/commands.py — 添加 /worlds, /wl-model     ✅ 完成
10. NeonRP/src/neonrp/tui/app.py — WorldLines TUI 命令处理          ✅ 完成
11. NeonRP/src/neonrp/kernel.py — Dual-Kernel 协议                  ✅ 完成
12. 测试：所有模块导入 + 集成验证                                    ✅ 验证通过
```

**步骤 1-5 完成后就可以让人试玩。**
**Phase 1-3 全部完成，Phase 4-5 延后。**

---

## 验证方式

```bash
cd /Users/yuhanghuang/Workspaces/10.coc-proj/Ludic-Dynamics/NeonRP
uv pip install -e .
worldlines                    # 显示世界选择
# 选石津镇 + GLM
# 自动初始化 ~/.worldlines/games/stone-ford-xxx/
# 进入 NeonRP TUI
# 输入 "开始冒险" → 看到开场叙事
# /save → 存档成功
# 退出
worldlines                    # 显示 [继续] 石津镇 存档
# 选继续 → 恢复上次
```

---

## 实现细节记录

### 验证中发现并修复的问题

1. **entity path ↔ kind 必须匹配**：NeonRP 的 schema 验证要求 `game/<kind>/<id>.json` 中的目录名必须与 entity 的 `kind` 字段一致。
   - isekai: `starter-village` 和 `guild-hall` 的 kind 设为 `town`，放在 `town/` 目录下
   - isekai: `first-dungeon` 的 kind 设为 `dungeon`，放在 `dungeon/` 目录下
   - dark-train: 所有车厢 kind 为 `location`，放在 `location/` 目录下

2. **inventory 字段格式**：NPC entity 的 `inventory` 字段必须是 object 数组，不能是字符串数组。修复了 `merchant.json` 和 `child-with-bear.json`。

3. **初始化流程调用链**：`worldlines_cli()` → `_worldlines_init_and_launch()` 内部按顺序调用：
   - `create_game_dir()` → `ensure_dirs()` → `Manifest()` + `atomic_write_json()`
   - `build_config_dict()` → `atomic_write_json(config)`
   - `_load_game_template()` → `apply_system_proposal()`
   - `_copy_agent_from_template()` × N agents
   - `_copy_runtime_contract_from_template()`
   - `create_rule_samples()` + `create_skill_samples()`
   - `run_tui(root=game_dir)`

### Phase 3 实现记录

4. **TUI 新增命令**：
   - `/worlds` — 列出可用世界（id, name, name_local, desc）
   - `/wl-model` — 无参数列出预设；带参数切换预设并热重载 config
   - 两个命令都注册到 `LOCAL_SLASH_COMMANDS` 和 `COMMANDS` dict

5. **Dual-Kernel 设计** (`kernel.py`):
   - `GameKernel` — Protocol，定义 `send_turn()`, `cancel()`, `clear()` 接口
   - `NeonRPKernel` — 适配器，包装 `ConversationSession.send()` → `TurnResult`
   - `ClaudeKernel` — Phase 4 占位，返回 "not yet implemented"
   - `TurnResult` — 统一返回结构，与 `ConversationTurnResult` 字段对齐

6. **`/wl-model` 热切换流程**：
   - `build_config_dict(preset_id)` → `atomic_write_json(config_path)` 覆写项目 config
   - `self._init_session()` 重新初始化 ConversationSession（读取新 config）
   - 更新 StatusBar model 显示
