# M12 Task Cards — Multi-Agent Delegation Reliability + Template Expansion

---

## M12-T0: Specs Freeze + Scope Lock (doc-first)

**Goal**: 冻结 M12 范围，避免“先改代码后改规则”导致反复返工。

**Input baseline**:
- `docs/ISSUE_SUB_AGENT_AUTO_EXIT.md`
- `my-rpg/.neonrp/sessions/main.jsonl`
- `my-rpg/agents/*`
- `src/neonrp/core/conversation.py`
- `src/neonrp/core/agent_runner.py`
- `src/neonrp/commands/game.py`

**Deliverables**:
- `docs/M12_TASK_CARDS.md`（本文档）
- `docs/ROADMAP.md` 增加 M12 段落与 checkbox（计划项）
- ADR（建议新增）:
  - `docs/ADRs/0026-sub-agent-delegation-contract.md`
  - `docs/ADRs/0027-game-new-default-template-multi-agent.md`

**Decisions locked**:
1. M12 目标是提升 one-shot `task` 设计下的委托稳定性，不在 M12 引入 persistent sub-agent runtime。
2. M12 必做 `active-agent` 状态协议（文件级状态 + 提示词协议 + 运行时兜底）。
3. `my-rpg` 作为 `/game new` 默认模板升级的来源样本，但上线前必须先完成代理重审重写。
4. `game-start.json` = bootstrap contract；`active-agent.json` = live routing contract。二者职责必须分离，不能混用。
5. Router execution mode 分层：`fast` 保留当前“specialist 直接前台输出”语义；`orchestrator` 采用“narrator/orchestrator 永远前台输出，specialist 只做后台 owner/处理”的新语义；未来可扩展 `multi-agent`。

**Acceptance**:
- 范围、依赖顺序、非目标明确。
- ISSUE 文档中 A/B 方案在 M12 有具体任务映射。

---

## M12-T1: Repro Harness + Baseline Metrics

**Goal**: 把“子代理自动退出后 narrator 接管”变成可回归、可量化的问题。

**Changes**:
- 新增可复现脚本/fixture（建议放在 `tests/fixtures/m12/`）
- 固化典型流程：进入城镇 → 连续购物/对话 → 离开城镇
- 新增委托链路观测字段（run_id、agent_id、route_decision、active_agent）

**Tests**:
- `tests/test_conversation_subagent_routing.py`（新增）
  - one-shot 返回后仍在城镇时，下一轮必须继续委托
  - 离开城镇后控制权回 narrator

**Acceptance**:
- 本地可稳定复现旧问题并验证修复。
- 输出可比较的前后指标（委托率、误接管次数）。

---

## M12-T2: Narrator Prompt Contract v2 (Mandatory Delegation)

**Goal**: 先用最小改动把 narrator 的“必须委托”规则写成强约束，而不是建议。

**Changes**:
- 更新 `my-rpg/agents/narrator/system.md`
  - 新增 `Mandatory Delegation Rules`
  - 明确 narrator 禁止直接执行 town/dungeon 业务写操作
  - 明确 task 返回后若仍在相同 location type，下一轮必须再次 task
- 同步更新模板 narrator 文案来源（`src/neonrp/commands/game.py` 的 `create_narrator_agent` 内容）

**Tests**:
- `tests/test_game_cli.py`: 断言 `game new` 生成的 narrator system 包含关键 delegation 规则
- `tests/test_conversation_edges.py`: 增加提示词契约相关回归断言

**Acceptance**:
- narrator 提示词包含强制路由、禁止越权、连续委托规则。
- `game new` 产出的 narrator 与 `my-rpg` 的契约一致。

---

## M12-T3: my-rpg Agent Audit + Rewrite (职责与边界重建)

**Goal**: 对 `my-rpg` 全部代理进行职责重审，重写角色定义、边界和交接协议。

**Scope**:
- `my-rpg/agents/narrator/agent.json`
- `my-rpg/agents/narrator/system.md`
- `my-rpg/agents/town-agent/agent.json`
- `my-rpg/agents/dungeon-agent/agent.json`
- `my-rpg/agents/agent-orchestrator/agent.json`
- `my-rpg/agents/README.md`
- `my-rpg/agents/registry.json`

**Rewrite requirements**:
1. 每个代理有明确 `owns / must_not_do / handoff_when / handoff_to`。
2. narrator 只做路由、过场叙事、跨域协调，不做 town/dungeon 细节执行。
3. town-agent 与 dungeon-agent 各自定义输入输出契约（状态读写范围、工具白名单、退出条件）。
4. 明确是否保留 `agent-orchestrator`（若保留，限定为 registry/health，不和 narrator 职责重叠）。

**Tests**:
- `tests/test_agents_contract.py`（新增）
  - 校验关键代理字段存在（职责/边界/交接）
  - 校验 narrator 不拥有 town/dungeon 直接执行语义

**Acceptance**:
- `my-rpg` 代理定义可读、可审计、无职责冲突。
- 新对话日志中 narrator 的越权操作显著下降。

---

## M12-T4: Active-Agent State Protocol (方案 B 核心)

**Goal**: 引入持久状态，减少 narrator 每轮“从零判断”导致的路由漂移。

**Changes**:
- 新增状态文件：`game/meta/active-agent.json`
- 新增状态工具函数（建议）:
  - `src/neonrp/core/active_agent.py`（读/写/清理/校验）
- 在 `conversation.py` 引入 protocol hooks：
  - 回合开始读取 active-agent
  - 若 active_agent 非 narrator，则优先委托对应子代理
  - 满足 exit_condition 时清理 active-agent

**Schema (v1)**:
```json
{
  "active_agent": "town-agent",
  "reason": "player is in town",
  "exit_condition": "player leaves town",
  "updated_at": "2026-02-17T00:00:00Z",
  "updated_by": "narrator"
}
```

**Tests**:
- `tests/test_active_agent.py`（新增）
  - state file parse/validation
  - narrator routing with active_agent lock
  - exit_condition met -> clear lock

**Acceptance**:
- 城镇连续多轮对话期间，路由稳定落在 town-agent。
- 离开城镇后可恢复 narrator。

---

## M12-T5: Runtime Guardrails in Conversation Loop

**Goal**: 在提示词之外加运行时兜底，降低“模型临时忘记规则”风险。

**Changes**:
- `src/neonrp/core/conversation.py`
  - 为 task 调用结果增加路由一致性检查（基于 active-agent + location）
  - narrator 直接调用高风险工具处理 town/dungeon 时，优先触发“应委托”错误提示并引导重试委托
- `src/neonrp/core/agent_runner.py`
  - `task` schema 描述加入“one-shot + 需要持续重委托”的明确文案

**Tests**:
- `tests/test_conversation_edges.py`
  - narrator 误执行 town 操作时触发 guardrail
  - guardrail 不影响正常纯叙事输出

**Acceptance**:
- 即使提示词漂移，核心路由仍具备兜底。
- 不引入死循环或明显误判。

---

## M12-T5b: Router Execution Modes (`fast` / `orchestrator` / `multi-agent` placeholder)

**Goal**: 把当前 sticky/active-agent 的前台输出语义，与新的 orchestrator-only 前台输出语义明确区分，避免后续 agent/sub-agent 逻辑互相污染。

**Spec source of truth**:
- `docs/ADRs/0026-sub-agent-delegation-contract.md`

**Why this is needed**:
- 现有 `active-agent` 设计更偏向 **fast mode**：specialist 在 sticky 锁定期间可直接成为前台输出者。
- 新规则要求一个独立模式：**orchestrator mode** 中 narrator/orchestrator 永远是前台 speaker，specialist 只负责后台 owner/执行。
- 未来还可能扩展 **multi-agent mode**，因此需要先把模式层抽象建立起来。

**Mode definitions**:

### `fast`
- 保留当前语义
- `active-agent` 既可能表示后台 owner，也可能成为前台输出者
- sticky specialist 可直接响应玩家
- 同一回合允许 specialist handoff 后继续滚动到下一个 specialist

### `orchestrator`
- `speaker` 永远是 narrator / orchestrator
- `active-agent` 字段保留，但不作为 orchestrator 模式的主语义核心
- `delegated-to` = 本回合 narrator 实际调用的 specialist
- specialist 返回结构化结果 / 摘要 / 状态变化
- narrator / orchestrator 负责最终玩家可见叙事
- orchestrator 保留**单个顶层 loop**，但禁止 self-recursive re-entry
- 不再做同回合 specialist → specialist 的滚动链
- 允许 bounded specialist recursion：总 agent 调用层数最多 3 层

### `multi-agent`
- 先作为占位模式保留
- 供未来更复杂的并行/多角色协作编排使用

**Changes**:
- `runtime_contract.router.execution_mode` 新增模式字段
- 旧项目默认 `fast`，保持兼容
- 新模板默认 `orchestrator`
- `ConversationTurnResult` 增加观测字段：
  - `route_decision`
  - `active_agent`
  - `delegated_to`
- fallback orchestrator 使用内建 prompt，不要求项目必须先定义 `narrator` / `orchestrator` 文件

**Tests**:
- `tests/test_conversation_subagent_routing.py`
  - `fast`：active-agent 锁定时 specialist 仍可作为前台 speaker
  - `orchestrator`：前台 speaker 永远是 narrator/orchestrator
  - `fast`：允许 same-turn specialist rolling
  - `orchestrator`：禁止 same-turn specialist rolling
- `tests/test_runtime_contract.py`
  - execution_mode 默认值与覆盖值
- `tests/test_game_cli.py`
  - 新模板默认 `execution_mode = orchestrator`

**Acceptance**:
- `fast` 与 `orchestrator` 的行为边界清晰且可回归
- 旧项目继续按 `fast` 语义工作
- 新模板默认进入 `orchestrator` 模式
- 为未来 `multi-agent` 模式预留扩展点

---

## M12-T6: Expand `/game new` Default Template from my-rpg (新增必做项)

**Goal**: 在代理和提示词修复完成后，基于 `my-rpg` 扩充默认模板，使新项目开箱即用多代理 RPG。

**Changes**:
- `src/neonrp/commands/game.py` `_TEMPLATES["default"]` 扩充：
  - 更完整的开局实体（player/town/npc/路径/基础物品）
  - `game/meta/active-agent.json` 初始值（如 `narrator`）
- `create_narrator_agent()` 升级为多代理模板生成器（或新增 helper）：
  - 同时生成 narrator / town-agent / dungeon-agent（必要时含 orchestrator）
  - 输出统一的职责边界和路由协议
- 为新模板增加说明文档（建议 `docs/TUTORIAL.md` 或 `docs/CLI_REFERENCE.md`）

**Compatibility**:
- 保持 `neonrp game new --template default` 命令不变
- 若新增模板变体（可选），需保持旧脚本兼容并提供迁移提示

**Tests**:
- `tests/test_game_cli.py`
  - 断言默认模板生成多代理文件与关键 meta 文件
  - 断言模板可 `validate` + `index build`
  - `--force` 覆盖 + undo 回滚回归

**Acceptance**:
- 新建项目后可直接体验“narrator 路由 + town/dungeon 子代理”流程。
- 模板数据和代理定义与 `my-rpg` 审核后版本一致。

---

## M12-T7: Migration + Backward Compatibility

**Goal**: 不破坏已有项目和历史会话。

**Changes**:
- 读取 `active-agent.json` 时允许缺失并自动回退（老项目兼容）
- 对老 agent 配置缺字段做软兼容（日志警告而非崩溃）
- 提供一次性迁移命令或文档步骤（可选，见 `docs/M12_MIGRATION.md`）

**Tests**:
- `tests/test_conversation_edges.py`
  - 无 active-agent 文件时仍可运行
  - 旧 agent.json 结构仍可启动会话

**Acceptance**:
- 旧项目不需要手工改动也能继续运行。
- 新能力按“可选增强”方式生效。

---

## M12-T8: Evaluation + Scenario E2E

**Goal**: 以真实多回合剧本验证 M12 的路由稳定性和模板可玩性。

**Scenarios**:
1. 连续城镇交互（买药水→买武器→问任务→离开）
2. 城镇→野外/地牢切换
3. 子代理失败/取消后的恢复路径
4. `/continue` 恢复后 active-agent 一致性

**Tests**:
- `tests/test_conversation.py` / `tests/test_app_v2.py` 增加端到端路径
- 可选：`tests/e2e/` 增加长会话脚本

**Metrics**:
- Delegation correctness rate（目标 >= 95%）
- Wrong-owner operation count（目标趋近 0）
- Session resume consistency（目标 100%）

**Acceptance**:
- 关键场景通过且指标达标。

---

## M12-T9: Review Gate + Release Notes

**Checklist**:
1. `ruff format` + `ruff check`
2. `pytest` 全量回归
3. `opencode run` 评审并归档 `reviews/M12_review_<date>.md`
4. 更新文档：
   - `docs/ROADMAP.md`
   - `docs/PROGRESS.md`
   - `docs/TUTORIAL.md`
   - `docs/CLI_REFERENCE.md`
   - `CHANGELOG.md`

**Acceptance**:
- M12 交付可回归、可文档化、可迁移。

---

## Dependency Order

```text
M12-T0 (spec freeze)
  └── M12-T1 (repro baseline)
       ├── M12-T2 (narrator prompt contract v2)
       ├── M12-T3 (my-rpg agent audit + rewrite)
       └── M12-T4 (active-agent protocol)
            └── M12-T5 (runtime guardrails)
                 └── M12-T5b (router execution modes)
                      └── M12-T6 (expand game new default template)
                           └── M12-T7 (backward compatibility)
                                └── M12-T8 (scenario e2e + metrics)
                                     └── M12-T9 (review gate)
```

---

## Out of Scope (M12)

- `task` 工具 persistent 模式（`persistent=true`）与 `exit_task()` 机制（推迟到 M13，复杂内容整合落在 M15）
- 并行多子代理调度
- 复杂世界模板市场/外部模板仓库

---

## Milestone Acceptance (M12)

1. `my-rpg` 多代理职责边界完成重审重写，narrator 不再越权执行 town/dungeon 业务。
2. 引入 `active-agent` 协议后，城镇/地牢连续交互路由稳定。
3. `fast` / `orchestrator` 执行模式边界明确，新模板默认 `orchestrator`，旧项目保持 `fast` 兼容。
4. `/game new` 默认模板完成基于 `my-rpg` 的扩充，开箱即用多代理 RPG。
5. 兼容旧项目（无 active-agent 文件、旧 agent 定义）且无破坏性回归。
6. 场景 E2E 与质量门通过，文档同步完成。
