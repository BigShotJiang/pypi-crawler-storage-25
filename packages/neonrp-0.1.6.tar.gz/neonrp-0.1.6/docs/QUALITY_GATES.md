# Quality Gates (Definition of Done)

NeonRP is built to be stable and auditable. To keep it that way, every milestone/task must pass these gates.

## Gate order (mandatory)
1. **Format**: `ruff format .`
2. **Lint**: `ruff check .`
3. **Tests**: `pytest` (see test strategy below)
4. **Code review**: `opencode run "Using guidelines in prompts/code_review.md, review changes..."`
5. **Apply fixes**: implement review feedback (or document why not)
6. **Tests again**: `pytest` (must be green after fixes)
7. **Log review findings**: record ALL review findings in `docs/PROGRESS.md` (see Review findings tracking below)
8. **Docs update (per-milestone)**:
   - Mark tasks done in `docs/ROADMAP.md`
   - Add entry to `docs/PROGRESS.md`
   - **文档完整性扫描**：逐项确认每项已完成任务都有 PROGRESS 条目，所有 ROADMAP checkbox 一致
9. **Session handoff note**: 输出本次会话的交接说明（见下方会话交接协议）

## Per-task documentation checklist (每项任务完成时)

除了上述里程碑级质量门，每项任务完成后 agent 必须**立即**执行以下文档更新（不要等到 review gate）：

1. `docs/PROGRESS.md`: 添加本任务条目（Date / Milestone/Task / Summary / Evidence / Notes / Next）
2. `docs/ROADMAP.md`: 勾选对应 task checkbox
3. 若任务计划创建 ADR/设计文档：确认已创建，或在 PROGRESS 条目中显式记录跳过原因

> **为什么不能批量更新？**
> M6 开发中 agent 在一个会话中完成了 8 项任务但未逐项更新 PROGRESS，导致第二个会话接手时无法感知遗漏。增量更新确保每个会话边界处文档状态完整。

## Session handoff protocol (会话交接协议)

当一个 coding session 即将结束（context 接近上限、用户切换会话、任务告一段落），agent 必须输出 **Handoff Note**：

```
## Session Handoff Note
- Completed tasks: [list]
- PROGRESS entries written: [list, or "all" / "none"]
- ROADMAP checkboxes updated: [yes/no, which ones]
- Pending tasks: [list with blockers]
- Known documentation gaps: [list]
- Next recommended action: [description]
```

新会话开始时，agent 应：
1. 阅读 `docs/PROGRESS.md` 最近条目
2. 阅读 `docs/ROADMAP.md` 当前里程碑 checkbox 状态
3. 比对：哪些任务已完成但没有 PROGRESS 条目？哪些 checkbox 未勾选？
4. 若发现遗漏，优先补齐后再继续开发

## Test strategy (three layers)

| Layer | Scope | Tool | What to cover |
|-------|-------|------|---------------|
| **Unit** | Storage layer core functions | pytest | save/load state transitions, event append/read, manifest read/write, atomic write correctness |
| **Integration** | CLI command chains | pytest + click.testing.CliRunner | init → run → save → load → undo → branch end-to-end flow |
| **E2E** | Actual CLI binary | pytest + subprocess | invoke `neonrp` commands as a subprocess, verify exit codes, stdout, and file system side effects |

Each task must include tests covering:
- The happy path
- Failure modes (missing files, corrupt saves, invalid input)
- Idempotency where specified (e.g. `init` must be idempotent)

## Code review: separation of duties

The coding agent (the one writing code) MUST NOT perform its own code review. The review MUST be performed by a separate tool (`opencode run`) invoked as an external subprocess.

Rules:
- The coding agent MUST invoke `opencode run` via shell command and capture its actual stdout/stderr output.
- The coding agent MUST NOT write a review itself and attribute it to `opencode run`.
- The coding agent MUST NOT paraphrase, summarize, or rewrite `opencode run` output. Save the raw output directly.
- If `opencode run` is unavailable, the coding agent MUST report this to the human operator and stop. It MUST NOT substitute its own review.

## Code review failure policy

- If `opencode run` **encounters an unrecoverable error** (opencode itself crashes, fails to start, connection errors, etc.): **stop development immediately**. Do not proceed to the next task. Resolve the tooling issue first.
- If `opencode run` completes but **produces review findings**: address findings per normal gate flow (apply fixes or document non-adoption).

## Review artifacts
- Save review output under `reviews/` using one of these formats:
  - `reviews/<milestone>-<task>_opencode_review_YYYYMMDD.md`
  - `reviews/<git_sha>_opencode.md`

## What reviewers should focus on
- Safety of file operations (no silent destructive writes)
- Correctness of save/load/undo/branch invariants
- Append-only event log guarantees
- Write atomicity (write-to-temp-then-rename pattern)
- Crash recovery behavior
- Testability and determinism (seeded RNG routing)
- Clear errors and actionable messages
- Extensibility hooks (agents/skills/indexing)
- **Agent Sandbox:** Permission boundaries are strictly enforced (deny-first)
- **Proposal Safety:** Staging and validation before commit for all agent actions

## Review findings tracking

Every code review produces findings. ALL findings must be recorded in `docs/PROGRESS.md` under the review gate entry, regardless of disposition. This ensures nothing is silently dropped.

For each finding, record:
- **Description**: what the finding is
- **Disposition**: one of:
  - `fixed` — fixed in this milestone
  - `deferred:<milestone>` — intentionally deferred to a specific milestone (must create a Pre-M housekeeping task in ROADMAP)
  - `accepted` — accepted as-is with rationale
  - `wontfix` — not worth fixing with rationale
- **Reference**: `file:line` or review artifact section

Template (append to the review gate entry in PROGRESS.md):
```
- Review findings:
  - [fixed] <description> (file:line)
  - [deferred:M4] <description> (file:line) — rationale
  - [accepted] <description> — rationale
  - [wontfix] <description> — rationale
```

When a finding is `deferred:<milestone>`, a corresponding housekeeping task MUST exist in `docs/ROADMAP.md` under that milestone's Pre-M section.
