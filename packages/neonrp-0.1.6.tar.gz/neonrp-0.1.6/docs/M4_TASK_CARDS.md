# M4 Task Cards (Sandbox + Replay)

这些 task cards 面向"让 Codex/自动化代理按卡片逐个推进"。每张卡片尽量控制在一次小 PR 的规模内。

质量门（每张卡片收尾必跑）：见 `docs/QUALITY_GATES.md`。

## Task dependency graph
```
H7/H8/H9 (Pre-M4 housekeeping)
  └→ M4-T0 (docs/ADRs)
       └→ M4-T1 (save meta + world hash utility)
            ├→ M4-T2 (sandbox commands) ──→ M4-T4 (replay checkout / sandbox from event)
            └→ M4-T3 (replay verify)    ──┘
                                              └→ M4-T5 (event schema hardening: import/game → system proposal)
                                                    └→ M4-T6 (review gate)
```
注：M4-T4 依赖 M4-T2（sandbox 基础设施）和 M4-T3（replay 核心逻辑）。

## Output format convention
延续 M1/M2/M3 约定：所有 M4 CLI 命令支持 `--json` 输出标志（sandbox/replay）。

---

## H7 — `save.py` load 命令原子替换（Pre-M4 Housekeeping）

**Goal**
- 修复 `load` 命令的 crash-unsafe game/ 替换（rmtree + copytree → 原子 rename）。

**Existing code**
- `src/neonrp/commands/save.py:64-68` — `shutil.rmtree(world_dir)` + `shutil.copytree(source, world_dir)`
- `src/neonrp/core/apply.py:136-156` — H4 修复后的原子 rename 策略（可参考）

**New work**
- 将 load 命令改为 rename 策略（与 apply.py 一致）：
  1. `shutil.copytree(source, world_dir.with_suffix('.new'))`
  2. `world_dir.rename(world_dir.with_suffix('.old'))`（如果存在）
  3. `world_dir.with_suffix('.new').rename(world_dir)`
  4. `shutil.rmtree(world_dir.with_suffix('.old'))`（如果存在）
- 考虑抽取公共工具函数 `core/storage.py:atomic_replace_dir()`

**Acceptance**
- load 过程中任意时刻崩溃不丢失 game/（旧目录在 rename 前仍存在）
- 现有 load 测试通过

**Tests**
- 单测：atomic_replace_dir 正常路径
- 单测：目标 game/ 不存在时 rename 正常

---

## H8 — `save.py` datetime.utcnow() 修复（Pre-M4 Housekeeping）

**Goal**
- 修复 `save.py:28` 使用已弃用的 `datetime.utcnow()`。

**Existing code**
- `src/neonrp/commands/save.py:28` — `datetime.datetime.utcnow().strftime(...)`
- `src/neonrp/core/manifest.py:7-8` — 已修复的 `datetime.now(timezone.utc)` 模式

**New work**
- 改为 `datetime.now(timezone.utc).strftime(...)`
- 添加 `from datetime import timezone` import

**Acceptance**
- 无 DeprecationWarning
- 现有测试通过

**Tests**
- 已有 save 测试覆盖

---

## H9 — PNG 角色卡导入（Pre-M4 Housekeeping）

**Goal**
- 扩展 `import sillytavern-card` 支持 PNG 格式角色卡。

**Existing code**
- `src/neonrp/commands/import_cmd.py` — 当前 JSON-only 入口，PNG 时 exit code 1 并提示
- `src/neonrp/core/importers/sillytavern.py` — `parse_card()`, `build_entity()` 核心映射逻辑

**Background**
SillyTavern PNG 角色卡在 PNG 文件的 `tEXt` chunk 中嵌入 Base64 编码的 JSON：
- PNG 文件以 8 字节 magic bytes 开头：`\x89PNG\r\n\x1a\n`
- 每个 chunk: 4 bytes length + 4 bytes type + data + 4 bytes CRC
- 角色数据在 `tEXt` chunk 中，keyword 为 `chara`，value 为 Base64 编码的 JSON

**New work**
- `src/neonrp/core/importers/png_extract.py` — 纯 Python PNG chunk reader（不依赖 Pillow）：
  - 验证 PNG magic bytes
  - 遍历 chunks 查找 `tEXt` 类型
  - 提取 keyword=`chara` 的 value
  - Base64 解码 → JSON parse
- 更新 `import_cmd.py`：自动检测文件格式（PNG magic bytes vs JSON `{` 开头）
- 移除当前的 PNG 拒绝逻辑

**Acceptance**
- `import sillytavern-card card.png` 自动检测 PNG 格式并提取 JSON
- 提取的 JSON 与直接导入 JSON 角色卡结果一致（经 `parse_card` + `build_entity`）
- 无 `tEXt`/`chara` chunk 的 PNG → exit code 1，可操作错误
- 损坏的 PNG → exit code 1，可操作错误
- 不依赖 Pillow 或其他图像库

**Tests**
- 单测：PNG chunk reader 提取 `chara` tEXt 数据
- 单测：缺少 `chara` chunk 的 PNG 报错
- 单测：损坏 PNG（截断、无效 magic bytes）报错
- 集成：import PNG card → validate → index build
- 需要 PNG fixture 文件（可在测试中用 Python 构造最小 PNG）

---

## M4-T0 — Sandbox/Replay 规格 + ADR（Doc-first）

**Goal**
- 固化 sandbox 与 replay 的最小可用规格，避免实现阶段反复改接口。

**Primary docs**
- `docs/M4_SANDBOX_REPLAY_DESIGN.md`
- `docs/ADRs/0011-sandbox-branch-model.md`
- `docs/ADRs/0012-replay-and-determinism-contract.md`

**Acceptance**
- 文档明确：save meta 字段、sandbox branch 元数据（kind/parent/fork_event/base_save）、replay verify 目标与边界
- 文档明确：world hash 算法、event type 扩展（system type for import/game）、replay verify --json 格式
- 文档明确：index invalidation 策略（sandbox switch 后失效 + 提示）
- Resolved Questions 全部已决

---

## M4-T1 — Save snapshot meta + events copy + world hash utility

**Goal**
- 让 `save` 的输出可用于 sandbox 与 replay。
- 提供 world hash 工具函数。

**Existing code**
- `src/neonrp/commands/save.py` — 当前 save 只复制 game/
- `src/neonrp/core/storage.py` — atomic write 工具
- `src/neonrp/core/event_log.py:47-62` — `read_events()` 读取分支事件
- `src/neonrp/core/manifest.py` — Manifest 模型

**New work**
- `src/neonrp/core/hashing.py` — `compute_game_hash(world_dir: Path) -> str` 工具函数
- `neonrp save` 扩展写入：
  - `.neonrp/saves/<id>/game/`（已有）
  - `.neonrp/saves/<id>/events.jsonl`（当前分支事件日志副本）
  - `.neonrp/saves/<id>/meta.json`（save_id/created/branch/head_event/game_hash/manifest_version）

**Acceptance**
- 新 save 总是包含 meta.json + events.jsonl
- meta.json 中 head_event 与 manifest 一致
- game_hash 确定性：同内容同 hash
- 旧格式 save（无 meta.json）在 sandbox/replay 时给出可操作报错

**Tests**
- 单测：`compute_game_hash` 稳定性（路径排序、同内容同 hash、新文件改变 hash）
- 单测：meta.json 结构与字段
- 集成：init → game new → run/apply → save → 检查 meta 与 events copy

---

## M4-T2 — `neonrp sandbox` 命令组

**Goal**
- 提供沙盒的创建/列表/切换/销毁。

**Existing code**
- `src/neonrp/commands/branch.py` — 现有 branch 命令（sandbox 复用 branch 语义）
- `src/neonrp/core/manifest.py` — BranchMetadata 模型（需扩展 kind/parent/fork_event/base_save）
- `src/neonrp/commands/save.py` — save/load 命令（sandbox new 需要读取 save）
- `src/neonrp/core/apply.py:136-156` — 原子 rename 策略（sandbox switch 需要复用）

**New work**
- `src/neonrp/commands/sandbox.py` — `neonrp sandbox new|list|switch|drop [--json]`
- `src/neonrp/core/manifest.py` — BranchMetadata 扩展：`kind`（`"main"` 或 `"sandbox"`）、`parent`、`fork_event`、`base_save`
- manifest.version bump 到 `"0.3"`
- sandbox switch 后 manifest.entities 失效：清空 entities 并提示 `index build`

**Acceptance**
- `sandbox new <name> --from <save_id>` 可用，并可 `--switch`
- `sandbox drop` 不允许删除 main；删除当前 sandbox 必须先切换或 `--force`
- sandbox switch 使用原子 rename 替换 game/
- switch 后 manifest.entities 清空，stderr 提示 `index build`
- `sandbox list` 区分 main 和 sandbox branches

**Tests**
- CLI：CliRunner 覆盖 new/list/switch/drop
- 集成：sandbox new → apply changes → switch back → verify main unchanged
- 单测：BranchMetadata 扩展字段序列化/反序列化

---

## M4-T3 — `neonrp replay verify`

**Goal**
- 从 save 基线重放事件到目标点，验证可复现。

**Existing code**
- `src/neonrp/core/apply.py:48-190` — `apply_proposal()` ops 执行逻辑（replay 复用 staging+ops 部分）
- `src/neonrp/core/event_log.py` — `read_events()` 事件日志读取
- `src/neonrp/core/hashing.py` — `compute_game_hash()`（M4-T1 产出）
- `src/neonrp/core/proposal.py` — Proposal 模型

**New work**
- `src/neonrp/commands/replay.py` — `neonrp replay verify --from <save_id> [--branch <branch>] [--to <event_id|head>] [--json]`
- `src/neonrp/core/replay.py` — 重放引擎：
  - 从 save 加载 world 到 staging
  - 过滤 `type in {"agent", "system"}` 事件
  - 每个事件通过 `run_id` 定位 proposal 日志，在 staging 上 apply ops
  - 每步计算 world hash 并与预期比较
  - mismatch 时停止，报告 divergent event id + file path

**Acceptance**
- 默认不写入真实 game/
- mismatch 时输出：first divergent event id + file path + expected/actual hash
- `--json` 输出格式见设计文档
- 缺少 proposal 日志的事件 → 报告为不可重放并跳过或报错

**Tests**
- 集成：stub/fixture proposal apply 后 replay verify 通过
- 集成：手动改 world 文件后 replay verify 报错
- 单测：event 选择逻辑（from/to range filtering）

---

## M4-T4 — replay checkout / sandbox at event

**Goal**
- 把 replay 结果落盘为一个可操作的状态（创建 sandbox 或 checkout）。

**Existing code**
- `src/neonrp/commands/replay.py` — replay verify（M4-T3 产出）
- `src/neonrp/commands/sandbox.py` — sandbox new（M4-T2 产出）
- `src/neonrp/core/replay.py` — 重放引擎（M4-T3 产出）

**New work**
- `neonrp replay checkout --from <save_id> --to <event_id> --to-branch <name> [--json]`
- 内部流程：replay to target event in staging → 创建 sandbox branch → 写入 world
- crash-safe：staging + 原子 swap

**Acceptance**
- checkout 过程 crash-safe（staging + 原子 swap）
- checkout 到新 sandbox 后 `find`/`context` 可看到对应状态（需先 `index build`）
- `--json` 输出 branch name, event_id, game_hash

**Tests**
- E2E：checkout 到新 sandbox 后验证 game/ 状态
- 集成：replay checkout → index build → find 可查到目标状态的实体

---

## M4-T5 — Event schema hardening: import/game → system proposal

**Goal**
- 保证所有 world 变更都可被 replay 重放。

**Existing code**
- `src/neonrp/commands/import_cmd.py` — 当前直接 `atomic_write_json` 写入 game/（不经过 apply pipeline）
- `src/neonrp/commands/game.py` — 当前直接写入 game/（不经过 apply pipeline）
- `src/neonrp/core/apply.py` — `apply_proposal()` pipeline
- `src/neonrp/core/proposal.py` — Proposal 模型

**New work**
- 重构 `import` 和 `game new`：生成 system proposal → 走 `apply_proposal()` pipeline
- System proposal 使用 `agent_id="system"`，`type="system"`
- 自动设置 `base_head_event` 和 `branch` 从当前 manifest
- 日志保存到 `.neonrp/logs/agents/<run_id>/`（复用现有结构）
- Event payload 包含 `command` 字段（`"import"` 或 `"game_new"`）

**Acceptance**
- import 和 game new 成功后有 event 记录（type=system, command=import/game_new）
- replay 可重放 import/game 事件
- 现有 import/game 测试通过（行为不变，仅增加 event 写入）

**Tests**
- 集成：import → verify event log → replay verify 通过
- 集成：game new → verify event log → replay verify 通过
- 单测：system proposal 生成逻辑

---

## M4-T6 — Review Gate

**Goal**
- 运行 `opencode run` 审查并落盘到 `reviews/`。

**Acceptance**
- Review saved under `reviews/`
- ALL review findings 记录到 `docs/PROGRESS.md`（含 disposition: fixed/deferred/accepted/wontfix）
- Tests green after fixes
- ROADMAP checkboxes + PROGRESS updated

