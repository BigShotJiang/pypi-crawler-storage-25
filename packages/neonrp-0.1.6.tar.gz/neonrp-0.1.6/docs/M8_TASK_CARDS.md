# M8 Task Cards — Universal Tools + Sub-Agents + Per-Agent LLM

---

## M8-T0: Specs + ADRs (doc-first)

**Goal**: Establish design decisions before coding.

**Deliverables**:
- ADR 0021: Universal Tool System (write_file, edit_file, glob, grep, ask_user)
- ADR 0022: Sub-Agent Task Tool — 2-layer depth + resume
- ADR 0023: Per-Agent LLM Configuration + Provider Registry
- M8 section in ROADMAP.md
- This task cards document

**Design decisions resolved**:
1. Dual-mode write: `direct_write_globs` in `agent.json`; proposal for `game/`, direct for auxiliary
2. edit_file: exact match only, 0 or >1 matches → error
3. ask_user: sentinel result + on_ask_user callback + tool result injection
4. Sub-agent: 2-layer max, `task` schema excluded at depth≥1
5. Resume: `SubAgentState` serialized to `.neonrp/agent_states/<run_id>.json`
6. Provider registry: named configs in `config.json`; agent.json references via `provider_ref`

**Acceptance**: All ADRs accepted. Task cards created. ROADMAP updated.

---

## M8-T1: write_file + edit_file Skills

**Goal**: Agents can directly write/edit auxiliary files; game/ changes still use proposal pipeline.

**Changes**:
- `core/permissions.py`: Add `check_write_permission(path, direct_write_globs, deny_globs)`
- `core/skills.py`: Add `write_file` and `edit_file` schemas + implementations; extend `SkillRegistry.__init__` with `direct_write_globs`
- `core/storage.py`: Add `atomic_write_text(path, content)`
- `core/agent_runner.py`: Pass `direct_write_globs` from `agent.json` to `SkillRegistry`

**write_file behavior**:
- Path in `direct_write_globs` → atomic write (create parent dirs)
- Path NOT in `direct_write_globs` → error "Use submit_proposal for this path"
- Path in `REQUIRED_DENY_GLOBS` → error "Permission denied"
- Path traversal (`..`) → rejected

**edit_file behavior**:
- Same permission checks as write_file
- Read file → count `old_text` occurrences → exactly 1 → replace → atomic write
- 0 matches → "Text not found" / >1 matches → "Text found N times, must be unique"

**Tests** (`tests/test_write_skills.py`): ~20
- Write to allowed/denied/deny-glob paths
- Path traversal rejection
- Parent dir auto-creation
- edit_file exact/not-found/multiple matches
- REQUIRED_DENY_GLOBS override

**Files**: `core/permissions.py`, `core/skills.py`, `core/storage.py`, `core/agent_runner.py`

---

## M8-T2: glob + grep Skills

**Goal**: Agents can discover files and search contents.

**Changes**:
- `core/skills.py`: Add `glob` and `grep` schemas + implementations

**glob(pattern, path?)**:
- Uses `Path.glob()` / `Path.rglob()`
- Results filtered by read_globs permissions
- Max 200 results; rejects `..` traversal

**grep(pattern, path?, glob?, max_results?)**:
- Regex search with `re.search()` per line
- Returns `[{file, line_number, line_content}]`
- Max 50 results (configurable); lines truncated to 500 chars
- Invalid regex → friendly error

**Tests** (`tests/test_search_skills.py`): ~16
- Glob matching / subdirectory / permissions / traversal / cap
- Grep content search / regex / glob filter / invalid regex / permissions / cap

**Files**: `core/skills.py`

---

## M8-T3: ask_user Skill + TUI/CLI Rendering

**Goal**: Agents can ask structured questions; user responses flow back into the agentic loop.

**Protocol**:
```
Agent → ask_user(question, options) → sentinel SkillResult
  → agent_runner detects sentinel → calls on_ask_user callback
    → TUI/CLI renders question + options → user responds
      → response injected as tool result → agentic loop resumes
```

**Changes**:
- `core/skills.py`: Add `ask_user` schema + sentinel implementation
- `core/agent_runner.py`: Add `on_ask_user: Callable[[str, list[str]], str]` parameter; detect sentinel in `_execute_tool()`; inject user response as tool result
- `core/dispatcher.py`: Pass `on_ask_user` through
- `tui/app.py`: Render question + options in transcript; collect user input via `call_from_thread`
- `commands/game.py`: CLI mode uses `click.prompt()` with choices

**Tests** (`tests/test_ask_user.py`): ~12
- Sentinel format / with-without options / loop pause-resume
- Callback invocation / response injection / empty question rejection

**Files**: `core/skills.py`, `core/agent_runner.py`, `core/dispatcher.py`, `tui/app.py`, `commands/game.py`

---

## M8-T4: task Tool + Sub-Agent + Resume

**Goal**: Agents can delegate to sub-agents; 2-layer depth limit; resumable sub-agents.

**2-layer depth**:
- `run_agent_agentic()` gains `current_depth: int = 0`
- At `current_depth >= 1`: `task` schema excluded from `tool_schemas`
- Sub-agents never see `task` as an available tool

**task execution** (special-cased in `_execute_tool`, like `submit_proposal`):
- Validate agent_id exists
- Call `run_agent_agentic(agent_id, prompt, current_depth=depth+1)`
- Sub-agent gets own `SkillRegistry`, own messages, own audit log
- Result serialized: `{success, run_id, agent_id, rationale, error, can_resume}`
- Errors caught and returned as tool results (no parent crash)

**Resume**:
- `SubAgentState` dataclass: run_id, agent_id, messages, turn, pending_user_input, skill_calls
- Saved to `.neonrp/agent_states/<run_id>.json` on sub-agent completion
- `task(agent_id, prompt, resume_run_id=...)` loads state and continues
- Rotation: keep last 20 states per agent

**Changes**:
- `core/skills.py`: Add `task` schema (dispatched in agent_runner, not SkillRegistry)
- `core/agent_runner.py`: `current_depth`/`max_depth`/`resume_state` params; `SubAgentState` dataclass; save/load state; recursive dispatch in `_execute_tool()`
- `core/config.py`: Add `max_sub_agent_depth: int = 2`
- `core/llm_stub.py`: Extend for multi-turn task testing
- `core/dispatcher.py`: Pass depth params

**Tests** (`tests/test_sub_agent.py`): ~18
- Task call success / result serialization / depth limit
- Isolated permissions / failure containment / not found
- Resume from saved state / invalid resume_run_id
- Separate audit logs / config depth setting

**Files**: `core/skills.py`, `core/agent_runner.py`, `core/config.py`, `core/llm_stub.py`, `core/dispatcher.py`

---

## M8-T5: Per-Agent LLM Configuration

**Goal**: Each agent can use a different LLM provider/model.

**Provider registry** in `config.json`:
```json
{
  "providers": {
    "fast": {"provider": "openai", "model": "gpt-4o-mini"},
    "strong": {"provider": "openai", "model": "gpt-4o"},
    "local": {"provider": "openai", "model": "llama3", "base_url": "http://localhost:11434/v1"}
  }
}
```

**Agent reference** in `agent.json`:
```json
{"llm": {"provider_ref": "strong"}}
```
or inline:
```json
{"llm": {"provider": "openai", "model": "gpt-4o", "temperature": 0.9}}
```

**Priority**: CLI --provider > agent inline > agent provider_ref > global config

**Changes**:
- `core/config.py`: `ProviderConfig` dataclass; `providers` dict in `ProjectConfig`; `resolve_provider()` function
- `core/llm.py`: `get_adapter_from_config(ProviderConfig)` factory
- `core/agent_runner.py`: Use `resolve_provider()` + `get_adapter_from_config()` for adapter creation
- `commands/agent.py`: `agent show` displays per-agent LLM config

**Tests** (`tests/test_per_agent_llm.py`): ~15
- No llm block → global / provider_ref / inline / ref not found
- CLI override / custom base_url / api_key_env
- Sub-agent own LLM / backward compat

**Files**: `core/config.py`, `core/llm.py`, `core/agent_runner.py`, `commands/agent.py`

---

## M8-T6: Integration + Orchestrator Example

**Goal**: End-to-end integration tests + example multi-agent setup.

**Example** (`examples/multi-agent/`):
- `agents/orchestrator/` — reads run_state, routes via task, merges results, uses ask_user
- `agents/narrator/` — creative writing with direct_write_globs for lore/

**Changes**:
- `examples/multi-agent/`: Agent definitions + system prompts
- `tests/test_m8_integration.py`: Full pipeline tests
- `docs/TUTORIAL.md`: Sub-agent / orchestrator section
- `docs/CLI_REFERENCE.md`: New tools documentation

**Tests** (`tests/test_m8_integration.py`): ~10
- orchestrator → task(narrator) pipeline
- ask_user in pipeline
- per-agent LLM + provider registry
- depth limit end-to-end
- mixed write modes

**Files**: `examples/multi-agent/`, `tests/test_m8_integration.py`, `docs/TUTORIAL.md`, `docs/CLI_REFERENCE.md`

---

## M8-T7: Review Gate

**Process**:
1. `ruff format` + `ruff check` — all clean
2. `pytest` — all 629+ tests pass
3. Code review → `reviews/M8_review_<date>.md`
4. Fix must-fix items
5. Re-run tests
6. Documentation completeness check
7. Update `docs/PROGRESS.md` + ROADMAP checkboxes

**Target**: 91+ new tests, 629+ total
