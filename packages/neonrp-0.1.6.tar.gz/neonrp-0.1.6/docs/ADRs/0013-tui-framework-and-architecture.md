# ADR 0013: TUI Framework and Architecture

- Status: Accepted
- Date: 2026-01-31
- Related: ROADMAP M5 (TUI), ARCHITECTURE (UI layer), REQUIREMENTS (TUI)

## Context
NeonRP 已有完整的 CLI + core 层能力（agent run / proposal / diff / apply / logs / sandbox / replay）。
M5 需要提供一个像 Claude Code / OpenCode 一样高效的 TUI，把这些能力组织成 keyboard-first 的终端体验。

关键约束：
- Windows Terminal 兼容
- streaming 输出
- 可测试（至少能在 CI 里做交互测试）
- 不通过 subprocess 调 CLI（避免解析 stdout、避免重复实现逻辑）

## Decision
1) 采用 **Textual** 作为 TUI 框架（Python 原生，适合 panes、async、Rich 渲染与测试）。
2) 增加 `neonrp tui` 入口命令，TUI 作为可选前端，不替代 CLI。
3) TUI 直接调用 `neonrp.core.*` 模块实现功能（agent run / apply / find/context / sandbox/replay），避免 subprocess。
4) 采用 view-model 思路：命令解析/状态机尽量放在纯函数/类中，便于单测。

## Consequences
- Positive: UI 开发速度快；可实现多 pane + overlay；支持测试 harness；复用现有核心逻辑。
- Negative: 引入新的依赖与 UI 复杂度；需要避免把业务逻辑写进 UI 事件回调。
- Neutral: 若未来要做 TUI 插件/主题系统，可在 Textual 基础上扩展，不影响核心。

## Alternatives considered
- Rich + prompt_toolkit：可做输入与部分布局，但复杂交互/多 pane/测试体验不如 Textual。
- urwid：成熟但风格较旧，开发体验与现代 terminal UX 目标不匹配。

