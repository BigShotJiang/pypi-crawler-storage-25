# ADR 0016: Session Log and Context Window

- Status: Accepted
- Date: 2026-02-02
- Related: ADR-0015 (Agentic Loop), M6 Task Cards (M6-T4)

## Context

M5 TUI transcript 仅在内存中，退出后丢失。每次 agent run 是独立的，无跨轮次上下文。RPG 需要叙事连贯性——"上一轮发生了什么"必须对 LLM 可见。

关键设计问题：
1. Session 存储格式和路径
2. Session 与 branch 的关系
3. 上下文窗口：注入多少历史到 LLM prompt
4. Session 恢复策略

## Decision

### 1. 存储格式：Per-branch JSONL

- 路径：`.neonrp/sessions/<branch>.jsonl`
- 每 branch 一个 session 文件（非 per-session-id）
- 格式：每行一条 `SessionEntry` JSON

简化说明：原计划为 `.neonrp/logs/sessions/<branch>/<session_id>.jsonl`（per-session-id），实现中简化为 per-branch 单文件。理由：
- RPG 场景中 branch 本身就代表一条叙事线
- 同一 branch 内的对话天然连续
- 避免 session_id 管理复杂度（创建/恢复/清理）

### 2. SessionEntry schema

```python
SessionEntry(
    timestamp: str,       # ISO format
    role: str,            # user | assistant | tool | system
    content: str | None,  # 消息文本
    tool_calls: list[dict],  # tool call 记录（assistant role）
    tool_call_id: str | None,  # tool result 关联 ID
    name: str | None,     # tool name（tool role）
    run_id: str | None,   # 关联的 agent run ID
)
```

与 `Message` 互转：`SessionEntry.from_message()` / `to_message()`。

### 3. Session 与 branch 绑定

- 切换 branch 时自动切换到该 branch 的 session
- 不同 branch 的 session 互不干扰
- Branch 内的对话上下文自动连续

### 4. 上下文窗口

- `DEFAULT_MAX_TURNS = 50`（session 最多保留 50 条 entry）
- `truncate_session()` 截断超出的旧条目
- Agent runner 将最近 N 轮 session history 注入到 system/user prompt

### 5. TUI Session 恢复（M6.5-T2）

- TUI 启动时调用 `read_session()` → 恢复 transcript 内容 + turn_count
- 损坏的 JSONL 行 graceful skip（不 crash）

## Consequences

- Positive: 跨轮叙事连贯——LLM 知道"上一轮发生了什么"
- Positive: Session 可审计——JSONL 格式可直接查阅
- Positive: Branch 隔离——不同故事线不会串上下文
- Negative: Per-branch 单文件不支持同一 branch 的多个独立 session
- Negative: 50 条上限是硬编码，大型 session 可能需要更智能的裁剪（摘要）
- Tradeoff: 截断比摘要简单但会丢失远期上下文

## Alternatives considered

1. **Per-session-id 文件**：`.neonrp/logs/sessions/<branch>/<session_id>.jsonl`。优点：支持多 session。缺点：增加 session 管理复杂度（哪个是"当前"session？恢复哪个？），MVP 阶段 over-engineering。
2. **SQLite**：结构化查询。缺点：JSONL 更简单，可直接 `cat` 查看，与项目其他日志格式一致。
3. **摘要裁剪**：用 LLM 总结旧轮次而非截断。推迟：增加额外 LLM 调用和延迟，MVP 用截断足够。

## Notes

- Session 目录不在 `.neonrp/logs/` 下（路径简化），但功能等价
- `append_user_query()` 和 `append_assistant_response()` 是 TUI 的便捷方法
- Session 恢复时 transcript 显示最近 20 条（UI 限制），但 context window 注入基于完整 session
