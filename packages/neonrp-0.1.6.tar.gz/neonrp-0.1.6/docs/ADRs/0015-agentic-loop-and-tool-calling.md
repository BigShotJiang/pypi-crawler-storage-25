# ADR 0015: Agentic Loop and Tool Calling

- Status: Accepted
- Date: 2026-02-02
- Related: ADR-0008 (LLM Adapter), ADR-0009 (Skill Tool Registry), M6 Task Cards

## Context

M0-M5 的 agent run 是单次 LLM 调用：query → generate() → proposal text。Agent 无法在一次 run 中先读取游戏数据、再推理、再生成变更。这是与 Claude Code 交互体验差距的根本原因。

M6 需要实现多轮 agentic loop：LLM 输出 tool_calls → 执行 skill → 结果喂回 LLM → 重复，直到 LLM 提交最终 proposal。

关键设计问题：
1. Proposal 如何提交——文本 JSON 还是 tool call？
2. 数据结构如何设计——兼容 OpenAI API 格式？
3. 终止条件和安全防护如何设置？

## Decision

### 1. Proposal 提交方式：`submit_proposal` tool call

LLM 通过调用 `submit_proposal` tool 提交最终 proposal，而非在文本中输出 JSON。

理由：
- 解析更可靠（tool call arguments 是结构化 JSON，不需要从混合文本中提取）
- 与 tool calling 流程统一（submit_proposal 就是另一个 tool，只是它终止 loop）
- 终止条件更清晰（收到 `submit_proposal` call = loop 结束）

`submit_proposal` schema 定义在 `core/skills.py`，包含 `run_id`, `agent_id`, `branch`, `base_head_event`, `rationale`, `ops` 字段。

### 2. 数据结构（`core/llm.py`）

```python
ToolCall(id: str, name: str, arguments: dict)     # 单个 tool call
Message(role, content, tool_calls, tool_call_id, name)  # 对话消息
LLMTurnResult(message, tool_calls, finished, usage, error)  # 单轮结果
```

- `Message.to_api_dict()` 转换为 OpenAI API 格式
- `LLMTurnResult.finished` 为 True 时表示 LLM 不再请求 tool calls（loop 可结束）

### 3. LLMAdapter Protocol 扩展

保留 `generate()` 向后兼容（M3 单次调用路径），新增：
- `chat(messages: list[Message], tools: list[dict] | None) -> LLMTurnResult`

### 4. Agentic loop（`core/agent_runner.py:run_agent_agentic()`）

```
构建初始 messages（system + user）
for turn in range(max_turns):
    result = adapter.chat(messages, tools)
    if result.tool_calls:
        for tc in result.tool_calls:
            if tc.name == "submit_proposal":
                → 提取 proposal, break loop
            else:
                → execute skill, append tool result to messages
    else:
        → no tool calls and no proposal = stuck, exit
```

### 5. 终止条件和安全防护

- `MAX_AGENTIC_TURNS = 20`（每次 run 最多 20 轮对话）
- Tool result 截断：`read_file` 最多返回 5000 字符（`MAX_READ_CHARS`）
- 权限被拒时：将 error tool_result 喂回 LLM（允许自我修正），不崩溃
- 无进展检测：连续无 tool_calls 且无 submit_proposal → fail fast

## Consequences

- Positive: Agent 可以先查阅游戏数据再做决策，RPG 体验大幅提升
- Positive: submit_proposal 作为 tool call，解析失败率接近零
- Positive: generate() 保留，M3 单次调用路径不受影响
- Negative: 多轮调用增加 token 消耗和延迟
- Negative: MAX_AGENTIC_TURNS 是硬编码（未来可能需要 per-agent 配置）
- Tradeoff: 20 轮上限在复杂场景可能不够，但能防止 token 爆炸

## Alternatives considered

1. **文本 JSON 输出**（M3 方式）：LLM 在 content 中输出 proposal JSON。问题：提取不可靠，需要 regex/JSON 边界检测，混合文本中提取容易出错。
2. **独立 propose 方法**：LLMAdapter 增加 `propose()` 方法。问题：与 tool calling 流程割裂，增加 Protocol 复杂度。
3. **精确 token 计数**：每轮计算 token 用量，按 context window 预算裁剪。推迟：MVP 用 max_turns + 字符截断已足够，精确计数需要 tokenizer 依赖。

## Notes

- StubAdapter 支持脚本化 fixtures：第 1 轮返回 tool_call（如 read_file），第 2 轮返回 submit_proposal，用于 CI 测试
- `generate()` 和 `chat()` 共存于 LLMAdapter Protocol，前者供旧代码/简单场景使用
