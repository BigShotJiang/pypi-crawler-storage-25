# ADR 0026: Sub-Agent Delegation Contract v2 — `fast` vs `orchestrator`

- Status: Accepted
- Date: 2026-04-13
- Related: ADR 0015 (Agentic Loop), ADR 0017 (Dispatcher), ADR 0021 (Universal Tool System), ADR 0022 (Sub-Agent Task Tool)

## Context

NeonRP now needs to support two different delegation semantics without breaking existing worlds:

1. A **compatibility path** where sticky specialists may directly become the player-facing responder.
2. A stricter **orchestrator path** where the top-level narrator/orchestrator always owns the player-facing response, while specialists operate as backend domain processors.

The existing M12 work introduced `active-agent.json`, sticky delegation, runtime guardrails, and router execution-mode scaffolding. However, the desired long-term semantics are not identical across all worlds:

- Existing worlds and tests need a **fast** mode that preserves current behavior.
- New worlds should default to **orchestrator** mode, which is closer to a stable controller-specialist architecture.

At the same time, NeonRP already has a strong tool system. Game mechanics like dice, checks, and pure rule evaluation should be expressed as **deterministic-style game tools**, not as free-form Python execution or pseudo-agents.

## Decision

### 1. Router execution modes are first-class runtime-contract data

`runtime_contract.router.execution_mode` defines the active delegation semantics for a project.

Valid values:

- `fast`
- `orchestrator`
- `multi-agent` (reserved placeholder)

Defaults:

- Existing projects without this field behave as `fast`
- New default templates use `orchestrator`

### 2. `fast` mode preserves current semantics

In `fast` mode:

- Sticky specialists may become the effective player-facing responder.
- `active-agent` may act as a primary routing-state mechanism.
- Same-turn specialist rolling is allowed (e.g. specialist handoff followed by another specialist in the same turn).
- This mode exists for backward compatibility and low-latency direct routing.

### 3. `orchestrator` mode has different semantics

In `orchestrator` mode:

- `speaker` is always the top-level narrator/orchestrator.
- `active-agent` is **not** a primary semantic routing authority.
- `active-agent` remains in the schema for compatibility, debugging, and future modes, but orchestrator-mode routing must not depend on it as the core control signal.
- Specialists run as backend processors.
- Specialists return structured results / summaries / state-change signals.
- The top-level orchestrator performs the final player-facing narration pass.

This means orchestrator mode is not just “fast mode with a renamed speaker”; it is a different contract.

### 4. Player-facing vs backend concepts are separated explicitly

The following concepts are distinct:

- `speaker`
  - The player-facing speaker for this turn.
  - In `orchestrator`, this is always narrator/orchestrator.

- `delegated_to`
  - The specialist actually called during the current turn.

- `active-agent`
  - A retained compatibility/debug field.
  - May still exist in state and format.
  - In `orchestrator`, must not define player-facing control.

- `route_decision`
  - The structured explanation of why this turn used self, tool, or specialist routing.

### 5. Orchestrator-mode turn flow

Per turn, orchestrator mode follows this logical flow:

1. Top-level narrator/orchestrator receives user input.
2. It reads relevant world state.
3. It decides whether to:
   - narrate directly,
   - call tools,
   - delegate to a specialist,
   - continue its own top-level multi-turn reasoning loop.
4. If a specialist is used, that specialist performs backend processing.
5. The specialist returns structured results.
6. The top-level orchestrator performs the final player-facing narration.

Additional constraint:

- The orchestrator may keep exactly **one top-level agent loop per player turn**.
- The orchestrator must **not** re-enter itself as a second recursive orchestrator pass.
- In other words, orchestrator mode allows top-level tool use + specialist delegation inside one controller loop, but disallows orchestrator self-recursive re-entry.

### 6. Specialist recursion is allowed, but bounded

To support domain refinement (for example `dungeon-agent -> combat-referee`), orchestrator mode allows bounded recursive specialist calls.

Maximum agent-call depth is **3 layers total**:

```text
Layer 0: orchestrator
Layer 1: specialist
Layer 2: specialist-called specialist
```

Rules:

- Layer 0 may call specialists.
- Layer 1 specialists may call one deeper specialist.
- Layer 2 specialists may **not** call more specialists.
- Depth-2 agents may still:
  - use tools,
  - perform multi-turn self reasoning,
  - read/write allowed files.

This keeps recursion useful but bounded.

### 7. Tools and specialists are different abstractions

#### Tools

Use tools for:

- deterministic or bounded computation,
- rule evaluation,
- local mechanical outcomes,
- file and context operations,
- limited, auditable actions.

Examples:

- `read_file`
- `write_file`
- `find`
- `resolve_action`
- future dice/check tools

#### Specialists

Use specialists for:

- domain reasoning,
- multi-step state coordination,
- complex context handling,
- routing to another specialist when the domain truly changes,
- orchestration of multiple tool calls.

### 8. Dice and checks are tools, not specialists

Dice mechanics must not be implemented as open Python execution or as pseudo-agents.

They should be exposed as **restricted game-mechanic tools** implemented internally in Python.

Recommended future tools:

- `roll_dice`
- `roll_check`
- `resolve_check`

These tools should:

- use game terminology,
- return structured results,
- avoid direct file mutation,
- be replayable/testable via explicit inputs (including optional seed support).

### 9. Fallback orchestrator

If a project defines neither `narrator` nor `orchestrator`, the system should use an internal fallback orchestrator prompt.

This fallback is still **orchestrator mode**, not a separate mode.

The fallback orchestrator:

- may use tools,
- may perform one top-level multi-turn reasoning loop,
- may read/write according to default safe permissions,
- should not invent arbitrary domain semantics,
- should act as a minimal controller when no project-specific orchestrator exists.

### 10. Fast mode is not changed by this ADR

This ADR explicitly does **not** redefine `fast` mode behavior beyond naming it and preserving it.

Any migration toward orchestrator-mode semantics must not break existing fast-mode worlds.

## Consequences

- Positive: Clear semantic separation between compatibility routing and controller-style routing.
- Positive: Allows future high-fidelity orchestrator worlds without breaking existing sticky specialist worlds.
- Positive: Keeps dice/check mechanics inside the tool system, not as general execution.
- Positive: Enables bounded specialist recursion for richer domains.
- Negative: Orchestrator mode now requires a stronger contract for structured specialist outputs.
- Negative: Some current orchestrator implementation details may need further refinement to fully stop relying on `active-agent` as a control mechanism.

## Alternatives considered

### A. Keep only one delegation semantic

Rejected.

This would either break old worlds or block the cleaner orchestrator architecture.

### B. Remove `active-agent` entirely

Rejected.

It still has value as a compatibility/debug field and may remain useful for future modes.

### C. Model dice as specialists

Rejected.

Dice and checks are not domain personas; they are bounded mechanics and fit the tool system much better.
