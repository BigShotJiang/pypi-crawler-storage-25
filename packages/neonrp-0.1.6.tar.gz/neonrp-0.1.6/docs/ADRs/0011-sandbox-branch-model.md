# ADR 0011: Sandbox Branch Model

- Status: Proposed
- Date: 2026-01-30
- Related: ROADMAP M4-T1~T4, REQUIREMENTS R4, ADR 0003 (snapshot/branch), ARCHITECTURE (storage safety)

## Context
NeonRP needs a "sandbox" feature: a temporary playable timeline derived from an existing save, without affecting the main line.
We already have branches, saves, and an apply pipeline; sandbox should reuse these primitives while remaining safe and auditable.

## Decision
1) **Sandbox is a special branch**: a branch with `kind = "sandbox"` (or equivalent metadata) stored in `manifest.json`.
2) **Sandbox is created from a save**: `sandbox new --from <save_id>` copies the save's world into the sandbox branch storage and sets the sandbox head_event to the save head_event.
3) **Sandbox has its own event log**: `.neonrp/events/<sandbox>.jsonl`.
4) **Sandbox drop is safe**: cannot delete `main`; dropping the current sandbox requires switching away (or explicit `--force`).

## Consequences
- Positive: sandbox reuse branch semantics; isolation is explicit; operations remain auditable.
- Negative: requires save snapshots to record `head_event` and (optionally) events copy; may require a manifest version bump to store branch metadata.
- Neutral: merge/cherry-pick back to main is deferred (P2).

## Alternatives considered
- Use a separate sandbox directory outside branch system: rejected (duplicates concepts, harder to audit).
- Treat sandbox as "just a save": rejected (doesn't support continued gameplay and event logging).
