# ADR 0004: World Entity Conventions

- Status: Proposed
- Date: 2026-01-29
- Related: ROADMAP M1-T0/M1-T1/M1-T2, REQUIREMENTS R3, ARCHITECTURE (game/, schema/)

## Context
M1 需要为 `game/` 下的数据文件建立：
1) 可验证的结构（schema validation）
2) 可索引的寻址方式（manifest entity index）
3) 可检索的最小上下文（find/context）

如果缺少统一约定，后续会出现：
- id 不唯一导致 find/索引歧义
- kind 不一致导致权限边界（M2）与检索策略无法落地
- 文件分布随意导致扫描/增量更新成本高

## Decision
### 1) 路径约定（推荐）
世界实体使用：

`game/<kind>/<id>.json`

示例：
- `game/town/tokyo.json`
- `game/dungeon/iron-mine.json`
- `game/item/health-potion.json`

允许的扩展（后续里程碑）：
- `game/<kind>/<id>.yaml`（若引入 YAML）
- `game/<kind>/<id>/...`（当一个实体需要多文件拆分时，但 M1 默认不启用）

### 2) 最小实体字段（M1 必须）
每个实体文件必须包含：
- `id`: string（全局唯一；允许字符：`[a-z0-9-_.]`，建议使用 kebab-case）
- `kind`: string（与路径中的 `<kind>` 一致）
- `name`: string（用户可读名称）

可选字段（用于检索/叙事；M1 不强制，但强烈建议）：
- `tags`: string[]（标签）
- `summary`: string（1~3 句摘要，用于关键词检索与最小上下文）

保留字段（M1 不定义语义，但允许存在）：
- `meta`: object（作者、来源、版本、扩展信息）

### 3) 唯一性与冲突规则
- `id` 必须在整个 `game/` 中唯一（跨 kind 也唯一）。
  - 例外：若未来确实需要同名 id，可在 manifest key 中使用 `kind:id` 消解；但 M1 的校验仍以“全局唯一”为默认规则。
- 同一实体的 `kind` 必须与路径一致，否则视为错误。

## Consequences
- Positive: 扫描与索引变为确定性流程；schema 可直接覆盖最常见错误；为 M2 的权限边界与 agent ownership 建立基础。
- Negative: 对现有世界数据（若已存在且无规律）需要一次性迁移整理路径与字段。
- Neutral: M1 只规定最小字段，不限制更复杂的 domain schema（城镇/地下城/战斗等）由后续扩展 schema 完成。

## Alternatives considered
- **Sidecar meta 文件**（`town.json` + `town.meta.json`）：
  - 优点：索引信息可与内容分离。
  - 缺点：文件数翻倍，易失配，写入与回滚更复杂；M1 不采用。
- **完全自由的目录结构**：
  - 优点：不约束内容组织。
  - 缺点：索引/权限/检索都变复杂；M1 不采用。

## Notes
- M1 的 schema 校验分两层：结构层（本 ADR）+ 约束层（唯一性、kind 合法值等）。
- 后续如需要强类型（例如 `town.schema.json`），在不破坏最小字段的前提下扩展即可。

