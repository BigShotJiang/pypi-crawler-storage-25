# ADR 0019: LLM Error Handling and Retry Strategy

- **Status**: Accepted
- **Created**: 2026-02-02
- **Context**: M7-T0

## Context

M6 implemented the agentic loop with `OpenAIAdapter`, but all error handling is a catch-all `except Exception` that returns a generic error string. Real LLM providers return diverse error types (rate limits, auth failures, timeouts, malformed responses) that require different handling strategies. The stub adapter never exercises these paths.

Additionally, there is no tool argument validation — the LLM can send malformed arguments that cause skill execution failures without helpful feedback.

## Decision

### Error Taxonomy

Introduce `core/llm_errors.py` with typed error hierarchy:

```python
class LLMError(Exception):
    """Base error for LLM operations."""
    retryable: bool = False

class RetryableError(LLMError):
    """Transient error that may succeed on retry (429, 5xx, timeout)."""
    retryable = True

class AuthError(LLMError):
    """Authentication/authorization failure (401, 403)."""

class InvalidResponseError(LLMError):
    """LLM returned malformed or unparseable response."""

class BudgetExhaustedError(LLMError):
    """Token or turn budget exceeded."""
```

### Retry Strategy

- **Scope**: `OpenAIAdapter.chat()` and `chat_stream()` methods
- **Algorithm**: Exponential backoff: 1s, 2s, 4s (base * 2^attempt) with 0-1s random jitter
- **Max retries**: Configurable via `config.json: llm.max_retries` (default: 3)
- **Retryable errors**: HTTP 429 (rate limit), 500/502/503 (server), `ConnectionError`, `Timeout`
- **Non-retryable errors**: HTTP 401/403 (auth — fail fast with "Check API key"), 400 (bad request)
- **Logging**: Each retry attempt logged with error type and backoff duration

### Error mapping (OpenAI SDK)

| OpenAI exception | NeonRP error | Retry? |
|-----------------|--------------|--------|
| `openai.RateLimitError` | `RetryableError` | Yes |
| `openai.APIConnectionError` | `RetryableError` | Yes |
| `openai.APITimeoutError` | `RetryableError` | Yes |
| `openai.InternalServerError` | `RetryableError` | Yes |
| `openai.AuthenticationError` | `AuthError` | No |
| `openai.BadRequestError` | `InvalidResponseError` | No |
| `json.JSONDecodeError` (tool args) | `InvalidResponseError` | No |

### Token Budget

- **Estimation**: `sum(len(msg.content or "") for msg in messages) // 4` (chars/4 approximation, no tokenizer dependency)
- **Config**: `llm.max_context_chars: int = 100000` (~25K tokens)
- **Behavior at 80%**: inject warning system message ("Context budget nearly exhausted, please call submit_proposal now")
- **Behavior at 100%**: raise `BudgetExhaustedError`, terminate loop with partial result

### Tool Argument Validation

- `validate_tool_arguments(name, args) -> (bool, error_msg | None)` validates against `SKILL_SCHEMAS`
- Called in `_execute_tool()` before skill dispatch
- On failure: return error as tool_result message (not crash), allowing LLM to self-correct
- `submit_proposal.ops` schema tightened: items require `op` (enum), `path` (minLength 1), optional `content`

## Consequences

- Real LLM providers become usable (transient failures recovered automatically)
- Invalid tool calls produce helpful feedback instead of crashes
- Token budget prevents runaway multi-turn loops from consuming unlimited API credits
- Auth errors fail fast with actionable messages
- Existing stub tests unaffected (stub doesn't raise these errors)

## Alternatives Considered

1. **Use `tenacity` library for retry**: Adds dependency for minimal gain; hand-rolled retry is ~15 lines.
2. **Use `tiktoken` for token counting**: Adds heavy dependency; char/4 approximation is sufficient for budget guardrails.
3. **Retry at agent_runner level instead of adapter**: Adapter-level retry is cleaner; the agent_runner shouldn't need to know about HTTP error codes.
