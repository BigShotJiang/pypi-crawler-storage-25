# ADR 0003: Snapshot and Branch Strategy

- Status: Proposed
- Date: 2026-01-29
- Related: ROADMAP T3/T4a/T4b, REQUIREMENTS R0/R4, ARCHITECTURE (saves/)

## Context
NeonRP 需要支持 save/load（快照）、undo/redo（状态回退）、branch（时间线分叉）三种操作。需要决定：
1. 快照的存储方式（全量复制 vs 增量）
2. 分支的数据结构（DAG vs 线性树）
3. undo/redo 的实现机制

## Decision

### 快照：全量目录复制
Save 操作将 `game/` 目录和 `.neonrp/events/` 完整复制到 `.neonrp/saves/<save_id>/`。

```
.neonrp/saves/
  save_0001/
    game/          # game/ 的完整副本
    events.ndjson   # 当前分支事件日志的副本
    meta.json       # 快照元数据（时间、分支名、head_event seq）
```

Load 操作将快照内容恢复到工作区。

### 分支：树形结构（parent pointer）
每个分支记录其父分支和分叉点：

```json
{
  "name": "try-stealing-route",
  "parent": "main",
  "fork_event": 5,
  "created": "ISO-8601"
}
```

分支信息存储在 `manifest.json` 的 `branches` 字段中。

分支创建时：
1. 复制父分支的事件日志（截止到 fork_event）为新分支的事件文件
2. 工作区 `game/` 不变（继续在当前状态上操作）
3. 后续事件写入新分支的事件文件

### Undo/Redo：基于快照回退
- 每回合（`run`）执行前自动创建一个轻量快照（auto-save）
- `undo` = 恢复到上一个 auto-save
- `redo` = 恢复到下一个 auto-save（如果存在）
- Auto-save 使用独立目录：`.neonrp/saves/_auto/turn_<seq>/`

## Consequences
- Positive: 全量复制实现简单，正确性可验证（hash 比对）；分支隔离天然保证（独立事件文件）；undo/redo 语义清晰
- Negative: 全量复制在大型世界下占用磁盘空间；auto-save 每回合都复制一次 game/
- Neutral: 空间问题可在后续里程碑优化（增量快照、COW），M0 优先保证正确性

## Alternatives considered
- **增量快照（diff-based）**: 只存储变更的文件。节省空间但恢复逻辑复杂，需要从基准点逐层叠加 diff，容易出错。
- **COW（Copy-on-Write）**: 使用硬链接或 reflink，性能好但依赖文件系统支持（Windows NTFS 不支持 reflink），跨平台有问题。
- **DAG 分支模型**: 允许分支合并。复杂度高，M0 不需要，M4 沙盒合并标记为 P2。

## Notes
- Auto-save 的保留策略暂定为保留最近 20 个回合的快照，超出后清理最早的。具体数字可通过配置调整。
- M4（Sandbox）可直接复用 branch 机制：sandbox = 一个特殊标记的 branch。
- 如果后续世界数据量增长到全量复制不可接受的程度，优先考虑增量快照方案。
