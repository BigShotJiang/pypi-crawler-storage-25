# ADR 0012: Replay and Determinism Contract

- Status: Proposed
- Date: 2026-01-30
- Related: ROADMAP M4-T3~T5, REQUIREMENTS (replay), ARCHITECTURE (determinism + audit)

## Context
NeonRP aims to be resumable, undoable, and debuggable. When world state breaks, we need to answer: "Which step diverged?".
Replay provides this by rebuilding world state from a known baseline and replaying recorded changes deterministically.

## Decision
1) **Replay uses recorded inputs, not re-calling the LLM**.
   - For agent/apply events, the event must include (directly or indirectly) a stable pointer to the proposal used (e.g. `payload.run_id` -> `.neonrp/logs/agents/<run_id>/proposal.json`).
2) **Replay is non-destructive by default**.
   - `replay verify` operates on a staging copy and does not modify real `game/`.
   - Any checkout behavior must be explicit and crash-safe.
3) **World hash is defined and stable**.
   - Tree hash is computed over sorted file paths and per-file sha256 of bytes; final digest is prefixed with `sha256:`.
4) **World mutations must be replayable**.
   - Commands that mutate world outside the proposal/apply pipeline (e.g. import, game scaffolding) should be refactored to emit replayable events (preferably via system proposals).

## Consequences
- Positive: reproducible debugging; offline verification; compatible with CI.
- Negative: requires consistent logging discipline and storage of proposal artifacts.
- Neutral: full engine RNG determinism can be layered later by recording seed/rolls in events.

## Alternatives considered
- Re-run the LLM during replay: rejected (not deterministic and requires network).
- Store full world snapshots for every event: rejected (too much disk; save snapshots already exist).
