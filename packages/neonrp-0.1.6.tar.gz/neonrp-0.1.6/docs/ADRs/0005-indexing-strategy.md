# ADR 0005: Indexing Strategy (Manifest + Optional Inverted Index)

- Status: Proposed
- Date: 2026-01-29
- Related: ROADMAP M1-T2/M1-T3/M1-T4/M1-T5, REQUIREMENTS R3, ARCHITECTURE (index/)

## Context
NeonRP 在 M1 要解决的核心问题是：世界文件变多后，仍能快速定位“与本回合相关的最小上下文”，并为后续 agent 系统提供稳定的寻址层。

需求侧（R3）要求：
- `find` 能按 id/tag/关键词定位实体
- `run`（未来）不必每次重读全部文件

## Decision
### 1) Manifest 作为“权威索引”
在 `.neonrp/manifest.json` 中新增顶层字段 `entities`：

```json
{
  "entities": {
    "town:tokyo": {
      "id": "tokyo",
      "kind": "town",
      "name": "Tokyo",
      "tags": ["capital", "market"],
      "summary": "A dense neon city...",
      "path": "game/town/tokyo.json",
      "mtime": 0,
      "hash": "sha256:..."
    }
  }
}
```

Key 使用 `"{kind}:{id}"`，避免跨 kind 冲突，并便于未来做权限边界（按 kind 分区）。

### 2) 索引构建与增量更新
提供命令：
- `neonrp index build`: 扫描 `game/` 全量重建 `entities`
- `neonrp index update`: 基于 `mtime/hash` 做增量更新（只重新解析变更文件）

行为约束：
- build/update 都必须是幂等的（重复执行产生同样的结果）
- index 更新必须是可审计的（写入 event/log；具体落地在实现阶段）

### 3) 可选：倒排关键词索引（M1-T3）
为了避免每次关键词搜索都扫描所有文件内容，可选引入：
- `.neonrp/index/inverted.json`（term → [entity_key...]）

M1 默认 ranking 优先使用：
1) `tags` / `name` 命中
2) `summary` 命中
3) （可选）文件内容 token 命中（仅当需要且成本可控）

## Consequences
- Positive: `manifest.entities` 作为单一真相，find/context 的行为可预测；增量更新支撑大世界场景；为 M2 的 agent ownership/权限控制预留结构。
- Negative: 需要定义稳定的 tokenization 策略，否则倒排索引质量不稳定；M1 先以简单规则为主。
- Neutral: embedding 索引（向量检索）可后置到 M3/M4，不影响 manifest 的稳定性。

## Alternatives considered
- **每次 find 扫描 game/ 全文本搜索**：
  - 优点：实现简单。
  - 缺点：性能差，无法支持“最小上下文”；仅作为降级策略。
- **SQLite 作为主索引**（WAL）：
  - 优点：查询强、增量更新方便、并发友好。
  - 缺点：引入迁移/备份复杂度；M1 不做主依赖（可作为 T3 的替代实现）。

## Notes
- manifest 本身需要保留扩展性（未来添加 `errors`, `refs`, `ownership` 等字段）。
- `entities` 的字段是“检索元数据”，不替代世界文件本身的 domain schema。

