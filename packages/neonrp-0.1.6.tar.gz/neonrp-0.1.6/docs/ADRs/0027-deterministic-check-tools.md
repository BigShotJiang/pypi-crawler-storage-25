# ADR 0027: Deterministic Check Tools — `roll_dice` / `roll_check` / `resolve_check`

- Status: Accepted
- Date: 2026-04-13
- Related: ADR 0020 (Game Rules Engine), ADR 0021 (Universal Tool System), ADR 0026 (Sub-Agent Delegation Contract v2)

## Context

NeonRP's current mechanics surface includes `resolve_action`, which covers a small fixed set of game actions (`damage`, `heal`, `buy`, `sell`, `move`).

This is not enough for role-play-first gameplay that depends on:

- skill checks,
- uncertain social actions,
- contested actions,
- narrated dice outcomes,
- benchmarkable and replayable mechanical rulings.

At the same time, ADR 0026 already establishes that dice and checks should be modeled as **deterministic-style tools**, not specialists and not open Python execution.

## Decision

NeonRP will model dice/check mechanics as builtin **game-mechanic tools** implemented in Python and exposed through the tool system.

The long-term family is:

- `roll_dice`
- `roll_check`
- `resolve_check`

The **minimum implementation** starts with `roll_check` only.

## Tool roles

### `roll_dice`

Low-level dice primitive.

Use when the caller needs explicit dice output but is still responsible for interpreting the meaning.

### `roll_check`

Primary minimum-viable tool.

Use for standard “attempt something uncertain” checks in role-play and GM-style adjudication.

This should be the first tool implemented.

### `resolve_check`

Higher-level wrapper for future rules integration.

Use when check semantics depend on system-level concepts like:

- attack roll,
- saving throw,
- contested check,
- social persuasion,
- stealth vs perception,
- advantage/disadvantage,
- critical success/failure.

This is intentionally deferred until after the minimum `roll_check` lands.

## Contract principles

All deterministic check tools must follow these rules:

1. They are **tools**, not specialists.
2. They are implemented in Python internally, but do **not** expose arbitrary Python execution.
3. They do **not** directly mutate files.
4. They return structured results usable by orchestrators and specialists.
5. They use game terminology, not engineering terminology.
6. They are replayable and testable.

## Minimum implementation: `roll_check`

### Purpose

Provide a role-play-friendly, bounded, deterministic-style d20-style check tool for uncertain actions.

### Initial scope

Phase 1 intentionally keeps the contract narrow:

- d20-style checks only
- one character/actor at a time
- single target difficulty
- no file writes
- no initiative system
- no contested chains beyond simple comparison
- no full combat resolution

### Proposed schema

```json
{
  "name": "roll_check",
  "description": "Resolve a bounded game check using deterministic dice logic. Use this for uncertain actions such as persuasion, stealth, climbing, searching, resisting danger, or other GM-style rulings.",
  "parameters": {
    "type": "object",
    "properties": {
      "character_id": {
        "type": "string",
        "description": "Entity id of the acting character. Usually 'player' or an NPC id."
      },
      "stat": {
        "type": "string",
        "description": "The stat or skill being checked, e.g. STR, DEX, INT, CHA, stealth, persuasion."
      },
      "difficulty": {
        "description": "Target difficulty. Accept integer DC or preset string: easy, medium, hard, epic."
      },
      "modifier": {
        "type": "integer",
        "description": "Optional situational modifier applied after stat bonus.",
        "default": 0
      },
      "description": {
        "type": "string",
        "description": "Short natural-language description of what the character is attempting.",
        "default": ""
      },
      "seed": {
        "type": "string",
        "description": "Optional explicit seed for replay-safe deterministic rolls. If omitted, NeonRP derives a deterministic per-run seed.",
        "default": ""
      }
    },
    "required": ["character_id", "stat", "difficulty"]
  }
}
```

### Difficulty normalization

The tool should normalize preset difficulty labels to numeric targets:

- `easy` → `10`
- `medium` → `15`
- `hard` → `20`
- `epic` → `25`

If `difficulty` is already an integer, use it directly.

### Result contract

```json
{
  "success": true,
  "character_id": "player",
  "stat": "DEX",
  "difficulty": 15,
  "roll": 14,
  "stat_bonus": 3,
  "modifier": 2,
  "total": 19,
  "passed": true,
  "critical": null,
  "margin": 4,
  "narration_hint": "success",
  "description": "Slip past the sleepy guard"
}
```

### Result fields

- `roll`: raw d20 result
- `stat_bonus`: resolved bonus from the character stat/skill
- `modifier`: explicit situational modifier
- `total`: `roll + stat_bonus + modifier`
- `passed`: whether total met/exceeded difficulty
- `critical`: one of `critical_success`, `critical_failure`, or `null`
- `margin`: `total - difficulty`
- `narration_hint`: one of:
  - `critical_success`
  - `critical_failure`
  - `success`
  - `failure`

## Determinism model

The implementation must be deterministic **for the same run and same call context**.

### Seeding rules

Order of precedence:

1. If caller provides `seed`, use it.
2. Otherwise derive a seed from:
   - `run_id`
   - `agent_id`
   - tool name
   - normalized arguments
   - skill-call index within the current run

This gives:

- stable results for a given replayed call context,
- easier testing,
- auditability,
- no dependency on global randomness.

### Why not true randomness

True randomness makes:

- undo / replay,
- benchmark reproducibility,
- deterministic testing,

much harder.

NeonRP therefore treats dice as **narratively random but operationally deterministic** unless explicit future game modes require a different policy.

## Data lookup rules

`roll_check` may read game state to resolve the actor's stat/skill bonus.

Minimum behavior:

- resolve `character_id` to a game entity
- inspect the entity's stat block
- if the stat/skill is missing, fall back to a neutral/default bonus

Recommended minimum stat-resolution policy:

- exact stat/skill key match first
- case-insensitive fallback
- if no value found, use default bonus `0`

The tool must not fail just because a world uses incomplete stat data.

## Narration contract

`roll_check` does **not** produce final player-facing narration.

It returns structured information and a `narration_hint`, which the caller uses to narrate the result.

This keeps narration responsibility with:

- orchestrator,
- narrator,
- or a specialist such as a combat/domain referee.

## Minimal implementation plan

### Phase 1 — `roll_check` only

Implement only:

- schema registration
- skill dispatch in `SkillRegistry`
- deterministic d20 roll
- difficulty normalization
- stat lookup
- structured result payload
- unit tests

### Phase 2 — optional `roll_dice`

Add a lower-level dice primitive only if callers truly need raw dice without check semantics.

### Phase 3 — `resolve_check`

Add richer rules-layer semantics once check patterns stabilize.

## Tests required for Phase 1

1. Same inputs + same derived seed → same result
2. Explicit `seed` overrides derived seed
3. Difficulty label normalization works
4. Missing stat falls back to default bonus
5. Critical success/failure hinting works
6. Tool does not mutate files
7. Tool result is serializable and stable

## Consequences

- Positive: Keeps dice/check mechanics inside the tool system.
- Positive: Fits orchestrator mode naturally.
- Positive: Supports replay, benchmark, and regression.
- Positive: Avoids pseudo-agents for pure mechanics.
- Negative: Deterministic dice may feel less “truly random” unless carefully narrated.
- Negative: Worlds with inconsistent stat schemas need sensible fallback behavior.

## Alternatives considered

### A. Model dice as specialists

Rejected.

Dice and checks are bounded mechanics, not domain personas.

### B. Expose open Python as a tool

Rejected.

This breaks the RP/tool boundary and introduces unnecessary risk.

### C. Extend only `resolve_action`

Deferred.

`resolve_action` may absorb some of this later, but `roll_check` is the clearer minimum gameplay primitive.

