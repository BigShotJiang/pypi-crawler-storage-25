# ADR 0006: Agent Spec and Permissions

- Status: Proposed
- Date: 2026-01-29
- Related: ROADMAP M2-T0~T6, REQUIREMENTS R1, ARCHITECTURE (Agent layer, Plan→Diff→Apply, Storage permissions)

## Context
M2 要落地“子代理系统”，但必须避免 agent 直接、无约束地写入文件导致存档损坏。
因此需要：
- agent 的可版本化定义（可提交到 git）
- 明确的读写权限边界（owned paths）
- 标准化的运行日志，支撑审计与 rerun

## Decision
1) **Agent 作为项目资产**：放在 `agents/<agent_id>/`，便于版本控制与协作。
2) **权限模型**：agent.json 中定义 `permissions`：
   - `read_globs`: 允许读取的路径（M2 可先 soft enforce）
   - `write_globs`: 允许写入的路径（M2 必须 hard enforce）
   - `deny_globs`: 明确禁止（默认包含 `.neonrp/**`）
3) **运行态日志**：放在 `.neonrp/logs/agents/<run_id>/`，记录 input/proposal/diff/validation/apply。

## Consequences
- Positive: agent 能被安全地集成到主流程；越权与坏写入可被拦截并给出可修复错误；日志可用于重放与调试。
- Negative: 引入 glob/路径规范化与 staging 的实现复杂度；需要较完整的测试覆盖。
- Neutral: read 权限硬隔离可在 M2.5/M3 强化，不阻塞 M2 的写入安全。

## Alternatives considered
- **把 agent 放在 `.neonrp/agents/`**：
  - 优点：运行态与定义放一起。
  - 缺点：更像缓存，不利于 git 协作；默认应避免让 agent 直接改 `.neonrp/`。
- **不做权限边界**：
  - 优点：实现快。
  - 缺点：会直接破坏 NeonRP 的“可控/可审计/稳定”胜利条件；不可接受。
