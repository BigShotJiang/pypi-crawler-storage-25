# ADR 0007: Proposal Format and Plan→Diff→Apply

- Status: Proposed
- Date: 2026-01-29
- Related: ROADMAP M2-T2~T4, REQUIREMENTS R1, ARCHITECTURE (Plan→Diff→Apply)

## Context
M2 的目标是让 agent 产出“结构化提案”，并由引擎执行可审计的写入流程。
如果提案格式不稳定：
- diff/preview 难以标准化
- apply 难以做权限与校验
- 日志与 rerun 无法可靠复现

## Decision
1) **proposal.json 作为唯一执行输入**：apply 只接受 proposal，不接受自由文本。
2) **版本化 schema**：`proposal_version = "0.1"`，未来通过版本迁移。
3) **ops 为文件级操作**：M2 以 `upsert_text/delete` 为主，不做 AST patch，降低 apply 复杂度。
4) **写入前强制 validate**：对 staging 结果执行 M1 的 validate（结构+约束），通过后才写入真实 world。

## Consequences
- Positive: 可审计、可测试、可重放；diff 输出稳定；权限边界易实现。
- Negative: 文件级替换可能导致冲突更粗粒度；大文件 diff 更长。
- Neutral: M3+ 可增加 JSON patch/AST patch 以减少冲突，但不改变 proposal 的“版本化 + 可验证”原则。

## Alternatives considered
- **直接让 agent 输出 unified diff**：
  - 优点：看起来接近 git workflow。
  - 缺点：解析与安全风险高；难以做权限与 schema 校验。
- **直接让 agent 调用写文件工具**：
  - 优点：少一层格式。
  - 缺点：破坏 Plan→Diff→Apply 的审计链，容易污染存档。
