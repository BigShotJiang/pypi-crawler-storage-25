# ADR {N}: {Title}

- Status: Proposed | Accepted | Deprecated
- Date: YYYY-MM-DD
- Related: (links)

## Context
What problem are we solving? What constraints matter?

## Decision
What did we decide?

## Consequences
- Positive:
- Negative:
- Neutral/Tradeoffs:

## Alternatives considered
List the main alternatives and why we didn't choose them.

## Notes
Anything else future maintainers should know.
