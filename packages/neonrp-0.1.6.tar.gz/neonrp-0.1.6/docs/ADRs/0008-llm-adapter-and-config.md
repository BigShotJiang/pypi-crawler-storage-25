# ADR 0008: LLM Adapter and Project Config

- Status: Proposed
- Date: 2026-01-30
- Related: ROADMAP M3-T1~T5, REQUIREMENTS R1/R2, ARCHITECTURE (Agent layer)

## Context
M2 implemented proposal/diff/apply without invoking an LLM. M3 needs end-to-end execution: agent run uses an LLM to produce a proposal.
To keep tests deterministic and to support multiple providers, NeonRP needs a small adapter layer plus a project config file.

## Decision
1) Add optional project config file: `.neonrp/config.json`.
2) Introduce an LLM adapter interface used by `agent run`.
3) Provide a deterministic `stub` provider for tests and CI (no network).
4) Secrets (API keys) are sourced from environment variables, never stored in repo.

## Consequences
- Positive: reproducible tests; provider swap without rewriting core; easier debugging via logged I/O.
- Negative: extra abstraction layer to maintain.
- Neutral: provider-specific features (seed/tool calling) are optional and can be implemented incrementally.

## Alternatives considered
- Hardcode a single provider: rejected (locks the project and breaks offline tests).
- Store secrets in config: rejected (security risk).
