# ADR 0020: Game Rules Engine and Entity Schema Extension

- **Status**: Accepted
- **Created**: 2026-02-02
- **Context**: M7-T0

## Context

NeonRP's entity schema (`game_entity.schema.json`) is completely generic — only `id`, `kind`, `name` are required, with `additionalProperties: true`. All game mechanics (HP, gold, inventory, combat) are entirely LLM-improvised, leading to inconsistency. There is no validation of game logic constraints (e.g., HP going negative, gold going negative, inventory items lacking required fields).

## Decision

### Per-Kind Schema Extension

Extend `game_entity.schema.json` with JSON Schema `if/then` conditional blocks keyed on `kind`:

```json
{
  "allOf": [
    {
      "if": { "properties": { "kind": { "const": "character" } } },
      "then": {
        "properties": {
          "hp": { "type": "integer", "minimum": 0 },
          "max_hp": { "type": "integer", "minimum": 1 },
          "gold": { "type": "integer", "minimum": 0 },
          "inventory": { "type": "array", "items": { "type": "object", "required": ["id", "name"] } },
          "location": { "type": "string" },
          "level": { "type": "integer", "minimum": 1 }
        }
      }
    },
    {
      "if": { "properties": { "kind": { "const": "item" } } },
      "then": {
        "properties": {
          "value": { "type": "integer", "minimum": 0 },
          "weight": { "type": "number", "minimum": 0 },
          "quantity": { "type": "integer", "minimum": 0 },
          "effects": { "type": "array" }
        }
      }
    },
    {
      "if": { "properties": { "kind": { "const": "location" } } },
      "then": {
        "properties": {
          "connections": { "type": "array", "items": { "type": "string" } },
          "npcs": { "type": "array", "items": { "type": "string" } },
          "items_available": { "type": "array" }
        }
      }
    }
  ]
}
```

**Important**: Per-kind fields are **RECOMMENDED**, not required. This maintains backward compatibility — existing entities without per-kind fields still validate. The schema only enforces **type and range** when the fields are present (e.g., `hp` must be integer >= 0 if provided).

### Post-Staging Game Rules Validation

New module `core/rules.py` with a validation hook called after JSON schema validation in `apply_proposal()`:

```python
@dataclass
class RuleViolation:
    rule: str       # e.g., "hp_non_negative"
    path: str       # entity file path
    message: str    # human-readable error
    suggestion: str # how to fix

def validate_game_rules(staged_world: Path, proposal: Proposal) -> list[RuleViolation]
```

**MVP rules** (hardcoded, not configurable):
1. `hp_non_negative`: If proposal modifies a character entity, check `hp >= 0` in staged result
2. `gold_non_negative`: If proposal modifies a character entity, check `gold >= 0`
3. `inventory_item_valid`: If inventory items present, each must have `id` and `name`
4. `location_exists`: If character's `location` field is set, target location entity file should exist

Rules check the **staged state** (after ops applied), not the proposal ops themselves. This means rules validate the end result, which is more reliable than trying to infer intent from ops.

**Integration point**: `apply.py` after line 136 (after schema validation, before atomic commit). Violations produce `ApplyResult(success=False, ...)` with the same format as schema validation errors.

### resolve_action Skill

New agent skill for mechanical outcome resolution:

```python
"resolve_action": {
    "name": "resolve_action",
    "description": "Resolve a game action and get the mechanical result",
    "parameters": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["damage", "heal", "buy", "sell", "move"]},
            "actor": {"type": "string"},
            "target": {"type": "string"},
            "amount": {"type": "integer"},
            "item_id": {"type": "string"}
        },
        "required": ["action", "actor"]
    }
}
```

Returns structured results (e.g., `{"new_hp": 30, "defeated": false}`) that the agent uses to build correct proposal ops. This separates "what happens mechanically" from "how the LLM narrates it."

## Consequences

- Game state consistency improves (schema + rules catch invalid mutations)
- Backward compatible (old entities still validate)
- `resolve_action` gives agents deterministic mechanical outcomes
- Rules are hardcoded in M7; future milestones can make them configurable
- The game template (`game new`) produces richer starter entities

## Alternatives Considered

1. **Required per-kind fields**: Would break all existing worlds. Deferred to M8+.
2. **Configurable rules DSL**: Over-engineering for M7; hardcoded rules are sufficient for MVP.
3. **Rules as agent skills only (no validation hook)**: Agent could ignore skill results; validation hook is the enforcement mechanism.
4. **Per-kind schema as separate files**: JSON Schema `if/then` keeps everything in one file, simpler than schema registry.

