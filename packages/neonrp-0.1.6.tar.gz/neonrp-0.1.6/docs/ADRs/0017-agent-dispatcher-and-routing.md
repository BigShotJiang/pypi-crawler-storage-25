# ADR 0017: Agent Dispatcher and Routing

- Status: Accepted
- Date: 2026-02-02
- Related: ADR-0006 (Agent Spec), ADR-0015 (Agentic Loop), M6 Task Cards (M6-T3)

## Context

用户有多个子代理（城镇管理员、商店管理员、地下城管理员）。在 Claude Code 中主模型自主判断调用谁；NeonRP 中用户需手动 `agent run <id>`，打破沉浸感。

需要一个 dispatcher 层：用户输入自然语言 → 自动选择最合适的 agent → 执行 agentic loop。

关键设计问题：
1. 路由策略——规则匹配 vs LLM 分类 vs orchestrator？
2. Agent spec 需要哪些新字段？
3. `neonrp run` vs `neonrp agent run` 的职责边界

## Decision

### 1. MVP 路由策略：渐进式复杂度（规则优先）

```
1. 单 agent 场景 → 直接使用，无需路由
2. 多 agent 场景：
   a. triggers（正则列表）—— 精确命中直接使用
   b. tags + description 关键词匹配（简单 tf 评分）
   c. 平分时用 priority（默认 0）排序
   d. 仍无法区分 → fallback 到 priority 最高的 agent
```

选择规则匹配而非 LLM 分类的理由：
- 确定性强——同输入同输出，可测试
- 零额外 token 消耗
- 延迟低——无需额外 LLM 调用
- 保留扩展点：`--route llm` 开关，后期可引入 LLM 意图分类

### 2. AgentSpec 扩展字段

```python
AgentSpec(
    id, name, description, version,
    priority: int = 0,         # 高 = 更可能被选中
    tags: list[str] = [],      # 语义标签（匹配用）
    triggers: list[str] = [],  # 正则模式（精确命中）
    system_prompt, context_limit, permissions
)
```

`triggers` 为可选高级配置。绝大多数用户只需设置 `tags` + `description` 即可工作。

### 3. `neonrp run` vs `neonrp agent run`

| | `neonrp run "<text>"` | `neonrp agent run <id> --query "..."` |
|---|---|---|
| 入口 | 游戏主入口 | 专家/调试模式 |
| 路由 | dispatcher 自动选择 agent | 指定 agent，跳过路由 |
| Agentic | 默认启用 | 可选 `--agentic` |
| 目标用户 | 玩家 | 开发者/调试 |

两者共享 `core.agent_runner.run_agent()` / `run_agent_agentic()`。

### 4. DispatchResult

```python
DispatchResult(
    success: bool,
    agent_id: str | None,
    run_result: AgentRunResult | None,
    matched_trigger: str | None,    # 命中的 trigger
    matched_tags: list[str],        # 命中的 tags
    error: str | None,
    candidates: list[str],          # 所有匹配的 agent
)
```

路由过程可审计——日志记录选中的 agent 和匹配原因。

## Consequences

- Positive: 用户只需输入自然语言，无需知道 agent ID
- Positive: 单 agent 场景零配置即可工作
- Positive: 路由稳定、可测试、可审计
- Negative: 关键词匹配在复杂语义场景不如 LLM 分类（如"我想去那个昨天发现的洞穴"可能匹配失败）
- Tradeoff: 规则匹配 vs LLM 分类是速度/成本 vs 智能的权衡

## Alternatives considered

1. **LLM 意图分类**：每次 dispatch 先做一次轻量 LLM 调用。优点：理解自然语言意图。缺点：增加延迟和 token 成本，MVP 阶段 over-engineering。保留为 `--route llm` 扩展点。
2. **Orchestrator 模式**：主 agent 统一接收所有输入，自行决定调用子 agent。最接近 Claude Code 体验，但增加架构复杂度和 token 消耗。推迟到 M7+。
3. **Embedding 相似度匹配**：用向量检索匹配 agent。需要 embedding 模型依赖，MVP 不值得。

## Notes

- `commands/run.py` 从 M0 echo placeholder 升级为完整的 dispatch → agentic loop → diff/validate/apply 管线
- Trigger 使用 Python `re` 标准库，支持完整正则语法
- Agent spec 向后兼容：无 triggers/tags/priority 字段的 agent 使用默认值正常工作
