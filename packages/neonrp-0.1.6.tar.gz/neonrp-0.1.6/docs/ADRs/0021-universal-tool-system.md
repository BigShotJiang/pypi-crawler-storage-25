# ADR 0021: Universal Tool System

- Status: Accepted
- Date: 2026-02-02
- Related: ADR 0009 (Skill Tool Registry), ADR 0015 (Agentic Loop)

## Context

M7 agents have only 6 skills: `read_file`, `find`, `read_context`, `list_entities`, `resolve_action`, `submit_proposal`. This is insufficient for Claude Code-level RP experiences where agents need to:
- Write auxiliary files directly (lore, notes, journals)
- Edit existing files with precision
- Discover project structure via file pattern matching
- Search file contents for specific information
- Ask the player structured questions with choices

The reference project (`llm-rpg-starter-sample`) agents use `Read, Write, Edit, Glob, Grep, Task, AskUserQuestion` — a superset of NeonRP's capabilities.

The key tension is between NeonRP's safety-first proposal pipeline (`submit_proposal → staging → validate → apply`) and the need for flexible direct file manipulation.

## Decision

### 1. Dual-Mode Write System

Introduce **two write paths** controlled by per-agent permissions:

- **Proposal mode** (default): Changes to `game/` game state go through `submit_proposal → staging → validate → apply`. This preserves atomicity, validation, and auditability.
- **Direct mode**: Auxiliary files (lore, notes, journals) can be written directly via `write_file` / `edit_file` skills, controlled by `permissions.direct_write_globs` in `agent.json`.

`REQUIRED_DENY_GLOBS` (`.neonrp/**`, `agents/**`) are always enforced, even for direct writes.

### 2. New Skills

| Skill | Purpose | Write Mode |
|-------|---------|------------|
| `write_file(path, content)` | Create/overwrite a file | Direct (if path in `direct_write_globs`) |
| `edit_file(path, old_text, new_text)` | Exact string replacement in a file | Direct (if path in `direct_write_globs`) |
| `glob(pattern, path?)` | Find files matching glob pattern | Read-only |
| `grep(pattern, path?, glob?, max_results?)` | Search file contents with regex | Read-only |
| `ask_user(question, options?)` | Ask user a structured question | N/A (interactive) |

### 3. Permission Model Extension

`agent.json` `permissions` block gains a new field:
```json
{
  "permissions": {
    "read_globs": ["**"],
    "write_globs": ["game/**"],
    "deny_globs": [],
    "direct_write_globs": ["lore/**", "notes/**", "journal/**"]
  }
}
```

- `direct_write_globs`: Paths matching these globs can be written directly via `write_file`/`edit_file`.
- Paths NOT in `direct_write_globs` trigger an error message guiding the agent to use `submit_proposal`.
- `REQUIRED_DENY_GLOBS` always override `direct_write_globs`.

### 4. edit_file Safety

- Reads current file content, counts occurrences of `old_text`
- Exactly 1 occurrence → replace and write atomically
- 0 occurrences → error "Text not found in file"
- \>1 occurrences → error "Text found N times, must be unique for safe replacement"
- No regex support (exact match only, like Claude Code's Edit tool)

### 5. ask_user Protocol

`ask_user` returns a sentinel result that the agent runner detects:
```python
SkillResult(success=True, data={"type": "pending_user_input", "question": "...", "options": [...]})
```

The agent runner pauses the agentic loop, invokes an `on_ask_user` callback (provided by TUI or CLI), injects the user's response as a tool result message, and resumes the loop.

### 6. Search Result Bounds

- `glob`: Maximum 200 results
- `grep`: Maximum 50 results (configurable via `max_results`), lines truncated to 500 chars
- Both respect `read_globs` permissions (denied paths silently filtered)

## Consequences

- Positive: Agents gain Claude Code-level file manipulation capabilities
- Positive: Dual-mode preserves safety for game state while enabling flexibility for auxiliary files
- Positive: `ask_user` enables structured RPG interaction (action choices)
- Negative: Two write paths increase cognitive load for agent prompt design
- Negative: `ask_user` adds async complexity to the agent runner
- Tradeoff: Direct writes bypass validation/staging — acceptable for non-game-state files

## Alternatives considered

1. **All writes through proposal**: Safest, but too restrictive. Writing a journal entry shouldn't require schema validation.
2. **All writes direct**: Most flexible, but loses NeonRP's core safety guarantees for game state.
3. **Hybrid with auto-proposal**: `write_file` auto-generates a proposal. Rejected — adds latency and complexity without clear benefit for auxiliary files.

## Notes

- `write_file` and `edit_file` use `atomic_write_text()` (temp file + rename) for crash safety.
- Path traversal (`..`) is rejected in all new skills.
- All skill calls are audited to `.neonrp/logs/skills/<run_id>.jsonl` (existing infrastructure).
