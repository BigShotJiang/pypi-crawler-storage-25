# ADR 0025: MCP Tool Routing, Namespacing, and Permission Model

- Status: Accepted
- Date: 2026-02-10
- Related: ADR 0006 (Agent Spec and Permissions), ADR 0009 (Skill Tool Registry), ADR 0024 (MCP Integration Scope)

## Context

With MCP introduced in M11, NeonRP must dispatch tool calls from two sources:

1. Built-in tools (`SkillRegistry`)
2. MCP server tools (dynamic)

Without a unified routing contract, collisions, permission ambiguity, and inconsistent audit behavior are likely.

## Decision

1. Introduce a dedicated `ToolRouter` layer as the single dispatch entry.
   - Router decides builtin vs MCP target and executes through the proper backend.
2. Preserve `SkillRegistry` as builtin execution backend.
   - `ToolRouter` composes with `SkillRegistry`; it does not replace it.
3. Apply MCP tool namespacing:
   - Exposed tool names use `{server_name}__{tool_name}`.
   - Builtin names are unchanged.
4. Add MCP permission policy with defaults and overrides:
   - Server-level: `auto | confirm | deny`
   - Optional tool-level overrides under each server.
5. Enforce audit logging for MCP tool calls:
   - Record request/response, run_id, server, tool, and permission decision.
   - Default log location: `.neonrp/logs/mcp/<server>/<run_id>.jsonl`.
6. Reliability guardrails:
   - Per-call timeout default 30s (configurable).
   - Failed/unhealthy servers return actionable errors, without crashing host loop.

## Consequences

- Positive:
  - Uniform tool call path simplifies reasoning, testing, and observability.
  - Namespacing prevents collisions with built-in tools.
  - Security posture improves via explicit allow/confirm/deny controls.
- Negative:
  - Additional routing layer and config surface add implementation overhead.
  - `confirm` mode introduces UX flow complexity (especially in non-interactive runs).
- Neutral/Tradeoffs:
  - Server restarts and health checks are operational concerns but isolated in MCP pool/router modules.

## Alternatives considered

1. Inject MCP tools directly into `SkillRegistry`.
   - Rejected: blurs builtin/dynamic boundaries and complicates lifecycle handling.
2. No namespacing; rely on conflict detection only.
   - Rejected: conflict behavior becomes brittle and non-deterministic for prompts.
3. Single global MCP permission toggle.
   - Rejected: too coarse; does not satisfy mixed-trust server deployments.

## Notes

- Prompt/tool schema generation must show namespaced MCP tools as callable names.
- `/mcp` TUI and `neonrp mcp` CLI should reflect router/pool health status for debugging.
