# ADR 0018: LLM Streaming Contract

- Status: Accepted
- Date: 2026-02-02
- Related: ADR-0015 (Agentic Loop), M6 Task Cards (M6-T7)

## Context

等待完整 LLM 响应才显示结果，叙事体验不佳。RPG 场景中，逐字显示叙事输出能显著提升沉浸感和反馈速度。

M6-T7 在 LLM 层实现了 streaming 能力（`chat_stream()`），M6.5-T4 计划将其接入 TUI 渲染（可选，已 skip）。

关键设计问题：
1. Streaming 数据结构
2. 与 tool calling 的交互
3. 降级策略

## Decision

### 1. StreamChunk 数据结构

```python
StreamChunk(
    delta: str = "",                    # 本 chunk 的增量文本
    tool_calls: list[ToolCall] | None,  # 完整的 tool calls（仅 final chunk）
    finished: bool = False,             # True = stream 结束
    usage: dict = {},                   # token 用量（仅 final chunk）
    error: str | None = None,           # 错误信息
)
```

### 2. LLMAdapter Protocol 扩展

```python
def chat_stream(
    messages: list[Message],
    tools: list[dict] | None = None,
) -> Iterator[StreamChunk]
```

- Generator-based：调用者 `for chunk in adapter.chat_stream(...)` 消费
- Final chunk 有 `finished=True`，包含 usage 和可能的 tool_calls
- 非 streaming adapter 退化为 yield 单个 chunk

### 3. Streaming 与 tool calling 的交互

OpenAI API 在 streaming 模式下，tool calls 通过多个 chunk 的 `delta.tool_calls` 逐步积累（name、arguments 分段到达）。

`OpenAIAdapter.chat_stream()` 实现：
- 内部积累 tool_calls（name + arguments 拼接）
- Delta text 实时 yield
- Final chunk 包含完整 tool_calls 列表
- 调用者无需关心 tool call 积累细节

### 4. 降级策略

- Provider 不支持 streaming → `chat_stream()` 内部调用 `chat()`，将完整响应包装为单个 StreamChunk yield
- StubAdapter 的 `chat_stream()` 模拟分块输出（将 proposal text 按字符分割 yield）
- **功能正确性不依赖 streaming**——streaming 是纯体验优化

### 5. TUI 集成策略（M6.5-T4，已 skip）

计划但未实现：
- `agent_runner.run_agent_agentic()` 接受 `on_chunk` 回调
- 有回调时使用 `chat_stream()`，否则回退到 `chat()`
- TUI 通过 Textual worker + `call_from_thread` 增量更新 transcript
- Tool call 轮次不 streaming（或显示 "[using tools...]"）

## Consequences

- Positive: LLM 层 streaming 能力完整，TUI 接入无需改 LLM 代码
- Positive: Generator 接口简洁，调用者按需消费
- Positive: 降级透明——不支持 streaming 的场景自动回退
- Negative: TUI 实际接入推迟（M6.5-T4 skip），当前体验仍为一次性渲染
- Negative: Tool call 积累逻辑增加了 OpenAIAdapter 复杂度
- Tradeoff: Generator (同步) vs AsyncIterator (异步)——选择同步以保持 agent_runner 的同步架构简单

## Alternatives considered

1. **AsyncIterator**：`async def chat_stream() -> AsyncIterator[StreamChunk]`。优点：原生异步，与 Textual async 架构匹配。缺点：需要将 agent_runner 改为 async，影响面大。推迟。
2. **SSE (Server-Sent Events) 格式**：标准化 streaming 格式。缺点：NeonRP 是本地 CLI，不是 web 服务，SSE 增加不必要的序列化。
3. **Callback-based**：`on_token(callback)` 而非 generator。缺点：callback hell，不如 generator 直观。M6.5-T4 计划的 `on_chunk` 回调是 agent_runner 层的适配，LLM 层仍使用 generator。

## Notes

- `chat_stream()` 与 `chat()` 并存于 LLMAdapter Protocol
- OpenAI streaming 使用 `stream=True` 参数，返回的 response 是 iterable
- M6-T8 review 发现并修复了 streaming fallback 丢失 tool calls 的 bug（llm_openai.py:357）
