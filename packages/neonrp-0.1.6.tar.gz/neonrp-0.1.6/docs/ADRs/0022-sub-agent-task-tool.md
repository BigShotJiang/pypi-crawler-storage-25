# ADR 0022: Sub-Agent Task Tool — 2-Layer Depth + Resume

- Status: Accepted
- Date: 2026-02-02
- Related: ADR 0006 (Agent Spec), ADR 0015 (Agentic Loop), ADR 0017 (Dispatcher)

## Context

The reference project (`llm-rpg-starter-sample`) uses 10 specialized sub-agents orchestrated by a main controller via Claude Code's `Task` tool. Each sub-agent runs in an isolated context, processes its domain (combat, shop, dungeon, etc.), and returns structured results.

NeonRP's dispatcher (M6) only routes to a single agent per query. There is no mechanism for:
- An orchestrator agent to delegate tasks to specialist agents
- Agents to run other agents as sub-tasks
- Results from multiple agents to be composed

This is the single biggest architectural gap preventing Claude Code-level RP experiences.

## Decision

### 1. task Skill

Add a `task` skill that enables an agent to spawn a sub-agent:

```json
{
  "name": "task",
  "description": "Delegate a task to a sub-agent",
  "parameters": {
    "properties": {
      "agent_id": {"type": "string"},
      "prompt": {"type": "string"},
      "context": {"type": "string"},
      "resume_run_id": {"type": "string"}
    },
    "required": ["agent_id", "prompt"]
  }
}
```

### 2. Two-Layer Depth Limit

Strict 2-layer maximum:
```
Layer 0: User → Orchestrator (can call task)
Layer 1: Orchestrator → Sub-agent (CANNOT call task)
```

Implementation:
- `run_agent_agentic()` gains `current_depth: int = 0` parameter
- When `current_depth >= 1`, the `task` tool is **excluded from tool_schemas** entirely — sub-agents never see it as an option
- This is simpler and more reliable than depth checking at execution time
- `max_sub_agent_depth` is configurable in `config.json` (default: 2)

### 3. Sub-Agent Isolation

Each sub-agent gets:
- Its own `SkillRegistry` instance (constructed from its own `agent.json` permissions)
- Its own message history (no context bleed from parent)
- Its own audit log (separate `run_id`)
- Its own LLM adapter (may differ from parent, see ADR 0023)

The sub-agent result is serialized to JSON and returned as a tool result to the parent:
```json
{
  "success": true,
  "run_id": "narrator_20260202_...",
  "agent_id": "narrator",
  "rationale": "Wrote the chapter introduction",
  "applied_paths": ["lore/chapter1.md"],
  "error": null,
  "can_resume": false
}
```

### 4. Resume Mechanism

Sub-agents may be suspended (ask_user pending, budget exhausted, etc.). Their state is saved for later resumption.

**SubAgentState** (serialized to `.neonrp/agent_states/<run_id>.json`):
```python
@dataclass
class SubAgentState:
    run_id: str
    agent_id: str
    messages: list[dict]       # Serialized message history
    turn: int                  # Current turn number
    pending_user_input: dict | None  # If suspended on ask_user
    skill_calls: list[dict]    # Audit log entries
```

**Resume flow**:
1. Parent calls `task(agent_id="narrator", prompt="continue", resume_run_id="narrator_20260202_abc")`
2. Agent runner loads `SubAgentState` from disk
3. Rebuilds messages list, creates new adapter (adapters are not serializable)
4. Continues agentic loop from saved turn number
5. If `pending_user_input` exists, injects the new prompt as the user's answer

**State lifecycle**:
- Created: when sub-agent completes (success or suspension)
- Consumed: when resume is called
- Cleaned: rotation policy (keep last 20 per agent)

### 5. Error Handling

Sub-agent failures are contained:
- Sub-agent exception → caught, returned as `{"success": false, "error": "..."}`
- Sub-agent timeout (max_turns) → returned as error result
- Sub-agent not found → validation error before execution
- Parent agent receives the error as a tool result and can decide how to proceed

### 6. Execution Model

`task` is handled as a special case in `_execute_tool()`, similar to `submit_proposal`:
- It does NOT go through `SkillRegistry.invoke()`
- It recursively calls `run_agent_agentic()` with `current_depth + 1`
- Sub-agent's `on_ask_user` callback is inherited from the parent (user questions bubble up)

## Consequences

- Positive: Enables orchestrator → specialist agent pattern (core of Claude Code RP)
- Positive: 2-layer limit prevents runaway recursion while enabling the key use case
- Positive: Resume enables long-running sub-agent workflows
- Positive: Sub-agent isolation prevents context pollution
- Negative: Recursive `run_agent_agentic()` increases stack depth and memory
- Negative: Resume state serialization adds disk I/O and complexity
- Tradeoff: 2-layer limit means no agent A → agent B → agent C chains (acceptable for RPG use case)

## Alternatives considered

1. **Unlimited depth**: Too risky for recursion/resource exhaustion. Agent A → B → A loops possible.
2. **3-layer depth**: Overkill for RPG. The orchestrator + specialist pattern only needs 2 layers.
3. **No resume**: Simpler, but sub-agents that need user input would fail completely.
4. **Flat dispatch only (no nesting)**: Keep the current dispatcher model. Rejected — cannot achieve the orchestrator pattern that makes Claude Code RP work.

## Notes

- Sub-agent `run_id` includes parent `run_id` prefix for traceability: `parent_<run_id>_sub_<agent_id>_<timestamp>`
- Sub-agent proposals (if any) can be applied within the sub-agent's agentic loop if `do_apply=True`
- The orchestrator pattern is purely a prompt engineering concern — no special code for "orchestrator" agents. Any agent at depth 0 can use `task`.
