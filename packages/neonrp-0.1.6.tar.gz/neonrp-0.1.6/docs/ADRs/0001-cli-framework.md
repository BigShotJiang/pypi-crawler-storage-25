# ADR 0001: CLI Framework

- Status: Proposed
- Date: 2026-01-29
- Related: ROADMAP T0, REQUIREMENTS R0

## Context
NeonRP CLI 需要一个 Python CLI 框架来实现命令行交互。M0 要求 `neonrp --help`、`init`、`run`、`save`、`load`、`undo`、`redo`、`branch` 等子命令，后续里程碑还会持续新增命令（agent、find、sandbox 等）。

选型需考虑：
- 命令注册的可扩展性（M3 要求 command registry）
- 代码的显式性和可审计性（项目核心原则）
- 社区成熟度和维护状态

## Decision
使用 **click**。

理由：
- 成熟稳定，社区广泛使用
- 装饰器风格的命令注册，显式且可读
- 原生支持子命令分组（`@click.group()`），便于后续扩展 command registry
- 不依赖运行时类型推断，行为可预测

## Consequences
- Positive: 显式注册、文档丰富、生态成熟
- Negative: 比 typer 稍显冗长（需要手写 `@click.option` 等装饰器）
- Neutral: 与 argparse 相比，引入一个第三方依赖

## Alternatives considered
- **typer**: 基于 click 的封装，通过类型注解自动推导参数。优势是更少样板代码，劣势是隐式行为较多，调试时不够透明。
- **argparse**: 标准库，零依赖。但子命令管理冗长，代码可读性差，不适合频繁扩展命令的项目。

## Notes
如果后续发现 click 的冗长成为显著负担，可评估迁移到 typer（底层仍是 click，迁移成本低）。
