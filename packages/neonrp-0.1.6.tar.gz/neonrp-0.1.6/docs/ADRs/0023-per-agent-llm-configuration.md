# ADR 0023: Per-Agent LLM Configuration and Provider Registry

- Status: Accepted
- Date: 2026-02-02
- Related: ADR 0008 (LLM Adapter and Config), ADR 0022 (Sub-Agent Task Tool)

## Context

NeonRP currently uses a single global LLM configuration (`config.json` → `llm.provider` + `llm.model`). All agents share the same provider and model. This is limiting because:

- An orchestrator may need a strong model (GPT-4o) for routing decisions, while a narrator can use a fast model (GPT-4o-mini) for creative writing
- Local models (Ollama, vLLM) may be preferred for some agents to reduce cost
- Different agents may need different temperature settings (low for combat mechanics, high for narrative)
- Users want OpenCode-style flexibility: custom endpoints, arbitrary OpenAI-compatible APIs

## Decision

### 1. Provider Registry in config.json

`config.json` gains a `providers` dictionary of named LLM configurations:

```json
{
  "llm": {
    "provider": "openai",
    "model": "gpt-4o-mini",
    "temperature": 0.7,
    "max_output_tokens": 4096
  },
  "providers": {
    "fast": {
      "provider": "openai",
      "model": "gpt-4o-mini",
      "temperature": 0.7
    },
    "strong": {
      "provider": "openai",
      "model": "gpt-4o",
      "temperature": 0.5,
      "max_output_tokens": 8192
    },
    "local": {
      "provider": "openai",
      "model": "llama3",
      "base_url": "http://localhost:11434/v1",
      "api_key_env": "OLLAMA_API_KEY"
    },
    "anthropic": {
      "provider": "openai",
      "model": "claude-3-5-sonnet-20241022",
      "base_url": "https://api.anthropic.com/v1",
      "api_key_env": "ANTHROPIC_API_KEY"
    }
  }
}
```

All providers use the OpenAI-compatible adapter (`OpenAIAdapter`) with custom `base_url` and `api_key_env`. No need for separate adapter implementations — the OpenAI SDK handles any compatible endpoint.

### 2. Per-Agent LLM Configuration in agent.json

`agent.json` gains an optional `llm` block:

**Option A — Reference a named provider:**
```json
{
  "id": "narrator",
  "llm": {
    "provider_ref": "strong"
  }
}
```

**Option B — Inline configuration:**
```json
{
  "id": "combat",
  "llm": {
    "provider": "openai",
    "model": "gpt-4o-mini",
    "temperature": 0.3
  }
}
```

**Option C — Reference with overrides:**
```json
{
  "id": "narrator",
  "llm": {
    "provider_ref": "strong",
    "temperature": 0.9
  }
}
```

### 3. Resolution Priority (highest to lowest)

1. **CLI `--provider` flag**: Always wins (for debugging/testing)
2. **Agent inline `llm` block**: Agent-specific full config
3. **Agent `llm.provider_ref`**: Resolved from `config.json` `providers` dict, with optional field overrides
4. **Global `config.json` `llm`**: Default fallback

### 4. ProviderConfig Dataclass

```python
@dataclass
class ProviderConfig:
    provider: str = "openai"      # Adapter type (always "openai" for now)
    model: str = ""               # Model name
    base_url: str | None = None   # Custom API endpoint
    api_key_env: str | None = None  # Env var name for API key
    temperature: float = 0.7
    max_tokens: int = 4096
    max_retries: int = 3
    extra_kwargs: dict | None = None  # top_p, response_format, etc.
```

### 5. resolve_provider() Function

```python
def resolve_provider(
    config: ProjectConfig,
    agent_data: dict,
    cli_provider: str | None = None,
) -> ProviderConfig:
```

This function implements the priority chain and returns a fully resolved `ProviderConfig`.

### 6. get_adapter_from_config() Factory

```python
def get_adapter_from_config(provider_config: ProviderConfig) -> LLMAdapter:
```

Creates an `OpenAIAdapter` from a `ProviderConfig`. The existing `get_adapter(provider_name)` is kept for backward compatibility.

## Consequences

- Positive: Each agent can use the optimal model for its role
- Positive: Supports any OpenAI-compatible endpoint (OpenAI, Anthropic via proxy, Ollama, vLLM, etc.)
- Positive: Named providers reduce config duplication
- Positive: Backward compatible — agents without `llm` block use global config
- Negative: Three levels of configuration (global, provider registry, agent inline) add complexity
- Negative: Misconfigured `provider_ref` produces runtime errors
- Tradeoff: Only OpenAI-compatible adapters supported. Native Anthropic/Bedrock adapters deferred.

## Alternatives considered

1. **Per-agent provider only (no registry)**: Each agent has full inline config. Leads to massive duplication when multiple agents share the same provider.
2. **Environment-variable only**: No config file, everything via env vars. Too rigid and hard to manage.
3. **Native multi-provider adapters**: Separate `AnthropicAdapter`, `OllamaAdapter`, etc. Overkill — all modern providers offer OpenAI-compatible endpoints.

## Notes

- `api_key_env` defaults to `"{PROVIDER}_API_KEY"` if not specified (e.g., `OPENAI_API_KEY`)
- `NEONRP_LLM_API_KEY` is a universal fallback for all providers
- The `glm` provider shorthand is preserved for backward compatibility but internally creates an `OpenAIAdapter` with GLM defaults
- Sub-agents (ADR 0022) resolve their own LLM config independently — an orchestrator using GPT-4o can delegate to a narrator using GPT-4o-mini
