# ADR 0010: SillyTavern Character Card Import Mapping

- Status: Proposed
- Date: 2026-01-30
- Related: ROADMAP M3-T6, REQUIREMENTS R2, ARCHITECTURE (world entity conventions, validation)

## Context
Users want a one-command import path from SillyTavern character cards to NeonRP world entities.
SillyTavern card formats vary (JSON exports, PNG-embedded metadata), so NeonRP needs a robust but minimal mapping and a clear storage strategy.

## Decision
1) M3 guarantees support for JSON character card exports.
2) PNG extraction is best-effort and may be deferred if format drift makes it unreliable.
3) Imported characters are stored as:
   - `game/character/<id>.json` (kind=`character`)
4) Raw imported payload is preserved (for audit/debug) either:
   - embedded under `meta.raw` OR
   - stored as sidecar `game/character/<id>.raw.json` (final choice in implementation).
5) ID is user-specified via `--id` or derived from name (kebab-case) with conflict resolution.

## Consequences
- Positive: import is deterministic and compatible with validation/indexing.
- Negative: PNG import may require ongoing maintenance.
- Neutral: richer mapping (persona fields, examples, lorebook links) can be added later without breaking the minimal schema.

## Alternatives considered
- Only support PNG: rejected (too brittle).
- Drop raw payload: rejected (hurts traceability).
