# ADR 0024: MCP Integration Scope and Compatibility Baseline

- Status: Accepted
- Date: 2026-02-10
- Related: ADR 0008 (LLM Adapter and Config), ADR 0009 (Skill Tool Registry), ADR 0022 (Sub-Agent Task Tool)

## Context

NeonRP currently exposes tools via built-in `SkillRegistry` only. This limits ecosystem reuse and external capability integration (image generation, remote retrieval, custom services).  
At the same time, M10.1 established a stable TUI/conversation loop; introducing MCP must not regress existing behavior.

The M11 target is to add MCP incrementally while preserving default UX and compatibility.

## Decision

1. Adopt MCP as an additive capability in M11, not a replacement of built-in skills.
2. Use the official Python `mcp` SDK instead of implementing JSON-RPC/transport manually.
3. Scope M11 to **Tools-first**:
   - Required in M11: MCP Tools (list/call), stdio transport first.
   - Optional/deferred: Resources, Prompts, Sampling (post-M11).
4. Keep backward compatibility strict:
   - If no `mcp_servers` configured, behavior remains equivalent to M10.1.
   - Existing commands, prompts, and built-in tools remain valid.
5. Configuration model:
   - Add `mcp_servers` section to config.
   - Support project/user config merge via existing config policy.

## Consequences

- Positive:
  - Reuse broad MCP ecosystem with minimal NeonRP-specific glue code.
  - Keeps core loop stable while expanding capability surface.
  - Lower maintenance cost by relying on SDK for protocol details.
- Negative:
  - Adds external dependency and lifecycle complexity (server processes, connectivity).
  - Requires careful observability for failures/timeouts.
- Neutral/Tradeoffs:
  - Resources/Prompts remain out-of-scope in M11 to reduce risk and timeline.

## Alternatives considered

1. Build custom plugin protocol.
   - Rejected: reinvents ecosystem standards, no interoperability.
2. Replace SkillRegistry entirely with MCP in one milestone.
   - Rejected: high migration risk and backward compatibility breakage.
3. Implement MCP protocol manually.
   - Rejected: unnecessary complexity and long-term maintenance burden.

## Notes

- M11 task baseline is documented in `docs/M11_TASK_CARDS.md`.
- Follow-up ADRs can ratify post-M11 decisions (e.g., Resources, remote auth, agent-level MCP allowlists).
