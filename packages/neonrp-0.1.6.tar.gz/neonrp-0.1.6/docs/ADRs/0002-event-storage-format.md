# ADR 0002: Event Storage Format

- Status: Proposed
- Date: 2026-01-29
- Related: ROADMAP T2, REQUIREMENTS R0, ARCHITECTURE (events/)

## Context
NeonRP 的事件日志是 append-only 的核心数据结构，用于记录每回合的输入、输出、变更 diff 和校验结果。ARCHITECTURE.md 中列出了两种候选格式但未做决定：
- NDJSON（Newline-Delimited JSON，单文件）
- Per-event files（每个事件一个 JSON 文件）

选型需考虑：
- Append-only 语义的实现难度
- 读取和遍历的性能
- 崩溃恢复的简易性
- 后续 replay 功能（M4）的需求

## Decision
使用 **NDJSON**（每个分支一个事件文件）。

文件路径：`.neonrp/events/<branch_name>.ndjson`

每行一个 JSON 对象，格式示例：
```json
{"seq": 0, "type": "init", "ts": "ISO-8601", "actor": "system", "data": {}}
{"seq": 1, "type": "player_input", "ts": "ISO-8601", "actor": "player", "data": {"text": "look around"}}
{"seq": 2, "type": "turn_result", "ts": "ISO-8601", "actor": "engine", "data": {"diff": [], "output": "..."}}
```

必含字段：
- `seq`: 单调递增序号
- `type`: 事件类型
- `ts`: ISO-8601 时间戳
- `actor`: 事件来源（player / engine / system，后续扩展为 agent id）
- `data`: 事件负载

## Consequences
- Positive: 追加写入只需 `open("a")` + `write(json + "\n")`，实现简单；逐行解析，内存友好；单文件便于备份和传输
- Negative: 单文件在极大量事件时可能变慢（但 M0 阶段不构成问题）；并发写入需要文件锁（M0 无并发场景）
- Neutral: 需要按分支分文件，分支创建时从父分支复制事件文件

## Alternatives considered
- **Per-event files**: 每个事件一个 `events/0001.json` 文件。优势是单事件操作简单，劣势是大量小文件造成文件系统压力，遍历需要排序文件名，append-only 语义反而更难保证。

## Notes
- `actor` 字段为 M2（子代理系统）预留，M0 阶段仅使用 `player` / `engine` / `system`。
- 如果后续事件量级达到性能瓶颈，可考虑分段文件（按 save point 切割）或迁移到 SQLite WAL。
