# ADR 0014: TUI Interaction Model and Keybindings

- Status: Accepted
- Date: 2026-01-31
- Related: ROADMAP M5 (TUI), REQUIREMENTS (keyboard-first), ARCHITECTURE (Plan→Diff→Apply)

## Context
M5 的目标是提供接近 Claude Code / OpenCode 的终端体验：command palette 驱动、少量稳定快捷键、默认安全（preview-first）。
如果交互模型不固定，实现期会反复改键位/模式，导致 UX 不一致、测试不稳定。

## Decision
1) 使用 **single input model**：
   - 默认输入为自然语言（触发 agent run）
   - 以 `:` 开头的输入视为命令（例如 `:validate`, `:index build`）
2) command palette 为主入口：
   - `Ctrl+K` / `Ctrl+P` 打开
   - 支持模糊搜索与动作分组（Agent/World/Index/Sandbox/Replay/Logs）
3) 最小快捷键集合（可配置，但要稳定）：
   - `Ctrl+K`: palette
   - `Tab`: focus cycle
   - `Ctrl+Enter`: send (agent run)
   - `a`: apply (only when diff is focused and proposal is valid)
   - `u`: undo
   - `s`: save
   - `q`: quit (with confirmation if there is a pending proposal)
4) preview-first apply：
   - 任何会写 world 的操作，在 TUI 中默认先展示 diff/summary，再允许 apply。

## Consequences
- Positive: 易学、可发现；避免复杂模式；测试稳定（按键序列固定）。
- Negative: `:` 命令解析需要额外实现；某些高级用户可能想要更多快捷键（可后续扩展）。
- Neutral: 若后续加入 vim-like 模式，可作为可选配置，不改变默认模型。

