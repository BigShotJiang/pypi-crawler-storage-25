# ADR 0009: Skill Tool Registry and Auditing

- Status: Proposed
- Date: 2026-01-30
- Related: ROADMAP M3-T3, REQUIREMENTS R2, ARCHITECTURE (Storage permissions, auditing)

## Context
M3 will allow agents/LLMs to call tools (skills) to retrieve context and read project files. Without a registry and audit trail, tool calls become opaque and unsafe.

## Decision
1) Define a skill registry mapping `skill_name` -> implementation + JSON schema for args.
2) Enforce permissions for skill calls:
   - path-based skills must honor agent `read_globs` and `deny_globs`.
3) Log every skill call to `.neonrp/logs/skills/<run_id>.jsonl`.

## Consequences
- Positive: observable and testable tool behavior; safer LLM integration.
- Negative: need to keep schemas and implementations in sync.
- Neutral: write-capable skills remain out of scope for M3; file writes continue through proposals + M2 apply.

## Alternatives considered
- Let LLM read arbitrary files directly: rejected (breaks permission boundary).
- Skip logging: rejected (breaks auditability).
