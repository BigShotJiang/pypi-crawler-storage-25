# L14 — Product Auto-Update Scheme (Draft)

> Status: draft proposal
> Scope: `worldlines` / `neonrp` product version update, not game-content sync
> Note: this document describes how the application itself should detect, fetch, and apply updates.

## Goal

这里讨论的“自动更新”指的是：

- `worldlines` / `neonrp` 程序本身升级
- bundled templates / `.claude/agents` / `CLAUDE.md` / runtime defaults 随版本一起升级
- 用户已安装的 CLI / app 在合适时机提示或自动应用新版本

**不包括：**

- 某个具体游戏存档内容自动同步
- 某个世界目录下 `game/` 文件自动改写
- 用户项目内容被静默迁移

---

## Product Surfaces

当前产品至少有两种运行形态：

1. **开发形态**
   - `uv run neonrp`
   - `uv tool install -e /path/to/NeonRP`
   - 本地源码 checkout
2. **发布形态**
   - `uv tool install neonrp`
   - 未来可能的 standalone bundle / installer / package manager release

自动更新方案必须明确区分这两类形态。

---

## Core Principle

### 1. 开发形态不做自动升级

如果用户当前运行方式是：

- editable install
- local source checkout
- `uv run --project ...`

则系统只做：

- 当前版本显示
- 新版本可用提示（可选）
- 不自动下载
- 不自动覆盖本地代码

原因：

- 开发环境有未提交修改
- 本地 branch / fork 可能偏离官方版本
- 自动覆盖源码风险过高

### 2. 发布形态才允许自动更新

只有当安装来源可判定为“正式发布包”时，才允许：

- 检查更新
- 下载更新
- 在用户确认后更新
- 或按策略静默准备，下次启动切换

---

## Update Channels

建议至少维护三条更新通道：

### `stable`

- 默认通道
- 面向普通用户
- 只包含通过回归与迁移检查的版本

### `preview`

- 面向提前体验用户
- 可包含较新的 TUI / MCP / Claude bootstrap 机制
- 允许轻微行为变化，但必须有回滚能力

### `nightly`（可选）

- 面向内部测试 / 早期贡献者
- 每日或每 commit 构建
- 不保证存档体验稳定

用户级配置建议：

```json
{
  "updates": {
    "channel": "stable"
  }
}
```

---

## Release Manifest

自动更新依赖一个远端 release manifest。

建议结构：

```json
{
  "product": "neonrp",
  "latest": {
    "stable": "0.3.4",
    "preview": "0.4.0-beta.2",
    "nightly": "2026.04.18"
  },
  "releases": {
    "0.3.4": {
      "channel": "stable",
      "published_at": "2026-04-18T10:30:00Z",
      "notes_url": "https://.../releases/0.3.4",
      "min_supported_project_version": "0.2.0",
      "artifacts": {
        "macos-arm64": {
          "kind": "standalone",
          "url": "https://...",
          "sha256": "..."
        },
        "python-wheel": {
          "kind": "pypi",
          "version": "0.3.4"
        }
      }
    }
  }
}
```

manifest 至少要回答：

- 最新版本是什么
- 当前通道应该更新到哪里
- 下载地址是什么
- 版本是否兼容当前项目
- 是否需要迁移步骤

---

## Update Modes

### A. `notify-only`

只提示，不执行升级。

适合：

- 开发环境
- 网络受限环境
- 用户首次接触自动更新功能时

### B. `prompt-and-update`

检测到新版本后提示：

- 查看 release notes
- 立即更新
- 跳过本次
- 关闭此版本提醒

这是推荐默认模式。

### C. `auto-download-apply-on-next-launch`

后台下载新版本，但不在当前运行中切换。

行为：

1. 当前会话继续运行
2. 更新包下载到 cache
3. 下次启动时切换到新版本

适合：

- TUI 正在运行中
- 不想打断玩家会话

### D. `silent-auto-update`（后期可选）

只有在发布包极稳定、回滚成熟后才考虑。

L14 不建议一开始就做默认 silent update。

---

## UX Entry Points

### 1. Launch-time check

启动时轻量检查：

- 不阻塞 TUI 首屏
- 先进入应用
- 检查完成后在状态区或 transcript 里提示

示例：

```text
Update available: 0.3.3 → 0.3.4 (stable)
Run /update to review and apply.
```

### 2. Manual command

建议新增统一命令：

```text
/update
/update check
/update apply
/update channel stable|preview|nightly
/update status
```

CLI 侧对应：

```bash
neonrp self-update check
neonrp self-update apply
neonrp self-update status
```

### 3. Settings surface

用户级配置建议：

```json
{
  "updates": {
    "enabled": true,
    "channel": "stable",
    "mode": "prompt-and-update",
    "check_on_launch": true,
    "last_skipped_version": "0.3.4"
  }
}
```

---

## Install-Mode Detection

更新系统首先要判断“当前安装是不是可安全自动更新的发布形态”。

建议检测顺序：

### 1. Editable install / local source

判定为开发形态的信号：

- `uv tool install -e`
- import path 指向源码 checkout
- 可检测到 `.git/` + package source tree

结果：

- 禁用自动 apply
- 只显示 notify-only 提示

### 2. `uv tool install neonrp`

这是最可能的正式 Python 安装方式。

建议更新策略：

- 仍由 `uv` 执行实际安装升级
- App 只负责检测 / 提示 / 调用升级命令

例如：

```bash
uv tool upgrade neonrp
```

如果 `uv tool upgrade` 不满足需求，则退回：

```bash
uv tool install --upgrade neonrp
```

### 3. Standalone app / installer（未来）

如果未来有：

- macOS app bundle
- Windows installer
- Linux tarball/appimage

则每个平台可拥有自己的 updater backend，但共享同一个 release manifest。

---

## Update Contents

一次产品版本更新，可能包含：

1. Python application code
2. packaged templates
3. packaged `.claude/agents`
4. packaged `CLAUDE.md`
5. default TUI rendering logic
6. migration scripts / compatibility rules

其中：

- **产品包内资源**可以直接随版本更新
- **用户项目内容**不能被静默覆盖

---

## Project Compatibility and Migration

产品自动更新不等于用户项目自动改写。

### Rule

更新程序本身时：

- 可以升级 bundled defaults
- 不应默认重写现有项目 `game/`、`agents/`、`.claude/agents/`
- 可以在需要时提示用户执行 migration / bootstrap refresh

### Two-layer compatibility model

#### Layer 1 — app compatibility

App 新版本必须尽量继续打开旧项目。

#### Layer 2 — optional project upgrade

如果某个新版本需要新模板/新 bootstrap：

- 提示用户“项目可升级”
- 提供显式命令执行
- 生成 diff / backup / rollback 点

例如：

```text
Project bootstrap update available for Claude companion workspace.
Run /update project-bootstrap to refresh .claude/agents and CLAUDE.md.
```

---

## Safety Rules

### 1. Never update during an active critical session

如果当前存在：

- 正在进行的 TUI 会话
- MCP server 正在服务中
- 正在执行 proposal/apply

则只允许：

- 提示可更新
- 下载到 cache
- 延迟到下次启动应用

### 2. Always verify artifact hash

下载的更新包必须校验：

- `sha256`
- 可选签名

### 3. Always keep previous runnable version

更新后应保留上一个版本，直到新版本成功启动一次。

### 4. Always support rollback

如果新版本启动失败：

- 自动回滚到上个版本
- 或提示用户切回上个版本

---

## Rollback Model

建议维护：

- current version
- staged version
- previous known-good version

状态示意：

```text
current -> 0.3.3
staged  -> 0.3.4
backup  -> 0.3.2
```

切换流程：

1. 下载 0.3.4
2. 校验 hash
3. 标记 staged
4. 下次启动切换
5. 若启动成功，backup=0.3.3
6. 若启动失败，回滚 0.3.3

---

## MCP-Specific Considerations

`worldlines` / `neonrp` 更新后，MCP 相关资源也可能变化：

- bundled `.claude/agents`
- `CLAUDE.md`
- `.mcp.json` shape
- local bootstrap semantics

因此要区分两类更新：

### Product update

更新应用自身。

### Workspace refresh

更新 derived Claude companion workspace。

这两个动作不要强绑定成一次静默写入。

推荐做法：

- 产品升级后，如果 companion workspace bootstrap 版本落后
- 提示用户刷新 workspace bootstrap
- 显式执行，而不是悄悄覆盖

---

## Recommended L14 Rollout

### Phase 1 — notify + manual apply

实现：

- launch-time version check
- `/update check`
- `/update apply`
- install-mode detection
- stable channel only

### Phase 2 — staged next-launch update

实现：

- 下载到 cache
- 下次启动切换
- 回滚指针

### Phase 3 — channel + workspace refresh split

实现：

- `stable/preview/nightly`
- product update 与 workspace refresh 分离
- bootstrap stale detection

### Phase 4 — platform-native updater backends

当未来有 standalone release 时再做：

- macOS native update path
- Windows native update path
- Linux package-specific path

---

## Non-Goals

以下不是这份自动更新方案的目标：

- 自动改写用户剧情/存档内容
- 后台静默覆盖本地源码 checkout
- 自动合并用户手工改过的 `.claude/agents`
- 在活跃游戏回合中热切换程序版本

---

## Proposed Next Planning Slice

当真正开始排期时，建议先拆成这 5 个实现块：

1. install-mode detection
2. release manifest client
3. `/update` + `self-update` command surface
4. staged update cache + rollback pointer
5. product update vs workspace refresh split
