# M13 Task Cards — Claude Code 必要能力移植到 NeonRP

> **Scope:** 在 M12 稳定性补尾之后，聚焦把 Claude Code 中对长时会话、复杂编排、可靠 agent loop 真正必要的能力移植到 NeonRP。
> **目标:** 不是复制 Claude Code 产品形态，而是吸收其中对 NeonRP 成为复杂游戏引擎确实必要的 runtime / loop / orchestration 能力。
> **非目标:** 不做开源发布包装（移至 `L13`），不做 WorldLines 体验层（移至 `L14`），不直接扩写复杂游戏内容（移至 `M15`）。

---

## 范围定义

M13 只回答一个问题：

**NeonRP 要支持更长、更复杂、更多代理协作的游戏流程，底层还缺哪些必要能力？**

当前优先级最高的候选能力：
- 长会话 context compression / compaction
- 动态回合管理与 budget 策略
- persistent sub-agent / mailbox
- turn sequence / loop orchestration
- 更硬的工具调用与委托运行时约束

---

## M13-T0: Scope Lock + Capability Audit

**Goal:** 明确哪些能力真的是“Claude Code 必要能力”，哪些只是可选参考。

**Deliverables:**
- `docs/M13_TASK_CARDS.md` 作为冻结基线
- 一份能力审计表：能力来源 / 解决问题 / NeonRP 当前缺口 / 是否纳入 M13

**Acceptance:**
- M13 范围收敛到 4~6 项必要能力
- 每项能力都有明确的游戏引擎价值，而非“因为 Claude Code 有所以也做”

---

## M13-T1: Context Compression + Budget Policy

**Goal:** 支持长 session，不再靠硬截断结束复杂 RP。

**Candidate changes:**
- 提取 context compactor
- 支持至少一种可配置压缩策略
- 把 token budget 管理从“快超了就停”升级为“可解释、可恢复、可调优”

**Acceptance:**
- 50+ turn session 可持续运行
- 压缩前后行为可测试、可审计

---

## M13-T2: Dynamic Turn Management

**Goal:** 回合上限从固定数字，升级为按配置/上下文/任务复杂度调整。

**Candidate changes:**
- `max_turns` 策略化
- 区分普通对话、委托任务、复杂编排的 budget
- 暴露必要 debug 指标

**Acceptance:**
- 长任务不因僵硬回合上限过早中断
- 短任务不会因为过度放宽而拖慢

---

## M13-T3: Persistent Sub-Agent + Mailbox

**Goal:** 让子代理不再完全是“一次性临时调用”，支持更自然的持续状态与异步交接。

**Candidate changes:**
- sub-agent 持久化状态
- mailbox / wake-up / handoff 协议
- `/continue` 与 session restore 一致性

**Acceptance:**
- 子代理跨回合保持状态一致
- 恢复会话后，子代理生命周期不混乱

---

## M13-T4: Turn Sequence / Loop Orchestration

**Goal:** 支持更复杂的 agent 执行顺序，而不只靠 narrator 单点兜底。

**Candidate changes:**
- turn sequence 执行器
- loop phase / ordering 约定
- 针对神乐岛类世界的明确运行契约

**Acceptance:**
- 多 agent 顺序执行可预测、可回放
- 已知 loop_config 缺口有明确修复路径

---

## M13-T5: Runtime Hardening Borrowed from Claude Code

**Goal:** 吸收 Claude Code 在稳定 agent loop 上最值得迁移的守护机制。

**Candidate changes:**
- 更明确的工具调用 guardrails
- 更稳定的路由/委托/恢复状态记录
- 对异常 loop、重复思考、错误 ownership 的兜底检查

**Acceptance:**
- 错误路由与错误 ownership 明显下降
- 调试日志足够定位 agent loop 问题

---

## M13-T6: Agent Prompt Density — 从 94 行到 1000+ 行

**Problem:**
llm-rpg-starter 的 `.claude/agents/` 有 10 个 agent prompt 共 1098 行。
NeonRP `examples/starter-world` 只有 1 个 narrator 共 94 行。**12 倍密度差。**
这是体验质量下降的核心原因——不是引擎问题，是 prompt 太薄。

**Root cause analysis:**
- CC 版: 每个 agent (orchestrator/town/dungeon/combat/story/inn/shop/guild/notary) 都有 80-240 行的详细 prompt
- NeonRP 版: 只剩一个通用 narrator（67 行 system.md + 27 行 agent.json）
- 当迁移到 NeonRP 时，10 个专精 agent 的叙事指导、路由逻辑、读写边界全部丢失

**Changes:**

### 6a. 每个 agent 搭配叙事指导 md

每个 `agents/{id}/` 目录必须包含：
- `agent.json` — 身份、权限、工具、路由 trigger
- `system.md` — 核心 prompt（100+ 行）
- **`narrative.md`（新增）** — 叙事指导，专门告诉 agent 怎么"说话"

`narrative.md` 必须包含：
```
1. 这个 agent 的叙事风格（语调、用词、节奏）
2. 输出格式要求（纯文本 vs 结构化 vs 对话体）
3. 什么时候用什么语气（战斗紧张 / 对话温和 / 探索神秘）
4. 不允许的叙事模式（不要用 bot 语气、不要列选项列表）
5. 示例输出片段（至少 3 段，让 LLM 模仿）
```

### 6b. 每个 NPC 搭配 soul doc

每个 `game/npc/{id}.json` 旁必须有一个对应的 **soul** 描述：

```
game/npc/elena.json              ← entity 数据（HP/位置/关系）
game/npc/elena.soul.md           ← 灵魂文档（性格/秘密/说话方式）
```

`soul.md` 内容结构：
```markdown
# [NPC Name] — Soul

## 一句话
谁是这个人？用一句话说清楚内心驱动力。

## 说话方式
- 语速、口头禅、常用词
- 紧张时怎么说
- 放松时怎么说
- 撒谎时有什么破绽

## 秘密（玩家不知道）
给 narrator 用的内在逻辑。NPC 的行为必须能从这里推导出来。

## 对其他 NPC 的态度
与每个可能交互的角色的关系和情绪。

## 底线
这个 NPC 绝对不会做的事。
这个 NPC 被逼急了会做的事。
```

**为什么需要 soul doc：**
- 没有 soul doc → LLM 把所有 NPC 写成同一种性格（"友好的任务 NPC"）
- 有 soul doc → LLM 能区分赫伦的沉默、米拉的笑、老苇的聒噪
- llm-rpg-starter 的 heroine 系统有 5 个 agent（mind/memory/action/dialogue/narrative）来维护一个角色的内在一致性，本质就是一份拆得很细的 soul doc

### 6c. Player 文件结构恢复

当前 NeonRP 把 7 个 player 文件压成 1 个 `player.json`，丢失了结构化信息。

**必须恢复：**

| 文件 | 作用 | agent 为什么需要 |
|------|------|----------------|
| `player/profile.json` | 姓名/背景/职业 | narrator 需要知道叫什么 |
| `player/stats.json` | HP/MP/属性/技能 | combat 需要数值 |
| `player/inventory.json` | 背包/物品 | shop 需要知道有什么 |
| `player/equipment.json` | 装备 | combat 需要 ATK/DEF |
| `player/wallet.json` | 金币 | shop/inn 需要知道余额 |
| `player/flags.json` | 故事进度标记 | 所有 agent 需要 |
| `player/journal.md` | 玩家日志 | narrative 需要回忆 |

**额外必须恢复：**

| 文件 | 作用 |
|------|------|
| `run_state.json` 或 `meta/run_state.json` | 当前位置 (scope/node_id)、时间 (day/clock)、上次行动 |

没有 run_state → agent 不知道"玩家在哪""几点了""上次做了什么" → 叙事断裂。

**Acceptance:**
- 至少 5 个 agent（narrator + town + dungeon + combat + story）各有 100+ 行 prompt
- 每个 agent 有 narrative.md
- 每个关键 NPC 有 soul.md
- player 拆回 7 文件 + run_state 恢复
- starter-world 用新结构跑通 5 turn，叙事质量可感知提升

---

## M13-T7: Narrator 永远是最终输出层

**Problem:**
NeonRP 的 `active_agent.json` 机制让 town-agent/dungeon-agent 在"锁定"后**直接对玩家输出**，跳过了 narrator。
sub-agent 的 prompt 是工具导向的（"处理城镇交互""处理战斗"），不是叙事导向的。
结果：当 active_agent = town-agent 时，叙事质量急剧下降。

**CC 的做法：**
orchestrator 永远是最终输出。sub-agent 返回结果（JSON/文本），orchestrator 整合成面向玩家的叙事。

**修复：**

```python
# conversation.py handle_turn 修改：

# 当前（问题）:
#   active_agent = town-agent → 直接调 town-agent → 输出给玩家
#
# 修复后:
#   Step 1: 判断 active_agent
#   Step 2: 如果是 sub-agent → 调 sub-agent → 拿到结果（不输出）
#   Step 3: ALWAYS 把结果传给 narrator
#   Step 4: narrator 做最终叙事整合 → 输出给玩家

def handle_turn(user_input):
    active = get_active_agent_id()
    narrator_id = get_narrator_agent_id()
    
    if active != narrator_id:
        # sub-agent 处理业务逻辑
        sub_result = run_agent_agentic(active, user_input)
        # narrator 整合叙事
        narrator_context = f"Sub-agent [{active}] result:\n{sub_result.summary}\n\nPlayer said: {user_input}"
        final_output = run_agent_agentic(narrator_id, narrator_context)
    else:
        # narrator 直接处理
        final_output = run_agent_agentic(narrator_id, user_input)
    
    return final_output
```

**关键变化：**
- sub-agent 的输出**不直接给玩家**
- narrator **永远是最后一跳**
- narrator 的 narrative.md 保证输出是文学质量的
- active_agent.json 仍然用于"告诉 narrator 该委托给谁"，但不跳过 narrator

**Acceptance:**
- 任何时候的最终输出都经过 narrator
- town-agent/dungeon-agent 的返回是结构化的（状态变更），不是面向玩家的文本
- 叙事质量在 active_agent 切换前后无明显落差

---

## M13-T8: 允许 Narrator 跳过 Proposal 直接输出叙事

**Problem:**
NeonRP 的 agentic loop 要求 agent 必须 `submit_proposal` 才算"成功完成"。
对于纯叙事场景（描写风景、角色对话、情绪推进），强制 proposal = 迫使 LLM 把注意力花在"我该改什么 JSON"而不是"我该写什么故事"。

**CC 的做法：**
CC 的 queryLoop 允许 LLM 在**不调用任何工具**的情况下结束回合。当 LLM 判断"这一刻只需要文本"时，它直接生成叙事，不走 proposal。

**修复：**

```python
# agent_runner.py run_agent_agentic() 修改：

# 当前:
#   if not proposal_data:
#       return AgentRunResult(success=False, error="Agent did not submit a proposal")

# 修复后:
#   if not proposal_data:
#       # 如果 agent 有文本输出但没有 proposal → 这是纯叙事回合 → 合法
#       if last_assistant_content:
#           return AgentRunResult(
#               success=True,
#               narrative=last_assistant_content,  # 新字段
#               proposal=None,
#               turns=turn,
#           )
#       else:
#           return AgentRunResult(success=False, error="Agent produced no output")
```

**AgentRunResult 新增字段：**
```python
@dataclass
class AgentRunResult:
    ...
    narrative: str | None = None  # 纯叙事输出，不需要 proposal
```

**何时触发：**
- narrator agent 决定"这一刻只需要描写/对话" → 不 submit_proposal → 直接输出文本
- sub-agent 处理完状态变更 → submit_proposal → narrator 拿到结果后做纯叙事 → 不需要再 submit_proposal

**Acceptance:**
- narrator 在纯叙事场景能正常返回（不报 "did not submit a proposal" 错误）
- 战斗/交易等需要改状态的场景仍然走 submit_proposal
- 混合场景（先改状态再叙事）可以 submit_proposal + 文本两者都有

---

## M13-T9a: Agent Base Prompt 底座（enhanceSystemPrompt 等价物）

**Problem:**

CC 的每个 agent spawn 时，在用户定义的 `.claude/agents/*.md` 之上**自动叠加 4 层底座 prompt**：

```
═══════════════════════════════════════════════════
CC sub-agent 的 system prompt 构成（从底到顶）
═══════════════════════════════════════════════════

Layer 4 (最上层 · 用户可见): 你写的 agent .md body
  ↓ 例如: "你是 town-agent，负责城镇交互..."

Layer 3 (注入 · 用户不可见): enhanceSystemPromptWithEnvDetails()
  ↓ 自动添加:
  ↓ - "Agent threads always have their cwd reset between bash calls,
  ↓    please only use absolute file paths."
  ↓ - "In your final response, share file paths that are relevant"
  ↓ - "Do not use emojis"
  ↓ - "Do not use a colon before tool calls"

Layer 2 (环境 · 用户不可见): computeEnvInfo()
  ↓ 自动添加:
  ↓ - Working directory: /path/to/project
  ↓ - Is directory a git repo: Yes
  ↓ - Platform: darwin
  ↓ - Shell: zsh
  ↓ - OS Version: Darwin 24.6.0
  ↓ - Model: Claude Opus 4.6
  ↓ - Knowledge cutoff: May 2025

Layer 1 (上下文 · 用户不可见): getUserContext() + getSystemContext()
  ↓ 自动添加:
  ↓ - CLAUDE.md 内容（项目指令，除非 omitClaudeMd=true）
  ↓ - 当前日期
  ↓ - Git status（branch, recent commits, modified files）
  ↓ - Memory files（如果有 auto-memory）

Layer 0 (兜底 · 如果用户 prompt 加载失败):
  DEFAULT_AGENT_PROMPT =
  "You are an agent for Claude Code, Anthropic's official CLI for Claude.
   Given the user's message, you should use the tools available to
   complete the task. Complete the task fully—don't gold-plate, but
   don't leave it half-done. When you complete the task, respond with
   a concise report covering what was done and any key findings —
   the caller will relay this to the user, so it only needs the essentials."
```

**CC 源码位置：**
- Layer 0: `constants/prompts.ts` L758 `DEFAULT_AGENT_PROMPT`
- Layer 1: `context.ts` L155 `getUserContext()` + L116 `getSystemContext()`
- Layer 2: `constants/prompts.ts` L606 `computeEnvInfo()`
- Layer 3: `constants/prompts.ts` L760 `enhanceSystemPromptWithEnvDetails()`
- 组装: `tools/AgentTool/runAgent.ts` L906 `getAgentSystemPrompt()`

**这就是为什么 CC 的 agent "随便写都能 work"——即使用户的 .md 只有一行 description，CC 仍然注入了完整的行为规范 + 环境信息 + 兜底指令。**

**NeonRP 没有这些。** agent 的 system prompt = system.md 原文。system.md 写烂了 agent 就废了。

**Root cause of "NeonRP agent 定义给错就停止工作":**
CC agent 有底座兜底；NeonRP agent 没有。

---

### CC 实际的 prompt 组装（代码确认版）

**CC 源码确认：agent prompt 分两个注入点，不是全部塞进 system prompt。**

CC 源码路径：
- `tools/AgentTool/runAgent.ts` L748-757 → 调用 `query()`
- `utils/api.ts` L437 `appendSystemContext()` → 拼 system prompt
- `utils/api.ts` L449 `prependUserContext()` → 注入 messages[0]
- `query.ts` L449-451 + L660 → 最终组装

```
CC 调 API 时实际发出去的内容：

┌──────────────────────────────────────────────────────────┐
│ API system 参数（不可 compact，prompt cache 友好）         │
│                                                          │
│ = appendSystemContext(agentSystemPrompt, systemContext)   │
│                                                          │
│   [0] 用户的 .md body                                     │
│       如果加载失败 → DEFAULT_AGENT_PROMPT 兜底             │
│   [1] enhanceSystemPromptWithEnvDetails 注入的 notes      │
│       "Agent threads always have their cwd reset..."      │
│       "Do not use emojis"                                 │
│       "Do not use a colon before tool calls"              │
│   [2] computeEnvInfo()                                    │
│       Working directory / Platform / Model / Cutoff       │
│   [3] systemContext                                       │
│       gitStatus (branch, recent commits)                  │
└──────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────┐
│ API messages 参数（可被 compact 压缩）                     │
│                                                          │
│ = prependUserContext(messages, userContext)                │
│                                                          │
│ messages[0] (伪装成 user message):                        │
│   <system-reminder>                                       │
│   # claudeMd                                              │
│   (CLAUDE.md 全文 — 项目指令)                              │
│   # currentDate                                           │
│   Today's date is 2026-04-11.                             │
│   </system-reminder>                                      │
│                                                          │
│ messages[1..N] 实际对话                                    │
└──────────────────────────────────────────────────────────┘
```

**CC 关键源码：**

```typescript
// utils/api.ts L437 — system prompt 拼接（稳定，不可 compact）
export function appendSystemContext(systemPrompt, context) {
  return [...systemPrompt, Object.entries(context)
    .map(([key, value]) => `${key}: ${value}`).join('\n')
  ].filter(Boolean)
}

// utils/api.ts L449 — messages[0] 注入（可变，可 compact）
export function prependUserContext(messages, context) {
  return [
    createUserMessage({
      content: `<system-reminder>\n${Object.entries(context)
        .map(([key, value]) => `# ${key}\n${value}`).join('\n')}
      IMPORTANT: this context may or may not be relevant.\n</system-reminder>`,
      isMeta: true,
    }),
    ...messages,
  ]
}
```

**CC 的设计决策：**
- **稳定内容 → system prompt**（base + notes + env）— prompt cache 友好，不被 compact
- **变化内容 → messages[0]**（CLAUDE.md + 日期）— 可被 compact 压缩

---

### NeonRP 对应实装：双注入点

```python
# 新文件: core/agent_base_prompt.py

# ═══════════════════════════════════════════
# 注入点 1: system prompt（稳定，不可 compact）
# ═══════════════════════════════════════════

AGENT_BASE_PROMPT = \"\"\"You are an agent for WorldLines, Ludic Dynamics' Game Orchestrator Engine for GLM, or Claude.

Given the user's input, use the available skills and agents to present a living, breathing game world. Complete your task fully — don't gold-plate, but don't leave it half-done. Your output will be relayed to the player; make it essential, compelling, and engaging.

## Core Rules
- Read before you write. Never guess file contents.
- Use project-relative paths (e.g., `game/player/stats.json`).
- On "file not found": use find/glob to locate. Do not retry the same broken path.
- On any error: try ONE alternative approach. If that fails, return what you have with a note.
- Never expose system internals to the player (file paths, JSON fields, agent IDs).
- When uncertain: return "clarify" so the orchestrator can ask the player.

## Tool Discipline
- read_file / read_context / find / glob / grep → information gathering (always safe)
- write_file / edit_file → only within permissions.write_globs
- submit_proposal → atomic batch changes to game state
- ask_user → present 2-4 choices to the player (structured, not prose lists)
- task → delegate to another agent (orchestrator only)
- resolve_action → deterministic game mechanics (damage, buy, heal)

## Output Contract
- orchestrator → narrative text for the player (the voice of the world)
- domain agent → structured JSON result for orchestrator (never shown to player)
- rules-referee → dice ruling JSON (roll, DC, success, consequences)
\"\"\"

AGENT_ENV_TEMPLATE = \"\"\"
## Environment
- Project root: {project_root}
- World: {world_id}
- Branch: {branch} (head_event: {head_event})
- Engine: WorldLines/NeonRP {engine_version}
- Data directory: {data_dir}/
\"\"\"

MINIMAL_ENV_TEMPLATE = \"\"\"
## Environment
- Project root: {project_root}
\"\"\"


# ═══════════════════════════════════════════
# 注入点 2: messages[0]（可变，可 compact）
# ═══════════════════════════════════════════

CONTEXT_INJECTION_TEMPLATE = \"\"\"<system-reminder>
# run_state
{run_state_content}

# narrative_style
{narrative_content}

# currentDate
{current_date}
</system-reminder>\"\"\"


# ═══════════════════════════════════════════
# Fallback 定义
# ═══════════════════════════════════════════

# system.md 加载失败 → 根据 agent_id 推断职责
ROLE_FALLBACK = {
    "orchestrator": "你是主控调度器。读 run_state → 路由 → 整合叙事。\n",
    "town-agent": "你处理城镇全部交互。返回 JSON 给 orchestrator。\n",
    "dungeon-agent": "你处理地下城。战斗交 combat-referee。\n",
    "combat-referee": "你是 d20 战斗裁判。返回战斗 JSON。\n",
    "rules-referee": "你是规则裁判。d20+mod >= DC。返回判定 JSON。\n",
    "world-builder": "你管世界地图。更新 world_map.json。\n",
}
DEFAULT_ROLE_FALLBACK = "你是一个游戏 agent。用工具完成任务。返回结构化结果。\n"

# narrative.md 缺失 → 通用叙事
GENERIC_NARRATIVE = "第二人称。短段落。感官细节。不用感叹号。不用 emoji。"

# run_state.json 缺失 → 默认起点
DEFAULT_RUN_STATE = {
    "location": {"scope": "town", "node_id": "T001", "subnode_id": "gate_north"},
    "time": {"day": 1, "clock": "08:30"},
    "turn_count": 0,
}


# ═══════════════════════════════════════════
# 组装函数
# ═══════════════════════════════════════════

def build_system_prompt(agent_id, agent_system_md, root, manifest, config):
    \"\"\"注入点 1: 稳定内容 → system prompt（不被 compact）。\"\"\"
    parts = [AGENT_BASE_PROMPT]

    # env info (fallback to minimal)
    try:
        branch = manifest.current_branch
        head = manifest.branches.get(branch, {}).get("head_event", 0)
        parts.append(AGENT_ENV_TEMPLATE.format(...))
    except Exception:
        parts.append(MINIMAL_ENV_TEMPLATE.format(project_root=str(root)))

    # system.md (fallback to role)
    if agent_system_md and agent_system_md.strip():
        parts.append("---\n\n" + agent_system_md)
    else:
        parts.append("---\n\n" + ROLE_FALLBACK.get(agent_id, DEFAULT_ROLE_FALLBACK))

    return "\n\n".join(parts)


def build_context_injection(run_state, narrative_md):
    \"\"\"注入点 2: 可变内容 → messages[0]（可被 compact）。\"\"\"
    rs = run_state or DEFAULT_RUN_STATE
    narr = narrative_md.strip() if narrative_md else GENERIC_NARRATIVE
    content = CONTEXT_INJECTION_TEMPLATE.format(
        run_state_content=json.dumps(rs, ensure_ascii=False, indent=2),
        narrative_content=narr,
        current_date=date.today().isoformat(),
    )
    return Message(role="system", content=content)
```

### 代码改��位置（agent_runner.py L746-873）

```python
# 改动 1: system_prompt (L752)
# 当前:  system_prompt = system_prompt_path.read_text()
# 改为:
raw_md = system_prompt_path.read_text() if system_prompt_path.exists() else None
system_prompt = build_system_prompt(agent_id, raw_md, root, manifest, config)

# 改动 2: messages (L873)
# 当前:  messages = [Message(role="system", content=system_prompt), Message(role="user", ...)]
# 改为:
run_state = load_run_state(root)
narrative = load_narrative_md(agent_dir)
context_msg = build_context_injection(run_state, narrative)
messages = [
    Message(role="system", content=system_prompt),  # 注入点 1
    context_msg,                                     # 注入点 2
    Message(role="user", content=user_content),
]
```

### Fallback 汇总

| 层 | 失败时 | fallback | 日志 |
|----|--------|----------|------|
| base prompt | 永不失败（硬编码） | — | — |
| env info | manifest 读取失败 | MINIMAL_ENV | warning |
| system.md | 文件空/缺失 | ROLE_FALLBACK[id] | warning |
| run_state | 文件缺失/解析失败 | DEFAULT_RUN_STATE | warning |
| narrative.md | 缺失 | GENERIC_NARRATIVE | warning (orchestrator only) |

**每次 fallback 必须 log warning。调试时一眼看到哪层降级了。**

### 与 CC 精确对应

| CC 源码 | NeonRP 对应 | 注入位置 |
|---------|------------|---------|
| `DEFAULT_AGENT_PROMPT` (prompts.ts L758) | `AGENT_BASE_PROMPT` | system prompt |
| `enhanceSystemPromptWithEnvDetails()` (prompts.ts L760) | Core Rules 嵌入底座 | system prompt |
| `computeEnvInfo()` (prompts.ts L606) | `AGENT_ENV_TEMPLATE` | system prompt |
| `appendSystemContext()` (api.ts L437) | `build_system_prompt()` | system prompt |
| `prependUserContext()` (api.ts L449) | `build_context_injection()` | messages[0] |
| `getUserContext().claudeMd` | `narrative.md` | messages[0] |
| `getUserContext().currentDate` | `date.today()` | messages[0] |
| `getSystemContext().gitStatus` | `run_state.json` | messages[0] |

### Acceptance

- [ ] 所有 agent 自动带底座 prompt
- [ ] 空 system.md 也能运转（role fallback）
- [ ] 稳定内容在 system prompt（不被 compact）
- [ ] 可变内容在 messages[0]（可被 compact）
- [ ] 每次 fallback ��� warning 日志
- [ ] 不破坏现有 agent（叠加不替换）



---

## M13-T9b: Agent 调用失败恢复链（CC query.ts 错误处理移植）

**Problem:**

NeonRP 的 `run_agent_agentic()` 在 tool 调用失败时**没有任何恢复机制**：

```python
# agent_runner.py L998-1000 — 当前逻辑
if result.finished or not result.tool_calls:
    break  # ← LLM 决定不再调工具 → 直接退出。没有重��。
```

**失败场景链：**
1. orchestrator 调 `task(town-agent)` → town-agent 失败（system.md 加载错 / depth 超限 / LLM 返回 error）
2. 错误以 `{"status": "error", ...}` 注入回 orchestrator 的 messages
3. orchestrator 的 LLM 看到错误 → **决定放弃** → 不再调工具 → `finished = True`
4. **Loop 直接 break。没有 fallback。没有重试。**

���就是为什么"提示词差一点 → trigger 就断 → 断了就不继续"。

**CC 的 query.ts（L650-930）有 6 层错误恢复：**

```
CC 错误处理链（从代码确认）：

Layer 1: Model Fallback
  API 抛 FallbackTriggeredError → 换 fallbackModel 重试
  （query.ts L894-897: currentModel = fallbackModel; attemptWithFallback = true）

Layer 2: Context 413 → Compact Retry
  API 返回 413 (prompt too long) → reactive compact 压缩 → 重试
  （query.ts L1087-1110: collapse_drain_retry → reactive_compact_retry）

Layer 3: Tool Error → 注入回 messages → LLM 自动重试
  工具执行失败 → 错误作为 tool_result 回 LLM → LLM 下一轮换策略
  （这是最基本的——NeonRP 也有，但 LLM 可能决定放弃）

Layer 4: needsFollowUp 判断
  即使 LLM 停止调工具，如果有未完成的 tool results → 继续 loop
  （防止 LLM "假装完成"实际没做完）

Layer 5: Streaming 中断恢复
  streaming 中途断开 → 清理 partial messages → 重新发起 API call
  （query.ts L712-730: yield tombstones → retry）

Layer 6: Stop Hook
  所有重试都失败 → 触发 stop hook → hook 可以决定继续或终止
  （query.ts L1261+: error → hook → retry/stop）
```

**NeonRP 有 0 层。**

---

**修复：实装 3 层错误恢复（对齐 CC 的 Layer 1/3/4）**

```python
# agent_runner.py run_agent_agentic() 修改

# ═══════════════════════════════════════
# Recovery Layer 1: Tool Error → 注入提示让 LLM 重试
# ═══════════════════════════════════════

# 当前（问题）:
# tool error 只注入 {"status": "error", "error": "..."} → LLM 可能放弃

# 修复:
# tool error 注入时追加恢复指令
if tool_result and '"status": "error"' in tool_result:
    tool_result_with_hint = _json_dumps({
        **json.loads(tool_result),
        "_recovery_hint": (
            "This tool call failed. You MUST try an alternative approach. "
            "Options: (1) retry with different parameters, "
            "(2) use a different tool, "
            "(3) skip this step and continue with what you have. "
            "Do NOT give up. Do NOT return without completing your task."
        )
    })
    messages.append(Message(role="tool", content=tool_result_with_hint, ...))


# ═══════════════════════════════════════
# Recovery Layer 2: LLM 放弃检测 + 强制 re-prompt
# ═══════════════════════════════════════

# 当前（问题）:
# if result.finished or not result.tool_calls: break

# 修复:
if result.finished or not result.tool_calls:
    # 检查是否真的完成了（有 proposal 或有叙事内容���
    has_proposal = proposal_data is not None
    has_narrative = result.message and result.message.content and len(result.message.content) > 50
    
    if has_proposal or has_narrative:
        break  # 真的完成了
    elif abandonment_retries < MAX_ABANDONMENT_RETRIES:  # 新增：最多 re-prompt 2 次
        abandonment_retries += 1
        # 强制注入一条 "你还没完成" 的提示
        messages.append(Message(
            role="user",
            content=(
                "[SYSTEM: Your task is not complete. You have not submitted a proposal "
                "or produced meaningful output. Please continue working. "
                f"Attempt {abandonment_retries}/{MAX_ABANDONMENT_RETRIES}.]"
            )
        ))
        logger.warning("Agent %s abandoned without output, re-prompting (%d/%d)",
                       agent_id, abandonment_retries, MAX_ABANDONMENT_RETRIES)
        continue  # 不 break，继续 loop
    else:
        break  # 真的放弃了，允许退出


# ═══════════════════════════════════════
# Recovery Layer 3: Sub-agent 调用失败 → Orchestrator 自行处理
# ═══════════════════════════════════════

# 当前（问题）:
# task() 调用 sub-agent → sub-agent 失败 → 返回 error JSON → orchestrator 可能放弃

# 修复: sub-agent 失败时 orchestrator 收到的不只是 error，还有降级建议
if task_data:
    try:
        sub_result = run_agent_agentic(...)
        if not sub_result.success:
            # Sub-agent 失败 → 告诉 orchestrator 可以自己做
            tool_result = _json_dumps({
                "status": "degraded",
                "error": sub_result.error,
                "agent_id": target_agent_id,
                "_recovery_hint": (
                    f"Sub-agent '{target_agent_id}' failed: {sub_result.error}. "
                    "You can: (1) retry the delegation, (2) handle this task yourself "
                    "using read_file/write_file directly, or (3) skip and inform the player."
                ),
            })
        else:
            tool_result = _json_dumps({...})  # 正常结果
    except Exception as e:
        tool_result = _json_dumps({
            "status": "error",
            "error": f"Sub-agent crashed: {e}",
            "_recovery_hint": "Sub-agent crashed. Handle this yourself or skip.",
        })
```

**新增常量：**
```python
MAX_ABANDONMENT_RETRIES = 2  # LLM "放弃"后最多 re-prompt 2 次
```

### NeonRP vs CC 错误恢复对比（修复后）

| CC 层 | CC 做法 | NeonRP 修复后 |
|-------|--------|-------------|
| Layer 1: Model Fallback | 换 fallback model 重试 | **暂不实装**（需要多 model 支持）|
| Layer 2: 413 Compact Retry | reactive compact → 重试 | **M13-T1 Context Compression 解决** |
| **Layer 3: Tool Error Recovery** | 错误注入 messages | **注入 + _recovery_hint 恢复指令** |
| **Layer 4: Abandonment Detection** | needsFollowUp 检查 | **has_proposal/has_narrative 检查 + re-prompt** |
| Layer 5: Streaming Recovery | 清理 + 重试 | **暂不实装**（NeonRP streaming 较稳定）|
| **Layer 6: Sub-agent Failure** | Agent tool error handling | **degraded 状态 + 自行处理建议** |

### 为什么"递归迁移会稳一点但不能彻底解决"

你说得对。递归（orchestrator → sub-agent → tool）本身是稳的，因为错误会自然冒泡回 parent。**但问题不在递归结构，在于 parent 收到错误后怎么反应。**

```
当前:
  orchestrator → task(town-agent) → 失败
  → orchestrator 收到 {"status": "error"}
  → LLM 看到 error → "我不知道怎么办" → 停止���工具 → break
  → 用户看到空白输出

修复后:
  orchestrator → task(town-agent) → 失败
  → orchestrator 收到 {"status": "degraded", "_recovery_hint": "你可以自己做"}
  → LLM 看到 hint → "好，我自己用 read_file 读数据，直接处理"
  → 即使 sub-agent 挂了，orchestrator 能降级完成任务
```

**关键：不是修复递归，是给错误消息加"恢复指令"。** LLM 不会自己想到"失败了可以换策略"——你得**显式告诉它**。CC 的底座 prompt 里那句 "Complete the task fully—don't leave it half-done" 就是在做这个。

### Acceptance

- [ ] Tool error 包含 `_recovery_hint`（告诉 LLM 怎么恢复）
- [ ] LLM 放弃时 re-prompt 最多 2 次（abandonment detection）
- [ ] Sub-agent 失败返回 `"status": "degraded"` 而不是 `"error"`（提示可降级）
- [ ] 每次 recovery 有 warning 日志
- [ ] 10 turn 测试：故意让 sub-agent 失败 → orchestrator 能降级完成

---

## M13-T9: 3-Layer Agent Architecture + run_state.json

**Problem:**

NeonRP 缺少 `run_state.json`（llm-rpg-starter 有）。没有它，agent 不知道玩家在哪、几点了、上次做了什么。
同时，当前的 agent 递归模型是"平级转交"（town-agent 通过 active_agent.json 锁定自己），而不是"层级委托"。

**核心设计变更：从"状态转交"改为"3 层层级递归"**

### 3 层定义

```
Layer 1: Orchestrator（main-agent）
  - 拥有 run_state.json 读写权
  - 负责：路由决策、状态更新、最终叙事输出
  - 永远是 parent，永远不被跳过
  - depth = 0

Layer 2: Domain Agent（sub-agent，有持久 context）
  - town-agent / dungeon-agent / story-agent 等
  - 拥有领域数据读写权（game/towns/*, game/dungeons/*...）
  - 可以有持久 context（跨 turn 记住正在处理的任务）
  - 可以调用 Layer 3 tool-agent
  - depth = 1

Layer 3: Tool Agent（原子工具，不可再递归）
  - dice-agent: 纯骰子计算
  - rules-agent: 查 rules.md 判断合法性
  - crisis-agent: 基于状态预测危机
  - ❌ 不能 spawn 任何 agent（task tool 被移除）
  - ❌ 不能改 run_state
  - ❌ 不能输出面向玩家的叙事
  - depth = 2 (max_depth = 3 时，Layer 3 没有 task 工具)
```

### run_state.json 设计

```json
{
  "session_id": "S0001",
  "world_id": "W001",
  "location": {
    "scope": "town",       // world | town | dungeon | combat | facility
    "node_id": "T001",     // 当前城镇/地下城 ID
    "subnode_id": "inn"    // 当前子节点（设施/房间）
  },
  "time": {
    "day": 3,
    "clock": "16:45"
  },
  "active_domain_agent": "town-agent",  // 替代 active-agent.json
  "active_domain_reason": "player is in town T001",
  "last_action": "entered_inn",
  "pending": [],
  "turn_count": 0
}
```

**关键变化：**
- `active-agent.json` 被**废弃**，合并到 `run_state.json` 的 `active_domain_agent` 字段
- `run_state.json` 由 **orchestrator 独占写权**（sub-agent 不能改）
- `location.scope` 决定路由：`town` → town-agent, `dungeon` → dungeon-agent, `combat` → combat-agent

### 请求流转（一次完整的 handle_turn）

```
User: "我去杂货铺买把剑"
  │
  ▼
Orchestrator (Layer 1):
  1. 读 run_state.json → scope=town, node=T001, subnode=main_street
  2. 路由决策：scope=town → 委托 town-agent
  3. 调用 task(town-agent, {
       input: "我去杂货铺买把剑",
       run_state: { location, time, last_action },
       player_summary: { gold: 74, inventory: [...] }
     })
       │
       ▼
     Town-Agent (Layer 2):
       1. 读 towns/T001/facilities/shop_general.json
       2. 判断：需要砍价 → 调用 dice-agent
       3. 调用 task(dice-agent, {
            check: "persuasion",
            stat: "CHA",
            modifier: 0,
            dc: 12
          })
            │
            ▼
          Dice-Agent (Layer 3):
            ❌ 没有 task 工具
            纯计算：d20=14, CHA_mod=+1, total=15, dc=12
            return { roll: 14, modifier: 1, total: 15, dc: 12, success: true }
            │
       ◀────┘
       4. 砍价成功 → 构造 proposal:
          - edit player/wallet.json: gold 74 → 62
          - edit player/inventory.json: +1 长剑
          - edit shop_general.json: stock -1
       5. submit_proposal + return structured result:
          {
            action: "buy_item",
            item: "长剑",
            price: 12 (砍价后),
            original_price: 14,
            dice_result: { roll: 14, success: true },
            narrative_hint: "老苇一脸肉痛地给了折扣"
          }
       │
  ◀────┘
  4. 收到 town-agent 结果
  5. 更新 run_state.json:
     - last_action: "bought_longsword_at_shop"
     - time.clock: "16:50" (+5 min)
  6. Apply town-agent 的 proposal（状态变更）
  7. 生成最终叙事（用 narrative.md 的风格指导）:

     "老苇看了你一眼，拿起那把长剑在手里掂了掂。
      '十四个金币。'
      你还价。他一脸肉痛，最后咬牙说 '十二。再少我要亏了。'
      你把铜币推过去。他把剑递给你时手指不情愿地松开。
      一把旧长剑。但至少比你的拳头强。"

  8. 输出给玩家
```

### 与当前 active_agent.json 的区别

| | 当前 (active_agent.json) | 新设计 (run_state + 3 层) |
|--|--|--|
| **谁管状态** | sub-agent 自己改 active_agent | orchestrator 独占 run_state |
| **谁做路由** | conversation.py 根据 active_agent 跳过 narrator | orchestrator 每次都先跑，自己决定委托谁 |
| **谁做叙事** | 当前 active_agent（可能是 town-agent） | 永远是 orchestrator |
| **depth 模型** | 2 层（narrator → sub-agent），sub-agent 不能再委托 | 3 层（orchestrator → domain → tool） |
| **tool-agent** | 不存在 | 新增：dice / rules / crisis，纯计算不递归 |
| **状态感知** | agent 不知道玩家在哪（没有 run_state） | orchestrator 读 run_state 后告诉 domain agent |

### Tool Agent 列表（Layer 3）

| Agent | 输入 | 输出 | 说明 |
|-------|------|------|------|
| `dice-agent` | check type, stat, DC, modifier | roll, total, success, crit | 骰子判定（d20 系统），纯计算不读文件 |
| `rules-agent` | action, actor, target, context | allowed, reason, consequences | 查 rules.md 判断行为合法性 |
| `crisis-agent` | current run_state, recent events | threat_level, prediction, suggestion | 预测接下来可能的危险（给 orchestrator 决策用） |

**为什么这些是 tool-agent 而不是普通 tool?**
因为它们需要**推理**（不只是查表），但不需要**持久状态**和**文件读写**。

实际实现可以两种方式：
- **方式 A（推荐）：** 作为 `resolve_action` 的增强版 skill，代码里做骰子计算
- **方式 B：** 作为真正的 depth=2 agent，用 LLM 做推理（更灵活但更慢）

dice-agent 推荐方式 A（确定性计算用代码更可靠）。
rules-agent 和 crisis-agent 推荐方式 B（需要语义理解）。

### Dispatcher 路由规则修改（关键）

**现状问题：**
NeonRP 的 `dispatcher.py::select_agent()` 用 trigger regex "first match wins"。
所有 agent 都有 triggers → dispatcher 可能把玩家输入直接路由到 domain agent（如 combat-referee），**绕过 orchestrator**。

**当前 NeonRP 缺少的概念：**
代码里没有 domain agent / sub-agent / tool-agent（skill）的区分。所有 agent 对 dispatcher 都是平等的。只有 orchestrator 应该是"**唯一的 domain agent**"——唯一能被 dispatcher 直接选中的 agent。其余 agent 只能被 orchestrator 通过 `task()` 调用。

**修复规则：**

```
1. 只有 orchestrator 可以有 triggers（通常是 [".*"]）
2. 所有其他 agent 的 triggers 必须为空 []
3. dispatcher 选中的永远是 orchestrator
4. orchestrator 内部读 run_state.json 决定委托给哪个 sub-agent
5. sub-agent 只能被 task() 调用，不能被 dispatcher 直接路由
```

**这意味着 dispatcher.py 在 3 层架构下的角色变了：**

| | 当前 dispatcher | 修改后 dispatcher |
|--|--|--|
| **选谁** | 任何 agent（trigger first match） | 只选 orchestrator |
| **路由依据** | 玩家输入的 regex 匹配 | 固定选 narrator_agent_id |
| **sub-agent 路由** | dispatcher 做（错） | orchestrator 做（对） |
| **domain 知识在哪** | 分散在各 agent 的 trigger | 集中在 orchestrator 的 system.md 路由规则 |

**具体代码改动方案（两选一）：**

**方案 A（最小改动，推荐先做）：** 不改 dispatcher.py 代码，只改数据——所有 domain agent 的 `agent.json` 里 `triggers: []`，只有 orchestrator 有 `triggers: [".*"]`。dispatcher 自然只能选中 orchestrator。

**方案 B（干净方案，M13 后期）：** 改 `conversation.py`，在 handle_turn 开头**硬编码**"永远先调 `narrator_agent_id`（= orchestrator）"，不走 dispatcher 的 trigger 匹配逻辑。dispatcher 只在 orchestrator **内部**被用于 debug/fallback。

**Stone Ford Town 已经执行了方案 A：** 所有 domain agent triggers 已清空，只有 orchestrator 保留 `[".*"]`。

### 代码改动范围

```
需改的文件：

dispatcher.py（方案 B 时改，方案 A 不需要改）:
  - select_agent 增加 "如果 narrator_agent_id 在 specs 里则直接返回它" 的 fast path
  - 或者 conversation.py 不再调 dispatcher，直接用 narrator_agent_id

conversation.py:
  - handle_turn 永远先调 orchestrator
  - 去掉 "active_agent 跳过 narrator" 逻辑
  - orchestrator 的返回分两部分：proposal（状态变更）+ narrative（叙事）

agent_runner.py:
  - max_depth=3 (已在 config 里，确认默认值)
  - depth=2 时自动移除 task tool（已有逻辑，确认生效）

active_agent.py:
  - 废弃或重构为 "读 run_state.json 的 active_domain_agent 字段"
  - 不再作为路由决策的唯一依据

新增文件：
  - game/meta/run_state.json（每个 world 模板都要有）
  - game/meta/game-start.json（启动引导）
  - agents/orchestrator/system.md + narrative.md（新 agent）
  - agents/orchestrator/agent.json

不改的：
  - skills.py / tool_router.py / llm adapters（不受影响）
  - session.py（session 历史机制不变）
```

### 迁移计划（从现有结构）

**Phase 1（不改代码）：** 在 starter-world 里加 `orchestrator/` agent 目录 + `run_state.json`，把现在的 narrator 改名为 orchestrator。验证"orchestrator 总是先跑"的 prompt 方案能否 work。

**Phase 2（小改代码）：** conversation.py 强制每次 handle_turn 先调 orchestrator，去掉 active_agent 跳过逻辑。

**Phase 3（增量代码）：** dice-agent 实装（先用 `resolve_action` 增强版，后面再决定是否用 LLM agent）。

**Acceptance:**
- run_state.json 在所有 world 模板中存在
- orchestrator 永远是 Layer 1，sub-agent 不能改 run_state
- Layer 3 tool-agent 不能 spawn sub-agent
- 10 turn 测试：orchestrator 正确路由 + 正确更新 run_state + 叙事质量不下降

---

## M13-T10: Review Gate

**Acceptance:**
- `ruff` / `pytest` / targeted E2E 通过
- 关键行为有基线指标与回归用例
- `docs/ROADMAP.md`、`docs/PROGRESS.md`、相关 ADR 同步更新

---

## Milestone Acceptance (M13)

### Runtime 能力
- [ ] NeonRP 具备支持复杂长会话的基础 runtime 能力
- [ ] 多代理 loop 的持久化、压缩、排序、恢复能力形成闭环
- [ ] 至少一个复杂世界场景能稳定跑通，为 M15 铺路

### Agent 底座（T9a 新增）
- [ ] `build_agent_system_prompt()` 实装：所有 agent 自动带底座 prompt
- [ ] 底座包含：行为规范 + 工具使用规范 + 输出规范 + 环境信息
- [ ] 空 system.md 也能让 agent 基本运转（兜底能力）
- [ ] 底座可被 system.md 覆盖（用户指令优先级 > 底座）

### 架构（T9 新增）
- [ ] 3 层递归架构实装：orchestrator (L1) → domain-agent (L2) → tool-agent (L3)
- [ ] run_state.json 存在且由 orchestrator 独占写入
- [ ] active_agent.json 废弃，合并到 run_state.active_domain_agent
- [ ] Layer 3 agent 无法 spawn sub-agent（task tool 被移除）
- [ ] orchestrator 每次 handle_turn 都先跑（不被跳过）
- [ ] dispatcher 只路由到 orchestrator（domain agent triggers 为空）

### 叙事质量（T6-T8 新增）
- [ ] Agent prompt 总密度 ≥ 500 行（对标 llm-rpg-starter 的 1098 行）
- [ ] 至少 5 个专精 agent 各有 system.md + narrative.md
- [ ] 关键 NPC（≥ 5 个）有 soul.md
- [ ] player 文件拆为 7 个 + run_state 恢复
- [ ] narrator 永远是最终输出层（任何 active_agent 切换不跳过 narrator）
- [ ] narrator 可纯叙事输出（不强制 submit_proposal）
- [ ] starter-world 10 turn 体验对比测试：新旧版叙事质量有可感知提升

