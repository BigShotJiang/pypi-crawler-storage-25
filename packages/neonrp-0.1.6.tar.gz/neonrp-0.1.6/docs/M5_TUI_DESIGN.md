# M5 Design: TUI (Claude Code/OpenCode-style)

本文件定义 M5（TUI）的设计规格，用于指导实现与验收（见 `docs/ROADMAP.md` 的 M5-T0~T6）。

## Goals (M5 必达)
- **Keyboard-first**：像 Claude Code / OpenCode 一样，以快捷键和 command palette 为主完成主要操作。
- **Single-pane workflow**：在一个 TUI 里完成：
  - `agent run`（含 streaming 输出）
  - plan/diff 预览
  - 一键 apply（走 M2 apply pipeline）
  - 文件/日志浏览与跳转（run_id / save_id / sandbox）
- **Audit-first**：所有动作都能追溯到 `.neonrp/logs/`，且默认先 preview 再 apply。
- **Non-destructive defaults**：默认不执行会破坏 world 的操作（如强制覆盖/删除）；需要显式确认或 `--force`。

## Non-goals (M5 不做)
- 不做 Mods（移至 M7+）。
- 不做向量检索/embedding。
- 不做多 agent 并行调度。
- 不强制提供“完整 IDE 替代”；目标是高效的 terminal workflow。

## UX Principles (对标 Claude Code/OpenCode)
- **Fast**：常用动作不超过 2 次按键（打开 palette → 输入关键字 → Enter）。
- **Clear**：始终可见当前 branch/sandbox、LLM provider、最近 run_id、head_event。
- **Reviewable**：diff 永远可见/可一键切换；apply 必须在 diff 预览之后发生。
- **Recoverable**：任何 apply 后都引导用户快速 `save` 或 `undo` / `replay verify`。

## UI Layout

推荐使用 4 区域 + 1 overlay：

1) **Top status bar**
- project root / current branch (sandbox badge)
- head_event
- provider/model
- index status（entities count / stale hint）
- last run_id shortcut

2) **Left sidebar (Navigator)**
- Tabs（或列表）：
  - Files（game/, agents/, .neonrp/logs/）
  - Runs（最近 agent/system runs，按 run_id）
  - Saves（快照列表）
  - Sandboxes（sandbox 列表）

3) **Main pane (Chat/Transcript)**
- 显示交互式会话（用户输入、agent 输出、系统提示）
- 支持 streaming（逐 token/逐 chunk 追加）
- 显示 tool/skill 调用摘要（可折叠）

4) **Right pane (Details)**
- 根据上下文切换：
  - Diff view（proposal diff.patch + summary）
  - File viewer（只读预览）
  - Context view（M1 context hits）
  - Validation view（validate errors）

5) **Command palette overlay**
- `Ctrl+K` / `Ctrl+P` 呼出
- 支持 fuzzy search
- 输出统一的“动作/命令”（例如：`Agent: Run`, `World: Validate`, `Index: Build`, `Sandbox: New`）

## Interaction Model

### Modes
尽量避免多模式；默认是一条输入框：
- 输入自然语言：触发 `agent run`（默认 provider 从 config 读取）
- 以 `:` 开头：进入“命令行模式”，解析为 TUI 内命令（更快）
  - 示例：`:validate`, `:index build`, `:find tokyo`, `:sandbox new try-1 --from save_001`

### Keybindings (建议最小集合)
- `Ctrl+K`：command palette
- `Tab`：切换焦点（Navigator → Chat → Details → Input）
- `Ctrl+Enter`：发送输入（agent run）
- `a`：在 diff 视图中 apply（需要焦点在 diff 并且 proposal 已通过校验）
- `u`：undo（调用已有命令）
- `s`：save（快速保存）
- `g`：跳转到最近 run（open run logs）
- `q`：退出（若存在未应用 proposal，提示确认）

> Keybindings 需要在 TUI 内可发现：在 palette 中提供 `Help: Keybindings`。

## Command Surface (M5)

新增命令：
- `neonrp tui [--branch <name>] [--provider <stub|openai|glm>] [--model <name>] [--json]`

说明：
- TUI 应优先直接调用 core 模块（而不是 subprocess 调 CLI），避免解析 stdout。
- CLI flags 的覆盖规则与 M3 保持一致（default < config < flags）。

## Data Sources & Integrations

TUI 只读/读写的主要数据源：
- `manifest.json`（branch/head_event/entities）
- `.neonrp/events/<branch>.jsonl`（事件流，用于 Timeline/Logs）
- `.neonrp/logs/agents/<run_id>/...`（agent run 的审计链）
- `.neonrp/logs/skills/<run_id>.jsonl`（skill 审计）
- `game/**`（文件树与预览）

### Agent run integration
- 输入框发送 → 生成 run_id → 调用 `core/llm`（streaming）→ 解析 proposal → 生成 diff → 在 Details 显示 preview
- apply 按键/按钮 → 走 `core/apply.apply_proposal()`（staging + validate + atomic swap + event append）
- apply 结果 → 写 log + 更新 manifest/head_event + 刷新 UI

## Error Handling & Safety
- 用户错误（未 init、未知 agent、权限不足）使用 toast + 详情面板显示可操作修复建议。
- 系统错误（IO、崩溃恢复）使用 toast + 提示查看日志路径。
- 任何 destructive 行为必须有二次确认（除非用户在 palette 中选择了明确的 “Force …” 动作）。

## Testing Strategy (M5)
- **View-model first**：把“选择/路由/命令解析/状态机”做成纯 Python 单测。
- **Textual app tests**：使用 Textual 的 test harness（模拟按键）验证：
  - palette 可打开并过滤
  - agent run 输出能渲染到 transcript
  - diff 视图可切换并触发 apply（stub provider + fixture proposal）

## Resolved Questions (原 Open Questions，M5 计划审查时关闭)

1. **Session 概念** — M5 不做独立 session 落盘。TUI transcript 仅在内存中维持，退出即丢弃。所有可追溯的数据已通过 agent run logs（`.neonrp/logs/agents/<run_id>/`）和事件日志持久化。独立 session 持久化（`.neonrp/logs/sessions/<id>.jsonl`）推迟到 M6+，届时可按需引入。

2. **内置 editor vs 外部 `$EDITOR`** — M5 仅提供只读 viewer（右侧 Details 面板中的文件预览）。不实现内置编辑能力。"在外部编辑器打开"功能（M5-T4）尊重 `$EDITOR` 环境变量，缺失时回退到平台默认（Windows: `notepad`，其他: `vi`）。

3. **Windows Terminal 快捷键冲突** — `Ctrl+K` 在部分终端（如 Windows Terminal）可能被系统快捷键占用。解决方案：
   - Command palette 同时注册 `Ctrl+K` 和 `Ctrl+P`，确保至少一个可用。
   - 单字母快捷键（`a`/`u`/`s`/`q`/`g`）仅在焦点**不在**输入框时激活，避免与文本输入冲突。
   - M5-T6 中实测 Windows Terminal / PowerShell / CMD 环境并记录已知冲突。

## Streaming 策略 (M5 计划审查时补充)

M5 不改造 `LLMAdapter` Protocol。当前 LLM 调用为单次完整响应（M3 设计）。TUI 中的表现：
- Agent run 期间显示"Running agent…"进度指示（spinner/动画）。
- LLM 返回后，一次性将结果渲染到 transcript 面板。
- 真正的 token-level streaming（`LLMAdapter.stream()` 方法）推迟到 M5.5+ 或 M6，届时需扩展 Protocol 和 adapter 实现。
