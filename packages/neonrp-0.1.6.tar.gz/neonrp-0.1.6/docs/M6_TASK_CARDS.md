# M6 Task Cards (Agentic Loop + RPG 体验对齐)

这些 task cards 面向"让自动化代理按卡片逐个推进"。每张卡片尽量控制在一次小 PR 的规模内。

质量门（每张卡片收尾必跑）：见 `docs/QUALITY_GATES.md`。

---

## Task dependency graph

```
H12/H13 (Pre-M6 housekeeping)
  └→ M6-T0 (docs/ADRs)
       └→ M6-Tundo (undo/redo checkpoint 子系统)
       └→ M6-T1 (LLM tool-calling, non-streaming)
            └→ M6-T2 (agent_runner agentic loop + prompt rewrite)
                 ├→ M6-T3 (dispatcher + neonrp run)
                 ├→ M6-T4 (session persistence + context window)
                 └─── M6-Tundo + M6-T2 ──→ M6-T5 (auto-apply + safety/undo)
                                                 └→ M6-T6 (TUI game loop integration)
                                                      └→ M6-T8 (review gate)
M6-T7 (LLM streaming) — 独立可选，不阻塞 review gate
```

注：
- M6-T3/T4 可与 M6-T5 并行，但 M6-T5（auto-apply）**强依赖** M6-Tundo（undo checkpoint）。
- M6-T6（TUI game loop）依赖 M6-T3 + T4 + T5 全部完成。
- M6-T7（streaming）独立于 review gate，可在 M6.5 实现。

---

## Output format convention

延续 M1~M5 约定：所有新增/重构的 CLI 命令支持 `--json` 输出标志（特别是 `neonrp run`、session 相关命令若有）。

---

## Pre-M6 — H12: 统一 Agent Run 日志命名与完整性（来自 M5 review 的 deferred）

**Goal**
- 解决 M5 review 的两条 deferred findings：
  - agent run 日志命名不一致（`llm_input.json` vs `input.json`，`diff.txt` vs `diff.patch`）
  - agent run 缺少 `validation.json` / `apply.json`
- 对齐 `docs/ARCHITECTURE.md` 的审计链规范，并与 `core/system_proposal.py` 的 system proposal logs 保持一致。

**Suggested changes**
- `src/neonrp/core/agent_runner.py`
- `src/neonrp/commands/agent.py`（JSON 输出字段中的 diff 路径）
- `src/neonrp/tui/**`（Logs Browser/Details 中读取 diff 文件名的地方）
- （可选）`docs/ARCHITECTURE.md`：如果实际落地与现有规范不同，更新规范而不是继续分叉。

**Scope**
- 统一 agent run logs 的"标准文件集合"：
  - `input.json`：本次运行上下文（run_id/agent_id/provider/query/branch/base_head_event/context_items…）
  - `llm_raw.txt`：原始 LLM 输出（便于排查 parse 错误）
  - `proposal.json`：解析后的 proposal
  - `diff.patch`：diff 预览
  - `validation.json`：dry-run validate 的结果（至少包含 issues）
  - `apply.json`：do_apply 时写入（成功/失败、event_id、applied_paths、error）
- 兼容策略：不强制迁移旧 logs；TUI/CLI 只需要能显示新 logs（必要时对旧 logs 做 best-effort 回退）。

**Acceptance**
- `neonrp agent run ...` 总会生成 `input.json`/`proposal.json`/`diff.patch`/`validation.json`
- `neonrp agent run --apply ...` 会额外生成 `apply.json`
- `neonrp replay verify`（依赖 run_id→proposal logs）不受影响

**Tests**
- Unit：agent_runner 日志文件名与字段稳定性
- Integration：stub provider 走完整 agent run（含 dry-run validate），验证日志齐全
- Integration：`--apply` 时 `apply.json` 存在且包含 event_id

---

## Pre-M6 — H13: Agent Spec 对齐（字段读取/默认值/system_prompt 路径）

**Goal**
- 修复/统一 agent spec 的若干细节，避免 M6 引入 dispatcher/session 后放大不一致：
  - `system_prompt` 字段是相对 `agents/<id>/` 还是相对 project root？
  - `context_limit` 读取来源（顶层 vs `defaults.context_limit`）
  - `permissions.read_globs/deny_globs` 在 tool calling 中必须可用

**Suggested changes**
- `src/neonrp/commands/agent.py`（agent.json 模板）
- `src/neonrp/core/agent_runner.py`（读取 system prompt、defaults、permissions）
- `docs/ADRs/0006-agent-spec-and-permissions.md`（若需要补充字段约定）

**Scope**
- 明确并固化一个约定（建议）：
  - `agents/<agent_id>/agent.json` 内的 `system_prompt` 默认值为 `"system.md"`（相对 agent 目录）
  - `defaults.context_limit` 为检索上限（agent_runner/TUI 共用）
- tool calling 读取权限使用 `permissions.read_globs`（deny-first），并在日志里记录 denied_paths（已由 SkillRegistry 支持）

**Acceptance**
- 使用 `neonrp agent new <id>` 创建的 agent，system prompt 一定能被 agent runner 正确加载
- agent runner 能读取 `defaults.context_limit` 且行为与旧版一致或更合理（文档同步）

**Tests**
- Unit：agent spec path resolution（system_prompt 相对路径）
- Integration：用新模板创建 agent 后，agent run logs 的 input.json 记录了正确的 system prompt 源（路径或摘要）

---

## M6-T0 — M6 Specs + ADRs (Doc-first)

**Goal**
- 将 M6 的关键决策写成可执行的规格与 ADR，避免实现期反复改接口。

**Primary docs**
- `docs/M6_AGENTIC_LOOP_DESIGN.md`（新增）
- `docs/ADRs/0015-agentic-loop-and-tool-calling.md`（新增）
- `docs/ADRs/0016-session-log-and-context-window.md`（新增）
- `docs/ADRs/0017-agent-dispatcher-and-routing.md`（新增）
- （若做 streaming）`docs/ADRs/0018-llm-streaming-contract.md`（新增）

**必须解决的设计决策**
1. **Proposal 提交方式** — text JSON vs `submit_proposal` tool call。建议后者：
   - 解析更可靠（不需要从混合文本中提取 JSON）
   - 与 tool calling 流程统一
   - 终止条件更清晰（收到 `submit_proposal` call = loop 结束）
2. **Prompt 格式变更** — 从"直接输出 proposal.json"改为"先用工具收集信息，最后调用 submit_proposal 提交"。需要重写 system prompt 模板和 user prompt 组装逻辑。
3. **`neonrp run` vs `neonrp agent run` 职责边界**：
   - `neonrp run "<text>"` = dispatcher 路由 + agentic loop（游戏主入口）
   - `neonrp agent run <id> --query "..."` = 指定 agent 的专家/调试模式
   - 两者共享 `core.agent_runner.run_agent()`
4. **Session 与 branch 绑定策略** — MVP 做 session 绑定 branch。切换 branch 时创建新 session 或恢复该 branch 上一个 session。
5. **Token 预算 MVP 策略** — 不做精确 token 计数；仅用 `max_turns` + `max_tool_calls` + tool result 字符截断（如 read_file 最多 5000 字符）。精确 token budget 推迟。

**Acceptance**
- 文档明确：
  - tool calling 的 message 结构（assistant tool_calls / tool results）
  - `submit_proposal` tool 的 schema 定义
  - agentic loop 的终止条件、max_turns、tool result 截断策略
  - session JSONL schema（最小字段集合 + branch 绑定策略）
  - dispatcher 路由策略（默认 deterministic；可选 LLM 分类开关）
  - `neonrp run` vs `neonrp agent run` 的职责矩阵
- ADR 状态：Accepted（按项目习惯）

---

## M6-Tundo — Undo/Redo Checkpoint 子系统

**Goal**
- 构建自动 checkpoint 机制，使 `undo` 能真实回退 game/ 文件状态（而非仅移动 head_event 指针）。
- 这是 auto-apply（M6-T5）和 game loop（M6-T6）的安全兜底——如果 auto-apply 写坏 game/ 而 undo 无法回退文件，后果灾难性。

**背景：当前 undo 的缺陷**
- `commands/branch.py:undo` 仅将 `head_event` 指针 -2，**不恢复 game/ 文件**
- 如果 apply 写入了新文件或修改了现有文件，undo 后 game/ 内容与 head_event 不一致
- 这在 M0-M5 中影响有限（用户可以手动 save/load），但在 auto-apply + game loop 场景下不可接受

**Suggested changes**
- `src/neonrp/core/checkpoint.py`（新增：checkpoint 创建/恢复/轮转）
- `src/neonrp/core/apply.py`（apply 成功前自动创建 checkpoint）
- `src/neonrp/commands/branch.py`（undo/redo 改为使用 checkpoint）
- `docs/ADRs/0003-snapshot-and-branch-strategy.md`（补充 checkpoint 策略）

**Scope**
- Checkpoint 存储：`.neonrp/checkpoints/<branch>/<event_id>/`，包含 game/ 快照 + manifest 状态
- 生命周期：
  - **创建**：每次 `apply_proposal()` 成功前，自动创建当前 game/ 的 checkpoint
  - **恢复**：`undo` 定位上一个 checkpoint → 原子替换 game/ → 回退 manifest.head_event
  - **轮转**：默认保留最近 N 个 checkpoint（建议 N=50），超过自动清理最旧的
- Redo：若存在 forward checkpoint（undo 后还没有新的 apply 覆盖），恢复到下一个 checkpoint
- Redo 在有新 apply 后失效（forward checkpoints 被清理）

**Acceptance**
- apply → undo → game/ 文件回到 apply 前的状态（可用 world hash 验证）
- undo → redo → game/ 文件回到 apply 后的状态
- undo/redo 不破坏 append-only event log（事件仍在，只改变 head 指针 + world 状态）
- checkpoint 轮转：超过 N 个时自动清理

**Tests**
- Unit：checkpoint 创建/恢复/轮转（含边界：空 world、checkpoint 不存在）
- Integration：apply（stub proposal）→ undo → verify world hash 回到 apply 前
- Integration：undo → redo → verify world hash 回到 apply 后
- Integration：连续 apply N+1 次 → 最旧 checkpoint 被清理

---

## M6-T1 — LLMAdapter: Tool Calling（非 streaming 版本）

**Goal**
- 让 LLM 调用 skills 成为"可迭代"的多轮过程：tool_call → tool_result → 继续生成 → 最终输出 proposal（或调用 `submit_proposal` tool）。

**Suggested changes**
- `src/neonrp/core/llm.py`（新增消息/工具调用的数据结构；扩展 Protocol）
- `src/neonrp/core/llm_openai.py`（解析 tool_calls，支持多轮 messages 输入）
- `src/neonrp/core/llm_stub.py`（支持脚本化 fixtures：可模拟 tool_calls 的序列）
- `src/neonrp/core/skills.py`（新增 `submit_proposal` tool schema；read_file 增加截断参数，避免 token 爆炸）

**Scope**
- 新增数据结构（建议）：
  - `Message`（role: system/user/assistant/tool, content, tool_calls?, tool_call_id?）
  - `ToolCall`（id, name, arguments）
  - `LLMTurnResult`（messages, tool_calls, finished, usage）
- `LLMAdapter` Protocol 扩展：
  - 保留 `generate()` 向后兼容（单次调用，不处理 tool calls）
  - 新增 `chat(messages: list[Message], tools: list[dict]) -> LLMTurnResult`（多轮入口）
- `submit_proposal` tool：schema 包含 `rationale` + `ops` 字段，LLM 通过 tool call 提交最终 proposal

**Acceptance**
- openai-compatible provider 能返回 tool_calls，并能在下一轮继续生成
- stub provider 能用 fixture 重放：第 1 轮请求 read_file，第 2 轮调用 submit_proposal（用于 CI）
- usage/token 信息能逐轮累积或至少可观测（写入 trace 日志）

**Tests**
- Unit：tool_calls JSON → 内部结构解析
- Unit：`submit_proposal` tool call → Proposal 对象转换
- Unit：stub 脚本 fixture 驱动 2-3 轮对话

---

## M6-T2 — `core/agent_runner`: Agentic Loop + Prompt 重写

**Goal**
- 在 `core/agent_runner.run_agent()` 内实现多轮 loop：
  - LLM 输出 tool_calls → SkillRegistry.invoke → 结果喂回 LLM → 重复
  - 直到 LLM 调用 `submit_proposal` 或触发终止条件
- 重写 prompt 模板，从"直接输出 JSON"改为"先用工具探索，最后提交 proposal"。

**Suggested changes**
- `src/neonrp/core/agent_runner.py`（loop 逻辑 + prompt 重写）
- `src/neonrp/core/skills.py`（复用 SkillRegistry + skills audit log）
- `src/neonrp/commands/agent.py`（agent new 模板更新：system prompt 包含 tool calling 指引）
- `prompts/`（若需要：更新 system prompt 模板文件）

**Scope**
- Loop guardrails：
  - `max_turns`（默认 10）
  - `max_tool_calls`（默认 20）
  - tool result 截断（read_file 等返回值限制字符数，默认 5000）
  - "无进展"检测（连续 N 轮无 tool_calls 且无法解析 proposal → fail fast）
- Prompt 重写：
  - System prompt 新增：tool calling 指引（"你可以使用以下工具读取游戏数据…"）+ proposal 提交方式（"使用 submit_proposal 工具提交变更"）
  - User prompt 简化：不再要求直接输出 JSON，改为描述任务 + 提供初始上下文
  - `neonrp agent new` 生成的模板 system.md 更新为 agentic 风格
- 日志：
  - `.neonrp/logs/agents/<run_id>/trace.jsonl`（每轮记录：messages 摘要、tool_calls、tool_results 摘要、usage）
  - `.neonrp/logs/skills/<run_id>.jsonl`（复用现有）

**Acceptance**
- 典型场景可用：agent 先 read_file 再 submit_proposal（无需用户手动喂上下文）
- tool call 权限被拒绝时：agent_runner 不崩溃；将错误 tool_result 喂回模型，允许其自我修正
- `neonrp agent new` 创建的模板包含 agentic 风格的 system prompt

**Tests**
- Unit：agentic loop happy-path（stub：tool_call → submit_proposal）
- Unit：permission denied path（tool_result 为 error，最终输出可操作失败）
- Unit：max_turns 超限 → graceful exit
- Integration：`neonrp agent run --provider stub` 产出 trace.jsonl + skills audit log

---

## M6-T3 — Dispatcher / 自动路由 + `neonrp run` 升级

**Goal**
- 用户输入一句自然语言即可"自动选 agent 并跑一回合"，对齐 Claude Code 的主模型体验。

**Suggested changes**
- `src/neonrp/core/dispatcher.py`（新增：路由 + 执行 orchestrator）
- `src/neonrp/commands/run.py`（从 M0 echo placeholder 升级为：dispatch → agentic loop → diff/validate/(auto)apply）
- `agents/*/agent.json` schema（新增可选字段：`tags`/`triggers`/`priority`）

**Scope（MVP 策略 — 渐进式复杂度）**
- **单 agent 场景**：如果项目中只有 1 个 agent → 直接使用它，无需路由逻辑
- **多 agent 场景**：
  1. 首先检查 `triggers`（可选：关键词/正则列表），精确命中直接使用
  2. 其次匹配 `description` + `tags` 关键词（简单 tf 评分）
  3. 平分时用 `priority`（默认 0）排序
  4. 仍无法区分时：回退到默认 agent（`priority` 最高的）或提示用户选择
- `triggers` 为**可选**高级配置，不影响基础使用
- 保留扩展点：`--route llm` 做 LLM 意图分类（后期再开）
- `neonrp run` 与 `neonrp agent run` 共享 `core.agent_runner.run_agent()`

**Acceptance**
- `neonrp run "<text>"` 不再只是 echo；能够产出 proposal + diff（并可选 auto-apply）
- 单 agent 场景：无需任何路由配置即可工作
- 多 agent 场景：路由稳定、可解释（日志记录选中的 agent_id 和匹配原因）
- 未命中路由时：回退到默认 agent 或提示用户可选 agent 列表（可操作）

**Tests**
- Unit：路由评分/稳定性（同输入同输出）
- Unit：单 agent 直接命中
- Integration：模拟 2 个 agent（town/shop），输入命中 triggers 后路由正确

---

## M6-T4 — Session 持久化 + 跨轮上下文窗口

**Goal**
- 让"上一轮发生了什么"成为可用能力：跨轮叙事连贯性 + 可审计。

**Suggested changes**
- `src/neonrp/core/session.py`（新增：读写 session JSONL、裁剪、上下文注入）
- `src/neonrp/core/agent_runner.py`（接受 session history 参数，注入到 prompt）
- `src/neonrp/tui/**`（启动/退出时创建/恢复 session；每轮追加记录）

**Scope**
- session log path：`.neonrp/logs/sessions/<branch>/<session_id>.jsonl`（绑定 branch）
- 最小记录字段（建议）：
  - `timestamp`, `session_id`, `turn`, `branch`
  - `user_text`
  - `routed_agent_id`
  - `run_id`, `event_id`（若 applied）
  - `assistant_text`（优先用 proposal.rationale 或 LLM 输出摘要）
  - `diff_summary`（added/modified/deleted count）
- context window：最近 N 轮（默认 8），超过则截断（M6 先做截断；摘要可后续引入）
- branch 切换时：创建新 session 或恢复该 branch 上一个 session（按 mtime 查找）

**Acceptance**
- 退出 TUI 再进入能恢复 session（至少恢复最近 N 轮 transcript）
- session history 会被注入到下一轮 agentic loop 的 prompt（可在 trace.jsonl 中验证）
- 切换 branch 后 session 隔离（不会把 branch A 的对话注入 branch B 的 prompt）

**Tests**
- Unit：session append/read/last_n 裁剪
- Unit：branch 绑定（不同 branch 的 session 不互相干扰）
- Integration：TUI 启动 → 发送 2 轮 → 退出 → 再启动，session 仍存在且可读

---

## M6-T5 — Auto-apply 模式（含安全阀 + undo 提示）

**Goal**
- 降低游戏节奏摩擦：让"探索/刷剧情"可以快，关键决策仍可 review。

**前置**
- **M6-Tundo 已完成**（undo 能真实回退 game/ 文件）
- M6-T2 已完成（agentic loop 可产出 proposal）

**Suggested changes**
- `src/neonrp/core/config.py`（新增配置项：`tui.auto_apply`）
- `src/neonrp/core/agent_runner.py`（`run_agent()` 接受 `auto_apply` 参数）
- `src/neonrp/tui/**`（toggle 快捷键；状态栏显示；apply 后 toast 提示 undo/save）

**Acceptance**
- auto-apply=on：每轮结束自动 apply（仅当 validation 成功且 permissions 通过）
- auto-apply=off：维持 M5 行为（preview-first）
- 任何失败都不会写 game/（仍保持审计日志 + 可操作错误）
- auto-apply 后 transcript 显示"已应用 (event_id: N)，按 u 撤回"

**Tests**
- Integration：auto-apply on → event_id 增长 → undo 后 world hash 回到 apply 前（依赖 M6-Tundo）
- Unit：配置加载与 TUI toggle 持久化

---

## M6-T6 — TUI Game Loop 整合（持续对话模式）

**Goal**
- 将 dispatcher + agentic loop + session + auto-apply 整合为"可持续游玩"的体验。

**前置**
- M6-T3（dispatcher）、M6-T4（session）、M6-T5（auto-apply）全部完成

**Suggested changes**
- `src/neonrp/tui/app.py`（输入→dispatcher→渲染）
- `src/neonrp/tui/panels/*`（transcript 渲染、HUD/status 扩展、错误视图）

**Acceptance**
- 用户只需在输入框输入自然语言并发送：即可完成路由、agentic loop、（可选）auto-apply、叙事渲染
- HUD 至少显示：branch、head_event、session_id、turn、auto-apply 状态
- `:` 命令与 command palette 仍可用（不被 game loop 干扰）
- 两轮以上连续输入/输出叙事连贯（session history 注入可验证）

**Tests**
- Textual：模拟按键发送两轮输入，验证 transcript 追加两轮、session 写入两条记录

---

## M6-T7 — LLM Streaming（可选/独立于 review gate）

**Goal**
- 逐 token/逐 chunk 渲染叙事输出，提升沉浸感与反馈速度。

**注意**：此任务独立于 review gate（M6-T8），可在 M6-T8 之前或之后实现，也可推迟到 M6.5。

**Suggested changes**
- `src/neonrp/core/llm.py`（扩展 stream 接口）
- `src/neonrp/core/llm_openai.py`（实现 streaming；兼容 tool calling 的中断/恢复）
- `src/neonrp/tui/**`（transcript 面板 incremental render）

**Acceptance**
- streaming 打开后：TUI 可逐步显示输出；tool call 期间暂停并显示"calling tools…"
- 若 provider 不支持 streaming：自动降级为非 streaming（不影响功能正确性）

**Tests**
- Unit：stub streaming（yield chunks）驱动 UI 渲染

---

## M6-T8 — 阶段 Review Gate

**Goal**
- 按 `docs/QUALITY_GATES.md` 跑完质量门并落盘审查产物到 `reviews/`。

**前置**
- M6-T6（TUI game loop 整合）已完成
- M6-T7（streaming）不阻塞此任务

**Acceptance**
- `reviews/` 下存在 M6 审查文件
- 修复后二次 `pytest` 全绿
- `docs/ROADMAP.md` 勾选完成项，`docs/PROGRESS.md` 追加记录
- 所有 review findings 记录在 `docs/PROGRESS.md` 中（含 disposition）
