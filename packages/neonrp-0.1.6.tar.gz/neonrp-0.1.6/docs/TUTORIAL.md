# NeonRP Tutorial: Your First Game

This tutorial walks you through creating and playing your first NeonRP text RPG, from initialization to your first turn.

## Prerequisites

- Python 3.11+
- NeonRP CLI installed:
```bash
uv tool install neonrp
# From local source (editable install — picks up code changes)
uv tool install -e /path/to/NeonRP
# Verify installation
neonrp --help
```

## Step 1: Initialize Your Project

Create a new directory and initialize NeonRP:

```bash
mkdir my-rpg
cd my-rpg
neonrp init
```

```bash
# for debug
cd my-rpg
uv run --project .. neonrp
```

This creates the `.neonrp/` directory structure:
```
my-rpg/
├── .neonrp/
│   ├── manifest.json    # Project state and entity index
│   └── config.json      # LLM provider settings
├── game/               # Your game entities (created later)
└── agents/              # AI agents (created later)
```

After `neonrp init`, you can already open `neonrp tui` and work in build mode. Packaged builtin skills are available automatically, so `game new` is optional unless you want the default starter world and play scaffold right away.

## Step 2: Create a Starter Game State

Scaffold a basic game state with the `game new` command:

```bash
neonrp game new
```

This creates starter entities in `game/`:
```
game/
├── player/
│   └── player.json      # The player character
├── town/
│   └── start-town.json  # Starting location
└── npc/
    └── old-sage.json    # A quest-giver NPC
```

## Step 3: Validate Your Game Data

Ensure all entities conform to the schema:

```bash
neonrp validate
```

Expected output:
```
Validation passed. 3 file(s) OK.
```

## Step 4: Build the Entity Index

Index your entities for fast retrieval:

```bash
neonrp index build
```

Expected output:
```
Index built: 3 entities indexed.
```

## Step 5: Explore Your Game Data

Search for entities:

```bash
# Find all entities
neonrp find

# Find by keyword
neonrp find "sage"

# Find by kind
neonrp find --kind npc

# Get context for a query
neonrp context "starting area" --limit 5
```

## Step 6: Create an Agent

Agents are AI personas that modify your game state. Create a narrator agent:

```bash
neonrp agent new narrator
```

This creates `agents/narrator/`:
```
agents/narrator/
├── agent.json    # Agent configuration
└── system.md     # System prompt
```

Edit `agents/narrator/system.md` to define the narrator's personality and rules.

## Step 7: Configure LLM Provider (Optional)

NeonRP now uses a named `models` registry.  
Default user config path is `~/.neonrp/config.json` (project-level `.neonrp/config.json` can override it).

Example with OpenRouter + reasoning config:

```json
{
  "llm": {
    "model_ref": "openrouter-grok-fast",
    "max_retries": 3,
    "max_context_chars": 100000
  },
  "tui": {
    "max_tool_rounds": 20
  },
  "models": {
    "stub": {
      "provider": "stub",
      "model": "stub"
    },
    "openrouter-grok-fast": {
      "provider": "openai",
      "base_url": "https://openrouter.ai/api/v1",
      "model": "x-ai/grok-4.1-fast",
      "api_key_env": "OPENROUTER_API_KEY",
      "extra": {
        "reasoning": {
          "effort": "high",
          "exclude": false,
          "enabled": true
        }
      }
    }
  }
}
```

Key fields:
- `llm.model_ref`: Active model name under `models`
- `models.<name>.provider`: one of `stub | openai | anthropic | glm | gemini`
- `models.<name>.base_url`: optional custom endpoint for OpenAI-compatible services
- `models.<name>.extra`: provider-specific request payload (passed through safely)
- `tui.max_tool_rounds`: max tool-calling rounds per turn

Create a `.env` file for API keys:
```
OPENAI_API_KEY=sk-...
OPENROUTER_API_KEY=sk-or-...
# or generic fallback:
NEONRP_LLM_API_KEY=...
```

You can also manage models in TUI with slash commands:
```bash
/auth add model <name> <provider> <base_url> <model> [api_key_env_or_key]
/models <name>
```

## Step 8: Run Your First Turn

Now you're ready to play! Run a query through the dispatcher:

```bash
# Without LLM (stub provider - for testing)
neonrp run "look around" --provider stub

# With LLM (single-turn mode)
neonrp run "look around"

# With auto-apply
neonrp run "talk to the old sage" --apply

# Multi-turn agentic mode (recommended for complex queries)
neonrp run "build a dungeon with traps and treasure" --agentic --apply
```

### Single-Turn vs Agentic Mode

| Mode | Flag | Description |
|------|------|-------------|
| **Single-turn** | (default) | Agent generates a proposal in one LLM call. Good for simple queries. |
| **Agentic** | `--agentic` | Multi-turn loop where the agent can use tools (read files, search entities, ask clarifying questions, delegate subtasks) before submitting a proposal. Better for complex or context-dependent queries. |

The TUI (`neonrp tui`) defaults to agentic mode.

The `run` command:
1. Selects an appropriate agent based on your query
2. Retrieves relevant context from your game state
3. Generates a proposal (game-state changes) — in agentic mode, the agent may make multiple tool calls first
4. Shows a diff preview
5. Optionally applies the changes (with `--apply`)

## Step 9: Save Your Progress

Create a checkpoint:

```bash
neonrp save my-first-save
```

This saves:
- Complete game state
- Event history
- Branch metadata

## Step 10: Experiment with Branches

Create a branch to try different paths:

```bash
# Create and switch to a new branch
neonrp branch try-stealing

# Make some changes...
neonrp run "steal from the merchant" --apply

# Undo if you don't like the result
neonrp undo

# Switch back to main
neonrp branch main
```

## Step 11: Use the TUI (Terminal UI)

For a richer experience, launch the TUI:

```bash
neonrp tui

# Resume the previous session for current branch
neonrp tui --continue

# Start a new session explicitly (default startup behavior)
neonrp tui --new

# Import a Tavern card before the first turn
neonrp tui --import-card character.png --import-id my-character

# Enable debug/diagnostic logs
neonrp tui --verbose
```

The TUI provides a conversational interface (M9+) similar to Claude Code:
- Natural language input with streaming responses
- Real-time tool use indicators
- Todo list display for multi-step planning (`[x]` / `[>]` / `[ ]`)
- Three conversation modes: `build`, `sandbox`, `play`
- Slash commands: `/mode`, `/clear`, `/files`, `/skills`, `/import`, `/sessions`, `/continue`, `/new`, `/verbose`, `/help`
- Session persistence across restarts (history is archived per branch)
- Top-right live token counters (local real-time estimation)
- `Esc` to interrupt in-flight model calls, `Ctrl+Q` for safe immediate quit

### Conversation Modes

The TUI supports three modes for different workflows:

**Build Mode (default)**
- Direct file operations (read/write/edit)
- Model generates natural narrative responses
- File changes automatically create events and checkpoints
- Use for: Game content building, content creation, editing entities

**Sandbox Mode**
- Changes go through proposal pipeline
- Model must call `submit_proposal` to apply changes
- Allows review before applying
- Use for: Testing changes, safe experimentation

**Play Mode**
- Direct file operations like Build mode
- Model acts as Game Master with immersive narrative
- Use for: Gameplay sessions

Switch modes with:
```
/mode build
/mode sandbox
/mode play
```

See [TUI_GUIDE.md](TUI_GUIDE.md) for full details.

### TodoWrite Minimal Example (for weaker models)

If your model often fails TodoWrite argument formatting, this minimal payload is valid:

```json
{"todos":[{"content":"Draft outline","status":"in_progress"}]}
```

## Understanding Entity Structure

Each entity in `game/` is a JSON file with this structure:

```json
{
  "id": "player",
  "kind": "player",
  "name": "Player",
  "tags": ["player"],
  "summary": "The player character.",
  "hp": 100,
  "max_hp": 100,
  "gold": 50,
  "level": 1,
  "location": "start-town",
  "inventory": []
}
```

Required fields:
- `id`: Unique identifier (kebab-case)
- `kind`: Entity type (`player`, `npc`, `town`, `item`, etc.)
- `name`: Display name

Optional fields vary by kind:
- Characters: `hp`, `max_hp`, `gold`, `level`, `location`, `inventory`
- Locations: `connections`, `npcs`, `items_available`
- Items: `value`, `weight`, `effects`

## Next Steps

- Read [CLI_REFERENCE.md](CLI_REFERENCE.md) for all commands
- Read [TUI_GUIDE.md](TUI_GUIDE.md) for the terminal UI
- Explore `examples/starter-game/` for a richer game template
- Check [ARCHITECTURE.md](ARCHITECTURE.md) for system design

## Troubleshooting

### "neonrp: command not found" or "not recognized"
The Python Scripts directory may not be in your PATH. Workarounds:
```bash
# Use python -m instead
python -m neonrp init

# Or if developing locally with uv
uv run neonrp init
```

### "failed to locate pyvenv.cfg" (Windows + uv tool install)
This is a uv bug on Windows where `uv tool install` creates tool venvs without a `pyvenv.cfg` file. Fix by creating it manually:
```bash
# Find your uv tool directory
uv tool dir
# e.g. C:\Users\<you>\AppData\Roaming\uv\tools

# Find which Python uv is using
uv python list --only-installed

# Create pyvenv.cfg in the tool venv
# File: <uv-tool-dir>\neonrp\pyvenv.cfg
# Contents (adjust paths to match your system):
#   home = C:\Users\<you>\AppData\Roaming\uv\python\cpython-3.13.5-windows-x86_64-none
#   include-system-site-packages = false
#   version = 3.13.5
#   executable = C:\Users\<you>\AppData\Roaming\uv\python\cpython-3.13.5-windows-x86_64-none\python.exe
```
Alternatively, skip the tool install and use `uv run` directly:
```bash
uv run --project /path/to/NeonRP neonrp <command>
```

### "Not initialized" error
Run `neonrp init` in your project directory.

### "Index is empty" error
Run `neonrp index build` after creating game entities.

### Validation errors
Check your JSON syntax and ensure required fields (`id`, `kind`, `name`) are present.

### LLM errors
Verify your API key is set in `.env` or environment variables.

For transient network failures (for example, `Network connection lost`), NeonRP now retries automatically with backoff:
`2s -> 7s -> 15s -> 30s`, then stops and returns an error.

