#!/usr/bin/env sh
# WorldLines / NeonRP bootstrap installer.
#
# Usage:
#   curl -LsSf https://worldlines.gg/install.sh | sh
#
# What it does:
#   1. Ensures `uv` is installed (fetches it from astral.sh if missing).
#   2. Installs `worldlines` (which pins the matching `neonrp` runtime).
#   3. Prints a quick-start hint.
#
# Design notes:
#   - POSIX-sh compatible (no bash-isms) so macOS + minimal Linux shells work.
#   - `set -e` so partial failures don't leave the user thinking it worked.
#   - Non-interactive; prints what it's doing so the user can audit via
#     `curl ... | less` before piping to sh.

set -eu

PACKAGE="${WORLDLINES_PACKAGE:-worldlines}"

log() { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m  %s\n' "$*" >&2; }
die() { printf '\033[1;31mxx\033[0m  %s\n' "$*" >&2; exit 1; }

need_cmd() {
    command -v "$1" >/dev/null 2>&1 || die "required command '$1' not found on PATH"
}

# Step 1 — ensure uv (astral's Python/tool installer).
if command -v uv >/dev/null 2>&1; then
    log "uv already installed ($(uv --version))"
else
    log "installing uv from astral.sh"
    need_cmd curl
    curl -LsSf https://astral.sh/uv/install.sh | sh

    # uv's installer drops the binary in ~/.local/bin (Linux/macOS) or
    # ~/.cargo/bin on some setups; make sure it's on PATH for this shell.
    case ":$PATH:" in
        *":$HOME/.local/bin:"*) : ;;
        *) export PATH="$HOME/.local/bin:$PATH" ;;
    esac
    case ":$PATH:" in
        *":$HOME/.cargo/bin:"*) : ;;
        *) export PATH="$HOME/.cargo/bin:$PATH" ;;
    esac

    command -v uv >/dev/null 2>&1 || die "uv installed but not found on PATH; open a new shell and re-run this script"
fi

# Step 1.5 — optional China mirror. Mainland networks often throttle
# PyPI's default CDN; pass `CHINA_MIRROR=1` to route uv through TUNA.
# Respects an explicitly-set UV_DEFAULT_INDEX (user override wins).
if [ "${CHINA_MIRROR:-0}" = "1" ] && [ -z "${UV_DEFAULT_INDEX:-}" ]; then
    export UV_DEFAULT_INDEX="https://pypi.tuna.tsinghua.edu.cn/simple"
    log "CHINA_MIRROR=1 → using Tsinghua PyPI mirror"
fi

# Step 2 — install the CLI via uv tool.
log "installing $PACKAGE"
uv tool install --force "$PACKAGE"

# Step 3 — quick-start hint.
cat <<EOF

\033[1;32m✓ $PACKAGE installed\033[0m

Next steps:

  $PACKAGE              # launch the guided world picker
  neonrp --help         # full engine CLI
  neonrp self-update    # check for updates

Docs: https://github.com/LudicDynamics/WorldLines

EOF
