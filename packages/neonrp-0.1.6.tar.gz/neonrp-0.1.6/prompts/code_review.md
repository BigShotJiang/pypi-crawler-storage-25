# NeonRP Code Review Prompt (for opencode run)

You are a senior engineer reviewing a file-backed RPG CLI built on a three-layer architecture (Agent → Engine → Storage).

## Goals
- Prevent destructive or unsafe file operations.
- Ensure save/load/undo/branch semantics are correct and reproducible.
- Enforce append-only event logging.
- Enforce agent permission boundaries and proposal validation.
- Keep code testable and extendable across the Agent/Engine/Storage layers.

## What to review

### 1) File safety
- No accidental deletion/overwrite of user world data.
- Writes are explicit and confined to intended paths.
- **Atomic writes**: All file updates (manifests, saves, apply) MUST use the write-to-temp-then-rename pattern (`os.replace`) to prevent corruption on crash.
- **Staging isolation**: Agent apply MUST operate on a staging copy of `world/`; real `world/` is untouched until validation passes.

### 2) Permission boundaries
- Agent writes MUST be checked against `write_globs` and `deny_globs` (deny takes priority).
- Path traversal (`..`) MUST be rejected.
- `deny_globs` MUST include `.neonrp/**` and `agents/**` by default.
- Permission errors MUST include: agent_id, target path, matched/unmatched glob, and fix suggestion.

### 3) Proposal & ops validation
- Proposal MUST include `proposal_version`, `agent_id`, `run_id`, `branch`, `base_head_event`, `query`, `ops`.
- `upsert_text` ops MUST have `content`; `delete` ops MUST NOT have `content`.
- All op paths MUST be relative (no leading `/`) and MUST NOT contain `..`.
- `base_head_event` MUST match current `head_event`; mismatch → reject (stale proposal).

### 4) Correctness
- save/load restores identical state (content hash or byte-level check).
- undo reliably returns to previous turn state.
- branch isolation is real (no cross-contamination).
- Schema validation (`validate_game_data`) catches structural and constraint errors with actionable, file-scoped messages.
- Entity indexing handles partial failure: invalid entities are skipped (not all-or-nothing), valid entities are indexed, warnings are emitted.
- `find`/`context` ranking is stable and deterministic (same input → same output).

### 5) Auditability
- Events are append-only and sufficient to debug.
- Agent apply events include `type=agent`, `actor=<agent_id>`, and payload with `run_id`, `query`, `ops_count`, `applied_paths`.
- Agent runs log to `.neonrp/logs/agents/<run_id>/` with: `input.json`, `proposal.json`, `diff.patch`, `validation.json`, `apply.json`.
- `manifest.branches[current].head_event` increments after each successful apply.

### 6) Testing (three layers)
- **Unit**: Core function correctness (storage, validation, permissions, proposal parsing, diff generation, event append).
- **Integration**: CLI command chains via `CliRunner` (init → validate → index → find/context; agent new → run → apply).
- **E2E**: Subprocess invocation of `neonrp` commands, verifying exit codes, stdout/stderr, and filesystem side effects.
- Tests cover failure modes: missing files, corrupt saves, invalid schema, permission violations, path traversal, stale proposals.
- Tests verify idempotency where specified (e.g. `init`, `delete` on missing file).

### 7) Output & CLI conventions
- All commands support `--json` for structured output (machine-consumable).
- Exit codes: `0` success, `1` user/validation/permission error, `2` system error.
- Error messages are actionable (include file path, json path, fix suggestion where applicable).

### 8) Maintainability
- Clear interfaces, small modules, docstrings where needed.
- Errors are actionable.
- Pydantic v2 conventions: `model_config = ConfigDict(...)`, `@field_serializer`, `datetime.now(UTC)`.
- No overengineering: stubs anticipate later milestones without implementing them.

## Output format
- Summary (overall risk level: Low/Medium/High)
- Must-fix items (blocking)
- Should-fix items (non-blocking)
- Nice-to-have improvements
- Suggested tests to add

