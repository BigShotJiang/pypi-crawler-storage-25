"""WorldLines MCP server — exposes game tools via SSE for Claude Code.

Embeds a FastMCP server in a daemon thread so the TUI can
accept tool calls from Claude Code (Opus) over ``http://127.0.0.1:{port}/sse``.
"""

from __future__ import annotations

import json
import logging
import socket
import threading
from pathlib import Path
from typing import Any, Callable

from mcp.server.fastmcp import FastMCP

from neonrp.core.manifest import Manifest
from neonrp.core.paths import (
    get_game_dir,
    get_manifest_path,
    get_neonrp_dir,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _find_free_port() -> int:
    """Find a free TCP port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _load_manifest(root: Path) -> Manifest:
    mp = get_manifest_path(root)
    if mp.exists():
        return Manifest(**json.loads(mp.read_text(encoding="utf-8")))
    return Manifest()


def _build_instructions(root: Path, manifest: Manifest) -> str:
    """Build dynamic MCP instructions from manifest."""
    branch = manifest.current_branch
    branch_meta = manifest.branches.get(branch)
    head = branch_meta.head_event if branch_meta else -1
    entity_count = len(manifest.entities)

    kinds: dict[str, int] = {}
    for rec in manifest.entities.values():
        kinds[rec.kind] = kinds.get(rec.kind, 0) + 1

    kinds_summary = ", ".join(f"{k}({v})" for k, v in sorted(kinds.items())) or "(none)"

    # Read world name from runtime contract if available
    world_name = root.name
    rc_path = get_neonrp_dir(root) / "runtime_contract.json"
    if rc_path.exists():
        try:
            rc = json.loads(rc_path.read_text(encoding="utf-8"))
            world_name = rc.get("world_name", world_name) or world_name
        except Exception:
            pass

    return (
        f"You are the Game Master for '{world_name}'.\n"
        f"Branch: {branch} | Head event: {head} | Entities: {entity_count}\n"
        f"Entity kinds: {kinds_summary}\n\n"
        "## Available Tools\n"
        "- get_game_state: Overview of the world\n"
        "- list_entities: Browse entities by kind or keyword\n"
        "- read_entity: Read a single entity's full data\n"
        "- read_context: Semantic search for relevant entities\n"
        "- update_entity: Create or update an entity\n"
        "- narrate: Send narrative text to the player's TUI\n"
        "- save_game: Create a checkpoint/save\n\n"
        "## Guidelines\n"
        "- Always read entities before modifying them.\n"
        "- Use narrate() to deliver story text — this is what the player sees.\n"
        "- Keep entity data consistent with the world's lore.\n"
        "- When the player asks about the world, use read_context to find relevant entities.\n"
    )


# ---------------------------------------------------------------------------
# WorldLinesMCPServer
# ---------------------------------------------------------------------------

class WorldLinesMCPServer:
    """Embeddable MCP server exposing WorldLines game tools.

    Parameters
    ----------
    root : Path
        Game project root directory (where ``.neonrp/`` lives).
    port : int | None
        TCP port for the SSE endpoint.  ``None`` → pick a free port.
    on_narrate : callback(speaker, text)
        Called when the ``narrate`` tool fires.
    on_tool_use : callback(name, params)
        Called when any tool is invoked (before execution).
    on_tool_result : callback(name, params, result)
        Called when any tool completes.
    """

    def __init__(
        self,
        root: Path,
        port: int | None = None,
        on_narrate: Callable[[str, str], None] | None = None,
        on_tool_use: Callable[[str, dict[str, Any]], None] | None = None,
        on_tool_result: Callable[[str, dict[str, Any], str], None] | None = None,
    ) -> None:
        self._root = root
        self._port = port or _find_free_port()
        self._on_narrate = on_narrate
        self._on_tool_use = on_tool_use
        self._on_tool_result = on_tool_result
        self._thread: threading.Thread | None = None
        self._mcp: FastMCP | None = None

    # -- public API ---------------------------------------------------------

    @property
    def port(self) -> int:
        return self._port

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self._port}/sse"

    def start(self) -> None:
        """Start the MCP SSE server on a daemon thread."""
        mcp = self._build_server()
        self._mcp = mcp

        def _run() -> None:
            try:
                mcp.run(transport="sse")
            except Exception:
                logger.exception("MCP server crashed")

        self._thread = threading.Thread(target=_run, name="worldlines-mcp", daemon=True)
        self._thread.start()
        logger.info("MCP server started on %s", self.url)
        self.write_server_info()

    def stop(self) -> None:
        """Stop the MCP server (best-effort; daemon thread will die with process)."""
        self._thread = None
        self._mcp = None

    def write_server_info(self) -> None:
        """Write connection info to ``.neonrp/mcp_server.json``."""
        info_path = get_neonrp_dir(self._root) / "mcp_server.json"
        info_path.parent.mkdir(parents=True, exist_ok=True)
        data = {"url": self.url, "port": self._port}
        info_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    # -- tool wrapper -------------------------------------------------------

    def _wrap_tool(self, tool_name: str, fn: Callable) -> Callable:
        """Wrap a tool function with on_tool_use / on_tool_result callbacks."""
        on_use = self._on_tool_use
        on_result = self._on_tool_result

        def wrapper(**kwargs: Any) -> Any:
            if on_use:
                try:
                    on_use(tool_name, kwargs)
                except Exception:
                    pass
            try:
                result = fn(**kwargs)
            except Exception as exc:
                result_str = f"Error: {exc}"
                if on_result:
                    try:
                        on_result(tool_name, kwargs, result_str)
                    except Exception:
                        pass
                raise
            result_str = result if isinstance(result, str) else json.dumps(result, default=str, ensure_ascii=False)
            if on_result:
                try:
                    on_result(tool_name, kwargs, result_str)
                except Exception:
                    pass
            return result

        # Preserve signature for FastMCP introspection
        import functools
        functools.update_wrapper(wrapper, fn)
        return wrapper

    # -- server construction ------------------------------------------------

    def _build_server(self) -> FastMCP:
        manifest = _load_manifest(self._root)
        instructions = _build_instructions(self._root, manifest)

        mcp = FastMCP(
            "worldlines",
            instructions=instructions,
            host="127.0.0.1",
            port=self._port,
        )
        root = self._root

        # ── get_game_state ─────────────────────────────────────────────
        @mcp.tool()
        def get_game_state() -> str:
            """Return a summary of the current game world: branch, event count, entity kinds and counts."""
            m = _load_manifest(root)
            branch = m.current_branch
            bm = m.branches.get(branch)
            head = bm.head_event if bm else -1

            kinds: dict[str, int] = {}
            for rec in m.entities.values():
                kinds[rec.kind] = kinds.get(rec.kind, 0) + 1

            return json.dumps({
                "branch": branch,
                "head_event": head,
                "entity_count": len(m.entities),
                "kinds": kinds,
                "entity_ids": list(m.entities.keys())[:50],
            }, ensure_ascii=False, indent=2)

        # ── list_entities ──────────────────────────────────────────────
        @mcp.tool()
        def list_entities(kind: str = "", query: str = "") -> str:
            """List entities, optionally filtered by kind or keyword query.

            Args:
                kind: Filter by entity kind (e.g. 'character', 'location'). Empty = all kinds.
                query: Keyword filter on entity name/tags. Empty = no filter.
            """
            m = _load_manifest(root)
            results = []
            query_lower = query.lower()
            for eid, rec in m.entities.items():
                if kind and rec.kind != kind:
                    continue
                if query_lower:
                    haystack = f"{rec.name} {' '.join(rec.tags or [])}".lower()
                    if query_lower not in haystack:
                        continue
                results.append({
                    "id": eid,
                    "kind": rec.kind,
                    "name": rec.name,
                    "tags": rec.tags or [],
                    "summary": rec.summary or "",
                })
            return json.dumps(results, ensure_ascii=False, indent=2)

        # ── read_entity ────────────────────────────────────────────────
        @mcp.tool()
        def read_entity(entity_id: str) -> str:
            """Read the full JSON data of a single entity.

            Args:
                entity_id: The entity ID to read.
            """
            m = _load_manifest(root)
            rec = m.entities.get(entity_id)
            if not rec:
                return json.dumps({"error": f"Entity '{entity_id}' not found"})
            entity_path = root / rec.path
            if not entity_path.exists():
                return json.dumps({"error": f"Entity file missing: {rec.path}"})
            return entity_path.read_text(encoding="utf-8")

        # ── read_context ───────────────────────────────────────────────
        @mcp.tool()
        def read_context(query: str, limit: int = 5) -> str:
            """Semantic search for entities relevant to a query.

            Args:
                query: Natural language query describing what you're looking for.
                limit: Maximum number of results (default 5).
            """
            from neonrp.core.retrieval import retrieve_context
            results = retrieve_context(root, query, max_results=limit)
            # Slim down for transport
            slim = []
            for r in results:
                slim.append({
                    "id": r.get("id", ""),
                    "kind": r.get("kind", ""),
                    "name": r.get("data", {}).get("name", r.get("id", "")),
                    "score": round(r.get("score", 0), 3),
                    "summary": r.get("data", {}).get("summary", ""),
                })
            return json.dumps(slim, ensure_ascii=False, indent=2)

        # ── update_entity ──────────────────────────────────────────────
        @mcp.tool()
        def update_entity(entity_id: str, kind: str, data: str) -> str:
            """Create or update a game entity.

            Args:
                entity_id: Entity ID (e.g. 'npc-merchant-bob').
                kind: Entity kind (e.g. 'character', 'location', 'item').
                data: Full entity JSON string. Must include at minimum: id, kind, name.
            """
            from neonrp.core.storage import atomic_write_json as _aw
            from neonrp.core.indexing import refresh_manifest_index

            try:
                entity_data = json.loads(data) if isinstance(data, str) else data
            except json.JSONDecodeError as exc:
                return json.dumps({"error": f"Invalid JSON: {exc}"})

            # Ensure required fields
            entity_data.setdefault("id", entity_id)
            entity_data.setdefault("kind", kind)
            if "name" not in entity_data:
                entity_data["name"] = entity_id

            game_dir = get_game_dir(root)
            entity_path = game_dir / kind / f"{entity_id}.json"
            entity_path.parent.mkdir(parents=True, exist_ok=True)
            _aw(entity_path, entity_data)

            # Refresh manifest index
            try:
                refresh_manifest_index(root)
            except Exception as exc:
                logger.warning("Failed to refresh manifest index: %s", exc)

            return json.dumps({"status": "ok", "entity_id": entity_id, "path": str(entity_path.relative_to(root))})

        # ── narrate ────────────────────────────────────────────────────
        @mcp.tool()
        def narrate(text: str, speaker: str = "Narrator") -> str:
            """Send narrative text to the player's TUI display.

            Args:
                text: The narrative text to display (supports markdown).
                speaker: Speaker label (default 'Narrator').
            """
            if self._on_narrate:
                try:
                    self._on_narrate(speaker, text)
                except Exception:
                    logger.exception("on_narrate callback failed")
            return json.dumps({"status": "ok", "length": len(text)})

        # ── save_game ──────────────────────────────────────────────────
        @mcp.tool()
        def save_game(label: str = "") -> str:
            """Create a game checkpoint/save.

            Args:
                label: Optional label for this save. Empty = auto-generated.
            """
            from neonrp.core.checkpoint import create_checkpoint

            m = _load_manifest(root)
            branch = m.current_branch
            bm = m.branches.get(branch)
            event_id = (bm.head_event if bm else -1) + 1

            cp = create_checkpoint(root, branch, event_id)
            if cp is None:
                return json.dumps({"error": "Failed to create checkpoint"})

            return json.dumps({
                "status": "ok",
                "branch": branch,
                "event_id": event_id,
                "label": label or f"save-{event_id}",
            })

        return mcp
