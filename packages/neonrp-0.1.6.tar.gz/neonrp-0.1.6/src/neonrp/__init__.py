"""NeonRP — file-backed text RPG engine with agent-driven storytelling."""

__version__ = "0.1.6"
