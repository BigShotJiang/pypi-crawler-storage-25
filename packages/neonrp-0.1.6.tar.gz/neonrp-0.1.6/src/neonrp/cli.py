from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import click

from neonrp.commands.init import init
from neonrp.commands.run import run
from neonrp.commands.save import save, load
from neonrp.commands.branch import branch, undo, redo
from neonrp.commands.validate import validate
from neonrp.commands.index import index
from neonrp.commands.find import find
from neonrp.commands.context import context
from neonrp.commands.agent import agent
from neonrp.commands.import_cmd import import_group
from neonrp.commands.game import game
from neonrp.commands.sandbox import sandbox_group
from neonrp.commands.replay import replay_group
from neonrp.commands.mcp import mcp
from neonrp.commands.tui import tui
from neonrp.commands.self_update import self_update
from neonrp.commands.export_world import export_world, load_world


class _AppendPerEmitFileHandler(logging.Handler):
    """Append one log record per emit and close immediately.

    This avoids keeping long-lived file handles (notably on Windows) so
    `llm_raw.jsonl` can be inspected/rotated while TUI is running.
    """

    def __init__(self, filename: str | Path, encoding: str = "utf-8") -> None:
        super().__init__()
        target = Path(filename).resolve()
        # Keep FileHandler-compatible attribute name for existing tests/helpers.
        self.baseFilename = str(target)
        self._target_path = target
        self._encoding = encoding

    def emit(self, record: logging.LogRecord) -> None:
        try:
            rendered = self.format(record)
            with self._target_path.open("a", encoding=self._encoding, newline="\n") as f:
                f.write(rendered)
                f.write("\n")
        except Exception:
            self.handleError(record)


def _handler_target_path(handler: logging.Handler) -> str:
    base = getattr(handler, "baseFilename", "")
    if isinstance(base, str) and base:
        return str(Path(base).resolve())
    return ""


def _setup_logging(root: Path) -> None:
    """Configure project logging outputs.

    - Human-readable runtime log: ``.neonrp/logs/neonrp.log``
    - Raw LLM audit log (JSONL): ``.neonrp/logs/llm_raw.jsonl``
    """
    try:
        from neonrp.core.paths import get_neonrp_dir

        log_dir = get_neonrp_dir(root) / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "neonrp.log"
        resolved_log = str(log_file.resolve())
        raw_file = log_dir / "llm_raw.jsonl"
        resolved_raw_log = str(raw_file.resolve())

        root_logger = logging.getLogger("neonrp")
        # Default to INFO for lower runtime noise. Opt into DEBUG explicitly.
        configured_level = str(os.getenv("NEONRP_LOG_LEVEL", "INFO")).upper().strip()
        level = getattr(logging, configured_level, logging.INFO)
        root_logger.setLevel(level)
        root_logger.propagate = False

        # Idempotent setup: avoid stacking duplicate file handlers when CLI is
        # invoked repeatedly in-process (e.g. TUI uses CliRunner.invoke()).
        has_main_handler = False
        for existing in root_logger.handlers:
            existing_path = _handler_target_path(existing)
            if existing_path and existing_path == resolved_log:
                has_main_handler = True
                break

        if not has_main_handler:
            handler = logging.FileHandler(resolved_log, encoding="utf-8")
            handler.setFormatter(
                logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
            )
            root_logger.addHandler(handler)

        # Dedicated raw JSONL logger for exact LLM request/response auditing.
        raw_logger = logging.getLogger("neonrp.raw_json")
        raw_logger.setLevel(logging.INFO)
        raw_logger.propagate = False
        has_raw_handler = False
        for existing in raw_logger.handlers:
            existing_path = _handler_target_path(existing)
            if existing_path and existing_path == resolved_raw_log:
                has_raw_handler = True
                break
        if not has_raw_handler:
            raw_handler = _AppendPerEmitFileHandler(resolved_raw_log, encoding="utf-8")
            raw_handler.setFormatter(logging.Formatter("%(message)s"))
            raw_logger.addHandler(raw_handler)
    except Exception:
        pass  # Logging is best-effort; don't crash CLI


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """NeonRP CLI entry point."""
    from neonrp.core.config import load_dotenv

    load_dotenv(Path.cwd())
    _setup_logging(Path.cwd())

    # If no command given, launch TUI (like Claude Code)
    if ctx.invoked_subcommand is None:
        ctx.invoke(tui)


cli.add_command(init)
cli.add_command(run)
cli.add_command(save)
cli.add_command(load)
cli.add_command(branch)
cli.add_command(undo)
cli.add_command(redo)
cli.add_command(validate)
cli.add_command(index)
cli.add_command(find)
cli.add_command(context)
cli.add_command(agent)
cli.add_command(import_group)
cli.add_command(game)
cli.add_command(sandbox_group)
cli.add_command(replay_group)
cli.add_command(mcp)
cli.add_command(tui)
cli.add_command(self_update)
cli.add_command(export_world)
cli.add_command(load_world)


# ---------------------------------------------------------------------------
# WorldLines CLI entry point
# ---------------------------------------------------------------------------


def _worldlines_prompt_choice(prompt: str, options: list[str], allow_back: bool = False) -> int | None:
    """Simple numbered choice prompt.

    Returns 0-based index into *options*, or None if user picks '返回'.
    When allow_back is True, '返回' is shown as the last numbered item.
    """
    click.echo()
    click.echo(prompt)
    click.echo()
    for i, opt in enumerate(options, 1):
        click.echo(f"  {i}. {opt}")
    back_num = len(options) + 1
    if allow_back:
        click.echo(f"  {back_num}. 返回")
    click.echo()

    while True:
        raw = click.prompt(">", type=str, default="1").strip()
        if not raw:
            continue
        try:
            choice = int(raw)
        except ValueError:
            click.echo("  请输入数字。")
            continue
        if allow_back and choice == back_num:
            return None
        if 1 <= choice <= len(options):
            return choice - 1
        click.echo(f"  请输入 1-{len(options) + (1 if allow_back else 0)}。")


def _worldlines_init_and_launch(
    world_id: str,
    preset_id: str,
    mode: str = "play",
    player_profile: dict[str, Any] | None = None,
) -> None:
    """Initialize a new game directory and launch the TUI."""
    import json
    from neonrp.worlds import get_world, create_game_dir
    from neonrp.presets import build_config_dict

    world = get_world(world_id)
    template_name = world["template"]

    # 1. Create game directory
    game_dir = create_game_dir(world_id)
    click.echo(f"\n  Initializing {world['name']} ({world['name_local']})...")

    # 2. cd into the game directory (NeonRP operates on cwd)
    import os
    os.chdir(game_dir)

    # 3. Run init logic (create .neonrp/, manifest, config)
    from neonrp.core.storage import ensure_dirs, atomic_write_json
    from neonrp.core.manifest import Manifest
    from neonrp.core.paths import get_manifest_path, get_neonrp_dir

    ensure_dirs(game_dir)
    manifest_path = get_manifest_path(game_dir)
    manifest = Manifest()
    atomic_write_json(manifest_path, manifest.model_dump())

    # 4. Write config from preset
    config_dict = build_config_dict(preset_id)
    _tag_worldlines_preset(config_dict, preset_id)
    config_path = get_neonrp_dir(game_dir) / "config.json"
    atomic_write_json(config_path, config_dict)

    # 5. Run game new logic (scaffold game entities + agents from template)
    from neonrp.commands.game import create_rule_samples, create_skill_samples
    from neonrp.core.paths import get_data_dir_name
    from neonrp.core.proposal import UpsertTextOp
    from neonrp.core.system_proposal import apply_system_proposal
    from neonrp.core.template_assets import (
        bootstrap_claude_workspace,
        copy_agent_from_template,
        copy_game_support_files_from_template,
        copy_runtime_contract_from_template,
        list_template_agent_ids,
        load_game_template,
    )

    data_dir_name = get_data_dir_name(game_dir)
    template_entities = load_game_template(template_name, data_dir_name)

    ops = []
    for rel_path, data in template_entities:
        content = json.dumps(data, indent=2, ensure_ascii=False)
        ops.append(UpsertTextOp(path=rel_path, content=content))

    result = apply_system_proposal(
        game_dir,
        ops,
        rationale=f"WorldLines: create game from template '{template_name}'",
        command="worldlines_init",
    )
    if not getattr(result, "success", False):
        err = getattr(result, "error", "") or ""
        raise click.ClickException(
            f"Template scaffold failed: {err.strip() or 'unknown'}"
        )

    # Copy agents
    for agent_id in list_template_agent_ids(template_name):
        copy_agent_from_template(
            game_dir,
            template_name=template_name,
            agent_id=agent_id,
            data_dir_name=data_dir_name,
            force=True,
        )

    # Copy runtime contract
    copy_runtime_contract_from_template(
        game_dir,
        template_name=template_name,
        data_dir_name=data_dir_name,
        force=True,
    )
    copy_game_support_files_from_template(
        game_dir,
        template_name=template_name,
        data_dir_name=data_dir_name,
        force=True,
    )

    # Create rule/skill samples
    create_rule_samples(game_dir)
    create_skill_samples(game_dir)

    # 6. Apply player profile if provided
    if player_profile:
        _apply_player_profile(game_dir, player_profile)

    if mode == "mcp":
        bootstrap_claude_workspace(game_dir, template_name=template_name, force=True)

    click.echo("  Done.\n")

    # 7. Launch TUI — inject a localized "start the game" message so the
    # agent opens the scene in the user's language without them typing first.
    _setup_logging(game_dir)
    from neonrp.tui.app import run_tui

    startup_commands = _build_startup_handoff(player_profile)
    run_tui(root=game_dir, mode=mode, startup_commands=startup_commands)


def _tag_worldlines_preset(config_dict: dict[str, Any], preset_id: str) -> None:
    """Stamp the active WorldLines preset onto the game's config.json.

    We can't rely on `llm.model_ref` to recover this — Claude Code preset
    writes `model_ref = "stub"`, custom user models use their own id. Store
    the preset id under `worldlines.last_preset_id` so the launcher's
    continue flow can pre-select it next time.
    """
    wl = config_dict.get("worldlines") if isinstance(config_dict.get("worldlines"), dict) else {}
    wl["last_preset_id"] = str(preset_id or "").strip()
    config_dict["worldlines"] = wl


def read_worldlines_last_preset(game_path: Path) -> str | None:
    """Read the last preset id used for this saved game, if recorded."""
    import json as _json

    cfg_path = game_path / ".neonrp" / "config.json"
    if not cfg_path.exists():
        return None
    try:
        data = _json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        return None
    wl = data.get("worldlines") if isinstance(data, dict) else None
    if not isinstance(wl, dict):
        return None
    preset_id = str(wl.get("last_preset_id", "") or "").strip()
    return preset_id or None


def _build_startup_handoff(
    player_profile: dict[str, Any] | None,
    *,
    world_intent: dict[str, Any] | None = None,
) -> list[str]:
    """Return a list of localized opening messages for the TUI to inject.

    Order of concatenation in the single opening message:
    - world build/import handoff (when world_intent present)
    - character create/import handoff (when player_profile is a pending marker)
    - start-game prompt (always)
    """
    from neonrp.tui.i18n import get_message, resolve_locale

    locale = resolve_locale()
    parts: list[str] = []

    if world_intent:
        action = world_intent.get("action")
        if action == "create":
            parts.append(
                get_message(locale, "handoff.world_create").format(
                    prompt=(world_intent.get("prompt") or "").strip()
                )
            )
        elif action == "import":
            parts.append(
                get_message(locale, "handoff.world_import").format(
                    path=(world_intent.get("source_path") or "").strip()
                )
            )

    if isinstance(player_profile, dict):
        if player_profile.get("__pending_ai__"):
            parts.append(
                get_message(locale, "handoff.character_create").format(
                    prompt=(player_profile.get("summary") or "").strip()
                )
            )
        elif player_profile.get("__pending_import__"):
            parts.append(
                get_message(locale, "handoff.character_import").format(
                    path=(player_profile.get("source_path") or "").strip()
                )
            )
        else:
            # Regular saved-profile or manual-entry persona: ask the agent to
            # translate it into the template's actual player schema (stats,
            # location, inventory, world-specific flags) since our 6-field
            # merge only covers universal persona fields.
            import json as _json

            persona_clean = {
                k: v for k, v in player_profile.items() if not k.startswith("__")
            }
            if persona_clean:
                parts.append(
                    get_message(locale, "handoff.character_adapt").format(
                        persona_json=_json.dumps(persona_clean, ensure_ascii=False, indent=2)
                    )
                )

    # Always end with the language-specific "start the game" cue.
    parts.append(get_message(locale, "handoff.start_game"))

    # One single composite message — the agent sees a coherent brief.
    return ["\n\n".join(parts)]


def _apply_player_profile(game_dir: Path, profile: dict[str, Any]) -> None:
    """Merge player profile into the game's player.json after scaffolding.

    If the profile carries a `__pending_ai__` / `__pending_import__` marker
    set by the TUI launcher, write a handoff brief instead and let the
    relevant built-in skill (player-character-authoring /
    character-card-authoring) finish the authoring inside the running TUI.
    """
    import json
    from neonrp.players import merge_player_into_template
    from neonrp.core.paths import get_game_dir as _get_gd

    if profile.get("__pending_ai__") or profile.get("__pending_import__"):
        brief_path = game_dir / ".neonrp" / "worldlines_character_intent.json"
        brief_path.parent.mkdir(parents=True, exist_ok=True)
        brief_path.write_text(
            json.dumps(profile, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        return

    gd = _get_gd(game_dir)
    player_path = gd / "player" / "player.json"
    if not player_path.exists():
        # Try to find any player entity
        player_dir = gd / "player"
        if player_dir.exists():
            candidates = list(player_dir.glob("*.json"))
            if candidates:
                player_path = candidates[0]

    if player_path.exists():
        template_player = json.loads(player_path.read_text(encoding="utf-8"))
        merged = merge_player_into_template(template_player, profile)
        player_path.write_text(
            json.dumps(merged, indent=2, ensure_ascii=False), encoding="utf-8"
        )


def _worldlines_select_player(preset_id: str) -> dict[str, Any] | None:
    """Prompt user to select, create, or edit a player profile.

    Returns the chosen profile dict, or None to skip (use template default).
    """
    from neonrp.players import (
        list_players,
        prompt_create_player,
        prompt_edit_player,
        prompt_ai_create_player,
    )

    players = list_players()

    if not players:
        idx = _worldlines_prompt_choice(
            "  角色：",
            ["用一句话创建角色（AI 生成）", "手动填写创建", "跳过（使用默认角色）"],
            allow_back=True,
        )
        if idx is None:
            return None
        if idx == 0:
            return prompt_ai_create_player(preset_id)
        if idx == 1:
            return prompt_create_player()
        return None  # skip

    # Show existing profiles + create/skip options
    options = [f"{p['name']}  {p['summary'][:30] if p['summary'] else ''}" for p in players]
    options.append("用一句话创建角色（AI 生成）")
    options.append("手动填写创建")
    options.append("跳过（使用默认角色）")

    idx = _worldlines_prompt_choice("  选择角色：", options, allow_back=True)
    if idx is None:
        return None

    if idx < len(players):
        # Selected existing — offer to use or edit
        selected = players[idx]
        click.echo(f"\n  角色: {selected['name']}")
        if selected.get("summary"):
            click.echo(f"  简介: {selected['summary']}")

        action_idx = _worldlines_prompt_choice(
            "  操作：", ["使用此角色", "编辑后使用"], allow_back=True
        )
        if action_idx is None:
            return _worldlines_select_player(preset_id)  # re-select
        if action_idx == 0:
            return selected["data"]
        return prompt_edit_player(selected["data"])

    # Extra options after saved profiles
    extra_start = len(players)
    if idx == extra_start:
        return prompt_ai_create_player(preset_id)
    if idx == extra_start + 1:
        return prompt_create_player()

    return None  # skip


def _resolve_mode(preset_id: str) -> str:
    """Determine TUI mode from the selected preset."""
    from neonrp.presets import is_claude_code_preset
    return "mcp" if is_claude_code_preset(preset_id) else "play"


def _worldlines_continue_game_with_preset(game_path: Path, preset_id: str) -> bool:
    """Continue an existing game using a preselected preset."""
    from neonrp.presets import build_config_dict
    from neonrp.core.paths import get_neonrp_dir
    from neonrp.core.storage import atomic_write_json

    mode = _resolve_mode(preset_id)
    config_dict = build_config_dict(preset_id)
    _tag_worldlines_preset(config_dict, preset_id)
    config_path = get_neonrp_dir(game_path) / "config.json"
    atomic_write_json(config_path, config_dict)

    import os

    os.chdir(game_path)
    _setup_logging(game_path)

    from neonrp.core.config import load_dotenv
    from neonrp.core.template_assets import bootstrap_claude_workspace
    from neonrp.worlds import get_world, infer_world_id_from_game_dir

    load_dotenv(game_path)

    if mode == "mcp":
        world_id = infer_world_id_from_game_dir(game_path)
        if world_id is not None:
            bootstrap_claude_workspace(game_path, template_name=get_world(world_id)["template"], force=True)

    from neonrp.tui.app import run_tui

    # `continue_session=True` in all modes: in non-MCP it restores the local
    # session; in MCP mode it signals the claude-p bridge to start turn 1
    # with `--continue` so Claude Code resumes its prior workspace conversation.
    run_tui(root=game_path, continue_session=True, mode=mode)
    return True


def _worldlines_continue_game(game_path: Path) -> bool:
    """Continue an existing game. Prompts for model selection.

    Returns False if user backs out (don't launch).
    """
    from neonrp.presets import list_presets, ensure_preset_key, is_claude_code_preset

    presets = list_presets()
    preset_options = [p["display"] for p in presets]
    preset_idx = _worldlines_prompt_choice(
        "  \u2699\uFE0F  选择模型：", preset_options, allow_back=True
    )
    if preset_idx is None:
        return False

    selected_preset = presets[preset_idx]

    # Claude Code preset needs no API key; others do
    if not is_claude_code_preset(selected_preset["id"]):
        if not ensure_preset_key(selected_preset["id"]):
            return False

    return _worldlines_continue_game_with_preset(game_path, selected_preset["id"])


def _launch_time_update_check() -> None:
    """Check for a newer release and offer the user to upgrade.

    Best-effort: any error is silently swallowed so a bad network never
    blocks launch. Honors `updates.check_on_launch` and `last_skipped_version`.
    """
    try:
        from neonrp.core import updater
        from neonrp.tui.i18n import get_message, resolve_locale

        locale = resolve_locale()

        settings = updater.get_update_settings()
        if not settings.get("enabled", True) or not settings.get("check_on_launch", True):
            return
        result = updater.check_for_update_cached()
        if not result.update_available or not result.latest_version:
            return
        if settings.get("last_skipped_version") == result.latest_version:
            return
        click.echo()
        click.echo(
            "  "
            + get_message(locale, "update.launch_banner").format(
                current=result.current_version,
                latest=result.latest_version,
                channel=result.channel,
            )
        )
        if result.release_notes_url:
            click.echo(
                "    "
                + get_message(locale, "update.launch_release_notes").format(url=result.release_notes_url)
            )
        if not result.install_mode.allow_auto_apply:
            click.echo("    " + get_message(locale, "update.launch_editable_blocked"))
            return
        choice = click.prompt(
            "    " + get_message(locale, "update.launch_choice_prompt"),
            default="n",
            show_default=False,
        ).strip().lower()
        if choice in ("y", "yes"):
            ok, output = updater.apply_update_in_background()
            if output:
                click.echo(output)
            if ok:
                click.echo("  " + get_message(locale, "upgrade.success"))
                raise SystemExit(0)
            click.echo("  " + get_message(locale, "update.launch_failed"))
        elif choice in ("s", "skip"):
            updater.mark_version_skipped(result.latest_version)
            click.echo(
                "  "
                + get_message(locale, "update.launch_skipped").format(version=result.latest_version)
            )
    except SystemExit:
        raise
    except Exception:
        return


@click.command()
def worldlines_cli() -> None:
    """WorldLines - unified guided entry into the NeonRP runtime."""
    from neonrp.presets import ensure_preset_key, is_claude_code_preset
    from neonrp.tui.app import run_worldlines_launcher

    _launch_time_update_check()

    selection = run_worldlines_launcher()
    if selection is None:
        return

    if not is_claude_code_preset(selection.preset_id):
        if not ensure_preset_key(selection.preset_id):
            return

    if selection.mode == "continue":
        if selection.game_path is None:
            return
        _worldlines_continue_game_with_preset(selection.game_path, selection.preset_id)
        return

    if selection.world_id in ("__wl_create__", "__wl_import__") and selection.world_intent:
        _worldlines_init_custom_world(
            selection.world_intent,
            selection.preset_id,
            mode=selection.runtime_mode,
            player_profile=selection.player_profile,
        )
        return

    if not selection.world_id:
        return
    _worldlines_init_and_launch(
        selection.world_id,
        selection.preset_id,
        mode=selection.runtime_mode,
        player_profile=selection.player_profile,
    )


def _worldlines_init_custom_world(
    intent: dict[str, Any],
    preset_id: str,
    *,
    mode: str,
    player_profile: dict[str, Any] | None,
) -> None:
    """Create a fresh game directory and delegate world creation to a skill.

    The launcher has already captured the user's intent (create vs. import,
    plus a natural-language prompt or source path). We scaffold a minimal
    game directory, seed a starter message pointing at the relevant built-in
    skill, and hand off to the TUI runtime so the active agent picks up the
    thread with `world-game-authoring` or `tavern-game-import`.
    """
    from datetime import datetime
    from neonrp.core.manifest import Manifest
    from neonrp.core.paths import get_manifest_path, get_neonrp_dir
    from neonrp.core.storage import atomic_write_json
    from neonrp.presets import build_config_dict
    from neonrp.worlds import GAME_HOME

    action = intent.get("action") or "create"
    skill_name = intent.get("skill") or "world-game-authoring"
    slug = "custom-create" if action == "create" else "custom-import"
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    game_dir = GAME_HOME / f"{slug}-{timestamp}"
    game_dir.mkdir(parents=True, exist_ok=True)

    click.echo(f"\n  Preparing {action} workspace at {game_dir}...")

    import os
    os.chdir(game_dir)

    from neonrp.core.storage import ensure_dirs
    ensure_dirs(game_dir)
    atomic_write_json(get_manifest_path(game_dir), Manifest().model_dump())

    config_dict = build_config_dict(preset_id)
    _tag_worldlines_preset(config_dict, preset_id)
    atomic_write_json(get_neonrp_dir(game_dir) / "config.json", config_dict)

    # Seed the runtime scaffold with the "default" template so the TUI has
    # working narrator/router agents to hand the intent to. The skill itself
    # will write the real world content from the prompt/source.
    from neonrp.commands.game import create_rule_samples, create_skill_samples
    from neonrp.core.paths import get_data_dir_name
    from neonrp.core.template_assets import (
        bootstrap_claude_workspace,
        copy_agent_from_template,
        copy_runtime_contract_from_template,
        list_template_agent_ids,
    )

    template_name = "default"
    data_dir_name = get_data_dir_name(game_dir)
    for agent_id in list_template_agent_ids(template_name):
        copy_agent_from_template(
            game_dir,
            template_name=template_name,
            agent_id=agent_id,
            data_dir_name=data_dir_name,
            force=True,
        )
    copy_runtime_contract_from_template(
        game_dir,
        template_name=template_name,
        data_dir_name=data_dir_name,
        force=True,
    )
    create_rule_samples(game_dir)
    create_skill_samples(game_dir)

    # Write the handoff brief the TUI will pick up as an opening instruction.
    brief_path = game_dir / ".neonrp" / "worldlines_intent.json"
    brief_path.parent.mkdir(parents=True, exist_ok=True)
    import json as _json

    brief_path.write_text(
        _json.dumps(
            {
                "action": action,
                "skill": skill_name,
                "prompt": intent.get("prompt", ""),
                "source_path": intent.get("source_path", ""),
                "player_profile": player_profile,
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    if mode == "mcp":
        bootstrap_claude_workspace(game_dir, template_name=template_name, force=True)

    # Build localized handoff from the user's chosen ui.language. The same
    # helper composes world_intent + (optional) character intent + the
    # start-game cue into one message the agent sees on turn 1.
    startup_commands = _build_startup_handoff(player_profile, world_intent=intent)

    click.echo("  Done.\n")
    click.echo("  Handoff brief:")
    for line in (startup_commands[0] if startup_commands else "").splitlines():
        click.echo(f"    {line}")
    click.echo()

    _setup_logging(game_dir)
    from neonrp.tui.app import run_tui

    run_tui(root=game_dir, mode=mode, startup_commands=startup_commands)


if __name__ == "__main__":
    cli()
