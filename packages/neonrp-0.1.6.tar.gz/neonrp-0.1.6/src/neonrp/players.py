"""WorldLines player profile management.

Player profiles are stored in ``~/.worldlines/players/``.
Each profile is a JSON file with customizable character info
that gets merged into the template's ``player.json`` at game start.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import click

logger = logging.getLogger(__name__)

PLAYERS_HOME = Path.home() / ".worldlines" / "players"

# Minimal fields a player profile must have
_REQUIRED = ("name",)

# Fields the user can customize (others come from template)
_EDITABLE_FIELDS = {
    "name": "角色名",
    "summary": "角色简介",
    "gender": "性别",
    "personality": "性格特征",
    "appearance": "外貌描述",
    "backstory": "背景故事",
}


def _ensure_dir() -> None:
    PLAYERS_HOME.mkdir(parents=True, exist_ok=True)


def list_players() -> list[dict[str, Any]]:
    """Return saved player profiles sorted by mtime (newest first)."""
    _ensure_dir()
    profiles: list[dict[str, Any]] = []
    for f in PLAYERS_HOME.glob("*.json"):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            profiles.append({
                "path": f,
                "file": f.stem,
                "name": data.get("name", f.stem),
                "summary": data.get("summary", ""),
                "data": data,
            })
        except Exception:
            continue
    profiles.sort(key=lambda p: p["path"].stat().st_mtime, reverse=True)
    return profiles


def load_player(file_stem: str) -> dict[str, Any]:
    """Load a player profile by filename (without .json)."""
    path = PLAYERS_HOME / f"{file_stem}.json"
    if not path.exists():
        raise FileNotFoundError(f"Player profile not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def save_player(data: dict[str, Any]) -> Path:
    """Save a player profile. Uses sanitized name as filename."""
    _ensure_dir()
    name = data.get("name", "player")
    # Sanitize filename
    safe_name = "".join(c if c.isalnum() or c in "-_" else "-" for c in name).strip("-")
    if not safe_name:
        safe_name = "player"
    path = PLAYERS_HOME / f"{safe_name}.json"
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def merge_player_into_template(template_player: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    """Merge user's player profile into the template player entity.

    Profile fields override template fields. Template-specific fields
    (hp, location, inventory, special_abilities, etc.) are preserved.
    """
    merged = dict(template_player)
    # Override customizable fields from profile
    for key in _EDITABLE_FIELDS:
        if key in profile and profile[key]:
            merged[key] = profile[key]
    # Always preserve id and kind
    merged["id"] = "player"
    merged["kind"] = "player"
    return merged


def prompt_create_player() -> dict[str, Any] | None:
    """Interactive CLI prompt to create a new player profile.

    Returns the profile dict, or None if user cancels.
    """
    click.echo()
    click.echo("  创建新角色")
    click.echo()

    data: dict[str, Any] = {}
    for field, label in _EDITABLE_FIELDS.items():
        required = field in _REQUIRED
        hint = "（必填）" if required else "（可选，回车跳过）"
        while True:
            value = click.prompt(f"    {label} {hint}", default="", show_default=False).strip()
            if required and not value:
                click.echo("    请输入角色名。")
                continue
            if value:
                data[field] = value
            break

    if "name" not in data:
        return None

    # Save
    path = save_player(data)
    click.echo(f"\n  角色已保存: {path.name}")
    return data


def prompt_edit_player(profile: dict[str, Any]) -> dict[str, Any]:
    """Interactive CLI prompt to edit an existing player profile."""
    click.echo()
    click.echo(f"  编辑角色: {profile.get('name', '???')}")
    click.echo("  （回车保持原值）")
    click.echo()

    data = dict(profile)
    for field, label in _EDITABLE_FIELDS.items():
        current = data.get(field, "")
        display = current if current else "(空)"
        value = click.prompt(f"    {label} [{display}]", default="", show_default=False).strip()
        if value:
            data[field] = value

    save_player(data)
    click.echo("\n  已保存。")
    return data


# ---------------------------------------------------------------------------
# AI-powered player creation
# ---------------------------------------------------------------------------

_AI_GENERATE_PROMPT = """\
根据用户的一句话描述，生成一个RPG角色资料。返回纯JSON，不要markdown代码块。

JSON字段：
- name: 角色名（有创意的名字）
- summary: 一句话角色简介
- gender: 性别
- personality: 性格特征（2-3句）
- appearance: 外貌描述（2-3句）
- backstory: 背景故事（3-5句）

用户描述：{description}
"""


def _build_adapter_from_preset(preset_id: str) -> Any:
    """Build an LLM adapter directly from a preset ID (no game dir needed)."""
    from neonrp.presets import is_claude_code_preset

    if is_claude_code_preset(preset_id):
        return None  # handled by _generate_via_claude_cli

    from dataclasses import fields as dc_fields
    from neonrp.presets import build_config_dict
    from neonrp.core.config import ProviderConfig
    from neonrp.core.llm import get_adapter_from_config

    config_dict = build_config_dict(preset_id)
    model_ref = config_dict.get("llm", {}).get("model_ref", "")
    models = config_dict.get("models", {})
    model_data = models.get(model_ref, {})

    if not model_data or model_data.get("provider") == "stub":
        return None

    # Build ProviderConfig from model_data
    valid_fields = {f.name for f in dc_fields(ProviderConfig)}
    filtered = {k: v for k, v in model_data.items() if k in valid_fields}
    provider_config = ProviderConfig(**filtered)
    return get_adapter_from_config(provider_config)


def _generate_via_claude_cli(description: str) -> dict[str, Any] | None:
    """Use ``claude -p`` to generate a player profile."""
    import shutil
    import subprocess

    claude_path = shutil.which("claude")
    if not claude_path:
        return None

    prompt = (
        "你是一个RPG角色生成器。根据以下描述生成角色资料。"
        "只返回纯JSON，不要markdown代码块，不要其他文字。\n"
        f"JSON字段：name, summary, gender, personality, appearance, backstory\n\n"
        f"用户描述：{description}"
    )

    try:
        proc = subprocess.run(
            [claude_path, "-p", prompt],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if proc.returncode != 0:
            logger.warning("claude -p failed: %s", proc.stderr)
            return None

        text = proc.stdout.strip()
        # Strip markdown code fences if present
        if text.startswith("```"):
            text = text.split("\n", 1)[-1]
            if text.endswith("```"):
                text = text[:-3]
            text = text.strip()
        return json.loads(text)
    except Exception as exc:
        logger.warning("claude CLI player generation failed: %s", exc)
        return None


def generate_player_from_description(preset_id: str, description: str) -> dict[str, Any] | None:
    """Use the selected LLM to generate a player profile from a one-line description.

    Returns the generated profile dict, or None on failure.
    """
    from neonrp.presets import is_claude_code_preset

    # Claude Code mode: use claude CLI directly
    if is_claude_code_preset(preset_id):
        return _generate_via_claude_cli(description)

    from neonrp.core.llm import Message

    adapter = _build_adapter_from_preset(preset_id)
    if adapter is None:
        return None

    try:
        result = adapter.chat([
            Message(role="system", content="你是一个RPG角色生成器。只返回JSON，不要其他文字。"),
            Message(role="user", content=_AI_GENERATE_PROMPT.format(description=description)),
        ])
        if result.message and result.message.content:
            text = result.message.content.strip()
            # Strip markdown code fences if present
            if text.startswith("```"):
                text = text.split("\n", 1)[-1]
                if text.endswith("```"):
                    text = text[:-3]
                text = text.strip()
            return json.loads(text)
    except Exception as exc:
        logger.warning("AI player generation failed: %s", exc)
    return None


def _display_profile(data: dict[str, Any]) -> None:
    """Display a generated player profile for review."""
    click.echo()
    for field, label in _EDITABLE_FIELDS.items():
        value = data.get(field, "")
        if value:
            click.echo(f"    {label}: {value}")
    click.echo()


def prompt_ai_create_player(preset_id: str) -> dict[str, Any] | None:
    """AI-powered player creation: user gives a one-line description,
    LLM generates the full profile, user confirms/edits/regenerates.

    Returns the profile dict, or None if user cancels.
    """
    click.echo()
    description = click.prompt(
        "  请用一句话描述你的角色", default="", show_default=False
    ).strip()
    if not description:
        return None

    click.echo("\n  AI 生成中...")
    data = generate_player_from_description(preset_id, description)

    if data is None:
        click.echo("  生成失败，请重试或手动创建。")
        return None

    while True:
        _display_profile(data)

        click.echo("  1. 确认使用")
        click.echo("  2. 编辑后使用")
        click.echo("  3. 重新生成")
        click.echo("  4. 取消")
        click.echo()

        choice = click.prompt(">", type=str, default="1").strip()

        if choice == "1":
            path = save_player(data)
            click.echo(f"\n  角色已保存: {path.name}")
            return data

        if choice == "2":
            edited = prompt_edit_player(data)
            return edited

        if choice == "3":
            click.echo("\n  重新生成中...")
            new_data = generate_player_from_description(preset_id, description)
            if new_data is None:
                click.echo("  生成失败，保留当前结果。")
            else:
                data = new_data
            continue

        if choice == "4":
            return None
