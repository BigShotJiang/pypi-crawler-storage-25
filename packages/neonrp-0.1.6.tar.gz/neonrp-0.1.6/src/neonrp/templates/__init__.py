"""Built-in game templates for `neonrp game new`."""

