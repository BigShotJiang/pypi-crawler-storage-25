# Sanity Rules — Dark Train

> Canonical reference for rules-referee. puzzle-agent may skim but
> must delegate actual SAN resolution to rules-referee via `task()`.

## Scale

- `san` runs 0–100, starts at 80 for the PC.
- Damage to SAN is frequent but small. Don't deplete in one dramatic swing.
- At `san ≤ 40` the PC exhibits first fraying signs (Narrator latitude:
  hand tremor, perception skips, dreaming while awake).
- At `san ≤ 20` each new uncanny contact adds +1 difficulty to the check.
- At `san = 0` the PC doesn't die — they **disperse**: next turn opens
  on an earlier carriage with a gap in memory.

## Check mechanic

On uncanny contact the PC makes a SAN check: roll `d20`.
- `d20 < current san` → pass (lower SAN loss).
- `d20 ≥ current san` → fail (higher SAN loss).

This roll-under-SAN is deliberately inverted from other d20 checks —
high SAN = large target = likely to pass.

## Trigger table

| Trigger                                     | Fail loss  | Pass loss |
|---|---|---|
| Glimpse the void outside a window           | 1d3        | 0 or 1    |
| Long stare into the void                    | 1d6        | 1         |
| NPC's face skews briefly                    | 1d4        | 0         |
| Train stops shuddering completely           | 1d6+1      | 1         |
| The child's bear answers a question         | 1d4        | 1         |
| Reading text that reads you back            | 2d6        | 1d3       |
| Direct contact with the Conductor's hand    | 2d6        | 1d4       |

Triggers scale with proximity and duration. Combat referees layer
an additional 1d4 on critical hits where the attacker's behavior was
off-human.

## Narrative beats the puzzle-agent should draw from

Past SAN loss leaves **traces** in the carriage: the player's
reflection lags a beat, the ceiling creaks answer to nothing, a
passenger you met yesterday doesn't remember meeting you. Fail states
are feature, not failure — they're how the Train communicates.
