# Combat Rules — Dark Train

> Canonical reference for combat-referee. Puzzle-agent delegates any
> physical exchange here via `task()`. Combat is rare and the PC is
> not an action hero.

## Core dice

- Single d20 roll per exchange — no initiative, no multi-round turns.
- Player attempts: `d20 + mod` vs `DC`.
  - DC 10 mundane · 15 serious · 20 heroic (Conductor-tier).
- NPC attacks on player: `d20` vs player AC (default 10, no armor).
  - Hit → `npc.attack.damage` dice.
  - Nat 20 → max damage AND a SAN hit (rules-referee if deep call).

## HP

- PC `hp` 0–100, starts 100. This is resilience, not video-game HP bar.
- Damage ranges should FEEL heavy:

| Weapon / attacker           | Dice     |
|---|---|
| Clumsy scuffle              | 1d4      |
| Nervous passenger's knife   | 1d6+2    |
| Conductor's cane            | 1d8+3    |
| The Thing in the fog        | 2d6      |

- At HP 0 the PC **does not die**. They wake in an earlier carriage
  with memory gaps. Returning to the scene they fell is possible but
  not guaranteed; the Train may have rearranged its corridors.

## No armor, no weapons

The PC has no combat training. Improvised weapons (a broken bottle,
the heavy lantern from carriage-3, the Conductor's dropped cane) grant
+1 to attack AND +1 damage at GM's discretion.

## SAN in combat

Some attacks have an SAN rider even on mundane wounds — when the
attacker's behavior crosses the uncanny line:

- Face distorts briefly mid-swing: +SAN 1d3 on a hit
- Bleeds something not red: +SAN 1d4
- Doesn't react to a clear strike: +SAN 1d6

Combat-referee may bundle this in the return JSON's `san_delta` or
delegate to rules-referee for a proper check.

## Ending combat

- NPC escapes / collapses / becomes something else (uncanny pivot).
- No loot drops. If anything is carried away it's a scar, an
  impression, a line in `clues_found`.
- Combat-referee returns one exchange per call. For extended
  violence, puzzle-agent calls repeatedly — but most encounters
  resolve in 1–2 exchanges.
