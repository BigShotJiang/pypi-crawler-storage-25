# Dark Train — Claude Code RPG

神秘/恐怖基调的线性谜题游戏。玩家在一辆永无止境的列车上醒来，从第 6 节车厢走向第 1 节，每节有独立的谜题和 NPC。

## 怎么玩

在 Claude Code 里：`@puzzle-agent 开始游戏`

## 架构（fast mode — 单主 agent + 三个 specialist）

所有游戏数据在 `game/`。Agent 在 `.claude/agents/`。

```
@puzzle-agent  — 主叙事：车厢内所有交互（探索 / 解谜 / NPC / 拾取 / 推进 / startup）
  ├─ @rules-referee  — SAN 检定、调查 / 感知 / 说服等 d20 判定
  ├─ @combat-referee — 罕见物理遭遇（暴力乘客 / 雾中之物 / 列车长测试）
  └─ @train-event   — 列车"本体"：tick 时钟、环境事件、剧情触发
```

Dark Train 是 **fast mode** 加三个 specialist：
- runtime_contract.json 不声明 `execution_mode: orchestrator`
- puzzle-agent 直接面向玩家 — 它是唯一做叙事的
- specialist 只在特定情境被 task() 调用：
  - rules-referee：玩家动作需要骰子
  - combat-referee：物理暴力爆发
  - train-event：时间流逝 / 剧情 precondition 可能命中
- 它们返回结构化 JSON（骰子 / beats / state delta），puzzle-agent 编织成散文
- 它们本身不面向玩家（不写 prose），`presentation_hidden` 可以不设（fast mode 不读这个 flag）

## 事件 / 节奏数据

- `game/events/*.json` — 剧情事件（precondition gated，fire once）
- `game/rules/narrative.md` — 叙事规范（HUD 行格式 / 长度 / 视角 / 禁用词汇 / canonical codex）
- `game/rules/train_events.md` — tick 机制 + 环境事件表 + fragment 池
- `game/rules/sanity_rules.md` — SAN 规则 + 触发表
- `game/rules/combat_rules.md` — 战斗规则

车厢 / 玩家多了几个字段：
- `location/*.json`: `fog_level` (1-5) / `ambient_rate` (d100) / `ambient_events` / `events_triggered` / `passenger_manifest`
- `player.json`: `san` / `max_san` / `tick_count` / `events_seen` / `fragments_heard`

## 世界观

- 列车永不停站，窗外是虚空
- 玩家失忆，从第 6 节醒来
- 每节车厢一个谜题 + 至少一个 NPC
- 气氛：存在主义不安 / 不是 gore horror / 细节都有用意
- 不要解释这列车是什么（神秘感靠不解释撑起）

## 规则

- 解谜宽松判定：只要方案创意合理就通过
- NPC 真相碎片化 — 细节对不上是 feature
- 窗外虚空不能看久
- 不要把玩家当"天选之人"
- 不要感叹号

## 玩家状态

保存在 `game/player/player.json`：
- `location` — 当前车厢 id
- `inventory` — 拾到的物品 id 列表
- `clues_found` — 发现的线索 id 列表
- `carriages_visited` — 已进入的车厢 id 列表
