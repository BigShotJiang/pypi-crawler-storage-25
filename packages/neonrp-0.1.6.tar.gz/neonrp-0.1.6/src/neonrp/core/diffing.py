"""Diff rendering for NeonRP proposals.

Generates unified diff output from proposals for human review.
"""

import difflib
from pathlib import Path

from neonrp.core.proposal import Proposal, UpsertTextOp, DeleteOp


def render_diff(proposal: Proposal, game_root: Path) -> str:
    """Render a proposal as unified diff output.

    Args:
        proposal: The proposal containing operations
        game_root: Path to the game directory

    Returns:
        Unified diff string, sorted by path for stability
    """
    diff_sections = []

    # Sort ops by path for stable output
    sorted_ops = sorted(proposal.ops, key=lambda op: op.path)

    for op in sorted_ops:
        section = _render_op_diff(op, game_root)
        if section:
            diff_sections.append(section)

    return "\n".join(diff_sections)


def _render_op_diff(op: UpsertTextOp | DeleteOp, game_root: Path) -> str:
    """Render diff for a single operation.

    Args:
        op: The operation to render
        game_root: Path to the game directory

    Returns:
        Diff string for this operation
    """
    file_path = game_root / op.path

    if isinstance(op, DeleteOp):
        return _render_delete_diff(op.path, file_path)
    elif isinstance(op, UpsertTextOp):
        return _render_upsert_diff(op.path, file_path, op.content)

    return ""


def _render_delete_diff(path: str, file_path: Path) -> str:
    """Render diff for a delete operation.

    Args:
        path: Relative path of the file
        file_path: Absolute path to the file

    Returns:
        Diff showing file deletion
    """
    old_lines = []

    # Read old content if file exists
    if file_path.exists():
        try:
            old_content = file_path.read_text(encoding="utf-8")
            old_lines = old_content.splitlines(keepends=False)
        except (IOError, UnicodeDecodeError):
            old_lines = ["[binary or unreadable file]"]

    # Compute hunk header with correct line count
    old_line_count = len(old_lines)
    hunk_header = f"@@ -1,{old_line_count} +0,0 @@"

    lines = [
        f"--- a/{path}",
        "+++ /dev/null",
        hunk_header,
    ]

    for line in old_lines:
        lines.append(f"-{line}")

    return "\n".join(lines)


def _render_upsert_diff(path: str, file_path: Path, new_content: str) -> str:
    """Render diff for an upsert operation.

    Args:
        path: Relative path of the file
        file_path: Absolute path to the file
        new_content: New content to write

    Returns:
        Unified diff showing changes
    """
    # Get old content if file exists
    if file_path.exists():
        try:
            old_content = file_path.read_text(encoding="utf-8")
        except (IOError, UnicodeDecodeError):
            old_content = ""
        from_file = f"a/{path}"
    else:
        old_content = ""
        from_file = "/dev/null"

    # Generate unified diff
    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    # Ensure lines end with newlines for proper diff
    if old_lines and not old_lines[-1].endswith("\n"):
        old_lines[-1] += "\n"
    if new_lines and not new_lines[-1].endswith("\n"):
        new_lines[-1] += "\n"

    diff = difflib.unified_diff(old_lines, new_lines, fromfile=from_file, tofile=f"b/{path}", lineterm="")

    result = "\n".join(line.rstrip() for line in diff)

    # If no changes, return empty
    if not result:
        return ""

    return result


def render_diff_summary(proposal: Proposal, game_root: Path) -> dict:
    """Generate a summary of changes in a proposal.

    Args:
        proposal: The proposal containing operations
        game_root: Path to the game directory

    Returns:
        Dictionary with lists of added, modified, and deleted files
    """
    added = []
    modified = []
    deleted = []

    for op in proposal.ops:
        file_path = game_root / op.path

        if isinstance(op, DeleteOp):
            deleted.append(op.path)
        elif isinstance(op, UpsertTextOp):
            if file_path.exists():
                modified.append(op.path)
            else:
                added.append(op.path)

    return {
        "added": sorted(added),
        "modified": sorted(modified),
        "deleted": sorted(deleted),
        "total": len(added) + len(modified) + len(deleted),
    }


