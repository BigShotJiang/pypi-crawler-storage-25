"""Runtime contract for project-specific engine behavior.

This keeps engine logic data-driven instead of hardcoding project domains.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from neonrp.core.config import load_config

logger = logging.getLogger(__name__)

DEFAULT_DATA_DIR_NAME = "game"
RUNTIME_CONTRACT_FILENAME = "runtime_contract.json"
CONVENTIONAL_ROUTER_AGENT_IDS: tuple[str, ...] = ("narrator", "orchestrator")
VALID_ROUTER_EXECUTION_MODES: tuple[str, ...] = ("fast", "orchestrator", "multi-agent")
VALID_STARTUP_ROUTER_TYPES: tuple[str, ...] = ("sticky", "one-shot")


@dataclass(frozen=True)
class RuntimeLocationSource:
    entity_id: str
    field: str


@dataclass(frozen=True)
class RuntimeRouterContract:
    agent_id: str
    state_file: str
    startup_file: str
    execution_mode: str = "fast"

    @property
    def state_entity_id(self) -> str:
        return Path(self.state_file).stem

    @property
    def startup_entity_id(self) -> str:
        return Path(self.startup_file).stem


@dataclass(frozen=True)
class RuntimeRoutingContract:
    location_source: RuntimeLocationSource
    domain_agent_map: dict[str, str]
    fallback_agent: str


@dataclass(frozen=True)
class RuntimeContextPackContract:
    seed_entity_ids: tuple[str, ...]
    max_entities: int


@dataclass(frozen=True)
class RuntimeContract:
    data_dir: str
    router: RuntimeRouterContract
    routing: RuntimeRoutingContract
    context_pack: RuntimeContextPackContract
    source: str = "default"

    @property
    def active_agent_relpath(self) -> str:
        return f"{self.data_dir}/{self.router.state_file}"

    @property
    def startup_relpath(self) -> str:
        return f"{self.data_dir}/{self.router.startup_file}"


def get_runtime_contract_path(root: Path) -> Path:
    return root / ".neonrp" / RUNTIME_CONTRACT_FILENAME


def load_startup_payload(root: Path) -> dict[str, Any] | None:
    """Load the configured startup file payload if present and valid."""
    contract = load_runtime_contract(root)
    path = root / contract.startup_relpath
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("Failed to parse startup file '%s': %s", path, exc)
        return None
    return raw if isinstance(raw, dict) else None


def get_startup_entry_agent(root: Path) -> str | None:
    """Return the entry agent defined by the startup file, if any."""
    payload = load_startup_payload(root)
    if not isinstance(payload, dict):
        return None
    routing = payload.get("agent_routing")
    if not isinstance(routing, dict):
        return None
    entry_agent = str(routing.get("entry_agent", "") or "").strip()
    return entry_agent or None


def get_startup_router_type(root: Path) -> str | None:
    """Return startup router type defined by the startup file.

    Current fast-mode startup only guarantees sticky semantics.
    Any unsupported value falls back to ``sticky``.
    """
    payload = load_startup_payload(root)
    if not isinstance(payload, dict):
        return None
    routing = payload.get("agent_routing")
    if not isinstance(routing, dict):
        return None
    raw = str(routing.get("router_type", "") or "").strip().lower().replace("_", "-")
    if not raw:
        return "sticky"
    if raw not in VALID_STARTUP_ROUTER_TYPES:
        logger.warning("Unknown startup router_type '%s'; falling back to sticky", raw)
        return "sticky"
    if raw == "one-shot":
        logger.warning("startup router_type=one-shot is not implemented; falling back to sticky")
        return "sticky"
    return raw


def load_runtime_contract(root: Path) -> RuntimeContract:
    """Load the effective runtime contract for a project."""
    base = _infer_runtime_contract(root)
    path = get_runtime_contract_path(root)
    if not path.exists():
        return base

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("Failed to parse runtime contract '%s': %s", path, exc)
        return base

    if not isinstance(raw, dict):
        logger.warning("Runtime contract '%s' must be a JSON object", path)
        return base

    return _merge_runtime_contract(base, raw, source="file")


def _infer_runtime_contract(root: Path) -> RuntimeContract:
    narrator_agent_id = _get_configured_router_agent_id(root)
    router_state_file = "meta/active-agent.json"
    router_startup_file = "meta/game-start.json"
    data_dir = DEFAULT_DATA_DIR_NAME
    location_source = RuntimeLocationSource(entity_id="player", field="location")
    domain_agent_map = _infer_domain_agent_map(root, narrator_agent_id)
    seed_entity_ids = tuple(
        dict.fromkeys(
            [
                location_source.entity_id,
                Path(router_state_file).stem,
                Path(router_startup_file).stem,
            ]
        )
    )
    return RuntimeContract(
        data_dir=data_dir,
        router=RuntimeRouterContract(
            agent_id=narrator_agent_id,
            state_file=router_state_file,
            startup_file=router_startup_file,
            execution_mode="fast",
        ),
        routing=RuntimeRoutingContract(
            location_source=location_source,
            domain_agent_map=domain_agent_map,
            fallback_agent=narrator_agent_id,
        ),
        context_pack=RuntimeContextPackContract(seed_entity_ids=seed_entity_ids, max_entities=6),
        source="inferred",
    )


def _merge_runtime_contract(base: RuntimeContract, raw: dict[str, Any], *, source: str) -> RuntimeContract:
    data_dir = _normalize_rel_segment(raw.get("data_dir"), fallback=base.data_dir)

    router_raw = raw.get("router")
    router = base.router
    if isinstance(router_raw, dict):
        router = RuntimeRouterContract(
            agent_id=_normalize_name(router_raw.get("agent_id"), fallback=base.router.agent_id),
            state_file=_normalize_relpath(router_raw.get("state_file"), fallback=base.router.state_file),
            startup_file=_normalize_relpath(router_raw.get("startup_file"), fallback=base.router.startup_file),
            execution_mode=_normalize_router_execution_mode(
                router_raw.get("execution_mode"), fallback=base.router.execution_mode
            ),
        )

    routing_raw = raw.get("routing")
    routing = base.routing
    if isinstance(routing_raw, dict):
        location_source_raw = routing_raw.get("location_source")
        location_source = base.routing.location_source
        if isinstance(location_source_raw, dict):
            location_source = RuntimeLocationSource(
                entity_id=_normalize_name(location_source_raw.get("entity_id"), fallback=base.routing.location_source.entity_id),
                field=_normalize_name(location_source_raw.get("field"), fallback=base.routing.location_source.field),
            )

        domain_agent_map = _normalize_domain_agent_map(routing_raw.get("domain_agent_map"), fallback=base.routing.domain_agent_map)
        fallback_agent = _normalize_name(routing_raw.get("fallback_agent"), fallback=base.routing.fallback_agent)
        routing = RuntimeRoutingContract(
            location_source=location_source,
            domain_agent_map=domain_agent_map,
            fallback_agent=fallback_agent,
        )

    context_pack_raw = raw.get("context_pack")
    context_pack = base.context_pack
    if isinstance(context_pack_raw, dict):
        seed_entity_ids = _normalize_seed_ids(context_pack_raw.get("seed_entity_ids"), fallback=base.context_pack.seed_entity_ids)
        max_entities = _normalize_positive_int(context_pack_raw.get("max_entities"), fallback=base.context_pack.max_entities)
        context_pack = RuntimeContextPackContract(seed_entity_ids=seed_entity_ids, max_entities=max_entities)

    return RuntimeContract(
        data_dir=data_dir,
        router=router,
        routing=routing,
        context_pack=context_pack,
        source=source,
    )


def _infer_domain_agent_map(root: Path, narrator_agent_id: str) -> dict[str, str]:
    agents_root = root / "agents"
    if not agents_root.exists():
        return {}

    router_aliases = get_router_agent_aliases(narrator_agent_id)
    mapping: dict[str, str] = {}
    for agent_dir in sorted(child for child in agents_root.iterdir() if child.is_dir()):
        agent_id = agent_dir.name.strip()
        if not agent_id or agent_id in router_aliases:
            continue
        agent_json = agent_dir / "agent.json"
        if not agent_json.exists():
            continue
        try:
            payload = json.loads(agent_json.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(payload, dict):
            continue
        sticky_domain_kinds = payload.get("sticky_domain_kinds")
        if not isinstance(sticky_domain_kinds, list):
            continue
        for raw_kind in sticky_domain_kinds:
            kind = _normalize_name(raw_kind, fallback="")
            if kind and kind not in mapping:
                mapping[kind] = agent_id
    return mapping


def _get_configured_router_agent_id(root: Path) -> str:
    return resolve_router_agent_id(root)


def get_router_agent_aliases(router_agent_id: str | None = None) -> set[str]:
    aliases = {agent_id for agent_id in CONVENTIONAL_ROUTER_AGENT_IDS if agent_id}
    normalized = _normalize_name(router_agent_id, fallback="")
    if normalized:
        aliases.add(normalized)
    return aliases


def resolve_router_agent_id(root: Path) -> str:
    try:
        configured = str(load_config(root).tui.narrator_agent_id or "").strip()
    except Exception:
        configured = ""

    if configured and configured not in CONVENTIONAL_ROUTER_AGENT_IDS:
        return configured

    agents_root = root / "agents"
    if agents_root.exists():
        existing_ids = {
            child.name.strip()
            for child in agents_root.iterdir()
            if child.is_dir() and (child / "agent.json").exists() and child.name.strip()
        }
        for candidate in CONVENTIONAL_ROUTER_AGENT_IDS:
            if candidate in existing_ids:
                return candidate

    if configured:
        return configured
    return CONVENTIONAL_ROUTER_AGENT_IDS[0]


def get_router_execution_mode(root: Path) -> str:
    contract = load_runtime_contract(root)
    return _normalize_router_execution_mode(contract.router.execution_mode, fallback="fast")


def set_router_execution_mode(root: Path, execution_mode: str) -> str:
    normalized = _normalize_router_execution_mode(execution_mode, fallback="")
    if not normalized:
        raise ValueError(
            f"Invalid router execution mode: {execution_mode}. "
            f"Use one of: {', '.join(VALID_ROUTER_EXECUTION_MODES)}"
        )

    path = get_runtime_contract_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw: dict[str, Any] = {}
    if path.exists():
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                raw = loaded
        except Exception:
            raw = {}

    router = raw.get("router")
    if not isinstance(router, dict):
        router = {}
        raw["router"] = router
    router["execution_mode"] = normalized
    path.write_text(json.dumps(raw, indent=2, ensure_ascii=False), encoding="utf-8")
    return normalized


def _normalize_router_execution_mode(value: object, *, fallback: str) -> str:
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in VALID_ROUTER_EXECUTION_MODES:
            return normalized
    return fallback


def _normalize_name(value: object, *, fallback: str) -> str:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return fallback


def _normalize_rel_segment(value: object, *, fallback: str) -> str:
    candidate = _normalize_relpath(value, fallback=fallback)
    if "/" in candidate:
        return fallback
    return candidate


def _normalize_relpath(value: object, *, fallback: str) -> str:
    if not isinstance(value, str):
        return fallback
    normalized = value.replace("\\", "/").strip().strip("/")
    if not normalized or normalized.startswith(".") or ".." in normalized.split("/"):
        return fallback
    return normalized


def _normalize_positive_int(value: object, *, fallback: int) -> int:
    if isinstance(value, int) and value > 0:
        return value
    return fallback


def _normalize_domain_agent_map(value: object, *, fallback: dict[str, str]) -> dict[str, str]:
    if not isinstance(value, dict):
        return dict(fallback)
    normalized: dict[str, str] = {}
    for raw_domain, raw_agent in value.items():
        domain = _normalize_name(raw_domain, fallback="")
        agent_id = _normalize_name(raw_agent, fallback="")
        if domain and agent_id and domain not in normalized:
            normalized[domain.lower()] = agent_id
    return normalized or dict(fallback)


def _normalize_seed_ids(value: object, *, fallback: tuple[str, ...]) -> tuple[str, ...]:
    if not isinstance(value, list):
        return fallback
    seed_ids: list[str] = []
    for raw in value:
        seed_id = _normalize_name(raw, fallback="")
        if seed_id and seed_id not in seed_ids:
            seed_ids.append(seed_id)
    return tuple(seed_ids or fallback)
