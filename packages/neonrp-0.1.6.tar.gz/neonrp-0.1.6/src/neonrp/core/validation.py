import json
import re
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from jsonschema import Draft7Validator

from neonrp.core.paths import (
    DEFAULT_SCHEMA_FILENAME,
    get_rules_dir,
    get_data_dir_name,
    get_game_dir,
)

ID_KIND_PATTERN = re.compile(r"^[a-z0-9._-]+$")


@dataclass
class ValidationIssue:
    file: str
    layer: str
    code: str
    path: str
    message: str
    suggestion: str

    def to_dict(self) -> Dict[str, str]:
        return {
            "file": self.file,
            "layer": self.layer,
            "code": self.code,
            "path": self.path,
            "message": self.message,
            "suggestion": self.suggestion,
        }


def load_schema(root: Path) -> Dict[str, Any]:
    schema_path = get_rules_dir(root) / DEFAULT_SCHEMA_FILENAME
    if schema_path.exists():
        with schema_path.open("r", encoding="utf-8") as f:
            return json.load(f)

    try:
        schema_text = resources.files("neonrp.schema").joinpath(DEFAULT_SCHEMA_FILENAME).read_text(encoding="utf-8")
    except Exception as exc:
        raise FileNotFoundError("Default schema not found") from exc

    return json.loads(schema_text)


def _json_path_from_error(error) -> str:
    if not error.absolute_path:
        return "$"
    path = "$"
    for part in error.absolute_path:
        if isinstance(part, int):
            path += f"[{part}]"
        else:
            path += f".{part}"
    return path


def _iter_game_json_files(root: Path) -> Iterable[Path]:
    game_dir = get_game_dir(root)
    if not game_dir.exists():
        return []
    return game_dir.rglob("*.json")


def validate_game_data(root: Path, schema: Dict[str, Any]) -> Tuple[List[ValidationIssue], List[Dict[str, Any]]]:
    issues: List[ValidationIssue] = []
    entities: List[Dict[str, Any]] = []
    validator = Draft7Validator(schema)
    data_dir_name = get_data_dir_name(root)

    for path in _iter_game_json_files(root):
        rel_path = path.relative_to(root).as_posix()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            issues.append(
                ValidationIssue(
                    file=rel_path,
                    layer="structure",
                    code="json",
                    path="$",
                    message=f"Invalid JSON: {exc.msg}",
                    suggestion="Fix JSON syntax.",
                )
            )
            continue

        schema_errors = sorted(validator.iter_errors(data), key=lambda e: list(e.path))
        if schema_errors:
            for err in schema_errors:
                issues.append(
                    ValidationIssue(
                        file=rel_path,
                        layer="structure",
                        code="schema",
                        path=_json_path_from_error(err),
                        message=err.message,
                        suggestion="Fix the value or add the required field.",
                    )
                )
            continue

        entities.append({"path": rel_path, "data": data})

    issues.extend(_constraint_issues(entities, data_dir_name=data_dir_name))
    return issues, entities


def _constraint_issues(entities: List[Dict[str, Any]], *, data_dir_name: str) -> List[ValidationIssue]:
    issues: List[ValidationIssue] = []
    id_index: Dict[str, str] = {}
    duplicate_reported: set[tuple[str, str]] = set()

    for entry in entities:
        rel_path = entry["path"]
        data = entry["data"]
        parts = Path(rel_path).parts

        if len(parts) != 3 or parts[0] != data_dir_name or not parts[2].endswith(".json"):
            issues.append(
                ValidationIssue(
                    file=rel_path,
                    layer="constraint",
                    code="path-format",
                    path="$",
                    message=f"Entity files must be stored at {data_dir_name}/<kind>/<id>.json",
                    suggestion="Move or rename the file to match the convention.",
                )
            )
            continue

        kind_from_path = parts[1]
        id_from_path = parts[2][:-5]

        kind_value = data.get("kind")
        id_value = data.get("id")

        if kind_value != kind_from_path:
            issues.append(
                ValidationIssue(
                    file=rel_path,
                    layer="constraint",
                    code="kind-mismatch",
                    path="$.kind",
                    message=f"kind '{kind_value}' does not match path segment '{kind_from_path}'",
                    suggestion="Update the kind or move the file to the correct folder.",
                )
            )

        if id_value != id_from_path:
            issues.append(
                ValidationIssue(
                    file=rel_path,
                    layer="constraint",
                    code="id-mismatch",
                    path="$.id",
                    message=f"id '{id_value}' does not match filename '{id_from_path}'",
                    suggestion="Update the id or rename the file to match.",
                )
            )

        if kind_value and not ID_KIND_PATTERN.fullmatch(kind_value):
            issues.append(
                ValidationIssue(
                    file=rel_path,
                    layer="constraint",
                    code="kind-format",
                    path="$.kind",
                    message="kind contains invalid characters",
                    suggestion="Use only lowercase letters, digits, '.', '_' or '-'.",
                )
            )

        if id_value:
            if id_value in id_index:
                other = id_index[id_value]
                key = tuple(sorted([rel_path, other]))
                if key not in duplicate_reported:
                    duplicate_reported.add(key)
                    issues.append(
                        ValidationIssue(
                            file=rel_path,
                            layer="constraint",
                            code="id-duplicate",
                            path="$.id",
                            message=f"Duplicate id '{id_value}' also appears in {other}",
                            suggestion="Ensure ids are globally unique.",
                        )
                    )
                    issues.append(
                        ValidationIssue(
                            file=other,
                            layer="constraint",
                            code="id-duplicate",
                            path="$.id",
                            message=f"Duplicate id '{id_value}' also appears in {rel_path}",
                            suggestion="Ensure ids are globally unique.",
                        )
                    )
            else:
                id_index[id_value] = rel_path

    return issues


