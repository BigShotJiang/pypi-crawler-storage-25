"""LLM error types for NeonRP.

Provides typed error hierarchy for distinguishing retryable from fatal LLM errors.
"""


class LLMError(Exception):
    """Base error for LLM operations."""

    retryable: bool = False

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class RetryableError(LLMError):
    """Transient error that may succeed on retry.

    Covers: HTTP 429 (rate limit), 500/502/503 (server errors),
    connection errors, and timeouts.
    """

    retryable = True


class AuthError(LLMError):
    """Authentication or authorization failure (401, 403).

    Not retryable — requires user to fix API key configuration.
    """

    retryable = False


class InvalidResponseError(LLMError):
    """LLM returned a malformed or unparseable response.

    Covers: malformed JSON in tool arguments, unexpected response structure.
    """

    retryable = False


class BudgetExhaustedError(LLMError):
    """Token or turn budget exceeded.

    Raised when the agentic loop's context size exceeds the configured limit.
    """

    retryable = False
