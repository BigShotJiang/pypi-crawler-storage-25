"""OpenAI-compatible LLM adapter for NeonRP.

Provides integration with OpenAI and OpenAI-compatible APIs (GLM, etc.).
"""

import json
import logging
import os
import random
import time
import inspect
import uuid
from datetime import datetime, timezone
from typing import Any

from neonrp.core.llm import LLMResponse, LLMTurnResult, Message, ToolCall, extract_proposal_json
from neonrp.core.llm_errors import AuthError, InvalidResponseError, RetryableError
from neonrp.core.config import get_api_key

logger = logging.getLogger(__name__)
raw_logger = logging.getLogger("neonrp.raw_json")
_LOG_STREAM_TOOL_DELTAS = str(os.getenv("NEONRP_LOG_STREAM_TOOL_DELTAS", "0")).strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}


def _apply_openai_extra_kwargs(client: Any, kwargs: dict[str, Any], extra_kwargs: dict[str, Any]) -> None:
    """Apply custom kwargs safely for OpenAI SDK.

    New/unknown provider fields (e.g. OpenRouter `reasoning`) can raise
    "unexpected keyword argument" on strict SDK signatures. Route unknown keys
    via `extra_body` so they are still sent to compatible endpoints.
    """
    if not extra_kwargs:
        return

    accepted_keys: set[str] = set()
    try:
        sig = inspect.signature(client.chat.completions.create)
        for name, param in sig.parameters.items():
            if name == "self":
                continue
            if param.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY):
                accepted_keys.add(name)
    except Exception:
        accepted_keys = set()

    extra_body = kwargs.get("extra_body")
    if not isinstance(extra_body, dict):
        extra_body = {}

    for key, value in extra_kwargs.items():
        if key in accepted_keys:
            kwargs[key] = value
        else:
            extra_body[key] = value

    if extra_body:
        kwargs["extra_body"] = extra_body


def _merge_streamed_arguments(existing: str, fragment: str) -> str:
    """Merge streamed function arguments from OpenAI-compatible providers.

    Some providers stream argument deltas; others stream cumulative snapshots.
    This helper accepts both styles and avoids duplicated JSON fragments.
    """
    if not fragment:
        return existing
    if not existing:
        return fragment

    # Cumulative style: each fragment contains the full content so far.
    if fragment.startswith(existing):
        return fragment

    # Duplicate retransmission.
    if existing.endswith(fragment):
        return existing

    # Sometimes provider sends a longer full snapshot that includes previous.
    if len(fragment) > len(existing) and existing in fragment:
        return fragment

    # Delta style with overlap: append only non-overlapping tail.
    max_overlap = min(len(existing), len(fragment))
    for overlap in range(max_overlap, 0, -1):
        if existing.endswith(fragment[:overlap]):
            return existing + fragment[overlap:]

    # Fallback: plain append (best effort).
    return existing + fragment


def _finalize_streamed_arguments(fragments: list[str], merged_fallback: str = "") -> str:
    """Reconstruct streamed function arguments from raw fragments.

    OpenAI-compatible providers typically use one of two styles:
    1) Cumulative snapshots: each fragment contains full args-so-far.
    2) Delta chunks: each fragment is the next literal slice.

    We choose style by inspecting fragment progression. For delta mode, we
    preserve repeated adjacent fragments (e.g. '/player' + '/player').
    """
    cleaned = [str(f) for f in fragments if isinstance(f, str) and f]
    if not cleaned:
        return merged_fallback
    if len(cleaned) == 1:
        return cleaned[0]

    cumulative_votes = 0
    for i in range(1, len(cleaned)):
        if cleaned[i].startswith(cleaned[i - 1]):
            cumulative_votes += 1

    # If most fragments look cumulative, pick the longest/fullest snapshot.
    if cumulative_votes >= ((len(cleaned) - 1) * 2) // 3:
        return max(cleaned, key=len)

    # Delta mode: concatenate raw slices directly; do not dedupe suffix repeats.
    return "".join(cleaned)


def _tool_calls_need_recovery(tool_calls: list[ToolCall]) -> bool:
    """Detect likely-incomplete streamed tool calls that need recovery.

    Some compatible providers end with a tool shell (name/id) but missing args,
    or return non-JSON argument fragments that decode as {"raw": ...}.
    """
    if not tool_calls:
        return False

    for tc in tool_calls:
        if not tc.name:
            return True
        if not isinstance(tc.arguments, dict):
            return True
        if "raw" in tc.arguments:
            return True
        if not tc.arguments:
            return True
    return False


def _preview_log_text(value: Any, max_len: int = 220) -> str:
    try:
        if isinstance(value, str):
            text = value
        else:
            text = json.dumps(value, ensure_ascii=False)
    except Exception:
        text = str(value)
    text = text.replace("\n", "\\n")
    if len(text) > max_len:
        return f"{text[:max_len]}...(+{len(text) - max_len} chars)"
    return text


def _to_jsonable(value: Any) -> Any:
    """Best-effort conversion to JSON-serializable structures."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(v) for v in value]

    for method_name in ("model_dump", "dict", "to_dict"):
        method = getattr(value, method_name, None)
        if callable(method):
            try:
                dumped = method()
                return _to_jsonable(dumped)
            except Exception:
                pass

    model_dump_json = getattr(value, "model_dump_json", None)
    if callable(model_dump_json):
        try:
            return json.loads(model_dump_json())
        except Exception:
            pass

    return str(value)


def _emit_raw_json(event: str, request_id: str, payload: dict[str, Any]) -> None:
    """Append a structured raw LLM record to neonrp.raw_json logger."""
    record = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "event": event,
        "request_id": request_id,
        **payload,
    }
    try:
        raw_logger.info(json.dumps(record, ensure_ascii=False, default=str))
    except Exception:
        logger.debug("Failed to write raw LLM audit log", exc_info=True)


def _classify_openai_error(e: Exception) -> Exception:
    """Map an openai SDK exception to a NeonRP LLMError type."""
    # Check built-in Python connection/OS errors first (before openai-specific)
    # This catches plain ConnectionError, TimeoutError, etc. from network layers
    if isinstance(e, (ConnectionError, TimeoutError, OSError)):
        return RetryableError(str(e))

    try:
        import openai
    except ImportError:
        return e

    if isinstance(e, openai.RateLimitError):
        return RetryableError(str(e), status_code=429)
    if isinstance(e, openai.APITimeoutError):
        return RetryableError(str(e))
    if isinstance(e, openai.APIConnectionError):
        return RetryableError(str(e))
    if isinstance(e, openai.InternalServerError):
        return RetryableError(str(e), status_code=getattr(e, "status_code", 500))
    if isinstance(e, openai.AuthenticationError):
        return AuthError(
            f"Authentication failed. Check your API key. Details: {e}",
            status_code=401,
        )
    if isinstance(e, openai.BadRequestError):
        return InvalidResponseError(str(e), status_code=400)
    return e


class OpenAIAdapter:
    """OpenAI-compatible API adapter.

    Works with OpenAI, GLM (Zhipu AI), and other OpenAI-compatible endpoints.
    Requires openai package to be installed.
    """

    def __init__(
        self,
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        seed: int | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        api_key_env: str = "openai",
        extra_kwargs: dict[str, Any] | None = None,
        max_retries: int = 3,
    ):
        """Initialize OpenAI-compatible adapter.

        Args:
            model: Model name (default: gpt-4o-mini)
            temperature: Sampling temperature
            max_tokens: Maximum output tokens
            seed: Optional seed for reproducibility
            base_url: Custom API base URL (for OpenAI-compatible services)
            api_key: Direct API key (overrides env lookup)
            api_key_env: Provider name for env var lookup (default: "openai")
            extra_kwargs: Extra parameters for the API call (e.g. top_p, response_format)
            max_retries: Maximum retry attempts for transient errors (default: 3)
        """
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.seed = seed
        self.base_url = base_url
        self._api_key = api_key
        self._api_key_env = api_key_env
        self.extra_kwargs = extra_kwargs or {}
        self.max_retries = max_retries

        # Lazy import to avoid requiring openai unless used
        self._client = None

    def _get_client(self) -> Any:
        """Get or create OpenAI client."""
        if self._client is None:
            try:
                import openai
            except ImportError:
                raise ImportError("openai package is required for OpenAI adapter. Install with: pip install openai")

            api_key = self._api_key or get_api_key(self._api_key_env)
            if not api_key:
                raise ValueError(
                    f"API key not found for '{self._api_key_env}'. "
                    f"Set {self._api_key_env.upper()}_API_KEY or NEONRP_LLM_API_KEY environment variable."
                )

            client_kwargs: dict[str, Any] = {"api_key": api_key}
            if self.base_url:
                client_kwargs["base_url"] = self.base_url

            self._client = openai.OpenAI(**client_kwargs)

        return self._client

    def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        tools: list[dict] | None = None,
    ) -> LLMResponse:
        """Generate a response from OpenAI.

        Args:
            system_prompt: Agent's system.md content
            user_prompt: Constructed from query + context items
            tools: Skill tool schemas (passed but not processed in M3)

        Returns:
            LLMResponse with proposal text and raw output
        """
        try:
            client = self._get_client()
        except (ImportError, ValueError) as e:
            return LLMResponse(raw_output="", error=str(e))

        messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]

        try:
            # Build API call parameters
            kwargs: dict[str, Any] = {
                "model": self.model,
                "messages": messages,
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
            }

            if self.seed is not None:
                kwargs["seed"] = self.seed

            # Merge extra kwargs (e.g. top_p, response_format, provider-specific custom fields)
            _apply_openai_extra_kwargs(client, kwargs, self.extra_kwargs)

            # M3: tools passed but not processed (for schema exposure to LLM)
            # Tool calling loop deferred to M3.5+
            if tools:
                kwargs["tools"] = [{"type": "function", "function": tool} for tool in tools]

            response = client.chat.completions.create(**kwargs)

            # Extract response content
            raw_output = response.choices[0].message.content or ""

            # Extract proposal JSON from response
            proposal_text = extract_proposal_json(raw_output)

            # Build usage info
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            if proposal_text is None:
                return LLMResponse(
                    raw_output=raw_output, usage=usage, error="Failed to extract valid proposal JSON from LLM response"
                )

            return LLMResponse(proposal_text=proposal_text, raw_output=raw_output, usage=usage)

        except Exception as e:
            return LLMResponse(raw_output="", error=f"OpenAI API error: {e}")

    def _call_with_retry(self, api_call, error_prefix: str = "OpenAI API error"):
        """Execute an API call with exponential backoff retry for transient errors.

        Args:
            api_call: Callable that makes the API request
            error_prefix: Prefix for error messages

        Returns:
            The API response

        Raises:
            AuthError: On authentication failure (no retry)
            InvalidResponseError: On bad request (no retry)
            RetryableError: After exhausting all retries
            Exception: On unknown errors
        """
        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                return api_call()
            except Exception as e:
                classified = _classify_openai_error(e)
                if isinstance(classified, RetryableError):
                    last_error = classified
                    if attempt < self.max_retries:
                        backoff = (2**attempt) + random.uniform(0, 1)
                        logger.warning(
                            "Retryable error (attempt %d/%d): %s. Retrying in %.1fs...",
                            attempt + 1,
                            self.max_retries,
                            str(classified)[:200],
                            backoff,
                        )
                        time.sleep(backoff)
                        continue
                    # Exhausted retries
                    raise RetryableError(f"{error_prefix} after {self.max_retries} retries: {classified}") from e
                elif isinstance(classified, (AuthError, InvalidResponseError)):
                    raise classified from e
                else:
                    raise
        # Should not reach here, but just in case
        raise last_error if last_error else RuntimeError("Unexpected retry loop exit")

    def chat(
        self,
        messages: list[Message],
        tools: list[dict] | None = None,
    ) -> LLMTurnResult:
        """Execute one turn of a multi-turn conversation (M6).

        This method supports the agentic loop with tool calling.
        Includes retry logic for transient API errors.

        Args:
            messages: Conversation history as list of Message objects
            tools: Tool schemas for function calling

        Returns:
            LLMTurnResult with assistant response and any tool calls
        """
        try:
            client = self._get_client()
        except (ImportError, ValueError) as e:
            return LLMTurnResult(error=str(e), finished=True)

        # Convert Message objects to API format
        api_messages = [msg.to_api_dict() for msg in messages]

        # Log message summary for diagnosing conversation flow
        if logger.isEnabledFor(logging.DEBUG):
            msg_summary = []
            for i, m in enumerate(api_messages):
                role = m.get("role", "?")
                content_len = len(m.get("content", "") or "")
                has_tc = bool(m.get("tool_calls"))
                tc_id = m.get("tool_call_id", "")
                msg_summary.append(f"[{i}]{role}(c={content_len},tc={has_tc},tcid={tc_id!r})")
            logger.debug("chat() sending %d messages: %s", len(api_messages), " ".join(msg_summary))

        # Build API call parameters
        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": api_messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }

        if self.seed is not None:
            kwargs["seed"] = self.seed

        _apply_openai_extra_kwargs(client, kwargs, self.extra_kwargs)

        # Add tools if provided
        if tools:
            kwargs["tools"] = [{"type": "function", "function": tool} for tool in tools]

        request_id = uuid.uuid4().hex
        _emit_raw_json(
            "openai.chat.request",
            request_id,
            {
                "provider": "openai",
                "mode": "chat",
                "model": self.model,
                "base_url": self.base_url,
                "payload": _to_jsonable(kwargs),
            },
        )

        try:
            response = self._call_with_retry(
                lambda: client.chat.completions.create(**kwargs),
                error_prefix="Chat API error",
            )

            choice = response.choices[0]
            api_message = choice.message

            # Log full response summary for diagnosing non-streaming issues
            logger.debug(
                "chat() response: finish_reason=%s content_len=%d tool_calls=%s",
                choice.finish_reason,
                len(api_message.content or ""),
                len(api_message.tool_calls) if api_message.tool_calls else 0,
            )

            # Build usage info
            usage = {}
            if response.usage:
                usage = {
                    "prompt_tokens": response.usage.prompt_tokens,
                    "completion_tokens": response.usage.completion_tokens,
                    "total_tokens": response.usage.total_tokens,
                }

            # Extract tool calls if any
            tool_calls: list[ToolCall] = []
            if api_message.tool_calls:
                for tc in api_message.tool_calls:
                    logger.debug(
                        "chat() raw tool_call: id=%s name=%s args=%r content=%r",
                        tc.id,
                        tc.function.name,
                        tc.function.arguments,
                        getattr(api_message, "content", None),
                    )
                    try:
                        arguments = json.loads(tc.function.arguments)
                    except json.JSONDecodeError:
                        arguments = {"raw": tc.function.arguments}

                    tool_calls.append(
                        ToolCall(
                            id=tc.id,
                            name=tc.function.name,
                            arguments=arguments,
                        )
                    )

            # Build Message object for response
            assistant_msg = Message(
                role="assistant",
                content=api_message.content,
                tool_calls=tool_calls if tool_calls else None,
            )

            _emit_raw_json(
                "openai.chat.response",
                request_id,
                {
                    "provider": "openai",
                    "mode": "chat",
                    "model": self.model,
                    "base_url": self.base_url,
                    "response_raw": _to_jsonable(response),
                    "response_merged": {
                        "finish_reason": choice.finish_reason,
                        "message": {
                            "role": "assistant",
                            "content": api_message.content,
                            "tool_calls": [
                                {"id": tc.id, "name": tc.name, "arguments": tc.arguments}
                                for tc in tool_calls
                            ],
                        },
                        "usage": usage,
                    },
                },
            )

            # Determine if finished (no tool calls = finished)
            finished = len(tool_calls) == 0 and choice.finish_reason == "stop"

            return LLMTurnResult(
                message=assistant_msg,
                tool_calls=tool_calls if tool_calls else None,
                finished=finished,
                usage=usage,
            )

        except AuthError as e:
            _emit_raw_json(
                "openai.chat.error",
                request_id,
                {
                    "provider": "openai",
                    "mode": "chat",
                    "model": self.model,
                    "base_url": self.base_url,
                    "error": f"Authentication failed: {e}",
                    "error_type": "AuthError",
                },
            )
            return LLMTurnResult(error=f"Authentication failed: {e}", finished=True)
        except RetryableError as e:
            _emit_raw_json(
                "openai.chat.error",
                request_id,
                {
                    "provider": "openai",
                    "mode": "chat",
                    "model": self.model,
                    "base_url": self.base_url,
                    "error": f"API error after retries: {e}",
                    "error_type": "RetryableError",
                },
            )
            return LLMTurnResult(error=f"API error after retries: {e}", finished=True, retryable=True)
        except InvalidResponseError as e:
            _emit_raw_json(
                "openai.chat.error",
                request_id,
                {
                    "provider": "openai",
                    "mode": "chat",
                    "model": self.model,
                    "base_url": self.base_url,
                    "error": f"Invalid request: {e}",
                    "error_type": "InvalidResponseError",
                },
            )
            return LLMTurnResult(error=f"Invalid request: {e}", finished=True)
        except Exception as e:
            classified = _classify_openai_error(e)
            if isinstance(classified, RetryableError):
                _emit_raw_json(
                    "openai.chat.error",
                    request_id,
                    {
                        "provider": "openai",
                        "mode": "chat",
                        "model": self.model,
                        "base_url": self.base_url,
                        "error": f"OpenAI API error: {classified}",
                        "error_type": "RetryableError",
                    },
                )
                return LLMTurnResult(error=f"OpenAI API error: {classified}", finished=True, retryable=True)
            _emit_raw_json(
                "openai.chat.error",
                request_id,
                {
                    "provider": "openai",
                    "mode": "chat",
                    "model": self.model,
                    "base_url": self.base_url,
                    "error": f"OpenAI API error: {e}",
                    "error_type": type(e).__name__,
                },
            )
            return LLMTurnResult(error=f"OpenAI API error: {e}", finished=True)

    def chat_stream(
        self,
        messages: list[Message],
        tools: list[dict] | None = None,
    ):
        """Stream a chat turn chunk by chunk (M6-T7).

        Uses OpenAI's stream=True mode to yield chunks as they arrive.
        Accumulates tool calls across chunks since OpenAI sends them incrementally.
        Initial connection uses retry logic for transient errors.

        Args:
            messages: Conversation history as list of Message objects
            tools: Tool schemas for function calling

        Yields:
            StreamChunk with delta text or final tool calls
        """
        from neonrp.core.llm import StreamChunk

        try:
            client = self._get_client()
        except (ImportError, ValueError) as e:
            yield StreamChunk(error=str(e), finished=True)
            return

        # Convert Message objects to API format
        api_messages = [msg.to_api_dict() for msg in messages]

        # Build API call parameters with streaming
        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": api_messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},  # Get usage in final chunk
        }

        if self.seed is not None:
            kwargs["seed"] = self.seed

        _apply_openai_extra_kwargs(client, kwargs, self.extra_kwargs)

        # Add tools if provided
        if tools:
            kwargs["tools"] = [{"type": "function", "function": tool} for tool in tools]

        request_id = uuid.uuid4().hex
        _emit_raw_json(
            "openai.chat_stream.request",
            request_id,
            {
                "provider": "openai",
                "mode": "chat_stream",
                "model": self.model,
                "base_url": self.base_url,
                "payload": _to_jsonable(kwargs),
            },
        )

        try:
            # Use retry for the initial connection
            stream = self._call_with_retry(
                lambda: client.chat.completions.create(**kwargs),
                error_prefix="Stream API error",
            )

            # Accumulate tool calls (OpenAI sends them in parts).
            # Key supports int index and id fallback for compatible APIs that omit index.
            tool_calls_buffer: dict[int | str, dict[str, Any]] = {}
            usage = {}
            chunk_count = 0
            content_parts: list[str] = []
            thinking_parts: list[str] = []
            last_finish_reason: str | None = None

            for chunk in stream:
                chunk_count += 1
                # Handle usage in final chunk
                if chunk.usage:
                    usage = {
                        "prompt_tokens": chunk.usage.prompt_tokens,
                        "completion_tokens": chunk.usage.completion_tokens,
                        "total_tokens": chunk.usage.total_tokens,
                    }

                if not chunk.choices:
                    continue

                choice = chunk.choices[0]
                delta = choice.delta

                # Yield text content chunks
                if delta.content:
                    content_parts.append(delta.content)
                    yield StreamChunk(delta=delta.content)

                # Yield reasoning/thinking chunks for providers that expose them.
                reasoning_text = ""
                try:
                    rc = getattr(delta, "reasoning_content", None)
                    if isinstance(rc, str):
                        reasoning_text = rc
                    elif rc:
                        reasoning_text = str(rc)
                except Exception:
                    reasoning_text = ""
                if not reasoning_text:
                    try:
                        r = getattr(delta, "reasoning", None)
                        if isinstance(r, str):
                            reasoning_text = r
                        elif r:
                            reasoning_text = str(r)
                    except Exception:
                        reasoning_text = ""
                if reasoning_text:
                    thinking_parts.append(reasoning_text)
                    yield StreamChunk(thinking=reasoning_text)

                # Accumulate tool calls and emit early name notifications
                if delta.tool_calls:
                    newly_named: list[str] = []
                    for pos, tc_delta in enumerate(delta.tool_calls):
                        raw_idx = getattr(tc_delta, "index", None)
                        call_id = getattr(tc_delta, "id", None) or ""
                        if isinstance(raw_idx, int):
                            key: int | str = raw_idx
                        elif call_id:
                            key = call_id
                        else:
                            # Best-effort fallback for non-standard providers that omit both index and id.
                            key = f"pos_{pos}"

                        if key not in tool_calls_buffer:
                            tool_calls_buffer[key] = {
                                "id": tc_delta.id or "",
                                "name": "",
                                "arguments": "",
                                "argument_fragments": [],
                            }
                        if tc_delta.id:
                            tool_calls_buffer[key]["id"] = tc_delta.id
                        if tc_delta.function:
                            if tc_delta.function.name:
                                had_name = bool(tool_calls_buffer[key]["name"])
                                tool_calls_buffer[key]["name"] = tc_delta.function.name
                                if not had_name:
                                    newly_named.append(tc_delta.function.name)
                            if tc_delta.function.arguments:
                                tool_calls_buffer[key]["argument_fragments"].append(tc_delta.function.arguments)
                                tool_calls_buffer[key]["arguments"] = _merge_streamed_arguments(
                                    tool_calls_buffer[key]["arguments"], tc_delta.function.arguments
                                )
                        # Log raw delta for diagnosing Ollama/compatible providers
                        raw_args = getattr(tc_delta.function, "arguments", None) if tc_delta.function else None
                        if _LOG_STREAM_TOOL_DELTAS and logger.isEnabledFor(logging.DEBUG):
                            logger.debug(
                                "stream tc_delta: key=%s id=%s name=%r args=%r (type=%s, bool=%s)",
                                key,
                                getattr(tc_delta, "id", None),
                                getattr(tc_delta.function, "name", None) if tc_delta.function else None,
                                raw_args,
                                type(raw_args).__name__,
                                bool(raw_args),
                            )
                    # Notify UI as soon as tool names are known (before args finish)
                    if newly_named:
                        yield StreamChunk(tool_call_starts=newly_named)

                # Check for finish
                if choice.finish_reason:
                    last_finish_reason = choice.finish_reason
                    # Convert accumulated tool calls to ToolCall objects
                    final_tool_calls = []
                    for key, tc_data in tool_calls_buffer.items():
                        finalized_args = _finalize_streamed_arguments(
                            tc_data.get("argument_fragments", []),
                            merged_fallback=tc_data.get("arguments", ""),
                        )
                        parse_ok = True
                        try:
                            arguments = json.loads(finalized_args) if finalized_args else {}
                        except json.JSONDecodeError:
                            parse_ok = False
                            arguments = {"raw": finalized_args}
                        logger.debug(
                            "stream tool_call finalized: key=%s finish_reason=%s id=%s name=%r "
                            "fragment_count=%d merged_len=%d finalized_len=%d parse_ok=%s args=%s",
                            key,
                            choice.finish_reason,
                            tc_data.get("id", ""),
                            tc_data.get("name", ""),
                            len(tc_data.get("argument_fragments", []) or []),
                            len(tc_data.get("arguments", "") or ""),
                            len(finalized_args or ""),
                            parse_ok,
                            _preview_log_text(arguments),
                        )
                        final_tool_calls.append(
                            ToolCall(
                                id=tc_data["id"],
                                name=tc_data["name"],
                                arguments=arguments,
                            )
                        )

                    # Some compatible providers stream incomplete tool calls
                    # (often finish_reason=length). Recover by re-requesting once
                    # with non-stream chat, then prefer recovered calls.
                    recovered_calls = None
                    if final_tool_calls and (
                        choice.finish_reason == "length" or _tool_calls_need_recovery(final_tool_calls)
                    ):
                        logger.warning(
                            "Streamed tool calls need recovery (finish_reason=%s): %s",
                            choice.finish_reason,
                            [(tc.name, tc.arguments) for tc in final_tool_calls],
                        )
                        recovered = self.chat(messages, tools=tools)
                        if recovered.tool_calls and not _tool_calls_need_recovery(recovered.tool_calls):
                            recovered_calls = recovered.tool_calls
                            logger.debug(
                                "stream tool_call recovery succeeded: model=%s recovered=%s",
                                self.model,
                                [(tc.name, _preview_log_text(tc.arguments)) for tc in recovered_calls],
                            )
                        elif recovered.error:
                            logger.warning(
                                "Stream tool-call recovery failed for model=%s: %s",
                                self.model,
                                recovered.error[:300],
                            )
                        else:
                            logger.debug(
                                "stream tool_call recovery not usable: model=%s recovered=%s",
                                self.model,
                                [(tc.name, _preview_log_text(tc.arguments)) for tc in (recovered.tool_calls or [])],
                            )

                    yield StreamChunk(
                        tool_calls=recovered_calls or (final_tool_calls if final_tool_calls else None),
                        finished=True,
                        usage=usage,
                    )
                    final_calls = recovered_calls or (final_tool_calls if final_tool_calls else [])
                    _emit_raw_json(
                        "openai.chat_stream.response",
                        request_id,
                        {
                            "provider": "openai",
                            "mode": "chat_stream",
                            "model": self.model,
                            "base_url": self.base_url,
                            "response_merged": {
                                "finish_reason": last_finish_reason,
                                "message": {
                                    "role": "assistant",
                                    "content": "".join(content_parts) if content_parts else "",
                                    "thinking": "".join(thinking_parts) if thinking_parts else "",
                                    "tool_calls": [
                                        {"id": tc.id, "name": tc.name, "arguments": tc.arguments}
                                        for tc in final_calls
                                    ],
                                },
                                "usage": usage,
                                "chunk_count": chunk_count,
                                "recovered_calls": bool(recovered_calls),
                            },
                        },
                    )
                    return

            # If we get here without a finish_reason, yield final chunk with any accumulated tool calls (review fix)
            final_tool_calls = []
            for key, tc_data in tool_calls_buffer.items():
                finalized_args = _finalize_streamed_arguments(
                    tc_data.get("argument_fragments", []),
                    merged_fallback=tc_data.get("arguments", ""),
                )
                parse_ok = True
                try:
                    arguments = json.loads(finalized_args) if finalized_args else {}
                except json.JSONDecodeError:
                    parse_ok = False
                    arguments = {"raw": finalized_args}
                logger.debug(
                    "stream tool_call finalized (no_finish_reason): key=%s id=%s name=%r "
                    "fragment_count=%d merged_len=%d finalized_len=%d parse_ok=%s args=%s",
                    key,
                    tc_data.get("id", ""),
                    tc_data.get("name", ""),
                    len(tc_data.get("argument_fragments", []) or []),
                    len(tc_data.get("arguments", "") or ""),
                    len(finalized_args or ""),
                    parse_ok,
                    _preview_log_text(arguments),
                )
                final_tool_calls.append(
                    ToolCall(
                        id=tc_data["id"],
                        name=tc_data["name"],
                        arguments=arguments,
                    )
                )

            recovered_calls = None
            if final_tool_calls and _tool_calls_need_recovery(final_tool_calls):
                recovered = self.chat(messages, tools=tools)
                if recovered.tool_calls and not _tool_calls_need_recovery(recovered.tool_calls):
                    recovered_calls = recovered.tool_calls
                    logger.debug(
                        "stream tool_call recovery succeeded (no_finish_reason): model=%s recovered=%s",
                        self.model,
                        [(tc.name, _preview_log_text(tc.arguments)) for tc in recovered_calls],
                    )
                elif recovered.error:
                    logger.warning(
                        "Stream tool-call recovery failed for model=%s (no finish_reason): %s",
                        self.model,
                        recovered.error[:300],
                    )
                else:
                    logger.debug(
                        "stream tool_call recovery not usable (no_finish_reason): model=%s recovered=%s",
                        self.model,
                        [(tc.name, _preview_log_text(tc.arguments)) for tc in (recovered.tool_calls or [])],
                    )
            yield StreamChunk(
                tool_calls=recovered_calls or (final_tool_calls if final_tool_calls else None),
                finished=True,
                usage=usage,
            )
            final_calls = recovered_calls or (final_tool_calls if final_tool_calls else [])
            _emit_raw_json(
                "openai.chat_stream.response",
                request_id,
                {
                    "provider": "openai",
                    "mode": "chat_stream",
                    "model": self.model,
                    "base_url": self.base_url,
                    "response_merged": {
                        "finish_reason": last_finish_reason,
                        "message": {
                            "role": "assistant",
                            "content": "".join(content_parts) if content_parts else "",
                            "thinking": "".join(thinking_parts) if thinking_parts else "",
                            "tool_calls": [
                                {"id": tc.id, "name": tc.name, "arguments": tc.arguments}
                                for tc in final_calls
                            ],
                        },
                        "usage": usage,
                        "chunk_count": chunk_count,
                        "recovered_calls": bool(recovered_calls),
                    },
                },
            )

        except AuthError as e:
            _emit_raw_json(
                "openai.chat_stream.error",
                request_id,
                {
                    "provider": "openai",
                    "mode": "chat_stream",
                    "model": self.model,
                    "base_url": self.base_url,
                    "error": f"Authentication failed: {e}",
                    "error_type": "AuthError",
                },
            )
            yield StreamChunk(error=f"Authentication failed: {e}", finished=True)
        except RetryableError as e:
            _emit_raw_json(
                "openai.chat_stream.error",
                request_id,
                {
                    "provider": "openai",
                    "mode": "chat_stream",
                    "model": self.model,
                    "base_url": self.base_url,
                    "error": f"API error after retries: {e}",
                    "error_type": "RetryableError",
                },
            )
            yield StreamChunk(error=f"API error after retries: {e}", finished=True, retryable=True)
        except InvalidResponseError as e:
            _emit_raw_json(
                "openai.chat_stream.error",
                request_id,
                {
                    "provider": "openai",
                    "mode": "chat_stream",
                    "model": self.model,
                    "base_url": self.base_url,
                    "error": f"Invalid request: {e}",
                    "error_type": "InvalidResponseError",
                },
            )
            yield StreamChunk(error=f"Invalid request: {e}", finished=True)
        except Exception as e:
            classified = _classify_openai_error(e)
            if isinstance(classified, RetryableError):
                _emit_raw_json(
                    "openai.chat_stream.error",
                    request_id,
                    {
                        "provider": "openai",
                        "mode": "chat_stream",
                        "model": self.model,
                        "base_url": self.base_url,
                        "error": f"OpenAI API streaming error: {classified}",
                        "error_type": "RetryableError",
                    },
                )
                yield StreamChunk(error=f"OpenAI API streaming error: {classified}", finished=True, retryable=True)
            else:
                _emit_raw_json(
                    "openai.chat_stream.error",
                    request_id,
                    {
                        "provider": "openai",
                        "mode": "chat_stream",
                        "model": self.model,
                        "base_url": self.base_url,
                        "error": f"OpenAI API streaming error: {e}",
                        "error_type": type(e).__name__,
                    },
                )
                yield StreamChunk(error=f"OpenAI API streaming error: {e}", finished=True)
