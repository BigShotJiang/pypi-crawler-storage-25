"""Self-update infrastructure (L14 Phase 1).

Responsibilities:
- Detect install mode (editable vs. released)
- Fetch release manifest from worldlines.gg (fallback to GitHub)
- Compare with running version
- Surface a check result to CLI + TUI callers
- Defer the actual upgrade to `uv tool upgrade neonrp` (or the equivalent
  for worldlines), never rewriting local source

See docs/L14_AUTO_UPDATE_SCHEME.md for the full design.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

import neonrp

# Primary CDN (worldlines.gg mirrors the same JSON published as a GitHub
# Release asset by the `release` workflow). Fallback is the raw GitHub API.
PRIMARY_MANIFEST_URL = "https://worldlines.gg/releases.json"
# The release workflow in the private LudicDynamics/NeonRP repo creates
# the public-facing Release (with releases.json + install.sh attached) on
# LudicDynamics/WorldLines, so auto-update clients query THIS public repo.
# NeonRP's own releases are never published directly.
GITHUB_LATEST_RELEASE_URL = "https://api.github.com/repos/LudicDynamics/WorldLines/releases/latest"

USER_CONFIG_PATH = Path.home() / ".neonrp" / "config.json"
CACHE_PATH = Path.home() / ".neonrp" / "update_cache.json"
DEFAULT_CHANNEL = "stable"
FETCH_TIMEOUT = 4.0


@dataclass
class InstallMode:
    kind: str  # "editable" | "released" | "unknown"
    detail: str
    allow_auto_apply: bool


@dataclass
class UpdateCheckResult:
    current_version: str
    latest_version: str | None
    channel: str
    update_available: bool
    install_mode: InstallMode
    release_notes_url: str | None = None
    error: str | None = None

    def to_json(self) -> dict[str, Any]:
        data = asdict(self)
        data["install_mode"] = asdict(self.install_mode)
        return data


# ---------------------------------------------------------------------------
# Install-mode detection
# ---------------------------------------------------------------------------

def detect_install_mode() -> InstallMode:
    """Detect how the running neonrp package was installed."""
    try:
        pkg_path = Path(neonrp.__file__).resolve().parent
    except Exception:
        return InstallMode(kind="unknown", detail="no __file__", allow_auto_apply=False)

    # Editable / source checkout: package parent (src/neonrp → src → repo) contains .git
    for parent in (pkg_path.parent, pkg_path.parent.parent):
        if (parent / ".git").exists() and (parent / "pyproject.toml").exists():
            return InstallMode(
                kind="editable",
                detail=f"source checkout at {parent}",
                allow_auto_apply=False,
            )

    # uv tool install path — typically contains "uv/tools/neonrp" or "pipx"
    path_str = str(pkg_path).replace("\\", "/")
    for marker in ("/uv/tools/", "/pipx/venvs/", "/site-packages/"):
        if marker in path_str:
            return InstallMode(
                kind="released",
                detail=f"installed package at {pkg_path}",
                allow_auto_apply=True,
            )

    return InstallMode(
        kind="unknown",
        detail=f"package at {pkg_path}",
        allow_auto_apply=False,
    )


# ---------------------------------------------------------------------------
# User config
# ---------------------------------------------------------------------------

def _load_user_config() -> dict[str, Any]:
    if not USER_CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(USER_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_user_config(data: dict[str, Any]) -> None:
    USER_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    USER_CONFIG_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def get_update_settings() -> dict[str, Any]:
    data = _load_user_config()
    settings = data.get("updates")
    if not isinstance(settings, dict):
        settings = {}
    settings.setdefault("enabled", True)
    settings.setdefault("channel", DEFAULT_CHANNEL)
    settings.setdefault("check_on_launch", True)
    settings.setdefault("mode", "prompt-and-update")
    return settings


def set_update_settings(**patch: Any) -> dict[str, Any]:
    data = _load_user_config()
    settings = data.get("updates") if isinstance(data.get("updates"), dict) else {}
    settings.update({k: v for k, v in patch.items() if v is not None})
    data["updates"] = settings
    _save_user_config(data)
    return settings


def mark_version_skipped(version: str) -> None:
    set_update_settings(last_skipped_version=version)


def clear_skipped_version() -> None:
    data = _load_user_config()
    settings = data.get("updates") if isinstance(data.get("updates"), dict) else {}
    if "last_skipped_version" in settings:
        del settings["last_skipped_version"]
        data["updates"] = settings
        _save_user_config(data)


# ---------------------------------------------------------------------------
# Manifest fetching
# ---------------------------------------------------------------------------

def _fetch_json(url: str, *, timeout: float = FETCH_TIMEOUT) -> dict[str, Any] | None:
    try:
        import urllib.request

        req = urllib.request.Request(url, headers={"User-Agent": "neonrp-updater"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


def fetch_release_manifest(channel: str = DEFAULT_CHANNEL) -> dict[str, Any] | None:
    """Try the primary manifest URL; fall back to GitHub latest release."""
    manifest = _fetch_json(PRIMARY_MANIFEST_URL)
    if manifest and "latest" in manifest:
        return manifest

    # Fallback: synthesize a minimal manifest from GitHub's latest release
    gh = _fetch_json(GITHUB_LATEST_RELEASE_URL)
    if gh and isinstance(gh.get("tag_name"), str):
        tag = gh["tag_name"].lstrip("v")
        return {
            "product": "neonrp",
            "latest": {channel: tag},
            "releases": {
                tag: {
                    "channel": channel,
                    "published_at": gh.get("published_at"),
                    "notes_url": gh.get("html_url"),
                }
            },
        }
    return None


# ---------------------------------------------------------------------------
# Version comparison
# ---------------------------------------------------------------------------

_VERSION_RE = re.compile(r"(\d+)")


def _version_key(version: str) -> tuple[int, ...]:
    if not isinstance(version, str):
        return ()
    parts = _VERSION_RE.findall(version)
    return tuple(int(p) for p in parts)


def is_newer(candidate: str, current: str) -> bool:
    return _version_key(candidate) > _version_key(current)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_current_version() -> str:
    """Return the version of the installed `neonrp` distribution.

    Reads from `importlib.metadata`, which is what pip / uv recorded in
    `*.dist-info/METADATA` at install time — the authoritative source.
    Falls back to the source `__version__` string only when distribution
    metadata is unavailable (e.g. running straight from a git checkout
    with no install step at all).
    """
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("neonrp")
    except PackageNotFoundError:
        pass
    except Exception:
        pass
    return getattr(neonrp, "__version__", "0.0.0")


def check_for_update(channel: str | None = None) -> UpdateCheckResult:
    install_mode = detect_install_mode()
    settings = get_update_settings()
    resolved_channel = channel or settings.get("channel") or DEFAULT_CHANNEL
    current = get_current_version()

    manifest = fetch_release_manifest(resolved_channel)
    if manifest is None:
        return UpdateCheckResult(
            current_version=current,
            latest_version=None,
            channel=resolved_channel,
            update_available=False,
            install_mode=install_mode,
            error="Failed to fetch release manifest",
        )

    latest_map = manifest.get("latest") if isinstance(manifest.get("latest"), dict) else {}
    latest = latest_map.get(resolved_channel) or latest_map.get(DEFAULT_CHANNEL)
    release_entry = {}
    if isinstance(manifest.get("releases"), dict) and isinstance(latest, str):
        release_entry = manifest["releases"].get(latest) or {}

    available = bool(latest) and is_newer(latest, current)
    return UpdateCheckResult(
        current_version=current,
        latest_version=latest if isinstance(latest, str) else None,
        channel=resolved_channel,
        update_available=available,
        install_mode=install_mode,
        release_notes_url=release_entry.get("notes_url"),
    )


# ---------------------------------------------------------------------------
# Upgrade execution (delegates to `uv tool upgrade`)
# ---------------------------------------------------------------------------

def _find_uv_binary() -> str | None:
    return shutil.which("uv")


def build_upgrade_command(package: str = "neonrp") -> list[str] | None:
    """Return the shell command to upgrade this install, or None if unsupported."""
    uv = _find_uv_binary()
    if uv:
        return [uv, "tool", "upgrade", package]
    # pipx fallback
    pipx = shutil.which("pipx")
    if pipx:
        return [pipx, "upgrade", package]
    # pip fallback (only if running inside a non-editable pip install)
    return [sys.executable, "-m", "pip", "install", "--upgrade", package]


def apply_update_in_background(package: str | None = None) -> tuple[bool, str]:
    """Run the upgrade command. Returns (success, stdout+stderr merged).

    If `package` is None, try the distribution the user most likely has
    installed. `worldlines` is our primary brand (pins neonrp), and
    `neonrp` is the direct-install alternative. If one reports "is not
    installed" we silently fall through to the next candidate before
    surfacing an error.
    """
    candidates = [package] if package else _default_upgrade_candidates()
    last_output = ""
    for pkg in candidates:
        cmd = build_upgrade_command(pkg)
        if cmd is None:
            return False, "No supported package manager (uv / pipx / pip) found on PATH."
        try:
            proc = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                text=True,
                env={**os.environ, "CLICOLOR": "0"},
            )
        except Exception as exc:
            return False, f"Failed to run upgrade command: {exc}"
        output = (proc.stdout or "") + (proc.stderr or "")
        last_output = output
        if proc.returncode == 0:
            # Invalidate the on-disk check cache so the next launch
            # re-queries with the freshly-installed version instead of
            # re-offering the same upgrade from a stale snapshot.
            try:
                CACHE_PATH.unlink(missing_ok=True)
            except Exception:
                pass
            return True, output.strip()
        # Try the next candidate only when the failure was clearly "wrong
        # package name" — any other error (network, perms, etc.) should
        # surface immediately without retrying against another target.
        if "is not installed" not in output.lower():
            break
    return False, last_output.strip()


def _default_upgrade_candidates() -> list[str]:
    """Ordered fallback list for `uv tool upgrade <name>`.

    Prefers whatever entry point the user invoked (argv[0]) — if they
    ran `worldlines`, try `worldlines` first; if they ran `neonrp`, try
    `neonrp` first. Falls back to the opposite name so whichever one is
    actually installed as a uv / pipx tool wins.
    """
    import sys
    from pathlib import Path

    names = ["worldlines", "neonrp"]
    try:
        argv0 = Path(sys.argv[0]).stem.lower()
        if argv0 in names:
            names.remove(argv0)
            names.insert(0, argv0)
    except Exception:
        pass
    return names


# ---------------------------------------------------------------------------
# Cache (avoid hitting network on every single launch)
# ---------------------------------------------------------------------------

def _read_cache() -> dict[str, Any]:
    if not CACHE_PATH.exists():
        return {}
    try:
        return json.loads(CACHE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_cache(payload: dict[str, Any]) -> None:
    try:
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        CACHE_PATH.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def check_for_update_cached(
    *,
    channel: str | None = None,
    max_age_seconds: int = 6 * 3600,
) -> UpdateCheckResult:
    """Like check_for_update, but cache the result for `max_age_seconds`.

    This is what launch-time callers should use to avoid slowing every
    startup with a network round-trip.
    """
    import time

    cache = _read_cache()
    ts = cache.get("ts")
    payload = cache.get("result")
    fresh = isinstance(ts, (int, float)) and (time.time() - float(ts)) < max_age_seconds
    if fresh and isinstance(payload, dict):
        try:
            # The cache only authoritatively holds remote-fetched fields
            # (latest_version, release_notes_url, channel). Local state
            # — current_version and install_mode — is re-read every time
            # so a silent upgrade or switch between editable / released
            # installs is reflected immediately and never loops on a
            # stale "update available" decision.
            latest = payload.get("latest_version")
            current = get_current_version()
            install_mode = detect_install_mode()
            latest_str = latest if isinstance(latest, str) else None
            update_available = bool(latest_str) and is_newer(latest_str, current)
            return UpdateCheckResult(
                current_version=current,
                latest_version=latest_str,
                channel=payload.get("channel", DEFAULT_CHANNEL),
                update_available=update_available,
                install_mode=install_mode,
                release_notes_url=payload.get("release_notes_url"),
                error=payload.get("error"),
            )
        except Exception:
            pass

    result = check_for_update(channel=channel)
    _write_cache({"ts": time.time(), "result": result.to_json()})
    return result


def format_result_for_human(result: UpdateCheckResult) -> str:
    lines: list[str] = []
    lines.append(f"  current: {result.current_version}")
    lines.append(f"  channel: {result.channel}")
    lines.append(f"  install: {result.install_mode.kind} ({result.install_mode.detail})")
    if result.error:
        lines.append(f"  error:   {result.error}")
        return "\n".join(lines)
    if not result.latest_version:
        lines.append("  latest:  (unknown)")
        return "\n".join(lines)
    lines.append(f"  latest:  {result.latest_version}")
    if result.update_available:
        lines.append("  status:  update available")
        if result.release_notes_url:
            lines.append(f"  notes:   {result.release_notes_url}")
        if not result.install_mode.allow_auto_apply:
            lines.append("  note:    auto-apply disabled for this install (editable/unknown)")
    else:
        lines.append("  status:  up-to-date")
    return "\n".join(lines)
