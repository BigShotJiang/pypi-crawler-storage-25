"""Conversation engine for M9 interactive loop."""

from __future__ import annotations

import json
import logging
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Literal

from neonrp.core.active_agent import (
    NARRATOR_AGENT,
    clear_active_agent,
    get_active_agent_id,
    get_narrator_agent_id,
    write_active_agent,
)
from neonrp.core.agent_runner import _build_task_tool_schema, _execute_tool, run_agent_agentic
from neonrp.core.checkpoint import create_checkpoint
from neonrp.core.config import TUIConfig, load_config, resolve_provider
from neonrp.core.event_log import GameEvent, append_event
from neonrp.core.indexing import refresh_manifest_index
from neonrp.core.llm import LLMTurnResult, Message
from neonrp.core.llm import get_adapter_from_config
from neonrp.core.manifest import EntityRecord, Manifest
from neonrp.core.mcp_pool import MCPPool
from neonrp.core.paths import get_data_dir_name, get_manifest_path
from neonrp.core.prompts import build_system_prompt
from neonrp.core.runtime_contract import (
    get_router_agent_aliases,
    get_router_execution_mode,
    get_startup_entry_agent,
    get_startup_router_type,
    load_runtime_contract,
)
from neonrp.core.session import append_message, clear_session, read_session_messages, truncate_session
from neonrp.core.skill_loader import SkillLoader
from neonrp.core.skills import SkillRegistry, get_skill_schemas
from neonrp.core.storage import atomic_write_json
from neonrp.core.todo import TodoManager
from neonrp.core.tool_router import ToolRouter

logger = logging.getLogger(__name__)

MAX_CONVERSATION_TURNS = 20
API_RETRY_DELAYS_S = [2, 7, 15, 30]
ConversationMode = Literal["build", "sandbox", "play"]
ASK_USER_CANCELLED_RESPONSE = "__neonrp_ask_user_cancelled__"
REPEATED_READONLY_TOOL_STREAK_MAX = 4
REPEATED_READONLY_TOOL_BREAKER_MAX = 2
MISSING_READ_FILE_ERROR_STREAK_MAX = 3


def _is_initial_game_turn(root: Path, data_dir_name: str) -> bool:
    """Return True when the runtime is still at the pre-first-turn startup state."""
    run_state_path = root / data_dir_name / "meta" / "run_state.json"
    if not run_state_path.exists():
        return False
    try:
        payload = json.loads(run_state_path.read_text(encoding="utf-8"))
    except Exception:
        return False
    if not isinstance(payload, dict):
        return False
    try:
        turn_count = int(payload.get("turn_count", 0) or 0)
    except Exception:
        return False
    return turn_count <= 0
READONLY_TOOL_LOOP_GUARD = {
    "read_file",
    "read_context",
    "find",
    "list_entities",
    "glob",
    "grep",
    "resolve_action",
}
CONTEXT_PACK_MAX_ENTITIES = 6
CONTEXT_PACK_REGISTRY_MAX_ITEMS = 12
CONTEXT_PACK_ENTITY_MAX_CHARS = 900
CONTEXT_PACK_MAX_CHARS = 7000
_ENTITY_ID_TOKEN_PATTERN = re.compile(r"\b[a-z0-9][a-z0-9._-]{1,63}\b")

_TODO_ITEM_SCHEMA = {
    "type": "object",
    "properties": {
        "content": {
            "type": "string",
            "description": "What needs to be done (e.g., 'Create hero backstory')",
        },
        "status": {
            "type": "string",
            "enum": ["pending", "in_progress", "completed"],
            "description": "Current status of this item",
        },
        "activeForm": {
            "type": "string",
            "description": "Present-participle form shown during execution (e.g., 'Creating hero backstory')",
        },
    },
    "required": ["content", "status", "activeForm"],
}

TODO_TOOL_SCHEMA = {
    "name": "TodoWrite",
    "description": (
        "Update the structured todo list for tracking your work. "
        "Pass the COMPLETE list each time (not just changes). "
        "Exactly one item should be in_progress at a time."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "todos": {
                "type": "array",
                "description": "The full todo list. Max 20 items.",
                "items": _TODO_ITEM_SCHEMA,
            },
        },
        "required": ["todos"],
    },
}

HANDOFF_TO_ROUTER_TOOL_SCHEMA = {
    "name": "handoff_to_router",
    "description": (
        "Signal that the current sticky specialist has completed/exited its domain and control should return "
        "to the configured narrator/router agent. Use this instead of embedding protocol markers in reply text."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "reason": {
                "type": "string",
                "description": "Short reason for handoff (e.g., 'player left town to forest-path').",
            },
        },
        "required": [],
    },
}


def _skill_tool_schema(loader: SkillLoader) -> dict[str, Any]:
    available = loader.list_skills()
    listing = ", ".join(available) if available else "(none)"
    return {
        "name": "Skill",
        "description": (
            "Load a skill (reusable prompt snippet) by name and return its content. "
            "Skills provide domain-specific instructions or rules (e.g., combat rules, crafting recipes). "
            f"Available skills: {listing}. "
            "Call this when the user mentions a skill by name or when you need specialized guidance."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "skill": {
                    "type": "string",
                    "minLength": 1,
                    "description": f"Skill name to load. Must be one of: {listing}.",
                },
            },
            "required": ["skill"],
        },
    }


@dataclass
class ConversationTurnResult:
    """Result for a single conversation send() turn."""

    success: bool
    run_id: str
    assistant_message: str = ""
    assistant_speaker: str | None = None
    handoff_to: str | None = None
    route_decision: str | None = None
    active_agent: str | None = None
    delegated_to: str | None = None
    files_modified: list[str] = field(default_factory=list)
    tool_calls_made: list[str] = field(default_factory=list)
    turns_used: int = 0
    todo_snapshot: list[dict] = field(default_factory=list)
    usage: dict[str, Any] = field(default_factory=dict)
    proposal: dict[str, Any] | None = None
    error: str | None = None
    cancelled: bool = False


def run_conversation_turn(
    root: Path,
    agent_id: str,
    messages: list[Message],
    mode: ConversationMode = "build",
    provider: str | None = None,
    fixture_path: str | None = None,
    max_turns: int = MAX_CONVERSATION_TURNS,
    on_chunk: Callable[[str], None] | None = None,
    on_thinking: Callable[[str], None] | None = None,
    on_tool_use: Callable[[str, dict[str, Any]], None] | None = None,
    on_tool_result: Callable[[str, dict[str, Any], str], None] | None = None,
    on_ask_user: Callable[[str, list[str]], str | None] | None = None,
    todo_manager: TodoManager | None = None,
    skill_loader: SkillLoader | None = None,
    current_depth: int = 0,
    max_depth: int = 2,
    cancel_event: threading.Event | None = None,
    on_message_persist: Callable[[Message], None] | None = None,
    run_id: str | None = None,
    disabled_tools: set[str] | None = None,
) -> ConversationTurnResult:
    """Run one user turn with a multi-step tool-calling loop."""
    if mode not in {"build", "sandbox", "play"}:
        return ConversationTurnResult(success=False, run_id="", error=f"Unsupported mode: {mode}")

    router_execution_mode = get_router_execution_mode(root)
    run_id = run_id or f"{agent_id}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
    agent_dir = root / "agents" / agent_id
    agent_json_path = agent_dir / "agent.json"
    narrator_agent_id = get_narrator_agent_id(root)
    allow_router_fallback = agent_id == narrator_agent_id and router_execution_mode == "orchestrator"
    if not agent_dir.exists() and not (mode == "build" and agent_id == narrator_agent_id) and not allow_router_fallback:
        return ConversationTurnResult(success=False, run_id=run_id, error=f"Agent '{agent_id}' not found")
    if agent_dir.exists() and not agent_json_path.exists():
        return ConversationTurnResult(success=False, run_id=run_id, error=f"Cannot read agent.json for '{agent_id}'")
    if agent_json_path.exists():
        try:
            json.loads(agent_json_path.read_text(encoding="utf-8"))
        except Exception as exc:
            return ConversationTurnResult(success=False, run_id=run_id, error=f"Cannot read agent.json: {exc}")
    agent_data = _load_agent_data_for_mode(root, agent_id, mode)
    if agent_data is None:
        return ConversationTurnResult(success=False, run_id=run_id, error=f"Agent '{agent_id}' not found")

    manifest_path = get_manifest_path(root)
    if not manifest_path.exists():
        return ConversationTurnResult(success=False, run_id=run_id, error="NeonRP project not initialized")

    try:
        manifest = Manifest(**json.loads(manifest_path.read_text(encoding="utf-8")))
    except Exception as exc:
        return ConversationTurnResult(success=False, run_id=run_id, error=f"Failed to load manifest: {exc}")

    branch = manifest.current_branch
    if branch not in manifest.branches:
        return ConversationTurnResult(success=False, run_id=run_id, error=f"Branch '{branch}' not found in manifest")
    base_head_event = manifest.branches[branch].head_event

    config = load_config(root)
    if router_execution_mode == "orchestrator" and max_depth < 3:
        max_depth = 3
    runtime_contract = load_runtime_contract(root)
    agent_llm_config = agent_data.get("llm")
    provider_config = resolve_provider(config, agent_llm_config, provider)

    todo_manager = todo_manager or TodoManager()
    skill_loader = skill_loader or SkillLoader(root)

    try:
        adapter_kwargs: dict[str, Any] = {}
        if provider_config.provider == "stub" and fixture_path:
            adapter_kwargs["fixture_path"] = fixture_path
        adapter = get_adapter_from_config(provider_config, **adapter_kwargs)
        if provider_config.disable_streaming:
            logger.info("Streaming disabled for this provider (disable_streaming=true in model config)")
    except Exception as exc:
        return ConversationTurnResult(success=False, run_id=run_id, error=f"Failed to initialize LLM adapter: {exc}")

    # Always keep system prompt at index 0 and refresh on each call.
    agent_name = str(agent_data.get("name") or agent_id)
    base_system_prompt = build_system_prompt(
        agent_name=agent_name,
        project_name=root.name,
        branch=branch,
        mode=mode,
        skill_descriptions=skill_loader.get_descriptions(),
        project_root=str(root.resolve()),
        include_resolve_action=config.rules.enable_resolve_action,
        is_sub_agent=current_depth > 0,
        data_dir_name=runtime_contract.data_dir,
        routing_state_path=runtime_contract.active_agent_relpath,
        startup_path=runtime_contract.startup_relpath,
        location_source_entity_id=runtime_contract.routing.location_source.entity_id,
        location_source_field=runtime_contract.routing.location_source.field,
    )
    agent_policy = _load_agent_system_prompt_text(root, agent_id, agent_data)
    if agent_policy:
        system_prompt = (
            f"{base_system_prompt}\n\n"
            "## Agent-Specific Instructions\n"
            f"{agent_policy.strip()}\n"
        )
    else:
        system_prompt = base_system_prompt
    if not messages or messages[0].role != "system":
        messages.insert(0, Message(role="system", content=system_prompt))
    else:
        messages[0] = Message(role="system", content=system_prompt)

    permissions = agent_data.get("permissions", {})
    data_dir_name = runtime_contract.data_dir
    if mode == "build":
        # Build mode can write anywhere, including agents/ and .neonrp/.
        read_globs = ["**"]
        deny_globs: list[str] = []
        direct_write_globs = ["**"]
        allow_protected_paths = True
    else:
        read_globs = permissions.get("read_globs", ["**"])
        deny_globs = permissions.get("deny_globs", [])
        if mode == "play":
            # Play mode direct writes are controlled by agent permissions.
            # Prefer explicit direct_write_globs; fall back to write_globs for
            # backward compatibility with existing agent templates.
            configured_direct = permissions.get("direct_write_globs")
            configured_write = permissions.get("write_globs", [])
            if isinstance(configured_direct, list) and any(isinstance(p, str) and p.strip() for p in configured_direct):
                direct_write_globs = [p for p in configured_direct if isinstance(p, str) and p.strip()]
            elif isinstance(configured_write, list):
                direct_write_globs = [p for p in configured_write if isinstance(p, str) and p.strip()]
            else:
                direct_write_globs = []
        else:
            direct_write_globs = []
        allow_protected_paths = False

    # Routing-state ownership policy:
    # - Router agent can manage active-agent state.
    # - Specialists are denied by default unless explicitly opted in.
    routing_state_path = runtime_contract.active_agent_relpath
    allow_routing_state_write = bool(permissions.get("allow_routing_state_write", False))
    if agent_id != narrator_agent_id and not allow_routing_state_write:
        if routing_state_path not in deny_globs:
            deny_globs = [*deny_globs, routing_state_path]

    skill_registry = SkillRegistry(
        root,
        run_id,
        agent_id,
        read_globs,
        deny_globs,
        direct_write_globs,
        allow_protected_paths=allow_protected_paths,
        enable_resolve_action=config.rules.enable_resolve_action,
    )
    tool_schemas = _get_tool_schemas(
        mode,
        skill_loader,
        root,
        include_resolve_action=config.rules.enable_resolve_action,
    )
    if agent_id == narrator_agent_id and router_execution_mode == "fast":
        # Fast mode keeps ask_user owned by specialists.
        tool_schemas = [schema for schema in tool_schemas if schema.get("name") != "ask_user"]
    # Prevent infinite sub-agent nesting: strip task tool at depth limit
    if current_depth >= max_depth - 1:
        tool_schemas = [s for s in tool_schemas if s.get("name") != "task"]
    if disabled_tools:
        blocked = {str(name).strip() for name in disabled_tools if isinstance(name, str) and str(name).strip()}
        if blocked:
            tool_schemas = [s for s in tool_schemas if str(s.get("name", "")) not in blocked]

    # MCP integration (M11-T4): create pool + router if MCP servers configured
    mcp_pool: MCPPool | None = None
    tool_router: ToolRouter | None = None
    if config.mcp_servers:
        enabled = {n: c for n, c in config.mcp_servers.items() if c.enabled}
        if enabled:
            mcp_pool = MCPPool(enabled)
            startup_errors = mcp_pool.ensure_started()
            # Surface startup failures (should-fix #3)
            for srv_name, srv_err in startup_errors.items():
                if srv_err:
                    logger.warning("MCP server '%s' failed to start: %s", srv_name, srv_err)
            audit_path = root / ".neonrp" / "logs" / "mcp"
            tool_router = ToolRouter(
                mcp_pool, configs=enabled, audit_path=audit_path, run_id=run_id,
            )
            tool_schemas = tool_router.get_merged_schemas(tool_schemas)

    tool_schemas = _filter_tool_schemas_by_agent_config(tool_schemas, agent_data)
    allowed_tool_names = {schema.get("name", "") for schema in tool_schemas if schema.get("name")}
    active_agent_id = get_active_agent_id(root) if (current_depth == 0 and router_execution_mode == "fast") else narrator_agent_id
    agent_policy = _get_agent_policy(root, agent_id, agent_data, narrator_agent_id=narrator_agent_id)
    enforce_narrator_guardrail = bool(
        agent_id == narrator_agent_id
        and agent_policy["disallow_direct_game_tools"]
        and router_execution_mode != "orchestrator"
    )

    try:  # guarantee MCP pool cleanup (must-fix #1)
        files_modified: list[str] = []
        tool_calls_made: list[str] = []
        assistant_chunks: list[str] = []
        usage: dict[str, Any] = {}
        proposal_data: dict[str, Any] | None = None
        _empty_args_streak = 0  # circuit breaker for empty-argument tool calls
        _EMPTY_ARGS_MAX = 3  # stop after this many consecutive empty-argument failures
        _last_readonly_tool_sig: str | None = None
        _readonly_tool_streak = 0
        _readonly_breaker_trips = 0
        _missing_read_file_error_streak = 0
        requested_handoff_to: str | None = None
        requested_route_decision: str | None = None
        requested_active_agent: str | None = None
        requested_delegated_to: str | None = None
        checkpoint_created = False

        # Narrator top-level scheduler path: route to specialists and return their result.
        if (
            current_depth == 0
            and mode in {"build", "play"}
            and agent_id == narrator_agent_id
            and agent_policy["role"] == "router"
            and router_execution_mode == "fast"
        ):
            latest_user_text = ""
            for msg in reversed(messages):
                if msg.role == "user" and isinstance(msg.content, str) and msg.content.strip():
                    latest_user_text = msg.content.strip()
                    break
            if not latest_user_text:
                return ConversationTurnResult(
                    success=False,
                    run_id=run_id,
                    error="Narrator scheduler requires a user message to route.",
                    turns_used=0,
                    todo_snapshot=todo_manager.snapshot(),
                )

            routed_segments: list[str] = []
            routed_files: list[str] = []
            routed_tools: list[str] = []
            routed_usage: dict[str, Any] = {}
            total_routed_turns = 0
            last_run_id = run_id
            last_speaker = ""
            previous_agent_id = ""
            previous_assistant_text = ""
            reroutes_remaining = 1
            last_route_decision: str | None = None
            last_active_agent: str | None = None
            last_delegated_to: str | None = None

            while True:
                target_agent_id = get_active_agent_id(root)
                last_active_agent = target_agent_id
                if target_agent_id != narrator_agent_id and _should_release_active_agent_lock(
                    root,
                    data_dir_name,
                    latest_user_text,
                    target_agent_id,
                    narrator_agent_id=narrator_agent_id,
                ):
                    clear_active_agent(root, updated_by=narrator_agent_id)
                    target_agent_id = narrator_agent_id
                    last_active_agent = narrator_agent_id
                if target_agent_id == narrator_agent_id:
                    selected = _select_router_target_agent(root, data_dir_name, narrator_agent_id)
                    if selected:
                        target_agent_id = selected
                        last_route_decision = "router_selected_specialist"
                        last_delegated_to = selected
                    else:
                        last_route_decision = "router_no_specialist"
                        last_delegated_to = None
                else:
                    last_route_decision = "active_agent_lock"
                    last_delegated_to = target_agent_id
                if not target_agent_id or target_agent_id == narrator_agent_id:
                    if routed_segments:
                        return ConversationTurnResult(
                            success=True,
                            run_id=last_run_id,
                            assistant_message="\n\n".join(segment for segment in routed_segments if segment),
                            assistant_speaker=last_speaker or previous_agent_id or narrator_agent_id,
                            files_modified=routed_files,
                            tool_calls_made=routed_tools or ["task"],
                            turns_used=total_routed_turns or 1,
                            todo_snapshot=todo_manager.snapshot(),
                            usage=routed_usage,
                            handoff_to=narrator_agent_id,
                            route_decision=last_route_decision,
                            active_agent=last_active_agent,
                            delegated_to=last_delegated_to,
                        )
                    return ConversationTurnResult(
                        success=False,
                        run_id=run_id,
                        error="Router could not select a specialist agent for this turn.",
                        turns_used=0,
                        todo_snapshot=todo_manager.snapshot(),
                        route_decision=last_route_decision,
                        active_agent=last_active_agent,
                        delegated_to=last_delegated_to,
                    )

                task_prompt = _build_router_task_prompt(
                    data_dir_name,
                    latest_user_text,
                    previous_agent_id=previous_agent_id,
                    previous_assistant_text=previous_assistant_text,
                )
                task_args = {"agent_id": target_agent_id, "prompt": task_prompt}
                if on_tool_use:
                    on_tool_use("task", task_args)
                routed_result = _dispatch_sub_agent(
                    task_data=task_args,
                    root=root,
                    mode=mode,
                    max_turns=max_turns,
                    caller_agent_id=agent_id,
                    on_chunk=on_chunk,
                    on_thinking=on_thinking,
                    on_tool_use=on_tool_use,
                    on_tool_result=on_tool_result,
                    on_ask_user=on_ask_user,
                    current_depth=current_depth,
                    max_depth=max_depth,
                    cancel_event=cancel_event,
                    on_message_persist=on_message_persist,
                )
                routed_tools.append("task")
                if on_tool_result:
                    on_tool_result("task", task_args, routed_result)
                try:
                    payload = json.loads(routed_result)
                except Exception:
                    payload = {"status": "error", "error": f"Invalid task result: {routed_result}"}
                tool_message = Message(role="tool", content=_json_dumps(payload), name="task")
                messages.append(tool_message)
                if on_message_persist:
                    on_message_persist(tool_message)
                data = payload.get("data") if isinstance(payload, dict) else {}
                if not isinstance(data, dict):
                    data = {}
                usage_data = data.get("usage")
                if not isinstance(usage_data, dict):
                    usage_data = {}
                assistant_speaker = str(data.get("agent_id") or "").strip() or target_agent_id
                assistant_text = str(data.get("assistant_text") or "")
                handoff_to = str(data.get("handoff_to") or "").strip().lower() or None
                if assistant_text:
                    routed_segments.append(assistant_text)
                    assistant_msg = Message(role="assistant", content=assistant_text, name=assistant_speaker)
                    messages.append(assistant_msg)
                    if on_message_persist:
                        on_message_persist(assistant_msg)
                last_speaker = assistant_speaker
                last_run_id = str(data.get("run_id") or last_run_id)
                total_routed_turns += int(data.get("turns_used") or 1)
                _merge_usage(routed_usage, usage_data)
                for path in data.get("files_modified", []):
                    if isinstance(path, str) and path not in routed_files:
                        routed_files.append(path)

                status = str(payload.get("status", "")).strip().lower()
                if (
                    router_execution_mode == "fast"
                    and status == "success"
                    and handoff_to == narrator_agent_id
                    and reroutes_remaining > 0
                ):
                    reroutes_remaining -= 1
                    previous_agent_id = assistant_speaker
                    previous_assistant_text = assistant_text
                    continue

                combined_text = "\n\n".join(segment for segment in routed_segments if segment)
                current_active_after_dispatch = str(data.get("active_agent") or get_active_agent_id(root) or last_active_agent or "").strip() or None
                delegated_to = str(data.get("delegated_to") or last_delegated_to or target_agent_id or "").strip() or None
                player_facing_speaker = assistant_speaker if router_execution_mode == "fast" else narrator_agent_id
                if status == "success":
                    return ConversationTurnResult(
                        success=True,
                        run_id=last_run_id,
                        assistant_message=combined_text,
                        assistant_speaker=player_facing_speaker,
                        route_decision=str(data.get("route_decision") or last_route_decision or "").strip() or None,
                        active_agent=current_active_after_dispatch,
                        delegated_to=delegated_to,
                        files_modified=routed_files,
                        tool_calls_made=routed_tools,
                        turns_used=total_routed_turns or 1,
                        todo_snapshot=todo_manager.snapshot(),
                        usage=routed_usage,
                        handoff_to=handoff_to,
                    )
                if status == "cancelled":
                    return ConversationTurnResult(
                        success=True,
                        run_id=last_run_id,
                        assistant_message=combined_text,
                        assistant_speaker=player_facing_speaker,
                        route_decision=str(data.get("route_decision") or last_route_decision or "").strip() or None,
                        active_agent=current_active_after_dispatch,
                        delegated_to=delegated_to,
                        files_modified=routed_files,
                        tool_calls_made=routed_tools,
                        turns_used=total_routed_turns or 1,
                        todo_snapshot=todo_manager.snapshot(),
                        usage=routed_usage,
                        cancelled=True,
                        handoff_to=handoff_to,
                    )
                return ConversationTurnResult(
                    success=False,
                    run_id=last_run_id,
                    assistant_message=combined_text,
                    assistant_speaker=player_facing_speaker,
                    route_decision=str(data.get("route_decision") or last_route_decision or "").strip() or None,
                    active_agent=current_active_after_dispatch,
                    delegated_to=delegated_to,
                    files_modified=routed_files,
                    tool_calls_made=routed_tools,
                    turns_used=total_routed_turns or 1,
                    todo_snapshot=todo_manager.snapshot(),
                    usage=routed_usage,
                    error=str(payload.get("error") or f"Sub-agent '{target_agent_id}' failed"),
                    handoff_to=handoff_to,
                )

        turn = 0
        api_retries = 0
        while turn < max_turns:
            # --- ESC / cancel check ---
            if cancel_event is not None and cancel_event.is_set():
                return ConversationTurnResult(
                    success=True,
                    run_id=run_id,
                    assistant_message="\n".join(assistant_chunks),
                    files_modified=files_modified,
                    tool_calls_made=tool_calls_made,
                    turns_used=turn,
                    todo_snapshot=todo_manager.snapshot(),
                    usage=usage,
                    cancelled=True,
                )

            turn += 1
            short_circuit_turn = False
            _truncate_messages_for_budget(messages, config.llm.max_context_chars)

            use_streaming = (on_chunk or on_thinking) and not provider_config.disable_streaming
            if use_streaming:
                turn_result = _chat_stream(adapter, messages, tool_schemas, on_chunk, on_thinking, cancel_event)
            else:
                turn_result = adapter.chat(messages, tools=tool_schemas)
                # When streaming is disabled but callbacks exist, deliver the
                # complete response in one shot so the TUI still displays it.
                if turn_result.message and turn_result.message.content and on_chunk:
                    on_chunk(turn_result.message.content)

            _merge_usage(usage, turn_result.usage)

            # --- ESC / cancel check right after LLM call returns ---
            if cancel_event is not None and cancel_event.is_set():
                # Preserve any partial content already streamed
                if turn_result.message and turn_result.message.content:
                    assistant_chunks.append(turn_result.message.content)
                return ConversationTurnResult(
                    success=True,
                    run_id=run_id,
                    assistant_message="\n".join(assistant_chunks),
                    files_modified=files_modified,
                    tool_calls_made=tool_calls_made,
                    turns_used=turn,
                    todo_snapshot=todo_manager.snapshot(),
                    usage=usage,
                    cancelled=True,
                )
            if not turn_result.success:
                should_retry = turn_result.retryable or _looks_retryable_error_text(turn_result.error)
                if should_retry and api_retries < len(API_RETRY_DELAYS_S):
                    delay_s = API_RETRY_DELAYS_S[api_retries]
                    api_retries += 1
                    logger.warning(
                        "Retryable API error on turn %d (attempt %d/%d), retrying in %ds: %s",
                        turn, api_retries, len(API_RETRY_DELAYS_S), delay_s, turn_result.error,
                    )
                    time.sleep(delay_s)
                    # Trim the last assistant+tool exchange that may have caused
                    # a 400 Bad Request (e.g. malformed tool_use/tool_result pair).
                    _trim_broken_tail(messages)
                    turn -= 1  # don't count failed attempt
                    continue
                return ConversationTurnResult(
                    success=False,
                    run_id=run_id,
                    files_modified=files_modified,
                    tool_calls_made=tool_calls_made,
                    turns_used=turn,
                    todo_snapshot=todo_manager.snapshot(),
                    usage=usage,
                    error=f"LLM call failed on turn {turn}: {turn_result.error}",
                )
            api_retries = 0  # reset on success

            if turn_result.message:
                messages.append(turn_result.message)
                if on_message_persist:
                    on_message_persist(turn_result.message)
                if turn_result.message.content:
                    assistant_chunks.append(turn_result.message.content)

            if not turn_result.tool_calls:
                if mode == "sandbox":
                    break
                return _finalize_turn(
                    root=root,
                    run_id=run_id,
                    branch=branch,
                    base_head_event=base_head_event,
                    mode=mode,
                    agent_id=agent_id,
                    assistant_chunks=assistant_chunks,
                    files_modified=files_modified,
                    tool_calls_made=tool_calls_made,
                    turns_used=turn,
                    todo_manager=todo_manager,
                    usage=usage,
                    proposal=proposal_data,
                    handoff_to=requested_handoff_to,
                    route_decision=requested_route_decision or "self",
                    active_agent=requested_active_agent or agent_id,
                    delegated_to=requested_delegated_to,
                )

            for tool_call in turn_result.tool_calls:
                # --- ESC / cancel check before each tool ---
                if cancel_event is not None and cancel_event.is_set():
                    return ConversationTurnResult(
                        success=True,
                        run_id=run_id,
                        assistant_message="\n".join(assistant_chunks),
                        route_decision=requested_route_decision,
                        active_agent=requested_active_agent or agent_id,
                        delegated_to=requested_delegated_to,
                        files_modified=files_modified,
                        tool_calls_made=tool_calls_made,
                        turns_used=turn,
                        todo_snapshot=todo_manager.snapshot(),
                        usage=usage,
                        cancelled=True,
                    )

                # Normalize malformed tool names like glob("**/*.json") → name="glob", args merged
                _normalize_tool_call(tool_call, tool_schemas)

                logger.debug(
                    "tool_call start: run=%s turn=%d agent=%s id=%s name=%s args=%s",
                    run_id,
                    turn,
                    agent_id,
                    tool_call.id,
                    tool_call.name,
                    _preview_for_log(tool_call.arguments),
                )
                tool_calls_made.append(tool_call.name)
                if on_tool_use:
                    on_tool_use(tool_call.name, tool_call.arguments)
                tool_cancelled = False

                if tool_call.name not in allowed_tool_names:
                    logger.debug(
                        "tool_call blocked_by_allowlist: run=%s agent=%s id=%s name=%s allowed=%s",
                        run_id,
                        agent_id,
                        tool_call.id,
                        tool_call.name,
                        sorted(allowed_tool_names),
                    )
                    tool_result = _json_dumps(
                        {
                            "status": "error",
                            "error": (
                                f"Tool '{tool_call.name}' is not enabled for agent '{agent_id}'. "
                                "Use one of the configured tools in agent.json."
                            ),
                            "data": {"allowed_tools": sorted(allowed_tool_names)},
                        }
                    )
                    if on_tool_result:
                        on_tool_result(tool_call.name, tool_call.arguments, tool_result)
                    tool_msg = Message(
                        role="tool",
                        content=tool_result,
                        tool_call_id=tool_call.id,
                        name=tool_call.name,
                    )
                    messages.append(tool_msg)
                    if on_message_persist:
                        on_message_persist(tool_msg)
                    continue

                if _should_block_narrator_tool_call(
                    agent_id=agent_id,
                    tool_name=tool_call.name,
                    tool_args=tool_call.arguments,
                    data_dir_name=data_dir_name,
                    enforce_guardrail=enforce_narrator_guardrail,
                    narrator_agent_id=narrator_agent_id,
                ):
                    logger.debug(
                        "tool_call blocked_by_narrator_guardrail: run=%s id=%s name=%s args=%s active_agent=%s",
                        run_id,
                        tool_call.id,
                        tool_call.name,
                        _preview_for_log(tool_call.arguments),
                        active_agent_id,
                    )
                    delegate_hint = (
                        active_agent_id
                        if active_agent_id != narrator_agent_id
                        else "the appropriate specialist agent"
                    )
                    tool_result = _json_dumps(
                        {
                            "status": "error",
                            "error": (
                                "Narrator guardrail: direct game-entity operations are not allowed. "
                                f"Delegate via task() to {delegate_hint}."
                            ),
                            "data": {"active_agent": active_agent_id},
                        }
                    )
                    if on_tool_result:
                        on_tool_result(tool_call.name, tool_call.arguments, tool_result)
                    tool_msg = Message(
                        role="tool",
                        content=tool_result,
                        tool_call_id=tool_call.id,
                        name=tool_call.name,
                    )
                    messages.append(tool_msg)
                    if on_message_persist:
                        on_message_persist(tool_msg)
                    continue

                current_active_agent = active_agent_id
                if agent_id == narrator_agent_id and current_depth == 0 and router_execution_mode == "fast":
                    current_active_agent = get_active_agent_id(root)

                if (
                    agent_id == narrator_agent_id
                    and tool_call.name == "ask_user"
                    and router_execution_mode == "fast"
                    and current_active_agent != narrator_agent_id
                    and _get_agent_delegation_mode(root, current_active_agent) == "sticky"
                ):
                    logger.debug(
                        "tool_call blocked_by_sticky_ask_user_policy: run=%s id=%s active_agent=%s",
                        run_id,
                        tool_call.id,
                        current_active_agent,
                    )
                    tool_result = _json_dumps(
                        {
                            "status": "error",
                            "error": (
                                "Narrator cannot call ask_user while a sticky specialist agent is active. "
                                f"Delegate via task() to '{current_active_agent}'."
                            ),
                            "data": {"active_agent": current_active_agent, "policy": "sticky_subagent_owns_ask_user"},
                        }
                    )
                    if on_tool_result:
                        on_tool_result(tool_call.name, tool_call.arguments, tool_result)
                    tool_msg = Message(
                        role="tool",
                        content=tool_result,
                        tool_call_id=tool_call.id,
                        name=tool_call.name,
                    )
                    messages.append(tool_msg)
                    if on_message_persist:
                        on_message_persist(tool_msg)
                    continue

                if (
                    mode in {"build", "play"}
                    and tool_call.name in {"write_file", "edit_file", "delete_file", "ensure_playable_scaffold"}
                    and not checkpoint_created
                ):
                    create_checkpoint(root, branch, base_head_event)
                    checkpoint_created = True

                if _is_loop_guard_readonly_tool(tool_call.name):
                    current_sig = _tool_call_signature(tool_call.name, tool_call.arguments)
                    if current_sig == _last_readonly_tool_sig:
                        _readonly_tool_streak += 1
                    else:
                        _last_readonly_tool_sig = current_sig
                        _readonly_tool_streak = 1
                    if _readonly_tool_streak >= REPEATED_READONLY_TOOL_STREAK_MAX:
                        _readonly_breaker_trips += 1
                        logger.warning(
                            "Circuit breaker: repeated identical read-only tool call (%d): %s args=%s",
                            _readonly_tool_streak,
                            tool_call.name,
                            _preview_for_log(tool_call.arguments, 220),
                        )
                        tool_result = _json_dumps(
                            {
                                "status": "error",
                                "error": (
                                    "Detected repeated identical read-only tool call without progress. "
                                    "Stop repeating this call and either delegate, ask_user, or respond based on known state."
                                ),
                                "data": {
                                    "tool": tool_call.name,
                                    "repeat_count": _readonly_tool_streak,
                                    "guard": "repeated_readonly_tool_loop",
                                },
                            }
                        )
                        if on_tool_result:
                            on_tool_result(tool_call.name, tool_call.arguments, tool_result)
                        tool_msg = Message(
                            role="tool",
                            content=tool_result,
                            tool_call_id=tool_call.id,
                            name=tool_call.name,
                        )
                        messages.append(tool_msg)
                        if on_message_persist:
                            on_message_persist(tool_msg)
                        messages.append(
                            Message(
                                role="user",
                                content=(
                                    "[System: You are repeating the same read-only tool call with identical arguments. "
                                    "Do not call it again now. Continue with task(), ask_user(), or a normal reply.]"
                                ),
                            )
                        )
                        _readonly_tool_streak = 0
                        short_circuit_turn = True
                        if _readonly_breaker_trips >= REPEATED_READONLY_TOOL_BREAKER_MAX:
                            return ConversationTurnResult(
                                success=False,
                                run_id=run_id,
                                files_modified=files_modified,
                                tool_calls_made=tool_calls_made,
                                turns_used=turn,
                                todo_snapshot=todo_manager.snapshot(),
                                usage=usage,
                                error=(
                                    "Conversation aborted: repeated identical read-only tool calls "
                                    "indicate an LLM loop."
                                ),
                            )
                        break
                else:
                    _last_readonly_tool_sig = None
                    _readonly_tool_streak = 0

                if tool_call.name == "TodoWrite":
                    tool_result = _handle_todo_tool(todo_manager, tool_call.arguments)
                elif tool_call.name == "Skill":
                    tool_result = _handle_skill_tool(skill_loader, tool_call.arguments)
                elif tool_call.name == "handoff_to_router":
                    if agent_id == narrator_agent_id:
                        tool_result = _json_dumps(
                            {
                                "status": "error",
                                "error": "Narrator/router is already active; handoff_to_router is for specialist agents.",
                            }
                        )
                    else:
                        handoff_reason = str(tool_call.arguments.get("reason", "") or "").strip()
                        requested_handoff_to = narrator_agent_id
                        tool_result = _json_dumps(
                            {
                                "status": "success",
                                "data": {
                                    "handoff_to": narrator_agent_id,
                                    "reason": handoff_reason,
                                    "by": agent_id,
                                },
                            }
                        )
                elif tool_call.name == "task":
                    logger.debug(
                        "tool_call dispatch_sub_agent: run=%s caller=%s id=%s task=%s",
                        run_id,
                        agent_id,
                        tool_call.id,
                        _preview_for_log(tool_call.arguments),
                    )
                    tool_result = _dispatch_sub_agent(
                        task_data=tool_call.arguments,
                        root=root,
                        mode=mode,
                        # Give sub-agents their own turn budget instead of inheriting the
                        # parent's remaining turns (which caused confusing limits like 15).
                        max_turns=max_turns,
                        caller_agent_id=agent_id,
                        on_chunk=on_chunk,
                        on_thinking=on_thinking,
                        on_tool_use=on_tool_use,
                        on_tool_result=on_tool_result,
                        on_ask_user=on_ask_user,
                        current_depth=current_depth,
                        max_depth=max_depth,
                        cancel_event=cancel_event,
                        on_message_persist=on_message_persist,
                    )
                    parsed_task = _parse_task_tool_result(tool_result)
                    if parsed_task is not None:
                        requested_route_decision = str(parsed_task.get("route_decision") or requested_route_decision or "").strip() or requested_route_decision
                        requested_active_agent = str(parsed_task.get("active_agent") or requested_active_agent or "").strip() or requested_active_agent
                        requested_delegated_to = (
                            str(parsed_task.get("delegated_to") or tool_call.arguments.get("agent_id") or requested_delegated_to or "").strip()
                            or requested_delegated_to
                        )
                    # If the nested run was canceled (e.g. sub-agent ask_user Esc),
                    # stop this parent turn as well instead of continuing generation.
                    tool_cancelled = _is_cancelled_tool_result(tool_result)
                else:
                    # Try MCP router first (M11-T4)
                    mcp_handled = False
                    ask_user_data = None
                    if tool_router:
                        router_result = tool_router.dispatch(
                            tool_call.name,
                            tool_call.arguments,
                            run_id=run_id,
                            agent_id=agent_id,
                        )
                        if router_result.handled:
                            # should-fix #1: handle confirm permission flow
                            if router_result.needs_confirm and on_ask_user:
                                confirm_info = json.loads(router_result.result_json)
                                answer = on_ask_user(
                                    f"MCP tool '{confirm_info.get('tool', '')}' on server "
                                    f"'{confirm_info.get('server', '')}' requires confirmation. Allow?",
                                    ["yes", "no"],
                                )
                                if isinstance(answer, tuple):
                                    answer = answer[0]
                                if str(answer).lower() in ("yes", "y", "1"):
                                    router_result = tool_router.dispatch(
                                        tool_call.name,
                                        tool_call.arguments,
                                        run_id=run_id,
                                        agent_id=agent_id,
                                        confirmed=True,
                                    )
                                    tool_result = router_result.result_json
                                else:
                                    tool_result = _json_dumps({
                                        "status": "error",
                                        "error": "MCP tool call rejected by user",
                                    })
                            else:
                                tool_result = router_result.result_json
                            mcp_handled = True

                    if not mcp_handled:
                        run_context = {
                            "run_id": run_id,
                            "agent_id": agent_id,
                            "branch": branch,
                            "base_head_event": base_head_event,
                        }
                        tool_result, submitted_proposal, ask_user_data, _ = _execute_tool(
                            skill_registry,
                            tool_call,
                            run_context,
                            include_resolve_action=config.rules.enable_resolve_action,
                            allowed_tool_names=allowed_tool_names,
                        )
                        if submitted_proposal:
                            proposal_data = submitted_proposal

                        # --- Circuit breaker for empty-argument tool calls ---
                        # Some providers (Ollama) intermittently drop tool call
                        # arguments.  After N consecutive failures, stop retrying
                        # and ask the model to respond with plain text instead.
                        if not tool_call.arguments:
                            _empty_args_streak += 1
                            if _empty_args_streak >= _EMPTY_ARGS_MAX:
                                logger.warning(
                                    "Circuit breaker: %d consecutive empty-argument "
                                    "tool calls for '%s'. Forcing text-only reply.",
                                    _empty_args_streak,
                                    tool_call.name,
                                )
                                # Append the error result so the model sees it
                                messages.append(Message(
                                    role="tool",
                                    content=tool_result,
                                    tool_call_id=tool_call.id,
                                    name=tool_call.name,
                                ))
                                # Inject a user-role hint to break the loop
                                messages.append(Message(
                                    role="user",
                                    content=(
                                        "[System: Tool call arguments are being lost by the API. "
                                        "Stop calling tools. Instead, write your question or "
                                        "choices as plain text in your reply.]"
                                    ),
                                ))
                                _empty_args_streak = 0
                                break  # exit tool-call for-loop → triggers new LLM turn
                        else:
                            _empty_args_streak = 0

                    if ask_user_data:
                        questions_list = ask_user_data.get("questions", [])
                        logger.debug(
                            "tool_call ask_user_prompt: run=%s id=%s questions=%s",
                            run_id,
                            tool_call.id,
                            _preview_for_log(questions_list),
                        )
                        if on_ask_user:
                            answers: dict[str, str] = {}
                            cancelled = False
                            for idx, q_item in enumerate(questions_list):
                                q_text = str(q_item.get("question", ""))
                                labels = [
                                    str(o.get("label", "")) for o in q_item.get("options", [])
                                    if isinstance(o, dict)
                                ]
                                response_raw = on_ask_user(q_text, labels)
                                if isinstance(response_raw, tuple):
                                    response_raw = response_raw[0] if response_raw else ""
                                if response_raw is None or str(response_raw) == ASK_USER_CANCELLED_RESPONSE:
                                    cancelled = True
                                    logger.debug(
                                        "tool_call ask_user_cancelled: run=%s id=%s q_idx=%d",
                                        run_id, tool_call.id, idx,
                                    )
                                    break
                                answers[str(idx)] = str(response_raw or "")
                            if cancelled:
                                tool_cancelled = True
                                tool_result = _json_dumps({"status": "cancelled"})
                            else:
                                logger.debug(
                                    "tool_call ask_user_answers: run=%s id=%s answers=%s",
                                    run_id, tool_call.id, _preview_for_log(answers, 200),
                                )
                                tool_result = _json_dumps({"answers": answers})
                        else:
                            tool_result = _json_dumps(
                                {"status": "error", "error": "ask_user not available (no callback provided)"}
                            )

                logger.debug(
                    "tool_call result: run=%s turn=%d agent=%s id=%s name=%s %s",
                    run_id,
                    turn,
                    agent_id,
                    tool_call.id,
                    tool_call.name,
                    _summarize_tool_result_for_log(tool_result),
                )
                if on_tool_result:
                    on_tool_result(tool_call.name, tool_call.arguments, tool_result)

                _track_modified_files(tool_call.name, tool_result, files_modified)

                if _is_missing_read_file_error(tool_call.name, tool_result):
                    _missing_read_file_error_streak += 1
                elif tool_call.name == "read_file":
                    _missing_read_file_error_streak = 0

                tool_msg = Message(
                    role="tool",
                    content=tool_result,
                    tool_call_id=tool_call.id,
                    name=tool_call.name,
                )
                messages.append(tool_msg)
                if on_message_persist:
                    on_message_persist(tool_msg)
                if (
                    agent_id == narrator_agent_id
                    and current_depth == 0
                    and tool_call.name == "task"
                    and _is_sticky_task_success(tool_result)
                ):
                    payload = _parse_task_tool_result(tool_result) or {}
                    data = payload.get("data")
                    if not isinstance(data, dict):
                        data = {}
                    sub_agent_id = str(data.get("agent_id") or "").strip()
                    sub_assistant_speaker = sub_agent_id or None
                    sub_assistant_text = str(data.get("assistant_text") or "")
                    handoff_target = str(data.get("handoff_to") or "").strip().lower()
                    if sub_assistant_text:
                        assistant_chunks.append(sub_assistant_text)
                        assistant_msg = Message(
                            role="assistant",
                            content=sub_assistant_text,
                            name=sub_assistant_speaker,
                        )
                        messages.append(assistant_msg)
                        if on_message_persist:
                            on_message_persist(assistant_msg)
                    nested_files = [p for p in data.get("files_modified", []) if isinstance(p, str)]
                    for path in nested_files:
                        if path not in files_modified:
                            files_modified.append(path)
                    nested_usage = data.get("usage")
                    if isinstance(nested_usage, dict):
                        _merge_usage(usage, nested_usage)
                    if handoff_target:
                        requested_handoff_to = handoff_target
                    logger.debug(
                        "narrator sticky short-circuit: run=%s turn=%d task=%s assistant_len=%d files=%d",
                        run_id,
                        turn,
                        tool_call.id,
                        len(sub_assistant_text),
                        len(nested_files),
                    )
                    return ConversationTurnResult(
                        success=True,
                        run_id=run_id,
                        assistant_message="\n".join(assistant_chunks),
                        files_modified=files_modified,
                        tool_calls_made=tool_calls_made,
                        turns_used=turn,
                        todo_snapshot=todo_manager.snapshot(),
                        usage=usage,
                        assistant_speaker=sub_assistant_speaker or agent_id,
                        handoff_to=requested_handoff_to,
                    )
                if _missing_read_file_error_streak >= MISSING_READ_FILE_ERROR_STREAK_MAX:
                    logger.warning(
                        "Circuit breaker: %d consecutive read_file not-found errors (run=%s agent=%s).",
                        _missing_read_file_error_streak,
                        run_id,
                        agent_id,
                    )
                    messages.append(
                        Message(
                            role="user",
                            content=(
                                "[System: Multiple read_file attempts failed with File not found. "
                                "Stop guessing file paths. Use find/list_entities/glob to confirm paths first, "
                                "or continue with the context already available.]"
                            ),
                        )
                    )
                    _missing_read_file_error_streak = 0
                    short_circuit_turn = True
                    break
                if tool_cancelled:
                    return ConversationTurnResult(
                        success=True,
                        run_id=run_id,
                        assistant_message="\n".join(assistant_chunks),
                        files_modified=files_modified,
                        tool_calls_made=tool_calls_made,
                        turns_used=turn,
                        todo_snapshot=todo_manager.snapshot(),
                        usage=usage,
                        cancelled=True,
                        handoff_to=requested_handoff_to,
                    )
            if short_circuit_turn:
                continue

            if mode == "sandbox" and proposal_data:
                return _finalize_turn(
                    root=root,
                    run_id=run_id,
                    branch=branch,
                    base_head_event=base_head_event,
                    mode=mode,
                    agent_id=agent_id,
                    assistant_chunks=assistant_chunks,
                    files_modified=files_modified,
                    tool_calls_made=tool_calls_made,
                    turns_used=turn,
                    todo_manager=todo_manager,
                    usage=usage,
                    proposal=proposal_data,
                    route_decision=requested_route_decision or "self",
                    active_agent=requested_active_agent or agent_id,
                    delegated_to=requested_delegated_to,
                )

        if mode == "sandbox" and not proposal_data:
            return ConversationTurnResult(
                success=False,
                run_id=run_id,
                files_modified=files_modified,
                tool_calls_made=tool_calls_made,
                turns_used=turn,
                todo_snapshot=todo_manager.snapshot(),
                usage=usage,
                error="Sandbox mode requires submit_proposal before ending a turn",
            )

        return ConversationTurnResult(
            success=False,
            run_id=run_id,
            route_decision=requested_route_decision or "self",
            active_agent=requested_active_agent or agent_id,
            delegated_to=requested_delegated_to,
            files_modified=files_modified,
            tool_calls_made=tool_calls_made,
            turns_used=turn,
            todo_snapshot=todo_manager.snapshot(),
            usage=usage,
            error=f"Conversation exceeded max turns ({max_turns})",
            handoff_to=requested_handoff_to,
        )

    finally:  # must-fix #1: always stop MCP pool
        if mcp_pool is not None:
            try:
                mcp_pool.stop_all()
            except Exception as exc:
                logger.warning("Error stopping MCP pool: %s", exc)


class ConversationSession:
    """Persistent conversation state for interactive UIs."""

    def __init__(
        self,
        root: Path,
        agent_id: str,
        mode: ConversationMode = "build",
        provider: str | None = None,
        max_turns: int | None = None,
        todo_manager: TodoManager | None = None,
        skill_loader: SkillLoader | None = None,
    ):
        self.root = root
        self.agent_id = agent_id
        self.mode = mode
        self.provider = provider
        # Read max_turns from config if not explicitly passed
        if max_turns is None:
            try:
                cfg = load_config(root)
                max_turns = cfg.tui.max_tool_rounds
                defaults = TUIConfig()
                # Backward-compatible UX: some users tune only session_max_turns and
                # expect turn budget to follow. If max_tool_rounds is still default,
                # honor the explicit session_max_turns override.
                if (
                    cfg.tui.max_tool_rounds == defaults.max_tool_rounds
                    and cfg.tui.session_max_turns != defaults.session_max_turns
                ):
                    max_turns = cfg.tui.session_max_turns
            except Exception:
                max_turns = MAX_CONVERSATION_TURNS
        self.max_turns = max_turns
        self.todo_manager = todo_manager or TodoManager()
        self.skill_loader = skill_loader or SkillLoader(root)
        self.messages: list[Message] = []
        self.recent_files: list[str] = []
        self.branch = self._current_branch()
        self.total_turns: int = 0
        self.total_usage: dict[str, Any] = {}
        self._persisted_up_to: int = 0  # index of last persisted message
        self._last_run_id: str = ""
        self._cancel_event: threading.Event = threading.Event()

    def send(
        self,
        user_text: str,
        on_chunk: Callable[[str], None] | None = None,
        on_thinking: Callable[[str], None] | None = None,
        on_tool_use: Callable[[str, dict[str, Any]], None] | None = None,
        on_tool_result: Callable[[str, dict[str, Any], str], None] | None = None,
        on_ask_user: Callable[[str, list[str]], str | None] | None = None,
        fixture_path: str | None = None,
    ) -> ConversationTurnResult:
        """Append user input, execute one turn, and persist session history.

        Messages are persisted incrementally (Claude Code style): each assistant
        response and tool result is appended to the JSONL session file as soon
        as it arrives, so work is never lost even if the process crashes.
        """
        # Reset cancel flag for new turn
        self._cancel_event.clear()

        user_msg = Message(role="user", content=user_text)
        self.messages.append(user_msg)

        # Persist user message immediately
        run_id = f"{self.agent_id}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        self._last_run_id = run_id
        append_message(self.root, self.branch, user_msg, run_id=run_id)
        self._persisted_up_to = len(self.messages)

        # Incremental persist callback -- saves each message to disk as it arrives
        def _persist_message(msg: Message) -> None:
            append_message(self.root, self.branch, msg, run_id=self._last_run_id)
            # Track that messages list has grown and is persisted
            self._persisted_up_to = len(self.messages)

        narrator_agent_id = get_narrator_agent_id(self.root)
        router_execution_mode = get_router_execution_mode(self.root)
        # M12-T4/T5: Active-agent lock path (narrator only).
        # If a specialist is already active, route the player's message directly
        # to that specialist unless the player explicitly requests to leave.
        if self.mode in {"build", "play"} and self.agent_id == narrator_agent_id and router_execution_mode == "fast":
            data_dir_name = get_data_dir_name(self.root)
            startup_entry_agent = get_startup_entry_agent(self.root)
            startup_router_type = get_startup_router_type(self.root)
            if startup_entry_agent and _is_initial_game_turn(self.root, data_dir_name):
                active_agent = startup_entry_agent
                if startup_router_type in {None, "sticky"}:
                    try:
                        write_active_agent(
                            self.root,
                            startup_entry_agent,
                            reason="startup entry agent from game-start.json",
                            exit_condition="router updates active-agent state after the first routed turn",
                            updated_by=narrator_agent_id,
                        )
                    except Exception:
                        logger.debug("Failed to seed startup active-agent state (non-fatal)", exc_info=True)
            else:
                active_agent = get_active_agent_id(self.root)
            if active_agent != narrator_agent_id:
                if _should_release_active_agent_lock(
                    self.root,
                    data_dir_name,
                    user_text,
                    active_agent,
                    narrator_agent_id=narrator_agent_id,
                ):
                    clear_active_agent(self.root, updated_by=narrator_agent_id)
                else:
                    task_prompt = (
                        "Handle this player request within your domain. "
                        f"Update game state as needed and return player-facing narration. Do NOT edit `{data_dir_name}/meta/active-agent.json`; "
                        "routing state is managed by the router.\n\n"
                        f"Player request: {user_text}"
                    )
                    task_args = {"agent_id": active_agent, "prompt": task_prompt}
                    if on_tool_use:
                        on_tool_use("task", task_args)
                    task_result = _dispatch_sub_agent(
                        task_data=task_args,
                        root=self.root,
                        mode=self.mode,
                        max_turns=self.max_turns,
                        caller_agent_id=self.agent_id,
                        on_chunk=on_chunk,
                        on_thinking=on_thinking,
                        on_tool_use=on_tool_use,
                        on_tool_result=on_tool_result,
                        on_ask_user=on_ask_user,
                        current_depth=0,
                        max_depth=2,
                        cancel_event=self._cancel_event,
                        on_message_persist=_persist_message,
                    )
                    if on_tool_result:
                        on_tool_result("task", task_args, task_result)
                    try:
                        payload = json.loads(task_result)
                    except Exception:
                        payload = {"status": "error", "error": f"Invalid task result: {task_result}"}
                    status = str(payload.get("status", "")).strip().lower()
                    data = payload.get("data")
                    if not isinstance(data, dict):
                        data = {}
                    usage_data = data.get("usage")
                    if not isinstance(usage_data, dict):
                        usage_data = {}
                    assistant_text = str(data.get("assistant_text") or "")
                    handoff_to = str(data.get("handoff_to") or "").strip().lower() or None
                    if status == "success":
                        if handoff_to == narrator_agent_id:
                            if assistant_text:
                                assistant_msg = Message(role="assistant", content=assistant_text, name=active_agent)
                                self.messages.append(assistant_msg)
                                _persist_message(assistant_msg)
                            rerouted = run_conversation_turn(
                                root=self.root,
                                agent_id=self.agent_id,
                                messages=self.messages,
                                mode=self.mode,
                                provider=self.provider,
                                fixture_path=fixture_path,
                                max_turns=self.max_turns,
                                on_chunk=on_chunk,
                                on_thinking=on_thinking,
                                on_tool_use=on_tool_use,
                                on_tool_result=on_tool_result,
                                on_ask_user=on_ask_user,
                                todo_manager=self.todo_manager,
                                skill_loader=self.skill_loader,
                                cancel_event=self._cancel_event,
                                on_message_persist=_persist_message,
                                run_id=run_id,
                            )
                            if assistant_text:
                                rerouted.assistant_message = (
                                    f"{assistant_text}\n\n{rerouted.assistant_message}"
                                    if rerouted.assistant_message
                                    else assistant_text
                                )
                            return self._finalize_send_result(rerouted)
                        if assistant_text:
                            assistant_msg = Message(role="assistant", content=assistant_text, name=active_agent)
                            self.messages.append(assistant_msg)
                            _persist_message(assistant_msg)
                        routed = ConversationTurnResult(
                            success=True,
                            run_id=str(data.get("run_id") or self._last_run_id),
                            assistant_message=assistant_text,
                            assistant_speaker=active_agent,
                            route_decision=str(data.get("route_decision") or "active_agent_lock_direct_route").strip() or None,
                            active_agent=str(data.get("active_agent") or active_agent).strip() or None,
                            delegated_to=str(data.get("delegated_to") or active_agent).strip() or None,
                            files_modified=[p for p in data.get("files_modified", []) if isinstance(p, str)],
                            tool_calls_made=[f"task:{active_agent}"],
                            turns_used=int(data.get("turns_used") or 1),
                            todo_snapshot=self.todo_manager.snapshot(),
                            usage=usage_data,
                            handoff_to=handoff_to,
                        )
                        return self._finalize_send_result(routed)
                    if status == "cancelled":
                        cancelled = ConversationTurnResult(
                            success=True,
                            run_id=str(data.get("run_id") or self._last_run_id),
                            assistant_message=assistant_text,
                            assistant_speaker=active_agent,
                            route_decision=str(data.get("route_decision") or "active_agent_lock_direct_route").strip() or None,
                            active_agent=str(data.get("active_agent") or active_agent).strip() or None,
                            delegated_to=str(data.get("delegated_to") or active_agent).strip() or None,
                            files_modified=[p for p in data.get("files_modified", []) if isinstance(p, str)],
                            tool_calls_made=[f"task:{active_agent}"],
                            turns_used=int(data.get("turns_used") or 1),
                            todo_snapshot=self.todo_manager.snapshot(),
                            usage=usage_data,
                            cancelled=True,
                            handoff_to=handoff_to,
                        )
                        return self._finalize_send_result(cancelled)
                    failed = ConversationTurnResult(
                        success=False,
                        run_id=str(data.get("run_id") or self._last_run_id),
                        assistant_message=assistant_text,
                        assistant_speaker=active_agent,
                        route_decision=str(data.get("route_decision") or "active_agent_lock_direct_route").strip() or None,
                        active_agent=str(data.get("active_agent") or active_agent).strip() or None,
                        delegated_to=str(data.get("delegated_to") or active_agent).strip() or None,
                        files_modified=[p for p in data.get("files_modified", []) if isinstance(p, str)],
                        tool_calls_made=[f"task:{active_agent}"],
                        turns_used=int(data.get("turns_used") or 1),
                        todo_snapshot=self.todo_manager.snapshot(),
                        usage=usage_data,
                        error=str(payload.get("error") or f"Sub-agent '{active_agent}' failed"),
                        handoff_to=handoff_to,
                    )
                    return self._finalize_send_result(failed)

        result = run_conversation_turn(
            root=self.root,
            agent_id=self.agent_id,
            messages=self.messages,
            mode=self.mode,
            provider=self.provider,
            fixture_path=fixture_path,
            max_turns=self.max_turns,
            on_chunk=on_chunk,
            on_thinking=on_thinking,
            on_tool_use=on_tool_use,
            on_tool_result=on_tool_result,
            on_ask_user=on_ask_user,
            todo_manager=self.todo_manager,
            skill_loader=self.skill_loader,
            cancel_event=self._cancel_event,
            on_message_persist=_persist_message,
            run_id=run_id,
        )
        return self._finalize_send_result(result)

    def _finalize_send_result(self, result: ConversationTurnResult) -> ConversationTurnResult:
        self._last_run_id = result.run_id or self._last_run_id
        # Flush any remaining unpersisted messages (safety net)
        self.flush()
        truncate_session(self.root, self.branch, max_turns=load_config(self.root).tui.session_max_turns)

        self.total_turns += result.turns_used
        _merge_usage(self.total_usage, result.usage)

        for path in result.files_modified:
            if path not in self.recent_files:
                self.recent_files.append(path)
        self.recent_files = self.recent_files[-20:]
        return result

    def flush(self) -> None:
        """Persist any unsaved messages to the session file.

        Safe to call at any time (e.g. on Ctrl+Q) -- only writes messages
        that haven't been persisted yet, avoiding duplicates.
        """
        if self._persisted_up_to >= len(self.messages):
            return
        run_id = self._last_run_id or "unsaved"
        for message in self.messages[self._persisted_up_to:]:
            append_message(self.root, self.branch, message, run_id=run_id)
        self._persisted_up_to = len(self.messages)

    def set_mode(self, mode: ConversationMode) -> None:
        if mode not in {"build", "sandbox", "play"}:
            raise ValueError(f"Unsupported mode: {mode}")
        self.mode = mode

    def cancel(self) -> None:
        """Signal the running conversation turn to stop after the current step."""
        self._cancel_event.set()

    @property
    def is_cancelled(self) -> bool:
        """Whether a cancellation has been requested."""
        return self._cancel_event.is_set()

    def clear(self) -> None:
        self.messages = []
        self.recent_files = []
        self._persisted_up_to = 0
        self._last_run_id = ""
        self._cancel_event.clear()
        self.todo_manager.update([])
        clear_session(self.root, self.branch)

    def compact(self, keep_recent: int = 10) -> int:
        """Compact conversation by summarizing old messages and keeping recent ones.

        Follows the Claude Code pattern: instead of silently dropping messages,
        creates a structured summary of what happened so the LLM retains context.

        Returns the number of messages removed.
        """
        if len(self.messages) <= keep_recent + 1:
            return 0
        system = self.messages[0] if self.messages and self.messages[0].role == "system" else None
        # Messages to drop (between system prompt and the kept tail)
        start = 1 if system else 0
        end = len(self.messages) - keep_recent
        dropped = self.messages[start:end]
        removed_count = len(dropped)
        if removed_count == 0:
            return 0

        summary = _build_compact_summary(dropped, self.recent_files, self.todo_manager)

        recent = self.messages[end:]
        compacted: list[Message] = []
        if system:
            compacted.append(system)
        compacted.append(Message(role="user", content=summary))
        compacted.append(
            Message(
                role="assistant",
                content="Understood. I have the summary of our previous conversation and will continue from here.",
            )
        )
        compacted.extend(recent)
        self.messages = compacted
        return removed_count

    def resume(self) -> int:
        """Load messages from persisted branch session."""
        self.branch = self._current_branch()
        self.messages = read_session_messages(self.root, self.branch)
        # Rebuild TodoWrite state from persisted tool outputs so resumed sessions
        # keep consistent todo snapshots in following turns.
        self.todo_manager.update([])
        for message in self.messages:
            if message.role != "tool" or message.name != "TodoWrite":
                continue
            content = message.content or ""
            if not isinstance(content, str) or not content:
                continue
            try:
                payload = json.loads(content)
            except Exception:
                continue
            if not isinstance(payload, dict):
                continue
            data = payload.get("data")
            if not isinstance(data, dict):
                continue
            items = data.get("items")
            if not isinstance(items, list):
                continue
            try:
                self.todo_manager.update(items)
            except ValueError:
                continue
        # Resumed messages are already on disk — mark them as persisted.
        self._persisted_up_to = len(self.messages)
        return len(self.messages)

    def get_messages(self) -> list[Message]:
        """Return current message list (for TUI restore)."""
        return self.messages

    def _current_branch(self) -> str:
        manifest_path = get_manifest_path(self.root)
        if not manifest_path.exists():
            return "main"
        try:
            manifest = Manifest(**json.loads(manifest_path.read_text(encoding="utf-8")))
            return manifest.current_branch
        except Exception:
            return "main"


def _build_compact_summary(
    dropped: list[Message],
    recent_files: list[str],
    todo_manager: TodoManager,
) -> str:
    """Build a structured summary of compacted conversation messages.

    Instead of just "[Previous conversation compacted]", we extract meaningful
    context so the LLM knows what happened and can continue coherently.
    """
    parts = ["[System: Previous conversation was compacted. Summary follows.]", ""]

    # Extract user requests
    user_messages = [m.content for m in dropped if m.role == "user" and m.content]
    if user_messages:
        parts.append("## User Requests")
        for msg in user_messages[-5:]:  # Keep last 5 user messages
            truncated = msg[:200] + "..." if len(msg) > 200 else msg
            parts.append(f"- {truncated}")
        parts.append("")

    # Extract tool calls made
    tool_names: list[str] = []
    for m in dropped:
        if m.role == "assistant" and m.tool_calls:
            for tc in m.tool_calls:
                tool_names.append(tc.name)
    if tool_names:
        # Deduplicate while preserving order, show counts
        seen: dict[str, int] = {}
        for name in tool_names:
            seen[name] = seen.get(name, 0) + 1
        summary_items = [f"{name} x{count}" if count > 1 else name for name, count in seen.items()]
        parts.append(f"## Tools Used: {', '.join(summary_items)}")
        parts.append("")

    # Files modified
    if recent_files:
        parts.append(f"## Files Modified: {', '.join(recent_files[-10:])}")
        parts.append("")

    # Current todo state
    todo_text = todo_manager.render()
    if todo_text != "(no todos)":
        parts.append(f"## Current Todo State\n{todo_text}")
        parts.append("")

    return "\n".join(parts)


def _chat_stream(
    adapter: Any,
    messages: list[Message],
    tools: list[dict],
    on_chunk: Callable[[str], None] | None,
    on_thinking: Callable[[str], None] | None = None,
    cancel_event: threading.Event | None = None,
) -> LLMTurnResult:
    """Collect streaming chunks into a standard turn result."""
    content = ""
    tool_calls = None
    finished = False
    usage: dict[str, Any] = {}
    error = None
    retryable = False
    try:
        for chunk in adapter.chat_stream(messages, tools=tools):
            if cancel_event is not None and cancel_event.is_set():
                break
            if chunk.delta:
                content += chunk.delta
                if on_chunk:
                    on_chunk(chunk.delta)
            if chunk.thinking and on_thinking:
                on_thinking(chunk.thinking)
            if chunk.tool_call_starts and on_chunk:
                names = ", ".join(chunk.tool_call_starts)
                on_chunk(f"\n[calling {names}...]\n")
            if chunk.tool_calls:
                tool_calls = chunk.tool_calls
            if chunk.usage:
                usage = chunk.usage
            if chunk.finished:
                finished = True
            if chunk.error:
                error = chunk.error
                retryable = bool(getattr(chunk, "retryable", False)) or _looks_retryable_error_text(chunk.error)
                break
    except Exception as exc:
        return LLMTurnResult(error=str(exc), finished=True, retryable=_looks_retryable_error_text(str(exc)))

    message = Message(role="assistant", content=content or None, tool_calls=tool_calls)
    return LLMTurnResult(
        message=message,
        tool_calls=tool_calls,
        finished=finished,
        usage=usage,
        error=error,
        retryable=retryable,
    )


def _looks_retryable_error_text(error_text: str | None) -> bool:
    """Best-effort classifier for transient errors from adapters/chunks."""
    if not error_text:
        return False
    text = str(error_text).lower()
    markers = (
        "network connection lost",
        "connection reset",
        "connection aborted",
        "connection refused",
        "connection error",
        "api connection error",
        "timed out",
        "timeout",
        "temporarily unavailable",
        "rate limit",
        "429",
        "503",
        "502",
        "500",
        "retryable",
    )
    return any(marker in text for marker in markers)


def _preview_for_log(value: Any, max_len: int = 260) -> str:
    """Render compact one-line preview for debug logs."""
    try:
        if isinstance(value, str):
            text = value
        else:
            text = json.dumps(value, ensure_ascii=False)
    except Exception:
        text = str(value)
    text = text.replace("\n", "\\n")
    if len(text) > max_len:
        return f"{text[:max_len]}...(+{len(text) - max_len} chars)"
    return text


def _json_dumps(value: Any) -> str:
    """Serialize tool/session payloads with readable UTF-8 characters."""
    return json.dumps(value, ensure_ascii=False, default=str)


def _truncate_for_prompt(text: str, max_chars: int) -> str:
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    keep = max(0, max_chars - 48)
    return f"{text[:keep]}\n... [truncated {len(text) - keep} chars]"


def _load_indexed_entities_for_context_pack(root: Path) -> dict[str, EntityRecord]:
    """Best-effort manifest entity index refresh for prompt-time context packing."""
    try:
        manifest, _, warnings = refresh_manifest_index(root, full_rebuild=False)
    except Exception as exc:
        logger.debug("context_pack: failed to refresh manifest index: %s", exc)
        return {}
    if warnings:
        logger.debug("context_pack: index refresh warnings=%d", len(warnings))
    entities = manifest.entities
    return entities if isinstance(entities, dict) else {}


def _entities_by_id(entities: dict[str, EntityRecord]) -> dict[str, EntityRecord]:
    by_id: dict[str, EntityRecord] = {}
    for record in entities.values():
        if not isinstance(record, EntityRecord):
            continue
        entity_id = str(record.id or "").strip()
        if not entity_id or entity_id in by_id:
            continue
        by_id[entity_id] = record
    return by_id


def _extract_prompt_entity_ids(task_prompt: str, by_id: dict[str, EntityRecord]) -> list[str]:
    ids: list[str] = []
    seen: set[str] = set()
    for match in _ENTITY_ID_TOKEN_PATTERN.finditer(str(task_prompt or "").lower()):
        token = match.group(0)
        if token in by_id and token not in seen:
            ids.append(token)
            seen.add(token)
    return ids


def _read_player_location_id(root: Path, by_id: dict[str, EntityRecord]) -> str:
    contract = load_runtime_contract(root)
    source_entity_id = contract.routing.location_source.entity_id
    source_field = contract.routing.location_source.field
    source_record = by_id.get(source_entity_id)
    if not source_record:
        return ""
    try:
        payload = json.loads((root / source_record.path).read_text(encoding="utf-8"))
    except Exception:
        return ""
    location = payload.get(source_field) if isinstance(payload, dict) else None
    if isinstance(location, str):
        return location.strip()
    return ""


def _preferred_kinds_for_agent(
    root: Path,
    target_agent_id: str,
    by_id: dict[str, EntityRecord],
) -> tuple[str, ...]:
    preferred: list[str] = []
    for kind in sorted(_get_agent_sticky_domain_kinds(root, target_agent_id)):
        if kind not in preferred:
            preferred.append(kind)

    all_kinds = sorted(
        {str(record.kind or "").strip() for record in by_id.values() if str(record.kind or "").strip()},
        key=lambda kind: ({"meta": 0, "player": 1}.get(kind, 10), kind),
    )
    for kind in all_kinds:
        if kind not in preferred:
            preferred.append(kind)
    return tuple(preferred)


def _select_context_pack_entity_ids(
    *,
    root: Path,
    target_agent_id: str,
    task_prompt: str,
    by_id: dict[str, EntityRecord],
) -> list[str]:
    contract = load_runtime_contract(root)
    max_entities = max(1, contract.context_pack.max_entities)
    selected: list[str] = []

    def _add(entity_id: str) -> None:
        key = str(entity_id or "").strip()
        if not key or key not in by_id or key in selected:
            return
        selected.append(key)

    for entity_id in _extract_prompt_entity_ids(task_prompt, by_id):
        _add(entity_id)
        if len(selected) >= max_entities:
            return selected

    for seed in contract.context_pack.seed_entity_ids:
        _add(seed)
        if len(selected) >= max_entities:
            return selected

    location_id = _read_player_location_id(root, by_id)
    if location_id:
        _add(location_id)
        if len(selected) >= max_entities:
            return selected

    preferred_kinds = _preferred_kinds_for_agent(root, target_agent_id, by_id)
    for kind in preferred_kinds:
        for record in sorted(by_id.values(), key=lambda item: item.id):
            if record.kind != kind:
                continue
            _add(record.id)
            if len(selected) >= max_entities:
                return selected

    return selected


def _build_registry_ids(
    *,
    root: Path,
    selected_ids: list[str],
    by_id: dict[str, EntityRecord],
    target_agent_id: str,
) -> list[str]:
    registry_ids: list[str] = []
    seen: set[str] = set()

    def _add(entity_id: str) -> None:
        key = str(entity_id or "").strip()
        if not key or key in seen or key not in by_id:
            return
        seen.add(key)
        registry_ids.append(key)

    for entity_id in selected_ids:
        _add(entity_id)
        if len(registry_ids) >= CONTEXT_PACK_REGISTRY_MAX_ITEMS:
            return registry_ids

    preferred_kinds = set(_preferred_kinds_for_agent(root, target_agent_id, by_id))
    for record in sorted(by_id.values(), key=lambda item: item.id):
        if record.kind not in preferred_kinds:
            continue
        _add(record.id)
        if len(registry_ids) >= CONTEXT_PACK_REGISTRY_MAX_ITEMS:
            return registry_ids
    return registry_ids


def _build_task_context_pack(root: Path, target_agent_id: str, task_prompt: str) -> str:
    entities = _load_indexed_entities_for_context_pack(root)
    if not entities:
        return ""
    by_id = _entities_by_id(entities)
    if not by_id:
        return ""

    selected_ids = _select_context_pack_entity_ids(
        root=root,
        target_agent_id=target_agent_id,
        task_prompt=task_prompt,
        by_id=by_id,
    )
    if not selected_ids:
        return ""

    registry_ids = _build_registry_ids(
        root=root,
        selected_ids=selected_ids,
        by_id=by_id,
        target_agent_id=target_agent_id,
    )
    registry_lines = [
        f"- {entity_id} -> {by_id[entity_id].path}"
        for entity_id in registry_ids
    ]

    snapshots: list[str] = []
    for entity_id in selected_ids:
        record = by_id[entity_id]
        abs_path = root / record.path
        try:
            raw = abs_path.read_text(encoding="utf-8")
        except Exception:
            raw = f'{{"error":"Failed to read {record.path}"}}'
        excerpt = _truncate_for_prompt(raw, CONTEXT_PACK_ENTITY_MAX_CHARS)
        snapshots.append(
            "\n".join(
                [
                    f"### {entity_id} ({record.kind})",
                    f"path: {record.path}",
                    excerpt,
                ]
            )
        )

    section = "\n".join(
        [
            "## Context Pack (preloaded canonical paths + entity snapshots)",
            "Use these canonical paths directly before any broad discovery calls.",
            "### Entity Path Registry",
            *registry_lines,
            "",
            "### Preloaded Entity Snapshots",
            *snapshots,
        ]
    )
    return _truncate_for_prompt(section, CONTEXT_PACK_MAX_CHARS)


def _is_loop_guard_readonly_tool(tool_name: str) -> bool:
    return str(tool_name or "").strip() in READONLY_TOOL_LOOP_GUARD


def _tool_call_signature(tool_name: str, tool_args: dict[str, Any]) -> str:
    """Build a stable signature for repeated-tool loop detection."""
    try:
        args_json = json.dumps(tool_args or {}, ensure_ascii=False, default=str, sort_keys=True, separators=(",", ":"))
    except Exception:
        args_json = str(tool_args)
    return f"{str(tool_name or '').strip()}::{args_json}"


def _summarize_tool_result_for_log(tool_result: str) -> str:
    """Extract stable high-signal fields from tool result payload."""
    try:
        payload = json.loads(tool_result)
    except Exception:
        return f"non_json len={len(tool_result)} preview={_preview_for_log(tool_result)}"
    if not isinstance(payload, dict):
        return f"json_non_object type={type(payload).__name__} preview={_preview_for_log(payload)}"
    status = str(payload.get("status", ""))
    error = payload.get("error")
    data = payload.get("data")
    data_keys: list[str] = []
    path = None
    if isinstance(data, dict):
        data_keys = [str(k) for k in sorted(data.keys())]
        if isinstance(data.get("path"), str):
            path = data.get("path")
    parts = [f"status={status or '?'}"]
    if error:
        parts.append(f"error={_preview_for_log(error, 180)}")
    if path:
        parts.append(f"path={path}")
    if data_keys:
        parts.append(f"data_keys={data_keys}")
    return " ".join(parts)


def _tag_sub_agent_event(agent_id: str, payload: str) -> str:
    """Attach a lightweight sub-agent tag so UI can route nested stream events."""
    safe_agent = str(agent_id or "").strip()
    text = payload if isinstance(payload, str) else str(payload)
    if not safe_agent:
        return text
    return f"[[subagent:{safe_agent}]]{text}"


def _is_cancelled_tool_result(tool_result: str) -> bool:
    """Return True when a tool result payload explicitly reports cancellation."""
    try:
        payload = json.loads(tool_result)
    except Exception:
        return False
    if not isinstance(payload, dict):
        return False
    return str(payload.get("status", "")).strip().lower() == "cancelled"


def _parse_task_tool_result(tool_result: str) -> dict[str, Any] | None:
    """Parse task() tool result payload when it is valid JSON object."""
    try:
        payload = json.loads(tool_result)
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _is_sticky_task_success(tool_result: str) -> bool:
    payload = _parse_task_tool_result(tool_result)
    if not payload:
        return False
    if str(payload.get("status", "")).strip().lower() != "success":
        return False
    data = payload.get("data")
    if not isinstance(data, dict):
        return False
    return str(data.get("delegation_mode", "")).strip().lower() == "sticky"


def _is_missing_read_file_error(tool_name: str, tool_result: str) -> bool:
    """True when read_file result indicates a missing path."""
    if tool_name != "read_file":
        return False
    try:
        payload = json.loads(tool_result)
    except Exception:
        return False
    if not isinstance(payload, dict):
        return False
    if str(payload.get("status", "")).strip().lower() != "error":
        return False
    error_text = str(payload.get("error", "")).strip().lower()
    return error_text.startswith("file not found:")


def _load_agent_data(root: Path, agent_id: str) -> dict[str, Any] | None:
    """Load agent.json for the given agent id, returning None on errors."""
    agent_json = root / "agents" / agent_id / "agent.json"
    if not agent_json.exists():
        return None
    try:
        payload = json.loads(agent_json.read_text(encoding="utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _build_default_build_agent_data(root: Path, agent_id: str) -> dict[str, Any]:
    """Provide a safe default build-mode agent for init-only projects."""
    narrator_agent_id = get_narrator_agent_id(root)
    display_name = "Workspace Agent" if agent_id == narrator_agent_id else agent_id.replace("-", " ").title()
    return {
        "id": agent_id,
        "name": display_name,
        "description": (
            "Fallback build-mode agent for initialized projects without explicit agents. "
            "Behaves like a general workspace coding agent."
        ),
        "system_prompt": (
            "You are the default build-mode workspace agent. "
            "Work like Claude Code: inspect the repository, read before writing, "
            "edit carefully, and keep changes scoped to the user's request."
        ),
        "policy": {
            "role": "builder",
            "disallow_direct_game_tools": False,
        },
        "permissions": {
            "read_globs": ["**"],
            "deny_globs": [],
            "write_globs": ["**"],
            "direct_write_globs": ["**"],
        },
    }


def _build_default_orchestrator_agent_data(root: Path, agent_id: str) -> dict[str, Any]:
    """Provide a safe fallback orchestrator when projects define no router agent."""
    del root
    return {
        "id": agent_id,
        "name": "Default Orchestrator",
        "description": (
            "Fallback orchestrator for play/build flows when the project does not define "
            "a narrator/orchestrator agent."
        ),
        "system_prompt": (
            "You are the default orchestrator for a role-playing game world. "
            "You are always the player-facing speaker. Read the current game state, decide whether to "
            "use tools directly or delegate to a specialist via task(), and then produce the final player-visible narration. "
            "Use tools for deterministic mechanics and local state operations; use specialists for domain reasoning."
        ),
        "policy": {
            "role": "router",
            "disallow_direct_game_tools": False,
        },
        "permissions": {
            "read_globs": ["game/**", ".neonrp/manifest.json"],
            "deny_globs": [],
            "write_globs": ["game/**"],
            "direct_write_globs": ["game/**"],
        },
    }


def _load_agent_data_for_mode(root: Path, agent_id: str, mode: ConversationMode) -> dict[str, Any] | None:
    """Load agent.json, or synthesize a default build agent after plain init."""
    agent_dir = root / "agents" / agent_id
    agent_json = agent_dir / "agent.json"
    if agent_json.exists():
        try:
            payload = json.loads(agent_json.read_text(encoding="utf-8"))
        except Exception:
            return None
        return payload if isinstance(payload, dict) else None
    narrator_agent_id = get_narrator_agent_id(root)
    router_execution_mode = get_router_execution_mode(root)
    if mode == "build" and agent_id == narrator_agent_id and not agent_dir.exists():
        return _build_default_build_agent_data(root, agent_id)
    if agent_id == narrator_agent_id and router_execution_mode == "orchestrator" and not agent_dir.exists():
        return _build_default_orchestrator_agent_data(root, agent_id)
    return None


def _get_agent_policy(
    root: Path,
    agent_id: str,
    agent_data: dict[str, Any] | None = None,
    *,
    narrator_agent_id: str | None = None,
) -> dict[str, Any]:
    agent_data = agent_data if isinstance(agent_data, dict) else (_load_agent_data(root, agent_id) or {})
    narrator_agent_id = narrator_agent_id or load_runtime_contract(root).router.agent_id
    policy = agent_data.get("policy")
    role = ""
    disallow_direct_game_tools = None
    if isinstance(policy, dict):
        raw_role = policy.get("role")
        if isinstance(raw_role, str) and raw_role.strip():
            role = raw_role.strip().lower()
        raw_disallow = policy.get("disallow_direct_game_tools")
        if isinstance(raw_disallow, bool):
            disallow_direct_game_tools = raw_disallow

    if not role:
        role = "router" if agent_id == narrator_agent_id else "specialist"
    if disallow_direct_game_tools is None:
        disallow_direct_game_tools = role == "router"

    return {
        "role": role,
        "disallow_direct_game_tools": bool(disallow_direct_game_tools),
    }


def _load_agent_system_prompt_text(root: Path, agent_id: str, agent_data: dict[str, Any]) -> str:
    """Load agent-specific system instructions from file path or inline text.

    Priority:
    1) agents/<agent_id>/<system_prompt> when value looks like file name/path
    2) <project_root>/<system_prompt> fallback
    3) inline string value from agent.json
    """
    raw = agent_data.get("system_prompt")
    if not isinstance(raw, str):
        return ""
    candidate = raw.strip()
    if not candidate:
        return ""

    def _read_if_exists(path: Path) -> str:
        try:
            if path.exists() and path.is_file():
                return path.read_text(encoding="utf-8").strip()
        except Exception:
            return ""
        return ""

    agent_local = _read_if_exists(root / "agents" / agent_id / candidate)
    if agent_local:
        return agent_local

    project_relative = _read_if_exists(root / candidate)
    if project_relative:
        return project_relative

    looks_like_file_ref = _looks_like_prompt_file_reference(candidate)
    if looks_like_file_ref:
        logger.warning(
            "Agent '%s' system_prompt references missing file '%s'; continuing without agent-specific prompt",
            agent_id,
            candidate,
        )
        return ""

    return candidate


def _looks_like_prompt_file_reference(candidate: str) -> bool:
    """Heuristic: decide whether `system_prompt` looks like a file path."""
    if not isinstance(candidate, str):
        return False
    text = candidate.strip()
    if not text:
        return False
    if "\n" in text or "\r" in text:
        return False
    if len(text) > 240:
        return False
    has_sep = "/" in text or "\\" in text
    has_ws = bool(re.search(r"\s", text))
    lowered = text.lower()
    if lowered.endswith((".md", ".txt", ".prompt", ".rst")) and not has_ws:
        return True
    if has_sep and not has_ws:
        return True
    if "." in text and re.fullmatch(r"[A-Za-z0-9_.-]+", text):
        return True
    return False


def _normalize_delegation_mode(raw: object) -> str:
    text = str(raw or "").strip().lower().replace("_", "-")
    if text in {"oneshot", "one-shot"}:
        return "one-shot"
    if text == "sticky":
        return "sticky"
    return ""


def _get_agent_delegation_mode(root: Path, agent_id: str) -> str:
    """Resolve delegation mode from agent.json.

    Priority:
    1) explicit `delegation_mode` (`sticky` / `one-shot`)
    2) legacy `handoff_when` present -> sticky
    3) fallback -> one-shot
    """
    agent_data = _load_agent_data(root, agent_id)
    if not isinstance(agent_data, dict):
        return "one-shot"

    explicit = _normalize_delegation_mode(agent_data.get("delegation_mode"))
    if explicit:
        return explicit

    handoff_when = agent_data.get("handoff_when")
    if isinstance(handoff_when, dict) and handoff_when:
        return "sticky"
    return "one-shot"


def _get_agent_sticky_domain_kinds(root: Path, agent_id: str) -> set[str]:
    """Resolve allowed location kinds for sticky lock ownership.

    Source priority:
    1) agent.json `sticky_domain_kinds` (list[str])
    2) runtime contract `routing.domain_agent_map`
    """
    agent_data = _load_agent_data(root, agent_id) or {}
    raw = agent_data.get("sticky_domain_kinds")
    if isinstance(raw, list):
        parsed = {str(item).strip().lower() for item in raw if isinstance(item, str) and str(item).strip()}
        if parsed:
            return parsed
    contract = load_runtime_contract(root)
    return {
        domain
        for domain, mapped_agent in contract.routing.domain_agent_map.items()
        if str(mapped_agent or "").strip() == agent_id
    }


def _read_player_location_state(root: Path, data_dir_name: str) -> tuple[str, str]:
    """Best-effort current player location id + entity kind."""
    contract = load_runtime_contract(root)
    data_dir_name = contract.data_dir or data_dir_name
    source_entity_id = contract.routing.location_source.entity_id
    source_field = contract.routing.location_source.field
    location_id = ""
    entities = _load_indexed_entities_for_context_pack(root)
    by_id = _entities_by_id(entities) if entities else {}
    if by_id:
        source_record = by_id.get(source_entity_id)
        if isinstance(source_record, EntityRecord):
            try:
                payload = json.loads((root / source_record.path).read_text(encoding="utf-8"))
            except Exception:
                payload = {}
            if isinstance(payload, dict):
                raw_location = payload.get(source_field)
                if isinstance(raw_location, str):
                    location_id = raw_location.strip()
        if location_id:
            record = by_id.get(location_id)
            if isinstance(record, EntityRecord):
                return location_id, str(record.kind or "").strip().lower()

    if not location_id:
        data_root = root / data_dir_name
        if data_root.exists():
            for candidate_path in sorted(data_root.rglob(f"{source_entity_id}.json"), key=lambda path: path.as_posix()):
                try:
                    payload = json.loads(candidate_path.read_text(encoding="utf-8"))
                except Exception:
                    continue
                if not isinstance(payload, dict) or payload.get("id") != source_entity_id:
                    continue
                raw_location = payload.get(source_field)
                if isinstance(raw_location, str) and raw_location.strip():
                    location_id = raw_location.strip()
                    break

    if not location_id:
        return "", ""

    data_root = root / data_dir_name
    if data_root.exists():
        for candidate_path in sorted(data_root.rglob(f"{location_id}.json"), key=lambda path: path.as_posix()):
            try:
                payload = json.loads(candidate_path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if isinstance(payload, dict) and payload.get("id") == location_id:
                kind = str(payload.get("kind") or "").strip().lower()
                return location_id, kind
    return location_id, ""


def _should_release_active_agent_lock(
    root: Path,
    data_dir_name: str,
    user_text: str,
    active_agent: str,
    *,
    narrator_agent_id: str = NARRATOR_AGENT,
) -> bool:
    """Decide whether the current active-agent lock should be cleared.

    Release conditions:
    1) The locked agent no longer exists or has invalid config.
    2) The locked agent is configured as one-shot (no persistent control).
    3) Sticky agent domain no longer matches player's current location kind.
    """
    _ = user_text  # reserved for future policy usage
    if not isinstance(active_agent, str) or not active_agent.strip():
        return True
    if active_agent == narrator_agent_id:
        return False
    active_agent_id = active_agent.strip()
    if _load_agent_data(root, active_agent_id) is None:
        return True
    if _get_agent_delegation_mode(root, active_agent_id) == "one-shot":
        return True

    domain_kinds = _get_agent_sticky_domain_kinds(root, active_agent_id)
    if not domain_kinds:
        return False
    location_id, location_kind = _read_player_location_state(root, data_dir_name)
    if not location_kind:
        return False
    should_release = location_kind not in domain_kinds
    if should_release:
        logger.info(
            "Active agent '%s' released: player location '%s' kind='%s' outside sticky_domain_kinds=%s",
            active_agent_id,
            location_id or "?",
            location_kind,
            sorted(domain_kinds),
        )
    return should_release


def _iter_configured_agent_ids(root: Path, narrator_agent_id: str) -> list[str]:
    agents_root = root / "agents"
    if not agents_root.exists():
        return []
    router_aliases = get_router_agent_aliases(narrator_agent_id)
    ids: list[str] = []
    for child in sorted(agents_root.iterdir()):
        if not child.is_dir():
            continue
        agent_json = child / "agent.json"
        if not agent_json.exists():
            continue
        agent_id = child.name.strip()
        if not agent_id or agent_id in router_aliases:
            continue
        ids.append(agent_id)
    return ids


def _select_router_target_agent(
    root: Path,
    data_dir_name: str,
    narrator_agent_id: str,
) -> str | None:
    """Pick a specialist agent for narrator routing without narrator LLM narration."""
    contract = load_runtime_contract(root)
    location_id, location_kind = _read_player_location_state(root, data_dir_name)
    agent_ids = _iter_configured_agent_ids(root, narrator_agent_id)
    if not agent_ids:
        return None

    # 1) Exact domain mapping from runtime contract wins.
    if location_kind:
        mapped_agent = contract.routing.domain_agent_map.get(location_kind)
        if mapped_agent in agent_ids:
            return mapped_agent

    # 2) Fallback agent if it is a configured specialist.
    fallback_agent = str(contract.routing.fallback_agent or "").strip()
    if fallback_agent and fallback_agent != narrator_agent_id and fallback_agent in agent_ids:
        return fallback_agent

    # 3) Stable compatibility fallback: first configured specialist.
    if location_id:
        logger.warning(
            "Router fell back to first configured specialist for location '%s' (kind='%s'); runtime contract lacks a match",
            location_id,
            location_kind or "?",
        )
    return agent_ids[0]


def _build_router_task_prompt(
    data_dir_name: str,
    player_request: str,
    *,
    previous_agent_id: str = "",
    previous_assistant_text: str = "",
) -> str:
    routing_guard = f"Do NOT edit `{data_dir_name}/meta/active-agent.json`; routing state is managed by the router."
    if not previous_agent_id:
        return (
            "Handle this player request within your domain. "
            "Update game state as needed and return player-facing narration. "
            f"{routing_guard}\n\n"
            f"Player request: {player_request}"
        )

    handoff_summary = previous_assistant_text.strip()
    handoff_section = (
        f"Previous specialist handoff summary:\n{handoff_summary}\n\n"
        if handoff_summary
        else ""
    )
    return (
        "Continue this same player turn after a router handoff. "
        "Another specialist already handled the domain transition and released control to narrator. "
        "Read current state, continue seamlessly from there, and avoid repeating the handoff narration verbatim. "
        f"{routing_guard}\n\n"
        f"Original player request: {player_request}\n"
        f"Previous specialist: {previous_agent_id}\n\n"
        f"{handoff_section}"
        "Return player-facing narration for what happens next in your domain."
    )


def _is_game_path(path_value: object, data_dir_name: str) -> bool:
    if not isinstance(path_value, str):
        return False
    normalized = path_value.replace("\\", "/").lstrip("./")
    return normalized == data_dir_name or normalized.startswith(f"{data_dir_name}/")


def _should_block_narrator_tool_call(
    *,
    agent_id: str,
    tool_name: str,
    tool_args: dict[str, Any],
    data_dir_name: str,
    enforce_guardrail: bool,
    narrator_agent_id: str = NARRATOR_AGENT,
) -> bool:
    if not enforce_guardrail or agent_id != narrator_agent_id:
        return False
    if tool_name == "resolve_action":
        return True
    if tool_name in {"write_file", "edit_file", "delete_file"}:
        return _is_game_path(tool_args.get("path"), data_dir_name)
    return False


def _filter_tool_schemas_by_agent_config(
    tool_schemas: list[dict[str, Any]],
    agent_data: dict[str, Any],
) -> list[dict[str, Any]]:
    """Apply agent.json `tools` allowlist to runtime tool schemas.

    When `tools` is absent or empty, keep current behavior for backwards
    compatibility. When present, only listed tools are exposed.
    """
    allowlist = _get_agent_tool_allowlist(agent_data)
    if allowlist is None:
        return tool_schemas
    return [schema for schema in tool_schemas if schema.get("name") in allowlist]


def _get_agent_tool_allowlist(agent_data: dict[str, Any]) -> set[str] | None:
    configured_tools = agent_data.get("tools")
    if not isinstance(configured_tools, list):
        return None
    allowlist = {str(name).strip() for name in configured_tools if isinstance(name, str) and str(name).strip()}
    if not allowlist or "*" in allowlist:
        return None
    return allowlist


def _dispatch_sub_agent(
    task_data: dict[str, Any],
    root: Path,
    mode: ConversationMode,
    max_turns: int,
    caller_agent_id: str | None = None,
    on_chunk: Callable[[str], None] | None = None,
    on_thinking: Callable[[str], None] | None = None,
    on_tool_use: Callable[[str, dict[str, Any]], None] | None = None,
    on_tool_result: Callable[[str, dict[str, Any], str], None] | None = None,
    on_ask_user: Callable[[str, list[str]], str | None] | None = None,
    current_depth: int = 0,
    max_depth: int = 2,
    cancel_event: threading.Event | None = None,
    on_message_persist: Callable[[Message], None] | None = None,
) -> str:
    """Dispatch a sub-agent for the task tool and return a JSON result string."""
    target_agent_id = str(task_data.get("agent_id", "")).strip()
    prompt = str(task_data.get("prompt", "")).strip()
    caller = str(caller_agent_id or "").strip()
    data_dir_name = get_data_dir_name(root)
    narrator_agent_id = get_narrator_agent_id(root)
    router_execution_mode = get_router_execution_mode(root)

    if not target_agent_id:
        return _json_dumps({"status": "error", "error": "Missing required field: agent_id"})
    if not prompt:
        return _json_dumps({"status": "error", "error": "Missing required field: prompt"})
    if caller and caller == target_agent_id:
        logger.debug("sub_agent dispatch blocked_self_delegate: caller=%s target=%s", caller, target_agent_id)
        return _json_dumps(
            {
                "status": "error",
                "error": f"Agent '{caller}' cannot delegate to itself via task()",
                "data": {"agent_id": caller, "target_agent_id": target_agent_id},
            }
        )

    # Sub-agent delegation policy:
    # - Router/narrator can delegate to any agent.
    # - In fast mode, non-router agents can only delegate back to narrator.
    # - In orchestrator mode, depth-1 specialists may delegate one layer deeper.
    if (
        caller
        and caller != narrator_agent_id
        and target_agent_id != narrator_agent_id
        and (
            router_execution_mode != "orchestrator"
            or current_depth >= max_depth - 1
        )
    ):
        logger.debug(
            "sub_agent dispatch blocked_non_router_delegate: caller=%s target=%s narrator=%s",
            caller,
            target_agent_id,
            narrator_agent_id,
        )
        return _json_dumps(
            {
                "status": "error",
                "error": (
                    f"Agent '{caller}' can only delegate to narrator '{narrator_agent_id}' via task()"
                ),
                "data": {
                    "agent_id": caller,
                    "target_agent_id": target_agent_id,
                    "narrator_agent_id": narrator_agent_id,
                    "policy": "subagent_task_only_to_narrator",
                },
            }
        )

    target_agent_data = _load_agent_data(root, target_agent_id) or {}
    target_allowlist = _get_agent_tool_allowlist(target_agent_data)
    delegation_mode = _get_agent_delegation_mode(root, target_agent_id)
    sticky_ask_user_enabled = delegation_mode == "sticky" and on_ask_user is not None
    if (
        sticky_ask_user_enabled
        and target_allowlist is not None
        and "ask_user" not in target_allowlist
    ):
        return _json_dumps(
            {
                "status": "error",
                "error": (
                    f"Agent '{target_agent_id}' is sticky but cannot call ask_user. "
                    "Add 'ask_user' to agent.json tools."
                ),
                "data": {
                    "agent_id": target_agent_id,
                    "delegation_mode": delegation_mode,
                    "required_tool": "ask_user",
                    "configured_tools": sorted(target_allowlist),
                },
            }
        )

    if "max_task_turns" in target_agent_data:
        logger.debug(
            "sub_agent dispatch: agent-level max_task_turns is ignored; using session/config max_turns=%d",
            max_turns,
        )
    effective_max_turns = max_turns

    logger.debug(
        "sub_agent dispatch start: caller=%s target=%s mode=%s depth=%d/%d max_turns=%d effective_max_turns=%d prompt=%s",
        caller or "?",
        target_agent_id or "?",
        mode,
        current_depth,
        max_depth,
        max_turns,
        effective_max_turns,
        _preview_for_log(prompt, 240),
    )
    # Persist active-agent transitions only for top-level build/play routing.
    track_active_agent_state = mode in {"build", "play"} and current_depth == 0 and router_execution_mode == "fast"
    if track_active_agent_state:
        try:
            write_active_agent(
                root,
                target_agent_id,
                reason=(
                    f"dispatch enter: delegated from '{caller or narrator_agent_id}' "
                    f"to '{target_agent_id}'"
                ),
                exit_condition=(
                    "agent updates active-agent state when it leaves its domain"
                    if delegation_mode == "sticky"
                    else "auto-release after one-shot task completion"
                ),
                updated_by=caller or narrator_agent_id,
            )
            logger.debug(
                "active-agent enter: caller=%s target=%s delegation_mode=%s",
                caller or narrator_agent_id,
                target_agent_id,
                delegation_mode,
            )
        except Exception:
            logger.debug("Failed to write active-agent enter state (non-fatal)", exc_info=True)

    def _release_active_agent_lock(outcome: str, *, force: bool = False) -> None:
        if not track_active_agent_state:
            return
        if delegation_mode == "sticky" and not force:
            return
        try:
            write_active_agent(
                root,
                narrator_agent_id,
                reason=f"dispatch exit: {outcome} from '{target_agent_id}'",
                exit_condition="",
                updated_by=narrator_agent_id,
            )
            logger.debug(
                "active-agent exit: target=%s outcome=%s force=%s -> %s",
                target_agent_id,
                outcome,
                force,
                narrator_agent_id,
            )
        except Exception:
            logger.debug("Failed to write active-agent exit state (non-fatal)", exc_info=True)

    try:
        if mode == "sandbox":
            # Sandbox: use agentic workflow with proposals, apply on success
            sub_result = run_agent_agentic(
                root=root,
                agent_id=target_agent_id,
                query=prompt,
                do_apply=True,
                max_turns=effective_max_turns,
                on_ask_user=on_ask_user,
                current_depth=current_depth + 1,
                max_depth=max_depth,
            )
            if not sub_result.success:
                _release_active_agent_lock("sandbox_error", force=True)
                logger.debug(
                    "sub_agent sandbox result: target=%s success=%s turns=%s error=%s",
                    target_agent_id,
                    sub_result.success,
                    sub_result.turns,
                    _preview_for_log(sub_result.error or "", 180),
                )
                return _json_dumps({
                    "status": "error",
                    "error": sub_result.error or f"Sub-agent '{target_agent_id}' failed",
                    "data": {
                        "run_id": sub_result.run_id,
                        "agent_id": target_agent_id,
                        "success": sub_result.success,
                        "turns": sub_result.turns,
                    },
                })
            logger.debug(
                "sub_agent sandbox result: target=%s success=%s turns=%s",
                target_agent_id,
                sub_result.success,
                sub_result.turns,
            )
            _release_active_agent_lock("sandbox_success")
            return _json_dumps({
                "status": "success",
                "data": {
                    "run_id": sub_result.run_id,
                    "agent_id": target_agent_id,
                    "success": sub_result.success,
                    "error": sub_result.error,
                    "turns": sub_result.turns,
                },
            })
        else:
            # Build/play: run as nested conversation — sub-agent can directly
            # read/write files just like Claude Code.
            context_pack = _build_task_context_pack(root, target_agent_id, prompt)
            context_pack_section = f"{context_pack}\n\n" if context_pack else ""
            allow_subagent_ask_user = sticky_ask_user_enabled
            logger.debug(
                "sub_agent contract: target=%s delegation_mode=%s ask_user_enabled=%s context_pack=%s",
                target_agent_id,
                delegation_mode,
                allow_subagent_ask_user,
                bool(context_pack),
            )
            # Differentiate contract by delegation_mode:
            # - sticky agents may remain active across turns
            # - one-shot agents complete a single task and return
            common_rules = (
                "- Stay within your own domain defined in agent.json.\n"
                "- If the action crosses into another domain, stop at boundary handling and return a handoff suggestion.\n"
                "- Do NOT guess file paths from entity IDs.\n"
                "- If a path is uncertain, use find/list_entities/glob to confirm before read_file.\n"
                "- If read_file returns File not found, do not repeat path variants; move on with confirmed data.\n"
                "- Prefer canonical reads/edits over exploratory search.\n"
            )
            if delegation_mode == "sticky":
                ask_user_rule = (
                    "- For meaningful player choices, call ask_user and wait for the player's answer.\n"
                    if allow_subagent_ask_user
                    else "- ask_user callback is unavailable in this run; present explicit options in response text instead.\n"
                )
                wrapped_prompt = (
                    "Sub-agent execution contract (sticky mode):\n"
                    "- You are the active domain specialist. Handle the player's request interactively.\n"
                    "- You will remain active until the player leaves your domain.\n"
                    f"{ask_user_rule}"
                    "- Information-first rule: when the player asks to clarify details (e.g., '先问清楚', '任务细节', '具体怎么做'),\n"
                    "  you MUST provide concrete details first (objective, location, risks, completion criteria, rewards),\n"
                    "  then ask follow-up choices only after the details are presented.\n"
                    "- ask_user pacing rule: do NOT issue back-to-back ask_user calls without substantial new narrative/state info between them.\n"
                    "  Do not use ask_user to merely re-confirm or paraphrase the player's previous answer.\n"
                    "- Choice capture rule: when you present 2+ concrete player options, call ask_user to capture the choice instead of ending with a plain-text question.\n"
                    "- End-of-turn interaction rule: if you are staying in-domain (no handoff), end by calling ask_user with 2-4 concrete options.\n"
                    "  Do NOT end the turn with only a plain-text question.\n"
                    "- Hard completion rule (sticky): each turn MUST end with exactly one of:\n"
                    "  (A) ask_user(...) when you are still in your domain, OR\n"
                    "  (B) handoff_to_router(reason) when domain change is confirmed.\n"
                    "- If your draft reply ends with plain text choices but no ask_user/handoff tool call, it is INVALID.\n"
                    "  Stop and issue the required tool call instead.\n"
                    f"{common_rules}"
                    "- Exit authority: when the player explicitly leaves your domain, or your applied state update moves the player outside your domain,\n"
                    "  call handoff_to_router(reason) in this turn to release control back to narrator.\n"
                    "- Sticky handoff validity: do NOT call handoff_to_router just because you finished one reply.\n"
                    "  Handoff is valid only after domain change is confirmed (e.g., player location moved outside your domain this turn).\n"
                    "- After calling handoff_to_router, do NOT call ask_user again in this turn.\n"
                    f"- Keep tool usage compact and finish within about {effective_max_turns} turns.\n"
                    "- Target <= 4 tool calls total; only exceed when correctness strictly requires it.\n"
                    "- Keep narration concise and immersive, then offer 2-3 concrete next actions.\n\n"
                    f"{context_pack_section}"
                    f"{prompt}"
                )
            else:
                wrapped_prompt = (
                    "Sub-agent execution contract (one-shot mode):\n"
                    "- Complete this as a single delegated task response.\n"
                    "- Do NOT call ask_user; provide options in your final response text instead.\n"
                    f"{common_rules}"
                    f"- Keep tool usage compact and finish within about {effective_max_turns} turns.\n"
                    "- Target <= 4 tool calls total; only exceed when correctness strictly requires it.\n"
                    "- Keep final narration concise, then provide 2-3 actionable options.\n\n"
                    f"{context_pack_section}"
                    f"{prompt}"
                )
            sub_messages: list[Message] = [Message(role="user", content=wrapped_prompt)]
            nested_on_ask_user = on_ask_user if allow_subagent_ask_user else None
            nested_disabled_tools = None if allow_subagent_ask_user else {"ask_user"}

            # Forward nested callbacks with sub-agent tags so callers can
            # render real-time details under the correct speaker identity.
            def _forward_chunk(chunk: str) -> None:
                if on_chunk:
                    on_chunk(_tag_sub_agent_event(target_agent_id, chunk))

            def _forward_thinking(thinking: str) -> None:
                if on_thinking:
                    on_thinking(_tag_sub_agent_event(target_agent_id, thinking))

            def _forward_tool_use(tool_name: str, tool_args: dict[str, Any]) -> None:
                if on_tool_use:
                    on_tool_use(_tag_sub_agent_event(target_agent_id, tool_name), tool_args)

            def _forward_tool_result(tool_name: str, tool_args: dict[str, Any], result: str) -> None:
                if on_tool_result:
                    on_tool_result(_tag_sub_agent_event(target_agent_id, tool_name), tool_args, result)

            def _persist_nested_transcript(message: Message) -> None:
                """Persist resumable sub-agent transcript into the parent session.

                Only persist user-visible nested transcript elements:
                - assistant messages that carry tool calls (ask_user prompt/options live here)
                - tool results that resolve those calls

                Plain assistant narration is still persisted by the parent task/task-result
                flow after successful completion, which avoids duplicate restored replies.
                """
                if on_message_persist is None:
                    return
                if message.role == "assistant":
                    if not getattr(message, "tool_calls", None):
                        return
                    nested_message = Message(
                        role="assistant",
                        content=message.content,
                        tool_calls=message.tool_calls,
                        name=target_agent_id,
                    )
                    on_message_persist(nested_message)
                    return
                if message.role == "tool":
                    on_message_persist(message)

            sub_result = run_conversation_turn(
                root=root,
                agent_id=target_agent_id,
                messages=sub_messages,
                mode=mode,
                max_turns=effective_max_turns,
                on_chunk=_forward_chunk,
                on_thinking=_forward_thinking,
                on_tool_use=_forward_tool_use,
                on_tool_result=_forward_tool_result,
                on_ask_user=nested_on_ask_user,
                current_depth=current_depth + 1,
                max_depth=max_depth,
                cancel_event=cancel_event,
                on_message_persist=_persist_nested_transcript,
                disabled_tools=nested_disabled_tools,
            )
            if sub_result.cancelled:
                _release_active_agent_lock("cancelled")
                logger.debug(
                    "sub_agent nested result: target=%s cancelled turns=%s files=%d",
                    target_agent_id,
                    sub_result.turns_used,
                    len(sub_result.files_modified),
                )
                return _json_dumps({
                    "status": "cancelled",
                    "error": f"Sub-agent '{target_agent_id}' canceled by user",
                    "data": {
                        "run_id": sub_result.run_id,
                        "agent_id": target_agent_id,
                        "success": sub_result.success,
                        "turns_used": sub_result.turns_used,
                        "files_modified": sub_result.files_modified,
                        "usage": sub_result.usage,
                    },
                })
            if not sub_result.success:
                _release_active_agent_lock("error", force=True)
                logger.debug(
                    "sub_agent nested result: target=%s failed turns=%s error=%s",
                    target_agent_id,
                    sub_result.turns_used,
                    _preview_for_log(sub_result.error or "", 180),
                )
                return _json_dumps({
                    "status": "error",
                    "error": sub_result.error or f"Sub-agent '{target_agent_id}' failed",
                    "data": {
                        "run_id": sub_result.run_id,
                        "agent_id": target_agent_id,
                        "success": sub_result.success,
                        "turns_used": sub_result.turns_used,
                        "files_modified": sub_result.files_modified,
                        "usage": sub_result.usage,
                    },
                })
            assistant_text = sub_result.assistant_message or ""
            handoff_target = str(sub_result.handoff_to or "").strip().lower()
            if delegation_mode == "sticky":
                try:
                    domain_kinds = _get_agent_sticky_domain_kinds(root, target_agent_id)
                    location_id, location_kind = _read_player_location_state(root, data_dir_name)
                    if handoff_target and handoff_target == narrator_agent_id:
                        if domain_kinds and location_kind and location_kind in domain_kinds:
                            logger.warning(
                                "active-agent sticky handoff rejected: target=%s location=%s kind=%s domain_kinds=%s",
                                target_agent_id,
                                location_id or "?",
                                location_kind,
                                sorted(domain_kinds),
                            )
                            handoff_target = ""
                        else:
                            _release_active_agent_lock("sticky_handoff", force=True)
                            logger.info(
                                "active-agent sticky release by explicit handoff: target=%s handoff_to=%s",
                                target_agent_id,
                                narrator_agent_id,
                            )

                    # Respect explicit in-task handoff/release decisions made by
                    # the sticky agent itself (e.g., it switched active_agent to narrator).
                    current_active = get_active_agent_id(root)
                    if current_active == target_agent_id:
                        if domain_kinds and location_kind and location_kind not in domain_kinds:
                            _release_active_agent_lock("sticky_domain_exit", force=True)
                            logger.info(
                                "active-agent sticky auto-release: target=%s location=%s kind=%s domain_kinds=%s",
                                target_agent_id,
                                location_id or "?",
                                location_kind,
                                sorted(domain_kinds),
                            )
                        else:
                            write_active_agent(
                                root,
                                target_agent_id,
                                reason=f"sticky delegation: router keeps '{target_agent_id}' active",
                                exit_condition="router updates active-agent state before routing changes",
                                updated_by=narrator_agent_id,
                            )
                    else:
                        logger.debug(
                            "active-agent sticky release respected: target=%s current_active=%s",
                            target_agent_id,
                            current_active,
                        )
                except Exception:
                    logger.debug("Failed to update active-agent state (non-fatal)", exc_info=True)
            else:
                _release_active_agent_lock("success")
                logger.debug(
                    "sub_agent delegation one-shot: target=%s no active-agent lock persisted",
                    target_agent_id,
                )

            logger.debug(
                "sub_agent nested result: target=%s success turns=%s files=%d usage_keys=%s",
                target_agent_id,
                sub_result.turns_used,
                len(sub_result.files_modified),
                sorted(sub_result.usage.keys()) if isinstance(sub_result.usage, dict) else [],
            )
            return _json_dumps({
                "status": "success",
                "data": {
                    "run_id": sub_result.run_id,
                    "agent_id": target_agent_id,
                    "route_decision": sub_result.route_decision,
                    "active_agent": sub_result.active_agent,
                    "delegated_to": sub_result.delegated_to,
                    "success": sub_result.success,
                    "error": sub_result.error,
                    "turns_used": sub_result.turns_used,
                    "files_modified": sub_result.files_modified,
                    "assistant_text": assistant_text,
                    "delegation_mode": delegation_mode,
                    "handoff_to": handoff_target or None,
                    "usage": sub_result.usage,
                },
            })
    except Exception as e:
        _release_active_agent_lock("exception", force=True)
        logger.debug("sub_agent dispatch exception: target=%s error=%s", target_agent_id, _preview_for_log(e), exc_info=True)
        return _json_dumps({"status": "error", "error": f"Sub-agent '{target_agent_id}' failed: {e}"})


def _get_tool_schemas(
    mode: ConversationMode,
    loader: SkillLoader,
    root: Path | None = None,
    include_resolve_action: bool = True,
) -> list[dict[str, Any]]:
    schemas = get_skill_schemas(include_resolve_action=include_resolve_action, root=root)
    if mode in {"build", "play"}:
        schemas = [schema for schema in schemas if schema.get("name") != "submit_proposal"]
    else:
        # Sandbox mode must route state changes via submit_proposal.
        # Hiding direct-write tools avoids repeated, guaranteed-to-fail calls.
        schemas = [
            schema
            for schema in schemas
            if schema.get("name") not in {"write_file", "edit_file", "delete_file", "import_sillytavern_card", "ensure_playable_scaffold"}
        ]
    schemas.append(TODO_TOOL_SCHEMA)
    schemas.append(HANDOFF_TO_ROUTER_TOOL_SCHEMA)
    schemas.append(_skill_tool_schema(loader))
    if root:
        schemas.append(_build_task_tool_schema(root))
    return schemas


def _estimate_tokens(messages: list[Message]) -> int:
    total_chars = 0
    for message in messages:
        if message.content:
            total_chars += len(message.content)
        if message.tool_calls:
            for tool_call in message.tool_calls:
                total_chars += len(tool_call.name) + len(json.dumps(tool_call.arguments, ensure_ascii=False))
    return total_chars // 4


def _normalize_tool_call(tool_call: Any, tool_schemas: list[dict[str, Any]]) -> None:
    """Fix malformed tool calls from non-Anthropic models served via compatible APIs.

    Some models (e.g. GLM) generate tool names like ``glob("**/*.json")`` instead
    of ``name="glob", input={"pattern": "**/*.json"}``.  This mutates the ToolCall
    in-place to extract the real name and merge positional arguments.
    """
    raw_name = tool_call.name
    # Fast path: name is clean
    if "(" not in raw_name:
        return

    # Try to match  name(args...)
    m = re.match(r'^(\w+)\((.*)?\)$', raw_name, re.DOTALL)
    if not m:
        return

    real_name = m.group(1)
    args_str = (m.group(2) or "").strip()

    # Look up the schema so we can map positional args to the first required param
    schema = None
    for s in tool_schemas:
        if s.get("name") == real_name:
            schema = s
            break

    merged_args = dict(tool_call.arguments) if tool_call.arguments else {}

    if args_str and schema:
        params = schema.get("parameters", {})
        required = params.get("required", [])
        first_param = required[0] if required else None
        if first_param and first_param not in merged_args:
            # Strip surrounding quotes from the value
            value = args_str.strip("'\"")
            merged_args[first_param] = value

    tool_call.name = real_name
    tool_call.arguments = merged_args
    logger.info("Normalized malformed tool call: %s → %s(%s)", raw_name, real_name, merged_args)


def _trim_broken_tail(messages: list[Message]) -> None:
    """Remove the trailing assistant + tool_result messages that may have caused an API error.

    When the Anthropic API returns a 400 Bad Request, it's often because the
    last assistant message contained a malformed tool_use block (e.g. the model
    hallucinated a tool name the API doesn't recognise in the message history).
    Trimming the broken exchange lets the loop retry cleanly.
    """
    # Walk backwards: remove trailing tool messages, then the assistant message
    while len(messages) > 1 and messages[-1].role == "tool":
        messages.pop()
    if len(messages) > 1 and messages[-1].role == "assistant":
        messages.pop()


def _truncate_messages_for_budget(messages: list[Message], max_context_chars: int) -> None:
    if max_context_chars <= 0 or len(messages) <= 3:
        return
    while len(messages) > 3 and (_estimate_tokens(messages) * 4) > max_context_chars:
        # Keep system at index 0 and trim earliest non-system entry.
        messages.pop(1)


def _handle_todo_tool(todo_manager: TodoManager, args: dict[str, Any]) -> str:
    # Accept both "todos" (Claude Code convention) and "items" (legacy)
    items = args.get("todos") or args.get("items")
    if not isinstance(items, list):
        return _json_dumps({"status": "error", "error": "TodoWrite requires a 'todos' array"})
    try:
        snapshot = todo_manager.update(items)
    except ValueError as exc:
        return _json_dumps({"status": "error", "error": str(exc)})
    return _json_dumps(
        {
            "status": "success",
            "data": {
                "items": snapshot,
                "rendered": todo_manager.render(),
            },
        }
    )


def _handle_skill_tool(loader: SkillLoader, args: dict[str, Any]) -> str:
    skill_name = str(args.get("skill", "")).strip()
    if not skill_name:
        return _json_dumps({"status": "error", "error": "Skill requires a non-empty skill name"})
    content = loader.get_content(skill_name)
    if content is None:
        return _json_dumps({"status": "error", "error": f"Skill not found: {skill_name}"})
    return _json_dumps({"status": "success", "data": {"skill": skill_name, "content": content}})


def _track_modified_files(tool_name: str, tool_result: str | None, files_modified: list[str]) -> None:
    if tool_name not in {"write_file", "edit_file", "delete_file", "import_sillytavern_card", "ensure_playable_scaffold"} or not tool_result:
        return
    try:
        payload = json.loads(tool_result)
    except json.JSONDecodeError:
        return
    if payload.get("status") != "success":
        return
    data = payload.get("data", {})
    files = data.get("files")
    if isinstance(files, list):
        for path in files:
            if isinstance(path, str) and path and path not in files_modified:
                files_modified.append(path)
    path = data.get("path")
    if isinstance(path, str) and path and path not in files_modified:
        files_modified.append(path)


def _merge_usage(total: dict[str, Any], part: dict[str, Any] | None) -> None:
    if not part:
        return
    for key, value in part.items():
        if isinstance(value, (int, float)):
            total[key] = total.get(key, 0) + value
        else:
            total[key] = value


def _finalize_turn(
    root: Path,
    run_id: str,
    branch: str,
    base_head_event: int,
    mode: ConversationMode,
    agent_id: str,
    assistant_chunks: list[str],
    files_modified: list[str],
    tool_calls_made: list[str],
    turns_used: int,
    todo_manager: TodoManager,
    usage: dict[str, Any],
    proposal: dict[str, Any] | None,
    handoff_to: str | None = None,
    route_decision: str | None = None,
    active_agent: str | None = None,
    delegated_to: str | None = None,
) -> ConversationTurnResult:
    assistant_message = "".join(chunk for chunk in assistant_chunks if chunk)
    if mode in {"build", "play"} and files_modified:
        manifest_path = get_manifest_path(root)
        manifest = Manifest(**json.loads(manifest_path.read_text(encoding="utf-8")))
        current_head = manifest.branches[branch].head_event
        if current_head != base_head_event:
            return ConversationTurnResult(
                success=False,
                run_id=run_id,
                assistant_message=assistant_message,
                route_decision=route_decision,
                active_agent=active_agent,
                delegated_to=delegated_to,
                files_modified=files_modified,
                tool_calls_made=tool_calls_made,
                turns_used=turns_used,
                todo_snapshot=todo_manager.snapshot(),
                usage=usage,
                proposal=proposal,
                error=(
                    f"base_head_event mismatch: conversation started at {base_head_event}, "
                    f"current head is {current_head}"
                ),
            )

        new_event_id = current_head + 1
        event = GameEvent(
            id=new_event_id,
            type=mode,
            actor=agent_id,
            payload={
                "run_id": run_id,
                "files_modified": files_modified,
                "tool_calls": tool_calls_made,
            },
        )
        append_event(root, branch, event)
        manifest.branches[branch].head_event = new_event_id
        if manifest.branches[branch].max_event is None or manifest.branches[branch].max_event < new_event_id:
            manifest.branches[branch].max_event = new_event_id
        atomic_write_json(manifest_path, manifest.model_dump())

    return ConversationTurnResult(
        success=True,
        run_id=run_id,
        assistant_message=assistant_message,
        assistant_speaker=agent_id,
        route_decision=route_decision,
        active_agent=active_agent or agent_id,
        delegated_to=delegated_to,
        files_modified=files_modified,
        tool_calls_made=tool_calls_made,
        turns_used=turns_used,
        todo_snapshot=todo_manager.snapshot(),
        usage=usage,
        proposal=proposal,
        handoff_to=handoff_to,
    )
