"""Skill tool registry for NeonRP agents.

Provides controlled, permission-aware tools that agents can use to retrieve
context, find entities, and read files.
"""

import json
import logging
import re
import time
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from neonrp.core.config import load_config
from neonrp.core.importers.sillytavern import build_entity_from_card_file, is_valid_entity_id
from neonrp.core.indexing import refresh_manifest_index
from neonrp.core.paths import get_game_dir, get_neonrp_dir
from neonrp.core.permissions import check_permission, check_write_permission, PermissionResult
from neonrp.core.retrieval import retrieve_context
from neonrp.core.rules import load_rules_profile, resolve_action as rules_resolve_action
from neonrp.core.storage import atomic_write_text
from neonrp.core.template_assets import (
    DEFAULT_TEMPLATE_NAME,
    ensure_playable_runtime_scaffold,
    list_playable_scaffold_targets,
)


logger = logging.getLogger(__name__)


@dataclass
class SkillResult:
    """Result from a skill invocation."""

    success: bool
    data: Any = None
    error: str | None = None
    denied_paths: list[str] = field(default_factory=list)
    duration_ms: int = 0


@dataclass
class SkillCall:
    """Record of a skill invocation for auditing."""

    timestamp: str
    run_id: str
    agent_id: str
    skill_name: str
    args: dict[str, Any]
    result_summary: str
    error: str | None
    duration_ms: int
    denied_paths: list[str]


# Skill JSON schemas for LLM tool calling
SKILL_SCHEMAS = {
    "read_context": {
        "name": "read_context",
        "description": (
            "Retrieve relevant context entities for a query using semantic search. "
            "Use this when you need background information about the game world "
            "before taking action. Returns entity summaries ranked by relevance. "
            "For game-start intents, prefer reading the runtime contract's configured startup file first "
            "before broad semantic retrieval. "
            "Example: read_context('the dragon king') returns entities related to that topic."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural language query describing what you want to know about (e.g., 'dark forest monsters', 'player inventory')",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results to return (default: 10). Use smaller values for focused queries.",
                    "default": 10,
                },
            },
            "required": ["query"],
        },
    },
    "find": {
        "name": "find",
        "description": (
            "Find entities by exact id, tag, kind, or keyword. "
            "Use this when you know the specific entity you are looking for. "
            "For broad/semantic searches, prefer read_context instead. "
            "When you only know an entity id/name but not its file path, call this before read_file."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Exact entity id (e.g., 'hero'), or keyword to search names/summaries",
                },
                "kind": {
                    "type": "string",
                    "description": "Filter by entity kind defined in the current project index.",
                },
                "tag": {
                    "type": "string",
                    "description": "Filter by tag (e.g., 'hostile', 'quest-giver')",
                },
            },
            "required": ["query"],
        },
    },
    "read_file": {
        "name": "read_file",
        "description": (
            "Read a file's contents. You MUST call this before write_file or edit_file "
            "on the same path to understand existing content and avoid accidental overwrites. "
            "Use project-root relative paths by default (absolute paths are also accepted). "
            "Do NOT use placeholder prefixes like '<project-root>' or '/workspace/project'. "
            "Content is truncated to max_chars. "
            "Only files within agent read permissions are accessible. "
            "Do NOT guess file paths from entity IDs; use find/list_entities/glob to confirm uncertain paths first."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Project-root relative path preferred (e.g., 'src/main.py' or 'index.html'). Absolute path is also accepted.",
                },
                "max_chars": {
                    "type": "integer",
                    "description": "Maximum characters to return. Use smaller values for quick checks, larger for full reads. Default: 5000.",
                    "default": 5000,
                },
            },
            "required": ["path"],
        },
    },
    "list_entities": {
        "name": "list_entities",
        "description": (
            "List all indexed entities, optionally filtered by kind or tag. "
            "Use this to discover what entities exist before reading or modifying them. "
            "Do not use as the first startup step when an explicit entrypoint file is available. "
            "Returns entity ids, names, kinds, and tags."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "kind": {
                    "type": "string",
                    "description": "Filter by entity kind defined in the current project index.",
                },
                "tag": {
                    "type": "string",
                    "description": "Filter by tag (e.g., 'hostile', 'merchant', 'quest')",
                },
            },
        },
    },
    "submit_proposal": {
        "name": "submit_proposal",
        "description": (
            "Submit a batch of changes to game/ state files as an atomic proposal. "
            "This is the ONLY way to create, update, or delete files under game/. "
            "All ops are applied atomically — either all succeed or none do. "
            "Always call read_file or read_context first to understand current state before proposing changes. "
            "Call this once per turn with ALL intended changes bundled together."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "proposal_version": {
                    "type": "string",
                    "minLength": 1,
                    "description": "Proposal schema version (currently '0.1').",
                },
                "run_id": {"type": "string", "minLength": 1, "description": "The run ID for this agent run (provided in context)"},
                "agent_id": {"type": "string", "minLength": 1, "description": "The agent ID (provided in context)"},
                "branch": {"type": "string", "minLength": 1, "description": "Target branch name (provided in context)"},
                "base_head_event": {"type": "integer", "description": "Base event ID for optimistic concurrency (provided in context)"},
                "query": {"type": "string", "description": "Original user query that triggered this proposal"},
                "rationale": {
                    "type": "string",
                    "description": "Brief explanation of WHY these changes are being made (for audit log)",
                },
                "ops": {
                    "type": "array",
                    "description": "List of file operations. Each op targets a path under game/.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "op": {
                                "type": "string",
                                "enum": ["upsert_text", "delete"],
                                "description": "upsert_text: create or overwrite file content. delete: remove the file.",
                            },
                            "path": {
                                "type": "string",
                                "minLength": 1,
                                "description": "Path relative to game/ (e.g., 'character/hero.json', 'location/tavern.json'). Do NOT include the 'game/' prefix.",
                            },
                            "content": {
                                "type": "string",
                                "description": "Full file content as a string. Required for upsert_text. For JSON entities, must be valid JSON with id/kind/name fields. Omit for delete ops.",
                            },
                        },
                        "required": ["op", "path"],
                    },
                },
            },
            "required": ["proposal_version", "run_id", "agent_id", "branch", "base_head_event", "ops"],
        },
    },
    "resolve_action": {
        "name": "resolve_action",
        "description": (
            "Compute the mechanical outcome of a game action (combat, healing, trading, movement). "
            "This is a PURE COMPUTATION tool — it does NOT modify any files. "
            "Use the returned values to build ops for submit_proposal. "
            "Typical workflow: resolve_action → read affected entities → submit_proposal with updated values."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["damage", "heal", "buy", "sell", "move"],
                    "description": "Action type: damage (deal damage), heal (restore hp), buy (purchase item), sell (sell item), move (change location)",
                },
                "actor": {
                    "type": "string",
                    "description": "Entity id performing the action (e.g., 'player', 'goblin_chief')",
                },
                "target": {
                    "type": "string",
                    "description": "Target entity id. Required for damage/heal. For buy, this is the shop entity id.",
                },
                "amount": {
                    "type": "integer",
                    "description": "Numeric amount: damage/heal points, or quantity for buy/sell",
                },
                "item": {
                    "type": "string",
                    "description": "Item entity id for buy/sell actions (e.g., 'iron_sword', 'health_potion')",
                },
                "destination": {
                    "type": "string",
                    "description": "Location entity id for move actions (e.g., 'dark_forest', 'castle_gate')",
                },
            },
            "required": ["action", "actor"],
        },
    },
    "write_file": {
        "name": "write_file",
        "description": (
            "Create or overwrite a file. "
            "Use project-root relative paths by default (absolute paths are also accepted). "
            "Do NOT use placeholder prefixes like '<project-root>' or '/workspace/project'. "
            "Works only when the target path is allowed by direct_write_globs. "
            "\n\nIMPORTANT usage rules:\n"
            "- ALWAYS call read_file first if the file may already exist, to avoid losing content.\n"
            "- For small edits to existing files, prefer edit_file over write_file.\n"
            "- write_file completely OVERWRITES the file — pass the FULL desired content.\n"
            "- Parent directories are created automatically."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "minLength": 1,
                    "description": "Project-root relative path preferred (e.g., 'src/app.js' or 'docs/notes.md'). Absolute path is also accepted.",
                },
                "content": {
                    "type": "string",
                    "description": "The COMPLETE file content to write. This replaces the entire file. Use UTF-8 text.",
                },
            },
            "required": ["path", "content"],
        },
    },
    "edit_file": {
        "name": "edit_file",
        "description": (
            "Edit an existing file by replacing an exact text substring. "
            "Works only when the target path is allowed by direct_write_globs. "
            "Preferred over write_file when making small, targeted changes to existing files.\n\n"
            "IMPORTANT usage rules:\n"
            "- ALWAYS call read_file first to see the current content and find the exact text to replace.\n"
            "- old_text must match EXACTLY (including whitespace and newlines) and appear EXACTLY ONCE in the file.\n"
            "- If old_text is not found or appears multiple times, the edit will fail.\n"
            "- To insert text, use a surrounding passage as old_text and include the insertion in new_text."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "minLength": 1,
                    "description": "Project-root relative path preferred (e.g., 'src/app.js' or 'docs/notes.md'). Absolute path is also accepted.",
                },
                "old_text": {
                    "type": "string",
                    "minLength": 1,
                    "description": "The exact text to find in the file. Must match character-for-character and appear exactly once. Include enough surrounding context to be unique.",
                },
                "new_text": {
                    "type": "string",
                    "description": "The replacement text. Can be empty string to delete old_text. Can be longer or shorter than old_text.",
                },
            },
            "required": ["path", "old_text", "new_text"],
        },
    },
    "delete_file": {
        "name": "delete_file",
        "description": (
            "Delete a single file. Cannot delete directories. "
            "Use project-root relative paths by default (absolute paths are also accepted). "
            "Works only when the target path is allowed by direct_write_globs. "
            "Returns the deleted file path on success."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "minLength": 1,
                    "description": "Project-root relative path preferred (e.g., 'docs/old-notes.md'). Absolute path is also accepted.",
                },
            },
            "required": ["path"],
        },
    },
    "glob": {
        "name": "glob",
        "description": (
            "Find files matching a glob pattern within read permissions. "
            "Use this to discover files before reading them. "
            "Returns a list of matching file paths sorted by name."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "minLength": 1,
                    "description": "Glob pattern (e.g., '*.json', 'game/**/*.json', 'lore/*.md', 'notes/session*.txt')",
                },
                "path": {
                    "type": "string",
                    "description": "Base directory to search from (default: project root). Relative to project root.",
                },
            },
            "required": ["pattern"],
        },
    },
    "import_sillytavern_card": {
        "name": "import_sillytavern_card",
        "description": (
            "Import a SillyTavern JSON or PNG character card into the current NeonRP project. "
            "Use this for Tavern/酒馆 cards instead of read_file when the source is a .png or raw card .json. "
            "The tool extracts embedded PNG card payloads, converts them to a NeonRP entity, "
            "can optionally set the destination path and visible name, writes the entity under game/, "
            "and returns the imported entity path and metadata."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "minLength": 1,
                    "description": "Project-root relative or absolute path to a SillyTavern card file (.png or .json).",
                },
                "entity_id": {
                    "type": "string",
                    "description": "Optional ASCII entity id override (must match [a-z0-9._-]+).",
                },
                "target_path": {
                    "type": "string",
                    "description": "Optional destination JSON path under game/ (e.g. 'game/npc/yan_chiyang.json' or 'npc/yan_chiyang.json').",
                },
                "name": {
                    "type": "string",
                    "description": "Optional visible name override for the imported entity. Chinese is allowed here.",
                },
            },
            "required": ["path"],
        },
    },
    "ensure_playable_scaffold": {
        "name": "ensure_playable_scaffold",
        "description": (
            "Ensure the current project has the minimum runtime scaffold required for play mode. "
            "This copies packaged play agents and runtime metadata when missing, and rewrites "
            "the active-agent state with the canonical protocol. Use this after build-mode world "
            "generation before claiming the project is playable."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "template_name": {
                    "type": "string",
                    "description": "Optional template source for scaffold assets. Defaults to 'default'.",
                    "default": DEFAULT_TEMPLATE_NAME,
                },
                "active_agent": {
                    "type": "string",
                    "description": "Optional agent id to set as the current active agent after scaffold creation. Defaults to the runtime router agent.",
                },
                "force": {
                    "type": "boolean",
                    "description": "When true, overwrite packaged scaffold files even if they already exist.",
                    "default": False,
                },
            },
        },
    },
    "grep": {
        "name": "grep",
        "description": (
            "Search file contents using a regex pattern. "
            "Returns matching lines with file paths and line numbers. "
            "Use this to find specific content across multiple files. "
            "Results are filtered by read permissions."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "minLength": 1,
                    "description": "Regex pattern to search for (e.g., '\"kind\":\\s*\"character\"', 'dragon', 'hp.*[0-9]+')",
                },
                "path": {
                    "type": "string",
                    "description": "Base directory to search in (default: project root). Relative to project root.",
                },
                "glob": {
                    "type": "string",
                    "description": "Glob filter for file names (e.g., '*.md' for markdown only, '**/*.json' for all JSON)",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of matching lines to return (default: 50). Use smaller values for targeted searches.",
                },
            },
            "required": ["pattern"],
        },
    },
    "ask_user": {
        "name": "ask_user",
        "description": (
            "Ask the user questions during gameplay. You MUST call this tool whenever "
            "the user faces a meaningful choice — do NOT decide on the user's behalf. "
            "Users will always be able to select 'Other' to provide custom text input. "
            "Use multiSelect: true to allow multiple answers for a question."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "questions": {
                    "type": "array",
                    "description": "Questions to ask the user (1-4 questions)",
                    "minItems": 1,
                    "maxItems": 4,
                    "items": {
                        "type": "object",
                        "properties": {
                            "question": {
                                "type": "string",
                                "description": (
                                    "The complete question to ask the user. Should be clear, "
                                    "specific, and end with a question mark."
                                ),
                            },
                            "header": {
                                "type": "string",
                                "description": "Very short label displayed as a chip/tag (max 12 chars).",
                            },
                            "options": {
                                "type": "array",
                                "description": "The available choices (2-4 options). An 'Other' option is added automatically.",
                                "minItems": 2,
                                "maxItems": 4,
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "label": {
                                            "type": "string",
                                            "description": "Display text for this option (1-8 words).",
                                        },
                                        "description": {
                                            "type": "string",
                                            "description": "Explanation of what this option means or what will happen.",
                                        },
                                    },
                                    "required": ["label", "description"],
                                },
                            },
                            "multiSelect": {
                                "type": "boolean",
                                "default": False,
                                "description": "Set to true to allow multiple selections.",
                            },
                        },
                        "required": ["question", "header", "options", "multiSelect"],
                    },
                },
            },
            "required": ["questions"],
        },
    },
}


def _skill_schema_map(include_resolve_action: bool = True) -> dict[str, dict[str, Any]]:
    """Build effective skill schema map based on feature toggles."""
    if include_resolve_action:
        return SKILL_SCHEMAS
    return {name: schema for name, schema in SKILL_SCHEMAS.items() if name != "resolve_action"}


def _indexed_entity_kinds(root: Path | None) -> list[str]:
    """Read entity kinds from the current manifest index."""
    if not isinstance(root, Path):
        return []
    manifest_path = root / ".neonrp" / "manifest.json"
    if not manifest_path.exists():
        return []
    kinds: set[str] = set()
    try:
        manifest, _, _ = refresh_manifest_index(root, full_rebuild=False)
        kinds.update(str(record.kind).strip() for record in manifest.entities.values() if str(record.kind).strip())
    except Exception:
        pass
    if kinds:
        return sorted(kinds)
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        entities = payload.get("entities", {})
        if isinstance(entities, dict):
            for record in entities.values():
                if isinstance(record, dict):
                    kind = str(record.get("kind", "")).strip()
                    if kind:
                        kinds.add(kind)
    except Exception:
        pass
    return sorted(kinds)


def _apply_dynamic_kind_enum(schemas: dict[str, dict[str, Any]], kinds: list[str]) -> None:
    """Inject available indexed kinds into find/list_entities kind parameters."""
    if not kinds:
        return
    kind_desc = f"Filter by entity kind. Must be one of indexed kinds: {', '.join(kinds)}."
    for tool_name in ("find", "list_entities"):
        tool_schema = schemas.get(tool_name)
        if not isinstance(tool_schema, dict):
            continue
        params = tool_schema.get("parameters")
        if not isinstance(params, dict):
            continue
        properties = params.get("properties")
        if not isinstance(properties, dict):
            continue
        kind_schema = properties.get("kind")
        if not isinstance(kind_schema, dict):
            continue
        kind_schema["enum"] = kinds
        kind_schema["description"] = kind_desc


def _effective_skill_schema_map(include_resolve_action: bool = True, root: Path | None = None) -> dict[str, dict[str, Any]]:
    """Return feature-gated schemas with optional dynamic kind enum injection."""
    schemas = deepcopy(_skill_schema_map(include_resolve_action=include_resolve_action))
    _apply_dynamic_kind_enum(schemas, _indexed_entity_kinds(root))
    return schemas


def get_skill_schemas(include_resolve_action: bool = True, root: Path | None = None) -> list[dict]:
    """Get all skill schemas for LLM tool calling."""
    return list(_effective_skill_schema_map(include_resolve_action=include_resolve_action, root=root).values())


def validate_tool_arguments(
    name: str,
    args: dict[str, Any],
    *,
    include_resolve_action: bool = True,
    allowed_tool_names: set[str] | None = None,
    root: Path | None = None,
) -> tuple[bool, str | None]:
    """Validate tool arguments against schema.

    Args:
        name: Tool name
        args: Arguments to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    schemas = _effective_skill_schema_map(include_resolve_action=include_resolve_action, root=root)
    if allowed_tool_names is not None:
        schemas = {tool_name: schema for tool_name, schema in schemas.items() if tool_name in allowed_tool_names}

    if name not in schemas:
        available = ", ".join(sorted(schemas.keys()))
        return False, (
            f"Unknown tool: {name}. "
            f"Available tools: {available}. "
            f"Call tools by name with arguments as a JSON object, e.g. "
            f'{{\"name\": \"glob\", \"input\": {{\"pattern\": \"**/*.json\"}}}}'
        )

    schema = schemas[name]
    params = schema.get("parameters", {})
    properties = params.get("properties", {})
    required = params.get("required", [])

    # Detect completely empty arguments — give a detailed example to help the
    # model self-correct (especially for Ollama/compatible providers that may
    # drop arguments during streaming).
    if not args and required:
        example_args = {}
        for field_name in required:
            prop = properties.get(field_name, {})
            ptype = prop.get("type", "string")
            desc = prop.get("description", "")
            if ptype == "array":
                example_args[field_name] = ["option1", "option2"]
            else:
                example_args[field_name] = desc[:60] if desc else f"<{field_name}>"
        example_json = json.dumps(example_args, ensure_ascii=False)
        return False, (
            f"Tool '{name}' received empty arguments. "
            f"Required fields: {', '.join(required)}. "
            f"You MUST pass arguments as a JSON object, e.g.: {example_json}"
        )

    # Check required fields
    for field_name in required:
        if field_name not in args:
            return False, f"Missing required field: {field_name}"
        if args[field_name] is None:
            return False, f"Field '{field_name}' cannot be null"

    # Validate each provided field
    for field_name, value in args.items():
        if field_name not in properties:
            # Allow extra fields (additionalProperties not explicitly false)
            continue

        prop_schema = properties[field_name]
        prop_type = prop_schema.get("type")

        # Auto-coerce: some models pass dict/list where a string is expected
        # (e.g. write_file content as a JSON object instead of serialized string).
        if prop_type == "string" and isinstance(value, (dict, list)):
            value = json.dumps(value, ensure_ascii=False, indent=2)
            args[field_name] = value

        # Type validation
        if prop_type == "string":
            if not isinstance(value, str):
                return False, f"Field '{field_name}' must be a string, got {type(value).__name__}"
            # minLength validation
            min_length = prop_schema.get("minLength")
            if min_length is not None and len(value) < min_length:
                return False, f"Field '{field_name}' must be at least {min_length} character(s)"
            # enum validation
            enum_values = prop_schema.get("enum")
            if enum_values is not None and value not in enum_values:
                return False, f"Field '{field_name}' must be one of: {', '.join(enum_values)}"
        elif prop_type == "integer":
            if not isinstance(value, int) or isinstance(value, bool):
                return False, f"Field '{field_name}' must be an integer, got {type(value).__name__}"
        elif prop_type == "array":
            if not isinstance(value, list):
                return False, f"Field '{field_name}' must be an array, got {type(value).__name__}"
            # Validate array items if items schema exists
            items_schema = prop_schema.get("items", {})
            if items_schema.get("type") == "object":
                item_props = items_schema.get("properties", {})
                item_required = items_schema.get("required", [])
                for i, item in enumerate(value):
                    if not isinstance(item, dict):
                        return False, f"{field_name}[{i}] must be an object"
                    # Check required fields in item
                    for req_field in item_required:
                        if req_field not in item:
                            return False, f"{field_name}[{i}] missing required field: {req_field}"
                    # Validate item fields
                    for item_field, item_value in item.items():
                        if item_field not in item_props:
                            continue
                        item_prop_schema = item_props[item_field]
                        item_prop_type = item_prop_schema.get("type")
                        if item_prop_type == "string":
                            if not isinstance(item_value, str):
                                return False, f"{field_name}[{i}].{item_field} must be a string"
                            item_min_len = item_prop_schema.get("minLength")
                            if item_min_len is not None and len(item_value) < item_min_len:
                                return (
                                    False,
                                    f"{field_name}[{i}].{item_field} must be at least {item_min_len} character(s)",
                                )
                            item_enum = item_prop_schema.get("enum")
                            if item_enum is not None and item_value not in item_enum:
                                return False, f"{field_name}[{i}].{item_field} must be one of: {', '.join(item_enum)}"

    return True, None


class SkillRegistry:
    """Permission-aware skill registry for agent tool calls.

    Enforces agent permissions on file access and logs all invocations.
    """

    def __init__(
        self,
        root: Path,
        run_id: str,
        agent_id: str,
        read_globs: list[str],
        deny_globs: list[str],
        direct_write_globs: list[str] | None = None,
        allow_protected_paths: bool = False,
        enable_resolve_action: bool | None = None,
        rules_profile: dict[str, Any] | None = None,
    ):
        """Initialize skill registry.

        Args:
            root: Project root directory
            run_id: Current agent run ID
            agent_id: Agent identifier
            read_globs: Agent read permission globs
            deny_globs: Agent deny globs (takes priority)
            direct_write_globs: Paths allowed for direct writes via write_file/edit_file
            allow_protected_paths: Whether to allow writing in protected directories
            enable_resolve_action: Whether resolve_action tool is available
            rules_profile: Optional preloaded rules profile for resolve_action
        """
        self.root = root
        self.run_id = run_id
        self.agent_id = agent_id
        self.read_globs = read_globs
        self.deny_globs = deny_globs
        self.direct_write_globs = direct_write_globs or []
        self.allow_protected_paths = allow_protected_paths
        config = load_config(root)
        self.enable_resolve_action = (
            config.rules.enable_resolve_action if enable_resolve_action is None else bool(enable_resolve_action)
        )
        self._rules_profile = rules_profile or load_rules_profile(root, config.rules.profile_path)
        self._calls: list[SkillCall] = []

    def _resolve_path(self, path: str) -> Path:
        mapped = self._map_model_placeholder(path)
        if mapped is not None:
            return self.root / mapped if mapped else self.root
        candidate = Path(path)
        return candidate if candidate.is_absolute() else (self.root / candidate)

    def _map_model_placeholder(self, path: str) -> str | None:
        """Map common model placeholder paths to the current project root.

        Some models emit placeholders like '/workspace/project/...' or
        '<project-root>/...'. On Windows these can resolve outside the active
        project or fail path validation. We remap those placeholders to self.root.
        """
        raw = str(path).replace("\\", "/")
        prefixes = (
            "/workspace/project/",
            "<project-root>/",
            "${PROJECT_ROOT}/",
            "$PROJECT_ROOT/",
            "{{project_root}}/",
        )
        roots = (
            "/workspace/project",
            "<project-root>",
            "${PROJECT_ROOT}",
            "$PROJECT_ROOT",
            "{{project_root}}",
        )
        if raw in roots:
            return ""
        for prefix in prefixes:
            if raw.startswith(prefix):
                return raw[len(prefix) :]
        return None

    def _path_for_permission(self, path: str) -> str:
        raw = str(path).replace("\\", "/")
        if ".." in raw.split("/"):
            return raw
        candidate = self._resolve_path(path)
        try:
            rel = candidate.resolve().relative_to(self.root.resolve())
            return str(rel).replace("\\", "/")
        except Exception:
            # Keep best-effort normalized path for error reporting when target is outside root.
            return str(candidate).replace("\\", "/")

    def invoke(self, skill_name: str, args: dict[str, Any]) -> SkillResult:
        """Invoke a skill by name.

        Args:
            skill_name: Name of the skill to invoke
            args: Skill arguments

        Returns:
            SkillResult with data or error
        """
        start_time = time.time()

        if skill_name == "resolve_action" and not self.enable_resolve_action:
            return SkillResult(success=False, error="resolve_action is disabled by rules config")

        available_schemas = _skill_schema_map(include_resolve_action=self.enable_resolve_action)
        if skill_name not in available_schemas:
            return SkillResult(success=False, error=f"Unknown skill: {skill_name}")

        # Dispatch to skill implementation
        try:
            if skill_name == "read_context":
                result = self._skill_read_context(args)
            elif skill_name == "find":
                result = self._skill_find(args)
            elif skill_name == "read_file":
                result = self._skill_read_file(args)
            elif skill_name == "list_entities":
                result = self._skill_list_entities(args)
            elif skill_name == "resolve_action":
                result = self._skill_resolve_action(args)
            elif skill_name == "write_file":
                result = self._skill_write_file(args)
            elif skill_name == "edit_file":
                result = self._skill_edit_file(args)
            elif skill_name == "delete_file":
                result = self._skill_delete_file(args)
            elif skill_name == "glob":
                result = self._skill_glob(args)
            elif skill_name == "import_sillytavern_card":
                result = self._skill_import_sillytavern_card(args)
            elif skill_name == "ensure_playable_scaffold":
                result = self._skill_ensure_playable_scaffold(args)
            elif skill_name == "grep":
                result = self._skill_grep(args)
            else:
                result = SkillResult(success=False, error=f"Skill not implemented: {skill_name}")
        except Exception as e:
            result = SkillResult(success=False, error=str(e))

        # Calculate duration
        duration_ms = int((time.time() - start_time) * 1000)
        result.duration_ms = duration_ms

        # Log the call
        self._log_call(skill_name, args, result)

        return result

    def _check_path_permission(self, path: str) -> PermissionResult:
        """Check if a path is allowed by agent permissions."""
        return check_permission(self._path_for_permission(path), self.read_globs, self.deny_globs)

    def _filter_paths(self, items: list[dict], path_key: str = "path") -> tuple[list[dict], list[str]]:
        """Filter items by path permission.

        Returns:
            Tuple of (allowed items, denied paths)
        """
        allowed = []
        denied = []

        for item in items:
            path = item.get(path_key, "")
            result = self._check_path_permission(path)
            if result.allowed:
                if isinstance(path, str) and path:
                    item_copy = dict(item)
                    item_copy[path_key] = str(self._resolve_path(path).resolve())
                    allowed.append(item_copy)
                else:
                    allowed.append(item)
            else:
                denied.append(path)
                logger.warning(f"Path denied for agent {self.agent_id}: {path}")

        return allowed, denied

    def _skill_read_context(self, args: dict[str, Any]) -> SkillResult:
        """Execute read_context skill."""
        query = args.get("query", "")
        limit = args.get("limit", 10)

        if not query:
            return SkillResult(success=False, error="Query is required")

        items = retrieve_context(self.root, query, max_results=limit * 2)  # Get extra to filter
        allowed, denied = self._filter_paths(items)

        return SkillResult(success=True, data=allowed[:limit], denied_paths=denied)

    def _skill_find(self, args: dict[str, Any]) -> SkillResult:
        """Execute find skill."""
        query = args.get("query", "")
        kind_filter = args.get("kind")
        tag_filter = args.get("tag")

        if not query:
            return SkillResult(success=False, error="Query is required")

        # Use retrieval for now (could optimize with direct manifest access)
        items = retrieve_context(self.root, query, max_results=50)

        # Apply filters
        if kind_filter:
            items = [i for i in items if i.get("kind") == kind_filter]
        if tag_filter:
            items = [i for i in items if tag_filter in i.get("data", {}).get("tags", [])]

        allowed, denied = self._filter_paths(items)

        return SkillResult(success=True, data=allowed, denied_paths=denied)

    def _skill_read_file(self, args: dict[str, Any]) -> SkillResult:
        """Execute read_file skill."""
        path = args.get("path", "")
        max_chars = args.get("max_chars", 5000)  # Default truncation limit

        if not path:
            return SkillResult(success=False, error="Path is required")

        result = self._check_path_permission(path)
        if not result.allowed:
            return SkillResult(success=False, error=f"Permission denied for path: {path}", denied_paths=[path])

        file_path = self._resolve_path(path)
        if not file_path.exists():
            return SkillResult(success=False, error=f"File not found: {path}")

        try:
            content = file_path.read_text(encoding="utf-8")
            truncated = False
            if len(content) > max_chars:
                content = content[:max_chars]
                truncated = True
            return SkillResult(
                success=True,
                data={"path": str(file_path.resolve()), "content": content, "truncated": truncated},
            )
        except Exception as e:
            return SkillResult(success=False, error=f"Failed to read file: {e}")

    def _skill_list_entities(self, args: dict[str, Any]) -> SkillResult:
        """Execute list_entities skill."""
        kind_filter = args.get("kind")
        tag_filter = args.get("tag")

        try:
            manifest, _, warnings = refresh_manifest_index(self.root, full_rebuild=False)
        except Exception as e:
            return SkillResult(success=False, error=f"Failed to refresh entity index: {e}")

        if warnings:
            logger.info("list_entities index refresh warnings: %d", len(warnings))

        entities = []
        for _, record in manifest.entities.items():
            entity = {
                "id": record.id,
                "kind": record.kind,
                "name": record.name,
                "path": record.path,
                "tags": record.tags or [],
                "summary": record.summary,
            }

            # Apply filters
            if kind_filter and record.kind != kind_filter:
                continue
            if tag_filter and tag_filter not in (record.tags or []):
                continue

            entities.append(entity)

        allowed, denied = self._filter_paths(entities)

        return SkillResult(success=True, data=allowed, denied_paths=denied)

    def _skill_resolve_action(self, args: dict[str, Any]) -> SkillResult:
        """Resolve a game action mechanically.

        This skill computes the outcome of game actions without modifying files.
        The agent should use the computed values to build correct ops.
        """
        action = args.get("action")
        actor = args.get("actor")
        target = args.get("target")
        amount = args.get("amount")
        item = args.get("item")
        destination = args.get("destination")

        if not action or not actor:
            return SkillResult(success=False, error="action and actor are required")

        # Use the rules engine to resolve the action
        result = rules_resolve_action(
            root=self.root,
            action=action,
            actor=actor,
            target=target,
            amount=amount,
            item=item,
            destination=destination,
            profile=self._rules_profile,
        )

        return SkillResult(
            success=result.success,
            data={
                "action": result.action,
                "message": result.message,
                "computed_values": result.computed_values,
            },
            error=result.error,
        )

    @staticmethod
    def _normalize_json_text_for_write(path: str, content: Any) -> str:
        """Pretty-print JSON payloads with UTF-8 chars to avoid escaped \\uXXXX text."""
        text = content if isinstance(content, str) else str(content)
        normalized_path = str(path or "").replace("\\", "/").lower()
        if not normalized_path.endswith(".json"):
            return text
        try:
            parsed = json.loads(text)
        except Exception:
            return text
        return json.dumps(parsed, ensure_ascii=False, indent=2)

    def _skill_write_file(self, args: dict[str, Any]) -> SkillResult:
        """Execute write_file skill.

        Writes content to a file if path is in direct_write_globs.
        For game/ changes, guide user to use submit_proposal.
        """
        path = args.get("path", "")
        content = args.get("content", "")

        if not path:
            return SkillResult(success=False, error="path is required")

        # Check write permission
        permission_path = self._path_for_permission(path)
        perm_result = check_write_permission(
            permission_path,
            self.direct_write_globs,
            self.deny_globs,
            allow_protected_paths=self.allow_protected_paths,
        )
        if not perm_result.allowed:
            return SkillResult(success=False, error=perm_result.reason, denied_paths=[path])

        # Perform atomic write
        try:
            file_path = self._resolve_path(path)
            normalized_content = self._normalize_json_text_for_write(path, content)
            atomic_write_text(file_path, normalized_content)
            logger.info(f"write_file: wrote {len(normalized_content)} chars to {path}")
            return SkillResult(
                success=True,
                data={"path": str(file_path.resolve()), "bytes_written": len(normalized_content.encode("utf-8"))},
            )
        except Exception as e:
            return SkillResult(success=False, error=f"Failed to write file: {e}")

    def _skill_edit_file(self, args: dict[str, Any]) -> SkillResult:
        """Execute edit_file skill.

        Replaces exact text in a file if path is in direct_write_globs.
        old_text must appear exactly once for safe replacement.
        """
        path = args.get("path", "")
        old_text = args.get("old_text", "")
        new_text = args.get("new_text", "")

        if not path:
            return SkillResult(success=False, error="path is required")
        if not old_text:
            return SkillResult(success=False, error="old_text is required")

        # Check write permission
        permission_path = self._path_for_permission(path)
        perm_result = check_write_permission(
            permission_path,
            self.direct_write_globs,
            self.deny_globs,
            allow_protected_paths=self.allow_protected_paths,
        )
        if not perm_result.allowed:
            return SkillResult(success=False, error=perm_result.reason, denied_paths=[path])

        file_path = self._resolve_path(path)

        # Check file exists
        if not file_path.exists():
            return SkillResult(success=False, error=f"File not found: {path}")

        # Read current content
        try:
            current_content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            return SkillResult(success=False, error=f"Failed to read file: {e}")

        # Count occurrences
        count = current_content.count(old_text)

        if count == 0:
            return SkillResult(success=False, error="Text not found in file")
        if count > 1:
            return SkillResult(
                success=False,
                error=f"Text found {count} times, must be unique for safe replacement",
            )

        # Perform replacement
        new_content = current_content.replace(old_text, new_text, 1)
        new_content = self._normalize_json_text_for_write(path, new_content)

        # Atomic write
        try:
            atomic_write_text(file_path, new_content)
            logger.info(f"edit_file: replaced text in {path}")
            return SkillResult(
                success=True,
                data={"path": str(file_path.resolve()), "replaced": True},
            )
        except Exception as e:
            return SkillResult(success=False, error=f"Failed to write file: {e}")

    def _skill_delete_file(self, args: dict[str, Any]) -> SkillResult:
        """Execute delete_file skill.

        Deletes a single file if path is in direct_write_globs.
        Cannot delete directories.
        """
        path = args.get("path", "")

        if not path:
            return SkillResult(success=False, error="path is required")

        # Check write permission (delete is a write operation)
        permission_path = self._path_for_permission(path)
        perm_result = check_write_permission(
            permission_path,
            self.direct_write_globs,
            self.deny_globs,
            allow_protected_paths=self.allow_protected_paths,
        )
        if not perm_result.allowed:
            return SkillResult(success=False, error=perm_result.reason, denied_paths=[path])

        file_path = self._resolve_path(path)

        if not file_path.exists():
            return SkillResult(success=False, error=f"File not found: {path}")

        if file_path.is_dir():
            return SkillResult(success=False, error=f"Cannot delete directory: {path}. Only files can be deleted.")

        try:
            file_path.unlink()
            logger.info(f"delete_file: deleted {path}")
            return SkillResult(
                success=True,
                data={"path": str(file_path.resolve()), "deleted": True},
            )
        except Exception as e:
            return SkillResult(success=False, error=f"Failed to delete file: {e}")

    def _skill_glob(self, args: dict[str, Any]) -> SkillResult:
        """Execute glob skill.

        Find files matching a glob pattern, filtered by read permissions.
        Max 200 results.
        """
        pattern = args.get("pattern", "")
        base_path = args.get("path", "")

        if not pattern:
            return SkillResult(success=False, error="pattern is required")

        # Reject path traversal in pattern
        if ".." in pattern:
            return SkillResult(success=False, error="Path traversal (..) not allowed in pattern")

        # Determine search root
        if base_path:
            if ".." in base_path:
                return SkillResult(success=False, error="Path traversal (..) not allowed in path")
            search_root = self.root / base_path
        else:
            search_root = self.root

        if not search_root.exists():
            return SkillResult(success=False, error=f"Path not found: {base_path or '.'}")

        # Collect matching files
        matches = []
        denied_paths = []
        max_results = 200

        try:
            # Path.glob() natively supports ** for recursive matching since Python 3.5
            file_iter = search_root.glob(pattern)

            for file_path in file_iter:
                if len(matches) >= max_results:
                    break

                if not file_path.is_file():
                    continue

                # Get relative path from project root
                try:
                    rel_path = str(file_path.relative_to(self.root)).replace("\\", "/")
                except ValueError:
                    continue

                # Check read permission
                perm_result = self._check_path_permission(rel_path)
                if perm_result.allowed:
                    matches.append(
                        {
                            "path": rel_path,
                            "size": file_path.stat().st_size,
                        }
                    )
                else:
                    denied_paths.append(rel_path)

        except Exception as e:
            return SkillResult(success=False, error=f"Glob error: {e}")

        return SkillResult(
            success=True,
            data={"files": matches, "count": len(matches), "capped": len(matches) >= max_results},
            denied_paths=denied_paths,
        )

    def _skill_import_sillytavern_card(self, args: dict[str, Any]) -> SkillResult:
        """Import a SillyTavern JSON/PNG card into game/character/."""
        source_path = args.get("path", "")
        entity_id = args.get("entity_id")
        target_path = str(args.get("target_path", "") or "").strip()
        name_override = str(args.get("name", "") or "").strip()

        if not source_path:
            return SkillResult(success=False, error="path is required")

        read_result = self._check_path_permission(source_path)
        if not read_result.allowed:
            return SkillResult(success=False, error=f"Permission denied for path: {source_path}", denied_paths=[source_path])

        resolved_source = self._resolve_path(source_path)
        if not resolved_source.exists():
            return SkillResult(success=False, error=f"File not found: {source_path}")

        data_dir = get_game_dir(self.root)
        normalized_entity_id = str(entity_id).strip() if entity_id is not None else None
        rel_path = ""
        target_kind = "character"
        target_entity_id = normalized_entity_id or None
        existing_ids: set[str] | None = None

        if target_path:
            normalized_target = target_path.replace("\\", "/").strip()
            if ".." in normalized_target.split("/"):
                return SkillResult(success=False, error="Path traversal (..) not allowed in target_path")
            if normalized_target.startswith("/"):
                return SkillResult(success=False, error="target_path must be project-relative under game/")
            if not normalized_target.startswith(f"{data_dir.name}/"):
                normalized_target = f"{data_dir.name}/{normalized_target.lstrip('/')}"
            target_parts = Path(normalized_target)
            parts = list(target_parts.parts)
            if len(parts) < 3 or parts[0] != data_dir.name or target_parts.suffix.lower() != ".json":
                return SkillResult(
                    success=False,
                    error=f"target_path must point to a JSON entity under {data_dir.name}/<kind>/<id>.json",
                )
            target_kind = parts[-2]
            target_entity_id = target_parts.stem
            if normalized_entity_id and normalized_entity_id != target_entity_id:
                return SkillResult(
                    success=False,
                    error=f"entity_id '{normalized_entity_id}' does not match target_path id '{target_entity_id}'",
                )
            if not is_valid_entity_id(target_entity_id):
                return SkillResult(
                    success=False,
                    error=f"Invalid target_path id '{target_entity_id}': must match pattern [a-z0-9._-]+",
                )
            rel_path = normalized_target
        else:
            target_dir = data_dir / "character"
            existing_ids = {path.stem for path in target_dir.glob("*.json")} if target_dir.exists() else set()

        try:
            entity = build_entity_from_card_file(
                resolved_source,
                entity_id=target_entity_id,
                existing_ids=existing_ids,
            )
        except ValueError as exc:
            return SkillResult(success=False, error=str(exc))

        entity["kind"] = target_kind
        if name_override:
            entity["name"] = name_override

        if not rel_path:
            rel_path = f"{data_dir.name}/character/{entity['id']}.json"

        permission_path = self._path_for_permission(rel_path)
        perm_result = check_write_permission(
            permission_path,
            self.direct_write_globs,
            self.deny_globs,
            allow_protected_paths=self.allow_protected_paths,
        )
        if not perm_result.allowed:
            return SkillResult(success=False, error=perm_result.reason, denied_paths=[rel_path])

        target_path = self._resolve_path(rel_path)
        try:
            atomic_write_text(target_path, json.dumps(entity, indent=2, ensure_ascii=False))
        except Exception as exc:
            return SkillResult(success=False, error=f"Failed to write imported card: {exc}")

        return SkillResult(
            success=True,
            data={
                "id": entity["id"],
                "name": entity["name"],
                "kind": entity["kind"],
                "path": str(target_path.resolve()),
                "source_path": str(resolved_source.resolve()),
                "tags_count": len(entity.get("tags", [])),
            },
        )

    def _skill_ensure_playable_scaffold(self, args: dict[str, Any]) -> SkillResult:
        """Ensure packaged play scaffold assets exist and active-agent state is canonical."""
        template_name = str(args.get("template_name", "") or DEFAULT_TEMPLATE_NAME).strip() or DEFAULT_TEMPLATE_NAME
        active_agent = str(args.get("active_agent", "") or "").strip() or None
        force = bool(args.get("force", False))

        try:
            scaffold_targets = list_playable_scaffold_targets(self.root, template_name=template_name)
        except Exception as exc:
            return SkillResult(success=False, error=f"Failed to inspect scaffold targets: {exc}")
        denied_paths: list[str] = []
        for rel_path in scaffold_targets:
            permission_path = self._path_for_permission(rel_path)
            perm_result = check_write_permission(
                permission_path,
                self.direct_write_globs,
                self.deny_globs,
                allow_protected_paths=self.allow_protected_paths,
            )
            if not perm_result.allowed:
                denied_paths.append(rel_path)

        if denied_paths:
            denied_list = ", ".join(denied_paths)
            return SkillResult(
                success=False,
                error=f"Write blocked by direct_write_globs/deny_globs for scaffold targets: {denied_list}",
                denied_paths=denied_paths,
            )

        try:
            result = ensure_playable_runtime_scaffold(
                self.root,
                template_name=template_name,
                force=force,
                active_agent_id=active_agent,
            )
        except Exception as exc:
            return SkillResult(success=False, error=f"Failed to ensure playable scaffold: {exc}")

        absolute_files = [str((self.root / rel_path).resolve()) for rel_path in result.files]
        return SkillResult(
            success=True,
            data={
                "path": str((self.root / result.active_agent_path).resolve()),
                "files": absolute_files,
                "relative_files": result.files,
                "active_agent": result.active_agent,
                "created_agent_ids": result.created_agent_ids,
            },
        )

    def _skill_grep(self, args: dict[str, Any]) -> SkillResult:
        """Execute grep skill.

        Search file contents using regex.
        Returns matching lines with file paths and line numbers.
        Max 50 results, lines truncated to 500 chars.
        """
        pattern = args.get("pattern", "")
        base_path = args.get("path", "")
        glob_pattern = args.get("glob", "**/*")
        max_results = args.get("max_results", 50)

        if not pattern:
            return SkillResult(success=False, error="pattern is required")

        # Compile regex
        try:
            regex = re.compile(pattern)
        except re.error as e:
            return SkillResult(success=False, error=f"Invalid regex pattern: {e}")

        # Reject path traversal
        if ".." in glob_pattern:
            return SkillResult(success=False, error="Path traversal (..) not allowed in glob")
        if base_path and ".." in base_path:
            return SkillResult(success=False, error="Path traversal (..) not allowed in path")

        # Determine search root
        if base_path:
            search_root = self.root / base_path
        else:
            search_root = self.root

        if not search_root.exists():
            return SkillResult(success=False, error=f"Path not found: {base_path or '.'}")

        # Collect matching lines
        results = []
        denied_paths = []
        max_line_length = 500

        try:
            # Get files matching glob
            for file_path in search_root.rglob(
                glob_pattern.replace("**/", "").replace("**", "*") if "**" in glob_pattern else glob_pattern
            ):
                if len(results) >= max_results:
                    break

                if not file_path.is_file():
                    continue

                # Get relative path
                try:
                    rel_path = str(file_path.relative_to(self.root)).replace("\\", "/")
                except ValueError:
                    continue

                # Check read permission
                perm_result = self._check_path_permission(rel_path)
                if not perm_result.allowed:
                    denied_paths.append(rel_path)
                    continue

                # Search file contents
                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    for line_num, line in enumerate(content.splitlines(), 1):
                        if len(results) >= max_results:
                            break
                        if regex.search(line):
                            # Truncate long lines
                            display_line = line[:max_line_length]
                            if len(line) > max_line_length:
                                display_line += "..."
                            results.append(
                                {
                                    "file": rel_path,
                                    "line_number": line_num,
                                    "line_content": display_line,
                                }
                            )
                except Exception:
                    # Skip files that can't be read
                    continue

        except Exception as e:
            return SkillResult(success=False, error=f"Grep error: {e}")

        return SkillResult(
            success=True,
            data={"matches": results, "count": len(results), "capped": len(results) >= max_results},
            denied_paths=denied_paths,
        )

    def _log_call(self, skill_name: str, args: dict[str, Any], result: SkillResult) -> None:
        """Log a skill call for auditing."""
        # Build result summary (bounded to 500 chars)
        if result.success:
            if isinstance(result.data, list):
                summary = f"Returned {len(result.data)} items"
            elif isinstance(result.data, dict):
                summary = f"Returned dict with keys: {list(result.data.keys())[:5]}"
            else:
                summary = str(result.data)[:500]
        else:
            summary = f"Error: {result.error}"

        call = SkillCall(
            timestamp=datetime.now(timezone.utc).isoformat(),
            run_id=self.run_id,
            agent_id=self.agent_id,
            skill_name=skill_name,
            args=args,
            result_summary=summary[:500],
            error=result.error,
            duration_ms=result.duration_ms,
            denied_paths=result.denied_paths,
        )

        self._calls.append(call)

    def save_audit_log(self) -> Path:
        """Save all skill calls to JSONL audit log.

        Returns:
            Path to the saved log file
        """
        logs_dir = get_neonrp_dir(self.root) / "logs" / "skills"
        logs_dir.mkdir(parents=True, exist_ok=True)

        log_path = logs_dir / f"{self.run_id}.jsonl"

        with open(log_path, "w", encoding="utf-8") as f:
            for call in self._calls:
                record = {
                    "timestamp": call.timestamp,
                    "run_id": call.run_id,
                    "agent_id": call.agent_id,
                    "skill_name": call.skill_name,
                    "args": call.args,
                    "result_summary": call.result_summary,
                    "error": call.error,
                    "duration_ms": call.duration_ms,
                    "denied_paths": call.denied_paths,
                }
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

        return log_path
