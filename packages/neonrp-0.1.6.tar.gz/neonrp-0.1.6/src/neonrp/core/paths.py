import re
from pathlib import Path

NEONRP_DIR_NAME = ".neonrp"
MANIFEST_FILENAME = "manifest.json"
DEFAULT_SCHEMA_FILENAME = "game_entity.schema.json"
RULES_DIR_NAME = "rules"
GAME_DIR_NAME = "game"


def get_project_root(cwd: Path | None = None) -> Path:
    """Find the project root (where .neonrp exists) or return cwd if creating new."""
    # Simplified for M0: Assumes current directory or simple lookup.
    # In M0 init, we construct it in CWD.
    if cwd is None:
        return Path.cwd()
    return cwd


def get_neonrp_dir(root: Path) -> Path:
    return root / NEONRP_DIR_NAME


def get_rules_dir(root: Path) -> Path:
    return root / RULES_DIR_NAME


def get_index_dir(root: Path) -> Path:
    return get_neonrp_dir(root) / "index"


def get_game_dir(root: Path) -> Path:
    """Get canonical game data directory."""
    return root / get_data_dir_name(root)


def get_data_dir_name(root: Path) -> str:
    """Return active game data directory name."""
    try:
        from neonrp.core.runtime_contract import load_runtime_contract

        return load_runtime_contract(root).data_dir
    except Exception:
        return GAME_DIR_NAME


def get_manifest_path(root: Path) -> Path:
    return get_neonrp_dir(root) / MANIFEST_FILENAME


_BRANCH_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]*$")


def validate_branch_name(name: str) -> str | None:
    """Validate a branch/sandbox name for filesystem safety.

    Returns None if valid, or an error message string if invalid.
    Rejects names containing path separators, traversal sequences,
    drive letters, or other unsafe patterns.
    """
    if not name:
        return "Branch name cannot be empty"

    # Reject path separators and traversal
    if "/" in name or "\\" in name:
        return "Branch name must not contain path separators ('/' or '\\\\')"

    if ".." in name:
        return "Branch name must not contain '..'"

    # Reject Windows drive letters (e.g., "C:")
    if len(name) >= 2 and name[1] == ":" and name[0].isalpha():
        return "Branch name must not contain drive letters"

    # Reject reserved names
    if name in (".", ".."):
        return "Branch name must not be '.' or '..'"

    # Must match safe pattern: alphanumeric start, then alphanumeric/dot/hyphen/underscore
    if not _BRANCH_NAME_RE.match(name):
        return "Branch name must start with alphanumeric and contain only alphanumeric, '.', '-', or '_'"

    # Reject excessively long names
    if len(name) > 128:
        return "Branch name must be 128 characters or fewer"

    return None


