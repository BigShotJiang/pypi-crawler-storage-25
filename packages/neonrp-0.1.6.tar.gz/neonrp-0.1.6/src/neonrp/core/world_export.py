"""Zip a worldlines game folder for sharing / backup.

The archive contains the whole game directory (including `.neonrp/` history
and event log). The sibling Claude Code workspace (`<name>-cc/`) is NOT
included — it's derivable from the templates and contains symlinks back into
the main game dir. On import, re-running `worldlines` in MCP mode regenerates it.
"""

from __future__ import annotations

import zipfile
from datetime import datetime
from pathlib import Path


def default_download_dir() -> Path:
    """Return a sensible default output directory for exports."""
    downloads = Path.home() / "Downloads"
    if downloads.is_dir():
        return downloads
    return Path.home()


def default_export_path(world_path: Path) -> Path:
    """Build a default zip file path from the world folder's name."""
    stem = world_path.name
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    return default_download_dir() / f"worldlines-{stem}-{ts}.zip"


# Directories we always skip inside a game folder — noise that would
# bloat the archive and isn't useful for restoring the world.
_EXCLUDE_DIR_NAMES = {
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    ".mypy_cache",
    ".pytest_cache",
}


def export_world(
    world_path: Path,
    output_path: Path | None = None,
    *,
    include_logs: bool = True,
) -> Path:
    """Zip a worldlines game folder. Returns the final archive path.

    Args:
        world_path: path to the game directory (must contain `.neonrp/`).
        output_path: destination .zip path; default = ~/Downloads/<auto>.zip.
        include_logs: when False, skip `.neonrp/logs/` to keep the archive small.

    Raises:
        FileNotFoundError: if world_path doesn't exist.
        ValueError: if world_path has no `.neonrp/` directory.
    """
    world_path = Path(world_path).expanduser().resolve()
    if not world_path.is_dir():
        raise FileNotFoundError(f"World directory not found: {world_path}")
    if not (world_path / ".neonrp").is_dir():
        raise ValueError(f"Not a worldlines game (missing .neonrp/): {world_path}")

    output_path = Path(output_path).expanduser().resolve() if output_path else default_export_path(world_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    arc_root = world_path.name

    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for entry in world_path.rglob("*"):
            if any(part in _EXCLUDE_DIR_NAMES for part in entry.relative_to(world_path).parts):
                continue
            if not include_logs and ".neonrp/logs" in entry.relative_to(world_path).as_posix():
                continue
            if entry.is_symlink() or not entry.is_file():
                continue
            rel = entry.relative_to(world_path)
            zf.write(entry, arcname=str(Path(arc_root) / rel))

    return output_path


def summarize_archive(archive_path: Path) -> dict:
    """Return a small summary of an exported archive (for display)."""
    archive_path = Path(archive_path)
    size_bytes = archive_path.stat().st_size
    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            count = len(zf.namelist())
    except Exception:
        count = -1
    return {
        "path": str(archive_path),
        "size_bytes": size_bytes,
        "size_mb": round(size_bytes / (1024 * 1024), 2),
        "file_count": count,
    }


def load_world_zip(
    zip_path: Path,
    games_dir: Path | None = None,
    *,
    overwrite: bool = False,
) -> Path:
    """Extract an exported world zip into `~/.worldlines/games/`.

    The archive produced by `export_world` has a single top-level folder
    (the original world dir name). We preserve that name unless the target
    already exists — then we append a timestamp suffix to avoid clobbering.

    Args:
        zip_path: path to the .zip produced by export_world.
        games_dir: destination games root (default: ~/.worldlines/games).
        overwrite: if True and target exists, replace it; otherwise suffix.

    Returns:
        Path to the extracted game folder.

    Raises:
        FileNotFoundError: if zip_path doesn't exist.
        ValueError: if the archive isn't a valid worldlines export.
    """
    import shutil

    zip_path = Path(zip_path).expanduser().resolve()
    if not zip_path.is_file():
        raise FileNotFoundError(f"Zip not found: {zip_path}")

    if games_dir is None:
        from neonrp.worlds import GAME_HOME

        games_dir = GAME_HOME
    games_dir = Path(games_dir).expanduser()
    games_dir.mkdir(parents=True, exist_ok=True)

    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            members = zf.namelist()
            if not members:
                raise ValueError("Zip is empty")
            # Detect the single top-level dir from the archive.
            top_levels = {m.split("/", 1)[0] for m in members if m.strip("/")}
            if len(top_levels) != 1:
                raise ValueError(
                    f"Expected exactly one top-level folder in the archive, got {len(top_levels)}"
                )
            arc_root = next(iter(top_levels))

            # Pre-flight: the archive must have a `<arc_root>/.neonrp/manifest.json`
            # to qualify as a worldlines export.
            expected = f"{arc_root}/.neonrp/manifest.json"
            if not any(m == expected or m.startswith(expected) for m in members):
                raise ValueError(
                    "Archive does not look like a worldlines export "
                    "(missing .neonrp/manifest.json)."
                )

            target = games_dir / arc_root
            if target.exists():
                if overwrite:
                    shutil.rmtree(target)
                else:
                    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
                    target = games_dir / f"{arc_root}-restored-{ts}"

            # Archive's entries are `<arc_root>/...` — extracting into
            # `games_dir` lays them down as `games_dir/<arc_root>/...`.
            zf.extractall(games_dir)
            extracted = games_dir / arc_root
            if extracted != target:
                shutil.move(str(extracted), target)
    except zipfile.BadZipFile as exc:
        raise ValueError(f"Not a valid zip: {exc}")

    return target
