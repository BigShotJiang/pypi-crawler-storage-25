"""WorldLines model presets.

Each preset generates a config.json compatible with NeonRP's
``models`` registry + ``model_ref`` system (zero modifications needed).

Presets come from two sources:
1. Built-in PRESETS dict (standard providers: openai, anthropic, glm)
2. User's ~/.neonrp/config.json ``models`` section (custom/local endpoints)
3. "claude-code" virtual preset (detected if ``claude`` CLI is on PATH)
"""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any

# Special preset ID for Claude Code MCP mode
CLAUDE_CODE_PRESET_ID = "claude-code"


PRESETS: dict[str, dict[str, Any]] = {
    "anthropic": {
        "display": "Anthropic Claude",
        "provider": "anthropic",
        "model": "claude-sonnet-4-6",
        "api_key_env": "ANTHROPIC_API_KEY",
        "key_hint": "console.anthropic.com/settings/keys",
        "temperature": 0.7,
        "max_output_tokens": 4096,
    },
    "openai": {
        "display": "OpenAI GPT",
        "provider": "openai",
        "model": "gpt-4o",
        "api_key_env": "OPENAI_API_KEY",
        "key_hint": "platform.openai.com/api-keys",
        "temperature": 0.7,
        "max_output_tokens": 4096,
    },
    "deepseek": {
        "display": "DeepSeek",
        "provider": "openai",
        "model": "deepseek-chat",
        "base_url": "https://api.deepseek.com/v1",
        "api_key_env": "DEEPSEEK_API_KEY",
        "key_hint": "platform.deepseek.com/api_keys",
        "temperature": 0.7,
        "max_output_tokens": 4096,
    },
    "openrouter": {
        "display": "OpenRouter",
        "provider": "openai",
        "model": "anthropic/claude-sonnet-4.5",
        "base_url": "https://openrouter.ai/api/v1",
        "api_key_env": "OPENROUTER_API_KEY",
        "key_hint": "openrouter.ai/keys",
        "temperature": 0.7,
        "max_output_tokens": 4096,
    },
    "glm": {
        "display": "GLM-4-Flash (free)",
        "provider": "openai",
        "model": "glm-4-flash",
        "base_url": "https://open.bigmodel.cn/api/paas/v4",
        "api_key_env": "GLM_API_KEY",
        "key_hint": "zhipuai.cn",
        "temperature": 0.85,
        "max_output_tokens": 4096,
    },
    # Legacy alias kept for existing user configs; same thing as "anthropic".
    "opus": {
        "display": "Claude Opus (legacy alias)",
        "provider": "anthropic",
        "model": "claude-opus-4-6",
        "api_key_env": "ANTHROPIC_API_KEY",
        "key_hint": "console.anthropic.com/settings/keys",
        "temperature": 0.7,
        "max_output_tokens": 4096,
    },
}

# Provider TYPES offered in "Add new" flow.
# Each entry is the starting template for a new user-config entry.
PROVIDER_TYPES: list[dict[str, Any]] = [
    {
        "id": "anthropic",
        "label": "Anthropic (Claude)",
        "provider": "anthropic",
        "default_model": "claude-sonnet-4-6",
        "models": ["claude-opus-4-6", "claude-sonnet-4-6", "claude-haiku-4-5-20251001"],
        "base_url": None,
        "api_key_env": "ANTHROPIC_API_KEY",
        "key_hint": "console.anthropic.com/settings/keys",
    },
    {
        "id": "openai",
        "label": "OpenAI (GPT)",
        "provider": "openai",
        "default_model": "gpt-4o",
        "models": ["gpt-4o", "gpt-4-turbo", "gpt-4.1", "o1", "o3"],
        "base_url": None,
        "api_key_env": "OPENAI_API_KEY",
        "key_hint": "platform.openai.com/api-keys",
    },
    {
        "id": "deepseek",
        "label": "DeepSeek",
        "provider": "openai",
        "default_model": "deepseek-chat",
        "models": ["deepseek-chat", "deepseek-reasoner"],
        "base_url": "https://api.deepseek.com/v1",
        "api_key_env": "DEEPSEEK_API_KEY",
        "key_hint": "platform.deepseek.com/api_keys",
    },
    {
        "id": "openrouter",
        "label": "OpenRouter",
        "provider": "openai",
        "default_model": "anthropic/claude-sonnet-4.5",
        "models": [m["id"] for m in [
            {"id": "anthropic/claude-sonnet-4.5"},
            {"id": "anthropic/claude-opus-4.1"},
            {"id": "openai/gpt-4o"},
            {"id": "google/gemini-2.5-pro"},
            {"id": "deepseek/deepseek-chat"},
            {"id": "meta-llama/llama-3.3-70b-instruct"},
        ]],
        "base_url": "https://openrouter.ai/api/v1",
        "api_key_env": "OPENROUTER_API_KEY",
        "key_hint": "openrouter.ai/keys",
        "fetch_catalog": True,
    },
    {
        "id": "custom",
        "label": "Custom (OpenAI-compatible endpoint)",
        "provider": "openai",
        "default_model": "",
        "models": [],
        "base_url": "",
        "api_key_env": None,
        "key_hint": "",
    },
    {
        "id": "mcp",
        "label": "Claude Code (MCP)",
        "provider": "mcp",
        "default_model": "claude-code-mcp",
        "models": [],
        "base_url": None,
        "api_key_env": None,
        "key_hint": "Install the `claude` CLI from anthropic.com/claude-code",
    },
]


def get_provider_type(type_id: str) -> dict[str, Any] | None:
    for entry in PROVIDER_TYPES:
        if entry["id"] == type_id:
            return entry
    return None


# ---------------------------------------------------------------------------
# Config health test — small API ping per provider type.
# ---------------------------------------------------------------------------

def test_preset(preset_id: str, *, timeout: float = 6.0) -> dict[str, Any]:
    """Send a tiny "say ok" request to the preset's endpoint.

    Returns a dict with:
        ok        — bool
        latency_ms— int (only when ok)
        error     — str  (only when not ok; short human-readable label)
        provider  — str  (for display)
        model     — str  (for display)
    """
    import time

    if preset_id == CLAUDE_CODE_PRESET_ID:
        return _test_claude_code()

    entry = _resolve_effective_entry(preset_id)
    if entry is None:
        return {"ok": False, "error": f"Unknown preset: {preset_id}"}

    provider = str(entry.get("provider", "")).lower()
    model = str(entry.get("model", "") or "").strip()
    api_key = str(entry.get("api_key", "") or "").strip()

    if not api_key and entry.get("api_key_env"):
        api_key = os.environ.get(entry["api_key_env"], "").strip()

    # Short-circuit fail fast — don't burn the timeout on entries we know
    # can't authenticate.
    if not api_key and provider != "stub":
        return {"ok": False, "provider": provider, "model": model, "error": "no API key configured"}

    start = time.time()
    try:
        if provider == "anthropic":
            ok, err = _ping_anthropic(api_key, model, timeout)
        elif provider == "openai":
            ok, err = _ping_openai_compatible(
                api_key,
                model,
                str(entry.get("base_url", "") or "https://api.openai.com/v1"),
                timeout,
            )
        elif provider == "stub":
            ok, err = True, None
        else:
            return {"ok": False, "provider": provider, "model": model, "error": f"unsupported provider: {provider}"}
    except Exception as exc:
        return {
            "ok": False,
            "provider": provider,
            "model": model,
            "error": _clean_network_error(exc),
        }

    elapsed = int((time.time() - start) * 1000)
    if not ok:
        return {
            "ok": False,
            "provider": provider,
            "model": model,
            "error": err or "unknown error",
            "latency_ms": elapsed,
        }
    return {"ok": True, "provider": provider, "model": model, "latency_ms": elapsed}


def _resolve_effective_entry(preset_id: str) -> dict[str, Any] | None:
    """Merge built-in PRESETS defaults with user-config overrides."""
    merged: dict[str, Any] = {}
    if preset_id in PRESETS:
        merged.update(PRESETS[preset_id])
    user_models = _load_user_config_models()
    if preset_id in user_models:
        merged.update(user_models[preset_id])
    return merged or None


def _clean_network_error(exc: Exception) -> str:
    """Turn raw urllib / socket errors into short human-readable labels."""
    import socket

    msg = str(exc) or exc.__class__.__name__
    if isinstance(exc, (TimeoutError, socket.timeout)):
        return "timeout"
    if "timed out" in msg.lower() or "timeout" in msg.lower():
        return "timeout"
    if "getaddrinfo failed" in msg.lower() or "name or service not known" in msg.lower():
        return "DNS failed (check network / base_url)"
    if "connection refused" in msg.lower():
        return "connection refused"
    if "ssl" in msg.lower() and "verify" in msg.lower():
        return "TLS verification failed"
    return msg[:200]


def _ping_anthropic(api_key: str, model: str, timeout: float) -> tuple[bool, str | None]:
    import urllib.request
    import urllib.error

    body = json.dumps(
        {
            "model": model or "claude-haiku-4-5-20251001",
            "max_tokens": 8,
            "messages": [{"role": "user", "content": "ok"}],
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        if isinstance(payload, dict) and payload.get("type") == "message":
            return True, None
        return False, f"unexpected response: {str(payload)[:160]}"
    except urllib.error.HTTPError as e:
        body_text = ""
        try:
            body_text = e.read().decode("utf-8", "ignore")[:200]
        except Exception:
            pass
        return False, f"HTTP {e.code}: {body_text}"
    except Exception as exc:
        return False, _clean_network_error(exc)


def _ping_openai_compatible(api_key: str, model: str, base_url: str, timeout: float) -> tuple[bool, str | None]:
    import urllib.request
    import urllib.error

    url = base_url.rstrip("/") + "/chat/completions"
    body = json.dumps(
        {
            "model": model,
            "max_tokens": 8,
            "messages": [{"role": "user", "content": "say ok"}],
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        if isinstance(payload, dict) and "choices" in payload:
            return True, None
        return False, f"unexpected response: {str(payload)[:160]}"
    except urllib.error.HTTPError as e:
        body_text = ""
        try:
            body_text = e.read().decode("utf-8", "ignore")[:200]
        except Exception:
            pass
        return False, f"HTTP {e.code}: {body_text}"
    except Exception as exc:
        return False, _clean_network_error(exc)


def _test_claude_code() -> dict[str, Any]:
    import shutil as _shutil

    path = _shutil.which("claude")
    if not path:
        return {
            "ok": False,
            "provider": "mcp",
            "model": "claude-code-mcp",
            "error": "`claude` CLI not found on PATH",
        }
    return {"ok": True, "provider": "mcp", "model": "claude-code-mcp", "latency_ms": 0, "detail": path}

# Providers for which users may want to pick a specific model at preset time.
# Maps preset_id -> (models_endpoint, suggested curated models).
OPENROUTER_MODELS_URL = "https://openrouter.ai/api/v1/models"
OPENROUTER_SUGGESTED_MODELS: list[dict[str, str]] = [
    {"id": "anthropic/claude-sonnet-4.5", "label": "Claude Sonnet 4.5 (默认)"},
    {"id": "anthropic/claude-opus-4.1", "label": "Claude Opus 4.1"},
    {"id": "openai/gpt-4o", "label": "GPT-4o"},
    {"id": "google/gemini-2.5-pro", "label": "Gemini 2.5 Pro"},
    {"id": "deepseek/deepseek-chat", "label": "DeepSeek Chat"},
    {"id": "meta-llama/llama-3.3-70b-instruct", "label": "Llama 3.3 70B"},
]

# Model name fragments that indicate a pure embedding model (skip from chat preset list)
_EMBEDDING_FRAGMENTS = ("embedding", "embed")

_USER_CONFIG_PATH = Path.home() / ".neonrp" / "config.json"


# ---------------------------------------------------------------------------
# User config helpers
# ---------------------------------------------------------------------------

def _load_user_config_models() -> dict[str, dict[str, Any]]:
    """Read the ``models`` section from ~/.neonrp/config.json."""
    try:
        if not _USER_CONFIG_PATH.exists():
            return {}
        data = json.loads(_USER_CONFIG_PATH.read_text(encoding="utf-8"))
        raw = data.get("models", {})
        return {k: v for k, v in raw.items() if isinstance(v, dict)} if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _save_key_to_user_config(preset_id: str, key: str, *, model_override: str | None = None) -> None:
    """Persist an API key for a built-in preset into ~/.neonrp/config.json."""
    try:
        if _USER_CONFIG_PATH.exists():
            data = json.loads(_USER_CONFIG_PATH.read_text(encoding="utf-8"))
        else:
            data = {}

        if "models" not in data or not isinstance(data["models"], dict):
            data["models"] = {}

        # Create or update the model entry with the key
        preset = PRESETS.get(preset_id, {})
        entry = data["models"].get(preset_id, {})
        entry.update({
            "provider": preset.get("provider", entry.get("provider", "")),
            "model": model_override or preset.get("model", entry.get("model", "")),
            "api_key": key,
        })
        if preset.get("base_url"):
            entry["base_url"] = preset["base_url"]
        data["models"][preset_id] = entry

        _USER_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        _USER_CONFIG_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def fetch_openrouter_models(api_key: str, *, timeout: float = 6.0) -> list[dict[str, str]]:
    """Fetch the OpenRouter model catalog. Returns [] on any failure."""
    try:
        import urllib.request

        req = urllib.request.Request(
            OPENROUTER_MODELS_URL,
            headers={"Authorization": f"Bearer {api_key}", "User-Agent": "neonrp"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        items = payload.get("data", []) if isinstance(payload, dict) else []
        result: list[dict[str, str]] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            model_id = str(item.get("id", "")).strip()
            if not model_id:
                continue
            name = str(item.get("name") or model_id).strip()
            result.append({"id": model_id, "label": name})
        return result
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Key availability
# ---------------------------------------------------------------------------

def _preset_key_available(preset_id: str) -> bool:
    """Return True if the API key for this built-in preset is already configured."""
    info = PRESETS.get(preset_id, {})

    # Direct key in PRESETS (shouldn't happen for built-ins, defensive)
    if info.get("api_key"):
        return True

    # Environment variable
    api_key_env = info.get("api_key_env", "")
    if api_key_env and os.environ.get(api_key_env):
        return True

    # Previously saved in user config
    user_models = _load_user_config_models()
    if preset_id in user_models and user_models[preset_id].get("api_key"):
        return True

    return False


def _user_model_key_available(model_data: dict[str, Any]) -> bool:
    """Return True if a user-config model has a usable API key."""
    if model_data.get("api_key"):
        return True
    api_key_env = model_data.get("api_key_env", "")
    return bool(api_key_env and os.environ.get(api_key_env))


def _is_embedding_model(model_id: str, model_data: dict[str, Any]) -> bool:
    combined = (model_id + " " + model_data.get("model", "")).lower()
    return any(frag in combined for frag in _EMBEDDING_FRAGMENTS)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def is_claude_code_available() -> bool:
    """Return True if the ``claude`` CLI is installed and authenticated."""
    return shutil.which("claude") is not None


def is_claude_code_preset(preset_id: str) -> bool:
    """Return True if this preset triggers MCP mode (Claude Code as backend)."""
    return preset_id == CLAUDE_CODE_PRESET_ID


def list_presets() -> list[dict[str, Any]]:
    """Return display-friendly preset list (built-in + user config + Claude Code).

    Each entry:
    - ``id``:              identifier for build_config_dict / /wl-model
    - ``display``:         human label (includes ✓ if key found)
    - ``available``:       True if API key detected
    - ``from_user_config``: True if sourced from ~/.neonrp/config.json
    """
    result: list[dict[str, Any]] = []

    # Claude Code (MCP mode) — shown first if available
    if is_claude_code_available():
        result.append({
            "id": CLAUDE_CODE_PRESET_ID,
            "display": "Claude Opus (Claude Code) ✓",
            "available": True,
            "from_user_config": False,
        })

    for preset_id, info in PRESETS.items():
        available = _preset_key_available(preset_id)
        badge = " ✓" if available else ""
        result.append({
            "id": preset_id,
            "display": f"{info['display']}{badge}",
            "available": available,
            "from_user_config": False,
        })

    user_models = _load_user_config_models()
    for model_id, model_data in user_models.items():
        if model_id in ("stub", *PRESETS):
            continue
        if _is_embedding_model(model_id, model_data):
            continue
        available = _user_model_key_available(model_data)
        badge = " ✓" if available else ""
        # Caller appends the localized "[custom]" tag via
        # `from_user_config` — kept out of display so the label is
        # locale-agnostic at this layer.
        result.append({
            "id": model_id,
            "display": f"{model_id}{badge}",
            "available": available,
            "from_user_config": True,
        })

    return result


def first_custom_entry_example() -> str:
    """Pick a concrete example `entry_id` for the Add-custom prompt.

    Prefers a real entry the user already has in `~/.neonrp/config.json`
    (so the prompt's example matches their own naming habit). Falls
    back to a common nickname when the user has no custom entries yet.
    """
    try:
        user_models = _load_user_config_models()
        for model_id, data in user_models.items():
            if model_id in PRESETS or model_id == "stub":
                continue
            if _is_embedding_model(model_id, data):
                continue
            return model_id
    except Exception:
        pass
    return "qwen"


def ensure_preset_key(preset_id: str) -> bool:
    """Ensure the API key for *preset_id* is available, prompting if needed.

    For built-in presets without a configured key, interactively asks the user
    to paste their key and saves it to ~/.neonrp/config.json for future use.

    Returns:
        True  – key is available (was already set, or user just entered it)
        False – user skipped / left blank (caller should abort or go back)
    """
    import click

    # User-config models are assumed to have their own key already
    if preset_id not in PRESETS:
        return True

    if _preset_key_available(preset_id):
        return True

    from neonrp.tui.i18n import get_message, resolve_locale

    locale = resolve_locale()

    info = PRESETS[preset_id]
    api_key_env = info.get("api_key_env", "")
    key_hint = info.get("key_hint", "")

    click.echo()
    click.echo("  " + get_message(locale, "preset.api_key_needed").format(display=info["display"]))
    if key_hint:
        click.echo("  " + get_message(locale, "preset.api_key_get_at").format(url=key_hint))
    click.echo()

    raw = click.prompt("  " + get_message(locale, "prompt.api_key"), default="", show_default=False).strip()
    if not raw:
        return False

    model_override: str | None = None
    if preset_id == "openrouter":
        model_override = _prompt_openrouter_model(raw)

    # Persist to user config
    _save_key_to_user_config(preset_id, raw, model_override=model_override)

    # Also set in current process env so it's immediately usable
    if api_key_env:
        os.environ[api_key_env] = raw

    click.echo("  " + get_message(locale, "preset.api_key_saved"))
    return True


def _prompt_openrouter_model(api_key: str) -> str | None:
    """Offer the user a curated list + optional full catalog for OpenRouter."""
    import click

    click.echo()
    click.echo("  OpenRouter 模型选择：")
    options: list[dict[str, str]] = list(OPENROUTER_SUGGESTED_MODELS)

    for idx, item in enumerate(options, 1):
        click.echo(f"    {idx}. {item['label']}  [{item['id']}]")
    fetch_idx = len(options) + 1
    custom_idx = len(options) + 2
    click.echo(f"    {fetch_idx}. 拉取完整模型列表")
    click.echo(f"    {custom_idx}. 手动输入 model id")

    raw = click.prompt("  选择（留空=默认第1项）", default="1", show_default=False).strip()
    if not raw:
        return None
    try:
        choice = int(raw)
    except ValueError:
        return None

    if 1 <= choice <= len(options):
        return options[choice - 1]["id"]
    if choice == fetch_idx:
        catalog = fetch_openrouter_models(api_key)
        if not catalog:
            click.echo("  未能拉取模型列表，使用默认。")
            return None
        return _prompt_from_catalog(catalog)
    if choice == custom_idx:
        typed = click.prompt("  model id", default="", show_default=False).strip()
        return typed or None
    return None


def _prompt_from_catalog(catalog: list[dict[str, str]]) -> str | None:
    """Show a paginated catalog and let user pick by number or substring."""
    import click

    total = len(catalog)
    click.echo(f"  共 {total} 个模型，输入关键字过滤（回车显示前 30 个）：")
    keyword = click.prompt("  关键字", default="", show_default=False).strip().lower()
    filtered = [m for m in catalog if keyword in m["id"].lower() or keyword in m["label"].lower()] if keyword else catalog

    shown = filtered[:30]
    if not shown:
        click.echo("  没有匹配项。")
        return None
    for idx, item in enumerate(shown, 1):
        click.echo(f"    {idx}. {item['label']}  [{item['id']}]")
    raw = click.prompt("  选择编号（留空取消）", default="", show_default=False).strip()
    if not raw:
        return None
    try:
        choice = int(raw)
    except ValueError:
        return None
    if 1 <= choice <= len(shown):
        return shown[choice - 1]["id"]
    return None


def build_config_dict(preset_id: str) -> dict[str, Any]:
    """Build a complete NeonRP config.json dict for the given preset or user model.

    The output is directly compatible with NeonRP's config system:
    - ``llm.model_ref`` selects the active model
    - ``models`` section registers the named model
    """
    # Claude Code virtual preset — scaffold only, LLM handled by claude CLI
    if preset_id == CLAUDE_CODE_PRESET_ID:
        return {
            "llm": {"model_ref": "stub"},
            "tui": {"narrator_agent_id": "narrator"},
            "rules": {},
            "models": {"stub": {"provider": "stub", "model": "claude-code-mcp"}},
            "mcp_servers": {},
        }

    # Built-in preset
    if preset_id in PRESETS:
        preset = PRESETS[preset_id]
        model_entry: dict[str, Any] = {
            "provider": preset["provider"],
            "model": preset["model"],
            "temperature": preset.get("temperature", 0.7),
            "max_output_tokens": preset.get("max_output_tokens", 4096),
        }
        if preset.get("base_url"):
            model_entry["base_url"] = preset["base_url"]

        # Prefer saved key from user config over env var reference
        user_models = _load_user_config_models()
        saved_key = user_models.get(preset_id, {}).get("api_key", "")
        if saved_key:
            model_entry["api_key"] = saved_key
        elif preset.get("api_key_env"):
            model_entry["api_key_env"] = preset["api_key_env"]

        return {
            "llm": {"model_ref": preset_id},
            "tui": {"narrator_agent_id": "narrator"},
            "rules": {},
            "models": {preset_id: model_entry},
            "mcp_servers": {},
        }

    # User-config model
    user_models = _load_user_config_models()
    if preset_id in user_models:
        return {
            "llm": {"model_ref": preset_id},
            "tui": {"narrator_agent_id": "narrator"},
            "rules": {},
            "models": {preset_id: dict(user_models[preset_id])},
            "mcp_servers": {},
        }

    raise KeyError(f"Unknown preset or model: {preset_id!r}")
