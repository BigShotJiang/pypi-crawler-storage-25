"""Validate command for NeonRP CLI."""

import json
import sys

import click

from neonrp.core.paths import get_project_root
from neonrp.core.validation import ValidationIssue, load_schema, validate_game_data


@click.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def validate(as_json: bool) -> None:
    """Validate game data against schema and constraints."""
    root = get_project_root()

    try:
        schema = load_schema(root)
    except FileNotFoundError as e:
        if as_json:
            click.echo(json.dumps({"error": str(e), "code": "schema_missing"}, ensure_ascii=False))
        else:
            click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    except Exception as e:
        if as_json:
            click.echo(json.dumps({"error": str(e), "code": "system_error"}, ensure_ascii=False))
        else:
            click.echo(f"System error: {e}", err=True)
        sys.exit(2)

    try:
        issues, entities = validate_game_data(root, schema)
    except Exception as e:
        if as_json:
            click.echo(json.dumps({"error": str(e), "code": "io_error"}, ensure_ascii=False))
        else:
            click.echo(f"IO error: {e}", err=True)
        sys.exit(2)

    if as_json:
        output = {
            "ok": len(issues) == 0,
            "files_ok": len(entities),
            "files_failed": _count_unique_files(issues),
            "issues": [issue.to_dict() for issue in issues],
        }
        click.echo(json.dumps(output, indent=2, ensure_ascii=False))
    else:
        if issues:
            click.echo(f"Validation failed with {len(issues)} issue(s):\n")
            for issue in issues:
                click.echo(f"  [{issue.layer}] {issue.file}")
                click.echo(f"    Path: {issue.path}")
                click.echo(f"    Code: {issue.code}")
                click.echo(f"    Message: {issue.message}")
                click.echo(f"    Suggestion: {issue.suggestion}")
                click.echo()
        else:
            click.echo(f"Validation passed. {len(entities)} file(s) OK.")

    sys.exit(1 if issues else 0)


def _count_unique_files(issues: list[ValidationIssue]) -> int:
    return len(set(issue.file for issue in issues))

