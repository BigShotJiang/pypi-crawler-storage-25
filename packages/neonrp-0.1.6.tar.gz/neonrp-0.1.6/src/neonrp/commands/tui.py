"""TUI CLI command entry point."""

from pathlib import Path
import shlex

import click

@click.command()
@click.option("--branch", default=None, help="Branch to use (default: current branch)")
@click.option("--provider", default=None, help="LLM provider override (default: from config)")
@click.option("--continue", "continue_session", is_flag=True, help="Continue the previous session on startup")
@click.option("--new", "new_session", is_flag=True, help="Start a brand new session on startup (default)")
@click.option("--import-card", "import_card", type=click.Path(exists=True), help="Import a SillyTavern JSON/PNG card on startup")
@click.option("--import-id", "import_id", default=None, help="Override imported entity ID for --import-card")
@click.option("--verbose", is_flag=True, help="Enable verbose debug mode (extra logs and on-screen diagnostics)")
@click.option("--mcp", "mcp_mode", is_flag=True, help="Start as MCP server for Claude Code")
def tui(
    branch: str | None,
    provider: str | None,
    continue_session: bool,
    new_session: bool,
    import_card: str | None,
    import_id: str | None,
    verbose: bool,
    mcp_mode: bool,
):
    """Launch the NeonRP Terminal User Interface.

    The TUI provides a Claude Code/OpenCode-style workflow for:
    - Running agents and previewing diffs
    - Browsing files and logs
    - Managing sandboxes and saves
    """
    if continue_session and new_session:
        click.echo("Error: --continue and --new cannot be used together.", err=True)
        raise SystemExit(1)
    if import_id and not import_card:
        click.echo("Error: --import-id requires --import-card.", err=True)
        raise SystemExit(1)

    startup_commands: list[str] = []
    if import_card:
        quoted_path = shlex.quote(import_card)
        command = f"/import sillytavern-card {quoted_path}"
        if import_id:
            command += f" --id {shlex.quote(import_id)}"
        startup_commands.append(command)

    # Use conversational TUI.
    # Intentionally allow non-initialized directories so users can run /init inside TUI.
    from neonrp.tui.app import run_tui

    run_tui(
        root=Path.cwd(),
        branch=branch,
        provider=provider,
        continue_session=continue_session and not new_session,
        startup_commands=startup_commands,
        verbose=verbose,
        mode="mcp" if mcp_mode else "build",
    )
