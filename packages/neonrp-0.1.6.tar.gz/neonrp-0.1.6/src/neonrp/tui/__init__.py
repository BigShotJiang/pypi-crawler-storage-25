"""NeonRP TUI package."""
