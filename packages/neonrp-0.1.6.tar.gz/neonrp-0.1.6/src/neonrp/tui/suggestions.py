"""Inline slash command suggestions widget (Claude Code style)."""

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import Static
from textual.reactive import reactive
from textual.message import Message

from neonrp.tui.commands import COMMANDS, get_command_suggestions, get_command_args_hint


class SuggestionItem(Static):
    """A single suggestion item."""

    DEFAULT_CSS = """
    SuggestionItem {
        height: 1;
        width: 100%;
        padding: 0 1;
    }
    SuggestionItem.selected {
        background: $primary;
        color: $text;
    }
    """

    def __init__(self, command: str, description: str, selected: bool = False) -> None:
        super().__init__()
        self.command = command
        self.description = description
        if selected:
            self.add_class("selected")

    def compose(self) -> ComposeResult:
        """Render the suggestion."""
        yield Static(f"[cyan]/{self.command}[/]  [dim]{self.description}[/]")


class SlashSuggestions(Vertical):
    """Inline suggestion dropdown for slash commands."""

    DEFAULT_CSS = """
    SlashSuggestions {
        height: auto;
        max-height: 12;
        width: 100%;
        background: $surface;
        border: solid $primary;
        display: none;
        layer: suggestions;
        dock: bottom;
        offset-y: -1;
    }
    SlashSuggestions.visible {
        display: block;
    }
    SlashSuggestions .suggestion-hint {
        height: 1;
        padding: 0 1;
        background: $surface-darken-1;
        color: $text-muted;
    }
    """

    selected_index: reactive[int] = reactive(0)
    filter_text: reactive[str] = reactive("")

    class CommandSelected(Message):
        """Sent when a command is selected."""

        def __init__(self, command: str, args_hint: str) -> None:
            super().__init__()
            self.command = command
            self.args_hint = args_hint

    class CommandCompleted(Message):
        """Sent when Tab is pressed to complete command."""

        def __init__(self, command: str, args_hint: str) -> None:
            super().__init__()
            self.command = command
            self.args_hint = args_hint

    def __init__(self) -> None:
        super().__init__()
        self.suggestions: list[tuple[str, str, str]] = []  # (command, description, args_hint)

    def compose(self) -> ComposeResult:
        """Compose the suggestions panel."""
        yield Static("[dim]↑↓ navigate · Tab complete · Enter select · Esc cancel[/]", classes="suggestion-hint")

    def show_suggestions(self, filter_text: str = "") -> None:
        """Show suggestions filtered by text."""
        self.filter_text = filter_text
        self.selected_index = 0
        self._refresh_suggestions()
        self.add_class("visible")

    def hide(self) -> None:
        """Hide the suggestions panel."""
        self.remove_class("visible")

    def _refresh_suggestions(self) -> None:
        """Refresh the suggestion list."""
        # Clear existing items (except hint)
        for child in list(self.children):
            if isinstance(child, SuggestionItem):
                child.remove()

        # Get matching commands
        matching = get_command_suggestions(self.filter_text)
        self.suggestions = []

        for cmd in matching[:10]:  # Limit to 10
            spec = COMMANDS.get(cmd, {})
            desc = spec.get("help", "")
            args_hint = get_command_args_hint(cmd, spec)

            self.suggestions.append((cmd, desc, args_hint))

        # Mount new items
        for i, (cmd, desc, _) in enumerate(self.suggestions):
            item = SuggestionItem(cmd, desc, selected=(i == self.selected_index))
            self.mount(item)

    def watch_selected_index(self, old: int, new: int) -> None:
        """Update visual selection when index changes."""
        items = [c for c in self.children if isinstance(c, SuggestionItem)]
        for i, item in enumerate(items):
            if i == new:
                item.add_class("selected")
            else:
                item.remove_class("selected")

    def move_selection(self, delta: int) -> None:
        """Move selection up or down."""
        if not self.suggestions:
            return
        new_index = (self.selected_index + delta) % len(self.suggestions)
        self.selected_index = new_index

    def get_selected(self) -> tuple[str, str] | None:
        """Get the currently selected command and args hint."""
        if 0 <= self.selected_index < len(self.suggestions):
            cmd, _, args_hint = self.suggestions[self.selected_index]
            return cmd, args_hint
        return None

    def select_current(self) -> None:
        """Select the current suggestion (Enter)."""
        result = self.get_selected()
        if result:
            cmd, args_hint = result
            self.post_message(self.CommandSelected(cmd, args_hint))
            self.hide()

    def complete_current(self) -> None:
        """Complete the current suggestion (Tab)."""
        result = self.get_selected()
        if result:
            cmd, args_hint = result
            self.post_message(self.CommandCompleted(cmd, args_hint))

    def update_filter(self, text: str) -> None:
        """Update filter and refresh suggestions."""
        # Extract command part after /
        if text.startswith("/"):
            filter_text = text[1:].split()[0] if text[1:] else ""
        else:
            filter_text = text

        self.filter_text = filter_text
        self._refresh_suggestions()

        # Update selection to stay in bounds
        if self.selected_index >= len(self.suggestions):
            self.selected_index = 0
