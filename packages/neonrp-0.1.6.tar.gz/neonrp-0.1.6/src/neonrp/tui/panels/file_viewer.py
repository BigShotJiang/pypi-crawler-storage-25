"""File viewer panel for NeonRP TUI."""

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Container
from textual.widgets import Static, RichLog


class FileViewer(Container):
    """Read-only file viewer panel."""

    MAX_LINES = 500
    DISPLAY_LINES = 200

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._current_file: Path | None = None

    def compose(self) -> ComposeResult:
        """Compose the file viewer."""
        yield Static("[bold]File Viewer[/]", classes="panel-title")
        yield RichLog(id="file-log", highlight=True, markup=True)

    def on_mount(self) -> None:
        """Initialize the file viewer."""
        log = self.query_one("#file-log", RichLog)
        log.write("[dim]Select a file from the navigator[/]")

    def view_file(self, path: Path) -> None:
        """Display contents of a file.

        Large files (>500 lines) are truncated to first 200 lines.

        Args:
            path: Path to the file to display
        """
        log = self.query_one("#file-log", RichLog)
        log.clear()

        if not path.exists():
            log.write(f"[red]File not found: {path}[/]")
            return

        if path.is_dir():
            log.write(f"[yellow]{path.name}/ is a directory[/]")
            return

        self._current_file = path

        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            log.write(f"[red]Cannot read binary file: {path.name}[/]")
            return
        except Exception as e:
            log.write(f"[red]Error reading file: {e}[/]")
            return

        lines = content.split("\n")
        total_lines = len(lines)

        # Display header
        log.write(f"[bold]{path.name}[/] ({total_lines} lines)")
        log.write("")

        # Truncate large files
        if total_lines > self.MAX_LINES:
            log.write(f"[yellow]File too large, showing first {self.DISPLAY_LINES} lines[/]")
            log.write("")
            lines = lines[: self.DISPLAY_LINES]

        # Syntax highlighting based on extension
        ext = path.suffix.lower()
        for i, line in enumerate(lines, 1):
            # Line number prefix
            prefix = f"[dim]{i:4}[/]│ "

            if ext == ".json":
                # Basic JSON syntax highlighting
                if '"' in line and ":" in line:
                    line = line.replace('":', '"[cyan]:[/]')
                log.write(prefix + line)
            elif ext == ".md":
                # Markdown highlighting
                if line.startswith("#"):
                    log.write(prefix + f"[bold cyan]{line}[/]")
                elif line.startswith("-") or line.startswith("*"):
                    log.write(prefix + f"[yellow]{line}[/]")
                else:
                    log.write(prefix + line)
            else:
                log.write(prefix + line)

        if total_lines > self.MAX_LINES:
            log.write("")
            log.write(f"[dim]... {total_lines - self.DISPLAY_LINES} more lines not shown[/]")

    def get_current_file(self) -> Path | None:
        """Get the current file being viewed."""
        return self._current_file

    def clear(self) -> None:
        """Clear the file viewer."""
        self._current_file = None
        log = self.query_one("#file-log", RichLog)
        log.clear()
        log.write("[dim]Select a file from the navigator[/]")
