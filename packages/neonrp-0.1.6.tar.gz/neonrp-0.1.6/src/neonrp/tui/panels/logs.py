"""Logs browser panel for NeonRP TUI."""

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Container
from textual.widgets import Static, RichLog, ListView, ListItem

from neonrp.core.paths import get_neonrp_dir


class LogItem(ListItem):
    """A single log run item."""

    def __init__(self, run_id: str, path: Path) -> None:
        super().__init__()
        self.run_id = run_id
        self.path = path

    def compose(self) -> ComposeResult:
        """Compose the list item."""
        yield Static(f"[cyan]{self.run_id}[/]")


class LogsBrowser(Container):
    """Agent logs browser panel."""

    def __init__(self, root: Path, **kwargs):
        super().__init__(**kwargs)
        self.root = root
        self._current_run_id: str | None = None

    def compose(self) -> ComposeResult:
        """Compose the logs browser."""
        yield Static("[bold]Agent Runs[/]", classes="panel-title")
        yield ListView(id="runs-list")
        yield Static("[bold]Log Details[/]", classes="panel-title")
        yield RichLog(id="log-details", highlight=True, markup=True)

    def on_mount(self) -> None:
        """Refresh the runs list on mount."""
        self.refresh_runs()

    def refresh_runs(self) -> None:
        """Refresh the list of agent runs."""
        list_view = self.query_one("#runs-list", ListView)
        list_view.clear()

        logs_dir = get_neonrp_dir(self.root) / "logs" / "agents"
        if not logs_dir.exists():
            return

        # Get all run directories, sorted by name (timestamp) descending
        runs = sorted(
            [d for d in logs_dir.iterdir() if d.is_dir()],
            key=lambda x: x.name,
            reverse=True,
        )

        for run_dir in runs[:20]:  # Limit to 20 most recent
            list_view.append(LogItem(run_dir.name, run_dir))

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Handle run selection."""
        if isinstance(event.item, LogItem):
            self.show_run_details(event.item.run_id, event.item.path)

    def show_run_details(self, run_id: str, path: Path) -> None:
        """Show details for a specific run.

        Args:
            run_id: ID of the run
            path: Path to the run directory
        """
        self._current_run_id = run_id
        log = self.query_one("#log-details", RichLog)
        log.clear()

        log.write(f"[bold]Run ID:[/] {run_id}")
        log.write(f"[bold]Path:[/] {path}")
        log.write("")

        # Show available log files (new names with fallback to old names)
        log_file_mappings = [
            ("input.json", "llm_input.json"),  # new, old
            ("llm_raw.txt", None),
            ("proposal.json", None),
            ("diff.patch", "diff.txt"),  # new, old
            ("validation.json", None),
            ("apply.json", None),
        ]

        for primary_name, fallback_name in log_file_mappings:
            file_path = path / primary_name
            display_name = primary_name
            if not file_path.exists() and fallback_name:
                file_path = path / fallback_name
                display_name = fallback_name

            if file_path.exists():
                log.write(f"[green]✓[/] {display_name}")

                # Show snippet for some files
                if primary_name == "input.json":
                    try:
                        import json

                        data = json.loads(file_path.read_text(encoding="utf-8"))
                        log.write(f"  [dim]Query: {data.get('query', 'N/A')}[/]")
                        log.write(f"  [dim]Agent: {data.get('agent_id', 'N/A')}[/]")
                        log.write(f"  [dim]Provider: {data.get('provider', 'N/A')}[/]")
                    except Exception:
                        pass
                elif primary_name == "diff.patch":
                    try:
                        content = file_path.read_text(encoding="utf-8")
                        lines = content.split("\n")[:5]
                        for line in lines:
                            if line.startswith("+"):
                                log.write(f"  [green]{line[:60]}[/]")
                            elif line.startswith("-"):
                                log.write(f"  [red]{line[:60]}[/]")
                            else:
                                log.write(f"  [dim]{line[:60]}[/]")
                    except Exception:
                        pass
                elif primary_name == "validation.json":
                    try:
                        import json

                        data = json.loads(file_path.read_text(encoding="utf-8"))
                        if data.get("success"):
                            log.write("  [dim]Validation: passed[/]")
                        else:
                            log.write(f"  [yellow]Validation: {len(data.get('validation_errors', []))} errors[/]")
                    except Exception:
                        pass
                elif primary_name == "apply.json":
                    try:
                        import json

                        data = json.loads(file_path.read_text(encoding="utf-8"))
                        if data.get("success"):
                            log.write(f"  [dim]Applied: event_id={data.get('event_id')}[/]")
                        else:
                            log.write(f"  [red]Apply failed: {data.get('error', 'unknown')}[/]")
                    except Exception:
                        pass
            else:
                log.write(f"[dim]○ {primary_name}[/]")

    def goto_recent(self) -> None:
        """Jump to the most recent run."""
        logs_dir = get_neonrp_dir(self.root) / "logs" / "agents"
        if not logs_dir.exists():
            return

        runs = sorted(
            [d for d in logs_dir.iterdir() if d.is_dir()],
            key=lambda x: x.name,
            reverse=True,
        )

        if runs:
            self.show_run_details(runs[0].name, runs[0])

    def get_current_run_id(self) -> str | None:
        """Get the current run ID being viewed."""
        return self._current_run_id
