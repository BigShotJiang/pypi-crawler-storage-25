"""Diff view panel for NeonRP TUI."""

from textual.app import ComposeResult
from textual.containers import Container
from textual.widgets import Static, RichLog


class DiffView(Container):
    """Diff preview panel with apply functionality."""

    def __init__(
        self,
        diff_content: str = "",
        can_apply: bool = False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self._diff_content = diff_content
        self._can_apply = can_apply
        self._proposal = None
        self._agent_result = None

    def compose(self) -> ComposeResult:
        """Compose the diff view."""
        yield Static("[bold]Diff Preview[/]", classes="panel-title")
        yield RichLog(id="diff-log", highlight=True, markup=True)

    def on_mount(self) -> None:
        """Initialize the diff view."""
        self.update_diff(self._diff_content, self._can_apply)

    def update_diff(self, content: str, can_apply: bool = False) -> None:
        """Update the diff content.

        Args:
            content: Diff content to display
            can_apply: Whether the diff can be applied
        """
        self._diff_content = content
        self._can_apply = can_apply

        log = self.query_one("#diff-log", RichLog)
        log.clear()

        if not content:
            log.write("[dim]No changes to display[/]")
            return

        # Add header
        if can_apply:
            log.write("[bold green]Press 'a' to apply these changes[/]")
            log.write("")

        # Render diff with syntax highlighting
        for line in content.split("\n"):
            if line.startswith("+") and not line.startswith("+++"):
                log.write(f"[green]{line}[/]")
            elif line.startswith("-") and not line.startswith("---"):
                log.write(f"[red]{line}[/]")
            elif line.startswith("@@"):
                log.write(f"[cyan]{line}[/]")
            elif line.startswith("---") or line.startswith("+++"):
                log.write(f"[bold]{line}[/]")
            else:
                log.write(line)

    def set_agent_result(self, result) -> None:
        """Store the agent result for apply action.

        Args:
            result: AgentRunResult from agent run
        """
        self._agent_result = result
        if result and result.proposal:
            self._proposal = result.proposal
            self.update_diff(result.diff_content, can_apply=True)
        else:
            self._proposal = None
            self.update_diff("", can_apply=False)

    def get_proposal(self):
        """Get the current proposal for applying."""
        return self._proposal

    def get_agent_result(self):
        """Get the current agent result."""
        return self._agent_result

    def clear(self) -> None:
        """Clear the diff view."""
        self._diff_content = ""
        self._can_apply = False
        self._proposal = None
        self._agent_result = None
        log = self.query_one("#diff-log", RichLog)
        log.clear()
        log.write("[dim]No changes to display[/]")
