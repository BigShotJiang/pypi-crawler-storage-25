"""TUI panels package."""
