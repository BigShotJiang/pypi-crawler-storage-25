"""NeonRP TUI — Claude Code style conversational interface.

M9-T5: Single-pane conversational TUI replacing 4-pane layout as default.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import threading
import traceback
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from textwrap import dedent
from typing import Any, Callable, Literal

import regex as regex_re
from rich.syntax import Syntax
from rich.text import Text
from rich.rule import Rule
from textual.app import App, ComposeResult, ScreenStackError
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.suggester import Suggester
from textual.widgets import Button, Collapsible, Input, Markdown, Static
from textual.worker import get_current_worker

from neonrp.core.conversation import (
    ASK_USER_CANCELLED_RESPONSE,
    ConversationMode,
    ConversationSession,
    ConversationTurnResult,
)

AppMode = ConversationMode | Literal["mcp"]
from neonrp.core.config import (
    SUPPORTED_MODEL_PROVIDERS,
    create_default_config_template,
    get_api_key,
    get_config_path,
    get_user_config_path,
    load_config,
    resolve_provider,
)
from neonrp.core.manifest import Manifest
from neonrp.core.mcp_pool import MCPPool
from neonrp.core.paths import get_data_dir_name, get_manifest_path, get_neonrp_dir, get_game_dir
from neonrp.core.runtime_contract import get_router_execution_mode, get_startup_entry_agent, set_router_execution_mode
from neonrp.core.session import get_session_path
from neonrp.core.skill_loader import SkillLoader
from neonrp.core.state import get_auto_apply, set_auto_apply
from neonrp.core.storage import atomic_write_json
from neonrp.tui.commands import COMMANDS, get_command_suggestions, get_subcommand_suggestions, parse_command
from neonrp.tui.commands import get_command_args_hint
from neonrp.tui.i18n import get_message, localize_mode, resolve_locale
from neonrp.tui.palette import CommandPalette

try:
    from neonrp import __version__ as _NEONRP_VERSION
except Exception:
    _NEONRP_VERSION = "0.0.0"

LOCAL_SLASH_COMMANDS = {
    "mode",
    "router-mode",
    "clear",
    "files",
    "skills",
    "mcp",
    "help",
    "copy",
    "auth",
    "models",
    "apply",
    "undo",
    "save",
    "load",
    "stats",
    "compact",
    "sessions",
    "continue",
    "new",
    "verbose",
    "autoapply",
    "config",
    "quit",
    "q",
    "worldlines",
    "worlds",
    "debug",
    "wl-model",
    "update",
    "locale",
    "settings",
    "export-world",
    "load-world",
    "bridge",
}

CLI_FORWARD_COMMANDS = {
    "init",
    "run",
    "validate",
    "index",
    "find",
    "context",
    "redo",
    "branch",
    "game",
    "sandbox",
    "replay",
    "agent",
    "import",
}


@dataclass
class WorldLinesLaunchSelection:
    mode: Literal["continue", "new"]
    preset_id: str
    runtime_mode: AppMode
    game_path: Path | None = None
    world_id: str | None = None
    player_profile: dict[str, Any] | None = None
    # Populated when the user picked "Create new world" or "Import world";
    # CLI launcher inspects this to run the relevant built-in skill.
    world_intent: dict[str, Any] | None = None


class StatusBar(Static):
    """Top status bar showing project state."""

    def __init__(
        self,
        root: Path,
        branch: str,
        event_count: int,
        mode: AppMode,
        agent: str,
        model_display: str = "",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.root = root
        self.branch = branch
        self.event_count = event_count
        self.mode = mode
        self.agent = agent
        self.model_display = model_display
        self.prompt_tokens = 0
        self.completion_tokens = 0

    def compose(self) -> ComposeResult:
        """Compose the status bar."""
        with Horizontal(id="status-row"):
            yield Static(self._build_left_text(), id="status-text")
            yield Static(self._build_tokens_text(), id="status-tokens")

    def _build_left_text(self) -> str:
        mode_color = {
            "build": "blue",
            "sandbox": "yellow",
            "play": "green",
            "mcp": "magenta",
        }.get(self.mode, "white")
        return (
            f"[bold]{self.root.name}[/] │ "
            f"[bold cyan]{self.branch}[/] │ "
            f"ev:[bold yellow]{self.event_count}[/] │ "
            f"[bold {mode_color}]{self.mode}[/] │ "
            f"[bold magenta]{self.agent}[/] │ "
            f"mdl:[bold green]{self.model_display or '(n/a)'}[/]"
        )

    def _build_tokens_text(self) -> str:
        total = self.prompt_tokens + self.completion_tokens
        return (
            f"[dim]↑[/][cyan]{self.prompt_tokens}[/]  "
            f"[dim]↓[/][green]{self.completion_tokens}[/]  "
            f"[dim]Σ[/][bold]{total}[/]"
        )

    def update_status(
        self,
        event_count: int | None = None,
        mode: ConversationMode | None = None,
        agent: str | None = None,
        model_display: str | None = None,
        prompt_tokens: int | None = None,
        completion_tokens: int | None = None,
    ) -> None:
        """Update status bar values."""
        if event_count is not None:
            self.event_count = event_count
        if mode is not None:
            self.mode = mode
        if agent is not None:
            self.agent = agent
        if model_display is not None:
            self.model_display = model_display
        if prompt_tokens is not None:
            self.prompt_tokens = max(0, int(prompt_tokens))
        if completion_tokens is not None:
            self.completion_tokens = max(0, int(completion_tokens))
        try:
            self.query_one("#status-text", Static).update(self._build_left_text())
            self.query_one("#status-tokens", Static).update(self._build_tokens_text())
        except Exception:
            self.refresh()


class ConversationView(VerticalScroll):
    """Main conversation panel with segmented markdown/code rendering."""

    BINDINGS = [Binding("y", "copy_selection", "Copy selection")]
    _FENCED_CODE_RE = re.compile(r"```([a-zA-Z0-9_+-]*)\n(.*?)```", re.DOTALL)
    _KEYCAP_RE = re.compile(r"([0-9#*])(?:\ufe0f|\ufe0e)?\u20e3")
    _DANGLING_ZWJ_RE = re.compile(r"\u200d(?=\s|$)")
    _UNSAFE_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
    _GRAPHEME_CLUSTER_RE = regex_re.compile(r"\X")
    _MARKDOWN_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")
    _MARKDOWN_STRONG_RE = re.compile(r"\*\*(.+?)\*\*")
    # Low-key spinner frames: minimal, readable, and less "emoji-heavy".
    _SPINNER_FRAMES = ["◜", "◠", "◝", "◞", "◡", "◟"]
    _SPINNER_COLORS = ["#4f97df", "#66a9ec", "#7bb8f4", "#66a9ec", "#4f97df", "#3f83c7"]
    _OK_COLOR = "#67c587"
    _ERR_COLOR = "#cf7f7f"
    _NEUTRAL_COLOR = "#8a919b"
    _TOOL_TITLE_TEXT_COLOR = "#8e96a1"
    _EXECUTION_FOLD_TITLE_COLOR = "#7c8591"

    def __init__(self, display_mode: AppMode = "build", **kwargs):
        super().__init__(**kwargs)
        self.display_mode: AppMode = display_mode
        # Keep framework auto-scroll disabled and control follow behavior explicitly.
        self.auto_scroll = False
        self._follow_output = True
        self._programmatic_scroll = False
        self._scroll_end_pending = False
        self._scroll_end_reschedule = False
        self._plain_chunks: list[str] = []
        self._stream_render_timer = None
        self._assistant_stream_needs_render = False
        self._assistant_stream_open = False
        self._assistant_stream_buffer = ""
        self._assistant_stream_widget: Any | None = None
        self._assistant_stream_speaker: str = "Narrator"
        # Widget reference for the last mounted "### Speaker" header — so
        # we can remove it if the segment turns out to have no content
        # (e.g. the LLM produced only a tool call then delegated, leaving
        # a "[World Agent]" header with nothing under it).
        self._assistant_header_widget: Static | None = None
        # Per-turn accumulator for bridge broadcasting. Each entry is
        # (speaker_name, segment_text). Populated on every
        # `_flush_assistant_stream_segment` and drained at `add_assistant_end`.
        # Without this, bridges would only see the LAST segment of a multi-
        # speaker turn — so sub-agent chatter (town-agent, character-agent)
        # would mask the orchestrator's narration on Discord.
        self._bridge_segment_buffer: list[tuple[str, str]] = []
        # Last speaker we emitted a header for in the current user-turn.
        # Reset on add_user_message / add_assistant_end so subsequent turns
        # get their own header; keeps multi-tool-call turns under one label.
        self._last_header_speaker_in_turn: str | None = None
        self._thinking_stream_needs_render = False
        self._thinking_stream_open = False
        self._thinking_stream_buffer = ""
        self._thinking_stream_widget: Static | None = None
        self._thinking_stream_speaker: str | None = None
        self._tool_cards: list[dict[str, Any]] = []
        self._tool_spinner_frame = 0
        self._tool_spinner_timer = None
        self._pending_execution_items: list[dict[str, Any]] = []
        self._execution_live_widget: Static | None = None
        self._current_thinking_execution_item: dict[str, Any] | None = None
        self._assistant_activity_widget: Static | None = None
        self._assistant_activity_base: str = ""
        self._assistant_activity_pulse: int = 0
        self._assistant_activity_speaker: str | None = None
        self._assistant_activity_animating = False

    def set_display_mode(self, mode: AppMode) -> None:
        """Update transcript presentation mode."""
        self.display_mode = mode

    def _use_narrative_folding(self) -> bool:
        return self.display_mode in {"play", "mcp"}

    @staticmethod
    def _to_plain_text(content: Any) -> str:
        """Convert rich/markup content into plain text for clipboard export."""
        if isinstance(content, Text):
            return content.plain
        if isinstance(content, str):
            try:
                return Text.from_markup(content).plain
            except Exception:
                return content
        return str(content)

    def _append_plain(self, text: str) -> None:
        plain = self._to_plain_text(text)
        if plain:
            self._plain_chunks.append(plain)

    def _is_near_bottom(self, y_value: float | None = None, threshold: float = 3.0) -> bool:
        y = self.scroll_y if y_value is None else y_value
        return (self.max_scroll_y - y) <= threshold

    def _pause_follow_output(self) -> None:
        self._follow_output = False

    def _resume_follow_output(self) -> None:
        self._follow_output = True

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        """Track user scroll intent to control output tail-following."""
        # Preserve Textual's default scroll bookkeeping (scrollbar position, refresh, anchoring).
        super().watch_scroll_y(old_value, new_value)
        if not self.is_mounted:
            return
        if self._programmatic_scroll:
            return
        if self._is_near_bottom(new_value):
            self._resume_follow_output()
            return
        # Dragging the scrollbar is explicit user intent to inspect older output.
        if self.is_vertical_scrollbar_grabbed:
            self._pause_follow_output()
            return
        # Wheel / keyboard scroll-up should also suspend follow mode.
        if new_value < old_value:
            self._pause_follow_output()

    def _safe_scroll_end(self) -> None:
        if not self.is_mounted:
            return
        if not self._follow_output:
            return
        if self._scroll_end_pending:
            self._scroll_end_reschedule = True
            return
        self._scroll_end_pending = True
        self.call_after_refresh(self._scroll_end_now)

    def _scroll_end_now(self) -> None:
        """Scroll to bottom after layout refresh so scrollbar state stays in sync."""
        if not self.is_mounted or not self._follow_output:
            self._scroll_end_pending = False
            self._scroll_end_reschedule = False
            return
        try:
            self._programmatic_scroll = True
            self.scroll_end(animate=False, immediate=True, x_axis=False)
        except Exception:
            try:
                self.scroll_end(animate=False)
            except Exception:
                pass
        finally:
            self._programmatic_scroll = False
            if self._scroll_end_reschedule and self.is_mounted and self._follow_output:
                self._scroll_end_reschedule = False
                self.call_after_refresh(self._scroll_end_now)
            else:
                self._scroll_end_pending = False
                self._scroll_end_reschedule = False

    def _mount_role_header(self, title: str, role: str) -> Static | None:
        """Mount a `### Speaker` row. Returns the widget so the caller
        can remove it later if the segment turns out to be empty."""
        if not self.is_mounted:
            return None
        self._mount_content_divider()
        display = title
        if self._use_narrative_folding() and role == "assistant":
            display = f"[{title}]"
        header = Static(Text(display), classes=f"msg-header msg-{role}")
        self.mount(header)
        self._safe_scroll_end()
        return header

    def _resolve_view_locale(self) -> str:
        app_ctx = getattr(self, "_app_context", None)
        if app_ctx is None:
            try:
                app_ctx = self.app
            except Exception:
                app_ctx = None
        locale = str(getattr(app_ctx, "ui_locale", "en") or "en")
        return resolve_locale(locale)

    def _get_app_context(self) -> Any | None:
        app_ctx = getattr(self, "_app_context", None)
        if app_ctx is not None:
            return app_ctx
        try:
            return self.app
        except Exception:
            return None

    # L14 presentation-role resolution relies ONLY on agent.json:
    #
    #   {
    #     "presentation_role":        "World",    // optional, locale-neutral
    #     "presentation_roles":       { "zh": "世界", "en": "World" },
    #     "display_name":             "World",
    #     "display_names":            { "zh": "世界", "en": "World" },
    #     "presentation_hidden":      false        // if true, this agent's
    #                                              // turns are folded away
    #                                              // in the default view
    #   }
    #
    # The engine stays dumb — it doesn't know that `town-agent` means "Town"
    # or that `orchestrator` should be hidden. Templates / projects own those
    # decisions and set the fields on their own agent.json files.

    @staticmethod
    def _agent_is_hidden_at(root: Path | None, agent_ref: str | None) -> bool:
        """Mode-aware `presentation_hidden` read from agents/<ref>/agent.json.

        Implemented as a pure staticmethod so NeonRPApp can call it without
        going through the `view` instance — otherwise test mocks
        (`view = MagicMock()`) would make `view._is_agent_hidden(...)`
        return a truthy Mock, treating every agent as hidden.

        Engine is deliberately NAME-AGNOSTIC — no hardcoded list of
        "sub-agent" names. Whether a speaker is hidden depends entirely
        on the author-supplied `presentation_hidden` flag on the game's
        own agent.json. Same engine works for combat-referee (visible
        result), town-agent (author might hide), rules-referee
        (author might show), etc., without code changes.

        Mode gating:
        - `orchestrator` mode: respect per-agent `presentation_hidden`.
        - `fast` / non-orchestrator: sub-agents ARE the primary
          narrators via active-agent routing — never hide, regardless
          of flag.
        """
        raw = str(agent_ref or "").strip()
        if not raw or root is None:
            return False
        try:
            from neonrp.core.runtime_contract import get_router_execution_mode

            mode = get_router_execution_mode(Path(root))
        except Exception:
            mode = "fast"
        if mode != "orchestrator":
            return False
        agent_json = Path(root) / "agents" / raw / "agent.json"
        if not agent_json.exists():
            return False
        try:
            payload = json.loads(agent_json.read_text(encoding="utf-8"))
        except Exception:
            return False
        return bool(payload.get("presentation_hidden", False))

    def _is_agent_hidden(self, agent_ref: str | None) -> bool:
        """Instance wrapper around `_agent_is_hidden_at` using the current root."""
        app_ctx = self._get_app_context()
        root = getattr(app_ctx, "root", None)
        return ConversationView._agent_is_hidden_at(root, agent_ref)

    def _resolve_agent_transcript_meta(self, agent_ref: str | None) -> tuple[str, str, str, str]:
        raw = str(agent_ref or "").strip()
        locale = self._resolve_view_locale()
        default_thinking = "思考中" if locale == "zh" else "thinking"
        default_narrating = "叙事中" if locale == "zh" else "narrating"
        default_acting = "处理中" if locale == "zh" else "working"
        if not raw:
            return ("Narrator", default_thinking, default_narrating, default_acting)
        app_ctx = self._get_app_context()
        root = getattr(app_ctx, "root", None)
        if root is None:
            return (raw, default_thinking, default_narrating, default_acting)
        agent_json = Path(root) / "agents" / raw / "agent.json"
        if not agent_json.exists():
            return (raw, default_thinking, default_narrating, default_acting)
        try:
            payload = json.loads(agent_json.read_text(encoding="utf-8"))
        except Exception:
            return (raw, default_thinking, default_narrating, default_acting)
        if not isinstance(payload, dict):
            return (raw, default_thinking, default_narrating, default_acting)

        # Presentation role: optional locale-aware alias from agent.json.
        presentation_roles = payload.get("presentation_roles")
        if isinstance(presentation_roles, dict):
            presentation_role = str(presentation_roles.get(locale, "") or "").strip()
        else:
            presentation_role = ""
        if not presentation_role:
            presentation_role = str(payload.get("presentation_role", "") or "").strip()

        localized_names = payload.get("display_names")
        if isinstance(localized_names, dict):
            localized_name = str(localized_names.get(locale, "") or "").strip()
        else:
            localized_name = ""
        display_name = (
            presentation_role
            or localized_name
            or str(payload.get(f"display_name_{locale}", "") or "").strip()
            or str(payload.get("name_local", "") or "").strip()
            or str(payload.get("display_name", "") or "").strip()
            or str(payload.get("name", "") or "").strip()
            or raw
        )

        localized_thinking = payload.get("thinking_labels")
        if isinstance(localized_thinking, dict):
            thinking_label = str(localized_thinking.get(locale, "") or "").strip()
        else:
            thinking_label = ""
        thinking_label = (
            thinking_label
            or str(payload.get(f"thinking_label_{locale}", "") or "").strip()
            or str(payload.get("thinking_label", "") or "").strip()
            or default_thinking
        )

        localized_narrating = payload.get("narrating_labels")
        if isinstance(localized_narrating, dict):
            narrating_label = str(localized_narrating.get(locale, "") or "").strip()
        else:
            narrating_label = ""
        narrating_label = (
            narrating_label
            or str(payload.get(f"narrating_label_{locale}", "") or "").strip()
            or str(payload.get("narrating_label", "") or "").strip()
            or default_narrating
        )

        localized_acting = payload.get("acting_labels")
        if isinstance(localized_acting, dict):
            acting_label = str(localized_acting.get(locale, "") or "").strip()
        else:
            acting_label = ""
        acting_label = (
            acting_label
            or str(payload.get(f"acting_label_{locale}", "") or "").strip()
            or str(payload.get("acting_label", "") or "").strip()
            or default_acting
        )
        return (display_name, thinking_label, narrating_label, acting_label)

    def _mount_content_divider(self) -> None:
        if not self.is_mounted:
            return
        try:
            children = list(self.children)
        except Exception:
            children = []
        if not children:
            return
        last = children[-1]
        try:
            if "msg-divider" in str(getattr(last, "classes", "")):
                return
        except Exception:
            pass
        self.mount(Static(Rule(style="#3F3F46", characters="─"), classes="msg-divider"))

    @staticmethod
    def _semantic_line_class(line: str) -> str:
        stripped = line.strip()
        if not stripped:
            return "semantic-spacer"
        if ConversationView._MARKDOWN_HEADING_RE.match(stripped):
            return "semantic-markdown-heading"
        if stripped.startswith("//") or "═══" in stripped:
            return "semantic-scene-header"
        if stripped.startswith("[state_update]"):
            return "semantic-state-update"
        if stripped.startswith("[awaiting_player_action]"):
            return "semantic-awaiting"
        if stripped.startswith("[") and "]" in stripped:
            return "semantic-agent-tag"
        if stripped.startswith("内心独白"):
            return "semantic-inner"
        if stripped.startswith(">"):
            return "semantic-player-line"
        if re.match(r"^\d+\.\s", stripped):
            return "semantic-choice-line"
        return "semantic-narrative-line"

    @staticmethod
    def _semantic_base_color(css_class: str) -> str:
        mapping = {
            "semantic-scene-header": "#a5b4fc",
            "semantic-markdown-heading": "#c4b5fd",
            "semantic-agent-tag": "#93c5fd",
            "semantic-state-update": "#86efac",
            "semantic-awaiting": "#fcd34d",
            "semantic-inner": "#d8b4fe",
            "semantic-choice-line": "#f5f5f5",
            "semantic-player-line": "#e4e4e7",
            "semantic-narrative-line": "#f8fafc",
        }
        return mapping.get(css_class, "#f8fafc")

    @classmethod
    def _build_semantic_inline_text(cls, line: str, css_class: str = "semantic-narrative-line") -> Text:
        raw = cls._sanitize_terminal_text(line)
        heading_match = cls._MARKDOWN_HEADING_RE.match(raw.strip())
        content = heading_match.group(2) if heading_match else raw
        base_style = cls._semantic_base_color(css_class)

        rendered = Text()
        cursor = 0
        for match in cls._MARKDOWN_STRONG_RE.finditer(content):
            if match.start() > cursor:
                rendered.append(content[cursor:match.start()], style=base_style)
            rendered.append(match.group(1), style="#F5C2E7")
            cursor = match.end()
        if cursor < len(content):
            rendered.append(content[cursor:], style=base_style)
        return rendered

    def _build_semantic_stream_text(self, text: str) -> Text:
        combined = Text()
        sanitized = self._sanitize_terminal_text(text)
        lines = sanitized.splitlines()
        for idx, line in enumerate(lines):
            css_class = self._semantic_line_class(line)
            if css_class == "semantic-spacer":
                if idx < len(lines) - 1:
                    combined.append("\n")
                continue
            combined.append_text(self._build_semantic_inline_text(line, css_class=css_class))
            if idx < len(lines) - 1:
                combined.append("\n")
        return combined

    def _build_semantic_text_widgets(self, text: str, role: str = "assistant") -> list[Any]:
        widgets: list[Any] = []
        sanitized = self._sanitize_terminal_text(text)
        for line in sanitized.splitlines():
            css_class = self._semantic_line_class(line)
            if css_class == "semantic-spacer":
                widgets.append(Static("", classes="msg-spacer"))
                continue
            widgets.append(
                Static(self._build_semantic_inline_text(line, css_class=css_class), classes=f"msg-body msg-{role} {css_class}")
            )
        return widgets

    @staticmethod
    def _is_hidden_json_code_block(lang: str, content: str) -> bool:
        text = str(content or "").strip()
        if not text:
            return False
        normalized_lang = str(lang or "").strip().lower()
        if normalized_lang not in {"", "json", "jsonc", "javascript", "js"} and not text.startswith(("{", "[")):
            return False
        try:
            parsed = json.loads(text)
        except Exception:
            return False
        return isinstance(parsed, (dict, list))

    @classmethod
    def _split_markdown_segments(cls, text: str) -> list[tuple[str, str, str]]:
        """Split markdown into text/code segments."""
        segments: list[tuple[str, str, str]] = []
        pos = 0
        for match in cls._FENCED_CODE_RE.finditer(text):
            start, end = match.span()
            if start > pos:
                text_seg = text[pos:start]
                if text_seg.strip():
                    segments.append(("text", "", text_seg))
            lang = (match.group(1) or "").strip().lower()
            code = match.group(2).strip("\n")
            segments.append(("code", lang, code))
            pos = end
        if pos < len(text):
            tail = text[pos:]
            if tail.strip():
                segments.append(("text", "", tail))
        return segments

    def _build_code_block(self, role: str, lang: str, content: str) -> Vertical:
        lexer = lang or "text"
        try:
            syntax = Syntax(content, lexer, theme="monokai", word_wrap=True, line_numbers=False)
        except Exception:
            syntax = Syntax(content, "text", theme="monokai", word_wrap=True, line_numbers=False)
        code_lang = lang or "code"
        return Vertical(
            Static(f"[{code_lang}]", classes="code-lang"),
            Static(syntax, classes="code-body"),
            classes=f"code-block msg-{role}",
        )

    def _build_segment_widgets(self, markdown: str, role: str = "system") -> list:
        """Create widgets for markdown/code segments."""
        widgets = []
        for seg_type, lang, content in self._split_markdown_segments(markdown):
            if seg_type == "text":
                safe_content = self._sanitize_terminal_text(content)
                if self._use_narrative_folding() and role == "assistant":
                    widgets.extend(self._build_semantic_text_widgets(safe_content, role=role))
                else:
                    widgets.append(Markdown(safe_content, classes=f"msg-body msg-{role}"))
            else:
                safe_content = self._sanitize_terminal_text(content)
                if self._use_narrative_folding() and role == "assistant" and self._is_hidden_json_code_block(lang, safe_content):
                    continue
                widgets.append(self._build_code_block(role, lang, safe_content))
        return widgets

    def _render_markdown_segments(
        self,
        markdown: str,
        role: str = "system",
        parent: Any | None = None,
        before: Any | None = None,
    ) -> None:
        if not self.is_mounted:
            return
        target = parent or self
        is_first = True
        for widget in self._build_segment_widgets(markdown, role):
            mount_kwargs: dict[str, Any] = {}
            if before is not None and is_first:
                mount_kwargs["before"] = before
            target.mount(widget, **mount_kwargs)
            is_first = False
        self._safe_scroll_end()

    @staticmethod
    def _split_scoped_tool_name(tool_name: str) -> tuple[str | None, str]:
        raw = str(tool_name or "").strip()
        if ":" not in raw:
            return None, raw
        scope, base = raw.split(":", 1)
        scope = scope.strip()
        base = base.strip()
        if not scope or not base:
            return None, raw
        return scope, base

    @staticmethod
    def _extract_ask_user_question(params: dict[str, Any]) -> str:
        if not isinstance(params, dict):
            return ""
        question = str(params.get("question", "") or "").strip()
        if question:
            return question
        questions = params.get("questions")
        if isinstance(questions, list):
            first = next((item for item in questions if isinstance(item, dict)), None)
            if first:
                return str(first.get("question", "") or "").strip()
        return ""

    @staticmethod
    def _tool_summary(tool_name: str, params: dict[str, Any]) -> str:
        """Build one-line tool call summary with readable phrasing."""
        MAX_LEN = 80
        scope, base_name = ConversationView._split_scoped_tool_name(tool_name)
        normalized = str(base_name or "").strip().lower()

        summary = str(base_name or tool_name or "").strip()
        if normalized in {"read_file", "write_file", "edit_file", "delete_file"}:
            path = str(params.get("path", "") or "").strip()
            if path:
                verb = {
                    "read_file": "Read",
                    "write_file": "Write",
                    "edit_file": "Edit",
                    "delete_file": "Delete",
                }[normalized]
                summary = f"{verb} {path}"
        elif normalized == "ask_user":
            question = ConversationView._extract_ask_user_question(params)
            if question:
                summary = f'Ask "{question}"'
            else:
                summary = "Ask player"
        elif normalized == "task":
            target = str(params.get("agent_id", "") or "").strip()
            summary = f"Delegate to {target}" if target else "Delegate task"
        elif normalized == "resolve_action":
            action = str(params.get("action", "") or "").strip()
            summary = f'Resolve "{action}"' if action else "Resolve action"
        elif normalized == "glob":
            pattern = str(params.get("pattern", "") or "").strip()
            summary = f'Search "{pattern}"' if pattern else "Search files"
        elif normalized == "list_entities":
            etype = str(params.get("entity_type", "") or "").strip()
            summary = f"List {etype}" if etype else "List entities"
        elif normalized == "read_context":
            query = str(params.get("query", "") or "").strip()
            summary = f'Read context "{query}"' if query else "Read context"
        elif params:
            pairs: list[str] = []
            for key, value in params.items():
                text = str(value).replace("\n", " ").strip()
                if len(text) > 36:
                    text = f"{text[:33]}..."
                pairs.append(f"{key}={text}")
            tail = " ".join(pairs).strip()
            summary = f"{base_name} {tail}".strip()

        if scope:
            result = f"{scope}: {summary}"
        else:
            result = summary

        if len(result) > MAX_LEN:
            return f"{result[: MAX_LEN - 3]}..."
        return result

    @staticmethod
    def _tool_payload_text(params: dict[str, Any]) -> str:
        """Serialize tool params for detail panel."""
        if not params:
            return "(no params)"
        serialized = json.dumps(params, ensure_ascii=False, indent=2, default=str)
        return serialized if len(serialized) <= 500 else f"{serialized[:497]}..."

    @staticmethod
    def _tool_result_text(raw_result: str) -> str:
        """Serialize tool result payload for detail panel with safe truncation."""
        if not isinstance(raw_result, str) or not raw_result.strip():
            return "(no result yet)"
        try:
            payload = json.loads(raw_result)
            if isinstance(payload, dict):
                data = payload.get("data")
                if isinstance(data, dict):
                    # Large file reads can dominate the card; keep a compact preview.
                    content = data.get("content")
                    if isinstance(content, str) and len(content) > 320:
                        data = dict(data)
                        data["content"] = f"{content[:317]}..."
                        payload = dict(payload)
                        payload["data"] = data
                serialized = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
            else:
                serialized = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
        except Exception:
            serialized = raw_result

        if len(serialized) > 900:
            return f"{serialized[:897]}..."
        return serialized

    def _tool_body_markdown(self, params: dict[str, Any], raw_result: str | None = None) -> str:
        payload = self._tool_payload_text(params)
        if raw_result is None:
            return self._normalize_markdown(f"```json\n{payload}\n```")
        result_payload = self._tool_result_text(raw_result)
        return self._normalize_markdown(f"Params:\n```json\n{payload}\n```\n\nResult:\n```json\n{result_payload}\n```")

    def _refresh_tool_card_details(self, state: dict[str, Any]) -> None:
        """Rebuild an existing tool card's details panel from its latest params."""
        card = state.get("card")
        params = state.get("params", {})
        if card is None or not isinstance(params, dict):
            return
        raw_result = state.get("result_raw")
        if not isinstance(raw_result, str):
            raw_result = None
        body = self._tool_body_markdown(params, raw_result)
        details = self._build_segment_widgets(body, role="tool")
        if not details:
            details = [Static("(no details)", classes="msg-body msg-tool")]

        try:
            contents = card.query_one(Collapsible.Contents)
        except Exception:
            contents = None

        if contents is not None:
            try:
                contents.remove_children()
            except Exception:
                pass
            for widget in details:
                try:
                    contents.mount(widget)
                except Exception:
                    # Best effort: avoid breaking tool flow if widget internals differ by Textual version.
                    break
            return

        # Fallback for unexpected widget states.
        for widget in details:
            try:
                card.mount(widget)
            except Exception:
                break

    @staticmethod
    def _canonical_tool_name(tool_name: str) -> str:
        """Normalize tool labels so early stream markers and real calls match."""
        raw = str(tool_name or "").strip()
        if not raw:
            return raw
        raw = raw.strip("`")
        match = re.match(r"^([A-Za-z_][A-Za-z0-9_:\.-]*)\s*\(", raw)
        if match:
            return match.group(1)
        return raw

    def write(
        self,
        content: Any,
        *_args: Any,
        **_kwargs: Any,
    ) -> "ConversationView":
        """Append plain text content to the transcript area."""
        plain = self._to_plain_text(content)
        if not plain:
            return self
        return self.write_markdown(plain)

    def write_markdown(self, text: str) -> "ConversationView":
        """Append markdown/plain text directly to the transcript."""
        if not text:
            return self
        self._append_plain(text)
        if self.is_mounted:
            self._render_markdown_segments(self._normalize_markdown(text), role="system")
        return self

    def clear(self) -> "ConversationView":
        """Clear transcript content."""
        self._plain_chunks.clear()
        self._stop_stream_timer()
        self._assistant_stream_needs_render = False
        self._assistant_stream_open = False
        self._assistant_stream_buffer = ""
        self._assistant_stream_widget = None
        self._assistant_stream_speaker = "Narrator"
        self._thinking_stream_needs_render = False
        self._thinking_stream_open = False
        self._thinking_stream_buffer = ""
        self._thinking_stream_widget = None
        self._thinking_stream_speaker = None
        self._tool_cards = []
        self._tool_spinner_frame = 0
        self._stop_tool_spinner()
        self._pending_execution_items = []
        self._execution_live_widget = None
        self._current_thinking_execution_item = None
        self._assistant_activity_widget = None
        self._assistant_activity_base = ""
        self._assistant_activity_pulse = 0
        self._assistant_activity_speaker = None
        self._assistant_activity_animating = False
        if self.is_mounted:
            self.remove_children()
        return self

    @staticmethod
    def _truncate_inline(text: str, max_len: int = 72) -> str:
        value = re.sub(r"\s+", " ", str(text or "")).strip()
        if len(value) <= max_len:
            return value
        return f"{value[: max_len - 3]}..."

    def _queue_execution_widget(self, widget: Any, summary: str, kind: str) -> dict[str, Any]:
        item = {
            "widget": widget,
            "summary": self._truncate_inline(summary),
            "kind": kind,
        }
        self._pending_execution_items.append(item)
        return item

    @staticmethod
    def _format_thinking_summary(label: str, thinking_label: str, text: str) -> str:
        prefix = f"[{label} {thinking_label}]"
        excerpt = re.sub(r"\s+", " ", str(text or "")).strip()
        if excerpt:
            return f"{prefix} {excerpt}"
        return prefix

    @staticmethod
    def _animated_suffix(frame: int) -> str:
        return [".", "..", "..."][frame % 3]

    def _tool_execution_summary(self, tool_name: str, params: dict[str, Any]) -> str:
        scope, base_name = ConversationView._split_scoped_tool_name(tool_name)
        normalized = str(base_name or "").strip().lower()
        actor = ""
        if scope:
            display_label, _thinking, _narrating, acting_label = self._resolve_agent_transcript_meta(scope)
            actor = f"[{display_label} {acting_label}] "
        if normalized == "task":
            target = str(params.get("agent_id", "") or "").strip()
            return f"{actor}delegate → {target}" if target else f"{actor}delegate"
        if normalized == "read_file":
            path = str(params.get("path", "") or "").strip()
            return f"{actor}read {path}" if path else f"{actor}read file"
        if normalized == "glob":
            pattern = str(params.get("pattern", "") or "").strip()
            return f"{actor}search {pattern}" if pattern else f"{actor}search files"
        if normalized == "ask_user":
            return f"{actor}await player action"
        return f"{actor}{ConversationView._tool_summary(tool_name, params)}"

    def _build_execution_summary_text(self) -> str:
        if not self._pending_execution_items:
            return "working..."
        parts: list[str] = []
        thinking_count = sum(1 for item in self._pending_execution_items if item.get("kind") == "thinking")
        if thinking_count:
            parts.append("thinking")
        tool_summaries = [
            str(item.get("summary", "")).strip()
            for item in self._pending_execution_items
            if item.get("kind") == "tool" and str(item.get("summary", "")).strip()
        ]
        if tool_summaries:
            preview = "; ".join(tool_summaries[:2])
            if len(tool_summaries) > 2:
                preview = f"{preview} +{len(tool_summaries) - 2}"
            parts.append(preview)
        return self._truncate_inline(" · ".join(parts) if parts else "working...", max_len=88)

    def _update_live_execution_preview(self) -> None:
        if not self._use_narrative_folding() or not self.is_mounted or not self._pending_execution_items:
            return
        text = self._build_execution_summary_text()
        content = f"[dim]{text}[/]"
        if self._execution_live_widget is None:
            self._execution_live_widget = Static(content, classes="msg-system execution-live")
            self.mount(self._execution_live_widget)
        else:
            self._execution_live_widget.update(content)
        self._safe_scroll_end()

    def _clear_live_execution_preview(self) -> None:
        if self._execution_live_widget is None:
            return
        try:
            self._execution_live_widget.remove()
        except Exception:
            pass
        self._execution_live_widget = None

    def _mount_assistant_activity_note(self, speaker_ref: str | None, *, animated: bool) -> None:
        if not self._use_narrative_folding() or not self.is_mounted:
            return
        speaker_key = str(speaker_ref or "Narrator").strip() or "Narrator"
        if self._assistant_activity_speaker == speaker_key and self._assistant_activity_widget is not None:
            if not animated:
                self._finalize_assistant_activity_note()
            return
        self._assistant_activity_pulse = 0
        label, _thinking, narrating_label, _acting = self._resolve_agent_transcript_meta(speaker_ref)
        _ = label
        self._assistant_activity_base = narrating_label
        text = narrating_label + (self._animated_suffix(self._assistant_activity_pulse) if animated else "")
        widget = Static(Text(text), classes="msg-system assistant-activity-line")
        self.mount(widget)
        self._assistant_activity_widget = widget
        self._assistant_activity_speaker = speaker_key
        self._assistant_activity_animating = animated

    def _finalize_assistant_activity_note(self) -> None:
        if self._assistant_activity_widget is not None:
            try:
                self._assistant_activity_widget.update(Text(self._assistant_activity_base))
            except Exception:
                pass
        self._assistant_activity_animating = False

    def _release_assistant_activity_tracking(self) -> None:
        self._assistant_activity_widget = None
        self._assistant_activity_base = ""
        self._assistant_activity_pulse = 0
        self._assistant_activity_speaker = None
        self._assistant_activity_animating = False

    def _mount_execution_summary_note(self) -> None:
        if not self._use_narrative_folding() or not self.is_mounted or not self._pending_execution_items:
            return
        summary = self._build_execution_summary_text()
        self._append_plain(f"_{summary}_\n")
        self.mount(Static(f"[dim]{summary}[/]", classes="msg-system execution-summary"))

    def _format_execution_fold_title(self) -> str:
        if not self._pending_execution_items:
            return f"[{self._EXECUTION_FOLD_TITLE_COLOR}]Behind the scene[/]"
        thinking_count = sum(1 for item in self._pending_execution_items if item.get("kind") == "thinking")
        tool_summaries = [
            str(item.get("summary", "")).strip()
            for item in self._pending_execution_items
            if item.get("kind") == "tool" and str(item.get("summary", "")).strip()
        ]
        parts: list[str] = []
        if thinking_count:
            parts.append("reasoning")
        if tool_summaries:
            preview = "; ".join(tool_summaries[:2])
            if len(tool_summaries) > 2:
                preview = f"{preview} +{len(tool_summaries) - 2}"
            parts.append(preview)
        if not parts:
            parts.append(f"{len(self._pending_execution_items)} steps")
        body = self._truncate_inline(" · ".join(parts), max_len=84)
        return f"[{self._EXECUTION_FOLD_TITLE_COLOR}]Behind the scene · {body}[/]"

    def flush_pending_execution_details(self) -> None:
        if not self._pending_execution_items or not self.is_mounted:
            return
        self._clear_live_execution_preview()
        self._mount_content_divider()
        widgets = [item.get("widget") for item in self._pending_execution_items if item.get("widget") is not None]
        if not widgets:
            self._pending_execution_items = []
            return
        card = Collapsible(
            *widgets,
            title=self._format_execution_fold_title(),
            collapsed=True,
            collapsed_symbol="▸",
            expanded_symbol="▾",
            classes="tool-collapsible msg-system execution-fold",
        )
        self.mount(card)
        self._pending_execution_items = []
        self._safe_scroll_end()

    @staticmethod
    def is_compact_summary_message(text: str) -> bool:
        content = str(text or "").strip()
        return content.startswith("[System: Previous conversation was compacted. Summary follows.]")

    @staticmethod
    def is_compact_ack_message(text: str) -> bool:
        content = str(text or "").strip()
        return content.startswith("Understood. I have the summary of our previous conversation")

    def add_compact_summary_fold(self, summary_text: str, acknowledgement: str | None = None) -> None:
        """Render compacted history as a collapsed narrative fold."""
        summary_body = self._normalize_markdown(str(summary_text or "").strip())
        ack = str(acknowledgement or "").strip()
        if ack:
            summary_body = f"{summary_body}\n\n---\n\n{ack}"
        if not summary_body:
            return
        if not self.is_mounted:
            self.write_markdown(f"\n### Story So Far\n\n{summary_body}\n")
            return
        self._mount_content_divider()
        self._append_plain(f"\n### Story So Far\n\n{summary_body}\n")
        details = self._build_segment_widgets(summary_body, role="system")
        if not details:
            details = [Static("(no summary)", classes="msg-body msg-system")]
        card = Collapsible(
            *details,
            title="[dim]Story so far (folded)[/]",
            collapsed=True,
            collapsed_symbol="▸",
            expanded_symbol="▾",
            classes="tool-collapsible msg-system",
        )
        self.mount(card)
        self._safe_scroll_end()

    def get_plain_text(self) -> str:
        """Get full conversation as plain text."""
        return "".join(self._plain_chunks).strip()

    def add_user_message(self, text: str) -> None:
        """Add a user message to the view."""
        # New user message should resume tail-following.
        self._resume_follow_output()
        self._clear_live_execution_preview()
        self._release_assistant_activity_tracking()
        self.flush_pending_execution_details()
        # New user-turn → reset per-turn speaker-header dedup state so the
        # next assistant response gets its own header.
        self._last_header_speaker_in_turn = None
        # Drop any leftover bridge segments from an aborted previous turn.
        self._bridge_segment_buffer.clear()
        lines = text.splitlines() or [text]
        quoted = "\n".join(f"> {line}" if line else ">" for line in lines)
        if not self.is_mounted:
            self.write_markdown(f"\n### You\n\n{quoted}\n")
            return
        self._append_plain(f"\n### You\n\n{quoted}\n")
        self._mount_role_header("You", "user")
        self._render_markdown_segments(quoted, role="user")

    def _ensure_stream_timer(self) -> None:
        if self._stream_render_timer is None:
            self._stream_render_timer = self.set_interval(1 / 15.0, self._tick_stream_render)

    def _stop_stream_timer(self) -> None:
        if self._stream_render_timer is not None:
            try:
                self._stream_render_timer.stop()
            except Exception:
                pass
            self._stream_render_timer = None

    def _tick_stream_render(self) -> None:
        if self._assistant_activity_widget is not None and self._assistant_activity_animating:
            self._assistant_activity_pulse = (self._assistant_activity_pulse + 1) % 3
            try:
                self._assistant_activity_widget.update(
                    Text(self._assistant_activity_base + self._animated_suffix(self._assistant_activity_pulse))
                )
            except Exception:
                pass

        if self._assistant_stream_needs_render and self._assistant_stream_widget is not None:
            if self._use_narrative_folding():
                rendered = self._build_semantic_stream_text(self._assistant_stream_buffer)
            else:
                rendered = self._sanitize_terminal_text(self._assistant_stream_buffer)
            try:
                self._assistant_stream_widget.update(rendered)
            except Exception:
                pass
            self._assistant_stream_needs_render = False
            self._safe_scroll_end()

        if self._thinking_stream_needs_render and self._thinking_stream_widget is not None:
            try:
                self._thinking_stream_widget.update(self._thinking_stream_buffer)
            except Exception:
                pass
            self._thinking_stream_needs_render = False
            self._safe_scroll_end()

    def add_assistant_chunk(self, text: str, speaker: str = "Narrator") -> None:
        """Add an assistant chunk (streaming).

        Speaker-header dedup: within a single user-turn, if the stream is
        re-opened with the SAME speaker (e.g. after a tool call flushed the
        segment), we do NOT emit another `### Speaker` header or role row —
        the tool cards render inline, and the narrative just continues under
        the already-mounted speaker label. `_last_header_speaker_in_turn` is
        reset when `add_user_message` or `add_assistant_end` fires.

        Hidden agents (presentation_hidden:true in agent.json) short-circuit
        at the top. They skip TUI render, session log, and bridge emit — the
        TUI is the single source of truth, and hidden means hidden everywhere.
        """
        if not text:
            return
        speaker_ref = str(speaker or "Narrator").strip() or "Narrator"
        if self._is_agent_hidden(speaker_ref):
            return
        display_label, _thinking_label, _narrating_label, _acting_label = self._resolve_agent_transcript_meta(speaker_ref)
        speaker_name = speaker_ref or display_label
        if self._assistant_stream_open and self._assistant_stream_speaker != speaker_name:
            self._flush_assistant_stream_segment()
        if not self._assistant_stream_open:
            self._assistant_stream_open = True
            self._assistant_stream_buffer = ""
            self._assistant_stream_speaker = speaker_name
            # Only emit a fresh speaker header when this speaker hasn't
            # already spoken in the current user-turn. Otherwise the stream
            # is just resuming after a tool call — keep it visually under
            # the previous header.
            suppress_header = (
                getattr(self, "_last_header_speaker_in_turn", None) == speaker_name
            )
            if not self.is_mounted:
                if not suppress_header:
                    self.write_markdown(f"\n### {display_label}\n\n")
            else:
                if not suppress_header:
                    self._append_plain(f"\n### {display_label}\n\n")
                    self._assistant_header_widget = self._mount_role_header(display_label, "assistant")
                    self._mount_assistant_activity_note(speaker_ref, animated=False)
                self._clear_live_execution_preview()
                self._mount_execution_summary_note()
                if self._use_narrative_folding():
                    self._assistant_stream_widget = Static(Text(""), classes="msg-body msg-assistant semantic-stream")
                else:
                    self._assistant_stream_widget = Markdown("", classes="msg-body msg-assistant")
                self.mount(self._assistant_stream_widget)
            self._last_header_speaker_in_turn = speaker_name
        if not self.is_mounted or self._assistant_stream_widget is None:
            self.write_markdown(text)
            return
        self._assistant_stream_buffer += text
        self._assistant_stream_buffer = re.sub(r"\n{3,}", "\n\n", self._assistant_stream_buffer)
        self._append_plain(text)
        self._ensure_stream_timer()
        self._assistant_stream_needs_render = True

    def _flush_assistant_stream_segment(self) -> None:
        """Close current streaming assistant segment while preserving stable scroll behavior."""
        if not self._assistant_stream_open:
            return

        # Capture this speaker's segment BEFORE we clear the buffer, so the
        # bridge emission at turn end can reconstruct the full turn even
        # across speaker changes (orchestrator → town-agent → character-agent)
        # or tool-call interruptions (ask_user).
        seg_text = self._assistant_stream_buffer
        seg_speaker = self._assistant_stream_speaker or "Narrator"
        has_content = bool(seg_text and seg_text.strip())
        if has_content:
            self._bridge_segment_buffer.append((seg_speaker, seg_text))

        if self.is_mounted:
            if self._assistant_stream_widget is not None:
                finalized = self._normalize_markdown(self._assistant_stream_buffer)
                stream_widget = self._assistant_stream_widget
                try:
                    if has_content:
                        self._render_markdown_segments(finalized, role="assistant", before=stream_widget)
                    stream_widget.remove()
                except Exception:
                    try:
                        stream_widget.update(finalized)
                    except Exception:
                        pass
            # Empty segment cleanup: scrub the speaker header + activity
            # note so the transcript doesn't carry a lonely "[Speaker]"
            # row with nothing under it (LLM produced a tool call then
            # delegated and said nothing visible itself).
            if not has_content:
                for ghost in (self._assistant_header_widget, self._assistant_activity_widget):
                    if ghost is not None:
                        try:
                            ghost.remove()
                        except Exception:
                            pass
                self._assistant_header_widget = None
                self._release_assistant_activity_tracking()

        self._assistant_stream_needs_render = False
        self._assistant_stream_open = False
        self._assistant_stream_buffer = ""
        self._assistant_stream_widget = None
        self._assistant_header_widget = None
        self._assistant_stream_speaker = "Narrator"
        self._finalize_assistant_activity_note()
        if getattr(self, "_thinking_stream_open", False) is False:
            self._stop_stream_timer()

    def add_thinking_chunk(self, text: str, speaker: str | None = None) -> None:
        """Append model thinking/reasoning chunk when provider exposes it.

        Hidden agents short-circuit here too — otherwise the reasoning
        stream briefly flashes on screen before the assistant segment
        check hides the actual narrative, giving the "peek-then-hide" UX.
        """
        if not text:
            return
        speaker_ref = str(speaker or "").strip() or None
        if speaker_ref and self._is_agent_hidden(speaker_ref):
            return
        display_label, thinking_label, _narrating_label, _acting_label = self._resolve_agent_transcript_meta(
            speaker_ref
        )
        speaker_name = speaker_ref or display_label
        if self._thinking_stream_open and self._thinking_stream_speaker != speaker_name:
            self._flush_thinking_stream_segment()

        if not self._thinking_stream_open:
            self._thinking_stream_open = True
            self._thinking_stream_buffer = ""
            self._thinking_stream_speaker = speaker_name
            label = f"[{display_label} {thinking_label}]"
            if not self.is_mounted:
                self.write_markdown(f"\n{label}")
            else:
                self._append_plain(f"\n{label}")
                self._thinking_stream_widget = Static("", classes="thinking-content")
                row = Horizontal(
                    Static(label, classes="thinking-label"),
                    self._thinking_stream_widget,
                    classes="thinking-row",
                )
                if self._use_narrative_folding():
                    self._mount_assistant_activity_note(speaker_ref or display_label, animated=True)
                    self._current_thinking_execution_item = self._queue_execution_widget(
                        row,
                        self._format_thinking_summary(display_label, thinking_label, ""),
                        kind="thinking",
                    )
                    self._update_live_execution_preview()
                else:
                    self.mount(row)

        if not self.is_mounted or self._thinking_stream_widget is None:
            self.write_markdown(text)
            return

        self._thinking_stream_buffer += text
        self._thinking_stream_buffer = re.sub(r"\n{3,}", "\n\n", self._thinking_stream_buffer)
        if self._current_thinking_execution_item is not None:
            self._current_thinking_execution_item["summary"] = self._truncate_inline(
                self._format_thinking_summary(display_label, thinking_label, self._thinking_stream_buffer),
                max_len=88,
            )
            self._update_live_execution_preview()
        self._append_plain(text)
        self._ensure_stream_timer()
        self._thinking_stream_needs_render = True

    def _flush_thinking_stream_segment(self) -> None:
        """Close current thinking segment while preserving current rendered content."""
        if not self._thinking_stream_open:
            return

        if self.is_mounted and self._thinking_stream_widget is not None:
            try:
                self._thinking_stream_widget.update(self._thinking_stream_buffer)
            except Exception:
                pass

        self._thinking_stream_needs_render = False
        self._thinking_stream_open = False
        self._thinking_stream_buffer = ""
        self._thinking_stream_widget = None
        self._thinking_stream_speaker = None
        self._current_thinking_execution_item = None
        if getattr(self, "_assistant_stream_open", False) is False:
            self._stop_stream_timer()

    def add_markdown_message(self, text: str) -> None:
        """Append a complete assistant message."""
        if not text.strip():
            return
        self._flush_thinking_stream_segment()
        self._flush_assistant_stream_segment()
        body = self._normalize_markdown(text.strip())
        if not self.is_mounted:
            self.write_markdown(f"\n### Narrator\n\n{body}\n")
            return
        self._append_plain(f"\n### Narrator\n\n{body}\n")
        self._mount_role_header("Narrator", "assistant")
        self._clear_live_execution_preview()
        self._mount_execution_summary_note()
        self._mount_assistant_activity_note("narrator", animated=False)
        self._render_markdown_segments(body, role="assistant")
        self.flush_pending_execution_details()

    def add_named_assistant_message(self, name: str, text: str) -> None:
        """Append a complete assistant-like message with a custom speaker name.

        Skips hidden agents entirely (no TUI, no session, no bridge).
        Unlike the streaming path, this is a one-shot whole message — so
        we also append directly to the per-turn bridge-segment buffer
        here, since there's no flush hook to capture it.
        """
        speaker_ref = str(name or "Sub-agent").strip() or "Sub-agent"
        if self._is_agent_hidden(speaker_ref):
            return
        display_label, _thinking_label, _narrating_label, _acting_label = self._resolve_agent_transcript_meta(speaker_ref)
        speaker = display_label
        if not text.strip():
            return
        self._flush_thinking_stream_segment()
        self._flush_assistant_stream_segment()
        # Mirror to the bridge buffer so the next `add_assistant_end`
        # (which Discord relies on) sees this one-shot narration.
        self._bridge_segment_buffer.append((speaker, text.strip()))
        body = self._normalize_markdown(text.strip())
        if not self.is_mounted:
            self.write_markdown(f"\n### {speaker}\n\n{body}\n")
            return
        self._append_plain(f"\n### {speaker}\n\n{body}\n")
        self._mount_role_header(speaker, "assistant")
        self._clear_live_execution_preview()
        self._mount_execution_summary_note()
        self._mount_assistant_activity_note(speaker_ref, animated=False)
        self._render_markdown_segments(body, role="assistant")
        self.flush_pending_execution_details()

    def _finalize_predicted_tool_indicators(
        self,
        confirmed_tool_name: str | None = None,
        detail: str = "not called",
    ) -> None:
        """Close unresolved predicted cards once real tool flow is known."""
        confirmed = self._canonical_tool_name(confirmed_tool_name or "") if confirmed_tool_name else ""
        updated = False
        for state in self._tool_cards:
            if state.get("done") or not state.get("predicted"):
                continue
            state_tool_name = self._canonical_tool_name(str(state.get("tool_name", "")))
            if confirmed and state_tool_name == confirmed:
                continue
            state["done"] = True
            state["ok"] = False
            state["detail"] = detail
            card = state.get("card")
            params = state.get("params", {})
            if not isinstance(params, dict):
                params = {}
            if card is not None:
                card.title = self._format_tool_title(
                    state_tool_name or "tool", params, detail=detail, done=True, ok=False
                )
            updated = True
        if updated:
            if all(state.get("done") for state in self._tool_cards):
                self._stop_tool_spinner()
            self._safe_scroll_end()

    def add_tool_indicator(self, tool_name: str, params: dict[str, Any], predicted: bool = False) -> None:
        """Add a tool use indicator."""
        tool_name = self._canonical_tool_name(tool_name)
        if not predicted:
            self._finalize_predicted_tool_indicators(confirmed_tool_name=tool_name)

        # Deduplicate/upgrade existing in-flight indicator for the same tool.
        for state in self._tool_cards:
            if state.get("done"):
                continue
            state_tool_name = self._canonical_tool_name(str(state.get("tool_name", "")))
            if state_tool_name != tool_name:
                continue
            state_params = state.get("params")
            state_predicted = bool(state.get("predicted"))
            if state_params == params and state_predicted == predicted:
                return
            # Upgrade predicted placeholder to a real running tool once confirmed.
            if state_predicted and not predicted:
                state["predicted"] = False
                state["detail"] = "running"
                if isinstance(state_params, dict) and not state_params and params:
                    state["params"] = params
                    self._refresh_tool_card_details(state)
                card = state.get("card")
                effective_params = state.get("params", params)
                if card is not None and isinstance(effective_params, dict):
                    card.title = self._format_tool_title(tool_name, effective_params, detail="running", done=False)
                self._safe_scroll_end()
                return
            # Upgrade an early placeholder (no params yet) once full args arrive.
            if isinstance(state_params, dict) and not state_params and params:
                state["params"] = params
                self._refresh_tool_card_details(state)
                card = state.get("card")
                if card is not None:
                    detail = "preparing" if bool(state.get("predicted")) else "running"
                    card.title = self._format_tool_title(tool_name, params, detail=detail, done=False)
                self._safe_scroll_end()
                return
            # If we already have an in-flight card for this tool and the new call has
            # no params (early calling marker), do not create duplicates.
            if not params:
                return

        # Seal current stream first so tool cards stay chronologically stable.
        self._flush_thinking_stream_segment()
        self._flush_assistant_stream_segment()

        body = self._tool_body_markdown(params)
        if not self.is_mounted:
            self.write_markdown(f"\n### Tool `{tool_name}`\n\n{body}\n")
            return
        self._append_plain(f"\n### Tool `{tool_name}`\n\n{body}\n")
        details = self._build_segment_widgets(body, role="tool")
        if not details:
            details = [Static("(no details)", classes="msg-body msg-tool")]
        card = Collapsible(
            *details,
            title=self._format_tool_title(
                tool_name,
                params,
                detail="preparing" if predicted else "running",
                done=False,
            ),
            collapsed=True,
            collapsed_symbol="▸",
            expanded_symbol="▾",
            classes="tool-collapsible msg-tool",
        )
        if self._use_narrative_folding():
            self._queue_execution_widget(card, self._tool_execution_summary(tool_name, params), kind="tool")
            self._update_live_execution_preview()
        else:
            self.mount(card)
        self._tool_cards.append(
            {
                "card": card,
                "tool_name": tool_name,
                "params": params,
                "result_raw": None,
                "done": False,
                "detail": "preparing" if predicted else "running",
                "ok": True,
                "predicted": predicted,
            }
        )
        self._ensure_tool_spinner()
        self._safe_scroll_end()

    def complete_tool_indicator(self, tool_name: str, params: dict[str, Any], raw_result: str) -> None:
        """Finalize one running tool indicator with concise result details."""
        tool_name = self._canonical_tool_name(tool_name)
        self._finalize_predicted_tool_indicators(confirmed_tool_name=tool_name)
        target: dict[str, Any] | None = None
        for state in self._tool_cards:
            if state.get("done"):
                continue
            state_tool_name = self._canonical_tool_name(str(state.get("tool_name", "")))
            if state_tool_name == tool_name and state.get("params") == params:
                target = state
                break
        if target is None:
            for state in self._tool_cards:
                if state.get("done"):
                    continue
                state_tool_name = self._canonical_tool_name(str(state.get("tool_name", "")))
                if state_tool_name == tool_name:
                    target = state
                    break
        if target is None:
            for state in self._tool_cards:
                if state.get("done") or state.get("predicted"):
                    continue
                target = state
                break
        if target is None:
            for state in self._tool_cards:
                if not state.get("done"):
                    target = state
                    break
        if target is None:
            return

        if params and isinstance(target.get("params"), dict) and not target.get("params"):
            target["params"] = params
            self._refresh_tool_card_details(target)

        ok, detail = self._tool_result_detail(tool_name, raw_result)
        target["done"] = True
        target["ok"] = ok
        target["detail"] = detail
        target["result_raw"] = raw_result
        target["predicted"] = False
        self._refresh_tool_card_details(target)
        card = target["card"]
        target_tool_name = str(target.get("tool_name", tool_name))
        target_params = target.get("params", params)
        if not isinstance(target_params, dict):
            target_params = params
        card.title = self._format_tool_title(target_tool_name, target_params, detail=detail, done=True, ok=ok)
        if all(state.get("done") for state in self._tool_cards):
            self._stop_tool_spinner()
        self._safe_scroll_end()

    def fail_open_tool_indicators(self, detail: str = "aborted") -> None:
        """Mark any running tool indicators as failed and stop spinner animation."""
        self._clear_live_execution_preview()
        updated = False
        for state in self._tool_cards:
            if state.get("done"):
                continue
            state["done"] = True
            state["ok"] = False
            state["detail"] = detail
            state["result_raw"] = json.dumps({"status": "error", "error": detail}, ensure_ascii=False)
            self._refresh_tool_card_details(state)
            card = state.get("card")
            tool_name = str(state.get("tool_name", "tool"))
            params = state.get("params", {})
            if not isinstance(params, dict):
                params = {}
            if card is not None:
                card.title = self._format_tool_title(tool_name, params, detail=detail, done=True, ok=False)
            updated = True
        if updated or self._tool_spinner_timer is not None:
            self._stop_tool_spinner()
            self._safe_scroll_end()

    def _format_tool_title(
        self,
        tool_name: str,
        params: dict[str, Any],
        detail: str,
        done: bool,
        ok: bool = True,
    ) -> str:
        summary = self._tool_summary(tool_name, params)
        # Keep a single space gap to avoid odd spacing with some terminal glyph rendering.
        gap = " "
        if done:
            # Keep completion marks understated (avoid emoji-heavy appearance).
            neutral_details = {"not called", "cancelled"}
            if str(detail or "").strip().lower() in neutral_details:
                icon = "○"
                color = self._NEUTRAL_COLOR
            else:
                icon = "✓" if ok else "✕"
                color = self._OK_COLOR if ok else self._ERR_COLOR
            return f"[{color}]{icon}[/]{gap}[{self._TOOL_TITLE_TEXT_COLOR}]{summary}[/]"
        idx = self._tool_spinner_frame % len(self._SPINNER_FRAMES)
        frame = self._SPINNER_FRAMES[idx]
        color = self._SPINNER_COLORS[idx % len(self._SPINNER_COLORS)]
        return f"[{color}]{frame}[/]{gap}[{self._TOOL_TITLE_TEXT_COLOR}]{summary}[/]"

    def _ensure_tool_spinner(self) -> None:
        if self._tool_spinner_timer is None:
            self._tool_spinner_timer = self.set_interval(0.18, self._tick_tool_spinner)

    def _stop_tool_spinner(self) -> None:
        if self._tool_spinner_timer is not None:
            try:
                self._tool_spinner_timer.stop()
            except Exception:
                pass
            self._tool_spinner_timer = None

    def _tick_tool_spinner(self) -> None:
        self._tool_spinner_frame = (self._tool_spinner_frame + 1) % len(self._SPINNER_FRAMES)
        for state in self._tool_cards:
            if state.get("done"):
                continue
            card = state["card"]
            card.title = self._format_tool_title(
                state["tool_name"],
                state["params"],
                detail=state.get("detail", "running"),
                done=False,
            )

    @staticmethod
    def _tool_result_detail(tool_name: str, raw_result: str) -> tuple[bool, str]:
        """Convert tool result JSON to short one-line detail."""
        try:
            payload = json.loads(raw_result)
        except Exception:
            return True, "done"

        status = str(payload.get("status", "success")).lower()
        if status == "cancelled":
            return False, "cancelled"
        ok = status in {"success", "proposal_submitted"}
        if not ok:
            err = str(payload.get("error", "failed"))
            err = err.replace("\n", " ")
            if len(err) > 50:
                err = f"{err[:47]}..."
            return False, err

        if status == "proposal_submitted" or tool_name == "submit_proposal":
            return True, "proposal ready"

        data = payload.get("data")
        if tool_name == "glob" and isinstance(data, dict):
            count = data.get("count")
            if isinstance(count, int):
                return True, f"{count} files"
            files = data.get("files")
            if isinstance(files, list):
                return True, f"{len(files)} files"
        if tool_name == "read_file" and isinstance(data, dict):
            content = str(data.get("content", ""))
            lines = len(content.splitlines()) if content else 0
            truncated = bool(data.get("truncated"))
            if truncated:
                return True, f"{lines} lines (truncated)"
            return True, f"{lines} lines"
        if tool_name == "ask_user":
            # New format: {"answers": {"0": "label"}} or old format: {"data": {"response": ...}}
            answers = data.get("answers") if isinstance(data, dict) else None
            if isinstance(answers, dict):
                first_answer = str(next(iter(answers.values()), "")).strip().replace("\n", " ")
                if first_answer:
                    if len(first_answer) > 36:
                        first_answer = f"{first_answer[:33]}..."
                    return True, f"selected: {first_answer}"
                return True, "answered"
            # Legacy fallback
            if isinstance(data, dict):
                response = str(data.get("response", "")).strip().replace("\n", " ")
                if response:
                    if len(response) > 36:
                        response = f"{response[:33]}..."
                    return True, f"selected: {response}"
            return True, "answered"

        return True, "done"

    def add_todo_display(self, items: list[dict]) -> None:
        """Add todo list display."""
        if not items:
            return
        lines = ["### Todo", ""]
        for item in items:
            status = item.get("status", "pending")
            content = item.get("content", "")
            if status in {"completed", "done"}:
                lines.append(f"- `[x]` {content}")
            elif status == "in_progress":
                lines.append(f"- `[>]` {content}")
            else:
                lines.append(f"- `[ ]` {content}")
        body = "\n".join(lines)
        if not self.is_mounted:
            self.write_markdown(f"\n{body}\n")
            return
        self._append_plain(f"\n{body}\n")
        self._mount_role_header("Todo", "system")
        self._render_markdown_segments("\n".join(lines[2:]), role="system")

    def add_skill_indicator(self, skill_name: str) -> None:
        """Add skill loading indicator."""
        if not self.is_mounted:
            self.write_markdown(f"\n### Skill\n\nLoading `{skill_name}`\n")
            return
        body = f"Loading `{skill_name}`"
        self._append_plain(f"\n### Skill\n\n{body}\n")
        self._mount_role_header("Skill", "system")
        self._render_markdown_segments(body, role="system")

    def set_semantic_mode(self, mode: str) -> None:
        """Enable L14.5 semantic-annotation footer for play / mcp modes."""
        self._semantic_mode = mode

    def set_semantic_layer(self, layer: int) -> None:
        """Switch transcript visibility: 1 = narrative only, 2 = + chips, 3 = + raw trace."""
        layer = max(1, min(3, int(layer)))
        for cls in ("layer-1", "layer-2", "layer-3"):
            try:
                self.remove_class(cls)
            except Exception:
                pass
        try:
            self.add_class(f"layer-{layer}")
        except Exception:
            pass
        self._semantic_layer = layer

    def add_assistant_end(self) -> None:
        """Mark end of assistant response."""
        self._flush_thinking_stream_segment()
        # Snapshot the buffer before it gets cleared by flush, so callers can
        # run post-hoc parsing (e.g. L14.5 semantic annotations in play/mcp).
        self._last_assistant_text = self._assistant_stream_buffer
        turn_text = self._assistant_stream_buffer
        if not self._assistant_stream_open:
            if not self.is_mounted:
                self.write_markdown("\n")
        else:
            if not self.is_mounted:
                self.write_markdown("\n")
            else:
                self._flush_assistant_stream_segment()
                self._append_plain("\n")
                self.flush_pending_execution_details()
                self._release_assistant_activity_tracking()
                self._safe_scroll_end()
        # Turn is finished — reset the per-turn header-dedup state so the
        # next turn's first assistant text gets a proper speaker header.
        self._last_header_speaker_in_turn = None

        # Bridge broadcast: emit from the accumulated per-segment buffer so
        # multi-speaker turns AND turns interrupted by tool calls (ask_user)
        # get a complete relay. In play/mcp mode we keep only the primary
        # narrator's segments — sub-agents (town-agent, character-agent) are
        # internal state-updaters that would clutter Discord.
        segments = list(self._bridge_segment_buffer)
        self._bridge_segment_buffer.clear()
        self._emit_turn_to_bridges(segments)

        # L14.5 — append semantic chips below the narrative in play / mcp mode.
        semantic_mode = getattr(self, "_semantic_mode", "")
        speaker_for_parse = segments[0][0] if segments else (
            getattr(self, "_assistant_stream_speaker", "") or "world"
        )
        if semantic_mode in ("play", "mcp") and turn_text:
            try:
                from neonrp.core.semantic_events import (
                    SEMANTIC_EVENT_ENABLED_MODES,
                    parse_semantic_events,
                )
                if semantic_mode in SEMANTIC_EVENT_ENABLED_MODES:
                    events = parse_semantic_events(
                        turn_text,
                        speaker_hint=speaker_for_parse,
                        mode=semantic_mode,
                    )
                    if events:
                        self.emit_semantic_annotations(events)
            except Exception:
                # Rendering errors must never break transcript flow.
                pass

    def _emit_turn_to_bridges(self, segments: list[tuple[str, str]]) -> None:
        """Fan out a completed turn to registered bridges (Discord etc).

        `segments` already excludes hidden agents — they were short-circuited
        at the `add_assistant_chunk` / `add_named_assistant_message` entry
        point. So whatever reaches here also reached the TUI, by design.

        We emit one merged message per turn, joined by blank lines, using
        the first visible speaker's name as the Discord header. This keeps
        Discord messages coherent rather than one-chunk-per-post.
        """
        if not segments:
            return
        try:
            app = self._get_app_context()
            emit = getattr(app, "_emit_bridge_event", None)
            if not callable(emit):
                return
            speaker = segments[0][0]
            text = "\n\n".join(tx.strip() for _sp, tx in segments if tx.strip())
            if text.strip():
                emit("narrator_text", speaker=speaker or "World", text=text.strip())
        except Exception:
            pass

    def get_last_assistant_text(self) -> str:
        """Return the raw text of the most recently completed assistant turn."""
        return getattr(self, "_last_assistant_text", "") or ""

    def emit_semantic_annotations(self, events: list[Any]) -> None:
        """Render L2 semantic chips below the latest assistant turn (L14.5).

        Accepts a list of `SemanticEvent` objects. Only the subset with
        layer=='L2' (state_update / rule_check / execution_summary) is
        rendered — L1 events are already visible in the streamed text.
        Unknown layers are ignored.
        """
        if not events or not self.is_mounted:
            return
        try:
            from neonrp.core.semantic_events import SemanticEvent as _SE  # local import
        except Exception:
            _SE = None
        lines: list[str] = []
        icon_map = {
            "state_update":       "⟳",
            "rule_check":         "◉",
            "execution_summary":  "∴",
        }
        color_map = {
            "state_update":       "#86EFAC",
            "rule_check":         "#FCD34D",
            "execution_summary":  "#A5B4FC",
        }
        for ev in events:
            layer = getattr(ev, "layer", None)
            etype = getattr(ev, "type", None)
            text = (getattr(ev, "text", "") or "").strip()
            if layer != "L2" or etype not in icon_map or not text:
                continue
            icon = icon_map[etype]
            color = color_map[etype]
            lines.append(f"[dim]{icon}[/] [{color}]{text}[/]")
        if not lines:
            return
        try:
            self.mount(
                Static(
                    "\n".join(lines),
                    classes="msg-body msg-semantic-footer",
                )
            )
            self._safe_scroll_end()
        except Exception:
            pass

    def action_copy_selection(self) -> None:
        """Copy full transcript text to clipboard."""
        transcript = self.get_plain_text()
        if transcript:
            self.app.copy_to_clipboard(transcript)
            self.notify(f"Copied {len(transcript)} chars")

    @classmethod
    def _sanitize_terminal_text(cls, text: str) -> str:
        """Sanitize text sequences that can break Rich/Textual width calculation."""
        cleaned = cls._UNSAFE_CONTROL_RE.sub("", text)
        clusters = cls._GRAPHEME_CLUSTER_RE.findall(cleaned)
        safe_clusters: list[str] = []
        for cluster in clusters:
            if cluster == "\u200d":
                continue
            if cluster.endswith("\u200d"):
                cluster = cls._DANGLING_ZWJ_RE.sub("", cluster)
                cluster = cluster.rstrip("\u200d")
                if not cluster:
                    continue
            safe_clusters.append(cluster)
        return "".join(safe_clusters)

    @classmethod
    def _normalize_markdown(cls, text: str) -> str:
        """Normalize markdown code fences for better readability/highlighting."""

        normalized_text = cls._KEYCAP_RE.sub(r"\1", text)
        normalized_text = cls._sanitize_terminal_text(normalized_text)

        def repl(match: re.Match[str]) -> str:
            lang = (match.group(1) or "").strip().lower()
            body = match.group(2).strip()
            if lang == "json":
                try:
                    parsed = json.loads(body)
                    body = json.dumps(parsed, ensure_ascii=False, indent=2)
                except Exception:
                    pass
            if lang:
                return f"```{lang}\n{body}\n```"
            return f"```\n{body}\n```"

        return cls._FENCED_CODE_RE.sub(repl, normalized_text)


class AskUserInlinePanel(Container):
    """Inline ask_user panel rendered between conversation and main input."""

    CANCEL_RESULT = "__ask_user_cancelled__"
    BINDINGS = [Binding("escape", "cancel", "Cancel")]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._question = ""
        self._options: list[str] = []
        self._on_submit: Callable[[str], None] | None = None

    def compose(self) -> ComposeResult:
        locale = getattr(self.app, "ui_locale", None) or getattr(self.app, "locale", "en")
        placeholder = get_message(locale or "en", "ask_user.placeholder")
        esc_hint = get_message(locale or "en", "ui.hint.esc_cancel")
        yield Static("", id="ask-inline-question")
        with VerticalScroll(id="ask-inline-options-scroll"):
            yield Vertical(id="ask-inline-options")
        yield Input(placeholder=placeholder, id="ask-inline-input")
        with Horizontal(id="ask-inline-actions"):
            yield Static(f"[dim]{esc_hint}[/]", id="ask-inline-hint")

    def on_mount(self) -> None:
        self.add_class("hidden")

    @property
    def is_active(self) -> bool:
        return self._on_submit is not None

    def show_prompt(self, question: str, options: list[str], on_submit: Any) -> None:
        """Render prompt + options and wait for user response."""
        self._question = str(question or "").strip()
        self._options = [str(opt or "").strip() for opt in options if str(opt or "").strip()]
        self._on_submit = on_submit

        question_widget = self.query_one("#ask-inline-question", Static)
        question_widget.update(f"[bold]{self._question}[/]" if self._question else "[bold]Question[/]")

        options_box = self.query_one("#ask-inline-options", Vertical)
        options_box.remove_children()
        if self._options:
            for i, opt in enumerate(self._options):
                options_box.mount(Button(f"{i + 1}. {opt}", id=f"ask-inline-opt-{i}", variant="default"))
        else:
            options_box.mount(Static("[dim](No options provided; please type your response.)[/]"))

        hint_widget = self.query_one("#ask-inline-hint", Static)
        self.remove_class("options-only")
        locale = getattr(self.app, "ui_locale", None) or getattr(self.app, "locale", "en")
        hint_widget.update(f"[dim]{get_message(locale or 'en', 'ui.hint.esc_cancel_enter_submit')}[/]")

        ask_input = self.query_one("#ask-inline-input", Input)
        ask_input.value = ""
        self.remove_class("hidden")
        self.add_class("visible")
        ask_input.focus()

    def hide_prompt(self) -> None:
        """Hide panel and clear pending prompt state."""
        self._on_submit = None
        self._question = ""
        self._options = []
        self.remove_class("visible")
        self.add_class("hidden")
        try:
            self.query_one("#ask-inline-options", Vertical).remove_children()
        except Exception:
            pass

    def cancel_current(self) -> bool:
        """Cancel current prompt if one is active."""
        if not self.is_active:
            return False
        self._submit(self.CANCEL_RESULT)
        return True

    def _submit(self, value: str) -> None:
        callback = self._on_submit
        self.hide_prompt()
        if callback is not None:
            callback(value)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id.startswith("ask-inline-opt-"):
            idx = int(btn_id.split("-")[-1])
            if 0 <= idx < len(self._options):
                self._submit(self._options[idx])
                event.stop()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "ask-inline-input":
            return
        value = event.value.strip()
        if value:
            self._submit(value)
        else:
            self._submit(self.CANCEL_RESULT)
        event.stop()

    def action_cancel(self) -> None:
        self.cancel_current()


class AskUserScreen(ModalScreen[str]):
    """Modal dialog for agent ask_user questions."""

    CANCEL_RESULT = "__ask_user_cancelled__"

    CSS = """
    AskUserScreen {
        align: center bottom;
        background: transparent;
    }

    #ask-modal {
        width: 92%;
        max-width: 112;
        min-height: 7;
        max-height: 60%;
        background: #09090B;
        border: round #A78BFA;
        padding: 1 2;
        layout: vertical;
        margin: 0 0 2 0;
    }

    #ask-question {
        height: auto;
        margin: 0 0 1 0;
        color: #E4E4E7;
    }

    #ask-options-scroll {
        width: 1fr;
        max-height: 14;
        overflow-y: scroll;
        margin: 0 0 1 0;
    }

    #ask-options {
        height: auto;
        margin: 0;
    }

    #ask-options Button {
        width: 100%;
        height: 1;
        margin-bottom: 0;
        background: #09090B;
        color: #D4D4D8;
        border: none;
        padding: 0 1;
        content-align: left middle;
    }

    #ask-options Button:focus {
        background: #18181B;
        color: #4ADE80;
        text-style: bold;
    }

    #ask-input {
        background: #09090B;
        color: #E4E4E7;
        border: none;
    }

    #ask-actions Button {
        background: #09090B;
        color: #71717A;
        border: none;
        padding: 0 1;
        height: 1;
    }

    #ask-actions Button:focus {
        color: #A1A1AA;
        text-style: bold;
    }

    #ask-input {
        margin: 0;
    }

    #ask-actions {
        width: 1fr;
        margin: 1 0 0 0;
    }

    #ask-toggle {
        width: auto;
        margin: 0 1 0 0;
    }

    #ask-cancel {
        width: auto;
    }

    #ask-modal.compact {
        min-height: 4;
        max-height: 5;
    }

    #ask-modal.compact #ask-options-scroll {
        display: none;
    }

    #ask-modal.compact #ask-input {
        display: none;
    }

    #ask-modal.compact #ask-actions {
        margin: 0;
    }
    """

    BINDINGS = [Binding("escape", "cancel", "Cancel")]

    def __init__(self, question: str, options: list[str]):
        super().__init__()
        self._question = question
        self._options = options
        self._compact = False

    def compose(self) -> ComposeResult:
        with Container(id="ask-modal"):
            yield Static(f"[bold]{self._question}[/]", id="ask-question")
            with VerticalScroll(id="ask-options-scroll"):
                if self._options:
                    with Vertical(id="ask-options"):
                        for i, opt in enumerate(self._options):
                            yield Button(f"{i + 1}. {opt}", id=f"ask-opt-{i}", variant="default")
            yield Input(placeholder="Type your response (or pick an option above)...", id="ask-input")
            with Horizontal(id="ask-actions"):
                yield Button("Minimize", id="ask-toggle", variant="default")
                yield Button("Cancel", id="ask-cancel", variant="error")

    def on_mount(self) -> None:
        self.query_one("#ask-input", Input).focus()
        self._apply_compact_state()

    def _apply_compact_state(self) -> None:
        modal = self.query_one("#ask-modal", Container)
        toggle = self.query_one("#ask-toggle", Button)
        if self._compact:
            modal.add_class("compact")
            toggle.label = "Expand"
        else:
            modal.remove_class("compact")
            toggle.label = "Minimize"

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "ask-toggle":
            self._compact = not self._compact
            self._apply_compact_state()
            if not self._compact:
                self.query_one("#ask-input", Input).focus()
            return
        if btn_id == "ask-cancel":
            self.dismiss(self.CANCEL_RESULT)
            return
        if btn_id.startswith("ask-opt-"):
            idx = int(btn_id.split("-")[-1])
            if 0 <= idx < len(self._options):
                self.dismiss(self._options[idx])

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "ask-input":
            value = event.value.strip()
            if value:
                self.dismiss(value)
            else:
                self.dismiss(self.CANCEL_RESULT)

    def action_cancel(self) -> None:
        self.dismiss(self.CANCEL_RESULT)


def section(title: str) -> tuple[str, str]:
    """Build a centered section-header row for ChoicePickerScreen options."""
    return (title, "__section__")


def spacer() -> tuple[str, str]:
    """Build a blank spacer row for ChoicePickerScreen options."""
    return ("", "__spacer__")


class ChoicePickerScreen(ModalScreen[str | None]):
    """Generic modal picker with section headers + spacers.

    Options list supports three kinds of rows:
    - Selectable option: ``(label, value)`` — left-aligned Button
    - Section header:    ``(title, "__section__")`` — centered Static, bold
    - Spacer:            ``("", "__spacer__")``     — blank line

    Keyboard navigation skips non-selectable rows.
    """

    CSS = """
    ChoicePickerScreen {
        align: center middle;
        background: #09090B;
    }

    #choice-modal {
        width: 80%;
        max-width: 96;
        max-height: 85%;
        background: #09090B;
        border: round #A78BFA;
        padding: 1 2;
        layout: vertical;
    }

    #choice-title {
        height: auto;
        margin-bottom: 0;
        color: #E4E4E7;
        text-style: bold;
        content-align: center middle;
    }

    #choice-hint {
        height: auto;
        margin-bottom: 1;
        color: #71717A;
        content-align: center middle;
    }

    #choice-list {
        height: 1fr;
        margin-bottom: 1;
        overflow-y: auto;
    }

    #choice-list Button {
        width: 100%;
        height: 1;
        margin-bottom: 0;
        background: #09090B;
        color: #D4D4D8;
        border: none;
        padding: 0 1;
        content-align: left middle;
        text-style: none;
    }

    #choice-list Button:focus {
        background: #18181B;
        color: #4ADE80;
        text-style: bold;
    }

    #choice-list .section-header {
        width: 100%;
        height: 1;
        margin: 0;
        padding: 0 1;
        color: #A78BFA;
        content-align: center middle;
        text-style: bold;
    }

    #choice-list .row-spacer {
        width: 100%;
        height: 1;
        background: #09090B;
    }

    #choice-actions {
        height: auto;
        color: #71717A;
    }

    #choice-actions Button {
        background: #09090B;
        color: #71717A;
        border: none;
        padding: 0 1;
        height: 1;
    }

    #choice-actions Button:focus {
        color: #A1A1AA;
        text-style: bold;
    }
    """

    BINDINGS = [
        Binding("up", "move_prev", "Prev"),
        Binding("down", "move_next", "Next"),
        Binding("left", "move_prev", "Prev"),
        Binding("right", "move_next", "Next"),
        Binding("tab", "move_next", "Next"),
        Binding("shift+tab", "move_prev", "Prev"),
        Binding("enter", "confirm", "Confirm"),
        Binding("escape", "cancel", "Cancel"),
    ]

    def __init__(self, title: str, options: list[tuple[str, str]], hint: str | None = None):
        super().__init__()
        self._title = title
        self._options = options
        # Default hint resolved lazily in `compose` via `self.app.ui_locale`
        # so it honors the user's selected language. Callers may still pass
        # an explicit hint string.
        self._hint = hint
        # Index of the currently focused row in `options` (may point at a
        # selectable row only; headers/spacers are always skipped).
        self._focus_index = self._first_selectable_index()

    def _is_selectable(self, idx: int) -> bool:
        if not (0 <= idx < len(self._options)):
            return False
        _, value = self._options[idx]
        return value not in ("__section__", "__spacer__")

    def _first_selectable_index(self) -> int:
        for i in range(len(self._options)):
            if self._is_selectable(i):
                return i
        return 0

    def _last_selectable_index(self) -> int:
        for i in range(len(self._options) - 1, -1, -1):
            if self._is_selectable(i):
                return i
        return 0

    def _next_selectable_from(self, start: int, direction: int) -> int:
        """Return next selectable index moving in `direction` (+1/-1), wrapping."""
        if not self._options:
            return 0
        n = len(self._options)
        for step in range(1, n + 1):
            idx = (start + direction * step) % n
            if self._is_selectable(idx):
                return idx
        return start  # no selectable rows

    def compose(self) -> ComposeResult:
        hint = self._hint
        if hint is None:
            locale = getattr(self.app, "ui_locale", None) or getattr(self.app, "locale", "en")
            hint = get_message(locale or "en", "ui.hint.picker_default")
        with Container(id="choice-modal"):
            yield Static(f"[bold #A78BFA]◆[/] [bold]{self._title}[/]", id="choice-title")
            yield Static(f"[dim]{hint}[/]", id="choice-hint")
            with VerticalScroll(id="choice-list"):
                for i, (label, value) in enumerate(self._options):
                    if value == "__section__":
                        yield Static(label, classes="section-header")
                    elif value == "__spacer__":
                        yield Static("", classes="row-spacer")
                    else:
                        yield Button(label, id=f"choice-opt-{i}", variant="default")
            with Horizontal(id="choice-actions"):
                yield Button("Back", id="choice-cancel", variant="default")

    def on_mount(self) -> None:
        self._focus_button(self._first_selectable_index())

    def _focus_button(self, index: int) -> None:
        if not self._options:
            return
        if not self._is_selectable(index):
            index = self._next_selectable_from(index - 1, 1)
        self._focus_index = index
        try:
            self.query_one(f"#choice-opt-{index}", Button).focus()
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "choice-cancel":
            self.dismiss(None)
            return
        if not btn_id.startswith("choice-opt-"):
            return
        idx = int(btn_id.split("-")[-1])
        if not self._is_selectable(idx):
            return
        self._focus_index = idx
        self.dismiss(self._options[idx][1])

    def action_move_prev(self) -> None:
        self._focus_button(self._next_selectable_from(self._focus_index, -1))

    def action_move_next(self) -> None:
        self._focus_button(self._next_selectable_from(self._focus_index, 1))

    def action_confirm(self) -> None:
        if self._is_selectable(self._focus_index):
            self.dismiss(self._options[self._focus_index][1])

    def action_cancel(self) -> None:
        self.dismiss(None)


# ---------------------------------------------------------------------------
# Specialized picker subclasses — all share ChoicePickerScreen's section /
# spacer support, keyboard nav, and styling. Each only customizes its title.
# Kept as distinct types so existing callers and tests (isinstance checks)
# keep working.
# ---------------------------------------------------------------------------

class SessionPickerScreen(ChoicePickerScreen):
    """Modal for selecting a saved session or starting a new one."""

    def __init__(self, branch: str, options: list[tuple[str, str]]):
        super().__init__(f"Sessions ({branch})", options)


class ModelPickerScreen(ChoicePickerScreen):
    """Modal for selecting an active model_ref."""

    def __init__(self, options: list[tuple[str, str]]):
        super().__init__("Select Active Model", options)


class SavePickerScreen(ChoicePickerScreen):
    """Modal for selecting a save snapshot to load."""

    def __init__(self, options: list[tuple[str, str]]):
        super().__init__("Load Snapshot", options)


class WorldPickerScreen(ChoicePickerScreen):
    """Modal for selecting a WorldLines world template."""

    def __init__(self, options: list[tuple[str, str]]):
        super().__init__("Choose WorldLines World", options)


class SpinnerWorkerScreen(ModalScreen[str]):
    """Run a blocking worker in a thread while showing an animated spinner.

    The worker returns a result string which is passed to the caller via the
    usual `push_screen(..., on_dismiss)` callback. Esc cancels — the worker
    thread keeps running but its result is discarded.
    """

    CSS = """
    SpinnerWorkerScreen {
        align: center middle;
        background: #09090B;
    }

    #spinner-modal {
        width: 60%;
        max-width: 80;
        min-height: 7;
        background: #09090B;
        border: round #A78BFA;
        padding: 1 2;
        layout: vertical;
    }

    #spinner-title {
        height: auto;
        color: #E4E4E7;
        text-style: bold;
        content-align: center middle;
        margin-bottom: 1;
    }

    #spinner-body {
        height: auto;
        color: #D4D4D8;
        content-align: center middle;
    }

    #spinner-hint {
        height: auto;
        color: #71717A;
        content-align: center middle;
        margin-top: 1;
    }
    """

    BINDINGS = [Binding("escape", "cancel", "Cancel")]

    _FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, title: str, label: str, worker: Callable[[], str], hint: str | None = None):
        super().__init__()
        self._title = title
        self._label = label
        self._worker = worker
        self._hint = hint
        self._frame_idx = 0
        self._result: str | None = None
        self._done = False
        self._tick_timer: Any = None

    def compose(self) -> ComposeResult:
        hint = self._hint
        if hint is None:
            locale = getattr(self.app, "ui_locale", None) or getattr(self.app, "locale", "en")
            hint = get_message(locale or "en", "ui.hint.esc_cancel")
        with Container(id="spinner-modal"):
            yield Static(f"[bold #A78BFA]◆[/] [bold]{self._title}[/]", id="spinner-title")
            yield Static(self._render_body(), id="spinner-body")
            yield Static(f"[dim]{hint}[/]", id="spinner-hint")

    def _render_body(self) -> str:
        frame = self._FRAMES[self._frame_idx % len(self._FRAMES)]
        return f"[#A78BFA]{frame}[/]  {self._label}"

    def on_mount(self) -> None:
        self._tick_timer = self.set_interval(0.08, self._tick_spinner)
        threading.Thread(target=self._run_worker, daemon=True, name="spinner-worker").start()

    def _tick_spinner(self) -> None:
        if self._done:
            return
        self._frame_idx = (self._frame_idx + 1) % len(self._FRAMES)
        try:
            self.query_one("#spinner-body", Static).update(self._render_body())
        except Exception:
            pass

    def _run_worker(self) -> None:
        try:
            result = self._worker()
        except Exception as exc:
            result = f"✗  {exc}"
        self._result = result
        self._done = True
        try:
            self.app.call_from_thread(self._finish)
        except Exception:
            pass

    def _finish(self) -> None:
        self._stop_timer()
        self.dismiss(self._result or "")

    def _stop_timer(self) -> None:
        if self._tick_timer is not None:
            try:
                self._tick_timer.stop()
            except Exception:
                pass
            self._tick_timer = None

    def action_cancel(self) -> None:
        # User cancelled before worker finished — leave the daemon thread to
        # finish on its own; we just discard the result.
        self._done = True
        self._stop_timer()
        self.dismiss("")


class TextInputScreen(ModalScreen[str | None]):
    """Generic modal text input used by WorldLines settings + create flows.

    Pure-TUI styling: no thick border, a single prompt line ("> ") in the
    spirit of Claude Code's input shell.
    """

    CSS = """
    TextInputScreen {
        align: center middle;
        background: #09090B;
    }

    #text-input-modal {
        width: 80%;
        max-width: 96;
        background: #09090B;
        border: round #A78BFA;
        padding: 1 2;
        layout: vertical;
    }

    #text-input-title {
        height: auto;
        margin-bottom: 0;
        color: #E4E4E7;
        text-style: bold;
    }

    #text-input-hint {
        height: auto;
        margin-bottom: 1;
        color: #71717A;
    }

    #text-input-field {
        height: 3;
        margin-bottom: 1;
        background: #09090B;
        color: #E4E4E7;
        border: none;
    }

    #text-input-actions {
        height: auto;
    }

    #text-input-actions Button {
        background: #09090B;
        color: #71717A;
        border: none;
        padding: 0 1;
        height: 1;
    }

    #text-input-actions Button:focus {
        color: #4ADE80;
        text-style: bold;
    }
    """

    BINDINGS = [
        Binding("enter", "submit", "Submit"),
        Binding("escape", "cancel", "Cancel"),
    ]

    def __init__(self, title: str, default: str = "", hint: str | None = None):
        super().__init__()
        self._title = title
        self._default = default
        self._hint = hint

    def compose(self) -> ComposeResult:
        hint = self._hint
        if hint is None:
            locale = getattr(self.app, "ui_locale", None) or getattr(self.app, "locale", "en")
            hint = get_message(locale or "en", "ui.hint.text_input_default")
        with Container(id="text-input-modal"):
            yield Static(f"[bold #A78BFA]▸[/] [bold]{self._title}[/]", id="text-input-title")
            yield Static(f"[dim]{hint}[/]", id="text-input-hint")
            yield Input(value=self._default, id="text-input-field")
            with Horizontal(id="text-input-actions"):
                yield Button("Save", id="text-input-save", variant="primary")
                yield Button("Cancel", id="text-input-cancel")

    def on_mount(self) -> None:
        try:
            self.query_one("#text-input-field", Input).focus()
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "text-input-save":
            self._submit_value()
        elif btn_id == "text-input-cancel":
            self.dismiss(None)

    def action_submit(self) -> None:
        self._submit_value()

    def action_cancel(self) -> None:
        self.dismiss(None)

    def _submit_value(self) -> None:
        try:
            value = self.query_one("#text-input-field", Input).value
        except Exception:
            value = self._default
        self.dismiss(value)


class WorldLinesLauncherApp(App[None]):
    """Guided startup flow for the public `worldlines` entry command."""

    ASCII_LOGO = dedent(
        r"""
        $ Agents for RolePlay
        """
    ).strip("\n")

    ASCII_TITLE = dedent(
        r"""
        ██╗    ██╗ ██████╗ ██████╗ ██╗     ██████╗  ██╗     ██╗███╗   ██╗███████╗███████╗
        ██║    ██║██╔═══██╗██╔══██╗██║     ██╔══██╗ ██║     ██║████╗  ██║██╔════╝██╔════╝
        ██║ █╗ ██║██║   ██║██████╔╝██║     ██║  ██║ ██║     ██║██╔██╗ ██║█████╗  ███████╗
        ██║███╗██║██║   ██║██╔══██╗██║     ██║  ██║ ██║     ██║██║╚██╗██║██╔══╝  ╚════██║
        ╚███╔███╔╝╚██████╔╝██║  ██║███████╗██████╔╝ ███████╗██║██║ ╚████║███████╗███████║
        ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝ ╚ ══════╝╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝
                                                                    
        """
    ).strip("\n")

    ASCII_DIVIDER = "-" * 48

    ASCII_GRAPH = dedent(
        r"""
                                                                                        
                                  ░▒▓▓▓▓▓▓▓▒░                                   
                                ▒▓▓▓▓▓▓▓▓▓▓▓▓▓▒░                                
 ░       ░                    ░▒▓▓▓▒▓▓▓▓▓▓▓▒▓▓▓▒░                               
   ░       ░░░    ░░         ░▒▓▓▓▓▓▓▓▓▓▓▓▒ ▒▓▓▓▒░            ░░░               
     ░░▒▒     ░▒   ░░░░      ░▓▓▓▓▓▓▓▓▓▓▒▒▒ ▒▓▓▓▓░░       ░░ ░░  ░░░    ░░▒░░   
      ░░░▒░▒░         ░░░░░  ░▒▓▓▒▓▓▓▓▓▓░    ▒▓▓▓▒░░   ░░░░░░░░▒▒░     ░▒▒░░    
       ░░░▒▒▒▒░ ░   ░░░░░  ░░░░▓▓▓▓▓▓▒▒▓     ░▓▒▒▒░░░░░     ░░▒░░░░░░▒░░░░      
░ ░     ░░░░▒▒▓░░   ░░░▒▒▒▒▒░░░▒▓▓▓▓▓▒░░      ░ ░░▒▒▒░░░░░▒▒▒▒░░░░░▒▒▒▒░░░      
    ░░░░  ░░▒░░▒▒▒░░ ░ ░░▒▒▒▓▓▓▒▒▓░▒▓░           ░▒ ▒▒▒▓▓▓▓▒▒▒░░▒▓▒▒░░     ░    
░░░░░     ░░░░░░▒▒▒▒▓▒▒▒▒▒▒▒▒▒▒▓▓▒                  ▓▓▓▓▓▒▒▒▒▒▒▒░░░░░░░   ░░░░░░
    ░░░░░░░░░░░░░░░░░░▒▒▒▒▓▓▓▓▓▒░░                   ░░▒▒▒▒▒░░░░░░░▒░░░░░░░     
      ░░░░  ░▒▒▒░▒▒▒▒▒▒▒▒▒▒░                            ▒▒▒▒▒▒▒▒▒▒▒░░░░░        
               ░░▒▒▒▒▓▒▒░                                ░▓▒▒▒▒▒░               
          ░░░░░░░░░░            ░▒▓░░                        ░░░░        ░░     
            ░░░             ░░░░░▓▓▒░░                           ░░░░░░         
                          ░░░▒▓▒▒▓▒░░                                           
  ░░                   ░░░░░▒▓▓▓▒▓▒░░               ░░░░░░░░░░░ ░               
     ░░░                  ░░▒▓▓▒▒▒░░░                                        ░  
       ░░▒░░░░ ░░        ░░░▒▓▓▓▒░░░░░░         ░░░                        ░    
           ░▒▒▒░░░░░░░░▒▒▒▒▒▓▓▒▓▒▒▒░░░░░░░░░░                       ░ ░░░░░░    
    ░          ░░░▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒░░░░░░░                 ░░░░░░          
             ░░▒░░░░░░░    ░░ ░░▒░░░░░▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░            ░   
     ░░░░    ░░░            ░    ░   ░  ░░░   ░░░░░░▒▒▒▒▒▒▒▒░░    ░░  ░         
       ░                  ░          ░░     ░    ░░      ░   ░░░░░░░            
                               ░       ░    ░      ░░ ░                         
                                             ░                                  

    
        """)

    BINDINGS = [
        Binding("up", "move_prev", "Prev"),
        Binding("down", "move_next", "Next"),
        Binding("left", "move_prev", "Prev"),
        Binding("right", "move_next", "Next"),
        Binding("tab", "move_next", "Next"),
        Binding("shift+tab", "move_prev", "Prev"),
        Binding("enter", "confirm_choice", "Confirm"),
        Binding("c", "continue_flow", "Continue"),
        Binding("n", "new_flow", "New"),
        Binding("s", "settings_flow", "Settings"),
        Binding("escape", "quit_launcher", "Quit"),
    ]

    CSS = """
    WorldLinesLauncherApp {
        background: #09090B;
        color: #E4E4E7;
    }

    #worldlines-launcher {
        align: center middle;
        width: 100%;
        height: 100%;
        layout: vertical;
    }

    #worldlines-shell {
        align: center middle;
        width: 100%;
        height: 100%;
        layout: vertical;
        background: #09090B;
    }

    #worldlines-panel {
        width: 120;
        height: auto;
        border: none;
        background: #09090B;
        padding: 0 2;
        layout: vertical;
    }

    #worldlines-kicker {
        color: #71717A;
        content-align: left middle;
        height: auto;
        margin-top: 0;
    }

    #worldlines-logo {
        color: #4ADE80;
        content-align: left middle;
        height: auto;
        margin-top: 0;
    }

    #worldlines-title {
        content-align: left middle;
        height: auto;
        margin-top: 0;
        margin-bottom: 0;
        color: #A78BFA;
    }

    #worldlines-divider {
        color: #3F3F46;
        content-align: left middle;
        height: auto;
        margin-top: 0;
        margin-bottom: 0;
    }

    #worldlines-subtitle {
        content-align: left middle;
        color: #A1A1AA;
        height: auto;
        margin-bottom: 0;
    }

    #worldlines-status {
        color: #71717A;
        content-align: left middle;
        height: auto;
        margin-bottom: 0;
    }

    #worldlines-menu {
        width: 100%;
        height: 1;
        layout: horizontal;
        align: left middle;
        margin-top: 1;
        margin-bottom: 0;
    }

    .worldlines-menu-button {
        width: auto;
        min-width: 26;
        height: 1;
        margin-right: 2;
        background: #09090B;
        color: #D4D4D8;
        border: none;
        padding: 0 1;
        content-align: left middle;
    }

    .worldlines-menu-button:focus {
        background: #18181B;
        color: #4ADE80;
        text-style: bold;
    }

    #worldlines-hint {
        color: #A1A1AA;
        content-align: left middle;
        height: auto;
        margin-top: 0;
    }

    #worldlines-footer {
        color: #71717A;
        content-align: left middle;
        height: auto;
        margin-top: 1;
    }
    """

    def __init__(self):
        super().__init__()
        self.launch_selection: WorldLinesLaunchSelection | None = None
        from neonrp.players import list_players
        from neonrp.presets import list_presets
        from neonrp.worlds import list_saved_games, list_worlds
        from neonrp.core.user_config import get_user_locale

        self._saved_games: list[dict[str, Any]] = list_saved_games()
        self._worlds: list[dict[str, str]] = list_worlds()
        self._presets: list[dict[str, Any]] = list_presets()
        self._players: list[dict[str, Any]] = list_players()
        self._selected_game: Path | None = None
        self._selected_world_id: str | None = None
        self._selected_player: dict[str, Any] | None = None
        self._custom_world_intent: dict[str, Any] | None = None
        self._menu_focus_index = 0
        # Track whether user has ever chosen a locale. If not, the launcher
        # shows a first-run language picker before the main menu.
        self._user_locale_on_disk: str = get_user_locale()
        self._first_run_locale: bool = self._user_locale_on_disk == "auto"
        self.locale: str = resolve_locale()

    def compose(self) -> ComposeResult:
        if self._saved_games:
            continue_label = f"[1] {get_message(self.locale, 'menu.continue')} ({len(self._saved_games)})"
        else:
            continue_label = f"[1] {get_message(self.locale, 'menu.continue_empty')}"
        continue_variant = "primary" if self._saved_games else "default"
        with Container(id="worldlines-launcher"):
            with Container(id="worldlines-shell"):
                with Container(id="worldlines-panel"):
                    yield Static(get_message(self.locale, "launcher.kicker"), id="worldlines-kicker")
                    yield Static(self.ASCII_LOGO, id="worldlines-logo")
                    yield Static(self.ASCII_TITLE, id="worldlines-title")
                    yield Static(self.ASCII_DIVIDER, id="worldlines-divider")
                    yield Static(self.ASCII_GRAPH, id="worldlines-graph")
                    yield Static(get_message(self.locale, "launcher.subtitle"), id="worldlines-subtitle")
                    yield Static(get_message(self.locale, "launcher.status_ready"), id="worldlines-status")
                    with Horizontal(id="worldlines-menu"):
                        yield Button(continue_label, id="wl-continue", variant=continue_variant, classes="worldlines-menu-button")
                        yield Button(f"[2] {get_message(self.locale, 'menu.new')}", id="wl-new", variant="default", classes="worldlines-menu-button")
                        yield Button(f"[3] {get_message(self.locale, 'menu.settings')}", id="wl-settings", variant="default", classes="worldlines-menu-button")
                        yield Button(f"[4] {get_message(self.locale, 'menu.exit')}", id="wl-exit", variant="default", classes="worldlines-menu-button")
                    yield Static(get_message(self.locale, "launcher.shortcuts"), id="worldlines-hint")
                    yield Static(get_message(self.locale, "launcher.footer").format(version=_NEONRP_VERSION), id="worldlines-footer")

    def on_mount(self) -> None:
        try:
            if self._saved_games:
                self._focus_menu_button(0)
            else:
                self._focus_menu_button(1)
        except Exception:
            pass
        # First run — prompt for UI language before anything else.
        if self._first_run_locale:
            self.call_after_refresh(self._prompt_first_run_locale)

    def _prompt_first_run_locale(self) -> None:
        from neonrp.core.user_config import set_user_locale

        options = [
            ("English",    "en"),
            ("简体中文",   "zh"),
            ("日本語",     "ja"),
            ("한국어",     "ko"),
            ("Auto (system default)", "auto"),
        ]

        def on_selected(value: str | None) -> None:
            self._first_run_locale = False
            if value:
                set_user_locale(value)
                self._user_locale_on_disk = value
                self.locale = resolve_locale()
                self._relabel_launcher()

        self.push_screen(
            ChoicePickerScreen(
                "Language / 语言 / 言語 / 언어",
                options,
                hint="Enter to confirm · Esc to keep default",
            ),
            on_selected,
        )

    def _relabel_launcher(self) -> None:
        """Re-render launcher button labels + hint text after a locale change."""
        try:
            kicker = self.query_one("#worldlines-kicker", Static)
            subtitle = self.query_one("#worldlines-subtitle", Static)
            status = self.query_one("#worldlines-status", Static)
            hint = self.query_one("#worldlines-hint", Static)
            footer = self.query_one("#worldlines-footer", Static)
            btn_continue = self.query_one("#wl-continue", Button)
            btn_new = self.query_one("#wl-new", Button)
            btn_settings = self.query_one("#wl-settings", Button)
            btn_exit = self.query_one("#wl-exit", Button)
        except Exception:
            return

        kicker.update(get_message(self.locale, "launcher.kicker"))
        subtitle.update(get_message(self.locale, "launcher.subtitle"))
        status.update(get_message(self.locale, "launcher.status_ready"))
        hint.update(get_message(self.locale, "launcher.shortcuts"))
        footer.update(get_message(self.locale, "launcher.footer").format(version=_NEONRP_VERSION))
        if self._saved_games:
            btn_continue.label = f"[1] {get_message(self.locale, 'menu.continue')} ({len(self._saved_games)})"
        else:
            btn_continue.label = f"[1] {get_message(self.locale, 'menu.continue_empty')}"
        btn_new.label = f"[2] {get_message(self.locale, 'menu.new')}"
        btn_settings.label = f"[3] {get_message(self.locale, 'menu.settings')}"
        btn_exit.label = f"[4] {get_message(self.locale, 'menu.exit')}"

    @staticmethod
    def _menu_button_ids() -> list[str]:
        return ["wl-continue", "wl-new", "wl-settings", "wl-exit"]

    def _focus_menu_button(self, index: int) -> None:
        menu_ids = self._menu_button_ids()
        if not menu_ids:
            return
        self._menu_focus_index = index % len(menu_ids)
        try:
            self.query_one(f"#{menu_ids[self._menu_focus_index]}", Button).focus()
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "wl-continue":
            self._start_continue_flow()
            return
        if btn_id == "wl-new":
            self._start_new_flow()
            return
        if btn_id == "wl-settings":
            self._start_settings_flow()
            return
        if btn_id == "wl-exit":
            self.exit()

    def action_continue_flow(self) -> None:
        self._start_continue_flow()

    def action_new_flow(self) -> None:
        self._start_new_flow()

    def action_settings_flow(self) -> None:
        self._start_settings_flow()

    def action_move_prev(self) -> None:
        self._focus_menu_button(self._menu_focus_index - 1)

    def action_move_next(self) -> None:
        self._focus_menu_button(self._menu_focus_index + 1)

    def action_confirm_choice(self) -> None:
        menu_ids = self._menu_button_ids()
        if not menu_ids:
            return
        current = menu_ids[self._menu_focus_index % len(menu_ids)]
        if current == "wl-continue":
            self._start_continue_flow()
            return
        if current == "wl-new":
            self._start_new_flow()
            return
        if current == "wl-settings":
            self._start_settings_flow()
            return
        if current == "wl-exit":
            self.exit()

    def action_quit_launcher(self) -> None:
        self.exit()

    def _start_continue_flow(self) -> None:
        if not self._saved_games:
            self._step_choose_world()
            return
        self._step_choose_saved_game()

    def _start_new_flow(self) -> None:
        self._step_choose_world()

    def _start_settings_flow(self) -> None:
        self._step_settings_menu()

    def _refresh_presets(self) -> None:
        from neonrp.presets import list_presets

        self._presets = list_presets()

    def _step_settings_menu(self) -> None:
        """Open the unified settings flow (shared with NeonRPApp /settings)."""
        from neonrp.tui.settings_flow import SettingsFlow

        flow = SettingsFlow(
            host=self,
            on_exit=lambda: (self._refresh_presets(), self.call_later(self._return_to_main)),
        )
        # Locale attribute used by SettingsFlow is read as `ui_locale`; the
        # launcher stores it under `self.locale` — expose it under both names.
        if not hasattr(self, "ui_locale"):
            self.ui_locale = self.locale
        flow.open_root()

    def _step_configure_discord(self) -> None:
        """Discord setup — guided wizard with status dashboard.

        Two states:
        - If nothing is configured yet → show welcome + 4 progressive steps
        - Once any field exists → show dashboard with ✓/○ per field + actions
        """
        from neonrp.core.discord_config import (
            get_discord_settings,
            set_discord_settings,
            clear_discord_settings,
            get_discord_inline_status,
            discord_oauth_invite_url,
            VALID_RELAY_MODES,
        )
        from neonrp.bridges.discord_bridge import discord_py_status

        t = lambda k: get_message(self.locale, k)  # noqa: E731

        settings = get_discord_settings()
        token = settings.get("bot_token", "")
        app_id = settings.get("application_id", "")
        channel = settings.get("channel_id", "")
        guild = settings.get("guild_id", "")
        relay = settings.get("relay_mode", "mirror")
        status = get_discord_inline_status()
        masked = (token[:4] + "…" + token[-4:]) if token else "(not set)"
        lib_ok, lib_version, _lib_err = discord_py_status()
        if lib_ok:
            lib_line = f"✓  discord.py installed  (v{lib_version or '?'})"
        else:
            lib_line = "⚠  discord.py NOT installed — run:  uv sync --extra discord"

        # Is the runtime bridge currently wired into the hub? We read this
        # live so the dashboard reflects `/bridge start|stop discord`.
        hub = getattr(self, "_bridge_hub", None)
        bridge_running = False
        if hub is not None:
            try:
                bridge_running = "discord" in hub.list_bridges()
            except Exception:
                bridge_running = False

        def _mark(ok: bool) -> str:
            return "✓" if ok else "○"

        has_any = bool(token or app_id or channel)

        options: list[tuple[str, str]] = []
        options.append(section(f"── {t('discord_setup.title')} ──"))
        options.append(spacer())

        if not has_any:
            # First-run welcome
            for line in t("discord_setup.welcome").split("\n"):
                options.append((line or " ", "__noop__"))
            options.append(spacer())
            options.append((f"▶  {t('discord_setup.begin')}", "step_portal"))
            options.append((t("discord_setup.skip"), "back"))
        else:
            # Dashboard — show progress + actions.
            # Relay on/off is the single source of truth: toggling it both
            # persists `autostart` and starts/stops the runtime bridge, so
            # the user never has two controls for the same thing.
            relay_marker = "●" if bridge_running else "○"
            relay_label = "ON  — mirroring narrator turns to Discord" if bridge_running else "OFF — turns stay local to the TUI"
            options.append((f"{_mark(bool(app_id))}  Application ID:  {app_id or '(not set)'}", "set_app_id"))
            options.append((f"{_mark(bool(token))}  Bot token:       {masked}", "set_token"))
            options.append((f"{_mark(bool(channel))}  Channel ID:      {channel or '(not set)'}", "set_channel"))
            options.append((f"   Guild ID:        {guild or '(optional)'}", "set_guild"))
            options.append((f"   Relay mode:      {relay}  ({' | '.join(VALID_RELAY_MODES)})", "set_relay"))
            if token and channel and lib_ok:
                options.append((f"{relay_marker}  Relay:           {relay_label}", "toggle_relay"))
            else:
                options.append(("○  Relay:           disabled (complete setup above first)", "__noop__"))
            options.append(spacer())
            options.append((f"   {t('discord_setup.status')}:          {status}", "__noop__"))
            options.append((f"   {lib_line}", "__noop__"))
            options.append(spacer())
            options.append(section("── actions ──"))
            options.append(spacer())
            if app_id or token:
                options.append((f"🔗  {t('discord_setup.invite_url_title')}", "show_invite"))
            if token and channel:
                options.append((f"▶  {t('discord_setup.test_connection')}  (ping + send test message)", "test_conn"))
            options.append(("✗  Delete Discord config", "delete"))
            options.append(spacer())
            options.append((t("settings.back"), "back"))

        def on_selected(value: str | None) -> None:
            if value is None or value == "back":
                self._step_settings_menu()
                return
            if value in ("__noop__",):
                self._step_configure_discord()
                return
            if value == "step_portal":
                self._step_discord_portal_hint()
                return
            if value == "set_app_id":
                self._step_prompt_text(
                    t("discord_setup.app_id_prompt"),
                    default=app_id,
                    on_submit=lambda v: self._discord_save_and_refresh({"application_id": v}),
                )
                return
            if value == "set_token":
                self._step_prompt_text(
                    t("discord_setup.token_prompt"),
                    default="",
                    on_submit=lambda v: self._discord_save_and_refresh({"bot_token": v}),
                )
                return
            if value == "set_channel":
                self._step_prompt_text(
                    t("discord_setup.channel_prompt"),
                    default=channel,
                    on_submit=lambda v: self._discord_save_and_refresh({"channel_id": v}),
                )
                return
            if value == "set_guild":
                self._step_prompt_text(
                    t("discord_setup.guild_prompt"),
                    default=guild,
                    on_submit=lambda v: self._discord_save_and_refresh({"guild_id": v}),
                )
                return
            if value == "set_relay":
                self._step_prompt_text(
                    f"Relay mode ({' | '.join(VALID_RELAY_MODES)})",
                    default=relay,
                    on_submit=lambda v: self._discord_save_and_refresh({"relay_mode": v}),
                )
                return
            if value == "toggle_relay":
                # The launcher is a separate App instance from the running
                # NeonRPApp — their bridge hubs don't share state. Any
                # in-process start/stop here would target the launcher's
                # (empty) hub, not the game. So we only flip the persisted
                # `autostart` flag; the new value takes effect on the next
                # `worldlines` / `neonrp` launch. This also matches the
                # user's mental model: Discord relay = "on/off for next run".
                new_state = not bridge_running
                set_discord_settings(autostart=new_state)  # type: ignore[call-arg]
                # If we're inside a live NeonRPApp (the in-app /settings
                # flow), apply immediately via its real `_cmd_bridge`.
                cmd_bridge = getattr(self, "_cmd_bridge", None)
                if callable(cmd_bridge):
                    cmd_bridge(["start", "discord"] if new_state else ["stop", "discord"])
                self._step_configure_discord()
                return
            if value == "show_invite":
                invite = discord_oauth_invite_url(application_id=app_id, bot_token=token)
                if not invite:
                    # Couldn't resolve a valid Application ID from either the
                    # explicit field or by decoding the bot token.
                    err_note = [
                        section("── Can't build invite URL ──"),
                        spacer(),
                        ("Discord needs a numeric Application ID (Snowflake).", "__noop__"),
                        ("Go back and fill the 'Application ID' row from the developer portal:", "__noop__"),
                        ("   https://discord.com/developers/applications", "__noop__"),
                        ("   → your app → General Information → Application ID", "__noop__"),
                        spacer(),
                        (t("settings.back"), "back"),
                    ]
                    self.push_screen(
                        ChoicePickerScreen("Discord — invite URL", err_note),
                        lambda _v: self._step_configure_discord(),
                    )
                    return

                # Best-effort: open the invite URL in the user's browser so
                # they don't have to copy-paste manually. Falls through if
                # no browser is available (SSH session, etc).
                browser_opened = False
                try:
                    import webbrowser

                    browser_opened = webbrowser.open(invite, new=2)
                except Exception:
                    browser_opened = False

                hint = (
                    "✓  Browser opened — authorize the bot in the page that appeared."
                    if browser_opened
                    else "Browser couldn't open automatically. Copy the URL below and paste it:"
                )
                note = [
                    section(f"── {t('discord_setup.invite_url_title')} ──"),
                    spacer(),
                    (hint, "__noop__"),
                    spacer(),
                    (invite, "__noop__"),
                    spacer(),
                    ("After authorizing, come back here and run 'Test connection'.", "__noop__"),
                    spacer(),
                    (t("settings.back"), "back"),
                ]

                def _invite_back(v: str | None) -> None:
                    # Only return to wizard on explicit Back / Esc; clicking
                    # a noop row would otherwise dismiss the modal before the
                    # user can read the URL.
                    if v is None or v == "back":
                        self._step_configure_discord()
                        return
                    # Re-push the screen (no-op rows shouldn't close it).
                    self.push_screen(
                        ChoicePickerScreen(t("discord_setup.invite_url_title"), note),
                        _invite_back,
                    )

                self.push_screen(
                    ChoicePickerScreen(t("discord_setup.invite_url_title"), note),
                    _invite_back,
                )
                return
            if value == "test_conn":
                self._step_discord_test_connection()
                return
            if value == "delete":
                clear_discord_settings()
                self._step_configure_discord()

        self.push_screen(
            ChoicePickerScreen(t("discord_setup.title"), options),
            on_selected,
        )

    def _discord_save_and_refresh(self, updates: dict[str, Any]) -> None:
        """Persist partial Discord updates and redisplay the wizard."""
        from neonrp.core.discord_config import set_discord_settings

        cleaned = {k: str(v).strip() for k, v in updates.items() if v is not None and str(v).strip()}
        if cleaned:
            set_discord_settings(**cleaned)  # type: ignore[arg-type]
        self._step_configure_discord()

    def _step_discord_portal_hint(self) -> None:
        """Step 1: point the user at the Discord developer portal."""
        t = lambda k: get_message(self.locale, k)  # noqa: E731
        options = [
            section("── step 1 / 4: developer portal ──"),
            spacer(),
            ("Open this URL in your browser:", "__noop__"),
            ("   https://discord.com/developers/applications", "__noop__"),
            spacer(),
            ("Then:  New Application → Bot → Reset Token (copy the token).", "__noop__"),
            ("Scroll down to 'Application ID' on the General page — copy it too.", "__noop__"),
            spacer(),
            ("▶  Next: paste Application ID", "goto_app_id"),
            (t("settings.back"), "back"),
        ]

        def on_selected(value: str | None) -> None:
            if value == "goto_app_id":
                self._step_prompt_text(
                    t("discord_setup.app_id_prompt"),
                    default="",
                    on_submit=lambda v: self._discord_save_and_refresh({"application_id": v}),
                )
                return
            self._step_configure_discord()

        self.push_screen(
            ChoicePickerScreen(t("discord_setup.title"), options),
            on_selected,
        )

    def _step_discord_test_connection(self) -> None:
        """Two-step probe: REST ping + send a real test message to the channel.

        Runs in a background thread behind an animated spinner so the TUI
        stays responsive. The worker uses urllib directly — discord.py isn't
        required for REST — but we also report whether the runtime lib is
        installed, because the live relay needs it.

        The second step posts `POST /channels/{id}/messages` so the user
        sees an actual message land in the configured Discord channel and
        knows the pipe works end-to-end.
        """
        from neonrp.core.discord_config import get_discord_settings
        from neonrp.bridges.discord_bridge import discord_py_status

        settings = get_discord_settings()
        token = settings.get("bot_token", "")
        channel_id = str(settings.get("channel_id", "") or "").strip()
        t = lambda k: get_message(self.locale, k)  # noqa: E731

        lib_ok, lib_version, lib_err = discord_py_status()
        lib_line = (
            f"✓  discord.py installed  (v{lib_version or '?'})"
            if lib_ok
            else "⚠  discord.py NOT installed — live relay won't start"
        )

        def _show_result(lines: list[str]) -> None:
            rows: list[tuple[str, str]] = [
                section(f"── {t('discord_setup.test_connection')} ──"),
                spacer(),
                (lib_line, "__noop__"),
            ]
            for line in lines:
                rows.append((line, "__noop__"))
            if not lib_ok:
                rows.append(spacer())
                rows.append(("Install runtime dep with:  uv sync --extra discord", "__noop__"))
            rows.append(spacer())
            rows.append((t("settings.back"), "back"))
            self.push_screen(
                ChoicePickerScreen(t("discord_setup.test_connection"), rows),
                lambda _v: self._step_configure_discord(),
            )

        if not token:
            _show_result(["✗  No bot token configured"])
            return

        def _worker() -> str:
            import urllib.request
            import urllib.error
            import json as _json

            lines: list[str] = []

            # Step 1 — GET /users/@me (validates the token)
            try:
                req = urllib.request.Request(
                    "https://discord.com/api/v10/users/@me",
                    headers={
                        "Authorization": f"Bot {token}",
                        "User-Agent": "neonrp-discord-test",
                    },
                )
                with urllib.request.urlopen(req, timeout=6.0) as resp:
                    data = _json.loads(resp.read().decode("utf-8"))
                bot_name = str(data.get("username", "?"))
                bot_id = str(data.get("id", ""))
                lines.append(f"✓  Auth OK — {bot_name} (id={bot_id})")
            except Exception as exc:
                msg = str(exc).split("\n")[0][:120]
                lines.append(f"✗  Auth failed — {msg}")
                # Don't try step 2 if auth failed.
                return "\n".join(lines)

            # Step 2 — POST /channels/{id}/messages
            if not channel_id:
                lines.append("⚠  No channel_id configured — skipped send test")
                return "\n".join(lines)
            try:
                payload = _json.dumps(
                    {"content": "✅ NeonRP test message — bridge wiring verified."}
                ).encode("utf-8")
                req2 = urllib.request.Request(
                    f"https://discord.com/api/v10/channels/{channel_id}/messages",
                    data=payload,
                    method="POST",
                    headers={
                        "Authorization": f"Bot {token}",
                        "Content-Type": "application/json",
                        "User-Agent": "neonrp-discord-test",
                    },
                )
                with urllib.request.urlopen(req2, timeout=6.0) as resp:
                    resp.read()
                lines.append(f"✓  Sent test message to channel {channel_id}")
            except urllib.error.HTTPError as exc:
                body = ""
                try:
                    body = exc.read().decode("utf-8", "ignore")[:200]
                except Exception:
                    pass
                hint = ""
                if exc.code == 403:
                    hint = "  (bot missing 'Send Messages' / 'View Channel' on that channel)"
                elif exc.code == 404:
                    hint = "  (channel_id wrong, or bot not in that server)"
                lines.append(f"✗  Send failed — HTTP {exc.code}{hint}")
                if body:
                    lines.append(f"   {body[:120]}")
            except Exception as exc:
                msg = str(exc).split("\n")[0][:120]
                lines.append(f"✗  Send failed — {msg}")

            return "\n".join(lines)

        def _on_spinner_done(result: str) -> None:
            # Esc cancelled before the worker finished → go back.
            if not result:
                self._step_configure_discord()
                return
            _show_result(result.split("\n"))

        self.push_screen(
            SpinnerWorkerScreen(
                t("discord_setup.test_connection"),
                "Validating token + sending test message …",
                _worker,
            ),
            _on_spinner_done,
        )

    def _return_to_main(self) -> None:
        try:
            self._focus_menu_button(0)
        except Exception:
            pass

    def _step_show_config_path(self) -> None:
        from neonrp.presets import _USER_CONFIG_PATH

        path_str = str(_USER_CONFIG_PATH)
        exists = "(exists)" if _USER_CONFIG_PATH.exists() else "(not created yet)"
        options = [(f"{path_str}  {exists}", "ok"), ("Back", "back")]

        def on_selected(value: str | None) -> None:
            self._step_settings_menu()

        self.push_screen(ChoicePickerScreen("Config file location", options), on_selected)

    def _step_configure_preset(self, preset_id: str) -> None:
        from neonrp.presets import (
            PRESETS,
            _load_user_config_models,
            is_claude_code_preset,
        )

        if is_claude_code_preset(preset_id):
            options = [
                ("Claude Code uses the local `claude` CLI — no key needed.", "ack"),
                ("Back", "back"),
            ]

            def on_ack(value: str | None) -> None:
                self._step_settings_menu()

            self.push_screen(ChoicePickerScreen(preset_id, options), on_ack)
            return

        user_models = _load_user_config_models()
        cur_key = user_models.get(preset_id, {}).get("api_key", "")
        cur_model = user_models.get(preset_id, {}).get("model", "") or PRESETS.get(preset_id, {}).get("model", "")

        masked = (cur_key[:4] + "…" + cur_key[-4:]) if cur_key else "(not set)"
        options = [
            (f"Current key: {masked}", "noop"),
            (f"Current model: {cur_model}", "noop"),
            ("Update API key", "set_key"),
            ("Update model id", "set_model"),
            ("Delete entry", "delete"),
            ("Back", "back"),
        ]

        def on_selected(value: str | None) -> None:
            if value is None or value == "back":
                self._step_settings_menu()
                return
            if value == "set_key":
                self._step_prompt_text(
                    f"API key for {preset_id}",
                    default="",
                    on_submit=lambda raw: self._apply_key_update(preset_id, raw),
                )
                return
            if value == "set_model":
                self._step_prompt_text(
                    f"model id for {preset_id}",
                    default=cur_model,
                    on_submit=lambda raw: self._apply_model_update(preset_id, raw),
                )
                return
            if value == "delete":
                self._delete_preset_entry(preset_id)
                self._step_settings_menu()
                return
            self._step_configure_preset(preset_id)

        self.push_screen(ChoicePickerScreen(f"Configure {preset_id}", options), on_selected)

    def _apply_key_update(self, preset_id: str, raw: str) -> None:
        from neonrp.presets import _save_key_to_user_config

        raw = (raw or "").strip()
        if raw:
            _save_key_to_user_config(preset_id, raw)
            os.environ.setdefault("_", "")
        self._refresh_presets()
        self._step_configure_preset(preset_id)

    def _apply_model_update(self, preset_id: str, raw: str) -> None:
        import json
        from neonrp.presets import _USER_CONFIG_PATH

        raw = (raw or "").strip()
        if not raw:
            self._step_configure_preset(preset_id)
            return
        try:
            data = json.loads(_USER_CONFIG_PATH.read_text(encoding="utf-8")) if _USER_CONFIG_PATH.exists() else {}
            models = data.setdefault("models", {})
            entry = models.setdefault(preset_id, {})
            entry["model"] = raw
            _USER_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
            _USER_CONFIG_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        self._refresh_presets()
        self._step_configure_preset(preset_id)

    def _delete_preset_entry(self, preset_id: str) -> None:
        import json
        from neonrp.presets import _USER_CONFIG_PATH

        if not _USER_CONFIG_PATH.exists():
            return
        try:
            data = json.loads(_USER_CONFIG_PATH.read_text(encoding="utf-8"))
            if "models" in data and preset_id in data["models"]:
                del data["models"][preset_id]
                _USER_CONFIG_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        self._refresh_presets()

    def _step_add_custom_model(self) -> None:
        self._step_prompt_text(
            "custom model id (e.g. my-llama)",
            default="",
            on_submit=self._after_custom_model_id,
        )

    def _after_custom_model_id(self, model_id: str) -> None:
        model_id = (model_id or "").strip().lower().replace(" ", "-")
        if not model_id:
            self._step_settings_menu()
            return
        self._step_prompt_text(
            f"base_url for {model_id}",
            default="http://localhost:11434/v1",
            on_submit=lambda base_url: self._after_custom_base_url(model_id, base_url),
        )

    def _after_custom_base_url(self, model_id: str, base_url: str) -> None:
        self._step_prompt_text(
            f"model name to send to the API for {model_id}",
            default=model_id,
            on_submit=lambda model_name: self._after_custom_model_name(model_id, base_url, model_name),
        )

    def _after_custom_model_name(self, model_id: str, base_url: str, model_name: str) -> None:
        self._step_prompt_text(
            f"api key for {model_id} (leave blank if not needed)",
            default="",
            on_submit=lambda api_key: self._write_custom_model(model_id, base_url, model_name, api_key),
        )

    def _write_custom_model(self, model_id: str, base_url: str, model_name: str, api_key: str) -> None:
        import json
        from neonrp.presets import _USER_CONFIG_PATH

        try:
            data = json.loads(_USER_CONFIG_PATH.read_text(encoding="utf-8")) if _USER_CONFIG_PATH.exists() else {}
            models = data.setdefault("models", {})
            entry: dict[str, Any] = {
                "provider": "openai",
                "model": (model_name or model_id).strip(),
                "base_url": (base_url or "").strip(),
            }
            if api_key.strip():
                entry["api_key"] = api_key.strip()
            models[model_id] = entry
            _USER_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
            _USER_CONFIG_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        self._refresh_presets()
        self._step_settings_menu()

    def _step_prompt_text(
        self,
        title: str,
        default: str,
        on_submit: Callable[[str], None],
        *,
        on_cancel: Callable[[], None] | None = None,
    ) -> None:
        def handler(value: str | None) -> None:
            if value is None:
                if on_cancel is not None:
                    on_cancel()
                else:
                    self._step_settings_menu()
                return
            on_submit(value)

        self.push_screen(TextInputScreen(title, default=default), handler)

    def _step_choose_entry(self) -> None:
        if not self._saved_games:
            self._step_choose_world()
            return

        options = [
            (f"Continue existing game ({len(self._saved_games)})", "__continue__"),
            ("Start a new game", "__new__"),
        ]

        def on_selected(value: str | None) -> None:
            if value is None:
                self.exit()
                return
            if value == "__continue__":
                self._step_choose_saved_game()
                return
            self._step_choose_world()

        self.push_screen(ChoicePickerScreen("WorldLines", options), on_selected)

    def _step_choose_saved_game(self) -> None:
        # Load picker also needs to exist even when there are no saved games,
        # so always build the full list (with an empty Saved Runs section
        # if applicable) rather than bailing out.
        options: list[tuple[str, str]] = []
        options.append(section(f"── {get_message(self.locale, 'saved.section.runs')} ──"))
        options.append(spacer())

        if self._saved_games:
            for game in self._saved_games:
                options.append(
                    (f"{game['display_name']}  —  {game['mtime_display']}", f"pick::{game['path']}")
                )
        else:
            options.append(("(no saved runs yet)", "__noop__"))

        options.append(spacer())
        options.append(section(f"── {get_message(self.locale, 'saved.section.actions')} ──"))
        options.append(spacer())
        if self._saved_games:
            options.append((get_message(self.locale, "saved.export"), "export_pick"))
        options.append((get_message(self.locale, "saved.load"), "load_zip"))
        if self._saved_games:
            options.append((get_message(self.locale, "saved.delete"), "delete_pick"))

        def on_selected(value: str | None) -> None:
            if value is None:
                # Top-level picker: just dismiss; main launcher panel shows again.
                self._focus_menu_button(0)
                return
            if value == "__noop__":
                self._step_choose_saved_game()
                return
            if value == "export_pick":
                self._step_export_pick_game()
                return
            if value == "load_zip":
                self._step_load_zip_prompt()
                return
            if value == "delete_pick":
                self._step_delete_pick_game()
                return
            if value.startswith("pick::"):
                self._selected_game = Path(value.split("::", 1)[1])
                self._step_choose_preset(continue_mode=True)
                return

        self.push_screen(
            ChoicePickerScreen(get_message(self.locale, "picker.continue_game"), options),
            on_selected,
        )

    # ------------------------------------------------------------------
    # Export / Load saved runs — sub-flows triggered from the saved-game
    # picker. Both delegate to neonrp.core.world_export under the hood.
    # ------------------------------------------------------------------

    def _step_export_pick_game(self) -> None:
        """Ask the user which saved run to export, then prompt for a path."""
        if not self._saved_games:
            self._step_choose_saved_game()
            return
        options: list[tuple[str, str]] = [
            section(f"── {get_message(self.locale, 'saved.section.runs')} ──"),
            spacer(),
        ]
        for game in self._saved_games:
            options.append(
                (f"{game['display_name']}  —  {game['mtime_display']}", f"exp::{game['path']}")
            )
        options.append(spacer())
        options.append((get_message(self.locale, "settings.back"), "back"))

        def on_selected(value: str | None) -> None:
            if value is None or value == "back":
                self._step_choose_saved_game()
                return
            if value.startswith("exp::"):
                self._step_export_prompt_path(Path(value.split("::", 1)[1]))

        self.push_screen(
            ChoicePickerScreen(get_message(self.locale, "saved.export"), options),
            on_selected,
        )

    def _step_export_prompt_path(self, world_path: Path) -> None:
        """Ask for the output .zip path (default: ~/Downloads/)."""
        from neonrp.core.world_export import default_export_path

        default_out = str(default_export_path(world_path))

        def on_submit(raw: str) -> None:
            raw = (raw or "").strip()
            target = Path(raw or default_out).expanduser()
            self._run_export(world_path, target)

        self._step_prompt_text(
            f"{get_message(self.locale, 'saved.export')}",
            default=default_out,
            on_submit=on_submit,
        )

    def _run_export(self, world_path: Path, output_path: Path) -> None:
        """Run the export, then show a result screen."""
        from neonrp.core.world_export import export_world, summarize_archive

        try:
            final = export_world(world_path, output_path)
            info = summarize_archive(final)
            msg = get_message(self.locale, "export.success").format(
                files=info["file_count"], mb=info["size_mb"]
            )
            lines = [f"✓  {msg}", f"   {final}"]
        except Exception as exc:
            lines = [f"✗  {type(exc).__name__}: {exc}"]

        self._show_result_screen(get_message(self.locale, "saved.export"), lines)

    def _step_load_zip_prompt(self) -> None:
        """Ask the user for the .zip path to load."""
        def on_submit(raw: str) -> None:
            raw = (raw or "").strip()
            if not raw:
                self._step_choose_saved_game()
                return
            self._run_load(Path(raw).expanduser())

        self._step_prompt_text(
            get_message(self.locale, "prompt.zip_path"),
            default="",
            on_submit=on_submit,
        )

    def _run_load(self, zip_path: Path) -> None:
        from neonrp.core.world_export import load_world_zip
        from neonrp.worlds import list_saved_games

        try:
            target = load_world_zip(zip_path)
            # Refresh the in-memory saved-games cache so the picker shows it.
            self._saved_games = list_saved_games()
            msg = get_message(self.locale, "load.success").format(path=str(target))
            lines = [f"✓  {msg}"]
        except Exception as exc:
            lines = [f"✗  {type(exc).__name__}: {exc}"]

        self._show_result_screen(get_message(self.locale, "saved.load"), lines)

    # ------------------------------------------------------------------
    # Delete — two-step picker to make accidental removal impossible.
    # ------------------------------------------------------------------

    def _step_delete_pick_game(self) -> None:
        """Select-mode picker: tap rows to toggle, then confirm delete N.

        The action ID used in the continue picker is still `delete_pick` and
        this method is still named `_step_delete_pick_game` so the call
        sites don't change. But the UX is now multi-select instead of
        single-pick, matching user ask "click delete → select mode →
        press delete button after picking what to delete".
        """
        if not self._saved_games:
            self._step_choose_saved_game()
            return
        if not hasattr(self, "_delete_selection"):
            self._delete_selection: set[Path] = set()
        # Drop paths that no longer correspond to real saves (a previous
        # batch delete might have removed them without clearing the set).
        live_paths = {g["path"] for g in self._saved_games}
        self._delete_selection &= live_paths

        options: list[tuple[str, str]] = [
            section(f"── {get_message(self.locale, 'saved.section.runs')} ──"),
            spacer(),
            (f"  {get_message(self.locale, 'saved.delete.select_hint')}", "__noop__"),
            spacer(),
        ]
        for game in self._saved_games:
            mark = "[x]" if game["path"] in self._delete_selection else "[ ]"
            options.append(
                (
                    f"{mark}  {game['display_name']}  —  {game['mtime_display']}",
                    f"toggle::{game['path']}",
                )
            )
        options.append(spacer())
        options.append(section("── actions ──"))
        options.append(spacer())
        selected_count = len(self._delete_selection)
        if selected_count > 0:
            options.append(
                (
                    get_message(self.locale, "saved.delete.action_selected").format(count=selected_count),
                    "confirm_selected",
                )
            )
        options.append((get_message(self.locale, "settings.back"), "back"))

        def on_selected(value: str | None) -> None:
            if value is None or value == "back":
                # Bail: discard selection so next entry starts clean.
                self._delete_selection.clear()
                self._step_choose_saved_game()
                return
            if value == "__noop__":
                # Hint row — re-render picker, preserve selection.
                self._step_delete_pick_game()
                return
            if value.startswith("toggle::"):
                target = Path(value.split("::", 1)[1])
                if target in self._delete_selection:
                    self._delete_selection.discard(target)
                else:
                    self._delete_selection.add(target)
                self._step_delete_pick_game()
                return
            if value == "confirm_selected":
                self._step_delete_confirm_batch()
                return

        self.push_screen(
            ChoicePickerScreen(get_message(self.locale, "saved.delete.pick_title"), options),
            on_selected,
        )

    def _step_delete_confirm_batch(self) -> None:
        """Confirm batch deletion — shows every selected save by name."""
        selected = list(self._delete_selection)
        if not selected:
            self._step_delete_pick_game()
            return

        # Keep rows sorted by mtime (newest first) so the confirm list
        # matches the picker order above it.
        lookup = {g["path"]: g for g in self._saved_games}
        entries = [lookup[p] for p in selected if p in lookup]
        entries.sort(key=lambda g: g.get("mtime", 0), reverse=True)

        options: list[tuple[str, str]] = [
            section(f"── {get_message(self.locale, 'saved.delete.confirm_title')} ──"),
            spacer(),
            (get_message(self.locale, "saved.delete.confirm_line1"), "__noop__"),
        ]
        for entry in entries:
            options.append((f"   • {entry['display_name']}  —  {entry['mtime_display']}", "__noop__"))
        options.append(spacer())
        options.append((get_message(self.locale, "saved.delete.confirm_warn"), "__noop__"))
        options.append(spacer())
        # Cancel listed first so keyboard focus lands on the safe option.
        options.append((get_message(self.locale, "saved.delete.cancel"), "cancel"))
        options.append(
            (
                get_message(self.locale, "saved.delete.action_selected").format(count=len(entries)),
                "confirm",
            )
        )

        def on_selected(value: str | None) -> None:
            if value == "confirm":
                self._run_delete_batch()
                return
            if value == "__noop__":
                self._step_delete_confirm_batch()
                return
            # cancel / back / Esc → return to select picker, selection kept
            # so the user can refine their choice without reselecting from
            # scratch.
            self._step_delete_pick_game()

        self.push_screen(
            ChoicePickerScreen(get_message(self.locale, "saved.delete.confirm_title"), options),
            on_selected,
        )

    def _run_delete_batch(self) -> None:
        """Remove all selected saved-run directories."""
        from neonrp.worlds import list_saved_games

        selected = list(self._delete_selection)
        self._delete_selection.clear()

        deleted: list[str] = []
        errors: list[str] = []
        lookup = {g["path"]: g for g in self._saved_games}
        for path in selected:
            meta = lookup.get(path)
            name = meta["display_name"] if meta else path.name
            try:
                cc_sibling = path.with_name(path.name + "-cc")
                shutil.rmtree(path, ignore_errors=False)
                if cc_sibling.exists():
                    shutil.rmtree(cc_sibling, ignore_errors=True)
                deleted.append(name)
            except Exception as exc:
                errors.append(f"{name}: {type(exc).__name__}: {exc}")

        self._saved_games = list_saved_games()

        lines: list[str] = []
        if deleted:
            lines.append(
                get_message(self.locale, "saved.delete.success_count").format(count=len(deleted))
            )
            for name in deleted:
                lines.append(f"  • {name}")
        for err in errors:
            lines.append(
                get_message(self.locale, "saved.delete.failed").format(error=err)
            )

        self._show_result_screen(get_message(self.locale, "saved.delete"), lines)

    def _show_result_screen(self, title: str, body_lines: list[str]) -> None:
        """Tiny wrapper: push a ChoicePickerScreen that only shows status."""
        options: list[tuple[str, str]] = [spacer()]
        for line in body_lines:
            options.append((line, "__noop__"))
        options.append(spacer())
        options.append((get_message(self.locale, "settings.back"), "back"))

        def on_selected(value: str | None) -> None:
            self._step_choose_saved_game()

        self.push_screen(ChoicePickerScreen(title, options), on_selected)

    def _step_choose_world(self) -> None:
        if not self._worlds:
            self.exit()
            return

        options: list[tuple[str, str]] = []
        options.append(section(f"── {get_message(self.locale, 'worlds.section.builtin')} ──"))
        options.append(spacer())
        for world in self._worlds:
            options.append(
                (f"{world['name']} ({world['name_local']})  —  {world['desc']}", world["id"])
            )
        options.append(spacer())
        options.append(section(f"── {get_message(self.locale, 'worlds.section.create')} ──"))
        options.append(spacer())
        options.append((get_message(self.locale, "worlds.create"), "__create__"))
        options.append((get_message(self.locale, "worlds.import"), "__import__"))

        def on_selected(value: str | None) -> None:
            if value is None:
                # Top-level picker: just dismiss; main launcher panel shows again.
                self._focus_menu_button(1)  # "start new run" button
                return
            if value == "__create__":
                self._step_world_create_prompt()
                return
            if value == "__import__":
                self._step_world_import_prompt()
                return
            self._selected_world_id = value
            self._step_choose_player()

        self.push_screen(
            ChoicePickerScreen(get_message(self.locale, "picker.choose_world"), options),
            on_selected,
        )

    # ------------------------------------------------------------------
    # World create / import — the launcher captures the intent here, and
    # the actual authoring is delegated to the relevant built-in skill
    # (`world-game-authoring` or `tavern-game-import`) once the TUI starts
    # inside the new game directory.
    # ------------------------------------------------------------------

    def _step_world_create_prompt(self) -> None:
        self._step_prompt_text(
            get_message(self.locale, "prompt.world_create_desc"),
            default="",
            on_submit=self._after_world_create_prompt,
        )

    def _after_world_create_prompt(self, prompt: str) -> None:
        prompt = (prompt or "").strip()
        if not prompt:
            self._step_choose_world()
            return
        self._selected_world_id = "__wl_create__"
        self._custom_world_intent = {
            "action": "create",
            "skill": "world-game-authoring",
            "prompt": prompt,
        }
        # Fall through to the normal flow (player → preset → launch).
        self._step_choose_player()

    def _step_world_import_prompt(self) -> None:
        self._step_prompt_text(
            get_message(self.locale, "prompt.world_import_path"),
            default="",
            on_submit=self._after_world_import_prompt,
        )

    def _after_world_import_prompt(self, path: str) -> None:
        path = (path or "").strip()
        if not path:
            self._step_choose_world()
            return
        self._selected_world_id = "__wl_import__"
        self._custom_world_intent = {
            "action": "import",
            "skill": "tavern-game-import",
            "source_path": path,
        }
        self._step_choose_player()

    def _step_choose_player(self) -> None:
        options: list[tuple[str, str]] = []
        options.append(section(f"── {get_message(self.locale, 'character.section.saved')} ──"))
        options.append(spacer())
        options.append((get_message(self.locale, "character.use_default"), "__default__"))
        for player in self._players:
            summary = str(player.get("summary", "") or "").strip()
            suffix = f" — {summary}" if summary else ""
            options.append((f"{player['name']}{suffix}", str(player.get("file") or player["name"])))

        options.append(spacer())
        options.append(section(f"── {get_message(self.locale, 'character.section.create')} ──"))
        options.append(spacer())
        options.append((get_message(self.locale, "character.create_ai"), "__create_ai__"))
        options.append((get_message(self.locale, "character.create_manual"), "__create_manual__"))
        options.append((get_message(self.locale, "character.import_card"), "__import_card__"))

        def on_selected(value: str | None) -> None:
            if value is None:
                self._step_choose_world()
                return
            if value == "__default__":
                self._selected_player = None
                self._step_choose_preset(continue_mode=False)
                return
            if value == "__create_ai__":
                self._step_character_create_ai_prompt()
                return
            if value == "__create_manual__":
                self._step_character_create_manual_name()
                return
            if value == "__import_card__":
                self._step_character_import_prompt()
                return
            selected = next(
                (player for player in self._players if str(player.get("file") or player["name"]) == value),
                None,
            )
            self._selected_player = selected["data"] if selected else None
            self._step_choose_preset(continue_mode=False)

        self.push_screen(
            ChoicePickerScreen(get_message(self.locale, "picker.choose_character"), options),
            on_selected,
        )

    # ------------------------------------------------------------------
    # Character create / import — mirrors world create/import. The launcher
    # captures the intent; actual AI generation happens after preset selection
    # so we have an LLM to talk to.
    # ------------------------------------------------------------------

    def _step_character_create_ai_prompt(self) -> None:
        self._step_prompt_text(
            get_message(self.locale, "prompt.character_create_desc"),
            default="",
            on_submit=self._after_character_create_ai,
        )

    def _after_character_create_ai(self, prompt: str) -> None:
        prompt = (prompt or "").strip()
        if not prompt:
            self._step_choose_player()
            return
        self._selected_player = {
            "__pending_ai__": True,
            "__skill__": "player-character-authoring",
            "summary": prompt,
        }
        self._step_choose_preset(continue_mode=False)

    def _step_character_create_manual_name(self) -> None:
        self._step_prompt_text(
            get_message(self.locale, "prompt.character_name"),
            default="",
            on_submit=self._after_character_manual_name,
        )

    def _after_character_manual_name(self, name: str) -> None:
        name = (name or "").strip()
        if not name:
            self._step_choose_player()
            return
        self._pending_manual_profile: dict[str, Any] = {"name": name}
        self._step_prompt_text(
            get_message(self.locale, "prompt.character_summary"),
            default="",
            on_submit=self._after_character_manual_summary,
        )

    def _after_character_manual_summary(self, summary: str) -> None:
        summary = (summary or "").strip()
        default_name = get_message(self.locale, "player.default_name")
        profile = getattr(self, "_pending_manual_profile", {"name": default_name})
        if summary:
            profile["summary"] = summary
        self._step_prompt_text(
            get_message(self.locale, "prompt.character_backstory"),
            default="",
            on_submit=lambda text: self._finalize_manual_character(profile, text),
        )

    def _finalize_manual_character(self, profile: dict[str, Any], backstory: str) -> None:
        backstory = (backstory or "").strip()
        if backstory:
            profile["backstory"] = backstory
        # Persist to ~/.worldlines/players/ so the user can reuse it next time.
        try:
            from neonrp.players import save_player

            save_player(profile)
        except Exception:
            pass
        self._selected_player = profile
        self._step_choose_preset(continue_mode=False)

    def _step_character_import_prompt(self) -> None:
        self._step_prompt_text(
            get_message(self.locale, "prompt.character_import_path"),
            default="",
            on_submit=self._after_character_import,
        )

    def _after_character_import(self, path: str) -> None:
        path = (path or "").strip()
        if not path:
            self._step_choose_player()
            return
        self._selected_player = {
            "__pending_import__": True,
            "__skill__": "character-card-authoring",
            "source_path": path,
        }
        self._step_choose_preset(continue_mode=False)

    def _step_choose_preset(self, continue_mode: bool) -> None:
        from neonrp.presets import is_claude_code_preset

        if not self._presets:
            self.exit()
            return

        # On continue, peek at the saved game's config.json and move the
        # last-used preset to the top with a "✓ last used" marker so the
        # default-focused first option is a 1-key resume.
        last_preset_id: str | None = None
        if continue_mode and self._selected_game is not None:
            try:
                from neonrp.cli import read_worldlines_last_preset

                last_preset_id = read_worldlines_last_preset(self._selected_game)
            except Exception:
                last_preset_id = None

        ordered_presets: list[dict[str, Any]] = list(self._presets)
        if last_preset_id:
            last_entry = next((p for p in ordered_presets if p["id"] == last_preset_id), None)
            if last_entry is not None:
                ordered_presets.remove(last_entry)
                ordered_presets.insert(0, last_entry)

        custom_badge = get_message(self.locale, "preset.badge.custom")
        options: list[tuple[str, str]] = []
        for preset in ordered_presets:
            label = preset["display"]
            if preset.get("from_user_config"):
                # Insert localized `[custom]` badge before any trailing ✓
                if label.endswith(" ✓"):
                    label = f"{label[:-2]} [{custom_badge}] ✓"
                else:
                    label = f"{label} [{custom_badge}]"
            if last_preset_id and preset["id"] == last_preset_id:
                label = f"{label}   ← last used"
            options.append((label, preset["id"]))
        # Tail entry so users discover they can wire up a Qwen / Ollama /
        # any OpenAI-compatible endpoint directly from the model picker.
        options.append((get_message(self.locale, "preset.add_custom"), "__add_custom__"))

        def finalize_launch(value: str) -> None:
            # Runtime mode decision:
            # - Claude Code preset  → mcp (always, regardless of intent)
            # - World create/import → build (agent needs free file writes to
            #                                scaffold the slice; not play)
            # - Everything else     → play (default gameplay loop)
            if is_claude_code_preset(value):
                runtime_mode: AppMode = "mcp"
            elif (not continue_mode) and self._custom_world_intent is not None:
                runtime_mode = "build"
            else:
                runtime_mode = "play"

            if continue_mode:
                self.launch_selection = WorldLinesLaunchSelection(
                    mode="continue",
                    preset_id=value,
                    runtime_mode=runtime_mode,
                    game_path=self._selected_game,
                )
            else:
                self.launch_selection = WorldLinesLaunchSelection(
                    mode="new",
                    preset_id=value,
                    runtime_mode=runtime_mode,
                    world_id=self._selected_world_id,
                    player_profile=self._selected_player,
                    world_intent=self._custom_world_intent,
                )
            self.exit()

        def on_selected(value: str | None) -> None:
            if value is None:
                if continue_mode:
                    self._step_choose_saved_game()
                else:
                    self._step_choose_player()
                return

            if value == "__add_custom__":
                self._step_add_custom_provider(continue_mode)
                return

            # Claude Code preset → gate on a one-time MCP authorization screen
            # before actually launching, so the user knows we are granting
            # filesystem-write permission to claude -p in the workspace.
            if is_claude_code_preset(value):
                from neonrp.core.user_config import is_mcp_authorized

                if not is_mcp_authorized():
                    self._step_mcp_authorization(
                        on_granted=lambda: finalize_launch(value),
                        on_cancel=lambda: self._step_choose_preset(continue_mode),
                    )
                    return
            finalize_launch(value)

        self.push_screen(
            ChoicePickerScreen(get_message(self.locale, "picker.choose_model"), options),
            on_selected,
        )

    def _step_add_custom_provider(self, continue_mode: bool) -> None:
        """Jump into the Settings custom-add wizard, return to picker on done."""
        from neonrp.presets import get_provider_type
        from neonrp.tui.settings_flow import SettingsFlow

        ptype = get_provider_type("custom")
        if ptype is None:
            self._step_choose_preset(continue_mode)
            return

        reopen_picker = lambda: (  # noqa: E731
            self._refresh_presets(),
            self._step_choose_preset(continue_mode),
        )

        def after_saved(_entry_id: str) -> None:
            reopen_picker()

        flow = SettingsFlow(host=self, on_exit=reopen_picker)
        flow._open_add_custom(ptype, on_done=after_saved)

    def _step_mcp_authorization(
        self,
        *,
        on_granted: Callable[[], None],
        on_cancel: Callable[[], None],
    ) -> None:
        """One-time consent screen shown before the first MCP-mode launch.

        Writes `mcp.authorized_at` to user config on confirm so subsequent
        launches skip this prompt. The actual `.claude/settings.local.json`
        allowlist is written by `bootstrap_claude_workspace` just before the
        TUI starts — this screen is purely about explicit user consent.
        """
        body_lines = get_message(self.locale, "mcp_auth.body").split("\n")
        options: list[tuple[str, str]] = [
            section(f"── {get_message(self.locale, 'mcp_auth.title')} ──"),
            spacer(),
        ]
        for line in body_lines:
            options.append((line or " ", "__noop__"))
        options.append(spacer())
        options.append((get_message(self.locale, "mcp_auth.grant"), "grant"))
        options.append((get_message(self.locale, "mcp_auth.cancel"), "cancel"))

        def handler(value: str | None) -> None:
            from neonrp.core.user_config import set_mcp_authorized

            if value == "grant":
                set_mcp_authorized(True)
                on_granted()
                return
            on_cancel()

        self.push_screen(
            ChoicePickerScreen(get_message(self.locale, "mcp_auth.title"), options),
            handler,
        )


class InputArea(Container):
    """Input area with inline Claude-style status metadata."""

    def __init__(self, mode: AppMode = "build", **kwargs):
        super().__init__(**kwargs)
        self.mode = mode
        self.router_mode = "-"
        self.locale = "en"
        self.model_display = "-"
        self.world_time = "-"
        self.world_location = "-"
        self.connection_state = "mcp:off discord:-"
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self._prompt_visible = True
        self._prompt_timer = None
        self._run_status_text = ""
        self._run_active = False
        self._run_anim_frame = 0
        self._run_anim_timer = None

    _RUN_MIN_WIDTH = 24
    _RUN_BASE_COLOR = "#23282f"
    _RUN_GLOW_COLORS = ["#2a3038", "#313843", "#39414d", "#485363", "#39414d", "#313843", "#2a3038"]

    def compose(self) -> ComposeResult:
        """Compose the input area."""
        yield Static("", id="run-activity-line")
        yield Static("", id="slash-suggestions")
        with Horizontal(id="input-row"):
            yield Static(">", id="input-prompt", classes="input-prompt-on")
            yield Input(
                placeholder=get_message(self.locale, "input_hint"),
                id="message-input",
                suggester=SlashCommandSuggester(),
            )
        with Vertical(id="input-status-block"):
            with Horizontal(classes="input-status-row"):
                yield Static("", id="input-status-top-left")
                yield Static("", id="input-status-top-center")
                yield Static("", id="input-status-top-right")
            with Horizontal(classes="input-status-row"):
                yield Static("", id="input-status-bottom-left")
                yield Static("", id="input-status-bottom-center")
                yield Static("", id="input-status-bottom-right")

    def on_mount(self) -> None:
        self._render_run_activity()
        self._prompt_timer = self.set_interval(0.55, self._tick_prompt_indicator)
        self._render_input_placeholder()
        self._render_status_line()

    def set_mode(self, mode: AppMode) -> None:
        """Update mode metadata."""
        self.mode = mode
        self._render_status_line()

    def set_locale(self, locale: str) -> None:
        """Update UI locale for inline input copy."""
        self.locale = resolve_locale(locale)
        self._render_input_placeholder()
        self._render_status_line()

    def update_status(
        self,
        *,
        mode: AppMode | None = None,
        router_mode: str | None = None,
        model_display: str | None = None,
        world_time: str | None = None,
        world_location: str | None = None,
        connection_state: str | None = None,
        prompt_tokens: int | None = None,
        completion_tokens: int | None = None,
    ) -> None:
        """Update inline status metadata shown under the input."""
        if mode is not None:
            self.mode = mode
        if router_mode is not None:
            self.router_mode = router_mode or "-"
        if model_display is not None:
            self.model_display = model_display or "-"
        if world_time is not None:
            self.world_time = world_time or "-"
        if world_location is not None:
            self.world_location = world_location or "-"
        if connection_state is not None:
            self.connection_state = connection_state or "-"
        if prompt_tokens is not None:
            self.prompt_tokens = max(0, int(prompt_tokens))
        if completion_tokens is not None:
            self.completion_tokens = max(0, int(completion_tokens))
        self._render_status_line()

    def _tick_prompt_indicator(self) -> None:
        self._prompt_visible = not self._prompt_visible
        try:
            prompt = self.query_one("#input-prompt", Static)
        except Exception:
            return
        prompt.update(">")
        prompt.classes = "input-prompt-on" if self._prompt_visible else "input-prompt-off"

    def _render_input_placeholder(self) -> None:
        try:
            input_widget = self.query_one("#message-input", Input)
        except Exception:
            return
        input_widget.placeholder = get_message(self.locale, "input_hint")

    def _render_status_line(self) -> None:
        try:
            top_left, top_center, top_right, bottom_left, bottom_center, bottom_right = self._build_status_segments()
            self.query_one("#input-status-top-left", Static).update(top_left)
            self.query_one("#input-status-top-center", Static).update(top_center)
            self.query_one("#input-status-top-right", Static).update(top_right)
            self.query_one("#input-status-bottom-left", Static).update(bottom_left)
            self.query_one("#input-status-bottom-center", Static).update(bottom_center)
            self.query_one("#input-status-bottom-right", Static).update(bottom_right)
        except Exception:
            pass

    @staticmethod
    def _format_compact_count(value: int) -> str:
        if value < 1000:
            return str(value)
        if value < 10_000:
            return f"{value / 1000:.1f}k".rstrip("0").rstrip(".")
        return f"{value // 1000}k"

    def _build_status_segments(self) -> tuple[str, str, str, str, str, str]:
        prompt = self._format_compact_count(self.prompt_tokens)
        completion = self._format_compact_count(self.completion_tokens)
        top_left = f"{localize_mode(self.locale, self.mode or 'build')} · {self.router_mode or '-'}"
        top_center = self.model_display or "-"
        top_right = f"{self.connection_state or '-'} · ↑{prompt} ↓{completion}"
        bottom_left = self.world_time or "-"
        bottom_center = self.world_location or "-"
        bottom_right = ""
        return top_left, top_center, top_right, bottom_left, bottom_center, bottom_right

    def _build_status_text(self) -> str:
        """Return a plain-text snapshot useful for tests/debugging."""
        return "\n".join(" | ".join(part for part in row if part) for row in [self._build_status_segments()[:3], self._build_status_segments()[3:]])

    def set_run_status(self, text: str) -> None:
        """Enable fixed-height input activity animation while waiting."""
        self._run_status_text = text
        self._run_active = True
        if self._run_anim_timer is None:
            self._run_anim_timer = self.set_interval(0.07, self._tick_run_activity)
        self._render_run_activity()

    def clear_run_status(self) -> None:
        """Disable input activity animation."""
        self._run_status_text = ""
        self._run_active = False
        if self._run_anim_timer is not None:
            try:
                self._run_anim_timer.stop()
            except Exception:
                pass
            self._run_anim_timer = None
        self._render_run_activity()

    def _tick_run_activity(self) -> None:
        if not self._run_active:
            return
        width = self._current_run_line_width()
        self._run_anim_frame = (self._run_anim_frame + 1) % width
        self._render_run_activity()

    def _current_run_line_width(self) -> int:
        width = 0
        try:
            line = self.query_one("#run-activity-line", Static)
            width = int(getattr(line.size, "width", 0) or 0)
        except Exception:
            width = 0
        if width <= 0:
            width = int(getattr(self.size, "width", 0) or 0)
        if width <= 0:
            width = int(getattr(getattr(self.app, "size", None), "width", 0) or 0) - 2
        return max(self._RUN_MIN_WIDTH, width)

    def _render_run_activity(self) -> None:
        try:
            line = self.query_one("#run-activity-line", Static)
        except Exception:
            return
        width = self._current_run_line_width()
        if not self._run_active:
            line.display = False
            line.update("")
            return
        line.display = True

        # Overlay the status text at the start of the glow bar so the
        # user actually sees *what* is happening, not just a pulsing line.
        status_text = str(self._run_status_text or "").strip()
        spinner = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"][self._run_anim_frame % 10]
        if status_text:
            label = f" {spinner}  {status_text}   "
        else:
            label = f" {spinner}  "
        label_len = len(label)

        chars: list[str] = []
        color_by_pos: list[str] = []
        for i, ch in enumerate(label):
            chars.append(ch)
            color_by_pos.append("#E4E4E7" if ch != " " else self._RUN_BASE_COLOR)

        # Fill the remaining width with the existing glow bar.
        remaining = max(0, width - label_len)
        bar_chars = ["─"] * remaining
        bar_colors = [self._RUN_BASE_COLOR] * remaining
        trail_len = len(self._RUN_GLOW_COLORS)
        if remaining > 0:
            start = self._run_anim_frame % remaining
            for i, color in enumerate(self._RUN_GLOW_COLORS):
                pos = (start + i) % remaining
                bar_colors[pos] = color
                if 2 <= i <= trail_len - 3:
                    bar_chars[pos] = "━"
        chars.extend(bar_chars)
        color_by_pos.extend(bar_colors)

        # Render as compact color runs for better performance/readability.
        runs: list[tuple[str, str]] = []
        run_color = color_by_pos[0]
        run_text = chars[0]
        for i in range(1, len(chars)):
            if color_by_pos[i] == run_color:
                run_text += chars[i]
            else:
                runs.append((run_color, run_text))
                run_color = color_by_pos[i]
                run_text = chars[i]
        runs.append((run_color, run_text))

        markup = "".join(f"[{color}]{text}[/]" for color, text in runs)
        line.update(markup)


class SlashCommandSuggester(Suggester):
    """Inline ghost-text suggester for slash commands."""

    def __init__(self) -> None:
        super().__init__(use_cache=False, case_sensitive=True)

    async def get_suggestion(self, value: str) -> str | None:
        if not value.startswith("/"):
            return None
        command_text = value[1:]
        if not command_text:
            return None

        parts = command_text.split()
        has_trailing_space = value.endswith(" ")
        cmd_name = parts[0]
        spec = COMMANDS.get(cmd_name, {})
        has_subcommands = isinstance(spec.get("subcommands"), list)

        # Partial command name → suggest full command + args hint
        if cmd_name not in COMMANDS and not has_trailing_space and len(parts) == 1:
            matches = get_command_suggestions(cmd_name)
            if matches:
                best = matches[0]
                best_spec = COMMANDS.get(best, {})
                hint = _args_hint(best, best_spec)
                return f"/{best} {hint}" if hint else f"/{best}"
            return None

        # Complete command, user just added space → show args hint
        if cmd_name in COMMANDS and has_trailing_space and len(parts) == 1:
            if has_subcommands:
                subs = spec["subcommands"]
                return f"{value}{subs[0]}"
            hint = _args_hint(cmd_name, spec)
            if hint:
                return f"{value}{hint}"
            return None

        # Typing subcommand → suggest full subcommand + its args hint
        if has_subcommands and len(parts) == 2 and not has_trailing_space:
            sub_prefix = parts[1]
            subs = get_subcommand_suggestions(cmd_name, sub_prefix)
            if subs:
                sub_hint = spec.get("sub_args_hint", {}).get(subs[0], "")
                suffix = f" {sub_hint}" if sub_hint else ""
                return f"/{cmd_name} {subs[0]}{suffix}"
            return None

        # Subcommand complete with trailing space → show sub args hint
        if has_subcommands and len(parts) == 2 and has_trailing_space:
            sub_name = parts[1]
            sub_hint = spec.get("sub_args_hint", {}).get(sub_name, "")
            if sub_hint:
                return f"{value}{sub_hint}"
            return None

        return None


def _args_hint(cmd_name: str, spec: dict) -> str:
    """Return placeholder hint for a command's expected arguments."""
    return get_command_args_hint(cmd_name, spec)


class NeonRPApp(App):
    """NeonRP conversational TUI ."""

    CSS = """
    Screen {
        layout: vertical;
        padding: 0;
    }

    StatusBar {
        height: 1;
        background: $surface-darken-1;
        padding: 0 1;
    }

    #status-row {
        height: 1;
        width: 1fr;
    }

    #status-text {
        width: 1fr;
    }

    #status-tokens {
        width: auto;
        text-align: right;
    }

    ConversationView {
        height: 1fr;
        border: none;
        padding: 1 2 0 2;
        layout: vertical;
        overflow-y: auto;
        overflow-x: hidden;
    }

    ConversationView .msg-header {
        margin: 0 0 0 0;
        color: $text-muted;
    }

    ConversationView .msg-user {
        color: $text;
    }

    ConversationView .msg-header.msg-user {
        color: $text;
    }

    ConversationView .msg-assistant {
        color: $text;
    }

    ConversationView .msg-header.msg-assistant {
        color: #8fc6ff;
    }

    ConversationView .msg-tool {
        color: #8a919b;
    }

    ConversationView .msg-system {
        color: $text-muted;
    }

    ConversationView .msg-thinking {
        color: #b18a53;
    }

    ConversationView .thinking-row {
        width: 1fr;
        height: auto;
        margin: 0 0 1 0;
        align: left top;
    }

    ConversationView .thinking-label {
        width: auto;
        color: #b18a53;
    }

    ConversationView .thinking-content {
        width: 1fr;
        height: auto;
        color: #a9b0b9;
    }

    ConversationView .msg-body {
        width: 1fr;
        height: auto;
        margin: 0;
    }

    /* L14.5 semantic footer: compact chip list shown under narrative in play/mcp. */
    ConversationView .msg-semantic-footer {
        width: 1fr;
        height: auto;
        margin: 0 2 1 2;
        padding: 0 1;
        background: transparent;
        color: #a1a1aa;
    }

    /* L14.5 layer toggle (Ctrl+L cycles layer-1 → layer-2 → layer-3).
       layer-1: narrative only
       layer-2: + semantic footer (state_update / rule_check chips)
       layer-3: + tool calls + execution details + thinking
       Default (no class) == layer-2. */
    ConversationView.layer-1 .msg-semantic-footer,
    ConversationView.layer-1 .msg-tool,
    ConversationView.layer-1 .tool-collapsible,
    ConversationView.layer-1 .execution-live,
    ConversationView.layer-1 .execution-fold,
    ConversationView.layer-1 .execution-summary,
    ConversationView.layer-1 .assistant-activity-line {
        display: none;
    }

    ConversationView.layer-2 .msg-tool,
    ConversationView.layer-2 .tool-collapsible,
    ConversationView.layer-2 .execution-live,
    ConversationView.layer-2 .execution-fold,
    ConversationView.layer-2 .execution-summary,
    ConversationView.layer-2 .assistant-activity-line {
        display: none;
    }

    ConversationView .code-block {
        width: 1fr;
        height: auto;
        margin: 0 2 1 2;
        padding: 0 1;
        border: none;
        background: transparent;
        layout: vertical;
    }

    ConversationView .code-lang {
        width: 1fr;
        height: auto;
        color: $success;
    }

    ConversationView .code-body {
        width: 1fr;
        height: auto;
        margin: 0;
    }

    ConversationView .tool-collapsible {
        width: 1fr;
        margin: 0 0 1 0;
        padding: 0;
        border: none;
        background: transparent;
    }

    ConversationView .tool-collapsible > Contents {
        padding: 0 0 0 1;
    }

    ConversationView .execution-live {
        width: 1fr;
        height: auto;
        margin: 0 0 1 0;
        color: #8a919b;
    }

    ConversationView .execution-summary {
        width: 1fr;
        height: auto;
        margin: 0 0 1 0;
        color: #8a919b;
    }

    ConversationView .assistant-activity-line {
        width: 1fr;
        height: auto;
        margin: 0 0 1 0;
        color: #94A3B8;
    }

    ConversationView .semantic-scene-header {
        color: #a5b4fc;
        margin: 0 0 1 0;
    }

    ConversationView .semantic-markdown-heading {
        color: #c4b5fd;
        margin: 0 0 1 0;
    }

    ConversationView .semantic-agent-tag {
        color: #93c5fd;
    }

    ConversationView .semantic-state-update {
        color: #86efac;
    }

    ConversationView .semantic-awaiting {
        color: #fcd34d;
    }

    ConversationView .semantic-inner {
        color: #d8b4fe;
    }

    ConversationView .semantic-choice-line {
        color: #f5f5f5;
        margin: 0 0 0 2;
    }

    ConversationView .semantic-player-line {
        color: #e4e4e7;
    }

    ConversationView .semantic-narrative-line {
        color: $text;
    }

    ConversationView .msg-spacer {
        height: 1;
    }

    ConversationView .msg-divider {
        width: 1fr;
        height: auto;
        margin: 0 0 1 0;
        color: #3F3F46;
    }

    AskUserInlinePanel {
        display: none;
        width: 1fr;
        height: auto;
        max-height: 50%;
        overflow-y: auto;
        overflow-x: hidden;
        border: solid #34414f;
        padding: 0 1;
        margin: 0;
        layout: vertical;
        background: #10151b;
    }

    AskUserInlinePanel.visible {
        display: block;
    }

    #ask-inline-question {
        height: auto;
        margin: 0 0 1 0;
        color: #d4d8dd;
    }

    #ask-inline-options-scroll {
        width: 1fr;
        height: auto;
        min-height: 1;
        max-height: 14;
        overflow-y: scroll;
        margin: 0 0 1 0;
    }

    #ask-inline-options {
        height: auto;
        padding: 0 0 0 0;
    }

    #ask-inline-options Button {
        width: 1fr;
        height: auto;
        min-height: 1;
        margin: 0;
        background: #18212b;
        border: solid #2e3b49;
        color: #c5ccd4;
    }

    #ask-inline-options Button:hover {
        background: #223042;
        border: solid #4a6780;
        color: #e5edf6;
        text-style: bold;
    }

    #ask-inline-options Button:focus {
        background: #223042;
        border: solid #5c83a3;
        color: #f0f5fa;
        text-style: bold;
    }

    #ask-inline-input {
        width: 1fr;
        margin: 0;
    }

    #ask-inline-actions {
        width: 1fr;
        height: auto;
        align: left middle;
        margin: 0;
    }

    #ask-inline-hint {
        width: 1fr;
        color: #7f8995;
    }

    InputArea {
        width: 1fr;
        height: auto;
        min-height: 3;
        border-top: solid #2a2f36;
        padding: 0 2 1 2;
        layout: vertical;
    }

    InputArea.ask-user-active {
        height: 0;
        min-height: 0;
        padding: 0;
    }

    InputArea.ask-user-active #run-activity-line {
        display: none;
    }

    InputArea.ask-user-active #slash-suggestions {
        display: none;
    }

    InputArea.ask-user-active Horizontal {
        display: none;
    }

    InputArea.ask-user-active #input-status-block {
        display: none;
    }

    #slash-suggestions {
        display: none;
        width: 1fr;
        border: round $primary-darken-1;
        background: $surface-darken-1;
        color: $text-muted;
        padding: 0 1;
        margin: 0 0 1 0;
        height: auto;
        max-height: 14;
    }

    #slash-suggestions.visible {
        display: block;
    }

    #run-activity-line {
        display: block;
        width: 1fr;
        height: 1;
        align: left middle;
        margin: 0 0 1 0;
    }

    InputArea Horizontal {
        width: 1fr;
        height: auto;
        margin: 0;
        align: left middle;
    }

    #input-row {
        height: auto;
    }

    #input-status-block {
        width: 1fr;
        height: auto;
        margin: 0;
        padding: 0 0 0 2;
    }

    .input-status-row {
        width: 1fr;
        height: auto;
        align: left middle;
    }

    #input-status-top-left,
    #input-status-bottom-left {
        width: 1fr;
        color: #7f8995;
        text-align: left;
    }

    #input-status-top-center,
    #input-status-bottom-center {
        width: 1fr;
        color: #7f8995;
        text-align: center;
    }

    #input-status-top-right,
    #input-status-bottom-right {
        width: 1fr;
        color: #7f8995;
        text-align: right;
    }

    #input-prompt {
        width: 2;
        color: #2ed573;
        text-style: bold;
        content-align: left middle;
    }

    .input-prompt-on {
        color: #2ed573;
    }

    .input-prompt-off {
        color: #173b23;
    }

    InputArea Input {
        width: 1fr;
        margin: 0;
        background: transparent;
        border: none;
        color: #d8dee9;
    }

    #message-input {
        background: transparent;
        border: none;
        color: #d8dee9;
        padding: 0;
    }

    InputArea Input:disabled {
        color: #6e7682;
    }

    .bg-blue {
        background: $primary;
        color: $text;
    }

    .bg-yellow {
        background: $warning;
        color: $text;
    }

    .bg-green {
        background: $success;
        color: $text;
    }

    .bg-magenta {
        background: #a855f7;
        color: $text;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("ctrl+q", "safe_quit", "Quit"),
        Binding("ctrl+k", "command_palette", "Commands"),
        Binding("ctrl+p", "command_palette", "Commands"),
        Binding("ctrl+l", "cycle_layer", "Cycle L1/L2/L3"),
        Binding("f6", "copy_transcript", "Copy"),
    ]
    _CALLING_CHUNK_RE = re.compile(r"^\s*\[calling\s+([^\]]+?)\.\.\.\]\s*$", re.IGNORECASE)
    _TOOL_NAME_TOKEN_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_:\.-]*$")
    _TOOL_CALL_FUNC_RE = re.compile(r"([A-Za-z_][A-Za-z0-9_:\.-]*)\s*\(")
    _SUB_AGENT_TAG_RE = re.compile(r"^\[\[subagent:([^\]]+)\]\](.*)$", re.DOTALL)
    _TOKEN_SPLIT_RE = re.compile(r"\w+|[^\w\s]", re.UNICODE)
    _MAX_VISIBLE_SLASH_SUGGESTIONS = 10

    def __init__(
        self,
        root: Path | None = None,
        branch: str | None = None,
        provider: str | None = None,
        continue_session: bool = False,
        startup_commands: list[str] | None = None,
        verbose: bool = False,
        mode: AppMode = "build",
    ):
        super().__init__()
        self.root = root or Path.cwd()
        self.branch = branch
        self.provider = provider
        self.continue_session = continue_session
        self.startup_commands = list(startup_commands or [])
        self.verbose = verbose
        self.mode: AppMode = mode
        self.ui_locale = "en"
        self._mcp_mode = mode == "mcp"
        self._mcp_server: Any = None
        self._mcp_claude_process: Any = None  # subprocess.Popen[str] | None
        # If the launcher requested a resumed session, start at turn 1 so the
        # first `claude -p` invocation uses `--continue` and picks up the
        # sibling workspace's prior conversation instead of starting fresh.
        self._mcp_claude_turn_count = 1 if (self._mcp_mode and continue_session) else 0
        # Per-turn buffer: accumulates streamed claude -p output so we can
        # persist one coherent assistant message to the session log on end.
        self._mcp_assistant_buffer: list[str] = []
        # External bridge hub (Discord / Telegram / future adapters). Starts
        # empty; launcher or /bridge command attaches bridges when enabled.
        # None until `_ensure_bridge_hub()` lazily creates it — keeps cost
        # at zero for users who don't use external bridges.
        self._bridge_hub: Any = None  # BridgeHub | None
        self.session: ConversationSession | None = None
        self.skill_loader = SkillLoader(self.root)
        self.auto_apply = get_auto_apply(self.root)
        self._pending_proposal: dict[str, Any] | None = None
        self._current_run_result: ConversationTurnResult | None = None
        self._provider_notice_shown = False
        self._stream_started = False
        self._subagent_stream_seen: set[str] = set()
        self._last_user_input = ""
        self._est_prompt_tokens_total = 0
        self._est_completion_tokens_total = 0
        self._active_send_thread: threading.Thread | None = None
        # When a turn is paused on ask_user, this holds the panel's submit
        # callback so that typed input (from the main TUI input OR a Discord
        # bridge inbound) can answer the prompt instead of bouncing off the
        # "A request is already running" guard. Cleared the moment we hand
        # the text back to the blocked worker thread.
        self._active_ask_user_submit: Callable[[str], None] | None = None
        self._slash_suggestions: list[tuple[str, str]] = []
        self._slash_selected_index = 0
        self._suppress_input_change = False
        self._input_history: list[str] = []
        self._history_index: int | None = None
        self._history_draft = ""
        self._verbose_log_path: Path | None = None
        self._verbose_lock = threading.Lock()
        self._conversation_epoch = 0

    def compose(self) -> ComposeResult:
        """Compose the TUI layout."""
        # Load manifest
        manifest_path = get_manifest_path(self.root)
        if manifest_path.exists():
            manifest = Manifest(**json.loads(manifest_path.read_text(encoding="utf-8")))
            self.branch = self.branch or manifest.current_branch
        else:
            self.branch = self.branch or "main"

        # Yield components
        yield ConversationView(display_mode=self.mode, id="conversation-view")
        yield AskUserInlinePanel(id="ask-user-inline")
        yield InputArea(mode=self.mode, id="input-area")

    def on_mount(self) -> None:
        """Initialize on mount."""
        self.title = f"NeonRP — {self.root.name}"
        self.ui_locale = self._resolve_ui_locale()
        self.query_one("#input-area", InputArea).set_locale(self.ui_locale)

        # L14.5 — enable semantic annotations in play / mcp mode only.
        try:
            view = self.query_one("#conversation-view", ConversationView)
            view.set_semantic_mode("mcp" if self._mcp_mode else str(self.mode))
            # Default layer: L2 in play/mcp (narrative + semantic chips),
            # L3 in build/sandbox (author wants to see tool calls).
            default_layer = 2 if (self._mcp_mode or self.mode == "play") else 3
            view.set_semantic_layer(default_layer)
            self._semantic_layer = default_layer
        except Exception:
            self._semantic_layer = 2

        if self._mcp_mode:
            self._start_mcp_server()
            # MCP doesn't use ConversationSession, but we mirror the transcript
            # into `<game>/.neonrp/sessions/<branch>.jsonl` on every turn so
            # the TUI can replay it here on continue.
            if self.continue_session:
                self._restore_mcp_session()
        else:
            # Initialize conversation session
            self._init_session()

            # Startup policy: default new session; optional continue.
            self._apply_startup_session_policy()

            # Show provider setup hints
            self._show_provider_setup_notice()
            self._show_init_hint_if_needed()

        # Start external bridges (Discord, etc) if user has autostart=true.
        # No-op for users without any bridge configured.
        try:
            self._ensure_bridge_hub()
        except Exception:
            pass

        if self.verbose:
            self._set_verbose_enabled(True, announce=True)

        # Focus input
        self.query_one("#message-input", Input).focus()
        self._refresh_status(include_event_count=False)
        if self.startup_commands:
            self.call_after_refresh(self._run_startup_commands)

    def _run_startup_commands(self) -> None:
        """Execute deferred commands after the UI has mounted.

        Inputs that start with `/` go through slash-command handling;
        anything else is injected as a regular user message (so the agent
        can pick it up as the opening turn).
        """
        commands = list(self.startup_commands)
        self.startup_commands = []
        for command in commands:
            if not command:
                continue
            if command.startswith("/"):
                self._handle_slash_command(command)
            else:
                self._send_message(command)

    def _show_init_hint_if_needed(self) -> None:
        """Show hint when project is not initialized yet."""
        manifest_path = get_manifest_path(self.root)
        if manifest_path.exists():
            return
        view = self.query_one("#conversation-view", ConversationView)
        view.write("[yellow]Project not initialized in this directory.[/]\n")
        view.write("[dim]Run /init, then /game new to scaffold starter game data.[/]\n")

    def _init_session(self) -> None:
        """Initialize conversation session."""
        agent = self._get_default_agent()
        session_mode: ConversationMode = "build" if self._mcp_mode else self.mode
        self.session = ConversationSession(
            root=self.root,
            agent_id=agent,
            mode=session_mode,
            provider=self.provider,
        )

    def _start_mcp_server(self) -> None:
        """Start embedded MCP server and show connection info."""
        from neonrp.mcp_server import WorldLinesMCPServer
        from neonrp.core.template_assets import get_claude_workspace_dir, write_claude_workspace_mcp_config

        view = self.query_one("#conversation-view", ConversationView)

        def on_narrate(speaker: str, text: str) -> None:
            self._safe_call_from_thread(self._mcp_narrate, speaker, text)

        def on_tool_use(name: str, params: dict[str, Any]) -> None:
            self._safe_call_from_thread(self._show_tool_use, name, params)

        def on_tool_result(name: str, params: dict[str, Any], result: str) -> None:
            self._safe_call_from_thread(self._show_tool_result, name, params, result)

        try:
            server = WorldLinesMCPServer(
                root=self.root,
                on_narrate=on_narrate,
                on_tool_use=on_tool_use,
                on_tool_result=on_tool_result,
            )
            server.start()
            self._mcp_server = server
            workspace_root = get_claude_workspace_dir(self.root)
            write_claude_workspace_mcp_config(self.root, server_url=server.url)

            view.write("[bold magenta]MCP Server started[/]\n")
            view.write(f"[dim]SSE endpoint:[/] [bold cyan]{server.url}[/]\n")
            view.write(f"[dim]Claude workspace:[/] [bold cyan]{workspace_root}[/]\n\n")
            if shutil.which("claude"):
                view.write("[green]Ready.[/] [dim]Type a message — it goes to `claude -p` in the workspace.[/]\n\n")
            else:
                view.write(
                    "[yellow]`claude` CLI not on PATH.[/]\n"
                    "[dim]Install Claude Code, or use /wl-model to switch to a hosted model.[/]\n\n"
                )
        except Exception as exc:
            view.write(f"[red]Failed to start MCP server: {exc}[/]\n")

    def _mcp_narrate(self, speaker: str, text: str) -> None:
        """Handle narrate callback from MCP server.

        Sub-agents invoke this via the MCP `narrate` tool. These calls do
        NOT appear in `claude -p`'s stdout (so they're absent from
        `_mcp_assistant_buffer`), which means without an explicit mirror
        here they never reach session.jsonl — breaking restore and leaving
        Discord relay blind. `add_named_assistant_message` already gates
        on `presentation_hidden`, and we only persist if the view actually
        rendered it, keeping TUI/session/Discord in lockstep.
        """
        view = self.query_one("#conversation-view", ConversationView)
        hidden = view._is_agent_hidden(speaker)
        view.add_named_assistant_message(speaker, text)
        view.add_assistant_end()
        if not hidden and text and text.strip():
            label = speaker.strip() or "Narrator"
            self._append_mcp_session_assistant(f"[{label}]\n{text.strip()}")

    def _apply_startup_session_policy(self) -> None:
        """Choose startup behavior: default new session unless continue requested."""
        if self.continue_session:
            restored = self._restore_session()
            if not restored:
                view = self.query_one("#conversation-view", ConversationView)
                view.write("[dim]No previous session found. Started a new session.[/]\n")
            return
        self._start_new_session(announce=False)

    def _restore_mcp_session(self) -> bool:
        """Restore the mirrored MCP session transcript on continue.

        MCP mode doesn't use ConversationSession; instead `_send_mcp_message`
        appends each turn to the same `.neonrp/sessions/<branch>.jsonl` file.
        On continue, we read that file and re-render its messages so the user
        sees the prior conversation (Claude Code's own `--continue` separately
        restores its model-side context).
        """
        try:
            from neonrp.core.session import read_session

            branch = self._resolve_session_branch()
            entries = read_session(self.root, branch)
        except Exception:
            return False
        if not entries:
            return False

        messages: list[Any] = []
        for entry in entries:
            try:
                messages.append(entry.to_message())
            except Exception:
                continue
        if not any(getattr(m, "role", "") in {"user", "assistant"} for m in messages):
            return False

        try:
            view = self.query_one("#conversation-view", ConversationView)
            view.write("[dim]--- Previous MCP session restored ---[/]\n")
            self._render_session_messages(messages)
        except Exception:
            return False
        return True

    def _restore_session(self) -> bool:
        """Restore previous session messages."""
        if not self.session:
            return False

        loaded = self.session.resume()
        if loaded <= 0:
            return False

        messages = self.session.get_messages()
        if not any(m.role in {"user", "assistant"} for m in messages):
            return False

        view = self.query_one("#conversation-view", ConversationView)
        view.write("[dim]--- Previous session restored ---[/]\n")
        self._render_session_messages(messages)
        return True

    def _render_session_messages(self, messages: list[Any]) -> None:
        """Render persisted user/assistant messages into conversation view."""
        view = self.query_one("#conversation-view", ConversationView)
        root_speaker = self._get_root_speaker_name()
        ask_user_fallbacks: dict[str, tuple[str, list[str]]] = {}
        pending_tool_calls: dict[str, tuple[str, dict[str, Any]]] = {}
        idx = 0
        while idx < len(messages):
            message = messages[idx]
            if message.role == "system":
                idx += 1
                continue
            # Call the compact-message detectors on the CLASS (they're
            # @staticmethod), not via `view`. Otherwise unit tests that use
            # a bare `MagicMock()` for view get a truthy Mock back and take
            # this branch for every user message, skipping real render.
            if message.role == "user" and ConversationView.is_compact_summary_message(message.content or ""):
                acknowledgement = None
                if idx + 1 < len(messages):
                    next_message = messages[idx + 1]
                    if next_message.role == "assistant" and ConversationView.is_compact_ack_message(next_message.content or ""):
                        acknowledgement = next_message.content or ""
                        idx += 1
                view.add_compact_summary_fold(message.content or "", acknowledgement)
                idx += 1
                continue
            if message.role == "user":
                view.add_user_message(message.content or "")
            elif message.role == "assistant":
                for tool_call in getattr(message, "tool_calls", []) or []:
                    tool_name = ConversationView._canonical_tool_name(getattr(tool_call, "name", ""))
                    tool_call_id = str(getattr(tool_call, "id", "") or "").strip()
                    raw_args = getattr(tool_call, "arguments", {})
                    params = raw_args if isinstance(raw_args, dict) else {}
                    if tool_call_id:
                        pending_tool_calls[tool_call_id] = (tool_name, params)
                    view.add_tool_indicator(tool_name, params)
                    if tool_name == "ask_user" and tool_call_id:
                        question, options = self._extract_ask_user_prompt_from_args(params)
                        ask_user_fallbacks[tool_call_id] = (question, options)
                if message.content:
                    cleaned_content = self._normalize_assistant_text(message.content)
                    if not cleaned_content:
                        continue
                    speaker_name = root_speaker
                    message_speaker = str(getattr(message, "name", "") or "").strip()
                    if message_speaker:
                        speaker_name = self._get_agent_display_name(message_speaker)
                    view.add_named_assistant_message(speaker_name, cleaned_content)
                    view.add_assistant_end()
            elif message.role == "tool":
                tool_call_id = str(getattr(message, "tool_call_id", "") or "").strip()
                tool_name = ConversationView._canonical_tool_name(getattr(message, "name", "") or "")
                params: dict[str, Any] = {}
                if tool_call_id in pending_tool_calls:
                    pending_name, pending_params = pending_tool_calls[tool_call_id]
                    if pending_name:
                        tool_name = pending_name
                    if isinstance(pending_params, dict):
                        params = pending_params
                raw_tool_result = getattr(message, "content", "") or ""
                if tool_name:
                    if not params:
                        view.add_tool_indicator(tool_name, {})
                    view.complete_tool_indicator(tool_name, params, raw_tool_result)
                if self._is_todo_tool_message(message):
                    items = self._extract_todo_items_from_tool_message(message)
                    if items:
                        view.add_todo_display(items)
                elif self._is_ask_user_tool_message(message):
                    fallback_question, fallback_options = ask_user_fallbacks.get(tool_call_id, ("", []))
                    selected = self._extract_ask_user_selection(
                        raw_tool_result,
                        fallback_question=fallback_question,
                        fallback_options=fallback_options,
                    )
                    if selected:
                        question, response, options = selected
                        rendered = self._format_ask_user_selection_message(question, response, options)
                        if rendered:
                            view.add_user_message(rendered)
                    else:
                        cancelled = False
                        try:
                            payload = json.loads(raw_tool_result)
                            cancelled = str(payload.get("status", "")).strip().lower() == "cancelled"
                        except Exception:
                            cancelled = False
                        if cancelled:
                            rendered_cancelled = self._format_ask_user_cancelled_message(
                                fallback_question,
                                fallback_options,
                            )
                            if rendered_cancelled:
                                view.add_user_message(rendered_cancelled)
                elif self._is_task_tool_message(message):
                    rendered_task = self._extract_task_tool_transcript(raw_tool_result)
                    if rendered_task:
                        speaker, body = rendered_task
                        view.add_named_assistant_message(speaker, body)
                        view.add_assistant_end()
            idx += 1

    @staticmethod
    def _is_todo_tool_message(message: Any) -> bool:
        return str(getattr(message, "name", "") or "").strip() == "TodoWrite"

    @staticmethod
    def _is_ask_user_tool_message(message: Any) -> bool:
        return str(getattr(message, "name", "") or "").strip() == "ask_user"

    @staticmethod
    def _is_task_tool_message(message: Any) -> bool:
        return str(getattr(message, "name", "") or "").strip() == "task"

    @staticmethod
    def _extract_ask_user_prompt_from_args(raw_args: Any) -> tuple[str, list[str]]:
        """Parse ask_user tool-call args into fallback question/options."""
        if not isinstance(raw_args, dict):
            return "", []

        question = ""
        options_raw: list[Any] = []

        questions = raw_args.get("questions")
        if isinstance(questions, list):
            first = next((item for item in questions if isinstance(item, dict)), None)
            if first:
                question = str(first.get("question", "") or "").strip()
                options_value = first.get("options", [])
                if isinstance(options_value, list):
                    options_raw = options_value
        if not question:
            question = str(raw_args.get("question", "") or "").strip()
        if not options_raw:
            options_value = raw_args.get("options", [])
            if isinstance(options_value, list):
                options_raw = options_value

        options: list[str] = []
        for option in options_raw:
            if isinstance(option, dict):
                label = str(option.get("label", "") or "").strip()
            else:
                label = str(option or "").strip()
            if label:
                options.append(label)
        return question, options

    @staticmethod
    def _extract_ask_user_selection(
        raw_result: str,
        fallback_question: str = "",
        fallback_options: list[str] | None = None,
    ) -> tuple[str, str, list[str]] | None:
        """Best-effort parse of ask_user tool output payload.

        Supports both new format ``{"answers": {"0": "label"}}`` and
        legacy format ``{"data": {"question": ..., "response": ...}}``.
        """
        if not isinstance(raw_result, str) or not raw_result.strip():
            return None
        try:
            payload = json.loads(raw_result)
        except Exception:
            return None
        if not isinstance(payload, dict):
            return None

        # --- New lean format: {"answers": {"0": "label", ...}} ---
        answers = payload.get("answers")
        if isinstance(answers, dict) and answers:
            first_answer = str(next(iter(answers.values()), "")).strip()
            if not first_answer:
                return None
            question = str(fallback_question or "").strip()
            options = [str(o).strip() for o in (fallback_options or []) if str(o or "").strip()]
            return question, first_answer, options

        # --- Legacy format: {"data": {"question", "options", "response"}} ---
        data = payload.get("data")
        if not isinstance(data, dict):
            return None
        response = str(data.get("response", "") or "").strip()
        if not response:
            return None
        question = str(data.get("question", "") or "").strip()
        if not question:
            question = str(fallback_question or "").strip()
        options_raw = data.get("options")
        if not isinstance(options_raw, list):
            options_raw = fallback_options if isinstance(fallback_options, list) else []
        options: list[str] = []
        for option in options_raw:
            value = str(option or "").strip()
            if value:
                options.append(value)
        return question, response, options

    @staticmethod
    def _format_ask_user_selection_message(question: str, response: str, options: list[str] | None = None) -> str:
        """Format ask_user selection as a user-visible transcript message."""
        q = str(question or "").strip()
        r = str(response or "").strip()
        opts = [str(option or "").strip() for option in (options or []) if str(option or "").strip()]
        if not r:
            return ""
        if opts:
            lines = [f"- [{'x' if option == r else ' '}] {option}" for option in opts]
            if r not in opts:
                lines.append(f"- [x] {r}")
            return f"{q}\n" + "\n".join(lines) if q else "\n".join(lines)
        if q:
            return f"{q}\n{r}"
        return r

    def _format_ask_user_cancelled_message(self, question: str, options: list[str] | None = None) -> str:
        """Render ask_user prompt details when user cancels via ESC."""
        locale = getattr(self, "ui_locale", None) or getattr(self, "locale", "en") or "en"
        cancelled = get_message(locale, "ask_user.cancelled")
        q = str(question or "").strip()
        opts = [str(option or "").strip() for option in (options or []) if str(option or "").strip()]
        if opts:
            body = "\n".join(f"- [ ] {option}" for option in opts)
            if q:
                return f"{q}\n{body}\n{cancelled}"
            return f"{body}\n{cancelled}"
        if q:
            return f"{q}\n{cancelled}"
        return cancelled

    @staticmethod
    def _normalize_assistant_text(text: str) -> str:
        """Normalize assistant text for transcript rendering."""
        if not isinstance(text, str):
            return ""
        return text

    def _extract_task_tool_transcript(self, raw_result: str) -> tuple[str, str] | None:
        """Extract speaker + text from task() tool result for session replay."""
        if not isinstance(raw_result, str) or not raw_result.strip():
            return None
        try:
            payload = json.loads(raw_result)
        except Exception:
            return None
        if not isinstance(payload, dict):
            return None

        data = payload.get("data")
        if not isinstance(data, dict):
            data = {}

        status = str(payload.get("status", "") or "").strip().lower()
        agent_id = str(data.get("agent_id", "") or "").strip()
        speaker = self._get_agent_display_name(agent_id) if agent_id else "Sub-agent"
        assistant_text = str(data.get("assistant_text", "") or "")

        if not assistant_text:
            if status == "success":
                assistant_text = "Sub-task completed."
            elif status == "cancelled":
                error_text = str(payload.get("error") or data.get("error") or "").strip()
                assistant_text = f"Sub-task canceled: {error_text}" if error_text else "Sub-task canceled by user."
            else:
                error_text = str(payload.get("error") or data.get("error") or "").strip()
                assistant_text = f"Sub-task failed: {error_text}" if error_text else "Sub-task failed."

        if not assistant_text:
            return None
        return speaker, assistant_text

    @classmethod
    def _extract_sub_agent_tag(cls, text: str) -> tuple[str | None, str]:
        """Decode tagged nested-agent stream payload: [[subagent:<id>]]<payload>."""
        if not isinstance(text, str):
            return None, str(text)
        match = cls._SUB_AGENT_TAG_RE.match(text)
        if not match:
            return None, text
        speaker = str(match.group(1) or "").strip() or None
        payload = match.group(2) or ""
        return speaker, payload

    @staticmethod
    def _scope_tool_name(tool_name: str, speaker: str | None) -> str:
        """Attach speaker scope so sub-agent tool cards don't collide with parent cards."""
        base = str(tool_name or "").strip()
        if not speaker:
            return base
        return f"{speaker}:{base}"

    @staticmethod
    def _extract_todo_items_from_tool_message(message: Any) -> list[dict]:
        """Best-effort parse of TodoWrite tool output payload."""
        content = getattr(message, "content", "") or ""
        if not isinstance(content, str) or not content.strip():
            return []
        try:
            payload = json.loads(content)
        except Exception:
            return []
        if not isinstance(payload, dict):
            return []
        data = payload.get("data")
        if not isinstance(data, dict):
            return []
        items = data.get("items")
        if not isinstance(items, list):
            return []
        return [item for item in items if isinstance(item, dict)]

    def _count_session_entries(self, path: Path) -> int:
        """Count non-empty lines in a session JSONL file."""
        if not path.exists():
            return 0
        try:
            with open(path, encoding="utf-8") as f:
                return sum(1 for line in f if line.strip())
        except OSError:
            return 0

    def _history_dir_for_branch(self, branch: str) -> Path:
        return get_neonrp_dir(self.root) / "sessions" / "history" / branch

    def _archive_active_session(self, branch: str) -> Path | None:
        """Archive current active session into history/branch if non-empty."""
        active_path = get_session_path(self.root, branch)
        if self._count_session_entries(active_path) == 0:
            return None

        history_dir = self._history_dir_for_branch(branch)
        history_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        target = history_dir / f"{stamp}.jsonl"
        idx = 1
        while target.exists():
            target = history_dir / f"{stamp}-{idx}.jsonl"
            idx += 1

        active_path.replace(target)
        return target

    def _list_branch_history_sessions(self, branch: str) -> list[Path]:
        """List archived sessions for branch, sorted newest first."""
        history_dir = self._history_dir_for_branch(branch)
        if not history_dir.exists():
            return []
        files = [p for p in history_dir.glob("*.jsonl") if p.is_file()]
        files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return files

    def _start_new_session(self, announce: bool = True) -> None:
        """Start a fresh session and archive existing active conversation."""
        if not self.session:
            return

        view = self.query_one("#conversation-view", ConversationView)
        # Invalidate late callbacks from older turns before clearing UI/session state.
        self._conversation_epoch += 1
        self._stream_started = False
        self._subagent_stream_seen.clear()
        self._pending_proposal = None
        self._clear_run_status()
        self._cancel_active_ask_user()

        if self._active_send_thread is not None and self._active_send_thread.is_alive():
            self.session.cancel()
            self._active_send_thread.join(timeout=1.0)
            if self._active_send_thread.is_alive():
                view.write("[yellow]Current request is still stopping. Please run /new again in a moment.[/]\n")
                return
        self._active_send_thread = None

        branch = self.session.branch
        archived = self._archive_active_session(branch)
        self.session.clear()

        view.clear()
        self._reset_estimated_tokens()
        self._refresh_status()
        if announce:
            view.write("[green]Started a new session.[/]\n")
            if archived:
                view.write(f"[dim]Archived previous session: {archived.name}[/]\n")

    def _load_archived_session(self, session_path: Path) -> bool:
        """Load an archived session as the active current session."""
        if not self.session or not session_path.exists():
            return False

        branch = self.session.branch
        active_path = get_session_path(self.root, branch)
        active_path.parent.mkdir(parents=True, exist_ok=True)

        self.session.clear()
        shutil.copy2(session_path, active_path)

        view = self.query_one("#conversation-view", ConversationView)
        view.clear()
        self._reset_estimated_tokens()
        return self._restore_session()

    def _get_event_count(self) -> int:
        """Get current event count."""
        if not self.branch:
            return 0
        try:
            events_file = get_neonrp_dir(self.root) / "logs" / self.branch / "events.jsonl"
            if events_file.exists():
                count = 0
                with open(events_file, encoding="utf-8") as f:
                    for _ in f:
                        count += 1
                return count
        except (OSError, IOError):
            pass
        return 0

    def _get_default_agent(self) -> str:
        """Get default agent ID.

        In MCP mode, resolve to the runtime-contract's startup entry agent
        (typically `orchestrator`) so the transcript shows the project's
        root speaker instead of whatever comes first alphabetically under
        `agents/` (e.g. `clock-keeper`).
        """
        narrator_agent_id = self._get_narrator_agent_id()
        startup_entry_agent = get_startup_entry_agent(self.root)

        if self._mcp_mode:
            # Claude Code subprocess doesn't have a neonrp session of its own;
            # we just need a stable top-level label. Prefer the runtime-contract
            # startup agent (usually `orchestrator` / `world-agent`), fall back
            # to narrator id, and only as a last resort to first-in-agents-dir.
            if startup_entry_agent:
                return startup_entry_agent
            if narrator_agent_id:
                agents_dir = self.root / "agents"
                if agents_dir.exists() and (agents_dir / narrator_agent_id).is_dir():
                    return narrator_agent_id
            # Last-resort fallback: alphabetical (same behavior as before).
        elif self.mode in {"build", "play"}:
            data_dir_name = get_data_dir_name(self.root)
            run_state_path = self.root / data_dir_name / "meta" / "run_state.json"
            if startup_entry_agent and run_state_path.exists():
                try:
                    run_state = json.loads(run_state_path.read_text(encoding="utf-8"))
                except Exception:
                    run_state = None
                if isinstance(run_state, dict):
                    try:
                        turn_count = int(run_state.get("turn_count", 0) or 0)
                    except Exception:
                        turn_count = 0
                    if turn_count <= 0:
                        return startup_entry_agent
        agents_dir = self.root / "agents"
        if agents_dir.exists():
            agents = sorted(d.name for d in agents_dir.iterdir() if d.is_dir())
            if agents:
                if narrator_agent_id in agents:
                    return narrator_agent_id
                if "narrator" in agents:
                    return "narrator"
                # Prefer an orchestrator / world-agent if present, before
                # falling back to the alphabetical first entry. Otherwise the
                # default speaker ends up being whichever agent happens to
                # sort first (e.g. `clock-keeper`).
                for preferred in ("orchestrator", "world-agent", "world"):
                    if preferred in agents:
                        return preferred
                return agents[0]
        return narrator_agent_id

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission."""
        event_input = getattr(event, "input", None)
        event_input_id = getattr(event_input, "id", None)
        if isinstance(event_input_id, str) and event_input_id != "message-input":
            return
        if not event.value.strip():
            return

        text = event.value.strip()
        input_widget = self.query_one("#message-input", Input)

        # If slash suggestions are visible, Enter selects and immediately executes
        # Only apply completion when user text is a partial prefix of the suggestion
        if text.startswith("/") and self._slash_suggestions:
            completion = self._get_selected_slash_completion()
            if completion and completion.startswith(text):
                text = completion

        input_widget.value = ""
        self._hide_slash_suggestions()
        self._push_input_history(text)

        # Handle slash commands
        if text.startswith("/"):
            self._handle_slash_command(text)
            return

        # Handle apply shortcut
        if text.lower() == "a" and self._pending_proposal:
            self._do_apply()
            return

        # Send to conversation
        self._send_message(text)

    def _handle_slash_command(self, text: str) -> None:
        """Handle slash commands."""
        view = self.query_one("#conversation-view", ConversationView)
        view.add_user_message(text)

        parsed = parse_command(text)
        if parsed.error:
            view.write(f"[red]Error: {parsed.error}[/]\n")
            return

        cmd = parsed.command

        if cmd == "mode":
            self._cmd_mode(parsed.args)
        elif cmd == "router-mode":
            self._cmd_router_mode(parsed.args)
        elif cmd == "clear":
            self._cmd_clear()
        elif cmd == "files":
            self._cmd_files()
        elif cmd == "skills":
            self._cmd_skills()
        elif cmd == "help":
            self._cmd_help()
        elif cmd == "copy":
            self._cmd_copy()
        elif cmd == "auth":
            self._cmd_auth(parsed.args)
        elif cmd == "models":
            self._cmd_models(parsed.args)
        elif cmd == "apply":
            if self._pending_proposal:
                self._do_apply()
            else:
                view.write("[yellow]No pending proposal to apply.[/]\n")
        elif cmd == "undo":
            self._cmd_undo()
        elif cmd == "save":
            self._cmd_save(parsed.args)
        elif cmd == "load":
            self._cmd_load(parsed.args)
        elif cmd == "stats":
            self._cmd_stats()
        elif cmd == "compact":
            self._cmd_compact()
        elif cmd == "sessions":
            self._cmd_sessions()
        elif cmd == "continue":
            self._cmd_continue(parsed.args)
        elif cmd == "new":
            self._cmd_new(parsed.args)
        elif cmd == "verbose":
            self._cmd_verbose(parsed.args)
        elif cmd == "debug":
            self._cmd_debug(parsed.args)
        elif cmd == "autoapply":
            self._cmd_autoapply(parsed.args)
        elif cmd == "wl-model":
            self._cmd_wl_model(parsed.args)
        elif cmd == "config":
            self._cmd_config(parsed.args)
        elif cmd == "mcp":
            self._cmd_mcp(parsed.args)
        elif cmd == "worldlines":
            self._cmd_worldlines(parsed.args)
        elif cmd == "worlds":
            self._cmd_worlds(parsed.args)
        elif cmd == "update":
            self._cmd_update(parsed.args)
        elif cmd == "locale":
            self._cmd_locale(parsed.args)
        elif cmd == "settings":
            self._cmd_settings()
        elif cmd == "export-world":
            self._cmd_export_world(parsed.args)
        elif cmd == "load-world":
            self._cmd_load_world(parsed.args)
        elif cmd == "bridge":
            self._cmd_bridge(parsed.args)
        elif cmd == "branch" and not parsed.args and not parsed.options:
            self._cmd_branch_list()
        elif cmd in CLI_FORWARD_COMMANDS:
            self._forward_cli_command(parsed)
        elif cmd in ("quit", "q"):
            self.exit()
        else:
            view.write(f"[yellow]Unknown command: /{cmd}[/]\n")

    def on_input_changed(self, event: Input.Changed) -> None:
        """Show inline slash command suggestions as user types."""
        if event.input.id != "message-input":
            return
        if self._suppress_input_change:
            self._suppress_input_change = False
            return
        if self._history_index is None:
            self._history_draft = event.value
        self._update_slash_suggestions(event.value)

    def on_key(self, event) -> None:
        """Handle key events for slash suggestions and command history."""
        if event.key == "escape":
            if self._cancel_active_ask_user():
                event.stop()
                event.prevent_default()
                return

        # When a modal screen is active (model picker / sessions / etc.),
        # let the modal own keyboard handling and do not mutate base input state.
        try:
            if isinstance(self.screen, ModalScreen):
                return
        except ScreenStackError:
            # App not mounted in unit tests; continue with normal logic.
            pass

        input_widget = self.query_one("#message-input", Input)
        if not input_widget.has_focus:
            return

        if self._slash_suggestions:
            if event.key == "up":
                self._move_slash_selection(-1)
                event.stop()
                event.prevent_default()
                return
            if event.key == "down":
                self._move_slash_selection(1)
                event.stop()
                event.prevent_default()
                return
            if event.key == "tab":
                completion = self._get_selected_slash_completion()
                if completion:
                    new_value = completion + " "
                    self._set_input_text(new_value)
                    self._update_slash_suggestions(new_value)
                event.stop()
                event.prevent_default()
                return
            if event.key == "escape":
                self._hide_slash_suggestions()
                event.stop()
                event.prevent_default()
                return

        if event.key == "up":
            if self._navigate_input_history(-1):
                event.stop()
                event.prevent_default()
        elif event.key == "down":
            if self._navigate_input_history(1):
                event.stop()
                event.prevent_default()
        elif event.key == "escape":
            # ESC while an LLM request is in-flight → interrupt
            if (
                self._active_send_thread is not None
                and self._active_send_thread.is_alive()
                and self.session is not None
            ):
                self.session.cancel()
                view = self.query_one("#conversation-view", ConversationView)
                view.write("\n[yellow]⚡ Interrupted by user (ESC)[/]\n")
                self._clear_run_status()
                event.stop()
                event.prevent_default()

    def _compute_slash_suggestions(self, value: str) -> list[tuple[str, str]]:
        """Compute slash suggestions as (display_markup, completion)."""
        value = value.replace("\r", "").replace("\n", "")
        if not value.startswith("/"):
            return []

        command_text = value[1:]
        if not command_text:
            command_names = get_command_suggestions("")
            return self._format_command_suggestions(command_names)

        parts = command_text.split()
        has_trailing_space = value.endswith(" ")
        cmd_name = parts[0]
        spec = COMMANDS.get(cmd_name, {})
        has_subcommands = isinstance(spec.get("subcommands"), list)

        # If command expects subcommands and user completed "/cmd ", suggest subcommands.
        if has_subcommands and (has_trailing_space or len(parts) > 1):
            sub_prefix = ""
            if len(parts) > 1 and not has_trailing_space:
                sub_prefix = parts[1]
            # Subcommand fully matched + user typing args beyond it: hide suggestions.
            valid_subs = spec.get("subcommands", [])
            if len(parts) > 2 or (len(parts) == 2 and has_trailing_space and parts[1] in valid_subs):
                return []
            subcommands = get_subcommand_suggestions(cmd_name, sub_prefix)
            return self._format_subcommand_suggestions(cmd_name, subcommands)

        # Commands without subcommands can still have enum-like first args
        # (e.g. /mode build|sandbox|play).
        if cmd_name in COMMANDS and not has_subcommands and (has_trailing_space or len(parts) > 1):
            arg_suggestions = self._extract_enum_arg_suggestions(cmd_name, parts, has_trailing_space)
            if arg_suggestions:
                return self._format_argument_suggestions(cmd_name, arg_suggestions)
            return []

        # Command without subcommands and already complete: hide suggestions.
        command_names = get_command_suggestions(cmd_name)
        return self._format_command_suggestions(command_names)

    @staticmethod
    def _format_command_suggestions(command_names: list[str]) -> list[tuple[str, str]]:
        suggestions: list[tuple[str, str]] = []
        for cmd in command_names:
            spec = COMMANDS.get(cmd, {})
            desc = spec.get("help", "")
            suggestions.append((f"[cyan]/{cmd}[/] [dim]- {desc}[/]", f"/{cmd}"))
        return suggestions

    @staticmethod
    def _format_subcommand_suggestions(parent: str, subcommands: list[str]) -> list[tuple[str, str]]:
        suggestions: list[tuple[str, str]] = []
        for sub in subcommands:
            suggestions.append((f"[cyan]/{parent}[/] [magenta]{sub}[/]", f"/{parent} {sub}"))
        return suggestions

    @staticmethod
    def _parse_enum_choices_from_args_hint(args_hint: str) -> list[str]:
        hint = str(args_hint or "").strip()
        if not (hint.startswith("[") and hint.endswith("]")):
            return []
        content = hint[1:-1].strip()
        if "|" not in content:
            return []
        # Skip composite hints like "set <name>|show [name]".
        if "<" in content:
            return []
        choices = [part.strip() for part in content.split("|")]
        if not choices or any(not c or " " in c for c in choices):
            return []
        return choices

    def _extract_enum_arg_suggestions(self, cmd_name: str, parts: list[str], has_trailing_space: bool) -> list[str]:
        spec = COMMANDS.get(cmd_name, {})
        choices = self._parse_enum_choices_from_args_hint(str(spec.get("args_hint", "") or ""))
        if not choices:
            return []
        if len(parts) > 2:
            return []
        if len(parts) == 1:
            return choices if has_trailing_space else []
        arg_prefix = "" if has_trailing_space else str(parts[1] or "").strip().lower()
        if has_trailing_space and str(parts[1] or "").strip().lower() in {c.lower() for c in choices}:
            return []
        if not arg_prefix:
            return choices
        return [choice for choice in choices if choice.lower().startswith(arg_prefix)]

    @staticmethod
    def _format_argument_suggestions(command: str, args: list[str]) -> list[tuple[str, str]]:
        suggestions: list[tuple[str, str]] = []
        for arg in args:
            suggestions.append((f"[cyan]/{command}[/] [magenta]{arg}[/]", f"/{command} {arg}"))
        return suggestions

    def _update_slash_suggestions(self, value: str) -> None:
        """Refresh slash suggestion panel from current input value."""
        suggestions = self._compute_slash_suggestions(value)
        if not suggestions:
            self._hide_slash_suggestions()
            return

        self._slash_suggestions = suggestions
        if self._slash_selected_index >= len(suggestions):
            self._slash_selected_index = 0
        self._render_slash_suggestions()

    def _render_slash_suggestions(self) -> None:
        """Render slash suggestions panel."""
        panel = self.query_one("#slash-suggestions", Static)
        lines: list[str] = []
        total = len(self._slash_suggestions)
        max_visible = self._MAX_VISIBLE_SLASH_SUGGESTIONS
        if total <= max_visible:
            start = 0
            end = total
        else:
            start = max(0, min(self._slash_selected_index - (max_visible // 2), total - max_visible))
            end = start + max_visible

        for idx, (label, _) in enumerate(self._slash_suggestions[start:end], start=start):
            prefix = "[bold]>[/] " if idx == self._slash_selected_index else "  "
            lines.append(f"{prefix}{label}")
        if total > 0:
            if total > max_visible:
                lines.append(
                    f"[dim]{self._slash_selected_index + 1}/{total} · "
                    "↑↓ select · Tab complete · Enter run · Esc close[/]"
                )
            elif total > 1:
                lines.append("[dim]↑↓ select · Tab complete · Enter run · Esc close[/]")
        panel.update("\n".join(lines))
        panel.add_class("visible")

    def _hide_slash_suggestions(self) -> None:
        """Hide slash suggestions panel."""
        self._slash_suggestions = []
        self._slash_selected_index = 0
        panel = self.query_one("#slash-suggestions", Static)
        panel.remove_class("visible")
        panel.update("")

    def _move_slash_selection(self, delta: int) -> None:
        """Move selected suggestion up/down."""
        if not self._slash_suggestions:
            return
        self._slash_selected_index = (self._slash_selected_index + delta) % len(self._slash_suggestions)
        self._render_slash_suggestions()

    def _get_selected_slash_completion(self) -> str | None:
        """Return completion text for selected suggestion."""
        if not self._slash_suggestions:
            return None
        return self._slash_suggestions[self._slash_selected_index][1]

    def _set_input_text(self, value: str) -> None:
        """Set input text without re-entering change handlers."""
        input_widget = self.query_one("#message-input", Input)
        self._suppress_input_change = True
        input_widget.value = value
        input_widget.cursor_position = len(value)

    def _push_input_history(self, text: str) -> None:
        """Store submitted input in history."""
        normalized = text.strip()
        if not normalized:
            return
        self._input_history.append(normalized)
        self._history_index = None
        self._history_draft = ""

    def _navigate_input_history(self, direction: int) -> bool:
        """Navigate input history; direction -1 for up, +1 for down."""
        if not self._input_history:
            return False

        input_widget = self.query_one("#message-input", Input)

        if direction < 0:
            if self._history_index is None:
                self._history_draft = input_widget.value
                self._history_index = len(self._input_history) - 1
            elif self._history_index > 0:
                self._history_index -= 1
            self._set_input_text(self._input_history[self._history_index])
            return True

        if self._history_index is None:
            return False

        if self._history_index < len(self._input_history) - 1:
            self._history_index += 1
            self._set_input_text(self._input_history[self._history_index])
        else:
            self._history_index = None
            self._set_input_text(self._history_draft)
            self._history_draft = ""
        return True

    def _ensure_verbose_log_path(self) -> Path | None:
        """Ensure debug log file path exists when verbose mode is enabled."""
        if self._verbose_log_path:
            return self._verbose_log_path
        try:
            log_dir = get_neonrp_dir(self.root) / "logs" / "tui"
            log_dir.mkdir(parents=True, exist_ok=True)
            branch = self.session.branch if self.session else (self.branch or "main")
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            self._verbose_log_path = log_dir / f"debug_{stamp}_{branch}.jsonl"
            return self._verbose_log_path
        except Exception:
            return None

    def _append_verbose_event(self, event_type: str, payload: dict[str, Any] | None = None) -> None:
        """Append one verbose debug event to JSONL log."""
        if not self.verbose:
            return
        path = self._ensure_verbose_log_path()
        if not path:
            return
        event = {
            "ts": datetime.now().isoformat(timespec="milliseconds"),
            "event": event_type,
            "payload": payload or {},
        }
        try:
            line = json.dumps(event, ensure_ascii=False)
            with self._verbose_lock:
                with open(path, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
        except Exception:
            pass

    def _write_verbose_line(self, message: str) -> None:
        """Write a one-line verbose status message to conversation view."""
        if not self.verbose:
            return
        try:
            view = self.query_one("#conversation-view", ConversationView)
            view.write(f"[dim][verbose][/dim] {message}\n")
        except Exception:
            pass

    def _set_verbose_enabled(self, enabled: bool, announce: bool = True) -> None:
        """Enable/disable verbose mode and announce status."""
        if enabled:
            self.verbose = True
            log_path = self._ensure_verbose_log_path()
            self._append_verbose_event("verbose_enabled", {"path": str(log_path) if log_path else ""})
            if announce:
                if log_path:
                    self._write_verbose_line(f"Verbose mode enabled. Log: {log_path}")
                else:
                    self._write_verbose_line("Verbose mode enabled. Log file unavailable.")
            return

        if self.verbose:
            self._append_verbose_event("verbose_disabled", {})
        self.verbose = False
        if announce:
            try:
                view = self.query_one("#conversation-view", ConversationView)
                view.write("[dim]Verbose mode disabled.[/]\n")
            except Exception:
                pass

    def _verbose_turn_context(self, text: str) -> dict[str, Any]:
        """Collect safe debug context for an outgoing turn."""
        session = self.session
        context: dict[str, Any] = {
            "input_chars": len(text),
            "input_preview": text[:240],
            "branch": session.branch if session else (self.branch or "main"),
            "mode": session.mode if session else "build",
            "agent": session.agent_id if session else self._get_default_agent(),
            "message_count": len(session.messages) if session else 0,
        }
        try:
            provider_cfg = self._get_effective_provider_config()
            context.update(
                {
                    "provider": provider_cfg.provider,
                    "model": provider_cfg.model,
                    "base_url": provider_cfg.base_url,
                    "api_key_env": provider_cfg.api_key_env,
                    "api_key_configured": bool(provider_cfg.api_key) or self._has_api_credential(provider_cfg),
                }
            )
        except Exception as exc:
            context["provider_resolve_error"] = str(exc)
        return context

    def _cmd_verbose(self, args: list[str]) -> None:
        """Enable/disable verbose debug mode."""
        view = self.query_one("#conversation-view", ConversationView)
        if not args:
            self._set_verbose_enabled(True, announce=True)
            return

        action = args[0].strip().lower()
        if action in {"on", "enable", "enabled", "true", "1"}:
            self._set_verbose_enabled(True, announce=True)
            return
        if action in {"off", "disable", "disabled", "false", "0"}:
            self._set_verbose_enabled(False, announce=True)
            return
        if action in {"status", "show"}:
            status = "enabled" if self.verbose else "disabled"
            if self.verbose:
                log_path = self._verbose_log_path if self._verbose_log_path else self._ensure_verbose_log_path()
                view.write(f"[dim]Verbose mode: {status}. Log: {log_path}[/]\n")
            else:
                view.write(f"[dim]Verbose mode: {status}. Use /verbose on to enable.[/]\n")
            return

        view.write("[yellow]Usage: /verbose [on|off|status][/]\n")

    def _cmd_autoapply(self, args: list[str]) -> None:
        """Enable/disable sandbox auto-apply mode and persist UI state."""
        view = self.query_one("#conversation-view", ConversationView)
        action = args[0].strip().lower() if args else "status"

        if action in {"status", "show"}:
            status = "ON" if self.auto_apply else "OFF"
            view.write(f"[dim]Auto-apply: {status}[/]\n")
            return

        if action in {"on", "enable", "enabled", "true", "1"}:
            self.auto_apply = True
            set_auto_apply(self.root, True)
            view.write("[green]Auto-apply enabled.[/]\n")
            return

        if action in {"off", "disable", "disabled", "false", "0"}:
            self.auto_apply = False
            set_auto_apply(self.root, False)
            view.write("[yellow]Auto-apply disabled.[/]\n")
            return

        view.write("[yellow]Usage: /autoapply [on|off|status][/]\n")

    def _cmd_mode(self, args: list[str]) -> None:
        """Switch conversation mode."""
        view = self.query_one("#conversation-view", ConversationView)

        if not args:
            view.write(f"[yellow]Current mode: {self.session.mode if self.session else 'build'}[/]\n")
            view.write("Usage: /mode build|sandbox|play\n")
            return

        new_mode = args[0].lower()
        if new_mode not in ("build", "sandbox", "play"):
            view.write(f"[red]Invalid mode: {new_mode}. Use: build, sandbox, or play[/]\n")
            return

        if self.session:
            self.session.set_mode(new_mode)

        # Update UI
        input_area = self.query_one("#input-area", InputArea)
        input_area.set_mode(new_mode)
        self.query_one("#conversation-view", ConversationView).set_display_mode(new_mode)
        self._refresh_status(include_event_count=False)

        view.write(f"[green]Switched to {new_mode} mode[/]\n")

    def _cmd_router_mode(self, args: list[str]) -> None:
        """Show or switch router execution mode."""
        view = self.query_one("#conversation-view", ConversationView)

        if not args:
            current = get_router_execution_mode(self.root)
            view.write(f"[yellow]Current router mode: {current}[/]\n")
            view.write("Usage: /router-mode fast|orchestrator|multi-agent\n")
            return

        try:
            new_mode = set_router_execution_mode(self.root, args[0])
        except ValueError as exc:
            view.write(f"[red]{exc}[/]\n")
            return

        view.write(f"[green]Switched router mode to {new_mode}[/]\n")

    def _cmd_clear(self) -> None:
        """Clear conversation history."""
        view = self.query_one("#conversation-view", ConversationView)

        if self.session:
            self.session.clear()

        view.clear()
        view.write("[dim]Conversation history cleared[/]\n")

    def _cmd_files(self) -> None:
        """List recently modified files."""
        view = self.query_one("#conversation-view", ConversationView)

        game_dir = get_game_dir(self.root)
        if not game_dir.exists():
            view.write("[yellow]No game directory found[/]\n")
            return

        view.write(f"[bold]Recently modified files ({get_data_dir_name(self.root)}/):[/]\n")

        import time

        files = []
        for f in game_dir.rglob("*.json"):
            try:
                stat = f.stat()
                files.append((f.relative_to(self.root), stat.st_mtime))
            except OSError:
                continue

        files.sort(key=lambda x: x[1], reverse=True)

        for rel_path, mtime in files[:10]:
            time_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime))
            view.write(f"  [dim]{time_str}[/] {rel_path}\n")

    def _cmd_skills(self) -> None:
        """List available skills and open a modal picker for inspection."""
        view = self.query_one("#conversation-view", ConversationView)

        skills = self.skill_loader.list_skills()
        if not skills:
            view.write("[yellow]No skills available[/]\n")
            return

        # Also write a transcript summary so the listing is visible even when
        # the picker cannot render (unit tests, non-interactive runs).
        view.write("[bold]Available skills:[/]\n")
        options: list[tuple[str, str]] = []
        for name in skills:
            desc = self.skill_loader.get_description(name) or "No description"
            view.write(f"  [cyan]{name}[/]: {desc}\n")
            options.append((f"{name} — {desc[:90]}", name))

        def on_selected(value: str | None) -> None:
            if not value:
                return
            self._show_skill_detail(value)

        try:
            locale = getattr(self, "ui_locale", None) or getattr(self, "locale", "en") or "en"
            self.push_screen(
                ChoicePickerScreen(
                    "Skills · built-in + project-local",
                    options,
                    hint=get_message(locale, "ui.hint.picker_expand"),
                ),
                on_selected,
            )
        except Exception:
            # Running headless (tests) — the transcript summary above is enough.
            pass

    def _show_skill_detail(self, name: str) -> None:
        """Print the full body of a skill to the transcript and re-open the picker."""
        view = self.query_one("#conversation-view", ConversationView)
        body = self.skill_loader.get_content(name)
        if body is None:
            view.write(f"[yellow]Skill '{name}' not found[/]\n")
            return
        view.write(f"\n[bold cyan]# skill: {name}[/]\n")
        view.write(body.strip() + "\n")
        self.call_after_refresh(self._cmd_skills)

    def _cmd_mcp(self, args: list[str]) -> None:
        """MCP server management (M11-T6)."""
        view = self.query_one("#conversation-view", ConversationView)
        config = load_config(self.root)

        if not config.mcp_servers:
            view.write("[yellow]No MCP servers configured.[/]\n")
            return

        sub = args[0] if args else "status"

        if sub == "status":
            enabled = {n: c for n, c in config.mcp_servers.items() if c.enabled}
            if not enabled:
                view.write("[yellow]All MCP servers are disabled.[/]\n")
                return

            pool = MCPPool(enabled)
            try:
                results = pool.ensure_started()
                view.write("[bold]MCP Server Status:[/]\n")
                for name, err in results.items():
                    if err:
                        view.write(f"  [red]✖ {name}[/]: {err}\n")
                    else:
                        client = pool.get_started_client(name)
                        tool_count = len(client.list_tools()) if client else 0
                        perm = config.mcp_servers[name].permission
                        view.write(f"  [green]✔ {name}[/]: {tool_count} tools (permission: {perm})\n")
                        if client:
                            for tool in client.list_tools():
                                view.write(f"    [dim]· {tool.name}[/]: {tool.description[:60]}\n")
            finally:
                pool.stop_all()

        elif sub == "restart":
            if len(args) < 2:
                view.write("[yellow]Usage: /mcp restart <server_name>[/]\n")
                return
            server_name = args[1]
            if server_name not in config.mcp_servers:
                view.write(f"[red]Unknown MCP server: {server_name}[/]\n")
                return
            view.write(f"[dim]Restarting MCP server '{server_name}'...[/]\n")
            pool = MCPPool({server_name: config.mcp_servers[server_name]})
            try:
                pool.ensure_started()
                status = pool.get_status(server_name)
                if status and status[0].status == "healthy":
                    view.write(f"[green]✔ Server '{server_name}' restarted successfully.[/]\n")
                else:
                    view.write(f"[red]✖ Server '{server_name}' failed to restart.[/]\n")
            except Exception as exc:
                view.write(f"[red]Error: {exc}[/]\n")
            finally:
                pool.stop_all()

        else:
            view.write(f"[yellow]Unknown subcommand: {sub}. Use status or restart.[/]\n")

    def _cmd_help(self) -> None:
        """Show help."""
        view = self.query_one("#conversation-view", ConversationView)
        from neonrp.tui.commands import format_help

        view.write(format_help() + "\n")

    def _cmd_stats(self) -> None:
        """Show conversation statistics."""
        view = self.query_one("#conversation-view", ConversationView)

        if not self.session:
            view.write("[yellow]No active session[/]\n")
            return

        msg_count = len(self.session.messages)
        user_msgs = sum(1 for m in self.session.messages if m.role == "user")
        assistant_msgs = sum(1 for m in self.session.messages if m.role == "assistant")
        tool_msgs = sum(1 for m in self.session.messages if m.role == "tool")
        usage = self.session.total_usage

        view.write("[bold]Conversation Statistics:[/]\n")
        view.write(f"  [cyan]Mode:[/] {self.session.mode}\n")
        view.write(f"  [cyan]Agent:[/] {self.session.agent_id}\n")
        view.write(
            f"  [cyan]Messages:[/] {msg_count} (user: {user_msgs}, assistant: {assistant_msgs}, tool: {tool_msgs})\n"
        )
        view.write(f"  [cyan]LLM turns:[/] {self.session.total_turns}\n")
        view.write(
            "  [cyan]Tokens (local est):[/] "
            f"{self._est_prompt_tokens_total + self._est_completion_tokens_total} "
            f"(prompt: {self._est_prompt_tokens_total}, completion: {self._est_completion_tokens_total})\n"
        )
        if usage:
            prompt_tokens = usage.get("prompt_tokens", 0)
            completion_tokens = usage.get("completion_tokens", 0)
            view.write(
                f"  [dim]Provider usage:[/] {prompt_tokens + completion_tokens} "
                f"(prompt: {prompt_tokens}, completion: {completion_tokens})\n"
            )
        view.write(f"  [cyan]Files modified:[/] {len(self.session.recent_files)}\n")

    def _cmd_compact(self) -> None:
        """Compact conversation history."""
        view = self.query_one("#conversation-view", ConversationView)

        if not self.session:
            view.write("[yellow]No active session[/]\n")
            return

        removed = self.session.compact()
        if removed > 0:
            view.clear()
            self._render_session_messages(self.session.get_messages())
            view.write(f"[green]Compacted: removed {removed} old messages[/]\n")
        else:
            view.write("[dim]Nothing to compact (conversation is short enough)[/]\n")

    def _cmd_worldlines(self, args: list[str]) -> None:
        """Open the minimal WorldLines guided world picker."""
        if args:
            view = self.query_one("#conversation-view", ConversationView)
            view.write("[yellow]Usage: /worldlines[/]\n")
            return
        self._cmd_worlds([])

    def _cmd_worlds(self, args: list[str]) -> None:
        """Browse available WorldLines worlds and scaffold one into current workspace."""
        from neonrp.worlds import get_world, list_worlds

        view = self.query_one("#conversation-view", ConversationView)
        if args:
            view.write("[yellow]Usage: /worlds[/]\n")
            return

        worlds = list_worlds()
        if not worlds:
            view.write("[yellow]No WorldLines worlds are available.[/]\n")
            return

        options = [
            (
                f"{world['name']} ({world['name_local']})  —  {world['desc']}",
                world["id"],
            )
            for world in worlds
        ]

        def on_selected(world_id: str | None) -> None:
            if not world_id:
                return
            try:
                world = get_world(world_id)
            except KeyError:
                view.write(f"[red]Unknown world '{world_id}'.[/]\n")
                return

            manifest_exists = get_manifest_path(self.root).exists()
            if not manifest_exists:
                init_code, init_output = self._invoke_cli(["init"])
                if init_output:
                    view.write(f"{init_output}\n")
                if init_code != 0:
                    view.write("[red]Failed to initialize workspace for WorldLines world setup.[/]\n")
                    return

            exit_code, output = self._invoke_cli(["game", "new", "--template", world["template"]])
            if output:
                view.write(f"{output}\n")
            if exit_code == 0:
                view.write(f"[green]WorldLines world ready: {world['name']} ({world['name_local']}).[/]\n")
                self._refresh_status()
            else:
                view.write(
                    f"[yellow]If you want to replace existing game data, run /game new --template {world['template']} --force[/]\n"
                )

        self.push_screen(WorldPickerScreen(options), on_selected)

    def _cmd_debug(self, args: list[str]) -> None:
        """Legacy WorldLines debug alias backed by verbose diagnostics."""
        view = self.query_one("#conversation-view", ConversationView)
        if args:
            view.write("[yellow]Usage: /debug[/]\n")
            return
        self._set_verbose_enabled(not self.verbose, announce=True)

    def _cmd_settings(self) -> None:
        """Open the unified settings flow (shared with WorldLines launcher)."""
        from neonrp.tui.settings_flow import SettingsFlow

        flow = SettingsFlow(host=self)
        flow.open_root()

    def _cmd_export_world(self, args: list[str]) -> None:
        """Zip the current game folder to a .zip archive."""
        from neonrp.core.world_export import (
            default_export_path,
            export_world as core_export,
            summarize_archive,
        )

        view = self.query_one("#conversation-view", ConversationView)
        output_path = Path(args[0]).expanduser() if args else default_export_path(self.root)

        try:
            final = core_export(self.root, output_path)
        except (FileNotFoundError, ValueError) as exc:
            view.write(f"[red]Export failed: {exc}[/]\n")
            return
        except Exception as exc:
            view.write(f"[red]Unexpected error during export: {exc}[/]\n")
            return

        info = summarize_archive(final)
        view.write(
            f"[green]✓ Exported {info['file_count']} files  —  {info['size_mb']} MB[/]\n"
            f"  [cyan]{final}[/]\n"
        )

    def _cmd_bridge(self, args: list[str]) -> None:
        """Manage external bridges (Discord, Telegram) at runtime."""
        view = self.query_one("#conversation-view", ConversationView)
        sub = (args[0] if args else "status").lower()

        hub = self._ensure_bridge_hub()
        if hub is None:
            view.write("[red]Bridge subsystem unavailable[/]\n")
            return

        if sub == "status":
            names = hub.list_bridges()
            view.write(f"[bold]Active bridges:[/] {', '.join(names) if names else '(none)'}\n")
            try:
                from neonrp.core.discord_config import get_discord_inline_status, get_discord_settings

                s = get_discord_settings()
                view.write(
                    f"  [cyan]discord[/]: status={get_discord_inline_status()}  "
                    f"autostart={bool(s.get('autostart'))}  "
                    f"channel={s.get('channel_id', '(not set)')}\n"
                )
            except Exception:
                pass
            return

        if sub == "start":
            name = (args[1] if len(args) > 1 else "").strip().lower()
            if name == "discord":
                try:
                    from neonrp.bridges.discord_bridge import build_discord_bridge_from_config

                    bridge = build_discord_bridge_from_config()
                    if bridge is None:
                        view.write("[yellow]Discord config incomplete — run /settings → Discord wizard first.[/]\n")
                        return
                    if "discord" in hub.list_bridges():
                        view.write("[yellow]Discord bridge already running.[/]\n")
                        return
                    hub.register(bridge)
                    err = bridge.last_error()
                    if err:
                        view.write(f"[red]{err}[/]\n")
                    else:
                        view.write("[green]Discord bridge started.[/]\n")
                except Exception as exc:
                    view.write(f"[red]Failed to start discord bridge: {exc}[/]\n")
                return
            view.write(f"[yellow]Unknown bridge: {name}[/]\n")
            return

        if sub == "stop":
            name = (args[1] if len(args) > 1 else "").strip().lower()
            for bridge in list(getattr(hub, "_bridges", [])):
                if getattr(bridge, "name", "") == name:
                    hub.unregister(bridge)
                    view.write(f"[green]Stopped bridge: {name}[/]\n")
                    return
            view.write(f"[yellow]Bridge not running: {name}[/]\n")
            return

        view.write(f"[yellow]Unknown /bridge subcommand: {sub}[/]\n")

    def _cmd_load_world(self, args: list[str]) -> None:
        """Restore a worldlines game folder from an exported .zip archive."""
        from neonrp.core.world_export import load_world_zip

        view = self.query_one("#conversation-view", ConversationView)
        if not args:
            view.write("[yellow]Usage: /load-world <zip_path>[/]\n")
            return
        zip_path = Path(args[0]).expanduser()
        try:
            target = load_world_zip(zip_path)
        except (FileNotFoundError, ValueError) as exc:
            view.write(f"[red]Load failed: {exc}[/]\n")
            return
        view.write(
            f"[green]✓ Loaded into:[/] [cyan]{target}[/]\n"
            f"[dim]Return to the worldlines launcher to continue that run.[/]\n"
        )

    def _step_prompt_text(self, title: str, default: str, on_submit: Callable[[str], None]) -> None:
        """Compatibility shim used by SettingsFlow to pop a TextInputScreen."""
        def handler(value: str | None) -> None:
            on_submit(value or "")

        self.push_screen(TextInputScreen(title, default=default), handler)

    def _cmd_locale(self, args: list[str]) -> None:
        """Switch UI locale and persist it to ~/.neonrp/config.json:ui.language.

        User-level so the setting follows you across every project and the
        worldlines launcher itself. Project-level `.neonrp/config.json:tui.language`
        still wins when present.
        """
        view = self.query_one("#conversation-view", ConversationView)
        from neonrp.tui.i18n import SUPPORTED_LOCALES
        from neonrp.core.user_config import set_user_locale

        valid = ("auto", *SUPPORTED_LOCALES)
        if not args:
            view.write(
                f"  current locale: [cyan]{self.ui_locale}[/]  "
                f"(choices: {', '.join(valid)})\n"
                f"  usage: [dim]/locale <auto|en|zh|ja|ko>[/]\n"
            )
            return
        choice = args[0].strip().lower()
        if choice not in valid:
            view.write(f"[yellow]Invalid locale '{choice}'. Choices: {', '.join(valid)}[/]\n")
            return

        try:
            set_user_locale(choice)
        except Exception as exc:
            view.write(f"[red]Failed to save locale: {exc}[/]\n")
            return

        self.ui_locale = self._resolve_ui_locale()
        try:
            self.query_one("#input-area", InputArea).set_locale(self.ui_locale)
        except Exception:
            pass
        view.write(f"[green]locale set to {choice} (active: {self.ui_locale})[/]\n")

    def _cmd_update(self, args: list[str]) -> None:
        """Check / apply product updates (L14 auto-update Phase 1)."""
        view = self.query_one("#conversation-view", ConversationView)
        from neonrp.core import updater

        sub = (args[0] if args else "check").lower()

        if sub == "status":
            mode = updater.detect_install_mode()
            settings = updater.get_update_settings()
            view.write(
                f"  current: {updater.get_current_version()}\n"
                f"  install: {mode.kind} ({mode.detail})\n"
                f"  channel: {settings.get('channel')}\n"
                f"  auto-apply allowed: {mode.allow_auto_apply}\n"
            )
            return

        if sub == "channel":
            if len(args) < 2:
                view.write("[yellow]Usage: /update channel <stable|preview|nightly>[/]\n")
                return
            ch = args[1].lower()
            if ch not in ("stable", "preview", "nightly"):
                view.write("[yellow]channel must be one of stable|preview|nightly[/]\n")
                return
            updater.set_update_settings(channel=ch)
            view.write(f"[green]channel set to {ch}[/]\n")
            return

        if sub in ("check", ""):
            result = updater.check_for_update()
            view.write(updater.format_result_for_human(result) + "\n")
            return

        if sub == "apply":
            mode = updater.detect_install_mode()
            if not mode.allow_auto_apply:
                view.write(
                    f"[yellow]Auto-apply disabled for this install ({mode.kind}). "
                    f"Please upgrade manually via `uv tool upgrade neonrp`.[/]\n"
                )
                return
            cmd = updater.build_upgrade_command("neonrp")
            if not cmd:
                view.write("[red]No supported package manager on PATH.[/]\n")
                return
            view.write(f"  running: {' '.join(cmd)}\n")
            ok, output = updater.apply_update_in_background("neonrp")
            if output:
                view.write(output + "\n")
            locale = getattr(self, "ui_locale", None) or getattr(self, "locale", "en") or "en"
            if ok:
                view.write(f"[green]{get_message(locale, 'upgrade.success')}[/]\n")
            else:
                view.write(f"[red]{get_message(locale, 'upgrade.failed')}[/]\n")
            return

        view.write(f"[yellow]Unknown /update subcommand: {sub}[/]\n")

    def _cmd_wl_model(self, args: list[str]) -> None:
        """Legacy WorldLines preset switch helper backed by /models."""
        self._cmd_models(args)

    def _cmd_sessions(self) -> None:
        """Open a modal picker with session history for current branch."""
        view = self.query_one("#conversation-view", ConversationView)
        if not self.session:
            view.write("[yellow]No active session[/]\n")
            return

        branch = self.session.branch
        history_files = self._list_branch_history_sessions(branch)
        options: list[tuple[str, str]] = [("New session (default)", "__new__")]

        for session_file in history_files:
            entries = self._count_session_entries(session_file)
            updated = datetime.fromtimestamp(session_file.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
            options.append((f"{session_file.stem} - {entries} entries ({updated})", str(session_file)))

        def on_selected(value: str | None) -> None:
            if value is None:
                return
            if value == "__new__":
                self._start_new_session(announce=True)
                return

            loaded = self._load_archived_session(Path(value))
            if loaded:
                view.write("[green]Loaded selected session.[/]\n")
            else:
                view.write("[red]Failed to load selected session.[/]\n")

        self.push_screen(SessionPickerScreen(branch, options), on_selected)

    def _cmd_continue(self, args: list[str]) -> None:
        """Resume conversation history from persisted session on current branch."""
        view = self.query_one("#conversation-view", ConversationView)
        if args:
            view.write("[yellow]Usage: /continue[/]\n")
            return

        if not self.session:
            view.write("[yellow]No active session[/]\n")
            return

        active_path = get_session_path(self.root, self.session.branch)
        if self._count_session_entries(active_path) > 0:
            view.clear()
            if self._restore_session():
                view.write("[green]Continued active session.[/]\n")
            else:
                view.write("[yellow]No previous session found for current branch.[/]\n")
            return

        history_files = self._list_branch_history_sessions(self.session.branch)
        if not history_files:
            view.write("[yellow]No previous session found for current branch.[/]\n")
            return

        if self._load_archived_session(history_files[0]):
            view.write("[green]Session resumed from latest history.[/]\n")
        else:
            view.write("[red]Failed to resume previous session.[/]\n")

    def _cmd_new(self, args: list[str]) -> None:
        """Start a full new session and archive current active session."""
        view = self.query_one("#conversation-view", ConversationView)
        if args:
            view.write("[yellow]Usage: /new[/]\n")
            return
        self._start_new_session(announce=True)

    def _cmd_copy(self) -> None:
        """Copy current conversation to system clipboard."""
        view = self.query_one("#conversation-view", ConversationView)
        transcript = view.get_plain_text()
        if not transcript:
            view.write("[yellow]Nothing to copy yet.[/]\n")
            return
        try:
            self.copy_to_clipboard(transcript)
            view.write("[green]Copied conversation to clipboard.[/]\n")
        except Exception as e:
            view.write(f"[red]Copy failed: {e}[/]\n")

    def _cmd_auth(self, args: list[str]) -> None:
        """Manage named model configs in user-level config."""
        view = self.query_one("#conversation-view", ConversationView)
        if not args:
            self._cmd_auth_list()
            return

        sub = args[0].lower()
        rest = args[1:]
        if sub == "list":
            self._cmd_auth_list()
            return
        if sub == "add":
            self._cmd_auth_add_model(rest)
            return
        if sub == "set":
            self._cmd_auth_set_model(rest)
            return
        if sub == "rm":
            self._cmd_auth_rm_model(rest)
            return
        if sub == "show":
            self._cmd_auth_show_model(rest)
            return

        view.write(
            "[yellow]Usage: /auth list | /auth add model ... | /auth set model ... | /auth rm model ... | /auth show model ...[/]\n"
        )

    def _cmd_models(self, args: list[str]) -> None:
        """Quick model list/switch helper.

        Usage:
        - /models                     -> open selection menu
        - /models <name>              -> set active model_ref to <name>
        - /models list                -> list
        - /models set <name>          -> set
        - /models show [name]         -> show details
        """
        view = self.query_one("#conversation-view", ConversationView)
        if not args:
            data = self._load_user_config_dict()
            llm = data.get("llm", {})
            if not isinstance(llm, dict):
                llm = {}
            models = self._ensure_models_map(data)
            if not models:
                view.write("[yellow]No models configured yet. Use /auth add model ...[/]\n")
                return

            active_ref = llm.get("model_ref", "")
            options: list[tuple[str, str]] = []
            # Put active model first for faster confirm.
            names = list(models.keys())
            if active_ref in names:
                names.remove(active_ref)
                names.insert(0, active_ref)
            for name in names:
                cfg = models.get(name, {})
                if not isinstance(cfg, dict):
                    continue
                provider = cfg.get("provider", "stub")
                model = cfg.get("model", "")
                marker = "✓ " if name == active_ref else ""
                label = f"{marker}{name}  ({provider}:{model or '(default)'})"
                options.append((label, name))

            def on_selected(model_ref: str | None) -> None:
                if not model_ref:
                    return
                self._cmd_auth_set_model(["model", model_ref])

            self.push_screen(ModelPickerScreen(options), on_selected)
            return

        if args[0].lower() == "list":
            self._cmd_auth_list()
            return

        sub = args[0].lower()
        if sub == "set":
            if len(args) < 2:
                view.write("[yellow]Usage: /models set <name>[/]\n")
                return
            self._cmd_auth_set_model(["model", args[1]])
            return
        if sub == "show":
            if len(args) >= 2:
                self._cmd_auth_show_model(["model", args[1]])
            else:
                self._cmd_auth_show_model(["model"])
            return

        # Default shortcut: treat first arg as model name.
        self._cmd_auth_set_model(["model", args[0]])

    def _load_user_config_dict(self) -> dict[str, Any]:
        """Load user config JSON or return default template."""
        user_config_path = get_user_config_path()
        try:
            if user_config_path.exists():
                data = json.loads(user_config_path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    return data
        except Exception:
            pass
        return create_default_config_template()

    def _ensure_models_map(self, data: dict[str, Any]) -> dict[str, Any]:
        """Ensure and return top-level models mapping."""
        models = data.setdefault("models", {})
        if not isinstance(models, dict):
            models = {}
            data["models"] = models
        return models

    def _cmd_auth_list(self) -> None:
        """List named models and current active model_ref."""
        view = self.query_one("#conversation-view", ConversationView)
        data = self._load_user_config_dict()
        llm = data.get("llm", {})
        if not isinstance(llm, dict):
            llm = {}
        models = self._ensure_models_map(data)
        active_ref = llm.get("model_ref", "stub")

        view.write("[bold]Named Models[/]\n")
        if not models:
            view.write("[yellow]No models configured yet.[/]\n")
        for name, cfg in models.items():
            if not isinstance(cfg, dict):
                continue
            marker = "*" if name == active_ref else " "
            provider = cfg.get("provider", "stub")
            model = cfg.get("model", "")
            view.write(f"  {marker} [cyan]{name}[/] -> {provider}:{model or '(default)'}\n")
        view.write(f"[dim]Active model_ref: {active_ref}[/]\n")
        view.write(
            "[dim]Commands: /auth add model ..., /auth set model ..., /auth show model ..., /auth rm model ...[/]\n"
        )

    def _cmd_auth_add_model(self, args: list[str]) -> None:
        """Add a named model: /auth add model <name> <provider> [base_url] [model] [api_key_env_or_key]."""
        view = self.query_one("#conversation-view", ConversationView)
        if len(args) < 3 or args[0].lower() != "model":
            view.write("[yellow]Usage: /auth add model <name> <provider> [base_url] [model] [api_key_env_or_key][/]\n")
            return

        model_name = args[1].strip()
        provider = args[2].strip().lower()
        base_url = args[3].strip() if len(args) > 3 else ""
        model = args[4].strip() if len(args) > 4 else ""
        credential = args[5].strip() if len(args) > 5 else ""

        if provider not in SUPPORTED_MODEL_PROVIDERS:
            allowed = ", ".join(sorted(SUPPORTED_MODEL_PROVIDERS))
            view.write(f"[red]Unsupported provider '{provider}'. Supported: {allowed}[/]\n")
            return

        data = self._load_user_config_dict()
        llm = data.setdefault("llm", {})
        if not isinstance(llm, dict):
            llm = {}
            data["llm"] = llm
        models = self._ensure_models_map(data)

        entry: dict[str, Any] = {"provider": provider}
        if model:
            entry["model"] = model
        if base_url:
            entry["base_url"] = base_url
        if credential:
            if self._is_env_var_name(credential):
                entry["api_key_env"] = credential.upper()
            else:
                entry["api_key"] = credential

        models[model_name] = entry
        if not llm.get("model_ref"):
            llm["model_ref"] = model_name

        user_config_path = get_user_config_path()
        atomic_write_json(user_config_path, data)
        self._provider_notice_shown = False

        view.write(f"[green]Added model '{model_name}' to {user_config_path}[/]\n")
        if provider != "stub" and not entry.get("api_key"):
            env_name = self._preferred_env_var_name(provider, entry.get("api_key_env"))
            view.write(
                f"[dim]Set environment key: {env_name} (or NEONRP_LLM_API_KEY), then restart TUI for shell-level env changes.[/]\n"
            )
        if entry.get("api_key"):
            view.write("[yellow]API key is stored in plain text in user config. Prefer environment variables.[/]\n")
        self._show_provider_setup_notice()

    def _cmd_auth_set_model(self, args: list[str]) -> None:
        """Set active model_ref: /auth set model <name>."""
        view = self.query_one("#conversation-view", ConversationView)
        if len(args) < 2 or args[0].lower() != "model":
            view.write("[yellow]Usage: /auth set model <name>[/]\n")
            return
        model_name = args[1].strip()

        data = self._load_user_config_dict()
        models = self._ensure_models_map(data)
        if model_name not in models:
            view.write(f"[red]Model '{model_name}' not found. Use /auth list.[/]\n")
            return

        llm = data.setdefault("llm", {})
        if not isinstance(llm, dict):
            llm = {}
            data["llm"] = llm
        llm["model_ref"] = model_name

        user_config_path = get_user_config_path()
        atomic_write_json(user_config_path, data)
        self._provider_notice_shown = False
        view.write(f"[green]Active model set to '{model_name}'.[/]\n")
        self._show_provider_setup_notice()
        self._refresh_status(include_event_count=False)

    def _cmd_auth_rm_model(self, args: list[str]) -> None:
        """Remove a named model: /auth rm model <name>."""
        view = self.query_one("#conversation-view", ConversationView)
        if len(args) < 2 or args[0].lower() != "model":
            view.write("[yellow]Usage: /auth rm model <name>[/]\n")
            return
        model_name = args[1].strip()

        data = self._load_user_config_dict()
        models = self._ensure_models_map(data)
        if model_name not in models:
            view.write(f"[red]Model '{model_name}' not found.[/]\n")
            return

        llm = data.get("llm", {})
        active_ref = llm.get("model_ref") if isinstance(llm, dict) else None
        if active_ref == model_name:
            view.write("[red]Cannot remove currently active model. Switch first with /auth set model <name>.[/]\n")
            return

        models.pop(model_name, None)
        user_config_path = get_user_config_path()
        atomic_write_json(user_config_path, data)
        view.write(f"[green]Removed model '{model_name}'.[/]\n")

    def _cmd_auth_show_model(self, args: list[str]) -> None:
        """Show model details: /auth show model [name]."""
        view = self.query_one("#conversation-view", ConversationView)
        if args and args[0].lower() != "model":
            view.write("[yellow]Usage: /auth show model [name][/]\n")
            return

        data = self._load_user_config_dict()
        llm = data.get("llm", {})
        if not isinstance(llm, dict):
            llm = {}
        models = self._ensure_models_map(data)

        model_name = args[1].strip() if len(args) > 1 else llm.get("model_ref", "stub")
        cfg = models.get(model_name)
        if not isinstance(cfg, dict):
            view.write(f"[red]Model '{model_name}' not found. Use /auth list.[/]\n")
            return

        provider = str(cfg.get("provider", "stub")).lower()
        api_key_env = cfg.get("api_key_env")
        env_hint = self._preferred_env_var_name(provider, api_key_env)
        api_key_present = bool(cfg.get("api_key")) or bool(get_api_key(api_key_env or provider))

        view.write("[bold]Model Details[/]\n")
        view.write(f"  [cyan]name:[/] {model_name}\n")
        view.write(f"  [cyan]provider:[/] {provider}\n")
        view.write(f"  [cyan]model:[/] {cfg.get('model', '(default)')}\n")
        view.write(f"  [cyan]base_url:[/] {cfg.get('base_url', '(default)')}\n")
        view.write(f"  [cyan]api_key_env:[/] {api_key_env or env_hint}\n")
        view.write(
            f"  [cyan]api_key:[/] {'configured (stored in config)' if cfg.get('api_key') else ('configured' if api_key_present else 'missing')}\n"
        )
        view.write(f"  [cyan]active:[/] {'yes' if llm.get('model_ref') == model_name else 'no'}\n")
        view.write(f"  [dim]User config: {get_user_config_path()}[/]\n")

    def _load_agent_llm_config(self, agent_id: str) -> dict[str, Any] | None:
        """Load optional llm config from agent.json."""
        agent_json = self.root / "agents" / agent_id / "agent.json"
        if not agent_json.exists():
            return None
        try:
            data = json.loads(agent_json.read_text(encoding="utf-8"))
            llm_data = data.get("llm")
            return llm_data if isinstance(llm_data, dict) else None
        except Exception:
            return None

    def _get_narrator_agent_id(self) -> str:
        """Resolve configured narrator/router agent id for this project."""
        try:
            narrator_id = str(load_config(self.root).tui.narrator_agent_id or "").strip()
            return narrator_id or "narrator"
        except Exception:
            return "narrator"

    def _get_agent_display_name(self, agent_id: str) -> str:
        """Resolve human-readable speaker name from agents/<id>/agent.json."""
        normalized_id = str(agent_id or "").strip()
        if not normalized_id:
            return "Narrator"
        agent_json = self.root / "agents" / normalized_id / "agent.json"
        if not agent_json.exists():
            return normalized_id
        try:
            payload = json.loads(agent_json.read_text(encoding="utf-8"))
        except Exception:
            return normalized_id
        if not isinstance(payload, dict):
            return normalized_id
        configured_name = str(payload.get("name") or "").strip()
        return configured_name or normalized_id

    def _get_root_speaker_name(self) -> str:
        """Get current top-level speaker display name for untagged model output."""
        agent_id = self.session.agent_id if self.session else self._get_default_agent()
        return self._get_agent_display_name(agent_id)

    def _get_effective_provider_config(self):
        """Resolve effective provider for current app/session."""
        config = load_config(self.root)
        agent_id = self.session.agent_id if self.session else self._get_default_agent()
        agent_llm = self._load_agent_llm_config(agent_id)
        return resolve_provider(config, agent_llm, self.provider)

    def _show_provider_setup_notice(self) -> None:
        """Show one-time provider setup guidance for common misconfiguration cases."""
        if self._provider_notice_shown:
            return

        view = self.query_one("#conversation-view", ConversationView)
        provider_cfg = self._get_effective_provider_config()
        provider_name = provider_cfg.provider

        if provider_name == "stub":
            view.write("[yellow]LLM endpoint is not configured (using stub test provider).[/]\n")
            view.write("[dim]Run /auth list, then /auth set model <name> to use a real model endpoint.[/]\n")
            self._provider_notice_shown = True
            return

        if not self._has_api_credential(provider_cfg):
            env_name = self._preferred_env_var_name(provider_name, provider_cfg.api_key_env)
            view.write(f"[yellow]Provider '{provider_name}' is selected but API key is missing.[/]\n")
            view.write(f"[dim]Set {env_name} (or NEONRP_LLM_API_KEY), then run /auth show model.[/]\n")
            self._provider_notice_shown = True

    @staticmethod
    def _is_env_var_name(value: str) -> bool:
        """Heuristic: treat uppercase-with-underscores token as env var name."""
        if not value:
            return False
        if not value.replace("_", "").isalnum():
            return False
        return value.upper() == value and "_" in value

    @staticmethod
    def _preferred_env_var_name(provider: str, api_key_env: str | None) -> str:
        """Return the env var name to show to users."""
        if api_key_env and NeonRPApp._is_env_var_name(api_key_env):
            candidate = api_key_env.upper()
            if candidate.endswith("_API_KEY"):
                return candidate
            return f"{candidate}_API_KEY"
        return f"{provider.upper()}_API_KEY"

    @staticmethod
    def _has_api_credential(provider_cfg: Any) -> bool:
        """Check whether provider has usable API credentials."""
        if getattr(provider_cfg, "api_key", None):
            return True
        key_provider = provider_cfg.api_key_env or provider_cfg.provider
        return bool(get_api_key(key_provider))

    def _cmd_undo(self) -> None:
        """Undo last change."""
        view = self.query_one("#conversation-view", ConversationView)

        try:
            from neonrp.core.branch import undo_last_event

            success = undo_last_event(self.root, self.branch)
            if success:
                view.write("[green]Undone last change[/]\n")
                self._refresh_status()
            else:
                view.write("[yellow]Nothing to undo[/]\n")
        except Exception as e:
            view.write(f"[red]Undo failed: {e}[/]\n")

    def _cmd_save(self, args: list[str]) -> None:
        """Save checkpoint."""
        view = self.query_one("#conversation-view", ConversationView)

        name = args[0] if args else None
        try:
            from neonrp.commands.save import create_save_snapshot

            result = create_save_snapshot(self.root, name)
            view.write(f"[green]Saved checkpoint: {result['save_id']}[/]\n")
        except Exception as e:
            view.write(f"[red]Save failed: {e}[/]\n")

    def _cmd_load(self, args: list[str]) -> None:
        """Load a saved snapshot."""
        view = self.query_one("#conversation-view", ConversationView)

        if not args:
            from neonrp.commands.save import list_loadable_save_snapshots

            snapshots = list_loadable_save_snapshots(self.root)
            if not snapshots:
                view.write("[yellow]No loadable snapshots found.[/]\n")
                return

            options: list[tuple[str, str]] = []
            for snapshot in snapshots:
                created = snapshot.get("created") or "unknown"
                label = (
                    f"{snapshot['save_id']}  "
                    f"(branch={snapshot['branch']} · head={snapshot['head_event']} · created={created})"
                )
                options.append((label, snapshot["save_id"]))

            def on_selected(selected_snapshot_id: str | None) -> None:
                if not selected_snapshot_id:
                    return
                self._cmd_load([selected_snapshot_id])

            self.push_screen(SavePickerScreen(options), on_selected)
            return

        snapshot_id = args[0]
        try:
            from neonrp.commands.save import load_save_snapshot

            load_save_snapshot(self.root, snapshot_id)
            if self.session:
                self.branch = self.session._current_branch()
                self.session.branch = self.branch
                view.clear()
                self._reset_estimated_tokens()
                if self._restore_session():
                    view.write(f"[green]Loaded snapshot: {snapshot_id} (session restored).[/]\n")
                else:
                    view.write(f"[green]Loaded snapshot: {snapshot_id}.[/]\n")
            else:
                view.write(f"[green]Loaded snapshot: {snapshot_id}.[/]\n")
        except Exception as e:
            view.write(f"[red]Load failed: {e}[/]\n")

    def _cmd_config(self, args: list[str]) -> None:
        """Show or set project-level config values."""
        view = self.query_one("#conversation-view", ConversationView)

        if not args or args[0] == "show":
            try:
                config = load_config(self.root)
                cfg_path = get_config_path(self.root)
                provider_cfg = self._get_effective_provider_config()
                view.write("[bold]Project config:[/]\n")
                view.write(f"  [cyan]llm.model_ref:[/] {config.llm.model_ref}\n")
                view.write(f"  [cyan]resolved provider:[/] {provider_cfg.provider}\n")
                view.write(f"  [cyan]resolved model:[/] {provider_cfg.model or '(default)'}\n")
                view.write(f"  [cyan]llm.max_retries:[/] {config.llm.max_retries}\n")
                view.write(f"  [cyan]llm.max_context_chars:[/] {config.llm.max_context_chars}\n")
                view.write(f"  [cyan]config file:[/] {cfg_path}\n")
                view.write("[dim]Use /config set <model_ref|max_retries|max_context_chars> <value>[/]\n")
            except Exception as e:
                view.write(f"[red]Config error: {e}[/]\n")
            return

        if args[0] != "set":
            view.write("[red]Usage: /config [show|set <key> <value>][/]\n")
            return

        if len(args) < 3:
            view.write("[red]Usage: /config set <key> <value>[/]\n")
            view.write("[dim]Keys: model_ref, max_retries, max_context_chars[/]\n")
            return

        key = args[1]
        value = " ".join(args[2:])
        valid_keys = {"model_ref", "max_retries", "max_context_chars"}
        if key not in valid_keys:
            view.write(f"[red]Unknown key '{key}'. Valid: {', '.join(sorted(valid_keys))}[/]\n")
            return

        if key in {"max_retries", "max_context_chars"}:
            try:
                value = int(value)
            except ValueError:
                view.write(f"[red]{key} must be an integer[/]\n")
                return

        try:
            config_path = get_config_path(self.root)
            data: dict[str, Any]
            if config_path.exists():
                data = json.loads(config_path.read_text(encoding="utf-8"))
            else:
                data = create_default_config_template()
            if "llm" not in data:
                data["llm"] = {}
            data["llm"][key] = value
            atomic_write_json(config_path, data)
            view.write(f"[green]Set {key} = {value}[/]\n")
        except Exception as e:
            view.write(f"[red]Config set failed: {e}[/]\n")

    def _cmd_branch_list(self) -> None:
        """List branches from manifest."""
        view = self.query_one("#conversation-view", ConversationView)
        manifest_path = get_manifest_path(self.root)
        if not manifest_path.exists():
            view.write("[red]Error: Not initialized. Run 'neonrp init' first.[/]\n")
            return
        try:
            manifest = Manifest(**json.loads(manifest_path.read_text(encoding="utf-8")))
            view.write("[bold]Branches:[/]\n")
            for name, meta in manifest.branches.items():
                marker = "*" if name == manifest.current_branch else " "
                view.write(f"  {marker} {name} (head: {meta.head_event})\n")
        except Exception as e:
            view.write(f"[red]Failed to list branches: {e}[/]\n")

    @staticmethod
    def _parsed_to_argv(command: str, args: list[str], options: dict[str, str]) -> list[str]:
        """Convert parsed slash command into CLI argv."""
        argv = [command, *args]
        for key, value in options.items():
            flag = f"-{key}" if len(key) == 1 else f"--{key}"
            argv.append(flag)
            if value != "true":
                argv.append(value)
        return argv

    def _invoke_cli(self, argv: list[str]) -> tuple[int, str]:
        """Invoke NeonRP CLI command and return (exit_code, output)."""
        from click.testing import CliRunner
        from neonrp.cli import cli

        runner = CliRunner()
        old_cwd = Path.cwd()
        try:
            os.chdir(self.root)
            result = runner.invoke(cli, argv)
        finally:
            os.chdir(old_cwd)

        output = (result.output or "").strip()
        if result.exception and isinstance(result.exception, SystemExit):
            return result.exit_code, output
        if result.exception and output:
            output = f"{output}\n{result.exception}"
        elif result.exception:
            output = str(result.exception)
        return result.exit_code, output

    def _forward_cli_command(self, parsed) -> None:
        """Forward a slash command to the corresponding CLI command."""
        view = self.query_one("#conversation-view", ConversationView)
        argv = self._parsed_to_argv(parsed.command, parsed.args, parsed.options)
        exit_code, output = self._invoke_cli(argv)

        if output:
            view.write(f"{output}\n")
        elif exit_code != 0:
            view.write(f"[red]Command failed (exit {exit_code})[/]\n")

        # Commands that mutate project state should refresh status.
        if parsed.command in {"branch", "game", "sandbox", "load", "save", "undo", "redo", "init", "import"}:
            self._refresh_status()

    def _set_run_status(self, text: str) -> None:
        """Show ephemeral run status in input area."""
        try:
            input_area = self.query_one("#input-area", InputArea)
            input_area.set_run_status(text)
        except Exception:
            pass

    def _clear_run_status(self) -> None:
        """Hide run status in input area."""
        try:
            input_area = self.query_one("#input-area", InputArea)
            input_area.clear_run_status()
        except Exception:
            pass

    def _get_ask_user_panel(self) -> AskUserInlinePanel | None:
        """Return inline ask_user panel when mounted."""
        try:
            return self.query_one("#ask-user-inline", AskUserInlinePanel)
        except Exception:
            return None

    def _show_ask_user_panel(self, question: str, options: list[str], on_submit: Any) -> None:
        """Show inline ask_user panel; fallback to canceled if panel is unavailable.

        Wraps the raw `on_submit` so we can also:
        - clear `_active_ask_user_submit` the moment a result comes in
        - hide the panel if the submit was triggered externally (main
          input / Discord inbound) rather than via the panel's own buttons

        Keeping the main input ENABLED during ask_user means the player
        can answer by typing in the main chat bar too — `_send_message`
        re-routes that text into this callback instead of starting a new
        turn.
        """
        panel = self._get_ask_user_panel()
        if panel is None:
            on_submit(AskUserInlinePanel.CANCEL_RESULT)
            return

        def _wrapped_submit(result: str | None) -> None:
            # Drop the app-level hook first so a late-arriving re-entrant
            # Discord inbound can't double-submit.
            self._active_ask_user_submit = None
            # If the submit came from OUTSIDE the panel (typed in main
            # input, or pushed via bridge), the panel is still visible —
            # dismiss it explicitly.
            try:
                live_panel = self._get_ask_user_panel()
                if live_panel is not None:
                    live_panel.hide_prompt()
            except Exception:
                pass
            on_submit(result)

        self._active_ask_user_submit = _wrapped_submit
        self._set_main_input_enabled(False)
        panel.show_prompt(question, options, _wrapped_submit)
        self._set_run_status("Waiting for your choice...")

    def _cancel_active_ask_user(self) -> bool:
        """Cancel active inline ask_user prompt, if any."""
        panel = self._get_ask_user_panel()
        if panel is None:
            return False
        cancelled = panel.cancel_current()
        if cancelled:
            # Clear the routing hook too — the panel's own cancel path
            # invokes the wrapped submit with the CANCELLED result, which
            # already clears this, but guard against the panel firing
            # cancel without going through our wrapper.
            self._active_ask_user_submit = None
            self._clear_run_status()
            self._set_main_input_enabled(True)
            try:
                self.query_one("#message-input", Input).focus()
            except Exception:
                pass
        return cancelled

    def _set_main_input_enabled(self, enabled: bool) -> None:
        """Swap placeholder/styling on the main chat input while ask_user is active.

        Historically this actually disabled the input widget — but that
        blocked both keyboard answers and Discord inbound. Now the input
        stays editable; `_send_message` detects the active ask_user hook
        and re-routes the text to it instead of starting a new turn.
        """
        try:
            input_area = self.query_one("#input-area", InputArea)
            if enabled:
                input_area.remove_class("ask-user-active")
            else:
                input_area.add_class("ask-user-active")
        except Exception:
            pass

        try:
            input_widget = self.query_one("#message-input", Input)
            # Always keep the input editable — just change the hint so the
            # user knows typing will answer the pending prompt rather than
            # open a new turn.
            input_widget.disabled = False
            if enabled:
                input_widget.placeholder = get_message(self.ui_locale, "input_hint")
            else:
                input_widget.placeholder = get_message(self.ui_locale, "ask_user.waiting_choice")
        except Exception:
            pass

    @classmethod
    def _estimate_text_tokens(cls, text: str) -> int:
        """Estimate token count from plain text without provider usage metadata."""
        if not text:
            return 0
        try:
            unit_count = len(cls._TOKEN_SPLIT_RE.findall(text))
            byte_count = len(text.encode("utf-8"))
        except Exception:
            unit_count = len(text)
            byte_count = len(text)
        estimate = max(unit_count, byte_count // 4)
        return max(1, estimate)

    def _estimate_prompt_tokens_for_turn(self, user_text: str) -> int:
        """Estimate prompt tokens for the next turn from local conversation context."""
        texts: list[str] = []
        message_count = 1  # current user message
        if self.session:
            raw_messages = getattr(self.session, "messages", [])
            messages = raw_messages if isinstance(raw_messages, list) else []
            for msg in messages:
                content = getattr(msg, "content", "")
                if content:
                    texts.append(str(content))
                message_count += 1
        texts.append(user_text)
        joined = "\n".join(texts)
        # Add small structural overhead per message.
        return self._estimate_text_tokens(joined) + (message_count * 4)

    def _bump_prompt_tokens(self, text: str) -> None:
        increment = self._estimate_prompt_tokens_for_turn(text)
        self._est_prompt_tokens_total += max(0, increment)
        self._refresh_status(include_event_count=False)

    def _bump_completion_tokens(self, text: str) -> None:
        increment = self._estimate_text_tokens(text)
        if increment <= 0:
            return
        self._est_completion_tokens_total += increment
        self._refresh_status(include_event_count=False)

    def _bump_tool_activity_tokens(self, tool_name: str, params: dict[str, Any], raw_result: str = "") -> None:
        """Add a small token estimate for tool-activity events to keep live counters responsive.

        Heuristic direction:
        - tool use announcement (no ``raw_result``): completion-side activity
        - tool result payload (has ``raw_result``): prompt-side activity for next turn
        """
        snippet = raw_result[:320] if raw_result else ""
        payload = f"{tool_name} {json.dumps(params, ensure_ascii=False)} {snippet}"
        increment = max(1, min(64, self._estimate_text_tokens(payload) // 2))
        if raw_result:
            self._est_prompt_tokens_total += increment
        else:
            self._est_completion_tokens_total += increment
        self._refresh_status(include_event_count=False)

    def _reset_estimated_tokens(self) -> None:
        self._est_prompt_tokens_total = 0
        self._est_completion_tokens_total = 0

    def _send_message(self, text: str) -> None:
        """Send message to conversation session (or claude -p bridge in MCP mode)."""
        # Ask_user re-routing — must come BEFORE the "request already running"
        # guard, because the worker thread IS alive (blocked on the ask_user
        # response event). Typing in the main input OR a Discord inbound
        # message goes through here; we treat the text as the prompt answer,
        # unblock the worker, and skip starting a new turn.
        if self._active_ask_user_submit is not None:
            cb = self._active_ask_user_submit
            # Render the answer as a user message so the transcript shows
            # what the player said, the same as a normal turn would.
            try:
                view = self.query_one("#conversation-view", ConversationView)
                view.add_user_message(text)
            except Exception:
                pass
            try:
                cb(text)
            except Exception:
                # Never let a broken submit kill the whole event loop —
                # just clear the hook and the worker will time out on its
                # own `response_event.wait()` in the worst case.
                self._active_ask_user_submit = None
            return
        if self._mcp_mode:
            self._send_mcp_message(text)
            return
        if not self.session:
            view = self.query_one("#conversation-view", ConversationView)
            view.write("[red]Session not initialized[/]\n")
            return
        if self._active_send_thread is not None and self._active_send_thread.is_alive():
            view = self.query_one("#conversation-view", ConversationView)
            view.write("[yellow]A request is already running. Please wait...[/]\n")
            return

        view = self.query_one("#conversation-view", ConversationView)
        view.add_user_message(text)
        self._last_user_input = text
        self._stream_started = False
        self._subagent_stream_seen.clear()
        self._set_run_status("Thinking... waiting for model response")
        self._bump_prompt_tokens(text)
        # Immediately tell bridges a turn is starting — Discord etc. show a
        # 💭 placeholder so the remote viewer isn't staring at dead air while
        # the LLM is still streaming locally.
        self._emit_bridge_event("turn_status", data={"state": "thinking"})
        turn_epoch = self._conversation_epoch

        # Use a daemon thread so Ctrl+Q can always return terminal control promptly.
        worker = threading.Thread(
            target=self._send_worker,
            args=(text, turn_epoch),
            name="neonrp-send-worker",
            daemon=True,
        )
        self._active_send_thread = worker
        worker.start()

    # ------------------------------------------------------------------
    # MCP mode: forward user input to `claude -p` running inside the sibling
    # Claude workspace directory. No separate terminal needed.
    # ------------------------------------------------------------------

    def _send_mcp_message(self, text: str) -> None:
        view = self.query_one("#conversation-view", ConversationView)
        if self._active_send_thread is not None and self._active_send_thread.is_alive():
            view.write("[yellow]Claude is still responding. Please wait...[/]\n")
            return
        if shutil.which("claude") is None:
            view.write(
                "[red]`claude` CLI not found on PATH. Install Claude Code or switch to a hosted model via /wl-model.[/]\n"
            )
            return

        view.add_user_message(text)
        self._last_user_input = text
        self._bump_prompt_tokens(text)
        # Mirror the user turn into the NeonRP session log so `continue` can
        # restore the transcript even though `self.session is None` in MCP mode.
        self._append_mcp_session_user(text)
        # Immediately mark the Discord side as "thinking" — claude -p startup
        # alone can take 10–30s, so without this Discord looks frozen.
        self._emit_bridge_event("turn_status", data={"state": "thinking"})
        self._set_run_status("Claude Code thinking…  (this may take 10–30s on first turn)")
        # Mount the animated `narrating…` activity note immediately so the
        # user sees something happening during the long `claude -p` startup /
        # permission-approval window — not just a speaker tag with silence.
        try:
            speaker_ref = self._get_root_speaker_name()
            view._mount_assistant_activity_note(speaker_ref, animated=True)
        except Exception:
            pass
        # Reset the per-turn assistant buffer — will be filled as chunks arrive.
        self._mcp_assistant_buffer = []
        turn_epoch = self._conversation_epoch

        worker = threading.Thread(
            target=self._mcp_claude_worker,
            args=(text, turn_epoch),
            name="neonrp-mcp-claude",
            daemon=True,
        )
        self._active_send_thread = worker
        worker.start()

    def _mcp_claude_worker(self, text: str, turn_epoch: int) -> None:
        import subprocess as _sp
        from neonrp.core.template_assets import get_claude_workspace_dir

        def _is_stale() -> bool:
            return turn_epoch != self._conversation_epoch

        workspace = get_claude_workspace_dir(self.root)
        if not workspace.exists():
            self._safe_call_from_thread(
                self._mcp_claude_error,
                f"Claude workspace missing: {workspace}",
            )
            return

        # -c / --continue resumes the most recent conversation in the workspace.
        # First message has no prior conversation, so we use plain -p. Track
        # whether a conversation has already been opened via a flag.
        use_continue = getattr(self, "_mcp_claude_turn_count", 0) > 0
        # `acceptEdits` auto-approves edits that match the settings.local.json
        # allowlist we wrote. If the settings file isn't present (older
        # workspace) the user still gets prompted interactively — but the
        # settings.local.json approach is the primary path.
        cmd = ["claude", "-p", "--permission-mode", "acceptEdits", text]
        if use_continue:
            cmd.insert(1, "--continue")

        try:
            proc = _sp.Popen(
                cmd,
                cwd=str(workspace),
                stdout=_sp.PIPE,
                stderr=_sp.PIPE,
                text=True,
                encoding="utf-8",
                bufsize=1,
            )
        except Exception as exc:
            self._safe_call_from_thread(
                self._mcp_claude_error, f"Failed to spawn `claude`: {exc}"
            )
            return

        self._mcp_claude_process = proc
        first_chunk = True
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                if _is_stale():
                    try:
                        proc.terminate()
                    except Exception:
                        pass
                    return
                if not line:
                    continue
                if first_chunk:
                    self._safe_call_from_thread(self._mcp_claude_begin_stream)
                    first_chunk = False
                self._safe_call_from_thread(self._mcp_claude_append_stream, line)
                self._bump_completion_tokens(line)
            proc.wait(timeout=5)
        except Exception as exc:
            self._safe_call_from_thread(
                self._mcp_claude_error, f"claude stream error: {exc}"
            )
            return
        finally:
            self._mcp_claude_process = None

        if proc.returncode and proc.returncode != 0:
            stderr_text = ""
            try:
                stderr_text = proc.stderr.read() if proc.stderr else ""
            except Exception:
                pass
            self._safe_call_from_thread(
                self._mcp_claude_error,
                f"claude exited {proc.returncode}. {stderr_text.strip()[:300]}",
            )
            return

        self._mcp_claude_turn_count = getattr(self, "_mcp_claude_turn_count", 0) + 1
        self._safe_call_from_thread(self._mcp_claude_end_stream)

    def _mcp_claude_begin_stream(self) -> None:
        # First chunk arrived — swap status text so the bar reflects actual streaming.
        self._set_run_status("Claude Code narrating…")

    def _mcp_claude_append_stream(self, chunk: str) -> None:
        view = self.query_one("#conversation-view", ConversationView)
        view.add_assistant_chunk(chunk, speaker=self._get_root_speaker_name())
        # Accumulate for the session mirror; flushed on end_stream.
        try:
            self._mcp_assistant_buffer.append(chunk)
        except Exception:
            pass

    def _mcp_claude_end_stream(self) -> None:
        view = self.query_one("#conversation-view", ConversationView)
        # `view.add_assistant_end()` internally emits a single bridge
        # narrator_text event using the normalized stream buffer (3+ blank
        # lines collapsed to 2). Don't re-emit `_mcp_assistant_buffer` here —
        # it's the raw `claude -p` stdout and would double-post to Discord,
        # the raw copy still carrying every blank line from the subprocess.
        view.add_assistant_end()
        self._clear_run_status()
        # Mirror the finalized assistant turn into the NeonRP session log.
        full_text = "".join(getattr(self, "_mcp_assistant_buffer", []))
        self._mcp_assistant_buffer = []
        if full_text.strip():
            self._append_mcp_session_assistant(full_text)
        self._emit_bridge_event("turn_status", data={"state": "complete"})

    def _mcp_claude_error(self, message: str) -> None:
        view = self.query_one("#conversation-view", ConversationView)
        view.write(f"[red]{message}[/]\n")
        self._clear_run_status()
        # Flush any partial buffer so the saved transcript matches what was shown.
        full_text = "".join(getattr(self, "_mcp_assistant_buffer", []))
        self._mcp_assistant_buffer = []
        if full_text.strip():
            self._append_mcp_session_assistant(full_text)
        self._emit_bridge_event("turn_status", data={"state": "complete"})

    # ------------------------------------------------------------------
    # NeonRP session mirror for MCP mode. The real ConversationSession is
    # not initialized (`self.session is None`) because the LLM call is
    # proxied to `claude -p`. We still want the TUI transcript restorable
    # on next launch, `/save`/`/load` usable, and session-based features to
    # work for MCP-authored games — so we append directly to the same
    # `.neonrp/sessions/<branch>.jsonl` file that ConversationSession uses.
    # ------------------------------------------------------------------

    def _append_mcp_session_user(self, text: str) -> None:
        if not self._mcp_mode or not text:
            return
        try:
            from neonrp.core.session import append_user_query

            branch = self._resolve_session_branch()
            append_user_query(self.root, branch, text)
        except Exception:
            pass

    def _append_mcp_session_assistant(self, text: str) -> None:
        if not self._mcp_mode or not text:
            return
        try:
            from neonrp.core.session import append_assistant_response

            branch = self._resolve_session_branch()
            append_assistant_response(self.root, branch, content=text)
        except Exception:
            pass

    def _resolve_session_branch(self) -> str:
        branch = str(getattr(self, "branch", None) or "").strip()
        if branch:
            return branch
        try:
            from neonrp.core.manifest import load_manifest

            manifest = load_manifest(self.root)
            return manifest.current_branch or "main"
        except Exception:
            return "main"

    # ------------------------------------------------------------------
    # Bridge hub (Phase 1a) — Discord / Telegram / future buddy-bot.
    # Lazy-init: if nobody asks for it, there's zero overhead.
    # ------------------------------------------------------------------

    def _ensure_bridge_hub(self) -> Any:
        """Create the bridge hub on first use and wire up the inbound path.

        Also registers any external bridges (Discord, Telegram) whose
        `autostart` flag is set in user config. If the optional python
        package (discord.py etc) is missing, the bridge silently no-ops.
        """
        if self._bridge_hub is not None:
            return self._bridge_hub
        try:
            from neonrp.bridges import BridgeHub, InboundMessage
            from neonrp.bridges.tui import TUIBridge

            hub = BridgeHub()

            def _on_inbound(msg: InboundMessage) -> None:
                # Bridge-originated player input flows through the same
                # `_send_message` path as local typing. Running on a bridge
                # thread → re-enter via call_from_thread so Textual widgets
                # stay thread-consistent.
                try:
                    self.call_from_thread(self._send_message, msg.text or "")
                except Exception:
                    # call_from_thread requires app.run loop; fall back to
                    # direct call for tests / headless.
                    self._send_message(msg.text or "")

            hub.set_inbound_handler(_on_inbound)
            hub.register(TUIBridge(self))

            # Auto-register external bridges flagged in user config.
            self._register_autostart_bridges(hub)

            hub.start_all()
            self._bridge_hub = hub
        except Exception:
            # Bridge subsystem must never break the TUI — swallow and leave
            # hub as None so emits become no-ops via `emit_if_hub`.
            self._bridge_hub = None
        return self._bridge_hub

    def _register_autostart_bridges(self, hub: Any) -> None:
        """Attach bridges whose `autostart=true` in ~/.neonrp/config.json.

        Hard-skipped under pytest or when `NEONRP_DISABLE_EXTERNAL_BRIDGES=1`
        is set — otherwise the test suite would connect to the developer's
        real Discord channel (because the user config is read globally) and
        blast test fixtures into it. `add_assistant_end` emits to bridges,
        so a single long-stream test fixture posts hundreds of lines.
        """
        if os.environ.get("PYTEST_CURRENT_TEST") or os.environ.get("NEONRP_DISABLE_EXTERNAL_BRIDGES"):
            return
        # Discord
        try:
            from neonrp.core.discord_config import get_discord_settings
            from neonrp.bridges.discord_bridge import build_discord_bridge_from_config

            settings = get_discord_settings()
            if settings.get("autostart") and settings.get("bot_token") and settings.get("channel_id"):
                bridge = build_discord_bridge_from_config()
                if bridge is not None:
                    hub.register(bridge)
        except Exception:
            pass  # discord subsystem stays optional

    def _flush_bridge_before_ask_user(self, question: str, options: list[str]) -> None:
        """Drain the per-turn bridge buffer as a narrator_text, then emit ask_user.

        Runs on the UI thread (must touch the view). `on_ask_user` in the
        worker thread hops here via `_safe_call_from_thread` so the ordering
        on bridges is:
          1. any narrative accumulated so far → narrator_text (edits the
             💭 placeholder into the pre-question narration)
          2. ask_user → posts the question as a NEW message below it
        Without step 1, the ask_user prompt would overwrite the 💭 and the
        pre-question story would never reach Discord.
        """
        try:
            view = self.query_one("#conversation-view", ConversationView)
        except Exception:
            view = None
        if view is not None:
            try:
                # Capture whatever's mid-stream into the bridge buffer, then
                # drain — otherwise the post-question `add_assistant_end`
                # would re-emit the same segments we just sent.
                view._flush_assistant_stream_segment()
                segments = list(view._bridge_segment_buffer)
                view._bridge_segment_buffer.clear()
                if segments:
                    view._emit_turn_to_bridges(segments)
            except Exception:
                pass
        self._emit_bridge_event(
            "ask_user",
            data={"question": question, "options": list(options or [])},
        )

    def _emit_bridge_event(
        self,
        kind: str,
        speaker: str = "",
        text: str = "",
        data: dict[str, Any] | None = None,
    ) -> None:
        """Publish an event to all registered bridges (no-op if none).

        `data` is an explicit dict kwarg (not **kwargs) — the previous
        signature captured `data={...}` into `**kwargs` as `{"data": {...}}`,
        producing a double-wrapped payload on the OutboundEvent. That broke
        `turn_status`, which packs its state in `data`. Callers now pass a
        plain dict and it's forwarded untouched to the bridge.
        """
        hub = self._bridge_hub
        if hub is None:
            return
        try:
            from neonrp.bridges import OutboundEvent

            hub.emit(
                OutboundEvent(
                    kind=kind,
                    speaker=speaker,
                    text=text,
                    data=dict(data) if data else {},
                )
            )
        except Exception:
            pass

    def _send_worker(self, text: str, turn_epoch: int | None = None) -> None:
        """Worker for sending message."""
        if turn_epoch is None:
            turn_epoch = self._conversation_epoch

        def _is_stale_turn() -> bool:
            return turn_epoch != self._conversation_epoch

        try:
            worker = get_current_worker()
        except Exception:
            # Not running in a worker thread, run synchronously
            worker = None

        if self.verbose:
            turn_ctx = self._verbose_turn_context(text)
            self._append_verbose_event("turn_start", turn_ctx)
            if worker is None or not worker.is_cancelled:
                self._safe_call_from_thread(
                    self._write_verbose_line,
                    (
                        f"turn start: mode={turn_ctx.get('mode')} agent={turn_ctx.get('agent')} "
                        f"provider={turn_ctx.get('provider', 'unknown')} model={turn_ctx.get('model', '')}"
                    ),
                )

        # Callbacks for streaming and tool use
        def on_chunk(chunk: str) -> None:
            if (worker is None or not worker.is_cancelled) and not _is_stale_turn():
                self._safe_call_from_thread(self._append_chunk, chunk)

        def on_thinking(thinking: str) -> None:
            if (worker is None or not worker.is_cancelled) and not _is_stale_turn():
                self._safe_call_from_thread(self._append_thinking, thinking)

        def on_tool_use(tool_name: str, params: dict[str, Any]) -> None:
            if (worker is None or not worker.is_cancelled) and not _is_stale_turn():
                self._safe_call_from_thread(self._show_tool_use, tool_name, params)

        def on_tool_result(tool_name: str, params: dict[str, Any], raw_result: str) -> None:
            if (worker is None or not worker.is_cancelled) and not _is_stale_turn():
                self._safe_call_from_thread(self._show_tool_result, tool_name, params, raw_result)

        def on_ask_user(question: str, options: list[str]) -> str:
            response_event = threading.Event()
            response_holder: list[str | None] = [None]

            # Mirror the prompt to external bridges (Discord etc) before we
            # block on the TUI modal. Without this the Discord-side viewer
            # would just see "💭 Thinking…" until the turn finally ends,
            # with no idea the game is waiting for an input choice.
            #
            # Flush any accumulated pre-ask-user narrative FIRST so Discord
            # sees the story leading up to the question, not just the
            # question dropped in without context. The normal narrator_text
            # emit only fires at turn end — without this flush, the
            # placeholder would be overwritten by the ask_user prompt and
            # the pre-question narration would be lost on Discord.
            self._safe_call_from_thread(
                self._flush_bridge_before_ask_user, question, list(options or [])
            )

            def _show_inline() -> None:
                def _on_submit(result: str | None) -> None:
                    if result is None or result == AskUserInlinePanel.CANCEL_RESULT:
                        response_holder[0] = ASK_USER_CANCELLED_RESPONSE
                    else:
                        response_holder[0] = result
                    response_event.set()
                    self._set_main_input_enabled(True)
                    try:
                        self.query_one("#message-input", Input).focus()
                    except Exception:
                        pass

                self._show_ask_user_panel(question, options, _on_submit)

            self._safe_call_from_thread(_show_inline)
            response_event.wait()
            return str(response_holder[0] or ASK_USER_CANCELLED_RESPONSE)

        # Run conversation turn
        try:
            result = self.session.send(
                text,
                on_chunk=on_chunk,
                on_thinking=on_thinking,
                on_tool_use=on_tool_use,
                on_tool_result=on_tool_result,
                on_ask_user=on_ask_user,
            )
        except Exception as exc:
            if self.verbose:
                self._append_verbose_event(
                    "turn_exception",
                    {
                        "error": str(exc),
                        "traceback": traceback.format_exc(),
                    },
                )
            result = ConversationTurnResult(success=False, run_id="", error=f"Conversation failed: {exc}")

        if self.verbose:
            self._append_verbose_event(
                "turn_result",
                {
                    "success": result.success,
                    "run_id": result.run_id,
                    "error": result.error,
                    "turns_used": result.turns_used,
                    "usage": result.usage,
                    "tool_calls_made": result.tool_calls_made,
                    "files_modified": result.files_modified,
                },
            )

        if not _is_stale_turn():
            self._current_run_result = result

        if (worker is None or not worker.is_cancelled) and not _is_stale_turn():
            self._safe_call_from_thread(self._handle_result, result)
        if self._active_send_thread is threading.current_thread():
            self._active_send_thread = None

    def _safe_call_from_thread(self, callback: Any, *args: Any) -> None:
        """Call into UI thread safely; ignore late calls after app shutdown."""
        try:
            self.call_from_thread(callback, *args)
        except Exception:
            pass

    def _append_chunk(self, chunk: str) -> None:
        """Append a chunk to the conversation view (called from thread)."""
        if not chunk:
            return
        speaker, payload = self._extract_sub_agent_tag(chunk)
        payload = self._normalize_assistant_text(payload)
        if not payload:
            return
        # Hidden sub-agents: short-circuit BEFORE touching status bar,
        # tool-prediction cards, or the stream widget. Otherwise the
        # content flashes into the TUI before `add_assistant_chunk` can
        # reject it, giving the "peek-then-hide" UX. Call the class-level
        # staticmethod so tests with MagicMock views don't short-circuit
        # through truthy-Mock returns.
        if speaker and ConversationView._agent_is_hidden_at(self.root, speaker):
            return
        if speaker:
            self._subagent_stream_seen.add(speaker)
        marker = self._CALLING_CHUNK_RE.match(payload.strip())
        if marker:
            raw_names = marker.group(1) if marker.groups() else ""
            func_names = [
                ConversationView._canonical_tool_name(name) for name in self._TOOL_CALL_FUNC_RE.findall(raw_names)
            ]
            if func_names:
                names = list(dict.fromkeys(func_names))
            else:
                names: list[str] = []
                for piece in raw_names.split(","):
                    name = ConversationView._canonical_tool_name(piece.strip())
                    if name and self._TOOL_NAME_TOKEN_RE.fullmatch(name):
                        names.append(name)
            if names:
                view = self.query_one("#conversation-view", ConversationView)
                scoped_names = [self._scope_tool_name(name, speaker) for name in names]
                if len(names) == 1:
                    if speaker:
                        self._set_run_status(f"Sub-agent `{speaker}` preparing tool `{names[0]}`")
                    else:
                        self._set_run_status(f"Thinking... preparing tool `{names[0]}`")
                else:
                    if speaker:
                        self._set_run_status(f"Sub-agent `{speaker}` preparing tools")
                    else:
                        self._set_run_status("Thinking... preparing tools")
                for scoped_name in scoped_names:
                    view.add_tool_indicator(scoped_name, {}, predicted=True)
                    self._bump_tool_activity_tokens(scoped_name, {})
            return
        view = self.query_one("#conversation-view", ConversationView)
        if speaker:
            self._set_run_status(f"Sub-agent `{speaker}` streaming response...")
        else:
            self._stream_started = True
            self._set_run_status("Streaming response...")
            speaker = self._get_root_speaker_name()
        if speaker:
            view.add_assistant_chunk(payload, speaker=speaker)
        else:
            view.add_assistant_chunk(payload)
        self._bump_completion_tokens(payload)

    def _append_thinking(self, thinking: str) -> None:
        """Append model thinking chunk when available (called from thread)."""
        if not thinking:
            return
        speaker, payload = self._extract_sub_agent_tag(thinking)
        if speaker and ConversationView._agent_is_hidden_at(self.root, speaker):
            return
        view = self.query_one("#conversation-view", ConversationView)
        if speaker:
            self._subagent_stream_seen.add(speaker)
        if speaker:
            self._set_run_status(f"Sub-agent `{speaker}` thinking...")
        else:
            self._set_run_status("Thinking...")
            speaker = self._get_root_speaker_name()
        if speaker:
            view.add_thinking_chunk(payload, speaker=speaker)
        else:
            view.add_thinking_chunk(payload)
        self._bump_completion_tokens(payload)

    def _show_tool_use(self, tool_name: str, params: dict[str, Any]) -> None:
        """Show tool use indicator (called from thread)."""
        speaker, raw_tool_name = self._extract_sub_agent_tag(tool_name)
        tool_name = ConversationView._canonical_tool_name(raw_tool_name)
        scoped_tool_name = self._scope_tool_name(tool_name, speaker)
        # Hidden sub-agents' tool cards would leak raw JSON params into
        # the transcript — token accounting still runs, but no UI card.
        if speaker and ConversationView._agent_is_hidden_at(self.root, speaker):
            self._bump_tool_activity_tokens(scoped_tool_name, params)
            return
        view = self.query_one("#conversation-view", ConversationView)
        if speaker:
            self._subagent_stream_seen.add(speaker)
        if speaker:
            self._set_run_status(f"Sub-agent `{speaker}` running tool `{tool_name}`")
        else:
            self._set_run_status(f"Thinking... running tool `{tool_name}`")
        view.add_tool_indicator(scoped_tool_name, params)
        self._bump_tool_activity_tokens(scoped_tool_name, params)

    def _show_tool_result(self, tool_name: str, params: dict[str, Any], raw_result: str) -> None:
        """Update tool indicator with completion detail (called from thread)."""
        speaker, raw_tool_name = self._extract_sub_agent_tag(tool_name)
        tool_name = ConversationView._canonical_tool_name(raw_tool_name)
        scoped_tool_name = self._scope_tool_name(tool_name, speaker)
        if speaker and ConversationView._agent_is_hidden_at(self.root, speaker):
            self._bump_tool_activity_tokens(scoped_tool_name, params, raw_result)
            return
        view = self.query_one("#conversation-view", ConversationView)
        if speaker:
            self._subagent_stream_seen.add(speaker)
        view.complete_tool_indicator(scoped_tool_name, params, raw_result)
        self._bump_tool_activity_tokens(scoped_tool_name, params, raw_result)

        # Show todo list inline immediately when TodoWrite completes
        if tool_name == "TodoWrite":
            try:
                payload = json.loads(raw_result)
                items = payload.get("data", {}).get("items", [])
                if isinstance(items, list) and items:
                    view.add_todo_display(items)
            except Exception:
                pass
        elif tool_name == "ask_user":
            fallback_question, fallback_options = self._extract_ask_user_prompt_from_args(params or {})
            selected = self._extract_ask_user_selection(
                raw_result,
                fallback_question=fallback_question,
                fallback_options=fallback_options,
            )
            if selected:
                question, response, options = selected
                rendered = self._format_ask_user_selection_message(question, response, options)
                if rendered:
                    view.add_user_message(rendered)
            else:
                cancelled = False
                try:
                    payload = json.loads(raw_result)
                    cancelled = str(payload.get("status", "")).strip().lower() == "cancelled"
                except Exception:
                    cancelled = False
                if cancelled:
                    rendered_cancelled = self._format_ask_user_cancelled_message(
                        fallback_question,
                        fallback_options,
                    )
                    if rendered_cancelled:
                        view.add_user_message(rendered_cancelled)
        elif tool_name == "task":
            try:
                payload = json.loads(raw_result)
            except Exception:
                payload = {}
            if isinstance(payload, dict):
                data = payload.get("data", {})
                if isinstance(data, dict):
                    agent_id = str(data.get("agent_id", "") or "").strip()
                    speaker = self._get_agent_display_name(agent_id) if agent_id else "Sub-agent"
                    assistant_text = self._normalize_assistant_text(str(data.get("assistant_text", "") or ""))
                    status = str(payload.get("status", "")).lower()
                    already_streamed = (agent_id in self._subagent_stream_seen) if agent_id else (speaker in self._subagent_stream_seen)
                    if not assistant_text:
                        if status == "success" and already_streamed:
                            return
                        if status == "success":
                            assistant_text = "Sub-task completed."
                        elif status == "cancelled":
                            error_text = str(payload.get("error") or data.get("error") or "").strip()
                            assistant_text = (
                                f"Sub-task canceled: {error_text}" if error_text else "Sub-task canceled by user."
                            )
                        else:
                            error_text = str(payload.get("error") or data.get("error") or "").strip()
                            assistant_text = f"Sub-task failed: {error_text}" if error_text else "Sub-task failed."
                    elif already_streamed:
                        return
                    view.add_named_assistant_message(speaker, assistant_text)
                    # Prevent _handle_result fallback from rendering the same
                    # sub-agent content again as the root narrator speaker.
                    self._stream_started = True

    def _handle_result(self, result: ConversationTurnResult) -> None:
        """Handle conversation result."""
        view = self.query_one("#conversation-view", ConversationView)
        self._set_main_input_enabled(True)

        if not result.success:
            self._stream_started = False
            self._clear_run_status()
            view.fail_open_tool_indicators("interrupted")
            view.write(f"\n[red]Error: {result.error}[/]\n")
            view.flush_pending_execution_details()
            self._refresh_status()
            # Always clear the 💭 placeholder on Discord — even when the
            # turn failed — so the remote viewer sees the turn is done
            # rather than being stuck "Thinking…" forever.
            self._emit_bridge_event("turn_status", data={"state": "complete"})
            if self.verbose:
                self._write_verbose_line(f"turn failed: run_id={result.run_id or '-'} error={result.error}")
            return

        if getattr(result, "cancelled", False) is True:
            self._stream_started = False
            self._clear_run_status()
            view._finalize_predicted_tool_indicators(detail="cancelled")
            view.write("[dim]ask_user canceled. Waiting for your next message.[/]\n")
            view.flush_pending_execution_details()
            self._refresh_status()
            self._emit_bridge_event("turn_status", data={"state": "complete"})
            return

        # Note: todo display is now shown inline via _show_tool_result when
        # the TodoWrite callback fires, so we no longer duplicate it here.

        if not self._stream_started:
            fallback_message = getattr(result, "assistant_message", "")
            if isinstance(fallback_message, str) and fallback_message:
                fallback_message = self._normalize_assistant_text(fallback_message)
            if isinstance(fallback_message, str) and fallback_message:
                speaker_hint = str(getattr(result, "assistant_speaker", "") or "").strip()
                speaker = self._get_agent_display_name(speaker_hint) if speaker_hint else self._get_root_speaker_name()
                view.add_named_assistant_message(speaker, fallback_message)
                self._bump_completion_tokens(fallback_message)
        view._finalize_predicted_tool_indicators(detail="not called")
        self._stream_started = False
        view.add_assistant_end()
        view.flush_pending_execution_details()
        self._clear_run_status()
        # Bridge: mark the turn done. If `add_assistant_end` already
        # replaced the 💭 placeholder with a real narration, this is a
        # no-op on the DiscordBridge side. If the turn was silent
        # (all speakers hidden), the placeholder is finalized here.
        self._emit_bridge_event("turn_status", data={"state": "complete"})
        if self.verbose:
            usage = result.usage or {}
            self._write_verbose_line(
                (
                    f"turn ok: run_id={result.run_id} turns={result.turns_used} "
                    f"prompt={usage.get('prompt_tokens', 0)} completion={usage.get('completion_tokens', 0)} "
                    f"tools={len(result.tool_calls_made)} files={len(result.files_modified)}"
                )
            )

        # Update status
        self._refresh_status()

        # Handle proposal in sandbox mode
        if result.proposal and self.session and self.session.mode == "sandbox":
            self._pending_proposal = result.proposal
            view.write("\n[yellow]Proposal ready. Type /apply or 'a' to apply.[/]\n")

            if self.auto_apply:
                self._do_apply()

    def _do_apply(self) -> None:
        """Apply pending proposal."""
        if not self._pending_proposal or not self.session:
            return

        view = self.query_one("#conversation-view", ConversationView)
        view.write("[dim]Applying proposal...[/]\n")

        try:
            from neonrp.core.apply import apply_proposal
            from neonrp.core.proposal import Proposal

            proposal = Proposal.model_validate(self._pending_proposal)
            result = apply_proposal(self.root, proposal, self.session.agent_id)

            if result.success:
                view.write("[green]Proposal applied successfully[/]\n")
                self._pending_proposal = None
                self._refresh_status()
            else:
                view.write(f"[red]Apply failed: {result.error}[/]\n")
        except Exception as e:
            view.write(f"[red]Apply error: {e}[/]\n")

    def _refresh_status(self, include_event_count: bool = True) -> None:
        """Refresh status bar."""
        model_display = self._get_status_model_display()
        world_time, world_location = self._read_world_status_snapshot()
        try:
            input_area = self.query_one("#input-area", InputArea)
        except Exception:
            return
        _ = include_event_count
        input_area.update_status(
            mode=self.session.mode if self.session else self.mode,
            router_mode=self._get_router_mode_status(),
            model_display=model_display,
            world_time=world_time,
            world_location=world_location,
            connection_state=self._get_connection_status_text(),
            prompt_tokens=self._est_prompt_tokens_total,
            completion_tokens=self._est_completion_tokens_total,
        )

    def _read_world_status_snapshot(self) -> tuple[str, str]:
        """Read lightweight world time/location labels for the inline status area."""
        run_state_path = get_game_dir(self.root) / "meta" / "run_state.json"
        if not run_state_path.exists():
            return "-", "-"
        try:
            payload = json.loads(run_state_path.read_text(encoding="utf-8"))
        except Exception:
            return "-", "-"
        if not isinstance(payload, dict):
            return "-", "-"
        return self._format_world_time(payload.get("time")), self._format_world_location(payload.get("location"))

    @staticmethod
    def _format_world_time(raw_time: Any) -> str:
        """Format world time for compact inline display."""
        if not isinstance(raw_time, dict):
            return "-"
        day = raw_time.get("day")
        clock = str(raw_time.get("clock") or "").strip()
        if day in {None, ""} and not clock:
            return "-"
        day_text = f"Day {day}" if day not in {None, ""} else "-"
        if clock:
            return f"{day_text} {clock}".strip()
        return day_text

    def _format_world_location(self, raw_location: Any) -> str:
        """Resolve a compact world location label from run_state location data."""
        if not isinstance(raw_location, dict):
            return "-"

        display = str(raw_location.get("display") or "").strip()
        if display:
            return display.replace("·", "・")

        scope = str(raw_location.get("scope") or "").strip().lower()
        node_id = str(raw_location.get("node_id") or "").strip()
        subnode_id = str(raw_location.get("subnode_id") or raw_location.get("zone") or "").strip()
        if not node_id and not subnode_id:
            return "-"

        if scope == "town" and node_id:
            game_dir = get_game_dir(self.root)
            town_name = node_id
            zone_name = subnode_id
            town_path = game_dir / "towns" / node_id / "town.json"
            town_map_path = game_dir / "towns" / node_id / "town_map.json"
            try:
                if town_path.exists():
                    town_payload = json.loads(town_path.read_text(encoding="utf-8"))
                    if isinstance(town_payload, dict):
                        town_name = str(town_payload.get("name") or town_name).strip() or town_name
                if subnode_id and town_map_path.exists():
                    town_map_payload = json.loads(town_map_path.read_text(encoding="utf-8"))
                    if isinstance(town_map_payload, dict):
                        for node in town_map_payload.get("nodes", []):
                            if isinstance(node, dict) and str(node.get("id") or "").strip() == subnode_id:
                                zone_name = str(node.get("name") or zone_name).strip() or zone_name
                                break
            except Exception:
                pass
            return "・".join(part for part in [town_name, zone_name] if part) or "-"

        return "・".join(part for part in [node_id, subnode_id] if part) or "-"

    def _get_connection_status_text(self) -> str:
        """Build compact connection-status text for inline metadata."""
        mcp_state = "on" if self._mcp_mode and self._mcp_server is not None else "off"
        try:
            from neonrp.core.discord_config import get_discord_inline_status

            discord_state = get_discord_inline_status()
        except Exception:
            discord_state = "off"
        return f"mcp:{mcp_state} discord:{discord_state}"

    def _get_router_mode_status(self) -> str:
        """Return the current router execution mode for compact status display."""
        try:
            return get_router_execution_mode(self.root)
        except Exception:
            return "-"

    def _resolve_ui_locale(self) -> str:
        """Resolve the active TUI locale from config/environment."""
        try:
            configured = load_config(self.root).tui.language
        except Exception:
            configured = "auto"
        return resolve_locale(configured)

    def _get_status_model_display(self) -> str:
        """Build a concise label for the currently effective model."""
        try:
            if self._mcp_mode:
                return "claude-code"
            provider_cfg = self._get_effective_provider_config()
            model_name = (provider_cfg.model or "").strip() or "(default)"
            if len(model_name) > 28:
                model_name = f"{model_name[:25]}..."
            return f"{provider_cfg.provider}:{model_name}"
        except Exception:
            return "unknown"

    @staticmethod
    def _usage_token_pair(usage: dict[str, Any]) -> tuple[int, int]:
        """Extract prompt/completion token counts across provider usage formats."""
        nested = usage.get("usage")
        if isinstance(nested, dict):
            usage = {**nested, **usage}

        prompt_aliases = ("prompt_tokens", "input_tokens", "promptTokenCount")
        completion_aliases = ("completion_tokens", "output_tokens", "completionTokenCount")

        def _to_int(value: Any) -> int:
            try:
                return max(0, int(value or 0))
            except Exception:
                return 0

        prompt = next((_to_int(usage.get(k)) for k in prompt_aliases if usage.get(k) is not None), 0)
        completion = next((_to_int(usage.get(k)) for k in completion_aliases if usage.get(k) is not None), 0)

        # Some providers only return a combined token count.
        if prompt == 0 and completion == 0:
            total = _to_int(usage.get("total_tokens") or usage.get("token_count"))
            if total > 0:
                return total, 0
        return prompt, completion

    def _maybe_add_fallback_token_usage(self, result: ConversationTurnResult) -> None:
        """Estimate token usage when provider doesn't return prompt/completion counts."""
        _ = result
        return

    def action_command_palette(self) -> None:
        """Show command palette."""

        def handle_result(command: str | None) -> None:
            if command:
                self._execute_command(command, [])

        self.push_screen(CommandPalette(), handle_result)

    def action_safe_quit(self) -> None:
        """Quit safely even if an LLM request is in flight.

        Flushes unsaved session messages before exit so that work done
        during a long tool-calling loop is not lost.
        """
        if self.session:
            try:
                self.session.flush()
            except Exception:
                pass
        self.action_quit()

    def action_quit(self) -> None:
        """Quit TUI and return terminal control immediately."""
        self._cancel_active_ask_user()
        self._clear_run_status()
        if self._mcp_server is not None:
            try:
                self._mcp_server.stop()
            except Exception:
                pass
        self.exit()

    def action_copy_transcript(self) -> None:
        """Copy full conversation transcript to clipboard."""
        self._cmd_copy()

    def action_cycle_layer(self) -> None:
        """Cycle transcript visibility between L1 / L2 / L3 (Ctrl+L)."""
        current = getattr(self, "_semantic_layer", 2)
        next_layer = {1: 2, 2: 3, 3: 1}.get(int(current), 2)
        try:
            view = self.query_one("#conversation-view", ConversationView)
            view.set_semantic_layer(next_layer)
        except Exception:
            return
        self._semantic_layer = next_layer
        label = {
            1: "L1 · narrative only",
            2: "L2 · narrative + semantic chips",
            3: "L3 · + raw tool trace",
        }[next_layer]
        try:
            view.write(f"[dim]{label}[/]\n")
        except Exception:
            pass

    def _execute_command(self, command: str, args: list[str]) -> None:
        """Execute a command from palette."""
        command_text = f"/{command}"
        if args:
            command_text = f"{command_text} {' '.join(args)}"
        self._handle_slash_command(command_text)

    def _execute_validate(self, view: ConversationView) -> None:
        """Execute validate command."""
        view.write("[dim]Validating...[/]\n")
        try:
            from neonrp.core.validation import validate_project

            result = validate_project(self.root)
            if result.valid:
                view.write(f"[green]Valid! {len(result.entities)} entities[/]\n")
            else:
                view.write(f"[red]{len(result.errors)} errors[/]\n")
                for error in result.errors[:5]:
                    view.write(f"  [red]- {error}[/]\n")
        except Exception as e:
            view.write(f"[red]Validation failed: {e}[/]\n")

    def _execute_index(self, view: ConversationView, args: list[str]) -> None:
        """Execute index command."""
        view.write("[dim]Building index...[/]\n")
        try:
            from neonrp.core.indexing import build_index

            index = build_index(self.root)
            view.write(f"[green]Indexed {len(index.entities)} entities[/]\n")
        except Exception as e:
            view.write(f"[red]Index failed: {e}[/]\n")


def run_tui(
    root: Path | None = None,
    branch: str | None = None,
    provider: str | None = None,
    continue_session: bool = False,
    startup_commands: list[str] | None = None,
    verbose: bool = False,
    mode: AppMode = "build",
) -> None:
    """Run the TUI."""
    app = NeonRPApp(
        root=root,
        branch=branch,
        provider=provider,
        continue_session=continue_session,
        startup_commands=startup_commands,
        verbose=verbose,
        mode=mode,
    )
    app.run()


def run_worldlines_launcher() -> WorldLinesLaunchSelection | None:
    """Run the public WorldLines launcher flow and return the chosen startup selection."""
    app = WorldLinesLauncherApp()
    app.run()
    return app.launch_selection
