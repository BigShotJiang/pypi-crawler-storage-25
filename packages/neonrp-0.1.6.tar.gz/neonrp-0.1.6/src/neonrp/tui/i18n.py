"""Lightweight TUI localization helpers for L14."""

from __future__ import annotations

import os

Locale = str

# Supported TUI locales.
SUPPORTED_LOCALES: tuple[str, ...] = ("en", "zh", "ja", "ko")

_MESSAGES: dict[str, dict[str, str]] = {
    "en": {
        "input_hint": "Type your message or /command",
        "mode.build": "setup",
        "mode.sandbox": "sandbox",
        "mode.play": "play",
        "mode.mcp": "mcp",
        "mode.setup": "setup",
        "update.available": "Update available",
        "update.up_to_date": "Up to date",
        "update.current": "current",
        "update.latest": "latest",
        "update.channel": "channel",
        "update.apply_prompt": "Upgrade now?",
        "update.skip_version": "Skip this version",
        "update.later": "Not now",
        "menu.continue": "continue saved run",
        "menu.continue_empty": "continue saved run (no saves)",
        "menu.new": "start new run",
        "menu.settings": "settings / api keys",
        "menu.exit": "exit shell",
        "launcher.kicker": "$ worldlines",
        "launcher.subtitle": "> Living agents, AI-driven stories — unknown worlds at your fingertips",
        "launcher.status_ready": "> ready",
        "launcher.shortcuts": "$ keys: ←↑→↓ / tab   enter=confirm   c=continue  n=new  s=settings  esc=quit",
        "launcher.footer": "WorldLines v{version}",
        "picker.choose_world": "Choose World",
        "picker.choose_character": "Choose Character",
        "picker.choose_model": "Select Active Model",
        "picker.continue_game": "Continue Game",
        "worlds.section.builtin": "built-in worlds",
        "worlds.section.create": "create / import",
        "worlds.create": "+  Create new world (AI-authored · `world-game-authoring`)",
        "worlds.import": "↓  Import world (SillyTavern PNG / JSON · `tavern-game-import`)",
        "character.section.saved": "saved characters",
        "character.section.create": "create / import",
        "character.use_default": "Use default character",
        "character.create_ai": "+  Create new character (AI-generated · `player-character-authoring`)",
        "character.create_manual": "+  Create new character (enter fields manually)",
        "character.import_card": "↓  Import character card (SillyTavern PNG / JSON · `character-card-authoring`)",
        "saved.section.runs": "saved runs",
        "saved.section.actions": "actions",
        "saved.export": "↗  Export a saved run to .zip",
        "saved.load": "↙  Load world from .zip",
        "saved.delete": "✗  Delete a saved run…",
        "saved.delete.pick_title": "Delete a saved run",
        "saved.delete.confirm_title": "Confirm delete",
        "saved.delete.confirm_line1": "This will permanently remove:",
        "saved.delete.confirm_warn": "⚠  This cannot be undone.",
        "saved.delete.yes": "✗  Yes, delete permanently",
        "saved.delete.cancel": "←  Cancel (keep the run)",
        "saved.delete.success": "Deleted  ·  {name}",
        "saved.delete.success_count": "Deleted  ·  {count} saved runs",
        "saved.delete.failed": "Delete failed  ·  {error}",
        "saved.delete.select_hint": "tap rows to toggle — nothing deleted until you confirm below",
        "saved.delete.action_selected": "✗  Delete {count} selected",
        "prompt.zip_path": "Path to worldlines .zip",
        "prompt.world_create_desc": "Describe the world you want (one line — e.g. steampunk desert city-state where water is currency)",
        "prompt.world_import_path": "Path: SillyTavern PNG / JSON file (absolute path)",
        "prompt.character_create_desc": "One-line character description (e.g. 15-year-old vampire girl, skilled with a sword, hates garlic)",
        "prompt.character_name": "Character name",
        "prompt.character_summary": "Short summary (1–2 sentences, optional)",
        "prompt.character_backstory": "Personality / backstory (optional — the LLM will fill in)",
        "prompt.character_import_path": "Tavern character card path (PNG / JSON absolute path)",
        "export.success": "Exported  ·  {files} files  ·  {mb} MB",
        "load.success": "Loaded world folder: {path}",
        "handoff.start_game": (
            "Start the game.\n\n"
            "Language: English. All narration, dialogue, NPC lines, and "
            "`ask_user` options must be written in English for the entire "
            "session, regardless of what language the player types later."
        ),
        "handoff.world_create": (
            "Use the built-in skill `world-game-authoring` to design the game/ folder.\n\n"
            "User context:\n{prompt}\n\n"
            "First write a short plan, then ask the user to confirm scope before writing any files."
        ),
        "handoff.world_import": (
            "Use the built-in skill `tavern-game-import`.\n\n"
            "Source path: {path}\n\n"
            "Read the card first, classify the content, ask about ambiguous design choices, "
            "then author the minimal playable slice."
        ),
        "handoff.character_create": (
            "Use the built-in skill `player-character-authoring` to update the player/ folder.\n\n"
            "User description:\n{prompt}"
        ),
        "handoff.character_import": (
            "Use the built-in skill `character-card-authoring` to import the tavern character "
            "card at `{path}` into game/player/."
        ),
        "handoff.character_adapt": (
            "A saved persona from ~/.worldlines/players/ has been seeded into game/player/player.json "
            "with the basic fields (name, summary, personality, appearance, backstory). "
            "Use the built-in skill `player-character-authoring` to read the template's expected schema "
            "(e.g. stats, location, inventory, flags specific to this world) and translate the persona "
            "into the fields this game actually needs. Persona JSON:\n{persona_json}"
        ),
        "discord_setup.title": "Discord bridge — setup wizard",
        "discord_setup.welcome": (
            "This wizard walks you through connecting this game to Discord.\n\n"
            "You'll need: (1) a Discord account, (2) a server where you have "
            "Manage Server permission, (3) 5 minutes.\n\n"
            "Steps:\n"
            "  1) Create a Discord Application + Bot at discord.com/developers\n"
            "  2) Paste the Application ID, Bot Token, and target Channel ID here\n"
            "  3) Invite the bot to your server via the generated OAuth URL\n"
            "  4) Test the connection (optional)\n\n"
            "You can skip any step and come back later."
        ),
        "discord_setup.begin": "Start setup",
        "discord_setup.portal": "Open discord.com/developers in browser",
        "discord_setup.app_id_prompt": "Application ID (from developer portal)",
        "discord_setup.token_prompt": "Bot token (keep this secret!)",
        "discord_setup.channel_prompt": "Channel ID (right-click channel → Copy Channel ID)",
        "discord_setup.guild_prompt": "Guild ID (server — optional, right-click server icon)",
        "discord_setup.invite_url_title": "Bot invite URL — paste in browser",
        "discord_setup.test_connection": "Test connection",
        "discord_setup.enable_autostart": "Auto-start bridge with worldlines",
        "discord_setup.status": "Status",
        "discord_setup.skip": "Skip — back to settings",
        "discord_setup.complete": "Setup complete",
        "mcp_auth.title": "Claude Code — authorization required",
        "mcp_auth.body": (
            "MCP mode uses Claude Code as the storyteller. The narrator needs to "
            "write to files under this game's folder (game/, .neonrp/) on every "
            "turn — state deltas, journal entries, NPC memories.\n\n"
            "Because `claude -p` runs non-interactively, we need to pre-authorize "
            "those writes. A scoped allowlist will be written to the sibling "
            "`.claude/settings.local.json`.\n\n"
            "Grant access?  (You can revoke later by deleting "
            "`~/.neonrp/config.json` → `mcp.authorized_at`.)"
        ),
        "mcp_auth.grant": "✓  Grant full write access to this game's workspace",
        "mcp_auth.cancel": "✗  Cancel — pick a different model",
        "settings.title": "Settings",
        "settings.configured": "Configured",
        "settings.add_new": "Add new provider",
        "settings.language": "Language / 语言 / 言語 / 언어",
        "settings.discord": "Discord bridge",
        "settings.config_path": "Show config file path",
        "settings.test": "Test",
        "settings.edit": "Edit",
        "settings.delete": "Delete",
        "settings.back": "Back",
        "settings.test_ok": "OK",
        "settings.test_fail": "FAIL",
        "settings.provider.anthropic": "Anthropic (Claude)",
        "settings.provider.openai": "OpenAI (GPT)",
        "settings.provider.deepseek": "DeepSeek",
        "settings.provider.openrouter": "OpenRouter",
        "settings.provider.custom": "Custom (OpenAI-compatible)",
        "settings.provider.mcp": "Claude Code (MCP)",
        "prompt.api_key": "Paste API key (leave blank to cancel)",
        "prompt.model_id": "Model id",
        "prompt.base_url": "Base URL",
        "prompt.entry_id": "Config id (e.g. {example})",
        "preset.badge.custom": "custom",
        "preset.add_custom": "+  Add new custom provider (Qwen / Ollama / OpenAI-compatible…)",
        "choice.use": "Use this",
        "choice.edit": "Edit before use",
        "choice.cancel": "Cancel",
        "ui.hint.picker_default": "↑↓←→ select · Enter confirm · Esc back",
        "ui.hint.picker_expand": "↑↓ select · Enter view full · Esc close",
        "ui.hint.text_input_default": "Enter save · Esc cancel",
        "ui.hint.esc_cancel": "Esc cancel",
        "ui.hint.esc_cancel_enter_submit": "Esc cancel · Enter submit",
        "ask_user.placeholder": "Type your reply (Enter to submit)...",
        "ask_user.waiting_choice": "Waiting for ask_user choice...",
        "ask_user.cancelled": "(cancelled)",
        "player.default_name": "Protagonist",
        "upgrade.success": "Upgrade complete — please restart neonrp / worldlines.",
        "upgrade.failed": "Upgrade failed — see output above.",
        "update.launch_banner": "↑ New version available: {current} → {latest} ({channel})",
        "update.launch_release_notes": "Release notes: {url}",
        "update.launch_editable_blocked": "Source / editable install — auto-upgrade is disabled, only notifying at launch.",
        "update.launch_choice_prompt": "Upgrade?  [y] upgrade  /  [s] skip this version  /  [n] later",
        "update.launch_failed": "Upgrade failed — continuing with the current version.",
        "update.launch_skipped": "Skipped {version} — we'll ask again on the next update.",
        "preset.api_key_needed": "{display} requires an API key",
        "preset.api_key_get_at": "Get one at: https://{url}",
        "preset.api_key_saved": "Saved — you won't need to paste this again next launch.",
    },
    "zh": {
        "input_hint": "输入消息或 /命令",
        "mode.build": "构建",
        "mode.sandbox": "沙盒",
        "mode.play": "游玩",
        "mode.mcp": "MCP",
        "mode.setup": "设置",
        "update.available": "有新版本可用",
        "update.up_to_date": "已是最新",
        "update.current": "当前",
        "update.latest": "最新",
        "update.channel": "通道",
        "update.apply_prompt": "现在升级吗？",
        "update.skip_version": "跳过此版本",
        "update.later": "稍后再说",
        "menu.continue": "继续已保存的游戏",
        "menu.continue_empty": "继续（暂无存档）",
        "menu.new": "开始新的游戏",
        "menu.settings": "设置 / API Key",
        "menu.exit": "退出",
        "launcher.kicker": "$ worldlines",
        "launcher.subtitle": "> 鲜活的 Agent 驱动的 AI 故事，未知世界就在眼前",
        "launcher.status_ready": "> 就绪",
        "launcher.shortcuts": "$ 按键： ←↑→↓ / tab   enter=确认   c=继续  n=新建  s=设置  esc=退出",
        "launcher.footer": "WorldLines v{version}",
        "picker.choose_world": "选择世界",
        "picker.choose_character": "选择角色",
        "picker.choose_model": "选择模型",
        "picker.continue_game": "继续游戏",
        "worlds.section.builtin": "内置世界",
        "worlds.section.create": "新建 / 导入",
        "worlds.create": "+  新建世界（AI 生成 · `world-game-authoring`）",
        "worlds.import": "↓  导入世界（SillyTavern PNG / JSON · `tavern-game-import`）",
        "character.section.saved": "已保存角色",
        "character.section.create": "新建 / 导入",
        "character.use_default": "使用默认角色",
        "character.create_ai": "+  新建角色（AI 生成 · `player-character-authoring`）",
        "character.create_manual": "+  手动填写创建角色",
        "character.import_card": "↓  导入酒馆角色卡（SillyTavern PNG / JSON · `character-card-authoring`）",
        "saved.section.runs": "已保存的游戏",
        "saved.section.actions": "操作",
        "saved.export": "↗  导出存档为 .zip",
        "saved.load": "↙  从 .zip 载入世界",
        "saved.delete": "✗  删除存档…",
        "saved.delete.pick_title": "删除存档",
        "saved.delete.confirm_title": "确认删除",
        "saved.delete.confirm_line1": "即将永久删除：",
        "saved.delete.confirm_warn": "⚠  操作不可撤销。",
        "saved.delete.yes": "✗  确认永久删除",
        "saved.delete.cancel": "←  取消（保留存档）",
        "saved.delete.success": "已删除  ·  {name}",
        "saved.delete.success_count": "已删除  ·  {count} 个存档",
        "saved.delete.failed": "删除失败  ·  {error}",
        "saved.delete.select_hint": "点击行可切换勾选 — 点下方按钮才真正删除",
        "saved.delete.action_selected": "✗  删除已选中的 {count} 个",
        "prompt.zip_path": "worldlines .zip 文件路径",
        "prompt.world_create_desc": "描述你想要的世界（一句话即可 — 例：蒸汽朋克沙漠城邦，水资源是硬通货）",
        "prompt.world_import_path": "路径：SillyTavern PNG / JSON 文件绝对路径",
        "prompt.character_create_desc": "一句话描述角色（例：十五岁吸血鬼少女，擅长刀术，讨厌大蒜）",
        "prompt.character_name": "角色名",
        "prompt.character_summary": "简介（一两句话，可留空）",
        "prompt.character_backstory": "性格 / 背景（可留空，LLM 会补全）",
        "prompt.character_import_path": "酒馆角色卡文件路径（PNG / JSON 绝对路径）",
        "export.success": "已导出  ·  {files} 个文件  ·  {mb} MB",
        "load.success": "已载入：{path}",
        "handoff.start_game": (
            "开始游戏。\n\n"
            "语言：简体中文。整个 session 的叙事、对话、NPC 台词以及所有 "
            "`ask_user` 选项都必须使用简体中文，无论玩家之后用什么语言输入。"
        ),
        "handoff.world_create": (
            "使用内置 skill `world-game-authoring` 设计 game/ 文件夹。\n\n"
            "用户需求：\n{prompt}\n\n"
            "先写一段简要方案，等用户确认范围后再开始写文件。"
        ),
        "handoff.world_import": (
            "使用内置 skill `tavern-game-import`。\n\n"
            "源文件路径：{path}\n\n"
            "先读取卡片内容，对内容分类，就不明确的设计点问用户，再产出最小可玩切片。"
        ),
        "handoff.character_create": (
            "使用内置 skill `player-character-authoring` 更新 game/player/ 文件夹。\n\n"
            "用户描述：\n{prompt}"
        ),
        "handoff.character_import": (
            "使用内置 skill `character-card-authoring` 把 `{path}` 的酒馆角色卡导入到 game/player/。"
        ),
        "handoff.character_adapt": (
            "已从 ~/.worldlines/players/ 载入一份玩家档案，基础字段（name / summary / personality / appearance / backstory）"
            "已写入 game/player/player.json。请使用内置 skill `player-character-authoring` 读取 template 的"
            "player.json schema（如 stats、location、inventory、本世界专属的 flag 等），把 persona 翻译 / 适配成这个游戏实际需要的字段。"
            "Persona JSON：\n{persona_json}"
        ),
        "discord_setup.title": "Discord 桥接 — 设置向导",
        "discord_setup.welcome": (
            "本向导引导你把这个游戏连接到 Discord。\n\n"
            "你需要：(1) Discord 账号，(2) 在某个服务器有「管理服务器」权限，(3) 5 分钟。\n\n"
            "步骤：\n"
            "  1) 在 discord.com/developers 创建 Application + Bot\n"
            "  2) 把 Application ID、Bot Token、频道 ID 填到这里\n"
            "  3) 用生成的 OAuth 链接把 bot 拉进你的服务器\n"
            "  4) 测试连接（可选）\n\n"
            "每一步都可以跳过，之后再回来继续。"
        ),
        "discord_setup.begin": "开始设置",
        "discord_setup.portal": "在浏览器打开 discord.com/developers",
        "discord_setup.app_id_prompt": "Application ID（开发者门户）",
        "discord_setup.token_prompt": "Bot Token（保密，不要泄露！）",
        "discord_setup.channel_prompt": "频道 ID（右键频道 → Copy Channel ID）",
        "discord_setup.guild_prompt": "服务器 ID（可选，右键服务器图标）",
        "discord_setup.invite_url_title": "Bot 邀请链接 — 粘贴到浏览器打开",
        "discord_setup.test_connection": "测试连接",
        "discord_setup.enable_autostart": "启动时自动连 Discord",
        "discord_setup.status": "状态",
        "discord_setup.skip": "跳过 — 返回设置",
        "discord_setup.complete": "设置完成",
        "mcp_auth.title": "Claude Code — 需要授权",
        "mcp_auth.body": (
            "MCP 模式下 Claude Code 作为叙事 agent 来运行。"
            "每回合都需要写这个游戏目录下的文件（game/、.neonrp/）— 状态变化、journal、NPC 记忆。\n\n"
            "因为 `claude -p` 是非交互 subprocess，必须预先授权这些写入。"
            "会在同级的 `.claude/settings.local.json` 里写一份精确范围的 allowlist。\n\n"
            "允许吗？  （今后可以删除 `~/.neonrp/config.json` 里的 "
            "`mcp.authorized_at` 来撤销。）"
        ),
        "mcp_auth.grant": "✓  授权写入本游戏的 workspace",
        "mcp_auth.cancel": "✗  取消 — 换别的模型",
        "settings.title": "设置",
        "settings.configured": "已配置",
        "settings.add_new": "添加新配置",
        "settings.language": "语言 / Language",
        "settings.discord": "Discord 桥接",
        "settings.config_path": "显示配置文件路径",
        "settings.test": "测试",
        "settings.edit": "编辑",
        "settings.delete": "删除",
        "settings.back": "返回",
        "settings.test_ok": "可用",
        "settings.test_fail": "失败",
        "settings.provider.anthropic": "Anthropic（Claude）",
        "settings.provider.openai": "OpenAI（GPT）",
        "settings.provider.deepseek": "DeepSeek",
        "settings.provider.openrouter": "OpenRouter",
        "settings.provider.custom": "自定义（OpenAI 兼容端点）",
        "settings.provider.mcp": "Claude Code（MCP）",
        "prompt.api_key": "粘贴 API Key（留空取消）",
        "prompt.model_id": "模型 id",
        "prompt.base_url": "API 基础 URL",
        "prompt.entry_id": "配置 id（例如：{example}）",
        "preset.badge.custom": "自定义",
        "preset.add_custom": "+  新增自定义 provider（Qwen / Ollama / OpenAI 兼容…）",
        "choice.use": "使用",
        "choice.edit": "编辑后使用",
        "choice.cancel": "取消",
        "ui.hint.picker_default": "↑↓←→ 选择 · Enter 确认 · Esc 返回",
        "ui.hint.picker_expand": "↑↓ 选择 · Enter 查看完整内容 · Esc 关闭",
        "ui.hint.text_input_default": "Enter 保存 · Esc 取消",
        "ui.hint.esc_cancel": "Esc 取消",
        "ui.hint.esc_cancel_enter_submit": "Esc 取消 · Enter 提交",
        "ask_user.placeholder": "输入你的回复（Enter 提交）...",
        "ask_user.waiting_choice": "等待 ask_user 选择...",
        "ask_user.cancelled": "(已取消)",
        "player.default_name": "主角",
        "upgrade.success": "升级完成，请重启 neonrp / worldlines。",
        "upgrade.failed": "升级失败，详见上面输出。",
        "update.launch_banner": "↑ 有新版本可用：{current} → {latest}（{channel}）",
        "update.launch_release_notes": "Release notes：{url}",
        "update.launch_editable_blocked": "当前是源码/editable 模式，自动升级已禁用，启动时仅提示。",
        "update.launch_choice_prompt": "升级吗？[y] 升级 / [s] 跳过此版本 / [n] 稍后再说",
        "update.launch_failed": "升级失败；继续使用当前版本启动。",
        "update.launch_skipped": "已跳过 {version}；下次有更新再提示。",
        "preset.api_key_needed": "{display} 需要 API Key",
        "preset.api_key_get_at": "获取地址：https://{url}",
        "preset.api_key_saved": "已保存，下次启动无需再次输入。",
    },
    "ja": {
        "input_hint": "メッセージか /コマンド を入力",
        "mode.build": "構築",
        "mode.sandbox": "サンドボックス",
        "mode.play": "プレイ",
        "mode.mcp": "MCP",
        "mode.setup": "設定",
        "update.available": "アップデートがあります",
        "update.up_to_date": "最新版です",
        "update.current": "現在",
        "update.latest": "最新",
        "update.channel": "チャンネル",
        "update.apply_prompt": "今すぐ更新しますか？",
        "update.skip_version": "このバージョンをスキップ",
        "update.later": "あとで",
        "menu.continue": "セーブデータを続ける",
        "menu.continue_empty": "続き（セーブなし）",
        "menu.new": "新しく始める",
        "menu.settings": "設定 / APIキー",
        "menu.exit": "終了",
        "launcher.kicker": "$ worldlines",
        "launcher.subtitle": "> 生き生きしたAgentによってAI駆動の物語を未知の世界は眼の前に、",
        "launcher.status_ready": "> 準備完了",
        "launcher.shortcuts": "$ キー： ←↑→↓ / tab   enter=決定   c=続き  n=新規  s=設定  esc=終了",
        "launcher.footer": "WorldLines v{version}",
        "picker.choose_world": "ワールド選択",
        "picker.choose_character": "キャラクター選択",
        "picker.choose_model": "モデル選択",
        "picker.continue_game": "続きから",
        "worlds.section.builtin": "内蔵ワールド",
        "worlds.section.create": "作成 / インポート",
        "worlds.create": "+  新しいワールドを作る（AI生成 · `world-game-authoring`）",
        "worlds.import": "↓  ワールドをインポート（SillyTavern PNG / JSON · `tavern-game-import`）",
        "character.section.saved": "保存済みキャラクター",
        "character.section.create": "作成 / インポート",
        "character.use_default": "デフォルトキャラを使う",
        "character.create_ai": "+  新しいキャラを作る（AI生成 · `player-character-authoring`）",
        "character.create_manual": "+  キャラを手動で作成",
        "character.import_card": "↓  Tavernキャラカードをインポート（SillyTavern PNG / JSON · `character-card-authoring`）",
        "saved.section.runs": "保存済みのゲーム",
        "saved.section.actions": "操作",
        "saved.export": "↗  セーブを .zip にエクスポート",
        "saved.load": "↙  .zip からワールドを読み込む",
        "saved.delete": "✗  セーブを削除…",
        "saved.delete.pick_title": "セーブを削除",
        "saved.delete.confirm_title": "削除の確認",
        "saved.delete.confirm_line1": "以下を完全に削除します：",
        "saved.delete.confirm_warn": "⚠  この操作は元に戻せません。",
        "saved.delete.yes": "✗  削除を実行する",
        "saved.delete.cancel": "←  キャンセル（セーブを残す）",
        "saved.delete.success": "削除しました  ·  {name}",
        "saved.delete.success_count": "削除しました  ·  {count} 件",
        "saved.delete.failed": "削除失敗  ·  {error}",
        "saved.delete.select_hint": "行をタップで選択切り替え — 下のボタンを押すまで削除されません",
        "saved.delete.action_selected": "✗  選択した {count} 件を削除",
        "prompt.zip_path": "worldlines .zip のパス",
        "prompt.world_create_desc": "作りたいワールドを一言で（例：水が通貨のスチームパンク砂漠都市国家）",
        "prompt.world_import_path": "パス：SillyTavern PNG / JSON ファイルの絶対パス",
        "prompt.character_create_desc": "キャラクターを一言で（例：15歳の吸血鬼少女、剣術に長け、にんにくが嫌い）",
        "prompt.character_name": "キャラクター名",
        "prompt.character_summary": "簡単な紹介（1〜2文、任意）",
        "prompt.character_backstory": "性格 / 背景（任意 — LLM が補完します）",
        "prompt.character_import_path": "Tavern キャラカードのパス（PNG / JSON 絶対パス）",
        "export.success": "エクスポート完了  ·  {files} ファイル  ·  {mb} MB",
        "load.success": "読み込み完了：{path}",
        "handoff.start_game": (
            "ゲームを始めてください。\n\n"
            "言語：日本語。ナレーション・会話・NPC のセリフ・`ask_user` の選択肢は"
            "すべて日本語で出力してください。プレイヤーが後で別言語で入力しても、"
            "出力言語は日本語のまま維持してください。"
        ),
        "handoff.world_create": (
            "以下のコンテキストに従って `world-game-authoring` skill で game/ folder を設計する。\n\n"
            "ユーザーの希望：\n{prompt}\n\n"
            "先に短い計画案を書き、ユーザーに範囲を確認してからファイル作成を始めること。"
        ),
        "handoff.world_import": (
            "内蔵 skill `tavern-game-import` を使う。\n\n"
            "ソースパス：{path}\n\n"
            "まずカードを読み、内容を分類し、不明な設計点をユーザーに確認してから最小プレイアブル・スライスを作成する。"
        ),
        "handoff.character_create": (
            "内蔵 skill `player-character-authoring` で player の folder を更新する。\n\n"
            "ユーザーの説明：\n{prompt}"
        ),
        "handoff.character_import": (
            "内蔵 skill `character-card-authoring` で、Tavern キャラカード `{path}` を game/player/ にインポートする。"
        ),
        "handoff.character_adapt": (
            "~/.worldlines/players/ から保存済みペルソナを読み込み、基本項目（name / summary / personality / appearance / backstory）を "
            "game/player/player.json に書き込みました。内蔵 skill `player-character-authoring` で template の player.json の "
            "schema（stats・location・inventory・本ワールド固有のフラグなど）を確認し、ペルソナをこのゲームが実際に必要とする項目へ"
            "翻訳・適応させてください。Persona JSON：\n{persona_json}"
        ),
        "discord_setup.title": "Discord ブリッジ — セットアップウィザード",
        "discord_setup.welcome": (
            "このゲームを Discord に接続する手順を案内します。\n\n"
            "必要なもの：(1) Discord アカウント、(2) 「サーバー管理」権限を持つサーバー、(3) 5 分間。\n\n"
            "ステップ：\n"
            "  1) discord.com/developers で Application + Bot を作成\n"
            "  2) Application ID、Bot Token、チャンネル ID をここに貼り付け\n"
            "  3) 生成された OAuth リンクで bot をサーバーに招待\n"
            "  4) 接続テスト（任意）\n\n"
            "どのステップもスキップ可能、あとで続行できます。"
        ),
        "discord_setup.begin": "セットアップ開始",
        "discord_setup.portal": "ブラウザで discord.com/developers を開く",
        "discord_setup.app_id_prompt": "Application ID（開発者ポータル）",
        "discord_setup.token_prompt": "Bot Token（秘匿、他人に見せない！）",
        "discord_setup.channel_prompt": "チャンネル ID（チャンネル右クリック → Copy Channel ID）",
        "discord_setup.guild_prompt": "サーバー ID（任意、サーバーアイコン右クリック）",
        "discord_setup.invite_url_title": "Bot 招待 URL — ブラウザに貼り付け",
        "discord_setup.test_connection": "接続テスト",
        "discord_setup.enable_autostart": "起動時に自動接続",
        "discord_setup.status": "ステータス",
        "discord_setup.skip": "スキップ — 設定に戻る",
        "discord_setup.complete": "セットアップ完了",
        "mcp_auth.title": "Claude Code — 認証が必要",
        "mcp_auth.body": (
            "MCPモードでは Claude Code が語り手として動きます。"
            "毎ターン、このゲームフォルダ内のファイル（game/、.neonrp/）に書き込みます — "
            "状態の変化、ジャーナル、NPCの記憶など。\n\n"
            "`claude -p` は非対話型 subprocess なので、書き込みを事前に許可する必要があります。"
            "隣接する `.claude/settings.local.json` に範囲を絞った allowlist を書き込みます。\n\n"
            "許可しますか？ （`~/.neonrp/config.json` の `mcp.authorized_at` を削除すれば撤回できます。）"
        ),
        "mcp_auth.grant": "✓  このゲームのワークスペースへの書き込みを許可",
        "mcp_auth.cancel": "✗  キャンセル — 別のモデルを選ぶ",
        "settings.title": "設定",
        "settings.configured": "設定済み",
        "settings.add_new": "新しいプロバイダを追加",
        "settings.language": "言語 / Language",
        "settings.discord": "Discord ブリッジ",
        "settings.config_path": "設定ファイルのパス",
        "settings.test": "テスト",
        "settings.edit": "編集",
        "settings.delete": "削除",
        "settings.back": "戻る",
        "settings.test_ok": "OK",
        "settings.test_fail": "失敗",
        "settings.provider.anthropic": "Anthropic（Claude）",
        "settings.provider.openai": "OpenAI（GPT）",
        "settings.provider.deepseek": "DeepSeek",
        "settings.provider.openrouter": "OpenRouter",
        "settings.provider.custom": "カスタム（OpenAI 互換エンドポイント）",
        "settings.provider.mcp": "Claude Code（MCP）",
        "prompt.api_key": "APIキーを貼り付け（空でキャンセル）",
        "prompt.model_id": "モデル id",
        "prompt.base_url": "ベース URL",
        "prompt.entry_id": "設定 id（例：{example}）",
        "preset.badge.custom": "カスタム",
        "preset.add_custom": "+  カスタム provider を追加（Qwen / Ollama / OpenAI 互換…）",
        "choice.use": "使う",
        "choice.edit": "編集してから使う",
        "choice.cancel": "キャンセル",
        "ui.hint.picker_default": "↑↓←→ 選択 · Enter 決定 · Esc 戻る",
        "ui.hint.picker_expand": "↑↓ 選択 · Enter 全文表示 · Esc 閉じる",
        "ui.hint.text_input_default": "Enter 保存 · Esc キャンセル",
        "ui.hint.esc_cancel": "Esc キャンセル",
        "ui.hint.esc_cancel_enter_submit": "Esc キャンセル · Enter 送信",
        "ask_user.placeholder": "返信を入力してください（Enter で送信）...",
        "ask_user.waiting_choice": "ask_user の選択待ち...",
        "ask_user.cancelled": "(キャンセル)",
        "player.default_name": "主人公",
        "upgrade.success": "アップグレード完了。neonrp / worldlines を再起動してください。",
        "upgrade.failed": "アップグレード失敗。上の出力を確認してください。",
        "update.launch_banner": "↑ 新しいバージョンがあります：{current} → {latest}（{channel}）",
        "update.launch_release_notes": "Release notes：{url}",
        "update.launch_editable_blocked": "ソース / editable インストール — 自動アップグレードは無効、起動時の通知のみ。",
        "update.launch_choice_prompt": "アップグレードしますか？[y] アップグレード / [s] このバージョンをスキップ / [n] あとで",
        "update.launch_failed": "アップグレード失敗 — 現在のバージョンのまま起動します。",
        "update.launch_skipped": "{version} をスキップしました — 次回の更新で再度お知らせします。",
        "preset.api_key_needed": "{display} には API Key が必要です",
        "preset.api_key_get_at": "取得先：https://{url}",
        "preset.api_key_saved": "保存しました。次回以降は入力不要です。",
    },
    "ko": {
        "input_hint": "메시지 또는 /명령어 입력",
        "mode.build": "빌드",
        "mode.sandbox": "샌드박스",
        "mode.play": "플레이",
        "mode.mcp": "MCP",
        "mode.setup": "설정",
        "update.available": "업데이트가 있습니다",
        "update.up_to_date": "최신 상태",
        "update.current": "현재",
        "update.latest": "최신",
        "update.channel": "채널",
        "update.apply_prompt": "지금 업그레이드할까요?",
        "update.skip_version": "이 버전 건너뛰기",
        "update.later": "나중에",
        "menu.continue": "저장된 게임 계속하기",
        "menu.continue_empty": "계속 (저장 없음)",
        "menu.new": "새 게임 시작",
        "menu.settings": "설정 / API Key",
        "menu.exit": "종료",
        "launcher.kicker": "$ worldlines",
        "launcher.subtitle": "> 생생한 Agent가 이끄는 AI 이야기, 미지의 세계가 눈앞에",
        "launcher.status_ready": "> 준비됨",
        "launcher.shortcuts": "$ 키: ←↑→↓ / tab   enter=확인   c=계속  n=새로  s=설정  esc=종료",
        "launcher.footer": "WorldLines v{version}",
        "picker.choose_world": "월드 선택",
        "picker.choose_character": "캐릭터 선택",
        "picker.choose_model": "모델 선택",
        "picker.continue_game": "계속하기",
        "worlds.section.builtin": "내장 월드",
        "worlds.section.create": "만들기 / 가져오기",
        "worlds.create": "+  새 월드 만들기 (AI 생성 · `world-game-authoring`)",
        "worlds.import": "↓  월드 가져오기 (SillyTavern PNG / JSON · `tavern-game-import`)",
        "character.section.saved": "저장된 캐릭터",
        "character.section.create": "만들기 / 가져오기",
        "character.use_default": "기본 캐릭터 사용",
        "character.create_ai": "+  새 캐릭터 만들기 (AI 생성 · `player-character-authoring`)",
        "character.create_manual": "+  수동으로 캐릭터 만들기",
        "character.import_card": "↓  Tavern 캐릭터 카드 가져오기 (SillyTavern PNG / JSON · `character-card-authoring`)",
        "saved.section.runs": "저장된 게임",
        "saved.section.actions": "작업",
        "saved.export": "↗  저장 게임을 .zip 으로 내보내기",
        "saved.load": "↙  .zip 에서 월드 불러오기",
        "saved.delete": "✗  저장 게임 삭제…",
        "saved.delete.pick_title": "저장 게임 삭제",
        "saved.delete.confirm_title": "삭제 확인",
        "saved.delete.confirm_line1": "다음을 영구 삭제합니다:",
        "saved.delete.confirm_warn": "⚠  이 작업은 되돌릴 수 없습니다.",
        "saved.delete.yes": "✗  영구 삭제",
        "saved.delete.cancel": "←  취소 (저장 게임 유지)",
        "saved.delete.success": "삭제됨  ·  {name}",
        "saved.delete.success_count": "삭제됨  ·  {count} 개",
        "saved.delete.failed": "삭제 실패  ·  {error}",
        "saved.delete.select_hint": "행 탭으로 선택 전환 — 아래 버튼을 눌러야 실제 삭제",
        "saved.delete.action_selected": "✗  선택한 {count} 개 삭제",
        "prompt.zip_path": "worldlines .zip 경로",
        "prompt.world_create_desc": "원하는 월드를 한 줄로 (예: 물이 화폐인 스팀펑크 사막 도시국가)",
        "prompt.world_import_path": "경로: SillyTavern PNG / JSON 파일 (절대경로)",
        "prompt.character_create_desc": "캐릭터를 한 줄로 (예: 검술에 능한 15세 흡혈귀 소녀, 마늘을 싫어함)",
        "prompt.character_name": "캐릭터 이름",
        "prompt.character_summary": "짧은 소개 (1~2 문장, 선택)",
        "prompt.character_backstory": "성격 / 배경 (선택 — LLM이 보완합니다)",
        "prompt.character_import_path": "Tavern 캐릭터 카드 경로 (PNG / JSON 절대경로)",
        "export.success": "내보내기 완료  ·  {files} 파일  ·  {mb} MB",
        "load.success": "불러오기 완료: {path}",
        "handoff.start_game": (
            "게임을 시작합니다.\n\n"
            "언어: 한국어. 서술·대화·NPC 대사·`ask_user` 선택지는 모두 한국어로 "
            "작성해 주세요. 플레이어가 이후에 다른 언어로 입력하더라도 출력 언어는 "
            "한국어로 유지해 주세요."
        ),
        "handoff.world_create": (
            "내장 skill `world-game-authoring`을 사용하여 game/ 폴더를 설계합니다.\n\n"
            "사용자 요청:\n{prompt}\n\n"
            "먼저 짧은 계획을 쓰고, 사용자에게 범위를 확인받은 다음 파일 작성을 시작합니다."
        ),
        "handoff.world_import": (
            "내장 skill `tavern-game-import`을 사용합니다.\n\n"
            "소스 경로: {path}\n\n"
            "먼저 카드를 읽고 내용을 분류하며, 애매한 디자인 부분은 사용자에게 확인한 후 최소 플레이 가능 슬라이스를 작성합니다."
        ),
        "handoff.character_create": (
            "내장 skill `player-character-authoring`을 사용해 game/player/ 폴더를 업데이트합니다.\n\n"
            "사용자 설명:\n{prompt}"
        ),
        "handoff.character_import": (
            "내장 skill `character-card-authoring`을 사용해 Tavern 캐릭터 카드 `{path}` 를 game/player/ 에 가져옵니다."
        ),
        "handoff.character_adapt": (
            "~/.worldlines/players/ 의 저장된 페르소나가 game/player/player.json 에 기본 필드(name / summary / personality / "
            "appearance / backstory)로 주입되었습니다. 내장 skill `player-character-authoring`을 사용해 템플릿 player.json 의 "
            "schema(stats, location, inventory, 이 월드 고유 플래그 등)를 읽고, 페르소나를 이 게임이 실제로 요구하는 필드로 "
            "번역 / 적응시켜 주세요. Persona JSON:\n{persona_json}"
        ),
        "discord_setup.title": "Discord 브리지 — 설정 마법사",
        "discord_setup.welcome": (
            "이 마법사는 게임을 Discord에 연결하는 과정을 안내합니다.\n\n"
            "필요한 것: (1) Discord 계정, (2) '서버 관리' 권한이 있는 서버, (3) 5분.\n\n"
            "단계:\n"
            "  1) discord.com/developers 에서 Application + Bot 생성\n"
            "  2) Application ID, Bot Token, 채널 ID 를 여기에 붙여넣기\n"
            "  3) 생성된 OAuth 링크로 bot 을 서버에 초대\n"
            "  4) 연결 테스트 (선택)\n\n"
            "어떤 단계든 건너뛰고 나중에 돌아와 이어갈 수 있습니다."
        ),
        "discord_setup.begin": "설정 시작",
        "discord_setup.portal": "브라우저에서 discord.com/developers 열기",
        "discord_setup.app_id_prompt": "Application ID (개발자 포털)",
        "discord_setup.token_prompt": "Bot Token (비밀, 공개 금지!)",
        "discord_setup.channel_prompt": "채널 ID (채널 우클릭 → Copy Channel ID)",
        "discord_setup.guild_prompt": "서버 ID (선택, 서버 아이콘 우클릭)",
        "discord_setup.invite_url_title": "Bot 초대 URL — 브라우저에 붙여넣기",
        "discord_setup.test_connection": "연결 테스트",
        "discord_setup.enable_autostart": "실행 시 자동 연결",
        "discord_setup.status": "상태",
        "discord_setup.skip": "건너뛰기 — 설정으로",
        "discord_setup.complete": "설정 완료",
        "mcp_auth.title": "Claude Code — 권한이 필요합니다",
        "mcp_auth.body": (
            "MCP 모드에서는 Claude Code가 내레이터로 동작합니다. "
            "매 턴마다 이 게임 폴더의 파일(game/, .neonrp/)을 수정합니다 — "
            "상태 변화, 저널, NPC 기억 등.\n\n"
            "`claude -p`는 비대화형 subprocess이므로 쓰기 권한을 미리 승인해야 합니다. "
            "인접한 `.claude/settings.local.json`에 범위가 제한된 allowlist가 기록됩니다.\n\n"
            "허용하시겠습니까? (`~/.neonrp/config.json`의 `mcp.authorized_at`을 삭제하면 취소할 수 있습니다.)"
        ),
        "mcp_auth.grant": "✓  이 게임 작업공간의 쓰기 권한 허용",
        "mcp_auth.cancel": "✗  취소 — 다른 모델 선택",
        "settings.title": "설정",
        "settings.configured": "이미 설정됨",
        "settings.add_new": "새 제공자 추가",
        "settings.language": "언어 / Language",
        "settings.discord": "Discord 브리지",
        "settings.config_path": "설정 파일 경로",
        "settings.test": "테스트",
        "settings.edit": "수정",
        "settings.delete": "삭제",
        "settings.back": "뒤로",
        "settings.test_ok": "정상",
        "settings.test_fail": "실패",
        "settings.provider.anthropic": "Anthropic (Claude)",
        "settings.provider.openai": "OpenAI (GPT)",
        "settings.provider.deepseek": "DeepSeek",
        "settings.provider.openrouter": "OpenRouter",
        "settings.provider.custom": "사용자 정의 (OpenAI 호환)",
        "settings.provider.mcp": "Claude Code (MCP)",
        "prompt.api_key": "API Key 붙여넣기 (비우면 취소)",
        "prompt.model_id": "모델 id",
        "prompt.base_url": "베이스 URL",
        "prompt.entry_id": "설정 id (예: {example})",
        "preset.badge.custom": "커스텀",
        "preset.add_custom": "+  커스텀 provider 추가 (Qwen / Ollama / OpenAI 호환…)",
        "choice.use": "사용",
        "choice.edit": "수정 후 사용",
        "choice.cancel": "취소",
        "ui.hint.picker_default": "↑↓←→ 선택 · Enter 확인 · Esc 뒤로",
        "ui.hint.picker_expand": "↑↓ 선택 · Enter 전체 보기 · Esc 닫기",
        "ui.hint.text_input_default": "Enter 저장 · Esc 취소",
        "ui.hint.esc_cancel": "Esc 취소",
        "ui.hint.esc_cancel_enter_submit": "Esc 취소 · Enter 전송",
        "ask_user.placeholder": "답변을 입력하세요 (Enter 전송)...",
        "ask_user.waiting_choice": "ask_user 선택 대기 중...",
        "ask_user.cancelled": "(취소됨)",
        "player.default_name": "주인공",
        "upgrade.success": "업그레이드 완료. neonrp / worldlines 를 재시작해 주세요.",
        "upgrade.failed": "업그레이드 실패. 위의 출력 확인.",
        "update.launch_banner": "↑ 새 버전 있음: {current} → {latest} ({channel})",
        "update.launch_release_notes": "Release notes: {url}",
        "update.launch_editable_blocked": "소스 / editable 설치 — 자동 업그레이드 비활성, 시작 시 알림만 표시.",
        "update.launch_choice_prompt": "업그레이드하시겠습니까? [y] 업그레이드 / [s] 이 버전 건너뛰기 / [n] 나중에",
        "update.launch_failed": "업그레이드 실패 — 현재 버전으로 계속 진행합니다.",
        "update.launch_skipped": "{version} 건너뜀 — 다음 업데이트 때 다시 알립니다.",
        "preset.api_key_needed": "{display} 에 API Key 가 필요합니다",
        "preset.api_key_get_at": "발급 주소: https://{url}",
        "preset.api_key_saved": "저장됨 — 다음 실행 시 다시 입력하지 않아도 됩니다.",
    },
}

# Aliases recognized when reading from env or user config. Maps raw tokens to canonical codes.
_ALIAS_MAP: dict[str, Locale] = {
    # English variants
    "en": "en", "en-us": "en", "en-gb": "en", "us": "en", "uk": "en",
    # Simplified/traditional Chinese all roll up to "zh" for now.
    "zh": "zh", "zh-cn": "zh", "zh-hans": "zh", "zh-sg": "zh",
    "zh-tw": "zh", "zh-hk": "zh", "zh-mo": "zh", "zh-hant": "zh",
    "cn": "zh", "chs": "zh", "cht": "zh", "hans": "zh", "hant": "zh",
    # Japanese
    "ja": "ja", "ja-jp": "ja", "jp": "ja", "jpn": "ja",
    # Korean
    "ko": "ko", "ko-kr": "ko", "kr": "ko", "kor": "ko",
}


def normalize_locale(value: str | None) -> Locale:
    """Normalize locale hints to a supported TUI locale.

    Accepts IETF-style tags ("zh-CN"), POSIX-style ("zh_CN.UTF-8"), and common
    country shortcuts ("cn", "jp", "kr"). Falls back to English.
    """
    text = str(value or "").strip().lower().replace("_", "-")
    if not text:
        return "en"

    # Strip encoding suffix like ".utf-8"
    if "." in text:
        text = text.split(".", 1)[0]

    if text in _ALIAS_MAP:
        return _ALIAS_MAP[text]

    # Try language-only part: "zh-hans-cn" → "zh"
    root = text.split("-", 1)[0]
    if root in _ALIAS_MAP:
        return _ALIAS_MAP[root]

    if root in SUPPORTED_LOCALES:
        return root  # type: ignore[return-value]

    return "en"


def resolve_locale(configured: str | None = None) -> Locale:
    """Resolve UI locale using the precedence:
    project config → user config (~/.neonrp/config.json ui.language) →
    NEONRP_LOCALE env → system locale env → `en`.
    """
    configured_value = str(configured or "").strip().lower()
    if configured_value and configured_value != "auto":
        return normalize_locale(configured_value)

    # User-level config fallback (applies across projects and the launcher).
    try:
        from neonrp.core.user_config import get_user_locale

        user_locale = get_user_locale()
    except Exception:
        user_locale = "auto"
    if user_locale and user_locale != "auto":
        return normalize_locale(user_locale)

    env_value = (
        os.environ.get("NEONRP_LOCALE")
        or os.environ.get("LC_ALL")
        or os.environ.get("LC_MESSAGES")
        or os.environ.get("LANG")
        or "en"
    )
    return normalize_locale(env_value)


def get_message(locale: Locale, key: str) -> str:
    """Get a localized UI string, falling back to English."""
    language = normalize_locale(locale)
    return _MESSAGES.get(language, _MESSAGES["en"]).get(key, _MESSAGES["en"].get(key, key))


def localize_mode(locale: Locale, mode: str) -> str:
    """Localize a compact mode label."""
    return get_message(locale, f"mode.{mode}")
