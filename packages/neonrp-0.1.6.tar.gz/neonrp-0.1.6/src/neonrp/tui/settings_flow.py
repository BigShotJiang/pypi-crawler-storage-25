"""Shared settings flow used by both WorldLines launcher and NeonRP TUI.

Instead of duplicating the "pick a model / add a new one / test it" wizard in
two places, both the launcher and the main TUI push screens built from here.

The flow is a stateless collection of helpers; it does not own any
long-lived widgets. Each entry point receives the host App so it can call
`push_screen` / `call_later` with correct context.
"""

from __future__ import annotations

import json
import re
from typing import Any, Callable

from neonrp.presets import (
    CLAUDE_CODE_PRESET_ID,
    PRESETS,
    PROVIDER_TYPES,
    _USER_CONFIG_PATH,
    _load_user_config_models,
    _save_key_to_user_config,
    fetch_openrouter_models,
    get_provider_type,
    is_claude_code_available,
    test_preset,
)
from neonrp.tui.i18n import get_message

ENTRY_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


# ---------------------------------------------------------------------------
# Data helpers
# ---------------------------------------------------------------------------

def list_configured_entries() -> list[dict[str, Any]]:
    """Return every configured model entry the user has set up.

    Sources, in this order:
    - `claude-code` (virtual preset, available if `claude` CLI is present)
    - Built-in PRESETS where a real API key resolves (env or user config)
    - User-config `~/.neonrp/config.json.models.*` custom entries
    """
    import os

    result: list[dict[str, Any]] = []

    if is_claude_code_available():
        result.append({
            "id": CLAUDE_CODE_PRESET_ID,
            "provider": "mcp",
            "model": "claude-code-mcp",
            "source": "cli",
            "has_key": True,
        })

    user_models = _load_user_config_models()

    for preset_id, info in PRESETS.items():
        env_key = os.environ.get(info.get("api_key_env", "") or "", "").strip()
        user_key = str((user_models.get(preset_id) or {}).get("api_key", "") or "").strip()
        has_key = bool(env_key or user_key)
        if not has_key:
            continue
        entry = {
            "id": preset_id,
            "provider": info.get("provider", ""),
            "model": (user_models.get(preset_id) or {}).get("model", info.get("model", "")),
            "source": "builtin",
            "has_key": True,
        }
        result.append(entry)

    for mid, data in user_models.items():
        if mid in PRESETS or mid == "stub":
            continue
        result.append({
            "id": mid,
            "provider": data.get("provider", "openai"),
            "model": data.get("model", ""),
            "source": "custom",
            "has_key": bool(data.get("api_key")),
        })

    # De-dup by id, preserving order.
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []
    for item in result:
        if item["id"] in seen:
            continue
        seen.add(item["id"])
        deduped.append(item)
    return deduped


def save_custom_entry(entry_id: str, data: dict[str, Any]) -> None:
    """Overwrite `~/.neonrp/config.json.models.<entry_id>` with `data`."""
    if _USER_CONFIG_PATH.exists():
        cfg = json.loads(_USER_CONFIG_PATH.read_text(encoding="utf-8"))
    else:
        cfg = {}
    models = cfg.setdefault("models", {})
    models[entry_id] = data
    _USER_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _USER_CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")


def delete_entry(entry_id: str) -> None:
    if not _USER_CONFIG_PATH.exists():
        return
    cfg = json.loads(_USER_CONFIG_PATH.read_text(encoding="utf-8"))
    if "models" in cfg and entry_id in cfg["models"]:
        del cfg["models"][entry_id]
        _USER_CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")


# ---------------------------------------------------------------------------
# Flow controller — attached to either WorldLinesLauncherApp or NeonRPApp.
# The host must provide:
#   push_screen(screen, callback)
#   _step_prompt_text(title, default, on_submit)  (for TextInputScreen prompts)
#   ui_locale  (str)   — optional, defaults to "en"
# ---------------------------------------------------------------------------

class SettingsFlow:
    """State-less helpers for the shared settings flow."""

    def __init__(
        self,
        host: Any,
        *,
        on_exit: Callable[[], None] | None = None,
    ):
        self.host = host
        self.on_exit = on_exit

    @property
    def locale(self) -> str:
        return getattr(self.host, "ui_locale", None) or getattr(self.host, "locale", "en") or "en"

    def _t(self, key: str) -> str:
        return get_message(self.locale, key)

    # ------------------------------------------------------------------
    # Top-level menu: Configured (N) + Add new + System — each a section.
    # ------------------------------------------------------------------
    def open_root(self) -> None:
        from neonrp.tui.app import ChoicePickerScreen, section, spacer
        from neonrp.core.discord_config import get_discord_inline_status
        from neonrp.core.user_config import get_user_locale

        configured = list_configured_entries()

        options: list[tuple[str, str]] = []

        # ─── Section 1: Configured ────────────────────────────────────
        options.append(section(f"── {self._t('settings.configured')} ({len(configured)}) ──"))
        options.append(spacer())
        if configured:
            options.append((f"▶▶ {self._t('settings.test')} all ({len(configured)})", "test_all"))
        for entry in configured:
            prov = entry["provider"] or "?"
            model = entry["model"] or "?"
            options.append((f"{entry['id']:<14}  [{prov:<9}]  {model}", f"view::{entry['id']}"))
        if not configured:
            options.append(("(none — add one below)", "__noop__"))

        options.append(spacer())

        # ─── Section 2: Add new ───────────────────────────────────────
        options.append(section(f"── {self._t('settings.add_new')} ──"))
        options.append(spacer())
        for ptype in PROVIDER_TYPES:
            tkey = f"settings.provider.{ptype['id']}"
            label = self._t(tkey) if tkey in self._all_translation_keys() else ptype["label"]
            options.append((f"+  {label}", f"add::{ptype['id']}"))

        options.append(spacer())

        # ─── Section 3: System ────────────────────────────────────────
        options.append(section("── system ──"))
        options.append(spacer())
        options.append((f"{self._t('settings.language')}  ({get_user_locale()})", "locale"))
        options.append((f"{self._t('settings.discord')}  ({get_discord_inline_status()})", "discord"))
        options.append((self._t('settings.config_path'), "show_path"))
        options.append(spacer())
        options.append((self._t('settings.back'), "back"))

        def on_selected(value: str | None) -> None:
            if value is None or value == "back":
                if self.on_exit:
                    self.on_exit()
                return
            if value == "__noop__":
                self.open_root()
                return
            if value == "test_all":
                self._run_test_all(configured)
                return
            if value == "locale":
                self._open_language_picker()
                return
            if value == "discord":
                self._open_discord()
                return
            if value == "show_path":
                self._open_config_path()
                return
            if value.startswith("view::"):
                self._open_entry_detail(value.split("::", 1)[1])
                return
            if value.startswith("add::"):
                self._open_add_flow(value.split("::", 1)[1])
                return

        self.host.push_screen(
            ChoicePickerScreen(self._t("settings.title"), options),
            on_selected,
        )

    def _all_translation_keys(self) -> set[str]:
        from neonrp.tui.i18n import _MESSAGES

        return set(_MESSAGES.get(self.locale, _MESSAGES["en"]).keys())

    # ------------------------------------------------------------------
    # Per-entry detail: edit key / edit model / test / delete / back
    # ------------------------------------------------------------------
    def _open_entry_detail(self, entry_id: str) -> None:
        from neonrp.tui.app import ChoicePickerScreen, section, spacer

        user_models = _load_user_config_models()
        preset_info = PRESETS.get(entry_id, {})
        merged = {**preset_info, **(user_models.get(entry_id) or {})}
        masked = _mask_key(merged.get("api_key", ""))
        model = merged.get("model", "") or "(unset)"
        prov = merged.get("provider", "?")

        options = [
            section(f"── {entry_id} ──"),
            spacer(),
            (f"id:        {entry_id}", "__noop__"),
            (f"provider:  {prov}", "__noop__"),
            (f"model:     {model}", "__noop__"),
            (f"api key:   {masked}", "__noop__"),
            spacer(),
            section("── actions ──"),
            spacer(),
            (f"▶  {self._t('settings.test')}", "test"),
            (f"✎  {self._t('settings.edit')} API key", "edit_key"),
            (f"✎  {self._t('settings.edit')} model", "edit_model"),
            (f"✗  {self._t('settings.delete')}", "delete"),
            spacer(),
            (self._t("settings.back"), "back"),
        ]

        def on_selected(value: str | None) -> None:
            if value is None or value == "back":
                self.open_root()
                return
            if value == "__noop__":
                self._open_entry_detail(entry_id)
                return
            if value == "test":
                self._run_test(entry_id)
                return
            if value == "edit_key":
                self.host._step_prompt_text(
                    f"{self._t('prompt.api_key')} · {entry_id}",
                    default="",
                    on_submit=lambda v: self._apply_key_edit(entry_id, v),
                )
                return
            if value == "edit_model":
                self.host._step_prompt_text(
                    f"{self._t('prompt.model_id')} · {entry_id}",
                    default=model if model != "(unset)" else "",
                    on_submit=lambda v: self._apply_model_edit(entry_id, v),
                )
                return
            if value == "delete":
                delete_entry(entry_id)
                self.open_root()

        self.host.push_screen(
            ChoicePickerScreen(f"{self._t('settings.title')} · {entry_id}", options),
            on_selected,
        )

    def _apply_key_edit(self, entry_id: str, raw: str) -> None:
        raw = (raw or "").strip()
        if raw:
            _save_key_to_user_config(entry_id, raw)
        self._open_entry_detail(entry_id)

    def _apply_model_edit(self, entry_id: str, raw: str) -> None:
        raw = (raw or "").strip()
        if not raw:
            self._open_entry_detail(entry_id)
            return
        if _USER_CONFIG_PATH.exists():
            cfg = json.loads(_USER_CONFIG_PATH.read_text(encoding="utf-8"))
        else:
            cfg = {}
        models = cfg.setdefault("models", {})
        entry = models.setdefault(entry_id, {})
        entry["model"] = raw
        _USER_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        _USER_CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
        self._open_entry_detail(entry_id)

    def _run_test(self, entry_id: str) -> None:
        from neonrp.tui.app import ChoicePickerScreen, section, spacer

        result = test_preset(entry_id)
        if result.get("ok"):
            status = f"✓ {self._t('settings.test_ok')}  ({result.get('latency_ms', 0)}ms)"
        else:
            status = f"✗ {self._t('settings.test_fail')}  {result.get('error', '')[:200]}"
        options = [
            section(f"── test · {entry_id} ──"),
            spacer(),
            (status, "__noop__"),
            (f"provider:  {result.get('provider', '?')}", "__noop__"),
            (f"model:     {result.get('model', '?')}", "__noop__"),
            spacer(),
            (self._t("settings.back"), "back"),
        ]

        def on_selected(value: str | None) -> None:
            self._open_entry_detail(entry_id)

        self.host.push_screen(
            ChoicePickerScreen(f"Test · {entry_id}", options),
            on_selected,
        )

    def _run_test_all(self, entries: list[dict[str, Any]]) -> None:
        """Test every configured entry in parallel, then show a summary screen."""
        from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FutTimeout
        from neonrp.tui.app import ChoicePickerScreen, section, spacer

        if not entries:
            self.open_root()
            return

        results: list[tuple[str, dict[str, Any]]] = []
        ids = [e["id"] for e in entries]

        # Run pings in parallel. Per-preset timeout is enforced inside
        # `test_preset` (6s). We give the outer `as_completed` a hard
        # 10s wall-clock cap so a single hung request can't block the whole
        # Test-all screen from rendering.
        with ThreadPoolExecutor(max_workers=min(8, len(ids) or 1)) as pool:
            futures = {pool.submit(test_preset, pid): pid for pid in ids}
            try:
                for fut in as_completed(futures, timeout=12.0):
                    pid = futures[fut]
                    try:
                        results.append((pid, fut.result(timeout=0)))
                    except Exception as exc:
                        results.append((pid, {"ok": False, "error": str(exc)[:160]}))
            except FutTimeout:
                # Collect whatever finished; mark the rest as timed out.
                done_ids = {futures[f] for f in futures if f.done()}
                for fut, pid in futures.items():
                    if pid in [r[0] for r in results]:
                        continue
                    if pid in done_ids:
                        try:
                            results.append((pid, fut.result(timeout=0)))
                        except Exception as exc:
                            results.append((pid, {"ok": False, "error": str(exc)[:160]}))
                    else:
                        fut.cancel()
                        results.append((pid, {"ok": False, "error": "timeout"}))

        # Preserve original configured order for stable UX.
        order_index = {pid: i for i, pid in enumerate(ids)}
        results.sort(key=lambda r: order_index.get(r[0], 1_000_000))

        ok_count = sum(1 for _, r in results if r.get("ok"))
        fail_count = len(results) - ok_count

        options: list[tuple[str, str]] = [
            section(f"── {self._t('settings.test')} all  ·  ✓ {ok_count} / ✗ {fail_count} ──"),
            spacer(),
        ]
        for pid, res in results:
            if res.get("ok"):
                line = (
                    f"✓  {pid:<16} [{res.get('provider', ''):<9}] "
                    f"{res.get('model', ''):<28} {res.get('latency_ms', 0)}ms"
                )
            else:
                err = str(res.get("error", ""))[:110]
                line = f"✗  {pid:<16} [{res.get('provider', ''):<9}] {err}"
            options.append((line, f"view::{pid}"))

        options.append(spacer())
        options.append((self._t("settings.back"), "back"))

        def on_selected(value: str | None) -> None:
            if value is None or value == "back" or value == "__noop__":
                self.open_root()
                return
            if value.startswith("view::"):
                self._open_entry_detail(value.split("::", 1)[1])

        self.host.push_screen(
            ChoicePickerScreen(f"Test all · {self._t('settings.title')}", options),
            on_selected,
        )

    # ------------------------------------------------------------------
    # Add-new flow — 6 provider types
    # ------------------------------------------------------------------
    def _open_add_flow(self, type_id: str) -> None:
        ptype = get_provider_type(type_id)
        if ptype is None:
            self.open_root()
            return
        if type_id == "mcp":
            self._open_add_mcp()
            return
        if type_id == "custom":
            self._open_add_custom(ptype)
            return
        self._open_add_standard(ptype)

    def _open_add_standard(self, ptype: dict[str, Any]) -> None:
        """anthropic / openai / deepseek / openrouter flow."""
        # Use the canonical id (anthropic/openai/deepseek/openrouter) unless
        # user wants a variant name. Phase 1: simple, reuse the built-in id.
        entry_id = ptype["id"]

        def after_model(model: str) -> None:
            model = (model or "").strip() or ptype["default_model"]
            self.host._step_prompt_text(
                f"{self._t('prompt.api_key')} · {ptype['label']}",
                default="",
                on_submit=lambda k: self._finalize_standard(ptype, entry_id, model, k),
            )

        if ptype["id"] == "openrouter" and ptype.get("fetch_catalog"):
            self.host._step_prompt_text(
                f"{self._t('prompt.api_key')} · OpenRouter (for model catalog)",
                default="",
                on_submit=lambda k: self._openrouter_after_key(ptype, entry_id, k),
            )
            return

        # Standard path: offer model choice from ptype["models"], then API key.
        models = list(ptype.get("models") or [])
        if not models:
            after_model(ptype["default_model"])
            return
        self._pick_model(
            title=f"{ptype['label']} — {self._t('prompt.model_id')}",
            models=models,
            allow_manual=True,
            on_selected=after_model,
        )

    def _openrouter_after_key(self, ptype: dict[str, Any], entry_id: str, key: str) -> None:
        key = (key or "").strip()
        if not key:
            self.open_root()
            return
        catalog = fetch_openrouter_models(key)
        models = [m["id"] for m in catalog[:120]] if catalog else list(ptype.get("models") or [])

        def after(model: str) -> None:
            self._finalize_standard(ptype, entry_id, model, key)

        self._pick_model(
            title=f"OpenRouter — {self._t('prompt.model_id')} ({len(models)})",
            models=models,
            allow_manual=True,
            on_selected=after,
        )

    def _finalize_standard(self, ptype: dict[str, Any], entry_id: str, model: str, key: str) -> None:
        key = (key or "").strip()
        if not key:
            self.open_root()
            return
        entry: dict[str, Any] = {
            "provider": ptype["provider"],
            "model": model,
            "api_key": key,
        }
        if ptype.get("base_url"):
            entry["base_url"] = ptype["base_url"]
        save_custom_entry(entry_id, entry)
        # Jump into detail so the user sees the result immediately.
        self._open_entry_detail(entry_id)

    def _open_add_custom(
        self,
        ptype: dict[str, Any],
        *,
        on_done: Callable[[str], None] | None = None,
    ) -> None:
        from neonrp.presets import first_custom_entry_example

        example = first_custom_entry_example()
        prompt_title = self._t("prompt.entry_id").format(example=example)

        def after_id(entry_id: str) -> None:
            entry_id = (entry_id or "").strip().lower()
            if not ENTRY_ID_RE.match(entry_id or ""):
                self.open_root()
                return
            self.host._step_prompt_text(
                self._t("prompt.base_url"),
                default="http://localhost:11434/v1",
                on_submit=lambda url: after_url(entry_id, url),
            )

        def after_url(entry_id: str, base_url: str) -> None:
            base_url = (base_url or "").strip()
            self.host._step_prompt_text(
                self._t("prompt.model_id"),
                default=entry_id,
                on_submit=lambda m: after_model(entry_id, base_url, m),
            )

        def after_model(entry_id: str, base_url: str, model: str) -> None:
            model = (model or "").strip()
            self.host._step_prompt_text(
                self._t("prompt.api_key"),
                default="",
                on_submit=lambda k: self._finalize_custom(entry_id, base_url, model, k, on_done=on_done),
            )

        self.host._step_prompt_text(
            prompt_title,
            default="",
            on_submit=after_id,
        )

    def _finalize_custom(
        self,
        entry_id: str,
        base_url: str,
        model: str,
        key: str,
        *,
        on_done: Callable[[str], None] | None = None,
    ) -> None:
        entry: dict[str, Any] = {
            "provider": "openai",
            "model": model or entry_id,
            "base_url": base_url,
        }
        if key.strip():
            entry["api_key"] = key.strip()
        save_custom_entry(entry_id, entry)
        if on_done is not None:
            on_done(entry_id)
            return
        self._open_entry_detail(entry_id)

    def _open_add_mcp(self) -> None:
        from neonrp.tui.app import ChoicePickerScreen

        if is_claude_code_available():
            options = [
                ("✓ `claude` CLI detected on PATH", "__noop__"),
                (f"  {_which_claude()}", "__noop__"),
                ("No further setup required — use Claude Code as your model.", "__noop__"),
                (self._t("settings.back"), "back"),
            ]
        else:
            options = [
                ("✗ `claude` CLI not found on PATH", "__noop__"),
                ("Install from: anthropic.com/claude-code", "__noop__"),
                (self._t("settings.back"), "back"),
            ]

        def on_selected(value: str | None) -> None:
            self.open_root()

        self.host.push_screen(
            ChoicePickerScreen("Claude Code (MCP)", options),
            on_selected,
        )

    def _pick_model(
        self,
        *,
        title: str,
        models: list[str],
        allow_manual: bool,
        on_selected: Callable[[str], None],
    ) -> None:
        from neonrp.tui.app import ChoicePickerScreen

        options: list[tuple[str, str]] = []
        for m in models:
            options.append((m, f"m::{m}"))
        if allow_manual:
            options.append(("…manual entry", "__manual__"))

        def handler(value: str | None) -> None:
            if value is None:
                self.open_root()
                return
            if value == "__manual__":
                self.host._step_prompt_text(
                    self._t("prompt.model_id"),
                    default="",
                    on_submit=lambda m: on_selected((m or "").strip()),
                )
                return
            if value.startswith("m::"):
                on_selected(value.split("::", 1)[1])
                return

        self.host.push_screen(ChoicePickerScreen(title, options), handler)

    # ------------------------------------------------------------------
    # Shortcuts to existing flows (language / discord / config path)
    # ------------------------------------------------------------------
    def _open_language_picker(self) -> None:
        # Delegate to whatever the host already has; launcher has one.
        prompter = getattr(self.host, "_prompt_first_run_locale", None)
        if callable(prompter):
            prompter()
            return
        # Fallback: open an inline locale picker.
        from neonrp.tui.app import ChoicePickerScreen
        from neonrp.core.user_config import set_user_locale

        options = [
            ("English", "en"),
            ("简体中文", "zh"),
            ("日本語", "ja"),
            ("한국어", "ko"),
            ("Auto", "auto"),
        ]

        def on_selected(value: str | None) -> None:
            if value:
                set_user_locale(value)
            self.open_root()

        self.host.push_screen(ChoicePickerScreen(self._t("settings.language"), options), on_selected)

    def _open_discord(self) -> None:
        fn = getattr(self.host, "_step_configure_discord", None)
        if callable(fn):
            fn()
            return
        self.open_root()

    def _open_config_path(self) -> None:
        from neonrp.tui.app import ChoicePickerScreen

        options = [
            (str(_USER_CONFIG_PATH), "__noop__"),
            (f"exists: {_USER_CONFIG_PATH.exists()}", "__noop__"),
            (self._t("settings.back"), "back"),
        ]

        def on_selected(value: str | None) -> None:
            self.open_root()

        self.host.push_screen(ChoicePickerScreen("Config file", options), on_selected)


def _mask_key(key: str) -> str:
    key = (key or "").strip()
    if not key:
        return "(not set)"
    if len(key) <= 10:
        return "…" + key[-4:]
    return key[:4] + "…" + key[-4:]


def _which_claude() -> str:
    import shutil

    return shutil.which("claude") or ""
