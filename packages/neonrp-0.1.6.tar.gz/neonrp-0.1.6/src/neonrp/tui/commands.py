"""TUI command parser for `/` commands (Claude Code style)."""

from dataclasses import dataclass
from typing import Optional
import shlex


@dataclass
class ParsedCommand:
    """Result of parsing a `/` command."""

    command: str
    args: list[str]
    options: dict[str, str]
    raw: str
    error: Optional[str] = None


def parse_command(input_text: str) -> ParsedCommand:
    """Parse a `:` command string.

    Examples:
        :validate -> ParsedCommand(command="validate", args=[], options={})
        :index build -> ParsedCommand(command="index", args=["build"], options={})
        :find tokyo -> ParsedCommand(command="find", args=["tokyo"], options={})
        :sandbox new test-1 --from save_001 -> ParsedCommand(
            command="sandbox", args=["new", "test-1"], options={"from": "save_001"}
        )

    Args:
        input_text: Command string (with or without leading `:`)

    Returns:
        ParsedCommand with parsed command, args, and options
    """
    # Remove leading `/` or `:` if present (support both for compatibility)
    text = input_text.strip()
    if text.startswith("/") or text.startswith(":"):
        text = text[1:]

    if not text:
        return ParsedCommand(command="", args=[], options={}, raw=input_text, error="Empty command")

    try:
        # Use shlex for proper quote handling
        tokens = shlex.split(text)
    except ValueError as e:
        return ParsedCommand(command="", args=[], options={}, raw=input_text, error=f"Parse error: {e}")

    if not tokens:
        return ParsedCommand(command="", args=[], options={}, raw=input_text, error="Empty command")

    command = tokens[0]
    args = []
    options = {}

    i = 1
    while i < len(tokens):
        token = tokens[i]
        if token.startswith("--"):
            # Option with value
            key = token[2:]
            if i + 1 < len(tokens) and not tokens[i + 1].startswith("-"):
                options[key] = tokens[i + 1]
                i += 2
            else:
                options[key] = "true"
                i += 1
        elif token.startswith("-") and len(token) == 2:
            # Short option
            key = token[1]
            if i + 1 < len(tokens) and not tokens[i + 1].startswith("-"):
                options[key] = tokens[i + 1]
                i += 2
            else:
                options[key] = "true"
                i += 1
        else:
            args.append(token)
            i += 1

    return ParsedCommand(command=command, args=args, options=options, raw=input_text)


# Mapping of valid commands and their expected structure
COMMANDS = {
    "init": {"args": 0, "help": "Initialize project in current directory"},
    "apply": {"args": 0, "help": "Apply pending proposal in sandbox mode"},
    "auth": {
        "args": "?",
        "args_hint": "[list|add|set|rm|show]",
        "subcommands": ["list", "add", "set", "rm", "show"],
        "sub_args_hint": {
            "add": "model <name> <provider> [base_url] [model] [api_key_env_or_key]",
            "set": "model <name>",
            "rm": "model <name>",
            "show": "model [name]",
        },
        "help": "Manage named model configs",
    },
    "models": {
        "args": "?",
        "args_hint": "[name|list|set <name>|show [name]]",
        "help": "Quick model switch: /models [name|list|set <name>|show <name>]",
    },
    "config": {
        "args": "?",
        "args_hint": "[show|set <key> <value>]",
        "subcommands": ["set", "show"],
        "sub_args_hint": {"set": "<key> <value>"},
        "help": "Show/set configuration",
    },
    "run": {"args": 1, "args_hint": "<query>", "help": "Run agent query explicitly"},
    "validate": {"args": 0, "help": "Validate game data schema"},
    "index": {"args": 1, "args_hint": "[build|update]", "subcommands": ["build", "update"], "help": "Rebuild/update entity index"},
    "find": {"args": 1, "args_hint": "<keyword>", "help": "Search entities by keyword"},
    "context": {"args": 1, "args_hint": "<query>", "help": "Retrieve context for a query"},
    "import": {
        "args": 1,
        "args_hint": "[sillytavern-card]",
        "subcommands": ["sillytavern-card"],
        "sub_args_hint": {"sillytavern-card": "<file> [--id <id>] [--json]"},
        "help": "Import external content",
    },
    "save": {"args": "?", "args_hint": "[save_name]", "help": "Create save snapshot [name]"},
    "copy": {"args": 0, "help": "Copy conversation to clipboard"},
    "load": {"args": "?", "args_hint": "[save_name]", "help": "Load a save snapshot or list available saves"},
    "undo": {"args": 0, "help": "Undo last change"},
    "redo": {"args": 0, "help": "Redo last undone change"},
    "branch": {"args": "?", "args_hint": "[name|list]", "help": "Create/switch/list branches"},
    "game": {"args": "?", "args_hint": "[new]", "subcommands": ["new"], "help": "Game management"},
    "sandbox": {
        "args": 1,
        "args_hint": "[new|list|switch|drop]",
        "subcommands": ["new", "list", "switch", "drop"],
        "sub_args_hint": {"new": "<name>", "switch": "<name>", "drop": "<name>"},
        "help": "Sandbox management",
    },
    "replay": {
        "args": 1,
        "args_hint": "[verify|checkout]",
        "subcommands": ["verify", "checkout"],
        "help": "Replay verification",
    },
    "agent": {
        "args": 1,
        "args_hint": "[list|show|run|new]",
        "subcommands": ["list", "show", "run", "new"],
        "sub_args_hint": {"show": "<name>", "run": "<name>", "new": "<name>"},
        "help": "Agent management",
    },
    "stats": {"args": 0, "help": "Show conversation statistics"},
    "compact": {"args": 0, "help": "Compact conversation history"},
    "sessions": {"args": 0, "help": "List saved per-branch sessions"},
    "continue": {"args": 0, "help": "Resume previous conversation for current branch"},
    "new": {"args": 0, "help": "Start a brand new conversation session"},
    "verbose": {"args": "?", "args_hint": "[on|off|status]", "help": "Enable/disable verbose debug mode (on|off|status)"},
    "autoapply": {"args": "?", "args_hint": "[on|off|status]", "help": "Toggle sandbox auto-apply (on|off|status)"},
    "mode": {"args": "?", "args_hint": "[build|sandbox|play]", "help": "Switch mode (build/sandbox/play)"},
    "router-mode": {
        "args": "?",
        "args_hint": "[fast|orchestrator|multi-agent]",
        "help": "Switch router execution mode",
    },
    "clear": {"args": 0, "help": "Clear conversation history"},
    "files": {"args": 0, "help": "List recently modified files"},
    "skills": {"args": 0, "help": "List available skills"},
    "mcp": {
        "args": "?",
        "args_hint": "[status|restart]",
        "subcommands": ["status", "restart"],
        "sub_args_hint": {"restart": "<server_name>"},
        "help": "MCP server management",
    },
    "help": {"args": 0, "help": "Show help"},
    "quit": {"args": 0, "help": "Exit TUI"},
    "q": {"args": 0, "help": "Exit TUI (alias)"},
    # WorldLines commands
    "debug": {"args": 0, "help": "Toggle MCP debug mode (show/hide tool calls and Claude output)"},
    "worlds": {"args": 0, "help": "Browse WorldLines worlds and scaffold a template"},
    "worldlines": {"args": 0, "help": "Open the WorldLines guided world picker"},
    "wl-model": {
        "args": "?",
        "args_hint": "[preset_name]",
        "help": "Switch WorldLines model preset (glm|opus)",
    },
    "update": {
        "args": "?",
        "args_hint": "[check|apply|status|channel <name>]",
        "subcommands": ["check", "apply", "status", "channel"],
        "help": "Check / apply neonrp updates",
    },
    "locale": {
        "args": "?",
        "args_hint": "[auto|en|zh|ja|ko]",
        "subcommands": ["auto", "en", "zh", "ja", "ko"],
        "help": "Switch UI language (persists in .neonrp/config.json tui.language)",
    },
    "settings": {
        "args": 0,
        "help": "Open unified model / api key / discord settings",
    },
    "bridge": {
        "args": "?",
        "args_hint": "[status|start <name>|stop <name>]",
        "subcommands": ["status", "start", "stop"],
        "help": "Manage Discord / Telegram bridges at runtime",
    },
    "export-world": {
        "args": "?",
        "args_hint": "[output.zip]",
        "help": "Zip the current game folder to a .zip (default ~/Downloads/)",
    },
    "load-world": {
        "args": 1,
        "args_hint": "<zip_path>",
        "help": "Restore a previously exported world .zip into ~/.worldlines/games/",
    },
}


def get_command_args_hint(command: str, spec: dict | None = None) -> str:
    """Get a display placeholder hint for command arguments."""
    cmd_spec = spec if spec is not None else COMMANDS.get(command, {})

    explicit_hint = cmd_spec.get("args_hint")
    if isinstance(explicit_hint, str) and explicit_hint.strip():
        return explicit_hint

    if "subcommands" in cmd_spec:
        return "[" + "|".join(cmd_spec["subcommands"]) + "]"
    if cmd_spec.get("args") == 1:
        return f"[{command}]"
    if cmd_spec.get("args") == "?":
        return "[name]"
    return ""


def get_subcommand_suggestions(command: str, prefix: str = "") -> list[str]:
    """Get subcommand suggestions for a given command.

    Args:
        command: The parent command name
        prefix: Optional prefix to filter subcommands

    Returns:
        List of matching subcommand names
    """
    cmd_spec = COMMANDS.get(command, {})
    subcmds = cmd_spec.get("subcommands", [])
    if prefix:
        return [s for s in subcmds if s.startswith(prefix.lower())]
    return subcmds


def get_command_suggestions(prefix: str) -> list[str]:
    """Get command suggestions for fuzzy matching.

    Args:
        prefix: Partial command input

    Returns:
        List of matching command names
    """
    prefix = prefix.lower()
    if not prefix:
        return list(COMMANDS.keys())

    return [cmd for cmd in COMMANDS.keys() if cmd.startswith(prefix)]


def validate_command(parsed: ParsedCommand) -> Optional[str]:
    """Validate a parsed command.

    Args:
        parsed: ParsedCommand to validate

    Returns:
        Error message if invalid, None if valid
    """
    if parsed.error:
        return parsed.error

    if not parsed.command:
        return "Empty command"

    if parsed.command not in COMMANDS:
        suggestions = get_command_suggestions(parsed.command)
        if suggestions:
            return f"Unknown command: {parsed.command}. Did you mean: {', '.join(suggestions[:3])}?"
        return f"Unknown command: {parsed.command}. Type /help for available commands."

    cmd_spec = COMMANDS[parsed.command]

    # Check subcommand if required
    if "subcommands" in cmd_spec:
        if not parsed.args:
            return f"Command '{parsed.command}' requires a subcommand: {', '.join(cmd_spec['subcommands'])}"
        if parsed.args[0] not in cmd_spec["subcommands"]:
            return f"Unknown subcommand '{parsed.args[0]}'. Valid options: {', '.join(cmd_spec['subcommands'])}"

    return None


def format_help() -> str:
    """Format help text for all commands."""
    lines = ["[bold]Available Commands:[/]", ""]
    for cmd, spec in sorted(COMMANDS.items()):
        help_text = spec.get("help", "")
        if "subcommands" in spec:
            help_text += f" ({', '.join(spec['subcommands'])})"
        lines.append(f"  [cyan]/{cmd}[/] - {help_text}")
    return "\n".join(lines)
