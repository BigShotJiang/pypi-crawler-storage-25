"""Main entry point for python -m neonrp."""

from neonrp.cli import cli

if __name__ == "__main__":
    cli()
