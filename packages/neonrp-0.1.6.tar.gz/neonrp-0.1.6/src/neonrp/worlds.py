"""WorldLines world registry and game directory management."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any


WORLDS: dict[str, dict[str, str]] = {
    "stone-ford": {
        "name": "Stone Ford Town",
        "name_local": "石津镇",
        "template": "stoneford-orch",
        "desc": "Classic fantasy RPG",
    },
    "dark-train": {
        "name": "Dark Train",
        "name_local": "暗夜列车",
        "template": "dark-train",
        "desc": "7-carriage mystery",
    },
}

GAME_HOME = Path.home() / ".worldlines" / "games"


def list_worlds() -> list[dict[str, str]]:
    """Return list of available worlds with display info."""
    result = []
    for world_id, info in WORLDS.items():
        result.append({
            "id": world_id,
            "name": info["name"],
            "name_local": info["name_local"],
            "template": info["template"],
            "desc": info["desc"],
        })
    return result


def get_world(world_id: str) -> dict[str, str]:
    """Get world info by ID."""
    if world_id not in WORLDS:
        raise KeyError(f"Unknown world: {world_id}")
    return {**WORLDS[world_id], "id": world_id}


def create_game_dir(world_id: str) -> Path:
    """Create a new game directory for the given world.

    Returns the path to the new game directory.
    Directory format: ``~/.worldlines/games/<world-id>-<YYYYMMDD-HHMMSS>/``
    """
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    game_dir = GAME_HOME / f"{world_id}-{timestamp}"
    game_dir.mkdir(parents=True, exist_ok=True)
    return game_dir


def infer_world_id_from_game_dir(game_dir: Path) -> str | None:
    """Infer world id from a saved game directory name."""
    dir_name = game_dir.name
    for world_id in WORLDS:
        if dir_name.startswith(f"{world_id}-"):
            return world_id
    return None


def list_saved_games() -> list[dict[str, Any]]:
    """List existing game directories with metadata.

    Returns a list sorted by modification time (newest first).
    Each entry has: path, world_id, display_name, mtime.
    """
    if not GAME_HOME.exists():
        return []

    games = []
    for game_dir in GAME_HOME.iterdir():
        if not game_dir.is_dir():
            continue
        # Extract world_id from directory name (format: <world-id>-<timestamp>)
        dir_name = game_dir.name

        # Skip Claude Code workspace siblings (they end with one or more -cc).
        # These are derived from a real game dir and should never be re-picked
        # as a saved game (doing so stacks another -cc on top).
        if dir_name.endswith("-cc") or "-cc-" in dir_name:
            continue

        world_id = None
        for wid in WORLDS:
            if dir_name.startswith(f"{wid}-"):
                world_id = wid
                break
        if world_id is None:
            continue

        # Check if it's actually initialized (has .neonrp/)
        neonrp_dir = game_dir / ".neonrp"
        if not neonrp_dir.exists():
            continue

        world_info = WORLDS[world_id]
        mtime = game_dir.stat().st_mtime
        mtime_dt = datetime.fromtimestamp(mtime)

        games.append({
            "path": game_dir,
            "world_id": world_id,
            "display_name": f"{world_info['name']} ({world_info['name_local']})",
            "mtime": mtime,
            "mtime_display": mtime_dt.strftime("%m/%d %H:%M"),
            "dir_name": dir_name,
        })

    # Sort by modification time, newest first
    games.sort(key=lambda g: g["mtime"], reverse=True)
    return games
