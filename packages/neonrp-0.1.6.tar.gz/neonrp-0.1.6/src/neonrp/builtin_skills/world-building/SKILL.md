---
name: world-building
description: World entity structure, map coherence, and NPC design guidance.
---

# Entity Conventions

- Store entities in `world/<kind>/<id>.json`.
- Keep `id`, `kind`, and `name` consistent.
- Use stable IDs; avoid rewriting IDs unless required.

# Map Coherence

- Ensure location connections are bidirectional where expected.
- Keep travel descriptions aligned with location metadata.
- Introduce new locations with at least one meaningful hook.

# NPC Design

- Give each NPC a concrete role and motivation.
- Track relation to player/world factions.
- Keep dialogue style consistent with setting tone.

# Continuity

- Prefer incremental edits over large rewrites.
- Preserve established facts unless explicitly retconned.
