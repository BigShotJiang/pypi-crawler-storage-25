"""Bundled builtin skills shipped with NeonRP."""
