#!/usr/bin/env python3
"""Cross-platform QA gate runner for NeonRP."""

import subprocess
import sys
import datetime


def run(cmd: list[str], label: str) -> bool:
    print(f"\n{'=' * 40}")
    print(f"  {label}")
    print(f"{'=' * 40}\n")
    # Use shell=True for windows command resolution if needed, but list is safer.
    # On Windows, shell=True is often needed for batch files or path resolution if not full path.
    shell = sys.platform == "win32"
    try:
        result = subprocess.run(cmd, shell=shell)
        if result.returncode != 0:
            print(f"\n!! {label} FAILED (exit {result.returncode})")
            return False
        print(f"\n-- {label} OK")
        return True
    except FileNotFoundError:
        print(f"\n!! {label} FAILED (Command not found: {cmd[0]})")
        return False


def main() -> int:
    steps = [
        (["ruff", "format", "."], "Format"),
        (["ruff", "check", "."], "Lint"),
        (["pytest"], "Tests"),
    ]

    for cmd, label in steps:
        if not run(cmd, label):
            return 1

    print("\n" + "=" * 40)
    print("  All automated gates passed.")
    print("=" * 40)
    print()

    date_str = datetime.date.today().strftime("%Y%m%d")
    print("NEXT STEPS (Copy & Run):")
    print("-" * 20)
    print(
        f'1. Code Review:\n   opencode run "Using guidelines in prompts/code_review.md, review src/ changes against docs/REQUIREMENTS.md. Report to reviews/REVIEW_{date_str}.md"'
    )
    print("-" * 20)
    print("2. Documentation Update:")
    print("   - [ ] Check off items in docs/ROADMAP.md")
    print("   - [ ] Add entry to docs/PROGRESS.md")
    print("-" * 20)

    return 0


if __name__ == "__main__":
    sys.exit(main())
