@echo off
REM WorldLines - Windows double-clickable launcher.
REM
REM Double-click opens a cmd window; this script delegates to PowerShell
REM (because the real install flow needs Invoke-RestMethod and env-aware
REM PATH tweaks that are a pain in pure .bat). PowerShell pipes through
REM install.ps1 from worldlines.gg, then execs `worldlines`.
REM
REM Companion scripts: WorldLines.command (macOS), WorldLines.sh (Linux).

title WorldLines
cls

echo.
echo   WorldLines launcher
echo.

where worldlines >nul 2>&1
if %ERRORLEVEL%==0 (
    echo   checking for updates...
    where uv >nul 2>&1 && uv tool upgrade worldlines >nul 2>&1
    goto :launch
)

echo   worldlines not installed yet -- running first-time setup
echo.

powershell -ExecutionPolicy ByPass -NoProfile -Command ^
    "try { irm https://worldlines.gg/install.ps1 | iex } catch { irm https://github.com/LudicDynamics/WorldLines/releases/latest/download/install.ps1 | iex }"

if %ERRORLEVEL% neq 0 (
    echo.
    echo   install failed. Check the output above.
    pause
    exit /b 1
)

REM Make sure the newly-installed uv / worldlines are on this shell's PATH.
set "PATH=%USERPROFILE%\.local\bin;%USERPROFILE%\.cargo\bin;%PATH%"

where worldlines >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo.
    echo   setup finished but 'worldlines' is still not on PATH.
    echo   Open a new cmd or PowerShell and run: worldlines
    pause
    exit /b 1
)

:launch
echo.
worldlines
