# Changelog (docs pack)

## v0.9.3 (2026-03-29)
- TUI build mode now works immediately after `neonrp init` in fresh directories, without requiring local agent scaffolding first.
- Added packaged builtin skills under `src/neonrp/builtin_skills/` and project-level skill loading now falls back to those builtin skills automatically.
- Added TUI Tavern import entry points:
  - `neonrp tui --import-card <file> [--import-id <id>]`
  - `/import sillytavern-card <file> [--id <id>]`
- Improved SillyTavern import ergonomics:
  - PNG/JSON import tool is exposed to build-mode agents as `import_sillytavern_card(...)`
  - non-ASCII card names now derive stable ASCII entity IDs instead of collapsing to `unnamed`
  - agent tool can set destination path and visible name explicitly.
- Fixed Tavern "convert into full game" workflow:
  - added `ensure_playable_scaffold(...)` to copy missing play agents/runtime scaffold
  - normalized `game/meta/active-agent.json` to the canonical top-level `active_agent` protocol
  - updated Tavern import skill/prompt guidance so generated worlds only claim playability after scaffold exists.

## v0.9.2 (2026-02-16)
- Added optional embedding-based retrieval pipeline:
  - new `src/neonrp/core/embedding.py` (adapters + vector index persistence)
  - hybrid fuzzy + vector ranking in `read_context` / `context`
  - automatic fuzzy-only fallback when embedding is unavailable.
- `index build` now precomputes embeddings by default when `embedding.enabled=true`.
- Simplified embedding config workflow:
  - supports minimal config with `embedding.enabled + embedding.model_ref`
  - inherits provider/model/auth/base_url from `models[model_ref]`.
- Applied fixes from `reviews/code_review_20260216.md` across apply/save-load/permissions/CLI consistency paths.
- Added regression coverage for embedding and fuzzy retrieval:
  - `tests/test_embedding.py`
  - `tests/test_retrieval_fuzzy.py`

## v0.9.1 (2026-02-10)
- Added provider-specific request passthrough via model-level `extra` config (`models.<name>.extra`), including OpenRouter reasoning payloads.
- Fixed OpenAI-compatible extra parameter compatibility:
  - unknown extra fields are now routed through `extra_body` instead of top-level kwargs
  - avoids SDK errors like `unexpected keyword argument 'reasoning'`.
- Improved retry behavior for transient streaming failures:
  - conversation loop now retries with fixed backoff `2s -> 7s -> 15s -> 30s`, then stops.
  - streaming/network errors are now classified as retryable and propagated correctly.
- Improved `ask_user` UX in TUI:
  - selected answer is shown inline in the conversation as a user-visible message
  - restored sessions re-render historical `ask_user` selections
  - tool card detail now shows `selected: ...` for `ask_user`.
- Test coverage updates for new behavior:
  - added `tests/test_llm_openai_extra.py`
  - expanded coverage in `test_conversation.py`, `test_conversation_edges.py`, `test_app_v2.py`, `test_llm_retry.py`, `test_llm_streaming.py`, `test_config.py`, `test_per_agent_llm.py`.

## v0.9
- **M10.1 delivered**: TUI/Conversation reliability and operability upgrades.
- Added **ESC interrupt** for in-flight LLM turns in conversational TUI.
- Added configurable per-turn tool-call ceiling via `tui.max_tool_rounds` in config.
- Added **incremental session history saving** (Claude Code-style persistence behavior).
- Added startup/session controls:
  - `neonrp tui --continue` / `--new` / `--verbose`
  - `/sessions` picker modal + `/continue` + `/new`
  - `/verbose on|off|status` with debug JSONL logs.
- Improved TUI telemetry and lifecycle:
  - real-time local token estimation in status bar
  - safer quit path (`Ctrl+Q`) while requests are running.
- Todo workflow compatibility fixes:
  - TodoWrite prompt now includes a **minimal valid example**
  - todo validation aligned to mainstream UX (`<=1 in_progress`, `activeForm` optional, `done` alias accepted)
  - todo rendering stabilized with literal markers ``[x]`` / ``[>]`` / ``[ ]``
  - `/continue` now restores todo list from tool history.
- Documentation refresh:
  - synced `README.md`, `DEV_README.md`, `docs/TUTORIAL.md`, `docs/ROADMAP.md` with latest TUI/session behavior.

## v0.8
- **M9 + M10 stabilization delivered** (conversation-first TUI, ask_user modal, markdown transcript, slash suggestion UX)
- Added coverage补测 wave focused on real runtime paths (not stub-only):
  - `tests/test_conversation_edges.py`
  - `tests/test_retrieval.py`
  - `tests/test_tui_suggestions.py`
  - `tests/test_llm_real_endpoint.py` (real endpoint e2e via `~/.neonrp/config.json`)
- Coverage report updated (`reviews/coverage_report_20260209.md`):
  - Total coverage: **63% → 65%**
  - `core/conversation.py`: 80% → 99%
  - `core/retrieval.py`: 33% → 95%
  - `tui/suggestions.py`: 0% → 99%
- Regression status updated: `803 passed, 7 skipped`

## v0.7
- **M4 Implementation**: Sandbox + Replay milestone complete (290 tests)
- **Pre-M4 Housekeeping**:
  - H7: Fixed `load` command crash-safety (atomic rename strategy)
  - H8: Fixed deprecated `datetime.utcnow()` → `datetime.now(timezone.utc)`
  - H9: Added PNG character card import (pure Python tEXt chunk reader, no Pillow)
- Added `neonrp sandbox new|list|switch|drop` CLI commands
- Added `neonrp replay verify|checkout` CLI commands
- Added `core/hashing.py` — deterministic world tree hash utility
- Added `core/replay.py` — replay engine (staging-based, non-destructive)
- Added `core/system_proposal.py` — system proposal factory for import/game commands
- Added `core/paths.py:validate_branch_name()` — path traversal protection
- Extended `BranchMetadata` with `kind`/`parent`/`fork_event`/`base_save` for sandbox support
- Save now includes `meta.json` (game_hash, head_event, branch) and `events.jsonl` copy
- Atomic `events.jsonl` copy via temp file + `os.replace`
- Import and `game new` now generate system proposals through apply pipeline
- Sandbox switch invalidates `manifest.entities` with `index build` prompt
- Bumped manifest.version to `"0.3"`
- ADR 0011 (sandbox branch model), ADR 0012 (replay and determinism contract)

## v0.6
- **M3 Implementation**: LLM Integration + Skills + Import milestone complete (219 tests)
- **Pre-M3 Housekeeping**:
  - H3: Fixed `agent.py:393` active_branch bug
  - H4: Atomic world/ directory replacement in `apply.py`
  - H5: Empty index warning in `retrieval.py`
  - H6: Standardized delete hunk header in `diffing.py`
- Added LLM adapter Protocol (`core/llm.py`) with stub, OpenAI, and GLM providers
- Added skill tool registry (`core/skills.py`) with per-file deny-first permissions and JSONL audit logging
- Added `neonrp agent run <id> --query "..." [--provider] [--apply] [--json]` LLM-driven agent execution
- Added `neonrp import sillytavern-card` with v1/v2 JSON card support, ID conflict resolution, raw payload preservation
- Added `neonrp game new` scaffolding command with `--force`/`--json`
- Added project config `.neonrp/config.json` with provider/model/CLI defaults
- Added `.env` file loader for API key management
- ADR 0008 (LLM adapter), ADR 0009 (skill registry), ADR 0010 (SillyTavern import)

## v0.5
- **M2 Implementation**: Agents + Plan/Diff/Apply milestone complete (110 tests)
- Added `neonrp agent new|list|show|path` CLI commands with template generation
- Added `core/proposal.py` — Proposal/Op models with path validation
- Added `core/permissions.py` — deny-first glob matching permission engine
- Added `core/diffing.py` — stable unified diff generation
- Added `core/apply.py` — staging + validate + atomic swap apply pipeline
- Added `core/retrieval.py` — agent-scoped context retrieval
- Added `neonrp agent run --proposal --apply` and `neonrp agent logs` commands
- GameEvent model extended with `actor` field for agent attribution
- ADR 0006 (agent spec and permissions), ADR 0007 (proposal format)

## v0.4
- **M1 Implementation**: Validation + Indexing milestone complete (41 tests)
- Added `neonrp validate` CLI with `--json` support and exit codes 0/1/2
- Added `neonrp index build|update` CLI for entity indexing
- Added `neonrp find` CLI with --id/--tag/--kind/keyword search
- Added `neonrp context` CLI with explainable scoring and snippets
- Fixed `scan_entities()` to handle partial failures (index valid, skip invalid)
- Migrated to Pydantic v2 patterns (`ConfigDict`, `datetime.now(UTC)`)
- Bumped manifest.version to `"0.2"`

## v0.3
- **M0 Implementation**: Skeleton + Core Lifecycle milestone complete
- ARCHITECTURE: added write atomicity & crash recovery strategy; defined manifest.json minimal structure
- QUALITY_GATES: added three-layer test strategy (unit/integration/E2E); added code review process
- Replaced scripts/qa.sh with cross-platform scripts/qa.py

## v0.2
- Added ADRs: CLI framework (click), event storage format (NDJSON), snapshot & branch strategy
- ROADMAP: split T4 into T4a (undo/redo) + T4b (branch); added R-number cross-references
- QUALITY_GATES: added code review unrecoverable failure policy

## v0.1
- Initial documentation set: requirements, architecture, roadmap, progress, quality gates
- Added opencode review gate and code review prompt

