"""Shim package for PyPI `worldlines` distribution.

The actual CLI and runtime live in the `neonrp` package. This package
only exists so `pip install worldlines` / `uv tool install worldlines`
works as a discoverable alias and installs the pinned neonrp runtime.
"""

from neonrp.cli import worldlines_cli as main  # noqa: F401
