# worldlines

WorldLines is the guided launcher for the [NeonRP](https://github.com/LudicDynamics/WorldLines)
runtime — a file-backed text RPG engine with agent-driven storytelling.

This package is a thin shim that installs the matching `neonrp` runtime
and exposes the `worldlines` CLI entry point:

```bash
uv tool install worldlines
worldlines
```

For the full engine, features, and developer docs, see the main
[NeonRP repository](https://github.com/LudicDynamics/WorldLines).
