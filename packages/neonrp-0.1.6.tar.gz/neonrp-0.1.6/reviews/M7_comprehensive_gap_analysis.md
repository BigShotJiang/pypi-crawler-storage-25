# NeonRP M7 全面审查：与 Claude Code RP 体验的差距分析

**审查日期**: 2026-02-02
**审查目标**: 评估 NeonRP 距离 Claude Code 原生 RP 游戏体验还有多远
**参考项目**: `llm-rpg-starter-sample` (Claude Code 原生 RP 实现)

---

## 一、核心结论

**NeonRP 是一个出色的"RP 引擎基础设施"，但还不是一个完整的"RP 游戏体验"。**

用一个比喻：NeonRP 像是建好了一座配备安全系统、版本控制、审计日志的"剧院大楼"，但舞台上还缺少演员(多子代理)、剧本导演(编排器)、观众互动(结构化选择)、和道具管理(通用工具)。

**差距评分（排除模型因素）**: 约 **45/100**

- 基础设施层（版本控制/安全/审计）：**95/100** — 远超参考项目
- 核心 RP 游戏循环：**25/100** — 严重不足
- 工具能力层：**30/100** — 工具集过于受限
- 子代理架构：**15/100** — 几乎缺失
- 交互体验层：**40/100** — TUI 有但缺关键特性

---

## 二、架构对比：两种完全不同的哲学

### Claude Code RP（参考项目）的工作方式

```
用户输入 "进入商店"
    │
    ▼
rpg-orchestrator（主控代理）
    ├── Read game/run_state.json     ← 读取当前状态
    ├── 判断 scope=="town" → 路由到 rpg-shop-agent
    ├── Task(rpg-shop-agent, context) ← 调用子代理！
    │       ├── Read shop.json        ← 子代理独立读取文件
    │       ├── Read player/wallet.json
    │       ├── 计算结果
    │       └── 返回 PATCH_PLAN + NARRATIVE
    ├── Write(合并 PATCH)            ← 直接写入文件
    ├── AskUserQuestion(4个选项)      ← 结构化交互！
    └── Task(rpg-notary-archivist)    ← 记录事件
```

**关键特征**:
- 10 个专业子代理，各有领域职责
- 代理通过 Task 工具调用彼此（上下文隔离）
- 直接使用 Read/Write/Edit 操作文件
- AskUserQuestion 提供结构化选择
- 编排器负责路由、合并补丁、推进时间

### NeonRP 的工作方式

```
用户输入 "进入商店"
    │
    ▼
Dispatcher（简单路由：trigger/tag 匹配）
    │
    ▼
单一 Agent（narrator）
    ├── read_context("商店")          ← 唯一的读取方式
    ├── read_file("world/...")        ← 受限读取
    ├── resolve_action(buy/sell)      ← 机械计算
    └── submit_proposal(ops=[...])    ← 提交变更
         │
         ▼
    staging → validate → rules → apply  ← 安全管线
```

**关键特征**:
- 单一代理 + dispatcher 路由（不是编排器模式）
- 6 个受限 skills（不是通用工具）
- 所有变更通过 proposal → staging → apply 管线
- 无结构化交互
- 无子代理调用能力

---

## 三、六大核心差距（按优先级排序）

### 差距 1：🔴 无子代理编排架构（CRITICAL）

**参考项目**: 10 个专业子代理通过 Task 工具相互调用
```
orchestrator → Task(shop-agent, context) → PATCH_PLAN
orchestrator → Task(combat-referee, context) → PATCH_PLAN
orchestrator → Task(notary, context) → event log
```

**NeonRP 现状**: Dispatcher 只是一个路由器，选择单一代理运行
```python
# dispatcher.py: 只选择一个代理，不会调用多个
selected_id = select_agent(query, specs)  # 选一个
run_result = run_agent_agentic(root, selected_id, query)  # 跑一个
```

**差距影响**:
- 无法实现"编排器读状态 → 路由到专业代理 → 合并多个代理结果"的模式
- 无法实现"战斗后自动调用记录代理 + 叙事代理"的链式调用
- 每次只有一个代理视角，不能有领域划分

**需要什么**:
1. `Task` skill：允许代理 A 调用代理 B 作为子任务
2. 编排器模式：一个主代理读取状态、路由、合并补丁
3. 上下文隔离：子代理独立会话，不污染主代理上下文
4. PATCH_PLAN 格式：子代理返回结构化变更而非直接 proposal

---

### 差距 2：🔴 工具集严重不足（CRITICAL）

**参考项目代理可用工具**: `Read, Write, Edit, Glob, Grep, Task, AskUserQuestion`

**NeonRP 代理可用 skills**: `read_file, find, read_context, list_entities, resolve_action, submit_proposal`

| 能力 | Claude Code RP | NeonRP | 差距 |
|------|---------------|--------|------|
| 读取任意文件 | ✅ Read | ⚠️ read_file（受权限限制，截断5000字符） | 功能受限 |
| **写入文件** | ✅ Write | ❌ 无 | **完全缺失** |
| **编辑文件** | ✅ Edit | ❌ 无 | **完全缺失** |
| **文件搜索** | ✅ Glob | ❌ 无 | **完全缺失** |
| **内容搜索** | ✅ Grep | ❌ 无 | **完全缺失** |
| **调用子代理** | ✅ Task | ❌ 无 | **完全缺失** |
| **交互式提问** | ✅ AskUserQuestion | ❌ 无 | **完全缺失** |
| 实体检索 | ❌ 无（自己 Read） | ✅ read_context, find | NeonRP 优势 |
| 机械计算 | ❌ 无（rules in prompt） | ✅ resolve_action | NeonRP 优势 |

**差距影响**:
- 代理不能直接写文件 → 只能通过 proposal 间接修改 `world/` 下的内容
- 不能搜索文件结构 → 不知道项目里有什么
- 不能交互式提问 → 不能实现"给你4个选项，选一个"的 RP 体验
- 不能调用子代理 → 回到差距 1

**需要什么**:
1. `write_file` skill：在权限范围内直接写入文件
2. `edit_file` skill：精确替换文件内容
3. `glob` skill：搜索匹配模式的文件
4. `grep` skill：搜索文件内容
5. `task` skill：调用子代理（关联差距 1）
6. `ask_user` skill：向用户展示选项并获取选择

---

### 差距 3：🔴 无结构化交互（CRITICAL）

**参考项目**:
```json
// rpg-orchestrator 使用 AskUserQuestion 工具
{
  "question": "你想做什么？",
  "header": "行动",
  "options": [
    { "label": "进入商店", "description": "浏览商品并购买物资" },
    { "label": "前往公会", "description": "查看任务板" },
    { "label": "休息", "description": "在旅店恢复HP/MP" },
    { "label": "离开城镇", "description": "返回世界地图" }
  ]
}
```

**NeonRP 现状**: TUI 只有自由文本输入框，无结构化选择 UI

**差距影响**:
- 玩家不知道可以做什么 → 每次都要自己想输入什么
- 没有"选择驱动"的游戏流程 → 不像游戏，更像对话
- 没有输入验证 → LLM 难以准确理解自由文本意图

**需要什么**:
1. TUI 层面：选项渲染 + 快捷键选择
2. Skill 层面：`ask_user` 工具让代理能主动提供选项
3. 代理层面：编排器在每回合末尾提供下一步选项

---

### 差距 4：🟡 游戏数据模型过于简化（MAJOR）

**参考项目数据结构**:
```
game/
├── run_state.json          # 会话状态（scope、位置、时间）
├── player/
│   ├── profile.json        # 名字/职业/背景
│   ├── stats.json          # HP/MP/属性/技能
│   ├── inventory.json      # 物品列表 + 容量
│   ├── equipment.json      # 装备栏
│   ├── wallet.json         # 金币/银币/铜币
│   ├── flags.json          # 发现/任务/声望
│   └── journal.md          # 玩家日记
├── towns/T001/
│   ├── town.json           # 城镇元数据
│   ├── town_map.json       # 城镇地图 + 节点发现
│   ├── npcs.json           # NPC 列表
│   ├── quests.json         # 任务注册表
│   └── facilities/         # 设施（公会/商店/旅店）
├── dungeons/D001/
│   ├── layout.json         # 房间拓扑
│   ├── encounter_tables.json  # 遭遇表
│   ├── loot_tables.json    # 掉落表
│   └── rooms/              # 每个房间独立文件
└── lore/                   # 叙事/传闻/笔记
```

**NeonRP 数据结构**:
```
world/
├── character/hero.json     # 所有角色属性在一个文件里
├── item/health-potion.json # 每个物品一个文件
└── location/neon-city.json # 每个地点一个文件
```

**差距分析**:
- NeonRP 的扁平结构缺少 `run_state`（游戏会话状态）
- 没有分离的 player 数据（profile/stats/inventory/equipment 分离）
- 没有任务系统数据结构（quests.json、quest 状态机）
- 没有地点内部结构（城镇地图、设施、房间拓扑）
- 没有遭遇/掉落表（encounter_tables, loot_tables）
- 没有时间系统

**但这不是代码缺陷** — NeonRP 的实体系统足够灵活，可以用 kind 标记存放这些数据。问题是没有模板/示例来展示如何组织复杂游戏数据。

---

### 差距 5：🟡 缺少编排器级游戏循环（MAJOR）

**参考项目的回合结构**:
```
1. 读取 run_state → 确定 scope（世界/城镇/地下城）
2. 根据 scope 路由到专业代理
3. 执行代理 → 返回 PATCH_PLAN + NARRATIVE
4. 合并补丁到游戏文件
5. 推进游戏时间（+10min/+30min/next day）
6. 调用记录代理 → 更新事件日志
7. 调用叙事代理 → 可能推进主线剧情
8. 向玩家展示结果 + 下一步选项
```

**NeonRP 的回合结构**:
```
1. 用户输入 → dispatcher 选择代理
2. 代理 agentic loop → 读取/计算 → submit_proposal
3. validate → apply
4. 显示 diff
```

**缺失**:
- 无 run_state 概念（不知道当前在哪个 scope）
- 无时间推进系统
- 无回合末尾的自动事件记录
- 无自动叙事推进
- 无下一步选项生成

---

### 差距 6：🟡 模型接口不够灵活（MAJOR）

**用户需求**: 子代理能像 OpenCode 一样自定义模型接口

**NeonRP 现状**:
- 全局配置 `config.json` 中 `llm.provider` 和 `llm.model`
- 所有代理共用同一个 LLM provider/model
- 支持 openai/glm 两种 provider
- 无法为不同代理指定不同模型

**需要什么**:
1. **Per-agent model config**: 每个 `agent.json` 可指定自己的 provider/model/base_url
2. **Provider registry**: 支持注册多个 provider（OpenAI/Anthropic/Ollama/自定义）
3. **Base URL 可配置**: 支持任意 OpenAI-compatible 端点
4. **API key 隔离**: 不同 provider 使用不同 key

当前架构已经支持 base_url 和 api_key_env，但缺少 per-agent 配置传递路径：
```python
# agent.json 目前没有 llm 配置
# 需要类似:
{
  "id": "narrator",
  "llm": {
    "provider": "openai",
    "model": "gpt-4o",
    "base_url": "https://custom-endpoint.com/v1"
  }
}
```

---

## 四、NeonRP 的优势（参考项目不具备的）

| 能力 | NeonRP | 参考项目 |
|------|--------|----------|
| **版本控制** | save/load/undo/redo/branch | ❌ 无 |
| **沙箱实验** | sandbox new/switch/drop | ❌ 无 |
| **确定性重放** | replay verify/checkout | ❌ 无 |
| **验证管线** | JSON schema + rules engine | ❌ 无（靠 prompt 约束） |
| **原子操作** | staging → validate → apply | ❌ 直接写文件 |
| **审计日志** | JSONL 全程记录 | ❌ 仅 notes.md |
| **检查点系统** | 每次提交前自动存档 | ❌ 无 |
| **权限模型** | deny-first glob 匹配 | 📝 contracts.md（约定而非强制） |
| **TUI 界面** | Textual 4 面板布局 | ❌ 依赖 Claude Code CLI |
| **流式输出** | chat_stream + TUI 渲染 | ❌ 依赖 Claude Code |
| **独立运行** | 自带 CLI + TUI，不依赖 Claude Code | 🔴 必须在 Claude Code 内运行 |

**这些优势非常有价值。** 参考项目完全依赖 Claude Code 运行时，NeonRP 是独立工具。

---

## 五、M8 建议路线图：弥合差距

### Phase 1: 通用工具系统（解决差距 2）

**目标**: 让代理拥有 Read/Write/Edit/Glob/Grep 等通用能力

新增 skills:
```python
SKILL_SCHEMAS = {
    # 现有 skills 保留
    "read_file": ...,
    "find": ...,
    "read_context": ...,
    "list_entities": ...,
    "resolve_action": ...,
    "submit_proposal": ...,

    # 新增通用工具
    "write_file": {
        "name": "write_file",
        "description": "Write content to a file (within write permissions)",
        "parameters": {
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"}
            },
            "required": ["path", "content"]
        }
    },
    "edit_file": {
        "name": "edit_file",
        "description": "Replace exact text in a file",
        "parameters": {
            "properties": {
                "path": {"type": "string"},
                "old_text": {"type": "string"},
                "new_text": {"type": "string"}
            },
            "required": ["path", "old_text", "new_text"]
        }
    },
    "glob": {
        "name": "glob",
        "description": "Find files matching a glob pattern",
        "parameters": {
            "properties": {
                "pattern": {"type": "string"},
                "path": {"type": "string"}
            },
            "required": ["pattern"]
        }
    },
    "grep": {
        "name": "grep",
        "description": "Search file contents for a pattern",
        "parameters": {
            "properties": {
                "pattern": {"type": "string"},
                "path": {"type": "string"},
                "glob": {"type": "string"}
            },
            "required": ["pattern"]
        }
    },
    "ask_user": {
        "name": "ask_user",
        "description": "Ask the player a question with structured options",
        "parameters": {
            "properties": {
                "question": {"type": "string"},
                "options": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "label": {"type": "string"},
                            "description": {"type": "string"}
                        }
                    }
                }
            },
            "required": ["question", "options"]
        }
    }
}
```

**关键设计决策**:
- `write_file` 和 `edit_file` 需要遵循 `write_globs` 权限
- 可选择是否绕过 proposal 管线（配置项：`direct_write: true/false`）
- `ask_user` 需要 TUI 层支持渲染选项

### Phase 2: 子代理 + Task 工具（解决差距 1）

**目标**: 实现代理调用代理的编排模式

```python
"task": {
    "name": "task",
    "description": "Spawn a sub-agent to handle a specific task",
    "parameters": {
        "properties": {
            "agent_id": {"type": "string", "description": "Sub-agent to invoke"},
            "prompt": {"type": "string", "description": "Task description for sub-agent"},
            "context": {"type": "object", "description": "Context to pass to sub-agent"}
        },
        "required": ["agent_id", "prompt"]
    }
}
```

**实现要点**:
- Task skill 在 `_execute_tool` 中递归调用 `run_agent_agentic()`
- 子代理有自己的 SkillRegistry 实例（上下文隔离）
- 子代理结果序列化后返回给父代理
- 深度限制：防止无限递归（max_depth=3）
- 子代理可以有不同的 LLM 配置（关联差距 6）

### Phase 3: Per-Agent 模型配置（解决差距 6）

**目标**: 每个代理可以使用不同的 LLM provider/model

```json
// agents/narrator/agent.json
{
  "id": "narrator",
  "llm": {
    "provider": "openai",
    "model": "gpt-4o",
    "temperature": 0.9
  }
}

// agents/combat/agent.json
{
  "id": "combat",
  "llm": {
    "provider": "openai",
    "model": "gpt-4o-mini",
    "temperature": 0.3
  }
}

// agents/world-builder/agent.json
{
  "id": "world-builder",
  "llm": {
    "provider": "custom",
    "base_url": "http://localhost:11434/v1",
    "model": "llama3",
    "api_key": "ollama"
  }
}
```

**实现要点**:
- `agent_runner.py` 读取 agent.json 中的 llm 配置
- 如果 agent.json 没有 llm 配置，fallback 到全局 config.json
- Provider registry 支持动态注册
- 支持任意 OpenAI-compatible 端点

### Phase 4: 游戏循环增强（解决差距 3 & 5）

**目标**: 实现编排器级游戏循环 + 结构化交互

1. **引入 run_state 概念**:
```json
// .neonrp/run_state.json
{
  "scope": "town",
  "location": {"node_id": "T001", "subnode": "main_street"},
  "time": {"day": 1, "clock": "08:50"},
  "pending_actions": [],
  "last_action": "enter_town"
}
```

2. **编排器代理模板**: 提供一个 orchestrator agent 模板
3. **TUI ask_user 渲染**: 当代理调用 `ask_user` 时，TUI 渲染选项按钮
4. **回合末尾钩子**: 代理可配置 `post_turn_hooks`（自动调记录代理等）

### Phase 5: 丰富游戏模板（解决差距 4）

**目标**: 提供 Claude Code RP 级别的游戏数据模板

- 更新 `neonrp game new --template rpg-full` 生成完整数据结构
- 包含 player/, towns/, dungeons/, lore/, rules/
- 包含 orchestrator + 多个专业代理
- 每个代理有详细的中文 system prompt

---

## 六、实施优先级矩阵

```
                    高影响
                      │
    Phase 1           │          Phase 2
    (通用工具)        │          (子代理/Task)
                      │
  ────────────────────┼────────────────────
                      │
    Phase 3           │          Phase 4 + 5
    (模型配置)        │          (游戏循环+模板)
                      │
                    低影响
     低复杂度 ────────┼──────── 高复杂度
```

**推荐顺序**: Phase 1 → Phase 2 → Phase 3 → Phase 4 → Phase 5

Phase 1 + 2 完成后，差距评分应从 45/100 提升到约 **75/100**。
Phase 3 + 4 + 5 完成后，应达到 **90/100** 或以上。

---

## 七、代码层面的具体问题

### 7.1 Dispatcher 不是 Orchestrator

当前 `dispatcher.py` 的 `dispatch()` 函数只是选择代理然后运行：
```python
def dispatch(root, query, agent_id=None, ...):
    specs = load_agent_specs(root)
    selected_id = select_agent(query, specs, agent_id)
    run_result = run_agent_agentic(root, selected_id, query)
    return DispatchResult(...)
```

这不能实现"读 run_state → 路由 → 调用多个子代理 → 合并结果 → 推进时间"的编排循环。编排逻辑应在代理的 system prompt + Task 工具内实现，而非硬编码在 Python 中。

### 7.2 Skills 与 Proposal 管线的矛盾

NeonRP 的核心设计是：所有文件变更通过 `submit_proposal → staging → validate → apply`。
但通用工具（write_file/edit_file）暗示直接写入文件。

**建议**: 提供两种模式
1. **Proposal 模式**（默认）：通过 submit_proposal，适合需要验证的游戏状态变更
2. **Direct 模式**（可选）：通过 write_file/edit_file，适合辅助文件（lore/notes/journal）

通过 agent.json 的 `permissions.direct_write_globs` 控制哪些路径允许直接写入。

### 7.3 Session 没有与游戏状态关联

当前 session 只记录对话历史（user/assistant），不关联游戏状态。
参考项目的 `run_state.json` 记录了 scope/location/time，session 恢复时能回到正确的游戏状态。

### 7.4 Agent 定义格式差异

NeonRP agent 定义：`agents/<id>/agent.json` + `agents/<id>/system.md`
参考项目 agent 定义：`.claude/agents/<id>.md`（YAML frontmatter + markdown body）

两种方式各有优劣。NeonRP 的分离式更好维护，但需要确保 system prompt 足够丰富。

---

## 八、总结

### NeonRP 已经建好的（保持）
- ✅ 原子操作 + staging 管线（核心优势）
- ✅ 版本控制（save/load/undo/redo/branch/sandbox/replay）
- ✅ JSON schema + rules 验证
- ✅ 审计日志
- ✅ TUI 界面
- ✅ 流式输出
- ✅ LLM 重试 + 错误分类
- ✅ 538 个测试

### NeonRP 还需要建的（按优先级）
1. 🔴 **通用工具系统** — write_file, edit_file, glob, grep, ask_user
2. 🔴 **Task 子代理** — 代理调用代理，编排器模式
3. 🔴 **结构化交互** — ask_user + TUI 选项渲染
4. 🟡 **Per-agent 模型配置** — 每个代理可用不同 LLM
5. 🟡 **游戏状态管理** — run_state + 时间系统
6. 🟡 **丰富游戏模板** — 完整 RPG 数据结构 + 多代理模板
7. 🟢 **Provider 扩展** — Anthropic/Ollama/自定义端点支持

**核心信息**: NeonRP 的基础设施层（安全/版本控制/审计）是参考项目完全没有的，这是独特价值。但要达到"玩 RP 游戏"的体验，需要补齐工具层和编排层。这不是推倒重来，而是在现有坚实基础上搭建上层能力。
