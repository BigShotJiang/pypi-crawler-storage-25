# NeonRP vs Claude Code 差距评估（M9 后）

日期：2026-02-08

---

## M9 实现概况

| 模块 | 行数 | 状态 |
|------|-----|------|
| conversation.py | 590 | 完整，三模式（build/sandbox/play） |
| todo.py | 96 | 完整，移植自 learn-claude-code v2 |
| skill_loader.py | 139 | 完整，YAML frontmatter + 3 个预置 skill |
| prompts.py | 99 | 完整，模式感知 system prompt |
| app_v2.py | 677 | 完整，单面板对话 TUI |
| tui.py (CLI入口) | 43 | 完整，--legacy 标志 |
| 测试总数 | 657 | 通过 |

---

## 核心体验对比

### 已达到 Claude Code 水平的能力

| 能力 | Claude Code | NeonRP M9 | 评分 |
|------|------------|-----------|------|
| **对话循环** | while True + tool call loop | `run_conversation_turn()` 多轮工具调用 | **90%** |
| **流式输出** | token-by-token | `on_chunk` 回调 + RichLog 渲染 | **85%** |
| **文件读写工具** | Read/Write/Edit/Glob/Grep | read_file/write_file/edit_file/glob/grep | **90%** |
| **TodoWrite** | 内置任务规划工具 | TodoManager，完整移植 | **95%** |
| **Skills/知识注入** | SKILL.md + 渐进式加载 | SkillLoader，Layer 1/2 策略 | **85%** |
| **子代理** | Task tool + 深度限制 | M8 已实现，2 层深度 | **80%** |
| **会话持久化** | --resume / --continue | session.py JSONL，跨轮恢复 | **80%** |
| **权限系统** | allowedTools / deny-first | direct_write_globs / deny globs | **85%** |
| **System Prompt** | 丰富的工具描述+规则 | `build_system_prompt()` 模式感知 | **80%** |

### 仍有显著差距的能力

| 能力 | Claude Code | NeonRP M9 | 差距 | 严重度 |
|------|------------|-----------|------|--------|
| **ask_user 交互** | 模态对话 + 选项 | TUI 中返回空字符串（未实现） | 用户无法回答代理问题 | **高** |
| **上下文压缩** | auto-compaction at 95% + /compact | `_truncate_messages_for_budget()` 简单截断 | 长对话质量下降 | **中** |
| **Bash 工具** | 执行任意 shell 命令 | 无 | 代理无法运行命令 | **中** |
| **Markdown 渲染** | 终端 rich markdown | RichLog 纯文本 | 叙事可读性差 | **低** |
| **MCP 集成** | 数百个外部工具服务器 | 无 | 不可扩展到外部工具 | **低**（RPG场景不急需） |
| **Hooks** | PreToolUse/PostToolUse 生命周期 | 无 | 无自动化工作流 | **低** |
| **IDE 集成** | VSCode 原生扩展 | 无 | 仅终端模式 | **低**（RPG场景不需要） |
| **会话分叉** | --fork-session | 无 | 无法从历史点分叉对话 | **低** |

### NeonRP 超越 Claude Code 的能力

| 能力 | Claude Code | NeonRP | 说明 |
|------|------------|--------|------|
| **事件溯源** | 无 | 完整 append-only event log | 所有变更可追溯 |
| **确定性重放** | 无 | `replay verify` | 可验证重放一致性 |
| **沙盒分支** | 无（仅 session） | `sandbox new/switch/drop` | 隔离实验环境 |
| **Proposal 管线** | 无 | Plan→Diff→Validate→Apply | 变更可审计 |
| **检查点恢复** | 无 | `save/load` + auto checkpoint | 世界状态快照 |
| **游戏规则引擎** | 无 | `rules.py` + `resolve_action` | 确定性机制判定 |
| **实体索引** | 无 | `index build/update` + `find/context` | 快速实体检索 |
| **三模式系统** | 单一模式 | Build/Sandbox/Play | 场景化体验 |

---

## 综合评分

| 维度 | M8 评分 | M9 评分 | 说明 |
|------|--------|--------|------|
| 对话循环 | 0/20 | **18/20** | 核心循环完整，ask_user 未完成 |
| 流式输出 | 5/15 | **13/15** | on_chunk + TUI 渲染完整 |
| 工具系统 | 12/15 | **14/15** | 全面，缺 Bash |
| 任务规划 | 0/10 | **9/10** | TodoManager 完整 |
| 知识注入 | 0/10 | **8/10** | SkillLoader + 3 个预置 skill |
| TUI 体验 | 8/15 | **13/15** | 单面板对话式，缺 markdown 渲染 |
| 会话管理 | 5/15 | **12/15** | 持久化 + 恢复，缺压缩 |
| **总分** | **30/100** | **87/100** | 从不可用到基本可用 |

---

## 剩余差距优先级排序

### P0（阻塞实际游玩）

1. **ask_user 未在 TUI 实现** — `app_v2.py:539` 返回空字符串。代理问玩家问题时无法得到回答。修复量：~30 行。

### P1（影响体验质量）

2. **Markdown 渲染** — 叙事输出是纯文本，RPG 需要格式化文本。RichLog 原生支持 markdown，开启即可。~5 行。
3. **上下文压缩** — 当前简单截断，长对话会丢失重要信息。需要 /compact 命令或自动摘要。~100 行。
4. **对话统计** — 无 turn count / token usage / timing 可见性。review 建议的 /stats 命令。~30 行。

### P2（增强功能）

5. **Bash 工具** — 代理无法运行 shell 命令（如 dice roller 脚本）。
6. **会话分叉** — 从对话历史某一点创建分支。
7. **插件/MCP** — 外部工具集成。

---

## M9 Review 遗留项

来源：`reviews/M9_review_20260207.md`

| 编号 | 类型 | 描述 | 状态 |
|------|------|------|------|
| 1 | must-fix | Todo status mismatch：TUI 检查 `"done"` 但 TodoManager 发出 `"completed"` | 待确认是否已修复 |
| 2 | should-fix | SkillLoader reload 每次重新解析，可加 mtime 缓存 | 未修复 |
| 3 | should-fix | TodoManager 验证错误应包含实际无效值 | 未修复 |
| 4 | nice-to-have | TUI 添加快捷键提示 | 未修复 |
| 5 | nice-to-have | 启用 markdown 渲染 | 未修复 |
| 6 | nice-to-have | 对话统计 /stats 命令 | 未修复 |

---

## 结论

**M9 完成了从 30 分到 87 分的跨越。** 核心对话循环、流式输出、TodoManager、Skills 系统全部到位。NeonRP 在 RPG 特有维度（事件溯源、沙盒、重放、规则引擎）远超 Claude Code。

最关键的一个残留问题是 **ask_user 在 TUI 中未实现**（~30 行修复），修复后即可进行真正的交互式游戏。

如果将 P0 + P1 全部修复（估计 ~165 行），评分可达 **92-95/100**。
