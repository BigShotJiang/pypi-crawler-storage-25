# NeonRP 诊断报告

## 一句话总结

**NeonRP 建成了一个"提案审批系统"，而用户需要的是一个"对话系统"。**

---

## 1. 用户到底想要什么

用户的原始体验是在 Claude Code 中玩 RPG（`llm-rpg-starter-sample`）。那个体验是：

```
你输入 → Claude 回复叙事文字 + 自动读写游戏文件 → 你看到故事推进 → 你继续输入 → 循环
```

这就是一个**对话循环**。Claude Code 本身提供了：
- 持久的对话上下文（整个会话期间模型记住所有历史）
- 直接读写文件的能力（Read/Write/Edit 工具）
- 流式输出（打字机效果）
- 子代理调度（Task 工具调用不同的 agent）
- 交互式提问（AskUserQuestion）

`llm-rpg-starter-sample` 本质上是一个**提示工程项目**，不是软件项目。它的所有 "代码" 都是 `.claude/agents/*.md` 文件——纯文本的 system prompt。运行时是 Claude Code 在驱动一切。

---

## 2. learn-claude-code 教了什么

这个参考项目用 200 行 Python 实现了一个完整的 AI agent：

```python
# 核心循环（伪代码）
while True:
    user_input = input("> ")
    messages.append({"role": "user", "content": user_input})

    while True:  # agent 内循环
        response = client.messages.create(model, system, messages, tools)

        # 打印文字
        for block in response.content:
            if hasattr(block, "text"):
                print(block.text)

        # 如果没有工具调用，本轮结束
        if response.stop_reason != "tool_use":
            break

        # 执行工具，把结果喂回去
        results = execute_tools(response)
        messages.append({"role": "assistant", "content": response.content})
        messages.append({"role": "user", "content": results})
```

**关键特征：**
- 直接调 Anthropic API（`client.messages.create`）
- 工具执行后结果立即喂回模型
- 模型自己决定什么时候停（`stop_reason != "tool_use"`）
- **对话历史在整个会话期间持久存在**
- 无需 "提案" 或 "审批"——模型直接读写文件

---

## 3. NeonRP 实际建了什么

### 架构对比

| 维度 | Claude Code / learn-claude-code | NeonRP |
|------|------|--------|
| 核心循环 | `while True: call_llm → exec_tools → loop` | `dispatch → run_agent_agentic → submit_proposal → validate → apply` |
| 模型交互 | 持续对话，累积上下文 | **每次 `run` 是独立的一次性调用** |
| 文件操作 | 模型直接读/写文件 | 模型必须构建 Proposal JSON → 系统验证 → 用户审批 → 系统应用 |
| 用户体验 | 打字 → 看到叙事 → 打字 → 循环 | `neonrp run "query" --agentic --apply` → 看到 JSON diff → 手动按 'a' 应用 |
| 对话连续性 | 整个会话共享历史 | **每次 run 重新开始，无历史** |
| 输出 | 叙事文字 + 工具动作交织 | Proposal rationale（一段干巴巴的理由） |
| 停止条件 | 模型自己决定 | **模型必须调 `submit_proposal` 才算完成** |

### 运行流程对比

**用户想要的（Claude Code 体验）：**
```
> 我走进酒馆
🎭 推门而入，昏暗的灯光下，酒馆弥漫着麦酒的气息。
   角落里坐着一个老者，目光锐利地看着你。
   吧台后的酒保擦着杯子，头也不抬地说："来点什么？"

> 和老者说话
🎭 你走向角落，老者放下酒杯...
   "年轻人，我等你很久了。北方的迷雾里有东西在苏醒..."
   [游戏文件已自动更新：player.location = "tavern", flags.met_sage = true]
```

**NeonRP 实际给的：**
```
$ neonrp run "我走进酒馆" --agentic
Agent: narrator
Run ID: narrator_20260207_143000_abc
Turns: 2

Proposal: 1 changes
  Modified: player/player.json

--- Diff Preview ---
- "location": "start-town"
+ "location": "tavern"

Logs: .neonrp/logs/agents/narrator_20260207_143000_abc/
```

没有叙事。没有对话。没有沉浸感。只有冷冰冰的 JSON diff。

---

## 4. 根本问题诊断

### P0: 没有对话循环（致命）

NeonRP 没有 `while True` 的用户对话循环。每次交互是：
1. 用户输入命令
2. 系统执行一次 agent run
3. Agent 提交一个 Proposal
4. 结束

下一次输入完全独立——没有历史，没有上下文，没有"会话"概念。

**TUI 中虽然有 session 持久化，但 session 只保存文本记录用于显示，不会把历史 messages 喂回给 LLM。** 每次 dispatch 调用都是一个全新的对话。

### P1: Proposal 系统是反模式（致命）

Agent 不能直接修改游戏世界。它必须：
1. 构造 `submit_proposal` 的 JSON 参数
2. 系统解析 Proposal
3. 系统在 staging 目录验证
4. 用户手动确认（或开 auto-apply）
5. 系统原子提交

这在 **企业级代码审查工具** 中是正确设计。在 **RPG 游戏** 中，这意味着：
- 模型的创造力被迫转化为 JSON ops
- 叙事和世界变更是**分离的**（rationale ≠ 叙事）
- 每轮交互延迟巨大（验证 + 审批）
- 模型花大量 token 在构造正确的 Proposal JSON 格式上

### P2: 默认使用 stub provider（致命）

`my-rpg/.neonrp/config.json` 中 `"provider": "stub"`。Stub adapter 返回的是硬编码的假数据，不是真正的 LLM 响应。用户首次运行就会发现完全没有 AI。

### P3: 叙事输出被吞掉

Agent 的 system prompt 说 "Stay in character as a narrator -- describe outcomes vividly"。但系统只关心 `submit_proposal` 的结构化输出。Agent 在工具调用之间说的叙事文字，在 CLI 模式下根本不显示；在 TUI 模式下只作为 streaming chunks 短暂显示，不是正式的游戏输出。

### P4: 系统prompt 指向不存在的工具

Narrator 的 system.md 列出了 `write_file`, `edit_file`, `glob`, `grep` 等工具，但 `SkillRegistry` 实际注册的工具只有 `read_context`, `find`, `read_file`, `list_entities`, `submit_proposal`, `resolve_action`, `ask_user`, `task`。大部分工具名对不上。

### P5: 过度工程

为了"硬核RPG CLI"，NeonRP 建了：
- Event sourcing（事件日志 + 检查点）
- 分支系统（类 git 的 branch/undo/redo）
- 权限系统（read_globs/write_globs/deny_globs）
- Proposal 验证管线（staging → validate → commit）
- 实体索引与检索系统
- Session 持久化
- Sandbox 隔离
- Replay 验证
- 多 agent 调度器（trigger patterns + tag matching + priority）

这些功能都是 M1-M8 的里程碑产出。但核心问题是：**连最基本的对话循环都没有**。

---

## 5. 对比三个项目

```
┌──────────────────────────────────────────────────────────────────┐
│                                                                  │
│  llm-rpg-starter-sample (原始体验)                                │
│  ─────────────────────────────────                               │
│  • 运行在 Claude Code 内部                                        │
│  • 0 行应用代码（全部是 .md prompt）                                │
│  • Claude Code 提供: 对话循环 + 工具 + 流式输出 + 子代理            │
│  • 效果: ✅ 可以玩                                                │
│                                                                  │
│  learn-claude-code (参考实现)                                      │
│  ──────────────────────────                                      │
│  • 独立 Python 脚本                                               │
│  • 200 行核心代码                                                  │
│  • 自己实现: 对话循环 + Anthropic API + 4个工具                     │
│  • 效果: ✅ 可以对话                                               │
│                                                                  │
│  NeonRP (当前项目)                                                 │
│  ──────────────                                                  │
│  • 复杂的 Python 包（20+ 模块，626 测试）                           │
│  • 事件溯源 + 提案审批 + 分支管理 + 权限系统                        │
│  • 缺失: 对话循环、对话历史、直接文件操作、叙事输出                   │
│  • 效果: ❌ 无法进行一次对话                                        │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

## 6. 缺失清单

| # | 缺失项 | 严重度 | 说明 |
|---|--------|--------|------|
| 1 | **对话循环** | 致命 | 没有持续的 input→response→input 循环 |
| 2 | **对话历史持久化到 LLM** | 致命 | 每次 run 都是全新上下文，模型不记得之前说过什么 |
| 3 | **直接文件读写（非 Proposal）** | 致命 | 模型应该能直接修改游戏文件，像 Claude Code 一样 |
| 4 | **叙事输出作为主要输出** | 致命 | 用户看到的应该是故事文字，不是 JSON diff |
| 5 | **真实 LLM 默认配置** | 严重 | 默认 stub provider 让用户首次体验为零 |
| 6 | **run_state.json（游戏状态机）** | 严重 | 没有 scope/location/time 等游戏循环状态 |
| 7 | **工具名一致性** | 严重 | system.md 列的工具与实际注册工具不匹配 |
| 8 | **流式叙事显示** | 中等 | TUI 中应像 Claude Code 一样逐字显示叙事 |
| 9 | **游戏循环（scope routing）** | 中等 | 缺少 world/town/dungeon 的状态机路由 |

---

## 7. 核心修复方向

要让 NeonRP 能"玩起来"，最小可行修复是：

### 方案 A: 最小化改造（推荐）

借鉴 `learn-claude-code` v1 的模式，在现有架构旁边建一个**对话模式**：

1. **新增 `neonrp chat` 命令**（或让 TUI 默认进入此模式）
2. **维持对话历史**：`messages` 列表在整个会话期间累积
3. **让模型直接读写文件**：不走 Proposal，用 `read_file` + `write_file` + `edit_file`
4. **打印模型的文字输出**：叙事文字就是主输出
5. **保留现有 Proposal 系统**作为可选的"严格模式"

核心代码量：~150 行（一个新的 `chat_loop` 函数）。

### 方案 B: 全面重构

把整个 agent_runner 改成对话模式优先，Proposal 作为可选层。工程量大，但更干净。

---

## 8. 一个残酷的比喻

`learn-claude-code` 的 v1 用 200 行实现了完整的 Claude Code 对话体验。

NeonRP 用 8 个里程碑、20+ 个模块、626 个测试、构建了一个精密的提案审批管线——然后发现用户只想聊天。

这不是代码质量问题。代码写得很好，测试很全面，架构设计考虑了很多边界情况。
问题是：**方向错了**。

NeonRP 把 Claude Code 的基础设施层（事件溯源、权限、分支）当成了核心功能来实现，却跳过了 Claude Code 最基本的功能：**让模型和人持续对话**。

---

## 9. 下一步建议

1. 先让一个最简单的对话能跑起来（方案 A 的第 1-4 步）
2. 配置一个真实的 LLM provider（Anthropic / OpenAI）
3. 在对话模式中验证游戏体验
4. 然后再考虑哪些现有功能（事件溯源、分支等）值得整合进对话模式
