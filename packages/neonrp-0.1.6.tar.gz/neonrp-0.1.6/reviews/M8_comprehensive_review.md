# NeonRP M8 全面审查：与 Claude Code RP 体验的差距分析（M8 后）

**审查日期**: 2026-02-03
**审查目标**: 评估 M8 完成后 NeonRP 距离 Claude Code 原生 RP 游戏体验还有多远
**参考基线**: M7 审查评分 45/100；M7 审查预期 M8（Phase 1+2）完成后达到 ~75/100
**参考项目**: `llm-rpg-starter-sample` (Claude Code 原生 RP 实现)

---

## 一、核心结论

**M8 成功地将 NeonRP 从"RP 引擎基础设施"升级为"代理平台"。** M7 审查中识别的 6 大差距中，前 3 个（最高优先级）已在 M8 中得到实质性解决。

**差距评分（排除模型因素）**: **70/100**（M7 时为 45/100，提升 25 分）

| 维度 | M7 评分 | M8 评分 | 变化 | 说明 |
|------|---------|---------|------|------|
| 基础设施层（版本控制/安全/审计）| 95/100 | 95/100 | → | 保持优势 |
| 核心 RP 游戏循环 | 25/100 | 40/100 | +15 | agentic loop 已有（M6），但仍缺 run_state/时间系统 |
| 工具能力层 | 30/100 | 85/100 | **+55** | **最大进步**：12 个 skills，覆盖 Read/Write/Edit/Glob/Grep/Task/AskUser |
| 子代理架构 | 15/100 | 70/100 | **+55** | task tool + 2 层深度 + 编排器示例 |
| 交互体验层 | 40/100 | 60/100 | +20 | ask_user + CLI/TUI 回调，但 TUI 选项渲染仍偏简 |

---

## 二、M7 六大差距逐项对照

### 差距 1：🔴→🟡 子代理编排架构（原 CRITICAL → 部分解决）

**M7 时状态**: Dispatcher 只选择单一代理运行，无 agent-calls-agent 模式。
**M8 后状态**:
- ✅ `task` tool 实现，代理可递归调用其他代理
- ✅ 2 层深度限制，depth≥1 时 `task` tool 从 schema 中过滤
- ✅ 子代理有独立 SkillRegistry、独立 messages、独立审计日志
- ✅ `SubAgentState` dataclass 定义（序列化框架）
- ✅ `max_sub_agent_depth` 可配置且被 agent_runner 读取
- ✅ `examples/multi-agent/` 提供 orchestrator + narrator 示例
- ⚠️ **Resume 未实现**：`SubAgentState` 仅有 dataclass 定义，无 save/load 实现
- ⚠️ **子代理 proposal 不会被父代理合并**：子代理执行结果仅返回 metadata（run_id, success, error），父代理无法直接获取子代理的 proposal/ops 内容来合并

**评估**: 核心的"编排器→子代理"模式已可运行，但尚未达到"编排器读状态→路由到专业代理→**合并多个代理结果**"的完整模式。子代理返回的是 success/error 而非 PATCH_PLAN，父代理无法基于子代理结果做进一步编排。

**剩余工作**:
1. Resume 机制（SubAgentState save/load/rotate）
2. 子代理 proposal 结果透传给父代理（允许父代理读取/合并子代理的 ops）
3. 多子代理结果合并模式

---

### 差距 2：🔴→✅ 工具集不足（原 CRITICAL → 基本解决）

**M7 时状态**: 6 个受限 skills（read_file, find, read_context, list_entities, resolve_action, submit_proposal）
**M8 后状态**: 12 个 skills，对照参考项目工具集完整性：

| 能力 | Claude Code RP | NeonRP M8 | 状态 |
|------|---------------|-----------|------|
| 读取文件 | ✅ Read | ✅ read_file | ✅ 对齐 |
| **写入文件** | ✅ Write | ✅ write_file（dual-mode） | ✅ 对齐 |
| **编辑文件** | ✅ Edit | ✅ edit_file（exact match） | ✅ 对齐 |
| **文件搜索** | ✅ Glob | ✅ glob（max 200 results） | ✅ 对齐 |
| **内容搜索** | ✅ Grep | ✅ grep（regex, max 50 results） | ✅ 对齐 |
| **调用子代理** | ✅ Task | ✅ task（2 层深度） | ✅ 对齐 |
| **交互式提问** | ✅ AskUserQuestion | ✅ ask_user（sentinel + callback） | ✅ 对齐 |
| 实体检索 | ❌ 无 | ✅ read_context, find, list_entities | NeonRP 优势 |
| 机械计算 | ❌ 无 | ✅ resolve_action | NeonRP 优势 |

**评估**: 工具集已完全覆盖参考项目的所有能力，且有额外优势（实体检索、规则引擎）。Dual-mode write 设计优雅——`world/` 变更走 proposal pipeline 保证安全，辅助文件（lore/notes）走 direct write 保证效率。

---

### 差距 3：🔴→🟡 无结构化交互（原 CRITICAL → 部分解决）

**M7 时状态**: TUI 只有自由文本输入框，无结构化选择。
**M8 后状态**:
- ✅ `ask_user` skill 允许代理向用户展示问题 + 选项
- ✅ Sentinel 协议 + on_ask_user callback 实现
- ✅ CLI 模式使用 `click.prompt()` 渲染
- ⚠️ **TUI 选项渲染仍然偏简**：callback 机制存在，但 TUI 端的选项按钮/快捷键选择 UI 可能仅为文本形式

**评估**: 骨架已就位，核心的"代理主动提供选项→用户选择→结果注入"链路完整。但距离"4 个精美选项按钮+快捷键"的游戏体验仍有差距。

**剩余工作**:
1. TUI 层更丰富的选项渲染（按钮组件/快捷键映射）
2. 编排器模板在每回合末尾自动调用 ask_user 提供下一步选项

---

### 差距 4：🟡→🟡 游戏数据模型过于简化（原 MAJOR → 未变化）

M8 不以此为目标。`examples/multi-agent/` 引入了 `world/run_state/game-state.json`（scope/location/time 概念的萌芽），但还不是完整的游戏状态系统。

**仍然缺失**:
- 分离的 player 数据（profile/stats/inventory/equipment）
- 任务系统（quests.json）
- 地点内部结构（城镇地图/设施/房间拓扑）
- 遭遇/掉落表

**评估**: 这属于 M9 的"丰富游戏模板"范畴。M8 的 run_state 示例是正确方向的第一步。

---

### 差距 5：🟡→🟡 缺少编排器级游戏循环（原 MAJOR → 有改善但未达标）

**M7 时状态**: 无 run_state 概念，无时间推进，无自动事件记录。
**M8 后状态**:
- ✅ 编排器代理示例存在（`examples/multi-agent/agents/orchestrator/`）
- ✅ 编排器可通过 task + ask_user 实现路由→子代理→结构化交互的循环
- ⚠️ **编排逻辑在 prompt 中而非代码中**——这是正确的设计（与参考项目一致），但没有默认模板来演示完整循环
- ⚠️ **缺少**：run_state 读/写、时间推进 hooks、回合末尾自动记录

**评估**: 基础设施已就位（task + ask_user + session persistence），但"编排器读 run_state → 路由 → 调子代理 → 合并 → 推时间 → 记录 → 展示选项"的完整循环还需要 M9 的模板和 hooks。

---

### 差距 6：🟡→✅ 模型接口不够灵活（原 MAJOR → 基本解决）

**M7 时状态**: 所有代理共用同一个 LLM provider/model。
**M8 后状态**:
- ✅ `ProviderConfig` dataclass 支持 provider/model/temperature/base_url/api_key_env
- ✅ `config.json` `providers` 字典支持命名配置（fast/strong/local 等）
- ✅ `agent.json` `llm` 块支持 `provider_ref`（引用命名配置）和 inline 配置
- ✅ 优先级链完整：CLI > agent inline > agent provider_ref > global config
- ✅ `get_adapter_from_config()` 工厂函数从 ProviderConfig 创建 adapter
- ✅ 子代理独立解析自己的 LLM config（orchestrator 用 GPT-4o，narrator 用 GPT-4o-mini）
- ✅ 示例中 orchestrator 用 `strong`，narrator 用 `fast`
- ✅ 22 个专项测试覆盖各种优先级组合

**评估**: 完全解决。灵活度已达 OpenCode 水平。

---

## 三、代码质量评估

### 3.1 测试覆盖

| 测试文件 | 测试数 | 覆盖范围 |
|----------|--------|----------|
| test_write_skills.py | 19 | write_file/edit_file 权限、原子写入、安全检查 |
| test_search_skills.py (glob/grep) | 20 | glob/grep 模式匹配、权限过滤、结果上限 |
| test_ask_user.py | 10 | sentinel 协议、回调调用、响应注入 |
| test_sub_agent.py | 9 | task schema、深度过滤、SubAgentState |
| test_per_agent_llm.py | 23 | ProviderConfig、优先级链、工厂函数 |
| test_m8_integration.py | 10 | 端到端管线、混合写模式、深度限制 |
| **M8 新增合计** | **91** | — |
| **项目总计** | **626** | 626 passed, 5 skipped |

测试设计质量良好：
- 权限边界测试完整（allow/deny/required_deny/traversal）
- 工具参数验证测试存在（M7 的 validate_tool_arguments）
- 集成测试覆盖核心管线（provider resolution → task → ask_user → write_modes）

### 3.2 安全性

**已修复问题**（M8 review must-fix）：
1. ✅ **绝对路径逃逸**：`normalize_path()` 现在拒绝 Unix（`/path`）和 Windows（`C:\path`）绝对路径
2. ✅ **max_sub_agent_depth 未被使用**：`run_agent_agentic()` 在 `max_depth=None` 时从 config 读取

**残留问题**：
1. ⚠️ **`apply_overrides()` 不保留 `max_sub_agent_depth`**：
   ```python
   # config.py:175
   return ProjectConfig(llm=llm, tui=tui, providers=config.providers)
   # 缺少 max_sub_agent_depth=config.max_sub_agent_depth
   ```
   当前无活跃调用者（函数未在 src/ 中被调用），但如果未来有人使用此函数，会静默重置深度限制为默认值 2。

2. ⚠️ **Permission error payloads 缺少上下文**（M8 review should-fix，已标记 deferred:M9）：
   `write_file`/`edit_file` 错误仅返回 `perm_result.reason`，不包含 agent_id、目标路径、匹配的 glob、修复建议等完整上下文信息。

3. ⚠️ **子代理 provider 继承问题**：`dispatch()` 将 CLI `--provider` 传给 `run_agent_agentic()`，但子代理的 `task` 调用也会继承这个 CLI override。如果用户 `--provider stub` 调试，子代理也会被强制使用 stub，这可能不是预期行为（当然也可以认为这是合理的调试行为）。

### 3.3 架构评估

**设计决策质量**：

1. **Dual-mode write 是优秀的设计**：在安全（proposal pipeline for game state）和灵活性（direct write for auxiliary）之间取得了正确的平衡。`REQUIRED_DENY_GLOBS` 作为最后防线确保 `.neonrp/` 和 `agents/` 永远不会被直接写入。

2. **ask_user 的 sentinel 协议设计清晰**：`_execute_tool()` 返回 4-tuple `(result, proposal, ask_user_data, task_data)` 是对原有 2-tuple 的自然扩展。代码可读性良好。

3. **task tool 的执行模型正确**：在 `_execute_tool()` 中 special-case 处理（类似 submit_proposal），而非通过 SkillRegistry。递归调用 `run_agent_agentic()` 实现简洁。

4. **ProviderConfig + resolve_provider() 优先级链清晰**：4 级优先级（CLI > inline > ref > global）覆盖了所有合理的使用场景。

**潜在架构风险**：

1. **`_execute_tool()` 返回值越来越复杂**：从最初的 `(result, proposal)` 2-tuple 扩展到 `(result, proposal, ask_user_data, task_data)` 4-tuple。每增加一种特殊工具就要增加一个返回值。考虑是否需要重构为一个 `ToolExecutionResult` dataclass。

2. **run_agent_agentic() 函数已达 ~470 行**：承载了太多职责（agent 加载、LLM 调用、tool 执行循环、streaming、ask_user 处理、task 处理、proposal 解析、diff 生成、apply）。考虑按关注点拆分。

---

## 四、M8 Task Cards 交付对照

| Task | 目标 | 状态 | 备注 |
|------|------|------|------|
| M8-T0 | Specs + ADRs | ✅ | ADR 0021/0022/0023 均已创建，状态 Accepted |
| M8-T1 | write_file + edit_file | ✅ | 19 tests, dual-mode write, atomic writes |
| M8-T2 | glob + grep | ✅ | 20 tests (test_search_skills.py found via grep) |
| M8-T3 | ask_user + TUI/CLI | ✅ | 10 tests, sentinel protocol, callback chain |
| M8-T4 | task + sub-agent | ⚠️ 部分 | 9 tests, depth limit ✅, **resume 未实现** |
| M8-T5 | per-agent LLM | ✅ | 23 tests, provider registry, resolve chain |
| M8-T6 | integration + example | ✅ | 10 tests, examples/multi-agent/ |
| M8-T7 | review gate | ⚠️ 部分 | 已执行 review + 修复 must-fix, 但 ROADMAP 未完全勾选 |

**ROADMAP 勾选状态**：M8 section 中 M8-T6/T7 未勾选，部分 acceptance 条目未勾选：
- ☐ Sub-agent state can be saved and resumed via resume_run_id
- ☐ Each agent can specify its own LLM via llm.provider_ref or inline llm block
- ☐ Provider registry in config.json supports named provider configurations
- ☐ CLI --provider flag overrides per-agent config
- ☐ Orchestrator → sub-agent pipeline works end-to-end with stub provider
- ☐ All 538+ existing tests remain green; 91+ new tests added

实际上大部分这些功能**已经实现并有测试覆盖**，只是 ROADMAP 文件未更新勾选。

---

## 五、NeonRP 当前优势总结

| 能力 | NeonRP (M8) | 参考项目 |
|------|-------------|----------|
| **版本控制** | save/load/undo/redo/branch | ❌ 无 |
| **沙箱实验** | sandbox new/switch/drop | ❌ 无 |
| **确定性重放** | replay verify/checkout | ❌ 无 |
| **验证管线** | JSON schema + rules engine | ❌ 无（靠 prompt 约束） |
| **原子操作** | staging → validate → apply | ❌ 直接写文件 |
| **审计日志** | JSONL 全程记录 | ❌ 仅 notes.md |
| **检查点系统** | 每次 apply 前自动存档 | ❌ 无 |
| **权限模型** | deny-first glob + REQUIRED_DENY_GLOBS | 📝 contracts.md（约定而非强制） |
| **TUI 界面** | Textual 4 面板布局 | ❌ 依赖 Claude Code CLI |
| **流式输出** | chat_stream + TUI 渲染 | ❌ 依赖 Claude Code |
| **独立运行** | 自带 CLI + TUI，不依赖外部 | 🔴 必须在 Claude Code 内运行 |
| **Dual-mode write** | proposal 模式 + direct 模式 | ❌ 只有直接写 |
| **Per-agent LLM** | 每个代理可用不同模型 | ❌ 统一 Claude |
| **子代理编排** | task tool + 2 层深度 | ✅ Task tool + 无限深度 |
| **结构化交互** | ask_user skill | ✅ AskUserQuestion |
| **工具集** | 12 skills（包括 rules engine） | 7 基础工具 |

---

## 六、M9 建议路线图

基于 M8 完成后的差距分析，M9 应聚焦以下 4 个方向：

### Phase 1: 完善子代理编排（填补 M8 剩余）
1. **SubAgentState save/load/rotate** — 实现 resume 机制
2. **子代理 proposal 透传** — 父代理可获取子代理的 ops 列表，决定是否合并/修改/apply
3. **run_agent_agentic() 拆分** — 将 ~470 行函数按关注点拆分

### Phase 2: 游戏循环 + run_state（差距 4+5）
1. **run_state 系统** — `world/run_state/game-state.json`（scope/location/time/pending_actions）
2. **时间推进系统** — 每回合自动推进 in-game 时间
3. **回合末尾钩子** — 自动调用记录代理、叙事推进

### Phase 3: 丰富游戏模板（差距 4）
1. **完整 RPG 数据结构模板** — player/, towns/, dungeons/, lore/, rules/
2. **编排器 + 多专业代理模板** — orchestrator + shop/combat/explore/narrative 代理集
3. **每个代理有详细 system prompt** — 包含领域知识和行为规范

### Phase 4: TUI 体验打磨
1. **ask_user 选项渲染优化** — 按钮组件、快捷键映射
2. **HUD 增强** — run_state 驱动的 HP/Gold/Location/Time 显示
3. **TUI streaming 完善**（如果 M6.5 跳过的 T4 仍需实现）

### 优先级矩阵

```
                    高影响
                      │
    Phase 2           │          Phase 3
    (游戏循环)        │          (模板)
                      │
  ────────────────────┼────────────────────
                      │
    Phase 1           │          Phase 4
    (完善编排)        │          (TUI 打磨)
                      │
                    低影响
     低复杂度 ────────┼──────── 高复杂度
```

**推荐顺序**: Phase 1 → Phase 2 → Phase 3 → Phase 4

Phase 1 + 2 完成后，评分应从 70/100 提升到 **82/100**。
Phase 3 + 4 完成后，应达到 **90/100** 或以上。

---

## 七、总结

### M8 成就
- ✅ **工具层差距几乎消除**：从 6 个 skills 到 12 个，覆盖 Claude Code 的全部工具能力
- ✅ **子代理编排成为可能**：task tool + 2 层深度 + 示例
- ✅ **per-agent LLM 完全解决**：灵活的 3 级配置 + 命名 provider 注册
- ✅ **安全性增强**：绝对路径拒绝 + REQUIRED_DENY_GLOBS + dual-mode write
- ✅ **91 个新测试**（总 626 passed），lint 全部通过
- ✅ **3 份 ADR**（0021/0022/0023）完整记录设计决策

### M8 未完成项
- ⚠️ SubAgentState resume 未实现（dataclass 存在但无 save/load）
- ⚠️ 子代理 proposal 不透传给父代理
- ⚠️ ROADMAP M8 section 勾选未完全更新
- ⚠️ `apply_overrides()` 不保留 `max_sub_agent_depth`
- ⚠️ Permission error payloads 缺少完整上下文（deferred M9）

### 核心信息
M8 是 NeonRP 从"数据管理工具"到"代理平台"的关键转折点。M7 审查预期 Phase 1+2（工具系统+子代理）完成后达到 ~75/100，实际评估为 70/100——略低于预期，主要因为 resume 和 proposal 透传尚未实现。但工具层的 **55 分跃升** 和 per-agent LLM 的完全解决是实质性的进步。

距离"完整 RP 游戏体验"（90/100），核心差距已从"基础能力缺失"（M7 时）转移到"游戏循环和内容模板"（M9 范畴）。这意味着 NeonRP 的平台层已基本就绪，下一阶段应聚焦于**在平台上构建游戏**，而非继续建设平台本身。
