# M8 Hands-On Test Report：按教程走一遍的真实体验

**测试日期**: 2026-02-03
**测试方法**: 从零开始按 TUTORIAL.md 执行每一步，记录所有碰壁点
**测试环境**: Windows (cp932 locale), uv run, NeonRP dev install

---

## 一、总览

按教程走完全流程，发现 **5 个阻断性问题** 和 **8 个显著问题**。测试过 626 个单元测试全部通过，但**真实用户体验和单元测试之间存在显著鸿沟**。

### 阻断性问题（用户无法继续）

| # | 问题 | 影响 | 位置 |
|---|------|------|------|
| **B0** | **包未发布到 PyPI，安装指令全部无效** | `pip install neonrp` 和 `uv tool install neonrp` 均失败，用户在第 0 步就死 | README.md, TUTORIAL.md 安装段 |
| B1 | Windows 非 UTF-8 终端 `✓`/`✗` 字符崩溃 | `--apply` 成功后 crash | agent.py:554, run.py:137, replay.py:101 等 5 个文件 |
| B2 | Tutorial config.json 格式完全错误 | 用户照抄后 LLM 配置失效 | TUTORIAL.md:118-133 |
| B3 | `agent new` 生成的 system.md 极度简陋 | 代理不知道有什么工具可用，实际运行时行为不可预测 | commands/agent.py 模板 |
| B4 | Fixture 格式文档缺失 | 用户无法使用 stub fixture 测试 | CLI_REFERENCE.md, TUTORIAL.md |

### 显著问题（可绕过但体验差）

| # | 问题 | 影响 | 位置 |
|---|------|------|------|
| S1 | Tutorial 提到 `:` 命令，代码已改为 `/` | TUI 文档过时 | TUTORIAL.md:205, TUI_GUIDE.md 全文 |
| S2 | `redo` 始终返回 "No redo checkpoint available" | undo 后无法 redo | branch.py redo 逻辑 |
| S3 | `game new` 不创建 agents 目录 | 新用户不知道需要手动 `agent new` | commands/game.py |
| S4 | Tutorial 的 `find --kind character` 找不到结果 | 模板用 `player`/`npc` 不是 `character` | TUTORIAL.md:91 vs game template |
| S5 | `neonrp run` 默认非 agentic 模式 | 需加 `--agentic` 才有 multi-turn，教程未提及 | TUTORIAL.md:146-153 |
| S6 | `branch` 命令没有 `--list` 选项 | CLI reference 说"Create or switch"，但没列出功能 | branch CLI |
| S7 | stub fixture 必须包含 run_id/agent_id 等元数据 | 上下文字段应由 runner 自动注入 | llm_stub.py `_load_fixture_data()` |
| S8 | `apply_overrides()` 丢失 `max_sub_agent_depth` | 未来如有调用者会静默重置深度 | config.py:175 |

---

## 二、详细发现

### B0: 包未发布，安装不可能成功 🔴🔴

**复现**:
```bash
PS D:\Project\NeonRP\my-rpg> uv tool install neonrp
  × No solution found when resolving dependencies:
  ╰─▶ Because neonrp was not found in the package registry

PS D:\Project\NeonRP\my-rpg> neonrp
failed to locate pyvenv.cfg
```

**根因**: NeonRP 从未发布到 PyPI。Tutorial 和 README 写的 `pip install neonrp` / `uv tool install neonrp` / `pipx install neonrp` **全部无效**。这是比任何代码 bug 更根本的问题——用户在安装步骤就被彻底挡住。

**唯一有效的安装方式**:
```bash
# 从本地源码安装
uv tool install -e d:\Project\NeonRP

# 或开发模式
uv run --project d:\Project\NeonRP neonrp <command>
```

**修复方案**（二选一）:
1. **发布到 PyPI**: `uv build && uv publish`（需要 PyPI 账号和配置）
2. **修正文档**: 将安装说明改为从 git clone + 本地安装

---

### B1: Windows Unicode 崩溃 🔴

**复现**:
```bash
neonrp agent run narrator --query "look around" --provider stub --fixture fixture.json --apply
```

**错误**:
```
UnicodeEncodeError: 'cp932' codec can't encode character '\u2713' in position 0
```

**根因**: `click.echo(f"✓ Applied successfully")` — `✓`(U+2713) 和 `✗`(U+2717) 在 cp932/gbk/euc-kr 等非 UTF-8 Windows 终端无法编码。

**影响范围** (5 个文件):
- `commands/agent.py:289,291,295,359,554,558`
- `commands/run.py:137,139`
- `commands/replay.py:101,137`

**修复**: 将 `✓` 替换为 `[OK]` 或 `√`，`✗` 替换为 `[FAIL]` 或 `X`。或者在 cli.py 入口处设置 `sys.stdout.reconfigure(errors='replace')`。

---

### B2: Tutorial config.json 格式错误 🔴

**Tutorial 写的** (TUTORIAL.md:118-133):
```json
{
  "llm": {
    "default_provider": "openai",
    "providers": {
      "openai": { "api_key_env": "OPENAI_API_KEY", "model": "gpt-4" }
    }
  }
}
```

**实际格式** (`neonrp init` 生成的):
```json
{
  "llm": { "provider": "stub", "model": "", "temperature": 0.7 },
  "providers": {
    "fast": { "provider": "openai", "model": "gpt-4o-mini" },
    "strong": { "provider": "openai", "model": "gpt-4o" }
  }
}
```

**差异**:
- `llm.default_provider` 不存在 → 应为 `llm.provider`
- `llm.providers` (嵌套在 llm 下) → 应为顶层 `providers`
- 命名格式不同

---

### B3: agent new 的 system.md 模板问题 🔴

`neonrp agent new narrator` 生成的 system.md:
```markdown
# narrator System Prompt
You are narrator, an agent in the NeonRP system.
## Your Role
Describe the agent's role and responsibilities here.
## Guidelines
- Follow the proposal format for all changes
```

**问题**: 完全没提到可用工具（read_file, find, read_context, submit_proposal, write_file, edit_file, glob, grep, ask_user, task 等 12 个 skills）。

而 `_build_default_system_prompt()` 包含完整的工具说明、entity 格式、workflow 指南。但这个 fallback prompt **只在 system.md 文件不存在时生效**——`agent new` 必然创建 system.md，所以 fallback 永远不会触发。

**结果**: 代理在 agentic 模式下虽然能看到工具 schema，但 system prompt 没有指导它如何使用这些工具。LLM 表现取决于它是否能纯粹从 schema 推断用法。

**修复**: system.md 模板应包含 `_build_default_system_prompt()` 的内容，至少列出所有可用工具及其用途。

---

### B4: Fixture 格式无文档 🔴

教程说 `--fixture` 可以用于 stub 测试，但没说明 fixture JSON 的格式。实际测试发现：
- 必须包含 `run_id`, `agent_id`, `branch`, `base_head_event`, `query` 等元数据
- 不是 message 数组，而是 proposal dict

用户第一次尝试不可能猜对格式（我自己猜了两次才对）。

---

### S1: `/` vs `:` 命令文档不一致 🟡

代码已改为 `/` 前缀（你的修改），但以下文件仍用 `:`:
- `TUTORIAL.md:205` — "`:` commands"
- `TUI_GUIDE.md` — 全文 20+ 处引用 `:command`
- `CLI_REFERENCE.md` — 可能也有引用

---

### S2: redo 不工作 🟡

**复现**:
```
neonrp agent run narrator --apply  # event 2
neonrp undo                        # back to event 1
neonrp redo                        # "No redo checkpoint available"
```

undo 基于 checkpoint restore 实现，但 redo 似乎没有保存 undo 前的状态作为 redo 目标。

---

### S3: game new 不创建 agents 🟡

`neonrp game new` 创建 3 个 world 实体但不创建任何 agent。用户必须手动运行 `agent new`。Tutorial Step 6 确实提到了这一步，但 `game new` 后立刻尝试 `run` 会报 "No agents found"。

**建议**: `game new` 应同时创建一个默认 narrator agent，或在提示中说明下一步。

---

### S4: find --kind character 无结果 🟡

Tutorial 的 find 示例没有用 `--kind character`，但 entity 类型是 `player`/`npc`/`town`。如果有用户直觉性地搜 `--kind character`（因为 RP 游戏通常叫 character），会得到空结果。这不是 bug 但是 UX 问题。

---

### S5: --agentic 标志未在教程提及 🟡

`neonrp run` 默认使用**单轮**模式（`run_agent()`），不会进入 agentic loop。需要显式加 `--agentic` 才用 multi-turn 模式。TUI 默认 agentic。

教程完全没提到 `--agentic`，这导致 CLI 用户永远体验不到 M6-M8 的核心能力（tool calls、ask_user、task）。

---

### S7: Fixture 不自动注入上下文 🟡

StubAdapter 的 `_load_fixture_data()` 直接返回 fixture 文件内容作为 submit_proposal 的 arguments。如果 fixture 缺少 run_id 等字段，Proposal 验证失败。

正常的 stub（无 fixture）会从 messages 中提取上下文自动填充这些字段。但 fixture 模式不会。

**修复**: `chat()` 在使用 fixture data 后，应 merge 从 messages 提取的上下文字段。

---

## 三、测试结果矩阵

| 功能 | 结果 | 备注 |
|------|------|------|
| `neonrp init` | ✅ 通过 | |
| `neonrp game new` | ✅ 通过 | 但不创建 agents |
| `neonrp validate` | ✅ 通过 | |
| `neonrp index build` | ✅ 通过 | |
| `neonrp find` | ✅ 通过 | `--kind` 需用实际 kind 值 |
| `neonrp context` | ✅ 通过 | 排序合理 |
| `neonrp agent new` | ✅ 通过 | 但 system.md 过于简陋 |
| `neonrp agent run --provider stub` | ✅ 通过 | 空 proposal（正常） |
| `neonrp agent run --fixture` | ⚠️ 格式不明 | 需完整 proposal dict |
| `neonrp agent run --apply` | 🔴 Windows crash | Unicode 编码问题 |
| `neonrp run` (dispatcher) | ✅ 通过 | 非 agentic 模式 |
| `neonrp save` | ✅ 通过 | |
| `neonrp load` | ✅ 通过 | |
| `neonrp undo` | ✅ 通过 | |
| `neonrp redo` | 🔴 不工作 | "No redo checkpoint available" |
| `neonrp branch` | ✅ 通过 | 创建+切换均可 |
| `neonrp sandbox list` | ✅ 通过 | |
| `neonrp sandbox new --from` | ✅ 通过 | |
| `neonrp sandbox switch` | ✅ 通过 | |
| `neonrp replay verify` | ✅ 通过 | |
| `neonrp import sillytavern-card` | ✅ 通过 | |
| TUI import | ✅ 通过 | 无法完整 E2E 测试 |
| examples/starter-world | ✅ 通过 | 10 entities, trigger 匹配正常 |

---

## 四、修复优先级

### 必须立即修复（阻断用户）

1. **B1 Unicode 崩溃** — 替换 `✓`/`✗` 为 ASCII 等价物
2. **B2 Tutorial config 格式** — 更新为实际格式
3. **B3 agent template** — system.md 模板包含工具列表和 workflow
4. **B4 Fixture 文档** — CLI_REFERENCE.md 添加 fixture 格式说明

### 应尽快修复

5. **S1 `/` vs `:` 文档** — 更新 TUI_GUIDE.md 全文
6. **S2 redo 不工作** — 修复 checkpoint redo 逻辑
7. **S5 --agentic 文档** — Tutorial 中说明 agentic 模式
8. **S7 Fixture 自动注入** — stub adapter merge 上下文字段

### 可推迟

9. **S3 game new 创建 agent** — 改善首次体验
10. **S8 apply_overrides** — 保留 max_sub_agent_depth

---

## 五、核心观察

**626 个单元测试全部通过，但新用户首次体验仍然碎裂。** 这说明测试覆盖的是"函数正确性"而非"用户旅程正确性"。缺少的是：

1. **集成测试 / smoke test**: 模拟完整的 `init → game new → agent new → run → save → undo → branch` 流程
2. **多平台 encoding 测试**: Windows cp932/gbk + UTF-8 locale
3. **文档一致性检查**: config.json 格式、CLI 帮助文本 vs 实际行为

建议 M9 引入一个 `tests/test_tutorial_walkthrough.py` 自动化执行教程每一步，验证每个命令的退出码和关键输出。
