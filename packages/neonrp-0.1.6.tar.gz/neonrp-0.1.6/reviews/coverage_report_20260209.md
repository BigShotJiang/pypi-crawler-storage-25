# 测试覆盖率报告

- Date: 2026-02-09 (updated)
- Baseline: 803 passed, 7 skipped
- Tool: `pytest --cov=neonrp --cov-report=term-missing -q`
- **总覆盖率: 65%** (7674 statements, 2648 missed)
- 上次基线（同日早些时候）: 63% (7674 statements, 2843 missed)

---

## 本轮完成（已落地）

| 模块 | 变更前 | 变更后 | 状态 |
|------|--------|--------|------|
| `core/conversation.py` | 80% (315/62 miss) | **99%** (315/2 miss) | 已完成 |
| `core/retrieval.py` | 33% (63/42 miss) | **95%** (63/3 miss) | 已完成 |
| `tui/suggestions.py` | 0% (97/97 miss) | **99%** (97/1 miss) | 已完成 |

新增测试文件：
- `tests/test_conversation_edges.py`
- `tests/test_retrieval.py`
- `tests/test_tui_suggestions.py`
- `tests/test_llm_real_endpoint.py`（真实端点 E2E，读取 `~/.neonrp/config.json`）

---

## 当前主要低覆盖模块（待补）

### Commands 模块（P1）

| 模块 | 覆盖率 | 缺口 |
|------|--------|------|
| `commands/run.py` | **18%** | `run()` 主流程几乎未测 |
| `commands/branch.py` | **38%** | `branch/undo/redo` 主路径覆盖不足 |
| `commands/agent.py` | **46%** | `new/edit/show/tools` 子命令覆盖不足 |
| `commands/validate.py` | **48%** | 错误报告和边界路径未覆盖 |
| `commands/save.py` | **53%** | `save/restore` 关键流程缺回归 |

### Core 模块（P1）

| 模块 | 覆盖率 | 缺口 |
|------|--------|------|
| `core/storage.py` | **75%** | 原子写入异常分支覆盖不足 |
| `core/replay.py` | **77%** | replay 分支/校验路径待补 |
| `core/apply.py` | **75%** | apply 异常与回滚路径待补 |

### 外部集成与可跳过项

| 模块 | 覆盖率 | 说明 |
|------|--------|------|
| `core/llm_openai.py` | 39% | 外部 API 适配层，以集成测试为主 |
| `tui/app_legacy.py` | 10% | 废弃路径，不投入 |
| `tui/panels/*` | 0% | 纯 UI 面板，不作为当前优先 |

---

## 下一轮建议顺序

1. `commands/run.py` + `commands/branch.py`
2. `commands/agent.py` + `commands/validate.py`
3. `commands/save.py` + `core/storage.py`

预估：再补 ~20-30 个高价值测试，可把总覆盖率继续推到约 68%-72% 区间。

---

## 验证命令

```bash
# 全量覆盖率
uv run pytest --cov=neonrp --cov-report=term-missing -q

# 指定模块覆盖率（本轮重点）
uv run pytest --cov=neonrp.core.conversation --cov=neonrp.core.retrieval --cov=neonrp.tui.suggestions --cov-report=term-missing tests/test_conversation.py tests/test_conversation_edges.py tests/test_retrieval.py tests/test_tui_suggestions.py -q

# 真实端点 E2E（读取用户配置端点）
NEONRP_E2E_LLM=1 uv run pytest tests/test_llm_real_endpoint.py -q
```
