# NeonRP 代码审查报告（2026-02-16）

## Summary（总体风险：High）

本次按 `prompts/code_review.md` 对 Agent/Engine/Storage 关键链路进行了审查，重点覆盖：
- `src/neonrp/core/apply.py`
- `src/neonrp/core/permissions.py`
- `src/neonrp/core/conversation.py`
- `src/neonrp/commands/save.py`
- `src/neonrp/commands/branch.py`
- `src/neonrp/core/replay.py`
- `src/neonrp/core/proposal.py`
- `src/neonrp/core/agent_runner.py`
- `src/neonrp/commands/index.py`
- `src/neonrp/commands/context.py`
- `src/neonrp/commands/find.py`
- `src/neonrp/commands/run.py`
- `src/neonrp/core/config.py`

抽样验证测试（本地）：
- `.venv\Scripts\python.exe -m pytest -q tests/test_apply.py tests/test_proposal.py tests/test_permissions.py tests/test_replay.py tests/test_agent_runner.py tests/test_agent_cli.py`
- 结果：`94 passed`

当前主要风险集中在：**原子性提交、分支隔离、权限边界绕过、状态一致性**。这些问题可导致世界状态损坏、跨分支污染或受保护目录被改写。

## Must-fix（阻断项）

1. Apply 提交流程不是原子替换，且存在“先删后拷”窗口，可能导致世界数据损坏
- 证据：`src/neonrp/core/apply.py:180`, `src/neonrp/core/apply.py:181`, `src/neonrp/core/apply.py:182`
- 问题：提交阶段使用 `shutil.rmtree(world_root)` 后再 `copytree`，中间崩溃/中断会造成 `world/` 丢失或半写入。
- 影响：违反“apply 必须 crash-safe/atomic”要求；高概率破坏用户数据。
- 建议：使用同卷 staging + `os.replace` 的目录切换策略（必要时保留可回滚备份），避免 destructive window。

2. Apply 缺少“proposal.branch == 当前检出分支”约束，存在跨分支污染
- 证据：`src/neonrp/core/apply.py:81`, `src/neonrp/core/apply.py:95`, `src/neonrp/core/apply.py:180`, `src/neonrp/core/apply.py:197`
- 问题：`head_event` 读取和事件追加用的是 `proposal.branch`，但文件写入目标固定是当前 `world/`。
- 影响：可出现“修改了 A 分支工作树，却把事件写到 B 分支日志”的不一致，破坏 branch isolation。
- 建议：在 apply 前强制校验 `proposal.branch == manifest.current_branch`，或按目标分支专属工作树进行 apply。

3. 事件追加与 manifest 更新不是事务式提交，可能产生 head/event 不一致
- 证据：`src/neonrp/core/apply.py:197`, `src/neonrp/core/apply.py:200`, `src/neonrp/core/apply.py:201`
- 问题：先 append event，后写 manifest；若后者失败，事件已落盘但 `head_event` 未更新。
- 影响：审计链断裂，重放/并发控制依据失真。
- 建议：引入最小事务语义（写前日志或可恢复两阶段），确保 event 与 head 同步成功或可恢复。

4. build 模式可绕过受保护路径限制，违背 deny 默认保护
- 证据：`src/neonrp/core/conversation.py:210`, `src/neonrp/core/conversation.py:211`, `src/neonrp/core/conversation.py:212`, `src/neonrp/core/permissions.py:160`, `src/neonrp/core/permissions.py:196`, `src/neonrp/core/skills.py:921`
- 问题：build 模式将 `deny_globs=[]`、`direct_write_globs=["**"]` 且 `allow_protected_paths=True`，从而跳过 `.neonrp/**`、`agents/**` 强制拒绝。
- 影响：Agent 可直接改写受保护控制面文件，越权风险高。
- 建议：除显式管理员通道外，不允许禁用 `REQUIRED_DENY_GLOBS`；至少默认保持 deny-first。

5. save/load 的恢复路径仍有 destructive window，且恢复后状态不完整
- 证据：`src/neonrp/commands/save.py:113`, `src/neonrp/commands/save.py:114`, `src/neonrp/commands/save.py:115`
- 问题：`load` 使用 `rmtree + copytree`；同时只恢复 `world/`，未恢复对应 `events`/`head_event`。
- 影响：既有数据损坏风险，也会导致“世界内容与事件头不一致”，削弱可复现性。
- 建议：采用原子目录切换恢复；若语义为“完整快照恢复”，需同步恢复事件与分支 head。

## Should-fix（非阻断）

1. `proposal_version` 未强制显式提供
- 证据：`src/neonrp/core/proposal.py:91`
- 说明：当前有默认值 `"0.1"`，即缺字段也会通过；与“proposal 必须包含版本字段”的契约不完全一致。

2. `apply.json` 仅在 `--apply` 时写入，审计材料不完整
- 证据：`src/neonrp/core/agent_runner.py:550`, `src/neonrp/core/agent_runner.py:561`, `src/neonrp/core/agent_runner.py:1046`, `src/neonrp/core/agent_runner.py:1056`
- 说明：未 apply 的 run 目录缺少 `apply.json`，不利于统一审计与自动化消费。

3. CLI exit code 约定不一致
- 证据：`src/neonrp/commands/index.py:30`, `src/neonrp/commands/context.py:154`, `src/neonrp/commands/find.py:121`, `src/neonrp/commands/run.py:53`, `src/neonrp/commands/run.py:65`
- 说明：部分用户错误使用 `2`，`run` 某些错误路径直接 `return`（进程码为 0）。

4. `apply_overrides` 未保留 embedding 配置
- 证据：`src/neonrp/core/config.py:475`
- 说明：引入 `embedding` 后，`apply_overrides` 返回的新 `ProjectConfig` 未显式带回 `config.embedding`。

5. 仍存在非原子文本写入路径
- 证据：`src/neonrp/core/agent_runner.py:490`, `src/neonrp/core/agent_runner.py:525`, `src/neonrp/core/agent_runner.py:1021`
- 说明：日志写入可接受较低一致性，但如作为审计依据，建议统一 atomic helper。

## Nice-to-have（优化项）

1. 统一“目录原子替换”抽象，减少 `rmtree + copytree` 分散实现
- 涉及：`apply`, `save/load`, `branch restore`, `replay checkout`

2. 对关键日志与事件写入建立一致的 durability 策略
- 例如：结构化日志统一走 `atomic_write_json`，必要时加 `fsync`

3. 时间 API 一致化到 timezone-aware 写法
- 证据：`src/neonrp/commands/branch.py:90` 使用 `datetime.utcnow()`

## Suggested tests to add（建议补充测试）

1. apply 原子性回归：模拟在“删除 world 后、复制前”故障，验证可恢复且不丢数据。  
2. 分支隔离回归：`proposal.branch != current_branch` 时应拒绝。  
3. build 模式权限回归：尝试写 `.neonrp/manifest.json` 与 `agents/*`，默认应拒绝。  
4. save/load 一致性：load 后校验 `game_hash`、event log 与 `manifest.head_event` 一致。  
5. CLI exit code 约束：用户错误统一 `1`、系统错误 `2`。  
6. `apply_overrides` 保真：覆盖后 embedding 配置不丢失。  
7. run 日志完整性：无论是否 `--apply`，run 目录都应存在 `apply.json`。  

