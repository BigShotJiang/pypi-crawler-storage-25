# Storyline B: The World Before the Fog

## Function

Line B is the depth-of-time spine of the Stoneford cycle. Where other lines ask *who rules now* or *what walks the fog tonight*, this line asks *what stood here before any of it*. The player is meant to leave T005 no longer able to see a wall, a doorframe, or a mile-marker without wondering what the stone used to be.

The work is archaeological, linguistic, architectural. It moves not through battles or betrayals but through rubbings of glyphs, through the weight of a shard in a satchel, through a silent woman's hands shaping the air. It never names the far side. It never explains the hidden premise. It only lets the evidence accumulate until the player's own geography becomes suspect.

By the Critical beat, Mistmere is no longer a provincial capital above the Shale. It is a newer city sitting on an older one, and the player has walked enough of its back-alleys to feel the join.

## Soul figure(s)

- **Maester Eilin of the Broken Tongue** — monastery scholar at T003 (Wolfsjaw / the cliff-side monastery of the Silent Order). Her tongue was cut by royal order eleven years ago after her draft paper *On the Kinship of Great Cliff and Great Chasm* surfaced in the Crown library. The paper argued a single root governed the words *cliff* and *chasm* in old-tongue fragments, and carried the phrase **上下相通** (*above and below connect*) as its closing remark. She now communicates only through sign, written glyph, and ink drawing. First appearance: T003 monastery scriptorium.
- **Sub-soul: Preceptor Vossel the Younger** — roaming Faith scribe based at T002, but frequently on the road. He arrived at the monastery as a novice three winters ago and began secretly transcribing Eilin's gestures into a private codex. He carries part of this codex in a hollow psalter. He is the bridge that moves Eilin's thinking out of the monastery without her seal on it. First appearance: T002 chapel.

## Hook

**Tier 1 · T001 Stoneford · the Faith chapel behind the Shale Lantern.**

Septon Silas — the same Septon the Stoneford rumour-mill places walking alone to the mine-mouth every third night — is not a Jadehollow man by birth. He spent his novitiate at the Wolfsjaw monastery under Eilin. Three seasons ago, while walking the old mine road north of Stoneford, he turned over a flat stone at the ford and found wedged beneath it a **shard of dark grey stone no larger than a man's palm**, worked on one face with script neither he nor any Faith brother can read.

He has carried it since in the lining of his cassock. He will not take it to his own bishop in Mistmere — he knows what Reynard does with inconvenient objects. He has been waiting for someone neither Faith nor Guild nor Crown to carry it north to Eilin, whom he still addresses in letters as *Maester*, knowing she cannot reply.

The shard is the hook. Silas is the hand that offers it.

## Clues by town

### T001 — Stoneford

| Carrier | Type | Content |
|---------|------|---------|
| Septon Silas (visiting from T004) | NPC dialogue & item transfer | Silas is in Stoneford on the third-night walk the rumours describe. In the chapel, after evening prayer, he produces the **stone shard**. He will not hand it over in daylight, not in the tavern, not in earshot of Old Reed. He describes its weight as *warmer than stone has any business being*. He asks the player to carry it to *the Maester of the Silent Order at Wolfsjaw*. He refuses payment. He will give a sealed letter in old Faith script as introduction. |
| Stone shard | Item drop | Palm-sized, dark grey, worked on one face with seventeen incised glyphs in three rows. Two of the glyphs share their lower strokes with characters the player may later see inside the Iron-Dragon fragment **永生 × 黄金 × 无穷** (T002/T004 bard recitations). The shard is cold to the touch except along the glyph-lines, which run a half-degree warmer. It does not glow. It does not hum. It is simply wrong in a way the hand registers before the eye does. |
| Old Reed | NPC line (sprout) | If asked about the ford where Silas found it: *"Ford-stone? Aye. My grandfather said a man once pulled a square stone out of the river — cleaner-cut than any mason in the Reach could manage. Threw it back. Said it belonged to the river."* He will not be drawn further. He changes the subject to fish. |
| Mira Ashford | NPC line (sprout) | If the player shows the shard — do not: *"My husband came back with something like that in his pocket. I buried it with what was left of him. Don't bring it in here again."* This is a stop-signal, not an explanation. Eilin will later confirm the ford is the *shallow* end of something longer. |
| Heron Blackwater | NPC line (sprout) | Heron recognises the shard as *Guild-flagged*. He does not say the words *Northern Ban*. He says: *"Take it north, and take it by back roads. The Guild has posted men at every keep road this season for trinkets like that."* This is the line's first handoff to Storyline A — see Cross-line. |
| Chapel wall | Scene beat | Above the chapel's rear door, the mortar between two flagstones has cracked and half a glyph is visible in the underlying stone. It is not Faith script. It is the same hand as the shard. Silas has never pointed this out, though he has knelt under it every morning for a decade. The player is free to notice. The world-agent must not confirm. |
| River stones | Scene beat (optional, returning visit) | On a second pass through Stoneford after the player has seen the Wolfsjaw glyphs, the worked stones in the ford bed become legible as *cut stones*, not natural. The river-bed is a masonry floor with two hundred years of silt over it. No NPC says this. The description of the ford shifts. |

**Sprout end (T001):** player accepts the shard and the Silas letter; carries them toward T002.

---

### T002 — Windrest

| Carrier | Type | Content |
|---------|------|---------|
| Preceptor Vossel the Younger | NPC dialogue | Vossel is in the Windrest Faith chapel when the player arrives. He is young, thin, ink-stained at the cuff. He recognises Silas's seal on sight. He will ask, quietly, whether the player has *touched the cold face of a stone that was warmer than it should be*. If yes, he invites the player to the chapel back-room and opens his **hollow psalter**. |
| Hollow psalter | Item (shown, not given) | Inside the psalter's gutter lies a codex of twelve folded leaves. Each leaf carries a drawing in Eilin's hand: the gesture-for-a-word, rendered in ink. Each gesture is captioned beneath in Vossel's careful script. Three of the gestures correspond to glyphs on the player's shard. Vossel asks the player not to tell him this aloud — he prefers to deduce it himself from the player's reaction. |
| Vossel line | NPC dialogue | *"She draws before she signs. Every word is first a picture. She says — she gestures — that the old-tongue was built the same way. Picture before sound. The stone you carry was cut by a hand that thought the way she thinks."* |
| Vossel line (on royal ban) | NPC dialogue | *"I was not there when they took her tongue. I was still a novice. I was told she had misnamed the Chasm — called it by the name of a cliff. I did not understand why that was worth a knife. I am beginning to."* This seeds the A↔B dependency. |
| Captain Yura Stoneshield | NPC line (if asked about Vossel) | *"The boy writes more than he prays. Linden's scouts flagged him twice. I struck their reports. He's no danger."* She knows Vossel copies something. She does not know what. |
| Kalran the smith | NPC line (if shard shown) | Kalran takes the shard in his remaining hand. He holds it for a long breath. He returns it. *"Not a smith's work. Not any smith I know. Whoever cut that didn't strike the stone. They wore it down."* He will not elaborate. He refuses payment for the look. |
| Straight-line cloud | Scene beat (shared with Line D) | On the road between T001 and T002, a straight line of cloud crosses the sky at dusk. If the player is carrying the shard, the shard is perceptibly warmer for the duration of the cloud's passage. No NPC corroborates this. Old Zhao, if bribed later, will say: *"The cloud's been seen three times this year. Each time, something old moves."* He charges fifty gold and does not elaborate. |
| Windrest Keep foundation stone | Scene beat | In the keep's lower hall, behind a tapestry, one foundation block is cut too cleanly for its age. On close inspection (passive), a single weathered glyph is visible on its edge — matching the family of glyphs on the shard but not any specific one. Yura does not know. Linden knows and does not say. |

**Sprout/Involvement transition (T002):** player meets Vossel, is shown the codex, learns Eilin is mute and why, and continues to T003 carrying both the shard and Silas's letter.

---

### T003 — Wolfsjaw / the Silent Order monastery

The monastery is three hours' ride upslope from the garrison. It is older than the keep. Its outer walls are newer stone on much older courses.

| Carrier | Type | Content |
|---------|------|---------|
| Maester Eilin | NPC first meeting | Eilin is in the scriptorium when the player is brought in. Mid-fifties, grey hair cropped short, ink on every finger. She does not rise. She gestures once — palm open, then palm turned — and a novice fetches a writing board. She reads Silas's letter without expression. She extends her hand for the shard. |
| Eilin first response | Scene beat | She places the shard on a clean sheet. She inks its face. She presses a rubbing. She lines the rubbing up against a row of other rubbings already pinned on a board above her desk. The player sees — without being told — that the shard's glyphs are not unique. They belong to a family Eilin has been collecting for years. One of the other rubbings carries the label, in Eilin's hand, **上下相通**. |
| Eilin's board | Scene beat | Twenty-three rubbings. Monastery cellar. Wolfsjaw foundation. Stoneford ford. Jadehollow second-level drift. Mistmere harbour-wall below the tide-line. The map of the rubbings forms, if the player studies it, a ring — the Grey Reach sitting inside an older ring of the same hand's work. No NPC says this aloud. |
| Eilin signed answer | NPC dialogue (gestures) | To the player's question *what does it say* — whatever form the player takes to ask — Eilin signs a sequence: hand rising, hand falling, two fingers meeting. A novice translates, flatly: *Above. Below. They touch.* She does not elaborate on meaning. She does elaborate on **kinship** — she signs that two of the shard's glyphs are also present in the Iron-Dragon fragment **永生 × 黄金 × 无穷**, and that the kinship is a root kinship, like two words sharing a grandmother. She does not claim to read either. She is explicit: *I know they are kin. I do not know what they say.* |
| Monastery back wall glyph | Scene beat & fragment placement | Behind the scriptorium, down a short flight of worn steps, the monastery's original rear wall survives. At head height, carved into the stone and later whitewashed over and later again scrubbed partly clear, are the four glyphs **上下相通**. Eilin did not put them there. Eilin found them. That is the whole of her crime. |
| Eilin (chalk slate, if asked about lost sketches) | NPC dialogue (written) | If the player asks Eilin about her lost or missing drawings, she writes on her chalk slate, flatly: *"he keeps them."* She does not name Kestrel. She does not elaborate. She wipes the slate. (B↔E acknowledgement: Kestrel archives her drawings, per Line E T004.) |
| Abbot Merick (NEW NPC) | NPC dialogue | The Silent Order's abbot. Sixty, stooped, soft-voiced, hands folded in his sleeves. He was abbot when Eilin was muted. He approved the knife because the alternative was losing the entire monastery to the Crown's displeasure. He has not forgiven himself. He speaks to the player only once, and briefly: *"She is not a prisoner. She stays because the rubbings are here. If you take her out, you take her away from the only library that matters."* |
| Novice Taryn (NEW NPC) | NPC dialogue | Fourteen, Eilin's hands-and-voice in daily practice. She translates gestures for outsiders. She was assigned to Eilin at seven and has grown up inside her silence. She is the first person who will speak the phrase *above and below connect* aloud to the player — and she will say it without understanding it, as one recites a copied line. |
| Half-burned "Northern Ban" decree | Fragment (carried by Line A, referenced here) | In Archivist Naryn's cabinet (see Line A). Eilin, if the player has already seen the decree and mentions it, signs a single long sequence: the decree quotes the shard. She has known this for three years. She will not say which line of the decree. She signs: *look at the third clause. look at what it forbids to be named.* |
| Monastery cellar | Scene beat | Beneath the scriptorium, the cellar's load-bearing pillars are not of monastery make. They are older, rounder, and their bases sit below the modern floor — a fact visible only where a flagstone has cracked. One pillar carries a single glyph at knee height. Eilin has never rubbed this one. She signs, when asked, that she is *saving it*. She does not say for what. |
| Mark the one-eyed veteran | NPC line | If the player asks Mark (T003 garrison) about the monastery: *"Older than the keep. Older than the road. My grandmother said the stone remembers being someone else's stone."* He grins without humour. *"Granny drank."* |

**Involvement end (T003):** the player has met Eilin, seen the board of rubbings, recognised the shard as one item in a ring of evidence, and learned that the Crown muted a scholar for proposing a linguistic kinship the player's own shard now confirms. The player leaves with a **rubbing of the shard** and, if on good terms, **a copied leaf from Vossel's codex** cross-signed by Eilin.

---

### T004 — Jadehollow

| Carrier | Type | Content |
|---------|------|---------|
| Old Fane Crowseye | NPC dialogue | With the pale eye, Fane looks at the shard and is quiet for a long time. *"The stone is not the age of the cut. The cut is older. The stone was cut, then broken, then buried, then uncovered, then broken again. You are holding a fragment of a fragment."* He will not take payment for the appraisal. *"I do not want to be the one who priced this."* |
| Jadehollow second-level drift | Scene beat | On the second mine level, near the eastern face, the miners have exposed a worked stone wall behind the ore-vein. Ironpost believes it is a natural formation with unusual striations. It is not. Eilin has a rubbing from this exact face on her board. If the player returns to T003 with a fresh rubbing from this drift, Eilin will add it to the ring and sign *it closes*. |
| Kassa Deepvein | NPC line | *"Whatever is in the second drift is not on the Consortium's manifest. Keep your findings to yourself and I will keep mine to mine."* This is the polite warning. The rude one does not come. |
| Septon Silas (return) | NPC dialogue | Returning to T004 with the shard still in hand — Silas is visibly relieved not to see it. *"Tell me you left it with her."* If yes: he weeps, briefly, and prays. If no: he becomes very still, then asks to hold it one last time. He will say, quietly: *"I found it at the ford. I think the ford found me."* He does not elaborate. |
| King's Archivist Naryn (appears here, see Line A) | NPC dialogue (theory voice) | Naryn — if the player is on Line A or has earned the meeting — delivers her theory of why relics are underground: *"A hundred years ago the far side came down in pieces. Some pieces fell our way and some pieces fell into the ground. The floor we walk on is the ceiling of their graveyard."* Her theory is one of the four. It is spoken, not written. |
| Navigator Kestrel (appears here per Line E) | NPC dialogue (theory voice) | Kestrel — if met per Line E — delivers the Crosser theory: *"There were roads under the earth before there were roads over it. The Chasm is a mouth. The real roads are the throat."* She carries a **sketch labelled *from below, we may rise*** — see Cross-line E. |
| Unnamed rhythm-speech drunk | NPC dialogue (theory echo) | In the back room of the Jade Lantern, an unnamed drunk — hollow-cheeked, grey-haired, no teeth on the left — repeats a triadic fragment in rhythm: *"Below and beyond are one. The floor is the far wall. The floor is the far wall."* He does not know its source and will not say more. He refuses coin. He is not Hallen. The named carrier of Theory-3 is Hallen, at T005 (see Line E, sunken-ward sick-cell). |
| Grandmother Green | NPC line | If asked about the monastery or Eilin: *"They cut a good woman's tongue for a word. I keep my herbs and my mouth both. I recommend you do the same."* |

---

### T005 — Mistmere

Mistmere is the Critical beat. The revelation is not delivered by dialogue. It is delivered by the city itself.

| Carrier | Type | Content |
|---------|------|---------|
| Harbour-wall below the tide-line | Scene beat (CRITICAL) | At low tide, the base of Mistmere's harbour-wall exposes masonry that is not of the harbour's build. The stones are larger, differently jointed, and worked on their *inner* faces — faces that now look outward into the sea because the wall they once belonged to has been turned inside-out and repurposed. Three glyphs are visible on the exposed inner face. They are in the shard's hand. |
| Cathedral undercroft | Scene beat (CRITICAL) | Beneath the Grand Cathedral, the undercroft's oldest chamber is not Faith-built. Its columns are the same round pre-Faith columns as the Wolfsjaw monastery cellar. One column carries a full sentence of glyphs at shoulder height. Reynard has had the whole chamber limewashed once a year for forty years. The limewash is thinning. |
| Lady Vera Ashford-Blackwater | NPC dialogue (if Line C alignment permits) | Vera, shown the shard, does not flinch. She has seen several. *"My family's cellar — the Mossbarrow — sits on a floor that is not an Ashford floor. My brother Edric said as much before they exiled him. I purchased the land around it because I believe the floor extends outward. I believe this city sits on someone else's city."* She will not put this in writing. This is the first time the premise is named — and it is named as a **family conviction**, not as a fact. |
| His Holiness Reynard | NPC dialogue | Reynard, shown the shard — if the player is unwise enough to show him — will examine it, smile, and return it. *"A curiosity. The Faith collects many. I would be happy to add it to our reliquary."* The offer will be repeated later with force. Reynard's theory voice, if pressed: *"The earth buries what the earth wishes to bury. The question is impious."* He does not hold a fourth theory; he holds the policy that no theory should circulate. |
| Magister Corvin Ashford-Reed (Line A soul) | NPC dialogue | Corvin, if the player reaches him, confirms that the Guild's **Northern Ban** — the charter clause forbidding the trade, naming, or rubbing of a specific script — names that script by its opening glyph, and that glyph is on the player's shard. Corvin is the one who speaks the words *Northern Ban* aloud. He is also the one who tells the player that the Ban was drafted eleven years ago, the same season Eilin was muted. See Line A. |
| Navigator Kestrel's sketch | Fragment (deep archive, Line E carrier) | The sketch labelled *from below, we may rise* — in the deep archive at T004 per Line E — carries, along its lower border, three root-glyphs. Two are on the player's shard. One is on the harbour-wall inner face. If the player has rubbed all three carriers, the overlap is undeniable. Eilin, shown this, signs: *kin. not the same hand. the same grandmother.* |
| City-on-ruins reveal | Scene beat (CRITICAL, no NPC) | As the player walks Mistmere with the shard in their satchel and the rubbings in their coat, the city reorganises itself to their eye. The cathedral plaza's flagstones are cut in two sizes — the larger, older, square; the smaller, newer, filling gaps. Half the noble quarter's garden walls have round column-stumps set as corner posts. The fishmarket's drainage channel is too deep and too straight to be a drainage channel. No NPC points any of this out. The city does. |
| Septon Silas (if he reaches Mistmere) | NPC line | If Silas has travelled south — unlikely unless the player fetches him — he kneels once in the undercroft and says nothing the rest of the day. |

**Critical decision at T005 (Line B):**

The player, standing with Eilin's rubbings, Silas's shard, Vossel's codex leaf, and Kestrel's sketch in overlap, must decide what to do with the convergence. Four outcomes are supported and none is endorsed:

1. **Deliver to the Faith (Reynard).** The shard and rubbings enter the Cathedral reliquary. They are never seen again. The Northern Ban (Line A) is renewed by ten years. Eilin loses her board; a Faith delegation visits the monastery and removes all rubbings. Vossel is reassigned south. The evidence is not destroyed — it is buried deeper. The city keeps its secret.

2. **Deliver to Magister Corvin (the Guild).** The Guild absorbs the evidence into its sealed archives. The Northern Ban is quietly rewritten to admit a narrow scholarly exemption — Eilin is permitted, in old age, to publish one monograph under Guild seal. Vossel is made her amanuensis. The evidence survives in a form no commoner will read. This is Line A's preferred endpoint.

3. **Hand to Navigator Kestrel (the Crossers).** The shard, rubbings, and codex leaf are bound into the Crosser brief for their descent. The sketch *from below, we may rise* gains a linguistic spine. Eilin, offered the choice, signs *go*. Vossel chooses her — he stays at the monastery. This is Line E's preferred endpoint.

4. **Return everything to Eilin and walk away.** The player brings all the fragments back to T003 and adds them to the board. Eilin signs *thank you*. The board grows. Nothing changes in the visible world. The player is the only person outside the Silent Order who has seen the ring closed. This is Line B's own preferred endpoint — the quietest, the most honest, the least dramatic. It is also the only outcome in which Eilin is permitted to die with her rubbings intact.

The world-agent must not weight these. Each is a full ending for Line B.

## Stage endpoints

- **Sprout end (T001):** Player accepts the shard from Silas and commits to carrying it north. They have noticed, at minimum, that the shard is warmer along its cut lines. They may have noticed the half-glyph above the chapel's rear door. They have not yet heard the name *Eilin*.
- **Involvement end (T003):** Player has met Eilin, seen the board of rubbings, received a signed answer (via Taryn's voice) that the shard's glyphs say *above and below connect*, and learned that the Crown muted her for proving a linguistic kinship between *cliff* and *chasm*. The player carries a rubbing and, if trusted, a codex leaf. They have begun to notice that pre-monastery stonework is present under the monastery, the keep, and likely the ford.
- **Critical decision at T005:** As above. Four supported outcomes. The city-on-ruins is revealed by scene, not dialogue, before the decision is made.

## Cross-line interactions

- **B ↔ A (Guild's Buried Charter).** The Guild's **Northern Ban** — drafted eleven years ago, same season as Eilin's muting — quotes the **opening glyph** of the stone shard as the script it forbids to name, trade, or rub. The quotation is in the third clause of the half-burned decree held in Archivist Naryn's cabinet (Line A fragment, T003). Magister Corvin Ashford-Reed (Line A soul, T005) is the first NPC to say the words *Northern Ban* aloud to the player. Eilin's muting and the Ban's drafting are the same royal act seen from two angles.
- **B ↔ E (Depth-Walkers).** Navigator Kestrel (Line E sub-soul, T004 Crossers) keeps an archive of **Eilin's drawings** — copies smuggled out by Vossel in the last three years. Kestrel's **sketch labelled *from below, we may rise*** shares three root-glyphs with the shard — two of which also appear in Kestrel's copies of Eilin's rubbings. The Crossers read Eilin's *above and below connect* literally; Eilin does not correct this. If the player chooses Outcome 3 at T005, Eilin's work becomes the Crossers' linguistic spine.
- **B ↔ D (Iron Dragon).** The Iron-Dragon fragment **永生 × 黄金 × 无穷** — recited by bards from T002 onward, carried in part on Veyl's colonist crest fragment at T005 (Line D) — shares **two root glyphs** with the shard. Eilin is explicit: this is kinship, not identity. She refuses to decipher either. Line B proves the two fragments are the same family of language. Line D will or will not decipher the Iron-Dragon fragment on its own terms. Line B does not.
- **B ↔ C (Four-Crown Intrigue).** Eilin was muted by royal order. The order was a Crown-Faith joint act; High Septa Malen signed the Faith's half without understanding what she was signing (she believes the shard-script is demonic — see her T005 line in Line C). Chieftess Brenna Greyhold's predecessor refused to co-sign and was replaced within the year. This is background texture for Line C; Line B does not dramatise it.

## Four theories of why relics are underground — named voices

Per the Shared Brief, each of the four theories is delivered by a named NPC, with their name attached. They contradict. None is endorsed.

1. **King's Archivist Naryn (T003, Line A carrier; spoken at T004 if player reaches her).** *"A hundred years ago the far side came down in pieces. Some pieces fell our way and some pieces fell into the ground. The floor we walk on is the ceiling of their graveyard."* — collapse-burial theory.
2. **Navigator Kestrel (T004, Line E Crossers).** *"There were roads under the earth before there were roads over it. The Chasm is a mouth. The real roads are the throat."* — transit theory.
3. **Hallen the mad returnee (T005, owned by Line E).** *"Below and beyond are one. The floor is the far wall. The floor is the far wall."* — identity theory (the floor *is* the far side). The canonical voice is delivered at T005 in the sunken ward's sick-cell (see Line E). An unnamed rhythm-speech drunk at Jadehollow's Jade Lantern echoes the triadic fragment without source; that echo is Line B's only touch on this theory voice.
4. **Maester Eilin (T003).** Delivered as **wall glyph** (the monastery rear wall) **plus sign language** (the gesture sequence translated by Novice Taryn as *above and below connect*). **上下相通.** — kinship theory. Never spoken by Eilin. Only signed, drawn, and carved.

## Write-in checklist for town writers

### T001 / npcs.json

- [ ] Add to **Septon Silas** (currently in T004 npcs.json — see **Gaps** below) a visiting-presence hook at T001: third-night walk to the chapel behind the Shale Lantern. Dialogue: *"Carry it to the Maester of the Silent Order at Wolfsjaw. I cannot. Do not open it in any keep you sleep in."* Item: **stone shard** (described above). Item: **sealed letter in old Faith script** to Eilin.
- [ ] Add to **Old Reed** a sprout line about *the square stone my grandfather pulled from the ford*.
- [ ] Add to **Mira Ashford** a stop-line if the shard is shown in the Shale Lantern.
- [ ] Add to **Heron Blackwater** a Guild-awareness line naming *Guild men at every keep road this season* (no explicit *Northern Ban* mention at T001 — that name is reserved for T005 Corvin).

### T001 / facilities

- [ ] Add to the Faith chapel: **half-glyph above the rear door**, in the shard's hand, whitewash thinning. Passive observation.
- [ ] Add to the ford: **worked stones visible under silt on return visits**, description shift after T003.

### T002 / npcs.json

- [ ] **NEW NPC — Preceptor Vossel the Younger.** Young Faith scribe, hollow-psalter carrier, Eilin-transcriber. Based at the Windrest chapel; frequently on the road. Stats: scholar-tier, non-combat, DC 15 to deduce his codex without him volunteering it. Dialogue seeds as listed above.
- [ ] Add to **Kalran** a one-hand-on-shard appraisal line: *"They wore it down. They didn't strike it."*
- [ ] Add to **Captain Yura Stoneshield** an awareness line about Vossel: *"The boy writes more than he prays."*
- [ ] Add to **Old Zhao** a fifty-gold line about the straight-line cloud. (Coordinates with Line D.)

### T002 / facilities

- [ ] Add to **Windrest Keep lower hall**: one foundation block cut too cleanly for its age, single weathered glyph visible on its edge.

### T003 / npcs.json

- [ ] **NEW NPC — Maester Eilin of the Broken Tongue.** Mid-fifties, grey cropped hair, ink-stained, mute (tongue cut eleven years ago by royal order). Communicates via sign, written glyph, ink drawing. Scriptorium office, rubbings-board (twenty-three rubbings). First response to shard: ink the face, press a rubbing, pin it on the board.
- [ ] **NEW NPC — Abbot Merick.** Silent Order abbot, approved the muting to save the monastery, has not forgiven himself. One meeting, one line: *"She stays because the rubbings are here."*
- [ ] **NEW NPC — Novice Taryn.** Fourteen, Eilin's voice-in-practice, translates gestures, first to say *above and below connect* aloud.
- [ ] Add to **Lord Commander Linden Ironfist** an awareness line (no more): he knows the monastery sits on older stone, and he is paid not to say so.
- [ ] Add to **Mark the one-eyed veteran** a granny-drank line about the monastery's remembered stone.

### T003 / facilities

- [ ] Add to the monastery: **scriptorium with rubbings-board** (twenty-three rubbings, labelled locations, one labelled **上下相通**).
- [ ] Add to the monastery: **rear wall carving 上下相通**, whitewash thinning.
- [ ] Add to the monastery: **cellar** with pre-monastery round pillars, one pillar with knee-height single glyph Eilin has not yet rubbed.
- [ ] Add to the Wolfsjaw garrison: Mark's memorial-counting beat (shared with other lines).

### T004 / npcs.json

- [ ] Add to the **Jade Lantern back room** an **unnamed rhythm-speech drunk** (not Hallen): hollow-cheeked, grey-haired, no teeth on the left, repeats the triadic fragment *"Below and beyond are one. The floor is the far wall. The floor is the far wall."* Refuses coin. Will not say more. The named carrier Hallen lives at T005 (sunken-ward sick-cell, see Line E).
- [ ] Add to **Old Fane Crowseye** the shard-appraisal line: *"You are holding a fragment of a fragment."*
- [ ] Add to **Kassa Deepvein** the second-drift warning line.
- [ ] Confirm **Septon Silas** return dialogue (*"I think the ford found me"*) and resolve the T001/T004 location question — see **Gaps**.
- [ ] Add to **Grandmother Green** the *good woman's tongue for a word* line.

### T004 / facilities

- [ ] Add to the Jadehollow mines **second-level drift eastern face**: exposed worked stone wall behind the ore-vein, rubbing-compatible.
- [ ] Confirm Kestrel's deep-archive sketch *from below, we may rise* is tagged with three root-glyphs (Line E owner).

### T005 / npcs.json

- [ ] Add to **Lady Vera Ashford-Blackwater** the family-conviction line about Mossbarrow floor extending outward under Mistmere.
- [ ] Add to **Bishop Reynard** the *curiosity for the reliquary* line and the theory-suppression policy voice.
- [ ] Confirm **Magister Corvin Ashford-Reed** (Line A soul) speaks the words *Northern Ban* to the player and ties the Ban's drafting date to Eilin's muting.

### T005 / facilities

- [ ] Add to **Mistmere harbour-wall**: at low tide, exposed older masonry on inner-now-outer face, three glyphs visible.
- [ ] Add to **Grand Cathedral undercroft**: pre-Faith round columns, one column with shoulder-height full-sentence glyph, limewash thinning.
- [ ] Add to **Mistmere city description**: passive observations of pre-collapse stonework across the noble quarter, cathedral plaza, and fishmarket. No NPC to point these out. The city points them out by its own geometry.

### Cross-line / lore

- [ ] Confirm with Line A writer: the half-burned Northern Ban decree's **third clause** quotes the shard's **opening glyph**.
- [ ] Confirm with Line D writer: the Iron-Dragon fragment **永生 × 黄金 × 无穷** shares two root glyphs with the shard. Line D does not decipher; Line B does not decipher; the kinship is Eilin's observation, unresolved.
- [ ] Confirm with Line E writer: Kestrel's sketch carries three root-glyphs along its lower border, two overlapping the shard.
- [ ] Confirm with Line C writer: Eilin's muting was a Crown-Faith joint act; High Septa Malen did not understand what she was signing; Brenna Greyhold's predecessor refused and was replaced.

## Gaps needing sibling input

1. **Septon Silas location canon.** The Shared Brief's fragment inventory places Silas and the shard at T001. The T004 npcs.json places Silas as resident Septon of Jadehollow's Dawn Chapel. Line B resolves this by making Silas a Jadehollow Septon who walks the third-night pilgrimage south to Stoneford (consistent with the T001 rumour *"Septon Silas walks to the mine entrance every third night"*), and hands off the shard at T001. Needs confirmation from whichever sibling owns Silas's primary residence. Suggested resolution: Silas's *primary* npc record stays at T004; a T001 visit hook is added to T001's npcs.json or facilities.
2. **Naryn's town of residence.** The Shared Brief places the half-burned Northern Ban decree in Archivist Naryn's cabinet at T003. Line A will need to place Naryn definitively. Line B assumes T003-based, with her theory voice deliverable either at T003 or at T004 if Line A carries her south.
3. **Eilin's muting date vs. Northern Ban drafting date.** Line B asserts both occurred eleven years ago and are the same royal act. Line A should either confirm or supply an alternative spacing. If Line A places the Ban later, Line B adjusts Eilin's muting correspondingly.
4. **Iron-Dragon fragment glyph count.** Line B asserts *two* root-glyph overlaps with the shard. Line D owns the Iron-Dragon fragment. Final count (two or three) is Line D's call; Line B will align.
5. **Kestrel's sketch glyph count.** Line B asserts three root-glyphs along the sketch's lower border, two overlapping the shard. Line E owns the sketch. Final count is Line E's call; Line B will align.
6. **Vossel's codex — does any copy survive if Vossel is reassigned south at Outcome 1?** Line B's default: Vossel hides one leaf in the Windrest chapel's altar-stone before departing. If Line C wishes Vossel's reassignment to be clean (for intrigue purposes), Line B will drop the hidden leaf.
7. **Abbot Merick's fate at Outcome 1.** If the Faith removes the board, does Merick resist, comply, or resign? Line B's default: he complies and resigns within the season. Open to sibling adjustment if it conflicts with Line A or C.

## Appendix A — The shard, described

The shard is the line's central object. Writers and orchestrators should hold a consistent picture.

- Size: palm-length, three fingers wide, tapering at one end where it was broken from a larger face.
- Colour: dark grey with a faint green undertone in rain-light.
- Weight: heavier than its size predicts. Not dramatically — enough that a player, asked to guess its weight blindfolded, will guess high.
- Surface: one face worked, one face rough. The worked face carries seventeen incised glyphs in three rows. The rough face carries one fragmentary glyph at its broken edge — a glyph that, if the shard were complete, would be the beginning of a fourth row.
- Temperature: the stone sits at ambient temperature across its rough face. The incised lines of the worked face run approximately half a degree warmer. The difference is not detectable by sight. It is detectable by a fingertip held across the cut.
- Behaviour near the straight-line cloud (Line D): the temperature differential widens, briefly, to perhaps two degrees. No other effect.
- Behaviour in Eilin's presence: no change. The shard does not respond to her. It responds, if anything, only to the cloud.
- Behaviour in the reliquary (Outcome 1): unknown. The reliquary is not opened again in the scope of Line B.

The shard must never glow. It must never hum. It must never be described as *magical* by any NPC on Line B. If a player insists on the word *magical*, Eilin signs a dismissal that Taryn translates as *that is not the word for this*.

## Appendix B — Eilin's gesture vocabulary (partial)

The world-agent will improvise Eilin's signing as needed. The following are fixed.

- **Hand rising, palm up:** *above.*
- **Hand falling, palm down:** *below.*
- **Two fingers meeting at the fingertips:** *they touch* / *they connect.*
- **Hand rising and falling in the same breath:** *above and below connect* (上下相通).
- **Palm flat, drawn across the air at chest height:** *a floor.*
- **Palm flat, turned over and drawn back:** *a ceiling that was a floor.*
- **Fingertips brushing the lips, then opening outward:** *a word that cannot be said* — her self-referential sign, the one she signs when someone asks her name.
- **Thumb to forefinger, a small circle, held up:** *kin.* Used for glyph-kinship.
- **The same circle, opened:** *not kin* / *different hand.*
- **Flat hand, edge forward, pushed slowly:** *the wall moves* — her sign for the harbour-wall scene beat, if she is ever shown it. She will not be shown it in v0.1.

Novice Taryn knows all of these. Abbot Merick knows some. Vossel knows most, and is learning.

## Appendix C — The rubbings-board, by location

Twenty-three rubbings on the scriptorium board when the player first enters. The locations, in Eilin's hand:

1. Monastery cellar, pillar two, knee-height.
2. Monastery cellar, pillar four, shoulder-height.
3. Monastery rear wall (the 上下相通 carving).
4. Monastery well, interior face, below water-line (taken in drought year).
5. Wolfsjaw keep, lower hall, foundation block east.
6. Wolfsjaw keep, lower hall, foundation block west.
7. Wolfsjaw garrison memorial, base stone.
8. Stoneford ford, central stone.
9. Stoneford ford, east bank cut stone.
10. Stoneford chapel, rear door lintel underside.
11. Stoneford river, submerged course (taken by Vossel in winter low-water).
12. Windrest chapel, altar-stone rear face.
13. Windrest keep, watchtower base.
14. Jadehollow mine, second-level drift, east face. (Rubbed by Vossel, smuggled.)
15. Jadehollow mine, second-level drift, south face. (Rubbed by Vossel.)
16. Mistmere harbour-wall, inner-now-outer face, north.
17. Mistmere harbour-wall, inner-now-outer face, south.
18. Mistmere cathedral undercroft, column three, shoulder-height. (Taken forty years ago, before Reynard's limewash policy.)
19. Mistmere cathedral undercroft, column seven, knee-height. (Same.)
20. Mistmere noble quarter, garden wall corner-post, House Vance.
21. Mistmere fishmarket drainage channel, wall three.
22. Road-marker between T002 and T003, eaten by lichen, partial.
23. Unlabelled. Eilin signs that she cannot remember where she took it, only that she was a child.

The shard, when rubbed and added, becomes rubbing twenty-four. It is pinned by Eilin herself. The novice does not touch it.

When the rubbings are arranged in the geographical order of their sites, a ring is visible. The ring does not close until rubbings from the Jadehollow second drift and the Mistmere harbour-wall are set beside each other. This is the moment Eilin signs *it closes*.

## Appendix D — Vossel's codex, partial contents

Twelve folded leaves in the hollow psalter. Each leaf:

- Leaf one: the gesture-for-*above* and its matched glyph (top row, shard position 1).
- Leaf two: the gesture-for-*below* and its matched glyph (shard position 8).
- Leaf three: the gesture-for-*touch* and its matched glyph (shard position 15).
- Leaf four: the gesture-for-*floor* and its matched glyph (cellar pillar two).
- Leaf five: the gesture-for-*ceiling-that-was-a-floor* and its matched glyph (cellar pillar four).
- Leaf six: the gesture-for-*kin* and its matched glyph-pair (shard position 3 and cellar pillar seven).
- Leaf seven: Eilin's diagram of the ring of rubbing-sites.
- Leaf eight: a copied fragment of the Iron-Dragon recitation (**永生 × 黄金 × 无穷**) with Eilin's kinship-circle drawn around two of its characters.
- Leaf nine: Vossel's private note that he does not know what the Iron-Dragon fragment means and does not want to be the one who deciphers it.
- Leaf ten: Eilin's drawing of the monastery rear wall 上下相通, with each glyph annotated by its matched gesture.
- Leaf eleven: blank. Reserved, in Eilin's gesture, *for the glyph I have not yet rubbed*.
- Leaf twelve: Vossel's prayer, in his own hand, asking forgiveness for the copying.

If the player is given a leaf at T003, it is leaf seven (the ring diagram). Leaves one through six are referenced but not given. Leaves eight through ten are held by Vossel. Leaves eleven and twelve are private.

## Appendix E — Scene beat: the journey T002 to T003

Between Windrest and Wolfsjaw, the road climbs. The trees thin. The wind changes at the pass.

On this stretch the player, if carrying the shard, may notice the following, in order:

- A road-marker eaten by lichen, upon which a partial glyph survives where the lichen has been scraped by some earlier hand. Eilin has rubbed this stone (rubbing twenty-two).
- A field of cairns — old, pre-faith, rough. One cairn has been built using a squared block for its base-stone. The block is not a cairn stone. It has been reused.
- A brook crossing on a log bridge. Below the log, on the dry stones of the brook-bed, three flat stones in a row carry scouring marks that might be glyphs or might be water. The world-agent does not confirm.
- At the pass, a sudden view north — the keep visible, the monastery above it, the cliff beyond. The shard, in the satchel, warms briefly for no reason the player can establish. The sky is clear. No cloud.

None of these beats requires an NPC. All are passive description, triggered by carrying the shard.

## Appendix F — Scene beat: the first sight of the monastery

The monastery comes into view an hour before the player reaches it. It sits on a shoulder of rock above the keep. Its outer wall is newer stone on much older courses; at this distance the player cannot tell, but the silhouette is wrong for a monastery of its recorded age — too broad at the base, too narrow at the top, as though a larger building had been truncated and re-roofed.

Inside the main gate, the yard is small. A well. A bell. A covered walk. Novice Taryn meets the player at the gate and does not ask their business. She looks at the satchel. She nods once. She leads them in.

The scriptorium is a long low room off the covered walk. A single high window. Ink smell. Paper smell. A faint smell of cold stone. Eilin sits at the far end, at a sloped desk, her back to the door. She does not turn when they enter. Taryn coughs, once, softly. Eilin lifts a hand — *wait* — and finishes the stroke she is drawing. Then she turns.

Her eyes are the eyes of someone who has been reading small marks in poor light for thirty years. Her mouth is closed and kept closed. She has learned, over eleven years, to keep even the smallest breath from escaping as sound. It is a discipline. It is also a wound.

She extends her hand, palm up. Taryn says, quietly, *she would like to see it.*

## Appendix G — Scene beat: the harbour-wall at low tide

Mistmere's tide retreats furthest on the third day after full moon. On those mornings, for perhaps two hours, the base of the harbour-wall is exposed to the knees of the stones.

The player, walking the harbour-path at that hour, will see, without prompting:

- A seam in the wall, three feet above the current water-line, where two different courses of stone meet at a slight angle.
- Below the seam, the older course. Larger stones. Jointed differently. Seaweed clings unevenly — there are panels the weed avoids and panels it covers, as though the stone itself has different properties course to course.
- On one exposed stone of the older course, three glyphs. Weathered. Visible. One of the three is the shard's position-fifteen glyph. Another is from the Iron-Dragon recitation.

No NPC points any of this out. A gull cries. The tide begins to return. The glyphs will be under water in twenty minutes. The player has time for one rubbing, if they brought paper.

If they return at the next low tide with Vossel, he will ink the rubbing into leaf eleven of the codex — the blank leaf Eilin reserved *for the glyph I have not yet rubbed*. This is the only moment in Line B where Eilin's private reservation is filled by someone other than Eilin. She will, when shown the filled leaf, close her eyes for a long breath, and then sign *thank you*.

## Appendix H — Voice notes

- Eilin never speaks. She never attempts to speak. She does not mouth words. Her silence is complete and intentional. Writers who give her a grunt, a hiss, or a whispered syllable have broken the character.
- Taryn translates flatly. She does not dramatise. She says *above. below. they touch.* — not *my mistress says with great feeling that above and below connect.* The flatness is part of Eilin's method: the meaning must carry itself.
- Vossel is self-deprecating and careful. He never claims credit. He says *I am copying, only.* He is in fact doing much more than copying — he is the only person who has systematically linked Eilin's gestures to her glyph-rubbings — but he will not say so.
- Silas is tired. He has carried the shard for three seasons and it has cost him sleep. He is not a conspirator. He is a priest who found a stone and believed, rightly, that it was not his to keep.
- Abbot Merick speaks once. One line. No more. Writers who give him more lines have broken the character.
- The unnamed Jade Lantern drunk speaks in threes. His only line is triadic and he does not elaborate. Hallen himself — the named carrier of Theory-3 — belongs to Line E at T005; B does not write him.

## Appendix I — What Line B does not do

- Line B does not decipher the shard.
- Line B does not decipher the Iron-Dragon fragment.
- Line B does not name the far side.
- Line B does not confirm any of the four theories.
- Line B does not reveal the hidden premise.
- Line B does not let Eilin speak. Not at any outcome. Not even at the moment of her death, if that comes in a later version of the cycle.
- Line B does not allow the shard to be described as *magical*, as *cursed*, as *blessed*, or as *alive*.
- Line B does not resolve the paradox of relics-underground. It presents four voices. It lets them contradict. It closes the ring on the evidence and leaves the meaning open.

Line B's craft is restraint. The player leaves the line knowing more than they did and understanding less than they think. That is the intended effect. It is the only effect Line B is built to produce.

## Appendix J — The seventeen glyphs of the shard, schematic

The shard's worked face carries seventeen glyphs in three rows. They are not given literal forms in this document — the world-agent may render them as needed — but their positions, kinships, and functions are fixed.

Row one (five glyphs, positions 1 through 5):

- Position 1: the *opening* glyph. Appears also in the third clause of the half-burned Northern Ban decree (Line A). Tall, narrow, with a single rising stroke at the top. Eilin's gesture: hand rising, palm up.
- Position 2: a *modifier* glyph. Appears only on the shard. Function unknown. Eilin does not sign it; she draws a small question-mark beside its rubbing.
- Position 3: a *kin* glyph. Shares lower strokes with one of the three characters in the Iron-Dragon fragment **永生 × 黄金 × 无穷**. Eilin's gesture: thumb-to-forefinger circle, held up.
- Position 4: a *joining* glyph. Two strokes meeting at a point. Appears on cellar pillar four at the monastery. Eilin's gesture: two fingers meeting.
- Position 5: a *closing* glyph for the row. Ornamental. Appears at the end of rows on several rubbings; functions as a row-terminator.

Row two (seven glyphs, positions 6 through 12):

- Position 6: a *below* glyph. Hand falling, palm down. Appears on the Mistmere harbour-wall.
- Position 7: a *floor* glyph. Flat-hand drawn across the chest. Appears on cellar pillar two.
- Position 8: a second *below* glyph, variant form. Eilin signs the same gesture but tilts her hand. The variant is unresolved — kin, or dialect, or error.
- Position 9: a *connective* glyph. Small, between two larger neighbours. Appears rarely.
- Position 10: a *kin* glyph. Shares lower strokes with a second character in the Iron-Dragon fragment. The second of the two shard-to-Iron-Dragon overlaps.
- Position 11: a *joining* glyph, variant. Eilin's gesture: two fingers meeting, but brought up to the forehead — a variant meaning she has not deciphered.
- Position 12: a row-terminator. Same as position 5.

Row three (five glyphs, positions 13 through 17):

- Position 13: an *opening* glyph, variant. Similar to position 1 but with a shorter rising stroke. Appears on the Jadehollow second-drift east face.
- Position 14: a *modifier* glyph. Appears on two rubbings; function unknown.
- Position 15: the *touch* glyph. Two fingertips meeting. The signature glyph of Eilin's **上下相通** translation. Appears on the monastery rear wall. Appears on the Mistmere harbour-wall. Appears on Kestrel's sketch.
- Position 16: a *closing* glyph for the line, not the row. Appears once on the shard, once on the cellar pillar seven, once on the cathedral undercroft column three.
- Position 17: the *terminal* glyph. Ornamental. Indicates the sentence ends here. Eilin has drawn a small line beneath her rubbing of it — the convention in her notes for *this is the last word.*

The fragmentary glyph on the rough face, beginning a fourth row that does not exist, is not catalogued. Eilin has signed, when asked, that she will not catalogue it *until the rest of it is found.*

The shard's seventeen glyphs translate, in Naryn's predecessor's draft, to four sightings — *sun-nailed-to-tower, house-that-flies, iron-that-sings-like-a-forge, the-unending-road* — which are the four named sightings preserved in the Northern Ban's third clause (Line A, Naryn's cabinet). Eilin does not endorse the translation. She has not corrected it either.

## Appendix K — Orchestrator guidance on the four theories

The four theory-voices are to be delivered as **opinion**, never as **fact**. If a player attempts to force an world-agent ruling — *which theory is correct?* — the world-agent must refuse a ruling. Model refusals:

- *The Archivist says what the Archivist knows. The Navigator says what the Navigator knows. They do not know the same things.*
- *Hallen raves — at T005, in the sunken-ward sick-cell, not here. Some of his raving is correct. No one living knows which parts. The drunk in the Jade Lantern is only an echo.*
- *Eilin has signed her theory. She has not claimed it is the answer. She has claimed it is the kinship she can prove.*
- *You will leave this town without a ruling. That is the honest outcome.*

Under no circumstance may an orchestrator, in Line B, pronounce that any of the four is closer to truth than the others. The hidden premise (dead modern civilisation across the Chasm) is never referenced, confirmed, or hinted at in explicit terms. The player may form their own opinion from the accumulated evidence. The world-agent offers no verdict.

## Appendix L — Fail-states and soft-locks

Line B is designed to be unbreakable by player choice — the evidence accumulates regardless of order. Nonetheless, a handful of soft-lock conditions must be watched.

- **Shard lost or destroyed before T003.** If the player sells, discards, or destroys the shard before meeting Eilin, Silas's letter alone is insufficient. Eilin will take the letter. She will sign *return when you find it again.* The line stalls until the player recovers the shard (it can be bought back from the Serpent at T005 for 500 gold — see Line E; or it can be found again at the Stoneford ford, where another similar shard will surface in a later season). The line is not broken. It is paused.
- **Silas killed before handoff.** If Silas is killed at T004 before the player has spoken with him, the shard passes to Sara (T003 medic, ex-Faith). Sara will deliver it to the player on request, with the line: *"He asked me to keep it if anything happened. I have kept it. Now you take it."* Sara's delivery replaces Silas's but does not carry the chapel scene or the third-night walk. Line B accepts this handoff.
- **Eilin killed before T005.** If Eilin is killed — only possible by deliberate player action or by an world-agent choice at a late-game Faith-purge event — the rubbings-board is the inheritance. Vossel becomes the line's sole living voice. The T005 Critical beat proceeds without her sign-language. Her absence is noted. The four-outcome decision still stands.
- **Vossel killed before T002 meeting.** His hollow psalter is recovered from his body by the Windrest Faith chapel's senior brother, who turns it over to the player on the strength of Silas's seal. The codex survives. Vossel does not.
- **Player refuses the shard at T001.** Silas will ask once, wait one in-game week, then press the shard on the next credible traveller (a Bruno's-caravan rider). The shard reaches Eilin without the player. The player may still reach T003 and view the rubbings-board. Their role in Line B becomes witness rather than carrier. The four-outcome decision still stands, with reduced weight.

## Appendix M — Prop handoff log (for world-agent bookkeeping)

Props that must be tracked across sessions:

- **Stone shard.** Starts with Silas at T001 (or T004 depending on canon resolution — see Gaps #1). Passes to player. Passes to Eilin at T003 (typically returned to player with a rubbing). Terminal destination varies by Critical outcome.
- **Silas's sealed letter.** Starts with Silas. Passes to player. Read by Eilin at T003. Retained by Eilin regardless of outcome.
- **Rubbing of the shard.** Created at T003 by Eilin. One copy to the board, one copy given to the player if trusted.
- **Vossel's hollow psalter.** Starts with Vossel at T002. Never leaves his person in ordinary play. Contents copied to the player as single leaves, by Vossel's choice. Psalter itself is recovered only on Vossel's death.
- **Half-burned Northern Ban decree.** Line A fragment. Line B's interest is the third clause.
- **Kestrel's sketch *from below, we may rise*.** Line E fragment. Line B's interest is the three lower-border glyphs.
- **Colonist crest fragment.** Line D fragment. Line B's interest is the two root-glyph overlaps with the shard — a reading, not a claim on the object.

No Line B NPC takes possession of a Line D, Line A, or Line E prop. Line B reads cross-line evidence. It does not hoard it.

## Appendix N — Timeline (private to writers; never delivered to player)

- **Roughly 300 years ago:** the city beneath Mistmere is still standing. Pre-Faith. Pre-royal. The script of the shard is a living hand.
- **Roughly 200 years ago:** the city is collapsed / buried / repurposed (mechanism unresolved, per the four theories). Its walls become foundations. Its columns become cellar pillars. Its floors become flagstones. The script falls out of use.
- **Roughly 120 years ago:** the monastery is built atop the surviving shoulder of the older site. The rear wall's carving **上下相通** is inherited, not carved by the monks. The monks whitewash it.
- **Roughly 100 years ago:** contact with the far side ceases (hidden premise, never delivered).
- **Eighty years ago:** the Ashford estate sinks into the ground (T005 rumour). The Mossbarrow is revealed as a cellar that is older than the house.
- **Forty years ago:** the cathedral undercroft is limewashed for the first time under Reynard's predecessor. Two rubbings of column three and column seven are taken before the limewash, by the predecessor's archivist, and smuggled north. They reach Eilin's master. They become rubbings eighteen and nineteen on her board.
- **Eleven years ago:** Eilin's draft paper surfaces. The Northern Ban is drafted. The Crown and Faith jointly order her muting. The knife is done in the monastery infirmary. Abbot Merick holds her hand.
- **Three years ago:** Vossel arrives at the monastery as a novice. Begins copying gestures.
- **Three seasons ago:** Silas, walking the old mine road north of Stoneford, finds the shard at the ford.
- **Present:** the player arrives in Stoneford. The road ends here.

This timeline is for internal consistency. No NPC speaks it aloud. The dates are load-bearing only for Lines A, C, and D to align against.

## Appendix O — Line B reading list (for the next writer who picks this up)

Before adding to Line B, read, in order:

- This document.
- `_SHARED_BRIEF.md` in full, with attention to the fragment inventory and the four theory-voices.
- `beyond-the-world.md` for the Iron Dragon fragment wording.
- `rumors.md` for Silas's third-night walk and the Ashford-cellar rumour.
- Line A's document, when written, for the Northern Ban's clause structure.
- Line E's document, when written, for Kestrel's sketch and the Crossers' reading of Eilin.
- Line D's document, when written, for the Iron-Dragon fragment's glyph count.

Do not add new glyphs to the shard. Do not add new theories. Do not give Eilin a voice. Do not decipher anything.

If you must add, add rubbings. The board is hers. She will accept more.

## Appendix P — Session seeds for the orchestrator

The following are short scenes the world-agent may drop into any Line B session where the pacing needs a beat.

- **Seed 1: The ink-boy.** A twelve-year-old novice is grinding ink in the scriptorium corner. He has been grinding the same stick for two hours. When the player enters, he does not look up. He says, without turning: *"The Maester grinds her own ink for the rubbings. She says my ink is for letters. She says hers is for stone."* He grinds. He does not elaborate.
- **Seed 2: The lichen-scraper.** On the road between T002 and T003, a woman with a small knife is scraping lichen from a road-marker. She is not a monk. She is not a Faith sister. She says, when asked: *"Some of us keep the markers clean. It is not a guild. It is a habit."* She has been scraping this marker for an hour. The glyph she is uncovering is the position-fifteen glyph.
- **Seed 3: The river-bed at winter.** If the player crosses the Stoneford ford in winter when the water is low, the cut stones of the ford-bed are visible as a masonry floor. A single stone has been levered up and turned over. The underside carries a glyph in fresh condition — the water has preserved it. Whoever levered the stone up is not in evidence. The stone is heavy. The lever-marks are fresh.
- **Seed 4: The abbot's confession.** If the player earns Abbot Merick's trust — and this is difficult, requiring a specific sequence of respectful inaction — he will say, once, looking at the rear-wall carving: *"I held her hand. I have held many hands. None of the others were hers. That is all I will say about it."* He will not say it twice.
- **Seed 5: Vossel in a storm.** If the player travels with Vossel between T002 and T003 in bad weather, the psalter becomes wet. Vossel wraps it in his cassock and rides bare-chested in the rain for two hours. He does not explain. When the player asks, he says: *"The leaves bleed."* He is referring to the ink. He is also, without meaning to, referring to something else.
- **Seed 6: The fishmarket stone.** In T005's fishmarket, a stall-keeper uses a squared stone as a weight on her tarp. The stone carries, on its underside, a fragment of glyph. She has used it for thirty years and never turned it over. If the player buys it from her (one copper), she is baffled and gives it away for free. The glyph matches rubbing twenty-one.
- **Seed 7: The limewash flakes.** A cathedral novice is sweeping the undercroft. Flakes of limewash are coming off in his broom. He is sweeping them into a sack to be burned. If the player intervenes and takes a handful of flakes, some carry partial glyph-impressions on their inner face. These can be brought to Eilin. She will not rub them. She will keep them in a small box.
- **Seed 8: The Serpent's offer.** The Serpent (T005 black market) will offer the player 800 gold for the shard. If refused, he raises to 1200. If refused again, he says: *"The price does not matter. Whoever carries it will be asked. Remember who asked first."* He does not raise further. He will not steal it.

These seeds are optional. The world-agent deploys them when the line needs a pulse between the larger beats.

## Appendix Q — On the phrase 上下相通

The phrase **上下相通** is Line B's still point. Its handling must be careful.

- It is never translated aloud by Eilin. She cannot speak.
- It is translated by Taryn flatly, as *above and below connect* or *above, below, they touch.* Both are acceptable. *They meet* is not.
- It is never translated by Vossel. He writes the characters but does not gloss them. His codex leaf ten is annotated in gesture-glosses, not in prose translation.
- It is never translated by the Faith. Reynard, if pressed, will decline: *"It is a phrase in a dead hand. We do not translate dead hands."*
- It is never translated by the Crown or its archivists.
- The player may translate it for themselves. NPCs will not correct the player's translation. They will also not endorse it.
- It must never be rendered in Line B as meaning *heaven and earth*, *the sacred and the profane*, or any other Faith-flavoured binary. It means, literally, *above and below connect.* That literalness is the point.

The four carved characters on the monastery rear wall are the only uncontested original occurrence of the phrase. All other appearances — in Eilin's rubbings, in Vossel's codex, in the player's notes — are copies of copies. The wall is the source. The wall was not cut by Eilin. Eilin found the wall. That is the whole of her crime.

## Appendix R — Closing world-agent note

Line B is the slow line. It is the line that rewards players who stop walking. A player who rushes from T001 to T005 in pursuit of a louder plot will leave Line B with a shard and no understanding. A player who lingers in the scriptorium, who pulls rubbings in the rain, who kneels in the undercroft with a scrap of paper and a soft pencil, will leave Line B with something closer to knowledge.

Neither is wrong. The line is built to survive both.

The shard must be carried. The ring must be closed. The wall must be found. Everything else is permitted.

That is the whole of the line.

## Appendix S — Per-outcome epilogue beats

For the world-agent rounding out a campaign, each of the four Critical outcomes carries a short coda. These are not required. They are available.

**Outcome 1 coda — Delivered to the Faith (Reynard).**

- One season later, a Faith delegation of six brothers arrives at the Wolfsjaw monastery.
- They carry crates. They carry a writ of inventory.
- Abbot Merick meets them at the gate and does not protest.
- Eilin is not present when the rubbings-board is taken down. She is in the cellar, sitting with pillar four.
- Taryn watches the crates leave. She does not speak for three days.
- Vossel is reassigned to a southern parish within the month. He hides one leaf — the ring diagram — inside the Windrest chapel's altar-stone before departing. The altar-stone will not be opened in living memory.
- The Northern Ban is renewed for ten years. A new clause is added: the mere *description* of the script becomes an offence.
- Silas, learning of all this, walks to the Jadehollow mine entrance on a third night, and does not return. He is not found.
- Eilin lives another eleven years. Her rubbings during those years are kept in a locked chest under her desk. The chest is discovered after her death. Its contents are thirty-one new rubbings. The board, empty for eleven years, is filled again in a single afternoon by Taryn, now the monastery's senior scribe, reading from Eilin's final inventory sheet.

**Outcome 2 coda — Delivered to the Guild (Corvin).**

- The Guild archives absorb the rubbings, the shard, and the codex leaf within two weeks.
- The Northern Ban is quietly rewritten. A new clause is added: *the Silent Order is permitted one monograph, to be held under Guild seal, readable only by Magisters of the third grade or above.*
- Eilin, informed via sign, signs *acceptable.* She does not sign *good.*
- Vossel is appointed her amanuensis. He takes up residence at the monastery within the month. He and Taryn work together for the rest of Eilin's life.
- The monograph is written. It is one hundred and twelve pages. It contains no translation. It contains the ring of rubbings, the kinship argument, and a final blank page reserved for the glyph she has not yet rubbed.
- Two Magisters read the monograph in the first year. Neither speaks of it publicly.
- The shard is returned to the monastery upon Eilin's death. It is placed with her body in the cellar, at the base of pillar four, under a loose flagstone.
- This is the outcome the Guild prefers. It is not the outcome the line prefers. But it is survivable.

**Outcome 3 coda — Handed to Kestrel (the Crossers).**

- The shard, rubbings, and codex leaf are bound into the Crosser brief within a week.
- Kestrel, offered the chance to take Eilin north for the descent, puts the offer to Eilin in person.
- Eilin signs *go.*
- Vossel chooses her. He stays at the monastery. Taryn chooses Eilin. She goes.
- The Crosser descent party leaves in autumn. It does not return in the scope of Line B. (Whether it returns at all is Line E's question.)
- The monastery, without Eilin, becomes quieter than anyone alive remembers. The board is preserved untouched on Abbot Merick's order.
- Vossel begins his own rubbings. He is not as careful as Eilin was. He knows this. He keeps trying.
- The Iron-Dragon fragment remains unread. The shard remains undeciphered. The ring is still closed.
- Somewhere in the descent, on a night that cannot be dated, Taryn writes in a field-journal: *She signed, tonight, that she is tired. The floor is the far wall.* The journal does not survive. This line is included here for writers only.

**Outcome 4 coda — Returned everything to Eilin and walked away.**

- The player leaves the monastery. The board is complete. The shard is pinned to it.
- Eilin lives another eighteen years. She takes no more rubbings after the player's visit. She signs, when Taryn asks why: *the ring is closed.*
- Vossel continues copying. He does not attempt to leave.
- Silas, on his third-night walks, begins to make a pilgrimage to the monastery once a year. He does not speak to Eilin. He sits in the scriptorium for an hour and leaves.
- The Northern Ban is not renewed. It is also not revoked. It simply is not mentioned.
- The Iron-Dragon fragment remains unread. The shard remains undeciphered. Four theories still contradict in four voices.
- No book is written. No monograph is filed. No descent party leaves.
- The player, if they return to T003 in old age, will find the board unchanged and Eilin's chair empty. Taryn, now grey, will nod once. She will say, in Eilin's flat gesture-voice: *above. below. they touch.*
- This is the quietest outcome. It is also, by any honest measure, the outcome the line was built for.

## Appendix T — Final notes on emoji, footers, and voice

- No emoji appear in Line B. Not in dialogue. Not in stage directions. Not in headers. Not in tables.
- No AI-generation footer appears in Line B. The document ends where the document ends.
- The third-person limited voice is maintained throughout. Physical detail precedes emotional description. No exclamation marks. No *suddenly*. No *as if*. No *somehow*.
- The word *ancient* is permitted but should be rationed. Eilin's work is specific. *Ancient* is imprecise.
- The word *civilisation* is forbidden. The player does not yet have a word for what the evidence points to. Neither, properly, does the writer.

## Appendix U — Sibling coordination checklist (one-line items)

- Line A: confirm third-clause-quotes-opening-glyph.
- Line A: confirm Ban drafting year = Eilin muting year.
- Line A: confirm Corvin is the first to speak *Northern Ban* aloud to the player.
- Line A: confirm Naryn's primary residence and her willingness to deliver the collapse-burial theory aloud.
- Line C: confirm High Septa Malen signed without understanding.
- Line C: confirm Brenna Greyhold's predecessor refused and was replaced.
- Line C: confirm Darrik Voss knew what he was signing.
- Line D: confirm two shard-to-Iron-Dragon root-glyph overlaps.
- Line D: confirm the Iron-Dragon fragment is never deciphered in v0.1.
- Line D: confirm the straight-line cloud warms the shard, or adjust.
- Line E: confirm Kestrel archives Eilin's drawings.
- Line E: confirm the sketch carries three lower-border root-glyphs.
- Line E: confirm Kestrel's Crosser theory voice is available at T004.
- Line E: confirm the Serpent's 800/1200-gold shard offer is compatible with Line E's economy.
- Shared: confirm Silas's residence canon (T001 visit vs. T004 primary).
- Shared: confirm Vossel's introduction as a NEW NPC at T002.
- Shared: confirm Eilin, Merick, and Taryn as NEW NPCs at T003. Hallen is a Line E NPC at T005 (sunken-ward sick-cell), not a Line B NPC; B adds only the unnamed Jade Lantern drunk.
- Shared: confirm the monastery rear-wall carving 上下相通 as a facility addition at T003.
- Shared: confirm the harbour-wall low-tide scene beat as a facility addition at T005.
- Shared: confirm the cathedral undercroft limewash-thinning scene beat as a facility addition at T005.

- Shared: confirm the Stoneford ford-bed masonry as a facility addition at T001 (return-visit only).
- Shared: confirm the Jadehollow second-drift worked-stone wall as a facility addition at T004.
- Shared: confirm the road-marker lichen-scraping scene on the T002→T003 road.

End of Line B brief.




