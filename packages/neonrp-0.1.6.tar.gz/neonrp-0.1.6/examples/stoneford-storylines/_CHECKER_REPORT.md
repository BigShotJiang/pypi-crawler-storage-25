# Checker Report — Stoneford Storylines

## Summary verdict

**needs-editor-pass.**

The five storylines are internally rich, tonally consistent, and respect the hidden-premise discipline with only one near-leak (Line D's Forbidden scrap literally lifts the Shared Brief's forbidden-vocabulary phrasing into a player-facing item, but stays inside the sanctioned indigenous register). There are **three hard contradictions** that will break at the world-agent layer if not reconciled, **four cross-line phrase/count mismatches** that need a single editorial sweep to unify, and **one NPC-roster collision** (Septon Silas: T001 vs T004). None of the issues are rewrites; all are reconcilable at the line-edit level.

## Blockers (must fix before editor pass)

- [x] **B1. Septon Silas's residence contradiction.** The existing town roster (`NeonRP/examples/stoneford-orchestrator/game/towns/T004/facilities/chapel.json` and `T004/quests.json` Q_T004_05) places Silas as resident Septon of Jadehollow's Dawn Chapel. Shared Brief's fragment inventory assigns the stone shard to "Septon Silas · T001." Line A's T001 clue table writes "Septon Silas (NPC_T004_07)" (i.e. visiting from T004). Line B explicitly flags this as an open gap (B/gap 1). Line E refers to "Septon Silas at T001" once and "Septon Silas (NPC_T004_07)" elsewhere. Line C does not touch the residence but references Silas at T003 receiving a refused letter at his address. **Resolution:** Silas's primary record stays at T004; a "visiting at T001 on third-night walk" hook is added to T001 (not a new NPC record). All four lines must adopt this phrasing. Line B already offers this resolution; adopt it line-wide.

- [x] **B2. Hallen's location contradiction.** Line B/T004 places Hallen as a mad returnee in the Jade Lantern tavern back room (T004 clue table and write-in checklist: "NEW NPC — Hallen the mad returnee … T004"). Line E/T005 places Hallen "in the sick-cell of the sunken ward" at T005 as a new NPC, age sixty, and assigns him the *exact same* theory-voice line ("Below and beyond are one. The floor is the far wall.") and the Shared-Brief Theory-3 canon delivery. **Two writers have instantiated the same NPC in two different towns.** Shared Brief says only "Hallen (mad returnee) ravings" without assigning a town. **Resolution:** Hallen lives at T005 sick-cell (E's placement matches the Shared Brief's flow: Listeners' ward, Theory-3 delivered at the Critical). Line B's T004 Hallen-at-tavern scene should be demoted to an *unnamed rhythm-speech drunk* or a *brief T004 cameo of Hallen while he winters down from the scree*. Editor must pick one and cut the other.

- [x] **B3. Preceptor Vossel bloodline contradiction.** Line C (cross-line B↔C, line 468) asserts: "Preceptor Vossel the Younger (B sub-soul at T002) is a cousin of House Voss — of Darrik's line. His muted presence in the monastery is itself a royal arrangement: Darrik's father exiled him to the Faith's order so that the Voss bloodline would have a silent eye inside the Septa's house." Line B's Vossel is a Faith scribe with no bloodline notice; Line B Appendix J and write-in checklist show a nervous junior scribe whose function is to smuggle Eilin's gestures out. Making Vossel a Voss-cousin planted by the Crown *fundamentally changes* B's trust-logic — Eilin's smuggler is actually a royal eye. Line B's gaps flag this as B/gap 6 (clean reassignment vs. hidden-leaf) and C flags it too (C/gap "B↔C — Vossel bloodline"). **Resolution:** Editor chooses. Recommendation: **drop the C-side assertion.** It is a late addition by C that breaks B's Vossel integrity and does no load-bearing work in C (the Herald and the fifth door carry C). If kept, B must add a single quiet beat — Vossel recognises a Voss thumb-ring and says nothing — and reframe his codex-smuggling as *self-directed* despite his origin.

## Serious issues (editor should fix)

- [x] **S1. Northern Ban date vs. Eilin's muting date.** Line B (Function + T005 Corvin dialogue): Eilin was muted eleven years ago; the Northern Ban was drafted *the same season* as her muting. Line A's Corvin soul-figure has "not slept a full night in nine years" (his own tenure), and A's T005 Corvin dialogue states the Charter was founded two centuries ago with no drafted-eleven-years-ago claim for the Ban itself. A's T001 and T003 clue tables describe the half-burned decree as burned "seven years ago" and do not date its original drafting. **B asserts Ban-drafted = 11y ago; A is silent.** Editor: ratify B's date and add one line to A/T005 Corvin dialogue ("The Ban was re-drafted eleven years ago, in the same season a maester's tongue was taken in the north"). This is B/gap 3 and also A/gap to Line B.

- [x] **S2. Northern Ban "four indigenous-sensory phrases" vs. shard phrase-order.** Line A/T003 Naryn's-cabinet decree quotes *"sun-nailed-to-tower, house-that-flies, iron-that-sings-like-a-forge, the-unending-road"* in that order — A asks B to confirm. Line B says the decree quotes "the opening glyph of the shard" (singular, not the four phrases), and Line B's shard carries **seventeen glyphs in three rows**, not four phrases. Line D's Forbidden scrap quotes three of A's four phrases verbatim ("the house that flew … iron that knew the wind … do not attempt to visit"). **The discrepancy:** A treats the Ban's operative clause as four discrete indigenous-sensory phrases; B treats the shard as a glyph-carrier (not a phrase-carrier). **Resolution:** Editor promotes A's four phrases to canon (they are the best-drafted text in the bundle and D already quotes them) and B re-frames: *the shard carries glyphs; the glyphs translate to the four named sightings; Eilin does not decipher but Naryn's predecessor did.* A's checklist item "T001/items add ancient stone shard" stays in B's hands; no rewrite needed, just an aligning sentence in B.

- [x] **S3. Ban signatures — "three signing crowns" vs. "all four."** Line E/T005 contract-parchment is sealed by "three-crown seal; the fourth crown is absent." Line E explicitly attributes the absent crown to the Free North (Brenna). Line A/T005 describes the Charter (founding) as signed by all four original crowns; A does not state how many signed the *modern* Ban. Line C/T003 decree (half-burned) "co-signed by all four original arbitration seats" — and C/E cross says "Brenna Greyhold's predecessor refused to co-sign and was replaced within the year" (B↔C). But C/T005 contract reveals the Listener contract is three-crown only, with Brenna abstaining. **Problem:** if B↔C says Brenna's predecessor was replaced for refusing, Brenna herself should not be able to abstain from the *same kind of document* without consequence. **Resolution:** distinguish the two documents. (a) The Charter/Ban is four-crown (B↔C is correct). (b) The Listener contract on Sula's desk is a narrower crown-operational contract (not the Ban itself) and three-crown is legitimate because the Free North's historical signing was a Charter-level act, not a Listener-level one. A single aligning sentence in E at T005 ("the contract is not the Ban; it is the Listener bond under the Ban, and Brenna has never signed one") resolves it. This is E/gap 1.

- [x] **S4. Root-glyph overlap counts.** Line B asserts **two** shard ↔ Iron-Dragon (永生×黄金×无穷) overlaps (Appendix J, positions 3 and 10). Line D/B-cross says "two root glyphs" — agrees. Line B asserts **three** shard ↔ Crosser-sketch overlaps and **three** shard ↔ monastery-wall overlaps ("kin, not the same hand"). Line E says the sketch "shares at least three root-glyphs with the stone shard at T001 AND with Eilin's monastery wall (line B)" — agrees on *three*. Line A says nothing about counts (correctly out of scope). **All three ledgers now align at 2/3/3.** No action needed *unless* editor wants to promote to canon a single phrasing in each file. Low-priority tidy.

- [x] **S5. The Ashen Herald's identity candidate list.** Line C leaves Herald identity open with four candidates ("Jenn; a Tobiah twin; a Voss cousin exiled before Darrik's birth; Brenna's elder sister who does not officially exist"). Lines A, B, D, E do not reference the Herald at all except D (once: "Veyl's crest fragment visually echoes patterns on colonist crest fragments held by the four royal lines … the Ashen Herald at T005"). **Issue:** C/T005 encounter-with-Brenna cross-writer candidate note says "Jenn is Brenna's niece," and C/Herald dossier says Jenn stole the cipher independently (the Herald did *not* hire her). If the editor canonises "Herald = Brenna's elder sister" (one of C's candidates), the Jenn-niece note becomes Brenna's-niece = Herald's-niece, which is a clean line. If the editor picks "Jenn herself = Herald," the Jenn-niece note must be cut. **Resolution:** editor picks one. Recommendation: Brenna's elder sister (unofficial) — it aligns with C's colonial-memory logic (Brenna "remembers, and cannot say") and lets Jenn-the-niece remain a low-level courier.

- [x] **S6. Bram's age / letter-carrying past.** Line C (C↔D cross) claims: "Old Shepherd Bram (D sub-soul) has, in his youth, carried messages between Brenna's grandmother and Darrik's grandfather, and will — if asked — say exactly one thing: *'The old chieftess and the old king used to write each other in winter. They wrote in the same hand. They learned to write from the same woman.'*" Line D describes Bram as "sixty-some, deep lines in his face, one eye clouded, a limp in the left knee." Brenna's grandmother and Darrik's grandfather would have been active ~60–90 years ago; Bram at 60-something in his *youth* could just plausibly have carried letters 45+ years ago to royals in their *later* generation, not grandparents. **Numerical tension.** Resolution options: (a) bump Bram to seventy-five (editable); (b) swap C's line to "Bram's father carried letters" (cleanest, minimal damage); (c) make the royals "Brenna's mother and Darrik's father." Line D gap note (γ-raised) flags this. Editor: option (b).

- [x] **S7. The "Ashen Herald" vs. "Ashen Howe" overlap.** Line A introduces **Factor Selm Ashen-Howe** (T003 Guild factor, "Ashen cousin-house"). Line C's sub-soul is **the Ashen Herald** (masked, no name, no house). *Ashen* is used in two different registers in two different lines: as a surname-prefix (Ashen-Howe, Ashen cousin-house) and as a descriptor of colour (ash-grey cloak, un-glazed clay). The Faith's costume is also "robes the colour of wet ash." Not a strict contradiction but a naming collision the editor should note. **Resolution:** rename A's factor to **Selm Orren-Howe** or **Selm Cole-Howe** (avoid "Ashen" in a surname role), reserving "Ashen" for the Herald's un-glazed-mask register. Low-priority but affects player-facing tone.

## Minor issues

- [x] **M1. Crosser sketch glyph count alignment.** Line B asserts "three root-glyphs along the sketch's lower border, two overlapping the shard, one on the harbour-wall inner face." Line E says "shares at least three root-glyphs with the stone shard at T001 and with Eilin's monastery wall." E's *at least three* and B's precise *three* are compatible but B's precision should be promoted to canon. Add "three" to E.

- [x] **M2. Abbot Merick's fate at B-Outcome 1.** B/gap 7 flags this: if the Faith removes Eilin's board, does Merick resist/comply/resign? No other line has opinions. B's default (comply + resign within season) is fine. No blocker; editor may leave the default.

- [x] **M3. Brenna's tolerance vs. Ban unanimity.** ε-raised in the prompt's G. Resolved by S3 above (distinguish Charter/Ban from Listener contract). No additional fix needed.

- [x] **M4. Cloud-night timing.** ε-raised: E/gap 2 — confirm cloud-night occurs *before* the T005 E-confession. Line D never sets an absolute date for the cloud beyond "dawn of the second day at T002" and "recurs three-four times per season." Line C places "the straight-line cloud appears over Mistmere on the morning after the summit" in Endpoint 2 — but this is a *recurrence*, not the T002-hook occurrence. **No contradiction** but editor should add a one-line note in D's world-agent conduct: *"The T002 sprout-cloud is the earliest; recurrences are routine. The T005 E-confession occurs on a cloud-night that may be the sprout-cloud (if pacing is tight) or a later recurrence."*

- [x] **M5. Eilin chalk-slate register.** E asks B to allow Eilin to carry two specific phrases: *"he keeps them"* (about Kestrel holding her drawings) and *"the ring is untrue"* (about the lantern's off-centre tenth dot). B's chalk-slate register already includes *"The lantern is not of the cell that claims it. The ring is untrue. Who gave it to you?"* — **match confirmed.** B does not currently include *"he keeps them."* Editor: add one chalk line to B's T003 clue table: *"If asked about her lost sketches, Eilin writes in chalk: 'he keeps them.'"* This is B/gap-cross-E.

- [x] **M6. Bram's pasture Listener-sighting.** ε-raised. E asks D to add to Bram's dialogue a line about grey-coated folk crossing his high pasture at dusk with unlit lanterns. D's current Bram does not contain this. Editor: add to D/T004 Bram clue table (per E's requested phrasing): *"Grey-coated folk. The earth-men, maybe. I do not trouble them and they do not trouble me."* Non-controversial.

- [x] **M7. Corvin's office location for payment handler.** α-raised. E's door-2 (betray to the Guild) hands the parchment to "Magister Corvin Ashford-Reed at T005 (Guild soul figure, line A) or to the Guild branch at T001." A already has Corvin at T005 High House and the four endings (Reform/Burn/Break/Inherit) — but has no specific *sealed-letter payment* handler for E's door-2 parchment delivery. Editor: add one bullet to A/T005 Magister Corvin beats: *"If presented with a Listener contract parchment — he reads it in silence, pays by sealed letter through Hess Veigh, does not speak the player's name, and does not invite them to return."* This is E/gap 3 and δ-raised.

- [x] **M8. Veyl colonist-crest fragment <-> Darrik's colonist crest fragment.** Shared Brief places "colonist crest fragment · Veyl's pocket · T005 · D (+colonial history)." Line C's backstory ("Crown · King-Apparent Darrik Voss — drinks the unaging tea; has a colonist crest fragment") also gives Darrik a colonist crest fragment. C/D cross says "Veyl's crest fragment visually echoes patterns on the colonist crest fragments held by the four royal lines." **Two crest fragments exist:** Veyl's (pocket, D-fragment inventory) and Darrik's (Crown's private relic, C). This is **not** a duplicate. The SHARED_BRIEF inventory is Veyl's; Darrik's is unnamed in the inventory because it does not migrate to the player. Editor: add a one-line note in C's colonial-shadow appendix clarifying that Darrik's crest is *not* the inventory item and must not be transferable.

- [x] **M9. Corvin's payment for sealed letter.** ε-raised. Covered by M7. No separate fix.

- [x] **M10. Sula ledger / slow-stone audit.** δ-raised. E's Listener contract and slow-stone audit mechanics are internally consistent. No other line references them. No action.

- [x] **M11. Crosser marginalia acceptance.** δ-raised. D/T004 adds "or from above, if above returns" Crosser graffito next to E's sketch. E's T004 clue table includes the sketch but does not reference D's graffito. Editor: add a one-line cross-note in E's T004 table: *"A second hand has written beside the sketch 'or from above, if above returns.' This is a Crosser response to the cloud, per Line D."* Non-blocking.

- [x] **M12. Royal crest visual spec.** δ-raised. Veyl's crest is described in D/T005 as "a bird on a sunburst, the bird's wings sharp and angled like no bird's wings are." C's four-knot is "four loops around an empty centre." These are **different sigils** (good — Veyl's crest is a personal-lineage item, the four-knot is a council seal). No contradiction. No action.

## Resolved internally (no action needed)

- **Ashen Herald's vocabulary discipline.** C's Herald never says *colonist*, *far side*, or modern vocabulary on-screen; the dossier is writer-only. Clean.
- **Four NPC theories on why relics are underground.** All four are delivered by named NPCs in the correct towns per SHARED_BRIEF: Naryn (collapse-burial, T003/T004), Kestrel (transit, T004), Hallen (identity, T005 per E / T004 per B — see B2), Eilin (kinship, T003). Only the Hallen location requires a pick.
- **Fragment inventory — all 10 placed.** See section C below. All ten SHARED_BRIEF fragments have a home in at least one line; none duplicated across lines except the two sketched as "belong primarily to line X, referenced by line Y," which is correct per the brief.
- **Voice discipline.** All five lines hold the low-fantasy / indigenous-sensory register. No modern vocabulary leaks in player-facing text.
- **Hidden premise.** Never stated in any line's player-facing text. Writer-only backgrounders (C's colonial-shadow appendix, E's dossier, D's world-agent notes) are correctly flagged as writer-only.
- **Eilin never speaks.** B Appendix H is strict. No line violates this.
- **Bram's one line.** D enforces "said once." No other line undermines this. E's Bram pasture-sighting line (M6) is a *different* line about Listeners, not the dragon testimony; the constraint holds.

## Detailed findings

### A. Hard contradictions

1. **Septon Silas residence** — see **B1**. T001 vs. T004. Fixable.
2. **Hallen's town** — see **B2**. T004 vs. T005. Fixable.
3. **Vossel bloodline** — see **B3**. C-side assertion breaks B's internal logic. Fixable by cutting C's claim or by one reconciling line in B.
4. **Eilin muting date / Ban drafting date** — see **S1**. Fixable by accepting B's "eleven years ago" date and adding one Corvin line in A.
5. **Ban signatures (three vs. four crowns)** — see **S3**. Fixable by distinguishing Charter/Ban from Listener contract.
6. **Bram age vs. letter-carrying** — see **S6**. Fixable by swapping to "Bram's father carried letters."

No other hard contradictions detected.

### B. Hidden-premise leaks

**None in player-facing text.** All writer-dossier content is correctly fenced as writer-only (C's colonial-shadow appendix, E's world-agent notes, D's world-agent conduct notes).

**Near-misses noted:**
- Line D's Forbidden scrap (T003) contains the phrase "*do not attempt to visit*" — this is the Shared Brief's hidden hero-line, but it is given here in indigenous register inside an in-world parchment attributed to "the Hero." This is allowed by the brief (the Hero is an in-world figure; the line is *quoted as canonical hero-utterance*, not as authorial narration). **OK — not a leak.**
- Line C's Brenna utters *"Vi kam fra den andre sida"* — *"We came from the other side."* This is the nearest any line gets to naming the premise, and the brief explicitly permits one utterance, in clan-tongue, once. **OK — sanctioned.**
- Line D's Veyl recitation takes "nine generations" — no arithmetic breaks the hundred-year silence (9 × 11-12y avg = 99-108y). **OK.**

No action required for section B.

### C. Fragment inventory integrity

All 10 fragments from SHARED_BRIEF are placed exactly once:

| # | Fragment | SHARED_BRIEF location | Placed by line | Status |
|---|----------|-----------------------|----------------|--------|
| 1 | Ancient stone shard | T001 · Septon Silas | B · T001 (Silas carries, transfers) | ✅ |
| 2 | Old Guild brass token | T001 · Hidden under tavern hearth | A · T001 (Shale Lantern hearth-stone, Mira's husband) | ✅ |
| 3 | Un-hammerable metal lump | T002 · Durm | D · T002 (Blacksmith Durm, corner of Kalran's forge) | ✅ |
| 4 | Wall glyphs 上下相通 | T003 · Monastery back wall | B · T003 (primary owner); A · T003 (references); E · T003 (visual gate); C · T003 (scrubbing-order reference) | ✅ |
| 5 | Unaging-tea dregs | T004 · Crown envoy's cup | C · T004 (Envoy Alric's cup at the Jade Lantern) | ✅ |
| 6 | Crosser sketch "from below, we may rise" | T004 · Library deep archive | E · T004 (primary); referenced by A, B, C, D | ✅ |
| 7 | Colonist crest fragment | T005 · Veyl's pocket | D · T005 (Veyl carries) | ✅ (see M8) |
| 8 | Listener contract parchment | T005 · Sula's desk | E · T005 (primary) | ✅ |
| 9 | Straight-line cloud (sky event) | T002 · Sky between T001→T002 | D · T002 (primary sprout); referenced by B, C, E | ✅ |
| 10 | Half-burned "Northern Ban" decree | T003 · Archivist Naryn's cabinet | A · T003 (primary owner); B, C, D reference | ✅ |

No duplicates. No missing. Cross-line references all resolve to a single primary location.

### D. Cross-line dependencies

All six SHARED_BRIEF dependencies are implemented in both sides:

| Dependency | Implementation | Status |
|------------|----------------|--------|
| A↔B (Guild "Northern Ban" quotes shard) | A/T003 Naryn decree quotes four shard-phrases; B/T005 Corvin speaks "Northern Ban" aloud and ties to Eilin's muting | ✅ with S2 (phrase-list vs. glyph-level alignment) |
| A↔C (Guild was four-crown arbitration body) | A/T005 Corvin dialogue on four-crown origin; C/T005 four-knot seal and bricked fifth door; C/T001 Heron "the Guild used to answer to that knot"; A's Reform ending requires C's summit-room delivery | ✅ |
| A↔D (Guild suppresses cloud sightings; pressures Bram) | A/T002 Tamsin's suppression stipends (Bram on the list); A/T004 Kassa's register (Bram cat. *sky*, 3 stipends, doubled); D/T001 torn Guild notice signed "C.A.-R."; D/T003 Corporal Hest; D/T004 Hest's evening with Bram | ✅ |
| B↔E (Kestrel archives Eilin's drawings; sketch shares root-glyphs) | B/T004 Kestrel theory/Eilin drawings + B/T005 sketch-glyph overlap; E/T004 Kestrel dialogue "I have her drawings"; three-glyph overlap in both ledgers | ✅ (M1 tidy) |
| C↔E (Northern royals suppress Depth-Walkers) | C/T003 Linden "Septa sent riders to arrest any pilgrim who has been below"; C/T005 contract-parchment seal (three-crown, Free North absent — see S3); E/T005 contract clauses spelled out; C↔E Brenna's private tolerance | ✅ with S3 |
| D↔E (cloud-night → Listeners douse lanterns; Crossers read as scout) | D's T002 cloud; E/T002 wick self-lights during cloud, Yannic white-faced; E/T005 simultaneous lantern-dousing on cloud-night; D/T004 Crosser marginalia "or from above, if above returns" | ✅ (M4 timing note) |

All six dependencies are concretely implemented by both sides. Only S3 needs reconciliation.

### E. NPC collisions

**New NPCs introduced (cross-line comparison):**

- **A**: Magister Corvin Ashford-Reed (T005), Keeper-Commander Olric the Silent (grave, T003), Clerk-Registrar Tamsin Howe (T002), Factor Selm Ashen-Howe (T003), Archivist Naryn (T003), Senior Clerk Hess Veigh (T005)
- **B**: Maester Eilin of the Broken Tongue (T003), Preceptor Vossel the Younger (T002), Abbot Merick (T003), Novice Taryn (T003), Hallen the mad returnee (T004) ← see B2
- **C**: Jenn (T001), Ylva Stoneshield (T002), Envoy Alric of House Voss (T004), Darrik Voss (T005), High Septa Malen the Unsleeping (T005), Chieftess Brenna Greyhold (T005), Consul-Merchant Tobiah Caul (T005), The Ashen Herald (T005), Clerk Ostric (T004, bit-part librarian)
- **D**: Blacksmith Durm (T002), Traveler Nole (T002), Corporal Hest (T003), Old Shepherd Bram (T004), Old woman Haddie (T004), Veyl "the Line" (T005)
- **E**: Yannic "Yan" Vello (T002), Navigator Kestrel (T004), unnamed old Listener at T003 cave, Archdepth Sula (T005), Hallen (T005) ← see B2, six unnamed attending Listeners (T005)

**Collisions across new NPCs:** only **Hallen** (B2) — two writers created the same mad-returnee in different towns with identical Theory-3 canon dialogue.

**Collisions with existing T001–T005 rosters:**
- **Septon Silas** (existing NPC_T004_07 in T004 roster per existing `chapel.json` and Q_T004_05) — Lines A, B, C, D, E all reference Silas. Only B creates a clear T001 **visiting hook** (not a duplicate NPC). Lines A and E correctly tag him "NPC_T004_07" when citing. **B1 above resolves this.**
- **Old Shepherd Bram** — Shared Brief places him at T004; Lines A, C, D, E all reference. No collision; he is primary-D.
- **Septon Silas name** is also invoked in Line D/T001 as "Septon (cameo, visiting from Jadehollow)" delivering a sermon line. Matches B's "third-night walk to Stoneford." Consistent.
- **Maester Eilin** — primary-B at T003; referenced by A, C, D (locked-shelf neighbour), E. No collision.
- **Factor Selm Ashen-Howe** — see S7 (naming collision with "Ashen Herald" register only; not a character collision).
- **Preceptor Vossel the Younger** — B's creation; C reassigns bloodline (see B3). Not a duplicate; a contested characterisation.

No other name collisions. The existing-roster NPCs (Heron Blackwater NPC001, Old Reed NPC002, Mira Ashford NPC003, Captain Yura NPC_T002_01, Old Zhao NPC_T002_02, Mei NPC_T002_03, Brown NPC_T002_04, Kalran, Lord Commander Linden NPC_T003_01, Sara NPC_T003_02, Mark NPC_T003_03, Kassa Deepvein NPC_T004_01, Ironpost NPC_T004_02, Old Fane Crowseye NPC_T004_03, Jade NPC_T004_04, Grandmother Green NPC_T004_05, Damon NPC_T004_06, Septon Silas NPC_T004_07, Hawke NPC_T004_08, Bishop Reynard NPC_T005_02, Lady Vera NPC_T005_03, The Serpent NPC_T005_05) are referenced with correct IDs in each storyline.

### F. Write-in checklist completeness

All five lines carry concrete "Write-in checklist for town writers" sections with named NPCs, specific dialogue phrasings (in quotes), specific facility locations, and fragment-level specifications.

**Checklists that are concrete and actionable:**
- A: every new NPC has a name, age, dialogue beats, and a house-flag; every existing NPC has a specific dialogue quotation. ✅
- B: every new NPC and every rubbing-site is specified; the shard has a dedicated Appendix A physical spec and Appendix J 17-glyph schematic. ✅
- C: new NPCs are complete; the four material signatures are fixed as non-negotiable; the three-layer annotation discipline is a writer-only tool documented and enforced. ✅
- D: every new NPC has a role, the lullaby is canonical four-line text, Veyl's locket/recitation/fragment are specified. ✅
- E: every new NPC has state flags; the lantern has a full physical spec including base-mark; the three rituals are documented. ✅

**Ambiguities flagged in checklists themselves (author-admitted gaps):** consolidated in section G below.

**Editor concerns on checklist granularity:**
- **A/T001/Heron** beats are very specific ("finger-stump tap the desk once, twice") — good.
- **C/T001/Heron** adds a dialogue branch with three-layer annotation — annotation must be stripped from the actual npcs.json write-in; the check is that the editor *implements* only the `public=` line.
- **E/T002/Yannic** dialogue is explicit and quotable. ✅
- **B/T003/Abbot Merick** — only one line, enforced. ✅
- **D/T005/Veyl** — three-option ask is fully scripted. ✅

No checklist is fatally vague. The prompt's concern ("*add a line about…* without specifying which NPC / what line") does not apply here; every instruction names a person and quotes the line.

### G. Gap consolidation

The prompt enumerates gaps raised by each writer; consolidating and marking resolution status:

**α (Line A writer's gaps):**
- B-shard phrase-order → **S2** (unresolved; editor action required).
- C-summit deliverable (four crowns in a room) → **resolved** by C's Critical scene at T005 (summit chamber is fully staged, all four crowns physically present).
- D-Bram testimony ownership → **resolved** (D owns Bram's dialogue and death; A uses but does not rewrite).
- E-Crosser-sketch placement → **resolved** (E keeps it in T004 library deep archive, as A expects).

**β (Line B writer's gaps):**
- Silas residence conflict → **B1** (unresolved; blocker).
- Ban clause alignment → **S2** (unresolved).
- Root-glyph overlap count with D → **resolved** (both agree on two).
- Kestrel sketch glyph count → **resolved** (both agree on three; M1 tidy).
- Muting/Ban date sync → **S1** (unresolved; editor).
- Vossel-Voss lineage with C → **B3** (unresolved; blocker).
- Abbot Merick fate → **M2** (resolved by B's default).

**γ (Line C writer's gaps):**
- Charter "four seats and a fifth" reference → **resolved** in A (A/T005 Charter clauses name four crowns; the bricked-up fifth door is C's canonical expression of the implicit fifth; C explicitly flags "four-knot seal with empty centre" as the structural referent).
- Vossel Voss-cousin lineage → **B3** (unresolved; blocker).
- Bram age permitting past letter-carrying → **S6** (unresolved; editor).
- Ashen Herald canonical identity → **S5** (unresolved; editor picks from four candidates).

**δ (Line D writer's gaps):**
- Corvin's office location for payment handler → **M7** (unresolved; editor adds one bullet to A).
- Eilin materials / 上下相通 glyph co-location → **resolved** (B owns the wall; A, D, C all reference correctly).
- Royal crest visual spec → **M12** (resolved; Veyl's crest and four-knot are different sigils by design).
- Crosser marginalia acceptance → **M11** (unresolved; minor; editor adds one cross-note in E).
- Sula ledger → **M10** (resolved; fully owned by E).

**ε (Line E writer's gaps):**
- Brenna tolerance vs. Ban unanimity → **S3** (unresolved; editor; solution = distinguish Charter/Ban from Listener contract).
- Cloud-night timing → **M4** (resolved by one-line world-agent note).
- Corvin sealed-letter payment → **M7** (unresolved; editor).
- Eilin slate phrasings → **M5** (resolved for *ring is untrue*; unresolved for *he keeps them* — add one line to B).
- Bram pasture Listener-sighting → **M6** (unresolved; editor adds one line to D).

**Still-unresolved master list (fold into Blockers/Serious/Minor above):**
B1, B2, B3, S1, S2, S3, S5, S6, S7, M1, M5, M6, M7, M11.

No gap is a rewrite; all are surgical line edits.

## Proposed resolutions (to hand the editor)

### Blockers

**B1 — Silas residence.** File: all five lines. Action: keep Silas primary at T004 (NPC_T004_07). Add a T001 *visiting hook* (not a new NPC record) to T001/facilities.json (chapel behind Shale Lantern; third-night walk from T004 per the existing T001 rumour). Ratify B's proposal in Section "Gaps needing sibling input"; then update A/T001 ("Septon Silas (visiting from T004)"), E/T001 ("Septon Silas · passing remark"), D/T001 ("Septon visiting from Jadehollow"). All already use this phrasing — confirm in one editorial sweep.

**B2 — Hallen location.** File: `B-world-before-the-fog.md` (T004 clue table + write-in checklist) and `E-depth-walkers.md` (T005 clue table). Action: canonise Hallen at **T005 sick-cell** (E's placement, as it anchors Theory-3 to the Critical). Edit B: delete the T004 Hallen "NEW NPC" write-in and replace with "an unnamed rhythm-speech drunk at the Jade Lantern repeats the triadic fragment *'below and beyond are one…'* — he does not know its source and will not say more; the named carrier Hallen is at T005 (see Line E)." Delete Hallen from B's theory-voice delivery claim at T004; keep him as the canonical Theory-3 voice but only at T005.

**B3 — Vossel bloodline.** File: `C-four-crown-intrigue.md` cross-line section and the Preceptor Vossel paragraph. Action: delete or soften the assertion that Vossel is Darrik's Voss cousin planted by the Crown. Replace with: "Preceptor Vossel the Younger (B sub-soul, T002) maintains quiet correspondence with the monastery while traveling — Line C does not claim his bloodline." If the editor wishes to keep a seed, reduce to: "Vossel's northern cousin-house is a matter no one in the monastery presses; he himself does not speak of it." That is toothless enough to not break B.

### Serious

**S1 — Ban/muting date.** File: `A-guild-buried-charter.md` T005 Corvin dialogue. Action: add one sentence to Corvin's opening: *"The Ban was re-drafted eleven years ago, in the same season a maester's tongue was taken in the north. I was not Magister then. I inherited both."* Aligns with B.

**S2 — Ban quotation vs. shard glyphs.** File: `B-world-before-the-fog.md` Appendix J (shard schematic). Action: add one sentence: *"The shard's seventeen glyphs translate, in Naryn's predecessor's draft, to four sightings — sun-nailed-to-tower, house-that-flies, iron-that-sings-like-a-forge, the-unending-road — which are the four named sightings preserved in the Northern Ban's third clause. Eilin does not endorse the translation. She has not corrected it either."*

**S3 — three-crown Listener contract.** File: `E-depth-walkers.md` T005 Listener-contract-parchment entry. Action: add one line: *"This contract is not the Northern Ban. It is the Listener bond that the Ban permits. The Free North has never signed a Listener bond; Brenna's predecessors refused, Brenna continues to refuse, and her silence is legible on the wax."*

**S5 — Herald identity.** File: `C-four-crown-intrigue.md` Endpoint 5 and Herald dossier. Action: canonise **Brenna's elder sister who does not officially exist**. This aligns with Brenna's "remembers, and cannot say" motive-carry. Rewrite Endpoint 5's candidate list as a single canonical sentence. Keep Jenn as Brenna's niece (courier, not Herald).

**S6 — Bram's letter-carrying youth.** File: `C-four-crown-intrigue.md` (C↔D cross) and/or `D-iron-dragon-returns.md` (Bram T004). Action: change "Bram carried letters between Brenna's grandmother and Darrik's grandfather" to "*Bram's father carried letters between the old chieftess and the old king*. If asked, Bram says only: *'My father rode in winter for them. He learned his letters from the same woman they learned theirs from. He did not speak of it.'*" Preserves C's intent, fixes the math.

**S7 — "Ashen" collision.** File: `A-guild-buried-charter.md` Factor surname. Action: rename *Selm Ashen-Howe* → *Selm Orren-Howe*. One-token find/replace in A.

### Minor

M1/M4/M5/M6/M7/M11 — each is a single-line edit as specified in the Minor-issues section above. None requires rewriting any scene.

---

End of checker report. All listed edits are surgical; the five lines are ship-ready after a single editor pass implementing B1–B3, S1–S7, and M1/M5/M6/M7/M11.
