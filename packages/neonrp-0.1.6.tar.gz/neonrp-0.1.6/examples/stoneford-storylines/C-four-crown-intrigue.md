# Storyline C: The Four-Crown Intrigue

## Function

Line C is the political-philosophical spine of the Grey Reach. Where Line A asks *who keeps the record*, Line B asks *what was forgotten*, and Lines D and E ask *what is returning*, Line C asks the question that sits underneath all of them: **whose crown has the right to decide**. Four kingdoms sit at the table — and the table has a fifth chair no one will name.

Each of the four royal souls carries a worldview, worn in their mouth, their cloth, their food, and the shape of their oaths. The Crown believes legitimacy is carried in blood. The Faith believes legitimacy is carried in oath and omen. The Free North believes legitimacy is carried in the consent of the clan. The Union believes legitimacy is carried in the ledger, by contract, by the weight a man's word has when it is written and witnessed. These are not abstractions. They are the way each royal holds a spoon, the way each one signs a letter, the way each one mourns a dead child.

Three of the four know a secret that would dissolve all four crowns. The fourth is a merchant who has been accidentally selling the proof in lots of twelve. A fifth soul — the Ashen Herald — walks the edge of the summit in a mask, and every time she speaks she denies every crown at the table. The line reaches its critical at a summit in Mistmere where the player may be forced to stand in one of these four chairs — or sit in the fifth.

The player is not meant to learn the colonial history through this line. The player is meant to *feel* it: as a weight under the floor of the throne room, as a silence between two kings who know, as a cup of tea one king drinks and another is refused, as an armour-pattern one chieftess wears and will not explain.

## Soul figure(s)

- **Crown — King-Apparent Darrik Voss** (first appearance via envoy at T001; in person at T004/T005). Ashcrown heir, mid-thirties, lean, clean-shaven in the southern fashion. Drinks an amber tea no one else is served. *Knows.*
- **Faith — High Septa Malen the Unsleeping** (first appearance via proclamation at T001; in person at T003/T005). Fifty, robes the colour of wet ash, eyes rimmed as though she has not slept in ten years — and has not. *Does not know.*
- **Free North — Chieftess Brenna Greyhold** (present only through her envoy **Ylva Stoneshield** in T002; in person at T005). Armour inlaid with a pale metal no smith in the Reach can hammer. Forty-two. *Remembers, and cannot say.*
- **Union — Consul-Merchant Tobiah Caul** (first appearance at T001 docks; through ledgers at T002/T004; in person at T005). Broad, red-cheeked, the friendliest man in the room. *Knows nothing.* His honesty is the most dangerous thing at the summit.
- **Sub-soul, Fog — The Ashen Herald** (T005, masked, no name). Arrives uninvited. Rejects all four crowns on principle and in person.

NEW NPC flags (needed in town files):
- **NEW NPC T001 · Jenn**, messenger, smallfolk, hunted in the port at the hook.
- **NEW NPC T002 · Ylva Stoneshield**, envoy of Chieftess Brenna — flag as cousin to Captain Yura Stoneshield (existing NPC_T002_01); Ylva carries Brenna's letters southward.
- **NEW NPC T004 · Envoy Alric of House Voss**, Darrik's southern mouth, carries the amber tea in a sealed tin; leaves unaging-tea dregs in his cup (fragment per SHARED_BRIEF).
- **NEW NPC T005 · King-Apparent Darrik Voss**, Crown soul.
- **NEW NPC T005 · High Septa Malen the Unsleeping**, Faith soul.
- **NEW NPC T005 · Chieftess Brenna Greyhold**, Free North soul.
- **NEW NPC T005 · Consul-Merchant Tobiah Caul**, Union soul.
- **NEW NPC T005 · The Ashen Herald**, masked, Fog sub-soul.

## Hook

**Tier 1, T001 Stoneford, the port at dusk.**

A messenger called Jenn is being run down the dock-planks by two men in plain grey wool. She is bleeding from the shoulder. She has a letter in her boot. If the player intervenes — whether with a blade, a shout, or a thrown rope — the two men will break off, because they are not assassins, they are hired beaters, and hired beaters do not die for their coin.

Jenn, once safe, will press the letter into the player's hand and say only: *"The four will sit. If the Fourth doesn't know what he is sitting on, they will eat him. Get this to anyone who isn't wearing a crown."*

The letter is sealed with a wax impression that no one in Stoneford recognises — a four-pointed knot around an empty centre. The seal is the sigil of the arbitration body that the Northern Guild was originally founded to serve. *(See A↔C dependency.)*

Inside, the letter is in a traders' shorthand — Tobiah Caul's own merchant-cipher, which Jenn stole off a Union clerk. Decoded at T002 (by Old Zhao for 50 gold, or by Tobiah's own clerks if the player sells him the letter), it reads:

> *To any honest house that still answers letters — The four crowns have agreed to sit at Mistmere at the next dark moon. They are sitting on an heir that none of the four has seen. Three of them mean to bind the Fourth before he knows what binding is. I write to no crown. I write to whoever reads this. — a hand.*

The letter is unsigned. The hand is the Ashen Herald's.

## Clues by town

### T001 · Stoneford — Sprout

| Carrier | Type | Content |
|---|---|---|
| Jenn (NEW) | scene | The dockside chase. Jenn bleeds onto a crate of salt-fish. The crate is Tobiah Caul's consignment — stamped *CAUL & SONS · HONEST WEIGHT*. |
| Jenn (NEW) | item | **The Herald's Letter.** Four-knot seal, empty centre. Traders' cipher. Decodable downstream. |
| Mira Ashford (existing NPC003) | line | When shown the seal, her hands still on the kettle. "The old arbitration mark. My grandmother had a plate with that on it. She used it for funerals only." |
| Old Reed (existing NPC002) | line | "Four-knot? That's from before the crowns settled. Before any of it settled. Put it away, friend. Put it in a pocket that isn't yours." |
| Heron Blackwater (existing NPC001) | line | Looks at the seal. Looks at the player. Takes a drink. "The Guild used to answer to that knot. Before the Guild answered to coin." *// public=trivia, feared=the Guild is older than the crowns and still has the cup it drank from, private=I have the minutes of the last arbitration in my cellar* |
| Dockhand (ambient, unnamed) | line | "Tobiah Caul's clerk came down asking about a missing courier. Paid a copper to anyone who'd seen a girl with a shoulder-wound. Didn't ask for her name." |
| Tobiah Caul (NEW, cameo) | scene | Tobiah himself is in Stoneford this week, inspecting a salt-fish consignment. He is broad, red-cheeked, laughs too loud at his own jokes. He wears a merchant's guild-chain with twelve clasps, one for each honest weight. He does not know why someone tried to kill his courier. He is genuinely upset. *// public=concern for employees, feared=someone has begun to notice what I don't know, private=nothing, he has no private; that is the problem* |
| Tobiah's clerk | item | A manifest. Among salt-fish and linen: *"Item 47 — twelve brass cups of antique foreign manufacture, sold to Consul-Merchant's private collection, three silver the lot."* These are relic-vessels. He bought them as antiques. |
| Dockside crate | fragment | **Crate stamp** bearing Tobiah's house-words: *"Honest Weight, Honest Word."* Line-C reveal fodder: the Union's oath style is contractual, mercantile, a thing you can weigh. |

**Sprout scene — The Seal That Doesn't Match**

> The wax is old-red, almost brown. The four-knot is cleanly pressed. The centre is empty.
>
> Mira Ashford sets the plate on the table between them. It is cracked across one side, glazed grey, a black knot painted at its centre — four loops, empty middle.
>
> "Funerals," she says. "Only funerals. My grandmother said the plate was for when there was nothing left to argue over."
>
> The player holds the letter-seal up next to the plate. Same knot. Same hole in the middle.
>
> Mira does not touch it.

### T002 · Windrest Keep — Involvement, stage one

Ylva Stoneshield, envoy of Chieftess Brenna Greyhold, arrives at Windrest in a column of six horse, under a truce-pennant of undyed wool. She is Captain Yura Stoneshield's cousin — same House, different branch, different country. Yura has not seen her in eleven years.

| Carrier | Type | Content |
|---|---|---|
| Ylva Stoneshield (NEW) | description | Tall, pale-haired, braided twice. Armour of dark leather, plates at the shoulder and collar inlaid with a thread of pale metal that catches no light. The pattern on the inlay is not a knot — it is a line, straight as a ruled edge, running collar to collar across her throat. |
| Ylva Stoneshield | line | When offered wine: "I drink after my chieftess, not before her." *// public=northern courtesy, feared=to drink first is to claim first, and the Free North does not claim, private=Brenna told me never to take a cup from a crown-hand* |
| Ylva Stoneshield | line | To Yura, privately, in the stable: "She is riding south herself. Brenna. To Mistmere. She will not send a proxy for this." Yura: "Why?" Ylva: "Because she said, and I quote, *'if we send a proxy they will sign it in our name.'*" *// public=chieftess attends in person, feared=the other three will commit the Free North to a cover-up if a voice is absent, private=Brenna knows the summit is about the thing we came from, and she will not sit through that with a proxy's mouth* |
| Ylva Stoneshield | item | **Brenna's sealed reply** to the Herald's letter. Seal: a single pale line across bare wax. Undeliverable by any but Ylva. If the player is trusted (social DC 17, or the player showed her the Herald's letter unasked), Ylva will speak one line aloud in the clan-tongue, translating afterwards: *"Vi kam fra den andre sida."* — *"We came from the other side."* She says it once. She says it is a child's rhyme her grandmother used to sing. She will not say it a second time. *// public=a lullaby, feared=the clans do not know this and must never, private=Brenna carries the oldest memory of any Northern soul, and carries it alone* |
| Old Zhao (existing NPC_T002_02) | service | Will decrypt the Herald's letter for 50 gold. Reads it aloud. Whistles. "Not my business. Not my business. But whoever wrote this is either the bravest fool in the north or a dead woman walking." |
| Old Zhao | line | "The four-knot? Old Guild. Before your grandfather's grandfather. They used to settle which crown owned which river. Then they stopped. Then the Guild started taking paid work. Same people. Different coin." *(A↔C: Guild was the arbitration body, became the cover-up organ.)* |
| Captain Yura Stoneshield (existing NPC_T002_01) | line | Looks at Ylva's inlaid armour. Says nothing for a long moment. "That metal. My father said the chieftess-line never sells it. Said it's the only thing they'll take a blood-price for, not coin." *(D cross: unbreakable metal fragment echo; see Durm's lump in T002 per SHARED_BRIEF.)* |
| Mei (existing NPC_T002_03) | rumour | "There's a rider come from the far north. Her horse didn't need water when they got here. The stablemaster said it was a clean horse — no foam, no sweat. Three days' ride. How?" *(Ylva uses distant-voice stones along the road; the horse was rested via staged swaps along the clan-routes, but Mei has no frame for this.)* |
| Brown (existing NPC_T002_04) | line | "She — the envoy — she looked at my guild-chain and said *'contract-folk.'* Like it was a bird-name. Not mean. Just — naming a species." *(Free North voice on the Union.)* |

**Involvement scene — Two Stoneshields in the Stable**

> The stable smells of old hay and horse-sweat. Yura stands with her back to the door. Ylva has taken off her helm. Their hair is the same colour but cut eleven years apart.
>
> "You still wear the Keep's badge," Ylva says.
>
> "You still wear ours," Yura says, pointing at the pale line on Ylva's collar.
>
> Ylva touches it. The metal is warm under her glove. "We wear what we wear because we remember what we remember."
>
> "That's a saying."
>
> "It's a *clan* saying. It's meant to be a saying." Ylva does not look at her cousin. "Cousin. If you are asked, in the next six weeks, to stand for the Free North in any room south of the Brokenspine — do not stand."
>
> "Why?"
>
> "Because the room wants a proxy. The room wants someone to sign our name for us." Ylva puts her helm back on. "Brenna will sign her own name or no name. Tell no one I said so."

### T003 · Wolfsjaw Pass / Mistmere Approaches — Involvement, stage two

High Septa Malen the Unsleeping is in residence at the Grand Cathedral at Mistmere, but her outriders and preachers are everywhere by this point. The player will encounter her in person only if they travel ahead to Mistmere in advance of the summit; otherwise she appears here through her proclamations, through Septon Silas's shaking hands, through Sara's bitter silence.

| Carrier | Type | Content |
|---|---|---|
| Half-burned *Northern Ban* decree (fragment per SHARED_BRIEF, Archivist Naryn's cabinet) | item | A proclamation in the Septa's hand. The upper half reads: *"By oath and by omen, let no house north of the Brokenspine speak the old colonists' name…"* The lower half is burned. Above the burn: *"…for the silence of one hundred years is a door that has not been closed from our side."* *(A↔C cross: the ban was co-signed by all four original arbitration seats. C↔E cross: the same ban names Depth-Walkers as a royal-suppression target.)* |
| Septon Silas (existing NPC_T004_07, but referenced here through a letter he posted to the cathedral) | item | A returned letter, stamped *REFUSED · BY THE UNSLEEPING*. Silas had written to the Septa asking about the wall-glyphs 上下相通 (Line B). Her refusal is three lines: *"Child. You were sent to watch a mine. Watch the mine. The Faith has no mouth for questions it did not ask."* *// public=pastoral rebuke, feared=Silas has seen glyphs the Faith cannot afford to acknowledge, private=the Septa herself does not know what the glyphs mean and cannot afford to show that she does not know* |
| Sara (existing NPC_T003_02) | line | "The Septa hasn't slept in ten years. They say it's penitence. It isn't. Something in her chambers keeps her awake and she doesn't know what it is. I treated one of her handmaidens last winter. The girl said the Septa holds a stone to her ear at night and whispers into it. Begs it to be quiet. The stone does not obey." *(This is a distant-voice stone. Malen does not know what it is. Per SHARED_BRIEF royal motive 6.)* |
| Lord Commander Linden Ironfist (existing NPC_T003_01) | line | When pressed on the upcoming summit: Linden says nothing for a long time. Then: "I have been told, by a woman whose name I will not say, that the summit is not about the orcs and not about the Khanate. I have been told it is about a door." *(Brenna has written to him. They are Free North-aligned.)* *// public=frontier commander's deflection, feared=if Linden knows about the door, the Khanate negotiation is about who holds it when it opens, private=he has seen Brenna's metal and he has his suspicions* |
| Linden | line | "The Septa sent riders to arrest any pilgrim who has been below ground. Below. Not beyond. Think on that." *(C↔E cross: royal suppression of Depth-Walkers.)* |
| Mark (existing NPC_T003_03) | rumour | "Faith man rode through two weeks ago. Not a septon — higher. Wore the Septa's collar. He was asking if anyone had heard *voices in stones.* Not demons. Not ghosts. *Voices.* Like the stone was a messenger." |
| Monastery back wall (fragment per SHARED_BRIEF) | glyph | 上下相通 — carved, ancient. Referenced here because Malen's riders have been ordered to scrub it, and the monks have been polishing it to preserve it. The scrubbing order came sealed with the Septa's four-knot — the *same* four-knot as the Herald's letter. *(A↔C: Faith still uses the arbitration seal for internal business. The Septa does not know why her seal is the same as the Herald's; she was simply taught to use it.)* |

**Involvement scene — The Refused Letter**

> Silas's hands are worse today. The cup shakes on its way to his mouth. He sets it down.
>
> "I wrote to her," he says. "To the Unsleeping. I asked what the glyphs meant. Above and below connect. I asked her — because she is the voice of the Faith, and the Faith keeps the old records."
>
> He slides the returned letter across the table. The player reads it.
>
> "She doesn't know," Silas says, after a while. "She refused me because she does not know. If she knew, she would have answered me, even if she had to lie. A lie takes knowledge. This is not a lie. This is a woman refusing to look at a door."
>
> He drinks. The mercury is in his cup. He knows this. He drinks anyway.

### T004 · Jadehollow — Involvement, stage three

King-Apparent Darrik Voss's envoy **Alric** has arrived in Jadehollow under the pretext of auditing Deepvein's royal licences. In truth he is here to do two things: to drink a particular tea in a particular tavern, and to find out whether Tobiah Caul's merchants have been buying what they should not have been buying.

| Carrier | Type | Content |
|---|---|---|
| Envoy Alric (NEW) | description | Thirty, southern-dressed — doublet of dark green, silver piping at the cuffs, boots polished to mirror. Speaks in the Ashcrown court-cadence: slow, over-enunciated, every consonant weighed. Clean-shaven. Carries a sealed tin of tea and a silver strainer. |
| Envoy Alric | line | To Kassa Deepvein: "His Grace the King-Apparent extends his compliments to House Deepvein, and reminds the House that the Crown's licences are renewable at the Crown's discretion, and the Crown's discretion is a narrow gate." *// public=routine audit, feared=Deepvein's fourth level has been selling relics to Tobiah's merchants, and the Crown needs to know whether Tobiah has realised what he was buying, private=Darrik himself sent me to count the cups* |
| Envoy Alric | scene | Takes his tea alone every evening at the Jade Lantern. A tin of amber leaf, unrolled like a scroll. Steeped exactly four minutes. He drinks from a brass cup he brought with him. He does not offer. Jade (existing NPC_T004_04) notes aloud that she has never seen an envoy refuse the house wine. |
| Envoy Alric's cup (fragment per SHARED_BRIEF — *unaging-tea dregs*) | item | If the player sneaks or bribes Jade for the leavings, the dregs are amber, faintly sweet, faintly metallic. Grandmother Green (existing NPC_T004_05) will, on sight of them, go very quiet. She will say: *"That is not a tea that was grown. That is a tea that was made. By hands that are not ours."* *// public=herbalist's caution, feared=she has seen this colour once, in a leaf a Depth-Walker showed her thirty years ago, private=she knows the tea prolongs life, because her own mother drank it once as a girl and lived to a hundred and nine* |
| Envoy Alric | line | To Old Fane Crowseye (existing NPC_T004_03), when Fane stares at the tin: "Appraiser. Eyes on your own stones." Fane: "My eye does not choose what it sees, Envoy. Complain to the eye." *// public=courtly rebuke, feared=Fane's pale eye reads the tin as older than the Ashcrown, private=Alric was warned that the appraiser in this town has a colonial-touched eye and should be quietly noted* |
| Crosser sketch *from below, we may rise* (fragment per SHARED_BRIEF, Library deep archive) | item | In Jadehollow's library, filed under *mining — antique diagrams*. The sketch shows a tunnel rising toward an opening; above the opening, the straight-line cloud. The handwriting is Navigator Kestrel's (Line E). *(C↔E cross: Darrik's people have been trying for years to locate the Crossers' sketch. Alric is here partly to find out if Deepvein has a copy.)* |
| Hawke (existing NPC_T004_08) | line | "The envoy's not here for licences. He's here because Tobiah Caul's clerks have been stopping at our loading docks. Caul bought a box of *cups* last season. Brass cups. From Deepvein's fourth level. Twelve of them. Paid three silver the lot. He thought they were antiques." *(Confirms Tobiah's ignorant-relic-buying per SHARED_BRIEF.)* |
| Kassa Deepvein (existing NPC_T004_01) | line | Quietly, to Alric, after hours: "If His Grace wishes an inventory of what has moved out of the fourth level, it can be assembled. It will take a week. It will be accurate." Alric: "Make it three days. Make it accurate." *// public=audit compliance, feared=Deepvein has been paid enough to know what the cups were, but has not been paid enough to hand the ledger over, private=Kassa signed the Consortium confidentiality in good faith; she is willing to break it for the Crown because the Crown is louder than the Consortium* |

**Involvement scene — The Tea at the Jade Lantern**

> Alric sits alone. The tin is open on the table. The tea-leaves are amber, narrow, rolled.
>
> Jade watches from behind the bar. She has seen a thousand men drink at her tables. She has not seen this kind of drinking.
>
> Alric steeps. Four minutes exactly. He counts under his breath. He does not look at the door.
>
> The player may approach. Alric will allow a seat. He will not offer the tea.
>
> "You wish to speak, traveller."
>
> "About the summit."
>
> Alric does not react. He lifts the cup. He sips. He sets it down. "The summit is a crown matter. Crown matters are for crowns."
>
> "The letter I carry says three crowns mean to bind the fourth."
>
> Alric's cup stops halfway to his mouth. He sets it down, very carefully, on the exact ring of its previous placement.
>
> "Show me the seal."
>
> The player shows him the four-knot.
>
> Alric looks at it for a long time. His face does not change. Then he says, in a voice that is neither courtly nor southern: "The Herald is writing letters again. His Grace will want to know." *// public=envoy noting a development, feared=the Herald knows what the crowns know, which means the Herald has been inside a room no commoner enters, private=Darrik has been looking for the Herald for three years*

### T005 · Mistmere — Critical

The dark moon. The four crowns sit.

The summit is held not in the Governor's hall but in an ancient chamber beneath the Grand Cathedral — a room with four doors, four chairs, and a fifth, bricked-up door in the north wall. The bricked-up door bears the four-knot seal in fired clay. No one will explain it. No one in the room knows who bricked it, or when.

| Carrier | Type | Content |
|---|---|---|
| The summit chamber | scene | Four chairs. One table. Four place-settings: a cup of amber tea (Crown), a cup of untouched water with a grey stone at the bottom (Faith), a bone cup of clan-ale (Free North), a brass cup — *one of Tobiah's twelve* — of ordinary southern wine (Union). The Union's cup is the relic. Tobiah does not know. |
| Darrik Voss (NEW, soul) | description | Mid-thirties, lean. Hair dark, cut close in the southern fashion. A ring on his left thumb — four-knot, centre-empty. He drinks the amber tea throughout the meeting. He does not eat. His voice is low, unhurried, and every sentence lands. |
| Darrik Voss | line (opening) | "We sit because we have always sat. We sit because the table was set before our grandfathers, and before their grandfathers, and before. We sit to settle what cannot be settled outside this room." *// public=ceremonial opening, feared=if anyone at this table speaks the colonists' name aloud, the table breaks and four kingdoms become four provinces of a place we no longer know, private=I drink this tea because my father drank it, and because my father's father said the tea is the only reason any of us are still sitting* |
| Darrik Voss | line | To Tobiah: "Consul-Merchant. The Crown has long considered the Union a valued and — honest — partner. There are matters at this table that touch on the Union's honest trade. We would see the Union bound, as we are bound, to the sitting of this table." *// public=invitation to full partnership, feared=Tobiah has been buying relics without knowing what they are, and every cup in his warehouse is a weapon that could be placed in the wrong hand, private=bind him into the secret so he stops selling what he does not understand* |
| Darrik Voss | line | To Brenna, colder: "Chieftess. The Free North has been, in recent years — quiet. We ask whether that quiet is a settled quiet or a waiting quiet." *// public=diplomatic probe, feared=Brenna has been reading old things, and Brenna is the only one at this table who might have told her clans what we all agreed never to tell, private=I know she has not told them; I know she will not tell them; I need her to tell me, across this table, that she still will not* |
| High Septa Malen the Unsleeping (NEW, soul) | description | Fifty. Robes the colour of wet ash. Her eyes are rimmed in a colour that is not quite bruise and not quite ink. She holds a grey stone in her right hand throughout the meeting. Sometimes she presses it to her ear. No one asks. |
| Malen | line (on the oath) | "Let this sitting be sealed by the Oath of the Four-Knot, as the Faith has sealed every sitting before it. Let the words spoken here be the words the Pattern permits. Let the silence after them be the Pattern's silence." *// public=ceremonial sealing, feared=the silence of a hundred years has not been broken; the Pattern has not answered; she believes the gods have withdrawn, and she is holding this summit together with her own unravelling, private=the stone in her hand whispered last night, in a woman's voice, a word she did not understand, and she has brought the stone to this room because she is terrified to leave it behind* |
| Malen | line | To Darrik, in a lull: "Your Grace drinks a tea that the Faith did not bless." Darrik: "The Crown drinks what the Crown has always drunk, Holiness." Malen: "And the Faith notes what the Faith has always noted." *// public=ritual reminder of Faith's oversight, feared=she has no idea what that tea is; she only knows her mother's ledger recorded it as uninspected, private=she would give her remaining sleepless years to know what the tea does, and she is too proud to ask* |
| Malen | line | To Tobiah, with unexpected warmth: "Consul. The Faith has always found your house — honest. Honest in its weights. Honest in its word. The Faith would welcome an oath from the Union before this table ends." *// public=welcome to the binding, feared=she is being used by Darrik to bind the merchant and she senses it and cannot name it, private=she likes Tobiah; he is the only man at this table who does not frighten her; she would protect him from the others if she knew how* |
| Chieftess Brenna Greyhold (NEW, soul) | description | Forty-two. Tall, broad-shouldered, plaited hair bone-white at the temples. Armour of dark leather and pale inlaid metal — the inlay running in straight lines across collar, shoulder, vambrace. No heraldic device. Her oath is sworn on her own forearm, scored with a clan-knife, not on any written document. |
| Brenna | line (in answer to Darrik's probe) | "The Free North sits where the Free North has sat. We have told our clans what our clans need to know. We have not told them what our clans would not ask. If the Crown wishes the Free North to speak more, the Crown may ride north in summer and ask at the hearth, as hearth-folk ask." *// public=clan-courtesy deflection, feared=Darrik is asking whether I have told them we came from the other side, and he is asking because he cannot afford me telling them, private=I have not told. I will not tell. But I will not be bound to a room that decides for them either* |
| Brenna | line | To Tobiah, unprompted, turning fully to face him: "Consul-Merchant. You have brass cups in your warehouses. Twelve, I am told. They are not brass. If you value your house, you will melt them down before the next dark moon. Do not ask me how I know. Do not answer me in this room. Nod if you have understood." *// public=bizarre warning, feared=she has just broken summit protocol to warn the one man none of us was supposed to warn, private=I cannot let this table eat him; my chieftess-mother told me never to let the Crown bind a man who does not know what he is being bound to; the cups are relics and he has been carrying them like cooking-ware* |
| Consul-Merchant Tobiah Caul (NEW, soul) | description | Broad, red-cheeked, fifties. A merchant-chain of twelve clasps. He is the only person in the room wearing a guild-badge instead of a crown-mark. He does not drink the wine — he noticed it was served in a brass cup he recognises from his own warehouse, and he is, under his cheer, genuinely confused. |
| Tobiah | line (opening, when allowed to speak) | "Your Graces. Your Holiness. Chieftess. The Union is — honoured. Honoured and — I will confess — puzzled. My honest trade has no business at a crowns' table. If the crowns wish the Union's oath, they may have it: *Honest Weight, Honest Word.* That is our oath. It is the only one we keep, and we keep it well." *// public=merchant humility, feared=I do not know why I am here, and I have learned in forty years of trade that when you do not know why you are at a table, someone else has already decided what you will pay, private=I am frightened, and I am pretending I am not* |
| Tobiah | line | After Brenna's cup-warning, looking at his own brass cup, slowly: "Chieftess. The cup. The cup in my hand. I bought twelve of these, last autumn. From a Jadehollow vendor. Three silver the lot. I thought — I thought they were antiques." *// public=confused admission, feared=three of the four people at this table have just gone very still, and he has noticed, private=he is looking at Darrik, because Darrik is the only one whose stillness is not surprise; Darrik's stillness is recognition* |
| Tobiah | line | Quietly, to no one in particular: "Your Graces. Whatever this cup is — I would like to be told. I would like to be told honestly. My house's word is good. My house can keep a secret. But my house will not keep a secret my house does not know it is keeping." *// public=request for full partnership, feared=he has just asked the one question three of the four crowns have agreed he must not ask, private=this is Tobiah at his best and his most dangerous; he is asking to be told the truth, and he is asking for it in good faith, and the room cannot give it to him* |
| Darrik Voss | line (answering Tobiah) | "Consul-Merchant. The cup is old. Older than this table. Older than the kingdoms. The Crown has long held that certain antiquities are — best kept at the Crown's table. We would offer the Union, in exchange for the twelve cups in its warehouses, the Crown's protection and the Crown's full partnership in matters that have, until this day, remained between three crowns." *// public=royal offer of elevation, feared=I must get the cups back, I must bind him tonight, or by next winter half the Ashcrown will know what we are, private=he is too honest; he will ask questions; but the alternative is that a merchant with twelve relic-cups in his warehouse is the most dangerous commoner in the kingdom* |
| Brenna | line (breaking protocol again) | "Consul. You need not answer His Grace tonight. You may answer him in a year. You may answer him never. The Free North will accept your silence as your answer, and will ride home." *// public=clan-style patience, feared=she is giving Tobiah the out Darrik will not give him, and Darrik knows it, private=if Tobiah takes the binding tonight, the four crowns become one secret and the Free North is the only clan-voice inside it; if Tobiah refuses, the four crowns stay four* |
| Malen | line | A long silence. Then, not looking at anyone: "The Faith would — accept the Consul's oath, whatever its shape, and would hold the oath-keeper's silence sacred. As the Faith holds all oath-keepers' silences sacred." *// public=Faith's blessing on any oath freely given, feared=she is terrified, and she has realised that if she says anything definite she will say the wrong thing, private=she does not know what is in the cup and she does not want to know; she wants only to sleep* |

**Summit scene — The Four Cups**

> The chamber is under the Grand Cathedral, down a stairwell that is kept locked on every day of the year but this one. The stair is narrow. Each of the four crowns descends alone. The guards wait at the top.
>
> The chamber is round. The ceiling is low. Four doors open onto four landings, and a fifth door — bricked up, faced in pale clay — sits in the north wall with the four-knot pressed into its centre. The clay is older than the brickwork. No one knows who pressed it.
>
> The table is round. The four chairs are not identical. Darrik's is a high-backed chair of dark wood, carved with the Ashcrown's leaf. Malen's is a stool — the Faith refuses backs — with a cushion of undyed wool. Brenna's is a clan-bench, long enough for three, though she sits at its centre. Tobiah's is a merchant's chair, leather-seated, wheeled — a compromise brought down from the cathedral's library, because no one knew what chair to offer him.
>
> The cups are set. Amber tea. Water-with-stone. Clan-ale. Brass-cup wine.
>
> Darrik enters first. He sees his cup. He sits. He does not drink yet.
>
> Malen enters second. She sees her cup. She does not sit. She stands in her doorway for a full count of seven, naming the Pattern silently into the frame, and only then steps through. She sits. She does not drink at all.
>
> Brenna enters third. She is already carrying her own bone cup — she brought it with her, as Free North courtesy demands. She sits. She sets her bone cup next to the clan-ale cup the cathedral provided, and the cathedral's cup remains untouched for the rest of the meeting. Her message is legible to Darrik and Malen. It is not legible to Tobiah.
>
> Tobiah enters fourth. He is the only one smiling. He sees his cup. He says, aloud, *"A brass cup. Well, I like a brass cup."* He sits. He takes the wine. He raises it in a half-toast to no one in particular, and drinks.
>
> Darrik watches him drink from the brass cup. His expression does not change.
>
> Brenna watches him drink from the brass cup. Her right hand, under the table, has gone to the clan-knife at her belt.
>
> Malen watches him drink from the brass cup. Her grey stone is at her ear.
>
> The summit has begun.

**Summit scene — The Opening Round**

> Darrik speaks the opening. The ceremonial phrasing — *we sit because we have always sat* — is spoken without emphasis; he has said it at three previous four-crown sittings, and the words are worn smooth in his mouth.
>
> Malen answers. She speaks the sealing — *let this sitting be sealed by the Oath of the Four-Knot*. Her voice is thin. Darrik notices. He does not react.
>
> Brenna speaks the Free North's acknowledgement. It is the shortest acknowledgement in the history of the four-crown sittings. *"The Free North hears. The Free North listens. The Free North will speak when spoken to."* She stops there. Darrik and Malen both wait for more. None comes.
>
> Tobiah speaks last. He begins with *"Your Graces. Your Holiness. Chieftess."* and then stops, because he realises he does not know the ceremonial phrasing. He improvises. *"The Union is — honoured to be asked. We will do our honest best to deserve the asking."*
>
> It is, by Union standards, a small speech. By summit standards, it is a signature on a blank document. Darrik relaxes. Malen exhales. Brenna's hand does not leave her clan-knife.

**Summit scene — The Cup Revelation**

> It is Brenna who breaks the room.
>
> She has listened to Darrik's probe — *the Free North has been, in recent years — quiet* — and she has given her clan-courtesy reply. She has listened to Malen's invitation for Tobiah's oath. She has watched Darrik set the hook.
>
> Then she turns, fully, her whole body swinging on the clan-bench to face Tobiah, and she says — not loud, but not soft — *"Consul-Merchant. You have brass cups in your warehouses. Twelve, I am told. They are not brass. If you value your house, you will melt them down before the next dark moon. Do not ask me how I know. Do not answer me in this room. Nod if you have understood."*
>
> The chamber is silent.
>
> Darrik sets his tea down. The cup makes a small clean sound on the wood.
>
> Malen's stone drops from her ear into her lap.
>
> Tobiah looks at the brass cup in front of him. Then he looks at Brenna. Then he looks at Darrik. Darrik's face is perfectly still — not surprised, not angry, *still*, which is a thing a merchant reads.
>
> Tobiah does not nod. He does not shake his head. He asks the question instead.
>
> *"Chieftess. The cup. The cup in my hand. I bought twelve of these, last autumn. From a Jadehollow vendor. Three silver the lot. I thought — I thought they were antiques."*
>
> Brenna does not answer him. She has said her piece. She does not answer questions asked of her outside clan-protocol.
>
> Tobiah turns to Darrik. *"Your Grace. My house's word is good. My house can keep a secret. But my house will not keep a secret my house does not know it is keeping. What is in the cup?"*
>
> Darrik does not answer immediately. He picks up his amber tea. He drinks. He sets it down. He says, in the Crown's plural, *"The cup is old. Older than this table. Older than the kingdoms."*
>
> *"That is not an answer, Your Grace."*
>
> *"It is the answer the Crown is prepared to give."*
>
> Tobiah sits back in his wheeled chair. It squeaks. The squeak is absurd in the chamber, and two of the three other crowns flinch.
>
> *"Then the Crown is asking the Union to take an oath against the weight of a cup the Crown will not name,"* Tobiah says slowly, as though he is working it out in real time. *"That is not — your Grace. That is not an honest weight."*

**The Ashen Herald's entrance.**

At some point during the summit — after the cup-revelation, before any oath is given — the Ashen Herald arrives. She is not admitted; she is simply present. The guards at the four doors will later swear none of them opened. The bricked-up fifth door is unchanged.

| Carrier | Type | Content |
|---|---|---|
| The Ashen Herald (NEW, sub-soul) | description | Tall, wrapped in a long ash-grey cloak. Face covered by a mask of un-glazed clay, eyeholes empty. The mask bears no heraldry — or rather, the mask *is* the Herald's heraldry: the blank centre of the four-knot, personified. Voice is not quite a woman's, not quite a man's. She carries no weapon. She writes her words on a slate, and speaks aloud only at key moments. |
| Ashen Herald | line | Walks to the centre of the chamber. Looks at each of the four. Writes on the slate. Holds it up. *Three of you know. One of you does not. Your business is to keep it so. My business is to say otherwise.* |
| Ashen Herald | line (aloud, to Tobiah) | "Consul-Merchant. You have been asked to take an oath whose weight has not been shown to you. I, who answer to no crown, ask you to weigh it first. *Honest Weight, Honest Word.* Is it your oath, still?" *// public=rhetorical appeal, feared=she has walked into a sealed room and spoken the Union's own house-words back at the Union, which means she knows the Union better than the Union knows itself, private=the Herald is offering Tobiah the fifth option: refuse all four crowns, stand with her, stand with the Fog, stand with no one* |
| Ashen Herald | line (to Darrik) | "Your Grace drinks a tea that was not grown. You have drunk it since you were fifteen. Your father drank it. His father drank it. The Ashcrown is old, Your Grace, but the tea is older. I ask you — in front of this table — from whom did the first cup come?" *// public=provocation, feared=she is about to say the colonists' name; she is the only person in a hundred years who would, private=she will not say it; she will leave Darrik to say it, or not; that is her craft* |
| Darrik Voss | line (answering the Herald) | Silence. A long silence. Then: "The first cup came from our fathers, Herald. As all things come from our fathers." *// public=deflection, feared=she is right and he knows she is right, private=he just chose, in front of three crowns and a merchant, not to say the word; he has chosen the cover story over the truth, and the Herald heard him choose* |
| Ashen Herald | line | "So be it. The table has sat. The table has spoken. The table has not answered. I withdraw." |

**Critical decision — the fifth chair.**

The player, if they have followed Line C this far, will be present in the chamber — either as Jenn's surrogate courier, as Tobiah's advisor (Union path), as Alric's auditor-at-arms (Crown path), as Ylva's second (Free North path), as Silas's witness (Faith path, if Silas has survived Line A/B long enough), or as uninvited (Fog/Herald path).

At the moment the Herald withdraws, the player is offered, by the Herald's turning at the door, a choice. It is not spoken. It is offered by a look through an empty mask.

**Five branches:**

1. **Stand for the Crown.** Speak on Darrik's behalf to bind Tobiah tonight. Tobiah takes the oath under duress. The cups are surrendered. The four-crown cover-up holds for another generation. Darrik owes the player a debt. The player will, in later acts, be called upon to collect it — or to repay it.
2. **Stand for the Faith.** Speak for Malen, endorsing the oath-binding in the Pattern's name. Malen sleeps, for the first time in a decade, the night after the summit. The player becomes, unwittingly, the Septa's dream-bearer. (Line D hook: the straight-line cloud is seen over Mistmere the following dawn, and Malen hears a voice in her grey stone that she now cannot unhear.)
3. **Stand for the Free North.** Speak for Brenna. Tobiah is permitted to refuse. The summit ends without the binding. Three crowns ride home furious. Brenna rides home grim. Within a season, Tobiah's merchants begin asking questions the crowns cannot answer. (Sets up A and E critical beats.)
4. **Stand for the Union.** Speak as Tobiah's honest second. Demand to see the weight of the oath before it is sworn. Tobiah, backed, asks the question again: *what is in the cup?* No one answers. Tobiah withdraws his house from the table. The Union walks out of the four-crown frame. The crowns, for the first time in two hundred years, sit at three chairs. (The most destabilising option; Line A's Guild records begin to be reopened because the Union's withdrawal re-enables the arbitration body.)
5. **Stand for the Fog — the fifth option.** Take the Herald's offered silence. Leave with her through a door the guards will later swear did not open. The player no longer has a kingdom. The player has a mask waiting for them at T005's harbour. (Line D and E's critical beats both open to the player; Line A's Guild will hunt the player as a breach of the Northern Ban.)

## The four kingdoms, shown not told

This section is a reference sheet for town-writers. Every NPC in Lines A–E who references a kingdom must hold to these details. The kingdom's worldview must be carried in **voice, costume, food, and oath-style** — never in exposition.

### The Crown (Ashcrown)

**Value:** Legitimacy is carried in blood. The crown is a *body* that is passed from one body to the next. The word *heir* is sacred.

**Voice:** Southern court-cadence. Slow, over-enunciated, every consonant weighed. Uses the plural — *the Crown holds, the Crown drinks, the Crown has long considered* — rather than the first person singular. Disagreement is phrased as *the Crown's discretion is a narrow gate*. Never raises volume. A Crown-voice that must raise its volume has already lost.

**Costume:** Dark green or ashen grey wool in the field, deep blue velvet at court. Silver piping at cuffs. A ring worn on the left thumb, not the finger — the thumb-ring is the Crown's mark of station, and commoners who wear thumb-rings south of the Brokenspine are arrested. Hair cut close. Faces clean-shaven. Shoes mirror-polished.

**Food:** A Crown noble does not eat in front of commoners if they can avoid it. Private meals are small: game-bird, soft cheese, pickled roots, the amber tea. The tea is served from a brass or silver strainer — never ceramic. A Crown-guest offered a ceramic cup has been insulted, and the insult is legible only to other Crown-folk.

**Oath-style:** Oath is sworn on the body of the oath-taker. A Crown-oath touches the sternum with the flat of the right hand, and names the oath-taker's father and father's father. *"By my body, and by my father's body, and by his, I will hold this."* Oath-breaking is considered an assault on the ancestor-line. Crown-traitors are not only killed — their names are struck from the paternal register, and the register is read aloud at court once a year with the struck names paused-over in silence.

**At the summit:** Darrik wears his thumb-ring. He speaks in the plural. His tea is amber. His oath, if he takes one, will touch his sternum.

### The Faith (the Septon Order of the Pattern)

**Value:** Legitimacy is carried in oath and omen. The Pattern is the right-ordering of the world; the Septa's office is to read it and to speak it. A crown is legitimate because the Pattern tolerates it. When the Pattern withdraws — as the Faith fears it has, these past hundred years — legitimacy itself becomes provisional.

**Voice:** Slow, declarative, scripture-cadenced. Uses archaic conjugations — *let this sitting be sealed, let the words spoken here be the words the Pattern permits*. Malen specifically does not use contractions. She does not use the first person — she speaks as *the Faith*, or as *this servant*, or as *one who watches*. When she is frightened, she becomes *more* scripture-cadenced, not less.

**Costume:** Robes the colour of wet ash, cut to the ankle. A collar of undyed linen. A wooden prayer-bead at the wrist — nine beads for the nine seasons of the Pattern. A grey stone, un-polished, worn at the throat on a leather thong. Malen's stone is different — larger, smoother, and hers is a distant-voice stone, not a prayer-stone; she does not know this.

**Food:** Faith-folk eat only at the seven hours of the Pattern, and eat only grey foods — grey bread, grey porridge, river-fish. Colour is considered a distraction from the Pattern's reading. A Faith-guest offered coloured food may refuse politely, or may eat, and neither choice is taken amiss.

**Oath-style:** Oath is sworn by *Pattern-binding*. The oath-taker stands in a doorway — any doorway, any threshold — and names the oath into the frame. The Pattern is understood to *witness* the oath by the shape of the door. Oath-breaking is a breach of the world's geometry, and the oath-breaker is believed to be, quietly, unmade from within: they lose first their appetite, then their sleep, then their name. Malen has not slept in ten years. She does not know what oath she is being unmade by.

**At the summit:** Malen's grey stone is in her right hand. Every time she is about to speak, she presses it to her ear for a half-heartbeat. She does this without realising she is doing it.

### The Free North (the Greyhold clans)

**Value:** Legitimacy is carried in the consent of the clan. A chieftess is a *voice* of the clan, not a ruler of it. Authority that cannot be withdrawn by the clan-hearth is not authority — it is occupation. The Free North's kings do not rule; they *speak*.

**Voice:** Short sentences. Concrete nouns. Verbs before adjectives. *"We sit where we have sat. We speak what our hearths know. We do not speak what our clans do not ask."* A Free North-voice avoids abstractions and avoids the plural-of-majesty; they use *we* only when they mean an actual group of people, never as a royal form. Brenna, specifically, uses *I* only when she is prepared to be disobeyed.

**Costume:** Dark leather, fur at collar and cuff for winter, bare arms for summer. Plaited hair — the number of plaits marks clan-rank, not age. Pale metal inlay at shoulder, collar, and vambrace, in straight-line patterns that are *not* heraldry — Free North folk do not wear heraldry; they wear the patterns their clan-smiths learned from their clan-smith-mothers, and the patterns are named after rivers, mountains, and a few things whose names no one will explain. Brenna's inlay runs collar-to-collar, a straight line across her throat. No one in the Reach has asked her about it to her face.

**Food:** Communal. A Free North delegation eats out of one pot, and the chieftess eats last — not first. Clan-ale is drunk from bone cups, one cup per person, and the cup is carried by the drinker, not the host. To drink from a host's cup is to accept the host's authority, which a Free North chieftess will not do. Ylva's *"I drink after my chieftess, not before her"* is the surface layer; the deeper layer is *I do not drink from your cup because I do not acknowledge your house.*

**Oath-style:** Oath is sworn on the forearm, scored with a clan-knife, and the scoring is shown — the scar is the oath. An oath-keeper's arm is a record; a chieftess's arm is a small history of the clan. Brenna's arm, under her vambrace, is scored thirty-one times. Oath-breaking is resolved by the clan, not by the chieftess — the chieftess may call for a hearth-meeting, but she may not punish. The Free North does not have prisons.

**At the summit:** Brenna sits with her vambrace on, but her right sleeve pushed back to the elbow. Her arm is visible. The other three crowns understand. Tobiah does not.

### The Union (Caul & Sons, the Honest-Weight Guild)

**Value:** Legitimacy is carried in the ledger. A contract is a thing you can weigh; a word is a thing you can write; an oath is a thing you can witness and sign. The Union believes — sincerely, and without irony — that the crowns' business would be better conducted if the crowns kept proper books.

**Voice:** Plain northern merchant-speech. Uses contractions. Uses the first person freely. *"I would like to be told. I would like to be told honestly."* A Union-voice explains itself; it does not imply. It uses numbers, weights, and prices where other voices would use gestures. Tobiah, specifically, is a man who cannot tell a joke without explaining why it is funny, and who is loved by his clerks for this.

**Costume:** Merchant's doublet in muted colours — russet, ochre, slate — cut generously. A merchant-chain at the neck, one clasp per honest weight the merchant has pledged. Tobiah wears twelve clasps, which is a great deal; most Union-folk wear three or four. Boots good, not polished. Hair short but not southern-short. Beard trimmed.

**Food:** Union-folk eat and drink in company, and keep the accounts of what was eaten and drunk. A Union-host will, at the end of a meal, tally the cost of the food in front of the guest — not to charge the guest, but to *show* them what hospitality weighs. It is considered the highest form of honesty. Faith-folk find this disturbing. Crown-folk find it vulgar. Free North-folk find it baffling. Union-folk find it the only sane way to eat.

**Oath-style:** Oath is written, signed, witnessed, and filed. The oath-taker does not touch their body or any threshold; they sign a document, and the document is the oath. Copies are made. Copies are kept in separate buildings, in case of fire. Oath-breaking is pursued through the Union's arbitration — which is a ledger-court, not a combat-court — and the punishment is the *erasure of the oath-breaker's clasp*, a ritual in which the merchant-chain is cut at the broken clasp and the clasp is thrown into the Shale. An oath-breaker without clasps cannot trade in the Union's markets.

**At the summit:** Tobiah has a wax tablet in his sleeve. He is prepared, without realising it is improper, to take notes.

## The colonial shadow

A reference page for the writer-team. None of this is to be shown in any player-facing text.

The four crowns are descended from a single colonial administrator's lineage, split four ways in the third generation after contact ended. The first generation — the colonists themselves — kept a standing arbitration council called the Four-Knot. When the silence fell a hundred years ago, the council became a treaty-body between the four successor polities; two generations after that, it became the cover-up organ that the Guild is today (A↔C). The bricked-up fifth door in the summit chamber is the door that used to open onto the colonists' own archive. No one in the Reach alive today knows what is behind it. Three of the four crowns have inherited, from their predecessors on the day of accession, the instruction *do not open the fifth door.* None have been told why.

Darrik knows this instruction and has obeyed it. Brenna knows the instruction and has obeyed it, though she has, twice in her reign, stood in front of the door with her ear to the clay. Malen was never told the instruction — the Faith's office passes its secrets by written register, and the relevant page of the Septa's register was lost in a fire in her predecessor's time. Tobiah has never seen the fifth door, because the Union has never sat at the summit before. The Ashen Herald has been through the fifth door. This is how she comes and goes.

The amber tea: grown in hydroponic planters on the far side, brought across in the last supply-caravans before silence. The Ashcrown's stockpile has lasted four generations because the tea, brewed correctly, extends the life of the drinker and also — a detail Darrik has not been told — extends the *fertility* of the drinker's line. The Voss line has been thin for four generations for a reason. Darrik is the last male Voss. He does not know why his uncles were sterile.

The pale inlay metal: a structural alloy from the far-side high-towers. The Greyhold clan-smiths learned, two generations ago, that the metal could not be worked but could be inlaid cold. The pattern-discipline (straight lines, never knots) was not aesthetic — it was the pattern the first clan-smith-mother learned from the woman who taught her, who was a colonial engineer, who taught straight lines because straight lines were how the alloy wanted to be laid.

The distant-voice stones: paired communication devices. Malen's stone is paired with a stone that sits, to this day, in a sealed chamber on the far side. The voice she hears is not divine abandonment. It is a woman, across the Chasm, who has been trying for ninety-seven years to reach someone. The woman is still alive. The tea kept her alive. Malen does not know any of this. The woman does.

The brass cups Tobiah bought: drinking-vessels from an officers' mess in the colonial administration. Twelve of them. Tobiah has nine still in his Stoneford warehouse; three are in Mistmere, one of them now on the summit table in front of him.

The four-knot seal: the colonial council's mark. The empty centre is where the fifth sigil — the colonial authority itself — used to be pressed. When contact ended, the successor polities continued to use the seal, with the centre left blank. The blank centre is, in a literal and forgotten sense, the shape of the thing the four crowns are sitting on.

**Summit scene — The Withdrawal**

> The Herald writes a final line on the slate. She turns the slate around. The line reads:
>
> *Three of you know. The fourth has just learned that he does not. I have done what I came to do.*
>
> She walks to the north wall. She stops at the bricked-up door. She places her palm flat on the four-knot clay. The clay does not open. It does not move. But the Herald's hand goes *through* the clay up to the wrist, and then to the elbow, and then she steps forward and the rest of her follows.
>
> The four crowns watch her go. Malen's stone whispers something. Brenna's knife comes out of her belt and rests, bare, on the table in front of her. Darrik's face, for the first time in the meeting, changes: a small sharp inhalation, a tightening at the jaw. Tobiah has gone quite pale.
>
> The chamber is silent again.
>
> Darrik speaks first. *"The sitting is ended. The crowns will retire."*
>
> Malen does not answer. She is staring at the bricked-up door.
>
> Brenna sheathes her knife. She stands. She says, to no one, *"The Free North rides at first light."*
>
> Tobiah is still holding the brass cup. He sets it down, very carefully, on the table. He looks at the three crowns. He says, quietly, *"I will think on my house's oath overnight, Your Graces. Your Holiness. Chieftess. I will bring my answer at dawn."*
>
> Darrik nods, once. The nod is not agreement. It is acknowledgement.
>
> The four crowns leave by their four doors. The player, if present, is left in the chamber with the four cups, the bricked-up door, and the slate-chalk dust on the floor where the Herald stood.

## Stage endpoints

- **Sprout end (T001):** The player holds the Herald's letter. They know a summit is coming. They know three of four crowns are hiding something, and the fourth is being led to a table he does not understand. They do not yet know what is being hidden.
- **Involvement end (T002–T004):** The player has met Ylva (Free North voice), read the Septa's refusals (Faith voice), tasted Alric's tea (Crown voice), and counted Tobiah's twelve cups (Union voice). They have heard Brenna's one whispered line — *we came from the other side* — and may or may not have understood it. They know the Guild's four-knot is older than the crowns. They know the Septa's seal and the Herald's seal are the same seal.
- **Critical decision at T005:** Which of the five chairs the player takes at the summit. The decision is irreversible in this playthrough. It determines which line's critical (A/B/D/E) becomes easier or harder to reach from here on.

## Endpoints in detail

### Endpoint 1 — Crown path

The player speaks for Darrik. The speech is delivered at dawn, in the cathedral forecourt, with Tobiah standing on the steps between the four crowns. The player may argue, in the Crown's cadence, that the Union's honest word is best tested by what it is asked to keep rather than by what it is told. If the speech lands (social DC 18, or DC 15 if the player has earned Alric's regard at T004), Tobiah takes the oath. He signs a Crown-issued document. He surrenders the twelve cups. He is given, in exchange, a thumb-ring — the first Union thumb-ring in the history of the Ashcrown.

The cups are taken south in a Crown-sealed chest. Darrik will, three months later, ride to T001 and personally visit the player wherever they are. He will bring, as thanks, a tin of the amber tea, sealed. He will say: *"You have stood for the Crown. The Crown remembers who stands for it. The Crown also remembers who stands only once."* The tin is a debt and a warning.

Downstream consequences: Line A's buried charter becomes harder to reach (the Crown tightens Guild oversight). Line B's Eilin is moved to a closer observation (the Crown now has a formal reason to monitor the monasteries). Line D's straight-line cloud is seen twice in the next month, and the Crown's response — which is to arrest witnesses — becomes a cross-line friction. Line E's Crossers accelerate: they have calculated, correctly, that the Crown's grip is tightening, and that the window to cross is narrowing.

### Endpoint 2 — Faith path

The player speaks for Malen. The speech is delivered in the cathedral itself, at the seventh hour of the Pattern, in front of the altar-stone that bears no carving. The player must argue in Faith-cadence — scripture-rhythm, archaic conjugations, no contractions — that the Pattern's silence has not been an abandonment but a testing. If the speech lands (DC 19, or DC 16 if the player has recovered Silas's testament from T004 and presented a single passage of it to Malen as a sign), Malen weeps. It is the first time she has wept in nine years.

That night, Malen sleeps. Six hours, dreamless, the deepest sleep of her life.

The following dawn, the straight-line cloud appears over Mistmere. Malen wakes, hears it before she sees it — the grey stone at her throat has begun speaking in a woman's voice, clearly, a word at a time, a question. Malen does not understand the language. She will not sleep again for the rest of her life.

Downstream consequences: Line D opens directly from this beat (the cloud, the stone, the voice). Line B's Eilin becomes reachable through the Faith — Malen, destabilised, begins asking the questions her predecessors refused to ask, and the monasteries are ordered to *unbrick* certain archives. Line A's buried charter becomes easier to reach, because the Faith's oversight of the Guild slackens. The player becomes, in Malen's private ledger, a *named servant of the Pattern* — a designation that has not been given out in sixty years, and that carries obligations the player is not told about in advance.

### Endpoint 3 — Free North path

The player speaks for Brenna. The speech is not delivered publicly — Free North custom does not permit it. Instead, the player stands behind Brenna's right shoulder at the dawn assembly, and Brenna speaks, and the player's presence is the statement.

Brenna's speech is one sentence. *"The Free North will not ask the Consul-Merchant to take an oath the Free North itself has not sworn."*

The three other crowns understand. Tobiah is permitted to refuse. The summit ends without the binding. The three crowns ride home furious; Brenna rides home grim.

Within a season, Tobiah's merchants — unbound, unmuzzled, and now actively curious — begin asking questions about the brass cups. Within two seasons, a Union clerk in Stoneford has connected the cups to a crate-manifest from the far-side caravans. Within a year, the Union has a working hypothesis. It is wrong in two particulars and correct in the third, which is the particular that matters: *these cups were not made here.*

Downstream consequences: Line A's Guild is forced, by Union pressure, to open a limited access to its charter archive; the buried charter becomes reachable with Union sponsorship. Line E's Crossers find an unexpected ally in the Union — not because the Union agrees with them, but because the Union wants a fuller inventory of what is on both sides of the Chasm. Line D's Old Shepherd Bram becomes willing to testify to the Union, which he would not do to any crown. Brenna herself becomes a regular correspondent of the player's, by letter, one letter per season, written in a hand the player learns to recognise.

### Endpoint 4 — Union path

The player speaks as Tobiah's honest second. The speech is short, northern, concrete: *"My master's house will not take an oath whose weight has not been shown. My master's house will not sign a document whose terms have not been read. My master's house respectfully withdraws from this sitting."*

Tobiah walks out of the cathedral forecourt at his second's side. The three crowns are left standing.

This is the most destabilising of the five endpoints. The four-crown frame has not held three chairs in two hundred years. Without the Union's honest-witness function, the ceremonial sealings of the Oath of the Four-Knot cannot be closed. The Faith, specifically, cannot seal a sitting without all four cups being drunk from — and Tobiah's cup is now empty and abandoned on a table under the cathedral, un-sealed.

Downstream consequences: Line A's arbitration body re-activates, because the Union's withdrawal re-enables the pre-Guild function of the Four-Knot. Line B's Eilin becomes a *witness* the Union wants interviewed. Line D's cloud-sightings begin to be catalogued by Union clerks, which is the first systematic record any institution has kept of the phenomenon. Line E's Listeners lose a significant portion of their royal funding, because the Crown is preoccupied; the Crossers gain breathing room. The player becomes, in Tobiah's ledger, a *Union-bonded friend* — a rank with a clasp, the thirteenth on Tobiah's chain.

### Endpoint 5 — Fog path (the fifth chair)

The player does not speak. The player follows the Ashen Herald through the bricked-up north door. The guards at the cathedral will later swear no one passed them. The player will not be recorded as present at the dawn assembly. Tobiah will take whatever oath the three crowns press on him, because there is no fifth voice in the room.

The player emerges — a day later, a week later, a month later, the time is uncertain — at the Mistmere harbour, at dusk, with a mask of un-glazed clay in their hand. The mask fits. The mask is theirs. The Herald is gone.

Downstream consequences: the player is now outside all four kingdom frames. The Guild hunts them (Line A: breach of the Northern Ban). The Faith declares them unnamed-by-the-Pattern (Line B: accessible only by heresy). The Crown issues a quiet warrant (no public notice, but royal agents will recognise the player). The Free North will not hunt them, but will not shelter them. The Union will trade with them cautiously. The Crossers (Line E) will welcome them openly — because a masked, nameless, kingdomless agent is precisely what the Crossers have needed. Line D's Veyl "the Line" will, when encountered at T005, recognise the player as *kin* and say, quietly, *"So there are two of us now."*

This endpoint is the only one that opens direct dialogue with the Ashen Herald in subsequent scenes. The Herald, unmasked once in the player's presence, is canonically **Brenna's elder sister who does not officially exist** — a woman the Greyhold clans have had no record of for thirty years, whose name the chieftess does not speak. This aligns with Brenna's carry of colonial memory she may not share with her clans. Jenn remains Brenna's niece (courier, not Herald).

## Cross-line interactions

- **A ↔ C:** The four-knot is the Guild's original arbitration seal. The Herald writes letters in it; the Septa scrubs glyphs with it; the old plate in Mira Ashford's kitchen bears it. The Guild is both the cover-up organ (A's central fact) and the only institution whose seal still works at all four crowns' tables. Line A's critical — the buried charter — is the *founding document* of the four-knot body; reading it tells the player that the arbitration body was created *by the first generation of colonists* as a standing council, and the kingdoms inherited it.
- **C ↔ E:** Line C's Critical Endpoint 2 (Faith path) and Endpoint 3 (Free North path) both feed directly into Line E. Darrik and Brenna are the two crowns who have quietly co-signed the suppression of the Depth-Walkers, specifically the Crossers. Navigator Kestrel's sketch *from below, we may rise* (fragment, T004 library, per SHARED_BRIEF) is itself a diagram of how to reach the four-knot chamber *from below* — bypassing the four doors. Any player on Line E who reaches Sula or Kestrel will learn that the Crown and the Free North jointly pay the Listener contracts (Sula) to keep the Crossers in check.
- **C ↔ D:** The brass cups Tobiah bought are relics of the same far-side metallurgy as Durm's un-hammerable lump (T002 fragment). The straight-line cloud (T002 sky event) that triggers D is seen again over Mistmere on the morning after the summit, if the player chose Endpoint 2 (Faith); Malen's stone and the cloud are the same *family* of artefact. Old Shepherd Bram's father (D sub-soul's father) carried messages between the old chieftess and the old king in his youth; Bram, if asked, says exactly one thing: *"My father rode in winter for them. He learned his letters from the same woman they learned theirs from. He did not speak of it."*
- **C ↔ B:** Preceptor Vossel the Younger (B sub-soul at T002) maintains quiet correspondence with the monastery while traveling; Line C does not claim his bloodline. Eilin of the Broken Tongue (B soul) was muted not only for her map but because she drew the original four-knot in its *unbricked* form — five points, not four — on a monastery wall. The Septa's own riders scrubbed it, under the four-knot seal she does not understand.

## Four voices, side by side

A short reference for writers who must render an NPC speaking *about* another kingdom. The four voices should remain consistent when commenting on one another.

**The Crown on the Faith.** *"Her Holiness keeps the Pattern. The Pattern keeps her. The Crown does not intrude upon that arrangement."* (Respectful, distant, slightly patronising.)

**The Crown on the Free North.** *"The Chieftess is — direct. The Crown values directness, at its appropriate distance."* (Wary, slightly cold.)

**The Crown on the Union.** *"Honest weights. Honest words. A useful house, and the Crown is pleased by useful houses."* (Condescending, friendly.)

**The Faith on the Crown.** *"His Grace is a body, and the body walks within the Pattern. The Faith watches the body walk."* (Ritualised, patient.)

**The Faith on the Free North.** *"The clans do not sit within the Pattern. The Faith does not yet know whether the Pattern sits within the clans. The question is open."* (Uncertain, careful.)

**The Faith on the Union.** *"The Consul-Merchant keeps honest weights. Honest weights are a Pattern, after their fashion. The Faith recognises the Pattern where it finds it."* (Generous, surprising; Malen actually likes the Union.)

**The Free North on the Crown.** *"The southern king drinks from a cup that was poured for him. We pour our own."* (Flat, descriptive.)

**The Free North on the Faith.** *"The grey-robe talks to doorways. The doorways do not answer. The grey-robe keeps talking."* (Concrete, faintly contemptuous.)

**The Free North on the Union.** *"The weigh-folk. They weigh everything. They would weigh a child if you let them. They do not mean harm by it."* (Slightly amused, not hostile.)

**The Union on the Crown.** *"His Grace is — a valued customer. We would extend him a line of credit if he asked. He has not asked."* (Professional, slightly baffled by Crown etiquette.)

**The Union on the Faith.** *"The Faith keeps good records. We respect good records."* (Sincere, professional.)

**The Union on the Free North.** *"The Chieftess pays in silver and her word is good. Her ale is better than her silver."* (Warm, concrete.)

**The Ashen Herald on all four.** *"Four rooms with four doors, and one wall between them they have all agreed not to see."* (Written on her slate, shown to Tobiah at the summit.)

## A final image

A last picture, for the writers to carry.

The summit chamber is empty. The four cups are still on the table — amber tea cold in its brass strainer-cup, grey-stone water untouched, clan-ale in a cup the chieftess did not drink from, wine half-finished in a brass cup an honest man was given without being told what it was. The four doors are closed. The fifth door is bricked, and the four-knot clay on its face is, by the chamber's low lamplight, the only thing in the room with a shape that matters.

A line of chalk dust on the flagstones, where the Herald stood.

No one is there to see it.

## Gaps needing sibling input

Line C has three open joints where the adjacent lines' writers must lock in a shared detail before publication:

- **A↔C — the buried charter text.** The exact wording of the founding document, to be composed by Writer-α (Line A). Line C needs the document to contain the phrase *four seats and a fifth* or its equivalent — some explicit reference to the colonial fifth authority — so that a player who has read the charter recognises the bricked-up door at the summit for what it is. Writer-α to confirm language.
- **B↔C — Preceptor Vossel the Younger's bloodline.** Resolved: Line C does not claim Vossel's bloodline. Vossel's characterisation is wholly owned by Line B.
- **D↔C — Old Shepherd Bram's letter-carrying past.** Resolved: Bram's *father* carried the winter-letters, not Bram. Bram's single line on the matter is fixed: *"My father rode in winter for them. He learned his letters from the same woman they learned theirs from. He did not speak of it."*

Resolved: **the Ashen Herald's unmasked identity** (Endpoint 5 only) is Brenna's elder sister who does not officially exist. Jenn is Brenna's niece, a low-level courier, not the Herald.

## A closing note

Line C is, among the five Reach storylines, the one most concerned with *refusal*. Every soul-NPC in this line is, in their pivotal moment, refusing something: Darrik refuses to say the colonists' name, Malen refuses to read Silas's testament, Brenna refuses to tell her clans, Tobiah refuses to take the oath blind, the Herald refuses the crowns themselves. The line's drama is the drama of five refusals stacked on one table. The player's critical decision is which refusal — or whose — they themselves will stand behind.

The writers' task is to make each refusal land with the full weight of the kingdom behind it. A refusal without a kingdom behind it is a sulk. A refusal with a kingdom behind it is a crown-act. Every pivotal line in this document is, in its subtext, a crown-act — which is why the three-layer annotation matters, and why the material signatures matter, and why the four-knot must appear six times in the Reach before the summit is reached.

## The Ashen Herald — writers' dossier

The Ashen Herald is the sub-soul of Line C and the interlocutor of Lines A and D. This dossier is for writers only; none of its contents should appear in player-facing text.

**Appearance.** Tall, within the ordinary human range. Cloak of coarse ash-grey wool, hooded. The mask is un-glazed clay — grey-brown, porous, visibly fired but not glazed. The eyeholes are empty cut-outs, not behind glass. The mouth of the mask is a single horizontal slit. The mask is worn tied with a leather thong behind the head; the thong is visible when the Herald turns. The mask is not a single piece — it is two pieces, joined at the brow with a seam of fired clay. Why it is two pieces is for a later writer to decide.

**Voice.** When she speaks aloud, her voice is neither clearly a woman's nor clearly a man's. She prefers to write on a slate. The slate is grey, small, chalk-held. She wipes it with the heel of her hand, leaving a grey smear.

**Movement.** The Herald walks. She does not glide, hover, or appear-and-disappear in the narrative. The illusion that she moves through sealed doors is produced by her actual use of the fifth door — the bricked-up door in the summit chamber, and the other doors of its kind scattered through the Reach. There is at least one such door in every significant town. Writers should place one, un-noted, in each of T001–T005 (locations at writers' discretion).

**Knowledge.** The Herald has been through the fifth door. She knows, at minimum: that the four kingdoms are descended from colonists; that the four-knot is the colonial council's seal; that the amber tea, the pale metal, the distant-voice stones, and the brass cups are all far-side artefacts; that the woman Malen hears in the grey stone is alive and still on the far side. She does not know — flag for writers — what happened on the far side a hundred years ago, or why the silence began.

**Motive.** The Herald rejects all four crowns as a matter of principle. She believes the four-crown frame is a cage built over a door, and that the cage must be broken. She does not believe the far side should be contacted; she believes the *cage* should be exposed, so that whatever lies behind the bricked door can be seen for what it is. She is not an ally of the Crossers (Line E) — the Crossers want to reach the far side, and the Herald does not. She is, in an important sense, a *fifth kingdom of one*: Fog-aligned, anti-legitimacy, anti-return.

**Relationship to Jenn.** The Herald did not hire Jenn. Jenn stole the cipher-pad independently and wrote to anyone she thought would listen. The Herald's letter reached Jenn's hand by a chain of two intermediaries — a Windrest clerk and a Stoneford salt-fish buyer — neither of whom knew what they were passing. The Herald's intent in writing was to surface the summit *to the Union itself*, on the assumption that the Union, if warned, would refuse to attend. Jenn's decision to pass the letter to the player rather than to the Union was Jenn's own.

**Unmasking.** In Endpoint 5 (Fog path), the Herald unmasks once, in the player's presence, in a location the writer is to choose. The unmasking is a single scene, not repeated. After the unmasking, she replaces the mask and continues to wear it. The player is the only character in the Reach acts who has seen her face. Canonical identity: **Brenna's elder sister who does not officially exist.**

## Final notes for the orchestrator

Line C is designed to be survivable at all five endpoints. No endpoint is a game-over. Each endpoint redirects the flow of Lines A, B, D, and E, and each endpoint changes the *tone* of the Reach's remaining acts — Crown-aligned play is tighter, Faith-aligned play is dreamier, Free North-aligned play is slower and more letter-driven, Union-aligned play is record-heavy and investigation-forward, Fog-aligned play is stranger and less legible. The world-agent should flag the chosen endpoint at the close of T005's first act and carry it forward as a persistent world-state variable.

The player is never required to *understand* the colonial history to complete Line C. The line is designed so that a player who has understood almost nothing — who has merely helped a girl on a dock, carried a letter, sat quietly at a summit — can still meaningfully choose one of the five endpoints. The line rewards deep play with layered understanding, but it does not gate completion on it.

The material signatures — amber tea, pale metal, grey stone, brass cup — are the load-bearing images of the line. If any one of them is cut by a later writer for aesthetic reasons, the line loses a kingdom's voice. Writers are asked to treat these four as non-negotiable.

The four-knot seal is the visual signature of the line. If any one of its six appearances is cut, the player may fail to recognise it at the summit, and the summit's chamber-detail will not land. Writers are asked to treat the six appearances as non-negotiable.

Finally, the three-layer annotation — *// public= / feared= / private=* — is the most important craft-tool in this document. It is the method by which each royal carries the full 2+5+6 motive-stack in every pivotal line. Writers adapting lines to new scenes must preserve the three-layer structure even when the line itself changes. If a line is edited without its annotation surviving, the line has been damaged.

## Timeline — from hook to critical

This is the in-world calendar the world-agent should hold Line C to. Dates are given in the Reach's native reckoning; each *moon* is a month of approximately twenty-eight days.

**Moon before the hook — the Herald writes.** Somewhere between T004 and T005, in a room the Herald does not name, she composes the letter the player will later carry. She writes two drafts; the first she burns. The second she seals with the four-knot. She gives it to a courier whose name she has already forgotten.

**Three weeks before the hook — the courier is noticed.** The Consul-Merchant's clerks in Mistmere notice that one of their cipher-pads has gone missing. The clerk responsible is dismissed without pay. She takes the pad with her because they did not give her her final coin. Her name is Jenn.

**Two weeks before the hook — Brenna receives her summons.** A Crown rider arrives at the Greyhold hall with a sealed letter. Brenna reads it alone. She burns it. She tells Ylva to prepare six horse and the long road. She does not tell her clans. Ylva asks why; Brenna says *because the Crown has asked for a chair, and a chair has to be sat in.*

**Two weeks before the hook — Malen has her worst night.** The grey stone speaks four words. She does not understand any of them. She prays the Pattern into her doorway until dawn. She does not sleep.

**Ten days before the hook — Darrik drinks the tea alone.** He sits in the Ashcrown's summer garden. His thumb-ring is off; he is turning it in his fingers. He is thinking about Tobiah Caul, whom he has never met.

**Seven days before the hook — the hook.** Jenn is pursued across Stoneford's dockside. The player intervenes. (See T001.)

**Five days after the hook — Ylva crosses into Windrest.** Six horse, truce-pennant, the line-inlaid armour. Yura greets her. (See T002.)

**Eight days after the hook — Alric takes his first tea at the Jade Lantern.** Jade notices. (See T004.)

**Twelve days after the hook — the Septa refuses Silas's letter.** Silas receives the refusal the same day. Sara is with him when he reads it. (See T003.)

**Fourteen days after the hook — Brenna arrives at Mistmere outskirts and camps outside the walls.** She will not enter the city until the morning of the summit. The Crown considers this a discourtesy. Brenna considers it a courtesy to her clans, who would not wish to see their chieftess inside Faith-walls for longer than necessary.

**Fifteen days after the hook — Tobiah arrives at Mistmere.** He takes rooms at the best inn in the merchants' quarter. He is visibly pleased. He writes home to his wife that he has been *invited to a crowns' table, which is a thing my grandfather would not have believed.*

**Sixteen days after the hook — Darrik arrives at Mistmere.** He stays at the cathedral, by Malen's invitation. He and Malen dine together that evening. They speak of nothing consequential. Darrik notes that Malen's stone has been moved from her throat to her right hand. Malen notes that Darrik is drinking tea out of a cup she has never seen. Neither of them remarks on what they have noticed.

**Seventeen days after the hook — the dark moon. The summit.**

**Eighteen days after the hook — the dawn assembly.** Five endpoints. One is taken.

## Town-by-town scene script reference

### T001 — The hook, expanded

The hook is Jenn's. The dockside chase is the setpiece. Writers for T001 should hold to the following beat-structure:

1. Player is in the port on legitimate business (any business).
2. A commotion at the salt-fish quay: two men in grey wool, a girl bleeding.
3. Player chooses to intervene, ignore, or follow at distance.
4. If intervention: the men break off at the first sign of resistance. They are not killers.
5. Jenn, cornered, produces the letter. She does not read it aloud. She presses it into the nearest honest hand.
6. If ignore: the girl escapes into the warehouses and is found, three days later, dead in an alley with the letter still in her boot. The letter reaches the player by a different path — Mira Ashford's broom finds it when she sweeps the back of the inn.
7. If follow at distance: the chase ends at the warehouse of Caul & Sons, where Jenn hides in a crate that is, by a coincidence the Herald did not plan, one of the crates containing the twelve brass cups.

The letter must reach the player in all three paths. The letter is the trigger.

### T001 — Heron's hint, scene

> Heron Blackwater is alone in the Guild's back office when the player brings him the seal. He does not look up immediately. He finishes the line he is writing. He sets the quill down. Only then does he turn his head.
>
> "Show me."
>
> The player lays the letter on the desk. Heron looks at it for a long time. He does not touch it.
>
> "Close the door."
>
> The player closes the door.
>
> "Do you know what this is, traveller?"
>
> "A seal."
>
> "It is the seal of a body that is older than the Guild. It is the body the Guild was made to serve, and then made to replace, and then made to hide. Do you understand me?"
>
> "No."
>
> "Good. Keep not understanding. Keep it in a pocket that is not yours. Give it to the person it is addressed to, if you can. If you cannot — burn it. Do not read it. Do not have it copied. Do not ask me about it again."
>
> Heron picks up the quill. He returns to his line. The conversation is over.
>
> *// public=Guild-master's caution, feared=the four-knot is returning to circulation, which means the cover-up is being challenged, private=he has seen this seal once before, at his grandfather's funeral, on a letter his grandfather kept in a sealed drawer and never read*

### T002 — The stable, expanded

The Yura/Ylva stable scene (above) is the set-piece. In addition, T002 writers should place the following:

- An ambient exchange between two of Windrest's stablehands, overheard by the player: *"The envoy's horse doesn't sweat." "Don't say doesn't — say didn't. I rubbed her down and she was dry as bread. Three days' ride." "You're imagining things." "I rubbed her down, boy. I know a dry horse."*
- A late-night scene in which Ylva, alone in the guest quarters, takes a small grey stone from her belt-pouch, presses it to her ear, listens, and then puts it away. If the player is stealthed outside the door (DC 19 Stealth), they see the stone. Ylva does not use it again in the player's presence. She does not know what it is either — she thinks it is a clan-relic. Brenna has not told her.
- A refusal scene: if the player attempts to ask Ylva directly about *we came from the other side*, Ylva will go perfectly still, then will say, flatly, *"I do not know what you are talking about. I did not say those words. You did not hear them."* She will not speak to the player for the rest of the T002 visit.

### T003 — The Septa's reach, expanded

Malen is not physically present in T003, but her *weight* must be. T003 writers should place:

- Two of the Septa's riders at the Wolfsjaw garrison, interviewing every soldier who has been below ground in the past year. The interviews are formal, in writing, and each soldier is asked the same three questions: *Have you heard voices in stone? Have you seen a cloud that is a line? Have you been below ground without a Faith-witness?* Most soldiers answer no to all three. Two answer yes to the first. Those two disappear within a week. Mark (NPC_T003_03) knows this. He will tell the player quietly, once, and then refuse to speak of it again.
- A sealed crate in Archivist Naryn's cabinet, marked with the four-knot seal. Inside: copies of the Northern Ban decree, each one half-burned identically. The burning is the Faith's standard redaction. The unburned half is — in every copy — the same: the *lower half* survives in some, the *upper half* in others. Pieced together across three copies, the full text can be reconstructed. Reconstruction is a dedicated side-quest. The full text names the Depth-Walkers as a suppression target and the four-knot as a sealing body — confirming C↔E and A↔C in one document.
- Sara's field-medic tent at Wolfsjaw has, among the medical supplies, a wrapped parcel the Faith left behind three years ago and never collected. Sara has never opened it. If the player opens it (Sara will not), inside is a packet of amber tea-leaves, old and dry but still faintly fragrant. Grandmother Green can identify them (T004 cross). The parcel was meant for Malen. It never reached her. She has been running low for three years and does not know where the supply has gone.

### T004 — Jadehollow, expanded

Alric's presence at the Jade Lantern is the set-piece. In addition, T004 writers should place:

- A side-encounter with **Kassa Deepvein**. If the player has gained her professional regard (through any T004 quest), Kassa will, in a private conversation, say: *"The envoy wants the cup-inventory. He is going to get it. I am telling you this because I am going to give him accurate numbers, and you are going to know — if anyone ever asks — that I did not lie." // public=professional transparency, feared=the Crown's audit will expose Deepvein's fourth-level sales to the Union, private=Kassa has decided, without fully admitting it to herself, that the Consortium's confidentiality is no longer worth defending.*
- A scene in the library deep archive. The Crosser sketch *from below, we may rise* is filed between two volumes of legitimate mining diagrams. A librarian — NEW NPC **Clerk Ostric**, thin, middle-aged, unremarkable — is reshelving. He sees the player pull the sketch. He says nothing. He finishes reshelving. He leaves. That evening, a Crosser contact finds the player at the Jade Lantern and buys them a drink without introduction. *(Sets up Line E.)*
- A scene in Grandmother Green's hut. If the player brings her the unaging-tea dregs, she will brew a thin tea from them, a second steeping, and offer it. The player may drink or refuse. If they drink, they feel nothing — the effect of the tea requires years of daily use. Grandmother Green will say, looking into her own cup: *"My mother drank a tea this colour, once, when she was a girl. She lived a hundred and nine years. She said at the end she could not remember her own mother's face, but she remembered the colour of the cup. Do you want your long life to taste of this, traveller?"*

### T005 — Mistmere, the day before the summit

The summit itself is the set-piece. In addition, T005 writers should place:

- A chance encounter with Tobiah at the merchant-quarter inn the evening before. He is jovial, slightly drunk, happy to share a table. He will tell the player: *"I have never been to a crowns' table. My grandfather was a salt-fish seller. He would not have believed this, traveller. He would not have believed it. I am going to sit at a table with a King-Apparent and a Chieftess and a Septa. What do you say to a Septa, traveller? Is it *Your Holiness* or *Most Holy* or what? My wife will want to know."* He is unarmed. He is alone. He does not know he is in danger. The player may warn him, mislead him, drink with him, or say nothing. A warning delivered here materially affects the summit: Tobiah will arrive more alert, more cautious, and less likely to drink from the brass cup on sight.
- A chance encounter with Brenna at the outskirts-camp. She does not permit visitors, but Ylva will — if the player has earned her trust at T002 — allow a brief audience. Brenna asks one question: *"Traveller. Have you been in the port at Stoneford recently?"* If yes: *"Did you see a girl called Jenn?"* If yes: *"Is she well?"* Brenna's interest in Jenn is unexplained in this line; flag for cross-writer consideration. (One writer-team candidate: Jenn is Brenna's niece, sent south to watch the Herald's correspondence. Not canonised here.)
- A chance encounter with Darrik, if the player is Alric-sponsored. Darrik receives the player in a small chamber in the cathedral guest-wing. The meeting is brief. Darrik studies the player's face for a long moment before speaking. He says: *"You carry something of the Herald in you, traveller. I do not know what. I do not know if you know. I am telling you because I want you to know that I have noticed. The Crown notices." // public=royal courtesy, feared=this player has been in the same room as the Herald at some point, and the Crown's agents have not identified where, private=he is asking the player, in the only way he can without breaching court protocol, to declare themselves.*
- A chance encounter with Malen, if the player has recovered Silas's testament and approaches the cathedral with it. Malen will not receive them officially. A serving-girl will take them down a narrow stair into a prayer-cell. Malen is there, alone, in her ashen robes, with her grey stone pressed to her ear. She does not speak for a long moment. Then, without lowering the stone: *"What have you brought me, traveller?"* The player shows her a single page. Malen reads. Her face does not change. She says: *"Leave the page. Do not bring me the rest. I cannot read the rest and remain the Faith. Go." // public=pastoral refusal, feared=the testament will destroy her office if she reads it, private=she is asking to be spared; she is asking, not commanding, and a Septa asking rather than commanding is a Septa at the edge of her Pattern.*

## Style guide (Line C only)

- **No modern vocabulary.** Never use the words *colonist*, *continent*, *artefact* (use *relic* or *thing*), *alloy*, *concrete*, *metal-that-does-not-hammer* (use *un-hammerable metal*), *cryogenic*, *reactor*, *radio*, *signal*, *transmission*, *communications*, or any clearly technical register. The only permissible technical register is merchant-accounting — *weight, clasp, tally, ledger* — because the Union's voice is allowed that precision.
- **No modern psychological register.** No *trauma*, *dissociation*, *repression*, *internalised*. A character may be *haunted*, *unsleeping*, *quiet*, *not himself*, *thin in the face*.
- **The colonial history is never spoken aloud.** The one exception is Brenna's *we came from the other side*, spoken once in clan-tongue to Ylva alone. No other character speaks it. Writers for later acts MUST NOT add second or third utterances.
- **The three-layer annotation** (*// public= / feared= / private=*) is a writer-only tool. It must never appear in player-facing dialogue, in quest text, or in item descriptions. It is a continuity instrument for town writers, and it must travel with every soul-NPC pivotal line.
- **The four-knot seal** appears visually six times across the line (plate, letter, monastery-scrubbing order, ceremonial seal, bricked door, founding charter). At least three of these appearances must be in-game graphics or described image-fragments, not only in text. The player should learn to recognise the seal before they learn what it means.
- **The amber tea, the pale metal, the grey stone, the brass cup.** These are the four material signatures of the four kingdoms. Every soul-NPC must be shown touching, holding, drinking, wearing, or refusing their material signature in their first in-person scene.

## Glossary for writers

- **Ashcrown:** the Crown kingdom, southern-most of the four, capital at Mistmere (shared governance with the Faith).
- **Faith / Septon Order of the Pattern:** the Faith's institutional body, seated at the Grand Cathedral at Mistmere.
- **Free North / Greyhold clans:** the loose confederation of clans north of the Brokenspine, seat at Greyhold Hall (not visited in the Reach acts; known by reputation).
- **Union / Caul & Sons, the Honest-Weight Guild:** the merchant polity, headquartered in Caul-town (also not visited), with sub-offices in Stoneford, Windrest, Jadehollow, and Mistmere.
- **Four-Knot:** (1) the arbitration body that predates all four kingdoms; (2) the ceremonial seal of the same body, four loops around an empty centre; (3) the ritual oath the Faith uses to seal the four-crown summits.
- **The Pattern:** the Faith's cosmology. A right-ordered structure in the world, read by the Septon Order. Doors, thresholds, and frames are its visible signatures. The Faith's oaths are sworn into doorways.
- **Honest Weight, Honest Word:** the Union's house-words. Used as a greeting, a blessing, a closing, and — in the summit — as a rhetorical trap by the Ashen Herald.
- **Clan-ale:** the Free North's ceremonial drink. Drunk from bone cups carried by the drinker. A Free North-delegate arriving at a summit without their bone cup is a delegate who has declined the summit's hospitality.
- **Amber tea:** the Crown's private stimulant, believed by outsiders to be a southern luxury. Believed by the Crown to be a sacrament. Is, in fact, a relic preparation.
- **Distant-voice stone:** the term *the writers use*. The term the Faith uses is *grey stone of the Pattern*. The term the Crown uses is *silent cup*. The term the Free North uses is *listen-stone*. The term the Union has not coined yet.
- **The Herald:** always *the Ashen Herald* on first reference, *the Herald* subsequently. Never *she* in narration except in tight POV. The mask is always *un-glazed clay*.
- **The fifth door:** the bricked-up door in the summit chamber. Never called *the fifth door* in player-facing text; referred to as *the north wall* or *the bricked door*. The fifth door is a writers' term.

## Write-in checklist for town writers

- **T001/npcs.json:** Add NEW NPC **Jenn** (messenger, smallfolk, wounded at the hook; post-rescue becomes a low-tier recurring contact in the port). Add a dialogue branch to **Heron Blackwater** (NPC001): when shown the four-knot seal, Heron will quietly remark that the Guild used to answer to that knot before it answered to coin. Add a dialogue branch to **Mira Ashford** (NPC003): the funeral-plate recognition. Add an ambient dialogue line to **Old Reed** (NPC002) warning the player to pocket the seal elsewhere.
- **T001/facilities.json (or equivalent scene file):** Add the dockside chase scene. Add a Caul & Sons salt-fish crate stamped *HONEST WEIGHT, HONEST WORD*. Add Tobiah Caul's cameo at the customs shed (a T001 version of Tobiah, brief — the T005 version is the soul).
- **T002/npcs.json:** Add NEW NPC **Ylva Stoneshield**, envoy of Chieftess Brenna. Flag as cousin of existing NPC_T002_01 Yura Stoneshield. Add dialogue branch to **Yura** (NPC_T002_01) for the stable scene. Add a rumour line to **Mei** (NPC_T002_03) about the impossible-rested horse. Add a line to **Brown** (NPC_T002_04) about being named *contract-folk* by Ylva.
- **T002/npcs.json (Old Zhao):** Add the 50-gold decryption service for Herald's-cipher letters. Add Zhao's aside that the four-knot is pre-Guild.
- **T003/facilities.json:** Ensure the monastery back wall glyph 上下相通 (Line B fragment) is present and flag that the Septa has ordered it scrubbed under her four-knot seal. Add a glimpse of the seal order in Archivist Naryn's cabinet, adjacent to the half-burned Northern Ban decree.
- **T003/npcs.json:** Add dialogue branch to **Sara** (NPC_T003_02) about the Septa's distant-voice stone. Add dialogue branch to **Linden** (NPC_T003_01): *"the summit is about a door"* and the rider-arresting-pilgrims line. Add a one-line rumour for **Mark** (NPC_T003_03) about the Septa's rider asking after *voices in stones*.
- **T004/npcs.json:** Add NEW NPC **Envoy Alric of House Voss** (Crown envoy). Add dialogue branches to **Kassa Deepvein** (NPC_T004_01) for the royal-audit scene. Add dialogue branches to **Jade** (NPC_T004_04) for observing Alric's tea ritual and for selling/losing the unaging-tea dregs. Add a dialogue branch to **Grandmother Green** (NPC_T004_05) identifying the dregs as *not grown but made*. Add a line to **Old Fane Crowseye** (NPC_T004_03) where his pale eye reads Alric's tin as older than the Ashcrown. Add a line to **Hawke** (NPC_T004_08) about Tobiah's twelve cups.
- **T004/facilities.json:** Add the Crosser sketch *from below, we may rise* to the library deep archive (already listed in SHARED_BRIEF; confirm filed under *mining — antique diagrams*).
- **T004/items.json:** Add the *unaging-tea dregs* as a lootable/purchasable fragment tied to Alric's cup at the Jade Lantern.
- **T005/npcs.json:** Add the four NEW soul NPCs: **Darrik Voss**, **Malen the Unsleeping**, **Brenna Greyhold**, **Tobiah Caul**. Add the NEW sub-soul **The Ashen Herald**. Flag all five as summit-scoped — i.e., accessible in person only within the critical scene or under tightly gated sub-quests.
- **T005/facilities.json:** Add the summit chamber under the Grand Cathedral. Document the four doors, the four cups, the bricked-up fifth door with four-knot in fired clay. Flag the chamber as requiring a writer-held continuity list for the Herald's non-opening entry.
- **T005/items.json:** Flag Tobiah's brass cup (the Union's place-setting) as a relic-class item, identical in metallurgy to the un-hammerable lump at Durm's forge in T002 (Line D).
- **Cross-line asset:** Confirm the four-knot seal graphic is used consistently: the Herald's letter (T001), the plate in Mira's kitchen (T001), the Septa's scrubbing order (T003 archive), Malen's ceremonial seal at the summit (T005), the bricked clay relief on the fifth door (T005), and — once Line A's Critical is reached — the founding charter itself. The same image, six appearances, never commented on as *the same image*.
- **Dialogue annotation:** For every soul-NPC pivotal line in T005, writers MUST preserve the *// public= / feared= / private=* three-layer annotation as writer-only notes. These are NOT to be shown in-game. They guide voice-consistency across towns when supporting NPCs reference the crowns.
- **Naming discipline:** Never let any NPC below royal rank say *colonist*, *far side*, or any modern vocabulary. Brenna's line *we came from the other side* is the only explicit utterance in Line C, and it is spoken once, in clan-tongue, to a single listener. No other character — not Darrik, not the Herald — says it aloud.
