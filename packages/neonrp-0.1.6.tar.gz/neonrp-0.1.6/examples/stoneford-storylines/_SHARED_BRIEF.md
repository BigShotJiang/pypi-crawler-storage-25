# Stoneford Storylines — Shared Brief

> Read this first. All 5 storyline writers share this world logic.

## Hidden premise (NEVER write in any player-facing text)
The far side of the Great Chasm is a **dead modern civilization**. The lost hero's fragment "Eternal-life × Gold × Infinity. Do not visit." actually points to:
- Eternal-life = undying bodies (cryogenics / prosthetics)
- Gold = rare-metal architecture (high-rise alloy structures)
- Infinity = a full, fog-free continent

All references to the far side must stay in indigenous sensory language: "the sun nailed to a tower," "houses that fly," "iron dragon that sings like a forge," "the unending road." Never use modern vocabulary (plane, concrete, alloy, reactor, cryogenic).

## Core backstory
- The four Northern kingdoms' royal lines descend from **colonists from the far side**. Only the royal families still remember this (partially).
- **100 years ago contact stopped.** Royals interpret: either the far side abandoned us, or the far side collapsed.
- Royals secretly **excavate relics from beneath the land** (yes, underground — the paradox).
- **Relics are far-side artefacts, yet found buried underground.** Why? Deliberate mystery in v0.1. Four NPC theories (below) — all contradictory, all canon-as-opinion.

## Royal hiding motive (the 2+5+6 stack)
1. **Legitimacy vacuum (public rationale):** admitting the far side = all crowns become provincial. The four kings mutually agree to this cover story.
2. **Fear of return (true fear):** the 100-year silence might mean *they* are coming back. The warning "Do not visit" was *from them to us*. Only royals understand this. Each king is told by predecessor on accession.
3. **Resource monopoly (actual practice):** royals use relic-derived items (unaging tea, unbreakable metal, distant-voice stones). Public exposure = loss of monopoly.

Per king:
- **Crown · King-Apparent Darrik Voss** — drinks the unaging tea; has a colonist crest fragment.
- **Faith · High Septa Malen the Unsleeping** — does NOT know the colonial history; thinks the 100-year silence is a divine abandonment; uses distant-voice stones to survive insomnia without knowing what they are.
- **Free North · Chieftess Brenna Greyhold** — remembers "we came from the other side" but cannot tell her clans; wears armour inlaid with unbreakable metal.
- **Union · Consul-Merchant Tobiah Caul** — knows nothing; his merchants once bought relics thinking they were antiques. Dangerously ignorant; accidental ally to truth-seekers.

## Depth-Walkers (Line E) internal split
- **Listeners (派一):** partly genuine mystics, partly **royal-contracted relic miners**. Archdepth Sula is their half-mad icon; she was the original contracted miner.
- **Crossers (派二):** splinter from Listeners. Refuse to hand relics to royals. Secretly engineer a way to cross the Chasm. Led by Navigator Kestrel. Hold a sketch labelled "from below, we may rise."
- Listeners = wage-earners with mystic chaff. Crossers = defectors with engineering and illicit colonial knowledge.

## Why are relics underground? (Four NPC theories — all canon-as-opinion, none correct publicly)
1. **King's Archivist version:** "When the collapse came a hundred years ago, part of the far side was buried."
2. **Kestrel (Crosser) version:** "Colonial-era transit ran underground, not across. The Chasm was never the real road."
3. **Hallen (mad returnee) ravings:** "Below and beyond are one. The floor is the far wall."
4. **Eilin (Maester, mute) in written glyphs:** "Above and below connect." (上下相通)

These four appear as dialogue / notes / wall glyphs with their named NPC as source. The world-agent never confirms which is right.

## Soul figures per line
- **A Guild's Buried Charter:** Magister Corvin Ashford-Reed (T005). Sub: Keeper-Commander Olric the Silent (dead 200y, grave T003).
- **B World Before the Fog:** Maester Eilin of the Broken Tongue (T003). Sub: Preceptor Vossel the Younger (T002).
- **C Four-Crown Intrigue:** Darrik Voss / Malen / Brenna / Tobiah (one per kingdom). Sub: Ashen Herald (T005).
- **D Iron Dragon Returns (暗线):** Veyl "the Line" (T005). Sub: Old Shepherd Bram (T004).
- **E Depth-Walkers:** Archdepth Sula (T005, Listeners). Sub: Navigator Kestrel (T004, Crossers). Contact: Yannic "Yan" Vello (T002, young Listener).

## Hook tier
- **Tier 1 hooks in T001 (Stoneford):** A, B, C
- **Tier 2 hooks in T002 (Windrest):** D, E

## 5-town progression
Sprout (hear about it) → Involvement (pick sides) → Critical (irreversible decision at T005).
| Line | Sprout | Involvement | Critical |
|------|--------|-------------|----------|
| A | T001 | T002–T003 | T004–T005 |
| B | T001 | T002–T003 | T003/T005 (Eilin/T005 city-on-ruins) |
| C | T001 | T002–T004 | T005 four-crown summit |
| D | T002 | T003–T004 | T005 Veyl reveal |
| E | T002 | T003–T004 | T005 Sula + Crossers |

## Cross-line dependencies (must be honoured)
- A ↔ B : Guild's "Northern Ban" quotes the stone shard text.
- A ↔ C : Guild was originally the four-crown arbitration body.
- A ↔ D : Guild suppresses the straight-line-cloud sightings; pressures Old Bram.
- B ↔ E : Eilin was muted for proving "great cliff = great chasm"; Kestrel archives her drawings.
- C ↔ E : only Northern royals (Crown + Free North high) know the truth; the suppression of Depth-Walkers is a royal policy.
- D ↔ E : the night the cloud appears, Depth-Walker cells all douse lanterns and descend; Crossers read it as "the other side sent a scout."

## Fragment inventory (must be placed in the town files)
| Fragment | Carrier | Where | Primary line |
|----------|---------|-------|--------------|
| Ancient stone shard | Septon Silas | T001 | B (+A/E cross) |
| Old Guild brass token | Hidden under tavern hearth | T001 | A |
| Un-hammerable metal lump | Blacksmith Durm | T002 | D (+ motive 6) |
| Wall glyphs "上下相通" (Above-and-below connect) | Monastery back wall | T003 | B (Eilin) |
| Unaging-tea dregs | Crown envoy's leftover cup | T004 | C (+ motive 6) |
| Crosser sketch "from below, we may rise" | Library deep archive | T004 | E派二 (+B cross) |
| Colonist crest fragment | Veyl's pocket | T005 | D (+ colonial history) |
| Listener contract parchment | Sula's desk | T005 | E派一 (+ motive 6) |
| Straight-line cloud (sky event) | Sky between T001→T002 | T002 | D |
| Half-burned "Northern Ban" decree | Archivist Naryn's cabinet | T003 | A (+ colonial history) |

## Voice & style
- Third-person limited, short paragraphs, physical detail, no exclamations.
- Tone: low-fantasy political intrigue × grim monster-hunter frontier × eastern other-world metaphysics.
- NPC dialogue: terse, indirect, with implied history.
- Never explain the hidden premise to the player.

## Deliverable format per writer
Single Markdown file at `game/storylines/<ID>-<slug>.md`:

```
# Storyline <ID>: <Name>

## Function
(one-paragraph purpose of this line)

## Soul figure(s)
(name + role + first-appearance town)

## Hook
(tier, which town, what triggers it)

## Clues by town
| Town | Carrier | Type | Content |
For each of T001..T005: list every fragment, NPC line, scene beat, item drop, glyph.

## Stage endpoints
- Sprout end:
- Involvement end:
- Critical decision at T005:

## Cross-line interactions
(explicit citations: "references clue X of line Y")

## Write-in checklist for town writers
(bullet list: "T001/npcs: add dialogue to Septon Silas about...", "T003/facilities: add monastery wall glyph '上下相通'", etc.)
```
