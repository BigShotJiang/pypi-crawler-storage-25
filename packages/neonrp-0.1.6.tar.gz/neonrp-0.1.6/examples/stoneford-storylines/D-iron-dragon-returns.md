# Storyline D: The Iron Dragon Returns

> Hidden line (暗线). Writer-δ. Do not explain. Do not resolve.

## Function

This line is the world's weather report from beyond the weather. It is the
first proof, quietly dropped into the sky, that the world is no longer still.
Where Line A plots against paper, Line B digs under stone, Line C carves at
crowns, and Line E climbs into the dark — Line D only watches the air and
listens to old men. It expands sensory experience. It never explains itself.
The player receives a series of scraps — a straight line of cloud that
villagers call weather, a shepherd's refusal to tell his story twice, an old
woman's lullaby in a mining valley, a fragment of parchment behind a locked
shelf, a stranger in a travelling coat who recites genealogy the way a priest
recites prayer — and the player is expected to feel, not understand. The
orchestrator must never confirm what these scraps point to. The game never
adjudicates whether Veyl is a true-hearted liar or a real descendant of the
Hero-from-Beyond. The game never tells the player that the sky is moving
because something on the far side is moving. The feeling is the line. The
line does not survive being named.

## Soul figure(s)

- **Veyl "the Line"** — T005. A tall, careful man in a grey travelling coat
  cut in a style no one remembers. Speaks slowly. Carries a brass-framed
  locket that he opens for no one, and a pocket fragment he will show to one
  person in the course of the line. Claims a bloodline from the Hero-from-
  Beyond. The claim is either truth worn smooth by generations or a beautiful
  lie told by a man who believes it. The game never decides.
- **Old Shepherd Bram of the High Scree** — T004, sub-soul. Sixty-some, deep
  lines in his face, one eye clouded, a limp in the left knee from a fall he
  will not describe. Winters in Jadehollow, summers on the high scree above
  the Brokenspine. He has one testimony and will give it exactly once:
  *"It was not a dragon. It was a house that flew."* He will not elaborate.
  Pressing him makes him quieter, never louder.

## Hook

- **Tier 2 hook, Windrest Keep (T002).** The sprout is a sky event, not a
  person. In the week the player arrives at Windrest, the dawn comes up with
  a single straight line of cloud drawn across it from north to south — thin,
  level, longer than any cloud has a right to be, casting a needle of shadow
  across the parade ground. Villagers call it *weather*. A relay courier
  says his grandmother called it *the dragon's wake*. Blacksmith Durm, in
  the corner of the forge, looks at it once and does not look again. His
  hands go still over a lump of metal he has been trying to hammer for
  eleven years and cannot.
- **Secondary hook:** Blacksmith Durm's un-hammerable lump. The lump is in
  the fragment inventory at T002. Players who show it to Durm trigger his
  one real line: *"I took it from the hills. My hammer finds no tooth in
  it. My fire finds no belly. It is iron that knew the wind."*

## Clues by town

### T001 — Stoneford-on-the-Shale

T001 is the Sprout-zero for this line. Line D does not begin here; it
**touches** here, faintly. The player should leave Stoneford with the sense
that something is wrong with the sky, without knowing what.

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T001 | Old Reed (NPC002) | overheard line | While the player browses his shop, Reed mutters to himself about the river. If the player lingers, he says, without looking up: *"Gulls came back wrong this week. They flew south then turned around halfway. My father used to say the birds know when the road above is busy."* He will not explain "the road above." If pressed, he changes the subject to fish prices. |
| T001 | Septon Silas (cameo, Stoneford chapel) | sermon fragment | A Septon visiting from Jadehollow delivers a short morning sermon in Stoneford's chapel. One line, quoted without context, is heard by any player passing the open door: *"Do not read the sky for omens. The sky was written long before we learned our letters, and we are not its audience."* (This is Faith doctrine suppressing cloud-sightings — see cross-line A↔D.) |
| T001 | Heron Blackwater (NPC001) | dialogue (gated) | If the player has already met Bram (T004) or carried the Durm lump (T002), Heron will, when asked about "things in the north sky," look up from his ledger and say: *"Ask an old shepherd. Not a Guildsman. The Guild does not keep weather."* He will not say more. He is telling the truth: Guild policy forbids him from keeping weather records. |
| T001 | Dockside fragment | ambient | On the dawn after Windrest's straight-line-cloud event (whether or not the player has reached Windrest), a fisherman in Stoneford is overheard telling another: *"Long cloud up north. Straight as a blade. Gone by second bell."* The second man answers: *"Weather."* This exchange repeats for three consecutive dawns and then stops. Nobody remarks on it. |
| T001 | Guild notice board | poster (torn) | A half-torn notice, corners curled: *"By order of the Magister — sightings of 'long cloud' or 'iron shape in the air' are not to be logged in Guild incident reports. Direct such reports to the Magister's office. No bounty is offered."* Signed, in a small precise hand: *C.A.-R.* (Magister Corvin Ashford-Reed.) |

**Sprout note for T001.** The player should not have any Line D NPC to talk
to here. Line D in Stoneford is peripheral vision. The absence of
conversation is the point. A single poster suppressing a topic is more
effective than a speech about it.

### T002 — Windrest Keep

T002 is the Hook. The sky does the work. The player may arrive with or
without prior Line D exposure; in either case, the sky event is imposed on
the dawn after their first night in the Keep.

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T002 | Sky event | scripted ambient | Dawn of the second day. The player, regardless of location inside the Keep, can see from any window or parapet a single unnaturally straight line of pale cloud stretching from the northern horizon to the south. It is thinner than a natural cloud. It casts a hair-thin shadow on the flagstones. It persists for about two hours and then diffuses. The world-agent describes this in sensory terms only: "a line drawn in chalk across blue slate," "a thread the sky has forgotten to pull out." No NPC explains it. |
| T002 | Villagers' reactions | ambient chorus | Most residents glance up and resume work. A washerwoman says *"weather."* A courier says *"wind."* A child points and is told to stop pointing. One old man on a bench watches the whole of it without moving. If the player approaches him, he says only his name — *Nole, a traveler* — and will not speak of the sky. (See Traveler Nole below.) |
| T002 | **Blacksmith Durm** (NEW NPC, flag) | dialogue + item | Durm stands in the corner of Kalran's forge. Kalran tolerates him; Durm is not Kalran's apprentice, more a man the forge lets stay. He has an **un-hammerable metal lump** (fragment inventory, T002). Showing it to any other smith gets a shrug. Showing it to Durm, after the sky event, provokes his one full speech: *"I took it from the hills above the High Scree, six summers back. My hammer finds no tooth in it. My fire finds no belly. I have tried with oak charcoal and with river coal. I have tried with a wet anvil and a dry. It is iron that knew the wind. Bram knows the hill I took it from. Bram will not go back there."* He will not sell the lump. He may, if the player has earned his trust (a small quest, returning his lost nephew or fixing the bellows), lend it for one town. |
| T002 | Captain Yura (NPC_T002_01) | terse line | If the player asks Yura about the cloud: *"The Keep does not log weather. Ask the Guild, not the garrison."* She does not meet the player's eyes when she says this. She has been told, privately, by a courier from Stoneford, that the Guild will not log it either. |
| T002 | Mei (NPC_T002_03) | overheard song | Mei, sorting letters, hums a four-line verse without realizing she is being overheard. The verse is the same one that appears as a lullaby in T004 (see below). She learned it as a child in Jadehollow. She does not remember where. |
| T002 | Old Zhao (NPC_T002_02) | sale, 50g | Zhao sells, for exactly fifty gold, a single piece of information: *"A man in a grey coat passed through three weeks ago, going north. Did not buy from me. Did not sell. He stopped at the parapet at dawn and watched the sky as if he were counting something. He asked the way to Mistmere. He called himself Veyl."* Zhao will not speculate further. Zhao is incurious about what he cannot sell. |
| T002 | **Traveler Nole** (NEW NPC, flag) | bench, ambient | A man perhaps seventy, perhaps older, in a patched travelling coat. He sits on the same bench every dawn. He has walked, he says, *"the length of the Reach three times, and a year on the far moors."* He will not speak of the sky directly. He will, to a patient listener, say: *"I was a boy on the coast road. My grandmother had a saying for mornings like this. She said, when a line is drawn in the sky, the old road is open again. I never asked her which road."* He does not know. His grandmother is long dead. |

**Sprout end for T002.** The player leaves Windrest having (a) seen the
cloud, (b) heard two or three fragments that do not cohere, (c) possibly
holding, or having seen, the un-hammerable lump. No NPC has said the word
*dragon* to the player's face. The word should be in the player's mind
without having been placed there.

### T003 — Wolfsjaw Pass

T003 is Involvement. Here the line thickens: a scrap of parchment, a
soldier's story, and the first explicit (still deniable) contact with Line
A's suppression machinery. The Guild arrives with a reason to be here.

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T003 | Sara (NPC_T003_02) | medical observation | Sara, asked about unusual cases, mentions without emphasis: *"Three shepherds this season with the same burn on the back of the neck. Sunburn, they say. It is not sunburn. It is on the side the sun does not reach. I do not have a name for it."* She will not let the player examine a patient — medical privacy — but she will show a sketch of the burn pattern: a narrow, straight line. |
| T003 | Mark the Veteran (NPC_T003_03) | firelit story | If the player drinks with Mark at the garrison fire, and only then, Mark says: *"In the battle five years ago, the hour before dawn, I was on the east flank. I was the only man who looked up. There was a line in the sky then too. I thought it was a trick of my bad eye. After the battle I asked the captain. The captain said I had been concussed. The record says I was concussed. I was not concussed."* He will not repeat this the next night. He will deny having said it. |
| T003 | **禁书 / Forbidden scrap** | parchment, hidden | Behind the monastery library's locked shelf (same shelf as Line B's concerns; keys with Archivist Naryn). A single torn page, no author, no date. Handwriting archaic. The text reads, in the indigenous tongue: *"—and the house that flew came down into a valley that the maps do not hold. I did not see it land. I saw the line it drew across the dawn. The line stayed for the time it takes a man to say the morning prayer. The cloud was iron that knew the wind, and the wind did not know it back. I will not write the name of the valley. Whoever reads this, do not go. The Hero said, in his tongue: do not attempt to visit."* The page ends mid-sentence. The player may copy it. Taking the original triggers Line A's suppression reflex (Corvin learns within a week). |
| T003 | Archivist Naryn | dialogue (gated) | If the player asks Naryn about "houses that fly," Naryn's face becomes still. He says: *"You have been reading where you should not. The Magister has an interest in such pages. I would ask you, for your own sake, to forget you read that one."* He will not confiscate it unless forced. He has his own reasons to let fragments drift. |
| T003 | Corporal's notice | posted order | A small fresh notice on the garrison board: *"Any report from the High Scree concerning the shepherd Bram of the flock-valley is to be passed through Corporal Hest before any other channel. By order of the Guild Magister. Non-compliance will be considered obstruction of the Northern Ban."* (Cross-reference: Line A Northern Ban.) |
| T003 | **Corporal Hest** (NEW NPC, flag) | passing through | Corporal Hest is a lean, polite man in Guild livery, not garrison livery. He arrives at T003 on a specific day (the day after the player first reads the Forbidden scrap, if the world-agent chooses to couple the events; otherwise independently). He eats quietly at the garrison mess. He says he is "riding up to the scree to speak to an old shepherd." He will not say why. He is not cruel. He is a man sent to handle something. He mentions in passing that he has handled three shepherds before Bram and that all three now live quietly. The word *quietly* should fall into the conversation without weight. |
| T003 | Linden Ironfist (NPC_T003_01) | rare line | If the player has shown Linden either the un-hammerable lump or the Forbidden scrap, Linden looks at it for a long moment and then returns it without comment. Later that night, alone with the player, he says: *"I have been a soldier long enough to know when the sky stops being the sky. I do not know what it means. I know that the Magister's men would rather I not ask. That alone is reason to ask."* He does not offer aid. He offers only permission to continue. |

**Involvement mid-point.** The player has by now either (a) let Corporal
Hest ride north ahead of them, (b) tried to beat Hest to Bram, or (c)
ignored the thread. The world-agent must respect all three. If ignored,
Line D thins out; it never forecloses, because the sky continues.

### T004 — Jadehollow

T004 is Involvement-crescendo. Bram is the sub-soul. The old woman's
lullaby is placed here. The player may see Corporal Hest arrive at the
scree if the player did not outride him.

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T004 | **Old Shepherd Bram** (NEW NPC, flag — T004) | one-line testimony | Bram can be found in winter at the back of the Jade Lantern tavern, nursing a single beer for hours; in summer, on the high scree above Jadehollow. He is easy to find if one asks for "the old shepherd with the bad knee." He will accept food. He will accept company. He will not accept questions about the valley. If the player is patient across two or three evenings — if the player does not open with the question — Bram may, once, say his one line: *"It was not a dragon. It was a house that flew."* He will say nothing else that evening. He will not repeat the line another night. If the player presses, he says: *"I gave it to you. It is yours now. Do not make me give it again."* |
| T004 | Bram | pasture sighting (Listeners) | If asked about strangers on the high ground, Bram says once: *"Grey-coated folk. The earth-men, maybe. I do not trouble them and they do not trouble me."* He will not elaborate. He has seen them crossing his high pasture at dusk with unlit lanterns. (Cross-reference: Line E.) |
| T004 | Bram, pressed further | silence + gesture | If the player has shown Bram the un-hammerable lump, Bram stares at it for a long time, then taps the side of it twice with a fingernail. The tap sounds wrong — too deep for the size of the lump. Bram says: *"The hills above the flock-valley are full of pieces that sing like this. I do not take them any more. The ones I took when I was young — I gave them to the river. The river kept them."* He will not elaborate on "flock-valley." If the player asks where it is on a map, Bram looks at the map and says: *"The map does not hold it."* |
| T004 | **Old woman Haddie** (NEW NPC, flag — T004) | lullaby | Haddie is ninety, bedridden, cared for by Grandmother Green (NPC_T004_05). She is a minor NPC; the player meets her only if the player has helped Grandmother Green in any capacity. Haddie sings, in a thin voice, a lullaby she learned from her grandmother. Four lines: *"Hush now child, the line is drawn / Hush now child, the house is flown / Hush now child, the iron sings / Hush now child, the morning brings."* She does not know what the lines mean. She sang it to her own children. Grandmother Green learned it from her. Mei at T002 learned it from Green when she was a child. The lullaby is the oldest surviving artifact of Line D in the Grey Reach. |
| T004 | Grandmother Green (NPC_T004_05) | corroboration | Green, asked about the lullaby, says: *"Haddie's grandmother was a shepherd's wife. They had a song for the sky. Every generation loses a word of it. Two more generations and it will be a humming."* She does not claim to understand it. She sings an older version, with a different fourth line the player does not catch clearly. |
| T004 | Old Fane Crowseye (NPC_T004_03) | appraisal | If shown the un-hammerable lump, Fane's pale eye glows. The brown one does not. This is unusual; Mossbarrow items glow both. Fane says: *"This is not of the Barrow. This has never been buried. This remembers sky."* He will not give a price. He returns it carefully, with two hands. |
| T004 | Kassa Deepvein (NPC_T004_01) | refusal | Asked about Bram: *"The shepherd is not a Guild matter. We do not dispatch for him. We do not log him. Do not ask."* She is following a Magister's directive. She does not approve of it. She is efficient. |
| T004 | Crosser graffito | library alcove (deep archive) | Scrawled small in charcoal near the Crosser sketch *"from below, we may rise"* (E派二 fragment at T004), in a different hand: *"—or from above, if above returns."* This is a Crosser's private note, read as Line E's response to the cloud. Cross-reference: D↔E. |
| T004 | **Corporal Hest's arrival (if applicable)** | scripted scene | If the player did not outpace Hest at T003, Hest arrives at Jadehollow the day after the player does. He drinks at the Jade Lantern. He sits at Bram's table. He does not threaten Bram. He speaks to Bram in a low voice for an hour. The next morning, Bram is gone from the tavern. Grandmother Green says he has gone back to the scree. Green's face says she is not sure. If the player climbs to the scree, Bram is there, alive, walking more slowly than before. He will not speak again. His one line is already given. |

**Involvement end for T004.** Player has Bram's one line; has (possibly)
witnessed Corporal Hest's method; holds the un-hammerable lump or has seen
it; has heard or half-heard the lullaby. The player now has enough scraps
that the world-agent can, if asked for a summary, *list them* — but the
orchestrator must never connect them. Listing is permitted. Connecting is
the player's work.

### T005 — Mistmere

T005 is the Critical decision. Veyl is here. Veyl has been waiting for a
player who has carried the scraps this far. The colonist crest fragment
is in his pocket (fragment inventory, T005).

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T005 | **Veyl "the Line"** (NPC_T005_09, to be added; flag as new) | introduction | Veyl lodges at a small guesthouse near the noble quarter, not at the cathedral's inns. He pays in old coin that the innkeeper finds slightly heavy in the hand. He is courteous. He does not drink. He keeps the brass-framed locket shut. He introduces himself to the player *if the player has at least two of the following: seen the cloud at T002, handled the Durm lump, read the Forbidden scrap, heard Bram's line, heard Haddie's lullaby*. Otherwise he does not approach. |
| T005 | Veyl, first meeting | recitation | Veyl recites his line of descent. The recitation is long, measured, and takes nine generations to complete. It does not name the Hero-from-Beyond. It names only "the one who came on the house that flew" and, from there, father to son, mother to daughter, for nine names. The ninth name is his own. The recitation is word-perfect. Too word-perfect. It has the cadence of a prayer memorized in childhood — which is consistent with a true descendant *and* with a careful fraud. The world-agent must not tip. |
| T005 | Veyl, the crest fragment | item card | Veyl produces, in a private room, a fragment of worked metal the size of a child's palm. To the player's eye, the world-agent describes it in indigenous terms only: *"a piece of pale bright metal, thinner than any smith could beat it, with a pattern stamped into it — a bird on a sunburst, the bird's wings sharp and angled like no bird's wings are. The metal is warm to the touch though it has sat on the table for an hour."* To any in-world NPC who glances, it reads as "archaic heraldry" — the bird-on-sunburst looking like an old forgotten sigil of some line of lords. The player never hears the word "colonist" or "crest" in modern sense; the item card describes the sensory facts only. |
| T005 | Veyl, his ask | dialogue | Veyl says, quietly: *"I am going north. Past the last pass. Past the Grey Reach. I do not expect to return. I ask one of three things of you. First: stand beside me when I present my line to the High Septa — I will need a witness of good standing, and the Faith will not lie if a witness looks them in the eye. Second: if you believe I am a liar, expose me — take this fragment to the Magister, and he will know what to do with both it and me. Third: come with me. Walk the last road. See what drew the line in the sky. I will not promise you return."* |
| T005 | Magister Corvin Ashford-Reed (NPC_T005 Line A) | rare interaction | If the player brings the crest fragment to Corvin, Corvin examines it for a long time. His face is unreadable. He pays the player generously — more than generously — for the fragment, and for Veyl's lodging address. Within two days Veyl is gone. The innkeeper does not know where. The Guild logs nothing. (Cross-reference: A↔D. Corvin holds royal orders on this matter.) |
| T005 | High Septa Malen (cross-line C) | rare interaction | If the player stands witness at Veyl's presentation to the Faith, High Septa Malen listens to Veyl's nine-generation recitation in total silence. At the end, she says only: *"I have heard this song before. I do not know where. You may go."* She does not confirm. She does not deny. She is troubled for three days afterward and cannot say why. (This is canon for Malen: she does not know the colonial history; the recitation touches a place in her memory she cannot name.) |
| T005 | Reynard the Bishop (NPC_T005_02) | warning | If Reynard learns of Veyl (he learns of everything eventually), he sends a single note to the player's lodging. The note is one line: *"The sky is empty. It has always been empty. Confirm this for us, and there is no price we will not pay."* He does not sign it. The player is meant to understand. |
| T005 | Lady Vera (NPC_T005_03) | offer | If the player is perceived as an agent of truth-revealing, Vera sends a quiet invitation. She does not care about the cloud. She cares about legitimacy. She says: *"If this man is a true descendant, and the royal lines descend from the same — then the crowns sit above us on borrowed ground. I would like to know this. I would like him not to be killed before we know."* She offers funding for the northern journey (option three). She is a dangerous ally because her motive is unrelated to the line itself. |
| T005 | The Serpent (NPC_T005_05) | offer | The Serpent will buy the crest fragment for more gold than he has ever offered for any item. He is very interested. He will not say why. (Cross-reference: Line C — Jade Compact awareness.) |
| T005 | Veyl's locket | bonus clue | Veyl opens the locket only if the player has chosen option three (going with him) and only on the first night north of T005. Inside is not a portrait. Inside is a sliver of glass, thin as a fingernail, behind which is set a pressed, dried fragment of something — not a flower, not a feather, not any leaf the player knows. The world-agent describes it only as *"a scrap of something once soft, now dry, patterned as no plant on this side of the Reach is patterned."* Veyl closes the locket without speaking. |

**Critical decision at T005.** The player chooses one of three:

1. **Install him** — stand witness at the Faith presentation. Veyl gains
   standing. The Faith does not confirm, but does not denounce. He is
   lodged under light Faith protection. Within a season he vanishes anyway —
   north, on his own, a note left for the player: *"Thank you for the
   witness. The road was always mine."*
2. **Expose him** — bring fragment and address to Magister Corvin. Veyl
   disappears within two days. No body. No funeral. Corvin pays well. The
   player will see, once, six months later, a small notice in a Guild
   logbook: *Matter closed.* The sky keeps drawing its line at dawn,
   occasionally, for years.
3. **Follow his line north** — leave T005 with Veyl. This exits the current
   storyline map. The world-agent should close the Line D arc with Veyl
   disappearing over the last pass ahead of the player at dawn, with the
   straight-line cloud forming above him in a sky that had been clear.
   Whether the player follows is outside v0.1. The cloud is enough.

None of the three resolves whether Veyl was true descendant or fraud. In
option 1, his recitation stands on record but is unverified. In option 2,
the evidence is buried with him. In option 3, Veyl walks into a country
from which neither confirmation nor denial ever returns.

## Stage endpoints

- **Sprout end (T001–T002):** Player has seen the straight-line cloud,
  heard at least two scrap-references (Reed's birds, Silas's sermon, the
  torn Guild notice, a villager's *weather*, the dockside exchange, Mei's
  humming). Player may be carrying, or have seen, the un-hammerable lump.
  No NPC has named a "dragon" or "hero" to the player's face.
- **Involvement end (T003–T004):** Player has read the Forbidden scrap,
  heard Mark's flashback or Sara's unnamed burn observation, met Old Bram
  and received his one line, heard Haddie's lullaby (or Green's older
  version), possibly seen Corporal Hest's quiet method. Player may or may
  not have outpaced the Guild's suppression. Cross-scraps from Line E
  (Crosser marginalia: *"or from above, if above returns"*) are now in
  play.
- **Critical decision at T005:** Player meets Veyl, hears the nine-name
  recitation, is shown the crest fragment. Player chooses install / expose
  / follow. The line does not resolve. It sets. Like a line of cloud.

## Cross-line interactions

- **A ↔ D.** Guild suppression of cloud sightings is explicit. The torn
  Guild notice (T001) cites Magister Corvin by initial. The Northern Ban
  (A's half-burned decree at T003 in Archivist Naryn's cabinet) includes
  a clause that Line D's Forbidden scrap appears to quote from an earlier
  draft of. Corporal Hest is Corvin's instrument in the north; he is sent
  to "handle" Bram (T004). If the player brings Veyl's crest fragment to
  Corvin, Corvin acts on it within days. (Cites Line A clues: Northern
  Ban decree; Magister Corvin soul figure; Guild records discipline.)
- **A ↔ D, second channel.** Heron Blackwater's refusal at T001 ("the
  Guild does not keep weather") is a Line A artifact — Guild policy as
  cover. Heron is oath-bound; the player can read between his lines only
  if they already carry Line D scraps. (Cites Line A clues: Guild charter
  discipline; Heron's grandfather's deal, which is unrelated but reminds
  Heron what silence costs.)
- **D ↔ E.** On the dawn the straight-line cloud appears at T002, every
  Depth-Walker cell in the Grey Reach douses its lanterns and descends.
  Listeners (派一) interpret it as a sign to *go deeper*; Archdepth Sula
  at T005 records it in her ledger as *"the sky has begun to report, we
  must return to the silence."* Crossers (派二), led by Navigator Kestrel
  (T004), interpret it the opposite way: the Crosser marginalia *"or
  from above, if above returns"* (T004 library) is written the evening
  after the cloud. (Cites Line E clues: Crosser sketch "from below, we
  may rise" at T004; Listener contract parchment at T005; Archdepth Sula
  soul figure.)
- **D ↔ B.** The Forbidden scrap at T003 is in the same monastery
  library, behind the same locked shelf, as Line B's primary materials.
  Archivist Naryn keeps both. Maester Eilin of the Broken Tongue
  (B soul figure at T003) has, in her wall glyphs, a character that
  translates roughly as *"above and below connect"* (上下相通), which
  cross-references to D's "line in the sky / house fallen in a valley"
  motif — the *above* that *came down*. (Cites Line B clues: Eilin's
  wall glyphs at T003; the locked shelf.)
- **D ↔ C.** Veyl's crest fragment visually echoes patterns on the
  colonist crest fragments held by the four royal lines (Line C). The
  four-crown summit at T005 happens in the same season as Veyl's arrival,
  by coincidence or by Veyl's careful choice. High Septa Malen's
  unease at Veyl's recitation is a Line C artifact (her ignorance of
  the colonial history combined with a hereditary memory she cannot
  place). (Cites Line C clues: King-Apparent Darrik Voss's colonist crest
  fragment; High Septa Malen as Faith crown; the Ashen Herald at T005.)

## Write-in checklist for town writers

- **T001/npcs.json — Heron Blackwater (NPC001):** add gated dialogue: if
  player has met Bram (T004) or handled the Durm lump (T002), Heron
  responds to any sky question with *"Ask an old shepherd. Not a
  Guildsman. The Guild does not keep weather."*
- **T001/npcs.json — Old Reed (NPC002):** add passing mutter about
  *"Gulls came back wrong this week. They flew south then turned around
  halfway. My father used to say the birds know when the road above is
  busy."* Not to be offered unprompted; only if player lingers.
- **T001/facilities — Guild notice board:** add half-torn poster, signed
  *C.A.-R.*, suppressing cloud reports. See T001 clue table.
- **T001/facilities — Chapel:** add visiting-Septon sermon line (from
  Jadehollow): *"Do not read the sky for omens. The sky was written
  long before we learned our letters, and we are not its audience."*
- **T001/facilities — Dockside:** add recurring three-dawn fisherman
  exchange (*"Long cloud up north."* / *"Weather."*) after T002 sky
  event.
- **T002/npcs.json — ADD Blacksmith Durm (NEW NPC, flag):** minor smith
  working out of Kalran's forge corner, not owner. Carrier of
  un-hammerable lump (fragment inventory). One speech on request.
- **T002/npcs.json — ADD Traveler Nole (NEW NPC, flag):** old traveller,
  bench at parade ground, grandmother's saying about "a line drawn in
  the sky."
- **T002/npcs.json — Captain Yura Stoneshield (NPC_T002_01):** add terse
  line *"The Keep does not log weather. Ask the Guild."*
- **T002/npcs.json — Mei (NPC_T002_03):** add humming of four-line
  lullaby ("Hush now child…") learned as a child in Jadehollow; she
  does not know what it means.
- **T002/npcs.json — Old Zhao (NPC_T002_02):** add 50g info card: a
  grey-coated stranger named Veyl passed three weeks ago, watched the
  dawn as if counting.
- **T002 — sky event:** write scripted ambient scene, dawn of day 2 of
  player's stay. Straight-line cloud, two hours, indigenous sensory
  description only.
- **T002/quests.json:** add a small optional quest for Durm (returning
  lost nephew / fixing bellows) whose reward is a one-town loan of the
  un-hammerable lump.
- **T003/facilities — Monastery library, locked shelf:** add a single
  torn parchment page: the Forbidden scrap. Text as quoted in clue
  table. Co-locate with Line B materials.
- **T003/npcs.json — Archivist Naryn:** add line *"You have been
  reading where you should not. The Magister has an interest in such
  pages."*
- **T003/npcs.json — Sara (NPC_T003_02):** add observation about three
  shepherds with identical straight-line neck burns "on the side the sun
  does not reach." Refuses to let player examine patients; shows a
  sketch.
- **T003/npcs.json — Mark (NPC_T003_03):** add firelit-only story about
  the line in the sky during the Battle of Wolfsjaw; must only surface
  while drinking; next day he denies it.
- **T003/npcs.json — Lord Commander Linden (NPC_T003_01):** add
  conditional rare line acknowledging that the Magister's men would
  rather he not ask about the sky.
- **T003/facilities — Garrison noticeboard:** add Guild notice routing
  Bram-related reports through Corporal Hest.
- **T003/npcs.json — ADD Corporal Hest (NEW NPC, flag):** Guild livery,
  lean, polite, not cruel. Passes through T003 and proceeds to T004
  unless the player outpaces him.
- **T004/npcs.json — ADD Old Shepherd Bram of the High Scree (NEW NPC,
  flag — SUB-SOUL of Line D):** winters at Jade Lantern back table,
  summers on scree. Single testimony: *"It was not a dragon. It was a
  house that flew."* Refuses elaboration. Bad knee. Clouded eye.
- **T004/npcs.json — ADD Old woman Haddie (NEW NPC, flag, minor):**
  bedridden, ninety, cared for by Grandmother Green. Carrier of the
  four-line lullaby.
- **T004/npcs.json — Grandmother Green (NPC_T004_05):** add
  corroboration about the lullaby's generational drift; older variant
  with a different fourth line.
- **T004/npcs.json — Old Fane Crowseye (NPC_T004_03):** add appraisal
  response to un-hammerable lump: *"This is not of the Barrow. This has
  never been buried. This remembers sky."* Only his pale eye glows; a
  contrast to Mossbarrow items which glow both.
- **T004/npcs.json — Kassa Deepvein (NPC_T004_01):** add Guild refusal
  line about Bram not being a Guild matter.
- **T004/facilities — Library deep archive:** add Crosser marginalia
  *"or from above, if above returns"* next to the existing Crosser
  sketch *"from below, we may rise"*.
- **T004 — scripted scene (conditional):** if player did not outpace
  Corporal Hest at T003, stage Hest's evening with Bram at the Jade
  Lantern; next morning Bram is on the scree, slower, silent.
- **T005/npcs.json — ADD Veyl "the Line" as NPC_T005_09 (NEW NPC, flag
  — SOUL of Line D):** grey travelling coat, brass-framed locket,
  nine-generation recitation, colonist crest fragment (fragment
  inventory, T005). Three-option ask: install / expose / follow.
- **T005/npcs.json — Magister Corvin Ashford-Reed:** add cross-line
  response when brought Veyl's fragment: generous payment, Veyl
  vanishes within two days, Guild logs nothing.
- **T005/npcs.json — High Septa Malen:** add response to Veyl's
  recitation: *"I have heard this song before. I do not know where.
  You may go."* Three days of troubled sleep afterward.
- **T005/npcs.json — Bishop Reynard (NPC_T005_02):** add unsigned note
  to player if player is tied to Veyl: *"The sky is empty. It has
  always been empty. Confirm this for us, and there is no price we
  will not pay."*
- **T005/npcs.json — Lady Vera (NPC_T005_03):** add conditional offer
  of funding for northern journey if player is perceived as
  truth-revealing.
- **T005/npcs.json — The Serpent (NPC_T005_05):** add high-price bid
  for the crest fragment; cross-line C awareness (Jade Compact).
- **T005/quests.json:** add the three-branch critical choice quest
  (install / expose / follow north). Each branch has its own short
  resolution scene; none resolves Veyl's authenticity.

## Orchestrator conduct notes (Line D specific)

1. **Never name the hidden premise.** If the player asks *"is there a
   civilisation on the far side?"* the world-agent responds with NPC
   disagreement, not narration. Never with answer.
2. **Never use modern vocabulary.** Banned words in player-facing text:
   plane, aircraft, alloy, concrete, cryogenic, reactor, radiation,
   engineer, satellite, vehicle, missile. Substitutes are sensory only:
   *house that flew, dragon that sings like a forge, straight-line cloud,
   iron that knew the wind, the sun nailed to a tower, the man with the
   river running where his heart should be, the unending road, a world
   that does not stop.*
3. **Three to five sensory fragments, scattered.** Per this document:
   Bram's testimony (T004), Veyl's recitation (T005), Forbidden scrap
   (T003), Haddie's lullaby (T004), Durm's lump-speech (T002). The
   world-agent must not concentrate them. If the player skips a town,
   the fragments remain scattered; the player has less, not more
   clarity.
4. **Veyl's ambiguity is load-bearing.** Evidence for true descendant:
   the nine-generation recitation is word-perfect; the locket's dried
   fragment is genuinely not of this land; the crest fragment reads as
   warm metal that holds pattern no smith on this side can make;
   Malen's unease. Evidence for careful fraud: the recitation is *too*
   word-perfect (memorized); old coin is a forger's favourite; no
   witness to his parents; the crest fragment could be salvaged from
   any old shipwreck; Malen recognises the song because it is an old
   Faith cadence anyone could mimic. The world-agent presents both
   readings whenever the player probes. The world-agent never tips.
5. **The sky is patient.** The straight-line cloud recurs. Not often —
   perhaps three or four times per in-game season, more often in the
   north. Each recurrence is written as ambient, not as event. The
   sky is the one element of this line that cannot be suppressed by
   any faction, including the Guild, though they try.
6. **Bram's line is said once.** Enforce this. If the player reloads or
   re-approaches, Bram says *"I gave it to you. It is yours now. Do
   not make me give it again."* This is the emotional spine of the
   sub-soul.
7. **The Hero-from-Beyond is never named in-game.** No name is canon.
   Veyl's recitation names only roles and relations, never the Hero.
   Leave the blank.

## Additional scene beats

### Beat D-1: The Dawn Line (T002)

The first sky event in Windrest Keep. Time of day: the grey hour before
sunrise, when the stones of the parade ground are still cold. The player
may be sleeping, eating, walking the wall. The world-agent introduces it
by ambient detail, not by calling attention:

- A goat in the yard below the barracks is silent. Goats are never silent
  at dawn.
- The sky in the east is the colour of a fish's belly.
- There is one cloud and it is wrong. Not wrong in shape — wrong in
  direction. It runs not with the wind but against it, from the far
  northern horizon down toward the south, straight enough to set a
  rule against.
- The cloud is thin. The cloud is long. A hawk, startled off a tower
  weathervane, veers under it and does not veer back to see what it was.
- By the time the sun is fully up, the cloud has begun to fray. By the
  time the morning bell rings, it is only a smear. By noon it is gone.

NPC reactions, layered:

- A young recruit at the north wall asks his sergeant what it was. The
  sergeant, who has served thirty years, says: *"A cloud."* The tone is
  flat. The young recruit has been told, in one word, not to ask twice.
- A courier from Stoneford who rode in overnight says, at the relay
  station: *"I saw it from the river road. Four horses saw it with me.
  Not a one of them would cross the line of its shadow."*
- Mei (NPC_T002_03) is at the window sorting letters. She stops. Her
  hum starts without her noticing.
- Blacksmith Durm (NEW) is in the forge. He does not go outside. He
  does not look up. His hammer pauses over the un-hammerable lump for
  the first time in eleven years. Then he sets the hammer down. He
  does not pick it up again that day.
- Traveler Nole (NEW) is on his bench. He watches the whole of it
  without expression. When the cloud is gone, he taps the bench beside
  him twice with two fingers, slowly, as a man might count something
  he has been counting for a long time.

If the player walks the parapet during the event, the orchestrator
describes the player's own shadow on the flagstone and, crossing it at a
near-right angle, the cloud's thin shadow. Two lines of darkness. The
player's own, and one that is not theirs.

### Beat D-2: The Reading of the Scrap (T003)

The monastery library is cold in every season. Archivist Naryn keeps his
own lamp; the Faith lamps are thin-wicked. The locked shelf is on the
west wall, behind a reading-desk built into the panelling. The key is in
Naryn's belt pouch; a duplicate hangs from a nail beneath the desk that
Naryn pretends not to know about.

Behind the shelf, among other things the Faith would rather not see
read: the Forbidden scrap. One page. The parchment is old — older than
the monastery. The ink is iron-gall and has corroded through the page
in several words, making small holes. The handwriting is a monk's hand
from at least three centuries before present. The page has been folded
and unfolded many times.

If the player reads it at the desk: the lamp flame bends once, briefly,
toward the page as if drawn. Naryn, at the other end of the room, looks
up. He does not move. He waits to see whether the player will take the
page or leave it.

If the player takes the page: within the hour, a raven leaves the
monastery roof. Within the week, Corvin's office at Mistmere has been
informed. Within the fortnight, Corporal Hest is riding. (This triggers
the Hest thread more forcefully.)

If the player only copies it: Naryn exhales — the player hears it
across the room — and returns to his work.

If the player reads and leaves it: Naryn says nothing for the rest of
the visit. Three evenings later, he is found dead at his desk, of a
heart that had been tired for years. Whether this is coincidence is
never addressed. (Orchestrator note: this death is optional. Use it
only if the player has shown cruelty or inattention to the library. It
is the library protecting its own.)

### Beat D-3: The Scree (T004)

Bram's summer ground. The scree is a slope of loose grey stone above
Jadehollow, an hour's hard climb. The sheep that graze here are thin
and dark. Bram keeps a lean-to of weathered boards against a boulder.
He has a dog — a small grey animal with a missing ear — who watches the
player's hands and never the player's face.

If the player climbs up:

- Bram is on a stone, knees up, hands loose.
- He does not rise.
- He does not greet.
- He says, if the player greets first: *"You climbed up. That is more
  than most."*
- He offers water from a clay jug. The water tastes of the stone it
  was carried in.

If the player asks nothing: they may sit with Bram for an hour, and
Bram will, at the end of the hour, point with his chin toward a
distant notch between two peaks to the north. He will say nothing.
The player may later return to Jadehollow, look at a map, and find
that the notch Bram pointed to is not on the map. The map holds other
notches, just not that one.

If the player produces the un-hammerable lump: Bram takes it, weighs
it in one hand, and returns it. He says: *"There are seven more in
the flock-valley. I left them where I found them. You will not find
the valley by asking."*

If the player produces the Forbidden scrap: Bram cannot read. He
knows the shape of old script, though. He traces one word with his
fingertip — the word that, in the indigenous tongue, is translated
"house" — and he stops. He does not speak again that visit.

### Beat D-4: The Lullaby (T004)

Haddie's room is in the back of Grandmother Green's cottage. Dark, warm,
smelling of herbs. Haddie is small under blankets. Her eyes are cloudy.
Her voice is a reed.

Grandmother Green sits with her for the evening meal. If the player
shares the meal (a quest: bring a specific herb from the foothills),
Green nods at Haddie and Haddie, without prompting, begins to sing.

The lullaby, full version:

> *Hush now child, the line is drawn,*
> *Hush now child, the house is flown,*
> *Hush now child, the iron sings,*
> *Hush now child, the morning brings.*

Haddie sings it three times. The third time, she stops after the
second line and cannot continue. She closes her eyes. Green strokes
her hand.

Green, quietly, to the player: *"Her grandmother was the shepherd's
wife on the High Scree. Three generations ago. Same hill Bram walks.
The song goes back further than her grandmother. My great-grandmother
had a version with *dragon* for *house.* My grandmother had *house.*
I had *house.* Haddie has *house.* Something between dragon and house
was lost."*

The player who has been paying attention may notice: this is the
first time in the storyline that the word *dragon* has been spoken by
a friendly NPC, and it has been spoken only to say that it was the
earlier word, now gone.

### Beat D-5: The Recitation (T005)

Veyl's room at the guesthouse. Evening. Single candle. The player has
been invited, not summoned. Veyl offers tea. The tea is ordinary.

Veyl says: *"I will recite my line. You may stop me when you wish. Few
ask me to continue past the third name. You have come further than
most."*

The recitation:

1. *"The one who came on the house that flew, whose name is not
   written where I may read it."*
2. *"His son, called Marren of the Long Road, who kept the road open
   while the road was open."*
3. *"Marren's daughter, called Halla the Patient, who did not cross
   back though the way was still known."*
4. *"Halla's son, called Voren the Silent, who taught his children to
   speak the old tongue only inside a closed room."*
5. *"Voren's daughter, called Eren Far-Eyed, who went into the hills
   and did not return for a summer and spoke of a valley."*
6. *"Eren's son, called Jarn the Third Son, who was not a third son
   but called so to hide which son he was."*
7. *"Jarn's son, called Paur the Smith, who worked metal that other
   smiths would not touch."*
8. *"Paur's daughter, called Olle my mother, who taught me this
   line at the age of six and every year after until her death."*
9. *"Olle's son. Veyl. I am the end of this line or I am the last
   before the next. I do not know which."*

If the player asks about any named ancestor, Veyl can provide a
small biographical detail — one each, no more. The details are
consistent with each other and with nothing else the player has
learned. They could be memorized. They could be true.

The crest fragment is produced at the conclusion. The player is
offered the three-option ask.

## Orchestrator disambiguation table (Veyl's authenticity)

The world-agent should keep both readings equally warm. A condensed
crib for runtime:

| Evidence | Reads as true | Reads as fraud |
|----------|--------------|----------------|
| Nine-name recitation word-perfect | Memorised in childhood by a real line | Memorised from a forgery in adulthood |
| Locket with dried fragment not of this land | Genuine relic | Bought off a Serpent-type dealer |
| Crest fragment, warm metal, bird-on-sunburst | Actual colonist artefact | Salvaged from a shipwreck, polished up |
| Old coin, slightly heavy | Hero's treasury | Any coin-collector's cache |
| Malen's unease | Genuine hereditary memory | Malen is tired and superstitious |
| Goes willingly north alone | Destiny | Escape from a con that's about to unravel |
| No witnesses to his parents | Private family | No parents to find |

The world-agent never weights this table on any individual probe.
The player may come away certain either way. Both certainties are
wrong — not because Veyl is something else, but because the game
refuses to answer.

## Gaps noted for sibling writers

- **Line A (Writer-α):** please confirm Magister Corvin's exact
  office in Mistmere so the D↔A hand-off (player brings crest fragment
  to Corvin, Veyl vanishes) can be staged precisely. Also confirm the
  signature *C.A.-R.* on the Guild notice board is acceptable.
- **Line B (Writer-β):** the Forbidden scrap at T003 sits behind the
  same locked shelf as Line B's materials. Please coordinate: the
  scrap should be physically co-located but distinct from Eilin's
  papers. Also please confirm that the "上下相通" wall glyph reading
  (above-and-below connect) is the canonical form, so D can reference
  *"the above that came down"* without contradicting B.
- **Line C (Writer-γ):** please confirm the visual pattern of the
  four royal crest fragments. Veyl's fragment should visually rhyme
  (bird-on-sunburst) without being identical. If C's canonical crest
  is different, D defers.
- **Line E (Writer-ε):** please add the Crosser marginalia *"or from
  above, if above returns"* to T004's library archive, adjacent to the
  existing Crosser sketch *"from below, we may rise."* Please also
  confirm that Sula's ledger entry on the cloud-night night
  (*"the sky has begun to report, we must return to the silence"*)
  is acceptable as Listener canon.
- **All writers:** Traveler Nole, Blacksmith Durm, Corporal Hest, Old
  Shepherd Bram, Old woman Haddie, and Veyl are new NPCs introduced
  by this document. If any of these names conflict with NPCs added by
  sibling writers, D will yield and rename.

## Closing note to the orchestrator

If the player leaves the Grey Reach without understanding what the line
in the sky was, the line has succeeded. If the player leaves with a
private theory the player does not voice, the line has succeeded more.
If the player demands an answer and the world-agent gives one, the
line has failed. The line is the one thing in this game the player
is allowed to keep for themselves.
