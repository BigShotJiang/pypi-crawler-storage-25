# Storyline E: The Descent of the Depth-Walkers

## Function

Line E is the inverse-direction line.
Where A looks to charters,
B to the fog-veiled past,
C to the four crowns,
and D to the sky,
E looks **down**.

The Depth-Walkers (地者) are a scientist-guild in ceremonial robes.
They measure rope in fathoms marked by knotted wool.
They weigh lantern-oil to the grain on a balance older than the kingdoms.
They chart draft-currents with squares of oiled silk held over shaft-mouths at dawn.
They call every one of these measurements a prayer,
and they mean the word prayer the way a northern smith means the word *tempering*:
a procedure with a time and a temperature.

They are a parallel to the Guild and to the kingdoms, not a subordinate of either.
The player encounters them as a religion
and leaves understanding them as a laboratory that has learned to whisper.

The line is internally split.

The **Listeners (派一)** are the public face.
Half of them are genuine mystics
who entered the descent because a sibling died in a well
or because they heard something at the bottom of a cistern as a child
and have been trying to hear it again ever since.
The other half are relic-miners under sealed royal contract.
The two halves are not separated by rank;
they sit at the same table, eat the same thin soup, and wear the same grey robe.
The mysticism is the cover.
The mining is the trade.
Sula herself is both at once and cannot, at this age, say where one ends.

The **Crossers (派二)** broke away nine years before the game begins.
They will not hand what they find to the northern crowns.
They are engineering a way across the Chasm in secret,
and they believe the answer is below rather than across.
They do not wear the robe.
They do not carry the lantern in public.
They use the language of cataloguers and librarians when they have to speak.

The player discovers the Listeners immediately (T002 onward)
and does not learn the Crossers exist until T004.
This asymmetry is deliberate
and must be preserved by all town writers:
a player who has not earned the second layer must not be shown it.

The line delivers, at T005, the player's hardest betrayal-choice in the game.
Archdepth Sula confesses that her Listeners mine relics for kings.
The Crossers expose the same truth to the player on the same night,
from the opposite side of the room.
Three doors open:
join the Listeners and wear the contract with full knowledge of its shame,
betray them to the Guild and accept what the Guild will do with the paper,
or vanish with the Crossers toward a road no one has walked in a hundred years.

## Soul figure(s)

- **Archdepth Sula of the Long Descent**
  Icon of the Listeners.
  First appearance T005 Mistmere, in the sunken ward beneath the old waterhouse.
  Half-mad.
  Half of that madness is a residue from forty years of listening at the bottom of holes —
  she has heard things no word in the northern tongue is shaped to carry,
  and the shape of those un-carried things has worn a groove into her mind.
  The other half of the madness is guilt:
  she has carried relics up for men whose crowns she is no longer sure she believes in,
  and she has done it long enough that she cannot stop without admitting what she did.
  Speaks slowly.
  Counts her breaths in a slow four-count even when silent.
  One clouded eye from a rockfall at thirty.
  Hands of a woman who has worked rope for forty years.

- **Navigator Kestrel** (Sub)
  Icon of the Crossers.
  First appearance T004 Jadehollow,
  working under librarian cover in the deep archive of the Consortium library.
  Calm, clean, dangerous.
  Does not wear the robe.
  Carries no lantern.
  Keeps a graph-ruled black notebook and a brass compass-rose with a sixteenth division.
  Speaks in the register of a cataloguer:
  shelf-numbers, folio-numbers, polite corrections.
  A player who has not earned his second register will never hear it.

- **Yannic "Yan" Vello** (Contact)
  Young Listener, age seventeen, T002 Windrest.
  Idealistic. Not a leader.
  His function is narrow:
  place a lantern in the player's hand,
  walk them to the edge of an initiation trial,
  and disappear south before the trial is complete.
  He is not seen again in the main line.
  He does not know his lantern is a Crosser forgery;
  he believes he is running a straight Listener errand for Sula.
  This ignorance is part of his honesty.

## Hook

- **Tier:** 2
- **Town:** T002 Windrest
- **Trigger scene:**

The player passes the relay house on the keep's lower road after sundown.
The lamps are being lit by a boy with a taper,
working from the northwest corner of the courtyard inward,
in a pattern that is not the keep's usual left-to-right.

A thin young man in a dark-grey oiled coat
is standing at the relay counter
trying to hand a wrapped parcel to a courier.
The courier looks at the parcel,
looks at the young man's soot-stained fingers,
and walks away without a word.

The young man does not call after him.
He turns, sees the player, and measures them with his eyes
the way a smith measures a length of iron before he decides what can be made from it.

He asks whether they are travelling north.

The parcel is a lantern.
He asks the player to carry it as far as the Grey Reach
and to hand it, unopened,
to a woman in the sunken ward of Mistmere
who "will know the shape of the glass."

He does not offer coin.
He offers, instead, three things:
a folded square of oiled silk,
a small tin of otter-fat for the lantern-wick,
and a slip of paper with one word written on it in a careful child's hand: *Sula*.

If the player accepts without question, Yannic watches them leave
and then goes back into the relay house.
If the player opens the parcel before leaving,
Yannic does not stop them.
He says only: "Then you will know what you carry."
That line is the line E key.
A player who opens the parcel receives the lantern-description in full;
a player who does not is told only that it is heavier than it looks.

## The lantern (physical prop specification)

The lantern Yannic gives the player is not generic. It must be rendered the same way by every town writer who describes it.

- **Body:** a squat cylinder of blackened tin, two hands tall, with a hinged cap and a looped carrying ring. The tin has been scorched dark not by accident but by slow heat, so that the surface does not reflect.
- **Glass:** a single panel of thick green glass on one face only. The other three faces are solid tin. This is a directional lantern: it throws light one way and hides it the rest. A Listener reads this as "the depth speaks to one ear."
- **Wick:** woven goat-hair rather than cotton. Cotton burns fast and bright; goat-hair burns slow, low, and does not sputter in wet air. The wick is soaked before being cut, so it begins its life heavy.
- **Oil:** rendered fat of the river-otter, mixed with pine-resin and a pinch of black powder drawn from a stone the Listeners call the *slow-stone*. The mixture burns cold-blue near the wick and yellow at the tip. It does not smoke. It does not go out in a rising draft. The Listeners say the slow-stone is a chip of the Chasm floor; a Crosser would say it is ground relic, and would be closer to right.
- **Mark:** on the underside of the base, stamped faintly, is a ring of nine small dots around a tenth. Listeners recognise this as the sign of Sula's cell. Crossers recognise the tenth dot as misplaced — off-centre — and would know the lantern is not Sula's work but a Crosser-forged duplicate.

Yannic does not know the tenth dot is off-centre.
He believes he is doing a Listener errand.
He is, in fact, carrying a Crosser probe north,
and the probe is the player.

### Lantern behaviours (for the orchestrator)

- In still air, the flame burns cold-blue for the first finger-width of the wick and yellow at the tip. The blue part does not warm the glass.
- In rising draft, the flame does not flicker. It leans toward the source of the draft and stays leaned. Listeners read this as the lantern listening.
- In the presence of a genuine colonial artefact — the un-hammerable metal lump (T002, line D), the colonist crest fragment (T005, line D), a sufficient quantity of the unaging-tea dregs (T004, line C) — the flame doubles in height for three heartbeats and returns to normal. Listeners call this *the greeting*.
- In the presence of the Crosser sketch at T004, the flame does nothing. The sketch is ink on linen, not relic. This null-result is itself informative to a careful player.
- The lantern cannot be relit from another flame. It must be lit from a spark struck on its own base-rim. This is a procedural rule, not a magical one; the slow-stone in the oil requires the base-rim's iron to kindle.
- The lantern extinguishes itself when laid on its side for more than the count of twenty. A Listener never lays one down.

## Rituals and procedures (science in ceremonial disguise)

Every Depth-Walker rite is a laboratory procedure with an incense-cloud wrapped around it.
Town writers describing any Depth-Walker scene must keep both halves legible at once:
a player who reads only the surface sees a cult;
a player who reads carefully sees a measurement.

### The four-count breath

Used before any descent, any audit of a lantern, any reading of a codex.
Count four in, four held, four out, four held.
The Listeners say it is to "match the rhythm of the earth's own lung."
It is, in fact, a stabiliser:
a slow controlled oxygenation before entering low-oxygen air.
Sula's near-constant use of it is not piety.
She has lost lung capacity after four decades in shafts
and needs the discipline to speak at length without faltering.

### The knotted rope

Every descent-rope is wool-wrapped at one-fathom intervals.
The wool is dyed in a four-colour cycle: undyed, red, black, undyed.
The Listeners call the colours *the year, the blood, the deep, the year.*
The practical function is that a descender feeling knots in the dark
can report their depth to the surface team by calling out the colour they have just passed.
A Listener who calls out the wrong colour is not corrected; they are pulled up.

### The silk square

A six-inch square of silk, oiled on one face.
Held over a shaft-mouth at the changing of the light — dawn and dusk.
The Listeners watch how it lifts and in which direction it turns.
The record is kept in the cell's codex as three notations: *time, lift, turn.*
What they are recording is barometric draft,
which tells them whether a shaft is connected to a larger cavity below
and whether that cavity is open to another shaft-mouth elsewhere.
This is the central Depth-Walker instrument.
Sula's cells have silk squares from every major shaft in the Reach,
twenty years of data,
and Kestrel has a copy.

### The codex with ruled columns

Every cell keeps one.
Three columns: *sound, pause, thing-heard-in-the-pause.*
Filled at each descent by the attending recorder.
A Listener's piety is measured by the precision of the third column;
a Listener's honesty is measured by how often the third column is left blank.
Sula's own codex, on her desk at T005,
has eighteen years of entries
and a third column that is blank for more than half of them.
This, in the Listeners' own ethics, is a mark of integrity.

### The slow-stone audit

Once a season, each cell weighs its remaining slow-stone
on the balance that lives in its stove-room.
The weight is recorded against the previous season's weight.
The Listeners say the slow-stone "gives of itself to the lantern."
What they are actually tracking
is the rate at which a relic-fragment depletes in ordinary use —
data that has commercial value to the royal courier
and technical value to Kestrel.
Sula has never stopped doing the audits
even though she no longer trusts the hand that collects the numbers.

### The initiation (sit-once)

Described in the T003 clue table.
The physical description: a dry shaft, sixty feet, hemp rope, one hour of dark.
The recorded purpose: to hear what one hears when one is alone with the earth.
The actual purpose: to distinguish,
by the player's own reported sounds,
whether they have a trained ear, an untrained ear, or a lying ear.
The old woman at the T003 cell marks each reported sound in one of three columns
and the player never sees which column received which mark.

### The dousing (three-hour descent)

On nights when a cell-master signals,
every Listener in every cell in the Reach douses their lantern at the third hour past dusk
and descends.
The signalling mechanism is never described in a player-facing text.
(For the orchestrator: it is the silk-square protocol run in reverse — a coordinated draft-reading
that each cell performs independently and confirms by comparison in the following week's courier.
The signal's origin is Sula, always.)
On the cloud-night (line D), Sula does not give a signal and the dousing happens anyway.
This is the event that makes her, for the first time in her life, afraid of her own order.

### The robe

Undyed grey wool, unlined, knee-length, with a single iron toggle at the throat.
The toggle is always the same weight — a half-ounce, measured.
The Listeners say the weight is "the weight of what is owed."
The practical function is that the toggle is the counter-weight
on the small balance they use for oil-weighing;
a Listener travelling to a cell without instruments can weigh oil against their own throat-iron
and get within a grain.
A player who accepts Sula's robe at T005 (door 1)
is given a toggle cast from the same iron as Sula's own.

## Clues by town

### T001 — Stoneford

Line E is not active in T001. Do not plant a hook here. But the line must be quietly pre-audible for a player who has already done B or A and returns to Stoneford.

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T001 | Septon Silas | passing remark | If asked about the Depth-Walkers: "A northern kingdom's foolishness. They climb down to find what the rest of us lost above." He says it with a tired smile. He does not know Sula personally but once wrote her a letter; he does not say so. |
| T001 | Ancient stone shard (in Silas's vestry) | cross-reference | The shard bears a glyph-ring that, if the player later sees the Crosser sketch at T004, will be recognised as sharing root-glyphs. The shard belongs to line B; line E only *depends* on it. No fragment is placed here for E. |
| T001 | Tavern drunk (unnamed) | overheard line | "The earth-men. They got a house in Windrest now. A boy with a lantern." This is the sole signal that a hook exists in T002. It must be delivered flat, without emphasis, as tavern noise. |
| T001 | Guild noticeboard | absence-clue | A bounty notice for "cellar-crawlers and unlicensed tunnellers" is posted fresh each week and taken down within a day. A careful player notes the pattern. The Guild (line A) is suppressing Depth-Walker activity on royal orders; this is a C↔E bleed the player will only decode at T005. |

### T002 — Windrest

Sprout. The player meets Yannic, receives the lantern, and learns the word *Listener*. Nothing about Crossers is available here.

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T002 | Yannic "Yan" Vello | hook-giver | New NPC. Seventeen, thin, tan-dark skin, hair cropped short. Wears a grey oiled coat over plain wool. Fingers stained with lamp-soot and resin. Sleeps in the loft above the relay house Old Zhao runs, though Old Zhao does not know he is a Listener and thinks he is a courier's apprentice. |
| T002 | Yannic | dialogue (first) | "I do not need it delivered fast. I need it delivered unopened. There is a woman in the Grey Reach, in the sunken ward. She will know the shape of the glass." |
| T002 | Yannic | dialogue (pressed) | "We do not look up. When a man says *the sky* we nod and walk on. What is below is older than the sky. Older than the far side anyone mutters of. That is all I will say on a keep road." |
| T002 | Yannic | dialogue (about the lantern) | "Goat-hair. Otter-fat. A pinch of slow-stone. Do not light it in a wind. Do not light it in a crowded room. If you must light it, face the glass at a wall and sit behind it. The light is not for you to see by. It is for whatever is on the other side of the wall to see you by." |
| T002 | Captain Yura Stoneshield | institutional suppression | If the player mentions Depth-Walkers to Yura, her face closes. "We do not name them in the keep. The Crown has been clear." She does not arrest the player. She writes something in a small book. The book is forwarded weekly to T005. This is the C↔E link surfacing early. |
| T002 | Old Zhao | information-for-sale | For fifty gold, Old Zhao says: "The boy with the soot hands is not from here. He came up from the south two winters ago with no papers and a lantern too well-made for a boy his age. I do not ask. He pays rent in copper, which is more than the relay clerk does." |
| T002 | Mei | innocent observation | Mei has seen Yannic at dawn oiling the same lantern for an hour at a time. She thinks it is beautiful. She does not know it is ritual. |
| T002 | Brown | irrelevant | Brown has no E connection. Do not invent one. |
| T002 | Kalran (blacksmith) | refusal-clue | If the player shows Kalran the lantern, he grunts once and will not work on it. "That is not smithing. That is measuring. Ask the earth-men." He does not elaborate. |
| T002 | Sky event | D↔E cross | On the night of the straight-line cloud (line D), if the player is in Windrest and has the lantern, the wick lights itself briefly — three heartbeats, cold-blue — and goes out. Yannic, if the player finds him afterward, is white in the face. "It answered. I did not think it would answer in a keep. You must go north faster." |
| T002 | Scene beat (optional) | night descent | If the player follows Yannic on the cloud-night, he leads them to a disused well behind the relay house, removes three stones, and descends. He does not invite the player down. He returns an hour later, damp to the chest, and says nothing. |

Yannic does not travel with the player. He leaves Windrest within two days of handing over the lantern and is not seen again in this line. Town writers for T003, T004, T005 must not bring Yannic back. If the player asks about him at T003, the answer is "the boy went south."

### T003 — Greyholt / the Monastery

Involvement, first half. The player begins to see that the Listeners are not an isolated cult.

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T003 | Monastery back-wall glyphs | cross-clue | The wall bears Eilin's "上下相通" (Above and below connect). The player has seen this by the time line E is active here. If the player presents the lantern while standing before the glyphs, the lantern's base-mark (the off-centre tenth dot) casts a shadow onto the wall that lines up with the glyph's central stroke. This is a B↔E visual gate. |
| T003 | Maester Eilin | mute-to-writing | Eilin cannot speak. She writes in chalk on a slate: "The lantern is not of the cell that claims it. The ring is untrue. Who gave it to you?" She is the first person in the line to flag the Crosser forgery. She does not explain it; she simply writes the word *untrue* and underlines it twice. |
| T003 | Preceptor Vossel the Younger | reluctant guide | Vossel knows a Depth-Walker cell meets in a cave three hours north of the monastery. He will not take the player himself. He will draw a map on the inside of a prayer-book cover if asked twice. |
| T003 | Listener cell (cave, unnamed cell-master) | initiation trial | The cell has no leader present; they are all on descent. A single old woman tends a low stove. She takes the lantern from the player without asking, weighs it in her hand, frowns at the base-mark, and says, "This is not Sula's. But it is bound for Sula. Someone has done her a discourtesy. Carry it anyway." She then conducts the initiation trial. |
| T003 | Initiation trial | scene beat | The player is lowered sixty feet on a hemp rope into a dry shaft, told to sit at the bottom in full dark for one hour, and to describe what they heard when they come up. There is no monster. There is no test of courage. The old woman simply records the player's answer in a codex with ruled columns — one column for sounds, one for pauses, one for "the thing heard in the pause." It is a **scientific log pretending to be a rite**. The player leaves with a small brass token stamped with a single dot and a crease across it. This token identifies them at any Listener cell as "one who has sat once." |
| T003 | Half-burned Northern Ban decree | cross-reference | In Archivist Naryn's cabinet (line A's fragment). The decree names the Depth-Walkers among the proscribed movements. A careful reader sees the proscription is signed by three crowns and unsigned by the fourth — the Free North abstained. This is a C↔E link. |
| T003 | Old woman at the cell | dialogue (parting) | "North of here, in Jadehollow, there is a librarian who will tell you the lantern is old. He is lying. Be careful of librarians. They have read more than is good for one life." This is the first whisper that a Crosser exists, and it is a warning framed as a gossip-line. |

### T004 — Jadehollow

Involvement, second half. The Crosser faction becomes visible, but only to a gated player.

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T004 | Consortium library, deep archive | fragment location | **Fragment: Crosser sketch "from below, we may rise."** A single folded sheet of greased linen, tucked behind the third shelf of the third alcove, between a colonial-era tide-table and a miner's Bible. The sketch shows a cross-section: the Chasm from above as a black line, and beneath it a network of arched tunnels rising from the near cliff, running under the mist, and surfacing on the far side. In the margin, in a neat unadorned hand: *from below, we may rise.* The sketch shares exactly three root-glyphs with the stone shard at T001 (line B) and with Eilin's monastery wall (line B): three along the sketch's lower border, two overlapping the shard, one on the Mistmere harbour-wall inner face. Town writer must mirror those glyphs exactly. A second hand has written beside the sketch *"or from above, if above returns"* — this is a Crosser response to the cloud, per Line D. |
| T004 | Navigator Kestrel | gated NPC | New NPC. Librarian cover. Thirty-eight. Clean-shaven, plain grey tunic, ink on the side of his right hand. Wears no amulet. Keeps a small black notebook with graph-ruled pages. He does not claim to be a Depth-Walker. He is listed in Kassa Deepvein's payroll as "junior cataloguer." He will not speak to a player who has not already either (a) read Eilin's monastery glyphs "上下相通," or (b) handled a genuine colonial artefact (the un-hammerable metal lump from T002, or the colonist crest fragment once shown to them at T005). **This gate is crucial. Town writers must enforce it.** A player who tries to address Kestrel without having passed one of the two gates receives only polite cataloguer-speech: shelf-numbers, apologies, a request that they lower their voice. |
| T004 | Kestrel | dialogue (first, post-gate) | "You have seen the glyph. Good. Walk with me to the back stair. I need to show you a map older than the Consortium's charter." |
| T004 | Kestrel | dialogue (theory) | "The kingdoms tell you the Chasm is the only road. They are wrong. The colonial road ran *under* the Chasm, not across it. It was buried when the collapse came, because to bury a road is faster than to defend one. What the Listeners call relics are milestones. What they call holy dirt is a road-bed. We do not need to fly. We need to dig, and to walk where the old walkers walked." |
| T004 | Kestrel | dialogue (about Sula) | "She was a miner before she was an archdepth. She has a contract in a drawer. The kings pay her in coin and in the right to wear the robe. She is not a fraud. She is a woman who has convinced herself that the contract is the price of the truth. It is not." |
| T004 | Kestrel | dialogue (about Eilin) | "I have her drawings. Every line she has made in the last fifteen years has come to me through a courier chain Vossel does not know he runs. I do not return them. She does not ask. She and I have an agreement made entirely in not-asking." This is the B↔E acknowledgement. |
| T004 | Kestrel | dialogue (about the lantern) | If the player shows the lantern: "The tenth dot is mine. I made this one. Yannic believed he was running a Listener errand. He was running a Crosser probe. You are the probe." He says this without apology. |
| T004 | Old Fane Crowseye | side-reading | If the player brings the lantern to Fane, his pale eye lights. "Two makers. A Listener cast it, a Crosser re-stamped it. I have not seen that in twenty years. Someone is testing a seam." |
| T004 | Unaging-tea dregs (Crown envoy's cup) | cross-reference | The envoy who left the cup was last in conference with a Listener courier. Jade, the tavern-keeper, remembers the pair. She will not say so unless the player has already met Kestrel. |
| T004 | Septon Silas | testament entry | One line in Silas's three-year testament, if recovered: "A woman called Sula writes to me once a winter. She asks whether the Faith considers a contract a vow. I have not yet answered her." This is the only hint in the game that Sula is not fully at peace with what she has signed. |
| T004 | Kestrel | departure | Kestrel does not leave Jadehollow with the player. He says: "I will meet you in the sunken ward at Mistmere, on the night she confesses. You will know it is the night because the lanterns in every Depth-Walker cell in the Reach will go out at the same hour. Do not ask how I will know. Ask how *she* will know." |

### T005 — Mistmere

Critical. Sula and Kestrel both present. Three doors.

| Town | Carrier | Type | Content |
|------|---------|------|---------|
| T005 | Archdepth Sula of the Long Descent | soul figure | New NPC. Sixty-one. Hair shaved at the temples and long at the crown, bound with a grey ribbon. Skin the colour of tallow. Left eye clouded; she lost it to a rockfall at thirty and has never replaced the covering. Wears the Depth-Walker's plain grey robe over miner's leathers. Her hands are the hands of someone who has worked forty years with rope. She breathes in a slow four-count even when speaking. |
| T005 | Location | the sunken ward | Beneath the old waterhouse at Mistmere's lower terrace, there is a ward that was a cistern before the city rose around it. Sula lives and works there. Six other Listeners attend her. The ward has a descent-shaft in its centre, sealed by a slab that takes three people to move. |
| T005 | Fragment location | **Fragment: Listener contract parchment.** On Sula's desk, weighted by a piece of the slow-stone. A single folded sheet of heavy cream vellum. Language: the formal northern hand. Signatories: two — Sula (a simple cross) and, on the royal side, a wax seal only, no name. The seal is a three-crown seal; the fourth crown is absent. Clauses, brief: (1) the Archdepth's cells will deliver all artefacts of foreign casting discovered below to a named courier monthly; (2) the crowns will suppress public inquiry into Depth-Walker practice and shall not prosecute their members for unlicensed descent; (3) the contract is void on the death of the Archdepth. The parchment is seven years old. The edge is soot-stained where Sula has held a candle near it, considering burning it, and has not. This contract is not the Northern Ban. It is the Listener bond that the Ban permits. The Free North has never signed a Listener bond; Brenna's predecessors refused, Brenna continues to refuse, and her silence is legible on the wax. |
| T005 | Sula | dialogue (first) | "You carry a lantern that is mine and not mine. Sit. Breathe four. When you are ready, hand it to me." She takes it, turns it over, sees the off-centre tenth dot, and does not react visibly. The four-count breath does not change. |
| T005 | Sula | dialogue (confession, scripted beat) | "I signed a paper. I did not sign it for money, though money came. I signed it because the kings would have sent soldiers into our shafts, and soldiers break instruments a listener cannot replace. I signed so that we could keep descending. I was not wrong to sign. I have not yet forgiven myself for being not-wrong. Do you understand that distinction." (She does not pose it as a question.) |
| T005 | Sula | dialogue (theory) | "Below and beyond are not the same thing. That is Hallen talking, and Hallen came back with a cracked head. But below has more roads than the maps above will ever draw. That is what we listen for. The crowns think we listen for gold. We listen for the shape of a corridor that is not on any plan." |
| T005 | Hallen the mad returnee | dialogue (NPC, in the ward's sick-cell) | New NPC. Sixty. Hair white in patches, one shoulder permanently lowered. Came back from a six-month descent ten years ago and has not been wholly in one room since. Speaks in fragments. |
| T005 | Hallen | canonical line | "Below and beyond are one. The floor is the far wall." He says this and then laughs a laugh that is not cruel, only tired. This is the Theory-3 canon delivery. |
| T005 | Hallen | expansion | "I walked down until the lantern failed. Then I walked more. The wall I met was not a wall. It was a floor I had stood on from the other side. I turned around and the way up was the way down. The listeners write this in their codices and call it a hallucination. I call it a geometry I do not have the teeth to chew." |
| T005 | Navigator Kestrel | arrival | Kestrel enters the sunken ward on the night of the confession, without knocking. The six attending Listeners rise. Sula raises a hand and they sit. She and Kestrel do not embrace. They have not spoken in eleven years. Kestrel sets a second lantern on the desk beside the parchment. This lantern has ten dots in a true ring — no off-centre mark. "I brought you yours back," he says. "Corrected." |
| T005 | Kestrel (in Sula's presence) | dialogue | "The probe returned. The seam holds. The road is real. We do not need the kings and we no longer need the descent to be a vow. We need diggers who understand they are digging a road and not worshipping a hole." |
| T005 | Sula | dialogue (rebuttal) | "You were always a man who forgot that a rite is how a frightened people learn to measure. Take the road. Leave us the measurements." |
| T005 | Player scene beat | the three doors | The player has, at this moment, the full picture: contract on the desk, sketch in their satchel, Sula on one side, Kestrel on the other, Hallen in the sick-cell humming. The choice is framed without speech. Sula extends a hand palm-up: *join us, take the robe, wear the contract with us.* Kestrel inclines his head toward the ward-door: *come with me, leave by the back stair, we go tonight.* On the desk, visible to all three, is the parchment: the third option is to take it out of the ward to the Guild at Stoneford (line A). No one says anything while the player decides. Sula counts four. Kestrel does not count. |
| T005 | Sky event | D↔E cross | On this same night, if the line D timing is held, every Depth-Walker cell in the Reach douses its lantern at the third hour past dusk and descends. The waterhouse is dark. The shaft is open. The city above does not notice. Sula hears it and says: "The calling from below is answering itself." Kestrel hears the same silence and says: "The other side sent a scout. The road is proven." Hallen says: "It is the same sentence." |
| T005 | Fourth-crown absence | C↔E cross | A perceptive player, examining the contract's seal, notices that the Free North's crown is not on the wax. Chieftess Brenna Greyhold (line C) did not sign. A player who later raises this with Brenna gains a C-line lever. Writers on line C should expect this hand-off. |
| T005 | Bishop Reynard | external pressure | Reynard knows Sula exists. He has not moved against her because she delivers, through the contract, a flow of "foreign castings" the Faith quietly examines. If the player betrays the Listeners to the Guild, the Faith learns within a day and Reynard's calculus changes. (Hand-off to line C.) |
| T005 | Lady Vera Ashford-Blackwater | oblique interest | Vera has purchased, through a shell, the deed to the old waterhouse. She has not acted on it. If the Listeners dissolve (player chooses the Guild door), the ward becomes hers within the month and she demolishes it. |

## Stage endpoints

### Sprout end (T002)

The player has the lantern.
They know the word *Listener*.
They have been warned not to open the parcel.
They have either opened it or not.
Either way, they carry it north.
They have, if the cloud-night has already occurred, seen the wick light itself for three heartbeats
and they carry that image whether or not they have language for it.
Yannic is gone south and will not be seen again in this line.

### Involvement end (T004)

The player has met Kestrel — gated, earned, not accidental.
They have the Crosser sketch in their inventory, folded back into its oiled linen.
They know the lantern they carry is a Crosser forgery of a Listener design,
and they know the forgery was deliberate.
They know — because Kestrel has told them plainly —
that the meeting-night at Mistmere will be signalled
by a simultaneous dousing of every cell's lantern in the Reach.
They do not yet know that the contract is on Sula's desk,
but they know there is a contract.
They have, if they have also followed line B, recognised the root-glyphs
shared between the sketch, the shard, and the monastery wall.
A player who has not recognised them will still pass through T005;
the ending does not require the recognition,
but the recognition changes the weight of what Sula and Kestrel each say.

### Critical decision at T005

The scene:
the sunken ward under the old waterhouse,
the central shaft sealed,
six attending Listeners seated on wooden stools along the wall,
Sula at her desk with the contract parchment and the slow-stone,
Hallen in the sick-cell behind a grey curtain, humming a four-note pattern that is not a tune,
Kestrel standing at the ward-door with a corrected lantern in his left hand and nothing in his right.

The player has the full picture:
contract on the desk,
sketch in their satchel,
Sula on one side,
Kestrel on the other,
Hallen behind the curtain.

The choice is framed without speech.
Sula extends a hand palm-up: *join us, take the robe, wear the contract with us.*
Kestrel inclines his head toward the ward-door: *come with me, leave by the back stair, we go tonight.*
On the desk, visible to all three, is the parchment:
the third option is to take it out of the ward and south to the Guild at Stoneford (line A).

No one speaks while the player decides.
Sula counts four.
Kestrel does not count.
Hallen's humming does not change.

The three doors:

**Door 1 — Join the Listeners.**
The player sits on the empty stool beside Sula.
They take the four-count.
The robe is placed across their shoulders by the oldest of the attending Listeners.
The iron toggle is cast for them within the week from the same bar that cast Sula's own.
The lantern is opened on the desk, re-stamped with a true ten-dot ring
by a small punch Sula keeps in the drawer with the contract,
and returned to the player.
The player is written into the contract as an unnamed witness on a back page.
The Crossers consider the player lost.
Kestrel leaves the ward that night through the back stair
and does not contact the player again in the current game.
Long-term consequences:
the player gains access to Listener cells across all five towns,
a standing stipend paid in copper every half-season,
and the slow accumulation of knowledge of what is actually in the shafts.
They will never again be welcome in the Guild branch at Stoneford;
the Guild has rules about contracted parties and this is one of them.

**Door 2 — Betray to the Guild.**
The player lifts the parchment from Sula's desk.
Sula does not stop them.
Kestrel does not stop them.
Neither will take the parchment back if the player hesitates and offers it.
The attending Listeners stand but do not move;
Sula gestures them down with the hand that was palm-up a moment before.
The player carries the parchment south
to Magister Corvin Ashford-Reed at T005 (Guild soul figure, line A)
or to the Guild branch at T001.
The Guild uses it to force the three signing crowns to renegotiate the Northern Ban.
The Depth-Walkers are formally outlawed within the season.
Sula is arrested in the ward six days later;
she does not resist; she asks to carry her codex with her and is refused.
Kestrel vanishes.
The Crossers are driven further underground
and are no longer reachable in the current game.
The sunken ward is demolished within the month;
Lady Vera Ashford-Blackwater receives the cleared ground through a shell purchase.
The player is paid in Guild standing.
They are not paid in sleep.

**Door 3 — Go with the Crossers.**
The player leaves by the back stair with Kestrel, that night, in the dark.
The Crossers' engineering cell moves north immediately,
by a relay of three safehouses
(one in a hayloft outside T004, one in a goatherd's hut above T003, one in a fisher's boathouse on the Reach).
Within three days, the player is shown the mouth of the old colonial road:
a stone arch set into the Chasm's near cliff four hundred feet below the rim,
reached by a descent-rope the Crossers have been maintaining for nine years,
sealed with a slab bearing the same ring-mark as the lantern —
ten true dots in a ring,
carved into stone at a scale the hand of one man could not have done alone.
The game, in v0.1, ends at the slab.
The Crossers say: *not yet. You have seen it. Come back when you have the tools.*
The player gains the Crosser sketch as a permanent item,
a Crosser cipher-key in a separate folded sheet,
and access to Crosser safehouses in T003 and T004 for any future session.
They do not gain the ability to cross the Chasm.
They gain the knowledge that crossing is, in principle, a matter of work.

All three doors are narratively complete.
None is coded as the correct choice.
The world-agent must refuse to rank them.
If the player asks an NPC, after the fact, whether they chose well,
the NPC must answer in character and may judge —
Septa Malen will condemn door 3, Brenna will privately approve door 3,
Corvin will reward door 2 and never invite the player to dinner,
Sula, if still alive, will say only: *you chose. that is a thing to have done.*

## Cross-line interactions

### B ↔ E (primary)

Line E depends on line B's *ancient stone shard* (T001, Septon Silas)
and line B's *monastery wall glyphs "上下相通"* (T003, Eilin).

The Crosser sketch at T004 shares at least three root-glyphs with both.
The sketch, the shard, and the wall are in effect three witnesses of a single older hand.

Line E's Navigator Kestrel holds Eilin's drawings in the T004 deep archive;
line B's writer should acknowledge this by having Eilin write, in chalk,
*"he keeps them"* if the player asks about her lost sketches.

The monastery-glyph player-gate at T004
(Kestrel refuses to speak without either the glyph-reading or a colonial artefact in hand)
is the central B↔E hand-off and must not be weakened.

### B ↔ E (secondary)

If the player shows the lantern in Eilin's presence before T004,
Eilin writes *"the ring is untrue"* on her slate.
This is the earliest possible warning that the lantern is a Crosser forgery.
Line B's writer must honour this exact phrasing.
Eilin does not know the Crossers by name.
She knows only that the lantern's ring is not the ring she has seen Sula's couriers carry.
This is enough to flag the forgery without betraying Kestrel to the player.

### C ↔ E

Line E depends on line C's suppression policy.
Only the Crown, Faith, and Union crowns signed the Northern Ban
that proscribes the Depth-Walkers;
the Free North abstained.

Chieftess Brenna Greyhold (line C) secretly tolerates Listener cells in her holds
because her own memory of the colonial past aligns with Kestrel's theory,
though she has never met him.
She has never spoken the word *Crosser*.
She does not know the splinter exists by that name.

Line C writers must leave a seam at Brenna's court
for a player who arrives with knowledge of the unsigned fourth crown.
A player who has read the T005 parchment and notes the absent seal
may confront Brenna, and Brenna may, if pressed in private, not deny it.

The Faith side of line C — High Septa Malen — does not know about the contract at all.
She believes the suppression is doctrinal.
A player who shows her the parchment collapses her entire cosmology in one minute;
line C's writer owns the fallout.

### C ↔ E (Crown envoy)

The unaging-tea dregs fragment at T004 (line C)
was left in Jadehollow by a Crown envoy who was meeting a Listener courier.
The meeting's purpose, on the Listener side,
was the monthly hand-off of foreign castings promised by Sula's contract.
The meeting's purpose, on the envoy's side,
was to confirm that the Crown's payment had cleared.
Jade the tavern-keeper remembers the pair
and will describe them to a player who has met Kestrel
and no one else.

### D ↔ E

The night the straight-line cloud crosses the sky over the Reach (line D's sprout event),
every Depth-Walker cell douses its lantern and descends at the third hour past dusk.

Line D's *Veyl "the Line"* at T005 reads this event differently again —
he believes the cloud is a reconnaissance of the kind he remembers from the oldest songs,
and he takes the dousing, if he learns of it, as proof that the earth-men also recognised it.

Line E's Sula reads the dousing as *the calling from below answering itself.*
Line E's Kestrel reads the dousing as *the other side sent a scout.*
Line E's Hallen reads the dousing as *it is the same sentence.*

All three readings are canon-as-opinion.
None is confirmed.

Line D's writer must place the cloud-event before line E's T005 confession
and must not write the descent as public knowledge.
Any townsman of T005 asked about the dousing must say: *what dousing.*

### D ↔ E (Old Bram cross)

Old Shepherd Bram at T004 (line D sub) has seen Listener couriers twice in his life,
both times crossing his high pasture at dusk with unlit lanterns.
He does not know who they are.
If asked, he says: *grey-coated folk. The earth-men, maybe. I do not trouble them and they do not trouble me.*
This is the only line-D surface that acknowledges the Listeners at all,
and it must stay at that exact level.

### A ↔ E

Line E's *betrayal door* (door 2) hands the contract parchment to the Guild.
Line A's Magister Corvin Ashford-Reed must have a written handler for this:
when presented with the parchment,
he does not thank the player,
and he does not pay them at the counter —
he pays them by a sealed letter to the Stoneford branch,
delivered by a courier who does not speak the player's name aloud.
Line A's writer owns this handler;
line E only delivers the parchment.

### A ↔ E (suppression)

Line A's Guild posts weekly bounty-notices against "cellar-crawlers and unlicensed tunnellers."
These notices are taken down within a day.
They are posted by the Guild branch at Stoneford
under quiet contract with the northern Crown.
The contract itself is not visible to the player in line A or line E.
A careful reader notices the pattern and may ask Corvin about it;
Corvin will not answer.

### E-internal (Listener ↔ Crosser)

Nine years ago, Kestrel was Sula's second-best rope.
He left the night she brought the first contract back from the Crown courier
and would not show it to him.
He took two cells with him — one in Jadehollow, one in a village above the Reach
that is not on the player's map.
He has not seen Sula since, in person, until the confession night at T005.
They have exchanged letters twice in nine years,
both times by a courier neither of them trusted,
both times about a single technical question.
Neither of those letters is recoverable in v0.1.
The world-agent must not invent their content.

## Write-in checklist for town writers

- **T001 / npcs:** add to Septon Silas one passing dialogue option about the Depth-Walkers ("A northern kingdom's foolishness…"). Do NOT give him a Listener secret; he is not one. Add an unnamed tavern-drunk line: *"The earth-men. They got a house in Windrest now. A boy with a lantern."* Add the Guild noticeboard's weekly cellar-crawler bounty (appears and is torn down within a day).
- **T002 / npcs:** add **new NPC Yannic "Yan" Vello**, age 17, Listener contact, located at the relay house loft. State: not met. Add his three scripted dialogues (hand-off, pressed, lantern-instructions). Flag him as leaves-town-after-handoff; he does not return in this line.
- **T002 / npcs:** add to Captain Yura Stoneshield one reaction when Depth-Walkers are named ("We do not name them in the keep"); note that she writes such mentions in a small book forwarded weekly to T005.
- **T002 / npcs:** add to Old Zhao a 50-gold intelligence line about "the boy with the soot hands."
- **T002 / npcs:** add to Kalran the refusal-clue when shown the lantern ("That is not smithing. That is measuring.").
- **T002 / items:** add the lantern specification (body, glass, wick, oil, mark) as a physical inventory item with the off-centre tenth dot. This is the line-E signature prop.
- **T002 / events:** add the cloud-night wick-ignition event, cross-referenced to line D.
- **T003 / facilities:** ensure the monastery back wall glyphs "上下相通" are written in (this belongs to line B; line E depends on them). Add the visual gate: when the E-lantern is presented before the wall, its base-mark shadow aligns with the central stroke of the glyph.
- **T003 / npcs:** add to Maester Eilin a chalk-slate response when shown the lantern: *"The lantern is not of the cell that claims it. The ring is untrue. Who gave it to you?"*
- **T003 / npcs:** add to Preceptor Vossel the Younger the map-on-prayer-book-cover option.
- **T003 / npcs:** add the **unnamed old woman** at the Listener cell (cave, three hours north). She is not named in this line on purpose. Add the initiation-trial scene beat (sixty-foot rope, one hour of dark, recorded in a codex with ruled columns). Add the brass one-dot-with-crease token as an inventory item identifying the player as *one who has sat once*.
- **T003 / npcs (old woman parting):** add the warning about "a librarian in Jadehollow who will tell you the lantern is old; he is lying."
- **T004 / facilities:** add to the Consortium library deep archive the **fragment Crosser sketch "from below, we may rise,"** located behind the third shelf of the third alcove. Mirror the root-glyphs with the T001 shard and the T003 wall.
- **T004 / npcs:** add **new NPC Navigator Kestrel**, age 38, librarian cover, Crosser soul figure. State: not met. Enforce the player-gate: Kestrel will not speak to a player who has not read the monastery glyphs OR handled a genuine colonial artefact. Add his four scripted dialogues (theory, Sula, Eilin, lantern).
- **T004 / npcs:** add to Old Fane Crowseye the two-makers reading when shown the lantern ("A Listener cast it, a Crosser re-stamped it").
- **T004 / npcs:** add to Jade the tavern-keeper a memory of the Crown envoy meeting a Listener courier (gated on having met Kestrel).
- **T004 / npcs:** add to Septon Silas's three-year testament one line about Sula's annual letter.
- **T005 / npcs:** add **new NPC Archdepth Sula of the Long Descent**, age 61, Listener soul figure, sunken ward under the old waterhouse. State: not met. Add her four-count breath, the confession scene, the theory line.
- **T005 / npcs:** add **new NPC Hallen the mad returnee**, age 60, sick-cell of the sunken ward. State: not met. Add the canonical theory line *"Below and beyond are one. The floor is the far wall."* plus the geometry expansion.
- **T005 / npcs:** flag Navigator Kestrel for a second appearance at T005 on the confession night; he is already placed at T004.
- **T005 / facilities:** add the sunken ward beneath the old waterhouse, with a central descent-shaft sealed by a three-person slab. Add six unnamed attending Listeners.
- **T005 / items:** add the **fragment Listener contract parchment** on Sula's desk, weighted by a chip of slow-stone. Specify the two signatures (Sula's cross, three-crown wax seal, Free North absent), the three clauses, and the seven-year age.
- **T005 / events:** add the simultaneous lantern-dousing at the third hour past dusk on cloud-night (cross-reference to line D). Write it as a silence, not as a public event.
- **T005 / scenes:** add the three-doors scene in the sunken ward, scripted as a silent choice: Sula's palm-up, Kestrel's inclined head, the contract on the desk. The world-agent must not narrate the choice as weighted.
- **T005 / hand-offs:** leave a seam in line A (Magister Corvin) for the player who delivers the parchment; leave a seam in line C (Brenna) for the player who asks about the fourth crown; leave a seam in line D (Veyl) for the player who witnessed the cloud-night dousing.
- **All towns / suppression:** no NPC outside the Depth-Walkers speaks the word *Crosser*. That word is earned at T004 and never before. Writers must police their own dialogue for leaks.
- **All towns / no modern vocabulary:** Kestrel's "road under the Chasm" is a road, not a tunnel-system; the lantern oil is rendered fat, not fuel; the slow-stone is a stone, not a mineral; the sketch is a sketch, not a map. Hold the indigenous register.
- **All towns / Yannic does not return:** after T002, Yannic is gone south. Do not write him into T003, T004, or T005. This is a deliberate structural absence.

## New NPCs introduced by this line

The following NPCs are first introduced in this file and do not exist in any prior town roster.
Town writers must add them when wiring in the T00x hand-offs.

- **Yannic "Yan" Vello** — T002, contact, age 17, Listener. Flagged *state.met = false*.
- **Navigator Kestrel** — T004, Crosser soul figure, age 38, librarian cover under Kassa Deepvein's payroll as "junior cataloguer." Flagged *state.met = false*. Gated.
- **Unnamed old Listener at the T003 cave cell** — deliberately unnamed. Does not require a state flag; she is not persistent across sessions beyond her single scene.
- **Archdepth Sula of the Long Descent** — T005, Listener soul figure, age 61. Flagged *state.met = false*.
- **Hallen the mad returnee** — T005, sick-cell of the sunken ward, age 60. Flagged *state.met = false*.
- **Six attending Listeners at the T005 ward** — unnamed, collective. No flags.

## Organisation of the Listeners (reference map)

The Listeners are organised into *cells*, not chapters or lodges.
Each cell is a single shaft with a single stove-room and a codex.
A cell has between four and twelve members.
A cell has one master, called a *recorder* rather than a master,
whose function is to keep the codex and to sign the silk-square log.
Sula is the recorder of the T005 ward-cell
and, by seniority alone, the Archdepth —
*archdepth* is not a rank of authority but a rank of depth-reached.
Sula has been, by her own codex, deeper than any other living Listener,
and by four different shafts.

Known cells at game-start:
- **Windrest loft-cell** — above Old Zhao's relay house. Four members. Yannic is the youngest.
- **Greyholt cave-cell** — three hours north of the monastery. Seven members. Recorder is the old woman who runs the initiation.
- **Jadehollow pit-cell** — in a mine-shaft the Consortium abandoned nine years ago and assumes is collapsed. Six members. Recorder is known only as *Ten-Fingers*, a woman who lost none.
- **Mistmere ward-cell** — the sunken ward. Seven members including Sula. Recorder is Sula.
- **Upland cell (off-map)** — above the Reach, in a village the player cannot reach in v0.1. Eleven members. Recorder unknown to the other cells.

The Crossers have no cell structure.
They have three safehouses and one engineering site.
The engineering site is the old colonial road-mouth in the Chasm's near cliff.
Kestrel is not a recorder and not a master.
He is called *navigator* because he was the first to locate the road-mouth and match it to the sketch.

## Orchestrator notes

- The word *Crosser* is earned, not given. No NPC outside the faction speaks it before T004 Kestrel. If the player says it aloud at T001–T003, NPCs react as though the player has used a nonsense-word. Sula, at T005, hears it with a slow nod and does not correct the player's use of it.
- The word *Listener* is freely available from T002 onward.
- The Chinese-script glyphs "上下相通" appear once in this file in the T003 section as a cross-reference. They are line B's property. Line E's writer does not introduce any new glyphs; any glyph appearing in E is owned by B and mirrored only.
- Hallen's theory ("Below and beyond are one. The floor is the far wall.") is delivered at T005 and nowhere else. A player who does not visit the sick-cell does not receive this theory. That is intended.
- Kestrel's theory ("Colonial-era transit ran underground, not across.") is delivered at T004 and nowhere else. A player who does not pass the Kestrel gate never hears this theory. That is intended.
- The other two underground-relic theories (King's Archivist, Eilin) belong to lines C and B respectively. They are referenced in this file only as cross-links. Line E does not re-write them.
- The hidden premise is never stated in this file and must never be stated in any player-facing text generated from it. The far side remains indigenous-sensory only.
- If the player asks, at any point, whether the far side is real, the Depth-Walker answer is: *the far side is a question above. We are below.* This refuses without denying.

## Gaps requiring sibling input

- **Line C / Brenna:** confirm the absent fourth seal on the T005 contract is consistent with the line C framing of Brenna's private tolerance. If line C has already written the Ban as unanimous, this must be reconciled.
- **Line D / cloud timing:** confirm that line D's cloud-night occurs before line E's T005 confession in the intended session arc. If line D places the cloud-night after T005, the D↔E dousing event must be rewritten.
- **Line A / Corvin handler:** line A must supply the sealed-letter payment handler for door 2. Line E only writes the delivery.
- **Line B / Eilin chalk-lines:** confirm Eilin's slate can carry the two required phrases (*"he keeps them"*, *"the ring is untrue"*). If line B has assigned Eilin a different slate register, adjust phrasing in consultation.
- **Line D / Bram's pasture sighting:** line D's Bram may or may not already have a Listener-sighting line. If not, line D must add it; line E cannot add to a line D NPC without coordination.

End of Line E brief.
