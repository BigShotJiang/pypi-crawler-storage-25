# 主线 B：Fog 之前的世界（The World Before the Fog）

> 源文件：../B-world-before-the-fog.md  · 译文仅供审阅，以英文原版为准

## Function / 功能

B 线是 Stoneford 循环的"时间之深"的脊柱。其他线问"如今谁在治"或"今夜 fog 中有何物在走"，而此线问"在这一切之前，什么立于此地"。玩家离开 T005 时，应再也无法望着一堵墙、一道门框或一枚里程碑，而不去想这块石头原本是别的什么。

工作是考古的、语言学的、建筑学的。它不通过战役与背叛推进，而是通过字符的拓片、行囊里石片的分量、一位沉默女子以手掌塑形于空气。它从不命名彼岸。它从不解释隐藏前提。它只让证据累积，直到玩家自己脚下的地理变得可疑。

到 Critical 节拍时，Mistmere 不再是一座坐在 Shale 之上的行省都。它是一座新城坐落于一座更老的城之上，而玩家已在它的后巷走过足够远，感觉到了那处接缝。

## Soul figure(s) / 灵魂角色

- **Maester Eilin of the Broken Tongue** —— T003（Wolfsjaw / Silent Order 的悬崖修道院）的修道院学者。十一年前她的论文草稿 *On the Kinship of Great Cliff and Great Chasm*（论大崖与大沟的亲缘）出现在 Crown 藏书室之后，她的舌奉王命被割。该文论证旧语残片中 *cliff*（崖）与 *chasm*（沟）同出一根，并以 **上下相通**（*above and below connect*）作结。她今只以手势、书写字符与墨画沟通。首次出场：T003 修道院抄写室。
- **副灵魂：Preceptor Vossel the Younger** —— 驻 T002、常年在路上的 Faith 巡回抄写员。三冬之前他以初学修士身份抵达修道院，开始秘密把 Eilin 的手势誊入一本私人 codex。他把此 codex 的一部分藏在一本空心圣咏集内。他是那座桥：把 Eilin 的思想从修道院运出而不带她的印。首次出场：T002 小堂。

## Hook

**Tier 1 · T001 Stoneford · Shale Lantern 之后的 Faith 小堂。**

Septon Silas —— 正是 Stoneford 的传言所说"每三夜独自走向矿口"的那位 Septon —— 并非出生自 Jadehollow。他的初学之期是在 Wolfsjaw 修道院、Eilin 门下度过的。三季之前，他在 Stoneford 北的老矿道上行走时，在渡口翻起一块扁石，发现下面压着一片**不大于手掌的深灰石**，一面刻有文字，他与 Faith 所有弟兄皆不识。

他此后一直把它藏在法袍内衬里。他不肯带去 Mistmere 给自己的主教——他知道 Reynard 如何处理不便之物。他一直在等一个既非 Faith、也非 Guild、也非 Crown 的人把它北送给 Eilin —— 他在信里仍称她 *Maester*，明知她无法回信。

石片是 hook。Silas 是递出它的那只手。

## Clues by town / 各城线索

### T001 —— Stoneford

| 载体 | 类型 | 内容 |
|------|------|------|
| Septon Silas（自 T004 来访）| NPC 对话 & 物品转交 | Silas 正逢传言所说的"第三夜走访"进入 Stoneford。晚祷之后，在小堂，他取出**石片**。他不肯在白日、在酒馆、在 Old Reed 耳中交出。他把它的分量形容为 *warmer than stone has any business being*（比石头应当温度更温）。他请玩家把它带给 *the Maester of the Silent Order at Wolfsjaw*（Wolfsjaw Silent Order 的 Maester）。拒收酬金。会给出一封以 Faith 旧体书写的封缄介绍信。|
| 石片 | 物品掉落 | 手掌大小，深灰色，一面刻十七枚字符、三行。其中两枚字符的下笔与玩家日后或会见到的铁龙残片 **永生 × 黄金 × 无穷** 中的字共享（T002/T004 吟唱诵文）。石片冷手，但沿字符线温约半度。不发光。不鸣响。它只是"错"——手先于眼察觉到这"错"。|
| Old Reed | NPC 台词（sprout）| 若问他 Silas 找到石片的渡口：*"Ford-stone? Aye. My grandfather said a man once pulled a square stone out of the river — cleaner-cut than any mason in the Reach could manage. Threw it back. Said it belonged to the river."*（渡石？嗯。我祖父说，有一次有人从河里捞出一块方石——比整个 Reach 的任何石匠切得都干净。他把它扔回去了，说它属于河。）他不肯再被拉下去。他换话题说鱼。|
| Mira Ashford | NPC 台词（sprout）| 若玩家出示石片——切勿：*"My husband came back with something like that in his pocket. I buried it with what was left of him. Don't bring it in here again."*（我丈夫口袋里也带回过这种东西。我把它和他剩下的那一点一起埋了。别再把它带到这儿来。）这是止步之示，非解释。Eilin 日后会印证：渡口是更长之物的*浅端*。|
| Heron Blackwater | NPC 台词（sprout）| Heron 认出石片*被 Guild 标注*。他不说 *Northern Ban* 四字。他说：*"Take it north, and take it by back roads. The Guild has posted men at every keep road this season for trinkets like that."*（向北走，要走小路。Guild 这季在每条要道口都布了人，就为这样的小物。）此为本线对 A 线的首次递交——见 Cross-line。|
| 小堂墙面 | 场景节拍 | 小堂后门之上，两块地砖之间灰泥裂开，底石上露半枚字符。非 Faith 体。与石片同手。Silas 未指出，尽管十年来每日他在此下跪。玩家可自行察觉。orchestrator 不可确认。|
| 河石 | 场景节拍（可选；回访）| 玩家在 T003 见过 Wolfsjaw 字符之后再过 Stoneford，渡口河床里那些"加工过的石"变得可读为*切石*，非天然。河床是一片被二百年淤泥盖住的砌工。无 NPC 提及。对渡口的描述发生变化。|

**Sprout end（T001）：** 玩家接过石片与 Silas 之信，携之向 T002。

---

### T002 —— Windrest

| 载体 | 类型 | 内容 |
|------|------|------|
| Preceptor Vossel the Younger | NPC 对话 | 玩家抵达时 Vossel 正在 Windrest 的 Faith 小堂。年轻，瘦，袖口墨渍。一眼认出 Silas 的印。他会轻声问玩家是否*摸过一块本不该有的温度的石头*。若是，他邀玩家入后室，打开他的**空心圣咏集**。|
| 空心圣咏集 | 物品（示，不给）| 书脊处藏十二张折叠页的 codex。每页一画 —— Eilin 手里的"词之手势"，以墨呈现。每个手势之下有 Vossel 的小楷注释。其中三个手势对应玩家石片上的字符。Vossel 请玩家不要说破 —— 他宁可从玩家的反应里自己推断。|
| Vossel 台词 | NPC 对话 | *"She draws before she signs. Every word is first a picture. She says — she gestures — that the old-tongue was built the same way. Picture before sound. The stone you carry was cut by a hand that thought the way she thinks."*（她先画，后打手势。每一个词先是一幅画。她——打手势说——旧语也是这样造的。画先于声。你手里的石头，是由一只与她思维方式相同的手所切。）|
| Vossel 台词（论王家禁令）| NPC 对话 | *"I was not there when they took her tongue. I was still a novice. I was told she had misnamed the Chasm — called it by the name of a cliff. I did not understand why that was worth a knife. I am beginning to."*（他们取她舌的时候我不在场。我还是初学者。他们告诉我她把 Chasm 错命名了 —— 以崖之名名之。我不理解这何值一刀。我开始理解了。）种下 A↔B 的依赖。|
| Captain Yura Stoneshield | NPC 台词（若问及 Vossel）| *"The boy writes more than he prays. Linden's scouts flagged him twice. I struck their reports. He's no danger."*（那小子写得比祷告多。Linden 的斥候两次标注他。我把报告划掉了。他不是威胁。）她知道 Vossel 在抄什么东西。她不知道是什么。|
| Kalran the smith | NPC 台词（若出示石片）| Kalran 用仅剩的那只手握住石片。长长一息之后归还。*"Not a smith's work. Not any smith I know. Whoever cut that didn't strike the stone. They wore it down."*（不是铁匠的活。不是我认得的任何铁匠。切此者不曾击石。他们把它磨了下去。）不细说。不收钱。|
| 直线云 | 场景节拍（与 D 线共享）| T001 与 T002 之间的路上，黄昏时有一条直线云横贯天空。若玩家携石片，云过之际石片可察觉地变温。无 NPC 佐证。Old Zhao 若日后受贿：*"The cloud's been seen three times this year. Each time, something old moves."*（这云今年已见三次。每次，有旧物动。）五十金，不详谈。|
| Windrest Keep 地基石 | 场景节拍 | 下厅挂毯之后，一块地基石的切割与其年代不符。贴近观察（被动），石缘可见一枚风化字符——与石片同族但不对应任一具体字符。Yura 不知。Linden 知而不言。|

**Sprout/Involvement 过渡（T002）：** 玩家遇见 Vossel、得观 codex、得知 Eilin 为何为哑，继续向 T003 —— 石片与 Silas 的信仍在身上。

---

### T003 —— Wolfsjaw / Silent Order 修道院

修道院在卫戍之上三时马程。比城堡更老。外墙是更新的石砌在更老的基石上。

| 载体 | 类型 | 内容 |
|------|------|------|
| Maester Eilin | NPC 首次会面 | 玩家被领入时，Eilin 在抄写室。五十多，灰发剃短，十指皆墨。她不起身。抬手一次 —— 掌开，然后反转 —— 一位初学修士便去取写字板。她面无表情读完 Silas 的信。伸手要石片。|
| Eilin 首次回应 | 场景节拍 | 她把石片放上一张净纸。上墨于面。拓下一片。把它与书桌上方一排早已钉上的拓片对齐。玩家不被告知就看出：石片字符并非孤品。它们属于 Eilin 多年收集的一族。另一枚拓片旁有 Eilin 亲笔标签：**上下相通**。|
| Eilin 的拓片板 | 场景节拍 | 二十三枚拓片。修道院地窖。Wolfsjaw 地基。Stoneford 渡口。Jadehollow 二层采道。Mistmere 港墙潮线之下。若玩家细看，拓片的地图拼出一枚环 —— Grey Reach 坐落于同一只手所作的更大之环内。无 NPC 说破。|
| Eilin 的手势回答 | NPC 对话（手势）| 对玩家的提问"它说了什么"——无论玩家以何形式提出——Eilin 比一组手势：手升、手落、两指相触。一位初学修士平板翻译：*Above. Below. They touch.*（上。下。它们相触。）意义不细述。但*亲缘*她细述：她示意石片中有两枚字符亦现于铁龙残片 **永生 × 黄金 × 无穷** 中，而此亲缘是根亲缘，如两词共一个祖母。她不自称能读二者。她直言：*I know they are kin. I do not know what they say.*（我知其为亲。我不知其所言。）|
| 修道院后墙字符 | 场景节拍 & 残片落位 | 抄写室之后、沿一段磨损的短阶下去，修道院原初的后墙尚存。齐头处，凿于石、后被粉白覆盖、再后被部分刮开，四枚字符 **上下相通**。并非 Eilin 所刻。她*发现*了它们。这就是她全部的罪。|
| Eilin（粉笔板，若被问失落的草图）| NPC 对话（书写）| 若玩家问 Eilin 关于她遗失的草图，她平板地在粉笔板上写：*"he keeps them."*（他留着。）她不名 Kestrel。她不细说。她擦去。（B↔E 承认：Kestrel 收藏她的草图，参 E 线 T004。）|
| Abbot Merick（NEW NPC）| NPC 对话 | Silent Order 住持。六十，佝偻，声柔，双手拢袖中。Eilin 被噤时他是住持。他批准了那把刀，因为另一种结果是整座修道院失于 Crown 之怒。他没有原谅过自己。他只对玩家说一次话，只一句：*"She is not a prisoner. She stays because the rubbings are here. If you take her out, you take her away from the only library that matters."*（她不是囚徒。她留下，因为拓片在此。你若把她带走，你带她离开的是唯一重要的那座图书馆。）|
| Novice Taryn（NEW NPC）| NPC 对话 | 十四岁，Eilin 日常实践的"手与声"。对外人翻译手势。七岁起被分派给 Eilin，在她的沉默里长大。她是第一个把"上下相通"四字对玩家口说出来的人 —— 她说时并不懂其义，像背诵一行抄来的字。|
| 半焚 "Northern Ban" 诏令 | 残片（A 线携带，本处引用）| 在 Archivist Naryn 的柜中（参 A 线）。若玩家已见诏令并提及，Eilin 打一长串手势：诏令引了石片。她已知此事三年。她不指出是哪一行。她比：*look at the third clause. look at what it forbids to be named.*（看第三条。看它禁人为之命名的是什么。）|
| 修道院地窖 | 场景节拍 | 抄写室之下，地窖承重柱非修道院之作。更老，更圆，柱基坐在现代地面之下 —— 仅在一块地砖裂开处可见。一柱膝高处单字一枚。Eilin 从未拓。若被问，她比手势：她*在留之*。不说为何留。|
| Mark 独眼老兵 | NPC 台词 | 若问他修道院：*"Older than the keep. Older than the road. My grandmother said the stone remembers being someone else's stone."*（比城堡老。比路老。我祖母说石头记得自己曾是别人的石头。）他无笑意地笑。*"Granny drank."*（奶奶酗酒。）|

**Involvement end（T003）：** 玩家见过 Eilin、观过拓片板、把石片认作证据之环中的一件，得知 Crown 曾因一位学者证明 *cliff* 与 *chasm* 的语言亲缘而噤其声。玩家带走一张**石片拓片**；若博得信任，还带走一页由 Eilin 交叉签名的**Vossel codex 副本**。

---

### T004 —— Jadehollow

| 载体 | 类型 | 内容 |
|------|------|------|
| Old Fane Crowseye | NPC 对话 | 他那只灰眼看着石片，久久不语。*"The stone is not the age of the cut. The cut is older. The stone was cut, then broken, then buried, then uncovered, then broken again. You are holding a fragment of a fragment."*（石头的年岁不是切的年岁。切更老。此石：被切、被折、被埋、被掘出、又被折。你握在手里的是残片之残片。）不收钱。*"I do not want to be the one who priced this."*（我不想做那个给它定过价的人。）|
| Jadehollow 二层采道 | 场景节拍 | 二层矿洞东壁，矿工揭出了一面加工过的石壁，藏在矿脉之后。Ironpost 认为是带异常条纹的天然层。非也。Eilin 的拓片板上有此壁的正面拓片。若玩家带一份新拓回 T003，Eilin 会加入环，比：*it closes.*（闭合了。）|
| Kassa Deepvein | NPC 台词 | *"Whatever is in the second drift is not on the Consortium's manifest. Keep your findings to yourself and I will keep mine to mine."*（二采里的东西不在商会清单上。你的发现留你的，我留我的。）礼貌的警告。粗鲁的那句未至。|
| Septon Silas（回）| NPC 对话 | 若玩家回 T004 时石片仍在手——Silas 可见地松了口气，因为它不再在场。*"Tell me you left it with her."*（告诉我你把它留在她那儿了。）若是：他短哭，祷告。若否：他变得极静，然后请求再握最后一次。他会轻声说：*"I found it at the ford. I think the ford found me."*（我在渡口找到它。我想是渡口找到了我。）不细说。|
| King's Archivist Naryn（此处出现，参 A 线）| NPC 对话（理论之声）| 若玩家在 A 线或已赢得会面，Naryn 交付她的理论：*"A hundred years ago the far side came down in pieces. Some pieces fell our way and some pieces fell into the ground. The floor we walk on is the ceiling of their graveyard."*（一百年前彼岸化为碎片落下。一些落向我们，一些落入地里。我们走的地板，是他们坟场的天花板。）四理论之一。口说，不书。|
| Navigator Kestrel（此处出现，参 E 线）| NPC 对话（理论之声）| 若按 E 线相遇，Kestrel 交付 Crosser 的理论：*"There were roads under the earth before there were roads over it. The Chasm is a mouth. The real roads are the throat."*（地上之路之前，地下已有路。Chasm 是嘴。真正的路是咽喉。）她持一幅 **sketch labelled *from below, we may rise*** —— 参 Cross-line E。|
| 无名的带节奏酒鬼 | NPC 对话（理论回声）| Jade Lantern 后室一位无名酒鬼 —— 颊陷、灰发、左边无齿 —— 以节奏反复一段三联残句：*"Below and beyond are one. The floor is the far wall. The floor is the far wall."*（下方与彼岸是一体。地板是远墙。地板是远墙。）他不知其源，不再多言。拒收钱。他**不是** Hallen。Theory-3 的具名承载者是 Hallen，在 T005（参 E 线沉没厢房的病房）。|
| Grandmother Green | NPC 台词 | 若问及修道院或 Eilin：*"They cut a good woman's tongue for a word. I keep my herbs and my mouth both. I recommend you do the same."*（为一个词他们割了一位好女人的舌。我把我的药草与我的嘴都留着。我建议你也如此。）|

---

### T005 —— Mistmere

Mistmere 是 Critical 节拍。揭示不是由对话交付。是由城本身交付。

| 载体 | 类型 | 内容 |
|------|------|------|
| 潮线之下的港墙 | 场景节拍（CRITICAL）| 低潮时，Mistmere 港墙脚露出非港墙筑法的砌体。石更大，接缝方式不同，且加工在*内*面 —— 这些面如今因墙被翻转再利用而朝海。露出的内面有三枚字符。与石片同手。|
| 大教堂下窖 | 场景节拍（CRITICAL）| Grand Cathedral 之下，下窖最古的一室并非 Faith 所建。其柱与 Wolfsjaw 地窖同一族的前-Faith 圆柱。一柱肩高一整句字符。Reynard 四十年来每年一次为整室上灰白。灰白在变薄。|
| Lady Vera Ashford-Blackwater | NPC 对话（若 C 线对齐许可）| Vera 被出示石片，不惊。她已见过数枚。*"My family's cellar — the Mossbarrow — sits on a floor that is not an Ashford floor. My brother Edric said as much before they exiled him. I purchased the land around it because I believe the floor extends outward. I believe this city sits on someone else's city."*（我家地窖 —— Mossbarrow —— 坐在一片非 Ashford 之地板上。我弟 Edric 在被流放之前也这么说。我买下它周围的土地，因为我相信地板向外延展。我相信此城坐在别人之城上。）不肯书面落字。这是该前提第一次被命名 —— 而且是作为一项**家族确信**，非作为事实。|
| His Holiness Reynard | NPC 对话 | 若玩家不智到向他出示石片，Reynard 会细察、微笑、归还。*"A curiosity. The Faith collects many. I would be happy to add it to our reliquary."*（一件奇物。Faith 收集过许多。我乐意把它加入我们的圣物库。）此邀其后会以力再提。若被追问其理论之声：*"The earth buries what the earth wishes to bury. The question is impious."*（地埋它所愿埋者。此问不敬。）他不持第四种理论；他持的是"任何理论都不应流传"的政策。|
| Magister Corvin Ashford-Reed（A 线灵魂）| NPC 对话 | 若玩家到达他处，Corvin 证实：Guild 的 **Northern Ban** —— 那条禁某特定文字被交易、被命名、被拓的宪章条款 —— 以其开头字符命名该文字，而那枚字符就在玩家的石片上。Corvin 是第一个把 *Northern Ban* 四字对玩家口说出来的 NPC。他也是告诉玩家禁令是十一年前草拟、与 Eilin 被噤同季的那位。参 A 线。|
| Navigator Kestrel 的草图 | 残片（深藏区，E 线载体）| *from below, we may rise* —— 在 T004 深藏区，E 线拥 —— 沿下沿有三枚根字符。两枚在玩家石片上。一枚在港墙内面。若玩家已拓三载体，其重叠无可否认。Eilin 被出示此图：*kin. not the same hand. the same grandmother.*（亲。不同手。同一个祖母。）|
| 废墟之城的揭示 | 场景节拍（CRITICAL，无 NPC）| 玩家携石片行于 Mistmere，拓片在衣内，城在眼中重新排序。大教堂广场的地砖分两种尺寸 —— 更大、更老、方正；更小、更新，补隙。贵族区半数花园墙以圆柱残墩作角柱。鱼市排水沟太深、太直，不可能只是排水沟。无 NPC 指点。城自己指点。|
| Septon Silas（若抵 Mistmere）| NPC 台词 | 若 Silas 南下 —— 除非玩家去接，否则不太可能 —— 他在下窖跪过一次，此后整日不语。|

**Critical decision at T005（B 线）：**

玩家手中：Eilin 的拓片、Silas 的石片、Vossel 的 codex 叶、Kestrel 的草图，四物重叠。必须决定如何处理这份汇聚。四种结局都有支持，都不被认可：

1. **交予 Faith（Reynard）。** 石片与拓片入大教堂圣物库。从此不见。Northern Ban（A 线）续十年。Eilin 失去拓片板；Faith 使团访修道院，撤走所有拓片。Vossel 被调南。证据未毁 —— 只是埋得更深。城保住它的秘密。

2. **交予 Magister Corvin（Guild）。** Guild 将证据吸收入其封缄档案。Northern Ban 被悄悄改写，允一个狭窄的学术豁免 —— Eilin 许在晚年以 Guild 印发表一部专著。Vossel 为其抄写员。证据以无平民能读的形式存活。此为 A 线偏好。

3. **交予 Navigator Kestrel（Crossers）。** 石片、拓片、codex 叶合入 Crosser 的下潜简报。草图 *from below, we may rise* 获得语言之脊。被问选，Eilin 比：*go.*（去。）Vossel 选她 —— 他留在修道院。此为 E 线偏好。

4. **把一切带回给 Eilin 然后离开。** 玩家将所有残片带回 T003 加入板上。Eilin 比：*thank you.* 板长。可见世界无变。玩家是 Silent Order 之外唯一见过环闭合的人。此为 B 线自己最偏好的结局 —— 最安静、最诚实、最不戏剧性。这也是唯一一个允许 Eilin 带着她完整的拓片安然死去的结局。

orchestrator 不可对此四者加权。每种都是 B 线的完整结局。

## Stage endpoints

- **Sprout end（T001）：** 玩家接过 Silas 的石片并承诺携之北行。至少已注意到石片沿切线变暖。或已察觉小堂后门之上的半字符。尚未听过 *Eilin* 之名。
- **Involvement end（T003）：** 玩家见过 Eilin、观过拓片板、（经 Taryn 之口）得到"上下相通"的翻译；得知 Crown 因 Eilin 证明 *cliff* 与 *chasm* 的语言亲缘而噤其声。玩家携走一张拓片，若受信任，还有一页 codex 叶。已开始察觉：修道院之下、城堡之下、以及很可能渡口之下，皆有前-修道院的石作。
- **Critical decision at T005：** 如上。四种结局。废墟之城由场景揭示（非对话）在决定之前。

## Cross-line interactions

- **B ↔ A（Guild's Buried Charter）。** Guild 的 **Northern Ban** —— 起草于十一年前、与 Eilin 被噤同季 —— 引石片的**开头字符**作为其所禁命名、交易、拓印之文字。引文位于 Archivist Naryn 柜中那份半焚诏令第三条（A 线残片，T003）。Magister Corvin Ashford-Reed（A 线灵魂，T005）是第一个把 *Northern Ban* 四字说给玩家的 NPC。Eilin 被噤与禁令草拟是同一项王家行为的两面。
- **B ↔ E（Depth-Walkers）。** Navigator Kestrel（E 线副灵魂，T004 Crossers）保有 **Eilin 图画** 的一档副本 —— 近三年由 Vossel 偷渡而出。Kestrel 的 **sketch labelled *from below, we may rise*** 与石片共享三枚根字符 —— 其中两枚亦现于 Kestrel 所存 Eilin 拓片副本。Crossers 对 Eilin 的"上下相通"作字面读解；Eilin 不纠正。若玩家在 T005 选结局 3，Eilin 之作成为 Crossers 的语言之脊。
- **B ↔ D（Iron Dragon）。** 铁龙残片 **永生 × 黄金 × 无穷** —— 自 T002 起即有吟者诵之、其一部分在 T005 由 Veyl 的殖民者纹章残片承载（D 线）—— 与石片共享**两枚根字符**。Eilin 直言：此为亲缘，非同一。她拒译二者。B 线证明二片为同一语系。D 线或以其自身之道破译铁龙残片，或不破。B 不破。
- **B ↔ C（Four-Crown Intrigue）。** Eilin 奉王令被噤。该令为 Crown-Faith 合令；High Septa Malen 不明白自己在签什么便签下了 Faith 的一半（她认为石片文字是魔物 —— 参 C 线 T005 对白）。Chieftess Brenna Greyhold 的前任拒签，在一年内被更替。此为 C 线的背景纹理；B 不搬演。

## 四种遗物于地下的理论 —— 具名之声

按《共享简报》，四种理论各由一位具名 NPC 交付，挂其名。彼此矛盾。皆不被认可。

1. **King's Archivist Naryn（T003，A 线载体；若玩家抵达她，可在 T004 说）。** *"A hundred years ago the far side came down in pieces. Some pieces fell our way and some pieces fell into the ground. The floor we walk on is the ceiling of their graveyard."* —— 崩塌-埋葬理论。
2. **Navigator Kestrel（T004，E 线 Crossers）。** *"There were roads under the earth before there were roads over it. The Chasm is a mouth. The real roads are the throat."* —— 交通理论。
3. **Hallen the mad returnee（T005，E 线拥）。** *"Below and beyond are one. The floor is the far wall. The floor is the far wall."* —— 身份理论（地板*即是*彼岸）。正典之声在 T005 沉没厢房的病房（参 E 线）。Jadehollow Jade Lantern 一位无名的带节奏酒鬼无源回应此三联残句；此回声是 B 线对此理论之声的唯一触碰。
4. **Maester Eilin（T003）。** 以**墙面字符**（修道院后墙）**加手语**（手势序列由 Novice Taryn 翻译为 *above and below connect*）交付。**上下相通。** —— 亲缘理论。Eilin 永不口说。只比划、画、刻。

## Write-in checklist for town writers

### T001 / npcs.json

- [ ] 给 **Septon Silas**（目前在 T004 npcs.json —— 参下文 **Gaps**）加入一个 T001 来访 hook：第三夜走访 Shale Lantern 之后的小堂。对白：*"Carry it to the Maester of the Silent Order at Wolfsjaw. I cannot. Do not open it in any keep you sleep in."* 物品：**stone shard**（如上描述）；**sealed letter in old Faith script** 致 Eilin。
- [ ] 给 **Old Reed** 一句 sprout 台词，关于 *我祖父从渡口捞出的那块方石*。
- [ ] 给 **Mira Ashford** 一句在 Shale Lantern 出示石片时的"止步"台词。
- [ ] 给 **Heron Blackwater** 一句 Guild-警觉台词，提 *Guild men at every keep road this season*（T001 不直接提 *Northern Ban* —— 此名留给 T005 Corvin）。

### T001 / facilities

- [ ] Faith 小堂：**后门上之半字符**，与石片同手，灰白渐薄。被动观察。
- [ ] 渡口：**回访时可见淤泥下的切石**，T003 之后描述发生变化。

### T002 / npcs.json

- [ ] **NEW NPC —— Preceptor Vossel the Younger。** 年轻 Faith 抄写员，空心圣咏集携者，Eilin-转录者。驻 Windrest 小堂；常在路上。设定：学者层级，非战斗，DC 15 才能在他不主动提供时识破他的 codex。对白种子如上。
- [ ] 给 **Kalran** 一句"单手鉴石片"的台词：*"They wore it down. They didn't strike it."*
- [ ] 给 **Captain Yura Stoneshield** 一句对 Vossel 的警觉台词：*"The boy writes more than he prays."*
- [ ] 给 **Old Zhao** 一句 50 金"直线云"台词。（与 D 线协调。）

### T002 / facilities

- [ ] **Windrest Keep 下厅**：一块切割过净的地基石，石缘一枚风化字符。

### T003 / npcs.json

- [ ] **NEW NPC —— Maester Eilin of the Broken Tongue。** 五十多，灰发剃短，墨渍，哑（十一年前奉王令被割舌）。以手势、书写字符、墨画沟通。抄写室，拓片板（二十三枚）。首次回应石片：上墨于面、拓一片、钉上板。
- [ ] **NEW NPC —— Abbot Merick。** Silent Order 住持，批准了 Eilin 被噤以救修道院，从未自恕。一次会面，一句：*"She stays because the rubbings are here."*
- [ ] **NEW NPC —— Novice Taryn。** 十四岁，Eilin 的日常之声，翻译手势，第一个把"上下相通"对玩家口说出来。
- [ ] 给 **Lord Commander Linden Ironfist** 一句警觉台词（不多）：他知道修道院坐在更老之石上，并被付钱不言。
- [ ] 给 **Mark the one-eyed veteran** 一句"奶奶酗酒"的台词，关于修道院记得自己曾是别人的石头。

### T003 / facilities

- [ ] 修道院：**带拓片板的抄写室**（二十三枚拓片，具名位置，其中一枚标 **上下相通**）。
- [ ] 修道院：**后墙刻字 上下相通**，灰白渐薄。
- [ ] 修道院：**地窖**，前-修道院圆柱，一柱膝高单字符，Eilin 未拓。
- [ ] Wolfsjaw 卫戍：Mark 的"数点纪念"节拍（与他线共享）。

### T004 / npcs.json

- [ ] **Jade Lantern 后室**一位**无名的带节奏酒鬼**（非 Hallen）：颊陷、灰发、左边无齿，反复三联残句 *"Below and beyond are one. The floor is the far wall. The floor is the far wall."* 拒收钱。不再多言。具名载体 Hallen 在 T005（沉没厢房病房，参 E 线）。
- [ ] 给 **Old Fane Crowseye** 加"鉴石片"台词：*"You are holding a fragment of a fragment."*
- [ ] 给 **Kassa Deepvein** 加二采警告台词。
- [ ] 确认 **Septon Silas** 回归对白（*"I think the ford found me"*）并解决 T001/T004 位置问题 —— 参 **Gaps**。
- [ ] 给 **Grandmother Green** 加*为一个词割一位好女人的舌*台词。

### T004 / facilities

- [ ] Jadehollow 矿 **二层采道东壁**：矿脉之后的加工过的石壁，可拓。
- [ ] 确认 Kestrel 的深藏区草图 *from below, we may rise* 标注三枚根字符（E 线为拥有者）。

### T005 / npcs.json

- [ ] 给 **Lady Vera Ashford-Blackwater** 加 Mossbarrow 地板向外延展的家族确信台词。
- [ ] 给 **Bishop Reynard** 加"圣物库之奇物"台词，以及"理论压制"政策之声。
- [ ] 确认 **Magister Corvin Ashford-Reed**（A 线灵魂）对玩家说出 *Northern Ban* 二字并把禁令起草日绑到 Eilin 被噤。

### T005 / facilities

- [ ] **Mistmere 港墙**：低潮时露出的更老砌体（内现外面），三枚字符可见。
- [ ] **大教堂下窖**：前-Faith 圆柱，一柱肩高一整句字符，灰白渐薄。
- [ ] **Mistmere 城描述**：贵族区、大教堂广场、鱼市的前-崩塌石作之被动观察。无 NPC 指点。城以几何自指。

### Cross-line / lore

- [ ] 与 A 线写手确认：半焚 Northern Ban 诏令**第三条**引石片**开头字符**。
- [ ] 与 D 线写手确认：铁龙残片 **永生 × 黄金 × 无穷** 与石片共享两枚根字符。D 不破译；B 不破译；亲缘为 Eilin 所观察，未解。
- [ ] 与 E 线写手确认：Kestrel 草图下沿载三枚根字符，两枚与石片重叠。
- [ ] 与 C 线写手确认：Eilin 被噤为 Crown-Faith 合令；High Septa Malen 不明所签；Brenna Greyhold 的前任拒签被更替。

## Gaps needing sibling input

1. **Septon Silas 位置 canon。** 《共享简报》残片清单将 Silas 与石片置于 T001。T004 npcs.json 将 Silas 定为 Jadehollow Dawn Chapel 的常驻 Septon。B 线解：Silas 为 Jadehollow Septon，但每三夜南行朝 Stoneford（与 T001 传言 *"Septon Silas walks to the mine entrance every third night"* 相符），并在 T001 移交石片。需由 Silas 主条目所有者确认。建议：Silas 的*主档*留 T004；给 T001/npcs.json 或 facilities 加一个 T001 来访 hook。
2. **Naryn 的常驻城镇。** 《共享简报》把半焚 Northern Ban 诏令放在 T003 Archivist Naryn 的柜。A 线需明确 Naryn 的位置。B 假设其驻 T003，她的理论之声可在 T003 或 T004 交付（若 A 线携她南下）。
3. **Eilin 被噤日 vs Northern Ban 起草日。** B 主张二事同发于十一年前，为同一项王家行为。A 线当确认或给替代间隔。若 A 把禁令置后，B 相应调整 Eilin 被噤日。
4. **铁龙残片字符计数。** B 主张与石片两枚根字符重叠。D 线拥铁龙残片。最终计数（二或三）由 D 定；B 跟进。
5. **Kestrel 草图字符计数。** B 主张下沿三枚根字符，两枚与石片重叠。E 线拥草图。最终计数由 E 定；B 跟进。
6. **Vossel 的 codex —— 若 Vossel 在结局 1 被调南，是否有任何副本存活？** B 默认：Vossel 出发前把一页藏在 Windrest 小堂的祭石里。若 C 线希望 Vossel 的调派"干净"（阴谋之故），B 取消隐叶。
7. **Abbot Merick 在结局 1 的去留。** 若 Faith 撤板，Merick 是抵抗、顺从、还是辞职？B 默认：顺从并在本季辞。若与 A 或 C 冲突，可调。

## Appendix A —— 石片，描述

石片为本线核心之物。写手与 world-agent 应持一致图景。

- 大小：手掌长，三指宽，一端收窄为从更大之面折断处。
- 颜色：深灰，雨光下略带青绿底色。
- 重量：重于其大小所预。非夸张的程度 —— 足以让一位蒙眼估重的玩家估高。
- 表面：一面加工，一面粗糙。加工面刻十七枚字符、三行。粗糙面折断处边缘有一枚残字 —— 若石片完整，那将是第四行的开头。
- 温度：粗糙面处于环境温度。加工面刻线约高半度。肉眼不察。指尖扫过可察。
- 在直线云附近的行为（D 线）：温差短暂扩大为约二度。无别效。
- 在 Eilin 身前的行为：无变化。石片不应其。若应，也只应云。
- 在圣物库内（结局 1）的行为：未知。圣物库在 B 线范围内不再开启。

石片永不可发光。永不可鸣响。B 线内无任何 NPC 可称其*magical*。玩家若执意用 *magical* 一词，Eilin 比出一个拒绝式，Taryn 译为 *that is not the word for this.*

## Appendix B —— Eilin 的手势词汇（部分）

orchestrator 可按需即兴 Eilin 的手势。以下为固定：

- **手上升，掌上：** *above.*（上。）
- **手下落，掌下：** *below.*（下。）
- **两指指尖相触：** *they touch* / *they connect.*（相触 / 相通。）
- **手于一息间升而又落：** *above and below connect.*（上下相通。）
- **平掌，在胸前于空中横拉：** *a floor.*（一片地板。）
- **平掌，翻过再回拉：** *a ceiling that was a floor.*（曾为地板的一片天花板。）
- **指尖拂唇，再向外开：** *a word that cannot be said.*（不可言之词。）—— 她的自指手势，有人问她名字时用。
- **拇指与食指成小环，举起：** *kin.*（亲。）用于字符亲缘。
- **同一环，打开：** *not kin* / *different hand.*（非亲 / 他手。）
- **平掌，掌缘向前，缓推：** *the wall moves.*（墙在动。）—— 为港墙场景节拍而备，若她被出示之。v0.1 不给她看。

Taryn 尽知。Abbot Merick 知其部分。Vossel 知其大部分，仍在学。

## Appendix C —— 拓片板，按地点

玩家初入抄写室时，板上二十三枚拓片。位置，Eilin 亲笔：

1. 修道院地窖，二号柱，膝高。
2. 修道院地窖，四号柱，肩高。
3. 修道院后墙（上下相通刻字）。
4. 修道院井，内壁，水线之下（旱年拓）。
5. Wolfsjaw 城堡，下厅，东地基。
6. Wolfsjaw 城堡，下厅，西地基。
7. Wolfsjaw 卫戍纪念碑，基石。
8. Stoneford 渡口，中央之石。
9. Stoneford 渡口，东岸切石。
10. Stoneford 小堂，后门门楣内底。
11. Stoneford 河，水下河段（冬枯由 Vossel 拓）。
12. Windrest 小堂，祭石后面。
13. Windrest 城堡，望楼基。
14. Jadehollow 矿，二层采道，东壁。（Vossel 拓、偷渡。）
15. Jadehollow 矿，二层采道，南壁。（Vossel 拓。）
16. Mistmere 港墙，内现外面，北。
17. Mistmere 港墙，内现外面，南。
18. Mistmere 大教堂下窖，三号柱，肩高。（四十年前 Reynard 灰白政策之前拓。）
19. Mistmere 大教堂下窖，七号柱，膝高。（同。）
20. Mistmere 贵族区，花园墙角柱，House Vance。
21. Mistmere 鱼市排水沟，三号墙。
22. T002 与 T003 之间的路标，被地衣蚀，残。
23. 无标。Eilin 比：她记不得从哪里拓的，只知自己当时是孩子。

石片被拓入并钉上时，为拓片二十四。由 Eilin 亲钉。novice 不碰。

将拓片按各自地点的地理顺序摆放，可见一环。此环要到 Jadehollow 二采与 Mistmere 港墙的拓片并置时才闭合。那一刻，Eilin 比 *it closes.*

## Appendix D —— Vossel 的 codex，部分内容

空心圣咏集内十二折页。每页：

- 叶一：*above* 的手势与其所对字符（上行，石片位置 1）。
- 叶二：*below* 的手势与其所对字符（石片位置 8）。
- 叶三：*touch* 的手势与其所对字符（石片位置 15）。
- 叶四：*floor* 的手势与其所对字符（地窖二号柱）。
- 叶五：*ceiling-that-was-a-floor* 的手势与其所对字符（地窖四号柱）。
- 叶六：*kin* 的手势与其所对的一对字符（石片位置 3 与地窖七号柱）。
- 叶七：Eilin 绘制的拓片地点之环图。
- 叶八：铁龙诵文（**永生 × 黄金 × 无穷**）的抄段，Eilin 在其二字外圈画"亲缘环"。
- 叶九：Vossel 私注，他不知铁龙残片何意，也不愿做那个破译它的人。
- 叶十：Eilin 所绘修道院后墙 上下相通，每字符旁注对应手势。
- 叶十一：空白。按 Eilin 之手势，*留待我未拓之字*。
- 叶十二：Vossel 自书之祷，求宽恕于其誊抄。

若玩家在 T003 得一叶，为叶七（环图）。一至六被引但不给。八至十由 Vossel 持。十一、十二私藏。

## Appendix E —— 场景节拍：T002 至 T003 的旅程

Windrest 至 Wolfsjaw，路上升。树渐稀。隘口风转。

此段，若玩家携石片，可依序察觉：

- 一块被地衣蚀的路标，某枚字符残存于早先有人刮去地衣之处。Eilin 已拓（拓片二十二）。
- 一片石堆 —— 古，前-faith，粗。其中一堆用一块方石作基。那方石非石堆之石。是再利用。
- 溪上独木桥。桥下，干河石上，三块扁石一列，带有像字符又像水痕的刮痕。orchestrator 不确认。
- 隘口处，北望骤开 —— 城堡可见，修道院在其上，崖在更远处。行囊中的石片短暂变温，无可考证之因。天晴。无云。

这些节拍皆无需 NPC。皆为被动描述，由携石片触发。

## Appendix F —— 场景节拍：初见修道院

修道院在玩家到达之前一时出现于视野。它坐在城堡之上一道岩肩上。外墙是更新的石砌在更老的基石上；此距离下玩家分辨不清，但轮廓对一座记录年代的修道院来说是错的 —— 下宽，上窄，仿佛一座更大建筑被截顶再覆瓦。

主门之内，院小。一井，一钟，一覆顶廊。Novice Taryn 在门口迎，不问来意。她看行囊。点头一次。领入。

抄写室是一间沿覆顶廊而开的长而低的室。一扇高窗。墨味。纸味。一丝冷石味。Eilin 坐在远端，斜桌，背对门。她不转身。Taryn 轻咳一声。Eilin 举手 —— *wait* —— 画完手下的一笔。然后转身。

她的眼是一双在弱光下读小字读了三十年的眼。她的嘴闭着且保持闭着。她在十一年里学会了不让最小的一丝呼吸逸为声。那是一种纪律。也是一处伤。

她伸手，掌上。Taryn 轻声说：*she would like to see it.*

## Appendix G —— 场景节拍：低潮之港墙

Mistmere 在满月后第三日退潮最远。那些早晨，约二时，港墙脚露到石之膝。

玩家在那一时辰行港之路，不经提示可见：

- 墙上一道接缝，现水线之上三尺处，两种不同石层相遇、略成角。
- 接缝之下，更老的石层。石更大。接缝不同。海藻附着不均 —— 有些面藻不生，有些面藻全盖，仿佛石本身自层而异。
- 露出的一块更老之石上，三枚字符。风化。可见。其一为石片位置十五之字。其二取自铁龙诵文。

无 NPC 指点。鸥鸣。潮回。字符二十分钟内将复于水下。玩家若带纸，有一次拓印之机。

若玩家在下一次低潮带 Vossel 回来，他会把拓片墨入 codex 叶十一 —— 那张 Eilin 留空的 *for the glyph I have not yet rubbed*。这是 B 线唯一一处，Eilin 的私人留白由他人而非 Eilin 自己填上。她被出示填好的叶时，长长闭眼一息，然后比：*thank you.*

## Appendix H —— 声音注记

- Eilin 永不开口。永不尝试开口。不唇形词。她的沉默完整而有意。写手若给她一声咕哝、一声嘶、一声低语音节，就破坏了角色。
- Taryn 平板翻译。不渲染。她说 *above. below. they touch.* —— 不说 *我的 Maester 深情地说上下相通*。平板是 Eilin 方法的一部分：意义必须自承。
- Vossel 自谦且谨慎。不揽功。他说 *I am copying, only.* 他实际上做的远不止抄 —— 他是唯一系统地把 Eilin 的手势与她的字符拓片对勘的人 —— 但他不会这么说。
- Silas 疲惫。他把石片携在身上三季，失眠以偿。他不是阴谋者。他是一位祭司，拾到了一块石，并正确地相信它不属于他。
- Abbot Merick 说一次。一句。不多。写手若给他更多台词就破坏了角色。
- Jade Lantern 的无名酒鬼以三为单位说话。他只有一句三联，不展开。Hallen 本人 —— Theory-3 的具名载体 —— 属 E 线 T005；B 不写他。

## Appendix I —— B 线不做什么

- B 不破译石片。
- B 不破译铁龙残片。
- B 不命名彼岸。
- B 不认可四种理论中的任何一种。
- B 不揭露隐藏前提。
- B 不让 Eilin 开口。任一结局皆不。即使在她死的时刻（若循环的后续版本中该时刻到来），亦不。
- B 不允许石片被描述为 *magical*、*cursed*、*blessed*、或 *alive*。
- B 不解"遗物在地下"之悖论。它呈现四声。它让彼此矛盾。它把证据之环闭合，把意义留开。

B 线之技艺是克制。玩家离开此线，比先前知道更多，却比自以为懂得更少。此为所欲之效。此为 B 线唯一被建成以产生之效。

## Appendix J —— 石片十七字符示意

石片加工面载十七字符，三行。本文件不给其字形 —— world-agent 可按需呈现 —— 但其位置、亲缘、功能皆固定。

第一行（五字，位置 1–5）：

- 位置 1：*opening* 字。亦现于半焚 Northern Ban 诏令第三条（A 线）。高，窄，顶部一笔上扬。Eilin 手势：手上升，掌上。
- 位置 2：*modifier* 字。仅现于石片。功能未知。Eilin 不比划；她在其拓片旁画一问号。
- 位置 3：*kin* 字。下笔与铁龙残片 **永生 × 黄金 × 无穷** 三字之一共享。Eilin 手势：拇指-食指环，举起。
- 位置 4：*joining* 字。两笔交于一点。现于修道院地窖四号柱。Eilin 手势：两指相触。
- 位置 5：*closing* 字。饰性。在多拓片之行末现；功能为行终止符。

第二行（七字，位置 6–12）：

- 位置 6：*below* 字。手下落，掌下。现于 Mistmere 港墙。
- 位置 7：*floor* 字。平掌在胸前横拉。现于地窖二号柱。
- 位置 8：*below* 字第二形，异体。Eilin 比同一手势但倾手。异体未解 —— 或亲、或方言、或误。
- 位置 9：*connective* 字。小，在两枚较大邻字之间。罕现。
- 位置 10：*kin* 字。下笔与铁龙残片第二字共享。为石片-铁龙两处重叠之第二处。
- 位置 11：*joining* 字，异体。Eilin 手势：两指相触，但抬至额 —— 她未破译之一异义。
- 位置 12：行终止符。同位置 5。

第三行（五字，位置 13–17）：

- 位置 13：*opening* 字，异体。似位置 1 但上扬笔较短。现于 Jadehollow 二采东壁。
- 位置 14：*modifier* 字。现于两拓片；功能未知。
- 位置 15：*touch* 字。两指尖相触。Eilin 翻译 **上下相通** 的招牌字。现于修道院后墙。现于 Mistmere 港墙。现于 Kestrel 草图。
- 位置 16：*closing* 字（句之，非行之）。石片一次、地窖七号柱一次、大教堂下窖三号柱一次。
- 位置 17：*terminal* 字。饰性。表句至此止。Eilin 在其拓片下画一短线 —— 她笔记中的惯例：*this is the last word.*

粗糙面上的残字，开启一不存在之第四行，未入目录。Eilin 被问时比：她不目录之，*直至其余被找到*。

石片十七字符，按 Naryn 前任之译稿，翻为四句目击 —— *sun-nailed-to-tower, house-that-flies, iron-that-sings-like-a-forge, the-unending-road* —— 即 Northern Ban 第三条所存四句具名目击（A 线，Naryn 柜）。Eilin 不认可此译。亦未更正。

## Appendix K —— world-agent 对四种理论的指引

四种理论之声当以**观点**交付，永非**事实**。若玩家试图逼出裁决 —— *哪种理论为真？* —— world-agent 必须拒裁。拒模：

- *Archivist 说她所知。Navigator 说她所知。她们所知不同。*
- *Hallen 疯语 —— 在 T005 沉没厢房病房里，不在这里。他有些疯语是对的。在世无人知是哪几段。Jade Lantern 的酒鬼只是回声。*
- *Eilin 比出了她的理论。她未称其为答案。她称其为她能证的亲缘。*
- *你将离开本镇而无裁决。这是诚实的结局。*

任何情形下，B 线内 world-agent 皆不可宣告四理论中任一更接近真相。隐藏前提（Chasm 彼岸的一座已死现代文明）永不被显性引用、确认或暗示。玩家可从累积证据形成自己的看法。orchestrator 不给裁决。
