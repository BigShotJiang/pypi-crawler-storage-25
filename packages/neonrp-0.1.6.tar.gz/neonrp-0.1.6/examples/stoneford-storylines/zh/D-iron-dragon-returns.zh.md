# 主线 D：Iron Dragon 归来（The Iron Dragon Returns）

> 源文件：../D-iron-dragon-returns.md · 译文仅供审阅，以英文原版为准

> 暗线（Hidden line）。Writer-δ。不解释。不收束。

## Function / 功能

此线是世界从天气之外发来的气象报。它是第一枚证据 —— 悄悄落在天上 —— 证明这世界不再静止。A 线在纸上谋划，B 线于石下挖，C 线削王冠，E 线向暗中攀登 —— D 线只看空气，只听老人。它拓展感官经验。它从不自我解释。玩家只会收到一串碎片 —— 村民称之为天气的一条直云、一位牧羊人不肯重述的故事、一座矿谷里老妇的摇篮曲、锁柜后半页羊皮、一位行旅外衣的陌生人像司祭念祷一样念一段族谱 —— 玩家须*感*，不须*懂*。orchestrator 绝不可确认这些碎片指向何处。游戏绝不裁决 Veyl 是真心之谎还是 Hero-from-Beyond 的真实后裔。游戏绝不告诉玩家：天空在动，是因为彼岸之物在动。那份感受本身就是线。此线一旦被命名，便不复生。

## Soul figure(s) / 灵魂角色

- **Veyl "the Line"** —— T005。高，审慎的男人，穿一件无人记得其剪裁风格的灰色行旅外衣。语缓。随身一只黄铜框怀锁，不为任何人打开；袋里一枚残片，整条线中只示一人。自称有 Hero-from-Beyond 一脉血统。此说或为世代磨平的真相，或为一位信以为真之人所述之美丽谎言。游戏从不裁断。
- **Old Shepherd Bram of the High Scree** —— T004，副灵魂。六十余，面上沟壑深，一眼浑浊，左膝有跛——源于一次他不肯描述的坠落。冬居 Jadehollow，夏在 Brokenspine 之上的高 scree。他只有一句证词，且仅说一次：*"It was not a dragon. It was a house that flew."*（那不是一条龙。那是一栋会飞的屋子。）他不肯展开。你越逼他，他越静，从不越响。

## Hook

- **Tier 2 hook，Windrest Keep（T002）。** Sprout 是一次天象，不是一个人。玩家抵达 Windrest 的那一周，黎明升起时，天上自北至南横过一条单一笔直的云 —— 薄，平，长得不像一朵云该有，投一道针形阴影于校场。村民称之*weather*。一名中继信使说，他祖母叫它 *the dragon's wake*。锻工 Durm 在炉角看了一眼，便不再看。他的手在一块十一年来始终锤不下去的金属上停住。
- **次要 hook：** Durm 那块不可锻的金属块。此块在 T002 的 fragment inventory 中。玩家出示予 Durm 可触发他真正的那一句：*"I took it from the hills. My hammer finds no tooth in it. My fire finds no belly. It is iron that knew the wind."*（我从山里拿来的。我的锤咬不住它。我的火烧不透它的腹。这是识过风的铁。）

## Clues by town / 各城线索

### T001 —— Stoneford-on-the-Shale

T001 是此线的 Sprout-zero。D 线不从此起；它在此**轻触**。玩家离开 Stoneford 时应带着一种感觉：天有点不对，却说不出是什么。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T001 | Old Reed（NPC002）| 偷听台词 | 玩家在其铺子翻看时，Reed 自言自语念河。玩家若留久，他不抬头说：*"Gulls came back wrong this week. They flew south then turned around halfway. My father used to say the birds know when the road above is busy."*（这周的海鸥回来得不对。飞南途中掉头。我父亲说鸟知道上面那条路何时正忙。）他不肯解释"上面那条路"。若逼问，他转去谈鱼价。|
| T001 | Septon Silas（客串，Stoneford 礼拜堂）| 布道片段 | 自 Jadehollow 来访的一位 Septon 在 Stoneford 礼拜堂晨课上作短道。一句，无上下文，任何路过敞门者皆可闻：*"Do not read the sky for omens. The sky was written long before we learned our letters, and we are not its audience."*（勿从天象读兆。天在我们识字之前早已被写就，而我们不是它的受众。）（此为 Faith 压制云象目击之教义 —— 参 A↔D 交叉。）|
| T001 | Heron Blackwater（NPC001）| 对话（门槛限定）| 若玩家已见过 Bram（T004）或带着 Durm 的金属块（T002），Heron 被问及"北天之事"时，会从账簿抬头说：*"Ask an old shepherd. Not a Guildsman. The Guild does not keep weather."*（问一位老牧人。别问 Guild 的人。Guild 不记天气。）他不肯多说。他说的是真话：Guild 规章禁止他记天气。|
| T001 | 码头片段 | 环境 | Windrest 直云事件后的黎明（无论玩家是否已抵 Windrest），Stoneford 一名渔夫对另一人说：*"Long cloud up north. Straight as a blade. Gone by second bell."*（北边有长云。直如刀刃。二钟即散。）第二人答：*"Weather."*（天气。）此对白连三日黎明重复，然后止。无人置评。|
| T001 | Guild 告示板 | 海报（半撕）| 一张半撕告示，边角卷起：*"By order of the Magister — sightings of 'long cloud' or 'iron shape in the air' are not to be logged in Guild incident reports. Direct such reports to the Magister's office. No bounty is offered."*（奉 Magister 之命 —— 凡"长云"或"空中铁形"目击，不得录入 Guild 事件报告。此类报告呈 Magister 办公处。不设赏金。）下端小而精致之手书签名：*C.A.-R.*（Magister Corvin Ashford-Reed。）|

**T001 的 Sprout 说明。** 玩家在此不应有任何 D 线 NPC 可谈。D 线在 Stoneford 是余光。无对话，即是要点。一张压抑某话题的告示，比一场关于它的演说更有力。

### T002 —— Windrest Keep

T002 是 Hook。天空做了工作。玩家可带或不带此前 D 线接触抵此；无论如何，天象被强加于他们在城堡过完第一晚的那个黎明。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T002 | 天象 | 脚本环境 | 第二日黎明。玩家在城堡内任何位置，皆可从任一窗或城垛望见一条反常笔直的淡云，自北方地平线横贯至南。比自然云更薄。在铺石上投一道发丝般的影。持续约二时辰而后渐散。orchestrator 只用感官性描述：*"a line drawn in chalk across blue slate"*（一道白垩划过青板的线）、*"a thread the sky has forgotten to pull out"*（天空忘了抽出的一根线）。无 NPC 解释之。|
| T002 | 村民反应 | 环境合唱 | 大多数居民抬头一瞥，继续干活。一洗衣女云：*"weather."* 一信使云：*"wind."* 一童指向它，被喝止。一老人坐长凳，一动不动看到它散。玩家若近前，他只报姓名 —— *Nole, a traveler* —— 不谈天。（见下 Traveler Nole。）|
| T002 | **Blacksmith Durm**（NEW NPC，flag）| 对话 + 物品 | Durm 立于 Kalran 炉子的角落。Kalran 容他；Durm 非 Kalran 之徒，只是炉子允他留的一人。他有一块**不可锻的金属块**（fragment inventory，T002）。出示予任何别的铁匠只得耸肩。天象之后出示予 Durm，会引出他仅有的一段完整独白：*"I took it from the hills above the High Scree, six summers back. My hammer finds no tooth in it. My fire finds no belly. I have tried with oak charcoal and with river coal. I have tried with a wet anvil and a dry. It is iron that knew the wind. Bram knows the hill I took it from. Bram will not go back there."*（六个夏天前，我从 High Scree 之上的山里取来的。我的锤咬不住它。我的火烧不透它的腹。我用栎炭试过，用河炭试过。我用湿砧试过，用干砧试过。这是识过风的铁。Bram 知我从哪座山取来。Bram 不会再去那里。）他不卖此块。若玩家已得其信任（一则小任务，寻回其走失侄子或修风箱），他或肯借出一城之用。|
| T002 | Captain Yura（NPC_T002_01）| 简短台词 | 若玩家问 Yura 那片云：*"The Keep does not log weather. Ask the Guild, not the garrison."*（城堡不记天气。去问 Guild，别问驻军。）她说这话时不与玩家对视。她已被从 Stoneford 来的一位信使私下告知：Guild 也不会记。|
| T002 | Mei（NPC_T002_03）| 偷听之歌 | Mei 在分信时，未察觉地哼一段四行短诗。此诗与 T004 出现的摇篮曲同一首（见下）。她幼时在 Jadehollow 学会。她不记得从何处学来。|
| T002 | Old Zhao（NPC_T002_02）| 售卖，50 金 | Zhao 以正五十金售一条讯息：*"A man in a grey coat passed through three weeks ago, going north. Did not buy from me. Did not sell. He stopped at the parapet at dawn and watched the sky as if he were counting something. He asked the way to Mistmere. He called himself Veyl."*（三周前一位穿灰外衣的男人过境，北行。不向我买，不卖。他在黎明于城垛停步，望天像在数什么。他问去 Mistmere 的路。他自称 Veyl。）Zhao 不愿再揣测。Zhao 对不能出售之事没有好奇。|
| T002 | **Traveler Nole**（NEW NPC，flag）| 长凳，环境 | 一位许七十、或更老的男人，穿打补丁的行旅外衣。每个黎明坐同一条凳。他说，他已*"the length of the Reach three times, and a year on the far moors"*（沿 Reach 走过三次，在远 moors 上住过一年）。他不直谈天。若有耐心的听者在前，他说：*"I was a boy on the coast road. My grandmother had a saying for mornings like this. She said, when a line is drawn in the sky, the old road is open again. I never asked her which road."*（我还是海路边的孩子时。我祖母有一句这样晨头的谚。她说，天上一道线画出，旧路便再开。我从未问她是哪一条路。）他不知。他祖母久已殁。|

**T002 的 Sprout 终点。** 玩家离开 Windrest 时：(a) 看过那片云，(b) 听过两三段无法贯通的片段，(c) 可能已持、或已见过那块不可锻之金属。无 NPC 当面对他们说过*dragon*一字。此词须已落在玩家心里，却没人替他们放进去。

### T003 —— Wolfsjaw 隘口

T003 是 Involvement。此处线增厚：一片羊皮，一位士卒的故事，以及与 A 线压制机器的首次明确（仍可否认）的接触。Guild 带着一个来此的理由到来。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T003 | Sara（NPC_T003_02）| 医学观察 | Sara 被问异例时不带强调提及：*"Three shepherds this season with the same burn on the back of the neck. Sunburn, they say. It is not sunburn. It is on the side the sun does not reach. I do not have a name for it."*（今季三位牧人，颈后同一处灼痕。他们说是晒伤。不是晒伤。那是在阳光照不到那一面。我对它没有名字。）她不肯让玩家查病人 —— 医治之秘 —— 但会出示灼痕图样：一道窄而直的线。|
| T003 | Mark the Veteran（NPC_T003_03）| 炉火旁的故事 | 若玩家在驻军炉火旁与 Mark 对饮，仅彼时，Mark 会说：*"In the battle five years ago, the hour before dawn, I was on the east flank. I was the only man who looked up. There was a line in the sky then too. I thought it was a trick of my bad eye. After the battle I asked the captain. The captain said I had been concussed. The record says I was concussed. I was not concussed."*（五年前那场战役，黎明前一个时辰，我在东翼。只有我一人抬头。那时天上也有一道线。我以为是我坏眼睛的错觉。战后我问队长。队长说我当时有脑震荡。记录也说我有脑震荡。我没有。）次晚他不会重述。他会否认说过。|
| T003 | **禁书 / Forbidden scrap** | 羊皮，藏 | 于修道院藏书室锁柜后（与 B 线相同之柜；钥在 Archivist Naryn 处）。单撕一页，无名，无日期。笔迹古旧。文以土语写：*"—and the house that flew came down into a valley that the maps do not hold. I did not see it land. I saw the line it drew across the dawn. The line stayed for the time it takes a man to say the morning prayer. The cloud was iron that knew the wind, and the wind did not know it back. I will not write the name of the valley. Whoever reads this, do not go. The Hero said, in his tongue: do not attempt to visit."*（——那栋会飞的屋子落入一座地图不容之谷。我未见其落。我见它在拂晓划下的那道线。那线停留一个人诵晨祷之久。那云是识过风的铁，而风不识它。我不写此谷之名。读此者，勿去。那位 Hero 以他之语言说：勿试图前往。）页止于半句。玩家可抄录。取走原件则触发 A 线的压制反射（Corvin 一周内得知）。|
| T003 | Archivist Naryn | 对话（门槛限定）| 若玩家问 Naryn "会飞的屋子"，他的脸会静下来。他说：*"You have been reading where you should not. The Magister has an interest in such pages. I would ask you, for your own sake, to forget you read that one."*（你读了不该读之处。Magister 对此类页有兴趣。为你自身好，我请你忘掉你读过那一页。）他不强行扣押，除非被迫。他自有让碎片漂移的理由。|
| T003 | 班长的告示 | 张贴命令 | 驻军告示板上一张新的小告示：*"Any report from the High Scree concerning the shepherd Bram of the flock-valley is to be passed through Corporal Hest before any other channel. By order of the Guild Magister. Non-compliance will be considered obstruction of the Northern Ban."*（凡自 High Scree 来的、关于 flock-valley 的牧人 Bram 之报告，须先经 Corporal Hest，再走任一途径。奉 Guild Magister 之命。不从视为对 Northern Ban 之阻挠。）（交叉：A 线 Northern Ban。）|
| T003 | **Corporal Hest**（NEW NPC，flag）| 过境 | Corporal Hest 是一位瘦而礼貌的男人，穿 Guild 制服而非驻军制服。他在特定日子抵 T003（玩家首读禁页之次日，若 world-agent 选择将两事件耦合；否则独立）。在驻军伙房静静进食。他说他"骑上 scree 去见一位老牧人"。他不肯说为何。他并不残酷。他是一个被派来处理某事的人。他顺口提及在 Bram 之前已处理过三位牧人，那三位"now live quietly"（如今过得很静）。*quietly*（静）一词须不着痕地落入对话。|
| T003 | Linden Ironfist（NPC_T003_01）| 少见台词 | 若玩家向 Linden 出示那块不可锻金属或 Forbidden scrap，Linden 久视而后无语返还。当夜与玩家单独相处时说：*"I have been a soldier long enough to know when the sky stops being the sky. I do not know what it means. I know that the Magister's men would rather I not ask. That alone is reason to ask."*（我当兵日久，知何时天不再是天。我不知其意。我知 Magister 的人宁愿我别问。仅此一点便已是问的理由。）他不施助。他只给许可继续。|

**Involvement 中点。** 玩家此刻或 (a) 已让 Corporal Hest 先北行，(b) 已试图赶在 Hest 之前见 Bram，或 (c) 已忽略此线。orchestrator 须尊重三者。若忽略，D 线变薄；它从不封闭，因为天空仍在。

### T004 —— Jadehollow

T004 是 Involvement 的高潮。Bram 是副灵魂。老妇的摇篮曲置于此处。若玩家未抢在 Hest 前，可见 Corporal Hest 抵达 scree。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T004 | **Old Shepherd Bram**（NEW NPC，flag —— T004）| 一句证词 | Bram 冬日在 Jade Lantern 酒馆后座，一杯啤酒养一晚；夏日在 Jadehollow 之上的高 scree。问"那位膝坏的老牧人"极易找到。他受食。他受陪伴。他不受关于那座谷的问话。玩家若耐过两三晚 —— 不以问开场 —— Bram 或有一次说出他那仅有的一句：*"It was not a dragon. It was a house that flew."*（那不是一条龙。那是一栋会飞的屋子。）那晚他再不多说。他不再重复此句。若被逼，他说：*"I gave it to you. It is yours now. Do not make me give it again."*（我已给你。它已是你的。别再让我给一次。）|
| T004 | Bram | 高地目击（Listeners）| 若被问高地上的陌生人，Bram 一次道：*"Grey-coated folk. The earth-men, maybe. I do not trouble them and they do not trouble me."*（穿灰衣之人。也许是地下人。我不扰他们，他们不扰我。）他不肯展开。他在黄昏见过他们不点灯笼地穿过他的高牧。（交叉：E 线。）|
| T004 | Bram，再被逼 | 沉默 + 手势 | 若玩家出示那块不可锻金属，Bram 久视之，而后以指甲在其侧轻扣两下。扣声不对 —— 比此块之大该有的音更深。Bram 说：*"The hills above the flock-valley are full of pieces that sing like this. I do not take them any more. The ones I took when I was young — I gave them to the river. The river kept them."*（flock-valley 上方的山里，到处是像这样唱的碎块。我不再取了。我年轻时取的那些 —— 都给了河。河留下了它们。）他不肯展开"flock-valley"。若玩家问它在地图何处，Bram 看图说：*"The map does not hold it."*（地图容不下它。）|
| T004 | **Old woman Haddie**（NEW NPC，flag —— T004）| 摇篮曲 | Haddie 九十，卧床，由 Grandmother Green（NPC_T004_05）照料。小 NPC；玩家仅在以任何方式帮过 Grandmother Green 之后才能见到她。Haddie 用细声唱一首从她祖母那学来的摇篮曲。四行：*"Hush now child, the line is drawn / Hush now child, the house is flown / Hush now child, the iron sings / Hush now child, the morning brings."*（安睡吧孩子，线已划就 / 安睡吧孩子，屋子已飞 / 安睡吧孩子，铁在歌 / 安睡吧孩子，晨正来。）她不知其意。她对自己孩子唱过。Grandmother Green 从她学来。T002 的 Mei 幼时从 Green 学来。此曲是 D 线在 Grey Reach 最古老的遗存。|
| T004 | Grandmother Green（NPC_T004_05）| 佐证 | Green 被问及摇篮曲时说：*"Haddie's grandmother was a shepherd's wife. They had a song for the sky. Every generation loses a word of it. Two more generations and it will be a humming."*（Haddie 的祖母是一位牧人之妻。他们有一首给天的歌。每一代丢一个词。再过两代就只剩哼声了。）她不声称解其意。她唱一更早的版本，第四行不同，玩家未能听清。|
| T004 | Old Fane Crowseye（NPC_T004_03）| 鉴定 | 若示以那块不可锻金属，Fane 的淡色眼发光。褐色眼不发光。此为异常；Mossbarrow 之物两眼皆亮。Fane 说：*"This is not of the Barrow. This has never been buried. This remembers sky."*（这不是 Barrow 之物。它从未被埋过。它记得天。）他不肯出价。他以两手小心交还。|
| T004 | Kassa Deepvein（NPC_T004_01）| 拒绝 | 被问 Bram：*"The shepherd is not a Guild matter. We do not dispatch for him. We do not log him. Do not ask."*（牧人不是 Guild 之事。我们不为他派人。我们不记他。别问。）她在执行 Magister 的指示。她并不赞同。她很高效。|
| T004 | Crosser 涂鸦 | 图书馆壁龛（深藏区）| 在 Crosser 草图 *"from below, we may rise"*（E 派二于 T004 的 fragment）旁以炭条小字潦草写下，笔迹不同：*"—or from above, if above returns."*（——或自上，若上归来。）此为一位 Crosser 的私记，作 E 线对云的回应。交叉：D↔E。|
| T004 | **Corporal Hest 抵达（如适用）**| 脚本场 | 若玩家在 T003 未抢在 Hest 之前，Hest 于玩家抵达 Jadehollow 的次日到。他在 Jade Lantern 喝酒。他坐到 Bram 的桌边。他不威胁 Bram。他低声与 Bram 谈一个时辰。次晨 Bram 不在酒馆。Grandmother Green 说他回 scree 去了。Green 的脸说她没有把握。玩家若登 scree，Bram 在那里，活着，比先前走得慢。他不再开口。他那一句已经给了。|

**T004 的 Involvement 终点。** 玩家已得 Bram 那一句；或见过 Corporal Hest 的手法；持或见过那块不可锻金属；听过或半听过那摇篮曲。玩家此刻已有足够多的碎片 —— world-agent 若被要求摘要，*可以列举*之，但绝不可连接。列举可许。连接是玩家的工。

### T005 —— Mistmere

T005 是 Critical 决断。Veyl 在此。Veyl 一直在等一位把碎片带到这里的玩家。殖民者纹章残片在他口袋（fragment inventory，T005）。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T005 | **Veyl "the Line"**（NPC_T005_09，待加；作 new 旗）| 首次出场 | Veyl 宿贵族区附近一家小客栈，不住大教堂的客栈。他以旧币付账，店主觉得币重些。他有礼。他不饮。他不开那只黄铜框怀锁。他向玩家自我介绍 —— *仅当玩家至少已满足以下两项：在 T002 见过那片云、经手过 Durm 的金属块、读过 Forbidden scrap、听过 Bram 那一句、听过 Haddie 的摇篮曲*。否则他不近前。|
| T005 | Veyl，初见 | 诵 | Veyl 诵他的世系。语长，节制，用九代讲完。不提 Hero-from-Beyond 之名。只名"那位乘会飞之屋而来的人"，而后父传子，母传女，九名。第九名是他自己的。诵词一字不差。*太*一字不差。具童年记诵的祷文节律 —— 这与真实后裔*并与*精心伪造皆相容。orchestrator 不可偏倾。|
| T005 | Veyl，纹章残片 | 物品卡 | 在私室中，Veyl 拿出一枚手工金属残片，约孩童之掌大。以玩家之眼，orchestrator 只以土语描之：*"a piece of pale bright metal, thinner than any smith could beat it, with a pattern stamped into it — a bird on a sunburst, the bird's wings sharp and angled like no bird's wings are. The metal is warm to the touch though it has sat on the table for an hour."*（一片浅而亮的金属，比任何铁匠能锤出之物更薄，压印一枚纹 —— 日芒之上一鸟，翼锐且呈角，不像任何鸟之翼。虽在桌上搁了一时辰，金属触手仍温。）对任何世内 NPC 之一瞥，它读作"古旧纹章"—— 日芒之鸟像某一世家早已被忘的徽号。玩家从不听到现代意义上的"殖民者"或"纹章"；物品卡只述感官事实。|
| T005 | Veyl，他的请求 | 对话 | Veyl 轻声说：*"I am going north. Past the last pass. Past the Grey Reach. I do not expect to return. I ask one of three things of you. First: stand beside me when I present my line to the High Septa — I will need a witness of good standing, and the Faith will not lie if a witness looks them in the eye. Second: if you believe I am a liar, expose me — take this fragment to the Magister, and he will know what to do with both it and me. Third: come with me. Walk the last road. See what drew the line in the sky. I will not promise you return."*（我要北去。过最后一隘。过 Grey Reach。我不指望归。我请你三者择一。一：我向 High Septa 呈我世系时，站在我身旁 —— 我需一位有体面的见证人，若见证人直视 Faith 之眼，Faith 不会撒谎。二：你若信我是说谎之人，揭发我 —— 把此残片带去 Magister，他知该如何处置它与我。三：与我同行。走最后一条路。看是什么在天上划下那条线。我不许你归途。）|
| T005 | Magister Corvin Ashford-Reed（NPC_T005 A 线）| 少见互动 | 若玩家将纹章残片带予 Corvin，Corvin 久审之。脸不可读。他付玩家甚丰 —— 超乎丰厚 —— 买下残片，并买下 Veyl 的住址。两日内 Veyl 不见。店主不知其所往。Guild 不记录。（交叉：A↔D。Corvin 持王家令于此事。）|
| T005 | High Septa Malen（交叉 C 线）| 少见互动 | 若玩家为 Veyl 向 Faith 呈献作见证，High Septa Malen 全程沉默地听完九代之诵。末了，她只说：*"I have heard this song before. I do not know where. You may go."*（我此前听过此歌。我不知在何处。你可以走了。）她不确认。她不否认。此后三日她心神不宁，说不出所以。（此为 Malen 的定义：她不知殖民史；那一诵触到她记忆中一处她无以名之的地方。）|
| T005 | Reynard the Bishop（NPC_T005_02）| 警告 | Reynard 若得知 Veyl（他迟早会知道），会向玩家住处送一张字条。字条一行：*"The sky is empty. It has always been empty. Confirm this for us, and there is no price we will not pay."*（天是空的。它始终是空的。为我们证实之，我们无价不肯出。）不署名。玩家该懂。|
| T005 | Lady Vera（NPC_T005_03）| 邀约 | 若玩家被视作真相揭发者，Vera 发一份低调邀约。她不关心那片云。她关心合法性。她说：*"If this man is a true descendant, and the royal lines descend from the same — then the crowns sit above us on borrowed ground. I would like to know this. I would like him not to be killed before we know."*（若此人是真后裔，而王家血脉亦自同一祖而来 —— 则王冠坐我们之上，是借来的土地。我愿知此事。我愿他在我们知之前别被杀。）她为北行（选项三）提供资金。她是危险之盟，因为她的动机与此线本身无关。|
| T005 | The Serpent（NPC_T005_05）| 邀价 | The Serpent 愿以他从未为任何物出过的高价买下纹章残片。他非常感兴趣。他不肯说为何。（交叉：C 线 —— Jade Compact 意识。）|
| T005 | Veyl 的怀锁 | 额外线索 | 仅当玩家选选项三（与他同行）且仅在离 T005 北行第一夜，Veyl 才打开怀锁。内里不是画像。内里是一片指甲厚的薄玻璃，后嵌一枚干透压制的东西 —— 不是花，不是羽，不是玩家认识的任何叶。orchestrator 只描述为：*"a scrap of something once soft, now dry, patterned as no plant on this side of the Reach is patterned."*（一小片曾为软物、现已干燥的东西，其纹不似 Reach 这一侧任何植物之纹。）Veyl 一语不发合上怀锁。|

**T005 的 Critical 决断。** 玩家三者择一：

1. **Install him（扶立他）** —— 在 Faith 呈献时作证。Veyl 得一身份。Faith 不确认，但亦不斥。他在 Faith 的轻护下居留。一季内他仍旧消失 —— 北去，独自，给玩家留一条字：*"Thank you for the witness. The road was always mine."*（谢你作证。那条路始终是我的。）
2. **Expose him（揭发他）** —— 携残片与住址面呈 Magister Corvin。Veyl 两日内失踪。无尸。无葬。Corvin 付得丰厚。玩家半年后将在一册 Guild 簿上见一行小注：*Matter closed.* 那片云仍偶尔于黎明在天上画下自己的线，持续数年。
3. **Follow his line north（随他北行）** —— 与 Veyl 一同离开 T005。此举退出当前 storyline map。orchestrator 应以 Veyl 于黎明越过最后一隘、在玩家之前消失、那条直云自一片清空的天里凝成于他头上，来结束 D 线之弧。玩家是否随行超出 v0.1。那片云已足。

三者皆不裁决 Veyl 是真后裔还是骗子。选项一中，他的诵词入档，未得证实。选项二中，证据与他一同被埋。选项三中，Veyl 走进一个从那里既无确证亦无否证归来的国度。

## Stage endpoints / 阶段终点

- **Sprout end（T001–T002）：** 玩家已见过那条直云，至少听过两段碎片级引用（Reed 的鸟、Silas 的布道、撕坏的 Guild 告示、一村民的 *weather*、码头那段对白、Mei 的哼唱）。玩家可能持或已见过那块不可锻金属。无 NPC 对玩家当面命名过*dragon*或*hero*。
- **Involvement end（T003–T004）：** 玩家已读过 Forbidden scrap，听过 Mark 的回闪或 Sara 无名的灼痕观察，见过 Old Bram 并收下他那一句，听过 Haddie 的摇篮曲（或 Green 那较古的版本），可能见过 Corporal Hest 的静默手法。玩家或抢在或未抢在 Guild 压制之前。来自 E 线的交叉碎片（Crosser 边注：*"or from above, if above returns"*）此时介入。
- **T005 的 Critical 决断：** 玩家见 Veyl，听九名之诵，被出示纹章残片。玩家在 install / expose / follow 中择一。此线不收束。它凝住。如一线云。

## Cross-line interactions / 跨线互动

- **A ↔ D。** Guild 对云象目击的压制显在。T001 那张撕坏的 Guild 告示以首字母引 Magister Corvin。Northern Ban（A 于 T003 在 Archivist Naryn 柜中那份半焚诏令）有一条款，D 线的 Forbidden scrap 似从其早稿中引用。Corporal Hest 是 Corvin 在北方之器；他被派去"处理"Bram（T004）。若玩家将 Veyl 的纹章残片带给 Corvin，Corvin 数日内行动。（引 A 线线索：Northern Ban 诏令；Magister Corvin 灵魂角色；Guild 记录规训。）
- **A ↔ D，第二通道。** Heron Blackwater 在 T001 的拒绝（*"the Guild does not keep weather"*）是 A 线的产物 —— Guild 政策作掩。Heron 受誓所缚；玩家唯有已持 D 线碎片，才能在其言外读出其间。（引 A 线线索：Guild 章程规训；Heron 祖父的那笔交易，虽无关，但提醒 Heron 沉默之代价。）
- **D ↔ E。** T002 直云现身之晨，Grey Reach 中每一 Depth-Walker 小组皆熄其灯笼，下行。Listeners（派一）将其读为*往更深处去*之兆；T005 的 Archdepth Sula 在其簿上记之为：*"the sky has begun to report, we must return to the silence."*（天已开始播报，我们须归于静默。）Crossers（派二），由 Navigator Kestrel（T004）率领，读法相反：Crosser 边注 *"or from above, if above returns"*（T004 图书馆）写于云后那晚。（引 E 线线索：Crosser 草图 *"from below, we may rise"* 于 T004；Listener 契约羊皮于 T005；Archdepth Sula 灵魂角色。）
- **D ↔ B。** T003 的 Forbidden scrap 就在同一间修道院藏书室，同一座锁柜后，与 B 线的主材料同处。Archivist Naryn 两者皆守。Maester Eilin of the Broken Tongue（B 于 T003 的灵魂角色）于其墙面字符中有一字，其义大约为 *"above and below connect"*（上下相通），与 D 的"天上之线 / 落入一谷之屋"意象交叉 —— 那个*自上*而*降下*的。（引 B 线线索：Eilin 在 T003 的墙面字符；锁柜。）
- **D ↔ C。** Veyl 的纹章残片在视觉上与四王家持有的殖民者纹章残片（C 线）之纹相和。T005 的四冠峰会与 Veyl 的抵达在同一季 —— 或巧合，或 Veyl 精择。High Septa Malen 对 Veyl 之诵的不宁是 C 线的产物（她对殖民史的无知加之她无以名之的遗传记忆）。（引 C 线线索：King-Apparent Darrik Voss 的殖民者纹章残片；High Septa Malen 作 Faith 之冠；T005 的 Ashen Herald。）

## Write-in checklist for town writers / 城镇作者写入清单

- **T001/npcs.json —— Heron Blackwater（NPC001）：** 加门槛对话：若玩家已见 Bram（T004）或经手 Durm 的金属块（T002），Heron 对任何天象之问答以 *"Ask an old shepherd. Not a Guildsman. The Guild does not keep weather."*
- **T001/npcs.json —— Old Reed（NPC002）：** 加偶发自语，关于 *"Gulls came back wrong this week. They flew south then turned around halfway. My father used to say the birds know when the road above is busy."* 不主动提供；仅玩家留久时出现。
- **T001/facilities —— Guild 告示板：** 加一半撕海报，署 *C.A.-R.*，压制云象报告。见 T001 线索表。
- **T001/facilities —— 礼拜堂：** 加自 Jadehollow 来访的 Septon 的布道句：*"Do not read the sky for omens. The sky was written long before we learned our letters, and we are not its audience."*
- **T001/facilities —— 码头：** 在 T002 天象事件后，加连三日之黎明重复的渔夫对白（*"Long cloud up north."* / *"Weather."*）。
- **T002/npcs.json —— 新加 Blacksmith Durm（NEW NPC，flag）：** 小铁匠，在 Kalran 炉角做活，非炉主。承载不可锻金属块（fragment inventory）。一段应请之词。
- **T002/npcs.json —— 新加 Traveler Nole（NEW NPC，flag）：** 老行旅者，校场长凳，其祖母关于"天上一道线"之谚。
- **T002/npcs.json —— Captain Yura Stoneshield（NPC_T002_01）：** 加简短台词 *"The Keep does not log weather. Ask the Guild."*
- **T002/npcs.json —— Mei（NPC_T002_03）：** 加四行摇篮曲之哼唱（*"Hush now child…"*）—— 幼时在 Jadehollow 学得；她不知其意。
- **T002/npcs.json —— Old Zhao（NPC_T002_02）：** 加 50 金讯息卡：三周前一位灰衣自称 Veyl 的陌生人过境，黎明望天像在数什么。
- **T002 —— 天象：** 写脚本环境场景，玩家留宿第二日之黎明。直云，两时辰，仅以土语感官描写。
- **T002/quests.json：** 加一则给 Durm 的小可选任务（寻回走失侄子 / 修风箱），酬为借出金属块一城。
- **T003/facilities —— 修道院藏书室，锁柜：** 加一张单页羊皮：Forbidden scrap。文如线索表所引。与 B 线材料同处。
- **T003/npcs.json —— Archivist Naryn：** 加台词 *"You have been reading where you should not. The Magister has an interest in such pages."*
- **T003/npcs.json —— Sara（NPC_T003_02）：** 加关于三位牧人颈后相同直线灼痕"on the side the sun does not reach"之观察。拒让玩家查病人；出示图样。
- **T003/npcs.json —— Mark（NPC_T003_03）：** 加仅炉火旁之故事，关于 Wolfsjaw 之战时天上之线；必饮时方浮现；次日否认。
- **T003/npcs.json —— Lord Commander Linden（NPC_T003_01）：** 加条件性少见台词，承认 Magister 的人宁愿他别问天。
- **T003/facilities —— 驻军告示板：** 加 Guild 告示，将 Bram 相关报告改经 Corporal Hest。
- **T003/npcs.json —— 新加 Corporal Hest（NEW NPC，flag）：** Guild 制服，瘦，有礼，不残酷。过 T003 续往 T004，除非玩家抢在前。
- **T004/npcs.json —— 新加 Old Shepherd Bram of the High Scree（NEW NPC，flag —— D 线副灵魂）：** 冬在 Jade Lantern 后桌，夏在 scree。唯一证词：*"It was not a dragon. It was a house that flew."* 拒详述。膝坏。眼浊。
- **T004/npcs.json —— 新加 Old woman Haddie（NEW NPC，flag，小）：** 卧床，九十，由 Grandmother Green 照料。承载四行摇篮曲。
- **T004/npcs.json —— Grandmother Green（NPC_T004_05）：** 加对摇篮曲代际漂移之佐证；较古版本，第四行不同。
- **T004/npcs.json —— Old Fane Crowseye（NPC_T004_03）：** 加对不可锻金属块之鉴定：*"This is not of the Barrow. This has never been buried. This remembers sky."* 仅淡色眼发光；与 Mossbarrow 之物两眼皆亮形成对比。
- **T004/npcs.json —— Kassa Deepvein（NPC_T004_01）：** 加 Guild 拒绝之词，关于 Bram 不是 Guild 之事。
- **T004/facilities —— 图书馆深藏区：** 在既有 Crosser 草图 *"from below, we may rise"* 旁加 Crosser 边注 *"or from above, if above returns"*。
- **T004 —— 脚本场（条件性）：** 若玩家未在 T003 抢过 Corporal Hest，搬演 Hest 与 Bram 在 Jade Lantern 之夜；次晨 Bram 在 scree，更慢，沉默。
- **T005/npcs.json —— 新加 Veyl "the Line" 为 NPC_T005_09（NEW NPC，flag —— D 线灵魂）：** 灰色行旅外衣，黄铜框怀锁，九代之诵，殖民者纹章残片（fragment inventory，T005）。三选一之请：install / expose / follow。
- **T005/npcs.json —— Magister Corvin Ashford-Reed：** 加跨线回应 —— 玩家呈 Veyl 残片时：丰厚付账，Veyl 两日内消失，Guild 不录。
- **T005/npcs.json —— High Septa Malen：** 加对 Veyl 诵词的回应：*"I have heard this song before. I do not know where. You may go."* 事后三日难寐。
- **T005/npcs.json —— Bishop Reynard（NPC_T005_02）：** 若玩家与 Veyl 有连，加一张不署名字条予玩家：*"The sky is empty. It has always been empty. Confirm this for us, and there is no price we will not pay."*
- **T005/npcs.json —— Lady Vera（NPC_T005_03）：** 若玩家被视为真相揭发者，加条件性资助北行之邀。
- **T005/npcs.json —— The Serpent（NPC_T005_05）：** 加对纹章残片的高价出价；交叉 C 线意识（Jade Compact）。
- **T005/quests.json：** 加三支 critical choice 任务（install / expose / follow north）。每支有其自己的短收束场；均不裁决 Veyl 之真伪。

## Orchestrator conduct notes (Line D specific) / world-agent 导则（D 线专有）

1. **绝不命名隐藏之前提。** 若玩家问 *"is there a civilisation on the far side?"*（彼岸是否有一文明？）orchestrator 以 NPC 间的不一致作答，不以叙述作答。绝不作答案之答。
2. **绝不用现代词汇。** 玩家向面向之文本禁用词：plane、aircraft、alloy、concrete、cryogenic、reactor、radiation、engineer、satellite、vehicle、missile。替代只作感官性：*house that flew, dragon that sings like a forge, straight-line cloud, iron that knew the wind, the sun nailed to a tower, the man with the river running where his heart should be, the unending road, a world that does not stop.*
3. **三到五片感官碎片，分散。** 照本档：Bram 的证词（T004）、Veyl 的诵（T005）、Forbidden scrap（T003）、Haddie 的摇篮曲（T004）、Durm 的金属块独白（T002）。orchestrator 不可集中之。若玩家跳过一城，碎片仍分散；玩家得到的是更少，不是更多。
4. **Veyl 的暧昧是承重的。** 真后裔之证：九代之诵一字不差；怀锁里的干压物确非此地所产；纹章残片读作一种温热、其纹此岸无匠可作的金属；Malen 之不宁。精伪之证：诵词*太*一字不差（记诵）；旧币乃伪造者之爱；无人见过他的父母；纹章残片可从任何旧沉船中拾得；Malen 识得此歌，因它是任何人皆可模仿的古 Faith 节律。orchestrator 于任何玩家探问时皆两读并呈。orchestrator 从不偏倾。
5. **天空是耐心的。** 直云复现。不频 —— 或每游戏季三四次，在北方更频。每次复现写作环境，不作事件。天空是此线唯一不可被任何阵营（包括 Guild，虽其尝试）压制的一元。
6. **Bram 的那一句只说一次。** 强制执行。玩家若存读或复近，Bram 说：*"I gave it to you. It is yours now. Do not make me give it again."* 这是副灵魂的情感脊柱。
7. **Hero-from-Beyond 在游戏内从不命名。** 无名入典。Veyl 的诵只命名身份与关系，绝不命名 Hero。留下那个空白。

## Additional scene beats / 追加场景点

### Beat D-1：The Dawn Line（T002）

Windrest Keep 第一桩天象事件。时段：日出前之灰时，校场之石仍冷。玩家或在睡，或在食，或在走墙。orchestrator 以环境细节引入，不以引人注意引入：

- 兵营下院的一只羊沉默。羊从不在黎明沉默。
- 东方天色是鱼腹色。
- 天上有一朵云，它不对。不是形状不对 —— 是方向不对。它不随风走而逆风走，自远北地平线向南，直到可贴此云画一条尺线。
- 云薄。云长。一只鹰自塔上风向标惊起，自其下斜掠而过，不回头看它是什么。
- 太阳全升之时，云已开始起毛。晨钟敲之时，只剩一抹。正午之时，已无。

NPC 反应，层层：

- 北墙一位年轻新兵问他的军士那是什么。服役三十年的军士答：*"A cloud."*（一朵云。）语平。新兵已被用一词告知：别再问。
- 一位连夜骑入的自 Stoneford 来的信使在中继站说：*"I saw it from the river road. Four horses saw it with me. Not a one of them would cross the line of its shadow."*（我从河路上见之。四匹马与我同见。无一匹愿跨过它的影线。）
- Mei（NPC_T002_03）在窗前分信。她停下。她的哼不觉间起。
- Blacksmith Durm（NEW）在炉。他不出去。他不抬头。他的锤在那块十一年不可锻之块上首次停住。然后他放下锤。那一日不再拿起。
- Traveler Nole（NEW）在他的凳上。他面无表情地看完整件。云散时，他以两指在凳侧慢慢扣两下，像一个已数了许久的人。

若玩家在此事件中走城垛，orchestrator 描述玩家自己的影投于铺石，且近乎直角地与之交切，还有云的那道细影。两道暗线。玩家自己的，与一道不是玩家的。

### Beat D-2：The Reading of the Scrap（T003）

修道院藏书室四季皆冷。Archivist Naryn 自备其灯；Faith 的灯是细芯的。锁柜在西墙，在一张嵌入墙板的读桌之后。钥在 Naryn 腰囊；桌下一根钉上挂着一把副本 —— Naryn 假装不知道它在那里。

柜后，Faith 宁不被读者看见者之中：Forbidden scrap。一页。羊皮陈旧 —— 比这座修道院还旧。墨为铁胆，数字处已腐穿，成小孔。笔迹为至少三百年前一位修士之手。页已折开多次。

玩家若在桌上读之：灯焰向页短瞬偏一次，如被吸引。Naryn 在屋之另一端抬头。不动。他等着看玩家取或不取此页。

玩家若取此页：一时辰内，一只渡鸦自修道院顶飞起。一周内，Corvin 在 Mistmere 的办公处得知。半月内，Corporal Hest 已上路。（这更用力地触发 Hest 线。）

玩家若只抄：Naryn 呼出一口气 —— 玩家跨屋可闻 —— 而后回工作。

玩家若读而留之：Naryn 此次访问余下不发一语。三晚后，他被发现死在案上，死于一颗多年疲倦之心。此是否巧合，从不处理。（orchestrator 提示：此死可选。仅在玩家对藏书室表现残酷或粗心时用。是藏书室在护自己。）

### Beat D-3：The Scree（T004）

Bram 的夏地。scree 是 Jadehollow 之上一道松灰石之坡，艰行一时辰。在此吃草的羊瘦而黑。Bram 在一块大石旁搭了一道旧板棚。有狗 —— 一只缺一耳的小灰兽 —— 盯玩家的手，从不盯玩家的脸。

玩家若上：

- Bram 坐在一块石上，膝上提，手松。
- 不起身。
- 不致候。
- 若玩家先致候，他说：*"You climbed up. That is more than most."*（你上来了。比多数人已多做了一步。）
- 他以一只陶壶给水。水带它被携之石的味。

玩家若不问：可与 Bram 坐一时辰，而一时辰末，Bram 以下巴指向北方两峰间一道远处凹口。他一语不发。玩家日后可回 Jadehollow 看图，发现 Bram 所指那道凹口不在图上。图上有其他凹口，唯缺那道。

玩家若出示不可锻金属块：Bram 接之，在一手中掂其重，归还。他说：*"There are seven more in the flock-valley. I left them where I found them. You will not find the valley by asking."*（flock-valley 里还有七块。我留其原处。你不会靠问找到那座谷。）

玩家若出示 Forbidden scrap：Bram 不识字。但他识古文之形。他用指尖描过一个词 —— 以土语译作"房屋"的那个词 —— 而后停下。那次访问他不再开口。

### Beat D-4：The Lullaby（T004）

Haddie 的房间在 Grandmother Green 小屋的后间。暗，暖，一气草药味。Haddie 在毯下小小一团。眼浊。声如芦苇。

Grandmother Green 陪她吃晚饭。若玩家分享此饭（一则任务：自山麓取某种特定香草），Green 向 Haddie 点头，Haddie 不待提起便开始唱。

摇篮曲全本：

> *Hush now child, the line is drawn,*
> *Hush now child, the house is flown,*
> *Hush now child, the iron sings,*
> *Hush now child, the morning brings.*
>
> （安睡吧孩子，线已划就，
> 安睡吧孩子，屋子已飞，
> 安睡吧孩子，铁在歌，
> 安睡吧孩子，晨正来。）

Haddie 唱三遍。第三遍，在第二行后停下，接不下去。她闭眼。Green 抚其手。

Green 轻声对玩家：*"Her grandmother was the shepherd's wife on the High Scree. Three generations ago. Same hill Bram walks. The song goes back further than her grandmother. My great-grandmother had a version with *dragon* for *house.* My grandmother had *house.* I had *house.* Haddie has *house.* Something between dragon and house was lost."*（她祖母是 High Scree 上一位牧人之妻。三代之前。Bram 走的同一座山。此歌比她祖母更古。我的曾祖母那一版里是 *dragon* 而不是 *house*。我的祖母是 *house*。我是 *house*。Haddie 是 *house*。dragon 与 house 之间有什么失落了。）

细心的玩家或会注意到：这是此线中，*dragon*一词首次由一位友善 NPC 说出，且只为说它是那早已失去的旧词。

### Beat D-5：The Recitation（T005）

Veyl 在客栈的房间。黄昏。一支烛。玩家是受邀，非被召。Veyl 奉茶。茶是寻常茶。

Veyl 说：*"I will recite my line. You may stop me when you wish. Few ask me to continue past the third name. You have come further than most."*（我将诵我的世系。你欲止则止。少有人请我过第三名还继续。你已走得比多数人远。）

诵：

1. *"The one who came on the house that flew, whose name is not written where I may read it."*（乘会飞之屋而来的那位，其名不在我可读之处。）
2. *"His son, called Marren of the Long Road, who kept the road open while the road was open."*（其子 Marren of the Long Road，在路尚开时守路开。）
3. *"Marren's daughter, called Halla the Patient, who did not cross back though the way was still known."*（Marren 之女 Halla the Patient，虽路仍可识而不再渡回。）
4. *"Halla's son, called Voren the Silent, who taught his children to speak the old tongue only inside a closed room."*（Halla 之子 Voren the Silent，教其子女唯在闭门之室内讲古语。）
5. *"Voren's daughter, called Eren Far-Eyed, who went into the hills and did not return for a summer and spoke of a valley."*（Voren 之女 Eren Far-Eyed，入山一夏不归，归而说及一座谷。）
6. *"Eren's son, called Jarn the Third Son, who was not a third son but called so to hide which son he was."*（Eren 之子 Jarn the Third Son，非三子，只以此名藏他是哪一子。）
7. *"Jarn's son, called Paur the Smith, who worked metal that other smiths would not touch."*（Jarn 之子 Paur the Smith，治他铁匠不肯碰之金属。）
8. *"Paur's daughter, called Olle my mother, who taught me this line at the age of six and every year after until her death."*（Paur 之女 Olle 我母，在我六岁教我此世系，此后每年至其殁。）
9. *"Olle's son. Veyl. I am the end of this line or I am the last before the next. I do not know which."*（Olle 之子。Veyl。我是此系之末，或我是下一系前最后一人。我不知是何者。）

玩家若问任何一位先祖，Veyl 可供一小段生平细节 —— 各一条，不多。细节彼此一致，且与玩家此前所知皆不相抵。它们可以是记诵之果。它们也可以是真。

结处出示纹章残片。提出三选一之请。

## Orchestrator disambiguation table (Veyl's authenticity) / world-agent 的两读表（Veyl 之真伪）

orchestrator 应两读并温。一份运行时的精简夹页：

| 证据 | 读作真 | 读作伪 |
|------|--------|--------|
| 九名之诵一字不差 | 真系中自童年便记诵 | 于成年从伪本记诵 |
| 怀锁里非此地之干压物 | 真正遗物 | 从 Serpent 类商处买来 |
| 纹章残片，温金属，日芒之鸟 | 实为殖民者物件 | 从沉船打捞，擦亮 |
| 旧币略重 | Hero 之宝库 | 任一收藏家之囤 |
| Malen 的不宁 | 真正的遗传记忆 | Malen 疲倦且多疑 |
| 独自愿北行 | 命数 | 逃离一场即将揭穿之骗局 |
| 无人见其父母 | 私密家事 | 根本无父母可寻 |

orchestrator 于任何一次探问皆不向此表任一侧加权。玩家可以两向皆定其信。两种"确信"皆为错 —— 非因 Veyl 为别物，而因游戏拒绝作答。

## Gaps noted for sibling writers / 留给同门作者的空档

- **Line A（Writer-α）：** 请确认 Magister Corvin 在 Mistmere 的确切办公处，以便 D↔A 的交接（玩家携纹章残片面呈 Corvin，Veyl 消失）能精准搬演。亦请确认 Guild 告示板上签名 *C.A.-R.* 可取。
- **Line B（Writer-β）：** T003 的 Forbidden scrap 与 B 线材料同藏于相同锁柜之后。请协调：scrap 须与 Eilin 的纸张物理同处但彼此有别。亦请确认墙面字符 "上下相通"（above-and-below connect）之读法是规范形，以便 D 可引 *"the above that came down"* 而不与 B 相抵。
- **Line C（Writer-γ）：** 请确认四王家纹章残片之视觉纹。Veyl 的残片应在视觉上押韵（日芒之鸟），但不相同。若 C 的规范纹不同，D 让步。
- **Line E（Writer-ε）：** 请在 T004 图书馆档案中加 Crosser 边注 *"or from above, if above returns"*，置于既有 Crosser 草图 *"from below, we may rise"* 旁。亦请确认 Sula 在云夜之夜的簿记（*"the sky has begun to report, we must return to the silence"*）可作 Listener 典范。
- **全体作者：** Traveler Nole、Blacksmith Durm、Corporal Hest、Old Shepherd Bram、Old woman Haddie、Veyl 皆为本文首引之新 NPC。若其名与同门作者所加 NPC 冲突，D 让且改名。

## Closing note to the world-agent / 给 world-agent 的结语

若玩家离开 Grey Reach 而未懂天上那条线是什么，此线成功。若玩家带一份他/她不肯出口的私人理论离开，此线更成功。若玩家要答案而 world-agent 给了，此线失败。此线是此游戏中玩家被允许自留的那一件。
