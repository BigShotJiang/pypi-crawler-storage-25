# 审校报告 —— Stoneford 主线

> 源文件：../_CHECKER_REPORT.md  · 译文仅供审阅，以英文原版为准

## 总评

**needs-editor-pass（需要一次主编通校）。**

五条主线内部丰厚、调性一致，对"隐藏前提"的克制上仅有一处近乎泄漏（D 线的 Forbidden 残页把《共享简报》里那组被禁的词汇逐字抬进了玩家可见的道具，但仍留在许可的本土感官语域之内）。有**三处硬矛盾**——若不调和，将在 world-agent 层击穿；**四处跨线短语／数目失配**——需要一次统一的主编清扫；以及**一处 NPC 名册碰撞**（Septon Silas：T001 vs T004）。无一属于重写，皆可在逐行编辑层面调停。

## Blockers（必须在主编通校前修复）

- [x] **B1. Septon Silas 的居所矛盾。** 现有城镇名册（`NeonRP/examples/stoneford-orchestrator/game/towns/T004/facilities/chapel.json` 与 `T004/quests.json` 的 Q_T004_05）将 Silas 定为 Jadehollow 的 Dawn Chapel 的常驻 Septon。《共享简报》的残片清单把石片分派给 "Septon Silas · T001"。A 线 T001 clue 表写作 "Septon Silas (NPC_T004_07)"（即从 T004 来访）。B 线明确地把这一点标为开放空缺（B/gap 1）。E 线一处写 "Septon Silas at T001"，另一处写 "Septon Silas (NPC_T004_07)"。C 线不触及住所，只在 T003 处引述 Silas 收到一封被拒的信。**决议：** Silas 主条目留在 T004；给 T001 加一个"在第三夜散步来访"的 hook（不新建 NPC 条目）。四线必须统一采用此措辞。B 线已提出这个解法；各线照办。

- [x] **B2. Hallen 的位置矛盾。** B 线 T004 把 Hallen 定为在 Jade Lantern 酒馆后屋的疯归者（T004 clue 表与 write-in checklist："NEW NPC — Hallen the mad returnee … T004"）。E 线 T005 则把 Hallen 定为"沉没厢房的病房里"的新 NPC，六十岁，并把**完全同一句**的理论台词（"Below and beyond are one. The floor is the far wall."）与《共享简报》的 Theory-3 canon 交付归给他。**两位写手在两座不同城镇里实例化了同一个 NPC。**《共享简报》只写 "Hallen (mad returnee) ravings"，并未指定城镇。**决议：** Hallen 落在 T005 病房（E 的落位与《共享简报》的脉络相符：Listeners 的病房、Theory-3 在 Critical 交付）。B 线 T004 酒馆的 Hallen 场景应降格为*一名无名的、说话带韵律的酒鬼*，或*Hallen 从崖屑坡过冬下山时的 T004 短暂客串*。主编择一取舍。

- [x] **B3. Preceptor Vossel 血统矛盾。** C 线（cross-line B↔C，第 468 行）宣称："Preceptor Vossel the Younger（B 副灵魂，T002）是 House Voss 的堂兄弟 —— Darrik 一脉。他在修道院里静默的存在本身就是一项王家安排：Darrik 的父亲把他流放到 Faith 的僧团，好让 Voss 血脉在 Septa 的家中留有一只沉默的眼睛。" B 线的 Vossel 是 Faith 的抄写员，没有任何血统暗示；B 线附录 J 与 write-in checklist 显示一位神经质的年轻抄写员，功能是偷渡 Eilin 的手势。把 Vossel 变成被 Crown 安插的 Voss 堂弟*根本性地改变*了 B 的信任逻辑 —— Eilin 的私渡者其实是王家的眼。B 线在 gaps 里标记为 B/gap 6（清洁再分派 vs. 隐叶），C 也标记（C/gap "B↔C — Vossel 血统"）。**决议：** 主编择一。建议：**放弃 C 侧的这一断言。** 这是 C 的后加，破坏 B 的 Vossel 完整性，且在 C 里并不承担任何结构性作用（Herald 和第五扇门才是 C 的承重）。若保留，B 必须加一处安静节拍 —— Vossel 认出一枚 Voss 拇指戒而不作声 —— 并把他偷渡 codex 的行为重新框定为*出于自身意志*，与他的出身无关。

## Serious（主编应修）

- [x] **S1. Northern Ban 起草日期 vs. Eilin 被噤日期。** B 线（Function + T005 Corvin 对白）：Eilin 十一年前被噤；Northern Ban 是*同一季*草拟的。A 线 Corvin 灵魂角色写"已九年未眠一整夜"（他自己任期），A 的 T005 Corvin 对白写 Charter 创立于两百年前，并未对 Ban 的起草日给出"十一年前"的主张。A 的 T001 与 T003 clue 表描述半焚诏令为"七年前"被焚，并未给出最初起草日期。**B 宣称 Ban 草拟 = 十一年前；A 沉默。** 主编：批准 B 的日期，并在 A/T005 Corvin 对白中加入一句（"The Ban was re-drafted eleven years ago, in the same season a maester's tongue was taken in the north"）。对应 B/gap 3，也是 A 对 B 的 gap。

- [x] **S2. Northern Ban "四句本土感官短语" vs. 石片短语顺序。** A 线 T003 Naryn 柜中诏令引用的顺序为 *"sun-nailed-to-tower, house-that-flies, iron-that-sings-like-a-forge, the-unending-road"* —— A 请 B 确认。B 线表示诏令引用的是"石片的开头字符"（单数，非四句），并且 B 的石片承载**十七枚字符、三行**，而非四句短语。D 线 Forbidden 残页逐字引用了 A 四句中的三句（"the house that flew … iron that knew the wind … do not attempt to visit"）。**矛盾在于：** A 把 Ban 的运作条款视为四句离散的本土感官短语；B 则把石片视为字符载体（非短语载体）。**决议：** 主编把 A 的四句提升为 canon（它们是本次成稿中最佳的文字，D 也已逐字引用）；B 改写措辞：*石片承载字符；字符翻译为那四句被命名的目击；Eilin 没有解译，Naryn 的前任做过。* A 的 checklist 项"T001/items 加上古石片"仍在 B 手中；无需重写，只在 B 加一句对齐即可。

- [x] **S3. Ban 签署 —— "三冠签字" vs. "全四冠"。** E 线 T005 contract-parchment 上盖有"三冠之印；第四冠缺席"。E 明确把缺席归给 Free North（Brenna）。A 线 T005 把 Charter（创立）描述为由最初四冠签署；A 未陈述*当代* Ban 有几冠签署。C 线 T003 诏令（半焚）"由四冠最初仲裁席共同签署"—— C/E cross 说 "Brenna Greyhold 的前任拒绝联署、在一年之内被更替"（B↔C）。但 C/T005 contract 揭示 Listener 契约为三冠，Brenna 弃签。**问题：** 若 B↔C 说 Brenna 的前任因为拒签而被更替，Brenna 自己不应能在*同类文件*上弃签而无事。**决议：** 区分两份文件。(a) Charter/Ban 为四冠（B↔C 正确）。(b) Sula 桌上的 Listener 契约是一份更狭义的 crown-operational 契约（并非 Ban 本身），三冠合法，因为 Free North 历史上的签字是一项 Charter 级行为，而非 Listener 级。E 在 T005 加一句对齐（"the contract is not the Ban; it is the Listener bond under the Ban, and Brenna has never signed one"）即可解。对应 E/gap 1。

- [x] **S4. 根字符重叠计数。** B 主张石片 ↔ 铁龙（永生×黄金×无穷）**两处**重叠（附录 J，位置 3 与 10）。D 线 B-cross 说 "two root glyphs" —— 一致。B 主张石片 ↔ Crosser 草图 **三处**重叠、石片 ↔ 修道院墙 **三处**重叠（"kin, not the same hand"）。E 说草图"与 T001 石片以及 Eilin 的修道院墙（B 线）至少共享三枚根字符" —— 在*三*上一致。A 对数目无记载（恰当地超出其范围）。**三册现已对齐为 2/3/3。** 无需动作，除非主编希望在每份文件里钦定一种单一措辞。低优先级整饬。

- [x] **S5. Ashen Herald 的身份候选清单。** C 线把 Herald 的身份留开，给出四位候选（"Jenn；Tobiah 的双胞胎；Darrik 出生之前被流放的 Voss 堂亲；Brenna 的官方不存在的姐姐"）。A/B/D/E 均未提 Herald，唯 D 提一次（"Veyl 的纹章残片的花纹与四王家各自所持的殖民者纹章残片视觉呼应 …… T005 的 Ashen Herald"）。**问题：** C 的 T005 与 Brenna 会面场景的跨写手候选注释说"Jenn 是 Brenna 的外甥女"，而 C 的 Herald 档案说 Jenn 独自偷走了密码 —— Herald 并未雇用她。若主编钦定"Herald = Brenna 的姐姐"（C 四候选之一），Jenn 的外甥女条即 Brenna 的外甥女 = Herald 的外甥女，是一条干净的线。若主编选"Jenn 本人 = Herald"，则 Jenn 外甥女条必须删除。**决议：** 主编择一。建议：Brenna 的（官方不存在的）姐姐 —— 与 C 的殖民记忆逻辑相契（Brenna "记得却不能说"），且保留 Jenn 作为低阶信使（外甥女）。

- [x] **S6. Bram 的年龄 / 送信过往。** C 线（C↔D cross）宣称："Old Shepherd Bram（D 副灵魂），年轻时曾为 Brenna 的祖母与 Darrik 的祖父递送讯息；若被问，他只会说一句：*'The old chieftess and the old king used to write each other in winter. They wrote in the same hand. They learned to write from the same woman.'*" D 线把 Bram 描述为"六十来岁，脸上深纹，一只眼翳浊，左膝跛"。Brenna 的祖母与 Darrik 的祖父应活跃于约 60–90 年前；Bram 六十来岁，"年轻时"送信只能最多是 45+ 年前，送给的其实是这两位王族的*后代*，而非祖辈。**数目张力。** 解法：(a) 把 Bram 改为七十五岁（可编辑）；(b) 把 C 的那句换成"Bram 的父亲送信"（最干净、最小伤害）；(c) 把王族改成"Brenna 的母亲与 Darrik 的父亲"。D 线 gap 注（γ 级）已标记。主编：采 (b)。

- [x] **S7. "Ashen Herald" 与 "Ashen Howe" 重叠。** A 线引入 **Factor Selm Ashen-Howe**（T003 Guild 代办，"Ashen 堂支"）。C 线的副灵魂是 **Ashen Herald**（戴面具，无名，无家）。*Ashen* 在两线用作两种语域：作姓氏前缀（Ashen-Howe、Ashen 堂支）和作颜色描述（灰烬色的斗篷、未上釉的陶）。Faith 的衣装也是"湿灰色的袍"。不算严格矛盾，但有命名撞色，主编应留意。**决议：** 将 A 的 Factor 改名为 **Selm Orren-Howe** 或 **Selm Cole-Howe**（避免让 "Ashen" 担任姓氏角色），把 "Ashen" 保留给 Herald 的未上釉面具语域。低优先级，但影响玩家端的语感。

## Minor（次要问题）

- [x] **M1. Crosser 草图字符计数对齐。** B 说"三枚根字符沿草图下沿，两枚与石片重叠，一枚重叠在港墙内面"。E 说"至少三枚根字符与 T001 石片以及 Eilin 的修道院墙（B 线）共享"。E 的*至少三*与 B 的精确*三*相容，但 B 的精确应升为 canon。在 E 里添上"三"。

- [x] **M2. Abbot Merick 在 B-Outcome 1 中的去留。** B/gap 7 标记此项：若 Faith 撤下 Eilin 的书板，Merick 是抵抗 / 顺从 / 辞职？其他线无意见。B 的默认（顺从 + 本季辞职）可用。非阻断；主编可保留默认。

- [x] **M3. Brenna 的容忍 vs. Ban 的一致签署。** 提示词 G 中的 ε 级问题。由上述 S3 解决（区分 Charter/Ban 与 Listener 契约）。无需额外修。

- [x] **M4. 云夜的时序。** ε 级：E/gap 2 —— 确认云夜在 T005 E-告白*之前*。D 线从未给云设定绝对日期，只说"T002 第二日晨"与"每季复发三至四次"。C 线把"直线云在峰会次日晨出现于 Mistmere 之上"放在 Endpoint 2 —— 但这是*复发*，非 T002-hook 的那一次。**无矛盾**，但主编应在 D 的 world-agent 行为里加一行注："T002 萌芽云是最早的一次；复发乃常态。T005 的 E-告白发生在某个云夜 —— 若节奏紧凑，可能就是萌芽云；否则为后续复发。"

- [x] **M5. Eilin 粉笔板语域。** E 请 B 允许 Eilin 携带两句具体台词：*"he keeps them"*（关于 Kestrel 保留她的图画）与 *"the ring is untrue"*（关于灯笼第十点的离心）。B 粉笔板语域中已有 *"The lantern is not of the cell that claims it. The ring is untrue. Who gave it to you?"* —— **匹配确认。** B 目前未收录 *"he keeps them."* 主编：在 B 的 T003 clue 表加一条粉笔句："若问起她失落的草图，Eilin 粉笔书：'he keeps them.'" 对应 B/gap-cross-E。

- [x] **M6. Bram 的草场 Listener 目击。** ε 级。E 请 D 在 Bram 对话中加一句：关于灰袍人于黄昏时、持未点燃灯笼、穿过他高处牧场。D 现有 Bram 无此句。主编：在 D/T004 Bram clue 表加（按 E 所请措辞）："Grey-coated folk. The earth-men, maybe. I do not trouble them and they do not trouble me."（灰袍之人。或许是地底之人。我不扰他们，他们也不扰我。）无争议。

- [x] **M7. Corvin 办公处处理支付的位置。** α 级。E 的 door-2（向 Guild 告发）把羊皮纸交到"T005 的 Magister Corvin Ashford-Reed（Guild 灵魂角色，A 线）或 T001 的 Guild 支部"。A 已把 Corvin 置于 T005 High House，四种结局（Reform/Burn/Break/Inherit）都写完 —— 但未给 E door-2 的羊皮纸交付指定*封印信件支付*的处理节点。主编：在 A/T005 Magister Corvin 节拍中加一条："若被出示 Listener contract 羊皮纸 —— 他默读，经 Hess Veigh 之手以封印信件付款，不称呼玩家之名，亦不邀请其再来。" 对应 E/gap 3 与 δ 级。

- [x] **M8. Veyl 的殖民者纹章残片 ↔ Darrik 的殖民者纹章残片。** 《共享简报》把 "colonist crest fragment · Veyl's pocket · T005 · D（+殖民史）" 的坐标给了 Veyl。C 的前史（"Crown · King-Apparent Darrik Voss —— 饮不老茶；有一枚殖民者纹章残片"）也给了 Darrik 一枚。C/D cross 说 "Veyl 的纹章残片的花纹呼应四王家所持的殖民者纹章残片"。**存在两枚残片：** Veyl 的（口袋中，D 清单）与 Darrik 的（Crown 私藏遗物，C）。这**不是**重复。清单上的是 Veyl 的；Darrik 的未进清单，因为它不转移给玩家。主编：在 C 的 colonial-shadow 附录加一行，澄清 Darrik 的纹章*不是*清单物，亦不可转手。

- [x] **M9. Corvin 封印信件支付。** ε 级。由 M7 覆盖。无独立修复。

- [x] **M10. Sula 账簿 / 慢石审计。** δ 级。E 的 Listener 契约与慢石审计机制内部自洽。无他线引用。无动作。

- [x] **M11. Crosser 旁批采用。** δ 级。D/T004 在 E 的草图旁添加了 "or from above, if above returns" 的 Crosser 涂鸦。E 的 T004 clue 表收录了草图但未引用 D 的涂鸦。主编：在 E 的 T004 表加一行交叉注："A second hand has written beside the sketch 'or from above, if above returns.' This is a Crosser response to the cloud, per Line D."（另一只手在草图旁写下 'or from above, if above returns.'（或自上方，若上方归来。）这是 Crosser 对云的回应，参 D 线。）非阻断。

- [x] **M12. 王家纹章视觉规格。** δ 级。Veyl 的纹章在 D/T005 描述为"日轮上的鸟，鸟翼尖锐、角度如非鸟之翼"。C 的四结为"围绕空心的四环"。这是**两种不同的纹章**（好 —— Veyl 的纹章是个人血脉之物，四结是议事之印）。无矛盾。无动作。

## 内部已消解（无需动作）

- **Ashen Herald 的词汇纪律。** C 的 Herald 在场上从不说 *colonist*、*far side*，或任何现代词；档案仅写手可见。干净。
- **关于遗物为何在地底的四种 NPC 理论。** 四种皆由具名 NPC 在正确的城镇交付，合于《共享简报》：Naryn（崩塌-埋葬，T003/T004）、Kestrel（交通，T004）、Hallen（身份，E 在 T005 / B 在 T004 —— 见 B2）、Eilin（亲缘，T003）。只有 Hallen 的位置需择一。
- **残片清单 —— 十件全部落位。** 见下文 C 节。《共享简报》十件残片都有归宿，彼此不重复，除了两件被标为"主属 X 线、由 Y 线引用"的草图 —— 这是简报许可的做法。
- **声音纪律。** 五线都守住 low-fantasy / 本土感官语域。玩家可见文本无现代词泄漏。
- **隐藏前提。** 未在任何一线的玩家可见文本中陈述。写手后台文件（C 的 colonial-shadow 附录、E 的 dossier、D 的 world-agent 注记）均已正确标注为写手专用。
- **Eilin 永不开口。** B 附录 H 严格。无线违反。
- **Bram 的一句话。** D 强制"said once"。无他线破坏。E 的 Bram 草场目击线（M6）是*另一句*关于 Listeners 的话，而非龙之证言；约束保持。

## 详细发现

### A. 硬矛盾

1. **Septon Silas 住所** —— 见 **B1**。T001 vs T004。可修。
2. **Hallen 的城镇** —— 见 **B2**。T004 vs T005。可修。
3. **Vossel 血统** —— 见 **B3**。C 侧断言破坏 B 的内部逻辑。可通过删去 C 的主张或在 B 加一句对齐来修。
4. **Eilin 噤日 / Ban 起草日** —— 见 **S1**。接受 B 的"十一年前"并在 A 加一句 Corvin 台词即可。
5. **Ban 签署（三冠 vs 四冠）** —— 见 **S3**。通过区分 Charter/Ban 与 Listener 契约来修。
6. **Bram 年龄 vs 送信** —— 见 **S6**。换成"Bram 的父亲送信"。

未检出其他硬矛盾。

### B. 隐藏前提的泄漏

**玩家可见文本中无泄漏。** 所有写手档案内容均正确围栏在"writer-only"（C 的 colonial-shadow 附录、E 的 world-agent 注记、D 的 world-agent conduct 注记）。

**近似泄漏点：**
- D 的 Forbidden 残页（T003）中有 *"do not attempt to visit"* —— 这是《共享简报》的隐藏英雄台词，但此处以本土语域给出，嵌在 in-world 羊皮纸中，归于"the Hero"。简报许可（英雄是 in-world 人物；此句被*引作英雄的经典语录*，非作者叙述）。**OK —— 非泄漏。**
- C 的 Brenna 说出 *"Vi kam fra den andre sida"* —— *"We came from the other side."*（我们来自彼岸）这是任何一线最接近说破前提之处，简报明示许可一次、且以部族语。**OK —— 获授权。**
- D 的 Veyl 诵文用"九代"—— 不与"百年沉默"冲突（9 × 11-12 年平均 = 99-108 年）。**OK。**

B 节无需动作。

### C. 残片清单完整性

《共享简报》10 件残片恰各落位一次：

| # | 残片 | 《共享简报》位置 | 由谁落位 | 状态 |
|---|------|------------------|----------|------|
| 1 | 上古石片 | T001 · Septon Silas | B · T001（Silas 携带、转交）| ✅ |
| 2 | 旧 Guild 黄铜令 | T001 · 藏于酒馆炉下 | A · T001（Shale Lantern 炉石、Mira 的亡夫）| ✅ |
| 3 | 无法锤打的金属块 | T002 · Durm | D · T002（Blacksmith Durm，Kalran 熔炉角落）| ✅ |
| 4 | 墙面字符 上下相通 | T003 · 修道院后墙 | B · T003（主）；A · T003（引用）；E · T003（视觉闸）；C · T003（刮洗令引）| ✅ |
| 5 | 不老茶渣 | T004 · Crown 使节茶杯 | C · T004（Envoy Alric 在 Jade Lantern 的杯）| ✅ |
| 6 | Crosser 草图 "from below, we may rise" | T004 · 图书馆深藏区 | E · T004（主）；A、B、C、D 引用 | ✅ |
| 7 | 殖民者纹章残片 | T005 · Veyl 的衣袋 | D · T005（Veyl 携带）| ✅（见 M8）|
| 8 | Listener 契约羊皮纸 | T005 · Sula 的桌 | E · T005（主）| ✅ |
| 9 | 直线云（天象事件）| T002 · T001→T002 之间的天空 | D · T002（主萌芽）；B、C、E 引用 | ✅ |
| 10 | 半焚 "Northern Ban" 诏令 | T003 · Archivist Naryn 的柜 | A · T003（主）；B、C、D 引用 | ✅ |

无重复。无遗漏。跨线引用皆指回唯一的主位。

### D. 跨线依赖

《共享简报》六组依赖两侧均已落实：

| 依赖 | 落实 | 状态 |
|------|------|------|
| A↔B（Guild "Northern Ban" 引石片）| A/T003 Naryn 诏令引石片四句；B/T005 Corvin 口述 "Northern Ban" 并联到 Eilin 的噤 | ✅，仍需 S2（短语清单 vs 字符级对齐）|
| A↔C（Guild 原为四冠仲裁机构）| A/T005 Corvin 四冠起源对白；C/T005 四结印与砌死的第五扇门；C/T001 Heron "the Guild used to answer to that knot"；A 的 Reform 结局需要 C 的峰会房间 | ✅ |
| A↔D（Guild 压制云目击；施压 Bram）| A/T002 Tamsin 的压制津贴（Bram 在名单上）；A/T004 Kassa 的登记簿（Bram 分类 *sky*，三笔津贴，最后一笔加倍）；D/T001 署 "C.A.-R." 的撕破 Guild 告示；D/T003 Corporal Hest；D/T004 Hest 与 Bram 的共饮之夜 | ✅ |
| B↔E（Kestrel 收藏 Eilin 图画；草图共享根字符）| B/T004 Kestrel 理论 / Eilin 图画 + B/T005 草图字符重叠；E/T004 Kestrel 对白 "I have her drawings"；双册皆为三字符重叠 | ✅（M1 整饬）|
| C↔E（北方王族压制 Depth-Walkers）| C/T003 Linden "Septa sent riders to arrest any pilgrim who has been below"；C/T005 契约羊皮纸之印（三冠，Free North 缺席 —— 见 S3）；E/T005 契约条文；C↔E Brenna 的私下容忍 | ✅，仍需 S3 |
| D↔E（云夜 → Listeners 熄灯；Crossers 读作斥候）| D 的 T002 云；E/T002 云起时烛芯自燃，Yannic 面白；E/T005 云夜同步熄灯；D/T004 Crosser 旁批 "or from above, if above returns" | ✅（M4 时序注）|

六组依赖两侧皆有具体实现。仅 S3 需调和。

### E. NPC 碰撞

**新引入 NPC（跨线比较）：**

- **A**：Magister Corvin Ashford-Reed（T005）、Keeper-Commander Olric the Silent（墓，T003）、Clerk-Registrar Tamsin Howe（T002）、Factor Selm Ashen-Howe（T003）、Archivist Naryn（T003）、Senior Clerk Hess Veigh（T005）
- **B**：Maester Eilin of the Broken Tongue（T003）、Preceptor Vossel the Younger（T002）、Abbot Merick（T003）、Novice Taryn（T003）、Hallen the mad returnee（T004）← 见 B2
- **C**：Jenn（T001）、Ylva Stoneshield（T002）、Envoy Alric of House Voss（T004）、Darrik Voss（T005）、High Septa Malen the Unsleeping（T005）、Chieftess Brenna Greyhold（T005）、Consul-Merchant Tobiah Caul（T005）、The Ashen Herald（T005）、Clerk Ostric（T004，图书管理员小角色）
- **D**：Blacksmith Durm（T002）、Traveler Nole（T002）、Corporal Hest（T003）、Old Shepherd Bram（T004）、Old woman Haddie（T004）、Veyl "the Line"（T005）
- **E**：Yannic "Yan" Vello（T002）、Navigator Kestrel（T004）、T003 洞穴无名老 Listener、Archdepth Sula（T005）、Hallen（T005）← 见 B2、六位 T005 无名随侍 Listener

**新 NPC 之间的碰撞：** 只有 **Hallen**（B2）—— 两位写手在两座不同城镇里创建了同一位疯归者，且交付了相同的 Theory-3 经典台词。

**与现有 T001–T005 名册的碰撞：**
- **Septon Silas**（按现有 `chapel.json` 与 Q_T004_05 的 T004 名册已是 NPC_T004_07）—— A/B/C/D/E 全部引用。仅 B 造出了清晰的 T001 **来访 hook**（非新 NPC）。A/E 引用时正确加注 "NPC_T004_07"。**由上 B1 解决。**
- **Old Shepherd Bram** —— 《共享简报》置其于 T004；A/C/D/E 皆引。无碰撞；主归 D。
- **Septon Silas** 之名在 D/T001 也以"Septon（客串，来自 Jadehollow）"递送一句布道台词。与 B 的"第三夜散步至 Stoneford"一致。
- **Maester Eilin** —— 主归 B/T003；A/C/D（锁架邻位）/E 引用。无碰撞。
- **Factor Selm Ashen-Howe** —— 见 S7（仅语域撞 "Ashen Herald"，非角色碰撞）。
- **Preceptor Vossel the Younger** —— B 创造；C 重分派血统（见 B3）。非重复；是有争议的刻画。

其他无名册碰撞。既有 NPC（Heron Blackwater NPC001、Old Reed NPC002、Mira Ashford NPC003、Captain Yura NPC_T002_01、Old Zhao NPC_T002_02、Mei NPC_T002_03、Brown NPC_T002_04、Kalran、Lord Commander Linden NPC_T003_01、Sara NPC_T003_02、Mark NPC_T003_03、Kassa Deepvein NPC_T004_01、Ironpost NPC_T004_02、Old Fane Crowseye NPC_T004_03、Jade NPC_T004_04、Grandmother Green NPC_T004_05、Damon NPC_T004_06、Septon Silas NPC_T004_07、Hawke NPC_T004_08、Bishop Reynard NPC_T005_02、Lady Vera NPC_T005_03、The Serpent NPC_T005_05）在每条主线里均以正确 ID 引用。

### F. Write-in checklist 的完整性

五条主线都带有具体的 "Write-in checklist for town writers" 章节，含具名 NPC、具体对话措辞（带引号）、具体设施位置与残片级规格。

**具体可执行的 checklist：**
- A：每位新 NPC 都有名字、年龄、对话节拍、家族旗；每位既有 NPC 都有具体对话引语。✅
- B：每位新 NPC 与每处拓片点都有规格；石片有专属附录 A 物理规格与附录 J 的 17 字符示意。✅
- C：新 NPC 完整；四种材料特征固定为不可商；三层注释纪律作为写手专用工具已记录并强制。✅
- D：每位新 NPC 有角色，摇篮曲为四行 canonical 文本，Veyl 的锁钥坠 / 诵文 / 残片已规格化。✅
- E：每位新 NPC 有状态旗；灯笼含底印的完整物理规格；三项仪式已记录。✅

**checklist 自承的含糊（作者已标空缺）：** 统一于下节 G。

**主编对 checklist 粒度的关切：**
- **A/T001/Heron** 节拍极具体（"finger-stump tap the desk once, twice"）—— 好。
- **C/T001/Heron** 加入了三层注释的对话分支 —— 真正写入 npcs.json 时注释须剥除；主编只落实 `public=` 一行。
- **E/T002/Yannic** 对白明示可引。✅
- **B/T003/Abbot Merick** —— 仅一句，强制。✅
- **D/T005/Veyl** —— 三选一的问句完整成稿。✅

无 checklist 致命模糊。提示中的担忧（"*加一句关于……的台词*却不指明 NPC / 哪一句"）在此不适用；每条指令都具名某人并引其台词。

### G. 空缺汇总

提示词列出了各写手标注的空缺；汇总并标记解决状态：

**α（A 线作者的空缺）：**
- B-石片短语顺序 → **S2**（未解；需主编）
- C-峰会交付（四冠同室）→ **已解**，由 C 的 T005 Critical 场景（峰会厅已完整布景，四冠均在场）。
- D-Bram 证言归属 → **已解**（D 拥 Bram 的对白与死；A 使用但不改写）。
- E-Crosser 草图位置 → **已解**（E 留在 T004 图书馆深藏区，一如 A 期望）。

**β（B 线作者的空缺）：**
- Silas 住所冲突 → **B1**（未解；阻断）。
- Ban 条文对齐 → **S2**（未解）。
- 与 D 的根字符重叠计数 → **已解**（双方均为二）。
- Kestrel 草图字符计数 → **已解**（双方均为三；M1 整饬）。
- 噤日 / Ban 日期同步 → **S1**（未解；主编）。
- 与 C 的 Vossel-Voss 血统 → **B3**（未解；阻断）。
- Abbot Merick 去留 → **M2**（由 B 默认解决）。

**γ（C 线作者的空缺）：**
- Charter "四席加一" 指涉 → **已解**，由 A（A/T005 Charter 条款命名四冠；砌死的第五门是 C 对"隐含第五"的正式表达；C 明示"空心四结印"为结构性指涉）。
- Vossel Voss-堂亲血统 → **B3**（未解；阻断）。
- Bram 年龄允许过往送信 → **S6**（未解；主编）。
- Ashen Herald 的正典身份 → **S5**（未解；主编自四候选择一）。

**δ（D 线作者的空缺）：**
- Corvin 办公处处理支付位置 → **M7**（未解；主编在 A 加一条）。
- Eilin 材料 / 上下相通 字符共置 → **已解**（B 拥墙；A/D/C 皆正确引用）。
- 王家纹章视觉规格 → **M12**（已解；Veyl 纹章与四结本设计为不同符号）。
- Crosser 旁批采用 → **M11**（未解；次要；主编在 E 加一条交叉注）。
- Sula 账簿 → **M10**（已解；全由 E 拥）。

**ε（E 线作者的空缺）：**
- Brenna 容忍 vs Ban 一致 → **S3**（未解；主编；解法 = 区分 Charter/Ban 与 Listener 契约）。
- 云夜时序 → **M4**（由 world-agent 一行注解决）。
- Corvin 封印信件支付 → **M7**（未解；主编）。
- Eilin 粉笔台词 → **M5**（*ring is untrue* 已解；*he keeps them* 未解 —— 在 B 加一句）。
- Bram 草场 Listener 目击 → **M6**（未解；主编在 D 加一句）。

**仍未解决的主清单（合并进上文 Blockers/Serious/Minor）：**
B1、B2、B3、S1、S2、S3、S5、S6、S7、M1、M5、M6、M7、M11。

无一为重写；皆为外科缝合。

## 建议决议（交付主编）

### Blockers

**B1 —— Silas 住所。** 文件：五线全部。动作：Silas 主档留 T004（NPC_T004_07）。给 T001/facilities.json 加一个 T001 *来访 hook*（非新 NPC 条目）：Shale Lantern 后的小堂；按现有 T001 传言，第三夜自 T004 走来。在"Gaps needing sibling input"一节批准 B 的提案；然后统一：A/T001（"Septon Silas（来自 T004 的访客）"）、E/T001（"Septon Silas · 顺带一句"）、D/T001（"自 Jadehollow 来访的 Septon"）。四线皆已采此措辞 —— 只需一次编辑清扫确认。

**B2 —— Hallen 位置。** 文件：`B-world-before-the-fog.md`（T004 clue 表 + write-in checklist）与 `E-depth-walkers.md`（T005 clue 表）。动作：钦定 Hallen 在 **T005 病房**（E 的位置，因为它将 Theory-3 锚在 Critical）。编辑 B：删除 T004 的 Hallen "NEW NPC" 写入项，换为："Jade Lantern 有一位无名的、说话带韵律的酒鬼重复三段式残句 *'below and beyond are one …'* —— 他不知其出处，也不会多说；具名载体 Hallen 在 T005（参 E 线）。" 删掉 B 在 T004 的"theory-voice 交付"主张；保留他为 Theory-3 的正典之声，但只在 T005。

**B3 —— Vossel 血统。** 文件：`C-four-crown-intrigue.md` 的跨线小节与 Preceptor Vossel 段。动作：删除或软化"Vossel 是由 Crown 安插的 Darrik 的 Voss 堂亲"这一断言。换为："Preceptor Vossel the Younger（B 副灵魂，T002）在行旅中与修道院保持安静通信 —— C 线不主张其血统。" 如主编愿保留一颗种子，减为："Vossel 的北方堂支无人在修道院追问；他自己亦不谈。" 如此无牙，不破 B。

### Serious

**S1 —— Ban / 噤日期。** 文件：`A-guild-buried-charter.md` T005 Corvin 对白。动作：在 Corvin 开场加一句：*"The Ban was re-drafted eleven years ago, in the same season a maester's tongue was taken in the north. I was not Magister then. I inherited both."* 与 B 对齐。

**S2 —— Ban 引文 vs 石片字符。** 文件：`B-world-before-the-fog.md` 附录 J（石片示意）。动作：加一句：*"The shard's seventeen glyphs translate, in Naryn's predecessor's draft, to four sightings — sun-nailed-to-tower, house-that-flies, iron-that-sings-like-a-forge, the-unending-road — which are the four named sightings preserved in the Northern Ban's third clause. Eilin does not endorse the translation. She has not corrected it either."*

**S3 —— 三冠 Listener 契约。** 文件：`E-depth-walkers.md` T005 Listener-contract-parchment 条目。动作：加一行：*"This contract is not the Northern Ban. It is the Listener bond that the Ban permits. The Free North has never signed a Listener bond; Brenna's predecessors refused, Brenna continues to refuse, and her silence is legible on the wax."*

**S5 —— Herald 身份。** 文件：`C-four-crown-intrigue.md` Endpoint 5 与 Herald 档案。动作：钦定 **Brenna 的官方不存在的姐姐**。与 Brenna 的"记得却不能说"动机一致。把 Endpoint 5 的候选清单改写为单一正典句。Jenn 保留为 Brenna 的外甥女（信使，非 Herald）。

**S6 —— Bram 的送信青年。** 文件：`C-four-crown-intrigue.md`（C↔D cross）和/或 `D-iron-dragon-returns.md`（Bram T004）。动作：将"Bram 为 Brenna 的祖母与 Darrik 的祖父送信"改为"*Bram 的父亲曾为老族长与老王送信*。若被问，Bram 只说：*'My father rode in winter for them. He learned his letters from the same woman they learned theirs from. He did not speak of it.'*" 保留 C 的意图，修正数目。

**S7 —— "Ashen" 撞色。** 文件：`A-guild-buried-charter.md` Factor 姓氏。动作：*Selm Ashen-Howe* → *Selm Orren-Howe*。A 线一处单令替换。

### Minor

M1/M4/M5/M6/M7/M11 —— 每项均为上 Minor 节中所指的一行编辑。无需重写任何场景。

---

审校报告完。所列编辑皆为外科式；五条主线在一次主编通校（落实 B1–B3、S1–S7、M1/M5/M6/M7/M11）之后即可付运。
