# 主线 A：Guild 的埋藏宪章（The Guild's Buried Charter）

> 源文件：../A-guild-buried-charter.md  · 译文仅供审阅，以英文原版为准

## Function / 功能

A 线是整张地图的结构脊柱。它的任务是带玩家依次走过 Guild 五个支部的每一处屋檐，等 Mistmere 的城门在他们身后合拢时，他们已经站过 Guild 所有的屋顶、并在 Guild 所留的每一页纸上签过字——或拒绝签过字。此线以 Stoneford 一桩寻常的赏金委托开局——一枚银坠，二十枚金币，不问缘由——终于 Mistmere 的 Magister 读书室，在那里，玩家被迫判断：Guild 作为一个机构，是否应当继续存在。

在这桩委托之下，本线递送三项承重的揭示：

1. Guild 从来不是、也从未是一个中立的冒险者转运所。它在两百年前被创立为**四冠之间的仲裁机构**——最古旧的宪章条款写："to hold the peace between crown and crown, and to close the mouths that would unmake it."（以维护冠与冠之间的和平，并封闭那些足以毁之的口。）（C 线在此处咬合：四冠之栈。）
2. Guild 的 "Northern Ban"——每个支部主官都在最底下抽屉里正面朝下压着的那一份短诏令——是围绕 Septon Silas 所携石片的文本书写的。诏令的运作段几乎逐字抬自石片的本土感官行。（B 线在此处咬合。）
3. 过去两代人里，Guild 悄悄进入的不是赏金行业，而是**压制行业**。它压制任何"天上一条直线"的目击，任何对"像铁匠炉一样歌唱的铁"的提及，任何矿工关于第四层发现的报告，任何看见了不该看见的牧羊人。Jadehollow 之上的 Old Bram 被列入 Guild 的登记簿，正是因此。（D 线在此处咬合。）

玩家从未被直接告知这些。它们是从酒馆炉石下的一枚黄铜令、一张错归档的收据、一块修道院墓石、一份半焚诏令、一册撤回证人的登记簿，最后到 Magister 读书桌上那本敞开的手札——一件一件拼出来的。

本线承载动机 2（对归来的恐惧）、动机 5（Guild 的内部自利——作为机构自身的存续）与动机 6（资源垄断：Guild 向王冠与商会出售沉默）。Magister，Corvin Ashford-Reed，不是反派。他是整个北地最后一个读过全本宪章的人，他权衡之下决定，沉默比知情更仁慈。

## Soul figure(s) / 灵魂角色

- **Magister Corvin Ashford-Reed** —— Guild 的 Grand Magister，常驻 Mistmere High House（T005）。已败落的 Ashford 一族的远房堂亲；连字号是在三代人前、Guild 吸收两位 Ashford 抄写员时加上的。六十多岁。拄一支荆木手杖。声音柔。穿旧式灰袍，不穿当代的黑袍。他读过埋藏宪章（Buried Charter），已九年未睡过一整夜。**NEW NPC —— 必须加入 T005/npcs.json。**
- **Keeper-Commander Olric the Silent**（副灵魂，死去两百年）—— Guild 最初仲裁席的奠基人、埋藏宪章的作者，葬在 Wolfsjaw 修道院（T003）后庭一块无字石板下。他的印——一条咬着自己尾的河鱼——压在 Shale Lantern 炉石下的黄铜令上。他的墓石上只写 "Olric, who kept silence"（奥利克，守沉默者）。**仅作指涉 NPC ——以墓、字符、印、以及修道院档案中一封身后书信的形式出现。无在世行动者。必须在 T003 facilities/archive 中标注。**

## Hook

**Tier 1，T001 Stoneford，Guild 支部赏金板。**

触发条件：Heron Blackwater 在玩家抵达的第二天清晨钉出一道公开赏金——*二十金，寻回一枚银坠，遗落于 Shale Lantern 与矿道之间。不问来历。下方 Guild 之印。* 赏金由 Heron 亲手书写，并以支部之印复押——但那枚印略有不对。缺了内环。若问起，Old Reed 会说内环意为"此事 Guild 内部办理"。一道被卸掉内环的赏金，是支部主官不愿入账的赏金。

银坠确实存在。它是拇指指甲大小的一枚扁银，铸成河鱼咬尾之形。实际上，它是 Guild 旧日的仲裁之印——一枚"Guild 之前"的金属制品，是现代 Guild 情愿无人再把它握在手里的那类物件。它由一位 Guild 信差在两夜前遗落，当时他正从 Mistmere High House 赶往 Shale Lantern。

把银坠从它藏身之处拉出来（详见下文 Clues 中的炉石下）——这是 Sprout。把它交回给 Heron——这是第一个分支抉择：交回，Heron 会不动声色地付二十金并让玩家明日北行，说 Guild *另有事务*；留下，Heron 面孔一合，三天后会在另一支部出现第二道赏金，目标是玩家自己。

## Clues by town / 各城线索

### T001 —— Stoneford

| 载体 | 类型 | 内容 |
|------|------|------|
| Heron Blackwater（NPC001）| 赏金告示 | *银坠，遗于矿道。二十金。不问来历。* 黎明钉出。印缺内环。|
| Heron Blackwater | 对话节拍（若追问印章）| "The inner ring is a clerk's affectation. Don't trouble it."（内环是文书的做作，别计较。）他的左小指——那截残指——在桌上敲一下、两下。不与玩家目光相接。|
| Old Reed（NPC002）| 对话（若问 Guild 印章）| "Seal with the ring, that's the Guild asking. Seal without, that's the Guild *telling*. I wouldn't take a job that came with the ring filed off, myself. Not at my age."（有环的印，是 Guild 在*请*；没环的印，是 Guild 在*令*。我这个岁数的人，是不会接没环的活的。）|
| Old Reed | 对话（若问银坠）| "Fish biting its tail? That's an old shape. Older than the Guild's crest. My father had a knife pommel cast that way once. He said the river-fish is the sign of a man who keeps his mouth shut. Old pattern. Very old."（鱼咬着自己的尾？那是一个旧形。比 Guild 的纹还旧。我父亲有一柄刀鞘头是那样铸的。他说河鱼是一个闭口之人的标记。旧样。很旧了。）|
| Mira Ashford（NPC003）| 场景节拍 | 第二夜晚，Mira 扫炉收尾时停下。灰坑旁一块地砖敲起来是空的。若玩家向她买过茶（两银），她会在玩家抬砖时别过脸。砖下：一卷油布。油布里：那枚银坠，与一枚核桃大小的黄铜令。|
| 炉石藏物 | 残片（落位）| **旧 Guild 黄铜令**。一面压有 Olric 的印（河鱼咬尾），另一面是一对交叉的钥匙与其间一柄折断的第三把钥匙。背面以北地旧体写有：*arbiter · iiii · corona · mmcccxii.* 日期来自 Guild 以其当代形态成立之前。|
| 炉石藏物 | 物品掉落 | **银坠**（赏金目标）。银坠与黄铜令明显同出一脉——同金属、同手、同时代。银坠是磨损、可携带的版本；黄铜令是固定、仪式性的版本。任何半称职的鉴物人（T004 的 Old Fane Crowseye）一眼便知。|
| Mira Ashford | 对话（若只出示黄铜令而非银坠）| 她僵住良久。然后："That was my husband's. He took it from the mine track the week before he walked into the river. I never knew what it was. I was afraid to ask."（那是我丈夫的。他走进河里的前一周，从矿道上捡来的。我从不知道那是什么。我不敢问。）她请玩家不要告诉 Heron。她不解释为什么。|
| Heron Blackwater | 场景节拍（若银坠被交回）| Heron 付二十金，不清点。他将一封封缄的信推过桌面。"Ride to Windrest. Present this at the branch. You'll be expected."（去 Windrest。到支部出示这个。他们在等你。）信件封面写 *Guildmaster's Pro-Tem, Windrest Branch.* 外印恢复了内环。|
| Heron Blackwater | 对话（若保留银坠并被发现）| "I asked you a small thing. You chose to make it a large thing. The Guild has a long memory."（我只求你一件小事，你选择把它变成大事。Guild 记性很长。）他不再多言威胁。三日内，Windrest 出现第二道赏金，二十五金，目标仅按外貌描述——无姓名，只形貌。|

**T001 stage end（Sprout）：** 玩家离开 Stoneford 时，手里要么是（交回了的）银坠与一封封缄信，要么是（扣下了的）银坠与支部的静默敌意。无论哪一种，他都揣着那枚黄铜令；无论哪一种，下一座支部都是 Windrest。

---

### T002 —— Windrest Keep

| 载体 | 类型 | 内容 |
|------|------|------|
| Guild 支部——Windrest | 场景节拍 | Windrest 支部半是士兵营房、半是文书办公处。代理的 Guildmaster 缺席——"在隘口巡班"。由一名年轻文书 **Clerk-Registrar Tamsin Howe**（**NEW NPC——加入 T002/npcs.json**）接过信函。|
| Clerk-Registrar Tamsin Howe | 对话 | 相貌寻常，三十岁，袖口到手肘全是墨渍，戴眼镜。信读两遍。"Stoneford sends you to us to send you north. Very well."（Stoneford 把你送到我们这，好把你送北。很好。）盖下一份通行令。显然资历浅、显然好奇、显然不敢问。|
| Clerk-Registrar Tamsin Howe | 场景节拍（若玩家逗留或协助她整理错归档的收据，出两银即可）| 她二话不说，把过去一季 Windrest 支部的收据一叠塞给玩家。其中三张是*压制津贴*——付给同意撤回报告的证人的款项。三张津贴上的姓名：一位 Windrest 路上的烧炭工；一位隘口的 Ironfist 传令兵；以及 *Old Bram, shepherd, above Jadehollow.*（Jadehollow 之上的牧羊人 Old Bram。）三张的"款项原因"一栏皆相同：*Atmospheric misreport. Reviewed and retracted.*（大气误报。已审、已撤。）|
| Clerk-Registrar Tamsin Howe | 对话（若被问何为"大气误报"）| "A sky sighting. Something the witness thought they saw in the clouds. Usually lightning, usually drink. The branch pays a stipend and the witness signs a retraction."（天上一次目击。证人以为在云里看见了什么。通常是闪电，通常是酒。支部付一笔津贴，证人签一张撤回。）她不与玩家目光相接。"I don't read the originals. I'm not cleared."（我不读原件。我没有那个权限。）|
| Captain Yura Stoneshield（NPC_T002_01）| 对话（仅在被问及 Guild 时）| "I deal with the Guild because I must. They hold the pass roster. Their clerks have been writing down names that nobody is supposed to have, and then crossing them out. I will not say more in this courtyard."（我与 Guild 打交道是迫不得已。他们握着隘口名册。他们的文书一直在记下本不该握在谁手里的名字，然后又把它们划掉。在这院子里，我不会再多说。）若玩家压低声音到马厩，她会继续说——她说的是，在她五年的任期里，Windrest 支部两次请她*丢失*一位士兵关于"那条走得太直的云线"的报告。|
| Old Zhao（NPC_T002_02）| 对话（50 金）| "The Guild? You're not the first to ask. Branch master here is pro-tem because the last one hanged himself in his own reading-room. Official cause: melancholy. Unofficial: he'd been writing the Magister every week about *the sightings* and getting no reply. I have a copy of the last letter. Fifty gold more and it's yours."（Guild？你不是第一个来问的。这里的支部主官是代理的，因为上一位在自己的读书室里自缢。官方说是忧郁。私下传的是：他每周给 Magister 写信说*那些目击*，从没回音。我有最后那封信的抄本。再五十金，归你。）信是真的。写的是 *To the Magister, from the Pro-Tem Windrest, concerning matters of sky.* 结尾：*I cannot sign another retraction. I am not brave. I am only tired.*（我不能再签一张撤回。我并不勇敢，我只是疲倦。）|
| Guild Windrest —— 账房 | 残片（间接）| 一张错归档的收据夹在两份补给订单之间，指涉 Windrest 支部向 Wolfsjaw 修道院 **Archivist Naryn** 付过一批货：*一口封缄铁箍柜，内容列于 Northern Ban。*（这将玩家指向 T003 与清单中的半焚诏令残片。）|

**T002 stage end（Involvement 起）：** 玩家此时带着黄铜令、银坠（或对它的记忆）、北向通行令、一份三人压制名单，以及——若他追问到底——一位已故 Guildmaster 的最后书信。Guild 的性格在玩家手下一寸寸改变。它不再是一块赏金板。它是一架机器，在事后替人改写报告，并以一笔津贴买沉默。

---

### T003 —— Wolfsjaw / 修道院

| 载体 | 类型 | 内容 |
|------|------|------|
| Guild 支部——Wolfsjaw | 场景节拍 | 隘口没有正式支部。有的是一位 Guild *代办*，**Factor Selm Orren-Howe**（**NEW NPC——加入 T003/npcs.json**），他把桌子摆在修道院外厅。修道院事实上就是支部。任何登记、任何撤回，都经修道院抄写室、由代办与 Archivist Naryn 联合签押。|
| Factor Selm Orren-Howe | 对话 | Orren 某堂支的幼子，排行老三或老四。紧张。称职。二十八。他接过通行令时显出放松——一周前他从 Mistmere 收到的指示是*等一位携银的信差*。他不知道那银是什么。他没看见过银坠。他问过一次玩家是否佩械，然后道歉。|
| **Archivist Naryn**（**NEW NPC——加入 T003/npcs.json**）| 对话 | 五十多岁，墨渍沾到指节，一眼翳浊。修道院档案员兼 Guild 代办处书吏；两条绶带并披。她是埋藏宪章当地副本的守管人。不是狂信徒。是一名还差两年领取微薄养老金的文职。|
| Archivist Naryn | 场景节拍（若在未被提示下出示黄铜令）| 翳浊的那只眼不动。好的那只死盯住它许久。"Where did you come by that."（你从哪里得到这个。）平板，不是问句。她不让玩家离开此室。她用布把令包起锁进柜子的最下层抽屉。"I will return it when you leave the pass. Not before."（你离开隘口时我会还给你。之前不还。）|
| Archivist Naryn 的柜 | 残片（落位）| **半焚 Northern Ban 诏令**。七年前一次壁炉失火烧毁，存下的是羊皮纸的右半。运作段存留，以官式体书写：*No branch, no factor, no hand of the Guild shall report, record, or render in ink any sighting of sun-nailed-to-tower, of house-that-flies, of iron-that-sings-like-a-forge, of the-unending-road. The witness shall be paid in silence. The witness shall be paid in silver. The witness shall not speak again.*（Guild 的任何支部、任何代办、任何墨笔，不得以任何形式报告、记录或书写以下目击：被钉在塔上的太阳、会飞的房子、像铁匠炉一样歌唱的铁、没有尽头的路。证人当以沉默获偿。当以银获偿。当永不再言。）四处具名目击几乎逐字抄自 Septon Silas 所携石片（参 B 线）。|
| Archivist Naryn | 对话（仅当玩家也在 T001 见过石片）| "The Ban paragraph is older than the Ban. We copied it from a stone. I am told the stone is older than the Guild."（禁令的段落比禁令本身更老。我们是从一块石头上誊下来的。据说那石头比 Guild 还老。）再不多言。她害怕。|
| 修道院抄写室 —— Olric 的通信箱 | 残片（新子项，仅描述，不入清单）| 第三层架子后端的一口封蜡木匣藏有三封 **Keeper-Commander Olric the Silent** 寄给他四位王冠通信者的遗信（写于两百年前）。第三封中有：*The arbitration must become the suppression, or the arbitration cannot hold. I have taken the burden. Let no successor of mine open this box without first reading the Charter entire.*（仲裁必须变为压制，否则仲裁不立。担子由我担着。我的任何继任者，若未先通读全本宪章，不得开此匣。）箱子在玩家找到它时是敞开的。近时有人翻过。|
| 修道院后庭 | 场景节拍 | 后庭一块无字石板，比其余板略长一掌。凿刻的字几乎被风蚀尽。跪身、借烛，可辨：*OLRIC · WHO · KEPT · SILENCE · ARBITER · IIII · CORONA.* 石板脚下刻着和黄铜令相同的河鱼印。|
| 修道院后墙 | 残片（落位——与 B 线共享）| 墙面字符 **上下相通**（above-and-below-connect）。在此但主属 B 线（Eilin）。A 线仅记：Guild 的压制条款从未施于此字符上。若问 Archivist Naryn 为何，她只说："The Ban was written for sky. Not for wall."（禁令是为天而写的。不是为墙。）|
| Sara, field medic（NPC_T003_02）| 对话（零散）| "The Guild factor has asked me, twice, to leave my case notes in the outer hall overnight before sending them south. Both times, a paragraph was gone in the morning. I've started copying them twice."（Guild 代办两次让我把病例夹在外厅过夜再南送。两次早上都少了一段。我现在都抄两份。）她的副本最后流到 Jadehollow。|
| Mark, veteran（NPC_T003_03）| 对话（若问直线云）| "You mean the straight one. Yes. Three times since the battle. I reported it the first time. The factor paid me a stipend and asked me to sign a retraction. I signed. I needed the coin. I haven't reported the other two."（你是说那条直的。对。战后三次。第一次我报过。代办给我发了津贴，要我签撤回。我签了。我缺钱。后两次我没再报。）|

**T003 stage end（Involvement）：** 玩家此时在脑中拼出了埋藏宪章的全貌：Guild 初为四冠仲裁机构；在 Olric 治下某时，它变成一架强制沉默的机器；当代 Northern Ban 是沉默赖以运行的法律器械。Archivist Naryn 在玩家离开时归还黄铜令，并附上——作为一件小而惊恐的善意——一封致 Jadehollow 的 Kassa Deepvein 的介绍信。"She is a plain woman. Plain women are harder to lie to."（她是一个其貌不扬的女人。其貌不扬的女人更难对之撒谎。）

---

### T004 —— Jadehollow

关键支从此开始。T004 之后，每一次 Guild 对话都是一次关于"Guild 作为一个机构是否应当继续存在"的对话。

| 载体 | 类型 | 内容 |
|------|------|------|
| Kassa Deepvein（NPC_T004_01）| 对话（在递交 Naryn 的信时）| "An introduction from Wolfsjaw's archivist is not a small thing. Sit."（从 Wolfsjaw 档案员处来的介绍不是小事。坐。）她慢慢读完那封信。面无变化。"Naryn believes you have seen the lower drawer. I will tell you what I know about the lower drawer, and then I will ask you what you mean to do."（Naryn 相信你见过最下抽屉。我会告诉你我所知的关于下抽屉的事，然后问你打算怎么办。）|
| Kassa Deepvein | 场景节拍——下抽屉 | 她开自己支部桌的最下抽屉。里面一本皮面夹宗，盖着缺内环之印。内含：四十一个姓名的登记。每个名字配一个日期、一笔津贴数额、一个单字分类。分类是 *sky, metal, road, hero, other*（天、金、道、英雄、其他）。"I signed forty-one of these in nine years. I have never signed one I thought was a lie. I have signed many I wished were lies."（九年里我签过四十一张。从没有一张是我认为在说谎；却有许多我但愿它们是谎。）|
| Kassa Deepvein | 对话 | "You will find **Bram, shepherd** on the second page. Category sky. Three stipends in eighteen months. The Magister's office sent a private courier for the last one — the stipend was doubled. I was not told why."（你会在第二页看到**牧羊人 Bram**。分类为 sky。十八个月里三笔津贴。最后一笔由 Magister 办公处派私人信差送到——款额加倍。没人告诉我为什么。）|
| Old Fane Crowseye（NPC_T004_03）| 对话（若同时出示银坠与黄铜令）| 他那只灰眼一凝不动。"Same forge. Same year. Probably the same hand. That token is an *arbiter's weight* — a ceremonial half-pound of silver used two centuries ago to close a parley. The pendant is the personal seal of the arbiter who cast it. Olric, if I had to guess. The man who is buried at Wolfsjaw under a flagstone that has no name on it."（同炉。同年。多半同手。那枚令是一枚*仲裁之衡*——两百年前用以结束谈判的半磅仪式银。银坠是铸它之仲裁者的私印。要我猜，是 Olric。葬在 Wolfsjaw 一块无名石板下的那位。）他不肯收钱。"Knowing this is the payment."（知道这件事，就是酬劳。）|
| **Old Shepherd Bram**（属 D 线；A 线只碰他）| 场景节拍 | 若玩家带着 Kassa 的登记簿骑上 Bram 的牧场，他已在等——Kassa 已捎信。他只有在玩家当着他的面同意把登记从下抽屉*取出*后，才会就"目击"（D 线领地）开口。"I signed three pieces of paper that said I saw nothing. I want the pieces of paper back. I want my name crossed off a book I was never told I was written in."（我签过三张说我什么也没看见的纸。我要把那三张纸拿回来。我要我的名字从一本从没人告诉我上了名字的簿子里划掉。）|
| Septon Silas（NPC_T004_07）| 对话（若石片已由 B 线引入）| "The Guild factor at Wolfsjaw asked me, four years ago, to leave the shard in the monastery for a season of 'study.' I refused. He did not press. I understand now why he did not press. Pressing would have been a record."（四年前 Wolfsjaw 的 Guild 代办请我把石片留在修道院里"研究"一季。我拒绝了。他没有追问。我现在明白他为何不追——追问会成为一条记录。）|
| 图书馆深藏区（残片属 E 线）| 场景节拍 | 深藏区藏有 Crosser 草图 *from below, we may rise.* A 线仅记：Guild 的 Jadehollow 支部有一条"一经在私人手中发现即没收"的常令。Kassa 未执行此令。草图仍在。|

**T004 stage end（Critical 起）：** Kassa 向玩家出示一份 Jadehollow 登记簿的未签名副本。她不会轻易交出。她要的是一个承诺——明言，在支部办公室，门关起——关于玩家打算在 Mistmere 的 Magister 面前放上什么。三条大路：
- **Reform / 改革。** 出示登记作为证据，要求在四冠见证下重写埋藏宪章。
- **Burn / 焚毁。** 毁掉登记与宪章；让 Guild 维持现状；承认沉默护人多于害人。
- **Break / 拆解。** 把登记公诸——四冠、Faith、商会、任何人——并接受 Guild 作为单一机构将无法在公开后存活。

只在 Reform 或 Break 下，Kassa 才会实际把登记交给玩家。Burn 下，她自己留着并随玩家南下，亲眼监督焚毁。

---

### T005 —— Mistmere

| 载体 | 类型 | 内容 |
|------|------|------|
| Guild High House，外厅 | 场景节拍 | Mistmere High House 是北地最老的 Guild 建筑。灰石。门上是河鱼纹，内环完整。门口两名文书。Windrest 的通行令已足够；Heron Blackwater 那封信不被提及。|
| **Senior Clerk Hess Veigh**（**NEW NPC——加入 T005/npcs.json**）| 对话 | 瘦，五十岁，九年来替 Magister 朗读。她完全清楚玩家是谁、身上携何物，不作佯装。"The Magister will see you after the sixth bell. He asks that you come alone to the reading-room. He asks that you bring what you have brought. He asks nothing else."（Magister 六响之后见你。他请你独自到读书室。他请你把你已经带来的都带上。别的不要求。）|
| **Magister Corvin Ashford-Reed**（**NEW NPC——加入 T005/npcs.json**）| 场景节拍 —— 读书室 | 长室，一窗，无炉。Magister 坐在一张书桌后，一本书敞开：那本埋藏宪章的*完整*副本，不是修道院那片零碎。他示意一把椅子。他不起身。荆木杖横在膝上。|
| Magister Corvin | 对话（开场）| "You carry Olric's pendant. You carry Olric's weight. You have read the Ban, or half of it. You have stood on Olric's grave without knowing whose it was until someone told you. You have, I am told, made certain inquiries of a shepherd. The Ban was re-drafted eleven years ago, in the same season a maester's tongue was taken in the north. I was not Magister then. I inherited both. I will not waste the time between us. Sit. Ask."（你带着 Olric 的坠。你带着 Olric 的份量。你读过那份禁令，至少一半。你在 Olric 的墓上站过，直到有人告诉你那是谁。我被告知，你去询问过一位牧羊人。禁令是在十一年前重拟的，与北地一位 maester 被割舌同一季。那时我不是 Magister。两副担子我都是继承来的。我不浪费你我之间的时间。坐下。问吧。）|
| Magister Corvin | 对话（论四冠起源）| "The Guild was four-crown arbitration before it was anything else. The four crowns met, the four crowns quarrelled, and Olric — a keeper-commander at a monastery that had no quarrel with any of the four — was asked to hold the floor. He held it for eleven years. At the end of the eleven years he wrote the Charter, and the four crowns signed it, and the Charter's first clause was *to hold the peace between crown and crown, and to close the mouths that would unmake it.* The mouths, at that time, were mouths that spoke of the far side. The Charter's second clause — which you have not read, because it is in this book and nowhere else — is that the four signing crowns shall, in every generation, appoint one Magister to bear the closure. I am that Magister. I have borne it nine years. I am sixty-four years old. I have not slept a full night in nine years, and I will not sleep a full night again while I am in this room."（Guild 在成为任何别的东西之前，是四冠仲裁。四冠相会、四冠争吵，然后 Olric ——一位与四冠皆无争的修道院守门官——被请来主持那张桌。他主持了十一年。十一年末，他写下宪章，四冠共同签署；宪章的第一条是：*维护冠与冠间的和平，并封闭那些足以毁之的口。*那时的"口"，是谈论彼岸的口。宪章的第二条——你未读过，因为它只在这本书里，别处没有——是四位签字王冠在每一代指派一位 Magister 来担此封闭。我即那位 Magister。担子我担了九年。我六十四岁。九年来我从未睡过一整夜；只要我还在这间屋里，我也不会再睡一整夜。）|
| Magister Corvin | 对话（论动机 2，对归来的恐惧）| "The Ban is written because the four crowns agreed, two hundred years ago, that the silence from the far side might not be an ending. It might be a preparation. You have seen the straight line of cloud. You have met a shepherd who saw it three times. He is the forty-second shepherd in the register. There have been straight-line sightings in every generation since the Charter was signed, and every generation has chosen to close the mouth that reported them. I did not invent this. I inherited it. I will not pretend it is clean."（禁令之所以成文，是因为两百年前四冠共同承认：来自彼岸的沉默未必是终结。它可能是一种准备。你见过那道直的云线。你见过一个见过它三次的牧羊人。他是登记中的第四十二位。自宪章签署以来每一代都有直线云的目击，每一代都选择封闭报告者的口。这不是我发明的。是我继承的。我不会假装它是洁净的。）|
| Magister Corvin | 对话（论动机 5，Guild 的自利）| "The Guild persists because the Guild is useful. Bounty work, yes; arbitration, yes; but also the silence. The crowns pay us to hold the silence. The merchant houses pay us to hold the silence. We pay our own factors to hold the silence. If the silence goes, the coin goes. If the coin goes, the branches go. If the branches go, the arbitration goes, and the four crowns go back to knives at the table. I say this plainly because I am tired of saying it in other words."（Guild 得以存续，因为 Guild 有用。赏金之业，是；仲裁之业，是；还有那份沉默。诸王为沉默付我们钱。商会为沉默付我们钱。我们付自己的代办为沉默。沉默去，钱去。钱去，支部去。支部去，仲裁去，然后四冠又回到桌上的刀尖上。我直说，因为我厌了换别的方式说。）|
| Magister Corvin | 对话（论动机 6，资源垄断——暗含，不明说）| "There are objects that come out of the ground in this country that should not come out of the ground. You have probably held one. A shepherd's crooked length of metal that will not take a hammer. A cup that does not let its tea grow cold. A stone that carries a voice. These objects are bought, by the Guild, from the finders. The finders are paid and the finders are silenced. The objects are kept. I will not tell you where. I will tell you only that if the Guild ceases tomorrow, the keeping ceases, and the objects are on open markets by next spring. I do not know that this is worse. I know only that it is different."（在这片土地里有些东西从地里出来——本不该从地里出来。你大概握过一件。一根牧羊人手里、锤不入的扭金属。一只不让茶凉的杯子。一块载着声音的石头。Guild 从发现者手里收这些物件。发现者被付钱，发现者被沉默。物件被保管。我不会告诉你保管在何处。我只说：若 Guild 明日断，保管亦断，到了来春它们就在公开市场上了。我不敢说那更糟。我只知道，那不同。）|
| Magister Corvin | 场景节拍 —— 宪章敞于桌 | 他把书转向玩家。埋藏宪章最后一页一片空白，只有他今晨亲写的一行：*I have borne it nine years. I will bear it one more day, and not longer, without a witness.*（我已担它九年。若无一个见证者，我只能再担一日，再长不能。）他把荆木杖放上桌。"You are the witness. Decide."（见证者即是你。决。）|
| Magister Corvin | 场景节拍 —— 若被出示 Listener contract 羊皮纸（E 线 door-2 告发）| 他默读之。由 Senior Clerk Hess Veigh 经封缄信件付款。他不叫玩家的名字。他不请其再来。（交叉：E 线 T005 告发给 Guild 之路。）|

**Critical decision at T005 / T005 的关键决定。** 四种结局。Magister 会接受任意一种。这四种他已排练了九年。

1. **Reform / 改革。** 玩家要求在四冠见证下重写宪章。Magister 同意。他携宪章与 Jadehollow 登记，与玩家同赴四冠峰会（C 线 critical）。Guild 以改革之身续存——仲裁复位，禁令被划去，压制津贴转为对具名证人（Old Bram 亦在其列）的公开赔偿。代价：四冠必须同处一室。C 线须交付那间屋子，否则改革崩塌。
2. **Burn / 焚毁。** 玩家承认沉默比知情仁慈。Magister 在读书室那只独独的铜炉里亲手焚掉宪章，Jadehollow 登记一并。然后，他无声地走出 High House，踏入港口下的河口。第二天清晨，他的杖被发现留在栏杆上。Guild 继续——一季无主，继之以一位不知"何物被焚"的继任者。动机 2 的恐惧被保留。动机 6 的垄断被保留。玩家由 Senior Clerk Hess Veigh 安静而非常慷慨地付酬，并被请于月底前离开 Mistmere。
3. **Break / 拆解。** 玩家把登记公诸——致 Bishop Reynard（T005）、Lady Vera（T005）、商会（Gustav，T005），经信差致 Free North 与 Crown。Guild 作为单一机构在四十日内分裂。支部宣告独立；代办被召回；埋藏宪章至少在两座王室大厅被朗读。直线目击现已公开在案。Old Bram 得以昭雪，并在一个月内死于修道院所称的"风寒"。D 线的压制机器没了；D 线其他后果被释放。Magister 不抗。他亲签公告。他作为私人学者在 Ashford-Reed 家族乡间小屋再活一年，安静死去。
4. **Inherit / 继承。** 玩家接受 Magister 的长期 standing offer —— 仅当玩家曾以可见之敬对待过黄铜令、曾至少一次拒绝贿赂、未曾公开背叛过任何证人，才会被提出 —— 自己接下宪章。Magister 退隐。玩家成为 Magister。此后每一笔压制津贴都由玩家亲签。这是四种结局中最幽暗的一种。也是玩家知道最多的一种。

## Cross-line interactions / 跨线交互

- **A ↔ B。** 半焚 Northern Ban 诏令的运作段（T003，Archivist Naryn 的柜）几乎逐字抬自 Septon Silas 所携石片（B 线 T001 残片）。石片的本土感官短语 —— *sun-nailed-to-tower, house-that-flies, iron-that-sings-like-a-forge, the-unending-road* —— 以相同顺序出现在禁令中。这是告诉玩家"Guild 的沉默"正是关于彼岸之沉默的枢纽。**请 B 线确认石片的精确短语顺序，以便 A 线诏令逐字引用。** 引 B 线残片 *上古石片* 与 B 线线索 *Eilin 的字符 上下相通*（该字符被豁免于禁令，而此豁免本身即为线索）。
- **A ↔ C。** 埋藏宪章第一、二条款（T005，Magister 桌）命名四冠为 Guild 仲裁机构的缔约签字者。A 线的 Reform 结局要求四冠同处一室 —— 那间屋子由 C 线的 critical 节拍交付。A 线给出该会议的法律依据（宪章条款：Magister 可召四冠同席）；C 线把坐在椅上的人递来。**请 C 线保证 Darrik Voss、High Septa Malen、Chieftess Brenna Greyhold、Consul-Merchant Tobiah Caul 在 critical 窗口内皆可抵达 Mistmere 的某一场所。** 引 C 线四冠阴谋的灵魂角色。
- **A ↔ D。** Jadehollow 登记的分类 *sky* 是 Guild 对直线云目击的私名。Old Shepherd Bram 是登记第四十二位、十八个月里三笔津贴、最后一笔由 Magister 派私信加倍。Guild 对 Bram 的施压属 A 线；Bram 的实际证言属 D 线。**请 D 线协调 Bram 的对白，使其在玩家出示登记时同意作证；并在 Break 结局中处理他的死（一月之内"风寒"）。** 引 D 线残片 *直线云* 与 D 线副灵魂 *Old Shepherd Bram*。
- **间接 A ↔ E。** Crosser 草图 *from below, we may rise*（T004 图书馆深藏区，E 线残片）处于一条 Kassa Deepvein 未执行的 Guild 没收令之下。A 线不直接触碰草图；只确立 Guild *知道*它存在且选择不销毁。这在 Break 结局里变得重要——草图与登记一起被公布。**E 线只被请：将草图保留在 A 线所期望的位置。**

## Write-in checklist for town writers / 给城镇写手的补写清单

### T001（Stoneford）

- [ ] **T001/npcs.json —— Heron Blackwater（NPC001）：** 加入钉出"缺内环"赏金的对话节拍；加入"残指敲桌"的细节；加入银坠交回时的封缄信付酬（"Ride to Windrest. Present this at the branch. You'll be expected."）；加入银坠被扣下时的闭面敌意。
- [ ] **T001/npcs.json —— Old Reed（NPC002）：** 加入两句，一句解释"有环是请、无环是令"，一句认出河鱼咬尾印为"比 Guild 的纹还旧，我父亲有一柄刀鞘头是那样铸的"。
- [ ] **T001/npcs.json —— Mira Ashford（NPC003）：** 加入扫炉场景（只要玩家在她处买过两银的茶，她便在玩家抬空心地砖时别过脸）；加入被出示黄铜令时的一句安静台词："That was my husband's. He took it from the mine track the week before he walked into the river."
- [ ] **T001/facilities：** 在 Shale Lantern 客栈内加一块空心炉石，内藏油布卷，含银坠与旧 Guild 黄铜令。
- [ ] **T001/items：** 加入 **silver pendant / 银坠**（河鱼咬尾，拇指甲大小，扁）与 **Old Guild brass token / 旧 Guild 黄铜令**（核桃大小，一面压 Olric 印，另一面交叉钥匙加一柄折断的第三把；背面铭文 *arbiter · iiii · corona · mmcccxii*）。

### T002（Windrest Keep）

- [ ] **T002/npcs.json —— 加 NEW NPC Clerk-Registrar Tamsin Howe。** 初级 Guild 文书，三十，墨渍到肘，眼镜，寻常之女。家族：无。秘密：她曾悄悄抄下三笔压制津贴，因为她弟弟曾被付过一笔。对白示例："Stoneford sends you to us to send you north. Very well." / "A sky sighting. Usually lightning, usually drink. I don't read the originals. I'm not cleared."
- [ ] **T002/npcs.json —— Captain Yura Stoneshield（NPC_T002_01）：** 加入马厩旁的承认，"The Windrest branch has, twice in my five years, asked me to lose a soldier's report about the line of cloud that runs too straight."
- [ ] **T002/npcs.json —— Old Zhao（NPC_T002_02）：** 加入 50 金的出价（"Branch master here is pro-tem because the last one hanged himself"）；加入再 50 金的"Magister 最后一封信"（"I cannot sign another retraction. I am not brave. I am only tired."）。
- [ ] **T002/facilities：** 把 Windrest 的 Guild 支部加作双室构筑——外厅文书办公 / 内室账房。在两份补给单之间加一张错归档收据，指向 Archivist Naryn 与 Wolfsjaw 那口封缄铁箍柜。
- [ ] **T002/items：** 加入 **Guild travel warrant, Windrest pro-tem seal** 与 **dead guildmaster's last letter**（由 Zhao 获得，合计 100 金）。

### T003（Wolfsjaw 修道院）

- [ ] **T003/npcs.json —— 加 NEW NPC Factor Selm Orren-Howe。** 修道院 Guild 代办，二十八，紧张，称职，Orren 堂支。除明面之外无实质秘密。对白："Mistmere told me to expect a courier carrying silver. I did not expect you."
- [ ] **T003/npcs.json —— 加 NEW NPC Archivist Naryn。** 五十多岁，墨渍到指节，一眼翳浊。Faith 与 Guild 两条绶带并披。当地埋藏宪章与半焚 Northern Ban 的守管人。对白："The Ban paragraph is older than the Ban. We copied it from a stone. I am told the stone is older than the Guild."
- [ ] **T003/npcs.json —— Sara（NPC_T003_02）：** 加入零散对白，"The factor has asked me, twice, to leave my case notes in the outer hall overnight. Both times, a paragraph was gone in the morning."
- [ ] **T003/npcs.json —— Mark（NPC_T003_03）：** 加入直线云之言，"You mean the straight one. Yes. Three times since the battle. I reported it the first time. I signed the retraction. I needed the coin."
- [ ] **T003/facilities —— 修道院抄写室：** 加入 Archivist Naryn 的柜，内置半焚 Northern Ban 诏令（运作段含四句本土感官短语，与 B 线石片对齐）。在第三架后端加 **Olric 的通信箱**（木，三封遗信，当前敞开）。
- [ ] **T003/facilities —— 修道院后庭：** 加入一块略长的无字石板，凿刻 *OLRIC · WHO · KEPT · SILENCE · ARBITER · IIII · CORONA,* 石板脚下河鱼印。
- [ ] **T003/items：** 加入 **half-burned Northern Ban decree（残片清单物）**、**three Olric letters**（氛围文本）与 **一封自 Archivist Naryn 致 Kassa Deepvein 的介绍信**。

### T004（Jadehollow）

- [ ] **T004/npcs.json —— Kassa Deepvein（NPC_T004_01）：** 加入下抽屉场景节拍（她亲手开最下抽屉、出示四十一名登记簿）；加入 Bram 一句（"second page, category sky, three stipends in eighteen months, last stipend doubled by a Magister's courier"）；加入"三选一的承诺要求"（Reform / Burn / Break）。
- [ ] **T004/npcs.json —— Old Fane Crowseye（NPC_T004_03）：** 加入鉴物场景（灰眼凝两枚银而不动，宣告同炉 / 同年 / 同手，点名 Olric，拒收钱："Knowing this is the payment."）。
- [ ] **T004/npcs.json —— Old Shepherd Bram**（**与 D 线写手协调；Bram 是 D 线副灵魂，主归 D**）：加入一句，"I signed three pieces of paper that said I saw nothing. I want the pieces of paper back."
- [ ] **T004/npcs.json —— Septon Silas（NPC_T004_07）：** 加入四年前代办请他留石片"研究一季"的轶事。（与 B 线协调：Silas 的石片属 B；A 线仅引。）
- [ ] **T004/facilities —— Guild Jadehollow 支部办公室：** 加入最底抽屉皮面夹宗——四十一名登记，每条 日期 / 津贴 / 单字分类（*sky, metal, road, hero, other*）。
- [ ] **T004/items：** 加入 **Jadehollow Guild register（未签名副本）** —— 可转手物，由 Kassa 在 Reform 或 Break 下交出。

### T005（Mistmere）

- [ ] **T005/npcs.json —— 加 NEW NPC Magister Corvin Ashford-Reed。** Guild 的 Grand Magister。六十多，荆木杖，声柔，旧式灰袍，Ashford 远亲（连字号），九年未眠。家训：*What Is Kept Is Kept.*（守之者，守之。）秘密：他读过全本埋藏宪章；他在主持 Northern Ban 与压制津贴；他愿意把整副机器交给玩家。A 线灵魂。对白节拍见上文 T005 clue 表——开场、四冠起源、动机 2、动机 5、动机 6、以及宪章的交出。
- [ ] **T005/npcs.json —— 加 NEW NPC Senior Clerk Hess Veigh。** Magister 的朗读人，瘦，五十，九年任期。High House 的门禁。Burn 结局下的封口银由她不语发出。
- [ ] **T005/facilities —— Guild High House：** 加入外厅（两名门口文书）、读书室（长，一窗，无炉，单只铜炉）、Magister 的桌（敞开着*完整的*埋藏宪章至最后一页）。门上加河鱼纹，内环完整。
- [ ] **T005/items：** 加入 **Buried Charter（全本）**——仅在读书室场景可读，不可转手，除非 Break 结局中玩家明示。加入 **thornwood cane / 荆木杖**（Burn 结局中留在河口栏杆上；Inherit 结局中归还玩家）。
- [ ] **T005/npcs.json —— 与 C 线写手协调：** Reform 结局要求 Darrik Voss、High Septa Malen、Chieftess Brenna Greyhold、Consul-Merchant Tobiah Caul 在 critical 窗口内皆可自 Mistmere 抵达。A 线不引入这四人；C 线引入。
- [ ] **T005/npcs.json —— 与 D 线写手协调：** Break 结局在公布后一月内杀死 Old Shepherd Bram（"风寒"）。D 线写手拥该场景。
- [ ] **T005/npcs.json —— 与 E 线写手协调：** T004 图书馆深藏区的 Crosser 草图受一条 Kassa 未执行的 Guild 没收令。E 线拥草图；A 线只期望其保持原位。

### Flagged NEW NPCs（汇总）

1. **Clerk-Registrar Tamsin Howe** —— T002，初级 Guild 文书。
2. **Factor Selm Orren-Howe** —— T003，常驻 Wolfsjaw 修道院的 Guild 代办。
3. **Archivist Naryn** —— T003，修道院档案员兼 Guild 联合书吏，半焚 Northern Ban 的守管人。
4. **Senior Clerk Hess Veigh** —— T005，Magister 的朗读人。
5. **Magister Corvin Ashford-Reed** —— T005，Grand Magister，A 线灵魂角色。

### Gaps requiring sibling writers' input / 需兄弟写手确认的空缺

- **B 线写手：** 请确认石片上那一串短语的精确顺序，以便 A 线 Northern Ban 诏令逐字引用。当前占位顺序：*sun-nailed-to-tower, house-that-flies, iron-that-sings-like-a-forge, the-unending-road.*
- **C 线写手：** 请确认 Mistmere 四冠峰会的场所与窗口。A 线 Reform 结局依之。
- **D 线写手：** 请确认在 Bram 被出示登记时其作证之意愿，以及 Break 结局中的死亡场景。
- **E 线写手：** 请将 Crosser 草图留在 T004 图书馆深藏区，直到 A 线 critical 窗口关闭。
