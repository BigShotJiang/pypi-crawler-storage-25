# Stoneford 主线设定 —— 共享简报

> 源文件：../_SHARED_BRIEF.md  · 译文仅供审阅，以英文原版为准

> 先读这一份。五条主线的写手共享同一套世界逻辑。

## 隐藏前提（绝对不可出现在任何玩家可见的文本中）
Great Chasm 的彼岸是一个**已经死亡的现代文明**。失落英雄残片所说的 "Eternal-life × Gold × Infinity. Do not visit."（永生 × 黄金 × 无穷。勿前往。）实际指向：
- Eternal-life（永生）= 不死的肉身（低温冷冻 / 义体）
- Gold（黄金）= 稀有金属建筑（高层合金构造）
- Infinity（无穷）= 一整片无 Fog 的大陆

所有对彼岸的指涉必须停留在本土的感官语言里："the sun nailed to a tower"（被钉在塔上的太阳）、"houses that fly"（会飞的房子）、"iron dragon that sings like a forge"（像铁匠炉一样歌唱的铁龙）、"the unending road"（没有尽头的路）。绝不使用现代词汇（飞机、混凝土、合金、反应堆、冷冻）。

## 核心前史
- 北地四王国的王族血脉皆出自**来自彼岸的殖民者**。只有王族仍（部分地）记得此事。
- **一百年前，联络中断。** 王族的解读有二：要么是彼岸抛弃了我们，要么是彼岸崩塌了。
- 王族秘密**在地底挖掘遗物**（是的，地下 —— 悖论所在）。
- **遗物是彼岸的造物，却在地底出土。** 为什么？这是 v0.1 有意保留的谜团。四位 NPC 各持理论（见下）—— 彼此矛盾，但都作为"观点之 canon"存在。

## 王族隐瞒的动机（2 + 5 + 6 栈）
1. **正统性的真空（公开理由）**：承认彼岸存在 = 所有王冠都降格为行省。四位王共同承认这套掩盖说法。
2. **对归来的恐惧（真正的恐惧）**：一百年的沉默可能意味着*他们*正在回来。那句警告 "Do not visit" 是*从他们发往我们*的。只有王族明白这一点。每一位王在继位时由前任告知。
3. **资源垄断（实际操作）**：王族使用来自遗物的物品（不老之茶、不可击打的金属、远语之石）。一旦公开 = 垄断瓦解。

各王室：
- **Crown · King-Apparent Darrik Voss** —— 饮不老之茶；持有一枚殖民者纹章残片。
- **Faith · High Septa Malen the Unsleeping** —— 并**不**知晓殖民历史；认为一百年的沉默是神的弃绝；使用远语之石来承受失眠，却不知那是什么。
- **Free North · Chieftess Brenna Greyhold** —— 记得"我们来自彼岸"，却无法告诉她的部族；身穿以不可击打金属嵌饰的铠甲。
- **Union · Consul-Merchant Tobiah Caul** —— 一无所知；他的商人们曾把遗物当作古董收购。危险的无知；在不知情的情况下，反而成了真相追寻者的盟友。

## Depth-Walkers（E 主线）的内部分裂
- **Listeners（派一）**：部分为真正的神秘主义者，部分为**由王族雇佣的遗物矿工**。Archdepth Sula 是他们半疯的偶像；她本是最初的受雇矿工。
- **Crossers（派二）**：从 Listeners 分裂出来。拒绝把遗物交给王族。秘密工程化一种跨越 Chasm 的办法。由 Navigator Kestrel 领导。持有一幅题为 "from below, we may rise"（自下，我们或可上升）的草图。
- Listeners = 拿工钱、披神秘外衣的工匠。Crossers = 叛离者，带着工程技术与非法的殖民知识。

## 遗物为何在地底？（四种 NPC 理论 —— 都是 canon-as-opinion，公开层面都不正确）
1. **King's Archivist 版本**："一百年前崩塌降临时，彼岸的一部分被埋入地下。"
2. **Kestrel（Crosser）版本**："殖民时代的交通走的是地下，而非横渡。Chasm 从来不是真正的道路。"
3. **Hallen（疯归者）的呓语**："下方与彼岸本是一体。地板就是远墙。"
4. **Eilin（Maester，哑）的书写字符**："上下相通。"（Above and below connect.）

这四种说法以对话／笔记／墙上字符的形式出现，各自挂名到具名的 NPC 上。orchestrator（编排者）永不确认哪一种为真。

## 各主线的灵魂角色（Soul Figures）
- **A Guild's Buried Charter**：Magister Corvin Ashford-Reed（T005）。副：Keeper-Commander Olric the Silent（死去 200 年，葬于 T003）。
- **B World Before the Fog**：Maester Eilin of the Broken Tongue（T003）。副：Preceptor Vossel the Younger（T002）。
- **C Four-Crown Intrigue**：Darrik Voss / Malen / Brenna / Tobiah（每王国一位）。副：Ashen Herald（T005）。
- **D Iron Dragon Returns（暗线）**：Veyl "the Line"（T005）。副：Old Shepherd Bram（T004）。
- **E Depth-Walkers**：Archdepth Sula（T005, Listeners）。副：Navigator Kestrel（T004, Crossers）。联络：Yannic "Yan" Vello（T002, 年轻的 Listener）。

## Hook 层级
- **Tier 1 hooks 在 T001（Stoneford）**：A, B, C
- **Tier 2 hooks 在 T002（Windrest）**：D, E

## 五城推进
Sprout（听闻）→ Involvement（选边）→ Critical（在 T005 做出不可逆决定）。

| 主线 | Sprout | Involvement | Critical |
|------|--------|-------------|----------|
| A | T001 | T002–T003 | T004–T005 |
| B | T001 | T002–T003 | T003/T005（Eilin/T005 废墟之城）|
| C | T001 | T002–T004 | T005 四冠会议 |
| D | T002 | T003–T004 | T005 Veyl 揭露 |
| E | T002 | T003–T004 | T005 Sula + Crossers |

## 跨主线依赖（必须遵守）
- A ↔ B：Guild 的 "Northern Ban" 引用了石片文本。
- A ↔ C：Guild 最初是四冠仲裁机构。
- A ↔ D：Guild 压制"直线云"目击；向 Old Bram 施压。
- B ↔ E：Eilin 因为证明"大崖 = Great Chasm"而被割舌；Kestrel 收藏她的图画。
- C ↔ E：只有北方王族（Crown + Free North 的高层）知晓真相；压制 Depth-Walkers 是一项王家政策。
- D ↔ E：云出现的那一夜，所有 Depth-Walker 单元都熄灯下潜；Crossers 将其读作"彼岸派来了斥候"。

## 残片清单（须在城镇文件中落位）

| 残片 | 持有者 | 位置 | 主归主线 |
|------|--------|------|----------|
| 上古石片（Ancient stone shard）| Septon Silas | T001 | B（+A/E 交叉）|
| 旧 Guild 黄铜令（Old Guild brass token）| 藏于酒馆炉石下 | T001 | A |
| 无法锤打的金属块（Un-hammerable metal lump）| Blacksmith Durm | T002 | D（+动机 6）|
| 墙面字符 "上下相通"（Above-and-below connect）| 修道院后墙 | T003 | B（Eilin）|
| 不老茶渣（Unaging-tea dregs）| Crown 使节遗下的茶杯 | T004 | C（+动机 6）|
| Crosser 草图 "from below, we may rise" | 图书馆深藏区 | T004 | E派二（+B 交叉）|
| 殖民者纹章残片（Colonist crest fragment）| Veyl 的衣袋 | T005 | D（+殖民史）|
| Listener 契约羊皮纸（Listener contract parchment）| Sula 的书桌 | T005 | E派一（+动机 6）|
| 直线云（天象事件）（Straight-line cloud）| T001→T002 之间的天空 | T002 | D |
| 半焚 "Northern Ban" 诏令（Half-burned "Northern Ban" decree）| Archivist Naryn 的柜 | T003 | A（+殖民史）|

## 声音与风格
- 第三人称有限视角，短段落，物理细节，不用感叹号。
- 调性：low-fantasy 政治阴谋 × 阴郁的怪物猎人边境 × 东方异界形而上学。
- NPC 对白：简洁、间接，带有隐含的前史。
- 永不向玩家解释那个隐藏前提。

## 每位写手的交付格式
单一 Markdown 文件，路径 `game/storylines/<ID>-<slug>.md`：

```
# Storyline <ID>: <Name>

## Function
（本线的一段式目的）

## Soul figure(s)
（姓名 + 角色 + 首次登场城镇）

## Hook
（tier，哪座城，触发条件）

## Clues by town
| Town | Carrier | Type | Content |
对 T001..T005 的每一座：列出每一枚残片、每一句 NPC 台词、每一处场景节拍、每一件物品掉落、每一处字符。

## Stage endpoints
- Sprout end:
- Involvement end:
- Critical decision at T005:

## Cross-line interactions
（显式引用："references clue X of line Y"）

## Write-in checklist for town writers
（要点列表："T001/npcs: add dialogue to Septon Silas about...", "T003/facilities: add monastery wall glyph '上下相通'", 等等）
```
