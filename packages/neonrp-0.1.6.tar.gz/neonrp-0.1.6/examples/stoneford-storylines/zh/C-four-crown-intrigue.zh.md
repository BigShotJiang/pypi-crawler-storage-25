# 主线 C：四冠阴谋（The Four-Crown Intrigue）

> 源文件：../C-four-crown-intrigue.md  · 译文仅供审阅，以英文原版为准

## Function / 功能

C 线是 Grey Reach 的政治-哲学脊柱。A 问"谁在守记录"，B 问"什么被忘记"，D 与 E 问"什么在归来"，C 问的是一切之下的那个问题：**谁的王冠有权决定**。四个王国坐在一张桌前 —— 而桌上还有一把没人愿意指名的第五椅。

四位王家灵魂各自承一种世界观，戴在口、衣、食与誓言之形里。Crown 信：合法性在血里。Faith 信：合法性在誓与兆里。Free North 信：合法性在部族同意里。Union 信：合法性在账册里、在契约里、在一个人的话被写下并有证人时所称的重量里。这些不是抽象。它们是各人握勺子的方式，是各人签信的方式，是各人哀悼亡子的方式。

四位中有三位知一密 —— 它一旦被戳破，四冠尽溶。第四位是一位商人，正无意地以十二件一批地在卖那件证物。第五位灵魂 —— Ashen Herald —— 戴面具，在峰会边缘行走，每一次开口都当面否定桌上每一顶王冠。此线于 Mistmere 的一次峰会中抵达 critical，玩家或将被迫坐进五椅之一 —— 或坐进那第五把。

玩家不应通过此线*学到*殖民历史。玩家应*感到*它：一种压在王座厅地板之下的分量，两位知情之王之间的沉默，一王饮而另一王不得饮的一杯茶，一位族长所穿、她不解释的一片铠甲纹。

## Soul figure(s) / 灵魂角色

- **Crown —— King-Apparent Darrik Voss**（T001 以使节初现；T004/T005 亲临）。Ashcrown 继承人，三十多岁，瘦，按南地风尚净面。饮一种无旁人得饮的琥珀茶。*知*。
- **Faith —— High Septa Malen the Unsleeping**（T001 以宣告初现；T003/T005 亲临）。五十，袍如湿灰，眼周如十年未眠——事实上也未眠。*不知*。
- **Free North —— Chieftess Brenna Greyhold**（T002 仅经使节 **Ylva Stoneshield** 出场；T005 亲临）。铠甲嵌以 Reach 铁匠无法锤打的浅色金属。四十二。*记得，却不能说*。
- **Union —— Consul-Merchant Tobiah Caul**（T001 港口初现；T002/T004 经账册；T005 亲临）。壮，红颊，全屋最友善之人。*一无所知*。他的诚实，是峰会上最危险之物。
- **副灵魂，Fog —— The Ashen Herald**（T005，戴面具，无名）。未受邀而至。以原则并当面拒绝所有四冠。

NEW NPC 标识（城镇文件中需加）：
- **NEW NPC T001 · Jenn**，信使，平民，在 hook 中于港口被追。
- **NEW NPC T002 · Ylva Stoneshield**，Chieftess Brenna 的使节 —— 标为 Captain Yura Stoneshield（既有 NPC_T002_01）的表亲；Ylva 南携 Brenna 之信。
- **NEW NPC T004 · Envoy Alric of House Voss**，Darrik 的南口；以封锡携琥珀茶；其茶杯留下"不老茶渣"（残片，按 SHARED_BRIEF）。
- **NEW NPC T005 · King-Apparent Darrik Voss**，Crown 灵魂。
- **NEW NPC T005 · High Septa Malen the Unsleeping**，Faith 灵魂。
- **NEW NPC T005 · Chieftess Brenna Greyhold**，Free North 灵魂。
- **NEW NPC T005 · Consul-Merchant Tobiah Caul**，Union 灵魂。
- **NEW NPC T005 · The Ashen Herald**，戴面具，Fog 副灵魂。

## Hook

**Tier 1，T001 Stoneford，黄昏的港口。**

一位叫 Jenn 的信使被两个身着素灰羊毛的男人沿码头板追击。肩上流血。靴内一封信。玩家若介入 —— 以刃、以喊、以绳 —— 二人便罢手，因为他们不是刺客，他们是雇来的打手，雇来的打手不为几枚银子送命。

Jenn 脱险后会把信塞入玩家手中，只说一句：*"The four will sit. If the Fourth doesn't know what he is sitting on, they will eat him. Get this to anyone who isn't wearing a crown."*（四位将坐。若第四位不知他坐在什么之上，他们会吃掉他。把这封信交给任何不戴王冠的人。）

信封蜡印在 Stoneford 无人认得 —— 一个围着空心的四点结。此印是北方 Guild 原初所服侍的仲裁机构之纹章。*（参 A↔C 依赖。）*

信内为商旅速记 —— Tobiah Caul 自家的商人密码，Jenn 从一位 Union 文书处偷得。在 T002 解码后（Old Zhao 五十金，或玩家卖信于 Tobiah 由其自家文书代解），内文为：

> *To any honest house that still answers letters — The four crowns have agreed to sit at Mistmere at the next dark moon. They are sitting on an heir that none of the four has seen. Three of them mean to bind the Fourth before he knows what binding is. I write to no crown. I write to whoever reads this. — a hand.*
>
> （致任何仍回信的诚实之家 —— 四冠已约定在下一次新月于 Mistmere 同坐。他们正坐在一位无人见过的继嗣之上。三位意在令第四位在不知何为绑缚前即被绑缚。此信不致任何王冠。此信致任何读到它的人。—— 一只手。）

信未署名。那只手是 Ashen Herald 的。

## Clues by town / 各城线索

### T001 · Stoneford —— Sprout

| 载体 | 类型 | 内容 |
|---|---|---|
| Jenn（NEW）| 场景 | 码头追逐。Jenn 的血滴在一箱盐鱼上。此箱属 Tobiah Caul —— 戳印 *CAUL & SONS · HONEST WEIGHT*。|
| Jenn（NEW）| 物品 | **Herald 之信**。四结印，空心。商人密码。下游可解。|
| Mira Ashford（既有 NPC003）| 台词 | 被出示印，她手停在壶上。"The old arbitration mark. My grandmother had a plate with that on it. She used it for funerals only."（旧仲裁纹。我祖母有一只这样的碟。只在葬礼时用。）|
| Old Reed（既有 NPC002）| 台词 | "Four-knot? That's from before the crowns settled. Before any of it settled. Put it away, friend. Put it in a pocket that isn't yours."（四结？那是王冠安定之前。一切安定之前。收起来吧，朋友。放进一个不是你的口袋。）|
| Heron Blackwater（既有 NPC001）| 台词 | 看印。看玩家。喝一口。"The Guild used to answer to that knot. Before the Guild answered to coin."（Guild 曾答那枚结。在 Guild 答银子之前。）*// public=闲话, feared=Guild 比王冠老，仍藏着它当年饮过的那只杯, private=我地窖里有最后一次仲裁的纪要* |
| 码头工（无名）| 台词 | "Tobiah Caul's clerk came down asking about a missing courier. Paid a copper to anyone who'd seen a girl with a shoulder-wound. Didn't ask for her name."（Tobiah Caul 的文书下来问一名失踪信差。见过肩上带伤女孩的人得一枚铜。没问她的名字。）|
| Tobiah Caul（NEW，客串）| 场景 | Tobiah 本人这周在 Stoneford，亲自视察一批盐鱼。壮，红颊，对自己的笑话笑得太响。项下一条带十二扣的商人链，每一扣对应一次诚实之衡。他不知为何有人想杀他的信差。他真心恼火。*// public=对雇员的关切, feared=有人开始察觉到我所不知, private=无；他无"私"。这正是问题所在* |
| Tobiah 的文书 | 物品 | 一份清单。盐鱼亚麻之间：*"Item 47 — twelve brass cups of antique foreign manufacture, sold to Consul-Merchant's private collection, three silver the lot."*（第 47 项 —— 古异邦制造的黄铜杯十二件，售予 Consul-Merchant 私藏，全批三银。）这些是遗物器皿。他当古董买下。|
| 码头木箱 | 残片 | **木箱戳印** 载 Tobiah 家训：*"Honest Weight, Honest Word."*（诚之衡，诚之言。）C 线养料：Union 的誓言风格是契约的、商业的，可称之物。|

**Sprout 场景 —— 对不上的印**

> 蜡是旧红，近棕。四结印得整洁。中心是空的。
>
> Mira Ashford 把那只碟放上桌。碟一侧裂了，釉灰，中心一枚黑结 —— 四环，中空。
>
> "Funerals,"（葬礼。）她说。"Only funerals. My grandmother said the plate was for when there was nothing left to argue over."（只葬礼。我祖母说，这碟是当再无可争之事时用的。）
>
> 玩家将信印举近碟边。同一个结。中间同一个洞。
>
> Mira 不碰它。

### T002 · Windrest Keep —— Involvement 一阶段

Chieftess Brenna Greyhold 的使节 Ylva Stoneshield 在未染羊毛之停战旗下，率六骑抵 Windrest。她是 Captain Yura Stoneshield 的表亲 —— 同家族，不同支，不同国。Yura 十一年未见她。

| 载体 | 类型 | 内容 |
|---|---|---|
| Ylva Stoneshield（NEW）| 描述 | 高，淡发，双辫。深皮甲，肩领镶一缕不反光的浅金属。嵌纹非结 —— 是一线，直如刻度，贯颈自领至领。|
| Ylva Stoneshield | 台词 | 被敬酒时："I drink after my chieftess, not before her."（在我族长之后饮，不在她之前。）*// public=北方礼, feared=先饮即先主张，而 Free North 不主张, private=Brenna 嘱我永不接王冠之杯* |
| Ylva Stoneshield | 台词 | 私下，在马厩对 Yura："She is riding south herself. Brenna. To Mistmere. She will not send a proxy for this."（她亲自南行。Brenna。去 Mistmere。她不会为此事派代理。）Yura："Why?" Ylva："Because she said, and I quote, *'if we send a proxy they will sign it in our name.'*"（因为她说 —— 原话 —— *若我们派代理，他们会以我们之名签字。*）*// public=族长亲临, feared=其余三冠会在无声中把 Free North 签进一桩掩盖, private=Brenna 知此峰会关乎我们所来之处，她不肯以代理之口坐* |
| Ylva Stoneshield | 物品 | **Brenna 致 Herald 的封缄回信**。印：素蜡上一条浅线。非 Ylva 不可投递。若玩家受信（社交 DC 17，或玩家未被问即出示 Herald 之信），Ylva 会以族语说一次，事后翻译：*"Vi kam fra den andre sida."* —— *"We came from the other side."*（我们来自彼岸。）她只说一次。她说那是她祖母从前唱的童谣。她不会说第二次。*// public=催眠曲, feared=族人不知此事，也永不该知, private=Brenna 独自承担着北方最古老的记忆* |
| Old Zhao（既有 NPC_T002_02）| 服务 | 五十金为玩家解 Herald 之信。朗读。吹口哨。"Not my business. Not my business. But whoever wrote this is either the bravest fool in the north or a dead woman walking."（不干我事。不干我事。但写此信者，要么是北方最勇的傻瓜，要么是一位走路的死人。）|
| Old Zhao | 台词 | "The four-knot? Old Guild. Before your grandfather's grandfather. They used to settle which crown owned which river. Then they stopped. Then the Guild started taking paid work. Same people. Different coin."（四结？老 Guild。你祖父的祖父之前。他们曾裁决哪顶王冠拥哪条河。然后停。然后 Guild 开始接付费的活。同一批人。不同的银子。）*（A↔C：Guild 原为仲裁机构，后成为掩盖之器。）*|
| Captain Yura Stoneshield（既有 NPC_T002_01）| 台词 | 看 Ylva 的嵌甲。长久不语。"That metal. My father said the chieftess-line never sells it. Said it's the only thing they'll take a blood-price for, not coin."（那金属。我父亲说族长一脉从不售之。说那是他们只接血偿、不接钱的唯一之物。）*（D 线交叉：不可击打金属残片之回声；参 SHARED_BRIEF T002 Durm 的金属块。）*|
| Mei（既有 NPC_T002_03）| 传言 | "There's a rider come from the far north. Her horse didn't need water when they got here. The stablemaster said it was a clean horse — no foam, no sweat. Three days' ride. How?"（从极北来了一位骑者。她的马到时不需水。马厩主说那是一匹干净的马——无沫，无汗。三日骑程。怎么做到的？）*（Ylva 沿路用远语之石；马是沿族道分段换乘而非一马跑到底 —— 但 Mei 没这个框架。）*|
| Brown（既有 NPC_T002_04）| 台词 | "She — the envoy — she looked at my guild-chain and said *'contract-folk.'* Like it was a bird-name. Not mean. Just — naming a species."（她 —— 那使节 —— 看了我的行会链说*"契约之民"*。像在叫一种鸟的名字。不恶意。只是 —— 在命名一个物种。）*（Free North 对 Union 的声音。）*|

**Involvement 场景 —— 马厩中的两个 Stoneshield**

> 马厩里，旧草与马汗味。Yura 背对着门。Ylva 已摘盔。她们的头发颜色相同，只是剪法相差十一年。
>
> "You still wear the Keep's badge,"（你还戴着城堡的徽。）Ylva 说。
>
> "You still wear ours,"（你还戴着我们的。）Yura 说，指向 Ylva 领口的那条浅线。
>
> Ylva 触碰它。手套下金属是温的。"We wear what we wear because we remember what we remember."（我们戴我们之所戴，因我们记得我们之所记。）
>
> "That's a saying."（那是一句谚。）
>
> "It's a *clan* saying. It's meant to be a saying."（那是一句**族谚**。它就是要作为一句谚。）Ylva 不看她的表亲。"Cousin. If you are asked, in the next six weeks, to stand for the Free North in any room south of the Brokenspine — do not stand."（堂妹。若接下来六周内有人请你在 Brokenspine 以南任一间屋子里代表 Free North —— 不要站。）
>
> "Why?"
>
> "Because the room wants a proxy. The room wants someone to sign our name for us."（因为屋子要一个代理。屋子想要一个人替我们签我们的名。）Ylva 戴回盔。"Brenna will sign her own name or no name. Tell no one I said so."（Brenna 会签她自己的名，或一个不签。别告诉任何人我说过这话。）

### T003 · Wolfsjaw 隘口 / Mistmere 入境 —— Involvement 二阶段

High Septa Malen the Unsleeping 此时驻 Mistmere Grand Cathedral，但她的外骑与布道者此时已遍布四处。玩家只有在峰会之前抢先赶到 Mistmere 才能当面见到她；否则她在 T003 只以宣告、以 Septon Silas 颤抖之手、以 Sara 苦涩的沉默出现。

| 载体 | 类型 | 内容 |
|---|---|---|
| 半焚 *Northern Ban* 诏令（按 SHARED_BRIEF 残片，Archivist Naryn 柜）| 物品 | Septa 亲手之宣告。上半："By oath and by omen, let no house north of the Brokenspine speak the old colonists' name…"（以誓以兆，令 Brokenspine 以北无一家族说出旧殖民者之名……）下半焚毁。焚痕之上：*"…for the silence of one hundred years is a door that has not been closed from our side."*（……因为百年之沉默是一扇从我们这边未关上的门。）*（A↔C：此禁由四初始仲裁席共同签署。C↔E：同一禁点名 Depth-Walkers 为王家压制目标。）*|
| Septon Silas（既有 NPC_T004_07；此处经他寄往教堂的一封信引用）| 物品 | 一封被退之信，戳 *REFUSED · BY THE UNSLEEPING*。Silas 曾写信给 Septa 询问墙面字符 上下相通（B 线）。她的回拒是三行：*"Child. You were sent to watch a mine. Watch the mine. The Faith has no mouth for questions it did not ask."*（孩子。你被派去守一座矿。守你的矿。Faith 不对自己没问的问题开口。）*// public=牧者之斥, feared=Silas 看见了 Faith 无力承认的字符, private=Septa 自己也不知字符何意，却担不起让人看出她不知道* |
| Sara（既有 NPC_T003_02）| 台词 | "The Septa hasn't slept in ten years. They say it's penitence. It isn't. Something in her chambers keeps her awake and she doesn't know what it is. I treated one of her handmaidens last winter. The girl said the Septa holds a stone to her ear at night and whispers into it. Begs it to be quiet. The stone does not obey."（Septa 十年未眠。有人说那是悔。不是。她房中有什么让她醒着，她不知那是什么。去年冬我治过她的一位侍女。那女孩说，Septa 夜里把一块石头贴在耳上，对它低语。求它安静。石头不从。）*（此为远语之石。Malen 不知其何物。参 SHARED_BRIEF 王家动机 6。）*|
| Lord Commander Linden Ironfist（既有 NPC_T003_01）| 台词 | 被问及将至的峰会：Linden 长久不语。然后："I have been told, by a woman whose name I will not say, that the summit is not about the orcs and not about the Khanate. I have been told it is about a door."（有一位我不肯说其名的女人告诉我：峰会不是为 orcs 也不是为 Khanate。她告诉我：是为一扇门。）*（Brenna 已写信给他。他们 Free North 同路。）*|
| Linden | 台词 | "The Septa sent riders to arrest any pilgrim who has been below ground. Below. Not beyond. Think on that."（Septa 已派骑者去逮捕任何去过地下的朝圣者。下。不是远。想想。）*（C↔E：王家对 Depth-Walkers 的压制。）*|
| Mark（既有 NPC_T003_03）| 传言 | "Faith man rode through two weeks ago. Not a septon — higher. Wore the Septa's collar. He was asking if anyone had heard *voices in stones.* Not demons. Not ghosts. *Voices.* Like the stone was a messenger."（两周前过了一位 Faith 人。不是 septon —— 更高。戴 Septa 的领。他问有没有人听过*石头里的声音*。不是魔，不是鬼。*声音*。像石头是信差。）|
| 修道院后墙（按 SHARED_BRIEF 残片）| 字符 | 上下相通 —— 刻，古。此处被引用，因为 Malen 的骑者被令刮之，而修士们一直为保全字符而抛光。刮除令盖 Septa 四结印 —— 与 Herald 之信*同一枚*四结。*（A↔C：Faith 仍用仲裁之印处内务。Septa 不知她的印何以与 Herald 的印相同；她只是被教如此用之。）*|

**Involvement 场景 —— 被退之信**

> Silas 今日手更抖。杯送到唇边的途中摇。他放下。
>
> "I wrote to her,"（我写信给她。）他说。"To the Unsleeping. I asked what the glyphs meant. Above and below connect. I asked her — because she is the voice of the Faith, and the Faith keeps the old records."（致 Unsleeping。我问字符何意。上下相通。我问她 —— 因为她是 Faith 之声，Faith 存旧录。）
>
> 他把退回的信推过桌面。玩家读之。
>
> "She doesn't know,"（她不知。）Silas 停顿后说。"She refused me because she does not know. If she knew, she would have answered me, even if she had to lie. A lie takes knowledge. This is not a lie. This is a woman refusing to look at a door."（她拒我，因为她不知。若她知，她会回我，哪怕只能撒谎。撒谎需要知识。这不是撒谎。这是一个女人拒看一扇门。）
>
> 他饮。他杯中有水银。他知。他仍饮。

### T004 · Jadehollow —— Involvement 三阶段

King-Apparent Darrik Voss 的使节 **Alric** 以核查 Deepvein 王家许可证为名抵 Jadehollow。实际他来做两件事：在一家特定酒馆饮一种特定茶；并查明 Tobiah Caul 的商人们是否已购下他们不应购买之物。

| 载体 | 类型 | 内容 |
|---|---|---|
| Envoy Alric（NEW）| 描述 | 三十，南装 —— 深绿上衣，袖口银饰，靴擦至可照人。以 Ashcrown 宫音发言：慢，字正，每个辅音有重量。净面。携封锡茶与银滤。|
| Envoy Alric | 台词 | 对 Kassa Deepvein："His Grace the King-Apparent extends his compliments to House Deepvein, and reminds the House that the Crown's licences are renewable at the Crown's discretion, and the Crown's discretion is a narrow gate."（殿下敬候 Deepvein 府，并提醒：王冠之许可由王冠之裁量续发，而王冠之裁量是一道窄门。）*// public=例行审计, feared=Deepvein 四层一直在卖遗物给 Tobiah 的商人，王冠须知 Tobiah 是否已察觉其所购之物, private=Darrik 亲令我来点那些杯* |
| Envoy Alric | 场景 | 每晚独自在 Jade Lantern 饮茶。一锡琥珀叶，像卷轴一样展开。精确浸四分钟。他用自带的黄铜杯饮。不请他人饮。Jade（既有 NPC_T004_04）出言：她从没见过一位使节拒店家酒。|
| Envoy Alric 的杯（按 SHARED_BRIEF 残片 —— *不老茶渣*）| 物品 | 若玩家从 Jade 处偷或贿走其杯中残渣 —— 渣为琥珀色，略甜，略有金属味。Grandmother Green（既有 NPC_T004_05）一见即极静："That is not a tea that was grown. That is a tea that was made. By hands that are not ours."（那不是长出来的茶。那是被制成的茶。出自不属我们的手。）*// public=药师之慎, feared=她曾见此色一次，三十年前一位 Depth-Walker 给她看过一张这样的叶, private=她知这茶延寿，因为她自己的母亲少女时曾饮过一次，活到一百零九* |
| Envoy Alric | 台词 | 对 Old Fane Crowseye（既有 NPC_T004_03），当 Fane 盯着锡盒："Appraiser. Eyes on your own stones."（鉴物人。管你自己的石头。）Fane："My eye does not choose what it sees, Envoy. Complain to the eye."（我眼不择其所见，使节。请向那只眼投诉。）*// public=宫之斥, feared=Fane 的灰眼把锡读作比 Ashcrown 还老, private=Alric 事先被告：此镇有一位目色沾殖民气的鉴物人，当默默存档* |
| Crosser 草图 *from below, we may rise*（按 SHARED_BRIEF 残片，图书馆深藏区）| 物品 | 在 Jadehollow 图书馆，归档于 *采矿 —— 古图*。图示一条上行的隧道通往一个开口；开口之上，那道直线云。笔迹为 Navigator Kestrel（E 线）。*（C↔E：Darrik 的人多年在找 Crosser 的这张草图。Alric 来此，部分也是查 Deepvein 是否有一份副本。）*|
| Hawke（既有 NPC_T004_08）| 台词 | "The envoy's not here for licences. He's here because Tobiah Caul's clerks have been stopping at our loading docks. Caul bought a box of *cups* last season. Brass cups. From Deepvein's fourth level. Twelve of them. Paid three silver the lot. He thought they were antiques."（使节不是来查证照的。他来是因为 Tobiah Caul 的文书一直来我们装货码头。Caul 上季买了一箱*杯*。黄铜杯。来自 Deepvein 四层。十二件。全批三银。他以为是古董。）*（印证 SHARED_BRIEF：Tobiah 不知情地购入遗物。）*|
| Kassa Deepvein（既有 NPC_T004_01）| 台词 | 下班后，私下对 Alric："If His Grace wishes an inventory of what has moved out of the fourth level, it can be assembled. It will take a week. It will be accurate."（殿下若要四层出货之清单，可编。费时一周。必准。）Alric："Make it three days. Make it accurate."（三日。要准。）*// public=审计合规, feared=Deepvein 已被付够钱知杯为何物，却未被付够钱交出账, private=Kassa 当年是诚意签的 Consortium 保密条款；她愿为王冠打破之，因为王冠比 Consortium 响* |

**Involvement 场景 —— Jade Lantern 的茶**

> Alric 独坐。锡盒在桌上开着。茶叶琥珀、窄、卷。
>
> Jade 在吧台后看。她见过千人在她桌上饮。没见过这种饮法。
>
> Alric 浸。精确四分钟。他暗数。他不看门。
>
> 玩家可上前。Alric 允其坐。不让茶。
>
> "You wish to speak, traveller."（你想说话，旅人。）
>
> "About the summit."（关于峰会。）
>
> Alric 不反应。举杯。啜。放。圈放在上次之痕上。"The summit is a crown matter. Crown matters are for crowns."（峰会是王冠之事。王冠之事是王冠所理。）
>
> "The letter I carry says three crowns mean to bind the fourth."（我携的信说三冠要缚第四。）
>
> Alric 的杯停在半途。他极小心地放下，圈精确在前一痕之上。
>
> "Show me the seal."（给我看印。）
>
> 玩家出示四结。
>
> Alric 长久不动。面色无变。然后，以一种非宫、非南地的声音说："The Herald is writing letters again. His Grace will want to know."（Herald 又开始写信了。殿下会想知道。）*// public=使节报事, feared=Herald 知王冠之所知，意味着 Herald 曾身处平民不入之室, private=Darrik 已找了 Herald 三年*

### T005 · Mistmere —— Critical

新月。四冠同坐。

峰会不在 Governor's Hall，而在 Grand Cathedral 之下的一间古室 —— 一室有四门、四椅、而北墙上第五扇门已被砌死。砌死之门上有烧制粘土做的四结印。无人解释。室中无人知何人、何时所砌。

| 载体 | 类型 | 内容 |
|---|---|---|
| 峰会室 | 场景 | 四椅。一桌。四席：一杯琥珀茶（Crown）；一杯未动的水、底沉一枚灰石（Faith）；一只骨杯盛族啤（Free North）；一只黄铜杯 —— *Tobiah 那十二之一* —— 盛普通南酒（Union）。Union 之杯是遗物。Tobiah 不知。|
| Darrik Voss（NEW，灵魂）| 描述 | 三十多，瘦。发深，按南风剪短。左拇戒一枚 —— 四结，中空。整场饮琥珀茶。不食。声低、不急，每一句都落。|
| Darrik Voss | 台词（开场）| "We sit because we have always sat. We sit because the table was set before our grandfathers, and before their grandfathers, and before. We sit to settle what cannot be settled outside this room."（我们坐，因为我们一向坐。桌在我们祖父之前已摆，在祖父之祖父之前已摆，更久之前已摆。我们坐，以裁此室之外无法裁之事。）*// public=仪式开场, feared=若此桌有人口说殖民者之名，此桌裂开，四王国沦为一个我们不再识得之地的四省, private=我饮此茶因父亲饮此茶；因为父亲之父说，此茶是我们仍在此坐的唯一原因* |
| Darrik Voss | 台词 | 对 Tobiah："Consul-Merchant. The Crown has long considered the Union a valued and — honest — partner. There are matters at this table that touch on the Union's honest trade. We would see the Union bound, as we are bound, to the sitting of this table."（Consul-Merchant。王冠久视 Union 为受重之——诚实之——伙伴。此桌有事关乎 Union 的诚实之贸。我等愿见 Union 如我等被缚般，被缚于此桌之坐。）*// public=邀其缔结, feared=Tobiah 买遗物不自知，每一只仓中之杯都是可被置于错手的利器, private=把他缚进密里，让他停止卖那些他不懂的东西* |
| Darrik Voss | 台词 | 对 Brenna，更冷："Chieftess. The Free North has been, in recent years — quiet. We ask whether that quiet is a settled quiet or a waiting quiet."（Chieftess。Free North 近年 —— 静。我等问：此静乃安之静，抑或候之静。）*// public=外交之探, feared=Brenna 一直在读古物，Brenna 是此桌唯一一位可能已告知其族我等共誓不告之事的人, private=我知她未告；我知她不会告；我需要她在此桌上告诉我她仍然不会* |
| High Septa Malen the Unsleeping（NEW，灵魂）| 描述 | 五十。袍如湿灰。眼周之色非淤非墨。整场右手持一枚灰石。偶尔贴耳。无人问。|
| Malen | 台词（论誓）| "Let this sitting be sealed by the Oath of the Four-Knot, as the Faith has sealed every sitting before it. Let the words spoken here be the words the Pattern permits. Let the silence after them be the Pattern's silence."（愿此坐以四结之誓封缄，如 Faith 封缄之前每一次坐。愿此室所出之言为 Pattern 所许之言。愿言后之静为 Pattern 之静。）*// public=仪封, feared=百年之静未断；Pattern 未答；她信诸神已退，她正以自己的碎裂撑着这场峰会, private=昨夜她手中的石以女声低语了一个她不懂的词，她惧怕留之在外，故带至此室* |
| Malen | 台词 | 对 Darrik，于一顿："Your Grace drinks a tea that the Faith did not bless."（殿下所饮为 Faith 未祝之茶。）Darrik："The Crown drinks what the Crown has always drunk, Holiness."（王冠饮王冠一向所饮，圣下。）Malen："And the Faith notes what the Faith has always noted."（Faith 记 Faith 一向所记。）*// public=例行提醒 Faith 之监, feared=她不知那茶是什么；只知母亲的账册记它"未受稽"为, private=她愿以所剩之不眠年换知此茶之所是，却骄傲不问* |
| Malen | 台词 | 对 Tobiah，出其不意地温："Consul. The Faith has always found your house — honest. Honest in its weights. Honest in its word. The Faith would welcome an oath from the Union before this table ends."（Consul。Faith 一向以贵府为 —— 诚。衡之诚。言之诚。Faith 欢迎 Union 在此桌闭散前起一誓。）*// public=欢迎入缚, feared=她正被 Darrik 用以缚商而不自知, private=她喜欢 Tobiah；他是此桌上唯一不令她惧怕的人；她若知道如何，她会保护他不被其余三人缚* |
| Chieftess Brenna Greyhold（NEW，灵魂）| 描述 | 四十二。高，肩阔，鬓骨白编发。深皮与浅嵌金属之甲 —— 嵌为直线，横贯领、肩、臂甲。无家徽。誓在自己的前臂上起，由族刀划就，不在任何书面文件上。|
| Brenna | 台词（答 Darrik 之探）| "The Free North sits where the Free North has sat. We have told our clans what our clans need to know. We have not told them what our clans would not ask. If the Crown wishes the Free North to speak more, the Crown may ride north in summer and ask at the hearth, as hearth-folk ask."（Free North 坐其所坐。我们已告诉族人族人所需知。我们未告知族人所不问。王冠若愿 Free North 多言，王冠可于夏日北行、在炉边如炉边之人问。）*// public=族礼之推, feared=Darrik 在问我是否已告诉族人我们来自彼岸；他在问，因为他担不起我告诉他们, private=我未告。我不会告。但我也不会被缚进一间替他们做决定的屋子* |
| Brenna | 台词 | 对 Tobiah，未受问，整个身子转向他："Consul-Merchant. You have brass cups in your warehouses. Twelve, I am told. They are not brass. If you value your house, you will melt them down before the next dark moon. Do not ask me how I know. Do not answer me in this room. Nod if you have understood."（Consul-Merchant。你仓里有黄铜杯。我被告知有十二。它们不是黄铜。若你珍惜你家，在下次新月之前熔掉它们。别问我怎么知。别在此室答我。若你懂，点头。）*// public=一则离奇的警告, feared=她刚破峰会礼，警告了那个我等都不应警告的人, private=我不能让此桌吃他；我母曾嘱我永不让王冠缚一个不知自己被缚何物的人；那些杯是遗物，而他一直把它们当厨具* |
| Consul-Merchant Tobiah Caul（NEW，灵魂）| 描述 | 壮，红颊，五十余。十二扣商人链。全室唯一戴行会徽而非王冠之纹的人。他不饮那杯酒 —— 他注意到那只黄铜杯是自己仓中认得的款，笑意之下他是真的困惑。|
| Tobiah | 台词（开场，被允发言）| "Your Graces. Your Holiness. Chieftess. The Union is — honoured. Honoured and — I will confess — puzzled. My honest trade has no business at a crowns' table. If the crowns wish the Union's oath, they may have it: *Honest Weight, Honest Word.* That is our oath. It is the only one we keep, and we keep it well."（诸位殿下、圣下、Chieftess。Union 深感 —— 荣幸。荣幸而 —— 我承认 —— 困惑。我的诚实之贸无事可陈于王冠之桌。王冠若愿取 Union 之誓，可得之：*诚之衡，诚之言*。此我等之誓。此我等所守之唯一，守之甚善。）*// public=商人之谦, feared=我不知为何在此，而我四十年贸易中学到：当你不知为何在桌上时，有别人已替你决定你要付什么, private=我害怕，我在假装不怕* |
| Tobiah | 台词 | Brenna 警告杯之后，慢慢看着自己手中的黄铜杯："Chieftess. The cup. The cup in my hand. I bought twelve of these, last autumn. From a Jadehollow vendor. Three silver the lot. I thought — I thought they were antiques."（Chieftess。杯。我手里的杯。我去年秋买了十二件。自 Jadehollow 一位商贩。全批三银。我以为 —— 我以为它们是古董。）*// public=困惑之承, feared=桌上四人中三人骤静，他察觉到, private=他看向 Darrik，因为 Darrik 的静不是惊讶；Darrik 的静是认出* |
| Tobiah | 台词 | 轻声，不对任何人："Your Graces. Whatever this cup is — I would like to be told. I would like to be told honestly. My house's word is good. My house can keep a secret. But my house will not keep a secret my house does not know it is keeping."（诸殿下。无论这杯是什么 —— 我愿被告知。愿被诚实地告知。我家之言可信。我家能守密。但我家不会守我家不知自己在守的密。）*// public=请入共缔, feared=他问了四冠中三冠共议他不可问的那个问题, private=这是 Tobiah 最好也最危险的样子；他在诚意问真相，而此室无法给他* |
| Darrik Voss | 台词（答 Tobiah）| "Consul-Merchant. The cup is old. Older than this table. Older than the kingdoms. The Crown has long held that certain antiquities are — best kept at the Crown's table. We would offer the Union, in exchange for the twelve cups in its warehouses, the Crown's protection and the Crown's full partnership in matters that have, until this day, remained between three crowns."（Consul-Merchant。此杯古。比此桌古。比诸王国古。王冠久持：某些古物 —— 最好留在王冠之桌。我等愿以王冠之护与王冠之全谋，换 Union 仓中之十二杯；此谋事至今日为止只在三冠之间。）*// public=升格之邀, feared=我必须把那些杯拿回来，今晚必须缚住他，否则到来春半个 Ashcrown 会知我们是什么, private=他太诚实；他会问问题；但另一种结果是一位仓中藏十二只遗物杯的商人成为国中最危险的平民* |
| Brenna | 台词（再破礼）| "Consul. You need not answer His Grace tonight. You may answer him in a year. You may answer him never. The Free North will accept your silence as your answer, and will ride home."（Consul。今晚你不必答殿下。你可以一年后答，也可以永不答。Free North 接受你的沉默作为答，然后骑马回家。）*// public=族式之耐, feared=她在给 Tobiah 一个 Darrik 不愿给的退路，Darrik 知之, private=若 Tobiah 今晚受缚，四冠成一密，Free North 成其中唯一族声；若他拒，四冠留为四* |
| Malen | 台词 | 长静。然后，不看任何人："The Faith would — accept the Consul's oath, whatever its shape, and would hold the oath-keeper's silence sacred. As the Faith holds all oath-keepers' silences sacred."（Faith 将 —— 接受 Consul 之誓，无论其形，并视守誓者之沉默为神圣。如 Faith 视一切守誓者之沉默为神圣。）*// public=Faith 对任何自愿之誓的祝福, feared=她在惧，她意识到若说任何明确之言都可能说错, private=她不知杯里是什么，亦不愿知；她只愿睡* |

**峰会场景 —— 四只杯**

> 室在 Grand Cathedral 之下，沿一座全年除此日之外日日上锁的窄阶而下。阶窄。四冠各自独自下行。卫兵候于顶。
>
> 室圆。顶低。四门开向四平台；第五扇门——砌死、面覆浅粘土——坐于北墙，中央压着四结。粘土比砖更古。无人知谁压。
>
> 桌圆。四椅不一。Darrik 的是深木高背椅，刻 Ashcrown 之叶。Malen 的是无靠凳——Faith 不设靠背——软垫素毛。Brenna 的是族凳，可坐三人而她独坐其中。Tobiah 的是商人椅，皮面带轮——从大教堂图书馆下抬来的折衷之选，因为没人知该给他什么椅。
>
> 杯已摆。琥珀茶。石水。族啤。黄铜杯酒。
>
> Darrik 先入。见杯。坐。未饮。
>
> Malen 次入。见杯。未坐。在自己的门下站足七数，默默把 Pattern 念入门框，然后才步入。坐。完全不饮。
>
> Brenna 三入。已携自己的骨杯 —— 按 Free North 之礼，她带来之。坐。把骨杯放在大教堂所备的族啤杯旁；大教堂之杯整场未动。她的讯息 Darrik 与 Malen 可读。Tobiah 不可读。
>
> Tobiah 四入。室中唯一笑之人。见杯。出声："A brass cup. Well, I like a brass cup."（一只黄铜杯。好，我喜欢黄铜杯。）坐。取酒。举杯，向不确定何人敬半举，饮。
>
> Darrik 看他饮。面无变。
>
> Brenna 看他饮。桌下右手已至腰带处族刀。
>
> Malen 看他饮。灰石已贴耳。
>
> 峰会已开。

**峰会场景 —— 开场之轮**

> Darrik 念开场。仪式措辞 —— *we sit because we have always sat* —— 说得无重音；他已在此前三次四冠之坐中说过，此言在口中磨光。
>
> Malen 答。她念封缄 —— *let this sitting be sealed by the Oath of the Four-Knot*。她的声很薄。Darrik 注意到。不反应。
>
> Brenna 念 Free North 的承认。是四冠之坐史上最短之承认。*"The Free North hears. The Free North listens. The Free North will speak when spoken to."*（Free North 听。Free North 聆。Free North 被问时而言。）到此止。Darrik 与 Malen 都在等更多。没有更多。
>
> Tobiah 末念。他以 *"Your Graces. Your Holiness. Chieftess."* 开始，然后停下，因为他意识到他不知仪式措辞。他即兴。*"The Union is — honoured to be asked. We will do our honest best to deserve the asking."*（Union —— 受邀为荣。我等将尽诚以配此邀。）
>
> 依 Union 之标准，是一段小致辞。依峰会之标准，是一份签在空白文件上的签字。Darrik 松。Malen 吐气。Brenna 的手未离族刀。

**峰会场景 —— 杯之揭**

> 是 Brenna 破室之人。
>
> 她已听完 Darrik 之探 —— *Free North 近年 —— 静* —— 并以族礼之答回之。她已听完 Malen 邀 Tobiah 之誓。她已看见 Darrik 下钩。
>
> 然后她转身，全身在族凳上旋过去面对 Tobiah，她说 —— 不响，也不轻 —— *"Consul-Merchant. You have brass cups in your warehouses. Twelve, I am told. They are not brass. If you value your house, you will melt them down before the next dark moon. Do not ask me how I know. Do not answer me in this room. Nod if you have understood."*
>
> 室静。
>
> Darrik 放下茶。杯于木上作一小而清之响。
>
> Malen 的石自耳落入她的腿上。
>
> Tobiah 看自己面前的黄铜杯。然后看 Brenna。然后看 Darrik。Darrik 面全静 —— 非惊、非怒，*静* —— 商人读得出的那种静。
>
> Tobiah 未点头。也未摇头。他替之问。
>
> *"Chieftess. The cup. The cup in my hand. I bought twelve of these, last autumn. From a Jadehollow vendor. Three silver the lot. I thought — I thought they were antiques."*
>
> Brenna 不答。她已说完。她不在族礼之外答人问。
>
> Tobiah 转向 Darrik。*"Your Grace. My house's word is good. My house can keep a secret. But my house will not keep a secret my house does not know it is keeping. What is in the cup?"*（殿下。我家之言可信。我家能守密。但我家不会守我家不知自己在守的密。杯里是什么？）
>
> Darrik 未立答。他取起琥珀茶。饮。放。以王冠之复数说：*"The cup is old. Older than this table. Older than the kingdoms."*
>
> *"That is not an answer, Your Grace."*（那不是回答，殿下。）
>
> *"It is the answer the Crown is prepared to give."*（那是王冠愿给的回答。）
>
> Tobiah 在轮椅上靠回。椅吱响。在此室中此吱声甚是荒谬，其余三冠中的两人微缩。
>
> *"Then the Crown is asking the Union to take an oath against the weight of a cup the Crown will not name,"*（则王冠是在请 Union 对一杯王冠不肯命名之物的分量立誓。）Tobiah 慢慢说，像在此刻将之想通。*"That is not — your Grace. That is not an honest weight."*（那不是 —— 殿下。那不是诚实之衡。）

**Ashen Herald 之入**

峰会进行之时 —— 杯之揭之后、任一誓未起之前 —— Ashen Herald 到达。她非被允入；她只是*已在*。四门之卫后来都发誓门未开。第五砌死之门亦无变。

| 载体 | 类型 | 内容 |
|---|---|---|
| The Ashen Herald（NEW，副灵魂）| 描述 | 高，披长及踝之灰袍。面覆未上釉之陶。眼孔空。面具无纹章 —— 或者说面具*本身*即 Herald 的纹章：四结空心，化身为人。声音不像女也不像男。不携武器。以板书字，只在关键时口说。|
| Ashen Herald | 台词 | 走到室中央。看四人。在板上写。举起。*Three of you know. One of you does not. Your business is to keep it so. My business is to say otherwise.*（你们之中有三位知。一位不知。你们之务，是保其如是。我之务，是说其为非。）|
| Ashen Herald | 台词（口说，对 Tobiah）| "Consul-Merchant. You have been asked to take an oath whose weight has not been shown to you. I, who answer to no crown, ask you to weigh it first. *Honest Weight, Honest Word.* Is it your oath, still?"（Consul-Merchant。有人请你立一誓，而誓之分量未曾示你。我——不答任何王冠——请你先衡之。*诚之衡，诚之言*。此仍是你的誓吗？）*// public=修辞之诉, feared=她走进一间封缄之室，把 Union 自家的家训回掷给 Union，意味着她比 Union 更懂 Union, private=Herald 在给 Tobiah 第五选项：拒绝四冠，与她同立，与 Fog 同立，与无人同立* |
| Ashen Herald | 台词（对 Darrik）| "Your Grace drinks a tea that was not grown. You have drunk it since you were fifteen. Your father drank it. His father drank it. The Ashcrown is old, Your Grace, but the tea is older. I ask you — in front of this table — from whom did the first cup come?"（殿下所饮之茶非长出之茶。十五岁起你饮之。你父亲饮之。他的父亲饮之。Ashcrown 老，殿下，而茶更老。我在此桌前问你——第一杯自何人来？）*// public=激, feared=她将要说出殖民者之名；百年来唯一会说之人, private=她不会说；她会把它留给 Darrik 说，或不说；此乃她的技艺* |
| Darrik Voss | 台词（答 Herald）| 沉默。长沉默。然后："The first cup came from our fathers, Herald. As all things come from our fathers."（第一杯自我们的父辈来，Herald。如一切自我们的父辈来。）*// public=闪避, feared=她说得对，他知她说得对, private=他刚在三冠与一商面前选择了不说那个词；他选择了掩盖而非真相，Herald 听见了他的选择* |
| Ashen Herald | 台词 | "So be it. The table has sat. The table has spoken. The table has not answered. I withdraw."（如是。此桌已坐。此桌已言。此桌未答。我退。）|

**Critical decision —— 第五把椅**

玩家若跟至此，将在峰会室内出现 —— 或为 Jenn 的代笔信差，或为 Tobiah 的顾问（Union 路径），或为 Alric 的审计侍从（Crown 路径），或为 Ylva 的次从（Free North 路径），或为 Silas 的见证（Faith 路径，若 Silas 在 A/B 线活得足够久），或为未受邀（Fog/Herald 路径）。

Herald 退场之时，她在门口一回首，向玩家递出一选。不是口说。是一个透过空面具的眼神。

**五分支：**

1. **为 Crown 而立。** 替 Darrik 开口以在今晚缚 Tobiah。Tobiah 在胁迫下立誓。十二杯上缴。四冠掩盖再维持一代。Darrik 欠玩家一份情。在日后几幕中，玩家将被请履约 —— 或被请偿还。
2. **为 Faith 而立。** 替 Malen 开口，以 Pattern 之名认可此缚。Malen 在峰会之夜十年来第一次入眠。玩家无意中成为 Septa 的*负梦者*。（D 线 hook：直线云在次晨于 Mistmere 之上出现；Malen 的灰石再发女声，从此她听得见、抹不掉。）
3. **为 Free North 而立。** 替 Brenna 开口。Tobiah 被允拒。峰会无缚而散。三冠怒归。Brenna 凝重而归。不出一季，Tobiah 的商人们开始问王冠无法回答的问题。（引出 A 与 E 的 critical 节拍。）
4. **为 Union 而立。** 替 Tobiah 作其诚实之副。要求在立誓前看清誓之分量。Tobiah 有后盾，再问：*杯里是什么？* 无人答。Tobiah 撤出其家于桌外。Union 走出四冠之框。四冠两百年来第一次坐于三把椅上。（最具动摇力；A 线的 Guild 档案开始被重开，因为 Union 的撤出重启了仲裁机构。）
5. **为 Fog 而立 —— 第五选项。** 接受 Herald 递出的沉默。随她从卫兵事后发誓未开之门离去。玩家此后无国。玩家有一副在 T005 港口等着他们的未上釉之陶面具。（D 与 E 的 critical 节拍都向玩家敞开；A 线 Guild 以违反 Northern Ban 为由追捕玩家。）

## 四个王国 —— 见，不述

本节为城镇写手的参考页。A-E 中每一位引用某王国的 NPC 必须守这些细节。王国的世界观须载于 **voice, costume, food, and oath-style / 声、衣、食、誓之形**，绝不通过说教。

### The Crown（Ashcrown）

**价值**：合法性在血里。王冠是一*具身体*，自一具传于下一具。*heir*（继嗣）一词神圣。

**声**：南地宫音。慢，字正，每个辅音权衡。用复数 —— *the Crown holds, the Crown drinks, the Crown has long considered* —— 不用第一人称单数。异议措辞为 *the Crown's discretion is a narrow gate*。永不拔高音量。必须提高音量的 Crown 声已输。

**衣**：田野暗绿或灰褐羊毛，宫廷深蓝丝绒。袖银饰。左拇戒不在指，拇戒为王冠身份之标；在 Brokenspine 以南戴拇戒的平民会被捕。发短。净面。靴擦至可照人。

**食**：Crown 贵族若能避免，不当平民面进食。私餐小：野禽、软酪、腌根、琥珀茶。茶以黄铜或银滤上 —— 永非陶。被给陶杯的 Crown 宾已被辱，辱只对其他 Crown 之人可读。

**誓之形**：誓在立誓者自身之躯起。Crown 之誓以右手掌触胸骨，念立誓者之父及父之父。*"By my body, and by my father's body, and by his, I will hold this."* 破誓视为对祖脉之袭。Crown 叛徒非只被杀 —— 其名被自父系名录划去，名录在宫中每年一次被朗读，划去的名字各停一静。

**在峰会**：Darrik 戴拇戒。以复数言。其茶为琥珀。若立誓，触胸骨。

### The Faith（The Septon Order of the Pattern）

**价值**：合法性在誓与兆。Pattern 为世之正序；Septa 之职为读之、说之。王冠之合法，因 Pattern 容之。Pattern 退（如 Faith 百年来所惧），合法性本身即成权宜。

**声**：慢、陈述、经文节奏。用古变位 —— *let this sitting be sealed, let the words spoken here be the words the Pattern permits*。Malen 尤不用缩读。不用第一人称 —— 她以 *the Faith*、*this servant*、*one who watches* 言。惧时她更*向*经文节奏倾斜。

**衣**：袍如湿灰，至踝。素麻领。腕一串木祈珠 —— 九珠对应 Pattern 九季。颈一枚未磨灰石系皮绳。Malen 的石不同 —— 更大、更滑；她的不是祈石，是远语之石；她不知。

**食**：Faith 人只于 Pattern 七时进食，只食灰物 —— 灰面包、灰粥、河鱼。色被视为对 Pattern 读之分心。被给彩食的 Faith 宾可客气拒，亦可食，二者皆不以为忤。

**誓之形**：誓以 *Pattern-binding* 起。立誓者站门下 —— 任一门、任一阈 —— 以念誓入框。Pattern 由门之形*见证*此誓。破誓为世之几何之裂，破誓者被认为自内而默然散解：先失食欲，次失睡，末失己名。Malen 十年未眠。她不知自己正被何誓散解。

**在峰会**：Malen 的灰石在右手。每次将发言，她半息贴耳。她不自知。

### The Free North（Greyhold 部族）

**价值**：合法性在部族同意。Chieftess 是部族之*声*，非其统治。炉边无法撤回之权威非权威 —— 是占领。Free North 之王不治；他们*言*。

**声**：短句。具名名词。动词先于形容词。*"We sit where we have sat. We speak what our hearths know. We do not speak what our clans do not ask."* Free North 之声避抽象、避王家复数；*we* 只用于真有一群人，绝不作王家代称。Brenna 尤其：只有在准备被违抗时才用 *I*。

**衣**：深皮。冬日领袖毛；夏日袒臂。编发 —— 辫数表族阶而非年龄。肩、领、臂甲嵌浅金属，成直线之纹；此纹**非**纹章 —— Free North 不戴纹章；他们戴的是族匠从族匠之母处所学之纹，以河、山，及一些无人肯解释其名之物为名。Brenna 的嵌贯喉自领至领。Reach 中未有人当面问她。

**食**：共食。Free North 使节共锅而食；族长末食，非先食。族啤以骨杯饮，每人一杯，杯由饮者携，非由主人备。从主人之杯饮即承主人之权威 —— Free North 族长不为。Ylva 的 *"I drink after my chieftess, not before her"* 是表层；更深一层为 *我不从你的杯饮，因为我不承认你的家*。

**誓之形**：誓在前臂起，以族刀划就，划痕即誓。守誓者之臂是一份记录；族长之臂是一部小族史。Brenna 的臂，在臂甲之下，有三十一道。破誓由族断，不由族长 —— 族长可召炉会，但不可罚。Free North 无狱。

**在峰会**：Brenna 戴臂甲坐，但右袖推至肘。臂可见。其余三冠懂。Tobiah 不懂。

### The Union（Caul & Sons, the Honest-Weight Guild）

**价值**：合法性在账册。契约是可称之物；言是可写之物；誓是可证可签之物。Union —— 真心、不讽地 —— 相信：若王冠记好账，王冠之事会办得更好。

**声**：平实北商。用缩读。自由用第一人称。*"I would like to be told. I would like to be told honestly."* Union 之声自明，不暗示。它在其他声用手势处用数字、重量、价格。Tobiah 尤其：一个说不清笑点便解释笑点的人，其文书因此爱他。

**衣**：商人上衣，柔色 —— 赭、土、灰 —— 宽裁。颈一条商人链，每宣一次诚之衡加一扣。Tobiah 戴十二扣 —— 极多；多数 Union 人戴三四扣。靴佳但不擦亮。发短但非南短。须修。

**食**：Union 人共食同饮，并记账。Union 主人会在饭末当宾客面算食费 —— 非以之收款，而以*示*宾客礼之所值。视为最高之诚。Faith 人觉其扰。Crown 人觉其俗。Free North 人觉其惑。Union 人觉那是唯一理智的吃法。

**誓之形**：誓书写、签署、见证、归档。立誓者不触己身不触门阈；签一文件，文件即誓。备副本。副本存于不同建筑，以防火灾。破誓经 Union 的 arbitration 追究 —— 是账院，非斗院 —— 罚为 *erasure of the oath-breaker's clasp*（破誓者之扣之抹除），商人链于坏扣处被切开，扣投入 Shale。无扣之破誓者不得在 Union 市场贸易。

**在峰会**：Tobiah 袖内有蜡板。不自知地，他准备做笔记。

## The Colonial Shadow / 殖民阴影

写手团参考页。此处任何内容不在玩家可见文本出现。

四冠皆出自一位殖民行政官的血脉，在联络中断后第三代分为四支。第一代 —— 殖民者本身 —— 设一常设仲裁会名 Four-Knot。百年前沉默降临时，该会成为四后继政体间的条约机构；再两代后，成为今日 Guild 的掩盖之器（A↔C）。峰会室中砌死之第五门，是曾通往殖民者本部档案的那扇门。今日 Reach 无人知门后有何。四冠中三位在继位之日由前任受命 *do not open the fifth door.* 无一被告知为何。

Darrik 知此命并守之。Brenna 知此命并守之，虽然她在任内曾两度站在该门前把耳贴在粘土上。Malen 从未被告知此命 —— Faith 之职以书面登记传承，Septa 登记簿相应页在前任时毁于一火。Tobiah 从未见过第五门，因 Union 从未坐过峰会。Ashen Herald 穿过第五门。她正是这样来去的。

琥珀茶：在彼岸的水培栽培罐中种植，于沉默前最后几批补给船队中运过来。Ashcrown 的储备延续四代，因为此茶按正法泡制延寿，并 —— Darrik 未被告知之细节 —— 延其血脉之*育力*。Voss 一脉四代薄，因之。Darrik 是最后一位男 Voss。他不知叔伯为何无嗣。

浅嵌金属：彼岸高塔的结构合金。Greyhold 的族匠两代前学到：此金属不可锻但可冷嵌。纹之纪（直线，永不打结）非美学 —— 是最早那位族匠之母从一位殖民工程师处学到的纹：直线因合金愿如此敷。

远语之石：成对的通讯器。Malen 的石与一枚至今坐在彼岸一间封缄室里的石配对。她所闻之声非神之弃绝。是 Chasm 对岸一位女子，九十七年来试图联络某人。女子仍在世。茶让她仍在世。Malen 一概不知。女子知。

Tobiah 所购之黄铜杯：殖民行政下属官员食堂之饮器。十二件。Tobiah Stoneford 仓中尚有九件；三件在 Mistmere，其一今日就在桌上他手里。

四结印：殖民议事会之纹。空心处原压第五纹——殖民主权本身。联络中断后，继政体继续使用此印，中心留空。空心在字面上、在被遗忘的意义上，就是四冠所坐之物之形。

**峰会场景 —— 退场**

> Herald 在板上写下最后一行。她把板转过去。行读：
>
> *Three of you know. The fourth has just learned that he does not. I have done what I came to do.*
>
> 她走向北墙。在砌死之门前停。掌扁压在四结粘土上。粘土不开。不动。但 Herald 的手*穿过*粘土，直至腕、至肘；然后她迈步，身随手入。
>
> 四冠看她去。Malen 的石低语了什么。Brenna 的刀出鞘，裸露地放在身前桌上。Darrik 的面，整场会议中第一次，变了：一次短锐之吸气，颚收。Tobiah 已颇白。
>
> 室又静。
>
> Darrik 先语。*"The sitting is ended. The crowns will retire."*（坐已散。王冠将退。）
>
> Malen 未答。她在看那扇砌死之门。
>
> Brenna 收刀。立。对无人说：*"The Free North rides at first light."*（Free North 拂晓上马。）
>
> Tobiah 仍握黄铜杯。极小心地放下。看三冠。轻声说：*"I will think on my house's oath overnight, Your Graces. Your Holiness. Chieftess. I will bring my answer at dawn."*（我将通宵思量我家之誓，诸殿下、圣下、Chieftess。拂晓我将带我之答来。）
>
> Darrik 点头一次。非同意。是承认。
>
> 四冠从各自的四门离去。玩家若在场，被留在室中，与四杯、砌死之门、及 Herald 所立之处的板粉尘同在。

## Stage endpoints

- **Sprout end（T001）：** 玩家持 Herald 之信。知有峰会将至。知四冠中三冠在藏什么，第四冠被引向一张他不懂的桌。尚不知所藏为何。
- **Involvement end（T002–T004）：** 玩家见过 Ylva（Free North 之声）、读过 Septa 之拒（Faith 之声）、尝过 Alric 之茶（Crown 之声）、数过 Tobiah 的十二杯（Union 之声）。听过 Brenna 低语的一句 —— *we came from the other side* —— 或懂或不懂。知 Guild 的四结比王冠更老。知 Septa 之印与 Herald 之印同印。
- **Critical decision at T005：** 玩家在峰会时选五椅之一。此选在本周目不可逆。它决定 A/B/D/E 线之 critical 何者由此更易、何者更难。

## Endpoints in detail / 结局详述

### 结局 1 —— Crown 路径

玩家替 Darrik 发言。致辞于拂晓、大教堂前庭、Tobiah 于四冠之间站于阶上。玩家可以 Crown 之调论证：Union 的诚实之言最好在其所被请守护之物上验、而非在其所被告知之物上验。若致辞落（社交 DC 18，或 DC 15 若玩家已在 T004 赢得 Alric 之观感），Tobiah 立誓。他签一份 Crown 颁的文件。他上缴十二杯。作为交换，他得到一枚拇戒 —— Ashcrown 史上第一枚 Union 拇戒。

十二杯在 Crown 封缄箱中南运。三月后 Darrik 将亲至 T001 无论玩家在何处探望玩家。他将带一锡封琥珀茶为谢。他将说：*"You have stood for the Crown. The Crown remembers who stands for it. The Crown also remembers who stands only once."*（你曾为王冠而立。王冠记得谁为其立。王冠也记得谁只立一次。）锡是债，亦是警。

下游后果：A 线 buried charter 更难达（Crown 收紧 Guild 监督）。B 线 Eilin 被移至近处监视（Crown 今有正式理由监视修道院）。D 线直线云下月见二次；Crown 的回应 —— 逮捕证人 —— 成为跨线摩擦。E 线 Crossers 加速：他们正确地算出：Crown 的掌紧，跨越之窗在收窄。

### 结局 2 —— Faith 路径

玩家替 Malen 发言。于大教堂内，于 Pattern 第七时，在无刻之坛石前。须以 Faith 之调 —— 经文节奏、古变位、无缩读 —— 论证 Pattern 之静非弃，乃试。若致辞落（DC 19，或 DC 16 若玩家已自 T004 取回 Silas 的遗书并向 Malen 出示其中一段为兆），Malen 哭。九年来她第一次哭。

那一夜，Malen 睡。六小时，无梦，此生最深之睡。

翌日拂晓，直线云现于 Mistmere 之上。Malen 醒，先闻而后见 —— 她喉前灰石已以女声清楚说话，一字一字，一问。Malen 不懂此语。此后她余生再不睡。

下游后果：D 线直接自此节拍打开（云、石、声）。B 线 Eilin 可经 Faith 而达 —— 被动摇的 Malen 开始问她的前任拒问之问题，修道院被令*拆砌*某些档案。A 线 buried charter 更易达，Faith 对 Guild 的监督松。玩家被列入 Malen 的私账作 *named servant of the Pattern*（Pattern 之受命仆）—— 此名六十年未授，其所带义务不在事先告知之列。

### 结局 3 —— Free North 路径

玩家替 Brenna 发言。致辞不公开发出 —— Free North 之俗不许。代之以玩家站在 Brenna 右肩之后出席拂晓集会，Brenna 发言，玩家的在场即是陈述。

Brenna 的致辞一句：*"The Free North will not ask the Consul-Merchant to take an oath the Free North itself has not sworn."*（Free North 不会请 Consul-Merchant 立 Free North 自身亦未立之誓。）

其余三冠懂。Tobiah 被允拒。峰会无缚而散。三冠怒归；Brenna 凝重而归。

不出一季，Tobiah 的商人们 —— 未缚、未噤、如今主动好奇 —— 开始问关于黄铜杯的问题。不出二季，Stoneford 一位 Union 文书已把杯与彼岸船队之箱单连起。不出一年，Union 已有一个工作假设。错于二处、对于第三 —— 而第三处是唯一要紧处：*these cups were not made here.*（此杯非此地所制。）

下游后果：A 线 Guild 受 Union 压力被迫开放有限 charter 档案；buried charter 在 Union 赞助下可达。E 线 Crossers 在 Union 找到意外同盟 —— 非因 Union 赞同，而因 Union 要一份 Chasm 两岸更完整的清单。D 线 Old Shepherd Bram 愿向 Union 作证，而不愿向任何王冠。Brenna 自身成为玩家的定期通信人，每季一封，笔迹玩家学会辨认。

### 结局 4 —— Union 路径

玩家作 Tobiah 的诚实之副发言。致辞短、北方、具体：*"My master's house will not take an oath whose weight has not been shown. My master's house will not sign a document whose terms have not been read. My master's house respectfully withdraws from this sitting."*（吾主之家不立未示其衡之誓。不签未读其条之文。吾主之家恭请退出此坐。）

Tobiah 在他的副身旁走出大教堂前庭。三冠独立。

此为五结局中最具动摇力者。四冠之框两百年未曾坐过三椅。没有 Union 的诚实-见证功能，四结之誓的仪式封缄不能闭合。Faith 尤其：没有四杯皆被饮过，无法封缄一坐 —— Tobiah 的杯此刻空了，弃在大教堂下一桌上，未封。

下游后果：A 线仲裁机构重启，Union 的退出重启了 Four-Knot 前-Guild 功能。B 线 Eilin 成为 Union 想访问的*证人*。D 线云目击开始由 Union 文书登簿；任何机构对该现象的第一份系统记录。E 线 Listeners 失去大部分王家资助（Crown 心无暇旁骛）；Crossers 得喘息。玩家入 Tobiah 账册为 *Union-bonded friend*（Union 结友） —— 一个带扣之阶，Tobiah 链上第十三扣。

### 结局 5 —— Fog 路径（第五椅）

玩家不语。玩家随 Ashen Herald 穿北墙砌死之门而去。大教堂卫兵后来都发誓无人经过。玩家不会被记入次日拂晓集会。Tobiah 会接受三冠压于他之任一誓 —— 因为室内无第五声。

玩家再现 —— 一日后、一周后、一月后，时不定 —— 于 Mistmere 港，黄昏，手中一副未上釉之陶面具。面具合。面具归玩家。Herald 去。

下游后果：玩家现已在四王国之框外。Guild 追之（A 线：违反 Northern Ban）。Faith 宣其 *Pattern-未名*（B 线：只能以异端之径达）。Crown 发一道暗令（无公示，但王家爪牙会认出玩家）。Free North 不追，但不庇。Union 谨慎贸易。Crossers（E 线）公开欢迎 —— 因为一位戴面具、无名、无国之人正是 Crossers 所需。D 线 Veyl "the Line" 于 T005 见玩家时认其为*亲*，轻声说：*"So there are two of us now."*（如今我们是两人了。）

此结局是唯一一个在后续场景中开启与 Ashen Herald 直接对话的结局。Herald 在玩家面前唯一一次卸下面具时，经典之身份是 **Brenna 的官方不存在的姐姐** —— 一位 Greyhold 部族三十年来无记录的女子，chieftess 不说其名。此与 Brenna 承载的殖民记忆（她不能与族人共享）一致。Jenn 为 Brenna 的外甥女（信使，非 Herald）。

## Cross-line interactions

- **A ↔ C：** 四结是 Guild 原初的仲裁之印。Herald 以之写信；Septa 以之盖刮除令；Mira Ashford 厨中旧盘亦有之。Guild 既是掩盖之器（A 之核心），也是唯一一个其印仍在四冠桌上有效的机构。A 线 critical —— buried charter —— 是四结机构的*创建文件*；读之，玩家知仲裁机构是第一代殖民者所设之常议，王国是继承。
- **C ↔ E：** C 线 critical 结局 2（Faith 路径）与结局 3（Free North 路径）皆直通 E 线。Darrik 与 Brenna 是两位悄然联签压制 Depth-Walkers（尤其 Crossers）的王冠。Navigator Kestrel 的草图 *from below, we may rise*（残片，T004 图书馆，按 SHARED_BRIEF）本身即一张从*下方*绕过四门到达四结之室的路线图。E 线玩家若见 Sula 或 Kestrel，将知 Crown 与 Free North 联合支付 Listener 契约（Sula）以制 Crossers。
- **C ↔ D：** Tobiah 所购黄铜杯与 T002 Durm 的不可击打金属块（T002 残片）属同一彼岸冶金之遗物。触发 D 的直线云（T002 天象）若玩家选结局 2（Faith），次晨再现于 Mistmere 之上；Malen 的石与云属同一*族*之造物。Old Shepherd Bram 之父（D 副灵魂之父）年轻时在老族长与老王之间递冬信；Bram 若被问，只说一句：*"My father rode in winter for them. He learned his letters from the same woman they learned theirs from. He did not speak of it."*
- **C ↔ B：** Preceptor Vossel the Younger（B 副灵魂，T002）行旅间与修道院保持安静通信；C 线不主张其血统。Eilin of the Broken Tongue（B 灵魂）被噤，不仅因其地图，也因她曾在修道院一墙上画出原初四结的*未砌*之形 —— 五点，非四点。Septa 自己的骑者以她不懂的四结印签署的刮除令刮除之。

## Four voices, side by side / 四声对勘

一份简要参考，给将写 NPC 评论*他国*的写手。四声在彼此评论时应一致。

**Crown 论 Faith：** *"Her Holiness keeps the Pattern. The Pattern keeps her. The Crown does not intrude upon that arrangement."*（敬、远、略俯视。）

**Crown 论 Free North：** *"The Chieftess is — direct. The Crown values directness, at its appropriate distance."*（警惕、略冷。）

**Crown 论 Union：** *"Honest weights. Honest words. A useful house, and the Crown is pleased by useful houses."*（居高、友善。）

**Faith 论 Crown：** *"His Grace is a body, and the body walks within the Pattern. The Faith watches the body walk."*（仪式化、有耐。）

**Faith 论 Free North：** *"The clans do not sit within the Pattern. The Faith does not yet know whether the Pattern sits within the clans. The question is open."*（不定、慎。）

**Faith 论 Union：** *"The Consul-Merchant keeps honest weights. Honest weights are a Pattern, after their fashion. The Faith recognises the Pattern where it finds it."*（慷慨、意外；Malen 其实喜欢 Union。）

**Free North 论 Crown：** *"The southern king drinks from a cup that was poured for him. We pour our own."*（平、描述。）

**Free North 论 Faith：** *"The grey-robe talks to doorways. The doorways do not answer. The grey-robe keeps talking."*（具体、略不屑。）

**Free North 论 Union：** *"The weigh-folk. They weigh everything. They would weigh a child if you let them. They do not mean harm by it."*（略有趣、不敌。）

**Union 论 Crown：** *"His Grace is — a valued customer. We would extend him a line of credit if he asked. He has not asked."*（专业、略困惑于 Crown 之礼。）

**Union 论 Faith：** *"The Faith keeps good records. We respect good records."*（诚挚、专业。）

**Union 论 Free North：** *"The Chieftess pays in silver and her word is good. Her ale is better than her silver."*（温、具体。）

**Ashen Herald 论四者：** *"Four rooms with four doors, and one wall between them they have all agreed not to see."*（写于板，峰会上给 Tobiah 看。）

## 最后一幅图

给写手带走的最后一幅。

峰会室已空。四杯仍在桌上 —— 琥珀茶在黄铜滤杯里已冷；石水未动；骨杯之族啤（族长未饮大教堂备杯）；诚实之人未被告知之黄铜杯中半杯酒。四门已关。第五门砌死，其上之四结粘土，借室中低烛光，是室中唯一一个有要紧之形的东西。

一道板粉尘在地砖上，Herald 所立之处。

无人在场看它。

## Gaps needing sibling input

C 线有三处开放接点，须邻线写手在发布前锁定共享细节：

- **A↔C —— buried charter 文字。** 创建文件的精确措辞由 Writer-α（A 线）拟。C 线需该文件包含 *four seats and a fifth* 或等义 —— 某处对殖民第五主权的显性指涉 —— 使读过 charter 的玩家在峰会上认出砌死之门为何。Writer-α 确认语言。
- **B↔C —— Preceptor Vossel the Younger 血统。** 已解：C 线不主张 Vossel 的血统。Vossel 的刻画完全归 B 线所有。
- **D↔C —— Old Shepherd Bram 的送信过往。** 已解：Bram 之*父*送冬信，非 Bram。Bram 就此事之唯一一句台词固定为：*"My father rode in winter for them. He learned his letters from the same woman they learned theirs from. He did not speak of it."*

已解：**Ashen Herald 卸面具之身份**（仅结局 5）为 Brenna 的官方不存在的姐姐。Jenn 为 Brenna 的外甥女，低阶信使，非 Herald。

## 结语

C 线在五条 Reach 主线中最关"拒"。每位灵魂 NPC 在其枢纽时刻都在拒些什么：Darrik 拒说殖民者之名；Malen 拒读 Silas 的遗书；Brenna 拒告族人；Tobiah 拒盲目立誓；Herald 拒王冠本身。此线之戏剧即五拒叠于一桌之戏剧。玩家的 critical 决定是：他们愿立于哪一拒 —— 或哪一人 —— 之后。

写手之务是让每一拒都带其身后王国之全重落下。无王国之身后之拒是噘嘴。有王国之身后之拒是王冠之行。本文件每一枢纽台词，在潜文本里都是一次王冠之行 —— 故三层注释要紧，四种材料签名要紧，四结在峰会到来之前必须在 Reach 出现六次。

## The Ashen Herald —— 写手档

Ashen Herald 为 C 线副灵魂、A 与 D 线之对话者。此档仅供写手；任何内容不在玩家可见文本出现。

**外观。** 高，在人身常范之内。粗灰羊毛斗篷带风帽。面具未上釉之陶 —— 灰棕，多孔，可见烧制而未釉。眼孔为空切，非玻璃之后。面具之口为单一横切。以皮绳系于脑后；Herald 转身时可见。面具非整片 —— 是两片，于眉处以烧制粘土缝相接。两片为何，留给后续写手决定。

**声。** 口说时，声音既非清楚为女，亦非清楚为男。她更爱在板上书。板为灰、小、白粉握之。她以掌跟抹之，留一道灰痕。

**动。** Herald 行走。不滑翔、不悬浮、不在叙事中瞬现瞬隐。她似乎穿越封缄之门的幻象，实际源于她使用第五门 —— 峰会室之砌死门，及 Reach 各处其同类之门。每一重要城镇至少有一扇此门。写手应在 T001–T005 各安一扇（位置由写手自定），不作评注。

**知。** Herald 曾经第五门。她至少知：四王国皆殖民者后裔；四结为殖民议事之印；琥珀茶、浅金属、远语之石、黄铜杯皆彼岸之造物；Malen 在灰石中所闻之女仍活在彼岸。她**不**知 —— 给写手之标 —— 一百年前彼岸发生了什么，或沉默为何开始。

**动机。** Herald 以原则拒四冠。她相信四冠之框是建于一门之上的牢笼，此笼必破。她不信彼岸应被联络；她信*笼*应被揭露，以使砌死门后之物能被看作其所是。她不是 Crossers（E 线）之盟 —— Crossers 要到达彼岸，Herald 不要。她在一个要紧的意义上是一*五国之一者*：Fog 一路，反-合法性，反-归来。

**与 Jenn 的关系。** Herald 未雇 Jenn。Jenn 独自偷了密码册，并写给任何她以为会听之人。Herald 之信经两手人到 Jenn 手中 —— 一位 Windrest 文书与一位 Stoneford 盐鱼买家 —— 二者皆不知在传什么。Herald 写信之意是把峰会*浮于 Union 自身*之前，假设若 Union 被警告则不会出席。Jenn 把信交玩家而非 Union，是 Jenn 自己的决定。

**卸面具。** 结局 5（Fog 路径），Herald 在玩家面前于一处（由写手选）卸下面具一次。卸面具是一场戏，不重演。卸面具后她戴回并继续戴。在 Reach 之后续幕中，玩家是唯一见过她脸的角色。经典身份：**Brenna 的官方不存在的姐姐**。

## Final notes for the orchestrator

C 线设计为五结局皆可存活。任一结局非游戏结束。每结局转向 A、B、D、E 之流，并改变 Reach 后续各幕之*调* —— Crown-路径 玩法更紧，Faith-路径 更梦，Free North-路径 更缓更偏书信，Union-路径 多记录且偏调查，Fog-路径 更奇更不可读。orchestrator 应在 T005 首幕收尾时标记所选结局，并作为持久世界状态变量向前承载。

玩家从不必*理解*殖民历史来完成 C 线。此线设计成：几乎什么也不懂的玩家 —— 只在码头帮了一个女孩、携了一封信、在峰会静坐 —— 仍能有意义地选择五结局之一。此线奖励深度游玩以分层理解，但不以之为通关门槛。

四种材料签名 —— 琥珀茶、浅金属、灰石、黄铜杯 —— 是此线承重之象。任一被后续写手因美学原因删去，此线失一王国之声。写手被请视此四者为不可协商。

四结印是此线之视觉签名。六次出现中任一被删，玩家在峰会上或认不出，峰会室之细节落不下来。写手被请视六次出现为不可协商。

最后，三层注释 —— *// public= / feared= / private=* —— 是此文件最要紧的工艺工具。它是每位王家在每一枢纽台词中同时承载 2+5+6 动机栈的方法。写手把线改到新场景时，必须保留三层结构，即便台词本身变化。一句台词若被编辑而注释未存活，此台词已损。

## Timeline —— 自 hook 至 critical

这是 world-agent 应让 C 线遵守的世界内历法。日期以 Reach 本地历记；每 *moon* 约为二十八日。

**hook 前一月 —— Herald 写信。** 在 T004 与 T005 之间某处，在 Herald 不愿命名之室中，她草拟玩家日后将携之信。她写两稿；第一稿焚之。第二稿以四结封之。交一位她已忘其名之信差。

**hook 前三周 —— 信差被注意。** Consul-Merchant 在 Mistmere 的文书们察觉其一本密码册失。负责之文书被无偿辞退。她带走密码册，因为他们未付她尾期之银。她名 Jenn。

**hook 前二周 —— Brenna 收召。** 一位 Crown 骑至 Greyhold 厅交一封封缄信。Brenna 独自读之。焚之。令 Ylva 备六骑走长路。她不告族。Ylva 问为何；Brenna 说 *因为王冠要一把椅，而一把椅得被坐*。

**hook 前二周 —— Malen 最糟之夜。** 灰石说四词。她一词不懂。她彻夜将 Pattern 念入门框。她不眠。

**hook 前十日 —— Darrik 独饮。** 他坐 Ashcrown 的夏园。拇戒脱下；他在指间转。他在想 Tobiah Caul —— 他未曾见过。

**hook 前七日 —— hook。** Jenn 在 Stoneford 码头被追。玩家介入。（见 T001。）

**hook 后五日 —— Ylva 过 Windrest。** 六骑，停战旗，直线嵌甲。Yura 迎。（见 T002。）

**hook 后八日 —— Alric 在 Jade Lantern 饮第一杯茶。** Jade 注意到。（见 T004。）

**hook 后十二日 —— Septa 拒 Silas 之信。** Silas 当日收回信。Sara 在他身旁。（见 T003。）

**hook 后十四日 —— Brenna 抵 Mistmere 城外，营于墙外。** 除峰会之晨外，她不入城。Crown 视其为失礼。Brenna 视其为对族人的礼：他们不愿其族长在 Faith 墙内滞留过久。

**hook 后十五日 —— Tobiah 抵 Mistmere。** 他住商人区最佳旅馆。可见其悦。他致信妻子，言他受邀*至一王冠之桌，此事我祖父不敢相信*。

**hook 后十六日 —— Darrik 抵 Mistmere。** 住大教堂，受 Malen 之邀。当晚二人同餐。无关紧要之言。Darrik 注意到 Malen 之石自喉移至右手。Malen 注意到 Darrik 所饮之杯她从未见过。二人皆不提所注意。

**hook 后十七日 —— 新月。峰会。**

**hook 后十八日 —— 拂晓集会。** 五结局。其一被取。

## Town-by-town scene script reference / 逐城场景剧本参考

### T001 —— hook 展开

hook 属 Jenn。码头追逐是焦点场景。T001 写手应守以下节拍：

1. 玩家在港口以合理名义（任何名义）。
2. 盐鱼码头骚动：两名灰毛之人，一位流血女孩。
3. 玩家选择介入、无视、或远距跟随。
4. 若介入：二人见抵抗即止。他们不是杀手。
5. Jenn 被逼角，取信。不朗读。压入最近一只诚实之手。
6. 若无视：女孩退入仓栈，三日后被发现死在小巷，信仍在靴中。信以另一径到玩家手 —— Mira Ashford 扫客栈后门时找到。
7. 若远距跟随：追逐止于 Caul & Sons 仓栈；Jenn 藏入一只箱中 —— 这是 Herald 未计划的巧合：箱中正是十二黄铜杯之一。

信必须在三径之下都到玩家手。信即触发。

### T001 —— Heron 之暗示，场景

> Heron Blackwater 在 Guild 后室独处。玩家带印入室时，他未即抬头。写完手中那一行。放笔。然后才转头。
>
> "Show me."
>
> 玩家把信放桌上。Heron 看其良久。不触。
>
> "Close the door."
>
> 玩家关门。
>
> "Do you know what this is, traveller?"
>
> "A seal."
>
> "It is the seal of a body that is older than the Guild. It is the body the Guild was made to serve, and then made to replace, and then made to hide. Do you understand me?"（那是一家比 Guild 更老的机构之印。是 Guild 被造来服侍、后被造来取代、再后被造来藏匿之机构。你懂我吗？）
>
> "No."
>
> "Good. Keep not understanding. Keep it in a pocket that is not yours. Give it to the person it is addressed to, if you can. If you cannot — burn it. Do not read it. Do not have it copied. Do not ask me about it again."（好。保持不懂。放进一个不是你的口袋。若能，把它交给它所致之人。若不能 —— 焚之。不读。不抄。不再问我。）
>
> Heron 拾笔。回那一行。话至此止。
>
> *// public=Guild 主之慎, feared=四结回流，掩盖正被挑战, private=他曾在祖父葬礼上见过此印一次，祖父留一封以此印盖缄、从未开启之信于一锁抽屉里*

### T002 —— 马厩展开

Yura/Ylva 马厩场景（如上）为焦点场景。此外 T002 写手应设：

- Windrest 两位马厩工之间的一段环境对话，玩家偶闻：*"The envoy's horse doesn't sweat." "Don't say doesn't — say didn't. I rubbed her down and she was dry as bread. Three days' ride." "You're imagining things." "I rubbed her down, boy. I know a dry horse."*（"使节的马不流汗。""别说不流 —— 说没流。我给它擦身，干如面包。三日骑程。""你在想象。""我给它擦过，小子。我认得一匹干马。"）
- 一夜之内，Ylva 独在客寝，自腰袋取一小灰石，贴耳，听，然后收起。玩家若在门外潜行（Stealth DC 19）可见此石。Ylva 此后在玩家面前不再用。她也不知此为何物 —— 以为族之遗物。Brenna 未告她。
- 拒答场景：玩家若直接问 Ylva *我们来自彼岸*，Ylva 会全然静止，然后平板说：*"I do not know what you are talking about. I did not say those words. You did not hear them."* 她在 T002 此后不再与玩家语。

### T003 —— Septa 之触角展开

Malen 不亲临 T003，但她的*分量*须在。T003 写手应设：

- Wolfsjaw 卫戍中，Septa 的两位骑者访问每一位过去一年曾下地之士兵。访问正式、书面；每士兵问同三问：*Have you heard voices in stone? Have you seen a cloud that is a line? Have you been below ground without a Faith-witness?* 多数士兵三问皆答否。两人第一问答是。此二人一周内失踪。Mark（NPC_T003_03）知此事。他会悄悄告诉玩家一次，此后拒再言。
- Archivist Naryn 柜中一只封缄木箱，盖四结印。内：Northern Ban 诏令的副本，每份皆被以相同方式半焚。焚为 Faith 的标准删节。未焚之半 —— 每份中 —— 或*下半*、或*上半*存活。跨三份拼合，可还原全文。还原为一专项支任。全文点名 Depth-Walkers 为压制目标、点名四结为封缄机构 —— 以一文件确证 C↔E 与 A↔C。
- Sara 在 Wolfsjaw 的战地医帐，医疗物资之间有一只三年前 Faith 留下的包裹未曾取回。Sara 从未开过。若玩家开之（Sara 不开），里面是一包陈而仍微香之琥珀茶叶。Grandmother Green 可辨（T004 交叉）。包原本给 Malen。从未到她手。她三年来存量渐薄，不知储备去了哪里。

### T004 —— Jadehollow 展开

Alric 在 Jade Lantern 的在场为焦点场景。此外 T004 写手应设：

- 与 **Kassa Deepvein** 的一次旁遇。若玩家已在任何 T004 任务中赢得她的专业敬重，Kassa 会在私下对谈中说：*"The envoy wants the cup-inventory. He is going to get it. I am telling you this because I am going to give him accurate numbers, and you are going to know — if anyone ever asks — that I did not lie."* *// public=专业透明, feared=Crown 审计将揭露 Deepvein 四层对 Union 的出货, private=Kassa 未对自己全然承认地决定：Consortium 之保密不再值得捍卫。*
- 图书馆深藏区一场景。Crosser 草图 *from below, we may rise* 归档于两卷合法采矿图示之间。一位图书管理员 —— NEW NPC **Clerk Ostric**，瘦，中年，不显眼 —— 在归架。他见玩家抽出草图。不语。归完。离去。当晚，一位 Crosser 联络在 Jade Lantern 找到玩家，无自我介绍地请其饮一杯。*（引出 E 线。）*
- Grandmother Green 小屋一场景。若玩家把不老茶渣带给她，她会以渣二次浸出一壶淡茶相奉。玩家可饮或拒。若饮，无感 —— 此茶之效需多年日饮。Grandmother Green 看着自己杯中说：*"My mother drank a tea this colour, once, when she was a girl. She lived a hundred and nine years. She said at the end she could not remember her own mother's face, but she remembered the colour of the cup. Do you want your long life to taste of this, traveller?"*（我母亲少女时喝过一次这种颜色的茶。她活到一百零九。她到末了说，她记不起她自己母亲的脸，却记得杯的颜色。你愿你的长寿尝起来是这样吗，旅人？）

### T005 —— 峰会前夕

峰会本身为焦点场景。此外 T005 写手应设：

- 与 Tobiah 在商人区客栈的偶遇。他快活，微醺，乐与人同席。他会告诉玩家：*"I have never been to a crowns' table. My grandfather was a salt-fish seller. He would not have believed this, traveller. He would not have believed it. I am going to sit at a table with a King-Apparent and a Chieftess and a Septa. What do you say to a Septa, traveller? Is it *Your Holiness* or *Most Holy* or what? My wife will want to know."* 他未佩械。独自。不知身处险境。玩家可警告、误导、同饮或不言。若此处警告，将实质影响峰会：Tobiah 会更警、更慎，更不易一见即饮黄铜杯。
- 与 Brenna 在城外营地之偶遇。她不允访客，但 Ylva —— 若玩家已在 T002 赢得其信任 —— 允短见。Brenna 问一问：*"Traveller. Have you been in the port at Stoneford recently?"* 若是：*"Did you see a girl called Jenn?"* 若是：*"Is she well?"* Brenna 对 Jenn 的兴趣本线未解；标为跨写手考量。（一写手团候选：Jenn 为 Brenna 外甥女，南下为看 Herald 的通信。本处未钦定。）
- 与 Darrik 之偶遇，若玩家被 Alric 引荐。Darrik 在大教堂宾寝一小室受玩家。会面短。Darrik 长盯玩家之面而后开口。说：*"You carry something of the Herald in you, traveller. I do not know what. I do not know if you know. I am telling you because I want you to know that I have noticed. The Crown notices."* *// public=王家之礼, feared=此玩家某处曾与 Herald 同室，而王家爪牙未辨其地, private=他在以唯一不越宫礼之法请玩家自报身份。*
- 与 Malen 之偶遇，若玩家已取得 Silas 的遗书并携之近大教堂。Malen 不官式受。一位侍女将其自窄阶下至一祷室。Malen 独在其间，披灰袍，灰石贴耳。长久不语。然后，未放下石：*"What have you brought me, traveller?"* 玩家出示单页。Malen 读。面无变。说：*"Leave the page. Do not bring me the rest. I cannot read the rest and remain the Faith. Go."* *// public=牧者之拒, feared=遗书若读将摧毁其职, private=她在请求被饶；她在请而非令；而一位请而非令的 Septa 是一位正处 Pattern 边缘的 Septa。*

## Style guide（仅 C 线）

- **无现代词汇。** 永不用 *colonist*、*continent*、*artefact*（用 *relic* 或 *thing*）、*alloy*、*concrete*、*metal-that-does-not-hammer*（用 *un-hammerable metal*）、*cryogenic*、*reactor*、*radio*、*signal*、*transmission*、*communications* 或任何显性技术语域。唯一许可的技术语域是商人会计 —— *weight, clasp, tally, ledger* —— 因为 Union 的声音允此精度。
- **无现代心理语域。** 无 *trauma*、*dissociation*、*repression*、*internalised*。角色可为 *haunted*、*unsleeping*、*quiet*、*not himself*、*thin in the face*。
- **殖民历史永不口说。** 唯一例外为 Brenna 之 *we came from the other side*，以族语对 Ylva 独言一次。他角色不得说。后续幕之写手**不可**再加二次、三次。
- **三层注释**（*// public= / feared= / private=*）是写手专用工具。永不在玩家可见对话、任务文本、物品描述中出现。为城镇写手之连续性工具，须随每位灵魂 NPC 的每一枢纽台词同行。
- **四结印**在此线视觉出现六次（盘、信、修道院刮除令、仪封、砌死之门、创立宪章）。其中至少三次必须是游戏内图像或描述性的图碎，非仅文本。玩家应先学会辨识此印，再学知其意。
- **琥珀茶、浅金属、灰石、黄铜杯。** 四王国四材料签名。每位灵魂 NPC 须在其首次亲临场景中被*见*到在触、持、饮、戴、或拒其材料签名。

## Glossary for writers

- **Ashcrown：** Crown 王国，四国最南，都 Mistmere（与 Faith 分治）。
- **Faith / Septon Order of the Pattern：** Faith 之机构，设于 Mistmere Grand Cathedral。
- **Free North / Greyhold 部族：** Brokenspine 以北部族松散联盟，总部 Greyhold Hall（Reach 诸幕未至；凭声名可知）。
- **Union / Caul & Sons, the Honest-Weight Guild：** 商人政体，总部 Caul-town（亦未至），分部于 Stoneford、Windrest、Jadehollow、Mistmere。
- **Four-Knot：**（1）早于四王国的仲裁机构；（2）同机构的仪式之印，四环围空心；（3）Faith 用以封缄四冠峰会之仪誓。
- **The Pattern：** Faith 的宇宙论。世之正序，由 Septon Order 读之。门、阈、框为其可见之签。Faith 之誓入门框。
- **Honest Weight, Honest Word：** Union 之家训。用作问候、祝福、结语 —— 在峰会上亦被 Ashen Herald 用作修辞之陷。
- **Clan-ale：** Free North 之仪饮。以饮者自携之骨杯饮。到峰会不带骨杯之 Free North 代表即拒峰会之待客。
- **Amber tea：** Crown 之私用兴奋剂，外人以为南地奢品。Crown 以为圣事。实为遗物配制。
- **Distant-voice stone：** *写手所用之名*。Faith 称 *grey stone of the Pattern*。Crown 称 *silent cup*。Free North 称 *listen-stone*。Union 尚未命名。
- **The Herald：** 首引永为 *the Ashen Herald*，其后为 *the Herald*。叙述中永非 *she*，除非贴身 POV。面具永为 *un-glazed clay*。
- **The fifth door：** 峰会室之砌死之门。在玩家可见文本中永不名为 *the fifth door*；称 *the north wall* 或 *the bricked door*。*the fifth door* 为写手之名。

## Write-in checklist for town writers

- **T001/npcs.json：** 加 NEW NPC **Jenn**（信使，平民，在 hook 中受伤；救下后成为港口低阶反复联络人）。给 **Heron Blackwater**（NPC001）加对话分支：被出示四结印时，Heron 悄声道 Guild 曾答那枚结、后来答银子。给 **Mira Ashford**（NPC003）加对话分支：葬礼之盘之认出。给 **Old Reed**（NPC002）加环境台词，劝玩家把印放到别人的口袋里。
- **T001/facilities.json（或等价场景文件）：** 加码头追逐场景。加 Caul & Sons 盐鱼箱戳印 *HONEST WEIGHT, HONEST WORD*。加 Tobiah Caul 在海关棚之短客串（T001 版 Tobiah，短；T005 版为灵魂）。
- **T002/npcs.json：** 加 NEW NPC **Ylva Stoneshield**，Chieftess Brenna 的使节。标为既有 NPC_T002_01 Yura Stoneshield 的表亲。给 **Yura**（NPC_T002_01）加马厩场景对话分支。给 **Mei**（NPC_T002_03）加"不可能之未疲之马"的传言。给 **Brown**（NPC_T002_04）加一句，关于被 Ylva 叫作 *contract-folk*。
- **T002/npcs.json（Old Zhao）：** 加 50 金解 Herald 密信之服务。加 Zhao 对"四结比 Guild 更老"的旁白。
- **T003/facilities.json：** 确认修道院后墙字符 上下相通（B 线残片）在场，并标 Septa 已令以其四结印刮除之。在 Archivist Naryn 柜中加一瞥该刮除令，毗邻半焚 Northern Ban 诏令。
- **T003/npcs.json：** 给 **Sara**（NPC_T003_02）加对话分支，关于 Septa 的远语之石。给 **Linden**（NPC_T003_01）加分支：*"峰会是为一扇门"* 及"骑者逮朝圣下地人"的台词。给 **Mark**（NPC_T003_03）加一句关于 Septa 的骑者问"石头里的声音"的传言。
- **T004/npcs.json：** 加 NEW NPC **Envoy Alric of House Voss**（Crown 使节）。给 **Kassa Deepvein**（NPC_T004_01）加王家审计场景对话分支。给 **Jade**（NPC_T004_04）加分支：观察 Alric 之茶礼；出售／遗失不老茶渣。给 **Grandmother Green**（NPC_T004_05）加分支：辨渣为 *not grown but made*。给 **Old Fane Crowseye**（NPC_T004_03）加一句：他灰眼把 Alric 的锡读作比 Ashcrown 还老。给 **Hawke**（NPC_T004_08）加一句关于 Tobiah 的十二杯。
- **T004/facilities.json：** 把 Crosser 草图 *from below, we may rise* 加入图书馆深藏区（已在 SHARED_BRIEF；确认归档于 *采矿 —— 古图*）。
- **T004/items.json：** 把 *不老茶渣* 加为可拾/可买残片，系于 Jade Lantern Alric 之杯。
- **T005/npcs.json：** 加四位 NEW 灵魂 NPC：**Darrik Voss**、**Malen the Unsleeping**、**Brenna Greyhold**、**Tobiah Caul**。加 NEW 副灵魂 **The Ashen Herald**。五者皆标为峰会级 —— 即只在 critical 场景或严控子任务中可亲见。
- **T005/facilities.json：** 加大教堂之下的峰会室。记录四门、四杯、砌死的第五门（烧制粘土上之四结）。把此室标为需写手持有连续性清单以管 Herald 的"不开门而入"。
- **T005/items.json：** 把 Tobiah 的黄铜杯（Union 之席位）标为遗物级，与 T002 Durm 熔炉旁的不可击打金属块（D 线）冶金同。
- **Cross-line asset：** 确认四结图统一：Herald 之信（T001）、Mira 厨中之盘（T001）、Septa 的刮除令（T003 档案）、峰会 Malen 的仪封（T005）、第五门上之烧制粘土浮雕（T005）、一旦 A 线 Critical 达成 —— 创立宪章本身。同一图，六次出现，永不被 NPC 评注为 *the same image*。
- **Dialogue annotation：** T005 每位灵魂 NPC 的每一枢纽台词，写手**必须**保留 *// public= / feared= / private=* 三层注释作为写手专用注。游戏内**不**显示。它们在不同城镇里引用王冠时保 voice 一致。
- **Naming discipline：** 永不让任何王家阶以下之 NPC 说 *colonist*、*far side* 或任何现代词。Brenna 之 *we came from the other side* 是 C 线唯一明言，且只说一次、以族语、对单一听者。任何他角色 —— Darrik 不、Herald 不 —— 不口说之。
