# 主线 E：Depth-Walkers 的下行（The Descent of the Depth-Walkers）

> 源文件：../E-depth-walkers.md · 译文仅供审阅，以英文原版为准

## Function / 功能

E 线是反方向之线。
A 看章程，
B 看雾掩之旧事，
C 看四冠，
D 看天，
E 看**下**。

Depth-Walkers（地者）是一群披礼服的科学家行会。
他们以结毛绳量绳索，以 fathom 为单位。
他们以一架比诸王国还老的秤，将灯油称至粒。
他们在拂晓把一方油丝绢举在井口之上以测气流。
他们把上述每一种测量都称作祈祷，
而他们用*祈祷*一词，与北地铁匠用*tempering*（回火）一词同义：
一套有时序与温度的流程。

他们与 Guild、与诸王国平行，而非其附庸。
玩家遇之如一宗教，
离之时懂其为一座学会低语的实验室。

此线内部分裂。

**Listeners（派一）**是公开的面。
其中半数是真正的神秘者 —— 或因兄姊死于井，或因童年在蓄水池底听到什么，自此一生想再听到。
另一半是受封王家契约的遗物矿工。
两半不以阶相分；
他们坐同一桌，食同一薄汤，穿同一灰袍。
神秘是掩。
采矿是业。
Sula 本人两者并是，至此岁已分不清孰为孰。

**Crossers（派二）**于游戏开场九年前出走。
他们不愿将所得交给北冠。
他们秘密工程跨 Chasm 之法，
并相信答案在其下，而非其间。
他们不着袍。
他们在公开处不执灯。
他们必须发声时，用的是编目人与图书人的语域。

玩家立时遇见 Listeners（T002 起），
直到 T004 才知 Crossers 之存在。
此种不对称是刻意的，
所有城镇作者必须保之：
未挣得第二层的玩家不可被示以第二层。

此线在 T005 呈上游戏中玩家最难的背叛之选。
Archdepth Sula 坦白她的 Listeners 为诸王采掘遗物。
Crossers 则在同夜自屋之对侧向玩家揭示同一真相。
三扇门开：
加入 Listeners，明知其耻而披上契约，
将他们出卖予 Guild 并接受 Guild 对那张纸的处置，
或与 Crossers 一同消失，向一条百年无人走过之路。

## Soul figure(s) / 灵魂角色

- **Archdepth Sula of the Long Descent**
  Listeners 之图腾。
  首次出场：T005 Mistmere，旧水务所下之沉没厢。
  半疯。
  一半之疯是四十年在洞底听的余渣 —— 她听过北地之语无以承托之物，那些未被承托之物之形在她心上磨出一道凹。
  另一半之疯是愧：
  她为其冠她已不再确信的王们背遗物上来，
  且已做了太久，不认便不能止。
  语缓。
  即便沉默，也以四数为节数自己的呼吸。
  一只眼浊，三十岁时坍方所致。
  她的手是一双摸过四十年绳的手。

- **Navigator Kestrel**（副）
  Crossers 之图腾。
  首次出场：T004 Jadehollow，
  以图书管理员为掩，在 Consortium 图书馆深藏区工作。
  沉静，洁净，危险。
  不着袍。
  不执灯。
  持一本方格黑记事本与一枚十六分度的黄铜罗盘玫瑰。
  语域如编目员：
  架号，页号，礼貌的更正。
  未挣得他第二种语域的玩家永不会听见。

- **Yannic "Yan" Vello**（联络）
  年轻 Listener，十七岁，T002 Windrest。
  理想主义。非领袖。
  其作用狭：
  将一盏灯递入玩家之手，
  领其至一场启仪之边，
  然后在启仪完毕前南遁。
  他在主线中不再出现。
  他不知他那盏灯是 Crosser 的伪作；
  他以为自己是在为 Sula 跑一个直的 Listener 差。
  此种无知是他的诚实之一部分。

## Hook

- **Tier：** 2
- **城镇：** T002 Windrest
- **触发场：**

玩家日落后经城堡下道旁的中继所。
灯正由一名持长柴点灯之童从院之西北角向内点，
其序非城堡惯常的从左到右。

一位身披深灰油布外衣的瘦年轻人
站在中继柜台前，
想把一个裹好的包交给一位信使。
信使看包，
看年轻人一指烟炱，
一言未发走开。

年轻人不叫他。
他转身，见玩家，用眼量他们，
像铁匠量一段铁之前要看能造什么出来。

他问是否北行。

那包是一盏灯。
他请玩家把它送至 Grey Reach，
并原封不开地交给 Mistmere 沉没厢中
一位"will know the shape of the glass"（知此玻璃之形）的女人。

他不付钱。
他给三样：
一方折好的油丝绢，
一小铁罐水獭脂以浸灯芯，
还有一小张纸，上以稚拙而细心的字写一字：*Sula*。

玩家若不问径受，Yannic 目送其离去
而后回中继所内。
玩家若在离去前拆包，
Yannic 不止之。
他只说："Then you will know what you carry."（那你便知你带着什么。）
此言是 E 线之钥。
开包之玩家可得灯之完整描述；
未开者只被告知它比看起来重。

## The lantern (physical prop specification) / 灯（物理道具规格）

Yannic 予玩家之灯非泛用。凡写此灯之城镇作者须以同种方式呈现之。

- **身：** 一个两掌高的熏黑锡圆柱，附铰盖与环形提手。锡面被慢火熏黑，非偶然之痕，故其面不反光。
- **玻璃：** 仅一面有一块厚绿玻璃。另三面皆为实锡。这是一盏定向灯：光仅投一向，余向皆掩。Listener 读此为 *"the depth speaks to one ear"*（深只对一耳说）。
- **芯：** 织山羊毛而非棉。棉燃快而亮；山羊毛燃慢、低，湿风中不颤。芯被浸后再切，故始即重。
- **油：** 河獭之鍊脂，混松脂及一撮从一块 Listeners 称之为 *slow-stone* 的石头上刮下的黑粉。此混合物于芯近处冷蓝、尖处黄。不冒烟。升气中不灭。Listeners 说 slow-stone 是 Chasm 底之一片；Crosser 会说那是磨碎的 relic，且更近正确。
- **印：** 底之下，淡淡印一圈 —— 九小点绕第十点。Listeners 识此为 Sula 一组之记。Crossers 识出第十点偏 —— 偏中心 —— 从而知此灯非 Sula 之作，而是 Crosser 伪制之仿件。

Yannic 不知第十点偏。
他以为自己在跑 Listener 之差。
实际上，他在向北送一枚 Crosser 的探针，
而探针就是玩家。

### Lantern behaviours (for the orchestrator) / 灯之行为（orchestrator 用）

- 静风中，芯之首一指宽段燃冷蓝，尖处为黄。蓝段不暖玻璃。
- 升气中，焰不颤。它倾向气之源并保持倾向。Listeners 读此为灯在听。
- 当真正的殖民时代物件在场 —— T002（D 线）不可锻金属块、T005（D 线）殖民者纹章残片、T004（C 线）足量不老茶渣 —— 焰陡倍其高，凡三心跳复常。Listeners 称此为 *the greeting*（问候）。
- T004 之 Crosser 草图在场时，焰无反应。草图是亚麻上之墨，非 relic。此种"无反应"之结果，对细心玩家本身即是讯。
- 此灯不可从他焰引燃。须在其底缘击火自燃。此是流程之规，非法术之规；油中 slow-stone 需底缘之铁方能引燃。
- 若侧倒超过数二十之数，此灯会自熄。Listener 从不将之横放。

## Rituals and procedures (science in ceremonial disguise) / 仪与程（披礼服的科学）

每一场 Depth-Walker 仪轨都是一道实验流程外裹一层香云。
凡写 Depth-Walker 场景的城镇作者，须使两半同时可读：
只读表面者见一教；
细读者见一测。

### 四数之息

下行之前、查灯之前、读册之前皆用。
四入、四停、四出、四停。
Listeners 说这是"与大地之肺合律"。
实为一种稳定剂：
入低氧气之前的一段受控慢氧化。
Sula 近乎常驻之使用非敬 —— 
四十年在竖井中令她失肺活量，
她需此纪律方可长话不乏气。

### 结绳

每一条下行绳都按每 fathom 以毛包结。
毛染为四色循环：未染、红、黑、未染。
Listeners 称之为 *the year, the blood, the deep, the year*（年，血，深，年）。
实用之义：在暗中摸到结之下行者
可通过呼出自己刚过之色来向上报深度。
若一 Listener 呼出错色，不被纠正；他被拉上。

### 丝绢方

六寸见方之丝，一面上油。
在光之交替（黎明与黄昏）时举于井口。
Listeners 看它如何起，向何转。
记入本组之册三项：*time, lift, turn*。
他们所记者是气压差，
此差告知他们某井是否通一较大下方腔室
及该腔室是否另通别处之井口。
此为 Depth-Walkers 中心仪器。
Sula 诸组对 Reach 每一大井皆有丝绢方之记录，
二十年之数据，
Kestrel 藏有副本。

### 列格之册

每组一本。
三列：*sound, pause, thing-heard-in-the-pause*（声，停，停中所闻之物）。
每次下行由当值记录者填之。
一位 Listener 之敬虔以第三列之精度衡；
一位 Listener 之诚实以第三列多少次留空衡。
Sula 自己于 T005 桌上之册
有十八年记录
而第三列过半留空。
这，在 Listeners 自己的伦理中，是正直之标。

### Slow-stone 之审

每季一次，每组在其炉房的那架秤上称其剩余之 slow-stone。
重量对上一季记。
Listeners 说 slow-stone "以身供灯"。
他们实际追踪者
是一枚 relic 残片在常用中损耗之率 —— 
这对王家信使有商值，
对 Kestrel 有技术值。
Sula 虽已不信那只收数之手，却从未停此审。

### 启仪（坐一回）

详见 T003 线索表。
物理描述：一口干井，六十尺，麻绳，一时辰之黑。
载于册之目的：听独与地同时何物入耳。
实际目的：
藉玩家自述之所闻声，
辨其为受训之耳、未训之耳、或说谎之耳。
T003 组之老妇在三列之一勾下玩家的每一处声报，
玩家从不见哪列收了哪勾。

### 熄（三时辰之下行）

凡有组主发信之夜，
Reach 中每组每 Listener 皆在日落后第三时辰熄其灯，
下行。
发信机制在任何玩家向面向文本中都不描述。
（对 orchestrator：即丝绢方流程之反向 —— 一次协同之气压读数，由各组独立做，次周通过信使比对确认。信源始终是 Sula。）
云夜（D 线）那晚，Sula 未发信而熄仍发生。
这是她一生中首次对自己这一门畏。

### 袍

未染灰羊毛，无里，及膝，喉口一枚铁扣。
此扣同重 —— 半盎司，量过。
Listeners 说此重是 *"the weight of what is owed"*（所欠之重）。
实用之义：此扣是他们用以称油之小秤之对砣；
未带仪器外出至组之 Listener 可以自己喉口之铁为砣称油，
误差在一粒之内。
于 T005 门 1 接受 Sula 之袍者
会得一枚用与 Sula 同铁铸出之扣。

## Clues by town / 各城线索

### T001 —— Stoneford

E 线在 T001 不活动。此处不要埋 hook。但此线须对已做过 B 或 A 而回 Stoneford 之玩家保持可闻。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T001 | Septon Silas | 过话 | 问及 Depth-Walkers："A northern kingdom's foolishness. They climb down to find what the rest of us lost above."（一个北地王国的糊涂。他们下去找我们其余人在上头失之物。）他带倦笑说之。他不识 Sula 本人，但曾写过一信予她；他不说。|
| T001 | 古石碎片（Silas 法衣室）| 交叉参考 | 此碎片带一圈字符；若玩家日后在 T004 见 Crosser 草图，会认出它们与之共享根字符。此碎片属 B 线；E 线仅*依赖*它。此处不为 E 置 fragment。|
| T001 | 酒馆醉汉（无名）| 偷听台词 | "The earth-men. They got a house in Windrest now. A boy with a lantern."（地下人。他们现在在 Windrest 有一屋。一个带灯笼的男孩。）此为 T002 有 hook 的唯一信号。须平铺直述，不加强调，作酒馆杂音。|
| T001 | Guild 告示板 | 缺席之线索 | 一张关于 *"cellar-crawlers and unlicensed tunnellers"*（爬地窖者与无照掘道者）之悬赏每周新贴，一日内撤。细心玩家留意其规律。Guild（A 线）奉王家令压制 Depth-Walker 活动；此 C↔E 渗漏玩家要到 T005 才能破译。|

### T002 —— Windrest

Sprout。玩家见 Yannic，得灯，学到 *Listener* 一词。此处无 Crossers 可知。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T002 | Yannic "Yan" Vello | hook 授予者 | 新 NPC。十七，瘦，深褐肤，短发。灰油布外衣内套素毛衣。指染灯炱与松脂。宿于 Old Zhao 中继所的阁楼，虽 Old Zhao 不知他是 Listener，以为他是信使学徒。|
| T002 | Yannic | 对话（初）| "I do not need it delivered fast. I need it delivered unopened. There is a woman in the Grey Reach, in the sunken ward. She will know the shape of the glass."（我不需要快送。我需要不开送。Grey Reach 里有一位女人，在沉没厢。她会识此玻璃之形。）|
| T002 | Yannic | 对话（被逼）| "We do not look up. When a man says *the sky* we nod and walk on. What is below is older than the sky. Older than the far side anyone mutters of. That is all I will say on a keep road."（我们不往上看。有人说*天*我们就点头走开。下面比天老。比任何人喃喃的*彼岸*都老。在城堡之道上我只说这些。）|
| T002 | Yannic | 对话（关于灯）| "Goat-hair. Otter-fat. A pinch of slow-stone. Do not light it in a wind. Do not light it in a crowded room. If you must light it, face the glass at a wall and sit behind it. The light is not for you to see by. It is for whatever is on the other side of the wall to see you by."（山羊毛。水獭脂。一撮 slow-stone。勿在风中点。勿在拥挤屋中点。若必须点，使玻璃面墙，而你坐于后。光不是让你看路用的。光是让墙另一侧之物看你用的。）|
| T002 | Captain Yura Stoneshield | 体制压制 | 若玩家向 Yura 提 Depth-Walkers，她脸即合。"We do not name them in the keep. The Crown has been clear."（我们在城堡不称其名。王冠已明示。）她不逮捕玩家。她把一事写入一本小册。此册每周转至 T005。此为 C↔E 链接在早期浮出。|
| T002 | Old Zhao | 讯息售卖 | 五十金：*"The boy with the soot hands is not from here. He came up from the south two winters ago with no papers and a lantern too well-made for a boy his age. I do not ask. He pays rent in copper, which is more than the relay clerk does."*（那位手带灯炱的男孩不是本地人。两冬前自南上来，无文书，带一盏以他这年纪来说做得太好的灯。我不问。他以铜付房租，已比中继文书多。）|
| T002 | Mei | 无辜观察 | Mei 见过 Yannic 于黎明擦同一盏灯擦一时辰。她觉得美。她不知那是仪。|
| T002 | Brown | 无关 | Brown 无 E 关联。勿妄造之。|
| T002 | Kalran（铁匠）| 拒绝之线索 | 若玩家示灯予 Kalran，他哼一声，不肯加工。"That is not smithing. That is measuring. Ask the earth-men."（那不是打铁。那是测量。问地下人。）他不展开。|
| T002 | 天象 | D↔E 交叉 | 直云之夜（D 线），若玩家在 Windrest 且持此灯，芯会自燃短瞬 —— 三心跳，冷蓝 —— 而后熄。Yannic 若玩家事后找他，面色发白。"It answered. I did not think it would answer in a keep. You must go north faster."（它回答了。我没想到它会在城堡中回答。你须更快北行。）|
| T002 | 场景点（可选）| 夜下行 | 若玩家于云夜跟随 Yannic，他引之至中继所后一口废井，移三石，下行。他不请玩家下。一时辰后归，胸前湿至衣，一语不发。|

Yannic 不与玩家同行。他在交灯后两日内离 Windrest，此线中不再出现。T003、T004、T005 之城镇作者不得把 Yannic 调回。若玩家在 T003 问及，答："the boy went south"（那男孩南去了）。

### T003 —— Greyholt / 修道院

Involvement 前半。玩家开始看出 Listeners 不是孤立之教。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T003 | 修道院后墙字符 | 交叉线索 | 墙上刻 Eilin 的 "上下相通"（Above and below connect）。E 线在此活动时，玩家已见过。若玩家在墙前出示此灯，此灯底印（偏心之第十点）之影投墙上并与此字符的中心一划对齐。此为 B↔E 视觉门。|
| T003 | Maester Eilin | 哑写 | Eilin 不能言。她在石板上以粉写："The lantern is not of the cell that claims it. The ring is untrue. Who gave it to you?"（此灯非称之为其所属之组。此环不真。谁给你的？）她是此线中第一个指出 Crosser 伪作之人。她不解释；她只写 *untrue* 一字并加双线。|
| T003 | Preceptor Vossel the Younger | 勉强之导 | Vossel 知修道院北三时辰之一洞有一 Depth-Walker 组聚。他不亲带玩家。若被问两次，他会在一册祷书封内画地图。|
| T003 | Listener 组（洞，无名组主）| 启仪 | 此组无领班在场；皆在下行。唯一老妇守低炉。她未问便从玩家手中接过灯，在手中掂其重，对底印蹙眉，说："This is not Sula's. But it is bound for Sula. Someone has done her a discourtesy. Carry it anyway."（这不是 Sula 的。但它送予 Sula。有人对她无礼。照送就是。）随后主持启仪。|
| T003 | 启仪 | 场景点 | 玩家被以麻绳放入一口六十尺之干井，令其在全黑中坐一时辰，上来时描述所闻之音。无怪物。无勇气之试。老妇只把玩家所答记入一本有列格之册 —— 一列声，一列停，一列"停中所闻之物"。它是**一本伪装为仪的科学记录**。玩家离时得一枚小黄铜牌，上有一点与一道横痕。此牌在任何 Listener 组处皆识玩家为 *"one who has sat once"*（坐过一次者）。|
| T003 | 半焚 Northern Ban 诏令 | 交叉参考 | 在 Archivist Naryn 柜中（A 线 fragment）。此诏令将 Depth-Walkers 列入被禁之列。细读者见其由三冠签署，第四冠未签 —— Free North 弃签。此为 C↔E 链。|
| T003 | 老妇，组处 | 对话（临别）| "North of here, in Jadehollow, there is a librarian who will tell you the lantern is old. He is lying. Be careful of librarians. They have read more than is good for one life."（此北之 Jadehollow，有一图书管理员会告诉你此灯是旧物。他撒谎。慎防图书管理员。他们读得已多于一生所宜。）此为全线对 Crosser 存在的第一声私语，且以八卦之形作警。|

### T004 —— Jadehollow

Involvement 后半。Crosser 一派显形，但仅对已过门之玩家。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T004 | Consortium 图书馆深藏区 | fragment 位置 | **Fragment：Crosser 草图 "from below, we may rise"。** 一张折好的上脂亚麻片，塞在第三壁龛第三架后，在一本殖民时代潮汐表与一本矿工圣经之间。草图呈剖面：Chasm 自上看为一条黑线，其下一网拱道自近崖升起，穿雾而行，在对岸浮出。边侧以素净之手写：*from below, we may rise*。此草图与 T001 之石碎片（B 线）、与 Eilin 的修道院墙（B 线）精确共享三个根字符：沿草图下缘三个、与石碎片重叠二个、在 Mistmere 港壁内面一个。城镇作者必精确对应。第二笔写于草图旁：*"or from above, if above returns"* —— 此为 Crosser 对云之回应，见 D 线。|
| T004 | Navigator Kestrel | 门槛 NPC | 新 NPC。图书管理员为掩。三十八岁。净面，素灰罩衫，右手侧染墨。不戴护符。持一本方格小黑记事本。不自称 Depth-Walker。在 Kassa Deepvein 工资册上列为"junior cataloguer"（初级编目员）。他不与尚未 (a) 读过 Eilin 修道院字符"上下相通"，或 (b) 经手过真正殖民物件（T002 不可锻金属块，或在 T005 被示的殖民者纹章残片）的玩家说话。**此门关键。城镇作者须强制之。** 未过门而与他说话之玩家只得到编目员之礼：架号、道歉、请其降低音量。|
| T004 | Kestrel | 对话（初，过门后）| "You have seen the glyph. Good. Walk with me to the back stair. I need to show you a map older than the Consortium's charter."（你见过那字符。好。随我去后楼梯。我需给你看一张比 Consortium 章程更古的图。）|
| T004 | Kestrel | 对话（理论）| "The kingdoms tell you the Chasm is the only road. They are wrong. The colonial road ran *under* the Chasm, not across it. It was buried when the collapse came, because to bury a road is faster than to defend one. What the Listeners call relics are milestones. What they call holy dirt is a road-bed. We do not need to fly. We need to dig, and to walk where the old walkers walked."（诸王国告诉你 Chasm 是唯一之路。他们错。殖民之路走在 Chasm*之下*，非跨之。崩塌来时被埋，因埋一条路比守一条路更快。Listeners 所称之 relic 是里程碑。其所称圣土是路基。我们不须飞。我们须掘，并走古行者所行之处。）|
| T004 | Kestrel | 对话（论 Sula）| "She was a miner before she was an archdepth. She has a contract in a drawer. The kings pay her in coin and in the right to wear the robe. She is not a fraud. She is a woman who has convinced herself that the contract is the price of the truth. It is not."（她在成为 archdepth 之前是矿工。她抽屉里有一纸契约。诸王以币与容袍之权付她。她不是伪者。她是一位说服自己"那纸契约是真相之价"的女人。它不是。）|
| T004 | Kestrel | 对话（论 Eilin）| "I have her drawings. Every line she has made in the last fifteen years has come to me through a courier chain Vossel does not know he runs. I do not return them. She does not ask. She and I have an agreement made entirely in not-asking."（我有她的画。她近十五年所作每一笔，皆经一条 Vossel 不知自己在跑的信使链到我手中。我不归还。她不问。她与我有一份完全由"不问"组成之约。）此为 B↔E 的承认。|
| T004 | Kestrel | 对话（论灯）| 若玩家示灯："The tenth dot is mine. I made this one. Yannic believed he was running a Listener errand. He was running a Crosser probe. You are the probe."（那第十点是我的。此灯我做。Yannic 以为他在跑 Listener 之差。他在跑一枚 Crosser 探针。你就是那枚探针。）他说此话不致歉。|
| T004 | Old Fane Crowseye | 侧读 | 若玩家将灯带予 Fane，其淡色眼亮起。"Two makers. A Listener cast it, a Crosser re-stamped it. I have not seen that in twenty years. Someone is testing a seam."（两位制者。一位 Listener 铸之，一位 Crosser 重印之。我二十年未见此事。有人在试一条缝。）|
| T004 | 不老茶渣（王冠使节之杯）| 交叉参考 | 留杯之使节最近一次在与一位 Listener 信使会面。酒馆主 Jade 记得那一对。若玩家未先见 Kestrel，她不说。|
| T004 | Septon Silas | 遗言之卷一行 | 若 Silas 的三年遗言卷被寻得，其中一行："A woman called Sula writes to me once a winter. She asks whether the Faith considers a contract a vow. I have not yet answered her."（有位叫 Sula 的女人每冬写我一信。她问 Faith 是否视契约为誓。我尚未回她。）这是全游戏中唯一暗示 Sula 对她所签之物并未全然心安的线。|
| T004 | Kestrel | 离去 | Kestrel 不与玩家同离 Jadehollow。他说："I will meet you in the sunken ward at Mistmere, on the night she confesses. You will know it is the night because the lanterns in every Depth-Walker cell in the Reach will go out at the same hour. Do not ask how I will know. Ask how *she* will know."（我将在 Mistmere 沉没厢，她忏悔之夜与你会。你会知那是哪一夜，因为 Reach 中每一 Depth-Walker 组的灯笼将在同一时辰同灭。勿问我如何知。问*她*如何知。）|

### T005 —— Mistmere

Critical。Sula 与 Kestrel 皆在。三扇门。

| 城镇 | 载体 | 类型 | 内容 |
|------|------|------|------|
| T005 | Archdepth Sula of the Long Descent | 灵魂角色 | 新 NPC。六十一岁。鬓发剃短，顶发留长，以灰带束。肤色如羊脂。左眼浊；三十岁时坍方夺之，从未换罩。灰 Depth-Walker 袍外套矿工皮甲。手是一双与绳共四十年的手。即便讲话也以四数呼吸。|
| T005 | 地点 | 沉没厢 | 于 Mistmere 下阶旧水务所之下，一处厢在城池尚未立起之前是蓄水池。Sula 在此居与作。六位 Listener 陪侍。厢中央有一下行井，以一块需三人方可移之石板封。|
| T005 | Fragment 位置 | **Fragment：Listener 契约羊皮。** 在 Sula 桌上，以一片 slow-stone 压着。一张厚奶色折叠犊皮。语：北地正式文体。签者二：Sula（一枚简单十字）；王家一侧仅蜡印，无名。印为三冠印；第四冠缺。条款简：(1) Archdepth 诸组于月内将所有在下方掘得之异国铸物交指定信使；(2) 诸冠压下对 Depth-Walker 做法之公共调查，并不因无照下行诉其成员；(3) 此约于 Archdepth 身殁时作废。此羊皮七岁。一边沾炱 —— Sula 曾持烛近之，曾起焚心而未焚。此契约不是 Northern Ban。它是 Ban 所容许的 Listener 之契。Free North 从未签 Listener 之契；Brenna 的先辈拒绝，Brenna 继续拒绝，她的沉默在蜡上可读。|
| T005 | Sula | 对话（初）| "You carry a lantern that is mine and not mine. Sit. Breathe four. When you are ready, hand it to me."（你带着一盏既是我的也不是我的灯。坐。吸四。准备好时把它递给我。）她接过，翻转，见偏心之第十点，面上无显反应。四数之息不改。|
| T005 | Sula | 对话（忏悔，脚本点）| "I signed a paper. I did not sign it for money, though money came. I signed it because the kings would have sent soldiers into our shafts, and soldiers break instruments a listener cannot replace. I signed so that we could keep descending. I was not wrong to sign. I have not yet forgiven myself for being not-wrong. Do you understand that distinction."（我签了纸。我不是为钱而签，虽钱随之而来。我签是因为诸王会派兵进我们的井，而兵会碎一位 listener 无法更换之器。我签，以使我们得以继续下行。我签非错。我尚未原谅自己"非错"这一事实。你明白这一区分吗。）（她不作问句。）|
| T005 | Sula | 对话（理论）| "Below and beyond are not the same thing. That is Hallen talking, and Hallen came back with a cracked head. But below has more roads than the maps above will ever draw. That is what we listen for. The crowns think we listen for gold. We listen for the shape of a corridor that is not on any plan."（下与彼岸不是一事。那是 Hallen 在讲，而 Hallen 带着一颗裂头回来。但下比上图所能绘的有更多路。那才是我们在听的。诸冠以为我们在听黄金。我们在听一条不在任何图上的廊之形。）|
| T005 | Hallen the mad returnee | 对话（NPC，厢之病房）| 新 NPC。六十。斑白发，一肩永久下垂。十年前一次六月下行归来，自此未能整人安处一室。语残断。|
| T005 | Hallen | 典范一句 | "Below and beyond are one. The floor is the far wall."（下与彼岸是一。地板即远壁。）说完，笑一声 —— 不恶，只倦。此为理论三的典范交付。|
| T005 | Hallen | 展开 | "I walked down until the lantern failed. Then I walked more. The wall I met was not a wall. It was a floor I had stood on from the other side. I turned around and the way up was the way down. The listeners write this in their codices and call it a hallucination. I call it a geometry I do not have the teeth to chew."（我走下去直到灯失效。我再走。我遇到的那堵墙不是墙。那是一块我从另一侧站过的地板。我一转身，上行之道即下行之道。Listeners 把这写在他们册里，称之为幻觉。我称之为我没牙嚼的一种几何。）|
| T005 | Navigator Kestrel | 到达 | Kestrel 在忏悔之夜未叩径入沉没厢。六位陪侍 Listener 起立。Sula 抬手，他们坐下。她与 Kestrel 不拥抱。他们十一年未说过话。Kestrel 把另一盏灯放在桌上，在羊皮旁。此灯有真十点之环 —— 无偏心。"I brought you yours back," he says. "Corrected."（"我把你的带回来了，"他说。"已更正。"）|
| T005 | Kestrel（在 Sula 在场时）| 对话 | "The probe returned. The seam holds. The road is real. We do not need the kings and we no longer need the descent to be a vow. We need diggers who understand they are digging a road and not worshipping a hole."（探针归。缝合住。路为真。我们不需诸王，也不再需下行作誓。我们需懂得自己在掘一条路、而非敬一洞的掘者。）|
| T005 | Sula | 对话（反驳）| "You were always a man who forgot that a rite is how a frightened people learn to measure. Take the road. Leave us the measurements."（你一直是一位忘了"仪是受惊之民学测量之法"的男人。拿走那条路。把测量留给我们。）|
| T005 | 玩家场景点 | 三扇门 | 玩家此刻已持全貌：契约在桌，草图在袋，Sula 一边，Kestrel 一边，Hallen 在病房哼。此选不经言语成构。Sula 伸手掌上：*join us, take the robe, wear the contract with us*（加入我们，披上袍，与我们同披此契约）。Kestrel 头偏向厢门：*come with me, leave by the back stair, we go tonight*（随我，从后梯走，今夜即行）。桌上，三者皆见：羊皮 —— 第三选是把它带出厢到 Stoneford 的 Guild（A 线）。玩家作选时无人说话。Sula 数四。Kestrel 不数。|
| T005 | 天象 | D↔E 交叉 | 同夜，若 D 线之时合住，Reach 中每一 Depth-Walker 组在日落后第三时辰熄灯下行。水务所漆黑。井开。城上不觉。Sula 闻之，说："The calling from below is answering itself."（自下之呼正在答自己。）Kestrel 闻此同一静，说："The other side sent a scout. The road is proven."（彼岸派了斥候。路已证。）Hallen 说："It is the same sentence."（是同一句。）|
| T005 | 第四冠之缺 | C↔E 交叉 | 细心玩家审契约之印时察觉 Free North 之冠不在蜡上。Chieftess Brenna Greyhold（C 线）未签。若玩家日后就此事向 Brenna 提问，可得一枚 C 线之杠杆。C 线作者应预此交接。|
| T005 | Bishop Reynard | 外部压力 | Reynard 知 Sula 存在。他未动她，因她经契约向 Faith 悄悄送入一支"异国铸物"之流。若玩家把 Listeners 出卖予 Guild，Faith 一日内得知，Reynard 之算式随之变。（交予 C 线。）|
| T005 | Lady Vera Ashford-Blackwater | 斜视之兴 | Vera 已通过一个空壳买下旧水务所之地契。尚未动手。若 Listeners 解散（玩家选 Guild 门），此厢一月内归她，她拆之。|

## Stage endpoints / 阶段终点

### Sprout end（T002）

玩家持灯。
知 *Listener* 一词。
已被劝勿开包。
已开或未开。
无论如何，他/她携之北行。
若云夜已发生，他/她已见芯自燃三心跳，
并携此象同行，无论有无词。
Yannic 已南去，不再在此线出现。

### Involvement end（T004）

玩家已见 Kestrel —— 门槛、挣得、非偶然。
手中有 Crosser 草图，折回其油亚麻中。
知其所携之灯是一件 Crosser 对 Listener 之仿伪，
且知此伪是刻意为之。
知 —— 因 Kestrel 已直告 —— 
Mistmere 之会夜将以 Reach 中每组灯笼同时熄火为信号。
尚不知契约在 Sula 桌上，
但知有一纸契约。
若亦已循 B 线，已认出草图、石碎片与修道院墙所共之根字符。
未认出者仍可过 T005；
此结局不需此认出，
但此认出改变 Sula 与 Kestrel 各自所言之分量。

### Critical decision at T005

此景：
旧水务所之下的沉没厢，
中央井已封，
六位陪侍 Listener 坐于墙侧木凳，
Sula 在桌前，契约羊皮与 slow-stone 在桌，
Hallen 在灰帷后的病房，哼一非调之四音型，
Kestrel 立于厢门，左手一盏更正灯，右手空。

玩家已持全貌：
契约在桌，
草图在袋，
Sula 一边，
Kestrel 一边，
Hallen 在帷后。

此选不经言语成构。
Sula 伸手掌上：*join us, take the robe, wear the contract with us*。
Kestrel 头偏向厢门：*come with me, leave by the back stair, we go tonight*。
桌上，众目共见：羊皮 —— 第三选是将之出厢南送至 Stoneford 的 Guild（A 线）。

玩家作选时无人说话。
Sula 数四。
Kestrel 不数。
Hallen 的哼不改。

三扇门：

**门 1 —— 加入 Listeners。**
玩家坐到 Sula 身旁的空凳。
行四数之息。
袍由陪侍 Listener 中最老者置其肩。
一周内以与 Sula 同一铁条为其铸扣。
灯在桌上开启，以 Sula 抽屉中（与契约同处）之小打印，重印一圈真十点，复还玩家。
玩家被写入契约后页作无名证人。
Crossers 视玩家为失。
Kestrel 当夜从后梯离厢，
在本场游戏中不再联系玩家。
长期后果：
玩家获得五城所有 Listener 组之门径、
每半季以铜发放之固定津贴、
以及对井中究竟有何之慢积累知识。
玩家从此在 Stoneford Guild 分处不受欢迎；
Guild 有关于已受约方之规，而这就是其中一条。

**门 2 —— 出卖予 Guild。**
玩家从 Sula 桌上拿起羊皮。
Sula 不止。
Kestrel 不止。
若玩家迟疑并欲还之，二人皆不肯接。
陪侍 Listener 起立但不动；
Sula 以方才伸出过之手示意坐下。
玩家携羊皮南行，
至 T005 的 Magister Corvin Ashford-Reed（A 线 Guild 灵魂角色）
或 T001 的 Guild 分处。
Guild 以之迫三位签冠重议 Northern Ban。
Depth-Walkers 于此季内被正式立法禁绝。
Sula 在厢中六日后被捕；
不抗；请求携其册同行，被拒。
Kestrel 失踪。
Crossers 被迫更入地下，
在当前游戏中不再可联系。
沉没厢一月内被拆；
Lady Vera Ashford-Blackwater 经一空壳收购得此清空之地。
玩家以 Guild 声望得酬。
他们得不到安眠。

**门 3 —— 随 Crossers 而去。**
玩家当夜与 Kestrel 自后梯而出，在暗中。
Crossers 的工程组立即北移，
经三安全屋接力
（一在 T004 外之草棚，一在 T003 上之一牧羊人棚，一在 Reach 上的一渔人船屋）。
三日内，玩家被示以旧殖民之路的口：
一道嵌于 Chasm 近崖、下缘之下四百尺之石拱，
由 Crossers 九年维护之下行绳抵达，
以一块与灯同圈印之石板所封 ——
十个真点成环，刻于石上，规模非一人之手所能成。
游戏于 v0.1 在石板处结束。
Crossers 说：*not yet. You have seen it. Come back when you have the tools.*（还不行。你已见过。带着工具再来。）
玩家获得 Crosser 草图作永久物件、
一张另折之 Crosser 密码钥、
以及在 T003 与 T004 的 Crosser 安全屋之门径以供日后。
他们未获跨 Chasm 之能。
他们获得：跨越，原则上是一件工事的知。

三门皆叙事完整。
皆不标为正解。
orchestrator 须拒为其排名。
事后若玩家问某 NPC 自己选得如何，
NPC 须以角色作答，并可评断 ——
Septa Malen 将谴门 3，Brenna 将私许门 3，
Corvin 将赏门 2 而永不请玩家赴宴，
Sula 若尚在，只会说：*you chose. that is a thing to have done.*（你作了选。那是一件已做之事。）

## Cross-line interactions / 跨线互动

### B ↔ E（主）

E 线依赖 B 线之*古石碎片*（T001，Septon Silas）
与 B 线之*修道院墙字符 "上下相通"*（T003，Eilin）。

T004 之 Crosser 草图与两者至少共享三个根字符。
草图、碎片、墙，实为同一更古之手的三位证。

E 线之 Navigator Kestrel 在 T004 深藏区持 Eilin 之画；
B 线作者应使 Eilin 在玩家问及其失画时以粉写：*"he keeps them"*（他留着它们）。

T004 的墙字符玩家门
（Kestrel 拒与未读过字符或未经手过殖民物件之玩家说话）
是 B↔E 的中心交接，不可弱化。

### B ↔ E（次）

若玩家在 T004 之前于 Eilin 面前示灯，
Eilin 在石板上写：*"the ring is untrue"*。
此为灯为 Crosser 伪作的最早警。
B 线作者须守此精确措辞。
Eilin 不以名识 Crossers。
她只识：此灯之环不是她见过的 Sula 信使所携之环。
这已足指示伪作，而不必向玩家揭出 Kestrel。

### C ↔ E

E 线依赖 C 线的压制政策。
只有 Crown、Faith、Union 三冠签了将 Depth-Walkers 列禁的 Northern Ban；
Free North 弃签。

Chieftess Brenna Greyhold（C 线）秘许 Listener 组于其辖内，
因她自己对殖民旧事之记忆与 Kestrel 之理论相合，
虽她从未见过他。
她从未说出过 *Crosser* 一词。
她不知此派有此名。

C 线作者须在 Brenna 之廷留一缝，
予携"第四冠未签"之知识而至的玩家。
玩家若读过 T005 的羊皮并留意到缺印，
可于私下对 Brenna 质询，Brenna 被逼私问时，或可不否认。

C 线的 Faith 侧 —— High Septa Malen —— 根本不知有此契约。
她以为压制是教义之事。
玩家若向她出示羊皮，将在一分钟内令她整个宇宙观崩塌；
C 线作者承担其后果。

### C ↔ E（王冠使节）

T004（C 线）的不老茶渣是一位王冠使节留在 Jadehollow 的，
他当时在与一位 Listener 信使会。
此会之义，在 Listener 一侧，
是履行 Sula 契约所定的"异国铸物"月交。
此会之义，在使节一侧，
是确认王冠之付款已到。
酒馆主 Jade 记得那一对，
会对一位已见过 Kestrel 且未见过别人的玩家描述他们。

### D ↔ E

直云之夜横过 Reach 上空（D 线 sprout 事件），
Reach 中每一 Depth-Walker 组在日落后第三时辰熄灯下行。

D 线之 *Veyl "the Line"* 于 T005 对此事件又作别一读 ——
他以为此云是他记得的最古之歌中那种侦察，
他若得知熄灯之事，便以为那是地下人也识出之的证明。

E 线之 Sula 将熄灯读作 *the calling from below answering itself*（自下之呼答自己）。
E 线之 Kestrel 将熄灯读作 *the other side sent a scout*（彼岸派了斥候）。
E 线之 Hallen 将熄灯读作 *it is the same sentence*（是同一句）。

三读皆是"典范之见"。
三读皆未证实。

D 线作者须把云夜置于 E 线 T005 忏悔之前，
且不得把下行写作公共之事。
任何 T005 镇民被问及熄灯，须答：*what dousing.*（什么熄灯。）

### D ↔ E（Old Bram 交叉）

T004 的 Old Shepherd Bram（D 副）一生两次见过 Listener 信使，
两次皆于黄昏越过其高牧，未点灯笼。
他不知他们是谁。
若问，他说：*grey-coated folk. The earth-men, maybe. I do not trouble them and they do not trouble me.*
这是 D 线表面中唯一承认 Listeners 存在的一处，
且须保持在此精确水平。

### A ↔ E

E 线之*出卖门*（门 2）把契约羊皮交予 Guild。
A 线之 Magister Corvin Ashford-Reed 须有书面处置：
被呈羊皮时，
他不谢玩家，
也不在柜台付账 ——
他以一封寄至 Stoneford 分处的封缄信付账，
信由一位不出玩家之名的信使送至。
A 线作者主此处置；
E 线只交付羊皮。

### A ↔ E（压制）

A 线的 Guild 每周贴悬赏，针对 *"cellar-crawlers and unlicensed tunnellers"*。
此类悬赏一日内被撤。
它们由 Stoneford 的 Guild 分处
在与北冠的一份静默合约下张贴。
此合约本身在 A 线或 E 线中皆不对玩家可见。
细心玩家会察此规律，并可向 Corvin 问及；
Corvin 不答。

### E-internal（Listener ↔ Crosser）

九年前，Kestrel 是 Sula 的第二好之绳。
他在她从王冠使节那带回首份契约、不肯向他出示之夜离去。
他带走两组 —— 一在 Jadehollow，一在 Reach 上一个不在玩家地图上的村子。
他自此至 T005 忏悔之夜从未亲见 Sula。
九年间通过二封信，
两次都经一位二人皆不信任的信使，
两次都只问一个技术问题。
这两封信皆在 v0.1 中不可寻回。
orchestrator 不可虚构其内容。

## Write-in checklist for town writers / 城镇作者写入清单

- **T001 / npcs：** 给 Septon Silas 加一过话，关于 Depth-Walkers（*"A northern kingdom's foolishness…"*）。勿给他 Listener 之秘；他不是。加一无名酒馆醉汉台词：*"The earth-men. They got a house in Windrest now. A boy with a lantern."* 加 Guild 告示板每周关于 cellar-crawler 的悬赏（贴出并于一日内撕下）。
- **T002 / npcs：** 加**新 NPC Yannic "Yan" Vello**，17 岁，Listener 联络，位于中继所阁楼。状态：未遇。加其三段脚本对白（交付、被逼、灯具说明）。作交后离镇之旗；此线中不再出现。
- **T002 / npcs：** 给 Captain Yura Stoneshield 加被点名 Depth-Walkers 时之反应（*"We do not name them in the keep"*）；注其将此类提及写入一本小册，每周转至 T005。
- **T002 / npcs：** 给 Old Zhao 加 50 金情报：*"the boy with the soot hands"*。
- **T002 / npcs：** 给 Kalran 加示灯时的拒绝之线索（*"That is not smithing. That is measuring."*）。
- **T002 / items：** 加灯之规格（身、玻璃、芯、油、印）为物理物件，带偏心之第十点。此为 E 线标志性道具。
- **T002 / events：** 加云夜之芯自燃事件，交叉 D 线。
- **T003 / facilities：** 确保修道院后墙字符 "上下相通" 已写入（属 B 线；E 线依赖）。加视觉门：E 线之灯在墙前出示时，其底印之影与字符中心一划对齐。
- **T003 / npcs：** 给 Maester Eilin 加示灯时之石板回应：*"The lantern is not of the cell that claims it. The ring is untrue. Who gave it to you?"*
- **T003 / npcs：** 给 Preceptor Vossel the Younger 加祷书封内画图之选项。
- **T003 / npcs：** 加**无名老妇**于 Listener 组（洞，北三时辰）。此线中故意不给其名。加启仪场景点（六十尺麻绳，一时辰之黑，记入列格之册）。加一枚单点带横痕的黄铜牌作物件，识玩家为 *one who has sat once*。
- **T003 / npcs（老妇临别）：** 加关于"Jadehollow 有一图书管理员会告诉你此灯是旧物；他撒谎"之警。
- **T004 / facilities：** 给 Consortium 图书馆深藏区加**fragment Crosser 草图 "from below, we may rise"**，位于第三壁龛第三架后。根字符与 T001 石碎片、T003 墙镜像。
- **T004 / npcs：** 加**新 NPC Navigator Kestrel**，38 岁，图书管理员为掩，Crosser 灵魂角色。状态：未遇。强制玩家门：Kestrel 不与未读修道院字符或未经手殖民物件之玩家说话。加其四段脚本对白（理论、Sula、Eilin、灯）。
- **T004 / npcs：** 给 Old Fane Crowseye 加示灯时之两制者读数（*"A Listener cast it, a Crosser re-stamped it"*）。
- **T004 / npcs：** 给酒馆主 Jade 加对王冠使节与 Listener 信使会面之记忆（以已见 Kestrel 为门槛）。
- **T004 / npcs：** 给 Septon Silas 的三年遗言卷加一行，关于 Sula 的年信。
- **T005 / npcs：** 加**新 NPC Archdepth Sula of the Long Descent**，61 岁，Listener 灵魂角色，旧水务所之下的沉没厢。状态：未遇。加其四数之息、忏悔场、理论句。
- **T005 / npcs：** 加**新 NPC Hallen the mad returnee**，60 岁，沉没厢之病房。状态：未遇。加典范理论句 *"Below and beyond are one. The floor is the far wall."* 与几何展开。
- **T005 / npcs：** 作 Navigator Kestrel 于 T005 忏悔之夜第二次出场之旗；他已置于 T004。
- **T005 / facilities：** 加旧水务所之下的沉没厢，中央下行井以三人板封。加六位无名陪侍 Listener。
- **T005 / items：** 加**fragment Listener 契约羊皮**，在 Sula 桌上，以一片 slow-stone 压之。详其二签名（Sula 之十字，三冠蜡印，Free North 缺）、三条款与七岁。
- **T005 / events：** 加云夜日落后第三时辰之同时熄灯（交叉 D 线）。写作静默，非公共事件。
- **T005 / scenes：** 加沉没厢中三扇门之场，作无言之选：Sula 掌上、Kestrel 头偏、羊皮在桌。orchestrator 不可把此选叙作有权重。
- **T005 / hand-offs：** 为送羊皮之玩家在 A 线（Magister Corvin）留缝；为问及第四冠之玩家在 C 线（Brenna）留缝；为见证云夜熄灯之玩家在 D 线（Veyl）留缝。
- **全城 / 压制：** 除 Depth-Walkers 以外，无 NPC 说 *Crosser* 一词。此词在 T004 挣得，之前绝不得用。作者须自守其对白不漏。
- **全城 / 无现代词：** Kestrel 的 "road under the Chasm" 是路，不是隧道系统；灯油是鍊脂，不是燃料；slow-stone 是石头，不是矿物；草图是草图，不是地图。保持土语语域。
- **全城 / Yannic 不回：** T002 之后，Yannic 南去。勿将之写入 T003、T004、T005。此为刻意之结构性缺席。

## New NPCs introduced by this line / 本线首引之新 NPC

以下 NPC 首引自本文，未见于任何前述镇之 roster。
城镇作者在接入 T00x 交接时须加之。

- **Yannic "Yan" Vello** —— T002，联络，17 岁，Listener。旗 *state.met = false*。
- **Navigator Kestrel** —— T004，Crosser 灵魂角色，38 岁，图书管理员为掩，在 Kassa Deepvein 工资册上列为 "junior cataloguer"。旗 *state.met = false*。门槛。
- **T003 洞中组之无名老 Listener** —— 刻意不命名。不需持续旗；单场即止。
- **Archdepth Sula of the Long Descent** —— T005，Listener 灵魂角色，61 岁。旗 *state.met = false*。
- **Hallen the mad returnee** —— T005，沉没厢病房，60 岁。旗 *state.met = false*。
- **T005 厢之六位陪侍 Listener** —— 无名，集体。无旗。

## Organisation of the Listeners (reference map) / Listeners 组织（参照图）

Listeners 组织为*cells*（组），而非章或会。
一组一井一炉房一册。
一组四至十二人。
一组一位主事，称 *recorder*（记录者）而非 master，
其事为守册、签丝绢方之记录。
Sula 是 T005 厢组之记录者，
并仅因资深而为 Archdepth ——
*archdepth* 不是权之阶，而是所达之深之阶。
Sula 按其自己之册为现今所有 Listener 中所达最深者，
且分别于四井。

游戏开始时已知之组：
- **Windrest loft-cell** —— Old Zhao 中继所之上。四人。Yannic 最小。
- **Greyholt cave-cell** —— 修道院北三时辰。七人。记录者为主持启仪之老妇。
- **Jadehollow pit-cell** —— 在 Consortium 九年前弃用并视为已塌之矿井。六人。记录者仅知名 *Ten-Fingers*，一个一指未失之女人。
- **Mistmere ward-cell** —— 沉没厢。含 Sula 共七人。记录者为 Sula。
- **Upland cell（off-map）** —— Reach 之上，玩家在 v0.1 不可达之一村。十一人。记录者不为他组所识。

Crossers 无组之结构。
他们有三处安全屋与一处工程场。
工程场是 Chasm 近崖的旧殖民路口。
Kestrel 不是记录者，亦不是 master。
他被称 *navigator*（航者），因他是首位定位此路口并与草图对上者。

## Orchestrator notes / world-agent 备注

- *Crosser* 一词是挣得，非给予。在 T004 Kestrel 之前，无派外 NPC 说此词。若玩家在 T001–T003 说出，NPC 反应如玩家说了一无义词。Sula 在 T005 听到时缓慢一点头，不纠玩家之用。
- *Listener* 一词自 T002 起可随意得。
- 汉字 "上下相通" 在本文中仅在 T003 节出现一次作交叉参考。属 B 线。E 线作者不引新字符；E 中任何字符皆归 B，仅镜像之。
- Hallen 的理论（*"Below and beyond are one. The floor is the far wall."*）只在 T005 交付，别处皆无。不访病房之玩家不得此理论。此为预期。
- Kestrel 的理论（*"Colonial-era transit ran underground, not across."*）只在 T004 交付，别处皆无。不过 Kestrel 门之玩家永不听此理论。此为预期。
- 另两种地下 relic 之理论（King's Archivist、Eilin）分属 C 线与 B 线。本文只作交叉链提及。E 线不重写之。
- 隐藏之前提在本文中从未说出，并在由之生成之任何向玩家之文本中亦绝不得说出。彼岸永只作土语感官存在。
- 玩家若问，在任何时刻，彼岸是否为真，Depth-Walker 之答为：*the far side is a question above. We are below.*（彼岸是一个上面的问题。我们在下面。）此拒而不否。

## Gaps requiring sibling input / 需同门作者确认之空档

- **Line C / Brenna：** 确认 T005 契约缺第四印与 C 线对 Brenna 私容之框架一致。若 C 线已将 Ban 写作一致通过，须调和。
- **Line D / cloud timing：** 确认 D 线之云夜于 E 线 T005 忏悔之前发生，合于预期之场次弧。若 D 线把云夜置于 T005 之后，D↔E 熄灯事件须重写。
- **Line A / Corvin handler：** A 线须为门 2 供封缄信之付款处置。E 线只写交付。
- **Line B / Eilin 石板行：** 确认 Eilin 之石板可承两句所需措辞（*"he keeps them"*、*"the ring is untrue"*）。若 B 线给 Eilin 分派了不同的石板语域，须协商调整。
- **Line D / Bram 的高牧目击：** D 线之 Bram 或已有一 Listener 目击之台词，或无。若无，D 线须加；E 线不可越 D 线之 NPC 自增。

End of Line E brief.
