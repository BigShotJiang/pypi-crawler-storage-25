# Multi-Agent Orchestration Example

This example demonstrates M8 features for multi-agent orchestration:

- **Provider Registry**: Named LLM configurations (`fast`, `strong`, `local`)
- **Task Tool**: Orchestrator delegates work to sub-agents
- **Direct Write**: Narrator writes directly to `lore/` without proposal
- **Per-Agent LLM**: Each agent uses different provider via `provider_ref`

## Directory Structure

```
multi-agent/
├── .neonrp/
│   ├── config.json      # Provider registry
│   ├── manifest.json
│   └── events.jsonl
├── agents/
│   ├── orchestrator/    # Routes requests, uses 'strong' provider
│   │   ├── agent.json
│   │   └── system.md
│   └── narrator/        # Creative writing, uses 'fast' provider
│       ├── agent.json
│       └── system.md
└── game/
    ├── run_state/
    │   └── game-state.json
    └── lore/
        └── example-lore.json
```

## Usage

```bash
# Run world-agent with a lore request
cd examples/multi-agent
neonrp dispatch --agentic -q "Create a lore entry about the ancient war"

# The world-agent will:
# 1. Analyze the request
# 2. Delegate to narrator via task tool
# 3. Narrator writes directly to lore/
# 4. Orchestrator reports success
```

## Configuration

The `config.json` defines three provider profiles:

- **fast**: `gpt-4o-mini` for quick, cost-effective responses
- **strong**: `gpt-4o` for complex reasoning tasks
- **local**: Ollama endpoint for local inference

Agents reference these via `llm.provider_ref` in their `agent.json`.
