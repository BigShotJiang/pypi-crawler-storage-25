# Beyond the World — The Great Chasm

> Worldbuilding hook for the far north. Players travelling beyond the Grey Reach
> will surface one of two legends. No fixed plot yet — this is a v0.2+ thread.

## Geography

North of the last known holds, past where the maps stop naming things, the land
opens into a wound. The Great Chasm runs east to west for longer than any rider
has followed. Its walls fall away into a mist so thick the far side is only a
rumour of stone. No bird crosses it — they turn back at the updraft. No rope has
ever reached the bottom. No bridge has ever stood.

The Chasm cannot be flown. That part is not debated.

But the bottom can be walked, by those who know the ways down. And the far side
exists — men have seen it at dusk, when the mist thins. Reaching it requires
means the Chasm has not yet given up.

Two paths to the truth. The world admits this much, and nothing more.

## Legend One — The Iron Dragon

Told in the oldest hold of the north, passed down since before the kingdoms
had names.

In the first age, a dragon of iron flew the Chasm. It was not beast. It did not
breathe. It sang like a forge and left a straight line of cloud behind it. On
its back rode the Hero-from-Beyond — a traveller from the far side, whose
language is now lost.

The Hero spoke of a world across the Chasm, and the words have been repeated by
old men and old men's grandfathers, and each time a little more has been rubbed
smooth. What remains is a fragment in a tongue no one alive reads:

> *Eternal-life × Gold × Infinity. Do not attempt to visit.*
>
> (永生 × 黄金 × 无穷，千万不要尝试到访)

Nobody knows what the three words mean together. Some say it is a warning
scraped onto the door of a paradise. Some say it is a prayer. Some say it is the
Hero's last breath, mistranslated into something that only sounds like a curse.

The Iron Dragon has not been seen since.

## Legend Two — The Depth-Walkers

Told in the neighbouring northern kingdom, where the Chasm runs closest to the
border.

They do not look up. They look down.

The Depth-Walkers — *地者* — hold that the truth of the world is at the bottom
of the Chasm, and that the far side is a distraction. Their kingdom raises its
children to climb down. Rope-craft, lungs, lanterns that burn in the wet air.
To die at the bottom is an honour; to turn back halfway is a shame the family
carries for three generations.

No Depth-Walker has ever returned with the truth. That is not treated as
evidence against the practice. It is treated as evidence that the truth is
still down there, still waiting.

Their common saying, heard at funerals:

> *He walked until the lanterns failed. That is enough.*

## Player-facing hooks

- Travelling due north past the Grey Reach, the player will eventually meet
  bards, veterans, or Septons of either legend.
- Both legends are presented as **true-to-their-tellers**, never reconciled.
- Neither is fully playable in v0.1 — they are end-of-map teasers.
- A player who reaches the edge of the Chasm will see only mist and hear only
  wind. Finding a descent, or a means to cross, is beyond the current game.

## For the orchestrator

- Do not resolve the mystery.
- If the player asks which legend is correct, let NPCs argue. Let the argument
  end without a verdict.
- The phrase *Eternal-life × Gold × Infinity* is canon. Do not translate its
  meaning for the player. The language is lost.
- The word *地者* is canon. It is not translated inside the fiction.
