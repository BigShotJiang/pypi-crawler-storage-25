# The Old Tongue

> A reconstruction of the colonial-era language as it survives in the Grey
> Reach. Fragmentary, partial, and — in the Faith's handling — ritualized
> beyond recognition. The tongue is no longer spoken. It is read, written,
> and occasionally recited in liturgy, but no one alive has had a
> conversation in it.
>
> What remains is: thirty root-glyphs recovered from rubbings, inscriptions,
> and the field-texts carried by the Third Wave; a small inventory of
> particles and suffixes; a set of directional conventions; and a handful
> of reconstructed example sentences. The reconstruction is primarily
> Eilin's work, extending her unnamed master's notes. It is not complete.
> Where the reconstruction is uncertain, this document flags it.
>
> This document is the canonical root-roster. Do not add new roots without
> anchoring them to a storyline fragment.

## Part I — Orientation

The old tongue was written left-to-right, top-to-bottom, with no word-
division and no punctuation in running text. Glyphs stacked vertically
form compounds; glyphs placed side-by-side in a row form sentences.
Particles are written smaller than roots and sit in the lower-right
quadrant of the glyph they modify.

The tongue has thirty identified root-glyphs (this document's Part II),
a system of compound-formation by vertical stacking (Part III), five
grammatical particles (Part IV), a handful of directional and locative
affixes (Part V), and a prohibitive mood (Part VI). The reconstructed
example sentences are in Part VII. Known fragments — the Iron-Dragon
warning, Eilin's wall phrase, the stone shard, the colonist crest — are
decomposed in Part VIII.

### The problem of transliteration

Each root is given here in three forms:

- **Transliteration** — the Latin-alphabet rendering used by Eilin and her
  master. Three letters per root, occasionally four, never more.
- **Gloss** — a short English meaning. Where the gloss is metaphorical or
  extended, the base meaning is listed first and the extension in
  parentheses.
- **Visual shape** — a brief description of the glyph's shape, suitable for
  a town writer who needs to place the glyph on a wall or a pendant.

The transliteration is a working convention. It is not pronounced the
way its letters would be pronounced in any modern tongue. A reader who
wishes to say the tongue aloud should treat every *e* as a short *eh*,
every *a* as a flat *ah*, every *o* as a round *oh*, every *u* as a dark
*oo*, every *i* as a thin *ee*. Consonants are what they appear. There
are no tones.

## Part II — The Thirty Root-Glyphs

The thirty roots are grouped here by semantic domain. The numbering is
Eilin's, taken from her draft codex, and is preserved as the canonical
ordering.

### Body, Life, and Time (roots 1–6)

1. **bren** — body, flesh, self. Visual: a narrow upright with two short
   horizontals at the shoulder-line. Appears in vel-bren (unending-body).

2. **vel** — unending, without-stop, eternal. Visual: a long horizontal
   line that loops back into itself at the right terminal. The loop is
   the distinguishing mark; without the loop, it is merely *the-line*.
   **Present in the Iron-Dragon warning AND the stone shard.**

3. **keth** — time, season, the passage of days. Visual: three short
   parallel verticals descending from a single horizontal cap.

4. **dun** — death, ending, the stop. Visual: a single downward stroke
   crossed by a short horizontal near the bottom. Eilin's master noted
   that dun is the inverse of vel in the glyph-set's internal logic:
   vel loops back, dun does not.

5. **sai** — breath, voice, speaking. Visual: an open curve like a sickle
   with its point facing left. Breath enters from the point.

6. **ehn** — silence, the withheld word, that-which-is-not-said. Visual:
   the sickle of sai, closed at the point by a short vertical. The
   closure is the distinguishing mark.

### Earth, Stone, and Metal (roots 7–12)

7. **kor** — shining, bright, metallic (in the extended sense, of
   architecture made of shining metal). Visual: two short strokes
   crossing at right angles, like a small cross, with a dot at the upper
   right. The dot is the "shine." **Present in the Iron-Dragon warning.**

8. **thal** — dwelling, hall, built-thing. Visual: a horizontal base with
   three short uprights on it, like three stakes driven into a line.
   A compound with kor stacked above thal yields kor-thal, "shining-
   metal-dwelling."

9. **reh** — great-cliff, the vertical-face, the rising-stone. Visual: a
   tall vertical with a short horizontal cap and a downward hook at the
   right terminal. The hook distinguishes reh from the unmarked vertical.

10. **gai** — great-chasm, the vertical-fall, the opening-below. Visual:
    the mirror of reh — a tall vertical with a short horizontal base
    and an upward hook at the right terminal. Eilin's muted paper argued
    that reh and gai are the same glyph seen from two standpoints, and
    that the two meanings are therefore the same feature named twice.
    The Crown and Faith jointly ordered her silenced for this claim.

11. **nor** — metal, unworked. Visual: a short horizontal with a single
    vertical descending from its midpoint. The plainest of the mineral
    roots. A compound with kor above nor yields kor-nor, "shining-
    metal," which is the old-tongue name for the un-hammerable alloy
    the Free North inherits.

12. **gru** — earth, ground, the-floor. Visual: three horizontal strokes
    stacked, the lower two slightly longer than the upper.

### Motion, Path, and Place (roots 13–18)

13. **ven** — come, arrive, approach. Visual: a short upward stroke with
    two small curves branching from its midpoint to the lower-left.
    The branches suggest feet. **Present in the Iron-Dragon warning.**

14. **tol** — road, path, way. Visual: a single long horizontal with two
    small upward hooks at its left and right terminals. The horizontal
    is the road; the hooks are the destinations.

15. **san** — uncountable, many, without-number. Visual: a circular
    form, open at the right, with a small dot inside. The open circle
    represents the uncountable; the dot, the self that is counting.
    **Present in the Iron-Dragon warning AND the stone shard.**

16. **sel** — above, over, the upper. Visual: a short horizontal with
    three small dots above it, arranged in a slight arc. sel is the
    glyph for the upper region of any stacked compound.

17. **mor** — below, under, the lower. Visual: a short horizontal with
    three small dots below it, mirroring sel. In the old tongue mor
    also carries the euphemistic sense of *the place we came from*,
    because the First Wave came up from below. Compounds with mor
    therefore often read both spatially and historically.

18. **ruh** — sky, air, the above-the-above. Visual: an arch, like an
    inverted bowl. ruh is not a compounding root; it appears standing
    alone or as the subject of a sentence.

### Count, Measure, and Exchange (roots 19–22)

19. **ast** — one, the self, the singular. Visual: a single dot with a
    short horizontal below.

20. **bel** — four, the group, the quorum. Visual: four short strokes
    arranged as the points of a small square. The four-knot arbitration
    seal is a bel-glyph with a smaller ast-glyph nested inside, giving
    the "four around one" arbitration mark. The Guild's ten-dot mark
    is a late, ritualized form of this.

21. **nim** — exchange, barter, weight. Visual: two short horizontals
    linked at their midpoints by a vertical. A balance.

22. **haz** — lack, absence, the-not-there. Visual: an empty circle.
    haz is the semantic opposite of san: san is uncountably many, haz
    is zero. In later Faith liturgy haz is sometimes substituted for
    dun (death) in polite contexts.

### Speech, Writing, and Knowing (roots 23–26)

23. **lor** — speak, utter, declare. Visual: the sai glyph (breath) with
    a short horizontal added through the curve. The horizontal is the
    word leaving the mouth.

24. **kai** — write, inscribe, cut-into. Visual: a short vertical with
    a small hook at the top and a second, smaller hook at the bottom.
    kai is the root of kai-thal, "inscription-dwelling," the old-tongue
    name for a library.

25. **sev** — know, see-with-understanding, recognize. Visual: an open
    eye, rendered as a horizontal with a dot above its midpoint and a
    curve below. A compound with haz above sev yields haz-sev, "not-
    knowing," which is Malen's private name for her condition.

26. **ruk** — forget, lose, the-word-that-was-held. Visual: the sev
    glyph with its dot erased — a horizontal with the curve below but
    no dot above. An empty eye.

### Binding, Connection, and Refusal (roots 27–30)

27. **tha** — bind, tie, hold-together. Visual: two short verticals
    joined by a horizontal at their midpoints. The horizontal is the
    tie.

28. **vai** — open, loose, un-bound. Visual: the tha glyph with the
    horizontal tie broken in the middle — two verticals with a gap
    between them.

29. **kel** — refuse, withhold, say-no. Visual: a short horizontal
    with a small vertical crossing it at the left terminal. kel is
    distinct from the prohibitive particle -u (see Part VI); kel is a
    verb ("I refuse"), while -u is a mood marker ("do not").

30. **ish** — join, meet, come-together. Visual: two short diagonals
    that meet at a single point from opposite sides, forming an angle
    like an open mouth turned sideways. ish is the root that the
    linking particle -an- (Part IV) derives from.

## Part III — Compound Formation

Compounds are formed by vertical stacking. The upper glyph modifies the
lower. In transliteration, the upper glyph's form comes first, joined to
the lower by a hyphen.

### The three compound types

1. **Adjectival compound (upper modifies lower as an adjective):**

   - *vel-bren* = unending-body. vel is stacked above bren. The compound
     is a noun meaning "a body that does not end."
   - *kor-thal* = shining-metal-dwelling. kor is stacked above thal. The
     compound is a noun meaning "a dwelling made of shining metal."
   - *kor-nor* = shining-metal. kor above nor. The compound is a noun
     meaning "the metal that shines" — the un-hammerable alloy.

2. **Genitive compound (upper possesses lower):**

   - *ruh-tol* = sky-road. The road belonging to the sky; the cloud-trail
     of the Iron Dragon is so named in bard-song.
   - *gru-bren* = earth-body. A body of the earth; a buried person.

3. **Metaphorical compound (upper transforms lower semantically):**

   - *san-tol* = uncountable-road. Not merely a long road; a road so long
     it cannot be counted. Extended to mean "a road without end" and,
     further, "a continent-wide transit network" in the colonial-era
     sense.
   - *sel-mor* = above-below. This form exists but is rarely used without
     a linking particle (see Part IV); when used alone, it denotes
     *the vertical*.

### Stacking order

The upper-modifies-lower convention is inviolable. There is no
old-tongue compound in which the lower modifies the upper. Where a
modern reader might expect the reverse, the compound is instead written
with a linking particle.

## Part IV — The Five Particles

The old tongue has five grammatical particles. Each is written smaller
than a root-glyph and sits in the lower-right quadrant of the glyph it
modifies.

1. **-a-** — agent/directional particle. Marks the doer of an action, or
   the direction of motion. *ven-a-mor* = "come-from-below" or, with the
   directional reading, "one who comes from below." The First Wave's
   self-designation.

2. **-an-** — linking particle, derived from ish ("meet"). Used to link
   two nouns in a connecting relation where neither modifies the other.
   *sel-an-mor* = "above and below, meeting." Eilin's wall phrase. The
   linking particle is the load-bearing element of the phrase; without
   it, sel and mor together would mean only "above-below" (the vertical
   axis), not "above and below connect."

3. **-i-** — possessive particle. Marks belonging. *thal-i-voss* =
   "dwelling-of-Voss," rendered in Crown liturgy as *the Voss Hall*.

4. **-o-** — locative particle. Marks place-where. *tol-o-gai* =
   "road-at-the-chasm."

5. **-e-** — patient particle. Marks the thing acted upon. *kai-e-bren* =
   "body-inscribed," used in the context of tattoos or ritual scarring.

Particles never carry stress. They are written small and read quickly.
A speaker who lingered on a particle would be understood as either
archaic-in-affect or unsure of their word.

## Part V — Directional and Locative Affixes

Directional and locative affixes are distinct from particles. They attach
to the beginning or end of a root and are written at the same size as
the root, but in a lighter stroke-weight.

Prefix affixes:

- **u-** (upper-directional): "toward the upper." *u-ven* = "come upward."
- **d-** (lower-directional): "toward the lower." *d-ven* = "come downward."
- **k-** (inward): "toward the self." *k-lor* = "speak to oneself."

Suffix affixes:

- **-r** (completive): "to completion." *ven-r* = "fully arrived."
- **-s** (habitual): "as a practice." *lor-s* = "to be in the habit of
  speaking."

In the warning phrase *vel-bren · kor-thal · san-tol · ven-u*, the final
*-u* is not the suffix affix set above. It is the prohibitive mood
marker, which is formally identical in shape to the upper-directional
prefix **u-** but carries a different meaning. Context disambiguates.
(See Part VI.)

## Part VI — The Prohibitive Mood

The prohibitive mood is marked by the particle **-u** attached to a verb.
It is the old tongue's only mood marker. All other modal distinctions —
imperative, optative, conditional — are expressed by particles or by
tone (which, the tongue being unspoken now, is lost).

*ven-u* = "do not come" or "come-not." The prohibitive. The final word of
the Iron-Dragon warning.

*lor-u* = "do not speak." Appears in liturgy.

*sev-u* = "do not see" or "do not look." This is the prohibitive form
that appears in the Crown's Reconstruction C of the Late Bell
transmission: "Do not look at the sky on the nights when the line is
drawn."

The prohibitive is formally identical in shape to the upper-directional
prefix. Eilin's master noted this identity as a deliberate feature of
the tongue, arguing that the prohibitive originally meant "to put away,
upward" — to put the forbidden thing above, out of reach. The modern
reading as a simple negation is a contraction.

## Part VII — Five Example Sentences

Each example is presented with the old-tongue transliteration, a word-
by-word gloss, and a smooth English rendering. The sentences are drawn
from reconstructed fragments, not invented.

### Example 1. From the Third Wave's grammar primer.

> *ven-a-mor bren-i-ast lor-s.*

Gloss:
- ven-a-mor: come-AGENT-below = the one-who-came-up
- bren-i-ast: body-POSSESSIVE-one = one's own body (the self's body)
- lor-s: speak-HABITUAL = is in the habit of speaking

Rendering: *The one who came up speaks with their own body.*
(An idiom. A colonist speaks truthfully, with the weight of having come
up from below.)

### Example 2. From the stone shard's opening line.

> *san-tol ruh-o sev.*

Gloss:
- san-tol: uncountable-road = the road without end
- ruh-o: sky-LOCATIVE = in the sky
- sev: know/see-with-understanding

Rendering: *The uncountable road is seen in the sky.*
(Refers to the straight-line cloud of the Iron Dragon. A warning to
watchers.)

### Example 3. From Eilin's back-wall phrase.

> *sel-an-mor.*

Gloss:
- sel: above
- -an-: linking particle (meet)
- mor: below

Rendering: *Above and below connect.* (上下相通.)
(The inherited wall-phrase at Wolfsjaw. Originally a wayfinding inscription
for the underground transit; later read as a cosmological statement by
those who had lost the wayfinding context.)

### Example 4. From a Faith liturgy (post-muting, a ritualized fragment).

> *sai-u ehn-r.*

Gloss:
- sai-u: breath-PROHIBITIVE = do not breathe / do not voice
- ehn-r: silence-COMPLETIVE = silence to completion

Rendering: *Do not voice. Be fully silent.*
(The opening of a Faith vigil. The liturgists do not know the prohibitive
is a prohibitive; they read it as a name for the rite.)

### Example 5. From a Depth-Walker funeral invocation.

> *d-ven-r tol-o-gai, bren haz.*

Gloss:
- d-ven-r: downward-come-COMPLETIVE = fully descended
- tol-o-gai: road-LOCATIVE-chasm = on the road at the chasm
- bren haz: body absent = the body is gone

Rendering: *Fully descended on the road at the chasm; the body is gone.*
(A Depth-Walker funeral line, reconstructed from Yannic Vello's training
pamphlet.)

## Part VIII — Decomposition of the Named Fragments

This section decomposes the four canonical old-tongue fragments that
appear in the storylines. Each decomposition is exhaustive at the root
level; no root in a fragment is left unlabelled.

### The Iron-Dragon warning

Transliteration:

> **vel-bren · kor-thal · san-tol · ven-u**

Three compound words and one prohibited verb:

1. **vel-bren** = unending (vel) + body (bren) = *unending-body*.
   Meaning: *a body that does not die*. Player-facing gloss: *the flesh
   that does not end*.

2. **kor-thal** = shining-metal (kor) + dwelling (thal) = *shining-metal-
   dwelling*. Meaning: *a hall of shining metal*. Player-facing gloss:
   *the house of the bright stone*.

3. **san-tol** = uncountable (san) + road (tol) = *uncountable-road*.
   Meaning: *a road without end*. Player-facing gloss: *the road that
   cannot be walked to its end*.

4. **ven-u** = come (ven) + prohibitive (-u) = *do not come*.

Full rendering: *Unending body. Shining-metal dwelling. Uncountable road.
Do not come.*

The three compounds are constructed from six root-glyphs: **vel, bren,
kor, thal, san, tol**. The verb adds a seventh: **ven**. The prohibitive
mood-marker adds no root.

### Eilin's wall phrase — sel-an-mor (上下相通)

Transliteration:

> **sel-an-mor**

Decomposition:

- **sel** = above (affix-root, Part V; here functioning as the first half
  of a coordinate pair)
- **-an-** = linking particle (Part IV), derived from the root ish, meaning
  "meet" or "come together"
- **mor** = below (affix-root, functioning as the second half)

Full rendering: *Above and below, meeting.* Commonly translated as
*Above and below connect* (上下相通).

Note the structure: two coordinate locatives (sel, mor) joined by the
linking particle (-an-). This is the only structure in which sel and
mor appear as coordinate nouns rather than as directional affixes. The
linking particle is what transforms a mere axis (*above-below*, the
vertical) into a claim of connection (*above and below meet*). Eilin's
muted paper hinged on this distinction.

### The stone shard (T001)

The shard bears seventeen glyphs across its two faces. A full transcription
is provided in line B's Appendix J. Here, only the root-level analysis
is given.

Roots identified on the shard (counted once each, ignoring repetitions):

- **vel** (twice, on the upper face)
- **san** (once, lower face, lower-right)
- **tol** (once, lower face, lower-right, stacked above san to form
  san-tol)
- **reh** (once, upper face — *great-cliff*)
- **kor** (once, lower face, partial — only the cross-stroke survives;
  Eilin's reading is provisional)
- **thal** (once, lower face, next to the partial kor)
- **sev** (once, upper face)
- **ruh** (twice, upper face, bracketing the four sightings)
- **bren** (once, lower face — paired with vel to form vel-bren)

The shard therefore contains, in intact form, the compounds **vel-bren**
and **san-tol**, which are two of the three compound-words in the
Iron-Dragon warning. The third compound, **kor-thal**, is present only
partially — the kor glyph is damaged and Eilin has not published her
reading.

**Roots shared between the shard and the Iron-Dragon warning** (the
overlap that line E's checker report treats as canon):

- **vel** (clearly visible on the shard; central to the warning)
- **san** (clearly visible on the shard; central to the warning)

(The bren, tol, kor, and thal glyphs are also present on the shard but
only the two above are cited in the checker report as the unambiguous
overlap. The other four are either partial, ambiguous, or the scholarly
reading is disputed. For writer purposes, the load-bearing overlap is
**vel and san**.)

### The colonist crest fragment (Veyl's pocket)

The crest fragment bears the full three-compound warning plus the
prohibitive verb, plus a fourth element: a small **ast** glyph (the
numeral one) enclosed within a **bel** glyph (the numeral four). This
is the four-knot arbitration seal — the "four around one" mark. The
crest identifies Veyl as a bearer of the arbitration line, which in
modern terms means he is a colonial-era liaison between the First and
Second Waves, still carrying his office's mark.

Roots on the crest: **vel, bren, kor, thal, san, tol, ven** (the seven
of the warning), plus **ast** and **bel** (the arbitration mark). Nine
roots in total.

### The Crosser sketch (T004 — *from below, we may rise*)

Transliteration (the sketch's marginal inscription):

> **d-ven-u-r ast-mor.**

Decomposition:

- **d-**: lower-directional prefix (Part V)
- **ven**: come
- **-u-**: here NOT the prohibitive but the upper-directional affix
  (ambiguously rendered on the sketch; Kestrel reads it as upper-
  directional, which makes the whole a reversal-motion verb:
  "come-downward-upward," i.e. "come back up from below")
- **-r**: completive
- **ast-mor**: one-below = "the one from below" or "from a single place
  below"

Full rendering: *Fully returning upward from below, the one from below.*
Paraphrased by Kestrel as: *From below, we may rise.*

This sketch's root-glyph roster:

- **d-** (affix)
- **ven** (shared with the Iron-Dragon warning)
- **u-** (affix — the ambiguous one)
- **ast** (shared with the colonist crest's arbitration mark)
- **mor** (shared with Eilin's wall phrase)

The sketch shares three root-glyphs with the stone shard (the shard has
**ven** in one line not detailed here, and **mor** appears on the shard's
lower face in a passage Eilin has only partially read; together with
**ast**, these three overlap). This is the three-glyph overlap between
sketch, shard, and wall that line E's checker report canonizes.

## Part IX — What the Tongue Will Not Say

The old tongue, as reconstructed, has no words for the following
modern-vocabulary concepts. Writers must never supply these words in
indigenous form:

- No word for *machine* distinct from *built-thing* (thal covers both).
- No word for *flight* distinct from *sky-motion* (which would be
  ven-ruh, and which does not appear in any surviving fragment).
- No word for *alloy* distinct from *shining-metal* (kor-nor, or kor
  alone in extended use).
- No word for *electricity*, *engine*, *transmission*, *signal*. The
  distant-voice stones have no old-tongue name in any surviving
  fragment; they are referred to obliquely, by function or by color.
- No word for *continent*, *nation*, or *empire* distinct from *land*
  (which would be a mor-gru compound, not attested).
- No word for *death-by-machine* or *system-failure*. The tongue's
  speakers did not, in the surviving texts, admit that such things were
  possible.

The absence of these words is itself a tool. A writer who needs to
indicate the far side's technological character must do so through
indigenous sensory language — the warning phrase is the model — and
never by coining a new compound.

## Part X — Reconstruction Notes

Eilin's reconstruction draws on the Limewash rubbings (~40y ago), the
stone shard (surfaced ~3y; seen twice through Septon Silas), her
master's field-notes with fragments of the Third Wave's grammar primers,
the monastery's back-wall phrase, and rubbings of the colonist crest
that Kestrel has shown her twice. She has not seen the Guild's Buried
Charter, the Crown's sealed folio, or any distant-voice stone.

The thirty roots above are the ones for which she has at least three
independent attestations. At least six further candidate roots have only
one attestation each and are not yet canon; Vossel the Younger keeps
their drafts in his private codex.

## Part XI — For the Next Writer

- The thirty roots are the roster. Do not add new roots without anchoring
  them to a storyline fragment and coordinating with line B.
- The five particles are the particles. The five affixes are the affixes.
  The one prohibitive mood is the prohibitive mood. Do not add more.
- Every old-tongue fragment that appears in a player-facing text must
  decompose cleanly into this document's roster. If it does not, it is
  not old tongue; it is corruption, mistranscription, or a forgery.
- The warning phrase *vel-bren · kor-thal · san-tol · ven-u* is fixed.
  Do not rephrase it.
- Eilin's wall phrase *sel-an-mor* is fixed. Do not rephrase it.
- The shard's ambiguous glyphs (partial kor, contested thal) remain
  ambiguous. Do not resolve them.
- The tongue is dead. Do not allow any NPC to speak it fluently. Eilin
  reads it. Her master read it. Kestrel reads fragments. Corvin reads
  what the Buried Charter transcribes. No one else.

The old tongue is the load-bearing archaeological evidence of the Reach's
buried origin. It is preserved in this document at exactly the level of
detail required for the five storylines to cohere, and no deeper. The
deeper detail — what the tongue sounded like, how its speakers argued,
what they meant when they wrote *ven-u* on a crest and sent it up —
belongs to the far side, and the far side is dead.
