# The True History of the Grey Reach

> Foundation lore. This document contains the buried history of the four
> northern kingdoms. Most of its contents would, if spoken aloud in Mistmere,
> Windrest, Jadehollow, or Stoneford, be treated as heresy, sedition, or the
> raving of a mad returnee. Only fragments of it survive in the hands of kings,
> of one high archivist, of one muted maester, and of one grey-coated stranger
> who calls himself Veyl.
>
> Player-facing text in this document uses only indigenous vocabulary: *the
> far side, the long road, the unending-body, the singing forge, the house
> that flew.* Writer-only notes — clearly marked — may use modern words to
> anchor the mechanics for future writers.

## Part I — The Four Waves

The kingdoms of the Grey Reach descend from four successive arrivals of
colonists from the far side of the Great Chasm. The arrivals came not across
the Chasm but up through it, from below — along what the Crossers will later
call *the long road*, and what modern Crown archives call, in a single
indirect phrase, *the ascent*. Each wave came two generations or so after the
previous, and each brought a different purpose. Each founded, or seeded, one
of the four crowns.

### The First Wave — the Crown-line

The First Wave arrived roughly four centuries before the present day, in a
season the oldest Crown archive at Mistmere calls **the Long Thaw** —
remembering that it was the first spring the newcomers saw on this side, and
the thaw seemed to them so long that they took the word for their age.

They were fewer than three hundred. They carried:

- a charter in the old tongue, inscribed on nine thin sheets of pale metal;
- a cask of the amber tea that would become the Crown's private ration;
- a set of distant-voice stones, of which the Crown retains seven;
- the un-hammerable metal in unworked ingots, for the founding of a dynasty's
  armoury;
- and a banner, long lost, which is said to have carried a crest of nine
  dots around a tenth — the arbitration mark the Northern Guild would later
  adopt and the Crossers would later imitate.

The First Wave settled at the confluence that is now Mistmere and founded
what would become the **Crown of Voss**. They did not call themselves
colonists. They called themselves **the ones-who-came-up**, *ven-a-mor* in
the old tongue. The modern Crown phrase for its own origin, *the old rising*,
is a direct descendant.

<!-- writer-only
The First Wave corresponds, in modern vocabulary, to an initial scientific
and administrative expedition from the far-side civilization: a governance
cadre sent to establish a viable mirror-settlement during what appears to
have been a climate or political crisis on the far side. The "pale metal
sheets" are a durable alloy data tablet. The amber tea is a longevity
compound. The distant-voice stones are communication devices keyed to a
relay on the far side. The un-hammerable metal is a structural alloy. None
of this vocabulary is ever used in-world. The First Wave believed — rightly
— that their children would forget.
-->

### The Second Wave — the Faith-line

The Second Wave arrived approximately seventy years after the First — roughly
three hundred and thirty years before the present day. They were larger than
the First Wave: somewhere between five and seven hundred souls, including a
cadre of twelve who carried the robes of what would become the Faith.

They came during what Mistmere's oldest undercroft stone calls **the First
Silence** — a period of roughly twenty years during which no new wave arrived
and the First Wave began, for the first time, to fear that the far side had
forgotten them. The Second Wave broke that silence. They were welcomed as
kin. They were also received with a caution the First Wave never fully
explained.

The Faith-line brought:

- liturgy in the old tongue, now almost entirely lost except as fragmented
  cadence in Septon prayers;
- a large number of the distant-voice stones — of which the Faith retains,
  unknowingly, more than any other crown;
- doctrine concerning the sky, the sun, and the properness of looking up
  rather than down;
- the four-knot arbitration seal, which at that point was still in use as
  a practical device for sealing official correspondence.

The Faith-line settled south and west of the First Wave and founded what
would become the **Faith of Mistmere**, now headed by High Septa Malen the
Unsleeping. Malen does not know her own lineage. She inherited her distant-
voice stones from her predecessor, who inherited them from hers, and so on
through eleven generations. She has been told the stones are relics of
sanctity. She has not been told what they are for.

<!-- writer-only
The Faith-line corresponds to a religious or post-religious cadre sent as
social infrastructure: doctrine-builders tasked with giving the growing
colony a shared moral language. The twelve Faith-founders were likely
chosen for rhetorical skill rather than theological literacy. Their
"liturgy in the old tongue" was, originally, a mix of civic oaths and
operational manuals, ritualized over three generations into prayer. The
distant-voice stones given to the Faith were the largest single shipment
because the far-side sender believed a religious order would be the most
reliable long-term custodian of communications infrastructure. This was, in
hindsight, correct.
-->

### The Third Wave — the Free North-line

The Third Wave arrived approximately one hundred and sixty years after the
Second — about one hundred and seventy years before the present day. They
were the smallest of the four waves: fewer than two hundred souls. They came
during a season the far side had evidently begun to ration its ascents, and
they arrived not as a governance cadre, not as a doctrinal cadre, but as
what modern vocabulary would call *refugees*. The in-world memory of the
Third Wave is kept only by the Free North's ruling line, through a recitation
that the Chieftess of the day delivers once to her heir and never again.

They brought:

- the pale inlaid metal for armour-work, in unworked sheets, which the Free
  North's smiths would later learn to inlay but never to hammer;
- a smaller cask of the unaging tea, already rationed by their own council
  before they departed;
- a set of field-texts describing the old tongue's grammar, of which
  fragments survive in the Greyhold line's private library at Bonehollow;
- and the memory — the simple, unambiguous memory — that *we came from the
  other side*.

The Third Wave settled in the high north-west, among the scree and the
wind-scraped plateaux that the First and Second Waves had declined to
contest. They founded what would become the **Free North**, now led by
Chieftess Brenna Greyhold. Brenna remembers the coming-up. She has not told
her clans. She will not tell her clans. This is her refusal, and her grief,
and her grandmother's instruction.

<!-- writer-only
The Third Wave corresponds to the last cadre sent out of apparent goodwill:
a displaced population fleeing a political or environmental deterioration
on the far side. Their ration-before-departure of the unaging compound, and
their carrying of grammar primers rather than operational manuals, suggests
they expected a long separation and wanted to preserve the tongue. They
knew, or suspected, that further waves would be rare.
-->

### The Fourth Wave — the Union-line

The Fourth Wave arrived approximately fifty years after the Third — about
one hundred and twenty years before the present day. They were the largest
of the four: possibly a thousand souls, possibly more. They came not as
governance, not as doctrine, not as refugees, but as what modern vocabulary
would call *commercial operators*.

They brought:

- lots and lots of small, manufactured objects of uncertain purpose, most
  of which have, by the present day, been sold and resold through the
  continental markets as *antique foreign manufacture*;
- a small number of the distant-voice stones, none of which the Union has
  kept — they were all sold to private collectors within two generations;
- no written history, no grammar, no liturgy;
- and a charter of trade, written in the common speech of the day, which
  would become the founding document of the **Union of Saltmouth** under
  Consul-Merchant Tobiah Caul.

The Fourth Wave did not treat itself as a colonial generation. It treated
itself as a trading fleet that had happened to arrive at a promising
harbour. Its children married out widely. By the second generation after
arrival, nothing of the old tongue survived in Union houses. By the third,
nothing of the colonial memory survived either. Consul-Merchant Tobiah Caul
is the fourth-great-grandson of a Fourth-Wave quartermaster. He does not
know this. He has sold, in the last nine years, at least forty relics from
his family's own storehouse, believing them to be antiques from the
continental interior.

<!-- writer-only
The Fourth Wave corresponds to a commercial and logistical cadre — the
final scheduled ascent before contact was lost. Their casualness about the
colonial origin reflects a far-side assumption that contact would continue
indefinitely. It did not. The Union's loss of memory is not a suppression.
It is simple commercial turnover: a trading house with a ninety-year life-
cycle will forget anything not written into its ledger, and the Fourth
Wave's ledgers recorded only prices.
-->

## Part II — The First Century

For the first century after the Fourth Wave, contact between the far side
and the Grey Reach continued, though at diminishing frequency. The last
confirmed ascent of a small party from the far side occurred approximately
one hundred and twenty years before the present day — two years after the
main Fourth-Wave arrival, and led by what a Crown archive calls *the
quartermaster-under*. After that, no further ascents occurred.

Distant-voice transmissions continued for roughly another two decades.
Crown archivists record that the last confirmed transmission was received
at Mistmere **one hundred and one years before the present day**, in the
season the Crown called **the Late Bell**. The content of the transmission
is not recorded. What is recorded is that the Crown of the day — King
Voss the Seventh — was present at the reception, and that he emerged from
the reception-chamber with his hands trembling, refused wine, refused food,
and retired without speaking. He sealed the reception-chamber with a new
lock of his own design, and the key went with him into his grave nine
years later.

His successor — King Voss the Eighth — unsealed the chamber on the day of
his accession. He found, on the table, the distant-voice stone that had
received the last transmission, and beside it a single written line, in his
grandfather's hand:

> *They have told us not to come. They have told us not to look. Do not
> ask what we have done to deserve this.*

This note is the earliest Crown acknowledgement of the content of the last
transmission, and it is the basis of the Crown's interpretation of the
hundred-year silence: *the far side has forbidden us*. The note is held
today by Darrik Voss in a reliquary at Mistmere. He reads it once a year,
on the anniversary of his own accession, and replaces it.

<!-- writer-only
The Crown's interpretation — that the far side has forbidden us — is one of
two possible readings of the hundred-year silence. The other reading,
privately held by Darrik's more paranoid advisors, is that the far side has
collapsed and that the final transmission was automated: a last warning
routed through a failing system. Neither reading is confirmed in-world. The
true situation is that the far-side civilization is in fact dead, and the
final transmission was a pre-recorded warning triggered by their own
dying infrastructure. The "iron dragon" that the Grey Reach will later see
returning is not a returning representative. It is a drone, or similar
artefact, that was set on a long orbit or cycle and has only now come
around again. But this is all writer-only. The game never confirms.
-->

## Part III — The Hundred Years of Silence

The century since the last transmission is, in in-world memory, the period
called **the Hundred-Year Hush** or, more formally in Crown records,
**the Great Quiet**. Its first decade — the years immediately following the
Late Bell — was a period of active grief and active denial among the ruling
line. The Crown's position stabilised only under Voss the Eighth, who
established the mutual cover story that binds the four crowns to this day.

The cover story, in its operative paragraph, reads (Crown copy, Mistmere
archive, sealed):

> *The four crowns are kin. The four crowns will not name what lies beyond
> the cliff. The four crowns will not name what lies beneath the road. The
> four crowns will not seek the far side, and will not permit their
> subjects to seek it. In recompense, the four crowns will share what the
> cliff and the road have, through accident or through labour, surrendered
> up.*

The surrender-up — the *accident-or-labour* — is the reason that the four
crowns today possess a secret mining operation beneath the Chasm. Relics,
recovered from the underground, are distributed among the four courts
according to a schedule that the Crown and the Free North negotiate yearly
and that the Faith and the Union are simply told about. The Faith receives
the stones that *whisper* and does not know they are communications devices.
The Union receives, when given anything, small decorative objects. The
Crown takes the tea and the armour-metal. The Free North takes the
armour-metal and the grammar-scraps.

The operation is run, on the ground, by the **Depth-Walkers** — specifically
by the **Listeners**, the wing of the Depth-Walker order that is secretly
under royal contract. Archdepth Sula is the chief contracted miner. Her
contract is in her desk at Mistmere, and High Septa Malen has never seen it,
and Consul-Merchant Tobiah has never heard it exists.

<!-- writer-only
This is motive 6 of the 2+5+6 royal hiding-stack: resource monopoly. Relics
give the Crown and Free North a material advantage — unaging tea, un-
hammerable metal, distant-voice communication — that the other crowns
either use in ignorance (Faith) or lack entirely (Union). Admitting the
colonial history would end the monopoly. This is not the Crown's primary
reason for concealment, but it is the primary operational consequence.
Line E's Critical scene — Sula's confession — is the moment this monopoly
is made visible to the player.
-->

## Part IV — The Fog

The Fog is a consequence, not a natural feature.

It is not the fog of the Great Chasm itself, which is older and which is
genuinely atmospheric. The Fog of the Grey Reach — the grey-green wool
that rolls off the Shale and that rolls into Stoneford before the player
arrives — has intensified measurably over the last century. The Crown has
no stated explanation. The Faith teaches that the Fog is the veil of
penitence laid over the world by the Silent Saints to hide the far side
from the eyes of the unworthy. The Free North teaches nothing about the
Fog; the Free North treats the Fog as weather. The Union treats the Fog as
a nuisance that affects harbour pricing.

The Fog's actual cause is disputed even in Crown archives. The three
serious Crown hypotheses are:

1. **The Mirror Hypothesis:** the far side's civilization, in dying,
   released into the Chasm some residue — a persistent airborne by-product
   — that the prevailing winds now carry south into the Reach. The Fog is
   therefore a marker of the far side's *death*, not of its life, and the
   Fog's intensification over the last century is the long tail of a
   continuing collapse.

2. **The Doused Hypothesis:** the far side, before going silent, deliberately
   seeded the Chasm with the Fog as a barrier — a warning made weather —
   to prevent further ascent. In this reading, the Fog is an act of will,
   not of accident, and the warning fragment (永生 × 黄金 × 无穷, do not
   visit) refers to the Fog as much as to the far side itself.

3. **The Below-Hypothesis:** the Fog is a respiration of the long road —
   the underground passage between the two sides — and its intensification
   reflects increasing activity below, not decreasing activity above.
   Kestrel's Crossers hold this view, privately, and it is the reason they
   believe the ascent is still possible.

No Crown archivist endorses any of the three hypotheses in writing. Each is
discussed only in marginalia.

<!-- writer-only
The true mechanism is closest to hypothesis 1 combined with a small
component of hypothesis 2: the far side released a long-lived airborne
marker (likely a self-replicating particulate of some kind, or a slow-
release chemical agent) during its final stabilization attempts. Some of
this release was accidental — industrial, residual — and some was
deliberate — they wanted to prevent their dying-body disease from reaching
the colonies. The net effect is the Fog: neither pure accident nor pure
barrier, and genuinely intensifying as the last of the far-side
infrastructure decays. The Fog is not poisonous to ordinary humans. It is
mildly disorienting. It carries, for a traveller who stays in it too long,
a quality that later chroniclers will call *the Fog-thought*: a slowness
of mind that feels like being politely refused.

The Fog arrived and intensified not because of any single event but as the
long-decay residue of a civilization's dying. It will continue to thicken
for another two or three centuries before beginning, very slowly, to
dissipate. The game does not say this.
-->

## Part V — Dated Events

This is the master dated timeline, relative to the present day (year 0).
It is consistent with every date stated in the five storylines. Where a
storyline states a round number, that number is preserved here; where a
storyline states a range, the midpoint is used.

| Year (before present) | Era name | Event |
|----|----|----|
| ~400 | Long Thaw (begins) | First Wave (Crown-line) arrives. Founds what will become the Crown of Voss. |
| ~330 | First Silence (begins) | Twenty-year gap after First Wave; no new ascents. |
| ~330 | First Silence (ends) | Second Wave (Faith-line) arrives. Founds what will become the Faith of Mistmere. |
| ~300 | Long Thaw (ends) | The city beneath what is now Mistmere is in full flower. Pre-Faith, pre-royal, built by First and Second Wave together. The script of the shard is a living hand. |
| ~280 | The Middle Bright | A period of active inter-wave governance. The four-knot arbitration seal is adopted. |
| ~170 | The Slow Forgetting (begins) | Third Wave (Free North-line) arrives. Founds what will become the Free North. |
| ~120 | The Slow Forgetting (continues) | Fourth Wave (Union-line) arrives. Founds what will become the Union of Saltmouth. |
| ~120 | The Shoulder | The monastery at Wolfsjaw is built atop the surviving shoulder of the older city's precinct. The rear wall's carving **sel-an-mor** (*上下相通*, above-and-below connect) is inherited, not carved by the monks. The monks whitewash it. |
| ~118 | The Last Ascent | Final confirmed small-party ascent from the far side. Led by the quartermaster-under. |
| ~101 | The Late Bell | Final confirmed distant-voice transmission. Voss the Seventh receives it. The content is suppressed. |
| ~100 | First Silence of the New Age (begins) | Contact with the far side ceases. The Hundred-Year Hush begins. |
| ~92 | The Cover | Voss the Eighth formalises the four-crown cover story. Faith and Union are enrolled on separate terms; Free North under Chieftess Greyhold's great-great-grandmother signs under duress. |
| ~80 | The Ashford Sinking | The Ashford estate at Mistmere sinks partially into the ground. The Mossbarrow is exposed as a cellar older than the house. The Ashford line breaks. |
| ~60 | The Long Descent (begins) | Founding of the Depth-Walker order. Initial form: a commoner mystical practice, not yet royal-contracted. |
| ~40 | The Limewash | The cathedral undercroft is limewashed for the first time under Reynard's predecessor. Two rubbings of pre-Faith columns are taken and smuggled north; they reach Eilin's master. |
| ~30 | The Listener Contract | Archdepth Sula, then a young miner, signs the first Listener-Crown contract. Secret royal funding of Depth-Walker mining begins. |
| ~20 | The Shepherd's First Sighting | Old Shepherd Bram, as a younger man, sees the straight line in the sky for the first time. He tells a Faith brother. The Faith brother tells a Crown archivist. The Crown archivist tells the Guild. Nothing further is done. |
| ~11 | Eilin's Muting | Maester Eilin of the Wolfsjaw monastery circulates a draft paper proposing a linguistic kinship between the words *reh* (cliff) and *gai* (chasm). The Crown and Faith jointly order her muted. The Northern Ban is drafted. The knife is done in the monastery infirmary. Abbot Merick holds her hand. |
| ~11 | The Northern Ban | The Northern Guild's Magister of the day — not Corvin; his predecessor — formalises the Ban as Guild policy. The Ban's operative paragraph quotes the stone shard's script without attributing it. |
| ~9 | The Crosser Split | Navigator Kestrel, then a senior Listener, breaks with Archdepth Sula over the royal contract. The Crossers are founded. They begin acquiring engineering knowledge and illicit colonial records. |
| ~9 | The Ashford-Reed Accession | Corvin Ashford-Reed becomes Grand Magister of the Northern Guild. Reads the Buried Charter for the first time. Has not slept a full night since. |
| ~8 | The Second Sighting | Bram sees the straight line for the second time. Reports it to the Guild. The Guild pays him a stipend and asks him to sign a retraction. He signs. |
| ~3 | The Shard's Surfacing | Septon Silas, walking the old mine road north of Stoneford, finds the stone shard wedged under a flat stone at the ford. |
| ~3 | The Vossel Arrival | Preceptor Vossel the Younger arrives at the Wolfsjaw monastery as a novice. Begins secretly transcribing Eilin's gestures into a private codex. |
| ~2 | The Third Sighting | Bram sees the straight line for the third time. Does not report it. The Guild knows, via a Faith courier, and doubles his stipend anyway. |
| ~1 | The Dragon-Coat Stranger | A grey-coated stranger calling himself Veyl passes through Windrest, watches the sky at dawn as if counting, asks the way to Mistmere. No one yet connects him to anything. |
| 0 | Present | The player arrives in Stoneford. The road ends here. |

## Part VI — The Four Royal Lines, as They Stand Today

### Crown of Voss — Darrik Voss

Darrik Voss is the fourteenth of his line. He knows, in rough outline, the
content of the Late Bell transmission, because he has read his grandfather's
note. He knows the four waves. He knows the long road exists. He does not
know whether the far side is dead or merely forbidden; he has decided,
privately, to act as though it is dead and to prepare as though it is
merely forbidden. He drinks the amber tea. He wears the colonist crest on
his pectoral, hidden under his public sigil.

### Faith of Mistmere — High Septa Malen the Unsleeping

Malen does not know the colonial history. She was not told by her
predecessor, who died of a fever before the instruction-conversation could
be completed. Malen inherited the distant-voice stones as *relics of
sanctity*, and she holds one to her ear at night because it calms her. She
has not slept a full night in ten years. She believes the Hundred-Year
Hush is a divine abandonment — that the Silent Saints have withdrawn their
voices, and that the world is being tested for some impiety it has not
yet named. She is terrified and pious in roughly equal measure.

### Free North — Chieftess Brenna Greyhold

Brenna knows. She was told by her grandmother, on the night of her
grandmother's death, in the single instruction-conversation that the Free
North's oral tradition requires. She has not told her own daughter yet.
She will, when the time comes. She wears armour inlaid with the pale metal
her line has never learned to hammer, and she lets her clan-smiths
believe it is a ritual honour rather than a practical limitation.

### Union of Saltmouth — Consul-Merchant Tobiah Caul

Tobiah knows nothing. His merchant-house has sold, in his lifetime alone,
at least forty relics through its catalogue, most for comically small
sums. He has in his private collection twelve brass cups of *antique
foreign manufacture* which are in fact relic-vessels. Brenna will, at the
Mistmere summit, tell him to melt them down. He will not understand why.
He will do it anyway, because Brenna is not a woman one argues with, and
because his house has survived four generations by obeying, late, the
warnings of those more serious than itself.

## Part VII — On the Relics Being Underground

The central paradox of the Grey Reach is that the relics of the far side —
which ought, by any naive geography, to be *across* the Chasm — are found
*beneath* it. The four in-world theories (per the shared brief) are all
partial, all canon-as-opinion, and none is confirmed:

1. **King's Archivist theory:** a portion of the far side was buried in the
   collapse. This theory's strongest witness is the pre-Faith city beneath
   Mistmere, whose columns and foundation stones are visibly older than
   any above-ground work and whose architecture is not local.

2. **Kestrel's theory:** colonial-era transit ran underground — the long
   road — not across. The Chasm was never the real road. This theory's
   strongest witness is the rubbed inner face of Mistmere's harbour-wall,
   whose glyphs were carved to be read from *inside* a passage, not from
   outside a wall.

3. **Hallen's theory:** *below and beyond are one. The floor is the far
   wall.* This is held by most NPCs to be the raving of a man whose mind
   broke in the Mossbarrow. It has the inconvenient property of being, on
   a generous reading, consistent with the other three theories combined.

4. **Eilin's theory:** *above and below connect.* Written in glyphs, not in
   speech. The strongest witness to this theory is the phrase itself,
   inherited from a wall older than the Faith.

The true state of affairs is closer to theory 2 with theory 1 as a minor
component: the colonial transit ran underground, and some sections of the
far-side settlement were built directly into the Chasm's substructure and
are therefore, from the Reach's perspective, *underneath* rather than
*across*. The city beneath Mistmere is partly an actual buried far-side
outpost and partly a first-generation colonist construction on top of that
outpost. The two are now indistinguishable to anyone but Eilin, and Eilin
cannot speak.

<!-- writer-only
For future writers: the four theories are preserved as permanently
unresolved. If a later storyline is ever tempted to resolve them, resist.
The ambiguity is load-bearing. Eilin's theory is the nearest to correct on
a literal reading but the wall-phrase was originally a wayfinding
inscription for the colonial transit, not a cosmological statement. The
cosmological reading is a drift. The drift is canon.
-->

## Part VIII — What the Royals Were Told vs. What They Inferred

The content of the Late Bell transmission — the last message from the far
side — has never been written in full. Voss the Seventh's single-line
summary is the only record. But Crown archivists have, over the last
century, attempted three reconstructions. All three are held in a single
sealed folio at Mistmere. Darrik Voss has read the folio. Corvin
Ashford-Reed has read a copy. No one else alive has.

Reconstruction A (the Abandonment reading):

> *The far side is ending. We cannot send more. Do not attempt to come up.
> The road below will be unsafe for generations. Live well without us.*

Reconstruction B (the Prohibition reading):

> *The far side will not receive you. Do not come. Do not look. Do not
> build toward us. The warning is final.*

Reconstruction C (the Danger reading):

> *Something that was ours is now not. It will seek you, if you seek us.
> Do not seek us. Do not look at the sky on the nights when the line is
> drawn. Close your lanterns. Do not visit.*

The three reconstructions are not reconciled. Darrik Voss operates as
though all three are simultaneously true. He is, in this, correct, but he
does not know he is correct.

<!-- writer-only
Reconstruction C is the closest to the actual content of the Late Bell
transmission. The "something that was ours is now not" is, in modern
vocabulary, autonomous infrastructure that outlived its operators — drones,
reconnaissance craft, possibly defensive systems — that continue to
function on pre-programmed cycles. The Iron Dragon of line D is one such.
It was not sent to return. It returns because its cycle brings it back. It
is not hostile in any intentional sense. It is, however, dangerous in the
way any unsupervised heavy machinery is dangerous.

Reconstruction A is what the Faith would believe if the Faith knew there
was anything to believe. Reconstruction B is what the Free North believes.
Reconstruction C is what the Crown privately fears. The convergence of the
three readings — the actual Late Bell content — is known to no one in-world.
-->

## Part IX — On the Phrase *Eternal-life × Gold × Infinity. Do not visit.*

The warning fragment, as it survives in the Iron-Dragon legend and as it
is transcribed on the colonist crest fragment in Veyl's pocket, is a
three-compound-word phrase in the old tongue followed by a negated verb:

> **vel-bren · kor-thal · san-tol · ven-u**

Literally:
- **vel-bren** — unending-body (eternal-life)
- **kor-thal** — shining-metal-dwelling (gold, in the sense of metal-
  architecture, tall buildings of precious alloy)
- **san-tol** — uncountable-road (infinity, in the sense of a road without
  end, a continent-wide system)
- **ven-u** — do-not-come (literally *come-not*; the suffix *-u* is the
  old tongue's prohibitive)

The three roots `vel`, `kor`, and `san` are the compositional anchors of
the warning. They recur across almost all surviving fragments of the old
tongue. The stone shard carried by Septon Silas contains at least two of
them (`vel`, `san`) in visible form; the colonist crest in Veyl's pocket
contains all three. This is the *shared root* that Eilin's master
recognised and that Eilin herself has spent her working life corroborating.

The phrase's meaning, in the reading the colonist crest carries:

> *Bodies that do not die. Cities of shining metal. A road without end.
> Do not come.*

A commoner hearing this phrase will hear, depending on the telling:
*a paradise that is forbidden*, *a curse that sounds like a promise*,
*a warning scraped onto the door of heaven*. The phrase is never delivered
in modern vocabulary. The old tongue is the warning; the warning is the
old tongue.

<!-- writer-only
The three compound words, decoded in modern vocabulary:
- vel-bren = undying bodies = cryogenic preservation / prosthetic bodies
  / some combination of life-extension technologies
- kor-thal = shining-metal dwellings = high-rise buildings of structural
  alloy (what our world would call steel-and-glass skyscrapers)
- san-tol = uncountable road = a continent-wide transit network, or a
  fully developed settled continent (no wilderness)

The warning is, in modern vocabulary: *we have bodies that do not die, we
live in towers of alloy, we have filled the continent with roads, and
something about all of this has gone wrong enough that you must not come.*
The "gone wrong" is not named because the far side, in drafting the
warning, could not name it without giving away capability. They left the
warning as three admissions and a prohibition.

Player-facing text must never use cryogenic, alloy, skyscraper, continent,
transit network, etc. Only the old tongue and its sensory glosses.
-->

## Part X — Writer Consistency Notes

This document is consistent with:

- `_SHARED_BRIEF.md`: the hidden premise, the four-crown stack, the 2+5+6
  royal motive, the Depth-Walker split, the fragment inventory, the four
  theories of relic-burial.
- `beyond-the-world.md`: the Iron Dragon fragment wording, the Depth-Walker
  funeral saying, the Chasm geography.
- `A-guild-buried-charter.md`: the Guild founded two centuries ago, the
  Northern Ban drafted eleven years ago, Olric dead two hundred years ago
  at T003, Corvin's nine-year Magistry.
- `B-world-before-the-fog.md`: 300y city standing, 200y city buried, 120y
  monastery built, 100y contact ceases, 80y Ashford sinking, 40y limewash,
  11y Eilin muted, 3y Vossel, 3 seasons shard surfaces.
- `C-four-crown-intrigue.md`: the four-knot arbitration seal, Brenna's
  armour, Malen's insomnia and distant-voice stone, Tobiah's twelve
  cups, the Jade Compact.
- `D-iron-dragon-returns.md`: nine generations = ~100y silence, Veyl's
  year-ago passage through Windrest, the three straight-line-cloud
  sightings over Bram's life, Corvin's royal orders on the crest fragment.
- `E-depth-walkers.md`: Sula's forty-year rope-hands (began mining at 21),
  thirty-year Listener contract, nine-year-ago Crosser split, Kestrel's
  theory of the under-road.

Where a storyline states a round number and this document gives a slightly
more precise figure (e.g. storyline B says "roughly 120 years ago" and
this document uses ~120), the round number is preserved in the timeline
column and the precise figure is used only where arithmetic requires it.

No date in this document contradicts any date stated in any storyline.
Two apparent tensions were reconciled in drafting:

1. **Guild founding vs. Olric's grave.** Line A states the Guild was founded
   "two centuries ago" and that Keeper-Commander Olric has been dead 200
   years. These are consistent: Olric was a founding Keeper-Commander, and
   his death roughly coincides with the founding generation's passing. The
   grave at T003 predates the monastery's rear cloister by about eighty
   years; the cloister was built around the grave, not the other way
   around.

2. **Nine generations of silence vs. 100 years.** Line D's Veyl recites
   the hundred-year silence as "nine generations." At roughly 11 years per
   generation — which is unusually short and reflects the brevity of
   Depth-Walker accession cycles rather than human generations — this is
   99 years, consistent with the ~100-year figure. The short generational
   count is noted in the _CHECKER_REPORT.md and is treated as canonical.

## Part XI — For the Next Writer

If you are extending this document:

- Do not resolve the four theories of burial.
- Do not name the far side's technology in modern vocabulary in any
  player-facing block.
- Do not invent new waves. Four waves is the count. Further arrivals are
  splinter parties, not waves.
- Do not decipher the old tongue further than this document does. The
  `old-tongue.md` file is the canonical roster; do not add roots to it
  without matching them to a storyline's fragment.
- Do not give any of the four kings more knowledge than is listed here.
  Darrik knows the most; Malen knows the least; Brenna knows in the
  middle; Tobiah knows nothing.
- The Fog does not lift. Do not write a scene in which the Fog lifts. The
  Fog is a century-scale feature. The game's timescale does not include
  its end.

That is the whole of the colonial history. What survives of it, in the
present, is scattered across four courts, one monastery, one mine, one
library, and one grey-coated stranger's inner pocket. The rest is rumour,
liturgy, and the patience of one woman at the Wolfsjaw monastery who
cannot speak and who has been, for eleven years, the only person in the
Reach who understands what she is looking at.
