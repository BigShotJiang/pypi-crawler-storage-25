# Eras and Chronology of the Grey Reach

> A master timeline of the north, anchored to the present day (year 0, the
> season the player arrives at Stoneford). This document is the arithmetic
> spine of the setting. Where a storyline quotes a round number and this
> document quotes a slightly more precise number, both are canon; the round
> number is what a tavern-keeper would say, the precise number is what a
> Crown archivist would write.
>
> Every date here is consistent with `colonial-history.md`, with
> `mythology.md`, and with the five storylines A through E. Ages are named
> from the in-world memory of the age, not from the outside view. The names
> are the names the people of the time gave themselves, and in some cases
> they are the names later generations imposed retroactively.

## How the Reach Counts Years

The Grey Reach has no shared calendar. The four crowns keep four different
year-counts, and the commoners keep a fifth:

- **Crown of Voss (Mistmere)** counts from *the First Thaw* — the season the
  First Wave arrived. A Crown archivist's year-date is, today, *in the
  four-hundred-and-second spring since the First Thaw*. Commoners never
  hear this count.
- **Faith of Mistmere** counts from *the First Bell* — the first ringing of
  the reliquary bell that High Septon Annec (second of that name) struck
  to open the Faith's founding synod. This count places the present day at
  *year 328 of the Bell*.
- **Free North (Bonehollow)** keeps no numerical count. Clans reckon by
  generations of the ruling line. Brenna Greyhold is the *eleventh
  mother-chief* of Bonehollow. The present day is *the eleventh weaving*.
- **Union of Saltmouth** counts from the founding charter of the Saltmouth
  Merchants' Union, which places the present day at *year 118 of the Ledger*.
  The Union's calendar is the only one in the Reach that keeps a 365-day
  year with leap-correction. The Union does this because shipping contracts
  require it.
- **Commoners** count by seasons and by the reigns of the nearest lord. A
  Stoneford fisherman will say *the fifth summer of Darrik, the third
  after the long rains*. Nothing more.

This document uses **year-count before-present** (the shorthand "~120y"
meaning "approximately one hundred and twenty years before the present").
No in-world speaker uses this shorthand. It exists only for the orchestrator.

## The Ages, in Order

There are seven named ages in the long count of the Reach. They overlap.
Each was named by its own generation or the generation after, and the
names are not always flattering.

### Age I — The Long Thaw (~400y to ~300y before present)

The Long Thaw is the in-world name for the first century of colonial
settlement. It begins with the arrival of the First Wave, the Crown-line,
at the confluence that is now Mistmere. It ends approximately one century
later, when the pre-Faith city beneath Mistmere reached its full flower.

The Long Thaw was, in its own self-account, a season of *coming up from the
cold*. The First Wave called itself *ven-a-mor*, *the ones-who-came-up*.
That phrase is still preserved in Crown liturgy as *the old rising*, though
its literal meaning is no longer taught.

The Long Thaw is also the age of the First Silence: a twenty-year gap
(roughly 330y before present) when no new arrivals came up from below, and
the First Wave first learned that contact could fail. The Second Wave
ended that silence. The First Silence is therefore a sub-era inside the
Long Thaw, not a separate age.

Notable events within the Long Thaw:

- **~400y:** First Wave arrives. Mistmere founded.
- **~330y:** First Silence begins (twenty-year gap).
- **~330y (ending):** Second Wave arrives (the Faith-line). First Silence
  ends. The Faith is founded.
- **~300y:** The pre-Faith city beneath Mistmere is in full flower. Its
  columns, foundations, and inscriptions are the work of the First and
  Second Waves together. The script of the stone shard at T001 is, in this
  age, a living hand — a working script, used for notices and invoices,
  not yet mystified.

### Age II — The Middle Bright (~300y to ~180y before present)

A period of active inter-wave governance. The four-knot arbitration seal
(now called the Guild's four-dot mark, with a tenth dot placed later and
off-centre) is adopted during this age as a practical device for sealing
correspondence between the two colonial houses and the handful of inland
settlements the colonists are slowly bringing under charter.

During the Middle Bright, the colonists' children are born. By its end,
the generation that remembered coming up from below has died out. The
children who take over are the first true natives: they know the colonial
story as a family tale, not as a lived memory.

Notable events:

- **~280y:** The four-knot arbitration seal is adopted. At this point the
  seal is administrative. Its later transformation into a mystical symbol
  (the Guild's ten-dot mark) is centuries away.
- **~220y:** Keeper-Commander Olric the Silent (now buried at T003) is
  active. He is a founding arbiter of the inter-colonial court and one of
  the first to sign dispute-rulings under the four-knot seal. His grave at
  the Wolfsjaw monastery's rear cloister predates the cloister itself by
  about eighty years; the cloister was built around the grave.
- **~200y:** Olric dies. The founding generation of arbiters passes. The
  body that will become the Northern Guild is, at this point, still a
  loose inter-colonial court; it has not yet organized as a Guild.

### Age III — The Slow Forgetting (~180y to ~100y before present)

The Slow Forgetting is named by later scholars, not by those who lived it.
In its own moment, it was the age of *good harbour-trade*, *new arrivals*,
and *steady rain*. The name was applied retroactively by the earliest
Guild historians (roughly 50y before present), who noticed that the
colonial memory had, during this period, begun to fracture into crown-
specific secrets.

The Slow Forgetting is the age of the Third and Fourth Waves, of the Last
Ascent, and of the Late Bell.

Notable events:

- **~170y:** The Third Wave (Free North-line) arrives. Smaller than the
  First or Second, composed of what modern vocabulary would call refugees,
  they settle the wind-scraped plateaux of the north-west and found what
  will become the Free North. They carry, among other things, field-texts
  on the grammar of the old tongue. Fragments of these texts survive today
  in the Greyhold line's private library at Bonehollow.
- **~120y:** The Fourth Wave (Union-line) arrives. The largest of the four.
  A thousand or more souls, commercial in character, with a charter of
  trade rather than a charter of governance. They found what will become
  the Union of Saltmouth. They carry the last shipment of distant-voice
  stones to reach the Reach; within two generations, every Union-held
  stone has been sold to private collectors as a curiosity.
- **~120y:** The monastery at Wolfsjaw is raised. It is built atop the
  surviving shoulder of the older (pre-Faith) city's precinct. The rear
  wall carries the inherited glyphs **sel-an-mor** (*上下相通*,
  above-and-below connect). The monastery's founding monks whitewash the
  glyphs. They remain whitewashed, and re-whitewashed, until Eilin's work
  begins to strip them back.
- **~118y:** The Last Ascent. A small party comes up from below, led by
  the figure Crown archives call the *quartermaster-under*. This is the
  last confirmed arrival of colonists from the far side. They travel with
  the Iron Dragon as transport; commoner bards of the next generation will
  conflate the quartermaster-under with the Hero-from-Beyond.
- **~101y:** The Late Bell. At Mistmere, the Crown's distant-voice stone
  receives what will prove to be the final transmission from the far side.
  King Voss the Seventh is present. He emerges from the reception-chamber
  silent, seals the chamber with a new lock, and takes the key to his
  grave. His one-line note survives: *They have told us not to come. They
  have told us not to look. Do not ask what we have done to deserve this.*
  The content of the transmission is not otherwise recorded.

### Age IV — The First Silence of the New Age (~100y to present)

Named by the Crown; sometimes called the **Hundred-Year Hush** by commoners
and the **Great Quiet** by the Guild. It is the age the player lives in.
It began one hundred years ago, with the failure of further contact from
the far side. It has not yet ended.

Its early decade — the ten years after the Late Bell — is in Crown records
called *the Active Grief*. Voss the Seventh died nine years into the
silence. Voss the Eighth acceded and immediately began the work of
formalizing the four-crown cover story.

Notable events within the First Silence of the New Age:

- **~100y:** Contact with the far side ceases. The Hundred-Year Hush begins.
- **~92y:** Voss the Eighth formalizes the four-crown cover story. Faith
  and Union are enrolled on separate terms. The Free North — under
  Chieftess Greyhold's great-great-grandmother — signs under duress. The
  cover-story's operative paragraph binds the four crowns to this day.
- **~80y:** The Ashford Sinking. The Ashford estate at Mistmere sinks
  partially into the ground. The Mossbarrow is exposed as a cellar older
  than the house. The Ashford line breaks; the surviving cousin-house
  (Reed) absorbs the name. (Magister Corvin Ashford-Reed, present-day, is
  the fourth-great-grandson of the last unbroken Ashford.)
- **~60y:** The Long Descent. Founding of the Depth-Walker order in its
  earliest form — a commoner mystical practice, not yet royal-contracted,
  not yet split into Listeners and Crossers.
- **~40y:** The Limewash. The cathedral undercroft beneath Mistmere is
  limewashed for the first time, under Reynard's predecessor. Two rubbings
  of pre-Faith columns are taken by a junior archivist and smuggled north;
  they reach Eilin's master, the unnamed maester of Wolfsjaw who trained
  Eilin as a novice. These rubbings are the seed of Eilin's entire career.
- **~30y:** The Listener Contract. Archdepth Sula, then a young miner of
  twenty-one, signs the first Listener-Crown contract. Secret royal funding
  of Depth-Walker mining begins. Sula has worked under this contract for
  forty years by the present day — the forty-year rope-hands she is known
  for.
- **~20y:** The Shepherd's First Sighting. Old Shepherd Bram, as a younger
  man on the Jadehollow plateau, sees the straight line of cloud in the
  sky for the first time. He tells a Faith brother. The brother tells a
  Crown archivist. The archivist tells the Guild. Nothing further is done.
- **~11y:** Eilin's Muting. Maester Eilin of the Wolfsjaw monastery
  circulates a draft paper proposing a linguistic kinship between the
  words *reh* (great cliff) and *gai* (great chasm), arguing that the two
  are the same geographic feature named from two different standpoints.
  Within a season, the Crown and Faith jointly order her muted. The
  procedure is performed in the monastery infirmary by a contracted
  barber-surgeon. Abbot Merick holds her hand. She does not struggle.
- **~11y:** The Northern Ban. The Northern Guild's Magister of the day —
  not Corvin; his predecessor — formalizes the Ban as Guild policy. The
  Ban's operative paragraph quotes the stone shard's script (four
  sightings: *sun-nailed-to-tower*, *house-that-flies*,
  *iron-that-sings-like-a-forge*, *the-unending-road*) without attributing
  it.
- **~9y:** The Crosser Split. Navigator Kestrel, then a senior Listener,
  breaks with Archdepth Sula over the royal contract. The Crossers are
  founded. They begin acquiring engineering knowledge and illicit colonial
  records. Kestrel also begins, privately, to archive Eilin's drawings.
- **~9y:** The Ashford-Reed Accession. Corvin Ashford-Reed becomes Grand
  Magister of the Northern Guild. He reads the Buried Charter — the
  Guild's founding document, retained in a sealed vault beneath the
  Mistmere High House — for the first time. He has not slept a full night
  since.
- **~8y:** The Second Sighting. Bram sees the straight line for the second
  time. Reports it to the Guild. The Guild pays him a stipend and asks
  him to sign a retraction. He signs.
- **~3y:** The Shard's Surfacing. Septon Silas, walking the old mine road
  north of Stoneford on his regular third-night patrol, finds the ancient
  stone shard wedged under a flat stone at the ford. He carries it back
  to his vestry. He has not shown it to the Faith's higher offices. He
  has shown it, quietly, to four scholars, one of whom was Eilin's former
  student.
- **~3y:** The Vossel Arrival. Preceptor Vossel the Younger arrives at the
  Wolfsjaw monastery as a novice. He begins secretly transcribing Eilin's
  gestures into a private codex. Eilin has not stopped him. She has not,
  by any sign the monks can read, approved either.
- **~2y:** The Third Sighting. Bram sees the straight line for the third
  time. Does not report it. The Guild knows anyway, via a Faith courier,
  and doubles his stipend without requesting a further retraction.
- **~1y:** The Dragon-Coat Stranger. A grey-coated stranger calling himself
  Veyl passes through Windrest. He watches the sky at dawn as if counting.
  He asks the way to Mistmere. No one yet connects him to anything. Old
  woman Haddie at T004 will, later, remember his face from a song her
  grandmother sang.
- **0y (present):** The player arrives in Stoneford. The road ends here.

### Sub-ages within the First Silence

The Hundred-Year Hush is long enough that commoners have begun to break
it into sub-ages, mostly by reigns or by weather-memory:

- **The Cold Decade** (~100y to ~90y): the first ten years after the Late
  Bell. Crown records call this the Active Grief. Commoners remember only
  that the winters were hard.
- **The Quiet Years** (~90y to ~60y): the age of the four-crown cover
  story's consolidation. Commoners call these years simply *the quiet*.
- **The Long Descent** (~60y to ~30y): the age of the Depth-Walker order's
  founding and early growth. Named after the Depth-Walker practice, but
  not exclusively a Depth-Walker age. The Guild also consolidates in
  this period.
- **The Second Cold** (~30y to ~11y): a period of political tightening
  across the four crowns, culminating in the Northern Ban and Eilin's
  muting. No one uses this name in-world; it is included here for the
  orchestrator's convenience.
- **The Present Rains** (~11y to 0y): the years since Eilin was muted.
  Characterized by unusually heavy and unseasonable rains across the
  Reach, which commoners read as a minor omen and which the Faith has
  declined to interpret either way.

## The Future, as the Reach Imagines It

The Reach does not have a millennialist tradition. It has, instead, a
handful of future-anchors — events that some faction or another
anticipates, but none of them with urgency. These are included here for
writers who wish to foreshadow without committing.

- **The Fog's thinning.** No one in the Reach believes the Fog will thin
  within any living person's lifetime. The creation myth says the Fog
  lifts only when the four hands meet again with no fifth hand present.
  This is not considered a near-term event.
- **The Iron Dragon's return.** Commoners say the Dragon returns when the
  four kings forget their names. Privately, Corvin Ashford-Reed believes
  the Dragon's return cycle is approximately ninety years, and that the
  next return is therefore imminent. He has not written this down.
- **The next ascent.** The Crossers hold that an ascent to the far side
  is possible within a generation, if the right combination of engineering
  and colonial knowledge can be assembled. Kestrel believes the window
  opens within his own lifetime. No other faction shares this belief.
- **The next kingly generation.** Darrik Voss is in his fifties and has
  no named heir. Brenna Greyhold is in her forties and has one daughter,
  unmarried. Malen the Unsleeping is in her sixties and has not slept a
  full night in ten years. Tobiah Caul is in his late forties and has
  four sons, all in trade. A succession crisis is, on demographic grounds,
  due within two decades.

These future-anchors are not prophecy. They are the shape the Reach's
near future casts backward into the present.

## Reconciliation Notes

Where this document's dates meet storyline dates:

- **Line A:** Guild founded two centuries ago matches the ~200y mark at
  which Olric's founding-arbiter generation passed; the Guild's
  consolidation is slightly later (~180y to ~150y) but the "two centuries"
  figure is correct to within Line A's own stated tolerance. Olric's
  ~200y-ago death and his grave at T003 are both honoured.
- **Line B:** the 300y pre-Faith city, 200y burial, 120y monastery, 100y
  silence, 80y Ashford sinking, 40y limewash, 11y muting, 3y Vossel, and
  3-season shard-surfacing are all preserved.
- **Line C:** the four-knot arbitration seal adopted ~280y, Brenna's
  eleventh-weaving genealogy, Malen's ten-year insomnia, Tobiah's
  four-generation merchant house, and the Jade Compact's origin in the
  ~92y cover-story formalization are all consistent.
- **Line D:** nine generations = ~100y silence (at ~11 years per
  generation, per the checker's resolution), Veyl's year-ago passage
  through Windrest, the three Bram sightings at ~20y, ~8y, ~2y, and the
  ~118y Last Ascent as the original Iron-Dragon flight are all
  consistent.
- **Line E:** Sula's 40-year rope-hands (began at 21, now 61), 30-year
  Listener contract, 9-year-ago Crosser split, and Kestrel's collection
  of Eilin's drawings (begun ~9y, actively archived ever since) are all
  consistent.

No date in this document contradicts any date stated in any storyline,
and no era boundary crosses an established dated event.

## For the Next Writer

- Do not add new waves. Four waves is the count.
- Do not add new ages. Seven named ages is the count. If you need a finer
  granularity, use the sub-ages or add a named year, not a named age.
- Do not shift the present day. Year 0 is the player's arrival at
  Stoneford. Every other date is anchored to this one.
- Do not set a date for the Fog's end. The Fog does not end on the game's
  timescale.
- Do not set a date for the Iron Dragon's next return. If it returns
  on-screen, it returns in the present. If it does not return on-screen,
  its cycle is unknown.
- Do not give any crown a calendar more systematic than the five
  described here. Five calendars is the count.

The Reach's memory of itself is long, fractured, and self-contradictory.
This document holds the arithmetic. The stories hold everything else.
