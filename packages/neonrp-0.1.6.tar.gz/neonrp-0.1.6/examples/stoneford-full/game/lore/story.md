# The Chronicle of Stoneford-on-the-Shale

> Maintained by the orchestrator. Append only — never rewrite previous chapters.

## Prologue: The Road Ends Here

The road ended where the fog began.

You had walked for three days through country that grew colder with every mile — past burned farmsteads, past a gibbet where a crow picked at what remained of a deserter, past a stone marker so old the words had been eaten by lichen.

And then the fog, grey-green and thick as wool, rolling in from the Shale.

Stoneford appeared through it the way a drowned man surfaces — slowly, and not entirely welcome.

They say the Mossbarrow stands half a league east of here. They say things speak inside it — not with words, exactly, but with offers. They say the last man who came out was twenty years ago, and he walked straight into the river.

You don't know any of this yet.

You only know that the road ends here, and you have nowhere else to go.

---

## Chapter 1: The Guild Hall

You stand before the bounty board, your eyes tracing the weathered parchment. But something tugs at the back of your mind—a fog thicker than the one outside.

You reach for your sword hilt out of habit. The rusted steel feels familiar, yet distant, as if it belongs to someone else's hand. Your leather armor creaks when you shift your weight. You count the coins in your pouch: thirty-five gold, four silver, twelve copper. Not much, but enough to survive another week.

You try to remember how you got here.

Three days on the road. Burned farmsteads. A gibbet. A crow. The fog.

But before that?

Your name escapes you. Your home, your family, the reason you carry this rusted sword—all of it swims in grey mist, like the fog rolling in from the Shale.

The bounty board blurs for a moment. The words rearrange themselves. *The fog claims its own.*

Heron Blackwater looks up from his ledger. His eyes are sharp, measuring. He's seen this before—the hollow look in a stranger's eyes when they realize they've lost more than just their way.

"First time in Stoneford?" he asks, not unkindly. "You're not the only one this season."

---

You point to the cellar-crawler notice. Heron's grip tightens on his quill.

"Municipal pest control," he says flatly. "Old cellars. Vermin. Nothing for a newcomer."

But you press. And when you do, something flickers in his eyes—not fear, exactly, but the weariness of a man who has been keeping too many secrets for too long.

"Someone needs that work," he says finally. "And some things ought to be in the light, even if they're torn down at dusk."

He leans forward. "If you must know, talk to Merle. The apothecary. But don't say I sent you."

The three wavy lines in a circle. The underground surveyor's mark.

You've seen it before. You're sure of it. But where?

---

## Chapter 2: Wolves at the Barrow

The trail east of Stoneford churned into mud where the cart-wheels had sunk deepest. You followed it past the second bend, where the wolf-sign began—tracks too large for any natural beast, claw marks raked into the oak bark at shoulder-height.

Three encounters along the path:

**First**, a pair of moss-wolves in the bracken. Their fur hung in wet clumps, green with river-mold. They came at you from both sides, silent except for the sound of water dripping from their jaws. Your rusted sword found the gap behind the first one's ribs. The second broke and ran when you drove it through its throat.

**Second**, the cairn-stones. They leaned inward as you passed, forming a corridor that narrowed with every step. Something whispered from between them—not words, but the *shape* of words, like a voice heard through thick wool. You kept walking. The whispering stopped.

**Third**, the barrow-mouth itself. A low stone arch half-sunk in the moss, lintel carved with symbols that hurt to look at directly. A single wolf stood before it, larger than the others, one eye clouded white. It did not attack. It *watched*. And then it stepped aside.

Inside the barrow: damp earth, old bones, and a stone tablet fragment leaning against the back wall. Deepvein surveyor's mark—three wavy lines in a circle—scratched into the stone. The same mark you'd seen before. The same mark that meant *someone else had been here*.

You took the tablet fragment. Proof enough for Heron.

---

**Reward collected**: 30 gold, Minor Healing Potion ×1

**Discovery**: D001 — The Mossbarrow (dungeon entrance confirmed)

**Lead obtained**: The Deepvein surveyor's mark. Someone from House Deepvein was here before you. And they wanted whatever is inside this barrow kept quiet.

---

## Chapter 3: The Shale Lantern

The brass lantern above the inn door burned green-white, as it always did, whatever the weather. Inside, the common room smelled of wood-smoke, river herbs, and tea brewed too strong by a woman who had spent too many years grieving.

Mira Ashford swept the hearth without looking up. The iron fire-dog—a river-fish biting its own tail—cast long shadows across the flagstones. One of those stones sounded hollow when you shifted your weight.

*Two silvers of tea buys Mira looking the other way.*

You ordered the tea. Mira poured without meeting your eyes. When she turned to sweep the back corner, you lifted the flagstone by the iron dog.

Inside: an oilcloth bundle. A silver pendant, thumbnail-sized, flat, shaped like a river-fish biting its own tail. The inner ring was missing. And a brass token, walnut-sized, stamped with Olric's seal on one face and crossed-keys-with-a-broken-key on the other.

*ARBITER · IIII · CORONA · MMCCCXII.*

The pendant was Heron Blackwater's bounty pin. The token was something else entirely—something old, something that opened doors that had been locked for sixty years.

You wrapped them back in the oilcloth and slipped the bundle into your pouch.

Mira kept sweeping. The fire crackled. Outside, the fog pressed against the windows like a living thing.

---

**Item obtained**: Silver Pendant (river-fish, inner ring missing)
**Item obtained**: Old Guild Brass Token (Arbiter IIII, Corona MMCCCXII)

**Storyline A advanced**: The Hollow Flagstone — Heron's wife hid these before he walked into the river. You now hold the choice: return the pendant to Heron (40 gold + sealed letter to Windrest branch), or keep it (guild hostility).

---
