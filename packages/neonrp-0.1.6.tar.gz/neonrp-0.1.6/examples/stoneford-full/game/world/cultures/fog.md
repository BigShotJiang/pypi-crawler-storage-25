# The Fog — The Unbelonging and the Ashen Herald

## Snapshot

The Fog is not a kingdom and has never claimed to be one. It is the scatter of people who live in the mist-valleys between the four crowns and who do not swear to any of them — fog-walkers, cairn-hermits, former-era remnants, a line of stateless couriers, and the masked figure who carries letters between them and calls herself no name. The Fog wears ash-grey unmarked cloth, eats what the valley gives, and teaches its children that **nothing written survives, only what is spoken**. Its most visible voice is the Ashen Herald, who arrived at the four-crown summit uninvited, through a door the guards swore did not open.

## Governance

The Fog has no throne, no circle, no exchange. It has **arbiters** — individual fog-walkers whose judgement is accepted for as long as it is accepted, and no longer. An arbiter is named by consent of those present at a gathering and holds the role only for that gathering. A Fog arbiter's authority ends when the last mouth leaves the room. A new matter convenes a new arbiter.

Gatherings are called **mist-meets**. They are held at cairn-junctions in the valleys between the four kingdoms, announced by cairn-sign (three small flat stones stacked at a path's fork, visible for a day) or by spoken relay through a chain of fog-walkers. A mist-meet has no fixed membership. Any person who arrives is entitled to speak and to be heard. A decision is reached when no one present will speak against it. If one voice holds out, the matter is held over. No majority rule; no vote; no written record.

Power does not transfer in the Fog because power is not held. The Ashen Herald is not a ruler; she is a **voice that has been, for nine years, repeatedly named arbiter at mist-meets she did not call** — a functional authority that has no office and would dissolve the instant the fog-walkers stopped naming her. She carries no seal of state because there is no state. Her mask is an un-glazed clay blank, the negative of the four-knot. This is her only sign.

Arbitration between Fog-folk is by whichever arbiter the parties agree to approach. Most arbiters are old cairn-hermits known by voice and rumour; the Herald is approached for matters that cross the kingdoms' borders or touch the four-crown frame. The Herald's judgement is always spoken aloud to the parties and to whoever else is present, and is always accompanied by a line she writes on her slate and then wipes clean. The spoken word is the judgement. The slate is a demonstration. *Nothing written survives.*

Execution does not exist in Fog practice. A Fog-folk who has done a wrong beyond repair is **exhaled** — spoken of, to his face, by the arbiter and those present, and then never spoken of again. The exhalation is formal: the arbiter names the wrong aloud, the fog-walkers repeat the name once, and then the silence closes. The exhaled person may go on living; he will not be addressed by any fog-walker, and cairn-signs will not be hung for him, and no mist-meet will hear him. He is, in the Fog's phrase, **a man who has been said**. He is not hunted. He is simply not there.

## Bloodline

The Fog has no bloodline tradition. Fog-folk are, in origin, fragments of every other population in the Reach: Ashcrown deserters, Free-North exiles, Faith apostates, Union bankrupts, cathedral orphans who walked out the gate at fourteen, Depth-Walker drop-outs who could not climb, hill-folk whose valleys the cathedral census missed. The Fog takes anyone. The Fog keeps anyone who does not leave.

The one exception is the Herald herself. The Herald's unmasked identity is canonically **Brenna Greyhold's elder sister who does not officially exist** — a woman the Greyhold clans have had no record of for thirty years, whose name the chieftess does not speak. She carries, therefore, the Greyhold chieftess-line's colonial memory, the *under-road* inheritance, and the old-Norhald vocabulary of the *other side*. She has been through the fifth door. She is the only person in the Reach whose colonial knowledge comes from neither the Ashcrown's sealed monograph nor the Greyhold chieftess-line's lullaby, but from what she has **seen with her eyes** on the far side of the bricked-up door.

Interbreeding is not a Fog category. A Fog-folk child is raised by whichever fog-walkers are nearest when the child is born. Children are not registered, not counted, and not named in any fixed way — the name is given by the mother in a sentence spoken to the child, and the name is whatever the child remembers of that sentence when she is old enough to tell it back. Fog-folk often have no surname. Some have no fixed given name; they are addressed by circumstance (*the girl who waited at the three-stone cairn*, *the man who brought salt in the hard winter*).

Physically, Fog-folk are indistinguishable from the populations they came from. A Fog-walker born Ashcrown looks Ashcrown. A Fog-walker born Free-North looks Free-North. The Fog does not mark its own.

## Economy

The Fog has no economy in any Exchange sense. It has **carriage** — the moving of small things between the kingdoms by fog-walkers who accept payment in whatever is offered. Fog-walkers carry letters, packages, and occasionally people. They do not carry contracts. They do not ask what is in the package. They charge by distance and weather, not by weight, and they will, in a hard season, carry for free.

Fog-folk subsist by **valley-gleaning**: hunting cave-fish, snaring hill-grouse, gathering hearth-root and fog-moss, trading small-work at the edges of the four kingdoms for salt, grain, and iron tools. A fog-walker will repair a farmer's roof for a week's bread; a cairn-hermit will sharpen a cottager's knife for a handful of salt. None of this is recorded. The Fog has no ledger and no pride in weight.

Tax does not exist. Fog-folk do not pay tithe to any cathedral, do not pay hearth-service to any clan, do not pay Honest Tithe to any Exchange, and do not pay equinox-silver to any Crown. This is, to the four kingdoms, the Fog's chief offence. It is not an economic offence; the Fog is too small to matter economically. It is a theological and political offence — the Fog is the one population in the Reach that has withdrawn from the frame, and the frame cannot forgive withdrawal.

Currency is not used inside the Fog. Between Fog-folk, the exchange is direct — a knife for a week's food, a letter carried for a pair of boots, a night's shelter for a song sung at the fire. When a Fog-walker trades with a kingdom-folk, any coin is accepted at the kingdom-folk's weight; the coin is then spent, never held. Fog-folk are famously bad at saving. They are famously good at arriving when needed.

The Herald herself accepts no payment. She is given food and shelter at any mist-meet; beyond that, she owns what fits in the satchel at her hip — her slate, her chalk, a fragment of charcoal, a small iron bell, and a folded oilcloth cloak. Her mask she carries in her hand when not wearing it. She has no horse, no weapon, and no writing that she keeps.

## Food

The Fog's staple is **what the valley gives**. There is no fixed diet. Cave-fish, grouse, hill-rabbit, hearth-root, fog-moss, hill-berry, the occasional goat if a farmer is paying in livestock. Fog-folk eat simply and eat whatever is in front of them. A Fog-walker offered salt-fish at a Union table, blood-sausage at a clan-hall, wafer at a cathedral, or the nine dishes at a Voss estate will eat all four without comment and without preference.

Feast food is **the mist-meet meal** — at a gathering, each arriving fog-walker places what she has brought into a common pot over the fire, and the pot is eaten in turn, unportioned, with bread if there is bread. No host, no order, no announcement. Every fog-walker leaves the meet with an empty satchel and a fuller belly, or with neither. The Fog does not count the meal.

Travel food is **the walker's bag** — a handful of hard bread, a strip of cured meat, a pinch of salt, sometimes a twist of dried moss. A fog-walker can live on the walker's bag for three days and will, if the weather turns, live on fog-water and the memory of the bag for two more.

Sacred food does not exist. The Fog does not sanctify meals.

Forbidden food does not exist. The Fog will eat anything, including the grey cave-fish the clans refuse, the blood-sausage the Faith refuses, the river-eel the Crown refuses. A Fog-walker at an Ashcrown border-inn has been known to order the Shale-eel specifically, eat it slowly, and leave without comment. This is not done as provocation. It is done because hunger does not choose.

## Dress

Daily dress is **ash-grey unmarked cloth**. Fog-folk wear long hooded cloaks of undyed or wet-ash-dyed wool, over plain linen tunics and soft leather trousers. Boots are whatever can be traded for. No clan-plaid, no merchant-chain, no House sigil, no cathedral collar. A Fog-walker in the rain is a shape without heraldry.

Ceremonial dress is the **Ashen Herald's mask and cloak** — the only formal Fog costume. A long ash-grey cloak with a deep hood, a mask of un-glazed clay (the mask is made by the wearer, fired at a valley-kiln, and replaced when it cracks), and no other mark. The Herald's mask has eyeholes, small breath-holes at the nostrils, and nothing at the mouth. The wearer speaks through the clay. The voice is muffled, made not-quite-a-woman's-and-not-quite-a-man's by the resonance of the clay. This is the intended effect.

Military dress does not exist. The Fog has no uniform.

Colours are wet-ash grey (the default), undyed brown (for cloaks that have not been dyed yet), and plain black for mourning. Any other colour is considered kingdom-adjacent and is avoided — a red-cloaked fog-walker would be asked, gently, at the next mist-meet, whether she was returning to a kingdom. The answer would not be held against her. She would simply no longer be treated as fog-walker until she had re-dyed.

Fabrics are wool, linen, and leather — whatever the valleys produce. Silk is not worn (a Union vanity; also impractical in fog). Steel inlay is not worn (a Greyhold vanity; also a signature the Fog does not want).

The taboo, and the one strict one, is **no kingdom-mark**. A Fog-walker caught wearing a House sigil, a clan-plaid, a merchant-chain, or a Septa's collar is asked to remove it. If the removal is refused, the fog-walker is considered to have chosen a kingdom and is no longer fog. This is not punitive. It is diagnostic.

## Rituals & holidays

**Birth.** A Fog child is born wherever the mother is. The mother speaks a sentence to the child at the first nursing. The child's name is whatever the child eventually remembers of that sentence. There is no ceremony and no witness. The Fog holds that a name given in ritual is a name half-given.

**Marriage.** The Fog does not marry. Two Fog-folk who choose each other say so at a mist-meet, and the others present nod. The nodding is the marriage. If the two part, they say so at a later mist-meet, and the others present nod. The nodding is the parting. No record, no oath, no dowry, no plaid, no contract, no wafer.

**Death.** A Fog-folk body is carried to the nearest high cairn and laid under a flat stone. No name is cut into the stone. No mark is left. The Fog holds that the dead are in the air the living still breathe, and that a named stone is a cage. Fog-folk visit cairns without knowing which dead are under which stones. The visits are silent.

**Seasonal festivals** are two, both unofficial: **the dark moon** (the monthly gathering at whichever cairn-junction the fog-walkers have chosen, announced by stone-sign, lasting a single night, with the common pot and the common fire) and **the long silence** (the three nights at midwinter, beginning at dusk on the shortest day, during which no Fog-folk speaks a word aloud; the silence is broken at dawn of the fourth day with a single spoken sentence, which each fog-walker chooses for herself before the silence begins). The Herald has spent every long silence of the last nine years at a different cairn-junction. No fog-walker has ever heard what her breaking sentence is.

**Oath forms.** The Fog does not swear in any kingdom-sense. A Fog-folk gives **a spoken word** — a sentence said aloud, witnessed by whoever is present, that will be remembered by those who heard it for as long as they remember anything. The sentence is the oath. There is no form, no binding phrase, no object, no scar, no clause.

## Oath forms

The Fog swears **by what is said and by what is heard**. The full form, when a form is used at all, is: *"I say this, in the hearing of these mouths, and the mouths will remember."* The word is the oath. The hearing is the witness. There is nothing else.

The penalty for breaking a spoken word is **exhalation** (see Governance). There is no lesser penalty. The Fog does not distinguish life-oaths from season-oaths from day-oaths. A spoken word is a spoken word. A broken word is a broken mouth, and the Fog closes the silence around it.

The idiom *her word walks* means a Fog-folk is keeping a spoken oath and is trusted. The idiom *his word has been said* means he has been exhaled — the idiom is a pun; he has spoken, and he has been spoken of. The idiom *the slate is clean* is the Herald's own — her signature closing, spoken at the end of a judgement, as she wipes the chalk off the slate. It means *the judgement is given, and the writing is gone, and only the saying remains.*

The Herald has never, in nine years, sworn a Fog spoken-word oath in public. Fog-walkers have noted this. They have not asked. The one who asks would not be answered.

## Law & punishment

The Fog has no law. It has **memory** — the collective mouth of the fog-walkers, which remembers who did what and says so aloud when asked. A wrong done in the Fog is a wrong the fog-walkers carry in their mouths. There is no written statute, no sentence, no court, no judge except the arbiter of the moment.

Common wrongs: breaking a spoken word; taking what was offered to another; betraying a fog-walker to a kingdom; carrying a weapon into a mist-meet; wearing a kingdom-mark under the ash cloak. The response, in each case, is a mist-meet conversation, an arbiter's judgement, and either a correction (return what was taken, re-dye the cloak, leave the weapon at the cairn) or, for the unresolvable, exhalation.

A Fog-folk fears the law as **the silence that follows a spoken word**. When an arbiter begins to speak a judgement, the fog-walkers around the fire go still. If the judgement is correction, the fire comes back. If the judgement is exhalation, the fire stays low for the rest of the night, and the wrongdoer — still present, still seated — hears his own name spoken once by each mouth, and then the fire goes out, and no mouth addresses him again.

The most feared outcome is not exhalation itself but **the silence between the saying and the leaving**. A Fog-folk who has been exhaled must sit through the remaining hours of the meet, hear the others speak to each other and not to him, and walk out alone at dawn. This is the hour Fog-folk speak of with dread. The hour is said to last longer than any hour. Fog-walkers have, in living memory, chosen to die in a valley rather than walk the hour.

## Military style

The Fog has no army, no militia, no watch, no guard. It has **ambush-bands** — small, short-lived groups of fog-walkers who gather when a specific threat crosses the valleys and dissolve the moment the threat passes. An ambush-band forms by word-of-mouth, travels light, strikes from cover, and withdraws to the cairns. It does not hold ground. It does not take prisoners. It does not pursue.

Doctrine is **the closing mist**. Fog-walkers do not fight in open order. They let an enemy column pass into a valley, close the valley mouths with a handful of blades and a short-bow volley, and fade into the fog when the column breaks. They do not chase. They do not count kills. An ambush is over when the fog has closed.

Unit types, insofar as the word applies: the **valley-walker** (a single fog-walker with a long knife and a short-bow, operating alone, scouting and harassing), the **cairn-pair** (two fog-walkers at a prepared cairn-position, covering a valley mouth, usually armed with short-bow and a spear), and the **meet-band** (a temporary gathering of eight to twenty fog-walkers, called for a specific engagement, dissolved at its end).

Weapon preferences are the **long knife** (traded from the Free-North clans, the Fog's most common blade), the **short-bow** (cheaper than the Free-North recurve, adequate for valley-range), and the **sling** (for those who cannot afford a bow; silent, cheap, and accurate in the hands of a hill-born fog-walker). The Fog does not use the great-axe (too heavy for a walker's pace), the long spear (too long for valley cover), or the crossbow (too slow to re-span in a close ambush).

The Ashen Herald carries no weapon. She has never, in any record, struck a blow. She is protected by the one-way function of fog-walker solidarity: a fog-walker who saw her struck would see the attacker walk alone out of every cairn for the rest of his life. Her safety is not armour. It is memory.

## Religion / metaphysics

The Fog's cosmology is **oppositional to the four kingdoms'**. It can be stated in a single line, and fog-walkers will speak it if pressed: **nothing written survives, only what is spoken**. The written word is, in Fog belief, a dead thing — a word taken out of a mouth and laid on a page, where it cannot grow, cannot change, cannot be contradicted by a later mouth. The spoken word is alive. The spoken word is the only real word.

This belief is not mystical. Fog-folk do not claim the spoken word has magical power. They claim the written word is a **cage**, and the cage is the instrument the four kingdoms have used to trap their own legitimacy. A Crown monograph, a Faith edict, a Union contract, a clan-cairn with a name — each of these is, in Fog reading, an attempt to make a word permanent, and each has, in Fog experience, failed. The Crown monograph is a sealed document no one is allowed to read. The Faith edict is forgotten the moment the Septa who wrote it dies. The Union contract is superseded by the next contract. The clan-cairn is visited until the grandchildren stop visiting.

The Fog rejects all four crowns on this ground. A crown is a written thing — a House charter, a cathedral seal, a clan-muster roll, an Exchange register. A crown that must be written is a crown that is afraid of being forgotten, and the Fog holds that **a word that must be written is a word that has already begun to die**.

The Fog's cosmology aligns, in a way the Faith finds disturbing, with the Faith's own preference for unwritten judgement. The Herald has, in her letters, made this alignment visible: *the Septa's chair and the Fog arbiter's fire burn the same wood*. Malen has privately forbidden her septons to debate the Herald publicly, because a public debate would make the resemblance visible. The Fog is the Faith's own doctrine taken one step further and refused the cathedral.

The Fog's relationship to the Chasm is **the Chasm is the only honest geography**. The four kingdoms have written themselves a world of maps; the Chasm is the place the maps end. A fog-walker at the cliff-edge is a mouth at the boundary of all writing. The Herald has been at the cliff-edge. The Herald has, canonically, been **through the fifth door** — the bricked-up colonial-transit door preserved in every major town of the Reach — and has seen what is on the other side. She has not written what she saw. She has spoken it once, to one person, at a mist-meet whose attendance is not recorded.

The Fog does not recognise any named god. It does not recognise the Pattern. It does not recognise the Hearth-and-Stone. It does not recognise the Twelve Honest Weights. It recognises **mouths**, **air**, **silence**, and **memory**, and it considers these sufficient.

## Language & address

The Fog has no language of its own. Fog-walkers speak whatever they spoke before they came to the Fog — common northern, southern, Norhald, cathedral-tongue, or any of the valley dialects. At mist-meets the common tongue is **plain common northern**, used because it is the most mutually-intelligible across the populations the Fog draws from. A fog-walker will, at need, translate for another.

Addresses are minimal. A fog-walker is called by given name, or by circumstance (*the one who came from the west cairn*, *the woman with the iron bell*), or simply **friend** (common northern) or **mouth** (the Fog's one shared term). To address a Fog-folk as *friend* is a greeting; to address them as *mouth* is to invoke the Fog's core doctrine — you are acknowledging them as a bearer of spoken word, which is the Fog's highest recognition.

The Ashen Herald is addressed, when addressed at all, as **Herald** (the kingdoms' name for her, which she accepts without comment), **the walker-without-hearth** (Brenna Greyhold's name, Free-North idiom, meaning one who has no clan to swear on), or **Ash** (a small intimacy, used by the three or four fog-walkers who have known her longest; she has not corrected them). She has no surname, no House, no clan, and no guild. Her first name is not spoken by any mouth currently in the Reach.

A Fog-folk addresses an Ashcrown lord as **Voss-house** (no title; the Fog does not use *Your Grace*), a Septa as **Mistmere-woman** (no *Holiness*), a Free-North chieftess as **Greyhold-mother** or **clan-woman** (no *Hearth-mother*, because the Fog has no hearths to honour), and a Union consul as **Caul-house** or **merchant-man** (no *Consul*). This flattening of title is not rudeness. It is the Fog's refusal to reproduce the four kingdoms' hierarchies in its own mouth.

Idioms:

- *Her word walks.* She keeps her spoken oath.
- *His word has been said.* He has been exhaled.
- *The slate is clean.* Judgement is given; writing is gone; saying remains. (The Herald's closing.)
- *The mist closes.* The matter is settled.
- *She is a mouth.* She is trusted to speak truly.
- *He has a kingdom under his cloak.* He still wears a House sigil or clan-plaid beneath the ash. Diagnostic, not accusatory.
- *Four rooms with four doors, and one wall between them they have all agreed not to see.* The Herald's line on the four crowns, written once on the slate, shown to Tobiah at the summit.

## Attitude towards the other four cultures

**Crown.** The Fog regards the Ashcrown as the most coherent of the four kingdoms and therefore the most dangerous. The Crown's written hierarchy, its sealed monograph, its four-knot ring, and its discipline of silence are, in Fog reading, a finished cage — a structure that has been refined for generations and that now holds legitimacy tightly enough that no spoken word can puncture it from outside. The Herald has studied the Crown longer than any of the other three. She has written Darrik Voss two letters. He has not replied. She has not expected him to.

**Faith.** The Fog regards the Faith with a cousin's affection and a cousin's wariness. The Faith and the Fog share the preference for unwritten judgement, and the Herald has specifically used Faith scripture-cadence in two of her letters to Mistmere. Malen has read them. Malen has been disturbed. The Faith and the Fog are, doctrinally, a fork from the same root — the cathedral took the unwritten word and built a cathedral around it; the Fog took the unwritten word and refused any building at all. The Herald does not consider Malen an enemy. She considers Malen a woman who could, with three nights' conversation, become fog. Malen considers the same and is terrified.

**Free North.** The Fog has the warmest and most complicated relationship with the Free North. The Fog draws many of its members from Free-North exiles; the clan-tongue Norhald is spoken widely at mist-meets on the northern moors; the Herald herself is of Greyhold blood. The Free North regards the Herald as *walker-without-hearth* and would not take an oath from her — but would, and does, offer her the clan-hearth for a night if she arrives at a clan-hall. Brenna has received the Herald's single iron disc (the Greyhold-sigil mark *I have received and I owe you a word*) and has not yet given the word. The summit is the Herald's attempt to collect.

**Union.** The Fog regards the Union as the most honest of the four kingdoms and the most instrumentally useful. Union ledgers are the Fog's accidental library — the fog-walkers who pass through Greyharbour and Stoneford note which entries have been filed, which brass cups have been logged, which amber leaves have been weighed. The Herald's knowledge of the Crown's ignored consignments comes, in part, from Union clerks' honest ledger-keeping. The Fog does not believe the Union is innocent; it believes the Union is ignorant, and that ignorant honesty is the most exploitable resource in the Reach. The Herald's one letter to Tobiah was a test of exactly this.

**Among themselves.** Fog-folk do not romanticise the Fog. They do not call themselves a culture. A Fog-walker asked *what are you* will answer *a mouth* or *no one* or *a walker*. The Fog's solidarity is real and thin — it extends to feeding and sheltering any fog-walker who arrives, and no further. A Fog-folk who is exhaled is alone. There is no Fog safety-net for the exhaled.

## Attitude towards the Chasm & Depth-Walkers

Public stance: **the Chasm is the only geography the kingdoms have not written over.** The Fog does not revere the Chasm; it respects the Chasm as the one place where the kingdoms' maps end. A fog-walker at the cliff-edge is a mouth at the boundary of writing.

The Fog's relationship to the Depth-Walkers is **the closest alignment the Fog has with any organised body in the Reach**. The Listeners are mostly royal-contracted and are not Fog-aligned; but the **Crossers** — the splinter faction under Navigator Kestrel, who refuse to hand relics to royals and are secretly engineering a way across — are read by the Fog as kindred. The Herald has met Kestrel twice. She has read his sketch labelled *from below, we may rise*. She has not told him what she saw through the fifth door. She considers the Crossers a vehicle she may, at a later date, step into — but not yet.

The Herald's private conviction, known only to the fog-walkers who have heard her speak at the midwinter long silence's broken sentence: **the Crossers are right that the Chasm was never the real road, and the Listeners are right that the truth of the north is below, and the four crowns are wrong that either path must be hidden**. She has not written this. She has said it once. The fog-walkers who heard it remember.

## Storyline hooks

Named NPCs from this culture:

- **The Ashen Herald** (T005, Line C sub-soul — Fog; masked; canonically Brenna Greyhold's elder sister who does not officially exist)
- **Jenn** (T001, Line C — courier, Brenna's niece; NOT the Herald; carries the Herald's letter and does the dockside chase)
- **The fog-walker at the fifth door** (T001–T005, ambient; one per town, un-named, a figure in ash-grey who passes through a wall at the edge of a scene and is never explained)

Storyline beats that rely on this culture's norms:

- The Herald's letter (Line C T001) — sealed with a four-knot whose centre is empty. Written in Tobiah Caul's own merchant-cipher, which the Herald learned by reading a Union clerk's notebook left on a Greyharbour tavern table. The letter is the Fog's one written artefact in the storyline, and the Herald herself would say — did say, in a line Jenn never delivered — *"I wrote one word that the mouths cannot carry. I will never write again. The slate is clean."*
- The Herald's entrance at the summit (Line C T005) — she arrives through the bricked-up fifth door in the Mistmere summit chamber. The guards at the four doors will later swear none of them opened. The bricked-up clay door is unchanged. Her movement is not magic; it is the literal use of the fifth door, a colonial-transit door preserved in every significant town of the Reach.
- The slate and the wiping (Line C T005) — the Herald writes each of her lines on a slate, holds it up for the four crowns to read, and then wipes it clean before speaking the same line aloud. The wiping is doctrine: *nothing written survives, only what is spoken*. The Faith reads this and flinches. The Union reads this and, for the first time in Tobiah's life, does not know where to reach for a pen.
- The Herald's withdrawal (Line C T005) — she places her palm flat on the four-knot clay of the bricked-up door. The clay does not open. It does not move. But the Herald's hand goes through the clay up to the wrist, and then to the elbow, and then she steps forward and the rest of her follows. The player, if on the Fog path, may follow.
- The Herald's offered mask (Line C Endpoint 5) — the player who takes the Fog path emerges at the Mistmere harbour, at dusk, with a mask of un-glazed clay in their hand. The mask fits. The mask is theirs. The Herald is gone. The player is the only character in the Reach who has seen her face. This is the Fog's only rite of investiture, and it is not explained.

Idiosyncrasies a town writer must preserve:

- Fog NPCs do not use kingdom titles. *Voss-house*, *Mistmere-woman*, *Greyhold-mother*, *Caul-house*, *merchant-man*. A Fog-walker saying *Your Grace* is written wrong.
- Fog NPCs do not kneel. Not to kings, not to Septas, not to the fire. A Fog-folk sits, stands, or walks; she does not kneel.
- Fog NPCs do not sign. A Fog-walker asked to sign a written document will say, *"I will say it again, if you need it said."* She will not write. If the document is refused, she shrugs.
- Fog NPCs wear ash-grey, unmarked. A Fog-walker with any visible kingdom-mark (sigil, plaid, chain, collar) is either a defector returning to a kingdom or a fog-walker who has been exhaled. Writers should make either case legible.
- Fog NPCs eat anything. A Fog-walker at any feast will eat what is offered, without preference. Any Fog-walker who refuses food is either ill, exhaled, or about to deliver a judgement. Writers should use the refusal carefully; it is a flag.
- Fog NPCs do not own things. A Fog-walker's possessions are what fits in a shoulder-satchel. A Fog-walker asked *where is your horse* will answer *I walk*. A Fog-walker with a horse is suspect.
- The Herald writes on a slate and wipes it. She does not hand paper. She does not seal wax. The one exception — the sealed letter at the start of Line C — is a deliberate breach of her own doctrine, and she will not make another. Writers must not have her produce a second written letter in any act.
- The fifth door exists in every major town. Writers should place one, un-noted, un-explained, at the writer's discretion — a bricked-up door with a four-knot clay seal, in a cathedral wall, a cellar, a cairn, a warehouse, a gatehouse. The door does not open. It is observed. Players may recognise it on a second playthrough. The door is the Fog's only architecture.

<!-- writer-only
## Inner circle knowledge

The Ashen Herald's knowledge, as of the summit at Mistmere, is the broadest of any single NPC in the Reach. This is canon (C storyline, Herald dossier). Writers must preserve the distribution and the gaps.

1. The Herald knows that the four kingdoms are descended from colonists from the far side of the Great Chasm. She learned this as a girl, as the eldest daughter of the Greyhold chieftess-line, before she left the clans at the age of sixteen. She has since confirmed it independently by going through the fifth door.

2. The Herald knows the four-knot is the seal of the original colonial council — the arbitration body that preceded all four crowns and whose records were sealed into the Guild's Buried Charter (Line A). The Faith's four-knot, the Crown's four-knot ring, the Free North's cairn-mark, and the Union's Exchange-scales are all, in origin, the same seal. The empty centre of her own mask is the seal stripped of its borders.

3. The Herald has been through the fifth door. At least once, possibly more than once. What she saw on the far side is not fixed in canon and writers must not specify in player-facing text; in writer-only notes, the far side is a **dead modern civilisation** per SHARED_BRIEF — silent towers of rare-metal alloy, an unending road, houses of strange light, no living inhabitants. The Herald has seen this with her own eyes. The four crowns have not.

4. The Herald does not know why the contact stopped a hundred years ago. She has read, on the far side, evidence of sudden cessation — meals half-eaten, tools dropped, doors closed mid-cycle — but no evidence of collapse in the usual sense. She has formed no theory. She has, in fact, formed a discipline: she will not speculate on what she has not been told by a living mouth.

5. The Herald knows the contents of the Crown's sealed monograph in outline, but not in full. She knows, specifically, that the Crown has suspected the far side *cut us off* rather than collapsed. She disagrees, on the evidence of her own eyes; but she respects the Crown's fear and has not sought to correct Darrik in writing. She has said, once, at a mist-meet: *"He is not wrong to be afraid. He is wrong to keep his fear in a sealed box."*

6. The Herald knows the amber tea is a far-side preservative compound. She has not drunk it. She has been offered it once, by a Listener at a cairn-junction, and has refused. The Listener is still alive. The refusal is remembered.

7. The Herald knows the distant-voice stones are pair-linked. She knows the woman Malen hears at night is alive on the far side. She knows the voice is a woman who — this is the detail writers must hold carefully — the Herald has herself spoken to, once, through a stone of her own. The conversation was eight words long. The Herald has not repeated any of the eight words to any fog-walker.

8. The Herald knows the un-hammerable metal is a colonial alloy. She knows Brenna's inlay and Durm's lump are the same substance. She knows the Greyhold line has a reserve of it in the sealed cairn Brenna has not opened. She will not tell Brenna this. The inheritance is Brenna's to find, not the Herald's to give.

9. The Herald knows Jenn is her niece. Jenn does not know the Herald is her aunt. The Herald will not tell her. This is canon (Line C).

10. The Herald's identity is **Brenna Greyhold's elder sister who does not officially exist.** She was born before Brenna, removed from the clan-line at sixteen for refusing the chieftess-inheritance, walked south, was taught by a cairn-hermit who died ten years later, went through the fifth door nine years ago, and has worn the mask since. Her given name, spoken only by two fog-walkers still living, is not to be written in player-facing text under any circumstance. In writer-only material it may be referenced as *the Greyhold eldest*. Brenna has not spoken her sister's given name in thirty years. Brenna will not speak it at the summit. If the player reaches Endpoint 5, the Herald unmasks once, in a location the writer chooses, and the player sees her face. The given name is still not spoken.

11. The Fog's vocabulary, inside the Herald's head and at the midwinter long silence, is plain and exact. She does not use modern terms. She has, in her nine years of the mask, refused even the clan's old-Norhald *gjord-jern* (the made-metal), preferring *iron that has been made twice*. She refuses *undervei* (the under-road), preferring *the road beneath the road*. She refuses *andre sida* (the other side), preferring *the silent place*. This is her discipline. Writers must preserve it: no modern vocabulary in the Herald's mouth, and no old-Norhald vocabulary either. She has set aside the inheritance and speaks only in the common tongue, plainly.

12. The Herald will, at Endpoint 5, give the player one instruction at the harbour. It is canonically one sentence. Writers for later acts may fix the sentence or leave it variable. Candidate sentences, from the Herald's dossier: *"Walk to where you are not expected."* / *"The slate is clean. The mouth is yours now."* / *"Find the one who has not been told and tell her."* The last candidate points at Malen. Writers should preserve the ambiguity.
-->
