# The Crown Kingdom — The Ashcrown of the Southern Vale

## Snapshot

The Ashcrown is the oldest sitting throne north of the Brokenspine, and its people are taught from the cradle that a crown is a thing carried in the blood, not in the hand. Its courts are quiet, its cloth is dark, and its kings drink a tea no other kingdom is served.

## Governance

The Ashcrown is a single-line hereditary monarchy. Power passes from a reigning king to the eldest acknowledged child of the royal womb, and from no other. The acknowledged heir is titled **King-Apparent** from the eleventh year of age; the current King-Apparent is **Darrik Voss**, ruling in his father's name while the old king keeps to his southern estate.

Beneath the throne sit four Great Houses — **Voss** (royal), **Ashford-Reed** (now broken, absorbed), **Alric** (court and envoyship), and **Linden** (marches and sword). Each holds a Seat at the Morning Table, where the king hears petitions from sunrise to the second bell. The Morning Table has sat, in some form, for nine generations.

Arbitration between Houses is the king's own work. No House may sit in judgement of another House; all inter-House disputes ride south to the capital and are heard by the king in person. The ruling is given orally, written by a clerk, sealed, and the original spoken copy burned in front of the parties — so that what the king *said* is never contradicted by what is *written*.

Execution is by single blade. The executioner is always a son of House Linden, because the Crown holds that death-work should never be done by a stranger's hand. There is no public spectacle. The condemned is taken to the southern orchard at dawn, and the orchard is replanted with a new tree each year.

## Bloodline / race

The Ashcrown is the most human-dominant of the four kingdoms. Its smallfolk are short, dark-haired, olive-skinned in the south and paler toward the Shale; the southern court carries a narrow aquiline nose and high cheek that the Houses call *the royal stamp*.

The royal line itself carries a vestigial **noble-elven strain** — a trace so thin the court rarely speaks of it, but unmistakable to an old herbalist or a midwife. Royal-born children have slightly elongated lobeless ears, a pupil that narrows to a vertical slit in bright sun, and a tendency to live long past the common span. Darrik Voss has all three markers. His grandfather lived to a hundred and eleven; the current king is past ninety and still rides.

Interbreeding attitudes are strict at the top and loose at the bottom. Common Ashcrown folk marry across bloodlines without comment. The royal line marries only within acknowledged House-blood, and the elven trace is considered a sacred liability — the royal line preserves it, but the Faith is not permitted to examine a royal body at death. The king's corpse is burned whole within two hours of expiry, in a closed southern orchard, by Linden hands.

Mixed children of House lords and commoners are acknowledged but cannot inherit. They are titled **House-kin** and given a small southern estate, a stipend, and a polite distance.

## Economy

The Ashcrown produces grain — long-grain southern wheat, millet on the terraces, barley on the Shale — and wine, and cut silver from the low hills. It imports timber from the Free North, iron and finished goods from the Union, and cured fish from the Stoneford coast.

Tax is paid twice yearly, at the equinoxes, in a fixed silver weight per hearth. The tax-collector is always a Voss cousin or an Alric clerk, never a Linden — a House that swings a blade does not also count coins.

The Ashcrown mints its own coin: the **royal silver**, stamped with the four-knot on the obverse and the king's profile on the reverse. It is accepted at face weight across all four kingdoms. Commoners prefer it to Union paper and Free-North blood-coin.

The royal house itself trades privately in certain imported leaves — an amber tea served in brass cups at the Morning Table — for which no manifest is kept and no tax is paid. Commoners do not know this trade exists; House-kin know only that the king drinks something no one else is offered.

## Food

The staple is **flatbread and salt-pork**. Every Ashcrown hearth keeps a bread-stone and a pork-barrel. The bread is unleavened, cooked on the stone in thin discs, and served with a thumb of rendered pork-fat and a pinch of grey salt from the Shale.

Feast food is **the nine dishes**: a small bowl of each of nine traditional preparations, served in a single sitting. The nine are fixed by royal decree and have not changed in four generations — roast lamb, millet porridge with honey, river-fish in vinegar, pickled mountain root, boiled egg in brine, bitter greens, rye-bread with black butter, a single cured olive, and a thimble of southern wine. The order of eating is fixed. The ninth dish is always the olive. The olive is always eaten last.

Travel food is **ash-cake** — a dense flatbread baked twice, once soft and once hard, with rendered pork and a ribbon of salt through the middle. It keeps for three weeks and is the standard ration of a royal courier.

The sacred food is **the orchard plum**. Plums from the royal southern orchard are served only at the coronation of a new king. They are never sold and never given as gift. A commoner may go an entire life without tasting one.

The forbidden food is **the river-fish that bites its own tail** — the old Ashcrown word for a particular eel that runs in the southern ponds. The eel is the seal-shape of the old arbitration Guild, and the Crown has forbidden its eating for two hundred years. No Ashcrown hearth will serve it. Smallfolk at the northern border eat it and call it *Shale-eel* to avoid the taboo.

## Dress

Daily dress is **dark wool and undyed linen**. Men wear a long coat to the knee, belted at the waist, with plain horn buttons. Women wear a gown to the ankle with a high collar, belted at the ribs. The colours are black, charcoal, wine-dark, and the natural brown of the wool. Bright colours are considered merchant-dress and are not worn in the capital.

Ceremonial dress at court is **the southern doublet** — a tight-fitted dark green or dark blue garment with silver piping at the cuffs and collar. The doublet is worn by envoys and court attendants; the king himself wears a plain dark grey with no piping, because the king is above ornament.

Military dress is **the Linden grey** — a grey surcoat over plain iron mail, with the House's sigil (a single black oak) on the breast. Ashcrown soldiers do not wear cloaks in the field; the cloak is a court garment only.

The royal family wear a **four-knot ring on the left thumb**. The knot is pressed into the ring's face; the centre of the knot is empty. King-Apparent Darrik Voss wears one. The ring is never removed, not even for sleep, not even for bathing. When a king dies, the ring is burned with him.

The forbidden colour is **deep red**. The old histories — which no commoner reads — record that the first colonists wore deep red, and the Crown has not worn it since the contact stopped. A commoner wearing deep red at court is asked, politely, to change. No explanation is given.

## Rituals & holidays

**Birth** is quiet. A royal child is presented to the Morning Table on the seventh day. The House midwives examine the ears, the pupils, the palms. If the markers are present the child is named; if not, the child is named differently, and raised House-kin. No commoner knows this examination happens.

**Marriage** is a ledger matter. The two parties kneel before a House scribe, speak their names, and a single line is entered in the House roll. A small meal follows — the nine dishes, served by the bride's family. No Septa is required. No oath is sworn. The Ashcrown holds that a marriage is a fact to be recorded, not a ceremony to be witnessed.

**Death** for commoners is by burial under a flat stone with name and dates. Death for royals is by **fire in the orchard**, carried out by Linden hands within two hours of expiry. The ash is worked into the soil of a new tree. The royal line is, in this literal sense, a grove.

**Seasonal festivals** are four: the two equinoxes (tax days, quiet), and the two solstices. The winter solstice is **the Long Table** — every hearth sets a chair for a dead ancestor and a chair for a king who will come after. The summer solstice is **the Cut** — House Linden marches the capital's perimeter and every Linden son whose year of service has come presents himself for his oath.

**Military oaths** are sworn on the point of a House blade laid flat across the kneeling man's palms. The oath is spoken in old Ashcrown, which most swearers do not fully understand. The blade is then returned to its scabbard without touching the skin. This is the Crown's oldest rite and has not changed in four hundred years.

## Oath forms

The Ashcrown swears **by blood and by the table that was set before us**. The full form is: *"I swear, on the blood that came down to me, and on the table that was set before my fathers, and on the blood that will go down from me, that this word is the word I will keep."*

The oath is sworn on the point of a blade, on a cup of wine, or on a sealed letter, depending on the weight. A blade-oath is a life-oath; a wine-oath is a season-oath; a letter-oath is a contract-oath.

The penalty for breaking a blade-oath is death by the Linden blade. The penalty for breaking a wine-oath is exile for a year and a day. The penalty for breaking a letter-oath is the return of the letter, unopened, to the House that received it — and the subsequent loss of that House's good word, which in the Ashcrown is worse than a fine.

The idiom *he broke the wine* means he dishonoured a short oath. The idiom *the blade remembers* means an old oath is still binding on a new generation.

## Law & punishment

Ashcrown courts sit by House. A commoner appears before the Voss steward of his district. A House-born appears before the king at the Morning Table. A royal-born appears before no one — royal misconduct is handled privately and never recorded.

The common crimes are theft of grain, adulteration of wine, and striking a Linden man in the field. The sentences are, in order: three days' labour at the threshing floor, a year's exile to the Shale coast, and death.

A commoner fears the law as a tall still man at the end of a long road. Ashcrown law is slow but does not forget. The tax-clerk who came to your father's door will come to yours. The Linden who stood at your brother's oath will stand at your son's. A commoner does not run from Ashcrown law; he pays, and he keeps his mouth still.

The law's one great fear among commoners is **the closed door** — a judgement handed down in a private room with no witnesses but House-blood. A closed-door judgement has no written record and no appeal. It is rare. When it happens the condemned is simply not seen again.

## Military style

Ashcrown doctrine is **the slow line**. A Linden company marches in an ordered column, engages in an ordered line, and does not break line for any reason. The Crown does not raid. The Crown does not skirmish. The Crown sends five hundred men, in iron, in a line, and waits for the enemy to come to them.

Unit types are three: **the Linden foot** (mailed infantry, long spear, short sword, kite shield); **the Voss horse** (light cavalry, bow and sabre, used for screening and messenger work — never for the charge); and **the Morning Table Guard** (the king's own bodyguard, picked men from all four Houses, wearing the four-knot on the breast).

Weapon preferences are the **long spear** (the Linden weapon, eight feet, leaf-blade), the **side-sword** (a straight blade about thirty inches, worn in a plain leather scabbard), and the **horn-recurve bow** (short, for the Voss horse). The Ashcrown does not use the great-axe; axes are a Free-North weapon and are not welcome in the capital's armouries.

The royal family does not fight. A king who takes the field is held to have failed as a king. Darrik Voss has never drawn a blade in anger and is not expected to.

## Religion / metaphysics

The Ashcrown's official belief is **the Pattern** — an old southern cosmology in which the world is a woven cloth and each life is a thread. The Pattern is spoken of but not prayed to. The Ashcrown has no temples of its own; it accepts Faith septons as a courtesy and lets them preach in the outer courtyards, but no Voss has ever knelt to a Septa and no Voss ever will.

The folk variant is **the orchard**. Common Ashcrown hearths keep a small potted tree and speak to it at the equinoxes. The orchard-tree is said to hear the family's dead. Septons dislike this practice and cannot stop it.

The Ashcrown's relationship to the Fog is distant and wary. The Fog is a northern thing. Ashcrown couriers travelling north are instructed to avoid fog-valleys where possible and to sleep in walled keeps. There is no Ashcrown folk-practice against fog, because the capital has never seen it.

## Language & address

The Ashcrown common tongue is **southern** — slower, softer, with long vowels and a tendency to drop the final consonant. A commoner addresses a House lord as **my lord** or **Your Grace's steward**, never by name. A commoner addresses a Septa as **Holiness** but with a slight bow from the waist, not a kneel. A commoner addresses a clan-head of the Free North as **Chieftess-from-the-north** or, more politely, **the walker's lady**, because the Ashcrown does not use the word *chief* for a sitting title.

The royal address is **Your Grace** (the king), **Your Grace's Heir** (the King-Apparent), and **Your Grace's House** (the Great Houses). The king addresses his equals at other crowns as **Brother** or **Sister of the Table**.

Oaths and idioms:

- *By blood and table.* The full oath, shortened.
- *The wine remembers.* A short oath was broken, and the Crown has noted.
- *He sits at the Morning Table.* He has been granted a private audience with the king.
- *The orchard is full.* A House has lost its heir and has no successor.
- *Drink from the amber cup.* To be brought into a royal secret. (Older generations use this; younger do not know the source.)

## Attitude towards the other four cultures

**Faith.** The Ashcrown regards the Faith as a tolerated partner — useful for marrying commoners and burying them, necessary for the legitimising omen at a coronation, but in no way a superior. Darrik Voss says, privately, that the Unsleeping is a *frightened woman holding a stone she doesn't understand*. The commoner view is gentler: septons are respected, septas are feared, and the Septa of Mistmere is a distant weather in the north.

**Free North.** The Ashcrown respects the Free North in the way one respects an old uncle who drinks too much. The clans are held to be stubborn, honest, and incapable of ruling anything larger than a valley. A Voss dinner-guest from the north is seated high, served the nine dishes, and quietly not invited back. The commoner view is that northerners are *walking stones*: slow, heavy, and will crack a floor if they dance.

**Union.** The Ashcrown is deeply wary of the Union and hides the wariness under elaborate courtesy. Merchants are received at court; merchants are not seated at the Morning Table. Tobiah Caul is called *the Consul-Merchant*, never *Your Grace*. The commoner view is that Union men are clever, loud, and will sell a man his own shadow for a copper.

**Fog.** The Ashcrown does not recognise the Fog as a culture. It recognises the Ashen Herald as a persistent nuisance who has been writing letters for three years. Commoners know the Fog as a weather and a bad dream; the royal court knows the Fog as a political fiction that refuses to die.

## Attitude towards the Chasm & Depth-Walkers

The public stance is that the Chasm is a northern curiosity and the Depth-Walkers are a fringe cult tolerated because suppressing them would cost more than ignoring them. Ashcrown edicts refer to the Chasm as *the Great Cliff of the North*, never as a chasm — a linguistic tic the court has held for two centuries without explanation.

The private suspicion, known only to the reigning king and the King-Apparent, is that the Depth-Walkers are the Crown's own miners in robes. The Listeners operate under a sealed royal contract; the Crossers are a defection the Crown has not yet decided how to handle. Darrik Voss personally reviews the relic-inventory brought up by Listener Archdepth Sula once every third moon.

The Ashcrown's policy on Depth-Walkers is **contain**, not destroy. A destroyed Listener order becomes a Crosser order. A contained Listener order continues to mine.

## Storyline hooks

Named NPCs from this culture:

- **King-Apparent Darrik Voss** (T005, Line C soul)
- **Envoy Alric of House Voss** (T004, Line C)
- **Magister Corvin Ashford-Reed** (T005, Line A soul — House Ashford-Reed is the absorbed cadet of the Ashcrown and carries the old hyphen)
- **Lord Commander Linden Ironfist** (T003, frontier — House Linden sword)
- **Corporal Hest** (T003, Guild livery but Ashcrown-born, suppression officer)

Storyline beats that rely on this culture's norms:

- The Morning Table summit chamber at Mistmere (Line C T005) — four chairs, a brass cup of southern wine served to the Union, the ritual sealing in the Crown's voice. The brass cup is one of Tobiah's twelve. The Crown set the table knowing.
- The amber tea ritual at the Jade Lantern (Line C T004) — Alric's exact four-minute steep, the brass travel-cup, the refusal to share. This is Ashcrown royal discipline on display.
- The Linden oath-blade (Line C T003) — Linden Ironfist is Ashcrown-adjacent and swears by the Linden rite; his refusal to go further than permission is the Crown soldier's discipline under frontier pressure.
- The four-knot ring on Darrik's thumb (Line C T005) — physical proof of royal descent, silently read by every House-born in the room.
- The orchard plum reference (any T005 feast) — if served, it is a coronation gesture. The world-agent must not serve it casually.

Idiosyncrasies a town writer must preserve:

- Ashcrown royals do not kneel. Not to Septas, not to kings of other realms, not at funerals. The knee is never set to any floor.
- Ashcrown envoys do not eat in public. Alric does not eat in the Jade Lantern; he only drinks. A Voss man takes his meals in his own quarters.
- Ashcrown funerals are closed. A royal body is never displayed. A commoner funeral is open but small, family only, and strangers are not welcomed at the graveside.
- The word *chasm* is not spoken at court. The Crown says *the Cliff*, *the Great Cliff*, *the northern cliff*. Any Ashcrown NPC, anywhere in the five towns, should use *cliff* without comment, and if a player presses, the NPC should change the subject.
- The colour deep red is not worn. Ever. By any Ashcrown character. Even the tavern girl who serves an Ashcrown envoy will have changed her shawl before the night.

<!-- writer-only
## Inner circle knowledge

Darrik Voss knows the following, taught to him by his father on the night of his twenty-first birthday, in a sealed reading-room, by oral transmission only:

1. The Ashcrown royal line descends from colonists who crossed from the far side of the Great Chasm in an earlier age. The elven trace is not elven — it is a physiological adaptation inherited from the colonists themselves. The long lives, the slit pupils in bright light, the elongated lobeless ears — these are markers of the colonial bloodline, diluted but preserved by careful House-marriage.

2. Contact with the far side stopped a hundred years ago. Darrik has been taught two competing theories: (a) the far side collapsed, which is the comforting theory; (b) the far side cut us off, which is the true fear. His father holds (b); Darrik privately holds (a) and is beginning to suspect (b).

3. The warning *Eternal-life × Gold × Infinity. Do not visit.* was sent from the far side to the colonists, not from the colonists to us. The colonists were told not to attempt a return. The warning has been mistranslated into the Iron-Dragon legend.

4. The amber tea Darrik drinks is a far-side preservative compound (the court vocabulary is *the leaf of the long breath*). Its effects on the royal body include the extended lifespan and a slow thinning of the hair in late middle age. Darrik does not fully trust it but drinks it because his father drinks it.

5. Relics found underground are believed (in Crown theory) to be buried transit infrastructure from the colonial period — the far side's old underground roads, partially collapsed, partially preserved. This is not a theory Darrik shares with any other crown. The Crown's Archivist has written a sealed monograph on this point; only three men have read it.

6. Four crowns have an agreed cover story: admitting the colonial history would reduce all four kingdoms to provinces of a place none of them has seen. The cover is the legitimacy vacuum rationale. Darrik understands this is the *surface* cover; the deeper agreement is that if the far side is returning, a unified local front is the only defence.

7. The Ashen Herald is known to the Crown as a single individual, female, mid-thirties, formerly of the Morning Table Guard. She deserted nine years ago after reading the sealed Crown monograph. Darrik has been looking for her for three years.

8. The Depth-Walker Listeners operate under a royal contract renewed every nine years. The current contract was signed by Darrik's father. Darrik will renew it in two years. Archdepth Sula is known to Darrik by sight.

9. The Crossers are a defection Darrik has not yet decided how to handle. If they succeed in crossing the Chasm and contact the far side, the Crown's worst theory becomes operational. If they fail, they become martyrs and the Listener order fractures. The Crown's current policy is to let Navigator Kestrel continue his work, observe, and intercept only at the moment of attempt.

10. The Northern Ban decree was drafted in Darrik's great-grandfather's reign, in coordination with the Faith, the Free North, and the Ashen arbitration Guild. The four original seals are kept in a single sealed box in the Morning Table's inner chamber. Darrik has seen the box. He has not opened it.

The vocabulary used inside Crown court for these matters is precise and modern-adjacent: *transit*, *bloodline dilution*, *preservative compound*, *colonial-era infrastructure*, *the sealed monograph*. None of this vocabulary is permitted outside the reading-room. Outside, Darrik uses *cliff*, *old work*, *the amber leaf*, *the buried thing*.
-->
