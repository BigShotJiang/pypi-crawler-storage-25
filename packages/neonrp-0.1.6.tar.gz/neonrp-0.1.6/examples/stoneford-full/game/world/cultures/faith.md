# The Faith Kingdom — The Seat of the Unsleeping

## Snapshot

The Faith is a theocratic kingdom held together by oath and omen, ruled from the Grand Cathedral at Mistmere by a High Septa who has not slept in ten years. Its folk are mixed-blood, robed in wet-ash grey, and taught that a word spoken under the Pattern is heavier than a word written under a crown.

## Governance

The Faith is ruled by the **High Septa**, an office elected for life by the College of Nine Septons from among the seated Septas of the nine provincial cathedrals. The current High Septa is **Malen the Unsleeping**, elected eleven years ago at the age of thirty-nine.

Below the High Septa sit the **Nine Septas** — one per provincial cathedral — and beneath each Septa a tier of septons (clerics), preceptors (scribes and scholars), and novices. The hierarchy is ecclesiastical throughout; there are no secular lords. A Faith landholder holds his land from the nearest cathedral, not from a king.

Power transfers on the death of the High Septa. The nine Septas convene at Mistmere, fast for three days, and on the fourth day each Septa writes a single name on a folded strip of grey linen. The strips are burned together; the name that appears last in the ash-reading is the new High Septa. The reading is performed by the oldest septon still living, who is held to be the Pattern's eye for that hour.

Arbitration is by **the Septa's chair**. Any dispute between Faith subjects — common or ordained — is brought to the provincial Septa, who hears both sides in a single sitting, without scribes, and gives judgement orally. The judgement is not written down. It is remembered. The Faith holds that a written judgement is a dead one.

Execution is by **the grey rope**. A condemned subject is bound in grey wool and left on the cathedral steps at dawn, unfed and unspoken to, for three days. On the third dawn the Septa pronounces either the ending (strangulation by the rope, performed by a novice) or the commutation (the rope is cut and the subject is exiled to the coast). Malen has pronounced the ending four times in her reign. She has pronounced commutation ninety-one times.

## Bloodline / race

The Faith is the most mixed-blood of the four kingdoms. Its subjects intermarry freely — Ashcrown southerners who migrated north for the pilgrimage, Free-North clansfolk who settled for the cathedral stipend, Union merchants' children raised in Faith orphanages, and a small but persistent population of mountain-blooded hill-folk from the eastern ranges.

The Faith teaches that **the Pattern has no preferred thread**. A Septa can be elected from any bloodline. The current High Septa is herself the daughter of an Ashcrown grain-merchant and a Free-North midwife; her features carry both — the aquiline southern nose and the broad-boned northern jaw.

Interbreeding attitudes are actively encouraged. A Faith marriage between two subjects of the same bloodline requires a small additional oath — *that the children shall be raised to love the thread unlike their own*. There is no stigma to mixed parentage; children of unclear paternity are taken into the cathedral schools and raised as **Pattern-children**, a quiet pride.

The Faith acknowledges no high-fantasy lineages. There are no elf-blooded septas, no dwarf-blooded septons. The Faith teaches that such claims are vanities. When an Ashcrown royal visits Mistmere, the Septas privately note the long life and the narrow pupil but do not record it; the High Septa is doctrinally bound not to examine a royal body.

## Economy

The Faith's economy is **tithe and pilgrimage**. Every Faith hearth pays a tenth of its grain, wool, and cured meat to the provincial cathedral at the autumn harvest. The cathedral redistributes to the orphanages, the septon-schools, and the cathedral's own granaries, held for years of famine.

Pilgrimage is the second engine. Mistmere draws pilgrims from all four kingdoms during the winter solstice, when the cathedral's great bell rings for nine nights. A pilgrim pays a coin at the gate, sleeps in the cathedral's outer cloisters, and leaves on the tenth day with a small grey stone (a *pilgrim's token*) blessed at the altar.

The Faith trades wool, grey-dyed linen, cathedral candles, and blessed stones. It imports grain from the Ashcrown in lean years and iron tools from the Union.

Tax is collected by septons at the harvest and recorded in the cathedral's Grey Ledger, a book that stretches back four generations. The Grey Ledger is a record of obligation, not of wealth; the Faith does not count coin, it counts debt and gift.

Currency: the Faith accepts Ashcrown silver and Union paper at standard weight, but within its own borders it prefers the **cathedral copper** — a thin copper disc stamped with the four-knot and the Pattern-ring, valid only for payments to the cathedral and for certain blessed-goods in the cathedral towns. A Faith commoner keeps a pouch of cathedral copper for tithe and a pouch of royal silver for trade with outsiders.

## Food

The staple is **grey-bread and goat-milk**. The bread is made from a blend of rye and hill-barley, leavened with a sourdough that the cathedrals have kept in unbroken cultivation for six generations. The goat-milk is soured to a thin yogurt, eaten with the bread at every meal.

Feast food is **the seven bowls**: seven small bowls set in a circle around a central candle. The bowls hold boiled hill-root, soured goat-cheese, lentils in oil, pickled cabbage, rye-crumb porridge, cured mutton, and honey. Each diner reaches for bowls in the order they were served by the Septa; the Septa sets the order, and the order may change from feast to feast.

Travel food is **stone-bread** — a hard biscuit of rye flour, salt, and goat-fat, baked until it rings when struck. A pilgrim's ration is three stone-breads per day; a septon on circuit carries a week's supply in a leather bag.

Sacred food is **the wafer** — a small disc of unleavened flour-and-water bread, blessed by a Septa, placed on the tongue of a supplicant during the Pattern-rite. The wafer is made from grain grown in a cathedral's own granary; common grain is never used.

Forbidden food is **the blood-sausage**. The Faith holds that blood is the Pattern's own ink, not food. A Faith subject who eats blood-sausage (a Free-North staple) is said to have *drunk ink*, and must make a pilgrimage to the nearest cathedral to be cleansed.

## Dress

Daily dress is **grey linen**. Men wear a loose tunic to the knee over rough trousers; women wear a gown to the ankle with a draped shawl. The grey is undyed in the south, dyed with wet-ash pigment in the north, and almost black in the capital.

Ceremonial dress is **the septa's robe** — a full-length heavy robe in *wet-ash grey*, the colour of the stone at the cathedral's foundations after rain. The robe is cut straight, without belt, and falls to the floor. A Septa wears a grey collar of stiffened wool; the High Septa's collar is embroidered in silver thread with the nine-ring pattern.

Military dress is **the Faith militia** — there is no standing army. In emergencies the cathedrals raise a militia of volunteer pilgrims, issued a grey surcoat and a long staff with an iron butt. The militia is drilled for two weeks in autumn and dismissed after. Its function is pilgrimage-road defence, not war.

Colours are grey, grey, grey, and a single silver thread. Other colours are considered a vanity and are not worn by the ordained. Laity may wear undyed brown or white; bright colours are tolerated but frowned upon.

Fabrics: wool, linen, goat-hair. Silk is forbidden to the ordained (it is considered a Union vanity). Leather is worn only by the pilgrimage-road militia.

Taboos: no head-covering in the cathedral except the septa's collar. The head must be bare before the Pattern. A pilgrim removes any hat at the gate and receives a grey cord to tie around the wrist in its place.

## Rituals & holidays

**Birth.** A Faith child is carried to the nearest septon within three days and given a single drop of water on the forehead, then named in the child's own family's hearing. The name is spoken three times. It is not written.

**Marriage.** The parties stand before a Septa at the cathedral threshold. They do not kneel. The Septa lays a hand on each shoulder and speaks the **Binding Word**: *"By the Pattern that wove you, by the Pattern that will unweave you, by the silence between those two weavings, be bound."* The parties then exchange a pilgrim-stone each. The stones are kept for life. When one spouse dies, the surviving stone is buried with the body.

**Death.** A Faith body is washed in cold cathedral-well water, wrapped in undyed linen, and laid in a common grave at the cathedral's burial-field. There are no markers. A family places a single grey stone, unmarked, at the head. After three generations the grave is considered returned to the Pattern and may be re-used. The Faith does not believe in preserved bones.

**Seasonal festivals** are four, called **the Nine Bells** cycle at each equinox and solstice. The winter solstice is the greatest: the cathedral's great bell rings for nine consecutive nights, and pilgrims sleep in the outer cloisters. The Faith holds that during the Nine Bells the Pattern is closest to the weaver's hand and oaths sworn in those nights are double-bound.

**Military oaths** are sworn on a grey stone held in the palm. The swearer speaks: *"By the Pattern, by the stone, by the silence in the weave."* The stone is then pressed into the cathedral wall for a day and returned to the swearer. If the oath is kept, the stone is buried with him. If broken, the stone is returned to the cathedral and ground to powder.

## Oath forms

The Faith swears **by the Pattern and by the silence**. The full form is: *"I swear by the Pattern that wove me, and by the silence at its edge, that this word is the word I will keep. Let the Pattern unweave me if I lie."*

Oaths are sworn on a **grey stone**, a **pilgrim's wafer**, or — for the highest oaths — on **the Septa's own palm**. A palm-oath is life-binding and has been sworn only nine times in Malen's reign.

The penalty for breaking a Faith oath is **the grey rope** for life-oaths, **pilgrimage** (barefoot, fasting, three cathedrals) for season-oaths, and **the wafer returned** for contract-oaths. The wafer-returned is a quiet shame: the offender is handed a grey wafer at the cathedral gate, in public, and must eat it before the Septa. The Faith holds that the act of eating one's own broken oath is the worst shame available.

The idiom *she holds a grey stone* means she is under oath and cannot speak freely. The idiom *the wafer is coming* means a reckoning is near. The idiom *the Pattern is silent* means the gods have withdrawn — a phrase Malen herself uses in private and that her septons are beginning to dread.

## Law & punishment

Faith courts are the Septa's chair. A subject brings complaint; the Septa hears it in a single sitting. Judgement is oral. No record. The Faith believes that a living memory is a more honest record than a written one.

Common crimes: withholding tithe, breaking a sworn word, striking a septon, and (most seriously) **speaking in the cathedral** — that is, breaking the silence of the inner altar-space. The first three carry restorative sentences (additional tithe, pilgrimage, fasting). The last, if deliberate, is the grey rope.

A commoner fears the law as **a silence that is listening**. Faith law does not threaten; it waits. A subject who lies to a septon will feel the lie settle in his stomach for years, and will eventually walk to the cathedral himself to confess. This is considered a working of the Pattern, not a psychological phenomenon.

The Faith's most feared punishment among commoners is **being unnamed**. A subject who commits a crime the Septa judges unforgivable has his name struck from the cathedral roll. No Faith subject may address him by name again. He is referred to as *the one whose name is not spoken*. He may still live, eat, trade — but he cannot marry in the Faith, cannot be buried in the Faith, and his children are born without a name-line.

## Military style

The Faith has no army. In emergency the cathedrals raise a **pilgrim militia** — volunteers drawn from the pilgrimage-road hostels, drilled for two weeks each autumn. Their doctrine is **the circle**: a militia band forms a ring around the cathedral or the pilgrim it protects, bells ringing, staves presented outward. They do not march. They do not charge. They hold ground until relieved.

Unit types: only one, the **staff-pilgrim**. Armed with a six-foot hardwood staff tipped in iron, a small grey stone in the belt, and a leather pouch of hard bread and salt. No armour beyond a padded grey surcoat.

Weapon preferences: the staff, the sling (for distance), the small knife (for utility, never sworn upon). The Faith will not use the bow. Arrows are considered *ink without a word* — a killing without voice — and are taboo in cathedral armouries.

The Septas themselves do not fight and are not expected to. Malen the Unsleeping carries only a grey stone and a silver-threaded collar. She is said to be protected by the Pattern; in truth she is protected by six trained pilgrim-guards drawn from the winter solstice's best militia, who sleep in turn at her door.

## Religion / metaphysics

Official belief is **the Pattern**. The Pattern is an unwritten cosmology: the world is a weave, each life a thread, each death an unweaving, each oath a knot that holds two threads together. There are no named gods. There is only the Pattern, the weaver (unnamed, unimaged), and the silence at the edge where the weave ends.

The folk variant is **the grey stones speak**. Every Faith household keeps a few grey stones from the cathedral visit, placed at the hearth, the threshold, and the bedside. Folk belief holds that the stones hear prayers and sometimes answer — a small warmth in the palm, a whisper at the ear in the dark. Septons discourage this; the High Septa herself secretly practises it, because one of her stones actually whispers to her, and she cannot admit it.

The Faith's relationship to the Fog is **the silence at the edge**. The Pattern's edge is doctrinally where the weave ends, and the Fog is the physical manifestation of that edge — the place where the Pattern has not yet been woven, or has been unwoven. Septons travel into Fog with an iron bell and a grey stone; they walk in silence; they do not speak until they return. A Fog-silenced pilgrim (one who lost his voice in the Fog) is honoured for life.

Malen reads the hundred-year silence from the colonists as **the Pattern's withdrawal**. She believes the weaver has stopped weaving in the north, and that her own sleeplessness is a symptom of the withdrawn thread. This reading is the axis of the current Faith crisis: if the Pattern has withdrawn, the Faith's legitimacy is withdrawing with it.

## Language & address

The Faith tongue is **cathedral-tongue**, a slow liturgical form of the common northern speech. Every Faith subject learns it from the septons. Prayers and oaths are spoken in it; daily trade is done in the local vernacular.

A commoner addresses a septon as **father** or **mother**, regardless of age or sex. A Septa is addressed as **Holiness** with a kneel. The High Septa is addressed as **Unsleeping Holiness** or, informally among the clergy, **the Seat**.

A Faith subject addresses an Ashcrown lord as **Your Grace's faithful** (a slight barb — the word *faithful* implies a subordinate relationship to the Faith, which the Ashcrown politely ignores). A Faith subject addresses a Free-North clan-head as **hearth-mother** or **hearth-father**, acknowledging the clan's domestic seat. A Faith subject addresses a Union consul as **merchant-sir** or **merchant-madam**, a slightly cool form.

Idioms:

- *She holds a grey stone.* Under oath, cannot speak freely.
- *The wafer is coming.* A reckoning is near.
- *The Pattern is silent.* The weave has gone still; the gods have withdrawn.
- *He walks the nine bells.* He has undertaken a winter pilgrimage and will not be home until the Pattern-year turns.
- *Her thread is short.* She is near death. (Said gently, never to the dying themselves.)

## Attitude towards the other four cultures

**Crown.** The Faith treats the Ashcrown with careful respect and careful reserve. Coronations require a Septa's blessing; the Septas give it. But the Faith teaches, quietly, that a crown is a garment and the Pattern does not wear garments. Commoners view the Ashcrown as a distant southern weather — taxes and laws come from it, but piety does not.

**Free North.** The Faith respects the Free North's oath-tradition and is uneasy about its blood-rituals. A Faith septon in a Free-North valley will eat at the hearth, drink the clan-ale, and quietly excuse himself when the blood-sausage comes out. The High Septa has corresponded with Chieftess Brenna on three occasions. The letters were courteous.

**Union.** The Faith views the Union as a well-meaning but spiritually shallow culture. The Union's contracts are respected as binding, but the Union's merchants are held to *count too many coins and weigh too few stones*. A Union trader is welcome in a Faith town if he tithes; if he does not tithe, doors close quietly.

**Fog.** The Faith's official position is that Fog is the Pattern's edge and must be approached with silence and iron. The Ashen Herald is considered a heretic, but a heretic whose theology is disturbingly close to orthodox Faith doctrine — the Herald's claim that *nothing written survives* is the dangerous inverse of the Faith's own preference for unwritten judgement. Malen has privately forbidden her septons to debate the Herald publicly, because a public debate would make the resemblance visible.

## Attitude towards the Chasm & Depth-Walkers

Public stance: the Chasm is *the Pattern's end*, the edge beyond which the weave does not reach. Pilgrimage to the Chasm's rim is permitted; descent is discouraged. The Depth-Walkers are heretics who invert the Pattern — they look below rather than holding the middle. The High Septa has issued three rulings against the Depth-Walker order in her reign.

Private suspicion: the High Septa does not know. Malen the Unsleeping has no colonial knowledge. She reads the Depth-Walkers as genuine heretics and the Chasm as a genuine theological boundary. This makes her the most theologically sincere of the four sovereigns — and, because sincerity without colonial knowledge cannot explain the whispering stones in her chambers, the most dangerously destabilising.

Malen has ordered the arrest of any pilgrim who has *descended below ground*. Linden Ironfist has reported this. She does not know why the order disturbs her; she only knows that the Pattern, when she consults it, returns silence.

## Storyline hooks

Named NPCs from this culture:

- **High Septa Malen the Unsleeping** (T005, Line C soul — does not know colonial history)
- **Septon Silas** (T004/T001, Line B carrier — novitiate at Wolfsjaw under Eilin)
- **Preceptor Vossel the Younger** (T002, Line B sub-soul — copies Eilin's gestures in a hollow psalter)
- **Novice Taryn** (T003, Line B — Eilin's translator, fourteen years old)
- **Abbot Merick** (T003, Line B — abbot who approved Eilin's muting)

Storyline beats that rely on this culture's norms:

- The Grand Cathedral at Mistmere (Line C T005) — the summit chamber is beneath it; the bricked-up door on the north wall bears the four-knot seal in fired clay. Malen does not know what is behind it.
- The refused letter (Line C T003) — Silas writes to Malen about the glyphs 上下相通. She refuses him in three lines. The refusal is diagnostic: Malen does not know, and cannot afford to show she does not know. This is the Faith's current crisis of belief.
- The grey stone that whispers (Line C T005) — Malen carries a distant-voice stone she believes is a penitential token. It whispers to her at night in a woman's voice. She does not know what it is. She has brought it to the summit.
- Eilin's muting (Line B T003) — approved by Abbot Merick under the Crown's pressure. The Faith's willingness to cut a scholar's tongue to protect the monastery tells the player what the Faith will do to survive.
- The Northern Ban decree (Line A T003) — co-signed by the High Septa of the previous generation. The decree forbids the naming of *sun-nailed-to-tower, house-that-flies, iron-that-sings-like-a-forge, the-unending-road*. Malen was not the drafter; she inherited the enforcement.

Idiosyncrasies a town writer must preserve:

- Faith subjects do not write where they can speak. A Faith NPC asked for a written receipt will balk and offer a witnessed oral promise instead. A Septa never writes a judgement. A Faith marriage is never recorded.
- Faith subjects do not eat blood. A blood-sausage offered to a Faith NPC is a serious social breach. The NPC will refuse gently and the offering host will be embarrassed for three days.
- Faith subjects wear grey. An NPC in any other colour is either a laity-tolerant edge-case or is making a statement. Bright-colour Faith subjects do not exist.
- Faith subjects do not cover their heads indoors. A hat removed at the door is the Faith manner.
- The Pattern is never imaged. No icon, no painting, no statue. A cathedral is empty of figures. The altar is a plain grey stone. Any Faith NPC will react to a Crown portrait or a Union mercantile carving with polite disturbance.
- *The Pattern is silent* is a phrase spoken by no commoner. Only Malen speaks it. If a septon is heard using it, the player should mark the moment — it means the septon has begun to doubt the weave.

Canon note: Malen's ignorance is canon (SHARED_BRIEF §24). She reads the hundred-year silence as divine abandonment, not colonial collapse. No Faith NPC, including Malen, may be written with modern vocabulary or colonial knowledge. The distant-voice stones, the unaging tea, and the un-hammerable metal are all, to the Faith, *objects of the Pattern's unexplained working*. Faith NPCs encountering these items react with religious dread, never with recognition.
