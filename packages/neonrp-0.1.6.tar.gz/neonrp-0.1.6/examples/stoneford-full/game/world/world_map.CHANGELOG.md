# world_map.json — Changelog

## 2026-04-14 — Canon alignment pass

Rewrote `world_map.json` to reflect the 5-town storyline canon. Preserved schema, `world_id`, `seed`, and `time`. Preserved T001, T002, D001, R001, R002 verbatim (only added `links` entries).

### Nodes added

- **T003 Wolfsjaw Pass** — northern frontier fort (from `towns/T003/town.json`). Placed far north-west, adjacent to the Brokenspine.
- **T004 Jadehollow** — mining/trade town (from `towns/T004/town.json`). Placed north-east in the mountain vein.
- **T005 Mistmere** — capital of the Grey Reach on a lake (from `towns/T005/town.json`). Placed south-east, downstream from Stoneford for river access.
- **D002 Jadehollow Mines — Level Three** — sealed mine level referenced in `rumors.md` and `T004/quests.json` (Q_T004_01, hibernating Frostwolf megabeast). Adjacent to T004, `blocked: true` on access route to reflect the seal.
- **D003 The Sunken Ward** — cistern beneath Mistmere with sealed descent-shaft, from `storylines/E-depth-walkers.md`. Adjacent to T005.
- **D004 Brokenspine Watchtrail** — ridge north of Wolfsjaw referenced in T003 atmosphere, `species.md` (Hollowjaw Wolf habitat), and Frostwolf border (storyline C). Serves as the staging node between Wolfsjaw and the Chasm.
- **N001 The Great Chasm** — landmark, far-north endpoint from `lore/beyond-the-world.md`. `discovered: false`, reachable only via D004.

### Routes added

- **R003** T002 ↔ T003 — Grey Road continuation (military, cold).
- **R004** T003 ↔ T004 — mountain pass across the Brokenspine foothills.
- **R005** T004 ↔ T005 — ore-caravan trade road to the capital.
- **R006** T001 ↔ T005 — river/foggy trade route (Stoneford is a river port downstream of the capital's lake outflow).
- **R007** T004 ↔ D002 — short mine-access trail, currently blocked (mine seal).
- **R008** T003 ↔ D004 — frontier trail into Frostwolf-patrolled ridges.
- **R009** T005 ↔ D003 — short urban/hidden trail to the Sunken Ward.
- **R010** D004 ↔ N001 — trackless final approach to the Great Chasm's edge.

### Notes / follow-ups

- Town summaries kept in Chinese (short) to match T001/T002 existing style.
- Dungeon and landmark summaries in English, matching D001's hybrid style.
- No storyline dungeons dropped. Any additional instanced locations referenced inside storylines (e.g., private manors, caravan camps) are intentionally not surfaced here — world_map is region-scale.
- Positions are a coherent 2D grid with north = negative Y; adjust if a renderer assumes otherwise.

## 2026-04-14 — Writer-Dungeons expansion (D005–D009)

Added the five new dungeons produced by the Writer-Dungeons pass. No existing nodes or routes modified; `world_id`, `seed`, and `time` preserved.

### Nodes added

- **D005 Olric's Barrow** — Faith-era crypt half a league south-west of Wolfsjaw Pass (T003). pos [3, -9], danger 2. Source: `dungeons-design/D005-olric-barrow.md`.
- **D006 The Old Exchange Vault** — sealed Union merchant-vault in Stoneford's lower sewer. Modeled as a dungeon node with `sub_of: T001`, sharing T001's pos [12, 7]. danger 2. Source: `dungeons-design/D006-old-exchange-vault.md`.
- **D007 The Fogmoor Hide** — Fog-walker outlaw camp on a reed-island in the fen off R001. pos [9, 9], danger 3. Source: `dungeons-design/D007-fogmoor-hide.md`.
- **D008 The Crosser Workshop** — hidden Crosser engineering workshop off T004's scarp (explicitly not off D002's Deepvein map). pos [17, -2], danger 3. Source: `dungeons-design/D008-crosser-workshop.md`.
- **D009 The Second Sun Crag** — First-Wave landing-beacon ruin two days east of Wolfsjaw, between T003 and T004. pos [10, -6], danger 3. Source: `dungeons-design/D009-second-sun-crag.md`.

### Routes added

- **R011** T003 ↔ D005 — barrow-trail, foggy, old-road, faith. Short pilgrim path.
- **R012** T001 ↔ D006 — cellar-passage, hidden, town-internal. Trivial distance; entry via the Shale Lantern drain.
- **R013** T001 ↔ D007 — off-road, hidden, boggy. The hide is off R001's south side; anchored to T001 rather than splitting R001.
- **R014** T004 ↔ D008 — hidden-trail, crosser-only. `blocked: true` by default: gated by E-line progression / Crosser access.
- **R015** T003 ↔ D009 — crag-trail, stone, exposed. Two-day walk east through pine and scree.

### Rationale

- D006 uses the dungeon-node approach with `sub_of: T001` (per task spec) for consistency with other dungeons, rather than introducing a new facility schema.
- D007 routed from T001 rather than as a split mid-way on R001 to avoid mutating R001; the "off R001 side-trail" semantics are captured via tags (`off-road`, `hidden`) and a realistic 10-unit distance.
- D008 routed from T004 only, per spec — it is explicitly not off D002.
- D005 and D009 both hang off T003 — consistent with Wolfsjaw's role as the northern hub.
- All new dungeons `discovered: false`; danger 2–3 reflects surface/non-megabeast content compared to D002/D004 (danger 4).
