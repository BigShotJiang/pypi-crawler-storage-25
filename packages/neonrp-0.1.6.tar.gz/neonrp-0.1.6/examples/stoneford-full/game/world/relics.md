# The Relic Catalogue of the Grey Reach

> A working roster, kept in the Northern Guild's deep cabinet at Stoneford and
> copied — with gaps, with lies — into the ledgers of four crowns. The catalogue
> was begun by Magister Olric's hand two centuries ago. It has been continued,
> never finished. Each relic is a thing that should not be here. Each has been
> pulled up out of the ground by somebody, and each has cost somebody else
> something that the catalogue does not always name.
>
> Listeners assign a personal name to every relic at the moment of surfacing.
> The name is the last word of the ritual of bringing-up. Guild archivists
> append a catalogue ID afterward, usually grudgingly. Where a relic has no
> Guild ID, it is because the Listener who found it refused to register it,
> or because the relic was taken by a king before the Guild arrived.
>
> The tiers are not depths. They are correspondences: a shallow-find made at
> great depth remains a Shallow-find, because the tier names what the object
> *does* under the hand, not where the hand reached for it.

## Tier system

- **Tier A — Shallow-finds.** Surface dig. Partial function. Minor cost.
- **Tier B — Bone-tier.** Found at or near the bone-rooms. Obvious function, obvious cost.
- **Tier C — Wet-tier.** From the wet-silence level. Rules partially understood; the cost arrives later than the using.
- **Tier D — Lantern-Dies tier.** The deepest accessible workings. Rules only guessed.
- **Tier E — Royal-Held.** Not in public circulation. Held by Crown, Faith, Free North, Union, or by the senior Guild.
- **Tier F — Unknown.** One-offs, rumours, catalogued but nobody alive has seen them.

---

## Tier A — Shallow-finds

### Little Voice / Tier-A / GUILD-A-0041
- **Tier:** A
- **Discovered:** Pulled up at the Mossbarrow shallow by a miner called Hett, roughly thirty years ago. Hett gave the name on the spot: "It is small and it is voicing."
- **Appearance:** A palm-weight of dull grey stone, warm, with a flat side the size of a coin and a curved side that fits the ear. The flat side bears a single worn glyph that Eilin reads as *sai* with part of the curve lost. It smells faintly of hot iron.
- **Behaviour:** Held to the ear in a quiet room, it returns the sound of a woman humming a tune nobody present has ever heard. The tune is always the same seven notes.
- **Cost:** The person who holds it for the count of a hundred forgets a lullaby they knew in childhood.
- **Custody:** Stoneford Guild deep cabinet, middle shelf, in a felt-lined box.
- **Rumour:** Commoners who have heard of it think it is a pebble from a saint's grave.
- **Storyline links:** A (catalogue item), referenced obliquely in E (Sula says "the littlest are the loudest" and may mean this one).
<!-- writer-only -->
- **Real nature:** Fragment of a solid-state audio memory module. The humming is a recorded loop from a personal device. The "forgetting" is a mild electromagnetic interference with hippocampal retrieval; in this world, any handler for >90 seconds loses exactly one associated auditory memory.
<!-- /writer-only -->

### The Husband / Tier-A / GUILD-A-0077
- **Tier:** A
- **Discovered:** Surfaced forty years ago by the widow Margret, who took one look and said, "That is a husband. I will not keep it." The Guild took it from her hearth.
- **Appearance:** A smooth white plate the size of a bread-trencher, cool to the touch even in summer, with a lip around one edge. The underside has four small round feet of the same material. No seam, no join.
- **Behaviour:** A slice of bread laid on the plate is still warm at dawn if laid down at dusk. Cold meat is still cold. The plate does what the food was doing when it was put down.
- **Cost:** The household that uses the plate for a full season begins to have arguments it cannot remember starting.
- **Custody:** Guild, Stoneford — loaned out once to the Crown envoy at Wolfsjaw for a midsummer feast; returned three days later with the envoy refusing to say why.
- **Rumour:** A widow's saint-charm. A common joke in Stoneford taverns is "that man is a Husband," said of an unhelpful thing that looks useful.
- **Storyline links:** A (catalogued), C (the Wolfsjaw envoy episode).
<!-- writer-only -->
- **Real nature:** A ceramic thermal-stasis tile from a domestic food-preparation surface. Retains the thermal state of whatever is set on it for ~12 hours via a slow-acting phase-change layer. The "arguments" effect is probably coincidence; two Listeners disagree.
<!-- /writer-only -->

### Kettle-That-Remembers / Tier-A / GUILD-A-0102
- **Tier:** A
- **Discovered:** Pulled up twenty-two years ago at the shallow dig north of Stoneford by the Listener Obel. He named it while it was still wet.
- **Appearance:** A squat black kettle with no visible seam, its handle a single loop of the same metal as the body. It weighs less than a kettle of that size should weigh. The base carries the glyph *vel* faintly, so faintly that two Listeners deny it is there.
- **Behaviour:** Water boiled in this kettle, once, takes its full time. Water boiled in this kettle a second time in the same day boils in a third of the time. A third boiling is instantaneous and the handle is cold.
- **Cost:** A cook who uses the kettle daily for a year finds that they cannot remember the taste of the first tea of any morning.
- **Custody:** Stoneford Guild kitchen, for use by the Magister on audit days. Corvin Ashford-Reed uses it. He drinks tea he cannot taste.
- **Rumour:** A lucky kettle. Every tavern would like one.
- **Storyline links:** A (in active Guild use), cross-reference to the Unbroken Kettle (Tier E).
<!-- writer-only -->
- **Real nature:** Inductive heating element with residual charge-holding capacitor. Repeated short-cycle use draws from stored charge rather than full cold-start. The taste-memory cost is genuine but unexplained even writer-side.
<!-- /writer-only -->

### The Small Brightness / Tier-A / GUILD-A-0118
- **Tier:** A
- **Discovered:** Ten years ago, in a cellar beneath a collapsed tanner's shop at Stoneford. Listed by the finder — a boy named Mar — as "the small brightness the cellar had."
- **Appearance:** A thumb-long rod of translucent material the colour of weak tea. One end is flat, one end is rounded. Weight of a hen's egg. No markings.
- **Behaviour:** Laid on a ledger at dusk, it gives off a pale yellow light for the length of one candle's watch. Shaken, it goes out and will not light again for a day.
- **Cost:** The room it lights smells, the morning after, of a flower no one in the Reach recognises.
- **Custody:** Guild clerk's desk, Stoneford. Used for late audits.
- **Rumour:** A holy nightlight. Mothers would pay for one.
- **Storyline links:** A.
<!-- writer-only -->
- **Real nature:** Chemiluminescent or low-voltage glow rod; residual illumination device. The flower scent is an outgassing artefact of the degraded casing.
<!-- /writer-only -->

### Eight-Grain / Tier-A / GUILD-A-0133
- **Tier:** A
- **Discovered:** Surfaced fifteen years ago under a hearthstone at the old ferry-house, Stoneford.
- **Appearance:** A flat disc of pale metal, slightly warm, the size of a wafer, etched on one face with eight concentric rings. The rings do not quite close.
- **Behaviour:** When placed in a bowl of grain, the grain does not spoil for a season. When placed in a bowl of meat, the meat spoils faster than meat alone.
- **Cost:** The keeper of the disc develops a small, unfading grey spot on their tongue.
- **Custody:** Stoneford Guild, under Magister Corvin's seal.
- **Rumour:** A grain-saint's pledge, bought from a traveller.
- **Storyline links:** A.
<!-- writer-only -->
- **Real nature:** Preservation puck — a radiative sterilization disc that kills microbes on carbohydrates but accelerates fat oxidation.
<!-- /writer-only -->

### The Thin Mirror / Tier-A / GUILD-A-0144
- **Tier:** A
- **Discovered:** Pulled up at a shallow field-dig south of Windrest seven years ago, by a Listener who had it taken from her hands before she could name it; the name was given later by the Guild clerk, inaccurately.
- **Appearance:** A sheet of bright thin metal the size of a prayer-book, flexible, edged in a darker alloy. It reflects like still water, but darker.
- **Behaviour:** A person who looks at the mirror in full daylight sees their face as it was ten years before. A person who looks at it by candlelight sees a face they do not recognise. Two Listeners disagree whether the second face is the same one each time.
- **Cost:** Nobody who has looked twice will say what they saw.
- **Custody:** Guild cabinet, Stoneford.
- **Rumour:** A witch's glass; a trap for vanity.
- **Storyline links:** A.
<!-- writer-only -->
- **Real nature:** A fragment of display film or polished reflector with a slight image-processing coating that was once paired with a facial-recognition unit. The second-face phenomenon is an afterimage artefact; the Listeners' contradiction is genuine.
<!-- /writer-only -->

### Small-Warm / Tier-A / GUILD-A-0158
- **Tier:** A
- **Discovered:** Pulled up at the Mossbarrow shallow eight years ago. The Listener Pella named it through chattering teeth; she had been cold for two days.
- **Appearance:** A shallow cup-shaped bowl of dull red ceramic, thick-walled, always faintly warm on the inside surface.
- **Behaviour:** Hands held over the bowl warm quickly. Food placed in the bowl does not warm. The bowl does not warm any room it is set in.
- **Cost:** The user's palms, after long use, feel less of hot and cold both.
- **Custody:** Stoneford Guild; lent to the clerk's elderly aunt in winter, unofficially.
- **Rumour:** A kindly stone.
- **Storyline links:** A; cross-reference to the Unbroken Kettle (Tier E), since the palms-losing-sensation cost is the same and some Listeners believe the two objects are of one kind.
<!-- writer-only -->
- **Real nature:** A hand-warmer tile. Same family as the Unbroken Kettle's heating element but degraded and unregulated. The Listeners' intuition is correct.
<!-- /writer-only -->

### Near-Lamp / Tier-A / GUILD-A-0160
- **Tier:** A
- **Discovered:** Found nine years ago wrapped in oilcloth inside a horse-trough at Stoneford, placed there by a drunk who had dug it up elsewhere and could not later remember where.
- **Appearance:** A finger-thick loop of clear material set into a ring of soft metal. The loop is warm only when the metal is touched.
- **Behaviour:** Worn on a finger at night, the loop brightens when another person's hand passes within the span of an arm.
- **Cost:** The wearer's own hands, in daylight, feel less present. They drop cups.
- **Custody:** Guild; rotated among apprentice clerks as a training piece.
- **Rumour:** A spy's trinket. The Union would pay for one, if told.
- **Storyline links:** A; possible C (the Union has tried to buy one).
<!-- writer-only -->
- **Real nature:** Proximity-sensing ring, probably a gesture or consent wearable. The "hands feel less present" cost is a minor proprioceptive interference.
<!-- /writer-only -->

### Dripless / Tier-A / GUILD-A-0172
- **Tier:** A
- **Discovered:** Surfaced at a Stoneford shallow four years ago. Named by the Listener Yant.
- **Appearance:** A hand-sized flat square of a material resembling oiled paper but that does not tear. Pale, faintly patterned with a grid of tiny squares.
- **Behaviour:** A cup of water poured on it stands in a bead. Blood does the same. Wine the same. Nothing soaks in.
- **Cost:** The square, after each pour, weighs a grain heavier. It will eventually be too heavy to lift; the Guild estimates another fifty years.
- **Custody:** Guild, Stoneford, in a wooden press.
- **Rumour:** A saint's handkerchief.
- **Storyline links:** A.
<!-- writer-only -->
- **Real nature:** Superhydrophobic coated substrate. Mass accumulation suggests partial ion exchange with the liquids.
<!-- /writer-only -->

### The One-Ear Ring / Tier-A / GUILD-A-0179
- **Tier:** A
- **Discovered:** Pulled up last winter at a dig half a day's ride from Stoneford. The Listener who named it, Nerin, died of a chest-rot before registering; the Guild appended the name.
- **Appearance:** A small oval loop of pale alloy, polished, the weight of a river-pebble, with a tiny pinhole in one face. Smells of nothing.
- **Behaviour:** Held against the right ear, the wearer hears a conversation in a distant language, always between two voices, always stopping at the same place. Held against the left ear, it is silent.
- **Cost:** The wearer's own right-ear hearing declines, over months, by about a hand's width of distance.
- **Custody:** Stoneford Guild; Corvin has listened to it once, refused to explain, did not listen again.
- **Rumour:** An eavesdropper's charm. The tavern joke is that the Guild uses it to listen to the Crown.
- **Storyline links:** A; C (Corvin's one listening).
<!-- writer-only -->
- **Real nature:** An earbud-type device replaying a looped voice transmission in the old tongue. The two voices are an acknowledged technician's exchange — mundane on the far side, oracular here.
<!-- /writer-only -->

### Always-Knife / Tier-A / GUILD-A-0185
- **Tier:** A
- **Discovered:** Found three years ago by a turnip-digger at Stoneford, who sold it to the Guild for a coin and a loaf.
- **Appearance:** A thin blade the length of a finger, set into a plain wooden handle the digger carved himself afterward. The blade is grey, very smooth, with no hammer marks.
- **Behaviour:** The blade does not dull. Honing does nothing to it; it neither takes an edge nor loses one. It cuts what a cheap knife of that size would cut.
- **Cost:** The hand that uses it calluses oddly — in lines, not in patches.
- **Custody:** Guild, Stoneford; carried openly by the clerk who opens parcels.
- **Rumour:** A good knife. Nothing more.
- **Storyline links:** A; low-register parallel to the Unbreakable Metal (Tier E).
<!-- writer-only -->
- **Real nature:** A monolithic ceramic blade, factory-edged, indestructibly sharp but brittle. The same materials family as Brenna's armour inlay, one grade down.
<!-- /writer-only -->

### The Patient Bead / Tier-A / GUILD-A-0188
- **Tier:** A
- **Discovered:** Surfaced two years ago at a Stoneford shallow by the Listener Jome.
- **Appearance:** A single dark blue bead, glass-like but heavier, the size of a pea, with a pinhole drilled cleanly through.
- **Behaviour:** Strung on a thread and left in still water, the bead turns, slowly, until the thread points north-north-east. Always the same bearing. The bearing is not magnetic north.
- **Cost:** The wearer of the bead begins, after weeks, to dream of a road they have never walked.
- **Custody:** Stoneford Guild; Kestrel's Crossers have asked twice to examine it and been refused both times.
- **Rumour:** A lost-traveller's bead, once belonging to a saint.
- **Storyline links:** A; E (Crosser interest); oblique cross-reference to the Unbreakable Metal (the smith's dream of an unending road is of the same kind).
<!-- writer-only -->
- **Real nature:** A compass-bead keyed not to magnetic north but to a specific far-side beacon frequency. The dream is a mild induced-association effect from prolonged proximity.
<!-- /writer-only -->

### The Wife / Tier-A / GUILD-A-0191
- **Tier:** A
- **Discovered:** Pulled up last autumn at Stoneford. Named by the Listener Obel's daughter Tella, in a mood her mother called unwise.
- **Appearance:** A pale ceramic bowl, shallow, the size of two cupped hands. The inner surface is lined with a faint grid of darker lines. It is warm only when empty.
- **Behaviour:** Left on a table at night, the bowl is, in the morning, at the exact temperature of the room. But if someone has slept in the room, the bowl is at that person's blood-warmth. Two Listeners disagree on whether it measures or whether it remembers.
- **Cost:** The household that keeps it begins to sleep less deeply.
- **Custody:** Guild, Stoneford.
- **Rumour:** Paired with the Husband (GUILD-A-0077). Commoners who have heard of both say so as if the two relics ought to be kept in the same cabinet. The Guild, for reasons of archive policy rather than folk-belief, keeps them on the same shelf.
- **Storyline links:** A; paired with the Husband.
<!-- writer-only -->
- **Real nature:** A body-temperature-matching ambient sensor dish, probably a sleep-monitoring accessory. Paired in original use with the Husband's thermal-stasis family.
<!-- /writer-only -->

### Six-Thread / Tier-A / GUILD-A-0197
- **Tier:** A
- **Discovered:** Surfaced ten months ago at a dig east of Stoneford.
- **Appearance:** A small bundle of six thin strands, each of a different metal, twisted into a cord the length of a finger. Ends sealed in a drop of clear resin.
- **Behaviour:** Held in a fist during a lie, one or more of the strands becomes briefly warm. Held during truth, nothing. Which strand warms for which kind of lie, no two Listeners agree.
- **Cost:** The holder lies less well afterward, even in matters where lying would serve them.
- **Custody:** Guild; Magister Corvin has declined to use it in internal audits on ethical grounds.
- **Rumour:** A judge's cord. Every tavern hopes their bailiff does not have one.
- **Storyline links:** A; C (declined Crown request for loan).
<!-- writer-only -->
- **Real nature:** Multi-sensor bundle, possibly a truth-stress biometric toy. Ethically dubious on the far side too.
<!-- /writer-only -->

### The Quiet Coin / Tier-A / GUILD-A-0204
- **Tier:** A
- **Discovered:** Pulled up six months ago at a Stoneford shallow by the Listener Mar.
- **Appearance:** A disc of tarnished silver-coloured metal the size of a copper penny, one face blank, the other faintly marked with what might be a sea-wave or the glyph *ruh* half-worn.
- **Behaviour:** Placed on a sleeping person's forehead, the person sleeps through noise that would otherwise wake them. Removed, the person does not remember the noise.
- **Cost:** Used three nights in a row, the person loses their own voice for a morning.
- **Custody:** Stoneford Guild; a Faith courier requested it on behalf of Malen once and was told the catalogue had no such item. Malen, unknowing, also uses the distant-voice stones and would not have needed this.
- **Rumour:** A priest's lullaby-coin.
- **Storyline links:** A; C (Faith inquiry refused).
<!-- writer-only -->
- **Real nature:** Sleep-assist transcranial pad. The voice-loss is a transient neurological side effect from repeated dosing.
<!-- /writer-only -->

---

## Tier B — Bone-tier

### The Long Sister / Tier-B / GUILD-B-0009
- **Tier:** B
- **Discovered:** Pulled up from the bone-rooms under Mistmere seventeen years ago by the Listener Ylva, who was the first to enter that passage in a generation.
- **Appearance:** A rod of pale metal the length of a forearm, the thickness of a thumb, with a grip wrapped in an unknown dark fibre. One end flares slightly. It is cold in a warm room and warm in a cold room.
- **Behaviour:** Laid against a wall, it shows — faintly, in its own surface — a dim image of what is on the other side of the wall. Only walls of stone. Not wood. Not iron.
- **Cost:** The user, for a week afterward, forgets what is behind them when they turn around.
- **Custody:** Stoneford Guild, in the locked mid-cabinet. Used twice: once by Olric's successor; once by Corvin last year.
- **Rumour:** A ghost-seeker, from a collapsed monastery.
- **Storyline links:** A; B (Eilin has written of it, from rubbings only); E (Sula's contract lists it as "returned up-chain" nineteen years ago).
<!-- writer-only -->
- **Real nature:** Through-wall imaging rod using a form of ultrasonic or low-frequency radar. The stone-only limit reflects density tuning.
<!-- /writer-only -->

### The Whistler / Tier-B / GUILD-B-0012
- **Tier:** B
- **Discovered:** Surfaced fifteen years ago in the bone-rooms below the Mistmere bishopric cellar. Named by Sula herself, one of the last relics she personally named before the Listener Contract.
- **Appearance:** A slim tube of grey alloy the length of a hand, with three holes drilled in a row along one side and a fourth hole on the underside. It has no mouthpiece.
- **Behaviour:** A person who places their ear to the end hears, faintly, the sound of a hall full of people speaking, none of whom they can make out. Blown into, it makes no sound whatever. Two Listeners disagree on whether the hall is the same hall each time.
- **Cost:** The listener loses, for a day, the ability to pick a single voice out of a crowd.
- **Custody:** Guild deep cabinet. Sula has asked for it twice. Twice refused.
- **Rumour:** A saint's flute that cannot be played.
- **Storyline links:** A; E (Sula's two requests recorded in her contract addenda).
<!-- writer-only -->
- **Real nature:** A broken audio input/output tube from a public-address or intercom station. The hall-noise is recorded ambient from its operational use.
<!-- /writer-only -->

### Twelve-Below / Tier-B / GUILD-B-0018
- **Tier:** B
- **Discovered:** Pulled up from the bone-rooms under Jadehollow twelve years ago. Name is a register-error: the Listener named it "Twelve" and the Guild clerk added "-Below" assuming a suffix.
- **Appearance:** A flat square plate of dark glass-like material, the size of a serving platter, heavier than it looks. On one face, twelve small indentations in a grid.
- **Behaviour:** A fingertip pressed into one of the indentations produces, in the air just above the plate, a faint shape of coloured light that lasts the span of three breaths. The shape differs by indentation. Two Listeners record twelve different shapes; a third, recording later, records eleven and insists the twelfth is illusion.
- **Cost:** The finger that presses loses its print. The skin grows back smooth.
- **Custody:** Guild deep cabinet. Corvin has refused any further pressings.
- **Rumour:** A wizard's signboard. A Jadehollow child's toy.
- **Storyline links:** A; F-adjacent (the contested twelfth shape).
<!-- writer-only -->
- **Real nature:** An interactive display panel, badly degraded. Holographic projection from pressure-keyed inputs. The lost fingerprint is a real tissue effect from the reader's surface chemistry.
<!-- /writer-only -->

### The Husband's Brother / Tier-B / GUILD-B-0024
- **Tier:** B
- **Discovered:** Pulled up from the Mistmere bone-rooms ten years ago, on the same descent that surfaced the Wife's paired piece.
- **Appearance:** A dish of the same pale ceramic as the Husband (GUILD-A-0077), but larger — the width of a shield — and with a small round depression at its centre.
- **Behaviour:** A pot placed at its centre cooks what is in it, slowly, with no fire. The cooking does not stop; a stew left from dawn until dusk becomes something else, a thick silence of a stew.
- **Cost:** The cook who uses it weekly grows a small, painless lump at the base of the neck. The lump does not grow further.
- **Custody:** The Faith of Mistmere, unofficially. Malen does not know it is there; her under-cook uses it for vigil meals.
- **Rumour:** A blessed hearthstone from the undercroft.
- **Storyline links:** A; C (Faith holding); paired with Husband (GUILD-A-0077).
<!-- writer-only -->
- **Real nature:** An induction cooking surface, higher-power family cousin to the Kettle-That-Remembers. The lump is a low-grade localized tissue response.
<!-- /writer-only -->

### Soft-Rope / Tier-B / GUILD-B-0031
- **Tier:** B
- **Discovered:** Surfaced in the bone-rooms below Wolfsjaw eight years ago.
- **Appearance:** A length of cord, the length of two men laid end to end, soft as silk but heavier than rope. Dark grey, no visible twist.
- **Behaviour:** A knot tied in the cord does not hold unless both ends of the cord are already under tension. Loose, the knot slides free. Under load, it locks; released, it frees. It cannot be cut with any tool in the Reach.
- **Cost:** A climber who uses it to descend the Chasm returns unable to remember their own weight — not the number, the feel.
- **Custody:** Stoneford Guild; lent to Sula's cells by standing arrangement.
- **Rumour:** Angel-hair; or, less reverently, dead-man's-hair.
- **Storyline links:** A; E (in regular Listener use).
<!-- writer-only -->
- **Real nature:** A shear-thickening cordage, synthetic fibre. The self-locking knot is a tension-responsive braid structure. The proprioceptive cost is unexplained.
<!-- /writer-only -->

### The Thin Road / Tier-B / GUILD-B-0038
- **Tier:** B
- **Discovered:** Pulled up in the Mistmere bone-rooms six years ago.
- **Appearance:** A strip of pale, slightly flexible material the width of a finger, the length of a wagon, rolled into a tight coil. Bears a broken glyph that Eilin reads — tentatively — as *tol*.
- **Behaviour:** Unrolled and laid flat along the floor, the strip makes any footfall on it sound as if the walker is much farther down a corridor than they are. The sound recedes as they walk. When the walker stops, the footfalls take a breath to stop.
- **Cost:** Walked on daily for a month, the walker begins to arrive home without remembering the last stretch of the road.
- **Custody:** Guild, Stoneford; rolled in the deep cabinet.
- **Rumour:** A haunting-mat.
- **Storyline links:** A; E (Listeners have laid it in two cells to audit approach-sounds).
<!-- writer-only -->
- **Real nature:** A piezoelectric walkway strip paired with an audio-projection surface. Its acoustic logic reversed on degradation.
<!-- /writer-only -->

### Cold-Seam / Tier-B / GUILD-B-0044
- **Tier:** B
- **Discovered:** Bone-rooms under Mistmere, five years ago.
- **Appearance:** Two plates of pale metal each the size of a hand, joined along one edge by a hinge of the same metal, with no visible pin. Opens and closes without resistance. Inside, when closed, is as cold as a winter well.
- **Behaviour:** Any small thing placed between the plates and the plates closed remains at well-cold. A mouse placed inside, closed, and opened after the count of a hundred is still a mouse but has forgotten how to be afraid of a hand.
- **Cost:** The user's own fear of small, mundane dangers — a hot pan, a loose step — diminishes, slowly, with use.
- **Custody:** Guild deep cabinet; Corvin has set a rule that no living thing is to be placed inside.
- **Rumour:** A freezer-saint's alms-box.
- **Storyline links:** A; oblique to the unaging tea family (see Unbroken Kettle).
<!-- writer-only -->
- **Real nature:** A thermoelectric cold-storage case. The fear-diminishment is a writer-side mystery; possibly a mild neurological dampening from prolonged proximity.
<!-- /writer-only -->

### Third Candle / Tier-B / GUILD-B-0050
- **Tier:** B
- **Discovered:** From the bone-rooms under Jadehollow, four years ago.
- **Appearance:** A short rod of dull white material, the length of a finger, weighted at one end. When stood on its weighted end it lights itself after the count of three.
- **Behaviour:** The light is small, steady, bright as a strong candle. It does not go out in wind, in rain, or in the Fog. Struck, it extinguishes and will not relight for a day.
- **Cost:** The hand that holds it while it burns — held close, as in reading — trembles faintly for an hour after setting it down.
- **Custody:** Stoneford Guild; used by the clerk on Fog-nights.
- **Rumour:** A miner's saint-candle.
- **Storyline links:** A; D (if placed on the road on the night of the straight-line cloud, a Listener claims the candle dims while the cloud is overhead; another Listener denies it).
<!-- writer-only -->
- **Real nature:** A self-igniting illumination rod, possibly catalytic flame with stored fuel. The hand-tremor is a low-grade vibrational feedback through the casing.
<!-- /writer-only -->

### The Speaking Jar / Tier-B / GUILD-B-0057
- **Tier:** B
- **Discovered:** Pulled up three years ago from the bone-rooms under Wolfsjaw.
- **Appearance:** A sealed jar of pale green glass, the size of a fist, containing a pinch of dark powder and a small, unreadable slip of folded paper. The seal is of a material that is neither wax nor metal.
- **Behaviour:** Held to the ear, the jar speaks — once — a single short sentence in an unknown language. The sentence is different each time, and the jar will not speak again for a year and a day.
- **Cost:** The listener forgets, for the rest of the year, their mother's first name. It returns on the anniversary.
- **Custody:** Guild deep cabinet. Eilin has listened twice. She has written down each sentence; the two sentences share three glyphs.
- **Rumour:** A confession-jar from a martyred saint.
- **Storyline links:** A; B (Eilin's transcriptions).
<!-- writer-only -->
- **Real nature:** A single-use audio capsule, possibly a voicemail or will-recording device, with a slow recharge cycle. The powder is a battery residue.
<!-- /writer-only -->

### The Bone-Lamp / Tier-B / GUILD-B-0062
- **Tier:** B
- **Discovered:** Two years ago, bone-rooms under Mistmere, by the Listener Ren. Named in the ritual.
- **Appearance:** A hand-lamp of pale alloy shaped to resemble, roughly, a long finger-bone. The knuckle-end carries a clear lens. It has no wick, no oil reservoir, and no obvious way to light.
- **Behaviour:** Gripped firmly for the count of ten, the lens brightens. Released, it dims after thirty heartbeats. It is warm during use and warmer afterward. Tested in the Chasm mist, the beam does not scatter as a candle's would.
- **Cost:** The user's grip, on the hand that held it, becomes slightly weaker. Permanently. Each use costs a fractional weakening nobody can measure in one lifetime.
- **Custody:** Guild, held by Sula's senior cell under standing arrangement.
- **Rumour:** A saint's finger preserved and glowing.
- **Storyline links:** A; E (in active Listener use); pairs loosely with Third Candle.
<!-- writer-only -->
- **Real nature:** A pressure-activated hand-torch; body-heat and mechanical pressure recharge a micro-cell. The grip-weakening is real tissue atrophy from repeated hard clenching at the handle's unergonomic angle.
<!-- /writer-only -->

### The Year-Bowl / Tier-B / GUILD-B-0068
- **Tier:** B
- **Discovered:** Last year, bone-rooms under Mistmere.
- **Appearance:** A shallow bowl of pale stoneware, the inside lined with a circle of twelve small raised marks like a clock-face without hands.
- **Behaviour:** Water poured in the bowl evaporates at exactly one mark per month, from whichever mark the bowl faces when set down. Two Listeners disagree on whether the evaporation is the same month everywhere, or whether it is the bowl's month.
- **Cost:** The household keeping the bowl notices, at year's end, that one full month has no memories in it. Which month varies.
- **Custody:** Stoneford Guild; strongly discouraged from field use.
- **Rumour:** A saint's calendar.
- **Storyline links:** A; loose pair with the Patient Bead.
<!-- writer-only -->
- **Real nature:** A calibrated evaporative timing dish. The memory-month cost is not writer-documented; accepted as canon ambiguity.
<!-- /writer-only -->

---

## Tier C — Wet-tier

### Deep-Kindle / Tier-C / GUILD-C-0003
- **Tier:** C
- **Discovered:** Surfaced twenty years ago, from the wet-silence level under Mistmere. Named by a Listener named Sura, not Sula (the name-similarity causes occasional confusion in the Guild ledger).
- **Appearance:** A short black rod with a bulbed end, heavy for its size. The bulb is seamless and faintly warm. The rod bears no glyph and no mark.
- **Behaviour:** Laid on dry tinder, the tinder kindles after a count of forty. On wet tinder, after a count of four hundred. The rod is cool to the touch throughout. It does not kindle cloth, skin, or hair.
- **Cost:** A kindler who uses it three times in a day wakes the next morning unable to recall the word for *fire* for half an hour.
- **Custody:** Stoneford Guild; a copy held, with knowing irregularity, in Kestrel's possession.
- **Rumour:** A saint's dry-finger.
- **Storyline links:** A; E (Crosser duplicate).
<!-- writer-only -->
- **Real nature:** A low-temperature ignition rod, possibly catalytic. The word-loss is a transient aphasia effect from long-dose proximity to the device's casing.
<!-- /writer-only -->

### The Wet Speaker / Tier-C / GUILD-C-0008
- **Tier:** C
- **Discovered:** Pulled up eighteen years ago from the wet-silence level under Wolfsjaw. Named by the Listener Thess.
- **Appearance:** A small oval stone of dark green material, always damp, always cool, with two small metal beads set into one face. Smells faintly of river-weed no matter how long it is kept dry.
- **Behaviour:** Pressed between the palms, it speaks, in a woman's voice, a single word each time in a language no one in the Reach understands. Different word each time.
- **Cost:** The speaker's own voice grows quieter for a week.
- **Custody:** Guild cabinet. Eilin has logged fourteen of its words.
- **Rumour:** A martyr's tongue.
- **Storyline links:** A; B (Eilin's logs); cross-reference to Distant-voice stones (Tier E) — Malen's stones and this object are believed by two Listeners to be "of the same family, crippled."
<!-- writer-only -->
- **Real nature:** A crippled communications earpiece, water-damaged, emitting single packet fragments from an old buffer. Functionally identical ancestry to the royal distant-voice stones.
<!-- /writer-only -->

### The Held Breath / Tier-C / GUILD-C-0015
- **Tier:** C
- **Discovered:** Fifteen years ago, wet-silence under Mistmere. A Listener who surfaced with it would not give it a name; Sula named it from the mouth of the shaft.
- **Appearance:** A bronze-coloured mask the size of a hand, fitted to cover mouth and nose. Inside, lined with a dark soft mesh. Two small cylinders on the sides, each half the length of a finger.
- **Behaviour:** Worn in smoke or in the Fog, the wearer breathes clean air for the span of half a day. The cylinders warm during use. They do not cool.
- **Cost:** Each use shortens the wearer's own unaided breath — the time they can hold their breath is reduced by a heartbeat.
- **Custody:** Guild, Stoneford; lent out to senior Listeners for deep descents, with a strict use-count.
- **Rumour:** A saint's hand of breath.
- **Storyline links:** A; E (Listener use); D (Kestrel has argued for its distribution on cloud-nights).
<!-- writer-only -->
- **Real nature:** A cartridge respirator. Breath-hold reduction is a real effect of habitual device reliance on respiratory muscle conditioning.
<!-- /writer-only -->

### Wet-Eye / Tier-C / GUILD-C-0021
- **Tier:** C
- **Discovered:** Twelve years ago, wet-silence under Jadehollow.
- **Appearance:** A lens of dark glass, the size of a small plate, edged in pale metal. Always cool, always faintly wet on the surface however long it has been in a dry room.
- **Behaviour:** Held up at midnight, the lens shows the room as if lit by a weak noon sun. Held up at noon, it shows the room darker. It does not reverse colour. It reverses brightness.
- **Cost:** The user's own night-vision dims. The user's day-vision does not improve.
- **Custody:** Guild deep cabinet; Sula has a copy.
- **Rumour:** A burglar's eye.
- **Storyline links:** A; E.
<!-- writer-only -->
- **Real nature:** A light-amplifying optical lens with a light-attenuating shutter coupling. Once part of a night-vision system.
<!-- /writer-only -->

### The Slow Drum / Tier-C / GUILD-C-0029
- **Tier:** C
- **Discovered:** Ten years ago, wet-silence under Wolfsjaw.
- **Appearance:** A drumhead of pale skin-like material stretched across a ring of dark alloy, thumb-sized. It has no drumstick and no body.
- **Behaviour:** Tapped, it makes no sound; but a candle anywhere within an arm's length flickers once per tap. A lantern flickers twice.
- **Cost:** The tapper loses their ability to keep rhythm. A tapper who once sang in the tavern choir will never sing in tune again.
- **Custody:** Guild, Stoneford; Sula has declined a copy.
- **Rumour:** A mute-saint's drum.
- **Storyline links:** A; B (Eilin has written a note linking the tap-to-flicker behaviour to the footstep-lag of the Thin Road — she thinks the two objects share a principle; Vossel has transcribed her speculation).
<!-- writer-only -->
- **Real nature:** A pressure-to-electromagnetic transducer; disturbs nearby flames via a very small pulse. Related by operating principle to several other relics.
<!-- /writer-only -->

### Silent Hearth / Tier-C / GUILD-C-0035
- **Tier:** C
- **Discovered:** Nine years ago, wet-silence under Mistmere.
- **Appearance:** A round plate of matte black material, as wide as a plate of bread. On its underside, six small feet; on its top, a single circle scored lightly.
- **Behaviour:** Placed on a fire, the fire above it burns without smoke, without scent, and — critically — without sound. The flames dance but crackle not. A person near the fire does not realise they have been sitting quietly for hours.
- **Cost:** A household that uses it for a full winter is reported, by the neighbours, to argue in silence. The members of the household themselves say they argue as before; the neighbours disagree.
- **Custody:** Stoneford Guild. Corvin refuses to let it into private households; the refusal has been tested twice in suits brought before him.
- **Rumour:** A widow's hearth-plate; a quieting stone.
- **Storyline links:** A; C (two private suits logged); opposed in usage to the Slow Drum.
<!-- writer-only -->
- **Real nature:** An active-noise-cancellation fireplate, surprisingly domestic, probably a consumer product.
<!-- /writer-only -->

### The Open Eye / Tier-C / GUILD-C-0042
- **Tier:** C
- **Discovered:** Eight years ago, wet-silence under Mistmere. Named by the Listener Yolen.
- **Appearance:** A small bead of clear material, the size of a pea, mounted on a thin stalk of dark metal. The bead appears to blink — a slow, once-a-day blink — when observed closely.
- **Behaviour:** Set on a windowsill or lintel, the bead remembers, in some fashion no Listener can describe, who has passed beneath it. Asked, it does not answer; but a second person carrying the bead a day later knows, somehow, who was there. Three Listeners contradict each other on whether this knowledge is a memory or a guess.
- **Cost:** The bearer of the second-day bead cannot remember their own passing beneath it.
- **Custody:** Guild deep cabinet; Kestrel has requested a copy and been refused.
- **Rumour:** A watcher's eye.
- **Storyline links:** A; E.
<!-- writer-only -->
- **Real nature:** A passive recording sensor paired, originally, with a local database. Orphaned function. The Listeners' contradictions reflect the corrupted playback.
<!-- /writer-only -->

### Cold Iron / Tier-C / GUILD-C-0048
- **Tier:** C
- **Discovered:** Six years ago, wet-silence under Mistmere.
- **Appearance:** A bar of pale metal the length of a spoon, cold to the touch however long it is held, leaving no frost. Bears the glyph *nor* clearly, though it is not *kor-nor* (not the un-hammerable alloy).
- **Behaviour:** Laid against skin over a wound, the wound stops bleeding. Laid against an unwounded limb, the limb goes numb for an hour.
- **Cost:** The healer's own hand, after enough uses, begins to tremble in the cold.
- **Custody:** Stoneford Guild; used in the infirmary under strict log.
- **Rumour:** A surgeon-saint's rod.
- **Storyline links:** A; C (Faith infirmary has requested it, refused).
<!-- writer-only -->
- **Real nature:** A haemostatic cold pack, possibly cryogenic point-cauteriser. Simpler and more medical than most Tier C relics.
<!-- /writer-only -->

### The Slow-Stone / Tier-C / GUILD-C-0055
- **Tier:** C
- **Discovered:** Surfaced continuously from the wet-silence in small quantities for decades. Listeners treat it less as a relic than as a resource. The name predates the Guild ledger.
- **Appearance:** A coarse black powder, slightly greasy to the touch, heavier than charcoal. Found in seams, not as a single artefact.
- **Behaviour:** Mixed into lantern oil, it causes the flame to burn cold-blue near the wick, yellow at the tip, and to not go out in a rising draft. Listeners use it to gauge the Chasm's breath.
- **Cost:** Listeners who mix it too often lose the pale of their palms; the palms go slightly dark and stay so.
- **Custody:** Every Listener cell holds a pinch. Sula's cells hold the largest shares. The Guild catalogues the substance but does not attempt to monopolise it.
- **Rumour:** The Chasm's ash.
- **Storyline links:** A; E (in operational use throughout the line); referenced in Yannic's lantern (E/SHARED).
<!-- writer-only -->
- **Real nature:** Ground relic-material, probably a mix of battery anode residue and ferromagnetic particulate. Burns blue because of metal vapourisation. Kestrel's Crossers call it "ground relic" and are correct.
<!-- /writer-only -->

---

## Tier D — Lantern-Dies tier

### The Lantern-Killer / Tier-D / GUILD-D-0001
- **Tier:** D
- **Discovered:** Pulled up thirty years ago by Sula herself, on her first contracted descent. It is the relic that gives the tier its name. Sula named it in a whisper and has not said the name aloud since.
- **Appearance:** A pillar of dark alloy, the height of a man's knee, the thickness of a man's wrist, with a crown of fine wires at the top that move when no wind moves them. Heavier than stone.
- **Behaviour:** Every lantern within forty paces of the pillar goes out when the wires turn. They cannot be relit until the wires stop. The wires turn without pattern.
- **Cost:** Listeners who have spent a watch beside it report that, upon surfacing, they could no longer see small lights at distance for a month.
- **Custody:** Guild, Stoneford, in the deepest cabinet. Has been moved three times; at each move, every lantern in the transport train went out. The Guild has decreed no further moves.
- **Rumour:** A saint of blindness.
- **Storyline links:** A; D (the cloud-night lantern-dousing is explained by some Listeners as the Lantern-Killer "answering"; Sula herself refuses the comparison); E.
<!-- writer-only -->
- **Real nature:** An electromagnetic-pulse device or an active field-generator with intermittent output. Interferes with any open combustion nearby via micro-arc discharge. The eye-damage cost is real ocular photoreceptor overstress.
<!-- /writer-only -->

### The Long Knife / Tier-D / GUILD-D-0004
- **Tier:** D
- **Discovered:** Surfaced twenty-two years ago at the lantern-dies level under Mistmere. Named by a Listener who died in the descent; the name was finished by Sula.
- **Appearance:** A blade the length of a man's leg, pale, with no hilt — only a grip-ring at one end. The blade is not metal in any familiar sense; it does not ring when struck.
- **Behaviour:** Cuts stone as easily as cloth. Cuts cloth not at all. Cuts wood, but slowly. Cuts water in a way that leaves the water parted for a breath.
- **Cost:** The wielder forgets, over the year following a use, the name of one person they love. The choice is not theirs.
- **Custody:** Stoneford Guild, under Corvin's personal seal. Has been used twice in the last decade; both uses are logged but not described.
- **Rumour:** A headsman's saint-blade.
- **Storyline links:** A; E; obliquely D.
<!-- writer-only -->
- **Real nature:** A cutting tool using a focused-energy or ultrasonic edge, material-selective. The memory-loss cost is writer-canon-ambiguous.
<!-- /writer-only -->

### Night-Walker / Tier-D / GUILD-D-0007
- **Tier:** D
- **Discovered:** Eighteen years ago, lantern-dies under Wolfsjaw.
- **Appearance:** A pair of soft boots of pale grey hide-like material, with soles of dark alloy. They weigh nothing. A full-grown man, wearing them, weighs slightly less on the scale than he does without them.
- **Behaviour:** A walker in the boots does not sink in mud, does not slip on ice, does not stumble on scree. The walker does not tire through a night's walk. The boots do not tire either.
- **Cost:** A walker who has worn them to the third dawn begins to feel, for the rest of their life, that the ground underneath any ordinary boot is slightly wrong.
- **Custody:** Guild, Stoneford; refused to every applicant including Sula, including Kestrel.
- **Rumour:** A courier-saint's boots.
- **Storyline links:** A; E (refused requests on record).
<!-- writer-only -->
- **Real nature:** Active-stabilisation footwear with mild mass-compensation field. The permanent proprioceptive unease is a real after-effect.
<!-- /writer-only -->

### The Small Sun / Tier-D / GUILD-D-0011
- **Tier:** D
- **Discovered:** Twelve years ago. Named by a Listener who did not return; Sula finished the name from the transcript of the last rope-signal.
- **Appearance:** A sphere of pale alloy the size of a fist. It is cold on one side and warm on the other. The warm side is the one that faces upward in any orientation; turned, it adjusts. The sphere is seamless.
- **Behaviour:** In a sealed cold room, the sphere warms the room to summer in half a day. In a hot room, it does nothing. In winter, the Chasm's mouth has been melted clear of ice on the nights it was placed there — twice, twenty and nineteen years ago.
- **Cost:** The person who carries it for more than a day finds their tears warm.
- **Custody:** Stoneford Guild. Has not been deployed since the second Chasm-mouth winter. Sula keeps asking.
- **Rumour:** A sun-saint's small gift.
- **Storyline links:** A; E (Sula's standing request).
<!-- writer-only -->
- **Real nature:** A directional thermal emitter; probably a micro-reactor or stored-energy heater with passive orientation. Dangerous if used without schedule.
<!-- /writer-only -->

### The Thread-Pulled Door / Tier-D / GUILD-D-0015
- **Tier:** D
- **Discovered:** Nine years ago, lantern-dies under Mistmere. Named by the Listener Halvard, who also named the Crosser sketch's theme; his wording is disputed.
- **Appearance:** A rectangular frame of dark alloy the size of a large book, with a single thin wire crossing its diagonal. It is neither heavy nor light; its weight seems to depend on who is holding it.
- **Behaviour:** Held up against a wall, and the wire plucked, the wall on the far side becomes — for the span of a held breath — visible as if the frame were a window. The image is dim. Three Listeners agree the image shows the far wall. Two Listeners claim the image sometimes shows a wall that is not the far wall; it is a wall in some other place.
- **Cost:** The plucker's memory of the wall they were looking at (the near wall) goes blurry, and does not recover fully.
- **Custody:** Guild, Stoneford; Magister-sealed. Used once in nine years, by Corvin, who has not said what he saw.
- **Rumour:** A wizard's door that is not a door.
- **Storyline links:** A; C (Corvin's single use is a private Crown referent); B (Eilin believes the dissenting Listeners); E (Kestrel reads the dissenters as correct).
<!-- writer-only -->
- **Real nature:** A through-barrier imaging plate, perhaps paired in origin with a remote node. The "other wall" observations are likely stored frames from elsewhere, played back when the local imaging fails.
<!-- /writer-only -->

### The Measured Breath / Tier-D / GUILD-D-0019
- **Tier:** D
- **Discovered:** Four years ago, lantern-dies under Mistmere. Named by Sula without ceremony — "a thing that measures."
- **Appearance:** A cylinder of pale metal the length of a forearm, with a glass panel on one side through which one sees a small needle that trembles. No markings accompany the needle.
- **Behaviour:** Held in open air, the needle is still. Held near another relic — any relic — the needle trembles, more for some than for others. Held near the Chasm's updraft, the needle pins itself to the far end of its run and stays there.
- **Cost:** Unknown. Two Listeners who have carried it for long shifts report nothing unusual. One reports dreams of counting. None have died yet.
- **Custody:** Stoneford Guild deep cabinet; one of two relics Kestrel has personally requested by name. Refused.
- **Rumour:** A saint's finger-bone that still feels.
- **Storyline links:** A; E (Kestrel's request); F-adjacent.
<!-- writer-only -->
- **Real nature:** A field-strength meter, tuned to the ambient signature of the relic family. Would be extremely useful to Kestrel. The Guild knows this.
<!-- /writer-only -->

---

## Tier E — Royal-Held

> These are the canonical royal relics. Some are in daily use by the crowns of
> the Reach. Their costs are known to their bearers. Their names are older than
> the bearers know.

### Unbroken Kettle / Tier-E / no Guild ID — Crown-held
- **Tier:** E
- **Discovered:** Carried up by the First Wave; not surfaced from a dig. The name *Unbroken Kettle* is the Crown-liturgical form; the Listeners, who have never held it, call it *The Long Cup*.
- **Appearance:** A small kettle of pale metal, polished bright, with a long thin spout and a lid seated so precisely that no steam escapes. The body bears no glyph on its outside; the inside of the lid carries a faint ring that Eilin, from one brief description Kestrel obtained from a Crown servant, reads as *vel* stacked above *keth*.
- **Behaviour:** Tea brewed in this kettle, drunk at the rate of a cup a day, delays the drinker's aging. A king who began drinking at thirty looks thirty-three at fifty. A king who stops drinking ages, fast, through the years he postponed.
- **Cost:** The drinker's palms lose sensation. Darrik Voss cannot feel a needle on his left palm at all; on his right, only at the knuckle-joint. He has dropped three cups in the last year and blamed each on the servants.
- **Custody:** Crown of Voss, Mistmere. Kept in a lead-lined box in the king's own chamber. Handled only by Darrik himself and by one servant whose tongue was cut thirty years ago.
- **Rumour:** The Crown's longevity is called, by commoners, *the grace of the line*. Stoneford tavern wisdom holds that "the Voss do not die in battle because battle does not find them fast."
- **Storyline links:** C (royal use); also indirectly E (the unaging tea dregs are a fragment in Line C/E circulation); paired by principle with Kettle-That-Remembers (Tier A).
<!-- writer-only -->
- **Real nature:** An induction heating element with precise temperature control, brewing a decoction of a longevity compound stored in the cask the First Wave carried. The compound is running out; Darrik rations. The palm numbness is a peripheral neuropathy side effect of the compound, long-documented on the far side.
<!-- /writer-only -->

### Unbreakable Metal (kor-nor) / Tier-E / no Guild ID — Free North-held
- **Tier:** E
- **Discovered:** Carried up by the Third Wave in unworked ingots. Not dug. Inlaid into Brenna Greyhold's armour by Smith Durm's grandfather and by a smith whose name has been removed from the Free North ledger.
- **Appearance:** Pale metal, bright but not reflective, laid into the joints and throat-plate of a dark steel harness. The inlay reads, to a reader of the old tongue, as *kor-nor* — shining-metal — and nothing else. It does not tarnish. It cannot be hammered; the smiths who worked Brenna's armour set it in sockets cut from the host metal and pinned it with cold fits only.
- **Behaviour:** No blade tested against the inlay has ever marked it. No fire has heated it past warm. Arrows glance. A spear-point breaks before the inlay yields.
- **Cost:** The smith who worked the metal — the one named, not the one stricken — dreams, nightly, of an unending road. He has not slept easily in forty years. The Free North grants him an honoured pension and keeps him away from the armoury.
- **Custody:** Chieftess Brenna Greyhold, Free North. Worn in full at clan-muster; the throat-plate alone is worn daily.
- **Rumour:** The Greyhold line wears "a stone the gods forgot," and this is why no chieftess of the line has fallen in war in six generations.
- **Storyline links:** C (Free North royal use); D (un-hammerable lump in Durm's forge at Windrest is a fragment from the same family); E (Brenna and Sula have discussed it privately — in a conversation Sula's contract strictly forbids her from logging).
<!-- writer-only -->
- **Real nature:** A structural high-performance alloy or ceramic composite. The un-hammerability reflects a crystalline structure that cannot be cold-worked with hand tools. The smith's dream is the same proximity-dream effect seen in the Patient Bead, stronger at prolonged close contact.
<!-- /writer-only -->

### Distant-Voice Stones / Tier-E / no Guild ID — Faith-held
- **Tier:** E
- **Discovered:** Carried up by the Second Wave; the Faith has more of them than any other crown. Malen the Unsleeping has seven; the under-chapels of Mistmere hold perhaps twelve more. Their origin is unknown to the Faith; Malen has been told they are relics of sanctity.
- **Appearance:** Each stone is an oval of pale material the size of an almond, faintly warm to the touch, with a tiny black dot on one face. No two stones have the dot in the same place.
- **Behaviour:** Held to the ear at night, a stone produces a low murmur — sometimes only a hiss, sometimes a word or two in an unknown language, sometimes the sound of a room with other people breathing. Malen holds one against her right ear when she cannot sleep. She says the sound is a saint's hand on her shoulder.
- **Cost:** The bearer of a stone forgets the voices of the dead. Malen cannot remember the timbre of her mother's voice. She cannot remember her predecessor's voice. She believes this to be her own failing.
- **Custody:** High Septa Malen the Unsleeping, at Mistmere. Seven stones in a reliquary; one on her bedside table.
- **Rumour:** Holy murmurs. Commoners who have heard a stone murmur speak of it as a saint's secret.
- **Storyline links:** C (Malen); B (the Wet Speaker is argued by Listeners to be of the same kind); E (Sula's contract includes a clause to "return to sender" if any further are surfaced).
<!-- writer-only -->
- **Real nature:** Communication earpieces, keyed to a dead relay. The murmur is background noise from the receiver; occasional words are packet fragments. The voices-of-the-dead cost is a genuine auditory-memory interference, strong in users who listen nightly.
<!-- /writer-only -->

### Colonist Crest Fragment / Tier-E / no Guild ID — Veyl's possession
- **Tier:** E
- **Discovered:** Origin unknown. In Veyl's pocket when he entered Windrest a year ago. Not surfaced by the Guild, not catalogued until after the fact from a rubbing Kestrel stole.
- **Appearance:** A shard of pale metal the size of a thumb, edge-jagged, bearing on its flat a heraldic mark — a ring of dots around a central point — and, below, the three compounds of the old-tongue warning: *vel-bren, kor-thal, san-tol* with the prohibitive *ven-u*. A small *ast* within a *bel* marks a four-knot arbitration seal.
- **Behaviour:** The fragment is warm in the hand of a bearer of authority, cool in the hand of anyone else. Two Listeners disagree whether it is authority or intent that warms it.
- **Cost:** Whoever holds it for more than the count of a day forgets the name of their own house. Veyl, when asked his family name, pauses in a way that is not hesitation.
- **Custody:** Veyl "the Line," wandering. Briefly in Crown custody ninety years ago; removed from the Crown's sealed folio cabinet in a theft unremarked in any ledger.
- **Rumour:** A lost crest of a forgotten northern house. Union antiquarians would bid well for it.
- **Storyline links:** D (Veyl); C (colonist history); E (the Crosser sketch shares three glyphs with it).
<!-- writer-only -->
- **Real nature:** A broken colonist identification token, inscribed with the departure warning. Carried by arbitration-line personnel; Veyl is an arbitration-line descendant or an arbitration-line officer still in some sense functional. The house-name forgetting is a side effect of prolonged exposure to the warning's inscribed surface; the Crown archivists noticed this in the sealed folio and have been careful.
<!-- /writer-only -->

### Ancient Stone Shard (Silas's) / Tier-E / no Guild ID — Faith-adjacent
- **Tier:** E
- **Discovered:** Surfaced three years ago in the old mine road north of Stoneford, wedged under a flat stone at the ford. Septon Silas carried it to his vestry at Stoneford and has shown it twice: once to Eilin, once to Corvin.
- **Appearance:** A flat shard of pale grey stone, the size of a spread hand, inscribed on both faces in the old tongue. Seventeen glyphs in total. The surface is smooth, the inscription crisp at depth — not eroded as field-stone would be.
- **Behaviour:** Held in daylight, the shard is a piece of inscribed stone. Read at night — specifically, read with attention, in a quiet room — the reader dreams, that night, of a straight line drawn across the sky. The dream is specific and does not vary.
- **Cost:** The reader, upon waking, is unable to describe the dream in words. They can draw it. They cannot speak it.
- **Custody:** Septon Silas, Stoneford vestry. Corvin has requested it for the Guild; refused. Eilin has rubbed it three times.
- **Rumour:** A saint's warning-stone, washed down from the mountains.
- **Storyline links:** A (Guild request); B (Eilin's rubbings); D (the straight-line-cloud dreams); E (Crosser interest, by proxy of Kestrel's reading of the rubbings).
<!-- writer-only -->
- **Real nature:** A colonial-era signpost or warning marker, inscribed with a variant of the departure warning phrase. The dream-induction is a well-documented side effect of prolonged text-exposure — the same inscription technology as the crest fragment, less concentrated. The speech-block is a transient aphasia for a specific content domain.
<!-- /writer-only -->

### The Nine-Sheet Charter / Tier-E / GUILD-E-0001 — Crown-held
- **Tier:** E
- **Discovered:** Carried up by the First Wave. Nine thin sheets of pale metal, inscribed on both faces in the old tongue. Held in the Crown's sealed folio cabinet at Mistmere.
- **Appearance:** Each sheet the width of a prayer-book, flexible, edged in a darker alloy. Faintly warm. The glyphs are finer than any carved stone.
- **Behaviour:** Read in full — which takes a trained reader an afternoon — the reader knows for the rest of the day the boundaries of the original four-wave settlement, with a clarity they cannot later reconstruct from memory.
- **Cost:** The reader, the morning after, has lost one ordinary memory — not of the charter but of something else.
- **Custody:** Crown of Voss; Darrik Voss has read it three times. Corvin Ashford-Reed once, nine years ago; he has not read it again.
- **Rumour:** None. The charter's existence is not known outside the Crown inner circle.
- **Storyline links:** A (Corvin's reading); C (Crown custody).
<!-- writer-only -->
- **Real nature:** A durable-substrate data tablet, the First Wave's administrative archive. Still functional for reading; writing impossible without its paired stylus, which is lost.
<!-- /writer-only -->

### The Listener Contract / Tier-E / no Guild ID — Sula-held
- **Tier:** E
- **Discovered:** Drafted thirty years ago, signed by Sula and by a Crown archivist whose name is blacked out. Kept in Sula's desk at Mistmere. Not a colonial relic in the material sense, but listed here because its status is royal.
- **Appearance:** A single long parchment, folded three times, wax-sealed with the Crown's private mark. Written in common speech in a clerk's hand; signed in three places.
- **Behaviour:** Where a relic is listed in the contract's addenda by name, the Guild may not requisition it without royal consent. The contract has been amended seven times. Sula has kept every draft.
- **Cost:** The contract binds Sula's cells to royal auditing. Her payment is in grain, in lantern-oil, and in the continued existence of the Listeners. Her private cost — which she has never written and which is not in the addenda — is that she could not name the stars for the friend who died on her second descent.
- **Custody:** Archdepth Sula, desk, Mistmere. Kestrel has a copy by theft.
- **Rumour:** None. The contract is not publicly known.
- **Storyline links:** E (central); A (the Guild ledger references it obliquely); C (royal).
<!-- writer-only -->
- **Real nature:** A standard covert-contract document. No technology. Included here because the catalogue's purpose is custody-tracking, and the contract is the mechanism of royal custody.
<!-- /writer-only -->

### The Half-Burned Northern Ban / Tier-E / no Guild ID — Guild/Faith-held
- **Tier:** E
- **Discovered:** Drafted eleven years ago under Corvin's predecessor, burned at the edges during an attempted internal destruction seven years ago, rescued by Archivist Naryn, now in Naryn's cabinet at Wolfsjaw.
- **Appearance:** A sheaf of four parchments, edges black and fragile. The ink is Faith-court ink. The seal — half-burnt — is the Guild's ten-dot mark.
- **Behaviour:** Read aloud in a room with anyone of Faith rank, the reader is interrupted within the first paragraph. Every time. Four Listeners have tested this; four times they have been interrupted.
- **Cost:** The reader is not permitted to continue. The cost, such as it is, is procedural.
- **Custody:** Archivist Naryn, Wolfsjaw.
- **Rumour:** A Guild document that the Faith dislikes. This is, for once, commoner wisdom that is correct.
- **Storyline links:** A (central); B (quotes the shard's script without attribution); C (Crown-Faith joint policy).
<!-- writer-only -->
- **Real nature:** A political document. No technology. Its listing in the catalogue is formal; the Guild categorises any document that references the warning-phrase roots as catalogue-adjacent.
<!-- /writer-only -->

---

## Tier F — Unknown / rumoured

> Relics catalogued by name only. No living Listener has handled them. No Guild
> archivist has rubbed them. They appear in margin-notes, in drunken stories,
> in the reports of miners who did not come back, and in one sealed Crown
> folio that nobody presently alive has read.

### The Reader / Tier-F / catalogue entry only
- **Tier:** F
- **Discovered:** Rumoured, four generations ago, beneath the Mossbarrow; sealed in by a fall of stone before surfacing.
- **Appearance (rumoured):** A tablet of pale material the size of a breadboard, flat, cool, inscribed with no glyphs but with a regular pattern of small squares.
- **Behaviour (rumoured):** Pressed, it speaks back the presser's own thought as if it were the tablet's thought. A Listener who pressed it would hear their own mind and not recognise it.
- **Cost (rumoured):** The presser never speaks aloud again what they press.
- **Custody:** Presumed entombed.
- **Rumour:** A devil's mirror. Never to be surfaced. The Mossbarrow dig avoids the east face for this reason.
- **Storyline links:** A (catalogue); E (Sula has refused three times to authorise a dig toward it).
<!-- writer-only -->
- **Real nature:** Possibly an advanced thought-to-text interface, or a pattern-matching display. Entirely speculative.
<!-- /writer-only -->

### The Second Sun / Tier-F / catalogue entry only
- **Tier:** F
- **Discovered:** Seen, not surfaced. A Listener at Wolfsjaw, twenty years ago, reported seeing — through a crack in the wet-silence wall — a round bright thing that lit a chamber beyond. The chamber has never been reached. The Listener died of wet-lung within the year.
- **Appearance (reported):** A sphere, the height of a man, glowing softly yellow. Surrounded by rubble.
- **Behaviour (guessed):** Lights a room without heat. Or with heat. Two Listeners retelling the deceased's report disagree, though both heard it from the same mouth.
- **Cost:** Unknown. The one witness died.
- **Custody:** Unreachable.
- **Rumour:** A buried sun-saint. The Faith would give much to have the story confirmed; Malen, hearing it once from a Septon, declined to confirm.
- **Storyline links:** B (Eilin has written a note arguing it is a light-engine of the First Wave); E (Sula's private list of "to-reach").
<!-- writer-only -->
- **Real nature:** Probably a reactor pile or a large illumination installation in a collapsed far-side chamber. Dangerous to reach and dangerous to reach.
<!-- /writer-only -->

### The Black Mouth / Tier-F / catalogue entry only
- **Tier:** F
- **Discovered:** Rumoured below the Mistmere bone-rooms. A single miner's note, forty years old, describes "a mouth in the floor that ate a lantern and did not light it back."
- **Appearance (described):** A hole in the stone, circular, black, not exhaling, not inhaling.
- **Behaviour (described):** Anything dropped in it is gone. No rope has ever returned from it. No sound returns.
- **Cost:** Unknown. The miner who noted it did not return to the dig.
- **Custody:** None. The location has been, by Guild standing order, left unrecorded in common maps.
- **Rumour:** A saint's drain. The devil's ear.
- **Storyline links:** A; E (Kestrel's Crossers argue privately that it is a shaft of the long road, and should be descended).
<!-- writer-only -->
- **Real nature:** Possibly a deep shaft of the colonial transit. Possibly something else. Genuinely unknown.
<!-- /writer-only -->

### The Speaking House / Tier-F / catalogue entry only
- **Tier:** F
- **Discovered:** A ruined chamber below Jadehollow, glimpsed by two Listeners on a descent fifteen years ago. Not entered.
- **Appearance (described):** A small room whose walls speak, faintly, in many voices at once, when a lantern is held up. The voices are not words.
- **Behaviour (described):** The room speaks. It does not answer. The lanterns within dim and brighten with the speech.
- **Cost:** Both Listeners lost, in the year after, the ability to sing in chorus. They could sing alone. They could not sing with others.
- **Custody:** Unsurfaced; unentered.
- **Rumour:** A confessional of the dead.
- **Storyline links:** A; E; B (Eilin reads it as a surviving Middle-Bright public space).
<!-- writer-only -->
- **Real nature:** A room with many small audio emitters still trickling on residual power. The chorus-loss is a real effect of repeated exposure to overlapping frequencies.
<!-- /writer-only -->

### The Long Window / Tier-F / catalogue entry only
- **Tier:** F
- **Discovered:** Rumoured, never surfaced. Spoken of by a returnee from the Mossbarrow whose mind was not trusted afterward. Hallen, whose name is on the record, claimed to have stood before a window taller than three men, through which he saw a road that was also the sky.
- **Appearance (claimed):** A pane of clear material, taller than three men and wider than two, set into a stone wall below the earth.
- **Behaviour (claimed):** Shows a landscape that is not there. Sometimes shows the Reach from above. Sometimes shows a continent with no fog.
- **Cost:** Hallen's mind.
- **Custody:** Presumed mythical. The Crown's sealed folio contains a single sentence: "If the Window is real, it is not to be broken."
- **Rumour:** A madman's door. Hallen's ravings. The Crown folio, if read, would partly vindicate him.
- **Storyline links:** C (sealed folio); D (aligns with Hallen's "below and beyond are one"); E (Kestrel believes).
<!-- writer-only -->
- **Real nature:** A large display window, possibly a remote-viewing port or a passive recording playback of surface footage. Plausibly real. Genuinely dangerous to the sanity of anyone who understands what they are seeing.
<!-- /writer-only -->

### The Counting Child / Tier-F / catalogue entry only
- **Tier:** F
- **Discovered:** A single Listener, twenty-one years ago, on a wet-silence descent under Mistmere, heard a child's voice counting — *ast, bel, keth, dun, sai* — in the old tongue. The Listener, Yan the Elder, did not descend further. He refused to return to the Listeners and is said to farm sheep near Jadehollow now. The counting has not been heard again.
- **Appearance:** None. A voice.
- **Behaviour (reported):** Counts to five in the old tongue, in a child's voice, and stops.
- **Cost:** Yan the Elder, on surfacing, could no longer count past five without losing his place.
- **Custody:** None. The object, if it is an object, is not located.
- **Rumour:** A ghost of a colonist child. A lost recording. A trick of the wet-silence's acoustics.
- **Storyline links:** A; B (Eilin has logged the five words); E (Sula's standing order: any cell hearing a counting child is to surface immediately and report).
<!-- writer-only -->
- **Real nature:** Possibly a small audio relic still cycling. Possibly a recording of an actual colonist child. Genuinely unresolved.
<!-- /writer-only -->

---

## Notes on cross-references and contradictions

Several relics are catalogued by two or more Listeners whose reports do not
agree. This is not a defect in the catalogue. Two Listeners are not expected
to agree on a relic's behaviour any more than two travellers are expected to
agree on the colour of the Fog on a given morning. The Guild preserves the
disagreements. Where a disagreement is load-bearing — where what the relic
does depends on which Listener is telling — both claims are in the entry.

A reader of the catalogue will find the following sympathies and oppositions
recorded by the archivist's hand:

- The **Husband** (A-0077) and the **Wife** (A-0191) are kept on one shelf. The archivist's marginal note reads: *one keeps what is set upon it, one holds what was set upon it.*
- The **Husband's Brother** (B-0024) is in Faith custody; it is, by principle, the larger sibling of the two above.
- The **Kettle-That-Remembers** (A-0102) and the **Unbroken Kettle** (E, Crown-held) share a glyph, a cost-family, and — two Listeners argue — a maker. The Guild does not confirm this in writing. It does keep them on the same shelf-row.
- **Small-Warm** (A-0158) shares its palm-numbness cost with the **Unbroken Kettle**. Listener Pella is on record: "They are one thing, broken twice."
- The **Wet Speaker** (C-0008) and the **Distant-Voice Stones** (E, Faith-held) are argued by two Listeners to be of the same family, crippled. Eilin, silently, agrees; she has made a margin-gloss in her private codex that reads only *sai-sai*.
- The **Thin Road** (B-0038) and the **Slow Drum** (C-0029) are grouped by Eilin as "touch-echo" objects. Vossel has copied this grouping. Sula has not.
- The **Silent Hearth** (C-0035) opposes the **Slow Drum** (C-0029) in principle. The archivist's marginal note reads: *one kills the sound of fire, one kindles the sound of no fire.*
- The **Always-Knife** (A-0185), the **Long Knife** (D-0004), and the **Unbreakable Metal** (E) are three rungs of one ladder. A reader familiar with all three can guess what the fourth rung might look like, and the Guild would prefer they did not.
- The **Patient Bead** (A-0188) and the **Unbreakable Metal** share a dream: an unending road. The bead's wearer dreams it occasionally; the smith who worked the metal dreams it nightly.
- The **Measured Breath** (D-0019) is in catalogue-opposition to the **Distant-Voice Stones** (E). One measures the field the other generates.

The archivist's hand, on the back flyleaf of the Stoneford ledger, has
written a single sentence, not dated:

> *Nobody has asked the catalogue a question in twenty years.*

---

## A note on naming

Every Listener is taught to name the relic they surface. The name is spoken
once, aloud, in the moment of lifting. The name is the last word of the
ritual of bringing-up. Names are not always apt. Some Listeners name what
they feared; some name what they loved; some name what they had lost the
day before. Sula's own first named relic, the Lantern-Killer, was named
for her lantern which she could not keep lit; she has never explained this
and has never been asked.

The catalogue accepts the name given. It does not replace a name later even
if the Listener, years on, would have named the thing otherwise. The name
is the name. The relic, under its name, is a thing that should not be here,
dug up by a hand that should not have found it, held by a person who will
not say aloud what it does to them.

This is the catalogue. It is not complete. It will not be.
