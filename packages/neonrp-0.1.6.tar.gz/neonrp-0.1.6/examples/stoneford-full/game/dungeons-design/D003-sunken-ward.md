# D003 — The Sunken Ward

## Snapshot
A cistern-and-cell complex beneath Mistmere's lower terrace, half-hospice and half-oubliette, where the Faith keeps inmates whose words the city is not allowed to hear. Players enter to find the mad returnee Hallen, to retrieve a Listener's contract-fragment from Sula's edge-cell, or because a sealed three-person slab in the central shaft has begun to sweat warm water upward.

## Location
- Nearest town: T005 Mistmere
- Region: The Grey Reach, lake-margin capital
- Terrain approach: A river-stair in an unlit alley beside the cathedral undercroft. Two steps above the water-line at noon; two below at dusk. The door is iron, recessed. The cathedral sexton carries a key. A Listener cell also holds a key; Sula does not record to whom she gave the copy.

## Historical layers
- **Pre-collapse.** The Sunken Ward's central shaft was a colonial-era utility shaft — water, cable, ventilation. Round. Pale-walled. Sealed at its lower end by a three-person slab that the First Wave set in place before closing the shaft upstairs. The slab has a name in the old tongue inscribed along its top rim: *ehn-sai-ven-u* — *silence-breath-prohibition*. Do-not-speak-here.
- **Guild-era.** The Faith built a hospice around the shaft six generations ago — cells off a ring corridor, an infirmary, a chapel. The hospice admitted lepers, mad pilgrims, and, in later decades, returnees from the deep Listener descents. By Malen's grandmother's time, it was a sick-cell for returnees only. The Faith calls it the Ward of Saint Hellon the Silent. The commoners call it the cathedral's other cellar.
- **Current.** Hallen, the mad returnee who saw **The Long Window (Tier-F)**, has been kept here for seven years. Sula's Listeners use three cells on the north ring as an edge-station — a dry room for drying ropes, a desk, a bunk. The slab in the central shaft has begun, in the last month, to weep warm water upward. The Faith interprets this as a saint's tear. Sula's senior Listener privately calls it a leak.

## Structure — surface-to-cistern functional zones

The ward is not strictly subterranean (it sits below street-grade but above the lake-level). Its lower reaches behave, to a descending Listener, as a **Shallow-find** stratum grading into **Bone-rooms** at the shaft's rim.

### Zone 1 — The Cathedral Stair / *the saint's way* (Faith) / *the back door* (commoners)
- **Description.** A narrow stone stair spiralling down from the cathedral undercroft. The walls sweat lake-water; a lantern held close shows the water catching the flame as a thousand small points. The air smells of stone and candle-grease and, faintly, of old bread.

  Lanterns hung every six steps, most lit. The flames stand straight. There is no draught on this stair, because the stair turns against the wind; it is the only place in the cathedral where a candle does not need a hand cupped round it.

  A painted saint at the landing — Saint Hellon the Silent, a finger to her lips, paint flaking from the finger. Her face is patient. Her finger is new. The rest of her has not been repainted in fifty years.

- **Hazards.** Wet stone. A sexton who will ask after the party's business in a low voice, without looking up from his hand-book.
- **Creatures.** None.
- **Items / relics.** *Septa's Robe / wet-ash grey* on a peg — borrowed, one can pass unchallenged in much of the ring corridor.
- **Clues / fragments.** The saint's painted finger has been repainted recently; the fresh pigment does not match. Someone is repairing the finger because the finger has been falling. The fallen paint is in a small heap below the landing, unswept.
- **Exits.** Down to Zone 2.

*Ambient.* The stair has forty-seven steps. The Septons know the number. A pilgrim counting is a pilgrim not yet initiated. The septas do not count. Their feet know. On the eleventh step from the bottom, one stone is worn deeper than the others — the step where a sexton a century ago slipped and caught his heel. The worn place has not been re-cut; the Faith teaches that a saint's way should remember its own accidents.

*Ambient.* The saint's painted finger, where the flaking has been fresh, shows red underneath the white. The wood of the saint's carved hand is pine, and the pine has taken a red stain from some older paint — or from something older than paint. The repainting septa has not commented on the red. She paints over it in a dry white, thickly. The red shows through after a month. She paints again.

### Zone 2 — The Ring Corridor / *the visiting hall* (Faith) / *the ring* (everyone)
- **Description.** An annular corridor circling the central shaft. Twelve cells open off the outer wall. The inner wall is the shaft-drum: a pale-stone cylinder, two men tall, drum-taut to a knock. A knuckle rapped against the drum gives back a single clean low note, always the same note, whatever the weather.

  The corridor's flagstones slope gently inward toward a channel that runs around the shaft-base. The channel is wet. The water in the channel is warmer than the stone of the walls.

  Candles in iron sconces, one per cell-door. The flames lean inward, toward the drum, consistently, as though there were a slow cold current drawing toward the shaft. A septa passes with a tray; her sandals do not make a sound on the stone.

- **Hazards.** A **Cave-Salamander** or two from the channel. Stone cold enough to take skin off bare hands in winter.
- **Creatures.** Septa attendants (not monstrous, but they will remember faces). On certain nights, the **Ashen Herald (M005)** walks the ring corridor. Candles die in a single line as it passes. The candles do not relight on their own; the septas do not relight them either, on those nights.
- **Items / relics.** A **Septa's Robe**, a *Road Lantern / guild-lantern*, a *Bone Whistle / shepherd's call* (taken from Hallen when he was admitted; still on the attendants' hook, unhung).
- **Clues / fragments.** The candles along the ring were replaced an hour ago. Two in the north are dead already. The wicks of the dead candles are bent toward the drum.
- **Exits.** Twelve cell doors (see Zone 3). A low iron door to Zone 4 (the shaft-rim). The stair up to Zone 1.

*Ambient.* Walking the ring at the corridor's height, a visitor's shoulder passes within a finger of the drum-wall at every fourth pace. At those paces, the drum gives back a faint warmth to the cloth — not through the stone's own temperature but through the wool of a robe drawing it. A septa's robe, hung on a peg in a cell overnight, is warmer on the drum-side in the morning than on the outer side.

*Ambient.* The channel at the corridor's floor runs warm water in a slow thread. Somewhere along the corridor, the water picks up a faint taste — a visitor who dips a finger and tastes finds salt where there should be none. The cathedral is not near the sea. The lake is freshwater. The salt comes from below.

*Pre-encounter traces (Ashen Herald).* On the nights the Herald walks, the candles begin to die an hour before it arrives. The dying is not linear; it is a wave around the ring, cell by cell, east to west, counter to the corridor's drainage. The septas know the sign. The septas leave.

### Zone 3 — The Cells / *the returnees' rooms* / Bone-tier edges
- **Description.** Twelve cells, numbered by the Faith in old-script from *ast* (1) to *keth-dun* (12). The numbers are cut shallow into the lintel of each door, painted white, repainted by the same septa, once a year, on Saint Hellon's day. Nine are empty. Three are in use.
- **Hazards.** Cells 7 and 12 are locked from outside. Cell 4 has a cold draught that blows a candle out three times in five.
- **Creatures.** None caged that are not human.

**Cell 7 — Hallen's Cell / *the window-sayer* (Listeners) / *the raving cell* (Faith)**
- **Description.** A small room with a straw pallet, a bucket, a single high grilled window at the street level letting in one shaft of grey. The grey shifts across the floor in the day. Hallen's eyes follow it without his head following it.

  The walls — every wall, all four — are covered in charcoal drawings, re-drawn, smudged, re-drawn. All of them are variations of a single image: a tall rectangle set in a stone wall, through which a road and a sky are visible, and at the far end of the road, a tower with a sun nailed to it.

  The rectangle is drawn the same width every time. The road is drawn at the same angle every time. The tower is drawn taller on the east wall than on the west. Hallen will not say why. Charcoal dust fills the corners of the cell, black on the grey stone. His fingers are black to the second knuckle and will not wash clean.

- **Hazards.** Hallen himself is not dangerous. He is thin and barefoot and will speak only in sequences that begin with the word *below*. A PC who listens for more than a count of a hundred must resist a dream-inducement afterward (same dream as the **Ancient Stone Shard**: a straight line drawn across the sky). The dream comes on the third night after the listening, never the first or second.
- **Creatures.** Hallen.
- **Items / relics.** Hallen's charcoal is, by accident, smudged with **Slow-Stone (C-0055)** dust the attendants swept in from the ring. A fragment of **Ancient Stone Shard**-family cut has been pressed into the wall behind the pallet, low, and Hallen has drawn around it — a circle, and then a square around the circle, and then a circle around the square. He will not let it be taken without a trade — he wants word of Eilin. Specifically, he wants to know whether she is eating. He does not know her. He does not know why he asks.
- **Clues / fragments.** Hallen says, and has been saying for three years: *Below and beyond are one. The floor is the far wall.* This is his ravings as catalogued in the Shared Brief. He will also say: *the sun is nailed. Go and look. Take my drawing.* If given clean paper and fresh charcoal, his hand steadies. The drawings on paper are sharper than the drawings on the wall. This steadying worries Sula.

*Ambient.* Hallen hums, sometimes, a two-note phrase under his breath while he draws. The phrase is not a song any septa recognises. The phrase is constant — two notes, the same interval, repeated at the span of a slow breath. The septa who sits longest with him, Sister Vela (unrelated to the Listener Vela at Tower Seven; a common Faith name), has written the phrase in her notebook as best she can without knowing music. The phrase, transcribed later by a Mistmere choir-master, is a colonial call-sign identical to the one pressed into the pedestal at D009. Neither Vela nor the choir-master knows this.

*Ambient.* When Hallen sleeps, his charcoal-stained hand rests open beside his face. The stain, overnight, transfers onto his cheek in the shape of his palm. The septas wash it in the morning. They do not comment on the fact that the palm-shape is always on the same cheek.

- **Exits.** Back to ring.

**Cell 12 — the slab-watch cell / *the listener's edge-station*.**
- **Description.** A dry room the Listeners use. The dryness is deliberate; a small iron brazier in the corner burns a pinch of Slow-Stone to keep damp out of the rope. A cot. A folding desk with a lantern. A coil of **Soft-Rope (B-0031)** hung by a single hook at the exact height a shoulder reaches. On the desk: a copy of a page from **The Listener Contract (Tier-E)**, with a line on the addenda inked over in a hand that is not Sula's.
- **Hazards.** A spring-trap under the desk leg — Kestrel's insurance against casual readers. Not lethal; a needle that stains the finger blue for a month. The stain does not scrub. The septas know the stain. They do not comment on it.
- **Creatures.** None most days. The senior Listener is at the shaft at dusk, a tall woman whose name is not kept in the cathedral register.
- **Items / relics.** A **Bone-Lamp (B-0062)** on a hook. Spare **Slow-Stone** in a waxed envelope. A single rope-signal slate, unused, propped against the wall.
- **Clues / fragments.** The inked-over addendum line, held to lamp-light, reads: *any Listener who hears the counting is to surface immediately and report.* This is Sula's standing order. The inking-over is by Kestrel. The ink he used is a slightly different black.
- **Exits.** Back to ring.

**Cell 4 — the draught cell / *the empty cell* / unoccupied**
- **Description.** The cell is empty. The door is unlocked. The straw pallet has been taken up and set against the wall. The draught comes through a crack where a stone has settled a finger's width. Through the crack, with a lantern close, one sees pale stone — the shaft-drum — curving away, and the faint line of a seam on the drum's inner face.
- **Hazards.** None direct; the crack is a quick way to knock on the drum without being seen.
- **Items / relics.** On the floor against the crack, a small pile of **Slow-Stone** powder, swept to one place by whoever kneels here. Someone has been listening. The powder is finer than the powder on the ring corridor's floor; this batch was ground by hand.
- **Clues / fragments.** Three fingernail-marks on the stone beside the crack, at a height a kneeling woman would reach. The nails that made the marks were bitten short. The kneeling was recent.
- **Exits.** Back to ring.

### Zone 4 — The Shaft Rim / *the saint's well* (Faith) / *the drum* (Listeners)
- **Description.** A circular chamber, ceiling low, the pale-stone drum rising through its centre. A railed walkway rings the drum. The drum's inner rim is at chest height; the shaft drops, straight, into dark.

  At the bottom of the shaft — fifteen paces down — the **three-person slab** lies horizontal, pale-stone, rimmed with the inscription *ehn-sai-ven-u*. A Bone-Lamp lowered on a cord shows the slab's top face as a pale square in the black. The slab is weeping. A thin sheet of warm water slides upward along the drum's inside wall by some slow capillary or by something under the slab pushing. The water collects in the walkway's channel and drains out through the ring corridor's floor-channel.

  The walkway's handrail is cold iron. A hand laid on it takes print, faintly, and the print fades within a count of sixty. The rail has been replaced twice in memory; neither replacement has loosened the print-taking.

  Standing at the rim, a listener hears, occasionally, a tap from below the slab. Not regular. Not quite random.

  The drum's inside face, viewed over the rail with a lamp lowered halfway, shows faint vertical striations — grooves the width of a hair, running the full fifteen paces from rim to slab. The grooves are evenly spaced. They are not a mason's cut; they are a machining-mark the visitor has no word for. Kestrel, on a visit he was not supposed to make, saw them and said nothing. He took a rubbing that he has shown only to Parn.

  The warm-water film, climbing the drum's inner wall, does so at a rate a trained eye can measure: a finger's height per count of forty. It reaches the rim-channel and spills over into the corridor-floor channel without a sound. The spill is silent because the film is too thin to make a sound; the channel receives the water by absorption rather than by drop.

- **Hazards.** The railing is old iron. Do not lean. The warm water is, on analysis, slightly metallic (Slow-Stone family residue). Breathing the steam for long produces a mild light-headedness and, in susceptible bearers, the same dream as the shard.
- **Creatures.** None resident. On one night in twelve, the **Ashen Herald (M005)** descends the Zone 1 stair, walks the ring, enters Zone 4, and stands at the drum's rim without looking down. It delivers a message to whoever is present, in the voice of someone that person obeyed in childhood, and leaves. The message is not an order. It is a name, spoken once.
- **Items / relics.** **Soft-Rope (B-0031)** coiled on a bollard. **The Measured Breath (D-0019)**, if brought within a pace of the drum, pins its needle. **Wet-Eye (C-0021)**, held to the shaft, shows the slab faintly lit from below — not flickering, steady, the colour of a winter sun through cloud.
- **Clues / fragments.** A chip of pale material at the drum's base — not matched by any sample in the Guild cabinet. Kestrel would pay. Sula would forbid.
- **Exits.** Back to ring. Down the shaft to Zone 5 — **only with Soft-Rope, the Held Breath mask, and a Faith dispensation or a bribed sexton.** Not fully playable in v0.1: the slab is the end-point. What is below it is Wet-tier and beyond v0.1 scope.

*Ambient.* Malen, on her fortnightly dawn visit, stands at the rim for a count she does not keep and lets her breath slow. She has not told anyone — not Darrik, not her own septa-attendant — that the shaft calms her. She thinks of it as a saint's comfort. It is not. The drum's faint, slow emanation matches the rhythm her childhood nurse used to tap on her back at sleep. The match is accidental. The comfort is real. Malen has begun, without noticing, to stand a little longer each visit.

*Ambient.* The Ashen Herald, on its walks, never looks at the slab. It stands at the rim with its face toward the ring-wall opposite. When it speaks its single name, the name carries across the drum-rim and is heard by whoever is present as if spoken at the shoulder. The name is always a name the hearer has obeyed. Sula has been here once on a Herald-night. The name spoken to her was not her mother's and not her teacher's. It was a name she has not spoken aloud since.

### Zone 5 — The Slab *(not playable in v0.1 beyond description)*
- **Description.** The slab is three paces long, one pace wide, pale-stone. Its inscription, read cleanly, is *silence-breath-prohibition*. The letters are cut deep; a finger laid in the cut finds the cut-bottom smooth.

  The slab has been hotter along its eastern third in the last month. A palm laid flat senses the warmth as a shallow gradient — not burning, only warmer than the stone wants to be. A fine crack runs along the east edge. A Listener with **The Measured Breath** and the **Bone-Lamp** can establish that the crack is widening by a hair per week. The Faith does not know.

  Where the warm water lifts from the slab, it lifts without source — there is no seep, no spring, no visible pore. The stone simply gives water back the way warm bread gives back steam.

- **Hazards.** Any attempt to pry the slab open is a three-person operation and will, in v0.1, fail: the slab will not move. The narrative consequence is the crack widening; the slab's eventual opening is a v0.2+ event.
- **Creatures.** None yet.
- **Items / relics.** The slab itself is catalogue-adjacent. The Faith has never reported it.
- **Clues / fragments.** A ridged pattern along the slab's underside rim, visible with a mirror — the same ring-of-dots-around-a-central-point seen on the **Colonist Crest Fragment (Veyl's)**.
- **Exits.** Up. (Down is not yet a direction.)

## Storyline links
- **Line E — Depth-Walkers (central beat).** This is Sula's edge-station. Hallen's cell is a Line E waypoint. Kestrel's inked-over addendum is a Crosser act of suppression the party can discover.
- **Line B — World Before the Fog.** Hallen's ravings — *Below and beyond are one. The floor is the far wall.* — are one of the four NPC theories for why relics are underground. His wall drawings are the **Long Window** as he remembers it.
- **Line C — Four-Crown Intrigue.** Malen the Unsleeping visits Zone 4 once a fortnight at dawn, alone. She does not know why the shaft comforts her. The **Ashen Herald (M005)** walks this ring on nights the Crown has acted. A PC who witnesses both visits within the same cycle banks a Line C clue.
- **Line A — Guild's Buried Charter.** Corvin has requested access twice; refused twice. The Guild's interest in Zone 5's inscription is quiet and hungry.
- **Line D — Iron Dragon Returns.** Hallen will, unasked, begin to describe *the straight line drawn across the sky* to any listener who stays long enough. Veyl has never been here. He knows it is here.
- **Named NPCs.** Hallen (cell 7), Archdepth Sula (visits the edge-station at dusk every fifth day), Malen the Unsleeping (fortnightly dawn), Corvin Ashford-Reed (refused entry), the unnamed senior Listener at cell 12.
- **Quest hooks.** (1) Extract Hallen's drawing for Eilin (Line B). (2) Lift the inked addendum for Sula or for Kestrel (Line E split). (3) Investigate the warm water for the Faith's Malen (Line C, unwitting). (4) Guard the slab during a reading — the slab must not be opened in v0.1.

## Writer notes
<!-- writer-only -->
Zone 5's slab caps a colonial-era vertical shaft that links, eventually, to the transit shelf under Jadehollow and, far below those, to the near-Chasm descent. The warm-water weep is residual heat from something waking at depth. Do NOT let the party open it in v0.1. The crack may widen; Malen may begin to hear the *counting child* through the drum-wall; the Faith may begin a minor inquisition. Kestrel's inking-over of the addendum is a first visible crack in the Sula-Kestrel split. Hallen's drawings are accurate; he did see a Long Window and is remembering it in charcoal. If the party gives him ink and clean paper, his drawings clarify and he becomes harder to dismiss. The Ashen Herald's "name spoken once" is intentional — the message-as-name lets the DM choose what name (dead friend, unborn child, the PC's own former self). The slab's water-without-source effect is a slow thermal/humidity phenomenon; keep the prose un-explained.
<!-- /writer-only -->

## Map sketch
```
     [Cathedral undercroft]
             |
     [Zone 1: Stair / St. Hellon]
             |
     [Zone 2: Ring Corridor]
      /   |   |   |   |   \
   [C1] [C4] [C7]  [C12]   ...
         draught Hallen Listener
             |
     [Zone 4: Shaft Rim / drum]
             |
      [weeping slab]
             |
     [Zone 5: not yet a direction]
```
