# D004 — Brokenspine Watchtrail

## Snapshot
A ruined watch-line along the Brokenspine ridge north of Wolfsjaw Pass, where a chain of collapsed stone towers once marked the last road of four kingdoms before the Chasm. Players enter to find the only land route that still reaches N001, to hunt a Hollowjaw pack that has not howled in a month, or because a Frostwolf scout has been leaving signs in the old garrison dice-script.

## Location
- Nearest town: T003 Wolfsjaw Pass
- Region: The Grey Reach, far north frontier
- Terrain approach: An eight-league climb along a broken ridge. The road was a military road once; now it is a trail. Snow above the tree-line even in summer. At the fifth watchtower, the trail forks: west into Frostwolf territory, north along the cliffs toward the Chasm (R010 continues from here).

## Historical layers
- **Pre-collapse.** A First-Wave beacon station stood at the highest tower (Tower Seven). The station's ground-floor ring carries old-tongue inscription — *reh-kor*, great-cliff-shining, the beacon's own name. The beacons were a chain, not a wall. They marked the northward road from the waves' landing point.
- **Faith-era and Guild-era.** The Faith recommissioned the chain five hundred years ago as a warning-line against the north wind-raiders. The Crown maintained it for three centuries; the Free North took over after the Khanate border treaty. The towers are marked with three seals layered: Faith, Crown, Free North. Six of seven towers collapsed in the ground-failure eighty years ago — the same winter the Ashford estate sank. One tower, Tower Seven, still stands.
- **Current.** Frostwolf scouts range west of the fifth tower. Hollowjaw packs (**M003**) den in Towers Two and Four. A Free North border-patrol passes every ten days. A single Listener cell — one woman, one lamp — keeps a vigil at Tower Seven on thirty nights a year.

## Structure — surface dungeon, tower-chain

Surface pacing: ridge approach → ruined tower-to-tower traverse → final standing tower as the "inner keep." Not a Relic-tier site; Guild does not dig here.

### Tower One — The Dipped Stone / *the first beacon* (commoners) / *the broken mouth* (Frostwolf scouts)
- **Description.** Base only. Four courses of cut stone in a square, set into the ridge as if the ridge had grown around them. The stones are darker than the ridge-stone; they were brought here, eight leagues up, by hands that are two centuries quiet.

  The floor inside the square is drifted with snow even in summer. The snow is fine, dry, windblown. A boot in the snow leaves a print that closes within the hour, the wind smoothing it flat from the south.

  A Faith sigil has been chiseled off the eastern face. The chiselling is old. What remains is a rough patch, lighter than the stone around it, the shape of a hand with a finger missing.

- **Hazards.** Cold. A sink-hole behind the north wall where the cellar fell in — snow-bridged in winter, a black mouth in summer. The drop is six paces to broken masonry.
- **Creatures.** Ravens (do not kill — taboo). A **Fogwort** patch in the lee of the wall, its grey-green leaves pressed flat by the wind, its smoke (if burned) making the burner hear a conversation at a distance that is not happening.
- **Items / relics.** *Iron Travelling-Bell*, rusted, under snow — a Faith bell, its clapper gone. *Fog Cairn-Sign* stacked by a Free North patrol: four stones, flat-on-flat, topped with a pebble.
- **Clues / fragments.** A message left in the cairn: three pebbles, two dark, one pale — a Free North sign meaning *we have passed, unharmed, recent.* The pale pebble is river-stone, not ridge-stone; the patrol brought it up.
- **Exits.** On the trail north to Tower Two.

*Ambient.* The chiselled-off Faith sigil's shape is a five-pointed knot — visible only in rake-light at dawn. A patrol rider named Jas, who sleeps in the tower's lee in summer, has photographed the shape in his head three summers in a row and drawn it in charcoal at T003's garrison mess. The charcoal drawings agree. He does not know what the knot means. Neither does any septon younger than sixty.

*Pre-encounter traces (M003).* Below Tower One, a raven-feather caught in a thistle — not dropped, but pressed down into the thorn, as if the feather had been held and the hand had then been drawn away. The thistle has not been moved.

### Tower Two — The Hollow / *the wolf-den* / M003 habitat
- **Description.** Partial standing base, roofed over by fallen beams and the weathered remains of the upper course. The roof sags in the middle; snow slides off it in slow plates that break on the sill.

  Inside, the air is warmer than the ridge-air. The warmth is an animal warmth. A pack has lived here through the cold season, and the stone has taken the warmth into itself.

  The floor is strewn with bones. Not fresh bones; bones picked to white, arranged — somehow, not neatly, but in a pattern — against the north wall. A miner's jaw. A shepherd's long-bones. A child-size skull.

- **Hazards.** **Hollowjaw Wolf (M003)** pack, 2–3 strong. Silent attack — the pack hunts without call, and the first sign of them is the shadow across the doorway, not a sound. Half-eaten kills at the entrance with hearts untouched. The Hollowjaw does not eat hearts. Old shepherds say the pack leaves the hearts for the mountain.
- **Creatures.** M003 pack. Ravens feeding on leavings.
- **Items / relics.** *Clan-Knife / forearm-blade*, broken, in a drift. *Greymantle Cloak*, ragged, chewed — one sleeve torn clean off. The cloak has a pin still on the collar: a Free North clasp.
- **Clues / fragments.** A Frostwolf arrow — Khanate fletching, white goose-feathers bound with blue thread — lodged in a beam at a height a sitting wolf would sit. The scout shot at the pack and missed, or was never meant to hit. The arrow shaft carries a notch cut into it, a Khanate signature, readable by Brenna.
- **Exits.** Trail north to Tower Three. A side-path west down the scree (Frostwolf territory, not a town node, hostile).

*Ambient.* The Hollowjaw den smells of blood gone cold. The smell is not fresh-kill; it is week-old kill, banked in the fur of the pack, released slowly through the breath of sleeping wolves. A shepherd who has stood inside the den once does not willingly stand inside it again.

*Pre-encounter traces (Hollowjaw pack).* Half a league before Tower Two, the trail crosses a short stretch of snow where the pack has crossed at a trot. The prints are paw-wide and deep; the wolves had been carrying meat. A line of dark spots in the snow beside the prints shows the meat was bleeding. The spots are small and regular — a drip-count of one per pace. The pack had been running in line.

### Tower Three — The Fallen Name / *the nameless* (Free North) / *the pretender* (Faith)
- **Description.** Collapse site. A pile of stone with a broken lintel jutting at an angle. The lintel carries half of a Crown seal — the other half is rubble underfoot, split along the seal's vertical axis. A clean break. As if the seal had wanted to be halved.

  Snow has drifted to smooth the outline into something like a cairn. In heavy wind, the drift resettles and, for an hour at dawn, a different outline shows: the shape of a man lying flat beneath the stones, curled. The outline is not a body. It is how the drift falls round what is beneath.

- **Hazards.** Loose masonry. Avalanche-risk north face in late winter.
- **Creatures.** A single raven nest in the lintel-crack. A pair of **Named-Wolves** have been seen here — do not name them, do not kill (Free North taboo). The wolves sit at a distance; they have learned from the Hollowjaw what men do, and they avoid.
- **Items / relics.** Under the fallen stone, a sealed iron-bound case (Crown couriers' lock). Inside: a *Sealed Letter, Crown Form*, seventy years old, mould-green, the seal broken long ago. Its contents are a routine grain-accounting note — but the courier never delivered it, and the courier is still under the stone. A knuckle protrudes from the rubble, three fingers' width from where the case was found. Pale. Unbroken.
- **Clues / fragments.** The date on the letter (seventy years ago) is the year after contact-silence began. Nothing in the letter addresses the silence. A routine note about a missing grain-shipment, the tone a clerk's, unhurried. The courier was carrying nothing urgent. He died anyway.
- **Exits.** Trail north to Tower Four.

*Ambient.* On still mornings before the wind rises, the drift-outline under Tower Three is most distinct. A traveller passing at that hour sees the curl of a man beneath the stones; by mid-morning, when the wind has worked the drift, the outline has become simply snow again. The traveller who has seen the outline does not forget it. Jas has seen it twice. He will not camp at Tower Three.

### Tower Four — The Watch of Rope / *the wolf-stair* / second M003 den
- **Description.** Two walls standing, two fallen, the stair still climbing up into empty air. The stair ends at nothing — the upper floor is gone, and the stair's last step is worn smooth by two centuries of rain.

  The upper landing hangs twelve feet above the floor, a square of stone suspended by two iron pegs driven into the standing wall. A knotted rope hangs from it, Listener-grade, still good. The rope has been knotted by a hand that Kestrel would recognise.

- **Hazards.** Second **M003** pack; this one is hungry, three strong. The stair's upper landing is rotten — the stone is sound, but the timber that braces it is dry-rotted; it will hold a climber's weight for one trip, not two.
- **Creatures.** M003 pack. A **Weeping Sheep** — do not slaughter (taboo) — wandered up here from a shepherd's flock and cannot get down. The pack has not attacked the sheep. They are waiting for something. The sheep's eyes are wet. Sheep do not weep. This one does.
- **Items / relics.** On the upper landing: a lit-once-and-abandoned camp. *Road Lantern*, empty of oil, wick untrimmed. *Surgeon's Kit / Merle's roll*, opened, two instruments missing — the pliers, a small bone-saw. *Waxed-Linen Map-Case* with a Grey Road map annotated by hand in a Listener's script — the annotations show the trail and mark Tower Seven with a triple-circle.
- **Clues / fragments.** The map's triple-circle is the Listener sign for *relic here*. The Listener Ylva, who used to surface B-tier at Mistmere, annotated this map three years ago and has not returned. A second mark, fainter, on the Chasm rim: a single circle with a slash through it — *do not descend*. Ylva drew both with the same pen.
- **Exits.** Trail north to Tower Five.

*Ambient.* The Weeping Sheep's tears have wet the stone where she stands; the wet patch is the shape of two small footprints side by side, and the wet does not dry, even in wind. The sheep does not move from the patch. She has not eaten the grass at the tower's base. She drinks from a puddle of her own weeping. The pack has not eaten her because the pack does not eat what weeps.

*Pre-encounter traces (Hollowjaw, second pack).* The upper landing's rotten beam has a tuft of wolf-fur caught in a splinter. The fur is coarse grey with a black guard-hair. The beam is at a height no wolf can reach by standing. A wolf has climbed, at some point, using the fallen timbers as a ladder. This is unusual. The pack is changing.

### Tower Five — The Fork / *the parting* / patrol meet-point
- **Description.** A half-tower, the southern half intact, the northern half cliffed off. Standing in the doorway, the ridge ahead falls away in a gravel-run; standing at the north edge, nothing — a drop, and air, and the white horizon.

  From its top, on a clear day, one can see the Chasm's mist-line as a white horizon. The mist does not reach the sky. It stops at a clean line, as though it were a slow sea. In late afternoon the line moves; a watcher at Tower Five can, over an hour, see the mist breathe.

  The trail forks here: west down scree into Frostwolf territory, north along a narrow cliff-track toward Tower Six and Tower Seven.

- **Hazards.** Cliff exposure. Wind — the gap at the fork funnels wind such that a standing man leans to remain standing.
- **Creatures.** Free North border-patrol — two riders, ten-day cycle — may be present. Their horses do not like the tower. They wait at a stone's throw.
- **Items / relics.** A patrol lean-to with *Ship's Biscuit* and *Amber Tea* in a tin; *Fire-Striker Kit*; *Road Lantern* filled. A *Frostwolf Sabre / Khanate steel* — left in the lean-to, either in error or as a message. The sabre's grip is damp. Somebody was holding it recently.
- **Clues / fragments.** A scratched sign on the lean-to's doorpost in old garrison dice-script (consonantal, used by Windrest Keep garrison): a name and a date, *OLRIC, the tenth of keth-dun*. Keeper-Commander Olric's name, carved by someone two centuries after his death. The cut-marks are deep. Whoever carved it had time and a steady hand.
- **Exits.** North trail to Tower Six. West scree into Frostwolf.

*Ambient.* The Free North riders who sleep at the lean-to have carved their initials on the inside of the roof-beam. Seven sets of initials, dated. The last set is four months old. None is repeated; each rider comes once and does not return. Their horses do not like the tower, and a rider who comes twice learns not to insist.

*Ambient.* In winter, the drift at the north edge of the tower writes a white letter against the fallen-away half — a shape that on some mornings reads, to a Faith-trained eye, as the old-tongue root *u* (prohibition). The shape is wind-drawn and returns with every fresh drift. Nobody has erased it because nobody has thought to try.

### Tower Six — The Silence / *the ear* (Listeners) / *the teardrop* (Faith)
- **Description.** Collapsed to one floor, open to the sky, but the walls stand shoulder-high. The sky over the ruin is almost always grey; the tower is in a rain-shadow, and rain falls around it and not into it.

  The floor is tiled in pale stone — **not local.** Each tile is the span of a hand. The tiles fit without mortar, and a blade slid between them finds no bottom. Walking on them produces no sound. Not muffled: no sound. A boot heel that would crack on the ridge-stone falls silent on the tile; a dropped cup rings once in the throwing hand and then stops as it touches.

  A spoken word in the room produces the word faintly, one breath delayed, as if from the far side of a valley. Two people in conversation hear each other twice — once in the speaking, once in the return — and the second hearing comes from a direction neither chose.

- **Hazards.** The silence is disorienting. A PC who remains here for a count of a thousand loses, for a day, the ability to hear whispers. (Writer discretion on sanity-grade cost.) A candle set on the tiles burns steady; the flame does not flicker at a spoken word. This is not normal.
- **Creatures.** A **Silent Mouse** or two — fitting the name too literally. They cross the tiles and do not click. No wolves come here. The pack in Tower Four does not hunt this way.
- **Items / relics.** **Silent Hearth / Tier-C / GUILD-C-0035** was surfaced from the tile-seam here five generations ago; the tile-layout is the source-site. One tile can be pried with effort — cost: the prier's hand trembles for a week (related cost to the Bone-Lamp's grip-weakening). *Old-Tongue Potsherd* with the roots *ehn-sai* (silence-breath).
- **Clues / fragments.** The echo-delay is the same delay as **The Thin Road (B-0038)**. Eilin has noted this. The tile-writing along the north wall — if the party scrubs moss — is three lines of old-tongue that read (Eilin's gloss): *the road ends at the edge. the edge opens. the edge is not a wall.* This is one of the most explicit pre-collapse inscriptions in the Reach. Rubbing-worthy. The moss across the writing is stubborn; it returns within a moon.
- **Exits.** Trail north to Tower Seven.

*Ambient.* At Tower Six, a visitor who strikes a flint on the pale tiles hears the flint's own tiny spark-sound in the head and not in the air. The flint works; the tinder lights; there was no sound of flint-and-steel. A Listener who knows the room warns new visitors before they strike. Otherwise the new visitor thinks her flint is wet and strikes harder. A new striker at Tower Six can be heard, from the trail below, as a series of silent swings of the arm.

*Ambient.* The tile-seam from which Silent Hearth was surfaced has been backfilled with a chip of pale-stone. The chip does not quite match the tile around it; it is a shade paler. Standing on the chip, a visitor hears her own footstep for the first time since entering the room. The chip does not absorb sound. Whoever set the chip knew this, and set it anyway, as a marker.

### Tower Seven — The Standing / *the Beacon* (Faith) / *reh-kor* (Listeners' name, from the inscription) / *the end of the road* (Free North)
- **Description.** The only tower still standing. Three storeys of dressed stone, windowless below, slit-windowed above. From the trail, at a league's distance, the tower looks like a pale tooth set in the ridge.

  A belt of pale-stone at the waist of the tower — inscription band: *reh-kor* cleanly cut, the lettering sharp as if cut yesterday. The pale-stone is lighter than the surrounding course, and it does not take lichen. Insects do not crawl across it.

  Inside, the ground floor is a single round room, floor flagged, an iron brazier cold, a ladder to the second storey, a second ladder to the third. The ladders are Listener-replaced; the brazier is original to the tower.

  The roof opens to the sky and carries the beacon-cradle — empty for eighty years. The cradle is shaped for a fire the size of a bonfire, but the cradle itself is clean; no soot. The cradle has not held a fire in memory.

- **Hazards.** The ladder rungs are old. The beacon-cradle, if a fire is lit in it, is visible from Wolfsjaw Pass (any such fire summons the Free North patrol within two days). A lit cradle is also visible, in theory, from the Chasm's near rim. In theory, something on the far side may see.
- **Creatures.** The Listener vigil — one woman, *Listener Vela* — may be present. She is small and quiet and drinks a tea that smells of iron. Her lamp burns **Slow-Stone**-mixed oil. She will speak to a party with correct Guild chits. Otherwise, she watches.
- **Items / relics.** On the second floor, wedged under a floorboard: a **Patient Bead (A-0188)**-family piece, unsurfaced, unnamed. It sits in the split between two boards, the thread through it slack, pointing. On the third floor, in the beacon-cradle, a pinch of **Slow-Stone** and a Listener's rope-signal slate. In the ground floor iron brazier, a pre-collapse inscription on the brazier's inside bottom: a ring of dots around a central point — the **colonist crest mark**. The crest is not visible unless the brazier is lifted.
- **Clues / fragments.** Vela keeps a sparse log. The last entry: *tenth of keth-dun. no cloud. the counting was heard once, faint, at the drum.* — "the drum" is her word for Zone 4 of D003; she is in correspondence with the Mistmere edge-station. *This ties D004 to D003 as a single Listener long-watch.* Vela's previous entries are mostly blank dates; blankness is the record's normal. An entry with words is a worry.
- **Exits.** North, the trail to N001 begins. Ground floor door. Beacon roof up.

*Ambient.* Vela keeps a small pot of tea on the ground floor brazier even when the brazier is cold. The tea is iron-tasting, and her kettle is iron. She drinks it at the hour she has chosen; she has chosen to drink it at the hour when the mist over the Chasm — visible from the third floor's slit — most often parts. The parting is irregular and she misses it more often than she catches it. She drinks the tea anyway.

*Ambient.* On the second floor, the floorboard under which the Patient Bead sits has been walked over by Vela many times. She has not noticed it. The bead is pointing; the thread it is on is slack because Vela is here, and pulls taut when she leaves. A Listener who sits in Vela's absence and watches the floor sees the thread draw slowly, over a day, in a direction that points — not north, not south, not toward the Chasm — but across the trail, east, toward D009.

## Storyline links
- **Line C — Four-Crown Intrigue.** Frostwolf arrow in Tower Two hints at Khanate scouts; the Crown-courier letter in Tower Three is a stalled communication line; Tower Five's lean-to and the Frostwolf Sabre are a border-patrol exchange; Tower Seven's brazier colonial-crest is a Line C royal-lineage clue (one Crown envoy has been here quietly).
- **Line D — Iron Dragon Returns.** Vela's log — *no cloud* — is a D-line sighting log. The beacon-cradle, if lit, is a provocation Veyl might arrange.
- **Line E — Depth-Walkers.** Vela's correspondence with the Mistmere edge-station is a Listener long-watch; Ylva's annotated map in Tower Four is a Listener relic-marker. Kestrel knows Tower Six's tile-seam and wants a tile.
- **Line A — Guild's Buried Charter.** The Tower Six inscription *the road ends at the edge* is the kind of fragment the Guild would need to connect to the Northern Ban's decree language. Olric's name carved at Tower Five is the sub-soul anchor — though Olric's actual grave is at D005 (see below).
- **Line B — World Before the Fog.** Tower Six is the single clearest inscribed pre-Fog statement a PC can read in v0.1 without permission of a king.
- **Named NPCs.** Listener Vela (Tower Seven vigil). Free North border-patrol (two unnamed riders). Ylva (absent, map in Tower Four). A Frostwolf scout (referenced by arrow and sabre, not present).
- **Quest hooks.** (1) Recover Ylva's map for the Listeners. (2) Deliver Vela's next sealed note to the Mistmere edge-station. (3) Free North commission: clear a Hollowjaw den. (4) Free-range: find the route to N001 — this is the only viable land route.

## Writer notes
<!-- writer-only -->
Tower Seven's *reh-kor* band and the brazier crest are the clearest visible pre-collapse architecture in the v0.1 playable area. Avoid explaining the inscription; let NPCs translate only the roots. Tower Six's tile-room is a small-scale active noise-cancellation floor (same principle as **Silent Hearth**). Vela's correspondence with D003 is the connective tissue between Line E edge-stations — she and the Mistmere senior exchange signals by letter, not by any relic. If the party torches the beacon-cradle, it is a narrative-visible event: every Listener cell in the Reach notices. The "rain-shadow" over Tower Six is a residual field effect; prose only, no explanation. Tower Three's drift-outline should hint without confirming that more than one courier lies beneath.
<!-- /writer-only -->

## Map sketch
```
(South / T003 Wolfsjaw)
   |
[Tower One: Dipped Stone — ravens, Fogwort]
   |
[Tower Two: Hollow — M003 pack]
   |
[Tower Three: Fallen Name — buried courier, grain letter]
   |
[Tower Four: Watch of Rope — M003, Ylva's map, Weeping Sheep]
   |
[Tower Five: Fork] ---- (west → Frostwolf scree)
   |
[Tower Six: Silence — Silent Hearth tile-seam, north-wall inscription]
   |
[Tower Seven: Standing — Vela's vigil, reh-kor band, brazier crest]
   |
(North → N001 Great Chasm approach, R010)
```
