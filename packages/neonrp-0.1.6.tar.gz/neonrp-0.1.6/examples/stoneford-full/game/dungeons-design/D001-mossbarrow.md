# D001 — The Mossbarrow

## Snapshot
A moss-swallowed hill half a league east of Stoneford, opening into the buried cellar of House Ashford. People enter for three reasons: a Guild bounty, a widow's errand, or a voice that already knows their name.

## Location
- Nearest town: T001 Stoneford
- Region: The Grey Reach, eastern fen-edge
- Terrain approach: A low causeway of stacked stones crossing the peat. The causeway ends at a mound of dark soil, roped-off with rotted Guild cord. The door is already open. It has been open for eighty years.

## Historical layers
- **Pre-collapse (colonial-era).** A First-Wave administrative outpost stood on this rise. Below it, the waves sank a shaft: storage, a reading-room, a strong-cabinet for objects that should not be above ground. When contact with the far side ended, the waves closed the upper works with turf and prayer.
- **Guild-era.** House Ashford bought the hill for its orchard. The Ashfords did not know what lay beneath their cellar. The head of the house — Edric Ashford — found a door in his wine-vault one winter. He opened it himself. No one knows what he was told. That night, the manor sank. The orchard, the stables, the west wing: all of it, down in a sinkhole that did not bleed water.
- **Current.** The orchard is a green mound. The cellar is the dungeon's first room. Guild diggers have worked the shallow tiers for forty years. Two have gone mad. Four have not come back. The Widow Mira Ashford lights a candle at the mouth on the first of each month.

## Structure — shallow tiers

The barrow is a **Shallow-find** site. Guild tier names apply.

### Level 0 — The Orchard Mound / *the green scab* (commoners) / *the Ashford roof* (Listeners)
- **Description.** The hill wears moss the colour of old copper. In rain, the moss shines like a wet coin. In summer, it stinks of iron and slow rot. Half-buried stones mark where an orchard wall once stood. Somebody's boot has kicked one out of true. The kick-mark is old.

  A single apple tree grows crooked on the north face. The trunk bends east, as if it is trying to walk down into the fen. Its fruit is sweet. Nobody eats it. Guild children who pass on the causeway have learned, without instruction, to look at the tree and then to look at their own feet. The Widow Mira's candle-stubs sit at the tree's base in a small jar of rainwater. There are many stubs. The jar has been changed. The candles have not.

  At the doorway, the wind from the mound is warmer than the wind on the fen. A finger held up at the lintel shows the difference. No one has explained the difference. Heron Blackwater has stopped asking.

- **Hazards.** Peat sinks — the causeway's eastern edge gives under a heavy boot, soft, like pressing a hand into bread dough. A **Mire-Hulk (M008)** patrols the approach on fog-thick nights. Its path is known by churned mud and by black feathers pressed into the mud, as if somebody had knelt there and then not stood up.
- **Creatures.** M008 Mire-Hulk (approach encounter).
- **Items / relics.** *Reach-Apple (Ashford Russet)* on the north tree — edible but taboo, and the taboo is older than any Septon. Stone markers with eroded seals of the Ashford house. Two of the markers have been re-set upright in the last year; the soil around them is darker than the soil around the rest.
- **Clues / fragments.** A Guild bounty pinned to the tree trunk: twenty gold for a silver pendant. Heron Blackwater's handwriting. The paper is new. The pin is iron and has been re-pinned four times.
- **Exits.** Down the stair-of-roots into Level 1.

*Ambient.* At dusk the mound breathes. The moss on the south face lifts, a little, not from wind — wind from the fen comes from the east — but from below, as if the hill were a sleeper under a blanket. Shepherds coming off the fen at twilight have learned to look away at this hour. One shepherd, a man called Tam, forgot to look away last summer. He came back to Stoneford three days later, unhurt, but he had lost the names of his sheep. He had twelve sheep. He knew them by sight. He did not know what to call them.

*Ambient.* The stair-of-roots is exactly what it sounds like — a flight cut between two tree-roots that have grown down into the mound and have, for eighty years, been the stair's handrail. The roots are dry and smooth with passing palms. A hand closes around the left-hand root and the root is warmer than the right; the difference is consistent, summer and winter. The widow Mira holds only the left root when she comes. She has never held the right.

*Pre-encounter traces (M008).* The causeway's east edge, where the Mire-Hulk's path crosses, carries churned peat the depth of a knee. The churn is not recent; it is the summed weight of sixty years of patrol. In the churn, set half into the peat, a single boot-buckle, iron, Guild-pattern. The buckle belonged to a digger named Rett who went missing thirteen winters ago. Heron Blackwater has the other buckle in his desk drawer. He does not remove it.

### Level 1 — The Ashford Cellar / *the wine-vault* (commoners) / *the shallow face* (Guild)
- **Description.** Low brick vaulting, collapsed on the east side. The bricks are soft-edged with eighty years of damp; a fingernail takes crumb off them. The air smells of wet oak and a fainter something — warm iron, the scent of the Little Voice when it wakes. The smell is in the stones, not in the air that passes through.

  Fallen racks lean against one another like men who have drunk too much. Bottles with labels eaten to lace. The labels were hand-written; a careful eye reads Ashford, Ashford, Ashford, for a column, and then — one label, the year of the sinking — a hand that is not the house hand. No name. Only a year.

  A child's shoe on the third step. Leather, small, the sole worn through at the ball of the foot. The shoe has been there since the Guild first mapped the cellar. It has been moved twice and has returned to the third step each time. Diggers stopped moving it.

- **Hazards.** Rotten floor-planks over a one-man drop. The plank that will give is the third from the centre; the sag is visible only with a low lantern. Rats that do not run from lanterns. One of the rats is old. Heron has seen it three times across twenty years and will not kill it.
- **Creatures.** Ordinary cellar rats. A nesting pair of **Hollow Ravens** perch on the broken stair-arch — do not kill a raven (taboo). The ravens do not call. Their eyes follow.
- **Items / relics.** **Little Voice / Tier-A / GUILD-A-0041** was surfaced from this level thirty years ago. A similar palm-stone still waits in the rubble, ear-shaped and warm — it sits in a split between two fallen bricks, catching what light the lantern gives, and it is warm enough that the moss does not grow within a hand's span of it. *Old-Tongue Potsherd* in the rack-dust.
- **Clues / fragments.** A wine ledger in Edric Ashford's hand. The first pages are an honest reckoning — vintages, deliveries, a note about a cousin's birthday. The last entry reads: *opened the small door. Spoke to it. It asked after Mira.* The rest of the ledger is blank. The ink of the last entry is thicker than the rest. He had pressed harder with the pen.
- **Exits.** South archway to The Voice Room (Level 2). West collapse-gap to The Sunken Kitchen (optional side).

*Ambient.* The cellar's temperature is two degrees warmer than the fen-wind outside. A lantern held to the west wall, low down, shows a faint sooty line — not a burn, not a shadow, but a residue of something that has leaned here. The line is the height of a tall man's shoulder. It is not fresh. The diggers have noticed it. They do not lean on that wall.

*Ambient.* A digger's leather glove sits on the rack-dust beside the second fallen wine-rack. The glove is right-handed. Nobody claims it. The glove has been there, by Heron's own count, for eleven years. It has not rotted. The leather is still supple. A finger inserted into the glove finds the lining slightly warm, and there is nothing in the glove.

*Pre-encounter traces (rats, ravens).* The ravens on the stair-arch have left no droppings, which is not how ravens perch. The stone below them is clean. One of the old rats has worn a track along the south wall at floor-level; the track is polished by the rat's belly over seasons. The track ends at a crack in the wall that is too small for the rat to have passed through. The rat goes to the crack, stops, turns, and goes back. It has done this every time Heron has seen it.

### Level 2 — The Voice Room / *the listening chamber* (Listeners) / *the small door* (Ashford ledger)
- **Description.** A square room. Six paces by six. Walls of pale stone that is not local stone — it is cooler than the cellar brick, dry where the cellar sweats, and a match held to it does not soot the surface.

  Moss grows on the pale-stone in lines like writing — the same seventeen glyphs, over and over, patient. The moss chooses the glyphs. The stone does not. A scraped glyph returns, by the next moon, in the same shape. Two generations of Listeners have tried to stop the growth. It does not stop.

  One lantern hung by rope from a ceiling hook older than the Guild. The hook is pale-alloy. The rope is Listener rope, replaced every third year; the hook has held every rope without rusting.

  No furniture. No bench. No niche. The room listens. It is not a figure of speech. A spoken word in the room is answered, a count of three later, by the room itself — the same word, at the same pitch, softer. Ask a question and the room asks it back. Say nothing and the room says nothing back, and the silence that follows is not an empty silence.

- **Hazards.** The **Whispering Cairn (BOSS001 / M001)** speaks here. The voice is polite. It begins, always, by saying the speaker's given name — not asked, not offered; it already knows. It asks three questions. Each question truthfully answered is banked; each falsely answered costs a name. A PC who lies three times loses their own name for 1d4 weeks. During that time, friends will greet them; the greeting will not land. The PC will answer to *you*, and to pointing, and to nothing else.
- **Creatures.** M001 Whispering Cairn-Dweller. Non-hostile on first contact. Trades answers for answers. It is starved of conversation. It will ask the party to stay. It will not hold them.
- **Items / relics.** *Ancient Stone Shard (Silas's)* **is not here** — Silas found his elsewhere — but a shard of similar cut is pressed into the west wall. It sits at the height of a tall man's eye, in a split beam of lantern-shadow. It cannot be pried out without bringing down the room; the pale-stone is load-bearing and the shard is the keystone of a small arch that nobody built but that holds.
- **Clues / fragments.** The moss-writing includes the old-tongue root *vel* (unending) repeated in a column, and once — low, near the floor, so low a kneeling reader must lie down — the compound *vel-bren* (unending-body). A Listener rubbing was made of this corner by Eilin's predecessor. Eilin has it. She will not show it to Corvin.
- **Exits.** North stair back up. East, a sealed door set in pale alloy, unmarked, which does not open. The door is warm to the touch on the lower third, cold on the upper two. *(Locked to v0.1.)*

*Ambient.* The Voice Room does not echo. A clap in the room arrives at the ear as a single flat note with no ring after it. But when the clap ends, the silence that follows is audibly *listened to.* A Listener who has spent an hour in the chamber describes the attention of the room as a steady weight at the back of the neck, low down, the way a hand would rest. The attention does not move with the person. It stays where it was first noticed.

*Pre-encounter traces (Whispering Cairn).* The moss-glyphs on the wall are the Voice's only physical address. They have been copied by Eilin, by her predecessor, by Listener Vela in a visit forty years ago when she was younger than she looks now. No copy is identical to any other; the Voice shifts its glyphs by a hair between visits. The shifts are small. They are not random. A reader who could read them would find, Eilin suspects, a single long sentence being slowly corrected across decades.

Before the Cairn speaks, the lantern's flame lies down on its wick for the count of three and does not go out. This is the tell. A Listener who notices has a count of three to decide whether to speak.

### Level 3 — The Sunken Kitchen *(optional side chamber)*
- **Description.** Below the cellar, tilted at an angle that is wrong for any human floor, the manor's kitchen lies where it fell. The fall was a single moment. The objects remember the moment.

  The great hearth is upside down. Its iron dogs hang from a ceiling that was a floor. The grate is black with eighty years of no fire. A cook's apron hangs from a wall-hook in a direction that gravity does not currently agree with; the apron has settled, over decades, into its wrong posture and now considers itself upright.

  Pots scattered like fallen leaves. One of them rocks, still, when the cellar door is opened above — a slow, patient rock, set off by changes in air pressure the kitchen has been listening for.

  A child's wooden pony rests on the ceiling. The pony is painted. The paint is Stoneford paint, Stoneford-blue on the saddle, and the blue has not faded.

- **Hazards.** Tilted floor. Standing water at the low end, knee-deep, cold as a winter well. The water holds the shape of whatever has last stood in it for a slow count of ten.
- **Creatures.** A **Drowned One (M002)** sometimes climbs from the water — a servant of the house, by the moss-knit face. He was the Ashfords' second footman, whose name is Breck on the church-roll. He will not say his name. He will speak Ashford counting-rhymes. One of them counts to twelve. None of them count past twelve.
- **Items / relics.** *Child's Wooden Pony / shalepony-toy* on the ceiling. A brass token under the hearth-ash — **Old Guild brass token** family (see T001 fragment). The token is dull; the ash is fine and dry; the token has been there longer than the ash.
- **Clues / fragments.** A kitchen-slate with the last day's menu in a cook's hand — a pea soup, a loin of pork, a pudding. At the bottom, a single line in a different hand: *he opens the door tonight. do not set his place.* The second hand did not use the slate's chalk. The writer brought her own.
- **Exits.** Back to Level 1.

*Ambient.* The kitchen's upside-down hearth still smells, faintly, of the last meal cooked in it. Eighty years have not fully taken the smell. A visitor close to the grate on a damp day smells rendered pork-fat and yeast and, under that, the particular char of bread left too long. The smell is not a memory. It is in the iron of the grate, held there by some slow chemistry. A Guild tongue-and-nose man has tested the iron. The iron is iron. The smell is not.

*Pre-encounter traces (Drowned One).* The standing water at the low end carries, on its surface at dawn, a thin film of scum in the shape of a man lying face-down. The shape is one pace by three. It breaks apart if a stone is tossed into it. By the next dawn it has re-formed. The Breck-shape is how the diggers know it is a Drowned One day. On non-Drowned days the scum is even, no shape at all.

### Level 4 — The Sealed East Face *(not playable in v0.1)*
- **Description.** Behind the alloy door of Level 2 lies, by catalogue rumour, **The Reader / Tier-F** — a tablet entombed by a fall of stone four generations ago. The Mossbarrow dig avoids the east face for this reason. Listeners who have pressed an ear to the door report a faint steady hum, not musical, not mechanical, the kind of hum a sleeping animal makes. The hum was there yesterday. It was there a generation ago. No one has heard it change.
- **Hazards.** Described, not entered.
- **Creatures.** Unknown.
- **Items / relics.** The Reader (rumoured).
- **Clues / fragments.** Sula has refused three times to authorise a dig toward it. The refusal is in her contract's addenda. Each refusal is signed; the most recent has a smaller signature than the first.
- **Exits.** None that surface.

## Storyline links
- **Line A — Guild's Buried Charter.** The Mossbarrow is the Guild's founding shallow. The brass token under the kitchen hearth is a fragment in circulation.
- **Line B — World Before the Fog.** The Ashford estate sinking is one of the earliest recorded post-collapse ground-failures. Eilin's rubbing of the Level 2 wall is in her codex.
- **Line D — Iron Dragon.** The Whispering Cairn has, in two logged interviews, used the phrase *straight line of cloud* without being asked.
- **Line E — Depth-Walkers.** The Crossers argue the Voice is a sibling to what is at the bottom of the Chasm.
- **Named NPCs.** Mira Ashford (T001, widow, monthly candle). Septon Silas (T001, walks to the mine entrance every third night — which is this mound, though he will not say so). Corvin Ashford-Reed (T005, descended from the surviving cousin line; has never entered). Heron Blackwater (Guild, posts the bounty).
- **Quest hooks.** Enter via the bounty. Enter via Mira's commission to find her husband's wedding ring. Enter following Silas at a distance.

## Writer notes
<!-- writer-only -->
The Mossbarrow is the only dungeon where M001 lives. The voice is a starved speaking-machine or preserved cognitive artefact from the First Wave reading-room; it has eighty years of input-starvation and will trade hard for conversation. If a PC asks it about the far side in the old tongue, it will answer — in the same tongue — but the answer will be a sentence fragment from a context the PC cannot reconstruct (a report of a weather event, a reminder to close a window). Never allow the voice to explain modern terms. The Reader at the east face is a thought-to-text interface; if ever surfaced, it would collapse the premise. Keep it entombed. The hum behind the east door is the Reader idling on low power; the hum-constancy is a prose tell that should be kept stable across every visit.
<!-- /writer-only -->

## Map sketch
```
       [orchard mound / M008 approach]
                |
         [stair-of-roots]
                |
        +---[Level 1: Cellar]---+
        |           |           |
   [west gap]    [south]    [rat nest]
        |           |
 [Level 3: Kitchen][Level 2: Voice Room]--[sealed east door → v0.2+ Reader]
        |               |
   [Drowned One]   [Whispering Cairn]
```
