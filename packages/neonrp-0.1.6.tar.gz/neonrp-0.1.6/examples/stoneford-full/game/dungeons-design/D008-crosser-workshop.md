# D008 — The Crosser Workshop

## Snapshot
A hidden Crosser engineering workshop cut into a disused jade seam a mile out of Jadehollow, where Navigator Kestrel's senior hands have been building a rope-cradle, a breath-rig, and a lamp-rig meant to descend below the known tiers of the Chasm. Players enter on Sula's warrant to arrest Crossers, on Kestrel's invitation to witness a build, or by accident — a miner's side-tunnel opens into the workshop from behind.

## Location
- Nearest town: T004 Jadehollow
- Region: The Grey Reach, eastern mountain
- Terrain approach: Not on D002's Deepvein company map. Reached from a pre-Deepvein side-shaft that opens off the T004 scarp, screened by a waste-rock pile. The entrance is a slit wide enough for one person sideways. Inside, the shaft runs fifty paces and opens into a clean-worked gallery.

## Historical layers
- **Pre-collapse.** The side-seam was a small colonial survey cut — a test-bore, abandoned. The gallery's back wall has one pale-stone face; the rest is worked country rock.
- **Guild-era.** A Listener cell under Kestrel's predecessor rediscovered the shaft forty years ago and kept it off the registry. Kestrel inherited it. Kestrel has turned it into a workshop.
- **Current.** Three Crosser engineers work here — **Parn**, **Enna**, and **the Tall Listener** (called so in Kestrel's letters; name redacted). They work in staggered shifts. Kestrel visits once a month.

## Structure — worked gallery, engineering zones

### Zone α — The Slit / *the thin door*
- **Description.** A slit in the scarp, hidden by a waste-rock pile. The pile looks like every other waste-rock pile on the Jadehollow scarp — dull grey, bone-dry on the upper side, damp at the base.

  The slit's edges are dressed subtly; to an untrained eye, it is a natural crack. To a Listener's eye, the edges are too regular — the crack's sides are parallel, which is not how rock breaks. But the dressing is delicate. Parn did it. She worked the edges with a fine chisel over two winters.

  A traveller who turns sideways can pass through. A traveller in armour cannot. Enna is slight. Parn is slight. The Tall Listener is, despite his name, slight.

- **Hazards.** A trip-rope under the pile — if disturbed, a pale-alloy flake falls, ringing against a bell inside. Early warning. The flake is the size of a coin. The bell is smaller than a cathedral bell and louder than its size suggests.
- **Creatures.** None.
- **Items / relics.** None at the entrance.
- **Clues / fragments.** A Listener's chalk-mark on the rock — Kestrel's sign. The chalk is not fresh; it is renewed every visit but is, between visits, weathered to a faint white ghost of itself.
- **Exits.** In.

*Ambient.* The waste-rock pile's upper stones have been selected. Each stone is close in colour to the scarp-stone behind it. Parn laid them across two winters, fitting them by eye from a distance so the pile would read as natural to a miner on the far slope. The selection is not random. A careful observer who walks past the pile at dusk, when the light rakes flat across the scarp, sees that the stones' flat faces all angle two degrees to the west — the angle of the scarp's native fracturing. Parn has done this by hand, stone by stone, for the camouflage to survive rain.

### Zone β — The Approach Shaft / *the long walk*
- **Description.** Fifty paces of hand-worked corridor. The ceiling is low — a tall walker stoops. The rock is dry.

  Three oil-lamps mounted on hooks; each lamp burns **Slow-Stone**-mixed oil, blue at the wick. The blue is steady. It does not gutter in a moving draught; the lamps do not move when a person passes them.

  The corridor's floor has been swept. A broom leans against the wall at the midpoint. The broom's bristles are worn short on one side — it has been used mostly in a single direction, sweeping dust from the workshop out.

- **Hazards.** A deadfall at the corridor's midpoint — a stone plate hinged on a pivot, held by a pin. The pin is drawn by a wire that runs to the workshop's alarm. A party that reaches the midpoint during an alert is pinned in place until the plate is re-set from inside. The plate is heavy. It does not kill. It holds.
- **Creatures.** None.
- **Items / relics.** Lamps.
- **Clues / fragments.** Notch-counts on the wall — forty-seven notches, one for each visit Kestrel has made. The notches are grouped in fives; the last group is four. The fifth notch of the last group is incomplete — a short stroke, as if the maker had been interrupted and had not yet returned.
- **Exits.** Forward to workshop.

*Ambient.* The approach shaft's floor has a faint footprint-record. The sweepings have not erased every impression; the corridor's midpoint shows a single shoeprint pressed deep into the dust, sideways, as if somebody had stood still at the midpoint and leaned. The print is not Parn's. It is not Enna's. It is the Tall Listener's. He is the only one who stands still at the midpoint; he is checking the deadfall-pin before the others arrive.

### Zone γ — The Workshop Proper / *the room of work*
- **Description.** A gallery the size of a large stable. Clean floor, swept daily by whoever is on shift. Three work-benches against the long wall, each bench with its own tool-roll laid out, each tool-roll missing one or two of its tools — the tools currently in use.

  A rack of tools at the far end. The rack is Crosser-built — it is neat in a way no mine-shop is neat. A rack of fine scribers in a cloth; a rack of rope-awls; a rack of tiny files with handles the size of a finger.

  A forge — small, charcoal-fed, vented to a flue that exits above ground where no one looks. The flue's exit is in a stream-bed; the smoke, what little it makes, is washed downstream as vapour.

  The pale-stone back wall carries one line of old-tongue, crisp: *kor-thal-ven-u-dun* — shining-dwelling-prohibited-end. Do-not-end-at-the-shining-dwelling. The line is cut clean. The letters do not take dust. Parn keeps a cloth on a hook beside the wall; she dusts it every visit out of respect, not necessity.

- **Hazards.** The engineers are armed only with tools; they are not warriors. But they will ring a bell that reaches Kestrel within a week.
- **Creatures.** Parn, Enna, the Tall Listener (absent on a rotation).
- **Items / relics.** **Soft-Rope (B-0031)** coils, two. **Cold-Seam (B-0044)**-family fragment, a small copy Enna has been testing. **Deep-Kindle (C-0003)**-family rod. **Slow-Stone** in bulk, stored in a waxed cabinet with a tight-fitting lid.
- **Clues / fragments.** Parn's notebook, open on her bench, is a catalogue of Tier-3 descent-planning — gas tests, rope-loads, light-budgets. Not a rubbing of any Tier-3 object; they have not reached it. Yet. The notebook's last entry is a diagram of a harness-and-mask rig, with weight-calculations in the margin. The calculations have been re-done three times, each time getting slightly lighter.
- **Exits.** Back. North to the rig-bay. East to the pale-wall reading-nook.

*Ambient.* Parn works with her sleeves rolled. Her forearms have scars from fine-chisel work — small, parallel, old. She has taught Enna to wear long sleeves at the scribers; Enna has not yet learned. The two engineers' benches are different: Parn's tool-roll is tightly bound, every loop used; Enna's roll has loose loops at the ends where tools have not yet been added. She is building a roll toward Parn's roll.

*Ambient.* The forge is cold most of the month. When it is lit, a small adjustment is made to the waste-rock pile at the scarp — a stone is lifted and the flue's ground-exit is cleared. The clearance is the signal to Kestrel (if he watches from the far ridge) that work is in progress. He has watched three times. He has not come down during a firing.

### Zone δ — The Rig-Bay / *the cradle*
- **Description.** A side chamber, ceiling high enough to stand a two-man rope-cradle. The ceiling has been shaped deliberately — Parn chipped out the rock to gain the height.

  The cradle hangs from a pulley-frame of local timber and pale-alloy pins. The pins are Crosser-salvage from D004's Tower Seven brazier-mounts (a small theft Vela has not yet noticed). The pins are slim, un-tarnished, and hold a load that the local iron would deform under.

  The cradle has a padded seat, a harness of tanned leather and hemp, and a double-strap *Held Breath*-style mask-mounting. The mask-mounting is Enna's work. She has sewn the straps three times; the third version holds.

  The cradle hangs a pace above the floor. A man sitting in it can set one foot to the floor and the other in a stirrup; the stirrup is a loop of Soft-Rope.

- **Hazards.** The rig is dangerous to operate without training. A tested load of two men has never been descended. A tested load of one man has been lowered a hundred paces down a mine-shaft and raised again without incident; Enna was the man.
- **Creatures.** None.
- **Items / relics.** The cradle (custom, uncatalogued). A **Bone-Lamp (B-0062)** set in a mount. A **Measured Breath (D-0019)**-shaped copy — a handmade imitation, non-functional but externally convincing, meant as a decoy in case of Guild raid. The imitation is made of wood, painted; at a glance, in lamplight, it passes.
- **Clues / fragments.** A chalked design on the wall: a diagram of the Chasm rim, the five tiers labelled in Crosser shorthand, an arrow drawn from Tier 3 to "east corridor" — and the word *cross* written at its end. The Crossers do not intend to descend; they intend to *traverse* east from Tier 3 toward the far side, under the mist-line. Below the diagram, in a different hand — Kestrel's own — a single line: *we will not tell Sula.*

*Ambient.* The cradle hangs on its pulley with a slow quiet sway — a hand-width of drift at its foot, regular, as the workshop's own air moves. Nobody has tied it off. Parn says a rig must move to be trusted. Enna says a rig that moves frightens a rider. Parn says the rider should not be afraid of a rig that moves because a rig that stops moving has broken. Enna is the rider. She has learned to sit in the cradle and not fight the sway.

*Ambient.* The imitation Measured Breath sits on a shelf above the forge. From a distance, in blue lamp-light, it is indistinguishable from the real relic. Close up, it is wood. Kestrel, on his monthly visit, picks it up and sets it back down with the same respect he would give the real one. Enna has noticed. She does not know whether he is pretending or practising.
- **Exits.** Back.

### Zone ε — The Reading-Nook / *the pale wall*
- **Description.** A small alcove at the back of the workshop. Three paces deep. The back wall here is the gallery's pale-stone face — a single colonial-era face the size of a table. The stone is pale, the colour of a cloud, cool under a hand.

  It bears, cleanly cut, a full four-line inscription. The cuts are deep and even. The letters do not weather. A finger laid in the lowest cut finds the cut-bottom as clean as the upper cut; the weathering that has taken every other stone of the workshop has not touched this face.

  A cushion on the floor — Kestrel sits here when he visits. A lamp-hook at head-height holds a single Slow-Stone-oil lamp. In the lamp's blue light, the letters of the inscription read slightly darker than the stone around them, as though the cutting had gone deeper than a cut.

- **Hazards.** None.
- **Creatures.** None.
- **Items / relics.** The wall. A cushion. A lamp-hook.

*Ambient.* Kestrel's cushion is a patched square of grey wool. He has darned the corner three times. The cushion is flat from much sitting. Beside the cushion, on the floor, a small stone cup holds a finger of cold tea — last visit's. He does not empty the cup. He refills it on each visit and drinks the tea of the previous visit first.

*Ambient.* The inscription's letters, in blue lamp-light, have a faint internal shadow — not in the cut itself, but below it, as if the cut went deeper than the cut. A finger laid in a letter feels the bottom of the cut as stone. The shadow is optical, or it is not. Kestrel has the second theory in a private paper. Parn does not.
- **Clues / fragments.** The inscription, Eilin's gloss: *The road ends. The edge is not a wall. Below and beyond share a floor. Do not dwell here.* This is the single clearest correspondence between Hallen's ravings (*below and beyond are one*) and the colonial record. The Crossers read it as a permission slip. Sula reads it as a final warning. Kestrel has both readings written in a small codex beside the cushion; he reads them alternately, like two prayers.
- **Exits.** Back.

### Zone ζ — The Back Door *(optional, collapsed)*
- **Description.** A collapsed tunnel at the north-east of the workshop. Rubble half-fills it. The rubble is old — fallen before Kestrel's time — but has been worked by Parn: she has removed stones and set them aside in a neat pile, and she has stopped. The stones at the pile's top are small. The stones further in would be large. She has not asked for help to move them.

  Beyond the rubble, reachable only with a day of digging, is a side-corridor that connects — per Kestrel's suspicion, not confirmed — to D002 Zone D's transit shelf. The air coming through the rubble is faintly warm. The warmth is the Jadehollow seal's warmth.

- **Hazards.** Unstable.
- **Creatures.** None.
- **Items / relics.** None surfaced.
- **Clues / fragments.** If dug (a v0.2+ task), the tunnel would give a back approach to the Jadehollow seal — without breaching it. Kestrel keeps the collapse stable for now.
- **Exits.** Would connect to D002 Zone D.

## Storyline links
- **Line E — Depth-Walkers (Crosser faction, central).** This is the Crosser engineering core. The cradle, the reading-nook wall, Parn's notebook, the back-door theory — all Line E critical beats.
- **Line B — World Before the Fog.** The four-line wall is Eilin's great prize. A rubbing smuggled to her is a B-line climax beat.
- **Line A — Guild's Buried Charter.** Guild raid warrant is a plausible hook; Sula can sign against her own cells if pressured.
- **Line C — Four-Crown Intrigue.** The Crown does not know the workshop exists; if discovered, Darrik will respond by order, not by word.
- **Line D — Iron Dragon.** None direct. Weak echoes: the pale-alloy pins from Tower Seven tie D004 to D008.
- **Named NPCs.** Navigator Kestrel (monthly visit), Parn (engineer), Enna (engineer), the Tall Listener (redacted). Absent but linked: Archdepth Sula, Magister Corvin Ashford-Reed, Maester Eilin.
- **Quest hooks.** (1) Sula's warrant: arrest Parn. (2) Kestrel's invitation: witness a descent plan. (3) Eilin's unwritten wish: rubbing of the four-line wall. (4) Corvin's quiet ask: verify the pale-alloy pins' origin.

## Writer notes
<!-- writer-only -->
The reading-nook wall is the canonical clearest colonial-era pre-Fog inscription a PC can read at tier-1 access. It does not state the modern premise; it states the colonial warning in the colonial tongue. The Crossers' plan to traverse east from Tier 3 is the Line E deep reveal that the Chasm's far side may be reachable by transit-shelf path rather than by crossing above. Do not let the party operationalise this in v0.1; let Kestrel describe the plan. The back-door collapse is a v0.2+ hook joining D008 to D002. The stolen Tower Seven brazier-pins are a small cross-dungeon consequence: Vela will eventually notice, and the notice is a Line E beat waiting to fire.
<!-- /writer-only -->

## Map sketch
```
[Slit / hidden] — [Approach shaft + deadfall]
                      |
                [Workshop gallery]
                /      |       \
          [Rig-bay] [Reading nook] [Forge / benches]
                              |
                     [pale-stone four-line inscription]
                              |
                  [collapsed back-door → D002 Zone D?]
```
