# D006 — The Old Exchange Vault

## Snapshot
A Union merchant-guild vault buried in the lower sewer of Stoneford, sealed sixty years ago when the Exchange failed and the vault's last clerk walked out holding the key. Players enter to settle a debt the Exchange's heirs refuse to acknowledge, to retrieve an antiquary's bid-list for Tobiah Caul, or because a rat-catcher says the water beyond the vault is running warmer than the Shale.

## Location
- Nearest town: T001 Stoneford
- Region: The Grey Reach, river port
- Terrain approach: A drain grate in the alley behind the Shale Lantern Inn. Drops to a brick culvert. Quarter of a mile of crouching-walk along the culvert to a rusted iron gate. Past the gate, the Exchange's lower levels.

## Historical layers
- **Pre-collapse.** Not a colonial site. This is a Union-era construction sitting on older backfill. The backfill, when the Exchange's sub-basement was dug, contained a single pale-stone block too heavy to move — the diggers built around it.
- **Guild-era.** The Old Exchange was a Union merchant-bank and antiquary branch, operating from the waves' fourth-generation era until sixty years ago. Its vault held honest-copper, merchant-letters, and a small cabinet of relic-curios purchased as "antiques." The Exchange closed in a scandal; the clerk who closed it, a man named Hobbe Caul, was a distant relation of the present Consul-Merchant. He walked out with the key.
- **Current.** The vault has been locked for sixty years. Tobiah Caul does not admit it exists in his ledgers. Two Guild archivists have quietly noted its existence and have been quietly ignored. The culvert is a known rat-catcher's route.

## Structure — urban underground, functional zones

### Zone 1 — The Culvert / *the bottom drain* / Rat-catcher's route
- **Description.** A brick tunnel, man-height in the middle, knee-deep in Shale water at the edges. The bricks are old, dark with two centuries of damp, and covered in a moss that grows only on wet brick. The moss is green-black. It smells of river.

  The air is sour. The smell is two parts — the Shale's river-smell, which is clean-enough, and a second smell, sweeter, that does not belong to a sewer. A rat-catcher new to the route will notice the second smell. An old rat-catcher has stopped noticing.

  The water is cold. The water's cold is the Shale's cold in summer, but not the Shale's cold in winter — this culvert does not freeze. A hand dipped in the water at the second bend is cold. A hand dipped at the east end, near the gate, is less cold.

- **Hazards.** Footing. A **Drowned One (M002)** occasionally climbs here on fog nights — a figure, knee-deep, walking slow, face turned toward a wall, not speaking. Brick-collapse in two places; the broken brick is darker than the standing brick and has a soft give under a boot.
- **Creatures.** **Brass-beetle** swarms on the moss, their carapaces catching a lantern as a hundred small copper coins. Rats.
- **Items / relics.** *Oilskin Hood & Coat* essential. *Road Lantern*.
- **Clues / fragments.** A chalked sign, recent, at the second bend: *vault-key: third tile left of the gate-lock.* Handwriting is Kestrel's. The chalk is Listener-chalk; the sign was made within the last season.
- **Exits.** East to the iron gate.

*Ambient.* The culvert's second bend has a small recess cut into the brick at waist-height — a rat-catcher's stash. Inside, a bundle of oil-papered bait, a flask, and a note in charcoal: *do not drink the east water. Horn knows why.* The rat-catcher Horn comes here every Mondsday. He has refilled the flask every time for six years, because he does not trust that others will leave it where he left it.

*Pre-encounter traces (Drowned One).* Before a Drowned-One night, the culvert's water rises half a finger. The moss on the bricks, on those nights, glows faintly — not bright enough to read by, just enough to silver a hand passed through it. Horn has learned to come on bright-moss nights only if he is hired and paid in advance.

### Zone 2 — The Iron Gate / *the Exchange door*
- **Description.** A squared iron gate, padlocked, rusted. The gate is three men tall and two men wide. Above the gate, a carved sign: *Honest Weight. Honest Measure. Honest Storage.* Union motto, cut into a lintel of harder stone that has not weathered.

  The lock is a Union-pattern three-bar. The padlock's hasp has been greased in living memory; the grease is dry but not fossil. Somebody opened this gate a generation ago and closed it again.

  The third tile left of the gate, on the wall, is loose; behind it, a brass key wrapped in a scrap of merchant-letter. The tile is mortared on three sides and loose on the fourth. A finger-nail lifts it.

- **Hazards.** Bracing loose bricks. The gate, when swung, drops the top of its arch by a finger's width.
- **Creatures.** None.
- **Items / relics.** The key. **Little Voice (A-0041)**-family palm-stone used as a dead-letter drop by Kestrel — remove it and Kestrel will know. The palm-stone sits in the gate's lowest hinge-gap, wedged, warm.
- **Clues / fragments.** The scrap of merchant-letter reads: *Hobbe's account, closed by his own hand; open not without Consul approval.* The scrap's ink is old enough that a corner crumbles when lifted.
- **Exits.** Through the gate into the vestibule.

### Zone 3 — The Vestibule / *the ledger room*
- **Description.** A small brick room. The ceiling arches low. A clerk's desk, dust thick on it — a thick dust, two fingers deep on the unworked surface, and a clean strip where an arm has rested.

  A ledger open on the desk, last entry in Hobbe Caul's hand, dated sixty years and four months ago: *antiques cabinet to be inventoried by C. when he comes. He has not come.* The ink is brown with age. The page that follows is blank. The ledger is heavy; a Union clerk-ledger, bound in calf, the corners iron-capped.

  A lantern-hook on the wall, empty. A single hook-mark in the brick, where a hook was set and later pulled out. The absence is deliberate; Hobbe took his lantern home.

  The floor is stone, flagged, and one flag — the flag over the old sump — is rotten. The rot is black and soft; a boot on it will go through.

- **Hazards.** The floor over the old sump has rotted; the sump is below.
- **Creatures.** **Silent Mouse** — a nest in the ledger's lower leaves. The mice have eaten the outer edges of three pages. The eaten pages carry no important writing; the mice have been selective, or lucky.
- **Items / relics.** *Honest-Weight Writ* and *Exchange-Paper* stacked in a leather folio. *Merchant-Chain / the weights* set of weighing-chains, complete, on the desk. The chains are brass, polished on the handling-loops and dull on the weights.
- **Clues / fragments.** The ledger's final entries list antiques by cryptic names: *small warm; little voice; husband-smaller; kettle-that-remembers.* These are relic names — the Exchange was trafficking in relics as antiques. A diagonal line has been drawn through the list in a second hand, not Hobbe's. Hobbe did not draw it. Tobiah did not draw it. Someone between them did.
- **Exits.** North into the Vault. East into the antiques cabinet room. Down (rotten floor) into the old sump.

*Ambient.* The clean strip on Hobbe's desk — where an arm has rested — is wider than one arm. Two arms have rested there over the decades: Hobbe's, and a second, smaller arm. Someone has been sitting at the desk since Hobbe left. The sitting has been careful; no chair has been drawn up. Whoever sits has stood at the desk and leant.

*Ambient.* The mice in the ledger's lower leaves have built a nest of shredded paper. The shreds are not from the ledger alone; there are fragments of another document in the nest, paper of a different weight. The fragments carry Union-pattern numbering. The mice have been dragging paper from somewhere else.

### Zone 4 — The Vault Proper / *the honest room*
- **Description.** A vault the size of a parlour. Strong-boxes lining the walls, most empty, two still locked. The boxes are Union-pattern iron, each with a brass plate carrying an account number.

  The door is a Union three-bar; the brass key fits. The key turns stiff for the first quarter and free for the rest; Hobbe oiled the lock on his way out, because a Union clerk does not leave a dry lock.

  The floor is flagged with dressed stone. In the centre of the floor, a single pale-stone block — the backfill stone, the thing the diggers built around. It is a handspan proud of the floor, smooth, cool. The block is rectangular. A hand laid flat on it finds the stone cool even in summer, and faintly — almost not — humming, like a cat that has stopped purring but has not remembered to stop the muscle.

- **Hazards.** One strong-box is mercury-sealed — opening it vents a choking fume (merchant-guild trap). A careful reader, finding the mercury-seal, will find a small brass tag at the box's foot: *Caul private*.
- **Creatures.** None. **Brass-beetle** on the pale-stone. The beetles avoid the rest of the vault. They do not cross onto the flagged floor.
- **Items / relics.** In an unlocked strong-box: *Honest-Copper* coin, *Silver Ticket / guild-rider pass* long-expired, *Union-Pattern Courier Satchel*. In the mercury-sealed box (if opened safely): an antiquary's bid-list naming thirty-one "antiques" and their buyers — a Line C/E crossover document. The pale-stone block, read with **Wet-Eye**, bears faint old-tongue: *thal-reh* — dwelling-at-great-cliff.
- **Clues / fragments.** The bid-list names Tobiah's predecessor as the buyer of six "antiques." Tobiah claims not to know any of this. The Crown's unaging-tea supply passed through this vault once, sixty years ago; the bid-list records the transit in a line that reads, to a Union eye, as a tea shipment, and to a Guild eye as something else.
- **Exits.** Back. Down (the pale-stone block has a seam around it — it can be levered, with effort, to reveal the backfill shaft).

*Ambient.* The pale-stone block's hum is felt in the soles of the feet through leather before the hand finds it. A visitor who stands on the flagstones near the block for a count of twenty begins to feel an ache in the arches — not a pain, a pressure, as from standing too long on a river-rock. The ache passes when the visitor steps off.

*Ambient.* The mercury-seal on the Caul strong-box has corroded around its rim. A small amount of the mercury has wept out and beaded into the floor-cracks beside the box. The beads are silver-bright and have not tarnished in sixty years. A rat has stepped in one and left a print elsewhere in the vault — a single tiny silver track, three feet long, stopping where the rat found a crack to vanish into.

### Zone 5 — The Antiques Cabinet / *the curio room*
- **Description.** A panelled side-room off the vestibule. The panels are oak, painted once with a Union motif (a hexagon of small squares); the paint has peeled in strips, curling outward, as if the panels want to show what they are.

  Shelves of curiosities: a potter's wheel-model, a child's game, a bundle of old glyph-stamped letters. Five shelves, three walls, each shelf neatly catalogued with a brass tag in Hobbe's hand.

  The two shelf-bottoms hold items that ring on the **Measured Breath** if brought here. The ring is soft — not alarm-loud, not marketplace-ringing, but a small insistent note that a trained Guild ear picks up from a pace away.

- **Hazards.** None.
- **Creatures.** None.
- **Items / relics.** **The Thin Mirror (A-0144)** family piece (if catalogue permits — Guild record incomplete), **Kettle-That-Remembers (A-0102)**-family piece, small; **Eight-Grain (A-0133)**-family chip. All Shallow-finds, sold as antiques, unregistered with the Guild. Corvin would confiscate. Tobiah would deny.
- **Clues / fragments.** A purchase-slip, undated, signed *T. Caul* — not Tobiah, but his grandfather. Tobiah Caul would recognise the signature; he keeps a sample of his grandfather's hand in a locked drawer at home.
- **Exits.** Back.

### Zone 6 — The Sump / *the backfill* (sub-level, reachable by levering the pale-stone or falling through the rotten vestibule floor)
- **Description.** A low chamber below the vault. The ceiling is the vault floor; a dropped lantern from above lights the sump in a small yellow circle.

  Standing water ankle-deep. The water is clear. The sump's bottom is pale stone, flagged, clean — the same pale-stone as Zone 4's block, continuous with it. The sump is not a dug pit; it is a pre-existing chamber that the Union built over.

  The pale-stone block's underside is visible from the sump, rimmed in old-tongue *thal-reh-san* — dwelling-cliff-south. A second small pale-stone block sits in the sump, half-submerged, one face above water, one below. The water is slightly warmer than the Shale. The warmth is felt at the calf within a count of twenty.

- **Hazards.** Slip. The water's warmth is Slow-Stone-family; long exposure gives light-headedness and, in a sensitive bearer, a brief taste of iron at the back of the throat.
- **Creatures.** **Cave-Salamander**, pale, finger-long, motionless at the lip of the small block.
- **Items / relics.** The submerged block. A **Slow-Stone** seam along its base — Stoneford's only domestic Slow-Stone source was this sump, unknown to all parties but the Crossers.
- **Clues / fragments.** Kestrel has mined here. Three chalk marks on the wall — Kestrel's. The third mark has a date appended; the date is last month.
- **Exits.** Up.

*Ambient.* Kestrel's chalk-marks in the sump have a fourth, unfinished stroke beside the three dated marks — a single down-line, begun and abandoned. He was here, recently, and was interrupted. He has not returned to complete the fourth mark.

*Ambient.* The sump's submerged small block, viewed from directly above with a Wet-Eye, shows a faint pattern on its underside: a ring of dots around a central point, the colonist crest. The pattern is inverted relative to the block above. The two blocks, if they stood at the same orientation, would both present the crest in the same direction — but the sump block has been flipped, or set that way by whoever set it. The inversion is deliberate. Kestrel has noted it without explanation.

## Storyline links
- **Line A — Guild's Buried Charter.** Unregistered relic trafficking under Union colours is an A-line legal weapon. Corvin's case against Tobiah uses the bid-list.
- **Line C — Four-Crown Intrigue.** Tobiah Caul is "dangerously ignorant; accidental ally to truth-seekers." This vault is the record of his ignorance and his predecessors' quiet trade. The bid-list names names.
- **Line E — Depth-Walkers.** Kestrel's dead-letter drop and Slow-Stone mining cache are here. Line E infrastructure.
- **Line D — Iron Dragon.** None directly. A *Brass-beetle* swarm on the pale-stone pairs weakly with Veyl's matchbox.
- **Named NPCs.** Tobiah Caul (T001/T005 Consul-Merchant, never been here), Hobbe Caul (dead, his ledger speaks), Navigator Kestrel (active here).
- **Quest hooks.** (1) Retrieve the bid-list for Corvin. (2) Remove Kestrel's dead-letter drop for Sula. (3) Mine Slow-Stone for a non-Crosser buyer (provokes Kestrel).

## Writer notes
<!-- writer-only -->
The backfill pale-stone is a colonial-era structural fragment incorporated by accident. The sump's warm water is the same Slow-Stone-residue leakage as D003's drum. Keep modern vocabulary out; the bid-list must read as a merchant ledger. Do not let Tobiah be clever about this vault; he is genuinely unaware. The "hum" of the pale-stone block is a prose-only tell; the block is a partly-active embedded structural unit from the colonial transit shelf, and its hum is a residual low-power state. Never state this in player-facing text.
<!-- /writer-only -->

## Map sketch
```
[Alley grate] → [Culvert] → [Iron gate / key cache]
                                |
                          [Vestibule / ledger]
                           /     |      \
                    [Cabinet] [Vault]  [rotten floor ↓]
                                  |
                         [pale-stone seam ↓]
                                  |
                                [Sump]
```
