# Stoneford-on-the-Shale

> *A river crossing that has outlived three kingdoms.*
> Medieval JRPG · Adventure · d20 dice resolution · Multi-Agent orchestration
> Tone: medieval JRPG adventure — kingdoms, guilds, dungeons, ancient mysteries, and the people caught between them.

## Quick Start

```bash
cd NeonRP/examples/stoneford
neonrp play .
```

## Story Bible

Full worldview, house system, faction politics, quest truths, and endings:
→ `task-storywriting/published/05-stoneford.md`

## Agent Architecture (3 layers)

```
Layer 1: world-agent        — State + routing + final narrative (JRPG adventure voice)
Layer 2: town-agent          — All town interactions (navigation/NPC/shop/guild/inn)
         dungeon-agent       — Mossbarrow exploration
         combat-referee      — d20 combat adjudication
         world-builder       — World map updates
         rules-referee       — Non-combat skill checks + sanity enforcement
Layer 3: (future: dice tool-agent)
```

## Three Houses of Stoneford

| House | Words | Seat | Status |
|-------|-------|------|--------|
| **Blackwater** | *The River Remembers* | The Guild | Active — Heron is head |
| **Ashford** | *From Ash, We Rise* | The Inn | Last heir — Mira |
| **Deepvein** | *What Lies Beneath, We Claim* | Jadehollow mines | Absent from Stoneford |

## Five Factions

Crown's Hand · The Faith · Free North · The Union · The Fog

## Content

- **T001 Stoneford** — Starting town. Guild, Docks, Inn, Shops.
- **D001 The Mossbarrow** — 4-room dungeon. The Ashford cellar.
- **6 quests** including 1 boss (The Drowned Thing)
- **d20 combat + skill checks + dice resolution**
