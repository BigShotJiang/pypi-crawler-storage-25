# Stoneford-on-the-Shale — Claude Code Edition

> 用 Claude Code 直接玩的文件驱动 RPG。低魔政治权谋基调。d20 骰子判定。

## 开始

```bash
# 在 Claude Code 里打开这个目录
cd stoneford-cc
# 直接输入
@world-agent 开始游戏
```

## 架构

```
.claude/agents/
├── orchestrator.md     ← 主控（有 Agent tool，可调其他 agent）
├── town-agent.md       ← 城镇交互
├── dungeon-agent.md    ← 地下城探索
├── combat-referee.md   ← d20 战斗
├── rules-referee.md    ← 骰子判定 + 常识检查
└── world-builder.md    ← 世界地图

game/
├── meta/               ← run_state + game-start
├── player/             ← 7 个玩家文件
├── towns/T001/         ← Stoneford 城镇数据
├── dungeons/D001/      ← The Mossbarrow
├── world/              ← 世界地图
├── lore/               ← 故事 + 传闻
└── rules/              ← 战斗规则
```

## 与 NeonRP 版本的对应

| CC (本目录) | NeonRP (examples/stoneford/) |
|------------|------------------------------|
| `.claude/agents/*.md` | `agents/{id}/agent.json + system.md` |
| `Agent` tool spawn | `task()` tool spawn |
| `Read/Write/Edit` | `read_file/write_file/edit_file` |
| `AskUserQuestion` | `ask_user` |
| `CLAUDE.md` | `.neonrp/config.json` |
| game/ 数据完全相同 | game/ 数据完全相同 |

## 故事设定

→ `task-storywriting/published/05-stoneford.md`
