# Neon City Starter World

A cyberpunk-themed starter world for NeonRP featuring Neon City—a sprawling metropolis of neon lights, corporate intrigue, and technological wonders.

## Contents

### Locations (3)

| ID | Name | Type | Description |
|----|------|------|-------------|
| `neon-city-plaza` | Neon City Plaza | town | Central hub with street vendors |
| `cyber-market` | Cyber Market | shop | Underground tech and weapons market |
| `shadow-alley` | Shadow Alley | location | Dangerous passage for the brave |

### NPCs (2)

| ID | Name | Role |
|----|------|------|
| `info-broker-zara` | Zara the Info Broker | Quest giver, information dealer |
| `merchant-kai` | Kai the Merchant | Shop keeper in Cyber Market |

### Player

- Starts in Neon City Plaza
- 100 HP, 150 gold
- Equipped with worn dagger and 2 health potions

### Items (4)

| ID | Name | Type | Value |
|----|------|------|-------|
| `health-potion` | Health Potion | consumable | 50g |
| `plasma-blade` | Plasma Blade | weapon | 350g |
| `energy-shield` | Personal Energy Shield | defense | 200g |
| `hacking-kit` | Basic Hacking Kit | tool | 150g |

## Setup

To use this starter world:

```bash
# Create a new project
mkdir my-neon-game && cd my-neon-game
neonrp init

# Copy the world and agents
cp -r /path/to/examples/starter-game/world ./
cp -r /path/to/examples/starter-game/agents ./

# Validate and index
neonrp validate
neonrp index build

# Start playing
neonrp tui
```

## World Map

```
                    ┌─────────────────┐
                    │  Shadow Alley   │
                    │   (dangerous)   │
                    └────────┬────────┘
                             │
┌─────────────────┐          │          ┌─────────────────┐
│  Cyber Market   │──────────┼──────────│ Neon City Plaza │
│     (shop)      │          │          │   (start hub)   │
│   [Kai]         │──────────┴──────────│     [Zara]      │
└─────────────────┘                      └─────────────────┘
```

## Suggested First Actions

1. `look around` - Explore Neon City Plaza
2. `talk to Zara` - Get information about the city
3. `go to Cyber Market` - Visit Kai's shop
4. `buy plasma blade` - Upgrade your weapon
5. `go to Shadow Alley` - Seek adventure (dangerous!)

## Customization

Feel free to expand this world by adding:
- More locations (corporate towers, slums, nightclubs)
- Additional NPCs (fixers, hackers, gang members)
- Quests and storylines
- New item types (cyberware, vehicles, data chips)

## License

This example is part of NeonRP and is provided under the same license.
