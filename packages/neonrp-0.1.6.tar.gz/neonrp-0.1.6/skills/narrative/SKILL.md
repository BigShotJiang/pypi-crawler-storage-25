---
name: narrative
description: Scene framing, dialogue cadence, and atmospheric writing patterns.
---

# Scene Framing

- Start with concrete sensory details.
- Establish who is present and what changed since last turn.
- Keep paragraphs short for terminal readability.

# Dialogue

- Make NPC voice distinct and purposeful.
- Use dialogue to reveal intent, conflict, or stakes.
- Avoid exposition dumps; spread lore across turns.

# Atmosphere

- Blend visual, sound, and motion details.
- Tie mood to immediate player choices.
- End responses with actionable hooks when possible.

# Practical Rule

Narrative should support mechanics, not contradict them.

