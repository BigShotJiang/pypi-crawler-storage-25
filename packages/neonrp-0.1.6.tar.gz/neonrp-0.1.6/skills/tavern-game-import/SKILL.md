---
name: tavern-game-import
description: Convert a SillyTavern/酒馆 character card, world card, lorebook-heavy PNG/JSON, or imported raw card payload into a playable NeonRP project slice. Use when the user wants more than a single character import: full setting conversion, starter game scaffolding, entity decomposition, quest/location/NPC extraction, or build-mode transformation of tavern content into `game/` entities.
---

# Tavern Game Import

Convert tavern content into a playable NeonRP slice with the current engine.

# Core Rule

- Treat this as project authoring, not engine work.
- Prefer the nearest layer:
  - Imported raw content / source card
  - Project entities under `game/`
  - Existing agents / startup files
- Do not modify core engine unless the source content proves a cross-project engine defect.

# What "Playable" Means In NeonRP

Create the minimum coherent game state that NeonRP can actually run:

- A valid startup entry at `game/meta/game-start.json`
- A valid routing state at `game/meta/active-agent.json`
- A player entity at `game/player/player.json`
- At least one starting domain entity:
  - usually `town/<id>.json` or `location/<id>.json`
- Supporting content connected to that start:
  - 2-5 NPCs
  - 1-3 locations
  - 1 starter quest or explicit goal
  - optional items / dungeon / faction entities when source material supports them

Do not try to exhaustively convert every lore fragment in one pass unless the user asks for a full conversion.

# Required Workflow

1. Read the project contract first.
2. Read startup and routing files.
3. Read schema/rules before writing entities.
4. Read the imported tavern source.
5. Extract world structure.
6. Ask the user about ambiguous design choices.
7. Write a minimal playable slice first.
8. Ensure the play scaffold exists.
9. Validate the slice for path/id/kind consistency.

# 1) Read Project Contract First

- Read `.neonrp/runtime_contract.json` if present.
- Read `.neonrp/config.json`.
- Respect the active data dir from the runtime contract; default to `game/`.
- Read the current startup file path and routing state path from the contract when present.

# 2) Read Startup And Routing Files

- Read `game/meta/game-start.json` if it exists.
- Read `game/meta/active-agent.json` if it exists.
- Preserve router-owned behavior:
  - `active-agent.json` must remain a valid entity and a valid routing-state file.
- Valid active-agent state uses a top-level `active_agent` field.
- Do not invent a new startup flow if the project already has one; extend the existing flow.

# 3) Read Schema And Rules Before Writing

- Load `entity-authoring` first when available.
- Read `rules/game_entity.schema.json` if present.
- If project rules/config specify a domain rules profile, read that too.
- Keep every entity aligned:
  - folder kind
  - filename id
  - JSON `kind`
  - JSON `id`

# 4) Read The Tavern Source

Read the actual source artifact before planning:

- If the user provides a PNG/JSON card path, read the imported NeonRP entity created from it if available.
- Prefer the imported raw payload under `meta.raw` as the canonical source.
- If there is no imported entity yet, call `import_sillytavern_card(path, entity_id?, target_path?, name?)` first.
- Do not use `read_file` directly on Tavern PNG cards; they are binary files and must go through the import tool.
- After importing, treat the generated `game/character/*.json` entity and its `meta.raw` payload as the canonical source.
- If you already know the desired destination, pass `target_path` so the card lands in the right directory first.
- If you need to preserve or adjust the visible Chinese display name, pass `name`.

Extract these source buckets:

- Premise / genre / setting frame
- Player role
- Main scenario / opening scene
- Important NPCs
- Important locations
- Factions / sects / organizations
- Progression structure
- Explicit mechanics or constraints
- Lorebook / character_book entries

# 5) Classify The Source Before Converting

Decide which of these cases you are handling:

- Single-character card:
  - keep it as `character/` only unless the user asks for world expansion
- Character card with embedded world premise:
  - convert the setting into a starter slice around that character
- Full world card / lorebook-heavy package:
  - build a world-first slice, then place the imported character(s) inside it
- "Complete game" request:
  - create a starter playable loop, not a giant encyclopedia dump

# 6) Map Tavern Content To NeonRP Entities

Use this default mapping:

- Protagonist / player surrogate -> `game/player/player.json`
- Main imported persona(s) -> `game/character/*.json` or `game/npc/*.json`
- Hubs / cities / sect bases -> `game/town/*.json` or `game/location/*.json`
- Dangerous explorable areas -> `game/dungeon/*.json` or `game/location/*.json`
- Lore-only directives / opening instructions / quest briefs -> `game/meta/*.json`
- Gear / pills / artifacts / manuals -> `game/item/*.json`

Prefer existing kinds already used by the project before inventing new kinds.

# 7) Preserve Names, Normalize IDs

- Keep user-facing Chinese in `name`, `summary`, narrative text, and lore fields.
- Do not rely on raw Chinese entity IDs unless the project schema explicitly allows them.
- Use stable ASCII ids for filenames and references.
- If the source title is non-ASCII and no explicit id is provided, derive an ASCII id by one of:
  - established project naming
  - pinyin transliteration if available and reliable
  - short semantic English slug
  - deterministic fallback with a short suffix

Do not change the visible Chinese title just because the file id is ASCII.

# 8) Build A Minimal Playable Slice First

When the user says "import as a full game", do this first-pass target:

- `game/meta/game-start.json`
  - explain how play begins
  - point to required initial reads if the project uses them
- `game/meta/active-agent.json`
  - valid entity shape plus routing state
- `game/player/player.json`
  - define the player role in this setting
- one starting hub
- one adjacent explorable area or pressure source
- 2-5 important NPCs
- one explicit starter objective

Only after this first slice is coherent should you expand with extra factions, regions, or long lore chains.

# 9) Ensure The Play Scaffold Exists

Before claiming the project is playable:

- Call `ensure_playable_scaffold(template_name?, active_agent?, force?)`.
- Let that tool copy the packaged play agents and runtime scaffold when missing.
- Let that tool rewrite `game/meta/active-agent.json` with the canonical state protocol.
- Do not hand-write `agents/narrator/agent.json`, `agents/town-agent/agent.json`, `agents/dungeon-agent/agent.json`, or a custom routing blob unless the user explicitly asks for custom agents.

# 10) Ask User On These Ambiguities

You must ask instead of guessing when the source does not make these clear:

- Is the tavern card meant to become:
  - a single NPC
  - the player role
  - the whole campaign world
- Should the imported persona be:
  - `player`
  - `character`
  - `npc`
- What is the intended starting location?
- Is the tone sandbox / narrative / combat-heavy / social?
- Should the conversion target:
  - minimal playable slice
  - broad first-region scaffold
  - near-complete world codex

# 11) Avoid Common Conversion Mistakes

- Do not dump the entire tavern description into one giant `summary`.
- Do not create dozens of disconnected entities with no startup path.
- Do not leave implicit relationships unresolved.
- Do not store core world facts only inside one character file if they should drive gameplay.
- Do not overwrite valid project bootstrap files blindly; merge or extend them.
- Do not touch core engine files for source-specific lore mapping.
- Do not invent `routing.current_agent` or other ad-hoc state shapes inside `active-agent.json`.

# 12) Quality Bar For Converted Output

Before finishing, ensure:

- Startup path is readable and actionable.
- Player spawn and current situation are explicit.
- At least one meaningful next action exists.
- Referenced IDs actually exist.
- Required play agents and runtime contract exist.
- `active-agent.json` remains schema-valid.
- Names can stay Chinese even if ids are ASCII.
- The imported raw tavern payload remains preserved somewhere authoritative.

# 13) Recommended Build-Mode Execution Pattern

1. Read runtime contract, startup, routing state, schema, and relevant existing entities.
2. Read the imported tavern source entity/raw payload.
3. Write a short conversion plan in plain language for the user when scope is large.
4. Ask the user about unresolved role/start/scope ambiguities.
5. Create or update the minimal playable slice under `game/`.
6. Call `ensure_playable_scaffold(...)`.
7. Re-read touched files if needed and tighten cross-references.
8. End with a concise summary of:
   - what became playable now
   - what remains as optional follow-up expansion

# Suggested Prompt Patterns

These user requests should trigger this skill:

- "把这个酒馆卡直接转成完整游戏"
- "不要只导入角色，帮我转成 NeonRP 可玩的世界"
- "根据这个 tavern PNG 生成开局、地图、NPC 和任务"
- "把 lorebook-heavy 酒馆设定拆成我们系统的实体"
- "在 build 模式下把这张卡转换成 starter game"
