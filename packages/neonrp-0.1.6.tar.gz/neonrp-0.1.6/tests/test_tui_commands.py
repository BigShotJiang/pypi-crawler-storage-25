"""Tests for TUI command parser."""

from neonrp.tui.commands import (
    parse_command,
    validate_command,
    get_command_suggestions,
    get_command_args_hint,
    format_help,
    COMMANDS,
)


class TestParseCommand:
    """Tests for parse_command function."""

    def test_parse_simple_command(self):
        """Parse simple command without args."""
        result = parse_command(":validate")
        assert result.command == "validate"
        assert result.args == []
        assert result.options == {}
        assert result.error is None

    def test_parse_without_colon(self):
        """Parse command without leading colon."""
        result = parse_command("validate")
        assert result.command == "validate"
        assert result.error is None

    def test_parse_with_args(self):
        """Parse command with positional args."""
        result = parse_command(":index build")
        assert result.command == "index"
        assert result.args == ["build"]

    def test_parse_find_with_keyword(self):
        """Parse find command with keyword."""
        result = parse_command(":find tokyo")
        assert result.command == "find"
        assert result.args == ["tokyo"]

    def test_parse_sandbox_new_with_options(self):
        """Parse sandbox new with --from option."""
        result = parse_command(":sandbox new test-1 --from save_001")
        assert result.command == "sandbox"
        assert result.args == ["new", "test-1"]
        assert result.options == {"from": "save_001"}

    def test_parse_context_with_limit(self):
        """Parse context with --limit option."""
        result = parse_command(":context player --limit 5")
        assert result.command == "context"
        assert result.args == ["player"]
        assert result.options == {"limit": "5"}

    def test_parse_empty_command(self):
        """Parse empty command returns error."""
        result = parse_command(":")
        assert result.error == "Empty command"

    def test_parse_quoted_args(self):
        """Parse command with quoted arguments."""
        result = parse_command(':find "multi word query"')
        assert result.command == "find"
        assert result.args == ["multi word query"]

    def test_parse_short_option(self):
        """Parse command with short option."""
        result = parse_command(":context query -n 10")
        assert result.command == "context"
        assert result.args == ["query"]
        assert result.options == {"n": "10"}

    def test_parse_flag_option(self):
        """Parse command with flag (no value) option."""
        result = parse_command(":agent run test --json")
        assert result.command == "agent"
        assert result.args == ["run", "test"]
        assert result.options == {"json": "true"}


class TestValidateCommand:
    """Tests for validate_command function."""

    def test_validate_known_command(self):
        """Known commands should validate."""
        result = parse_command(":validate")
        assert validate_command(result) is None

    def test_validate_apply_command(self):
        """Apply command should be treated as known."""
        result = parse_command("/apply")
        assert validate_command(result) is None

    def test_validate_continue_command(self):
        """Continue command should be treated as known."""
        result = parse_command("/continue")
        assert validate_command(result) is None

    def test_validate_new_command(self):
        """New command should be treated as known."""
        result = parse_command("/new")
        assert validate_command(result) is None

    def test_validate_verbose_command(self):
        """Verbose command should be treated as known."""
        result = parse_command("/verbose")
        assert validate_command(result) is None

    def test_validate_autoapply_command(self):
        """Autoapply command should be treated as known."""
        result = parse_command("/autoapply")
        assert validate_command(result) is None

    def test_validate_models_command(self):
        """Models command should be treated as known."""
        result = parse_command("/models")
        assert validate_command(result) is None

    def test_validate_router_mode_command(self):
        """Router-mode command should be treated as known."""
        result = parse_command("/router-mode orchestrator")
        assert result.command == "router-mode"
        assert result.args == ["orchestrator"]
        assert validate_command(result) is None

    def test_validate_import_command(self):
        """Import command with known subcommand should validate."""
        result = parse_command('/import sillytavern-card "card.png" --id hero')
        assert validate_command(result) is None

    def test_validate_unknown_command(self):
        """Unknown commands should return error."""
        result = parse_command(":foobar")
        error = validate_command(result)
        assert "Unknown command" in error

    def test_validate_unknown_with_suggestion(self):
        """Unknown command similar to known should suggest."""
        result = parse_command(":val")
        error = validate_command(result)
        assert "validate" in error.lower()

    def test_validate_subcommand_required(self):
        """Commands requiring subcommand should validate."""
        result = parse_command(":sandbox")
        error = validate_command(result)
        assert "requires a subcommand" in error

    def test_validate_invalid_subcommand(self):
        """Invalid subcommand should return error."""
        result = parse_command(":sandbox foobar")
        error = validate_command(result)
        assert "Unknown subcommand" in error

    def test_validate_valid_subcommand(self):
        """Valid subcommand should pass."""
        result = parse_command(":sandbox new")
        assert validate_command(result) is None


class TestGetCommandSuggestions:
    """Tests for get_command_suggestions function."""

    def test_empty_prefix_returns_all(self):
        """Empty prefix returns all commands."""
        suggestions = get_command_suggestions("")
        assert len(suggestions) == len(COMMANDS)

    def test_prefix_filters_commands(self):
        """Prefix filters to matching commands."""
        suggestions = get_command_suggestions("val")
        assert "validate" in suggestions

    def test_no_match_returns_empty(self):
        """Non-matching prefix returns empty list."""
        suggestions = get_command_suggestions("xyz")
        assert suggestions == []


class TestFormatHelp:
    """Tests for format_help function."""

    def test_format_help_includes_commands(self):
        """Help text includes all commands."""
        help_text = format_help()
        assert "validate" in help_text
        assert "index" in help_text
        assert "find" in help_text
        assert "sandbox" in help_text


class TestCommandPlaceholders:
    """Tests for command argument placeholder hints."""

    def test_mode_placeholder_is_explicit_choices(self):
        """Mode should show concrete choices instead of generic [name]."""
        assert get_command_args_hint("mode", COMMANDS["mode"]) == "[build|sandbox|play]"

    def test_index_placeholder_keeps_subcommand_choices(self):
        """Index should show available subcommands."""
        assert get_command_args_hint("index", COMMANDS["index"]) == "[build|update]"

    def test_import_placeholder_keeps_subcommand_choices(self):
        """Import should show supported import subcommands."""
        assert get_command_args_hint("import", COMMANDS["import"]) == "[sillytavern-card]"

    def test_all_argument_commands_have_non_empty_placeholder(self):
        """Every command that accepts arguments should provide a placeholder."""
        for cmd, spec in COMMANDS.items():
            needs_hint = ("subcommands" in spec) or spec.get("args") in {1, "?"}
            if not needs_hint:
                continue
            hint = get_command_args_hint(cmd, spec)
            assert isinstance(hint, str)
            assert hint.strip() != ""
