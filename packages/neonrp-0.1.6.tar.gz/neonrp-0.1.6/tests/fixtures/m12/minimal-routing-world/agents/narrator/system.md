ROLE:narrator

Router-only narrator for M12 routing tests.
