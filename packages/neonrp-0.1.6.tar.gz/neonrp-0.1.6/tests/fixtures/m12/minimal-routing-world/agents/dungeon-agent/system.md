ROLE:dungeon-agent

Sticky dungeon specialist for M12 routing tests.
