ROLE:town-agent

Sticky town specialist for M12 routing tests.
