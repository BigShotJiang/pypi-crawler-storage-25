"""Tests for the public `worldlines` launcher entry."""

from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

from neonrp.cli import worldlines_cli
from neonrp.tui.app import WorldLinesLaunchSelection


def test_worldlines_cli_new_game_uses_launcher_selection(tmp_path: Path):
    selection = WorldLinesLaunchSelection(
        mode="new",
        world_id="stone-ford",
        preset_id="stub-test",
        runtime_mode="play",
        player_profile={"name": "Ari"},
    )

    runner = CliRunner()
    with patch("neonrp.tui.app.run_worldlines_launcher", return_value=selection), patch(
        "neonrp.presets.is_claude_code_preset", return_value=False
    ), patch("neonrp.presets.ensure_preset_key", return_value=True), patch(
        "neonrp.cli._worldlines_init_and_launch"
    ) as init_and_launch:
        result = runner.invoke(worldlines_cli, [])

    assert result.exit_code == 0, result.output
    init_and_launch.assert_called_once_with(
        "stone-ford",
        "stub-test",
        mode="play",
        player_profile={"name": "Ari"},
    )


def test_worldlines_cli_continue_game_uses_launcher_selection(tmp_path: Path):
    game_path = tmp_path / "save-1"
    selection = WorldLinesLaunchSelection(
        mode="continue",
        preset_id="stub-test",
        runtime_mode="play",
        game_path=game_path,
    )

    runner = CliRunner()
    with patch("neonrp.tui.app.run_worldlines_launcher", return_value=selection), patch(
        "neonrp.presets.is_claude_code_preset", return_value=False
    ), patch("neonrp.presets.ensure_preset_key", return_value=True), patch(
        "neonrp.cli._worldlines_continue_game_with_preset"
    ) as continue_game:
        result = runner.invoke(worldlines_cli, [])

    assert result.exit_code == 0, result.output
    continue_game.assert_called_once_with(game_path, "stub-test")


def test_worldlines_cli_cancelled_launcher_exits_cleanly():
    runner = CliRunner()
    with patch("neonrp.tui.app.run_worldlines_launcher", return_value=None), patch(
        "neonrp.cli._worldlines_init_and_launch"
    ) as init_and_launch:
        result = runner.invoke(worldlines_cli, [])

    assert result.exit_code == 0, result.output
    init_and_launch.assert_not_called()


def test_worldlines_cli_aborts_when_preset_key_setup_fails(tmp_path: Path):
    selection = WorldLinesLaunchSelection(
        mode="new",
        world_id="stone-ford",
        preset_id="stub-test",
        runtime_mode="play",
    )

    runner = CliRunner()
    with patch("neonrp.tui.app.run_worldlines_launcher", return_value=selection), patch(
        "neonrp.presets.is_claude_code_preset", return_value=False
    ), patch("neonrp.presets.ensure_preset_key", return_value=False), patch(
        "neonrp.cli._worldlines_init_and_launch"
    ) as init_and_launch:
        result = runner.invoke(worldlines_cli, [])

    assert result.exit_code == 0, result.output
    init_and_launch.assert_not_called()
