"""Tests for tui/suggestions.py."""

from __future__ import annotations

import asyncio

from textual.app import App, ComposeResult

from neonrp.tui.suggestions import SlashSuggestions


class _SuggestionsApp(App):
    def __init__(self) -> None:
        super().__init__()
        self.selected: tuple[str, str] | None = None
        self.completed: tuple[str, str] | None = None

    def compose(self) -> ComposeResult:
        yield SlashSuggestions()

    def on_slash_suggestions_command_selected(self, message: SlashSuggestions.CommandSelected) -> None:
        self.selected = (message.command, message.args_hint)

    def on_slash_suggestions_command_completed(self, message: SlashSuggestions.CommandCompleted) -> None:
        self.completed = (message.command, message.args_hint)


class TestSlashSuggestions:
    def test_show_and_hide_toggles_visibility_class(self):
        app = _SuggestionsApp()

        async def scenario() -> None:
            async with app.run_test() as pilot:
                widget = app.query_one(SlashSuggestions)
                widget.show_suggestions("au")
                await pilot.pause(0.05)
                assert widget.has_class("visible")

                widget.hide()
                await pilot.pause(0.05)
                assert not widget.has_class("visible")

        asyncio.run(scenario())

    def test_move_selection_wraps_and_get_selected(self):
        app = _SuggestionsApp()

        async def scenario() -> None:
            async with app.run_test() as pilot:
                widget = app.query_one(SlashSuggestions)
                widget.show_suggestions("a")
                await pilot.pause(0.05)
                assert widget.suggestions

                widget.selected_index = len(widget.suggestions) - 1
                widget.move_selection(1)
                assert widget.selected_index == 0

                selected = widget.get_selected()
                assert selected is not None
                assert selected[0]

        asyncio.run(scenario())

    def test_select_current_posts_selected_message_and_hides(self):
        app = _SuggestionsApp()

        async def scenario() -> None:
            async with app.run_test() as pilot:
                widget = app.query_one(SlashSuggestions)
                widget.show_suggestions("val")
                await pilot.pause(0.05)
                widget.select_current()
                await pilot.pause(0.05)
                assert app.selected is not None
                assert app.selected[0] == "validate"
                assert not widget.has_class("visible")

        asyncio.run(scenario())

    def test_complete_current_posts_completed_message(self):
        app = _SuggestionsApp()

        async def scenario() -> None:
            async with app.run_test() as pilot:
                widget = app.query_one(SlashSuggestions)
                widget.show_suggestions("mo")
                await pilot.pause(0.05)
                widget.complete_current()
                await pilot.pause(0.05)
                assert app.completed is not None
                assert app.completed[0] in {"mode", "models"}

        asyncio.run(scenario())

    def test_update_filter_extracts_command_and_keeps_index_in_bounds(self):
        app = _SuggestionsApp()

        async def scenario() -> None:
            async with app.run_test() as pilot:
                widget = app.query_one(SlashSuggestions)
                widget.show_suggestions("")
                await pilot.pause(0.05)
                widget.selected_index = 100
                widget.update_filter("/auth set provider")
                await pilot.pause(0.05)
                assert widget.filter_text == "auth"
                assert widget.selected_index == 0

        asyncio.run(scenario())

    def test_get_selected_returns_none_when_empty(self):
        app = _SuggestionsApp()

        async def scenario() -> None:
            async with app.run_test() as pilot:
                widget = app.query_one(SlashSuggestions)
                widget.show_suggestions("zzzz-no-match")
                await pilot.pause(0.05)
                assert widget.suggestions == []
                assert widget.get_selected() is None
                widget.move_selection(1)  # no-op for empty list
                assert widget.selected_index == 0

        asyncio.run(scenario())
