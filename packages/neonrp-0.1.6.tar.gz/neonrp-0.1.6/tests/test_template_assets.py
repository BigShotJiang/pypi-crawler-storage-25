"""Tests for packaged template assets and Claude workspace bootstrap."""

from __future__ import annotations

import json
from pathlib import Path

from neonrp.core.template_assets import (
    bootstrap_claude_workspace,
    copy_game_support_files_from_template,
    list_available_templates,
    write_claude_workspace_mcp_config,
)
from neonrp.worlds import get_world


def test_stone_ford_world_uses_stoneford_orch_template() -> None:
    world = get_world("stone-ford")

    assert world["template"] == "stoneford-orch"


def test_stoneford_orch_template_is_packaged() -> None:
    templates = list_available_templates()

    assert "stoneford-orch" in templates


def test_copy_game_support_files_from_stoneford_orch(tmp_path: Path) -> None:
    copied = copy_game_support_files_from_template(
        tmp_path,
        template_name="stoneford-orch",
        data_dir_name="game",
        force=True,
    )

    assert "game/lore/story.md" in copied
    assert "game/rules/combat_rules.md" in copied
    assert (tmp_path / "game" / "lore" / "story.md").exists()
    assert (tmp_path / "game" / "rules" / "combat_rules.md").exists()


def test_bootstrap_claude_workspace_creates_sibling_workspace(tmp_path: Path) -> None:
    (tmp_path / "game").mkdir(parents=True)
    (tmp_path / "game" / "meta").mkdir(parents=True)
    (tmp_path / ".neonrp").mkdir(parents=True)
    (tmp_path / "game" / "meta" / "game-start.json").write_text("{}", encoding="utf-8")
    (tmp_path / ".neonrp" / "runtime_contract.json").write_text("{}", encoding="utf-8")

    workspace_root, created = bootstrap_claude_workspace(
        tmp_path,
        template_name="stoneford-orch",
        server_url="http://127.0.0.1:7842/sse",
        force=True,
    )

    assert workspace_root == tmp_path.parent / f"{tmp_path.name}-cc"
    assert "CLAUDE.md" in created
    assert ".mcp.json" in created
    assert (workspace_root / "CLAUDE.md").exists()
    # L14 rename: agents/orchestrator/ → agents/world-agent/ in stoneford-orch.
    assert (workspace_root / ".claude" / "agents" / "world-agent.md").exists()
    assert (workspace_root / "game").exists()
    assert (workspace_root / ".neonrp").exists()


def test_write_claude_workspace_mcp_config_uses_sse(tmp_path: Path) -> None:
    config_path = write_claude_workspace_mcp_config(tmp_path, server_url="http://127.0.0.1:9999/sse")

    payload = json.loads(config_path.read_text(encoding="utf-8"))
    assert payload["mcpServers"]["worldlines"]["type"] == "sse"
    assert payload["mcpServers"]["worldlines"]["url"] == "http://127.0.0.1:9999/sse"
