# Developer Guide

Welcome to the NeonRP development documentation.

## Documentation Structure

Detailed documentation is located in the `docs/` directory:

- **[REQUIREMENTS.md](docs/REQUIREMENTS.md)**: Product requirements (Source of Truth).
- **[ROADMAP.md](docs/ROADMAP.md)**: Milestones, task lists, and acceptance criteria. **Check this first to see what to build.**
- **[ARCHITECTURE.md](docs/ARCHITECTURE.md)**: System design, layers, invariants, event model, and on-disk layout.
- **[QUALITY_GATES.md](docs/QUALITY_GATES.md)**: Definition of Done, testing strategy, and code review process.
- **[PROGRESS.md](docs/PROGRESS.md)**: Execution log. Update this after every completed task.
- **[ADRs/](docs/ADRs/)**: Architecture Decision Records (0001–0023).
- **Per-milestone design docs**: `M1_*` through `M10_*` design specs and task cards.

## Quick Start (Development)

1. **Setup Environment**:
   ```pwsh
   # using uv (recommended)
   uv sync
   # or using pip
   pip install -e ".[dev]"
   ```

2. **Run Tests**:
   ```pwsh
   uv run pytest
   ```

3. **Run Coverage (required for coverage-related work)**:
   ```pwsh
   uv run pytest --cov=neonrp --cov-report=term-missing -q
   ```

4. **Lint & Format**:
   ```pwsh
   uv run ruff format .
   uv run ruff check .
   ```

5. **Verify Process**:
   Use the QA script to run gates and get next steps:
   ```pwsh
   python scripts/qa.py
   ```

## Workflow

1. Pick a task from `docs/ROADMAP.md`.
2. Implement and test.
3. Run `python scripts/qa.py`.
4. Perform code review via `opencode`.
5. Update `docs/PROGRESS.md` and checklists.

## Task Plan Writing Guide

Use this as a lightweight guide when writing a task plan. Keep it practical; don't over-specify.

1. Define outcome first:
   - One clear goal sentence (what changes for users or developers).
   - In/out of scope boundaries.
2. List deliverables:
   - Files/modules expected to change.
   - Observable outputs (CLI behavior, UI behavior, docs, tests).
3. Add acceptance criteria:
   - Use behavior-level checks ("when X, then Y"), not only internal implementation details.
   - Include at least one end-to-end path for user-critical flows.
4. Add test strategy in the plan:
   - Unit tests for core logic and edge cases.
   - Integration tests for framework boundaries (e.g., TUI input -> worker -> session send).
   - For bug fixes, add a regression test that fails before the fix.
5. Coverage requirement (recommended baseline):
   - `src/` overall coverage >= 80%.
   - Changed files coverage >= 85%.
   - Critical modules (state, storage, conversation, dispatch, TUI event paths) should target >= 90%.
   - Command example:
     ```pwsh
     uv run pytest --cov=neonrp --cov-report=term-missing -q
     ```
6. Real-endpoint E2E requirement (for LLM integration changes):
   - Use user config endpoint in `~/.neonrp/config.json` when available.
   - Gate with env var to avoid CI cost:
     ```pwsh
     $env:NEONRP_E2E_LLM='1'
     uv run pytest tests/test_llm_real_endpoint.py -q
     ```
7. Code review requirement:
   - Run an `opencode` review before merge.
   - Save report under `reviews/` with date/task context.
   - Fix must-fix findings, then rerun tests.
   - Example:
     ```pwsh
     opencode run "Using prompts/code_review.md, review src/ changes against docs/REQUIREMENTS.md. Save report to reviews/REVIEW_YYYYMMDD.md"
     ```
8. Update records:
   - Check off task items in `docs/ROADMAP.md`.
   - Add a concise entry in `docs/PROGRESS.md` (what changed, tests, review result).
   - If user-facing behavior changed (especially TUI), update `README.md`, `docs/TUTORIAL.md`, and `CHANGELOG.md` in the same PR.
   - If coverage work was done, update `reviews/coverage_report_YYYYMMDD.md` with latest numbers and remaining gaps.
