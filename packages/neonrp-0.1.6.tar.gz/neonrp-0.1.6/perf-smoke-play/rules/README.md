# Rules Folder

This folder stores project rule files.

- `game_entity.schema.json`: active JSON Schema override for game entity validation.
- `domain_rules.sample.json`: example profile for the optional data-driven domain validation and `resolve_action` layer.

To activate a custom domain profile, set `.neonrp/config.json`:

```json
{
  "rules": {
    "profile_path": "rules/domain_rules.sample.json"
  }
}
```
