"""Tests for the update_task MCP tool."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock

import httpx
import pytest
import respx

from kanbantool_mcp.client import KanbanToolClient
from kanbantool_mcp.exceptions import (
    KanbanToolHTTPError,
    KanbanToolPermissionError,
    KanbanToolValidationError,
)
from kanbantool_mcp.server import update_task

from .conftest import BASE_URL

TASK_ID = 4242
TASK_URL = f"{BASE_URL}tasks/{TASK_ID}.json"


def _request_body(route: respx.Route) -> dict[str, object]:
    return json.loads(route.calls.last.request.content)


async def test_update_task_happy_path_single_field(_inject_client: KanbanToolClient) -> None:
    """A single-field update should produce a ``{"task": {...}}`` envelope
    containing only that field, hit PUT ``/tasks/{id}.json``, and round-trip
    the response into a ``Task``."""
    response_payload = {"id": TASK_ID, "name": "Renamed", "board_id": 7}
    with respx.mock(assert_all_called=True) as router:
        route = router.put(TASK_URL).mock(return_value=httpx.Response(200, json=response_payload))
        task = await update_task(task_id=TASK_ID, name="Renamed")

    assert task.id == TASK_ID
    assert task.name == "Renamed"

    request = route.calls.last.request
    assert request.method == "PUT"
    body = _request_body(route)
    assert body == {"task": {"name": "Renamed"}}


async def test_update_task_multi_field_renames_lane_id(_inject_client: KanbanToolClient) -> None:
    """Multi-field update: ``lane_id`` must serialize as ``workflow_stage_id``
    on the wire, matching the inbound alias and ``create_task``'s outbound
    rename."""
    response_payload = {
        "id": TASK_ID,
        "name": "Reshuffled",
        "board_id": 7,
        "workflow_stage_id": 200,
        "position": 5,
    }
    with respx.mock(assert_all_called=True) as router:
        route = router.put(TASK_URL).mock(return_value=httpx.Response(200, json=response_payload))
        task = await update_task(
            task_id=TASK_ID,
            name="Reshuffled",
            lane_id=200,
            position=5,
            priority="high",
            tags="release,urgent",
        )

    inner = _request_body(route)["task"]
    assert isinstance(inner, dict)
    assert inner == {
        "name": "Reshuffled",
        "workflow_stage_id": 200,
        "position": 5,
        "priority": "high",
        "tags": "release,urgent",
    }
    # The caller-facing key must not leak onto the wire.
    assert "lane_id" not in inner

    # Round-trip: the response is parsed back via the same alias.
    assert task.lane_id == 200
    assert task.position == 5


async def test_update_task_unset_optionals_omitted_not_nulled(
    _inject_client: KanbanToolClient,
) -> None:
    """Fields the caller didn't pass must be absent from the body, not sent
    as ``null``. ``None`` means *omit*, not *clear* — see docstring."""
    with respx.mock(assert_all_called=True) as router:
        route = router.put(TASK_URL).mock(
            return_value=httpx.Response(200, json={"id": TASK_ID, "name": "x", "board_id": 2})
        )
        await update_task(task_id=TASK_ID, name="x")

    inner = _request_body(route)["task"]
    assert isinstance(inner, dict)
    assert inner == {"name": "x"}
    for absent_key in (
        "description",
        "board_id",
        "lane_id",
        "workflow_stage_id",
        "swimlane_id",
        "position",
        "priority",
        "color",
        "due_date",
        "start_date",
        "tags",
        "assigned_user_id",
        "assignees",
    ):
        assert absent_key not in inner


async def test_update_task_assigned_user_id_serializes_directly(
    _inject_client: KanbanToolClient,
) -> None:
    """``assigned_user_id`` is the wire field name (not an alias) — a
    single-field update must land as ``{"task": {"assigned_user_id": <int>}}``."""
    response_payload = {
        "id": TASK_ID,
        "name": "x",
        "board_id": 2,
        "assigned_user_id": 11,
    }
    with respx.mock(assert_all_called=True) as router:
        route = router.put(TASK_URL).mock(return_value=httpx.Response(200, json=response_payload))
        task = await update_task(task_id=TASK_ID, assigned_user_id=11)

    assert task.assigned_user_id == 11
    inner = _request_body(route)["task"]
    assert isinstance(inner, dict)
    assert inner == {"assigned_user_id": 11}


async def test_update_task_legacy_assignees_kwarg_rejected(
    _inject_client: KanbanToolClient,
) -> None:
    """The legacy ``assignees=[int]`` kwarg has been removed (the API silently
    ignored it — see #62). Calling with it must reject before any HTTP traffic.
    With ``@validate_call`` enabled (M7-B), pydantic raises ``ValidationError``
    (a ``ValueError`` subclass) for unexpected kwargs."""
    # Route through a kwargs dict typed as ``dict[str, Any]`` so the static
    # type-checker doesn't flag the removed kwarg — we're deliberately
    # exercising runtime rejection.
    legacy_kwargs: dict[str, Any] = {"task_id": TASK_ID, "assignees": [11]}
    with pytest.raises(ValueError):
        await update_task(**legacy_kwargs)


async def test_update_task_no_args_raises_value_error_without_http(
    monkeypatch: pytest.MonkeyPatch,
    _inject_client: KanbanToolClient,
) -> None:
    """A call with no updatable kwargs is a client-side error — the LLM gets
    a ``ValueError`` naming the available fields, and no HTTP request is
    issued."""
    # Patch the underlying client.request to make sure it's never called.
    sentinel = AsyncMock(side_effect=AssertionError("update_task issued an HTTP call for a no-op"))
    monkeypatch.setattr(_inject_client, "request", sentinel)

    with pytest.raises(ValueError) as exc_info:
        await update_task(task_id=TASK_ID)

    # Message should name *every* available field so the LLM can self-correct.
    # The list is built dynamically from the helper's ``fields`` dict; pinning
    # all 12 names here catches a regression where a future caller (e.g.
    # ``move_task``) accidentally widens this message back to a hardcoded
    # superset of its own surface.
    msg = str(exc_info.value)
    for expected in (
        "name",
        "description",
        "board_id",
        "lane_id",
        "swimlane_id",
        "position",
        "priority",
        "color",
        "due_date",
        "start_date",
        "tags",
        "assigned_user_id",
    ):
        assert expected in msg, f"update_task ValueError message missing '{expected}': {msg!r}"
    # The legacy list-shaped key has been removed from this surface (#62).
    assert "assignees" not in msg.replace("assigned_user_id", "")
    # The wire-only name must not surface to the LLM — they call ``lane_id``.
    assert "workflow_stage_id" not in msg
    # ``column_id`` belongs to ``move_task``'s surface only; it must not bleed
    # into this message.
    assert "column_id" not in msg
    sentinel.assert_not_awaited()


async def test_update_task_401_raises_permission_error(
    _inject_client: KanbanToolClient,
) -> None:
    with respx.mock() as router:
        router.put(TASK_URL).mock(return_value=httpx.Response(401, text="unauthorized"))
        with pytest.raises(KanbanToolPermissionError):
            await update_task(task_id=TASK_ID, name="x")


async def test_update_task_422_raises_validation_error_with_field_errors(
    _inject_client: KanbanToolClient,
) -> None:
    """422 must surface as the typed ``KanbanToolValidationError`` subclass
    (not the bare base) with parsed ``field_errors`` populated."""
    error_body = {"errors": {"name": ["can't be blank"], "due_date": ["is invalid"]}}
    with respx.mock() as router:
        router.put(TASK_URL).mock(return_value=httpx.Response(422, json=error_body))
        with pytest.raises(KanbanToolValidationError) as exc_info:
            await update_task(task_id=TASK_ID, name="", due_date="not-a-date")

    err = exc_info.value
    # Specifically the typed subclass, not the bare KanbanToolHTTPError.
    assert isinstance(err, KanbanToolValidationError)
    assert err.status_code == 422
    assert err.field_errors == {
        "name": ["can't be blank"],
        "due_date": ["is invalid"],
    }
    assert err.body_excerpt


async def test_update_task_500_raises_http_error(_inject_client: KanbanToolClient) -> None:
    """Generic 5xx surfaces as the base ``KanbanToolHTTPError`` — not promoted
    to the validation subclass."""
    with respx.mock() as router:
        router.put(TASK_URL).mock(return_value=httpx.Response(500, text="server exploded"))
        with pytest.raises(KanbanToolHTTPError) as exc_info:
            await update_task(task_id=TASK_ID, name="x")

    err = exc_info.value
    assert err.status_code == 500
    assert "server exploded" in err.body_excerpt
    assert not isinstance(err, KanbanToolValidationError)


async def test_update_task_404_raises_http_error(_inject_client: KanbanToolClient) -> None:
    """404 (unknown task id) surfaces as the base ``KanbanToolHTTPError`` —
    not promoted to the validation subclass."""
    with respx.mock() as router:
        router.put(TASK_URL).mock(return_value=httpx.Response(404, text="task not found"))
        with pytest.raises(KanbanToolHTTPError) as exc_info:
            await update_task(task_id=TASK_ID, name="x")

    err = exc_info.value
    assert err.status_code == 404
    assert not isinstance(err, KanbanToolValidationError)


async def test_update_task_malformed_response_raises_http_error(
    _inject_client: KanbanToolClient,
) -> None:
    """A 200 with a response body missing the required ``id`` field surfaces
    as ``KanbanToolHTTPError(status_code=200)`` with a ``malformed``-tagged
    excerpt — never a raw ``pydantic.ValidationError``. Covers the shared
    ``_patch_task`` helper that also backs ``move_task``."""
    with respx.mock() as router:
        router.put(TASK_URL).mock(
            return_value=httpx.Response(200, json={"name": "no-id"}),
        )
        with pytest.raises(KanbanToolHTTPError) as exc_info:
            await update_task(task_id=TASK_ID, name="x")

    assert exc_info.value.status_code == 200
    assert "malformed" in exc_info.value.body_excerpt


async def test_update_task_url_shape(_inject_client: KanbanToolClient) -> None:
    """PUT hits ``tasks/{id}.json`` exactly — no double ``.json`` suffix, no
    query string, no trailing slash artifact."""
    with respx.mock(assert_all_called=True) as router:
        route = router.put(TASK_URL).mock(
            return_value=httpx.Response(200, json={"id": TASK_ID, "name": "x", "board_id": 2})
        )
        await update_task(task_id=TASK_ID, name="x")

    request = route.calls.last.request
    assert request.method == "PUT"
    assert str(request.url) == TASK_URL
