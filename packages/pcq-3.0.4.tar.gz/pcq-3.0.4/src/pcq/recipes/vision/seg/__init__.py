"""Segmentation recipes."""
