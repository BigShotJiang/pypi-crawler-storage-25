"""NLP recipes."""
