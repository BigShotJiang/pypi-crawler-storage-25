from setuptools import setup

setup(
    name='asr_consilium',
    version='1.0.0',
    author='Roman Sol (ZFTurbo)',
    packages=['asr_consilium', 'asr_consilium/normalizer'],
    url='https://github.com/ZFTurbo/asr_consilium',
    description='Ensemble of open-source ASR models',
    long_description='A repository for Automatic Speech Recognition (ASR) that ensembles multiple open-source models to achieve SOTA quality of recognition. Useful if you need to get the maximum quality of recognition despite the computational time.',
    install_requires=[
        'transformers==4.57.6',
        'huggingface_hub==0.36.2',
        'qwen_asr==0.0.6',
        'nemo_toolkit[asr,tts]',
        'jiwer',
        'evaluate',
        'Levenshtein',
        'tqdm',
        'editdistance',
        'numpy',
        'librosa',
        'soundfile',
    ],
)
