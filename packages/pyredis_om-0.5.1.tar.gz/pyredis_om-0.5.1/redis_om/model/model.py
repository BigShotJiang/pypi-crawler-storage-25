# mypy: disable-error-code="assignment,arg-type,union-attr,no-redef"

import abc
import dataclasses
import datetime
import decimal
import json
import logging
import operator
from copy import copy
from enum import Enum
from functools import reduce
from typing import (
    AbstractSet,
    Any,
    Callable,
    ClassVar,
    Dict,
    List,
    Literal,
    Mapping,
    Optional,
    Sequence,
    Set,
    Tuple,
    Type,
    TypeVar,
    Union,
)
from typing import get_args as typing_get_args
from typing import no_type_check

from more_itertools import ichunked
from redis.commands.json.path import Path
from redis.exceptions import ResponseError
from typing_extensions import Annotated, Protocol, get_args, get_origin
from ulid import ULID

from .. import redis
from .._compat import PYDANTIC_V2, BaseModel
from .._compat import FieldInfo as PydanticFieldInfo
from .._compat import ModelField, ModelMetaclass, NoArgAnyCallable
from .._compat import PydanticUndefined as Undefined
from .._compat import Representation, UndefinedType, validate_model, validator
from ..checks import has_redis_json, has_redisearch
from ..connections import get_redis_connection
from ..util import ASYNC_MODE, has_numeric_inner_type, is_numeric_type
from .encoders import jsonable_encoder
from .render_tree import render_tree
from .token_escaper import TokenEscaper
from .types import Coordinates, GeoFilter

model_registry = {}
_T = TypeVar("_T")
Model = TypeVar("Model", bound="RedisModel")
log = logging.getLogger(__name__)
escaper = TokenEscaper()
DatabaseConnection = Union[redis.Redis, redis.RedisCluster]
DatabaseProvider = Callable[[], DatabaseConnection]


def _is_cluster_pipeline(db) -> bool:
    """Check if a database object is an async RedisCluster pipeline.

    ClusterPipeline commands must NOT be awaited—doing so consumes the
    response immediately instead of queuing the command for batch execution.
    Regular async Pipeline commands may be safely awaited (they return the
    pipeline instance for chaining while still queueing the command).
    """
    try:
        from redis.asyncio.cluster import ClusterPipeline

        if isinstance(db, ClusterPipeline):
            return True
    except ImportError:
        pass
    # Fallback: check class name in case the import path changes.
    return type(db).__name__ == "ClusterPipeline"


# For basic exact-match field types like an indexed string, we create a TAG
# field in the RediSearch index. TAG is designed for multi-value fields
# separated by a "separator" character. We're using the field for single values
# (multi-value TAGs will be exposed as a separate field type), and we use the
# pipe character (|) as the separator. There is no way to escape this character
# in hash fields or JSON objects, so if someone indexes a value that includes
# the pipe, we'll warn but allow, and then warn again if they try to query for
# values that contain this separator.
SINGLE_VALUE_TAG_FIELD_SEPARATOR = "|"


# This is the default field separator in RediSearch. We need it to determine if
# someone has accidentally passed in the field separator with string value of a
# multi-value field lookup, like a IN or NOT_IN.
DEFAULT_REDISEARCH_FIELD_SEPARATOR = ","

ERRORS_URL = "https://github.com/XChikuX/redis-om-python/blob/main/docs/errors.md"


def get_outer_type(field):
    if hasattr(field, "outer_type_"):
        return field.outer_type_
    elif isinstance(field.annotation, type) or is_supported_container_type(
        field.annotation
    ):
        return field.annotation
    elif not hasattr(field.annotation, "__args__"):
        return None
    else:
        return field.annotation.__args__[0]


class RedisModelError(Exception):
    """Raised when a problem exists in the definition of a RedisModel."""


class QuerySyntaxError(Exception):
    """Raised when a query is constructed improperly."""


class NotFoundError(Exception):
    """Raised when a query found no results."""


class Operators(Enum):
    EQ = 1
    NE = 2
    LT = 3
    LE = 4
    GT = 5
    GE = 6
    OR = 7
    AND = 8
    NOT = 9
    IN = 10
    NOT_IN = 11
    LIKE = 12
    ALL = 13
    STARTSWITH = 14
    ENDSWITH = 15
    CONTAINS = 16
    TRUE = 17
    FALSE = 18

    def __str__(self):
        return str(self.name)


ExpressionOrModelField = Union[
    "Expression", "NegatedExpression", ModelField, PydanticFieldInfo
]


def embedded(cls):
    """
    Mark a model as embedded to avoid creating multiple indexes if the model is
    only ever used embedded within other models.
    """
    setattr(cls.Meta, "embedded", True)


def is_supported_container_type(typ: Optional[type]) -> bool:
    # TODO: Wait, why don't we support indexing sets?
    if typ == list or typ == tuple:
        return True
    unwrapped = get_origin(typ)
    return unwrapped == list or unwrapped == tuple


def validate_model_fields(model: Type["RedisModel"], field_values: Dict[str, Any]):
    for field_name in field_values:
        if "__" in field_name:
            obj = model
            for sub_field in field_name.split("__"):
                if not isinstance(obj, ModelMeta) and hasattr(obj, "field"):
                    obj = getattr(obj, "field").annotation

                if not hasattr(obj, sub_field):
                    raise QuerySyntaxError(
                        f"The update path {field_name} contains a field that does not "
                        f"exist on {model.__name__}. The field is: {sub_field}"
                    )
                obj = getattr(obj, sub_field)
            return

        if field_name not in model.__fields__:  # type: ignore
            raise QuerySyntaxError(
                f"The field {field_name} does not exist on the model {model.__name__}"
            )


def get_model_fields(model: Any) -> Mapping[str, Any]:
    """Return Pydantic field mappings from model_fields or __fields__."""
    model_fields = getattr(model, "model_fields", None)
    if model_fields is not None:
        return model_fields
    return getattr(model, "__fields__", {})


def has_model_field_mapping(model: Any) -> bool:
    """Check whether a model exposes Pydantic field mappings."""
    return hasattr(model, "model_fields") or hasattr(model, "__fields__")


def is_model_field_instance(value: Any) -> bool:
    """Detect both legacy and compatibility ModelField-like objects."""
    return hasattr(value, "name") and hasattr(value, "field_info")


def validate_model_data(model: Any, values: Any) -> Any:
    """Validate model data with model_validate or parse_obj, as available."""
    if hasattr(model, "model_validate"):
        return model.model_validate(values)
    return model.parse_obj(values)


def decode_redis_value(
    obj: Union[List[bytes], Dict[bytes, bytes], bytes], encoding: str
) -> Union[List[str], Dict[str, str], str]:
    """Decode a binary-encoded Redis hash into the specified encoding."""
    if isinstance(obj, list):
        return [v.decode(encoding) for v in obj]
    if isinstance(obj, dict):
        return {
            key.decode(encoding): value.decode(encoding) for key, value in obj.items()
        }
    elif isinstance(obj, bytes):
        return obj.decode(encoding)


def remove_prefix(value: str, prefix: str) -> str:
    """Remove a prefix from a string."""
    return value.removeprefix(prefix)


class PipelineError(Exception):
    """A Redis pipeline error."""


def verify_pipeline_response(
    response: List[Union[bytes, str]], expected_responses: int = 0
):
    # TODO: More generic pipeline verification here (what else is possible?),
    #  plus hash and JSON-specific verifications in separate functions.
    actual_responses = len(response)
    if actual_responses != expected_responses:
        raise PipelineError(
            f"We expected {expected_responses}, but the Redis "
            f"pipeline returned {actual_responses} responses."
        )


@dataclasses.dataclass
class NegatedExpression:
    """A negated Expression object.

    For now, this is a separate dataclass from Expression that acts as a facade
    around an Expression, indicating to model code (specifically, code
    responsible for querying) to negate the logic in the wrapped Expression. A
    better design is probably possible, maybe at least an ExpressionProtocol?
    """

    expression: "Expression"

    def __invert__(self):
        return self.expression

    def __and__(self, other):
        return Expression(
            left=self, op=Operators.AND, right=other, parents=self.expression.parents
        )

    def __or__(self, other):
        return Expression(
            left=self, op=Operators.OR, right=other, parents=self.expression.parents
        )

    @property
    def left(self):
        return self.expression.left

    @property
    def right(self):
        return self.expression.right

    @property
    def op(self):
        return self.expression.op

    @property
    def name(self):
        if self.expression.op is Operators.EQ:
            return f"NOT {self.expression.name}"
        else:
            return f"{self.expression.name} NOT"

    @property
    def tree(self):
        return render_tree(self)


@dataclasses.dataclass
class Expression:
    op: Operators
    left: Optional[ExpressionOrModelField]
    right: Optional[ExpressionOrModelField]
    parents: List[Tuple[str, "RedisModel"]]

    def __invert__(self):
        return NegatedExpression(self)

    def __and__(self, other: ExpressionOrModelField):
        return Expression(
            left=self, op=Operators.AND, right=other, parents=self.parents
        )

    def __or__(self, other: ExpressionOrModelField):
        return Expression(left=self, op=Operators.OR, right=other, parents=self.parents)

    @property
    def name(self):
        return str(self.op)

    @property
    def tree(self):
        return render_tree(self)


@dataclasses.dataclass(init=False)
class KNNExpression:
    k: int
    vector_field: ModelField
    reference_vector: bytes
    _score_field: Optional[str]

    def __init__(
        self,
        k: int,
        vector_field: Any,
        reference_vector: bytes,
        score_field: Optional[Any] = None,
    ):
        self.k = k
        self.vector_field = (
            vector_field.field if hasattr(vector_field, "field") else vector_field
        )
        self.reference_vector = reference_vector
        if score_field is None:
            self._score_field = None
        elif hasattr(score_field, "field"):
            self._score_field = score_field.field.name
        elif hasattr(score_field, "name"):
            self._score_field = score_field.name
        else:
            self._score_field = str(score_field)

    def __str__(self):
        return f"KNN $K @{self.vector_field.name} $knn_ref_vector AS {self.score_field}"

    @property
    def query_params(self) -> Dict[str, Union[str, bytes]]:
        return {"K": str(self.k), "knn_ref_vector": self.reference_vector}

    @property
    def score_field(self) -> str:
        return self._score_field or f"__{self.vector_field.name}_score"


ExpressionOrNegated = Union[Expression, NegatedExpression]


class ExpressionProxy:
    def __init__(self, field: ModelField, parents: List[Tuple[str, "RedisModel"]]):
        self.field = field
        self.parents = parents.copy()

    def __eq__(self, other: Any) -> Expression:  # type: ignore[override]
        return Expression(
            left=self.field, op=Operators.EQ, right=other, parents=self.parents
        )

    def __ne__(self, other: Any) -> Expression:  # type: ignore[override]
        return Expression(
            left=self.field, op=Operators.NE, right=other, parents=self.parents
        )

    def __lt__(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.LT, right=other, parents=self.parents
        )

    def __le__(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.LE, right=other, parents=self.parents
        )

    def __gt__(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.GT, right=other, parents=self.parents
        )

    def __ge__(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.GE, right=other, parents=self.parents
        )

    def __mod__(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.LIKE, right=other, parents=self.parents
        )

    def __lshift__(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.IN, right=other, parents=self.parents
        )

    def __rshift__(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.NOT_IN, right=other, parents=self.parents
        )

    def startswith(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.STARTSWITH, right=other, parents=self.parents
        )

    def endswith(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.ENDSWITH, right=other, parents=self.parents
        )

    def contains(self, other: Any) -> Expression:
        return Expression(
            left=self.field, op=Operators.CONTAINS, right=other, parents=self.parents
        )

    def __getattr__(self, item):
        if item.startswith("__"):
            raise AttributeError("cannot invoke __getattr__ with reserved field")
        outer_type = outer_type_or_annotation(self.field)
        if is_supported_container_type(outer_type):
            embedded_cls = get_args(outer_type)
            if not embedded_cls:
                raise QuerySyntaxError(
                    "In order to query on a list field, you must define "
                    "the contents of the list with a type annotation, like: "
                    f"orders: List[Order]. Docs: {ERRORS_URL}#E1"
                )
            embedded_cls = embedded_cls[0]
            attr = getattr(embedded_cls, item)
        else:
            attr = getattr(outer_type, item)
        if isinstance(attr, self.__class__):
            new_parents = self.parents.copy()
            new_parent = (self.field.alias, outer_type)
            if new_parent not in new_parents:
                new_parents.append(new_parent)
            return self.__class__(attr.field, new_parents)
        return attr


class QueryNotSupportedError(Exception):
    """The attempted query is not supported."""


class RediSearchFieldTypes(Enum):
    TEXT = "TEXT"
    TAG = "TAG"
    NUMERIC = "NUMERIC"
    GEO = "GEO"


# TODO: How to handle Geo fields?
NUMERIC_TYPES = (float, int, decimal.Decimal)
DEFAULT_PAGE_SIZE = 1000


def convert_datetime_to_timestamp(obj):
    """Convert datetime objects to Unix timestamps for storage."""
    if isinstance(obj, dict):
        return {key: convert_datetime_to_timestamp(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_datetime_to_timestamp(item) for item in obj]
    elif isinstance(obj, datetime.datetime):
        if obj.tzinfo is None:
            obj = obj.replace(tzinfo=datetime.timezone.utc)
        else:
            obj = obj.astimezone(datetime.timezone.utc)
        return obj.timestamp()
    elif isinstance(obj, datetime.date):
        # Convert date to datetime at midnight and get timestamp
        dt = datetime.datetime.combine(
            obj, datetime.time.min, tzinfo=datetime.timezone.utc
        )
        return dt.timestamp()
    else:
        return obj


def convert_timestamp_to_datetime(obj, model_fields):
    """Convert Unix timestamps back to datetime objects based on model field types."""
    if isinstance(obj, dict):
        result = {}
        for key, value in obj.items():
            if key in model_fields:
                field_info = model_fields[key]
                field_type = (
                    field_info.annotation if hasattr(field_info, "annotation") else None
                )

                # Handle Optional types - extract the inner type
                if hasattr(field_type, "__origin__") and field_type.__origin__ is Union:
                    # For Optional[T] which is Union[T, None], get the non-None type
                    args = getattr(field_type, "__args__", ())
                    non_none_types = [
                        arg for arg in args if arg is not type(None)  # noqa: E721
                    ]
                    if len(non_none_types) == 1:
                        field_type = non_none_types[0]

                # Handle direct datetime/date fields
                if field_type in (datetime.datetime, datetime.date) and isinstance(
                    value, (int, float, str)
                ):
                    try:
                        if isinstance(value, str):
                            value = float(value)
                        dt = datetime.datetime.fromtimestamp(
                            value, tz=datetime.timezone.utc
                        ).replace(tzinfo=None)
                        # If the field is specifically a date, convert to date
                        if field_type is datetime.date:
                            result[key] = dt.date()
                        else:
                            result[key] = dt
                    except (ValueError, OSError):
                        result[key] = value  # Keep original value if conversion fails
                # Handle nested models - check if it's a RedisModel subclass
                elif isinstance(value, dict):
                    try:
                        # Check if field_type is a class and subclass of RedisModel
                        if isinstance(field_type, type) and has_model_field_mapping(
                            field_type
                        ):
                            result[key] = convert_timestamp_to_datetime(
                                value, get_model_fields(field_type)
                            )
                        else:
                            result[key] = convert_timestamp_to_datetime(value, {})
                    except (TypeError, AttributeError):
                        result[key] = convert_timestamp_to_datetime(value, {})
                # Handle lists that might contain nested models
                elif isinstance(value, list):
                    # Try to extract the inner type from List[SomeModel]
                    inner_type = None
                    if (
                        hasattr(field_type, "__origin__")
                        and field_type.__origin__ in (list, List)
                        and hasattr(field_type, "__args__")
                        and field_type.__args__
                    ):
                        inner_type = field_type.__args__[0]

                        # Check if the inner type is a nested model
                        try:
                            if isinstance(inner_type, type) and has_model_field_mapping(
                                inner_type
                            ):
                                result[key] = [
                                    convert_timestamp_to_datetime(
                                        item, get_model_fields(inner_type)
                                    )
                                    for item in value
                                ]
                            else:
                                result[key] = convert_timestamp_to_datetime(value, {})
                        except (TypeError, AttributeError):
                            result[key] = convert_timestamp_to_datetime(value, {})
                    else:
                        result[key] = convert_timestamp_to_datetime(value, {})
                else:
                    result[key] = convert_timestamp_to_datetime(value, {})
            else:
                # For keys not in model_fields, still recurse but with empty field info
                result[key] = convert_timestamp_to_datetime(value, {})
        return result
    elif isinstance(obj, list):
        return [convert_timestamp_to_datetime(item, model_fields) for item in obj]
    else:
        return obj


def convert_empty_strings_to_none(obj, model_fields):
    """Convert empty strings back to None for Optional fields in HashModel.

    HashModel stores None as empty string "" because Redis HSET requires non-null
    values. This function converts empty strings back to None for fields that are
    Optional (Union[T, None]) so Pydantic validation succeeds. (Fixes #254)
    """
    if not isinstance(obj, dict):
        return obj

    result = {}
    for key, value in obj.items():
        if key in model_fields and value == "":
            field_info = model_fields[key]
            field_type = (
                field_info.annotation if hasattr(field_info, "annotation") else None
            )
            # Check if the field is Optional (Union[T, None])
            is_optional = False
            if hasattr(field_type, "__origin__") and field_type.__origin__ is Union:
                args = getattr(field_type, "__args__", ())
                if type(None) in args:
                    is_optional = True

            if is_optional:
                result[key] = None
            else:
                result[key] = value
        else:
            result[key] = value
    return result


def convert_bytes_to_base64(obj):
    """Convert bytes objects to base64-encoded strings for storage.

    This is necessary because Redis JSON and the jsonable_encoder cannot
    handle arbitrary binary data. Base64 encoding ensures all byte values
    (0-255) can be safely stored and retrieved.
    """
    import base64

    if isinstance(obj, dict):
        return {key: convert_bytes_to_base64(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_bytes_to_base64(item) for item in obj]
    elif isinstance(obj, bytes):
        return base64.b64encode(obj).decode("ascii")
    else:
        return obj


def convert_dataclasses_to_dicts(obj):
    """Recursively convert non-JSON-serializable types to JSON-safe values.

    Handles:
    - ``Coordinates`` → ``"lon,lat"`` string (required by RediSearch GEO)
    - Other dataclasses → plain dicts via ``dataclasses.asdict()``
    - ``set`` / ``frozenset`` → ``list``
    - ``uuid.UUID`` → string
    - ``Enum`` → its ``.value``
    - ``decimal.Decimal`` → ``float``

    Pydantic v1's ``.dict()`` does not automatically serialise these types,
    so this helper must run before ``json().set()``.
    """
    import uuid

    if isinstance(obj, Coordinates):
        return str(obj)  # "lon,lat" string for RediSearch GEO
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return dataclasses.asdict(obj)
    if isinstance(obj, dict):
        return {key: convert_dataclasses_to_dicts(value) for key, value in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [convert_dataclasses_to_dicts(item) for item in obj]
    if isinstance(obj, (set, frozenset)):
        return [convert_dataclasses_to_dicts(item) for item in obj]
    if isinstance(obj, uuid.UUID):
        return str(obj)
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    return obj


def convert_base64_to_bytes(obj, model_fields):
    """Convert base64-encoded strings back to bytes based on model field types."""
    import base64

    if not isinstance(obj, dict):
        return obj

    result = {}
    for key, value in obj.items():
        if key in model_fields:
            field_info = model_fields[key]
            field_type = (
                field_info.annotation if hasattr(field_info, "annotation") else None
            )

            # Handle Optional types - extract the inner type
            if hasattr(field_type, "__origin__") and field_type.__origin__ is Union:
                args = getattr(field_type, "__args__", ())
                non_none_types = [
                    arg for arg in args if arg is not type(None)  # noqa: E721
                ]
                if len(non_none_types) == 1:
                    field_type = non_none_types[0]

            if field_type is bytes and isinstance(value, str):
                try:
                    result[key] = base64.b64decode(value)
                except (ValueError, TypeError):
                    result[key] = value
            elif isinstance(value, dict):
                # Handle nested models with bytes fields
                try:
                    if isinstance(field_type, type) and has_model_field_mapping(
                        field_type
                    ):
                        result[key] = convert_base64_to_bytes(
                            value, get_model_fields(field_type)
                        )
                    else:
                        result[key] = value
                except (TypeError, AttributeError):
                    result[key] = value
            elif isinstance(value, list):
                # Handle lists that might contain nested models with bytes
                inner_type = None
                if (
                    hasattr(field_type, "__origin__")
                    and field_type.__origin__ in (list, List)
                    and hasattr(field_type, "__args__")
                    and field_type.__args__
                ):
                    inner_type = field_type.__args__[0]
                    try:
                        if isinstance(inner_type, type) and has_model_field_mapping(
                            inner_type
                        ):
                            result[key] = [
                                convert_base64_to_bytes(
                                    item, get_model_fields(inner_type)
                                )
                                for item in value
                            ]
                        else:
                            result[key] = value
                    except (TypeError, AttributeError):
                        result[key] = value
                else:
                    result[key] = value
            else:
                result[key] = value
        else:
            result[key] = value
    return result


class FindQuery:
    def __init__(
        self,
        expressions: Sequence[ExpressionOrNegated],
        model: Type["RedisModel"],
        knn: Optional[KNNExpression] = None,
        offset: int = 0,
        limit: Optional[int] = None,
        page_size: int = DEFAULT_PAGE_SIZE,
        sort_fields: Optional[List[str]] = None,
        nocontent: bool = False,
    ):
        self.expressions = expressions
        self.model = model
        self.knn = knn
        self.offset = offset
        self.limit = limit or (self.knn.k if self.knn else DEFAULT_PAGE_SIZE)
        self.page_size = page_size
        self.nocontent = nocontent

        if sort_fields:
            self.sort_fields = self.validate_sort_fields(sort_fields)
        elif self.knn:
            self.sort_fields = [self.knn.score_field]
        else:
            self.sort_fields = []

        self._expression = None
        self._query: Optional[str] = None
        self._pagination: List[str] = []
        self._model_cache: List[RedisModel] = []

    def dict(self) -> Dict[str, Any]:
        return dict(
            model=self.model,
            offset=self.offset,
            page_size=self.page_size,
            limit=self.limit,
            expressions=copy(self.expressions),
            sort_fields=copy(self.sort_fields),
            nocontent=self.nocontent,
        )

    def copy(self, **kwargs):
        original = self.dict()
        original.update(**kwargs)
        return FindQuery(**original)

    @property
    def pagination(self):
        if self._pagination:
            return self._pagination
        self._pagination = self.resolve_redisearch_pagination()
        return self._pagination

    @property
    def expression(self):
        if self._expression:
            return self._expression
        if self.expressions:
            self._expression = reduce(operator.and_, self.expressions)
        else:
            self._expression = Expression(
                left=None, right=None, op=Operators.ALL, parents=[]
            )
        return self._expression

    @property
    def query(self):
        """
        Resolve and return the RediSearch query for this FindQuery.

        NOTE: We cache the resolved query string after generating it. This should be OK
        because all mutations of FindQuery through public APIs return a new FindQuery instance.
        """
        if self._query:
            return self._query
        self._query = self.resolve_redisearch_query(self.expression)
        if self.knn:
            # Always wrap the filter expression in parentheses when combining
            # with KNN, unless it's the wildcard "*". This ensures OR expressions
            # like "(A)| (B)" become "((A)| (B))=>[KNN ...]" instead of the
            # invalid "(A)| (B)=>[KNN ...]" where KNN only applies to the
            # second term.
            if self._query != "*":
                self._query = f"({self._query})"
            self._query += f"=>[{self.knn}]"
        return self._query

    @property
    def query_params(self):
        params: List[Union[str, bytes]] = []
        if self.knn:
            params += [attr for kv in self.knn.query_params.items() for attr in kv]
        return params

    def validate_sort_fields(self, sort_fields: List[str]):
        resolved_sort_fields = []
        for sort_field in sort_fields:
            field_name = sort_field.lstrip("-")
            if self.knn and field_name == self.knn.score_field:
                resolved_sort_fields.append(sort_field)
                continue
            resolved_field_name, field_info = self.resolve_sort_field(field_name)
            if not getattr(field_info, "sortable", False):
                raise QueryNotSupportedError(
                    f"You tried sort by {field_name}, but {self.model} does "
                    f"not define that field as sortable. Docs: {ERRORS_URL}#E2"
                )
            resolved_sort_fields.append(
                f"-{resolved_field_name}"
                if sort_field.startswith("-")
                else resolved_field_name
            )
        return resolved_sort_fields

    def resolve_sort_field(self, field_name: str) -> Tuple[str, PydanticFieldInfo]:
        # Queries use `.` or `__` for embedded paths, but RediSearch SORTBY uses
        # the flattened schema alias with underscores.
        normalized_field_name = field_name.replace(".", "__")
        parts = normalized_field_name.split("__")
        current_model = self.model
        resolved_parts = []
        field_info = None

        for index, part in enumerate(parts):
            if part not in current_model.__fields__:  # type: ignore
                raise QueryNotSupportedError(
                    f"You tried sort by {field_name}, but that field "
                    f"does not exist on the model {self.model}"
                )
            field = current_model.__fields__[part]  # type: ignore[index]
            resolved_parts.append(part)
            if isinstance(field, FieldInfo) or isinstance(field, PydanticFieldInfo):
                field_info = field
            else:
                field_info = field.field_info

            if index == len(parts) - 1:
                break

            field_type = outer_type_or_annotation(field)
            if is_supported_container_type(field_type):
                type_args = get_args(field_type)
                field_type = type_args[0] if type_args else field_type
            if not isinstance(field_type, type) or not issubclass(
                field_type, RedisModel
            ):
                raise QueryNotSupportedError(
                    f"You tried sort by {field_name}, but that field "
                    f"does not exist on the model {self.model}"
                )
            current_model = field_type

        if field_info is None:
            raise QueryNotSupportedError(
                f"You tried sort by {field_name}, but that field "
                f"does not exist on the model {self.model}"
            )
        return "_".join(resolved_parts), field_info

    @staticmethod
    def resolve_field_type(
        field: Union[ModelField, PydanticFieldInfo], op: Operators
    ) -> RediSearchFieldTypes:
        field_info: Union[FieldInfo, ModelField, PydanticFieldInfo]

        if not hasattr(field, "field_info"):
            field_info = field
        else:
            field_info = field.field_info
        if getattr(field_info, "primary_key", None) is True:
            return RediSearchFieldTypes.TAG
        elif op is Operators.LIKE:
            fts = getattr(field_info, "full_text_search", None)
            if fts is not True:  # Could be PydanticUndefined
                raise QuerySyntaxError(
                    f"You tried to do a full-text search on the field '{field.alias}', "
                    f"but the field is not indexed for full-text search. Use the "
                    f"full_text_search=True option. Docs: {ERRORS_URL}#E3"
                )
            return RediSearchFieldTypes.TEXT

        field_type = outer_type_or_annotation(field)

        if not isinstance(field_type, type):
            field_type = field_type.__origin__

        if field_type is Coordinates:
            return RediSearchFieldTypes.GEO
        container_type = get_origin(field_type)

        if is_supported_container_type(container_type):
            # NOTE: A list of strings, like:
            #
            #     tarot_cards: List[str] = field(index=True)
            #
            # becomes a TAG field, which means that users can run equality and
            # membership queries on values.
            #
            # Meanwhile, a list of RedisModels, like:
            #
            #     friends: List[Friend] = field(index=True)
            #
            # is not itself directly indexed, but instead, we index any fields
            # within the model inside the list marked as `index=True`.
            return RediSearchFieldTypes.TAG
        elif container_type is not None:
            raise QuerySyntaxError(
                "Only lists and tuples are supported for multi-value fields. "
                f"Docs: {ERRORS_URL}#E4"
            )
        elif field_type is bool:
            return RediSearchFieldTypes.TAG
        elif is_numeric_type(field_type):
            # Index numeric Python types as NUMERIC fields, so we can support
            # range queries.
            return RediSearchFieldTypes.NUMERIC
        else:
            # TAG fields are the default field type and support equality and
            # membership queries, though membership (and the multi-value nature
            # of the field) are hidden from users unless they explicitly index
            # multiple values, with either a list or tuple,
            # e.g.,
            #    favorite_foods: List[str] = field(index=True)
            return RediSearchFieldTypes.TAG

    @staticmethod
    def expand_tag_value(value):
        if isinstance(value, str):
            return escaper.escape(value)
        if isinstance(value, bytes):
            # TODO: We don't decode bytes objects passed as input. Should we?
            # TODO: TAG indexes fail on JSON arrays of numbers -- only strings
            #  are allowed -- what happens if we save an array of bytes?
            return value
        try:
            return "|".join([escaper.escape(str(v)) for v in value])
        except TypeError:
            log.debug(
                "Escaping single non-iterable value used for an IN or "
                "NOT_IN query: %s",
                value,
            )
        return escaper.escape(str(value))

    @classmethod
    def resolve_value(
        cls,
        field_name: str,
        field_type: RediSearchFieldTypes,
        field_info: PydanticFieldInfo,
        op: Operators,
        value: Any,
        parents: List[Tuple[str, "RedisModel"]],
    ) -> str:
        result = ""
        if parents:
            prefix = "_".join([p[0] for p in parents])
            field_name = f"{prefix}_{field_name}"
        if field_type is RediSearchFieldTypes.TEXT:
            result = f"@{field_name}_fts:"
            if op is Operators.EQ:
                result += f'"{value}"'
            elif op is Operators.NE:
                result = f'-({result}"{value}")'
            elif op is Operators.LIKE:
                result += value
            else:
                raise QueryNotSupportedError(
                    "Only equals (=), not-equals (!=), and like() "
                    "comparisons are supported for TEXT fields. "
                    f"Docs: {ERRORS_URL}#E5"
                )
        elif field_type is RediSearchFieldTypes.NUMERIC:

            def convert_numeric_value(v):
                """Convert Enum and datetime values for NUMERIC queries."""
                # Convert Enum to its value (fixes #108)
                if isinstance(v, Enum):
                    v = v.value
                # Convert datetime objects to timestamps
                if isinstance(v, (datetime.datetime, datetime.date)):
                    if isinstance(v, datetime.date) and not isinstance(
                        v, datetime.datetime
                    ):
                        v = datetime.datetime.combine(v, datetime.time.min)
                    v = v.timestamp()
                return v

            if op is Operators.IN:
                # Handle IN operator for NUMERIC fields (fixes #499)
                converted_values = [convert_numeric_value(v) for v in value]
                parts = [f"(@{field_name}:[{v} {v}])" for v in converted_values]
                result += "|".join(parts)
            elif op is Operators.NOT_IN:
                # Handle NOT_IN operator for NUMERIC fields
                converted_values = [convert_numeric_value(v) for v in value]
                parts = [f"(@{field_name}:[{v} {v}])" for v in converted_values]
                result += f"-({' | '.join(parts)})"
            else:
                value = convert_numeric_value(value)
                if op is Operators.EQ:
                    result += f"@{field_name}:[{value} {value}]"
                elif op is Operators.NE:
                    result += f"-(@{field_name}:[{value} {value}])"
                elif op is Operators.GT:
                    result += f"@{field_name}:[({value} +inf]"
                elif op is Operators.LT:
                    result += f"@{field_name}:[-inf ({value}]"
                elif op is Operators.GE:
                    result += f"@{field_name}:[{value} +inf]"
                elif op is Operators.LE:
                    result += f"@{field_name}:[-inf {value}]"
        # TODO: How will we know the difference between a multi-value use of a TAG
        #  field and our hidden use of TAG for exact-match queries?
        elif field_type is RediSearchFieldTypes.GEO:
            if not isinstance(value, GeoFilter):
                raise QuerySyntaxError(
                    "You can only use a GeoFilter object with a GEO field."
                )
            if op is Operators.EQ:
                result += f"@{field_name}:[{value}]"
        elif field_type is RediSearchFieldTypes.TAG:
            if op is Operators.EQ:
                separator_char = getattr(
                    field_info, "separator", SINGLE_VALUE_TAG_FIELD_SEPARATOR
                )
                if value == separator_char:
                    # The value is ONLY the TAG field separator character --
                    # this is not going to work.
                    log.warning(
                        "Your query against the field %s is for a single character, %s, "
                        "that is used internally by redis-om-python. We must ignore "
                        "this portion of the query. Please review your query to find "
                        "an alternative query that uses a string containing more than "
                        "just the character %s.",
                        field_name,
                        separator_char,
                        separator_char,
                    )
                    return ""
                if isinstance(value, bool):
                    result = "@{field_name}:{{{value}}}".format(
                        field_name=field_name, value=value
                    )
                elif isinstance(value, int):
                    # This if will hit only if the field is a primary key of type int
                    result = f"@{field_name}:[{value} {value}]"
                elif separator_char in value:
                    # The value contains the TAG field separator. We can work
                    # around this by breaking apart the values and unioning them
                    # with multiple field:{} queries.
                    values: filter = filter(None, value.split(separator_char))
                    for value in values:
                        value = escaper.escape(value)
                        result += "@{field_name}:{{{value}}}".format(
                            field_name=field_name, value=value
                        )
                else:
                    value = escaper.escape(value)
                    result += "@{field_name}:{{{value}}}".format(
                        field_name=field_name, value=value
                    )
            elif op is Operators.NE:
                value = escaper.escape(value)
                result += "-(@{field_name}:{{{value}}})".format(
                    field_name=field_name, value=value
                )
            elif op is Operators.IN:
                expanded_value = cls.expand_tag_value(value)
                result += "(@{field_name}:{{{expanded_value}}})".format(
                    field_name=field_name, expanded_value=expanded_value
                )
            elif op is Operators.NOT_IN:
                # TODO: Implement NOT_IN, test this...
                expanded_value = cls.expand_tag_value(value)
                result += "-(@{field_name}:{{{expanded_value}}})".format(
                    field_name=field_name, expanded_value=expanded_value
                )
            elif op is Operators.STARTSWITH:
                expanded_value = cls.expand_tag_value(value)
                result += "(@{field_name}:{{{expanded_value}*}})".format(
                    field_name=field_name, expanded_value=expanded_value
                )
            elif op is Operators.ENDSWITH:
                expanded_value = cls.expand_tag_value(value)
                result += "(@{field_name}:{{*{expanded_value}}})".format(
                    field_name=field_name, expanded_value=expanded_value
                )
            elif op is Operators.CONTAINS:
                expanded_value = cls.expand_tag_value(value)
                result += "(@{field_name}:{{*{expanded_value}*}})".format(
                    field_name=field_name, expanded_value=expanded_value
                )

        return result

    def resolve_redisearch_pagination(self):
        """Resolve pagination options for a query."""
        return ["LIMIT", self.offset, self.limit]

    def resolve_redisearch_sort_fields(self):
        """Resolve sort options for a query."""
        if not self.sort_fields:
            return
        fields = []
        for f in self.sort_fields:
            direction = "desc" if f.startswith("-") else "asc"
            fields.extend([f.lstrip("-"), direction])
        if self.sort_fields:
            return ["SORTBY", *fields]

    @classmethod
    def resolve_redisearch_query(cls, expression: ExpressionOrNegated) -> str:
        """
        Resolve an arbitrarily deep expression into a single RediSearch query string.

        This method is complex. Note the following:

        1. This method makes a recursive call to itself when it finds that
           either the left or right operand contains another expression.

        2. An expression might be in a "negated" form, which means that the user
           gave us an expression like ~(Member.age == 30), or in other words,
           "Members whose age is NOT 30." Thus, a negated expression is one in
           which the meaning of an expression is inverted. If we find a negated
           expression, we need to add the appropriate "NOT" syntax but can
           otherwise use the resolved RediSearch query for the expression as-is.

        3. The final resolution of an expression should be a left operand that's
           a ModelField, an operator, and a right operand that's NOT a ModelField.
           With an IN or NOT_IN operator, the right operand can be a sequence
           type, but otherwise, sequence types are converted to strings.

        TODO: When the operator is not IN or NOT_IN, detect a sequence type (other
         than strings, which are allowed) and raise an exception.
        """
        field_type = None
        field_name = None
        field_info = None
        encompassing_expression_is_negated = False
        result = ""

        if isinstance(expression, NegatedExpression):
            encompassing_expression_is_negated = True
            expression = expression.expression

        if expression.op is Operators.ALL:
            if encompassing_expression_is_negated:
                # TODO: Is there a use case for this, perhaps for dynamic
                #  scoring purposes with full-text search?
                raise QueryNotSupportedError(
                    "You cannot negate a query for all results."
                )
            return "*"

        if isinstance(expression.left, Expression) or isinstance(
            expression.left, NegatedExpression
        ):
            result += f"({cls.resolve_redisearch_query(expression.left)})"
        elif is_model_field_instance(expression.left):
            field_type = cls.resolve_field_type(expression.left, expression.op)
            field_name = expression.left.name
            field_info = expression.left.field_info
            resolved_field_name = field_name
            if expression.parents:
                prefix = "_".join([p[0] for p in expression.parents])
                resolved_field_name = f"{prefix}_{field_name}"
            if not field_info or not getattr(field_info, "index", None):
                raise QueryNotSupportedError(
                    f"You tried to query by a field ({resolved_field_name}) "
                    f"that isn't indexed. Docs: {ERRORS_URL}#E6"
                )
        elif isinstance(expression.left, FieldInfo):
            field_type = cls.resolve_field_type(expression.left, expression.op)
            field_name = expression.left.alias
            field_info = expression.left
            if not field_info or not getattr(field_info, "index", None):
                raise QueryNotSupportedError(
                    f"You tried to query by a field ({field_name}) "
                    f"that isn't indexed. Docs: {ERRORS_URL}#E6"
                )
        else:
            raise QueryNotSupportedError(
                "A query expression should start with either a field "
                f"or an expression enclosed in parentheses. Docs: {ERRORS_URL}#E7"
            )

        right = expression.right

        if isinstance(right, Expression) or isinstance(right, NegatedExpression):
            if expression.op == Operators.AND:
                result += " "
            elif expression.op == Operators.OR:
                result += "| "
            else:
                raise QueryNotSupportedError(
                    "You can only combine two query expressions with"
                    f"AND (&) or OR (|). Docs: {ERRORS_URL}#E8"
                )

            if isinstance(right, NegatedExpression):
                result += "-"
                # We're handling the RediSearch operator in this call ("-"), so resolve the
                # inner expression instead of the NegatedExpression.
                right = right.expression

            result += f"({cls.resolve_redisearch_query(right)})"
        else:
            if not field_name:
                raise QuerySyntaxError("Could not resolve field name. See docs: TODO")
            elif not field_type:
                raise QuerySyntaxError("Could not resolve field type. See docs: TODO")
            elif not field_info:
                raise QuerySyntaxError("Could not resolve field info. See docs: TODO")
            elif is_model_field_instance(right):
                raise QueryNotSupportedError(
                    "Comparing fields is not supported. See docs: TODO"
                )
            else:
                result += cls.resolve_value(
                    field_name,
                    field_type,
                    field_info,
                    expression.op,
                    right,
                    expression.parents,
                )

        if encompassing_expression_is_negated:
            result = f"-({result})"

        return result

    def execute(
        self, exhaust_results=True, return_raw_result=False, return_query_args=False
    ):
        args: List[Union[str, bytes]] = [
            "FT.SEARCH",
            self.model.Meta.index_name,
            self.query,
            *self.pagination,
        ]
        if self.sort_fields:
            args += self.resolve_redisearch_sort_fields()

        if self.query_params:
            args += ["PARAMS", str(len(self.query_params))] + self.query_params

        if self.knn:
            # Ensure DIALECT is at least 2
            if "DIALECT" not in args:
                args += ["DIALECT", "2"]
            else:
                i_dialect = args.index("DIALECT") + 1
                if int(args[i_dialect]) < 2:
                    args[i_dialect] = "2"
            args += ["RETURN", "2", "$", self.knn.score_field]

        if self.nocontent:
            args.append("NOCONTENT")

        if return_query_args:
            return self.model.Meta.index_name, args

        if not has_redisearch(self.model.db()):
            raise RedisModelError(
                "Your Redis instance does not have either the RediSearch module "
                "or RedisJSON module installed. Querying requires that your Redis "
                "instance has one of these modules installed."
            )
        if not getattr(self.model._meta, "index_health_checked", False):
            self.model.check_index_health()
            self.model._meta.index_health_checked = True

        # Reset the cache if we're executing from offset 0.
        if self.offset == 0:
            self._model_cache.clear()

        # If the offset is greater than 0, we're paginating through a result set,
        # so append the new results to results already in the cache.
        raw_result = self.model.db().execute_command(*args)
        if return_raw_result:
            return raw_result
        count = raw_result[0]
        results = self.model.from_redis(raw_result)
        self._model_cache += results

        if not exhaust_results:
            return self._model_cache

        # The query returned all results, so we have no more work to do.
        if count <= len(results):
            return self._model_cache

        # Transparently (to the user) make subsequent requests to paginate
        # through the results and finally return them all.
        query = self
        while True:
            # Make a query for each pass of the loop, with a new offset equal to the
            # current offset plus `page_size`, until we stop getting results back.
            query = query.copy(offset=query.offset + query.page_size)
            _results = query.execute(exhaust_results=False)
            if not _results:
                break
            self._model_cache += _results
        return self._model_cache

    def get_query(self):
        query = self.copy()
        return query.execute(return_query_args=True)

    def first(self):
        query = self.copy(offset=0, limit=1, sort_fields=self.sort_fields)
        results = query.execute(exhaust_results=False)
        if not results:
            raise NotFoundError()
        return results[0]

    def count(self):
        query = self.copy(offset=0, limit=0, nocontent=True)
        result = query.execute(exhaust_results=True, return_raw_result=True)
        return result[0]

    def aggregate_ct(self) -> int:
        # WARN: Has issues when multiple 'find' parameters match the same record
        #       It will count them more than once.
        args = [
            "FT.AGGREGATE",
            self.model.Meta.index_name,
            self.query,
            "APPLY",
            "matched_terms()",
            "AS",
            "countable",
            "GROUPBY",
            "1",
            "@countable",
            "REDUCE",
            "COUNT",
            "0",
        ]
        raw_result = self.model.db().execute_command(*args)
        try:
            return sum(
                [
                    int(
                        result[3].decode("utf-8", "ignore")
                        if isinstance(result[3], bytes)
                        else result[3]
                    )
                    for result in raw_result[1:]
                ]
            )
        except IndexError:
            return 0

    def all(self, batch_size=DEFAULT_PAGE_SIZE):
        if batch_size != self.page_size:
            query = self.copy(page_size=batch_size, limit=batch_size)
            return query.execute()
        return self.execute()

    def page(self, offset=0, limit=10):
        return self.copy(offset=offset, limit=limit).execute(
            exhaust_results=False
        )

    def sort_by(self, *fields: str):
        if not fields:
            return self
        return self.copy(sort_fields=list(fields))

    def update(self, use_transaction=True, **field_values):
        """
        Update models that match this query to the given field-value pairs.

        Keys and values given as keyword arguments are interpreted as fields
        on the target model and the values as the values to which to set the
        given fields.
        """
        validate_model_fields(self.model, field_values)
        pipeline = self.model.db().pipeline() if use_transaction else None

        # TODO: async for here?
        for model in self.all():
            for field, value in field_values.items():
                setattr(model, field, value)
            # TODO: In the non-transaction case, can we do more to detect
            #  failure responses from Redis?
            model.save(pipeline=pipeline)

        if pipeline:
            # TODO: Response type?
            # TODO: Better error detection for transactions.
            pipeline.execute()

    def delete(self):
        """Delete all matching records in this query."""
        # TODO: Better response type, error detection
        try:
            return self.model.db().delete(*[m.key() for m in self.all()])
        except ResponseError:
            return 0

    def __iter__(self):
        if self._model_cache:
            for m in self._model_cache:
                yield m
        else:
            for m in self.execute():
                yield m

    def __getitem__(self, item: int):
        """
        Given this code:
            Model.find()[1000]

        We should return only the 1000th result.

            1. If the result is loaded in the query cache for this query,
               we can return it directly from the cache.

            2. If the query cache does not have enough elements to return
               that result, then we should clone the current query and
               give it a new offset and limit: offset=n, limit=1.
        """
        if ASYNC_MODE:
            raise QuerySyntaxError(
                "Cannot use [] notation with async code. "
                "Use FindQuery.get_item() instead."
            )
        if self._model_cache and len(self._model_cache) >= item:
            return self._model_cache[item]

        query = self.copy(offset=item, limit=1)

        return query.execute()[0]  # noqa

    def get_item(self, item: int):
        """
        Given this code:
            await Model.find().get_item(1000)

        We should return only the 1000th result.

            1. If the result is loaded in the query cache for this query,
               we can return it directly from the cache.

            2. If the query cache does not have enough elements to return
               that result, then we should clone the current query and
               give it a new offset and limit: offset=n, limit=1.

        NOTE: This method is included specifically for async users, who
        cannot use the notation Model.find()[1000].
        """
        if self._model_cache and len(self._model_cache) >= item:
            return self._model_cache[item]

        query = self.copy(offset=item, limit=1)
        result = query.execute()
        return result[0]


class PrimaryKeyCreator(Protocol):
    def create_pk(self, *args, **kwargs) -> str:
        """Create a new primary key"""


class UlidPrimaryKey:
    """
    A client-side generated primary key that follows the ULID spec.
    https://github.com/ulid/javascript#specification
    """

    @staticmethod
    def create_pk(*args, **kwargs) -> str:
        return str(ULID())


def __dataclass_transform__(
    *,
    eq_default: bool = True,
    order_default: bool = False,
    kw_only_default: bool = False,
    field_descriptors: Tuple[Union[type, Callable[..., Any]], ...] = (()),
) -> Callable[[_T], _T]:
    return lambda a: a


class FieldInfo(PydanticFieldInfo):
    def __init__(self, default: Any = Undefined, **kwargs: Any) -> None:
        primary_key = kwargs.pop("primary_key", False)
        sortable = kwargs.pop("sortable", Undefined)
        case_sensitive = kwargs.pop("case_sensitive", Undefined)
        index = kwargs.pop("index", Undefined)
        full_text_search = kwargs.pop("full_text_search", Undefined)
        vector_options = kwargs.pop("vector_options", None)
        separator = kwargs.pop("separator", SINGLE_VALUE_TAG_FIELD_SEPARATOR)
        # When PYDANTIC_V2=True, `Undefined` is pydantic_core.PydanticUndefined.
        # Pydantic v1's FieldInfo only treats its own `Undefined` sentinel as
        # "no default" / "required".  Passing pydantic v2's sentinel makes
        # pydantic v1 treat the field as having a concrete default (the sentinel
        # object itself), setting required=False.  Convert it to the v1 sentinel
        # so that required fields are correctly marked as required.
        if PYDANTIC_V2 and default is Undefined:
            from pydantic.v1.fields import Undefined as _V1Undefined

            super().__init__(default=_V1Undefined, **kwargs)
        else:
            super().__init__(default=default, **kwargs)
        self.primary_key = primary_key
        self.sortable = sortable
        self.case_sensitive = case_sensitive
        self.index = index
        self.full_text_search = full_text_search
        self.vector_options = vector_options
        self.separator = separator


class RelationshipInfo(Representation):
    def __init__(
        self,
        *,
        back_populates: Optional[str] = None,
        link_model: Optional[Any] = None,
    ) -> None:
        self.back_populates = back_populates
        self.link_model = link_model


@dataclasses.dataclass
class VectorFieldOptions:
    class ALGORITHM(Enum):
        FLAT = "FLAT"
        HNSW = "HNSW"

    class TYPE(Enum):
        FLOAT32 = "FLOAT32"
        FLOAT64 = "FLOAT64"

    class DISTANCE_METRIC(Enum):
        L2 = "L2"
        IP = "IP"
        COSINE = "COSINE"

    algorithm: ALGORITHM
    type: TYPE
    dimension: int
    distance_metric: DISTANCE_METRIC

    # Common optional parameters
    initial_cap: Optional[int] = None

    # Optional parameters for FLAT
    block_size: Optional[int] = None

    # Optional parameters for HNSW
    m: Optional[int] = None
    ef_construction: Optional[int] = None
    ef_runtime: Optional[int] = None
    epsilon: Optional[float] = None

    @staticmethod
    def flat(
        type: TYPE,
        dimension: int,
        distance_metric: DISTANCE_METRIC,
        initial_cap: Optional[int] = None,
        block_size: Optional[int] = None,
    ):
        return VectorFieldOptions(
            algorithm=VectorFieldOptions.ALGORITHM.FLAT,
            type=type,
            dimension=dimension,
            distance_metric=distance_metric,
            initial_cap=initial_cap,
            block_size=block_size,
        )

    @staticmethod
    def hnsw(
        type: TYPE,
        dimension: int,
        distance_metric: DISTANCE_METRIC,
        initial_cap: Optional[int] = None,
        m: Optional[int] = None,
        ef_construction: Optional[int] = None,
        ef_runtime: Optional[int] = None,
        epsilon: Optional[float] = None,
    ):
        return VectorFieldOptions(
            algorithm=VectorFieldOptions.ALGORITHM.HNSW,
            type=type,
            dimension=dimension,
            distance_metric=distance_metric,
            initial_cap=initial_cap,
            m=m,
            ef_construction=ef_construction,
            ef_runtime=ef_runtime,
            epsilon=epsilon,
        )

    @property
    def schema(self):
        attr = []
        for k, v in vars(self).items():
            if k == "algorithm" or v is None:
                continue
            attr.extend(
                [
                    k.upper() if k != "dimension" else "DIM",
                    str(v) if not isinstance(v, Enum) else v.name,
                ]
            )

        return " ".join([f"VECTOR {self.algorithm.name} {len(attr)}"] + attr)


def Field(
    default: Any = Undefined,
    *,
    default_factory: Optional[NoArgAnyCallable] = None,
    alias: Optional[str] = None,
    title: Optional[str] = None,
    description: Optional[str] = None,
    exclude: Union[
        AbstractSet[Union[int, str]], Mapping[Union[int, str], Any], Any
    ] = None,
    include: Union[
        AbstractSet[Union[int, str]], Mapping[Union[int, str], Any], Any
    ] = None,
    const: Optional[bool] = None,
    gt: Optional[float] = None,
    ge: Optional[float] = None,
    lt: Optional[float] = None,
    le: Optional[float] = None,
    multiple_of: Optional[float] = None,
    min_items: Optional[int] = None,
    max_items: Optional[int] = None,
    min_length: Optional[int] = None,
    max_length: Optional[int] = None,
    allow_mutation: bool = True,
    regex: Optional[str] = None,
    primary_key: bool = False,
    sortable: Union[bool, UndefinedType] = Undefined,
    case_sensitive: Union[bool, UndefinedType] = Undefined,
    index: Union[bool, UndefinedType] = Undefined,
    full_text_search: Union[bool, UndefinedType] = Undefined,
    vector_options: Optional[VectorFieldOptions] = None,
    separator: str = SINGLE_VALUE_TAG_FIELD_SEPARATOR,
    schema_extra: Optional[Dict[str, Any]] = None,
) -> Any:
    current_schema_extra = schema_extra or {}
    field_info = FieldInfo(
        default,
        default_factory=default_factory,
        alias=alias,
        title=title,
        description=description,
        exclude=exclude,
        include=include,
        const=const,
        gt=gt,
        ge=ge,
        lt=lt,
        le=le,
        multiple_of=multiple_of,
        min_items=min_items,
        max_items=max_items,
        min_length=min_length,
        max_length=max_length,
        allow_mutation=allow_mutation,
        regex=regex,
        primary_key=primary_key,
        sortable=sortable,
        case_sensitive=case_sensitive,
        index=index,
        full_text_search=full_text_search,
        vector_options=vector_options,
        separator=separator,
        **current_schema_extra,
    )
    return field_info


@dataclasses.dataclass
class PrimaryKey:
    name: str
    field: ModelField


class BaseMeta(Protocol):
    global_key_prefix: str
    model_key_prefix: str
    primary_key_pattern: str
    database: Optional[Union[DatabaseConnection, DatabaseProvider]]
    primary_key: PrimaryKey
    primary_key_creator_cls: Type[PrimaryKeyCreator]
    index_name: str
    embedded: bool
    encoding: str
    default_ttl: Optional[int]
    index_health_checked: bool


@dataclasses.dataclass
class DefaultMeta:
    """A default placeholder Meta object.

    TODO: Revisit whether this is really necessary, and whether making
     these all optional here is the right choice.
    """

    global_key_prefix: Optional[str] = None
    model_key_prefix: Optional[str] = None
    primary_key_pattern: Optional[str] = None
    # May be a connection instance or a callable that returns one lazily.
    database: Optional[Union[DatabaseConnection, DatabaseProvider]] = None
    primary_key: Optional[PrimaryKey] = None
    primary_key_creator_cls: Optional[Type[PrimaryKeyCreator]] = None
    index_name: Optional[str] = None
    embedded: Optional[bool] = False
    encoding: str = "utf-8"
    default_ttl: Optional[int] = None
    index_health_checked: bool = False


def _convert_v2_validators_to_v1(attrs: dict) -> dict:
    """Convert pydantic v2 validator proxies in *attrs* to pydantic v1 form.

    When a user decorates a method with ``@root_validator`` or ``@validator``
    imported from ``pydantic`` (the v2 compatibility shim), the decorator
    creates a ``PydanticDescriptorProxy`` wrapping a ``classmethod``.
    Pydantic v1's ``ModelMetaclass`` does not recognise these objects and
    attempts to deepcopy them as ordinary field defaults — which fails
    because ``classmethod`` objects are not picklable.

    This helper detects such proxies and re-wraps the underlying function
    with the corresponding ``pydantic.v1`` decorator so that the v1
    metaclass can process them normally.
    """
    try:
        from pydantic._internal._decorators import (
            PydanticDescriptorProxy,
            RootValidatorDecoratorInfo,
            ValidatorDecoratorInfo,
        )
    except ImportError:
        return attrs

    from pydantic.v1 import root_validator as v1_root_validator
    from pydantic.v1 import validator as v1_validator

    converted = dict(attrs)
    for attr_name, value in list(converted.items()):
        if not isinstance(value, PydanticDescriptorProxy):
            continue
        # Pydantic may wrap the original function in a classmethod for v1-style
        # validators, but some proxies expose the raw callable directly.
        func = getattr(value.wrapped, "__func__", value.wrapped)
        info = value.decorator_info

        if isinstance(info, RootValidatorDecoratorInfo):
            pre = info.mode == "before"
            # In pydantic v1, post-root-validators (pre=False) require
            # skip_on_failure=True so they are skipped when field
            # validation has already failed.  Pre-validators run before
            # field validation, so the flag is irrelevant for them.
            skip = not pre
            converted[attr_name] = v1_root_validator(
                pre=pre, skip_on_failure=skip, allow_reuse=True
            )(func)
        elif isinstance(info, ValidatorDecoratorInfo):
            converted[attr_name] = v1_validator(
                *info.fields,
                pre=(info.mode == "before"),
                always=info.always,
                each_item=info.each_item,
                allow_reuse=True,
            )(func)
    return converted


def _convert_v2_annotation_to_v1(annotation: Any) -> Any:
    origin = get_origin(annotation)
    if origin is not None:
        converted_args = tuple(
            _convert_v2_annotation_to_v1(arg) for arg in get_args(annotation)
        )
        if not converted_args:
            return annotation
        if origin is Union:
            return Union[converted_args]
        if origin is Annotated:
            return annotation
        if origin is Literal:
            return annotation
        if hasattr(annotation, "copy_with"):
            try:
                return annotation.copy_with(converted_args)
            except TypeError:
                return annotation
        try:
            if len(converted_args) == 1:
                return origin[converted_args[0]]
            return origin[converted_args]
        except TypeError:
            return annotation

    if isinstance(annotation, type):
        module_name = getattr(annotation, "__module__", "")
        annotation_name = getattr(annotation, "__name__", None)
        if (
            module_name.startswith("pydantic.")
            and not module_name.startswith("pydantic.v1")
            and annotation_name
        ):
            try:
                import pydantic.v1 as pydantic_v1

                if hasattr(pydantic_v1, annotation_name):
                    return getattr(pydantic_v1, annotation_name)
            except ImportError:
                return annotation
    return annotation


class ModelMeta(ModelMetaclass):
    _meta: BaseMeta

    def __new__(cls, name, bases, attrs, **kwargs):  # noqa C901
        meta = attrs.pop("Meta", None)

        # Convert pydantic v2 compat validators to pydantic v1 validators.
        # When users apply @root_validator or @validator from pydantic (v2),
        # they produce PydanticDescriptorProxy objects that pydantic v1's
        # ModelMetaclass cannot handle (deepcopy fails on the inner
        # classmethod).  Re-wrap them with the v1 equivalents so the v1
        # metaclass processes them correctly.
        if PYDANTIC_V2:
            attrs = _convert_v2_validators_to_v1(attrs)
            annotations = attrs.get("__annotations__", {})
            if annotations:
                attrs["__annotations__"] = {
                    key: _convert_v2_annotation_to_v1(value)
                    for key, value in annotations.items()
                }

        # pydantic v1 raises NameError when a field name shadows a BaseModel
        # built-in (e.g. "dict", "json", "schema").  Redis OM intentionally
        # allows any user-defined field name, so we temporarily suppress that
        # check during class creation.
        if PYDANTIC_V2:
            import pydantic.v1.main as _pv1_main
        else:
            import pydantic.main as _pv1_main

        _orig_validate_field_name = getattr(
            _pv1_main, "validate_field_name", lambda _bases, _field_name: None
        )
        _pv1_main.validate_field_name = lambda _bases, _field_name: None  # noqa: E731
        try:
            new_class = super().__new__(cls, name, bases, attrs, **kwargs)
        finally:
            _pv1_main.validate_field_name = _orig_validate_field_name

        # The fact that there is a Meta field and _meta field is important: a
        # user may have given us a Meta object with their configuration, while
        # we might have inherited _meta from a parent class, and should
        # therefore use some of the inherited fields.
        meta = meta or getattr(new_class, "Meta", None)
        base_meta = getattr(new_class, "_meta", None)

        if meta and meta != DefaultMeta and meta != base_meta:
            new_class.Meta = meta
            new_class._meta = meta
        elif base_meta:
            new_class._meta = type(
                f"{new_class.__name__}Meta", (base_meta,), dict(base_meta.__dict__)
            )
            new_class.Meta = new_class._meta
            # Unset inherited values we don't want to reuse (typically based on
            # the model name).
            new_class._meta.model_key_prefix = None
            new_class._meta.index_name = None
        else:
            new_class._meta = type(
                f"{new_class.__name__}Meta", (DefaultMeta,), dict(DefaultMeta.__dict__)
            )
            new_class.Meta = new_class._meta

        # Create proxies for each model field so that we can use the field
        # in queries, like Model.get(Model.field_name == 1)
        for field_name, field in new_class.__fields__.items():
            if not isinstance(field, FieldInfo):
                for base_candidate in bases:
                    if hasattr(base_candidate, field_name):
                        inner_field = getattr(base_candidate, field_name)
                        if hasattr(inner_field, "field") and isinstance(
                            getattr(inner_field, "field"), FieldInfo
                        ):
                            field.metadata.append(getattr(inner_field, "field"))
                            field = getattr(inner_field, "field")

            if not field.alias:
                field.alias = field_name
            setattr(new_class, field_name, ExpressionProxy(field, []))
            annotation = new_class.get_annotations().get(field_name)
            if annotation:
                new_class.__annotations__[field_name] = Union[
                    annotation, ExpressionProxy
                ]
            else:
                new_class.__annotations__[field_name] = ExpressionProxy
            # Check if this is our FieldInfo version with extended ORM metadata.
            field_info = None
            if hasattr(field, "field_info") and isinstance(field.field_info, FieldInfo):
                field_info = field.field_info
            elif field_name in attrs and isinstance(
                attrs.__getitem__(field_name), FieldInfo
            ):
                field_info = attrs.__getitem__(field_name)
                field.field_info = field_info

            if field_info is not None:
                if field_info.primary_key:
                    new_class._meta.primary_key = PrimaryKey(
                        name=field_name, field=field
                    )
                if field_info.vector_options:
                    score_attr = f"_{field_name}_score"
                    setattr(new_class, score_attr, None)
                    new_class.__annotations__[score_attr] = Union[float, None]

        # If this is an embedded model, we don't want to allow primary keys at all,
        if getattr(new_class._meta, "embedded", False):
            new_class._meta.primary_key = None

        if not getattr(new_class._meta, "global_key_prefix", None):
            new_class._meta.global_key_prefix = getattr(
                base_meta, "global_key_prefix", ""
            )
        if not getattr(new_class._meta, "model_key_prefix", None):
            # Don't look at the base class for this.
            new_class._meta.model_key_prefix = (
                f"{new_class.__module__}.{new_class.__name__}"
            )
        if not getattr(new_class._meta, "primary_key_pattern", None):
            new_class._meta.primary_key_pattern = getattr(
                base_meta, "primary_key_pattern", "{pk}"
            )
        if not getattr(new_class._meta, "database", None):
            new_class._meta.database = getattr(base_meta, "database", None)
        if not getattr(new_class._meta, "encoding", None):
            new_class._meta.encoding = getattr(base_meta, "encoding")
        if not getattr(new_class._meta, "primary_key_creator_cls", None):
            new_class._meta.primary_key_creator_cls = getattr(
                base_meta, "primary_key_creator_cls", UlidPrimaryKey
            )
        if getattr(new_class._meta, "default_ttl", None) is None:
            new_class._meta.default_ttl = getattr(base_meta, "default_ttl", None)
        new_class._meta.index_health_checked = False
        # TODO: Configurable key separate, defaults to ":"
        if not getattr(new_class._meta, "index_name", None):
            new_class._meta.index_name = (
                f"{new_class._meta.global_key_prefix}:"
                f"{new_class._meta.model_key_prefix}:index"
            )

        # Not an abstract model class or embedded model, so we should let the
        # Migrator create indexes for it.
        if abc.ABC not in bases and not getattr(new_class._meta, "embedded", False):
            key = f"{new_class.__module__}.{new_class.__qualname__}"
            model_registry[key] = new_class

        return new_class


def outer_type_or_annotation(field):
    if hasattr(field, "outer_type_"):
        return field.outer_type_
    elif not hasattr(field.annotation, "__args__"):
        if not isinstance(field.annotation, type):
            raise AttributeError(f"could not extract outer type from field {field}")
        return field.annotation
    elif get_origin(field.annotation) == Literal:
        return str
    else:
        return field.annotation.__args__[0]


class RedisModel(BaseModel, abc.ABC, metaclass=ModelMeta):
    pk: Optional[str] = Field(default=None, primary_key=True)
    if PYDANTIC_V2:
        ConfigDict: ClassVar

    Meta = DefaultMeta

    if PYDANTIC_V2:
        from pydantic import ConfigDict

        # Annotate as ClassVar so pydantic v1's ModelMetaclass does not include
        # this as a model field (which would produce empty schema parts and show
        # up in model repr).
        model_config: ClassVar[dict] = ConfigDict(
            from_attributes=True, arbitrary_types_allowed=True, extra="allow"
        )

        # pydantic.v1.BaseModel (used under the hood) ignores model_config and
        # requires a nested Config class.  Define one so that extra fields are
        # allowed, arbitrary types work, and smart_union avoids silently coercing
        # int/str Union values.
        class Config:
            orm_mode = True
            arbitrary_types_allowed = True
            extra = "allow"
            smart_union = True

    else:

        class Config:
            orm_mode = True
            arbitrary_types_allowed = True
            extra = "allow"
            smart_union = True

    def __init__(__pydantic_self__, **data: Any) -> None:
        __pydantic_self__.validate_primary_key()
        super().__init__(**data)

    def dict(self, *args, **kwargs):
        """Return model data, omitting null ``pk`` on embedded models only."""
        exclude = kwargs.pop("exclude", None)
        if PYDANTIC_V2:
            if exclude is None:
                exclude = {"model_config"}
            elif isinstance(exclude, AbstractSet):
                exclude = set(exclude)
                exclude.add("model_config")
            elif isinstance(exclude, dict):
                exclude = dict(exclude)
                exclude["model_config"] = True
        is_embedded = getattr(self._meta, "embedded", False)
        pk_value = getattr(self, "pk", None)
        if is_embedded and pk_value is None:
            if exclude is None:
                exclude = {"pk"}
            elif isinstance(exclude, AbstractSet):
                exclude = set(exclude)
                exclude.add("pk")
            elif isinstance(exclude, dict):
                exclude = dict(exclude)
                exclude["pk"] = True
        return super().dict(*args, exclude=exclude, **kwargs)

    @classmethod
    @no_type_check
    def _get_value(
        cls,
        v: Any,
        to_dict: bool,
        by_alias: bool,
        include: Any,
        exclude: Any,
        exclude_unset: bool,
        exclude_defaults: bool,
        exclude_none: bool,
    ) -> Any:
        """Override pydantic v1's _get_value to call dict() via the class.

        Pydantic v1 does ``v.dict(…)`` when serialising nested BaseModel
        instances.  If the model has a **field** named ``dict``, attribute
        access resolves to the field value (a plain ``dict`` object) rather
        than the method, raising ``TypeError: 'dict' object is not callable``.

        Calling through the class (``type(v).dict(v, …)``) always reaches
        the method regardless of field names.
        """
        if isinstance(v, BaseModel):
            if to_dict:
                # Use RedisModel.dict or BaseModel.dict directly via __func__
                # to avoid attribute lookup on the instance (which could
                # shadow `dict` if there's a field with that name).
                dict_method = None
                for klass in type(v).__mro__:
                    if "dict" in klass.__dict__:
                        val = klass.__dict__["dict"]
                        if callable(val):
                            dict_method = val
                            break
                if dict_method is None:
                    dict_method = BaseModel.dict
                v_dict = dict_method(
                    v,
                    by_alias=by_alias,
                    exclude_unset=exclude_unset,
                    exclude_defaults=exclude_defaults,
                    include=include,
                    exclude=exclude,
                    exclude_none=exclude_none,
                )
                if "__root__" in v_dict:
                    return v_dict["__root__"]
                return v_dict
            else:
                return v.copy(include=include, exclude=exclude)
        return super()._get_value(
            v,
            to_dict=to_dict,
            by_alias=by_alias,
            include=include,
            exclude=exclude,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=exclude_none,
        )

    def __lt__(self, other):
        """Default sort: compare primary key of models."""
        return self.key() < other.key()

    def key(self):
        """Return the Redis key for this model."""
        if hasattr(self._meta.primary_key.field, "name"):
            pk = getattr(self, self._meta.primary_key.field.name)
        else:
            pk = getattr(self, self._meta.primary_key.name)
        return self.make_primary_key(pk)

    @classmethod
    def _delete(cls, db, *pks):
        return db.delete(*pks)

    @classmethod
    def delete(
        cls, pk: Any, pipeline: Optional[redis.client.Pipeline] = None
    ) -> int:
        """Delete data at this key."""
        db = cls._get_db(pipeline)

        return cls._delete(db, cls.make_primary_key(pk))

    @classmethod
    def get(cls: Type["Model"], pk: Any) -> "Model":
        raise NotImplementedError

    def update(self, **field_values):
        """Update this model instance with the specified key-value pairs."""
        raise NotImplementedError

    def save(
        self: "Model", pipeline: Optional[redis.client.Pipeline] = None
    ) -> "Model":
        raise NotImplementedError

    def expire(
        self, num_seconds: int, pipeline: Optional[redis.client.Pipeline] = None
    ):
        db = self._get_db(pipeline)

        # ClusterPipeline commands must not be awaited; doing so consumes the
        # response instead of queuing the command for batch execution.
        if _is_cluster_pipeline(db):
            db.expire(self.key(), num_seconds)
        else:
            db.expire(self.key(), num_seconds)

    @validator("pk", always=True, allow_reuse=True)
    def validate_pk(cls, v):
        # Skip pk generation for embedded models - they don't need primary keys
        if getattr(cls._meta, "embedded", False):
            return None
        if not v or isinstance(v, ExpressionProxy):
            v = cls._meta.primary_key_creator_cls().create_pk()
        return v

    @classmethod
    def validate_primary_key(cls):
        """Check for a primary key. We need one (and only one)."""
        primary_keys = 0
        for name, field in cls.__fields__.items():
            if not hasattr(field, "field_info"):
                if (
                    not isinstance(field, FieldInfo)
                    and hasattr(field, "metadata")
                    and len(field.metadata) > 0
                    and isinstance(field.metadata[0], FieldInfo)
                ):
                    field_info = field.metadata[0]
                else:
                    field_info = field
            else:
                field_info = field.field_info

            if getattr(field_info, "primary_key", None):
                primary_keys += 1
        if primary_keys == 0:
            raise RedisModelError("You must define a primary key for the model")
        elif primary_keys > 2:
            raise RedisModelError("You must define only one primary key for a model")

    @classmethod
    def make_key(cls, part: str):
        global_prefix = getattr(cls._meta, "global_key_prefix", "").strip(":")
        model_prefix = getattr(cls._meta, "model_key_prefix", "").strip(":")
        return f"{global_prefix}:{model_prefix}:{part}"

    @classmethod
    def make_primary_key(cls, pk: Any):
        """Return the Redis key for this model."""
        return cls.make_key(cls._meta.primary_key_pattern.format(pk=pk))

    @classmethod
    def db(cls):
        # `Meta` is the user-facing configuration surface; `_meta` is the
        # internal copy inherited and normalized by the metaclass.
        database = getattr(cls.Meta, "database", None)
        if database is None:
            database = getattr(cls._meta, "database", None)
        if callable(database):
            database = database()
            cls.Meta.database = database
            cls._meta.database = database
        if database is None:
            database = get_redis_connection()
            cls.Meta.database = database
            cls._meta.database = database
        return database

    @classmethod
    def default_ttl(cls) -> Optional[int]:
        default_ttl = getattr(cls.Meta, "default_ttl", None)
        if default_ttl is None:
            default_ttl = getattr(cls._meta, "default_ttl", None)
        return default_ttl

    @classmethod
    def save_response_count(cls) -> int:
        # save + expire when a default TTL is configured, otherwise save only.
        return 2 if cls.default_ttl() is not None else 1

    def finalize_save(
        self, pipeline: Optional[redis.client.Pipeline] = None
    ) -> None:
        self.apply_default_ttl(pipeline=pipeline)
        # Re-check index health on the next query after writes.
        type(self)._meta.index_health_checked = False

    def apply_default_ttl(
        self, pipeline: Optional[redis.client.Pipeline] = None
    ) -> None:
        default_ttl = self.default_ttl()
        if default_ttl is None:
            return
        self.expire(default_ttl, pipeline=pipeline)

    @staticmethod
    def _normalize_redis_info(value: Any) -> Any:
        if isinstance(value, bytes):
            return value.decode("utf-8", "ignore")
        if isinstance(value, dict):
            return {
                RedisModel._normalize_redis_info(key): RedisModel._normalize_redis_info(
                    dict_value
                )
                for key, dict_value in value.items()
            }
        if isinstance(value, list):
            return [RedisModel._normalize_redis_info(item) for item in value]
        return value

    @classmethod
    def _find_first_nonempty_value(
        cls, *mappings: Mapping[str, Any], keys: Tuple[str, ...]
    ) -> Optional[Any]:
        """Return the first non-empty value found for any key in the mappings."""
        for mapping in mappings:
            if not isinstance(mapping, dict):
                continue
            for key in keys:
                value = mapping.get(key)
                if value not in (None, "", [], {}):
                    return value
        return None

    @staticmethod
    def _stringify_redis_info_value(value: Any) -> str:
        """Convert Redis INFO values into stable strings for warning messages."""
        if isinstance(value, (dict, list)):
            return json.dumps(value, sort_keys=True)
        return str(value)

    @classmethod
    def check_index_health(cls) -> Optional[Dict[str, Any]]:
        try:
            index_info = cls.db().ft(cls.Meta.index_name).info()
        except (AttributeError, redis.ResponseError):
            return None

        info = cls._normalize_redis_info(index_info)
        index_errors = info.get("Index Errors") or info.get("index_errors") or {}
        # RediSearch response shapes vary by version, so we check the common
        # top-level and nested key variants for indexing failures.
        indexing_failures = 0
        for mapping, key in (
            (info, "hash_indexing_failures"),
            (index_errors, "hash_indexing_failures"),
            (index_errors, "indexing failures"),
            (info, "indexing failures"),
        ):
            if isinstance(mapping, dict) and mapping.get(key) is not None:
                indexing_failures = mapping.get(key)
                break

        try:
            indexing_failures = int(indexing_failures)
        except (TypeError, ValueError):
            indexing_failures = 0

        last_indexing_error = cls._find_first_nonempty_value(
            index_errors,
            info,
            keys=(
                "last indexing error",
                "last_indexing_error",
                "last error",
                "last_error",
            ),
        )
        last_indexing_error_key = cls._find_first_nonempty_value(
            index_errors,
            info,
            keys=(
                "last indexing error key",
                "last_indexing_error_key",
                "last error key",
                "last_error_key",
            ),
        )
        health = {
            "index_name": cls.Meta.index_name,
            "indexing_failures": indexing_failures,
            "index_errors": index_errors,
            "last_indexing_error": last_indexing_error,
            "last_indexing_error_key": last_indexing_error_key,
        }
        if indexing_failures:
            detail_parts = []
            if last_indexing_error is not None:
                detail_parts.append(
                    "Last indexing error: "
                    + cls._stringify_redis_info_value(last_indexing_error)
                )
            if last_indexing_error_key is not None:
                detail_parts.append(
                    "Key: " + cls._stringify_redis_info_value(last_indexing_error_key)
                )
            detail_suffix = f" {'; '.join(detail_parts)}." if detail_parts else ""
            log.warning(
                "RediSearch index %s for %s reports %s indexing failures. "
                "Queries may return incomplete results.%sRun FT.INFO %s for details.",
                cls.Meta.index_name,
                cls.__name__,
                indexing_failures,
                detail_suffix,
                cls.Meta.index_name,
            )
        return health

    @classmethod
    def find(
        cls,
        *expressions: Union[Any, Expression],
        knn: Optional[KNNExpression] = None,
    ) -> FindQuery:
        return FindQuery(expressions=expressions, knn=knn, model=cls)

    @classmethod
    def from_redis(cls, res: Any):
        # TODO: Parsing logic copied from redisearch-py. Evaluate.
        def to_string(s):
            if isinstance(s, (str,)):
                return s
            elif isinstance(s, bytes):
                return s.decode(errors="ignore")
            else:
                return s  # Not a string we care about

        docs = []
        step = 2  # Because the result has content
        offset = 1  # The first item is the count of total matches.

        for i in range(1, len(res), step):
            if res[i + offset] is None:
                continue
            fields: Dict[str, str] = dict(
                zip(
                    map(to_string, res[i + offset][::2]),
                    map(to_string, res[i + offset][1::2]),
                )
            )
            # $ means a json entry
            if fields.get("$"):
                json_fields = json.loads(fields.pop("$"))
                model_fields = get_model_fields(cls)
                json_fields = convert_timestamp_to_datetime(json_fields, model_fields)
                json_fields = convert_base64_to_bytes(json_fields, model_fields)
                doc = cls(**json_fields)
                for k, v in fields.items():
                    if k.startswith("__") and k.endswith("_score"):
                        setattr(doc, k[1:], float(v))
                    elif k.endswith("_score") and hasattr(doc, k):
                        setattr(doc, k, float(v))
            else:
                model_fields = get_model_fields(cls)
                fields = convert_empty_strings_to_none(fields, model_fields)
                fields = convert_base64_to_bytes(fields, model_fields)
                doc = cls(**fields)

            docs.append(doc)
        return docs

    @classmethod
    def get_annotations(cls):
        d = {}
        for c in cls.mro():
            try:
                d.update(**c.__annotations__)
            except AttributeError:
                # object, at least, has no __annotations__ attribute.
                pass
        return d

    @classmethod
    def add(
        cls: Type["Model"],
        models: Sequence["Model"],
        pipeline: Optional[redis.client.Pipeline] = None,
        pipeline_verifier: Callable[..., Any] = verify_pipeline_response,
    ) -> Sequence["Model"]:
        db = cls._get_db(pipeline, bulk=True)

        for model in models:
            # save() just returns the model, we don't need that here.
            model.save(pipeline=db)

        # If the user didn't give us a pipeline, then we need to execute
        # the one we just created.
        if pipeline is None:
            result = db.execute()
            pipeline_verifier(
                result, expected_responses=len(models) * cls.save_response_count()
            )

        return models

    @classmethod
    def _get_db(
        self, pipeline: Optional[redis.client.Pipeline] = None, bulk: bool = False
    ):
        if pipeline is not None:
            return pipeline
        elif bulk:
            return self.db().pipeline(transaction=False)
        else:
            return self.db()

    @classmethod
    def delete_many(
        cls,
        models: Sequence["RedisModel"],
        pipeline: Optional[redis.client.Pipeline] = None,
    ) -> int:
        db = cls._get_db(pipeline)

        for chunk in ichunked(models, 100):
            pks = [model.key() for model in chunk]
            cls._delete(db, *pks)

        return len(models)

    @classmethod
    def get_many(
        cls: Type["Model"],
        pks: Sequence[Any],
        pipeline: Optional[redis.client.Pipeline] = None,
    ) -> Sequence["Model"]:
        """Retrieve multiple model instances by primary key using a pipeline.

        This minimises network overhead by fetching all records in a single
        round-trip instead of issuing one request per key.

        Args:
            pks: A sequence of primary key values.
            pipeline: An optional explicit Redis pipeline.  When *None* an
                implicit pipeline is created automatically.

        Returns:
            A list of model instances in the same order as *pks*.  Missing
            keys are silently skipped (no ``NotFoundError`` is raised for
            individual missing keys).
        """
        raise NotImplementedError

    @classmethod
    def redisearch_schema(cls):
        raise NotImplementedError

    def check(self):
        """Run all validations."""
        validate_model_data(self.__class__, self.__dict__)


class HashModel(RedisModel, abc.ABC):
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__()

        if hasattr(cls, "__annotations__"):
            for name, field_type in cls.__annotations__.items():
                origin = get_origin(field_type)
                for typ in (Set, Mapping, List):
                    if isinstance(origin, type) and issubclass(origin, typ):
                        raise RedisModelError(
                            f"HashModels cannot index set, list, "
                            f"or mapping fields. Field: {name}"
                        )
                if isinstance(field_type, type) and issubclass(field_type, RedisModel):
                    raise RedisModelError(
                        f"HashModels cannot index embedded model fields. Field: {name}"
                    )
                elif (
                    isinstance(field_type, type)
                    and dataclasses.is_dataclass(field_type)
                    and not issubclass(field_type, Coordinates)
                ):
                    raise RedisModelError(
                        f"HashModels cannot index dataclass fields. Field: {name}"
                    )

        for name, field in cls.__fields__.items():
            outer_type = outer_type_or_annotation(field)
            origin = get_origin(outer_type)
            if origin:
                for typ in (Set, Mapping, List):
                    if isinstance(origin, type) and issubclass(origin, typ):
                        raise RedisModelError(
                            f"HashModels cannot index set, list, "
                            f"or mapping fields. Field: {name}"
                        )

            if isinstance(outer_type, type) and issubclass(outer_type, RedisModel):
                raise RedisModelError(
                    f"HashModels cannot index embedded model fields. Field: {name}"
                )
            elif (
                isinstance(outer_type, type)
                and dataclasses.is_dataclass(outer_type)
                and not issubclass(outer_type, Coordinates)
            ):
                raise RedisModelError(
                    f"HashModels cannot index dataclass fields. Field: {name}"
                )

    def save(
        self: "Model", pipeline: Optional[redis.client.Pipeline] = None
    ) -> "Model":
        self.check()
        db = self._get_db(pipeline)

        # Get model data and convert datetime objects first
        document = self.dict()
        document = convert_datetime_to_timestamp(document)
        document = convert_bytes_to_base64(document)
        document = convert_dataclasses_to_dicts(document)

        # Then apply jsonable encoding for other types
        document = jsonable_encoder(document)

        # filter out values which are `None` because they are not valid in a HSET
        document = {k: v for k, v in document.items() if v is not None}
        # ClusterPipeline commands must not be awaited; doing so consumes the
        # response instead of queuing the command for batch execution.
        if _is_cluster_pipeline(db):
            db.hset(self.key(), mapping=document)
        else:
            db.hset(self.key(), mapping=document)
        self.finalize_save(pipeline=pipeline)
        return self

    @classmethod
    def all_pks(cls, count: Optional[int] = None):
        key_prefix = cls.make_key(cls._meta.primary_key_pattern.format(pk=""))
        scan_kwargs: Dict[str, Any] = {"_type": "HASH"}
        if count is not None:
            scan_kwargs["count"] = count
        # TODO: We need to decide how we want to handle the lack of
        #  decode_responses=True...
        return (
            (
                remove_prefix(key, key_prefix)
                if isinstance(key, str)
                else remove_prefix(key.decode(cls.Meta.encoding), key_prefix)
            )
            for key in cls.db().scan_iter(f"{key_prefix}*", **scan_kwargs)
        )

    @classmethod
    def get(cls: Type["Model"], pk: Any) -> "Model":
        document = cls.db().hgetall(cls.make_primary_key(pk))
        if not document:
            raise NotFoundError
        # Convert empty strings back to None for Optional fields (fixes #254)
        model_fields = get_model_fields(cls)
        document = convert_empty_strings_to_none(document, model_fields)
        document = convert_base64_to_bytes(document, model_fields)
        try:
            result = cls.parse_obj(document)
        except TypeError as e:
            log.warning(
                f'Could not parse Redis response. Error was: "{e}". Probably, the '
                "connection is not set to decode responses from bytes. "
                "Attempting to decode response using the encoding set on "
                f"model class ({cls.__class__}. Encoding: {cls.Meta.encoding}."
            )
            document = decode_redis_value(document, cls.Meta.encoding)
            document = convert_empty_strings_to_none(document, model_fields)
            document = convert_base64_to_bytes(document, model_fields)
            result = cls.parse_obj(document)
        return result

    @classmethod
    def get_many(
        cls: Type["Model"],
        pks: Sequence[Any],
        pipeline: Optional[redis.client.Pipeline] = None,
    ) -> Sequence["Model"]:
        """Retrieve multiple HashModel instances by primary key using a pipeline."""
        if not pks:
            return []
        keys = [cls.make_primary_key(pk) for pk in pks]
        if pipeline is not None:
            for key in keys:
                pipeline.hgetall(key)
            return []  # caller will execute the pipeline
        db = cls.db().pipeline(transaction=False)
        for key in keys:
            db.hgetall(key)
        results = db.execute()
        model_fields = get_model_fields(cls)
        models = []
        for document in results:
            if not document:
                continue
            document = convert_empty_strings_to_none(document, model_fields)
            document = convert_base64_to_bytes(document, model_fields)
            try:
                models.append(cls.parse_obj(document))
            except TypeError:
                document = decode_redis_value(document, cls.Meta.encoding)
                document = convert_empty_strings_to_none(document, model_fields)
                document = convert_base64_to_bytes(document, model_fields)
                models.append(cls.parse_obj(document))
        return models

    @classmethod
    @no_type_check
    def _get_value(cls, *args, **kwargs) -> Any:
        """
        Always send None as an empty string.

        TODO: We do this because redis-py's hset() method requires non-null
        values. Is there a better way?
        """
        val = super()._get_value(*args, **kwargs)
        if val is None:
            return ""
        return val

    @classmethod
    def redisearch_schema(cls):
        hash_prefix = cls.make_key(cls._meta.primary_key_pattern.format(pk=""))
        schema_prefix = f"ON HASH PREFIX 1 {hash_prefix} SCHEMA"
        schema_parts = [schema_prefix] + cls.schema_for_fields()
        return " ".join(schema_parts)

    def update(self, **field_values):
        validate_model_fields(self.__class__, field_values)
        for field, value in field_values.items():
            setattr(self, field, value)
        self.save()

    @classmethod
    def schema_for_fields(cls):
        schema_parts = []

        for name, field in cls.__fields__.items():
            # TODO: Merge this code with schema_for_type()?
            _type = outer_type_or_annotation(field)
            is_subscripted_type = get_origin(_type)

            if (
                not isinstance(field, FieldInfo)
                and hasattr(field, "metadata")
                and len(field.metadata) > 0
                and isinstance(field.metadata[0], FieldInfo)
            ):
                field = field.metadata[0]

            if not hasattr(field, "field_info"):
                field_info = field
            else:
                field_info = field.field_info

            if getattr(field_info, "primary_key", None):
                if issubclass(_type, str):
                    separator = getattr(
                        field_info, "separator", SINGLE_VALUE_TAG_FIELD_SEPARATOR
                    )
                    redisearch_field = f"{name} TAG SEPARATOR {separator}"
                else:
                    redisearch_field = cls.schema_for_type(name, _type, field_info)
                schema_parts.append(redisearch_field)
            elif getattr(field_info, "index", None) is True:
                schema_parts.append(cls.schema_for_type(name, _type, field_info))
            elif is_subscripted_type:
                # Ignore subscripted types (usually containers!) that we don't
                # support, for the purposes of indexing.
                if not is_supported_container_type(_type):
                    continue

                embedded_cls = get_args(_type)
                if not embedded_cls:
                    # TODO: Test if this can really happen.
                    log.warning("Model %s defined an empty list field: %s", cls, name)
                    continue
                embedded_cls = embedded_cls[0]
                schema_parts.append(cls.schema_for_type(name, embedded_cls, field_info))
            elif issubclass(_type, RedisModel):
                schema_parts.append(cls.schema_for_type(name, _type, field_info))
        return schema_parts

    @classmethod
    def schema_for_type(cls, name, typ: Any, field_info: PydanticFieldInfo):
        # TODO: Import parent logic from JsonModel to deal with lists, so that
        #  a List[int] gets indexed as TAG instead of NUMERICAL.
        # TODO: Abstract string-building logic for each type (TAG, etc.) into
        #  classes that take a field name.
        sortable = getattr(field_info, "sortable", False)
        case_sensitive = getattr(field_info, "case_sensitive", False)

        if is_supported_container_type(typ):
            embedded_cls = get_args(typ)
            if not embedded_cls:
                # TODO: Test if this can really happen.
                log.warning(
                    "Model %s defined an empty list or tuple field: %s", cls, name
                )
                return ""
            embedded_cls = embedded_cls[0]
            if sortable is True:
                raise ValueError(
                    f"Field '{name}' is a container type and cannot be marked as sortable.\
                         Mark individual fields within the embedded model as sortable instead."
                )
            schema = cls.schema_for_type(name, embedded_cls, field_info)
        elif typ is bool:
            schema = f"{name} TAG"
        elif is_numeric_type(typ):
            vector_options: Optional[VectorFieldOptions] = getattr(
                field_info, "vector_options", None
            )
            if vector_options:
                schema = f"{name} {vector_options.schema}"
            else:
                schema = f"{name} NUMERIC"
        elif typ is Coordinates:
            schema = f"{name} GEO"
        elif typ in (datetime.date, datetime.datetime):
            schema = f"{name} NUMERIC"
        elif isinstance(typ, type) and issubclass(typ, str):
            separator = getattr(
                field_info, "separator", SINGLE_VALUE_TAG_FIELD_SEPARATOR
            )
            if getattr(field_info, "full_text_search", False) is True:
                schema = (
                    f"{name} TAG SEPARATOR {separator} " f"{name} AS {name}_fts TEXT"
                )
            else:
                schema = f"{name} TAG SEPARATOR {separator}"
        elif isinstance(typ, type) and issubclass(typ, RedisModel):
            if sortable is True:
                raise ValueError(
                    f"Field '{name}' is an embedded model and cannot be marked as sortable.\
                          Mark individual fields within the embedded model as sortable instead."
                )
            sub_fields = []
            for embedded_name, field in typ.__fields__.items():
                sub_fields.append(
                    cls.schema_for_type(
                        f"{name}_{embedded_name}", field.outer_type_, field.field_info
                    )
                )
            schema = " ".join(sub_fields)
        else:
            separator = getattr(
                field_info, "separator", SINGLE_VALUE_TAG_FIELD_SEPARATOR
            )
            schema = f"{name} TAG SEPARATOR {separator}"
        if schema and sortable is True:
            schema += " SORTABLE"
        if schema and case_sensitive is True:
            schema += " CASESENSITIVE"

        return schema


class JsonModel(RedisModel, abc.ABC):
    @staticmethod
    def _extract_field_info(
        field: Any,
    ) -> Union[FieldInfo, PydanticFieldInfo, ModelField]:
        """
        Extract FieldInfo from a field, handling various Pydantic versions and formats.

        This method consolidates the logic for extracting field info from:
        - Direct FieldInfo instances
        - Fields with field_info attribute
        - Fields with metadata containing FieldInfo
        """
        if hasattr(field, "field_info"):
            return field.field_info
        elif (
            not isinstance(field, FieldInfo)
            and hasattr(field, "metadata")
            and field.metadata
            and isinstance(field.metadata[0], FieldInfo)
        ):
            return field.metadata[0]
        return field

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__()
        # Generate the RediSearch schema once to validate fields.
        cls.redisearch_schema()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def save(
        self: "Model", pipeline: Optional[redis.client.Pipeline] = None
    ) -> "Model":
        self.check()
        db = self._get_db(pipeline)

        # Get model data and convert datetime objects to timestamps
        document = self.dict()
        document = convert_datetime_to_timestamp(document)
        document = convert_bytes_to_base64(document)
        document = convert_dataclasses_to_dicts(document)

        # ClusterPipeline commands must not be awaited; doing so consumes the
        # response instead of queuing the command for batch execution.
        if _is_cluster_pipeline(db):
            db.json().set(self.key(), Path.root_path(), document)
        else:
            db.json().set(self.key(), Path.root_path(), document)
        self.finalize_save(pipeline=pipeline)
        return self

    @classmethod
    def all_pks(cls, count: Optional[int] = None):
        key_prefix = cls.make_key(cls._meta.primary_key_pattern.format(pk=""))
        scan_kwargs: Dict[str, Any] = {"_type": "ReJSON-RL"}
        if count is not None:
            scan_kwargs["count"] = count
        # TODO: We need to decide how we want to handle the lack of
        #  decode_responses=True...
        return (
            (
                remove_prefix(key, key_prefix)
                if isinstance(key, str)
                else remove_prefix(key.decode(cls.Meta.encoding), key_prefix)
            )
            for key in cls.db().scan_iter(f"{key_prefix}*", **scan_kwargs)
        )

    def update(self, **field_values):
        validate_model_fields(self.__class__, field_values)
        for field, value in field_values.items():
            # Handle the simple update case first, e.g. city="Happy Valley"
            if "__" not in field:
                setattr(self, field, value)
                continue

            # Handle the nested update field name case, e.g. address__city="Happy Valley"
            obj = self
            parts = field.split("__")
            path_to_field = parts[:-1]
            target_field = parts[-1]

            # Get the final object in a nested update field name, e.g. for
            # the string address__city, we want to get self.address.city
            for sub_field in path_to_field:
                obj = getattr(obj, sub_field)

            # Set the target field (the last "part" of the nested update
            # field name) to the target value.
            setattr(obj, target_field, value)
        self.save()

    @classmethod
    def get(cls: Type["Model"], pk: Any) -> "Model":
        document_data = cls.db().json().get(cls.make_key(pk))
        if document_data is None:
            raise NotFoundError
        # Convert timestamps back to datetime objects before validation
        model_fields = get_model_fields(cls)
        document_data = convert_timestamp_to_datetime(document_data, model_fields)
        document_data = convert_base64_to_bytes(document_data, model_fields)
        return validate_model_data(cls, document_data)

    @classmethod
    def get_many(
        cls: Type["Model"],
        pks: Sequence[Any],
        pipeline: Optional[redis.client.Pipeline] = None,
    ) -> Sequence["Model"]:
        """Retrieve multiple JsonModel instances by primary key using a pipeline."""
        if not pks:
            return []
        keys = [cls.make_key(pk) for pk in pks]
        if pipeline is not None:
            for key in keys:
                pipeline.json().get(key)
            return []  # caller will execute the pipeline
        db = cls.db().pipeline(transaction=False)
        for key in keys:
            db.json().get(key)
        results = db.execute()
        model_fields = get_model_fields(cls)
        models = []
        for document_data in results:
            if document_data is None:
                continue
            document_data = convert_timestamp_to_datetime(document_data, model_fields)
            document_data = convert_base64_to_bytes(document_data, model_fields)
            models.append(validate_model_data(cls, document_data))
        return models

    @classmethod
    def redisearch_schema(cls):
        key_prefix = cls.make_key(cls._meta.primary_key_pattern.format(pk=""))
        schema_prefix = f"ON JSON PREFIX 1 {key_prefix} SCHEMA"
        schema_parts = [schema_prefix] + cls.schema_for_fields()
        return " ".join(schema_parts)

    @classmethod
    def schema_for_fields(cls):
        schema_parts = []
        json_path = "$"

        # 1. Initialize fields with existing model fields
        fields = dict(cls.__fields__)

        # 2. Sync annotations and FieldInfo
        # Note: Use cls.__annotations__ to avoid the scoping 'field' error
        for name in cls.__annotations__:
            if name in fields:
                field = fields[name]
                # Ensure the FieldInfo has the correct annotation if missing
                if isinstance(field, FieldInfo) and not field.annotation:
                    field.annotation = cls.__annotations__[name]
            else:
                # 3. Handle missing fields (Pydantic v2 vs v1 compatibility)
                try:
                    # In v2, we try to generate FieldInfo from the raw annotation
                    fields[name] = PydanticFieldInfo.from_annotation(
                        cls.__annotations__[name]
                    )
                except (AttributeError, NameError):
                    continue

        # 4. Process the consolidated fields
        for name, field in fields.items():
            _type = get_outer_type(field)
            if _type is None:
                continue

            # Extract FieldInfo safely (handling Annotated and field_info wrappers)
            field_info = cls._extract_field_info(field)

            # 5. Generate Redis Schema parts
            # Call schema_for_type for both primary_key and indexed fields
            # The method handles the distinction internally
            schema_parts.append(
                cls.schema_for_type(json_path, name, "", _type, field_info)
            )

        return schema_parts

    @classmethod
    def schema_for_type(
        cls,
        json_path: str,
        name: str,
        name_prefix: str,
        typ: Any,
        field_info: PydanticFieldInfo,
        parent_type: Optional[Any] = None,
    ) -> str:
        should_index = getattr(field_info, "index", False)
        is_container_type = is_supported_container_type(typ)
        parent_is_container_type = is_supported_container_type(parent_type)
        parent_is_model = False

        if parent_type:
            try:
                parent_is_model = issubclass(parent_type, RedisModel)
            except TypeError:
                pass

        # TODO: We need a better way to know that we're indexing a value
        #  discovered in a model within an array.
        #
        # E.g., say we have a field like `orders: List[Order]`, and we're
        # indexing the "name" field from the Order model (because it's marked
        # index=True in the Order model). The JSONPath for this field is
        # $.orders[*].name, but the "parent" type at this point is Order, not
        # List. For now, we'll discover that Orders are stored in a list by
        # checking if the JSONPath contains the expression for all items in
        # an array.
        parent_is_model_in_container = parent_is_model and json_path.endswith("[*]")

        try:
            field_is_model = issubclass(typ, RedisModel)
        except TypeError:
            # Not a class, probably a type annotation
            field_is_model = False

        vector_options: Optional[VectorFieldOptions] = getattr(
            field_info, "vector_options", None
        )
        try:
            is_vector = vector_options and has_numeric_inner_type(typ)
        except IndexError:
            raise RedisModelError(
                f"Vector field '{name}' must be annotated as a container type"
            )

        # When we encounter a list or model field, we need to descend
        # into the values of the list or the fields of the model to
        # find any values marked as indexed.
        if is_container_type and not is_vector:
            field_type = get_origin(typ)
            if field_type == Literal:
                path = f"{json_path}.{name}"
                return cls.schema_for_type(
                    path,
                    name,
                    name_prefix,
                    str,
                    field_info,
                    parent_type=field_type,
                )
            else:
                embedded_cls = get_args(typ)
                if not embedded_cls:
                    log.warning(
                        "Model %s defined an empty list or tuple field: %s", cls, name
                    )
                    return ""
                path = f"{json_path}.{name}[*]"
                embedded_cls = embedded_cls[0]
                return cls.schema_for_type(
                    path,
                    name,
                    name_prefix,
                    embedded_cls,
                    field_info,
                    parent_type=field_type,
                )
        elif field_is_model:
            name_prefix = f"{name_prefix}_{name}" if name_prefix else name
            sub_fields = []
            for embedded_name, field in typ.__fields__.items():
                if hasattr(field, "field_info"):
                    field_info = field.field_info
                elif (
                    hasattr(field, "metadata")
                    and len(field.metadata) > 0
                    and isinstance(field.metadata[0], FieldInfo)
                ):
                    field_info = field.metadata[0]
                else:
                    field_info = field

                if parent_is_container_type:
                    # We'll store this value either as a JavaScript array, so
                    # the correct JSONPath expression is to refer directly to
                    # attribute names after the container notation, e.g.
                    # orders[*].created_date.
                    path = json_path
                else:
                    # All other fields should use dot notation with both the
                    # current field name and "embedded" field name, e.g.,
                    # order.address.street_line_1.
                    path = f"{json_path}.{name}"
                sub_fields.append(
                    cls.schema_for_type(
                        path,
                        embedded_name,
                        name_prefix,
                        # field.annotation,
                        get_outer_type(field),
                        field_info,
                        parent_type=typ,
                    )
                )
            return " ".join(filter(None, sub_fields))
        # NOTE: This is the termination point for recursion. We've descended
        # into models and lists until we found an actual value to index.
        elif should_index:
            index_field_name = f"{name_prefix}_{name}" if name_prefix else name
            if parent_is_container_type:
                # If we're indexing the this field as a JavaScript array, then
                # the currently built-up JSONPath expression will be
                # "field_name[*]", which is what we want to use.
                path = json_path
            else:
                path = f"{json_path}.{name}"
            sortable = getattr(field_info, "sortable", False)
            case_sensitive = getattr(field_info, "case_sensitive", False)
            full_text_search = getattr(field_info, "full_text_search", False)
            sortable_tag_error = RedisModelError(  # noqa: F841
                "In this Preview release, TAG fields cannot "
                f"be marked as sortable. Problem field: {name}. "
                "See docs: TODO"
            )

            # For more complicated compound validators (e.g. PositiveInt), we might get a _GenericAlias rather than
            # a proper type, we can pull the type information from the origin of the first argument.
            if not isinstance(typ, type):
                # Handle Literal types: resolve to the type of the literal values
                if get_origin(typ) is Literal:
                    type_args = typing_get_args(typ)
                    typ = type(type_args[0]) if type_args else str
                else:
                    type_args = typing_get_args(typ)
                    typ = (
                        getattr(type_args[0], "__origin__", type_args[0])
                        if type_args
                        else typ
                    )

            if is_vector and vector_options:
                schema = f"{path} AS {index_field_name} {vector_options.schema}"
            elif parent_is_container_type or parent_is_model_in_container:
                if typ is not str:
                    raise RedisModelError(
                        "In this Preview release, list and tuple fields can only "
                        f"contain strings. Problem field: {name}. See docs: TODO"
                    )
                if full_text_search is True:
                    raise RedisModelError(
                        "List and tuple fields cannot be indexed for full-text "
                        f"search. Problem field: {name}. See docs: TODO"
                    )
                if sortable is True:
                    raise RedisModelError(
                        "In this Preview release, list and tuple fields cannot be "
                        f"marked as sortable. Problem field: {name}. See docs: TODO"
                    )
                separator = getattr(
                    field_info, "separator", SINGLE_VALUE_TAG_FIELD_SEPARATOR
                )
                schema = f"{path} AS {index_field_name} TAG SEPARATOR {separator}"
                if case_sensitive is True:
                    schema += " CASESENSITIVE"
            elif typ is bool:
                schema = f"{path} AS {index_field_name} TAG"
                if sortable is True:
                    schema += " SORTABLE"
            elif typ is Coordinates:
                schema = f"{path} AS {index_field_name} GEO"
                if sortable is True:
                    schema += " SORTABLE"
            elif is_numeric_type(typ):
                schema = f"{path} AS {index_field_name} NUMERIC"
                if sortable is True:
                    schema += " SORTABLE"
            elif issubclass(typ, str):
                separator = getattr(
                    field_info, "separator", SINGLE_VALUE_TAG_FIELD_SEPARATOR
                )
                if full_text_search is True:
                    schema = (
                        f"{path} AS {index_field_name} TAG SEPARATOR {separator} "
                        f"{path} AS {index_field_name}_fts TEXT"
                    )
                    if sortable is True:
                        # NOTE: With the current preview release, making a field
                        # full-text searchable and sortable only makes the TEXT
                        # field sortable. This means that results for full-text
                        # search queries can be sorted, but not exact match
                        # queries.
                        schema += " SORTABLE"
                    if case_sensitive is True:
                        raise RedisModelError("Text fields cannot be case-sensitive.")
                else:
                    # String fields are indexed as TAG fields and can be sortable
                    schema = f"{path} AS {index_field_name} TAG SEPARATOR {separator}"
                    if sortable is True:
                        schema += " SORTABLE"
                    if case_sensitive is True:
                        schema += " CASESENSITIVE"
            else:
                # Default to TAG field, which can be sortable
                separator = getattr(
                    field_info, "separator", SINGLE_VALUE_TAG_FIELD_SEPARATOR
                )
                schema = f"{path} AS {index_field_name} TAG SEPARATOR {separator}"
                if sortable is True:
                    schema += " SORTABLE"

            return schema
        return ""


class EmbeddedJsonModel(JsonModel, abc.ABC):
    class Meta:
        embedded = True
