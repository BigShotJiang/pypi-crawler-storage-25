import SwiftUI

// MARK: - Menu bar

/// Native menu bar — every command reachable, keyboard shortcuts discoverable.
///
/// Uses the `View`-inside-`Commands` pattern: `@ObservedObject` is unreliable
/// directly in `Commands.body`, so each menu section is a small `View` struct
/// that owns `@ObservedObject var bridgeHandler`. Views inside `CommandMenu` /
/// `CommandGroup` follow normal SwiftUI view lifecycle and observe correctly.
///
/// All actions dispatch through `bridgeHandler.menuAction(_:payload:)` which
/// calls `callAsyncJavaScript` with structured arguments (security rule 3).
///
/// Menu order: Bristlenose · File · Edit · View · Project · Codes · Quotes · Video · Window · Help
///
/// Menu item labels are translated via `I18n` (reads from shared JSON locale files).
/// `CommandMenu` titles stay in English — SwiftUI resolves `LocalizedStringKey`
/// from `.lproj` bundles, not runtime JSON. Matches ATLAS.ti/MAXQDA precedent.
struct MenuCommands: Commands {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var serveManager: ServeManager
    @ObservedObject var projectIndex: ProjectIndex
    @ObservedObject var removalStore: UndoableRemovalStore
    @ObservedObject var i18n: I18n

    var body: some Commands {
        CommandGroup(replacing: .appInfo) {
            AppMenuContent(bridgeHandler: bridgeHandler, serveManager: serveManager, i18n: i18n)
        }

        CommandGroup(replacing: .newItem) {
            FileMenuContent(bridgeHandler: bridgeHandler, i18n: i18n)
        }

        CommandGroup(replacing: .undoRedo) {
            UndoRedoMenuContent(bridgeHandler: bridgeHandler, removalStore: removalStore, i18n: i18n)
        }

        CommandGroup(after: .textEditing) {
            FindMenuContent(bridgeHandler: bridgeHandler, i18n: i18n)
        }

        CommandGroup(replacing: .toolbar) {
            ViewMenuContent(bridgeHandler: bridgeHandler, i18n: i18n)
        }

        // CommandMenu titles stay in English (see doc comment above).
        // Grouped into a child Commands struct to stay under CommandsBuilder's
        // 10-element limit.
        CustomMenus(
            bridgeHandler: bridgeHandler,
            projectIndex: projectIndex,
            i18n: i18n
        )

        // Window > Bristlenose — reopen the main window if the user has closed it
        // but the app process is still alive (Notes / Music / Pages convention).
        // No keyboard shortcut: ⌘0 collides with WKWebView's "reset zoom" and
        // there's no recognisable alternative. Cohort feedback can revisit.
        CommandGroup(before: .windowList) {
            ShowMainWindowMenuContent()
            Divider()
        }

        CommandGroup(replacing: .help) {
            HelpMenuContent(bridgeHandler: bridgeHandler, i18n: i18n)
        }
    }
}

// MARK: - Custom CommandMenus grouped

private struct CustomMenus: Commands {
    let bridgeHandler: BridgeHandler
    let projectIndex: ProjectIndex
    let i18n: I18n

    var body: some Commands {
        CommandMenu("Project") {
            ProjectMenuContent(bridgeHandler: bridgeHandler, projectIndex: projectIndex, i18n: i18n)
        }
        CommandMenu("Codes") {
            CodesMenuContent(bridgeHandler: bridgeHandler, i18n: i18n)
        }
        CommandMenu("Quotes") {
            QuotesMenuContent(bridgeHandler: bridgeHandler, i18n: i18n)
        }
        CommandMenu("Video") {
            VideoMenuContent(bridgeHandler: bridgeHandler, i18n: i18n)
        }
    }
}

// MARK: - Window > Bristlenose

private struct ShowMainWindowMenuContent: View {
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        // Brand name, not a translatable phrase — Notes / Music / Pages all
        // use the app's own name here regardless of system language.
        Button("Bristlenose") {
            openWindow(id: "main")
        }
    }
}

// MARK: - App menu (Bristlenose)

private struct AppMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var serveManager: ServeManager
    @ObservedObject var i18n: I18n

    var body: some View {
        Button(i18n.t("desktop.menu.app.about")) {
            let buildNumber = Bundle.main.infoDictionary?["CFBundleVersion"] as? String
            var options: [NSApplication.AboutPanelOptionKey: Any] = [:]

            if let version = serveManager.serverVersion {
                var versionString = version
                if let build = buildNumber {
                    versionString += " (\(build))"
                }
                options[.applicationVersion] = versionString
            }

            // Stash the BuildInfo block in the standard panel's Credits area
            // so users posting an "About" screenshot already include enough
            // provenance to disambiguate the build.
            let credits = BuildInfo.current.detailed(
                sidecar: serveManager.mode?.shortSummary ?? "?"
            )
            options[.credits] = NSAttributedString(
                string: credits,
                attributes: [
                    .font: NSFont.monospacedSystemFont(ofSize: 10, weight: .regular),
                    .foregroundColor: NSColor.secondaryLabelColor,
                ]
            )

            options[.version] = ""
            NSApp.orderFrontStandardAboutPanel(options: options)
        }

        // Always-visible copyable Build Info diagnostic. Mirrors the footer
        // overlay's content but works in Release / TestFlight too — useful
        // when a user posts a screenshot of the About panel rather than the
        // main window.
        // Sheet is presented by ContentView via .onReceive — attaching .sheet
        // to a menu Button has no host window to present from.
        Button("Build Info…") {
            NotificationCenter.default.post(name: .showBuildInfoSheet, object: nil)
        }

        Divider()

        Button(i18n.t("desktop.menu.app.aiPrivacy")) {
            NotificationCenter.default.post(
                name: .showAIConsentSheet, object: nil)
        }

        Divider()

        Button(i18n.t("desktop.menu.app.checkHealth")) {
            bridgeHandler.menuAction("checkSystemHealth")
        }
    }
}

// MARK: - File menu

private struct FileMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var i18n: I18n

    var body: some View {
        Button(i18n.t("desktop.menu.file.newProject")) {
            NotificationCenter.default.post(name: .createNewProject, object: nil)
        }
        .keyboardShortcut("n", modifiers: .command)

        Button(i18n.t("desktop.menu.file.newFolder")) {
            NotificationCenter.default.post(name: .createNewFolder, object: nil)
        }
        .keyboardShortcut("n", modifiers: [.command, .shift])

        Button(i18n.t("desktop.menu.file.openInNewWindow")) {
            bridgeHandler.menuAction("openInNewWindow")
        }
        .keyboardShortcut("o", modifiers: [.command, .shift])

        Divider()

        Button(i18n.t("desktop.menu.file.exportReport")) {
            bridgeHandler.menuAction("exportReport")
        }
        .keyboardShortcut("e", modifiers: [.command, .shift])

        Button(i18n.t("desktop.menu.file.exportAnonymised")) {
            bridgeHandler.menuAction("exportAnonymised")
        }

        Divider()

        Button(i18n.t("desktop.menu.file.pageSetup")) {
            bridgeHandler.menuAction("pageSetup")
        }

        Button(i18n.t("desktop.menu.file.print")) {
            bridgeHandler.menuAction("print")
        }
        .keyboardShortcut("p", modifiers: .command)
    }
}

// MARK: - Edit > Undo/Redo

private struct UndoRedoMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var removalStore: UndoableRemovalStore
    @ObservedObject var i18n: I18n

    /// Removal-undo takes priority over web-side undo when pending: it's the
    /// most recent action and has a strict 8s window. After commit it falls
    /// back to the previous (web) behaviour.
    private var undoLabel: String {
        if let name = removalStore.pendingName {
            return String(format: i18n.t("desktop.menu.edit.undoRemove"), name)
        }
        return bridgeHandler.undoLabel ?? i18n.t("desktop.menu.edit.undo")
    }

    private var canUndo: Bool {
        removalStore.hasPending || bridgeHandler.canUndo
    }

    var body: some View {
        if !bridgeHandler.isEditing {
            Button(undoLabel) {
                if removalStore.hasPending {
                    removalStore.undoLastRemoval()
                } else {
                    bridgeHandler.menuAction("undo")
                }
            }
            .keyboardShortcut("z", modifiers: .command)
            .disabled(!canUndo)

            Button(i18n.t("desktop.menu.edit.redo")) {
                bridgeHandler.menuAction("redo")
            }
            .keyboardShortcut("z", modifiers: [.command, .shift])
            .disabled(!bridgeHandler.canRedo)
        }
    }
}

// MARK: - Edit > Find

private struct FindMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var i18n: I18n

    var body: some View {
        Divider()

        Button(i18n.t("desktop.menu.edit.find")) {
            bridgeHandler.menuAction("find")
        }
        .keyboardShortcut("f", modifiers: .command)

        Button(i18n.t("desktop.menu.edit.findNext")) {
            let text = NSPasteboard(name: .find).string(forType: .string) ?? ""
            bridgeHandler.menuAction("findNext", payload: ["text": text])
        }
        .keyboardShortcut("g", modifiers: .command)

        Button(i18n.t("desktop.menu.edit.findPrevious")) {
            let text = NSPasteboard(name: .find).string(forType: .string) ?? ""
            bridgeHandler.menuAction("findPrevious", payload: ["text": text])
        }
        .keyboardShortcut("g", modifiers: [.command, .shift])

        Button(i18n.t("desktop.menu.edit.useSelectionForFind")) {
            bridgeHandler.menuAction("useSelectionForFind")
        }
        .keyboardShortcut("e", modifiers: .command)

        Button(i18n.t("desktop.menu.edit.jumpToSelection")) {
            bridgeHandler.menuAction("jumpToSelection")
        }
        .keyboardShortcut("j", modifiers: .command)
    }
}

// MARK: - View menu

private struct ViewMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var i18n: I18n

    /// Locale key suffix for the left-panel label, per tab.
    private var leftPanelKey: String? {
        switch bridgeHandler.activeTab {
        case .quotes:   return "Contents"
        case .codebook: return "Codes"
        case .analysis: return "Signals"
        default:        return nil
        }
    }

    private var hasLeftPanel: Bool {
        leftPanelKey != nil
    }

    var body: some View {
        // Tab shortcuts Cmd+1 through Cmd+5
        ForEach(Array(Tab.allCases.enumerated()), id: \.element.id) { index, tab in
            Button(tab.localizedLabel(i18n)) {
                bridgeHandler.switchToTab(tab)
            }
            .keyboardShortcut(
                KeyEquivalent(Character("\(index + 1)")),
                modifiers: .command
            )
        }

        Divider()

        Button(i18n.t("desktop.menu.view.toggleSidebar")) {
            NSApp.keyWindow?.firstResponder?.tryToPerform(
                #selector(NSSplitViewController.toggleSidebar(_:)),
                with: nil
            )
        }
        .keyboardShortcut("s", modifiers: [.command, .option])

        Button(i18n.t("desktop.menu.view.show\(leftPanelKey ?? "Contents")")) {
            bridgeHandler.menuAction("toggleLeftPanel")
        }
        .keyboardShortcut("l", modifiers: [.command, .option])
        .disabled(!hasLeftPanel)

        Button(i18n.t("desktop.menu.view.showTags")) {
            bridgeHandler.menuAction("toggleRightPanel")
        }
        .keyboardShortcut("t", modifiers: [.command, .option])
        .disabled(bridgeHandler.activeTab != .quotes)

        Button(i18n.t("desktop.menu.view.showHeatmap")) {
            bridgeHandler.menuAction("toggleInspectorPanel")
        }
        .disabled(bridgeHandler.activeTab != .analysis)

        Divider()

        Button(i18n.t("desktop.menu.view.allQuotes")) {
            bridgeHandler.menuAction("allQuotes")
        }
        .disabled(bridgeHandler.activeTab != .quotes)

        Button(i18n.t("desktop.menu.view.starredQuotesOnly")) {
            bridgeHandler.menuAction("starredQuotesOnly")
        }
        .disabled(bridgeHandler.activeTab != .quotes)

        Button(i18n.t("desktop.menu.view.filterByTag")) {
            bridgeHandler.menuAction("filterByTag")
        }
        .disabled(bridgeHandler.activeTab != .quotes)

        Divider()

        Button(i18n.t("desktop.menu.view.zoomIn")) {
            bridgeHandler.menuAction("zoomIn")
        }
        .keyboardShortcut("=", modifiers: .command)

        Button(i18n.t("desktop.menu.view.zoomOut")) {
            bridgeHandler.menuAction("zoomOut")
        }
        .keyboardShortcut("-", modifiers: .command)

        Button(i18n.t("desktop.menu.view.actualSize")) {
            bridgeHandler.menuAction("actualSize")
        }

        Divider()

        Button(bridgeHandler.isDarkMode
               ? i18n.t("desktop.menu.view.switchToLightMode")
               : i18n.t("desktop.menu.view.switchToDarkMode")) {
            bridgeHandler.menuAction("toggleDarkMode")
        }
    }
}

// MARK: - Project menu

private struct ProjectMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var projectIndex: ProjectIndex
    @ObservedObject var i18n: I18n

    /// Whether a folder is selected.
    private var hasFolder: Bool {
        !bridgeHandler.selectedFolderName.isEmpty
    }

    var body: some View {
        if hasFolder {
            // Folder-specific items
            Button(i18n.t("desktop.menu.folder.rename")) {
                NotificationCenter.default.post(name: .renameSelectedFolder, object: nil)
            }

            Button(i18n.t("desktop.menu.folder.archive")) {
                // Phase 5
            }
            .disabled(true)

            Divider()

            Button(i18n.t("desktop.menu.folder.delete"), role: .destructive) {
                NotificationCenter.default.post(name: .deleteSelectedFolder, object: nil)
            }
            .keyboardShortcut(.delete, modifiers: .command)
        } else {
            // Project-specific items (or nothing selected)
            Button(i18n.t("desktop.menu.project.showInFinder")) {
                let path = bridgeHandler.selectedProjectRevealablePath
                if !path.isEmpty {
                    NSWorkspace.shared.selectFile(nil, inFileViewerRootedAtPath: path)
                }
            }
            .keyboardShortcut("r", modifiers: [.command, .shift])
            .disabled(bridgeHandler.selectedProjectRevealablePath.isEmpty)

            Button(i18n.t("desktop.chrome.locate")) {
                NotificationCenter.default.post(name: .locateSelectedProject, object: nil)
            }
            .disabled(bridgeHandler.selectedProjectAvailable)

            Button(i18n.t("desktop.menu.project.rename")) {
                NotificationCenter.default.post(name: .renameSelectedProject, object: nil)
            }
            // Single-selection-only operation; receiver guards on `sole`.
            // `selectedProjectPath.isEmpty` covers both no-selection AND
            // multi-selection (cleared by applySelectionChange's default
            // branch). Indie-consensus: Finder/Notes/Mail/Things disable
            // Rename on multi-select rather than silently no-op.
            .disabled(bridgeHandler.selectedProjectPath.isEmpty)

            // "Move to" submenu — lists all folders + "No Folder" for root.
            // Disabled on no-selection AND multi-selection for the same
            // reason as Rename — receiver guards on `sole`, so submenu
            // children would silently no-op (and that's especially bad in
            // a submenu, where the user has invested two clicks before
            // discovering the dead end).
            if !projectIndex.folders.isEmpty {
                Menu(i18n.t("desktop.menu.project.moveTo")) {
                    Button(i18n.t("desktop.menu.project.noFolder")) {
                        NotificationCenter.default.post(
                            name: .moveSelectedProject, object: nil
                        )
                    }

                    Divider()

                    ForEach(projectIndex.folders) { folder in
                        Button(folder.name) {
                            NotificationCenter.default.post(
                                name: .moveSelectedProject, object: nil,
                                userInfo: ["folderId": folder.id]
                            )
                        }
                    }
                }
                .disabled(bridgeHandler.selectedProjectPath.isEmpty)
            }

            Button(i18n.t("desktop.menu.project.reAnalyse")) {
                bridgeHandler.menuAction("reAnalyse")
            }
            .disabled(true)  // Future — Phase 2+

            Button(i18n.t("desktop.menu.project.archive")) {
                bridgeHandler.menuAction("archive")
            }
            .disabled(true)  // Future — Phase 5

            Divider()

            Button(i18n.t("desktop.menu.project.removeFromSidebar")) {
                NotificationCenter.default.post(
                    name: .removeSelectedProjectsFromSidebar, object: nil
                )
            }
            .keyboardShortcut(.delete, modifiers: .command)
        }
    }
}

// MARK: - Codes menu

private struct CodesMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var i18n: I18n

    private var isCodeTab: Bool {
        bridgeHandler.activeTab == .codebook || bridgeHandler.activeTab == .quotes
    }

    var body: some View {
        Button(i18n.t("desktop.menu.codes.createCodeGroup")) {
            bridgeHandler.menuAction("createCodeGroup")
        }

        Button(i18n.t("desktop.menu.codes.renameCodeGroup")) {
            bridgeHandler.menuAction("renameCodeGroup")
        }
        .disabled(!isCodeTab)

        Button(i18n.t("desktop.menu.codes.deleteCodeGroup")) {
            bridgeHandler.menuAction("deleteCodeGroup")
        }
        .disabled(!isCodeTab)

        Button(i18n.t("desktop.menu.codes.showHideCodeGroup")) {
            bridgeHandler.menuAction("toggleCodeGroup")
        }
        .disabled(!isCodeTab)

        Divider()

        Button(i18n.t("desktop.menu.codes.createCode")) {
            bridgeHandler.menuAction("createCode")
        }

        Button(i18n.t("desktop.menu.codes.renameCode")) {
            bridgeHandler.menuAction("renameCode")
        }
        .disabled(!isCodeTab)

        Button(i18n.t("desktop.menu.codes.deleteCode")) {
            bridgeHandler.menuAction("deleteCode")
        }
        .disabled(!isCodeTab)

        Button(i18n.t("desktop.menu.codes.mergeCodes")) {
            bridgeHandler.menuAction("mergeCode")
        }
        .disabled(!isCodeTab)

        Divider()

        Button(i18n.t("desktop.menu.codes.browseCodebooks")) {
            bridgeHandler.menuAction("browseCodebooks")
        }

        Button(i18n.t("desktop.menu.codes.importFramework")) {
            bridgeHandler.menuAction("importFramework")
        }

        Button(i18n.t("desktop.menu.codes.removeFramework")) {
            bridgeHandler.menuAction("removeFramework")
        }
        .disabled(!isCodeTab)
    }
}

// MARK: - Quotes menu

private struct QuotesMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var i18n: I18n

    private var onQuotesTab: Bool {
        bridgeHandler.activeTab == .quotes
    }

    private var hasFocus: Bool {
        onQuotesTab && bridgeHandler.focusedQuoteId != nil
    }

    private var hasSelection: Bool {
        onQuotesTab && bridgeHandler.selectedQuoteCount > 0
    }

    var body: some View {
        Button(i18n.t("desktop.menu.quotes.star")) {
            bridgeHandler.menuAction("star")
        }
        .disabled(!hasFocus)

        Button(i18n.t("desktop.menu.quotes.hide")) {
            bridgeHandler.menuAction("hide")
        }
        .disabled(!hasFocus)

        Button(i18n.t("desktop.menu.quotes.addTag")) {
            bridgeHandler.menuAction("addTag")
        }
        .disabled(!hasFocus)

        Button(i18n.t("desktop.menu.quotes.applyLastTag")) {
            bridgeHandler.menuAction("applyLastTag")
        }
        .disabled(!hasFocus)

        Button(i18n.t("desktop.menu.quotes.revealInTranscript")) {
            bridgeHandler.menuAction("revealInTranscript")
        }
        .disabled(!hasFocus)

        Button(i18n.t("desktop.menu.quotes.playPause")) {
            bridgeHandler.menuAction("playPause")
        }
        .disabled(!onQuotesTab)

        Divider()

        Button(i18n.t("desktop.menu.quotes.nextQuote")) {
            bridgeHandler.menuAction("nextQuote")
        }
        .disabled(!onQuotesTab)

        Button(i18n.t("desktop.menu.quotes.previousQuote")) {
            bridgeHandler.menuAction("previousQuote")
        }
        .disabled(!onQuotesTab)

        Divider()

        Button(i18n.t("desktop.menu.quotes.extendSelectionDown")) {
            bridgeHandler.menuAction("extendSelectionDown")
        }
        .disabled(!onQuotesTab)

        Button(i18n.t("desktop.menu.quotes.extendSelectionUp")) {
            bridgeHandler.menuAction("extendSelectionUp")
        }
        .disabled(!onQuotesTab)

        Button(i18n.t("desktop.menu.quotes.toggleSelection")) {
            bridgeHandler.menuAction("toggleSelection")
        }
        .disabled(!onQuotesTab)

        Button(i18n.t("desktop.menu.quotes.clearSelection")) {
            bridgeHandler.menuAction("clearSelection")
        }
        .disabled(!hasSelection)

        Divider()

        Button(i18n.t("desktop.menu.quotes.copyAsCSV")) {
            bridgeHandler.menuAction("copyAsCSV")
        }
        .disabled(!hasSelection)
    }
}

// MARK: - Video menu

private struct VideoMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var i18n: I18n

    private var active: Bool { bridgeHandler.hasPlayer }

    var body: some View {
        Button(bridgeHandler.playerPlaying
               ? i18n.t("desktop.menu.video.pause")
               : i18n.t("desktop.menu.video.play")) {
            bridgeHandler.menuAction("playPause")
        }
        .disabled(!active)

        Divider()

        Button(i18n.t("desktop.menu.video.skipForward5")) {
            bridgeHandler.menuAction("skipForward5")
        }
        .disabled(!active)

        Button(i18n.t("desktop.menu.video.skipBack5")) {
            bridgeHandler.menuAction("skipBack5")
        }
        .disabled(!active)

        Button(i18n.t("desktop.menu.video.skipForward30")) {
            bridgeHandler.menuAction("skipForward30")
        }
        .disabled(!active)

        Button(i18n.t("desktop.menu.video.skipBack30")) {
            bridgeHandler.menuAction("skipBack30")
        }
        .disabled(!active)

        Divider()

        Button(i18n.t("desktop.menu.video.speedUp")) {
            bridgeHandler.menuAction("speedUp")
        }
        .disabled(!active)

        Button(i18n.t("desktop.menu.video.slowDown")) {
            bridgeHandler.menuAction("slowDown")
        }
        .disabled(!active)

        Button(i18n.t("desktop.menu.video.normalSpeed")) {
            bridgeHandler.menuAction("normalSpeed")
        }
        .disabled(!active)

        Divider()

        Button(i18n.t("desktop.menu.video.volumeUp")) {
            bridgeHandler.menuAction("volumeUp")
        }
        .disabled(!active)

        Button(i18n.t("desktop.menu.video.volumeDown")) {
            bridgeHandler.menuAction("volumeDown")
        }
        .disabled(!active)

        Button(i18n.t("desktop.menu.video.mute")) {
            bridgeHandler.menuAction("mute")
        }
        .disabled(!active)

        Divider()

        Button(i18n.t("desktop.menu.video.pictureInPicture")) {
            bridgeHandler.menuAction("pictureInPicture")
        }
        .disabled(!active)

        Button(i18n.t("desktop.menu.video.fullscreen")) {
            bridgeHandler.menuAction("fullscreen")
        }
        .disabled(!active)
    }
}

// MARK: - Help menu

private struct HelpMenuContent: View {
    @ObservedObject var bridgeHandler: BridgeHandler
    @ObservedObject var i18n: I18n

    var body: some View {
        Button(i18n.t("desktop.menu.help.bristlenoseHelp")) {
            bridgeHandler.menuAction("showHelp")
        }
        .keyboardShortcut("?", modifiers: .command)

        Button(i18n.t("desktop.menu.help.keyboardShortcuts")) {
            bridgeHandler.menuAction("showKeyboardShortcuts")
        }

        Divider()

        Button(i18n.t("desktop.menu.help.releaseNotes")) {
            bridgeHandler.menuAction("showReleaseNotes")
        }

        Button(i18n.t("desktop.menu.help.sendFeedback")) {
            bridgeHandler.menuAction("sendFeedback")
        }

        Divider()

        Button(i18n.t("desktop.menu.help.blog")) {
            bridgeHandler.menuAction("openBlog")
        }

        Button(i18n.t("desktop.menu.help.acknowledgements")) {
            bridgeHandler.menuAction("showAcknowledgements")
        }
    }
}
