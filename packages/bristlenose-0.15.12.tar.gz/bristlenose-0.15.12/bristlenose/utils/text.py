"""Text cleanup utilities: smart quotes, disfluency removal, editorial helpers."""

from __future__ import annotations

import re
import unicodedata

import inflect

_inflect = inflect.engine()


def count_noun(n: int, singular: str, plural: str | None = None) -> str:
    """Format ``1 session`` / ``2 sessions`` / ``0 sessions`` for CLI output.

    Uses ``inflect`` for irregular plurals (child→children, person→people).
    Pass ``plural`` explicitly only when inflect's default disagrees.

    Note: returns ``"0 sessions"`` for ``n == 0`` (matches existing voice).
    Use ``inflect.engine().no()`` directly if you want ``"no sessions"``.
    """
    plural_form = plural if plural is not None else _inflect.plural_noun(singular)
    word = singular if n == 1 else plural_form
    return f"{n} {word}"

# Maximum length for slugified project names in filenames
_MAX_SLUG_LENGTH = 50


def slugify(text: str, max_length: int = _MAX_SLUG_LENGTH) -> str:
    """Convert text to a URL/filename-safe slug.

    - Lowercase
    - Replace spaces and underscores with hyphens
    - Strip accents (café → cafe)
    - Remove all non-alphanumeric chars except hyphens
    - Collapse multiple hyphens
    - Truncate to max_length (default 50)

    Examples:
        "Rockclimbing" → "rockclimbing"
        "Rock Climbing" → "rock-climbing"
        "My Project (2026)" → "my-project-2026"
        "Client: Acme / Phase 1" → "client-acme-phase-1"
    """
    # Normalise unicode and strip accents
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))

    # Lowercase
    text = text.lower()

    # Replace spaces and underscores with hyphens
    text = re.sub(r"[\s_]+", "-", text)

    # Remove anything that's not alphanumeric or hyphen
    text = re.sub(r"[^a-z0-9-]", "", text)

    # Collapse multiple hyphens
    text = re.sub(r"-+", "-", text)

    # Strip leading/trailing hyphens
    text = text.strip("-")

    # Truncate
    if len(text) > max_length:
        text = text[:max_length].rstrip("-")

    return text


# Characters forbidden in filenames on Windows (NTFS) and macOS (HFS+/APFS).
# Forward/back slashes and null bytes are path separators or terminators.
_UNSAFE_FILENAME_CHARS = re.compile(r'[/\\:\*\?"<>|\x00\r\n]')

# Maximum length for export filenames (leaves room for extension + path prefix)
_MAX_FILENAME_LENGTH = 120


def safe_filename(text: str, max_length: int = _MAX_FILENAME_LENGTH) -> str:
    """Sanitise user-derived text for use as a filename component.

    Unlike ``slugify()``, this preserves spaces, case, and accented characters
    so that exported filenames are human-readable in Finder/Explorer.

    Safety guarantees:
    - No path separators (``/``, ``\\``)
    - No null bytes
    - No Windows-illegal characters (``:``, ``*``, ``?``, ``"``, ``<``, ``>``, ``|``)
    - No ``..`` path traversal sequences
    - No leading/trailing dots or spaces (Windows/macOS gotcha)
    - Truncated to *max_length* (default 120)
    - Returns ``"_"`` if input is empty or reduces to nothing

    Examples:
        "Sarah" → "Sarah"
        "p1 03m45 Sarah onboarding was confusing" → unchanged
        "../../etc/cron.d/evil" → "etccron.devil"
        'He said "delete everything"' → "He said delete everything"
    """
    # Strip path traversal sequences (loop handles reassembly, e.g. "....//")
    while ".." in text:
        text = text.replace("..", "")

    # Remove unsafe characters
    text = _UNSAFE_FILENAME_CHARS.sub("", text)

    # Collapse multiple spaces (from removed chars)
    text = re.sub(r"  +", " ", text)

    # Strip leading/trailing dots and spaces
    text = text.strip(". ")

    # Truncate
    if len(text) > max_length:
        text = text[:max_length].rstrip(". ")

    return text or "_"


def apply_smart_quotes(text: str) -> str:
    """Replace straight double quotes with smart (curly) double quotes.

    Opening: \u201c  Closing: \u201d
    Also handles single quotes: \u2018 \u2019
    """
    # Double quotes
    result = text
    # Opening double quote: after start-of-string, whitespace, or open paren/bracket
    result = re.sub(r'(^|[\s(\[])"', "\\1\u201c", result)
    # Closing double quote: everything else
    result = result.replace('"', "\u201d")

    # Single quotes / apostrophes
    # Apostrophes within words (don't, it's, I'm) — use right single quote
    result = re.sub(r"(\w)'(\w)", "\\1\u2019\\2", result)

    return result


def wrap_in_smart_quotes(text: str) -> str:
    """Wrap text in smart double quotes, stripping any existing outer quotes."""
    from bristlenose.utils.markdown import LQUOTE, RQUOTE

    text = text.strip()
    # Remove existing outer quotes (straight or smart)
    if (text.startswith('"') and text.endswith('"')) or (
        text.startswith(LQUOTE) and text.endswith(RQUOTE)
    ):
        text = text[1:-1].strip()
    return f"{LQUOTE}{text}{RQUOTE}"


# Filler patterns to remove — replaced with ellipsis
_FILLER_WORDS = re.compile(
    r"\b(?:"
    r"um+|uh+|ah+|er+|hmm+|"
    r"you know|"
    r"sort of|kind of|"
    r"I mean"
    r")\b",
    re.IGNORECASE,
)

# "like" when used as filler (not comparison/simile)
# Heuristic: "like" preceded by a comma or start, and followed by a comma or common filler context
_LIKE_FILLER = re.compile(
    r"(?:^|,)\s*like\s*(?:,|\s)", re.IGNORECASE
)


def remove_disfluencies(text: str) -> str:
    """Remove filler words and replace with ellipsis.

    Handles: um, uh, ah, er, hmm, "you know", "sort of", "kind of", "I mean",
    and "like" when used as filler.

    Returns cleaned text with `...` where fillers were removed.
    """
    result = text

    # Remove filler words, replace with ellipsis marker
    result = _FILLER_WORDS.sub("\u2026", result)

    # Handle filler "like" — only when clearly filler, not comparison
    # Replace ", like," and ", like " patterns
    result = re.sub(r",\s*like\s*,", " \u2026", result, flags=re.IGNORECASE)
    result = re.sub(r",\s*like\s+", " \u2026 ", result, flags=re.IGNORECASE)

    # Clean up multiple consecutive ellipses
    result = re.sub(r"(?:\u2026\s*)+", "... ", result)
    result = re.sub(r"\.\.\.\s*\.\.\.", "...", result)

    # Clean up whitespace
    result = re.sub(r"\s{2,}", " ", result)
    result = result.strip()

    # Don't start or end with ellipsis
    result = re.sub(r"^\.\.\.\s*", "", result)
    result = re.sub(r"\s*\.\.\.$", "", result)

    return result


def format_editorial_insertion(word: str) -> str:
    """Format a word as an editorial insertion: [word]."""
    return f"[{word}]"


def format_researcher_context(context: str) -> str:
    """Format researcher context prefix: [When asked about X]."""
    context = context.strip()
    if not context.startswith("["):
        context = f"[{context}]"
    return context


def clean_transcript_text(text: str) -> str:
    """Basic cleanup of raw transcript text.

    - Collapse whitespace
    - Strip leading/trailing whitespace
    - Fix common transcription artefacts
    """
    result = text
    result = re.sub(r"\s+", " ", result)
    result = result.strip()
    # Fix double periods
    result = re.sub(r"\.{2}(?!\.)", ".", result)
    return result
