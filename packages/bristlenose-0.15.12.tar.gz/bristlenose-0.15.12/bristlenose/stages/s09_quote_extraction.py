"""Stage 9: LLM-based verbatim quote extraction with editorial cleanup."""

from __future__ import annotations

import asyncio
import logging

from bristlenose.events import StageFailure, StageOutcome
from bristlenose.llm import telemetry
from bristlenose.llm.boundary import wrap_untrusted
from bristlenose.llm.client import LLMClient
from bristlenose.llm.prompts import get_prompt_template
from bristlenose.llm.structured import QuoteExtractionResult
from bristlenose.models import (
    EmotionalTone,
    ExtractedQuote,
    JourneyStage,
    PiiCleanTranscript,
    QuoteIntent,
    QuoteType,
    Sentiment,
    SessionTopicMap,
    TranscriptSegment,
    format_timecode,
)
from bristlenose.run_lifecycle import _build_cause
from bristlenose.utils.text import apply_smart_quotes
from bristlenose.utils.timecodes import parse_timecode

logger = logging.getLogger(__name__)


_FAIL_THRESHOLD = 3  # Stop stage after this many consecutive LLM failures


def _resolve_segment_index(
    start_timecode: float,
    segments: list[TranscriptSegment],
) -> int:
    """Find the segment ordinal that best matches a quote's start timecode.

    For timecoded transcripts, returns the ``segment_index`` of the last
    segment whose ``start_time`` is at or before the quote start, provided
    the quote falls within the segment's time range (with a small tolerance).

    For non-timecoded transcripts (all ``start_time == 0.0``), returns -1
    because timecode matching is meaningless — sequence detection for these
    sources uses ordinal proximity via the ORM transcript segments.

    See ``docs/design-quote-sequences.md`` for rationale.
    """
    if not segments:
        return -1

    # Non-timecoded transcripts: all segments start at 0.0
    if all(s.start_time == 0.0 for s in segments):
        return -1

    # Binary-ish scan: find last segment whose start_time <= start_timecode
    best_idx = -1
    for i, seg in enumerate(segments):
        if seg.start_time <= start_timecode:
            best_idx = i
        else:
            break

    if best_idx < 0:
        return -1

    # Verify the quote falls within or very close to the segment
    seg = segments[best_idx]
    if start_timecode <= seg.end_time + 5.0:
        return seg.segment_index

    return -1


async def extract_quotes(
    transcripts: list[PiiCleanTranscript],
    topic_maps: list[SessionTopicMap],
    llm_client: LLMClient,
    min_quote_words: int = 5,
    concurrency: int = 1,
    errors: list[str] | None = None,
) -> tuple[list[ExtractedQuote], StageOutcome]:
    """Extract verbatim quotes from all transcripts.

    Args:
        transcripts: PII-cleaned transcripts.
        topic_maps: Topic boundaries for each transcript.
        llm_client: LLM client for analysis.
        min_quote_words: Minimum word count for a quote to be included.
        concurrency: Max concurrent LLM calls (default 1 = sequential).
        errors: Optional list to append error messages to (legacy short-form).

    Returns:
        Tuple of (quotes, outcome). ``outcome`` records per-session
        attempts/successes/failures so the orchestrator can decide whether
        to abandon the run.
    """
    # Build a lookup from session_id to topic map
    topic_map_lookup: dict[str, SessionTopicMap] = {
        tm.session_id: tm for tm in topic_maps
    }

    semaphore = asyncio.Semaphore(concurrency)
    stop = asyncio.Event()
    consecutive_failures = 0
    outcome = StageOutcome(attempted=len(transcripts))

    async def _process(
        transcript: PiiCleanTranscript,
    ) -> list[ExtractedQuote]:
        nonlocal consecutive_failures

        async with semaphore:
            if stop.is_set():
                # Early-stop sessions: not attempted at the LLM layer; record
                # as failures with a synthetic cause so abandon arithmetic
                # (succeeded == 0) reflects the user-visible reality.
                outcome.failed.append(StageFailure(
                    session_id=transcript.session_id,
                    cause=_build_cause(
                        RuntimeError("Skipped after consecutive upstream failures"),
                        stage="quote_extraction",
                        provider=llm_client.provider,
                        session_id=transcript.session_id,
                    ),
                ))
                return []

            logger.info(
                "%s: Extracting quotes",
                transcript.session_id,
            )
            topic_map = topic_map_lookup.get(transcript.session_id)
            try:
                with telemetry.session(transcript.participant_id):
                    quotes = await _extract_single(
                        transcript, topic_map, llm_client, min_quote_words
                    )
                consecutive_failures = 0
                outcome.succeeded += 1
                logger.info(
                    "%s: Extracted %d quotes",
                    transcript.session_id,
                    len(quotes),
                )
                return quotes
            except Exception as exc:
                logger.debug(
                    "%s: Quote extraction failed: %s",
                    transcript.session_id,
                    exc,
                )
                if errors is not None:
                    errors.append(str(exc))
                outcome.failed.append(StageFailure(
                    session_id=transcript.session_id,
                    cause=_build_cause(
                        exc,
                        stage="quote_extraction",
                        provider=llm_client.provider,
                        session_id=transcript.session_id,
                    ),
                ))
                consecutive_failures += 1
                if consecutive_failures >= _FAIL_THRESHOLD:
                    logger.warning(
                        "Stopping quote extraction early — %d consecutive failures",
                        consecutive_failures,
                    )
                    stop.set()
                return []

    results = await asyncio.gather(*(_process(t) for t in transcripts))
    # Flatten per-participant quote lists into a single list
    all_quotes: list[ExtractedQuote] = []
    for quotes in results:
        all_quotes.extend(quotes)
    return all_quotes, outcome


async def _extract_single(
    transcript: PiiCleanTranscript,
    topic_map: SessionTopicMap | None,
    llm_client: LLMClient,
    min_quote_words: int,
) -> list[ExtractedQuote]:
    """Extract quotes from a single transcript."""
    # Format topic boundaries for the prompt
    if topic_map and topic_map.boundaries:
        boundaries_text = "\n".join(
            f"- [{format_timecode(b.timecode_seconds)}] "
            f"{b.topic_label} ({b.transition_type.value})"
            for b in topic_map.boundaries
        )
    else:
        boundaries_text = "(No topic boundaries identified)"

    # Use the full transcript text (both researcher and participant visible
    # so the LLM understands context, but it must only extract participant quotes)
    transcript_text = transcript.full_text()

    _tmpl = get_prompt_template("quote-extraction")

    result = await llm_client.analyze(
        system_prompt=_tmpl.system,
        user_prompt=_tmpl.user.format(
            topic_boundaries=boundaries_text,
            transcript_text=wrap_untrusted("transcript", transcript_text),
        ),
        response_model=QuoteExtractionResult,
        prompt_template=_tmpl,
    )

    # Convert LLM output to our domain models
    quotes: list[ExtractedQuote] = []
    for item in result.quotes:
        # Parse timecodes
        try:
            start_tc = parse_timecode(item.start_timecode)
        except ValueError:
            start_tc = 0.0
        try:
            end_tc = parse_timecode(item.end_timecode)
        except ValueError:
            end_tc = start_tc

        # Resolve segment ordinal (see design-quote-sequences.md)
        seg_idx = _resolve_segment_index(start_tc, transcript.segments)

        # Parse quote type
        try:
            quote_type = QuoteType(item.quote_type)
        except ValueError:
            quote_type = QuoteType.SCREEN_SPECIFIC

        # Parse new sentiment field (v0.7+)
        sentiment: Sentiment | None = None
        if item.sentiment:
            try:
                sentiment = Sentiment(item.sentiment)
            except ValueError:
                sentiment = None
        intensity = max(1, min(3, item.intensity))

        # Parse deprecated fields for backward compatibility
        try:
            intent = QuoteIntent(item.intent)
        except ValueError:
            intent = QuoteIntent.NARRATION
        try:
            emotion = EmotionalTone(item.emotion)
        except ValueError:
            emotion = EmotionalTone.NEUTRAL
        try:
            journey_stage = JourneyStage(item.journey_stage)
        except ValueError:
            journey_stage = JourneyStage.OTHER

        # Skip very short quotes
        word_count = len(item.text.split())
        if word_count < min_quote_words:
            logger.debug(
                "Skipping short quote (%d words): %s",
                word_count,
                item.text[:50],
            )
            continue

        # Apply smart quotes to the text (curly quotes)
        text = apply_smart_quotes(item.text)

        quotes.append(
            ExtractedQuote(
                session_id=transcript.session_id,
                participant_id=transcript.participant_id,
                start_timecode=start_tc,
                end_timecode=end_tc,
                text=text,
                verbatim_excerpt=item.verbatim_excerpt or "",
                topic_label=item.topic_label,
                quote_type=quote_type,
                researcher_context=item.researcher_context,
                sentiment=sentiment,
                intensity=intensity,
                segment_index=seg_idx,
                # Deprecated fields (backward compat)
                intent=intent,
                emotion=emotion,
                journey_stage=journey_stage,
            )
        )

    return quotes
