"""Pipeline manifest — records which stages have completed.

The manifest lives at `<output_dir>/.bristlenose/pipeline-manifest.json`.
It is written after each stage completes so that interrupted runs can
resume from the last completed stage.

On startup, ``run()`` loads an existing manifest and skips stages marked
complete — loading cached intermediate JSON from disk instead of
re-computing.  Stages 1–7 always re-run (fast, no intermediate JSON).
Stages 8–11 are skippable when ``write_intermediate`` was True on the
original run.  Stage 12 (render) always re-runs.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class StageStatus(str, Enum):
    """Status of a single pipeline stage."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETE = "complete"
    PARTIAL = "partial"  # some sessions done, some not
    FAILED = "failed"


class SessionRecord(BaseModel):
    """Completion record for one session within a per-session stage."""

    status: StageStatus
    session_id: str
    completed_at: str | None = None
    provider: str | None = None  # "anthropic", "google", etc.
    model: str | None = None  # "claude-sonnet-4-20250514", etc.
    content_hash: str | None = None  # SHA-256 of the session output file
    # Phase 1f cost extension — additive, defaults to None for back-compat.
    input_tokens: int | None = None
    output_tokens: int | None = None
    cost_usd_estimate: float | None = None
    price_table_version: str | None = None


class StageRecord(BaseModel):
    """Record for one pipeline stage."""

    status: StageStatus = StageStatus.PENDING
    started_at: str | None = None
    completed_at: str | None = None
    error: str | None = None
    sessions: dict[str, SessionRecord] | None = None  # only for per-session stages
    content_hash: str | None = None  # SHA-256 of the stage output file
    input_hashes: dict[str, str] | None = None  # Phase 2c: hashes of stage inputs


class PipelineManifest(BaseModel):
    """Top-level manifest model.

    Persisted to ``pipeline-manifest.json`` in the ``.bristlenose/``
    directory of the output folder.
    """

    schema_version: int = 1
    project_name: str
    pipeline_version: str
    created_at: str
    updated_at: str
    stages: dict[str, StageRecord] = {}
    total_cost_usd: float = 0.0


# ---------------------------------------------------------------------------
# Stage name constants — keep in sync with pipeline.py
# ---------------------------------------------------------------------------

STAGE_INGEST = "ingest"
STAGE_EXTRACT_AUDIO = "extract_audio"
STAGE_TRANSCRIBE = "transcribe"
STAGE_IDENTIFY_SPEAKERS = "identify_speakers"
STAGE_MERGE_TRANSCRIPT = "merge_transcript"
STAGE_PII_REMOVAL = "pii_removal"
STAGE_TOPIC_SEGMENTATION = "topic_segmentation"
STAGE_QUOTE_EXTRACTION = "quote_extraction"
STAGE_CLUSTER_AND_GROUP = "cluster_and_group"
STAGE_RENDER = "render"

# Ordered list for the full `run()` pipeline.
STAGE_ORDER = [
    STAGE_INGEST,
    STAGE_EXTRACT_AUDIO,
    STAGE_TRANSCRIBE,
    STAGE_IDENTIFY_SPEAKERS,
    STAGE_MERGE_TRANSCRIPT,
    STAGE_PII_REMOVAL,
    STAGE_TOPIC_SEGMENTATION,
    STAGE_QUOTE_EXTRACTION,
    STAGE_CLUSTER_AND_GROUP,
    STAGE_RENDER,
]


# ---------------------------------------------------------------------------
# Manifest file name (relative to .bristlenose/)
# ---------------------------------------------------------------------------

MANIFEST_FILENAME = "pipeline-manifest.json"


# ---------------------------------------------------------------------------
# Read / write helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat()


def _manifest_path(output_dir: Path) -> Path:
    return output_dir / ".bristlenose" / MANIFEST_FILENAME


def create_manifest(project_name: str, pipeline_version: str) -> PipelineManifest:
    """Create a fresh manifest with all stages pending."""
    now = _now_iso()
    return PipelineManifest(
        project_name=project_name,
        pipeline_version=pipeline_version,
        created_at=now,
        updated_at=now,
    )


def load_manifest(output_dir: Path) -> PipelineManifest | None:
    """Load the manifest from disk, or return None if it doesn't exist."""
    path = _manifest_path(output_dir)
    if not path.exists():
        return None
    return PipelineManifest.model_validate_json(path.read_text(encoding="utf-8"))


def write_manifest(manifest: PipelineManifest, output_dir: Path) -> None:
    """Write the manifest to disk (atomic: write tmp then rename)."""
    path = _manifest_path(output_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(manifest.model_dump_json(indent=2), encoding="utf-8")
    tmp.rename(path)


def mark_stage_running(manifest: PipelineManifest, stage: str) -> None:
    """Mark a stage as running and update the manifest timestamp."""
    manifest.stages[stage] = StageRecord(
        status=StageStatus.RUNNING,
        started_at=_now_iso(),
    )
    manifest.updated_at = _now_iso()


def _is_content_empty(path: Path | None) -> bool:
    """True iff ``path`` exists and is empty / content-equivalent-to-empty.

    Used by ``mark_stage_complete`` to refuse recording completion when the
    stage produced no usable output. Without this guard, a stage that
    abandoned mid-flight could still stamp the manifest as COMPLETE with a
    valid ``content_hash`` of an empty intermediate JSON file (`b"[]"`),
    and the next run would read `(cached)` and re-render an empty report —
    the cache-poisoning bug A4 closes structurally at the source.

    Returns False when ``path`` is None or absent: nothing to refuse, caller
    proceeds as usual. Non-JSON paths return False unless zero-byte (rare
    for our intermediates; defensive).
    """
    if path is None or not path.exists():
        return False
    if path.stat().st_size == 0:
        return True
    if path.suffix == ".json":
        try:
            parsed = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False  # malformed — let the next layer fail loudly
        # Empty array / empty object / explicit null / whitespace-only string
        if parsed in ([], {}, None):
            return True
        if isinstance(parsed, str) and not parsed.strip():
            return True
    return False


def mark_stage_complete(
    manifest: PipelineManifest,
    stage: str,
    content_hash: str | None = None,
    input_hashes: dict[str, str] | None = None,
    output_path: Path | None = None,
) -> None:
    """Mark a stage as complete and update the manifest timestamp.

    When ``output_path`` is provided and the file is empty (zero-length OR
    content-equivalent-to-empty for JSON: ``[]`` / ``{}`` / ``null``), the
    manifest is **not** mutated — a warning is logged and the next run will
    re-execute the stage. This closes the A4 cache-poisoning bug at the
    source: even if a caller forgets to add an abandon-check, the manifest
    refuses to record completion for empty output.

    Callers should always pass ``output_path`` when the stage writes an
    intermediate file. Legacy callers without the kwarg get the old
    behaviour (always-mark-complete) and are protected by the call-site
    abandon-checks in pipeline.py.
    """
    if _is_content_empty(output_path):
        logger.warning(
            "manifest.refuse_empty_complete stage=%s path=%s — "
            "next run will re-execute this stage",
            stage,
            output_path,
        )
        return
    record = manifest.stages.get(stage, StageRecord())
    record.status = StageStatus.COMPLETE
    record.completed_at = _now_iso()
    if content_hash is not None:
        record.content_hash = content_hash
    if input_hashes is not None:
        record.input_hashes = input_hashes
    manifest.stages[stage] = record
    manifest.updated_at = _now_iso()


def mark_session_complete(
    manifest: PipelineManifest,
    stage: str,
    session_id: str,
    provider: str | None = None,
    model: str | None = None,
    content_hash: str | None = None,
) -> None:
    """Mark a single session as complete within a per-session stage.

    The overall stage status stays RUNNING — call ``mark_stage_complete()``
    after all sessions are done.  If the pipeline crashes before that call,
    the stage is left as RUNNING and ``_is_stage_cached()`` returns False,
    which triggers the per-session resume path on the next run.
    """
    record = manifest.stages.get(stage)
    if record is None:
        record = StageRecord(status=StageStatus.RUNNING, started_at=_now_iso())
        manifest.stages[stage] = record
    if record.sessions is None:
        record.sessions = {}
    record.sessions[session_id] = SessionRecord(
        status=StageStatus.COMPLETE,
        session_id=session_id,
        completed_at=_now_iso(),
        provider=provider,
        model=model,
        content_hash=content_hash,
    )
    manifest.updated_at = _now_iso()


def _derive_stage_status(record: StageRecord) -> StageStatus:
    """Derive overall stage status from session-level records.

    If there are no session records, returns the current status unchanged.
    """
    if record.sessions is None:
        return record.status
    statuses = {s.status for s in record.sessions.values()}
    if all(s == StageStatus.COMPLETE for s in statuses):
        return StageStatus.COMPLETE
    if any(s == StageStatus.COMPLETE for s in statuses):
        return StageStatus.PARTIAL
    return StageStatus.PENDING


def get_completed_session_ids(
    manifest: PipelineManifest | None,
    stage: str,
) -> set[str]:
    """Return session_ids marked complete in a per-session stage."""
    if manifest is None:
        return set()
    record = manifest.stages.get(stage)
    if record is None or record.sessions is None:
        return set()
    return {
        sid
        for sid, sr in record.sessions.items()
        if sr.status == StageStatus.COMPLETE
    }
