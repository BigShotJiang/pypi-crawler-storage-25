"""Pipeline orchestrator: runs all stages in sequence."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from rich.console import Console

# tqdm / huggingface_hub progress-bar suppression lives in
# `bristlenose/__init__.py` (must be set before any HF import, including
# the doctor preflight that runs before pipeline.py is reached).
from bristlenose import __version__
from bristlenose.config import BristlenoseSettings
from bristlenose.events import (
    Cause,
    CauseCategoryEnum,
    PipelineAbandonedError,
    PipelineSummary,
    StageOutcome,
)
from bristlenose.hashing import hash_bytes, hash_file_metadata, verify_file_hash
from bristlenose.llm import telemetry as _llm_telemetry
from bristlenose.manifest import (
    STAGE_CLUSTER_AND_GROUP,
    STAGE_EXTRACT_AUDIO,
    STAGE_IDENTIFY_SPEAKERS,
    STAGE_INGEST,
    STAGE_MERGE_TRANSCRIPT,
    STAGE_PII_REMOVAL,
    STAGE_QUOTE_EXTRACTION,
    STAGE_TOPIC_SEGMENTATION,
    PipelineManifest,
    StageStatus,
    create_manifest,
    get_completed_session_ids,
    load_manifest,
    mark_session_complete,
    mark_stage_complete,
    mark_stage_running,
    write_manifest,
)
from bristlenose.manifest import STAGE_RENDER as _M_STAGE_RENDER
from bristlenose.manifest import STAGE_TRANSCRIBE as _M_STAGE_TRANSCRIBE
from bristlenose.models import (
    ExtractedQuote,
    FileType,
    InputSession,
    PiiCleanTranscript,
    PipelineResult,
    ScreenCluster,
    SessionTopicMap,
    SpeakerRole,
    ThemeGroup,
    TranscriptSegment,
)
from bristlenose.ui_kinds import MessageKind, cli_prefix
from bristlenose.utils.fs import is_os_metadata
from bristlenose.utils.text import count_noun

logger = logging.getLogger(__name__)
console = Console(width=min(80, Console().width))

_MAX_SESSIONS_NO_CONFIRM = 16


def _dominant_cause(
    failures: list,
    *,
    default_category: CauseCategoryEnum,
    message: str,
) -> Cause:
    """Pick the dominant Cause from a list of StageFailures.

    Strategy: most common category wins. If tied, prefer non-retryable —
    those are the ones the user actually needs to act on. Specific
    precedence within non-retryable, in descending action-priority:
    AUTH > MISSING_BINARY > MISSING_DEP > MISSING_INPUT > DISK. Within
    retryable, just pick the first encountered. Falls back to a synthetic
    Cause built from ``default_category`` + ``message`` when ``failures``
    is empty (shouldn't happen on the abandon path, but defensive).
    """
    from collections import Counter

    if not failures:
        return Cause(category=default_category, message=message)

    # Pull the underlying Cause out of each StageFailure.
    causes = [f.cause for f in failures]
    counter = Counter(c.category for c in causes)
    top_count = counter.most_common(1)[0][1]
    contenders = [cat for cat, n in counter.items() if n == top_count]

    if len(contenders) == 1:
        chosen_cat = contenders[0]
    else:
        # Tie — prefer non-retryable in priority order.
        priority = [
            CauseCategoryEnum.AUTH,
            CauseCategoryEnum.MISSING_BINARY,
            CauseCategoryEnum.MISSING_DEP,
            CauseCategoryEnum.MISSING_INPUT,
            CauseCategoryEnum.DISK,
        ]
        chosen_cat = next(
            (p for p in priority if p in contenders),
            contenders[0],
        )

    # Use the first cause matching the chosen category, but stamp the
    # abandon-level message so the terminus event reads cleanly.
    chosen = next(c for c in causes if c.category == chosen_cat)
    return chosen.model_copy(update={"message": message})


# ---------------------------------------------------------------------------
# CLI output helpers
# ---------------------------------------------------------------------------


def _format_duration(seconds: float) -> str:
    """Format seconds as '0.1s' or '3m 41s'."""
    if seconds >= 60:
        m, s = divmod(int(seconds), 60)
        return f"{m}m {s:02d}s"
    return f"{seconds:.1f}s"


def _print_stage(
    message: str,
    kind: MessageKind,
    elapsed: float | None = None,
    *,
    suffix: str = "",
) -> None:
    """Single-source-of-truth CLI step printer.

    Glyph and colour come from :data:`bristlenose.ui_kinds.cli_prefix`. Time
    string trails right-aligned; ``suffix`` (e.g. ``"(cached)"``) replaces
    the time string when ``elapsed`` is ``None``.
    """
    if suffix:
        trailing = f"[dim]{suffix}[/dim]"
    elif elapsed is not None:
        trailing = f"[dim]{_format_duration(elapsed)}[/dim]"
    else:
        trailing = ""
    padding = max(1, 58 - len(message))
    console.print(f" {cli_prefix(kind)} {message}{' ' * padding}{trailing}")


def _print_step(message: str, elapsed: float) -> None:
    """Completed pipeline step (SUCCESS)."""
    _print_stage(message, MessageKind.SUCCESS, elapsed)


def _print_error_step(message: str, elapsed: float) -> None:
    """Failed pipeline step (ERROR)."""
    _print_stage(message, MessageKind.ERROR, elapsed)


def _print_warn_step(message: str, elapsed: float) -> None:
    """Partially-succeeded pipeline step (WARNING)."""
    _print_stage(message, MessageKind.WARNING, elapsed)


def _print_cached_step(message: str) -> None:
    """Cached pipeline step — SUCCESS with ``(cached)`` suffix."""
    _print_stage(message, MessageKind.SUCCESS, suffix="(cached)")


# Sentinel for missing upstream hash — won't match any real SHA-256 digest,
# so downstream stages always re-run when their upstream didn't produce output.
_MISSING_HASH = "MISSING"


def _is_stage_cached(manifest: PipelineManifest | None, stage: str) -> bool:
    """Return True if *stage* is marked complete in an existing manifest."""
    if manifest is None:
        return False
    record = manifest.stages.get(stage)
    return record is not None and record.status == StageStatus.COMPLETE


def _is_stage_verified(
    manifest: PipelineManifest | None,
    stage: str,
    output_paths: list[Path],
    current_input_hashes: dict[str, str] | None = None,
) -> bool:
    """Return True if *stage* is complete AND all output files pass hash check.

    Combines the old ``_is_stage_cached`` status check with Phase 2b
    integrity verification: every file in *output_paths* must exist on
    disk and its SHA-256 must match the hash stored in the manifest.

    Phase 2c adds input change detection: if *current_input_hashes* is
    provided and differs from the stored ``input_hashes``, the stage is
    stale even though its output file is intact.

    Old manifests with ``content_hash=None`` or ``input_hashes=None``
    pass unconditionally (backward compat).

    On hash mismatch the stage is removed from *manifest* so that
    downstream per-session resume logic (``get_completed_session_ids``)
    won't attempt to load data from the corrupt file.
    """
    if not _is_stage_cached(manifest, stage):
        return False
    for p in output_paths:
        if not p.exists():
            return False
    record = manifest.stages[stage]  # type: ignore[union-attr]

    # Phase 2c: input change detection
    if (
        current_input_hashes is not None
        and record.input_hashes is not None
        and record.input_hashes != current_input_hashes
    ):
        logger.info("Stage %s inputs changed — re-running", stage)
        _print_warn(f"{stage}: inputs changed since last run — re-running stage")
        manifest.stages.pop(stage, None)  # type: ignore[union-attr]
        return False

    expected = record.content_hash
    if expected is None:
        return True
    # Multi-file stages (cluster+group) store a combined hash
    mismatch = False
    if len(output_paths) == 1:
        if not verify_file_hash(output_paths[0], expected):
            _print_hash_mismatch(stage, output_paths[0])
            mismatch = True
    else:
        combined = b"".join(p.read_bytes() for p in output_paths)
        if hash_bytes(combined) != expected:
            _print_hash_mismatch(stage, output_paths[0])
            mismatch = True
    if mismatch:
        # Invalidate so per-session resume won't load corrupt data
        manifest.stages.pop(stage, None)  # type: ignore[union-attr]
        return False
    return True


def _is_speaker_stage_verified(
    manifest: PipelineManifest | None,
    stage: str,
    session_files: dict[str, Path],
    current_input_hashes: dict[str, str] | None = None,
) -> bool:
    """Return True if speaker-id stage is complete and per-session hashes match.

    Speaker identification stores per-session content hashes on
    ``SessionRecord.content_hash``.  Each session file is verified
    independently.

    On hash mismatch the stage is removed from *manifest* so that
    downstream per-session resume logic won't load corrupt data.
    """
    if not _is_stage_cached(manifest, stage):
        return False
    for path in session_files.values():
        if not path.exists():
            return False
    record = manifest.stages[stage]  # type: ignore[union-attr]

    # Phase 2c: input change detection
    if (
        current_input_hashes is not None
        and record.input_hashes is not None
        and record.input_hashes != current_input_hashes
    ):
        logger.info("Stage %s inputs changed — re-running", stage)
        _print_warn(f"{stage}: inputs changed since last run — re-running stage")
        manifest.stages.pop(stage, None)  # type: ignore[union-attr]
        return False

    if record.sessions is None:
        return True
    for sid, path in session_files.items():
        sess_rec = record.sessions.get(sid)
        if sess_rec is None:
            continue
        if not verify_file_hash(path, sess_rec.content_hash):
            _print_hash_mismatch(stage, path)
            manifest.stages.pop(stage, None)  # type: ignore[union-attr]
            return False
    return True


def _print_hash_mismatch(stage: str, path: Path) -> None:
    """Log a warning when a cached file fails hash verification."""
    _print_warn(f"{stage}: {path.name} changed on disk — re-running stage")


_printed_warnings: set[str] = set()


def _print_warn(message: str, link: str = "") -> None:
    """Print a warning line below the most recent step (deduplicated)."""
    if message in _printed_warnings:
        return
    _printed_warnings.add(message)
    console.print(f"   {cli_prefix(MessageKind.WARNING)} [dim yellow]{message}[/dim yellow]")
    if link:
        console.print(f"   [dim yellow][link={link}]{link}[/link][/dim yellow]")


_MAX_WARN_LEN = 74  # 80 col - 3 indent - small margin


_BILLING_URLS: dict[str, str] = {
    "anthropic": "https://platform.claude.com/settings/billing",
    "openai": "https://platform.openai.com/settings/organization/billing",
    "azure": "https://portal.azure.com/#view/Microsoft_Azure_Billing",
}


def _short_reason(errors: list[str], provider: str = "") -> tuple[str, str]:
    """Extract a short human-readable reason from the first error message.

    Returns:
        (message, link) — link is a billing URL when applicable, else "".
    """
    if not errors:
        return "", ""
    msg = errors[0]
    link = ""
    # Anthropic API errors embed a JSON 'message' field
    if "'message':" in msg:
        import re
        m = re.search(r"'message':\s*'([^']+)'", msg)
        if m:
            msg = m.group(1)
    # Detect billing issues and provide a direct link
    if "credit balance" in msg.lower() and provider in _BILLING_URLS:
        link = _BILLING_URLS[provider]
        msg = "API credit balance too low"
    if len(msg) > _MAX_WARN_LEN:
        msg = msg[:_MAX_WARN_LEN - 1] + "\u2026"
    return msg, link


def _compute_analysis(
    screen_clusters: list[ScreenCluster],
    theme_groups: list[ThemeGroup],
    all_quotes: list[ExtractedQuote],
    sessions: list[InputSession] | None = None,
) -> object | None:
    """Compute analysis data if quotes have sentiments.

    Returns an AnalysisResult or None if no sentiment data is available.
    Pure computation — no LLM calls.
    """
    if not screen_clusters and not theme_groups:
        return None
    if not any(q.sentiment is not None for q in all_quotes):
        return None

    from bristlenose.analysis.matrix import build_section_matrix, build_theme_matrix
    from bristlenose.analysis.signals import detect_signals

    section_matrix = build_section_matrix(screen_clusters)
    theme_matrix = build_theme_matrix(theme_groups)

    if sessions:
        total_participants = sum(1 for s in sessions if s.participant_id.startswith("p"))
    else:
        total_participants = len({q.participant_id for q in all_quotes if q.participant_id.startswith("p")})

    return detect_signals(
        section_matrix, theme_matrix,
        screen_clusters, theme_groups,
        total_participants,
    )


class Pipeline:
    """Orchestrates the full Bristlenose processing pipeline."""

    def __init__(
        self,
        settings: BristlenoseSettings,
        verbose: bool = False,
        on_event: object | None = None,
        estimator: object | None = None,
        skip_confirm: bool = False,
    ) -> None:
        self.settings = settings
        self.verbose = verbose
        # Callable[[PipelineEvent], None] — typed as object to avoid
        # importing timing at module level (lazy import pattern).
        self._on_event = on_event
        # TimingEstimator — typed as object for the same reason.
        self._estimator = estimator
        self._skip_confirm = skip_confirm

        # Per-stage outcome accumulator. Reset at the top of run / analyze /
        # transcribe-only; populated as each stage finishes; stamped onto
        # PipelineResult.summary at the end. Carried into
        # PipelineAbandonedError on abandon paths so the terminus event
        # includes whatever ran before the failing stage.
        self._summary = PipelineSummary()

        # Logging is configured later (once output_dir is known) via
        # _configure_logging().  Pipeline methods call it at the top of
        # run() / run_analysis_only() / run_transcription_only() /
        # run_render_only() where output_dir is available.
        self._logging_configured = False

    def _configure_logging(self, output_dir: Path) -> None:
        """Set up terminal + log file handlers (idempotent)."""
        if self._logging_configured:
            return
        from bristlenose.logging import setup_logging

        setup_logging(output_dir=output_dir, verbose=self.verbose)
        self._logging_configured = True

    def _emit(self, event: object) -> None:
        """Fire a PipelineEvent to the registered callback (if any)."""
        if self._on_event is not None:
            self._on_event(event)  # type: ignore[operator]

    def _emit_remaining(self, stage: str, elapsed: float) -> None:
        """Emit a revised remaining-time estimate after a stage completes."""
        if self._estimator is None:
            return
        from bristlenose.timing import PipelineEvent

        remaining = self._estimator.stage_completed(stage, elapsed)  # type: ignore[union-attr]
        if remaining is not None:
            self._emit(PipelineEvent(
                kind="remaining", stage=stage, elapsed=elapsed,
                estimate=remaining,
            ))

    def _confirm_large_session_count(self, count: int, source_dir: Path) -> bool:
        """Prompt for confirmation when session count exceeds threshold.

        Returns True to proceed, False to abort.
        """
        from rich.prompt import Confirm

        console.print(
            f"\n[yellow]Found {count_noun(count, 'session')} in {source_dir.name}/.[/yellow]"
        )
        return Confirm.ask("Continue?", default=True)

    async def run(self, input_dir: Path, output_dir: Path) -> PipelineResult:
        """Run the full pipeline: ingest → transcribe → analyse → output.

        Args:
            input_dir: Directory containing input files.
            output_dir: Directory for all output.

        Returns:
            PipelineResult with all data and paths.
        """
        import time
        from collections import Counter

        from bristlenose.llm.client import LLMClient
        from bristlenose.stages.s01_ingest import ingest
        from bristlenose.stages.s02_extract_audio import extract_audio_for_sessions
        from bristlenose.stages.s05b_identify_speakers import (
            SpeakerInfo,
            assign_speaker_codes,
            identify_speaker_roles_heuristic,
            identify_speaker_roles_llm,
            speaker_info_from_dict,
            speaker_info_to_dict,
            split_single_speaker_llm,
        )
        from bristlenose.stages.s06_merge_transcript import (
            merge_transcripts,
            write_raw_transcripts,
            write_raw_transcripts_md,
        )
        from bristlenose.stages.s07_pii_removal import (
            remove_pii,
            write_cooked_transcripts,
            write_cooked_transcripts_md,
            write_pii_summary,
        )
        from bristlenose.stages.s08_topic_segmentation import segment_topics
        from bristlenose.stages.s09_quote_extraction import extract_quotes
        from bristlenose.stages.s10_quote_clustering import cluster_by_screen
        from bristlenose.stages.s11_thematic_grouping import group_by_theme
        from bristlenose.stages.s12_render import render_html
        from bristlenose.stages.s12_render_output import (
            render_markdown,
            write_intermediate_json,
            write_pipeline_metadata,
        )

        pipeline_start = time.perf_counter()
        _printed_warnings.clear()
        # Reset the per-stage summary accumulator at the start of each run.
        self._summary = PipelineSummary()
        output_dir.mkdir(parents=True, exist_ok=True)
        self._configure_logging(output_dir)
        write_pipeline_metadata(output_dir, self.settings.project_name)

        # ── Manifest tracking ────────────────────────────────────
        # Load existing manifest for resume, or create fresh.
        _prev_manifest = load_manifest(output_dir) if output_dir.exists() else None
        manifest = create_manifest(self.settings.project_name, __version__)

        # ── Stage 1: Ingest ──────────────────────────────────────
        # Runs before the spinner — ingest is fast (directory scan) and
        # the session-count guard needs terminal input if triggered.
        mark_stage_running(manifest, STAGE_INGEST)
        t0 = time.perf_counter()
        sessions = ingest(input_dir)
        if not sessions:
            console.print("[red]No supported files found.[/red]")
            return self._empty_result(output_dir)

        ingest_elapsed = time.perf_counter() - t0

        # ── Session-count guard ───────────────────────────────────
        if len(sessions) > _MAX_SESSIONS_NO_CONFIRM and not self._skip_confirm:
            if not self._confirm_large_session_count(len(sessions), input_dir):
                return self._empty_result(output_dir)

        # ── Print found-sessions line, then ingest checkmark ──
        console.print(
            f"  [dim]{count_noun(len(sessions), 'session')} in {input_dir.name}/[/dim]\n",
        )
        type_counts = Counter(
            f.file_type.value for s in sessions for f in s.files
        )
        type_parts = [f"{n} {t}" for t, n in type_counts.most_common()]
        _print_step(
            f"Ingested {count_noun(len(sessions), 'session')} ({', '.join(type_parts)})",
            ingest_elapsed,
        )
        mark_stage_complete(manifest, STAGE_INGEST)
        write_manifest(manifest, output_dir)

        with console.status("", spinner="dots") as status:
            status.renderable.frames = [" " + f for f in status.renderable.frames]

            # ── Time estimate ────────────────────────────────────────
            from bristlenose.timing import (
                STAGE_CLUSTER,
                STAGE_QUOTES,
                STAGE_RENDER,
                STAGE_SPEAKERS,
                STAGE_TOPICS,
                STAGE_TRANSCRIBE,
                PipelineEvent,
                StageActual,
            )

            total_audio_mins = sum(
                (f.duration_seconds or 0) for s in sessions for f in s.files
            ) / 60.0

            _est = None
            if self._estimator is not None:
                _est = self._estimator.initial_estimate(
                    total_audio_mins, len(sessions),
                    skip_transcription=self.settings.skip_transcription,
                )
                if _est is not None:
                    self._emit(PipelineEvent(
                        kind="estimate", estimate=_est,
                    ))

            _stage_actuals: dict[str, StageActual] = {}
            _n_sessions = float(len(sessions))

            # ── Front-loaded preflights ──────────────────────────────
            # All user-interactive prompts (and any native subprocess
            # output — `brew install`, HF Hub progress) fire here, in
            # one block, after ingest and before any further stage
            # runs. The closing "No more questions" line guarantees no
            # later stage will pause to ask anything. See
            # docs/design-cli-just-works.md → "Front-load the entire
            # decision tree".
            _needs_ffmpeg = any(
                f.file_type == FileType.VIDEO and not s.has_existing_transcript
                for s in sessions for f in s.files
            )
            if _needs_ffmpeg:
                from bristlenose.preflight.ffmpeg import preflight_ffmpeg
                preflight_ffmpeg(
                    console=console,
                    status=status,
                    allow_install=not self.settings.no_fetch,
                )

            _needs_whisper = (
                not self.settings.skip_transcription
                and any(not s.has_existing_transcript for s in sessions)
            )
            if _needs_whisper:
                from bristlenose.preflight.whisper import preflight_whisper
                preflight_whisper(
                    settings=self.settings,
                    console=console,
                    status=status,
                    allow_fetch=not self.settings.no_fetch,
                )

            # Closing line — guarantees no further prompt this run.
            from bristlenose.i18n import t as _i18n_t
            _suffix = f" {_est.range_str} to your report." if _est is not None else ""
            _closing = _i18n_t(
                "preflight.closing.no_more_questions",
                estimate_suffix=_suffix,
            )
            console.print()
            console.print("  " + _closing)
            console.print()

            # ── Stage 2: Extract audio from video ────────────────────
            mark_stage_running(manifest, STAGE_EXTRACT_AUDIO)
            status.update("[dim]Extracting audio...[/dim]")
            t0 = time.perf_counter()
            # Temp files go in .bristlenose/temp/
            temp_dir = output_dir / ".bristlenose" / "temp"
            temp_dir.mkdir(parents=True, exist_ok=True)
            sessions = await extract_audio_for_sessions(sessions, temp_dir)
            _print_step(
                f"Extracted audio from {count_noun(len(sessions), 'session')}",
                time.perf_counter() - t0,
            )
            mark_stage_complete(manifest, STAGE_EXTRACT_AUDIO)
            write_manifest(manifest, output_dir)

            # ── Intermediate directory for cached JSON ────────────────
            intermediate = output_dir / ".bristlenose" / "intermediate"

            # ── Stages 3-5: Parse existing transcripts + Transcribe ──
            _ss_path = intermediate / "session_segments.json"
            _source_paths = [f.path for s in sessions for f in s.files]
            _tx_input_hashes = {"source_files": hash_file_metadata(_source_paths)}
            # Outer-scope defaults — both branches below populate these.
            # ``_transcribe_elapsed`` stays None on full-cache-hit (stage
            # didn't run this invocation; ``duration_ms`` reflects only
            # work this run actually did, per the contract).
            _fresh_transcript_outcome = StageOutcome()
            _transcribe_elapsed: float | None = None
            if _is_stage_verified(
                _prev_manifest, _M_STAGE_TRANSCRIBE, [_ss_path],
                current_input_hashes=_tx_input_hashes,
            ):
                import json as _json

                _ss_raw = _json.loads(_ss_path.read_text(encoding="utf-8"))
                session_segments = {
                    sid: [TranscriptSegment.model_validate(s) for s in segs]
                    for sid, segs in _ss_raw.items()
                }
                total_segments = sum(len(s) for s in session_segments.values())
                _print_cached_step(
                    f"Transcribed {count_noun(len(sessions), 'session')}"
                    f" ({count_noun(total_segments, 'segment')})",
                )
            else:
                import json as _json

                # Per-session resume: load cached segments for completed
                # sessions and only transcribe the remaining ones.
                _cached_tx_sids = get_completed_session_ids(
                    _prev_manifest, _M_STAGE_TRANSCRIBE,
                )
                _cached_segments: dict[str, list[TranscriptSegment]] = {}
                if _cached_tx_sids and _ss_path.exists():
                    _ss_raw = _json.loads(
                        _ss_path.read_text(encoding="utf-8"),
                    )
                    _cached_segments = {
                        sid: [
                            TranscriptSegment.model_validate(s) for s in segs
                        ]
                        for sid, segs in _ss_raw.items()
                        if sid in _cached_tx_sids
                    }

                _remaining_sessions = [
                    s for s in sessions
                    if s.session_id not in _cached_tx_sids
                ]

                mark_stage_running(manifest, _M_STAGE_TRANSCRIBE)
                # Carry forward session records from previous manifest
                if _cached_tx_sids and _prev_manifest is not None:
                    _prev_tx_rec = _prev_manifest.stages.get(
                        _M_STAGE_TRANSCRIBE,
                    )
                    if _prev_tx_rec and _prev_tx_rec.sessions:
                        rec_tx = manifest.stages[_M_STAGE_TRANSCRIBE]
                        rec_tx.sessions = {
                            sid: sr
                            for sid, sr in _prev_tx_rec.sessions.items()
                            if sr.status == StageStatus.COMPLETE
                        }

                # Whisper preflight is front-loaded (runs right after
                # ingest), so by the time we hit transcribe stage 5 the
                # model is guaranteed to be cached (or the pipeline
                # already aborted with the banner).

                status.update("[dim]Transcribing...[/dim]")
                t0 = time.perf_counter()

                if _remaining_sessions:
                    def _on_transcribe_progress(
                        current: int, total: int,
                    ) -> None:
                        word = "file" if total == 1 else "files"
                        status.update(
                            f"[dim]Transcribing..."
                            f" ({current}/{total} {word})[/dim]"
                        )

                    _fresh_segments, _fresh_transcript_outcome = (
                        await self._gather_all_segments(
                            _remaining_sessions,
                            on_progress=_on_transcribe_progress,
                        )
                    )
                    for sid in _fresh_segments:
                        mark_session_complete(
                            manifest, _M_STAGE_TRANSCRIBE, sid,
                        )
                else:
                    _fresh_segments = {}
                    _fresh_transcript_outcome = StageOutcome()

                session_segments = {**_cached_segments, **_fresh_segments}

                # Write intermediate JSON for resume
                if self.settings.write_intermediate:
                    intermediate.mkdir(parents=True, exist_ok=True)
                    _ss_data = {
                        sid: [seg.model_dump(mode="json") for seg in segs]
                        for sid, segs in session_segments.items()
                    }
                    _ss_path.write_text(
                        _json.dumps(_ss_data, indent=2), encoding="utf-8",
                    )

                total_segments = sum(
                    len(s) for s in session_segments.values()
                )
                total_audio = sum(
                    f.duration_seconds or 0
                    for s in sessions for f in s.files
                )
                audio_str = (
                    _format_duration(total_audio) if total_audio else ""
                )
                _n_new_tx = len(_remaining_sessions)
                if _cached_segments and _n_new_tx:
                    msg = (
                        f"Transcribed {count_noun(len(sessions), 'session')}"
                        f" ({count_noun(total_segments, 'segment')},"
                        f" {count_noun(_n_new_tx, 'new session')})"
                    )
                else:
                    msg = (
                        f"Transcribed {count_noun(len(sessions), 'session')}"
                        f" ({count_noun(total_segments, 'segment')}"
                    )
                    if audio_str:
                        msg += f", {audio_str} audio"
                    msg += ")"
                _transcribe_elapsed = time.perf_counter() - t0
                _print_step(msg, _transcribe_elapsed)
                _stage_actuals[STAGE_TRANSCRIBE] = StageActual(
                    elapsed=_transcribe_elapsed,
                    input_size=total_audio_mins,
                )
                self._emit_remaining(STAGE_TRANSCRIBE, _transcribe_elapsed)
            _tx_hash = hash_bytes(_ss_path.read_bytes()) if _ss_path.exists() else None
            mark_stage_complete(
                manifest, _M_STAGE_TRANSCRIBE,
                content_hash=_tx_hash,
                input_hashes=_tx_input_hashes,
            )
            write_manifest(manifest, output_dir)

            # ── Transcript outcome rollup + abandon check ──────────────
            # Success semantics: a session is "succeeded" when transcription
            # did NOT record a StageFailure for it. Whisper returning zero
            # segments on legitimate silent input is a success (Pass 3 lock);
            # only a real exception in the transcribe stage routes through
            # `_fresh_transcript_outcome.failed`. The previous predicate
            # `session_segments.get(sid)` was value-truthy and fired the
            # abandon check on every silent recording — false-positive
            # abandons. Drive the predicate off the explicit failure list
            # instead.
            _failed_sids = {
                f.session_id for f in _fresh_transcript_outcome.failed
                if f.session_id is not None
            }
            _succeeded_sids = [
                s.session_id for s in sessions
                if s.session_id not in _failed_sids
            ]
            self._summary.transcripts = StageOutcome(
                attempted=len(sessions),
                succeeded=len(_succeeded_sids),
                failed=list(_fresh_transcript_outcome.failed),
                duration_ms=(
                    int(_transcribe_elapsed * 1000)
                    if _transcribe_elapsed is not None else None
                ),
            )
            if (
                self._summary.transcripts.attempted > 0
                and self._summary.transcripts.succeeded == 0
            ):
                raise PipelineAbandonedError(
                    cause=_dominant_cause(
                        self._summary.transcripts.failed,
                        default_category=CauseCategoryEnum.WHISPER,
                        message="All sessions failed to transcribe.",
                    ),
                    summary=self._summary,
                )

            # ── Cost estimate before LLM stages ──────────────────────
            from bristlenose.llm.pricing import estimate_pipeline_cost

            est = estimate_pipeline_cost(
                self.settings.llm_model, len(sessions),
                run_dir=output_dir / ".bristlenose",
            )
            if est is not None:
                console.print(
                    f"  [dim]Estimated LLM cost: ~${est:.2f}"
                    f" for {count_noun(len(sessions), 'session')}"
                    f" ({self.settings.llm_model})[/dim]\n"
                )

            # ── Stage 5b: Speaker role identification ────────────────
            import json as _json

            _si_dir = intermediate / "speaker-info"
            llm_client: LLMClient | None = None
            concurrency = self.settings.llm_concurrency

            # Check for fully cached speaker ID stage
            _si_session_files = {
                s.session_id: _si_dir / f"{s.session_id}.json"
                for s in sessions
                if s.session_id in session_segments
            }
            _si_input_hashes = {"upstream": _tx_hash or _MISSING_HASH}
            if _is_speaker_stage_verified(
                _prev_manifest, STAGE_IDENTIFY_SPEAKERS, _si_session_files,
                current_input_hashes=_si_input_hashes,
            ):
                # Load all cached speaker info + segments with roles
                all_speaker_infos: dict[str, list] = {}
                for s in sessions:
                    sid = s.session_id
                    if sid not in session_segments:
                        continue
                    _si_data = _json.loads(
                        (_si_dir / f"{sid}.json").read_text(encoding="utf-8")
                    )
                    all_speaker_infos[sid] = [
                        speaker_info_from_dict(d)
                        for d in _si_data["speaker_infos"]
                    ]
                    # Restore segments with speaker roles
                    session_segments[sid] = [
                        TranscriptSegment.model_validate(seg)
                        for seg in _si_data["segments_with_roles"]
                    ]
                _print_cached_step("Identified speakers")
            else:
                # Per-session resume: load cached speaker info for completed
                # sessions and only run LLM on the remaining ones.
                _cached_si_sids = get_completed_session_ids(
                    _prev_manifest, STAGE_IDENTIFY_SPEAKERS,
                )
                all_speaker_infos = {}
                if _cached_si_sids and _si_dir.is_dir():
                    for sid in _cached_si_sids:
                        _si_file = _si_dir / f"{sid}.json"
                        if _si_file.exists():
                            _si_data = _json.loads(
                                _si_file.read_text(encoding="utf-8"),
                            )
                            all_speaker_infos[sid] = [
                                speaker_info_from_dict(d)
                                for d in _si_data["speaker_infos"]
                            ]
                            # Restore segments with speaker roles
                            session_segments[sid] = [
                                TranscriptSegment.model_validate(seg)
                                for seg in _si_data["segments_with_roles"]
                            ]

                _remaining_si_sids = {
                    sid for sid in session_segments
                    if sid not in _cached_si_sids
                }

                mark_stage_running(manifest, STAGE_IDENTIFY_SPEAKERS)
                # Carry forward session records from previous manifest
                if _cached_si_sids and _prev_manifest is not None:
                    _prev_si_rec = _prev_manifest.stages.get(
                        STAGE_IDENTIFY_SPEAKERS,
                    )
                    if _prev_si_rec and _prev_si_rec.sessions:
                        rec_si = manifest.stages[STAGE_IDENTIFY_SPEAKERS]
                        rec_si.sessions = {
                            sid: sr
                            for sid, sr in _prev_si_rec.sessions.items()
                            if sr.status == StageStatus.COMPLETE
                        }

                status.update("[dim]Identifying speakers...[/dim]")
                t0 = time.perf_counter()
                llm_client = LLMClient(self.settings)
                _speaker_errors: list[str] = []

                if _remaining_si_sids:
                    # Split single-speaker transcripts (LLM pre-pass)
                    _split_sids = [
                        sid for sid in _remaining_si_sids
                        if len(set(
                            seg.speaker_label or "Unknown"
                            for seg in session_segments[sid]
                        )) <= 1
                    ]
                    if _split_sids:
                        _sem_split = asyncio.Semaphore(concurrency)

                        async def _split(
                            sid: str,
                            segments: list[TranscriptSegment],
                        ) -> None:
                            async with _sem_split:
                                with _llm_telemetry.session(sid):
                                    await split_single_speaker_llm(
                                        segments, llm_client,
                                        errors=_speaker_errors,
                                    )

                        with _llm_telemetry.stage("s05b_identify_speakers"):
                            await asyncio.gather(*(
                                _split(sid, session_segments[sid])
                                for sid in _split_sids
                            ))

                    # Heuristic pass for remaining sessions
                    for sid in _remaining_si_sids:
                        identify_speaker_roles_heuristic(
                            session_segments[sid],
                        )

                    # LLM refinement concurrently
                    _sem_5b = asyncio.Semaphore(concurrency)

                    async def _identify(
                        sid: str, segments: list[TranscriptSegment],
                    ) -> tuple[str, list]:
                        async with _sem_5b:
                            with _llm_telemetry.session(sid):
                                infos = await identify_speaker_roles_llm(
                                    segments, llm_client,
                                    errors=_speaker_errors,
                                )
                            return sid, infos

                    with _llm_telemetry.stage("s05b_identify_speakers"):
                        _results_5b = await asyncio.gather(*(
                            _identify(sid, session_segments[sid])
                            for sid in _remaining_si_sids
                    ))
                    for sid, infos in _results_5b:
                        all_speaker_infos[sid] = infos
                        mark_session_complete(
                            manifest, STAGE_IDENTIFY_SPEAKERS, sid,
                            provider=self.settings.llm_provider,
                            model=self.settings.llm_model,
                        )

                    # Write speaker info cache for fresh sessions
                    if self.settings.write_intermediate:
                        _si_dir.mkdir(parents=True, exist_ok=True)
                        for sid in _remaining_si_sids:
                            _si_data = {
                                "speaker_infos": [
                                    speaker_info_to_dict(info)
                                    for info in all_speaker_infos.get(sid, [])
                                ],
                                "segments_with_roles": [
                                    seg.model_dump(mode="json")
                                    for seg in session_segments[sid]
                                ],
                            }
                            _si_bytes = _json.dumps(
                                _si_data, indent=2,
                            ).encode("utf-8")
                            (_si_dir / f"{sid}.json").write_bytes(_si_bytes)
                            # Update session record with content hash
                            _si_rec = manifest.stages.get(
                                STAGE_IDENTIFY_SPEAKERS,
                            )
                            if (
                                _si_rec
                                and _si_rec.sessions
                                and sid in _si_rec.sessions
                            ):
                                _si_rec.sessions[sid].content_hash = (
                                    hash_bytes(_si_bytes)
                                )

                _speakers_elapsed = time.perf_counter() - t0
                _n_new_si = len(_remaining_si_sids)
                if _cached_si_sids and _n_new_si:
                    _print_step(
                        f"Identified speakers ({_n_new_si} new sessions)",
                        _speakers_elapsed,
                    )
                else:
                    _print_step("Identified speakers", _speakers_elapsed)
                _stage_actuals[STAGE_SPEAKERS] = StageActual(
                    elapsed=_speakers_elapsed, input_size=_n_sessions,
                )
                self._emit_remaining(STAGE_SPEAKERS, _speakers_elapsed)
                if _speaker_errors:
                    _print_warn(
                        *_short_reason(
                            _speaker_errors, self.settings.llm_provider,
                        )
                    )

            # assign_speaker_codes() always re-runs — global numbering
            all_label_code_maps: dict[str, dict[str, str]] = {}
            next_pnum = 1
            for session in sessions:
                sid = session.session_id
                segments = session_segments.get(sid, [])
                if not segments:
                    continue
                label_map, next_pnum = assign_speaker_codes(
                    next_pnum, segments,
                )
                all_label_code_maps[sid] = label_map
                # Update session's participant_id from assigned codes
                p_codes = [
                    c for c in label_map.values() if c.startswith("p")
                ]
                if p_codes:
                    session.participant_id = p_codes[0]
                    session.participant_number = int(p_codes[0][1:])

            mark_stage_complete(
                manifest, STAGE_IDENTIFY_SPEAKERS,
                input_hashes=_si_input_hashes,
            )
            write_manifest(manifest, output_dir)

            # ── Stage 6: Merge and write raw transcripts ─────────────
            mark_stage_running(manifest, STAGE_MERGE_TRANSCRIPT)
            status.update("[dim]Merging transcripts...[/dim]")
            t0 = time.perf_counter()
            transcripts = merge_transcripts(sessions, session_segments, input_dir)
            raw_dir = output_dir / "transcripts-raw"
            write_raw_transcripts(transcripts, raw_dir)
            write_raw_transcripts_md(transcripts, raw_dir)
            _print_step("Merged transcripts", time.perf_counter() - t0)
            mark_stage_complete(manifest, STAGE_MERGE_TRANSCRIPT)
            write_manifest(manifest, output_dir)

            # ── Stage 7: PII removal ────────────────────────────────
            if self.settings.pii_enabled:
                mark_stage_running(manifest, STAGE_PII_REMOVAL)
                status.update("[dim]Removing PII...[/dim]")
                t0 = time.perf_counter()
                clean_transcripts, pii_redactions = remove_pii(
                    transcripts, self.settings,
                )
                cooked_dir = output_dir / "transcripts-cooked"
                write_cooked_transcripts(clean_transcripts, cooked_dir)
                write_cooked_transcripts_md(clean_transcripts, cooked_dir)
                write_pii_summary(pii_redactions, output_dir)
                _print_step(
                    f"Redacted PII ({len(pii_redactions)} entities)",
                    time.perf_counter() - t0,
                )
                mark_stage_complete(manifest, STAGE_PII_REMOVAL)
                write_manifest(manifest, output_dir)
            else:
                # Pass through without PII removal
                clean_transcripts = [
                    PiiCleanTranscript(
                        session_id=t.session_id,
                        participant_id=t.participant_id,
                        source_file=t.source_file,
                        session_date=t.session_date,
                        duration_seconds=t.duration_seconds,
                        segments=t.segments,
                    )
                    for t in transcripts
                ]

            # ── Stage 8: Topic segmentation ──────────────────────────
            _seg_errors: list[str] = []
            _tb_path = intermediate / "topic_boundaries.json"
            # Outer-scope defaults — both branches below populate. Cache-hit
            # branch treats every cached topic-map as attempted+succeeded;
            # per-session branch only counts truly cached items here, and
            # combines with `_seg_outcome` from the fresh call below.
            _seg_outcome = StageOutcome()
            _cached_topic_count = 0
            _topics_elapsed: float | None = None
            # Track both upstream transcript hash and PII config — toggling
            # --redact-pii changes the transcript content that topics see.
            _topic_input_hashes = {
                "upstream": _tx_hash or _MISSING_HASH,
                "pii_enabled": str(self.settings.pii_enabled),
            }
            if _is_stage_verified(
                _prev_manifest, STAGE_TOPIC_SEGMENTATION, [_tb_path],
                current_input_hashes=_topic_input_hashes,
            ):
                import json as _json

                topic_maps = [
                    SessionTopicMap.model_validate(obj)
                    for obj in _json.loads(_tb_path.read_text(encoding="utf-8"))
                ]
                total_boundaries = sum(len(m.boundaries) for m in topic_maps)
                _cached_topic_count = len(topic_maps)
                _print_cached_step(
                    f"Segmented {count_noun(total_boundaries, 'topic boundary')}",
                )
            else:
                # Per-session resume: load cached topic maps for completed
                # sessions and only run LLM on the remaining ones.
                import json as _json

                _cached_topic_sids = get_completed_session_ids(
                    _prev_manifest, STAGE_TOPIC_SEGMENTATION,
                )
                _cached_topic_maps: list[SessionTopicMap] = []
                if _cached_topic_sids and _tb_path.exists():
                    _cached_topic_maps = [
                        SessionTopicMap.model_validate(obj)
                        for obj in _json.loads(
                            _tb_path.read_text(encoding="utf-8")
                        )
                        if obj.get("session_id") in _cached_topic_sids
                    ]

                _cached_topic_count = len(_cached_topic_maps)
                _remaining_transcripts = [
                    t for t in clean_transcripts
                    if t.session_id not in _cached_topic_sids
                ]

                mark_stage_running(manifest, STAGE_TOPIC_SEGMENTATION)
                # Carry forward session records from previous manifest
                if _cached_topic_sids and _prev_manifest is not None:
                    _prev_rec = _prev_manifest.stages.get(
                        STAGE_TOPIC_SEGMENTATION,
                    )
                    if _prev_rec and _prev_rec.sessions:
                        rec = manifest.stages[STAGE_TOPIC_SEGMENTATION]
                        rec.sessions = {
                            sid: sr
                            for sid, sr in _prev_rec.sessions.items()
                            if sr.status == StageStatus.COMPLETE
                        }

                status.update("[dim]Segmenting topics...[/dim]")
                t0 = time.perf_counter()
                if _remaining_transcripts:
                    if llm_client is None:
                        llm_client = LLMClient(self.settings)
                    with _llm_telemetry.stage("s08_topic_segmentation"):
                        _fresh_topic_maps, _seg_outcome = await segment_topics(
                            _remaining_transcripts, llm_client,
                            concurrency=concurrency, errors=_seg_errors,
                        )
                    # Record per-session completion only for sessions whose
                    # boundaries were actually produced (skip-after-failure
                    # entries return an empty SessionTopicMap that is NOT a
                    # success, and per-session manifest marking must not
                    # claim otherwise).
                    _seg_failed_sids = {
                        f.session_id for f in _seg_outcome.failed
                        if f.session_id is not None
                    }
                    for tm in _fresh_topic_maps:
                        if tm.session_id in _seg_failed_sids:
                            continue
                        mark_session_complete(
                            manifest, STAGE_TOPIC_SEGMENTATION,
                            tm.session_id,
                            provider=self.settings.llm_provider,
                            model=self.settings.llm_model,
                        )
                else:
                    _fresh_topic_maps = []

                topic_maps = _cached_topic_maps + _fresh_topic_maps

                if self.settings.write_intermediate:
                    write_intermediate_json(
                        topic_maps, "topic_boundaries.json", output_dir,
                        self.settings.project_name,
                    )
                total_boundaries = sum(len(m.boundaries) for m in topic_maps)
                _topics_elapsed = time.perf_counter() - t0

                _n_new = len(_remaining_transcripts)
                if _cached_topic_maps and _n_new:
                    _msg_8 = (
                        f"Segmented {count_noun(total_boundaries, 'topic boundary')}"
                        f" ({count_noun(_n_new, 'new session')})"
                    )
                else:
                    _msg_8 = f"Segmented {count_noun(total_boundaries, 'topic boundary')}"
                if _seg_errors and total_boundaries == 0:
                    _print_error_step(_msg_8, _topics_elapsed)
                elif _seg_errors:
                    _print_warn_step(_msg_8, _topics_elapsed)
                else:
                    _print_step(_msg_8, _topics_elapsed)

                _stage_actuals[STAGE_TOPICS] = StageActual(
                    elapsed=_topics_elapsed, input_size=_n_sessions,
                )
                self._emit_remaining(STAGE_TOPICS, _topics_elapsed)
                if _seg_errors:
                    _print_warn(*_short_reason(_seg_errors, self.settings.llm_provider))

            # ── Topic outcome rollup + abandon check ────────────────────
            # MUST run BEFORE mark_stage_complete: writing the manifest
            # before raising would poison the cache (empty
            # topic_boundaries.json reads back as "stage already done") and
            # downstream stages run on zero topic data, producing an empty
            # report on every subsequent run.
            self._summary.topics = StageOutcome(
                attempted=_cached_topic_count + _seg_outcome.attempted,
                succeeded=_cached_topic_count + _seg_outcome.succeeded,
                failed=list(_seg_outcome.failed),
                duration_ms=(
                    int(_topics_elapsed * 1000)
                    if _topics_elapsed is not None else None
                ),
            )
            if (
                self._summary.topics.attempted > 0
                and self._summary.topics.succeeded == 0
            ):
                raise PipelineAbandonedError(
                    cause=_dominant_cause(
                        self._summary.topics.failed,
                        default_category=CauseCategoryEnum.UNKNOWN,
                        message="All topic segmentation calls failed.",
                    ),
                    summary=self._summary,
                )

            _tb_hash = (
                hash_bytes(_tb_path.read_bytes()) if _tb_path.exists() else None
            )
            mark_stage_complete(
                manifest, STAGE_TOPIC_SEGMENTATION,
                content_hash=_tb_hash,
                input_hashes=_topic_input_hashes,
                output_path=_tb_path,
            )
            write_manifest(manifest, output_dir)

            # ── Stage 9: Quote extraction ────────────────────────────
            _quote_errors: list[str] = []
            _eq_path = intermediate / "extracted_quotes.json"
            _qe_input_hashes = {"upstream": _tb_hash or _MISSING_HASH}
            # Outer-scope defaults — both branches below populate these.
            # `_cached_q_count` carries the number of quotes that came from
            # cache (full-cache-hit branch loads all; per-session branch
            # may load some). The rollup below treats cached items as
            # successes so cache-hit runs report attempted == succeeded.
            _fresh_quote_outcome = StageOutcome()
            _cached_q_count = 0
            _quotes_elapsed: float | None = None
            if _is_stage_verified(
                _prev_manifest, STAGE_QUOTE_EXTRACTION, [_eq_path],
                current_input_hashes=_qe_input_hashes,
            ):
                import json as _json

                all_quotes = [
                    ExtractedQuote.model_validate(obj)
                    for obj in _json.loads(_eq_path.read_text(encoding="utf-8"))
                ]
                # Full cache hit: every quote was loaded from disk. Count
                # them as both attempted and succeeded so the rollup tells
                # the truth ("all cached, all good") instead of "0/0".
                _cached_q_count = len(all_quotes)
                _print_cached_step(f"Extracted {count_noun(len(all_quotes), 'quote')}")
            else:
                # Per-session resume: load cached quotes for completed
                # sessions and only run LLM on the remaining ones.
                import json as _json

                _cached_quote_sids = get_completed_session_ids(
                    _prev_manifest, STAGE_QUOTE_EXTRACTION,
                )
                _cached_q_count = len(_cached_quote_sids)
                _cached_quotes: list[ExtractedQuote] = []
                if _cached_quote_sids and _eq_path.exists():
                    _cached_quotes = [
                        ExtractedQuote.model_validate(obj)
                        for obj in _json.loads(
                            _eq_path.read_text(encoding="utf-8")
                        )
                        if obj.get("session_id") in _cached_quote_sids
                    ]

                _remaining_transcripts_q = [
                    t for t in clean_transcripts
                    if t.session_id not in _cached_quote_sids
                ]
                _remaining_topic_maps = [
                    tm for tm in topic_maps
                    if tm.session_id not in _cached_quote_sids
                ]

                mark_stage_running(manifest, STAGE_QUOTE_EXTRACTION)
                # Carry forward session records from previous manifest
                if _cached_quote_sids and _prev_manifest is not None:
                    _prev_rec_q = _prev_manifest.stages.get(
                        STAGE_QUOTE_EXTRACTION,
                    )
                    if _prev_rec_q and _prev_rec_q.sessions:
                        rec_q = manifest.stages[STAGE_QUOTE_EXTRACTION]
                        rec_q.sessions = {
                            sid: sr
                            for sid, sr in _prev_rec_q.sessions.items()
                            if sr.status == StageStatus.COMPLETE
                        }

                status.update("[dim]Extracting quotes...[/dim]")
                t0 = time.perf_counter()

                if _remaining_transcripts_q:
                    if llm_client is None:
                        llm_client = LLMClient(self.settings)
                    with _llm_telemetry.stage("s09_quote_extraction"):
                        _fresh_quotes, _fresh_quote_outcome = await extract_quotes(
                            _remaining_transcripts_q,
                            _remaining_topic_maps,
                            llm_client,
                            min_quote_words=self.settings.min_quote_words,
                            concurrency=concurrency,
                            errors=_quote_errors,
                        )
                    # Record per-session completion — derive session_ids
                    # from the transcripts that were processed.
                    for t in _remaining_transcripts_q:
                        mark_session_complete(
                            manifest, STAGE_QUOTE_EXTRACTION,
                            t.session_id,
                            provider=self.settings.llm_provider,
                            model=self.settings.llm_model,
                        )
                else:
                    _fresh_quotes = []

                all_quotes = _cached_quotes + _fresh_quotes

                if self.settings.write_intermediate:
                    write_intermediate_json(
                        all_quotes, "extracted_quotes.json", output_dir,
                        self.settings.project_name,
                    )
                _quotes_elapsed = time.perf_counter() - t0

                _n_new_q = len(_remaining_transcripts_q)
                if _cached_quotes and _n_new_q:
                    _msg_9 = (
                        f"Extracted {count_noun(len(all_quotes), 'quote')}"
                        f" ({count_noun(_n_new_q, 'new session')})"
                    )
                else:
                    _msg_9 = f"Extracted {count_noun(len(all_quotes), 'quote')}"
                if _quote_errors and len(all_quotes) == 0:
                    _print_error_step(_msg_9, _quotes_elapsed)
                elif _quote_errors:
                    _print_warn_step(_msg_9, _quotes_elapsed)
                else:
                    _print_step(_msg_9, _quotes_elapsed)

                _stage_actuals[STAGE_QUOTES] = StageActual(
                    elapsed=_quotes_elapsed, input_size=_n_sessions,
                )
                self._emit_remaining(STAGE_QUOTES, _quotes_elapsed)
                if _quote_errors:
                    _print_warn(*_short_reason(_quote_errors, self.settings.llm_provider))
            # ── Quote outcome rollup + abandon check ───────────────────
            # MUST run BEFORE mark_stage_complete: if we mark the stage
            # complete first and then raise, the manifest poisons the next
            # run's cache (empty extracted_quotes.json reads back as
            # "stage already done"). Order is non-negotiable — A4 fix #1.
            #
            # Each transcript that reached s09 is one attempt. Cached
            # quotes from prior runs count as successes. If every quote
            # extraction call failed, abandon: a report with no quotes is
            # the symptom we're guarding against.
            self._summary.quotes = StageOutcome(
                attempted=_cached_q_count + _fresh_quote_outcome.attempted,
                succeeded=_cached_q_count + _fresh_quote_outcome.succeeded,
                failed=list(_fresh_quote_outcome.failed),
                duration_ms=(
                    int(_quotes_elapsed * 1000)
                    if _quotes_elapsed is not None else None
                ),
            )
            if (
                self._summary.quotes.attempted > 0
                and self._summary.quotes.succeeded == 0
            ):
                raise PipelineAbandonedError(
                    cause=_dominant_cause(
                        self._summary.quotes.failed,
                        default_category=CauseCategoryEnum.UNKNOWN,
                        message="All quote extraction calls failed.",
                    ),
                    summary=self._summary,
                )

            _eq_hash = (
                hash_bytes(_eq_path.read_bytes()) if _eq_path.exists() else None
            )
            mark_stage_complete(
                manifest, STAGE_QUOTE_EXTRACTION,
                content_hash=_eq_hash,
                input_hashes=_qe_input_hashes,
                output_path=_eq_path,
            )
            write_manifest(manifest, output_dir)

            # ── Stages 10+11: Cluster by screen + thematic grouping ──
            _sc_path = intermediate / "screen_clusters.json"
            _tg_path = intermediate / "theme_groups.json"
            _cg_input_hashes = {"upstream": _eq_hash or _MISSING_HASH}
            # Defaults — populated by either branch below. Cache hit treats
            # both stages as one attempt + one success each (the cached
            # result IS the success). Fresh path captures real outcomes.
            _cluster_outcome = StageOutcome()
            _theme_outcome = StageOutcome()
            _cluster_elapsed: float | None = None
            if _is_stage_verified(
                _prev_manifest, STAGE_CLUSTER_AND_GROUP,
                [_sc_path, _tg_path],
                current_input_hashes=_cg_input_hashes,
            ):
                import json as _json

                screen_clusters = [
                    ScreenCluster.model_validate(obj)
                    for obj in _json.loads(_sc_path.read_text(encoding="utf-8"))
                ]
                theme_groups = [
                    ThemeGroup.model_validate(obj)
                    for obj in _json.loads(_tg_path.read_text(encoding="utf-8"))
                ]
                _cluster_outcome = StageOutcome(attempted=1, succeeded=1)
                _theme_outcome = StageOutcome(attempted=1, succeeded=1)
                _print_cached_step(
                    f"Clustered {count_noun(len(screen_clusters), 'screen')}"
                    f" · Grouped {count_noun(len(theme_groups), 'theme')}",
                )
            else:
                mark_stage_running(manifest, STAGE_CLUSTER_AND_GROUP)
                status.update("[dim]Clustering and grouping...[/dim]")
                t0 = time.perf_counter()
                assert llm_client is not None  # narrowed by upstream lazy-init guards
                _client_cg = llm_client

                async def _run_clustering() -> tuple[list[ScreenCluster], StageOutcome]:
                    with _llm_telemetry.stage("s10_quote_clustering"):
                        return await cluster_by_screen(all_quotes, _client_cg)

                async def _run_grouping() -> tuple[list[ThemeGroup], StageOutcome]:
                    with _llm_telemetry.stage("s11_thematic_grouping"):
                        return await group_by_theme(all_quotes, _client_cg)

                _clustering, _grouping = await asyncio.gather(
                    _run_clustering(), _run_grouping(),
                )
                screen_clusters, _cluster_outcome = _clustering
                theme_groups, _theme_outcome = _grouping
                if self.settings.write_intermediate:
                    write_intermediate_json(
                        screen_clusters, "screen_clusters.json", output_dir,
                        self.settings.project_name,
                    )
                    write_intermediate_json(
                        theme_groups, "theme_groups.json", output_dir,
                        self.settings.project_name,
                    )
                _cluster_elapsed = time.perf_counter() - t0
                _print_step(
                    f"Clustered {count_noun(len(screen_clusters), 'screen')}"
                    f" · Grouped {count_noun(len(theme_groups), 'theme')}",
                    _cluster_elapsed,
                )
                _stage_actuals[STAGE_CLUSTER] = StageActual(
                    elapsed=_cluster_elapsed, input_size=_n_sessions,
                )
                self._emit_remaining(STAGE_CLUSTER, _cluster_elapsed)

            # ── Cluster+group outcome rollup + abandon check ────────────
            # MUST run BEFORE mark_stage_complete (cache-poisoning guard).
            # Pass 3 flips this from soft to hard: a fallback-clustered
            # report that LOOKS real is worse than honest abandon. Fallback
            # output still flows to render so partial state survives, but
            # the orchestrator reads outcome.succeeded and abandons when
            # both stages' LLM calls failed.
            self._summary.themes = StageOutcome(
                attempted=_cluster_outcome.attempted + _theme_outcome.attempted,
                succeeded=_cluster_outcome.succeeded + _theme_outcome.succeeded,
                failed=list(_cluster_outcome.failed) + list(_theme_outcome.failed),
                duration_ms=(
                    int(_cluster_elapsed * 1000)
                    if _cluster_elapsed is not None else None
                ),
            )
            if (
                self._summary.themes.attempted > 0
                and self._summary.themes.succeeded == 0
            ):
                raise PipelineAbandonedError(
                    cause=_dominant_cause(
                        self._summary.themes.failed,
                        default_category=CauseCategoryEnum.UNKNOWN,
                        message="All cluster and group calls failed.",
                    ),
                    summary=self._summary,
                )

            # Hash both output files; combine into a single stage hash
            _cg_parts: list[bytes] = []
            if _sc_path.exists():
                _cg_parts.append(_sc_path.read_bytes())
            if _tg_path.exists():
                _cg_parts.append(_tg_path.read_bytes())
            _cg_hash = hash_bytes(b"".join(_cg_parts)) if _cg_parts else None
            mark_stage_complete(
                manifest, STAGE_CLUSTER_AND_GROUP,
                content_hash=_cg_hash,
                input_hashes=_cg_input_hashes,
            )
            write_manifest(manifest, output_dir)

            # ── People file ───────────────────────────────────────────
            status.update("[dim]Updating people file...[/dim]")
            from bristlenose.people import (
                auto_populate_names,
                build_display_name_map,
                compute_participant_stats,
                extract_names_from_labels,
                load_people_file,
                merge_people,
                suggest_short_names,
                write_people_file,
            )

            existing_people = load_people_file(output_dir)
            computed_stats = compute_participant_stats(sessions, transcripts)
            people = merge_people(existing_people, computed_stats)

            # Auto-populate names from speaker labels and LLM extraction.
            label_names = extract_names_from_labels(transcripts)
            pid_speaker_info: dict[str, SpeakerInfo] = {}
            for sid, infos in all_speaker_infos.items():
                label_code_map = all_label_code_maps.get(sid, {})
                for info in infos:
                    code = label_code_map.get(info.speaker_label, "")
                    if not code:
                        continue
                    if info.role == SpeakerRole.PARTICIPANT:
                        pid_speaker_info[code] = info
                    elif info.role == SpeakerRole.RESEARCHER and code.startswith("m"):
                        pid_speaker_info[code] = info
            auto_populate_names(people, pid_speaker_info, label_names)
            suggest_short_names(people)

            write_people_file(people, output_dir)
            display_names = build_display_name_map(people)

            # ── Stage 12: Render output ──────────────────────────────
            mark_stage_running(manifest, _M_STAGE_RENDER)
            status.update("[dim]Rendering output...[/dim]")
            t0 = time.perf_counter()
            analysis = _compute_analysis(
                screen_clusters, theme_groups, all_quotes, sessions,
            )
            render_markdown(
                screen_clusters,
                theme_groups,
                sessions,
                self.settings.project_name,
                output_dir,
                all_quotes=all_quotes,
                display_names=display_names,
                people=people,
            )
            report_path = render_html(
                screen_clusters,
                theme_groups,
                sessions,
                self.settings.project_name,
                output_dir,
                all_quotes=all_quotes,
                color_scheme=self.settings.color_scheme,
                display_names=display_names,
                people=people,
                transcripts=transcripts,
                analysis=analysis,
            )
            _render_elapsed = time.perf_counter() - t0
            _print_step("Rendered report", _render_elapsed)
            _stage_actuals[STAGE_RENDER] = StageActual(
                elapsed=_render_elapsed, input_size=_n_sessions,
            )
            mark_stage_complete(manifest, _M_STAGE_RENDER)
            write_manifest(manifest, output_dir)

        elapsed = time.perf_counter() - pipeline_start

        # Record actuals for future estimates.
        if self._estimator is not None:
            self._estimator.record_run(_stage_actuals)  # type: ignore[union-attr]

        # Extract root-cause error/warning for the CLI summary.
        _p_error, _p_error_link = "", ""
        _p_warning = ""
        if len(all_quotes) == 0 and (_quote_errors or _seg_errors):
            _p_error, _p_error_link = _short_reason(
                _quote_errors or _seg_errors, self.settings.llm_provider,
            )
        elif len(all_quotes) > 0 and (_quote_errors or _seg_errors):
            _p_warning, _ = _short_reason(
                _quote_errors or _seg_errors, self.settings.llm_provider,
            )

        return PipelineResult(
            project_name=self.settings.project_name,
            participants=sessions,
            raw_transcripts=transcripts,
            clean_transcripts=clean_transcripts,
            screen_clusters=screen_clusters,
            theme_groups=theme_groups,
            output_dir=output_dir,
            report_path=report_path,
            people=people,
            elapsed_seconds=elapsed,
            llm_input_tokens=llm_client.tracker.input_tokens if llm_client else 0,
            llm_output_tokens=llm_client.tracker.output_tokens if llm_client else 0,
            llm_calls=llm_client.tracker.calls if llm_client else 0,
            llm_model=self.settings.llm_model,
            llm_provider=self.settings.llm_provider,
            total_quotes=len(all_quotes),
            pipeline_error=_p_error,
            pipeline_error_link=_p_error_link,
            pipeline_warning=_p_warning,
            summary=self._summary,
        )

    async def run_transcription_only(
        self, input_dir: Path, output_dir: Path
    ) -> PipelineResult:
        """Run only ingestion and transcription (no LLM analysis).

        Useful for producing raw transcripts without needing an API key.
        """
        import time
        from collections import Counter

        from bristlenose.stages.s01_ingest import ingest
        from bristlenose.stages.s02_extract_audio import extract_audio_for_sessions
        from bristlenose.stages.s05b_identify_speakers import identify_speaker_roles_heuristic
        from bristlenose.stages.s06_merge_transcript import (
            merge_transcripts,
            write_raw_transcripts,
            write_raw_transcripts_md,
        )

        pipeline_start = time.perf_counter()
        self._summary = PipelineSummary()
        output_dir.mkdir(parents=True, exist_ok=True)
        self._configure_logging(output_dir)

        # ── Stage 1: Ingest ──
        t0 = time.perf_counter()
        sessions = ingest(input_dir)
        if not sessions:
            console.print("[red]No supported files found.[/red]")
            raise PipelineAbandonedError(
                cause=Cause(
                    category=CauseCategoryEnum.MISSING_INPUT,
                    message="No supported files found in input directory.",
                    stage="s01_ingest",
                ),
                summary=self._summary,
            )

        ingest_elapsed = time.perf_counter() - t0

        # ── Session-count guard ───────────────────────────────────
        if len(sessions) > _MAX_SESSIONS_NO_CONFIRM and not self._skip_confirm:
            if not self._confirm_large_session_count(len(sessions), input_dir):
                return self._empty_result(output_dir)

        # ── Print found-sessions line, then ingest checkmark ──
        console.print(
            f"  [dim]{count_noun(len(sessions), 'session')} in {input_dir.name}/[/dim]\n",
        )
        type_counts = Counter(
            f.file_type.value for s in sessions for f in s.files
        )
        type_parts = [f"{n} {t}" for t, n in type_counts.most_common()]
        _print_step(
            f"Ingested {count_noun(len(sessions), 'session')} ({', '.join(type_parts)})",
            ingest_elapsed,
        )

        with console.status("", spinner="dots") as status:
            status.renderable.frames = [" " + f for f in status.renderable.frames]

            # ── Stage 2: Extract audio ──
            status.update("[dim]Extracting audio...[/dim]")
            t0 = time.perf_counter()
            temp_dir = output_dir / ".bristlenose" / "temp"
            temp_dir.mkdir(parents=True, exist_ok=True)
            sessions = await extract_audio_for_sessions(sessions, temp_dir)
            _print_step(
                f"Extracted audio from {count_noun(len(sessions), 'session')}",
                time.perf_counter() - t0,
            )

            # ── Stages 3-5: Transcribe ──
            status.update("[dim]Transcribing...[/dim]")
            t0 = time.perf_counter()

            def _on_transcribe_progress(current: int, total: int) -> None:
                word = "file" if total == 1 else "files"
                status.update(f"[dim]Transcribing... ({current}/{total} {word})[/dim]")

            session_segments, _transcript_outcome_t = await self._gather_all_segments(
                sessions, on_progress=_on_transcribe_progress
            )
            # Mirror the run() rollup: one attempt per session, success when
            # segments are non-empty. Whisper failures already flowed in via
            # _gather_all_segments.
            self._summary.transcripts = StageOutcome(
                attempted=len(sessions),
                succeeded=sum(
                    1 for s in sessions if session_segments.get(s.session_id)
                ),
                failed=list(_transcript_outcome_t.failed),
                duration_ms=int((time.perf_counter() - t0) * 1000),
            )
            if (
                self._summary.transcripts.attempted > 0
                and self._summary.transcripts.succeeded == 0
            ):
                raise PipelineAbandonedError(
                    cause=_dominant_cause(
                        self._summary.transcripts.failed,
                        default_category=CauseCategoryEnum.WHISPER,
                        message="All sessions failed to transcribe.",
                    ),
                    summary=self._summary,
                )
            total_segments = sum(len(s) for s in session_segments.values())
            total_audio = sum(
                f.duration_seconds or 0 for s in sessions for f in s.files
            )
            audio_str = _format_duration(total_audio) if total_audio else ""
            msg = (
                f"Transcribed {count_noun(len(sessions), 'session')}"
                f" ({count_noun(total_segments, 'segment')}"
            )
            if audio_str:
                msg += f", {audio_str} audio"
            msg += ")"
            _print_step(msg, time.perf_counter() - t0)

            # ── Heuristic speaker identification (no LLM) ──
            status.update("[dim]Identifying speakers...[/dim]")
            t0 = time.perf_counter()
            for pid, segments in session_segments.items():
                identify_speaker_roles_heuristic(segments)
            _print_step("Identified speakers (heuristic)", time.perf_counter() - t0)

            # ── Merge and write transcripts ──
            status.update("[dim]Merging transcripts...[/dim]")
            t0 = time.perf_counter()
            transcripts = merge_transcripts(sessions, session_segments, input_dir)
            raw_dir = output_dir / "transcripts-raw"
            write_raw_transcripts(transcripts, raw_dir)
            write_raw_transcripts_md(transcripts, raw_dir)
            _print_step("Merged transcripts", time.perf_counter() - t0)

        # People file (stats only, no rendering)
        from bristlenose.people import (
            auto_populate_names,
            compute_participant_stats,
            extract_names_from_labels,
            load_people_file,
            merge_people,
            suggest_short_names,
            write_people_file,
        )

        existing_people = load_people_file(output_dir)
        computed_stats = compute_participant_stats(sessions, transcripts)
        people = merge_people(existing_people, computed_stats)

        label_names = extract_names_from_labels(transcripts)
        auto_populate_names(people, {}, label_names)
        suggest_short_names(people)

        write_people_file(people, output_dir)

        elapsed = time.perf_counter() - pipeline_start

        return PipelineResult(
            project_name=self.settings.project_name,
            participants=sessions,
            raw_transcripts=transcripts,
            clean_transcripts=[],
            screen_clusters=[],
            theme_groups=[],
            output_dir=output_dir,
            people=people,
            elapsed_seconds=elapsed,
            summary=self._summary,
        )

    async def run_analysis_only(
        self, transcripts_dir: Path, output_dir: Path
    ) -> PipelineResult:
        """Run LLM analysis on existing transcript files.

        Loads .txt transcripts from a directory and runs stages 8-12.
        """
        import time

        from bristlenose.llm.client import LLMClient
        from bristlenose.stages.s08_topic_segmentation import segment_topics
        from bristlenose.stages.s09_quote_extraction import extract_quotes
        from bristlenose.stages.s10_quote_clustering import cluster_by_screen
        from bristlenose.stages.s11_thematic_grouping import group_by_theme
        from bristlenose.stages.s12_render import render_html
        from bristlenose.stages.s12_render_output import (
            render_markdown,
            write_intermediate_json,
            write_pipeline_metadata,
        )

        pipeline_start = time.perf_counter()
        _printed_warnings.clear()
        self._summary = PipelineSummary()
        output_dir.mkdir(parents=True, exist_ok=True)
        self._configure_logging(output_dir)
        write_pipeline_metadata(output_dir, self.settings.project_name)

        # Load existing transcripts from text files
        clean_transcripts = load_transcripts_from_dir(transcripts_dir)
        if not clean_transcripts:
            console.print("[red]No transcript files found.[/red]")
            return self._empty_result(output_dir)

        # ── Session-count guard ───────────────────────────────────
        if len(clean_transcripts) > _MAX_SESSIONS_NO_CONFIRM and not self._skip_confirm:
            if not self._confirm_large_session_count(
                len(clean_transcripts), transcripts_dir
            ):
                return self._empty_result(output_dir)

        llm_client = LLMClient(self.settings)
        concurrency = self.settings.llm_concurrency

        console.print(
            f"[dim]{count_noun(len(clean_transcripts), 'transcript')} in"
            f" {transcripts_dir.name}/[/dim]",
        )

        from bristlenose.llm.pricing import estimate_pipeline_cost

        est = estimate_pipeline_cost(
            self.settings.llm_model, len(clean_transcripts),
            run_dir=output_dir / ".bristlenose",
        )
        if est is not None:
            console.print(
                f"  [dim]Estimated LLM cost: ~${est:.2f}"
                f" for {count_noun(len(clean_transcripts), 'session')}"
                f" ({self.settings.llm_model})[/dim]\n"
            )
        else:
            console.print()  # blank line before stages

        with console.status("", spinner="dots") as status:
            status.renderable.frames = [" " + f for f in status.renderable.frames]

            # ── Topic segmentation ──
            status.update("[dim]Segmenting topics...[/dim]")
            t0 = time.perf_counter()
            _seg_errors_a: list[str] = []
            with _llm_telemetry.stage("s08_topic_segmentation"):
                topic_maps, _seg_outcome_a = await segment_topics(
                    clean_transcripts, llm_client, concurrency=concurrency,
                    errors=_seg_errors_a,
                )
            if self.settings.write_intermediate:
                write_intermediate_json(
                    topic_maps, "topic_boundaries.json", output_dir,
                    self.settings.project_name,
                )
            total_boundaries = sum(len(m.boundaries) for m in topic_maps)
            _seg_elapsed_a = time.perf_counter() - t0
            _msg_8a = f"Segmented {count_noun(total_boundaries, 'topic boundary')}"
            if _seg_errors_a and total_boundaries == 0:
                _print_error_step(_msg_8a, _seg_elapsed_a)
            elif _seg_errors_a:
                _print_warn_step(_msg_8a, _seg_elapsed_a)
            else:
                _print_step(_msg_8a, _seg_elapsed_a)
            if _seg_errors_a:
                _print_warn(*_short_reason(_seg_errors_a, self.settings.llm_provider))

            # Topic abandon-check — Pass 3 addition. `bristlenose analyze`
            # with a bad API key used to waste s09 LLM calls when s08 had
            # already 100%-failed. Gate s09 entry on s08 success.
            self._summary.topics = _seg_outcome_a.model_copy(update={
                "duration_ms": int(_seg_elapsed_a * 1000),
            })
            if (
                _seg_outcome_a.attempted > 0
                and _seg_outcome_a.succeeded == 0
            ):
                raise PipelineAbandonedError(
                    cause=_dominant_cause(
                        _seg_outcome_a.failed,
                        default_category=CauseCategoryEnum.UNKNOWN,
                        message="All topic segmentation calls failed.",
                    ),
                    summary=self._summary,
                )

            # ── Quote extraction ──
            status.update("[dim]Extracting quotes...[/dim]")
            t0 = time.perf_counter()
            _quote_errors_a: list[str] = []
            with _llm_telemetry.stage("s09_quote_extraction"):
                all_quotes, _quote_outcome_a = await extract_quotes(
                    clean_transcripts, topic_maps, llm_client,
                    min_quote_words=self.settings.min_quote_words,
                    concurrency=concurrency,
                    errors=_quote_errors_a,
                )
            # Stamp duration_ms before the abandon check so the partial
            # summary on the abandoned terminus event carries timing too.
            self._summary.quotes = _quote_outcome_a.model_copy(update={
                "duration_ms": int((time.perf_counter() - t0) * 1000),
            })
            if (
                _quote_outcome_a.attempted > 0
                and _quote_outcome_a.succeeded == 0
            ):
                raise PipelineAbandonedError(
                    cause=_dominant_cause(
                        _quote_outcome_a.failed,
                        default_category=CauseCategoryEnum.UNKNOWN,
                        message="All quote extraction calls failed.",
                    ),
                    summary=self._summary,
                )
            if self.settings.write_intermediate:
                write_intermediate_json(
                    all_quotes, "extracted_quotes.json", output_dir,
                    self.settings.project_name,
                )
            _quotes_elapsed_a = time.perf_counter() - t0
            _msg_9a = f"Extracted {count_noun(len(all_quotes), 'quote')}"
            if _quote_errors_a and len(all_quotes) == 0:
                _print_error_step(_msg_9a, _quotes_elapsed_a)
            elif _quote_errors_a:
                _print_warn_step(_msg_9a, _quotes_elapsed_a)
            else:
                _print_step(_msg_9a, _quotes_elapsed_a)
            if _quote_errors_a:
                _print_warn(*_short_reason(_quote_errors_a, self.settings.llm_provider))

            # ── Cluster + group ──
            status.update("[dim]Clustering and grouping...[/dim]")
            t0 = time.perf_counter()
            async def _run_clustering_a() -> tuple[list[ScreenCluster], StageOutcome]:
                with _llm_telemetry.stage("s10_quote_clustering"):
                    return await cluster_by_screen(all_quotes, llm_client)

            async def _run_grouping_a() -> tuple[list[ThemeGroup], StageOutcome]:
                with _llm_telemetry.stage("s11_thematic_grouping"):
                    return await group_by_theme(all_quotes, llm_client)

            _clustering_a, _grouping_a = await asyncio.gather(
                _run_clustering_a(),
                _run_grouping_a(),
            )
            screen_clusters, _cluster_outcome_a = _clustering_a
            theme_groups, _theme_outcome_a = _grouping_a
            _cg_elapsed_a = time.perf_counter() - t0
            # Combined cluster+group rollup. Pass 3 flip: soft → hard. If
            # both LLM calls failed, abandon honestly instead of shipping a
            # fallback-clustered "degraded" report dressed up as the real
            # thing. Fallback output still flows to render (so the partial
            # state survives if A4 isn't fully wired everywhere), but the
            # orchestrator reads outcome.succeeded and abandons.
            self._summary.themes = StageOutcome(
                attempted=_cluster_outcome_a.attempted + _theme_outcome_a.attempted,
                succeeded=_cluster_outcome_a.succeeded + _theme_outcome_a.succeeded,
                failed=list(_cluster_outcome_a.failed) + list(_theme_outcome_a.failed),
                duration_ms=int(_cg_elapsed_a * 1000),
            )
            if (
                self._summary.themes.attempted > 0
                and self._summary.themes.succeeded == 0
            ):
                raise PipelineAbandonedError(
                    cause=_dominant_cause(
                        self._summary.themes.failed,
                        default_category=CauseCategoryEnum.UNKNOWN,
                        message="All cluster and group calls failed.",
                    ),
                    summary=self._summary,
                )
            if self.settings.write_intermediate:
                write_intermediate_json(
                    screen_clusters, "screen_clusters.json", output_dir,
                    self.settings.project_name,
                )
                write_intermediate_json(
                    theme_groups, "theme_groups.json", output_dir,
                    self.settings.project_name,
                )
            _print_step(
                f"Clustered {count_noun(len(screen_clusters), 'screen')}"
                f" · Grouped {count_noun(len(theme_groups), 'theme')}",
                _cg_elapsed_a,
            )

            # ── Render ──
            status.update("[dim]Rendering output...[/dim]")
            t0 = time.perf_counter()

            from bristlenose.people import build_display_name_map, load_people_file

            people = load_people_file(output_dir)
            display_names = build_display_name_map(people) if people else {}

            analysis = _compute_analysis(
                screen_clusters, theme_groups, all_quotes,
            )
            render_markdown(
                screen_clusters, theme_groups, [],
                self.settings.project_name, output_dir,
                all_quotes=all_quotes,
                display_names=display_names,
                people=people,
            )
            report_path = render_html(
                screen_clusters, theme_groups, [],
                self.settings.project_name, output_dir,
                all_quotes=all_quotes,
                color_scheme=self.settings.color_scheme,
                display_names=display_names,
                people=people,
                transcripts=clean_transcripts,
                analysis=analysis,
            )
            _print_step("Rendered report", time.perf_counter() - t0)

        elapsed = time.perf_counter() - pipeline_start

        # Extract root-cause error/warning for the CLI summary.
        _p_error_a, _p_error_link_a = "", ""
        _p_warning_a = ""
        if len(all_quotes) == 0 and (_quote_errors_a or _seg_errors_a):
            _p_error_a, _p_error_link_a = _short_reason(
                _quote_errors_a or _seg_errors_a, self.settings.llm_provider,
            )
        elif len(all_quotes) > 0 and (_quote_errors_a or _seg_errors_a):
            _p_warning_a, _ = _short_reason(
                _quote_errors_a or _seg_errors_a, self.settings.llm_provider,
            )

        return PipelineResult(
            project_name=self.settings.project_name,
            participants=[],
            raw_transcripts=[],
            clean_transcripts=clean_transcripts,
            screen_clusters=screen_clusters,
            theme_groups=theme_groups,
            output_dir=output_dir,
            report_path=report_path,
            people=people,
            elapsed_seconds=elapsed,
            llm_input_tokens=llm_client.tracker.input_tokens,
            llm_output_tokens=llm_client.tracker.output_tokens,
            llm_calls=llm_client.tracker.calls,
            llm_model=self.settings.llm_model,
            llm_provider=self.settings.llm_provider,
            total_quotes=len(all_quotes),
            pipeline_error=_p_error_a,
            pipeline_error_link=_p_error_link_a,
            pipeline_warning=_p_warning_a,
            summary=self._summary,
        )

    async def _gather_all_segments(
        self,
        sessions: list[InputSession],
        *,
        on_progress: object | None = None,
    ) -> tuple[dict[str, list[TranscriptSegment]], StageOutcome]:
        """Gather transcript segments from all sources (subtitle, docx, whisper).

        Args:
            sessions: Input sessions.
            on_progress: Optional callback(current, total) for transcription progress.

        Returns:
            Tuple of (session_segments, transcript_outcome). Subtitle / docx
            sources are recorded as successes in the outcome (one per session
            that produced segments); Whisper failures come from
            ``transcribe_sessions`` directly.
        """
        from bristlenose.stages.s03_parse_subtitles import parse_subtitle_file
        from bristlenose.stages.s04_parse_docx import parse_docx_file
        from bristlenose.stages.s05_transcribe import transcribe_sessions

        session_segments: dict[str, list[TranscriptSegment]] = {}

        for session in sessions:
            segments: list[TranscriptSegment] = []

            # Try subtitle files first
            for f in session.files:
                if f.file_type in (FileType.SUBTITLE_SRT, FileType.SUBTITLE_VTT):
                    try:
                        subs = parse_subtitle_file(f)
                        segments.extend(subs)
                        logger.info(
                            "%s: Parsed %d segments from %s",
                            session.session_id,
                            len(subs),
                            f.path.name,
                        )
                    except Exception as exc:
                        logger.error(
                            "%s: Failed to parse %s: %s",
                            session.session_id,
                            f.path.name,
                            exc,
                        )

            # Try docx files
            for f in session.files:
                if f.file_type == FileType.DOCX:
                    try:
                        docs = parse_docx_file(f)
                        segments.extend(docs)
                        logger.info(
                            "%s: Parsed %d segments from %s",
                            session.session_id,
                            len(docs),
                            f.path.name,
                        )
                    except Exception as exc:
                        logger.error(
                            "%s: Failed to parse %s: %s",
                            session.session_id,
                            f.path.name,
                            exc,
                        )

            if segments:
                session_segments[session.session_id] = segments
            # If no existing transcript, audio will be transcribed below

        # Pre-existing-transcript sessions count as transcript successes —
        # they don't go through Whisper, but they did produce segments.
        transcript_outcome = StageOutcome(
            attempted=len(session_segments),
            succeeded=len(session_segments),
        )

        # Transcribe sessions that still need it
        if not self.settings.skip_transcription:
            needs_transcription = [
                s for s in sessions
                if s.session_id not in session_segments and s.audio_path is not None
            ]
            if needs_transcription:
                whisper_results, whisper_outcome = transcribe_sessions(
                    needs_transcription,
                    self.settings,
                    on_progress=on_progress,
                )
                session_segments.update(whisper_results)
                transcript_outcome.attempted += whisper_outcome.attempted
                transcript_outcome.succeeded += whisper_outcome.succeeded
                transcript_outcome.failed.extend(whisper_outcome.failed)

        return session_segments, transcript_outcome

    def run_render_only(
        self,
        output_dir: Path,
        input_dir: Path,
    ) -> PipelineResult:
        """Re-render reports from existing intermediate JSON.

        No transcription or LLM calls — just reads the JSON files written by
        a previous pipeline run and regenerates the HTML and Markdown output.

        Args:
            output_dir: Output directory containing ``intermediate/`` JSON.
            input_dir:  Original input directory. Sessions are re-ingested
                        (fast, no transcription) so the report can link
                        clickable timecodes to video files.

        Returns:
            PipelineResult (with empty transcripts — only clusters/themes populated).
        """
        import json as _json
        import time

        from bristlenose.models import ExtractedQuote, ScreenCluster, ThemeGroup
        from bristlenose.stages.s12_render import render_html
        from bristlenose.stages.s12_render_output import render_markdown

        self._configure_logging(output_dir)

        # Try new layout first (.bristlenose/intermediate/), fall back to legacy (intermediate/)
        intermediate = output_dir / ".bristlenose" / "intermediate"
        if not intermediate.is_dir():
            intermediate = output_dir / "intermediate"

        # --- Load intermediate JSON ---
        sc_path = intermediate / "screen_clusters.json"
        tg_path = intermediate / "theme_groups.json"
        eq_path = intermediate / "extracted_quotes.json"

        if not sc_path.exists() or not tg_path.exists():
            console.print(
                "[red]Missing intermediate files.[/red] "
                "Expected screen_clusters.json and theme_groups.json in "
                f"{intermediate}"
            )
            return self._empty_result(output_dir)

        screen_clusters = [
            ScreenCluster.model_validate(obj)
            for obj in _json.loads(sc_path.read_text(encoding="utf-8"))
        ]
        theme_groups = [
            ThemeGroup.model_validate(obj)
            for obj in _json.loads(tg_path.read_text(encoding="utf-8"))
        ]
        all_quotes: list[ExtractedQuote] = []
        if eq_path.exists():
            all_quotes = [
                ExtractedQuote.model_validate(obj)
                for obj in _json.loads(eq_path.read_text(encoding="utf-8"))
            ]

        # --- Re-ingest input files for video linking ---
        from bristlenose.stages.s01_ingest import ingest

        sessions = ingest(input_dir)

        # --- Load existing people file for display names ---
        from bristlenose.people import build_display_name_map, load_people_file

        people = load_people_file(output_dir)
        display_names = build_display_name_map(people) if people else {}

        # --- Load transcripts for coverage calculation ---
        # Use same preference as render_transcript_pages: cooked > raw
        # Try new layout first (transcripts-cooked/), fall back to legacy (cooked_transcripts/)
        cooked_dir = output_dir / "transcripts-cooked"
        if not cooked_dir.is_dir():
            cooked_dir = output_dir / "cooked_transcripts"
        raw_dir = output_dir / "transcripts-raw"
        if not raw_dir.is_dir():
            raw_dir = output_dir / "raw_transcripts"
        if cooked_dir.is_dir() and any(cooked_dir.glob("*.txt")):
            transcripts_dir = cooked_dir
        elif raw_dir.is_dir():
            transcripts_dir = raw_dir
        else:
            transcripts_dir = None
        transcripts = (
            load_transcripts_from_dir(transcripts_dir)
            if transcripts_dir
            else []
        )

        # --- Render ---
        t0 = time.perf_counter()
        analysis = _compute_analysis(
            screen_clusters, theme_groups, all_quotes, sessions,
        )
        render_markdown(
            screen_clusters, theme_groups, sessions,
            self.settings.project_name, output_dir,
            all_quotes=all_quotes,
            display_names=display_names,
            people=people,
        )
        report_path = render_html(
            screen_clusters, theme_groups, sessions,
            self.settings.project_name, output_dir,
            all_quotes=all_quotes,
            color_scheme=self.settings.color_scheme,
            display_names=display_names,
            people=people,
            transcripts=transcripts,
            analysis=analysis,
        )
        _print_step("Rendered report", time.perf_counter() - t0)

        return PipelineResult(
            project_name=self.settings.project_name,
            participants=sessions,
            raw_transcripts=[],
            clean_transcripts=[],
            screen_clusters=screen_clusters,
            theme_groups=theme_groups,
            output_dir=output_dir,
            report_path=report_path,
            people=people,
            total_quotes=len(all_quotes),
        )

    def _empty_result(self, output_dir: Path) -> PipelineResult:
        """Return an empty pipeline result."""
        return PipelineResult(
            project_name=self.settings.project_name,
            participants=[],
            raw_transcripts=[],
            clean_transcripts=[],
            screen_clusters=[],
            theme_groups=[],
            output_dir=output_dir,
        )


def load_transcripts_from_dir(
    transcripts_dir: Path,
) -> list[PiiCleanTranscript]:
    """Load transcript .txt files from a directory into PiiCleanTranscript objects.

    Expects files named like s1.txt (new layout) or s1_raw.txt (legacy layout)
    with the format::

        # Transcript: s1
        # Source: ...
        # Date: ...
        # Duration: ...

        [HH:MM:SS] [p1] text...

    The bracket token after the timecode is the speaker code (e.g. ``p1``,
    ``m1``).  Legacy files with speaker roles (e.g. ``[PARTICIPANT]``) are
    also accepted.
    """
    import re
    from datetime import datetime, timezone

    from bristlenose.models import SpeakerRole
    from bristlenose.utils.timecodes import parse_timecode

    transcripts: list[PiiCleanTranscript] = []

    for path in sorted(transcripts_dir.glob("*.txt")):
        if is_os_metadata(path):
            continue
        segments: list[TranscriptSegment] = []
        session_id = ""
        source_file = ""
        session_date = datetime.now(tz=timezone.utc)
        duration = 0.0

        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue

            # Parse header comments
            if line.startswith("# Transcript"):
                # Accept both "s1" (new) and "p1" (legacy) in header
                match = re.search(r":\s*([sp]\d+)", line)
                if match:
                    session_id = match.group(1)
                continue
            if line.startswith("# Source:"):
                source_file = line.split(":", 1)[1].strip()
                continue
            if line.startswith("# Date:"):
                try:
                    date_str = line.split(":", 1)[1].strip()
                    session_date = datetime.fromisoformat(date_str).replace(tzinfo=timezone.utc)
                except ValueError:
                    pass
                continue
            if line.startswith("# Duration:"):
                try:
                    duration = parse_timecode(line.split(":", 1)[1].strip())
                except ValueError:
                    pass
                continue
            if line.startswith("#"):
                continue

            # Parse transcript lines: [MM:SS] or [HH:MM:SS] [speaker_code] text
            # The bracket token is the speaker code (p1, m1, o1, ...) or
            # a legacy speaker role (PARTICIPANT, RESEARCHER, etc.).
            match = re.match(
                r"\[(\d{2}:\d{2}(?::\d{2})?)\]\s*(?:\[(\w+)\])?\s*(.*)", line
            )
            if match:
                tc_str, bracket_token, text = match.groups()
                start_time = parse_timecode(tc_str)

                # Interpret bracket token: moderator codes (m1, m2),
                # observer codes (o1), participant codes (p1), or
                # legacy speaker roles (PARTICIPANT, RESEARCHER).
                role = SpeakerRole.UNKNOWN
                speaker_code = ""
                if bracket_token:
                    if bracket_token[0] == "m" and bracket_token[1:].isdigit():
                        role = SpeakerRole.RESEARCHER
                        speaker_code = bracket_token
                    elif bracket_token[0] == "o" and bracket_token[1:].isdigit():
                        role = SpeakerRole.OBSERVER
                        speaker_code = bracket_token
                    elif bracket_token[0] == "p" and bracket_token[1:].isdigit():
                        speaker_code = bracket_token
                    else:
                        try:
                            role = SpeakerRole(bracket_token.lower())
                        except ValueError:
                            pass

                segments.append(
                    TranscriptSegment(
                        start_time=start_time,
                        end_time=start_time,
                        text=text,
                        speaker_role=role,
                        speaker_code=speaker_code,
                        source="file",
                    )
                )

        if not session_id:
            # Derive from filename (s1_raw.txt → s1, legacy p1_raw.txt → p1)
            stem = path.stem.replace("_raw", "").replace("_cooked", "").replace("_clean", "")
            session_id = stem

        # Derive primary participant_id from first p-code in segments
        participant_id = ""
        for seg in segments:
            if seg.speaker_code.startswith("p"):
                participant_id = seg.speaker_code
                break
        if not participant_id:
            # Legacy fallback: if session_id is a p-code, use it
            participant_id = session_id if session_id.startswith("p") else ""

        if segments:
            transcripts.append(
                PiiCleanTranscript(
                    session_id=session_id,
                    participant_id=participant_id,
                    source_file=source_file,
                    session_date=session_date,
                    duration_seconds=duration,
                    segments=segments,
                )
            )

    return transcripts
