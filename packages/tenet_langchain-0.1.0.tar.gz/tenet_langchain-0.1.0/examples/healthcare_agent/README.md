# Healthcare agent gated by the Tenet `healthcare-1` cloud judge

A self-contained example that wires a LangChain agent to the Tenet cloud
judge in one call via [`tenet_langchain.wrap`](../../src/tenet_langchain/wrap.py),
which attaches [`CloudJudgeMiddleware`](../../src/tenet_langchain/cloud_middleware.py)
at every tool boundary.

The agent has three stub healthcare tools and runs three demo prompts that
exercise the typical paths:

| Prompt | Tool called | Expected verdict |
|---|---|---|
| Look up first-line antihypertensives | `search_clinical_guidelines` | `allow` |
| Pull a patient chart | `get_patient_chart` | `block` at `tool_post` (PHI disclosure) |
| At-home triage for chest pain | `triage_symptom` | `block` at `tool_post` (out-of-scope triage) |

The agent fails closed by default — a transient cloud error halts the
agent. Pass `fail_open=True` to `wrap()` for dev.

## Run it

```bash
export TENET_CLIENT_ID=<your-m2m-client-id>
export TENET_CLIENT_SECRET=<your-m2m-client-secret>
export TENET_JUDGE_ID=healthcare-1
export ANTHROPIC_API_KEY=<your-anthropic-key>

uv run main.py
```

`main.py` uses [PEP 723 inline metadata](https://peps.python.org/pep-0723/),
so `uv run` resolves the dependency tree automatically — no virtualenv
setup needed.

## The shape

Strip out the demo scaffolding and what's left is essentially:

```python
from tenet_client import TenetCloudJudgeClient
from tenet_langchain import wrap

judge = TenetCloudJudgeClient.from_env()
await judge.warmup_async()  # pre-mint the Auth0 token at startup

agent = wrap(
    model="claude-sonnet-4-5-20250514",
    tools=[search_clinical_guidelines, get_patient_chart, triage_symptom],
    judge=judge,
    fail_open=False,  # compliance default
    system_prompt="You are a clinical-information assistant ...",
)

result = await agent.ainvoke({"messages": [HumanMessage(content="...")]})
```

`wrap()` is a thin façade for `langchain.agents.create_agent` that
pre-attaches the cloud-judge middleware. If you'd rather build your
own middleware list, use `CloudJudgeMiddleware` directly:

```python
from tenet_langchain import CloudJudgeMiddleware

agent = create_agent(
    model="claude-sonnet-4-5-20250514",
    tools=[...],
    middleware=[CloudJudgeMiddleware(judge, fail_open=False), my_other_mw],
)
```

## What you'll see

Each prompt prints the final assistant message. On a block, the LLM
gets a `ToolMessage` with `status="error"` and the judge's reason; the
system prompt instructs it to acknowledge the block and offer a safer
alternative rather than retry.

## Adapting to your codebase

- **Different tools.** Drop in your own `@tool`-decorated functions; the
  middleware is tool-agnostic.
- **Different judge.** Set `TENET_JUDGE_ID=hr-1` (or build the client
  yourself with `judge_id="hr-1"`) for the EEO / hiring judge. The wire
  shape is identical.
- **Both judges in one agent.** Instantiate two `TenetCloudJudgeClient`s
  and stack two `CloudJudgeMiddleware` instances via `extra_middleware=[…]`.
- **Pre-only or post-only checks.** Pass `check_pre=False` or
  `check_post=False` to `wrap()`.
- **Agent-boundary checks instead of tool-boundary.** See
  [recipe 2 in the recipe doc](../../../tenet-client/docs/cloud_judge_recipes.md#recipe-2--before_agent--after_agent)
  for the `before_agent` / `after_agent` shape — that one isn't shipped
  as a reusable middleware (the latency tradeoffs are surface-specific
  enough that we want integrators to opt in deliberately).
- **Non-LangChain code paths.** Use the `@judged` decorator from
  `tenet_client` (also re-exported from `tenet_langchain`) to gate any
  function with the cloud judge.
