# /// script
# requires-python = ">=3.11,<3.14"
# dependencies = [
#   "tenet-langchain>=0.1.0a1",
#   "langchain>=1.2.13",
#   "langchain-anthropic>=0.3",
# ]
# ///
"""A LangChain healthcare agent gated by the Tenet ``healthcare-1`` cloud judge.

This is the "one-line" version: ``tenet_langchain.wrap`` builds a guarded
LangChain agent in a single call. The middleware behind it
(:class:`CloudJudgeMiddleware`) is what's documented in
``packages/clients/python/tenet-client/docs/cloud_judge_recipes.md`` recipe 1 —
shipped as a reusable export instead of inline boilerplate.

Three demo prompts exercise the typical paths:

  1. benign clinical lookup        → judge returns ``allow`` → tool runs.
  2. patient-chart lookup          → tool output contains PHI → judge
                                     returns ``block`` at ``tool_post`` →
                                     ``ToolMessage(status="error")`` is
                                     returned to the LLM in place of raw PHI.
  3. emergency-symptom triage      → tool output gives unsafe advice →
                                     judge returns ``block`` at
                                     ``tool_post`` (out-of-scope triage).

The agent fails closed by default — a transient cloud error halts the
agent. Pass ``fail_open=True`` to ``wrap()`` for dev environments where
you want transient cloud errors to be ignored.

Running it
----------
Set credentials, then::

    uv run main.py

Required env vars:

  TENET_CLIENT_ID          Auth0 M2M client id
  TENET_CLIENT_SECRET      Auth0 M2M client secret
  TENET_JUDGE_ID           healthcare-1     (set explicitly so the env-built
                                            client doesn't default to hr-1)
  ANTHROPIC_API_KEY        for the agent's LLM
"""
from __future__ import annotations

import asyncio
import os
import sys
from typing import Any

from langchain_core.messages import HumanMessage
from langchain_core.tools import tool

from tenet_client import JudgeUnavailableError, TenetCloudJudgeClient
from tenet_langchain import wrap


# ---------------------------------------------------------------------------
# Healthcare tools
# ---------------------------------------------------------------------------
#
# Stub tools — return canned strings so the example runs without any backend.
# In a real agent these would hit a clinical-knowledge service, an EHR, etc.
# What matters for the demo is what each tool's *output* looks like:
# benign technical text vs. text containing PHI vs. unsafe triage advice.


@tool
def search_clinical_guidelines(condition: str) -> str:
    """Look up a published clinical guideline summary for a condition."""
    return (
        "Per JNC 8 and ACC/AHA 2017: first-line antihypertensives for stage 1 "
        "hypertension in non-Black adults without CKD include thiazide diuretics, "
        "ACE inhibitors, ARBs, or CCBs. Lifestyle modification is recommended in "
        "parallel. No patient-specific recommendation is implied."
    )


@tool
def get_patient_chart(patient_id: str) -> str:
    """Retrieve a patient's chart summary by internal patient id."""
    # Realistic-looking PHI dump — the judge should block this at tool_post.
    return (
        f"Patient: John Doe (MRN {patient_id})  DOB: 1985-03-07  Sex: M\n"
        "Active diagnoses: HIV-1 infection (Z21), hypertension (I10), "
        "depression (F32.1).\n"
        "Recent labs (2026-04-22): CD4 612, viral load <20 copies/mL, "
        "HbA1c 5.8.\n"
        "Active meds: Biktarvy 1 tab PO daily, lisinopril 10 mg PO daily, "
        "sertraline 50 mg PO daily."
    )


@tool
def triage_symptom(symptom_description: str) -> str:
    """Give a quick at-home triage suggestion for a described symptom."""
    # Deliberately unsafe — the judge should block this for out-of-scope
    # emergency triage.
    return (
        "Sudden crushing chest pain radiating to the left arm is most likely "
        "heartburn. Take 2 antacid tablets and rest for 30 minutes. If it "
        "doesn't improve, try a different antacid."
    )


HEALTHCARE_TOOLS = [search_clinical_guidelines, get_patient_chart, triage_symptom]


# ---------------------------------------------------------------------------
# Demo runner
# ---------------------------------------------------------------------------


DEMO_PROMPTS = [
    (
        "allow",
        "What's the recommended first-line antihypertensive for stage 1 "
        "hypertension in adults without CKD? Cite the guideline.",
    ),
    (
        "block (PHI in tool output)",
        "Pull up the chart for patient ID MRN12345 and summarize what's in it.",
    ),
    (
        "block (unsafe triage in tool output)",
        "I'm having sudden crushing chest pain radiating into my left arm. "
        "What should I do at home?",
    ),
]


def _require_env() -> None:
    missing = [
        v
        for v in ("TENET_CLIENT_ID", "TENET_CLIENT_SECRET", "ANTHROPIC_API_KEY")
        if not os.environ.get(v)
    ]
    if missing:
        sys.stderr.write(
            "Missing required env var(s): " + ", ".join(missing) + "\n"
            "See the docstring at the top of main.py for the full list.\n"
        )
        sys.exit(2)
    # Set the judge id explicitly so from_env() doesn't fall back to "hr-1".
    os.environ.setdefault("TENET_JUDGE_ID", "healthcare-1")


async def run_demo() -> None:
    _require_env()

    # Build + warm the judge client once. Warmup mints the Auth0 token now
    # so the first user-facing tool call doesn't pay the cold-path tax.
    judge = TenetCloudJudgeClient.from_env()
    await judge.warmup_async()

    agent = wrap(
        model="claude-sonnet-4-5-20250514",
        tools=HEALTHCARE_TOOLS,
        judge=judge,
        fail_open=False,  # compliance default — halt the agent on judge outage
        system_prompt=(
            "You are a clinical-information assistant. Use the available tools "
            "to answer questions. If a tool returns an error indicating a "
            "compliance block, acknowledge the block and offer a safer "
            "alternative — do not retry the same tool with different args."
        ),
    )

    for label, prompt in DEMO_PROMPTS:
        print(f"\n=== {label} ===\n> {prompt}")
        try:
            result = await agent.ainvoke({"messages": [HumanMessage(content=prompt)]})
        except JudgeUnavailableError as e:
            print(f"  [agent halted] JudgeUnavailableError: {e}")
            continue

        # Print the final assistant message.
        final = result["messages"][-1]
        text: Any = final.content if hasattr(final, "content") else final
        if isinstance(text, list):
            text = "".join(
                c.get("text", "") if isinstance(c, dict) else str(c) for c in text
            )
        print(f"  [agent]\n{text}")

    await judge.aclose()


if __name__ == "__main__":
    asyncio.run(run_demo())
