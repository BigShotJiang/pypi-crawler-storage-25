"""Human-in-the-loop review prompt for Tenet + LangChain.

This example shows how an application can turn a Tenet ``review`` verdict
into a user approval prompt. LangChain agents are backed by LangGraph, so
the implementation uses ``langgraph.types.interrupt`` inside the
``JudgePolicy.on_review`` callback.

The important pieces are:

- configure a checkpointer on ``create_agent``;
- invoke the agent with a stable ``configurable.thread_id``;
- expose the interrupt payload to your UI;
- resume with ``Command(resume=...)`` using the same thread ID.
"""

from __future__ import annotations

from typing import Any

from langchain.agents import create_agent
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command, interrupt

from tenet_client import (
    JudgeAction,
    JudgeContext,
    JudgePolicy,
    JudgeVerdict,
    TenetCloudJudgeClient,
)
from tenet_langchain import TenetJudgeMiddleware


@tool
def send_claim_to_payer(case_id: str, summary: str) -> str:
    """Submit a prior authorization packet to the payer."""
    return f"Submitted prior-auth case {case_id}: {summary}"


def ask_user_on_review(ctx: JudgeContext, verdict: JudgeVerdict) -> JudgeAction:
    """Pause the agent and ask the user whether the reviewed call may proceed."""
    answer: Any = interrupt(
        {
            "kind": "tenet_review",
            "question": "Tenet recommends human review. Proceed with this tool call?",
            "tool_name": ctx.tool_name,
            "tool_input": ctx.tool_input,
            "reason": verdict.reason,
            "choices": [
                {"id": "proceed", "label": "Yes, proceed"},
                {"id": "reject", "label": "No, choose another action"},
            ],
        }
    )

    if isinstance(answer, dict) and answer.get("proceed") is True:
        return JudgeAction.allow(metadata={"tenet_review_approved": True})

    if isinstance(answer, dict):
        message = answer.get("message")
    else:
        message = None

    return JudgeAction.tool_error(
        message or "The user rejected this tool call after Tenet review."
    )


def main() -> None:
    judge = TenetCloudJudgeClient.from_env()
    policy = JudgePolicy(on_review=ask_user_on_review)

    agent = create_agent(
        model="claude-sonnet-4-5-20250514",
        tools=[send_claim_to_payer],
        middleware=[TenetJudgeMiddleware(judge, policy=policy)],
        checkpointer=InMemorySaver(),
    )

    config = {"configurable": {"thread_id": "prior-auth-case-123"}}

    # First call runs until completion or until ask_user_on_review interrupts.
    result = agent.invoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": "Submit prior-auth case PA-123 to the payer.",
                }
            ]
        },
        config=config,
        version="v2",
    )

    if result.interrupts:
        # Present result.interrupts[0].value to your UI. The UI should return
        # a JSON-serializable answer matching the shape below.
        user_selected_yes = True

        if user_selected_yes:
            resume_payload = {"proceed": True}
        else:
            resume_payload = {
                "proceed": False,
                "message": "Do not submit yet. Ask me for missing evidence first.",
            }

        final = agent.invoke(
            Command(resume=resume_payload),
            config=config,
            version="v2",
        )
        print(final)
    else:
        print(result)


if __name__ == "__main__":
    main()
