"""Tenet PII governance integration for LangChain agents.

LangChain-specific adapters built on top of the framework-agnostic
:mod:`tenet_client` SDK.

Public surface:

- :class:`TenetMiddleware` — local-server-backed PII governance (calls
  ``http://127.0.0.1:19990``).
- :class:`CloudJudgeMiddleware` — cloud-judge-backed compliance gating
  (calls ``https://api.tenetlabs.com/v1/judge/evaluate``).
- :class:`TenetCallbackHandler` / :class:`AsyncTenetCallbackHandler` —
  LangChain callback-handler shape for non-agent chains.
- :class:`TenetGuard` — drop-in PII detector for arbitrary text.
- :func:`judged` — decorator that gates any function via the cloud
  judge (re-export from :mod:`tenet_client`).

For the cloud judge or local-server SDK *without* LangChain, install
``tenet-client`` directly — it has no LangChain dependency. Cloud-judge
types like ``TenetCloudJudgeClient`` and ``JudgeUnavailableError`` live
there.
"""

from tenet_client import (
    JudgeAction,
    JudgeBlocked,
    JudgeContext,
    JudgePolicy,
    JudgeVerdict,
    judged,
)

from tenet_langchain.callback import AsyncTenetCallbackHandler, TenetCallbackHandler
from tenet_langchain.cloud_middleware import CloudJudgeMiddleware
from tenet_langchain.display import DEFAULT_EEO_TOPIC_MAPPING, RiskLabelDisplay
from tenet_langchain.events import ReviewEvent, format_review_event
from tenet_langchain.guard import TenetGuard
from tenet_langchain.middleware import TenetMiddleware
from tenet_langchain.tenet_judge_middleware import TenetJudgeMiddleware
from tenet_langchain.wrap import wrap

__all__ = [
    "AsyncTenetCallbackHandler",
    "CloudJudgeMiddleware",
    "DEFAULT_EEO_TOPIC_MAPPING",
    "JudgeAction",
    "JudgeBlocked",
    "JudgeContext",
    "JudgePolicy",
    "JudgeVerdict",
    "ReviewEvent",
    "RiskLabelDisplay",
    "TenetCallbackHandler",
    "TenetGuard",
    "TenetJudgeMiddleware",
    "TenetMiddleware",
    "format_review_event",
    "judged",
    "wrap",
]
