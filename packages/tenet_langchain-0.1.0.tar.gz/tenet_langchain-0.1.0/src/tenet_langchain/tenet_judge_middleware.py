"""Policy-first cloud-judge middleware for LangChain agents.

The developer keeps owning the agent lifecycle: build the agent with
``langchain.agents.create_agent`` yourself and pass this middleware in
the ``middleware=[...]`` list. The middleware calls the cloud judge,
turns each response into a :class:`JudgeVerdict`, and asks the
:class:`JudgePolicy` what runtime action to take. Allow / review /
block / override / human-review / fail-open / fail-closed are all
expressed as policy callbacks; nothing is hard-coded in the middleware.

For the older binary-decision middleware, see
:class:`CloudJudgeMiddleware` — it is preserved for backward
compatibility with alpha integrations.
"""

from __future__ import annotations

import hashlib
import json
import logging
import uuid
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from langchain.agents.middleware import AgentMiddleware, hook_config
from langchain.agents.middleware.types import AgentState, ToolCallRequest
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from tenet_client import (
    JudgeAction,
    JudgeContext,
    JudgePolicy,
    JudgeUnavailableError,
    JudgeVerdict,
    TenetCloudJudgeClient,
)
from tenet_client.cloud_models import CloudJudgeResponse, CloudResolutionStatus

from tenet_langchain._telemetry import RetryNudgeTelemetry
from tenet_langchain._trace import generate_span_id, generate_trace_id
from tenet_langchain._verdict import verdict_risk_labels as _verdict_risk_labels

logger = logging.getLogger(__name__)

# RFC-008 §4.4.5 heuristics for client-side "unresolved" classification.
# Documented in the README so customers can override per their tools.
_UNRESOLVED_MARKERS = ("not found", "no results", "no match", "0 results")


@dataclass(frozen=True)
class _TurnApproval:
    """A user-granted approval for a single turn, scoped by risk labels.

    When the policy returns ``allow`` on a ``review``-decision verdict
    (the user clicked "Continue anyway" via the HITL flow), the
    middleware remembers the risk labels that were approved. Subsequent
    judge calls within the same turn whose verdicts surface a SUBSET of
    those labels auto-pass without re-consulting the policy.
    """

    user_message_count: int
    risk_labels: frozenset[str]


@dataclass
class _ThreadState:
    """All per-thread bookkeeping, colocated so invalidation is O(1).

    A single ``self._threads.pop(thread_key)`` clears the verdict
    cache, the turn approval, and the last-user-message marker — no
    parallel dicts to keep in sync.
    """

    verdict_cache: dict[str, CloudJudgeResponse] = field(default_factory=dict)
    approval: _TurnApproval | None = None
    last_user_msg_count: int = 0


class TenetJudgeMiddleware(AgentMiddleware):
    """LangChain middleware that delegates every outcome to a :class:`JudgePolicy`.

    Construction shape::

        from langchain.agents import create_agent
        from tenet_client import TenetCloudJudgeClient, JudgePolicy, JudgeAction
        from tenet_langchain import TenetJudgeMiddleware

        judge = TenetCloudJudgeClient.from_env()
        policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.tool_error(v.safe_message or "blocked"),
            on_unavailable=lambda ctx, err: JudgeAction.raise_error(err),
        )

        agent = create_agent(
            model=model,
            tools=tools,
            middleware=[TenetJudgeMiddleware(judge, policy=policy), *other_middleware],
        )

    The middleware itself never calls ``create_agent``. That stays in
    application code so developers can sequence middleware, swap models,
    and structure their app the way they already do.
    """

    def __init__(
        self,
        client: TenetCloudJudgeClient,
        *,
        policy: JudgePolicy | None = None,
        check_pre: bool = True,
        check_post: bool = True,
        check_user_messages: bool = False,
        judge_tools_pre: Iterable[str] | None = None,
        judge_tools_post: Iterable[str] | None = None,
        cache_verdicts: bool = False,
        turn_approval: bool = False,
        session_id: str | None = None,
        resolution_detection: bool = True,
        resolution_detection_excluded_tools: Iterable[str] | None = None,
        retry_nudge_max_consecutive: int = 3,
    ) -> None:
        super().__init__()
        self._client = client
        self._policy = policy if policy is not None else JudgePolicy()
        self._check_pre = check_pre
        self._check_post = check_post
        self._check_user_messages = check_user_messages
        # None = judge every tool at this phase; a concrete collection
        # narrows to listed names; an empty collection skips all tools
        # at this phase.
        self._judge_tools_pre = (
            None if judge_tools_pre is None else frozenset(judge_tools_pre)
        )
        self._judge_tools_post = (
            None if judge_tools_post is None else frozenset(judge_tools_post)
        )
        self._session_id = session_id or str(uuid.uuid4())
        self._trace_id: str | None = None
        self._root_span_id: str | None = None
        self._resolution_detection = resolution_detection
        self._resolution_detection_excluded_tools = frozenset(
            resolution_detection_excluded_tools or ()
        )
        if retry_nudge_max_consecutive < 1:
            raise ValueError("retry_nudge_max_consecutive must be >= 1")
        self._retry_nudge_max_consecutive = retry_nudge_max_consecutive
        self._consecutive_retry_nudges: dict[str, int] = {}
        self.telemetry = RetryNudgeTelemetry()
        # Per-thread bookkeeping for the cache + turn approval features.
        # Keyed by thread_id when a LangGraph checkpointer is configured,
        # so multiple conversations sharing this middleware instance don't
        # see each other's verdicts or approvals.
        self._cache_verdicts_enabled = cache_verdicts
        self._turn_approval_enabled = turn_approval
        self._threads: dict[str, _ThreadState] = {}

    @classmethod
    def from_env(
        cls,
        *,
        policy: JudgePolicy | None = None,
        check_pre: bool = True,
        check_post: bool = True,
        session_id: str | None = None,
    ) -> TenetJudgeMiddleware:
        """Build the middleware and its client from ``TENET_*`` env vars.

        Required env: ``TENET_CLIENT_ID``, ``TENET_CLIENT_SECRET``.
        Optional tuning: ``TENET_JUDGE_ID``, ``TENET_JUDGE_TIMEOUT_SECONDS``.
        ``TENET_CLOUD_URL``, ``TENET_AUTH0_AUDIENCE``, and
        ``TENET_AUTH0_ISSUER_URL`` exist as escape hatches for dev /
        staging but should not be set in production.
        """
        return cls(
            TenetCloudJudgeClient.from_env(),
            policy=policy,
            check_pre=check_pre,
            check_post=check_post,
            session_id=session_id,
        )

    # -- accessors ------------------------------------------------------

    @property
    def client(self) -> TenetCloudJudgeClient:
        return self._client

    @property
    def policy(self) -> JudgePolicy:
        return self._policy

    # -- trace context per agent invocation -----------------------------

    def _new_trace(self) -> None:
        self._trace_id = generate_trace_id()
        self._root_span_id = generate_span_id()

    def _ensure_trace(self) -> None:
        if self._trace_id is None or self._root_span_id is None:
            self._new_trace()

    @hook_config(can_jump_to=["end"])
    def before_agent(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        self._new_trace()
        return None

    @hook_config(can_jump_to=["end"])
    async def abefore_agent(
        self, state: AgentState, runtime: Any
    ) -> dict[str, Any] | None:
        self._new_trace()
        return None

    # -- model boundary (user prompt judging) ---------------------------

    @hook_config(can_jump_to=["end"])
    def before_model(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        """Judge the latest HumanMessage before the model is called.

        No-op unless ``check_user_messages=True`` is set on the
        middleware. When enabled, the latest HumanMessage in ``state``
        is judged at phase ``agent_input``; the action is then mapped
        to a model-boundary effect (allow / block / override-input).
        """
        if not self._check_user_messages:
            return None
        self._ensure_trace()
        user_text = self._latest_human_text(state)
        if user_text is None:
            return None
        scope = self._begin_turn(runtime, state)
        thread_key, user_msg_count = scope if scope is not None else (None, 0)

        ctx = self._build_context(
            phase="agent_input", tool_name="", tool_input=user_text
        )
        cache_hash, cached = self._cache_lookup(
            thread_key, "agent_input", "", user_text
        )
        if cached is not None:
            verdict = JudgeVerdict.from_cloud_response(cached)
            action = self._dispatch_with_turn_approval(
                verdict, ctx, thread_key, user_msg_count
            )
            return self._apply_action_at_model_boundary(action, state)
        try:
            resp = self._client.evaluate(
                phase="agent_input",
                tool_input=user_text,
                session_id=self._session_id,
                trace_id=self._trace_id,
                parent_span_id=self._root_span_id,
            )
        except JudgeUnavailableError as err:
            action = self._policy.on_unavailable_action(ctx, err)
        else:
            self._cache_store(thread_key, cache_hash, resp)
            verdict = JudgeVerdict.from_cloud_response(resp)
            action = self._dispatch_with_turn_approval(
                verdict, ctx, thread_key, user_msg_count
            )
        return self._apply_action_at_model_boundary(action, state)

    @hook_config(can_jump_to=["end"])
    async def abefore_model(
        self, state: AgentState, runtime: Any
    ) -> dict[str, Any] | None:
        """Async variant of :meth:`before_model`."""
        if not self._check_user_messages:
            return None
        self._ensure_trace()
        user_text = self._latest_human_text(state)
        if user_text is None:
            return None
        scope = self._begin_turn(runtime, state)
        thread_key, user_msg_count = scope if scope is not None else (None, 0)

        ctx = self._build_context(
            phase="agent_input", tool_name="", tool_input=user_text
        )
        cache_hash, cached = self._cache_lookup(
            thread_key, "agent_input", "", user_text
        )
        if cached is not None:
            verdict = JudgeVerdict.from_cloud_response(cached)
            action = self._dispatch_with_turn_approval(
                verdict, ctx, thread_key, user_msg_count
            )
            return self._apply_action_at_model_boundary(action, state)
        try:
            resp = await self._client.evaluate_async(
                phase="agent_input",
                tool_input=user_text,
                session_id=self._session_id,
                trace_id=self._trace_id,
                parent_span_id=self._root_span_id,
            )
        except JudgeUnavailableError as err:
            action = self._policy.on_unavailable_action(ctx, err)
        else:
            self._cache_store(thread_key, cache_hash, resp)
            verdict = JudgeVerdict.from_cloud_response(resp)
            action = self._dispatch_with_turn_approval(
                verdict, ctx, thread_key, user_msg_count
            )
        return self._apply_action_at_model_boundary(action, state)

    def _dispatch_with_turn_approval(
        self,
        verdict: JudgeVerdict,
        ctx: JudgeContext,
        thread_key: str | None,
        user_msg_count: int,
        *,
        resolution_status: CloudResolutionStatus | None = None,
    ) -> JudgeAction:
        """Route a verdict through the policy with turn-approval bypass.

        - If turn approval covers the verdict's risk labels → auto-allow.
        - Otherwise consult the policy. If the policy allowed a review,
          record this turn's approval so the next subset-covered call
          can bypass.
        """
        # Fast path: turn approval disabled → straight to policy dispatch.
        if not self._turn_approval_enabled:
            return self._verdict_or_action(
                verdict, ctx, resolution_status=resolution_status
            )
        if self._covered_by_turn_approval(thread_key, user_msg_count, verdict):
            return JudgeAction.allow(metadata={"tenet_turn_approved": True})
        action = self._verdict_or_action(
            verdict, ctx, resolution_status=resolution_status
        )
        self._record_turn_approval_if_applicable(
            thread_key, user_msg_count, verdict, action
        )
        return action

    @staticmethod
    def _latest_human_text(state: AgentState) -> str | None:
        """Extract the most recent HumanMessage's text content from state.

        Returns ``None`` if no HumanMessage is found, so the hook can
        cheaply skip turns where the last action was a tool result.
        """
        messages = state.get("messages") if isinstance(state, dict) else None
        if not messages:
            return None
        for msg in reversed(messages):
            if isinstance(msg, HumanMessage):
                content = msg.content
                if isinstance(content, str):
                    return content
                # LangChain occasionally wraps text in list-content blocks
                # (e.g., for vision / multipart input). Flatten to a single
                # string so the judge has a plain prompt to score.
                if isinstance(content, list):
                    parts: list[str] = []
                    for part in content:
                        if isinstance(part, str):
                            parts.append(part)
                        elif isinstance(part, dict):
                            text = part.get("text")
                            if isinstance(text, str):
                                parts.append(text)
                    return " ".join(parts) if parts else ""
                return str(content)
        return None

    def _apply_action_at_model_boundary(
        self, action: JudgeAction, state: AgentState
    ) -> dict[str, Any] | None:
        """Translate a :class:`JudgeAction` into a model-boundary effect.

        - ``allow``: ``None`` (continue to the model).
        - ``block`` / ``tool_error``: append a final AIMessage and jump
          to ``end``. The agent terminates with the safe message visible
          to the caller as the assistant's final response.
        - ``override_input``: replace the latest HumanMessage with the
          override payload, then continue.
        - ``raise_error``: re-raise immediately.
        - ``human_review``: passthrough — the policy callback is
          responsible for the ``interrupt(...)`` LangGraph pause.
        - ``override_output`` / ``retry_nudge``: not meaningful at this
          boundary; log and passthrough so the agent stays alive.
        """
        if action.kind == "allow":
            return None
        if action.kind in ("tool_error", "block"):
            content = action.message or "Blocked by Tenet compliance judge."
            return {"messages": [AIMessage(content=content)], "jump_to": "end"}
        if action.kind == "override_input":
            payload = action.payload
            new_text = payload if isinstance(payload, str) else str(payload)
            existing = list(state.get("messages") or [])
            replaced = False
            for i in range(len(existing) - 1, -1, -1):
                if isinstance(existing[i], HumanMessage):
                    existing[i] = HumanMessage(content=new_text)
                    replaced = True
                    break
            if not replaced:
                existing.append(HumanMessage(content=new_text))
            return {"messages": existing}
        if action.kind == "raise_error":
            raise action.error or RuntimeError("Tenet policy raised error")
        if action.kind == "human_review":
            # Policy callback owns the interrupt; nothing to do at this boundary.
            return None
        if action.kind in ("override_output", "retry_nudge"):
            logger.warning(
                "[tenet] action %r not applicable at model boundary; allowing",
                action.kind,
            )
            return None
        logger.warning(
            "[tenet] unknown JudgeAction.kind=%r at model boundary; allowing",
            action.kind,
        )
        return None

    # -- helpers --------------------------------------------------------

    def _build_context(
        self,
        *,
        phase: str,
        tool_name: str,
        tool_input: Any,
        tool_output: Any = None,
    ) -> JudgeContext:
        return JudgeContext(
            phase=phase,  # type: ignore[arg-type]
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            session_id=self._session_id,
            trace_id=self._trace_id,
            metadata={},
        )

    @staticmethod
    def _apply_action(
        action: JudgeAction,
        *,
        request: ToolCallRequest,
        tool_call_id: str,
        tool_name: str,
        result: ToolMessage | None,
    ) -> tuple[ToolMessage | None, ToolCallRequest]:
        """Translate a :class:`JudgeAction` into a tool-boundary effect.

        Returns ``(short_circuit_message_or_None, possibly_overridden_request)``.
        - ``allow``: ``(None, request)`` → run the handler unchanged.
        - ``override_input``: ``(None, request_with_args=payload)``.
        - ``override_output``: ``(ToolMessage(content=payload), request)``.
        - ``tool_error`` / ``block``: ``(ToolMessage(status="error"), request)``.
        - ``raise_error``: re-raises immediately.
        - ``human_review``: treated like ``allow`` with a marker; the
          policy author hands off to a queue from inside the callback.
        """
        if action.kind == "allow":
            return (None, request)

        if action.kind == "override_input":
            new_args = action.payload if isinstance(action.payload, dict) else {
                "input": action.payload
            }
            new_request = request.override(
                tool_call={**request.tool_call, "args": new_args}
            )
            return (None, new_request)

        if action.kind == "override_output":
            content = (
                action.payload
                if isinstance(action.payload, str)
                else str(action.payload)
            )
            return (
                ToolMessage(
                    content=content,
                    tool_call_id=tool_call_id,
                    name=tool_name,
                ),
                request,
            )

        if action.kind in ("tool_error", "block"):
            msg = action.message or "Blocked by Tenet compliance judge."
            return (
                ToolMessage(
                    content=msg,
                    tool_call_id=tool_call_id,
                    name=tool_name,
                    status="error",
                ),
                request,
            )

        if action.kind == "retry_nudge":
            # RFC-008 §4.4.5: feed corrective guidance back to the agent
            # loop as a tool result with status="error". The step stays
            # open — the agent reads the guidance on its next iteration
            # and re-issues the tool call. Distinct from tool_error
            # (terminal denial) and override_output (replacement output).
            guidance = action.guidance or "Please reconsider this tool call."
            return (
                ToolMessage(
                    content=guidance,
                    tool_call_id=tool_call_id,
                    name=tool_name,
                    status="error",
                ),
                request,
            )

        if action.kind == "raise_error":
            err = action.error or RuntimeError("Tenet policy raised error")
            raise err

        if action.kind == "human_review":
            # Application owns hand-off; we keep the agent moving so the
            # background process (queue, dashboard, alert) can pick it up.
            return (None, request)

        # Unknown kinds fall through as allow, keeping the agent alive.
        logger.warning("[tenet] unknown JudgeAction.kind=%r — treating as allow", action.kind)
        return (None, request)

    def _verdict_or_action(
        self,
        verdict: JudgeVerdict,
        ctx: JudgeContext,
        *,
        resolution_status: CloudResolutionStatus | None = None,
    ) -> JudgeAction:
        return self._policy.decide(ctx, verdict, resolution_status=resolution_status)

    def _surface(self) -> str:
        """Telemetry surface tag — the judge_id (e.g., "hr-1", "healthcare-1")."""
        return getattr(self._client, "_judge_id", "") or ""

    def _enforce_retry_budget(
        self, action: JudgeAction, tool_name: str
    ) -> tuple[JudgeAction, bool]:
        """Apply the retry-nudge budget to an outgoing action.

        Returns ``(action, nudged)``. When the budget is exhausted, the
        retry_nudge is escalated to ``tool_error`` and ``exhausted`` is
        recorded; ``nudged`` is ``False`` in that case so end-of-call
        bookkeeping treats the call as a non-nudge. Non-retry-nudge
        actions pass through unchanged with ``nudged=False``.
        """
        if action.kind != "retry_nudge":
            return action, False
        consecutive = self._consecutive_retry_nudges.get(tool_name, 0)
        if consecutive >= self._retry_nudge_max_consecutive:
            self.telemetry.record_exhausted(self._surface(), tool_name)
            self._consecutive_retry_nudges[tool_name] = 0
            return (
                JudgeAction.tool_error(
                    f"Retry budget exhausted after {self._retry_nudge_max_consecutive} "
                    "consecutive retry-nudges; the tool repeatedly produced "
                    "unresolvable results."
                ),
                False,
            )
        self.telemetry.record_emitted(self._surface(), tool_name)
        self._consecutive_retry_nudges[tool_name] = consecutive + 1
        return action, True

    def _finalize_call_counters(self, tool_name: str, call_nudged: bool) -> None:
        """End-of-call bookkeeping: if the call did not nudge but a chain
        was pending on this tool, the agent self-corrected — record
        success and reset.
        """
        if call_nudged:
            return
        if self._consecutive_retry_nudges.get(tool_name, 0) > 0:
            self.telemetry.record_succeeded(self._surface(), tool_name)
            self._consecutive_retry_nudges[tool_name] = 0

    # -- thread-scoped cache + turn approval ----------------------------

    def _features_enabled(self) -> bool:
        """Whether any feature needs per-thread bookkeeping at all.

        When false, ``before_model``/``wrap_tool_call`` skip the
        thread-key resolution, message count, and turn-invalidation
        path entirely — keeping the prior fast-path cost essentially
        zero for integrators that don't opt in.
        """
        return self._cache_verdicts_enabled or self._turn_approval_enabled

    def _thread_key(self, runtime: Any) -> str:
        """Identify the conversation thread for cache + approval scoping.

        Prefers ``runtime.execution_info.thread_id`` so multi-thread
        LangGraph deployments do not cross-contaminate. Falls back to
        the middleware's ``session_id`` when no thread_id is available
        (no checkpointer / out-of-graph use).
        """
        if runtime is not None:
            exec_info = getattr(runtime, "execution_info", None)
            if exec_info is not None:
                thread_id = getattr(exec_info, "thread_id", None)
                if isinstance(thread_id, str) and thread_id:
                    return thread_id
        return self._session_id

    @staticmethod
    def _count_human_messages(state: AgentState) -> int:
        if not isinstance(state, dict):
            return 0
        messages = state.get("messages") or []
        return sum(1 for m in messages if isinstance(m, HumanMessage))

    def _begin_turn(
        self, runtime: Any, state: AgentState
    ) -> tuple[str, int] | None:
        """Resolve the thread key, update the turn marker, and invalidate
        per-thread state if a new HumanMessage has arrived.

        Returns ``(thread_key, user_msg_count)``, or ``None`` when no
        feature is enabled (the caller skips bookkeeping entirely).
        """
        if not self._features_enabled():
            return None
        thread_key = self._thread_key(runtime)
        user_msg_count = self._count_human_messages(state)
        ts = self._threads.get(thread_key)
        if ts is None:
            self._threads[thread_key] = _ThreadState(
                last_user_msg_count=user_msg_count
            )
        elif user_msg_count > ts.last_user_msg_count:
            # New user message → drop the prior turn's cache + approval.
            # Single dict mutation, not a rebuild.
            ts.verdict_cache.clear()
            ts.approval = None
            ts.last_user_msg_count = user_msg_count
        return thread_key, user_msg_count

    @staticmethod
    def _cache_content_hash(
        phase: str,
        tool_name: str,
        tool_input: Any,
        tool_output: Any,
        resolution_status: CloudResolutionStatus | None,
    ) -> str:
        """Stable content hash for a judge request.

        ``json.dumps`` with ``sort_keys=True`` and ``default=str``
        gives a deterministic representation even when payloads contain
        non-JSON types (e.g., datetime).
        """
        payload = json.dumps(
            {
                "phase": phase,
                "tool_name": tool_name,
                "tool_input": tool_input,
                "tool_output": tool_output,
                "resolution_status": resolution_status,
            },
            sort_keys=True,
            default=str,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _cache_lookup(
        self,
        thread_key: str | None,
        phase: str,
        tool_name: str,
        tool_input: Any,
        tool_output: Any = None,
        resolution_status: CloudResolutionStatus | None = None,
    ) -> tuple[str | None, CloudJudgeResponse | None]:
        """Return ``(content_hash, cached_response_or_None)``.

        Pass the hash back to :meth:`_cache_store` so the second call
        doesn't recompute it on a miss.
        """
        if not self._cache_verdicts_enabled or thread_key is None:
            return None, None
        ch = self._cache_content_hash(
            phase, tool_name, tool_input, tool_output, resolution_status
        )
        ts = self._threads.get(thread_key)
        if ts is None:
            return ch, None
        return ch, ts.verdict_cache.get(ch)

    def _cache_store(
        self,
        thread_key: str | None,
        content_hash: str | None,
        response: CloudJudgeResponse,
    ) -> None:
        if (
            not self._cache_verdicts_enabled
            or thread_key is None
            or content_hash is None
        ):
            return
        ts = self._threads.setdefault(thread_key, _ThreadState())
        ts.verdict_cache[content_hash] = response

    def _covered_by_turn_approval(
        self,
        thread_key: str | None,
        user_msg_count: int,
        verdict: JudgeVerdict,
    ) -> bool:
        """Whether ``verdict``'s risk labels are covered by an approval
        recorded for this thread + turn."""
        if not self._turn_approval_enabled or thread_key is None:
            return False
        ts = self._threads.get(thread_key)
        if ts is None or ts.approval is None:
            return False
        if ts.approval.user_message_count != user_msg_count:
            return False
        return frozenset(_verdict_risk_labels(verdict)).issubset(
            ts.approval.risk_labels
        )

    def _record_turn_approval_if_applicable(
        self,
        thread_key: str | None,
        user_msg_count: int,
        verdict: JudgeVerdict,
        action: JudgeAction,
    ) -> None:
        """Record turn approval when the policy returned allow on a review.

        ``block`` verdicts never grant approval — terminal denial cannot
        carry forward. Only ``review`` outcomes the policy explicitly
        allowed translate into a future-tool auto-pass.
        """
        if (
            not self._turn_approval_enabled
            or thread_key is None
            or verdict.decision != "review"
            or action.kind != "allow"
        ):
            return
        ts = self._threads.setdefault(thread_key, _ThreadState())
        ts.approval = _TurnApproval(
            user_message_count=user_msg_count,
            risk_labels=frozenset(_verdict_risk_labels(verdict)),
        )

    def _should_judge_pre(self, tool_name: str) -> bool:
        """Whether to call the judge at ``tool_pre`` for this tool.

        ``check_pre=False`` disables pre entirely. Otherwise, gated by
        ``judge_tools_pre``: ``None`` means "all tools"; a concrete
        collection narrows to listed names; an empty collection means
        "no tools at this phase".
        """
        if not self._check_pre:
            return False
        if self._judge_tools_pre is None:
            return True
        return tool_name in self._judge_tools_pre

    def _should_judge_post(self, tool_name: str) -> bool:
        """Whether to call the judge at ``tool_post`` for this tool."""
        if not self._check_post:
            return False
        if self._judge_tools_post is None:
            return True
        return tool_name in self._judge_tools_post

    def _detect_resolution_status(
        self,
        tool_name: str,
        output_text: str,
    ) -> CloudResolutionStatus | None:
        """Classify a tool's output via the RFC-008 §4.4.5 heuristics.

        Returns ``"unresolved"`` for empty containers, the literal
        ``"None"``, or known not-found markers in the output text;
        otherwise ``"resolved"``. Returns ``None`` when detection is
        disabled or this tool is excluded — callers must treat ``None``
        as "client did not classify."
        """
        if not self._resolution_detection:
            return None
        if tool_name in self._resolution_detection_excluded_tools:
            return None
        stripped = output_text.strip()
        if stripped in ("", "[]", "{}", "None"):
            return "unresolved"
        lowered = stripped.lower()
        if any(marker in lowered for marker in _UNRESOLVED_MARKERS):
            return "unresolved"
        return "resolved"

    # -- sync wrap_tool_call -------------------------------------------

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage],
    ) -> ToolMessage:
        self._ensure_trace()
        tc = request.tool_call
        tool_name = tc.get("name", "")
        tool_args = tc.get("args") or {}
        tool_call_id = tc.get("id", "")
        call_nudged = False
        scope = self._begin_turn(
            getattr(request, "runtime", None),
            getattr(request, "state", None) or {},
        )
        thread_key, user_msg_count = scope if scope is not None else (None, 0)

        try:
            if self._should_judge_pre(tool_name):
                ctx = self._build_context(
                    phase="tool_pre", tool_name=tool_name, tool_input=tool_args
                )
                cache_hash, cached = self._cache_lookup(
                    thread_key, "tool_pre", tool_name, tool_args
                )
                if cached is not None:
                    verdict = JudgeVerdict.from_cloud_response(cached)
                    action = self._dispatch_with_turn_approval(
                        verdict, ctx, thread_key, user_msg_count
                    )
                else:
                    try:
                        resp = self._client.evaluate(
                            phase="tool_pre",
                            tool_name=tool_name,
                            tool_input=tool_args,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                            parent_span_id=self._root_span_id,
                        )
                    except JudgeUnavailableError as err:
                        action = self._policy.on_unavailable_action(ctx, err)
                    else:
                        self._cache_store(thread_key, cache_hash, resp)
                        verdict = JudgeVerdict.from_cloud_response(resp)
                        action = self._dispatch_with_turn_approval(
                            verdict, ctx, thread_key, user_msg_count
                        )

                action, nudged = self._enforce_retry_budget(action, tool_name)
                call_nudged = call_nudged or nudged
                short_circuit, request = self._apply_action(
                    action,
                    request=request,
                    tool_call_id=tool_call_id,
                    tool_name=tool_name,
                    result=None,
                )
                if short_circuit is not None:
                    return short_circuit

            result = handler(request)

            if self._should_judge_post(tool_name):
                output_text = (
                    result.content if isinstance(result, ToolMessage) else str(result)
                )
                resolution_status = self._detect_resolution_status(tool_name, output_text)
                ctx = self._build_context(
                    phase="tool_post",
                    tool_name=tool_name,
                    tool_input=tool_args,
                    tool_output=output_text,
                )
                cache_hash, cached = self._cache_lookup(
                    thread_key,
                    "tool_post",
                    tool_name,
                    tool_args,
                    output_text,
                    resolution_status,
                )
                if cached is not None:
                    verdict = JudgeVerdict.from_cloud_response(cached)
                    action = self._dispatch_with_turn_approval(
                        verdict,
                        ctx,
                        thread_key,
                        user_msg_count,
                        resolution_status=resolution_status,
                    )
                else:
                    try:
                        resp = self._client.evaluate(
                            phase="tool_post",
                            tool_name=tool_name,
                            tool_input=tool_args,
                            tool_output=output_text,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                            parent_span_id=self._root_span_id,
                            resolution_status=resolution_status,
                        )
                    except JudgeUnavailableError as err:
                        action = self._policy.on_unavailable_action(ctx, err)
                    else:
                        self._cache_store(thread_key, cache_hash, resp)
                        verdict = JudgeVerdict.from_cloud_response(resp)
                        action = self._dispatch_with_turn_approval(
                            verdict,
                            ctx,
                            thread_key,
                            user_msg_count,
                            resolution_status=resolution_status,
                        )

                action, nudged = self._enforce_retry_budget(action, tool_name)
                call_nudged = call_nudged or nudged
                short_circuit, _ = self._apply_action(
                    action,
                    request=request,
                    tool_call_id=tool_call_id,
                    tool_name=tool_name,
                    result=result,
                )
                if short_circuit is not None:
                    return short_circuit

            return result
        finally:
            self._finalize_call_counters(tool_name, call_nudged)

    # -- async wrap_tool_call ------------------------------------------

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]],
    ) -> ToolMessage:
        self._ensure_trace()
        tc = request.tool_call
        tool_name = tc.get("name", "")
        tool_args = tc.get("args") or {}
        tool_call_id = tc.get("id", "")
        call_nudged = False
        scope = self._begin_turn(
            getattr(request, "runtime", None),
            getattr(request, "state", None) or {},
        )
        thread_key, user_msg_count = scope if scope is not None else (None, 0)

        try:
            if self._should_judge_pre(tool_name):
                ctx = self._build_context(
                    phase="tool_pre", tool_name=tool_name, tool_input=tool_args
                )
                cache_hash, cached = self._cache_lookup(
                    thread_key, "tool_pre", tool_name, tool_args
                )
                if cached is not None:
                    verdict = JudgeVerdict.from_cloud_response(cached)
                    action = self._dispatch_with_turn_approval(
                        verdict, ctx, thread_key, user_msg_count
                    )
                else:
                    try:
                        resp = await self._client.evaluate_async(
                            phase="tool_pre",
                            tool_name=tool_name,
                            tool_input=tool_args,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                            parent_span_id=self._root_span_id,
                        )
                    except JudgeUnavailableError as err:
                        action = self._policy.on_unavailable_action(ctx, err)
                    else:
                        self._cache_store(thread_key, cache_hash, resp)
                        verdict = JudgeVerdict.from_cloud_response(resp)
                        action = self._dispatch_with_turn_approval(
                            verdict, ctx, thread_key, user_msg_count
                        )

                action, nudged = self._enforce_retry_budget(action, tool_name)
                call_nudged = call_nudged or nudged
                short_circuit, request = self._apply_action(
                    action,
                    request=request,
                    tool_call_id=tool_call_id,
                    tool_name=tool_name,
                    result=None,
                )
                if short_circuit is not None:
                    return short_circuit

            result = await handler(request)

            if self._should_judge_post(tool_name):
                output_text = (
                    result.content if isinstance(result, ToolMessage) else str(result)
                )
                resolution_status = self._detect_resolution_status(tool_name, output_text)
                ctx = self._build_context(
                    phase="tool_post",
                    tool_name=tool_name,
                    tool_input=tool_args,
                    tool_output=output_text,
                )
                cache_hash, cached = self._cache_lookup(
                    thread_key,
                    "tool_post",
                    tool_name,
                    tool_args,
                    output_text,
                    resolution_status,
                )
                if cached is not None:
                    verdict = JudgeVerdict.from_cloud_response(cached)
                    action = self._dispatch_with_turn_approval(
                        verdict,
                        ctx,
                        thread_key,
                        user_msg_count,
                        resolution_status=resolution_status,
                    )
                else:
                    try:
                        resp = await self._client.evaluate_async(
                            phase="tool_post",
                            tool_name=tool_name,
                            tool_input=tool_args,
                            tool_output=output_text,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                            parent_span_id=self._root_span_id,
                            resolution_status=resolution_status,
                        )
                    except JudgeUnavailableError as err:
                        action = self._policy.on_unavailable_action(ctx, err)
                    else:
                        self._cache_store(thread_key, cache_hash, resp)
                        verdict = JudgeVerdict.from_cloud_response(resp)
                        action = self._dispatch_with_turn_approval(
                            verdict,
                            ctx,
                            thread_key,
                            user_msg_count,
                            resolution_status=resolution_status,
                        )

                action, nudged = self._enforce_retry_budget(action, tool_name)
                call_nudged = call_nudged or nudged
                short_circuit, _ = self._apply_action(
                    action,
                    request=request,
                    tool_call_id=tool_call_id,
                    tool_name=tool_name,
                    result=result,
                )
                if short_circuit is not None:
                    return short_circuit

            return result
        finally:
            self._finalize_call_counters(tool_name, call_nudged)
