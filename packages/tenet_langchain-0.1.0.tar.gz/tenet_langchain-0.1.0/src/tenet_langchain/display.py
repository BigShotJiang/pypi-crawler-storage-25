"""Engine risk-label → user-facing topic translation.

The cloud judge emits ``risk_labels`` like ``EEO-AGE-PROXY-01``. The UI
needs a friendly topic ("age-discrimination") for review prompts.
:class:`RiskLabelDisplay` maps category → topic with sensible defaults
the integrator can override.

Codes that don't name a hiring concern the user can act on
(``BREAKER``, ``INJECTION``, unknown categories) map to ``None`` so
display synthesis silently drops them — they're operator-only signals.
"""

from __future__ import annotations

from collections.abc import Iterable

# Default mapping of engine EEO categories to user-facing topics. The
# operator-only categories (``BREAKER`` = LLM upstream tripped its
# breaker; ``INJECTION`` = prompt-manipulation signal) are intentionally
# absent: they're not hiring concerns the user can fix by rephrasing,
# and surfacing them in the review prompt produces user-facing noise.
DEFAULT_EEO_TOPIC_MAPPING: dict[str, str] = {
    "AGE": "age-discrimination",
    "PII": "personal-information disclosure",
    "RACE": "race-or-ethnicity",
    "ETHNICITY": "race-or-ethnicity",
    "RELIGION": "religion-related",
    "DISABILITY": "disability-discrimination",
    "GENDER": "gender-discrimination",
    "SEX": "gender-discrimination",
    "NATIONAL": "national-origin",
}


_GENERIC_REVIEW_MESSAGE = (
    "This request was flagged for review. Continue only if you've verified "
    "it complies with hiring policy."
)
_GENERIC_BLOCK_MESSAGE = (
    "This request can't be completed because it would violate hiring policy."
)


class RiskLabelDisplay:
    """Map engine risk labels to user-facing topics.

    Parameters
    ----------
    mapping:
        If supplied, replaces the default mapping entirely. Use this to
        ship a custom vocabulary (e.g., healthcare instead of EEO).
    extra:
        Adds or overrides individual categories without dropping the
        defaults. Useful for incremental extensions
        (``RiskLabelDisplay(extra={"HIPAA": "health-information disclosure"})``).
    """

    def __init__(
        self,
        *,
        mapping: dict[str, str] | None = None,
        extra: dict[str, str] | None = None,
    ) -> None:
        if mapping is not None:
            self._mapping = dict(mapping)
        else:
            self._mapping = dict(DEFAULT_EEO_TOPIC_MAPPING)
        if extra:
            self._mapping.update(extra)

    def topic_for(self, label: str) -> str | None:
        """Return the user-facing topic for a label, or ``None`` to omit.

        Looks at the second segment of an ``EEO-<CATEGORY>-...`` code.
        Non-EEO labels and unmapped categories return ``None`` so the
        caller drops them from user-facing copy.
        """
        if not isinstance(label, str) or not label.startswith("EEO-"):
            return None
        parts = label.split("-", 2)
        if len(parts) < 2:
            return None
        category = parts[1].upper()
        return self._mapping.get(category)

    def compose_message(
        self,
        risk_labels: Iterable[str],
        *,
        action: str,
    ) -> str:
        """Render a "flagged for X" sentence from a list of risk labels.

        Unmapped labels are dropped before counting, so the user-facing
        copy never mentions operator-only signals. When no labels map,
        returns an empty string and lets the caller fall back to a
        generic message.

        ``action`` shapes the language: ``"review"`` uses advisory
        phrasing ("possible ... concern") because a human can override;
        ``"block"`` uses terminal phrasing ("can't be processed due to
        ...") because there is no override path.
        """
        topics: list[str] = []
        for label in risk_labels:
            topic = self.topic_for(label)
            if topic and topic not in topics:
                topics.append(topic)
        if not topics:
            return ""
        primary = topics[0]
        others = len(topics) - 1
        if others == 0:
            suffix = ""
        elif others == 1:
            suffix = " (and 1 other concern)"
        else:
            suffix = f" (and {others} other concerns)"
        if action == "block":
            return f"This request can't be processed due to a {primary} concern{suffix}."
        return f"This request raised a possible {primary} concern{suffix}."

    def display_message(
        self,
        risk_labels: Iterable[str],
        *,
        action: str,
    ) -> str:
        """Like :meth:`compose_message` but falls back to a generic
        sentence when no labels map. Use this when you need a
        guaranteed-non-empty string for the UI prompt.
        """
        composed = self.compose_message(risk_labels, action=action)
        if composed:
            return composed
        return _GENERIC_BLOCK_MESSAGE if action == "block" else _GENERIC_REVIEW_MESSAGE
