"""Shared helpers for inspecting :class:`JudgeVerdict`.

The cloud response promotes ``risk_labels`` into ``findings`` as
``{"rule_id": label}`` entries; the middleware and event formatter
both need to read them back out, so the extractor lives here.
"""

from __future__ import annotations

from tenet_client import JudgeVerdict


def verdict_risk_labels(verdict: JudgeVerdict) -> list[str]:
    """Return the engine risk labels carried by a verdict.

    Order-preserving (the cloud response's original order is preserved
    through ``findings``). Returns an empty list when the verdict has
    none or the findings shape doesn't match.
    """
    out: list[str] = []
    for f in verdict.findings or ():
        if isinstance(f, dict):
            rid = f.get("rule_id")
            if isinstance(rid, str) and rid:
                out.append(rid)
    return out
