"""``tenet_langchain.wrap`` — convenience helper (deprecated).

Façade for :func:`langchain.agents.create_agent` that attaches
:class:`CloudJudgeMiddleware` automatically. Preserved for the alpha
integrations that already adopted it.

**The primary integration path is now**::

    from langchain.agents import create_agent
    from tenet_langchain import TenetJudgeMiddleware
    from tenet_client import JudgePolicy

    agent = create_agent(
        model=model,
        tools=tools,
        middleware=[TenetJudgeMiddleware(judge, policy=JudgePolicy()), ...],
    )

Owning the ``create_agent`` call gives developers control over the rest
of their middleware stack and the policy-vs-verdict split (see
:class:`tenet_client.JudgePolicy`).
"""

from __future__ import annotations

import warnings
from typing import Any, Sequence

from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware

from tenet_client import TenetCloudJudgeClient

from tenet_langchain.cloud_middleware import CloudJudgeMiddleware


def wrap(
    *,
    model: Any,
    tools: Sequence[Any] | None = None,
    judge: TenetCloudJudgeClient | None = None,
    fail_open: bool = False,
    check_pre: bool = True,
    check_post: bool = True,
    safe_message: str = "Blocked by Tenet compliance judge.",
    session_id: str | None = None,
    extra_middleware: Sequence[AgentMiddleware] = (),
    **create_agent_kwargs: Any,
) -> Any:
    """Build a LangChain agent with the Tenet cloud judge guarding every tool call.

    Equivalent to::

        agent = create_agent(
            model=model,
            tools=tools,
            middleware=[CloudJudgeMiddleware(judge, fail_open=...), *extra_middleware],
            **create_agent_kwargs,
        )

    Args:
        model: Forwarded to :func:`create_agent`.
        tools: Forwarded to :func:`create_agent`.
        judge: A :class:`TenetCloudJudgeClient`. If omitted, one is
            built via :meth:`TenetCloudJudgeClient.from_env` — pick the
            judge by setting ``TENET_JUDGE_ID`` (default ``hr-1``).
        fail_open: On :exc:`JudgeUnavailableError`, swallow + proceed.
            Default ``False`` (fail-closed). Set ``True`` only in dev.
        check_pre, check_post: Toggle the ``tool_pre`` / ``tool_post``
            judge calls independently. Default both on.
        safe_message: Template used in the ``ToolMessage`` returned to
            the LLM on a block. The judge's ``reason`` is appended in
            parens when present.
        session_id: Pinned session id for all judge calls; defaults to
            a fresh UUID per ``wrap()`` call.
        extra_middleware: Additional middleware to install *after* the
            cloud-judge middleware. Order matters: the judge runs first.
        **create_agent_kwargs: Anything else (``system_prompt``,
            ``response_format``, ``checkpointer``, ``state_schema``, …)
            forwards to :func:`create_agent` unchanged.

    Returns:
        The compiled LangChain agent (a ``CompiledStateGraph``), ready
        for ``.invoke()`` / ``.ainvoke()``.

    Tip:
        For lowest first-call latency, build and warm up the judge
        before calling ``wrap``::

            judge = TenetCloudJudgeClient.from_env()
            await judge.warmup_async()
            agent = wrap(model=..., tools=..., judge=judge)
    """
    warnings.warn(
        "tenet_langchain.wrap() is deprecated. Build the agent yourself "
        "with langchain.agents.create_agent(...) and pass "
        "TenetJudgeMiddleware(judge, policy=JudgePolicy(...)) in the "
        "middleware list. wrap() owns the agent lifecycle, which removes "
        "control over middleware order and policy dispatch — see the "
        "tenet_langchain README for the policy-first pattern.",
        DeprecationWarning,
        stacklevel=2,
    )

    if judge is None:
        judge = TenetCloudJudgeClient.from_env()

    cloud_mw = CloudJudgeMiddleware(
        judge,
        fail_open=fail_open,
        check_pre=check_pre,
        check_post=check_post,
        safe_message=safe_message,
        session_id=session_id,
    )
    middleware = [cloud_mw, *extra_middleware]

    return create_agent(
        model,
        tools,
        middleware=middleware,
        **create_agent_kwargs,
    )
