"""Transport-agnostic review event for HITL UIs.

The middleware decides when a human should weigh in (via policy
callbacks calling ``interrupt(...)``). When an HTTP service wants to
surface that decision to the end user, it builds a :class:`ReviewEvent`
and emits it on whatever wire it uses — SSE, WebSocket, or plain JSON.

Keeping the event a plain dataclass (not a websocket-specific or
SSE-specific type) lets the same code feed multiple transports.
:meth:`ReviewEvent.to_sse` is provided for convenience; everything
else is via :meth:`ReviewEvent.to_dict`.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from tenet_client import JudgeVerdict

from tenet_langchain._verdict import verdict_risk_labels
from tenet_langchain.display import RiskLabelDisplay


_REVIEW_CHOICES: list[dict[str, str]] = [
    {"id": "proceed", "label": "Continue anyway"},
    {"id": "reject", "label": "Cancel"},
]
_BLOCK_CHOICES: list[dict[str, str]] = [
    {"id": "dismiss", "label": "Dismiss"},
]


@dataclass
class ReviewEvent:
    """A user-facing record of a tenet review or block decision.

    Attributes
    ----------
    type:
        ``"tenet_review"`` (override available) or ``"tenet_block"``
        (terminal). Determines the SSE event name in :meth:`to_sse`.
    action:
        ``"review"`` or ``"block"`` — matches ``type`` but spelled as
        the wire vocabulary an integrator's frontend can branch on.
    reason:
        Operator-facing string. Includes severity + risk labels so
        audit logs are useful even without the engine metadata.
    display_message:
        User-facing string the frontend renders verbatim.
    risk_labels:
        Raw engine codes (e.g. ``EEO-AGE-PROXY-01``). Useful for
        downstream filtering / telemetry; not shown to the end user.
    severity:
        ``low | medium | high | critical`` or ``None``.
    choices:
        UI options for the prompt. Review defaults to proceed + reject;
        block defaults to dismiss-only.
    tool_name, tool_args, tool_result:
        Present when the review fired at a tool boundary; absent for
        ``agent_input`` decisions.
    extras:
        Free-form dict the app can populate with anything that should
        round-trip through ``to_dict`` — for example, LLM-generated
        alternative prompts (kept app-side so the SDK doesn't need to
        wire in an LLM call).
    """

    type: str
    action: str
    reason: str
    display_message: str
    risk_labels: list[str] = field(default_factory=list)
    severity: str | None = None
    choices: list[dict[str, str]] = field(default_factory=list)
    tool_name: str | None = None
    tool_args: dict[str, Any] | None = None
    tool_result: str | None = None
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dict suitable for any transport.

        ``tool_*`` fields are omitted when ``None`` so ``agent_input``
        events stay compact. ``extras`` keys are merged at the top
        level so app-specific fields like ``alternatives`` appear
        alongside the standard ones.
        """
        data: dict[str, Any] = {
            "type": self.type,
            "action": self.action,
            "reason": self.reason,
            "display_message": self.display_message,
            "risk_labels": list(self.risk_labels),
            "choices": list(self.choices),
        }
        if self.severity is not None:
            data["severity"] = self.severity
        if self.tool_name is not None:
            data["tool_name"] = self.tool_name
        if self.tool_args is not None:
            data["tool_args"] = self.tool_args
        if self.tool_result is not None:
            data["tool_result"] = self.tool_result
        for k, v in self.extras.items():
            # Don't let extras clobber canonical fields — that's an
            # invariant the caller would want to see broken loudly.
            if k in data:
                raise ValueError(
                    f"extras['{k}'] collides with a canonical ReviewEvent field"
                )
            data[k] = v
        return data

    def to_sse(self) -> str:
        """Render as an SSE event (``event:`` + ``data:`` + ``\\n\\n``).

        The JSON-encoded payload is a single line per SSE protocol;
        the terminating blank line is required to flush the event.
        """
        payload = json.dumps(self.to_dict(), separators=(",", ":"))
        return f"event: {self.type}\ndata: {payload}\n\n"


def format_review_event(
    verdict: JudgeVerdict,
    *,
    tool_name: str | None = None,
    tool_args: dict[str, Any] | None = None,
    tool_result: str | None = None,
    display: RiskLabelDisplay | None = None,
    extras: dict[str, Any] | None = None,
) -> ReviewEvent:
    """Build a :class:`ReviewEvent` from a verdict.

    The middleware does not call this; the application does, from
    inside its HITL handler (typically the same coroutine that calls
    ``interrupt(...)``). This separation keeps the middleware free of
    transport concerns and lets the same verdict round-trip through
    SSE, WebSocket, or any other wire format.

    ``display`` lets you swap the EEO-code → topic mapping. Pass an
    instance with a custom vocabulary to render hospital-style topics,
    healthcare-style topics, etc. Defaults to the standard EEO mapping.
    """
    disp = display if display is not None else RiskLabelDisplay()
    action = "block" if verdict.decision == "block" else "review"
    type_ = "tenet_block" if action == "block" else "tenet_review"
    risk_labels = verdict_risk_labels(verdict)
    display_message = disp.display_message(risk_labels, action=action)
    reason = verdict.reason or _synthesize_reason(verdict.severity, risk_labels)
    choices = _BLOCK_CHOICES if action == "block" else _REVIEW_CHOICES
    return ReviewEvent(
        type=type_,
        action=action,
        reason=reason,
        display_message=display_message,
        risk_labels=risk_labels,
        severity=verdict.severity,
        choices=list(choices),
        tool_name=tool_name,
        tool_args=tool_args,
        tool_result=tool_result,
        extras=dict(extras or {}),
    )


def _synthesize_reason(severity: str | None, risk_labels: list[str]) -> str:
    """Build an operator-facing reason string from severity + labels.

    Falls back to "no reason" when neither is set so logs always have
    something printable rather than ``None``.
    """
    sev = severity or "unknown"
    if risk_labels:
        return f"severity={sev}; risks: {', '.join(risk_labels)}"
    return f"severity={sev}"
