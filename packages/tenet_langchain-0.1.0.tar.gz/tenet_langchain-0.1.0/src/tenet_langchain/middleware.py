"""LangChain AgentMiddleware for Tenet PII governance."""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any, Callable, Awaitable

from langchain.agents.middleware import AgentMiddleware, hook_config
from langchain.agents.middleware.types import AgentState, ToolCallRequest
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from tenet_client import EvaluateRequest, EvaluateResponse, TenetClient

from tenet_langchain._trace import generate_span_id, generate_trace_id
from tenet_langchain.callback import ViolationCallback

logger = logging.getLogger(__name__)


class TenetMiddleware(AgentMiddleware):
    """Tenet PII governance middleware for LangChain agents.

    Drop-in replacement for LangChain's PIIMiddleware with ML-powered
    detection, behavioral rules, and HITL support.

    Generates a W3C trace_id per agent invocation and propagates it
    through all /evaluate calls so the server can link audit events
    into a single trace tree.

    Usage::

        agent = create_agent(
            model="claude-sonnet-4-5-20250514",
            tools=[...],
            middleware=[TenetMiddleware(tenet_ids=["hipaa-safe-harbor"])],
        )
    """

    def __init__(
        self,
        server_url: str = "http://127.0.0.1:19990",
        api_key: str | None = None,
        tenet_ids: list[str] | None = None,
        strategy: str = "redact",
        apply_to_input: bool = True,
        apply_to_output: bool = True,
        apply_to_tools: bool = True,
        fail_open: bool = True,
        on_violation: ViolationCallback | None = None,
        session_id: str | None = None,
    ):
        super().__init__()
        self.client = TenetClient(base_url=server_url, api_key=api_key, fail_open=fail_open)
        self.tenet_ids = tenet_ids
        self.strategy = strategy
        self.apply_to_input = apply_to_input
        self.apply_to_output = apply_to_output
        self.apply_to_tools = apply_to_tools
        self.fail_open = fail_open
        self.on_violation = on_violation
        self.session_id = session_id or str(uuid.uuid4())

        # Trace context — generated fresh per agent invocation in before_agent
        self._trace_id: str | None = None
        self._root_span_id: str | None = None

    # ------------------------------------------------------------------
    # Trace context helpers
    # ------------------------------------------------------------------

    def _new_trace(self) -> None:
        """Generate a fresh trace_id and root span_id for a new agent invocation."""
        self._trace_id = generate_trace_id()
        self._root_span_id = generate_span_id()

    def _make_request(
        self,
        *,
        tool_name: str = "",
        tool_input: dict | str = {},
        tool_output: dict | str | None = None,
        phase: str = "pre",
        parent_span_id: str | None = None,
    ) -> EvaluateRequest:
        """Build an EvaluateRequest with trace context propagated."""
        return EvaluateRequest(
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            phase=phase,
            session_id=self.session_id,
            tenet_ids=self.tenet_ids,
            trace_id=self._trace_id,
            parent_span_id=parent_span_id or self._root_span_id,
        )

    # ------------------------------------------------------------------
    # Message helpers
    # ------------------------------------------------------------------

    def _find_last_message(self, messages, msg_type):
        for msg in reversed(messages):
            if isinstance(msg, msg_type):
                return msg
            if isinstance(msg, dict) and msg.get("role") == ("human" if msg_type is HumanMessage else "assistant"):
                return msg
        return None

    def _get_content(self, msg):
        if isinstance(msg, (HumanMessage, AIMessage)):
            return msg.content
        if isinstance(msg, dict):
            return msg.get("content", "")
        return ""

    def _replace_message(self, messages, msg_type, new_content):
        new_messages = list(messages)
        for i in range(len(new_messages) - 1, -1, -1):
            msg = new_messages[i]
            if isinstance(msg, msg_type):
                new_messages[i] = msg_type(content=new_content)
                break
            role = "human" if msg_type is HumanMessage else "assistant"
            if isinstance(msg, dict) and msg.get("role") == role:
                new_messages[i] = {**msg, "content": new_content}
                break
        return new_messages

    # ------------------------------------------------------------------
    # Core scan logic
    # ------------------------------------------------------------------

    def _handle_result(self, result: EvaluateResponse, phase: str, content: str, msg_type, messages):
        """Process an EvaluateResponse and return state update or None."""
        if not result.has_violations:
            return None

        label = "__input__" if phase == "input" else "__output__"
        if self.on_violation:
            self.on_violation(result.violations, label, {"content": content})

        if self.strategy == "block" or result.should_block:
            block_msg = (
                "I detected personally identifiable information in your message "
                "and cannot process it. Please rephrase without including PII."
            ) if phase == "input" else (
                "I generated a response that contained personally identifiable "
                "information. The response has been withheld for compliance reasons."
            )
            return {"messages": [{"role": "assistant", "content": block_msg}], "jump_to": "end"}

        if self.strategy == "redact" and result.redacted_input:
            return {"messages": self._replace_message(messages, msg_type, result.redacted_input)}

        for v in result.violations:
            logger.warning("[tenet] %s violation: %s (severity=%s, tenet=%s)", phase.title(), v.message, v.severity, v.tenet_id)
        return None

    # ------------------------------------------------------------------
    # Sync hooks
    # ------------------------------------------------------------------

    @hook_config(can_jump_to=["end"])
    def before_agent(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        # Phase 1: Generate trace_id and root span for this agent invocation
        self._new_trace()

        if not self.apply_to_input:
            return None
        messages = state.get("messages", [])
        last_human = self._find_last_message(messages, HumanMessage)
        if last_human is None:
            return None
        content = self._get_content(last_human)
        if not content or not isinstance(content, str):
            return None

        result = self.client.evaluate(self._make_request(
            tool_input=content, phase="input",
        ))
        return self._handle_result(result, "input", content, HumanMessage, messages)

    @hook_config(can_jump_to=["end"])
    def after_agent(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        if not self.apply_to_output:
            return None
        messages = state.get("messages", [])
        last_ai = self._find_last_message(messages, AIMessage)
        if last_ai is None:
            return None
        content = self._get_content(last_ai)
        if not content or not isinstance(content, str):
            return None

        result = self.client.evaluate(self._make_request(
            tool_output=content, phase="output",
        ))
        return self._handle_result(result, "output", content, AIMessage, messages)

    def wrap_tool_call(self, request: ToolCallRequest, handler: Callable[[ToolCallRequest], ToolMessage]) -> ToolMessage:
        if not self.apply_to_tools:
            return handler(request)

        tool_name = request.tool_call.get("name", "unknown")
        tool_args = request.tool_call.get("args", {})
        tool_call_id = request.tool_call.get("id", "")
        input_text = json.dumps(tool_args) if isinstance(tool_args, dict) else str(tool_args)

        # Pre-evaluation span (child of root)
        pre_span_id = generate_span_id()
        pre_result = self.client.evaluate(self._make_request(
            tool_name=tool_name,
            tool_input=tool_args if isinstance(tool_args, dict) else input_text,
            phase="pre",
            parent_span_id=pre_span_id,
        ))

        if pre_result.has_violations:
            if self.on_violation:
                self.on_violation(pre_result.violations, tool_name, tool_args)
            if pre_result.should_block:
                msgs = "; ".join(v.message for v in pre_result.violations if v.action == "block")
                return ToolMessage(content=f"[tenet] Tool '{tool_name}' blocked: {msgs}", tool_call_id=tool_call_id, status="error")
            if self.strategy == "redact" and pre_result.redacted_input:
                try:
                    redacted_args = json.loads(pre_result.redacted_input)
                except (json.JSONDecodeError, TypeError):
                    redacted_args = {"input": pre_result.redacted_input}
                request = request.override(tool_call={**request.tool_call, "args": redacted_args})

        # Tool execution
        result = handler(request)

        # Post-evaluation span (child of root)
        output_content = result.content if isinstance(result, ToolMessage) else str(result)
        if not output_content or not isinstance(output_content, str):
            return result

        post_span_id = generate_span_id()
        post_result = self.client.evaluate(self._make_request(
            tool_name=tool_name, tool_output=output_content, phase="post",
            parent_span_id=post_span_id,
        ))

        if post_result.has_violations:
            if self.on_violation:
                self.on_violation(post_result.violations, tool_name, {"output": output_content})
            for v in post_result.violations:
                logger.warning("[tenet] Tool output violation: %s (severity=%s, tenet=%s)", v.message, v.severity, v.tenet_id)
            if self.strategy == "redact" and post_result.redacted_input:
                return ToolMessage(content=post_result.redacted_input, tool_call_id=tool_call_id)

        return result

    # ------------------------------------------------------------------
    # Async hooks
    # ------------------------------------------------------------------

    async def abefore_agent(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        # Phase 1: Generate trace_id and root span for this agent invocation
        self._new_trace()

        if not self.apply_to_input:
            return None
        messages = state.get("messages", [])
        last_human = self._find_last_message(messages, HumanMessage)
        if last_human is None:
            return None
        content = self._get_content(last_human)
        if not content or not isinstance(content, str):
            return None

        result = await self.client.evaluate_async(self._make_request(
            tool_input=content, phase="input",
        ))
        return self._handle_result(result, "input", content, HumanMessage, messages)

    async def aafter_agent(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        if not self.apply_to_output:
            return None
        messages = state.get("messages", [])
        last_ai = self._find_last_message(messages, AIMessage)
        if last_ai is None:
            return None
        content = self._get_content(last_ai)
        if not content or not isinstance(content, str):
            return None

        result = await self.client.evaluate_async(self._make_request(
            tool_output=content, phase="output",
        ))
        return self._handle_result(result, "output", content, AIMessage, messages)

    async def awrap_tool_call(self, request: ToolCallRequest, handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]]) -> ToolMessage:
        if not self.apply_to_tools:
            return await handler(request)

        tool_name = request.tool_call.get("name", "unknown")
        tool_args = request.tool_call.get("args", {})
        tool_call_id = request.tool_call.get("id", "")
        input_text = json.dumps(tool_args) if isinstance(tool_args, dict) else str(tool_args)

        # Pre-evaluation span (child of root)
        pre_span_id = generate_span_id()
        pre_result = await self.client.evaluate_async(self._make_request(
            tool_name=tool_name,
            tool_input=tool_args if isinstance(tool_args, dict) else input_text,
            phase="pre",
            parent_span_id=pre_span_id,
        ))

        if pre_result.has_violations:
            if self.on_violation:
                self.on_violation(pre_result.violations, tool_name, tool_args)
            if pre_result.should_block:
                msgs = "; ".join(v.message for v in pre_result.violations if v.action == "block")
                return ToolMessage(content=f"[tenet] Tool '{tool_name}' blocked: {msgs}", tool_call_id=tool_call_id, status="error")
            if self.strategy == "redact" and pre_result.redacted_input:
                try:
                    redacted_args = json.loads(pre_result.redacted_input)
                except (json.JSONDecodeError, TypeError):
                    redacted_args = {"input": pre_result.redacted_input}
                request = request.override(tool_call={**request.tool_call, "args": redacted_args})

        # Tool execution
        result = await handler(request)

        # Post-evaluation span (child of root)
        output_content = result.content if isinstance(result, ToolMessage) else str(result)
        if not output_content or not isinstance(output_content, str):
            return result

        post_span_id = generate_span_id()
        post_result = await self.client.evaluate_async(self._make_request(
            tool_name=tool_name, tool_output=output_content, phase="post",
            parent_span_id=post_span_id,
        ))

        if post_result.has_violations:
            if self.on_violation:
                self.on_violation(post_result.violations, tool_name, {"output": output_content})
            if self.strategy == "redact" and post_result.redacted_input:
                return ToolMessage(content=post_result.redacted_input, tool_call_id=tool_call_id)

        return result
