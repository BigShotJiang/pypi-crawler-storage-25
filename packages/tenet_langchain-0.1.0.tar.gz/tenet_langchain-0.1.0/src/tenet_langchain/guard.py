"""TenetGuard -- high-level entry point for Tenet + LangChain integration."""

from __future__ import annotations

import logging

from tenet_client import TenetClient

from tenet_langchain.callback import (
    AsyncTenetCallbackHandler,
    TenetCallbackHandler,
    ViolationCallback,
)

logger = logging.getLogger(__name__)


class TenetGuard:
    """High-level entry point for adding Tenet governance to LangChain agents."""

    def __init__(
        self,
        server_url: str = "http://127.0.0.1:19990",
        api_key: str | None = None,
        tenet_ids: list[str] | None = None,
        fail_open: bool = True,
        timeout: float = 10.0,
        on_violation: ViolationCallback | None = None,
        session_id: str | None = None,
    ):
        self.client = TenetClient(
            base_url=server_url, api_key=api_key, timeout=timeout, fail_open=fail_open,
        )
        self.tenet_ids = tenet_ids
        self.fail_open = fail_open
        self.on_violation = on_violation
        self.session_id = session_id

    def callback_handler(self, session_id: str | None = None, tenet_ids: list[str] | None = None, on_violation: ViolationCallback | None = None) -> TenetCallbackHandler:
        return TenetCallbackHandler(
            client=self.client, session_id=session_id or self.session_id,
            tenet_ids=tenet_ids or self.tenet_ids,
            on_violation=on_violation or self.on_violation, fail_open=self.fail_open,
        )

    def async_callback_handler(self, session_id: str | None = None, tenet_ids: list[str] | None = None, on_violation: ViolationCallback | None = None) -> AsyncTenetCallbackHandler:
        return AsyncTenetCallbackHandler(
            client=self.client, session_id=session_id or self.session_id,
            tenet_ids=tenet_ids or self.tenet_ids,
            on_violation=on_violation or self.on_violation, fail_open=self.fail_open,
        )

    async def close(self) -> None:
        await self.client.close_async()

    def close_sync(self) -> None:
        self.client.close()

    def is_healthy(self) -> bool:
        try:
            health = self.client.health()
            return health.status == "ok" and health.model_loaded
        except Exception:
            return False

    async def is_healthy_async(self) -> bool:
        try:
            health = await self.client.health_async()
            return health.status == "ok" and health.model_loaded
        except Exception:
            return False
