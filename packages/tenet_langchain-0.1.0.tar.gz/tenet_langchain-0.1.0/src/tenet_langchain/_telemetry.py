"""Retry-nudge telemetry counters for ``TenetJudgeMiddleware``.

RFC-008 §7 Phase 4.5 deliverable. The middleware tracks three counters
keyed by ``(surface, tool)`` so dashboards can answer "is the retry-
nudge mechanic actually helping agents recover?"

- ``emitted`` — every retry-nudge synthesized into a ToolMessage.
- ``succeeded`` — every chain of one-or-more retry-nudges that ended
  with the agent self-correcting (i.e., a non-nudge tool result
  followed the nudge on the same tool).
- ``exhausted`` — every chain that hit the configurable retry budget
  and was escalated to ``tool_error``.

Kept deliberately simple — no Prometheus dep, no metrics push pipeline.
Customers wire these into whatever observability stack they already use
by reading the counters directly off the middleware instance.
"""

from __future__ import annotations

from collections import Counter


class RetryNudgeTelemetry:
    """In-memory counters for retry-nudge emit / success / exhaustion."""

    def __init__(self) -> None:
        self.emitted: Counter[tuple[str, str]] = Counter()
        self.succeeded: Counter[tuple[str, str]] = Counter()
        self.exhausted: Counter[tuple[str, str]] = Counter()

    def record_emitted(self, surface: str, tool: str) -> None:
        self.emitted[(surface, tool)] += 1

    def record_succeeded(self, surface: str, tool: str) -> None:
        self.succeeded[(surface, tool)] += 1

    def record_exhausted(self, surface: str, tool: str) -> None:
        self.exhausted[(surface, tool)] += 1
