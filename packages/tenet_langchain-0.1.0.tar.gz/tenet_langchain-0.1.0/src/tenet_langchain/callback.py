"""LangChain callback handlers for Tenet PII governance."""

from __future__ import annotations

import logging
import uuid
from typing import Any, Callable

from langchain_core.callbacks import AsyncCallbackHandler, BaseCallbackHandler

from tenet_client import (
    EvaluateRequest,
    EvaluateResponse,
    TenetClient,
    TenetViolationError,
    Violation,
)

logger = logging.getLogger(__name__)

ViolationCallback = Callable[[list[Violation], str, dict[str, Any]], None]


def _handle_result(
    result: EvaluateResponse,
    tool_name: str,
    inputs: dict[str, Any],
    on_violation: ViolationCallback | None,
) -> None:
    if not result.has_violations:
        return

    blocking: list[Violation] = []
    for v in result.violations:
        if v.action == "block":
            blocking.append(v)
        elif v.action == "warn":
            logger.warning("[tenet] Violation: %s (severity=%s, tenet=%s)", v.message, v.severity, v.tenet_id)
        elif v.action == "redact":
            if result.redacted_input is not None:
                if isinstance(inputs, dict) and "input" in inputs:
                    inputs["input"] = result.redacted_input
                logger.info("[tenet] Tool input redacted for %s", tool_name)
        elif v.action == "log":
            logger.debug("[tenet] Rule %s triggered: %s", v.rule_id, v.message)

    if on_violation:
        on_violation(result.violations, tool_name, inputs)

    if blocking:
        messages = "; ".join(v.message for v in blocking)
        raise TenetViolationError(
            f"Tenet blocked tool '{tool_name}': {messages}",
            violations=blocking,
        )


def _build_evaluate_request(
    serialized: dict[str, Any],
    input_str: str,
    *,
    run_id: uuid.UUID,
    parent_run_id: uuid.UUID | None,
    tags: list[str] | None,
    metadata: dict[str, Any] | None,
    inputs: dict[str, Any] | None,
    session_id: str,
    tenet_ids: list[str] | None,
) -> tuple[str, EvaluateRequest]:
    tool_name = serialized.get("name") or serialized.get("id", ["unknown"])[-1]
    tool_input = inputs if inputs is not None else input_str

    request = EvaluateRequest(
        tool_name=tool_name,
        tool_input=tool_input if isinstance(tool_input, (str, dict)) else str(tool_input),
        phase="pre",
        session_id=session_id,
        metadata={
            "run_id": str(run_id),
            "parent_run_id": str(parent_run_id) if parent_run_id else None,
            "tags": tags or [],
            **(metadata or {}),
        },
        tenet_ids=tenet_ids,
    )
    return tool_name, request


def _log_post_violations(
    result: EvaluateResponse,
    tool_name: str,
    output: Any,
    on_violation: ViolationCallback | None,
) -> None:
    if not result.has_violations:
        return
    for v in result.violations:
        logger.warning("[tenet] Post-execution violation: %s (severity=%s, tenet=%s)", v.message, v.severity, v.tenet_id)
    if on_violation:
        on_violation(result.violations, tool_name, {"output": output})


class TenetCallbackHandler(BaseCallbackHandler):
    """Synchronous LangChain callback handler for Tenet PII governance."""

    raise_error = True

    def __init__(
        self,
        client: TenetClient,
        session_id: str | None = None,
        tenet_ids: list[str] | None = None,
        on_violation: ViolationCallback | None = None,
        fail_open: bool = True,
    ):
        super().__init__()
        self.client = client
        self.session_id = session_id or str(uuid.uuid4())
        self.tenet_ids = tenet_ids
        self.on_violation = on_violation
        self.fail_open = fail_open
        self._chain_names: dict[str, str] = {}

    def on_chain_start(self, serialized: dict[str, Any], inputs: dict[str, Any], *, run_id: uuid.UUID, parent_run_id: uuid.UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, **kwargs: Any) -> None:
        name = serialized.get("name") or serialized.get("id", ["unknown"])[-1]
        self._chain_names[str(run_id)] = name

    def on_llm_start(self, serialized: dict[str, Any], prompts: list[str], *, run_id: uuid.UUID, parent_run_id: uuid.UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, **kwargs: Any) -> None:
        """Scan prompts for PII before they reach the LLM."""
        for prompt in prompts:
            if not prompt:
                continue
            request = EvaluateRequest(
                tool_name="__llm__",
                tool_input=prompt,
                phase="input",
                session_id=self.session_id,
                metadata={"run_id": str(run_id), "parent_run_id": str(parent_run_id) if parent_run_id else None, "tags": tags or [], **(metadata or {})},
                tenet_ids=self.tenet_ids,
            )
            result = self.client.evaluate(request)
            _handle_result(result, "__llm__", {}, self.on_violation)

    def on_tool_start(self, serialized: dict[str, Any], input_str: str, *, run_id: uuid.UUID, parent_run_id: uuid.UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, inputs: dict[str, Any] | None = None, **kwargs: Any) -> None:
        tool_name, request = _build_evaluate_request(
            serialized, input_str,
            run_id=run_id, parent_run_id=parent_run_id,
            tags=tags, metadata=metadata, inputs=inputs,
            session_id=self.session_id, tenet_ids=self.tenet_ids,
        )
        result = self.client.evaluate(request)
        _handle_result(result, tool_name, inputs or {}, self.on_violation)

    def on_tool_end(self, output: str, *, run_id: uuid.UUID, parent_run_id: uuid.UUID | None = None, **kwargs: Any) -> None:
        tool_name = kwargs.get("name", "unknown")
        request = EvaluateRequest(
            tool_name=tool_name, tool_output=output, phase="post",
            session_id=self.session_id, metadata={"run_id": str(run_id)}, tenet_ids=self.tenet_ids,
        )
        result = self.client.evaluate(request)
        _log_post_violations(result, tool_name, output, self.on_violation)


class AsyncTenetCallbackHandler(AsyncCallbackHandler):
    """Async LangChain callback handler for Tenet PII governance."""

    raise_error = True

    def __init__(
        self,
        client: TenetClient,
        session_id: str | None = None,
        tenet_ids: list[str] | None = None,
        on_violation: ViolationCallback | None = None,
        fail_open: bool = True,
    ):
        super().__init__()
        self.client = client
        self.session_id = session_id or str(uuid.uuid4())
        self.tenet_ids = tenet_ids
        self.on_violation = on_violation
        self.fail_open = fail_open
        self._chain_names: dict[str, str] = {}

    async def on_chain_start(self, serialized: dict[str, Any], inputs: dict[str, Any], *, run_id: uuid.UUID, parent_run_id: uuid.UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, **kwargs: Any) -> None:
        name = serialized.get("name") or serialized.get("id", ["unknown"])[-1]
        self._chain_names[str(run_id)] = name

    async def on_llm_start(self, serialized: dict[str, Any], prompts: list[str], *, run_id: uuid.UUID, parent_run_id: uuid.UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, **kwargs: Any) -> None:
        for prompt in prompts:
            if not prompt:
                continue
            request = EvaluateRequest(
                tool_name="__llm__", tool_input=prompt, phase="input",
                session_id=self.session_id,
                metadata={"run_id": str(run_id), "parent_run_id": str(parent_run_id) if parent_run_id else None, "tags": tags or [], **(metadata or {})},
                tenet_ids=self.tenet_ids,
            )
            result = await self.client.evaluate_async(request)
            _handle_result(result, "__llm__", {}, self.on_violation)

    async def on_tool_start(self, serialized: dict[str, Any], input_str: str, *, run_id: uuid.UUID, parent_run_id: uuid.UUID | None = None, tags: list[str] | None = None, metadata: dict[str, Any] | None = None, inputs: dict[str, Any] | None = None, **kwargs: Any) -> None:
        tool_name, request = _build_evaluate_request(
            serialized, input_str,
            run_id=run_id, parent_run_id=parent_run_id,
            tags=tags, metadata=metadata, inputs=inputs,
            session_id=self.session_id, tenet_ids=self.tenet_ids,
        )
        result = await self.client.evaluate_async(request)
        _handle_result(result, tool_name, inputs or {}, self.on_violation)

    async def on_tool_end(self, output: str, *, run_id: uuid.UUID, parent_run_id: uuid.UUID | None = None, **kwargs: Any) -> None:
        tool_name = kwargs.get("name", "unknown")
        request = EvaluateRequest(
            tool_name=tool_name, tool_output=output, phase="post",
            session_id=self.session_id, metadata={"run_id": str(run_id)}, tenet_ids=self.tenet_ids,
        )
        result = await self.client.evaluate_async(request)
        _log_post_violations(result, tool_name, output, self.on_violation)
