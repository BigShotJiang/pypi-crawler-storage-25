"""Cloud-judge middleware for LangChain agents.

Gates every tool call via :class:`TenetCloudJudgeClient`. For the
local-server-backed equivalent (``http://127.0.0.1:19990``) see
:class:`tenet_langchain.TenetMiddleware`.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Awaitable, Callable

from langchain.agents.middleware import AgentMiddleware, hook_config
from langchain.agents.middleware.types import AgentState, ToolCallRequest
from langchain_core.messages import ToolMessage

from tenet_client import JudgeUnavailableError, TenetCloudJudgeClient

from tenet_langchain._trace import generate_span_id, generate_trace_id

logger = logging.getLogger(__name__)


class CloudJudgeMiddleware(AgentMiddleware):
    """Gate every tool call via the Tenet cloud judge.

    Calls ``client.evaluate_async`` at ``tool_pre`` (before the tool
    runs) and ``tool_post`` (after the tool returns), and short-circuits
    with a ``ToolMessage(status="error")`` whenever the judge returns
    ``decision="block"``. On :exc:`JudgeUnavailableError` the middleware
    **fails closed** by default — the agent halts. Pass ``fail_open=True``
    to let transient cloud errors slip through (dev only; not
    appropriate for compliance-critical surfaces).

    Usage::

        from tenet_client import TenetCloudJudgeClient
        from tenet_langchain import CloudJudgeMiddleware

        judge = TenetCloudJudgeClient.from_env()
        await judge.warmup_async()  # mint the Auth0 token at startup
        agent = create_agent(
            model="claude-sonnet-4-5-20250514",
            tools=[...],
            middleware=[CloudJudgeMiddleware(judge, fail_open=False)],
        )

    Or build the client implicitly from ``TENET_*`` env vars::

        middleware=[CloudJudgeMiddleware.from_env(fail_open=False)]
    """

    def __init__(
        self,
        client: TenetCloudJudgeClient,
        *,
        fail_open: bool = False,
        check_pre: bool = True,
        check_post: bool = True,
        safe_message: str = "Blocked by Tenet compliance judge.",
        session_id: str | None = None,
    ) -> None:
        super().__init__()
        self._client = client
        self._fail_open = fail_open
        self._check_pre = check_pre
        self._check_post = check_post
        self._safe_message = safe_message
        self._session_id = session_id or str(uuid.uuid4())
        self._trace_id: str | None = None
        self._root_span_id: str | None = None

    @classmethod
    def from_env(cls, **kwargs: Any) -> CloudJudgeMiddleware:
        """Build the middleware and its client from ``TENET_*`` env vars.

        Required env: ``TENET_CLIENT_ID``, ``TENET_CLIENT_SECRET``.
        Optional tuning: ``TENET_JUDGE_ID`` (default ``hr-1``),
        ``TENET_JUDGE_TIMEOUT_SECONDS``. ``TENET_CLOUD_URL``,
        ``TENET_AUTH0_AUDIENCE``, and ``TENET_AUTH0_ISSUER_URL`` exist as
        escape hatches for dev / staging but should not be set in
        production.

        ``**kwargs`` forward to the middleware constructor (``fail_open``,
        ``check_pre``, ``check_post``, ``safe_message``, ``session_id``).
        For a non-env-driven judge client, build it yourself and pass to
        the regular constructor instead.
        """
        return cls(TenetCloudJudgeClient.from_env(), **kwargs)

    @property
    def client(self) -> TenetCloudJudgeClient:
        """The underlying cloud judge client (e.g. for ``warmup()``)."""
        return self._client

    # -- trace context per agent invocation ------------------------------

    def _new_trace(self) -> None:
        self._trace_id = generate_trace_id()
        self._root_span_id = generate_span_id()

    def _ensure_trace(self) -> None:
        if self._trace_id is None or self._root_span_id is None:
            self._new_trace()

    @hook_config(can_jump_to=["end"])
    def before_agent(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        self._new_trace()
        return None

    @hook_config(can_jump_to=["end"])
    async def abefore_agent(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        self._new_trace()
        return None

    # -- tool boundary gates ---------------------------------------------

    def _block_msg(
        self, *, tool_name: str, tool_call_id: str, reason: str | None
    ) -> ToolMessage:
        body = (
            f"{self._safe_message} ({reason})"
            if reason
            else self._safe_message
        )
        return ToolMessage(
            content=body,
            tool_call_id=tool_call_id,
            name=tool_name,
            status="error",
        )

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage],
    ) -> ToolMessage:
        self._ensure_trace()
        tc = request.tool_call
        tool_name = tc.get("name", "")
        tool_args = tc.get("args") or {}
        tool_call_id = tc.get("id", "")

        if self._check_pre:
            try:
                verdict = self._client.evaluate(
                    phase="tool_pre",
                    tool_name=tool_name,
                    tool_input=tool_args,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                    parent_span_id=self._root_span_id,
                )
            except JudgeUnavailableError:
                if not self._fail_open:
                    raise
                logger.debug(
                    "[tenet] cloud judge unavailable at tool_pre on %s; failing open",
                    tool_name,
                )
            else:
                if verdict.decision == "block":
                    return self._block_msg(
                        tool_name=tool_name,
                        tool_call_id=tool_call_id,
                        reason=verdict.reason,
                    )

        result = handler(request)

        if self._check_post:
            output_text = result.content if isinstance(result, ToolMessage) else str(result)
            try:
                verdict = self._client.evaluate(
                    phase="tool_post",
                    tool_name=tool_name,
                    tool_input=tool_args,
                    tool_output=output_text,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                    parent_span_id=self._root_span_id,
                )
            except JudgeUnavailableError:
                if not self._fail_open:
                    raise
                logger.debug(
                    "[tenet] cloud judge unavailable at tool_post on %s; failing open",
                    tool_name,
                )
                return result

            if verdict.decision == "block":
                return self._block_msg(
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    reason=verdict.reason,
                )

        return result

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage]],
    ) -> ToolMessage:
        self._ensure_trace()
        tc = request.tool_call
        tool_name = tc.get("name", "")
        tool_args = tc.get("args") or {}
        tool_call_id = tc.get("id", "")

        if self._check_pre:
            try:
                verdict = await self._client.evaluate_async(
                    phase="tool_pre",
                    tool_name=tool_name,
                    tool_input=tool_args,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                    parent_span_id=self._root_span_id,
                )
            except JudgeUnavailableError:
                if not self._fail_open:
                    raise
                logger.debug(
                    "[tenet] cloud judge unavailable at tool_pre on %s; failing open",
                    tool_name,
                )
            else:
                if verdict.decision == "block":
                    return self._block_msg(
                        tool_name=tool_name,
                        tool_call_id=tool_call_id,
                        reason=verdict.reason,
                    )

        result = await handler(request)

        if self._check_post:
            output_text = result.content if isinstance(result, ToolMessage) else str(result)
            try:
                verdict = await self._client.evaluate_async(
                    phase="tool_post",
                    tool_name=tool_name,
                    tool_input=tool_args,
                    tool_output=output_text,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                    parent_span_id=self._root_span_id,
                )
            except JudgeUnavailableError:
                if not self._fail_open:
                    raise
                logger.debug(
                    "[tenet] cloud judge unavailable at tool_post on %s; failing open",
                    tool_name,
                )
                return result

            if verdict.decision == "block":
                return self._block_msg(
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    reason=verdict.reason,
                )

        return result
