"""W3C trace-context helpers shared by Tenet middleware modules."""

from __future__ import annotations

import os


def generate_trace_id() -> str:
    """W3C trace_id — 128 bits as 32 lowercase hex chars."""
    return os.urandom(16).hex()


def generate_span_id() -> str:
    """W3C span_id — 64 bits as 16 lowercase hex chars."""
    return os.urandom(8).hex()
