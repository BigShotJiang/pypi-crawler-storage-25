"""Tests for turn-level approval on TenetJudgeMiddleware.

When ``turn_approval=True`` is set, once the user approves a reviewable
verdict at the model boundary (the policy returned ``allow`` on a
``review``-decision verdict), subsequent tool-call verdicts within the
same turn whose risk labels are a *subset* of the approved labels
auto-pass without consulting the policy again.

This matches HITL UX where a user clicking "Continue anyway" on an
EEO-AGE warning should not have to re-approve each individual
downstream tool call that surfaces the same risk.

Rules:
- Approval is recorded only when ``verdict.decision == "review"`` AND
  the policy returned ``JudgeAction.allow(...)``.
- ``block`` verdicts never grant approval — terminal denials cannot
  carry over.
- Approval is scoped to a single turn (HumanMessage). A new user
  message drops the approval.
- The check is strict subset: a tool call surfacing labels NOT covered
  by the approval still routes through the policy.
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

from langchain_core.messages import HumanMessage, ToolMessage

from tenet_client import (
    JudgeAction,
    JudgePolicy,
    TenetCloudJudgeClient,
)
from tenet_client.cloud_models import CloudJudgeResponse
from tenet_langchain import TenetJudgeMiddleware


def _cloud(
    verdict: str = "pass", risk_labels: list[str] | None = None
) -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow" if verdict in ("pass", "include", "fast_pass") else "block",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=10,
        verdict=verdict,
        risk_labels=risk_labels or [],
    )


def _mock_client(*responses: CloudJudgeResponse) -> MagicMock:
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = list(responses)
    c.evaluate_async = AsyncMock(side_effect=list(responses))
    return c


def _runtime(thread_id: str = "t1") -> SimpleNamespace:
    return SimpleNamespace(execution_info=SimpleNamespace(thread_id=thread_id))


def _state(messages: list) -> dict:
    return {"messages": messages}


def _tool_request(
    tool_name: str = "search",
    args: dict | None = None,
    *,
    runtime: SimpleNamespace | None = None,
    state: dict | None = None,
) -> MagicMock:
    req = MagicMock()
    req.tool_call = {"id": f"call_{tool_name}", "name": tool_name, "args": args or {}}
    req.runtime = runtime if runtime is not None else _runtime()
    req.state = state if state is not None else _state([HumanMessage("hello")])
    req.override.return_value = req
    return req


def _approve_review() -> JudgePolicy:
    """Policy that approves any review verdict (simulates user clicking
    'Continue anyway' after the policy's ``interrupt(...)`` resumes)."""
    return JudgePolicy(
        on_review=lambda ctx, v: JudgeAction.allow(
            metadata={"tenet_review_approved": True}
        )
    )


# --------------------------------------------------------------------------
# Default: turn approval disabled.
# --------------------------------------------------------------------------


class TestTurnApprovalDisabledByDefault:
    def test_each_call_routes_through_policy(self):
        """Without ``turn_approval=True``, each judge call routes through
        the policy regardless of prior approvals."""
        # 2 review verdicts → policy called twice.
        client = _mock_client(
            _cloud("route_to_human", ["EEO-AGE-PROXY-01"]),
            _cloud("route_to_human", ["EEO-AGE-PROXY-01"]),
        )
        on_review = MagicMock(return_value=JudgeAction.allow())
        mw = TenetJudgeMiddleware(
            client,
            policy=JudgePolicy(on_review=on_review),
            check_user_messages=True,
            check_post=False,
        )
        state = _state([HumanMessage("find young hires")])
        rt = _runtime()
        mw.before_model(state, rt)

        # Now a tool call with same labels — policy still consulted.
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="x"))
        mw.wrap_tool_call(
            _tool_request("search", runtime=rt, state=state), handler
        )
        assert on_review.call_count == 2


# --------------------------------------------------------------------------
# Turn approval enabled — auto-pass when labels are a subset.
# --------------------------------------------------------------------------


class TestTurnApprovalAutoPass:
    def test_subset_labels_auto_pass(self):
        """User approved EEO-AGE — a downstream tool call surfacing only
        EEO-AGE auto-passes without re-consulting the policy."""
        client = _mock_client(
            # before_model: review with labels {AGE}
            _cloud("route_to_human", ["EEO-AGE-PROXY-01"]),
            # wrap_tool_call: review with labels {AGE} — subset of approval
            _cloud("route_to_human", ["EEO-AGE-PROXY-01"]),
        )
        on_review = MagicMock(return_value=JudgeAction.allow())
        mw = TenetJudgeMiddleware(
            client,
            policy=JudgePolicy(on_review=on_review),
            check_user_messages=True,
            turn_approval=True,
            check_post=False,
        )
        state = _state([HumanMessage("find young hires")])
        rt = _runtime()
        # Step 1: user prompt — policy called once, records approval.
        mw.before_model(state, rt)
        assert on_review.call_count == 1

        # Step 2: tool call surfaces same label — auto-allow.
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="x"))
        mw.wrap_tool_call(
            _tool_request("search", runtime=rt, state=state), handler
        )
        assert on_review.call_count == 1, (
            "tool-call review covered by turn approval should not re-consult policy"
        )
        handler.assert_called_once()

    def test_superset_labels_routes_through_policy(self):
        """Tool call surfaces a label NOT in the approval set → policy
        is consulted (the user did not approve this new concern)."""
        client = _mock_client(
            _cloud("route_to_human", ["EEO-AGE-PROXY-01"]),
            _cloud("route_to_human", ["EEO-AGE-PROXY-01", "EEO-PII-01"]),
        )
        on_review = MagicMock(return_value=JudgeAction.allow())
        mw = TenetJudgeMiddleware(
            client,
            policy=JudgePolicy(on_review=on_review),
            check_user_messages=True,
            turn_approval=True,
            check_post=False,
        )
        state = _state([HumanMessage("find young hires")])
        rt = _runtime()
        mw.before_model(state, rt)
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="x"))
        mw.wrap_tool_call(
            _tool_request("search", runtime=rt, state=state), handler
        )
        # Second review had labels not all covered → policy called again.
        assert on_review.call_count == 2

    def test_block_never_grants_approval(self):
        """Even with turn_approval=True, a ``block`` verdict's labels are
        never carried forward — terminal denial can't approve anything."""
        client = _mock_client(
            _cloud("block", ["EEO-AGE-PROXY-01"]),
            _cloud("route_to_human", ["EEO-AGE-PROXY-01"]),
        )
        on_review = MagicMock(return_value=JudgeAction.allow())
        on_block = MagicMock(
            return_value=JudgeAction.allow()  # contrived — user allows past block
        )
        mw = TenetJudgeMiddleware(
            client,
            policy=JudgePolicy(on_review=on_review, on_block=on_block),
            check_user_messages=True,
            turn_approval=True,
            check_post=False,
        )
        state = _state([HumanMessage("x")])
        rt = _runtime()
        mw.before_model(state, rt)
        # block path took on_block — no approval recorded.
        assert on_block.call_count == 1
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="y"))
        mw.wrap_tool_call(_tool_request("search", runtime=rt, state=state), handler)
        # Subsequent review must route through on_review (no approval).
        assert on_review.call_count == 1

    def test_new_turn_drops_approval(self):
        """Once the user sends another HumanMessage, the prior turn's
        approval is dropped — the new turn is a fresh consent surface."""
        client = _mock_client(
            _cloud("route_to_human", ["EEO-AGE-PROXY-01"]),  # turn 1
            _cloud("route_to_human", ["EEO-AGE-PROXY-01"]),  # turn 2 (after new msg)
            _cloud("route_to_human", ["EEO-AGE-PROXY-01"]),  # tool in turn 2
        )
        on_review = MagicMock(return_value=JudgeAction.allow())
        mw = TenetJudgeMiddleware(
            client,
            policy=JudgePolicy(on_review=on_review),
            check_user_messages=True,
            turn_approval=True,
            check_post=False,
        )
        rt = _runtime()
        mw.before_model(_state([HumanMessage("first")]), rt)
        # New turn — approval drops.
        state2 = _state([HumanMessage("first"), HumanMessage("second")])
        mw.before_model(state2, rt)
        assert on_review.call_count == 2, (
            "new turn should drop the prior approval and re-consult policy"
        )

        # Tool call in turn 2 — covered by turn-2 approval now.
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="z"))
        mw.wrap_tool_call(
            _tool_request("search", runtime=rt, state=state2), handler
        )
        assert on_review.call_count == 2, (
            "tool call in turn 2 is covered by turn 2's approval"
        )
