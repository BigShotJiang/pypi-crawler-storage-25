"""Compile every ```python block in README.md.

Catches syntax rot when LangChain / tenet-client APIs drift. Does not
execute the snippets — they reference real cloud creds and live LLMs.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

README_PATH = Path(__file__).resolve().parent.parent / "README.md"


def _extract_python_blocks(markdown: str) -> list[tuple[int, str]]:
    blocks: list[tuple[int, str]] = []
    pattern = re.compile(r"^```python\s*$", re.MULTILINE)
    end_pattern = re.compile(r"^```\s*$", re.MULTILINE)

    for fence_open in pattern.finditer(markdown):
        start_idx = markdown.find("\n", fence_open.end()) + 1
        end_match = end_pattern.search(markdown, start_idx)
        if end_match is None:
            raise AssertionError(
                f"Unterminated ```python fence at offset {fence_open.start()}"
            )
        code = markdown[start_idx : end_match.start()]
        line_number = markdown.count("\n", 0, start_idx) + 1
        blocks.append((line_number, code))
    return blocks


def _readme_blocks() -> list[tuple[int, str]]:
    if not README_PATH.exists():
        pytest.fail(f"README missing: {README_PATH}")
    return _extract_python_blocks(README_PATH.read_text())


class TestReadmeSnippets:
    def test_readme_has_python_blocks(self) -> None:
        blocks = _readme_blocks()
        assert len(blocks) >= 5, (
            f"expected >= 5 ```python blocks in README.md, found {len(blocks)}"
        )

    def test_every_block_compiles(self) -> None:
        blocks = _readme_blocks()
        failures: list[str] = []
        for line_no, code in blocks:
            location = f"README.md:{line_no}"
            try:
                compile(code, location, "exec")
            except SyntaxError as e:
                failures.append(f"{location}: {e}")
        if failures:
            joined = "\n  ".join(failures)
            pytest.fail(f"README snippets failed to compile:\n  {joined}")

    def test_primary_path_uses_create_agent(self) -> None:
        # The primary integration path must instantiate create_agent +
        # TenetJudgeMiddleware. Catches accidental regression to a
        # façade-first README.
        text = README_PATH.read_text()
        assert "create_agent" in text
        assert "TenetJudgeMiddleware" in text

    def test_wrap_marked_as_deprecated(self) -> None:
        text = README_PATH.read_text().lower()
        assert "deprecated" in text
        # And specifically tied to wrap()
        assert "wrap()" in README_PATH.read_text()
