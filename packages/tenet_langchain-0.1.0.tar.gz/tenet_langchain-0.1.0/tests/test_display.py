"""Tests for ``RiskLabelDisplay`` — engine risk-label → user topic mapping.

The cloud judge emits ``risk_labels`` like ``EEO-AGE-PROXY-01``. The UI
needs a friendly topic ("age-discrimination") for the review prompt.
``RiskLabelDisplay`` does that translation, with sensible defaults the
integrator can override.

Operator-only categories (``BREAKER`` = LLM upstream tripped its
breaker; ``INJECTION`` = prompt-manipulation signal) are intentionally
mapped to ``None`` so display synthesis drops them — they aren't user
concerns. Unknown categories also drop through to ``None`` for safety.
"""

from __future__ import annotations

from tenet_langchain.display import (
    DEFAULT_EEO_TOPIC_MAPPING,
    RiskLabelDisplay,
)


# --------------------------------------------------------------------------
# Default mapping covers the major EEO categories.
# --------------------------------------------------------------------------


class TestDefaultMapping:
    def test_age_proxy_label_maps_to_age_discrimination(self):
        d = RiskLabelDisplay()
        assert d.topic_for("EEO-AGE-PROXY-01") == "age-discrimination"

    def test_pii_label_maps_to_pii_topic(self):
        d = RiskLabelDisplay()
        assert d.topic_for("EEO-PII-01") == "personal-information disclosure"

    def test_race_and_ethnicity_dedupe_to_one_topic(self):
        d = RiskLabelDisplay()
        assert d.topic_for("EEO-RACE-01") == "race-or-ethnicity"
        assert d.topic_for("EEO-ETHNICITY-01") == "race-or-ethnicity"

    def test_gender_and_sex_dedupe_to_one_topic(self):
        d = RiskLabelDisplay()
        assert d.topic_for("EEO-GENDER-01") == "gender-discrimination"
        assert d.topic_for("EEO-SEX-01") == "gender-discrimination"

    def test_disability_religion_national_origin(self):
        d = RiskLabelDisplay()
        assert d.topic_for("EEO-DISABILITY-01") == "disability-discrimination"
        assert d.topic_for("EEO-RELIGION-01") == "religion-related"
        assert d.topic_for("EEO-NATIONAL-ORIGIN-01") == "national-origin"

    def test_operator_only_codes_return_none(self):
        d = RiskLabelDisplay()
        assert d.topic_for("EEO-BREAKER-OPEN-01") is None
        assert d.topic_for("EEO-INJECTION-01") is None

    def test_unknown_category_returns_none(self):
        d = RiskLabelDisplay()
        assert d.topic_for("EEO-UNKNOWN-CATEGORY-99") is None

    def test_non_eeo_label_returns_none(self):
        d = RiskLabelDisplay()
        assert d.topic_for("OTHER-LABEL") is None
        assert d.topic_for("") is None

    def test_default_mapping_is_exported(self):
        assert isinstance(DEFAULT_EEO_TOPIC_MAPPING, dict)
        assert DEFAULT_EEO_TOPIC_MAPPING["AGE"] == "age-discrimination"


# --------------------------------------------------------------------------
# Custom mapping override.
# --------------------------------------------------------------------------


class TestCustomMapping:
    def test_extend_with_extra_categories(self):
        """``extra`` adds categories without clobbering the defaults."""
        d = RiskLabelDisplay(extra={"HIPAA": "health-information disclosure"})
        assert d.topic_for("EEO-AGE-PROXY-01") == "age-discrimination"
        assert d.topic_for("EEO-HIPAA-01") == "health-information disclosure"

    def test_override_default_category(self):
        """``extra`` values override default mappings for the same key."""
        d = RiskLabelDisplay(extra={"AGE": "ageism"})
        assert d.topic_for("EEO-AGE-PROXY-01") == "ageism"

    def test_replace_mapping_entirely(self):
        """``mapping=...`` replaces all defaults — only the supplied
        categories produce topics."""
        d = RiskLabelDisplay(mapping={"AGE": "age"})
        assert d.topic_for("EEO-AGE-01") == "age"
        # PII no longer mapped — drops through.
        assert d.topic_for("EEO-PII-01") is None


# --------------------------------------------------------------------------
# compose_message — render a "flagged for X" sentence from risk labels.
# --------------------------------------------------------------------------


class TestComposeMessage:
    def test_review_message_uses_soft_language(self):
        d = RiskLabelDisplay()
        out = d.compose_message(["EEO-AGE-PROXY-01"], action="review")
        assert "possible" in out.lower()
        assert "age-discrimination" in out

    def test_block_message_uses_terminal_language(self):
        d = RiskLabelDisplay()
        out = d.compose_message(["EEO-AGE-PROXY-01"], action="block")
        assert "can't" in out.lower() or "cannot" in out.lower()
        assert "age-discrimination" in out

    def test_multiple_topics_summarized(self):
        d = RiskLabelDisplay()
        out = d.compose_message(
            ["EEO-AGE-PROXY-01", "EEO-PII-01"], action="review"
        )
        # Primary topic appears with an "(and 1 other concern)" suffix.
        assert "age-discrimination" in out
        assert "1 other concern" in out

    def test_two_other_topics_uses_plural_suffix(self):
        d = RiskLabelDisplay()
        out = d.compose_message(
            ["EEO-AGE-PROXY-01", "EEO-PII-01", "EEO-RACE-01"],
            action="review",
        )
        assert "2 other concerns" in out

    def test_unmapped_labels_dropped_from_output(self):
        """Operator-only labels are filtered out — the user only sees
        the topics they can actually do something about."""
        d = RiskLabelDisplay()
        out = d.compose_message(
            ["EEO-AGE-PROXY-01", "EEO-BREAKER-OPEN-01", "EEO-R03"],
            action="review",
        )
        assert "age-discrimination" in out
        # No counter for the dropped labels.
        assert "1 other concern" not in out
        assert "2 other concerns" not in out

    def test_dedupe_topics(self):
        """Multiple labels mapping to the same topic collapse to one."""
        d = RiskLabelDisplay()
        out = d.compose_message(
            ["EEO-AGE-PROXY-01", "EEO-AGE-INFERENCE-02"],
            action="review",
        )
        assert "age-discrimination" in out
        assert "other concern" not in out

    def test_empty_labels_returns_empty(self):
        d = RiskLabelDisplay()
        assert d.compose_message([], action="review") == ""

    def test_all_unmapped_returns_empty(self):
        d = RiskLabelDisplay()
        assert d.compose_message(["EEO-BREAKER-OPEN-01"], action="review") == ""
