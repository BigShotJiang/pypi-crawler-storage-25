"""Tests for ``TenetJudgeMiddleware`` heuristic resolution-status detection.

RFC-008 §4.4.5: client-side detection of "unresolved" tool outcomes —
valid request, data didn't resolve (analogous to HTTP 404), distinct from
"couldn't format a valid call" (schema failure, HTTP 400) or a compliance
block. The middleware inspects the tool's return and classifies as:

- empty list / empty dict / None → unresolved
- string content containing "not found", "no results", "no match",
  "0 results" (case-insensitive) → unresolved
- otherwise → resolved

The classification is passed to ``evaluate_phase``/``evaluate`` so the
server can branch on it via rails config and so ``JudgePolicy``'s
``on_unresolved`` callback fires when appropriate. Per-tool opt-out is
supported.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import ToolMessage

from tenet_client import (
    JudgeAction,
    JudgePolicy,
    TenetCloudJudgeClient,
)
from tenet_client.cloud_models import CloudJudgeResponse
from tenet_langchain import TenetJudgeMiddleware


def _allow() -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow", judge_id="hr-1", judge_version="hr-1.0.0", latency_ms=10
    )


def _mock_client(*verdicts: CloudJudgeResponse) -> MagicMock:
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = list(verdicts)
    c.evaluate_async = AsyncMock(side_effect=list(verdicts))
    return c


def _request(tool_name: str = "search", args: dict | None = None) -> MagicMock:
    req = MagicMock()
    req.tool_call = {"id": "call_123", "name": tool_name, "args": args or {"q": "x"}}

    def _override(**kwargs):
        new = MagicMock()
        new.tool_call = {**req.tool_call, **(kwargs.get("tool_call") or {})}
        new.override = req.override
        return new

    req.override.side_effect = _override
    return req


class TestResolutionDetectionHeuristics:
    @pytest.mark.parametrize(
        "content,expected_status",
        [
            ("[]", "unresolved"),
            ("{}", "unresolved"),
            ("", "unresolved"),
            ("None", "unresolved"),
            ("Search returned no results.", "unresolved"),
            ("No matches were found for that query.", "unresolved"),
            ("not found", "unresolved"),
            ("0 results", "unresolved"),
            # Mixed-case / embedded markers also match.
            ("Result: No Results returned.", "unresolved"),
            # Clean output → resolved.
            ("Found 5 candidates", "resolved"),
            ('{"results": [{"id": 1}]}', "resolved"),
        ],
    )
    def test_classifies_tool_output(self, content: str, expected_status: str):
        # We assert the middleware calls evaluate() for tool_post with
        # resolution_status set to the heuristic classification.
        client = _mock_client(_allow(), _allow())
        mw = TenetJudgeMiddleware(client)

        def handler(req):
            return ToolMessage(content=content, tool_call_id="call_123")

        mw.wrap_tool_call(_request(), handler)
        # tool_pre, then tool_post — both calls; tool_post carries the
        # resolution_status.
        post_call_kwargs = client.evaluate.call_args_list[-1].kwargs
        assert post_call_kwargs.get("resolution_status") == expected_status


class TestResolutionDetectionOptOut:
    def test_detection_disabled_globally(self):
        client = _mock_client(_allow(), _allow())
        mw = TenetJudgeMiddleware(client, resolution_detection=False)

        def handler(req):
            return ToolMessage(content="[]", tool_call_id="call_123")

        mw.wrap_tool_call(_request(), handler)
        post_call_kwargs = client.evaluate.call_args_list[-1].kwargs
        # Detection off → no resolution_status threaded through.
        assert post_call_kwargs.get("resolution_status") is None

    def test_excluded_tool_skips_detection(self):
        client = _mock_client(_allow(), _allow())
        mw = TenetJudgeMiddleware(
            client, resolution_detection_excluded_tools={"send_email"}
        )

        def handler(req):
            return ToolMessage(content="[]", tool_call_id="call_123")

        mw.wrap_tool_call(_request(tool_name="send_email"), handler)
        post_call_kwargs = client.evaluate.call_args_list[-1].kwargs
        assert post_call_kwargs.get("resolution_status") is None

    def test_non_excluded_tool_still_detects(self):
        client = _mock_client(_allow(), _allow())
        mw = TenetJudgeMiddleware(
            client, resolution_detection_excluded_tools={"send_email"}
        )

        def handler(req):
            return ToolMessage(content="[]", tool_call_id="call_123")

        mw.wrap_tool_call(_request(tool_name="search"), handler)
        post_call_kwargs = client.evaluate.call_args_list[-1].kwargs
        assert post_call_kwargs.get("resolution_status") == "unresolved"


class TestResolutionStatusPolicyRouting:
    """When detection fires, JudgePolicy.on_unresolved should be invoked
    instead of the normal allow/review/block dispatch."""

    def test_on_unresolved_fires_separately_from_on_block(self):
        on_unresolved_calls = []
        on_block_calls = []

        def on_unresolved(ctx, v):
            on_unresolved_calls.append((ctx.phase, ctx.tool_name))
            return JudgeAction.retry_nudge("try a broader query")

        def on_block(ctx, v):
            on_block_calls.append((ctx.phase, ctx.tool_name))
            return JudgeAction.tool_error("blocked")

        policy = JudgePolicy(on_unresolved=on_unresolved, on_block=on_block)
        # Both phases allow — but tool_post returns empty list → unresolved
        # triggers the on_unresolved branch via policy.decide.
        mw = TenetJudgeMiddleware(_mock_client(_allow(), _allow()), policy=policy)

        def handler(req):
            return ToolMessage(content="[]", tool_call_id="call_123")

        result = mw.wrap_tool_call(_request(tool_name="search"), handler)
        assert ("tool_post", "search") in on_unresolved_calls
        assert on_block_calls == []  # block was never the path
        # Middleware translated the retry_nudge to a ToolMessage(error).
        assert result.status == "error"
        assert "try a broader query" in result.content


class TestResolutionDetectionAsyncParity:
    @pytest.mark.asyncio
    async def test_unresolved_detected_in_async_path(self):
        client = _mock_client(_allow(), _allow())
        mw = TenetJudgeMiddleware(client)

        async def handler(req):
            return ToolMessage(content="[]", tool_call_id="call_123")

        await mw.awrap_tool_call(_request(), handler)
        post_call_kwargs = client.evaluate_async.call_args_list[-1].kwargs
        assert post_call_kwargs.get("resolution_status") == "unresolved"
