"""Tests for ``TenetJudgeMiddleware`` retry-nudge telemetry + budget.

RFC-008 §7 Phase 4.5 deliverable. The middleware exposes three counters
keyed by (surface, tool):

- ``retry_nudge_emitted_total`` — every retry_nudge the middleware
  synthesizes into a ToolMessage.
- ``retry_nudge_retry_succeeded_total`` — when a tool call following
  one or more retry_nudges does NOT itself produce another retry_nudge
  (the agent self-corrected successfully).
- ``retry_nudge_retry_exhausted_total`` — when N consecutive
  retry_nudges fire on the same tool (default N=3); the middleware
  escalates to tool_error and surfaces a clear message.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

from langchain_core.messages import ToolMessage

from tenet_client import (
    JudgeAction,
    JudgePolicy,
    TenetCloudJudgeClient,
)
from tenet_client.cloud_models import CloudJudgeResponse
from tenet_langchain import TenetJudgeMiddleware


def _allow() -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow", judge_id="hr-1", judge_version="hr-1.0.0", latency_ms=10
    )


def _block(reason: str = "policy violation") -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="block",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=11,
        reason=reason,
    )


def _mock_client(*verdicts: CloudJudgeResponse) -> MagicMock:
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = list(verdicts)
    c.evaluate_async = AsyncMock(side_effect=list(verdicts))
    # judge_id is the "surface" tag on telemetry counters.
    c._judge_id = "hr-1"
    return c


def _request(tool_name: str = "search") -> MagicMock:
    req = MagicMock()
    req.tool_call = {"id": "call_123", "name": tool_name, "args": {"q": "x"}}

    def _override(**kwargs):
        new = MagicMock()
        new.tool_call = {**req.tool_call, **(kwargs.get("tool_call") or {})}
        new.override = req.override
        return new

    req.override.side_effect = _override
    return req


def _retry_nudge_policy() -> JudgePolicy:
    return JudgePolicy(
        on_block=lambda ctx, v: JudgeAction.retry_nudge("self-correct, please"),
    )


class TestRetryNudgeEmittedCounter:
    def test_emitted_increments_per_retry_nudge(self):
        # Force a retry_nudge via a block verdict + nudge policy.
        mw = TenetJudgeMiddleware(_mock_client(_block()), policy=_retry_nudge_policy())
        mw.wrap_tool_call(_request(tool_name="search"), MagicMock())
        assert mw.telemetry.emitted.get(("hr-1", "search")) == 1

    def test_emitted_increments_separately_per_tool(self):
        # Two tools, each blocking once → both get one nudge.
        client = _mock_client(_block(), _block())
        mw = TenetJudgeMiddleware(client, policy=_retry_nudge_policy())
        mw.wrap_tool_call(_request(tool_name="search"), MagicMock())
        mw.wrap_tool_call(_request(tool_name="lookup"), MagicMock())
        assert mw.telemetry.emitted.get(("hr-1", "search")) == 1
        assert mw.telemetry.emitted.get(("hr-1", "lookup")) == 1


class TestRetryNudgeSucceededCounter:
    def test_succeeded_on_clean_next_call_after_nudge(self):
        # First call → retry_nudge fires. Second call → clean allow.
        # The succeeded counter increments because the chain
        # self-corrected.
        client = _mock_client(
            _block(),  # call 1, tool_pre → block → nudge
            _allow(),  # call 2, tool_pre → allow
            _allow(),  # call 2, tool_post → allow
        )
        mw = TenetJudgeMiddleware(client, policy=_retry_nudge_policy())
        mw.wrap_tool_call(_request(tool_name="search"), MagicMock())

        def handler(req):
            return ToolMessage(content="clean result", tool_call_id="call_123")

        mw.wrap_tool_call(_request(tool_name="search"), handler)
        assert mw.telemetry.succeeded.get(("hr-1", "search")) == 1


class TestRetryNudgeBudgetExhaustion:
    def test_exhausted_after_default_3_consecutive(self):
        # Default budget = 3. Four consecutive blocks → 3 nudges then
        # exhaustion on the 4th.
        client = _mock_client(_block(), _block(), _block(), _block())
        mw = TenetJudgeMiddleware(client, policy=_retry_nudge_policy())
        for _ in range(4):
            mw.wrap_tool_call(_request(tool_name="search"), MagicMock())
        assert mw.telemetry.emitted.get(("hr-1", "search")) == 3
        assert mw.telemetry.exhausted.get(("hr-1", "search")) == 1

    def test_escalates_to_tool_error_after_budget_exhausted(self):
        client = _mock_client(_block(), _block(), _block(), _block())
        mw = TenetJudgeMiddleware(client, policy=_retry_nudge_policy())
        # Run through the budget — the first 3 produce retry-nudge
        # ToolMessages (with the nudge content). The 4th escalates to
        # tool_error with a clear "budget exhausted" message.
        results = [
            mw.wrap_tool_call(_request(tool_name="search"), MagicMock())
            for _ in range(4)
        ]
        for r in results[:3]:
            assert "self-correct" in r.content
        assert results[3].status == "error"
        assert "budget exhausted" in results[3].content.lower()

    def test_configurable_budget(self):
        client = _mock_client(_block(), _block())
        mw = TenetJudgeMiddleware(
            client,
            policy=_retry_nudge_policy(),
            retry_nudge_max_consecutive=1,
        )
        # Budget=1: first call → nudge; second call → exhausted.
        first = mw.wrap_tool_call(_request(tool_name="search"), MagicMock())
        second = mw.wrap_tool_call(_request(tool_name="search"), MagicMock())
        assert "self-correct" in first.content
        assert second.status == "error"
        assert "budget exhausted" in second.content.lower()


class TestTelemetryReset:
    def test_consecutive_counter_resets_on_succeeded(self):
        # Two nudges then a success → counter resets → another nudge
        # ought to count from 1 again, not 3.
        client = _mock_client(
            _block(), _block(),       # two nudges
            _allow(), _allow(),       # success
            _block(),                 # another nudge — should be #1, not #3
        )
        mw = TenetJudgeMiddleware(client, policy=_retry_nudge_policy())
        mw.wrap_tool_call(_request(tool_name="search"), MagicMock())
        mw.wrap_tool_call(_request(tool_name="search"), MagicMock())

        def handler(req):
            return ToolMessage(content="result", tool_call_id="call_123")

        mw.wrap_tool_call(_request(tool_name="search"), handler)
        # Should NOT be exhausted after this — only 2 nudges in a row
        # before the success.
        mw.wrap_tool_call(_request(tool_name="search"), MagicMock())
        assert mw.telemetry.exhausted.get(("hr-1", "search"), 0) == 0
        assert mw.telemetry.emitted.get(("hr-1", "search")) == 3
        assert mw.telemetry.succeeded.get(("hr-1", "search")) == 1
