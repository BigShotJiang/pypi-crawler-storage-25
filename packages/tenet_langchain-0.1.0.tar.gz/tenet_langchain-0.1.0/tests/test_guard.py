"""Tests for TenetGuard."""

from __future__ import annotations
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from tenet_client import HealthResponse, TenetClient

from tenet_langchain.callback import AsyncTenetCallbackHandler, TenetCallbackHandler
from tenet_langchain.guard import TenetGuard


class TestTenetGuardInit:
    def test_defaults(self):
        with patch("tenet_client.client._read_api_key", return_value=None):
            guard = TenetGuard()
        assert guard.client._base_url == "http://127.0.0.1:19990"
        assert guard.fail_open is True

    def test_custom_config(self):
        guard = TenetGuard(server_url="http://localhost:8080", api_key="my-key", tenet_ids=["hipaa-safe-harbor"], fail_open=False, session_id="s1")
        assert guard.client._base_url == "http://localhost:8080"
        assert guard.tenet_ids == ["hipaa-safe-harbor"]


class TestTenetGuardHandlers:
    def test_callback_handler(self):
        guard = TenetGuard(api_key="k", tenet_ids=["hipaa"], session_id="s1")
        handler = guard.callback_handler()
        assert isinstance(handler, TenetCallbackHandler)
        assert handler.session_id == "s1"

    def test_callback_handler_overrides(self):
        guard = TenetGuard(api_key="k", tenet_ids=["hipaa"], session_id="s1")
        handler = guard.callback_handler(session_id="s2", tenet_ids=["financial"])
        assert handler.session_id == "s2"
        assert handler.tenet_ids == ["financial"]

    def test_async_callback_handler(self):
        guard = TenetGuard(api_key="k")
        assert isinstance(guard.async_callback_handler(), AsyncTenetCallbackHandler)

    def test_on_violation_propagates(self):
        callback = MagicMock()
        guard = TenetGuard(api_key="k", on_violation=callback)
        assert guard.callback_handler().on_violation is callback


class TestTenetGuardHealth:
    def test_is_healthy_true(self):
        guard = TenetGuard(api_key="k")
        guard.client = MagicMock(spec=TenetClient)
        guard.client.health.return_value = HealthResponse(status="ok", model_loaded=True, uptime_seconds=100.0)
        assert guard.is_healthy() is True

    def test_is_healthy_false_model_not_loaded(self):
        guard = TenetGuard(api_key="k")
        guard.client = MagicMock(spec=TenetClient)
        guard.client.health.return_value = HealthResponse(status="ok", model_loaded=False, uptime_seconds=1.0)
        assert guard.is_healthy() is False

    def test_is_healthy_exception(self):
        guard = TenetGuard(api_key="k")
        guard.client = MagicMock(spec=TenetClient)
        guard.client.health.side_effect = Exception("fail")
        assert guard.is_healthy() is False

    @pytest.mark.asyncio
    async def test_is_healthy_async_true(self):
        guard = TenetGuard(api_key="k")
        guard.client = MagicMock(spec=TenetClient)
        guard.client.health_async = AsyncMock(return_value=HealthResponse(status="ok", model_loaded=True, uptime_seconds=100.0))
        assert await guard.is_healthy_async() is True

    @pytest.mark.asyncio
    async def test_is_healthy_async_exception(self):
        guard = TenetGuard(api_key="k")
        guard.client = MagicMock(spec=TenetClient)
        guard.client.health_async = AsyncMock(side_effect=Exception("fail"))
        assert await guard.is_healthy_async() is False
