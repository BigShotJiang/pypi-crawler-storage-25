"""Tests for CloudJudgeMiddleware.

Mirrors test_middleware.py style: MagicMock-spec'd client + sync/async
handler mocks. Covers:

- pre/post block paths
- pre/post allow path
- check_pre / check_post toggles
- fail_open vs fail-closed on JudgeUnavailableError
- trace_id rotation per agent invocation + lazy init in tool hook
- from_env() factory
- safe_message + reason concatenation
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import ToolMessage

from tenet_client import JudgeUnavailableError, TenetCloudJudgeClient
from tenet_client.cloud_models import CloudJudgeResponse
from tenet_langchain.cloud_middleware import CloudJudgeMiddleware


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------


def _allow(reason: str | None = None) -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=12,
        reason=reason,
    )


def _block(reason: str | None = "policy violation") -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="block",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=15,
        reason=reason,
    )


def _mock_client(*verdicts: CloudJudgeResponse) -> MagicMock:
    """Build a mocked TenetCloudJudgeClient. Each call to evaluate(_async)
    consumes the next verdict; if ``verdicts`` is exhausted the mock errors
    out, which makes off-by-one bugs in the middleware visible.
    """
    client = MagicMock(spec=TenetCloudJudgeClient)
    client.evaluate.side_effect = list(verdicts)
    client.evaluate_async = AsyncMock(side_effect=list(verdicts))
    return client


def _mock_client_raises(exc: Exception) -> MagicMock:
    client = MagicMock(spec=TenetCloudJudgeClient)
    client.evaluate.side_effect = exc
    client.evaluate_async = AsyncMock(side_effect=exc)
    return client


def _request(tool_name: str = "search", args: dict | None = None) -> MagicMock:
    req = MagicMock()
    req.tool_call = {"id": "call_123", "name": tool_name, "args": args or {"q": "x"}}
    req.override.return_value = req
    return req


# --------------------------------------------------------------------------
# Sync wrap_tool_call
# --------------------------------------------------------------------------


class TestWrapToolCallSync:
    def test_allow_passthrough_runs_handler(self):
        mw = CloudJudgeMiddleware(_mock_client(_allow(), _allow()))
        handler = MagicMock(return_value=ToolMessage(content="result", tool_call_id="call_123"))
        result = mw.wrap_tool_call(_request(), handler)
        assert result.content == "result"
        handler.assert_called_once()
        assert mw.client.evaluate.call_count == 2  # pre + post

    def test_pre_block_short_circuits_handler(self):
        mw = CloudJudgeMiddleware(_mock_client(_block("PHI in args")))
        handler = MagicMock()
        result = mw.wrap_tool_call(_request(tool_name="get_chart"), handler)
        assert result.status == "error"
        assert "Blocked by Tenet" in result.content
        assert "PHI in args" in result.content
        assert result.name == "get_chart"
        handler.assert_not_called()

    def test_post_block_replaces_tool_output(self):
        mw = CloudJudgeMiddleware(_mock_client(_allow(), _block("PHI in output")))
        handler = MagicMock(return_value=ToolMessage(content="raw PHI", tool_call_id="call_123"))
        result = mw.wrap_tool_call(_request(), handler)
        assert result.status == "error"
        assert "Blocked by Tenet" in result.content
        assert "PHI in output" in result.content
        handler.assert_called_once()

    def test_check_pre_false_skips_pre(self):
        mw = CloudJudgeMiddleware(_mock_client(_allow()), check_pre=False)
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_123"))
        mw.wrap_tool_call(_request(), handler)
        assert mw.client.evaluate.call_count == 1  # post only
        # Verify the single call was tool_post, not tool_pre.
        kwargs = mw.client.evaluate.call_args.kwargs
        assert kwargs["phase"] == "tool_post"

    def test_check_post_false_skips_post(self):
        mw = CloudJudgeMiddleware(_mock_client(_allow()), check_post=False)
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_123"))
        mw.wrap_tool_call(_request(), handler)
        assert mw.client.evaluate.call_count == 1
        assert mw.client.evaluate.call_args.kwargs["phase"] == "tool_pre"

    def test_both_phases_off_just_runs_handler(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        mw = CloudJudgeMiddleware(client, check_pre=False, check_post=False)
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_123"))
        result = mw.wrap_tool_call(_request(), handler)
        assert result.content == "ok"
        client.evaluate.assert_not_called()


class TestFailureSemanticsSync:
    def test_fail_closed_on_pre_judge_unavailable(self):
        mw = CloudJudgeMiddleware(_mock_client_raises(JudgeUnavailableError("auth0 down")))
        handler = MagicMock()
        with pytest.raises(JudgeUnavailableError):
            mw.wrap_tool_call(_request(), handler)
        handler.assert_not_called()

    def test_fail_open_on_pre_runs_handler(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        # Pre raises, post is mocked to allow so we can verify both halves run.
        client.evaluate.side_effect = [
            JudgeUnavailableError("transient"),
            _allow(),
        ]
        mw = CloudJudgeMiddleware(client, fail_open=True)
        handler = MagicMock(return_value=ToolMessage(content="ran", tool_call_id="call_123"))
        result = mw.wrap_tool_call(_request(), handler)
        assert result.content == "ran"
        handler.assert_called_once()

    def test_fail_open_on_post_returns_handler_result(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate.side_effect = [_allow(), JudgeUnavailableError("post down")]
        mw = CloudJudgeMiddleware(client, fail_open=True)
        handler = MagicMock(return_value=ToolMessage(content="raw", tool_call_id="call_123"))
        result = mw.wrap_tool_call(_request(), handler)
        assert result.content == "raw"


# --------------------------------------------------------------------------
# Async wrap_tool_call
# --------------------------------------------------------------------------


class TestAwrapToolCall:
    @pytest.mark.asyncio
    async def test_allow_passthrough(self):
        mw = CloudJudgeMiddleware(_mock_client(_allow(), _allow()))

        async def handler(req):
            return ToolMessage(content="result", tool_call_id="call_123")

        result = await mw.awrap_tool_call(_request(), handler)
        assert result.content == "result"
        assert mw.client.evaluate_async.await_count == 2

    @pytest.mark.asyncio
    async def test_pre_block_short_circuits(self):
        mw = CloudJudgeMiddleware(_mock_client(_block("nope")))
        called = []

        async def handler(req):
            called.append(req)
            return ToolMessage(content="x", tool_call_id="call_123")

        result = await mw.awrap_tool_call(_request(), handler)
        assert result.status == "error"
        assert called == []

    @pytest.mark.asyncio
    async def test_post_block_replaces_output(self):
        mw = CloudJudgeMiddleware(_mock_client(_allow(), _block("PHI")))

        async def handler(req):
            return ToolMessage(content="leak", tool_call_id="call_123")

        result = await mw.awrap_tool_call(_request(), handler)
        assert result.status == "error"
        assert "PHI" in result.content

    @pytest.mark.asyncio
    async def test_fail_closed_async(self):
        mw = CloudJudgeMiddleware(_mock_client_raises(JudgeUnavailableError("down")))

        async def handler(req):
            return ToolMessage(content="x", tool_call_id="call_123")

        with pytest.raises(JudgeUnavailableError):
            await mw.awrap_tool_call(_request(), handler)

    @pytest.mark.asyncio
    async def test_fail_open_async_runs_handler(self):
        client = MagicMock(spec=TenetCloudJudgeClient)
        client.evaluate_async = AsyncMock(
            side_effect=[JudgeUnavailableError("pre"), _allow()]
        )
        mw = CloudJudgeMiddleware(client, fail_open=True)

        async def handler(req):
            return ToolMessage(content="ran", tool_call_id="call_123")

        result = await mw.awrap_tool_call(_request(), handler)
        assert result.content == "ran"


# --------------------------------------------------------------------------
# Trace context propagation
# --------------------------------------------------------------------------


class TestTraceContext:
    def test_before_agent_rotates_trace_id(self):
        mw = CloudJudgeMiddleware(_mock_client())
        assert mw._trace_id is None
        mw.before_agent({"messages": []}, runtime=None)
        first = mw._trace_id
        assert first is not None and len(first) == 32
        assert mw._root_span_id is not None and len(mw._root_span_id) == 16

        mw.before_agent({"messages": []}, runtime=None)
        assert mw._trace_id != first

    def test_wrap_tool_call_lazy_initializes_trace(self):
        # before_agent never ran (e.g. middleware used outside an agent
        # boundary); wrap_tool_call should still produce a trace_id.
        mw = CloudJudgeMiddleware(_mock_client(_allow(), _allow()))
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_123"))
        assert mw._trace_id is None
        mw.wrap_tool_call(_request(), handler)
        assert mw._trace_id is not None

    def test_trace_id_propagated_to_evaluate(self):
        mw = CloudJudgeMiddleware(_mock_client(_allow(), _allow()))
        mw.before_agent({"messages": []}, runtime=None)
        trace = mw._trace_id

        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_123"))
        mw.wrap_tool_call(_request(), handler)

        for call in mw.client.evaluate.call_args_list:
            assert call.kwargs["trace_id"] == trace
            assert call.kwargs["parent_span_id"] == mw._root_span_id


# --------------------------------------------------------------------------
# from_env() factory
# --------------------------------------------------------------------------


class TestFromEnv:
    def test_from_env_uses_client_factory(self, monkeypatch):
        monkeypatch.setenv("TENET_CLOUD_URL", "https://api.test.tenetlabs.com")
        monkeypatch.setenv("TENET_CLIENT_ID", "test-id")
        monkeypatch.setenv("TENET_CLIENT_SECRET", "test-secret")

        mw = CloudJudgeMiddleware.from_env(fail_open=True, safe_message="custom")
        assert isinstance(mw.client, TenetCloudJudgeClient)
        assert mw._fail_open is True
        assert mw._safe_message == "custom"

    def test_from_env_missing_var_raises(self, monkeypatch):
        monkeypatch.delenv("TENET_CLIENT_ID", raising=False)
        monkeypatch.delenv("TENET_CLIENT_SECRET", raising=False)
        with pytest.raises(ValueError, match="TENET_CLIENT_ID"):
            CloudJudgeMiddleware.from_env()


# --------------------------------------------------------------------------
# Block-message formatting
# --------------------------------------------------------------------------


class TestBlockMessage:
    def test_includes_reason_when_present(self):
        mw = CloudJudgeMiddleware(_mock_client(_block("PHI exposure")))
        handler = MagicMock()
        result = mw.wrap_tool_call(_request(tool_name="t"), handler)
        assert result.content == "Blocked by Tenet compliance judge. (PHI exposure)"

    def test_omits_parens_when_no_reason(self):
        mw = CloudJudgeMiddleware(_mock_client(_block(reason=None)))
        handler = MagicMock()
        result = mw.wrap_tool_call(_request(tool_name="t"), handler)
        assert result.content == "Blocked by Tenet compliance judge."

    def test_safe_message_override(self):
        mw = CloudJudgeMiddleware(
            _mock_client(_block("x")), safe_message="HALT — review required"
        )
        handler = MagicMock()
        result = mw.wrap_tool_call(_request(tool_name="t"), handler)
        assert result.content.startswith("HALT — review required")
