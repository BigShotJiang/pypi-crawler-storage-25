"""Tests for TenetMiddleware."""

from __future__ import annotations
from unittest.mock import AsyncMock, MagicMock, patch
import pytest
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from tenet_client import EvaluateResponse, TenetClient, Violation

from tenet_langchain.middleware import TenetMiddleware


def _mock_client(response):
    client = MagicMock(spec=TenetClient)
    client.evaluate.return_value = response
    client.evaluate_async = AsyncMock(return_value=response)
    client._base_url = "http://127.0.0.1:19990"
    client._api_key = "test"
    client._fail_open = True
    return client


class TestBeforeAgent:
    def test_no_messages_returns_none(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(no_violations_response)
        assert mw.before_agent({"messages": []}, runtime=None) is None

    def test_no_human_message_returns_none(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(no_violations_response)
        assert mw.before_agent({"messages": [AIMessage(content="hello")]}, runtime=None) is None

    def test_clean_input_returns_none(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(no_violations_response)
        assert mw.before_agent({"messages": [HumanMessage(content="hello world")]}, runtime=None) is None

    def test_block_strategy_jumps_to_end(self, block_violation_response):
        mw = TenetMiddleware(api_key="k", strategy="block")
        mw.client = _mock_client(block_violation_response)
        result = mw.before_agent({"messages": [HumanMessage(content="SSN: 123-45-6789")]}, runtime=None)
        assert result is not None
        assert result["jump_to"] == "end"

    def test_redact_strategy_modifies_message(self, redact_violation_response):
        mw = TenetMiddleware(api_key="k", strategy="redact")
        mw.client = _mock_client(redact_violation_response)
        result = mw.before_agent({"messages": [HumanMessage(content="email: user@example.com")]}, runtime=None)
        assert result is not None
        found = any(isinstance(m, HumanMessage) and "[EMAIL_1]" in m.content for m in result["messages"])
        assert found

    def test_warn_strategy_returns_none(self, warn_violation_response):
        mw = TenetMiddleware(api_key="k", strategy="warn")
        mw.client = _mock_client(warn_violation_response)
        assert mw.before_agent({"messages": [HumanMessage(content="some PII")]}, runtime=None) is None

    def test_apply_to_input_false_skips(self, block_violation_response):
        mw = TenetMiddleware(api_key="k", apply_to_input=False)
        mw.client = _mock_client(block_violation_response)
        assert mw.before_agent({"messages": [HumanMessage(content="SSN")]}, runtime=None) is None
        mw.client.evaluate.assert_not_called()

    def test_on_violation_callback(self, block_violation_response):
        callback = MagicMock()
        mw = TenetMiddleware(api_key="k", strategy="block", on_violation=callback)
        mw.client = _mock_client(block_violation_response)
        mw.before_agent({"messages": [HumanMessage(content="PII")]}, runtime=None)
        callback.assert_called_once()


class TestAfterAgent:
    def test_clean_output_returns_none(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(no_violations_response)
        assert mw.after_agent({"messages": [AIMessage(content="Hello!")]}, runtime=None) is None

    def test_block_output_jumps_to_end(self, block_violation_response):
        mw = TenetMiddleware(api_key="k", strategy="block")
        mw.client = _mock_client(block_violation_response)
        result = mw.after_agent({"messages": [AIMessage(content="Patient SSN is 123-45-6789")]}, runtime=None)
        assert result is not None and result["jump_to"] == "end"

    def test_redact_output_modifies_message(self, redact_violation_response):
        mw = TenetMiddleware(api_key="k", strategy="redact")
        mw.client = _mock_client(redact_violation_response)
        result = mw.after_agent({"messages": [AIMessage(content="email: user@example.com")]}, runtime=None)
        assert result is not None
        found = any(isinstance(m, AIMessage) and "[EMAIL_1]" in m.content for m in result["messages"])
        assert found

    def test_apply_to_output_false_skips(self, block_violation_response):
        mw = TenetMiddleware(api_key="k", apply_to_output=False)
        mw.client = _mock_client(block_violation_response)
        assert mw.after_agent({"messages": [AIMessage(content="PII output")]}, runtime=None) is None


class TestWrapToolCall:
    def _make_request(self, tool_name="search", args=None):
        req = MagicMock()
        req.tool_call = {"id": "call_123", "name": tool_name, "args": args or {"query": "test"}}
        req.override.return_value = req
        return req

    def test_clean_passthrough(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(no_violations_response)
        handler = MagicMock(return_value=ToolMessage(content="result", tool_call_id="call_123"))
        result = mw.wrap_tool_call(self._make_request(), handler)
        assert result.content == "result"

    def test_block_returns_error_message(self, block_violation_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(block_violation_response)
        handler = MagicMock()
        result = mw.wrap_tool_call(self._make_request(tool_name="shell"), handler)
        assert "[tenet]" in result.content and result.status == "error"
        handler.assert_not_called()

    def test_redact_output(self):
        pre = EvaluateResponse(violations=[], has_violations=False, should_block=False, processing_time_ms=1.0)
        post = EvaluateResponse(
            violations=[Violation(rule_id="r1", rule_name="PII", tenet_id="hipaa", severity="warning", action="redact", message="PII in output")],
            has_violations=True, should_block=False, redacted_input="Patient [NAME_1] has condition X", processing_time_ms=2.0,
        )
        mw = TenetMiddleware(api_key="k", strategy="redact")
        client = MagicMock(spec=TenetClient)
        client.evaluate.side_effect = [pre, post]
        mw.client = client
        handler = MagicMock(return_value=ToolMessage(content="Patient John Smith has condition X", tool_call_id="call_123"))
        result = mw.wrap_tool_call(self._make_request(), handler)
        assert result.content == "Patient [NAME_1] has condition X"

    def test_apply_to_tools_false_skips(self, block_violation_response):
        mw = TenetMiddleware(api_key="k", apply_to_tools=False)
        mw.client = _mock_client(block_violation_response)
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_123"))
        assert mw.wrap_tool_call(self._make_request(), handler).content == "ok"
        mw.client.evaluate.assert_not_called()


class TestAsyncMiddleware:
    @pytest.mark.asyncio
    async def test_abefore_agent_block(self, block_violation_response):
        mw = TenetMiddleware(api_key="k", strategy="block")
        mw.client = MagicMock(spec=TenetClient)
        mw.client.evaluate_async = AsyncMock(return_value=block_violation_response)
        result = await mw.abefore_agent({"messages": [HumanMessage(content="SSN")]}, runtime=None)
        assert result is not None and result["jump_to"] == "end"

    @pytest.mark.asyncio
    async def test_aafter_agent_clean(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = MagicMock(spec=TenetClient)
        mw.client.evaluate_async = AsyncMock(return_value=no_violations_response)
        assert await mw.aafter_agent({"messages": [AIMessage(content="ok")]}, runtime=None) is None

    @pytest.mark.asyncio
    async def test_awrap_tool_call_passthrough(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = MagicMock(spec=TenetClient)
        mw.client.evaluate_async = AsyncMock(return_value=no_violations_response)
        request = MagicMock()
        request.tool_call = {"id": "c1", "name": "search", "args": {"q": "test"}}
        async def handler(req): return ToolMessage(content="result", tool_call_id="c1")
        assert (await mw.awrap_tool_call(request, handler)).content == "result"


class TestTenetMiddlewareInit:
    def test_defaults(self):
        with patch("tenet_client.client._read_api_key", return_value=None):
            mw = TenetMiddleware()
        assert mw.strategy == "redact"
        assert mw.apply_to_input is True

    def test_custom_config(self):
        mw = TenetMiddleware(api_key="k", tenet_ids=["hipaa"], strategy="block", apply_to_input=False)
        assert mw.strategy == "block" and mw.apply_to_input is False


class TestTraceContext:
    """Verify Phase 1: trace_id generation and propagation."""

    def test_before_agent_generates_trace_id(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(no_violations_response)
        assert mw._trace_id is None

        mw.before_agent({"messages": [HumanMessage(content="hello")]}, runtime=None)

        assert mw._trace_id is not None
        assert len(mw._trace_id) == 32
        assert mw._root_span_id is not None
        assert len(mw._root_span_id) == 16

    def test_trace_id_propagated_to_evaluate(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(no_violations_response)
        mw.before_agent({"messages": [HumanMessage(content="hello")]}, runtime=None)

        call_args = mw.client.evaluate.call_args
        req = call_args[0][0]
        assert req.trace_id == mw._trace_id
        assert req.parent_span_id == mw._root_span_id

    def test_wrap_tool_call_uses_same_trace_id(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(no_violations_response)
        # Initialize trace via before_agent
        mw.before_agent({"messages": [HumanMessage(content="hello")]}, runtime=None)
        trace_id = mw._trace_id
        mw.client.evaluate.reset_mock()

        request = MagicMock()
        request.tool_call = {"id": "c1", "name": "search", "args": {"q": "test"}}
        def handler(req): return ToolMessage(content="result", tool_call_id="c1")
        mw.wrap_tool_call(request, handler)

        # Both pre and post evaluations should use the same trace_id
        for call in mw.client.evaluate.call_args_list:
            req = call[0][0]
            assert req.trace_id == trace_id

    def test_new_invocation_gets_new_trace_id(self, no_violations_response):
        mw = TenetMiddleware(api_key="k")
        mw.client = _mock_client(no_violations_response)

        mw.before_agent({"messages": [HumanMessage(content="hello")]}, runtime=None)
        first_trace = mw._trace_id

        mw.before_agent({"messages": [HumanMessage(content="world")]}, runtime=None)
        second_trace = mw._trace_id

        assert first_trace != second_trace
        assert len(second_trace) == 32
