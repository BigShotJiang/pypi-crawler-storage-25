"""Shared fixtures for tenet-langchain tests."""

from __future__ import annotations

import pytest

from tenet_client import EvaluateResponse, Violation


@pytest.fixture
def no_violations_response() -> EvaluateResponse:
    return EvaluateResponse(
        violations=[], has_violations=False, should_block=False, processing_time_ms=1.0,
    )


@pytest.fixture
def block_violation_response() -> EvaluateResponse:
    return EvaluateResponse(
        violations=[Violation(
            rule_id="r1", rule_name="Block Shell", tenet_id="security",
            severity="critical", action="block", message="Tool 'shell' is blocklisted",
        )],
        has_violations=True, should_block=True, processing_time_ms=2.0,
    )


@pytest.fixture
def warn_violation_response() -> EvaluateResponse:
    return EvaluateResponse(
        violations=[Violation(
            rule_id="r2", rule_name="PII Scan", tenet_id="hipaa",
            severity="warning", action="warn", message="PII detected in tool input: EMAIL",
        )],
        has_violations=True, should_block=False, processing_time_ms=3.0,
    )


@pytest.fixture
def redact_violation_response() -> EvaluateResponse:
    return EvaluateResponse(
        violations=[Violation(
            rule_id="r3", rule_name="Redact Input", tenet_id="hipaa",
            severity="warning", action="redact", message="PII detected, input redacted",
        )],
        has_violations=True, should_block=False,
        redacted_input="Hello [EMAIL_1]", processing_time_ms=4.0,
    )
