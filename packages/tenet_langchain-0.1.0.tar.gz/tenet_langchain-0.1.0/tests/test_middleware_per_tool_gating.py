"""Tests for per-tool gating on TenetJudgeMiddleware.

The middleware lets integrators judge only specific tools at each phase.
This matches integrations like Scout, where mutating tools
(``schedule_interview``) are judged pre-execution, read tools
(``top_candidates``) are judged post-execution, and the rest run
unjudged for latency.

Semantics:
- ``judge_tools_pre=None`` (default) — judge every tool at tool_pre when
  ``check_pre=True``. Preserves prior behavior.
- ``judge_tools_pre=[...]`` — judge only the listed tools at tool_pre.
- ``judge_tools_pre=[]`` — judge no tools at tool_pre (effectively the
  same as ``check_pre=False``, but expressed at the gating layer).
- Same for ``judge_tools_post``.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import ToolMessage

from tenet_client import TenetCloudJudgeClient
from tenet_client.cloud_models import CloudJudgeResponse
from tenet_langchain import TenetJudgeMiddleware


def _allow() -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=10,
    )


def _mock_client(*verdicts: CloudJudgeResponse) -> MagicMock:
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = list(verdicts) or [_allow()] * 8
    c.evaluate_async = AsyncMock(side_effect=list(verdicts) or [_allow()] * 8)
    return c


def _request(tool_name: str, args: dict | None = None) -> MagicMock:
    req = MagicMock()
    req.tool_call = {
        "id": f"call_{tool_name}",
        "name": tool_name,
        "args": args or {},
    }
    req.override.return_value = req
    return req


# --------------------------------------------------------------------------
# Sync
# --------------------------------------------------------------------------


class TestPerToolGatingSync:
    def test_default_judges_every_tool_pre_and_post(self):
        """No explicit list = preserve prior behavior (judge everything)."""
        client = _mock_client()
        mw = TenetJudgeMiddleware(client)
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_search"))
        mw.wrap_tool_call(_request("search"), handler)
        # 2 calls: pre + post
        assert client.evaluate.call_count == 2

    def test_judge_tools_pre_skips_unlisted_pre_call(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client,
            judge_tools_pre=["schedule_interview"],
            check_post=False,
        )
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_search"))
        # "search" is NOT in judge_tools_pre — pre should be skipped entirely.
        mw.wrap_tool_call(_request("search"), handler)
        assert client.evaluate.call_count == 0
        handler.assert_called_once()

    def test_judge_tools_pre_runs_pre_for_listed_tool(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client,
            judge_tools_pre=["schedule_interview"],
            check_post=False,
        )
        handler = MagicMock(
            return_value=ToolMessage(content="ok", tool_call_id="call_schedule_interview")
        )
        mw.wrap_tool_call(_request("schedule_interview"), handler)
        assert client.evaluate.call_count == 1
        assert client.evaluate.call_args.kwargs["phase"] == "tool_pre"

    def test_judge_tools_post_skips_unlisted_post_call(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client,
            check_pre=False,
            judge_tools_post=["top_candidates"],
        )
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_search"))
        mw.wrap_tool_call(_request("search"), handler)
        assert client.evaluate.call_count == 0

    def test_judge_tools_post_runs_post_for_listed_tool(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client,
            check_pre=False,
            judge_tools_post=["top_candidates"],
        )
        handler = MagicMock(
            return_value=ToolMessage(content="ok", tool_call_id="call_top_candidates")
        )
        mw.wrap_tool_call(_request("top_candidates"), handler)
        assert client.evaluate.call_count == 1
        assert client.evaluate.call_args.kwargs["phase"] == "tool_post"

    def test_combined_pre_and_post_gating(self):
        """Pre-list and post-list combine — Scout-style: pre for mutating,
        post for read, nothing else."""
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client,
            judge_tools_pre=["schedule_interview", "send_phone_screen"],
            judge_tools_post=["top_candidates"],
        )
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="x"))

        # search: NOT in either list → 0 calls
        mw.wrap_tool_call(_request("search"), handler)
        assert client.evaluate.call_count == 0

        # schedule_interview: in pre list → 1 call (pre)
        mw.wrap_tool_call(_request("schedule_interview"), handler)
        assert client.evaluate.call_count == 1
        assert client.evaluate.call_args.kwargs["phase"] == "tool_pre"

        # top_candidates: in post list → 1 call (post)
        mw.wrap_tool_call(_request("top_candidates"), handler)
        assert client.evaluate.call_count == 2
        assert client.evaluate.call_args.kwargs["phase"] == "tool_post"

    def test_empty_judge_tools_pre_skips_all_pre(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client,
            judge_tools_pre=[],  # explicit empty = skip ALL pre
            check_post=False,
        )
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="call_x"))
        mw.wrap_tool_call(_request("anything"), handler)
        assert client.evaluate.call_count == 0


# --------------------------------------------------------------------------
# Async
# --------------------------------------------------------------------------


class TestPerToolGatingAsync:
    @pytest.mark.asyncio
    async def test_async_default_judges_everything(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(client)

        async def handler(req):
            return ToolMessage(content="ok", tool_call_id="call_search")

        await mw.awrap_tool_call(_request("search"), handler)
        assert client.evaluate_async.await_count == 2

    @pytest.mark.asyncio
    async def test_async_per_tool_pre_gating(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client,
            judge_tools_pre=["schedule_interview"],
            check_post=False,
        )

        async def handler(req):
            return ToolMessage(content="ok", tool_call_id="call_search")

        await mw.awrap_tool_call(_request("search"), handler)
        assert client.evaluate_async.await_count == 0

        async def handler2(req):
            return ToolMessage(content="ok", tool_call_id="call_schedule_interview")

        await mw.awrap_tool_call(_request("schedule_interview"), handler2)
        assert client.evaluate_async.await_count == 1
