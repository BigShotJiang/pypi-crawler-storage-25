"""Tests for ``tenet_langchain.wrap`` — guarded-agent façade."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from tenet_client import TenetCloudJudgeClient
from tenet_langchain import wrap
from tenet_langchain.cloud_middleware import CloudJudgeMiddleware


def _judge() -> MagicMock:
    return MagicMock(spec=TenetCloudJudgeClient)


class TestWrap:
    def test_passes_judge_through_as_middleware(self):
        judge = _judge()
        with patch("tenet_langchain.wrap.create_agent") as ca:
            ca.return_value = "AGENT"
            agent = wrap(model="claude-x", tools=[], judge=judge)

        assert agent == "AGENT"
        ca.assert_called_once()
        kwargs = ca.call_args.kwargs
        middleware = kwargs["middleware"]
        assert len(middleware) == 1
        assert isinstance(middleware[0], CloudJudgeMiddleware)
        assert middleware[0].client is judge

    def test_propagates_failure_knobs_to_middleware(self):
        judge = _judge()
        with patch("tenet_langchain.wrap.create_agent") as ca:
            wrap(
                model="m",
                tools=[],
                judge=judge,
                fail_open=True,
                check_pre=False,
                check_post=True,
                safe_message="HALT",
            )
        mw = ca.call_args.kwargs["middleware"][0]
        assert mw._fail_open is True
        assert mw._check_pre is False
        assert mw._check_post is True
        assert mw._safe_message == "HALT"

    def test_extra_middleware_appended_after_judge(self):
        judge = _judge()
        extra1 = MagicMock(name="extra1")
        extra2 = MagicMock(name="extra2")
        with patch("tenet_langchain.wrap.create_agent") as ca:
            wrap(model="m", tools=[], judge=judge, extra_middleware=[extra1, extra2])
        middleware = ca.call_args.kwargs["middleware"]
        assert isinstance(middleware[0], CloudJudgeMiddleware)
        assert middleware[1] is extra1
        assert middleware[2] is extra2

    def test_create_agent_kwargs_pass_through(self):
        judge = _judge()
        with patch("tenet_langchain.wrap.create_agent") as ca:
            wrap(
                model="m",
                tools=["t"],
                judge=judge,
                system_prompt="SP",
                debug=True,
            )
        kwargs = ca.call_args.kwargs
        # tools come through as a positional, model too
        positional = ca.call_args.args
        assert positional == ("m", ["t"])
        assert kwargs["system_prompt"] == "SP"
        assert kwargs["debug"] is True

    def test_omitted_judge_falls_back_to_from_env(self, monkeypatch):
        monkeypatch.setenv("TENET_CLOUD_URL", "https://api.test.tenetlabs.com")
        monkeypatch.setenv("TENET_CLIENT_ID", "id")
        monkeypatch.setenv("TENET_CLIENT_SECRET", "sec")

        with patch("tenet_langchain.wrap.create_agent") as ca, patch(
            "tenet_langchain.wrap.TenetCloudJudgeClient.from_env"
        ) as from_env:
            built = MagicMock(spec=TenetCloudJudgeClient)
            from_env.return_value = built
            wrap(model="m", tools=[])

        from_env.assert_called_once()
        mw = ca.call_args.kwargs["middleware"][0]
        assert mw.client is built

    def test_omitted_judge_propagates_from_env_error(self, monkeypatch):
        monkeypatch.delenv("TENET_CLIENT_ID", raising=False)
        monkeypatch.delenv("TENET_CLIENT_SECRET", raising=False)
        with pytest.raises(ValueError, match="TENET_CLIENT_ID"):
            wrap(model="m", tools=[])


class TestWrapDeprecation:
    """``wrap()`` is being demoted to a convenience helper. The primary
    integration path is now ``create_agent(...)`` + ``TenetJudgeMiddleware``.
    ``wrap()`` should still work for alpha integrations but emit a
    ``DeprecationWarning`` pointing at the new path.
    """

    def test_emits_deprecation_warning(self):
        judge = _judge()
        with patch("tenet_langchain.wrap.create_agent"):
            with pytest.warns(DeprecationWarning, match="TenetJudgeMiddleware"):
                wrap(model="m", tools=[], judge=judge)

    def test_still_returns_agent(self):
        judge = _judge()
        with patch("tenet_langchain.wrap.create_agent") as ca:
            ca.return_value = "AGENT"
            with pytest.warns(DeprecationWarning):
                agent = wrap(model="m", tools=[], judge=judge)
        assert agent == "AGENT"
