"""Tests for ``ReviewEvent`` and ``format_review_event``.

``ReviewEvent`` is a transport-agnostic record of a tenet review or
block decision. The HTTP server can render it as SSE / WebSocket /
plain JSON without the middleware knowing or caring about the wire
format.

Shape:

- ``type``: ``"tenet_review"`` or ``"tenet_block"``
- ``action``: ``"review"`` or ``"block"``
- ``reason``: operator-facing string (severity + risk labels)
- ``display_message``: user-facing string (friendly topics)
- ``risk_labels``: raw engine codes (for downstream filtering)
- ``severity``: low/medium/high/critical or None
- ``choices``: list of ``{"id", "label"}`` shown to the user; the
  ``"review"`` UI defaults to proceed/reject, ``"block"`` to dismiss
- ``tool_name`` / ``tool_args`` / ``tool_result``: present for
  tool-boundary reviews; omitted for ``agent_input``
- ``extras``: free-form dict for app-specific fields (e.g. alternatives)
"""

from __future__ import annotations

import json

from tenet_client import JudgeVerdict
from tenet_langchain import format_review_event
from tenet_langchain.events import ReviewEvent


def _verdict(decision: str = "review", risk_labels: list[str] | None = None,
             severity: str | None = "medium", reason: str | None = None) -> JudgeVerdict:
    findings = [{"rule_id": rl} for rl in (risk_labels or [])]
    return JudgeVerdict(
        decision=decision,  # type: ignore[arg-type]
        status="ok" if decision == "allow" else "triggered",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=10,
        severity=severity,  # type: ignore[arg-type]
        reason=reason,
        findings=findings,
    )


class TestReviewEventShape:
    def test_review_event_basic_fields(self):
        ev = format_review_event(
            _verdict("review", ["EEO-AGE-PROXY-01"])
        )
        assert isinstance(ev, ReviewEvent)
        assert ev.type == "tenet_review"
        assert ev.action == "review"
        assert "age-discrimination" in ev.display_message
        assert ev.risk_labels == ["EEO-AGE-PROXY-01"]

    def test_block_event_basic_fields(self):
        ev = format_review_event(_verdict("block", ["EEO-PII-01"]))
        assert ev.type == "tenet_block"
        assert ev.action == "block"
        assert "personal-information" in ev.display_message

    def test_severity_propagates(self):
        ev = format_review_event(_verdict("review", severity="high"))
        assert ev.severity == "high"


class TestReviewEventChoices:
    def test_review_choices_default_to_proceed_and_reject(self):
        ev = format_review_event(_verdict("review", ["EEO-AGE-PROXY-01"]))
        assert isinstance(ev.choices, list) and len(ev.choices) == 2
        ids = [c["id"] for c in ev.choices]
        assert "proceed" in ids
        assert "reject" in ids

    def test_block_choices_default_to_dismiss_only(self):
        ev = format_review_event(_verdict("block", ["EEO-PII-01"]))
        assert isinstance(ev.choices, list) and len(ev.choices) == 1
        assert ev.choices[0]["id"] == "dismiss"


class TestReviewEventToolContext:
    def test_tool_context_included(self):
        ev = format_review_event(
            _verdict("review", ["EEO-AGE-PROXY-01"]),
            tool_name="schedule_interview",
            tool_args={"candidate_id": "c1"},
            tool_result=None,
        )
        assert ev.tool_name == "schedule_interview"
        assert ev.tool_args == {"candidate_id": "c1"}
        assert ev.tool_result is None

    def test_post_tool_includes_result(self):
        ev = format_review_event(
            _verdict("review", ["EEO-RACE-01"]),
            tool_name="top_candidates",
            tool_args={"q": "x"},
            tool_result="{\"hits\": []}",
        )
        assert ev.tool_result == "{\"hits\": []}"


class TestReviewEventExtras:
    def test_extras_pass_through(self):
        """Apps add their own fields (e.g., LLM-generated alternatives)
        via ``extras``; they round-trip through ``to_dict()``."""
        ev = format_review_event(
            _verdict("review", ["EEO-AGE-PROXY-01"]),
            extras={"alternatives": ["Find candidates with 5+ yrs experience."]},
        )
        data = ev.to_dict()
        assert data["alternatives"] == [
            "Find candidates with 5+ yrs experience."
        ]


class TestReviewEventSerialization:
    def test_to_dict_round_trips(self):
        ev = format_review_event(
            _verdict("review", ["EEO-AGE-PROXY-01"], severity="medium")
        )
        data = ev.to_dict()
        assert data["type"] == "tenet_review"
        assert data["action"] == "review"
        assert data["severity"] == "medium"
        assert data["risk_labels"] == ["EEO-AGE-PROXY-01"]
        # Tool fields are absent for agent_input boundaries.
        assert "tool_name" not in data

    def test_to_sse_emits_event_and_data_lines(self):
        ev = format_review_event(_verdict("review", ["EEO-AGE-PROXY-01"]))
        sse = ev.to_sse()
        assert sse.startswith("event: tenet_review\n")
        assert "\ndata: " in sse
        # ``\n\n`` terminator is required by the SSE protocol.
        assert sse.endswith("\n\n")
        # The data line is valid JSON.
        data_line = next(
            line[len("data: ") :] for line in sse.splitlines() if line.startswith("data: ")
        )
        parsed = json.loads(data_line)
        assert parsed["action"] == "review"

    def test_to_sse_block_uses_tenet_block_event_name(self):
        ev = format_review_event(_verdict("block", ["EEO-PII-01"]))
        assert ev.to_sse().startswith("event: tenet_block\n")


class TestReviewEventReason:
    def test_review_reason_synthesized_from_severity_and_labels(self):
        """When the verdict has no explicit reason, synthesize one from
        severity + labels so operator logs always carry something."""
        ev = format_review_event(
            _verdict("review", ["EEO-AGE-PROXY-01"], severity="medium")
        )
        assert "medium" in ev.reason.lower()
        assert "EEO-AGE-PROXY-01" in ev.reason

    def test_explicit_reason_wins(self):
        v = _verdict("review", ["EEO-AGE-PROXY-01"], reason="explicit")
        ev = format_review_event(v)
        assert ev.reason == "explicit"


class TestExportedPublicAPI:
    def test_format_review_event_imported_from_package(self):
        # Smoke test: the function is reachable from ``tenet_langchain``.
        from tenet_langchain import format_review_event as f
        assert callable(f)

    def test_review_event_imported_from_events(self):
        from tenet_langchain.events import ReviewEvent as R
        assert R is ReviewEvent
