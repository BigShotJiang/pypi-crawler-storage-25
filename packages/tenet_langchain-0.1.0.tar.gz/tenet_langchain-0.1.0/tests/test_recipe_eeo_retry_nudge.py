"""End-to-end recipe: EEO retry-nudge round-trip.

Exit criterion #9 from the Wave 5 plan: demonstrate the full forge-style
self-correction loop on the EEO surface end-to-end.

1. A borderline EEO tool call produces a `block` verdict with
   severity=low (a soft compliance signal — phrasing, not a hard PHI
   exfiltration).
2. The ``severity_routed_policy`` recipe routes low/medium severities
   to ``retry_nudge_from_verdict``; the middleware emits a
   ``ToolMessage(status="error")`` carrying corrective guidance.
3. The simulated agent reads the guidance and re-issues the tool call
   with corrected arguments.
4. The judge allows the second call cleanly.
5. The ``retry_nudge_retry_succeeded_total`` counter increments — the
   middleware saw the chain self-correct.

This test does not invoke a real LangChain agent (that would require a
live LLM); it exercises the middleware ``wrap_tool_call`` loop directly
with a mocked judge client, which is exactly what the agent loop calls.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

from langchain_core.messages import ToolMessage

from tenet_client import TenetCloudJudgeClient
from tenet_client.cloud_models import CloudJudgeResponse
from tenet_client.recipes import severity_routed_policy
from tenet_langchain import TenetJudgeMiddleware


def _block_low(reason: str) -> CloudJudgeResponse:
    """An EEO-style soft block — severity=low, retryable phrasing fix."""
    return CloudJudgeResponse(
        decision="block",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=11,
        reason=reason,
    )


def _allow() -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow", judge_id="hr-1", judge_version="hr-1.0.0", latency_ms=8
    )


def _mock_eeo_client(*verdicts: CloudJudgeResponse) -> MagicMock:
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = list(verdicts)
    c.evaluate_async = AsyncMock(side_effect=list(verdicts))
    c._judge_id = "hr-1"
    return c


def _request(args: dict) -> MagicMock:
    """Mimic LangChain's ToolCallRequest enough that the middleware can read it."""
    req = MagicMock()
    req.tool_call = {"id": "call_eeo", "name": "rank_candidates", "args": args}

    def _override(**kwargs):
        new = MagicMock()
        new.tool_call = {**req.tool_call, **(kwargs.get("tool_call") or {})}
        new.override = req.override
        return new

    req.override.side_effect = _override
    return req


def test_eeo_retry_nudge_end_to_end():
    """The full Wave 5 forge-loop exit criterion.

    NOTE: We have to patch ``JudgeVerdict.from_cloud_response`` indirectly
    here — the v1 CloudJudgeResponse doesn't carry severity, but the
    recipe routes by severity. We use a custom on_block that simulates
    the future severity-routed mapping by directly returning a
    retry_nudge for the first block, matching the recipe's behavior.
    """
    # The middleware will see one tool_pre block on the first call, then
    # a clean allow/allow on the second call.
    client = _mock_eeo_client(
        _block_low("Phrasing implies age-based screening — rephrase neutrally."),
        _allow(),  # second call: tool_pre allow
        _allow(),  # second call: tool_post allow
    )

    # The recipe ships defaults: low/medium → retry_nudge.
    # CloudJudgeResponse doesn't carry severity in v1; we simulate the
    # severity-routed mapping by configuring the policy to also nudge
    # on None-severity blocks (which is what the v1 wire surface
    # currently produces). When the cloud starts shipping severity, this
    # extra config becomes redundant — but the test still passes.
    policy = severity_routed_policy(
        retry_nudge_severities=("low", "medium", None),  # type: ignore[arg-type]
    )

    mw = TenetJudgeMiddleware(client, policy=policy)

    # === Call 1: borderline tool call → block → retry_nudge ===
    handler1 = MagicMock(
        return_value=ToolMessage(content="raw output", tool_call_id="call_eeo")
    )
    result1 = mw.wrap_tool_call(
        _request({"q": "find me young energetic candidates"}), handler1
    )
    # Middleware emitted a ToolMessage(status=error) with guidance.
    assert isinstance(result1, ToolMessage)
    assert result1.status == "error"
    # Two-line template from RFC-008 default.
    assert "Cannot proceed as requested:" in result1.content
    assert "age-based screening" in result1.content
    # Handler did NOT run — short-circuited at tool_pre.
    handler1.assert_not_called()
    # Telemetry: one retry-nudge emitted, no successes yet.
    assert mw.telemetry.emitted.get(("hr-1", "rank_candidates")) == 1
    assert mw.telemetry.succeeded.get(("hr-1", "rank_candidates"), 0) == 0
    assert mw.telemetry.exhausted.get(("hr-1", "rank_candidates"), 0) == 0

    # === Call 2: simulated agent re-issues with corrected args → clean ===
    handler2 = MagicMock(
        return_value=ToolMessage(
            content="3 candidates, neutral criteria.", tool_call_id="call_eeo"
        )
    )
    result2 = mw.wrap_tool_call(
        _request({"q": "find me candidates with strong systems experience"}), handler2
    )
    # Clean result — original handler output flowed through.
    assert result2.content == "3 candidates, neutral criteria."
    # And the succeeded counter incremented because the chain self-corrected.
    assert mw.telemetry.succeeded.get(("hr-1", "rank_candidates")) == 1
    # Consecutive-nudge counter reset (so the next chain starts at 0).
    assert mw._consecutive_retry_nudges.get("rank_candidates", 0) == 0
