"""Tests for TenetCallbackHandler and AsyncTenetCallbackHandler."""

from __future__ import annotations
import uuid
from unittest.mock import AsyncMock, MagicMock
import pytest
from tenet_client import TenetClient, TenetViolationError

from tenet_langchain.callback import AsyncTenetCallbackHandler, TenetCallbackHandler


def _mock_client(response):
    client = MagicMock(spec=TenetClient)
    client.evaluate.return_value = response
    client.evaluate_async = AsyncMock(return_value=response)
    return client

def _serialized(name="search"):
    return {"name": name, "id": ["langchain", "tools", name]}


class TestTenetCallbackHandlerOnToolStart:
    def test_no_violations_passes(self, no_violations_response):
        handler = TenetCallbackHandler(client=_mock_client(no_violations_response))
        handler.on_tool_start(_serialized(), "query", run_id=uuid.uuid4(), parent_run_id=None)

    def test_block_violation_raises(self, block_violation_response):
        handler = TenetCallbackHandler(client=_mock_client(block_violation_response))
        with pytest.raises(TenetViolationError) as exc_info:
            handler.on_tool_start(_serialized("shell"), "rm -rf /", run_id=uuid.uuid4(), parent_run_id=None)
        assert len(exc_info.value.violations) == 1

    def test_warn_violation_logs(self, warn_violation_response, caplog):
        handler = TenetCallbackHandler(client=_mock_client(warn_violation_response))
        import logging
        with caplog.at_level(logging.WARNING, logger="tenet_langchain.callback"):
            handler.on_tool_start(_serialized(), "user@example.com", run_id=uuid.uuid4(), parent_run_id=None)
        assert "Violation" in caplog.text

    def test_redact_violation_modifies_input(self, redact_violation_response):
        handler = TenetCallbackHandler(client=_mock_client(redact_violation_response))
        inputs = {"input": "Hello user@example.com"}
        handler.on_tool_start(_serialized(), "Hello user@example.com", run_id=uuid.uuid4(), parent_run_id=None, inputs=inputs)
        assert inputs["input"] == "Hello [EMAIL_1]"

    def test_on_violation_callback_called(self, block_violation_response):
        callback = MagicMock()
        handler = TenetCallbackHandler(client=_mock_client(block_violation_response), on_violation=callback)
        with pytest.raises(TenetViolationError):
            handler.on_tool_start(_serialized("shell"), "cmd", run_id=uuid.uuid4(), parent_run_id=None)
        callback.assert_called_once()

    def test_tool_name_from_serialized(self, no_violations_response):
        client = _mock_client(no_violations_response)
        handler = TenetCallbackHandler(client=client)
        handler.on_tool_start({"name": "my_tool"}, "input", run_id=uuid.uuid4(), parent_run_id=None)
        call_args = client.evaluate.call_args[0][0]
        assert call_args.tool_name == "my_tool"


class TestTenetCallbackHandlerOnToolEnd:
    def test_no_violations_silent(self, no_violations_response):
        handler = TenetCallbackHandler(client=_mock_client(no_violations_response))
        handler.on_tool_end("result text", run_id=uuid.uuid4(), parent_run_id=None)

    def test_violations_logged_not_raised(self, block_violation_response):
        handler = TenetCallbackHandler(client=_mock_client(block_violation_response))
        handler.on_tool_end("sensitive output", run_id=uuid.uuid4(), parent_run_id=None)

    def test_on_violation_callback_called(self, warn_violation_response):
        callback = MagicMock()
        handler = TenetCallbackHandler(client=_mock_client(warn_violation_response), on_violation=callback)
        handler.on_tool_end("output", run_id=uuid.uuid4(), parent_run_id=None)
        callback.assert_called_once()


class TestTenetCallbackHandlerSessionId:
    def test_auto_generates_session_id(self):
        handler = TenetCallbackHandler(client=MagicMock(spec=TenetClient))
        assert handler.session_id is not None

    def test_custom_session_id(self):
        handler = TenetCallbackHandler(client=MagicMock(spec=TenetClient), session_id="my-session")
        assert handler.session_id == "my-session"


class TestAsyncTenetCallbackHandler:
    @pytest.mark.asyncio
    async def test_on_tool_start_no_violations(self, no_violations_response):
        client = MagicMock(spec=TenetClient)
        client.evaluate_async = AsyncMock(return_value=no_violations_response)
        handler = AsyncTenetCallbackHandler(client=client)
        await handler.on_tool_start(_serialized(), "query", run_id=uuid.uuid4(), parent_run_id=None)

    @pytest.mark.asyncio
    async def test_on_tool_start_block_raises(self, block_violation_response):
        client = MagicMock(spec=TenetClient)
        client.evaluate_async = AsyncMock(return_value=block_violation_response)
        handler = AsyncTenetCallbackHandler(client=client)
        with pytest.raises(TenetViolationError):
            await handler.on_tool_start(_serialized("shell"), "cmd", run_id=uuid.uuid4(), parent_run_id=None)

    @pytest.mark.asyncio
    async def test_on_tool_end_logs_only(self, block_violation_response):
        client = MagicMock(spec=TenetClient)
        client.evaluate_async = AsyncMock(return_value=block_violation_response)
        handler = AsyncTenetCallbackHandler(client=client)
        await handler.on_tool_end("output", run_id=uuid.uuid4(), parent_run_id=None)
