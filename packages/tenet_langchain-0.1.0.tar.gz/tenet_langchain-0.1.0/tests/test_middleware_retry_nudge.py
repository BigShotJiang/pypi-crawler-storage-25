"""Tests for ``TenetJudgeMiddleware`` retry_nudge handling.

RFC-008 §4.4.5 Phase 4.5. When the policy returns
``JudgeAction.retry_nudge(guidance)``, the middleware synthesizes a
``ToolMessage(status="error", content=guidance)`` so the LangChain
agent loop reads the corrective guidance on its next iteration and
re-issues the tool call. This is forge's retry-nudge mechanic: step
stays open, model self-corrects.

Distinct from ``tool_error`` (terminal — content is a denial message)
and from ``override_output`` (replaces output with a fixed string).
The wire-level ToolMessage shape may be similar but the
content-source and semantic intent differ.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import ToolMessage

from tenet_client import (
    JudgeAction,
    JudgePolicy,
    TenetCloudJudgeClient,
)
from tenet_client.cloud_models import CloudJudgeResponse
from tenet_langchain import TenetJudgeMiddleware


def _allow() -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow", judge_id="hr-1", judge_version="hr-1.0.0", latency_ms=10
    )


def _block(reason: str = "policy violation") -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="block", judge_id="hr-1", judge_version="hr-1.0.0", latency_ms=11, reason=reason
    )


def _mock_client(*verdicts: CloudJudgeResponse) -> MagicMock:
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = list(verdicts)
    c.evaluate_async = AsyncMock(side_effect=list(verdicts))
    return c


def _request(tool_name: str = "search", args: dict | None = None) -> MagicMock:
    req = MagicMock()
    req.tool_call = {"id": "call_123", "name": tool_name, "args": args or {"q": "x"}}

    def _override(**kwargs):
        new = MagicMock()
        new.tool_call = {**req.tool_call, **(kwargs.get("tool_call") or {})}
        new.override = req.override
        return new

    req.override.side_effect = _override
    return req


class TestRetryNudgeBlock:
    """Policy returns retry_nudge from on_block — middleware emits a
    ToolMessage carrying the guidance.
    """

    def test_synthesizes_tool_message_with_guidance(self):
        policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.retry_nudge(
                "Cannot proceed: PHI present. Drop the MRN and retry."
            ),
        )
        mw = TenetJudgeMiddleware(_mock_client(_block("PHI")), policy=policy)
        handler = MagicMock()

        result = mw.wrap_tool_call(_request(tool_name="lookup"), handler)
        assert isinstance(result, ToolMessage)
        # Guidance, not action.message, drives the content.
        assert "PHI present" in result.content
        assert "Drop the MRN" in result.content
        # Step-not-complete semantics: status="error" tells the agent
        # loop the call did not succeed and to consider retrying.
        assert result.status == "error"
        # The original handler was NOT invoked (short-circuit at tool_pre).
        handler.assert_not_called()

    def test_tool_call_id_and_name_preserved(self):
        policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.retry_nudge("retry guidance"),
        )
        mw = TenetJudgeMiddleware(_mock_client(_block()), policy=policy)
        handler = MagicMock()

        result = mw.wrap_tool_call(_request(tool_name="get_chart"), handler)
        assert result.tool_call_id == "call_123"
        assert result.name == "get_chart"

    def test_distinguishes_from_tool_error_by_content_source(self):
        # When the policy returns tool_error, content comes from
        # action.message. When it returns retry_nudge, content comes
        # from action.guidance. Both produce status="error", but the
        # semantic intent differs.
        nudge_policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.retry_nudge("self-correct please"),
        )
        error_policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.tool_error("hard fail"),
        )

        nudge_mw = TenetJudgeMiddleware(_mock_client(_block()), policy=nudge_policy)
        error_mw = TenetJudgeMiddleware(_mock_client(_block()), policy=error_policy)

        nudge_result = nudge_mw.wrap_tool_call(_request(), MagicMock())
        error_result = error_mw.wrap_tool_call(_request(), MagicMock())

        assert nudge_result.content == "self-correct please"
        assert error_result.content == "hard fail"
        # Both ToolMessage shapes — the difference is content + intent.
        assert nudge_result.status == "error"
        assert error_result.status == "error"

    def test_post_block_retry_nudge_short_circuits_after_handler(self):
        # On tool_post, the handler has already run. retry_nudge replaces
        # the tool result with the corrective guidance — agent loop reads
        # that on its next iteration instead of the original output.
        policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.retry_nudge("Re-issue without PHI."),
        )
        # allow pre, block post.
        mw = TenetJudgeMiddleware(_mock_client(_allow(), _block("PHI")), policy=policy)
        handler = MagicMock(
            return_value=ToolMessage(content="raw PHI output", tool_call_id="call_123")
        )

        result = mw.wrap_tool_call(_request(), handler)
        # Handler ran (post-check fires after).
        handler.assert_called_once()
        # But the user-visible result is the corrective guidance, not the
        # raw output — step stays open for the agent to retry.
        assert result.status == "error"
        assert "Re-issue without PHI." in result.content


class TestRetryNudgeFromUnresolved:
    """End-to-end: policy.on_unresolved returns retry_nudge_from_verdict.

    The middleware does NOT yet thread resolution_status (that lands in
    a later commit). For now we exercise the on_unresolved branch by
    invoking it through the policy directly via on_block returning a
    retry_nudge_from_verdict.
    """

    def test_retry_nudge_from_verdict_threaded_through_middleware(self):
        # Verdict carries reason + safe_message; retry_nudge_from_verdict
        # assembles the two-line guidance template. Middleware emits it.
        policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.retry_nudge_from_verdict(v),
        )
        mw = TenetJudgeMiddleware(_mock_client(_block("PHI detected")), policy=policy)

        result = mw.wrap_tool_call(_request(), MagicMock())
        assert result.status == "error"
        # The two-line template from RFC-008 default.
        assert "Cannot proceed as requested:" in result.content
        assert "Suggested correction:" in result.content


class TestRetryNudgeAsyncParity:
    @pytest.mark.asyncio
    async def test_retry_nudge_async(self):
        policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.retry_nudge("async self-correct"),
        )
        mw = TenetJudgeMiddleware(_mock_client(_block()), policy=policy)

        async def handler(req):
            return ToolMessage(content="x", tool_call_id="call_123")

        result = await mw.awrap_tool_call(_request(), handler)
        assert result.status == "error"
        assert result.content == "async self-correct"
