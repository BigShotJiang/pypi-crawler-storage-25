"""Tests for per-thread verdict caching on TenetJudgeMiddleware.

When ``cache_verdicts=True`` is set, the middleware dedupes judge calls
within a turn:

- ``before_model`` for the same HumanMessage runs once per turn, not
  once per LLM step. (LangGraph re-executes the node after every tool
  call and on resume, so without caching the same prompt would be
  judged repeatedly.)
- ``wrap_tool_call`` for the same (phase, tool_name, tool_input,
  tool_output) tuple runs the judge once per turn.

The cache is scoped per thread_id (from ``runtime.execution_info``)
and invalidated when a new HumanMessage appears in state.
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import HumanMessage, ToolMessage

from tenet_client import TenetCloudJudgeClient
from tenet_client.cloud_models import CloudJudgeResponse
from tenet_langchain import TenetJudgeMiddleware


def _cloud(verdict: str = "pass") -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow" if verdict in ("pass", "include", "fast_pass") else "block",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=10,
        verdict=verdict,
    )


def _mock_client(*responses: CloudJudgeResponse) -> MagicMock:
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = list(responses) or [_cloud()] * 16
    c.evaluate_async = AsyncMock(side_effect=list(responses) or [_cloud()] * 16)
    return c


def _runtime(thread_id: str | None = "thread-A") -> SimpleNamespace:
    return SimpleNamespace(
        execution_info=SimpleNamespace(thread_id=thread_id)
    )


def _state(messages: list) -> dict:
    return {"messages": messages}


def _tool_request(
    tool_name: str = "search",
    args: dict | None = None,
    *,
    runtime: SimpleNamespace | None = None,
    state: dict | None = None,
) -> MagicMock:
    req = MagicMock()
    req.tool_call = {"id": f"call_{tool_name}", "name": tool_name, "args": args or {}}
    req.runtime = runtime if runtime is not None else _runtime()
    req.state = state if state is not None else _state([HumanMessage("hello")])
    req.override.return_value = req
    return req


# --------------------------------------------------------------------------
# Default: caching disabled.
# --------------------------------------------------------------------------


class TestCachingDisabledByDefault:
    def test_repeated_before_model_calls_re_judge(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(client, check_user_messages=True)
        state = _state([HumanMessage("find resumes")])
        rt = _runtime()
        mw.before_model(state, rt)
        mw.before_model(state, rt)
        assert client.evaluate.call_count == 2


# --------------------------------------------------------------------------
# Cache hits — same content within a turn.
# --------------------------------------------------------------------------


class TestCacheHits:
    def test_same_user_message_hits_cache(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client, check_user_messages=True, cache_verdicts=True
        )
        state = _state([HumanMessage("find resumes")])
        rt = _runtime()
        mw.before_model(state, rt)
        mw.before_model(state, rt)
        mw.before_model(state, rt)
        assert client.evaluate.call_count == 1, (
            "cache should dedupe re-runs of the same HumanMessage within a turn"
        )

    @pytest.mark.asyncio
    async def test_async_same_user_message_hits_cache(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client, check_user_messages=True, cache_verdicts=True
        )
        state = _state([HumanMessage("find resumes")])
        rt = _runtime()
        await mw.abefore_model(state, rt)
        await mw.abefore_model(state, rt)
        assert client.evaluate_async.await_count == 1

    def test_different_user_messages_both_judged(self):
        client = _mock_client(_cloud("pass"), _cloud("pass"))
        mw = TenetJudgeMiddleware(
            client, check_user_messages=True, cache_verdicts=True
        )
        rt = _runtime()
        mw.before_model(_state([HumanMessage("first")]), rt)
        # Same turn but different text — second prompt is new content,
        # should still be judged (cache keys on content, not turn).
        mw.before_model(
            _state([HumanMessage("first"), HumanMessage("second")]), rt
        )
        assert client.evaluate.call_count == 2

    def test_tool_call_dedupes_within_turn(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client,
            cache_verdicts=True,
            check_post=False,
        )

        rt = _runtime()
        state = _state([HumanMessage("hi")])
        req1 = _tool_request("search", {"q": "x"}, runtime=rt, state=state)
        req2 = _tool_request("search", {"q": "x"}, runtime=rt, state=state)
        handler = MagicMock(return_value=ToolMessage(content="ok", tool_call_id="x"))

        mw.wrap_tool_call(req1, handler)
        mw.wrap_tool_call(req2, handler)
        # 1 judge call total (the second is a cache hit on tool_pre).
        assert client.evaluate.call_count == 1


# --------------------------------------------------------------------------
# Cache invalidation on turn boundary.
# --------------------------------------------------------------------------


class TestCacheInvalidation:
    def test_new_human_message_invalidates_cache(self):
        """Once the user types a new message, the prior verdict cache for
        that thread is dropped (the conversation moved on)."""
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client, check_user_messages=True, cache_verdicts=True
        )
        rt = _runtime()
        mw.before_model(_state([HumanMessage("a")]), rt)
        mw.before_model(_state([HumanMessage("a")]), rt)  # cached
        # Now the user sends another message — turn boundary.
        mw.before_model(_state([HumanMessage("a"), HumanMessage("b")]), rt)
        # 2 distinct calls: one for "a" (cached on the third invoke too),
        # and one for "b" (the new turn).
        assert client.evaluate.call_count == 2


# --------------------------------------------------------------------------
# Cache scoped per thread.
# --------------------------------------------------------------------------


class TestCachePerThread:
    def test_different_threads_do_not_share_cache(self):
        client = _mock_client(_cloud("pass"), _cloud("pass"))
        mw = TenetJudgeMiddleware(
            client, check_user_messages=True, cache_verdicts=True
        )
        state = _state([HumanMessage("same content")])
        mw.before_model(state, _runtime("thread-A"))
        mw.before_model(state, _runtime("thread-B"))
        # Two threads, same content → 2 judge calls.
        assert client.evaluate.call_count == 2

    def test_no_thread_id_falls_back_to_session(self):
        """When runtime has no thread_id (no checkpointer), the cache
        still works using the middleware's session_id as the scope."""
        client = _mock_client()
        mw = TenetJudgeMiddleware(
            client, check_user_messages=True, cache_verdicts=True
        )
        rt = _runtime(thread_id=None)
        state = _state([HumanMessage("x")])
        mw.before_model(state, rt)
        mw.before_model(state, rt)
        assert client.evaluate.call_count == 1
