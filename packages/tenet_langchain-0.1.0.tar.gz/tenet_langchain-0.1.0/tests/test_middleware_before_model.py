"""Tests for ``TenetJudgeMiddleware.abefore_model`` / ``before_model``.

The middleware judges new HumanMessages at phase ``agent_input`` so user
prompts get gated before the LLM step runs. Behavior:

- ``check_user_messages=False`` (default) — the hook is a no-op.
  Integrators that want message judging opt in.
- ``check_user_messages=True`` — every model step checks the latest
  HumanMessage. (Per-turn deduplication requires ``cache_verdicts=True``.)

Action dispatch at the message boundary:

- ``allow``: return ``None`` (continue to model).
- ``block`` / ``tool_error``: append an AIMessage with the safe message
  and jump to ``end``. The agent terminates with a final assistant
  message rather than calling the model.
- ``override_input``: replace the latest HumanMessage content with the
  override payload, then continue.
- ``human_review`` / ``raise_error``: passthrough; the policy callback
  is responsible for any ``interrupt(...)`` or ``raise``.
- ``override_output`` / ``retry_nudge``: not meaningful here — passthrough.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import AIMessage, HumanMessage

from tenet_client import (
    JudgeAction,
    JudgePolicy,
    TenetCloudJudgeClient,
)
from tenet_client.cloud_models import CloudJudgeResponse
from tenet_langchain import TenetJudgeMiddleware


def _cloud(verdict: str, risk_labels: list[str] | None = None) -> CloudJudgeResponse:
    return CloudJudgeResponse(
        decision="allow" if verdict in ("pass", "include", "fast_pass") else "block",
        judge_id="hr-1",
        judge_version="hr-1.0.0",
        latency_ms=10,
        verdict=verdict,
        risk_labels=risk_labels or [],
    )


def _mock_client(*responses: CloudJudgeResponse) -> MagicMock:
    c = MagicMock(spec=TenetCloudJudgeClient)
    c.evaluate.side_effect = list(responses)
    c.evaluate_async = AsyncMock(side_effect=list(responses))
    return c


def _state(messages: list) -> dict:
    return {"messages": messages}


# --------------------------------------------------------------------------
# Default: opt-in — without check_user_messages=True, hook is a no-op.
# --------------------------------------------------------------------------


class TestBeforeModelDefaultDisabled:
    def test_sync_no_op_by_default(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(client)
        out = mw.before_model(_state([HumanMessage("hello")]), runtime=None)
        assert out is None
        client.evaluate.assert_not_called()

    @pytest.mark.asyncio
    async def test_async_no_op_by_default(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(client)
        out = await mw.abefore_model(_state([HumanMessage("hello")]), runtime=None)
        assert out is None
        client.evaluate_async.assert_not_awaited()


# --------------------------------------------------------------------------
# Opt-in path: allow / block / override at the model boundary.
# --------------------------------------------------------------------------


class TestBeforeModelAllow:
    def test_sync_allow_returns_none(self):
        client = _mock_client(_cloud("pass"))
        mw = TenetJudgeMiddleware(client, check_user_messages=True)
        out = mw.before_model(_state([HumanMessage("find resumes")]), runtime=None)
        assert out is None
        # Phase = agent_input, content carried as recruiter_prompt-shaped input.
        call_kwargs = client.evaluate.call_args.kwargs
        assert call_kwargs["phase"] == "agent_input"
        assert call_kwargs["tool_input"] == "find resumes"

    @pytest.mark.asyncio
    async def test_async_allow_returns_none(self):
        client = _mock_client(_cloud("pass"))
        mw = TenetJudgeMiddleware(client, check_user_messages=True)
        out = await mw.abefore_model(
            _state([HumanMessage("find resumes")]), runtime=None
        )
        assert out is None
        call_kwargs = client.evaluate_async.call_args.kwargs
        assert call_kwargs["phase"] == "agent_input"
        assert call_kwargs["tool_input"] == "find resumes"


class TestBeforeModelBlock:
    def test_block_jumps_to_end_with_ai_message(self):
        client = _mock_client(_cloud("block", risk_labels=["EEO-AGE-PROXY-01"]))
        policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.tool_error("Request blocked.")
        )
        mw = TenetJudgeMiddleware(client, policy=policy, check_user_messages=True)
        out = mw.before_model(_state([HumanMessage("find young hires")]), runtime=None)
        assert isinstance(out, dict)
        assert out.get("jump_to") == "end"
        # An AIMessage with the safe content is appended.
        msgs = out.get("messages") or []
        assert any(isinstance(m, AIMessage) and "blocked" in m.content.lower() for m in msgs)

    @pytest.mark.asyncio
    async def test_async_block_jumps_to_end(self):
        client = _mock_client(_cloud("block"))
        policy = JudgePolicy(
            on_block=lambda ctx, v: JudgeAction.tool_error("Request blocked.")
        )
        mw = TenetJudgeMiddleware(client, policy=policy, check_user_messages=True)
        out = await mw.abefore_model(
            _state([HumanMessage("find young hires")]), runtime=None
        )
        assert out is not None
        assert out.get("jump_to") == "end"


class TestBeforeModelOverrideInput:
    def test_override_input_replaces_last_human_message(self):
        """An ``override_input`` action at the message boundary rewrites
        the user prompt and lets the model proceed with the new text."""
        client = _mock_client(_cloud("route_to_human"))
        policy = JudgePolicy(
            on_review=lambda ctx, v: JudgeAction.override_input(
                "Find candidates with at least 5 years of relevant experience."
            )
        )
        mw = TenetJudgeMiddleware(client, policy=policy, check_user_messages=True)
        original = HumanMessage("find young hires")
        out = mw.before_model(_state([original]), runtime=None)
        assert isinstance(out, dict)
        # No jump_to — agent continues to model.
        assert "jump_to" not in out
        msgs = out.get("messages") or []
        # The latest HumanMessage is replaced with the override payload.
        replaced = [m for m in msgs if isinstance(m, HumanMessage)]
        assert any("5 years" in m.content for m in replaced)


class TestBeforeModelOnlyLatestHumanMessage:
    def test_no_human_message_is_no_op(self):
        client = _mock_client()
        mw = TenetJudgeMiddleware(client, check_user_messages=True)
        out = mw.before_model(_state([AIMessage("hi")]), runtime=None)
        assert out is None
        client.evaluate.assert_not_called()

    def test_judges_only_latest_human_message(self):
        client = _mock_client(_cloud("pass"))
        mw = TenetJudgeMiddleware(client, check_user_messages=True)
        mw.before_model(
            _state(
                [
                    HumanMessage("first"),
                    AIMessage("ack"),
                    HumanMessage("latest please"),
                ]
            ),
            runtime=None,
        )
        assert client.evaluate.call_args.kwargs["tool_input"] == "latest please"


class TestBeforeModelSurface:
    def test_surface_forwarded_to_judge(self):
        client = _mock_client(_cloud("pass"))
        mw = TenetJudgeMiddleware(client, check_user_messages=True)
        mw.before_model(_state([HumanMessage("anything")]), runtime=None)
        # Surface is a client-level config; the middleware does not pass
        # it per call. Trace + session must be forwarded.
        call_kwargs = client.evaluate.call_args.kwargs
        assert "session_id" in call_kwargs
        assert "trace_id" in call_kwargs
