use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

type PyObject = Py<PyAny>;

use ::libqdx::convert::{mmcif, pdb, sdf, xyz};
use ::libqdx::residue::Residue;
use ::libqdx::{
    AlphaHelices, AminoAcidSeq, AtomCheckStrictness, AtomRef, BetaSheets, BondOrder, Chains,
    Element, FormalCharge, Fragment, HelixClass, PartialCharge, Residues, Stereochemistry,
    StrandSense, TRC,
};

trait IntoPyResult<T> {
    fn py_err(self) -> PyResult<T>;
    fn py_err_ctx(self, ctx: &str) -> PyResult<T>;
}

impl<T, E: std::fmt::Display> IntoPyResult<T> for Result<T, E> {
    fn py_err(self) -> PyResult<T> {
        self.map_err(|e| PyValueError::new_err(e.to_string()))
    }
    fn py_err_ctx(self, ctx: &str) -> PyResult<T> {
        self.map_err(|e| PyValueError::new_err(format!("{ctx}: {e}")))
    }
}

fn serde_to_py(py: Python<'_>, val: &impl serde::Serialize) -> PyResult<PyObject> {
    pythonize::pythonize(py, val).map(|o| o.unbind()).py_err()
}

fn depythonize_into<T: serde::de::DeserializeOwned>(
    data: &Bound<'_, PyAny>,
    name: &str,
) -> PyResult<T> {
    pythonize::depythonize(data).py_err_ctx(&format!("failed to deserialize {name}"))
}

#[pyclass(frozen, get_all, from_py_object)]
#[derive(Clone)]
pub struct Bond {
    pub atoms: (u32, u32),
    pub order: BondOrder,
}

#[pymethods]
impl Bond {
    fn __repr__(&self) -> String {
        format!("Bond({:?}, {:?})", self.atoms, self.order)
    }
}

#[pyclass(frozen, name = "Topology")]
pub struct PyTopology {
    rust: ::libqdx::Topology,
    py_schema_version: PyObject,
    py_symbols: PyObject,
    py_geometry: PyObject,
    py_labels: PyObject,
    py_formal_charges: PyObject,
    py_partial_charges: PyObject,
    py_connectivity: PyObject,
    py_stereochemistry: PyObject,
    py_velocities: PyObject,
    py_fragments: PyObject,
    py_fragment_formal_charges: PyObject,
    py_fragment_partial_charges: PyObject,
    py_fragment_multiplicities: PyObject,
}

impl PyTopology {
    fn build(py: Python<'_>, t: &::libqdx::Topology) -> PyResult<Self> {
        let py_schema_version = t
            .schema_version
            .to_string()
            .into_pyobject(py)?
            .into_any()
            .unbind();

        let py_symbols = t.symbols.clone().into_pyobject(py)?.into_any().unbind();

        let n = t.symbols.len();
        let arr = ndarray::Array2::from_shape_vec((n, 3), t.geometry.clone())
            .py_err_ctx("bad geometry shape")?;
        let py_geometry = numpy::IntoPyArray::into_pyarray(arr, py)
            .into_any()
            .unbind();

        let py_labels = t.labels.clone().into_pyobject(py)?.into_any().unbind();

        let py_formal_charges = t
            .formal_charges
            .as_ref()
            .map(|fc| {
                numpy::PyArray1::from_vec(py, fc.iter().map(|c| c.0).collect())
                    .into_any()
                    .unbind()
            })
            .into_pyobject(py)?
            .into_any()
            .unbind();

        let py_partial_charges = t
            .partial_charges
            .as_ref()
            .map(|pc| {
                numpy::PyArray1::from_vec(py, pc.iter().map(|c| c.0).collect())
                    .into_any()
                    .unbind()
            })
            .into_pyobject(py)?
            .into_any()
            .unbind();

        let py_connectivity = t
            .connectivity
            .as_ref()
            .map(|bonds| {
                bonds
                    .iter()
                    .map(|b| Bond {
                        atoms: (b.0.0, b.1.0),
                        order: b.2,
                    })
                    .collect::<Vec<_>>()
            })
            .into_pyobject(py)?
            .into_any()
            .unbind();

        let py_stereochemistry = t
            .stereochemistry
            .clone()
            .into_pyobject(py)?
            .into_any()
            .unbind();

        let py_velocities = t
            .velocities
            .as_ref()
            .and_then(|v| ndarray::Array2::from_shape_vec((v.len() / 3, 3), v.clone()).ok())
            .map(|a| numpy::IntoPyArray::into_pyarray(a, py).into_any().unbind())
            .into_pyobject(py)?
            .into_any()
            .unbind();

        let py_fragments = t
            .fragments
            .as_ref()
            .map(|frags| {
                frags
                    .iter()
                    .map(|f| f.0.iter().map(|a| a.0).collect::<Vec<u32>>())
                    .collect::<Vec<_>>()
            })
            .into_pyobject(py)?
            .into_any()
            .unbind();

        let py_fragment_formal_charges = t
            .fragment_formal_charges
            .as_ref()
            .map(|fc| fc.iter().map(|c| c.0).collect::<Vec<i32>>())
            .into_pyobject(py)?
            .into_any()
            .unbind();

        let py_fragment_partial_charges = t
            .fragment_partial_charges
            .as_ref()
            .map(|pc| pc.iter().map(|c| c.0).collect::<Vec<f32>>())
            .into_pyobject(py)?
            .into_any()
            .unbind();

        let py_fragment_multiplicities = t
            .fragment_multiplicities
            .as_ref()
            .map(|fm| fm.iter().map(|m| m.0).collect::<Vec<u8>>())
            .into_pyobject(py)?
            .into_any()
            .unbind();

        Ok(Self {
            rust: t.clone(),
            py_schema_version,
            py_symbols,
            py_geometry,
            py_labels,
            py_formal_charges,
            py_partial_charges,
            py_connectivity,
            py_stereochemistry,
            py_velocities,
            py_fragments,
            py_fragment_formal_charges,
            py_fragment_partial_charges,
            py_fragment_multiplicities,
        })
    }
}

#[pymethods]
impl PyTopology {
    #[getter]
    fn schema_version(&self, py: Python<'_>) -> PyObject {
        self.py_schema_version.clone_ref(py)
    }
    #[getter]
    fn symbols(&self, py: Python<'_>) -> PyObject {
        self.py_symbols.clone_ref(py)
    }
    #[getter]
    fn geometry(&self, py: Python<'_>) -> PyObject {
        self.py_geometry.clone_ref(py)
    }
    #[getter]
    fn labels(&self, py: Python<'_>) -> PyObject {
        self.py_labels.clone_ref(py)
    }
    #[getter]
    fn formal_charges(&self, py: Python<'_>) -> PyObject {
        self.py_formal_charges.clone_ref(py)
    }
    #[getter]
    fn partial_charges(&self, py: Python<'_>) -> PyObject {
        self.py_partial_charges.clone_ref(py)
    }
    #[getter]
    fn connectivity(&self, py: Python<'_>) -> PyObject {
        self.py_connectivity.clone_ref(py)
    }
    #[getter]
    fn stereochemistry(&self, py: Python<'_>) -> PyObject {
        self.py_stereochemistry.clone_ref(py)
    }
    #[getter]
    fn velocities(&self, py: Python<'_>) -> PyObject {
        self.py_velocities.clone_ref(py)
    }
    #[getter]
    fn fragments(&self, py: Python<'_>) -> PyObject {
        self.py_fragments.clone_ref(py)
    }
    #[getter]
    fn fragment_formal_charges(&self, py: Python<'_>) -> PyObject {
        self.py_fragment_formal_charges.clone_ref(py)
    }
    #[getter]
    fn fragment_partial_charges(&self, py: Python<'_>) -> PyObject {
        self.py_fragment_partial_charges.clone_ref(py)
    }
    #[getter]
    fn fragment_multiplicities(&self, py: Python<'_>) -> PyObject {
        self.py_fragment_multiplicities.clone_ref(py)
    }
    #[getter]
    fn num_atoms(&self) -> usize {
        self.rust.symbols.len()
    }

    fn get_fragments_near_fragment(&self, frag_idx: u32, threshold: f32) -> PyResult<Vec<u32>> {
        self.rust
            .get_fragments_near_fragment(::libqdx::FragmentRef(frag_idx), threshold)
            .map(|fragments| {
                fragments
                    .into_iter()
                    .map(|fragment_ref| fragment_ref.0)
                    .collect()
            })
            .py_err()
    }

    fn to_dict(&self, py: Python<'_>) -> PyResult<PyObject> {
        serde_to_py(py, &self.rust)
    }

    #[staticmethod]
    fn from_dict(py: Python<'_>, data: &Bound<'_, PyAny>) -> PyResult<PyTopology> {
        PyTopology::build(py, &depythonize_into(data, "Topology")?)
    }

    fn __repr__(&self) -> String {
        format!("Topology(atoms={})", self.rust.symbols.len())
    }
}

#[pyclass(frozen, name = "Residues")]
pub struct PyResidues {
    rust: ::libqdx::Residues,
    py_residues: PyObject,
    py_seqs: PyObject,
    py_seq_ns: PyObject,
    py_insertion_codes: PyObject,
}

impl PyResidues {
    fn build(py: Python<'_>, r: &::libqdx::Residues) -> PyResult<Self> {
        let py_residues: Vec<Vec<u32>> = r
            .residues
            .iter()
            .map(|res| res.0.iter().map(|a| a.0).collect())
            .collect();
        let py_residues = py_residues.into_pyobject(py)?.into_any().unbind();
        let py_seqs = r.seqs.clone().into_pyobject(py)?.into_any().unbind();
        let py_seq_ns = r.seq_ns.clone().into_pyobject(py)?.into_any().unbind();
        let py_insertion_codes = r
            .insertion_codes
            .clone()
            .into_pyobject(py)?
            .into_any()
            .unbind();
        Ok(Self {
            rust: r.clone(),
            py_residues,
            py_seqs,
            py_seq_ns,
            py_insertion_codes,
        })
    }
}

#[pymethods]
impl PyResidues {
    #[getter]
    fn residues(&self, py: Python<'_>) -> PyObject {
        self.py_residues.clone_ref(py)
    }
    #[getter]
    fn seqs(&self, py: Python<'_>) -> PyObject {
        self.py_seqs.clone_ref(py)
    }
    #[getter]
    fn seq_ns(&self, py: Python<'_>) -> PyObject {
        self.py_seq_ns.clone_ref(py)
    }
    #[getter]
    fn insertion_codes(&self, py: Python<'_>) -> PyObject {
        self.py_insertion_codes.clone_ref(py)
    }
    #[getter]
    fn num_residues(&self) -> usize {
        self.rust.residues.len()
    }

    fn to_dict(&self, py: Python<'_>) -> PyResult<PyObject> {
        serde_to_py(py, &self.rust)
    }

    #[staticmethod]
    fn from_dict(py: Python<'_>, data: &Bound<'_, PyAny>) -> PyResult<PyResidues> {
        PyResidues::build(py, &depythonize_into(data, "Residues")?)
    }

    fn __repr__(&self) -> String {
        format!("Residues(count={})", self.rust.residues.len())
    }
}

#[pyclass(frozen, name = "Chains")]
pub struct PyChains {
    rust: ::libqdx::Chains,
    py_chains: PyObject,
    py_alpha_helices: PyObject,
    py_beta_sheets: PyObject,
}

impl PyChains {
    fn build(py: Python<'_>, c: &::libqdx::Chains) -> PyResult<Self> {
        let py_chains: Vec<Vec<u32>> = c
            .chains
            .iter()
            .map(|ch| ch.0.iter().map(|r| r.0).collect())
            .collect();
        let py_chains = py_chains.into_pyobject(py)?.into_any().unbind();
        let py_alpha_helices = c
            .alpha_helices
            .clone()
            .into_pyobject(py)?
            .into_any()
            .unbind();
        let py_beta_sheets = c.beta_sheets.clone().into_pyobject(py)?.into_any().unbind();
        Ok(Self {
            rust: c.clone(),
            py_chains,
            py_alpha_helices,
            py_beta_sheets,
        })
    }
}

#[pymethods]
impl PyChains {
    #[getter]
    fn chains(&self, py: Python<'_>) -> PyObject {
        self.py_chains.clone_ref(py)
    }
    #[getter]
    fn alpha_helices(&self, py: Python<'_>) -> PyObject {
        self.py_alpha_helices.clone_ref(py)
    }
    #[getter]
    fn beta_sheets(&self, py: Python<'_>) -> PyObject {
        self.py_beta_sheets.clone_ref(py)
    }
    #[getter]
    fn num_chains(&self) -> usize {
        self.rust.chains.len()
    }

    fn to_dict(&self, py: Python<'_>) -> PyResult<PyObject> {
        serde_to_py(py, &self.rust)
    }

    #[staticmethod]
    fn from_dict(py: Python<'_>, data: &Bound<'_, PyAny>) -> PyResult<PyChains> {
        PyChains::build(py, &depythonize_into(data, "Chains")?)
    }

    fn __repr__(&self) -> String {
        format!("Chains(count={})", self.rust.chains.len())
    }
}

fn to_atom_groups(groups: Vec<Vec<u32>>) -> Vec<Fragment> {
    groups
        .into_iter()
        .map(|g| Fragment::from(g.into_iter().map(AtomRef).collect::<Vec<_>>()))
        .collect()
}

fn to_residues(input: Option<Vec<Vec<u32>>>, num_atoms: usize) -> Vec<Residue> {
    input
        .map(|r| {
            r.into_iter()
                .map(|atoms| Residue(atoms.into_iter().map(AtomRef).collect()))
                .collect()
        })
        .unwrap_or_else(|| vec![Residue((0..num_atoms as u32).map(AtomRef).collect())])
}

#[pyclass(frozen, name = "TRC")]
pub struct PyTRC {
    inner: TRC,
    py_topology: Py<PyTopology>,
    py_residues: Py<PyResidues>,
    py_chains: Py<PyChains>,
}

impl PyTRC {
    fn new(py: Python<'_>, inner: TRC) -> PyResult<Self> {
        let py_topology = Py::new(py, PyTopology::build(py, &inner.topology)?)?;
        let py_residues = Py::new(py, PyResidues::build(py, &inner.residues)?)?;
        let py_chains = Py::new(py, PyChains::build(py, &inner.chains)?)?;
        Ok(Self {
            inner,
            py_topology,
            py_residues,
            py_chains,
        })
    }
}

#[pymethods]
impl PyTRC {
    #[new]
    #[pyo3(signature = (
        symbols,
        geometry,
        *,
        labels = None,
        formal_charges = None,
        partial_charges = None,
        connectivity = None,
        fragments = None,
        residues = None,
        residue_seqs = None,
        residue_seq_ns = None,
        residue_insertion_codes = None,
        chains = None,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn py_new(
        py: Python<'_>,
        symbols: Vec<Element>,
        geometry: Vec<[f32; 3]>,
        labels: Option<Vec<String>>,
        formal_charges: Option<Vec<i32>>,
        partial_charges: Option<Vec<f32>>,
        connectivity: Option<Vec<(u32, u32, u8)>>,
        fragments: Option<Vec<Vec<u32>>>,
        residues: Option<Vec<Vec<u32>>>,
        residue_seqs: Option<Vec<String>>,
        residue_seq_ns: Option<Vec<i32>>,
        residue_insertion_codes: Option<Vec<String>>,
        chains: Option<Vec<Vec<u32>>>,
    ) -> PyResult<Self> {
        let n = symbols.len();
        if geometry.len() != n {
            return Err(PyValueError::new_err(format!(
                "geometry has {} positions but there are {} symbols",
                geometry.len(),
                n
            )));
        }

        let rust_residues = to_residues(residues, n);
        let num_res = rust_residues.len();

        let topology = ::libqdx::Topology {
            symbols,
            geometry: geometry.into_iter().flatten().collect(),
            labels,
            formal_charges: formal_charges.map(|v| v.into_iter().map(FormalCharge).collect()),
            partial_charges: partial_charges.map(|v| v.into_iter().map(PartialCharge).collect()),
            connectivity: connectivity.map(|v| {
                v.into_iter()
                    .map(|(a, b, o)| ::libqdx::Bond(AtomRef(a), AtomRef(b), BondOrder::from(o)))
                    .collect()
            }),
            fragments: fragments.map(to_atom_groups),
            ..Default::default()
        };

        let residues = Residues {
            residues: rust_residues,
            seqs: residue_seqs.unwrap_or_else(|| vec!["UNK".into(); num_res]),
            seq_ns: residue_seq_ns.unwrap_or_else(|| (1..=num_res as i32).collect()),
            insertion_codes: residue_insertion_codes.unwrap_or_else(|| vec!["~".into(); num_res]),
            ..Default::default()
        };

        let chains = Chains {
            chains: chains
                .map(|v| {
                    v.into_iter()
                        .map(|r| ::libqdx::Chain(r.into_iter().map(::libqdx::ResidueRef).collect()))
                        .collect()
                })
                .unwrap_or_else(|| {
                    vec![::libqdx::Chain(
                        (0..num_res as u32).map(::libqdx::ResidueRef).collect(),
                    )]
                }),
            ..Default::default()
        };

        PyTRC::new(
            py,
            TRC {
                topology,
                residues,
                chains,
            },
        )
    }

    #[getter]
    fn topology(&self, py: Python<'_>) -> PyObject {
        self.py_topology.clone_ref(py).into_any()
    }
    #[getter]
    fn residues(&self, py: Python<'_>) -> PyObject {
        self.py_residues.clone_ref(py).into_any()
    }
    #[getter]
    fn chains(&self, py: Python<'_>) -> PyObject {
        self.py_chains.clone_ref(py).into_any()
    }
    #[getter]
    fn num_atoms(&self) -> usize {
        self.inner.topology.symbols.len()
    }
    #[getter]
    fn num_residues(&self) -> usize {
        self.inner.residues.residues.len()
    }
    #[getter]
    fn num_chains(&self) -> usize {
        self.inner.chains.chains.len()
    }

    #[pyo3(signature = (strictness=AtomCheckStrictness::Heavy))]
    fn perceive_bonds(&self, py: Python<'_>, strictness: AtomCheckStrictness) -> PyResult<PyTRC> {
        let mut trc = self.inner.clone();
        trc.perceive_bonds(strictness).py_err()?;
        PyTRC::new(py, trc)
    }

    fn perceive_formal_charges(&self, py: Python<'_>) -> PyResult<PyTRC> {
        let mut trc = self.inner.clone();
        trc.perceive_formal_charges().py_err()?;
        PyTRC::new(py, trc)
    }

    fn check(&self) -> PyResult<()> {
        self.inner.check().py_err()
    }

    fn extend(&self, py: Python<'_>, other: &PyTRC) -> PyResult<PyTRC> {
        let mut trc = self.inner.clone();
        trc.extend(other.inner.clone()).py_err()?;
        PyTRC::new(py, trc)
    }

    fn subset_by_residues(&self, py: Python<'_>, refs: Vec<u32>) -> PyResult<PyTRC> {
        let refs: Vec<_> = refs.into_iter().map(Into::into).collect();
        PyTRC::new(py, self.inner.new_trc_from_residue_subset(&refs))
    }

    fn with_fragments(&self, py: Python<'_>, fragments: Vec<Vec<u32>>) -> PyResult<PyTRC> {
        let num_atoms = self.inner.topology.symbols.len();
        let mut seen = vec![false; num_atoms];
        for (fi, frag) in fragments.iter().enumerate() {
            for &atom in frag {
                let a = atom as usize;
                if a >= num_atoms {
                    return Err(PyValueError::new_err(format!(
                        "fragment {fi} contains atom {atom}, but there are only {num_atoms} atoms"
                    )));
                }
                if seen[a] {
                    return Err(PyValueError::new_err(format!(
                        "atom {atom} appears in multiple fragments"
                    )));
                }
                seen[a] = true;
            }
        }
        if let Some(missing) = seen.iter().position(|&s| !s) {
            return Err(PyValueError::new_err(format!(
                "atom {missing} is not in any fragment"
            )));
        }

        let mut trc = self.inner.clone();
        let new_frags: Vec<Fragment> = fragments
            .into_iter()
            .map(|f| Fragment::from(f.into_iter().map(AtomRef).collect::<Vec<_>>()))
            .collect();

        trc.topology.fragment_formal_charges =
            trc.topology.formal_charges.as_ref().map(|charges| {
                new_frags
                    .iter()
                    .map(|frag| FormalCharge(frag.0.iter().map(|a| charges[a.0 as usize].0).sum()))
                    .collect()
            });
        trc.topology.fragment_partial_charges =
            trc.topology.partial_charges.as_ref().map(|charges| {
                new_frags
                    .iter()
                    .map(|frag| PartialCharge(frag.0.iter().map(|a| charges[a.0 as usize].0).sum()))
                    .collect()
            });
        trc.topology.fragment_multiplicities = None;
        trc.topology.fragments = Some(new_frags);

        PyTRC::new(py, trc)
    }

    fn with_geometry(&self, py: Python<'_>, geometry: Vec<[f32; 3]>) -> PyResult<PyTRC> {
        let n = self.inner.topology.symbols.len();
        if geometry.len() != n {
            return Err(PyValueError::new_err(format!(
                "geometry has {} positions but TRC has {} atoms",
                geometry.len(),
                n
            )));
        }
        let mut trc = self.inner.clone();
        trc.topology.geometry = geometry.into_iter().flatten().collect();
        PyTRC::new(py, trc)
    }

    fn to_dict(&self, py: Python<'_>) -> PyResult<PyObject> {
        serde_to_py(py, &self.inner)
    }

    #[staticmethod]
    fn from_dict(py: Python<'_>, data: &Bound<'_, PyAny>) -> PyResult<PyTRC> {
        PyTRC::new(py, depythonize_into(data, "TRC")?)
    }

    fn __repr__(&self) -> String {
        format!(
            "TRC(atoms={}, residues={}, chains={})",
            self.inner.topology.symbols.len(),
            self.inner.residues.residues.len(),
            self.inner.chains.chains.len()
        )
    }
}

#[pyfunction]
fn from_pdb(py: Python<'_>, contents: &str) -> PyResult<Vec<PyTRC>> {
    let mut trcs = pdb::from_pdb(contents).py_err_ctx("PDB parse error")?;
    for trc in &mut trcs {
        let _ = trc.perceive_bonds(AtomCheckStrictness::Heavy);
    }
    trcs.into_iter()
        .map(|inner| PyTRC::new(py, inner))
        .collect()
}

#[pyfunction]
fn to_pdb(trc: &PyTRC) -> PyResult<String> {
    pdb::to_pdb(&trc.inner).py_err_ctx("PDB write error")
}

#[pyfunction]
fn from_mmcif(py: Python<'_>, contents: &str) -> PyResult<Vec<PyTRC>> {
    let trcs = mmcif::from_mmcif(contents).py_err_ctx("mmCIF parse error")?;
    trcs.into_iter()
        .map(|inner| PyTRC::new(py, inner))
        .collect()
}

#[pyfunction]
fn from_sdf(py: Python<'_>, contents: &str) -> PyResult<Vec<PyTRC>> {
    let (trcs, _) = sdf::from_sdf(contents).py_err_ctx("SDF parse error")?;
    trcs.into_iter()
        .map(|inner| PyTRC::new(py, inner))
        .collect()
}

#[pyfunction]
fn to_sdf(trc: &PyTRC) -> PyResult<String> {
    let mut buf = Vec::new();
    sdf::to_sdf(std::slice::from_ref(&trc.inner), &[None], &mut buf)
        .py_err_ctx("SDF write error")?;
    String::from_utf8(buf).py_err_ctx("SDF encoding error")
}

#[pyfunction]
fn from_xyz(py: Python<'_>, contents: &str) -> PyResult<PyTRC> {
    let topology = xyz::from_xyz(contents).py_err_ctx("XYZ parse error")?;
    PyTRC::new(
        py,
        TRC {
            topology,
            residues: Residues::default(),
            chains: Chains::default(),
        },
    )
}

#[pyfunction]
fn to_xyz(trc: &PyTRC) -> PyResult<String> {
    xyz::to_xyz(&trc.inner.topology).py_err_ctx("XYZ write error")
}

#[pymodule]
fn libqdx(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyTRC>()?;
    m.add_class::<PyTopology>()?;
    m.add_class::<PyResidues>()?;
    m.add_class::<PyChains>()?;
    m.add_class::<Element>()?;
    m.add_class::<Bond>()?;
    m.add_class::<BondOrder>()?;
    m.add_class::<Stereochemistry>()?;
    m.add_class::<AminoAcidSeq>()?;
    m.add_class::<AlphaHelices>()?;
    m.add_class::<HelixClass>()?;
    m.add_class::<BetaSheets>()?;
    m.add_class::<StrandSense>()?;
    m.add_class::<AtomCheckStrictness>()?;
    m.add_function(wrap_pyfunction!(from_pdb, m)?)?;
    m.add_function(wrap_pyfunction!(to_pdb, m)?)?;
    m.add_function(wrap_pyfunction!(from_mmcif, m)?)?;
    m.add_function(wrap_pyfunction!(from_sdf, m)?)?;
    m.add_function(wrap_pyfunction!(to_sdf, m)?)?;
    m.add_function(wrap_pyfunction!(from_xyz, m)?)?;
    m.add_function(wrap_pyfunction!(to_xyz, m)?)?;
    Ok(())
}
