#[cfg(feature = "serde")]
#[cfg(feature = "rex")]
mod tests {
    use libqdx::{
        atom::{AtomRef, FormalCharge, HydrogenCapRef, PartialCharge},
        binding::BindingSiteBoundingBox,
        bond::{Bond, BondOrder, Stereochemistry},
        chain::{Chain, ChainRef, Chains},
        element::Element,
        fragment::{Fragment, FragmentMultiplicity, FragmentRef},
        libqdx_json_options,
        residue::ResidueRef,
        topology::{Topology, TopologyRef},
        version::SchemaVersion,
        xyz::Xyzf32,
    };
    use ouroboros::TypeInfo;
    use ouroboros_rex::ouroboros_to_rex;
    use rex::{Decode, Encode, Span, ToType, ast::assert_expr_eq, expr_to_json, json_to_expr};
    use serde::Serialize;
    use std::sync::Arc;

    fn compare_type<T>(_orig_value: T)
    where
        T: TypeInfo + ToType + Encode + Decode + Serialize + Clone + PartialEq + std::fmt::Debug,
    {
        let opts = libqdx_json_options();
        let r_type = Arc::new(T::to_type());
        let o_type = ouroboros_to_rex(&T::t(), &opts).unwrap();
        assert_eq!(r_type, o_type);
    }

    fn remove_nulls(value: serde_json::Value) -> serde_json::Value {
        match value {
            serde_json::Value::Object(map) => {
                let filtered: serde_json::Map<String, serde_json::Value> = map
                    .into_iter()
                    .filter_map(|(k, v)| {
                        let filtered_v = remove_nulls(v);
                        if filtered_v.is_null() {
                            None
                        } else {
                            Some((k, filtered_v))
                        }
                    })
                    .collect();
                serde_json::Value::Object(filtered)
            }
            serde_json::Value::Array(arr) => {
                let filtered: Vec<serde_json::Value> = arr
                    .into_iter()
                    .map(remove_nulls)
                    .filter(|v| !v.is_null())
                    .collect();
                serde_json::Value::Array(filtered)
            }
            other => other,
        }
    }

    fn compare_json<T>(orig_value: T)
    where
        T: TypeInfo + ToType + Encode + Decode + Serialize + Clone + PartialEq + std::fmt::Debug,
    {
        let opts = libqdx_json_options();

        let s_json = remove_nulls(serde_json::to_value(orig_value.clone()).unwrap());
        let expr = orig_value.clone().try_encode(Span::default()).unwrap();

        let r_type = Arc::new(T::to_type());
        let r_json = remove_nulls(expr_to_json(&expr, &r_type, &opts).unwrap());

        let o_type = ouroboros_to_rex(&T::t(), &opts).unwrap();
        let o_json = match expr_to_json(&expr, &o_type, &opts) {
            Ok(x) => remove_nulls(x),
            Err(e) => {
                panic!("expr_to_json: {}", e);
            }
        };

        let expr2 = match json_to_expr(&r_json, &r_type, &opts) {
            Ok(x) => x,
            Err(e) => {
                panic!("json_to_expr: {}", e);
            }
        };
        assert_expr_eq!(expr, expr2; ignore span);

        assert_eq!(s_json, o_json);
        assert_eq!(s_json, r_json);
    }

    fn compare<T>(orig_value: T)
    where
        T: TypeInfo + ToType + Encode + Decode + Serialize + Clone + PartialEq + std::fmt::Debug,
    {
        compare_type(orig_value.clone());
        compare_json(orig_value.clone());
    }

    #[test]
    fn test_atom_ref() {
        compare(AtomRef(4));
    }

    #[test]
    fn test_binding_site_bounding_box() {
        compare(BindingSiteBoundingBox {
            min: Xyzf32([0.1, 0.2, 0.3]),
            max: Xyzf32([0.4, 0.5, 0.7]),
        });
    }

    #[test]
    fn test_bond_order() {
        compare(BondOrder::Unspecified);
        compare(BondOrder::Single);
        compare(BondOrder::Double);
        compare(BondOrder::Triple);
        compare(BondOrder::Quadruple);
        compare(BondOrder::Quintuple);
        compare(BondOrder::Sextuple);
        compare(BondOrder::FiveAndAHalf);
        compare(BondOrder::FourAndAHalf);
        compare(BondOrder::ThreeAndAHalf);
        compare(BondOrder::TwoAndAHalf);
        compare(BondOrder::OneAndAHalf);
        compare(BondOrder::Ring);
    }

    #[test]
    fn test_bond() {
        compare(Bond(AtomRef(1), AtomRef(2), BondOrder::Double));
    }

    #[test]
    fn test_chains() {
        compare(Chains {
            chains: vec![Chain(vec![ResidueRef(0)])],
            ..Default::default()
        })
    }

    #[test]
    fn test_chain_ref() {
        compare(ChainRef(4));
    }

    #[test]
    fn test_element() {
        compare(Element::H);
        compare(Element::Si);
    }

    #[test]
    fn test_formal_charge() {
        compare(FormalCharge(1));
    }

    #[test]
    fn test_fragment_multiplicity() {
        compare(FragmentMultiplicity(4));
    }

    #[test]
    fn test_fragment_ref() {
        compare(FragmentRef(4));
    }

    #[test]
    fn test_fragment() {
        compare(Fragment(vec![AtomRef(1), AtomRef(2)]));
    }

    #[test]
    fn test_hydrogen_cap_ref() {
        compare(HydrogenCapRef(4));
    }

    #[test]
    fn test_partial_charge() {
        compare(PartialCharge(1.0));
    }

    #[test]
    fn test_residue_ref() {
        compare(ResidueRef(4));
    }

    #[test]
    fn test_schema_version() {
        compare(SchemaVersion::new(1, 2, 3));
    }

    #[test]
    fn test_stereochemistry() {
        compare(Stereochemistry::NONE);
        compare(Stereochemistry::Up);
        compare(Stereochemistry::Down);
        compare(Stereochemistry::Either);
        compare(Stereochemistry::CisOrTrans);
    }

    #[test]
    fn test_topology_ref() {
        compare(TopologyRef(4));
    }

    #[test]
    fn test_topology() {
        compare(Topology {
            schema_version: SchemaVersion::new(1, 2, 3),
            symbols: vec![Element::Si, Element::Mg],
            geometry: vec![2.5, 3.5],
            labels: Some(vec!["a".to_string(), "b".to_string()]),
            partial_charges: Some(vec![PartialCharge(1.2), PartialCharge(1.3)]),
            formal_charges: Some(vec![FormalCharge(5), FormalCharge(6)]),
            connectivity: Some(vec![Bond(AtomRef(1), AtomRef(2), BondOrder::Double)]),
            stereochemistry: Some(vec![Stereochemistry::Up, Stereochemistry::Down]),
            velocities: Some(vec![1.1, 1.2]),
            fragments: Some(vec![
                Fragment(vec![AtomRef(1), AtomRef(2)]),
                Fragment(vec![AtomRef(3), AtomRef(4)]),
            ]),
            fragment_formal_charges: Some(vec![FormalCharge(5), FormalCharge(6)]),
            fragment_partial_charges: Some(vec![PartialCharge(1.2), PartialCharge(1.3)]),
            fragment_multiplicities: Some(vec![FragmentMultiplicity(3), FragmentMultiplicity(2)]),
        });
    }
}
