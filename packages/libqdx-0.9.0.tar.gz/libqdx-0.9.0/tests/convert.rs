//! PDB vs mmCIF Conversion Tests
//!
//! These tests compare the output of parsing the same protein structure from both
//! PDB and mmCIF formats. The tests verify that:
//! 1. Topology (atoms, geometry, labels, etc.) match (excluding connectivity)
//! 2. Residues and chains match exactly
//! 3. PDB bonds are a subset of mmCIF bonds (PDB has special bonds only, mmCIF has all)
//!
//! ## Caching
//! Downloaded files and parsed results are cached in `test_cache/` (gitignored):
//! - `{pdb_id}.pdb` - Downloaded PDB file from RCSB
//! - `{pdb_id}.cif` - Downloaded mmCIF file from RCSB
//! - `{pdb_id}.<ext>.revision` - RCSB revision token for cache freshness checks
//! - `{pdb_id}.<ext>.<cache_key>.json` - Parsed TRC cache keyed by parser source + raw file
//!
//! To clear cache: `rm -rf test_cache/`

use libqdx::convert::{mmcif, parity, pdb};
use std::fs;
use std::hash::{DefaultHasher, Hash, Hasher};
use std::path::Path;

const CACHE_DIR: &str = "test_cache";
const PARSED_CACHE_FORMAT_VERSION: &str = "v2";

fn verbose_logs_enabled() -> bool {
    std::env::var_os("QDX_TEST_VERBOSE").is_some()
}

macro_rules! vlog {
    ($($arg:tt)*) => {
        if verbose_logs_enabled() {
            eprintln!($($arg)*);
        }
    };
}

/// Returns a revision token for an RCSB entry (if available).
///
/// This is intentionally best-effort: failures are logged and treated as
/// "unknown revision" so tests can still run from local cache when offline.
async fn fetch_entry_revision_token(pdb_id: &str) -> Option<String> {
    let url = format!(
        "https://data.rcsb.org/rest/v1/core/entry/{}",
        pdb_id.to_uppercase()
    );

    let response = match reqwest::get(&url).await {
        Ok(response) => response,
        Err(err) => {
            vlog!("  [cache info] Could not query entry revision for {pdb_id}: {err}");
            return None;
        }
    };

    if !response.status().is_success() {
        vlog!(
            "  [cache info] Entry revision API returned status {} for {}",
            response.status(),
            pdb_id
        );
        return None;
    }

    let body = match response.text().await {
        Ok(body) => body,
        Err(err) => {
            vlog!("  [cache info] Could not read entry revision response for {pdb_id}: {err}");
            return None;
        }
    };

    let value: serde_json::Value = match serde_json::from_str(&body) {
        Ok(value) => value,
        Err(err) => {
            vlog!("  [cache info] Could not parse entry revision response for {pdb_id}: {err}");
            return None;
        }
    };

    let info = &value["rcsb_accession_info"];
    let revision_date = info["revision_date"].as_str()?;
    let major_revision = info["major_revision"].as_i64().unwrap_or_default();
    let minor_revision = info["minor_revision"].as_i64().unwrap_or_default();

    Some(format!("{major_revision}.{minor_revision}:{revision_date}"))
}

fn revision_cache_path(pdb_id: &str, ext: &str) -> String {
    format!("{}/{}.{}.revision", CACHE_DIR, pdb_id, ext)
}

fn read_cached_revision_token(path: &str) -> Option<String> {
    fs::read_to_string(path)
        .ok()
        .map(|token| token.trim().to_string())
        .filter(|token| !token.is_empty())
}

fn parser_cache_key(ext: &str, raw_content: &str) -> String {
    let mut hasher = DefaultHasher::new();
    let parser_source = match ext {
        "pdb" => include_str!("../src/convert/pdb.rs"),
        "cif" => include_str!("../src/convert/mmcif.rs"),
        _ => "",
    };

    PARSED_CACHE_FORMAT_VERSION.hash(&mut hasher);
    parser_source.hash(&mut hasher);
    raw_content.hash(&mut hasher);
    format!("{:016x}", hasher.finish())
}

fn parsed_cache_path(pdb_id: &str, ext: &str, raw_content: &str) -> String {
    let cache_key = parser_cache_key(ext, raw_content);
    format!("{}/{}.{}.{}.json", CACHE_DIR, pdb_id, ext, cache_key)
}

async fn fetch_with_revision_cache(
    pdb_id: &str,
    ext: &str,
) -> Result<String, Box<dyn std::error::Error>> {
    let cache_path = format!("{}/{}.{}", CACHE_DIR, pdb_id, ext);
    let revision_path = revision_cache_path(pdb_id, ext);
    let latest_revision = fetch_entry_revision_token(pdb_id).await;

    if let Ok(cached_content) = fs::read_to_string(&cache_path) {
        let cached_revision = read_cached_revision_token(&revision_path);
        let needs_refresh = match (cached_revision.as_deref(), latest_revision.as_deref()) {
            (Some(cached), Some(latest)) => cached != latest,
            (None, Some(_)) => true,
            _ => false,
        };

        if !needs_refresh {
            vlog!("  [cache hit] Using cached {} file: {}", ext, cache_path);
            return Ok(cached_content);
        }

        vlog!(
            "  [cache stale] {} changed upstream; refreshing {}",
            pdb_id,
            cache_path
        );
    }

    vlog!(
        "  [cache miss] Downloading {} file: {}.{}",
        ext,
        pdb_id,
        ext
    );
    let url = format!("https://files.rcsb.org/download/{}.{}", pdb_id, ext);
    let response = reqwest::get(&url).await?;
    let content = response.text().await?;

    fs::create_dir_all(CACHE_DIR)?;
    fs::write(&cache_path, &content)?;
    if let Some(revision) = latest_revision {
        fs::write(&revision_path, format!("{revision}\n"))?;
    }
    vlog!("  [cached] Saved to: {}", cache_path);

    Ok(content)
}

/// Fetch a PDB file, using cache if available
async fn fetch_pdb(pdb_id: &str) -> Result<String, Box<dyn std::error::Error>> {
    fetch_with_revision_cache(pdb_id, "pdb").await
}

/// Fetch a mmCIF file, using cache if available
async fn fetch_mmcif(pdb_id: &str) -> Result<String, Box<dyn std::error::Error>> {
    fetch_with_revision_cache(pdb_id, "cif").await
}

/// Load or parse PDB file to TRC structures, with JSON caching
async fn load_or_parse_pdb(pdb_id: &str) -> Result<Vec<libqdx::TRC>, Box<dyn std::error::Error>> {
    let pdb_content = fetch_pdb(pdb_id).await?;
    let json_cache_path = parsed_cache_path(pdb_id, "pdb", &pdb_content);

    // Try to load from JSON cache
    if Path::new(&json_cache_path).exists()
        && let Ok(cached_json) = fs::read_to_string(&json_cache_path)
        && let Ok(trcs) = serde_json::from_str(&cached_json)
    {
        vlog!(
            "  [cache hit] Using cached parsed PDB JSON: {}",
            json_cache_path
        );
        return Ok(trcs);
    }

    // Parse from PDB file
    vlog!("  [cache miss] Parsing PDB file");
    let trcs = pdb::from_pdb(&pdb_content)?;

    // Save parsed result to JSON cache
    fs::create_dir_all(CACHE_DIR)?;
    let json = serde_json::to_string_pretty(&trcs)?;
    fs::write(&json_cache_path, &json)?;
    vlog!("  [cached] Saved parsed PDB to: {}", json_cache_path);

    Ok(trcs)
}

/// Load or parse mmCIF file to TRC structures, with JSON caching
async fn load_or_parse_mmcif(pdb_id: &str) -> Result<Vec<libqdx::TRC>, Box<dyn std::error::Error>> {
    let mmcif_content = fetch_mmcif(pdb_id).await?;
    let json_cache_path = parsed_cache_path(pdb_id, "cif", &mmcif_content);

    // Try to load from JSON cache
    if Path::new(&json_cache_path).exists()
        && let Ok(cached_json) = fs::read_to_string(&json_cache_path)
        && let Ok(trcs) = serde_json::from_str(&cached_json)
    {
        vlog!(
            "  [cache hit] Using cached parsed CIF JSON: {}",
            json_cache_path
        );
        return Ok(trcs);
    }

    // Parse from mmCIF file
    vlog!("  [cache miss] Parsing CIF file");
    let trcs = mmcif::from_mmcif(&mmcif_content)?;

    // Save parsed result to JSON cache
    fs::create_dir_all(CACHE_DIR)?;
    let json = serde_json::to_string_pretty(&trcs)?;
    fs::write(&json_cache_path, &json)?;
    vlog!("  [cached] Saved parsed CIF to: {}", json_cache_path);

    Ok(trcs)
}

async fn compare_pdb_mmcif(
    pdb_id: &str,
    allow_missing_pdb_bonds: bool,
) -> Result<(), Box<dyn std::error::Error>> {
    let pdb_result = load_or_parse_pdb(pdb_id).await?;
    let mmcif_result = load_or_parse_mmcif(pdb_id).await?;

    assert_eq!(
        pdb_result.len(),
        mmcif_result.len(),
        "{pdb_id}: model count mismatch (pdb {}, mmcif {})",
        pdb_result.len(),
        mmcif_result.len()
    );

    for (model_idx, (pdb_trc, mmcif_trc)) in pdb_result.iter().zip(mmcif_result.iter()).enumerate()
    {
        let context = format!("{pdb_id} model {model_idx}");

        if !parity::topology_matches_without_connectivity(
            &pdb_trc.topology,
            &mmcif_trc.topology,
            parity::GEOMETRY_TOLERANCE,
        ) {
            panic!(
                "{context}: topology mismatch (excluding connectivity): {}",
                parity::summarize_topology_mismatch(pdb_trc, mmcif_trc, parity::GEOMETRY_TOLERANCE,)
            );
        }

        if pdb_trc.residues != mmcif_trc.residues {
            panic!(
                "{context}: residue mismatch: {}",
                parity::summarize_residue_mismatch(pdb_trc, mmcif_trc)
            );
        }

        if pdb_trc.chains != mmcif_trc.chains {
            panic!(
                "{context}: chain mismatch: {}",
                parity::summarize_chain_mismatch(pdb_trc, mmcif_trc)
            );
        }

        if let Some(details) = parity::missing_pdb_bond_subset_error(pdb_trc, mmcif_trc) {
            if !allow_missing_pdb_bonds {
                panic!("{context}: PDB bonds are not a subset of mmCIF bonds: {details}");
            }
            vlog!("{context}: allowing known PDB/mmCIF bond mismatch: {details}");
        }
    }

    Ok(())
}

#[cfg(test)]
mod pdb_vs_mmcif {
    use super::*;

    #[tokio::test]
    async fn test_1crn_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        compare_pdb_mmcif("1crn", false).await
    }

    #[tokio::test]
    async fn test_1mbn_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        compare_pdb_mmcif("1mbn", false).await
    }

    #[tokio::test]
    async fn test_1lyz_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        compare_pdb_mmcif("1lyz", false).await
    }

    #[tokio::test]
    async fn test_1tim_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        compare_pdb_mmcif("1tim", false).await
    }

    #[tokio::test]
    async fn test_4ake_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        compare_pdb_mmcif("4ake", false).await
    }

    #[tokio::test]
    async fn test_2hhb_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        compare_pdb_mmcif("2hhb", false).await
    }

    #[tokio::test]
    async fn test_1bpi_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        compare_pdb_mmcif("1bpi", false).await
    }

    #[tokio::test]
    async fn test_1ubq_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        compare_pdb_mmcif("1ubq", false).await
    }

    #[tokio::test]
    async fn test_2ptc_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // 2PTC contains calcium ions with explicit metal coordination bonds (Ca-O) in the PDB file.
        // These metal coordination bonds are NOT included in the mmCIF chemical component dictionary,
        // which only defines covalent bonds within standard amino acid residues.
        // This is an expected difference between the formats, not a parsing bug.
        // The PDB file has 15 bonds total: 13 disulfide/standard bonds + 2 Ca-O coordination bonds.
        // Only the 13 standard bonds appear in the mmCIF output.
        compare_pdb_mmcif("2ptc", true).await
    }

    #[tokio::test]
    async fn test_1hvr_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        compare_pdb_mmcif("1hvr", false).await
    }

    #[tokio::test]
    async fn test_1fin_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // CDK2 kinase, enzyme
        compare_pdb_mmcif("1fin", false).await
    }

    #[tokio::test]
    async fn test_3sn6_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // β2-adrenergic receptor, GPCR complex with Gs
        compare_pdb_mmcif("3sn6", false).await
    }

    #[tokio::test]
    async fn test_2a65_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // LeuT, secondary transporter
        compare_pdb_mmcif("2a65", false).await
    }

    #[tokio::test]
    async fn test_1bl8_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // KcsA, potassium ion channel
        compare_pdb_mmcif("1bl8", false).await
    }

    #[tokio::test]
    async fn test_2sod_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Cu/Zn superoxide dismutase, oxidoreductase enzyme
        compare_pdb_mmcif("2sod", false).await
    }

    #[tokio::test]
    async fn test_1tnk_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Trypsin, serine protease
        // Contains calcium ions with explicit metal coordination bonds (Ca-O) in the PDB file.
        // These metal coordination bonds are NOT included in the mmCIF chemical component dictionary.
        // The PDB file has 24 bonds total: 22 disulfide/standard bonds + 2 Ca-O coordination bonds.
        compare_pdb_mmcif("1tnk", true).await
    }

    #[tokio::test]
    async fn test_1fm9_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // PPARγ ligand-binding domain, nuclear receptor
        compare_pdb_mmcif("1fm9", false).await
    }

    #[tokio::test]
    async fn test_2cg9_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Hsp90 N-terminal domain, chaperone
        compare_pdb_mmcif("2cg9", false).await
    }

    #[tokio::test]
    async fn test_1igt_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Intact IgG1, antibody
        // Contains glycosylation with explicit glycosidic bonds (O-C linkages between sugar residues)
        // in the PDB CONECT records. These inter-residue glycan linkages are NOT included in the mmCIF
        // chemical component dictionary, which only defines intra-residue covalent bonds.
        // The PDB file has 461 bonds total: 445 standard bonds + 16 glycosidic O-C linkages.
        // Examples of missing bonds: O4-C1, O6-C1, O3-C1, O2-C1 (typical glycosidic linkages).
        compare_pdb_mmcif("1igt", true).await
    }

    #[tokio::test]
    async fn test_4tz4_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Cereblon–DDB1 E3 ligase complex, ubiquitin–proteasome pathway
        compare_pdb_mmcif("4tz4", false).await
    }

    #[tokio::test]
    async fn test_1hsg_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // HIV-1 protease + indinavir (aspartyl protease, viral enzyme)
        compare_pdb_mmcif("1hsg", false).await
    }

    #[tokio::test]
    async fn test_2rh1_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // β2-adrenergic receptor (class A GPCR, T4L fusion)
        // Contains 1 glycosidic bond (O4-C1) that is in PDB CONECT but not in mmCIF.
        compare_pdb_mmcif("2rh1", true).await
    }

    #[tokio::test]
    async fn test_1a28_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Cyclophilin A + cyclosporin A (peptidyl-prolyl isomerase)
        compare_pdb_mmcif("1a28", false).await
    }

    #[tokio::test]
    async fn test_1opj_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // ABL kinase domain + imatinib (tyrosine kinase)
        compare_pdb_mmcif("1opj", false).await
    }

    #[tokio::test]
    async fn test_1stp_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Streptavidin + biotin (tetrameric binding protein)
        compare_pdb_mmcif("1stp", false).await
    }

    #[tokio::test]
    async fn test_1a6m_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Cytochrome c (electron-transfer heme protein)
        compare_pdb_mmcif("1a6m", false).await
    }

    #[tokio::test]
    async fn test_1tnf_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // TNF-α trimer (cytokine)
        compare_pdb_mmcif("1tnf", false).await
    }

    #[tokio::test]
    async fn test_4ins_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Insulin (hormone)
        // Contains zinc ion coordination (Zn-O bond) that is present in PDB CONECT records
        // but not in mmCIF chemical component dictionary.
        compare_pdb_mmcif("4ins", true).await
    }

    #[tokio::test]
    async fn test_1ppf_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Trypsin–BPTI complex (serine protease–inhibitor PPI)
        // Contains 14 glycosidic bonds (O-C linkages) that are in PDB CONECT but not in mmCIF.
        compare_pdb_mmcif("1ppf", true).await
    }

    #[tokio::test]
    async fn test_4pfk_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Phosphofructokinase (metabolic enzyme)
        // Contains magnesium ion coordination (2 Mg-O bonds) in PDB CONECT but not in mmCIF.
        compare_pdb_mmcif("4pfk", true).await
    }

    #[tokio::test]
    async fn test_1ca2_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Carbonic anhydrase II (metalloenzyme)
        compare_pdb_mmcif("1ca2", false).await
    }

    #[tokio::test]
    async fn test_2r9r_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Kv1.2 potassium channel (voltage-gated ion channel)
        compare_pdb_mmcif("2r9r", false).await
    }

    #[tokio::test]
    async fn test_2omf_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // OmpF porin (β-barrel outer-membrane channel)
        compare_pdb_mmcif("2omf", false).await
    }

    #[tokio::test]
    async fn test_1gpb_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Glycogen phosphorylase b (metabolic enzyme)
        // Contains 1 covalent modification bond (NZ-C4A, likely pyridoxal phosphate cofactor)
        // that is in PDB CONECT but not in mmCIF.
        compare_pdb_mmcif("1gpb", true).await
    }

    #[tokio::test]
    async fn test_7rsa_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Ribonuclease A (secreted endoribonuclease protein)
        compare_pdb_mmcif("7rsa", false).await
    }

    #[tokio::test]
    async fn test_1a4y_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Thrombin + inhibitor (coagulation serine protease)
        compare_pdb_mmcif("1a4y", false).await
    }

    #[tokio::test]
    async fn test_1m17_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // EGFR kinase + erlotinib (receptor tyrosine kinase domain)
        compare_pdb_mmcif("1m17", false).await
    }

    #[tokio::test]
    async fn test_1bvk_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Antibody Fab fragment (immune receptor)
        compare_pdb_mmcif("1bvk", false).await
    }

    #[tokio::test]
    async fn test_1cll_pdb_vs_mmcif() -> Result<(), Box<dyn std::error::Error>> {
        // Calmodulin (Ca2+-binding signaling protein)
        // Contains 4 calcium ion coordination bonds (Ca-O) in PDB CONECT but not in mmCIF.
        // Calmodulin is a Ca2+-binding protein, so these coordination bonds are expected.
        compare_pdb_mmcif("1cll", true).await
    }
}
