# libqdx

Made with <3 by QDX

## WASM
Run
```
wasm-pack build --scope talo --release --no-default-features --features serde,wasm,json
```

Sometimes getrandom complains, in which case you should

``` sh
export RUSTFLAGS='--cfg getrandom_backend="wasm_js"' 
```

before running wasm pack.

To pull wasm deps, you can enter this devshell
``` sh
nix develop .#libqdx
```

from the project root directory.  

To publish, ensure you have bumped the Cargo.toml version field, have a valid github packages .npmrc (see rush-base for setup) and then `npm publish` from the generated `pkg` directory.
