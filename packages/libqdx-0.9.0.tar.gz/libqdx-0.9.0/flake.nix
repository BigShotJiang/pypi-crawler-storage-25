{
  inputs = {
    flake-parts.url = "github:hercules-ci/flake-parts";
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    rust-flake-parts.url = "github:talo/qdx-rust-flake-parts";
    rust-flake-parts.inputs.nixpkgs.follows = "nixpkgs";
  };

  outputs =
    inputs@{ flake-parts, rust-flake-parts, ... }:
    flake-parts.lib.mkFlake { inherit inputs; } {
      imports = [
        rust-flake-parts.flakeModule
      ];
      systems = [
        "x86_64-linux"
        "aarch64-darwin"
      ];
      perSystem =
        { self', pkgs, ... }:
        {
          commonCraneArgs = {
            src = ./.;
            buildInputs = [
              pkgs.openssl.dev
              pkgs.wasm-pack
              pkgs.git
            ];
            extraFileTypesRegex = ".*pdb|.*sdf|.*json";
          };
          craneProjects.libqdx = {
            version = "0.8.0";
          };
          devShells = {
            default = pkgs.mkShell {
              inputsFrom = [ self'.devShells.libqdx ];
              packages = [
                pkgs.maturin
                pkgs.python3
                pkgs.uv
              ];
              # Needed for pip-installed numpy in the maturin develop venv.
              LD_LIBRARY_PATH = pkgs.lib.makeLibraryPath [
                pkgs.stdenv.cc.cc.lib
                pkgs.zlib
              ];
            };
          };
          packages = {
            default = self'.packages.libqdx;
          };
        };
    };
}
