use ouroboros::TypeInfo;
#[cfg(feature = "rex")]
use rex::Rex;

use crate::{AtomRef, ResidueRef, Xyzf32};

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(u8)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum BindingSiteInteractionKind {
    #[default]
    Unknown = 0,
    Hydrophobic = 1,
    HydrogenBond = 2,
    HalogenBond = 3,
    WaterBridge = 4,
    SaltBridge = 5,
    PiStack = 6,
    PiCation = 7,
    MetalComplex = 8,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(u8)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum PiStackKind {
    // Unknown
    #[default]
    Unknown = 0,
    // Perpendicular
    P = 1,
    // T-shaped
    T = 2,
}

#[derive(Clone, Copy, Debug, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(
        input_name = "BindingSiteInteractionInput",
        rename_fields = "snake_case"
    )
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct BindingSiteInteraction {
    /// Kind of interaction between the ligand and the receptor.
    pub kind: BindingSiteInteractionKind,

    /// In pi-stacking interactions what kind of stacking is happening?
    pub pi_stack_kind: Option<PiStackKind>,

    /// The ligand in the `Assembly` that is interacting with the receptor.
    pub ligand: ResidueRef,

    /// The atom in the ligand that is interacting with the receptor. Ignored
    /// for salt bridge and pi-interactions.
    pub ligand_atom: AtomRef,

    /// The co-ordinates of the interaction in the ligand. Often this is the
    /// co-ordinate of the `ligand_atom` but it is sometimes different (for
    /// example, in pi-stacking interactions).
    pub ligand_xyz: Xyzf32,

    /// The residue in the `Assembly` that is interacting with the ligand.
    pub receptor_residue: ResidueRef,

    /// The atom in the receptor that is interacting with the ligand. Ignored
    /// for salt bridge and pi-interactions.
    pub receptor_atom: AtomRef,

    /// The co-ordinates of the interaction in the receptor. Often this is the
    /// co-ordinate of the `receptor_atom` but it is sometimes different (for
    /// example, in pi-stacking interactions).
    pub receptor_xyz: Xyzf32,

    /// In hydrogen bonds and water bridges is the receptor the hydrogen bond
    /// donor?
    pub receptor_is_donor: bool,

    /// In pi-cation interactions is the receptor providing the charge?
    pub receptor_is_charged: bool,

    /// In salt bridges is the receptor carrying the positive charge?
    pub receptor_is_positively_charged: bool,
}
