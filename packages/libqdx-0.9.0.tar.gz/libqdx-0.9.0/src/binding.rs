use ouroboros::TypeInfo;
#[cfg(feature = "rex")]
use rex::Rex;

use crate::{Topology, Xyzf32};

#[derive(Clone, Debug, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(
        input_name = "BindingSiteBoundingBoxInput",
        name = "BindingSiteBoundingBox",
        rename_fields = "snake_case"
    )
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct BindingSiteBoundingBox {
    pub min: Xyzf32,
    pub max: Xyzf32,
}

impl BindingSiteBoundingBox {
    pub fn geom_center(&self) -> Xyzf32 {
        (self.min + self.max) / 2.0
    }

    pub fn geom_size(&self) -> Xyzf32 {
        self.max - self.min
    }

    pub fn grow(&self, size: f32) -> Self {
        let size = Xyzf32::new(size, size, size);
        BindingSiteBoundingBox {
            min: self.min - size,
            max: self.max + size,
        }
    }
}

impl From<Topology> for BindingSiteBoundingBox {
    fn from(topology: Topology) -> Self {
        let mut min = Xyzf32::new(f32::MAX, f32::MAX, f32::MAX);
        let mut max = Xyzf32::new(f32::MIN, f32::MIN, f32::MIN);

        for i in 0..topology.geometry.len() / 3 {
            let x = topology.geometry[i * 3];
            let y = topology.geometry[i * 3 + 1];
            let z = topology.geometry[i * 3 + 2];

            min.0[0] = min.0[0].min(x);
            min.0[1] = min.0[1].min(y);
            min.0[2] = min.0[2].min(z);

            max.0[0] = max.0[0].max(x);
            max.0[1] = max.0[1].max(y);
            max.0[2] = max.0[2].max(z);
        }

        Self { min, max }
    }
}

#[derive(Clone, Debug, PartialEq, TypeInfo)]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(
        input_name = "BindingSitesInput",
        name = "BindingSites",
        rename_fields = "snake_case"
    )
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct BindingSites {
    pub bounds: Vec<BindingSiteBoundingBox>,
    pub interactions: Vec<Vec<crate::interaction::BindingSiteInteraction>>,
    pub labels: Vec<String>,
}
