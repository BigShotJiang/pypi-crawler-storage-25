use std::collections::HashMap;
#[cfg(feature = "rex")]
use std::sync::Arc;

use ouroboros::{Alias, Type, TypeInfo, TypeName};
#[cfg(feature = "rex")]
use rex::{Decode, Encode, Error, Expr, Rex, Span, ToType, Type as RexType, TypeCon};
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use crate::ResidueRef;

#[cfg(feature = "graphql")]
async_graphql::scalar!(ChainRef);

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(
    feature = "pyo3",
    pyo3::pyclass(eq, eq_int, hash, frozen, from_py_object)
)]
pub enum HelixClass {
    RightHandedAlpha = 1,
    RightHandedOmega = 2,
    RightHandedPi = 3,
    RightHandedGamma = 4,
    RightHanded = 5,
    LeftHandedAlpha = 6,
    LeftHandedOmega = 7,
    LeftHandedGamma = 8,
    Ribbon27 = 9,
    Polyproline = 10,
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(
    feature = "pyo3",
    pyo3::pyclass(eq, eq_int, hash, frozen, from_py_object)
)]
pub enum StrandSense {
    First = 1,
    Parallel = 2,
    AntiParallel = 255,
}

impl StrandSense {
    pub fn from_pdb_sense(value: i32) -> Option<Self> {
        match value {
            0 => Some(Self::First),
            1 => Some(Self::Parallel),
            -1 => Some(Self::AntiParallel),
            _ => None,
        }
    }
}

impl HelixClass {
    pub fn from_pdb_class(value: i32) -> Option<Self> {
        match value {
            1 => Some(Self::RightHandedAlpha),
            2 => Some(Self::RightHandedOmega),
            3 => Some(Self::RightHandedPi),
            4 => Some(Self::RightHandedGamma),
            5 => Some(Self::RightHanded),
            6 => Some(Self::LeftHandedAlpha),
            7 => Some(Self::LeftHandedOmega),
            8 => Some(Self::LeftHandedGamma),
            9 => Some(Self::Ribbon27),
            10 => Some(Self::Polyproline),
            _ => None,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct ChainRef(pub u32);

impl TypeInfo for ChainRef {
    fn t() -> Type {
        Type::from(Alias::new("ChainRef", u32::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("ChainRef")
    }
}

impl From<u32> for ChainRef {
    fn from(value: u32) -> Self {
        Self(value)
    }
}

impl From<ChainRef> for u32 {
    fn from(value: ChainRef) -> Self {
        value.0
    }
}

#[cfg(feature = "rex")]
impl ToType for ChainRef {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::Uint)
    }
}

#[cfg(feature = "rex")]
impl Encode for ChainRef {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for ChainRef {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(ChainRef(u32::try_decode(v)?))
    }
}

#[cfg(feature = "graphql")]
async_graphql::scalar!(Chain);

#[derive(Clone, Debug, Default, Eq, Hash, PartialEq)]
#[repr(C)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Chain(pub Vec<ResidueRef>);

impl TypeInfo for Chain {
    fn t() -> Type {
        <Vec<ResidueRef>>::t()
    }

    fn tname() -> ouroboros::TypeName {
        <Vec<ResidueRef>>::tname()
    }
}

#[cfg(feature = "rex")]
impl ToType for Chain {
    fn to_type() -> RexType {
        <Vec<ResidueRef>>::to_type()
    }
}

#[cfg(feature = "rex")]
impl Encode for Chain {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for Chain {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(Chain(<Vec<ResidueRef>>::try_decode(v)?))
    }
}

impl From<Vec<ResidueRef>> for Chain {
    fn from(value: Vec<ResidueRef>) -> Self {
        Self(value)
    }
}

impl From<Vec<u32>> for Chain {
    fn from(value: Vec<u32>) -> Self {
        value.into_iter().map(ResidueRef).collect::<Vec<_>>().into()
    }
}

impl From<Chain> for Vec<ResidueRef> {
    fn from(value: Chain) -> Self {
        value.0
    }
}

impl From<Chain> for Vec<u32> {
    fn from(value: Chain) -> Self {
        value.0.into_iter().map(Into::into).collect()
    }
}

impl Chain {
    pub fn contains(&self, residue_ref: &ResidueRef) -> bool {
        self.0.contains(residue_ref)
    }
}

#[derive(Clone, Debug, Default, Eq, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "AlphaHelicesInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(feature = "pyo3", pyo3::pyclass(frozen, get_all, from_py_object))]
pub struct AlphaHelices {
    pub helix_ids: Vec<String>,
    pub chain_refs: Vec<ChainRef>,
    pub start_residues: Vec<ResidueRef>,
    pub end_residues: Vec<ResidueRef>,
    pub classes: Vec<Option<HelixClass>>,
    pub lengths: Vec<Option<u32>>,
}

impl AlphaHelices {
    pub fn len(&self) -> usize {
        self.helix_ids.len()
    }

    pub fn is_empty(&self) -> bool {
        self.helix_ids.is_empty()
    }

    pub fn push(
        &mut self,
        helix_id: String,
        chain_ref: ChainRef,
        start_residue: ResidueRef,
        end_residue: ResidueRef,
        class: Option<HelixClass>,
        length: Option<u32>,
    ) {
        self.helix_ids.push(helix_id);
        self.chain_refs.push(chain_ref);
        self.start_residues.push(start_residue);
        self.end_residues.push(end_residue);
        self.classes.push(class);
        self.lengths.push(length);
    }
}

#[derive(Clone, Debug, Default, Eq, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "BetaSheetsInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(feature = "pyo3", pyo3::pyclass(frozen, get_all, from_py_object))]
pub struct BetaSheets {
    pub sheet_ids: Vec<String>,
    pub strand_ids: Vec<String>,
    pub strand_ordinals: Vec<Option<u32>>,
    pub num_strands: Vec<Option<u32>>,
    pub chain_refs: Vec<ChainRef>,
    pub start_residues: Vec<ResidueRef>,
    pub end_residues: Vec<ResidueRef>,
    pub senses: Vec<Option<StrandSense>>,
}

impl BetaSheets {
    pub fn len(&self) -> usize {
        self.sheet_ids.len()
    }

    pub fn is_empty(&self) -> bool {
        self.sheet_ids.is_empty()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn push(
        &mut self,
        sheet_id: String,
        strand_id: String,
        strand_ordinal: Option<u32>,
        num_strands: Option<u32>,
        chain_ref: ChainRef,
        start_residue: ResidueRef,
        end_residue: ResidueRef,
        sense: Option<StrandSense>,
    ) {
        self.sheet_ids.push(sheet_id);
        self.strand_ids.push(strand_id);
        self.strand_ordinals.push(strand_ordinal);
        self.num_strands.push(num_strands);
        self.chain_refs.push(chain_ref);
        self.start_residues.push(start_residue);
        self.end_residues.push(end_residue);
        self.senses.push(sense);
    }
}

#[derive(Clone, Debug, Default, Eq, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "ChainsInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Chains {
    pub chains: Vec<Chain>,

    pub alpha_helices: Option<AlphaHelices>,
    pub beta_sheets: Option<BetaSheets>,

    /// WARN: Deprecated.
    pub labeled: Option<Vec<ChainRef>>,
    /// WARN: Deprecated.
    pub labels: Option<Vec<Vec<String>>>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum ChainsError {
    #[error("labeled and labels have different lengths")]
    LabelMismatch,
    #[error("labels are missing")]
    LabelsMissing,
    #[error("labeled is missing")]
    LabeledMissing,
}

impl Chains {
    pub fn check(&self) -> Result<(), ChainsError> {
        match (&self.labeled, &self.labels) {
            (Some(labeled), Some(labels)) => {
                if labeled.len() != labels.len() {
                    return Err(ChainsError::LabelMismatch);
                }
                for (i, r) in labeled.iter().enumerate() {
                    if r.0 as usize >= self.chains.len() {
                        return Err(ChainsError::LabelMismatch);
                    }
                    if i >= labels.len() {
                        return Err(ChainsError::LabelMismatch);
                    }
                }
            }
            (Some(_), None) => return Err(ChainsError::LabelsMissing),
            (None, Some(_)) => return Err(ChainsError::LabeledMissing),
            _ => {}
        }
        Ok(())
    }

    pub(crate) fn extend(&mut self, rhs: Self) -> Result<(), ChainsError> {
        let offset: usize = self.chains.iter().map(|c| c.0.len()).sum();
        let label_offset = self.chains.len();

        // if labeled is present for both, then we need to merge them. We always need to extend rhs by number of chains in lhs
        let mut rhs_labeled = rhs.labeled;
        rhs_labeled = rhs_labeled.map(|l| {
            l.into_iter()
                .map(|r| ChainRef(r.0 + label_offset as u32))
                .collect()
        });

        match (&mut self.labeled, rhs_labeled) {
            (Some(labeled), Some(rhs_labeled)) => {
                if let Some(labels) = &mut self.labels {
                    let rhs_labels = rhs.labels.ok_or(ChainsError::LabelsMissing)?;
                    for (i, rhs_r) in rhs_labeled.iter().enumerate() {
                        let rhs_labels = rhs_labels.get(i).unwrap();
                        if let Some(j) = labeled.iter().position(|&r| r == *rhs_r) {
                            labels[j].extend(rhs_labels.iter().cloned());
                        } else {
                            labeled.push(*rhs_r);
                            labels.push(rhs_labels.clone());
                        }
                    }
                }
            }
            (None, Some(labeled)) => {
                self.labeled = Some(labeled);
                self.labels = rhs.labels;
            }
            _ => {}
        };

        // chains need to be extended by offset of total residies in lhs chains
        self.chains.extend(rhs.chains.into_iter().map(|c| {
            let mut c = c;
            c.0 =
                c.0.into_iter()
                    .map(|r| ResidueRef(r.0 + offset as u32))
                    .collect();
            c
        }));

        let chain_offset = label_offset as u32;
        let residue_offset = offset as u32;

        let mut rhs_alpha_helices = rhs.alpha_helices;
        if let Some(alpha) = &mut rhs_alpha_helices {
            for r in alpha.chain_refs.iter_mut() {
                r.0 += chain_offset;
            }
            for r in alpha.start_residues.iter_mut() {
                r.0 += residue_offset;
            }
            for r in alpha.end_residues.iter_mut() {
                r.0 += residue_offset;
            }
        }

        match (&mut self.alpha_helices, rhs_alpha_helices) {
            (Some(lhs), Some(rhs)) => {
                lhs.helix_ids.extend(rhs.helix_ids);
                lhs.chain_refs.extend(rhs.chain_refs);
                lhs.start_residues.extend(rhs.start_residues);
                lhs.end_residues.extend(rhs.end_residues);
                lhs.classes.extend(rhs.classes);
                lhs.lengths.extend(rhs.lengths);
            }
            (None, Some(rhs)) => self.alpha_helices = Some(rhs),
            _ => {}
        }

        let mut rhs_beta_sheets = rhs.beta_sheets;
        if let Some(sheets) = &mut rhs_beta_sheets {
            for r in sheets.chain_refs.iter_mut() {
                r.0 += chain_offset;
            }
            for r in sheets.start_residues.iter_mut() {
                r.0 += residue_offset;
            }
            for r in sheets.end_residues.iter_mut() {
                r.0 += residue_offset;
            }
        }

        match (&mut self.beta_sheets, rhs_beta_sheets) {
            (Some(lhs), Some(rhs)) => {
                lhs.sheet_ids.extend(rhs.sheet_ids);
                lhs.strand_ids.extend(rhs.strand_ids);
                lhs.strand_ordinals.extend(rhs.strand_ordinals);
                lhs.num_strands.extend(rhs.num_strands);
                lhs.chain_refs.extend(rhs.chain_refs);
                lhs.start_residues.extend(rhs.start_residues);
                lhs.end_residues.extend(rhs.end_residues);
                lhs.senses.extend(rhs.senses);
            }
            (None, Some(rhs)) => self.beta_sheets = Some(rhs),
            _ => {}
        }

        Ok(())
    }

    pub fn new_chains_from_residue_subset(&self, residue_refs: &[ResidueRef]) -> Self {
        let mut new_chains = Chains::default();

        let mut old_to_new_chain_index = HashMap::<usize, usize>::new();
        for (residue_index, residue_ref) in residue_refs.iter().enumerate() {
            for (chain_index, chain) in self.chains.iter().enumerate() {
                if chain.contains(residue_ref) {
                    if let Some(&new_index) = old_to_new_chain_index.get(&chain_index) {
                        new_chains.chains[new_index]
                            .0
                            .push(ResidueRef(residue_index as u32));
                    } else {
                        old_to_new_chain_index.insert(chain_index, new_chains.chains.len());
                        new_chains
                            .chains
                            .push(Chain(vec![ResidueRef(residue_index as u32)]));
                    }
                }
            }
        }

        new_chains.alpha_helices = self.alpha_helices.as_ref().and_then(|alpha_helices| {
            let mut new_alpha = AlphaHelices::default();
            for i in 0..alpha_helices.len() {
                let old_chain_ref: usize = alpha_helices.chain_refs[i].0 as usize;
                let Some(&new_chain_ref) = old_to_new_chain_index.get(&old_chain_ref) else {
                    continue;
                };
                let Some(start_pos) = residue_refs
                    .iter()
                    .position(|other| other == &alpha_helices.start_residues[i])
                else {
                    continue;
                };
                let Some(end_pos) = residue_refs
                    .iter()
                    .position(|other| other == &alpha_helices.end_residues[i])
                else {
                    continue;
                };
                new_alpha.push(
                    alpha_helices.helix_ids[i].clone(),
                    ChainRef(new_chain_ref as u32),
                    ResidueRef(start_pos as u32),
                    ResidueRef(end_pos as u32),
                    alpha_helices.classes[i],
                    alpha_helices.lengths[i],
                );
            }
            (!new_alpha.is_empty()).then_some(new_alpha)
        });

        new_chains.beta_sheets = self.beta_sheets.as_ref().and_then(|beta_sheets| {
            let mut new_sheets = BetaSheets::default();
            for i in 0..beta_sheets.len() {
                let old_chain_ref: usize = beta_sheets.chain_refs[i].0 as usize;
                let Some(&new_chain_ref) = old_to_new_chain_index.get(&old_chain_ref) else {
                    continue;
                };
                let Some(start_pos) = residue_refs
                    .iter()
                    .position(|other| other == &beta_sheets.start_residues[i])
                else {
                    continue;
                };
                let Some(end_pos) = residue_refs
                    .iter()
                    .position(|other| other == &beta_sheets.end_residues[i])
                else {
                    continue;
                };

                new_sheets.push(
                    beta_sheets.sheet_ids[i].clone(),
                    beta_sheets.strand_ids[i].clone(),
                    beta_sheets.strand_ordinals[i],
                    beta_sheets.num_strands[i],
                    ChainRef(new_chain_ref as u32),
                    ResidueRef(start_pos as u32),
                    ResidueRef(end_pos as u32),
                    beta_sheets.senses[i],
                );
            }
            (!new_sheets.is_empty()).then_some(new_sheets)
        });

        if let Some(ref labeled) = self.labeled {
            let labels = self.labels.as_ref().unwrap();

            let mut new_labeled = Vec::new();
            let mut new_labels = Vec::new();

            for (old_index, new_index) in old_to_new_chain_index.iter() {
                if let Some(position) = labeled
                    .iter()
                    .position(|chain_ref| chain_ref.0 == *old_index as u32)
                {
                    new_labeled.push(ChainRef(*new_index as u32));
                    new_labels.push(labels[position].clone());
                }
            }

            if !new_labeled.is_empty() {
                new_chains.labeled = Some(new_labeled);
                new_chains.labels = Some(new_labels);
            }
        }

        new_chains
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_chain_ref() {
        let chain_ref = ChainRef(1);
        assert_eq!(u32::from(chain_ref), 1);
        assert_eq!(ChainRef::from(1), chain_ref);
    }

    #[test]
    fn test_chain() {
        let chain = Chain(vec![ResidueRef(1), ResidueRef(2)]);
        assert_eq!(Vec::<u32>::from(chain.clone()), vec![1, 2]);
        assert_eq!(Chain::from(vec![1, 2]), chain.clone());
    }

    #[test]
    fn test_chains() {
        let mut chains = Chains {
            labeled: Some(vec![ChainRef(0)]),
            labels: Some(vec![vec!["A".to_string()]]),
            chains: vec![Chain(vec![ResidueRef(0)])],
            alpha_helices: None,
            beta_sheets: None,
        };
        let chains2 = Chains {
            labeled: Some(vec![ChainRef(0)]),
            labels: Some(vec![vec!["B".to_string()]]),
            chains: vec![Chain(vec![ResidueRef(0)])],
            alpha_helices: None,
            beta_sheets: None,
        };
        chains.extend(chains2).unwrap();
        assert_eq!(chains.labeled, Some(vec![ChainRef(0), ChainRef(1)]));
        assert_eq!(
            chains.labels,
            Some(vec![vec!["A".to_string()], vec!["B".to_string()]])
        );
        assert_eq!(
            chains.chains,
            vec![Chain(vec![ResidueRef(0)]), Chain(vec![ResidueRef(1)])]
        );
    }

    #[test]
    fn test_chains_extend_error() {
        let mut chains = Chains {
            labeled: Some(vec![ChainRef(0)]),
            labels: Some(vec![vec!["A".to_string()]]),
            chains: vec![Chain(vec![ResidueRef(0)])],
            alpha_helices: None,
            beta_sheets: None,
        };
        let chains2 = Chains {
            labeled: Some(vec![ChainRef(0)]),
            labels: None,
            chains: vec![Chain(vec![ResidueRef(0)])],
            alpha_helices: None,
            beta_sheets: None,
        };
        assert_eq!(
            chains.extend(chains2).unwrap_err(),
            ChainsError::LabelsMissing
        );
    }

    #[test]
    fn test_new_chain_from_residue_subset() {
        let chains = Chains {
            chains: vec![
                Chain(vec![ResidueRef(0), ResidueRef(1), ResidueRef(2)]),
                Chain(vec![ResidueRef(3), ResidueRef(4), ResidueRef(5)]),
                Chain(vec![ResidueRef(6), ResidueRef(7), ResidueRef(8)]),
            ],
            alpha_helices: Some(AlphaHelices {
                helix_ids: vec!["H1".to_string(), "H2".to_string(), "H3".to_string()],
                chain_refs: vec![ChainRef(0), ChainRef(1), ChainRef(2)],
                start_residues: vec![ResidueRef(0), ResidueRef(3), ResidueRef(6)],
                end_residues: vec![ResidueRef(2), ResidueRef(5), ResidueRef(8)],
                classes: vec![Some(HelixClass::RightHandedAlpha); 3],
                lengths: vec![Some(3); 3],
            }),
            beta_sheets: Some(BetaSheets {
                sheet_ids: vec!["S".to_string(), "S".to_string(), "S".to_string()],
                strand_ids: vec!["A".to_string(), "B".to_string(), "C".to_string()],
                strand_ordinals: vec![Some(1), Some(2), Some(3)],
                num_strands: vec![Some(3), Some(3), Some(3)],
                chain_refs: vec![ChainRef(0), ChainRef(1), ChainRef(2)],
                start_residues: vec![ResidueRef(1), ResidueRef(4), ResidueRef(7)],
                end_residues: vec![ResidueRef(2), ResidueRef(4), ResidueRef(7)],
                senses: vec![
                    Some(StrandSense::First),
                    Some(StrandSense::Parallel),
                    Some(StrandSense::AntiParallel),
                ],
            }),
            labeled: Some(vec![ChainRef(1), ChainRef(2)]),
            labels: Some(vec![
                vec!["one".to_string()],
                vec!["two".to_string(), "three".to_string()],
            ]),
        };

        let residue_refs = vec![ResidueRef(1), ResidueRef(3), ResidueRef(4), ResidueRef(5)];

        let expected_chains = Chains {
            chains: vec![
                Chain(vec![ResidueRef(0)]),
                Chain(vec![ResidueRef(1), ResidueRef(2), ResidueRef(3)]),
            ],
            alpha_helices: Some(AlphaHelices {
                helix_ids: vec!["H2".to_string()],
                chain_refs: vec![ChainRef(1)],
                start_residues: vec![ResidueRef(1)],
                end_residues: vec![ResidueRef(3)],
                classes: vec![Some(HelixClass::RightHandedAlpha)],
                lengths: vec![Some(3)],
            }),
            beta_sheets: Some(BetaSheets {
                sheet_ids: vec!["S".to_string()],
                strand_ids: vec!["B".to_string()],
                strand_ordinals: vec![Some(2)],
                num_strands: vec![Some(3)],
                chain_refs: vec![ChainRef(1)],
                start_residues: vec![ResidueRef(2)],
                end_residues: vec![ResidueRef(2)],
                senses: vec![Some(StrandSense::Parallel)],
            }),
            labeled: Some(vec![ChainRef(1)]),
            labels: Some(vec![vec!["one".to_string()]]),
        };

        let new_chains = chains.new_chains_from_residue_subset(&residue_refs);

        assert!(new_chains.check().is_ok());

        assert_eq!(new_chains.chains, expected_chains.chains);
        assert_eq!(new_chains.alpha_helices, expected_chains.alpha_helices);
        assert_eq!(new_chains.beta_sheets, expected_chains.beta_sheets);
        assert_eq!(new_chains.labeled, expected_chains.labeled);
        assert_eq!(new_chains.labels, expected_chains.labels);
    }
}
