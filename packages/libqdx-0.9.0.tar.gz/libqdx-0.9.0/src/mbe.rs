use ouroboros::TypeInfo;
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use crate::{
    version::SchemaVersion,
    {FragmentDistanceMethod, FragmentDistanceMetric, FragmentRef, Method, Tensorf64},
};

use super::Nmer;

#[derive(Clone, Debug, Default, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "QMMBEInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct QMMBE {
    pub schema_version: SchemaVersion,

    /// Method used to compute this output.
    pub method: Method,

    /// Distance metric used to compute fragment distances for this computation.
    pub distance_metric: Option<FragmentDistanceMetric>,
    pub distance_method: Option<FragmentDistanceMethod>,

    /// The 1st element contains all monomers, the 2nd element contains all
    /// dimers, the 3rd element contains all trimers, and so on.
    pub nmers: Vec<Vec<Nmer>>,

    /// Index into the first element of `nmers` that identifies the monomer used
    /// as the reference monomer for the interaction calculation. If this value
    /// is `None` then the `expanded_hf_energy`, `expanded_mp2_ss_correction`,
    /// and `expanded_mp2_os_correction` energies should be interpreted as the
    /// total energy of the system. Otherwise, these energies should be
    /// interpreted as the interaction energy between the reference monomer and
    /// the rest of the system.
    pub reference_fragment: Option<FragmentRef>,

    /// Either the total HF energy of the system or the total HF interaction
    /// energy between the `reference_fragment` and the rest of the system. This
    /// value is only present when `method` is one of the HF or MP2 methods.
    pub expanded_hf_energy: Option<f64>,

    pub classical_water_energy: Option<f64>,

    /// Either the total MP2 same-spin energy correction of the system or the
    /// total MP2 same-spin energy correction for the interaction energy between
    /// the `reference_fragment` and the rest of the system. This value is only
    /// present when `method` is one of the MP2 methods.
    pub expanded_mp2_ss_correction: Option<f64>,

    /// Either the total MP2 opposite-spin energy correction of the system or
    /// the total MP2 opposite-spin energy correction for the interaction energy
    /// between the `reference_fragment` and the rest of the system. This value
    /// is only present when `method` is one of the MP2 methods.
    pub expanded_mp2_os_correction: Option<f64>,

    /// The total CCSD energy correction of the system. This value is only present when `method` is one of the CCSD methods.
    pub expanded_ccsd_correction: Option<f64>,

    /// The converged density matrix of the entire system in either
    /// square-symmetric or vectorised lower-triangular form.
    ///
    /// If `reference_fragment` is `Some`, then `expanded_density` must be
    /// `None`.
    pub expanded_density: Option<Tensorf64>,

    /// Hartree-Fock gradient vectors for each atom in the entire system. The
    /// gradients are ordered according to the atom ordering in respective
    /// `Topology`. If `expanded_hf_gradients` is `Some`, then
    /// `expanded_mp2_gradients` must be `None`.
    /// If `reference_fragment` is `Some`, then `expanded_hf_gradients` must be
    /// `None`.
    pub expanded_hf_gradients: Option<Vec<f64>>,

    /// MP2 gradient vectors for each atom in the entire system. The gradients
    /// are ordered according to the atom ordering in respective `Topology`. If
    /// `expanded_mp2_gradients` is `Some`, then `expanded_hf_gradients` must be
    /// `None`.
    /// If `reference_fragment` is `Some`, then `expanded_mp2_gradients` must be
    /// `None`.
    pub expanded_mp2_gradients: Option<Vec<f64>>,

    /// Number of SCF iterations required to reach convergence across all
    /// `Nmers`.
    pub num_iters: u32,
}
