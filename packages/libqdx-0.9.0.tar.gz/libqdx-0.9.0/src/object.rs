#[cfg(feature = "rex")]
use std::sync::Arc;
use std::{fs, io, marker::PhantomData, path::PathBuf};

#[cfg(any(feature = "rex", feature = "serde"))]
use ouroboros::{Fields, MutableValueVisitor, TypeVisitor, ValueVisitor};
use ouroboros::{Optional, Ptr, Record, Type, TypeInfo, TypeName};
#[cfg(feature = "rex")]
use rex::{
    Rex,
    ast::expr::Expr,
    engine::{
        codec::{Decode, Encode},
        error::Error as EngineError,
    },
    lexer::span::Span,
    type_system::types::{ADT, ADTVariant, ToType, Type as RexType},
};
#[cfg(feature = "serde")]
use serde::{Deserialize, Deserializer, Serialize, Serializer};
#[cfg(feature = "serde")]
use serde_json::{Map, Value};
use uuid::Uuid;

#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Copy, Clone, Default, Debug, Eq, PartialEq, TypeInfo)]
pub enum ObjectFormat {
    #[default]
    #[cfg_attr(feature = "serde", serde(rename = "json"))]
    #[cfg_attr(feature = "graphql", graphql(name = "json"))]
    Json,
    #[cfg_attr(feature = "serde", serde(rename = "bin"))]
    #[cfg_attr(feature = "graphql", graphql(name = "bin"))]
    Bin,
}

fn default_object_format() -> ObjectFormat {
    ObjectFormat::Json
}

// Implement these traits manually as derive(Rex) currently doens't handle renames in enums
#[cfg(feature = "rex")]
impl ToType for ObjectFormat {
    fn to_type() -> RexType {
        RexType::ADT(ADT {
            name: "ObjectFormat".to_string(),
            docs: None,
            variants: vec![
                ADTVariant {
                    name: "json".to_string(),
                    t: None,
                    docs: None,
                    t_docs: None,
                    discriminant: None,
                },
                ADTVariant {
                    name: "bin".to_string(),
                    t: None,
                    docs: None,
                    t_docs: None,
                    discriminant: None,
                },
            ],
        })
    }
}

#[cfg(feature = "rex")]
impl Encode for ObjectFormat {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, EngineError> {
        match self {
            ObjectFormat::Json => Ok(Arc::new(Expr::Named(span, "json".to_string(), None))),
            ObjectFormat::Bin => Ok(Arc::new(Expr::Named(span, "bin".to_string(), None))),
        }
    }
}

#[cfg(feature = "rex")]
impl Decode for ObjectFormat {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, EngineError> {
        match &**v {
            Expr::Named(_, name, None) if name == "json" => Ok(ObjectFormat::Json),
            Expr::Named(_, name, None) if name == "bin" => Ok(ObjectFormat::Json),
            _ => Err(EngineError::ExpectedTypeGotValue {
                expected: Arc::new(Self::to_type()),
                got: v.clone(),
                trace: Default::default(),
            }),
        }
    }
}

#[cfg_attr(feature = "graphql", derive(async_graphql::SimpleObject))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, Eq, PartialEq)]
#[cfg_attr(feature = "rex", derive(Rex))]
pub struct VirtualObject {
    pub path: String,
    pub size: u64,

    #[cfg_attr(feature = "serde", serde(default = "default_object_format"))]
    pub format: ObjectFormat,
}

impl<T> From<&Object<T>> for VirtualObject {
    fn from(obj: &Object<T>) -> Self {
        Self {
            path: obj.fd.display().to_string(),
            size: obj.fd.metadata().map(|m| m.len()).unwrap_or(0),
            format: obj.format,
        }
    }
}

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, Eq, PartialEq)]
#[cfg_attr(feature = "rex", derive(Rex))]
pub struct VirtualObjectWithoutFormat {
    pub path: String,
    pub size: u64,
}

#[derive(Debug)]
pub struct Object<T> {
    _t: PhantomData<T>,
    pub fd: PathBuf,
    pub format: ObjectFormat,
}

impl<T> PartialEq for Object<T> {
    fn eq(&self, other: &Self) -> bool {
        VirtualObject::from(self) == VirtualObject::from(other)
    }
}

impl<T> Object<T> {
    pub fn new() -> io::Result<Self> {
        let fd = Uuid::new_v4().to_string();
        let fd = fd.into();
        Ok(Self {
            _t: PhantomData,
            fd,
            format: ObjectFormat::Json,
        })
    }

    /// Create a a temporary object that will be deleted when the object is dropped
    pub fn temp() -> io::Result<Self> {
        let fd = tempfile::tempdir()?.keep().join("temp");

        Ok(Self {
            _t: PhantomData,
            fd,
            format: ObjectFormat::Json,
        })
    }

    pub fn with_fd<U: Into<PathBuf>>(fd: U) -> io::Result<Self> {
        let fd = fd.into();

        Ok(Self {
            _t: PhantomData,
            fd,
            format: ObjectFormat::Json,
        })
    }

    pub fn with_format(mut self, format: ObjectFormat) -> io::Result<Self> {
        self.format = format;
        Ok(self)
    }

    pub fn delete(self) -> io::Result<()> {
        fs::remove_file(self.fd)
    }

    /// Copy the file to the given path
    pub fn copy(&self, path: &PathBuf) -> io::Result<u64> {
        fs::copy(&self.fd, path)
    }
}

impl<T> TypeInfo for Object<T>
where
    T: TypeInfo,
{
    fn tname() -> TypeName {
        TypeName::with_generics("Object", [T::tname()])
    }

    fn t() -> Type {
        Type::Record(Record::new(
            "Object",
            [
                ("path", Type::from(Ptr::new(T::t()))),
                ("size", u64::t()),
                ("format", Type::from(Optional::new(ObjectFormat::t()))),
            ],
        ))
    }
}

#[cfg(feature = "serde")]
impl<'de, T> Deserialize<'de> for Object<T> {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        let obj = VirtualObject::deserialize(deserializer)?;
        Ok(Self {
            _t: PhantomData,
            fd: obj.path.into(),
            format: obj.format,
        })
    }
}

#[cfg(feature = "serde")]
impl<T> Serialize for Object<T> {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        VirtualObject {
            path: self.fd.display().to_string(),
            size: 0,
            format: self.format,
        }
        .serialize(serializer)
    }
}

#[cfg(feature = "serde")]
pub struct FirstObjectValueVisitor<F, Error>
where
    F: FnOnce(&VirtualObject, &Type) -> Result<(), Error>,
{
    f: Option<F>,
}

#[cfg(feature = "serde")]
impl<F, Error> FirstObjectValueVisitor<F, Error>
where
    F: FnOnce(&VirtualObject, &Type) -> Result<(), Error>,
{
    pub fn new(f: F) -> Self {
        Self { f: Some(f) }
    }
}

#[cfg(feature = "serde")]
impl<F, Error> ValueVisitor for FirstObjectValueVisitor<F, Error>
where
    F: FnOnce(&VirtualObject, &Type) -> Result<(), Error>,
{
    type Error = Error;

    fn visit_record_with_named_fields(
        &mut self,
        rec: &Record,
        val: &Map<String, Value>,
    ) -> Result<(), Self::Error> {
        if rec.n == "Object"
            && val.len() >= 2
            && val.contains_key("path")
            && val.contains_key("size")
            && let Ok(obj) = serde_json::from_value::<VirtualObject>(Value::Object(val.clone()))
            && let Fields::Named(named_fields) = &rec.fields
            && let Some(path) = named_fields.get("path")
            && let Type::Ptr(ptr) = &path.t
        {
            let f = self.f.take();
            if let Some(f) = f {
                return f(&obj, &ptr.t);
            }
        }
        Ok(())
    }
}

#[cfg(feature = "serde")]
pub struct FirstObjectTypeVisitor<F, Error>
where
    F: FnOnce(&Type) -> Result<(), Error>,
{
    f: Option<F>,
}

#[cfg(feature = "serde")]
impl<F, Error> FirstObjectTypeVisitor<F, Error>
where
    F: FnOnce(&Type) -> Result<(), Error>,
{
    pub fn new(f: F) -> Self {
        Self { f: Some(f) }
    }
}

#[cfg(feature = "serde")]
impl<F, Error> TypeVisitor for FirstObjectTypeVisitor<F, Error>
where
    F: FnOnce(&Type) -> Result<(), Error>,
{
    type Error = Error;

    fn visit_record_with_named_fields(&mut self, rec: &Record) -> Result<(), Self::Error> {
        if rec.n == "Object"
            && let Fields::Named(ref named_fields) = rec.fields
            && let Some(path) = named_fields.get("path")
            && let Type::Ptr(ptr) = &path.t
        {
            let f = self.f.take();
            if let Some(f) = f {
                return f(&ptr.t);
            }
        }
        Ok(())
    }
}

#[cfg(feature = "serde")]
pub struct ObjectValueVisitor<F, Error>
where
    F: FnMut(&VirtualObject, &Type) -> Result<(), Error>,
{
    f: F,
}

#[cfg(feature = "serde")]
impl<F, Error> ObjectValueVisitor<F, Error>
where
    F: FnMut(&VirtualObject, &Type) -> Result<(), Error>,
{
    pub fn new(f: F) -> Self {
        Self { f }
    }
}

#[cfg(feature = "serde")]
impl<F, Error> ValueVisitor for ObjectValueVisitor<F, Error>
where
    F: FnMut(&VirtualObject, &Type) -> Result<(), Error>,
{
    type Error = Error;

    fn visit_record_with_named_fields(
        &mut self,
        rec: &Record,
        val: &Map<String, Value>,
    ) -> Result<(), Self::Error> {
        if rec.n == "Object"
            && val.contains_key("path")
            && let Ok(obj) = serde_json::from_value::<VirtualObject>(Value::Object(val.clone()))
            && let Fields::Named(named_fields) = &rec.fields
            && let Some(path) = named_fields.get("path")
            && let Type::Ptr(ptr) = &path.t
        {
            return (self.f)(&obj, &ptr.t);
        }
        Ok(())
    }
}

#[cfg(feature = "serde")]
pub struct ObjectMutableValueVisitor<F, Error>
where
    F: FnMut(&mut VirtualObject, &Type) -> Result<(), Error>,
{
    f: F,
}

#[cfg(feature = "serde")]
impl<F, Error> ObjectMutableValueVisitor<F, Error>
where
    F: FnMut(&mut VirtualObject, &Type) -> Result<(), Error>,
{
    pub fn new(f: F) -> Self {
        Self { f }
    }
}

#[cfg(feature = "serde")]
impl<F, Error> MutableValueVisitor for ObjectMutableValueVisitor<F, Error>
where
    F: FnMut(&mut VirtualObject, &Type) -> Result<(), Error>,
{
    type Error = Error;

    fn visit_record_with_named_fields(
        &mut self,
        rec: &mut Record,
        val: &mut Map<String, Value>,
    ) -> Result<(), Self::Error> {
        if rec.n == "Object"
            && val.contains_key("path")
            && let Ok(ref mut obj) =
                serde_json::from_value::<VirtualObject>(Value::Object(val.clone()))
            && let Fields::Named(named_fields) = &rec.fields
            && let Some(path) = named_fields.get("path")
            && let Type::Ptr(ptr) = &path.t
        {
            let _ = (self.f)(obj, &ptr.t);
            // have to unwrap here because the error is generic
            let obj_map = serde_json::to_value(obj)
                .unwrap()
                .as_object()
                .unwrap()
                .clone();

            val.clear();
            val.extend(obj_map);
        }
        Ok(())
    }
}

#[cfg(feature = "serde")]
pub struct ObjectTypeVisitor<F, Error>
where
    F: FnMut(&Type) -> Result<(), Error>,
{
    f: F,
}

#[cfg(feature = "serde")]
impl<F, Error> ObjectTypeVisitor<F, Error>
where
    F: FnMut(&Type) -> Result<(), Error>,
{
    pub fn new(f: F) -> Self {
        Self { f }
    }
}

#[cfg(feature = "serde")]
impl<F, Error> TypeVisitor for ObjectTypeVisitor<F, Error>
where
    F: FnMut(&Type) -> Result<(), Error>,
{
    type Error = Error;

    fn visit_record_with_named_fields(&mut self, rec: &Record) -> Result<(), Self::Error> {
        if rec.n == "Object"
            && let Fields::Named(ref named_fields) = rec.fields
            && let Some(path) = named_fields.get("path")
            && let Type::Ptr(ptr) = &path.t
        {
            return (self.f)(&ptr.t);
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct TypedVirtualObject<T> {
    pub path: String,
    pub size: u64,

    #[cfg_attr(feature = "serde", serde(skip))]
    pub _t: PhantomData<T>,
}

impl<T> TypeInfo for TypedVirtualObject<T>
where
    T: TypeInfo,
{
    fn tname() -> TypeName {
        TypeName::with_generics("Object", [T::tname()])
    }

    fn t() -> Type {
        Type::Record(Record::new(
            "Object",
            [("path", Type::from(Ptr::new(T::t()))), ("size", u64::t())],
        ))
    }
}

#[cfg(feature = "rex")]
impl<T> ToType for TypedVirtualObject<T> {
    fn to_type() -> RexType {
        VirtualObjectWithoutFormat::to_type()
    }
}

#[cfg(feature = "rex")]
impl<T> Encode for TypedVirtualObject<T> {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, EngineError> {
        let vobj = VirtualObjectWithoutFormat {
            path: self.path.clone(),
            size: self.size,
        };
        vobj.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl<T> Decode for TypedVirtualObject<T> {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, EngineError> {
        let vobj = VirtualObjectWithoutFormat::try_decode(v)?;
        Ok(TypedVirtualObject {
            path: vobj.path,
            size: vobj.size,
            _t: PhantomData,
        })
    }
}

#[cfg(all(feature = "graphql", feature = "json"))]
#[async_graphql::Scalar]
impl<T> async_graphql::ScalarType for TypedVirtualObject<T>
where
    T: Send + Sync,
{
    fn parse(value: async_graphql::Value) -> async_graphql::InputValueResult<Self> {
        use async_graphql::InputType;

        let json_value: serde_json::Value = serde_json::Value::parse(Some(value))?;
        Ok(serde_json::from_value(json_value)?)
    }

    fn to_value(&self) -> async_graphql::Value {
        async_graphql::Value::Object(indexmap::indexmap! {
            async_graphql::Name::new("path") => async_graphql::Value::String(self.path.clone()),
            async_graphql::Name::new("size") => async_graphql::Value::Number(self.size.into()),
        })
    }
}
