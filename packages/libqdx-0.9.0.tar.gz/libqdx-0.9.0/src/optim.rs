use ouroboros::TypeInfo;

#[derive(Clone, Copy, Debug, TypeInfo)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct OptimizationFrame {
    pub total_energy: f64,
    pub max_gradient_component: f64,
}

pub type OptimizationResults = Vec<OptimizationFrame>;
