pub trait Symbol {
    fn symbol() -> String;
}

#[macro_export]
macro_rules! impl_symbol {
    ($($t:ident),*) => {
        $(
            #[derive(Clone, Debug, Eq, PartialEq)]
            pub struct $t(::std::vec::Vec<u8>);

            impl $t {
                pub fn new(v: ::std::vec::Vec<u8>) -> $t {
                    $t(v)
                }
            }

            impl $crate::symbol::Symbol for $t {
                fn symbol() -> ::std::string::String {
                    stringify!($t).to_string()
                }
            }

            impl ::std::ops::Deref for $t {
                type Target = ::std::vec::Vec<u8>;

                fn deref(&self) -> &<$t as ::std::ops::Deref>::Target {
                    &self.0
                }
            }

            impl ::std::ops::DerefMut for $t {
                fn deref_mut(&mut self) -> &mut <$t as ::std::ops::Deref>::Target {
                    &mut self.0
                }
            }

            impl ::ouroboros::TypeInfo for $t {
                fn tname() -> ::ouroboros::TypeName {
                    ::ouroboros::TypeName {
                        n: stringify!($t),
                        g: vec![],
                    }
                }
                fn t() -> ::ouroboros::Type {
                    ::ouroboros::Type::Symbolic(::ouroboros::Symbolic::new(stringify!($t)))
                }
            }

            #[cfg(feature = "serde")]
            impl ::serde::Serialize for $t {
                fn serialize<S: ::serde::Serializer>(&self, serializer: S) -> ::std::result::Result<S::Ok, S::Error> {
                    use ::base64::Engine;

                    serializer.serialize_str(&::base64::engine::general_purpose::STANDARD.encode(&self.0))
                }
            }


            #[cfg(feature = "serde")]
            impl<'de> ::serde::Deserialize<'de> for $t {
                fn deserialize<D>(deserializer: D) -> ::std::result::Result<$t, D::Error>
                where
                    D: ::serde::Deserializer<'de>,
                {
                    use ::base64::Engine;
                    use ::serde::de::Error;

                    let s = ::std::string::String::deserialize(deserializer)?;
                    let v = ::base64::engine::general_purpose::STANDARD
                        .decode(s)
                        .map_err(|e| D::Error::custom(format!("cannot decode base64: {e}")))?;

                    Ok($t(v))
                }
            }
        )*
    };
}

impl_symbol!(
    A3M, GRO, MDP, MOL2, PDB, PDBQT, PKL, SDF, SMI, TARGZ, TARZST, TRR, XML, XTC, HDF5
);
