#[cfg(feature = "rex")]
use rex::{Decode, Encode, Error, Expr, Span, ToType, Type as RexType, TypeCon};
use std::fmt::{self, Display, Formatter};
#[cfg(feature = "rex")]
use std::str::FromStr;
#[cfg(feature = "rex")]
use std::sync::Arc;

use ouroboros::{Alias, Type, TypeInfo, TypeName};
use semver::Version;

pub const CURRENT_SCHEMA_VERSION: SchemaVersion = SchemaVersion::new(0, 2, 0);

#[cfg(feature = "graphql")]
async_graphql::scalar!(SchemaVersion);

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(C)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct SchemaVersion(Version);

impl SchemaVersion {
    pub const fn new(major: u64, minor: u64, patch: u64) -> Self {
        SchemaVersion(Version::new(major, minor, patch))
    }
}

impl Display for SchemaVersion {
    fn fmt(&self, f: &mut Formatter) -> fmt::Result {
        self.0.fmt(f)
    }
}

impl Default for SchemaVersion {
    fn default() -> Self {
        SchemaVersion::new(0, 2, 0)
    }
}

impl TypeInfo for SchemaVersion {
    fn t() -> Type {
        Type::from(Alias::new("SchemaVersion", String::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("SchemaVersion")
    }
}

#[cfg(feature = "rex")]
impl ToType for SchemaVersion {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::String)
    }
}

#[cfg(feature = "rex")]
impl Encode for SchemaVersion {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.to_string().try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for SchemaVersion {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        match &**v {
            Expr::String(_, s) => {
                let version = Version::from_str(s).map_err(|e| Error::Custom {
                    error: format!("Invalid semver {}: {}", s, e),
                    trace: Default::default(),
                })?;
                Ok(SchemaVersion(version))
            }
            _ => Err(Error::ExpectedTypeGotValue {
                expected: Arc::new(Self::to_type()),
                got: v.clone(),
                trace: Default::default(),
            }),
        }
    }
}

#[cfg(test)]
mod test {
    use super::*;
    #[cfg(feature = "rex")]
    use rex::ast::assert_expr_eq;

    #[test]
    fn test_version() {
        assert_eq!(CURRENT_SCHEMA_VERSION, SchemaVersion::new(0, 2, 0));
        assert_eq!(SchemaVersion::default(), SchemaVersion::new(0, 2, 0));
    }

    #[test]
    fn test_display() {
        assert_eq!(format!("{}", SchemaVersion::new(0, 0, 0)), "0.0.0");
        assert_eq!(format!("{}", SchemaVersion::new(0, 1, 0)), "0.1.0");
    }

    #[test]
    fn test_eq() {
        assert_eq!(SchemaVersion::new(0, 0, 0), SchemaVersion::new(0, 0, 0));
        assert_eq!(SchemaVersion::new(0, 1, 0), SchemaVersion::new(0, 1, 0));
        assert_ne!(SchemaVersion::new(0, 0, 0), SchemaVersion::new(0, 1, 0));
    }

    #[test]
    fn test_ord() {
        assert!(SchemaVersion::new(0, 0, 0) < SchemaVersion::new(0, 1, 0));
        assert!(SchemaVersion::new(0, 1, 0) < SchemaVersion::new(0, 1, 1));
        assert!(SchemaVersion::new(0, 1, 0) < SchemaVersion::new(1, 0, 0));
    }

    #[test]
    fn test_rex() {
        let expected = SchemaVersion(semver::Version {
            major: 1,
            minor: 2,
            patch: 3,
            pre: semver::Prerelease::new("foo").unwrap(),
            build: semver::BuildMetadata::new("bar").unwrap(),
        });
        let encoded = expected.clone().try_encode(Span::default()).unwrap();
        let actual = SchemaVersion::try_decode(&encoded).unwrap();
        assert_expr_eq!(encoded, Expr::String(Span::default(), "1.2.3-foo+bar".to_string()); ignore span);
        assert_eq!(actual, expected);
    }
}
