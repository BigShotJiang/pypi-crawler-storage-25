#[cfg(feature = "rex")]
use std::sync::Arc;

use ouroboros::{Alias, Type, TypeInfo, TypeName};
#[cfg(feature = "rex")]
use rex::{Decode, Encode, Error, Expr, Rex, Span, ToType, Type as RexType, TypeCon};
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use crate::{
    AtomRef, BondOrder, Stereochemistry,
    atom::{FormalCharge, PartialCharge},
    bond::Bond,
    element::Element,
    fragment::{Fragment, FragmentMultiplicity, FragmentRef},
    residue::Residue,
    version::SchemaVersion,
};

#[cfg(feature = "graphql")]
async_graphql::scalar!(TopologyRef);

type BondAtoms = Vec<(AtomRef, AtomRef)>;
type AngleAtoms = Vec<(AtomRef, AtomRef, AtomRef)>;
type DihedralAtoms = Vec<(AtomRef, AtomRef, AtomRef, AtomRef)>;

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct TopologyRef(pub u32);

impl TypeInfo for TopologyRef {
    fn t() -> Type {
        Type::from(Alias::new("TopologyRef", u32::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("TopologyRef")
    }
}

#[cfg(feature = "rex")]
impl ToType for TopologyRef {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::Uint)
    }
}

#[cfg(feature = "rex")]
impl Encode for TopologyRef {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for TopologyRef {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(TopologyRef(u32::try_decode(v)?))
    }
}

// Topology contains all atom information.
#[derive(Clone, Debug, Default, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(
        input_name = "TopologyInput",
        name = "Topology",
        rename_fields = "snake_case"
    )
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Topology {
    pub schema_version: SchemaVersion,

    /// Element of each atom.
    pub symbols: Vec<Element>,

    /// XYZ coordinates of each atom. It must be 3 times the length of
    /// `symbols`.
    pub geometry: Vec<f32>,

    /// Optional list of the label of each atom. Often this is used for
    /// labelling specific atoms within residues (e.g. alpha carbons). If
    /// present, then it must be the same length as `symbols`.
    pub labels: Option<Vec<String>>,

    /// Optional list of the partial charge of each atom. If present, then it
    /// must be the same length as `symbols`.
    pub partial_charges: Option<Vec<PartialCharge>>,

    /// Optional list of the formal charge of each atom. If present, then it
    /// must be the same length as `symbols`.
    pub formal_charges: Option<Vec<FormalCharge>>,

    /// Optional list of bonds. Because bonds are perceived, this list should
    /// not be considered a reliable source of bond information.
    pub connectivity: Option<Vec<Bond>>,

    /// Optional list of stereochemistry specifiers for bonds. If present, then it
    /// must be the same length as `connectivity`.
    pub stereochemistry: Option<Vec<Stereochemistry>>,

    /// Contains the x, y, z components of initial atom velocities in Angstroms/ps
    /// V1 only
    pub velocities: Option<Vec<f32>>,

    /// Optional list of fragments. If present, then all atoms must be in
    /// exactly one fragment.
    pub fragments: Option<Vec<Fragment>>,

    /// Optional list of the formal charge of each fragment. If present, then it
    /// must be the same length as `fragments`.
    pub fragment_formal_charges: Option<Vec<FormalCharge>>,

    /// Optional list of the formal charge of each fragment. If present, then it
    /// must be the same length as `fragments`.
    pub fragment_partial_charges: Option<Vec<PartialCharge>>,

    /// Optional list of the multiplicity of each fragment. This is only
    /// relevant for open-shell systems. If present, then it must be the same
    /// length as `fragments`.
    pub fragment_multiplicities: Option<Vec<FragmentMultiplicity>>,
}

#[derive(Copy, Clone, Debug, PartialEq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum TopologyError {
    #[error("geometry length does not symbol length * 3: {0} != {1} * 3")]
    InvalidGeometryLength(usize, usize),
    #[error("labels length does not match symbols length: {0} != {1}")]
    InvalidLabelsLength(usize, usize),
    #[error("partial charges length does not match symbols length: {0} != {1}")]
    InvalidPartialChargesLength(usize, usize),
    #[error("formal charges length does not match symbols length: {0} != {1}")]
    InvalidFormalChargesLength(usize, usize),
    #[error("invalid connectivity between: {0:?} and {1:?}")]
    InvalidConnectivity(AtomRef, AtomRef),
    #[error("stereochemistry exists but connectivity does not")]
    InvalidStereochemistryExistence,
    #[error("stereochemistry length does not match connectivity length: {0} != {1}")]
    InvalidStereochemistryLength(usize, usize),
    #[error("velocities length does not match symbols length: {0} != {1}")]
    InvalidVelocitiesLength(usize, usize),
    #[error("invalid fragments")]
    InvalidFragments,
    #[error("invalid fragment reference: {}", 0.0)]
    InvalidFragmentRef(FragmentRef),
    #[error("fragment formal charges length does not match fragment length: {0} != {1}")]
    InvalidFragmentFormalChargesLength(usize, usize),
    #[error("fragment partial charges length does not match fragment length: {0} != {1}")]
    InvalidFragmentPartialChargesLength(usize, usize),
    #[error("fragment multiplicities length does not match fragment length: {0} != {1}")]
    InvalidFragmentMultiplicitiesLength(usize, usize),
}

impl Topology {
    /// Ensure that the topology is valid, checking that SOA is followed and no invalid refs exist.
    pub fn check(&self) -> Result<(), TopologyError> {
        if self.geometry.len() / 3 != self.symbols.len() {
            return Err(TopologyError::InvalidGeometryLength(
                self.geometry.len(),
                self.symbols.len(),
            ));
        }

        if let Some(labels) = &self.labels
            && labels.len() != self.symbols.len()
        {
            return Err(TopologyError::InvalidLabelsLength(
                labels.len(),
                self.symbols.len(),
            ));
        }

        if let Some(partial_charges) = &self.partial_charges
            && partial_charges.len() != self.symbols.len()
        {
            return Err(TopologyError::InvalidPartialChargesLength(
                partial_charges.len(),
                self.symbols.len(),
            ));
        }

        if let Some(formal_charges) = &self.formal_charges
            && formal_charges.len() != self.symbols.len()
        {
            return Err(TopologyError::InvalidFormalChargesLength(
                formal_charges.len(),
                self.symbols.len(),
            ));
        }

        if let Some(connectivity) = &self.connectivity {
            for bond in connectivity {
                if bond.0.0 >= self.symbols.len() as u32
                    || bond.1.0 >= self.symbols.len() as u32
                    || bond.0.0 == bond.1.0
                {
                    return Err(TopologyError::InvalidConnectivity(bond.0, bond.1));
                }
            }
        }

        if let Some(stereochemistry) = &self.stereochemistry {
            if let Some(connectivity) = &self.connectivity {
                if stereochemistry.len() != connectivity.len() {
                    return Err(TopologyError::InvalidStereochemistryLength(
                        stereochemistry.len(),
                        connectivity.len(),
                    ));
                }
            } else {
                return Err(TopologyError::InvalidStereochemistryExistence);
            }
        }

        if let Some(velocities) = &self.velocities
            && velocities.len() != self.symbols.len() * 3
        {
            return Err(TopologyError::InvalidVelocitiesLength(
                velocities.len(),
                self.symbols.len(),
            ));
        }

        if let Some(fragments) = &self.fragments {
            let mut atom_set = std::collections::HashSet::new();
            for fragment in fragments {
                for atom in fragment.0.iter() {
                    if atom_set.contains(atom) {
                        return Err(TopologyError::InvalidFragments);
                    }
                    atom_set.insert(atom);
                }
            }

            if atom_set.len() != self.symbols.len() {
                return Err(TopologyError::InvalidFragments);
            }
        }

        if let Some(fragment_formal_charges) = &self.fragment_formal_charges
            && fragment_formal_charges.len() != self.fragments.as_ref().unwrap().len()
        {
            return Err(TopologyError::InvalidFragmentFormalChargesLength(
                fragment_formal_charges.len(),
                self.fragments.as_ref().unwrap().len(),
            ));
        }

        if let Some(fragment_partial_charges) = &self.fragment_partial_charges
            && fragment_partial_charges.len() != self.fragments.as_ref().unwrap().len()
        {
            return Err(TopologyError::InvalidFragmentPartialChargesLength(
                fragment_partial_charges.len(),
                self.fragments.as_ref().unwrap().len(),
            ));
        }

        if let Some(fragment_multiplicities) = &self.fragment_multiplicities
            && fragment_multiplicities.len() != self.fragments.as_ref().unwrap().len()
        {
            return Err(TopologyError::InvalidFragmentMultiplicitiesLength(
                fragment_multiplicities.len(),
                self.fragments.as_ref().unwrap().len(),
            ));
        }

        Ok(())
    }

    pub fn extend(&mut self, rhs: Self) {
        let symbols = &mut self.symbols;
        let geometry = &mut self.geometry;
        let labels = &mut self.labels;
        let partial_charges = &mut self.partial_charges;
        let formal_charges = &mut self.formal_charges;
        let connectivity = &mut self.connectivity;
        let velocities = &mut self.velocities;
        let fragments = &mut self.fragments;
        let fragment_formal_charges = &mut self.fragment_formal_charges;
        let fragment_partial_charges = &mut self.fragment_partial_charges;
        let fragment_multiplicities = &mut self.fragment_multiplicities;

        let offset = symbols.len();
        let rhs_len = rhs.symbols.len();

        geometry.extend(rhs.geometry);
        symbols.extend(rhs.symbols);

        match (labels.as_mut(), rhs.labels) {
            (Some(lhs), Some(rhs)) => {
                lhs.extend(rhs);
            }
            // labels must be same length as symbols
            (Some(lhs), None) => {
                lhs.extend(std::iter::repeat_n(String::new(), rhs_len));
            }
            // if original does not have labels, we don't extend
            _ => (),
        }

        // we can't just extend the connectivity list because the indices in the rhs need to be updated
        match (connectivity.as_mut(), rhs.connectivity) {
            (Some(lhs), Some(rhs)) => {
                lhs.extend(
                    rhs.into_iter()
                        .map(|mut bond| {
                            bond.0 = AtomRef(u32::from(bond.0) + offset as u32);
                            bond.1 = AtomRef(u32::from(bond.1) + offset as u32);
                            bond
                        })
                        .collect::<Vec<Bond>>(),
                );
            }
            (Some(lhs), None) => {
                lhs.extend(std::iter::repeat_n(
                    Bond(AtomRef(0), AtomRef(0), BondOrder::Single),
                    rhs_len,
                ));
            }
            _ => (),
        }

        match (velocities.as_mut(), rhs.velocities) {
            (Some(lhs), Some(rhs)) => {
                lhs.extend(rhs);
            }
            (Some(lhs), None) => {
                lhs.extend(std::iter::repeat_n(0.0, rhs_len * 3));
            }
            _ => (),
        }

        // we can't just extend the fragments list because the indices in the rhs need to be updated
        match (fragments.as_mut(), rhs.fragments) {
            (Some(lhs), Some(rhs)) => {
                lhs.extend(
                    rhs.into_iter()
                        .map(|fragment| {
                            Fragment(
                                fragment
                                    .0
                                    .into_iter()
                                    .map(|atom| AtomRef(u32::from(atom) + offset as u32))
                                    .collect::<Vec<_>>(),
                            )
                        })
                        .collect::<Vec<Fragment>>(),
                );
            }
            (Some(lhs), None) => {
                // put all atoms from rhs into a single fragment
                lhs.push(Fragment(
                    (0..rhs_len)
                        .map(|i| AtomRef(i as u32 + offset as u32))
                        .collect::<Vec<_>>(),
                ));
            }
            _ => (),
        }

        match (
            fragment_formal_charges.as_mut(),
            rhs.fragment_formal_charges,
        ) {
            (Some(lhs), Some(rhs)) => {
                lhs.extend(rhs);
            }
            (Some(lhs), None) => {
                if let Some(rhs) = &rhs.formal_charges {
                    // sum the formal charges of all atoms in the fragment
                    let charge: i32 = rhs.iter().map(|x| x.0).sum();
                    lhs.push(charge.into());
                } else {
                    lhs.push(FormalCharge(0));
                }
            }
            _ => (),
        }

        match (
            fragment_partial_charges.as_mut(),
            rhs.fragment_partial_charges,
        ) {
            (Some(lhs), Some(rhs)) => {
                lhs.extend(rhs);
            }
            (Some(lhs), None) => {
                if let Some(rhs) = &rhs.partial_charges {
                    // sum the partial charges of all atoms in the fragment
                    let charge: f32 = rhs.iter().map(|x| x.0).sum();
                    lhs.push(charge.into());
                } else {
                    lhs.push(PartialCharge(0.0));
                }
            }
            _ => (),
        }

        // extend these here as we use refernces to charges in the fragments
        match (partial_charges.as_mut(), rhs.partial_charges) {
            (Some(lhs), Some(rhs)) => {
                lhs.extend(rhs);
            }
            // partial charges must be same length as symbols
            (Some(lhs), None) => {
                lhs.extend(std::iter::repeat_n(PartialCharge(0.0), rhs_len));
            }
            _ => (),
        }

        match (formal_charges.as_mut(), rhs.formal_charges) {
            (Some(lhs), Some(rhs)) => {
                lhs.extend(rhs);
            }
            // formal charges must be same length as symbols
            (Some(lhs), None) => {
                lhs.extend(std::iter::repeat_n(FormalCharge(0), rhs_len));
            }
            _ => (),
        }

        match (
            fragment_multiplicities.as_mut(),
            rhs.fragment_multiplicities,
        ) {
            (Some(lhs), Some(rhs)) => {
                lhs.extend(rhs);
            }
            (Some(lhs), None) => {
                lhs.push(FragmentMultiplicity(0));
            }
            _ => (),
        }
    }

    pub fn get_bonds_angles_dihedrals(&self) -> (BondAtoms, AngleAtoms, DihedralAtoms) {
        if let Some(ref connectivity) = self.connectivity {
            let num_atoms = self.symbols.len();

            let mut associativity = Vec::with_capacity(num_atoms);
            for _ in 0..num_atoms {
                associativity.push(Vec::new());
            }

            for bond in connectivity {
                associativity[bond.0.0 as usize].push(bond.1);
                associativity[bond.1.0 as usize].push(bond.0);
            }

            let mut bonds = Vec::with_capacity(connectivity.len());
            let mut angles = Vec::new();
            let mut dihedrals = Vec::new();

            for bond in connectivity {
                bonds.push((bond.0, bond.1));
            }

            for (middle_index, connections) in associativity.iter().enumerate().take(num_atoms) {
                for left_index in connections.iter() {
                    for right_index in connections.iter() {
                        if left_index < right_index {
                            angles.push((*left_index, AtomRef(middle_index as u32), *right_index));
                        }
                    }
                }
            }

            for bond in bonds.iter() {
                for left_index in associativity[bond.0.0 as usize].iter() {
                    for right_index in associativity[bond.1.0 as usize].iter() {
                        if left_index != right_index
                            && *left_index != bond.1
                            && *right_index != bond.0
                        {
                            dihedrals.push((*left_index, bond.0, bond.1, *right_index));
                        }
                    }
                }
            }

            (bonds, angles, dihedrals)
        } else {
            (Vec::new(), Vec::new(), Vec::new())
        }
    }

    /// Create a vector of atom indices within the threshold of the reference point.
    /// The u32s in the atom_sets parameter should be valid indices into the atoms in the topology.
    pub fn get_atoms_near_point<'x>(
        &self,
        reference_point: &[f32; 3],
        threshold: f32,
        atom_sets: impl Iterator<Item = &'x Vec<u32>> + 'x,
    ) -> Vec<u32> {
        atom_sets
            .flat_map(|atom_set| {
                atom_set
                    .iter()
                    .map(|a| {
                        let distance_to_atom = self.distance_to_atom(reference_point, *a);
                        if distance_to_atom <= threshold {
                            let geometry = [
                                self.geometry[*a as usize * 3],
                                self.geometry[*a as usize * 3 + 1],
                                self.geometry[*a as usize * 3 + 2],
                            ];
                            eprintln!("{reference_point:?} :: {geometry:?} :: {distance_to_atom}");
                        }
                        *a
                    })
                    .filter(|&a| self.distance_to_atom(reference_point, a) <= threshold)
                    .collect::<Vec<_>>()
            })
            .collect()
    }

    /// Compute the distance from the reference point to an atom identified by its index.
    pub fn distance_to_atom(&self, reference_point: &[f32; 3], atom_idx: u32) -> f32 {
        ((self.geometry[atom_idx as usize * 3] - reference_point[0]).powf(2.0)
            + (self.geometry[atom_idx as usize * 3 + 1] - reference_point[1]).powf(2.0)
            + (self.geometry[atom_idx as usize * 3 + 2] - reference_point[2]).powf(2.0))
        .sqrt()
    }

    /// Compute the distance between two atoms identified by their indices.
    pub fn distance_between_atoms(
        &self,
        AtomRef(atom1_idx): AtomRef,
        AtomRef(atom2_idx): AtomRef,
    ) -> f32 {
        ((self.geometry[atom1_idx as usize * 3] - self.geometry[atom2_idx as usize * 3]).powf(2.0)
            + (self.geometry[atom1_idx as usize * 3 + 1]
                - self.geometry[atom2_idx as usize * 3 + 1])
                .powf(2.0)
            + (self.geometry[atom1_idx as usize * 3 + 2]
                - self.geometry[atom2_idx as usize * 3 + 2])
                .powf(2.0))
        .sqrt()
    }

    /// Find fragment indices with at least one atom within the threshold of the reference fragment.
    pub fn get_fragments_near_fragment(
        &self,
        FragmentRef(fragment_idx): FragmentRef,
        threshold: f32,
    ) -> Result<Vec<FragmentRef>, TopologyError> {
        let Some(fragments) = &self.fragments else {
            return Ok(Vec::new());
        };

        let reference_fragment = fragments
            .get(fragment_idx as usize)
            .ok_or(TopologyError::InvalidFragmentRef(FragmentRef(fragment_idx)))?;

        let mut near_atoms = std::collections::HashSet::new();
        let num_atoms = self.symbols.len() as u32;

        for AtomRef(atom_idx) in reference_fragment.iter() {
            let reference_point = [
                self.geometry[*atom_idx as usize * 3],
                self.geometry[*atom_idx as usize * 3 + 1],
                self.geometry[*atom_idx as usize * 3 + 2],
            ];

            for candidate_idx in 0..num_atoms {
                if self.distance_to_atom(&reference_point, candidate_idx) <= threshold {
                    near_atoms.insert(candidate_idx);
                }
            }
        }

        Ok(fragments
            .iter()
            .enumerate()
            .filter(|(idx, fragment)| {
                *idx != fragment_idx as usize
                    && fragment
                        .iter()
                        .any(|AtomRef(atom_idx)| near_atoms.contains(atom_idx))
            })
            .map(|(idx, _)| FragmentRef(idx as u32))
            .collect())
    }

    /// Create a new topology with atoms consisting of those in the provided residues. Fragment related fields will be
    /// removed unless the a subset of the fragments exactly partition the set of atoms in the provided residues.
    pub fn new_topology_from_residue_subset(&self, residue_subset: &[Residue]) -> Self {
        let mut new_topology = Topology::default();

        let flat_residues = residue_subset
            .iter()
            .flat_map(|r| r.0.clone())
            .collect::<Vec<_>>();

        new_topology.schema_version = self.schema_version.clone();

        let new_num_atoms: usize = residue_subset.iter().map(|residue| residue.len()).sum();

        topology_atom_field_from_residue_subset(
            &mut new_topology.symbols,
            &self.symbols,
            residue_subset,
        );

        new_topology.geometry.reserve(3 * new_num_atoms);
        for residue in residue_subset.iter() {
            for atom_ref in residue.iter() {
                let atom_index = atom_ref.0 as usize;
                new_topology
                    .geometry
                    .extend_from_slice(&self.geometry[3 * atom_index..3 * atom_index + 3]);
            }
        }

        topology_optional_atom_field_from_residue_subset(
            &mut new_topology.labels,
            &self.labels,
            residue_subset,
        );
        topology_optional_atom_field_from_residue_subset(
            &mut new_topology.partial_charges,
            &self.partial_charges,
            residue_subset,
        );
        topology_optional_atom_field_from_residue_subset(
            &mut new_topology.formal_charges,
            &self.formal_charges,
            residue_subset,
        );

        if let Some(ref connectivity) = self.connectivity {
            let mut new_connectivity = Vec::new();
            let mut new_stereochemistry = Vec::new();

            for (i, bond) in connectivity.iter().enumerate() {
                let first_index = flat_residues
                    .iter()
                    .position(|atom_ref| *atom_ref == bond.0);
                let second_index = flat_residues
                    .iter()
                    .position(|atom_ref| *atom_ref == bond.1);

                if let (Some(first_index), Some(second_index)) = (first_index, second_index) {
                    new_connectivity.push(Bond(
                        AtomRef(first_index as u32),
                        AtomRef(second_index as u32),
                        bond.2,
                    ));
                    if let Some(ref stereochemistry) = self.stereochemistry {
                        new_stereochemistry.push(stereochemistry[i]);
                    }
                }
            }

            new_topology.connectivity = Some(new_connectivity);
            if self.stereochemistry.is_some() {
                new_topology.stereochemistry = Some(new_stereochemistry);
            }
        }

        if let Some(ref velocities) = self.velocities {
            let mut new_velocities = Vec::with_capacity(3 * new_num_atoms);
            for residue in residue_subset.iter() {
                for atom_ref in residue.iter() {
                    let atom_index = atom_ref.0 as usize;
                    new_velocities
                        .extend_from_slice(&velocities[3 * atom_index..3 * atom_index + 3]);
                }
            }

            new_topology.velocities = Some(new_velocities);
        }

        if let Some(ref fragments) = self.fragments {
            let mut new_fragments = Vec::new();
            let mut contained_fragments = Vec::new();

            let mut no_straddling_fragments = true;
            for (fragment_index, fragment) in fragments.iter().enumerate() {
                if fragment
                    .iter()
                    .any(|atom_ref| flat_residues.contains(atom_ref))
                {
                    let fragment_is_straddling = !fragment
                        .iter()
                        .all(|atom_ref| flat_residues.contains(atom_ref));

                    if fragment_is_straddling {
                        no_straddling_fragments = false;
                        break;
                    }

                    contained_fragments.push(fragment_index);

                    let mut new_fragment = Vec::with_capacity(fragment.len());
                    for atom_ref in fragment.iter() {
                        // NOTE(ross): In theory we are duplicating work here; we should know this index from checking whether
                        // it was in the residue subset previously. I doubt this will cause performance issues, but if it does
                        // then rewrite to remove the duplicated work.
                        let index = flat_residues
                            .iter()
                            .position(|other_atom_ref| other_atom_ref == atom_ref)
                            .unwrap();
                        new_fragment.push(AtomRef(index as u32));
                    }

                    new_fragments.push(Fragment(new_fragment));
                }
            }

            if no_straddling_fragments {
                new_topology.fragments = Some(new_fragments);

                topology_optional_fragment_field_from_contained_residues(
                    &mut new_topology.fragment_formal_charges,
                    &self.fragment_formal_charges,
                    &contained_fragments,
                );
                topology_optional_fragment_field_from_contained_residues(
                    &mut new_topology.fragment_partial_charges,
                    &self.fragment_partial_charges,
                    &contained_fragments,
                );
                topology_optional_fragment_field_from_contained_residues(
                    &mut new_topology.fragment_multiplicities,
                    &self.fragment_multiplicities,
                    &contained_fragments,
                );
            } else {
                new_topology.fragments = None;
            }
        }

        new_topology
    }
}

fn topology_atom_field_from_residue_subset<T: Clone>(
    field_subset: &mut Vec<T>,
    field: &[T],
    residue_subset: &[Residue],
) {
    let new_num_atoms = residue_subset.iter().map(|residue| residue.len()).sum();

    field_subset.clear();
    field_subset.reserve(new_num_atoms);

    for residue in residue_subset.iter() {
        for atom_ref in residue.iter() {
            let atom_index = atom_ref.0 as usize;
            field_subset.push(field[atom_index].clone());
        }
    }
}

fn topology_optional_atom_field_from_residue_subset<T: Clone>(
    field_subset: &mut Option<Vec<T>>,
    field: &Option<Vec<T>>,
    residue_subset: &[Residue],
) {
    *field_subset = None;

    if let Some(field) = field {
        let mut new_field = Vec::new();
        topology_atom_field_from_residue_subset(&mut new_field, field, residue_subset);

        *field_subset = Some(new_field);
    }
}

fn topology_optional_fragment_field_from_contained_residues<T: Clone>(
    dst_fragment_field: &mut Option<Vec<T>>,
    fragment_field: &Option<Vec<T>>,
    contained_fragments: &[usize],
) {
    *dst_fragment_field = None;

    if let Some(fragment_field) = fragment_field {
        let mut new_fragment_field = Vec::with_capacity(contained_fragments.len());
        for fragment_index in contained_fragments {
            new_fragment_field.push(fragment_field[*fragment_index].clone());
        }

        *dst_fragment_field = Some(new_fragment_field);
    }
}

// tests
#[cfg(test)]
mod tests {
    use super::*;

    // extend topology
    #[test]
    fn test_topology_add() {
        let mut topology1 = Topology {
            geometry: vec![0.0, 0.0, 0.0, 1.0, 1.0, 1.0],
            symbols: vec![Element::H, Element::H],
            fragments: Some(vec![vec![0].into(), vec![1].into()]),
            connectivity: Some(vec![Bond(0.into(), 1.into(), BondOrder::Double)]),

            ..Default::default()
        };
        let topology2 = topology1.clone();

        topology1.extend(topology2);

        assert_eq!(
            topology1.symbols,
            vec![Element::H, Element::H, Element::H, Element::H]
        );

        assert_eq!(
            topology1.geometry,
            vec![0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0]
        );

        assert_eq!(
            topology1.fragments,
            Some(vec![
                vec![0].into(),
                vec![1].into(),
                vec![2].into(),
                vec![3].into()
            ])
        );

        assert_eq!(
            topology1.connectivity,
            Some(vec![
                Bond(0.into(), 1.into(), BondOrder::Double),
                Bond(2.into(), 3.into(), BondOrder::Double)
            ])
        );

        topology1.check().unwrap();
    }

    #[test]
    fn test_unbalanced_add() {
        let mut topology1 = Topology {
            geometry: vec![0.0, 0.0, 0.0, 1.0, 1.0, 1.0],
            symbols: vec![Element::H, Element::H],
            labels: Some(vec!["H".into(), "H".into()]),
            fragments: Some(vec![vec![0].into(), vec![1].into()]),
            connectivity: Some(vec![Bond(0.into(), 1.into(), BondOrder::Double)]),

            ..Default::default()
        };

        let topology2 = Topology {
            geometry: vec![0.0, 0.0, 0.0, 1.0, 1.0, 1.0],
            symbols: vec![Element::H, Element::H],
            connectivity: Some(vec![Bond(0.into(), 1.into(), BondOrder::Double)]),

            ..Default::default()
        };

        topology1.extend(topology2);

        assert_eq!(
            topology1.symbols,
            vec![Element::H, Element::H, Element::H, Element::H]
        );

        assert_eq!(
            topology1.geometry,
            vec![0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0]
        );

        assert_eq!(
            topology1.labels,
            Some(vec!["H".into(), "H".into(), "".into(), "".into()])
        );

        assert_eq!(
            topology1.fragments,
            Some(vec![vec![0].into(), vec![1].into(), vec![2, 3].into()])
        );

        assert_eq!(
            topology1.connectivity,
            Some(vec![
                Bond(0.into(), 1.into(), BondOrder::Double),
                Bond(2.into(), 3.into(), BondOrder::Double)
            ])
        );

        topology1.check().unwrap();
    }

    fn vecs_have_same_elements<T: PartialEq>(a: &[T], b: &[T]) -> bool {
        a.len() == b.len() && a.iter().all(|x| b.contains(x))
    }

    #[test]
    fn test_get_bonds_angles_dihedrals() {
        // Molecule with the connectivity
        //     5
        //     |
        // 0-1-2-3-4
        let topology = Topology {
            geometry: vec![
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.0, 0.0,
            ],
            symbols: vec![
                Element::H,
                Element::H,
                Element::H,
                Element::H,
                Element::H,
                Element::H,
            ],
            connectivity: Some(vec![
                Bond(0.into(), 1.into(), BondOrder::Single),
                Bond(1.into(), 2.into(), BondOrder::Single),
                Bond(2.into(), 3.into(), BondOrder::Single),
                Bond(3.into(), 4.into(), BondOrder::Single),
                Bond(2.into(), 5.into(), BondOrder::Single),
            ]),
            ..Default::default()
        };

        let expected_bonds = vec![
            (AtomRef(0), AtomRef(1)),
            (AtomRef(1), AtomRef(2)),
            (AtomRef(2), AtomRef(3)),
            (AtomRef(3), AtomRef(4)),
            (AtomRef(2), AtomRef(5)),
        ];
        let expected_angles = vec![
            (AtomRef(0), AtomRef(1), AtomRef(2)),
            (AtomRef(1), AtomRef(2), AtomRef(3)),
            (AtomRef(1), AtomRef(2), AtomRef(5)),
            (AtomRef(3), AtomRef(2), AtomRef(5)),
            (AtomRef(2), AtomRef(3), AtomRef(4)),
        ];
        let expected_dihedrals = vec![
            (AtomRef(0), AtomRef(1), AtomRef(2), AtomRef(5)),
            (AtomRef(0), AtomRef(1), AtomRef(2), AtomRef(3)),
            (AtomRef(1), AtomRef(2), AtomRef(3), AtomRef(4)),
            (AtomRef(5), AtomRef(2), AtomRef(3), AtomRef(4)),
        ];

        let (bonds, angles, dihedrals) = topology.get_bonds_angles_dihedrals();

        assert!(vecs_have_same_elements(&bonds, &expected_bonds));
        assert!(vecs_have_same_elements(&angles, &expected_angles));
        assert!(vecs_have_same_elements(&dihedrals, &expected_dihedrals));
    }

    #[test]
    fn test_get_fragments_near_fragment() {
        let mut topology = Topology {
            schema_version: SchemaVersion::default(),
            symbols: vec![
                Element::H,
                Element::C,
                Element::C,
                Element::N,
                Element::N,
                Element::N,
                Element::O,
                Element::O,
                Element::O,
                Element::O,
            ],
            fragments: Some(vec![
                Fragment(vec![0.into(), 1.into()]),
                Fragment(vec![2.into(), 3.into(), 4.into(), 5.into()]),
                Fragment(vec![6.into(), 7.into(), 8.into(), 9.into()]),
            ]),
            ..Default::default()
        };
        set_debug_geometry(&mut topology);

        assert_eq!(
            topology
                .get_fragments_near_fragment(FragmentRef(0), 2.0)
                .unwrap(),
            vec![FragmentRef(1)]
        );
        assert_eq!(
            topology
                .get_fragments_near_fragment(FragmentRef(1), 2.0)
                .unwrap(),
            vec![FragmentRef(0), FragmentRef(2)]
        );
        assert_eq!(
            topology
                .get_fragments_near_fragment(FragmentRef(2), 1.0)
                .unwrap(),
            Vec::<FragmentRef>::new()
        );
        assert_eq!(
            topology
                .get_fragments_near_fragment(FragmentRef(3), 2.0)
                .unwrap_err(),
            TopologyError::InvalidFragmentRef(FragmentRef(3))
        );
    }

    fn set_debug_geometry(topology: &mut Topology) {
        let num_atoms = topology.symbols.len();

        topology.geometry.clear();
        topology.geometry.resize(3 * num_atoms, 0.0);
        for i in 0..num_atoms {
            for j in 0..3 {
                topology.geometry[3 * i + j] = i as f32;
            }
        }
    }

    #[test]
    fn test_extract_residues() {
        let mut topology = Topology {
            schema_version: SchemaVersion::default(),
            symbols: vec![
                Element::H,
                Element::C,
                Element::C,
                Element::N,
                Element::N,
                Element::N,
                Element::O,
                Element::O,
                Element::O,
                Element::O,
            ],
            geometry: Vec::new(),
            labels: Some(vec![
                "H0".to_string(),
                "C0".to_string(),
                "C1".to_string(),
                "N0".to_string(),
                "N1".to_string(),
                "N2".to_string(),
                "O0".to_string(),
                "O1".to_string(),
                "O2".to_string(),
                "O3".to_string(),
            ]),
            partial_charges: Some(vec![
                0.0.into(),
                1.0.into(),
                1.0.into(),
                2.0.into(),
                2.0.into(),
                2.0.into(),
                3.0.into(),
                3.0.into(),
                3.0.into(),
                3.0.into(),
            ]),
            formal_charges: Some(vec![
                0.into(),
                1.into(),
                1.into(),
                2.into(),
                2.into(),
                2.into(),
                3.into(),
                3.into(),
                3.into(),
                3.into(),
            ]),
            connectivity: Some(vec![
                Bond(0.into(), 1.into(), BondOrder::Single),
                Bond(1.into(), 2.into(), BondOrder::Single),
                Bond(2.into(), 3.into(), BondOrder::Single),
                Bond(3.into(), 4.into(), BondOrder::Single),
                Bond(4.into(), 5.into(), BondOrder::Single),
                Bond(5.into(), 6.into(), BondOrder::Single),
                Bond(6.into(), 7.into(), BondOrder::Single),
                Bond(7.into(), 8.into(), BondOrder::Single),
                Bond(8.into(), 9.into(), BondOrder::Single),
            ]),
            stereochemistry: Some(vec![
                Stereochemistry::NONE,
                Stereochemistry::Up,
                Stereochemistry::Up,
                Stereochemistry::Down,
                Stereochemistry::Down,
                Stereochemistry::Down,
                Stereochemistry::Either,
                Stereochemistry::Either,
                Stereochemistry::Either,
            ]),
            velocities: None,
            fragments: Some(vec![
                Fragment(vec![0.into(), 1.into()]),
                Fragment(vec![2.into(), 3.into(), 4.into(), 5.into()]),
                Fragment(vec![6.into(), 7.into(), 8.into(), 9.into()]),
            ]),
            fragment_formal_charges: Some(vec![0.into(), 1.into(), 2.into()]),
            fragment_partial_charges: Some(vec![0.0.into(), 1.0.into(), 2.0.into()]),
            fragment_multiplicities: Some(vec![0.into(), 1.into(), 2.into()]),
        };
        set_debug_geometry(&mut topology);
        topology.velocities = Some(topology.geometry.clone());

        // Fragments line up with residues.
        let residue_subset = vec![
            Residue(vec![0.into(), 1.into(), 2.into()]),
            Residue(vec![3.into(), 4.into(), 5.into()]),
        ];

        let expected_topology = Topology {
            schema_version: SchemaVersion::default(),
            symbols: topology.symbols[0..6].to_vec(),
            #[allow(clippy::erasing_op)]
            geometry: topology.geometry[3 * 0..3 * 6].to_vec(),
            labels: Some(topology.labels.clone().unwrap()[0..6].to_vec()),
            partial_charges: Some(topology.partial_charges.clone().unwrap()[0..6].to_vec()),
            formal_charges: Some(topology.formal_charges.clone().unwrap()[0..6].to_vec()),
            connectivity: Some(topology.connectivity.clone().unwrap()[0..5].to_vec()),
            stereochemistry: Some(topology.stereochemistry.clone().unwrap()[0..5].to_vec()),
            #[allow(clippy::erasing_op)]
            velocities: Some(topology.velocities.clone().unwrap()[3 * 0..3 * 6].to_vec()),
            fragments: Some(topology.fragments.clone().unwrap()[0..2].to_vec()),
            fragment_formal_charges: Some(
                topology.fragment_formal_charges.clone().unwrap()[0..2].to_vec(),
            ),
            fragment_partial_charges: Some(
                topology.fragment_partial_charges.clone().unwrap()[0..2].to_vec(),
            ),
            fragment_multiplicities: Some(
                topology.fragment_multiplicities.clone().unwrap()[0..2].to_vec(),
            ),
        };

        let new_topology = topology.new_topology_from_residue_subset(&residue_subset);

        assert!(new_topology.check().is_ok());

        assert_eq!(
            new_topology.schema_version,
            expected_topology.schema_version
        );
        assert_eq!(new_topology.symbols, expected_topology.symbols);
        assert_eq!(new_topology.geometry, expected_topology.geometry);
        assert_eq!(new_topology.labels, expected_topology.labels);
        assert_eq!(
            new_topology.partial_charges,
            expected_topology.partial_charges
        );
        assert_eq!(
            new_topology.formal_charges,
            expected_topology.formal_charges
        );
        assert_eq!(new_topology.connectivity, expected_topology.connectivity);
        assert_eq!(
            new_topology.stereochemistry,
            expected_topology.stereochemistry
        );
        assert_eq!(new_topology.velocities, expected_topology.velocities);
        assert_eq!(new_topology.fragments, expected_topology.fragments);
        assert_eq!(
            new_topology.fragment_formal_charges,
            expected_topology.fragment_formal_charges
        );
        assert_eq!(
            new_topology.fragment_partial_charges,
            expected_topology.fragment_partial_charges
        );
        assert_eq!(
            new_topology.fragment_multiplicities,
            expected_topology.fragment_multiplicities
        );

        // Fragments don't line up with residues
        let residue_subset = vec![
            Residue(vec![1.into(), 2.into(), 3.into()]),
            Residue(vec![4.into(), 5.into(), 6.into()]),
        ];

        let expected_topology = Topology {
            schema_version: SchemaVersion::default(),
            symbols: topology.symbols[1..7].to_vec(),
            #[allow(clippy::identity_op)]
            geometry: topology.geometry[3 * 1..3 * 7].to_vec(),
            labels: Some(topology.labels.clone().unwrap()[1..7].to_vec()),
            partial_charges: Some(topology.partial_charges.clone().unwrap()[1..7].to_vec()),
            formal_charges: Some(topology.formal_charges.clone().unwrap()[1..7].to_vec()),
            connectivity: Some(topology.connectivity.clone().unwrap()[0..5].to_vec()), // Atom indices will have shifted
            stereochemistry: Some(topology.stereochemistry.clone().unwrap()[1..6].to_vec()),
            #[allow(clippy::identity_op)]
            velocities: Some(topology.velocities.clone().unwrap()[3 * 1..3 * 7].to_vec()),
            fragments: None,
            fragment_formal_charges: None,
            fragment_partial_charges: None,
            fragment_multiplicities: None,
        };

        let new_topology = topology.new_topology_from_residue_subset(&residue_subset);

        assert!(new_topology.check().is_ok());

        assert_eq!(
            new_topology.schema_version,
            expected_topology.schema_version
        );
        assert_eq!(new_topology.symbols, expected_topology.symbols);
        assert_eq!(new_topology.geometry, expected_topology.geometry);
        assert_eq!(new_topology.labels, expected_topology.labels);
        assert_eq!(
            new_topology.partial_charges,
            expected_topology.partial_charges
        );
        assert_eq!(
            new_topology.formal_charges,
            expected_topology.formal_charges
        );
        assert_eq!(new_topology.connectivity, expected_topology.connectivity);
        assert_eq!(
            new_topology.stereochemistry,
            expected_topology.stereochemistry
        );
        assert_eq!(new_topology.velocities, expected_topology.velocities);
        assert_eq!(new_topology.fragments, expected_topology.fragments);
        assert_eq!(
            new_topology.fragment_formal_charges,
            expected_topology.fragment_formal_charges
        );
        assert_eq!(
            new_topology.fragment_partial_charges,
            expected_topology.fragment_partial_charges
        );
        assert_eq!(
            new_topology.fragment_multiplicities,
            expected_topology.fragment_multiplicities
        );
    }
}
