use ouroboros::TypeInfo;
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use crate::{AtomRef, Topology};

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd, TypeInfo)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct FrameRef(pub u32);

#[cfg(feature = "graphql")]
async_graphql::scalar!(FrameRef);

#[derive(Debug, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "ChangesetInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Changeset {
    // Atoms to be subtracted from the `Topology` of the previous frame. Done
    // before the addition.
    sub: Option<Vec<AtomRef>>,
    // `Topology` to be merged into the `Topology` of the previous frame. Done
    // after the subtraction.
    add: Option<Topology>,
}

#[derive(Debug, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "FrameOutputInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Frame {
    // Parent frame. This allows frames to be stored as a tree of divergent
    // simulation paths.
    parent: Option<FrameRef>,
    // Logical step in the simulation.
    step: u64,
    // Physical time of this frame in the simulation.
    simulation_time: f64,
    // Time change since the last frame (which may not be stored in the frame
    // tree).
    time_delta: f64,
    // Total kinetic energy.
    kinetic_energy: f64,
    // Estimated temperature
    estimated_temperature: f64,
    // Positions of each atom (after the changeset has been applied).
    positions: Option<Vec<f64>>,
    // Velocities of each atom (after the changeset has been applied).
    velocities: Option<Vec<f64>>,
    // Forces of each atom (after the changeset has been applied).
    forces: Option<Vec<f64>>,
    // Changes to the base topology of the trajectory and prior changes that
    // have been applied by previous frames. Changesets must be applied in
    // frame-by-frame order.
    changeset: Option<Changeset>,
}

#[derive(Debug, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "TrajectoryOutputInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Trajectory {
    // The frame tree. Frames with smaller steps appear before frames with
    // larger steps.
    frames: Vec<Frame>,
}
