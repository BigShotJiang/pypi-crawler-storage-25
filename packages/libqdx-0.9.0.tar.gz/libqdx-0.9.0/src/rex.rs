// Hack to work around inconsistencies between declared types and actual serialization.
// This isn't pretty, but it's necessary for the time being, until libqdx can be modified to
// avoid custom serialization formats (e.g. ints for enums). Such a modification will be a
// breaking change, since it will require all modules + tengu to be updated.
pub fn libqdx_json_options() -> rex::JsonOptions {
    let mut opts = rex::JsonOptions::default();
    opts.add_int_enum("BondOrder");
    opts.add_int_enum_with_patches(
        "Stereochemistry",
        vec![rex::EnumPatch {
            enum_name: "Down".to_string(),
            discriminant: -1,
        }],
    );
    opts
}
