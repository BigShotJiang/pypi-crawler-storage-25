#[cfg(feature = "rex")]
use rex::Rex;
use std::fmt::{self, Display, Formatter};

use ouroboros::TypeInfo;

#[derive(Debug, PartialEq, Eq, Hash, Copy, Clone, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(u8)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(
    feature = "pyo3",
    pyo3::pyclass(eq, eq_int, hash, frozen, from_py_object)
)]
pub enum Element {
    #[cfg_attr(feature = "serde", serde(alias = "X", alias = "x"))]
    X = 0,
    #[cfg_attr(feature = "serde", serde(alias = "H", alias = "h"))]
    H = 1,
    #[cfg_attr(feature = "serde", serde(alias = "HE", alias = "He", alias = "he"))]
    He,
    #[cfg_attr(feature = "serde", serde(alias = "LI", alias = "Li", alias = "li"))]
    Li,
    #[cfg_attr(feature = "serde", serde(alias = "BE", alias = "Be", alias = "be"))]
    Be,
    #[cfg_attr(feature = "serde", serde(alias = "B", alias = "b"))]
    B,
    #[cfg_attr(feature = "serde", serde(alias = "C", alias = "c"))]
    C,
    #[cfg_attr(feature = "serde", serde(alias = "N", alias = "n"))]
    N,
    #[cfg_attr(feature = "serde", serde(alias = "O", alias = "o"))]
    O,
    #[cfg_attr(feature = "serde", serde(alias = "F", alias = "f"))]
    F,
    #[cfg_attr(feature = "serde", serde(alias = "NE", alias = "Ne", alias = "ne"))]
    Ne,
    #[cfg_attr(feature = "serde", serde(alias = "NA", alias = "Na", alias = "na"))]
    Na,
    #[cfg_attr(feature = "serde", serde(alias = "MG", alias = "Mg", alias = "mg"))]
    Mg,
    #[cfg_attr(feature = "serde", serde(alias = "AL", alias = "Al", alias = "al"))]
    Al,
    #[cfg_attr(feature = "serde", serde(alias = "SI", alias = "Si", alias = "si"))]
    Si,
    #[cfg_attr(feature = "serde", serde(alias = "P", alias = "p"))]
    P,
    #[cfg_attr(feature = "serde", serde(alias = "S", alias = "s"))]
    S,
    #[cfg_attr(feature = "serde", serde(alias = "CL", alias = "Cl", alias = "cl"))]
    Cl,
    #[cfg_attr(feature = "serde", serde(alias = "AR", alias = "Ar", alias = "ar"))]
    Ar,
    #[cfg_attr(feature = "serde", serde(alias = "K", alias = "k"))]
    K,
    #[cfg_attr(feature = "serde", serde(alias = "CA", alias = "Ca", alias = "ca"))]
    Ca,
    #[cfg_attr(feature = "serde", serde(alias = "SC", alias = "Sc", alias = "sc"))]
    Sc,
    #[cfg_attr(feature = "serde", serde(alias = "TI", alias = "Ti", alias = "ti"))]
    Ti,
    #[cfg_attr(feature = "serde", serde(alias = "V", alias = "v"))]
    V,
    #[cfg_attr(feature = "serde", serde(alias = "CR", alias = "Cr", alias = "cr"))]
    Cr,
    #[cfg_attr(feature = "serde", serde(alias = "MN", alias = "Mn", alias = "mn"))]
    Mn,
    #[cfg_attr(feature = "serde", serde(alias = "FE", alias = "Fe", alias = "fe"))]
    Fe,
    #[cfg_attr(feature = "serde", serde(alias = "CO", alias = "Co", alias = "co"))]
    Co,
    #[cfg_attr(feature = "serde", serde(alias = "NI", alias = "Ni", alias = "ni"))]
    Ni,
    #[cfg_attr(feature = "serde", serde(alias = "CU", alias = "Cu", alias = "cu"))]
    Cu,
    #[cfg_attr(feature = "serde", serde(alias = "ZN", alias = "Zn", alias = "zn"))]
    Zn,
    #[cfg_attr(feature = "serde", serde(alias = "GA", alias = "Ga", alias = "ga"))]
    Ga,
    #[cfg_attr(feature = "serde", serde(alias = "GE", alias = "Ge", alias = "ge"))]
    Ge,
    #[cfg_attr(feature = "serde", serde(alias = "AS", alias = "As", alias = "as"))]
    As,
    #[cfg_attr(feature = "serde", serde(alias = "SE", alias = "Se", alias = "se"))]
    Se,
    #[cfg_attr(feature = "serde", serde(alias = "BR", alias = "Br", alias = "br"))]
    Br,
    #[cfg_attr(feature = "serde", serde(alias = "KR", alias = "Kr", alias = "kr"))]
    Kr,
    #[cfg_attr(feature = "serde", serde(alias = "RB", alias = "Rb", alias = "rb"))]
    Rb,
    #[cfg_attr(feature = "serde", serde(alias = "SR", alias = "Sr", alias = "sr"))]
    Sr,
    #[cfg_attr(feature = "serde", serde(alias = "Y", alias = "y"))]
    Y,
    #[cfg_attr(feature = "serde", serde(alias = "ZR", alias = "Zr", alias = "zr"))]
    Zr,
    #[cfg_attr(feature = "serde", serde(alias = "NB", alias = "Nb", alias = "nb"))]
    Nb,
    #[cfg_attr(feature = "serde", serde(alias = "MO", alias = "Mo", alias = "mo"))]
    Mo,
    #[cfg_attr(feature = "serde", serde(alias = "TC", alias = "Tc", alias = "tc"))]
    Tc,
    #[cfg_attr(feature = "serde", serde(alias = "RU", alias = "Ru", alias = "ru"))]
    Ru,
    #[cfg_attr(feature = "serde", serde(alias = "RH", alias = "Rh", alias = "rh"))]
    Rh,
    #[cfg_attr(feature = "serde", serde(alias = "PD", alias = "Pd", alias = "pd"))]
    Pd,
    #[cfg_attr(feature = "serde", serde(alias = "AG", alias = "Ag", alias = "ag"))]
    Ag,
    #[cfg_attr(feature = "serde", serde(alias = "CD", alias = "Cd", alias = "cd"))]
    Cd,
    #[cfg_attr(feature = "serde", serde(alias = "IN", alias = "In", alias = "in"))]
    In,
    #[cfg_attr(feature = "serde", serde(alias = "SN", alias = "Sn", alias = "sn"))]
    Sn,
    #[cfg_attr(feature = "serde", serde(alias = "SB", alias = "Sb", alias = "sb"))]
    Sb,
    #[cfg_attr(feature = "serde", serde(alias = "TE", alias = "Te", alias = "te"))]
    Te,
    #[cfg_attr(feature = "serde", serde(alias = "I", alias = "i"))]
    I,
    #[cfg_attr(feature = "serde", serde(alias = "XE", alias = "Xe", alias = "xe"))]
    Xe,
    #[cfg_attr(feature = "serde", serde(alias = "CS", alias = "Cs", alias = "cs"))]
    Cs,
    #[cfg_attr(feature = "serde", serde(alias = "BA", alias = "Ba", alias = "ba"))]
    Ba,
    #[cfg_attr(feature = "serde", serde(alias = "LA", alias = "La", alias = "la"))]
    La,
    #[cfg_attr(feature = "serde", serde(alias = "CE", alias = "Ce", alias = "ce"))]
    Ce,
    #[cfg_attr(feature = "serde", serde(alias = "PR", alias = "Pr", alias = "pr"))]
    Pr,
    #[cfg_attr(feature = "serde", serde(alias = "ND", alias = "Nd", alias = "nd"))]
    Nd,
    #[cfg_attr(feature = "serde", serde(alias = "PM", alias = "Pm", alias = "pm"))]
    Pm,
    #[cfg_attr(feature = "serde", serde(alias = "SM", alias = "Sm", alias = "sm"))]
    Sm,
    #[cfg_attr(feature = "serde", serde(alias = "EU", alias = "Eu", alias = "eu"))]
    Eu,
    #[cfg_attr(feature = "serde", serde(alias = "GD", alias = "Gd", alias = "gd"))]
    Gd,
    #[cfg_attr(feature = "serde", serde(alias = "TB", alias = "Tb", alias = "tb"))]
    Tb,
    #[cfg_attr(feature = "serde", serde(alias = "DY", alias = "Dy", alias = "dy"))]
    Dy,
    #[cfg_attr(feature = "serde", serde(alias = "HO", alias = "Ho", alias = "ho"))]
    Ho,
    #[cfg_attr(feature = "serde", serde(alias = "ER", alias = "Er", alias = "er"))]
    Er,
    #[cfg_attr(feature = "serde", serde(alias = "TM", alias = "Tm", alias = "tm"))]
    Tm,
    #[cfg_attr(feature = "serde", serde(alias = "YB", alias = "Yb", alias = "yb"))]
    Yb,
    #[cfg_attr(feature = "serde", serde(alias = "LU", alias = "Lu", alias = "lu"))]
    Lu,
    #[cfg_attr(feature = "serde", serde(alias = "HF", alias = "Hf", alias = "hf"))]
    Hf,
    #[cfg_attr(feature = "serde", serde(alias = "TA", alias = "Ta", alias = "ta"))]
    Ta,
    #[cfg_attr(feature = "serde", serde(alias = "W", alias = "w"))]
    W,
    #[cfg_attr(feature = "serde", serde(alias = "RE", alias = "Re", alias = "re"))]
    Re,
    #[cfg_attr(feature = "serde", serde(alias = "OS", alias = "Os", alias = "os"))]
    Os,
    #[cfg_attr(feature = "serde", serde(alias = "IR", alias = "Ir", alias = "ir"))]
    Ir,
    #[cfg_attr(feature = "serde", serde(alias = "PT", alias = "Pt", alias = "pt"))]
    Pt,
    #[cfg_attr(feature = "serde", serde(alias = "AU", alias = "Au", alias = "au"))]
    Au,
    #[cfg_attr(feature = "serde", serde(alias = "HG", alias = "Hg", alias = "hg"))]
    Hg,
    #[cfg_attr(feature = "serde", serde(alias = "TL", alias = "Tl", alias = "tl"))]
    Tl,
    #[cfg_attr(feature = "serde", serde(alias = "PB", alias = "Pb", alias = "pb"))]
    Pb,
    #[cfg_attr(feature = "serde", serde(alias = "BI", alias = "Bi", alias = "bi"))]
    Bi,
    #[cfg_attr(feature = "serde", serde(alias = "PO", alias = "Po", alias = "po"))]
    Po,
    #[cfg_attr(feature = "serde", serde(alias = "AT", alias = "At", alias = "at"))]
    At,
    #[cfg_attr(feature = "serde", serde(alias = "RN", alias = "Rn", alias = "rn"))]
    Rn,
    #[cfg_attr(feature = "serde", serde(alias = "FR", alias = "Fr", alias = "fr"))]
    Fr,
    #[cfg_attr(feature = "serde", serde(alias = "RA", alias = "Ra", alias = "ra"))]
    Ra,
    #[cfg_attr(feature = "serde", serde(alias = "AC", alias = "Ac", alias = "ac"))]
    Ac,
    #[cfg_attr(feature = "serde", serde(alias = "TH", alias = "Th", alias = "th"))]
    Th,
    #[cfg_attr(feature = "serde", serde(alias = "PA", alias = "Pa", alias = "pa"))]
    Pa,
    #[cfg_attr(feature = "serde", serde(alias = "U", alias = "u"))]
    U,
    #[cfg_attr(feature = "serde", serde(alias = "NP", alias = "Np", alias = "np"))]
    Np,
    #[cfg_attr(feature = "serde", serde(alias = "PU", alias = "Pu", alias = "pu"))]
    Pu,
    #[cfg_attr(feature = "serde", serde(alias = "AM", alias = "Am", alias = "am"))]
    Am,
    #[cfg_attr(feature = "serde", serde(alias = "CM", alias = "Cm", alias = "cm"))]
    Cm,
    #[cfg_attr(feature = "serde", serde(alias = "BK", alias = "Bk", alias = "bk"))]
    Bk,
    #[cfg_attr(feature = "serde", serde(alias = "CF", alias = "Cf", alias = "cf"))]
    Cf,
    #[cfg_attr(feature = "serde", serde(alias = "ES", alias = "Es", alias = "es"))]
    Es,
    #[cfg_attr(feature = "serde", serde(alias = "FM", alias = "Fm", alias = "fm"))]
    Fm,
    #[cfg_attr(feature = "serde", serde(alias = "MD", alias = "Md", alias = "md"))]
    Md,
    #[cfg_attr(feature = "serde", serde(alias = "NO", alias = "No", alias = "no"))]
    No,
    #[cfg_attr(feature = "serde", serde(alias = "LR", alias = "Lr", alias = "lr"))]
    Lr,
    #[cfg_attr(feature = "serde", serde(alias = "RF", alias = "Rf", alias = "rf"))]
    Rf,
    #[cfg_attr(feature = "serde", serde(alias = "DB", alias = "Db", alias = "db"))]
    Db,
    #[cfg_attr(feature = "serde", serde(alias = "SG", alias = "Sg", alias = "sg"))]
    Sg,
    #[cfg_attr(feature = "serde", serde(alias = "BH", alias = "Bh", alias = "bh"))]
    Bh,
    #[cfg_attr(feature = "serde", serde(alias = "HS", alias = "Hs", alias = "hs"))]
    Hs,
    #[cfg_attr(feature = "serde", serde(alias = "MT", alias = "Mt", alias = "mt"))]
    Mt,
    #[cfg_attr(feature = "serde", serde(alias = "DS", alias = "Ds", alias = "ds"))]
    Ds,
    #[cfg_attr(feature = "serde", serde(alias = "RG", alias = "Rg", alias = "rg"))]
    Rg,
    #[cfg_attr(feature = "serde", serde(alias = "CN", alias = "Cn", alias = "cn"))]
    Cn,
    #[cfg_attr(feature = "serde", serde(alias = "NH", alias = "Nh", alias = "nh"))]
    Nh,
    #[cfg_attr(feature = "serde", serde(alias = "FL", alias = "Fl", alias = "fl"))]
    Fl,
    #[cfg_attr(feature = "serde", serde(alias = "MC", alias = "Mc", alias = "mc"))]
    Mc,
    #[cfg_attr(feature = "serde", serde(alias = "LV", alias = "Lv", alias = "lv"))]
    Lv,
    #[cfg_attr(feature = "serde", serde(alias = "TS", alias = "Ts", alias = "ts"))]
    Ts,
    #[cfg_attr(feature = "serde", serde(alias = "OG", alias = "Og", alias = "og"))]
    Og,
}

impl Display for Element {
    fn fmt(&self, f: &mut Formatter) -> fmt::Result {
        let string: &str = (*self).into();
        write!(f, "{}", string)
    }
}

impl<'a> TryFrom<&'a str> for Element {
    type Error = String;

    fn try_from(s: &'a str) -> Result<Self, Self::Error> {
        use Element::*;

        match s.to_ascii_uppercase().as_ref() {
            "X" => Ok(X),
            "H" => Ok(H),
            "HE" => Ok(He),
            "LI" => Ok(Li),
            "BE" => Ok(Be),
            "B" => Ok(B),
            "C" => Ok(C),
            "N" => Ok(N),
            "O" => Ok(O),
            "F" => Ok(F),
            "NE" => Ok(Ne),
            "NA" => Ok(Na),
            "MG" => Ok(Mg),
            "AL" => Ok(Al),
            "SI" => Ok(Si),
            "P" => Ok(P),
            "S" => Ok(S),
            "CL" => Ok(Cl),
            "AR" => Ok(Ar),
            "K" => Ok(K),
            "CA" => Ok(Ca),
            "SC" => Ok(Sc),
            "TI" => Ok(Ti),
            "V" => Ok(V),
            "CR" => Ok(Cr),
            "MN" => Ok(Mn),
            "FE" => Ok(Fe),
            "CO" => Ok(Co),
            "NI" => Ok(Ni),
            "CU" => Ok(Cu),
            "ZN" => Ok(Zn),
            "GA" => Ok(Ga),
            "GE" => Ok(Ge),
            "AS" => Ok(As),
            "SE" => Ok(Se),
            "BR" => Ok(Br),
            "KR" => Ok(Kr),
            "RB" => Ok(Rb),
            "SR" => Ok(Sr),
            "Y" => Ok(Y),
            "ZR" => Ok(Zr),
            "NB" => Ok(Nb),
            "MO" => Ok(Mo),
            "TC" => Ok(Tc),
            "RU" => Ok(Ru),
            "RH" => Ok(Rh),
            "PD" => Ok(Pd),
            "AG" => Ok(Ag),
            "CD" => Ok(Cd),
            "IN" => Ok(In),
            "SN" => Ok(Sn),
            "SB" => Ok(Sb),
            "TE" => Ok(Te),
            "I" => Ok(I),
            "XE" => Ok(Xe),
            "CS" => Ok(Cs),
            "BA" => Ok(Ba),
            "LA" => Ok(La),
            "CE" => Ok(Ce),
            "PR" => Ok(Pr),
            "ND" => Ok(Nd),
            "PM" => Ok(Pm),
            "SM" => Ok(Sm),
            "EU" => Ok(Eu),
            "GD" => Ok(Gd),
            "TB" => Ok(Tb),
            "DY" => Ok(Dy),
            "HO" => Ok(Ho),
            "ER" => Ok(Er),
            "TM" => Ok(Tm),
            "YB" => Ok(Yb),
            "LU" => Ok(Lu),
            "HF" => Ok(Hf),
            "TA" => Ok(Ta),
            "W" => Ok(W),
            "RE" => Ok(Re),
            "OS" => Ok(Os),
            "IR" => Ok(Ir),
            "PT" => Ok(Pt),
            "AU" => Ok(Au),
            "HG" => Ok(Hg),
            "TL" => Ok(Tl),
            "PB" => Ok(Pb),
            "BI" => Ok(Bi),
            "PO" => Ok(Po),
            "AT" => Ok(At),
            "RN" => Ok(Rn),
            "FR" => Ok(Fr),
            "RA" => Ok(Ra),
            "AC" => Ok(Ac),
            "TH" => Ok(Th),
            "PA" => Ok(Pa),
            "U" => Ok(U),
            "NP" => Ok(Np),
            "PU" => Ok(Pu),
            "AM" => Ok(Am),
            "CM" => Ok(Cm),
            "BK" => Ok(Bk),
            "CF" => Ok(Cf),
            "ES" => Ok(Es),
            "FM" => Ok(Fm),
            "MD" => Ok(Md),
            "NO" => Ok(No),
            "LR" => Ok(Lr),
            "RF" => Ok(Rf),
            "DB" => Ok(Db),
            "SG" => Ok(Sg),
            "BH" => Ok(Bh),
            "HS" => Ok(Hs),
            "MT" => Ok(Mt),
            "DS" => Ok(Ds),
            "RG" => Ok(Rg),
            "CN" => Ok(Cn),
            "NH" => Ok(Nh),
            "FL" => Ok(Fl),
            "MC" => Ok(Mc),
            "LV" => Ok(Lv),
            "TS" => Ok(Ts),
            "OG" => Ok(Og),
            _ => Err(s.to_string()),
        }
    }
}

impl From<Element> for &str {
    fn from(element: Element) -> Self {
        use Element::*;

        match element {
            X => "X",
            H => "H",
            He => "He",
            Li => "Li",
            Be => "Be",
            B => "B",
            C => "C",
            N => "N",
            O => "O",
            F => "F",
            Ne => "Ne",
            Na => "Na",
            Mg => "Mg",
            Al => "Al",
            Si => "Si",
            P => "P",
            S => "S",
            Cl => "Cl",
            Ar => "Ar",
            K => "K",
            Ca => "Ca",
            Sc => "Sc",
            Ti => "Ti",
            V => "V",
            Cr => "Cr",
            Mn => "Mn",
            Fe => "Fe",
            Co => "Co",
            Ni => "Ni",
            Cu => "Cu",
            Zn => "Zn",
            Ga => "Ga",
            Ge => "Ge",
            As => "As",
            Se => "Se",
            Br => "Br",
            Kr => "Kr",
            Rb => "Rb",
            Sr => "Sr",
            Y => "Y",
            Zr => "Zr",
            Nb => "Nb",
            Mo => "Mo",
            Tc => "Tc",
            Ru => "Ru",
            Rh => "Rh",
            Pd => "Pd",
            Ag => "Ag",
            Cd => "Cd",
            In => "In",
            Sn => "Sn",
            Sb => "Sb",
            Te => "Te",
            I => "I",
            Xe => "Xe",
            Cs => "Cs",
            Ba => "Ba",
            La => "La",
            Ce => "Ce",
            Pr => "Pr",
            Nd => "Nd",
            Pm => "Pm",
            Sm => "Sm",
            Eu => "Eu",
            Gd => "Gd",
            Tb => "Tb",
            Dy => "Dy",
            Ho => "Ho",
            Er => "Er",
            Tm => "Tm",
            Yb => "Yb",
            Lu => "Lu",
            Hf => "Hf",
            Ta => "Ta",
            W => "W",
            Re => "Re",
            Os => "Os",
            Ir => "Ir",
            Pt => "Pt",
            Au => "Au",
            Hg => "Hg",
            Tl => "Tl",
            Pb => "Pb",
            Bi => "Bi",
            Po => "Po",
            At => "At",
            Rn => "Rn",
            Fr => "Fr",
            Ra => "Ra",
            Ac => "Ac",
            Th => "Th",
            Pa => "Pa",
            U => "U",
            Np => "Np",
            Pu => "Pu",
            Am => "Am",
            Cm => "Cm",
            Bk => "Bk",
            Cf => "Cf",
            Es => "Es",
            Fm => "Fm",
            Md => "Md",
            No => "No",
            Lr => "Lr",
            Rf => "Rf",
            Db => "Db",
            Sg => "Sg",
            Bh => "Bh",
            Hs => "Hs",
            Mt => "Mt",
            Ds => "Ds",
            Rg => "Rg",
            Cn => "Cn",
            Nh => "Nh",
            Fl => "Fl",
            Mc => "Mc",
            Lv => "Lv",
            Ts => "Ts",
            Og => "Og",
        }
    }
}

impl Element {
    pub fn atomic_number(self) -> usize {
        self as usize
    }
}
