use ouroboros::{Alias, Type, TypeInfo, TypeName};
#[cfg(feature = "rex")]
use rex::{Decode, Encode, Error, Expr, Span, ToType, Type as RexType, TypeCon};
#[cfg(feature = "rex")]
use std::sync::Arc;

#[cfg(feature = "graphql")]
async_graphql::scalar!(AtomRef);

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct AtomRef(pub u32);

impl TypeInfo for AtomRef {
    fn t() -> Type {
        Type::from(Alias::new("AtomRef", u32::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("AtomRef")
    }
}

impl From<u32> for AtomRef {
    fn from(value: u32) -> Self {
        Self(value)
    }
}

impl From<AtomRef> for u32 {
    fn from(value: AtomRef) -> Self {
        value.0
    }
}

#[cfg(feature = "rex")]
impl ToType for AtomRef {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::Uint)
    }
}

#[cfg(feature = "rex")]
impl Encode for AtomRef {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for AtomRef {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(AtomRef(u32::try_decode(v)?))
    }
}

#[cfg(feature = "graphql")]
async_graphql::scalar!(HydrogenCapRef);

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct HydrogenCapRef(pub u32);

impl TypeInfo for HydrogenCapRef {
    fn t() -> Type {
        Type::from(Alias::new("HydrogenCapRef", u32::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("HydrogenCapRef")
    }
}

#[cfg(feature = "rex")]
impl ToType for HydrogenCapRef {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::Uint)
    }
}

#[cfg(feature = "rex")]
impl Encode for HydrogenCapRef {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for HydrogenCapRef {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(HydrogenCapRef(u32::try_decode(v)?))
    }
}

impl From<u32> for HydrogenCapRef {
    fn from(value: u32) -> Self {
        Self(value)
    }
}

impl From<HydrogenCapRef> for u32 {
    fn from(value: HydrogenCapRef) -> Self {
        value.0
    }
}

#[cfg(feature = "graphql")]
async_graphql::scalar!(FormalCharge);

#[derive(Clone, Copy, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct FormalCharge(pub i32);

impl TypeInfo for FormalCharge {
    fn t() -> Type {
        Type::from(Alias::new("FormalCharge", i32::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("FormalCharge")
    }
}

#[cfg(feature = "rex")]
impl ToType for FormalCharge {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::Int)
    }
}

#[cfg(feature = "rex")]
impl Encode for FormalCharge {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for FormalCharge {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(FormalCharge(i32::try_decode(v)?))
    }
}

impl From<i32> for FormalCharge {
    fn from(value: i32) -> Self {
        Self(value)
    }
}

impl From<FormalCharge> for i32 {
    fn from(value: FormalCharge) -> Self {
        value.0
    }
}

#[cfg(feature = "graphql")]
async_graphql::scalar!(PartialCharge);

#[derive(Clone, Copy, Debug, Default, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct PartialCharge(pub f32);

impl TypeInfo for PartialCharge {
    fn t() -> Type {
        Type::from(Alias::new("PartialCharge", f32::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("PartialCharge")
    }
}

#[cfg(feature = "rex")]
impl ToType for PartialCharge {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::Float)
    }
}

#[cfg(feature = "rex")]
impl Encode for PartialCharge {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for PartialCharge {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(PartialCharge(f32::try_decode(v)?))
    }
}

impl From<f32> for PartialCharge {
    fn from(value: f32) -> Self {
        Self(value)
    }
}

impl From<PartialCharge> for f32 {
    fn from(value: PartialCharge) -> Self {
        value.0
    }
}
