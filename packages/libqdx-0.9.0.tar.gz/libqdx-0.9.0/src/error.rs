use crate::AminoAcidSeq;

#[derive(thiserror::Error, Debug)]
pub enum Error {
    #[error("terminal residue has bad hydrogens, found '{found:?}'")]
    BadTerminusError { found: Vec<String> },
    #[error("invalid amino acid name, found '{found}'")]
    ParseAminoAcid { found: String },
    #[error("unsupported amino acid atom '{amino_acid_atom}'")]
    UnsupportedAminoAcidAtom { amino_acid_atom: String },
    #[error("bad atom label: {atom_label:?}")]
    BadAtomLabel { atom_label: String },

    #[error(
        "bad protonation state for {aa:?} @ {}: {:?} doesn't match a known state",
        aa_seq_n.map(|id| id.to_string()).unwrap_or("???".into()),
        {let mut hydrogen_atoms = hydrogen_atoms.clone(); hydrogen_atoms.sort(); hydrogen_atoms},
    )]
    BadProtonationState {
        aa: AminoAcidSeq,
        aa_seq_n: Option<i32>,
        hydrogen_atoms: Vec<String>,
    },

    #[error(
        "on {aa:?} @ {}: the atom(s) {:?} clash with a covalent binder",
        aa_seq_n.map(|id| id.to_string()).unwrap_or("???".into()),
        {let mut clashing_atoms = clashing_atoms.clone(); clashing_atoms.sort(); clashing_atoms},
    )]
    ClashBetweenCovalentBinderAndHydrogen {
        aa: AminoAcidSeq,
        aa_seq_n: Option<i32>,
        clashing_atoms: Vec<String>,
    },

    #[error("missing topology data (i.e. bond info) for this amino acid")]
    MissingAminoAcidTopologyData,

    #[error("missing heavy atoms in {aa:?} @ {}: {missing_atoms:?} are missing",
        aa_seq_n.map(|id| id.to_string()).unwrap_or("???".into()),
    )]
    MissingAminoAcidHeavyAtoms {
        aa: AminoAcidSeq,
        aa_seq_n: Option<i32>,
        missing_atoms: Vec<String>,
    },

    #[error(
        "amino acid {aa:?} @ {} is unprotonated, but protonation is required for this task",
        aa_seq_n.map(|id| id.to_string()).unwrap_or("???".into()),
    )]
    NoAminoAcidHydrogens {
        aa: AminoAcidSeq,
        aa_seq_n: Option<i32>,
    },

    #[error("missing template for {aa:?}")]
    MissingAminoAcidTemplate { aa: AminoAcidSeq },

    #[error(
        "duplicate atoms in {aa:?} @ {}: {duplicate_atoms:?} appear more than once",
        aa_seq_n.map(|id| id.to_string()).unwrap_or("???".into()),
    )]
    DuplicateAtomsInAminoAcid {
        aa: AminoAcidSeq,
        aa_seq_n: Option<i32>,
        duplicate_atoms: Vec<String>,
    },

    #[error(
        "wrong atoms in {aa:?} @ {}: {wrong_atoms:?} should not be present",
        aa_seq_n.map(|id| id.to_string()).unwrap_or("???".into()),
    )]
    WrongAtomsInAminoAcid {
        aa: AminoAcidSeq,
        aa_seq_n: Option<i32>,
        wrong_atoms: Vec<String>,
    },

    #[error(
        "duplicate amino acid with same seq_id and insertion code: {:?}{}",
        aa_seq_n,
        aa_insertion_code.clone().unwrap_or("".into()),
    )]
    DuplicateAminoAcid {
        aa_seq_n: i32,
        aa_insertion_code: Option<String>,
    },
}
