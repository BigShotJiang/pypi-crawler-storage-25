use ouroboros::{Alias, Type, TypeInfo, TypeName};
#[cfg(feature = "rex")]
use rex::{Decode, Encode, Error, Expr, Rex, Span, ToType, Type as RexType};
#[cfg(feature = "rex")]
use std::sync::Arc;

use super::AtomRef;

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(u8)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(
    feature = "serde",
    derive(serde_repr::Deserialize_repr, serde_repr::Serialize_repr)
)]
#[cfg_attr(
    feature = "pyo3",
    pyo3::pyclass(eq, eq_int, hash, frozen, from_py_object)
)]
pub enum BondOrder {
    Unspecified = 0,
    Single = 1,
    Double = 2,
    Triple = 3,
    Quadruple = 4,
    Quintuple = 5,
    Sextuple = 6,

    FiveAndAHalf = 250,
    FourAndAHalf = 251,
    ThreeAndAHalf = 252,
    TwoAndAHalf = 253,
    OneAndAHalf = 254,

    Ring = 255,
}

impl From<u8> for BondOrder {
    fn from(value: u8) -> Self {
        match value {
            0 => Self::Unspecified,
            1 => Self::Single,
            2 => Self::Double,
            3 => Self::Triple,
            4 => Self::Quadruple,
            5 => Self::Quintuple,
            6 => Self::Sextuple,
            250 => Self::FiveAndAHalf,
            251 => Self::FourAndAHalf,
            252 => Self::ThreeAndAHalf,
            253 => Self::TwoAndAHalf,
            254 => Self::OneAndAHalf,
            255 => Self::Ring,
            _ => unreachable!(),
        }
    }
}

impl From<BondOrder> for u8 {
    fn from(value: BondOrder) -> Self {
        match value {
            BondOrder::Unspecified => 0,
            BondOrder::Single => 1,
            BondOrder::Double => 2,
            BondOrder::Triple => 3,
            BondOrder::Quadruple => 4,
            BondOrder::Quintuple => 5,
            BondOrder::Sextuple => 6,
            BondOrder::FiveAndAHalf => 250,
            BondOrder::FourAndAHalf => 251,
            BondOrder::ThreeAndAHalf => 252,
            BondOrder::TwoAndAHalf => 253,
            BondOrder::OneAndAHalf => 254,
            BondOrder::Ring => 255,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(i8)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(
    feature = "serde",
    derive(serde_repr::Deserialize_repr, serde_repr::Serialize_repr)
)]
#[cfg_attr(
    feature = "pyo3",
    pyo3::pyclass(eq, eq_int, hash, frozen, from_py_object)
)]
pub enum Stereochemistry {
    NONE = 0,
    Up = 1,
    Down = -1,
    Either = 2,
    CisOrTrans = 3,
}

impl From<i8> for Stereochemistry {
    fn from(value: i8) -> Self {
        match value {
            0 => Self::NONE,
            1 => Self::Up,
            -1 => Self::Down,
            2 => Self::Either,
            3 => Self::CisOrTrans,
            _ => unreachable!(),
        }
    }
}

impl From<Stereochemistry> for i8 {
    fn from(value: Stereochemistry) -> Self {
        match value {
            Stereochemistry::NONE => 0,
            Stereochemistry::Up => 1,
            Stereochemistry::Down => -1,
            Stereochemistry::Either => 2,
            Stereochemistry::CisOrTrans => 3,
        }
    }
}

#[cfg(feature = "graphql")]
async_graphql::scalar!(Bond);

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
#[repr(C)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Bond(pub AtomRef, pub AtomRef, pub BondOrder);

impl TypeInfo for Bond {
    fn t() -> Type {
        Type::Alias(Alias::new("Bond", <(AtomRef, AtomRef, BondOrder)>::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("Bond")
    }
}

#[cfg(feature = "rex")]
impl ToType for Bond {
    fn to_type() -> RexType {
        <(AtomRef, AtomRef, BondOrder)>::to_type()
    }
}

#[cfg(feature = "rex")]
impl Encode for Bond {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        (self.0, self.1, self.2).try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for Bond {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        let (x0, x1, x2) = <(AtomRef, AtomRef, BondOrder)>::try_decode(v)?;
        Ok(Bond(x0, x1, x2))
    }
}
