#[cfg(feature = "rex")]
use std::sync::Arc;

use ouroboros::{Alias, Type, TypeInfo, TypeName};
#[cfg(feature = "rex")]
use rex::{Decode, Encode, Error, Expr, Span, ToType, Type as RexType, TypeCon};
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use super::AtomRef;

#[cfg(feature = "graphql")]
async_graphql::scalar!(FragmentRef);

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct FragmentRef(pub u32);

impl TypeInfo for FragmentRef {
    fn t() -> Type {
        Type::from(Alias::new("FragmentRef", u32::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("FragmentRef")
    }
}

impl From<u32> for FragmentRef {
    fn from(value: u32) -> Self {
        Self(value)
    }
}

impl From<FragmentRef> for u32 {
    fn from(value: FragmentRef) -> Self {
        value.0
    }
}

#[cfg(feature = "rex")]
impl ToType for FragmentRef {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::Uint)
    }
}

#[cfg(feature = "rex")]
impl Encode for FragmentRef {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for FragmentRef {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(FragmentRef(u32::try_decode(v)?))
    }
}

#[cfg(feature = "graphql")]
async_graphql::scalar!(Fragment);

#[derive(Clone, Debug, Default, Eq, Hash, PartialEq)]
#[repr(C)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Fragment(pub Vec<AtomRef>);

impl TypeInfo for Fragment {
    fn t() -> Type {
        <Vec<AtomRef>>::t()
    }

    fn tname() -> ouroboros::TypeName {
        <Vec<AtomRef>>::tname()
    }
}

#[cfg(feature = "rex")]
impl ToType for Fragment {
    fn to_type() -> RexType {
        <Vec<AtomRef>>::to_type()
    }
}

#[cfg(feature = "rex")]
impl Encode for Fragment {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for Fragment {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(Fragment(<Vec<AtomRef>>::try_decode(v)?))
    }
}

impl From<Vec<AtomRef>> for Fragment {
    fn from(value: Vec<AtomRef>) -> Self {
        Self(value)
    }
}

impl From<Vec<u32>> for Fragment {
    fn from(value: Vec<u32>) -> Self {
        value.into_iter().map(AtomRef).collect::<Vec<_>>().into()
    }
}

impl From<Fragment> for Vec<u32> {
    fn from(value: Fragment) -> Self {
        value.0.into_iter().map(u32::from).collect()
    }
}

impl Fragment {
    pub fn iter(&self) -> impl Iterator<Item = &AtomRef> {
        self.0.iter()
    }

    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut AtomRef> {
        self.0.iter_mut()
    }

    pub fn len(&self) -> usize {
        self.0.len()
    }

    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    pub fn contains(&self, atom: &AtomRef) -> bool {
        self.0.contains(atom)
    }
}

#[cfg(feature = "graphql")]
async_graphql::scalar!(FragmentMultiplicity);

#[derive(Clone, Copy, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct FragmentMultiplicity(pub u8);

impl TypeInfo for FragmentMultiplicity {
    fn t() -> Type {
        Type::from(Alias::new("FragmentMultiplicity", u8::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("FragmentMultiplicity")
    }
}

#[cfg(feature = "rex")]
impl ToType for FragmentMultiplicity {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::Uint)
    }
}

#[cfg(feature = "rex")]
impl Encode for FragmentMultiplicity {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, Error> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for FragmentMultiplicity {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, Error> {
        Ok(FragmentMultiplicity(u8::try_decode(v)?))
    }
}

impl From<u8> for FragmentMultiplicity {
    fn from(value: u8) -> Self {
        Self(value)
    }
}

impl From<FragmentMultiplicity> for u8 {
    fn from(value: FragmentMultiplicity) -> Self {
        value.0
    }
}

#[derive(Clone, Debug, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "FragmentCutoffsInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct FragmentCutoffs {
    #[cfg_attr(feature = "serde", serde(default = "default_dimer_cutoff"))]
    pub dimer: Option<f64>,
    #[cfg_attr(feature = "serde", serde(default = "default_trimer_cutoff"))]
    pub trimer: Option<f64>,
    #[cfg_attr(feature = "serde", serde(default = "default_tetramer_cutoff"))]
    pub tetramer: Option<f64>,
    pub pentamer: Option<f64>,
    pub hexamer: Option<f64>,
    pub heptamer: Option<f64>,
    pub octamer: Option<f64>,
}

fn default_dimer_cutoff() -> Option<f64> {
    Some(100.0)
}

fn default_trimer_cutoff() -> Option<f64> {
    Some(25.0)
}

fn default_tetramer_cutoff() -> Option<f64> {
    Some(10.0)
}

impl Default for FragmentCutoffs {
    fn default() -> Self {
        Self {
            dimer: default_dimer_cutoff(),
            trimer: default_trimer_cutoff(),
            tetramer: default_tetramer_cutoff(),
            pentamer: None,
            hexamer: None,
            heptamer: None,
            octamer: None,
        }
    }
}

#[derive(Clone, Copy, Default, Debug, Eq, PartialEq, TypeInfo)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum FragmentDistanceMethod {
    #[cfg_attr(
        feature = "serde",
        serde(alias = "CENTROID", alias = "Centroid", alias = "centroid")
    )]
    Centroid = 1,
    #[default]
    #[cfg_attr(
        feature = "serde",
        serde(alias = "CLOSEST_PAIR", alias = "ClosestPair", alias = "closest_pair")
    )]
    ClosestPair = 2,
}

#[derive(Clone, Copy, Default, Debug, Eq, PartialEq, TypeInfo)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum FragmentDistanceMetric {
    #[cfg_attr(feature = "serde", serde(alias = "MAX", alias = "Max", alias = "max"))]
    Max = 1,
    #[default]
    #[cfg_attr(
        feature = "serde",
        serde(alias = "AVERAGE", alias = "Average", alias = "average")
    )]
    Average = 2,
    #[cfg_attr(feature = "serde", serde(alias = "MIN", alias = "Min", alias = "min"))]
    Min = 3,
}

#[derive(Clone, Default, Copy, Debug, Eq, PartialEq, TypeInfo)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum FragmentLevel {
    #[default]
    #[cfg_attr(
        feature = "serde",
        serde(alias = "MONOMER", alias = "Monomer", alias = "monomer")
    )]
    Monomer = 1,

    #[cfg_attr(
        feature = "serde",
        serde(alias = "DIMMER", alias = "Dimer", alias = "dimer")
    )]
    Dimer = 2,

    #[cfg_attr(
        feature = "serde",
        serde(alias = "TRIMER", alias = "Trimer", alias = "trimer")
    )]
    Trimer = 3,

    #[cfg_attr(
        feature = "serde",
        serde(alias = "TETRAMER", alias = "Tetramer", alias = "tetramer")
    )]
    Tetramer = 4,

    #[cfg_attr(
        feature = "serde",
        serde(alias = "PENTAMER", alias = "Pentamer", alias = "pentamer")
    )]
    Pentamer = 5,

    #[cfg_attr(
        feature = "serde",
        serde(alias = "HEXAMER", alias = "Hexamer", alias = "hexamer")
    )]
    Hexamer = 6,

    #[cfg_attr(
        feature = "serde",
        serde(alias = "HEPTAMER", alias = "Heptamer", alias = "heptamer")
    )]
    Heptamer = 7,

    #[cfg_attr(
        feature = "serde",
        serde(alias = "OCTAMER", alias = "Octamer", alias = "octamer")
    )]
    Octamer = 8,
}
