use crate::{TRC, Topology};

// Shared comparison helpers for PDB/mmCIF parity tests.
// Strict checks for semantic data (atom identity, residue/chains metadata),
// while handling known format-level differences in connectivity and precision.

/// PDB coordinates are typically written with 3-decimal precision, while mmCIF
/// may retain higher precision for the same structure.
pub const GEOMETRY_TOLERANCE: f32 = 0.001;

fn first_diff_index<T: PartialEq>(left: &[T], right: &[T]) -> Option<usize> {
    left.iter().zip(right.iter()).position(|(a, b)| a != b)
}

fn push_scalar_diff<T: PartialEq + std::fmt::Debug>(
    details: &mut Vec<String>,
    field: &str,
    left: &T,
    right: &T,
) {
    if left != right {
        details.push(format!("{field} differs: {left:?} vs {right:?}"));
    }
}

fn push_vec_diff<T: PartialEq + std::fmt::Debug>(
    details: &mut Vec<String>,
    field: &str,
    left: &[T],
    right: &[T],
) {
    if left.len() != right.len() {
        details.push(format!("{field} length {} vs {}", left.len(), right.len()));
        return;
    }

    if let Some(idx) = first_diff_index(left, right) {
        details.push(format!(
            "first {field} diff @{}: {:?} vs {:?}",
            idx, left[idx], right[idx]
        ));
    }
}

fn push_option_vec_diff<T: PartialEq + std::fmt::Debug>(
    details: &mut Vec<String>,
    field: &str,
    left: &Option<Vec<T>>,
    right: &Option<Vec<T>>,
) {
    if left.is_some() != right.is_some() {
        details.push(format!(
            "{field} presence differs: {} vs {}",
            left.is_some(),
            right.is_some()
        ));
        return;
    }

    if let (Some(left), Some(right)) = (left, right) {
        push_vec_diff(details, field, left, right);
    }
}

pub fn topology_without_connectivity(topology: &Topology) -> Topology {
    let mut topology = topology.clone();
    // PDB connectivity is often incomplete (e.g. only special CONECT records
    // like disulfide bridges), while mmCIF generally contains full bond tables.
    topology.connectivity = None;
    topology
}

type Point = (f32, f32, f32);

pub fn first_coordinate_diff(
    left: &[f32],
    right: &[f32],
    tol: f32,
) -> Option<(usize, Point, Point, f32)> {
    let atom_count = left.len().min(right.len()) / 3;
    (0..atom_count).find_map(|atom_idx| {
        let i = atom_idx * 3;
        let left_xyz = (left[i], left[i + 1], left[i + 2]);
        let right_xyz = (right[i], right[i + 1], right[i + 2]);
        let max_delta = [
            (left_xyz.0 - right_xyz.0).abs(),
            (left_xyz.1 - right_xyz.1).abs(),
            (left_xyz.2 - right_xyz.2).abs(),
        ]
        .into_iter()
        .fold(0.0f32, f32::max);
        (max_delta > tol).then_some((atom_idx, left_xyz, right_xyz, max_delta))
    })
}

pub fn topology_matches_without_connectivity(
    pdb_topology: &Topology,
    mmcif_topology: &Topology,
    tol: f32,
) -> bool {
    let mut pdb = topology_without_connectivity(pdb_topology);
    let mut mmcif = topology_without_connectivity(mmcif_topology);

    if pdb.geometry.len() != mmcif.geometry.len() {
        return false;
    }

    let pdb_geometry = std::mem::take(&mut pdb.geometry);
    let mmcif_geometry = std::mem::take(&mut mmcif.geometry);
    if pdb != mmcif {
        return false;
    }

    first_coordinate_diff(&pdb_geometry, &mmcif_geometry, tol).is_none()
}

pub fn summarize_topology_mismatch(pdb: &TRC, mmcif: &TRC, tol: f32) -> String {
    let p = &pdb.topology;
    let m = &mmcif.topology;
    let mut details = Vec::new();

    push_scalar_diff(
        &mut details,
        "schema_version",
        &p.schema_version,
        &m.schema_version,
    );
    push_vec_diff(&mut details, "symbols", &p.symbols, &m.symbols);

    if p.geometry.len() != m.geometry.len() {
        details.push(format!(
            "geometry length {} vs {}",
            p.geometry.len(),
            m.geometry.len()
        ));
    }
    if let Some((atom_idx, pdb_xyz, mmcif_xyz, delta)) =
        first_coordinate_diff(&p.geometry, &m.geometry, tol)
    {
        details.push(format!(
            "first coordinate diff at atom {}: ({}, {}, {}) vs ({}, {}, {}) (max |delta|={})",
            atom_idx, pdb_xyz.0, pdb_xyz.1, pdb_xyz.2, mmcif_xyz.0, mmcif_xyz.1, mmcif_xyz.2, delta
        ));
    }

    push_option_vec_diff(&mut details, "labels", &p.labels, &m.labels);
    push_option_vec_diff(
        &mut details,
        "partial_charges",
        &p.partial_charges,
        &m.partial_charges,
    );
    push_option_vec_diff(
        &mut details,
        "formal_charges",
        &p.formal_charges,
        &m.formal_charges,
    );
    push_option_vec_diff(
        &mut details,
        "stereochemistry",
        &p.stereochemistry,
        &m.stereochemistry,
    );
    push_option_vec_diff(&mut details, "velocities", &p.velocities, &m.velocities);
    push_option_vec_diff(&mut details, "fragments", &p.fragments, &m.fragments);
    push_option_vec_diff(
        &mut details,
        "fragment_formal_charges",
        &p.fragment_formal_charges,
        &m.fragment_formal_charges,
    );
    push_option_vec_diff(
        &mut details,
        "fragment_partial_charges",
        &p.fragment_partial_charges,
        &m.fragment_partial_charges,
    );
    push_option_vec_diff(
        &mut details,
        "fragment_multiplicities",
        &p.fragment_multiplicities,
        &m.fragment_multiplicities,
    );

    if details.is_empty() {
        details.push(
            "topology mismatch detected, but no specific field diff was isolated".to_string(),
        );
    }

    details.join(", ")
}

pub fn summarize_residue_mismatch(pdb: &TRC, mmcif: &TRC) -> String {
    let p = &pdb.residues;
    let m = &mmcif.residues;

    if p.residues.len() != m.residues.len() {
        return format!("residue count {} vs {}", p.residues.len(), m.residues.len());
    }

    for i in 0..p.residues.len() {
        if p.seqs[i] != m.seqs[i]
            || p.seq_ns[i] != m.seq_ns[i]
            || p.insertion_codes[i] != m.insertion_codes[i]
            || p.residues[i] != m.residues[i]
        {
            return format!(
                "first residue diff @{}: seq {} vs {}, seq_n {} vs {}, ins {:?} vs {:?}, atom_count {} vs {}",
                i,
                p.seqs[i],
                m.seqs[i],
                p.seq_ns[i],
                m.seq_ns[i],
                p.insertion_codes[i],
                m.insertion_codes[i],
                p.residues[i].len(),
                m.residues[i].len(),
            );
        }
    }

    "unknown residue mismatch".to_string()
}

pub fn summarize_chain_mismatch(pdb: &TRC, mmcif: &TRC) -> String {
    let p = &pdb.chains;
    let m = &mmcif.chains;

    if p.chains.len() != m.chains.len() {
        return format!("chain count {} vs {}", p.chains.len(), m.chains.len());
    }

    for i in 0..p.chains.len() {
        if p.chains[i] != m.chains[i] {
            return format!(
                "first chain diff @{}: residue_refs {} vs {}",
                i,
                p.chains[i].0.len(),
                m.chains[i].0.len(),
            );
        }
    }

    if p.alpha_helices != m.alpha_helices {
        let p_len = p.alpha_helices.as_ref().map_or(0, |a| a.len());
        let m_len = m.alpha_helices.as_ref().map_or(0, |a| a.len());
        return format!(
            "alpha_helices mismatch: pdb has {} helices, mmcif has {}; pdb={:?}, mmcif={:?}",
            p_len, m_len, p.alpha_helices, m.alpha_helices
        );
    }

    if p.beta_sheets != m.beta_sheets {
        let p_len = p.beta_sheets.as_ref().map_or(0, |b| b.len());
        let m_len = m.beta_sheets.as_ref().map_or(0, |b| b.len());
        return format!(
            "beta_sheets mismatch: pdb has {} strands, mmcif has {}; pdb={:?}, mmcif={:?}",
            p_len, m_len, p.beta_sheets, m.beta_sheets
        );
    }

    "unknown chain mismatch".to_string()
}

pub fn missing_pdb_bond_subset_error(pdb: &TRC, mmcif: &TRC) -> Option<String> {
    let (Some(pdb_conn), Some(mmcif_conn)) =
        (&pdb.topology.connectivity, &mmcif.topology.connectivity)
    else {
        return None;
    };

    // For cross-format parity we require PDB bonds to be a subset of mmCIF
    // bonds. Some structures are known exceptions (handled by test cases).
    let mmcif_bond_set: std::collections::HashSet<_> = mmcif_conn.iter().collect();
    let missing: Vec<_> = pdb_conn
        .iter()
        .filter(|bond| !mmcif_bond_set.contains(*bond))
        .collect();

    if missing.is_empty() {
        return None;
    }

    let bond_sample = missing
        .iter()
        .take(3)
        .map(|bond| format!("{bond:?}"))
        .collect::<Vec<_>>()
        .join(", ");

    let mut details = format!(
        "{} of {} PDB bonds are missing in mmCIF (mmCIF has {} total bonds); sample: [{}]",
        missing.len(),
        pdb_conn.len(),
        mmcif_conn.len(),
        bond_sample
    );

    if let Some(labels) = &pdb.topology.labels
        && let Some(first) = missing.first()
    {
        let atom1_idx = first.0.0 as usize;
        let atom2_idx = first.1.0 as usize;
        if atom1_idx < labels.len() && atom2_idx < labels.len() {
            details.push_str(&format!(
                "; first bond labels: {} - {}",
                labels[atom1_idx], labels[atom2_idx]
            ));
        }
    }

    Some(details)
}
