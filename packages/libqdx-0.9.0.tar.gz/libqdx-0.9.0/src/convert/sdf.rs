use std::error;
// SDF parser for V2000 format described in https://discover.3ds.com/sites/default/files/2020-08/biovia_ctfileformats_2020.pdf
use std::io::Write;

use ouroboros::TypeInfo;
#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use crate::constraints::Constraints;
use crate::version::CURRENT_SCHEMA_VERSION;
use crate::{
    AtomRef, Element, FormalCharge, Fragment, Residue, ResidueRef, Residues, Stereochemistry, TRC,
    Topology,
};
use crate::{Chain, Chains, bond};

const CONSTRAINT_GROUPS_KEY: &str = "TETHERED ATOMS";
const SMILES_PATTERN: &str = "SMILES";

#[derive(Debug)]
struct Atom {
    x: f64,
    y: f64,
    z: f64,
    symbol: Element,
    _mass_difference: i32,
    charge: i32,
    _atom_atom_mapping_number: Option<u32>,
}

#[derive(Debug)]
struct Bond {
    atom1: usize,
    atom2: usize,
    bond_type: u32,
    bond_stereo: u32,
}

#[derive(Debug)]
struct Molecule {
    name: String,
    atoms: Vec<Atom>,
    bonds: Vec<Bond>,
    associated_data: Vec<(String, String)>,
}

#[derive(Debug, Copy, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Counts {
    pub num_atoms: usize,
    pub num_bonds: usize,
}

#[derive(Debug, Copy, Clone, PartialEq)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub enum SDFParseState {
    HeaderBlock,
    CountsLine,
    AtomBlock(Counts),
    BondBlock(Counts),
    PropertiesBlock,
    DataItems,
    Done,
}

pub const SDF_BOND_TYPES: [u32; 4] = [1, 2, 3, 4];

impl std::fmt::Display for SDFParseState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        use SDFParseState::*;

        match self {
            HeaderBlock => write!(f, "HeaderBlock"),
            CountsLine => write!(f, "CountsLine"),
            AtomBlock(_) => write!(f, "AtomBlock"),
            BondBlock(_) => write!(f, "BondBlock"),
            PropertiesBlock => write!(f, "PropertiesBlock"),
            DataItems => write!(f, "DataItems"),
            Done => write!(f, "Done"),
        }
    }
}

#[derive(Debug, Copy, Clone)]
pub enum SDFPropertyType {
    Charge,
    Unk, // catch all for properties we don't care about
    End,
}

impl std::fmt::Display for SDFPropertyType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        use SDFPropertyType::*;

        match self {
            Charge => write!(f, "CHG"),
            End => write!(f, "END"),
            Unk => Ok(()),
        }
    }
}

impl std::str::FromStr for SDFPropertyType {
    type Err = ();

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        use SDFPropertyType::*;

        match s {
            "CHG" => Ok(Charge),
            "END" => Ok(End),
            _ => Ok(Unk),
        }
    }
}

#[derive(Debug, Copy, Clone, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub enum SDFParseErrorType {
    HeaderLine,
    ParseSymbol,
    ParseNumAtoms,
    ParseNumBonds,
    ParseX,
    ParseY,
    ParseZ,
    ParseCharge,
    ParseAtomAtomMappingNumber,
    ParseBondAtom1,
    ParseBondAtom2,
    ParseBondType,
    BondTypeNotAllowed,
    ParsePropertyType,
    ParsePropertyCHGCount,
    ParsePropertyCHGIndex,
    ParsePropertyCHGCharge,
    PropertyCHGCount,
    PropertyCHGIndex,
    PropertyCHGCharge,
    ParseDataKey,
    UnsupportedFormat,
    ParseConstraints,
    ParseTerminator,
    LineTooShort,
    NoResults,
}

impl std::fmt::Display for SDFParseErrorType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        use SDFParseErrorType::*;

        match self {
            HeaderLine => write!(f, "missing header line"),
            ParseSymbol => write!(f, "could not parse symbol"),
            ParseNumAtoms => write!(f, "could not parse number of atoms"),
            ParseNumBonds => write!(f, "could not parse number of bonds"),
            ParseX => write!(f, "could not parse x coordinate"),
            ParseY => write!(f, "could not parse y coordinate"),
            ParseZ => write!(f, "could not parse z coordinate"),
            ParseCharge => write!(f, "could not parse charge"),
            ParseAtomAtomMappingNumber => write!(f, "could not parse atom-atom mapping number"),
            ParseBondAtom1 => write!(f, "could not parse first bond atom index"),
            ParseBondAtom2 => write!(f, "could not parse second bond atom index"),
            ParseBondType => write!(f, "could not parse bond type"),
            BondTypeNotAllowed => write!(f, "bond type not part of SDF standard"),
            ParsePropertyType => write!(f, "could not parse property type"),
            ParsePropertyCHGCount => write!(f, "could not parse CHG count"),
            ParsePropertyCHGIndex => write!(f, "could not parse CHG index"),
            ParsePropertyCHGCharge => write!(f, "could not parse CHG charge"),
            PropertyCHGCount => write!(f, "HG count out of range"),
            PropertyCHGIndex => write!(f, "CHG index out of range"),
            PropertyCHGCharge => write!(f, "CHG charge out of range"),
            ParseDataKey => write!(f, "could not parse data item key"),
            UnsupportedFormat => write!(
                f,
                "unsupported format, only V2000 is supported by this parser"
            ),
            ParseConstraints => write!(f, "could not parse constraints"),
            ParseTerminator => write!(f, "could not find correctly formatted terminator"),
            LineTooShort => write!(f, "line shorter than the expcted length"),
            NoResults => write!(f, "there should be at least an error result"),
        }
    }
}

#[derive(Copy, Clone, Debug)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct SDFParseError {
    line_number: usize,
    state: SDFParseState,
    ty: SDFParseErrorType,
}

impl std::fmt::Display for SDFParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "line {} state {}: {}",
            self.line_number, self.state, self.ty
        )
    }
}

impl error::Error for SDFParseError {}

#[derive(Debug, Copy, Clone, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub enum SDFWriteErrorType {
    BadTRC(crate::TRCError),
    FormatCharge,
    TooManyResidues,
    Write,
    UnsupportedBondOrder(bond::BondOrder),
}

impl std::fmt::Display for SDFWriteErrorType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        use SDFWriteErrorType::*;
        match self {
            BadTRC(trc_error) => write!(f, "bad TRC: {trc_error:?}"),
            FormatCharge => write!(f, "could not format charge"),
            TooManyResidues => write!(
                f,
                "only 1 residue expected when doing a single conversion to SDF"
            ),
            Write => write!(f, "error writing"),
            UnsupportedBondOrder(order) => write!(f, "unsupported bond order: {:?}", order),
        }
    }
}

fn charge_field_to_charge(c: i32) -> Option<i32> {
    match c {
        0 => Some(0),
        1 => Some(3),
        2 => Some(2),
        3 => Some(1),
        // TODO: This apparently represents a "doublet radical", but I don't know what we want to
        // do aobut this.
        4 => None,
        5 => Some(-1),
        6 => Some(-2),
        7 => Some(-3),
        _ => None,
    }
}

fn charge_to_charge_field(c: Option<FormalCharge>) -> Result<i32, SDFWriteErrorType> {
    Ok(match c {
        None | Some(FormalCharge(0)) => 0,
        Some(FormalCharge(3)) => 1,
        Some(FormalCharge(2)) => 2,
        Some(FormalCharge(1)) => 3,
        Some(FormalCharge(-1)) => 5,
        Some(FormalCharge(-2)) => 6,
        Some(FormalCharge(-3)) => 7,
        _ => {
            return Err(SDFWriteErrorType::FormatCharge);
        }
    })
}

fn parse_sdf_entry(content: &str) -> Result<Molecule, SDFParseError> {
    use SDFParseErrorType::*;
    use SDFParseState::*;

    let mut state = SDFParseState::HeaderBlock;
    let mut seen_chg_property = false;

    let mut molecule: Molecule = Molecule {
        name: String::new(),
        atoms: Vec::new(),
        bonds: Vec::new(),
        associated_data: Vec::<(String, String)>::new(),
    };

    let mut lines = content.lines().enumerate();

    while let Some((line_number, line)) = lines.next() {
        if line.trim().is_empty() && state != HeaderBlock {
            continue; // Handle empty lines
        }

        let line_number = line_number + 1;

        match state {
            HeaderBlock => {
                molecule.name = line.to_string();

                lines.next().ok_or(SDFParseError {
                    line_number: line_number + 1,
                    state,
                    ty: HeaderLine,
                })?;
                lines.next().ok_or(SDFParseError {
                    line_number: line_number + 2,
                    state,
                    ty: HeaderLine,
                })?;

                state = CountsLine;
            }
            CountsLine => {
                if line.contains("V3000") {
                    return Err(SDFParseError {
                        line_number,
                        state,
                        ty: UnsupportedFormat,
                    });
                }
                let num_atoms: usize = line
                    .get(..3)
                    .ok_or(SDFParseError {
                        line_number,
                        state,
                        ty: LineTooShort,
                    })?
                    .trim()
                    .parse()
                    .map_err(|_| SDFParseError {
                        line_number,
                        state,
                        ty: ParseNumAtoms,
                    })?;
                let num_bonds: usize = line
                    .get(3..6)
                    .ok_or(SDFParseError {
                        line_number,
                        state,
                        ty: LineTooShort,
                    })?
                    .trim()
                    .parse()
                    .map_err(|_| SDFParseError {
                        line_number,
                        state,
                        ty: ParseNumBonds,
                    })?;

                molecule.atoms.reserve(num_atoms);
                molecule.bonds.reserve(num_bonds);

                state = AtomBlock(Counts {
                    num_atoms,
                    num_bonds,
                });
            }
            AtomBlock(counts) => {
                molecule.atoms.push(Atom {
                    x: line
                        .get(..10)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .parse()
                        .map_err(|_| SDFParseError {
                            line_number,
                            state,
                            ty: ParseX,
                        })?,
                    y: line
                        .get(10..20)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .parse()
                        .map_err(|_| SDFParseError {
                            line_number,
                            state,
                            ty: ParseY,
                        })?,
                    z: line
                        .get(20..30)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .parse()
                        .map_err(|_| SDFParseError {
                            line_number,
                            state,
                            ty: ParseZ,
                        })?,
                    symbol: line
                        .get(30..33)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .try_into()
                        .map_err(|_| SDFParseError {
                            line_number,
                            state,
                            ty: ParseSymbol,
                        })?,
                    _mass_difference: line
                        .get(33..35)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .parse()
                        .unwrap_or(0),
                    charge: line
                        .get(36..39)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .parse()
                        .map_err(|_| SDFParseError {
                            line_number,
                            state,
                            ty: ParseZ,
                        })
                        .map(|c| {
                            charge_field_to_charge(c).ok_or(SDFParseError {
                                line_number,
                                state,
                                ty: ParseZ,
                            })
                        })??,
                    _atom_atom_mapping_number: {
                        if line.len() < 57 {
                            None
                        } else {
                            let substr = line
                                .get(56..59)
                                .ok_or(SDFParseError {
                                    line_number,
                                    state,
                                    ty: LineTooShort,
                                })?
                                .trim();
                            if !substr.is_empty() {
                                let index: u32 = substr.parse().map_err(|_| SDFParseError {
                                    line_number,
                                    state,
                                    ty: ParseAtomAtomMappingNumber,
                                })?;
                                if index != 0 {
                                    return Err(SDFParseError {
                                        line_number,
                                        state,
                                        ty: ParseAtomAtomMappingNumber,
                                    });
                                }
                            }

                            None
                        }
                    },
                });

                if molecule.atoms.len() == counts.num_atoms {
                    if counts.num_bonds == 0 {
                        state = PropertiesBlock;
                    } else {
                        state = BondBlock(counts);
                    }
                }
            }
            BondBlock(counts) => {
                let bond_type: u32 = line
                    .get(6..9)
                    .ok_or(SDFParseError {
                        line_number,
                        state,
                        ty: LineTooShort,
                    })?
                    .trim()
                    .parse()
                    .map_err(|_| SDFParseError {
                        line_number,
                        state,
                        ty: ParseBondType,
                    })?;
                if !SDF_BOND_TYPES.contains(&bond_type) {
                    return Err(SDFParseError {
                        line_number,
                        state,
                        ty: BondTypeNotAllowed,
                    });
                }

                molecule.bonds.push(Bond {
                    atom1: line
                        .get(..3)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .parse()
                        .map_err(|_| SDFParseError {
                            line_number,
                            state,
                            ty: ParseBondAtom1,
                        })
                        .map(|index: usize| index - 1)?,
                    atom2: line
                        .get(3..6)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .parse()
                        .map_err(|_| SDFParseError {
                            line_number,
                            state,
                            ty: ParseBondAtom2,
                        })
                        .map(|index: usize| index - 1)?,
                    bond_type: line
                        .get(6..9)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .parse()
                        .map_err(|_| SDFParseError {
                            line_number,
                            state,
                            ty: ParseBondType,
                        })?,
                    bond_stereo: line
                        .get(9..12)
                        .ok_or(SDFParseError {
                            line_number,
                            state,
                            ty: LineTooShort,
                        })?
                        .trim()
                        .parse()
                        .unwrap_or(0),
                });

                if molecule.bonds.len() == counts.num_bonds {
                    state = PropertiesBlock;
                }
            }
            PropertiesBlock => {
                let property_type: SDFPropertyType = line
                    .get(3..6)
                    .ok_or(SDFParseError {
                        line_number,
                        state,
                        ty: LineTooShort,
                    })?
                    .trim()
                    .parse()
                    .map_err(|_| SDFParseError {
                        line_number,
                        state,
                        ty: ParsePropertyType,
                    })?;

                match property_type {
                    SDFPropertyType::Charge => {
                        if !seen_chg_property {
                            molecule.atoms.iter_mut().for_each(|atom| atom.charge = 0);
                            seen_chg_property = true;
                        }
                        // apparently, the count block is 6..9 in some standards, and 6..8 in others
                        // lets determine this by checking if 9 is a space or not
                        let count_end = if line
                            .get(8..9)
                            .ok_or(SDFParseError {
                                line_number,
                                state,
                                ty: LineTooShort,
                            })?
                            .trim()
                            .is_empty()
                        {
                            8
                        } else {
                            9
                        };

                        let count: u32 = line
                            .get(6..count_end)
                            .ok_or(SDFParseError {
                                line_number,
                                state,
                                ty: LineTooShort,
                            })?
                            .trim()
                            .parse()
                            .map_err(|_| SDFParseError {
                                line_number,
                                state,
                                ty: ParsePropertyCHGCount,
                            })?;

                        if count == 0 || count > 8 {
                            return Err(SDFParseError {
                                line_number,
                                state,
                                ty: PropertyCHGCount,
                            });
                        }

                        for i in 0..count {
                            let start = count_end + 8 * i as usize;
                            let end = count_end + 4 + 8 * i as usize;

                            let index: u32 = line
                                .get(start..end)
                                .ok_or(SDFParseError {
                                    line_number,
                                    state,
                                    ty: LineTooShort,
                                })?
                                .trim()
                                .parse()
                                .map_err(|_| SDFParseError {
                                    line_number,
                                    state,
                                    ty: ParsePropertyCHGIndex,
                                })?;

                            let start = count_end + 4 + 8 * i as usize;
                            let end = count_end + 8 + 8 * i as usize;

                            let charge: i32 = line
                                .get(start..end)
                                .ok_or(SDFParseError {
                                    line_number,
                                    state,
                                    ty: LineTooShort,
                                })?
                                .trim()
                                .parse()
                                .map_err(|_| SDFParseError {
                                    line_number,
                                    state,
                                    ty: ParsePropertyCHGCharge,
                                })?;

                            molecule.atoms[index as usize - 1].charge = charge;
                        }
                    }
                    SDFPropertyType::End => state = DataItems,
                    // don't do anything for other properties
                    _ => {}
                }
            }
            DataItems => {
                if line == "$$$$" {
                    break;
                } else {
                    if !line.starts_with('>') {
                        return Err(SDFParseError {
                            line_number,
                            state,
                            ty: ParseDataKey,
                        });
                    }

                    // Associated data entry.
                    let start = line.find('<').ok_or(SDFParseError {
                        line_number,
                        state,
                        ty: ParseDataKey,
                    })?;
                    let offset = line[start..].find('>').ok_or(SDFParseError {
                        line_number,
                        state,
                        ty: ParseDataKey,
                    })?;

                    let key = line[start + 1..start + offset].to_string();
                    let mut data = String::new();
                    for (_, line) in &mut lines {
                        if line.trim().is_empty() {
                            // Kind of hacky. We have been appending \n to each line but we don't want to append one to the last line in the data.
                            if !data.is_empty() {
                                _ = data.pop();
                            }
                            break;
                        }

                        data.push_str(line);
                        data.push('\n');
                    }
                    molecule.associated_data.push((key, data));
                }
            }
            Done => unreachable!(),
        }
    }
    Ok(molecule)
}

fn sdf_entries(content: &str) -> Vec<Result<(usize, &str), SDFParseError>> {
    let mut entries = Vec::new();
    let mut tail = content;
    let mut current_line_number = 1;
    loop {
        if let Some(just_before_last_line) = tail.find("\n$$$$") {
            let offset_after_terminator = just_before_last_line + 5;
            if tail.len() == offset_after_terminator {
                entries.push(Ok((current_line_number, tail)));
                break;
            } else if tail.as_bytes()[offset_after_terminator] != b'\n' {
                entries.push(Err(SDFParseError {
                    line_number: current_line_number,
                    state: SDFParseState::HeaderBlock,
                    ty: SDFParseErrorType::ParseTerminator,
                }));
                break;
            } else {
                let (entry, new_tail) = tail.split_at(just_before_last_line + 6);
                tail = new_tail;
                entries.push(Ok((current_line_number, entry)));
                current_line_number += entry.lines().count();
                if tail.is_empty() {
                    break;
                }
            }
        } else {
            entries.push(Err(SDFParseError {
                line_number: current_line_number,
                state: SDFParseState::HeaderBlock,
                ty: SDFParseErrorType::ParseTerminator,
            }));
            break;
        }
    }

    entries
}

fn parse_sdf(content: &str) -> Result<Vec<Molecule>, SDFParseError> {
    let entries = sdf_entries(content);

    let Some(last_entry) = entries.last() else {
        return Err(SDFParseError {
            line_number: 0,
            state: SDFParseState::Done,
            ty: SDFParseErrorType::NoResults,
        });
    };

    if let Err(e) = last_entry {
        return Err(*e);
    }

    let mut molecules = Vec::new();
    for (line_number, entry) in entries.into_iter().map(Result::unwrap) {
        molecules.push(parse_sdf_entry(entry).map_err(|mut e| {
            e.line_number += line_number - 1;
            e
        })?);
    }

    Ok(molecules)
}

fn parse_sdf_lossy(content: &str) -> Vec<Result<Molecule, SDFParseError>> {
    let mut entries: Vec<Result<(usize, &str), SDFParseError>> = sdf_entries(content);

    let Some(last_entry) = entries.last() else {
        return vec![Err(SDFParseError {
            line_number: 0,
            state: SDFParseState::Done,
            ty: SDFParseErrorType::NoResults,
        })];
    };

    let (ok_entries, err_entry) = if last_entry.is_err() {
        let err_entry = entries.pop();
        (entries, err_entry)
    } else {
        (entries, None)
    };

    let mut results: Vec<Result<Molecule, SDFParseError>> = ok_entries
        .into_iter()
        .map(Result::unwrap)
        .map(|(line_number, entry)| {
            parse_sdf_entry(entry).map_err(|mut e| {
                e.line_number += line_number - 1;
                e
            })
        })
        .collect();

    if let Some(Err(e)) = err_entry {
        results.push(Err(e));
    }

    results
}

fn bond_order_from_sdf(order: u32) -> Result<bond::BondOrder, ConversionError> {
    match order {
        1 => Ok(bond::BondOrder::Single),
        2 => Ok(bond::BondOrder::Double),
        3 => Ok(bond::BondOrder::Triple),
        4 => Ok(bond::BondOrder::Ring),
        _ => Err(ConversionError::UnexpectedBondOrder(order)),
    }
}

fn bond_order_to_sdf(order: bond::BondOrder) -> Result<u32, SDFWriteErrorType> {
    match order {
        bond::BondOrder::Single => Ok(1),
        bond::BondOrder::Double => Ok(2),
        bond::BondOrder::Triple => Ok(3),
        bond::BondOrder::Ring => Ok(4),
        _ => Err(SDFWriteErrorType::UnsupportedBondOrder(order)),
    }
}

fn stereochemistry_from_sdf(value: u32) -> Result<bond::Stereochemistry, ConversionError> {
    match value {
        0 => Ok(bond::Stereochemistry::NONE),
        1 => Ok(bond::Stereochemistry::Up),
        3 => Ok(bond::Stereochemistry::CisOrTrans),
        4 => Ok(bond::Stereochemistry::Either),
        6 => Ok(bond::Stereochemistry::Down),
        _ => Err(ConversionError::UnexpectedStereochemistryValue(value)),
    }
}

fn stereochemistry_to_sdf(kind: bond::Stereochemistry) -> u32 {
    match kind {
        bond::Stereochemistry::NONE => 0,
        bond::Stereochemistry::Up => 1,
        bond::Stereochemistry::CisOrTrans => 3,
        bond::Stereochemistry::Either => 4,
        bond::Stereochemistry::Down => 6,
    }
}

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Debug, Clone, TypeInfo)]
pub struct DataBlocks {
    pub constraints: Constraints,
    pub smiles: Option<String>,
    pub unspecified: Vec<(String, String)>,
}

#[derive(Debug, Clone, Copy, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub enum ConversionError {
    #[error("error parsing SDF: {0}")]
    Parse(SDFParseError),
    #[error("error parsing constraints")]
    Constraints,
    #[error(transparent)]
    TRError(#[from] crate::TRCError),
    #[error("Unexpected bond order {0}")]
    UnexpectedBondOrder(u32),
    #[error("Unexpected stereochemistry value {0}")]
    UnexpectedStereochemistryValue(u32),
}

impl TryInto<(TRC, Option<DataBlocks>)> for Molecule {
    type Error = ConversionError;

    fn try_into(mut self) -> Result<(TRC, Option<DataBlocks>), Self::Error> {
        let labeled = Some(vec![ResidueRef(0)]);
        let labels = Some(vec![vec![self.name]]);
        let residues = vec![Residue(
            self.atoms
                .iter()
                .enumerate()
                .map(|(i, _)| AtomRef(i as u32))
                .collect(),
        )];
        let seqs = vec!["LIG".to_string()];
        let seq_ns = vec![0];
        let insertion_codes = vec!["".to_string()];

        let residues = Residues {
            labeled,
            labels,
            residues,
            seqs,
            seq_ns,
            insertion_codes,
        };

        let schema_version = CURRENT_SCHEMA_VERSION;
        let symbols = self.atoms.iter().map(|atom| atom.symbol).collect();
        let geometry = self
            .atoms
            .iter()
            .flat_map(|atom| [atom.x as f32, atom.y as f32, atom.z as f32])
            .collect();
        let labels = None;
        let partial_charges = None;
        let formal_charges = Some(
            self.atoms
                .iter()
                .map(|atom| FormalCharge(atom.charge))
                .collect(),
        );
        let connectivity = Some(
            self.bonds
                .iter()
                .map(|bond| {
                    Ok(bond::Bond(
                        AtomRef(bond.atom1 as u32),
                        AtomRef(bond.atom2 as u32),
                        bond_order_from_sdf(bond.bond_type)?,
                    ))
                })
                .collect::<Result<Vec<bond::Bond>, ConversionError>>()?,
        );
        let stereochemistry = Some(
            self.bonds
                .iter()
                .map(|bond| stereochemistry_from_sdf(bond.bond_stereo))
                .collect::<Result<Vec<Stereochemistry>, ConversionError>>()?,
        );
        let velocities = None;
        let fragments = Some(
            residues
                .residues
                .iter()
                .map(|res| Fragment(res.0.clone()))
                .collect(),
        );
        let fragment_formal_charges = Some(vec![FormalCharge(
            self.atoms
                .iter()
                .fold(0, |charge, atom| charge + atom.charge),
        )]);
        let fragment_partial_charges = None;
        let fragment_multiplicities = None;

        let topology = Topology {
            schema_version,
            symbols,
            geometry,
            labels,
            partial_charges,
            formal_charges,
            connectivity,
            stereochemistry,
            velocities,
            fragments,
            fragment_formal_charges,
            fragment_partial_charges,
            fragment_multiplicities,
        };

        let chains = Chains {
            chains: vec![Chain(
                residues
                    .residues
                    .iter()
                    .enumerate()
                    .map(|(i, _)| ResidueRef(i as u32))
                    .collect(),
            )],
            alpha_helices: None,
            beta_sheets: None,
            labels: None,
            labeled: None,
        };

        let trc = TRC {
            topology,
            residues,
            chains,
        };
        trc.check()?;

        let constraint_groups = if let Some(data_index) = self
            .associated_data
            .iter()
            .position(|(k, _)| k == CONSTRAINT_GROUPS_KEY)
        {
            let (_, data) = self.associated_data.remove(data_index);
            let mut groups = Vec::with_capacity(data.len());
            let lines = data.split('\n');
            for line in lines {
                let mut constraint = Vec::new();
                for n in line.split(',') {
                    constraint.push(n.parse::<u32>().map_err(|_| ConversionError::Constraints)?);
                }
                groups.push(constraint);
            }
            groups
        } else {
            Vec::new()
        };

        let constraints = Constraints { constraint_groups };

        let smiles = if let Some(smiles_index) = self
            .associated_data
            .iter()
            .position(|(key, _)| key.contains(SMILES_PATTERN))
        {
            Some(self.associated_data.remove(smiles_index).1)
        } else {
            None
        };

        let unspecified: Vec<_> = self.associated_data.to_vec();

        let db = if unspecified.is_empty() && constraints.constraint_groups.is_empty() {
            None
        } else {
            Some(DataBlocks {
                constraints,
                smiles,
                unspecified,
            })
        };

        Ok((trc, db))
    }
}

/// Converts the SDF contents into libqdx types. If any error is encountered during this process, it will immediately return an error result.
pub fn from_sdf(content: &str) -> Result<(Vec<TRC>, Vec<Option<DataBlocks>>), ConversionError> {
    let mut trcs = Vec::new();
    let mut dbs = Vec::new();

    let molecules = parse_sdf(content).map_err(ConversionError::Parse)?;
    for molecule in molecules {
        let (trc, db) = molecule.try_into()?;
        trcs.push(trc);
        dbs.push(db);
    }

    Ok((trcs, dbs))
}

/// Converts the SDF contents into libqdx types, preserving SDF entries that can
/// be successfully converted. Will return a vector of results where a given
/// result will be an error if the corresponding SDF entry could not be
/// converted. If there is an error finding the '$$$$' terminator for an entry
/// then an error will be appended to the vector and conversion will exit, which
/// can cause the length of the results vector to be shorter than might be
/// expected.
pub fn from_sdf_lossy(content: &str) -> Vec<Result<(TRC, Option<DataBlocks>), ConversionError>> {
    parse_sdf_lossy(content)
        .into_iter()
        .map(|r| match r {
            Ok(molecule) => molecule.try_into(),
            Err(e) => Err(ConversionError::Parse(e)),
        })
        .collect()
}

pub fn to_sdf<T: Write>(
    trcs: &[TRC],
    data_blocks: &[Option<DataBlocks>],
    mut buffer: T,
) -> Result<(), SDFWriteErrorType> {
    for (tr, data_blocks) in trcs.iter().zip(data_blocks.iter()) {
        tr.check().map_err(SDFWriteErrorType::BadTRC)?;
        let title = if let Some(ref labels) = tr.residues.labels {
            if labels.len() > 1 {
                return Err(SDFWriteErrorType::TooManyResidues);
            }
            if labels.is_empty() {
                "".to_string()
            } else {
                labels[0][0].clone()
            }
        } else {
            "".to_string()
        };
        buffer
            .write(format!("{}\n", title).as_bytes())
            .map_err(|_| SDFWriteErrorType::Write)?;
        buffer
            .write("     QDXF           3D\n".as_bytes())
            .map_err(|_| SDFWriteErrorType::Write)?;
        buffer
            .write("\n".as_bytes())
            .map_err(|_| SDFWriteErrorType::Write)?;

        let atom_count = tr.topology.symbols.len();
        let bond_count = tr
            .topology
            .connectivity
            .as_ref()
            .map(|bonds| bonds.len())
            .unwrap_or(0);
        let atom_list_count = 0;
        let chiral_flag = 0;
        buffer
            .write(
                format!(
                    "{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>6}\n",
                    atom_count,
                    bond_count,
                    atom_list_count,
                    0,
                    chiral_flag,
                    0,
                    0,
                    0,
                    0,
                    0,
                    999,
                    "V2000",
                )
                .as_bytes(),
            )
            .map_err(|_| SDFWriteErrorType::Write)?;

        let max_absolute_charge = tr
            .topology
            .formal_charges
            .as_ref()
            .map(|charges| charges.iter().map(|c| c.0.abs()).max().unwrap_or(0))
            .unwrap_or(0);

        if max_absolute_charge > 15 {
            return Err(SDFWriteErrorType::FormatCharge);
        }

        let use_chg_lines = max_absolute_charge > 3;

        for (j, atom) in tr.topology.symbols.iter().enumerate() {
            let x = tr.topology.geometry[3 * j];
            let y = tr.topology.geometry[3 * j + 1];
            let z = tr.topology.geometry[3 * j + 2];
            let mass_difference = 0;
            let charge = if use_chg_lines {
                0
            } else {
                charge_to_charge_field(tr.topology.formal_charges.as_ref().map(|x| x[j]))?
            };
            let atom_stereo_parity = 0;
            let hydrogen_count_plus_one = 0;
            let stereo_care_box = 0;
            let valence = 0;
            let h0_designator = 0;
            let atom_atom_mapping_number = 0;
            let inversion_retention_flag = 0;
            let exact_change_flag = 0;
            buffer.write(format!(
                "{:>10.4}{:>10.4}{:>10.4} {:<3}{:>2}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}{:>3}\n",
                x,
                y,
                z,
                format!("{}", atom),
                mass_difference,
                charge,
                atom_stereo_parity,
                hydrogen_count_plus_one,
                stereo_care_box,
                valence,
                h0_designator,
                0,
                0,
                atom_atom_mapping_number,
                inversion_retention_flag,
                exact_change_flag,
            ).as_bytes()).map_err(|_| SDFWriteErrorType::Write)?;
        }

        if let Some(connectivity) = &tr.topology.connectivity {
            for (i, bond) in connectivity.iter().enumerate() {
                let stereo = (tr.topology.stereochemistry)
                    .as_ref()
                    .map_or(Stereochemistry::NONE, |stereos| stereos[i]); // ok b/c check()
                let first_atom = bond.0.0 + 1;
                let second_atom = bond.1.0 + 1;
                let bond_type = bond_order_to_sdf(bond.2)?;
                let bond_stereo = stereochemistry_to_sdf(stereo);
                let bond_topology = 0;
                let reacting_center_status = 0;
                buffer
                    .write(
                        format!(
                            "{:>3}{:>3}{:>3}{:>3}   {:>3}{:>3}\n",
                            first_atom,
                            second_atom,
                            bond_type,
                            bond_stereo,
                            bond_topology,
                            reacting_center_status,
                        )
                        .as_bytes(),
                    )
                    .map_err(|_| SDFWriteErrorType::Write)?;
            }
        }
        // do charge properties
        // After the M  CHG, the first number defines the number of charges defined on this line (up to 8).
        // If the compound has more than this, they can go on additional M  CHG lines.
        // Each charge entry consists of two four-character fields -
        // the first is the index of the charged atom (starting from one), and the second is the charge.
        // The below means "add a charge to the first atom of +2".
        // M  CHG  1   1   2
        if use_chg_lines {
            let chg_lines = tr.topology.formal_charges.as_ref().map(|x| {
                x.chunks(8)
                    .enumerate()
                    .map(|(i, x)| {
                        let mut s = format!("M  CHG{:>3}", x.len());
                        for (j, charge) in x.iter().enumerate() {
                            s.push_str(&format!(" {:>3} {:>3}", (i * 8) + j + 1, charge.0));
                        }
                        s
                    })
                    .collect::<Vec<_>>()
            });
            if let Some(chg_lines) = chg_lines {
                for chg_line in chg_lines {
                    buffer
                        .write(format!("{}\n", chg_line).as_bytes())
                        .map_err(|_| SDFWriteErrorType::Write)?;
                }
            }
        }

        buffer
            .write("M  END\n".as_bytes())
            .map_err(|_| SDFWriteErrorType::Write)?;

        if let Some(data_blocks) = data_blocks {
            if !data_blocks.constraints.constraint_groups.is_empty() {
                buffer
                    .write(format!("> <{}>\n", CONSTRAINT_GROUPS_KEY).as_bytes())
                    .map_err(|_| SDFWriteErrorType::Write)?;
                for constraint_group in data_blocks.constraints.constraint_groups.iter() {
                    buffer
                        .write(
                            constraint_group
                                .iter()
                                .map(u32::to_string)
                                .collect::<Vec<String>>()
                                .join(",")
                                .as_bytes(),
                        )
                        .map_err(|_| SDFWriteErrorType::Write)?;
                    buffer
                        .write("\n".as_bytes())
                        .map_err(|_| SDFWriteErrorType::Write)?;
                }
                buffer
                    .write("\n".as_bytes())
                    .map_err(|_| SDFWriteErrorType::Write)?;
            }

            for (key, data) in data_blocks.unspecified.iter() {
                buffer
                    .write(format!("> <{}>\n{}\n\n", key, data).as_bytes())
                    .map_err(|_| SDFWriteErrorType::Write)?;
            }
        }

        buffer
            .write("$$$$\n".as_bytes())
            .map_err(|_| SDFWriteErrorType::Write)?;
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::{SDFParseError, SDFParseErrorType, from_sdf, parse_sdf, to_sdf};
    use crate::{
        bond::Stereochemistry,
        convert::sdf::{CONSTRAINT_GROUPS_KEY, from_sdf_lossy},
        element::Element,
    };

    use std::{
        error, fs, io,
        path::{Path, PathBuf},
    };

    pub fn load_sdf(filepath_stem: impl AsRef<Path> + Clone) -> io::Result<String> {
        let manifest_path = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let mut data_path = manifest_path.join("tests/data/sdf");
        data_path.push(filepath_stem);
        fs::read_to_string(data_path)
    }

    #[test]
    fn test_v3000_errors_as_unsupported() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("v3000.sdf")?;
        assert!(matches!(
            parse_sdf(&input_contents),
            Err(SDFParseError {
                line_number: _,
                state: _,
                ty: SDFParseErrorType::UnsupportedFormat
            })
        ));
        Ok(())
    }

    #[test]
    fn parse_basic_ligand_1() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("ligand_1a30.sdf")?;

        let molecules = parse_sdf(&input_contents)?;

        assert_eq!(molecules.len(), 1);

        let molecule = &molecules[0];

        assert_eq!(molecule.atoms.len(), 49);
        assert_eq!(molecule.bonds.len(), 48);

        assert_eq!(molecule.atoms[0].x, 4.8410);
        assert_eq!(molecule.atoms[0].y, 27.5760);
        assert_eq!(molecule.atoms[0].z, 5.3100);
        assert_eq!(molecule.atoms[0].symbol, Element::N);
        assert_eq!(molecule.atoms[0]._mass_difference, 0);
        assert_eq!(molecule.atoms[0].charge, 1);

        assert_eq!(molecule.atoms[20].x, 13.7840);
        assert_eq!(molecule.atoms[20].y, 23.4420);
        assert_eq!(molecule.atoms[20].z, 4.1920);
        assert_eq!(molecule.atoms[20].symbol, Element::O);
        assert_eq!(molecule.atoms[20]._mass_difference, 0);
        assert_eq!(molecule.atoms[20].charge, 0);

        assert_eq!(molecule.atoms[48].x, 8.4734);
        assert_eq!(molecule.atoms[48].y, 21.6232);
        assert_eq!(molecule.atoms[48].z, 2.6515);
        assert_eq!(molecule.atoms[48].symbol, Element::H);
        assert_eq!(molecule.atoms[48]._mass_difference, 0);
        assert_eq!(molecule.atoms[48].charge, 0);

        assert_eq!(molecule.bonds[0].atom1, 2);
        assert_eq!(molecule.bonds[0].atom2, 1);
        assert_eq!(molecule.bonds[0].bond_type, 1);
        assert_eq!(molecule.bonds[0].bond_stereo, 0);

        assert_eq!(molecule.bonds[18].atom1, 21);
        assert_eq!(molecule.bonds[18].atom2, 22);
        assert_eq!(molecule.bonds[18].bond_type, 1);
        assert_eq!(molecule.bonds[18].bond_stereo, 0);

        assert_eq!(molecule.bonds[47].atom1, 24);
        assert_eq!(molecule.bonds[47].atom2, 48);
        assert_eq!(molecule.bonds[47].bond_type, 1);
        assert_eq!(molecule.bonds[47].bond_stereo, 0);

        assert_eq!(molecule.associated_data.len(), 5);

        let (ref key, ref data) = molecule.associated_data[0];
        assert_eq!(key, "MOLECULAR_FORMULA");
        assert_eq!(data, "C15H23N3O8");

        let (ref key, ref data) = molecule.associated_data[1];
        assert_eq!(key, "MOLECULAR_WEIGHT");
        assert_eq!(data, "373.2");

        let (ref key, ref data) = molecule.associated_data[2];
        assert_eq!(key, "NUM_HB_ATOMS");
        assert_eq!(data, "11");

        let (ref key, ref data) = molecule.associated_data[3];
        assert_eq!(key, "NUM_ROTOR");
        assert_eq!(data, "9");

        let (ref key, ref data) = molecule.associated_data[4];
        assert_eq!(key, "XLOGP2");
        assert_eq!(data, "-2.04");

        Ok(())
    }

    #[test]
    fn parse_basic_ligand_2() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("rank_1.sdf")?;

        let molecules = parse_sdf(&input_contents)?;

        assert_eq!(molecules.len(), 1);

        let molecule = &molecules[0];

        assert_eq!(molecule.atoms.len(), 26);
        assert_eq!(molecule.bonds.len(), 25);

        assert_eq!(molecule.atoms[0].x, 4.5505);
        assert_eq!(molecule.atoms[0].y, 28.0991);
        assert_eq!(molecule.atoms[0].z, 4.6360);
        assert_eq!(molecule.atoms[0].symbol, Element::N);
        assert_eq!(molecule.atoms[0]._mass_difference, 0);
        assert_eq!(molecule.atoms[0].charge, 1);

        assert_eq!(molecule.atoms[20].x, 13.0946);
        assert_eq!(molecule.atoms[20].y, 23.4684);
        assert_eq!(molecule.atoms[20].z, 4.2770);
        assert_eq!(molecule.atoms[20].symbol, Element::O);
        assert_eq!(molecule.atoms[20]._mass_difference, 0);
        assert_eq!(molecule.atoms[20].charge, -1);

        assert_eq!(molecule.bonds[0].atom1, 2);
        assert_eq!(molecule.bonds[0].atom2, 1);
        assert_eq!(molecule.bonds[0].bond_type, 1);
        assert_eq!(molecule.bonds[0].bond_stereo, 0);

        assert_eq!(molecule.bonds[18].atom1, 21);
        assert_eq!(molecule.bonds[18].atom2, 22);
        assert_eq!(molecule.bonds[18].bond_type, 1);
        assert_eq!(molecule.bonds[18].bond_stereo, 0);

        assert_eq!(molecule.associated_data.len(), 1);

        let (ref key, ref data) = molecule.associated_data[0];
        assert_eq!(key, "_TriposChargeType");
        assert_eq!(data, "MMFF94_CHARGES");

        Ok(())
    }

    #[test]
    fn from_to_rank1() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("rank_1.sdf")?;

        let (tr1, data_blocks1) = from_sdf(&input_contents)?;
        let mut sdf1 = Vec::<u8>::new();
        to_sdf(&tr1, &data_blocks1, &mut sdf1)?;
        let sdf1_string = String::from_utf8(sdf1)?;

        let (tr2, data_blocks2) = from_sdf(&sdf1_string)?;
        assert_eq!(tr1, tr2);
        let mut sdf2 = Vec::<u8>::new();
        to_sdf(&tr2, &data_blocks2, &mut sdf2)?;
        let sdf2_string = String::from_utf8(sdf2)?;

        assert_eq!(sdf1_string, sdf2_string);

        Ok(())
    }

    #[test]
    fn from_to_alt_charge_format() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("alt_charge.sdf")?;

        let (tr1, data_blocks1) = from_sdf(&input_contents)?;
        let mut sdf1 = Vec::<u8>::new();
        to_sdf(&tr1, &data_blocks1, &mut sdf1)?;
        let sdf1_string = String::from_utf8(sdf1)?;

        let (tr2, data_blocks2) = from_sdf(&sdf1_string)?;
        let mut sdf2 = Vec::<u8>::new();
        assert_eq!(tr1, tr2);
        to_sdf(&tr2, &data_blocks2, &mut sdf2)?;
        let sdf2_string = String::from_utf8(sdf2)?;

        assert_eq!(sdf1_string, sdf2_string);

        Ok(())
    }

    #[test]
    fn parse_stereochemistry() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("alt_charge.sdf")?;

        let (tr1, data_blocks1) = from_sdf(&input_contents)?;
        assert_eq!(
            tr1[0].topology.stereochemistry,
            Some(vec![
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::Down,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::Up,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::Down,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::Up,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE,
                Stereochemistry::NONE
            ])
        );
        let mut sdf1 = Vec::<u8>::new();
        to_sdf(&tr1, &data_blocks1, &mut sdf1)?;
        let sdf1_string = String::from_utf8(sdf1)?;

        let (tr2, data_blocks2) = from_sdf(&sdf1_string)?;
        let mut sdf2 = Vec::<u8>::new();
        assert_eq!(tr1, tr2);
        to_sdf(&tr2, &data_blocks2, &mut sdf2)?;
        let sdf2_string = String::from_utf8(sdf2)?;

        assert_eq!(sdf1_string, sdf2_string);

        Ok(())
    }

    #[test]
    fn from_to_1a30() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("ligand_1a30.sdf")?;

        let (tr1, data_blocks1) = from_sdf(&input_contents)?;
        let mut sdf1 = Vec::<u8>::new();
        to_sdf(&tr1, &data_blocks1, &mut sdf1)?;
        let sdf1_string = String::from_utf8(sdf1)?;

        let (tr2, data_blocks2) = from_sdf(&sdf1_string)?;
        let mut sdf2 = Vec::<u8>::new();
        assert_eq!(tr1, tr2);
        to_sdf(&tr2, &data_blocks2, &mut sdf2)?;
        let sdf2_string = String::from_utf8(sdf2)?;

        assert_eq!(sdf1_string, sdf2_string);

        Ok(())
    }

    #[test]
    fn to_constraints() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("constraints.sdf")?;

        let (tr, data_blocks) = from_sdf(&input_contents)?;
        let mut sdf = Vec::<u8>::new();
        to_sdf(&tr, &data_blocks, &mut sdf)?;
        let sdf_string = String::from_utf8(sdf)?;

        assert!(
            sdf_string
                .contains(format!("> <{}>\n11,3,2,1,10,5,4\n", CONSTRAINT_GROUPS_KEY).as_str())
        );

        Ok(())
    }

    #[test]
    fn isopropyl() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("isopropyl.sdf")?;

        let (molecules, _) = from_sdf(&input_contents)?;

        assert_eq!(molecules.len(), 1);
        assert_eq!(molecules[0].topology.symbols.len(), 12);
        assert_eq!(molecules[0].topology.geometry.len(), 36);
        assert_eq!(
            molecules[0].topology.connectivity.as_ref().unwrap().len(),
            11
        );

        Ok(())
    }

    #[test]
    fn dg() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("dg.sdf")?;

        let (molecules, _) = from_sdf(&input_contents)?;

        assert_eq!(molecules.len(), 1);
        assert_eq!(molecules[0].topology.symbols.len(), 37);
        assert_eq!(molecules[0].topology.geometry.len(), 111);
        assert_eq!(
            molecules[0].topology.connectivity.as_ref().unwrap().len(),
            39
        );

        Ok(())
    }

    #[test]
    fn auto3d() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("auto3d_out.sdf")?;

        let (molecules, _) = from_sdf(&input_contents)?;

        assert_eq!(molecules.len(), 43);
        assert_eq!(molecules[0].topology.symbols.len(), 6);
        assert_eq!(molecules[0].topology.geometry.len(), 18);
        assert_eq!(
            molecules[0].topology.connectivity.as_ref().unwrap().len(),
            5
        );

        Ok(())
    }

    #[test]
    fn multiple_entries() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("multiple_entries.sdf")?;

        let (trs, data_blocks) = from_sdf(&input_contents)?;

        assert_eq!(trs.len(), 10);
        for molecule in trs.iter() {
            assert_eq!(molecule.topology.symbols.len(), 77);
            assert_eq!(molecule.topology.geometry.len(), 231);
            assert_eq!(molecule.topology.connectivity.as_ref().unwrap().len(), 82);
        }

        let mut sdf = Vec::<u8>::new();
        to_sdf(&trs, &data_blocks, &mut sdf)?;
        let (trs_reparsed, _) = from_sdf(&String::from_utf8(sdf.clone()).unwrap())?;

        for (reference, just_parsed) in trs.iter().zip(trs_reparsed.iter()) {
            assert_eq!(reference, just_parsed);
        }

        Ok(())
    }

    #[test]
    fn lossy_conversion() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("multiple_entries_errs.sdf")?;

        let results = from_sdf_lossy(&input_contents);
        assert!(results[1].is_err());
        assert!(results[3].is_err());
        assert!(results[5].is_err());

        Ok(())
    }

    #[test]
    fn constraints() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("constraints.sdf")?;

        let (molecules, data_blocks) = from_sdf(&input_contents)?;

        assert_eq!(molecules.len(), 1);
        assert_eq!(molecules[0].topology.symbols.len(), 40);
        assert_eq!(molecules[0].topology.geometry.len(), 120);
        assert_eq!(
            molecules[0].topology.connectivity.as_ref().unwrap().len(),
            43
        );

        assert_eq!(data_blocks.len(), 1);
        let db = data_blocks[0].as_ref().unwrap();
        assert_eq!(db.unspecified.len(), 15);
        assert_eq!(db.constraints.constraint_groups.len(), 1);
        assert_eq!(
            db.constraints.constraint_groups[0],
            vec![11, 3, 2, 1, 10, 5, 4]
        );

        Ok(())
    }

    #[test]
    fn rdkit() -> Result<(), Box<dyn error::Error>> {
        let input_contents = load_sdf("rdkit.sdf")?;

        let molecules = parse_sdf(&input_contents)?;

        assert_eq!(molecules.len(), 1);

        let molecule = &molecules[0];

        assert_eq!(molecule.atoms.len(), 93);
        assert_eq!(molecule.bonds.len(), 98);

        assert_eq!(molecule.associated_data.len(), 4);

        let (ref key, ref data) = molecule.associated_data[0];
        assert_eq!(key, "UniqueID");
        assert_eq!(data, "1");

        let (ref key, ref data) = molecule.associated_data[1];
        assert_eq!(key, "SMILES");
        assert_eq!(
            data,
            "CNC(=O)c1nnc(NC(=O)C2CC2)cc1Nc1cccc([N@H+]2CC[N@@H+](C(=O)N(C)Cc3cnn(C)c3)C[C@@H]2Cc2ccccc2)c1OC"
        );

        let (ref key, ref data) = molecule.associated_data[2];
        assert_eq!(key, "Energy");
        assert_eq!(data, "435.6159624655418");

        let (ref key, ref data) = molecule.associated_data[3];
        assert_eq!(key, "Genealogy");
        assert_eq!(
            data,
            "CNC(=O)c1nnc(NC(=O)C2CC2)cc1Nc1cccc([NH+]2CC[NH+](C(=O)N(C)Cc3cnn(C)c3)C[C@@H]2Cc2ccccc2)c1OC (protonated)\n\
        CNC(=O)c1nnc(NC(=O)C2CC2)cc1Nc1cccc([N@H+]2CC[N@@H+](C(=O)N(C)Cc3cnn(C)c3)C[C@@H]2Cc2ccccc2)c1OC (chirality)\n\
        CNC(=O)c1nnc(NC(=O)C2CC2)cc1Nc1cccc([N@H+]2CC[N@@H+](C(=O)N(C)Cc3cnn(C)c3)C[C@@H]2Cc2ccccc2)c1OC (3D coordinates assigned)\n\
        CNC(=O)c1nnc(NC(=O)C2CC2)cc1Nc1cccc([N@H+]2CC[N@@H+](C(=O)N(C)Cc3cnn(C)c3)C[C@@H]2Cc2ccccc2)c1OC (nonaromatic ring conformer: 435.6159624655418 kcal/mol)"
        );

        let (_, data_blocks) = from_sdf(&input_contents)?;
        assert_eq!(data_blocks[0].clone().map(|x| x.smiles),
Some(Some("CNC(=O)c1nnc(NC(=O)C2CC2)cc1Nc1cccc([N@H+]2CC[N@@H+](C(=O)N(C)Cc3cnn(C)c3)C[C@@H]2Cc2ccccc2)c1OC".into()))
        );

        Ok(())
    }

    #[test]
    fn test_element_space_padding() -> Result<(), Box<dyn error::Error>> {
        let s1 = &format!("{:>3}", format!("{}", Element::O));
        let s2 = &format!("{:<3}", format!("{}", Element::O));

        assert_eq!(s1, "  O");
        assert_eq!(s2, "O  ");

        Ok(())
    }
}
