use std::io::{self, BufRead, Write};

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use crate::{Topology, version::SchemaVersion};

#[derive(thiserror::Error, Clone, Debug)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub enum Error {
    #[error("missing atom count")]
    MissingAtomCount,
    #[error("parsing atom count: {0}")]
    ParsingAtomCount(String),
    #[error("missing comment: {0}")]
    MissingComment(String),
    #[error("missing atom line")]
    MissingAtomLine,
    #[error("parsing atom line: {0}")]
    ParsingAtomLine(String),
}

/// Converts a string in XYZ format to a `Topology` struct.
///
/// # Arguments
///
/// * `xyz` - A string slice containing the XYZ formatted data.
///
/// # Returns
///
/// * `Result<Topology, Error>` - A `Result` containing the `Topology`
///   struct or an error.
pub fn from_xyz(xyz: &str) -> Result<Topology, Error> {
    let mut cursor = io::Cursor::new(xyz);
    read_xyz(&mut cursor)
}

/// Reads topology data from a buffered reader in XYZ format.
///
/// # Arguments
///
/// * `r` - A mutable reference to an object that implements the `BufRead`
///   trait.
///
/// # Returns
///
/// * `Result<Topology, Error>` - A `Result` containing the `Topology`
///   struct or an error.
pub fn read_xyz(r: &mut impl BufRead) -> Result<Topology, Error> {
    let mut line = String::new();
    r.read_line(&mut line)
        .map_err(|e| Error::ParsingAtomCount(e.to_string()))?;
    let n_atoms = line
        .trim()
        .parse::<usize>()
        .map_err(|e| Error::ParsingAtomCount(e.to_string()))?;

    line.clear();
    r.read_line(&mut line)
        .map_err(|e| Error::MissingComment(e.to_string()))?;
    if line.trim().is_empty() {
        return Err(Error::MissingComment("line is empty".to_string()));
    }

    let mut symbols = Vec::with_capacity(n_atoms);
    let mut geometry = Vec::with_capacity(n_atoms * 3);
    for _ in 0..n_atoms {
        line.clear();
        r.read_line(&mut line)
            .map_err(|e| Error::ParsingAtomLine(e.to_string()))?;
        let mut tokens = line.split_whitespace();
        symbols.push(
            tokens
                .next()
                .ok_or(Error::MissingAtomLine)
                .map(|sym| sym.try_into())?
                .map_err(|e| Error::ParsingAtomLine(format!("invalid atom symbol {}", e)))?,
        );
        geometry.push(tokens.next().ok_or(Error::MissingAtomLine).and_then(|g| {
            g.parse::<f32>()
                .map_err(|e| Error::ParsingAtomLine(e.to_string()))
        })?);
        geometry.push(tokens.next().ok_or(Error::MissingAtomLine).and_then(|g| {
            g.parse::<f32>()
                .map_err(|e| Error::ParsingAtomLine(e.to_string()))
        })?);
        geometry.push(tokens.next().ok_or(Error::MissingAtomLine).and_then(|g| {
            g.parse::<f32>()
                .map_err(|e| Error::ParsingAtomLine(e.to_string()))
        })?);
    }
    Ok(Topology {
        symbols,
        geometry,
        schema_version: SchemaVersion::new(0, 2, 0), // Assuming V1 as the schema version
        ..Default::default()
    })
}

/// Converts the topology data to a string in XYZ format.
///
/// # Arguments
///
/// * `topology` - A reference to the `Topology` struct containing the data
///   to be converted.
///
/// # Returns
///
/// * `io::Result<String>` - An `io::Result` containing the XYZ formatted
///   string or an error.
pub fn to_xyz(topology: &Topology) -> io::Result<String> {
    let mut buffer = Vec::new();
    write_xyz(&mut buffer, topology)?;
    String::from_utf8(buffer).map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))
}

/// Writes the topology data to a writer in XYZ format.
///
/// # Arguments
///
/// * `w` - A mutable reference to an object that implements the `Write`
///   trait.
/// * `topology` - A reference to the `Topology` struct containing the data
///   to be written.
///
/// # Returns
///
/// * `io::Result<()>` - An `io::Result` indicating success or failure.
pub fn write_xyz(w: &mut impl Write, topology: &Topology) -> io::Result<()> {
    writeln!(w, "{}\nqdx molecule", topology.symbols.len())?;
    for (i, line) in topology
        .geometry
        .chunks(3)
        .zip(topology.symbols.iter())
        .enumerate()
    {
        write!(
            w,
            "{:2} {:>10.5} {:>10.5} {:>10.5}",
            line.1, line.0[0], line.0[1], line.0[2]
        )?;
        if i + 1 < topology.symbols.len() {
            writeln!(w)?;
        }
    }
    Ok(())
}
