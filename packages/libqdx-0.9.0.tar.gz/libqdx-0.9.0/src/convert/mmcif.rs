#![allow(dead_code)]
#![allow(unused_imports)]

use std::{
    collections::{BTreeMap, BTreeSet, HashMap, HashSet},
    fmt::{self, Display, Formatter},
};

use itertools::Itertools as _;
#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use crate::{
    AlphaHelices, AtomRef, BetaSheets, Bond, BondOrder, Chain, ChainRef, Chains, Element,
    FormalCharge, Fragment, HelixClass, Residue, ResidueRef, Residues, StrandSense, TRC, Topology,
};

#[derive(thiserror::Error, Debug)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub enum MmCifError {
    #[error("invalid mmCIF format: {0}")]
    InvalidFormat(String),
    #[error("missing required field: {0}")]
    MissingField(String),
    #[error("invalid element symbol: {0}")]
    InvalidElement(String),
    #[error("parse error: {0}")]
    ParseError(String),
    #[error("invalid connection for atom {atom_id}")]
    InvalidConnection { atom_id: String },
    #[error("atom charges should zip with atoms")]
    AtomChargeZip,
}

#[derive(Clone, Debug)]
struct MmCifDocument {
    data_blocks: Vec<DataBlock>,
}

#[derive(Clone, Debug)]
struct DataBlock {
    name: String,
    items: HashMap<String, DataItem>,
}

#[derive(Clone, Debug)]
enum DataItem {
    Single(String),
    Loop(Vec<String>, Vec<Vec<String>>), // (column names, rows of data)
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
struct ResidueId {
    chain_id: String,
    sequence_number: i32,
    insertion_code: String,
    residue_name: String,
}

impl Display for ResidueId {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}_{:>9}_{}_{}",
            self.chain_id, self.sequence_number, self.insertion_code, self.residue_name
        )
    }
}

#[derive(Clone, Debug)]
struct AtomRecord {
    id: u32,
    type_symbol: String,
    label_atom_id: String,
    label_alt_id: Option<String>,
    label_comp_id: String,
    label_asym_id: String,
    label_seq_id: i32,
    pdbx_ins_code: Option<String>,
    cartn_x: f32,
    cartn_y: f32,
    cartn_z: f32,
    occupancy: f32,
    b_iso_or_equiv: f32,
    formal_charge: i32,
    auth_asym_id: String,
    auth_seq_id: i32,
    group_pdb: String,
    model_num: String,
}

#[derive(Clone, Debug)]
struct Connection {
    id: String,
    conn_type: String,
    ptnr1_atom: String,
    ptnr1_asym: String,
    ptnr1_seq: i32,
    ptnr2_atom: String,
    ptnr2_asym: String,
    ptnr2_seq: i32,
}

#[derive(Clone, Debug)]
struct CompBond {
    atom_id_1: String,
    atom_id_2: String,
    value_order: String,
    pdbx_ordinal: u32,
}

#[derive(Clone, Debug)]
struct MissingResidue {
    chain_id: String,
    sequence_number: i32,
    insertion_code: String,
    residue_name: String,
}

#[derive(Clone, Debug)]
struct MmcifHelixRecord {
    helix_id: String,
    beg_label_comp_id: String,
    beg_auth_asym_id: String,
    beg_auth_seq_id: i32,
    beg_ins_code: String,
    end_label_comp_id: String,
    end_auth_asym_id: String,
    end_auth_seq_id: i32,
    end_ins_code: String,
    helix_class: Option<i32>,
    helix_length: Option<u32>,
}

#[derive(Clone, Debug)]
struct MmcifSheetRangeRecord {
    sheet_id: String,
    range_id: String,
    beg_label_comp_id: String,
    beg_auth_asym_id: String,
    beg_auth_seq_id: i32,
    beg_ins_code: String,
    end_label_comp_id: String,
    end_auth_asym_id: String,
    end_auth_seq_id: i32,
    end_ins_code: String,
}

#[derive(Clone, Debug, Default)]
struct SecondaryStructureRecords {
    helices: Vec<MmcifHelixRecord>,
    sheet_ranges: Vec<MmcifSheetRangeRecord>,
    sheet_num_strands: HashMap<String, u32>,
    sheet_sense_by_range: HashMap<(String, String), StrandSense>,
}

fn parse_mmcif(content: &str) -> Result<MmCifDocument, MmCifError> {
    let mut data_blocks = Vec::new();
    let mut current_block: Option<DataBlock> = None;
    let mut lines = content.lines().peekable();

    while let Some(line) = lines.next() {
        let line = line.trim();

        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        if let Some(stripped) = line.strip_prefix("data_") {
            if let Some(block) = current_block.take() {
                data_blocks.push(block);
            }
            current_block = Some(DataBlock {
                name: stripped.to_string(),
                items: HashMap::new(),
            });
        } else if line.starts_with("loop_") {
            // Parse loop structure
            let mut columns = Vec::new();

            // Collect column names
            while let Some(next_line) = lines.peek() {
                let next_line = next_line.trim();
                if next_line.starts_with('_') {
                    columns.push(next_line.to_string());
                    lines.next();
                } else {
                    break;
                }
            }

            // Collect data rows
            let mut rows = Vec::new();
            while let Some(next_line) = lines.peek() {
                let next_line = next_line.trim();
                if next_line.is_empty() || next_line.starts_with('#') {
                    lines.next();
                    continue;
                }
                if next_line.starts_with('_')
                    || next_line.starts_with("loop_")
                    || next_line.starts_with("data_")
                {
                    break;
                }

                let mut row = Vec::new();
                let mut current_line = lines.next().unwrap().to_string();

                while row.len() < columns.len() {
                    let tokens = parse_line(&current_line);
                    row.extend(tokens);

                    if row.len() < columns.len() {
                        if let Some(next) = lines.peek() {
                            if !next.trim().starts_with('_')
                                && !next.trim().starts_with("loop_")
                                && !next.trim().starts_with("data_")
                            {
                                current_line = lines.next().unwrap().to_string();
                            } else {
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                }

                if row.len() == columns.len() {
                    rows.push(row);
                }
            }

            // Store loop data by category
            if !columns.is_empty() {
                let category = columns[0].split('.').next().unwrap_or("").to_string();
                if let Some(ref mut block) = current_block {
                    block.items.insert(category, DataItem::Loop(columns, rows));
                }
            }
        } else if line.starts_with('_') {
            // Single key-value pair
            let parts: Vec<&str> = line.splitn(2, char::is_whitespace).collect();
            if parts.len() == 2 {
                let key = parts[0].to_string();
                let value = parts[1].trim().to_string();
                if let Some(ref mut block) = current_block {
                    block.items.insert(key, DataItem::Single(value));
                }
            }
        }
    }

    if let Some(block) = current_block {
        data_blocks.push(block);
    }

    Ok(MmCifDocument { data_blocks })
}

fn parse_line(line: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut chars = line.chars().peekable();
    let mut current = String::new();

    while let Some(ch) = chars.next() {
        match ch {
            '\'' | '"' => {
                // Quoted string
                let quote = ch;
                for next_ch in chars.by_ref() {
                    if next_ch == quote {
                        break;
                    }
                    current.push(next_ch);
                }
                if !current.is_empty() {
                    tokens.push(current.clone());
                    current.clear();
                }
            }
            ';' if current.is_empty() => {
                // Multi-line string
                current.clear();
                for next_ch in chars.by_ref() {
                    if next_ch == '\n' {
                        break;
                    }
                }
                // This is a simplified handling - real mmCIF would need to handle multi-line properly
                tokens.push(String::new());
            }
            ch if ch.is_whitespace() => {
                if !current.is_empty() {
                    tokens.push(current.clone());
                    current.clear();
                }
            }
            ch => {
                current.push(ch);
            }
        }
    }

    if !current.is_empty() {
        tokens.push(current);
    }

    // Convert '.' and '?' to empty strings (mmCIF conventions for missing data)
    tokens
        .into_iter()
        .map(|t| {
            if t == "." || t == "?" {
                String::new()
            } else {
                t
            }
        })
        .collect()
}

fn get_loop_data<'a>(
    block: &'a DataBlock,
    category: &str,
) -> Option<(&'a Vec<String>, &'a Vec<Vec<String>>)> {
    match block.items.get(category)? {
        DataItem::Loop(columns, rows) => Some((columns, rows)),
        _ => None,
    }
}

fn get_single_data<'a>(block: &'a DataBlock, field: &str) -> Option<&'a str> {
    match block.items.get(field)? {
        DataItem::Single(value) => Some(value.as_str()),
        _ => None,
    }
}

fn is_missing_mmcif_value(value: &str) -> bool {
    value.is_empty() || value == "?" || value == "."
}

fn row_str(row: &[String], idx: Option<usize>) -> Option<&str> {
    idx.and_then(|i| row.get(i))
        .map(String::as_str)
        .filter(|value| !is_missing_mmcif_value(value))
}

fn row_str_fallback(
    row: &[String],
    primary_idx: Option<usize>,
    fallback_idx: Option<usize>,
) -> Option<&str> {
    row_str(row, primary_idx).or_else(|| row_str(row, fallback_idx))
}

fn row_string_or_default(row: &[String], idx: Option<usize>) -> String {
    row.get(idx.unwrap_or(0)).cloned().unwrap_or_default()
}

fn row_i32(row: &[String], idx: Option<usize>) -> Option<i32> {
    row_str(row, idx).and_then(|value| value.parse::<i32>().ok())
}

fn row_i32_fallback(
    row: &[String],
    primary_idx: Option<usize>,
    fallback_idx: Option<usize>,
) -> Option<i32> {
    row_i32(row, primary_idx).or_else(|| row_i32(row, fallback_idx))
}

fn row_i32_or(row: &[String], idx: Option<usize>, default: i32) -> i32 {
    row.get(idx.unwrap_or(0))
        .and_then(|value| value.parse::<i32>().ok())
        .unwrap_or(default)
}

fn row_u32_or(row: &[String], idx: Option<usize>, default: u32) -> u32 {
    row.get(idx.unwrap_or(0))
        .and_then(|value| value.parse::<u32>().ok())
        .unwrap_or(default)
}

fn row_f32_or(row: &[String], idx: Option<usize>, default: f32) -> f32 {
    row.get(idx.unwrap_or(0))
        .and_then(|value| value.parse::<f32>().ok())
        .unwrap_or(default)
}

fn insert_chain_seq_begin(
    chain_seq_begins: &mut HashMap<String, i32>,
    strands: &str,
    seq_begin: i32,
) {
    for chain_id in strands.split(',').map(str::trim).filter(|s| !s.is_empty()) {
        chain_seq_begins
            .entry(chain_id.to_string())
            .or_insert(seq_begin);
    }
}

fn find_column_index(columns: &[String], field: &str) -> Option<usize> {
    columns.iter().position(|c| c == field)
}

fn parse_charge(s: &str) -> Option<i32> {
    let s = s.trim();
    if s.is_empty() {
        return Some(0);
    }

    // Handle charges like "2+", "1-", "+2", "-1"
    if let Some(stripped) = s.strip_suffix('+') {
        stripped.parse::<i32>().ok()
    } else if let Some(stripped) = s.strip_suffix('-') {
        stripped.parse::<i32>().ok().map(|v| -v)
    } else if let Some(stripped) = s.strip_prefix('+') {
        stripped.parse::<i32>().ok()
    } else if let Some(stripped) = s.strip_prefix('-') {
        stripped.parse::<i32>().ok().map(|v| -v)
    } else {
        s.parse::<i32>().ok()
    }
}

fn ins_code_or_tilde(value: Option<&str>) -> String {
    match value {
        Some(v) if !v.is_empty() => v.to_string(),
        _ => "~".to_string(),
    }
}

fn parse_sheet_sense(value: &str) -> Option<StrandSense> {
    match value.to_ascii_lowercase().as_str() {
        "" => None,
        "first" => Some(StrandSense::First),
        "parallel" => Some(StrandSense::Parallel),
        "anti-parallel" | "antiparallel" => Some(StrandSense::AntiParallel),
        _ => None,
    }
}

fn parse_secondary_structure(block: &DataBlock) -> SecondaryStructureRecords {
    let mut secondary = SecondaryStructureRecords::default();

    if let Some((columns, rows)) = get_loop_data(block, "_struct_conf") {
        let conf_type_id_idx = find_column_index(columns, "_struct_conf.conf_type_id");
        let helix_id_idx = find_column_index(columns, "_struct_conf.pdbx_PDB_helix_id");
        let id_idx = find_column_index(columns, "_struct_conf.id");
        let beg_label_comp_id_idx = find_column_index(columns, "_struct_conf.beg_label_comp_id");
        let beg_auth_asym_id_idx = find_column_index(columns, "_struct_conf.beg_auth_asym_id");
        let beg_auth_seq_id_idx = find_column_index(columns, "_struct_conf.beg_auth_seq_id");
        let beg_ins_code_idx = find_column_index(columns, "_struct_conf.pdbx_beg_PDB_ins_code");
        let end_label_comp_id_idx = find_column_index(columns, "_struct_conf.end_label_comp_id");
        let end_auth_asym_id_idx = find_column_index(columns, "_struct_conf.end_auth_asym_id");
        let end_auth_seq_id_idx = find_column_index(columns, "_struct_conf.end_auth_seq_id");
        let end_ins_code_idx = find_column_index(columns, "_struct_conf.pdbx_end_PDB_ins_code");
        let helix_class_idx = find_column_index(columns, "_struct_conf.pdbx_PDB_helix_class");
        let helix_length_idx = find_column_index(columns, "_struct_conf.pdbx_PDB_helix_length");

        for row in rows {
            let conf_type_id = row_str(row, conf_type_id_idx).unwrap_or("");
            if !conf_type_id.starts_with("HELX") {
                continue;
            }

            let helix_id = row_str(row, helix_id_idx).unwrap_or("");
            let fallback_id = row_str(row, id_idx).unwrap_or("");
            let helix_id = if helix_id.is_empty() {
                fallback_id.to_string()
            } else {
                helix_id.to_string()
            };

            let beg_label_comp_id = row_str(row, beg_label_comp_id_idx)
                .unwrap_or_default()
                .to_string();
            let beg_auth_asym_id = row_str(row, beg_auth_asym_id_idx)
                .unwrap_or_default()
                .to_string();
            let beg_auth_seq_id = row_i32(row, beg_auth_seq_id_idx).unwrap_or_default();
            let beg_ins_code = ins_code_or_tilde(row_str(row, beg_ins_code_idx));

            let end_label_comp_id = row_str(row, end_label_comp_id_idx)
                .unwrap_or_default()
                .to_string();
            let end_auth_asym_id = row_str(row, end_auth_asym_id_idx)
                .unwrap_or_default()
                .to_string();
            let end_auth_seq_id = row_i32(row, end_auth_seq_id_idx).unwrap_or_default();
            let end_ins_code = ins_code_or_tilde(row_str(row, end_ins_code_idx));

            let helix_class = row_i32(row, helix_class_idx);
            let helix_length = row_str(row, helix_length_idx).and_then(|s| s.parse::<u32>().ok());

            secondary.helices.push(MmcifHelixRecord {
                helix_id,
                beg_label_comp_id,
                beg_auth_asym_id,
                beg_auth_seq_id,
                beg_ins_code,
                end_label_comp_id,
                end_auth_asym_id,
                end_auth_seq_id,
                end_ins_code,
                helix_class,
                helix_length,
            });
        }
    } else {
        let conf_type_id = get_single_data(block, "_struct_conf.conf_type_id").unwrap_or("");
        if conf_type_id.starts_with("HELX") {
            let get = |suffix| get_single_data(block, suffix);
            let helix_id = get("_struct_conf.pdbx_PDB_helix_id")
                .filter(|v| !v.is_empty())
                .or_else(|| get("_struct_conf.id"))
                .unwrap_or("")
                .to_string();
            let beg_label_comp_id = get("_struct_conf.beg_label_comp_id")
                .unwrap_or_default()
                .to_string();
            let beg_auth_asym_id = get("_struct_conf.beg_auth_asym_id")
                .filter(|v| !is_missing_mmcif_value(v))
                .unwrap_or_default()
                .to_string();
            let beg_auth_seq_id = get("_struct_conf.beg_auth_seq_id")
                .and_then(|s| s.parse::<i32>().ok())
                .unwrap_or_default();
            let beg_ins_code = ins_code_or_tilde(get("_struct_conf.pdbx_beg_PDB_ins_code"));
            let end_label_comp_id = get("_struct_conf.end_label_comp_id")
                .unwrap_or_default()
                .to_string();
            let end_auth_asym_id = get("_struct_conf.end_auth_asym_id")
                .unwrap_or_default()
                .to_string();
            let end_auth_seq_id = get("_struct_conf.end_auth_seq_id")
                .and_then(|s| s.parse::<i32>().ok())
                .unwrap_or_default();
            let end_ins_code = ins_code_or_tilde(get("_struct_conf.pdbx_end_PDB_ins_code"));
            let helix_class =
                get("_struct_conf.pdbx_PDB_helix_class").and_then(|s| s.parse::<i32>().ok());
            let helix_length =
                get("_struct_conf.pdbx_PDB_helix_length").and_then(|s| s.parse::<u32>().ok());

            if !helix_id.is_empty() && !beg_auth_asym_id.is_empty() {
                secondary.helices.push(MmcifHelixRecord {
                    helix_id,
                    beg_label_comp_id,
                    beg_auth_asym_id,
                    beg_auth_seq_id,
                    beg_ins_code,
                    end_label_comp_id,
                    end_auth_asym_id,
                    end_auth_seq_id,
                    end_ins_code,
                    helix_class,
                    helix_length,
                });
            }
        }
    }

    if let Some((columns, rows)) = get_loop_data(block, "_struct_sheet") {
        let sheet_id_idx = find_column_index(columns, "_struct_sheet.id");
        let number_strands_idx = find_column_index(columns, "_struct_sheet.number_strands");

        for row in rows {
            let sheet_id = row_str(row, sheet_id_idx);
            let num_strands = row_str(row, number_strands_idx).and_then(|s| s.parse::<u32>().ok());
            if let (Some(sheet_id), Some(num_strands)) = (sheet_id, num_strands) {
                secondary
                    .sheet_num_strands
                    .insert(sheet_id.to_string(), num_strands);
            }
        }
    } else if let (Some(sheet_id), Some(num_strands)) = (
        get_single_data(block, "_struct_sheet.id").filter(|v| !is_missing_mmcif_value(v)),
        get_single_data(block, "_struct_sheet.number_strands").and_then(|s| s.parse::<u32>().ok()),
    ) {
        secondary
            .sheet_num_strands
            .insert(sheet_id.to_string(), num_strands);
    }

    if let Some((columns, rows)) = get_loop_data(block, "_struct_sheet_order") {
        let sheet_id_idx = find_column_index(columns, "_struct_sheet_order.sheet_id");
        let range_id_2_idx = find_column_index(columns, "_struct_sheet_order.range_id_2");
        let sense_idx = find_column_index(columns, "_struct_sheet_order.sense");

        for row in rows {
            let sheet_id = row_str(row, sheet_id_idx);
            let range_id_2 = row_str(row, range_id_2_idx);
            let sense = row_str(row, sense_idx).unwrap_or("");

            let (Some(sheet_id), Some(range_id_2)) = (sheet_id, range_id_2) else {
                continue;
            };
            if let Some(sense) = parse_sheet_sense(sense) {
                secondary
                    .sheet_sense_by_range
                    .insert((sheet_id.to_string(), range_id_2.to_string()), sense);
            }
        }
    } else if let (Some(sheet_id), Some(range_id_2), Some(sense)) = (
        get_single_data(block, "_struct_sheet_order.sheet_id")
            .filter(|v| !is_missing_mmcif_value(v)),
        get_single_data(block, "_struct_sheet_order.range_id_2")
            .filter(|v| !is_missing_mmcif_value(v)),
        get_single_data(block, "_struct_sheet_order.sense").and_then(parse_sheet_sense),
    ) {
        secondary
            .sheet_sense_by_range
            .insert((sheet_id.to_string(), range_id_2.to_string()), sense);
    }

    if let Some((columns, rows)) = get_loop_data(block, "_struct_sheet_range") {
        let sheet_id_idx = find_column_index(columns, "_struct_sheet_range.sheet_id");
        let id_idx = find_column_index(columns, "_struct_sheet_range.id");
        let beg_label_comp_id_idx =
            find_column_index(columns, "_struct_sheet_range.beg_label_comp_id");
        let beg_auth_asym_id_idx =
            find_column_index(columns, "_struct_sheet_range.beg_auth_asym_id");
        let beg_auth_seq_id_idx = find_column_index(columns, "_struct_sheet_range.beg_auth_seq_id");
        let beg_ins_code_idx =
            find_column_index(columns, "_struct_sheet_range.pdbx_beg_PDB_ins_code");
        let end_label_comp_id_idx =
            find_column_index(columns, "_struct_sheet_range.end_label_comp_id");
        let end_auth_asym_id_idx =
            find_column_index(columns, "_struct_sheet_range.end_auth_asym_id");
        let end_auth_seq_id_idx = find_column_index(columns, "_struct_sheet_range.end_auth_seq_id");
        let end_ins_code_idx =
            find_column_index(columns, "_struct_sheet_range.pdbx_end_PDB_ins_code");

        for row in rows {
            let sheet_id = row_str(row, sheet_id_idx).unwrap_or_default().to_string();
            let range_id = row_str(row, id_idx).unwrap_or_default().to_string();

            let beg_label_comp_id = row_str(row, beg_label_comp_id_idx)
                .unwrap_or_default()
                .to_string();
            let beg_auth_asym_id = row_str(row, beg_auth_asym_id_idx)
                .unwrap_or_default()
                .to_string();
            let beg_auth_seq_id = row_i32(row, beg_auth_seq_id_idx).unwrap_or_default();
            let beg_ins_code = ins_code_or_tilde(row_str(row, beg_ins_code_idx));

            let end_label_comp_id = row_str(row, end_label_comp_id_idx)
                .unwrap_or_default()
                .to_string();
            let end_auth_asym_id = row_str(row, end_auth_asym_id_idx)
                .unwrap_or_default()
                .to_string();
            let end_auth_seq_id = row_i32(row, end_auth_seq_id_idx).unwrap_or_default();
            let end_ins_code = ins_code_or_tilde(row_str(row, end_ins_code_idx));

            if sheet_id.is_empty() || range_id.is_empty() || beg_auth_asym_id.is_empty() {
                continue;
            }

            secondary.sheet_ranges.push(MmcifSheetRangeRecord {
                sheet_id,
                range_id,
                beg_label_comp_id,
                beg_auth_asym_id,
                beg_auth_seq_id,
                beg_ins_code,
                end_label_comp_id,
                end_auth_asym_id,
                end_auth_seq_id,
                end_ins_code,
            });
        }
    } else {
        let get = |suffix| get_single_data(block, suffix);
        let sheet_id = get("_struct_sheet_range.sheet_id")
            .filter(|v| !is_missing_mmcif_value(v))
            .unwrap_or_default()
            .to_string();
        let range_id = get("_struct_sheet_range.id")
            .filter(|v| !is_missing_mmcif_value(v))
            .unwrap_or_default()
            .to_string();
        let beg_label_comp_id = get("_struct_sheet_range.beg_label_comp_id")
            .unwrap_or_default()
            .to_string();
        let beg_auth_asym_id = get("_struct_sheet_range.beg_auth_asym_id")
            .filter(|v| !is_missing_mmcif_value(v))
            .unwrap_or_default()
            .to_string();
        let beg_auth_seq_id = get("_struct_sheet_range.beg_auth_seq_id")
            .and_then(|s| s.parse::<i32>().ok())
            .unwrap_or_default();
        let beg_ins_code = ins_code_or_tilde(get("_struct_sheet_range.pdbx_beg_PDB_ins_code"));
        let end_label_comp_id = get("_struct_sheet_range.end_label_comp_id")
            .unwrap_or_default()
            .to_string();
        let end_auth_asym_id = get("_struct_sheet_range.end_auth_asym_id")
            .unwrap_or_default()
            .to_string();
        let end_auth_seq_id = get("_struct_sheet_range.end_auth_seq_id")
            .and_then(|s| s.parse::<i32>().ok())
            .unwrap_or_default();
        let end_ins_code = ins_code_or_tilde(get("_struct_sheet_range.pdbx_end_PDB_ins_code"));

        if !sheet_id.is_empty() && !range_id.is_empty() && !beg_auth_asym_id.is_empty() {
            secondary.sheet_ranges.push(MmcifSheetRangeRecord {
                sheet_id,
                range_id,
                beg_label_comp_id,
                beg_auth_asym_id,
                beg_auth_seq_id,
                beg_ins_code,
                end_label_comp_id,
                end_auth_asym_id,
                end_auth_seq_id,
                end_ins_code,
            });
        }
    }

    secondary
}

pub fn from_mmcif(mmcif_contents: impl AsRef<str>) -> Result<Vec<TRC>, MmCifError> {
    let doc = parse_mmcif(mmcif_contents.as_ref())?;
    let mut trcs = Vec::new();

    for block in doc.data_blocks {
        let mut models: HashMap<String, Vec<AtomRecord>> = HashMap::new();
        let mut connections: Vec<Connection> = Vec::new();
        let mut comp_bonds: HashMap<String, Vec<CompBond>> = HashMap::new();
        let mut missing_residues_by_model: HashMap<String, Vec<MissingResidue>> = HashMap::new();
        let mut missing_residues_for_all_models: Vec<MissingResidue> = Vec::new();
        let mut dropped_unobs_rows_by_chain: BTreeMap<String, usize> = BTreeMap::new();
        let mut chain_poly_seq: HashMap<String, BTreeMap<i32, String>> = HashMap::new();
        let mut chain_seq_begins: HashMap<String, i32> = HashMap::new();

        // Parse atom_site data
        if let Some((columns, rows)) = get_loop_data(&block, "_atom_site") {
            // Find column indices
            let id_idx = find_column_index(columns, "_atom_site.id");
            let type_symbol_idx = find_column_index(columns, "_atom_site.type_symbol");
            let label_atom_id_idx = find_column_index(columns, "_atom_site.label_atom_id");
            let label_alt_id_idx = find_column_index(columns, "_atom_site.label_alt_id");
            let label_comp_id_idx = find_column_index(columns, "_atom_site.label_comp_id");
            let label_asym_id_idx = find_column_index(columns, "_atom_site.label_asym_id");
            let label_seq_id_idx = find_column_index(columns, "_atom_site.label_seq_id");
            let pdbx_ins_code_idx = find_column_index(columns, "_atom_site.pdbx_PDB_ins_code");
            let cartn_x_idx = find_column_index(columns, "_atom_site.Cartn_x");
            let cartn_y_idx = find_column_index(columns, "_atom_site.Cartn_y");
            let cartn_z_idx = find_column_index(columns, "_atom_site.Cartn_z");
            let occupancy_idx = find_column_index(columns, "_atom_site.occupancy");
            let b_iso_idx = find_column_index(columns, "_atom_site.B_iso_or_equiv");
            let formal_charge_idx = find_column_index(columns, "_atom_site.pdbx_formal_charge");
            let auth_asym_id_idx = find_column_index(columns, "_atom_site.auth_asym_id");
            let auth_seq_id_idx = find_column_index(columns, "_atom_site.auth_seq_id");
            let group_pdb_idx = find_column_index(columns, "_atom_site.group_PDB");
            let model_num_idx = find_column_index(columns, "_atom_site.pdbx_PDB_model_num");

            for row in rows {
                let atom = AtomRecord {
                    id: row_u32_or(row, id_idx, 0),
                    type_symbol: row_string_or_default(row, type_symbol_idx),
                    label_atom_id: row_string_or_default(row, label_atom_id_idx),
                    label_alt_id: row
                        .get(label_alt_id_idx.unwrap_or(0))
                        .and_then(|s| if s.is_empty() { None } else { Some(s.clone()) }),
                    label_comp_id: row_string_or_default(row, label_comp_id_idx),
                    label_asym_id: row_string_or_default(row, label_asym_id_idx),
                    label_seq_id: row_i32_or(row, label_seq_id_idx, 0),
                    pdbx_ins_code: row
                        .get(pdbx_ins_code_idx.unwrap_or(0))
                        .and_then(|s| if s.is_empty() { None } else { Some(s.clone()) }),
                    cartn_x: row_f32_or(row, cartn_x_idx, 0.0),
                    cartn_y: row_f32_or(row, cartn_y_idx, 0.0),
                    cartn_z: row_f32_or(row, cartn_z_idx, 0.0),
                    occupancy: row_f32_or(row, occupancy_idx, 1.0),
                    b_iso_or_equiv: row_f32_or(row, b_iso_idx, 0.0),
                    formal_charge: row
                        .get(formal_charge_idx.unwrap_or(0))
                        .and_then(|s| parse_charge(s))
                        .unwrap_or(0),
                    auth_asym_id: row_str_fallback(row, auth_asym_id_idx, label_asym_id_idx)
                        .unwrap_or_default()
                        .to_string(),
                    auth_seq_id: row_i32_fallback(row, auth_seq_id_idx, label_seq_id_idx)
                        .unwrap_or(0),
                    group_pdb: row_str(row, group_pdb_idx).unwrap_or("ATOM").to_string(),
                    model_num: row_str(row, model_num_idx).unwrap_or("1").to_string(),
                };

                models.entry(atom.model_num.clone()).or_default().push(atom);
            }
        }

        // Parse chem_comp_bond data for intra-residue bonds
        if let Some((columns, rows)) = get_loop_data(&block, "_chem_comp_bond") {
            let comp_id_idx = find_column_index(columns, "_chem_comp_bond.comp_id");
            let atom_id_1_idx = find_column_index(columns, "_chem_comp_bond.atom_id_1");
            let atom_id_2_idx = find_column_index(columns, "_chem_comp_bond.atom_id_2");
            let value_order_idx = find_column_index(columns, "_chem_comp_bond.value_order");
            let pdbx_ordinal_idx = find_column_index(columns, "_chem_comp_bond.pdbx_ordinal");

            for row in rows {
                let comp_id = row_string_or_default(row, comp_id_idx);
                let bond = CompBond {
                    atom_id_1: row_string_or_default(row, atom_id_1_idx),
                    atom_id_2: row_string_or_default(row, atom_id_2_idx),
                    value_order: row_str(row, value_order_idx).unwrap_or("SING").to_string(),
                    pdbx_ordinal: row_u32_or(row, pdbx_ordinal_idx, 0),
                };
                comp_bonds.entry(comp_id).or_default().push(bond);
            }
        }

        // Parse polymer sequence data (SEQRES-equivalent).
        if let Some((columns, rows)) = get_loop_data(&block, "_pdbx_poly_seq_scheme") {
            let asym_id_idx = find_column_index(columns, "_pdbx_poly_seq_scheme.asym_id");
            let seq_id_idx = find_column_index(columns, "_pdbx_poly_seq_scheme.seq_id");
            let mon_id_idx = find_column_index(columns, "_pdbx_poly_seq_scheme.mon_id");
            let auth_mon_id_idx = find_column_index(columns, "_pdbx_poly_seq_scheme.auth_mon_id");
            let pdb_strand_id_idx =
                find_column_index(columns, "_pdbx_poly_seq_scheme.pdb_strand_id");

            for row in rows {
                let Some(seq_id) = row_i32(row, seq_id_idx) else {
                    continue;
                };

                let chain_id =
                    row_str_fallback(row, pdb_strand_id_idx, asym_id_idx).map(str::to_string);

                let residue_name =
                    row_str_fallback(row, auth_mon_id_idx, mon_id_idx).map(str::to_string);

                let (Some(chain_id), Some(residue_name)) = (chain_id, residue_name) else {
                    continue;
                };

                chain_poly_seq
                    .entry(chain_id)
                    .or_default()
                    .insert(seq_id, residue_name);
            }
        }

        // Parse sequence-number alignment data (DBREF-equivalent).
        if let Some((columns, rows)) = get_loop_data(&block, "_struct_ref_seq") {
            let strand_idx = find_column_index(columns, "_struct_ref_seq.pdbx_strand_id");
            let auth_seq_align_beg_idx =
                find_column_index(columns, "_struct_ref_seq.pdbx_auth_seq_align_beg");
            let seq_align_beg_idx = find_column_index(columns, "_struct_ref_seq.seq_align_beg");

            for row in rows {
                let Some(seq_begin) =
                    row_i32_fallback(row, auth_seq_align_beg_idx, seq_align_beg_idx)
                else {
                    continue;
                };

                let Some(strands) = row_str(row, strand_idx) else {
                    continue;
                };

                insert_chain_seq_begin(&mut chain_seq_begins, strands, seq_begin);
            }
        } else {
            // Some entries encode _struct_ref_seq as single key-value items
            // rather than a loop.
            let seq_begin = get_single_data(&block, "_struct_ref_seq.pdbx_auth_seq_align_beg")
                .filter(|value| !is_missing_mmcif_value(value))
                .and_then(|value| value.parse::<i32>().ok())
                .or_else(|| {
                    get_single_data(&block, "_struct_ref_seq.seq_align_beg")
                        .filter(|value| !is_missing_mmcif_value(value))
                        .and_then(|value| value.parse::<i32>().ok())
                });

            let strands = get_single_data(&block, "_struct_ref_seq.pdbx_strand_id")
                .filter(|value| !is_missing_mmcif_value(value));

            if let (Some(seq_begin), Some(strands)) = (seq_begin, strands) {
                insert_chain_seq_begin(&mut chain_seq_begins, strands, seq_begin);
            }
        }

        // Parse struct_conn data for inter-residue bonds
        if let Some((columns, rows)) = get_loop_data(&block, "_struct_conn") {
            let id_idx = find_column_index(columns, "_struct_conn.id");
            let conn_type_idx = find_column_index(columns, "_struct_conn.conn_type_id");
            let ptnr1_label_atom_id_idx =
                find_column_index(columns, "_struct_conn.ptnr1_label_atom_id");
            let ptnr1_label_asym_id_idx =
                find_column_index(columns, "_struct_conn.ptnr1_label_asym_id");
            let ptnr1_label_seq_id_idx =
                find_column_index(columns, "_struct_conn.ptnr1_label_seq_id");
            let ptnr2_label_atom_id_idx =
                find_column_index(columns, "_struct_conn.ptnr2_label_atom_id");
            let ptnr2_label_asym_id_idx =
                find_column_index(columns, "_struct_conn.ptnr2_label_asym_id");
            let ptnr2_label_seq_id_idx =
                find_column_index(columns, "_struct_conn.ptnr2_label_seq_id");

            for row in rows {
                connections.push(Connection {
                    id: row_string_or_default(row, id_idx),
                    conn_type: row_string_or_default(row, conn_type_idx),
                    ptnr1_atom: row_string_or_default(row, ptnr1_label_atom_id_idx),
                    ptnr1_asym: row_string_or_default(row, ptnr1_label_asym_id_idx),
                    ptnr1_seq: row_i32_or(row, ptnr1_label_seq_id_idx, 0),
                    ptnr2_atom: row_string_or_default(row, ptnr2_label_atom_id_idx),
                    ptnr2_asym: row_string_or_default(row, ptnr2_label_asym_id_idx),
                    ptnr2_seq: row_i32_or(row, ptnr2_label_seq_id_idx, 0),
                });
            }
        }

        // Parse unobserved residues so residues without atom records are preserved.
        if let Some((columns, rows)) = get_loop_data(&block, "_pdbx_unobs_or_zero_occ_residues") {
            let model_num_idx =
                find_column_index(columns, "_pdbx_unobs_or_zero_occ_residues.PDB_model_num");
            let polymer_flag_idx =
                find_column_index(columns, "_pdbx_unobs_or_zero_occ_residues.polymer_flag");
            let auth_asym_id_idx =
                find_column_index(columns, "_pdbx_unobs_or_zero_occ_residues.auth_asym_id");
            let auth_comp_id_idx =
                find_column_index(columns, "_pdbx_unobs_or_zero_occ_residues.auth_comp_id");
            let auth_seq_id_idx =
                find_column_index(columns, "_pdbx_unobs_or_zero_occ_residues.auth_seq_id");
            let pdb_ins_code_idx =
                find_column_index(columns, "_pdbx_unobs_or_zero_occ_residues.PDB_ins_code");
            let label_asym_id_idx =
                find_column_index(columns, "_pdbx_unobs_or_zero_occ_residues.label_asym_id");
            let label_comp_id_idx =
                find_column_index(columns, "_pdbx_unobs_or_zero_occ_residues.label_comp_id");
            let label_seq_id_idx =
                find_column_index(columns, "_pdbx_unobs_or_zero_occ_residues.label_seq_id");

            for row in rows {
                if let Some(polymer_flag) = row_str(row, polymer_flag_idx)
                    && polymer_flag != "Y"
                {
                    continue;
                }

                let chain_hint =
                    row_str_fallback(row, auth_asym_id_idx, label_asym_id_idx).map(str::to_string);
                let chain_id = chain_hint.clone();
                let sequence_number = row_i32_fallback(row, auth_seq_id_idx, label_seq_id_idx);
                let residue_name =
                    row_str_fallback(row, auth_comp_id_idx, label_comp_id_idx).map(str::to_string);

                let (Some(chain_id), Some(sequence_number), Some(residue_name)) =
                    (chain_id, sequence_number, residue_name)
                else {
                    let chain_key = chain_hint.unwrap_or_else(|| "<unknown>".to_string());
                    *dropped_unobs_rows_by_chain.entry(chain_key).or_insert(0) += 1;
                    continue;
                };

                let missing_residue = MissingResidue {
                    chain_id,
                    sequence_number,
                    insertion_code: row_string_or_default(row, pdb_ins_code_idx),
                    residue_name,
                };

                let model_num = row_string_or_default(row, model_num_idx);

                if model_num.is_empty() {
                    missing_residues_for_all_models.push(missing_residue);
                } else {
                    missing_residues_by_model
                        .entry(model_num)
                        .or_default()
                        .push(missing_residue);
                }
            }

            for (chain_id, dropped_rows) in dropped_unobs_rows_by_chain {
                tracing::warn!(
                    "mmCIF: chain {chain_id}: skipped {dropped_rows} \
                    _pdbx_unobs_or_zero_occ_residues row(s) due to missing chain/sequence/name fields"
                );
            }
        }

        let secondary = parse_secondary_structure(&block);

        // Convert each model to a TRC
        for (model_num, atoms) in models {
            let mut model_missing_residues = missing_residues_for_all_models.clone();
            if let Some(missing) = missing_residues_by_model.get(&model_num) {
                model_missing_residues.extend(missing.clone());
            }

            let trc = build_trc(
                atoms,
                &connections,
                &comp_bonds,
                &model_missing_residues,
                &chain_poly_seq,
                &chain_seq_begins,
                &secondary,
            )?;
            trcs.push(trc);
        }
    }

    Ok(trcs)
}

fn build_trc(
    atoms: Vec<AtomRecord>,
    connections: &[Connection],
    comp_bonds: &HashMap<String, Vec<CompBond>>,
    missing_residues: &[MissingResidue],
    chain_poly_seq: &HashMap<String, BTreeMap<i32, String>>,
    chain_seq_begins: &HashMap<String, i32>,
    secondary: &SecondaryStructureRecords,
) -> Result<TRC, MmCifError> {
    let mut topology = Topology::default();

    // Vector of atom identities that zips with the `atoms` vector.
    let mut atom_ids = Vec::new();
    // Vector of atom names.
    let mut atom_labels = Vec::new();
    // Vector of atom charges.
    let mut atom_formal_charges = Vec::new();
    // Mapping of alternative locations
    let mut alts = BTreeMap::<u32, Vec<([f32; 3], i32)>>::new();

    // Set of residue identities.
    let mut residue_ids = BTreeSet::new();
    // Mapping of residue identities to residue names.
    let mut residue_seq = BTreeMap::new();
    // Mapping of residue identities to atoms in the residue.
    let mut residues = BTreeMap::<ResidueId, Vec<u32>>::new();
    let mut residue_seq_ids = BTreeMap::new();
    let mut residue_insertion_codes = BTreeMap::new();

    // Mapping of chains to residues.
    let mut chains = BTreeMap::<String, BTreeSet<ResidueId>>::new();

    // Mapping from original atom index to topology atom index
    let mut atom_index_map: HashMap<usize, usize> = HashMap::new();

    // Process atoms
    for (original_idx, atom) in atoms.iter().enumerate() {
        let residue_id = ResidueId {
            chain_id: atom.auth_asym_id.clone(),
            sequence_number: atom.auth_seq_id,
            insertion_code: atom
                .pdbx_ins_code
                .clone()
                .unwrap_or_else(|| "~".to_string()),
            residue_name: atom.label_comp_id.clone(),
        };

        match atom.label_alt_id.as_deref() {
            Some("A") | None => {
                // Parse element from type_symbol
                let element: Element = atom
                    .type_symbol
                    .chars()
                    .filter(|c| c.is_alphabetic())
                    .collect::<String>()
                    .as_str()
                    .try_into()
                    .map_err(MmCifError::InvalidElement)?;

                topology.symbols.push(element);
                topology
                    .geometry
                    .extend_from_slice(&[atom.cartn_x, atom.cartn_y, atom.cartn_z]);

                // Map original atom index to topology index
                let topology_idx = topology.symbols.len() - 1;
                atom_index_map.insert(original_idx, topology_idx);

                residue_ids.insert(residue_id.clone());
                residue_seq.insert(residue_id.clone(), atom.label_comp_id.clone());
                residues
                    .entry(residue_id.clone())
                    .or_default()
                    .push(topology_idx as u32);
                residue_seq_ids.insert(residue_id.clone(), atom.auth_seq_id);
                residue_insertion_codes.insert(
                    residue_id.clone(),
                    atom.pdbx_ins_code.clone().unwrap_or_default(),
                );

                atom_ids.push(atom.id);
                atom_labels.push(atom.label_atom_id.clone());
                atom_formal_charges.push(atom.formal_charge);

                chains
                    .entry(atom.auth_asym_id.clone())
                    .or_default()
                    .insert(residue_id);
            }
            _ => {
                alts.entry(atom.id).or_default().push((
                    [atom.cartn_x, atom.cartn_y, atom.cartn_z],
                    atom.formal_charge,
                ));
            }
        }
    }

    let mut poly_seq_applied = HashSet::new();

    // Primary path: construct the expected polymer sequence per chain and
    // inject any missing positions as empty residues. This mirrors the
    // SEQRES+DBREF behavior used in the PDB parser.
    for (chain_id, seq_map) in chain_poly_seq {
        if seq_map.is_empty() {
            continue;
        }

        let seq_names: Vec<&String> = seq_map.values().collect();
        let existing_seq_ns: BTreeSet<i32> = residue_ids
            .iter()
            .filter(|rid| rid.chain_id == *chain_id)
            .map(|rid| rid.sequence_number)
            .collect();

        let Some(&min_resolved) = existing_seq_ns.iter().next() else {
            continue;
        };

        // Convert sequence positions (1-based polymer order) into author
        // residue numbers. Prefer explicit alignment metadata; otherwise infer
        // from the first resolved residue observed in atom_site.
        let offset = if let Some(&seq_begin) = chain_seq_begins.get(chain_id) {
            seq_begin
        } else {
            let first_resolved_name = residue_ids
                .iter()
                .find(|rid| rid.chain_id == *chain_id && rid.sequence_number == min_resolved)
                .map(|rid| rid.residue_name.as_str());

            let Some(first_resolved_name) = first_resolved_name else {
                tracing::warn!(
                    "mmCIF: chain {chain_id}: unable to determine first resolved residue \
                        while aligning _pdbx_poly_seq_scheme; skipping sequence-driven empty \
                        residue injection for this chain"
                );
                continue;
            };

            let Some(pos) = seq_names
                .iter()
                .position(|residue_name| residue_name.as_str() == first_resolved_name)
            else {
                tracing::warn!(
                    "mmCIF: chain {chain_id}: cannot align _pdbx_poly_seq_scheme with \
                        resolved residues (residue {first_resolved_name} at auth seq \
                        {min_resolved} not found in polymer sequence); skipping sequence-driven \
                        empty residue injection for this chain"
                );
                continue;
            };

            min_resolved - pos as i32
        };

        for (p, seq_name) in seq_names.iter().enumerate() {
            let seq_n = offset + p as i32;
            if existing_seq_ns.contains(&seq_n) {
                continue;
            }

            let residue_id = ResidueId {
                chain_id: chain_id.clone(),
                sequence_number: seq_n,
                insertion_code: "~".to_string(),
                residue_name: (*seq_name).clone(),
            };

            // Deduplicate against resolved residues and previously injected
            // empties via the full residue identity (chain, seq, insertion, name).
            if residue_ids.insert(residue_id.clone()) {
                residue_seq.insert(residue_id.clone(), (*seq_name).clone());
                residues.insert(residue_id.clone(), vec![]);
                residue_seq_ids.insert(residue_id.clone(), seq_n);
                residue_insertion_codes.insert(residue_id.clone(), String::new());
            }

            chains
                .entry(chain_id.clone())
                .or_default()
                .insert(residue_id);
        }

        poly_seq_applied.insert(chain_id.clone());
    }

    // Fallback path: use explicit unobserved-residue records only for chains
    // where we could not build sequence-driven missing residues above.
    for missing in missing_residues {
        if poly_seq_applied.contains(&missing.chain_id) {
            continue;
        }

        let residue_id = ResidueId {
            chain_id: missing.chain_id.clone(),
            sequence_number: missing.sequence_number,
            insertion_code: if missing.insertion_code.is_empty() {
                "~".to_string()
            } else {
                missing.insertion_code.clone()
            },
            residue_name: missing.residue_name.clone(),
        };

        if residue_ids.insert(residue_id.clone()) {
            residue_seq.insert(residue_id.clone(), missing.residue_name.clone());
            residues.insert(residue_id.clone(), vec![]);
            residue_seq_ids.insert(residue_id.clone(), missing.sequence_number);
            residue_insertion_codes.insert(residue_id.clone(), missing.insertion_code.clone());
        }

        chains
            .entry(missing.chain_id.clone())
            .or_default()
            .insert(residue_id);
    }

    // Build connectivity from struct_conn (inter-residue bonds)
    let mut connectivity_deduper = BTreeMap::<(usize, usize), u8>::new();
    for conn in connections {
        // Find atoms by matching atom name, chain, and residue
        let atom1_orig_idx = atoms.iter().position(|a| {
            a.label_atom_id == conn.ptnr1_atom
                && a.label_asym_id == conn.ptnr1_asym
                && a.label_seq_id == conn.ptnr1_seq
        });
        let atom2_orig_idx = atoms.iter().position(|a| {
            a.label_atom_id == conn.ptnr2_atom
                && a.label_asym_id == conn.ptnr2_asym
                && a.label_seq_id == conn.ptnr2_seq
        });

        if let (Some(orig_idx1), Some(orig_idx2)) = (atom1_orig_idx, atom2_orig_idx) {
            // Map original indices to topology indices
            if let (Some(&topo_idx1), Some(&topo_idx2)) = (
                atom_index_map.get(&orig_idx1),
                atom_index_map.get(&orig_idx2),
            ) {
                let bond_order = match conn.conn_type.as_str() {
                    "covale" | "metalc" | "disulf" => 1,
                    _ => 1, // Default to single bond
                };

                let (min_idx, max_idx) = if topo_idx1 < topo_idx2 {
                    (topo_idx1, topo_idx2)
                } else {
                    (topo_idx2, topo_idx1)
                };
                connectivity_deduper.insert((min_idx, max_idx), bond_order);
            }
        }
    }

    // Build connectivity from chem_comp_bond (intra-residue bonds)
    // Group atoms by residue for efficient lookup
    type ResidueKey = (String, String, i32);
    let mut residue_atoms: HashMap<ResidueKey, Vec<(usize, usize, &AtomRecord)>> = HashMap::new();
    for (orig_idx, atom) in atoms.iter().enumerate() {
        // Only process atoms that are in the main conformation (alt_id == "A" or None)
        if (atom.label_alt_id.is_none() || atom.label_alt_id.as_deref() == Some("A"))
            && let Some(&topo_idx) = atom_index_map.get(&orig_idx)
        {
            residue_atoms
                .entry((
                    atom.label_comp_id.clone(),
                    atom.auth_asym_id.clone(),
                    atom.auth_seq_id,
                ))
                .or_default()
                .push((orig_idx, topo_idx, atom));
        }
    }

    // Apply chem_comp_bond definitions to residues
    for ((comp_id, _chain_id, _seq_id), res_atoms) in residue_atoms.iter() {
        if let Some(bonds) = comp_bonds.get(comp_id) {
            for bond in bonds {
                // Find the atoms within this residue that match the bond atom names
                let atom1_topo_idx = res_atoms
                    .iter()
                    .find(|(_, _, a)| a.label_atom_id == bond.atom_id_1)
                    .map(|(_, topo_idx, _)| *topo_idx);
                let atom2_topo_idx = res_atoms
                    .iter()
                    .find(|(_, _, a)| a.label_atom_id == bond.atom_id_2)
                    .map(|(_, topo_idx, _)| *topo_idx);

                if let (Some(topo_idx1), Some(topo_idx2)) = (atom1_topo_idx, atom2_topo_idx) {
                    let bond_order = match bond.value_order.as_str() {
                        "SING" => 1,
                        "DOUB" => 2,
                        "TRIP" => 3,
                        "QUAD" => 4,
                        "AROM" => 1, // Aromatic bonds typically treated as single for bond order
                        _ => 1,
                    };

                    let (min_idx, max_idx) = if topo_idx1 < topo_idx2 {
                        (topo_idx1, topo_idx2)
                    } else {
                        (topo_idx2, topo_idx1)
                    };
                    connectivity_deduper.insert((min_idx, max_idx), bond_order);
                }
            }
        }
    }

    let chain_ids: Vec<String> = chains.keys().cloned().collect();
    let chain_ref_by_id = chain_ids
        .iter()
        .enumerate()
        .map(|(i, chain_id)| (chain_id.clone(), ChainRef(i as u32)))
        .collect::<HashMap<_, _>>();
    let residue_ref_by_id = residue_ids
        .iter()
        .enumerate()
        .map(|(i, residue_id)| (residue_id.clone(), ResidueRef(i as u32)))
        .collect::<BTreeMap<_, _>>();

    let mut alpha_helices = AlphaHelices::default();
    for helix in secondary.helices.iter() {
        let Some(&chain_ref) = chain_ref_by_id.get(&helix.beg_auth_asym_id) else {
            continue;
        };
        let start_id = ResidueId {
            chain_id: helix.beg_auth_asym_id.clone(),
            sequence_number: helix.beg_auth_seq_id,
            insertion_code: helix.beg_ins_code.clone(),
            residue_name: helix.beg_label_comp_id.clone(),
        };
        let end_id = ResidueId {
            chain_id: helix.end_auth_asym_id.clone(),
            sequence_number: helix.end_auth_seq_id,
            insertion_code: helix.end_ins_code.clone(),
            residue_name: helix.end_label_comp_id.clone(),
        };
        let (Some(&start_residue), Some(&end_residue)) = (
            residue_ref_by_id.get(&start_id),
            residue_ref_by_id.get(&end_id),
        ) else {
            continue;
        };

        alpha_helices.push(
            helix.helix_id.clone(),
            chain_ref,
            start_residue,
            end_residue,
            helix.helix_class.and_then(HelixClass::from_pdb_class),
            helix.helix_length,
        );
    }

    let mut beta_sheets = BetaSheets::default();
    for range in secondary.sheet_ranges.iter() {
        let Some(&chain_ref) = chain_ref_by_id.get(&range.beg_auth_asym_id) else {
            continue;
        };
        let start_id = ResidueId {
            chain_id: range.beg_auth_asym_id.clone(),
            sequence_number: range.beg_auth_seq_id,
            insertion_code: range.beg_ins_code.clone(),
            residue_name: range.beg_label_comp_id.clone(),
        };
        let end_id = ResidueId {
            chain_id: range.end_auth_asym_id.clone(),
            sequence_number: range.end_auth_seq_id,
            insertion_code: range.end_ins_code.clone(),
            residue_name: range.end_label_comp_id.clone(),
        };
        let (Some(&start_residue), Some(&end_residue)) = (
            residue_ref_by_id.get(&start_id),
            residue_ref_by_id.get(&end_id),
        ) else {
            continue;
        };

        let sense = secondary
            .sheet_sense_by_range
            .get(&(range.sheet_id.clone(), range.range_id.clone()))
            .copied()
            .or_else(|| {
                range
                    .range_id
                    .parse::<u32>()
                    .ok()
                    .filter(|&n| n == 1)
                    .map(|_| StrandSense::First)
            });

        beta_sheets.push(
            range.sheet_id.clone(),
            range.range_id.clone(),
            range.range_id.parse::<u32>().ok(),
            secondary.sheet_num_strands.get(&range.sheet_id).copied(),
            chain_ref,
            start_residue,
            end_residue,
            sense,
        );
    }

    let mut trc = TRC {
        topology,
        residues: Residues {
            residues: residues.values().cloned().map(Into::into).collect(),
            seqs: residue_seq.into_values().collect(),
            seq_ns: residue_seq_ids.into_values().collect(),
            insertion_codes: residue_insertion_codes.into_values().collect(),
            labels: None,
            labeled: None,
        },
        chains: Chains {
            chains: chains
                .values()
                .map(|chain| {
                    Chain(
                        chain
                            .iter()
                            .filter_map(|chain_residue_id| {
                                residue_ref_by_id.get(chain_residue_id).copied()
                            })
                            .collect(),
                    )
                })
                .collect(),
            alpha_helices: (!alpha_helices.is_empty()).then_some(alpha_helices),
            beta_sheets: (!beta_sheets.is_empty()).then_some(beta_sheets),
            labeled: Some(
                chain_ids
                    .iter()
                    .enumerate()
                    .map(|(i, _)| ChainRef(i as u32))
                    .collect::<Vec<_>>(),
            ),
            labels: Some(
                chain_ids
                    .into_iter()
                    .map(|chain_id| vec![chain_id])
                    .collect(),
            ),
        },
    };

    trc.topology.labels = Some(atom_labels);

    // Store amino acids as fragments, excluding empty residues
    trc.topology.fragments = Some(
        trc.residues
            .residues
            .iter()
            .filter(|Residue(atom_refs)| !atom_refs.is_empty())
            .map(|Residue(atom_refs)| Fragment(atom_refs.clone()))
            .collect(),
    );

    // Build connectivity
    trc.topology.connectivity = Some(
        connectivity_deduper
            .into_iter()
            .map(|((i, j), order)| {
                Bond(
                    AtomRef(i.min(j) as u32),
                    AtomRef(i.max(j) as u32),
                    BondOrder::from(order),
                )
            })
            .collect(),
    );

    // Add fragment formal charges
    trc.topology.fragment_formal_charges = Some(
        trc.residues
            .residues
            .iter()
            .filter(|Residue(atom_refs)| !atom_refs.is_empty())
            .map(|Residue(atom_refs)| {
                Ok(FormalCharge(
                    atom_refs
                        .iter()
                        .map(|AtomRef(atom_ref)| {
                            Ok(*atom_formal_charges
                                .get(*atom_ref as usize)
                                .ok_or(MmCifError::AtomChargeZip)?
                                as isize)
                        })
                        .collect::<Result<Vec<isize>, MmCifError>>()?
                        .into_iter()
                        .sum::<isize>() as i32,
                ))
            })
            .collect::<Result<Vec<FormalCharge>, MmCifError>>()?,
    );

    // Add atom charges
    trc.topology.formal_charges = Some(atom_formal_charges.into_iter().map(FormalCharge).collect());

    Ok(trc)
}

#[cfg(test)]
mod tests {
    use std::{
        fs::{self, File},
        io::Write as _,
        path::PathBuf,
    };

    use crate::convert::parity;
    use crate::convert::pdb::{from_pdb, to_pdb};

    use super::*;

    fn fixture_path(rel: &str) -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(rel)
    }

    fn read_fixture(rel: &str) -> String {
        fs::read_to_string(fixture_path(rel))
            .unwrap_or_else(|err| panic!("failed to read fixture {rel}: {err}"))
    }

    fn mmcif_fixture(rcsbid: &str) -> String {
        let rel = match rcsbid {
            "7pjq" => "tests/data/mmcif/7pjq.cif",
            "9atq" => "tests/data/mmcif/9atq.cif",
            "9dbu" => "tests/data/mmcif/9dbu.cif",
            "9gql" => "tests/data/mmcif/9gql.cif",
            "9hj7" => "tests/data/mmcif/9hj7.cif",
            "9jbd" => "tests/data/mmcif/9jbd.cif",
            "9jm5" => "tests/data/mmcif/9jm5.cif",
            _ => panic!("unknown test fixture id: {rcsbid}"),
        };
        read_fixture(rel)
    }

    fn pdb_fixture(rcsbid: &str) -> String {
        let rel = match rcsbid {
            "7pjq" => "tests/data/mmcif/7pjq.pdb",
            "9atq" => "tests/data/mmcif/9atq.pdb",
            "9dbu" => "tests/data/mmcif/9dbu.pdb",
            "9hj7" => "tests/data/mmcif/9hj7.pdb",
            "9jbd" => "tests/data/mmcif/9jbd.pdb",
            "9jm5" => "tests/data/mmcif/9jm5.pdb",
            _ => panic!("unknown test fixture id: {rcsbid}"),
        };
        read_fixture(rel)
    }

    #[test]
    fn parsing_9gql_succeeds() {
        let rcsbid = "9gql";
        let mmcif_content = mmcif_fixture(rcsbid);
        let mmcif_trcs = from_mmcif(mmcif_content).unwrap();
        for (model_idx, cif_trc) in mmcif_trcs.iter().enumerate() {
            let context = format!("{rcsbid} model {model_idx}");
            let pdb_output = to_pdb(cif_trc).unwrap();
            let re_parsed = from_pdb(pdb_output).unwrap();

            assert!(
                !re_parsed.is_empty(),
                "{context}: cif->pdb round-trip produced no models",
            );

            assert_eq!(
                cif_trc.topology.symbols.len(),
                re_parsed[0].topology.symbols.len(),
                "{context}: cif->pdb round-trip atom count mismatch \
                    (original {}, round-tripped {})",
                cif_trc.topology.symbols.len(),
                re_parsed[0].topology.symbols.len(),
            );
        }
    }

    #[test]
    fn local_reference_fixtures_match_pdb_parser() {
        let rcsbids = ["7pjq", "9atq", "9dbu", "9hj7", "9jbd", "9jm5"];
        for rcsbid in rcsbids {
            let mmcif_content = mmcif_fixture(rcsbid);
            let pdb_content = pdb_fixture(rcsbid);

            let mmcif_trcs = from_mmcif(mmcif_content).unwrap();
            let pdb_trcs = from_pdb(pdb_content).unwrap();

            assert_eq!(
                mmcif_trcs.len(),
                pdb_trcs.len(),
                "{rcsbid}: model count mismatch (mmcif {}, pdb {})",
                mmcif_trcs.len(),
                pdb_trcs.len(),
            );

            for (model_idx, (cif_trc, pdb_trc)) in
                mmcif_trcs.iter().zip(pdb_trcs.iter()).enumerate()
            {
                let context = format!("{rcsbid} model {model_idx}");

                if !parity::topology_matches_without_connectivity(
                    &pdb_trc.topology,
                    &cif_trc.topology,
                    parity::GEOMETRY_TOLERANCE,
                ) {
                    panic!(
                        "{context}: topology mismatch (excluding connectivity): {}",
                        parity::summarize_topology_mismatch(
                            pdb_trc,
                            cif_trc,
                            parity::GEOMETRY_TOLERANCE,
                        )
                    );
                }

                if cif_trc.residues != pdb_trc.residues {
                    panic!(
                        "{context}: residue metadata mismatch: {}",
                        parity::summarize_residue_mismatch(pdb_trc, cif_trc)
                    );
                }
                if cif_trc.chains != pdb_trc.chains {
                    panic!(
                        "{context}: chain metadata mismatch: {}",
                        parity::summarize_chain_mismatch(pdb_trc, cif_trc)
                    );
                }
            }

            for (model_idx, cif_trc) in mmcif_trcs.iter().enumerate() {
                let context = format!("{rcsbid} model {model_idx}");
                let pdb_output = to_pdb(cif_trc).unwrap();
                let re_parsed = from_pdb(pdb_output).unwrap();

                assert!(
                    !re_parsed.is_empty(),
                    "{context}: cif->pdb round-trip produced no models",
                );

                assert_eq!(
                    cif_trc.topology.symbols.len(),
                    re_parsed[0].topology.symbols.len(),
                    "{context}: cif->pdb round-trip atom count mismatch \
                    (original {}, round-tripped {})",
                    cif_trc.topology.symbols.len(),
                    re_parsed[0].topology.symbols.len(),
                );
            }
        }
    }

    #[test]
    fn test_mmcif_matches_pdb_secondary_structure() {
        let rcsbids = ["7pjq", "9atq", "9dbu", "9hj7", "9jbd", "9jm5"];
        for rcsbid in rcsbids {
            let mmcif_content = mmcif_fixture(rcsbid);
            let pdb_content = pdb_fixture(rcsbid);

            let mmcif_trc = from_mmcif(mmcif_content)
                .unwrap()
                .into_iter()
                .next()
                .expect("mmcif has at least one model");
            let pdb_trc = from_pdb(pdb_content)
                .unwrap()
                .into_iter()
                .next()
                .expect("pdb has at least one model");

            assert_eq!(
                canonical_helices(&mmcif_trc),
                canonical_helices(&pdb_trc),
                "helix mismatch for {rcsbid}"
            );
            assert_eq!(
                canonical_sheets(&mmcif_trc),
                canonical_sheets(&pdb_trc),
                "sheet mismatch for {rcsbid}"
            );
        }
    }

    fn chain_label(trc: &TRC, chain_ref: ChainRef) -> String {
        trc.chains
            .labels
            .as_ref()
            .and_then(|labels| labels.get(chain_ref.0 as usize))
            .and_then(|xs| xs.first())
            .cloned()
            .unwrap_or_default()
    }

    fn canonical_helices(
        trc: &TRC,
    ) -> Vec<(
        String,
        String,
        i32,
        String,
        String,
        i32,
        String,
        String,
        Option<u8>,
        Option<u32>,
    )> {
        let mut out = Vec::new();
        let Some(helices) = &trc.chains.alpha_helices else {
            return out;
        };

        for i in 0..helices.len() {
            let chain = chain_label(trc, helices.chain_refs[i]);
            let start = helices.start_residues[i].0 as usize;
            let end = helices.end_residues[i].0 as usize;
            out.push((
                helices.helix_ids[i].clone(),
                chain,
                trc.residues.seq_ns[start],
                trc.residues.insertion_codes[start].clone(),
                trc.residues.seqs[start].clone(),
                trc.residues.seq_ns[end],
                trc.residues.insertion_codes[end].clone(),
                trc.residues.seqs[end].clone(),
                helices.classes[i].map(|c| c as u8),
                helices.lengths[i],
            ));
        }

        out.sort();
        out
    }

    fn canonical_sheets(
        trc: &TRC,
    ) -> Vec<(
        String,
        String,
        Option<u32>,
        Option<u32>,
        String,
        i32,
        String,
        String,
        i32,
        String,
        String,
        Option<u8>,
    )> {
        let mut out = Vec::new();
        let Some(sheets) = &trc.chains.beta_sheets else {
            return out;
        };

        for i in 0..sheets.len() {
            let chain = chain_label(trc, sheets.chain_refs[i]);
            let start = sheets.start_residues[i].0 as usize;
            let end = sheets.end_residues[i].0 as usize;
            out.push((
                sheets.sheet_ids[i].clone(),
                sheets.strand_ids[i].clone(),
                sheets.strand_ordinals[i],
                sheets.num_strands[i],
                chain,
                trc.residues.seq_ns[start],
                trc.residues.insertion_codes[start].clone(),
                trc.residues.seqs[start].clone(),
                trc.residues.seq_ns[end],
                trc.residues.insertion_codes[end].clone(),
                trc.residues.seqs[end].clone(),
                sheets.senses[i].map(|s| s as u8),
            ));
        }

        out.sort();
        out
    }
}
