use std::{
    cmp::Ordering,
    collections::{BTreeMap, BTreeSet, HashMap},
    fmt::{self, Display, Formatter},
};

use itertools::Itertools as _;
#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

use crate::{
    AlphaHelices, AminoAcidSeq, AtomRef, BetaSheets, Bond, BondOrder, Chain, ChainRef, Chains,
    Element, FormalCharge, Fragment, HelixClass, Residue, ResidueRef, Residues, StrandSense, TRC,
    Topology,
};

#[derive(thiserror::Error, Debug)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub enum Error {
    #[error("invalid line length, expected '> {expected}', found '{found}'")]
    InvalidLineLength { expected: usize, found: usize },
    #[error("invalid line, expected '{expected}', found '{found}'")]
    InvalidLine { expected: String, found: String },
    #[error(
        "invalid connection for atom index {atom_idx}, references and atom that does not exist"
    )]
    InvalidConnection { atom_idx: u32 },
    #[error(
        "invalid bond order between {origin_element} {origin} and {target_element} {target} {distance}"
    )]
    InvalidBondOrder {
        origin: String,
        origin_element: String,
        target: String,
        target_element: String,
        distance: f32,
    },
    #[error("invalid symbol {symbol}")]
    InvalidSymbol { line: usize, symbol: String },
    #[error("expected int at {line}:{start}-{end}")]
    ExpectedInt {
        line: usize,
        start: usize,
        end: usize,
    },
    #[error("expected float at {line}:{start}-{end}")]
    ExpectedFloat {
        line: usize,
        start: usize,
        end: usize,
    },
    #[error("atom charges should zip with atoms")]
    AtomChargeZip,
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
struct ResidueId {
    chain_id: String,
    sequence_number: i32,
    insertion_code: String,
    residue_name: String,
}

impl Display for ResidueId {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}_{:…>9}_{}_{}",
            self.chain_id, self.sequence_number, self.insertion_code, self.residue_name
        )?;
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq)]
enum Line {
    Seqres(Seqres),
    Dbref(Dbref),
    Helix(Helix),
    Sheet(Sheet),
    Atom(Atom),
    Conect(Conect),
    Ter(Ter),
    Ignored(String),
    Model,
    EndModel,
    End,
}

fn ins_code_or_tilde(code: &str) -> String {
    if code.is_empty() {
        "~".to_string()
    } else {
        code.to_string()
    }
}

impl Line {
    fn try_from(value: &str, line: usize) -> Result<Self, Error> {
        if value.len() < 3 {
            return Err(Error::InvalidLineLength {
                expected: 3,
                found: value.len(),
            });
        }
        // In an ideal world, yes, but remark records sometimes exceeds it
        // if value.len() > 80 {
        //     return Err(Error::InvalidLineLength {
        //         expected: 80,
        //         found: value.len(),
        //     });
        // }
        if value.len() == 3 {
            if value == "END" {
                return Ok(Self::End);
            } else if value == "TER" {
                return Ok(Self::Ignored(value.to_string()));
            } else {
                return Err(Error::InvalidLine {
                    expected: "END".to_string(),
                    found: value.to_string(),
                });
            }
        }
        if value.len() < 6 {
            return Err(Error::InvalidLineLength {
                expected: 6,
                found: value.len(),
            });
        }
        let value = format!("{value:<80}");
        let line_id = &value[0..6];
        match line_id {
            "SEQRES" => Self::try_from_seqres(&value, line),
            "DBREF " => Self::try_from_dbref(&value, line),
            "HELIX " => Self::try_from_helix(&value, line),
            "SHEET " => Self::try_from_sheet(&value, line),
            "ATOM  " => Self::try_from_atom(&value, line),
            "HETATM" => Self::try_from_hetatm(&value, line),
            "CONECT" => Self::try_from_conect(&value, line),
            "TER   " => Self::try_from_ter(&value, line),
            "MODEL " => Ok(Self::Model),
            "ENDMDL" => Ok(Self::EndModel),
            "END   " => Ok(Self::End),
            _ => Ok(Self::Ignored(value.to_string())),
        }
    }

    fn try_from_seqres(value: &str, line: usize) -> Result<Self, Error> {
        Ok(Self::Seqres(Seqres {
            ser_num: Self::parse_u32(value, 7, 10, line)?,
            chain_id: Self::parse_str(value, 11, 12, line),
            num_res: Self::parse_u32(value, 13, 17, line)?,
            seq: {
                let mut chars = value.get(19..).unwrap_or("").chars().peekable();
                std::iter::from_fn(|| {
                    chars.peek()?;
                    let chunk: String = chars.by_ref().take(3).collect();
                    chars.next(); // skip the space
                    let trimmed = chunk.trim().to_string();
                    if trimmed.is_empty() {
                        None
                    } else {
                        Some(trimmed)
                    }
                })
                .collect()
            },
        }))
    }

    fn try_from_dbref(value: &str, line: usize) -> Result<Self, Error> {
        Ok(Self::Dbref(Dbref {
            chain_id: Self::parse_str(value, 12, 13, line),
            seq_begin: Self::parse_i32(value, 14, 18, line)?,
        }))
    }

    fn parse_opt_i32(
        value: &str,
        start: usize,
        end: usize,
        line: usize,
    ) -> Result<Option<i32>, Error> {
        Self::trace_parser(value, start, end);

        if value[start..end].trim() == "" {
            return Ok(None);
        }
        value[start..end]
            .trim()
            .parse()
            .map(Some)
            .map_err(|_source| Error::ExpectedInt { line, start, end })
    }

    fn try_from_helix(value: &str, line: usize) -> Result<Self, Error> {
        // https://www.wwpdb.org/documentation/file-format-content/format33/sect5.html#HELIX
        Ok(Self::Helix(Helix {
            ser_num: Self::parse_i32(value, 7, 10, line)?,
            helix_id: Self::parse_str(value, 11, 14, line),
            init_res_name: Self::parse_str(value, 15, 18, line),
            init_chain_id: Self::parse_str(value, 19, 20, line),
            init_seq_num: Self::parse_i32(value, 21, 25, line)?,
            init_insert_code: ins_code_or_tilde(&Self::parse_str(value, 25, 26, line)),
            end_res_name: Self::parse_str(value, 27, 30, line),
            end_chain_id: Self::parse_str(value, 31, 32, line),
            end_seq_num: Self::parse_i32(value, 33, 37, line)?,
            end_insert_code: ins_code_or_tilde(&Self::parse_str(value, 37, 38, line)),
            helix_class: Self::parse_opt_i32(value, 38, 40, line)?.unwrap_or(0),
            length: Self::parse_opt_i32(value, 71, 76, line)?.unwrap_or(0),
        }))
    }

    fn try_from_sheet(value: &str, line: usize) -> Result<Self, Error> {
        // https://www.wwpdb.org/documentation/file-format-content/format33/sect5.html#SHEET
        Ok(Self::Sheet(Sheet {
            strand: Self::parse_i32(value, 7, 10, line)?,
            sheet_id: Self::parse_str(value, 11, 14, line),
            num_strands: Self::parse_opt_i32(value, 14, 16, line)?.unwrap_or(0),
            init_res_name: Self::parse_str(value, 17, 20, line),
            init_chain_id: Self::parse_str(value, 21, 22, line),
            init_seq_num: Self::parse_i32(value, 22, 26, line)?,
            init_insert_code: ins_code_or_tilde(&Self::parse_str(value, 26, 27, line)),
            end_res_name: Self::parse_str(value, 28, 31, line),
            end_chain_id: Self::parse_str(value, 32, 33, line),
            end_seq_num: Self::parse_i32(value, 33, 37, line)?,
            end_insert_code: ins_code_or_tilde(&Self::parse_str(value, 37, 38, line)),
            sense: Self::parse_opt_i32(value, 38, 40, line)?.unwrap_or(0),
            cur_atom: Self::parse_str(value, 41, 45, line),
            cur_res_name: Self::parse_str(value, 45, 48, line),
            cur_chain_id: Self::parse_str(value, 49, 50, line),
            cur_res_seq: Self::parse_opt_i32(value, 50, 54, line)?.unwrap_or(0),
            cur_insert_code: ins_code_or_tilde(&Self::parse_str(value, 54, 55, line)),
            prev_atom: Self::parse_str(value, 56, 60, line),
            prev_res_name: Self::parse_str(value, 60, 63, line),
            prev_chain_id: Self::parse_str(value, 64, 65, line),
            prev_res_seq: Self::parse_opt_i32(value, 65, 69, line)?.unwrap_or(0),
            prev_insert_code: ins_code_or_tilde(&Self::parse_str(value, 69, 70, line)),
        }))
    }

    fn try_from_atom(value: &str, line: usize) -> Result<Self, Error> {
        Ok(Self::Atom(Atom {
            // LINE_ID [0 .. 6)
            atom_idx: Self::parse_u32(value, 6, 11, line)?,
            // UNUSED [11 .. 12)
            atom_name: Self::parse_str(value, 12, 16, line),
            alternate_location: Self::parse_opt_str(value, 16, 17, line),
            residue_name: Self::parse_str(value, 17, 20, line),
            // UNUSED [20 .. 21)
            chain_id: Self::parse_str(value, 21, 22, line),
            sequence_number: Self::parse_i32(value, 22, 26, line)?,
            residue_insertion: Self::parse_opt_str(value, 26, 27, line),
            // UNUSED [27 .. 30)
            atom_x: Self::parse_f32(value, 30, 38, line)?,
            atom_y: Self::parse_f32(value, 38, 46, line)?,
            atom_z: Self::parse_f32(value, 46, 54, line)?,
            occupancy: Self::parse_f32(value, 54, 60, line)?,
            temperature_factor: Self::parse_f32(value, 60, 66, line)?,
            // UNUSED [66 .. 72)
            segment_id: Self::parse_opt_str(value, 72, 76, line),
            element_symbol: Self::parse_element(value, 76, 78, line)?,
            charge: Self::parse_opt_charge(value, 78, 80, line)?.unwrap_or_default(),
            is_het_atom: false,
        }))
    }

    fn try_from_hetatm(value: &str, line: usize) -> Result<Self, Error> {
        Self::try_from_atom(value, line).map(|line| match line {
            Self::Atom(atom) => Self::Atom(Atom {
                is_het_atom: true,
                ..atom
            }),
            x => x,
        })
    }

    fn try_from_conect(value: &str, line: usize) -> Result<Self, Error> {
        let mut atom_idxs = Vec::with_capacity(15); // 15 is the maximum number of connections that fit in a single line

        let mut start = 6;
        let mut end = 11;
        while start < value.len() && end <= value.len() {
            let opt_atom_idx = Self::parse_opt_u32(value, start, end, line)?;
            match opt_atom_idx {
                Some(atom_idx) => atom_idxs.push(atom_idx),
                _ => break,
            }
            start += 5;
            end += 5;
        }

        Ok(Self::Conect(Conect { atom_idxs }))
    }

    fn try_from_ter(value: &str, line: usize) -> Result<Self, Error> {
        Ok(Self::Ter(Ter {
            // LINE_ID [0 .. 6)
            // Not used for anything and some underlying tooling just prints TER                    243
            // so we can default it
            atom_idx: Self::parse_u32(value, 6, 11, line).unwrap_or_default(),
            // UNUSED [11 .. 17)
            residue_name: Self::parse_str(value, 17, 20, line),
            // UNUSED [20 .. 21)
            chain_id: Self::parse_str(value, 21, 22, line),
            residue_idx: Self::parse_i32(value, 22, 26, line).unwrap_or_default(),
            // UNUSED [26 .. 80)
        }))
    }

    fn parse_opt_charge(
        value: &str,
        start: usize,
        end: usize,
        line: usize,
    ) -> Result<Option<i32>, Error> {
        Self::trace_parser(value, start, end);

        let trimmed = value[start..end].trim();
        if trimmed.is_empty() {
            return Ok(None);
        }

        if trimmed.ends_with('+') || trimmed.ends_with('-') {
            trimmed[..trimmed.len() - 1]
                .parse::<i32>()
                .map(|v| Some(v * if trimmed.ends_with('-') { -1 } else { 1 }))
                .map_err(|_source| Error::ExpectedInt { line, start, end })
        } else {
            trimmed
                .parse()
                .map(Some)
                .map_err(|_source| Error::ExpectedInt { line, start, end })
        }
    }

    fn parse_u32(value: &str, start: usize, end: usize, line: usize) -> Result<u32, Error> {
        Self::trace_parser(value, start, end);

        value[start..end]
            .trim()
            .parse()
            .map_err(|_source| Error::ExpectedInt { line, start, end })
    }

    fn parse_i32(value: &str, start: usize, end: usize, line: usize) -> Result<i32, Error> {
        Self::trace_parser(value, start, end);

        value[start..end]
            .trim()
            .parse()
            .map_err(|_source| Error::ExpectedInt { line, start, end })
    }

    fn parse_opt_u32(
        value: &str,
        start: usize,
        end: usize,
        line: usize,
    ) -> Result<Option<u32>, Error> {
        Self::trace_parser(value, start, end);

        if value[start..end].trim() == "" {
            return Ok(None);
        }
        value[start..end]
            .trim()
            .parse()
            .map(Some)
            .map_err(|_source| Error::ExpectedInt { line, start, end })
    }

    fn parse_f32(value: &str, start: usize, end: usize, line: usize) -> Result<f32, Error> {
        Self::trace_parser(value, start, end);

        value[start..end]
            .trim()
            .parse()
            .map_err(|_source| Error::ExpectedFloat { line, start, end })
    }

    fn parse_str(value: &str, start: usize, end: usize, _line: usize) -> String {
        Self::trace_parser(value, start, end);

        value[start..end].trim().to_string()
    }

    fn parse_element(value: &str, start: usize, end: usize, line: usize) -> Result<Element, Error> {
        Self::trace_parser(value, start, end);

        value[start..end]
            .trim()
            .try_into()
            .map_err(|symbol| Error::InvalidSymbol { line, symbol })
    }

    fn parse_opt_str(value: &str, start: usize, end: usize, _line: usize) -> Option<String> {
        Self::trace_parser(value, start, end);

        if value[start..end].trim() == "" {
            return None;
        }
        Some(value[start..end].trim().to_string())
    }

    fn trace_parser(value: &str, start: usize, end: usize) {
        tracing::debug!("{:<80}", value);
        if end > start + 1 {
            tracing::debug!("{:>2$}{:^>3$}", "^", "^", start + 1, end - start - 1);
        } else {
            tracing::debug!("{:>1$}", "^", start + 1);
        }
        tracing::debug!("{:>1$}", &value[start..end], end);
    }

    fn try_to_string(&self) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {
        match self {
            Self::Seqres(seqres) => Ok(seqres.to_string()),
            Self::Dbref(_dbref) => Err("Line::Dbref: Cannot convert to string".into()),
            Self::Helix(helix) => Ok(helix.to_string()),
            Self::Sheet(sheet) => Ok(sheet.to_string()),
            Self::Atom(atom) => Ok(atom.to_string()),
            Self::Conect(conect) => Ok(conect.try_to_string()?),
            Self::Ter(ter) => Ok(ter.to_string()),
            Self::Ignored(ignored) => Ok(ignored.to_string()),
            Self::End => Ok("END".to_string()),
            Self::Model => Ok("MODEL ".to_string()), // FIXME: Figure out model indices
            Self::EndModel => Ok("ENDMDL".to_string()),
        }
    }
}

fn put_left(dst: &mut [u8], s: &str) {
    let bytes = s.as_bytes();
    let n = bytes.len().min(dst.len());
    dst[..n].copy_from_slice(&bytes[..n]);
}

fn put_right(dst: &mut [u8], s: &str) {
    let bytes = s.as_bytes();
    let n = bytes.len().min(dst.len());
    let len = dst.len();
    dst[len - n..].copy_from_slice(&bytes[..n]);
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct Helix {
    pub ser_num: i32,
    pub helix_id: String,
    pub init_res_name: String,
    pub init_chain_id: String,
    pub init_seq_num: i32,
    pub init_insert_code: String,
    pub end_res_name: String,
    pub end_chain_id: String,
    pub end_seq_num: i32,
    pub end_insert_code: String,
    pub helix_class: i32,
    pub length: i32,
}

impl Display for Helix {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        // Fixed-width HELIX record formatting (v3.3-ish); only fields we parse are written.
        let mut buf = [b' '; 80];

        put_left(&mut buf[0..6], "HELIX ");
        put_right(&mut buf[7..10], &format!("{:>3}", self.ser_num));
        put_left(&mut buf[11..14], &self.helix_id);
        put_left(&mut buf[15..18], &self.init_res_name);
        put_left(&mut buf[19..20], &self.init_chain_id);
        put_right(&mut buf[21..25], &format!("{:>4}", self.init_seq_num));
        let init_ins = self.init_insert_code.as_str();
        if init_ins != "~" && !init_ins.is_empty() {
            put_left(&mut buf[25..26], init_ins);
        }
        put_left(&mut buf[27..30], &self.end_res_name);
        put_left(&mut buf[31..32], &self.end_chain_id);
        put_right(&mut buf[33..37], &format!("{:>4}", self.end_seq_num));
        let end_ins = self.end_insert_code.as_str();
        if end_ins != "~" && !end_ins.is_empty() {
            put_left(&mut buf[37..38], end_ins);
        }
        if self.helix_class != 0 {
            put_right(&mut buf[38..40], &format!("{:>2}", self.helix_class));
        }
        if self.length != 0 {
            put_right(&mut buf[71..76], &format!("{:>5}", self.length));
        }

        let s = std::str::from_utf8(&buf).map_err(|_| fmt::Error)?;
        f.write_str(s)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct Sheet {
    pub strand: i32,
    pub sheet_id: String,
    pub num_strands: i32,
    pub init_res_name: String,
    pub init_chain_id: String,
    pub init_seq_num: i32,
    pub init_insert_code: String,
    pub end_res_name: String,
    pub end_chain_id: String,
    pub end_seq_num: i32,
    pub end_insert_code: String,
    pub sense: i32,
    pub cur_atom: String,
    pub cur_res_name: String,
    pub cur_chain_id: String,
    pub cur_res_seq: i32,
    pub cur_insert_code: String,
    pub prev_atom: String,
    pub prev_res_name: String,
    pub prev_chain_id: String,
    pub prev_res_seq: i32,
    pub prev_insert_code: String,
}

impl Display for Sheet {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        // Fixed-width SHEET record formatting (v3.3-ish); only fields we parse are written.
        let mut buf = [b' '; 80];

        put_left(&mut buf[0..6], "SHEET ");
        put_right(&mut buf[7..10], &format!("{:>3}", self.strand));
        put_left(&mut buf[11..14], &self.sheet_id);
        if self.num_strands != 0 {
            put_right(&mut buf[14..16], &format!("{:>2}", self.num_strands));
        }
        put_left(&mut buf[17..20], &self.init_res_name);
        put_left(&mut buf[21..22], &self.init_chain_id);
        put_right(&mut buf[22..26], &format!("{:>4}", self.init_seq_num));
        let init_ins = self.init_insert_code.as_str();
        if init_ins != "~" && !init_ins.is_empty() {
            put_left(&mut buf[26..27], init_ins);
        }
        put_left(&mut buf[28..31], &self.end_res_name);
        put_left(&mut buf[32..33], &self.end_chain_id);
        put_right(&mut buf[33..37], &format!("{:>4}", self.end_seq_num));
        let end_ins = self.end_insert_code.as_str();
        if end_ins != "~" && !end_ins.is_empty() {
            put_left(&mut buf[37..38], end_ins);
        }
        if self.sense != 0 {
            put_right(&mut buf[38..40], &format!("{:>2}", self.sense));
        } else {
            put_right(&mut buf[38..40], " 0");
        }

        // Optional H-bond registration fields (we keep them if provided).
        put_left(&mut buf[41..45], &self.cur_atom);
        put_left(&mut buf[45..48], &self.cur_res_name);
        put_left(&mut buf[49..50], &self.cur_chain_id);
        if self.cur_res_seq != 0 {
            put_right(&mut buf[50..54], &format!("{:>4}", self.cur_res_seq));
        }
        let cur_ins = self.cur_insert_code.as_str();
        if cur_ins != "~" && !cur_ins.is_empty() {
            put_left(&mut buf[54..55], cur_ins);
        }

        put_left(&mut buf[56..60], &self.prev_atom);
        put_left(&mut buf[60..63], &self.prev_res_name);
        put_left(&mut buf[64..65], &self.prev_chain_id);
        if self.prev_res_seq != 0 {
            put_right(&mut buf[65..69], &format!("{:>4}", self.prev_res_seq));
        }
        let prev_ins = self.prev_insert_code.as_str();
        if prev_ins != "~" && !prev_ins.is_empty() {
            put_left(&mut buf[69..70], prev_ins);
        }

        let s = std::str::from_utf8(&buf).map_err(|_| fmt::Error)?;
        f.write_str(s)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct Seqres {
    ser_num: u32,
    chain_id: String,
    num_res: u32,
    seq: Vec<String>,
}

impl Display for Seqres {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "SEQRES {:>3} {:>1} {:>4} ",
            self.ser_num, self.chain_id, self.num_res,
        )?;
        for seq_elem in &self.seq {
            write!(f, " {seq_elem}")?;
        }
        write!(f, "          ")
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct Dbref {
    chain_id: String,
    seq_begin: i32,
}

#[derive(Clone, Debug, PartialEq)]
struct Atom {
    atom_idx: u32,
    atom_name: String,
    alternate_location: Option<String>,
    residue_name: String,
    chain_id: String,
    sequence_number: i32,
    residue_insertion: Option<String>,
    atom_x: f32,
    atom_y: f32,
    atom_z: f32,
    occupancy: f32,
    temperature_factor: f32,
    segment_id: Option<String>,
    element_symbol: Element,
    charge: i32,
    is_het_atom: bool,
}

impl Display for Atom {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        // the formatting behaviour is strange - not quite left or right aligned depending
        // on the name length
        // ATOM     14  CD1 ILE H  16       5.687  -5.180  20.042  1.00 16.16           C
        // ATOM     15  H   ILE H  16       5.719  -8.041  17.843  1.00 15.91           H
        // ATOM     16  HA  ILE H  16       5.011  -8.089  19.908  1.00 14.62           H
        // ATOM     17  HB  ILE H  16       2.748  -6.457  18.674  1.00 16.05           H
        // ATOM     18 HG13 ILE H  16       3.987  -4.470  18.959  1.00 14.52           H
        // ATOM     19 HG12 ILE H  16       4.979  -5.543  18.043  1.00 14.52           H
        // ATOM     20 HG21 ILE H  16       2.577  -5.253  20.823  1.00 16.45           H
        // ATOM     21 HG22 ILE H  16       2.045  -6.916  20.934  1.00 16.45           H
        // ATOM     22 HG23 ILE H  16       3.626  -6.474  21.558  1.00 16.45           H
        // ATOM     23 HD11 ILE H  16       6.596  -4.859  19.533  1.00 16.16           H
        // ATOM     24 HD12 ILE H  16       5.417  -4.409  20.763  1.00 16.16           H
        let atom_name = match self.atom_name.len() {
            0 => format!(" {}", self.atom_name),
            1 => format!(" {}", self.atom_name),
            2 => format!(" {}", self.atom_name),
            3 => format!(" {}", self.atom_name),
            4 => self.atom_name.clone(),
            _ => {
                // invalid name
                return Err(fmt::Error);
            }
        };
        write!(
            f,
            "{:<6.6}{:>5.5} {:<4.4}{:<1.1}{:>3.3} {:>1.1}{:>4.4}{:>1.1}   {:>8.3}{:>8.3}{:>8.3}{:>6.2}{:>6.2}      {:<4.4}{:>2.2}{:>2.2}",
            if self.is_het_atom { "HETATM" } else { "ATOM" },
            self.atom_idx,
            atom_name,
            self.alternate_location.clone().unwrap_or_default(),
            self.residue_name,
            self.chain_id,
            self.sequence_number,
            self.residue_insertion.clone().unwrap_or_default(),
            self.atom_x,
            self.atom_y,
            self.atom_z,
            self.occupancy,
            self.temperature_factor,
            self.segment_id.clone().unwrap_or_default(),
            format!("{}", self.element_symbol),
            match self.charge.cmp(&0) {
                Ordering::Greater => format!("{}+", self.charge),
                Ordering::Less => format!("{}-", -self.charge),
                Ordering::Equal => "".to_string(),
            }
        )
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Conect {
    atom_idxs: Vec<u32>,
}

impl Conect {
    fn try_to_string(&self) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {
        if self.atom_idxs.len() < 2 {
            Err("CONECT with less than 2 atoms not supported".into())
        } else if self.atom_idxs.len() == 2 {
            Ok(format!(
                "CONECT{:>5}{:>5}",
                self.atom_idxs[0], self.atom_idxs[1]
            ))
        } else if self.atom_idxs.len() == 3 {
            Ok(format!(
                "CONECT{:>5}{:>5}{:>10}",
                self.atom_idxs[0], self.atom_idxs[1], self.atom_idxs[2],
            ))
        } else if self.atom_idxs.len() == 4 {
            Ok(format!(
                "CONECT{:>5}{:>5}{:>10}{:>5}",
                self.atom_idxs[0], self.atom_idxs[1], self.atom_idxs[2], self.atom_idxs[3],
            ))
        } else {
            Err("CONECT with more than 4 atoms not supported".into())
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct Ter {
    atom_idx: u32,
    residue_name: String,
    chain_id: String,
    residue_idx: i32,
}

impl Display for Ter {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "TER   {:>5}      {:>3} {:>1}{:>4}",
            self.atom_idx, self.residue_name, self.chain_id, self.residue_idx
        )
    }
}

pub fn from_pdb(pdb_contents: impl AsRef<str>) -> Result<Vec<TRC>, Error> {
    from_pdb_with_options(pdb_contents, true)
}

/// Parse a PDB string into one or more TRC models.
///
/// When `include_seqres` is true (the default in `from_pdb`), empty
/// `Residue(vec![])` entries are created for SEQRES positions that have
/// no ATOM records, preserving the full construct sequence.
pub fn from_pdb_with_options(
    pdb_contents: impl AsRef<str>,
    include_seqres: bool,
) -> Result<Vec<TRC>, Error> {
    let mut global_connectivity = Vec::<(u32, u32, u8)>::new();
    let mut global_helices = Vec::<Helix>::new();
    let mut global_sheets = Vec::<Sheet>::new();
    let mut trcs = Vec::new();
    let mut trc_atom_ids = Vec::new();
    let mut seqres_chains: BTreeMap<String, Vec<String>> = BTreeMap::new();
    let mut dbref_seq_begins: BTreeMap<String, i32> = BTreeMap::new();

    let mut lines = pdb_contents.as_ref().lines().enumerate();
    loop {
        let mut topology = Topology::default();

        // Vector of atom identities that zips with the `atoms` vector.
        let mut atom_ids = Vec::new();
        // Vector of atom names. An atom name identifies the element symbol and
        // (optionally) its position within an amino acid.
        let mut atom_labels = Vec::new();
        // Vector of atom symbols that zips with the `atoms` vector.
        let mut atom_symbols = Vec::new();
        // Vector of atom charges that zips with the `atoms` vector.
        let mut atom_formal_charges = Vec::new();
        // Mapping of atom identities to a vector of alternative xyz coordinates for
        // that atom. This does not include the canonical coordinates.
        let mut alts = BTreeMap::<_, Vec<_>>::new();

        // Set of residue identities. An identity is guaranteed to be unique within
        // a model.
        let mut residue_ids = BTreeSet::new();
        // Mapping of residue identities to residue names. A residue name identifies
        // the type of residue (e.g. "LIG" for ligand).
        let mut residue_seq = BTreeMap::new();
        // Mapping of residue identities to a vector of atom indices (referenceing
        // the `atoms` vector) that are part of the residue.
        let mut residues = BTreeMap::<_, Vec<_>>::new();
        let mut residue_seq_ids = BTreeMap::new();
        let mut residue_insertion_codes = BTreeMap::new();

        // Mapping of chain identities (a.k.a. subunits and substructures) to a
        // vector of atom indices (referencing the `residues` vector) that are part of
        // the chain.
        let mut chains = BTreeMap::<_, BTreeSet<_>>::new();

        let mut connectivity = Vec::<(u32, u32, u8)>::new();

        let mut in_model = false;
        let mut eof = false;
        loop {
            // Load the next line and exit from the inner loop if there is no
            // next line. The outer loop with then attempt to finalize the
            // processing of any model that was being built, and then exit the
            // outer loop.
            let line = lines.next();
            if line.is_none() {
                eof = true;
                break;
            }
            let (i, line) = line.unwrap();
            let line = Line::try_from(line, i + 1)?;

            match line {
                Line::Model => {
                    in_model = true;
                }
                Line::EndModel => {
                    in_model = false;
                    break;
                }
                Line::Seqres(seqres) => {
                    seqres_chains
                        .entry(seqres.chain_id)
                        .or_default()
                        .extend(seqres.seq);
                }
                Line::Dbref(dbref) => {
                    dbref_seq_begins
                        .entry(dbref.chain_id)
                        .or_insert(dbref.seq_begin);
                }
                Line::Helix(helix) => {
                    global_helices.push(helix);
                }
                Line::Sheet(sheet) => {
                    global_sheets.push(sheet);
                }
                Line::Atom(atom) => {
                    in_model = true;

                    // To have a unique identifier for the residue, we need to
                    // combine:
                    //   - chain ID (indices can reset between chains)
                    //   - the sequence number
                    //   - the insertion code (disambiguates between residues
                    //     with the same sequence number)
                    //   - the residue name (yes, all the above still be the
                    //     same if the residue name differs)
                    //
                    // "Together, columns 23-27 make a sequence ID, which is a
                    //  mostly-numeric ID of the residue position.
                    //
                    //  Note: It's not a full ID of the residue. When you have a
                    //  point mutation (a.k.a. microheterogeneity) you have 2+
                    //  residues with partial occupancy at the same position. To
                    //  fully identify a residue both the sequence ID and
                    //  residue name are needed." ―
                    //  https://bioinformatics.stackexchange.com/a/11590
                    let residue_id = ResidueId {
                        chain_id: atom.chain_id.clone(),
                        sequence_number: atom.sequence_number,
                        insertion_code: atom.residue_insertion.clone().unwrap_or("~".to_string()),
                        residue_name: atom.residue_name.clone(),
                    };

                    match atom.alternate_location.as_deref() {
                        Some("A") | None => {
                            topology.symbols.push(atom.element_symbol);
                            topology.geometry.extend_from_slice(&[
                                atom.atom_x,
                                atom.atom_y,
                                atom.atom_z,
                            ]);

                            residue_ids.insert(residue_id.clone());
                            residue_seq.insert(residue_id.clone(), atom.residue_name);
                            residues
                                .entry(residue_id.clone())
                                .or_default()
                                .push((topology.symbols.len() - 1) as u32);
                            residue_seq_ids.insert(residue_id.clone(), atom.sequence_number);
                            residue_insertion_codes.insert(
                                residue_id.clone(),
                                atom.residue_insertion.clone().unwrap_or_default(),
                            );

                            atom_ids.push(atom.atom_idx);
                            atom_labels.push(atom.atom_name);
                            atom_symbols.push(atom.element_symbol);
                            atom_formal_charges.push(atom.charge);

                            chains.entry(atom.chain_id).or_default().insert(residue_id);
                        }
                        _ => {
                            alts.entry(atom.atom_idx)
                                .or_default()
                                .push(([atom.atom_x, atom.atom_y, atom.atom_z], atom.charge));
                        }
                    }
                }
                Line::Conect(conect) => {
                    let origin = conect.atom_idxs[0];
                    for target in conect.atom_idxs.into_iter().skip(1) {
                        if in_model {
                            connectivity.push((origin, target, 1));
                        } else {
                            global_connectivity.push((origin, target, 1));
                        }
                    }
                }
                _ => {
                    // TOOD: Support for other lines.
                }
            }
        }

        if topology.symbols.is_empty() {
            if in_model {
                tracing::warn!(
                    "No ATOM lines found despite being in a model; PDB file may be malformed"
                );
            }
            if !connectivity.is_empty() {
                tracing::warn!(
                    "CONECT lines found but no ATOM lines found for this model; PDB file may be malformed"
                );
            }
            if eof {
                // No model was found and the end of the file was reached.
                // Exit the outer loop.
                break;
            } else {
                // No model was found but we are not at the end of the file,
                // so we must re-enter the inner loop.
                continue;
            }
        }

        // Process SEQRES: inject empty residues or warn about missing internal ones
        for (chain_id, seqres_names) in &seqres_chains {
            let existing_seq_ns: BTreeSet<i32> = residue_ids
                .iter()
                .filter(|rid| &rid.chain_id == chain_id)
                .map(|rid| rid.sequence_number)
                .collect();

            let (Some(&min_resolved), Some(&max_resolved)) = (
                existing_seq_ns.iter().next(),
                existing_seq_ns.iter().next_back(),
            ) else {
                continue;
            };

            // Determine the sequence number offset for SEQRES positions.
            // SEQRES position p corresponds to seq_n = offset + p.
            let offset = if let Some(&seq_begin) = dbref_seq_begins.get(chain_id) {
                // DBREF provides the starting sequence number directly
                // TODO: SEQADV needs to be considered as well (e.g. 3qqk)
                seq_begin
            } else {
                // Fallback: match the first resolved residue name in SEQRES
                let first_resolved_name = residue_ids
                    .iter()
                    .find(|rid| &rid.chain_id == chain_id && rid.sequence_number == min_resolved)
                    .map(|rid| &rid.residue_name);
                if let Some(name) = first_resolved_name {
                    if let Some(pos) = seqres_names.iter().position(|s| s == name) {
                        min_resolved - pos as i32
                    } else {
                        tracing::warn!(
                            "WARNING: chain {chain_id}: could not align SEQRES with ATOM \
                            records (residue {name} at seq_n {min_resolved} not found in \
                            SEQRES). Skipping SEQRES processing for this chain.",
                        );
                        continue;
                    }
                } else {
                    continue;
                }
            };

            let mut missing_internal = Vec::new();
            for (p, seqres_name) in seqres_names.iter().enumerate() {
                let seq_n = offset + p as i32;
                if existing_seq_ns.contains(&seq_n) {
                    continue;
                }

                let is_internal = seq_n > min_resolved && seq_n < max_resolved;

                if include_seqres {
                    let rid = ResidueId {
                        chain_id: chain_id.clone(),
                        sequence_number: seq_n,
                        insertion_code: "~".to_string(),
                        residue_name: seqres_name.clone(),
                    };

                    residue_ids.insert(rid.clone());
                    residue_seq.insert(rid.clone(), seqres_name.clone());
                    residues.insert(rid.clone(), vec![]);
                    residue_seq_ids.insert(rid.clone(), seq_n);
                    residue_insertion_codes.insert(rid.clone(), String::new());
                    chains.entry(chain_id.clone()).or_default().insert(rid);
                } else if is_internal {
                    missing_internal.push((seq_n, seqres_name.as_str()));
                }
            }

            if include_seqres {
                let seqres_begin = offset;
                let seqres_end = offset + seqres_names.len() as i32 - 1;
                let n_terminal_empty = (seqres_begin..min_resolved).count()
                    + ((max_resolved + 1)..=seqres_end).count();
                if n_terminal_empty > 10 {
                    tracing::warn!(
                        "WARNING: chain {chain_id} has {n_terminal_empty} empty terminal \
                        residues from SEQRES (resolved range: {min_resolved}-{max_resolved}, \
                        SEQRES range: {seqres_begin}-{seqres_end}). \
                        Use from_pdb_with_options(..., false) to exclude them.",
                    );
                }
            }

            if !missing_internal.is_empty() {
                tracing::warn!(
                    "WARNING: chain {chain_id} has {} missing internal residue(s) from SEQRES \
                    that are being omitted because include_seqres is false: {}",
                    missing_internal.len(),
                    missing_internal
                        .iter()
                        .map(|(n, name)| format!("{name} {n}"))
                        .collect::<Vec<_>>()
                        .join(", "),
                );
            }
        }

        let mut trc = TRC {
            topology,
            residues: Residues {
                residues: residues.values().cloned().map(Into::into).collect(),
                seqs: residue_seq.into_values().collect(),
                seq_ns: residue_seq_ids.into_values().collect(),
                insertion_codes: residue_insertion_codes.into_values().collect(),
                labels: None,
                labeled: None,
            },
            chains: {
                let residue_ref_by_id = residue_ids
                    .iter()
                    .enumerate()
                    .map(|(i, residue_id)| (residue_id.clone(), ResidueRef(i as u32)))
                    .collect::<BTreeMap<_, _>>();
                let chain_ids: Vec<String> = chains.keys().cloned().collect();
                let chain_ref_by_id = chain_ids
                    .iter()
                    .enumerate()
                    .map(|(i, chain_id)| (chain_id.clone(), ChainRef(i as u32)))
                    .collect::<HashMap<_, _>>();

                Chains {
                    chains: {
                        chains
                            .values()
                            .map(|chain| {
                                Chain(
                                    chain
                                        .iter()
                                        .filter_map(|chain_residue_id| {
                                            residue_ref_by_id.get(chain_residue_id).copied()
                                        })
                                        .collect(),
                                )
                            })
                            .collect()
                    },
                    alpha_helices: {
                        let mut alpha_helices = AlphaHelices::default();
                        for helix in global_helices.iter() {
                            let Some(&chain_ref) = chain_ref_by_id.get(&helix.init_chain_id) else {
                                continue;
                            };
                            let start_id = ResidueId {
                                chain_id: helix.init_chain_id.clone(),
                                sequence_number: helix.init_seq_num,
                                insertion_code: helix.init_insert_code.clone(),
                                residue_name: helix.init_res_name.clone(),
                            };
                            let end_id = ResidueId {
                                chain_id: helix.end_chain_id.clone(),
                                sequence_number: helix.end_seq_num,
                                insertion_code: helix.end_insert_code.clone(),
                                residue_name: helix.end_res_name.clone(),
                            };
                            let (Some(&start_residue), Some(&end_residue)) = (
                                residue_ref_by_id.get(&start_id),
                                residue_ref_by_id.get(&end_id),
                            ) else {
                                continue;
                            };

                            alpha_helices.push(
                                helix.helix_id.clone(),
                                chain_ref,
                                start_residue,
                                end_residue,
                                HelixClass::from_pdb_class(helix.helix_class),
                                (helix.length > 0).then_some(helix.length as u32),
                            );
                        }
                        (!alpha_helices.is_empty()).then_some(alpha_helices)
                    },
                    beta_sheets: {
                        let mut beta_sheets = BetaSheets::default();
                        for sheet in global_sheets.iter() {
                            let Some(&chain_ref) = chain_ref_by_id.get(&sheet.init_chain_id) else {
                                continue;
                            };
                            let start_id = ResidueId {
                                chain_id: sheet.init_chain_id.clone(),
                                sequence_number: sheet.init_seq_num,
                                insertion_code: sheet.init_insert_code.clone(),
                                residue_name: sheet.init_res_name.clone(),
                            };
                            let end_id = ResidueId {
                                chain_id: sheet.end_chain_id.clone(),
                                sequence_number: sheet.end_seq_num,
                                insertion_code: sheet.end_insert_code.clone(),
                                residue_name: sheet.end_res_name.clone(),
                            };
                            let (Some(&start_residue), Some(&end_residue)) = (
                                residue_ref_by_id.get(&start_id),
                                residue_ref_by_id.get(&end_id),
                            ) else {
                                continue;
                            };

                            beta_sheets.push(
                                sheet.sheet_id.clone(),
                                sheet.strand.to_string(),
                                (sheet.strand > 0).then_some(sheet.strand as u32),
                                (sheet.num_strands > 0).then_some(sheet.num_strands as u32),
                                chain_ref,
                                start_residue,
                                end_residue,
                                StrandSense::from_pdb_sense(sheet.sense).and_then(|sense| {
                                    (sense != StrandSense::First || sheet.strand == 1)
                                        .then_some(sense)
                                }),
                            );
                        }
                        (!beta_sheets.is_empty()).then_some(beta_sheets)
                    },
                    labeled: Some(
                        chains
                            .keys()
                            .enumerate()
                            .map(|(i, _)| ChainRef(i as u32))
                            .collect(),
                    ),
                    labels: Some(chains.into_keys().map(|chain_id| vec![chain_id]).collect()),
                }
            },
        };

        trc.topology.labels = Some(atom_labels);

        // We store amino acids as the "default" fragments so that we
        // can generalize fast implicit connectvity searches
        trc.topology.fragments = Some(
            trc.residues
                .residues
                .iter()
                .filter(|Residue(atom_refs)| !atom_refs.is_empty())
                .map(|Residue(atom_refs)| Fragment(atom_refs.clone()))
                .collect(),
        );

        let mut connectivity_deduper = BTreeMap::<(usize, usize), u8>::new();
        for (origin, target, order) in connectivity {
            let origin = if let Some((origin, _)) = atom_ids.iter().find_position(|x| *x == &origin)
            {
                origin
            } else {
                continue;
            };

            let target = if let Some((target, _)) = atom_ids.iter().find_position(|x| *x == &target)
            {
                target
            } else {
                continue;
            };

            if connectivity_deduper.contains_key(&(target, origin)) {
                // Dedup CONECT records are that entered in reverse, because this it
                // is common for PDBs to describe one bond in both directions.
                continue;
            }
            match connectivity_deduper.get_mut(&(origin, target)) {
                Some(order) => {
                    // However, if the bond is explicitly entered twice in the same
                    // direction, this usually signifies that the bond is a double
                    // bond.
                    *order += 1;
                }
                None => {
                    connectivity_deduper.insert((origin, target), order);
                }
            }
        }
        trc.topology.connectivity = Some(
            connectivity_deduper
                .into_iter()
                .map(|((i, j), order)| {
                    Bond(
                        AtomRef(i.min(j) as u32),
                        AtomRef(i.max(j) as u32),
                        BondOrder::from(order),
                    )
                })
                .collect::<Vec<_>>(),
        );

        trc.topology.fragment_formal_charges = Some(
            trc.residues
                .residues
                .iter()
                .filter(|Residue(atom_refs)| !atom_refs.is_empty())
                .map(|Residue(atom_refs)| {
                    Ok(FormalCharge(
                        atom_refs
                            .iter()
                            .map(|AtomRef(atom_ref)| {
                                Ok(*atom_formal_charges
                                    .get(*atom_ref as usize)
                                    .ok_or(Error::AtomChargeZip)?
                                    as isize)
                            })
                            .collect::<Result<Vec<isize>, Error>>()?
                            .into_iter()
                            .sum::<isize>() as i32,
                    ))
                })
                .collect::<Result<Vec<crate::atom::FormalCharge>, Error>>()?,
        );

        // Add atom charges
        trc.topology.formal_charges =
            Some(atom_formal_charges.into_iter().map(FormalCharge).collect());

        // Store the model alongside the metadata required for parsing global
        // connectivity information
        trcs.push(trc);
        trc_atom_ids.push(atom_ids);

        if eof {
            break;
        }
    }

    // CONECT records can appear outside of model definitions even in PDBs that
    // define multiple models. The only reasonable interpretation is that these
    // CONECT records apply to all models.
    for (trc, atom_ids) in trcs.iter_mut().zip(trc_atom_ids.iter()) {
        let mut connectivity_deduper = HashMap::<(usize, usize), u8>::new();
        for (origin, target, order) in global_connectivity.iter() {
            let (origin, _) = atom_ids
                .iter()
                .find_position(|x| *x == origin)
                .ok_or(Error::InvalidConnection { atom_idx: *origin })?;
            let (target, _) = atom_ids
                .iter()
                .find_position(|x| *x == target)
                .ok_or(Error::InvalidConnection { atom_idx: *target })?;

            if connectivity_deduper.contains_key(&(target, origin)) {
                // Dedup CONECT records are that entered in reverse, because this it
                // is common for PDBs to describe one bond in both directions.
                continue;
            }
            match connectivity_deduper.get_mut(&(origin, target)) {
                Some(order) => {
                    // However, if the bond is explicitly entered twice in the same
                    // direction, this usually signifies that the bond is a double
                    // bond.
                    *order += 1;
                }
                None => {
                    connectivity_deduper.insert((origin, target), *order);
                }
            }
        }
        let additional_connectivity = connectivity_deduper
            .iter()
            .map(|((i, j), order)| {
                Bond(
                    AtomRef(*i.min(j) as u32),
                    AtomRef(*i.max(j) as u32),
                    BondOrder::from(*order),
                )
            })
            .collect::<Vec<_>>();
        match &mut trc.topology.connectivity {
            Some(connectivity) => {
                connectivity.extend(additional_connectivity);
            }
            None => {
                trc.topology.connectivity = Some(additional_connectivity);
            }
        }
    }

    Ok(trcs)
}

fn chain_id_for_pdb(chains: &Chains, chain_ref: usize) -> String {
    chains
        .labels
        .as_ref()
        .and_then(|labels| labels.get(chain_ref))
        .and_then(|labels| labels.first())
        .cloned()
        .unwrap_or_else(|| format!("{}", (chain_ref as u8 + 65) as char))
}

pub fn to_pdb(trc: &TRC) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {
    let mut pdb = String::new();

    let mut residue_ref_to_chain_ref = HashMap::new();
    for (chain_ref, Chain(chain)) in trc.chains.chains.iter().enumerate() {
        for residue_ref in chain {
            residue_ref_to_chain_ref.insert(*residue_ref, chain_ref);
        }
    }

    // Write SEQRES records
    for (chain_ref, Chain(chain)) in trc.chains.chains.iter().enumerate() {
        let chain_id = chain_id_for_pdb(&trc.chains, chain_ref);

        let residue_names: Vec<&str> = chain
            .iter()
            .filter(|ResidueRef(r)| AminoAcidSeq::is_amino_acid(&trc.residues.seqs[*r as usize]))
            .map(|ResidueRef(r)| trc.residues.seqs[*r as usize].as_str())
            .collect();
        if residue_names.is_empty() {
            continue;
        }
        let num_res = residue_names.len() as u32;

        for (line_idx, chunk) in residue_names.chunks(13).enumerate() {
            let seqres = Seqres {
                ser_num: (line_idx + 1) as u32,
                chain_id: chain_id.clone(),
                num_res,
                seq: chunk.iter().map(|s| s.to_string()).collect(),
            };
            pdb += &format!("{}\n", Line::Seqres(seqres).try_to_string()?);
        }
    }

    if let Some(alpha_helices) = &trc.chains.alpha_helices {
        for i in 0..alpha_helices.len() {
            let chain_id = chain_id_for_pdb(&trc.chains, alpha_helices.chain_refs[i].0 as usize);

            let start = alpha_helices.start_residues[i].0 as usize;
            let end = alpha_helices.end_residues[i].0 as usize;

            let helix = Helix {
                ser_num: (i + 1) as i32,
                helix_id: alpha_helices.helix_ids[i]
                    .chars()
                    .take(3)
                    .collect::<String>(),
                init_res_name: trc.residues.seqs.get(start).cloned().unwrap_or_default(),
                init_chain_id: chain_id.clone(),
                init_seq_num: trc.residues.seq_ns.get(start).copied().unwrap_or_default(),
                init_insert_code: trc
                    .residues
                    .insertion_codes
                    .get(start)
                    .cloned()
                    .unwrap_or_default(),
                end_res_name: trc.residues.seqs.get(end).cloned().unwrap_or_default(),
                end_chain_id: chain_id,
                end_seq_num: trc.residues.seq_ns.get(end).copied().unwrap_or_default(),
                end_insert_code: trc
                    .residues
                    .insertion_codes
                    .get(end)
                    .cloned()
                    .unwrap_or_default(),
                helix_class: alpha_helices.classes[i]
                    .map(|c| c as u8 as i32)
                    .unwrap_or_default(),
                length: alpha_helices.lengths[i]
                    .map(|l| l as i32)
                    .unwrap_or_default(),
            };
            pdb += &format!("{}\n", Line::Helix(helix).try_to_string()?);
        }
    }

    if let Some(beta_sheets) = &trc.chains.beta_sheets {
        for i in 0..beta_sheets.len() {
            let chain_id = chain_id_for_pdb(&trc.chains, beta_sheets.chain_refs[i].0 as usize);

            let start = beta_sheets.start_residues[i].0 as usize;
            let end = beta_sheets.end_residues[i].0 as usize;

            let sense = beta_sheets.senses[i].map(|s| match s {
                StrandSense::First => 0,
                StrandSense::Parallel => 1,
                StrandSense::AntiParallel => -1,
            });

            let sheet = Sheet {
                strand: beta_sheets.strand_ordinals[i]
                    .or_else(|| beta_sheets.strand_ids[i].parse::<u32>().ok())
                    .unwrap_or((i + 1) as u32) as i32,
                sheet_id: beta_sheets.sheet_ids[i].chars().take(3).collect::<String>(),
                num_strands: beta_sheets.num_strands[i].unwrap_or_default() as i32,
                init_res_name: trc.residues.seqs.get(start).cloned().unwrap_or_default(),
                init_chain_id: chain_id.clone(),
                init_seq_num: trc.residues.seq_ns.get(start).copied().unwrap_or_default(),
                init_insert_code: trc
                    .residues
                    .insertion_codes
                    .get(start)
                    .cloned()
                    .unwrap_or_default(),
                end_res_name: trc.residues.seqs.get(end).cloned().unwrap_or_default(),
                end_chain_id: chain_id,
                end_seq_num: trc.residues.seq_ns.get(end).copied().unwrap_or_default(),
                end_insert_code: trc
                    .residues
                    .insertion_codes
                    .get(end)
                    .cloned()
                    .unwrap_or_default(),
                sense: sense.unwrap_or_default(),
                cur_atom: "".to_string(),
                cur_res_name: "".to_string(),
                cur_chain_id: "".to_string(),
                cur_res_seq: 0,
                cur_insert_code: "~".to_string(),
                prev_atom: "".to_string(),
                prev_res_name: "".to_string(),
                prev_chain_id: "".to_string(),
                prev_res_seq: 0,
                prev_insert_code: "~".to_string(),
            };
            pdb += &format!("{}\n", Line::Sheet(sheet).try_to_string()?);
        }
    }

    for (i, Residue(residue)) in trc.residues.residues.iter().enumerate() {
        for AtomRef(atom_idx) in residue {
            let atom = Atom {
                atom_idx: *atom_idx,
                atom_name: trc
                    .topology
                    .labels
                    .as_ref()
                    .and_then(|atom_labels| atom_labels.get(*atom_idx as usize).cloned())
                    .or_else(|| {
                        trc.topology
                            .symbols
                            .get(*atom_idx as usize)
                            .cloned()
                            .map(|element| <&str>::from(element).to_string())
                    })
                    .unwrap_or_default(),
                alternate_location: None, // TODO: Support altlocs
                residue_name: trc.residues.seqs[i].to_string(),
                chain_id: format!(
                    "{}",
                    (residue_ref_to_chain_ref
                        .get(&ResidueRef(i as u32))
                        .cloned()
                        .unwrap_or_default() as u8
                        + 65) as char
                ),
                sequence_number: trc.residues.seq_ns[i],
                residue_insertion: Some(trc.residues.insertion_codes[i].clone()),
                atom_x: trc.topology.geometry[3 * *atom_idx as usize],
                atom_y: trc.topology.geometry[3 * *atom_idx as usize + 1],
                atom_z: trc.topology.geometry[3 * *atom_idx as usize + 2],
                occupancy: 1.0, // TODO: Support altlocs
                temperature_factor: 0.0,
                segment_id: None,
                element_symbol: trc.topology.symbols[*atom_idx as usize],
                charge: trc
                    .topology
                    .formal_charges
                    .as_ref()
                    .and_then(|atom_charges| {
                        atom_charges
                            .get(*atom_idx as usize)
                            .map(|FormalCharge(x)| *x)
                    })
                    .unwrap_or_default(),
                is_het_atom: !AminoAcidSeq::is_amino_acid(&trc.residues.seqs[i]),
            };

            pdb += &format!("{}\n", Line::Atom(atom).try_to_string()?);
        }
    }

    let empty = Vec::new();
    for Bond(AtomRef(atom_u), AtomRef(atom_v), bond_order) in
        trc.topology.connectivity.as_ref().unwrap_or(&empty)
    {
        // FIXME: this is slow but as its legacy code no point in making it fast
        // we should skip bonds that exist only in amino acids as they are standard
        if trc
            .residues
            .residues
            .iter()
            .enumerate()
            .filter(|(i, _)| AminoAcidSeq::is_amino_acid(&trc.residues.seqs[*i]))
            .any(|(_, Residue(residue))| residue.contains(&AtomRef(*atom_u)))
            && trc
                .residues
                .residues
                .iter()
                .enumerate()
                .filter(|(i, _)| AminoAcidSeq::is_amino_acid(&trc.residues.seqs[*i]))
                .any(|(_, Residue(residue))| residue.contains(&AtomRef(*atom_v)))
        {
            continue;
        }

        if let BondOrder::Single
        | BondOrder::Double
        | BondOrder::Triple
        | BondOrder::Quadruple
        | BondOrder::Quintuple
        | BondOrder::Sextuple = bond_order
        {
            for _ in 0..(*bond_order as u8) {
                pdb += &format!(
                    "{}\n",
                    Line::Conect(Conect {
                        atom_idxs: vec![*atom_u, *atom_v],
                    })
                    .try_to_string()?
                );
            }
        } else {
            pdb += &format!(
                "{}\n",
                Line::Conect(Conect {
                    atom_idxs: vec![*atom_u, *atom_v],
                })
                .try_to_string()?
            );
        }
    }

    Ok(pdb)
}

#[cfg(test)]
mod tests {
    use std::{fs, path::PathBuf};

    use crate::{AminoAcidSeq, AtomRef, Chain, Element, Residue, ResidueRef, TRC};

    use super::to_pdb;

    fn fixture_path(rel: &str) -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(rel)
    }

    fn read_fixture(rel: &str) -> String {
        fs::read_to_string(fixture_path(rel))
            .unwrap_or_else(|err| panic!("failed to read fixture {rel}: {err}"))
    }

    fn mmcif_fixture_pdb(rcsbid: &str) -> String {
        let rel = match rcsbid {
            "7pjq" => "tests/data/mmcif/7pjq.pdb",
            "9atq" => "tests/data/mmcif/9atq.pdb",
            "9dbu" => "tests/data/mmcif/9dbu.pdb",
            "9hj7" => "tests/data/mmcif/9hj7.pdb",
            "9jbd" => "tests/data/mmcif/9jbd.pdb",
            "9jm5" => "tests/data/mmcif/9jm5.pdb",
            _ => panic!("unknown test fixture id: {rcsbid}"),
        };
        read_fixture(rel)
    }

    /// Extract ATOM/HETATM lines from a PDB string. When `filter_altloc`
    /// is true, only keeps lines that `from_pdb` would parse (alt location
    /// A or blank), since alternate conformations are dropped during parsing.
    fn extract_atom_lines(pdb: &str, filter_altloc: bool) -> Vec<String> {
        pdb.lines()
            .filter(|l| l.starts_with("ATOM  ") || l.starts_with("HETATM"))
            .filter(|l| {
                if !filter_altloc {
                    return true;
                }
                let altloc = l.as_bytes().get(16).copied().unwrap_or(b' ');
                altloc == b' ' || altloc == b'A'
            })
            .map(|l| l.to_string())
            .collect()
    }

    type AtomKey = (String, String, i32, String);

    fn atom_keys(lines: &[String]) -> Vec<AtomKey> {
        let mut keys: Vec<AtomKey> = lines
            .iter()
            .map(|l| {
                (
                    l.get(12..16).unwrap_or("").trim().to_string(),
                    l.get(17..20).unwrap_or("").trim().to_string(),
                    l.get(22..26)
                        .unwrap_or("")
                        .trim()
                        .parse::<i32>()
                        .unwrap_or(0),
                    l.get(76..78).unwrap_or("").trim().to_string(),
                )
            })
            .collect();
        keys.sort();
        keys
    }

    #[test]
    fn parses_af2rave_output_pdb() {
        let pdb_content = read_fixture("tests/data/pdb/af2rave_output.pdb");
        let _structure = super::from_pdb(&pdb_content)
            .unwrap()
            .pop()
            .expect("af2rave output has at least one model");
    }

    #[test]
    fn parses_7l5o_fixture() {
        let pdb_content = read_fixture("tests/data/pdb/7l5o.pdb");
        let _structure = super::from_pdb(&pdb_content)
            .unwrap()
            .pop()
            .expect("75LO has at least one model");
    }

    #[test]
    fn test_7l5o_secondary_structure_extracted() {
        let pdb_content = read_fixture("tests/data/pdb/7l5o.pdb");
        let trc = super::from_pdb(&pdb_content)
            .unwrap()
            .pop()
            .expect("7L5O has at least one model");

        let helices = trc
            .chains
            .alpha_helices
            .as_ref()
            .expect("expected alpha helices");
        assert_eq!(helices.len(), 15);
        assert_eq!(helices.helix_ids.len(), helices.chain_refs.len());
        assert_eq!(helices.helix_ids.len(), helices.start_residues.len());
        assert_eq!(helices.helix_ids.len(), helices.end_residues.len());
        assert_eq!(helices.helix_ids.len(), helices.classes.len());
        assert_eq!(helices.helix_ids.len(), helices.lengths.len());

        assert_eq!(helices.helix_ids[0], "AA1");
        let start = helices.start_residues[0].0 as usize;
        let end = helices.end_residues[0].0 as usize;
        assert_eq!(trc.residues.seqs[start], "ASP");
        assert_eq!(trc.residues.seq_ns[start], 398);
        assert_eq!(trc.residues.seqs[end], "LYS");
        assert_eq!(trc.residues.seq_ns[end], 400);
        assert_eq!(helices.classes[0].map(|x| x as u8), Some(5));
        assert_eq!(helices.lengths[0], Some(3));

        let sheets = trc
            .chains
            .beta_sheets
            .as_ref()
            .expect("expected beta sheets");
        assert_eq!(sheets.len(), 8);
        assert_eq!(sheets.sheet_ids.len(), sheets.strand_ids.len());
        assert_eq!(sheets.sheet_ids.len(), sheets.strand_ordinals.len());
        assert_eq!(sheets.sheet_ids.len(), sheets.num_strands.len());
        assert_eq!(sheets.sheet_ids.len(), sheets.chain_refs.len());
        assert_eq!(sheets.sheet_ids.len(), sheets.start_residues.len());
        assert_eq!(sheets.sheet_ids.len(), sheets.end_residues.len());
        assert_eq!(sheets.sheet_ids.len(), sheets.senses.len());

        assert_eq!(sheets.sheet_ids[0], "AA1");
        assert_eq!(sheets.strand_ordinals[0], Some(1));
        assert_eq!(sheets.num_strands[0], Some(5));
        let start = sheets.start_residues[0].0 as usize;
        let end = sheets.end_residues[0].0 as usize;
        assert_eq!(trc.residues.seqs[start], "LEU");
        assert_eq!(trc.residues.seq_ns[start], 402);
        assert_eq!(trc.residues.seqs[end], "GLY");
        assert_eq!(trc.residues.seq_ns[end], 409);
        assert_eq!(sheets.senses[0].map(|x| x as u8), Some(1));
    }

    #[test]
    fn test_secondary_structure_optional_when_absent() {
        let pdb = r#"ATOM      1  N   ALA A   1      11.104  13.207   2.100  1.00 20.00           N  
ATOM      2  CA  ALA A   1      12.560  13.500   2.000  1.00 20.00           C  
END
"#;
        let trc = super::from_pdb(pdb)
            .unwrap()
            .pop()
            .expect("pdb has at least one model");
        assert!(trc.chains.alpha_helices.is_none());
        assert!(trc.chains.beta_sheets.is_none());
    }

    #[test]
    fn test_7l5o_secondary_structure_pdb_roundtrip() {
        let pdb_content = read_fixture("tests/data/pdb/7l5o.pdb");
        let trc1 = super::from_pdb(&pdb_content)
            .unwrap()
            .pop()
            .expect("7L5O has at least one model");
        let pdb = to_pdb(&trc1).unwrap();
        let trc2 = super::from_pdb(pdb)
            .unwrap()
            .pop()
            .expect("roundtrip has at least one model");

        assert_eq!(trc1.chains.alpha_helices, trc2.chains.alpha_helices);
        assert_eq!(trc1.chains.beta_sheets, trc2.chains.beta_sheets);
    }

    #[test]
    fn test_7l5o_secondary_structure_pdb_output_fixed_width() {
        let pdb_content = read_fixture("tests/data/pdb/7l5o.pdb");
        let trc = super::from_pdb(&pdb_content)
            .unwrap()
            .pop()
            .expect("7L5O has at least one model");
        let pdb = to_pdb(&trc).unwrap();

        // Basic interoperability checks: fixed-width records + key column alignment.
        let mut helix_lines = Vec::new();
        let mut sheet_lines = Vec::new();
        let mut first_atom_line_idx = None;
        for (i, line) in pdb.lines().enumerate() {
            if line.starts_with("ATOM  ") && first_atom_line_idx.is_none() {
                first_atom_line_idx = Some(i);
            }
            if line.starts_with("HELIX ") {
                assert!(line.is_ascii());
                assert_eq!(line.len(), 80);
                helix_lines.push(line.to_string());
            }
            if line.starts_with("SHEET ") {
                assert!(line.is_ascii());
                assert_eq!(line.len(), 80);
                sheet_lines.push(line.to_string());
            }
        }

        assert_eq!(helix_lines.len(), 15);
        assert_eq!(sheet_lines.len(), 8);

        let first_atom_line_idx = first_atom_line_idx.expect("expected at least one ATOM line");
        let first_helix_line_idx = pdb
            .lines()
            .position(|l| l.starts_with("HELIX "))
            .expect("expected helix lines");
        let first_sheet_line_idx = pdb
            .lines()
            .position(|l| l.starts_with("SHEET "))
            .expect("expected sheet lines");
        assert!(first_helix_line_idx < first_atom_line_idx);
        assert!(first_sheet_line_idx < first_atom_line_idx);

        // Spot-check first HELIX columns against the PDB v3.3 field layout.
        let h = &helix_lines[0];
        assert_eq!(&h[0..6], "HELIX ");
        assert_eq!(&h[7..10], "  1");
        assert_eq!(&h[11..14], "AA1");
        assert_eq!(&h[15..18], "ASP");
        assert_eq!(&h[19..20], "A");
        assert_eq!(&h[21..25], " 398");
        assert_eq!(&h[25..26], " ");
        assert_eq!(&h[27..30], "LYS");
        assert_eq!(&h[31..32], "A");
        assert_eq!(&h[33..37], " 400");
        assert_eq!(&h[37..38], " ");
        assert_eq!(&h[38..40], " 5");
        assert_eq!(&h[71..76], "    3");

        // Spot-check first SHEET columns against the PDB v3.3 field layout.
        let s = &sheet_lines[0];
        assert_eq!(&s[0..6], "SHEET ");
        assert_eq!(&s[7..10], "  1");
        assert_eq!(&s[11..14], "AA1");
        assert_eq!(&s[14..16], " 5");
        assert_eq!(&s[17..20], "LEU");
        assert_eq!(&s[21..22], "A");
        assert_eq!(&s[22..26], " 402");
        assert_eq!(&s[26..27], " ");
        assert_eq!(&s[28..31], "GLY");
        assert_eq!(&s[32..33], "A");
        assert_eq!(&s[33..37], " 409");
        assert_eq!(&s[37..38], " ");
        assert_eq!(&s[38..40], " 0");
    }

    #[test]
    fn test_to_pdb_uses_chain_labels_for_secondary_structure() {
        use crate::{
            AlphaHelices, BetaSheets, ChainRef, Chains, HelixClass, Residues, StrandSense, Topology,
        };

        // Regression: helix/sheet writers used to hardcode chain index → 'A','B',...
        // instead of looking up the actual chain label.
        let trc = TRC {
            topology: Topology {
                symbols: vec![Element::N, Element::C, Element::N],
                geometry: vec![11.1, 13.2, 2.1, 12.5, 13.5, 2.0, 13.0, 14.0, 3.0],
                ..Default::default()
            },
            residues: Residues {
                residues: vec![
                    Residue(vec![AtomRef(0), AtomRef(1)]),
                    Residue(vec![AtomRef(2)]),
                ],
                seqs: vec!["ALA".into(), "GLY".into()],
                seq_ns: vec![1, 2],
                insertion_codes: vec!["~".into(), "~".into()],
                labels: None,
                labeled: None,
            },
            chains: Chains {
                chains: vec![Chain(vec![ResidueRef(0), ResidueRef(1)])],
                alpha_helices: Some(AlphaHelices {
                    helix_ids: vec!["H1".into()],
                    chain_refs: vec![ChainRef(0)],
                    start_residues: vec![ResidueRef(0)],
                    end_residues: vec![ResidueRef(1)],
                    classes: vec![Some(HelixClass::RightHandedAlpha)],
                    lengths: vec![Some(2)],
                }),
                beta_sheets: Some(BetaSheets {
                    sheet_ids: vec!["S1".into()],
                    strand_ids: vec!["1".into()],
                    strand_ordinals: vec![Some(1)],
                    num_strands: vec![Some(1)],
                    chain_refs: vec![ChainRef(0)],
                    start_residues: vec![ResidueRef(0)],
                    end_residues: vec![ResidueRef(1)],
                    senses: vec![Some(StrandSense::First)],
                }),
                labeled: Some(vec![ChainRef(0)]),
                labels: Some(vec![vec!["L".into()]]),
            },
        };

        let pdb = to_pdb(&trc).unwrap();

        // HELIX chain columns
        let helix_line = pdb.lines().find(|l| l.starts_with("HELIX ")).unwrap();
        assert_eq!(&helix_line[19..20], "L"); // init chain ID
        assert_eq!(&helix_line[31..32], "L"); // end chain ID

        // SHEET chain columns
        let sheet_line = pdb.lines().find(|l| l.starts_with("SHEET ")).unwrap();
        assert_eq!(&sheet_line[21..22], "L"); // init chain ID
        assert_eq!(&sheet_line[32..33], "L"); // end chain ID
    }

    #[test]
    fn parses_4hhb_fixture_with_expected_counts() {
        // Load the PDB from the test string.
        let pdb_content = read_fixture("tests/data/pdb/4hhb.pdb");
        let complex = super::from_pdb(&pdb_content).unwrap()[0].clone();

        // Assert expected sizes for the topology.
        let n_expected_symbols = 4779;
        let n_expected_geometry = 3 * n_expected_symbols;
        assert_eq!(
            complex.topology.symbols.len(),
            n_expected_symbols,
            "expected {n_expected_symbols} symbols"
        );
        assert_eq!(
            complex.topology.geometry.len(),
            n_expected_geometry,
            "expected {n_expected_geometry} geometry coords"
        );

        // Assert expected sizes for the amino acids.
        let n_expected_amino_acids = 574;
        let n_expected_amino_acid_atoms = 4384;
        assert_eq!(
            complex
                .residues
                .residues
                .iter()
                .enumerate()
                .filter(|(i, _)| AminoAcidSeq::is_amino_acid(&complex.residues.seqs[*i]))
                .count(),
            n_expected_amino_acids,
            "expected {n_expected_amino_acids} amino acids"
        );
        assert_eq!(
            complex
                .residues
                .seqs
                .iter()
                .filter(|seq| AminoAcidSeq::is_amino_acid(seq))
                .count(),
            n_expected_amino_acids,
            "expected {n_expected_amino_acids} amino acid sequences"
        );
        assert_eq!(
            complex
                .residues
                .residues
                .iter()
                .enumerate()
                .filter(|(i, _)| AminoAcidSeq::is_amino_acid(&complex.residues.seqs[*i]))
                .fold(0, |accum, (_, Residue(atom_refs))| accum + atom_refs.len()),
            n_expected_amino_acid_atoms,
            "expected {n_expected_amino_acid_atoms} amino acid atoms"
        );

        // Assert the expected sizes for the residues.
        let n_expected_residues = 227;
        let n_expected_residue_atoms = 395;
        assert_eq!(
            complex
                .residues
                .residues
                .iter()
                .enumerate()
                .filter(|(i, _)| !AminoAcidSeq::is_amino_acid(&complex.residues.seqs[*i]))
                .count(),
            n_expected_residues,
            "expected {n_expected_residues} residues"
        );
        assert_eq!(
            complex
                .residues
                .seqs
                .iter()
                .filter(|seq| !AminoAcidSeq::is_amino_acid(seq))
                .count(),
            n_expected_residues,
            "expected {n_expected_residues} residue sequences"
        );
        assert_eq!(
            complex
                .residues
                .residues
                .iter()
                .enumerate()
                .filter(|(i, _)| !AminoAcidSeq::is_amino_acid(&complex.residues.seqs[*i]))
                .fold(0, |accum, (_, Residue(atom_refs))| accum + atom_refs.len()),
            n_expected_residue_atoms,
            "expected {n_expected_residue_atoms} residue atoms"
        );

        // Assert the expected sizes for the subunits.
        let n_expected_chains = 4;
        assert_eq!(
            complex.chains.chains.len(),
            n_expected_chains,
            "expected {n_expected_chains} subunits"
        );
        assert_eq!(
            complex
                .chains
                .chains
                .iter()
                .map(|Chain(chain)| chain
                    .iter()
                    .map(|ResidueRef(i)| &complex.residues.residues[*i as usize])
                    .fold(0, |accum, Residue(atom_refs)| accum + atom_refs.len()))
                .sum::<usize>(),
            n_expected_symbols,
            "expected {n_expected_symbols} subunit atoms"
        );
        assert_eq!(
            complex.chains.chains[0]
                .0
                .iter()
                .map(|ResidueRef(i)| &complex.residues.residues[*i as usize])
                .fold(0, |accum, Residue(atom_refs)| accum + atom_refs.len()),
            1168,
            "expected 1168 atoms in the 1st subunit"
        );
        assert_eq!(
            complex.chains.chains[1]
                .0
                .iter()
                .map(|ResidueRef(i)| &complex.residues.residues[*i as usize])
                .fold(0, |accum, Residue(atom_refs)| accum + atom_refs.len()),
            1224,
            "expected 1224 atoms in the 2nd subunit"
        );
        assert_eq!(
            complex.chains.chains[2]
                .0
                .iter()
                .map(|ResidueRef(i)| &complex.residues.residues[*i as usize])
                .fold(0, |accum, Residue(atom_refs)| accum + atom_refs.len()),
            1171,
            "expected 1171 atoms in the 3rd subunit"
        );
        assert_eq!(
            complex.chains.chains[3]
                .0
                .iter()
                .map(|ResidueRef(i)| &complex.residues.residues[*i as usize])
                .fold(0, |accum, Residue(atom_refs)| accum + atom_refs.len()),
            1216,
            "expected 1216 atoms in the 4th subunit"
        );

        // Assert the values of some atoms.
        assert_eq!(
            complex.topology.symbols[0],
            Element::N,
            "expected first atom to be N"
        );
        assert_eq!(
            complex.topology.geometry[..3],
            [6.204, 16.869, 4.854],
            "expected first atom to be at x=6.204, y=16.869, z=4.854"
        );
        assert_eq!(
            complex.topology.symbols[complex.topology.symbols.len() - 1],
            Element::O,
            "expected last atom to be O"
        );
        assert_eq!(
            complex.topology.geometry[complex.topology.geometry.len() - 3..],
            [-1.263, -2.837, -21.251],
            "expected first atom to be at x=-1.263, y=-2.837, z=-21.251"
        );

        // Assert the value of some residues.
        assert_eq!(
            complex.residues.seqs[0],
            AminoAcidSeq::VAL.to_pdb_std_name(),
            "expected first residue to be VAL"
        );
        assert_eq!(
            complex.residues.residues[0],
            Residue(vec![
                AtomRef(0),
                AtomRef(1),
                AtomRef(2),
                AtomRef(3),
                AtomRef(4),
                AtomRef(5),
                AtomRef(6)
            ]),
            "expected first residue to contain atoms 0, 1, 2, 3, 4, 5, and 6"
        );
    }

    #[test]
    fn seqres_fills_internal_gaps_with_empty_residues() {
        // SEQRES declares 10 amino acids for chain A:
        //   ALA GLY VAL LEU ILE PRO SER THR ASN GLN
        // ATOM records exist for positions 1,2,3,5,6,7,10 only (gaps at 4=LEU, 8=THR, 9=ASN)
        let pdb = "\
SEQRES   1 A   10  ALA GLY VAL LEU ILE PRO SER THR ASN GLN                    \n\
ATOM      1  N   ALA A   1       1.000   2.000   3.000  1.00  0.00           N  \n\
ATOM      2  CA  ALA A   1       2.000   2.000   3.000  1.00  0.00           C  \n\
ATOM      3  C   ALA A   1       3.000   2.000   3.000  1.00  0.00           C  \n\
ATOM      4  O   ALA A   1       4.000   2.000   3.000  1.00  0.00           O  \n\
ATOM      5  CB  ALA A   1       5.000   2.000   3.000  1.00  0.00           C  \n\
ATOM      6  N   GLY A   2       1.000   3.000   3.000  1.00  0.00           N  \n\
ATOM      7  CA  GLY A   2       2.000   3.000   3.000  1.00  0.00           C  \n\
ATOM      8  C   GLY A   2       3.000   3.000   3.000  1.00  0.00           C  \n\
ATOM      9  O   GLY A   2       4.000   3.000   3.000  1.00  0.00           O  \n\
ATOM     10  N   VAL A   3       1.000   4.000   3.000  1.00  0.00           N  \n\
ATOM     11  CA  VAL A   3       2.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     12  C   VAL A   3       3.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     13  O   VAL A   3       4.000   4.000   3.000  1.00  0.00           O  \n\
ATOM     14  CB  VAL A   3       5.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     15  CG1 VAL A   3       6.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     16  CG2 VAL A   3       7.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     17  N   ILE A   5       1.000   6.000   3.000  1.00  0.00           N  \n\
ATOM     18  CA  ILE A   5       2.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     19  C   ILE A   5       3.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     20  O   ILE A   5       4.000   6.000   3.000  1.00  0.00           O  \n\
ATOM     21  CB  ILE A   5       5.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     22  CG1 ILE A   5       6.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     23  CG2 ILE A   5       7.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     24  CD1 ILE A   5       8.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     25  N   PRO A   6       1.000   7.000   3.000  1.00  0.00           N  \n\
ATOM     26  CA  PRO A   6       2.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     27  C   PRO A   6       3.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     28  O   PRO A   6       4.000   7.000   3.000  1.00  0.00           O  \n\
ATOM     29  CB  PRO A   6       5.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     30  CG  PRO A   6       6.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     31  CD  PRO A   6       7.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     32  N   SER A   7       1.000   8.000   3.000  1.00  0.00           N  \n\
ATOM     33  CA  SER A   7       2.000   8.000   3.000  1.00  0.00           C  \n\
ATOM     34  C   SER A   7       3.000   8.000   3.000  1.00  0.00           C  \n\
ATOM     35  O   SER A   7       4.000   8.000   3.000  1.00  0.00           O  \n\
ATOM     36  CB  SER A   7       5.000   8.000   3.000  1.00  0.00           C  \n\
ATOM     37  OG  SER A   7       6.000   8.000   3.000  1.00  0.00           O  \n\
ATOM     38  N   GLN A  10       1.000  11.000   3.000  1.00  0.00           N  \n\
ATOM     39  CA  GLN A  10       2.000  11.000   3.000  1.00  0.00           C  \n\
ATOM     40  C   GLN A  10       3.000  11.000   3.000  1.00  0.00           C  \n\
ATOM     41  O   GLN A  10       4.000  11.000   3.000  1.00  0.00           O  \n\
ATOM     42  CB  GLN A  10       5.000  11.000   3.000  1.00  0.00           C  \n\
ATOM     43  CG  GLN A  10       6.000  11.000   3.000  1.00  0.00           C  \n\
ATOM     44  CD  GLN A  10       7.000  11.000   3.000  1.00  0.00           C  \n\
ATOM     45  OE1 GLN A  10       8.000  11.000   3.000  1.00  0.00           O  \n\
ATOM     46  NE2 GLN A  10       9.000  11.000   3.000  1.00  0.00           N  \n\
END\n";

        // Without SEQRES: should only have 7 residues from ATOM records
        let trcs_no_seqres = super::from_pdb_with_options(pdb, false).unwrap();
        assert_eq!(
            trcs_no_seqres[0].residues.residues.len(),
            7,
            "expected 7 residues without SEQRES"
        );

        // With SEQRES (default): should have 10 residues total (7 with atoms + 3 empty)
        let trcs = super::from_pdb(pdb).unwrap();
        assert_eq!(trcs.len(), 1);
        let trc = &trcs[0];
        assert_eq!(trc.residues.residues.len(), 10, "expected 10 residues");

        // Check that empty residues exist at positions for LEU(4), THR(8), ASN(9)
        let empty_indices: Vec<usize> = trc
            .residues
            .residues
            .iter()
            .enumerate()
            .filter(|(_, r)| r.is_empty())
            .map(|(i, _)| i)
            .collect();
        assert_eq!(empty_indices.len(), 3, "expected 3 empty residues");

        // Check that the empty residues have the right names
        let empty_names: Vec<&str> = empty_indices
            .iter()
            .map(|&i| trc.residues.seqs[i].as_str())
            .collect();
        assert!(
            empty_names.contains(&"LEU"),
            "expected LEU in empty residues, got {empty_names:?}"
        );
        assert!(
            empty_names.contains(&"THR"),
            "expected THR in empty residues, got {empty_names:?}"
        );
        assert!(
            empty_names.contains(&"ASN"),
            "expected ASN in empty residues, got {empty_names:?}"
        );

        // Non-empty residues should have atoms
        for (i, residue) in trc.residues.residues.iter().enumerate() {
            if !empty_indices.contains(&i) {
                assert!(
                    !residue.is_empty(),
                    "residue {} ({}) should have atoms",
                    i,
                    trc.residues.seqs[i]
                );
            }
        }

        // TRC check should pass
        trc.check().expect("TRC check should pass");

        // to_pdb should produce SEQRES with all 10 residue names
        let pdb_output = to_pdb(trc).unwrap();
        assert!(
            pdb_output.contains("SEQRES"),
            "output should contain SEQRES"
        );

        // Round-trip: from_pdb(to_pdb(trc)) should preserve residue count and names
        let trcs2 = super::from_pdb(&pdb_output).unwrap();
        assert_eq!(trcs2.len(), 1);
        let trc2 = &trcs2[0];
        assert_eq!(
            trc2.residues.residues.len(),
            trc.residues.residues.len(),
            "round-trip should preserve residue count"
        );

        // Same empty/non-empty pattern
        let empty_indices2: Vec<usize> = trc2
            .residues
            .residues
            .iter()
            .enumerate()
            .filter(|(_, r)| r.is_empty())
            .map(|(i, _)| i)
            .collect();
        assert_eq!(
            empty_indices.len(),
            empty_indices2.len(),
            "round-trip should preserve empty residue count"
        );

        // Same residue names
        assert_eq!(
            trc.residues.seqs, trc2.residues.seqs,
            "round-trip should preserve residue names"
        );
    }

    #[test]
    fn disabling_seqres_omits_terminal_only_placeholders() {
        // SEQRES declares 20 amino acids for chain A, but ATOM records only
        // cover positions 8-15 (the middle 8). This leaves 7 terminal residues
        // at the N-terminus and 5 at the C-terminus, with zero internal gaps.
        // This demonstrates when include_seqres=false is appropriate.
        let pdb = "\
SEQRES   1 A   20  ALA GLY VAL LEU ILE PRO SER THR ASN GLN PHE TRP TYR\n\
SEQRES   2 A   20  HIS LYS ARG ASP GLU MET CYS                       \n\
ATOM      1  N   THR A   8       1.000   2.000   3.000  1.00  0.00           N  \n\
ATOM      2  CA  THR A   8       2.000   2.000   3.000  1.00  0.00           C  \n\
ATOM      3  C   THR A   8       3.000   2.000   3.000  1.00  0.00           C  \n\
ATOM      4  O   THR A   8       4.000   2.000   3.000  1.00  0.00           O  \n\
ATOM      5  CB  THR A   8       5.000   2.000   3.000  1.00  0.00           C  \n\
ATOM      6  OG1 THR A   8       6.000   2.000   3.000  1.00  0.00           O  \n\
ATOM      7  CG2 THR A   8       7.000   2.000   3.000  1.00  0.00           C  \n\
ATOM      8  N   ASN A   9       1.000   3.000   3.000  1.00  0.00           N  \n\
ATOM      9  CA  ASN A   9       2.000   3.000   3.000  1.00  0.00           C  \n\
ATOM     10  C   ASN A   9       3.000   3.000   3.000  1.00  0.00           C  \n\
ATOM     11  O   ASN A   9       4.000   3.000   3.000  1.00  0.00           O  \n\
ATOM     12  CB  ASN A   9       5.000   3.000   3.000  1.00  0.00           C  \n\
ATOM     13  CG  ASN A   9       6.000   3.000   3.000  1.00  0.00           C  \n\
ATOM     14  OD1 ASN A   9       7.000   3.000   3.000  1.00  0.00           O  \n\
ATOM     15  ND2 ASN A   9       8.000   3.000   3.000  1.00  0.00           N  \n\
ATOM     16  N   GLN A  10       1.000   4.000   3.000  1.00  0.00           N  \n\
ATOM     17  CA  GLN A  10       2.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     18  C   GLN A  10       3.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     19  O   GLN A  10       4.000   4.000   3.000  1.00  0.00           O  \n\
ATOM     20  CB  GLN A  10       5.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     21  CG  GLN A  10       6.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     22  CD  GLN A  10       7.000   4.000   3.000  1.00  0.00           C  \n\
ATOM     23  OE1 GLN A  10       8.000   4.000   3.000  1.00  0.00           O  \n\
ATOM     24  NE2 GLN A  10       9.000   4.000   3.000  1.00  0.00           N  \n\
ATOM     25  N   PHE A  11       1.000   5.000   3.000  1.00  0.00           N  \n\
ATOM     26  CA  PHE A  11       2.000   5.000   3.000  1.00  0.00           C  \n\
ATOM     27  C   PHE A  11       3.000   5.000   3.000  1.00  0.00           C  \n\
ATOM     28  O   PHE A  11       4.000   5.000   3.000  1.00  0.00           O  \n\
ATOM     29  CB  PHE A  11       5.000   5.000   3.000  1.00  0.00           C  \n\
ATOM     30  CG  PHE A  11       6.000   5.000   3.000  1.00  0.00           C  \n\
ATOM     31  CD1 PHE A  11       7.000   5.000   3.000  1.00  0.00           C  \n\
ATOM     32  CD2 PHE A  11       8.000   5.000   3.000  1.00  0.00           C  \n\
ATOM     33  CE1 PHE A  11       9.000   5.000   3.000  1.00  0.00           C  \n\
ATOM     34  CE2 PHE A  11      10.000   5.000   3.000  1.00  0.00           C  \n\
ATOM     35  CZ  PHE A  11      11.000   5.000   3.000  1.00  0.00           C  \n\
ATOM     36  N   TRP A  12       1.000   6.000   3.000  1.00  0.00           N  \n\
ATOM     37  CA  TRP A  12       2.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     38  C   TRP A  12       3.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     39  O   TRP A  12       4.000   6.000   3.000  1.00  0.00           O  \n\
ATOM     40  CB  TRP A  12       5.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     41  CG  TRP A  12       6.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     42  CD1 TRP A  12       7.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     43  CD2 TRP A  12       8.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     44  NE1 TRP A  12       9.000   6.000   3.000  1.00  0.00           N  \n\
ATOM     45  CE2 TRP A  12      10.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     46  CE3 TRP A  12      11.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     47  CZ2 TRP A  12      12.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     48  CZ3 TRP A  12      13.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     49  CH2 TRP A  12      14.000   6.000   3.000  1.00  0.00           C  \n\
ATOM     50  N   TYR A  13       1.000   7.000   3.000  1.00  0.00           N  \n\
ATOM     51  CA  TYR A  13       2.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     52  C   TYR A  13       3.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     53  O   TYR A  13       4.000   7.000   3.000  1.00  0.00           O  \n\
ATOM     54  CB  TYR A  13       5.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     55  CG  TYR A  13       6.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     56  CD1 TYR A  13       7.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     57  CD2 TYR A  13       8.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     58  CE1 TYR A  13       9.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     59  CE2 TYR A  13      10.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     60  CZ  TYR A  13      11.000   7.000   3.000  1.00  0.00           C  \n\
ATOM     61  OH  TYR A  13      12.000   7.000   3.000  1.00  0.00           O  \n\
ATOM     62  N   HIS A  14       1.000   8.000   3.000  1.00  0.00           N  \n\
ATOM     63  CA  HIS A  14       2.000   8.000   3.000  1.00  0.00           C  \n\
ATOM     64  C   HIS A  14       3.000   8.000   3.000  1.00  0.00           C  \n\
ATOM     65  O   HIS A  14       4.000   8.000   3.000  1.00  0.00           O  \n\
ATOM     66  CB  HIS A  14       5.000   8.000   3.000  1.00  0.00           C  \n\
ATOM     67  CG  HIS A  14       6.000   8.000   3.000  1.00  0.00           C  \n\
ATOM     68  ND1 HIS A  14       7.000   8.000   3.000  1.00  0.00           N  \n\
ATOM     69  CD2 HIS A  14       8.000   8.000   3.000  1.00  0.00           C  \n\
ATOM     70  CE1 HIS A  14       9.000   8.000   3.000  1.00  0.00           C  \n\
ATOM     71  NE2 HIS A  14      10.000   8.000   3.000  1.00  0.00           N  \n\
ATOM     72  N   LYS A  15       1.000   9.000   3.000  1.00  0.00           N  \n\
ATOM     73  CA  LYS A  15       2.000   9.000   3.000  1.00  0.00           C  \n\
ATOM     74  C   LYS A  15       3.000   9.000   3.000  1.00  0.00           C  \n\
ATOM     75  O   LYS A  15       4.000   9.000   3.000  1.00  0.00           O  \n\
ATOM     76  CB  LYS A  15       5.000   9.000   3.000  1.00  0.00           C  \n\
ATOM     77  CG  LYS A  15       6.000   9.000   3.000  1.00  0.00           C  \n\
ATOM     78  CD  LYS A  15       7.000   9.000   3.000  1.00  0.00           C  \n\
ATOM     79  CE  LYS A  15       8.000   9.000   3.000  1.00  0.00           C  \n\
ATOM     80  NZ  LYS A  15       9.000   9.000   3.000  1.00  0.00           N  \n\
END\n";

        // With SEQRES (default): 20 residues (8 resolved + 12 empty terminal)
        let trcs = super::from_pdb(pdb).unwrap();
        let trc = &trcs[0];
        assert_eq!(
            trc.residues.residues.len(),
            20,
            "expected 20 residues with SEQRES"
        );

        let empty_count = trc
            .residues
            .residues
            .iter()
            .filter(|r| r.is_empty())
            .count();
        assert_eq!(empty_count, 12, "expected 12 empty terminal residues");

        // No internal gaps — all empties are before seq_n 8 or after seq_n 15
        let resolved_count = trc
            .residues
            .residues
            .iter()
            .filter(|r| !r.is_empty())
            .count();
        assert_eq!(resolved_count, 8, "expected 8 resolved residues");

        // Without SEQRES: only the 8 resolved residues, no terminal noise
        let trcs_no_seqres = super::from_pdb_with_options(pdb, false).unwrap();
        let trc_no_seqres = &trcs_no_seqres[0];
        assert_eq!(
            trc_no_seqres.residues.residues.len(),
            8,
            "expected 8 residues without SEQRES"
        );
        assert_eq!(
            trc_no_seqres
                .residues
                .residues
                .iter()
                .filter(|r| r.is_empty())
                .count(),
            0,
            "expected no empty residues without SEQRES"
        );
    }

    #[cfg(feature = "serde")]
    #[test]
    fn isopropyl_round_trip_to_pdb_is_stable() {
        let trc_json = read_fixture("tests/data/trc/isopropyl.json");
        let isoprophyl: TRC = serde_json::from_str(&trc_json).unwrap();

        let parsed_pdb1 = super::from_pdb(to_pdb(&isoprophyl).unwrap()).unwrap();
        assert_eq!(parsed_pdb1.len(), 1);

        let parsed_pdb2 = super::from_pdb(to_pdb(&parsed_pdb1[0].clone()).unwrap()).unwrap();
        assert_eq!(parsed_pdb2.len(), 1);

        assert_eq!(parsed_pdb1[0], parsed_pdb2[0]);
    }

    #[test]
    fn reference_entries_round_trip_atom_identity() {
        let rcsbids = ["7pjq", "9atq", "9dbu", "9hj7", "9jbd", "9jm5"];
        for rcsbid in rcsbids {
            let pdb_content = mmcif_fixture_pdb(rcsbid);
            let pdb_trcs = super::from_pdb(&pdb_content).unwrap();

            for (model_idx, pdb_trc) in pdb_trcs.iter().enumerate() {
                let round_tripped = to_pdb(pdb_trc).unwrap();
                let original_atoms = extract_atom_lines(&pdb_content, true);
                let round_tripped_atoms = extract_atom_lines(&round_tripped, false);

                assert_eq!(
                    original_atoms.len(),
                    round_tripped_atoms.len(),
                    "{rcsbid} model {model_idx}: ATOM line count mismatch \
                    (original {}, round-tripped {})",
                    original_atoms.len(),
                    round_tripped_atoms.len(),
                );

                let orig_keys = atom_keys(&original_atoms);
                let rt_keys = atom_keys(&round_tripped_atoms);

                for (i, (orig, rt)) in orig_keys.iter().zip(rt_keys.iter()).enumerate() {
                    assert_eq!(
                        orig, rt,
                        "{rcsbid} model {model_idx}: sorted atom {i} mismatch",
                    );
                }
            }
        }
    }
}
