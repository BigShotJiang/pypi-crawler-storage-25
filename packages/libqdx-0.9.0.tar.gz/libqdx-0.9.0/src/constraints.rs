use ouroboros::TypeInfo;

#[derive(Debug, Clone, TypeInfo)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Constraints {
    pub constraint_groups: Vec<Vec<u32>>,
}
