use std::{
    collections::{HashMap, HashSet},
    mem,
    str::FromStr as _,
};

use itertools::Itertools as _;
use ouroboros::TypeInfo;
#[cfg(feature = "rex")]
use rex::Rex;

use crate::{
    AminoAcidSeq, AtomRef, Bond, BondOrder, Chains, Element, Error, FormalCharge, ResidueRef,
    Residues, Topology,
    amino_acid_template::{
        AminoAcidAtom, AminoAcidTemplate, BondTemplate, Terminus, aa_template_by_tok,
    },
};

/// Allows us to change how strict we are when we check for missing atoms, add bonds, etc.
///
/// When we check for missing atoms, we can pass `Heavy` to only check that all heavy atoms are
/// present, `Hydrogens` to only check hydrogens, or `All` to check both. We can also pass `None` to
/// skip these checks, which might be convenient if running a bunch of functions that involve
/// strictness en masse and want to simply set one variable to disable any checking.
///
/// The bond and formal charge perception routines rely on predetermined atom sets to do their work.
/// When these states are incorrect in various ways, things can go wrong.
/// - In perceive_formal_charges: currently needs all atoms to be present; otherwise, the proper
///   protonation states will not be found.
/// - In perceive_bonds: can handle `Heavy` or `All` strictness levels (the former will only add
///   heavy atom bonds).
#[derive(Copy, Clone, Eq, Hash, PartialEq)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(
    feature = "pyo3",
    pyo3::pyclass(eq, eq_int, hash, frozen, from_py_object)
)]
pub enum AtomCheckStrictness {
    #[cfg_attr(feature = "serde", serde(alias = "None"))]
    NONE,
    Heavy,
    All,
}

#[derive(Clone, Debug, PartialEq, TypeInfo)]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "TRCInput", name = "TRC", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(feature = "rex", derive(Rex))]
pub struct TRC {
    pub topology: Topology,
    pub residues: Residues,
    pub chains: Chains,
}

#[derive(Clone, Debug, PartialEq, TypeInfo)]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "TRInput", name = "TR", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct TR {
    pub topology: Topology,
    pub residues: Residues,
}

impl TR {
    pub fn new_tr_from_residue_subset(&self, residue_refs: &[ResidueRef]) -> Self {
        let mut residue_subset = Vec::with_capacity(residue_refs.len());
        for residue_ref in residue_refs {
            residue_subset.push(self.residues.residues[residue_ref.0 as usize].clone());
        }

        Self {
            topology: self
                .topology
                .new_topology_from_residue_subset(&residue_subset),
            residues: self.residues.new_residues_from_subset(residue_refs),
        }
    }
}

#[derive(Clone, Copy, Debug, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum TRCError {
    #[error("residue not in any chain '{0:?}'")]
    ResidueNotInChain(ResidueRef),
    #[error("referenced residue not in residues '{0:?}'")]
    ResidueDoesNotExist(ResidueRef),
    #[error(transparent)]
    InvalidChains(#[from] crate::ChainsError),

    #[error("atoms exist in the topology that are not in any residue")]
    AtomsNotInResidues,
    #[error("referenced residue not in residues '{0:?}'")]
    AtomDoesNotExist(AtomRef),
    #[error(transparent)]
    InvalidTopology(#[from] crate::TopologyError),
    #[error(transparent)]
    InvalidResidues(#[from] crate::ResiduesError),
}

impl TRC {
    pub fn check(&self) -> Result<(), TRCError> {
        self.topology.check()?;
        self.residues.check()?;
        self.chains.check()?;

        let mut atom_set = std::collections::HashSet::new();
        for residue in self.residues.residues.iter() {
            for atom in residue.0.iter() {
                if atom_set.contains(atom) {
                    return Err(TRCError::AtomDoesNotExist(*atom));
                }
                atom_set.insert(atom);
            }
        }

        if atom_set.len() != self.topology.symbols.len() {
            return Err(TRCError::AtomsNotInResidues);
        }

        // check that all residues are contained in the chains
        for (i, _) in self.residues.residues.iter().enumerate() {
            let mut found = false;
            for chain in self.chains.chains.iter() {
                if chain.0.contains(&(i).into()) {
                    found = true;
                    break;
                }
            }
            if !found {
                return Err(TRCError::ResidueNotInChain(i.into()));
            }
        }

        // check that all referenced residues exist
        for chain in self.chains.chains.iter() {
            for residue in chain.0.iter() {
                if residue.0 as usize >= self.residues.residues.len() {
                    return Err(TRCError::ResidueDoesNotExist(*residue));
                }
            }
        }

        Ok(())
    }

    pub fn extend(&mut self, other: Self) -> Result<(), TRCError> {
        self.topology.extend(other.topology);
        self.residues.extend(other.residues)?;
        self.chains.extend(other.chains)?;
        Ok(())
    }

    pub fn new_trc_from_residue_subset(&self, residue_refs: &[ResidueRef]) -> Self {
        let mut residue_subset = Vec::with_capacity(residue_refs.len());
        for residue_ref in residue_refs {
            residue_subset.push(self.residues.residues[residue_ref.0 as usize].clone());
        }

        Self {
            topology: self
                .topology
                .new_topology_from_residue_subset(&residue_subset),
            residues: self.residues.new_residues_from_subset(residue_refs),
            chains: self.chains.new_chains_from_residue_subset(residue_refs),
        }
    }

    /// Use amino acid templates to assign formal charges to atoms
    pub fn perceive_formal_charges(&mut self) -> Result<(), Error> {
        self.ensure_no_missing_atoms(AtomCheckStrictness::All)?;
        // Assign charges for all atoms in all amino acids
        if let (aas, aa_seq, Some(connectivity), Some(atom_labels)) = (
            &self.residues.residues,
            &self.residues.seqs,
            &self.topology.connectivity,
            &self.topology.labels,
        ) {
            let mut total_charge = 0;
            for (aa_idx, aa) in aas.iter().enumerate() {
                let aa_seq_checked = match AminoAcidSeq::from_pdb_std_name(&aa_seq[aa_idx]) {
                    Ok(aa_seq) => aa_seq,
                    _ => {
                        continue; // Skip non-amino-acid residues
                    }
                };

                let aa_ref = aa_template_by_tok(aa_seq_checked)
                    .ok_or(Error::MissingAminoAcidTemplate { aa: aa_seq_checked })?;
                let aa_seq_id = self.residues.seq_ns[aa_idx];
                let aa_atoms = aa.iter().try_fold(HashSet::new(), |mut acc, &atom_idx| {
                    acc.insert(
                        AminoAcidAtom::from_str(&atom_labels[atom_idx.0 as usize]).map_err(
                            |_| Error::BadAtomLabel {
                                atom_label: atom_labels[atom_idx.0 as usize].clone(),
                            },
                        )?,
                    );
                    Ok(acc)
                })?;
                // allow covalent binders on SER's OG atom
                let extra_atoms = self.covalent_binder_substitutes(
                    aa_seq_checked,
                    aa.0.iter().map(|x| x.0).collect::<Vec<_>>().as_slice(),
                    &Some(atom_labels.clone()),
                );
                if !aa_atoms.is_disjoint(&extra_atoms) {
                    return Err(Error::ClashBetweenCovalentBinderAndHydrogen {
                        aa: aa_seq_checked,
                        aa_seq_n: Some(aa_seq_id),
                        clashing_atoms: aa_atoms
                            .intersection(&extra_atoms)
                            .map(|a| a.to_string())
                            .collect(),
                    });
                }
                let aa_heavy_atom_charges = aa_ref
                    .find_protonation_state(&aa_atoms, &extra_atoms)
                    .ok_or({
                        let hydrogen_atoms: Vec<_> = aa_atoms
                            .iter()
                            .filter(|&l| l.to_str().starts_with('H'))
                            .map(|l| l.to_string())
                            .collect();
                        if hydrogen_atoms.is_empty() {
                            Error::NoAminoAcidHydrogens {
                                aa: aa_seq_checked,
                                aa_seq_n: Some(aa_seq_id),
                            }
                        } else {
                            Error::BadProtonationState {
                                aa: aa_seq_checked,
                                aa_seq_n: Some(aa_seq_id),
                                hydrogen_atoms,
                            }
                        }
                    })?
                    .heavy_atom_charges;

                // Maps the index [of the atom in ths instance of the aa] into its charge
                let aa_heavy_atom_map = aa
                    .iter()
                    .filter_map(|&atom_idx| {
                        let aa_atom = AminoAcidAtom::from_str(&atom_labels[atom_idx.0 as usize])
                            .ok()?
                            .get_equivalence_class(aa_seq_checked);
                        if aa_atom == AminoAcidAtom::OXT {
                            Some((atom_idx, i8::MIN))
                        } else {
                            aa_ref
                                .heavy_atom_labels
                                .iter()
                                .position(|ref_aa_atom| ref_aa_atom == &aa_atom)
                                .map(|aa_ref_idx| (atom_idx, aa_heavy_atom_charges[aa_ref_idx]))
                        }
                    })
                    .collect::<HashMap<_, _>>();

                // Assign the heavy atom charges based on the identified protonation state
                let is_c_terminus = aa_ref.is_terminus(&aa_atoms, Terminus::C);
                let is_n_terminus = aa_ref.is_terminus(&aa_atoms, Terminus::N);
                for (&atom_idx, &atom_charge) in aa_heavy_atom_map.iter() {
                    let aa_atom = AminoAcidAtom::from_str(&atom_labels[atom_idx.0 as usize])
                        .map_err(|_| Error::BadAtomLabel {
                            atom_label: atom_labels[atom_idx.0 as usize].clone(),
                        })?
                        .get_equivalence_class(aa_seq_checked);
                    let mut finalized_atom_charge = atom_charge;
                    if is_c_terminus && aa_atom == AminoAcidAtom::OXT {
                        // Handle c-terminus
                        finalized_atom_charge =
                            aa_ref.gen_termini_charge(&aa_atoms, Terminus::C).unwrap();
                    }
                    if is_n_terminus && aa_atom == AminoAcidAtom::N {
                        // Handle n-terminus
                        finalized_atom_charge =
                            aa_ref.gen_termini_charge(&aa_atoms, Terminus::N).unwrap();
                    }
                    if self.topology.symbols[atom_idx.0 as usize] == Element::S
                        && connectivity
                            .iter()
                            .filter(|bond| {
                                (bond.0 == atom_idx
                                    && self.topology.symbols[bond.1.0 as usize] == Element::S)
                                    || (bond.1 == atom_idx
                                        && self.topology.symbols[bond.0.0 as usize] == Element::S)
                            })
                            .peekable()
                            .peek()
                            .is_some()
                    {
                        // Correct the charge in the case of a disulfide bridge
                        finalized_atom_charge += 1;
                    }
                    if !(-1..=2).contains(&finalized_atom_charge) {
                        eprintln!(
                            "WARNING: atom {} has unexpectedly large magnitude of charge: {:+}.",
                            atom_idx.0, finalized_atom_charge,
                        );
                    }
                    if let Some(atom_charges) = &mut self.topology.formal_charges {
                        atom_charges[atom_idx.0 as usize] =
                            FormalCharge(finalized_atom_charge as i32);
                    }
                    total_charge += finalized_atom_charge;
                }
                // Assign all hydrogens a charge of 0
                for &atom_idx in aa.iter().filter(|&&atom_idx| {
                    ["H", "1H", "2H", "3H"]
                        .iter()
                        .any(|prefix| atom_labels[atom_idx.0 as usize].starts_with(prefix))
                }) {
                    if let Some(atom_charges) = &mut self.topology.formal_charges {
                        atom_charges[atom_idx.0 as usize] = FormalCharge(0);
                    }
                }
            }
            if !(-20..=20).contains(&total_charge) {
                eprintln!(
                    "WARNING: total charge of all amino acids has unexpectedly large magnitude: \
                    {total_charge:+}.",
                );
            }
        }
        // fixup fragment charges
        if let Some(fragments) = &self.topology.fragments {
            let mut fragment_formal_charges = vec![FormalCharge(0); fragments.len()];
            for (fragment_idx, fragment) in fragments.iter().enumerate() {
                let mut fragment_formal_charge = 0;
                for atom_idx in fragment.iter() {
                    if let Some(formal_charges) = &self.topology.formal_charges
                        && let Some(formal_charge) = formal_charges.get(atom_idx.0 as usize)
                    {
                        fragment_formal_charge += formal_charge.0;
                    }
                }
                fragment_formal_charges[fragment_idx] = FormalCharge(fragment_formal_charge);
            }
            self.topology.fragment_formal_charges = Some(fragment_formal_charges);
        } else {
            self.topology.fragment_formal_charges = None;
        }

        Ok(())
    }

    pub fn perceive_bonds(
        &mut self,
        missing_atom_strictness: AtomCheckStrictness,
    ) -> Result<(), Error> {
        self.ensure_no_missing_atoms(missing_atom_strictness)?;
        // Clear existing bonds within amino acids and the chain's backbone,
        let old_connectivity = if let Some(ref mut connectivity) = self.topology.connectivity {
            let out = connectivity.clone();
            connectivity.retain(|bond| {
                let symbols = &self.topology.symbols;
                let atom0_idx = bond.0.0 as usize;
                let atom1_idx = bond.1.0 as usize;

                // Identify bonds with one atom not in an amino acid; we can't recreate these
                let not_in_aa = self
                    .residues
                    .non_amino_acid_iter()
                    .flat_map(|idx| self.residues.residues[idx.0 as usize].iter())
                    .contains(&bond.0)
                    || self
                        .residues
                        .non_amino_acid_iter()
                        .flat_map(|idx| self.residues.residues[idx.0 as usize].iter())
                        .contains(&bond.1);

                // Explicitly keep disulfide bridges too
                (symbols[atom0_idx] == Element::S && symbols[atom1_idx] == Element::S) || not_in_aa
            });
            out
        } else {
            self.topology.connectivity = Some(vec![]);
            vec![]
        };
        // Add bonds to each amino acid
        if let (aas, aa_seq, Some(atom_labels)) = (
            &self.residues.residues,
            &self.residues.seqs,
            &self.topology.labels,
        ) {
            for (i, aa) in aas.iter().enumerate() {
                let aa_seq_checked = match AminoAcidSeq::from_pdb_std_name(&aa_seq[i]) {
                    Ok(aa_seq) => aa_seq,
                    _ => {
                        continue; // Skip non-amino-acid residues
                    }
                };

                // Add inter amino acid bonds
                if i >= 1
                    && let (Some(&prev_c), Some(&curr_n)) =
                        (
                            aas[i - 1].iter().find(|&&atom_idx| {
                                AminoAcidAtom::from_str(&atom_labels[atom_idx.0 as usize])
                                    .is_ok_and(|aa_atom| {
                                        aa_atom.get_equivalence_class(aa_seq_checked)
                                            == AminoAcidAtom::C
                                    })
                            }),
                            aas[i].iter().find(|&&atom_idx| {
                                AminoAcidAtom::from_str(&atom_labels[atom_idx.0 as usize])
                                    .is_ok_and(|aa_atom| {
                                        aa_atom.get_equivalence_class(aa_seq_checked)
                                            == AminoAcidAtom::N
                                    })
                            }),
                        )
                {
                    // 2.0 is a lenient estimate for the size of a peptide bond.
                    // If the distance is smaller than this, a bond is guaranteed.
                    // If the distance is larger, a bond is nearly impossible.
                    // TODO: Check this against SEQRES, error on missing residues.
                    // Will also allow us to check for loops like in 1za8 and 2kuk
                    if self.topology.distance_between_atoms(prev_c, curr_n) < 2.0 {
                        self.topology
                            .connectivity
                            .as_mut()
                            .ok_or(Error::MissingAminoAcidTopologyData)?
                            .push(Bond(
                                AtomRef(prev_c.0.min(curr_n.0)),
                                AtomRef(prev_c.0.max(curr_n.0)),
                                BondOrder::Single,
                            ))
                    }
                }
                // Get the reference aa template for this aa instance in our structure
                let aa_ref = aa_template_by_tok(aa_seq_checked)
                    .ok_or(Error::MissingAminoAcidTemplate { aa: aa_seq_checked })?;
                // Maps the label into the index of this instance of that atom for this aa
                let aa_atom_map = aa.iter().try_fold(
                    HashMap::new(),
                    |mut acc, &atom_idx| -> Result<HashMap<AminoAcidAtom, u32>, Error> {
                        acc.insert(
                            AminoAcidAtom::from_str(&atom_labels[atom_idx.0 as usize])
                                .map_err(|_| Error::BadAtomLabel {
                                    atom_label: atom_labels[atom_idx.0 as usize].clone(),
                                })?
                                .get_equivalence_class(aa_seq_checked),
                            atom_idx.0,
                        );
                        Ok(acc)
                    },
                )?;
                // Construct the instance of the bonds for this aa using the instance atom idxs
                // NOTE: We use all+contains here instead of forming a BTreeSet and using subset
                //       because we want to make fewer clones...
                //       comparing Container<T> to Container<&T> is a pain
                if aa_atom_map
                    .keys()
                    .map(|k| k.get_equivalence_class(aa_seq_checked))
                    .all(|k| {
                        aa_ref.heavy_atom_labels.contains(&k)
                            || aa_ref.hydrogen_labels.contains(&k)
                            || AminoAcidTemplate::TERMINI_ATOMS.contains(&k)
                    })
                {
                    let new_connections = aa_ref
                        .bonds
                        .iter()
                        .filter_map(|BondTemplate(a1, a2, order)| {
                            match (aa_atom_map.get(a1), aa_atom_map.get(a2)) {
                                (Some(a_idx1), Some(a_idx2)) => Some(Bond(
                                    AtomRef(*a_idx1.min(a_idx2)),
                                    AtomRef(*a_idx1.max(a_idx2)),
                                    *order,
                                )),
                                _ => None,
                            }
                        })
                        .chain(aa_ref.gen_termini_bonds(&aa_atom_map));
                    self.topology
                        .connectivity
                        .as_mut()
                        .ok_or(Error::MissingAminoAcidTopologyData)?
                        .extend(new_connections);
                } else {
                    let wrong_atoms: Vec<_> = aa_atom_map
                        .keys()
                        .map(|k| k.get_equivalence_class(aa_seq_checked))
                        .filter(|k| {
                            !aa_ref.heavy_atom_labels.contains(k)
                                && !aa_ref.hydrogen_labels.contains(k)
                                && !AminoAcidTemplate::TERMINI_ATOMS.contains(k)
                        })
                        .map(|atom_label| atom_label.to_string())
                        .collect();
                    return Err(Error::WrongAtomsInAminoAcid {
                        aa: aa_seq_checked,
                        aa_seq_n: Some(self.residues.seq_ns[i]),
                        wrong_atoms,
                    });
                }
            }
        }
        // Check that we found all previously-present bonds; add back ones we missed with a warning
        let not_added = old_connectivity
            .iter()
            .filter(|old_bond| {
                !self
                    .topology
                    .connectivity
                    .as_ref()
                    .unwrap()
                    .iter()
                    .any(|new_bond| {
                        (old_bond.0 == new_bond.0 && old_bond.1 == new_bond.1)
                            || (old_bond.0 == new_bond.1 && old_bond.1 == new_bond.0)
                    })
            })
            .collect::<Vec<_>>();
        for n in not_added {
            eprintln!(
                "WARNING: didn't add previously-existing bond during perception: {}. \
                Adding it now.",
                self.display_bond(n)
            );
            self.topology
                .connectivity
                .as_mut()
                .ok_or(Error::MissingAminoAcidTopologyData)?
                .push(*n);
        }
        self.perceive_bonds_water();
        Ok(())
    }

    pub fn perceive_bonds_water(&mut self) {
        let num_atoms = self.topology.symbols.len();

        let connectivity = self.topology.connectivity.get_or_insert(Vec::new());

        let mut adjacencies = Vec::with_capacity(num_atoms);
        adjacencies.resize(num_atoms, Vec::with_capacity(4));

        for bond in connectivity.iter() {
            adjacencies[bond.0.0 as usize].push(bond.1.0 as usize);
            adjacencies[bond.1.0 as usize].push(bond.0.0 as usize);
        }

        for residue in self.residues.residues.iter() {
            if residue.len() != 3 {
                continue;
            }

            let indices = {
                let i1 = residue.0[0].0 as usize;
                let i2 = residue.0[1].0 as usize;
                let i3 = residue.0[2].0 as usize;

                match (
                    self.topology.symbols[i1],
                    self.topology.symbols[i2],
                    self.topology.symbols[i3],
                ) {
                    (Element::O, Element::H, Element::H) => Some((i1, i2, i3)),
                    (Element::H, Element::O, Element::H) => Some((i2, i1, i3)),
                    (Element::H, Element::H, Element::O) => Some((i2, i3, i1)),
                    _ => None,
                }
            };

            if let Some((o_index, h1_index, h2_index)) = indices {
                if !adjacencies[o_index].contains(&h1_index) {
                    connectivity.push(Bond(
                        AtomRef(o_index as u32),
                        AtomRef(h1_index as u32),
                        BondOrder::Single,
                    ))
                }
                if !adjacencies[o_index].contains(&h2_index) {
                    connectivity.push(Bond(
                        AtomRef(o_index as u32),
                        AtomRef(h2_index as u32),
                        BondOrder::Single,
                    ))
                }
            }
        }
    }

    pub fn ensure_no_missing_atoms(
        &mut self,
        strictness: AtomCheckStrictness,
    ) -> Result<(), Error> {
        if strictness == AtomCheckStrictness::NONE {
            return Ok(());
        }

        if let (aas, aa_seq, Some(atom_labels)) = (
            &self.residues.residues,
            &self.residues.seqs,
            &self.topology.labels,
        ) {
            for (i, aa) in aas.iter().enumerate() {
                let aa_seq_checked = match AminoAcidSeq::from_pdb_std_name(&aa_seq[i]) {
                    Ok(aa_seq) => aa_seq,
                    Err(_) => {
                        continue;
                    }
                };

                let aa_ref = aa_template_by_tok(aa_seq_checked)
                    .ok_or(Error::MissingAminoAcidTemplate { aa: aa_seq_checked })?;

                let aa_seq_n = self.residues.seq_ns[i];

                // Make sure atom labels are unique
                let aa_atoms = aa.0.iter().try_fold(HashSet::new(), |mut acc, &atom_idx| {
                    let aa_atom =
                        AminoAcidAtom::from_str(atom_labels[atom_idx.0 as usize].as_str())
                            .map_err(|_| Error::BadAtomLabel {
                                atom_label: atom_labels[atom_idx.0 as usize].clone(),
                            })?;
                    match acc.insert(aa_atom) {
                        true => Ok(()),
                        false => Err(Error::DuplicateAtomsInAminoAcid {
                            aa: aa_seq_checked,
                            aa_seq_n: Some(aa_seq_n),
                            duplicate_atoms: vec![aa_atom.to_string()],
                        }),
                    }?;
                    Ok(acc)
                })?;

                // Make sure all heavy atoms are present
                if strictness == AtomCheckStrictness::Heavy
                    || strictness == AtomCheckStrictness::All
                {
                    let standardized_aa_atoms = aa_atoms
                        .iter()
                        .map(|l| l.get_equivalence_class(aa_seq_checked))
                        .collect::<HashSet<_>>();
                    let mut missing_heavy_atoms = aa_ref
                        .heavy_atom_labels
                        .iter()
                        .filter(|&k| !standardized_aa_atoms.contains(k))
                        .peekable();
                    if missing_heavy_atoms.peek().is_some() {
                        return Err(Error::MissingAminoAcidHeavyAtoms {
                            aa: aa_seq_checked,
                            aa_seq_n: Some(aa_seq_n),
                            missing_atoms: missing_heavy_atoms
                                .map(AminoAcidAtom::to_string)
                                .collect(),
                        });
                    }
                }

                // allow covalent binders on SER's OG atom
                let extra_atoms = self.covalent_binder_substitutes(
                    aa_seq_checked,
                    unsafe { mem::transmute::<&[AtomRef], &[u32]>(aa.0.as_slice()) },
                    &self.topology.labels,
                );
                if !aa_atoms.is_disjoint(&extra_atoms) {
                    return Err(Error::ClashBetweenCovalentBinderAndHydrogen {
                        aa: aa_seq_checked,
                        aa_seq_n: Some(aa_seq_n),
                        clashing_atoms: aa_atoms
                            .intersection(&extra_atoms)
                            .map(|a| a.to_string())
                            .collect(),
                    });
                }

                if strictness == AtomCheckStrictness::All
                    && aa_ref
                        .find_protonation_state(&aa_atoms, &extra_atoms)
                        .is_none()
                {
                    let hydrogen_atoms: Vec<_> = aa_atoms
                        .iter()
                        .filter(|&l| l.to_str().starts_with('H'))
                        .map(|l| l.to_string())
                        .collect();
                    if hydrogen_atoms.is_empty() {
                        return Err(Error::NoAminoAcidHydrogens {
                            aa: aa_seq_checked,
                            aa_seq_n: Some(aa_seq_n),
                        });
                    } else {
                        return Err(Error::BadProtonationState {
                            aa: aa_seq_checked,
                            aa_seq_n: Some(aa_seq_n),
                            hydrogen_atoms,
                        });
                    }
                }
            }
        }

        Ok(())
    }

    fn covalent_binder_substitutes(
        &self,
        aa_kind: AminoAcidSeq,
        aa_atom_indices: &[u32],
        atom_labels: &Option<Vec<String>>,
    ) -> HashSet<AminoAcidAtom> {
        let mut extra_atoms = HashSet::new();
        if aa_kind == AminoAcidSeq::SER {
            let mut og_atom_coords = None;
            for atom_idx in aa_atom_indices {
                let atom_idx = *atom_idx as usize;
                if let Some("OG") = atom_labels
                    .as_ref()
                    .and_then(|atom_labels| atom_labels.get(atom_idx).map(|label| label.as_str()))
                {
                    og_atom_coords = Some([
                        self.topology.geometry[atom_idx * 3],
                        self.topology.geometry[atom_idx * 3 + 1],
                        self.topology.geometry[atom_idx * 3 + 2],
                    ])
                }
            }
            let clashing_atoms = self.topology.get_atoms_near_point(
                &og_atom_coords.unwrap(),
                2.5,
                self.residues
                    .non_amino_acid_iter()
                    .map(|r| unsafe { mem::transmute(&self.residues.residues[r.0 as usize].0) }), // FIXME: Pretty sure this is safe
            );
            if !clashing_atoms
                .iter()
                .filter(|&&atom_idx| self.topology.symbols[atom_idx as usize] == Element::H)
                .collect::<Vec<_>>()
                .is_empty()
            {
                eprintln!(
                    "WARNING: hydrogen in non-protein residue (e.g. water) clashes with \
                         protein atom. Check the protonation of your ligands and waters."
                );
            }
            if !clashing_atoms
                .iter()
                // TODO: for now, we filter out hydrogen clashes, but they're bad (2zff)
                .filter(|&&atom_idx| self.topology.symbols[atom_idx as usize] != Element::H)
                .collect::<Vec<_>>()
                .is_empty()
            {
                extra_atoms.insert(AminoAcidAtom::HG);
            }
        }
        extra_atoms
    }

    fn display_bond(&self, bond: &Bond) -> String {
        let (aas, aa_seq, aa_seq_ids) = (
            &self.residues.residues,
            &self.residues.seqs,
            &self.residues.seq_ns,
        );

        let maybe_atom0_aa_info = aas
            .iter()
            .position(|aa| aa.contains(&bond.0))
            .map(|aa_idx| (&aa_seq[aa_idx], aa_seq_ids[aa_idx]));
        let maybe_atom1_aa_info = aas
            .iter()
            .position(|aa| aa.contains(&bond.1))
            .map(|aa_idx| (&aa_seq[aa_idx], aa_seq_ids[aa_idx]));
        let atom0_symbol = self.topology.symbols[bond.0.0 as usize];
        let atom1_symbol = self.topology.symbols[bond.1.0 as usize];

        #[allow(clippy::useless_asref)]
        let maybe_atom0_label = self
            .topology
            .labels
            .as_ref()
            .map(|atom_labels| atom_labels[bond.0.0 as usize].clone());

        #[allow(clippy::useless_asref)]
        let maybe_atom1_label = self
            .topology
            .labels
            .as_ref()
            .map(|atom_labels| atom_labels[bond.1.0 as usize].clone());
        format!(
            "{} {} {} [{}]{}",
            if let Some(atom0_label) = maybe_atom0_label {
                format!("{atom0_label} ({atom0_symbol})")
            } else {
                atom0_symbol.to_string()
            },
            match bond.2 {
                BondOrder::Single => "-",
                BondOrder::Double => "=",
                BondOrder::Triple => "≡",
                BondOrder::OneAndAHalf => "∹",
                BondOrder::Ring => "⏣",
                _ => "?",
            },
            if let Some(atom1_label) = maybe_atom1_label {
                format!("{atom1_label} ({atom1_symbol})")
            } else {
                atom1_symbol.to_string()
            },
            match bond.2 {
                BondOrder::Single => "single bond",
                BondOrder::Double => "double bond",
                BondOrder::Triple => "triple bond",
                BondOrder::OneAndAHalf => "1.5 bond",
                BondOrder::Ring => "aromatic bond",
                _ => "unknown bond",
            },
            if let (Some((atom0_aa_seq, atom0_aa_seq_id)), Some((atom1_aa_seq, atom1_aa_seq_id))) =
                (maybe_atom0_aa_info, maybe_atom1_aa_info)
            {
                if atom0_aa_seq_id == atom1_aa_seq_id {
                    format!(" @ {atom0_aa_seq_id} ({atom0_aa_seq:?})")
                } else {
                    format!(
                        " @ {atom0_aa_seq_id} ({atom0_aa_seq:?}) & {atom1_aa_seq_id} ({atom1_aa_seq:?})",
                    )
                }
            } else {
                "".to_string()
            }
        )
    }
}
