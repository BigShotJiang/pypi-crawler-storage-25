use ouroboros::TypeInfo;

/// Level of chemical theory
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::Enum),
    graphql(name = "QMMethod")
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum Method {
    #[default]
    #[cfg_attr(
        feature = "serde",
        serde(
            alias = "RESTRICTEDHF",
            alias = "RestrictedHF",
            alias = "restrictedhf",
            alias = "RESTRICTED-HF",
            alias = "Restricted-HF",
            alias = "restricted-hf",
            alias = "RHF",
            alias = "rhf",
            alias = "R-HF",
            alias = "r-hf",
        )
    )]
    RestrictedHF = 1,
    #[cfg_attr(
        feature = "serde",
        serde(
            alias = "UNRESTRICTEDHF",
            alias = "UnrestrictedHF",
            alias = "unrestrictedhf",
            alias = "UNRESTRICTED-HF",
            alias = "Unrestricted-HF",
            alias = "unrestricted-hf",
            alias = "UHF",
            alias = "uhf",
            alias = "U-HF",
            alias = "u-hf",
        )
    )]
    UnrestrictedHF = 2,
    #[cfg_attr(
        feature = "serde",
        serde(
            alias = "RESTRICTEDKSDFT",
            alias = "RestrictedKSDFT",
            alias = "restrictedksdft",
            alias = "RESTRICTED-KSDFT",
            alias = "Restricted-KSDFT",
            alias = "restricted-ksdft",
            alias = "RKSDFT",
            alias = "rksdft",
            alias = "R-KSDFT",
            alias = "r-ksdft",
            alias = "KSDFT",
            alias = "ksdft",
        )
    )]
    RestrictedKSDFT = 3,
    #[cfg_attr(
        feature = "serde",
        serde(
            alias = "RESTRICTEDRIMP2",
            alias = "RestrictedRIMP2",
            alias = "restrictedrimp2",
            alias = "RESTRICTED-RIMP2",
            alias = "Restricted-RIMP2",
            alias = "restricted-rimp2",
            alias = "RRIMP2",
            alias = "rrimp2",
            alias = "R-RIMP2",
            alias = "r-rimp2",
            alias = "RIMP2",
            alias = "rimp2",
        )
    )]
    RestrictedRIMP2 = 7,
    #[cfg_attr(
        feature = "serde",
        serde(
            alias = "UNRESTRICTEDRIMP2",
            alias = "UnrestrictedRIMP2",
            alias = "unrestrictedrimp2",
            alias = "UNRESTRICTED-RIMP2",
            alias = "Unrestricted-RIMP2",
            alias = "unrestricted-rimp2",
            alias = "URIMP2",
            alias = "urimp2",
            alias = "U-RIMP2",
            alias = "u-rimp2",
        )
    )]
    UnrestrictedRIMP2 = 8,
    #[cfg_attr(
        feature = "serde",
        serde(
            alias = "RESTRICTEDRICCSD",
            alias = "RestrictedRICCSD",
            alias = "restrictedriccsd",
            alias = "RESTRICTED-RICCSD",
            alias = "Restricted-RICCSD",
            alias = "restricted-riccsd",
            alias = "RRICCSD",
            alias = "rriccsd",
            alias = "R-RICCSD",
            alias = "r-riccsd",
            alias = "RICCSD",
            alias = "riccsd",
        )
    )]
    RestrictedRICCSD = 16,
}
