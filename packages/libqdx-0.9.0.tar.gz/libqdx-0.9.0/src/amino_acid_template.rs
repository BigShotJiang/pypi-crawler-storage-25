use std::collections::{HashMap, HashSet};
use std::fmt::{self, Display, Formatter};
use std::str::FromStr;

use lazy_static::lazy_static;
use ouroboros::TypeInfo;

use crate::{AminoAcidSeq, AtomRef, Bond, BondOrder, Error};

use self::AminoAcidAtom::*;

#[derive(Clone, Debug)]
pub struct ProtonationState {
    pub missing_hydrogens: HashSet<AminoAcidAtom>,
    pub heavy_atom_charges: Vec<i8>,
}

impl ProtonationState {
    pub fn default(n_atoms: u32) -> ProtonationState {
        ProtonationState {
            missing_hydrogens: From::from([]),
            heavy_atom_charges: vec![0; n_atoms as usize],
        }
    }
}

#[derive(Copy, Clone, PartialEq, Eq)]
pub struct BondTemplate(pub AminoAcidAtom, pub AminoAcidAtom, pub BondOrder);

pub enum Terminus {
    C,
    N,
}

pub struct AminoAcidTemplate {
    pub tok: AminoAcidSeq,
    pub protonation_state_variants: HashMap<&'static str, ProtonationState>,
    pub heavy_atom_labels: Vec<AminoAcidAtom>,
    pub hydrogen_labels: HashSet<AminoAcidAtom>,
    pub bonds: Vec<BondTemplate>,
}

impl AminoAcidTemplate {
    pub const CAP_RESIDUES: [AminoAcidSeq; 5] = [
        AminoAcidSeq::ACE,
        AminoAcidSeq::BNC,
        AminoAcidSeq::NME,
        AminoAcidSeq::NMA,
        AminoAcidSeq::NHH,
    ];
    /// Stores labels only present in termini. The label H is needed here because of PRO and HYP.
    pub const TERMINI_ATOMS: [AminoAcidAtom; 6] = [OXT, HXT, H1, H2, H3, H];

    /// An amino acid template is a cap if it's in our explicit list of cap-like residues.
    /// Ideally these should be HETATM since they aren't amino acids, but they aren't always.
    pub fn is_cap(&self) -> bool {
        AminoAcidTemplate::CAP_RESIDUES.contains(&self.tok)
    }

    /// Checks if the amino acid specified by the set of atom labels passed in is a terminus by
    /// checking if it has any atoms present only in termini. It's invalid for a non-terminal amino
    /// acid to have any of these atoms.
    /// `aa_atom_labels` must contain all atoms, including hydrogens, in a single amino acid.
    /// NOTE: There's no need to include H in the case of PRO and HYP in the check here because to
    ///       be a terminal residue it must contain at least one numbered H label anyway.
    /// TODO: This fails for an N-terminus that isn't expected to be protonated. We're only using it
    ///       during charge assignment right now, where protonation is assumed.
    pub fn is_terminus(
        &self,
        aa_atom_labels: &HashSet<AminoAcidAtom>,
        terminus_type: Terminus,
    ) -> bool {
        if self.is_cap() {
            return false;
        }
        let aa_atom_labels_standardized = aa_atom_labels
            .iter()
            .map(|&k| k.get_equivalence_class(self.tok))
            .collect::<HashSet<_>>();
        match terminus_type {
            Terminus::C => aa_atom_labels_standardized.contains(&OXT),
            Terminus::N => [H2, H3]
                .iter()
                .any(|ter_h_label| aa_atom_labels_standardized.contains(ter_h_label)),
        }
    }

    /// Returns the name of the protonation state based on the atom labels passed in.
    /// `aa_atom_labels` must contain all hydrogen atoms in the single amino acid residue to check,
    /// but there is no problem if it contains more (e.g. the heavy atoms too).
    /// As expected, it will return None if there is no protonation state found.
    pub fn find_protonation_state_name(
        &self,
        aa_atom_labels: &HashSet<AminoAcidAtom>,
    ) -> Option<String> {
        let missing_hydrogens = self
            .hydrogen_labels
            .iter()
            .filter_map(|&k| {
                (!aa_atom_labels
                    .iter()
                    .map(|l| l.get_equivalence_class(self.tok))
                    .collect::<HashSet<_>>()
                    .contains(&k))
                .then_some(k)
            })
            .collect::<HashSet<AminoAcidAtom>>();
        // Return the matching variant, if there is one
        let state_names = self
            .protonation_state_variants
            .iter()
            .filter_map(|(&state_name, state_data)| {
                if state_data.missing_hydrogens == missing_hydrogens {
                    Some(state_name)
                } else {
                    None
                }
            })
            .collect::<Vec<_>>();
        Some(state_names.first()?.to_string())
    }

    /// Matches the atom labels passed in with a protonation state.
    /// `aa_atom_labels` must contain all hydrogen atoms in the single amino acid residue to check,
    /// but there is no problem if it contains more (e.g. the heavy atoms too).
    /// As expected, it will return None if there is no protonation state found.
    pub fn find_protonation_state(
        &self,
        aa_atom_labels: &HashSet<AminoAcidAtom>,
        extra_atom_labels: &HashSet<AminoAcidAtom>,
    ) -> Option<ProtonationState> {
        let missing_hydrogens = self
            .hydrogen_labels
            .iter()
            .filter_map(|&k| {
                (!aa_atom_labels
                    .iter()
                    .chain(extra_atom_labels.iter())
                    .map(|l| l.get_equivalence_class(self.tok))
                    .collect::<HashSet<_>>()
                    .contains(&k))
                .then_some(k)
            })
            .collect::<HashSet<AminoAcidAtom>>();
        // Return the matching variant, if there is one
        self.protonation_state_variants
            .values()
            .find(|state| state.missing_hydrogens == missing_hydrogens)
            .cloned()
    }

    /// Produce the bonds for the passed-in amino acid data, for atoms only present in termini.
    /// Returns an empty iterator if the amino acid data doesn't correspond to a terminal residue.
    /// `aa_atom_map` maps the atom label to the atom index for a single amino acid residue,
    /// allowing us to generate the correct bond objects.
    /// NOTE: Caps are handled explicitly, and not as terminal residues.
    pub fn gen_termini_bonds<'a>(
        &'a self,
        aa_atom_map: &'a HashMap<AminoAcidAtom, u32>,
    ) -> impl Iterator<Item = Bond> + 'a {
        // Handle hydrogens that should be connected to the nitrogen
        // The label H by itself is handled as a non-termini bond, except for PRO and HYP
        let ter_h_labels = if [AminoAcidSeq::PRO, AminoAcidSeq::HYP].contains(&self.tok) {
            vec![H, H1, H2, H3]
        } else {
            vec![H1, H2, H3]
        };
        let new_connections = aa_atom_map
            .keys()
            .map(|&k| k.get_equivalence_class(self.tok))
            .filter(move |k| ter_h_labels.contains(k))
            .filter_map(
                |ter_h_label| match (aa_atom_map.get(&N), aa_atom_map.get(&ter_h_label)) {
                    (Some(a_idx1), Some(a_idx2)) => Some(Bond(
                        AtomRef(*a_idx1.min(a_idx2)),
                        AtomRef(*a_idx1.max(a_idx2)),
                        BondOrder::Single,
                    )),
                    _ => None,
                },
            );
        // Handle oxygens at residues at the beginning of chains (and their possible hydrogen)
        let b1 = (aa_atom_map.contains_key(&OXT))
            .then_some(match (aa_atom_map.get(&OXT), aa_atom_map.get(&C)) {
                (Some(a_idx1), Some(a_idx2)) => Some(Bond(
                    AtomRef(*a_idx1.min(a_idx2)),
                    AtomRef(*a_idx1.max(a_idx2)),
                    BondOrder::Single,
                )),
                _ => None,
            })
            .flatten();
        let b2 = (aa_atom_map.contains_key(&HXT))
            .then_some(match (aa_atom_map.get(&OXT), aa_atom_map.get(&HXT)) {
                (Some(a_idx1), Some(a_idx2)) => Some(Bond(
                    AtomRef(*a_idx1.min(a_idx2)),
                    AtomRef(*a_idx1.max(a_idx2)),
                    BondOrder::Single,
                )),
                _ => None,
            })
            .flatten();
        new_connections
            .chain(std::iter::once(b1).flatten())
            .chain(std::iter::once(b2).flatten())
            .filter(|_| !self.is_cap()) // Caps have unique, explicit termini; return empty list
    }

    /// Produce the charges for the passed-in amino acid data, for the relevant terminal heavy atom.
    /// This means the charge for the OXT on a c-terminus, and for the N on the n-terminus.
    /// `aa_atom_labels` must contain all hydrogen atoms in the single amino acid residue to check,
    /// but there is no problem if it contains more (e.g. the heavy atoms too).
    /// Returns a BadTerminusError if the charge doesn't match an acceptable one.
    pub fn gen_termini_charge(
        &self,
        aa_atom_labels: &HashSet<AminoAcidAtom>,
        terminus_type: Terminus,
    ) -> Result<i8, Error> {
        match terminus_type {
            Terminus::C => {
                let n_hs_term = aa_atom_labels.iter().filter(|&&k| k == HXT).count() as i8;
                if (0..=1).contains(&n_hs_term) {
                    return Ok(n_hs_term - 1); // c terminus has 1 hydrogen at neutral charge
                }
            }
            Terminus::N => {
                let mut n_hs_term = aa_atom_labels
                    .iter()
                    .filter(|k| [H, H1, H2, H3].contains(k))
                    .count() as i8;
                // Proline and hydroxyproline have an extra bond on this nitrogen
                if [AminoAcidSeq::PRO, AminoAcidSeq::HYP].contains(&self.tok) {
                    n_hs_term += 1;
                }
                if (2..=3).contains(&n_hs_term) {
                    return Ok(n_hs_term - 2); // n terminus has 2 hydrogen at neutral charge
                } else {
                    print!("{n_hs_term:#?}");
                }
            }
        };
        Err(Error::BadTerminusError {
            found: aa_atom_labels.iter().map(|l| l.to_string()).collect(),
        })
    }
}

lazy_static! {
    #[rustfmt::skip]
    pub static ref GLY: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::GLY,
        heavy_atom_labels: From::from([
            N, CA, C, O]),
        protonation_state_variants: From::from(
            [("GLY", ProtonationState::default(4))]),
        hydrogen_labels: From::from([
            H, HA2, HA3]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA2, BondOrder::Single),
            BondTemplate(CA, HA3, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref ALA: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::ALA,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB]),
        protonation_state_variants: From::from(
            [("ALA", ProtonationState::default(5))]),
        hydrogen_labels: From::from([
            H, HA, HB1, HB2, HB3]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB1, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref VAL: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::VAL,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG1, CG2]),
        protonation_state_variants: From::from(
            [("VAL", ProtonationState::default(7))]),
        hydrogen_labels: From::from([
            H, HA, HB, HG11, HG12, HG13, HG21, HG22, HG23]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG1, CB, BondOrder::Single),
            BondTemplate(CG2, CB, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB, BondOrder::Single),
            BondTemplate(CG1, HG11, BondOrder::Single),
            BondTemplate(CG1, HG12, BondOrder::Single),
            BondTemplate(CG1, HG13, BondOrder::Single),
            BondTemplate(CG2, HG21, BondOrder::Single),
            BondTemplate(CG2, HG22, BondOrder::Single),
            BondTemplate(CG2, HG23, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref LEU: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::LEU,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD1, CD2]),
        protonation_state_variants: From::from(
            [("LEU", ProtonationState::default(8))]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HG, HD11, HD12, HD13, HD21, HD22, HD23]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD1, CG, BondOrder::Single),
            BondTemplate(CD2, CG, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CG, HG, BondOrder::Single),
            BondTemplate(CD1, HD11, BondOrder::Single),
            BondTemplate(CD1, HD12, BondOrder::Single),
            BondTemplate(CD1, HD13, BondOrder::Single),
            BondTemplate(CD2, HD21, BondOrder::Single),
            BondTemplate(CD2, HD22, BondOrder::Single),
            BondTemplate(CD2, HD23, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref ILE: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::ILE,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG1, CG2, CD1]),
        protonation_state_variants: From::from(
            [("ILE", ProtonationState::default(8))]),
        hydrogen_labels: From::from([
            H, HA, HB, HG12, HG13, HG21, HG22, HG23, HD11, HD12, HD13]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG1, CB, BondOrder::Single),
            BondTemplate(CG2, CB, BondOrder::Single),
            BondTemplate(CD1, CG1, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB, BondOrder::Single),
            BondTemplate(CG1, HG12, BondOrder::Single),
            BondTemplate(CG1, HG13, BondOrder::Single),
            BondTemplate(CG2, HG21, BondOrder::Single),
            BondTemplate(CG2, HG22, BondOrder::Single),
            BondTemplate(CG2, HG23, BondOrder::Single),
            BondTemplate(CD1, HD11, BondOrder::Single),
            BondTemplate(CD1, HD12, BondOrder::Single),
            BondTemplate(CD1, HD13, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref PRO: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::PRO,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD]),
        protonation_state_variants: From::from(
            [("PRO", ProtonationState::default(7))]),
        hydrogen_labels: From::from([
            HA, HB2, HB3, HG2, HG3, HD2, HD3]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD, CG, BondOrder::Single),
            BondTemplate(CD, N, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CG, HG2, BondOrder::Single),
            BondTemplate(CG, HG3, BondOrder::Single),
            BondTemplate(CD, HD2, BondOrder::Single),
            BondTemplate(CD, HD3, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref SER: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::SER,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, OG]),
        protonation_state_variants: From::from(
            [("SER", ProtonationState::default(6))]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HG]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(OG, CB, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(OG, HG, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref THR: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::THR,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, OG1, CG2]),
        protonation_state_variants: From::from(
            [("THR", ProtonationState::default(7))]),
        hydrogen_labels: From::from([
            H, HA, HB, HG1, HG21, HG22, HG23]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(OG1, CB, BondOrder::Single),
            BondTemplate(CG2, CB, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB, BondOrder::Single),
            BondTemplate(OG1, HG1, BondOrder::Single),
            BondTemplate(CG2, HG21, BondOrder::Single),
            BondTemplate(CG2, HG22, BondOrder::Single),
            BondTemplate(CG2, HG23, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref ASN: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::ASN,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, OD1, ND2]),
        protonation_state_variants: From::from(
            [("ASN", ProtonationState::default(8))]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HD21, HD22]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(OD1, CG, BondOrder::Double),
            BondTemplate(ND2, CG, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(ND2, HD21, BondOrder::Single),
            BondTemplate(ND2, HD22, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref GLN: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::GLN,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD, OE1, NE2]),
        protonation_state_variants: From::from(
            [("GLN", ProtonationState::default(9))]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HG2, HG3, HE21, HE22]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD, CG, BondOrder::Single),
            BondTemplate(OE1, CD, BondOrder::Double),
            BondTemplate(NE2, CD, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CG, HG2, BondOrder::Single),
            BondTemplate(CG, HG3, BondOrder::Single),
            BondTemplate(NE2, HE21, BondOrder::Single),
            BondTemplate(NE2, HE22, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref CYS: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::CYS,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, SG]),
        protonation_state_variants: From::from([(
            "CYS",
            ProtonationState {
                missing_hydrogens: From::from([]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0] }
        ), (
            "CYD",
            ProtonationState {
                missing_hydrogens: From::from([HG]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, -1] }
        ), (
            "CYX",
            ProtonationState {
                missing_hydrogens: From::from([HG]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, -1] }
        )]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HG]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(SG, CB, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(SG, HG, BondOrder::Single), // Optional (without -> CYD/CYX)
        ],
    };

    #[rustfmt::skip]
    pub static ref MET: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::MET,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, SD, CE]),
        protonation_state_variants: From::from(
            [("MET", ProtonationState::default(8))]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HG2, HG3, HE1, HE2, HE3]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(SD, CG, BondOrder::Single),
            BondTemplate(CE, SD, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CG, HG2, BondOrder::Single),
            BondTemplate(CG, HG3, BondOrder::Single),
            BondTemplate(CE, HE1, BondOrder::Single),
            BondTemplate(CE, HE2, BondOrder::Single),
            BondTemplate(CE, HE3, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref PHE: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::PHE,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD1, CD2, CE1, CE2, CZ]),
        protonation_state_variants: From::from(
            [("PHE", ProtonationState::default(11))]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HD1, HD2, HE1, HE2, HZ]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD1, CG, BondOrder::Ring),
            BondTemplate(CD2, CG, BondOrder::Ring),
            BondTemplate(CE1, CD1, BondOrder::Ring),
            BondTemplate(CE2, CD2, BondOrder::Ring),
            BondTemplate(CZ, CE1, BondOrder::Ring),
            BondTemplate(CZ, CE2, BondOrder::Ring),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CD1, HD1, BondOrder::Single),
            BondTemplate(CD2, HD2, BondOrder::Single),
            BondTemplate(CE1, HE1, BondOrder::Single),
            BondTemplate(CE2, HE2, BondOrder::Single),
            BondTemplate(CZ, HZ, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref TYR: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::TYR,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD1, CD2, CE1, CE2, CZ, OH]),
        protonation_state_variants: From::from([(
            "TYR",
            ProtonationState {
                missing_hydrogens: From::from([]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }
        ), (
            "TYD",
            ProtonationState {
                missing_hydrogens: From::from([HH]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1] }
        )]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HD1, HD2, HE1, HE2, HH]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD1, CG, BondOrder::Ring),
            BondTemplate(CD2, CG, BondOrder::Ring),
            BondTemplate(CE1, CD1, BondOrder::Ring),
            BondTemplate(CE2, CD2, BondOrder::Ring),
            BondTemplate(CZ, CE1, BondOrder::Ring),
            BondTemplate(CZ, CE2, BondOrder::Ring),
            BondTemplate(OH, CZ, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CD1, HD1, BondOrder::Single),
            BondTemplate(CD2, HD2, BondOrder::Single),
            BondTemplate(CE1, HE1, BondOrder::Single),
            BondTemplate(CE2, HE2, BondOrder::Single),
            BondTemplate(OH, HH, BondOrder::Single), // Optional (without -> TYD)
        ],
    };

    #[rustfmt::skip]
    pub static ref TRP: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::TRP,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD1, CD2, NE1, CE2, CE3, CZ2, CZ3, CH2]),
        protonation_state_variants: From::from(
            [("TRP", ProtonationState::default(14))]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HD1, HE1, HE3, HZ2, HZ3, HH2]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD1, CG, BondOrder::Ring),
            BondTemplate(CD2, CG, BondOrder::Ring),
            BondTemplate(NE1, CD1, BondOrder::Ring),
            BondTemplate(CE2, CD2, BondOrder::Ring),
            BondTemplate(CE2, NE1, BondOrder::Ring),
            BondTemplate(CE3, CD2, BondOrder::Ring),
            BondTemplate(CZ2, CE2, BondOrder::Ring),
            BondTemplate(CZ3, CE3, BondOrder::Ring),
            BondTemplate(CH2, CZ2, BondOrder::Ring),
            BondTemplate(CH2, CZ3, BondOrder::Ring),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CD1, HD1, BondOrder::Single),
            BondTemplate(NE1, HE1, BondOrder::Single),
            BondTemplate(CD2, HD2, BondOrder::Single),
            BondTemplate(CE3, HE3, BondOrder::Single),
            BondTemplate(CZ2, HZ2, BondOrder::Single),
            BondTemplate(CZ3, HZ3, BondOrder::Single),
            BondTemplate(CH2, HH2, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref ASP: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::ASP,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, OD1, OD2]),
        protonation_state_variants: From::from([(
            "ASP",
            ProtonationState {
                missing_hydrogens: From::from([HD2]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, -1] }
        ), (
            "ASH",
            ProtonationState {
                missing_hydrogens: From::from([]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0] }
        )]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HD2]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(OD1, CG, BondOrder::OneAndAHalf),
            BondTemplate(OD2, CG, BondOrder::OneAndAHalf),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(OD2, HD2, BondOrder::Single), // Optional (ASH)
        ],
    };

    #[rustfmt::skip]
    pub static ref GLU: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::GLU,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD, OE1, OE2]),
        protonation_state_variants: From::from([(
            "GLU",
            ProtonationState {
                missing_hydrogens: From::from([HE2]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, -1] }
        ), (
            "GLH",
            ProtonationState {
                missing_hydrogens: From::from([]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 0] }
        )]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HG2, HG3, HE2]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD, CG, BondOrder::Single),
            BondTemplate(OE1, CD, BondOrder::OneAndAHalf),
            BondTemplate(OE2, CD, BondOrder::OneAndAHalf),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CG, HG2, BondOrder::Single),
            BondTemplate(CG, HG3, BondOrder::Single),
            BondTemplate(OE2, HE2, BondOrder::Single), // Optional (GLH)
        ],
    };

    #[rustfmt::skip]
    pub static ref HIS: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::HIS,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, ND1, CD2, CE1, NE2]),
        // TODO: for HIN and HIP, figure out charge placement on ND1 vs NE2
        protonation_state_variants: From::from([(
            "HIS",
            ProtonationState {
                missing_hydrogens: From::from([HD1]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }
        ), (
            "HIN",
            ProtonationState {
                missing_hydrogens: From::from([HD1, HE2]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, -1, 0, 0, 0] }
        ), (
            "HID",
            ProtonationState {
                missing_hydrogens: From::from([HE2]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }
        ), (
            "HIE",
            ProtonationState {
                missing_hydrogens: From::from([HD1]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }
        ), (
            "HIP",
            ProtonationState {
                missing_hydrogens: From::from([]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 1, 0, 0, 0] }
        )]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HD1, HD2, HE1, HE2]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(ND1, CG, BondOrder::Ring),
            BondTemplate(CD2, CG, BondOrder::Ring),
            BondTemplate(CE1, ND1, BondOrder::Ring),
            BondTemplate(NE2, CD2, BondOrder::Ring),
            BondTemplate(NE2, CE1, BondOrder::Ring),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            // HIN: HD2, HE1
            // HID: HD2, HE1, HD1
            // HIE: HD2, HE1, HE2 (also called HIS)
            // HIP: HD2, HE1, HD1, HE2
            BondTemplate(ND1, HD1, BondOrder::Single),
            BondTemplate(CD2, HD2, BondOrder::Single),
            BondTemplate(CE1, HE1, BondOrder::Single),
            BondTemplate(NE2, HE2, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref LYS: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::LYS,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD, CE, NZ]),
        protonation_state_variants: From::from([(
            "LYS",
            ProtonationState {
                missing_hydrogens: From::from([]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 1] }
        ), (
            "LYD",
            ProtonationState {
                missing_hydrogens: From::from([HZ3]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 0] }
        ), (
            "LYN",
            ProtonationState {
                missing_hydrogens: From::from([HZ3]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 0] }
        )]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HG2, HG3, HD2, HD3, HE2, HE3, HZ1, HZ2, HZ3]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD, CG, BondOrder::Single),
            BondTemplate(CE, CD, BondOrder::Single),
            BondTemplate(NZ, CE, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CG, HG2, BondOrder::Single),
            BondTemplate(CG, HG3, BondOrder::Single),
            BondTemplate(CD, HD2, BondOrder::Single),
            BondTemplate(CD, HD3, BondOrder::Single),
            BondTemplate(CE, HE2, BondOrder::Single),
            BondTemplate(CE, HE3, BondOrder::Single),
            BondTemplate(NZ, HZ1, BondOrder::Single),
            BondTemplate(NZ, HZ2, BondOrder::Single),
            BondTemplate(NZ, HZ3, BondOrder::Single), // Optional (without -> LYD/LYN)
        ],
    };

    #[rustfmt::skip]
    pub static ref ARG: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::ARG,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD, NE, CZ, NH1, NH2]),
        protonation_state_variants: From::from([(
            "ARG",
            ProtonationState {
                missing_hydrogens: From::from([]),
                heavy_atom_charges: vec![0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1] }
        )]),
        hydrogen_labels: From::from([
            H, HA, HB2, HB3, HG2, HG3, HD2, HD3, HE, HH11, HH12, HH21, HH22]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD, CG, BondOrder::Single),
            BondTemplate(NE, CD, BondOrder::Single),
            BondTemplate(CZ, NE, BondOrder::Single),
            BondTemplate(NH1, CZ, BondOrder::OneAndAHalf),
            BondTemplate(NH2, CZ, BondOrder::OneAndAHalf),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CG, HG2, BondOrder::Single),
            BondTemplate(CG, HG3, BondOrder::Single),
            BondTemplate(CD, HD2, BondOrder::Single),
            BondTemplate(CD, HD3, BondOrder::Single),
            BondTemplate(NE, HE, BondOrder::Single),
            BondTemplate(NH1, HH11, BondOrder::Single),
            BondTemplate(NH1, HH12, BondOrder::Single),
            BondTemplate(NH2, HH21, BondOrder::Single),
            BondTemplate(NH2, HH22, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref HYP: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::HYP,
        heavy_atom_labels: From::from([
            N, CA, C, O, CB, CG, CD, OD]),
        protonation_state_variants: From::from(
            [("HYP", ProtonationState::default(8))]),
        hydrogen_labels: From::from([
            HA, HB2, HB3, HG, HD2, HD3, HD]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CA, C, BondOrder::Single),
            BondTemplate(CB, CA, BondOrder::Single),
            BondTemplate(CG, CB, BondOrder::Single),
            BondTemplate(CD, CG, BondOrder::Single),
            BondTemplate(CD, N, BondOrder::Single),
            BondTemplate(OD, CG, BondOrder::Single),
            BondTemplate(CA, HA, BondOrder::Single),
            BondTemplate(CB, HB2, BondOrder::Single),
            BondTemplate(CB, HB3, BondOrder::Single),
            BondTemplate(CG, HG, BondOrder::Single),
            BondTemplate(CD, HD2, BondOrder::Single),
            BondTemplate(CD, HD3, BondOrder::Single),
            BondTemplate(OD, HD, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref ACE: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::ACE,
        heavy_atom_labels: From::from([
            CH3, C, O]),
        protonation_state_variants: From::from(
            [("ACE", ProtonationState::default(3))]),
        hydrogen_labels: From::from([
            H1, H2, H3]),
        bonds: vec![
            BondTemplate(C, CH3, BondOrder::Single),
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(CH3, H1, BondOrder::Single),
            BondTemplate(CH3, H2, BondOrder::Single),
            BondTemplate(CH3, H3, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref BNC: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::BNC,
        heavy_atom_labels: From::from([
            C, O]),
        protonation_state_variants: From::from(
            [("BNC", ProtonationState::default(2))]),
        hydrogen_labels: From::from([
            HA]),
        bonds: vec![
            BondTemplate(C, O, BondOrder::Double),
            BondTemplate(C, HA, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref NME: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::NME,
        heavy_atom_labels: From::from([
            N, C]),
        protonation_state_variants: From::from(
            [("NME", ProtonationState::default(2))]),
        hydrogen_labels: From::from([
            H, H1, H2, H3]),
        bonds: vec![
            BondTemplate(N, C, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(C, H1, BondOrder::Single),
            BondTemplate(C, H2, BondOrder::Single),
            BondTemplate(C, H3, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref NMA: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::NMA,
        heavy_atom_labels: From::from([
            N, CA]),
        protonation_state_variants: From::from(
            [("NMA", ProtonationState::default(2))]),
        hydrogen_labels: From::from([
            H, _1HA, _2HA, _3HA]),
        bonds: vec![
            BondTemplate(N, CA, BondOrder::Single),
            BondTemplate(N, H, BondOrder::Single),
            BondTemplate(CA, _1HA, BondOrder::Single),
            BondTemplate(CA, _2HA, BondOrder::Single),
            BondTemplate(CA, _3HA, BondOrder::Single),
        ],
    };

    #[rustfmt::skip]
    pub static ref NHH: AminoAcidTemplate = AminoAcidTemplate {
        tok: AminoAcidSeq::NHH,
        heavy_atom_labels: From::from([
            N]),
        protonation_state_variants: From::from(
            [("NHH", ProtonationState::default(2))]),
        hydrogen_labels: From::from([
            H1, H2]),
        bonds: vec![
            BondTemplate(N, H1, BondOrder::Single),
            BondTemplate(N, H2, BondOrder::Single),
        ],
    };
}

pub fn aa_template_by_tok(aa_tok: AminoAcidSeq) -> Option<&'static AminoAcidTemplate> {
    match aa_tok {
        AminoAcidSeq::GLY => Some(&GLY),
        AminoAcidSeq::ALA => Some(&ALA),
        AminoAcidSeq::VAL => Some(&VAL),
        AminoAcidSeq::LEU => Some(&LEU),
        AminoAcidSeq::ILE => Some(&ILE),
        AminoAcidSeq::PRO => Some(&PRO),
        AminoAcidSeq::SER => Some(&SER),
        AminoAcidSeq::THR => Some(&THR),
        AminoAcidSeq::ASN => Some(&ASN),
        AminoAcidSeq::GLN => Some(&GLN),
        AminoAcidSeq::CYS => Some(&CYS),
        AminoAcidSeq::CYD => Some(&CYS),
        AminoAcidSeq::CYX => Some(&CYS),
        AminoAcidSeq::MET => Some(&MET),
        AminoAcidSeq::PHE => Some(&PHE),
        AminoAcidSeq::TYR => Some(&TYR),
        AminoAcidSeq::TYD => Some(&TYR),
        AminoAcidSeq::TRP => Some(&TRP),
        AminoAcidSeq::ASP => Some(&ASP),
        AminoAcidSeq::ASH => Some(&ASP),
        AminoAcidSeq::GLU => Some(&GLU),
        AminoAcidSeq::GLH => Some(&GLU),
        AminoAcidSeq::HIS => Some(&HIS),
        AminoAcidSeq::HIN => Some(&HIS),
        AminoAcidSeq::HID => Some(&HIS),
        AminoAcidSeq::HIE => Some(&HIS),
        AminoAcidSeq::HIP => Some(&HIS),
        AminoAcidSeq::LYS => Some(&LYS),
        AminoAcidSeq::LYD => Some(&LYS),
        AminoAcidSeq::LYN => Some(&LYS),
        AminoAcidSeq::ARG => Some(&ARG),
        AminoAcidSeq::HYP => Some(&HYP),
        AminoAcidSeq::ACE => Some(&ACE),
        AminoAcidSeq::BNC => Some(&BNC),
        AminoAcidSeq::NME => Some(&NME),
        AminoAcidSeq::NMA => Some(&NMA),
        AminoAcidSeq::NHH => Some(&NHH),
        AminoAcidSeq::UNK => None,
    }
}

#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash, TypeInfo)]
pub enum AminoAcidAtom {
    // Standard labels for heavy atoms
    N,
    CA,
    C,
    O,
    CB,
    CG,
    CG1,
    CG2,
    CD,
    CD1,
    CD2,
    CE,
    CE1,
    CE2,
    CE3,
    CZ,
    CZ2,
    CZ3,
    CH2,
    OG,
    OG1,
    OD,
    OD1,
    OD2,
    OE1,
    OE2,
    OH,
    ND1,
    ND2,
    NE,
    NE1,
    NE2,
    NZ,
    NH1,
    NH2,
    SG,
    SD,

    // Standard labels for hydrogens
    H,
    HA,
    HA2,
    HA3,
    HB,
    HB1,
    HB2,
    HB3,
    HG,
    HG1,
    HG2,
    HG3,
    HG11,
    HG12,
    HG13,
    HG21,
    HG22,
    HG23,
    HD,
    HD1,
    HD2,
    HD3,
    HD11,
    HD12,
    HD13,
    HD21,
    HD22,
    HD23,
    HE,
    HE1,
    HE2,
    HE3,
    HE21,
    HE22,
    HZ,
    HZ1,
    HZ2,
    HZ3,
    HH,
    HH2,
    HH11,
    HH12,
    HH21,
    HH22,

    // For terminal residues only
    OXT,
    HXT,

    // For caps only
    CH3,
    H1,
    H2,
    H3,
    _1HA,
    _2HA,
    _3HA,
    HH31,
    HH32,
    HH33,
    _1H,
    _2H,
    _3H,

    // Alternate names
    OC1, // Alternate of O (seen from GROMACS output for LEU)
    OC2, // Alternate of OXT (seen from GROMACS output for LEU)
    HA1, // Alternate of HA3 (seen from GROMACS output for GLY)
}

impl FromStr for AminoAcidAtom {
    type Err = Error;

    fn from_str(string: &str) -> Result<Self, Self::Err> {
        match string {
            // Standard labels for heavy atoms
            "N" => Ok(Self::N),
            "CA" => Ok(Self::CA),
            "C" => Ok(Self::C),
            "O" => Ok(Self::O),
            "CB" => Ok(Self::CB),
            "CG" => Ok(Self::CG),
            "CG1" => Ok(Self::CG1),
            "CG2" => Ok(Self::CG2),
            "CD" => Ok(Self::CD),
            "CD1" => Ok(Self::CD1),
            "CD2" => Ok(Self::CD2),
            "CE" => Ok(Self::CE),
            "CE1" => Ok(Self::CE1),
            "CE2" => Ok(Self::CE2),
            "CE3" => Ok(Self::CE3),
            "CZ" => Ok(Self::CZ),
            "CZ2" => Ok(Self::CZ2),
            "CZ3" => Ok(Self::CZ3),
            "CH2" => Ok(Self::CH2),
            "OG" => Ok(Self::OG),
            "OG1" => Ok(Self::OG1),
            "OD" => Ok(Self::OD),
            "OD1" => Ok(Self::OD1),
            "OD2" => Ok(Self::OD2),
            "OE1" => Ok(Self::OE1),
            "OE2" => Ok(Self::OE2),
            "OH" => Ok(Self::OH),
            "ND1" => Ok(Self::ND1),
            "ND2" => Ok(Self::ND2),
            "NE" => Ok(Self::NE),
            "NE1" => Ok(Self::NE1),
            "NE2" => Ok(Self::NE2),
            "NZ" => Ok(Self::NZ),
            "NH1" => Ok(Self::NH1),
            "NH2" => Ok(Self::NH2),
            "SG" => Ok(Self::SG),
            "SD" => Ok(Self::SD),

            // Standard labels for hydrogens
            "H" => Ok(Self::H),
            "HA" => Ok(Self::HA),
            "HA2" => Ok(Self::HA2),
            "HA3" => Ok(Self::HA3),
            "HB" => Ok(Self::HB),
            "HB1" => Ok(Self::HB1),
            "HB2" => Ok(Self::HB2),
            "HB3" => Ok(Self::HB3),
            "HG" => Ok(Self::HG),
            "HG1" => Ok(Self::HG1),
            "HG2" => Ok(Self::HG2),
            "HG3" => Ok(Self::HG3),
            "HG11" => Ok(Self::HG11),
            "HG12" => Ok(Self::HG12),
            "HG13" => Ok(Self::HG13),
            "HG21" => Ok(Self::HG21),
            "HG22" => Ok(Self::HG22),
            "HG23" => Ok(Self::HG23),
            "HD" => Ok(Self::HD),
            "HD1" => Ok(Self::HD1),
            "HD2" => Ok(Self::HD2),
            "HD3" => Ok(Self::HD3),
            "HD11" => Ok(Self::HD11),
            "HD12" => Ok(Self::HD12),
            "HD13" => Ok(Self::HD13),
            "HD21" => Ok(Self::HD21),
            "HD22" => Ok(Self::HD22),
            "HD23" => Ok(Self::HD23),
            "HE" => Ok(Self::HE),
            "HE1" => Ok(Self::HE1),
            "HE2" => Ok(Self::HE2),
            "HE3" => Ok(Self::HE3),
            "HE21" => Ok(Self::HE21),
            "HE22" => Ok(Self::HE22),
            "HZ" => Ok(Self::HZ),
            "HZ1" => Ok(Self::HZ1),
            "HZ2" => Ok(Self::HZ2),
            "HZ3" => Ok(Self::HZ3),
            "HH" => Ok(Self::HH),
            "HH2" => Ok(Self::HH2),
            "HH11" => Ok(Self::HH11),
            "HH12" => Ok(Self::HH12),
            "HH21" => Ok(Self::HH21),
            "HH22" => Ok(Self::HH22),

            // For terminal residues only
            "OXT" => Ok(Self::OXT),
            "HXT" => Ok(Self::HXT),

            // For caps only
            "CH3" => Ok(Self::CH3),
            "H1" => Ok(Self::H1),
            "H2" => Ok(Self::H2),
            "H3" => Ok(Self::H3),
            "1HA" => Ok(Self::_1HA),
            "2HA" => Ok(Self::_2HA),
            "3HA" => Ok(Self::_3HA),
            "HH31" => Ok(Self::HH31),
            "HH32" => Ok(Self::HH32),
            "HH33" => Ok(Self::HH33),
            "1H" => Ok(Self::_1H),
            "2H" => Ok(Self::_2H),
            "3H" => Ok(Self::_3H),

            // Alternate names
            "OC1" => Ok(Self::OC1), // Alternate of O (seen from GROMACS output for LEU)
            "OC2" => Ok(Self::OC2), // Alternate of OXT (seen from GROMACS output for LEU)
            "HA1" => Ok(Self::HA1), // Alternate of HA3 (seen from GROMACS output for GLY)

            _ => Err(Error::UnsupportedAminoAcidAtom {
                amino_acid_atom: string.to_string(),
            }),
        }
    }
}

impl AminoAcidAtom {
    pub fn to_str(&self) -> &'static str {
        match self {
            // Standard labels for heavy atoms
            Self::N => "N",
            Self::CA => "CA",
            Self::C => "C",
            Self::O => "O",
            Self::CB => "CB",
            Self::CG => "CG",
            Self::CG1 => "CG1",
            Self::CG2 => "CG2",
            Self::CD => "CD",
            Self::CD1 => "CD1",
            Self::CD2 => "CD2",
            Self::CE => "CE",
            Self::CE1 => "CE1",
            Self::CE2 => "CE2",
            Self::CE3 => "CE3",
            Self::CZ => "CZ",
            Self::CZ2 => "CZ2",
            Self::CZ3 => "CZ3",
            Self::CH2 => "CH2",
            Self::OG => "OG",
            Self::OG1 => "OG1",
            Self::OD => "OD",
            Self::OD1 => "OD1",
            Self::OD2 => "OD2",
            Self::OE1 => "OE1",
            Self::OE2 => "OE2",
            Self::OH => "OH",
            Self::ND1 => "ND1",
            Self::ND2 => "ND2",
            Self::NE => "NE",
            Self::NE1 => "NE1",
            Self::NE2 => "NE2",
            Self::NZ => "NZ",
            Self::NH1 => "NH1",
            Self::NH2 => "NH2",
            Self::SG => "SG",
            Self::SD => "SD",

            // Standard labels for hydrogens
            Self::H => "H",
            Self::HA => "HA",
            Self::HA2 => "HA2",
            Self::HA3 => "HA3",
            Self::HB => "HB",
            Self::HB1 => "HB1",
            Self::HB2 => "HB2",
            Self::HB3 => "HB3",
            Self::HG => "HG",
            Self::HG1 => "HG1",
            Self::HG2 => "HG2",
            Self::HG3 => "HG3",
            Self::HG11 => "HG11",
            Self::HG12 => "HG12",
            Self::HG13 => "HG13",
            Self::HG21 => "HG21",
            Self::HG22 => "HG22",
            Self::HG23 => "HG23",
            Self::HD => "HD",
            Self::HD1 => "HD1",
            Self::HD2 => "HD2",
            Self::HD3 => "HD3",
            Self::HD11 => "HD11",
            Self::HD12 => "HD12",
            Self::HD13 => "HD13",
            Self::HD21 => "HD21",
            Self::HD22 => "HD22",
            Self::HD23 => "HD23",
            Self::HE => "HE",
            Self::HE1 => "HE1",
            Self::HE2 => "HE2",
            Self::HE3 => "HE3",
            Self::HE21 => "HE21",
            Self::HE22 => "HE22",
            Self::HZ => "HZ",
            Self::HZ1 => "HZ1",
            Self::HZ2 => "HZ2",
            Self::HZ3 => "HZ3",
            Self::HH => "HH",
            Self::HH2 => "HH2",
            Self::HH11 => "HH11",
            Self::HH12 => "HH12",
            Self::HH21 => "HH21",
            Self::HH22 => "HH22",

            // For terminal residues only
            Self::OXT => "OXT",
            Self::HXT => "HXT",

            // For caps only
            Self::CH3 => "CH3",
            Self::H1 => "H1",
            Self::H2 => "H2",
            Self::H3 => "H3",
            Self::_1HA => "1HA",
            Self::_2HA => "2HA",
            Self::_3HA => "3HA",
            Self::HH31 => "HH31",
            Self::HH32 => "HH32",
            Self::HH33 => "HH33",
            Self::_1H => "1H",
            Self::_2H => "2H",
            Self::_3H => "3H",

            // Alternate names
            Self::OC1 => "OC1", // Alternate of O (seen from GROMACS output for LEU)
            Self::OC2 => "OC2", // Alternate of OXT (seen from GROMACS output for LEU)
            Self::HA1 => "HA1", // Alternate of HA3 (seen from GROMACS output for GLY)
        }
    }

    pub fn get_equivalence_class(&self, residue: AminoAcidSeq) -> AminoAcidAtom {
        use AminoAcidAtom::*;

        match residue {
            // Cases ordered from most to least wonky and with caps at the end
            AminoAcidSeq::ILE => match self {
                CD => CD1,
                HG11 => HG13,
                HD1 => HD11,
                HD2 => HD12,
                HD3 => HD13,
                OC1 => O,
                OC2 => OXT,
                H1 => H,
                _ => *self,
            },
            AminoAcidSeq::LYS | AminoAcidSeq::LYD | AminoAcidSeq::LYN => match self {
                HB1 => HB3,
                HG1 => HG3,
                HD1 => HD3,
                HE1 => HE3,
                OC1 => O,
                OC2 => OXT,
                H1 => H,
                _ => *self,
            },
            AminoAcidSeq::PRO | AminoAcidSeq::ARG => match self {
                HB1 => HB3,
                HG1 => HG3,
                HD1 => HD3,
                OC1 => O,
                OC2 => OXT,
                H1 => H,
                _ => *self,
            },
            AminoAcidSeq::GLN
            | AminoAcidSeq::CYS
            | AminoAcidSeq::CYD
            | AminoAcidSeq::CYX
            | AminoAcidSeq::MET
            | AminoAcidSeq::GLU
            | AminoAcidSeq::GLH => match self {
                HB1 => HB3,
                HG1 => HG3,
                OC1 => O,
                OC2 => OXT,
                H1 => H,
                _ => *self,
            },
            AminoAcidSeq::HYP => match self {
                HB1 => HB3,
                HD1 => HD3,
                OC1 => O,
                OC2 => OXT,
                H1 => H,
                _ => *self,
            },
            AminoAcidSeq::GLY => match self {
                HA1 => HA3,
                OC1 => O,
                OC2 => OXT,
                H1 => H,
                _ => *self,
            },
            AminoAcidSeq::LEU
            | AminoAcidSeq::SER
            | AminoAcidSeq::ASN
            | AminoAcidSeq::PHE
            | AminoAcidSeq::TYR
            | AminoAcidSeq::TYD
            | AminoAcidSeq::TRP
            | AminoAcidSeq::ASP
            | AminoAcidSeq::ASH
            | AminoAcidSeq::HIS
            | AminoAcidSeq::HIN
            | AminoAcidSeq::HID
            | AminoAcidSeq::HIE
            | AminoAcidSeq::HIP => match self {
                HB1 => HB3,
                OC1 => O,
                OC2 => OXT,
                H1 => H,
                _ => *self,
            },
            AminoAcidSeq::ALA | AminoAcidSeq::THR | AminoAcidSeq::VAL => match self {
                OC1 => O,
                OC2 => OXT,
                H1 => H,
                _ => *self,
            },
            AminoAcidSeq::ACE => match self {
                _1H => H1,
                _2H => H2,
                _3H => H3,
                HH31 => H1,
                HH32 => H2,
                HH33 => H3,
                _ => *self,
            },
            AminoAcidSeq::NME => match self {
                CH3 => C,
                HH31 => H1,
                HH32 => H2,
                HH33 => H3,
                _ => *self,
            },
            _ => *self, // Each standard variant is its own class
        }
    }
}

impl Display for AminoAcidAtom {
    fn fmt(&self, f: &mut Formatter) -> fmt::Result {
        self.to_str().fmt(f)
    }
}

#[cfg(test)]
mod test {
    use super::*;

    fn dedup<T: Eq>(mut v: Vec<T>) -> Vec<T> {
        let mut cursor = 0;
        loop {
            if cursor >= v.len() {
                break;
            }

            let mut i = cursor + 1;
            loop {
                if i >= v.len() {
                    break;
                }

                if v[cursor] == v[i] {
                    v.remove(i);
                } else {
                    i += 1;
                }
            }

            cursor += 1;
        }

        v
    }

    #[test]
    fn test_no_duplicate_bonds() {
        assert_eq!(dedup(GLY.bonds.clone()).len(), GLY.bonds.len());
        assert_eq!(dedup(ALA.bonds.clone()).len(), ALA.bonds.len());
        assert_eq!(dedup(VAL.bonds.clone()).len(), VAL.bonds.len());
        assert_eq!(dedup(LEU.bonds.clone()).len(), LEU.bonds.len());
        assert_eq!(dedup(ILE.bonds.clone()).len(), ILE.bonds.len());
        assert_eq!(dedup(PRO.bonds.clone()).len(), PRO.bonds.len());
        assert_eq!(dedup(SER.bonds.clone()).len(), SER.bonds.len());
        assert_eq!(dedup(THR.bonds.clone()).len(), THR.bonds.len());
        assert_eq!(dedup(ASN.bonds.clone()).len(), ASN.bonds.len());
        assert_eq!(dedup(GLN.bonds.clone()).len(), GLN.bonds.len());
        assert_eq!(dedup(CYS.bonds.clone()).len(), CYS.bonds.len());
        assert_eq!(dedup(MET.bonds.clone()).len(), MET.bonds.len());
        assert_eq!(dedup(PHE.bonds.clone()).len(), PHE.bonds.len());
        assert_eq!(dedup(TYR.bonds.clone()).len(), TYR.bonds.len());
        assert_eq!(dedup(TRP.bonds.clone()).len(), TRP.bonds.len());
        assert_eq!(dedup(ASP.bonds.clone()).len(), ASP.bonds.len());
        assert_eq!(dedup(GLU.bonds.clone()).len(), GLU.bonds.len());
        assert_eq!(dedup(HIS.bonds.clone()).len(), HIS.bonds.len());
        assert_eq!(dedup(LYS.bonds.clone()).len(), LYS.bonds.len());
        assert_eq!(dedup(ARG.bonds.clone()).len(), ARG.bonds.len());
        assert_eq!(dedup(HYP.bonds.clone()).len(), HYP.bonds.len());
        assert_eq!(dedup(ACE.bonds.clone()).len(), ACE.bonds.len());
        assert_eq!(dedup(BNC.bonds.clone()).len(), BNC.bonds.len());
        assert_eq!(dedup(NME.bonds.clone()).len(), NME.bonds.len());
        assert_eq!(dedup(NMA.bonds.clone()).len(), NMA.bonds.len());
        assert_eq!(dedup(NHH.bonds.clone()).len(), NHH.bonds.len());
    }
}
