use ouroboros::TypeInfo;
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct ExternalCharges {
    pub positions: Vec<f64>,
    pub charges: Vec<f64>,
}
