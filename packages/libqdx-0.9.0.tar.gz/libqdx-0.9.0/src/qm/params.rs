use ouroboros::TypeInfo;
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use crate::{Method, Residues, Topology, version::SchemaVersion};

use super::external_charges::ExternalCharges;
use super::keywords::Keywords;

/// Params attempts to follow the QC-JSON "standard" for configuring quantum chemistry calculations.
///
/// # Example
/// ```json
/// {
///   "topology": {
///     "symbols": ["O", "H", "H"]
///     "geometry": [
///       -4.3997, 1.0764, 7.7009,
///       -3.9597, 0.2664, 7.3109,
///       -4.4297, 0.9964, 8.7009
///     ],
///     "fragments": [[0, 1, 2]],
///     "fragment_formal_charges": [0],
///   },
///   "driver": "Energy",
///   "model": {
///     "method": "RHF",
///     "basis": "STO-3G",
///     "aux_basis": "6-31G"
///     "frag_emabled": true
///   },
///   "keywords": {
///     "frag": {
///       "cutoffs": {
///         "monomer": 60.0,
///         "dimer": 30.0,
///         "trimer": 15.0,
///         "tetramer": 10.0
///       },
///     }
///     "debug": {},
///     "export": {},
///     "guess": {},
///     "scf": {
///       "niter":100,
///       "ndiis":8,
///       "scf_conv": 0.000001,
///       "dynamic_screening_threshold_exp": 10,
///       "convergence_metric": "Energy"
///     }
///   }
/// }
///
/// ```
#[derive(Clone, Debug, Default, TypeInfo)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Params {
    /// TODO(sean): Make this optional? Allowed to be omitted upstream
    pub schema_version: SchemaVersion,

    /// The topology batch of the system to calculate.
    pub topologies: Vec<Topology>,

    pub residues: Option<Vec<Residues>>,

    pub external_charges: Option<ExternalCharges>,

    /// The model (method, basis sets, etc.) to use for the calculation.
    pub model: Model,

    /// The hardware (node, GPU, etc.) configuration.
    pub system: Option<System>,

    /// The configuration keywords.
    /// TODO(sean): Make this optional? Default value of Keywords struct is valid
    pub keywords: Keywords,

    /// The driver to use.
    pub driver: Driver,
}

#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum Driver {
    #[default]
    #[cfg_attr(
        feature = "serde",
        serde(alias = "ENERGY", alias = "Energy", alias = "energy")
    )]
    Energy = 1,
    #[cfg_attr(
        feature = "serde",
        serde(alias = "GRADIENT", alias = "Gradient", alias = "gradient")
    )]
    Gradient = 2,
    #[cfg_attr(
        feature = "serde",
        serde(alias = "DYNAMICS", alias = "Dynamics", alias = "dynamics")
    )]
    Dynamics = 3,
    #[cfg_attr(
        feature = "serde",
        serde(
            alias = "OPTIMIZATION",
            alias = "Optimization",
            alias = "optimization",
            alias = "OPTIMISATION",
            alias = "Optimisation",
            alias = "optimisation"
        )
    )]
    Optimization = 4,
    #[cfg_attr(
        feature = "serde",
        serde(alias = "HESSIAN", alias = "Hessian", alias = "hessian")
    )]
    Hessian = 5,
    #[cfg_attr(
        feature = "serde",
        serde(alias = "QMMM", alias = "Qmmm", alias = "qmmm")
    )]
    QMMM = 6,
}

#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::Enum),
    graphql(name = "StandardOrientation")
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum StandardOrientation {
    #[cfg_attr(
        feature = "serde",
        serde(alias = "NONE", alias = "None", alias = "none")
    )]
    None = 0,
    #[default]
    #[cfg_attr(
        feature = "serde",
        serde(alias = "FULLSYSTEM", alias = "FullSystem", alias = "fullsystem")
    )]
    FullSystem = 1,
    #[cfg_attr(
        feature = "serde",
        serde(alias = "PERFRAGMENT", alias = "PerFragment", alias = "perfragment")
    )]
    PerFragment = 2,
}

/// Model configures the quantum energy calculation method and basis set.
#[derive(Clone, Debug, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(
        input_name = "QuantumModelInput",
        name = "QuantumModel",
        rename_fields = "snake_case"
    )
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Model {
    /// Method to use. This argument is required upstream, but libqdx sets the default to Method::RestrictedHF
    #[cfg_attr(feature = "serde", serde(default = "model_default_method"))]
    pub method: Method,

    /// Basis set to use. This argument is required upstream, but libqdx sets the default to "cc-pVDZ"
    #[cfg_attr(feature = "serde", serde(default = "model_default_basis"))]
    pub basis: String,

    /// Auxiliary Basis set to use. This argument is required upstream, but libqdx sets the default to "cc-pVDZ-RIFIT"
    pub aux_basis: Option<String>,

    /// "None", "FullSystem" or "PerFragment". Be extremely vigilant if using "PerFragment" - this can have some weird side effects (e.g. total energies and energy differences will be incorrect). Default: FullSystem
    pub standard_orientation: Option<StandardOrientation>,

    /// If set to true all basis functions will be represented in cartesian form. If false will use spherical coordinates if specified in the basis set definition. Default: true
    pub force_cartesian_basis_sets: Option<bool>,
}

fn model_default_method() -> Method {
    Method::RestrictedHF
}

fn model_default_basis() -> String {
    "cc-pVDZ".into()
}

impl Default for Model {
    fn default() -> Self {
        Self {
            method: model_default_method(),
            basis: model_default_basis(),
            aux_basis: Default::default(),
            standard_orientation: Default::default(),
            force_cartesian_basis_sets: Default::default(),
        }
    }
}

/// Configure system resources
#[derive(Clone, Debug, Default, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(
        input_name = "QuantumSystemInput",
        name = "QuantumSystem",
        rename_fields = "snake_case"
    )
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct System {
    /// Maximum GPU memory to allocate per process per GPU in MB (can be used to speed up extremely small calculations or tune extremely large ones). Default: 75% of available GPU memory will be used (dynamically set)
    pub max_gpu_memory_mb: Option<u64>,

    /// Allow multiple processes to use each GPU. Default: false
    pub oversubscribe_gpus: Option<bool>,

    /// Number of worker teams per node. Default: 1
    pub teams_per_node: Option<u32>,

    /// Number of GPUs per team. Also overridable by MBE_NGPUS environment variable. Default: None (dynamically set)
    pub gpus_per_team: Option<u32>,
}
