use ouroboros::TypeInfo;
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use crate::{QMMBE, Trajectory, version::SchemaVersion};

#[derive(Debug, Default, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "QuantumOutputInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Output {
    pub schema_version: SchemaVersion,
    /// The time it took to run the calculation.
    pub calculation_time: f64,
    /// The QM/MMBE energy.
    pub qmmbe: Option<QMMBE>,
    /// The trajectory of the QM/MMBE energy.
    pub trajectory: Option<Trajectory>,
    /// The trajectory of the QM/MMBE energy for each fragment.
    /// The `i`th index corresponds to the `i`th frame of a `Dynamics` calculation. Not present in non-`Dynamics` calculations
    pub trajectory_qmmbes: Option<Vec<QMMBE>>,
}
