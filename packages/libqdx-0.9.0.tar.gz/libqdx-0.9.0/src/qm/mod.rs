pub mod external_charges;
pub mod keywords;
pub mod output;
pub mod params;

#[cfg(test)]
mod tests {
    use tests::{keywords::SCFKeywords, params::Model};

    use super::*;
    #[test]
    fn deserialize_default_model() {
        let model: Model = serde_json::from_str("{}").unwrap();
        println!("{model:?}");
        assert_eq!(model.basis, Model::default().basis);
        assert_eq!(model.method, Model::default().method);
        assert_eq!(model.aux_basis, Model::default().aux_basis);
        assert_eq!(
            model.force_cartesian_basis_sets,
            Model::default().force_cartesian_basis_sets
        );
        assert_eq!(
            model.standard_orientation,
            Model::default().standard_orientation
        );
    }

    #[test]
    fn deserialize_default_scf() {
        let scf: SCFKeywords = serde_json::from_str("{}").unwrap();
        println!("{scf:?}");
        assert_eq!(
            scf.convergence_metric,
            SCFKeywords::default().convergence_metric
        );
        assert_eq!(
            scf.convergence_threshold,
            SCFKeywords::default().convergence_threshold
        );
        assert_eq!(
            scf.max_diis_history_length,
            SCFKeywords::default().max_diis_history_length
        );
        assert_eq!(scf.max_iters, SCFKeywords::default().max_iters);
        assert_eq!(
            scf.density_threshold,
            SCFKeywords::default().density_threshold
        );
    }
}
