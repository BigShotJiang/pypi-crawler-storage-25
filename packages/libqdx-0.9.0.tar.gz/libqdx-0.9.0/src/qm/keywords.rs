use ouroboros::TypeInfo;
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use crate::{
    AtomRef, FragmentCutoffs, FragmentDistanceMethod, FragmentDistanceMetric, FragmentLevel,
    FragmentRef, HDF5, TypedVirtualObject,
};

/// Keywords configure different aspects of the quantum calculation.
#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Keywords {
    pub scf: Option<SCFKeywords>,

    pub rtat: Option<RTATKeywords>,

    /// Fragmentation configuration. It is important for specifying cutoffs and
    /// fragment selection.
    pub frag: Option<FragKeywords>,

    pub boundary: Option<BoundaryKeywords>,

    pub debug: Option<DebugKeywords>,

    /// Configures which matrices we want to export
    pub export: Option<ExportKeywords>,

    /// Configures initial guess for SCF
    pub guess: Option<GuessKeywords>,

    pub log: Option<LoggingKeywords>,

    /// Configures Driver::RestrictedKSDFT runs
    pub ks_dft: Option<KSDFTKeywords>,

    pub dynamics: Option<DynamicsKeywords>,

    pub integrals: Option<IntegralKeywords>,

    /// Configures force field file used when doing MM
    pub force_field: Option<ForceFieldKeywords>,

    /// Configures Driver::Optimization runs
    pub optimization: Option<OptimizationKeywords>,

    /// Among (probably) other things, configures gradient used during Driver::QMMM runs
    pub gradient: Option<GradientKeywords>,

    pub hessian: Option<HessianKeywords>,

    /// Configures ML behavior
    pub machine_learning: Option<MLKeywords>,

    /// Configures Driver::QMMM runs
    pub qmmm: Option<QMMMKeywords>,

    /// Configures which fragments are treated as QM, MM, or ML in Q4ML runs
    pub regions: Option<RegionKeywords>,
}

#[derive(Clone, Copy, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo, Debug)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum FockBuildType {
    #[default]
    HGP = 1,
    UM09 = 2,
    RI = 3,
}

/// SCF configures the self-consistent field procedure.
#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct SCFKeywords {
    /// Max number of SCF iterations to perform. Default is 50.
    #[cfg_attr(feature = "serde", serde(default = "scf_default_max_iters"))]
    pub max_iters: Option<u32>,

    /// Max number of Fock matrices to consider in the DIIS space. Default is 8.
    #[cfg_attr(feature = "serde", serde(default = "scf_default_diis_history_length"))]
    pub max_diis_history_length: Option<u32>,

    /// Controls the number of shell pairs to put in a batch, increase in multiples of 128. Smaller should produce lower performance, for older GPUs this might be needed. Default is 2560.
    #[cfg_attr(feature = "serde", serde(default = "scf_default_batch_size"))]
    pub batch_size: Option<u32>,

    /// Use energy or DIIS error differences as the convergence metric, DIIS can be unstable. Energy is recommended
    #[cfg_attr(feature = "serde", serde(default = "scf_default_convergence_metric"))]
    pub convergence_metric: Option<ConvergenceMetric>,

    /// SCF convergence threshold. Default is 1e-6.
    #[cfg_attr(
        feature = "serde",
        serde(default = "scf_default_convergence_threshold")
    )]
    pub convergence_threshold: Option<f64>,

    /// Density screening threshold (expert variable) safe space to move it around 1E-08 to 1E-12. A lower density threshold will make things faster but depending on the system it might cause accuracy issues. A large one can produce NaNs
    #[cfg_attr(feature = "serde", serde(default = "scf_default_density_threshold"))]
    pub density_threshold: Option<f64>,

    #[cfg_attr(
        feature = "serde",
        serde(default = "scf_default_gradient_screening_threshold")
    )]
    pub gradient_screening_threshold: Option<f64>,

    /// Expert variable: Threshold at which basis function contribution is considered negligible for DFT and shell pair formation (defaults to density threshold).
    #[cfg_attr(feature = "serde", serde(default = "scf_default_bf_cutoff_threshold"))]
    pub bf_cutoff_threshold: Option<f64>,

    /// Use basis set projection in STO-3G for density guess if SCF convergence fails default is true
    pub density_basis_set_projection_fallback_enabled: Option<bool>,

    /// Whether to use the resolution to the identity approximation (currently experimental) default is false
    #[cfg_attr(feature = "serde", serde(default = "scf_default_use_ri"))]
    pub use_ri: Option<bool>,

    #[cfg_attr(feature = "serde", serde(default = "scf_default_store_ri_b_on_host"))]
    pub store_ri_b_on_host: Option<bool>,

    #[cfg_attr(feature = "serde", serde(default = "scf_default_compress_ri_b"))]
    pub compress_ri_b: Option<bool>,

    /// Expert variable for rotating the HOMO and LUMO guesses after the first iteration, particularly relevant for unrestricted calculations to break spatial symmetry (units are degrees, valid range is [0, 180]). Will default to 45 degrees if an unrestricted calculation with multiplicity 1, otherwise will default to 0.
    #[cfg_attr(
        feature = "serde",
        serde(default = "scf_default_homo_lumo_guess_rotation_angle")
    )]
    pub homo_lumo_guess_rotation_angle: Option<f64>,

    /// Fock build with improved screening for improved performance on large systems (>3000 basis functions). See https://arxiv.org/abs/2407.21445 for more info.
    #[cfg_attr(feature = "serde", serde(default = "scf_default_fock_build_type"))]
    pub fock_build_type: Option<FockBuildType>,

    #[cfg_attr(
        feature = "serde",
        serde(default = "scf_default_exchange_screening_threshold")
    )]
    pub exchange_screening_threshold: Option<f64>,

    /// Expert variable for grouping shared primitive basis function exponents. Only used with the UM09 integral evaluation scheme and for basis sets with shared exponents in multiple basis functions with the same angular momentum (e.g. cc-pVDZ).
    #[cfg_attr(
        feature = "serde",
        serde(default = "scf_default_group_shared_exponents")
    )]
    pub group_shared_exponents: Option<bool>,
}

#[derive(Clone, Copy, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo, Debug)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum RadialQuad {
    #[default]
    MuraKnowles = 1,
    MurrayHandyLaming = 2,
    TreutlerAldrichs = 3,
}

#[derive(Clone, Copy, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo, Debug)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[serde(rename_all(serialize = "UPPERCASE"))]
pub enum PruningScheme {
    Unpruned = 1,
    #[default]
    Robust = 2,
    Treutler = 3,
}

#[derive(Clone, Copy, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo, Debug)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum XCGridDefaults {
    #[cfg_attr(feature = "serde", serde(rename(serialize = "FINE")))]
    Fine = 1,
    #[default]
    #[cfg_attr(feature = "serde", serde(rename(serialize = "ULTRAFINE")))]
    UltraFine = 2,
    #[cfg_attr(feature = "serde", serde(rename(serialize = "SUPERFINE")))]
    SuperFine = 3,
    #[cfg_attr(feature = "serde", serde(rename(serialize = "TREUTLER_GM3")))]
    TreutlerGM3 = 4,
    #[cfg_attr(feature = "serde", serde(rename(serialize = "TREUTLER_GM5")))]
    TreutlerGM5 = 5,
}

#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum XCGridResolution {
    Default(XCGridDefaults),
    Custom { radial_size: u32, angular_size: u32 },
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Octree {
    pub max_size: Option<u32>,
    pub max_depth: Option<u32>,
    pub max_distance: Option<f64>,
    pub combine_small_children: Option<bool>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct SpaceFilling {
    pub octree: Option<Octree>,
    pub target_batch_size: Option<u32>,
}

#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum XCBatchingScheme {
    ClosestAtom,
    Octree {
        max_size: Option<u32>,
        max_depth: Option<u32>,
        max_distance: Option<f64>,
        combine_small_children: Option<bool>,
    },
    SpaceFilling {
        octree: Option<Octree>,
        target_batch_size: Option<u32>,
    },
    GauXC {
        batch_size: u32,
    },
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(feature = "serde", serde(into = "XCGridWire"))]
pub struct XCGrid {
    pub radial_quad: Option<RadialQuad>,
    pub pruning_scheme: Option<PruningScheme>,
    pub consider_weight_zero: Option<f64>,
    pub resolution: Option<XCGridResolution>,
    pub batching: Option<XCBatchingScheme>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
struct XCGridWire {
    pub radial_quad: Option<RadialQuad>,
    pub pruning_scheme: Option<PruningScheme>,
    pub consider_weight_zero: Option<f64>,
    pub default_grid: Option<XCGridDefaults>,
    pub radial_size: Option<u32>,
    pub angular_size: Option<u32>,
    pub octree: Option<Octree>,
    pub space_filling: Option<SpaceFilling>,
    pub batch_size: Option<u32>,
}

impl From<XCGrid> for XCGridWire {
    fn from(grid: XCGrid) -> Self {
        let (default_grid, radial_size, angular_size) = match grid.resolution {
            Some(XCGridResolution::Default(default_grid)) => (Some(default_grid), None, None),
            Some(XCGridResolution::Custom {
                radial_size,
                angular_size,
            }) => (None, Some(radial_size), Some(angular_size)),
            None => (None, None, None),
        };

        let (octree, space_filling, batch_size) = match grid.batching {
            Some(XCBatchingScheme::ClosestAtom) | None => (None, None, None),
            Some(XCBatchingScheme::Octree {
                max_size,
                max_depth,
                max_distance,
                combine_small_children,
            }) => (
                Some(Octree {
                    max_size,
                    max_depth,
                    max_distance,
                    combine_small_children,
                }),
                None,
                None,
            ),
            Some(XCBatchingScheme::SpaceFilling {
                octree,
                target_batch_size,
            }) => (
                None,
                Some(SpaceFilling {
                    octree,
                    target_batch_size,
                }),
                None,
            ),
            Some(XCBatchingScheme::GauXC { batch_size }) => (None, None, Some(batch_size)),
        };

        Self {
            radial_quad: grid.radial_quad,
            pruning_scheme: grid.pruning_scheme,
            consider_weight_zero: grid.consider_weight_zero,
            default_grid,
            radial_size,
            angular_size,
            octree,
            space_filling,
            batch_size,
        }
    }
}

#[derive(Clone, Copy, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo, Debug)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum XCMethod {
    #[default]
    GauXC = 1,
    Dense = 2,
    BatchDense = 3,
    Direct = 4,
    SemiDirect = 5,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct KSDFTKeywords {
    pub functional: String,
    pub grid: Option<XCGrid>,
    pub method: Option<XCMethod>,
    #[cfg_attr(
        feature = "serde",
        serde(alias = "use_C_opt", rename(serialize = "use_C_opt"))
    )]
    pub use_c_opt: Option<bool>,
    pub sp_threshold: Option<f64>,
    pub dp_threshold: Option<f64>,
    // NOTE: really a size_t, but u32 is enough
    pub batches_per_batch: Option<u32>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct RTATKeywords {
    /// Whether runtime autotuning of matrix multiplication is enabled
    pub enabled: Option<bool>,
    pub synchronous: Option<bool>,
    /// Prefix of file to dump rtat json to
    pub json_file_dump_prefix: Option<String>,
}

#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct TrustRegionKeywords {
    pub initial_radius: Option<f64>,
    pub max_radius: Option<f64>,
    pub min_radius: Option<f64>,
    pub increase_factor: Option<f64>,
    pub decrease_factor: Option<f64>,
    pub constrict_factor: Option<f64>,
    pub increase_threshold: Option<f64>,
    pub decrease_threshold: Option<f64>,
    pub rejection_threshold: Option<f64>,
}

#[derive(Clone, Copy, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo, Debug)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum IntegralScheduler {
    #[default]
    Callback = 1,
    RoundRobin = 3,
}

#[derive(Clone, Copy, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo, Debug)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum OptimizationConvergenceMetric {
    /// Maximum gradient component needs to be within threshold
    /// and either the energy change or the step component must be
    /// within their respective thresholds.
    #[default]
    Baker = 1,
    /// Maximum gradient component needs to be within threshold
    /// the delta energy and step component thresholds are ignored
    GradientOnly = 2,
}

#[derive(Clone, Copy, Default, Debug, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum CoordinateSystem {
    Cartesian = 1,
    NaturalInternal = 2,
    #[default]
    DelocalisedInternal = 3,
}

#[derive(Clone, Copy, Default, Debug, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum OptimizationAlgorithmType {
    #[default]
    EigenvectorFollowing = 1,
    TrustRegionAugmentedHessian = 2,
    LBFGS = 3,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum HessianGuessType {
    Identity = 1,
    ScaledIdentity = 2,
    Schlegel = 3,
    Lindh = 4,
}

#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct OptimizationConvergenceCriteria {
    pub metric: Option<OptimizationConvergenceMetric>,
    /// Eh/a0
    pub gradient_threshold: Option<f64>,
    /// Eh
    pub delta_energy_threshold: Option<f64>,
    /// a0
    pub step_component_threshold: Option<f64>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum LBFGSLinesearch {
    MoreThuente = 0,
    BacktrackingArmijo = 1,
    BacktrackingWolfe = 2,
    BacktrackingStrongWolfe = 3,
}

#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct LBFGSKeywords {
    pub linesearch: Option<LBFGSLinesearch>,
    pub n_corrections: Option<i32>,
    pub epsilon: Option<f64>,
    pub max_linesearch: Option<i32>,
    pub gtol: Option<f64>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct OptimizationKeywords {
    pub max_iters: u64,
    pub convergence_criteria: Option<OptimizationConvergenceCriteria>,
    /// Number of iterations before the optimizer is reset
    pub optimizer_reset_interval: Option<u64>,
    pub coordinate_system: Option<CoordinateSystem>,
    /// List of constraints to apply for geometry optimization. Each constraint is specified
    /// as a list of atom indices. Supports constrained bond lengths, angles and dihedrals.
    pub constraints: Option<Vec<Vec<AtomRef>>>,
    pub hessian_guess: Option<HessianGuessType>,
    pub algorithm: Option<OptimizationAlgorithmType>,
    pub lbfgs_keywords: Option<LBFGSKeywords>,
    /// Slippage tolerances are required particularly in the case of frozen delocalised coordinates as
    /// some degree of slippage is expected. User can specify allowed amount of slippage for internal
    /// bonds and angles
    pub frozen_distance_slippage_tolerance_angstroms: Option<f64>,
    pub frozen_angle_slippage_tolerance_degrees: Option<f64>,
    pub trust_region_keywords: Option<TrustRegionKeywords>,

    // NOTE: There are debug_xyz and output_trc fields here too, but not useful for running through
    // tengu as they do irrelevant output configuration
    pub fixed_atoms: Option<Vec<AtomRef>>,
    pub free_atoms: Option<Vec<AtomRef>>,
    pub fixed_fragments: Option<Vec<FragmentRef>>,
    pub free_fragments: Option<Vec<FragmentRef>>,
    pub fix_heavy: Option<bool>,
}

#[derive(Clone, Copy, Default, Debug, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum DerivativesMethod {
    #[default]
    Analytical = 1,
    Numerical = 2,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct GradientKeywords {
    pub finite_difference_step_size: Option<f64>,
    pub method: Option<DerivativesMethod>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct HessianKeywords {
    pub finite_difference_step_size: Option<f64>,
    pub method: Option<DerivativesMethod>,
}

/// Type of ML calculation performed.
#[derive(Clone, Copy, Default, Debug, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum MLType {
    #[default]
    AIMNet = 1,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct MLKeywords {
    pub ml_type: Option<MLType>,
}

#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct ForceFieldKeywords {
    pub ff_filename: String,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct LoggingKeywords {
    pub console: Option<LogSettings>,
    pub logfiles: Option<Vec<FileLogSettings>>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct LogSettings {
    #[cfg_attr(feature = "serde", serde(default = "default_logsettings_log_level"))]
    pub level: Option<LogLevel>,
    #[cfg_attr(feature = "serde", serde(default = "default_logsettings_log_fmt"))]
    pub prefix_fmt: Option<String>,
}

fn default_logsettings_log_level() -> Option<LogLevel> {
    Some(LogLevel::LargeInfo)
}

fn default_logsettings_log_fmt() -> Option<String> {
    Some("".into())
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct FileLogSettings {
    pub directory: Option<String>,
    #[cfg_attr(feature = "serde", serde(default = "default_log_level"))]
    pub level: Option<LogLevel>,
    #[cfg_attr(feature = "serde", serde(default = "default_prefix_fmt"))]
    pub prefix_fmt: Option<String>,
}

fn default_log_level() -> Option<LogLevel> {
    Some(LogLevel::Verbose)
}

fn default_prefix_fmt() -> Option<String> {
    Some("[%Y-%m-%d %H:%M:%S.{us} r{rank} {level}] ".into())
}

#[derive(Clone, Copy, Default, Debug, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum LogLevel {
    Debug = 1,
    Verbose = 2,
    Info = 3,
    #[default]
    LargeInfo = 4,
    Warning = 5,
    Performance = 6,
    Error = 7,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct DynamicsKeywords {
    pub n_timesteps: u64,
    pub dt: f64,
    pub reuse_orbitals: Option<bool>,
    pub use_async_timesteps: Option<bool>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct IntegralKeywords {
    pub scheduler: Option<IntegralScheduler>,
    pub n_streams: Option<u32>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct BoundaryKeywords {
    pub x: Option<BoundaryCondition>,
    pub y: Option<BoundaryCondition>,
    pub z: Option<BoundaryCondition>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct BoundaryCondition {
    pub kind: BoundaryConditionKind,
    pub range: Range,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Range {
    pub lower: f64,
    pub upper: f64,
}

#[derive(Clone, Debug, Default, Eq, PartialEq, Copy, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum BoundaryConditionKind {
    #[default]
    Periodic = 1,
    Rigid = 2,
    Delete = 3,
}

/// Debug print levels and other debug options.
#[derive(Clone, Debug, TypeInfo, Default)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct DebugKeywords {
    /// Enable check runs, won't do any computation but will go through all the fragments and return how many will be evaluated.
    /// Can be use to spot errors in the input file preparation
    pub dry_run: Option<bool>,
    /// Print subfragment geometries as debug (for superposition_subfragment_densities)
    pub print_subfragment_xyz: Option<bool>,
    /// Number of fragments to compute, can be used for systems without covalent bond breaking to calculate a subset of fragments
    pub max_fragments: Option<i32>,
    /// Ignore fragmentation. This is mostly used by developers to validate that fragmented calculations match full system calculations.
    pub ignore_fragments: Option<bool>,

    pub skip_calcs: Option<bool>,
}

#[derive(Debug, Clone, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum DescriptorGridOptions {
    #[cfg_attr(feature = "serde", serde(rename = "standard"))]
    StandardGrid(StandardGrid),
    #[cfg_attr(feature = "serde", serde(rename = "params"))]
    GridParams(Grid),
    #[cfg_attr(feature = "serde", serde(rename = "custom"))]
    CustomGrid(Vec<f64>),
    #[cfg_attr(feature = "serde", serde(rename = "regular"))]
    RegularGrid(RegularGrid),
}

/// Export configures the export of various data from the quantum energy calculation.
#[derive(Clone, Debug, TypeInfo, Default)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct ExportKeywords {
    pub export_density: Option<bool>,
    pub export_relaxed_mp2_density_correction: Option<bool>,
    pub export_fock: Option<bool>,
    pub export_overlap: Option<bool>,
    pub export_h_core: Option<bool>,
    pub export_expanded_density: Option<bool>,
    pub export_expanded_gradient: Option<bool>,
    pub export_molecular_orbital_coeffs: Option<bool>,
    pub export_gradient: Option<bool>,
    pub export_external_charge_gradient: Option<bool>,
    pub export_mulliken_charges: Option<bool>,
    pub export_chelpg_charges: Option<bool>,
    pub export_bond_orders: Option<bool>,
    pub export_h_caps: Option<bool>,
    pub export_density_descriptors: Option<bool>,
    pub export_esp_descriptors: Option<bool>,
    pub export_expanded_esp_descriptors: Option<bool>,
    pub export_basis_labels: Option<bool>,
    pub export_hessian: Option<bool>,
    pub export_mass_weighted_hessian: Option<bool>,
    pub export_hessian_frequencies: Option<bool>,
    /// When exporting square symmetric matrices save memory by exporting the flattened lower triangle of the matrix. Default should be true.
    pub flatten_symmetric: Option<bool>,
    pub light_json: Option<bool>,
    /// Post-process exports into a single hdf5 output file. This is relevant for fragmented runs
    /// (particularly when configured for multinode). The concatenation of the hdf5 files may be
    /// expensive.
    pub concatenate_hdf5_files: Option<bool>,
    pub training_db: Option<bool>,
    /// Grid to use for exporting density descriptors
    pub descriptor_grid: Option<DescriptorGridOptions>,
}

#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct ClassicalMinimisation {
    pub err_tol_kj_per_mol_nm: Option<f64>,
    pub max_iterations: Option<u64>,
}

fn classical_minimisation_default_err_tol_kj_per_mol_nm() -> Option<f64> {
    Some(10.0)
}

fn classical_minimisation_default_max_iterations() -> Option<u64> {
    Some(0)
}

impl Default for ClassicalMinimisation {
    fn default() -> Self {
        Self {
            err_tol_kj_per_mol_nm: classical_minimisation_default_err_tol_kj_per_mol_nm(),
            max_iterations: classical_minimisation_default_max_iterations(),
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum TrajectoryFormat {
    #[cfg_attr(feature = "serde", serde(alias = "XYZ", alias = "xyz"))]
    XYZ = 1,
    #[default]
    #[cfg_attr(feature = "serde", serde(alias = "JSON", alias = "json"))]
    JSON = 2,
}

#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct MDTrajectory {
    pub format: Option<TrajectoryFormat>,
    pub interval: Option<u64>,
    pub start: Option<u64>,
    pub end: Option<u64>,
    pub include_waters: Option<bool>,
}

fn md_trajectory_default_format() -> Option<TrajectoryFormat> {
    Some(TrajectoryFormat::JSON)
}

fn md_trajectory_default_interval() -> Option<u64> {
    Some(1)
}

fn md_trajectory_default_start() -> Option<u64> {
    Some(0)
}

fn md_trajectory_default_end() -> Option<u64> {
    Some(u64::from(u32::MAX)) // TODO: fix this upstream (and then here)
}

fn md_trajectory_default_include_waters() -> Option<bool> {
    Some(false)
}

impl Default for MDTrajectory {
    fn default() -> Self {
        Self {
            format: md_trajectory_default_format(),
            interval: md_trajectory_default_interval(),
            start: md_trajectory_default_start(),
            end: md_trajectory_default_end(),
            include_waters: md_trajectory_default_include_waters(),
        }
    }
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Restraints {
    pub k: Option<f64>,
    pub fixed_atoms: Option<Vec<AtomRef>>,
    pub free_atoms: Option<Vec<AtomRef>>,
    pub fixed_fragments: Option<Vec<FragmentRef>>,
    pub free_fragments: Option<Vec<FragmentRef>>,
    pub fix_heavy: Option<bool>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct QMMMKeywords {
    pub n_timesteps: u64,
    pub dt_ps: f64,
    pub temperature_kelvin: f64,
    pub pressure_atm: Option<f64>,

    pub minimisation: Option<ClassicalMinimisation>,
    pub trajectory: Option<MDTrajectory>,
    pub energy_csv: Option<String>,
    pub restraints: Option<Restraints>,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct RegionKeywords {
    pub qm_fragments: Option<Vec<FragmentRef>>,
    pub mm_fragments: Option<Vec<FragmentRef>>,
    pub ml_fragments: Option<Vec<FragmentRef>>,
}

/// Grid configures the grid to use for exporting density descriptors.
#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Grid {
    /// Number of points per shell
    pub points_per_shell: u32,
    /// Grid order
    pub order: GridOrder,
    /// Grid scale
    pub scale: f64,
}

/// Grid configures the grid to use for exporting density descriptors.
#[derive(Clone, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct RegularGrid {
    pub min: Vec<f64>,
    pub max: Vec<f64>,
    pub spacing: Vec<f64>,
}

/// GridOrder configures the grid order.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum GridOrder {
    #[default]
    One = 1,
    Two = 2,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, PartialOrd, Ord, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum StandardGrid {
    #[default]
    #[cfg_attr(feature = "serde", serde(rename = "FINE"))]
    Fine = 1,
    #[cfg_attr(feature = "serde", serde(rename = "ULTRAFINE"))]
    UltraFine = 2,
    #[cfg_attr(feature = "serde", serde(rename = "SUPERFINE"))]
    SuperFine = 3,
    #[cfg_attr(feature = "serde", serde(rename = "TREUTLER_GM3"))]
    TreutlerGM3 = 4,
    #[cfg_attr(feature = "serde", serde(rename = "TREUTLER_GM5"))]
    TreutlerGM5 = 5,
}

/// Guess configures the initial guess for the SCF procedure.
#[derive(Clone, Debug, TypeInfo, Default)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct GuessKeywords {
    /// Path to hdf5 file containing initial density guess. If present will be used as the initial
    /// density guess. Guesses are expected to be in flattened lower triangular form. For a RHF
    /// calculation there must be a "density" dataset at root. For a UHF calculation there must be
    /// "alpha" and "beta" groups at root, each group containing a "density" dataset. There is
    /// currently no support for providing an initial guess for a fragmented calculation. This is an
    /// expert feature, take care as density matrices from other packages may have different basis
    /// function ordering and normalisation terms which may result in poor EXESS initial guesses.
    pub external_initial_density_path: Option<TypedVirtualObject<HDF5>>,
    /// Enable basis set projection to bootstrap SCF calculation by first computing in a lower resolution basis set and projecting into higher basis set. Default should be false.
    pub bsp: Option<bool>,
    /// The desired lower resolution basis set for bsp.
    pub bsp_basis: Option<String>,
    /// The base SCF keywords specified in keywords/scf SCF keywords used for the bootstrapping calculation (works with bsp).
    pub bsp_scf_keywords: Option<SCFKeywords>,
    /// Use hcore initial guess
    pub hcore: Option<bool>,
    /// Superposition of monomer density optimization where nmer density guesses will be formed from the converged densities of their constituent monomers. Default should be true.
    pub smd: Option<bool>,
    /// Initial monomer guess based on converged densities of auto-generated subfragments (experimental feature). Default should be false.
    pub ssfd: Option<bool>,
    /// Target number of atoms in subfragments produced under auto-fragmentation (works with ssfd). Default should be 30.
    pub ssfd_target_size: Option<u32>,
    /// When SSFD and basis set projection are applied on top of each other, should the subfragement densities be left unconverged in the primary basis and only projected from the bootstrap basis. Default should be true.
    pub ssfd_only_converge_in_bsp_basis: Option<bool>,
    /// The base SCF keywords specified in keywords/scf SCF keywords used for each subfragment calculation (works with ssfd).
    pub ssfd_scf_keywords: Option<GuessSCF>,
}

/// ConvergenceMetric configures the convergence metric for the SCF procedure.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum ConvergenceMetric {
    Energy = 1,
    #[default]
    DIIS = 2,
    Density = 3,
}

/// GuessSCF configures the initial guess for the SCF procedure.
#[derive(Clone, Debug, TypeInfo, Default)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct GuessSCF {
    pub max_iters: Option<u32>,
    pub max_diis_history_length: Option<u32>,
    pub batch_size: Option<u32>,
    pub convergence_metric: Option<ConvergenceMetric>,
    pub convergence_threshold: Option<f64>,
    pub density_threshold: Option<f64>,
    pub gradient_screening_threshold: Option<f64>,
    pub bt_cutoff_threshold: Option<f64>,
    pub density_basis_set_projection_fallback_enabled: Option<bool>,
    pub use_ri: Option<bool>,
    pub store_ri_b_on_host: Option<bool>,
    pub compress_ri_b: Option<bool>,
    pub homo_lumo_guess_rotation_angle: Option<f64>,
    pub fock_build_type: Option<FockBuildType>,
    pub exchange_screening_threshold: Option<f64>,
}

fn scf_default_max_iters() -> Option<u32> {
    Some(50)
}

fn scf_default_diis_history_length() -> Option<u32> {
    Some(8)
}

fn scf_default_batch_size() -> Option<u32> {
    Some(2560)
}

fn scf_default_convergence_threshold() -> Option<f64> {
    Some(1e-6)
}

fn scf_default_convergence_metric() -> Option<ConvergenceMetric> {
    Some(ConvergenceMetric::DIIS)
}

fn scf_default_basis_set_projection_fallback_enabled() -> Option<bool> {
    Some(true)
}

fn scf_default_use_ri() -> Option<bool> {
    Some(false)
}

fn scf_default_density_threshold() -> Option<f64> {
    Some(1e-10)
}

fn scf_default_gradient_screening_threshold() -> Option<f64> {
    Some(1e-10)
}

fn scf_default_exchange_screening_threshold() -> Option<f64> {
    Some(1e-5)
}

fn scf_default_bf_cutoff_threshold() -> Option<f64> {
    None
}

fn scf_default_homo_lumo_guess_rotation_angle() -> Option<f64> {
    None
}

fn scf_default_store_ri_b_on_host() -> Option<bool> {
    Some(false)
}

fn scf_default_compress_ri_b() -> Option<bool> {
    Some(false)
}

fn scf_default_group_shared_exponents() -> Option<bool> {
    Some(false)
}

fn scf_default_fock_build_type() -> Option<FockBuildType> {
    Some(FockBuildType::HGP)
}

impl Default for SCFKeywords {
    fn default() -> Self {
        Self {
            max_iters: scf_default_max_iters(),
            max_diis_history_length: scf_default_diis_history_length(),
            batch_size: scf_default_batch_size(),
            density_threshold: scf_default_density_threshold(),
            gradient_screening_threshold: scf_default_gradient_screening_threshold(),
            exchange_screening_threshold: scf_default_exchange_screening_threshold(),
            bf_cutoff_threshold: scf_default_bf_cutoff_threshold(),
            homo_lumo_guess_rotation_angle: scf_default_homo_lumo_guess_rotation_angle(),
            convergence_metric: scf_default_convergence_metric(),
            convergence_threshold: scf_default_convergence_threshold(),
            use_ri: scf_default_use_ri(),
            density_basis_set_projection_fallback_enabled:
                scf_default_basis_set_projection_fallback_enabled(),
            store_ri_b_on_host: scf_default_store_ri_b_on_host(),
            compress_ri_b: scf_default_compress_ri_b(),
            fock_build_type: scf_default_fock_build_type(),
            group_shared_exponents: scf_default_group_shared_exponents(),
        }
    }
}

#[derive(Clone, Default, Debug, TypeInfo)]
#[repr(C)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct FragKeywords {
    /// Fragmentation level to cutoff in Angstroms
    pub cutoffs: Option<FragmentCutoffs>,

    /// Controls how the distance between fragments is calculated.
    pub cutoff_type: Option<FragmentDistanceMethod>,

    /// Distance for higher order fragments is calculated based on max, min, or average distance between fragments. Defaults to max.
    pub distance_metric: Option<FragmentDistanceMetric>,

    /// Controls at which level the many body expansion is truncated.
    pub level: FragmentLevel,

    /// Reference fragment for lattice energy calculations, 0 indexed.
    #[cfg_attr(feature = "serde", serde(default))]
    pub reference_fragment: Option<FragmentRef>,

    /// Choose a set number of fragments from the list to evaluate as a small, independent system. E.g \[0,1,2,3,74\].
    /// Calculation will construct the queues as if only those fragments were present
    pub included_fragments: Option<Vec<FragmentRef>>,

    #[cfg_attr(feature = "serde", serde(default))]
    pub enable_speed: Option<bool>,
}
