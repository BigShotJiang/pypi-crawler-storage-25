use std::fmt::{self, Display, Formatter};
#[cfg(feature = "rex")]
use std::sync::Arc;

use ouroboros::{Alias, Type, TypeInfo, TypeName};
#[cfg(feature = "rex")]
use rex::{
    Decode, Encode, Error as EngineError, Expr, Rex, Span, ToType, Type as RexType, TypeCon,
};
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use crate::{AtomRef, Error};

#[cfg(feature = "graphql")]
async_graphql::scalar!(ResidueRef);

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct ResidueRef(pub u32);

impl TypeInfo for ResidueRef {
    fn t() -> Type {
        Type::from(Alias::new("ResidueRef", u32::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("ResidueRef")
    }
}

impl From<u32> for ResidueRef {
    fn from(value: u32) -> Self {
        Self(value)
    }
}

impl From<ResidueRef> for u32 {
    fn from(value: ResidueRef) -> Self {
        value.0
    }
}

impl From<usize> for ResidueRef {
    fn from(value: usize) -> Self {
        Self(value as u32)
    }
}

impl From<ResidueRef> for usize {
    fn from(value: ResidueRef) -> Self {
        value.0 as usize
    }
}

#[cfg(feature = "rex")]
impl ToType for ResidueRef {
    fn to_type() -> RexType {
        RexType::Con(TypeCon::Uint)
    }
}

#[cfg(feature = "rex")]
impl Encode for ResidueRef {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, EngineError> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for ResidueRef {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, EngineError> {
        Ok(ResidueRef(u32::try_decode(v)?))
    }
}

#[cfg(feature = "graphql")]
async_graphql::scalar!(Residue);

#[derive(Clone, Debug, Default, Eq, Hash, PartialEq)]
#[repr(C)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
/// A residue is a collection of atoms, representing a single amino acid, nucleotide, or any other kind of
/// small molecule.
pub struct Residue(pub Vec<AtomRef>);

#[cfg(feature = "rex")]
impl ToType for Residue {
    fn to_type() -> RexType {
        <Vec<AtomRef>>::to_type()
    }
}

#[cfg(feature = "rex")]
impl Encode for Residue {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, EngineError> {
        self.0.try_encode(span)
    }
}

#[cfg(feature = "rex")]
impl Decode for Residue {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, EngineError> {
        Ok(Residue(Vec::<AtomRef>::try_decode(v)?))
    }
}

impl TypeInfo for Residue {
    fn t() -> Type {
        <Vec<AtomRef>>::t()
    }

    fn tname() -> ouroboros::TypeName {
        <Vec<AtomRef>>::tname()
    }
}

impl From<Vec<AtomRef>> for Residue {
    fn from(value: Vec<AtomRef>) -> Self {
        Self(value)
    }
}

impl From<Vec<u32>> for Residue {
    fn from(value: Vec<u32>) -> Self {
        value.into_iter().map(AtomRef).collect::<Vec<_>>().into()
    }
}

impl From<Residue> for Vec<u32> {
    fn from(value: Residue) -> Self {
        value.0.into_iter().map(Into::into).collect()
    }
}

impl Residue {
    pub fn iter(&self) -> impl Iterator<Item = &AtomRef> {
        self.0.iter()
    }

    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut AtomRef> {
        self.0.iter_mut()
    }

    pub fn len(&self) -> usize {
        self.0.len()
    }

    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    pub fn contains(&self, atom: &AtomRef) -> bool {
        self.0.contains(atom)
    }
}

#[derive(Clone, Debug, Default, Eq, PartialEq, TypeInfo)]
#[cfg_attr(feature = "rex", derive(Rex))]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "ResiduesInput", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Residues {
    /// List of residues
    pub residues: Vec<Residue>,
    /// Sequence names, e.g. amino acid or nucleotide names
    pub seqs: Vec<String>,
    /// Sequence numbers, identifying the position of the residue in the sequence
    pub seq_ns: Vec<i32>,
    /// Insertion codes, specifying the order of residues inserted between existing residues
    pub insertion_codes: Vec<String>,

    /// Optional list of residue ids that have labels. Must be present if `labels` is present.
    ///
    /// WARN: Deprecated.
    pub labeled: Option<Vec<ResidueRef>>,

    /// Optional list of residue labels. Any given residue may have multiple labels. `labels[i]`
    /// corresponds to residue with id `labeled[i]`. Must be present if `labeled` is present.
    ///
    /// WARN: Deprecated.
    pub labels: Option<Vec<Vec<String>>>,
}

impl Residues {
    pub fn is_amino_acid(&self, i: usize) -> bool {
        if i >= self.seqs.len() {
            return false;
        }
        AminoAcidSeq::is_amino_acid(&self.seqs[i])
    }

    pub fn new_residues_from_subset(&self, residue_refs: &[ResidueRef]) -> Self {
        let mut new_residues = Residues::default();

        new_residues.residues.reserve(residue_refs.len());
        let mut offset = 0;
        for residue_index in residue_refs.iter() {
            let residue_len = self.residues[residue_index.0 as usize].len();
            new_residues.residues.push(Residue(
                (offset..offset + residue_len)
                    .map(|i| AtomRef(i as u32))
                    .collect(),
            ));
            offset += residue_len;
        }

        new_residues.seqs.reserve(residue_refs.len());
        for residue_index in residue_refs.iter() {
            new_residues
                .seqs
                .push(self.seqs[residue_index.0 as usize].clone());
        }

        // TODO(ross): Should this data be invalidated? I'm not sure it makes sense outside of the context of the original residues.
        new_residues.seq_ns.reserve(residue_refs.len());
        for residue_index in residue_refs.iter() {
            new_residues
                .seq_ns
                .push(self.seq_ns[residue_index.0 as usize]);
        }

        // TODO(ross): Should this data be invalidated? I'm not sure it makes sense outside of the context of the original residues.
        new_residues.insertion_codes.reserve(residue_refs.len());
        for residue_index in residue_refs.iter() {
            new_residues
                .insertion_codes
                .push(self.insertion_codes[residue_index.0 as usize].clone());
        }

        if let Some(ref labeled) = self.labeled {
            let labels = self.labels.as_ref().unwrap();

            let mut new_labeled = Vec::new();
            let mut new_labels = Vec::new();

            for (i, residue_index) in residue_refs.iter().enumerate() {
                if let Some(position) = labeled
                    .iter()
                    .position(|residue_ref| residue_ref == residue_index)
                {
                    new_labeled.push(ResidueRef(i as u32));
                    new_labels.push(labels[position].clone());
                }
            }

            if !new_labeled.is_empty() {
                new_residues.labeled = Some(new_labeled);
                new_residues.labels = Some(new_labels);
            }
        }

        new_residues
    }
}

#[derive(thiserror::Error, Copy, Clone, Eq, PartialEq, Debug)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum ResiduesError {
    #[error("labeled and labels have different lengths ({0} != {1})")]
    LabelMismatch(usize, usize),
    #[error("a nonexistent residue was labeled ({0} != {1})")]
    InvalidLabel(usize, usize),
    #[error("labels are missing")]
    LabelsMissing,
    #[error("labeled is missing")]
    LabeledMissing,
    #[error("seqs and residues have different lengths ({0} != {1})")]
    InvalidSeqsLength(usize, usize),
    #[error("seq_ns and residues have different lengths ({0} != {1})")]
    InvalidSeqNLength(usize, usize),
    #[error("insertion_codes and residues have different lengths ({0} != {1})")]
    InvalidInsertionCodesLength(usize, usize),
}

impl Residues {
    pub fn amino_acid_iter(&self) -> impl Iterator<Item = ResidueRef> + '_ {
        self.seqs
            .iter()
            .enumerate()
            .filter_map(|(i, seq)| AminoAcidSeq::is_amino_acid(seq).then_some(ResidueRef(i as u32)))
    }

    pub fn non_amino_acid_iter(&self) -> impl Iterator<Item = ResidueRef> + '_ {
        self.seqs.iter().enumerate().filter_map(|(i, seq)| {
            (!AminoAcidSeq::is_amino_acid(seq)).then_some(ResidueRef(i as u32))
        })
    }

    pub fn check(&self) -> Result<(), ResiduesError> {
        match (&self.labeled, &self.labels) {
            (Some(labeled), Some(labels)) => {
                if labeled.len() != labels.len() {
                    return Err(ResiduesError::LabelMismatch(labeled.len(), labels.len()));
                }
                for r in labeled.iter() {
                    if r.0 as usize >= self.residues.len() {
                        return Err(ResiduesError::InvalidLabel(
                            labeled.len(),
                            self.residues.len(),
                        ));
                    }
                }
            }
            (Some(_), None) => return Err(ResiduesError::LabelsMissing),
            (None, Some(_)) => return Err(ResiduesError::LabeledMissing),
            _ => {}
        }
        // seqs must match length of residues
        if self.seqs.len() != self.residues.len() {
            return Err(ResiduesError::InvalidSeqsLength(
                self.seqs.len(),
                self.residues.len(),
            ));
        }

        // seq_ns must match length of residues
        if self.seq_ns.len() != self.residues.len() {
            return Err(ResiduesError::InvalidSeqNLength(
                self.seq_ns.len(),
                self.residues.len(),
            ));
        }

        // insertion_codes must match length of residues
        if self.insertion_codes.len() != self.residues.len() {
            return Err(ResiduesError::InvalidInsertionCodesLength(
                self.insertion_codes.len(),
                self.residues.len(),
            ));
        }

        Ok(())
    }

    pub(crate) fn extend(&mut self, rhs: Self) -> Result<(), ResiduesError> {
        let residues = &mut self.residues;
        let seqs = &mut self.seqs;
        let seq_ns = &mut self.seq_ns;
        let insertion_codes = &mut self.insertion_codes;
        // offset is the sum of all residue lengths in self
        let offset: usize = residues.iter().map(|r| r.0.len()).sum();
        let label_offset = residues.len();

        // we can't just extend residues because their atoms have to be renumbered
        // residues.extend(rhs.residues);
        residues.extend(rhs.residues.into_iter().map(|mut r| {
            for atom in r.0.iter_mut() {
                atom.0 += offset as u32;
            }
            r
        }));
        seqs.extend(rhs.seqs);
        // FIXME: should we extend seq_ns?
        seq_ns.extend(rhs.seq_ns);
        insertion_codes.extend(rhs.insertion_codes);

        // if labeled is present for both, then we need to merge them. We always need to extend rhs by number of residues in lhs
        let mut rhs_labeled = rhs.labeled;
        rhs_labeled = rhs_labeled.map(|l| {
            l.into_iter()
                .map(|r| ResidueRef(r.0 + label_offset as u32))
                .collect()
        });

        match (&mut self.labeled, rhs_labeled) {
            (Some(labeled), Some(rhs_labeled)) => {
                if let Some(labels) = &mut self.labels {
                    let rhs_labels = rhs.labels.ok_or(ResiduesError::LabelsMissing)?;
                    for (i, rhs_r) in rhs_labeled.iter().enumerate() {
                        let rhs_labels = rhs_labels.get(i).unwrap();
                        if let Some(j) = labeled.iter().position(|&r| r == *rhs_r) {
                            labels[j].extend(rhs_labels.iter().cloned());
                        } else {
                            labeled.push(*rhs_r);
                            labels.push(rhs_labels.clone());
                        }
                    }
                }
            }
            (None, Some(labeled)) => {
                self.labeled = Some(labeled);
                self.labels = rhs.labels;
            }
            _ => {}
        };
        Ok(())
    }

    pub fn get_labels(&self, residue: ResidueRef) -> Option<&Vec<String>> {
        self.labeled
            .as_ref()?
            .iter()
            .position(|&r| r == residue)
            .and_then(|i| self.labels.as_ref()?.get(i))
    }
}

#[derive(Copy, Clone, Debug, Default, Eq, Hash, PartialEq, Ord, PartialOrd, TypeInfo)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(
    feature = "pyo3",
    pyo3::pyclass(eq, eq_int, hash, frozen, from_py_object)
)]
pub enum AminoAcidSeq {
    /// Glycine
    GLY,
    /// Alanine
    ALA,
    /// Valine
    VAL,
    /// Leucine
    LEU,
    /// Isoleucine
    ILE,
    /// Proline
    PRO,
    /// Serine
    SER,
    /// Threonine
    THR,
    /// Asparagine
    ASN,
    /// Glutamine
    GLN,
    /// Cysteine
    CYS,
    CYD,
    CYX,
    /// Methionine
    MET,
    /// Phenylalanine
    PHE,
    /// Tyrosine
    TYR,
    TYD,
    /// Tryptophan
    TRP,
    /// Aspartate
    ASP,
    ASH,
    /// Glutamate
    GLU,
    GLH,
    /// Histidine
    HIS,
    HIN,
    HID,
    HIE,
    HIP,
    /// Lysine
    LYS,
    LYD,
    LYN,
    /// Arginine
    ARG,
    /// Hydroxyproline
    HYP,
    /// Acetyl capping group
    ACE,
    /// Random small cap from SQM structures
    BNC,
    /// C-terminal N-methyl amide capping group
    NME,
    /// C-terminal N-methyl amide and acetyl capping group
    NMA,
    /// Exactly what it says on the tin
    NHH,
    /// Unknown
    #[default]
    UNK,
}

impl AminoAcidSeq {
    pub fn is_amino_acid(residue: &str) -> bool {
        matches!(
            residue,
            "GLY"
                | "gly"
                | "ALA"
                | "ala"
                | "VAL"
                | "val"
                | "LEU"
                | "leu"
                | "ILE"
                | "ile"
                | "PRO"
                | "pro"
                | "SER"
                | "ser"
                | "THR"
                | "thr"
                | "ASN"
                | "asn"
                | "GLN"
                | "gln"
                | "CYS"
                | "cys"
                | "CYD"
                | "cyd"
                | "CYX"
                | "cyx"
                | "MET"
                | "met"
                | "PHE"
                | "phe"
                | "TYR"
                | "tyr"
                | "TYD"
                | "tyd"
                | "TRP"
                | "trp"
                | "ASP"
                | "asp"
                | "ASH"
                | "ash"
                | "GLU"
                | "glu"
                | "GLH"
                | "glh"
                | "HIS"
                | "his"
                | "HIN"
                | "hin"
                | "HID"
                | "hid"
                | "HIE"
                | "hie"
                | "HIP"
                | "hip"
                | "LYS"
                | "lys"
                | "LYD"
                | "lyd"
                | "LYN"
                | "lyn"
                | "ARG"
                | "arg"
                | "HYP"
                | "hyp"
                | "ACE"
                | "ace"
                | "BNC"
                | "bnc"
                | "NME"
                | "nme"
                | "NMA"
                | "nma"
                | "NHH"
                | "nhh"
                | "UNK"
                | "unk"
        )
    }

    /// Convert from the 3-char PDB standard names to the respective amino acid.
    /// If the standard name is not recognised, then the amino acid reverts to
    /// UNK. See
    /// <http://www.rcsb.org/pdb/file_formats/pdb/pdbguide2.2/part_79.html> for
    /// more information about the PDB standard names.
    pub fn from_pdb_std_name(residue: &str) -> Result<Self, Error> {
        match residue {
            "GLY" | "gly" => Ok(Self::GLY),
            "ALA" | "ala" => Ok(Self::ALA),
            "VAL" | "val" => Ok(Self::VAL),
            "LEU" | "leu" => Ok(Self::LEU),
            "ILE" | "ile" => Ok(Self::ILE),
            "PRO" | "pro" => Ok(Self::PRO),
            "SER" | "ser" => Ok(Self::SER),
            "THR" | "thr" => Ok(Self::THR),
            "ASN" | "asn" => Ok(Self::ASN),
            "GLN" | "gln" => Ok(Self::GLN),
            "CYS" | "cys" => Ok(Self::CYS),
            "CYD" | "cyd" => Ok(Self::CYD),
            "CYX" | "cyx" => Ok(Self::CYX),
            "MET" | "met" => Ok(Self::MET),
            "PHE" | "phe" => Ok(Self::PHE),
            "TYR" | "tyr" => Ok(Self::TYR),
            "TYD" | "tyd" => Ok(Self::TYD),
            "TRP" | "trp" => Ok(Self::TRP),
            "ASP" | "asp" => Ok(Self::ASP),
            "ASH" | "ash" => Ok(Self::ASH),
            "GLU" | "glu" => Ok(Self::GLU),
            "GLH" | "glh" => Ok(Self::GLH),
            "HIS" | "his" => Ok(Self::HIS),
            "HIN" | "hin" => Ok(Self::HIN),
            "HID" | "hid" => Ok(Self::HID),
            "HIE" | "hie" => Ok(Self::HIE),
            "HIP" | "hip" => Ok(Self::HIP),
            "LYS" | "lys" => Ok(Self::LYS),
            "LYD" | "lyd" => Ok(Self::LYD),
            "LYN" | "lyn" => Ok(Self::LYN),
            "ARG" | "arg" => Ok(Self::ARG),
            "HYP" | "hyp" => Ok(Self::HYP),
            "ACE" | "ace" => Ok(Self::ACE),
            "BNC" | "bnc" => Ok(Self::BNC),
            "NME" | "nme" => Ok(Self::NME),
            "NMA" | "nma" => Ok(Self::NMA),
            "NHH" | "nhh" => Ok(Self::NHH),
            "UNK" | "unk" => Ok(Self::UNK),
            _ => Err(Error::ParseAminoAcid {
                found: residue.to_string(),
            }),
        }
    }

    /// Convert to the 3-char PDB standard names for the respective amino acid.
    /// See <http://www.rcsb.org/pdb/file_formats/pdb/pdbguide2.2/part_79.html>
    /// for more information about the PDB standard names.
    pub fn to_pdb_std_name(&self) -> &'static str {
        match self {
            Self::GLY => "GLY",
            Self::ALA => "ALA",
            Self::VAL => "VAL",
            Self::LEU => "LEU",
            Self::ILE => "ILE",
            Self::PRO => "PRO",
            Self::SER => "SER",
            Self::THR => "THR",
            Self::ASN => "ASN",
            Self::GLN => "GLN",
            Self::CYS => "CYS",
            Self::CYD => "CYD",
            Self::CYX => "CYX",
            Self::MET => "MET",
            Self::PHE => "PHE",
            Self::TYR => "TYR",
            Self::TYD => "TYD",
            Self::TRP => "TRP",
            Self::ASP => "ASP",
            Self::ASH => "ASH",
            Self::GLU => "GLU",
            Self::GLH => "GLH",
            Self::HIS => "HIS",
            Self::HIN => "HIN",
            Self::HID => "HID",
            Self::HIE => "HIE",
            Self::HIP => "HIP",
            Self::LYS => "LYS",
            Self::LYD => "LYD",
            Self::LYN => "LYN",
            Self::ARG => "ARG",
            Self::HYP => "HYP",
            Self::ACE => "ACE",
            Self::BNC => "BNC",
            Self::NME => "NME",
            Self::NMA => "NMA",
            Self::NHH => "NHH",
            Self::UNK => "UNK",
        }
    }

    pub fn one_letter_code(&self) -> char {
        match self {
            Self::GLY => 'G',
            Self::ALA => 'A',
            Self::VAL => 'V',
            Self::LEU => 'L',
            Self::ILE => 'I',
            Self::PRO => 'P',
            Self::SER => 'S',
            Self::THR => 'T',
            Self::ASN => 'N',
            Self::GLN => 'Q',
            Self::CYS => 'C',
            Self::CYD => 'C',
            Self::CYX => 'C',
            Self::MET => 'M',
            Self::PHE => 'F',
            Self::TYR => 'Y',
            Self::TYD => 'Y',
            Self::TRP => 'W',
            Self::ASP => 'D',
            Self::ASH => 'D',
            Self::GLU => 'E',
            Self::GLH => 'E',
            Self::HIS => 'H',
            Self::HIN => 'H',
            Self::HID => 'H',
            Self::HIE => 'H',
            Self::HIP => 'H',
            Self::LYS => 'K',
            Self::LYD => 'K',
            Self::LYN => 'K',
            Self::ARG => 'R',
            Self::HYP => 'O',
            Self::ACE | Self::BNC | Self::NME | Self::NMA | Self::NHH | Self::UNK => 'X',
        }
    }

    pub fn as_str(&self) -> &'static str {
        self.to_pdb_std_name()
    }
}

#[cfg(feature = "pyo3")]
#[pyo3::pymethods]
impl AminoAcidSeq {
    #[staticmethod]
    #[pyo3(name = "is_amino_acid")]
    fn py_is_amino_acid(residue: &str) -> bool {
        Self::is_amino_acid(residue)
    }

    #[staticmethod]
    #[pyo3(name = "from_pdb_std_name")]
    fn py_from_pdb_std_name(residue: &str) -> pyo3::PyResult<Self> {
        Self::from_pdb_std_name(residue)
            .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))
    }

    #[pyo3(name = "to_pdb_std_name")]
    fn py_to_pdb_std_name(&self) -> &'static str {
        self.to_pdb_std_name()
    }

    #[pyo3(name = "one_letter_code")]
    fn py_one_letter_code(&self) -> char {
        self.one_letter_code()
    }

    fn __str__(&self) -> String {
        self.to_string()
    }
}

impl Display for AminoAcidSeq {
    fn fmt(&self, f: &mut Formatter) -> fmt::Result {
        write!(f, "{}", self.to_pdb_std_name())
    }
}

impl PartialEq<str> for AminoAcidSeq {
    fn eq(&self, other: &str) -> bool {
        self.to_pdb_std_name() == other
    }
}

impl PartialEq<String> for AminoAcidSeq {
    fn eq(&self, other: &String) -> bool {
        self.to_pdb_std_name() == other
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
#[repr(u8)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum SolventKind {
    Calcium,
    Chlorine,
    Sodium,
    SodiumChloride,
    Water,
    HeavyWater,
}

// tests
#[cfg(test)]
mod tests {
    use super::*;
    // extend residues
    #[test]
    fn test_residues_add() {
        let mut residues = Residues {
            labeled: Some(vec![ResidueRef(0)]),
            labels: Some(vec![vec!["a".to_string(), "b".to_string()]]),
            residues: vec![
                Residue(vec![AtomRef(0), AtomRef(1)]),
                Residue(vec![AtomRef(2)]),
            ],
            seqs: vec!["a".to_string(), "b".to_string()],
            seq_ns: vec![1, 2],
            insertion_codes: vec!["".to_string(), "".to_string()],
        };
        let residues2 = Residues {
            labeled: Some(vec![ResidueRef(0), ResidueRef(1)]),
            labels: Some(vec![vec!["c".to_string()], vec!["d".to_string()]]),
            residues: vec![
                Residue(vec![AtomRef(0), AtomRef(1)]),
                Residue(vec![AtomRef(2)]),
            ],
            seqs: vec!["c".to_string(), "d".to_string()],
            seq_ns: vec![3, 4],
            insertion_codes: vec!["".to_string(), "".to_string()],
        };
        residues.extend(residues2).unwrap();
        assert_eq!(
            residues,
            Residues {
                labeled: Some(vec![ResidueRef(0), ResidueRef(2), ResidueRef(3)]),
                labels: Some(vec![
                    vec!["a".to_string(), "b".to_string()],
                    vec!["c".to_string()],
                    vec!["d".to_string()]
                ]),
                residues: vec![
                    Residue(vec![AtomRef(0), AtomRef(1)]),
                    Residue(vec![AtomRef(2)]),
                    Residue(vec![AtomRef(3), AtomRef(4)]),
                    Residue(vec![AtomRef(5)])
                ],
                seqs: vec![
                    "a".to_string(),
                    "b".to_string(),
                    "c".to_string(),
                    "d".to_string()
                ],
                seq_ns: vec![1, 2, 3, 4],
                insertion_codes: vec![
                    "".to_string(),
                    "".to_string(),
                    "".to_string(),
                    "".to_string()
                ]
            }
        );
    }

    #[test]
    fn test_residues_extend_error() {
        let mut residues = Residues {
            labeled: Some(vec![ResidueRef(0)]),
            labels: Some(vec![vec!["a".to_string(), "b".to_string()]]),
            residues: vec![
                Residue(vec![AtomRef(0), AtomRef(1)]),
                Residue(vec![AtomRef(2)]),
            ],
            seqs: vec!["a".to_string(), "b".to_string()],
            seq_ns: vec![1, 2],
            insertion_codes: vec!["".to_string(), "".to_string()],
        };
        let residues2 = Residues {
            labeled: Some(vec![ResidueRef(0), ResidueRef(1)]),
            labels: None,
            residues: vec![
                Residue(vec![AtomRef(0), AtomRef(1)]),
                Residue(vec![AtomRef(2)]),
            ],
            seqs: vec!["c".to_string(), "d".to_string()],
            seq_ns: vec![3, 4],
            insertion_codes: vec!["".to_string(), "".to_string()],
        };
        assert_eq!(
            residues.extend(residues2).unwrap_err(),
            ResiduesError::LabelsMissing
        );
    }

    #[test]
    fn test_new_residues_from_subset() {
        let residues = Residues {
            residues: vec![
                Residue(vec![0.into(), 1.into()]),
                Residue(vec![2.into(), 4.into()]),
                Residue(vec![3.into(), 5.into()]),
            ],
            seqs: vec!["0".to_string(), "1".to_string(), "2".to_string()],
            seq_ns: vec![0, 1, 2],
            insertion_codes: vec!["0".to_string(), "1".to_string(), "2".to_string()],
            labeled: Some(vec![ResidueRef(2)]),
            labels: Some(vec![vec!["one".to_string(), "two".to_string()]]),
        };

        let residue_indices = vec![ResidueRef(1), ResidueRef(2)];

        let expected_residues = Residues {
            residues: vec![
                Residue(vec![0.into(), 1.into()]),
                Residue(vec![2.into(), 3.into()]),
            ],
            seqs: vec!["1".to_string(), "2".to_string()],
            seq_ns: vec![1, 2],
            insertion_codes: vec!["1".to_string(), "2".to_string()],
            labeled: Some(vec![ResidueRef(1)]),
            labels: Some(vec![vec!["one".to_string(), "two".to_string()]]),
        };

        let new_residues = residues.new_residues_from_subset(&residue_indices);

        assert_eq!(new_residues.residues, expected_residues.residues);
        assert_eq!(new_residues.seqs, expected_residues.seqs);
        assert_eq!(new_residues.seq_ns, expected_residues.seq_ns);
        assert_eq!(
            new_residues.insertion_codes,
            expected_residues.insertion_codes
        );
        assert_eq!(new_residues.labeled, expected_residues.labeled);
        assert_eq!(new_residues.labels, expected_residues.labels);
    }
}
