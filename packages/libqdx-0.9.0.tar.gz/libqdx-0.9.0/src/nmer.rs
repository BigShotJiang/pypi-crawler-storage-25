use ouroboros::TypeInfo;
#[cfg(feature = "serde")]
use serde_with::skip_serializing_none;

use crate::{AtomRef, FragmentRef, Tensorf64, version::SchemaVersion};

#[derive(Clone, Debug, Default, TypeInfo)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(
        input_name = "QMNmerInput",
        name = "QMNmer",
        rename_fields = "snake_case"
    )
)]
#[cfg_attr(feature = "serde", skip_serializing_none)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Nmer {
    pub schema_version: SchemaVersion,

    /// List of fragments that are in this n-mer. Monomers have 1 fragment,
    /// dimers have 2 fragments, trimers have 3 fragments, and so on. These
    /// fragments are references to the fragments defined by a `Topology`.
    pub fragments: Vec<FragmentRef>,

    /// The converged density matrix for this n-mer in either square-symmetric or
    /// vectorised lower-triangular form.
    pub density: Option<Tensorf64>,

    /// The converged fock matrix for this n-mer in either square-symmetric or
    /// vectorised lower-triangular form.
    pub fock: Option<Tensorf64>,

    /// The overlap matrix for this n-mer in either square-symmetric or
    /// vectorised lower-triangular form.
    pub overlap: Option<Tensorf64>,

    /// The core hamiltonian matrix for this n-mer in either square-symmetric or
    /// vectorised lower-triangular form.
    pub h_core: Option<Tensorf64>,

    /// The initial coefficient matrix for the n-mer.
    pub coeffs_initial: Option<Tensorf64>,

    /// The final coefficient matrix for the n-mer.
    pub coeffs_final: Option<Tensorf64>,

    /// The molecular orbital energies for the n-mer. If present, there must be
    /// one entry per basis function.
    pub molecular_orbital_energies: Option<Vec<f64>>,

    /// Hartree-Fock gradient vectors for each atom in this n-mer. The gradients
    /// are orderd by fragment (as specified by this n-mer) and then by atom
    /// ordering (as specified by the referenced fragment). For example, in a
    /// dimer, all XYZ gradient vectors for the 1st fragment will appear before
    /// all XYZ gradients for the 2nd fragment; and the XYZ gradient vectors of
    /// each fragment will be ordered according to the atom ordering in the
    /// referenced element of the `fragments` field of the respective
    /// `Topology`. If `hf_gradients` is `Some`, then `mp2_gradients` must be
    /// `None`.
    pub hf_gradients: Option<Vec<f64>>,

    /// MP2 gradient vectors for each atom in this n-mer. The gradients are
    /// orderd by fragment (
    /// as specified by this n-mer) and then by atom
    /// ordering (as specified by the referenced fragment). For example, in a
    /// dimer, all XYZ gradient vectors for the 1st fragment will appear before
    /// all XYZ gradients for the 2nd fragment; and the XYZ gradient vectors of
    /// each fragment will be ordered according to the atom ordering in the
    /// referenced element of the `fragments` field of the respective
    /// `Topology`. If `mp2_gradients` is `Some`, then `hf_gradients` must be
    /// `None`.
    pub mp2_gradients: Option<Vec<f64>>,

    /// Hartree-Fock total energy of this n-mer.
    pub hf_energy: Option<f64>,

    /// MP2 same-spin correction to the total Hartree-Fock energy.
    pub mp2_ss_correction: Option<f64>,

    /// MP2 opposite-spin correction to the total Hartree-Fock energy.
    pub mp2_os_correction: Option<f64>,

    /// CCSD correction to the total Hartree-Fock energy.
    pub ccsd_correction: Option<f64>,

    /// Hartree-Fock delta energy of this n-mer. For example, in a dimer, this would be the interaction energy between the 2 udnerlying monomers.  Value only exported for unrestricted calculations, allowed the user to determine the spin contamination of the system and therefore the quality of the unrestricted calculation.
    pub s_squared_eigenvalue: Option<f64>,

    /// Hartree-Fock delta energy of this n-mer. For example, in a dimer, this
    /// would be the interaction energy between the 2 udnerlying monomers.
    pub delta_hf_energy: Option<f64>,

    /// MP2 same-spin correction to the Hartree-Fock delta energy.
    pub delta_mp2_ss_correction: Option<f64>,

    /// MP2 opposite-spin correction to the Hartree-Fock delta energy.
    pub delta_mp2_os_correction: Option<f64>,

    /// Mulliken charges of each atom in the fragment. If `None`, then this
    /// value was not exported.
    pub mulliken_charges: Option<Vec<f64>>,

    /// ChElPG charges of each atom in the fragment. If `None`, then this
    /// value was not exported.
    pub chelpg_charges: Option<Vec<f64>>,

    /// Distance between monomers in the dimer. If the nmer is not a dimer, this
    /// will not be present.
    pub fragment_distance: Option<f64>,

    /// Bond order adjacency matrix. If `None`, then this value was not
    /// exported.
    pub bond_orders: Option<Vec<Vec<f64>>>,

    /// List of atoms in this fragment that are hydrogen caps added by the
    /// fragmentation process. Elements of the list are indices relative to
    /// this fragment after the addition of hydrogen caps. The `h_caps` list
    /// must be present whenever matrices are exported (`density`, `fock`,
    /// `overlap`, etc).
    ///
    /// WARNING: these indices are local to this fragment. That is, an index
    /// of 0 represents the first atom in this fragment, and not in the
    /// first atom in the full system topology.
    pub h_caps: Option<Vec<AtomRef>>,

    /// Number of SCF iterations required to reach convergence.
    pub num_iters: u32,

    /// Number of basis functions used in the calculation.
    pub num_basis_fns: u32,
}
