use ouroboros::TypeInfo;

#[derive(Copy, Debug, Default, Eq, Clone, PartialEq, TypeInfo)]
#[repr(u8)]
#[cfg_attr(feature = "graphql", derive(async_graphql::Enum))]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum TensorKind {
    #[default]
    #[cfg_attr(
        feature = "serde",
        serde(alias = "DENSE", alias = "Dense", alias = "dense")
    )]
    Dense = 1,
    #[cfg_attr(
        feature = "serde",
        serde(
            alias = "SQUARE_SYMMETRIC",
            alias = "SquareSymmetric",
            alias = "square_symmetric"
        )
    )]
    SquareSymmetric = 2,
    #[cfg_attr(
        feature = "serde",
        serde(
            alias = "VECTORISED_LOWER_TRIANGULAR",
            alias = "VectorisedLowerTriangular",
            alias = "vectorised_lower_triangular"
        )
    )]
    LowerTriangular = 3,
}

#[derive(Clone, Debug, Default, TypeInfo)]
#[repr(C)]
#[cfg_attr(
    feature = "graphql",
    derive(async_graphql::InputObject, async_graphql::SimpleObject),
    graphql(input_name = "Tensorf64Input", rename_fields = "snake_case")
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Tensorf64 {
    /// In combination with `shape`, the `kind` tells us how to parse the `data`
    /// field.
    pub kind: TensorKind,

    /// The size of each dimensions of `Tensor`. The length of this field tells
    /// us the dimension of the `Tensor`. The value of each element tells us the
    /// size of that dimension. For example, if `shape` is `[2, 3, 4]`, then the
    /// `Tensor` is 3-dimensional, and the size of the first dimension is 2, the
    /// size of the second dimension is 3, and the size of the third dimension
    /// is 4. In combination with `kind`, the `shape` tells us how to parse the
    /// `data` field.
    pub shape: Vec<u32>,

    /// Densely packed data. To parse it, we need to consdier `kind` and
    /// `shape`.
    pub data: Vec<f64>,
}
