pub mod amino_acid_template;
pub mod atom;
pub mod binding;
pub mod bond;
pub mod chain;
pub mod constraints;
pub mod convert;
pub mod element;
pub mod error;
pub mod fragment;
pub mod interaction;
pub mod mbe;
pub mod method;
pub mod nmer;
pub mod object;
pub mod optim;
pub mod qm;
pub mod residue;
pub mod smiles;
pub mod symbol;
pub mod tensor;
pub mod topology;
pub mod traj;
pub mod trc;
pub mod ts;
pub mod version;
#[cfg(feature = "wasm")]
pub mod wasm;
pub mod xyz;

pub use atom::*;
pub use binding::*;
pub use bond::*;
pub use chain::*;
pub use element::*;
pub use error::*;
pub use fragment::*;
pub use interaction::*;
pub use mbe::*;
pub use method::*;
pub use nmer::*;
pub use object::*;
pub use optim::*;
pub use qm::*;
pub use residue::*;
pub use smiles::*;
pub use symbol::*;
pub use tensor::*;
pub use topology::*;
pub use traj::*;
pub use trc::*;
pub use version::*;
pub use xyz::*;

#[cfg(feature = "rex")]
pub mod rex;

#[cfg(feature = "rex")]
pub use rex::*;

// PyO3 boundary: make newtype refs appear as plain ints in Python.
#[cfg(feature = "pyo3")]
macro_rules! ref_into_pyobject {
    ($ty:ty) => {
        impl<'py> pyo3::IntoPyObject<'py> for $ty {
            type Target = pyo3::types::PyInt;
            type Output = pyo3::Bound<'py, Self::Target>;
            type Error = pyo3::PyErr;
            fn into_pyobject(self, py: pyo3::Python<'py>) -> Result<Self::Output, Self::Error> {
                Ok(self.0.into_pyobject(py)?)
            }
        }
    };
}

#[cfg(feature = "pyo3")]
ref_into_pyobject!(AtomRef);
#[cfg(feature = "pyo3")]
ref_into_pyobject!(ResidueRef);
#[cfg(feature = "pyo3")]
ref_into_pyobject!(ChainRef);
