use wasm_bindgen::{JsValue, prelude::wasm_bindgen};

use crate::{
    AtomCheckStrictness, Chains, Residues, TR, TRC,
    convert::{mmcif, pdb, sdf, xyz},
};

#[wasm_bindgen]
pub fn from_pdb(pdb_contents: &str) -> JsValue {
    match pdb::from_pdb(pdb_contents) {
        Ok(mut trcs) => {
            for trc in &mut trcs {
                if let Err(_e) = trc.perceive_bonds(AtomCheckStrictness::Heavy) {
                    // Do nothing
                }
            }
            serde_wasm_bindgen::to_value(&trcs).unwrap()
        }
        Err(e) => serde_wasm_bindgen::to_value(&e.to_string()).unwrap(),
    }
}

#[wasm_bindgen]
pub fn from_mmcif(mmcif_contents: &str) -> JsValue {
    match mmcif::from_mmcif(mmcif_contents) {
        Ok(mut trcs) => {
            for trc in &mut trcs {
                if let Err(_e) = trc.perceive_bonds(AtomCheckStrictness::Heavy) {
                    // Do nothing
                }
            }
            serde_wasm_bindgen::to_value(&trcs).unwrap()
        }
        Err(e) => serde_wasm_bindgen::to_value(&e.to_string()).unwrap(),
    }
}

#[wasm_bindgen]
pub fn to_pdb(trc: JsValue) -> JsValue {
    let trc = serde_wasm_bindgen::from_value(trc).unwrap();
    serde_wasm_bindgen::to_value(&pdb::to_pdb(&trc).unwrap()).unwrap()
}

#[wasm_bindgen]
pub fn from_sdf(sdf_contents: &str) -> JsValue {
    match sdf::from_sdf(sdf_contents) {
        Ok(trcs_and_dbs) => serde_wasm_bindgen::to_value(&trcs_and_dbs).unwrap(),
        Err(e) => serde_wasm_bindgen::to_value(&e.to_string()).unwrap(),
    }
}

#[wasm_bindgen]
pub fn to_sdf(trc: JsValue) -> JsValue {
    let trc = serde_wasm_bindgen::from_value(trc).unwrap();
    let mut buf = Vec::new();
    match sdf::to_sdf(&[trc], &[None], &mut buf) {
        Ok(()) => {
            let s = String::from_utf8(buf).unwrap();
            serde_wasm_bindgen::to_value(&s).unwrap()
        }
        Err(sdf_err) => serde_wasm_bindgen::to_value(&sdf_err).unwrap(),
    }
}

#[wasm_bindgen]
pub fn extend(lhs: JsValue, rhs: JsValue) -> JsValue {
    let mut lhs: TRC = serde_wasm_bindgen::from_value(lhs).unwrap();
    // rhs can be either a TR or a TRC

    if let Ok(rhs) = serde_wasm_bindgen::from_value(rhs.clone()) {
        lhs.extend(rhs).unwrap();
    } else {
        let rhs: TR = serde_wasm_bindgen::from_value(rhs).unwrap();
        let rhs = TRC {
            topology: rhs.topology,
            residues: rhs.residues,
            chains: Chains {
                chains: vec![vec![0].into()],
                ..Default::default()
            },
        };
        lhs.extend(rhs).unwrap();
    }
    serde_wasm_bindgen::to_value(&lhs).unwrap()
}

#[wasm_bindgen]
pub fn new_trc_from_residue_subset(trc: JsValue, residue_refs: &[u32]) -> JsValue {
    let trc = serde_wasm_bindgen::from_value::<TRC>(trc).unwrap();
    let new_trc = trc.new_trc_from_residue_subset(
        &residue_refs
            .iter()
            .copied()
            .map(Into::into)
            .collect::<Vec<_>>(),
    );
    serde_wasm_bindgen::to_value(&new_trc).unwrap()
}

#[wasm_bindgen]
pub fn perceive_bonds(trc: JsValue, strictness: JsValue) -> JsValue {
    let mut trc = serde_wasm_bindgen::from_value::<TRC>(trc).unwrap();
    let strictness = serde_wasm_bindgen::from_value::<Option<AtomCheckStrictness>>(strictness)
        .unwrap()
        .unwrap_or(AtomCheckStrictness::Heavy);
    trc.perceive_bonds(strictness).unwrap();
    serde_wasm_bindgen::to_value(&trc).unwrap()
}

#[wasm_bindgen]
pub fn perceive_formal_charges(trc: JsValue) -> JsValue {
    let mut trc = serde_wasm_bindgen::from_value::<TRC>(trc).unwrap();
    trc.perceive_formal_charges().unwrap();
    serde_wasm_bindgen::to_value(&trc).unwrap()
}

#[wasm_bindgen]
pub fn from_xyz(xyz_contents: &str) -> JsValue {
    match xyz::from_xyz(xyz_contents) {
        Ok(topology) => {
            let tr = TR {
                topology,
                residues: Residues::default(),
            };
            serde_wasm_bindgen::to_value(&tr).unwrap()
        }
        Err(e) => serde_wasm_bindgen::to_value(&e.to_string()).unwrap(),
    }
}

#[wasm_bindgen]
pub fn to_xyz(tr: JsValue) -> JsValue {
    let tr: TR = serde_wasm_bindgen::from_value(tr).unwrap();
    match xyz::to_xyz(&tr.topology) {
        Ok(xyz_str) => serde_wasm_bindgen::to_value(&xyz_str).unwrap(),
        Err(e) => serde_wasm_bindgen::to_value(&e.to_string()).unwrap(),
    }
}
