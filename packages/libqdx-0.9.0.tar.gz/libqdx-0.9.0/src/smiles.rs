use ouroboros::{Alias, Type, TypeInfo, TypeName};

#[cfg(feature = "graphql")]
async_graphql::scalar!(Smiles);

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[repr(transparent)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Smiles(pub String);

impl TypeInfo for Smiles {
    fn t() -> Type {
        Type::from(Alias::new("Smiles", String::t()))
    }

    fn tname() -> ouroboros::TypeName {
        TypeName::new("Smiles")
    }
}

impl From<String> for Smiles {
    fn from(value: String) -> Self {
        Self(value)
    }
}

impl From<Smiles> for String {
    fn from(value: Smiles) -> Self {
        value.0
    }
}
