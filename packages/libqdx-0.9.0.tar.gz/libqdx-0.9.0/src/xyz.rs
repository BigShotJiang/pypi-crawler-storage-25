use std::ops::{Add, Div, Sub};
#[cfg(feature = "rex")]
use std::sync::Arc;

use ouroboros::TypeInfo;
#[cfg(feature = "rex")]
use rex::{
    ast::expr::Expr,
    engine::{
        codec::{Decode, Encode},
        error::Error as EngineError,
    },
    lexer::span::Span,
    type_system::types::{ToType, Type},
};

#[cfg(feature = "graphql")]
async_graphql::scalar!(Xyzf32);

#[derive(Clone, Copy, Debug, Default, PartialEq)]
#[repr(C)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct Xyzf32(pub [f32; 3]);

impl Xyzf32 {
    pub fn new(x: f32, y: f32, z: f32) -> Self {
        Self([x, y, z])
    }

    pub fn as_slice(&self) -> &[f32] {
        unsafe { std::slice::from_raw_parts(self as *const _ as *const f32, 3) }
    }

    pub fn as_mut_slice(&mut self) -> &mut [f32] {
        unsafe { std::slice::from_raw_parts_mut(self as *mut _ as *mut f32, 3) }
    }
}

impl Add for Xyzf32 {
    type Output = Self;

    fn add(self, rhs: Self) -> Self {
        Self::new(
            self.0[0] + rhs.0[0],
            self.0[1] + rhs.0[1],
            self.0[2] + rhs.0[2],
        )
    }
}

impl Div<f32> for Xyzf32 {
    type Output = Self;

    fn div(self, rhs: f32) -> Self {
        Self::new(self.0[0] / rhs, self.0[1] / rhs, self.0[2] / rhs)
    }
}

impl Sub for Xyzf32 {
    type Output = Self;

    fn sub(self, rhs: Self) -> Self {
        Self::new(
            self.0[0] - rhs.0[0],
            self.0[1] - rhs.0[1],
            self.0[2] - rhs.0[2],
        )
    }
}

impl From<[f32; 3]> for Xyzf32 {
    fn from(arr: [f32; 3]) -> Self {
        Self::new(arr[0], arr[1], arr[2])
    }
}

impl TypeInfo for Xyzf32 {
    fn t() -> ouroboros::Type {
        <(f32, f32, f32)>::t()
    }

    fn tname() -> ouroboros::TypeName {
        <(f32, f32, f32)>::tname()
    }
}

#[cfg(feature = "rex")]
impl ToType for Xyzf32 {
    fn to_type() -> Type {
        <(f32, f32, f32)>::to_type()
    }
}

#[cfg(feature = "rex")]
impl Encode for Xyzf32 {
    fn try_encode(self, span: Span) -> Result<Arc<Expr>, EngineError> {
        Ok(Arc::new(Expr::Tuple(
            span,
            vec![
                self.0[0].try_encode(span)?,
                self.0[1].try_encode(span)?,
                self.0[2].try_encode(span)?,
            ],
        )))
    }
}

#[cfg(feature = "rex")]
impl Decode for Xyzf32 {
    fn try_decode(v: &Arc<Expr>) -> Result<Self, EngineError> {
        match &**v {
            Expr::Tuple(_span, xs) if xs.len() == 3 => Ok(Xyzf32([
                f32::try_decode(&xs[0])?,
                f32::try_decode(&xs[1])?,
                f32::try_decode(&xs[2])?,
            ])),
            _ => Err(EngineError::ExpectedTypeGotValue {
                expected: Arc::new(Self::to_type()),
                got: v.clone(),
                trace: Default::default(),
            }),
        }
    }
}
