"""Type stubs for the libqdx native extension."""

import numpy as np
import numpy.typing as npt

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class Element:
    X: Element
    H: Element
    He: Element
    Li: Element
    Be: Element
    B: Element
    C: Element
    N: Element
    O: Element
    F: Element
    Ne: Element
    Na: Element
    Mg: Element
    Al: Element
    Si: Element
    P: Element
    S: Element
    Cl: Element
    Ar: Element
    K: Element
    Ca: Element
    Sc: Element
    Ti: Element
    V: Element
    Cr: Element
    Mn: Element
    Fe: Element
    Co: Element
    Ni: Element
    Cu: Element
    Zn: Element
    Ga: Element
    Ge: Element
    As: Element
    Se: Element
    Br: Element
    Kr: Element
    Rb: Element
    Sr: Element
    Y: Element
    Zr: Element
    Nb: Element
    Mo: Element
    Tc: Element
    Ru: Element
    Rh: Element
    Pd: Element
    Ag: Element
    Cd: Element
    In: Element
    Sn: Element
    Sb: Element
    Te: Element
    I: Element
    Xe: Element
    Cs: Element
    Ba: Element
    La: Element
    Ce: Element
    Pr: Element
    Nd: Element
    Pm: Element
    Sm: Element
    Eu: Element
    Gd: Element
    Tb: Element
    Dy: Element
    Ho: Element
    Er: Element
    Tm: Element
    Yb: Element
    Lu: Element
    Hf: Element
    Ta: Element
    W: Element
    Re: Element
    Os: Element
    Ir: Element
    Pt: Element
    Au: Element
    Hg: Element
    Tl: Element
    Pb: Element
    Bi: Element
    Po: Element
    At: Element
    Rn: Element
    Fr: Element
    Ra: Element
    Ac: Element
    Th: Element
    Pa: Element
    U: Element
    Np: Element
    Pu: Element
    Am: Element
    Cm: Element
    Bk: Element
    Cf: Element
    Es: Element
    Fm: Element
    Md: Element
    No: Element
    Lr: Element
    Rf: Element
    Db: Element
    Sg: Element
    Bh: Element
    Hs: Element
    Mt: Element
    Ds: Element
    Rg: Element
    Cn: Element
    Nh: Element
    Fl: Element
    Mc: Element
    Lv: Element
    Ts: Element
    Og: Element
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...
    def __int__(self) -> int: ...

class BondOrder:
    Unspecified: BondOrder
    Single: BondOrder
    Double: BondOrder
    Triple: BondOrder
    Quadruple: BondOrder
    Quintuple: BondOrder
    Sextuple: BondOrder
    FiveAndAHalf: BondOrder
    FourAndAHalf: BondOrder
    ThreeAndAHalf: BondOrder
    TwoAndAHalf: BondOrder
    OneAndAHalf: BondOrder
    Ring: BondOrder
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...
    def __int__(self) -> int: ...

class AtomCheckStrictness:
    NONE: AtomCheckStrictness
    Heavy: AtomCheckStrictness
    All: AtomCheckStrictness
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

class Stereochemistry:
    NONE: Stereochemistry
    Up: Stereochemistry
    Down: Stereochemistry
    Either: Stereochemistry
    CisOrTrans: Stereochemistry
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

class HelixClass:
    RightHandedAlpha: HelixClass
    RightHandedOmega: HelixClass
    RightHandedPi: HelixClass
    RightHandedGamma: HelixClass
    RightHanded: HelixClass
    LeftHandedAlpha: HelixClass
    LeftHandedOmega: HelixClass
    LeftHandedGamma: HelixClass
    Ribbon27: HelixClass
    Polyproline: HelixClass
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

class StrandSense:
    First: StrandSense
    Parallel: StrandSense
    AntiParallel: StrandSense
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...

class AminoAcidSeq:
    GLY: AminoAcidSeq
    ALA: AminoAcidSeq
    VAL: AminoAcidSeq
    LEU: AminoAcidSeq
    ILE: AminoAcidSeq
    PRO: AminoAcidSeq
    SER: AminoAcidSeq
    THR: AminoAcidSeq
    ASN: AminoAcidSeq
    GLN: AminoAcidSeq
    CYS: AminoAcidSeq
    CYD: AminoAcidSeq
    CYX: AminoAcidSeq
    MET: AminoAcidSeq
    PHE: AminoAcidSeq
    TYR: AminoAcidSeq
    TYD: AminoAcidSeq
    TRP: AminoAcidSeq
    ASP: AminoAcidSeq
    ASH: AminoAcidSeq
    GLU: AminoAcidSeq
    GLH: AminoAcidSeq
    HIS: AminoAcidSeq
    HIN: AminoAcidSeq
    HID: AminoAcidSeq
    HIE: AminoAcidSeq
    HIP: AminoAcidSeq
    LYS: AminoAcidSeq
    LYD: AminoAcidSeq
    LYN: AminoAcidSeq
    ARG: AminoAcidSeq
    HYP: AminoAcidSeq
    ACE: AminoAcidSeq
    BNC: AminoAcidSeq
    NME: AminoAcidSeq
    NMA: AminoAcidSeq
    NHH: AminoAcidSeq
    UNK: AminoAcidSeq
    def __eq__(self, other: object) -> bool: ...
    def __hash__(self) -> int: ...
    @staticmethod
    def is_amino_acid(residue: str) -> bool: ...
    @staticmethod
    def from_pdb_std_name(residue: str) -> AminoAcidSeq: ...
    def to_pdb_std_name(self) -> str: ...
    def one_letter_code(self) -> str: ...

# ---------------------------------------------------------------------------
# Structs
# ---------------------------------------------------------------------------

class Bond:
    @property
    def atoms(self) -> tuple[int, int]: ...
    @property
    def order(self) -> BondOrder: ...
    def __repr__(self) -> str: ...

class AlphaHelices:
    @property
    def helix_ids(self) -> list[str]: ...
    @property
    def chain_refs(self) -> list[int]: ...
    @property
    def start_residues(self) -> list[int]: ...
    @property
    def end_residues(self) -> list[int]: ...
    @property
    def classes(self) -> list[HelixClass | None]: ...
    @property
    def lengths(self) -> list[int | None]: ...

class BetaSheets:
    @property
    def sheet_ids(self) -> list[str]: ...
    @property
    def strand_ids(self) -> list[str]: ...
    @property
    def strand_ordinals(self) -> list[int | None]: ...
    @property
    def num_strands(self) -> list[int | None]: ...
    @property
    def chain_refs(self) -> list[int]: ...
    @property
    def start_residues(self) -> list[int]: ...
    @property
    def end_residues(self) -> list[int]: ...
    @property
    def senses(self) -> list[StrandSense | None]: ...

# ---------------------------------------------------------------------------
# Topology, Residues, Chains
# ---------------------------------------------------------------------------

class Topology:
    @property
    def schema_version(self) -> str: ...
    @property
    def symbols(self) -> list[Element]: ...
    @property
    def geometry(self) -> npt.NDArray[np.float32]: ...
    @property
    def labels(self) -> list[str] | None: ...
    @property
    def formal_charges(self) -> npt.NDArray[np.int32] | None: ...
    @property
    def partial_charges(self) -> npt.NDArray[np.float32] | None: ...
    @property
    def connectivity(self) -> list[Bond] | None: ...
    @property
    def stereochemistry(self) -> list[Stereochemistry] | None: ...
    @property
    def velocities(self) -> npt.NDArray[np.float32] | None: ...
    @property
    def fragments(self) -> list[list[int]] | None: ...
    @property
    def fragment_formal_charges(self) -> list[int] | None: ...
    @property
    def fragment_partial_charges(self) -> list[float] | None: ...
    @property
    def fragment_multiplicities(self) -> list[int] | None: ...
    @property
    def num_atoms(self) -> int: ...
    def get_fragments_near_fragment(
        self, frag_idx: int, threshold: float
    ) -> list[int]: ...
    def to_dict(self) -> dict: ...
    @staticmethod
    def from_dict(data: dict) -> Topology: ...
    def __repr__(self) -> str: ...

class Residues:
    @property
    def residues(self) -> list[list[int]]: ...
    @property
    def seqs(self) -> list[str]: ...
    @property
    def seq_ns(self) -> list[int]: ...
    @property
    def insertion_codes(self) -> list[str]: ...
    @property
    def num_residues(self) -> int: ...
    def to_dict(self) -> dict: ...
    @staticmethod
    def from_dict(data: dict) -> Residues: ...
    def __repr__(self) -> str: ...

class Chains:
    @property
    def chains(self) -> list[list[int]]: ...
    @property
    def alpha_helices(self) -> AlphaHelices | None: ...
    @property
    def beta_sheets(self) -> BetaSheets | None: ...
    @property
    def num_chains(self) -> int: ...
    def to_dict(self) -> dict: ...
    @staticmethod
    def from_dict(data: dict) -> Chains: ...
    def __repr__(self) -> str: ...

# ---------------------------------------------------------------------------
# TRC
# ---------------------------------------------------------------------------

class TRC:
    def __init__(
        self,
        symbols: list[Element],
        geometry: list[list[float]],
        *,
        labels: list[str] | None = None,
        formal_charges: list[int] | None = None,
        partial_charges: list[float] | None = None,
        connectivity: list[tuple[int, int, int]] | None = None,
        fragments: list[list[int]] | None = None,
        residues: list[list[int]] | None = None,
        residue_seqs: list[str] | None = None,
        residue_seq_ns: list[int] | None = None,
        residue_insertion_codes: list[str] | None = None,
        chains: list[list[int]] | None = None,
    ) -> None: ...
    @property
    def topology(self) -> Topology: ...
    @property
    def residues(self) -> Residues: ...
    @property
    def chains(self) -> Chains: ...
    @property
    def num_atoms(self) -> int: ...
    @property
    def num_residues(self) -> int: ...
    @property
    def num_chains(self) -> int: ...
    def perceive_bonds(
        self, strictness: AtomCheckStrictness = AtomCheckStrictness.Heavy
    ) -> TRC: ...
    def perceive_formal_charges(self) -> TRC: ...
    def check(self) -> None: ...
    def extend(self, other: TRC) -> TRC: ...
    def subset_by_residues(self, refs: list[int]) -> TRC: ...
    def with_fragments(self, fragments: list[list[int]]) -> TRC: ...
    def with_geometry(self, geometry: list[list[float]]) -> TRC: ...
    def to_dict(self) -> dict: ...
    @staticmethod
    def from_dict(data: dict) -> TRC: ...
    def __repr__(self) -> str: ...

# ---------------------------------------------------------------------------
# Format conversions
# ---------------------------------------------------------------------------

def from_pdb(contents: str) -> list[TRC]: ...
def to_pdb(trc: TRC) -> str: ...
def from_mmcif(contents: str) -> list[TRC]: ...
def from_sdf(contents: str) -> list[TRC]: ...
def to_sdf(trc: TRC) -> str: ...
def from_xyz(contents: str) -> TRC: ...
def to_xyz(trc: TRC) -> str: ...
