"""Entry point for python -m migraph."""

from migraph.views.cli import main

if __name__ == "__main__":
    main()
