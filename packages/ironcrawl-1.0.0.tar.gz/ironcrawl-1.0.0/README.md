# Ironcrawl

Powerful terminal-first web scraping and AI extraction tool.

Ironcrawl combines Playwright-based browser automation with AI-powered content formatting to extract clean, structured data from any website. It supports stealth mode to bypass WAFs, waits for dynamic JavaScript content, and outputs results in Markdown or JSON.

## Features

- **Headless Browser Scraping** — Powered by Playwright for full JS-rendered page support
- **Stealth Mode** — Optional `playwright-stealth` integration to bypass rigid WAF checks
- **AI-Powered Formatting** — Uses nixagent or ocode to intelligently format extracted content
- **Multi-Format Output** — Export as Markdown or JSON
- **CLI-First Design** — Pipe output to other tools, save to files, or print to stdout
- **Network Idle Wait** — Waits for all AJAX/fetch requests to complete before extraction

## Installation

### From PyPI

```bash
pip install ironcrawl
```

### From Source

```bash
git clone https://github.com/<your-username>/ironcrawl.git
cd ironcrawl
pip install -e .
```

### Install Playwright Browsers

After installation, install the required Playwright browser binaries:

```bash
playwright install
```

## Configuration

Create a `.env` file in your project root (copy from `.env.example`):

```env
# Active Agent Selection (nixagent | ocode)
ACTIVE_AGENT=nixagent

# OpenAI Configuration (used by nixagent)
OPENAI_API_KEY=your_api_key_here
OPENAI_BASE_URL=https://your-openai-proxy.example.com/v1
OPENAI_MODEL="your-model"

# OpenCode Provider Config (used when ACTIVE_AGENT=ocode)
OPENCODE_BASE_URL=http://127.0.0.1:4096
OPENCODE_PROJECT_PATH=/path/to/your/project

# Logging
LOG_LEVEL=INFO
LOG_FILE=agent.log
```

## Usage

### Basic Scraping

Extract content from a URL and output as Markdown:

```bash
ironcrawl scrape https://example.com
```

### Save to File

```bash
ironcrawl scrape https://example.com --out output.md
```

### JSON Output

```bash
ironcrawl scrape https://example.com --format json --out data.json
```

### Enable Stealth Mode

Bypass WAF/bot detection:

```bash
ironcrawl scrape https://example.com --stealth
```

### Wait for Network Idle

Wait for all background requests to finish:

```bash
ironcrawl scrape https://example.com --wait-network-idle
```

### Full Example

```bash
ironcrawl scrape https://news.ycombinator.com \
  --format markdown \
  --stealth \
  --wait-network-idle \
  --out hackernews.md
```

### CLI Options

| Option | Description |
|---|---|
| `url` | Target URL (required) |
| `--format` | Output format: `markdown` (default) or `json` |
| `--out` | Save output to file path instead of stdout |
| `--stealth` | Enable playwright-stealth to bypass WAF |
| `--wait-network-idle` | Wait for network to be idle before extraction |

## Architecture

Ironcrawl follows a 3-stage pipeline:

1. **Scrape** — Playwright navigates to the target URL, optionally applies stealth, and waits for network idle. Raw HTML is captured.
2. **Extract** — Microsoft MarkItDown and BeautifulSoup parse the HTML, removing scripts, styles, and noise elements.
3. **Format** — An AI agent (nixagent or ocode) processes the extracted text in chunks and produces clean, structured output.

## Dependencies

- `nixagent` — AI agent framework
- `ocode` — OpenCode agent client
- `beautifulsoup4` — HTML parsing
- `markitdown` — Document-to-markdown conversion
- `playwright` — Browser automation
- `playwright-stealth` — Anti-detection
- `python-dotenv` — Environment variable loading

## License

MIT
