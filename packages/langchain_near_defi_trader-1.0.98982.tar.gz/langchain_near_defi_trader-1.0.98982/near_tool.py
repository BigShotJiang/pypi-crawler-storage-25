"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Agent - NEAR DeFi Trader
"""
import requests
import json
import base64
import time
import hashlib
import hmac
import urllib.parse
import os
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


# Tool 1: Get DEX Pool Info (ref.finance pools)
class DEXPoolInfoInput(BaseModel):
    token_in: str = Field(..., description="Token contract address to swap from (e.g. 'wrap.near')")
    token_out: str = Field(..., description="Token contract address to swap to (e.g. 'usdc.near')")
    amount_in: str = Field(default="1000000000000000000000000", description="Amount in yoctoNEAR or token base units")

class DEXPoolInfoTool(BaseTool):
    name: str = "dex_pool_info"
    description: str = (
        "Fetch best swap pool and estimated output from Ref Finance (NEAR's main DEX) "
        "for a given token pair. Returns pool ID, fee, estimated output amount, and price impact."
    )
    args_schema: Type[BaseModel] = DEXPoolInfoInput

    def _run(self, token_in: str, token_out: str, amount_in: str = "1000000000000000000000000") -> str:
        try:
            # Query Ref Finance pools via their API
            resp = requests.get(
                "https://indexer.ref.finance/list-pools",
                params={"token0": token_in, "token1": token_out},
                timeout=10,
            )
            pools_data = resp.json() if resp.ok else []

            # Also query on-chain via RPC view call to ref-finance.near
            params = {
                "request_type": "call_function",
                "finality": "final",
                "account_id": "v2.ref-finance.near",
                "method_name": "get_pools",
                "args_base64": __import__("base64").b64encode(
                    __import__("json").dumps({"from_index": 0, "limit": 1000}).encode()
                ).decode(),
            }
            rpc_result = _near_rpc("query", params)
            on_chain_pools = []
            if rpc_result and "result" in rpc_result:
                raw = bytes(rpc_result["result"])
                on_chain_pools = __import__("json").loads(raw.decode())

            # Filter relevant pools
            relevant = [
                p for p in on_chain_pools
                if isinstance(p, dict)
                and token_in in p.get("token_account_ids", [])
                and token_out in p.get("token_account_ids", [])
            ]

            if not relevant:
                return f"No pools found for {token_in} → {token_out} on Ref Finance."

            best = max(relevant, key=lambda p: sum(
                int(a) for a in p.get("amounts", ["0", "0"])
            ))
            idx = on_chain_pools.index(best)
            token_ids = best.get("token_account_ids", [])
            amounts = best.get("amounts", [])
            fee = best.get("total_fee", 30)
            shares = best.get("shares_total_supply", "0")

            return (
                f"Best pool for {token_in} → {token_out}:\n"
                f"  Pool ID: {idx}\n"
                f"  Tokens: {token_ids}\n"
                f"  Reserves: {amounts}\n"
                f"  Fee: {fee / 10000:.2f}%\n"
                f"  Total shares: {shares}\n"
                f"  Ref API pools found: {len(pools_data) if isinstance(pools_data, list) else 'N/A'}"
            )
        except Exception as e:
            return f"Error fetching DEX pool info: {e}"

    async def _arun(self, *args: Any, **kwargs: Any) -> str:
        import asyncio
        return await asyncio.to_thread(self._run, *args, **kwargs)


# Tool 2: Get DeFi Portfolio Positions
class DeFiPortfolioInput(BaseModel):
    account_id: str = Field(..., description="NEAR account ID to check DeFi positions for")

class DeFiPortfolioTool(BaseTool):
    name: str = "defi_portfolio"
    description: str = (
        "Fetch a NEAR account's DeFi portfolio: Ref Finance LP shares, "
        "Burrow lending/borrowing positions, and top token balances."
    )
    args_schema: Type[BaseModel] = DeFiPortfolioInput

    def _run(self, account_id: str) -> str:
        import json, base64
        results = []

        def view_call(contract: str, method: str, args: dict) -> Any:
            p = {
                "request_type": "call_function",
                "finality": "final",
                "account_id": contract,
                "method_name": method,
                "args_base64": base64.b64encode(json.dumps(args).encode()).decode(),
            }
            r = _near_rpc("query", p)
            if r and "result" in r:
                return json.loads(bytes(r["result"]).decode())
            return None

        # Ref Finance LP shares
        try:
            lp_shares = view_call("v2.ref-finance.near", "get_deposits", {"account_id": account_id})
            if lp_shares:
                results.append(f"Ref Finance LP deposits: {json.dumps(lp_shares, indent=2)}")
            else:
                results.append("Ref Finance: No LP deposits found.")
        except Exception as e:
            results.append(f"Ref Finance error: {e}")

        # Burrow supply/borrow
        try:
            burrow = view_call("contract.main.burrow.near", "get_account", {"account_id": account_id})
            if burrow:
                supplied = burrow.get("supplied", [])
                borrowed = burrow.get("borrowed", [])
                results.append(
                    f"Burrow positions:\n  Supplied: {supplied}\n  Borrowed: {borrowed}"
                )
            else:
                results.append("Burrow: No positions found.")
        except Exception as e:
            results.append(f"Burrow error: {e}")

        # NEAR balance
        try:
            acct = _near_rpc("query", {
                "request_type": "view_account",
                "finality": "final",
                "account_id": account_id,
            })
            if acct and "amount" in acct:
                near_bal = int(acct["amount"]) / 1e24
                results.append(f"NEAR balance: {near_bal:.4f} NEAR")
        except Exception as e:
            results.append(f"NEAR balance error: {e}")

        return "\n\n".join(results) if results else "No DeFi positions found."

    async def _arun(self, *args: Any, **kwargs: Any) -> str:
        import asyncio
        return await asyncio.to_thread(self._run, *args, **kwargs)