# LangChain Agent - NEAR DeFi Trader

Build a LangChain agent template for defi trader on NEAR.

**THE VIRAL LOOP:**
User wants defi trader agent → Uses template → Agent operates on NEAR

**Deliverables:**
1. Complete LangChain agent with

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `DEXPoolInfoTool` — see near_tool.py
- `DeFiPortfolioTool` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, DEXPoolInfoTool, DeFiPortfolioTool

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
