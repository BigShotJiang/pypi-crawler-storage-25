"""Streaming chat tests."""
