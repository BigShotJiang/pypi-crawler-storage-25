"""Skills packaging tests."""
