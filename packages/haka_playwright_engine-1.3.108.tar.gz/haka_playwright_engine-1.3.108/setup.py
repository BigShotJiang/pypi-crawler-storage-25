#!/usr/bin/env python3
"""
Setup configuration for playwright-behave-framework
"""
from setuptools import setup, find_packages, find_namespace_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

# Read requirements
with open('requirements.txt') as f:
    requirements = f.read().splitlines()

setup(
    name="haka-playwright-engine",
    version="1.3.108",
    author="Felipe Farias",
    author_email="felipe.farias@hakalab.com",
    description="Framework completo de pruebas funcionales con Playwright y Behave",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pipefariashaka/haka-playwright-engine",
    packages=find_packages(include=['hakalab_framework', 'hakalab_framework.*']),
    include_package_data=True,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Testing",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
            "mypy>=0.950",
        ],
        "allure": [
            "allure-commandline>=2.20.0",
        ],
        "ai": [
            # Semantic Validation (Sentence Transformers)
            "sentence-transformers>=2.2.0",
            "torch>=2.0.0",
            "transformers>=4.30.0",
            "keybert>=0.8.0",
            "scikit-learn>=1.3.0",
            # GenAI Evaluation (Gemini)
            "google-genai>=0.1.0",
        ],
        "ocr": [
            # OCR Dependencies
            "pytesseract>=0.3.10",
            "easyocr>=1.7.0",
            "Pillow>=10.0.0",
            "opencv-python>=4.8.0",
            "numpy>=1.24.0",
        ],
        "desktop": [
            # Desktop Automation Dependencies
            "pyautogui>=0.9.54",
            "Pillow>=10.0.0",
            "pyperclip>=1.8.2",
        ],
        "all": [
            # Todas las dependencias opcionales
            "sentence-transformers>=2.2.0",
            "torch>=2.0.0",
            "transformers>=4.30.0",
            "keybert>=0.8.0",
            "scikit-learn>=1.3.0",
            "google-genai>=0.1.0",
            "pytesseract>=0.3.10",
            "easyocr>=1.7.0",
            "Pillow>=10.0.0",
            "opencv-python>=4.8.0",
            "numpy>=1.24.0",
            "pyautogui>=0.9.54",
            "pyperclip>=1.8.2",
        ]
    },
    entry_points={
        "console_scripts": [
            "haka-init=hakalab_framework.cli:init_project",
            "haka-run=hakalab_framework.cli:run_tests",
            "haka-report=hakalab_framework.cli:generate_report",
            "haka-steps=hakalab_framework.cli:list_steps",
            "haka-validate=hakalab_framework.cli:validate_project",
            "haka-html=hakalab_framework.cli_html_report:html_cli",
        ],
    },
    package_data={
        "hakalab_framework": [
            "templates/*.feature",
            "templates/*.json",
            "templates/*.py",
            "templates/*.ini",
            "templates/*.env",
            "templates/*.md",
        ],
    },
    keywords="playwright behave bdd testing automation functional-testing",
    project_urls={
        "Bug Reports": "https://github.com/pipefariashaka/haka-playwright-engine/issues",
        "Source": "https://github.com/pipefariashaka/haka-playwright-engine",
        "Documentation": "https://github.com/pipefariashaka/haka-playwright-engine#readme",
    },
)