"""사내 지식 저장소 MCP 서버.

GitHub 레포에 저장된 사내 지식 문서를 조회/업로드하는 3개 tool을 제공한다.
- get_index: index.json 기반 문서 검색
- read_doc: 문서 내용 읽기
- write_doc: 문서 쓰기 + index 갱신 + commit & push

저장소 동기화(clone/pull)는 각 tool 호출 시 TTL 기반으로 자동 수행된다.
"""

import json
import os
import re
import subprocess
import time
from pathlib import Path

from mcp.server.fastmcp import FastMCP

REPO_URL = os.environ.get("CONTEXT_REPO_URL", "")
DATA_DIR = Path(os.environ.get("CONTEXT_DATA_DIR", "")) if os.environ.get("CONTEXT_DATA_DIR") else Path.home() / ".cache" / "contexts-server"
REPO_DIR = DATA_DIR / "repo"

server = FastMCP("context-in")

_WRITE_LOCK_TIMEOUT = 30


class _DirLock:
    """디렉토리 생성 기반 크로스 플랫폼 파일 락.

    mkdir은 모든 OS에서 원자적이므로 별도 의존성 없이
    프로세스 간 배타적 접근을 보장한다.
    """

    def __init__(self, lock_dir: Path, timeout: int = _WRITE_LOCK_TIMEOUT):
        self.lock_dir = lock_dir
        self.timeout = timeout

    def __enter__(self):
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                self.lock_dir.mkdir()
                return self
            except FileExistsError:
                if time.monotonic() > deadline:
                    # 타임아웃 — stale lock으로 간주하고 강제 해제
                    try:
                        self.lock_dir.rmdir()
                    except OSError:
                        pass
                    self.lock_dir.mkdir()
                    return self
                time.sleep(0.5)

    def __exit__(self, *exc):
        try:
            self.lock_dir.rmdir()
        except OSError:
            pass


def _run_git(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess:
    """git 명령 실행 헬퍼."""
    return subprocess.run(
        ["git", *args],
        cwd=cwd or REPO_DIR,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        timeout=60,
    )


def _get_head_commit() -> str:
    """현재 HEAD 커밋 해시(short) 반환."""
    result = _run_git("rev-parse", "--short", "HEAD")
    return result.stdout.strip() if result.returncode == 0 else "unknown"


def _pull_with_fallback() -> subprocess.CompletedProcess:
    """pull --ff-only 시도 후 실패 시 --rebase로 재시도."""
    result = _run_git("pull", "--ff-only")
    if result.returncode == 0:
        return result
    return _run_git("pull", "--rebase")


_last_sync_time: float = 0
_SYNC_TTL = 60  # seconds


def _ensure_synced(ttl: int = _SYNC_TTL) -> dict | None:
    """필요 시 저장소를 동기화한다 (clone 또는 TTL 기반 pull).

    Returns:
        None: 정상
        dict: 에러 ({"error": "메시지"})
    """
    global _last_sync_time

    if not REPO_URL:
        return {"error": "CONTEXT_REPO_URL이 설정되지 않았습니다."}

    now = time.monotonic()

    if not REPO_DIR.exists():
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        result = _run_git("clone", REPO_URL, str(REPO_DIR), cwd=DATA_DIR)
        if result.returncode != 0:
            return {"error": f"clone 실패: {result.stderr.strip()}"}
        _last_sync_time = now
        return None

    if now - _last_sync_time > ttl:
        result = _pull_with_fallback()
        if result.returncode != 0:
            return {"error": f"pull 실패: {result.stderr.strip()}"}
        _last_sync_time = now

    return None


def _load_index() -> dict:
    """repo/index.json을 읽어서 반환."""
    index_path = REPO_DIR / "index.json"
    if not index_path.exists():
        return {"version": 1, "entries": []}
    with open(index_path, encoding="utf-8") as f:
        return json.load(f)


def _save_index(index: dict) -> None:
    """index.json을 저장."""
    index_path = REPO_DIR / "index.json"
    with open(index_path, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)
        f.write("\n")


_SEPARATOR_RE = re.compile(r"[-_.]")


def _normalize(text: str) -> str:
    """검색용 정규화: 소문자 변환 + 하이픈/언더스코어/점을 공백으로 치환."""
    return _SEPARATOR_RE.sub(" ", text.lower())


def _match_query(query: str, entry: dict) -> bool:
    """entry의 title, tags, keywords, description에서 query 키워드 매칭.

    하이픈, 언더스코어, 점은 공백으로 정규화하여
    "socket-library"와 "socket library"가 상호 매칭된다.
    """
    keywords = _normalize(query).split()

    searchable = _normalize(" ".join([
        entry.get("title", ""),
        entry.get("description", ""),
        " ".join(entry.get("tags", [])),
        " ".join(entry.get("keywords", [])),
        " ".join(doc.get("doc_title", "") for doc in entry.get("docs", [])),
    ]))

    return any(kw in searchable for kw in keywords)


@server.tool()
def get_index(query: str = "") -> dict:
    """index.json에서 문서를 검색한다.

    Args:
        query: 자연어 검색어 (빈 문자열이면 전체 목록 반환)

    Returns:
        entries: 매칭된 entry 배열
    """
    err = _ensure_synced()
    if err:
        return err

    index = _load_index()
    entries = index.get("entries", [])

    if not query.strip():
        return {"entries": entries, "total": len(entries)}

    matched = [e for e in entries if _match_query(query, e)]
    return {"entries": matched, "total": len(matched)}


@server.tool()
def read_doc(path: str) -> dict:
    """지정된 경로의 문서 내용을 읽는다.

    Args:
        path: index의 docs[].path 값 (레포 루트 기준 상대 경로)

    Returns:
        content: 문서 내용 (마크다운 텍스트)
    """
    err = _ensure_synced()
    if err:
        return err

    doc_path = REPO_DIR / path
    if not doc_path.exists():
        return {"error": f"파일을 찾을 수 없습니다: {path}"}

    # 경로 탈출 방지
    try:
        doc_path.resolve().relative_to(REPO_DIR.resolve())
    except ValueError:
        return {"error": f"허용되지 않는 경로입니다: {path}"}

    content = doc_path.read_text(encoding="utf-8")
    return {"path": path, "content": content}


@server.tool()
def write_doc(path: str, content: str, index_entry: dict) -> dict:
    """문서를 작성하고 index.json을 갱신한 뒤 commit & push 한다.

    Args:
        path: 저장할 파일 경로 (레포 루트 기준 상대 경로)
        content: 문서 내용
        index_entry: index.json에 등록할 정보
            - id: 주제 식별자 (예: "socket-lib")
            - title: 주제 제목
            - description: 주제 설명
            - tags: 태그 배열
            - keywords: 키워드 배열
            - doc_title: 이 문서의 제목 (예: "API Reference")
            - version: 문서 대상의 버전 (선택, 예: "2.1.0")

    Returns:
        status: "success" | "error"
        commit: 커밋 해시
    """
    # 레포 존재 보장 (clone)
    err = _ensure_synced()
    if err:
        return {"status": "error", "message": err["error"]}

    # 경로 탈출 방지 (락 획득 전에 검증)
    doc_path = REPO_DIR / path
    try:
        doc_path.resolve().relative_to(REPO_DIR.resolve())
    except ValueError:
        return {"status": "error", "message": f"허용되지 않는 경로입니다: {path}"}

    with _DirLock(DATA_DIR / ".write_lock"):
        # 최신화
        pull_result = _pull_with_fallback()
        if pull_result.returncode != 0:
            return {"status": "error", "message": f"pull 실패: {pull_result.stderr.strip()}"}

        # 파일 쓰기
        doc_path.parent.mkdir(parents=True, exist_ok=True)
        doc_path.write_text(content, encoding="utf-8")

        # index.json 갱신
        index = _load_index()
        entries = index.get("entries", [])

        entry_id = index_entry.get("id", "")
        doc_record = {
            "path": path,
            "doc_title": index_entry.get("doc_title", ""),
        }

        existing = next((e for e in entries if e.get("id") == entry_id), None)
        if existing:
            docs = existing.get("docs", [])
            replaced = False
            for i, d in enumerate(docs):
                if d.get("path") == path:
                    docs[i] = doc_record
                    replaced = True
                    break
            if not replaced:
                docs.append(doc_record)
            existing["docs"] = docs
            for key in ("title", "description", "tags", "keywords", "version"):
                if key in index_entry:
                    existing[key] = index_entry[key]
        else:
            new_entry = {
                "id": entry_id,
                "title": index_entry.get("title", ""),
                "description": index_entry.get("description", ""),
                "tags": index_entry.get("tags", []),
                "keywords": index_entry.get("keywords", []),
                "docs": [doc_record],
            }
            if index_entry.get("version"):
                new_entry["version"] = index_entry["version"]
            entries.append(new_entry)

        index["entries"] = entries
        _save_index(index)

        # git add → commit → push (push 실패 시 rebase 후 재시도)
        _run_git("add", path, "index.json")
        commit_msg = f"docs: {index_entry.get('title', path)} - {index_entry.get('doc_title', 'update')}"
        result = _run_git("commit", "-m", commit_msg)
        if result.returncode != 0:
            return {"status": "error", "message": f"commit 실패: {result.stderr.strip()}"}

        for attempt in range(3):
            push_result = _run_git("push")
            if push_result.returncode == 0:
                return {"status": "success", "commit": _get_head_commit()}
            if attempt < 2:
                rebase = _run_git("pull", "--rebase")
                if rebase.returncode != 0:
                    return {
                        "status": "error",
                        "message": f"push 충돌 해결 실패: {rebase.stderr.strip()}",
                    }

        return {"status": "error", "message": f"push 실패 (3회 시도): {push_result.stderr.strip()}"}


def main():
    """엔트리포인트: uvx에서 호출되는 함수."""
    server.run(transport="stdio")


if __name__ == "__main__":
    main()
