"""Rich terminal reporting for benchmark results."""

from __future__ import annotations

from rich.console import Console
from rich.table import Table

from mdarena.evaluation.metrics import compute_p_value
from mdarena.models import BenchmarkReport

console = Console()


def _fmt_pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def _fmt_delta(value: float, invert: bool = False) -> str:
    """Format a delta value with color. invert=True means lower is better."""
    pct = value * 100
    if abs(pct) < 0.1:
        return "[dim]--[/dim]"
    sign = "+" if pct > 0 else ""
    color = "green" if (pct > 0) != invert else "red"
    return f"[{color}]{sign}{pct:.1f}%[/{color}]"


def _fmt_delta_cost(value: float) -> str:
    if abs(value) < 0.001:
        return "[dim]--[/dim]"
    sign = "+" if value > 0 else ""
    color = "red" if value > 0 else "green"  # Higher cost = bad
    return f"[{color}]{sign}${value:.3f}[/{color}]"


def print_report(report: BenchmarkReport) -> None:
    """Print a multi-column comparison report to the terminal."""
    console.print()
    console.print("[bold]mdarena Benchmark Report[/bold]")
    console.print("=" * 60)
    console.print(f"Repository: [cyan]{report.repo}[/cyan]")
    console.print(f"Tasks: {report.num_tasks}")
    console.print()

    if not report.conditions:
        console.print("[yellow]No results to report.[/yellow]")
        return

    # Find baseline for delta computation
    baseline = next((c for c in report.conditions if c.condition_name == "baseline"), None)

    # Build comparison table
    table = Table(show_header=True, header_style="bold")
    table.add_column("Metric", style="dim")
    for cond in report.conditions:
        label = cond.condition_name
        if cond.context_file:
            label = (
                cond.context_file.split("/")[-1] if "/" in cond.context_file else cond.context_file
            )
        table.add_column(label, justify="right")

    # Resolution rate row
    row = ["Resolution rate"]
    for cond in report.conditions:
        row.append(_fmt_pct(cond.resolution_rate))
    table.add_row(*row)

    # Delta vs baseline row (if we have a baseline)
    if baseline and len(report.conditions) > 1:
        row = ["  vs baseline"]
        for cond in report.conditions:
            if cond.condition_name == "baseline":
                row.append("[dim]--[/dim]")
            else:
                delta = cond.resolution_rate - baseline.resolution_rate
                p_val = _get_p_value(report, baseline.condition_name, cond.condition_name)
                cell = _fmt_delta(delta)
                if p_val is not None and p_val < 0.05:
                    cell += "*"
                row.append(cell)
        table.add_row(*row)

    # Test resolution row (if any tasks had tests)
    any_tests = any(c.num_tasks_with_tests > 0 for c in report.conditions)
    if any_tests:
        row = ["Test resolution"]
        for cond in report.conditions:
            if cond.test_resolution_rate is not None:
                cell = _fmt_pct(cond.test_resolution_rate)
                cell += f" ({cond.num_tasks_with_tests} tasks)"
            else:
                cell = "[dim]n/a[/dim]"
            row.append(cell)
        table.add_row(*row)

    # File overlap row
    row = ["Avg file overlap"]
    for cond in report.conditions:
        row.append(f"{cond.avg_file_overlap:.2f}")
    table.add_row(*row)

    # Hunk overlap row
    row = ["Avg hunk overlap"]
    for cond in report.conditions:
        row.append(f"{cond.avg_hunk_overlap:.2f}")
    table.add_row(*row)

    # Cost row
    row = ["Avg cost/task"]
    for cond in report.conditions:
        row.append(f"${cond.avg_cost:.3f}")
    table.add_row(*row)

    # Cost delta row
    if baseline and len(report.conditions) > 1:
        row = ["  vs baseline"]
        for cond in report.conditions:
            if cond.condition_name == "baseline":
                row.append("[dim]--[/dim]")
            else:
                row.append(_fmt_delta_cost(cond.avg_cost - baseline.avg_cost))
        table.add_row(*row)

    # Tokens row
    row = ["Avg tokens/task"]
    for cond in report.conditions:
        row.append(f"{cond.avg_tokens:,.0f}")
    table.add_row(*row)

    console.print(table)

    # Footnotes
    if baseline:
        console.print("\n[dim]* = statistically significant (p < 0.05, paired t-test)[/dim]")
    if any_tests:
        console.print(
            "[dim]Resolution rate uses test pass/fail for tasks with tests, "
            "diff overlap (>50%) for tasks without.[/dim]"
        )

    # Verdict
    console.print()
    if report.winner and report.loser and report.winner != report.loser:
        winner_cond = next(c for c in report.conditions if c.condition_name == report.winner)
        loser_cond = next(c for c in report.conditions if c.condition_name == report.loser)

        if baseline:
            w_delta = winner_cond.resolution_rate - baseline.resolution_rate
            l_delta = loser_cond.resolution_rate - baseline.resolution_rate

            console.print(
                f"[bold green]Winner:[/bold green] "
                f"{report.winner} ({_fmt_delta(w_delta)} resolution)"
            )
            if loser_cond.condition_name != "baseline":
                console.print(
                    f"[bold red]Loser:[/bold red]  "
                    f"{report.loser} ({_fmt_delta(l_delta)} resolution)"
                )
        else:
            rate = _fmt_pct(winner_cond.resolution_rate)
            console.print(f"[bold green]Winner:[/bold green] {report.winner} ({rate} resolution)")

    console.print()


def _get_p_value(
    report: BenchmarkReport,
    baseline_name: str,
    condition_name: str,
) -> float | None:
    """Compute p-value between baseline and a condition from the report."""
    baseline_results = [r for r in report.eval_results if r.condition_name == baseline_name]
    condition_results = [r for r in report.eval_results if r.condition_name == condition_name]
    return compute_p_value(baseline_results, condition_results)
