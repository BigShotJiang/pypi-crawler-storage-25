"""Export benchmark results to JSON and CSV."""

from __future__ import annotations

import csv
from pathlib import Path

from mdarena.models import BenchmarkReport


def export_json(report: BenchmarkReport, output: Path) -> None:
    """Export the full report as JSON."""
    output.write_text(report.model_dump_json(indent=2))


def export_csv(report: BenchmarkReport, output: Path) -> None:
    """Export eval results as a CSV file."""
    with output.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(
            [
                "instance_id",
                "condition",
                "file_overlap",
                "hunk_overlap",
                "exact_match",
                "test_resolved",
                "tests_available",
                "cost_usd",
                "duration_ms",
                "tokens_total",
            ]
        )
        for r in report.eval_results:
            writer.writerow(
                [
                    r.instance_id,
                    r.condition_name,
                    r.file_overlap,
                    r.hunk_overlap,
                    r.exact_match,
                    r.test_resolved,
                    r.tests_available,
                    r.cost_usd,
                    r.duration_ms,
                    r.tokens_total,
                ]
            )
