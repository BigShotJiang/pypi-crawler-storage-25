"""Parse test runner output to extract individual test results.

Auto-detects the output format and extracts test names with pass/fail status.
Each parser returns None if the output doesn't match its expected format,
allowing fallthrough to the next parser.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass


@dataclass
class ParsedTest:
    name: str
    status: str  # "passed", "failed", "error", "skipped"


def parse_test_output(
    stdout: str,
    stderr: str,
    test_cmd: str,
) -> list[ParsedTest]:
    """Auto-detect output format and parse individual test results.

    Tries parsers in order, returns results from the first successful one.
    Falls back to a single whole-command result if nothing parses.
    """
    combined = stdout + "\n" + stderr

    # Try each parser
    for parser in [
        _parse_pytest_output,
        _parse_jest_json,
        _parse_go_test_json,
        _parse_cargo_test,
        _parse_junit_xml,
    ]:
        result = parser(combined)
        if result:
            return result

    return []


def _parse_pytest_output(output: str) -> list[ParsedTest] | None:
    """Parse pytest verbose output.

    Handles both standard and xdist formats:
      Standard: tests/test_auth.py::test_login PASSED
      xdist:    [gw0] PASSED tests/test_auth.py::test_login
    """
    status_map = {
        "PASSED": "passed",
        "FAILED": "failed",
        "ERROR": "error",
        "SKIPPED": "skipped",
    }

    # Standard format: path::test_name STATUS
    standard = re.compile(
        r"^([\w/\.\-]+::\S+)\s+(PASSED|FAILED|ERROR|SKIPPED)",
        re.MULTILINE,
    )
    # xdist format: [gwN] [ XX%] STATUS path::test_name
    xdist = re.compile(
        r"^\[gw\d+\]\s+\[.*?\]\s+(PASSED|FAILED|ERROR|SKIPPED)\s+([\w/\.\-]+::\S+)",
        re.MULTILINE,
    )
    # Summary section: STATUS path::test_name (no prefix)
    summary = re.compile(
        r"^(PASSED|FAILED|ERROR|SKIPPED)\s+([\w/\.\-]+::\S+)",
        re.MULTILINE,
    )

    # Try xdist first (more specific), then standard, then summary
    xdist_matches = xdist.findall(output)
    if xdist_matches:
        return [ParsedTest(name=name, status=status_map[s]) for s, name in xdist_matches]

    standard_matches = standard.findall(output)
    if standard_matches:
        return [ParsedTest(name=name, status=status_map[s]) for name, s in standard_matches]

    summary_matches = summary.findall(output)
    if summary_matches:
        return [ParsedTest(name=name, status=status_map[s]) for s, name in summary_matches]

    return None


def _parse_jest_json(output: str) -> list[ParsedTest] | None:
    """Parse jest --json output."""
    try:
        start = output.find('{"numFailedTestSuites"')
        if start == -1:
            start = output.find('{"numFailedTests"')
        if start == -1:
            return None

        data, _ = json.JSONDecoder().raw_decode(output, start)
    except (json.JSONDecodeError, ValueError):
        return None

    results: list[ParsedTest] = []
    for suite in data.get("testResults", []):
        for test in suite.get("assertionResults", []):
            name = test.get("fullName", test.get("title", "unknown"))
            status = test.get("status", "unknown")
            status_map = {"passed": "passed", "failed": "failed", "pending": "skipped"}
            results.append(ParsedTest(name=name, status=status_map.get(status, "error")))

    return results if results else None


def _parse_go_test_json(output: str) -> list[ParsedTest] | None:
    """Parse go test -json output (JSON lines)."""
    results: list[ParsedTest] = []
    found_json = False

    for line in output.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue

        if data.get("Action") in ("pass", "fail") and "Test" in data:
            found_json = True
            pkg = data.get("Package", "")
            test = data["Test"]
            name = f"{pkg}/{test}" if pkg else test
            status = "passed" if data["Action"] == "pass" else "failed"
            results.append(ParsedTest(name=name, status=status))

    return results if found_json else None


def _parse_cargo_test(output: str) -> list[ParsedTest] | None:
    """Parse cargo test output.

    Matches lines like:
      test tests::test_basic ... ok
      test tests::test_edge ... FAILED
    """
    pattern = re.compile(r"^test\s+(\S+)\s+\.\.\.\s+(ok|FAILED|ignored)", re.MULTILINE)
    matches = pattern.findall(output)
    if not matches:
        return None

    status_map = {"ok": "passed", "FAILED": "failed", "ignored": "skipped"}
    return [ParsedTest(name=name, status=status_map[s]) for name, s in matches]


def _parse_junit_xml(output: str) -> list[ParsedTest] | None:
    """Parse JUnit XML output (basic, no external dependency).

    Matches <testcase> elements with optional <failure> children.
    """
    if "<testcase" not in output:
        return None

    results: list[ParsedTest] = []

    # Simple regex-based XML parsing (no lxml dependency)
    testcase_pattern = re.compile(
        r'<testcase\s+[^>]*\bname="([^"]+)"[^>]*>(.*?)</testcase>',
        re.DOTALL,
    )
    for match in testcase_pattern.finditer(output):
        name = match.group(1)
        body = match.group(2)
        if "<failure" in body or "<error" in body:
            results.append(ParsedTest(name=name, status="failed"))
        elif "<skipped" in body:
            results.append(ParsedTest(name=name, status="skipped"))
        else:
            results.append(ParsedTest(name=name, status="passed"))

    # Also handle self-closing testcases (no failure = passed)
    selfclose_pattern = re.compile(r'<testcase\s+[^>]*?\bname="([^"]+)"[^>]*/>', re.DOTALL)
    for match in selfclose_pattern.finditer(output):
        name = match.group(1)
        results.append(ParsedTest(name=name, status="passed"))

    return results if results else None
