"""Auto-detect test commands for a repository."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from rich.console import Console

from mdarena.config import DEFAULT_TEST_TIMEOUT

console = Console()


@dataclass
class TestConfig:
    """Discovered test configuration for a repository."""

    test_cmd: str
    setup_cmd: str | None = None
    source: Literal["user", "ci", "package", "unknown"] = "unknown"
    confidence: float = 0.0
    env_vars: dict[str, str] = field(default_factory=dict)
    timeout: int = DEFAULT_TEST_TIMEOUT
    work_dir: str | None = None  # Subdirectory to run tests in (relative to repo root)


def _load_env_file(env_file: Path) -> dict[str, str]:
    """Parse a .env file (KEY=VALUE lines)."""
    env_vars: dict[str, str] = {}
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            env_vars[key.strip()] = value.strip().strip("\"'")
    return env_vars


def detect_test_config(
    repo_path: Path,
    user_test_cmd: str | None = None,
    user_setup_cmd: str | None = None,
    env_file: Path | None = None,
    scope_path: str | None = None,
) -> TestConfig | None:
    """Detect test configuration for a repository.

    Priority:
    1. User-provided --test-cmd (highest confidence)
    2. CI/CD files (.github/workflows/*.yml, Makefile), scoped by scope_path
    3. Package files in the scoped subdirectory first, then repo root

    When scope_path is set (e.g. "ui/app-ui"), package detection looks in
    that subdirectory first, and CI detection boosts workflows that match
    the scope.

    Returns None if no test command can be discovered.
    """
    env_vars = _load_env_file(env_file) if env_file else {}

    # Tier 0: User override
    if user_test_cmd:
        return TestConfig(
            test_cmd=user_test_cmd,
            setup_cmd=user_setup_cmd,
            source="user",
            confidence=1.0,
            env_vars=env_vars,
        )

    # Tier 1: CI/CD files (scope_hint helps rank relevant workflows)
    from mdarena.discovery.ci_parser import detect_from_ci

    ci_configs = detect_from_ci(repo_path, scope_hint=scope_path)
    for config in ci_configs:
        # Skip low-confidence CI results, let package parser try instead
        if config.confidence < 0.5:
            continue
        config.env_vars.update(env_vars)
        if scope_path:
            config.work_dir = scope_path
        console.print(f"  [dim]Detected from CI ({config.confidence:.0%}): {config.test_cmd}[/dim]")
        return config

    # Tier 2: Package files, try scoped subdirectory first
    from mdarena.discovery.package_parser import detect_from_packages

    if scope_path:
        scoped_dir = repo_path / scope_path
        if scoped_dir.is_dir():
            pkg_configs = detect_from_packages(scoped_dir)
            for config in pkg_configs:
                config.env_vars.update(env_vars)
                config.work_dir = scope_path
                console.print(
                    f"  [dim]Detected from packages in {scope_path}/ "
                    f"({config.confidence:.0%}): {config.test_cmd}[/dim]"
                )
                return config

    # Fallback: repo root
    pkg_configs = detect_from_packages(repo_path)
    for config in pkg_configs:
        config.env_vars.update(env_vars)
        console.print(
            f"  [dim]Detected from packages ({config.confidence:.0%}): {config.test_cmd}[/dim]"
        )
        return config

    return None
