"""Extract test commands from CI/CD configuration files.

Reads actual commands from the repo's CI -- never hardcodes framework-specific
commands like 'pytest' or 'npm test'.
"""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from mdarena.discovery.detect import TestConfig

# Step names that indicate test execution
TEST_STEP_KEYWORDS = {"test", "tests", "check", "verify", "ci", "lint", "spec"}


def detect_from_ci(
    repo_path: Path,
    scope_hint: str | None = None,
) -> list[TestConfig]:
    """Parse CI/CD files and extract test commands.

    When scope_hint is provided (e.g. "ui/app-ui" or "backend"),
    configs whose test_cmd or workflow filename contains any component
    of the hint are boosted in confidence. This helps pick the right
    test framework in monorepos.
    """
    configs: list[TestConfig] = []

    # GitHub Actions (highest signal)
    workflows_dir = repo_path / ".github" / "workflows"
    if workflows_dir.is_dir():
        for yml_file in workflows_dir.glob("*.yml"):
            configs.extend(_parse_github_actions(yml_file, scope_hint=scope_hint))
        for yml_file in workflows_dir.glob("*.yaml"):
            configs.extend(_parse_github_actions(yml_file, scope_hint=scope_hint))

    # Makefile
    makefile = repo_path / "Makefile"
    if not makefile.exists():
        makefile = repo_path / "makefile"
    if makefile.exists():
        configs.extend(_parse_makefile(makefile))

    # Sort by confidence descending
    configs.sort(key=lambda c: c.confidence, reverse=True)
    return configs


def _matches_scope(text: str, scope_hint: str) -> bool:
    """Check if text references the scope (any path component matches)."""
    text_lower = text.lower()
    return any(part.lower() in text_lower for part in scope_hint.strip("/").split("/"))


def _parse_github_actions(
    yml_path: Path,
    scope_hint: str | None = None,
) -> list[TestConfig]:
    """Extract test commands from a GitHub Actions workflow."""
    configs: list[TestConfig] = []

    try:
        data = yaml.safe_load(yml_path.read_text())
    except (OSError, yaml.YAMLError):
        return configs

    if not isinstance(data, dict):
        return configs

    jobs = data.get("jobs", {})
    if not isinstance(jobs, dict):
        return configs

    for _job_name, job in jobs.items():
        if not isinstance(job, dict):
            continue

        steps = job.get("steps", [])
        if not isinstance(steps, list):
            continue

        setup_cmds: list[str] = []
        test_cmds: list[str] = []

        for step in steps:
            if not isinstance(step, dict):
                continue

            run_cmd = step.get("run", "")
            if not run_cmd or not isinstance(run_cmd, str):
                continue

            step_name = str(step.get("name", "")).lower()

            is_test_step = any(kw in step_name for kw in TEST_STEP_KEYWORDS) or any(
                kw in run_cmd.lower()
                for kw in ("pytest", "jest", "vitest", "cargo test", "go test", "rspec")
            )

            if is_test_step:
                # Multi-line run: last command is the test, earlier are setup
                lines = [
                    ln.strip()
                    for ln in run_cmd.strip().splitlines()
                    if ln.strip() and not ln.strip().startswith("#")
                ]
                if len(lines) > 1:
                    setup_cmds.extend(lines[:-1])
                    test_cmds.append(lines[-1])
                elif lines:
                    test_cmds.append(lines[0])
            elif "install" in run_cmd.lower() or "setup" in run_cmd.lower():
                for ln in run_cmd.strip().splitlines():
                    ln = ln.strip()
                    if ln and not ln.startswith("#"):
                        setup_cmds.append(ln)

        # Filter setup commands that contain GitHub Actions template variables
        local_setup = [c for c in setup_cmds if "${{" not in c]

        for cmd in test_cmds:
            # Skip commands with unresolvable GitHub Actions template variables
            if "${{" in cmd:
                continue

            confidence = 0.8
            # Boost confidence when the workflow filename or command matches the scope
            if scope_hint:
                matches = _matches_scope(yml_path.stem, scope_hint) or _matches_scope(
                    cmd, scope_hint
                )
                confidence = 0.95 if matches else 0.3
            configs.append(
                TestConfig(
                    test_cmd=cmd,
                    setup_cmd=" && ".join(local_setup) if local_setup else None,
                    source="ci",
                    confidence=confidence,
                )
            )

    return configs


def _parse_makefile(makefile_path: Path) -> list[TestConfig]:
    """Extract test targets from a Makefile."""
    configs: list[TestConfig] = []

    try:
        content = makefile_path.read_text()
    except OSError:
        return configs

    # Find targets named test, check, ci
    target_pattern = re.compile(r"^(test|check|ci|test-unit|test-all)\s*:", re.MULTILINE)

    for match in target_pattern.finditer(content):
        target_name = match.group(1)
        configs.append(
            TestConfig(
                test_cmd=f"make {target_name}",
                source="ci",
                confidence=0.7,
            )
        )

    return configs
