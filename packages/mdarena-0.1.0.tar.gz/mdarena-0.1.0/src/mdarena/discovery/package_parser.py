"""Extract test commands from package manifest files.

Reads actual test configurations from the repo's package/build files.
"""

from __future__ import annotations

import json
import tomllib
from pathlib import Path

from mdarena.discovery.detect import TestConfig


def detect_from_packages(repo_path: Path) -> list[TestConfig]:
    """Extract test commands from package files."""
    configs: list[TestConfig] = []

    # package.json (JS/TS)
    pkg_json = repo_path / "package.json"
    if pkg_json.exists():
        configs.extend(_parse_package_json(repo_path, pkg_json))

    # pyproject.toml (Python)
    pyproject = repo_path / "pyproject.toml"
    if pyproject.exists():
        configs.extend(_parse_pyproject_toml(pyproject))

    # Cargo.toml (Rust)
    cargo = repo_path / "Cargo.toml"
    if cargo.exists():
        configs.append(TestConfig(test_cmd="cargo test", source="package", confidence=0.6))

    # go.mod (Go)
    gomod = repo_path / "go.mod"
    if gomod.exists():
        configs.append(TestConfig(test_cmd="go test ./...", source="package", confidence=0.6))

    # Gemfile (Ruby)
    gemfile = repo_path / "Gemfile"
    if gemfile.exists():
        rakefile = repo_path / "Rakefile"
        if rakefile.exists():
            configs.append(
                TestConfig(
                    test_cmd="bundle exec rake test",
                    setup_cmd="bundle install",
                    source="package",
                    confidence=0.5,
                )
            )

    configs.sort(key=lambda c: c.confidence, reverse=True)
    return configs


def _parse_package_json(repo_path: Path, pkg_json: Path) -> list[TestConfig]:
    """Extract test command from package.json scripts."""
    configs: list[TestConfig] = []

    try:
        data = json.loads(pkg_json.read_text())
    except (OSError, json.JSONDecodeError, KeyError):
        return configs

    scripts = data.get("scripts", {})
    if not isinstance(scripts, dict):
        return configs

    # Detect package manager
    if (repo_path / "pnpm-lock.yaml").exists():
        runner = "pnpm"
    elif (repo_path / "yarn.lock").exists():
        runner = "yarn"
    elif (repo_path / "bun.lockb").exists() or (repo_path / "bun.lock").exists():
        runner = "bun"
    else:
        runner = "npm"

    # Look for test scripts (skip npm's default stub)
    npm_default = 'echo "Error: no test specified" && exit 1'
    for script_name in ("test", "test:unit", "test:ci", "check"):
        cmd = scripts.get(script_name, "")
        if cmd and cmd != npm_default:
            install_cmd = f"{runner} install"
            configs.append(
                TestConfig(
                    test_cmd=f"{runner} run {script_name}",
                    setup_cmd=install_cmd,
                    source="package",
                    confidence=0.6,
                )
            )
            break  # Take the first valid one

    return configs


def _parse_pyproject_toml(pyproject: Path) -> list[TestConfig]:
    """Extract test configuration from pyproject.toml."""
    configs: list[TestConfig] = []

    try:
        data = tomllib.loads(pyproject.read_text())
    except (OSError, tomllib.TOMLDecodeError):
        return configs

    tool = data.get("tool", {})
    repo_dir = pyproject.parent

    # Detect if this is a uv-managed project (uv.lock present)
    uses_uv = (repo_dir / "uv.lock").exists()
    runner = "uv run " if uses_uv else ""
    setup = "uv sync" if uses_uv else "pip install -e ."

    # pytest configured
    if "pytest" in tool:
        configs.append(
            TestConfig(
                test_cmd=f"{runner}pytest -n 4 --timeout=60 -v --tb=line",
                setup_cmd=setup,
                source="package",
                confidence=0.6,
            )
        )

    # hatch test scripts
    hatch_envs = tool.get("hatch", {}).get("envs", {})
    for _env_name, env_config in hatch_envs.items():
        if isinstance(env_config, dict):
            env_scripts = env_config.get("scripts", {})
            if isinstance(env_scripts, dict) and "test" in env_scripts:
                cmd = env_scripts["test"]
                if isinstance(cmd, str):
                    configs.append(
                        TestConfig(
                            test_cmd=cmd,
                            setup_cmd=setup,
                            source="package",
                            confidence=0.5,
                        )
                    )

    return configs
