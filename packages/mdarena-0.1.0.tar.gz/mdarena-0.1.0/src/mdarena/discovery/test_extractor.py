"""Extract FAIL_TO_PASS and PASS_TO_PASS test lists for a PR.

Runs the test suite at base_commit (before fix) and merge_commit (after fix),
then diffs the results to find which tests flipped from fail to pass.
"""

from __future__ import annotations

import contextlib
import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console

from mdarena.discovery.detect import TestConfig
from mdarena.discovery.output_parsers import parse_test_output

console = Console()


@dataclass
class TestResults:
    """Results from a single test suite run."""

    passed: set[str] = field(default_factory=set)
    failed: set[str] = field(default_factory=set)
    errored: set[str] = field(default_factory=set)
    exit_code: int = -1
    timed_out: bool = False


@dataclass
class TestLists:
    """FAIL_TO_PASS and PASS_TO_PASS lists for a single PR."""

    fail_to_pass: list[str] = field(default_factory=list)
    pass_to_pass: list[str] = field(default_factory=list)
    error: str | None = None


def run_tests(
    repo_path: Path,
    config: TestConfig,
) -> TestResults:
    """Run the test suite and parse individual test results."""
    env = {**os.environ, **config.env_vars}
    results = TestResults()

    # Use work_dir if specified (for monorepo subdirectory scoping)
    cwd = repo_path / config.work_dir if config.work_dir else repo_path

    if config.setup_cmd:
        with contextlib.suppress(subprocess.TimeoutExpired, subprocess.SubprocessError, OSError):
            subprocess.run(
                config.setup_cmd,
                shell=True,
                cwd=cwd,
                capture_output=True,
                timeout=config.timeout,
                env=env,
            )

    try:
        proc = subprocess.run(
            config.test_cmd,
            shell=True,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=config.timeout,
            env=env,
        )
        results.exit_code = proc.returncode
    except subprocess.TimeoutExpired:
        results.timed_out = True
        return results
    except (subprocess.SubprocessError, OSError) as e:
        results.errored.add(f"__runner_error__: {e}")
        return results

    parsed = parse_test_output(proc.stdout, proc.stderr, config.test_cmd)
    for test in parsed:
        if test.status == "passed":
            results.passed.add(test.name)
        elif test.status == "failed":
            results.failed.add(test.name)
        elif test.status == "error":
            results.errored.add(test.name)

    if not parsed and not results.timed_out:
        if results.exit_code == 0:
            results.passed.add("__suite__")
        else:
            results.failed.add("__suite__")

    return results


def extract_test_lists(
    repo_path: Path,
    base_commit: str,
    merge_commit: str,
    config: TestConfig,
) -> TestLists:
    """Extract FAIL_TO_PASS and PASS_TO_PASS by running tests at two commits.

    Uses temporary worktrees instead of checking out on the shared cache,
    so this is safe to call concurrently for different tasks.

    1. Worktree at base_commit, run tests -> pre_results
    2. Worktree at merge_commit, run tests -> post_results
    3. FAIL_TO_PASS = pre_results.failed ∩ post_results.passed
    4. PASS_TO_PASS = pre_results.passed ∩ post_results.passed
    """
    from mdarena.utils.git import create_isolated_checkout, remove_checkout

    try:
        base_wt = create_isolated_checkout(repo_path, base_commit)
    except (RuntimeError, subprocess.SubprocessError) as e:
        return TestLists(error=f"Failed to create base checkout: {e}")

    try:
        pre_results = run_tests(base_wt, config)
    finally:
        remove_checkout(base_wt)

    try:
        merge_wt = create_isolated_checkout(repo_path, merge_commit)
    except (RuntimeError, subprocess.SubprocessError) as e:
        return TestLists(error=f"Failed to create merge checkout: {e}")

    try:
        post_results = run_tests(merge_wt, config)
    finally:
        remove_checkout(merge_wt)

    if pre_results.timed_out or post_results.timed_out:
        return TestLists(error="Test suite timed out")

    fail_to_pass = sorted(pre_results.failed & post_results.passed)
    pass_to_pass = sorted(pre_results.passed & post_results.passed)

    # Cap PASS_TO_PASS to avoid huge lists
    from mdarena.config import MAX_PASS_TO_PASS

    if len(pass_to_pass) > MAX_PASS_TO_PASS:
        console.print(
            f"  [yellow]Truncating PASS_TO_PASS: {len(pass_to_pass)} -> {MAX_PASS_TO_PASS}[/yellow]"
        )
        pass_to_pass = pass_to_pass[:MAX_PASS_TO_PASS]

    return TestLists(
        fail_to_pass=fail_to_pass,
        pass_to_pass=pass_to_pass,
    )
