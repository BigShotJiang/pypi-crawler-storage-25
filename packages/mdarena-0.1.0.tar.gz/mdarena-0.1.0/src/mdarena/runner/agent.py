"""Drive the Claude CLI for a single benchmark task.

Matches the SWE-bench evaluation pattern used by claudecode_swebench and
Anthropic's own SWE-bench harness:
  - Prompt piped via stdin (interactive mode with tool use)
  - Claude edits files directly in the repo using bash/edit tools
  - Patch extracted via git diff HEAD after the run
  - Baseline uses --bare (no CLAUDE.md discovery)
  - Context condition lets Claude auto-discover CLAUDE.md in the repo
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
import time
from pathlib import Path

from mdarena.config import DEFAULT_BUDGET_PER_TASK, DEFAULT_MODEL
from mdarena.models import AgentRun, RunCondition
from mdarena.utils.git import get_diff

# Binaries that let the agent fetch the gold patch from a hosting provider
# in a single command. These are replaced with stubs on the agent's PATH
# (rather than removing their PATH entries, which would break legitimate
# tools installed in the same directory).
_BLOCKED_BINARIES = ("gh", "glab", "hub")

# Environment variables that authenticate git/HTTP access to code hosts.
# Removed from the agent's env so `git fetch`, `curl api.github.com`, and
# any gh replacement the agent might find all come up unauthenticated.
_BLOCKED_ENV_VARS = (
    "GH_TOKEN",
    "GITHUB_TOKEN",
    "GH_HOST",
    "GH_CONFIG_DIR",
    "GH_ENTERPRISE_TOKEN",
    "GITHUB_API_URL",
    "GITLAB_TOKEN",
    "GITLAB_HOST",
)

_STUB_SCRIPT = """#!/bin/sh
echo "mdarena: $(basename "$0") is disabled during benchmarks to prevent leaking PR metadata" >&2
exit 127
"""

_shim_dir: Path | None = None


def _get_shim_dir() -> Path:
    """Return a cached temp directory containing stubs for blocked binaries.

    The stubs exit 127 with an explanatory message. Prepending this directory
    to PATH causes `gh`, `glab`, and `hub` to resolve to the stubs before the
    real binaries, without removing the real binaries' directory from PATH
    (which would break other legitimate tools installed alongside them).
    """
    global _shim_dir
    if _shim_dir is None or not _shim_dir.exists():
        _shim_dir = Path(tempfile.mkdtemp(prefix="mdarena-shims-"))
        for binary in _BLOCKED_BINARIES:
            stub = _shim_dir / binary
            stub.write_text(_STUB_SCRIPT)
            stub.chmod(0o755)
    return _shim_dir


def _sanitize_env(extra: dict[str, str] | None = None) -> dict[str, str]:
    """Build the agent subprocess environment with integrity protections.

    1. Strips GH_TOKEN / GITHUB_TOKEN / related credentials so any
       `git fetch`, `curl`, or gh replacement the agent tries is
       unauthenticated against GitHub / GitLab.
    2. Prepends a shim dir with stub executables for `gh`, `glab`, `hub`
       so those commands fail with an explanatory error before touching
       the real binary (if one exists on the host).

    This is the *OS layer* of defense. The history-free checkout
    (utils/git.py) is the git layer. Together they close the main
    cheating vectors against a PR-replay benchmark.
    """
    env = {**os.environ, **(extra or {})}

    for var in _BLOCKED_ENV_VARS:
        env.pop(var, None)

    shim = _get_shim_dir()
    env["PATH"] = f"{shim}{os.pathsep}{env.get('PATH', '')}"

    return env


# Matches Anthropic's SWE-bench prompt structure:
# - Tells Claude the repo is at a specific location
# - Provides the issue/PR description
# - Guides: explore -> reproduce -> fix -> verify
# - Tells Claude not to modify tests
PROMPT_TEMPLATE = """\
I've uploaded a code repository in the directory {repo_path}. \
Consider the following issue description:

<issue_description>
{problem_statement}
</issue_description>

Can you help me implement the necessary changes to the repository \
so that the requirements specified in the <issue_description> are met?

Your task is to make the minimal changes to non-test files in the \
{repo_path} directory to resolve the issue.

Follow these steps to resolve the issue:
1. As a first step, explore the repo to familiarize yourself with its structure.
2. Create a script to reproduce the error and execute it to confirm the error.
3. Edit the source code of the repo to resolve the issue.
4. Rerun your reproduce script and confirm that the error is fixed.
5. Think about edge cases and make sure your fix handles them as well.
"""


def _build_prompt(
    problem_statement: str,
    repo_path: Path,
) -> str:
    return PROMPT_TEMPLATE.format(
        repo_path=str(repo_path),
        problem_statement=problem_statement,
    )


def run_agent(
    instance_id: str,
    condition: RunCondition,
    problem_statement: str,
    repo: str,
    worktree_path: Path,
    budget: float = DEFAULT_BUDGET_PER_TASK,
    model: str = DEFAULT_MODEL,
    api_key: str | None = None,
) -> AgentRun:
    """Run Claude Code on a task in interactive mode (matching SWE-bench harness).

    For baseline (no context): uses --bare to prevent CLAUDE.md discovery.
    For context conditions: no --bare, CLAUDE.md is placed in the repo by
    the sandbox so Claude auto-discovers it (tests the real developer experience).
    """
    prompt = _build_prompt(problem_statement, worktree_path)

    cmd = ["claude", "--dangerously-skip-permissions"]

    # Only load project-level settings (CLAUDE.md in the worktree), never
    # user-level (~/.claude/CLAUDE.md). This ensures:
    #   - Baseline: no ambient context (sandbox stripped all CLAUDE.md)
    #   - Context: only the injected CLAUDE.md is discovered
    # We can't use --bare because it also strips OAuth auth.
    cmd.extend(["--setting-sources", "project"])

    cmd.extend(["--max-budget-usd", str(budget)])
    cmd.extend(["--model", model])

    extra_env = {"ANTHROPIC_API_KEY": api_key} if api_key else None
    env = _sanitize_env(extra_env)

    start_time = time.time()

    try:
        result = subprocess.run(
            cmd,
            input=prompt,
            capture_output=True,
            text=True,
            cwd=worktree_path,
            timeout=1800,  # 30 min timeout (Opus on large repos needs room)
            env=env,
        )

        duration_ms = int((time.time() - start_time) * 1000)

        # Extract the patch from actual file changes (not from stdout)
        patch = get_diff(worktree_path)

        # Try to parse cost/usage from Claude's stderr or output
        usage = _parse_usage(result.stderr + "\n" + result.stdout)

        # Capture error from stderr; if empty, include stdout tail for diagnosis
        error_msg = None
        if result.returncode != 0:
            error_msg = result.stderr[:500] if result.stderr.strip() else result.stdout[-500:]

        return AgentRun(
            instance_id=instance_id,
            condition_name=condition.name,
            patch_produced=patch if patch.strip() else None,
            exit_reason="success" if result.returncode == 0 else "error",
            cost_usd=usage.get("cost_usd", 0.0),
            duration_ms=duration_ms,
            input_tokens=usage.get("input_tokens", 0),
            output_tokens=usage.get("output_tokens", 0),
            model=model,
            session_id=usage.get("session_id", ""),
            error=error_msg,
        )

    except subprocess.TimeoutExpired:
        duration_ms = int((time.time() - start_time) * 1000)
        # Still capture any changes made before timeout
        try:
            patch = get_diff(worktree_path)
        except (RuntimeError, subprocess.SubprocessError):
            patch = ""
        return AgentRun(
            instance_id=instance_id,
            condition_name=condition.name,
            patch_produced=patch if patch.strip() else None,
            exit_reason="timeout",
            duration_ms=duration_ms,
        )

    except (subprocess.SubprocessError, OSError) as e:
        duration_ms = int((time.time() - start_time) * 1000)
        return AgentRun(
            instance_id=instance_id,
            condition_name=condition.name,
            exit_reason="error",
            error=str(e),
            duration_ms=duration_ms,
        )


def _parse_usage(output: str) -> dict:
    """Best-effort extraction of cost/usage from Claude CLI output.

    Claude Code may print usage info to stderr. Format varies by version,
    so we try multiple patterns.
    """
    usage: dict = {}

    for line in output.split("\n"):
        line = line.strip()
        if not line:
            continue
        if line.startswith("{") and "cost" in line.lower():
            try:
                data = json.loads(line)
                if "total_cost_usd" in data:
                    usage["cost_usd"] = float(data["total_cost_usd"])
                elif "cost_usd" in data:
                    usage["cost_usd"] = float(data["cost_usd"])
                if "session_id" in data:
                    usage["session_id"] = data["session_id"]
                u = data.get("usage", {})
                if "input_tokens" in u:
                    usage["input_tokens"] = u["input_tokens"]
                if "output_tokens" in u:
                    usage["output_tokens"] = u["output_tokens"]
            except (json.JSONDecodeError, ValueError):
                pass

    if "cost_usd" not in usage:
        _COST_KEYWORDS = re.compile(r"(?:cost|total|spent|budget|usage)", re.IGNORECASE)
        for line in output.split("\n"):
            if _COST_KEYWORDS.search(line):
                cost_match = re.search(r"\$(\d+\.\d{2,})", line)
                if cost_match:
                    usage["cost_usd"] = float(cost_match.group(1))
                    break

    return usage
