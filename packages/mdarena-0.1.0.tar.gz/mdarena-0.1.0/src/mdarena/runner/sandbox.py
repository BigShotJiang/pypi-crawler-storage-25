"""Git worktree sandbox for isolated agent runs.

Handles both single-file and directory-based CLAUDE.md configurations.
Claude Code discovers CLAUDE.md at multiple levels:
  - repo/CLAUDE.md (project root)
  - repo/subdir/CLAUDE.md (directory-level, loaded when Claude explores that dir)

For baseline: removes ALL CLAUDE.md/AGENTS.md files throughout the repo tree.
For context (single file): removes existing, places one CLAUDE.md at root.
For context (directory): removes existing, copies the directory tree into the repo,
  preserving paths so e.g. configs/packages/api/CLAUDE.md -> packages/api/CLAUDE.md.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from mdarena.models import RunCondition
from mdarena.utils.git import clone_repo, create_isolated_checkout, remove_checkout

# Filenames that Claude Code auto-discovers as context
CONTEXT_FILENAMES = {"CLAUDE.md", "AGENTS.md"}


class Sandbox:
    """Manages an isolated worktree for a single agent run."""

    def __init__(
        self,
        repo: str,
        base_commit: str,
        condition: RunCondition,
        path_filter: str | None = None,
    ):
        self.repo = repo
        self.base_commit = base_commit
        self.condition = condition
        self.path_filter = path_filter
        self._repo_path: Path | None = None
        self._worktree: Path | None = None

    def setup(self) -> Path:
        """Clone repo (if needed) and create an isolated checkout at base_commit.

        Uses a history-free checkout (see create_isolated_checkout) so the
        agent cannot inspect future commits, tags, or remotes to find the
        gold patch. The returned directory is a fresh single-commit git repo.
        Future history literally does not exist in its object database.

        Always does a full checkout. path_filter is only for PR
        selection and scoring, not for restricting the agent's access.
        The agent needs the full repo to navigate, understand context,
        and modify files outside the scoped directory if needed.

        Returns the worktree path.
        """
        self._repo_path = clone_repo(self.repo)

        self._worktree = create_isolated_checkout(
            self._repo_path,
            self.base_commit,
        )

        # NOTE: .env files are NOT copied into the agent worktree to avoid
        # exposing credentials to the LLM. Tests run in separate clean
        # worktrees (see orchestrator._test_in_clean_worktree) which handle
        # .env copying independently.

        # Always remove existing context files first
        self._remove_all_context_files()

        # Place context files if this isn't a baseline run
        if self.condition.context_file is not None:
            self._inject_context(self.condition.context_file)

        # Checkpoint: commit sandbox changes so get_diff only captures agent work
        self._checkpoint()

        return self._worktree

    def _remove_all_context_files(self) -> None:
        """Remove ALL CLAUDE.md and AGENTS.md files throughout the worktree.

        Uses git ls-files for speed, avoids traversing node_modules, .next,
        and other heavy directories that rglob would walk through.
        """
        if not self._worktree:
            return

        # Fast path: ask git for tracked context files
        result = subprocess.run(
            ["git", "ls-files", *CONTEXT_FILENAMES],
            capture_output=True,
            text=True,
            cwd=self._worktree,
            check=False,
            timeout=30,
        )
        for rel_path in result.stdout.splitlines():
            rel_path = rel_path.strip()
            if rel_path:
                p = self._worktree / rel_path
                if p.is_file() or p.is_symlink():
                    p.unlink()

        # Also remove any untracked context files at root (e.g. from prior injection)
        for name in CONTEXT_FILENAMES:
            p = self._worktree / name
            if p.is_file() or p.is_symlink():
                p.unlink()

        # Also remove .claude/settings.json if present
        settings = self._worktree / ".claude" / "settings.json"
        if settings.is_symlink() or settings.is_file():
            settings.unlink()

    def _inject_context(self, source: Path) -> None:
        """Inject context file(s) into the worktree.

        If source is a file: place it as CLAUDE.md at the worktree root.
        If source is a directory: copy its tree into the worktree, preserving
        relative paths. E.g.:
          source/CLAUDE.md            -> worktree/CLAUDE.md
          source/packages/api/CLAUDE.md -> worktree/packages/api/CLAUDE.md
        """
        if not self._worktree:
            return

        if source.is_file():
            dest = self._worktree / "CLAUDE.md"
            shutil.copy2(source, dest)
        elif source.is_dir():
            for src_file in source.rglob("*"):
                if src_file.is_symlink() or not src_file.is_file():
                    continue
                rel = src_file.relative_to(source)
                dest = self._worktree / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_file, dest)

    def _checkpoint(self) -> None:
        """Commit sandbox file changes so they don't pollute the agent's diff.

        After stripping/injecting context files, those changes show up in
        git diff HEAD. Committing them resets HEAD so get_diff only captures
        the agent's actual work.
        """
        if not self._worktree:
            return
        subprocess.run(
            ["git", "add", "-A"],
            cwd=self._worktree,
            capture_output=True,
            check=False,
            timeout=30,
        )
        subprocess.run(
            ["git", "commit", "-m", "mdarena: sandbox setup", "--allow-empty", "--no-verify"],
            cwd=self._worktree,
            capture_output=True,
            check=False,
            timeout=30,
        )

    def cleanup(self) -> None:
        """Remove the checkout directory."""
        if self._worktree:
            remove_checkout(self._worktree)

    @property
    def worktree_path(self) -> Path | None:
        return self._worktree
