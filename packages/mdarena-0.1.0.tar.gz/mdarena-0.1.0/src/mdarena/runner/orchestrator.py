"""Orchestrate benchmark runs across tasks and conditions."""

from __future__ import annotations

import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from rich.console import Console
from rich.progress import Progress

from mdarena.config import DEFAULT_MODEL, DEFAULT_PARALLEL
from mdarena.evaluation.test_runner import TestVerdict
from mdarena.models import AgentRun, RunCondition, SwebenchPrediction, TaskInstance
from mdarena.runner.agent import run_agent
from mdarena.runner.sandbox import Sandbox

console = Console()


def build_conditions(
    context_files: list[Path],
    include_baseline: bool = True,
) -> list[RunCondition]:
    """Build the list of conditions to benchmark."""
    conditions = []
    if include_baseline:
        conditions.append(RunCondition.baseline())
    for f in context_files:
        conditions.append(RunCondition.from_file(f))
    return conditions


def _result_path(output_dir: Path, instance_id: str, condition_name: str) -> Path:
    return output_dir / "runs" / f"{instance_id}__{condition_name}.json"


def _result_exists(output_dir: Path, instance_id: str, condition_name: str) -> bool:
    return _result_path(output_dir, instance_id, condition_name).exists()


def _copy_env_files(repo_path: Path, worktree: Path, path_filter: str | None) -> None:
    """Copy .env files from cached repo into a worktree."""
    subdirs = [""]
    if path_filter:
        subdirs.append(path_filter)

    for subdir in subdirs:
        target_env = worktree / subdir / ".env"
        if target_env.exists():
            continue
        local_env = repo_path / subdir / ".env"
        if local_env.is_file():
            shutil.copy2(local_env, target_env)
            continue
        test_ci_env = worktree / subdir / ".env.test-ci"
        if test_ci_env.is_file():
            shutil.copy2(test_ci_env, target_env)


def _copy_venv(repo_path: Path, worktree: Path, path_filter: str | None) -> None:
    """Copy a cached .venv into the worktree instead of running uv sync from scratch.

    Looks for a .venv in the cached repo clone (built by a previous uv sync).
    Falls back gracefully, the setup_cmd will create one if no cache exists.
    """
    subdirs = [path_filter] if path_filter else [""]

    for subdir in subdirs:
        target_venv = worktree / subdir / ".venv"
        if target_venv.exists():
            continue
        source_venv = repo_path / subdir / ".venv"
        if source_venv.is_dir():
            shutil.copytree(source_venv, target_venv, symlinks=True)


def _copy_node_modules(repo_path: Path, worktree: Path, path_filter: str | None) -> None:
    """Copy cached node_modules into the worktree for JS/TS test suites.

    Handles pnpm monorepos: copies the root node_modules (which contains the
    pnpm virtual store) and any workspace-level node_modules directories that
    appear within the path_filter scope or its parent workspaces.
    """
    # Always copy root node_modules (contains pnpm virtual store)
    root_nm = repo_path / "node_modules"
    target_root_nm = worktree / "node_modules"
    if root_nm.is_dir() and not target_root_nm.exists():
        shutil.copytree(root_nm, target_root_nm, symlinks=True)

    # For monorepos, also copy node_modules for each workspace directory
    # between the root and the path_filter target.
    if path_filter:
        parts = Path(path_filter).parts
        for i in range(1, len(parts) + 1):
            subdir = str(Path(*parts[:i]))
            source_nm = repo_path / subdir / "node_modules"
            target_nm = worktree / subdir / "node_modules"
            if source_nm.is_dir() and not target_nm.exists():
                shutil.copytree(source_nm, target_nm, symlinks=True)


def _test_in_clean_worktree(
    repo_path: Path,
    task: TaskInstance,
    agent_patch: str,
    test_timeout: int,
    path_filter: str | None,
    api_key: str | None = None,
    utility_model: str | None = None,
) -> TestVerdict:
    """Run tests in a fresh worktree with only the agent's patch applied.

    This avoids environment contamination from the agent's exploration.
    The agent runs uv/pip commands, installs packages, and otherwise
    dirties its worktree, testing there produces spurious failures.

    Instead we:
    1. Create a clean worktree at the same base commit
    2. Copy cached .venv (skip expensive uv sync if possible)
    3. Copy .env files for test infrastructure
    4. Apply the agent's patch via git apply
    5. Run targeted tests (only files related to the patch)
    """
    from mdarena.evaluation.test_runner import verify_patch
    from mdarena.utils.git import create_isolated_checkout, remove_checkout

    test_wt = create_isolated_checkout(repo_path, task.base_commit)
    try:
        _copy_env_files(repo_path, test_wt, path_filter)
        _copy_venv(repo_path, test_wt, path_filter)
        _copy_node_modules(repo_path, test_wt, path_filter)

        # Apply the agent's patch
        try:
            subprocess.run(
                ["git", "apply", "--allow-empty", "-"],
                input=agent_patch,
                capture_output=True,
                text=True,
                cwd=test_wt,
                check=True,
                timeout=30,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
            return TestVerdict(
                tests_ran=True,
                resolved=False,
                error=f"Failed to apply patch: {e}",
            )

        return verify_patch(
            worktree_path=test_wt,
            task=task,
            timeout=test_timeout,
            agent_patch=agent_patch,
            api_key=api_key,
            utility_model=utility_model,
        )
    finally:
        remove_checkout(test_wt)


def _run_single(
    task: TaskInstance,
    condition: RunCondition,
    output_dir: Path,
    budget: float,
    model: str,
    run_tests: bool,
    test_timeout: int,
    path_filter: str | None,
    api_key: str | None = None,
    utility_model: str | None = None,
) -> AgentRun:
    """Run a single task x condition pair. Thread-safe, each gets its own worktree."""
    effective_filter = task.path_filter or path_filter
    sandbox = Sandbox(
        task.repo,
        task.base_commit,
        condition,
        path_filter=effective_filter,
    )
    try:
        worktree = sandbox.setup()

        agent_run = run_agent(
            instance_id=task.instance_id,
            condition=condition,
            problem_statement=task.problem_statement,
            repo=task.repo,
            worktree_path=worktree,
            budget=budget,
            model=model,
            api_key=api_key,
        )

        # Run tests in a CLEAN worktree with only the agent's patch applied.
        # This avoids environment contamination from the agent's exploration.
        if run_tests and task.has_test_suite() and agent_run.patch_produced:
            from mdarena.utils.git import clone_repo

            repo_path = clone_repo(task.repo)
            verdict = _test_in_clean_worktree(
                repo_path=repo_path,
                task=task,
                agent_patch=agent_run.patch_produced,
                test_timeout=test_timeout,
                path_filter=effective_filter,
                api_key=api_key,
                utility_model=utility_model,
            )
            agent_run.tests_ran = verdict.tests_ran
            agent_run.fail_to_pass_passed = verdict.fail_to_pass_passed
            agent_run.pass_to_pass_passed = verdict.pass_to_pass_passed
            agent_run.test_resolved = verdict.resolved
            agent_run.test_error = verdict.error
            agent_run.new_test_failures = verdict.new_failures
            agent_run.targeted_tests = verdict.targeted_tests

        # Save incrementally
        result_file = _result_path(output_dir, task.instance_id, condition.name)
        result_file.write_text(agent_run.model_dump_json(indent=2))

        return agent_run
    finally:
        sandbox.cleanup()


def run_benchmark(
    tasks: list[TaskInstance],
    conditions: list[RunCondition],
    output_dir: Path,
    budget: float = 2.00,
    model: str = DEFAULT_MODEL,
    skip_existing: bool = False,
    run_tests: bool = True,
    test_timeout: int = 300,
    path_filter: str | None = None,
    parallel: int = DEFAULT_PARALLEL,
    api_key: str | None = None,
    utility_model: str | None = None,
) -> list[AgentRun]:
    """Run all tasks across all conditions.

    Each task x condition pair produces one AgentRun, saved incrementally.
    When parallel > 1, multiple runs execute concurrently in separate worktrees.

    Tests run in clean worktrees with only the agent's patch applied,
    targeting only test files related to the changed code. No baseline
    test phase is needed.
    """
    runs_dir = output_dir / "runs"
    runs_dir.mkdir(parents=True, exist_ok=True)

    conditions_meta = [
        {"name": c.name, "context_file": str(c.context_file) if c.context_file else None}
        for c in conditions
    ]
    (output_dir / "conditions.json").write_text(json.dumps(conditions_meta, indent=2))

    # Build work items, skipping existing if requested
    work_items: list[tuple[TaskInstance, RunCondition]] = []
    skipped: list[AgentRun] = []
    for task in tasks:
        for condition in conditions:
            if skip_existing and _result_exists(output_dir, task.instance_id, condition.name):
                existing = AgentRun.model_validate_json(
                    _result_path(output_dir, task.instance_id, condition.name).read_text()
                )
                skipped.append(existing)
            else:
                work_items.append((task, condition))

    total_runs = len(work_items) + len(skipped)
    estimated_cost = len(work_items) * budget
    effective_parallel = min(parallel, len(work_items)) if work_items else 1

    console.print("\n[bold]Benchmark plan:[/bold]")
    console.print(f"  Tasks: {len(tasks)}")
    console.print(f"  Conditions: {len(conditions)} ({', '.join(c.name for c in conditions)})")
    console.print(f"  Total runs: {total_runs} ({len(skipped)} skipped)")
    console.print(f"  Max cost: ${estimated_cost:.2f} (at ${budget}/task/condition)")
    console.print(f"  Parallel: {effective_parallel}")
    if run_tests:
        console.print("  Tests: targeted (clean worktree, no baseline needed)")
    console.print()

    results: list[AgentRun] = list(skipped)

    if not work_items:
        console.print("[yellow]All runs already complete.[/yellow]")
        return results

    with Progress() as progress:
        bar = progress.add_task("Running benchmark", total=len(work_items))

        def on_complete(task: TaskInstance, condition: RunCondition, agent_run: AgentRun) -> None:
            """Log result when a run finishes."""
            task_label = f"PR #{task.pr_number}" if task.pr_number else task.instance_id
            status = (
                "[green]OK[/green]" if agent_run.patch_produced else "[yellow]no patch[/yellow]"
            )
            if agent_run.exit_reason != "success":
                status = f"[red]{agent_run.exit_reason}[/red]"
            if agent_run.test_resolved is True:
                status += " [green]tests:PASS[/green]"
            elif agent_run.test_resolved is False:
                status += " [red]tests:FAIL[/red]"
            elif agent_run.tests_ran and agent_run.test_error:
                status += " [yellow]tests:ERROR[/yellow]"

            console.print(
                f"  {task_label} [{condition.name}]: {status} (${agent_run.cost_usd:.3f})"
            )

        def run_task(task: TaskInstance, condition: RunCondition) -> AgentRun:
            return _run_single(
                task,
                condition,
                output_dir,
                budget,
                model,
                run_tests,
                test_timeout,
                path_filter,
                api_key=api_key,
                utility_model=utility_model,
            )

        if effective_parallel <= 1:
            for task, condition in work_items:
                task_label = f"PR #{task.pr_number}" if task.pr_number else task.instance_id
                progress.update(bar, description=f"{task_label} [{condition.name}]")
                agent_run = run_task(task, condition)
                results.append(agent_run)
                on_complete(task, condition, agent_run)
                progress.advance(bar)
        else:
            with ThreadPoolExecutor(max_workers=effective_parallel) as executor:
                future_to_info = {}
                for task, condition in work_items:
                    future = executor.submit(run_task, task, condition)
                    future_to_info[future] = (task, condition)

                for future in as_completed(future_to_info):
                    task, condition = future_to_info[future]
                    try:
                        agent_run = future.result()
                    except (RuntimeError, subprocess.SubprocessError, OSError, ValueError) as exc:
                        agent_run = AgentRun(
                            instance_id=task.instance_id,
                            condition_name=condition.name,
                            exit_reason="error",
                            error=str(exc)[:500],
                        )
                        result_file = _result_path(output_dir, task.instance_id, condition.name)
                        result_file.write_text(agent_run.model_dump_json(indent=2))

                    results.append(agent_run)
                    on_complete(task, condition, agent_run)
                    progress.advance(bar)

    # Write SWE-bench compatible JSONL predictions per condition
    _write_swebench_predictions(results, conditions, output_dir, model)

    console.print(f"\n[green]Completed {len(results)} runs[/green]")
    return results


def _write_swebench_predictions(
    results: list[AgentRun],
    conditions: list[RunCondition],
    output_dir: Path,
    model: str,
) -> None:
    """Write SWE-bench compatible JSONL predictions for each condition."""
    preds_dir = output_dir / "predictions"
    preds_dir.mkdir(parents=True, exist_ok=True)

    by_condition: dict[str, list[AgentRun]] = {}
    for r in results:
        by_condition.setdefault(r.condition_name, []).append(r)

    for condition_name, runs in by_condition.items():
        pred_file = preds_dir / f"predictions_{condition_name}.jsonl"
        with pred_file.open("w") as f:
            for run in runs:
                pred = SwebenchPrediction(
                    instance_id=run.instance_id,
                    model_name_or_path=f"mdarena-{condition_name}-{model}",
                    model_patch=run.patch_produced or "",
                )
                f.write(pred.model_dump_json() + "\n")

        console.print(f"  Predictions: {pred_file}")
