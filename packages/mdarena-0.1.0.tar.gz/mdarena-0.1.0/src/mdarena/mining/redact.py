"""Redact implementation details from PR descriptions.

Rewrites a PR problem statement to preserve the intent and business
context while stripping file paths, function names, and step-by-step
implementation instructions. This prevents the benchmark agent from
"cheating" by following the PR description as a roadmap.
"""

from __future__ import annotations

import subprocess

_REDACT_PROMPT = """\
You are preparing a coding task for a benchmark. Given a pull request title and \
description, rewrite it as a problem statement that a developer would receive \
as a task assignment.

Rules:
- Keep the business context, motivation, and desired behavior
- Remove ALL file paths, class names, function names, and variable names
- Remove step-by-step implementation instructions or changelists
- Remove references to specific lines of code or diff hunks
- Do NOT mention which files to edit or how many files to change
- Keep any behavioral requirements, edge cases, or constraints
- Keep descriptions of the problem being solved (bugs, missing features)
- Write in imperative mood ("Add support for..." not "This PR adds...")
- If the description is very short or title-only, just return it cleaned up
- Output ONLY the rewritten problem statement, no preamble

Example input:
  Title: Fix race condition in cache invalidation
  Body: The `CacheManager.invalidate()` method in `src/cache/manager.py` \
doesn't acquire the lock before clearing entries. Fix by adding \
`with self._lock:` around the delete loop in lines 45-52.

Example output:
  Fix the race condition in cache invalidation. The cache can return stale \
data when multiple threads invalidate entries simultaneously because the \
invalidation path doesn't properly synchronize access. Ensure thread-safe \
cache invalidation."""


DEFAULT_REDACT_MODEL = "claude-haiku-4-5-20251001"


def redact_problem_statement(
    title: str, body: str, api_key: str | None = None, model: str = DEFAULT_REDACT_MODEL
) -> str:
    """Rewrite a PR description to remove implementation hints.

    Uses the claude CLI (--print mode with haiku) so it works with
    OAuth auth, no ANTHROPIC_API_KEY needed.
    Returns the title if the CLI call fails.
    """
    import os

    raw = f"Title: {title}\nBody: {body}" if body else f"Title: {title}"
    env = {**os.environ, "ANTHROPIC_API_KEY": api_key} if api_key else None

    try:
        result = subprocess.run(
            [
                "claude",
                "--print",
                "--model",
                model,
                "--setting-sources",
                "",
                "--max-budget-usd",
                "0.50",
                "--system-prompt",
                _REDACT_PROMPT,
            ],
            input=raw,
            capture_output=True,
            text=True,
            timeout=30,
            env=env,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, subprocess.SubprocessError, OSError):
        pass

    # Fallback: return title-only to avoid leaking implementation details
    return title
