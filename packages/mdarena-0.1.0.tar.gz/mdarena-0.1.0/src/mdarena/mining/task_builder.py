"""Convert filtered PRs into TaskInstance objects."""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from typing import Any, Literal

from rich.console import Console
from rich.progress import Progress

from mdarena.config import TEST_FILE_PATTERNS
from mdarena.discovery.detect import TestConfig
from mdarena.mining.pr_filter import changed_files
from mdarena.models import TaskInstance
from mdarena.utils.gh import get_issue_body, get_pr_diff

console = Console()


def _estimate_difficulty(pr: dict[str, Any]) -> Literal["easy", "medium", "hard"]:
    changes = pr.get("additions", 0) + pr.get("deletions", 0)
    files = pr.get("files", [])
    num_files = len(files)

    if num_files <= 3 and changes < 50:
        return "easy"
    elif num_files <= 8 and changes < 200:
        return "medium"
    return "hard"


def _extract_test_patch(full_diff: str) -> str | None:
    """Extract the portion of a diff that only touches test files."""
    if not full_diff:
        return None

    test_hunks = []
    current_file_header = ""
    current_hunks: list[str] = []
    is_test_file = False

    for line in full_diff.split("\n"):
        if line.startswith("diff --git"):
            if is_test_file and current_hunks:
                test_hunks.append(current_file_header + "\n" + "\n".join(current_hunks))

            current_file_header = line
            current_hunks = []
            is_test_file = any(pat in line.lower() for pat in TEST_FILE_PATTERNS)
        else:
            current_hunks.append(line)

    if is_test_file and current_hunks:
        test_hunks.append(current_file_header + "\n" + "\n".join(current_hunks))

    return "\n".join(test_hunks) if test_hunks else None


def _build_problem_statement(
    pr: dict[str, Any],
    repo: str,
    redact: bool = True,
    api_key: str | None = None,
    utility_model: str | None = None,
) -> str:
    """Build the prompt that the agent will receive.

    Defaults to redact=True: a utility LLM rewrites the PR description
    to remove implementation hints (file paths, function names,
    step-by-step instructions, issue references like "Fixes #123")
    while preserving intent. This prevents the agent from cheating by
    reading the PR body as a roadmap to the gold patch.

    Pass redact=False only if you have vetted the problem statements
    and want full fidelity.
    """
    title = pr.get("title", "")
    body = pr.get("body", "") or ""

    # Try to find linked issues (Fixes #123, Closes #456)
    issue_refs = re.findall(r"(?:fixes|closes|resolves)\s+#(\d+)", body, re.IGNORECASE)
    issue_context = ""
    for ref in issue_refs[:2]:  # Limit to 2 linked issues
        issue_body = get_issue_body(repo, int(ref))
        if issue_body:
            issue_context += f"\n\n--- Linked Issue #{ref} ---\n{issue_body}"

    if redact:
        from mdarena.mining.redact import redact_problem_statement

        full_body = body
        if issue_context:
            full_body += issue_context
        kwargs: dict[str, Any] = {"api_key": api_key}
        if utility_model:
            kwargs["model"] = utility_model
        return redact_problem_statement(title, full_body, **kwargs)

    statement = f"## {title}\n\n{body}"
    if issue_context:
        statement += issue_context

    return statement


def _make_instance_id(repo: str, pr_number: int) -> str:
    return f"{repo.replace('/', '__')}-{pr_number}"


def build_tasks(
    prs: list[dict[str, Any]],
    repo: str,
    output_dir: Path,
    test_config: TestConfig | None = None,
    path_filter: str | None = None,
    extract_tests: bool = False,
    redact: bool = True,
    api_key: str | None = None,
    utility_model: str | None = None,
) -> list[TaskInstance]:
    """Convert PRs to TaskInstances and save them to disk.

    When test_config is provided, the test command is stored on each task
    so tests can run during 'mdarena run'.

    When extract_tests is True, also runs the test suite at base and merge
    commits to build FAIL_TO_PASS / PASS_TO_PASS lists (expensive).
    """
    tasks_dir = output_dir / "tasks"
    tasks_dir.mkdir(parents=True, exist_ok=True)

    repo_path: Path | None = None

    tasks = []
    with Progress() as progress:
        task_bar = progress.add_task("Building tasks", total=len(prs))

        for pr in prs:
            pr_number = pr["number"]
            instance_id = _make_instance_id(repo, pr_number)

            progress.update(task_bar, description=f"PR #{pr_number}")

            try:
                diff = get_pr_diff(repo, pr_number)
            except (RuntimeError, subprocess.SubprocessError) as e:
                console.print(f"  [yellow]Skipping PR #{pr_number}: {e}[/yellow]")
                progress.advance(task_bar)
                continue

            if not diff.strip():
                progress.advance(task_bar)
                continue

            files = changed_files(pr)

            merge_commit = pr.get("mergeCommit", {})
            merge_oid = merge_commit.get("oid") if isinstance(merge_commit, dict) else None

            base_ref = pr.get("baseRefOid", "")

            # Extract test lists only if explicitly requested (expensive)
            fail_to_pass: list[str] = []
            pass_to_pass: list[str] = []
            if extract_tests and test_config and base_ref and merge_oid:
                from mdarena.discovery.test_extractor import extract_test_lists
                from mdarena.utils.git import clone_repo

                try:
                    if repo_path is None:
                        repo_path = clone_repo(repo)
                    test_lists = extract_test_lists(
                        repo_path,
                        base_ref,
                        merge_oid,
                        test_config,
                    )
                    if test_lists.error:
                        console.print(
                            f"  [yellow]PR #{pr_number} test extraction: "
                            f"{test_lists.error}[/yellow]"
                        )
                    else:
                        fail_to_pass = test_lists.fail_to_pass
                        pass_to_pass = test_lists.pass_to_pass
                        if fail_to_pass:
                            console.print(
                                f"  [green]PR #{pr_number}: "
                                f"{len(fail_to_pass)} FAIL_TO_PASS, "
                                f"{len(pass_to_pass)} PASS_TO_PASS[/green]"
                            )
                except (RuntimeError, subprocess.SubprocessError, OSError) as e:
                    console.print(f"  [yellow]PR #{pr_number} test error: {e}[/yellow]")

            task = TaskInstance(
                instance_id=instance_id,
                repo=repo,
                pr_number=pr_number,
                pr_url=f"https://github.com/{repo}/pull/{pr_number}",
                base_commit=base_ref,
                merge_commit=merge_oid,
                problem_statement=_build_problem_statement(
                    pr, repo, redact=redact, api_key=api_key, utility_model=utility_model
                ),
                patch=diff,
                test_patch=_extract_test_patch(diff),
                files_changed=files,
                additions=pr.get("additions", 0),
                deletions=pr.get("deletions", 0),
                labels=[
                    lbl.get("name", "") if isinstance(lbl, dict) else str(lbl)
                    for lbl in pr.get("labels", [])
                ],
                difficulty=_estimate_difficulty(pr),
                FAIL_TO_PASS=fail_to_pass,
                PASS_TO_PASS=pass_to_pass,
                test_cmd=test_config.test_cmd if test_config else None,
                setup_cmd=test_config.setup_cmd if test_config else None,
                test_cmd_source=test_config.source if test_config else None,
                test_work_dir=test_config.work_dir if test_config else None,
                path_filter=path_filter,
            )

            # Save individual task
            task_file = tasks_dir / f"{instance_id}.json"
            task_file.write_text(task.model_dump_json(indent=2))
            tasks.append(task)
            progress.advance(task_bar)

    # Write manifest
    manifest = {
        "repo": repo,
        "path_filter": path_filter,
        "num_tasks": len(tasks),
        "tasks": [
            {
                "instance_id": t.instance_id,
                "pr_number": t.pr_number,
                "difficulty": t.difficulty,
                "additions": t.additions,
                "deletions": t.deletions,
                "has_test_commands": t.has_test_commands(),
            }
            for t in tasks
        ],
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))

    console.print(f"[green]Built {len(tasks)} task instances in {output_dir}[/green]")
    return tasks
