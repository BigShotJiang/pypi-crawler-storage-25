"""Filter PRs to find good benchmark candidates."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from rich.console import Console

from mdarena.config import (
    BOT_AUTHORS,
    DEFAULT_MAX_CHANGES,
    DEFAULT_MAX_FILES,
    DEFAULT_MIN_CHANGES,
    EXCLUDED_LABELS,
    NON_CODE_PATTERNS,
)

console = Console()


def _is_bot(pr: dict[str, Any]) -> bool:
    author = pr.get("author", {})
    login = author.get("login", "") if isinstance(author, dict) else ""
    return login.lower() in BOT_AUTHORS


def _has_excluded_label(pr: dict[str, Any]) -> bool:
    labels = pr.get("labels", [])
    label_names = {
        (lbl.get("name", "") if isinstance(lbl, dict) else str(lbl)).lower() for lbl in labels
    }
    return bool(label_names & EXCLUDED_LABELS)


def _total_changes(pr: dict[str, Any]) -> int:
    return pr.get("additions", 0) + pr.get("deletions", 0)


def changed_files(pr: dict[str, Any]) -> list[str]:
    files = pr.get("files", [])
    return [f.get("path", "") if isinstance(f, dict) else str(f) for f in files]


def _is_only_lockfiles(pr: dict[str, Any]) -> bool:
    files = changed_files(pr)
    if not files:
        return True
    return all(any(f.endswith(pat) or pat in f for pat in NON_CODE_PATTERNS) for f in files)


def _has_meaningful_description(pr: dict[str, Any]) -> bool:
    title = pr.get("title", "")
    body = pr.get("body", "") or ""
    return len(title) > 5 and (len(body) > 20 or len(title) > 20)


def _files_under_prefix(pr: dict[str, Any], prefix: str) -> list[dict[str, Any]]:
    """Return per-file entries that fall under a path prefix."""
    prefix = prefix.rstrip("/") + "/"
    files = pr.get("files", [])
    return [f for f in files if isinstance(f, dict) and f.get("path", "").startswith(prefix)]


def _changes_under_prefix(pr: dict[str, Any], prefix: str) -> int:
    """Sum additions + deletions for files under a path prefix."""
    return sum(
        f.get("additions", 0) + f.get("deletions", 0) for f in _files_under_prefix(pr, prefix)
    )


def filter_prs(
    prs: list[dict[str, Any]],
    min_changes: int = DEFAULT_MIN_CHANGES,
    max_changes: int = DEFAULT_MAX_CHANGES,
    max_files: int = DEFAULT_MAX_FILES,
    path_prefix: str | None = None,
) -> list[dict[str, Any]]:
    """Filter PRs to good benchmark candidates.

    When path_prefix is set, only files under that prefix count toward
    the size/files thresholds, and PRs with zero files under the prefix
    are excluded.
    """
    filtered = []
    reasons: defaultdict[str, int] = defaultdict(int)

    for pr in prs:
        if _is_bot(pr):
            reasons["bot_author"] += 1
            continue

        if _has_excluded_label(pr):
            reasons["excluded_label"] += 1
            continue

        # Scope to path prefix if provided
        if path_prefix:
            scoped_files = _files_under_prefix(pr, path_prefix)
            if not scoped_files:
                reasons["outside_path_filter"] += 1
                continue
            changes = _changes_under_prefix(pr, path_prefix)
            num_files = len(scoped_files)
        else:
            changes = _total_changes(pr)
            num_files = len(changed_files(pr))

        if changes < min_changes:
            reasons["too_small"] += 1
            continue
        if changes > max_changes:
            reasons["too_large"] += 1
            continue

        if num_files > max_files:
            reasons["too_many_files"] += 1
            continue

        if path_prefix:
            scoped_paths = [f.get("path", "") for f in scoped_files]
            only_locks = all(
                any(p.endswith(pat) or pat in p for pat in NON_CODE_PATTERNS) for p in scoped_paths
            )
        else:
            only_locks = _is_only_lockfiles(pr)
        if only_locks:
            reasons["only_lockfiles"] += 1
            continue

        if not _has_meaningful_description(pr):
            reasons["no_description"] += 1
            continue

        filtered.append(pr)

    console.print(f"  Filtered: {len(prs)} -> {len(filtered)} candidates")
    if path_prefix:
        console.print(f"    Path filter: {path_prefix}/")
    if reasons:
        for reason, count in sorted(reasons.items(), key=lambda x: -x[1]):
            console.print(f"    Excluded {count} PRs: {reason}")

    return filtered
