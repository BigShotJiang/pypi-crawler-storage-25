"""Fetch merged PRs from GitHub via gh CLI."""

from __future__ import annotations

from typing import Any

from rich.console import Console

from mdarena.utils.gh import list_merged_prs

console = Console()


def fetch_prs(
    repo: str,
    limit: int = 100,
    since: str | None = None,
) -> list[dict[str, Any]]:
    """Fetch merged PRs for a repo.

    Returns raw PR dicts from gh CLI with fields:
    number, title, body, baseRefOid, mergeCommit, files, additions,
    deletions, labels, mergedAt, author, changedFiles.
    """
    console.print(f"[bold]Fetching up to {limit} merged PRs from {repo}...[/bold]")
    prs = list_merged_prs(repo, limit=limit, since=since)
    console.print(f"  Fetched {len(prs)} PRs")
    return prs
