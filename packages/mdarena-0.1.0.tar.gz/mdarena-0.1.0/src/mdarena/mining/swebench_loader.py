"""Load tasks from SWE-bench HuggingFace datasets into mdarena format."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.progress import Progress

from mdarena.models import TaskInstance

console = Console()

# Common SWE-bench dataset names
KNOWN_DATASETS = {
    "lite": "princeton-nlp/SWE-bench_Lite",
    "verified": "princeton-nlp/SWE-bench_Verified",
    "full": "princeton-nlp/SWE-bench",
    "multimodal": "princeton-nlp/SWE-bench_Multimodal",
}


def _parse_test_list(value: Any) -> list[str]:
    """Parse FAIL_TO_PASS / PASS_TO_PASS which can be a JSON string or list."""
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            pass
        # Single test command as a string
        return [value] if value.strip() else []
    return []


def _swebench_to_task(item: dict[str, Any]) -> TaskInstance:
    """Convert a single SWE-bench dataset row to a TaskInstance."""
    return TaskInstance(
        instance_id=item["instance_id"],
        repo=item.get("repo", ""),
        base_commit=item.get("base_commit", ""),
        problem_statement=item.get("problem_statement", ""),
        patch=item.get("patch", ""),
        test_patch=item.get("test_patch") or None,
        FAIL_TO_PASS=_parse_test_list(item.get("FAIL_TO_PASS", [])),
        PASS_TO_PASS=_parse_test_list(item.get("PASS_TO_PASS", [])),
        version=item.get("version") or None,
        environment_setup_commit=item.get("environment_setup_commit") or None,
        hints_text=item.get("hints_text") or None,
        created_at=item.get("created_at") or None,
    )


def load_swebench(
    dataset_name: str = "lite",
    split: str = "test",
    limit: int | None = None,
    instance_ids: list[str] | None = None,
    output_dir: Path = Path("mdarena_tasks"),
) -> list[TaskInstance]:
    """Load SWE-bench tasks from HuggingFace and save in mdarena format.

    Requires: pip install datasets
    """
    try:
        from datasets import load_dataset  # ty: ignore[unresolved-import]
    except ImportError:
        console.print(
            "[red]'datasets' package required. Install with:[/red]\n  pip install datasets"
        )
        raise SystemExit(1) from None

    # Resolve dataset alias
    resolved = KNOWN_DATASETS.get(dataset_name, dataset_name)
    console.print(f"[bold]Loading {resolved} (split={split})...[/bold]")

    dataset = load_dataset(resolved, split=split)

    # Filter by instance IDs if provided
    if instance_ids:
        id_set = set(instance_ids)
        dataset = dataset.filter(lambda x: x["instance_id"] in id_set)

    if limit:
        dataset = dataset.select(range(min(limit, len(dataset))))

    console.print(f"  Loaded {len(dataset)} instances")

    # Convert to TaskInstance and save
    tasks_dir = output_dir / "tasks"
    tasks_dir.mkdir(parents=True, exist_ok=True)

    tasks = []
    with Progress() as progress:
        bar = progress.add_task("Converting tasks", total=len(dataset))

        for item in dataset:
            task = _swebench_to_task(item)
            task_file = tasks_dir / f"{task.instance_id}.json"
            task_file.write_text(task.model_dump_json(indent=2))
            tasks.append(task)
            progress.advance(bar)

    # Write manifest
    manifest = {
        "repo": resolved,
        "source": "swebench",
        "dataset": resolved,
        "split": split,
        "num_tasks": len(tasks),
        "tasks": [
            {
                "instance_id": t.instance_id,
                "repo": t.repo,
                "difficulty": t.difficulty,
                "has_test_commands": t.has_test_commands(),
            }
            for t in tasks
        ],
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))

    console.print(f"[green]Saved {len(tasks)} tasks to {output_dir}/[/green]")
    return tasks
