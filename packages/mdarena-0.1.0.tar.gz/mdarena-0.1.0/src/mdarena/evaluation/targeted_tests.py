"""Find test files related to an agent's patch.

Given a unified diff, extracts the modified source files and finds
test files that likely cover them, by naming convention and by
scanning imports. Returns pytest-compatible file paths that can be
passed directly to the test command.
"""

from __future__ import annotations

import re
from pathlib import Path


def _files_from_diff(patch: str) -> list[str]:
    """Extract file paths from a unified diff."""
    files = []
    for line in patch.splitlines():
        if line.startswith("diff --git"):
            parts = line.split()
            if len(parts) >= 4:
                files.append(parts[3].lstrip("b/"))
    return files


def _is_test_file(path: str) -> bool:
    """Check if a path looks like a test file (Python, JS/TS)."""
    name = path.rsplit("/", 1)[-1] if "/" in path else path
    return (
        name.startswith("test_")
        or name.startswith("tests_")
        or name.endswith("_test.py")
        or name.endswith((".test.js", ".test.ts", ".test.tsx", ".spec.js", ".spec.ts", ".spec.tsx"))
    )


def _source_to_test_patterns(source_path: str) -> list[str]:
    """Generate possible test file paths for a source file.

    Supports Python (.py) and JS/TS (.js, .ts, .tsx) conventions.

    For 'backend/bots/cache/caches.py', generates:
      - backend/bots/cache/test_caches.py
      - backend/bots/cache/tests/test_caches.py
      - backend/bots/tests/test_cache.py  (parent module name)
      - backend/bots/tests/test_caches.py

    For 'src/components/Button.tsx', generates:
      - src/components/Button.test.tsx
      - src/components/Button.spec.tsx
      - src/components/__tests__/Button.test.tsx
    """
    parts = source_path.rsplit("/", 1)
    if len(parts) == 2:
        directory, filename = parts
    else:
        directory, filename = "", parts[0]

    patterns: list[str] = []

    if source_path.endswith(".py"):
        stem = filename.removesuffix(".py")
        if directory:
            patterns.append(f"{directory}/test_{stem}.py")
            patterns.append(f"{directory}/tests/test_{stem}.py")
            parent = directory.rsplit("/", 1)[0] if "/" in directory else ""
            if parent:
                patterns.append(f"{parent}/tests/test_{stem}.py")
                module_name = directory.rsplit("/", 1)[-1]
                patterns.append(f"{parent}/tests/test_{module_name}.py")
    else:
        # JS/TS conventions
        for ext in (".js", ".ts", ".tsx", ".jsx"):
            if filename.endswith(ext):
                stem = filename.removesuffix(ext)
                if directory:
                    patterns.append(f"{directory}/{stem}.test{ext}")
                    patterns.append(f"{directory}/{stem}.spec{ext}")
                    patterns.append(f"{directory}/__tests__/{stem}.test{ext}")
                break

    return patterns


def _find_test_by_import(
    source_path: str,
    test_files: list[Path],
    worktree: Path,
) -> list[Path]:
    """Find test files that import the modified source module.

    Uses the last two path components (e.g. 'studio.api') to avoid
    false positives on generic names like 'api' or 'utils'.
    """
    if not source_path.endswith(".py"):
        return []

    module = source_path.removesuffix(".py").replace("/", ".")
    # Use last two components for specificity (e.g. "bots.studio.api" -> "studio.api")
    parts = module.rsplit(".", 2)
    import_key = ".".join(parts[-2:]) if len(parts) >= 2 else module

    matches = []
    import_pattern = re.compile(
        rf"(?:from\s+\S*{re.escape(import_key)}\S*\s+import"
        rf"|import\s+\S*{re.escape(import_key)})"
    )

    for test_file in test_files:
        try:
            content = test_file.read_text(errors="ignore")
            if import_pattern.search(content):
                matches.append(test_file)
        except OSError:
            continue

    return matches


def find_targeted_tests(
    patch: str,
    worktree: Path,
    scope: str | None = None,
) -> list[str]:
    """Find test files related to the files modified in a patch.

    Returns a list of test file paths (relative to worktree) suitable
    for passing to pytest. Returns an empty list if no related tests
    are found (caller should decide whether to skip or run full suite).
    """
    changed_files = _files_from_diff(patch)
    if not changed_files:
        return []

    # Separate test files the agent modified (always include) from source files
    agent_test_files = [f for f in changed_files if _is_test_file(f)]
    _SOURCE_EXTENSIONS = (".py", ".js", ".ts", ".tsx", ".jsx")
    source_files = [
        f
        for f in changed_files
        if any(f.endswith(ext) for ext in _SOURCE_EXTENSIONS) and not _is_test_file(f)
    ]

    targeted: set[str] = set(agent_test_files)

    # Collect all test files in the repo (or scope) for import scanning,
    # excluding virtual environments, node_modules, and build directories
    _EXCLUDE_DIRS = {
        ".venv",
        "venv",
        "node_modules",
        ".next",
        "__pycache__",
        ".git",
        "dist",
        ".tox",
        "build",
        "__snapshots__",
    }
    search_root = worktree / scope if scope else worktree

    _TEST_EXTENSIONS = (".test.js", ".test.ts", ".test.tsx", ".spec.js", ".spec.ts", ".spec.tsx")

    def _find_test_files(root: Path) -> list[Path]:
        results = []
        try:
            entries = list(root.iterdir())
        except (PermissionError, OSError):
            return results
        for child in entries:
            if child.name in _EXCLUDE_DIRS:
                continue
            if child.is_dir():
                results.extend(_find_test_files(child))
            elif child.is_file() and (
                child.name.startswith("test_")
                or child.name.endswith("_test.py")
                or any(child.name.endswith(ext) for ext in _TEST_EXTENSIONS)
            ):
                results.append(child)
        return results

    all_test_files = _find_test_files(search_root)

    for src in source_files:
        # Try naming convention first
        for pattern in _source_to_test_patterns(src):
            candidate = worktree / pattern
            if candidate.is_file():
                targeted.add(pattern)

        # Also scan imports
        import_matches = _find_test_by_import(src, all_test_files, worktree)
        for match in import_matches:
            rel = str(match.relative_to(worktree))
            targeted.add(rel)

    return sorted(targeted)
