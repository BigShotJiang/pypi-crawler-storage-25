"""Run tests on agent output in a clean environment.

Two modes:
- SWE-bench mode: when FAIL_TO_PASS exists, check specific test transitions
- Targeted mode: find tests related to the agent's changed files, run only
  those in a clean worktree with the patch applied. No baseline needed.
"""

from __future__ import annotations

import shlex
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from mdarena.config import DEFAULT_TEST_TIMEOUT
from mdarena.discovery.detect import TestConfig
from mdarena.discovery.test_extractor import run_tests
from mdarena.models import TaskInstance


@dataclass
class TestVerdict:
    """Result of running tests on an agent's patch."""

    tests_ran: bool
    fail_to_pass_passed: bool | None = None
    pass_to_pass_passed: bool | None = None
    resolved: bool | None = None
    error: str | None = None
    new_failures: list[str] = field(default_factory=list)
    targeted_tests: list[str] = field(default_factory=list)


def _build_config(
    task: TaskInstance,
    timeout: int,
    test_files: list[str] | None = None,
) -> TestConfig:
    base_cmd = task.test_cmd or ""

    if test_files and "pytest" in base_cmd:
        # Replace the pytest command to only run specific files.
        # Strip xdist (-n N) since we're running a small subset.
        import re

        cmd = re.sub(r"-n\s+\d+", "", base_cmd).strip()
        # Test file paths are relative to worktree root, but pytest runs
        # from work_dir. Strip the work_dir prefix so paths resolve correctly.
        work_dir = task.test_work_dir or ""
        prefix = work_dir.rstrip("/") + "/" if work_dir else ""
        adjusted = [f.removeprefix(prefix) for f in test_files]
        files_arg = " ".join(shlex.quote(f) for f in adjusted)
        cmd = f"{cmd} {files_arg}"
    else:
        cmd = base_cmd

    return TestConfig(
        test_cmd=cmd,
        setup_cmd=task.setup_cmd,
        timeout=timeout,
        work_dir=task.test_work_dir,
    )


def verify_patch(
    worktree_path: Path,
    task: TaskInstance,
    timeout: int = DEFAULT_TEST_TIMEOUT,
    agent_patch: str = "",
    api_key: str | None = None,
    utility_model: str | None = None,
) -> TestVerdict:
    """Run tests on the agent's patch.

    Three modes:
    - SWE-bench mode: when FAIL_TO_PASS exists, check specific test transitions
    - Targeted mode (default): find tests related to changed files, run only those
    - Fallback: if no targeted tests found, run full suite with baseline comparison
    """
    if not task.test_cmd:
        return TestVerdict(tests_ran=False)

    # SWE-bench mode: check specific test transitions
    if task.FAIL_TO_PASS:
        config = _build_config(task, timeout)
        try:
            results = run_tests(worktree_path, config)
        except (subprocess.SubprocessError, OSError, RuntimeError) as e:
            return TestVerdict(tests_ran=True, error=f"Test execution failed: {e}")

        if results.timed_out:
            return TestVerdict(tests_ran=True, error="Test suite timed out")

        f2p_passed = all(t in results.passed for t in task.FAIL_TO_PASS)
        p2p_passed = all(t in results.passed for t in task.PASS_TO_PASS)
        return TestVerdict(
            tests_ran=True,
            fail_to_pass_passed=f2p_passed,
            pass_to_pass_passed=p2p_passed,
            resolved=f2p_passed and p2p_passed,
        )

    # Targeted mode: find tests related to the agent's changes
    from mdarena.evaluation.targeted_tests import find_targeted_tests

    scope = task.path_filter or task.test_work_dir
    test_files = find_targeted_tests(agent_patch, worktree_path, scope=scope)

    if test_files:
        config = _build_config(task, timeout, test_files=test_files)
        try:
            results = run_tests(worktree_path, config)
        except (subprocess.SubprocessError, OSError, RuntimeError) as e:
            return TestVerdict(
                tests_ran=True,
                targeted_tests=test_files,
                error=f"Test execution failed: {e}",
            )

        if results.timed_out:
            return TestVerdict(
                tests_ran=True,
                targeted_tests=test_files,
                error="Targeted tests timed out",
            )

        failures = sorted(results.failed | results.errored)
        passed = not failures

        return TestVerdict(
            tests_ran=True,
            resolved=passed,
            pass_to_pass_passed=passed,
            new_failures=failures,
            targeted_tests=test_files,
            error=f"{len(failures)} targeted test failures" if failures else None,
        )

    # No targeted tests found, run full suite with baseline comparison
    config = _build_config(task, timeout)
    try:
        results = run_tests(worktree_path, config)
    except (subprocess.SubprocessError, OSError, RuntimeError) as e:
        return TestVerdict(tests_ran=True, error=f"Test execution failed: {e}")

    if results.timed_out:
        return TestVerdict(tests_ran=True, error="Test suite timed out")

    new_failures = sorted(results.failed | results.errored)

    if not new_failures:
        return TestVerdict(
            tests_ran=True,
            resolved=True,
            pass_to_pass_passed=True,
            new_failures=[],
        )

    # Short-circuit for obvious environment breakage
    if len(new_failures) > 50:
        return TestVerdict(
            tests_ran=True,
            resolved=False,
            pass_to_pass_passed=False,
            new_failures=new_failures,
            error=f"{len(new_failures)} new failures, likely environment breakage",
        )

    # Ask LLM whether the patch actually caused the new failures
    from mdarena.evaluation.failure_triage import triage_failures

    triage_kwargs: dict = {"api_key": api_key}
    if utility_model:
        triage_kwargs["model"] = utility_model
    caused, explanation = triage_failures(agent_patch, new_failures, **triage_kwargs)

    return TestVerdict(
        tests_ran=True,
        resolved=not caused,
        pass_to_pass_passed=not caused,
        new_failures=new_failures,
        error=f"Triage: {explanation}" if caused else None,
    )
