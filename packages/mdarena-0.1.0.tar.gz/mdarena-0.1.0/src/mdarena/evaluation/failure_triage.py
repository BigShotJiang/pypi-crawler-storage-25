"""LLM-based triage of test failures after agent patching.

Given the agent's diff and a list of new test failures, asks an LLM
whether the patch caused the failures or they're unrelated (flaky/pre-existing).
"""

from __future__ import annotations

import subprocess

_TRIAGE_PROMPT = """\
You are triaging test failures in a CI system. You will be given:
1. A code diff (the changes an agent made)
2. A list of test names that newly failed after the diff was applied

Determine whether the diff CAUSED these failures or they are UNRELATED \
(flaky tests, environment issues, pre-existing failures).

Rules:
- A failure is CAUSED if the diff modified code that the test exercises, \
directly or through imports/dependencies
- A failure is UNRELATED if the test covers code the diff never touched \
and there is no plausible transitive dependency
- When uncertain, lean toward CAUSED (false positives are safer than misses)

Respond with EXACTLY one of these two words on the first line:
CAUSED
UNRELATED

Then a brief explanation (2-3 sentences max)."""


DEFAULT_TRIAGE_MODEL = "claude-haiku-4-5-20251001"


def triage_failures(
    patch: str,
    new_failures: list[str],
    api_key: str | None = None,
    model: str = DEFAULT_TRIAGE_MODEL,
) -> tuple[bool, str]:
    """Ask an LLM if the patch caused the test failures.

    Returns (caused: bool, explanation: str).
    Falls back to (True, ...) if the LLM call fails (conservative).
    """
    if not new_failures:
        return False, "No new failures."

    failures_text = "\n".join(f"- {f}" for f in new_failures)
    user_msg = f"## Diff\n```\n{patch[:8000]}\n```\n\n## New test failures\n{failures_text}"

    import os

    env = {**os.environ, "ANTHROPIC_API_KEY": api_key} if api_key else None

    try:
        result = subprocess.run(
            [
                "claude",
                "--print",
                "--model",
                model,
                "--setting-sources",
                "",
                "--max-budget-usd",
                "0.50",
                "--system-prompt",
                _TRIAGE_PROMPT,
            ],
            input=user_msg,
            capture_output=True,
            text=True,
            timeout=60,
            env=env,
        )
        if result.returncode == 0 and result.stdout.strip():
            text = result.stdout.strip()
            first_line = text.split("\n")[0].strip().upper()
            explanation = "\n".join(text.split("\n")[1:]).strip()
            if first_line == "UNRELATED":
                return False, explanation
            if first_line == "CAUSED":
                return True, explanation
            # LLM didn't follow format, conservative default
            return True, f"Unexpected triage response ({first_line}). {explanation}"

        # Non-zero exit or empty output, include stderr for diagnosis
        err = result.stderr.strip()[:200] if result.stderr else "empty output"
        return True, f"Triage failed (exit {result.returncode}): {err}"
    except subprocess.TimeoutExpired:
        return True, "Triage timed out (60s), assuming caused."
    except (subprocess.SubprocessError, OSError) as e:
        return True, f"Triage error: {e}"
