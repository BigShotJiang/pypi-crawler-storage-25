"""Aggregate metrics and statistical comparisons."""

from __future__ import annotations

from scipy import stats

from mdarena.models import BenchmarkReport, ConditionSummary, EvalResult

RESOLUTION_THRESHOLD = 0.5  # file_overlap > this = "resolved" (diff-only fallback)


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _score_for_resolution(r: EvalResult) -> float:
    """Score used for resolution rate and p-value.

    Binary in both cases so p-value and resolution_rate stay consistent:
    test pass/fail when available, file_overlap > threshold otherwise.
    """
    if r.tests_available and r.test_resolved is not None:
        return 1.0 if r.test_resolved else 0.0
    return 1.0 if r.file_overlap > RESOLUTION_THRESHOLD else 0.0


def summarize_condition(
    condition_name: str,
    context_file: str | None,
    results: list[EvalResult],
) -> ConditionSummary:
    """Compute aggregate metrics for one condition.

    Resolution rate is blended: uses test pass/fail for tasks that have
    tests, diff overlap > threshold for tasks without.
    """
    n = len(results)
    if n == 0:
        return ConditionSummary(
            condition_name=condition_name,
            context_file=context_file,
            num_tasks=0,
            resolution_rate=0.0,
            avg_file_overlap=0.0,
            avg_hunk_overlap=0.0,
            avg_cost=0.0,
            avg_tokens=0.0,
            avg_duration_ms=0.0,
        )

    # Blended resolution: test results where available, diff overlap otherwise
    resolved_count = 0
    for r in results:
        if r.tests_available and r.test_resolved is not None:
            resolved_count += 1 if r.test_resolved else 0
        else:
            resolved_count += 1 if r.file_overlap > RESOLUTION_THRESHOLD else 0

    # Test-only resolution rate
    results_with_tests = [r for r in results if r.tests_available]
    test_resolved_count = sum(1 for r in results_with_tests if r.test_resolved is True)
    test_resolution_rate = (
        round(test_resolved_count / len(results_with_tests), 4) if results_with_tests else None
    )

    return ConditionSummary(
        condition_name=condition_name,
        context_file=context_file,
        num_tasks=n,
        resolution_rate=round(resolved_count / n, 4),
        avg_file_overlap=round(_mean([r.file_overlap for r in results]), 4),
        avg_hunk_overlap=round(_mean([r.hunk_overlap for r in results]), 4),
        avg_cost=round(_mean([r.cost_usd for r in results]), 4),
        avg_tokens=round(_mean([float(r.tokens_total) for r in results]), 1),
        avg_duration_ms=round(_mean([float(r.duration_ms) for r in results]), 1),
        test_resolution_rate=test_resolution_rate,
        num_tasks_with_tests=len(results_with_tests),
    )


def compute_p_value(
    baseline_results: list[EvalResult],
    condition_results: list[EvalResult],
) -> float | None:
    """Compute p-value comparing resolution scores between two conditions.

    Uses test pass/fail when available, file overlap otherwise.
    Paired t-test (same tasks, different conditions).
    """
    if len(baseline_results) < 5 or len(condition_results) < 5:
        return None

    baseline_map = {r.instance_id: _score_for_resolution(r) for r in baseline_results}
    condition_map = {r.instance_id: _score_for_resolution(r) for r in condition_results}

    shared_ids = set(baseline_map.keys()) & set(condition_map.keys())
    if len(shared_ids) < 5:
        return None

    baseline_scores = [baseline_map[iid] for iid in sorted(shared_ids)]
    condition_scores = [condition_map[iid] for iid in sorted(shared_ids)]

    _, p_value = stats.ttest_rel(condition_scores, baseline_scores)
    return round(float(p_value), 4)


def build_report(
    repo: str,
    all_results: list[EvalResult],
    conditions_meta: list[dict],
) -> BenchmarkReport:
    """Build a full benchmark report from eval results."""
    by_condition: dict[str, list[EvalResult]] = {}
    for r in all_results:
        by_condition.setdefault(r.condition_name, []).append(r)

    summaries = []
    for meta in conditions_meta:
        name = meta["name"]
        results = by_condition.get(name, [])
        summaries.append(summarize_condition(name, meta.get("context_file"), results))

    if summaries:
        sorted_by_rate = sorted(summaries, key=lambda s: s.resolution_rate, reverse=True)
        winner = sorted_by_rate[0].condition_name
        loser = sorted_by_rate[-1].condition_name
    else:
        winner = loser = None

    return BenchmarkReport(
        repo=repo,
        num_tasks=len({r.instance_id for r in all_results}),
        conditions=summaries,
        eval_results=all_results,
        winner=winner,
        loser=loser,
    )
