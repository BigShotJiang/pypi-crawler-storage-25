"""Score agent patches against gold patches using diff overlap."""

from __future__ import annotations

from dataclasses import dataclass, field

from unidiff import PatchSet

from mdarena.models import AgentRun, EvalResult, TaskInstance


@dataclass
class _ParsedDiff:
    """Pre-parsed diff: file paths and per-file changed line numbers."""

    files: set[str] = field(default_factory=set)
    changed_lines: dict[str, set[int]] = field(default_factory=dict)


def _parse_diff(diff: str) -> _ParsedDiff:
    """Parse a unified diff once, extracting both file paths and changed lines."""
    if not diff or not diff.strip():
        return _ParsedDiff()

    files: set[str] = set()
    changed_lines: dict[str, set[int]] = {}

    try:
        patch = PatchSet.from_string(diff)
        for patched_file in patch:
            files.add(patched_file.path)
            lines = set()
            for hunk in patched_file:
                for line in hunk:
                    if line.is_added:
                        lines.add(line.target_line_no)
            if lines:
                changed_lines[patched_file.path] = lines
    except (ValueError, KeyError):
        # Fallback: parse diff --git headers for file paths
        for line in diff.split("\n"):
            if line.startswith("diff --git"):
                parts = line.split()
                if len(parts) >= 4:
                    files.add(parts[3].lstrip("b/"))

    return _ParsedDiff(files=files, changed_lines=changed_lines)


def _file_overlap(agent: _ParsedDiff, gold: _ParsedDiff) -> float:
    """Jaccard similarity of files modified: |A & G| / |A | G|."""
    if not agent.files and not gold.files:
        return 1.0
    if not agent.files or not gold.files:
        return 0.0
    intersection = agent.files & gold.files
    union = agent.files | gold.files
    return len(intersection) / len(union)


def _hunk_overlap(agent: _ParsedDiff, gold: _ParsedDiff) -> float:
    """Line-level overlap across all files.

    For each file present in both diffs, compute Jaccard of line numbers.
    Average across all files in the gold diff.
    """
    if not gold.changed_lines:
        return 1.0 if not agent.changed_lines else 0.0

    scores = []
    for filepath, gold_set in gold.changed_lines.items():
        agent_set = agent.changed_lines.get(filepath, set())
        if not gold_set and not agent_set:
            scores.append(1.0)
        elif not gold_set or not agent_set:
            scores.append(0.0)
        else:
            intersection = gold_set & agent_set
            union = gold_set | agent_set
            scores.append(len(intersection) / len(union))

    return sum(scores) / len(scores) if scores else 0.0


def file_overlap(agent_diff: str, gold_diff: str) -> float:
    """Jaccard similarity of files modified: |A & G| / |A | G|."""
    return _file_overlap(_parse_diff(agent_diff), _parse_diff(gold_diff))


def hunk_overlap(agent_diff: str, gold_diff: str) -> float:
    """Line-level overlap across all files."""
    return _hunk_overlap(_parse_diff(agent_diff), _parse_diff(gold_diff))


def _filter_by_scope(parsed: _ParsedDiff, scope: str) -> _ParsedDiff:
    """Filter a parsed diff to only include files under a path prefix."""
    prefix = scope.rstrip("/") + "/"
    scoped_files = {f for f in parsed.files if f.startswith(prefix)}
    scoped_lines = {f: lines for f, lines in parsed.changed_lines.items() if f.startswith(prefix)}
    return _ParsedDiff(files=scoped_files, changed_lines=scoped_lines)


def score_run(
    agent_run: AgentRun,
    gold_patch: str,
    task: TaskInstance | None = None,
) -> EvalResult:
    """Score a single agent run against the gold patch.

    When the task has a path_filter, the gold patch is filtered to only
    include files within scope. This prevents out-of-scope gold files
    from artificially lowering overlap scores.
    """
    agent_patch = agent_run.patch_produced or ""

    agent_parsed = _parse_diff(agent_patch)
    gold_parsed = _parse_diff(gold_patch)

    # Filter gold to scope so out-of-scope files don't penalize the agent
    if task and task.path_filter:
        gold_parsed = _filter_by_scope(gold_parsed, task.path_filter)

    f_overlap = _file_overlap(agent_parsed, gold_parsed)
    h_overlap = _hunk_overlap(agent_parsed, gold_parsed)
    exact = agent_patch.strip() == gold_patch.strip() if agent_patch else False

    return EvalResult(
        instance_id=agent_run.instance_id,
        condition_name=agent_run.condition_name,
        file_overlap=round(f_overlap, 4),
        hunk_overlap=round(h_overlap, 4),
        exact_match=exact,
        test_resolved=agent_run.test_resolved,
        tests_available=agent_run.tests_ran or (task.has_test_commands() if task else False),
        cost_usd=agent_run.cost_usd,
        duration_ms=agent_run.duration_ms,
        tokens_total=agent_run.input_tokens + agent_run.output_tokens,
    )
