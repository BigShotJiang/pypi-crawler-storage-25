"""Thin wrapper around the gh CLI."""

from __future__ import annotations

import json
import subprocess
from typing import Any

# Default timeout for gh commands (seconds)
_TIMEOUT = 120


def _run(args: list[str], check: bool = True, timeout: int = _TIMEOUT) -> str:
    result = subprocess.run(
        ["gh", *args],
        capture_output=True,
        text=True,
        check=check,
        timeout=timeout,
    )
    return result.stdout


def list_merged_prs(
    repo: str,
    limit: int = 100,
    since: str | None = None,
) -> list[dict[str, Any]]:
    """Fetch merged PRs with metadata.

    Returns list of dicts with: number, title, body, baseRefOid,
    mergeCommit, files, additions, deletions, labels, mergedAt, author.
    """
    fields = [
        "number",
        "title",
        "body",
        "baseRefOid",
        "mergeCommit",
        "files",
        "additions",
        "deletions",
        "labels",
        "mergedAt",
        "author",
        "headRefName",
        "changedFiles",
    ]
    args = [
        "pr",
        "list",
        "-R",
        repo,
        "--state",
        "merged",
        "--limit",
        str(limit),
        "--json",
        ",".join(fields),
    ]
    if since:
        args.extend(["--search", f"merged:>={since}"])

    raw = _run(args)
    return json.loads(raw) if raw.strip() else []


def get_pr_diff(repo: str, pr_number: int) -> str:
    """Fetch the unified diff for a PR."""
    return _run(["pr", "diff", str(pr_number), "-R", repo, "--patch"])


def get_issue_body(repo: str, issue_number: int) -> str | None:
    """Fetch an issue's body text. Returns None if not found."""
    try:
        raw = _run(
            ["issue", "view", str(issue_number), "-R", repo, "--json", "body"],
            check=False,
        )
        if raw.strip():
            data = json.loads(raw)
            return data.get("body")
    except (subprocess.TimeoutExpired, json.JSONDecodeError, RuntimeError):
        pass
    return None
