"""Thin wrapper around git CLI for clone, checkout, and diff operations."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from mdarena.config import REPOS_DIR

# Default timeout for git commands (seconds)
_TIMEOUT = 300  # 5 min (clones can be slow)

# Track repos already fetched this process to avoid redundant network calls
_fetched_repos: set[str] = set()


def _run(
    args: list[str],
    cwd: Path | None = None,
    check: bool = True,
    timeout: int = _TIMEOUT,
) -> str:
    result = subprocess.run(
        ["git", *args],
        capture_output=True,
        text=True,
        cwd=cwd,
        check=check,
        timeout=timeout,
    )
    return result.stdout


def _resolve_clone_url(repo: str) -> str:
    """Resolve the best clone URL for a repo, handling private repos.

    Tries in order:
    1. gh CLI (knows the user's auth and protocol preference)
    2. SSH URL (works for private repos with SSH keys)
    3. HTTPS URL (fallback)
    """
    try:
        result = subprocess.run(
            ["gh", "repo", "view", repo, "--json", "sshUrl,url"],
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )
        if result.returncode == 0 and result.stdout.strip():
            data = json.loads(result.stdout)
            # gh respects the user's git_protocol setting; prefer SSH for
            # private repos since it avoids credential helper issues
            if data.get("sshUrl"):
                return data["sshUrl"]
            if data.get("url"):
                return data["url"]
    except (subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError):
        pass

    # Fallback: SSH (works for most private repos without extra credential setup)
    return f"git@github.com:{repo}.git"


def repo_cache_path(repo: str) -> Path:
    """Return the cache path for a repo (owner__name)."""
    return REPOS_DIR / repo.replace("/", "__")


def clone_repo(repo: str) -> Path:
    """Clone a repo to cache if not already present. Returns the clone path."""
    cache = repo_cache_path(repo)
    if cache.exists():
        if repo not in _fetched_repos:
            _run(["fetch", "--all", "--quiet"], cwd=cache, check=False)
            _fetched_repos.add(repo)
        return cache

    cache.parent.mkdir(parents=True, exist_ok=True)
    url = _resolve_clone_url(repo)
    _run(
        [
            "clone",
            "--filter=blob:none",  # Treeless clone for speed
            "--quiet",
            url,
            str(cache),
        ],
        timeout=600,  # 10 min for large repos
    )
    return cache


def create_isolated_checkout(repo_path: Path, commit: str) -> Path:
    """Create a history-free checkout of a repo at a specific commit.

    Unlike ``git worktree add``, which shares the full object database with
    the parent repo (leaking all future commits, tags, and branches via
    ``git log --all``, ``git show <sha>``, ``git rev-parse``, etc.), this
    exports the file snapshot at ``commit`` via ``git archive`` and
    initializes a fresh single-commit repo in a temp directory.

    The agent sees exactly one commit and no remotes. There is no history
    to mine for the solution, future commits are not "unreachable", they
    simply do not exist in the object database at all.

    The returned directory is a valid git repo, so downstream patch
    extraction via ``git diff HEAD`` works unchanged.
    """
    checkout = Path(tempfile.mkdtemp(prefix="mdarena-wt-"))

    # Stream `git archive <commit>` into `tar -x`. Pipe avoids holding the
    # full archive in memory for large repos.
    #
    # COPYFILE_DISABLE=1 prevents macOS BSD tar from interpreting files whose
    # names start with "._" as AppleDouble resource-fork companions, which
    # causes spurious "Failed to restore metadata" errors when those files are
    # just ordinary blobs that happen to start with "._".
    tar_env = {**os.environ, "COPYFILE_DISABLE": "1"}
    try:
        archive_proc = subprocess.Popen(
            ["git", "archive", "--format=tar", commit],
            cwd=repo_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        try:
            extract_proc = subprocess.run(
                ["tar", "-x", "--no-same-owner", "--no-same-permissions"],
                cwd=checkout,
                stdin=archive_proc.stdout,
                capture_output=True,
                timeout=600,
                env=tar_env,
            )
        finally:
            if archive_proc.stdout:
                archive_proc.stdout.close()
            archive_rc = archive_proc.wait(timeout=60)
            archive_err = (
                archive_proc.stderr.read().decode(errors="replace") if archive_proc.stderr else ""
            )
            if archive_proc.stderr:
                archive_proc.stderr.close()

        if archive_rc != 0:
            raise RuntimeError(f"git archive failed for {commit}: {archive_err.strip()}")
        if extract_proc.returncode != 0:
            raise RuntimeError(
                f"tar extract failed: {extract_proc.stderr.decode(errors='replace').strip()}"
            )
    except Exception:
        shutil.rmtree(checkout, ignore_errors=True)
        raise

    # Initialize a fresh repo with one commit so `git diff HEAD` (used by
    # `get_diff` for patch extraction) works. Explicit author/committer env
    # avoids depending on the caller's git config.
    env = {
        **os.environ,
        "GIT_AUTHOR_NAME": "mdarena",
        "GIT_AUTHOR_EMAIL": "bench@mdarena.local",
        "GIT_COMMITTER_NAME": "mdarena",
        "GIT_COMMITTER_EMAIL": "bench@mdarena.local",
    }
    try:
        subprocess.run(
            ["git", "init", "--quiet"],
            cwd=checkout,
            check=True,
            capture_output=True,
            timeout=30,
            env=env,
        )
        subprocess.run(
            ["git", "add", "-A"],
            cwd=checkout,
            check=True,
            capture_output=True,
            timeout=120,
            env=env,
        )
        subprocess.run(
            [
                "git",
                "commit",
                "--quiet",
                "--message",
                "base",
                "--no-verify",
                "--allow-empty",
            ],
            cwd=checkout,
            check=True,
            capture_output=True,
            timeout=120,
            env=env,
        )
    except Exception:
        shutil.rmtree(checkout, ignore_errors=True)
        raise

    return checkout


def remove_checkout(checkout_dir: Path) -> None:
    """Remove an isolated checkout directory created by create_isolated_checkout."""
    if checkout_dir.exists():
        shutil.rmtree(checkout_dir, ignore_errors=True)


def get_diff(cwd: Path) -> str:
    """Get the diff of all changes in a working directory.

    Matches SWE-bench patch extraction: stages new files first so they
    appear in the diff, then diffs against HEAD.
    """
    _run(["add", "-N", "."], cwd=cwd, check=False)
    return _run(["diff", "HEAD", "--no-color", "--no-ext-diff"], cwd=cwd)
