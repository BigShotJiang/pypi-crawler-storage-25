"""Configuration and defaults."""

from __future__ import annotations

from pathlib import Path

# Cache directory for cloned repos
CACHE_DIR = Path.home() / ".mdarena"
REPOS_DIR = CACHE_DIR / "repos"

# Default task set / results directories (relative to cwd)
DEFAULT_TASKS_DIR = "mdarena_tasks"
DEFAULT_RESULTS_DIR = "mdarena_results"

# Mining defaults
DEFAULT_PR_LIMIT = 100
DEFAULT_MIN_CHANGES = 10
DEFAULT_MAX_CHANGES = 1000
DEFAULT_MAX_FILES = 50  # Raised from 20 for monorepo compatibility

# Runner defaults
DEFAULT_BUDGET_PER_TASK = 5.00
DEFAULT_MODEL = "claude-opus-4-6"
DEFAULT_PARALLEL = 4  # Concurrent agent runs

# Test execution defaults
DEFAULT_TEST_TIMEOUT = 900  # seconds per test suite run (15 min)
MAX_PASS_TO_PASS = 500  # Limit PASS_TO_PASS list size

# Bot authors to exclude
BOT_AUTHORS = frozenset(
    {
        "dependabot[bot]",
        "dependabot",
        "renovate[bot]",
        "renovate",
        "github-actions[bot]",
        "codecov[bot]",
        "mergify[bot]",
        "greenkeeper[bot]",
        "snyk-bot",
        "depfu[bot]",
        "allcontributors[bot]",
    }
)

# Labels that indicate dependency/bot PRs
EXCLUDED_LABELS = frozenset(
    {
        "dependencies",
        "deps",
        "renovate",
        "dependabot",
        "automated",
    }
)

# File patterns that are not "real code"
NON_CODE_PATTERNS = frozenset(
    {
        "package-lock.json",
        "yarn.lock",
        "pnpm-lock.yaml",
        "Gemfile.lock",
        "poetry.lock",
        "Cargo.lock",
        "go.sum",
        "composer.lock",
    }
)

# Test file patterns (for extracting test_patch)
TEST_FILE_PATTERNS = (
    "test_",
    "_test.",
    ".test.",
    ".spec.",
    "/tests/",
    "/test/",
    "/__tests__/",
    "/spec/",
)
