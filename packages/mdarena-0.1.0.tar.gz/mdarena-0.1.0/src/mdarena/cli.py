"""mdarena CLI: Benchmark your CLAUDE.md against your own PRs."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from mdarena.config import (
    DEFAULT_BUDGET_PER_TASK,
    DEFAULT_MAX_CHANGES,
    DEFAULT_MAX_FILES,
    DEFAULT_MIN_CHANGES,
    DEFAULT_MODEL,
    DEFAULT_PARALLEL,
    DEFAULT_PR_LIMIT,
    DEFAULT_RESULTS_DIR,
    DEFAULT_TASKS_DIR,
    DEFAULT_TEST_TIMEOUT,
)


def _version_callback(value: bool) -> None:
    if value:
        from mdarena import __version__

        typer.echo(f"mdarena {__version__}")
        raise typer.Exit()


app = typer.Typer(
    name="mdarena",
    help="Benchmark your CLAUDE.md against your own PRs.",
    no_args_is_help=True,
)
console = Console()


@app.callback()
def main(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            "-V",
            callback=_version_callback,
            is_eager=True,
            help="Show version",
        ),
    ] = None,
) -> None:
    pass


@app.command(name="load-swebench")
def load_swebench_cmd(
    dataset: Annotated[
        str,
        typer.Argument(
            help="Dataset: lite, verified, full, or a HuggingFace path",
        ),
    ] = "lite",
    output: Annotated[
        Path,
        typer.Option("-o", "--output", help="Output directory"),
    ] = Path(DEFAULT_TASKS_DIR),
    split: Annotated[
        str,
        typer.Option(help="Dataset split"),
    ] = "test",
    limit: Annotated[
        int | None,
        typer.Option("-n", "--limit", help="Max instances to load"),
    ] = None,
    instance_ids: Annotated[
        str | None,
        typer.Option(
            "--instance-ids",
            help="Comma-separated instance IDs",
        ),
    ] = None,
) -> None:
    """Load tasks from a SWE-bench dataset (requires: pip install datasets)."""
    from mdarena.mining.swebench_loader import load_swebench

    ids = [i.strip() for i in instance_ids.split(",")] if instance_ids else None
    tasks = load_swebench(
        dataset_name=dataset,
        split=split,
        limit=limit,
        instance_ids=ids,
        output_dir=output,
    )
    console.print(f"\n[bold green]Done![/bold green] {len(tasks)} tasks saved to {output}/")


@app.command()
def mine(
    repo: Annotated[
        str,
        typer.Argument(help="GitHub repo (owner/repo)"),
    ],
    output: Annotated[
        Path,
        typer.Option("-o", "--output", help="Output directory"),
    ] = Path(DEFAULT_TASKS_DIR),
    limit: Annotated[
        int,
        typer.Option("-n", "--limit", help="Max PRs to fetch"),
    ] = DEFAULT_PR_LIMIT,
    since: Annotated[
        str | None,
        typer.Option(
            help="Only PRs merged after this date (YYYY-MM-DD)",
        ),
    ] = None,
    min_changes: Annotated[
        int,
        typer.Option(help="Min lines changed"),
    ] = DEFAULT_MIN_CHANGES,
    max_changes: Annotated[
        int,
        typer.Option(help="Max lines changed"),
    ] = DEFAULT_MAX_CHANGES,
    max_files: Annotated[
        int,
        typer.Option(help="Max files changed per PR"),
    ] = DEFAULT_MAX_FILES,
    test_cmd: Annotated[
        str | None,
        typer.Option("--test-cmd", help="Test command (e.g. 'make test')"),
    ] = None,
    setup_cmd: Annotated[
        str | None,
        typer.Option("--setup-cmd", help="Setup command (e.g. 'npm install')"),
    ] = None,
    env_file: Annotated[
        Path | None,
        typer.Option("--env-file", help="Env file for tests (KEY=VALUE)"),
    ] = None,
    detect_tests: Annotated[
        bool,
        typer.Option(
            "--detect-tests/--no-detect-tests",
            help="Auto-detect test commands from CI/package files",
        ),
    ] = True,
    extract_tests: Annotated[
        bool,
        typer.Option(
            "--extract-tests/--no-extract-tests",
            help="Run tests at each commit to build FAIL_TO_PASS lists (slow)",
        ),
    ] = False,
    path_filter: Annotated[
        str | None,
        typer.Option(
            "--path-filter",
            "--scope",
            help="Scope to a subdirectory (e.g. 'ui/app-ui' or 'backend')",
        ),
    ] = None,
    redact: Annotated[
        bool,
        typer.Option(
            "--redact/--no-redact",
            help=(
                "LLM-rewrite PR descriptions to strip file paths, function "
                "names, and issue references so the agent can't use them as "
                "a roadmap to the gold patch. On by default for benchmark "
                "integrity; pass --no-redact to keep raw PR text."
            ),
        ),
    ] = True,
    api_key: Annotated[
        str | None,
        typer.Option(
            "--api-key",
            help="Anthropic API key for Claude CLI (used for redaction)",
        ),
    ] = None,
    utility_model: Annotated[
        str | None,
        typer.Option(
            "--utility-model",
            help="Model for utility LLM calls (redaction, triage). Defaults to haiku.",
        ),
    ] = None,
) -> None:
    """Mine merged PRs from a repo and build a task set."""
    from mdarena.mining.pr_fetcher import fetch_prs
    from mdarena.mining.pr_filter import filter_prs
    from mdarena.mining.task_builder import build_tasks

    if path_filter:
        path_filter = path_filter.strip("/")
        console.print(f"[bold]Scoping to: {path_filter}/[/bold]")

    prs = fetch_prs(repo, limit=limit, since=since)
    if not prs:
        console.print("[red]No PRs found.[/red]")
        raise typer.Exit(1)

    filtered = filter_prs(
        prs,
        min_changes=min_changes,
        max_changes=max_changes,
        max_files=max_files,
        path_prefix=path_filter,
    )
    if not filtered:
        console.print("[red]No PRs passed filtering.[/red]")
        raise typer.Exit(1)

    # Detect or use provided test config
    test_config = None
    if test_cmd or detect_tests:
        from mdarena.discovery.detect import detect_test_config
        from mdarena.utils.git import clone_repo

        repo_path = clone_repo(repo)
        test_config = detect_test_config(
            repo_path=repo_path,
            user_test_cmd=test_cmd,
            user_setup_cmd=setup_cmd,
            env_file=env_file,
            scope_path=path_filter,
        )
        if test_config:
            console.print(
                f"[green]Test command ({test_config.source}): {test_config.test_cmd}[/green]"
            )
        else:
            console.print("[yellow]Could not detect test command. Mining without tests.[/yellow]")

    if redact:
        console.print("[bold]Redacting implementation hints from PR descriptions...[/bold]")

    tasks = build_tasks(
        filtered,
        repo,
        output,
        test_config=test_config,
        path_filter=path_filter,
        extract_tests=extract_tests,
        redact=redact,
        api_key=api_key,
        utility_model=utility_model,
    )
    console.print(f"\n[bold green]Done![/bold green] {len(tasks)} tasks saved to {output}/")


@app.command()
def run(
    context_file: Annotated[
        list[Path] | None,
        typer.Option(
            "-c",
            "--context-file",
            help="Context files to compare (repeatable)",
        ),
    ] = None,
    tasks: Annotated[
        Path,
        typer.Option("-t", "--tasks", help="Task set directory"),
    ] = Path(DEFAULT_TASKS_DIR),
    output: Annotated[
        Path,
        typer.Option("-o", "--output", help="Results directory"),
    ] = Path(DEFAULT_RESULTS_DIR),
    budget: Annotated[
        float,
        typer.Option(help="Max USD per task per condition"),
    ] = DEFAULT_BUDGET_PER_TASK,
    model: Annotated[
        str,
        typer.Option(help="Model to use"),
    ] = DEFAULT_MODEL,
    no_baseline: Annotated[
        bool,
        typer.Option("--no-baseline", help="Skip baseline (no context) run"),
    ] = False,
    max_tasks: Annotated[
        int | None,
        typer.Option(help="Limit number of tasks"),
    ] = None,
    skip_existing: Annotated[
        bool,
        typer.Option(
            "--skip-existing",
            help="Skip already-completed runs",
        ),
    ] = False,
    run_tests: Annotated[
        bool,
        typer.Option(
            "--run-tests/--no-run-tests",
            help="Run tests after agent (if task has test commands)",
        ),
    ] = True,
    test_timeout: Annotated[
        int,
        typer.Option("--test-timeout", help="Timeout per test run (seconds)"),
    ] = DEFAULT_TEST_TIMEOUT,
    path_filter: Annotated[
        str | None,
        typer.Option(
            "--path-filter",
            "--scope",
            help="Scope to a subdirectory (overrides value from manifest)",
        ),
    ] = None,
    parallel: Annotated[
        int,
        typer.Option(
            "-j",
            "--parallel",
            help="Number of concurrent agent runs",
        ),
    ] = DEFAULT_PARALLEL,
    api_key: Annotated[
        str | None,
        typer.Option(
            "--api-key",
            help="Anthropic API key for Claude CLI (overrides ANTHROPIC_API_KEY env var)",
        ),
    ] = None,
    utility_model: Annotated[
        str | None,
        typer.Option(
            "--utility-model",
            help="Model for utility LLM calls (triage). Defaults to haiku.",
        ),
    ] = None,
) -> None:
    """Run benchmark: compare context files head-to-head + baseline."""
    from mdarena.runner.orchestrator import build_conditions, run_benchmark

    if context_file is None:
        context_file = []

    if not context_file and no_baseline:
        console.print("[red]Need at least one --context-file when using --no-baseline[/red]")
        raise typer.Exit(1)

    if not context_file:
        console.print("[yellow]No --context-file provided. Running baseline only.[/yellow]")

    for f in context_file:
        if not f.exists():
            console.print(f"[red]Context file not found: {f}[/red]")
            raise typer.Exit(1)

    manifest, task_instances = _load_tasks(tasks, limit=max_tasks)

    if not task_instances:
        console.print("[red]No task instances found.[/red]")
        raise typer.Exit(1)

    # Use path_filter from CLI, falling back to what was used during mining
    effective_path_filter = path_filter or manifest.get("path_filter")
    if effective_path_filter:
        effective_path_filter = effective_path_filter.strip("/")
        console.print(f"[bold]Scoping to: {effective_path_filter}/[/bold]")

    console.print(f"Loaded {len(task_instances)} tasks from {tasks}/")

    # Build conditions
    conditions = build_conditions(
        context_files=[f.resolve() for f in context_file],
        include_baseline=not no_baseline,
    )

    # Run
    run_benchmark(
        tasks=task_instances,
        conditions=conditions,
        output_dir=output,
        budget=budget,
        model=model,
        skip_existing=skip_existing,
        run_tests=run_tests,
        test_timeout=test_timeout,
        path_filter=effective_path_filter,
        parallel=parallel,
        api_key=api_key,
        utility_model=utility_model,
    )


@app.command()
def report(
    results: Annotated[
        Path,
        typer.Option("-r", "--results", help="Results directory"),
    ] = Path(DEFAULT_RESULTS_DIR),
    format: Annotated[
        str,
        typer.Option(
            "--format",
            help="Output format: terminal, json, csv",
        ),
    ] = "terminal",
    output: Annotated[
        Path | None,
        typer.Option("-o", "--output", help="Output file"),
    ] = None,
) -> None:
    """Analyze results and produce a comparison report."""
    from mdarena.evaluation.diff_scorer import score_run
    from mdarena.evaluation.metrics import build_report
    from mdarena.models import AgentRun
    from mdarena.reporting.export import export_csv, export_json
    from mdarena.reporting.terminal import print_report

    conditions_path = results / "conditions.json"
    if not conditions_path.exists():
        console.print(f"[red]No conditions.json found in {results}. Run 'mdarena run' first.[/red]")
        raise typer.Exit(1)

    conditions_meta = json.loads(conditions_path.read_text())

    tasks_dir = _find_tasks_dir(results)
    if not tasks_dir:
        console.print("[red]Cannot find task set. Ensure mdarena_tasks/ exists.[/red]")
        raise typer.Exit(1)

    runs_dir = results / "runs"
    if not runs_dir.exists():
        console.print("[red]No runs found.[/red]")
        raise typer.Exit(1)

    manifest, task_list = _load_tasks(tasks_dir)
    gold_tasks = {t.instance_id: t for t in task_list}

    eval_results = []
    for run_file in sorted(runs_dir.glob("*.json")):
        agent_run = AgentRun.model_validate_json(run_file.read_text())
        task = gold_tasks.get(agent_run.instance_id)
        gold = task.patch if task else ""
        eval_results.append(score_run(agent_run, gold, task=task))

    if not eval_results:
        console.print("[yellow]No results to report.[/yellow]")
        raise typer.Exit(1)

    repo = manifest.get("repo", "unknown")

    # Build report
    benchmark_report = build_report(repo, eval_results, conditions_meta)

    # Output
    if format == "json":
        out = output or Path("mdarena_report.json")
        export_json(benchmark_report, out)
        console.print(f"Report saved to {out}")
    elif format == "csv":
        out = output or Path("mdarena_report.csv")
        export_csv(benchmark_report, out)
        console.print(f"Report saved to {out}")
    else:
        print_report(benchmark_report)


@app.command(name="export-swebench")
def export_swebench_cmd(
    tasks: Annotated[
        Path,
        typer.Option("-t", "--tasks", help="Task set directory"),
    ] = Path(DEFAULT_TASKS_DIR),
    output: Annotated[
        Path,
        typer.Option("-o", "--output", help="Output JSONL file"),
    ] = Path("swebench_tasks.jsonl"),
) -> None:
    """Export mdarena tasks as SWE-bench compatible JSONL."""
    _, task_list = _load_tasks(tasks)

    with output.open("w") as f:
        for task in task_list:
            f.write(json.dumps(task.to_swebench_dict()) + "\n")

    console.print(f"[green]Exported {len(task_list)} tasks to {output}[/green]")


def _load_tasks(tasks_dir: Path, *, limit: int | None = None) -> tuple[dict, list]:
    """Load manifest and task instances from a tasks directory.

    Returns (manifest_dict, task_list). Raises typer.Exit on error.
    """
    from mdarena.models import TaskInstance

    manifest_path = tasks_dir / "manifest.json"
    if not manifest_path.exists():
        console.print(
            f"[red]No manifest.json found in {tasks_dir}. Run 'mdarena mine' first.[/red]"
        )
        raise typer.Exit(1)

    manifest = json.loads(manifest_path.read_text())
    entries = manifest["tasks"]
    if limit is not None:
        entries = entries[:limit]

    tasks = []
    for entry in entries:
        task_file = tasks_dir / "tasks" / f"{entry['instance_id']}.json"
        if task_file.exists():
            tasks.append(TaskInstance.model_validate_json(task_file.read_text()))

    return manifest, tasks


def _find_tasks_dir(results_dir: Path) -> Path | None:
    """Try to find the tasks directory relative to results."""
    candidates = [
        results_dir.parent / DEFAULT_TASKS_DIR,
        Path(DEFAULT_TASKS_DIR),
    ]
    for c in candidates:
        resolved = c.resolve()
        if (resolved / "manifest.json").exists():
            return resolved
    return None
