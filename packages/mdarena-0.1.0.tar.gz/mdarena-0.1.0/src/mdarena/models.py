"""Core data models for mdarena."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import BaseModel


class TaskInstance(BaseModel):
    """A benchmark task derived from a merged PR or loaded from SWE-bench.

    Core fields are shared between mdarena-mined tasks and SWE-bench tasks.
    SWE-bench-specific fields (FAIL_TO_PASS, etc.) are optional so the model
    works in both directions:
      - mdarena mine -> TaskInstance (no test commands)
      - SWE-bench dataset -> TaskInstance (with test commands)
      - TaskInstance -> SWE-bench JSONL (for Docker eval, if test fields present)
    """

    # -- Core fields (always present) --
    instance_id: str  # "owner__repo-123"
    repo: str  # "owner/repo"
    base_commit: str  # SHA before the PR / issue fix
    problem_statement: str  # PR body or issue description (the agent's prompt)
    patch: str  # Gold solution diff

    # -- SWE-bench compatible fields --
    FAIL_TO_PASS: list[str] = []  # Test commands that should go fail->pass
    PASS_TO_PASS: list[str] = []  # Test commands that must stay passing
    test_patch: str | None = None  # Test-only subset of the diff
    version: str | None = None  # Package version for env setup
    environment_setup_commit: str | None = None  # Commit for env setup
    hints_text: str | None = None  # Optional hints
    created_at: str | None = None  # ISO timestamp

    # -- Test discovery metadata --
    test_cmd: str | None = None  # Discovered or user-provided test command
    setup_cmd: str | None = None  # Setup command (install deps, etc.)
    test_cmd_source: Literal["user", "ci", "package", "unknown"] | None = None
    test_work_dir: str | None = None  # Subdirectory to run tests in

    # -- mdarena-specific fields (from PR mining) --
    pr_number: int | None = None
    pr_url: str | None = None
    merge_commit: str | None = None  # SHA after merge
    files_changed: list[str] = []
    additions: int = 0
    deletions: int = 0
    labels: list[str] = []
    difficulty: Literal["easy", "medium", "hard"] | None = None
    path_filter: str | None = None  # Subdirectory scope (e.g. "ui/app-ui")

    def has_test_commands(self) -> bool:
        """Whether this task has SWE-bench test commands for Docker eval."""
        return bool(self.FAIL_TO_PASS)

    def has_test_suite(self) -> bool:
        """Whether this task has a runnable test suite (regression or FAIL_TO_PASS)."""
        return bool(self.test_cmd)

    def to_swebench_dict(self) -> dict:
        """Export as a SWE-bench compatible dict (for dataset creation)."""
        return {
            "instance_id": self.instance_id,
            "repo": self.repo,
            "base_commit": self.base_commit,
            "problem_statement": self.problem_statement,
            "patch": self.patch,
            "test_patch": self.test_patch or "",
            "FAIL_TO_PASS": self.FAIL_TO_PASS,
            "PASS_TO_PASS": self.PASS_TO_PASS,
            "version": self.version or "",
            "environment_setup_commit": self.environment_setup_commit or "",
            "hints_text": self.hints_text or "",
            "created_at": self.created_at or "",
        }


class RunCondition(BaseModel):
    """A single benchmark condition (baseline or a specific context file/directory).

    context_file can be:
      - None: baseline (no CLAUDE.md)
      - Path to a file: single CLAUDE.md placed at repo root
      - Path to a directory: tree of CLAUDE.md files mirroring repo structure
        e.g. my-configs/CLAUDE.md -> root, my-configs/packages/api/CLAUDE.md -> packages/api/
    """

    name: str  # "baseline", "claude_v1", etc.
    context_file: Path | None = None  # None = baseline (no context)

    @classmethod
    def baseline(cls) -> RunCondition:
        return cls(name="baseline", context_file=None)

    @classmethod
    def from_file(cls, path: Path) -> RunCondition:
        return cls(name=path.stem, context_file=path)


class AgentRun(BaseModel):
    """Result of running the agent on one task under one condition."""

    instance_id: str
    condition_name: str
    patch_produced: str | None = None  # The diff the agent generated
    exit_reason: Literal["success", "budget_exceeded", "error", "timeout"] = "success"
    cost_usd: float = 0.0
    duration_ms: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    model: str = ""
    session_id: str = ""
    error: str | None = None

    # -- Test execution results --
    tests_ran: bool = False
    fail_to_pass_passed: bool | None = None
    pass_to_pass_passed: bool | None = None
    test_resolved: bool | None = None  # Both passed = resolved
    test_error: str | None = None
    new_test_failures: list[str] = []  # Tests that newly failed after agent patch
    targeted_tests: list[str] = []  # Test files selected for targeted testing


class SwebenchPrediction(BaseModel):
    """SWE-bench compatible prediction format.

    This is the standard JSONL format consumed by:
      python -m swebench.harness.run_evaluation --predictions_path <file>
    """

    instance_id: str
    model_name_or_path: str
    model_patch: str  # The unified diff


class EvalResult(BaseModel):
    """Evaluation of one agent run against the gold patch."""

    instance_id: str
    condition_name: str
    file_overlap: float  # 0.0-1.0, Jaccard of files modified
    hunk_overlap: float  # 0.0-1.0, line-level overlap
    exact_match: bool
    test_resolved: bool | None = None  # True if tests pass after agent patch
    tests_available: bool = False  # Whether test commands existed for this task
    cost_usd: float = 0.0
    duration_ms: int = 0
    tokens_total: int = 0


class ConditionSummary(BaseModel):
    """Aggregate metrics for one condition across all tasks."""

    condition_name: str
    context_file: str | None
    num_tasks: int
    resolution_rate: float  # Blended: test pass/fail where available, diff overlap otherwise
    avg_file_overlap: float
    avg_hunk_overlap: float
    avg_cost: float
    avg_tokens: float
    avg_duration_ms: float
    test_resolution_rate: float | None = None  # % resolved by tests (when available)
    num_tasks_with_tests: int = 0


class BenchmarkReport(BaseModel):
    """Full benchmark report comparing multiple conditions."""

    repo: str
    num_tasks: int
    conditions: list[ConditionSummary]
    eval_results: list[EvalResult]
    winner: str | None = None  # condition name with highest resolution rate
    loser: str | None = None  # condition name with lowest resolution rate
