"""mdarena: Benchmark your CLAUDE.md against your own PRs."""

__version__ = "0.1.0"
