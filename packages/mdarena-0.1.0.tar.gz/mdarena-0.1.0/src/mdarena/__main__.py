from mdarena.cli import app

app()
