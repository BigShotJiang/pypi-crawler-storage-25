#!/usr/bin/env python3
"""
Windows 原生明显通知的手工验证脚本。

该测试默认跳过，避免在非 Windows / 非交互 CI 环境下导入时直接执行。
如需手工验证，可运行：
    VIBE_NOTIFICATION_RUN_OBVIOUS_TEST=1 pytest tests/test_obvious_notification.py -q -s
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time

import pytest


PS_COMMAND = r"""
Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -AssemblyName System.Windows.Forms

try {
    $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where { $_.Name -eq 'AsTask' } | Where {$_.GetParameters().Count -eq 1})[0]
    Function Await($WinRtTask, $ResultSig) {
        $asTask = $asTaskGeneric.MakeGenericMethod($ResultSig)
        $netTask = $asTask.Invoke($null, @($WinRtTask))
        $netTask.Wait(-1) | Out-Null
    }
    [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
    [Windows.UI.Notifications.ToastNotification, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
    [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom, ContentType = WindowsRuntime] | Out-Null
    $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
    $xml.LoadXml("<toast scenario='reminder'><visual><binding template='ToastGeneric'><text>WSL测试通知</text><text>如果你看到这条消息，说明通知系统正常工作！</text></binding></visual></toast>")
    $toast = New-Object Windows.UI.Notifications.ToastNotification($xml)
    $notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("WSL Test")
    $notifier.Show($toast)
    Write-Host "Toast sent"
} catch {
    Write-Host "Toast failed: $_"
}

Start-Sleep 0.5
[console]::beep(800, 300)
"""
def test_windows_obvious_notification(request):
    if os.environ.get("VIBE_NOTIFICATION_RUN_OBVIOUS_TEST") != "1":
        pytest.skip("需要设置 VIBE_NOTIFICATION_RUN_OBVIOUS_TEST=1 才运行手工通知测试")

    if sys.platform != "win32":
        pytest.skip("仅在 Windows 环境下运行")

    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if not powershell:
        pytest.skip("未找到 PowerShell")

    print("发送测试通知...")
    result = subprocess.run([powershell, "-Command", PS_COMMAND], capture_output=True, text=True)
    print("输出:", result.stdout)
    if result.stderr:
        print("错误:", result.stderr)
    print("返回码:", result.returncode)

    time.sleep(3)

    assert result.returncode == 0
