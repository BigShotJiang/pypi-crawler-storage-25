"""Service generation helpers backed by bundled cookiecutter templates."""

import os
import shutil
from pathlib import Path
from typing import Any

from cookiecutter.main import cookiecutter

from .resources import templates_path


def _build_context(
    *,
    name: str,
    description: str,
    port: int,
    model_name: str,
    model_name_plural: str,
    has_database: bool,
    database: str,
    has_delegates: bool,
    upstreams: str,
    has_workers: bool,
    broker: str,
    has_caching: bool,
    cache_backend: str,
    has_structured_logging: bool,
) -> dict[str, Any]:
    return {
        "service_name": name,
        "service_description": description,
        "port": str(port),
        "model_name": model_name,
        "model_name_plural": model_name_plural,
        "has_database": has_database,
        "database": database,
        "has_delegates": has_delegates,
        "upstreams": upstreams,
        "has_workers": has_workers,
        "broker": broker,
        "has_caching": has_caching,
        "cache_backend": cache_backend,
        "has_structured_logging": has_structured_logging,
    }


def generate_service(
    *,
    name: str,
    output_dir: Path,
    description: str,
    port: int,
    model_name: str,
    model_name_plural: str,
    has_database: bool,
    database: str,
    has_delegates: bool,
    upstreams: str,
    has_workers: bool,
    broker: str,
    has_caching: bool,
    cache_backend: str,
    has_structured_logging: bool,
    overwrite_if_exists: bool,
) -> Path:
    """Generate a service from the bundled cookiecutter-service template."""
    output_root = output_dir.resolve()
    src_dir = output_root / "src"
    src_dir.mkdir(parents=True, exist_ok=True)
    target = src_dir / name.replace("-", "_")

    if target.exists() and any(target.iterdir()) and not overwrite_if_exists:
        raise FileExistsError(
            f"Target directory already exists and is not empty: {target}. Use --force to overwrite."
        )

    if has_delegates and not upstreams.strip():
        raise ValueError("--upstreams is required when --delegates is enabled")

    context = _build_context(
        name=name,
        description=description,
        port=port,
        model_name=model_name,
        model_name_plural=model_name_plural,
        has_database=has_database,
        database=database,
        has_delegates=has_delegates,
        upstreams=upstreams,
        has_workers=has_workers,
        broker=broker,
        has_caching=has_caching,
        cache_backend=cache_backend,
        has_structured_logging=has_structured_logging,
    )

    # Suppress bytecode generation during template rendering.
    old_dontwritebytecode = os.environ.get("PYTHONDONTWRITEBYTECODE")
    try:
        os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
        with templates_path() as template_root:
            template = template_root / "cookiecutter-service"
            generated = cookiecutter(
                str(template),
                no_input=True,
                extra_context=context,
                output_dir=str(src_dir),
                overwrite_if_exists=overwrite_if_exists,
            )
    finally:
        if old_dontwritebytecode is None:
            os.environ.pop("PYTHONDONTWRITEBYTECODE", None)
        else:
            os.environ["PYTHONDONTWRITEBYTECODE"] = old_dontwritebytecode

    # Clean up any __pycache__ that may have been created despite PYTHONDONTWRITEBYTECODE.
    generated_path = Path(generated).resolve()
    for pycache_dir in generated_path.rglob("__pycache__"):
        shutil.rmtree(pycache_dir, ignore_errors=True)

    # Move docker files to workspace root and update Dockerfile
    _move_docker_files_to_workspace_root(generated_path, output_root, name)

    return generated_path


def _move_docker_files_to_workspace_root(
    service_path: Path, workspace_root: Path, service_name: str
) -> None:
    """Move docker-compose.yml and Dockerfile to workspace root, updating paths in Dockerfile."""
    service_name_snake = service_name.replace("-", "_")

    # Move docker-compose.yml to workspace root (create if doesn't exist)
    docker_compose_src = service_path / "docker-compose.yml"
    docker_compose_dst = workspace_root / "docker-compose.yml"
    if docker_compose_src.exists():
        if not docker_compose_dst.exists():
            shutil.copy2(docker_compose_src, docker_compose_dst)
        docker_compose_src.unlink()

    # Move Dockerfile to workspace root as Dockerfile.{service_name}
    dockerfile_src = service_path / "Dockerfile"
    dockerfile_dst = workspace_root / f"Dockerfile.{service_name}"
    if dockerfile_src.exists():
        # Read and update the Dockerfile to account for workspace root context
        dockerfile_content = dockerfile_src.read_text()
        # Update COPY . to COPY src/{service_name}/
        dockerfile_content = dockerfile_content.replace(
            "COPY . /app", f"COPY src/{service_name_snake} /app"
        )
        dockerfile_dst.write_text(dockerfile_content)
        dockerfile_src.unlink()
