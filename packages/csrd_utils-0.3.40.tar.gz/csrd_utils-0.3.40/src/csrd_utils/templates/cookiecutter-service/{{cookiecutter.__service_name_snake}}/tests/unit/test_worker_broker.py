"""Unit tests for worker broker dependency wiring."""

import importlib

from {{cookiecutter.__service_name_snake}}.dependencies.worker_broker import get_worker_broker_url
from {{cookiecutter.__service_name_snake}}.workers.tasks import ping_task


def test_worker_broker_url_uses_expected_scheme() -> None:
    broker_url = get_worker_broker_url()
    assert broker_url.startswith(("redis://", "amqp://"))


def test_ping_task_returns_pong() -> None:
    assert ping_task() == "pong"


def test_worker_broker_url_reflects_runtime_settings() -> None:
    settings_mod = importlib.import_module("app.settings")
    original = settings_mod.settings.worker_broker_url
    try:
        settings_mod.settings.worker_broker_url = "amqp://runtime-test"
        assert get_worker_broker_url() == "amqp://runtime-test"
    finally:
        settings_mod.settings.worker_broker_url = original
