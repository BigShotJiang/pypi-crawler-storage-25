"""ms_graph — A Python client for the Microsoft Graph API."""

from ms_graph.client import MicrosoftGraphClient

__all__ = ["MicrosoftGraphClient"]
