from enum import Enum
import json
from typing import Union
from ms_graph.session import GraphSession


def build_endpoint(inputs: dict) -> str:
    """Builds the endpoint for the Range object.

    ### Parameters
    ----
    inputs : dict
        The `locals()` of the function.

    ### Raises
    ----
    ValueError:
        If an item id or item path is not specified
        an error will be raised.

    ### Returns
    ----
    str:
        The full URL path.
    """

    item_id = inputs.get("item_id", None)
    item_path = inputs.get("item_path", None)
    worksheet_name_or_id = inputs.get("worksheet_name_or_id", None)
    address = inputs.get("address", None)
    name = inputs.get("name", None)
    table_name_or_id = inputs.get("table_name_or_id", None)
    column_name_or_id = inputs.get("column_name_or_id", None)

    if item_id:
        workbook_path = f"/me/drive/items/{item_id}/workbook/"
    elif item_path:
        workbook_path = f"/me/drive/root:/{item_path}:/workbook/"
    else:
        raise ValueError("Must specify an Item ID or Item Path.")

    if (worksheet_name_or_id and address):
        range_path = f"worksheets/{worksheet_name_or_id}/range(address='{address}')"
    elif name:
        range_path = f"names/{name}/range"
    elif (table_name_or_id and column_name_or_id):
        range_path = f"tables/{table_name_or_id}/columns/{column_name_or_id}/range"

    return workbook_path + range_path


class Table:

    """
    ### Overview:
    ----
    Represents an Excel Table Object, also called an
    Excel List Object.
    """

    def __init__(self, session: object) -> None:
        """Initializes the `Table` object.

        # Parameters
        ----
        session : object
            An authenticated session for our Microsoft Graph Client.
        """

        # Set the session.
        self.graph_session: GraphSession = session

    @staticmethod
    def build_endpoint(**kwargs):
        """ Build endpoint for MS Graph Session depending
        and the resource required to be called """

        item_id = kwargs.get("item_id", None)
        workbook_path = kwargs.get("workbook_path", None)
        item_path = kwargs.get("item_path", None)
        worksheet_name_or_id = kwargs.get("worksheet_name_or_id", None)
        table_name_or_id = kwargs.get("table_name_or_id", None)
        endpoint_resource = kwargs.get("endpoint_resource", None)

        if item_id:
            workbook_path = f"/me/drive/items/{item_id}/workbook/"
        elif item_path:
            workbook_path = f"/me/drive/root:/{item_path}:/workbook/"
        else:
            raise ValueError("Must specify an Item ID or Item Path.")


        if (worksheet_name_or_id and table_name_or_id):
            table_path = f"worksheets/{worksheet_name_or_id}/tables/{table_name_or_id}"
        elif table_name_or_id:
            table_path = f"tables/{table_name_or_id}"

        endpoint = workbook_path + table_path

        if endpoint_resource == "add":
            endpoint = endpoint + "/add"
        elif endpoint_resource == "rows":
            endpoint = endpoint + "/rows"
        elif endpoint_resource == "columns":
            endpoint = endpoint + "/columns"
        elif endpoint_resource == "range":
            endpoint = endpoint + "/range"
        elif endpoint_resource == "headerrowrange":
            endpoint = endpoint + "/headerrowrange"
        elif endpoint_resource == "databodyrange":
            endpoint = endpoint + "/databodyrange"

        return endpoint

    def get_table(
        self,
        table_name_or_id: str = None,
        worksheet_name_or_id: str = None,
        item_id: str = None,
        item_path: str = None,
    ) -> dict:
        """Retrieve the properties and relationships of table object.

        ### Parameters
        ----
        table_name_or_id : str (optional, Default=None)
            The name of the table or the resource id.

        worksheet_name_or_id : str (optional, Default=None)
            The name of the worksheet or the resource id.

        item_id : str (optional, Default=None)
            The Drive Item Resource ID.

        item_path : str (optional, Default=None)
            The Item Path. An Example would be the following:
            `/TestFolder/TestFile.txt`

        ### Returns
        ----
        dict:
            A WorkbookTable object.
        """

        endpoint = self.build_endpoint(
            table_name_or_id=table_name_or_id,
            worksheet_name_or_id=worksheet_name_or_id,
            item_id=item_id,
            item_path=item_path
        )

        content = self.graph_session.make_request(
            method="get",
            endpoint=endpoint
        )

        return content

    def add_table(
        self,
        address: str,
        has_headers: bool,
        table_name_or_id: str = None,
        worksheet_name_or_id: str = None,
        item_id: str = None,
        item_path: str = None,
    ) -> dict:
        """Create a new WorkbookTable Object.

        ### Overview
        ----
        The range source address determines the worksheet under
        which the table will be added. If the table cannot be
        added (e.g., because the address is invalid, or the table
        would overlap with another table), an error will be thrown.

        ### Parameters
        ----
        address : str
            Address or name of the range object representing the
            data source. If the address does not contain a sheet
            name, the currently-active sheet is used.

            imported has column labels. If the source does not
            contain headers (i.e,. when this property set to
            `False`), Excel will automatically generate header
            shifting the data down by one row.

        table_name_or_id : str (optional, Default=None)
            The name of the table or the resource id.

        worksheet_name_or_id : str (optional, Default=None)
            The name of the worksheet or the resource id.

        item_id : str (optional, Default=None)
            The Drive Item Resource ID.

        item_path : str (optional, Default=None)
            The Item Path. An Example would be the following:
            `/TestFolder/TestFile.txt`

        ### Returns
        ----
        dict:
            A WorkbookTable Object.
        """
        # build endpoint
        endpoint=self.build_endpoint(
            table_name_or_id=table_name_or_id,
            worksheet_name_or_id=worksheet_name_or_id,
            item_id=item_id,
            item_path=item_path,
            endpoint_resource="add"
        )

        body = {"address": address, "hasHeaders": has_headers}

        content = self.graph_session.make_request(
            method="post",
            json=body,
            additional_headers={"Content-type": "application/json"},
            endpoint=endpoint
        )

        return content

    def update_table(
        self,
        name: str = None,
        show_headers: bool = None,
        show_totals: bool = None,
        style: Union[str, Enum] = None,
        table_name_or_id: str = None,
        worksheet_name_or_id: str = None,
        item_id: str = None,
        item_path: str = None,
    ):
        """Update the properties of table object.

        ### Parameters
        ----
        name : str (optional, Default=None)
            The name of the table.

        show_headers : bool (optional, Default=None)
            Indicates whether the header row is visible or not. This
            value can be set to show or remove the header row.

        show_totals : bool (optional, Default=None)
            Indicates whether the total row is visible or not. This
            value can be set to show or remove the total row.

        style : Union[str, Enum] (optional, Default=None)
            Constant value that represents the Table style. The possible
            values are: `TableStyleLight1` through `TableStyleLight21`,
            `TableStyleMedium1` through `TableStyleMedium28`, `TableStyleDark1`
            through `TableStyleDark11`. A custom user-defined style
            present in the workbook can also be specified.

        table_name_or_id : str (optional, Default=None)
            The name of the table or the resource id.

        worksheet_name_or_id : str (optional, Default=None)
            The name of the worksheet or the resource id.

        item_id : str (optional, Default=None)
            The Drive Item Resource ID.

        item_path : str (optional, Default=None)
            The Item Path. An Example would be the following:
            `/TestFolder/TestFile.txt`

        ### Returns
        ----
        dict:
            A WorkbookTable object.
        """
        #build endpoint
        endpoint=self.build_endpoint(
            item_id=item_id,
            item_path=item_path,
            worksheet_name_or_id=worksheet_name_or_id,
            table_name_or_id=table_name_or_id
        )

        if isinstance(style, Enum):
            style = style.value

        body = {
            "name": name,
            "showHeaders": show_headers,
            "showTotals": show_totals,
            "style": style
        }

        content = self.graph_session.make_request(
            method="patch",
            json=body,
            additional_headers={"Content-type": "application/json"},
            endpoint=endpoint
        )

        return content

    def list_table_rows(
        self,
        table_name_or_id: str = None,
        worksheet_name_or_id: str = None,
        item_id: str = None,
        item_path: str = None) -> dict:

        """ lists table rows """

        endpoint = self.build_endpoint(
            table_name_or_id=table_name_or_id,
            worksheet_name_or_id=worksheet_name_or_id,
            item_id=item_id,
            item_path=item_path,
            endpoint_resource="rows"
        )

        content = self.graph_session.make_request(
            method="get",
            additional_headers={"Content-type": "application/json"},
            endpoint=endpoint
        )

        return content

    def create_table_rows(
        self,
        index_row: int = None,
        values_list: json = None,
        table_name_or_id: str = None,
        worksheet_name_or_id: str = None,
        item_id: str = None,
        item_path: str = None) -> dict:

        # build endpoint
        endpoint=self.build_endpoint(
            item_id=item_id,
            item_path=item_path,
            worksheet_name_or_id=worksheet_name_or_id,
            table_name_or_id=table_name_or_id,
            endpoint_resource="rows"
        )

        """ lists table rows """

        if index_row is not None:
            body = {
                "index": index_row,
                "values": values_list
            }
        elif index_row is None:
            body = {
                "values": values_list
            }


        content = self.graph_session.make_request(
            method="post",
            json=body,
            additional_headers={"Content-type": "application/json"},
            endpoint=endpoint
        )

        return content

    def list_table_columns(
        self,
        table_name_or_id: str = None,
        worksheet_name_or_id: str = None,
        item_id: str = None,
        item_path: str = None
    ) -> dict:

        # build endpoint
        endpoint=self.build_endpoint(
            item_id=item_id,
            item_path=item_path,
            worksheet_name_or_id=worksheet_name_or_id,
            table_name_or_id=table_name_or_id,
            endpoint_resource="columns"
        )

        content = self.graph_session.make_request(
            method="get",
            additional_headers={"Content-type": "application/json"},
            endpoint=endpoint
        )

        return content

    def get_table_range(
        self,
        table_name_or_id: str = None,
        worksheet_name_or_id: str = None,
        item_id: str = None,
        item_path: str = None) -> dict:

        # build endpoint
        endpoint=self.build_endpoint(
            item_id=item_id,
            item_path=item_path,
            worksheet_name_or_id=worksheet_name_or_id,
            table_name_or_id=table_name_or_id,
            endpoint_resource="range"
        )

        content = self.graph_session.make_request(
            method = "get",
            additional_headers = {"content-type": "application/json"},
            endpoint = endpoint
        )

        return content

    def get_header_row_range(
        self,
        table_name_or_id: str = None,
        worksheet_name_or_id: str = None,
        item_id: str = None,
        item_path: str = None
    ) -> dict:

        #build endpoint
        endpoint = self.build_endpoint(
            item_id=item_id,
            item_path=item_path,
            worksheet_name_or_id=worksheet_name_or_id,
            table_name_or_id=table_name_or_id,
            endpoint_resource="headerrowrange"
        )

        content = self.graph_session.make_request(
            method = "get",
            additional_headers = {"content-type": "application/json"},
            endpoint = endpoint
        )

        return content

    def get_data_body_range(
        self,
        table_name_or_id: str = None,
        worksheet_name_or_id: str = None,
        item_id: str = None,
        item_path: str = None
    ) -> dict:

        #build endpoint
        endpoint = self.build_endpoint(
            item_id=item_id,
            item_path=item_path,
            worksheet_name_or_id=worksheet_name_or_id,
            table_name_or_id=table_name_or_id,
            endpoint_resource="databodyrange"
        )

        content = self.graph_session.make_request(
            method = "get",
            additional_headers = {"content-type": "application/json"},
            endpoint = endpoint
        )

        return content
