""" logger setup to configure logger """

# logger_setup.py
from logpy import get_logger

# Initiate logging
log = get_logger(__name__)
