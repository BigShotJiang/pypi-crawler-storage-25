"""Authsome CLI package."""
