from datetime import date
from uuid import UUID

from pydantic import BaseModel

from shared_models.enums import AvailabilityStatus


class AvailabilityDayDTO(BaseModel):
    """
    Describes availability status for a single day in a calendar view.

    This DTO is used by tenant and listing interfaces to render each day
    with the corresponding availability state.
    """

    date: date
    status: AvailabilityStatus


class InscriptionAvailabilityDTO(BaseModel):
    """
    Represents day-by-day availability for a housing inscription period.

    This DTO groups a requested date window and the computed status of each
    day so consuming clients can build visual calendars consistently.
    """

    housing_inscription_id: UUID
    from_date: date
    to_date: date
    days: list[AvailabilityDayDTO]
