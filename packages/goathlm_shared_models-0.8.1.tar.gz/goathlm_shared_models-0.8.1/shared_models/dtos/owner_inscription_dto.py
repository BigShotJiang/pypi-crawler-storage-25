from datetime import date
from uuid import UUID

from pydantic import BaseModel, Field


class OwnerInscriptionCreateDTO(BaseModel):
    """
    Data Transfer Object for creating new housing inscriptions.

    This DTO encapsulates the required and optional fields needed to
    create a new rental listing for a property owner. It validates
    input data and provides a standardized interface for the API
    endpoints that handle inscription creation.

    Attributes:
        owner_id (UUID): The unique identifier of the property owner
            creating the inscription.
        housing_id (UUID): The unique identifier of the housing unit
            being listed for rent.
        available_from (date): The start date when the property becomes
            available for rental.
        available_to (date | None): The optional end date for the rental
            availability period. If None, the listing has no fixed end date.
        monthly_rent (float): The monthly rental price in the local currency.
            Must be a non-negative value (default: 0).
        is_active (bool): Whether this inscription is currently active
            and visible to potential tenants (default: True).

    """

    owner_id: UUID
    housing_id: UUID
    available_from: date
    available_to: date | None = None
    monthly_rent: float = Field(default=0, ge=0)
    is_active: bool = True


class OwnerInscriptionUpdateDTO(BaseModel):
    """
    Data Transfer Object for updating existing housing inscriptions.

    This DTO defines the fields that can be modified on an existing
    inscription, allowing owners to update their rental listings.

    Attributes:
        available_from (date | None): The updated start date for availability.
        available_to (date | None): The updated end date for availability.
        monthly_rent (float | None): The updated monthly rental price.
        is_active (bool | None): Whether the inscription should be active.

    """

    available_from: date | None = None
    available_to: date | None = None
    monthly_rent: float | None = Field(default=None, ge=0)
    is_active: bool | None = None
