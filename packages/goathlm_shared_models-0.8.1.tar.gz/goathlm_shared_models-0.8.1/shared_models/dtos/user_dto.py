from uuid import UUID

from pydantic import BaseModel, ConfigDict

from .location_dto import LocationDTO


class UserDTO(BaseModel):
    """
    Provides a standardized representation of a user profile for API responses.

    This data transfer object isolates the public-facing user details from
    sensitive database fields like passwords or internal metadata. It includes
    nested geographic information and is configured to automatically
    map from ORM model attributes.
    """

    id: UUID
    email_address: str

    first_name: str
    last_name: str
    phone_number: str

    location_id: UUID
    location: LocationDTO
    street_address: str
    country: str

    model_config = ConfigDict(from_attributes=True)
