from uuid import UUID

from pydantic import BaseModel, ConfigDict


class LocationDTO(BaseModel):
    """
    Represents a simplified geographic location for data exchange.

    This data transfer object is used to communicate city information
    across different services while abstracting the underlying
    database model. It includes configuration to allow seamless
    conversion from SQLAlchemy or SQLModel ORM objects.
    """

    id: UUID
    city: str

    model_config = ConfigDict(from_attributes=True)
