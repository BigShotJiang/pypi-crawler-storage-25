from typing import Annotated
from uuid import UUID

from pydantic import AfterValidator, BaseModel, Field


class HousingCreationDTO(BaseModel):
    """
    Data Transfer Object for creating a new housing entry.

    Defines the required and optional fields for housing registration. Uses
    serialization aliases to match database naming conventions.
    """

    owner_id: UUID
    city: str
    address: str = Field(serialization_alias="street_address")
    floor_number: str | None = Field(default="", max_length=5)
    type: Annotated[str, AfterValidator(lambda type_elem: type_elem.upper())]
    bedrooms: int | None = Field(default=None, ge=0)
    bathrooms: int | None = Field(default=None, ge=0)
    toilets: int | None = Field(default=None, ge=0)
    surface: int | None = Field(default=0, ge=0)
    total_rooms: int = Field(default=0, ge=0)
    has_garden: bool | None = Field(default=False)
    has_basement: bool | None = Field(default=False)
    has_parking: bool | None = Field(default=False)
