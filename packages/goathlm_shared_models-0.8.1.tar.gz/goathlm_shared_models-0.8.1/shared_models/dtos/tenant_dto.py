from uuid import UUID

from pydantic import BaseModel, ConfigDict


class TenantSummaryDTO(BaseModel):
    """
    Provides a lightweight tenant identity projection for nested payloads.

    This DTO is used inside offer responses where only key identity attributes
    are needed for display, without exposing sensitive account details.
    """

    id: UUID
    first_name: str
    last_name: str
    email_address: str

    model_config = ConfigDict(from_attributes=True)


class TenantProfileDTO(BaseModel):
    """
    Represents a tenant profile returned by tenant-oriented API endpoints.

    This DTO centralizes publicly exposed contact and location fields so all
    services can reuse the same schema when returning tenant profile data.
    """

    id: UUID
    email_address: str
    first_name: str
    last_name: str
    phone_number: str
    city: str
    street_address: str
    country: str
