from datetime import datetime
from typing import Any

from pydantic import BaseModel


class NotificationDTO(BaseModel):
    """
    Represents a user-facing notification persisted in Redis.

    This payload is intentionally generic so each microservice can push
    domain-specific metadata while keeping a stable polling contract.
    """

    id: str
    user_id: str
    event_type: str
    created_at: datetime
    payload: dict[str, Any]
