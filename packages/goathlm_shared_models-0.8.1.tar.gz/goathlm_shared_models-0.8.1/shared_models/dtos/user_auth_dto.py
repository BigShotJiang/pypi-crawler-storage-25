from uuid import UUID

from pydantic import BaseModel, ConfigDict

from shared_models.models.jwt_tokens import JWTTokens

from .location_dto import LocationDTO


class UserAuthDTO(BaseModel):
    """
    Combines core user identity with active session security tokens.

    This comprehensive data transfer object is returned upon successful
    authentication or token refresh. It bundles the user's personal
    profile, geographic location details, and the JWT credentials
    required for subsequent authorized requests.
    """

    id: UUID
    email_address: str
    jwt_tokens: JWTTokens

    first_name: str
    last_name: str
    phone_number: str

    location_id: UUID
    location: LocationDTO
    street_address: str
    country: str

    model_config = ConfigDict(from_attributes=True)
