from datetime import date
from typing import Annotated

from pydantic import AfterValidator, BaseModel, Field


class HousingFilterDTO(BaseModel):
    """
    Data Transfer Object for filtering housing searches.

    Contains optional criteria to narrow down housing results. Includes automatic
    normalization of housing types to uppercase via validators.
    """

    city: str | None = None
    types: Annotated[
        list[str],
        AfterValidator(lambda types: [elem.upper() for elem in types]),
    ] = Field(default=None)
    bedrooms: int | None = Field(default=None, ge=0)
    bathrooms: int | None = Field(default=None, ge=0)
    toilets: int | None = Field(default=None, ge=0)
    total_rooms: int | None = Field(default=None, ge=0)
    surface: int | None = Field(default=None, ge=0)
    has_garden: bool | None = None
    has_basement: bool | None = None
    has_parking: bool | None = None
    date_debut: date | None = None
    date_fin: date | None = None
