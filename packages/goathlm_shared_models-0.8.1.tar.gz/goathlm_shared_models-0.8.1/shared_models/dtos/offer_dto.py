from datetime import date
from uuid import UUID

from pydantic import BaseModel, Field

from shared_models.dtos.tenant_dto import TenantSummaryDTO
from shared_models.enums import OfferStatus


class OfferCreateDTO(BaseModel):
    """
    Carries tenant offer creation input shared across microservices.

    This DTO defines the mandatory identifiers and desired stay period
    required to create an offer on a housing inscription.
    """

    housing_inscription_id: UUID
    tenant_id: UUID
    from_date: date
    to_date: date


class OfferStatusUpdateDTO(BaseModel):
    """
    Encapsulates a status change request for an existing offer.

    This DTO is shared between services that need to update offer states
    while keeping the same contract for status transition operations.
    """

    offer_status: OfferStatus = Field(description="New status for the offer")


class HousingSummaryDTO(BaseModel):
    """
    Provides a compact housing view embedded in offer responses.

    This DTO aggregates display-oriented housing fields with the inscription
    availability and rent metadata needed by tenant-facing interfaces.
    """

    id: UUID
    street_address: str
    zip_code: str
    city: str
    housing_type: str
    monthly_rent: float
    available_from: date
    available_to: date | None


class TenantOfferDTO(BaseModel):
    """
    Represents an offer payload returned by tenant service endpoints.

    This DTO combines the offer period and status with nested tenant and
    housing summaries so the front-end can render offer cards directly.
    """

    id: UUID
    offer_status: OfferStatus
    from_date: date
    to_date: date
    tenant: TenantSummaryDTO
    housing: HousingSummaryDTO
