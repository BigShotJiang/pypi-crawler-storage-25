from uuid import UUID, uuid4

from sqlmodel import Field, Relationship, SQLModel

from .housing_type import HousingType
from .location import Location
from .user import User


class Housing(SQLModel, table=True):
    """
    Represents a physical real estate unit and its technical specifications for an owner.

    This model serves as the central data point for property details, linking
    geographic information with architectural categories through relational mapping.
    It stores structural data such as room counts, total surface area, and
    amenities like parking or gardens to facilitate precise rental filtering.
    """

    id: UUID = Field(default_factory=uuid4, primary_key=True)

    location_id: UUID = Field(foreign_key="location.id", nullable=False, index=True)
    location: Location = Relationship()

    owner_id: UUID = Field(foreign_key="user.id", nullable=False, index=True)
    owner: User = Relationship()

    housing_type_id: UUID = Field(
        foreign_key="housing_type.id",
        nullable=False,
        index=True,
    )
    housing_type: HousingType = Relationship()

    street_address: str = Field(max_length=50, nullable=False)
    floor_number: str = Field(max_length=5, nullable=True)

    bedrooms: int = Field(default=0, ge=0, nullable=False)
    bathrooms: int = Field(default=0, ge=0, nullable=False)
    toilets: int = Field(default=0, ge=0, nullable=False)
    total_rooms: int = Field(default=0, ge=0, nullable=False)
    surface: int = Field(default=0, ge=0, nullable=False)

    has_garden: bool = Field(default=False, nullable=False)
    has_basement: bool = Field(default=False, nullable=False)  # sous-sol
    has_parking: bool = Field(default=False, nullable=False)
