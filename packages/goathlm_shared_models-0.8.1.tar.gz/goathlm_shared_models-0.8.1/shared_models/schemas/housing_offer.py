from datetime import date
from uuid import UUID, uuid4

from sqlmodel import Field, Relationship, SQLModel

from shared_models.enums import OfferStatus

from .housing_inscription import HousingInscription
from .user import User


class HousingOffer(SQLModel, table=True):
    """
    Represents a formal rental application submitted by a potential tenant.

    This model manages the lifecycle of a housing request by connecting
    interested tenants to active property inscriptions. It tracks the
    negotiation status and the specific duration for which the tenant
    intends to occupy the property.
    """

    __tablename__ = "housing_offer"

    id: UUID = Field(default_factory=uuid4, primary_key=True)

    offer_status: OfferStatus = Field(default=OfferStatus.PENDING, nullable=False)

    tenant_id: UUID = Field(foreign_key="user.id", nullable=False, index=True)
    tenant: User = Relationship()

    housing_inscription_id: UUID = Field(
        foreign_key="housing_inscription.id",
        nullable=False,
        index=True,
    )
    housing_inscription: HousingInscription = Relationship()

    from_date: date = Field(nullable=False)
    to_date: date = Field(nullable=False)
