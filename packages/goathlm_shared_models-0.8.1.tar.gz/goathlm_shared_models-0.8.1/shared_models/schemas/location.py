from uuid import UUID, uuid4

from sqlmodel import Field, SQLModel


class Location(SQLModel, table=True):
    """
    Defines the geographic areas available for housing listings.

    This lookup model standardizes city names across the application
    to ensure data consistency. It serves as a central reference for
    address validation and enables users to filter properties based
    on specific urban centers.
    """

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    city: str = Field(max_length=50, unique=True, nullable=False)
    zip_code: str = Field(max_length=5, nullable=False)
