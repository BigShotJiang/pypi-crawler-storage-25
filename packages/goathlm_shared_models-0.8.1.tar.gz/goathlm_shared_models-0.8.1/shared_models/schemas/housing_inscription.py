from datetime import date
from uuid import UUID, uuid4

from sqlmodel import Field, Relationship, SQLModel

from .housing import Housing


class HousingInscription(SQLModel, table=True):
    """
    Represents a formal rental listing created by a property owner.

    This model serves as the operational link between a specific user and
    a physical housing unit, defining the commercial terms of the rental.
    It tracks the availability period, financial requirements, and the
    current publication status of the property on the market.
    """

    __tablename__ = "housing_inscription"

    id: UUID = Field(default_factory=uuid4, primary_key=True)

    housing_id: UUID = Field(foreign_key="housing.id", nullable=False, index=True)
    housing: Housing = Relationship()

    available_from: date = Field(nullable=False)
    available_to: date | None = Field(default=None, nullable=True)

    is_active: bool = Field(default=True, nullable=False)

    monthly_rent: float = Field(default=0, ge=0, nullable=False, index=True)
