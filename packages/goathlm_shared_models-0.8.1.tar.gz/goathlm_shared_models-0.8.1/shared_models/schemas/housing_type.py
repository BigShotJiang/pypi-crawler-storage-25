from uuid import UUID, uuid4

from sqlmodel import Field, SQLModel


class HousingType(SQLModel, table=True):
    """
    Defines the architectural categories for housing units.

    This lookup model standardizes property types across the
    application to ensure consistent filtering and display. It
    provides a technical identifier for system logic and a
    human-readable label for the user interface.
    """

    __tablename__ = "housing_type"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    name: str = Field(max_length=25, unique=True, nullable=False)
    label: str = Field(max_length=50, nullable=True)
