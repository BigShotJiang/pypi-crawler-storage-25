from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ServerSettings(BaseSettings):
    """
    Manages the network and connectivity configurations for the application server.

    This model facilitates the transition between environments (development,
    staging, production) by mapping environment variables to validated
    attributes. It ensures that the application binds to the correct
    network interfaces and recognizes its upstream proxy.
    """

    host: str = Field(validation_alias="SERVER_HOST")
    port: int = Field(validation_alias="SERVER_PORT")
    reverse_proxy_url: str = Field(validation_alias="REVERSE_PROXY_URL")
    redis_url: str = Field(
        validation_alias="REDIS_URL",
    )
    redis_notifications_channel: str = Field(
        validation_alias="REDIS_NOTIFICATIONS_CHANNEL",
    )

    model_config = SettingsConfigDict(
        env_file=(".env.prod", ".env"),
        extra="ignore",
        env_file_encoding="utf-8",
    )


@lru_cache
def get_server_settings() -> "ServerSettings":
    """
    Returns a cached instance of the server configuration.

    Leveraging the LRU cache prevents the application from re-reading
    environment files and re-running Pydantic validation on every
    request/call. This maintains a single source of truth for server
    parameters throughout the process lifecycle.

    :return: A singleton instance of the ServerSettings class.
    """
    return ServerSettings()
