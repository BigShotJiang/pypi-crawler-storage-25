from uuid import UUID

from pydantic import BaseModel

from shared_models.schemas import Location

from .jwt_tokens import JWTTokens


class UserAuth(BaseModel):
    """
    Comprehensive user profile and authentication data.

    Represents the full context of an authenticated user, including personal
    details, location information, and active JWT security tokens.
    """

    id: UUID
    email_address: str
    jwt_tokens: JWTTokens

    first_name: str
    last_name: str
    phone_number: str

    location_id: UUID
    location: Location
    street_address: str
    country: str
