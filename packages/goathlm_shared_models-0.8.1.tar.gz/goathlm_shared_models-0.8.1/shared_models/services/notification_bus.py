import json
import logging
from collections.abc import AsyncGenerator
from datetime import UTC, datetime
from uuid import UUID, uuid4

from pydantic import ValidationError
from redis.asyncio import Redis
from redis.exceptions import RedisError

from shared_models.dtos.notification_dto import NotificationDTO
from shared_models.models.server_settings import get_server_settings

logger = logging.getLogger(__name__)

_NOTIFICATION_TTL_SECONDS = 60 * 60 * 24 * 7
_NOTIFICATION_MAX_BUFFER = 200


def _user_key(user_id: UUID | str) -> str:
    return f"goathlm:notifications:user:{user_id}"


async def publish_notification(
    user_id: UUID | str,
    event_type: str,
    payload: dict,
) -> NotificationDTO | None:
    """
    Publishes one notification for a target user into Redis.

    Data is stored in a capped list to support simple polling and also
    published on a channel for future real-time consumers.
    """
    settings = get_server_settings()
    redis = Redis.from_url(settings.redis_url, decode_responses=True)

    notification = NotificationDTO(
        id=str(uuid4()),
        user_id=str(user_id),
        event_type=event_type,
        created_at=datetime.now(UTC),
        payload=payload,
    )

    key = _user_key(user_id)
    raw = notification.model_dump_json()

    try:
        async with redis.client() as client:
            pipeline = client.pipeline()
            pipeline.lpush(key, raw)
            pipeline.ltrim(key, 0, _NOTIFICATION_MAX_BUFFER - 1)
            pipeline.expire(key, _NOTIFICATION_TTL_SECONDS)
            pipeline.publish(settings.redis_notifications_channel, raw)
            await pipeline.execute()
    except RedisError:
        logger.exception("Failed to publish Redis notification")
        return None
    finally:
        await redis.aclose()

    return notification


async def get_notifications(
    user_id: UUID | str,
    *,
    limit: int = 20,
) -> list[NotificationDTO]:
    """Reads the latest notifications for a user from Redis."""
    safe_limit = max(1, min(limit, 100))
    settings = get_server_settings()
    redis = Redis.from_url(settings.redis_url, decode_responses=True)

    try:
        async with redis.client() as client:
            rows = await client.lrange(_user_key(user_id), 0, safe_limit - 1)
    except RedisError:
        logger.exception("Failed to fetch Redis notifications")
        return []
    finally:
        await redis.aclose()

    notifications: list[NotificationDTO] = []
    for row in rows:
        try:
            notifications.append(NotificationDTO.model_validate(json.loads(row)))
        except (json.JSONDecodeError, ValidationError):
            continue

    return notifications


async def subscribe_notifications(
    user_id: UUID | str,
) -> AsyncGenerator[NotificationDTO | None]:
    """
    Subscribes to the Redis notifications channel and yields user events.

    It yields `None` periodically when no message is available so SSE clients
    can receive keep-alive frames.
    """
    settings = get_server_settings()
    redis = Redis.from_url(settings.redis_url, decode_responses=True)
    pubsub = redis.pubsub()

    try:
        await pubsub.subscribe(settings.redis_notifications_channel)

        while True:
            message = await pubsub.get_message(
                ignore_subscribe_messages=True,
                timeout=25.0,
            )
            if message is None:
                yield None
                continue

            raw = message.get("data")
            if not isinstance(raw, str):
                continue

            try:
                notification = NotificationDTO.model_validate_json(raw)
            except ValidationError:
                continue

            if notification.user_id == str(user_id):
                yield notification
    except RedisError:
        logger.exception("Failed to subscribe to Redis notifications")
    finally:
        await pubsub.unsubscribe(settings.redis_notifications_channel)
        await pubsub.aclose()
        await redis.aclose()
