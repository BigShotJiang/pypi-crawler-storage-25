"""Filesystem-backed store for first-class proposal operations.

``ProposalOperationStore`` is the swap-ready read/write boundary for
assistant proposal operations after the projection cutover. The interface
mirrors ``ActionAuditStore``'s replaceable surface while the local
implementation follows ``AssistantRepository``'s JSON-file, RLock-guarded
storage pattern under the Obra runtime directory.
"""

from __future__ import annotations

import json
import threading
from collections.abc import Callable, Iterable
from pathlib import Path
from typing import Protocol

from obra.config.loaders import get_gateway_assistant_config
from obra.gateway.assistant.proposal_operations import (
    ProposalOperation,
    proposal_operation_from_dict,
)
from obra.utils.obra_home import get_runtime_dir


class ProposalOperationStore(Protocol):
    """Storage boundary for durable proposal operations."""

    def get(self, operation_id: str) -> ProposalOperation | None:
        """Return one operation by id."""
        ...

    def list_for_workflow(
        self,
        workflow_id: str,
        statuses: Iterable[str] | None = None,
    ) -> list[ProposalOperation]:
        """Return operations for one workflow, optionally status-filtered."""
        ...

    def list_for_thread(self, thread_id: str) -> list[ProposalOperation]:
        """Return operations for one assistant thread."""
        ...

    def list_for_user(self, user_id: str) -> list[ProposalOperation]:
        """Return operations created by one user."""
        ...

    def put(self, operation: ProposalOperation) -> None:
        """Create or replace one operation."""
        ...

    def mutate(
        self,
        operation_id: str,
        updater: Callable[[ProposalOperation], ProposalOperation],
    ) -> ProposalOperation:
        """Atomically replace one operation using *updater*."""
        ...

    def delete(self, operation_id: str) -> bool:
        """Delete one operation by id."""
        ...

    def delete_where(self, predicate: Callable[[ProposalOperation], bool]) -> int:
        """Delete operations matching *predicate* and return the count."""
        ...


class FilesystemProposalOperationStore:
    """Local JSON implementation of ``ProposalOperationStore``."""

    def __init__(self, *, storage_path: Path | None = None) -> None:
        self._lock = threading.RLock()
        self._storage_path = storage_path or (
            get_runtime_dir() / "assistant" / "proposal_operations.json"
        )
        self._operations: dict[str, ProposalOperation] = {}
        self._by_workflow: dict[str, set[str]] = {}
        self._by_thread: dict[str, set[str]] = {}
        self._by_user: dict[str, set[str]] = {}
        self._storage_path.parent.mkdir(parents=True, exist_ok=True)
        self._load()

    @classmethod
    def from_app_state(cls, app_state: object) -> ProposalOperationStore:
        """Extract or lazily create the operation store from app state."""
        store = getattr(app_state, "proposal_operation_store", None)
        if store is not None:
            return store

        configured_path = getattr(app_state, "proposal_operation_store_path", None)
        if configured_path:
            storage_path = Path(str(configured_path)).expanduser()
        else:
            assistant_config = get_gateway_assistant_config()
            assistant_path = Path(str(assistant_config["persistence_storage_path"]))
            storage_path = get_runtime_dir() / assistant_path.parent / "proposal_operations.json"

        store = cls(storage_path=storage_path)
        app_state.proposal_operation_store = store
        return store

    def get(self, operation_id: str) -> ProposalOperation | None:
        """Return one operation by id."""
        normalized = str(operation_id or "").strip()
        if not normalized:
            return None
        with self._lock:
            return self._operations.get(normalized)

    def list_for_workflow(
        self,
        workflow_id: str,
        statuses: Iterable[str] | None = None,
    ) -> list[ProposalOperation]:
        """Return operations for one workflow, optionally status-filtered."""
        normalized = str(workflow_id or "").strip()
        allowed = {str(status or "").strip().lower() for status in statuses or []}
        with self._lock:
            operation_ids = self._by_workflow.get(normalized, set()) if normalized else set()
            operations = [self._operations[item] for item in operation_ids if item in self._operations]
        if allowed:
            operations = [operation for operation in operations if operation.status in allowed]
        return _sort_operations(operations)

    def list_for_thread(self, thread_id: str) -> list[ProposalOperation]:
        """Return operations for one assistant thread."""
        normalized = str(thread_id or "").strip()
        with self._lock:
            operation_ids = self._by_thread.get(normalized, set()) if normalized else set()
            return _sort_operations(
                [self._operations[item] for item in operation_ids if item in self._operations]
            )

    def list_for_user(self, user_id: str) -> list[ProposalOperation]:
        """Return operations created by one user."""
        normalized = str(user_id or "").strip()
        with self._lock:
            operation_ids = self._by_user.get(normalized, set()) if normalized else set()
            return _sort_operations(
                [self._operations[item] for item in operation_ids if item in self._operations]
            )

    def put(self, operation: ProposalOperation) -> None:
        """Create or replace one operation."""
        if not str(operation.operation_id or "").strip():
            raise ValueError("ProposalOperation.operation_id is required")
        with self._lock:
            self._operations[operation.operation_id] = operation
            self._rebuild_indexes_locked()
            self._save_locked()

    def mutate(
        self,
        operation_id: str,
        updater: Callable[[ProposalOperation], ProposalOperation],
    ) -> ProposalOperation:
        """Atomically replace one operation using *updater*."""
        normalized = str(operation_id or "").strip()
        if not normalized:
            raise KeyError("Proposal operation id is required")
        with self._lock:
            operation = self._operations.get(normalized)
            if operation is None:
                raise KeyError(f"Proposal operation not found: {normalized}")
            next_operation = updater(operation)
            if not str(next_operation.operation_id or "").strip():
                raise ValueError("ProposalOperation.operation_id is required")
            self._operations.pop(normalized, None)
            self._operations[next_operation.operation_id] = next_operation
            self._rebuild_indexes_locked()
            self._save_locked()
            return next_operation

    def delete(self, operation_id: str) -> bool:
        """Delete one operation by id."""
        normalized = str(operation_id or "").strip()
        if not normalized:
            return False
        with self._lock:
            existed = normalized in self._operations
            if existed:
                del self._operations[normalized]
                self._rebuild_indexes_locked()
                self._save_locked()
            return existed

    def delete_where(self, predicate: Callable[[ProposalOperation], bool]) -> int:
        """Delete operations matching *predicate* and return the count."""
        with self._lock:
            operation_ids = [
                operation_id
                for operation_id, operation in self._operations.items()
                if predicate(operation)
            ]
            for operation_id in operation_ids:
                del self._operations[operation_id]
            if operation_ids:
                self._rebuild_indexes_locked()
                self._save_locked()
            return len(operation_ids)

    def _load(self) -> None:
        with self._lock:
            if not self._storage_path.exists():
                self._save_locked()
                return
            payload = json.loads(self._storage_path.read_text(encoding="utf-8") or "{}")
            raw_operations = payload.get("operations", {})
            if isinstance(raw_operations, dict):
                for operation_id, raw_operation in raw_operations.items():
                    if not isinstance(raw_operation, dict):
                        continue
                    operation = proposal_operation_from_dict(
                        {"operation_id": operation_id, **raw_operation}
                    )
                    if operation.operation_id:
                        self._operations[operation.operation_id] = operation
            self._rebuild_indexes_locked()

    def _save_locked(self) -> None:
        payload = {
            "operations": {
                operation_id: operation.to_dict()
                for operation_id, operation in sorted(self._operations.items())
            }
        }
        self._storage_path.parent.mkdir(parents=True, exist_ok=True)
        self._storage_path.write_text(
            json.dumps(payload, indent=2, sort_keys=True, default=str),
            encoding="utf-8",
        )

    def _rebuild_indexes_locked(self) -> None:
        self._by_workflow = {}
        self._by_thread = {}
        self._by_user = {}
        for operation_id, operation in self._operations.items():
            workflow_id = str(operation.workflow_id or "").strip()
            if workflow_id:
                self._by_workflow.setdefault(workflow_id, set()).add(operation_id)
            thread_id = str(operation.thread_id or "").strip()
            if thread_id:
                self._by_thread.setdefault(thread_id, set()).add(operation_id)
            created_by = str(operation.created_by or "").strip()
            if created_by:
                self._by_user.setdefault(created_by, set()).add(operation_id)


def _sort_operations(operations: list[ProposalOperation]) -> list[ProposalOperation]:
    return sorted(
        operations,
        key=lambda operation: (
            str(operation.status or ""),
            str(operation.updated_at or operation.created_at or ""),
            operation.thread_id,
            operation.turn_id,
            operation.operation_id,
        ),
    )
