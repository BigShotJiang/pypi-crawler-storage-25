"""Action broker — dispatches registered actions with safety enforcement (TR-3.2).

Orchestrates: registry lookup -> safety check -> input validation ->
handler dispatch -> audit recording -> result assembly.
"""

from __future__ import annotations

import importlib
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from obra.gateway.assistant.action_registry import get_action
from obra.gateway.assistant.audit import (
    ActionAuditRecord,
    ActionAuditStore,
    generate_audit_id,
)
from obra.gateway.workflow_studio.file_checkpoint import (
    create_checkpoint,
    update_checkpoint_files_after,
)
from obra.gateway.workflow_studio.operator_actions import WorkflowRunActionService
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.workflow_actions import WorkflowActionService

# -- Safety mode ordering ---------------------------------------------------

_MODE_ORDER: dict[str, int] = {"advisory": 0, "guided": 1, "active": 2}


# -- Outcome contract -------------------------------------------------------

# Outcomes that mean "the handler did not apply the action; here is why".
# Conflict is intentionally excluded: it carries a structured conflict_summary
# and the user resolves it through a different UI path.
FAILURE_OUTCOMES: frozenset[str] = frozenset({"invalid", "rejected", "checkpoint_failed", "error"})


def is_failure_outcome(outcome: str | None) -> bool:
    """Return True when *outcome* is one of the canonical failure outcomes."""
    return outcome in FAILURE_OUTCOMES


def extract_failure_detail(payload: Mapping[str, Any] | None) -> str | None:
    """Return the human-readable failure reason from a handler payload.

    Handlers historically wrote the reason to one of ``error_detail``,
    ``detail``, or ``message``.  Centralising the lookup lets downstream
    readers depend on a single field without each handler being audited.
    """
    if not isinstance(payload, Mapping):
        return None
    for key in ("error_detail", "detail", "message"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


# -- Exceptions -------------------------------------------------------------


class ActionNotFoundError(Exception):
    """Raised when the requested action_id is not in the registry."""


class SafetyModeInsufficientError(Exception):
    """Raised when the current safety mode is below the action requirement."""

    def __init__(self, current_mode: str, required_mode: str) -> None:
        self.current_mode = current_mode
        self.required_mode = required_mode
        super().__init__(
            f"Safety mode '{current_mode}' insufficient; action requires '{required_mode}'"
        )


class ActionInputError(Exception):
    """Raised when action inputs fail validation."""


# -- Context / result dataclasses -------------------------------------------


@dataclass
class HandlerContext:
    """Injected into every handler call."""

    repository: WorkflowStudioRepository
    action_service: WorkflowActionService
    run_action_service: WorkflowRunActionService | None
    thread_id: str
    user_id: str
    turn_id: str
    project_root: Path | None = None
    app_state: Any | None = None
    working_dir_resolver: Callable[[str], str] | None = None
    llm_call: Any = None
    log_event: Callable[..., None] | None = None


@dataclass
class ActionExecutionResult:
    """Returned from ``ActionBroker.execute``."""

    # 'applied' | 'conflict' | one of FAILURE_OUTCOMES.  When outcome is in
    # FAILURE_OUTCOMES, payload['error_detail'] is guaranteed to be populated
    # whenever the handler supplied any human-readable reason.
    outcome: str
    payload: dict
    audit_id: str
    resulting_revision_ref: str | None = None
    conflict_summary: dict | None = None


# -- Input validation -------------------------------------------------------


def _validate_inputs(inputs: dict[str, Any], schema: dict[str, Any]) -> None:
    """Validate *inputs* against the action's declarative schema.

    Uses simple required-field checking consistent with the gateway's
    Pydantic-first validation style (jsonschema is not an installed dep).
    """
    for field_name, field_spec in schema.items():
        if field_spec.get("required") and field_name not in inputs:
            raise ActionInputError(f"Missing required field: {field_name}")


# -- Broker ------------------------------------------------------------------


class ActionBroker:
    """Dispatches registered actions through the canonical handler pipeline."""

    def __init__(
        self,
        repository: WorkflowStudioRepository,
        action_service: WorkflowActionService,
        run_action_service: WorkflowRunActionService | None = None,
        *,
        audit_store: ActionAuditStore | None = None,
        working_dir_resolver: Callable[[str], str] | None = None,
    ) -> None:
        self._repository = repository
        self._action_service = action_service
        self._run_action_service = run_action_service
        self._audit_store = audit_store or ActionAuditStore()
        self._working_dir_resolver = working_dir_resolver

    def execute(
        self,
        action_id: str,
        inputs: dict[str, Any],
        safety_mode: str,
        thread_id: str,
        turn_id: str,
        user_id: str,
        correlation: dict[str, Any] | None = None,
        project_root: Path | None = None,
        app_state: Any | None = None,
        llm_call: Any = None,
        log_event: Callable[..., None] | None = None,
    ) -> ActionExecutionResult:
        """Execute a registered action, enforcing safety and recording audit."""
        correlation = correlation or {}

        # 1. Registry lookup
        action = get_action(action_id)
        if action is None:
            raise ActionNotFoundError(action_id)

        # 2. Safety mode check
        current_level = _MODE_ORDER.get(safety_mode, -1)
        required_level = _MODE_ORDER.get(action.required_safety_mode, 0)
        if current_level < required_level:
            raise SafetyModeInsufficientError(safety_mode, action.required_safety_mode)

        # 3. Input validation
        _validate_inputs(inputs, action.input_schema)

        # 4. Build handler context
        ctx = HandlerContext(
            repository=self._repository,
            action_service=self._action_service,
            run_action_service=self._run_action_service,
            thread_id=thread_id,
            user_id=user_id,
            turn_id=turn_id,
            project_root=project_root,
            app_state=app_state,
            working_dir_resolver=self._working_dir_resolver,
            llm_call=llm_call,
            log_event=log_event,
        )

        # 5. Resolve and call handler
        module_path, func_name = action.handler_ref.rsplit(".", 1)
        module = importlib.import_module(module_path)
        handler_fn = getattr(module, func_name)
        audit_id = generate_audit_id()
        now = datetime.now(timezone.utc).isoformat()
        workflow_id = inputs.get("workflow_id") or inputs.get("source_workflow_id")
        checkpoint_id: str | None = None
        checkpoint_workflow_id: str | None = None

        if action.category == "project_files" and action.mutates:
            if project_root is None:
                raise ActionInputError("Project root is required for file-mutating actions")
            checkpoint_workflow_id = str(workflow_id or "assistant-project-files")
            target_dir = str(
                inputs.get("target_dir")
                or (
                    "docs"
                    if action_id == "save_documentation"
                    else f"test-data/{checkpoint_workflow_id}"
                )
            )
            turn_index = int(correlation.get("turn_index") or 0)
            try:
                checkpoint = create_checkpoint(
                    project_root=project_root,
                    workflow_id=checkpoint_workflow_id,
                    target_dir=target_dir,
                    action_id=action_id,
                    thread_id=thread_id,
                    turn_index=turn_index,
                )
            except Exception as exc:
                failure_correlation = dict(correlation)
                failure_correlation["project_root"] = str(project_root)
                self._audit_store.record(
                    ActionAuditRecord(
                        audit_id=audit_id,
                        thread_id=thread_id,
                        turn_id=turn_id,
                        action_id=action_id,
                        initiated_by=user_id,
                        safety_mode=safety_mode,
                        action_inputs=inputs,
                        outcome="checkpoint_failed",
                        workflow_id=workflow_id,
                        error_detail=str(exc),
                        timestamp=now,
                        correlation=failure_correlation,
                    )
                )
                raise ActionInputError(str(exc)) from exc
            checkpoint_id = checkpoint.checkpoint_id
            correlation["checkpoint_id"] = checkpoint_id
            correlation["project_root"] = str(project_root)
            if log_event is not None:
                log_event(
                    "asst.checkpoint_created",
                    turn_id=turn_id,
                    action_id=action_id,
                    checkpoint_id=checkpoint_id,
                    workflow_id=checkpoint_workflow_id,
                    target_dir=target_dir,
                    project_root=str(project_root),
                )

        # Handlers receive workflow_id (or source_workflow_id) from inputs,
        # plus the full inputs dict, plus the context.
        try:
            handler_result: dict[str, Any] = handler_fn(
                workflow_id=workflow_id, inputs=inputs, ctx=ctx
            )
        except Exception as exc:
            self._audit_store.record(
                ActionAuditRecord(
                    audit_id=audit_id,
                    thread_id=thread_id,
                    turn_id=turn_id,
                    action_id=action_id,
                    initiated_by=user_id,
                    safety_mode=safety_mode,
                    action_inputs=inputs,
                    outcome="rejected",
                    workflow_id=workflow_id,
                    error_detail=str(exc),
                    timestamp=now,
                    correlation=dict(correlation),
                )
            )
            raise ActionInputError(str(exc)) from exc

        outcome = handler_result.get("outcome", "applied")
        if is_failure_outcome(outcome):
            detail = extract_failure_detail(handler_result)
            if detail and "error_detail" not in handler_result:
                handler_result["error_detail"] = detail
        resulting_revision_ref = handler_result.get("resulting_revision_ref")
        conflict_summary = handler_result.get("conflict_summary")
        files_written = handler_result.get("files_written", [])
        if (
            checkpoint_id is not None
            and project_root is not None
            and checkpoint_workflow_id is not None
            and isinstance(files_written, list)
        ):
            update_checkpoint_files_after(
                project_root=project_root,
                checkpoint_id=checkpoint_id,
                workflow_id=checkpoint_workflow_id,
                files_after=[str(path) for path in files_written],
            )
        handler_result["correlation"] = dict(correlation)

        # 6. Record audit
        audit = ActionAuditRecord(
            audit_id=audit_id,
            thread_id=thread_id,
            turn_id=turn_id,
            action_id=action_id,
            initiated_by=user_id,
            safety_mode=safety_mode,
            action_inputs=inputs,
            outcome=outcome,
            resulting_revision_ref=resulting_revision_ref,
            base_revision_ref=handler_result.get("base_revision_ref"),
            workflow_id=workflow_id,
            timestamp=now,
            correlation=correlation,
        )
        self._audit_store.record(audit)

        # 7. Build result
        return ActionExecutionResult(
            outcome=outcome,
            payload=handler_result,
            audit_id=audit_id,
            resulting_revision_ref=resulting_revision_ref,
            conflict_summary=conflict_summary,
        )
