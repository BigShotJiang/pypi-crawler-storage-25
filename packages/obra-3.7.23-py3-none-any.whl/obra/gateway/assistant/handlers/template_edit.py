"""Template edit action handlers — propose and execute template mutations."""

from __future__ import annotations

import copy
import difflib
import logging
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.handlers.structural import _find_stage, _get_stages
from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.workflow_studio.template_asset_store_resolver import resolve_template_asset_store
from obra.workflow.stage_instruction_assets import (
    PRIMARY_STAGE_INSTRUCTION_ROLE,
    PendingStageInstructionAssetWrite,
    apply_primary_stage_instruction_candidate_update,
    canonicalize_template_role,
    commit_pending_stage_instruction_asset_writes,
    resolve_primary_stage_instruction,
)
from obra.workflow.template_asset_store import TemplateAssetStore

logger = logging.getLogger(__name__)


def _resolve_template_content(
    workflow: dict[str, Any],
    stage_id: str | None,
    template_role: str,
    *,
    store: TemplateAssetStore | None = None,
) -> str | None:
    """Extract current template content from the workflow.

    For stage-level templates, locates the stage by *stage_id* and reads
    the binding matching *template_role*.  For workflow-level templates
    (stage_id is None), reads from the top-level workflow_definition.
    """
    defn = workflow.get("workflow_definition", {})

    if stage_id is None:
        # Workflow-level template (e.g., workflow description or top-level prompt)
        templates = defn.get("templates", {})
        return templates.get(template_role)

    # Stage-level template
    stages = _get_stages(workflow)
    stage = _find_stage(stages, stage_id)
    if stage is None:
        return None
    if template_role == PRIMARY_STAGE_INSTRUCTION_ROLE:
        workflow_id = str(workflow.get("workflow_id") or defn.get("workflow_id") or "").strip()
        resolution = resolve_primary_stage_instruction(
            stage,
            workflow_id,
            store,
            domain_id=str(workflow.get("domain_id") or defn.get("domain_id") or "business"),
        )
        return resolution.content

    # Check template_bindings first, then inline template fields
    for binding in stage.get("template_bindings", []):
        if binding.get("role") == template_role:
            return binding.get("content", "")

    # Fallback: inline template field (e.g., stage_prompt, input_template)
    return stage.get(template_role)


def _apply_template_to_workflow(
    workflow: dict[str, Any],
    stage_id: str | None,
    template_role: str,
    proposed_content: str,
) -> tuple[dict[str, Any], list[PendingStageInstructionAssetWrite]]:
    """Return a copy of *workflow* with the target template replaced."""
    candidate = copy.deepcopy(workflow)
    pending_writes = _apply_template_to_candidate(
        candidate,
        stage_id,
        template_role,
        proposed_content,
    )
    return candidate, pending_writes


def _apply_template_edits_to_workflow(
    workflow: dict[str, Any],
    edits: list[dict[str, Any]],
) -> tuple[dict[str, Any], list[PendingStageInstructionAssetWrite]]:
    """Return a workflow candidate with multiple template edits applied."""
    candidate = copy.deepcopy(workflow)
    pending_writes: list[PendingStageInstructionAssetWrite] = []
    for edit in edits:
        stage_id = edit.get("stage_id")
        template_role = canonicalize_template_role(str(edit.get("template_role") or ""))
        proposed_content = str(edit.get("proposed_content") or "")
        if not str(stage_id or "").strip() or not proposed_content.strip():
            raise ValueError("Template edit requires stage_id and proposed_content.")
        pending_writes.extend(
            _apply_template_to_candidate(
                candidate,
                str(stage_id),
                template_role,
                proposed_content,
            )
        )
    return candidate, pending_writes


def _apply_template_to_candidate(
    candidate: dict[str, Any],
    stage_id: str | None,
    template_role: str,
    proposed_content: str,
) -> list[PendingStageInstructionAssetWrite]:
    """Apply a template update directly to *candidate* in place."""
    defn = candidate.get("workflow_definition", {})

    if stage_id is None:
        templates = defn.setdefault("templates", {})
        templates[template_role] = proposed_content
        return []

    stages = _get_stages(candidate)
    stage = _find_stage(stages, stage_id)
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")

    if template_role == PRIMARY_STAGE_INSTRUCTION_ROLE:
        workflow_id = str(candidate.get("workflow_id") or defn.get("workflow_id") or "").strip()
        pending = apply_primary_stage_instruction_candidate_update(
            candidate,
            workflow_id=workflow_id,
            stage_id=stage_id,
            content=proposed_content,
            workflow_version="current",
        )
        return [pending]

    # Update template_bindings if the role exists there
    for binding in stage.get("template_bindings", []):
        if binding.get("role") == template_role:
            binding["content"] = proposed_content
            return []

    # Fallback: set inline template field
    stage[template_role] = proposed_content
    return []


def build_template_edit_proposal(
    *,
    workflow: dict[str, Any],
    workflow_id: str,
    stage_id: str | None,
    template_role: str,
    proposed_content: str,
    expected_revision_id: str = "",
    proposal_group: str | None = None,
    store: TemplateAssetStore | None = None,
) -> dict[str, Any]:
    """Build the canonical template-edit proposal payload."""
    current_content = _resolve_template_content(
        workflow,
        stage_id,
        template_role,
        store=store,
    )
    if current_content is None:
        current_content = ""

    before_lines = current_content.splitlines(keepends=True)
    after_lines = proposed_content.splitlines(keepends=True)
    diff_lines = list(
        difflib.unified_diff(
            before_lines,
            after_lines,
            fromfile=f"{template_role} (current)",
            tofile=f"{template_role} (proposed)",
        )
    )

    return build_proposal_record(
        action_id="execute_template_edit",
        action_type="propose_template_edit",
        action_inputs={
            "workflow_id": workflow_id,
            "stage_id": stage_id,
            "template_role": template_role,
            "proposed_content": proposed_content,
            "expected_revision_id": expected_revision_id,
        },
        preview_type="diff",
        proposal_group=proposal_group,
        outcome="proposal",
        diff=diff_lines,
        before_content=current_content,
        after_content=proposed_content,
        workflow_id=workflow_id,
        stage_id=stage_id,
        template_role=template_role,
    )


def propose(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose a template edit and return a diff preview."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str | None = inputs.get("stage_id")
    template_role: str = canonicalize_template_role(inputs.get("template_role", ""))
    proposed_content: str = inputs.get("proposed_content", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    store = (
        resolve_template_asset_store(ctx.app_state, project_root=ctx.project_root)
        if template_role == PRIMARY_STAGE_INSTRUCTION_ROLE
        else None
    )
    return build_template_edit_proposal(
        workflow=workflow,
        workflow_id=wf_id,
        stage_id=stage_id,
        template_role=template_role,
        proposed_content=proposed_content,
        expected_revision_id=str(inputs.get("expected_revision_id") or ""),
        store=store,
    )


def execute(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed template edit."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str | None = inputs.get("stage_id")
    template_role: str = canonicalize_template_role(inputs.get("template_role", ""))
    proposed_content: str = inputs.get("proposed_content", "")
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    store = resolve_template_asset_store(ctx.app_state, project_root=ctx.project_root)

    template_edits = inputs.get("template_edits")
    if isinstance(template_edits, list) and template_edits:
        normalized_edits = [dict(edit) for edit in template_edits if isinstance(edit, dict)]
        if len(normalized_edits) != len(template_edits):
            return {"outcome": "invalid", "detail": "Template edits must be objects."}
        normalized_edits = [
            _hydrate_proposed_template_content(wf_id, edit, store=store)
            for edit in normalized_edits
        ]
        try:
            candidate, pending_asset_writes = _apply_template_edits_to_workflow(
                workflow,
                normalized_edits,
            )
        except ValueError as exc:
            return {"outcome": "invalid", "detail": str(exc)}
    else:
        draft_inputs = _hydrate_proposed_template_content(
            wf_id,
            {
                "stage_id": stage_id,
                "template_role": template_role,
                "proposed_content": proposed_content,
            },
            store=store,
        )
        proposed_content = str(draft_inputs.get("proposed_content") or proposed_content)
        # Build candidate with the proposed content applied
        candidate, pending_asset_writes = _apply_template_to_workflow(
            workflow,
            stage_id,
            template_role,
            proposed_content,
        )

    result = ctx.action_service.apply_workflow(
        wf_id,
        candidate,
        expected_revision_id=expected_revision_id,
        pending_stage_instruction_writes=pending_asset_writes,
    )

    outcome = result.get("outcome", "")

    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
        }

    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
        }

    committed_assets = []
    if pending_asset_writes:
        logger.info(
            "Applying Studio template asset writes",
            extra={
                "workflow_id": wf_id,
                "template_asset_store_base_dir": str(getattr(store, "base_dir", "")),
                "stage_ids": [write.stage_id for write in pending_asset_writes],
                "write_count": len(pending_asset_writes),
            },
        )
        try:
            committed_assets = _commit_or_promote_stage_instruction_writes(
                pending_asset_writes,
                store,
                author_id=ctx.user_id or "assistant",
            )
        except Exception:
            logger.exception(
                "Failed applying Studio template asset writes",
                extra={
                    "workflow_id": wf_id,
                    "template_asset_store_base_dir": str(getattr(store, "base_dir", "")),
                    "stage_ids": [write.stage_id for write in pending_asset_writes],
                    "write_count": len(pending_asset_writes),
                },
            )
            raise
        logger.info(
            "Applied Studio template asset writes",
            extra={
                "workflow_id": wf_id,
                "template_asset_store_base_dir": str(getattr(store, "base_dir", "")),
                "committed_asset_count": len(committed_assets),
                "stage_ids": [str(asset.get("stage_id") or "") for asset in committed_assets],
            },
        )
        if not committed_assets:
            logger.warning(
                "Workflow apply accepted template writes but no template assets were committed",
                extra={
                    "workflow_id": wf_id,
                    "template_asset_store_base_dir": str(getattr(store, "base_dir", "")),
                    "pending_write_count": len(pending_asset_writes),
                },
            )

    # accepted
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
        "stage_id": stage_id,
        "template_role": template_role,
        "template_assets": committed_assets,
    }


def _hydrate_proposed_template_content(
    workflow_id: str,
    edit: dict[str, Any],
    *,
    store: TemplateAssetStore,
) -> dict[str, Any]:
    """Fill proposed content from draft storage when the action references a draft."""
    stage_id = str(edit.get("stage_id") or "").strip()
    role = canonicalize_template_role(str(edit.get("template_role") or ""))
    if not stage_id or not role:
        return edit
    proposed_content = str(edit.get("proposed_content") or "")
    if proposed_content:
        return edit
    draft = store.read_proposed_asset(workflow_id, stage_id, role)
    if draft is None:
        return edit
    hydrated = dict(edit)
    hydrated["proposed_content"] = draft.content
    hydrated["template_role"] = role
    return hydrated


def _commit_or_promote_stage_instruction_writes(
    writes: list[PendingStageInstructionAssetWrite],
    store: TemplateAssetStore,
    *,
    author_id: str,
) -> list[dict[str, Any]]:
    """Commit pending writes, promoting matching proposed drafts when present."""
    committed: list[dict[str, Any]] = []
    direct_writes: list[PendingStageInstructionAssetWrite] = []
    for write in writes:
        draft = store.read_proposed_asset(write.workflow_id, write.stage_id, write.role)
        if draft is None or draft.content != write.content:
            direct_writes.append(write)
            continue
        revision = store.promote_proposed_asset(
            write.workflow_id,
            write.stage_id,
            write.role,
            author_id=author_id,
        )
        if revision is None:
            direct_writes.append(write)
            continue
        committed.append(
            {
                "workflow_id": write.workflow_id,
                "stage_id": write.stage_id,
                "role": write.role,
                "version": revision.version,
                "asset_id": revision.artifact_id,
                "materialization_path": write.materialization_path,
            }
        )
    if direct_writes:
        committed.extend(
            commit_pending_stage_instruction_asset_writes(
                direct_writes,
                store,
                author_id=author_id,
            )
        )
    return committed
