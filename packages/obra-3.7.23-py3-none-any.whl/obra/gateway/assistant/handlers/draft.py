"""Draft workflow handler — create a new workflow from a conversation scaffold."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.workflow_studio.starter_catalog import normalize_starter_domain_id

_CANONICAL_DOMAIN_ALIASES = frozenset({"business", "obra_business", "software", "obra_software"})


def _log_domain_coercion(
    ctx: HandlerContext | None,
    *,
    raw_domain_id: str,
    coerced_domain_id: str,
    source: str,
) -> None:
    if ctx is None or ctx.log_event is None:
        return
    normalized_raw = raw_domain_id.strip().lower()
    if not normalized_raw or normalized_raw in _CANONICAL_DOMAIN_ALIASES:
        return
    if coerced_domain_id != "business":
        return
    ctx.log_event(
        "asst.domain_id_coerced",
        turn_id=ctx.turn_id,
        raw_domain_id=raw_domain_id,
        coerced_domain_id=coerced_domain_id,
        source=source,
    )


def _resolve_domain_id(
    inputs: dict[str, Any],
    scaffold: dict[str, Any],
    *,
    ctx: HandlerContext | None = None,
    source: str = "draft_workflow",
) -> str:
    """Resolve domain_id, defaulting to 'business' and coercing unregistered values.

    LLM tool calls sometimes emit domain ids outside the declared enum
    (e.g. 'education' for a lesson-plan workflow). Persisting that value would
    later fail at run launch with an opaque ConfigurationError. Coerce here to
    keep the workflow record valid.
    """
    raw = str(inputs.get("domain_id") or scaffold.get("domain_id") or "business").strip()
    domain_id = normalize_starter_domain_id(raw) or "business"
    _log_domain_coercion(ctx, raw_domain_id=raw, coerced_domain_id=domain_id, source=source)
    return domain_id


def propose_draft(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose creating a new workflow from an LLM-generated scaffold definition."""
    scaffold_definition: dict[str, Any] = inputs.get("scaffold_definition", {})

    stages = scaffold_definition.get("stages", [])
    if not stages:
        return {"outcome": "invalid", "detail": "scaffold_definition must have at least one stage"}

    title = scaffold_definition.get("title", "")
    if not title:
        return {"outcome": "invalid", "detail": "scaffold_definition must have a title"}

    connections = sum(len(s.get("depends_on", [])) for s in stages)
    action_inputs = {
        "scaffold_definition": scaffold_definition,
        "domain_id": _resolve_domain_id(
            inputs,
            scaffold_definition,
            ctx=ctx,
            source="draft_workflow_proposal",
        ),
    }

    return build_proposal_record(
        action_id="execute_draft_workflow_from_thread",
        action_type="draft_workflow_from_thread",
        action_inputs=action_inputs,
        preview_type="scaffold",
        outcome="proposal",
        scaffold_definition=scaffold_definition,
        stage_count=len(stages),
        connection_count=connections,
    )


def execute_draft(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Execute: create a new workflow from the accepted scaffold definition."""
    scaffold_definition: dict[str, Any] = inputs.get("scaffold_definition", {})
    domain_id: str = _resolve_domain_id(
        inputs,
        scaffold_definition,
        ctx=ctx,
        source="draft_workflow_execute",
    )

    payload: dict[str, Any] = {
        "title": scaffold_definition.get("title", ""),
        "domain_id": domain_id,
        "workflow_definition": scaffold_definition,
    }

    result = ctx.action_service.create_workflow(payload)

    # Extract workflow_id and revision ref from CF response.
    # CF returns: { "workflow": { "workflow_id": ... }, "resulting_revision_ref": { "revision_id": ... } }
    workflow_data = result.get("workflow", {})
    new_workflow_id = workflow_data.get("workflow_id", "")
    revision_ref = result.get("resulting_revision_ref", {})

    return {
        "outcome": "applied",
        "workflow_id": new_workflow_id,
        "resulting_revision_ref": revision_ref,
    }
