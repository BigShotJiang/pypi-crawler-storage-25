"""Clone-and-adapt handler — clone a workflow with targeted modifications."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.handlers.draft import _log_domain_coercion
from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.workflow_studio.starter_catalog import normalize_starter_domain_id


def _resolve_domain_id(
    inputs: dict[str, Any],
    definition: dict[str, Any],
    *,
    ctx: HandlerContext | None = None,
    source: str = "clone_and_adapt",
) -> str:
    """Resolve domain_id, defaulting to 'business' and coercing unregistered values.

    See draft.py:_resolve_domain_id — same rationale.
    """
    raw = str(inputs.get("domain_id") or definition.get("domain_id") or "business").strip()
    domain_id = normalize_starter_domain_id(raw) or "business"
    _log_domain_coercion(ctx, raw_domain_id=raw, coerced_domain_id=domain_id, source=source)
    return domain_id


def _stage_title(stage: dict[str, Any]) -> str:
    return stage.get("title", stage.get("stage_id", ""))


def propose_adaptation(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose cloning a workflow with adapted definition."""
    source_workflow_id: str = inputs.get("source_workflow_id", "")
    adapted_definition: dict[str, Any] = inputs.get("adapted_definition", {})

    source = ctx.repository.get_workflow(source_workflow_id)
    if source is None:
        return {"outcome": "invalid", "detail": f"Source workflow not found: {source_workflow_id}"}

    source_title = source.get("title", "")
    source_stages = source.get("workflow_definition", {}).get("stages", [])
    adapted_stages = adapted_definition.get("stages", [])

    # Build adaptation summary comparing source to adapted
    source_titles = {_stage_title(s) for s in source_stages}
    adapted_titles = {_stage_title(s) for s in adapted_stages}
    added = sorted(adapted_titles - source_titles)
    removed = sorted(source_titles - adapted_titles)
    # Stages with same title but possibly different content
    changed_titles = sorted(adapted_titles & source_titles)

    adaptation_summary: dict[str, Any] = {
        "source_stage_count": len(source_stages),
        "adapted_stage_count": len(adapted_stages),
        "added_stages": added,
        "removed_stages": removed,
        "retained_stages": changed_titles,
    }

    return build_proposal_record(
        action_id="execute_clone_and_adapt",
        action_type="clone_and_adapt",
        action_inputs={
            "source_workflow_id": source_workflow_id,
            "adapted_definition": adapted_definition,
            "domain_id": _resolve_domain_id(
                inputs,
                adapted_definition,
                ctx=ctx,
                source="clone_and_adapt_proposal",
            ),
        },
        preview_type="scaffold",
        outcome="proposal",
        adapted_definition=adapted_definition,
        source_workflow_id=source_workflow_id,
        source_title=source_title,
        adaptation_summary=adaptation_summary,
    )


def execute_adaptation(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Execute: create a new workflow from the adapted definition. Original is not mutated."""
    adapted_definition: dict[str, Any] = inputs.get("adapted_definition", {})
    domain_id: str = _resolve_domain_id(
        inputs,
        adapted_definition,
        ctx=ctx,
        source="clone_and_adapt_execute",
    )

    payload: dict[str, Any] = {
        "title": adapted_definition.get("title", ""),
        "domain_id": domain_id,
        "workflow_definition": adapted_definition,
    }

    # POST — no expected_revision_id needed (new workflow, not mutating source)
    result = ctx.action_service.create_workflow(payload)

    workflow_data = result.get("workflow", {})
    new_workflow_id = workflow_data.get("workflow_id", "")
    revision_ref = result.get("resulting_revision_ref", {})

    return {
        "outcome": "applied",
        "workflow_id": new_workflow_id,
        "resulting_revision_ref": revision_ref,
    }
