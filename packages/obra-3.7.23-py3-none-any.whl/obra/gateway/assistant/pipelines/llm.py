"""Structured LLM helpers for assistant pipelines."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.config.loaders import get_gateway_assistant_config
from obra.hybrid.preexecution_pipeline import build_preexecution_pipeline


def build_pipeline_llm_config(app_state: Any) -> dict[str, Any]:
    """Build TemplateEditPipeline config from canonical tier resolution."""
    assistant_config = get_gateway_assistant_config()
    pipeline_config = assistant_config.get("pipelines", {})
    provider_state = getattr(app_state, "assistant_llm_provider_state", None)
    provider_name = str(getattr(provider_state, "provider_name", "") or "").strip()
    default_model_id = str(getattr(provider_state, "default_model_id", "") or "").strip()
    auth_method = str(getattr(provider_state, "auth_method", "oauth") or "oauth").strip()
    resolved = resolve_tier_config(
        str(pipeline_config.get("llm_model_tier") or "fast"),
        role="orchestrator",
        override_provider=provider_name or None,
        override_model=default_model_id or None,
        override_auth_method=auth_method or None,
        override_reasoning_level=str(pipeline_config.get("llm_reasoning_level") or "default"),
    )
    return {
        **resolved,
        "auth": resolved["auth_method"],
    }


def run_structured_json(
    *,
    working_dir: Path,
    action_name: str,
    prompt: str,
    template_content: dict[str, Any],
    validator: Callable[[dict[str, Any]], tuple[bool, str | None]],
    llm_config: dict[str, Any],
    timeout_s: int,
    fallback_fn: Callable[[], dict[str, Any]] | None = None,
    log_event: Callable[..., None] | None = None,
    production_logger: Any | None = None,
) -> dict[str, Any]:
    """Execute one structured JSON call through TemplateEditPipeline.

    When the browser-rig stub middleware is active, the LLM call is skipped and
    ``fallback_fn`` is returned directly. This keeps the full pipeline lifecycle
    exercised in browser-rig mode without requiring a real LLM provider.
    """
    from obra.gateway.workflow_studio.assistant_stub_responses import (
        is_browser_rig_stub_mount_enabled,
        is_stub_enabled,
    )

    if is_stub_enabled() and is_browser_rig_stub_mount_enabled() and fallback_fn is not None:
        if log_event is not None:
            log_event(
                "asst.pipeline_step_stub",
                action_name=action_name,
                stub=True,
            )
        return fallback_fn()

    pipeline = build_preexecution_pipeline(
        working_dir=working_dir,
        action_name=action_name,
        log_event=log_event,
        production_logger=production_logger,
    )
    result, _metadata = pipeline.execute(
        base_prompt=prompt,
        template_content=template_content,
        validator=validator,
        fallback_fn=fallback_fn,
        llm_config=llm_config,
        timeout_s=timeout_s,
        allow_unchanged=False,
    )
    return result
