"""Built-in assistant action pipelines."""

from __future__ import annotations

from obra.gateway.assistant.pipelines.registry import get_pipeline, register_pipeline

_PIPELINE_MODULES = {
    "bulk_template_gen": "obra.gateway.assistant.pipelines.builtin.bulk_template_gen",
    "compliance_audit": "obra.gateway.assistant.pipelines.builtin.compliance_audit",
    "diagnostic": "obra.gateway.assistant.pipelines.builtin.diagnostic",
    "self_review": "obra.gateway.assistant.pipelines.builtin.self_review",
}

__all__ = ["register_builtin_pipelines", *_PIPELINE_MODULES]


def register_builtin_pipelines() -> None:
    """Register all gateway-owned built-in pipelines."""
    from obra.gateway.assistant.pipelines.builtin import (
        bulk_template_gen,
        compliance_audit,
        diagnostic,
        self_review,
    )

    for factory in (
        bulk_template_gen.create_definition,
        self_review.create_definition,
        diagnostic.create_definition,
        compliance_audit.create_definition,
    ):
        definition = factory()
        if get_pipeline(definition.pipeline_id) is None:
            register_pipeline(definition)


def __getattr__(name: str) -> object:
    """Lazy-load built-in pipeline modules on first use."""
    module_path = _PIPELINE_MODULES.get(name)
    if module_path is None:
        msg = f"module {__name__!r} has no attribute {name!r}"
        raise AttributeError(msg)

    import importlib

    module = importlib.import_module(module_path)
    globals()[name] = module
    return module
