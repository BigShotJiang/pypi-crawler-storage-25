"""Compliance audit pipeline for policy-driven workflow review."""

from __future__ import annotations

import json
from typing import Any
from uuid import uuid4

from obra.config.loaders import get_gateway_assistant_config
from obra.gateway.assistant.handlers.quality_gate import (
    build_quality_gate_proposal,
    build_quality_loop_payload,
)
from obra.gateway.assistant.handlers.structural import _get_stages
from obra.gateway.assistant.handlers.template_edit import build_template_edit_proposal
from obra.gateway.assistant.pipelines.engine import PipelineEngine
from obra.gateway.assistant.pipelines.llm import run_structured_json
from obra.gateway.assistant.pipelines.types import (
    PipelineDefinition,
    PipelineResult,
    StepDefinition,
)

PIPELINE_ID = "pipeline_compliance_audit"


def _workflow_stages(workflow_context: dict[str, Any]) -> list[dict[str, Any]]:
    stages = workflow_context.get("stages")
    if isinstance(stages, list):
        return [stage for stage in stages if isinstance(stage, dict)]
    return _get_stages(workflow_context)


def build_audit_steps(workflow_context: dict[str, Any]) -> list[StepDefinition]:
    """Create one compliance audit step per workflow stage."""
    return [
        StepDefinition(
            step_id=f"audit_{str(stage.get('stage_id') or stage.get('id') or '').strip()}",
            description=f"Audit stage: {stage.get('title') or stage.get('id') or 'stage'!s}",
            step_type="audit",
        )
        for stage in _workflow_stages(workflow_context)
        if str(stage.get("stage_id") or stage.get("id") or "").strip()
    ]


def execute_audit_step(
    engine: PipelineEngine,
    step: StepDefinition,
    workflow_context: dict[str, Any],
) -> dict[str, Any]:
    """Audit one stage against the supplied policy document."""
    stage_id = step.step_id.removeprefix("audit_")
    stage = next(
        (
            item
            for item in _workflow_stages(workflow_context)
            if str(item.get("stage_id") or item.get("id") or "").strip() == stage_id
        ),
        None,
    )
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")
    policy_document = str(
        workflow_context.get("policy_document")
        or workflow_context.get("params", {}).get("policy_document")
        or ""
    ).strip()
    if not policy_document:
        raise ValueError(
            "compliance_audit pipeline requires a non-empty policy_document in workflow_context"
        )
    prompt = (
        f"Policy document: {policy_document}\n"
        f"Stage definition: {json.dumps(stage, sort_keys=True)}\n"
        "Return JSON with compliance_status, gaps, proposed_mitigations."
    )
    template = {
        "compliance_status": "compliant",
        "gaps": [],
        "proposed_mitigations": [],
        "_instructions": "Return one stage-level policy audit assessment.",
    }

    def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
        if not str(data.get("compliance_status") or "").strip():
            return (False, "compliance_status is required")
        return (True, None)

    return run_structured_json(
        working_dir=engine.working_dir,
        action_name=f"{PIPELINE_ID}_{stage_id}",
        prompt=prompt,
        template_content=template,
        validator=validator,
        llm_config=engine.llm_config,
        timeout_s=engine.timeout_s,
        log_event=engine.log_event,
        production_logger=engine.production_logger,
        fallback_fn=lambda: {
            "compliance_status": "compliant",
            "gaps": [],
            "proposed_mitigations": [],
        },
    )


def build_audit_report(
    step_results: list[Any],
    workflow_context: dict[str, Any],
) -> PipelineResult:
    """Build proposal records from compliance gaps and mitigations."""
    workflow_id = str(workflow_context.get("workflow_id") or "")
    proposal_group = str(uuid4())
    proposals: list[dict[str, Any]] = []
    for result in step_results:
        output = result.output or {}
        stage_id = result.step_id.removeprefix("audit_")
        for mitigation in output.get("proposed_mitigations", []):
            if not isinstance(mitigation, dict):
                continue
            mitigation_type = str(mitigation.get("type") or "").strip()
            if mitigation_type == "gate_insertion":
                quality_loop = build_quality_loop_payload(workflow_context, stage_id=stage_id)
                proposals.append(
                    build_quality_gate_proposal(
                        workflow=workflow_context,
                        workflow_id=workflow_id,
                        stage_id=stage_id,
                        quality_loop=quality_loop,
                        proposal_group=proposal_group,
                    )
                )
            elif mitigation_type == "template_modification":
                proposed_content = str(mitigation.get("proposed_content") or "").strip()
                template_role = (
                    str(mitigation.get("template_role") or "purpose").strip() or "purpose"
                )
                proposals.append(
                    build_template_edit_proposal(
                        workflow=workflow_context,
                        workflow_id=workflow_id,
                        stage_id=stage_id,
                        template_role=template_role,
                        proposed_content=proposed_content,
                        proposal_group=proposal_group,
                    )
                )
    return PipelineResult(
        pipeline_id=PIPELINE_ID,
        status="completed",
        step_results=step_results,
        proposals=proposals,
        summary_message=f"Compliance audit prepared {len(proposals)} workflow proposals.",
    )


async def run_compliance_audit_pipeline(engine: PipelineEngine) -> Any:
    """Execute policy audit steps and build proposal outputs."""
    engine.set_step_handler(
        lambda step, workflow_context, _predecessors, _review_feedback=None: execute_audit_step(
            engine,
            step,
            workflow_context,
        )
    )
    steps = build_audit_steps(engine.workflow_context)
    for step in steps:
        for event in await engine.execute_step_with_events(step):
            yield event
        if engine.cancelled:
            remaining = steps[steps.index(step) + 1 :]
            engine.mark_pending_steps_skipped(remaining)
            engine.set_result(
                PipelineResult(
                    pipeline_id=PIPELINE_ID,
                    status="cancelled",
                    step_results=engine.step_results,
                    proposals=[],
                    summary_message="Compliance audit was cancelled.",
                )
            )
            return
    engine.set_result(build_audit_report(engine.step_results, engine.workflow_context))


def create_definition() -> PipelineDefinition:
    """Create the registered compliance audit pipeline definition."""
    assistant_config = get_gateway_assistant_config()
    pipeline_config = assistant_config.get("pipelines", {})
    return PipelineDefinition(
        pipeline_id=PIPELINE_ID,
        display_name="Compliance Audit",
        trigger_mode="manual",
        timeout_s=int(
            pipeline_config.get(
                "compliance_audit_timeout_s", pipeline_config.get("default_timeout_s", 600)
            )
        ),
        steps_factory=build_audit_steps,
        runner=run_compliance_audit_pipeline,
    )
