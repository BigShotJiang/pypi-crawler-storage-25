"""Error classification for transient vs non-transient retry decisions.

Provides heuristic-based classification of arbitrary exceptions, HTTP status
code sets for transient/non-transient errors, and retry-after extraction.

Metrics:
    - obra_errors_classified_total: Counter of classified errors
      Labels: classification (transient|non_transient), error_type

Usage:
    from obra.execution.error_classifier import is_transient, get_retry_after

    if is_transient(some_exception):
        delay = get_retry_after(some_exception)
        # retry with backoff
    else:
        # fail fast

Related:
    - obra/execution/errors.py (exception hierarchy)
    - obra/execution/retry.py (retry metrics)
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from http import HTTPStatus
from typing import Any

from obra.execution.errors import NonTransientError, TransientError

logger = logging.getLogger(__name__)

# Metric names following Prometheus naming convention
METRIC_ERRORS_CLASSIFIED = "obra_errors_classified_total"

# Global metrics storage for error classification
_error_classification_metrics: list[dict[str, Any]] = []


def emit_error_classification_metric(
    classification: str,
    error_type: str,
    log_event: Any | None = None,
    trace_id: str | None = None,
) -> dict[str, Any]:
    """Emit an error classification counter metric.

    Args:
        classification: "transient" or "non_transient"
        error_type: Name of the exception type
        log_event: Optional event logger callback
        trace_id: Optional trace ID for correlation

    Returns:
        The emitted metric dict
    """
    metric = {
        "metric_name": METRIC_ERRORS_CLASSIFIED,
        "value": 1,
        "labels": {
            "classification": classification,
            "error_type": error_type,
        },
        "timestamp": datetime.now(UTC).isoformat(),
        "metadata": {},
    }

    _error_classification_metrics.append(metric)

    if log_event:
        try:
            log_event(
                "error_classification_metric",
                session_id=None,
                trace_id=trace_id,
                **metric,
            )
        except Exception as e:
            logger.debug("Failed to log error classification metric: %s", e)

    logger.debug(
        "Emitted error classification metric: classification=%s, error_type=%s",
        classification,
        error_type,
    )

    return metric


def get_error_classification_metrics_summary() -> dict[str, Any]:
    """Get summary of error classification metrics.

    Returns:
        Summary dict with totals by classification and error type.
    """
    if not _error_classification_metrics:
        return {"total": 0, "transient": 0, "non_transient": 0, "by_error_type": {}}

    transient_count = sum(
        1
        for m in _error_classification_metrics
        if m.get("labels", {}).get("classification") == "transient"
    )
    non_transient_count = len(_error_classification_metrics) - transient_count

    by_error_type: dict[str, int] = {}
    for m in _error_classification_metrics:
        error_type = m.get("labels", {}).get("error_type", "unknown")
        by_error_type[error_type] = by_error_type.get(error_type, 0) + 1

    return {
        "total": len(_error_classification_metrics),
        "transient": transient_count,
        "non_transient": non_transient_count,
        "by_error_type": by_error_type,
    }


# HTTP status codes that indicate transient errors (retryable)
# Using HTTPStatus enum for semantic clarity (ADR-068)
TRANSIENT_HTTP_STATUSES: frozenset[HTTPStatus] = frozenset(
    {
        HTTPStatus.REQUEST_TIMEOUT,  # 408
        HTTPStatus.TOO_EARLY,  # 425
        HTTPStatus.TOO_MANY_REQUESTS,  # 429 (rate limit)
        HTTPStatus.INTERNAL_SERVER_ERROR,  # 500
        HTTPStatus.BAD_GATEWAY,  # 502
        HTTPStatus.SERVICE_UNAVAILABLE,  # 503
        HTTPStatus.GATEWAY_TIMEOUT,  # 504
    }
)

# Backward compatibility: integer set derived from HTTPStatus enum
# DEPRECATED: Use TRANSIENT_STATUSES from obra.api.response_handler instead
_TRANSIENT_HTTP_STATUS_CODES: frozenset[int] = frozenset(s.value for s in TRANSIENT_HTTP_STATUSES)

# HTTP status codes that indicate non-transient errors (fail fast)
# Using HTTPStatus enum for semantic clarity (ADR-068)
NON_TRANSIENT_HTTP_STATUSES: frozenset[HTTPStatus] = frozenset(
    {
        HTTPStatus.BAD_REQUEST,  # 400
        HTTPStatus.UNAUTHORIZED,  # 401
        HTTPStatus.FORBIDDEN,  # 403
        HTTPStatus.NOT_FOUND,  # 404
        HTTPStatus.METHOD_NOT_ALLOWED,  # 405
        HTTPStatus.CONFLICT,  # 409
        HTTPStatus.GONE,  # 410
        HTTPStatus.UNPROCESSABLE_ENTITY,  # 422
    }
)

# Backward compatibility: integer set derived from HTTPStatus enum
# DEPRECATED: Use NON_TRANSIENT_HTTP_STATUSES with HTTPStatus values instead
_NON_TRANSIENT_HTTP_STATUS_CODES: frozenset[int] = frozenset(
    s.value for s in NON_TRANSIENT_HTTP_STATUSES
)


def is_transient(error: BaseException, *, emit_metric: bool = True) -> bool:
    """Classify whether an error is transient (retryable).

    This function inspects an exception and determines if it represents a
    transient failure that may succeed on retry.

    Classification rules (in order of precedence):
    1. TransientError instances -> True
    2. NonTransientError instances -> False
    3. HTTP status code analysis (from APIError, HTTPError, etc.)
    4. Exception message heuristics (timeout, rate limit, connection)
    5. Exception type matching (OSError, ConnectionError, TimeoutError)

    Args:
        error: The exception to classify
        emit_metric: Whether to emit a classification metric (default True)

    Returns:
        True if the error is transient and should be retried,
        False if the error is non-transient and should fail fast
    """
    error_type = type(error).__name__
    result: bool

    # Rule 1: Explicit TransientError types
    if isinstance(error, TransientError):
        result = True
    # Rule 2: Explicit NonTransientError types
    elif isinstance(error, NonTransientError):
        result = False
    else:
        # Rule 3: Check for HTTP status codes
        status_code = _extract_status_code(error)
        if status_code is not None:
            if status_code in _TRANSIENT_HTTP_STATUS_CODES:
                result = True
            elif status_code in _NON_TRANSIENT_HTTP_STATUS_CODES:
                result = False
            else:
                result = _classify_by_heuristics(error)
        else:
            result = _classify_by_heuristics(error)

    # Emit error classification metric (P1 observability)
    if emit_metric:
        emit_error_classification_metric(
            classification="transient" if result else "non_transient",
            error_type=error_type,
        )

    return result


def _classify_by_heuristics(error: BaseException) -> bool:
    """Classify error by message and type heuristics.

    Args:
        error: The exception to classify

    Returns:
        True if transient, False otherwise
    """
    # Rule 4: Exception message heuristics
    error_message = str(error).lower()
    if _has_transient_message(error_message):
        return True
    if _has_non_transient_message(error_message):
        return False

    # Rule 5: Exception type matching
    if _is_transient_exception_type(error):
        return True

    # Default: treat unknown errors as non-transient (fail fast)
    return False


def _extract_status_code(error: BaseException) -> int | None:
    """Extract HTTP status code from an exception if available.

    Handles common patterns:
    - error.status_code (requests, httpx, obra.exceptions.APIError)
    - error.response.status_code (requests, httpx)
    - error.code (urllib)

    Args:
        error: The exception to extract status code from

    Returns:
        HTTP status code if found, None otherwise
    """
    # Direct status_code attribute (APIError, HTTPStatusError, etc.)
    if hasattr(error, "status_code"):
        code = error.status_code
        if isinstance(code, int):
            return code

    # Response object with status_code (requests.HTTPError, httpx.HTTPStatusError)
    if hasattr(error, "response"):
        response = error.response
        if response is not None and hasattr(response, "status_code"):
            code = response.status_code
            if isinstance(code, int):
                return code

    # urllib-style code attribute
    if hasattr(error, "code"):
        code = error.code
        if isinstance(code, int):
            return code

    return None


def _has_transient_message(message: str) -> bool:
    """Check if error message indicates a transient error.

    Args:
        message: Lowercase error message to check

    Returns:
        True if message suggests a transient error
    """
    transient_patterns = [
        "rate limit",
        "rate-limit",
        "ratelimit",
        "too many requests",
        "throttl",
        "timeout",
        "timed out",
        "connection reset",
        "connection refused",
        "connection error",
        "temporarily unavailable",
        "service unavailable",
        "server overloaded",
        "try again later",
        "retry",
        "temporary",
        "transient",
        "overloaded",
        "capacity",
    ]
    return any(pattern in message for pattern in transient_patterns)


def _has_non_transient_message(message: str) -> bool:
    """Check if error message indicates a non-transient error.

    Args:
        message: Lowercase error message to check

    Returns:
        True if message suggests a non-transient error
    """
    non_transient_patterns = [
        "invalid",
        "validation",
        "not found",
        "does not exist",
        "unauthorized",
        "forbidden",
        "permission denied",
        "access denied",
        "authentication failed",
        "bad request",
        "malformed",
    ]
    return any(pattern in message for pattern in non_transient_patterns)


def _is_transient_exception_type(error: BaseException) -> bool:
    """Check if exception type indicates a transient error.

    Args:
        error: The exception to check

    Returns:
        True if exception type is typically transient
    """
    # Built-in timeout and connection errors
    # Note: We check class names to avoid import dependencies
    transient_type_names = {
        "TimeoutError",
        "ConnectionError",
        "ConnectionResetError",
        "ConnectionRefusedError",
        "ConnectionAbortedError",
        "BrokenPipeError",
        "OSError",  # Often indicates network issues
        # Common library exceptions
        "ConnectTimeout",
        "ReadTimeout",
        "Timeout",
        "ConnectionTimeout",
        "PoolError",
        "MaxRetryError",
        "NewConnectionError",
    }

    error_type_name = type(error).__name__
    if error_type_name in transient_type_names:
        return True

    # Check base classes
    return any(base.__name__ in transient_type_names for base in type(error).__mro__)


def get_retry_after(error: BaseException) -> float | None:
    """Extract retry-after delay from an error if available.

    Checks common patterns:
    - error.retry_after (TransientError)
    - error.response.headers["Retry-After"]
    - Parse from error message

    Args:
        error: The exception to extract retry-after from

    Returns:
        Seconds to wait before retrying, or None if not specified
    """
    # Direct retry_after attribute (TransientError)
    if hasattr(error, "retry_after"):
        retry_after = error.retry_after
        if isinstance(retry_after, (int, float)) and retry_after > 0:
            return float(retry_after)

    # Response headers (HTTP libraries)
    if hasattr(error, "response"):
        response = error.response
        if response is not None and hasattr(response, "headers"):
            headers = response.headers
            if headers is not None:
                retry_after = headers.get("Retry-After") or headers.get("retry-after")
                if retry_after is not None:
                    try:
                        return float(retry_after)
                    except (ValueError, TypeError):
                        pass

    return None
