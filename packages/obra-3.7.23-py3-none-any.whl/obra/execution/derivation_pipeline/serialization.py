"""Serialization facade for the derivation engine pipeline."""

from __future__ import annotations

import logging
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config.loaders import (
    get_derivation_epic_item_rederive_threshold,
    get_derivation_epic_output_token_limit,
    get_derivation_preview_config,
)

from ._epic_parser import EpicParser
from ._plan_assembler import PlanAssembler
from ._plan_serializer import PlanSerializer
from ._plan_validator import PlanValidator

logger = logging.getLogger(__name__)

_preview_config = get_derivation_preview_config()
RAW_RESPONSE_PREVIEW_LIMIT = _preview_config["raw_response_limit"]
ITEM_COUNT_WARNING_THRESHOLDS = (25, 50, 100, 200, 500, 1000)

EPIC_ITEM_REDERIVE_THRESHOLD = get_derivation_epic_item_rederive_threshold()
EPIC_OUTPUT_TOKEN_LIMIT = get_derivation_epic_output_token_limit()

VALID_PHASES = ["explore", "plan", "implement", "commit"]
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",
    "plan": None,
    "implement": None,
    "commit": None,
}


def _engine_attr(name: str, default: Any) -> Any:
    module = sys.modules.get("obra.execution.derivation")
    if module is None:
        return default
    return getattr(module, name, default)


def _epic_limits() -> tuple[int, int]:
    return (
        int(_engine_attr("EPIC_ITEM_REDERIVE_THRESHOLD", EPIC_ITEM_REDERIVE_THRESHOLD)),
        int(_engine_attr("EPIC_OUTPUT_TOKEN_LIMIT", EPIC_OUTPUT_TOKEN_LIMIT)),
    )


_EPIC_PARSER = EpicParser()
_PLAN_VALIDATOR = PlanValidator(
    raw_response_preview_limit=RAW_RESPONSE_PREVIEW_LIMIT,
    item_count_warning_thresholds=ITEM_COUNT_WARNING_THRESHOLDS,
    epic_limits=_epic_limits,
    valid_phases=VALID_PHASES,
    phase_to_agent=PHASE_TO_AGENT,
)


class DerivationSerializationService:
    """Stable engine-facing facade over parser, serializer, and validator owners."""

    def __init__(self, owner: Any) -> None:
        self._owner = owner
        self._parser = _EPIC_PARSER
        self._validator = _PLAN_VALIDATOR
        self._serializer = PlanSerializer(
            parse_flat_response=owner._parse_flat_response_via_pipeline,
            working_dir=Path(owner._working_dir),
            reasoning_level=owner._reasoning_level,
            validator=self._validator,
            epic_limits=_epic_limits,
            owner=owner,
            prompt_builder=getattr(owner, "_prompt_builder", None),
        )

    @staticmethod
    def validate_step1_epics(content: dict, min_epics: int) -> tuple[bool, str | None]:
        return _EPIC_PARSER.validate_step1_epics(content, min_epics)

    @staticmethod
    def normalize_epics(epics_data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return _EPIC_PARSER.normalize_epics(epics_data)

    def parse_epics_from_prose(self, epics_prose: str) -> list[dict[str, Any]]:
        return self._parser.parse_epics_from_prose(epics_prose)

    def log_item_count_warning(self, item_count: int) -> None:
        self._validator.log_item_count_warning(item_count)

    @staticmethod
    def extract_epics_from_prose(epics_prose: str) -> list[dict[str, Any]]:
        return _EPIC_PARSER.extract_epics_from_prose(epics_prose)

    @staticmethod
    def render_epics_prose(epics: list[dict[str, Any]]) -> str:
        return _EPIC_PARSER.render_epics_prose(epics)

    @staticmethod
    def extract_epic_story_task_titles(
        epic_detail_prose: str,
        epic_id: str,
    ) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
        return _PLAN_VALIDATOR.extract_epic_story_task_titles(epic_detail_prose, epic_id)

    @staticmethod
    def build_partial_plan_items(
        epic_id: str,
        epic_title: str,
        stories: list[dict[str, str]],
        tasks: list[dict[str, str]],
    ) -> list[dict[str, Any]]:
        return PlanAssembler.build_partial_plan_items(epic_id, epic_title, stories, tasks)

    @staticmethod
    def estimate_output_tokens(text: str) -> int:
        return _PLAN_VALIDATOR.estimate_output_tokens(text)

    @staticmethod
    def validate_epic_prose(content: str, epic_id: str) -> tuple[bool, str | None]:
        return _PLAN_VALIDATOR.validate_epic_prose(content, epic_id)

    @staticmethod
    def count_epic_story_task_ids(epic_detail_prose: str, epic_id: str) -> tuple[int, int]:
        return _PLAN_VALIDATOR.count_epic_story_task_ids(epic_detail_prose, epic_id)

    @staticmethod
    def count_epic_items(epic_detail_prose: str, epic_id: str | None = None) -> int:
        return _PLAN_VALIDATOR.count_epic_items(epic_detail_prose, epic_id)

    @staticmethod
    def extract_reason_codes_for_epic(
        epic_detail_prose: str,
        epic_id: str,
        *,
        status: str = "",
        item_count: int | None = None,
        output_tokens: int | None = None,
    ) -> list[str]:
        return _PLAN_VALIDATOR.extract_reason_codes_for_epic(
            epic_detail_prose,
            epic_id,
            status=status,
            item_count=item_count,
            output_tokens=output_tokens,
        )

    @staticmethod
    def write_epic_failure_artifact(
        working_dir,
        *,
        epic_id: str,
        story_count: int,
        task_count: int,
        reason_codes: list[str],
        retry_metadata: dict[str, Any],
        output_preview: str,
    ) -> str | None:
        return _PLAN_VALIDATOR.write_epic_failure_artifact(
            working_dir,
            epic_id=epic_id,
            story_count=story_count,
            task_count=task_count,
            reason_codes=reason_codes,
            retry_metadata=retry_metadata,
            output_preview=output_preview,
        )

    def merge_epic_details(self, epics_prose: str, all_epic_details: list[str]) -> str:
        return PlanAssembler.merge_epic_details(epics_prose, all_epic_details)

    def serialize_per_epic(
        self,
        all_epic_details: list[str],
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        return self._serializer.serialize_per_epic(
            all_epic_details=all_epic_details,
            parsed_epics=parsed_epics,
            provider=provider,
            progress_callback=progress_callback,
        )

    def derive_per_epic(
        self,
        objective: str,
        epics_prose: str,
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
    ) -> tuple[str, list[str], int]:
        return self._serializer.derive_per_epic(
            objective=objective,
            epics_prose=epics_prose,
            parsed_epics=parsed_epics,
            provider=provider,
            progress_callback=progress_callback,
            intent_markdown=intent_markdown,
            exploration_context=exploration_context,
        )

    def derive_multi_step_plan(
        self,
        objective: str,
        project_context: str,
        constraints: str,
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        validation_intensity: str = "light",
    ) -> tuple[list[dict[str, Any]], int]:
        """Derive implementation plan using the stable facade orchestration flow.

        Delegates the heavy orchestration to ``MultiStepOrchestrator`` while
        retaining pipeline-level bookkeeping (timing, token totals, logging).
        """
        from ._multi_step_orchestrator import MultiStepOrchestrator

        pipeline_start = time.perf_counter()
        step_tokens: dict[str, dict[str, int]] = {}

        logger.info(
            "derivation_pipeline_started",
            extra={"objective_length": len(objective)},
        )

        orchestrator = MultiStepOrchestrator(
            owner=self._owner,
            serialization_service=self,
            epic_parser=self._parser,
            plan_validator=self._validator,
            epic_limits=_epic_limits,
        )

        step1_result = orchestrator.orchestrate_step1(
            objective=objective,
            project_context=project_context,
            constraints=constraints,
            provider=provider,
            progress_callback=progress_callback,
        )
        total_tokens = step1_result.tokens
        step_tokens["structure"] = {"total_tokens": step1_result.tokens}

        plan_items, step2_tokens = orchestrator.orchestrate_step2(
            objective=objective,
            step1_result=step1_result,
            provider=provider,
            progress_callback=progress_callback,
            validation_intensity=validation_intensity,
        )
        total_tokens += step2_tokens

        logger.info(
            "Multi-step derivation completed: %d items, %d total tokens",
            len(plan_items),
            total_tokens,
        )
        pipeline_duration_ms = int((time.perf_counter() - pipeline_start) * 1000)
        logger.info(
            "derivation_pipeline_completed",
            extra={
                "total_duration_ms": pipeline_duration_ms,
                "total_tokens": total_tokens,
                "item_count": len(plan_items),
                "step_tokens": step_tokens,
            },
        )

        return plan_items, total_tokens

    def parse_flat_response_via_pipeline(
        self,
        prompt: str,
        provider: str,
    ) -> list[dict[str, Any]]:
        return self._serializer.parse_flat_response_via_pipeline(prompt, provider)

    def normalize_flat_plan_items(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return self._serializer.normalize_flat_plan_items(items)

    def parse_response_via_pipeline(self, prompt: str, provider: str) -> list[dict[str, Any]]:
        return self._serializer.parse_response_via_pipeline(prompt, provider)

    def normalize_hierarchical_plan_items(
        self,
        items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        return self._validator.normalize_hierarchical_plan_items(items)

    def validate_plan_items(self, plan_items: list[dict[str, Any]]) -> list[str]:
        return self._validator.validate_plan_items(plan_items)
