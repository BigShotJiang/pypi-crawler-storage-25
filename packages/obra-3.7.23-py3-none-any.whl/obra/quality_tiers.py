"""Quality Tiers — Tier Resolution, Dimension Parsing, and Reasoning Profiles.

Provides quality-tier resolution for LLM models, model dimension parsing,
reasoning profile access, and refinement iteration scaling.  Imports
``MODEL_REGISTRY`` and ``resolve_alias`` from ``obra.model_lookup``.

Migration Note:
    Extracted from ``obra.model_registry`` as part of REFACTOR-SCHEMAS-P7-001.
    ``obra.model_registry`` re-exports every public symbol for backward
    compatibility.
"""

import re
from dataclasses import dataclass
from typing import Any, Literal

from obra.model_lookup import (
    MODEL_REGISTRY,
    REASONING_LEVELS,
    get_default_model,
    get_model_info,
    resolve_alias,
)

# =============================================================================
# Quality Tier Types
# =============================================================================

# Quality tier determines refinement settings based on model capability.
# "fast" = smaller models (haiku, mini) - lower investment knobs
# "medium" = balanced models (sonnet) - standard investment knobs
# "high" = largest models (opus) - higher-capability tier, same policy knobs
QualityTier = Literal["fast", "medium", "high"]


@dataclass
class ModelDimensions:
    """Canonical decomposition of model identity for dimension-based tier resolution.

    Different providers signal capability tier through different dimensions:
    - Anthropic: series (opus/sonnet/haiku)
    - OpenAI: variant (mini/max)
    - Google: series+variant (pro, flash, flash-lite)
    - Ollama: variant (size tag: 3b/32b)

    The parsing logic extracts the capability-signaling dimension,
    not the version number. This makes the system version-agnostic:
    when Opus 5.0 releases, parsing extracts series="opus" and rules
    resolve to "high" tier without code changes.

    Example:
        >>> dims = parse_model_dimensions("anthropic", "claude-opus-4-6")
        >>> dims.series
        'opus'
        >>> dims.version
        '4.6'
    """

    provider: str  # anthropic, openai, google, ollama
    family: str  # claude, gpt, gemini, qwen, phi
    series: str | None = None  # opus/sonnet/haiku, codex, pro/flash, coder
    variant: str | None = None  # mini/max, lite, 3b/32b
    version: str | None = None  # 4.5, 5.1, 2.5
    timestamp: str | None = None  # 20251101 (optional)


@dataclass
class ReasoningProfile:
    """Reasoning capability profile for a provider/model."""

    provider: str
    model_id: str | None
    default_level: str
    supported_levels: set[str]
    level_map: dict[str, str | None]


# =============================================================================
# Quality Tier Rules - Provider-Specific Dimension Mapping
# =============================================================================

# Each provider signals capability tier through different dimensions.
# "_key" specifies which dimension to look up for tier resolution.
# "_default" is fallback for unknown/missing values.
QUALITY_TIER_RULES: dict[str, dict[str, str]] = {
    "anthropic": {
        "_key": "series",
        "opus": "high",
        "sonnet": "medium",
        "haiku": "fast",
        "_default": "medium",
    },
    "openai": {
        "_key": "variant",
        "mini": "fast",
        "spark": "fast",
        "max": "medium",
        "_default": "medium",  # no variant = base model = medium
    },
    "google": {
        "_key": "series_variant",  # compound key: "{series}" or "{series}-{variant}"
        "pro": "high",
        "pro-preview": "high",
        "flash": "medium",
        "flash-preview": "medium",
        "flash-lite": "fast",
        "_default": "medium",
    },
    "ollama": {
        "_key": "variant",
        "3b": "fast",
        "7b": "medium",
        "14b": "medium",
        "32b": "high",
        "mini": "fast",
        "_default": "medium",
    },
}


# =============================================================================
# Quality Tier Defaults - Tier to Settings Mapping
# =============================================================================

# Quality settings per tier - used by DecisionConfig to configure refinement.
# Tiers now carry only investment knobs: refinement iterations and score floor.
# Blocking policy lives under review.fix_loop per ADR-114 §2.
#
# Research basis (see reference_review_loop_research.md):
#   - Rounds 1-2 capture ~75% of findable issues (convergence model)
#   - Rounds 3+ enter degradation zone: +37.6% new vulnerabilities at 5 iterations (IEEE-ISTAS 2025)
#   - LLM examiners structurally produce false positives; more passes amplifies noise
#   - Obra's server-curated context and oscillation detection mitigate but do not eliminate this
#   - Complex task investment is handled by rigor mode (THOROUGH), not extra examine/revise loops
#
# medium and high resolve to the same settings. The three-value enum is
# preserved for backward compatibility; rigor mode (not quality tier) is the
# axis for scaling investment in complex tasks.
QUALITY_TIER_DEFAULTS: dict[str, dict[str, Any]] = {
    "fast": {
        "max_refinement_iterations": 1,
        "quality_threshold": 0.5,
    },
    "medium": {
        "max_refinement_iterations": 2,
        "quality_threshold": 0.7,
    },
    "high": {
        "max_refinement_iterations": 2,
        "quality_threshold": 0.7,
    },
}


# =============================================================================
# Model Dimension Parsing Patterns
# =============================================================================

# Provider-specific regex patterns for parsing model IDs into dimensions.
# Each provider has a different naming convention for signaling model capability.
# The "groups" list names the capture groups in order for the regex.
MODEL_DIMENSION_PATTERNS: dict[str, dict[str, Any]] = {
    "anthropic": {
        # claude-{series}-{major}-{minor}-{timestamp?}
        # Examples: claude-opus-4-6, claude-sonnet-4-6, opus (alias)
        "regex": r"^(?:claude-)?(\w+)(?:-(\d+)-(\d+))?(?:-(\d+))?$",
        "groups": ["series", "version_major", "version_minor", "timestamp"],
    },
    "openai": {
        # gpt-{version}-{series}-{variant?}
        # Examples: gpt-5.1-codex-mini, gpt-5.2-codex, gpt-5.4-mini, codex (alias)
        "regex": r"^(?:gpt-(\d+\.?\d*)-)?(\w+)(?:-(\w+))?$",
        "groups": ["version", "series", "variant"],
    },
    "google": {
        # gemini-{version}-{series}-{variant?}
        # Examples: gemini-2.5-flash-lite, gemini-3.1-pro-preview
        "regex": r"^gemini-(\d+\.?\d*)-(\w+)(?:-(\w+))?$",
        "groups": ["version", "series", "variant"],
    },
    "ollama": {
        # {family}{version?}-{series?}:{variant}
        # Examples: qwen2.5-coder:32b, phi3:mini
        "regex": r"^(\w+?)(\d+\.?\d*)?(?:-(\w+))?:(\w+)$",
        "groups": ["family", "version", "series", "variant"],
    },
}


# =============================================================================
# Quality Tier Resolution
# =============================================================================


def parse_model_dimensions(provider: str, model_id: str) -> ModelDimensions:
    """Parse a model ID into its canonical dimensions.

    Extracts the capability-signaling dimensions from a model identifier
    using provider-specific regex patterns. This is version-agnostic:
    "claude-opus-5-0-20261201" extracts series="opus" regardless of version.

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model_id: Model identifier string (e.g., "claude-opus-4-6", "haiku")

    Returns:
        ModelDimensions with extracted fields. Unknown/missing fields are None.

    Example:
        >>> dims = parse_model_dimensions("anthropic", "claude-opus-4-6")
        >>> dims.series, dims.version
        ('opus', '4.6')

        >>> dims = parse_model_dimensions("anthropic", "haiku")
        >>> dims.series
        'haiku'

        >>> dims = parse_model_dimensions("openai", "gpt-5.1-codex-mini")
        >>> dims.series, dims.variant
        ('codex', 'mini')
    """
    # Default dimensions with provider and unknown family
    defaults = ModelDimensions(provider=provider, family="unknown")

    # Get provider patterns
    patterns = MODEL_DIMENSION_PATTERNS.get(provider)
    if not patterns:
        return defaults

    regex_pattern = patterns.get("regex")
    group_names = patterns.get("groups", [])

    if not regex_pattern:
        return defaults

    # Try to match the model_id
    match = re.match(regex_pattern, model_id)
    if not match:
        if provider == "google":
            resolved_model = resolve_alias(provider, model_id)
            if model_id == "auto" and resolved_model != model_id:
                return parse_model_dimensions(provider, resolved_model)
            if model_id.startswith("auto-gemini-"):
                return ModelDimensions(
                    provider=provider,
                    family="gemini",
                    series="auto",
                    version=model_id.removeprefix("auto-gemini-"),
                )
            if resolved_model != model_id:
                return parse_model_dimensions(provider, resolved_model)
        # For anthropic, aliases like "haiku" should still parse to series="haiku"
        if provider == "anthropic" and model_id in ("opus", "sonnet", "haiku"):
            return ModelDimensions(
                provider=provider,
                family="claude",
                series=model_id,
            )
        # For openai, aliases like "codex" should parse to series="codex"
        if provider == "openai" and model_id in ("codex",):
            return ModelDimensions(
                provider=provider,
                family="gpt",
                series=model_id,
            )
        if provider == "openai":
            gpt_match = re.match(r"^gpt-(\d+\.?\d*)$", model_id)
            if gpt_match:
                return ModelDimensions(
                    provider=provider,
                    family="gpt",
                    series="gpt",
                    version=gpt_match.group(1),
                )
        return defaults

    # Extract groups into a dict
    groups = match.groups()
    extracted: dict[str, str | None] = {}
    for i, name in enumerate(group_names):
        if i < len(groups):
            extracted[name] = groups[i]

    # Build ModelDimensions based on provider
    if provider == "anthropic":
        # Family is always "claude" for Anthropic
        version = None
        if extracted.get("version_major") and extracted.get("version_minor"):
            version = f"{extracted['version_major']}.{extracted['version_minor']}"
        return ModelDimensions(
            provider=provider,
            family="claude",
            series=extracted.get("series"),
            version=version,
            timestamp=extracted.get("timestamp"),
        )

    if provider == "openai":
        series = extracted.get("series")
        variant = extracted.get("variant")

        # GPT base-model variants like gpt-5.4-mini and gpt-5.4-nano omit an
        # explicit series token. Normalize them to series="gpt" so quality-tier
        # resolution can continue to key off the variant.
        if extracted.get("version") and series in {"mini", "nano"} and variant is None:
            series, variant = "gpt", series

        return ModelDimensions(
            provider=provider,
            family="gpt",
            series=series,
            variant=variant,
            version=extracted.get("version"),
        )

    if provider == "google":
        return ModelDimensions(
            provider=provider,
            family="gemini",
            series=extracted.get("series"),
            variant=extracted.get("variant"),
            version=extracted.get("version"),
        )

    if provider == "ollama":
        # Family comes from the regex for ollama
        return ModelDimensions(
            provider=provider,
            family=extracted.get("family") or "unknown",
            series=extracted.get("series"),
            variant=extracted.get("variant"),
            version=extracted.get("version"),
        )

    return defaults


def supports_extended_thinking(provider: str, model_id: str) -> bool:
    """Check whether a model supports extended thinking.

    For providers without explicit extended thinking gating, this returns True
    to preserve existing behavior where thinking level is not restricted.

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model_id: Model identifier string

    Returns:
        True if extended thinking is supported, False otherwise.
    """
    if provider != "anthropic":
        return True

    dims = parse_model_dimensions(provider, model_id)
    return dims.series in ("opus", "sonnet")


def supports_anthropic_cli_effort(model_id: str) -> bool:
    """Check whether a Claude model supports CLI ``--effort``.

    Anthropic CLI effort is enabled for Claude model versions 4.6+.
    Known 4.5 models (including the current Haiku 4.5 alias target) are
    treated as unsupported and should not receive ``--effort``.

    Args:
        model_id: Anthropic model alias or canonical ID

    Returns:
        True when the model resolves to Claude 4.6+, else False.
    """
    if not model_id:
        return False

    candidate_model = get_default_model("anthropic") if model_id == "default" else model_id
    if not candidate_model:
        return False

    resolved_model = resolve_alias("anthropic", candidate_model)
    dims = parse_model_dimensions("anthropic", resolved_model)
    if dims.family != "claude" or not dims.version:
        return False

    major_str, _, minor_str = dims.version.partition(".")
    if not major_str.isdigit() or not minor_str.isdigit():
        return False

    major = int(major_str)
    minor = int(minor_str)
    return major > 4 or (major == 4 and minor >= 6)


def get_reasoning_profile(
    provider: str,
    model: str | None,
    *,
    role: str | None = None,
    tier: str | None = None,
) -> ReasoningProfile:
    """Get reasoning capability profile for a provider/model/context."""
    config = MODEL_REGISTRY.get(provider)
    if not config:
        return ReasoningProfile(
            provider=provider,
            model_id=model,
            default_level="medium",
            supported_levels=set(REASONING_LEVELS),
            level_map={},
        )

    effective_model = model or config.default_model
    model_info = None
    if effective_model:
        model_info = get_model_info(provider, effective_model, resolve_aliases=True)

    context_default_level: str | None = None
    if model_info and role and tier:
        context_key = f"{role}.{tier}"
        role_tier_defaults = model_info.reasoning_role_tier_defaults or {}
        candidate = role_tier_defaults.get(context_key)
        if isinstance(candidate, str) and candidate in REASONING_LEVELS:
            context_default_level = candidate

    default_level = context_default_level or (
        model_info.reasoning_default_level
        if model_info and model_info.reasoning_default_level
        else config.default_reasoning_level
    )
    supported_levels = (
        model_info.reasoning_supported_levels
        if model_info and model_info.reasoning_supported_levels
        else (
            config.reasoning_supported_levels
            if config.reasoning_supported_levels
            else set(REASONING_LEVELS)
        )
    )

    # Resolve crosswalk: provider-level map is the baseline; a model-level map
    # is merged over it so each model only declares keys where it diverges.
    effective_level_map: dict[str, str | None] = dict(config.reasoning_level_map)
    if model_info and model_info.reasoning_level_map:
        effective_level_map.update(model_info.reasoning_level_map)

    return ReasoningProfile(
        provider=provider,
        model_id=model_info.id if model_info else effective_model,
        default_level=default_level or "medium",
        supported_levels=supported_levels,
        level_map=effective_level_map,
    )


def resolve_quality_tier(provider: str, model_id: str) -> QualityTier:
    """Resolve quality tier using hybrid approach.

    Resolution order:
    1. Check ModelInfo.quality_tier (explicit override in registry)
    2. Parse model_id and apply dimension-based rules
    3. Fall back to "medium"

    This is version-agnostic: when Opus 5.0 releases, parsing extracts
    series="opus" and rules resolve to "high" without code changes.

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model_id: Model identifier string

    Returns:
        Quality tier: "fast", "medium", or "high"

    Example:
        >>> resolve_quality_tier("anthropic", "haiku")
        'fast'
        >>> resolve_quality_tier("openai", "gpt-5.1-codex-mini")
        'fast'
        >>> resolve_quality_tier("anthropic", "claude-opus-5-0-20261201")  # Future model
        'high'  # Resolved via dimension rules
        >>> resolve_quality_tier("unknown_provider", "unknown_model")
        'medium'  # Safe default
    """
    # 1. Check explicit override in registry
    config = MODEL_REGISTRY.get(provider)
    if config:
        model_info = config.models.get(model_id)
        if model_info and model_info.quality_tier:
            return model_info.quality_tier

    # 2. Dimension-based resolution
    dims = parse_model_dimensions(provider, model_id)
    rules = QUALITY_TIER_RULES.get(provider, {})
    tier_key_type = rules.get("_key", "series")

    # Extract the tier-determining value based on provider's key type
    key: str | None = None
    if tier_key_type == "series":
        key = dims.series
    elif tier_key_type == "variant":
        key = dims.variant
    elif tier_key_type == "series_variant":
        # Compound: "flash-lite" or just "flash"
        key = f"{dims.series}-{dims.variant}" if dims.series and dims.variant else dims.series

    # Lookup with fallback to provider default, then global default
    tier = (
        rules.get(key, rules.get("_default", "medium")) if key else rules.get("_default", "medium")
    )

    # Ensure valid tier value
    if tier in ("fast", "medium", "high"):
        return tier  # type: ignore[return-value]
    return "medium"


def scale_max_refinement_iterations(base_iterations: int, plan_item_count: int) -> int:
    """Scale max refinement iterations based on plan item count.

    Larger plans need more refinement cycles to converge. This applies
    a step function that adds iterations for larger plans while capping
    at tier-appropriate limits.

    Thresholds:
        items <= 15:   base (no adjustment)
        items 16-40:   base + 1
        items 41+:     base + 2

    Args:
        base_iterations: Base max iterations from the quality tier.
        plan_item_count: Total number of plan items (epics + stories + tasks).

    Returns:
        Adjusted max refinement iterations.
    """
    if plan_item_count > 40:
        return base_iterations + 2
    if plan_item_count > 15:
        return base_iterations + 1
    return base_iterations


def get_quality_config_for_model(
    provider: str,
    model_id: str,
    *,
    plan_item_count: int | None = None,
    policy_mode: str | None = None,
) -> dict[str, Any]:
    """Get quality configuration settings for a model.

    Returns the QUALITY_TIER_DEFAULTS entry for the resolved tier.
    This provides tier investment settings: max_refinement_iterations and
    quality_threshold. Fix-loop attention and hard-block policy are independent
    review.fix_loop settings per ADR-114 §2.

    When ``plan_item_count`` is provided, ``max_refinement_iterations`` is
    scaled via :func:`scale_max_refinement_iterations` to give larger plans
    more convergence budget.

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model_id: Model identifier string
        plan_item_count: Optional total plan items for iteration scaling.
        policy_mode: Optional explicit quality tier override. When set to
            ``fast``, ``medium``, or ``high``, this takes precedence over
            model-based tier resolution. ``None`` or ``auto`` preserves the
            model-derived tier behavior.

    Returns:
        Quality settings dict with keys:
        - max_refinement_iterations: int - Max refinement attempts
        - quality_threshold: float - Minimum quality score required

    Example:
        >>> config = get_quality_config_for_model("anthropic", "haiku")
        >>> config["max_refinement_iterations"]
        1

        >>> config = get_quality_config_for_model("anthropic", "opus")
        >>> config["max_refinement_iterations"]
        5
    """
    if policy_mode in {"fast", "medium", "high"}:
        tier = policy_mode
    else:
        tier = resolve_quality_tier(provider, model_id)
    config = dict(QUALITY_TIER_DEFAULTS.get(tier, QUALITY_TIER_DEFAULTS["medium"]))
    if plan_item_count is not None:
        config["max_refinement_iterations"] = scale_max_refinement_iterations(
            config["max_refinement_iterations"], plan_item_count
        )
    return config
