"""Failure-shape extraction and comparison for fix-worker auto-commit gates.

The harness emits ``commit_blocked_reason='shape_change_unverified'`` when a
shape cannot be extracted and ``commit_blocked_reason='shape_did_not_change'``
when a patched-worktree rerun preserves the diagnosed signature. The gate
checks whether a fix moved the failure in the analyzer's stated direction
before the autonomous patch is committed.
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal, Protocol


@dataclass(frozen=True)
class FailureShape:
    """A bounded signature for a failed validation leaf."""

    step_type: str
    signature: dict[str, str | int | None]
    extracted_at: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class FailureShapeExtractor(Protocol):
    """Callable protocol for leaf-specific shape extractors."""

    def __call__(self, payload: dict[str, Any]) -> FailureShape | None: ...


ShapeComparison = Literal["changed_aligned", "changed_orthogonal", "unchanged"]

_ALIASES: dict[str, str] = {
    "dispatch": "dispatch_resolved_to",
    "route": "dispatch_resolved_to",
    "strategy": "dispatch_resolved_to",
    "status": "operation_status",
    "operation": "operation_status",
    "outcome": "overall_outcome",
    "traceback": "traceback_class",
    "exception": "traceback_class",
    "error": "traceback_class",
    "test": "failing_test_ids",
    "tests": "failing_test_ids",
}


def extract_failure_shape(*, step_type: str, payload: dict[str, Any]) -> FailureShape | None:
    """Extract a failure shape for *step_type*, returning None on unsupported payloads."""
    extractor = EXTRACTORS.get(step_type)
    if extractor is None:
        return None
    try:
        return extractor(payload)
    except (OSError, json.JSONDecodeError, TypeError, ValueError, KeyError):
        return None


def compare_failure_shapes(
    *,
    before: FailureShape,
    after: FailureShape,
    fix_focus: str,
) -> tuple[ShapeComparison, str]:
    """Compare before/after signatures and classify directionality."""
    if before.step_type != after.step_type:
        raise ValueError("FailureShape step_type mismatch")
    changed_fields = [
        key
        for key in sorted(set(before.signature) | set(after.signature))
        if before.signature.get(key) != after.signature.get(key)
    ]
    if not changed_fields:
        return ("unchanged", "failure shape fields unchanged")

    focus_tokens = _tokens(fix_focus)
    aligned_fields = [
        field for field in changed_fields if _field_tokens(field).intersection(focus_tokens)
    ]
    summary = ", ".join(
        f"{field}: {before.signature.get(field)!r} -> {after.signature.get(field)!r}"
        for field in changed_fields
    )
    if aligned_fields:
        return ("changed_aligned", summary)
    return ("changed_orthogonal", summary)


def fix_focus_is_shape_specific(*, fix_focus: str, shape: FailureShape) -> bool:
    """Return True when fix_focus names a concrete shape field or known alias."""
    focus_tokens = _tokens(fix_focus)
    if not focus_tokens:
        return False
    signature_tokens: set[str] = set()
    for field in shape.signature:
        signature_tokens.update(_field_tokens(field))
    return bool(focus_tokens.intersection(signature_tokens))


def extract_studio_assistant_validate_shape(payload: dict[str, Any]) -> FailureShape | None:
    metadata = _load_first_metadata(payload)
    signature = {
        "dispatch_resolved_to": _first_text(metadata, "dispatch_resolved_to", "strategy"),
        "operation_status": _first_text(metadata, "operation_status", "status"),
        "overall_outcome": _first_text(payload, "outcome", "status")
        or _first_text(metadata, "overall_outcome", "outcome"),
    }
    if not any(value is not None for value in signature.values()):
        return None
    return _shape("studio_assistant_validate", signature)


def extract_pytest_batch_shape(payload: dict[str, Any]) -> FailureShape | None:
    pytest_batch = dict(payload.get("pytest_batch") or payload)
    failing_tests = [str(item) for item in list(pytest_batch.get("failing_tests") or []) if item]
    traceback_class = ""
    for command in list(pytest_batch.get("commands") or []):
        if not isinstance(command, dict):
            continue
        for block in list(command.get("failure_blocks") or []):
            if isinstance(block, dict):
                traceback_class = _extract_exception_class(str(block.get("error") or ""))
                if traceback_class:
                    break
        if traceback_class:
            break
    signature = {
        "failing_test_ids": ",".join(failing_tests),
        "failing_test_count": len(failing_tests),
        "traceback_class": traceback_class or None,
        "overall_outcome": str(pytest_batch.get("outcome") or ""),
    }
    if not any(value not in ("", None, 0) for value in signature.values()):
        return None
    return _shape("pytest_batch", signature)


def extract_studio_validate_shape(payload: dict[str, Any]) -> FailureShape | None:
    validation = dict(payload.get("validation") or payload)
    failed_tests: list[str] = []
    traceback_class = ""
    for path_payload in dict(validation.get("paths") or {}).values():
        if not isinstance(path_payload, dict):
            continue
        detail = path_payload.get("detail")
        if isinstance(detail, dict):
            for item in list(detail.get("failed_tests") or []):
                if not isinstance(item, dict):
                    continue
                test_id = str(item.get("test_id") or item.get("title") or item.get("test_file") or "")
                if test_id:
                    failed_tests.append(test_id)
                traceback_class = traceback_class or _extract_exception_class(
                    str(item.get("error") or item.get("message") or "")
                )
    signature = {
        "failing_test_ids": ",".join(sorted(dict.fromkeys(failed_tests))),
        "failing_test_count": len(set(failed_tests)),
        "traceback_class": traceback_class or None,
        "overall_outcome": str(validation.get("outcome") or ""),
    }
    if not any(value not in ("", None, 0) for value in signature.values()):
        return None
    return _shape("studio_validate", signature)


EXTRACTORS: dict[str, FailureShapeExtractor] = {
    "studio_assistant_validate": extract_studio_assistant_validate_shape,
    "pytest_batch": extract_pytest_batch_shape,
    "studio_validate": extract_studio_validate_shape,
}


def _shape(step_type: str, signature: dict[str, str | int | None]) -> FailureShape:
    return FailureShape(
        step_type=step_type,
        signature=signature,
        extracted_at=datetime.now(UTC).isoformat(),
    )


def _load_first_metadata(payload: dict[str, Any]) -> dict[str, Any]:
    for path_text in _walk_values(payload):
        if not isinstance(path_text, str) or not path_text.endswith("metadata.json"):
            continue
        path = Path(path_text)
        if path.exists():
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                return loaded
    metadata = payload.get("metadata")
    return dict(metadata) if isinstance(metadata, dict) else {}


def _walk_values(value: Any) -> list[Any]:
    values: list[Any] = []
    if isinstance(value, dict):
        for child in value.values():
            values.extend(_walk_values(child))
    elif isinstance(value, list):
        for child in value:
            values.extend(_walk_values(child))
    else:
        values.append(value)
    return values


def _first_text(payload: dict[str, Any], *keys: str) -> str | None:
    for key in keys:
        value = payload.get(key)
        if value not in (None, ""):
            return str(value)
    for child in payload.values():
        if isinstance(child, dict):
            found = _first_text(child, *keys)
            if found:
                return found
        elif isinstance(child, list):
            for item in child:
                if isinstance(item, dict):
                    found = _first_text(item, *keys)
                    if found:
                        return found
    return None


def _extract_exception_class(text: str) -> str:
    for pattern in (
        r"\b([A-Za-z_][A-Za-z0-9_]*(?:Error|Exception|Failure))\b",
        r"^E\s+([A-Za-z_][A-Za-z0-9_]*):",
    ):
        match = re.search(pattern, text, re.MULTILINE)
        if match:
            return match.group(1)
    return ""


def _tokens(text: str) -> set[str]:
    raw = {token for token in re.split(r"[^a-z0-9]+", text.lower()) if token}
    expanded = set(raw)
    for token in raw:
        alias = _ALIASES.get(token)
        if alias:
            expanded.update(_field_tokens(alias))
    return expanded


def _field_tokens(field: str) -> set[str]:
    tokens = {token for token in re.split(r"[^a-z0-9]+", field.lower()) if token}
    for alias, target in _ALIASES.items():
        if target == field:
            tokens.add(alias)
    return tokens
