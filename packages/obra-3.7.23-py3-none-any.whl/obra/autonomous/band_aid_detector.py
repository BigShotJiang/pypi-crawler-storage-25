"""Detect conservative Python band-aid diff patterns before auto-commit.

The harness emits ``commit_blocked_reason='band_aid_pattern_detected'`` when
this detector finds patterns such as silent ``except`` bodies, Python
denylist/skip-list additions, or default-bypass kwargs. The detector is
intentionally conservative: false positives are tolerated because the analyzer
gets another loop. JavaScript/TypeScript analogs are intentionally out of
scope; cases such as legitimate Vitest exclude-list changes need more semantic
context than these Python-side rules carry.
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class BandAidFinding:
    """One suspicious hunk-level band-aid signal."""

    pattern: str
    file: str
    hunk_summary: str


_DIFF_HEADER_RE = re.compile(r"^diff --git a/(.*?) b/(.*?)$")
_LIST_NAME_RE = re.compile(
    r"\b[A-Za-z0-9_]*(?:denylist|skip_list|excluded|ignored|blocklist)"
    r"[A-Za-z0-9_]*\b",
    re.IGNORECASE,
)
_DEFAULT_KWARG_RE = re.compile(
    r"\b(?P<name>[A-Za-z_][A-Za-z0-9_]*)"
    r"\s*(?::\s*[^=,]+)?=\s*(?:False|None|0)\b",
    re.IGNORECASE,
)
_EXCEPT_RE = re.compile(r"^\+\s*except\b.*:\s*(?:#.*)?$")
_SILENT_BODY_RE = re.compile(
    r"^\+\s*(?:pass|return\s+(?:None|False|''|\"\")|continue)\s*(?:#.*)?$"
)
_LOG_BODY_RE = re.compile(r"^\+\s*(?:logger|logging)\.[A-Za-z_]+\(")


def detect_band_aid_patterns(diff_text: str) -> list[BandAidFinding]:
    """Return suspicious Python band-aid findings from added diff lines."""
    findings: list[BandAidFinding] = []
    for file_path, hunk_lines in _iter_file_hunks(diff_text):
        if not file_path.endswith(".py"):
            continue
        findings.extend(_detect_silent_except(file_path, hunk_lines))
        findings.extend(_detect_denylist_addition(file_path, hunk_lines))
        findings.extend(_detect_default_bypass_kwarg(file_path, hunk_lines))
    return _dedupe(findings)


def _iter_file_hunks(diff_text: str) -> list[tuple[str, list[str]]]:
    file_path = ""
    current: list[str] = []
    hunks: list[tuple[str, list[str]]] = []
    for line in diff_text.splitlines():
        header = _DIFF_HEADER_RE.match(line)
        if header:
            if file_path and current:
                hunks.append((file_path, current))
            file_path = header.group(2)
            current = []
            continue
        if line.startswith("@@"):
            if file_path and current:
                hunks.append((file_path, current))
            current = [line]
            continue
        if file_path:
            current.append(line)
    if file_path and current:
        hunks.append((file_path, current))
    return hunks


def _detect_silent_except(file_path: str, hunk_lines: list[str]) -> list[BandAidFinding]:
    findings: list[BandAidFinding] = []
    for index, line in enumerate(hunk_lines):
        if not _EXCEPT_RE.match(line):
            continue
        body = [
            candidate
            for candidate in hunk_lines[index + 1 : index + 4]
            if candidate.startswith("+") and not candidate.startswith("+++")
        ]
        if not body:
            continue
        if _SILENT_BODY_RE.match(body[0]) or (
            len(body) >= 2 and _LOG_BODY_RE.match(body[0]) and _SILENT_BODY_RE.match(body[1])
        ):
            findings.append(
                BandAidFinding(
                    pattern="silent_except",
                    file=file_path,
                    hunk_summary=_summary(line),
                )
            )
    return findings


def _detect_denylist_addition(file_path: str, hunk_lines: list[str]) -> list[BandAidFinding]:
    hunk_text = "\n".join(hunk_lines)
    if not _LIST_NAME_RE.search(hunk_text):
        return []
    for line in hunk_lines:
        if not line.startswith("+") or line.startswith("+++"):
            continue
        stripped = line[1:].strip()
        if not stripped or _LIST_NAME_RE.search(stripped):
            continue
        if stripped.endswith((",", ")", "]", "}")) or stripped.startswith(("'", '"')):
            return [
                BandAidFinding(
                    pattern="denylist_addition",
                    file=file_path,
                    hunk_summary=_summary(line),
                )
            ]
    return []


def _detect_default_bypass_kwarg(
    file_path: str,
    hunk_lines: list[str],
) -> list[BandAidFinding]:
    if any(line.startswith("+") and re.match(r"^\+\s*else\s*:", line) for line in hunk_lines):
        return []
    findings: list[BandAidFinding] = []
    for line in hunk_lines:
        if not line.startswith("+") or line.startswith("+++"):
            continue
        if "def " not in line and "," not in line:
            continue
        match = _DEFAULT_KWARG_RE.search(line)
        if match and any(
            token in match.group("name").lower()
            for token in ("skip", "bypass", "allow", "force")
        ):
            findings.append(
                BandAidFinding(
                    pattern="default_bypass_kwarg",
                    file=file_path,
                    hunk_summary=_summary(line),
                )
            )
    return findings


def _summary(line: str) -> str:
    return line.removeprefix("+").strip()[:160]


def _dedupe(findings: list[BandAidFinding]) -> list[BandAidFinding]:
    seen: set[tuple[str, str, str]] = set()
    unique: list[BandAidFinding] = []
    for finding in findings:
        key = (finding.pattern, finding.file, finding.hunk_summary)
        if key in seen:
            continue
        seen.add(key)
        unique.append(finding)
    return unique
