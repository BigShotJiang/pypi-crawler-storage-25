"""Gate fix-worker commits whose tests do not validate the production change.

The harness emits ``commit_blocked_reason='test_does_not_validate_fix'`` when
new or modified tests still pass after the production-side part of a patch is
temporarily stashed. Production-only patches pass with ``reason='no_tests_to_verify'``.
Test-only patches pass with ``reason='test_only_diff'`` because they can be
legitimate realignments to an earlier intentional production change; shape and
band-aid gates cover the residual risk.
"""

from __future__ import annotations

import re
import subprocess
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class TestIntegrityResult:
    """Outcome from the test-integrity gate."""

    passed: bool
    reason: str
    verified_tests: list[str]


_DIFF_HEADER_RE = re.compile(r"^diff --git a/(.*?) b/(.*?)$")
_PYTEST_DEF_RE = re.compile(r"^\+\s*def\s+(test_[A-Za-z0-9_]+)\s*\(")
_JS_TEST_RE = re.compile(
    r"^\+\s*(?:test|it|describe)\s*\(\s*['\"]([^'\"]+)['\"]"
)


def verify_test_exercises_production_change(
    *,
    repo_root: Path,
    fix_worker_diff_text: str,
    run_test_command: Callable[[list[str]], int],
    test_file_detector: Callable[[str], bool],
) -> TestIntegrityResult:
    """Verify changed tests fail when the production side of the patch is hidden."""
    changed = _parse_changed_files(fix_worker_diff_text)
    test_files = sorted(path for path in changed if test_file_detector(path))
    production_files = sorted(path for path in changed if not test_file_detector(path))

    if not test_files:
        return TestIntegrityResult(
            passed=True,
            reason="no_tests_to_verify",
            verified_tests=[],
        )
    if not production_files:
        return TestIntegrityResult(
            passed=True,
            reason="test_only_diff",
            verified_tests=[],
        )

    selectors = _extract_test_selectors(
        diff_text=fix_worker_diff_text,
        test_files=test_files,
    )
    before_stash = _stash_ref(repo_root)
    _git(
        repo_root,
        ["stash", "push", "--include-untracked", "-m", "obra-test-integrity", "--", *production_files],
    )
    after_stash = _stash_ref(repo_root)
    stash_created = after_stash != before_stash
    try:
        without_production_exit = int(run_test_command(selectors))
    finally:
        if stash_created:
            pop = subprocess.run(
                ["git", "stash", "pop", "--index"],
                cwd=repo_root,
                check=False,
                capture_output=True,
                text=True,
            )
            if pop.returncode != 0:
                detail = (pop.stderr or pop.stdout or "").strip()
                raise RuntimeError(
                    "test-integrity gate failed to restore stashed production files"
                    + (f": {detail}" if detail else "")
                )

    after_restore_exit = int(run_test_command(selectors))
    if after_restore_exit != 0:
        raise RuntimeError(
            "test-integrity gate sanity check failed after restoring production files"
        )
    if without_production_exit == 0:
        return TestIntegrityResult(
            passed=False,
            reason="test_does_not_validate_fix",
            verified_tests=selectors,
        )
    return TestIntegrityResult(passed=True, reason="", verified_tests=selectors)


def _parse_changed_files(diff_text: str) -> set[str]:
    files: set[str] = set()
    for line in diff_text.splitlines():
        match = _DIFF_HEADER_RE.match(line)
        if match:
            files.add(match.group(2))
            continue
        if line.startswith("+++ b/"):
            files.add(line.removeprefix("+++ b/").strip())
    return {path for path in files if path and path != "/dev/null"}


def _extract_test_selectors(*, diff_text: str, test_files: list[str]) -> list[str]:
    current_file = ""
    selectors_by_file: dict[str, list[str]] = {path: [] for path in test_files}
    test_file_set = set(test_files)
    for line in diff_text.splitlines():
        header = _DIFF_HEADER_RE.match(line)
        if header:
            current_file = header.group(2)
            continue
        if current_file not in test_file_set:
            continue
        if current_file.endswith(".py"):
            py_match = _PYTEST_DEF_RE.match(line)
            if py_match:
                selectors_by_file[current_file].append(f"{current_file}::{py_match.group(1)}")
                continue
        if current_file.endswith((".js", ".jsx", ".ts", ".tsx")):
            js_match = _JS_TEST_RE.match(line)
            if js_match:
                selectors_by_file[current_file].append(current_file)

    selectors: list[str] = []
    for path in test_files:
        file_selectors = selectors_by_file[path]
        selectors.extend(file_selectors or [path])
    return sorted(dict.fromkeys(selectors))


def _stash_ref(repo_root: Path) -> str:
    result = subprocess.run(
        ["git", "rev-parse", "--verify", "refs/stash"],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def _git(repo_root: Path, args: list[str]) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            ["git", *args],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        raise RuntimeError(
            f"test-integrity git command failed: git {' '.join(args)}"
            + (f": {detail}" if detail else "")
        ) from exc
