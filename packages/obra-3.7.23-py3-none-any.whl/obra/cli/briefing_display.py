"""Pure presentation functions for the Obra briefing command.

Extracted from obra.cli.briefing (REFACTOR-STRUCTURAL-P26-001 Story 3).
These are Rich console display functions with no business logic dependencies.
"""

from __future__ import annotations

from rich.console import Console

from obra.display.charset import glyphs


def _display_default_briefing(console: Console) -> None:
    """Display the default briefing output (process-first with conversation example)."""
    console.print()
    console.print("[bold]FOR HUMANS: Copy this prompt to your AI assistant:[/bold]")
    console.print()
    console.print(
        "[cyan]┌─────────────────────────────────────────────────────────────────┐[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]  I want to use Obra. Start with `obra briefing quick`, then  [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]  use `obra models`, `obra help domains`, and `obra help run` [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]  before invoking `obra run` for my objective.                 [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]└─────────────────────────────────────────────────────────────────┘[/cyan]"
    )
    console.print()
    console.print(
        "[cyan]══════════════════════════════════════════════════════════════════════[/cyan]"
    )
    console.print("[bold cyan]           OBRA OPERATING GUIDE FOR AI ASSISTANTS[/bold cyan]")
    console.print(
        "[cyan]══════════════════════════════════════════════════════════════════════[/cyan]"
    )
    console.print()
    console.print("[bold red]IMPORTANT: DO NOT KILL LONG-RUNNING OBRA COMMANDS[/bold red]")
    console.print("[red]Obra runs can take 15-40 minutes. If your tool enforces timeouts,[/red]")
    console.print("[red]do NOT let it terminate the process. Start `obra run` in a separate[/red]")
    console.print("[red]terminal or background (tmux/screen/nohup) and monitor with[/red]")
    console.print("[red]`obra status` while the run keeps going.[/red]")
    console.print()
    console.print("[bold]LLM Operator Fast Path (deterministic)[/bold]")
    console.print(
        "  1) Discovery: [cyan]obra models[/cyan] for provider/model names, "
        "[cyan]obra help domains[/cyan] for installed domains, "
        "[cyan]obra help run[/cyan] for execution flags."
    )
    console.print(
        "     Session overrides: [cyan]obra run --model X --fast-model X --high-model X --impl-provider PROVIDER[/cyan]."
    )
    console.print(
        "     Or env vars: [cyan]OBRA_MODEL/OBRA_FAST_MODEL/OBRA_HIGH_MODEL/OBRA_PROVIDER[/cyan]."
    )
    console.print("     Do NOT use [cyan]obra config set llm.*.model[/cyan] (unsupported).")
    console.print(
        "  2) Working dir: run inside the target repo, or pass [cyan]--dir /path[/cyan]. "
        "Use [cyan]--project[/cyan] only when you intentionally need a stored project binding."
    )
    console.print(
        "  3) Domains: [cyan]obra run[/cyan] needs an explicit resolved domain from "
        "[cyan]--domain[/cyan], project config, or layered config. "
        "If none resolve, the run fails before session creation."
    )
    console.print(
        "     Use [cyan]obra run --domain business[/cyan] for business workflows. "
        "Use [cyan]--domain software[/cyan] or set [cyan]orchestration.domain[/cyan] explicitly when needed."
    )
    console.print(
        "  4) Monitoring: capture the printed [bold]session id[/bold], then use "
        "[cyan]obra status <id>[/cyan]. Prefer [cyan]obra run --continue-from <id>[/cyan] "
        "for failed or escalated work when resumability is unclear."
    )
    console.print(
        "     Config warnings: ignore auth metadata keys in "
        "[cyan]~/.obra/config-layers/01-user.yaml[/cyan]; others are real issues."
    )
    console.print(
        "  5) Logs & paths: See [cyan]~/.obra/README.md[/cyan] for log file locations and "
        "monitoring commands."
    )
    console.print("     Real-time logs: [cyan]tail -f ~/.obra-runtime/logs/hybrid.jsonl[/cyan]")
    console.print(
        "  6) Briefings: [cyan]obra briefing quick[/cyan] is the recommended short guide. "
        "[cyan]obra briefing[/cyan] is the full default orientation. "
        "[cyan]obra briefing examples[/cyan] is the best follow-up when user input is still vague."
    )
    console.print()
    console.print("Obra executes development tasks autonomously. Your job: gather requirements")
    console.print("through conversation, then invoke Obra with structured input.")
    console.print()
    console.print(
        "Run `obra` to see all commands. High-signal commands for LLMs: run, status, models, help, briefing"
    )
    console.print()

    # Check for active intent and display if found (FEAT-AUTO-INTENT-001 S8.T2)
    try:
        from pathlib import Path as PathLib

        from obra.intent import IntentStorage

        working_dir = PathLib.cwd()
        storage = IntentStorage()
        project_id = storage.get_workspace_id(working_dir)
        active_intent = storage.load_active(project_id)

        if active_intent:
            console.print(
                "[cyan]╔═════════════════════════════════════════════════════════════════╗[/cyan]"
            )
            console.print(
                "[cyan]║[/cyan] [bold yellow]ACTIVE INTENT DETECTED[/bold yellow]                                           [cyan]║[/cyan]"
            )
            console.print(
                "[cyan]╚═════════════════════════════════════════════════════════════════╝[/cyan]"
            )
            console.print("[dim](Session state from previous work - ignore for new projects)[/dim]")
            console.print()
            console.print(f"[bold]Intent:[/bold] {active_intent.slug}")
            console.print(f"[bold]Problem:[/bold] {active_intent.problem_statement}")
            console.print()

            # Show key requirements (first 3 if more than 3)
            if active_intent.requirements:
                console.print("[bold]Key Requirements:[/bold]")
                max_to_show = 3
                for i, req in enumerate(active_intent.requirements[:max_to_show], 1):
                    console.print(f"  {i}. {req}")
                if len(active_intent.requirements) > max_to_show:
                    remaining = len(active_intent.requirements) - max_to_show
                    console.print(f"  [dim]... and {remaining} more[/dim]")
                console.print()

            console.print("[bold]Suggested Commands:[/bold]")
            console.print(
                "  [cyan]obra derive[/cyan]                  Continue derivation with this intent"
            )
            console.print(
                "  [cyan]obra context add 'info'[/cyan]     Amend intent with additional context"
            )
            console.print("  [cyan]obra intent show[/cyan]            Show full intent details")
            console.print(
                "  [cyan]obra verify[/cyan]                 Verify completion against acceptance criteria"
            )
            console.print()
            console.print(
                "[cyan]─────────────────────────────────────────────────────────────────[/cyan]"
            )
            console.print()
    except Exception:
        # Silently ignore errors (don't break briefing if intent loading fails)
        pass

    console.print("[bold]YOUR PROCESS[/bold]")
    console.print("[cyan]────────────[/cyan]")
    console.print("1. Ask what they're building (get specific, not vague)")
    console.print("2. Check project files for tech stack (don't ask what you can infer)")
    console.print("3. Clarify features, constraints, anti-patterns through conversation")
    console.print("4. Summarize into one structured Obra input")
    console.print()
    console.print("[bold]EXAMPLE CONVERSATION[/bold]")
    console.print("[cyan]────────────────────[/cyan]")
    console.print('  User: "Build me an API"')
    console.print('  You:  "What kind? REST, GraphQL? What\'s it for?"')
    console.print('  User: "REST for user management"')
    console.print('  You:  "I see FastAPI in your project. Auth approach?"')
    console.print('  User: "JWT with refresh tokens"')
    console.print('  You:  "Deployment target? Any existing services to integrate?"')
    console.print()
    console.print("  [bold]→ INVOKE:[/bold]")
    console.print('    obra run "User management REST API: FastAPI + PostgreSQL.')
    console.print("    JWT auth with refresh tokens, CRUD operations, role-based access.")
    console.print('    Docker Compose deployment. Integrate with auth-service:8000." --stream')
    console.print()
    console.print("[bold]CHECKLIST (what to cover)[/bold]")
    console.print("[cyan]─────────────────────────[/cyan]")
    console.print("Required: Objective, Tech Stack, Features")
    console.print("Optional: Constraints, Integrations, Anti-patterns")
    console.print()
    console.print("Trivial tasks (typos, single-line fixes) → invoke Obra directly")
    console.print()
    console.print("[bold]ADVANCED FLAGS (optional)[/bold]")
    console.print("[cyan]──────────────────────────[/cyan]")
    console.print("Override model/provider for specific tasks:")
    console.print()
    console.print("  --model opus                    Use specific model")
    console.print("  --impl-provider google          Use specific provider")
    console.print("  --reasoning-level high           Set reasoning depth")
    console.print()
    console.print("[dim]Run `obra run --help` for complete flag reference[/dim]")
    console.print()
    console.print("[bold]PARALLEL EXECUTION[/bold]")
    console.print("[cyan]──────────────────[/cyan]")
    console.print("Run multiple Obra sessions simultaneously for faster development:")
    console.print()
    console.print("  1. Discover models: [cyan]obra models[/cyan]")
    console.print()
    console.print("  2. Run in separate terminals:")
    console.print('     [dim]Terminal 1:[/dim] obra run "feature A" --model opus')
    console.print('     [dim]Terminal 2:[/dim] obra run "feature B" -p google -m gemini-2.5-flash')
    console.print()
    console.print("  3. Or use environment variables:")
    console.print('     OBRA_MODEL=opus obra run "feature A" &')
    console.print('     OBRA_PROVIDER=google obra run "feature B" &')
    console.print()
    console.print("[dim]Env vars: OBRA_MODEL, OBRA_PROVIDER, OBRA_REASONING_LEVEL[/dim]")
    console.print("[dim]Precedence: CLI flags > env vars > config file[/dim]")
    console.print()
    console.print("[bold]WHILE OBRA RUNS[/bold]")
    console.print("[cyan]───────────────[/cyan]")
    console.print("Monitor progress, validate success, escalate if stuck.")
    console.print("See `obra briefing protocol` for full 11 autonomous behaviors.")
    console.print()
    console.print(
        "[cyan]──────────────────────────────────────────────────────────────────────[/cyan]"
    )
    console.print(
        "[bold]obra briefing quick[/bold]       Essential checklist (~2 min) [green]RECOMMENDED[/green]"
    )
    console.print("obra briefing examples    Good vs bad input examples (10 project types)")
    console.print("obra briefing blueprint   Quick checklist (condensed)")
    console.print("obra briefing questions   Question patterns (detailed)")
    console.print("obra briefing protocol    11 autonomous behaviors")
    console.print("obra briefing full        Complete guide (includes advanced flags reference)")
    console.print(
        "[cyan]══════════════════════════════════════════════════════════════════════[/cyan]"
    )
    console.print()


def _display_blueprint(console: Console) -> None:
    """Display the condensed blueprint checklist format."""
    console.print()
    console.print("[bold]OBRA INPUT BLUEPRINT (Quick Reference)[/bold]")
    console.print("[cyan]══════════════════════════════════════[/cyan]")
    console.print()
    console.print("First: Run `obra` to see all commands.")
    console.print()
    console.print("[bold]REQUIRED:[/bold]")
    console.print("  □ Objective      What are we building/fixing?")
    console.print("  □ Tech Stack     Languages, frameworks, databases")
    console.print("  □ Features       List of capabilities needed")
    console.print()
    console.print("[bold]RECOMMENDED:[/bold]")
    console.print("  □ Constraints    Performance, security, compliance")
    console.print("  □ Integrations   External services, APIs, existing systems")
    console.print("  □ Anti-patterns  What to avoid")
    console.print()
    console.print("Trivial tasks (typos, single-line fixes) → invoke directly")
    console.print("Design decisions required → gather requirements first")
    console.print()
    console.print("[bold]Example:[/bold]")
    console.print('  obra run "E-commerce: React + Node + MongoDB. Features: catalog, cart,')
    console.print('  Stripe. Constraints: <500ms, OWASP. Anti-patterns: no Redux." --stream')
    console.print()


def _display_examples(console: Console) -> None:
    """Display good vs bad input examples for common project types."""
    console.print()
    console.print("[bold]OBRA INPUT EXAMPLES: Good vs Bad[/bold]")
    console.print("[cyan]══════════════════════════════════[/cyan]")
    console.print()
    console.print("Compare [red]BAD[/red] (vague) vs [green]GOOD[/green] (specific) inputs.")
    console.print("Notice: domain, stack, features, success criteria, and constraints.")
    console.print()

    # Example 1: Software API
    console.print("[bold]1. Software API[/bold]")
    console.print("[cyan]──────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Build me an API"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "User management REST API with FastAPI + PostgreSQL.')
    console.print("         JWT authentication with refresh tokens, CRUD operations")
    console.print("         (create, read, update, delete users), role-based access")
    console.print('         control (admin/user). Docker Compose deployment. Tests >80%."')
    console.print()

    # Example 2: Business Workflow
    console.print("[bold]2. Business Workflow[/bold]")
    console.print("[cyan]────────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Make an invoice workflow"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Business workflow for invoice review:')
    console.print("         validate invoice packet, branch exceptions to approval,")
    console.print("         require finance review before completion, and produce")
    console.print("         a final handoff summary. Success: approval branch is")
    console.print('         explicit, exception path is clear, and review steps are visible."')
    console.print()

    # Example 3: Workflow Studio Authoring
    console.print("[bold]3. Workflow Studio Authoring[/bold]")
    console.print("[cyan]──────────────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Improve the workflow editor"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Improve Workflow Studio business canvas:')
    console.print("         diagram-first editing route, add insert/connect affordances,")
    console.print("         keep advanced editor secondary, and preserve one canonical")
    console.print("         workflow draft. Success: non-technical user can add a review")
    console.print('         step, reconnect flow, validate, and save without raw JSON."')
    console.print()

    # Example 4: Web Application
    console.print("[bold]4. Web Application[/bold]")
    console.print("[cyan]─────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Build a website"')
    console.print()
    console.print(
        '[green]✅ GOOD:[/green] "E-commerce storefront: Next.js 14 + TypeScript frontend,'
    )
    console.print("         Stripe checkout integration, product catalog with search")
    console.print("         and filter by category/price, shopping cart with session")
    console.print("         persistence, responsive design. Vercel deployment.")
    console.print('         Lighthouse score >90."')
    console.print()

    # Example 5: Authentication Feature
    console.print("[bold]5. Authentication Feature[/bold]")
    console.print("[cyan]────────────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Add authentication"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Add JWT authentication to existing Express API:')
    console.print("         Access tokens (15min expiry), refresh tokens (7 day),")
    console.print("         bcrypt password hashing, /register, /login, /refresh,")
    console.print("         /logout endpoints. Auth middleware for protected routes.")
    console.print('         Rate limiting on auth endpoints. Integration tests."')
    console.print()

    # Example 6: Bug Fix
    console.print("[bold]6. Bug Fix[/bold]")
    console.print("[cyan]──────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Fix the bug"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Fix race condition in src/workers/queue.py:')
    console.print("         Multiple workers calling process_job() simultaneously")
    console.print("         cause duplicate processing. Symptom: same job ID appears")
    console.print("         2-3x in logs. Expected: each job processed exactly once.")
    console.print('         Add Redis SETNX lock or PostgreSQL advisory lock."')
    console.print()

    # Example 7: Database Integration
    console.print("[bold]7. Database Integration[/bold]")
    console.print("[cyan]──────────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Add a database"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Add PostgreSQL to existing FastAPI app:')
    console.print("         SQLAlchemy ORM with async support (asyncpg driver),")
    console.print("         Alembic migrations, connection pooling (5-20 connections),")
    console.print("         models for User, Product, Order with relationships.")
    console.print('         Docker Compose with postgres:15. Seed script for dev data."')
    console.print()

    # Example 8: Simulation / Emulator Validation
    console.print("[bold]8. Simulation Validation[/bold]")
    console.print("[cyan]────────────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Test yesterday\'s refactor"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Validate the coordinator runtime refactor with')
    console.print("         local emulator-backed simulation. Use obra simulate prepare,")
    console.print("         run the canonical software regression suite, diagnose from")
    console.print("         canonical logs, patch root cause in this repo, rerun the")
    console.print(
        '         same suite, and stop only when the suite passes or a real blocker is confirmed."'
    )
    console.print()

    # Example 9: Refactoring
    console.print("[bold]9. Refactoring[/bold]")
    console.print("[cyan]─────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Refactor the code"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Refactor src/api/handlers.py (800 lines) into modules:')
    console.print("         Split by domain: users.py, products.py, orders.py, auth.py.")
    console.print("         Extract shared validation to validators.py, shared DB")
    console.print("         queries to repositories.py. Keep all existing tests passing.")
    console.print('         No new dependencies. Preserve API contract."')
    console.print()

    # Example 10: Documentation / CLI Guidance
    console.print("[bold]10. Documentation and Help[/bold]")
    console.print("[cyan]──────────────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Update the docs"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Update obra help, obra briefing, and CLI reference')
    console.print("         so LLM users discover the right path: briefing quick, models,")
    console.print("         help domains, help run, explicit domain resolution, and")
    console.print('         packaged onboarding docs. Keep help text concise and test-covered."')
    console.print()

    # Example 11: Business Workflow Lifecycle (worked example)
    console.print("[bold]11. Business Workflow — Full Lifecycle[/bold]")
    console.print("[cyan]──────────────────────────────────────[/cyan]")
    console.print()
    console.print("This shows what Obra actually produces for a business workflow run.")
    console.print()
    console.print("[bold]Invocation:[/bold]")
    console.print()
    console.print('[cyan]  obra run --domain business "Invoice review workflow:[/cyan]')
    console.print("[cyan]    validate invoice packet fields, flag exceptions over $10k for[/cyan]")
    console.print("[cyan]    manager approval, generate finance summary with totals and flags.[/cyan]")
    console.print('[cyan]    Success: exceptions routed, summary includes line-item totals."[/cyan]')
    console.print()
    console.print("[bold]Step 1 — Extraction → definition.yaml:[/bold]")
    console.print()
    console.print("  Obra's LLM reads your objective and extracts a structured workflow:")
    console.print()
    console.print("  [dim]workflow_id: WORKFLOW-INVOICE-001[/dim]")
    console.print("  [dim]title: Invoice Review and Approval[/dim]")
    console.print("  [dim]stages:[/dim]")
    console.print("  [dim]  - id: S0, type: input_validation   # Validate invoice fields[/dim]")
    console.print("  [dim]  - id: S1, type: decision            # Flag >$10k exceptions[/dim]")
    console.print("  [dim]  - id: S2, type: quality_gate         # Verify routing logic[/dim]")
    console.print("  [dim]  - id: S3, type: generation           # Produce finance summary[/dim]")
    console.print("  [dim]  - id: S4, type: output               # Format final deliverables[/dim]")
    console.print()
    console.print("[bold]Step 2 — Compilation → WORKFLOW_PLAN.json:[/bold]")
    console.print()
    console.print("  Each stage becomes a story with tasks and verification criteria.")
    console.print("  Stage S0 → Story S1, Stage S1 → Story S2, etc. (1-indexed for plan compat)")
    console.print()
    console.print("[bold]Step 3 — Execution:[/bold]")
    console.print()
    console.print("  [dim]▸ S0 input_validation  [fast model]   ✓ Validated 12 fields[/dim]")
    console.print("  [dim]▸ S1 decision          [high model]   ✓ Flagged 3 exceptions >$10k[/dim]")
    console.print("  [dim]▸ S2 quality_gate       [medium model] ✓ Routing logic verified[/dim]")
    console.print("  [dim]▸ S3 generation         [high model]   ✓ Summary generated[/dim]")
    console.print("  [dim]▸ S4 output             [medium model] ✓ Deliverables formatted[/dim]")
    console.print()
    console.print("[bold]Output artifacts:[/bold]")
    console.print()
    console.print("  [dim].obra-biz/workflows/WORKFLOW-INVOICE-001/[/dim]")
    console.print("  [dim]  definition.yaml          # Workflow blueprint[/dim]")
    console.print("  [dim]  WORKFLOW_PLAN.json        # Compiled execution plan[/dim]")
    console.print("  [dim]  stages/S0_validate.md     # Per-stage instructions[/dim]")
    console.print("  [dim]  stages/S1_decision.md[/dim]")
    console.print("  [dim]  stages/S3_summary.md[/dim]")
    console.print("  [dim]  runs/<run-id>/            # Execution outputs[/dim]")
    console.print()
    console.print("[dim]Run [cyan]obra help business[/cyan] for stage types, quality gates, and config.[/dim]")
    console.print()

    console.print(
        "[cyan]══════════════════════════════════════════════════════════════════════[/cyan]"
    )
    console.print()
    console.print("[bold]Key Pattern:[/bold] Good input includes:")
    console.print("  • [cyan]Domain[/cyan] when the work is workflow-governed or business-facing")
    console.print("  • [cyan]Tech stack[/cyan] (language, framework, database)")
    console.print("  • [cyan]Specific features[/cyan] (not 'auth' but 'JWT with refresh tokens')")
    console.print("  • [cyan]Success criteria[/cyan] (testable: '>80% coverage', '<200ms')")
    console.print("  • [cyan]Constraints[/cyan] (deployment target, existing code to preserve)")
    console.print()
    console.print(
        f"[dim]{glyphs.hint} Run [/dim][cyan]obra briefing quick[/cyan][dim] for the full checklist[/dim]"
    )
    console.print()
