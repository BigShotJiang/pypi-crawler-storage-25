"""Dedicated CLI surface for business workflow execution."""

from __future__ import annotations

import os
import sys
import json
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import typer
import yaml  # type: ignore[import-untyped]

from obra.cli._shared import _resolve_command_verbosity, require_terms_accepted
from obra.cli.run import _apply_config_override_layer, _apply_interaction_mode
from obra.cli.run_support.command_surface import (
    _normalize_working_dir_arg,
    prepare_run_invocation,
)
from obra.cli.run_support.interaction_mode import InteractionMode, resolve_interaction_mode
from obra.cli.run_support.shared_options import (
    OptConfigOverride,
    OptDefaultsJson,
    OptFastModel,
    OptHighModel,
    OptHardBlockOn,
    OptImplProvider,
    OptInteractive,
    OptLocal,
    OptModel,
    OptMosaic,
    OptNoExtendedThinking,
    OptNonInteractive,
    OptOrchModel,
    OptOrchProvider,
    OptOrchReasoning,
    OptPlanOnly,
    OptReasoningLevel,
    OptStream,
    OptVerbose,
    OptWorkingDir,
)
from obra.display import (
    console,
    glyphs,
    handle_encoding_errors,
    print_banner,
    print_error,
    print_info,
)
from obra.session.working_dir import normalize_wsl_unc_path

_CANONICAL_SOURCE_DIRNAME = ".obra-biz"
_CANONICAL_SOURCE_FILENAME = "canonical-workflow-source.json"
_WORKFLOW_PLAN_FILENAME = "WORKFLOW_PLAN.json"

business_app = typer.Typer(
    help="Run business workflows through the Obra runtime.",
    no_args_is_help=True,
)
workflow_app = typer.Typer(help="Compile and validate business workflow artifacts.")
business_app.add_typer(workflow_app, name="workflow")


@dataclass(frozen=True)
class WorkflowLaunchTarget:
    """Resolved workflow inputs for business CLI execution."""

    workflow_dir: Path
    plan_path: Path
    metadata_path: Path
    source_kind: str


@dataclass(frozen=True)
class BusinessRunResolution:
    """Resolved business run mode after CLI argument parsing."""

    mode: str
    target: WorkflowLaunchTarget | None = None
    objective: str | None = None
    discovery_root: Path | None = None
    candidates: tuple[WorkflowLaunchTarget, ...] = ()


def _require_business_support() -> tuple[Any, Any]:
    """Return business config helpers or exit with actionable guidance."""
    try:
        from obra_business.config.loader import get_config_value, load_config
    except ImportError as exc:
        print_error(
            "Business workflow support requires the in-repo obra-business package. "
            "Install it with: pip install -e obra-business/"
        )
        raise typer.Exit(1) from exc
    return load_config, get_config_value


@contextmanager
def _pushd(path: Path) -> Iterator[None]:
    """Temporarily switch working directory for config-owned path resolution."""
    previous = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(previous)


def _resolve_base_dir(working_dir: str | None) -> Path:
    """Resolve the base directory used for config and relative workflow paths."""
    return _normalize_working_dir_arg(working_dir) or Path.cwd().resolve()


def _resolve_cli_path(raw_value: str, *, base_dir: Path) -> Path:
    """Resolve a CLI-supplied path relative to the command base directory."""
    normalized = Path(normalize_wsl_unc_path(raw_value)).expanduser()
    if not normalized.is_absolute():
        normalized = base_dir / normalized
    return normalized.resolve(strict=False)


def _resolve_input_document_path(
    *,
    input_path: str | None,
    base_dir: Path,
    execute_pipeline: bool,
) -> Path | None:
    """Resolve and validate the ``--input`` document path supplied by the user.

    Returns ``None`` when ``--input`` is omitted so the canonical runtime
    falls back to the workflow's ``input_template.md`` convention. When a
    path is supplied but unusable, the CLI fails fast with a readable error
    instead of deferring to a silent stage-level failure deep in the server
    dispatch.
    """
    if input_path is None:
        return None
    if not execute_pipeline:
        print_error(
            "--input requires a compiled workflow. Pass a WORKFLOW_PLAN.json "
            "or canonical-workflow-source.json as the first positional."
        )
        raise typer.Exit(2)
    resolved = _resolve_cli_path(input_path, base_dir=base_dir)
    if not resolved.exists():
        print_error(f"Input document not found: {resolved}")
        raise typer.Exit(2)
    if not resolved.is_file():
        print_error(f"Input document is not a file: {resolved}")
        raise typer.Exit(2)
    if not os.access(resolved, os.R_OK):
        print_error(f"Input document is not readable: {resolved}")
        raise typer.Exit(2)
    return resolved


def _load_business_config_for_dir(base_dir: Path) -> dict[str, Any]:
    """Load business config relative to the resolved working directory."""
    load_config, _ = _require_business_support()
    with _pushd(base_dir):
        config = load_config()
    if not isinstance(config, dict):
        print_error("Business configuration must resolve to a mapping.")
        raise typer.Exit(1)
    return config


def _resolve_workflows_root(base_dir: Path) -> Path:
    """Resolve the configured business workflow storage root for discovery."""
    _, get_config_value = _require_business_support()
    config = _load_business_config_for_dir(base_dir)
    try:
        workflows_dir = get_config_value(config, "business.storage.workflows_dir")
    except KeyError as exc:
        print_error("Missing required business.storage.workflows_dir configuration.")
        raise typer.Exit(1) from exc
    if not isinstance(workflows_dir, str) or not workflows_dir.strip():
        print_error("business.storage.workflows_dir must be a non-empty string.")
        raise typer.Exit(1)
    root = Path(workflows_dir).expanduser()
    if not root.is_absolute():
        root = base_dir / root
    return root.resolve(strict=False)


def _build_launch_target(
    *,
    workflow_dir: Path,
    plan_path: Path,
    metadata_path: Path,
    source_kind: str,
) -> WorkflowLaunchTarget:
    """Build one normalized workflow execution target."""
    return WorkflowLaunchTarget(
        workflow_dir=workflow_dir.resolve(strict=False),
        plan_path=plan_path.resolve(strict=True),
        metadata_path=metadata_path.resolve(strict=True),
        source_kind=source_kind,
    )


def _metadata_path_for_workflow_dir(workflow_dir: Path, plan_path: Path) -> Path:
    """Prefer canonical workflow metadata when present, otherwise use the plan."""
    canonical_path = workflow_dir / _CANONICAL_SOURCE_DIRNAME / _CANONICAL_SOURCE_FILENAME
    if canonical_path.is_file():
        return canonical_path
    return plan_path


def _resolve_workflow_target(
    raw_value: str,
    *,
    base_dir: Path,
) -> WorkflowLaunchTarget | None:
    """Resolve a CLI positional into a supported workflow artifact target."""
    candidate_path = _resolve_cli_path(raw_value, base_dir=base_dir)
    if not candidate_path.is_file():
        return None

    if candidate_path.name == _WORKFLOW_PLAN_FILENAME:
        workflow_dir = candidate_path.parent
        return _build_launch_target(
            workflow_dir=workflow_dir,
            plan_path=candidate_path,
            metadata_path=_metadata_path_for_workflow_dir(workflow_dir, candidate_path),
            source_kind="workflow_plan",
        )

    if (
        candidate_path.name == _CANONICAL_SOURCE_FILENAME
        and candidate_path.parent.name == _CANONICAL_SOURCE_DIRNAME
    ):
        workflow_dir = candidate_path.parent.parent
        plan_path = workflow_dir / _WORKFLOW_PLAN_FILENAME
        if not plan_path.is_file():
            print_error(
                f"Workflow source exists but {plan_path} is missing. "
                "Restore or regenerate WORKFLOW_PLAN.json before execution."
            )
            raise typer.Exit(2)
        return _build_launch_target(
            workflow_dir=workflow_dir,
            plan_path=plan_path,
            metadata_path=candidate_path,
            source_kind="canonical_workflow_source",
        )

    return None


def _discover_compiled_workflows(base_dir: Path) -> tuple[Path, list[WorkflowLaunchTarget]]:
    """Discover compiled workflows under the config-owned business storage root."""
    workflows_root = _resolve_workflows_root(base_dir)
    if not workflows_root.exists():
        return workflows_root, []

    candidates: list[WorkflowLaunchTarget] = []
    workflow_dirs = [path for path in sorted(workflows_root.iterdir()) if path.is_dir()]

    for workflow_dir in workflow_dirs:
        plan_path = workflow_dir / _WORKFLOW_PLAN_FILENAME
        canonical_path = workflow_dir / _CANONICAL_SOURCE_DIRNAME / _CANONICAL_SOURCE_FILENAME
        if canonical_path.is_file() and plan_path.is_file():
            candidates.append(
                _build_launch_target(
                    workflow_dir=workflow_dir,
                    plan_path=plan_path,
                    metadata_path=canonical_path,
                    source_kind="canonical_workflow_source",
                )
            )
            continue
        if plan_path.is_file():
            candidates.append(
                _build_launch_target(
                    workflow_dir=workflow_dir,
                    plan_path=plan_path,
                    metadata_path=plan_path,
                    source_kind="workflow_plan",
                )
            )

    return workflows_root, candidates


def _read_workflow_artifact(path: Path) -> dict[str, Any]:
    """Load one workflow artifact as a mapping."""
    try:
        loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        print_error(f"Workflow artifact not found: {path}")
        raise typer.Exit(2) from exc
    except yaml.YAMLError as exc:
        print_error(f"Workflow artifact is not valid YAML/JSON: {path} ({exc})")
        raise typer.Exit(2) from exc

    if isinstance(loaded, dict):
        return loaded
    return {}


def _get_nested_value(payload: dict[str, Any], *keys: str) -> str | None:
    """Return a stripped nested string value when present."""
    current: Any = payload
    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    if current is None:
        return None
    normalized = str(current).strip()
    return normalized or None


def _first_non_empty(*values: str | None) -> str | None:
    """Return the first non-empty string candidate."""
    for value in values:
        if value is not None:
            stripped = value.strip()
            if stripped:
                return stripped
    return None


def _extract_workflow_title(payload: dict[str, Any]) -> str | None:
    """Extract a user-facing workflow title from known business payload shapes."""
    return _first_non_empty(
        _get_nested_value(payload, "workflow_source_summary", "title"),
        _get_nested_value(payload, "workflow_definition", "title"),
        _get_nested_value(payload, "workflow_source_artifact", "metadata", "title"),
        _get_nested_value(payload, "workflow_source_artifact", "title"),
        _get_nested_value(payload, "title"),
        _get_nested_value(payload, "name"),
    )


def _workflow_identifier(payload: dict[str, Any]) -> str | None:
    """Extract a stable workflow identifier when present."""
    return _first_non_empty(
        _get_nested_value(payload, "workflow_definition", "workflow_id"),
        _get_nested_value(payload, "workflow_id"),
        _get_nested_value(payload, "work_id"),
    )


def _describe_workflow_target(target: WorkflowLaunchTarget) -> str:
    """Build a human-readable discovery label for a workflow target."""
    payload = _read_workflow_artifact(target.metadata_path)
    title = _extract_workflow_title(payload)
    identifier = _workflow_identifier(payload)
    label = title or identifier or target.workflow_dir.name
    return f"{label} ({target.plan_path})"


def _find_workflow_targets_by_identifier(
    workflow_id: str,
    *,
    base_dir: Path,
) -> tuple[Path, list[WorkflowLaunchTarget]]:
    workflows_root, candidates = _discover_compiled_workflows(base_dir)
    normalized_workflow_id = workflow_id.strip()
    matches = [
        candidate
        for candidate in candidates
        if _workflow_identifier(_read_workflow_artifact(candidate.metadata_path)) == normalized_workflow_id
    ]
    return workflows_root, matches


def _publish_workflow_revision_for_plan(plan_file: Path) -> None:
    """Register the compiled workflow as a server-side revision before launch.

    ADR-101 Invariant 3 routes nested business runs through the
    pipeline_only per-story dispatch, which resolves the compiled
    workflow through ``state_manager.get_workflow_head/_revision``. The
    record only exists if a prior Workflow Studio apply or this CLI's
    own publish step wrote it. Without this call the on_start shim's
    nested ``obra run`` fails with
    ``workflow record <id>@<rev> not found``.

    The publish helper is idempotent: when the head's
    ``workflow_content_hash`` matches the compiled plan, no new revision
    is written.
    """
    try:
        from obra_business.runtime.workflow_publication import (
            WorkflowPublicationError,
            publish_workflow_revision,
        )
    except ImportError as exc:
        print_error(
            "Business workflow execution requires the in-repo obra-business package. "
            "Install it with: pip install -e obra-business/"
        )
        raise typer.Exit(1) from exc

    try:
        plan_data = json.loads(plan_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print_error(f"Failed to read compiled workflow plan {plan_file}: {exc}")
        raise typer.Exit(1) from exc

    from obra.api import APIClient

    try:
        client = APIClient.from_config()
    except Exception as exc:
        print_error(
            f"Could not initialize API client to publish workflow revision: {exc}"
        )
        raise typer.Exit(1) from exc

    try:
        result = publish_workflow_revision(client=client, plan=plan_data)
    except WorkflowPublicationError as exc:
        print_error(f"Failed to publish workflow revision: {exc}")
        raise typer.Exit(1) from exc

    action = "registered" if result.created else "reused"
    _persist_published_workflow_revision(plan_file, result.revision_id)
    console.print(
        f"[dim]Workflow {action}: {result.workflow_id}@{result.revision_id}[/dim]"
    )


def _persist_published_workflow_revision(plan_file: Path, revision_id: str) -> None:
    """Update imported-plan workflow refs to the revision actually published."""
    from obra_business.runtime.workflow_publication import (
        persist_published_workflow_revision,
    )

    persist_published_workflow_revision(plan_file, revision_id)


def _synthesize_objective_from_workflow_artifact(plan_path: Path) -> str:
    """Synthesize a non-empty objective from current business workflow artifacts."""
    payload = _read_workflow_artifact(plan_path)
    title = _extract_workflow_title(payload)
    if title is not None:
        return f"Execute business workflow: {title}"

    mission = _first_non_empty(
        _get_nested_value(payload, "objective"),
        _get_nested_value(payload, "mission"),
    )
    if mission is not None:
        return mission

    workflow_identifier = _workflow_identifier(payload)
    if workflow_identifier is not None:
        return f"Execute workflow: {workflow_identifier}"

    return f"Execute business workflow: {plan_path.stem}"


def _resolve_business_run_mode(
    workflow_or_objective: str | None,
    objective: str | None,
    *,
    base_dir: Path,
) -> BusinessRunResolution:
    """Resolve business run launch mode from the CLI positionals."""
    if workflow_or_objective is None and objective is not None:
        print_error("Explicit objective override requires a workflow file first.")
        raise typer.Exit(2)

    if workflow_or_objective is None:
        discovery_root, candidates = _discover_compiled_workflows(base_dir)
        if len(candidates) == 1:
            return BusinessRunResolution(mode="workflow", target=candidates[0])
        return BusinessRunResolution(
            mode="discovery",
            discovery_root=discovery_root,
            candidates=tuple(candidates),
        )

    if objective is None:
        target = _resolve_workflow_target(workflow_or_objective, base_dir=base_dir)
        if target is not None:
            return BusinessRunResolution(mode="workflow", target=target)
        return BusinessRunResolution(mode="objective", objective=workflow_or_objective)

    target = _resolve_workflow_target(workflow_or_objective, base_dir=base_dir)
    if target is None:
        print_error(
            "The first positional must be a supported workflow file when you also pass "
            "an explicit objective. Objective-only mode uses one positional, and "
            "workflow execution uses <workflow-file> [objective]."
        )
        raise typer.Exit(2)

    return BusinessRunResolution(mode="workflow", target=target, objective=objective)


def _render_discovery_outcome(
    *,
    workflows_root: Path,
    candidates: tuple[WorkflowLaunchTarget, ...],
) -> None:
    """Render no-arg discovery guidance when execution cannot continue automatically."""
    console.print()
    if not candidates:
        print_error(f"No compiled business workflows found under {workflows_root}.")
        console.print(
            "Compile a workflow into the configured business workflow storage root "
            "or pass an explicit WORKFLOW_PLAN.json path."
        )
        raise typer.Exit(1)

    print_info("Multiple compiled business workflows are available.")
    for candidate in candidates:
        console.print(f"  - {_describe_workflow_target(candidate)}")
    console.print()
    console.print("Run `obra business run <workflow-file>` to choose one explicitly.")
    raise typer.Exit(0)


@workflow_app.command("compile")
@handle_encoding_errors
@require_terms_accepted
def compile_workflow(
    workflow_dir: str = typer.Argument(..., help="Directory containing definition.yaml"),
    validate: bool = typer.Option(
        False,
        "--validate",
        help="Validate the workflow definition and runner bindings without writing a plan",
    ),
) -> None:
    """Compile a business workflow directory to WORKFLOW_PLAN.json."""
    try:
        from obra_business.compilation.compiler import CompilationError, WorkflowCompiler
    except ImportError as exc:
        print_error(
            "Business workflow compilation requires the in-repo obra-business package. "
            "Install it with: pip install -e obra-business/"
        )
        raise typer.Exit(1) from exc

    target_dir = Path(workflow_dir).expanduser().resolve(strict=False)
    if not target_dir.is_dir():
        print_error(f"Workflow directory not found: {target_dir}")
        raise typer.Exit(2)

    try:
        compiler = WorkflowCompiler()
        plan = compiler.compile(target_dir, validate_only=validate)
    except CompilationError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc

    if validate:
        print_info(f"Validated business workflow definition in {target_dir}.")
        raise typer.Exit(0)

    output_path = target_dir / _WORKFLOW_PLAN_FILENAME
    if plan is None:
        print_error("Compilation completed without producing a workflow plan.")
        raise typer.Exit(1)
    print_info(f"Wrote {output_path}.")
    raise typer.Exit(0)


@workflow_app.command("regrade")
@handle_encoding_errors
@require_terms_accepted
def regrade_workflow(
    workflow_id: str = typer.Argument(..., help="Logical workflow_id to invalidate cached grades for."),
    working_dir: OptWorkingDir = None,
) -> None:
    """Invalidate cached complexity grades for a compiled business workflow."""
    base_dir = _resolve_base_dir(working_dir)
    workflows_root, matches = _find_workflow_targets_by_identifier(workflow_id, base_dir=base_dir)
    if not matches:
        print_error(
            f"No compiled business workflow with workflow_id '{workflow_id}' was found under {workflows_root}."
        )
        raise typer.Exit(1)
    if len(matches) > 1:
        print_error(
            f"workflow_id '{workflow_id}' is ambiguous under {workflows_root}. "
            "Resolve the duplicate compiled artifacts before regrading."
        )
        for candidate in matches:
            console.print(f"  - {_describe_workflow_target(candidate)}")
        raise typer.Exit(1)

    target = matches[0]
    plan_payload = _read_workflow_artifact(target.plan_path)
    if "complexity_grades" in plan_payload:
        plan_payload.pop("complexity_grades", None)
        target.plan_path.write_text(
            json.dumps(plan_payload, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    print_info(f"Invalidated cached grades for {workflow_id}: {target.plan_path}")
    raise typer.Exit(0)


@business_app.command()
@handle_encoding_errors
@require_terms_accepted
def run(
    ctx: typer.Context,
    workflow_or_objective: str | None = typer.Argument(
        None,
        help=(
            "Compiled workflow artifact path or a business objective. "
            "Supported workflow files are WORKFLOW_PLAN.json and "
            ".obra-biz/canonical-workflow-source.json."
        ),
    ),
    objective: str | None = typer.Argument(
        None,
        help="Optional objective override when launching a workflow file.",
    ),
    input_path: str | None = typer.Option(
        None,
        "--input",
        "-i",
        help=(
            "Path to the input document the workflow will process. When "
            "omitted, the compiled workflow's input_template.md is used as "
            "a convention fallback."
        ),
        rich_help_panel="Business Workflow",
    ),
    working_dir: OptWorkingDir = None,
    orch_provider: OptOrchProvider = None,
    orch_model: OptOrchModel = None,
    orch_reasoning: OptOrchReasoning = None,
    mosaic: OptMosaic = None,
    model: OptModel = None,
    fast_model: OptFastModel = None,
    high_model: OptHighModel = None,
    impl_provider: OptImplProvider = None,
    reasoning_level: OptReasoningLevel = None,
    no_extended_thinking: OptNoExtendedThinking = False,
    verbose: OptVerbose = 0,
    interactive: OptInteractive = False,
    non_interactive: OptNonInteractive = False,
    stream: OptStream = False,
    plan_only: OptPlanOnly = False,
    hard_block_on: OptHardBlockOn = None,
    defaults_json: OptDefaultsJson = False,
    config_override: OptConfigOverride = None,
    local: OptLocal = False,
) -> None:
    """Run business workflows with discovery, direct execution, or derivation.

    Examples:
        obra business run
        obra business run .obra-biz/workflows/WORKFLOW-001/WORKFLOW_PLAN.json
        obra business run "Generate Q1 report"
        obra business run WORKFLOW_PLAN.json "Use the imported workflow for Q1 reporting"
        obra business run WORKFLOW_PLAN.json --input ./inputs/q1-invoice.md
    """

    verbose = _resolve_command_verbosity(ctx, verbose)
    mode = resolve_interaction_mode(interactive=interactive, non_interactive=non_interactive)

    with _apply_interaction_mode(mode):
        print_banner()
        console.print(
            f"{glyphs.logs} Logs: run 'obra logs viewer' for live session logs", style="cyan"
        )
        if mode is InteractionMode.HEADLESS and sys.stdin.isatty():
            console.print("[dim]Headless mode (default). Use --interactive for prompts.[/dim]")
        console.print()

        base_dir = _resolve_base_dir(working_dir)
        resolution = _resolve_business_run_mode(
            workflow_or_objective,
            objective,
            base_dir=base_dir,
        )
        if resolution.mode == "discovery":
            _render_discovery_outcome(
                workflows_root=resolution.discovery_root or base_dir,
                candidates=resolution.candidates,
            )

        if resolution.mode == "objective":
            effective_objective = resolution.objective
            plan_file = None
            execute_pipeline = False
        else:
            target = resolution.target
            if target is None:
                print_error("Business workflow resolution failed before launch.")
                raise typer.Exit(2)
            effective_objective = resolution.objective or _synthesize_objective_from_workflow_artifact(
                target.metadata_path
            )
            plan_file = target.plan_path
            execute_pipeline = True

        resolved_input_path = _resolve_input_document_path(
            input_path=input_path,
            base_dir=base_dir,
            execute_pipeline=execute_pipeline,
        )

        if execute_pipeline and plan_file is not None:
            _publish_workflow_revision_for_plan(plan_file)

        from obra.cli.run_support.session_flow import run_derive as _session_run_derive

        with _apply_config_override_layer(config_override):
            _session_run_derive(
                **prepare_run_invocation(
                    objective=effective_objective,
                    working_dir=working_dir,
                    domain="business",
                    resume_session=None,
                    continue_from=None,
                    resume_from=None,
                    rerun_setup=False,
                    plan_id=None,
                    plan_file=plan_file,
                    execution_input_path=resolved_input_path,
                    orch_provider=orch_provider,
                    orch_model=orch_model,
                    orch_reasoning=orch_reasoning,
                    mosaic=mosaic,
                    model=model,
                    fast_model=fast_model,
                    high_model=high_model,
                    impl_provider=impl_provider,
                    reasoning_level=reasoning_level,
                    no_extended_thinking=no_extended_thinking,
                    verbose=verbose,
                    stream=stream,
                    plan_only=plan_only,
                    execute_pipeline=execute_pipeline,
                    hard_block_on=hard_block_on,
                    defaults_json=defaults_json,
                    spike_first=False,
                    no_spike_first=False,
                    plan_first=False,
                    no_closeout=False,
                    skip_intent=False,
                    review_intent=False,
                    enrich=False,
                    no_enrich=False,
                    isolated=None,
                    no_isolated=None,
                    full_review=False,
                    skip_review=False,
                    review_agents=None,
                    with_security=False,
                    with_testing=False,
                    with_docs=False,
                    with_code_quality=False,
                    no_security=False,
                    no_testing=False,
                    no_docs=False,
                    no_code_quality=False,
                    review_format=None,
                    review_quiet=False,
                    review_summary_only=False,
                    fail_on_p1=False,
                    fail_on_p2=False,
                    review_timeout=None,
                    auto_report=False,
                    yes=False,
                    mock_credentials=False,
                    skip_env_setup=False,
                    skip_git_check=False,
                    auto_init_git=False,
                    skip_plan_quality_gate=False,
                    skip_complexity_check=False,
                    parallel=False,
                    skip_tier_check=False,
                    skip_explore=False,
                    force_explore=False,
                    plan_mode=None,
                    local=local,
                )
            )
