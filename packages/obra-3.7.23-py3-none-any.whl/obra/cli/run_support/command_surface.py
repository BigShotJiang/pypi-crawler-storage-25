"""Shared command-surface preprocessing for `obra run` and `obra derive`."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer

from obra.display import console, print_error, print_info, print_warning
from obra.session.working_dir import normalize_wsl_unc_path

VALID_WORK_TYPES = (
    "feature_implementation",
    "bug_fix",
    "refactoring",
    "documentation",
    "testing",
    "performance",
    "security",
    "configuration",
    "infrastructure",
    "dependencies",
    "general",
)

_VALID_PLAN_MODES = ("auto", "quick", "standard", "light", "balanced", "thorough")


def _enable_local_mode(local: bool) -> None:
    """Enable local emulator mode when requested."""
    if not local:
        return

    from obra.config import enable_local_mode

    enable_local_mode()
    print_info("Local mode: Using Firebase emulator at localhost:5001")


def _normalize_reasoning_level(
    reasoning_level: str | None,
    no_extended_thinking: bool,
) -> str | None:
    """Apply the no-extended-thinking override."""
    effective_reasoning_level = reasoning_level
    if no_extended_thinking:
        if reasoning_level is not None and reasoning_level != "off":
            print_warning(f"--no-extended-thinking overrides --reasoning-level {reasoning_level}")
        effective_reasoning_level = "off"
    return effective_reasoning_level


def _normalize_mosaic_models(
    *,
    mosaic: str | None,
    orch_model: str | None,
    model: str | None,
) -> tuple[str | None, str | None]:
    """Expand --mosaic shorthand into explicit orchestrator and implementation models."""
    if mosaic is None:
        return orch_model, model

    if orch_model is not None or model is not None:
        print_error("--mosaic cannot be combined with explicit --orch-model or --model")
        raise typer.Exit(1)

    raw_value = mosaic.strip()
    orch_part, separator, impl_part = raw_value.partition(":")
    normalized_orch = orch_part.strip()
    normalized_impl = impl_part.strip()
    if separator != ":" or not normalized_orch or not normalized_impl or ":" in normalized_impl:
        print_error("Invalid --mosaic value. Use ORCH_MODEL:IMPL_MODEL")
        raise typer.Exit(1)
    return normalized_orch, normalized_impl


def _normalize_working_dir_arg(working_dir: str | None) -> Path | None:
    """Normalize a CLI working-directory option."""
    if working_dir is None:
        return None
    normalized_path = normalize_wsl_unc_path(working_dir)
    return Path(normalized_path).expanduser().resolve(strict=False)


def _normalize_plan_mode(plan_mode: str | None) -> str | None:
    """Validate and normalize the plan-mode flag."""
    if plan_mode is not None and plan_mode.lower() not in _VALID_PLAN_MODES:
        print_error(
            f"Invalid --plan-mode '{plan_mode}'. Must be one of: {', '.join(_VALID_PLAN_MODES)}"
        )
        raise typer.Exit(1)
    return plan_mode.lower() if plan_mode else None


def _normalize_hard_block_on(raw_value: str | None) -> list[str] | None:
    """Validate and normalize --hard-block-on."""
    if raw_value is None:
        return None
    priorities = [
        part.strip().upper()
        for part in raw_value.split(",")
        if part.strip()
    ]
    if not priorities:
        print_error("--hard-block-on cannot be empty")
        raise typer.Exit(1)
    invalid = sorted(set(priorities) - {"P0", "P1", "P2"})
    if invalid:
        print_error(
            "--hard-block-on accepts only P0, P1, and P2; P3 is a NOTE tier and cannot hard-block"
        )
        raise typer.Exit(1)
    if "P0" not in priorities:
        print_error("--hard-block-on must include P0")
        raise typer.Exit(1)
    if len(set(priorities)) != len(priorities):
        print_error("--hard-block-on cannot contain duplicate priorities")
        raise typer.Exit(1)
    return priorities


def _normalize_spike_first_override(
    *,
    spike_first: bool,
    no_spike_first: bool,
    plan_first: bool,
) -> bool | None:
    """Validate and normalize the per-session spike-first override."""
    enabled_count = sum(bool(flag) for flag in (spike_first, no_spike_first, plan_first))
    if enabled_count > 1:
        print_error("Specify at most one of --spike-first, --no-spike-first, or --plan-first")
        raise typer.Exit(1)
    if spike_first:
        return True
    if no_spike_first or plan_first:
        return False
    return None


def prepare_run_invocation(
    *,
    objective: str | None,
    working_dir: str | None,
    domain: str | None,
    resume_session: str | None,
    continue_from: str | None,
    resume_from: str | None,
    rerun_setup: bool,
    plan_id: str | None,
    plan_file: Path | None,
    execution_input_path: Path | None = None,
    orch_provider: str | None = None,
    orch_model: str | None = None,
    orch_reasoning: str | None = None,
    mosaic: str | None = None,
    model: str | None,
    fast_model: str | None,
    high_model: str | None,
    impl_provider: str | None,
    reasoning_level: str | None,
    no_extended_thinking: bool,
    verbose: int,
    stream: bool,
    plan_only: bool,
    execute_pipeline: bool = False,
    hard_block_on: str | None,
    defaults_json: bool,
    spike_first: bool,
    no_spike_first: bool,
    plan_first: bool,
    no_closeout: bool,
    skip_intent: bool,
    review_intent: bool,
    enrich: bool,
    no_enrich: bool,
    isolated: bool | None,
    no_isolated: bool | None,
    full_review: bool,
    skip_review: bool,
    review_agents: str | None,
    with_security: bool,
    with_testing: bool,
    with_docs: bool,
    with_code_quality: bool,
    no_security: bool,
    no_testing: bool,
    no_docs: bool,
    no_code_quality: bool,
    review_format: str | None,
    review_quiet: bool,
    review_summary_only: bool,
    fail_on_p1: bool,
    fail_on_p2: bool,
    review_timeout: int | None,
    auto_report: bool,
    yes: bool,
    mock_credentials: bool,
    skip_env_setup: bool,
    skip_git_check: bool,
    auto_init_git: bool,
    skip_plan_quality_gate: bool,
    skip_complexity_check: bool,
    parallel: bool,
    skip_tier_check: bool,
    skip_explore: bool,
    force_explore: bool,
    plan_mode: str | None,
    local: bool,
) -> dict[str, Any]:
    """Normalize `obra run` inputs into `_run_derive()` kwargs."""
    _enable_local_mode(local)
    normalized_orch_model, normalized_model = _normalize_mosaic_models(
        mosaic=mosaic,
        orch_model=orch_model,
        model=model,
    )

    return {
        "objective": objective,
        "initial_intent_id": None,
        "working_dir": _normalize_working_dir_arg(working_dir),
        "domain": domain,
        "resume_session": resume_session,
        "continue_from": continue_from,
        "resume_from": resume_from,
        "rerun_setup": rerun_setup,
        "plan_id": plan_id,
        "plan_file": plan_file,
        "execution_input_path": execution_input_path,
        "orch_provider": orch_provider,
        "orch_model": normalized_orch_model,
        "orch_reasoning": orch_reasoning,
        "model": normalized_model,
        "fast_model": fast_model,
        "high_model": high_model,
        "impl_provider": impl_provider,
        "reasoning_level": _normalize_reasoning_level(reasoning_level, no_extended_thinking),
        "verbose": verbose,
        "stream": stream,
        "plan_only": plan_only,
        "execute_pipeline": execute_pipeline,
        "hard_block_on": _normalize_hard_block_on(hard_block_on),
        "defaults_json": defaults_json,
        "spike_first_override": _normalize_spike_first_override(
            spike_first=spike_first,
            no_spike_first=no_spike_first,
            plan_first=plan_first,
        ),
        "no_closeout": no_closeout,
        "skip_intent": skip_intent,
        "review_intent": review_intent,
        "enrich": enrich,
        "no_enrich": no_enrich,
        "isolated": isolated,
        "no_isolated": no_isolated,
        "full_review": full_review,
        "skip_review": skip_review,
        "review_agents": review_agents,
        "with_security": with_security,
        "with_testing": with_testing,
        "with_docs": with_docs,
        "with_code_quality": with_code_quality,
        "no_security": no_security,
        "no_testing": no_testing,
        "no_docs": no_docs,
        "no_code_quality": no_code_quality,
        "review_format": review_format,
        "review_quiet": review_quiet,
        "review_summary_only": review_summary_only,
        "fail_on_p1": fail_on_p1,
        "fail_on_p2": fail_on_p2,
        "review_timeout": review_timeout,
        "auto_report": auto_report,
        "yes": yes,
        "mock_credentials": mock_credentials,
        "skip_env_setup": skip_env_setup,
        "skip_git_check": skip_git_check,
        "auto_init_git": auto_init_git,
        "skip_plan_quality_gate": skip_plan_quality_gate,
        "skip_complexity_check": skip_complexity_check,
        "parallel": parallel,
        "skip_tier_check": skip_tier_check,
        "skip_explore": skip_explore,
        "force_explore": force_explore,
        "plan_mode": _normalize_plan_mode(plan_mode),
    }


def _resolve_derive_objective(
    *,
    objective: str | None,
    continue_intent: bool,
    working_dir: Path,
) -> tuple[str, str | None]:
    """Resolve the objective for `obra derive`."""
    from obra.intent.storage import IntentStorage

    storage = IntentStorage()
    project_id = storage.get_workspace_id(working_dir)

    if objective:
        if not continue_intent:
            active_intent = storage.load_active(project_id)
            if active_intent:
                console.print()
                print_info(
                    f"Note: Active intent '{active_intent.slug}' exists. "
                    "New derivation will create a separate intent."
                )
                console.print(
                    "      To use the active intent, run: [cyan]obra derive[/cyan] (no objective)"
                )
                console.print()
        return objective, None

    active_intent = storage.load_active(project_id)
    if not active_intent:
        console.print()
        print_error("No active intent found for this project")
        console.print()
        console.print("To create an intent:")
        console.print("  [cyan]obra intent new 'your objective'[/cyan]")
        console.print()
        console.print("Or provide an objective directly:")
        console.print("  [cyan]obra derive 'your objective'[/cyan]")
        console.print()
        raise typer.Exit(1)

    final_objective = active_intent.raw_objective or active_intent.problem_statement
    console.print()
    print_info(f"Using active intent: {active_intent.slug}")
    console.print(f"  [dim]Problem: {active_intent.problem_statement[:60]}...[/dim]")
    console.print()
    return final_objective, active_intent.id


def prepare_derive_invocation(
    *,
    objective: str | None,
    working_dir: str | None,
    domain: str | None,
    continue_intent: bool,
    resume_session: str | None,
    continue_from: str | None,
    plan_id: str | None,
    plan_file: Path | None,
    orch_provider: str | None = None,
    orch_model: str | None = None,
    orch_reasoning: str | None = None,
    mosaic: str | None = None,
    model: str | None,
    fast_model: str | None,
    high_model: str | None,
    impl_provider: str | None,
    reasoning_level: str | None,
    no_extended_thinking: bool,
    verbose: int,
    stream: bool,
    plan_only: bool,
    hard_block_on: str | None,
    defaults_json: bool,
    spike_first: bool,
    no_spike_first: bool,
    plan_first: bool,
    no_closeout: bool,
    skip_intent: bool,
    review_intent: bool,
    isolated: bool | None,
    no_isolated: bool | None,
    full_review: bool,
    skip_review: bool,
    review_agents: str | None,
    with_security: bool,
    with_testing: bool,
    with_docs: bool,
    with_code_quality: bool,
    no_security: bool,
    no_testing: bool,
    no_docs: bool,
    no_code_quality: bool,
    review_format: str | None,
    review_quiet: bool,
    review_summary_only: bool,
    fail_on_p1: bool,
    fail_on_p2: bool,
    review_timeout: int | None,
    auto_report: bool,
    skip_git_check: bool,
    auto_init_git: bool,
    skip_plan_quality_gate: bool,
    skip_complexity_check: bool,
    force_empty: bool,
    force_existing: bool,
    from_step: int | None,
    cascade: bool,
    work_type: str | None,
    skip_explore: bool,
    force_explore: bool,
    plan_mode: str | None,
    local: bool,
) -> dict[str, Any]:
    """Normalize `obra derive` inputs into `_run_derive()` kwargs."""
    _enable_local_mode(local)

    work_dir = _normalize_working_dir_arg(working_dir) or Path.cwd()

    if force_empty and force_existing:
        console.print()
        print_error("Cannot specify both --force-empty and --force-existing")
        console.print()
        raise typer.Exit(1)

    if work_type is not None and work_type not in VALID_WORK_TYPES:
        console.print()
        print_error(f"Invalid work type: '{work_type}'")
        console.print()
        console.print("Valid work types:")
        for valid_work_type in VALID_WORK_TYPES:
            console.print(f"  - {valid_work_type}")
        console.print()
        raise typer.Exit(1)

    resolved_objective, initial_intent_id = _resolve_derive_objective(
        objective=objective,
        continue_intent=continue_intent,
        working_dir=work_dir,
    )
    normalized_orch_model, normalized_model = _normalize_mosaic_models(
        mosaic=mosaic,
        orch_model=orch_model,
        model=model,
    )

    return {
        "objective": resolved_objective,
        "initial_intent_id": initial_intent_id,
        "working_dir": work_dir,
        "domain": domain,
        "resume_session": resume_session,
        "continue_from": continue_from,
        "plan_id": plan_id,
        "plan_file": plan_file,
        "orch_provider": orch_provider,
        "orch_model": normalized_orch_model,
        "orch_reasoning": orch_reasoning,
        "model": normalized_model,
        "fast_model": fast_model,
        "high_model": high_model,
        "impl_provider": impl_provider,
        "reasoning_level": _normalize_reasoning_level(reasoning_level, no_extended_thinking),
        "verbose": verbose,
        "stream": stream,
        "plan_only": plan_only,
        "hard_block_on": _normalize_hard_block_on(hard_block_on),
        "defaults_json": defaults_json,
        "spike_first_override": _normalize_spike_first_override(
            spike_first=spike_first,
            no_spike_first=no_spike_first,
            plan_first=plan_first,
        ),
        "no_closeout": no_closeout,
        "skip_intent": skip_intent,
        "review_intent": review_intent,
        "isolated": isolated,
        "no_isolated": no_isolated,
        "full_review": full_review,
        "skip_review": skip_review,
        "review_agents": review_agents,
        "with_security": with_security,
        "with_testing": with_testing,
        "with_docs": with_docs,
        "with_code_quality": with_code_quality,
        "no_security": no_security,
        "no_testing": no_testing,
        "no_docs": no_docs,
        "no_code_quality": no_code_quality,
        "review_format": review_format,
        "review_quiet": review_quiet,
        "review_summary_only": review_summary_only,
        "fail_on_p1": fail_on_p1,
        "fail_on_p2": fail_on_p2,
        "review_timeout": review_timeout,
        "auto_report": auto_report,
        "skip_git_check": skip_git_check,
        "auto_init_git": auto_init_git,
        "skip_plan_quality_gate": skip_plan_quality_gate,
        "skip_complexity_check": skip_complexity_check,
        "from_step": from_step,
        "cascade": cascade,
        "work_type": work_type,
        "skip_explore": skip_explore,
        "force_explore": force_explore,
        "plan_mode": _normalize_plan_mode(plan_mode),
    }
