"""Pre-built agent templates — the user-facing catalogue."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from openvox.config import get_settings
from openvox.db import db_session
from openvox.db.models import Agent

logger = logging.getLogger(__name__)

router = APIRouter()


# ──────────────────────────────────────────────────────────────────────
# Built-in templates. Each is a fully-configured agent the user can
# instantiate with one click. The skills referenced here must exist in
# the built-in skill registry.
# ──────────────────────────────────────────────────────────────────────
TEMPLATES: list[dict[str, Any]] = [
    {
        "id": "ecommerce-support",
        "match": {"priority": 30, "keywords": ["order", "shipment", "refund", "return", "e-comm", "ecommerce", "shopping"]},
        "name": "E-commerce Customer Support",
        "tagline": "Resolve order, return, and stock questions over voice.",
        "category": "Support",
        "icon": "ShoppingBag",
        "use_cases": [
            "Where is my order?",
            "Start a return",
            "Check stock availability",
            "Update shipping address",
        ],
        "default": {
            "name": "Acme Support Voice",
            "system_prompt": (
                "You are a friendly e-commerce support agent for Acme. "
                "Use the lookup_order, start_return, and check_stock tools. "
                "Always confirm the order ID by reading it back. Keep responses under 2 sentences."
            ),
            "greeting": "Hi! I'm Acme's voice assistant — how can I help you today?",
            "skills": ["lookup_order", "start_return", "check_stock", "get_time"],
            "voice_id": "en_male_tim_uranus_bigtts",
        },
    },
    {
        "id": "education-tutor",
        "match": {"priority": 30, "keywords": ["tutor", "teach", "homework", "math", "science", "explain"]},
        "name": "Science & Math Tutor",
        "tagline": "Explain concepts, walk through worked examples, give homework hints.",
        "category": "Education",
        "icon": "GraduationCap",
        "use_cases": [
            "Explain photosynthesis to a 12-year-old",
            "Help me solve this quadratic",
            "What is the difference between mitosis and meiosis?",
        ],
        "default": {
            "name": "Science Tutor",
            "system_prompt": (
                "You are a patient science and mathematics tutor. Use the calculator and "
                "explain_concept tools. Always check the student's understanding with a "
                "follow-up question. Speak clearly at a measured pace."
            ),
            "greeting": "Hi there — what would you like to learn about today?",
            "skills": ["calculator", "explain_concept", "web_search"],
            # Use the same activated default as the other English templates.
            # The previous `en_male_adam_mars_bigtts` value wasn't licensed on
            # the user's BytePlus key and produced a runtime 55000000 error
            # on every voice turn (bug #25 / #58).
            "voice_id": "en_male_tim_uranus_bigtts",
        },
    },
    {
        "id": "stock-analyst",
        "match": {"priority": 30, "keywords": ["stock", "share price", "ticker", "market", "trading", "invest"]},
        "name": "Stock Market Analyst",
        "tagline": "Live quotes and basic technical analysis. Voice-first.",
        "category": "Finance",
        "icon": "TrendingUp",
        "use_cases": [
            "How is NVDA doing today?",
            "Compare AAPL and MSFT",
            "What's the RSI on TSLA?",
        ],
        "default": {
            "name": "Market Pulse",
            "system_prompt": (
                "You are a markets analyst. Use the get_quote and technical_indicators tools "
                "for any factual ticker question. Always include a short risk disclaimer "
                "('this is not financial advice'). Keep responses under 3 sentences."
            ),
            "greeting": "Markets desk here — which ticker would you like to look at?",
            "skills": ["get_quote", "technical_indicators", "get_time"],
            "voice_id": "en_male_tim_uranus_bigtts",
        },
    },
    {
        "id": "sales-sdr",
        "match": {"priority": 30, "keywords": ["lead", "sdr", "outbound", "qualif", "cold call", "telesales"]},
        "name": "Outbound Sales SDR (lead qualifier)",
        "tagline": "Calls leads, runs BANT qualification, books demos.",
        "category": "Sales",
        "icon": "PhoneOutgoing",
        "use_cases": [
            "Dial the next lead in our pipeline.",
            "Find out if Northwind Logistics is qualified.",
            "Book a demo for LEAD-001 next Wednesday at 2 PM.",
            "List qualified leads from this week.",
        ],
        "default": {
            "name": "Mira (SDR)",
            "system_prompt": (
                "You are Mira, an outbound SDR at OpenVox. Your job is to qualify leads "
                "using BANT (Budget, Authority, Need, Timeline) and book demos for "
                "qualified prospects. Be warm but efficient — calls under 5 minutes.\n\n"
                "Workflow for each call:\n"
                "  1. Greet the prospect by name and confirm you're speaking with the right person.\n"
                "  2. One sentence on why you're calling (reference their `interest` field).\n"
                "  3. Ask one BANT question at a time:\n"
                "       Need:      What problem are you trying to solve right now?\n"
                "       Timeline:  When are you hoping to have a solution in place?\n"
                "       Authority: Will you be making the decision, or who else is involved?\n"
                "       Budget:    Do you have a budget allocated for this?\n"
                "  4. Score each 0-100 in your head (be honest — don't inflate).\n"
                "  5. Call record_disposition with the four scores + 1-3 sentences of notes.\n"
                "  6. If the result is `qualified`, call check_availability (service_id=massage as "
                "     a placeholder 60-min slot), confirm a time, then call book_demo.\n"
                "  7. Thank them and end the call.\n\n"
                "Never pressure the prospect. If they ask to be removed, set next_step=closed_lost "
                "and apologise once for the interruption. Always rely on the tools — do not invent "
                "facts about the prospect."
            ),
            "greeting": "",  # Outbound: WE greet, picked up by the agent's first sentence.
            "skills": [
                "fetch_next_lead",
                "get_lead",
                "record_disposition",
                "qualified_leads",
                "book_demo",
                "check_availability",
                "get_time",
            ],
        },
    },
    {
        "id": "receptionist",
        # Customer-facing appointment booking — salons/clinics/spas.
        # Distinct from calendar-scheduler (user's own Google Calendar).
        "match": {"priority": 20, "keywords": [
            "appointment", "salon", "barber", "spa", "clinic", "receptionist",
            "front desk", "book a client", "book a customer", "walk-in",
        ]},
        "name": "Receptionist / Appointment Scheduler",
        "tagline": "Answers calls, books appointments, knows business hours.",
        "category": "Front desk",
        "icon": "Calendar",
        "use_cases": [
            "Hi, I'd like to book a haircut next Tuesday afternoon.",
            "What time do you close on Saturdays?",
            "Cancel my appointment APT-1-14.",
            "What's on the schedule today?",
        ],
        "default": {
            "name": "Front Desk",
            "system_prompt": (
                "You are the front-desk receptionist for Acme Salon & Spa. Always be warm and "
                "concise — keep voice responses under 2 sentences when possible.\n\n"
                "Workflow for every booking:\n"
                "  1. Greet and ask which service the caller wants.\n"
                "  2. Call check_availability for the requested service and read back 2-3 slots.\n"
                "  3. Confirm the slot, then collect the caller's full name and phone number "
                "     by reading the number back digit-by-digit.\n"
                "  4. Call book_appointment with the EXACT ISO start time from check_availability.\n"
                "  5. Read the confirmation code back and offer anything else.\n"
                "If asked about hours, services, or pricing, call business_info. "
                "If the caller wants to cancel, ask for the confirmation code and call "
                "cancel_appointment. Never invent details — always rely on the tools."
            ),
            "greeting": "Acme Salon and Spa, how can I help you today?",
            "skills": [
                "business_info",
                "check_availability",
                "book_appointment",
                "cancel_appointment",
                "list_appointments",
                "get_time",
            ],
        },
    },
    {
        "id": "document-qa",
        "match": {"priority": 30, "keywords": ["pdf", "document", "knowledge base", "rag", "research", "policy"]},
        "name": "Document Q&A Assistant",
        "tagline": "Upload PDFs, slides, or images and ask questions out loud.",
        "category": "Knowledge",
        "icon": "FileText",
        "use_cases": [
            "What does the contract say about renewal terms?",
            "Summarise page 4 of this report",
            "What's shown in the architecture diagram?",
            "Find references to 'GDPR' across all my docs",
        ],
        "default": {
            "name": "Doc Assistant",
            "system_prompt": (
                "You are a careful document-grounded assistant. When the user asks a question, "
                "ALWAYS call the query_documents tool first to retrieve relevant passages. "
                "If a retrieved passage is an image, call analyze_image with its image_url to inspect it. "
                "Ground every claim in the returned passages and cite sources by document name. "
                "If the answer isn't in the documents, say so plainly. Keep voice responses under 3 sentences."
            ),
            "greeting": "Hi! Upload a document on the agent page and ask me anything about it.",
            "skills": ["query_documents", "analyze_image", "get_time"],
        },
    },
    {
        "id": "multilingual-support",
        "match": {"priority": 30, "keywords": [
            "multilingual", "language", "polyglot", "international",
            "english spanish", "chinese support",
        ]},
        "name": "Multilingual Customer Support IVR",
        "tagline": "One conversational agent, 51+ languages. No 'press 1 for…' menus.",
        "category": "Support",
        "icon": "Languages",
        "use_cases": [
            "Hello, my internet stopped working.",
            "Hola, necesito ayuda con mi factura.",
            "你好, 我想查一下我的订单。",
            "Salut, j'ai un problème avec mon abonnement.",
        ],
        "default": {
            "name": "Polyglot Support",
            "system_prompt": (
                "You are a multilingual customer support IVR. The caller may speak any of "
                "51 languages BytePlus Seed ASR supports — automatically reply in the same "
                "language the caller is using.\n\n"
                "Workflow:\n"
                "  1. Greet in English first ('Hello, thanks for calling. How can I help?').\n"
                "  2. After the caller's first sentence, call detect_language with the user's "
                "     text to confirm the language. If it differs from English, switch — your "
                "     next response must be in the caller's language.\n"
                "  3. Identify what they need: 'billing', 'technical', or 'sales'. If unclear, "
                "     ask one clarifying question in their language.\n"
                "  4. Call route_to_specialist with the topic and language. Read the "
                "     queue.agent_name and wait_min back to the caller in their language: "
                "     'I'll connect you with <agent_name>; the wait is about <wait_min> minutes.'\n"
                "  5. Stay concise — voice responses no longer than two sentences.\n\n"
                "Never apologise for not understanding. The pipeline handles language fluently."
            ),
            "greeting": "Hello, thanks for calling. How can I help you today?",
            "skills": [
                "detect_language",
                "route_to_specialist",
                "query_documents",
                "get_time",
            ],
            # Per-language voice routing. Operators add/remove entries as
            # they activate voices in the BytePlus console.
            "voice_map": {
                "en": "en_male_tim_uranus_bigtts",
                # `_mars_bigtts` was the old TTS 1.0 family. The current
                # TTS 2.0 catalogue uses `_uranus_bigtts` exclusively.
                "zh": "zh_female_cancan_uranus_bigtts",
                "es": "es_male_felipe_uranus_bigtts",
                "fr": "fr_male_usseau_uranus_bigtts",
                "ja": "jp_female_minimi_uranus_bigtts",
                "ko": "kr_male_shane_uranus_bigtts",
                "pt": "pt_male_martins_uranus_bigtts",
            },
        },
    },
    {
        "id": "voice-analyzer",
        "match": {"priority": 30, "keywords": ["audio", "recording", "transcribe", "sentiment", "call analy"]},
        "name": "Voice Recording Analyzer",
        "tagline": "Upload or record audio, get sentiment + profanity + summary.",
        "category": "Analytics",
        "icon": "Mic",
        "use_cases": [
            "Quality-assure call-centre recordings",
            "Moderation on user-generated audio",
            "Coach sales calls",
        ],
        "default": {
            "name": "Audio Analyzer",
            "system_prompt": (
                "You are an audio QA assistant. When the user submits a recording, transcribe "
                "it then call sentiment_analyze and profanity_check on the transcript. Return "
                "a one-paragraph summary plus a structured report."
            ),
            "greeting": "Drop a recording or speak now and I'll analyse it.",
            "skills": ["transcribe_recording", "sentiment_analyze", "profanity_check"],
            "voice_id": "en_male_tim_uranus_bigtts",
        },
    },
]


# ──────────────────────────────────────────────────────────────────────
# Session 8: multi-language template family.
#
# Three use-cases (service hotline, reactivation outbound, telesales) ×
# seven languages (EN, ZH-CN, YUE, ES, ID, FR, HI). The system_prompt is
# in-language for each so the LLM speaks idiomatically rather than
# producing translated-from-English responses.
#
# Voice picks are pragmatic defaults — the user's BytePlus key has only
# some of these activated, so the dashboard's "Voice" tab is the place to
# refine after instantiation. Where a BytePlus voice isn't activated,
# fall back to ElevenLabs multilingual v2 (the user has it on another
# tier — see CLAUDE.md §6 BytePlus TTS gotcha).
# ──────────────────────────────────────────────────────────────────────


def _hotline_prompt(lang: str) -> str:
    return {
        "en": (
            "You are a polite multilingual customer-service voice agent for Acme. "
            "Look up orders, check stock, start returns, and escalate to a human when "
            "the caller asks. Always confirm the order ID by reading it back. Keep "
            "responses to one or two short sentences."
        ),
        "zh": (
            "你是 Acme 客服电话语音助手。请使用 lookup_order、check_stock、start_return 等工具。"
            "客户来电时请先礼貌问候,然后帮助解决订单查询、库存确认、退换货等问题。"
            "回答简洁,每次回复控制在两句话以内。客户要求转人工时请使用 route_to_specialist。"
        ),
        "yue": (
            "你係 Acme 嘅客戶服務電話語音助手。請用 lookup_order、check_stock、start_return 工具。"
            "幫客人查訂單、確認存貨、辦理退貨。每次回答最多兩句,保持簡潔。"
            "客人要求搵真人就用 route_to_specialist。"
        ),
        "es": (
            "Eres un asistente de voz amable para el servicio al cliente de Acme. "
            "Utiliza las herramientas lookup_order, check_stock y start_return para "
            "ayudar al cliente. Confirma siempre el número de pedido repitiéndolo. "
            "Mantén las respuestas en una o dos frases breves."
        ),
        "id": (
            "Anda adalah asisten suara layanan pelanggan untuk Acme. "
            "Gunakan tools lookup_order, check_stock, dan start_return untuk membantu "
            "pelanggan. Selalu konfirmasi ID pesanan dengan mengulanginya. "
            "Jawab dengan singkat, satu sampai dua kalimat saja."
        ),
        "fr": (
            "Tu es un agent vocal de service client pour Acme. Utilise les outils "
            "lookup_order, check_stock et start_return pour aider l'appelant. "
            "Confirme toujours le numéro de commande en le répétant. Réponds en une "
            "ou deux phrases courtes."
        ),
        "hi": (
            "आप एसएमई के लिए एक विनम्र ग्राहक सेवा वॉइस एजेंट हैं। ऑर्डर देखने, स्टॉक "
            "चेक करने, और रिटर्न शुरू करने के लिए lookup_order, check_stock, और "
            "start_return टूल्स का उपयोग करें। ऑर्डर आईडी हमेशा दोहराकर पुष्टि करें। "
            "उत्तर एक या दो वाक्यों में दें।"
        ),
    }[lang]


def _reactivation_prompt(lang: str) -> str:
    return {
        "en": (
            "You're calling a lapsed Acme customer who hasn't ordered in 90+ days. "
            "Open warmly, ask if their needs have changed, mention this month's 15% "
            "discount code REACTIVATE15, then offer to schedule a follow-up via "
            "book_appointment. Respect a 'no' on the first try — do not push twice."
        ),
        "zh": (
            "你正在致电一位 90 天未下单的 Acme 老客户。开场要温暖友好,询问他们的需求是否有变化,"
            "提及本月 15% 折扣码 REACTIVATE15,然后用 book_appointment 提议安排回访。"
            "客户第一次拒绝时请尊重对方,不要再次催促。"
        ),
        "yue": (
            "你打緊俾一位 90 日無落單嘅 Acme 老客戶。開頭要熱情友善,問下佢需求有冇變,"
            "順便提下今個月嘅 9 折優惠碼 REACTIVATE15,再用 book_appointment 約下次跟進。"
            "客人第一次拒絕就尊重,唔好再追問。"
        ),
        "es": (
            "Estás llamando a un cliente de Acme que no compra desde hace 90 días o más. "
            "Abre con calidez, pregunta si sus necesidades han cambiado, menciona el "
            "código de descuento del 15% REACTIVATE15, y ofrécete a programar un "
            "seguimiento con book_appointment. Respeta el 'no' la primera vez."
        ),
        "id": (
            "Anda menelepon pelanggan Acme yang sudah 90+ hari tidak memesan. "
            "Buka dengan hangat, tanyakan apakah kebutuhan mereka berubah, sebutkan "
            "kode diskon 15% bulan ini REACTIVATE15, lalu tawarkan untuk menjadwalkan "
            "tindak lanjut via book_appointment. Hormati 'tidak' pada percobaan pertama."
        ),
        "fr": (
            "Tu appelles un client d'Acme qui n'a pas commandé depuis 90 jours ou plus. "
            "Ouvre chaleureusement, demande si ses besoins ont changé, mentionne le "
            "code de remise de 15% REACTIVATE15, puis propose un rendez-vous de suivi "
            "via book_appointment. Respecte un « non » dès la première fois."
        ),
        "hi": (
            "आप एक Acme ग्राहक को कॉल कर रहे हैं जिसने 90+ दिनों से ऑर्डर नहीं किया। "
            "गर्मजोशी से शुरू करें, पूछें कि क्या उनकी ज़रूरतें बदली हैं, इस महीने के "
            "15% डिस्काउंट कोड REACTIVATE15 का ज़िक्र करें, और book_appointment से "
            "फ़ॉलो-अप शेड्यूल करने का प्रस्ताव दें। पहली बार 'नहीं' सुनकर रुक जाएँ।"
        ),
    }[lang]


def _telesales_prompt(lang: str) -> str:
    return {
        "en": (
            "You're an outbound SDR for Acme calling a fresh B2B lead. Run a short "
            "BANT-style qualification: budget, authority, need, timeline. If qualified, "
            "use book_demo to schedule a follow-up; otherwise record disposition via "
            "record_disposition and end politely. Keep the call under 3 minutes."
        ),
        "zh": (
            "你是 Acme 的电销代表,正在致电一位新的 B2B 潜在客户。请进行简短的 BANT 资质评估:"
            "预算 (Budget)、决策权 (Authority)、需求 (Need)、时间线 (Timeline)。若符合条件,"
            "使用 book_demo 预约演示;否则用 record_disposition 记录后礼貌结束。"
            "整通电话控制在 3 分钟以内。"
        ),
        "yue": (
            "你係 Acme 嘅電銷代表,而家打俾一個新嘅 B2B 潛在客戶。做個簡短嘅 BANT 資格評估:"
            "預算、決策權、需求、時間線。如果合資格,用 book_demo 約 demo;否則用 "
            "record_disposition 記錄之後禮貌咁掛線。成通電話最多 3 分鐘。"
        ),
        "es": (
            "Eres un SDR de Acme llamando a un nuevo prospecto B2B. Realiza una "
            "calificación BANT breve: presupuesto, autoridad, necesidad, plazo. Si "
            "califica, usa book_demo para agendar una demo; si no, registra la "
            "disposición con record_disposition y cierra cortésmente. Menos de 3 minutos."
        ),
        "id": (
            "Anda adalah SDR outbound Acme yang menelepon prospek B2B baru. Lakukan "
            "kualifikasi BANT singkat: budget, authority, need, timeline. Jika "
            "memenuhi syarat, gunakan book_demo untuk menjadwalkan demo; jika tidak, "
            "catat dengan record_disposition lalu tutup sopan. Total panggilan di "
            "bawah 3 menit."
        ),
        "fr": (
            "Tu es un SDR sortant pour Acme, en appel avec un prospect B2B frais. "
            "Mène une qualification BANT courte : budget, autorité, besoin, échéance. "
            "Si qualifié, utilise book_demo pour planifier une démo ; sinon, enregistre "
            "la disposition avec record_disposition et raccroche poliment. Moins de "
            "3 minutes au total."
        ),
        "hi": (
            "आप Acme के एक आउटबाउंड SDR हैं जो एक नए B2B लीड को कॉल कर रहे हैं। "
            "एक छोटा BANT क्वालिफिकेशन करें: बजट, अधिकार, ज़रूरत, समयसीमा। "
            "अगर योग्य हो, तो book_demo से डेमो शेड्यूल करें; नहीं तो "
            "record_disposition से नोट करके विनम्रता से कॉल समाप्त करें। "
            "कुल कॉल 3 मिनट से कम रखें।"
        ),
    }[lang]


# Every `voice` here must exist in `providers/byteplus/voices.py`
# (the real TTS 2.0 catalogue). The original cut of this map invented
# IDs that don't exist:
#   - zh_female_qiniao_bigtts        — TTS 1.0 family, removed
#   - zh_female_cantonese_bigtts     — no Cantonese voice in TTS 2.0
#   - multilingual_v2_{rachel,alice,henri,aria} — these are ElevenLabs
#                                                  voice IDs, not BytePlus
# Result: every multilingual template using these IDs got
# `code=55000000` at TTS time.
#
# Replacements:
#   zh   → Celeste (Chinese Female Clear) — real Mandarin voice.
#   yue  → Celeste again. The catalogue has no native Cantonese
#          voice; Mandarin TTS reading Cantonese romanisation gives
#          the closest acceptable demo until BytePlus ships one.
#   es   → Felipe (Mexican Spanish Male Clear) — real ES voice.
#   id   → Han (Indonesian Bahasa Male Clear) — real ID voice.
#   fr   → Usseau (French Male Clear) — real FR voice.
#   hi   → Vivi (Mixed-language Female Vivid). NOTE: TTS 2.0 has no
#          native Hindi voice. Vivi covers en/zh/ja/es/id but not hi;
#          the Hindi template will read text as transliterated English.
#          Documented limitation — to fix properly, swap TTS provider
#          to ElevenLabs Multilingual v2 for hi-IN agents.
_LANG_META: dict[str, dict[str, str]] = {
    "en":  {"name": "English",            "bcp47": "en-US",  "voice": "en_male_tim_uranus_bigtts",                "flag": "🇺🇸"},
    "zh":  {"name": "Mandarin (中文)",     "bcp47": "zh-CN",  "voice": "zh_female_qingxinnvsheng_uranus_bigtts",   "flag": "🇨🇳"},
    "yue": {"name": "Cantonese (粤语)",    "bcp47": "yue-HK", "voice": "zh_female_qingxinnvsheng_uranus_bigtts",   "flag": "🇭🇰"},
    "es":  {"name": "Spanish (Español)",  "bcp47": "es-ES",  "voice": "es_male_felipe_uranus_bigtts",             "flag": "🇪🇸"},
    "id":  {"name": "Bahasa Indonesia",   "bcp47": "id-ID",  "voice": "id_male_han_uranus_bigtts",                "flag": "🇮🇩"},
    "fr":  {"name": "French (Français)",  "bcp47": "fr-FR",  "voice": "fr_male_usseau_uranus_bigtts",             "flag": "🇫🇷"},
    "hi":  {"name": "Hindi (हिन्दी)",     "bcp47": "hi-IN",  "voice": "zh_female_vv_uranus_bigtts",               "flag": "🇮🇳"},
}


def _make_lang_templates() -> list[dict[str, Any]]:
    """Generate 3 use-cases × 7 languages = 21 templates.

    Returns one entry per (use_case, language) pair so the system_prompt
    is in-language (translated prompts feel wrong; native phrasing
    matters for tone of voice).
    """
    out: list[dict[str, Any]] = []
    # 7-tuple per use-case: slug, label, category, icon, prompt_fn,
    # skills, tagline, recommender keywords. Recommender keywords are
    # applied to EVERY language variant — language disambiguation is
    # handled separately via the LLM's own language detection on the
    # user's voice input (not the keyword classifier).
    use_cases = [
        ("hotline", "Service hotline", "Support", "PhoneOutgoing",
         _hotline_prompt,
         ["lookup_order", "check_stock", "start_return", "route_to_specialist", "detect_language"],
         "Greet customers, look up orders, handle returns, escalate.",
         ["customer service hotline", "hotline", "service line", "help line"]),
        ("reactivate", "Customer reactivation", "Sales", "Sparkles",
         _reactivation_prompt,
         ["book_appointment", "record_disposition", "get_lead", "detect_language"],
         "Outbound win-back: discount, soft pitch, book follow-up.",
         ["reactivat", "win back", "lapsed customer", "churn"]),
        ("telesales", "B2B telesales", "Sales", "TrendingUp",
         _telesales_prompt,
         ["fetch_next_lead", "record_disposition", "book_demo", "qualified_leads", "detect_language"],
         "BANT qualification + demo booking on a 3-minute call.",
         ["b2b telesales", "telesales call", "outbound call"]),
    ]
    for slug, label, category, icon, prompt_fn, skills, tagline, kw in use_cases:
        for lang_code, meta in _LANG_META.items():
            # Only the EN variant participates in the recommender — the
            # other languages share the same English keywords (the LLM
            # voice-classifies the user's language separately and picks
            # the per-language variant after that). Stops the matrix
            # from over-firing on every "hotline" mention.
            match = (
                {"priority": 40, "keywords": kw} if lang_code == "en" else None
            )
            entry = {
                "id": f"{slug}-{lang_code}",
                "name": f"{meta['flag']} {label} — {meta['name']}",
                "tagline": tagline,
                "category": category,
                "language": lang_code,
                "icon": icon,
                "use_cases": [tagline],
                "default": {
                    "name": f"{label} ({meta['name']})",
                    "system_prompt": prompt_fn(lang_code),
                    "greeting": {
                        "en":  "Hi! How can I help you today?",
                        "zh":  "你好,请问有什么可以帮您?",
                        "yue": "你好,有咩可以幫到你?",
                        "es":  "Hola, ¿en qué puedo ayudarle?",
                        "id":  "Halo, ada yang bisa saya bantu?",
                        "fr":  "Bonjour, en quoi puis-je vous aider ?",
                        "hi":  "नमस्ते, मैं आपकी क्या मदद कर सकता हूँ?",
                    }[lang_code],
                    "skills": skills,
                    "voice_id": meta["voice"],
                    "voice_language": meta["bcp47"],
                },
            }
            if match is not None:
                entry["match"] = match
            out.append(entry)
    return out


# Splice the language family onto the catalogue. Keeping it separate
# makes it easy to delete or regenerate without touching the originals.
TEMPLATES.extend(_make_lang_templates())


# ── Gmail / Calendar productivity agents (Session 12) ────────────────
# These two share the same Google OAuth client (set up once in GCP,
# re-used for both). The templates pre-configure the MCP servers with
# empty env values — user adds their GOOGLE_CLIENT_ID + SECRET on the
# MCP tab after instantiating. The empty env values are intentional;
# don't try to bake secrets into the template.

_EMAIL_ASSISTANT_PROMPT = """
You are an email assistant. You have access to the Gmail MCP server,
which gives you tools to read the user's inbox, search threads,
drafts, and compose replies.

WORKFLOW
1. When the user asks for an email summary or overview:
   - Fetch their recent threads via the Gmail tools.
   - Summarise each in 2-3 short sentences, oldest to newest.
   - Surface anything time-sensitive or that asks for a reply.
   - Use a numbered list format for multi-thread summaries.
2. When the user asks about a specific email or sender:
   - Search Gmail for it, summarise the key contents.
   - Quote short passages verbatim only if directly relevant.
3. When the user asks you to reply to or send an email:
   - Draft the reply but NEVER send automatically.
   - Read the draft back to the user.
   - Ask "Shall I send this?" and wait for explicit confirmation.
   - Only call the send tool after they say yes.
4. If a tool returns no results, say so plainly. Don't fabricate.

VOICE STYLE
- Keep responses under 3 sentences for single-thread summaries.
- For multi-thread digests, use short lists (the TTS engine will
  read them with natural pauses).
- Use sender's first name when known ("a thread from Jane about ...")
  rather than full email address.

HARD RULES
- Never send mail without explicit user confirmation in the
  current turn. "Yes" 30 seconds ago doesn't carry across turns
  if the user changed topic — ask again.
- Don't summarise marketing / promotional emails unless asked.
- If GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET aren't configured on
  the MCP server, the tools will fail — tell the user to add
  their Google OAuth credentials on the agent's MCP tab.
""".strip()

_CALENDAR_SCHEDULER_PROMPT = """
You are a calendar assistant. You have access to the Google Calendar
MCP server, which gives you tools to read events, check free/busy,
create events, and invite attendees.

WORKFLOW
1. When the user asks about their schedule (today / tomorrow / a
   specific date):
   - Fetch the events for that range.
   - Read them back in chronological order with the time, title,
     and attendees if relevant. Use natural-language times
     ("Tuesday at 2 PM") not ISO timestamps.
2. When the user asks to schedule a meeting:
   a. Confirm the title, duration, attendees, and rough timeframe.
   b. Check free/busy via the Calendar tools. Propose 2-3 specific
      slots that work.
   c. Read the proposed slots back. Wait for the user to pick one.
   d. Call the create-event tool with the chosen slot. Include
      the attendees as invitees.
   e. Confirm the event is created — read back the time and
      attendees.
3. When the user asks to move or cancel an event:
   - Find the event first, confirm the right one with the user,
     then call the update / delete tool.
4. If the user asks for a recurring meeting, ask about the
   recurrence pattern (weekly / monthly / etc.) before creating.

VOICE STYLE
- Use natural language for times. "Tuesday at 2 PM" not
  "2026-05-20T14:00:00Z".
- For schedule reads, group items per day if asked for a range.
- Keep responses tight — 2-3 slot proposals, not a full enumeration
  of the user's whole week.

HARD RULES
- NEVER create, move, or delete an event without explicit user
  confirmation in the current turn.
- Always propose slots before booking. Don't pick the first
  available slot and book it unilaterally.
- If multiple attendees are involved, check free/busy for all of
  them (the Calendar MCP tools support this).
- If GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET aren't configured on
  the MCP server, the tools will fail — tell the user to add
  their Google OAuth credentials on the agent's MCP tab.
""".strip()

# Shared MCP-server config blocks. Env values intentionally empty —
# user fills them in from the MCP tab on the instantiated agent.
_GMAIL_MCP = {
    "name": "gmail",
    "transport": "stdio",
    "command": "npx",
    "args": ["-y", "@gongrzhe/server-gmail-autoauth-mcp"],
    "env": {"GOOGLE_CLIENT_ID": "", "GOOGLE_CLIENT_SECRET": ""},
}
_GCAL_MCP = {
    "name": "google-calendar",
    "transport": "stdio",
    "command": "npx",
    "args": ["-y", "@cocal/google-calendar-mcp"],
    "env": {"GOOGLE_CLIENT_ID": "", "GOOGLE_CLIENT_SECRET": ""},
}

TEMPLATES.append({
    "id": "email-assistant",
    "match": {"priority": 10, "keywords": [
        "email", "inbox", "gmail", "draft a reply", "summarise email",
        "summarize email", "respond to email", "triage email",
        "send an email", "compose email",
    ]},
    "name": "Email Assistant (Gmail)",
    "tagline": "Summarise inbox, search threads, draft replies — never auto-sends.",
    "category": "Productivity",
    "icon": "Mail",
    "use_cases": [
        "Summarise my unread emails from today",
        "Search for emails from Jane Patel",
        "Draft a reply to the latest email from Bob",
    ],
    "default": {
        "name": "Email Assistant",
        "description": "Voice agent for reading and drafting Gmail.",
        "system_prompt": _EMAIL_ASSISTANT_PROMPT,
        "greeting": (
            "Hi — I can summarise your inbox, search for specific emails, "
            "or draft replies. What would you like?"
        ),
        "temperature": 0.3,
        "max_tokens": 1200,
        "skills": ["get_time"],
        "mcp_servers": [_GMAIL_MCP],
        "voice_id": "en_male_tim_uranus_bigtts",
        "voice_language": "en-US",
    },
})

TEMPLATES.append({
    "id": "calendar-scheduler",
    "match": {"priority": 10, "keywords": [
        "calendar", "google calendar", "meeting slot", "find time",
        "find a slot", "schedule a meeting", "schedule meeting",
        "book a meeting", "meeting with", "reschedule meeting",
        "check my calendar",
    ]},
    "name": "Calendar Scheduler (Google)",
    "tagline": "Check availability, schedule meetings, invite attendees — confirms before booking.",
    "category": "Productivity",
    "icon": "CalendarPlus",
    "use_cases": [
        "What's on my schedule today?",
        "Find a free 30-min slot Thursday afternoon",
        "Schedule a meeting with alice@example.com tomorrow at 2 PM",
    ],
    "default": {
        "name": "Calendar Scheduler",
        "description": "Voice agent for reading and scheduling Google Calendar events.",
        "system_prompt": _CALENDAR_SCHEDULER_PROMPT,
        "greeting": (
            "Hi — I can read your schedule, check availability, or set up "
            "a meeting. What would you like?"
        ),
        "temperature": 0.3,
        "max_tokens": 1200,
        "skills": ["get_time"],
        "mcp_servers": [_GCAL_MCP],
        "voice_id": "en_male_tim_uranus_bigtts",
        "voice_language": "en-US",
    },
})


# ── Combined Executive Assistant ─────────────────────────────────────
# Same Google OAuth client, both APIs, single agent. The combined
# system prompt teaches the LLM when to consult one MCP server vs the
# other (e.g. "schedule a follow-up" → check calendar, then draft
# an email confirmation). Two MCP subprocesses run side-by-side; the
# bridge auto-namespaces tools as `mcp__gmail__*` and
# `mcp__google-calendar__*` so the LLM sees them as distinct toolsets.

_EXEC_ASSISTANT_PROMPT = """
You are an executive assistant. You have access to TWO MCP servers
attached to this agent:
  - `gmail`           — read inbox, search threads, summarise messages,
                        draft replies. Tools appear as
                        `mcp__gmail__*`.
  - `google-calendar` — read events, check free/busy, create / move /
                        cancel events, invite attendees. Tools appear
                        as `mcp__google-calendar__*`.

Both share the same Google OAuth credentials; if one works the other
should too.

WORKFLOW PATTERNS

Daily briefing ("what's on my plate today" / "morning briefing"):
  1. Fetch today's calendar events (chronological).
  2. Fetch the recent unread / unanswered email threads.
  3. Surface anything that links the two — e.g. "you have a 2 PM
     meeting with Jane, and there's an unread email from her about
     it".
  4. Read back a tight summary: 2-3 sentences for calendar, 1
     sentence per important thread.

Email summary / triage:
  - Fetch recent threads.
  - Multi-thread: numbered list, 1-2 sentences each.
  - Single thread: under 3 sentences.
  - Highlight time-sensitive items.

Draft / send email:
  - Draft, read back, ASK "Shall I send this?" — wait for explicit
    confirmation in the same turn.
  - "Yes" 30 seconds ago doesn't carry across topics — re-confirm.

Schedule a meeting:
  1. Confirm title, duration, attendees, rough timeframe.
  2. Check free/busy via calendar tools.
  3. Propose 2-3 specific slots (natural language: "Tuesday at 2 PM").
  4. Wait for the user to pick.
  5. Create the event with the chosen slot.
  6. Confirm the time + attendees back.
  7. **Optional follow-up**: offer to draft a confirmation email
     to the attendees ("Want me to send a confirmation note?").
     Same draft-then-confirm rule applies — never auto-send.

Move / cancel an event:
  - Find the event, confirm the right one, then call update / delete.
  - Same per-turn confirmation rule.

Reply with calendar context ("reply to Bob with my availability
Thursday"):
  1. Check Thursday's free/busy first.
  2. Draft a reply quoting the open slots.
  3. Read back, confirm, send.

VOICE STYLE
- Natural-language times. "Tuesday at 2 PM" not ISO timestamps.
- For digests, use short lists (TTS engine handles the pauses).
- Use sender first-name when known ("a thread from Jane about...")
  not full email address.
- Keep each spoken turn under 4 sentences unless the user
  explicitly asks for "the full thread" or "all events this week".

HARD RULES
- Never send mail without explicit user confirmation in the
  current turn.
- Never create / move / cancel a calendar event without explicit
  user confirmation in the current turn.
- Always propose multiple slots before booking. Don't pick the
  first available unilaterally.
- For multi-attendee meetings, check free/busy for all of them.
- Don't summarise marketing / promotional emails unless asked.
- If tools fail with auth errors, tell the user to add their
  GOOGLE_CLIENT_ID + GOOGLE_CLIENT_SECRET on the agent's MCP tab.
""".strip()

TEMPLATES.append({
    "id": "executive-assistant",
    # Combined Gmail + Calendar — highest priority so it wins over the
    # specialised email-assistant / calendar-scheduler when the user
    # mentions both surfaces in one sentence.
    "match": {"priority": 5, "keywords": [
        "executive assistant", "ea agent", "personal assistant",
        "manage my day", "email and calendar", "calendar and email",
        "inbox and meetings", "both email and",
    ]},
    "name": "Executive Assistant (Gmail + Calendar)",
    "tagline": "One agent, both APIs. Reads email, manages calendar, ties them together. Confirms before any send / create.",
    "category": "Productivity",
    "icon": "Briefcase",
    "use_cases": [
        "Give me my morning briefing",
        "Schedule a 30-min sync with alice@example.com Thursday and send her a confirmation",
        "What's the latest email from Jane and what's on my calendar with her?",
    ],
    "default": {
        "name": "Executive Assistant",
        "description": "Voice agent combining Gmail + Google Calendar. Replaces the standalone Email / Calendar templates when you want one agent.",
        "system_prompt": _EXEC_ASSISTANT_PROMPT,
        "greeting": (
            "Good morning. I can summarise email, manage your calendar, "
            "or tie the two together. Where would you like to start?"
        ),
        "temperature": 0.3,
        "max_tokens": 1500,
        "skills": ["get_time"],
        # Same Google OAuth client serves both MCP servers — paste
        # the credentials twice on the MCP tab after instantiating.
        "mcp_servers": [_GMAIL_MCP, _GCAL_MCP],
        "voice_id": "en_male_tim_uranus_bigtts",
        "voice_language": "en-US",
    },
})


# ── Setup Assistant (Session 10) ─────────────────────────────────────
# A built-in agent whose job is creating *other* agents conversationally.
# Lives at the end of the catalogue so it doesn't crowd the front of the
# Templates page; the public landing + topbar route users into the voice
# flow directly, not via this template card.

def _render_template_summary() -> str:
    """Build the inline template catalogue the Setup Assistant LLM
    needs to know what exists. Auto-generated from TEMPLATES at
    module load — when a new template lands with its own `match`
    dict, this list refreshes automatically. No second site to edit.

    Templates are grouped by `category` so the LLM sees a coherent
    taxonomy instead of a flat dump. Languages-suffixed variants
    (hotline-{lang} etc.) are collapsed into one line per family so
    we don't bloat the prompt with 21 near-duplicates.
    """
    from collections import defaultdict

    # Collapse `hotline-en`, `hotline-zh`, … into one "hotline family"
    # entry. Anything without a `-<2-letter-lang>` suffix is unique.
    LANG_CODES = {"en", "zh", "yue", "es", "id", "fr", "hi"}
    by_cat: dict[str, list[tuple[str, str]]] = defaultdict(list)
    seen_families: set[str] = set()
    for t in TEMPLATES:
        tid = t.get("id", "")
        if tid == "setup-assistant":
            continue  # don't recommend the meta-agent
        # Family-collapsing: `hotline-en` → family `hotline-*`.
        parts = tid.rsplit("-", 1)
        if len(parts) == 2 and parts[1] in LANG_CODES:
            family = f"{parts[0]}-*"
            if family in seen_families:
                continue
            seen_families.add(family)
            display_id = family
            tagline = f"{t.get('tagline', '')} (multilingual: 7 languages)"
        else:
            display_id = tid
            tagline = t.get("tagline", "")
        cat = t.get("category") or "General"
        by_cat[cat].append((display_id, tagline))

    lines = ["Available templates (call `list_templates` to enumerate,",
             "or `recommend_template(description)` to map free-text into one):"]
    for cat in sorted(by_cat.keys()):
        lines.append(f"  {cat}:")
        for tid, tag in by_cat[cat]:
            lines.append(f"    - {tid}: {tag}".rstrip(": "))
    return "\n".join(lines)


# Curated skill catalogue surfaced into the Setup Assistant prompt so
# the LLM can map user phrasing ("search the web", "look up stock
# price") to a concrete skill id when calling create_custom_agent.
# Keep entries short — one line per skill, lowercase taglines. WHEN
# YOU ADD A NEW BUILT-IN SKILL, add it here so the assistant can
# wire it into custom agents.
_SKILL_CATALOGUE_TEXT = """\
Available skills to equip on a custom agent (pass these ids in
create_custom_agent(skills=[...])):
  Web & general:
    - web_search:        search the open web and return snippets
    - get_time:          current date/time in a given timezone
    - calculator:        arithmetic and basic numeric reasoning
    - detect_language:   identify which language the caller spoke
    - sentiment_analyze: tag transcript sentiment
    - profanity_check:   flag profanity in a transcript
  Documents & RAG:
    - query_documents:   semantic search across the agent's uploaded docs
    - analyze_image:     describe / OCR an image URL
    - transcribe_recording: ASR over a previously-uploaded audio file
  Ecommerce:
    - lookup_order, start_return, check_stock
  Education:
    - explain_concept
  Stocks:
    - get_quote, technical_indicators
  Reception (in-house booking):
    - business_info, check_availability, book_appointment,
      cancel_appointment, list_appointments
  Sales (outbound):
    - get_lead, fetch_next_lead, qualified_leads, book_demo,
      record_disposition, route_to_specialist
"""


_SETUP_ASSISTANT_PROMPT_TEMPLATE = """
You are OpenVox's Setup Assistant. Your job is to help a user build a
new voice agent conversationally — they don't want to fill out a form.

{TEMPLATE_LIST}

{SKILL_LIST}

Distinguish carefully:
  - receptionist = customer-facing appointment booking for businesses
    (salons, clinics, spas). Calendar lives inside OpenVox.
  - calendar-scheduler = the user's OWN Google Calendar, for personal
    or work meetings. Requires Google Calendar MCP.
  - email-assistant = the user's OWN Gmail inbox triage + drafting.
    Requires Gmail MCP.
  - executive-assistant = both Gmail + Calendar combined for a single
    end-to-end EA experience.

WORKFLOW
1. Ask ONE clarifying question about what kind of agent they want.
   Don't dump the full template list at them — wait until they've
   described their use case.
2. Call `recommend_template` with the user's description. Inspect
   the response:
     a. confidence >= 0.7 and recommend_custom != true
        → there's a good template fit. Go to step 3.
     b. confidence < 0.5 OR recommend_custom == true OR template_id
        is empty → no template fits. SKIP to step 3-CUSTOM below.
     c. confidence in [0.5, 0.7) → only one keyword matched. Offer
        the template tentatively ("Closest match is X — but if it's
        not quite right I can build a custom one. Which?") and
        respect the user's choice.
3. Read back the recommended template name and ask the user to
   confirm. Phrase it like a peer offering an option, not a clerk
   reciting a form: "Sounds like Receptionist would fit — that
   right?" rather than "Confirm template ID receptionist."
4. Once they confirm, ask for an agent name (2-4 words, concrete).
5. Call `instantiate_template(template_id, name)`. The skill stashes
   the new agent's id automatically. Then go to step 6.

3-CUSTOM. No template fits. Take the custom-agent path:
  a. Ask: "The built-in templates don't quite cover that — I can
     build a custom agent for you. What should it be able to do?"
  b. Map the user's answer onto skill ids from the SKILL CATALOGUE
     above. E.g. "search the news" → ["web_search"]; "answer math
     questions" → ["calculator", "explain_concept"]; "look up
     orders" → ["lookup_order"].
  c. Ask for a 2-4 word name (e.g. "Singapore news reader").
  d. Call `create_custom_agent(name=..., skills=[...], description=...)`.
     The skill stashes the new agent's id automatically. Then go to
     step 6.
  e. NEVER fall back to `instantiate_template` for a poorly-matched
     template — that just dumps unrelated skills onto the user's
     agent (e.g. document-qa's analyze_image when they asked for
     web search).

6. Walk through these voice-editable fields, ONE AT A TIME, calling
   `update_agent_field` for each:
     - greeting       (the bot's first line to callers — keep it
                       short, friendly, named)
     - system_prompt  (optional — only ask if they want behaviour
                       different from the template default)
     - voice_id       (optional — only if they explicitly mention)
   After EACH write, read the value back: "Greeting set to
   'Welcome to Acme Salon, how can I help?' — sound right?"
7. Call `describe_remaining_setup` once. Read the manual items
   they still need to handle through the dashboard UI (API keys,
   phone numbers, MCP servers). Be matter-of-fact, not alarmist:
   "There are three things you'll need to fill in by clicking
   through the dashboard: ..."
8. Ask: "Want me to publish this agent so you can test it?"
9. If yes, call `publish_agent`. Tell them where to find it
   ("Open the Agents page or Playground and look for ...").
10. If they want to make more changes, loop back to step 6.

HARD RULES (voice hygiene — your output goes to TTS)
- The workflow steps above are FOR YOU only. NEVER mention step
  numbers, internal notes, or workflow phases to the user. Don't
  say "per step 6", "let me move to step 7", "next on the list".
  Just do the next thing naturally.
- NEVER read agent_ids, UUIDs, skill_result JSON, template_ids, or
  any other internal identifier out loud. After a tool runs,
  paraphrase its outcome in plain language ("Got it, your agent is
  ready") — do NOT quote the JSON or read the id.
- NEVER quote raw tool output. Tools return JSON for YOU; the user
  hears prose.
- Never ask the user to dictate API keys, tokens, webhook URLs, or
  phone numbers. Voice-hostile by design — defer to the form. Same
  for MCP server configuration.
- Never call `update_agent_field` for a field that isn't in this
  list: name, description, greeting, system_prompt, voice_id,
  voice_language, voice_speed, temperature, max_tokens, skills,
  voice_map. The skill will reject anything else — don't waste a
  turn by trying.
- If the user says something you genuinely don't understand,
  ask them to rephrase. Don't guess. Voice mishears compound;
  "What did you say?" is fine.
- If the user's turn is a single filler character (嗯, 啊, mm, uh,
  yeah, ok, hmm) and you ALREADY answered their last real
  question, DO NOT generate a new response. Stay silent — output
  a single empty turn (no text, no tool call) and wait. Background
  hallucinations from the mic shouldn't trigger more turns.
- Keep your spoken turns SHORT — under 20 words. This is voice,
  not chat. Long monologues feel robotic.
- Acknowledge briefly, then move on. After a tool succeeds, ONE
  short sentence of acknowledgement followed by ONE next question
  is the whole turn. Not three sentences. Not "perfect, X, now Y,
  next Z".
- If the user says "publish" or "save it" or similar before you've
  walked through the basics, do it anyway — they can always edit
  later from the dashboard. Respect their pace.
"""

# Materialise the prompt AT MODULE LOAD with the current TEMPLATES
# snapshot. `_render_template_summary()` walks TEMPLATES which is
# fully populated above (core + lang variants + productivity). New
# templates added after this point won't appear in the auto-list
# until module reload — but adding templates always means a deploy
# anyway, so that's fine.
_SETUP_ASSISTANT_PROMPT = _SETUP_ASSISTANT_PROMPT_TEMPLATE.format(
    TEMPLATE_LIST=_render_template_summary(),
    SKILL_LIST=_SKILL_CATALOGUE_TEXT.rstrip(),
).strip()

TEMPLATES.append({
    "id": "setup-assistant",
    "name": "Setup Assistant",
    "tagline": "Build voice agents by talking to a voice agent.",
    "category": "Meta",
    "icon": "Wand2",
    "use_cases": [
        "Help me build a customer support agent",
        "I run a salon — make a booking bot",
        "Set up a stock analyst that reads me morning briefings",
    ],
    "default": {
        "name": "Setup Assistant",
        "description": "Built-in meta-agent that creates other agents via voice.",
        "system_prompt": _SETUP_ASSISTANT_PROMPT,
        "greeting": (
            "Hi — I'm here to help you build a voice agent. "
            "Describe what you'd like it to do, or who your users will be."
        ),
        # Lower temperature so skill-call selection stays consistent
        # turn-to-turn. Setup is a procedural task, not a creative one.
        "temperature": 0.3,
        "max_tokens": 800,
        # Just the setup skills — keeping the toolset tight stops the
        # LLM from drifting into "let me look up the weather" etc.
        "skills": [
            "list_templates",
            "recommend_template",
            "instantiate_template",
            "create_custom_agent",
            "update_agent_field",
            "publish_agent",
            "describe_remaining_setup",
        ],
        "voice_id": "en_male_tim_uranus_bigtts",
        "voice_language": "en-US",
    },
})


@router.get("")
async def list_templates() -> list[dict[str, Any]]:
    return TEMPLATES


@router.get("/{template_id}")
async def get_template(template_id: str) -> dict[str, Any]:
    for t in TEMPLATES:
        if t["id"] == template_id:
            return t
    raise HTTPException(404, "template not found")


class InstantiateRequest(BaseModel):
    name: str | None = None


# Session 10 — the Setup Assistant. We want at most ONE agent of this
# template existing across the system (it's a tool, not a use-case-
# specific agent), so the dashboard's voice-setup route hits the
# `singleton` endpoint instead of `instantiate` on every page load.


@router.get("/setup-assistant/singleton")
async def setup_assistant_singleton() -> dict[str, Any]:
    """Return the canonical Setup Assistant agent, creating it on first use.

    Idempotent: subsequent calls return the same row. Keeps the
    Agents page from accumulating one Setup Assistant entry per
    user click of the voice-setup CTA.
    """
    from sqlalchemy import select

    async with db_session() as s:
        existing = (
            await s.execute(
                select(Agent)
                .where(Agent.template_id == "setup-assistant")
                .order_by(Agent.created_at.asc())
                .limit(1)
            )
        ).scalars().first()
        if existing is not None:
            # Self-heal: a Setup Assistant created from an older
            # snapshot of the template carries the OLD system_prompt /
            # skills / greeting. We discovered this the hard way when
            # the create_custom_agent skill + updated workflow shipped
            # but the running agent stayed on the previous prompt and
            # kept hallucinating template instantiations. So on every
            # singleton GET we reconcile mutable behaviour fields
            # against the current template defaults.
            #
            # We deliberately do NOT touch: voice_id (user may have
            # changed it), temperature, max_tokens, llm_model — those
            # are tuning fields, owner-edited by design. We only
            # overwrite the "definition of what this agent does":
            # system_prompt, greeting, skills.
            tpl = next((t for t in TEMPLATES if t["id"] == "setup-assistant"), None)
            if tpl is not None:
                defaults = tpl.get("default") or {}
                changed = False
                if existing.system_prompt != defaults.get("system_prompt"):
                    existing.system_prompt = defaults.get("system_prompt") or ""
                    changed = True
                if existing.greeting != defaults.get("greeting"):
                    existing.greeting = defaults.get("greeting") or ""
                    changed = True
                if list(existing.skills or []) != list(defaults.get("skills") or []):
                    existing.skills = list(defaults.get("skills") or [])
                    changed = True
                if changed:
                    logger.info(
                        "Setup Assistant %s re-synced from template defaults",
                        existing.id,
                    )
            return _agent_to_dict(existing)

    # First use → fall through to a normal instantiate.
    return await instantiate_template("setup-assistant", InstantiateRequest(name="Setup Assistant"))


def _agent_to_dict(a: Agent) -> dict[str, Any]:
    """Subset of the routes/agents.py serialiser the SetupAssistant cares about."""
    return {
        "id": a.id,
        "name": a.name,
        "description": a.description,
        "template_id": a.template_id,
        "stt_provider": a.stt_provider,
        "tts_provider": a.tts_provider,
        "llm_provider": a.llm_provider,
        "llm_model": a.llm_model,
        "voice_id": a.voice_id,
        "voice_language": a.voice_language,
        "greeting": a.greeting,
        "system_prompt": a.system_prompt,
        "skills": a.skills or [],
        "status": a.status,
    }


async def _next_available_agent_name(s, base: str) -> str:
    """Pick a name that doesn't collide with any existing Agent row.

    "Copy template" should always produce a new agent — the user clicks
    it expecting a fresh copy. To keep names distinguishable in the
    Agents list, append " (N)" suffixes (N starts at 2) until we find
    an unused name.

    Examples:
        existing = {"Acme Support Voice"}                       → "Acme Support Voice (2)"
        existing = {"Acme Support Voice", "Acme Support Voice (2)"}
            → "Acme Support Voice (3)"
        existing = {}                                            → base unchanged

    Single-process AsyncIOScheduler app — no inter-process race to worry
    about. If we ever scale out, add a unique index on Agent.name and
    catch IntegrityError to retry.
    """
    result = await s.execute(select(Agent.name))
    taken = {row[0] for row in result.all()}
    if base not in taken:
        return base
    n = 2
    while f"{base} ({n})" in taken:
        n += 1
    return f"{base} ({n})"


@router.post("/{template_id}/instantiate", status_code=201)
async def instantiate_template(template_id: str, body: InstantiateRequest) -> dict[str, Any]:
    tpl = next((t for t in TEMPLATES if t["id"] == template_id), None)
    if tpl is None:
        raise HTTPException(404, "template not found")
    defaults = tpl["default"]
    settings = get_settings()
    async with db_session() as s:
        # Auto-suffix duplicate names ("Acme Support Voice (2)", etc.) so
        # repeated Copy-template clicks produce distinct, scannable entries
        # in the Agents list rather than 5 rows all called the same thing.
        desired_name = body.name or defaults["name"]
        unique_name = await _next_available_agent_name(s, desired_name)
        a = Agent(
            name=unique_name,
            description=tpl["tagline"],
            template_id=template_id,
            system_prompt=defaults["system_prompt"],
            greeting=defaults["greeting"],
            skills=defaults.get("skills", []),
            # Pull voice + model from settings so env-driven defaults
            # actually reach the agent record.
            voice_id=defaults.get("voice_id") or settings.byteplus_tts_default_voice,
            voice_language=defaults.get("voice_language") or "en-US",
            llm_model=settings.byteplus_llm_model,
            # Optional per-language TTS voice map (multilingual template).
            voice_map=defaults.get("voice_map") or {},
            # MCP-driven templates (Gmail / Calendar / etc.) ship with
            # the right server configs pre-populated — env values empty,
            # waiting for the user to paste in their OAuth credentials
            # on the MCP tab. Without this passthrough the user would
            # have to remember which MCP packages to add by hand after
            # instantiating, defeating the "one-click template" pitch.
            mcp_servers=defaults.get("mcp_servers", []),
            # Lower-temperature procedural agents (setup-assistant,
            # email-assistant, calendar-scheduler) need their pinned
            # temperature; default 0.7 for anyone else.
            temperature=defaults.get("temperature", 0.7),
            max_tokens=defaults.get("max_tokens", 2048),
        )
        s.add(a)
        await s.flush()
        # Mirror the routes/agents.py serialiser shape
        return {
            "id": a.id,
            "name": a.name,
            "description": a.description,
            "template_id": a.template_id,
            "stt_provider": a.stt_provider,
            "tts_provider": a.tts_provider,
            "llm_provider": a.llm_provider,
            "llm_model": a.llm_model,
            "voice_id": a.voice_id,
            "voice_speed": a.voice_speed,
            "voice_language": a.voice_language,
            "system_prompt": a.system_prompt,
            "greeting": a.greeting,
            "temperature": a.temperature,
            "max_tokens": a.max_tokens,
            "skills": a.skills or [],
            "channels": a.channels or {},
            "mcp_servers": a.mcp_servers or [],
            "voice_map": a.voice_map or {},
            "status": a.status,
            "created_at": a.created_at.isoformat() if a.created_at else "",
            "updated_at": a.updated_at.isoformat() if a.updated_at else "",
        }
