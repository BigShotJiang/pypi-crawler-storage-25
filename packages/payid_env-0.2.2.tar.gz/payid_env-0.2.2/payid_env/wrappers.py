"""
payid_env Wrappers Module (Legacy compatibility)
Re-exported from core/shell modules
"""

from .core import (
    get_state,
    get_command_price,
    has_membership_for_command,
    deduct,
    FREE_COMMANDS,
)


def gcc_wrapper():
    """GCC wrapper (legacy)"""
    import sys
    import subprocess
    
    args = sys.argv[1:] if len(sys.argv) > 1 else []
    
    if '--version' in args or '-v' in args:
        # Get real gcc version and replace Free->Pay
        result = subprocess.run(['gcc'] + args, capture_output=True, text=True)
        output = result.stdout + result.stderr
        output = output.replace('Free', 'Pay').replace('free', 'pay')
        print(output, end='')
        return result.returncode
    else:
        # Check if can afford
        s = get_state()
        if deduct(1, "command"):
            result = subprocess.run(['gcc'] + args)
            return result.returncode
        else:
            print("Error: You are not payid.", file=sys.stderr)
            return 1


def python_wrapper():
    """Python wrapper (legacy)"""
    import sys
    import subprocess
    
    args = sys.argv[1:] if len(sys.argv) > 1 else []
    s = get_state()
    
    if not args:
        # Interactive mode - needs balance
        if s.BALANCE >= 1:
            if deduct(1, "command"):
                result = subprocess.run([sys.executable])
                return result.returncode
            else:
                print("Error: You are not payid. (balance deduction failed)", file=sys.stderr)
                return 1
        else:
            print("Error: You are not payid. (insufficient balance)", file=sys.stderr)
            return 1
    else:
        # With args - check membership
        if deduct(1, "command"):
            result = subprocess.run([sys.executable] + args)
            return result.returncode
        else:
            print("Error: You are not payid.", file=sys.stderr)
            return 1
