"""
payid_env Shell Module - Interactive PayShell with embedded Bash
Version 0.2.2 - Fixed terminal handling and exit formatting
"""

import os
import sys
import time
import select
import subprocess
import pty
import termios
import tty

from .core import (
    get_state,
    apply_replacements,
    check_breath_tax,
    get_command_price,
    has_membership_for_command,
    deduct, add, buy_pass,
    show_pass_list, show_shop,
    show_tax_status, toggle_tax,
    show_exit_bill, get_exit_penalty,
    FREE_COMMANDS, PIPE_TAX, REDIRECT_TAX,
    count_pipes_and_redirects, extract_command
)


class PayShell:
    """PayShell - Bash wrapper with paywall economy"""
    
    def __init__(self):
        self.bash_process = None
        self.running = False
        self.master_fd = None
        self.is_tty = False
        self.old_tty = None
        
    def restore_tty(self):
        """Restore terminal to cooked mode"""
        if self.is_tty and self.old_tty is not None:
            try:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_tty)
            except:
                pass
    
    def set_raw_tty(self):
        """Set terminal to raw mode"""
        if self.is_tty:
            try:
                tty.setraw(sys.stdin.fileno())
            except:
                pass
        
    def process_command(self, cmdline):
        """Process command through PayShell payment logic"""
        s = get_state()
        
        cmdline = cmdline.strip()
        if not cmdline:
            return True, ""
        
        # Update breath tax
        check_breath_tax()
        
        # Handle PayShell builtin commands (these don't go to bash)
        if cmdline == 'balance':
            os.write(sys.stdout.fileno(), f"\r\nBalance: {s.BALANCE} coins\r\n".encode())
            return False, ""
        
        if cmdline == 'pass_list':
            self.restore_tty()
            show_pass_list()
            self.set_raw_tty()
            return False, ""
        
        if cmdline == 'shop':
            self.restore_tty()
            show_shop()
            self.set_raw_tty()
            return False, ""
        
        if cmdline == 'tax_status':
            self.restore_tty()
            show_tax_status()
            self.set_raw_tty()
            return False, ""
        
        if cmdline == 'tax_toggle':
            self.restore_tty()
            toggle_tax()
            self.set_raw_tty()
            return False, ""
        
        if cmdline.startswith('buy_pass '):
            parts = cmdline.split(maxsplit=1)
            if len(parts) > 1:
                self.restore_tty()
                if buy_pass(parts[1]):
                    print(f"Purchased {parts[1]} membership!")
                else:
                    print("Purchase failed: insufficient funds or invalid pass")
                sys.stdout.flush()
                self.set_raw_tty()
            return False, ""
        
        # Count pipes and redirects
        pipes, redirects = count_pipes_and_redirects(cmdline)
        cmd = extract_command(cmdline)
        
        # Free builtins don't cost anything
        if cmd in FREE_COMMANDS:
            return True, cmdline
        
        # Calculate total cost
        cmd_cost = get_command_price(cmd) if cmd else 0
        pipe_cost = pipes * PIPE_TAX
        redirect_cost = redirects * REDIRECT_TAX
        total = cmd_cost + pipe_cost + redirect_cost
        
        # Check if user can afford
        if total > 0:
            if s.BALANCE < total:
                os.write(sys.stdout.fileno(), f"\r\n❌ Insufficient funds: need {total} coins, have {s.BALANCE}\r\n".encode())
                return False, ""
            
            # Deduct costs
            if cmd_cost > 0:
                deduct(cmd_cost, "command")
            if pipe_cost > 0:
                deduct(pipe_cost, "pipe")
            if redirect_cost > 0:
                deduct(redirect_cost, "redirect")
            
            os.write(sys.stdout.fileno(), f"\r\n💰 Charged {total} coins\r\n".encode())
            os.write(sys.stdout.fileno(), f"   Remaining: {s.BALANCE} coins\r\n".encode())
        
        return True, cmdline
    
    def filter_output(self, data):
        """Filter output through PayShell text replacements"""
        if not data:
            return data
        
        try:
            text = data.decode('utf-8', errors='replace')
            text = apply_replacements(text)
            return text.encode('utf-8')
        except:
            return data
    
    def run(self):
        """Run PayShell with embedded real bash"""
        s = get_state()
        
        # Create PTY for bash
        master, slave = pty.openpty()
        self.master_fd = master
        
        # Set up environment
        env = os.environ.copy()
        env['PAYSHELL'] = '1'
        
        # Start bash process with setsid for proper job control
        self.bash_process = subprocess.Popen(
            ['/bin/bash', '-i'],
            stdin=slave,
            stdout=slave,
            stderr=slave,
            env=env,
            preexec_fn=os.setsid
        )
        
        os.close(slave)
        
        # Terminal setup
        self.is_tty = sys.stdin.isatty()
        self.old_tty = None
        
        if self.is_tty:
            try:
                self.old_tty = termios.tcgetattr(sys.stdin)
                tty.setraw(sys.stdin.fileno())
            except:
                self.is_tty = False
        
        self.running = True
        command_line = ""
        
        try:
            while self.running:
                readable, _, _ = select.select([master, sys.stdin], [], [], 0.05)
                
                # Periodic breath tax check
                check_breath_tax()
                
                # Handle bash output
                if master in readable:
                    try:
                        data = os.read(master, 4096)
                        if data:
                            filtered = self.filter_output(data)
                            sys.stdout.buffer.write(filtered)
                            sys.stdout.flush()
                        else:
                            # EOF from PTY - check if bash is still running
                            if self.bash_process.poll() is not None:
                                break
                            # Otherwise continue, might be temporary
                            time.sleep(0.01)
                            continue
                    except OSError:
                        break
                
                # Handle user input
                if sys.stdin in readable:
                    try:
                        char = sys.stdin.read(1)
                        
                        if not char:  # EOF on stdin
                            continue
                        
                        if char in ('\r', '\n'):
                            # ENTER pressed - send newline to bash first
                            os.write(master, b'\n')
                            
                            # Then process payment
                            should_send, processed = self.process_command(command_line)
                            
                            # If we blocked the command, send a comment to bash
                            if not should_send:
                                os.write(master, b'# payshell-blocked\n')
                            
                            command_line = ""
                            
                        elif char == '\x03':  # Ctrl+C
                            os.write(master, b'\x03')
                            command_line = ""
                            
                        elif char == '\x04':  # Ctrl+D - just forward to bash, don't intercept
                            os.write(master, b'\x04')
                            command_line = ""
                            
                        elif char == '\x7f':  # Backspace
                            if command_line:
                                command_line = command_line[:-1]
                            os.write(master, b'\x7f')
                            
                        elif ord(char) >= 32 or char == '\t':  # Printable or tab
                            command_line += char
                            os.write(master, char.encode())
                            
                    except OSError:
                        break
                        
        finally:
            # Show final bill before restoring terminal
            s = get_state()
            penalty = get_exit_penalty()
            if penalty > 0 and s.BALANCE >= penalty:
                deduct(penalty, "exit")
            
            # Drain remaining output from PTY
            try:
                while True:
                    ready, _, _ = select.select([master], [], [], 0.5)
                    if not ready:
                        break
                    data = os.read(master, 4096)
                    if not data:
                        break
                    filtered = self.filter_output(data)
                    sys.stdout.buffer.write(filtered)
                    sys.stdout.flush()
            except:
                pass
            
            # Restore terminal before printing bill
            self.restore_tty()
            
            # Show the final bill
            show_exit_bill()
            
            # Cleanup bash process
            if self.bash_process:
                self.bash_process.terminate()
                try:
                    self.bash_process.wait(timeout=1)
                except:
                    self.bash_process.kill()
            
            try:
                os.close(master)
            except:
                pass


def main():
    """Entry point for payid_env"""
    shell = PayShell()
    shell.run()
