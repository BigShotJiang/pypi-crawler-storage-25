"""
payid_env CLI Module - Command line interface
"""

import sys

from .core import (
    get_state,
    add,
    buy_pass,
    show_pass_list,
    show_shop,
    show_tax_status,
    toggle_tax,
    show_exit_bill,
    get_exit_penalty
)


def print_setup():
    """Output shell wrapper functions"""
    setup_script = '''
# PayShell environment setup
export PATH="/usr/local/bin:$PATH"
'''
    print(setup_script)


def main():
    """Command line entry point for payid command"""
    s = get_state()
    
    if len(sys.argv) < 2:
        # No arguments - print help
        print("PayID Shell 0.2.0")
        print("Commands: pay, balance, setup, status, shop, pass_list")
        return
    
    command = sys.argv[1]
    
    if command == "pay":
        # Add 3 coins
        new_balance = add(3)
        print(f"Added 3 coins. Current balance: {new_balance}")
    
    elif command == "balance":
        # Show balance
        print(f"Current balance: {s.BALANCE}")
    
    elif command == "setup":
        # Output shell setup
        print_setup()
    
    elif command == "status":
        # Show status
        print(f"PayShell Status:")
        print(f"  Balance: {s.BALANCE}")
        print(f"  Breath tax: {'ON' if s.BREATH_TAX_ENABLED else 'OFF'}")
    
    elif command == "shop":
        # Show shop
        show_shop()
    
    elif command == "pass_list":
        # Show memberships
        show_pass_list()
    
    elif command == "buy_pass" and len(sys.argv) > 2:
        # Buy membership
        if buy_pass(sys.argv[2]):
            print(f"Purchased {sys.argv[2]} membership!")
        else:
            print("Purchase failed")
    
    else:
        print(f"Unknown command: {command}")
        print("Commands: pay, balance, setup, status, shop, pass_list, buy_pass")
