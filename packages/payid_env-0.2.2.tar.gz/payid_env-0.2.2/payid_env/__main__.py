#!/usr/bin/env python3
"""payid_env entry point"""
from payid_env.shell import main

if __name__ == '__main__':
    main()
