"""
payid_env 0.2.1 - PayShell Satirical Shell Environment
Copyright (C) 2025 PayShell Authors
GPLv3+ Licensed
"""

__version__ = "0.2.1"

from .core import (
    get_state,
    apply_replacements,
    check_breath_tax,
    get_command_price,
    has_membership_for_command,
    deduct,
    add,
    buy_pass,
    show_pass_list,
    show_shop,
    show_tax_status,
    toggle_tax,
    show_exit_bill,
    get_exit_penalty,
    FREE_COMMANDS,
    BASIC_COMMANDS,
    DEV_COMMANDS,
    NET_COMMANDS,
    PRO_COMMANDS,
    PIPE_TAX,
    REDIRECT_TAX,
)

from .shell import PayShell

__all__ = [
    '__version__',
    'get_state',
    'apply_replacements',
    'check_breath_tax',
    'get_command_price',
    'has_membership_for_command',
    'deduct',
    'add',
    'buy_pass',
    'show_pass_list',
    'show_shop',
    'show_tax_status',
    'toggle_tax',
    'show_exit_bill',
    'get_exit_penalty',
    'FREE_COMMANDS',
    'BASIC_COMMANDS',
    'DEV_COMMANDS',
    'NET_COMMANDS',
    'PRO_COMMANDS',
    'PIPE_TAX',
    'REDIRECT_TAX',
    'PayShell',
]
