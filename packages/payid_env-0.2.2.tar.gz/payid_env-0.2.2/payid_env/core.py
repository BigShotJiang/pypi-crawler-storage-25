"""
payid_env Core Module - PayShell Economy System
Embeds real bash and intercepts all output for satirical "Pay" replacements
"""

import os
import sys
import time
import re

# Global state class for proper mutability
class PayShellState:
    def __init__(self):
        self.BALANCE = 20
        self.SESSION_START = time.time()
        self.BREATH_TAX_ENABLED = True
        self.PIPE_TAX = 2
        self.REDIRECT_TAX = 1
        self.MEMBERSHIP_FLAGS = 0
        
        # Accounting totals
        self.TOTAL_BREATH_TAX = 0
        self.TOTAL_COMMAND_TAX = 0
        self.TOTAL_PIPE_TAX = 0
        self.TOTAL_REDIRECT_TAX = 0
        
        # Breath tracking
        self.last_breath_check = self.SESSION_START

# Global state instance
_state = PayShellState()

# Module-level constants for import
BALANCE = _state.BALANCE
SESSION_START = _state.SESSION_START
BREATH_TAX_ENABLED = _state.BREATH_TAX_ENABLED
PIPE_TAX = _state.PIPE_TAX
REDIRECT_TAX = _state.REDIRECT_TAX
MEMBERSHIP_FLAGS = _state.MEMBERSHIP_FLAGS
TOTAL_BREATH_TAX = _state.TOTAL_BREATH_TAX
TOTAL_COMMAND_TAX = _state.TOTAL_COMMAND_TAX
TOTAL_PIPE_TAX = _state.TOTAL_PIPE_TAX
TOTAL_REDIRECT_TAX = _state.TOTAL_REDIRECT_TAX

# Membership tier flags
TIER_BASIC = 0x01
TIER_DEV = 0x02
TIER_NET = 0x04
TIER_PRO = 0x08
TIER_UNLIMITED = 0x10

# Command groups by membership tier
BASIC_COMMANDS = ['ls', 'cat', 'grep', 'wc', 'head', 'tail', 'sort', 'uniq']
DEV_COMMANDS = ['gcc', 'g++', 'python', 'python3', 'make', 'git', 'cc', 'clang']
NET_COMMANDS = ['curl', 'wget', 'ping', 'ssh', 'scp', 'nc', 'netcat', 'dig']
PRO_COMMANDS = ['sudo', 'rm', 'kill', 'pkill', 'chmod', 'chown']

# Free builtins - never charged
FREE_COMMANDS = [
    'cd', 'pwd', 'echo', 'exit', 'logout',
    'balance', 'buy_pass', 'pass_list', 'shop',
    'tax_status', 'tax_toggle', 'help',
    'type', 'declare', 'export', 'unset', 'alias',
    'unalias', 'source', '.', 'test', '[', 'return',
    'shift', 'builtin', 'command', 'enable', 'eval',
    'set', 'shopt', 'bind', 'builtin', 'caller',
    'exec', 'hash', 'mapfile', 'printf', 'read',
    'readarray', 'readonly', 'times', 'trap', 'true',
    'false', 'wait', 'let', 'local', 'pushd', 'popd', 'dirs'
]

# Membership prices (in coins)
PASS_PRICES = {
    'Basic': 50,
    'Dev': 150,
    'Net': 100,
    'Pro': 300,
    'Unlimited': 1000
}

# Text replacements for satirical output
REPLACEMENTS = [
    (r'Free Software Foundation', 'Pay Software Foundation'),
    (r'free software', 'pay software'),
    (r'Free', 'Pay'),
    (r'free', 'pay'),
    (r'ERROR', 'TRANSACTION FAILED'),
    (r'Error', 'Transaction failed'),
    (r'error', 'transaction failed'),
    (r'SUCCESS', 'PAYMENT PROCESSED'),
    (r'Success', 'Payment processed'),
    (r'success', 'payment processed'),
    (r'WARNING', 'BILLING ALERT'),
    (r'Warning', 'Billing alert'),
    (r'warning', 'billing alert'),
    (r'Permission denied', 'Insufficient funds'),
    (r'permission denied', 'insufficient funds'),
    (r'Not found', 'Subscription expired'),
    (r'not found', 'subscription expired'),
    (r'command not found', 'subscription expired'),
    (r'No such file', 'Subscription expired'),
]


def get_state():
    """Get the global PayShell state"""
    return _state


def apply_replacements(text):
    """Apply satirical text replacements to output"""
    for pattern, replacement in REPLACEMENTS:
        text = re.sub(pattern, replacement, text)
    return text


def check_breath_tax():
    """Check and apply breath tax (1 coin per 10 seconds)"""
    s = get_state()
    if not s.BREATH_TAX_ENABLED:
        return
    
    elapsed = time.time() - s.SESSION_START
    breaths = int(elapsed / 10)
    cost = breaths - s.TOTAL_BREATH_TAX
    
    if cost > 0 and s.BALANCE >= cost:
        s.BALANCE -= cost
        s.TOTAL_BREATH_TAX += cost


def get_command_price(cmd):
    """Get price for executing a command (in coins)"""
    s = get_state()
    if cmd in FREE_COMMANDS:
        return 0
    if s.MEMBERSHIP_FLAGS & TIER_UNLIMITED:
        return 0
    if has_membership_for_command(cmd):
        return 0
    return 1


def has_membership_for_command(cmd):
    """Check if user has membership for specified command"""
    s = get_state()
    if s.MEMBERSHIP_FLAGS & TIER_UNLIMITED:
        return True
    if (s.MEMBERSHIP_FLAGS & TIER_BASIC) and cmd in BASIC_COMMANDS:
        return True
    if (s.MEMBERSHIP_FLAGS & TIER_DEV) and cmd in DEV_COMMANDS:
        return True
    if (s.MEMBERSHIP_FLAGS & TIER_NET) and cmd in NET_COMMANDS:
        return True
    if (s.MEMBERSHIP_FLAGS & TIER_PRO) and cmd in PRO_COMMANDS:
        return True
    return False


def deduct(amount, reason=""):
    """Deduct coins from balance, returns True on success"""
    s = get_state()
    
    if s.BALANCE < amount:
        return False
    
    s.BALANCE -= amount
    
    if reason == "command":
        s.TOTAL_COMMAND_TAX += amount
    elif reason == "pipe":
        s.TOTAL_PIPE_TAX += amount
    elif reason == "redirect":
        s.TOTAL_REDIRECT_TAX += amount
    elif reason == "breath":
        s.TOTAL_BREATH_TAX += amount
    
    return True


def add(amount):
    """Add coins to balance, returns new balance"""
    s = get_state()
    s.BALANCE += amount
    return s.BALANCE


def buy_pass(name):
    """Buy a membership pass by name, returns True on success"""
    s = get_state()
    
    name = name.capitalize()
    if name not in PASS_PRICES:
        return False
    
    price = PASS_PRICES[name]
    if s.BALANCE < price:
        return False
    
    s.BALANCE -= price
    
    if name == 'Basic':
        s.MEMBERSHIP_FLAGS |= TIER_BASIC
    elif name == 'Dev':
        s.MEMBERSHIP_FLAGS |= TIER_DEV
    elif name == 'Net':
        s.MEMBERSHIP_FLAGS |= TIER_NET
    elif name == 'Pro':
        s.MEMBERSHIP_FLAGS |= TIER_PRO
    elif name == 'Unlimited':
        s.MEMBERSHIP_FLAGS |= TIER_UNLIMITED
    
    return True


def show_pass_list():
    """Display list of owned memberships"""
    s = get_state()
    print("Your memberships:")
    if s.MEMBERSHIP_FLAGS == 0:
        print("  (none)")
        return
    
    if s.MEMBERSHIP_FLAGS & TIER_BASIC:
        print("  [Basic] - ls, cat, grep, wc")
    if s.MEMBERSHIP_FLAGS & TIER_DEV:
        print("  [Dev] - gcc, python, make, git")
    if s.MEMBERSHIP_FLAGS & TIER_NET:
        print("  [Net] - curl, wget, ping, ssh")
    if s.MEMBERSHIP_FLAGS & TIER_PRO:
        print("  [Pro] - sudo, rm, kill")
    if s.MEMBERSHIP_FLAGS & TIER_UNLIMITED:
        print("  [Unlimited] - ALL commands")


def show_shop():
    """Display membership shop with prices"""
    s = get_state()
    print("=== PayShell Membership Shop ===")
    print(f"Basic     - {PASS_PRICES['Basic']} coins  - ls, cat, grep, wc")
    print(f"Dev       - {PASS_PRICES['Dev']} coins  - gcc, python, make, git")
    print(f"Net       - {PASS_PRICES['Net']} coins  - curl, wget, ping, ssh")
    print(f"Pro       - {PASS_PRICES['Pro']} coins  - sudo, rm, kill")
    print(f"Unlimited - {PASS_PRICES['Unlimited']} coins  - ALL commands")
    print("==================================")
    print(f"Your balance: {s.BALANCE} coins")


def show_tax_status():
    """Display current tax status"""
    s = get_state()
    print("Tax Status:")
    print(f"  Breath tax: {'ON' if s.BREATH_TAX_ENABLED else 'OFF'}")
    print(f"  Pipe tax: {s.PIPE_TAX} coins per '|'")
    print(f"  Redirect tax: {s.REDIRECT_TAX} coins per '>'")
    print(f"  Current balance: {s.BALANCE} coins")


def toggle_tax():
    """Toggle breath tax (costs 5 coins)"""
    s = get_state()
    cost = 5
    
    if s.BALANCE < cost:
        print(f"Insufficient funds to toggle tax (need {cost} coins)")
        return
    
    s.BALANCE -= cost
    s.BREATH_TAX_ENABLED = not s.BREATH_TAX_ENABLED
    
    if s.BREATH_TAX_ENABLED:
        print(f"Breath tax ENABLED. Cost: {cost} coins")
    else:
        print(f"Breath tax DISABLED. Cost: {cost} coins")


def show_exit_bill():
    """Display final bill on exit - called after terminal is restored"""
    s = get_state()
    session_seconds = int(time.time() - s.SESSION_START)
    exit_penalty = session_seconds // 10
    
    total = (s.TOTAL_BREATH_TAX + s.TOTAL_COMMAND_TAX + 
             s.TOTAL_PIPE_TAX + s.TOTAL_REDIRECT_TAX + exit_penalty)
    
    print()
    print("=== PayShell Final Bill ===")
    print(f"Session duration: {session_seconds} seconds")
    print()
    print("Charges:")
    print(f"  Breath tax:     {s.TOTAL_BREATH_TAX} coins")
    print(f"  Command tax:    {s.TOTAL_COMMAND_TAX} coins")
    print(f"  Pipe tax:       {s.TOTAL_PIPE_TAX} coins")
    print(f"  Redirect tax:   {s.TOTAL_REDIRECT_TAX} coins")
    print(f"  Exit penalty:   {exit_penalty} coins")
    print()
    print(f"Total: {total} coins")
    print(f"Remaining balance: {s.BALANCE} coins")
    
    if exit_penalty > s.BALANCE:
        print("WARNING: Insufficient funds for exit penalty!")
    
    print("===========================")
    print()


def get_exit_penalty():
    """Calculate exit penalty based on session duration"""
    s = get_state()
    session_seconds = int(time.time() - s.SESSION_START)
    return session_seconds // 10


def count_pipes_and_redirects(cmdline):
    """Count pipes and redirects in command line for taxation"""
    pipes = cmdline.count('|')
    redirects = cmdline.count('>') + cmdline.count('<')
    return pipes, redirects


def extract_command(cmdline):
    """Extract main command from command line"""
    cmdline = cmdline.strip()
    if not cmdline:
        return None
    
    parts = cmdline.split()
    if not parts:
        return None
    
    cmd = parts[0]
    # Strip function calls like exit() → exit
    if '(' in cmd:
        cmd = cmd.split('(')[0]
    
    if cmd.startswith('./'):
        cmd = cmd[2:]
    
    return cmd
