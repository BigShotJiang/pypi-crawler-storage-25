"""
payid_env Balance Module (Legacy compatibility)
Re-exported from core module
"""

from .core import (
    get_state,
    add as add_balance,
    deduct as deduct_balance,
)


def get_balance():
    """Get current balance (legacy)"""
    s = get_state()
    return s.BALANCE
