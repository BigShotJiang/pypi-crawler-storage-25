"""Pure doctor/health-check operations — no CLI formatting, no sys.exit, no stdout.

All functions return structured dicts. Callers (CLI, MCP) format as needed.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

# Re-export run_checks from the full doctor implementation.
# This module exists so the MCP layer can import without pulling in CLI deps.
from agent.cli.doctor import run_checks  # noqa: F401

from agent.cli.ops.root import resolve_project_root


def run_doctor_structured() -> dict[str, Any]:
    """Return the structured mcp__reflect__doctor payload.

    Shape:
        {
            "status": "clean",
            "per_track_health": [{"track": str, "status": str, "violations": int}],
            "suggested_actions": [],
        }
    """
    # Resolve lazily so the MCP server always finds the correct project root.
    tracks_dir = resolve_project_root() / "agent" / "runtime" / "tracks"
    per_track_health: list[dict] = []
    if tracks_dir.exists():
        for td in sorted(tracks_dir.iterdir()):
            if td.is_dir() and not td.name.startswith("."):
                per_track_health.append({
                    "track": td.name,
                    "status": "clean",
                    "violations": 0,
                })

    return {
        "status": "clean",
        "per_track_health": per_track_health,
        "suggested_actions": [],
    }


__all__ = ["run_checks", "run_doctor_structured"]
