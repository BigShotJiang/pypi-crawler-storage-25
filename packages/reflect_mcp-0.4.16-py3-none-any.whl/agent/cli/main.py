"""reflect CLI entry point."""
from __future__ import annotations

import os
from enum import Enum
from pathlib import Path
from types import SimpleNamespace
from typing import Optional

import typer
from typing_extensions import Annotated

# ── Shared install snippet ────────────────────────────────────────────────────
#
# Surfaced at the top level (`reflect -h` epilog), on the dispatch subcommand
# (`reflect dispatch -h`), and printed after `reflect init` completes. Keep
# in sync with REFLECT_SETUP.md if either changes substantively.

CRONTAB_INSTALL = """\
Install the wake schedule via `crontab -e`. Pick one of two auth paths.

Subscription path. Wakes bill against a Claude Max subscription via the local
OAuth proxy. Run `reflect proxy` as a long-lived daemon separately (reads
~/.claude/.credentials.json):

  * * * * * cd /absolute/path/to/this/project && reflect dispatch >> /tmp/reflect-dispatch.log 2>&1

⚠  Routing automated headless wake traffic through the Claude Max
   subscription uses technically valid auth (your own token), but the
   legitimacy of the use case depends entirely on what you're using it for:

   - Personal, hobbyist, exploratory, or local-dev use: plausibly
     defensible. You're using your own subscription for your own work,
     just through a different client surface.
   - Production deployment, commercial use, anything customer-facing, or
     anything resembling automated business logic at scale: the API path
     is absolutely required. Routing production completions through a
     Claude Max subscription is an unambiguous violation of Anthropic's
     Claude Max terms of service. Don't do it.

   When in doubt, use the API path.

API path. Wakes bill directly against the Anthropic API. Set the key at
agent/secrets/anthropic.api_key and set REFLECT_USE_API=1:

  * * * * * cd /absolute/path/to/this/project && export ANTHROPIC_API_KEY="$(cat agent/secrets/anthropic.api_key)" REFLECT_USE_API=1 && reflect dispatch >> /tmp/reflect-dispatch.log 2>&1

Replace the path with this project's actual root. See REFLECT_SETUP.md for
the full setup walkthrough.
"""

# ── App tree ──────────────────────────────────────────────────────────────────
app = typer.Typer(
    name="reflect",
    help="reflection operator CLI",
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
    epilog="Install the wake schedule:\n" + CRONTAB_INSTALL,
)
track_app = typer.Typer(
    help="Track configuration and state",
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)
project_app = typer.Typer(
    help="Manage linked projects",
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)
wake_app = typer.Typer(
    help="Wake process management",
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)
events_app = typer.Typer(
    help="Wake event stream",
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)
webhooks_app = typer.Typer(
    help="Webhook subscriptions for the event stream",
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)

app.add_typer(track_app, name="track")
app.add_typer(project_app, name="project")
app.add_typer(wake_app, name="wake")
app.add_typer(events_app, name="events")
app.add_typer(webhooks_app, name="webhooks")


# ── Shared state ──────────────────────────────────────────────────────────────
class _OutputFormat(str, Enum):
    human = "human"
    json = "json"


class _State:
    output: str = "human"
    no_color: bool = False


_state = _State()


@app.callback()
def _root(
    output: Annotated[
        _OutputFormat,
        typer.Option("-o", "--output", help="Output format (default: human)"),
    ] = _OutputFormat.human,
    no_color: Annotated[
        bool,
        typer.Option("--no-color/--color", help="Disable/enable ANSI colors"),
    ] = False,
) -> None:
    _state.output = output.value
    _state.no_color = no_color
    if no_color:
        os.environ["NO_COLOR"] = "1"
        os.environ["TERM"] = "dumb"


def _args(**kwargs) -> SimpleNamespace:
    """Create a SimpleNamespace carrying shared state + command-specific fields."""
    return SimpleNamespace(output=_state.output, no_color=_state.no_color, **kwargs)


# ── init ──────────────────────────────────────────────────────────────────────
@app.command("init")
def init(
    name: Annotated[str, typer.Argument(help="Project name (creates a new directory)")],
    path: Annotated[
        Optional[str],
        typer.Option("--path", "-p", help="Parent directory to create the project in (default: cwd)"),
    ] = None,
) -> None:
    """Scaffold a new reflect project.

    Creates a directory named NAME containing the minimal structure to run an
    autonomous agent loop: wake.md, concept.md, AGENT.md, and the runtime track
    skeleton for the main track.

    \\b
    Quick start:

    \\b
      reflect init my-project
      cd my-project
      # Edit concept.md — the agent reads this first
      reflect wake start main
    """
    from .init import cmd_init
    cmd_init(_args(name=name, path=Path(path) if path else None))


# ── dispatch ──────────────────────────────────────────────────────────────────
@app.command(
    "dispatch",
    help="Fire wakes for tracks that have signal (cron-driven dispatcher).",
    epilog=CRONTAB_INSTALL,
)
def dispatch(
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Print signal state without firing wakes"),
    ] = False,
) -> None:
    """Multi-track dispatcher. Designed for cron — one entry, every minute.

    Iterates `agent/runtime/tracks/*/` and fires per-track wakes for tracks
    that have signal. Tracks run concurrently via background processes.

    See the install snippet below for the canonical crontab line.
    """
    from ..runtime import dispatch as dispatch_module
    import sys
    sys.argv = ["reflect-dispatch"] + (["--dry-run"] if dry_run else [])
    dispatch_module.main()


# ── proxy ─────────────────────────────────────────────────────────────────────
@app.command("proxy")
def proxy(
    host: Annotated[
        str,
        typer.Option("--host", help="Listen host"),
    ] = "127.0.0.1",
    port: Annotated[
        int,
        typer.Option("--port", help="Listen port"),
    ] = 9000,
    credentials: Annotated[
        Optional[str],
        typer.Option("--credentials", help="Path to Claude credentials JSON (default: ~/.claude/.credentials.json)"),
    ] = None,
) -> None:
    """Run the Claude OAuth proxy for subscription-auth wakes.

    Translates Anthropic SDK calls to Claude Max subscription auth. Run as a
    long-lived daemon when wakes are configured for subscription billing
    (i.e. crontab does NOT set REFLECT_USE_API=1).

    \\b
      reflect proxy                          # default: 127.0.0.1:9000
      reflect proxy --port 9001              # alternate port
      reflect proxy --credentials /path/...  # alternate credentials file
    """
    from ..lib.proxy import run as run_proxy
    creds_path = Path(credentials) if credentials else Path.home() / ".claude" / ".credentials.json"
    run_proxy(host=host, port=port, creds_path=creds_path)


# ── track ─────────────────────────────────────────────────────────────────────
@track_app.command("list")
def track_list() -> None:
    """List all tracks with state summary."""
    from .track import cmd_track_list
    cmd_track_list(_args())


@track_app.command("status")
def track_status(
    name: Annotated[str, typer.Argument(help="Track name")],
) -> None:
    """Detailed track status."""
    from .track import cmd_track_status
    cmd_track_status(_args(name=name))


@track_app.command("tail")
def track_tail(
    name: Annotated[str, typer.Argument(help="Track name")],
    no_follow: Annotated[
        bool,
        typer.Option("--no-follow", help="Print last lines and exit (do not follow)"),
    ] = False,
) -> None:
    """Tail the track log (follow by default on a TTY)."""
    from .track import cmd_track_tail
    cmd_track_tail(_args(name=name, no_follow=no_follow))


@track_app.command("logs")
def track_logs(
    name: Annotated[str, typer.Argument(help="Track name")],
) -> None:
    """Print full track log."""
    from .track import cmd_track_logs
    cmd_track_logs(_args(name=name))


@track_app.command("enable")
def track_enable(
    name: Annotated[str, typer.Argument(help="Track name")],
) -> None:
    """Enable a track (clear disabled.flag)."""
    from .track import cmd_track_enable
    cmd_track_enable(_args(name=name))


@track_app.command("disable")
def track_disable(
    name: Annotated[str, typer.Argument(help="Track name")],
) -> None:
    """Disable a track (set disabled.flag)."""
    from .track import cmd_track_disable
    cmd_track_disable(_args(name=name))


@track_app.command("create")
def track_create(
    name: Annotated[str, typer.Argument(help="Track name (or name prefix for --from-template-family mode)")],
    template: Annotated[
        str,
        typer.Option("--template", "-t", help="Template kind (blank, security-audit, or auditor template name)"),
    ] = "blank",
    project: Annotated[
        Optional[str],
        typer.Option("--project", "-p", help="Project name (feeds into auditor template variables)"),
    ] = None,
    cadence_seconds: Annotated[
        Optional[int],
        typer.Option("--cadence-seconds", "-c", help="Wake cadence in seconds (overrides template default)"),
    ] = None,
    filter: Annotated[
        Optional[str],
        typer.Option("--filter", help="Filter description embedded in template (overrides template default)"),
    ] = None,
    from_template_family: Annotated[
        Optional[str],
        typer.Option("--from-template-family", help="Bulk mode: apply all templates in a named family (e.g. auditors)"),
    ] = None,
    projects: Annotated[
        Optional[str],
        typer.Option("--projects", help="Comma-separated projects (required with --from-template-family)"),
    ] = None,
) -> None:
    """Create a new track.

    \\b
    Single-track mode (--template):

    \\b
      reflect track create my-track
      reflect track create my-track --template security-audit
      reflect track create tbd-smoke --template smoke-test-auditor --project tbd

    \\b
    Bulk mode (--from-template-family):

    \\b
      reflect track create unused --from-template-family auditors --projects tbd,toilet-finder
      Creates: tbd-smoke-test-auditor, tbd-security-auditor, ... toilet-finder-smoke-test-auditor, ...

    \\b
    --template and --from-template-family are mutually exclusive.
    """
    from .track import cmd_track_create
    cmd_track_create(_args(
        name=name,
        template=template,
        project=project,
        cadence_seconds=cadence_seconds,
        filter=filter,
        from_template_family=from_template_family,
        projects=projects,
    ))


@track_app.command("send")
def track_send(
    name: Annotated[str, typer.Argument(help="Track name")],
    message: Annotated[str, typer.Argument(help="Message text to drop in the track's inbox")],
) -> None:
    """Queue a message to a track's inbox (next-wake delivery)."""
    from .track import cmd_track_send
    cmd_track_send(_args(name=name, message=message))


@track_app.command("interrupt")
def track_interrupt(
    name: Annotated[str, typer.Argument(help="Track name")],
    message: Annotated[str, typer.Argument(help="Message to inject into the running wake")],
) -> None:
    """Inject a message into a running track's wake (live delivery via socket; falls back to inbox if sleeping)."""
    from .track import cmd_track_interrupt
    cmd_track_interrupt(_args(name=name, message=message))


@track_app.command("session")
def track_session(
    name: Annotated[str, typer.Argument(help="Track name to watch")],
    replay: Annotated[
        int,
        typer.Option("--replay", "-n", help="Number of historical events to show on startup"),
    ] = 20,
) -> None:
    """Interactive TUI session — watch and direct a track in real time.

    Shows a live event stream in the top pane and a prompt at the bottom.
    Input routing:

    \\b
      running track → interrupt (socket delivery, next tool boundary)
      idle/sleeping → inbox drop (read on next wake)

    \\b
    Slash-commands (local, never sent to track):

    \\b
      /wake    Fire a new wake.
      /stop    Signal the running wake to stop.
      /inbox   List queued messages.
      /status  Print full track status.
      /diff    Show git diff for a commit sha.
      /cost    Show current wake cost.
      /clear   Clear the tail pane.
      /help    List all commands.
      /quit    Exit (wake continues running).

    \\b
    Keys: Up/Down for send history. Ctrl+D or Escape to exit.
    """
    from .track import cmd_track_session
    cmd_track_session(_args(name=name, replay=replay))


# ── project ───────────────────────────────────────────────────────────────────
@project_app.command("link")
def project_link(
    path: Annotated[str, typer.Argument(help="Path to project directory")],
) -> None:
    """Link a project."""
    from .project import cmd_project_link
    cmd_project_link(_args(path=path))


@project_app.command("unlink")
def project_unlink(
    name: Annotated[str, typer.Argument(help="Project name or path")],
) -> None:
    """Unlink a project."""
    from .project import cmd_project_unlink
    cmd_project_unlink(_args(name=name))


@project_app.command("list")
def project_list() -> None:
    """List linked projects."""
    from .project import cmd_project_list
    cmd_project_list(_args())


# ── wake ──────────────────────────────────────────────────────────────────────
@wake_app.command("list")
def wake_list() -> None:
    """List currently running wakes."""
    from .wake import cmd_wake_list
    cmd_wake_list(_args())


@wake_app.command("start")
def wake_start(
    track: Annotated[str, typer.Argument(help="Track name")],
    force: Annotated[
        bool,
        typer.Option("--force/--no-force", "-f", help="Stop existing wake and restart"),
    ] = False,
) -> None:
    """Manually fire a wake for a track."""
    from .wake import cmd_wake_start
    cmd_wake_start(_args(track=track, force=force))


@wake_app.command("stop")
def wake_stop(
    track: Annotated[str, typer.Argument(help="Track name")],
) -> None:
    """Gracefully stop a running wake."""
    from .wake import cmd_wake_stop
    cmd_wake_stop(_args(track=track))


@wake_app.command("pause")
def wake_pause(
    track: Annotated[str, typer.Argument(help="Track name")],
) -> None:
    """Pause a running wake cooperatively (at the next safe checkpoint).

    The wake process stays alive — LLM context and tool state are preserved.
    Use `reflect wake resume <track>` to continue from where it left off.
    """
    from .wake import cmd_wake_pause
    cmd_wake_pause(_args(track=track))


@wake_app.command("resume")
def wake_resume(
    track: Annotated[str, typer.Argument(help="Track name")],
) -> None:
    """Resume a paused wake."""
    from .wake import cmd_wake_resume
    cmd_wake_resume(_args(track=track))


@wake_app.command("history")
def wake_history(
    track: Annotated[Optional[str], typer.Argument(help="Filter by track (optional)")] = None,
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Max rows to show"),
    ] = 20,
) -> None:
    """Show wake history from wakes.tsv."""
    from .wake import cmd_wake_history
    cmd_wake_history(_args(track=track, limit=limit))


# ── events ───────────────────────────────────────────────────────────────────


@events_app.command("list")
def events_list(
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Max events to show (0 = all; default 50)"),
    ] = 50,
    track: Annotated[
        Optional[str],
        typer.Option("--track", "-t", help="Filter by track name"),
    ] = None,
    event_type: Annotated[
        Optional[str],
        typer.Option("--type", help="Filter by event type (e.g. wake.completed)"),
    ] = None,
    since: Annotated[
        Optional[str],
        typer.Option("--since", help="Show events at or after this ISO timestamp"),
    ] = None,
) -> None:
    """List recent events from the event stream."""
    from .events import cmd_events_list
    cmd_events_list(_args(limit=limit, track=track, event_type=event_type, since=since))


@events_app.command("since")
def events_since(
    timestamp: Annotated[str, typer.Argument(help="ISO-8601 timestamp (e.g. 2026-05-10T07:00:00Z)")],
    track: Annotated[
        Optional[str],
        typer.Option("--track", "-t", help="Filter by track name"),
    ] = None,
    event_type: Annotated[
        Optional[str],
        typer.Option("--type", help="Filter by event type"),
    ] = None,
) -> None:
    """Show all events since a given timestamp."""
    from .events import cmd_events_since
    cmd_events_since(_args(since=timestamp, track=track, event_type=event_type))


@events_app.command("tail")
def events_tail(
    track: Annotated[
        Optional[str],
        typer.Option("--track", "-t", help="Filter by track name"),
    ] = None,
    event_type: Annotated[
        Optional[str],
        typer.Option("--type", help="Filter by event type"),
    ] = None,
    no_follow: Annotated[
        bool,
        typer.Option("--no-follow", help="Print last events and exit (do not follow)"),
    ] = False,
    lines: Annotated[
        int,
        typer.Option("--lines", "-n", help="Number of recent events to print before following"),
    ] = 20,
) -> None:
    """Follow the live event stream (Ctrl-C to stop)."""
    from .events import cmd_events_tail
    cmd_events_tail(_args(track=track, event_type=event_type, no_follow=no_follow, lines=lines))


# ── webhooks ─────────────────────────────────────────────────────────────────


@webhooks_app.command("list")
def webhooks_list() -> None:
    """List all registered webhooks."""
    from .webhooks import cmd_webhooks_list
    cmd_webhooks_list(_args())


@webhooks_app.command("add")
def webhooks_add(
    url: Annotated[str, typer.Argument(help="Webhook endpoint URL (must accept HTTP POST)")],
    event_type: Annotated[
        Optional[list[str]],
        typer.Option("--event-type", "-e", help="Filter by event type (repeatable; default: all)"),
    ] = None,
    track: Annotated[
        Optional[list[str]],
        typer.Option("--track", "-t", help="Filter by track name (repeatable; default: all)"),
    ] = None,
) -> None:
    """Register a new webhook endpoint.

    Events are POSTed as JSON with headers X-Reflect-Event and X-Reflect-Track.
    Delivery is best-effort (no retry on failure).
    """
    from .webhooks import cmd_webhooks_add
    cmd_webhooks_add(_args(url=url, event_type=event_type, track=track))


@webhooks_app.command("remove")
def webhooks_remove(
    id: Annotated[str, typer.Argument(help="Webhook id (from `reflect webhooks list`)")],
) -> None:
    """Remove a webhook by id."""
    from .webhooks import cmd_webhooks_remove
    cmd_webhooks_remove(_args(id=id))


@webhooks_app.command("test")
def webhooks_test(
    id: Annotated[str, typer.Argument(help="Webhook id (from `reflect webhooks list`)")],
) -> None:
    """POST a test.ping event to a webhook and report the HTTP response."""
    from .webhooks import cmd_webhooks_test
    cmd_webhooks_test(_args(id=id))


# ── inbox ─────────────────────────────────────────────────────────────────────
@app.command("inbox")
def inbox(
    track: Annotated[Optional[str], typer.Argument(help="Filter by track (optional)")] = None,
    interleave: Annotated[
        bool,
        typer.Option("-i", "--interleave", help="Interleaved timeline view: pending + consumed + agent surfaces, sorted by time"),
    ] = False,
    pending_only: Annotated[
        bool,
        typer.Option("--pending-only/--all", help="With -i: show only pending (unconsumed) messages"),
    ] = False,
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Max entries to show (applies to -i mode)"),
    ] = 50,
    since: Annotated[
        Optional[str],
        typer.Option("--since", help="With -i: only show messages at or after this ISO timestamp"),
    ] = None,
) -> None:
    """Show unread inbox messages."""
    from .inbox import cmd_inbox
    cmd_inbox(_args(
        track=track,
        interleave=interleave,
        pending_only=pending_only,
        limit=limit,
        since=since,
    ))


# ── report ───────────────────────────────────────────────────────────────────
@app.command("report")
def report(
    tracks: Annotated[
        Optional[str],
        typer.Option("--tracks", "-t", help="Comma-separated track names or glob patterns (e.g. 'crimes-*,bark-worker'). Omitted = all tracks."),
    ] = None,
    kinds: Annotated[
        Optional[str],
        typer.Option("--kinds", "-k", help="Comma-separated artifact kinds with optional :N per-kind limits (e.g. 'inbox,reports:3,completed:1'). Omitted = all kinds."),
    ] = None,
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Default per-kind limit (overridden by :N syntax in --kinds)."),
    ] = 3,
    offset: Annotated[
        int,
        typer.Option("--offset", help="Skip N most recent before applying limit."),
    ] = 0,
    since: Annotated[
        Optional[str],
        typer.Option("--since", help="Filter artifacts with timestamp >= this value (ISO8601 or keyword: today, yesterday, now)."),
    ] = None,
    until: Annotated[
        Optional[str],
        typer.Option("--until", help="Filter artifacts with timestamp <= this value (ISO8601 or keyword)."),
    ] = None,
    state: Annotated[
        str,
        typer.Option("--state", help="State file inclusion: core (default), all, none."),
    ] = "core",
) -> None:
    """Aggregate track artifacts and state into a single concatenated output.

    Context concatenator for agents. Replaces multi-step Bash loops with a
    one-shot call.

    \\b
    Examples:

    \\b
      reflect report --tracks bark-*
      reflect report --tracks crimes-* --kinds inbox:0,reports:3
      reflect report --tracks originator --kinds inbox:10
      reflect report --tracks bark-* --since today
      reflect report --tracks rtai-* --limit 5 --offset 5
    """
    from .report import cmd_report
    cmd_report(_args(
        tracks=tracks,
        kinds=kinds,
        limit=limit,
        offset=offset,
        since=since,
        until=until,
        state=state,
    ))


# ── doctor ────────────────────────────────────────────────────────────────────
@app.command("doctor")
def doctor() -> None:
    """Run health checks on the reflection runtime."""
    from .doctor import cmd_doctor
    cmd_doctor(_args())


# ── cost ──────────────────────────────────────────────────────────────────────
@app.command("cost")
def cost(
    by_track: Annotated[
        bool,
        typer.Option("--by-track/--global", help="Group costs by track"),
    ] = False,
    since: Annotated[
        Optional[str],
        typer.Option("--since", help="Filter wakes started after TS (ISO or unix timestamp)"),
    ] = None,
) -> None:
    """Show spend summary across wakes."""
    from .cost import cmd_cost
    cmd_cost(_args(by_track=by_track, since=since))


# ── dashboard ─────────────────────────────────────────────────────────────────
@app.command("dashboard")
def dashboard() -> None:
    """Live multi-track TUI dashboard.

    Not pipeable. Use `reflect track list -o json` for machine-readable output.
    """
    from .dashboard import cmd_dashboard
    cmd_dashboard(_args())


# ── docs ─────────────────────────────────────────────────────────────────────
@app.command("docs")
def docs(
    topic: Annotated[Optional[str], typer.Argument(help="Doc topic (e.g. 'state', 'tracks', 'primitives/state')")] = None,
    list_all: Annotated[
        bool,
        typer.Option("--list", "-l", help="List all available docs"),
    ] = False,
    path_only: Annotated[
        bool,
        typer.Option("--path", "-p", help="Print file path instead of opening in pager"),
    ] = False,
) -> None:
    """View reflect documentation.

    \\b
    Examples:

    \\b
      reflect docs state           # opens docs/primitives/state.md in $PAGER
      reflect docs --list          # lists all docs
      reflect docs --path state    # prints path
    """
    from .docs import cmd_docs
    cmd_docs(_args(topic=topic, list_all=list_all, path_only=path_only))


# ── completion ────────────────────────────────────────────────────────────────
@app.command("completion")
def completion(
    install: Annotated[
        bool,
        typer.Option("--install", help="Install shell completion for the current shell (bash/zsh/fish auto-detected)"),
    ] = False,
    shell: Annotated[
        Optional[str],
        typer.Option("--shell", help="Override shell detection (bash, zsh, fish, powershell)"),
    ] = None,
) -> None:
    """Manage shell completion for reflect.

    Run `reflect completion --install` to add completion to your shell config.
    Detected shell is printed unless --shell overrides it.

    After installation, restart your shell or source your rc file:
      bash: source ~/.bashrc
      zsh:  source ~/.zshrc
      fish: (auto-loaded; open a new shell)
    """
    import subprocess
    import sys

    # Detect shell
    detected_shell = shell
    if detected_shell is None:
        try:
            import shellingham  # type: ignore[import-untyped]
            detected_shell, _ = shellingham.detect_shell()
        except Exception:
            typer.echo("Could not auto-detect shell. Use --shell bash|zsh|fish|powershell.", err=True)
            raise typer.Exit(1)

    if not install:
        typer.echo(f"Detected shell: {detected_shell}")
        typer.echo("Run `reflect completion --install` to install completion.")
        return

    _install_completion(detected_shell)


def _install_completion(shell: str) -> None:
    """Write the completion eval line to the appropriate shell rc file."""
    shell_configs = {
        "bash": Path.home() / ".bashrc",
        "zsh": Path.home() / ".zshrc",
        "fish": Path.home() / ".config" / "fish" / "completions" / "reflect.fish",
    }

    eval_lines = {
        "bash": 'eval "$(reflect --show-completion bash)"',
        "zsh": 'eval "$(reflect --show-completion zsh)"',
        "fish": "reflect --show-completion fish | source",
        "powershell": "reflect --show-completion powershell | Out-String | Invoke-Expression",
    }

    if shell not in eval_lines:
        typer.echo(f"Unsupported shell: {shell}. Supported: bash, zsh, fish, powershell.", err=True)
        raise typer.Exit(1)

    eval_line = eval_lines[shell]

    if shell == "fish":
        rc_file = shell_configs["fish"]
        rc_file.parent.mkdir(parents=True, exist_ok=True)
        rc_file.write_text(f"# reflect shell completion\n{eval_line}\n")
        typer.echo(f"Completion installed to {rc_file}")
        typer.echo("Open a new fish shell to activate.")
        return

    if shell == "powershell":
        typer.echo(f"Add this line to your PowerShell profile:")
        typer.echo(f"  {eval_line}")
        return

    rc_file = shell_configs.get(shell)
    if rc_file is None:
        typer.echo(f"No known rc file for shell: {shell}", err=True)
        raise typer.Exit(1)

    marker = "# reflect shell completion"
    if rc_file.exists():
        content = rc_file.read_text()
        if eval_line in content:
            typer.echo(f"Completion already installed in {rc_file}")
            return

    with open(rc_file, "a") as f:
        f.write(f"\n{marker}\n{eval_line}\n")

    typer.echo(f"Completion installed to {rc_file}")
    typer.echo(f"Run `source {rc_file}` or open a new terminal to activate.")


# ── Entry point ───────────────────────────────────────────────────────────────
def main() -> None:
    app()


if __name__ == "__main__":
    main()
