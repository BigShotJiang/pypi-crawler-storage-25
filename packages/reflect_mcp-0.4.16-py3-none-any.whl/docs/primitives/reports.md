# reflect report

Context concatenator for agents. Aggregates track artifacts and state into a single concatenated output. Replaces multi-step Bash loops with a one-shot tool/CLI call.

## Purpose

Agents frequently need to load context from multiple tracks' runtime artifacts:
- "What have all `crimes-*` tracks shipped today?"
- "Bundle the last 3 reports + state from bark workers for handoff"
- "Show me the originator's recent inbox"

Without `reflect report`, this requires manually listing directories, sorting, head/tail, and cat-ing each file. `reflect report` collapses this into one declarative call.

## CLI

```bash
reflect report [--tracks <glob>] [--kinds <spec>] [--limit N] [--offset N] [--since <iso>] [--until <iso>] [--state core|all|none]
```

### Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--tracks` | all tracks | Comma-separated track names or glob patterns (e.g. `crimes-*,bark-worker`). Omitted = all tracks alphabetical. |
| `--kinds` | all kinds | Comma-separated artifact kinds with optional `:N` per-kind limits (e.g. `inbox,reports:3,completed:1`). Bare name uses `--limit`; `:N` overrides. |
| `--limit N` | `3` | Default per-kind limit. Overridden by per-kind `:N` syntax. |
| `--offset N` | `0` | Skip N most recent before applying limit. |
| `--since <iso>` | none | Filter artifacts with timestamp >= this value. |
| `--until <iso>` | none | Filter artifacts with timestamp <= this value. |
| `--state` | `core` | `core` = include `core.state.yaml` per track. `all` = include all `*.state.yaml`. `none` = skip state files. |

### Artifact kinds

Recognized kinds (correspond to subdirectories under `agent/runtime/tracks/<track>/`):
- `inbox` — pending messages
- `reports` — wake reports
- `followup` — pending followups
- `completed` — completed work
- `state` — state files (controlled via `--state`, not `--kinds`)

### State handling

- `core.state.yaml` is included per matched track by default (placed first, before artifacts).
- Other `*.state.yaml` files require `--state all`.
- Silent skip if a track has no `core.state.yaml`.

### Date parsing

`--since` / `--until` accept:
- ISO8601: `2026-05-14`, `2026-05-14T18:00Z`, `2026-05-14T18:00:00+00:00`
- Relative keywords: `today`, `yesterday`, `now`

Artifact timestamps come from:
1. **Filename prefix** — parsed from patterns like `2026-05-14T18-00Z-foo.md` (preferred — stable across copies/renames)
2. **File mtime** — fallback when filename has no parseable timestamp prefix (covers state files and unprefixed artifacts)

### Mutual exclusion (soft)

`--offset`/`--limit` and `--since`/`--until` are semantically distinct:
- `--offset`/`--limit` → "recent N" queries
- `--since`/`--until` → "time window" queries

Combining them is supported but rarely useful. If both are given: date filters apply first, then offset/limit on the filtered set.

### Output format

Files concatenated with separator headers:
```
=== <track>/<kind>/<filename> ===
<file contents>

=== <track>/<kind>/<filename> ===
<file contents>
```

State file separator:
```
=== <track>/state/core.state.yaml ===
<file contents>
```

### Ordering

- **Group by track** — all artifacts for one track together, then next track (alphabetical by track name).
- **Within a track:** state file first, then artifacts grouped by kind.
- **Within a kind:** newest first (filename timestamp → mtime fallback).

### Empty tracks

Tracks matching the glob with zero matching artifacts emit a placeholder header so consumers don't mistake absence for error:
```
=== <track>/<empty> ===
```

No content body — the header alone signals "track matched, no artifacts in scope."

## MCP

```python
mcp__reflect__report(
    action: "read",                          # required (future: "summary", etc.)
    tracks: list[str] | str | None = None,   # ["bark-*"], "bark-*", or None (= all)
    kinds: dict[str, int] | None = None,     # {"inbox": 0, "reports": 3, "completed": 1}
    limit: int = 3,                          # default per-kind
    offset: int = 0,                         # skip N most recent before limit
    since: str | None = None,                # ISO8601 or keyword
    until: str | None = None,                # ISO8601 or keyword
    include_state: "core" | "all" | "none" = "core",
) -> str
```

Returns the same concatenated string the CLI would print to stdout.

`tracks` accepts both `list[str]` and `str` (DX nicety; comma-separated strings parse like CLI).

## Examples

### All bark tracks' state + last 3 of each artifact kind
```bash
reflect report --tracks bark-*
```

### Last 3 reports per crimes track, skip inbox
```bash
reflect report --tracks crimes-* --kinds inbox:0,reports:3
```

### Recent originator inbox
```bash
reflect report --tracks originator --kinds inbox:10
```

### Time-window query — everything from today
```bash
reflect report --tracks bark-* --since today
```

### Cross-track synthesis context for an agent
```bash
reflect report --tracks bark-orchestrator,bark-ux-worker --kinds reports:3,completed:5
```

### Pipe to file or pager
```bash
reflect report --tracks rtai-* > rtai-context.md
reflect report --tracks crimes-* | less
```

### MCP equivalent
```python
mcp__reflect__report(
    action="read",
    tracks=["bark-orchestrator", "bark-ux-worker"],
    kinds={"reports": 3, "completed": 5},
)
```

## Anti-patterns

**Don't use for:**
- Pretty status dashboards (use `reflect wake status` / `reflect track list`)
- Real-time monitoring (use `reflect track logs`)
- Running summary or analytics (consumer agent does that on the concatenated output)

`reflect report` is a context loader, not a presentation layer.

## Related primitives

- [[state]] — `core.state.yaml` is the canonical track state primitive read by report
- [[tracks]] — directory structure and artifact kinds
- [[docs]] — `reflect docs` for documentation access
