"""Cross-method consistency invariants.

These invariants hold for *every* valid input — they cannot fail
without an implementation bug — so they are the broadest possible
correctness net. See ``docs/implementation-v1.1.md`` §T1.3(b).

Invariants
----------
1. Every linking method (Cariño / GRAP / geometric) produces the
   identical compounded portfolio return and identical compounded
   benchmark return for the same input. Only the *attribution
   decomposition* differs by method.
2. Cariño and GRAP both close the additive identity
   ``A + S + I == arithmetic excess`` to ≤ 1e-9.
3. Geometric linking closes the multiplicative identity
   ``(1 + A)(1 + S) − 1 == geometric excess`` to ≤ 1e-9.
4. BHB and BF on the same input produce identical portfolio total
   return, benchmark total return, excess return, total selection and
   total interaction. Only the *per-segment* allocation split differs
   (the totals coincide because ``Σ(w_p − w_b) = 0`` when both weight
   vectors sum to 1).

Tests are parametric over a small bank of fixtures so adding a new
linking method (Menchero, Frongello in v1.1) automatically inherits the
invariants by appending to ``LINKING_METHODS``.
"""

from __future__ import annotations

import random

import pytest

from pybrinson import (
    PeriodAttribution,
    Segment,
    bhb,
    fachler,
    link_carino,
    link_frongello,
    link_geometric,
    link_grap,
)
from pybrinson.fixtures import (
    bacon_2008_ch5_bhb,
    two_period_linking_example,
)

# Linking functions that satisfy the additive identity (Cariño, GRAP, Frongello).
ADDITIVE_LINKERS = [link_carino, link_grap, link_frongello]
# All linking methods (additive + geometric).
ALL_LINKERS = [link_carino, link_grap, link_frongello, link_geometric]


def _random_periods(seed: int, n_periods: int = 4, n_segments: int = 3):
    rng = random.Random(seed)
    out = []
    for t in range(n_periods):
        w_p = [rng.random() for _ in range(n_segments)]
        w_b = [rng.random() for _ in range(n_segments)]
        sp, sb = sum(w_p), sum(w_b)
        w_p = [w / sp for w in w_p]
        w_b = [w / sb for w in w_b]
        segs = [
            Segment(
                f"S{i}",
                w_p[i],
                w_b[i],
                rng.uniform(-0.15, 0.15),
                rng.uniform(-0.15, 0.15),
            )
            for i in range(n_segments)
        ]
        out.append(bhb(segs, period=f"P{t}"))
    return out


# ---------------------------------------------------------------------------
# Invariant 1: every linking method recovers the same compounded R_p / R_b.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("seed", [20260411, 20260412, 20260413, 20260414])
def test_all_linkers_agree_on_compounded_returns(seed: int) -> None:
    periods = _random_periods(seed)
    refs = [link(periods) for link in ALL_LINKERS]
    r_p = refs[0].portfolio_return
    r_b = refs[0].benchmark_return
    for other in refs[1:]:
        assert other.portfolio_return == pytest.approx(r_p, abs=1e-12)
        assert other.benchmark_return == pytest.approx(r_b, abs=1e-12)


# ---------------------------------------------------------------------------
# Invariant 2: additive linking closes the additive identity.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("link", ADDITIVE_LINKERS)
@pytest.mark.parametrize("seed", [20260415, 20260416, 20260417])
def test_additive_linkers_close_additive_identity(link, seed: int) -> None:
    periods = _random_periods(seed)
    linked = link(periods)
    total = linked.allocation + linked.selection + linked.interaction
    assert total == pytest.approx(linked.excess_return, abs=1e-9)


# ---------------------------------------------------------------------------
# Invariant 3: geometric linking closes the multiplicative identity.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("seed", [20260418, 20260419])
def test_geometric_linker_closes_multiplicative_identity(seed: int) -> None:
    periods = _random_periods(seed)
    linked = link_geometric(periods)
    lhs = (1.0 + linked.allocation) * (1.0 + linked.selection) - 1.0
    assert lhs == pytest.approx(linked.excess_return, abs=1e-9)


# ---------------------------------------------------------------------------
# Invariant 4: BHB and BF agree on totals (only the per-segment split
# differs). Verified on both literature-pinned and random inputs.
# ---------------------------------------------------------------------------


def _bhb_bf_totals_agree(segments: tuple[Segment, ...]) -> None:
    bh = bhb(segments)
    bf = fachler(segments)
    assert bh.portfolio_return == pytest.approx(bf.portfolio_return, abs=1e-12)
    assert bh.benchmark_return == pytest.approx(bf.benchmark_return, abs=1e-12)
    assert bh.excess_return == pytest.approx(bf.excess_return, abs=1e-12)
    assert bh.allocation == pytest.approx(bf.allocation, abs=1e-12)
    assert bh.selection == pytest.approx(bf.selection, abs=1e-12)
    assert bh.interaction == pytest.approx(bf.interaction, abs=1e-12)


def test_bhb_bf_agree_on_bacon_2008_fixture() -> None:
    segments, _ = bacon_2008_ch5_bhb()
    _bhb_bf_totals_agree(segments)


@pytest.mark.parametrize("seed", [20260420, 20260421, 20260422, 20260423, 20260424])
def test_bhb_bf_agree_on_random_inputs(seed: int) -> None:
    rng = random.Random(seed)
    n = rng.randint(2, 8)
    w_p = [rng.random() for _ in range(n)]
    w_b = [rng.random() for _ in range(n)]
    sp, sb = sum(w_p), sum(w_b)
    w_p = [w / sp for w in w_p]
    w_b = [w / sb for w in w_b]
    segs = tuple(
        Segment(
            f"S{i}",
            w_p[i],
            w_b[i],
            rng.uniform(-0.5, 0.5),
            rng.uniform(-0.5, 0.5),
        )
        for i in range(n)
    )
    _bhb_bf_totals_agree(segs)


# ---------------------------------------------------------------------------
# Bonus: the relationship between additive and geometric excess.
#
# By construction, geometric_excess = (1 + arithmetic_excess + R_b) / (1 + R_b)
# − 1 = arithmetic_excess / (1 + R_b). Verifies the two are not silently
# swapped or double-applied.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("seed", [20260425, 20260426])
def test_geometric_excess_equals_arithmetic_over_1_plus_rb(seed: int) -> None:
    periods = _random_periods(seed)
    arith = link_carino(periods)
    geom = link_geometric(periods)
    expected_geom = arith.excess_return / (1.0 + arith.benchmark_return)
    assert geom.excess_return == pytest.approx(expected_geom, abs=1e-12)


# ---------------------------------------------------------------------------
# Sanity-check that the public two-period fixture produces the documented
# compounded numbers across all linking methods (single point of truth).
# ---------------------------------------------------------------------------


def test_two_period_fixture_consistent_across_linkers() -> None:
    periods, expected = two_period_linking_example()
    period_attrs: list[PeriodAttribution] = []
    for label, segs in periods:
        period_attrs.append(bhb(segs, period=label))

    for link in ALL_LINKERS:
        linked = link(period_attrs)
        assert linked.portfolio_return == pytest.approx(
            expected["compounded_portfolio_return"], abs=1e-12
        )
        assert linked.benchmark_return == pytest.approx(
            expected["compounded_benchmark_return"], abs=1e-12
        )

    # Cariño + GRAP carry the arithmetic excess, geometric carries the
    # geometric excess. Pinned per fixture docstring.
    assert link_carino(period_attrs).excess_return == pytest.approx(
        expected["arithmetic_excess"], abs=1e-12
    )
    assert link_grap(period_attrs).excess_return == pytest.approx(
        expected["arithmetic_excess"], abs=1e-12
    )
    assert link_frongello(period_attrs).excess_return == pytest.approx(
        expected["arithmetic_excess"], abs=1e-12
    )
    assert link_geometric(period_attrs).excess_return == pytest.approx(
        expected["geometric_excess"], abs=1e-12
    )
