"""Frongello recursive linking tests.

The pinned values come from hand-derivation of Frongello (2002) on the
public ``two_period_linking_example`` fixture and from the closed-form
factor ``f_t = Π_{s<t}(1+R_b,s) · Π_{s>t}(1+R_p,s)``.
"""

from __future__ import annotations

import random

import pytest

from pybrinson import (
    AttributionError,
    PeriodAttribution,
    Segment,
    bhb,
    fachler,
    link_frongello,
)
from pybrinson.fixtures import two_period_linking_example


def _two_period_attrs() -> tuple[PeriodAttribution, PeriodAttribution]:
    periods, _ = two_period_linking_example()
    p1 = bhb(periods[0][1], period=periods[0][0])
    p2 = bhb(periods[1][1], period=periods[1][0])
    return p1, p2


def test_frongello_method_label_and_identity():
    p1, p2 = _two_period_attrs()
    linked = link_frongello([p1, p2])
    assert linked.method == "Frongello"
    total = linked.allocation + linked.selection + linked.interaction
    assert total == pytest.approx(linked.excess_return, abs=1e-12)


def test_frongello_pinned_two_period_values():
    """Hand-computed Frongello factors for the two-period example.

    f_1 = (1 + R_p,2) = 1.125  (no prior benchmark, future portfolio = 1.125)
    f_2 = (1 + R_b,1) = 1.075  (prior benchmark = 1.075, no future portfolio)
    """
    p1, p2 = _two_period_attrs()
    linked = link_frongello([p1, p2])

    f1 = 1.125
    f2 = 1.075
    expected_alloc = -0.005 * f1 + 0.0 * f2
    expected_sel = 0.0 * f1 + 0.025 * f2
    expected_inter = 0.010 * f1 + 0.0 * f2

    assert linked.allocation == pytest.approx(expected_alloc, abs=1e-12)
    assert linked.selection == pytest.approx(expected_sel, abs=1e-12)
    assert linked.interaction == pytest.approx(expected_inter, abs=1e-12)

    expected_excess = 1.08 * 1.125 - 1.075 * 1.10
    assert linked.excess_return == pytest.approx(expected_excess, abs=1e-12)


def test_frongello_compounded_returns_match_carino_grap_geometric():
    """All linking methods agree on R_p^cum and R_b^cum (consistency)."""
    from pybrinson import link_carino, link_geometric, link_grap

    p1, p2 = _two_period_attrs()
    fr = link_frongello([p1, p2])
    ca = link_carino([p1, p2])
    gr = link_grap([p1, p2])
    ge = link_geometric([p1, p2])
    for other in (ca, gr, ge):
        assert fr.portfolio_return == pytest.approx(other.portfolio_return, abs=1e-12)
        assert fr.benchmark_return == pytest.approx(other.benchmark_return, abs=1e-12)


def test_frongello_single_period_raises():
    p1, _ = _two_period_attrs()
    with pytest.raises(AttributionError, match="≥ 2 periods"):
        link_frongello([p1])


def test_frongello_rejects_mixed_methods():
    p1 = bhb([Segment("A", 1.0, 1.0, 0.05, 0.04)])
    p2 = fachler([Segment("A", 1.0, 1.0, 0.05, 0.04)])
    with pytest.raises(AttributionError, match="single attribution method"):
        link_frongello([p1, p2])


def test_frongello_identity_random_multi_period():
    rng = random.Random(20260427)
    for _ in range(20):
        n_periods = rng.randint(2, 8)
        period_attrs: list[PeriodAttribution] = []
        for t in range(n_periods):
            n = rng.randint(2, 5)
            w_p = [rng.random() for _ in range(n)]
            w_b = [rng.random() for _ in range(n)]
            sp, sb = sum(w_p), sum(w_b)
            w_p = [w / sp for w in w_p]
            w_b = [w / sb for w in w_b]
            segs = [
                Segment(
                    f"S{i}",
                    w_p[i],
                    w_b[i],
                    rng.uniform(-0.2, 0.2),
                    rng.uniform(-0.2, 0.2),
                )
                for i in range(n)
            ]
            period_attrs.append(bhb(segs, period=f"P{t}"))
        linked = link_frongello(period_attrs)
        total = linked.allocation + linked.selection + linked.interaction
        assert total == pytest.approx(linked.excess_return, abs=1e-9)


def test_frongello_recursive_form_matches_closed_form():
    """The recursive Frongello definition

        L_t = a_t · Π_{s<t}(1+R_b,s) + L_{t-1} · (1+R_p,t)

    must equal the closed-form factor sum used by the implementation.
    Verified by direct hand-recursion for a 4-period synthetic input.
    """
    rng = random.Random(20260428)
    period_attrs: list[PeriodAttribution] = []
    for t in range(4):
        segs = [
            Segment("A", 0.55, 0.50, rng.uniform(-0.1, 0.1), rng.uniform(-0.1, 0.1)),
            Segment("B", 0.45, 0.50, rng.uniform(-0.1, 0.1), rng.uniform(-0.1, 0.1)),
        ]
        period_attrs.append(bhb(segs, period=f"P{t}"))

    # Hand recursion on the allocation channel.
    L_alloc = period_attrs[0].allocation
    for t in range(1, len(period_attrs)):
        prefix_b = 1.0
        for s in range(t):
            prefix_b *= 1.0 + period_attrs[s].benchmark_return
        # Recursive update: L_t = a_t · prefix_b - 0 + L_{t-1} · (1 + R_p,t)
        # Wait — the recursive form is L_t = a_t · Π_{s<t}(1+R_b,s) + L_{t-1} · (1+R_p,t).
        L_alloc = period_attrs[t].allocation * prefix_b + L_alloc * (
            1.0 + period_attrs[t].portfolio_return
        )

    linked = link_frongello(period_attrs)
    assert linked.allocation == pytest.approx(L_alloc, abs=1e-12)
