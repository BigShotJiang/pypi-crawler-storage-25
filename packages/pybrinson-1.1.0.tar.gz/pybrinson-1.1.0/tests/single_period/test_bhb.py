"""Tests for Brinson-Hood-Beebower single-period attribution.

The pinned worked example is the canonical 3-sector teaching example
that appears across the literature (Brinson 1986; Bacon 2008, chap. 5;
CFA Institute Refresher Reading on Performance Attribution). Numbers
are reproduced by hand here so the test is self-contained; the
identity ``A + S + I == R_p − R_b`` is the primary correctness check.
"""

from __future__ import annotations

import random

import pytest

from pybrinson import AttributionError, Segment, bhb

# 3-sector example used in Bacon 2008 chap. 5 and CFA Institute teaching
# materials.  Weights and returns kept exact so floating-point residuals
# vanish to ~1e-17.
EXAMPLE_SEGMENTS = [
    Segment("UK Equity", 0.40, 0.40, 0.20, 0.10),
    Segment("Japan Equity", 0.30, 0.20, -0.05, -0.04),
    Segment("US Equity", 0.30, 0.40, 0.06, 0.08),
]
EXAMPLE_R_P = 0.083
EXAMPLE_R_B = 0.064
EXAMPLE_EXCESS = 0.019


def test_bhb_totals_match_expected():
    res = bhb(EXAMPLE_SEGMENTS, period="2024")
    assert res.method == "BHB"
    assert res.period == "2024"
    assert res.portfolio_return == pytest.approx(EXAMPLE_R_P, abs=1e-12)
    assert res.benchmark_return == pytest.approx(EXAMPLE_R_B, abs=1e-12)
    assert res.excess_return == pytest.approx(EXAMPLE_EXCESS, abs=1e-12)


def test_bhb_per_segment_pinned_values():
    res = bhb(EXAMPLE_SEGMENTS)
    by_name = {s.name: s for s in res.by_segment}

    # UK: w_p = w_b = 0.40 → allocation and interaction zero, selection only
    uk = by_name["UK Equity"]
    assert uk.allocation == pytest.approx(0.0, abs=1e-12)
    assert uk.selection == pytest.approx(0.40 * (0.20 - 0.10), abs=1e-12)
    assert uk.interaction == pytest.approx(0.0, abs=1e-12)

    # Japan: overweight (0.30 vs 0.20) in a negative-return segment
    jp = by_name["Japan Equity"]
    assert jp.allocation == pytest.approx((0.30 - 0.20) * -0.04, abs=1e-12)
    assert jp.selection == pytest.approx(0.20 * (-0.05 - -0.04), abs=1e-12)
    assert jp.interaction == pytest.approx(
        (0.30 - 0.20) * (-0.05 - -0.04), abs=1e-12
    )

    # US: underweight (0.30 vs 0.40), benchmark return 8%
    us = by_name["US Equity"]
    assert us.allocation == pytest.approx((0.30 - 0.40) * 0.08, abs=1e-12)
    assert us.selection == pytest.approx(0.40 * (0.06 - 0.08), abs=1e-12)
    assert us.interaction == pytest.approx(
        (0.30 - 0.40) * (0.06 - 0.08), abs=1e-12
    )


def test_bhb_identity_holds_on_example():
    res = bhb(EXAMPLE_SEGMENTS)
    total = res.allocation + res.selection + res.interaction
    assert total == pytest.approx(res.excess_return, abs=1e-12)


def test_bhb_identity_holds_on_random_inputs():
    rng = random.Random(20260411)
    for _ in range(50):
        n = rng.randint(2, 8)
        w_p = [rng.random() for _ in range(n)]
        w_b = [rng.random() for _ in range(n)]
        s_p = sum(w_p)
        s_b = sum(w_b)
        w_p = [w / s_p for w in w_p]
        w_b = [w / s_b for w in w_b]
        segs = [
            Segment(
                f"S{i}",
                w_p[i],
                w_b[i],
                rng.uniform(-0.5, 0.5),
                rng.uniform(-0.5, 0.5),
            )
            for i in range(n)
        ]
        res = bhb(segs)
        total = res.allocation + res.selection + res.interaction
        assert total == pytest.approx(res.excess_return, abs=1e-9)


def test_bhb_zero_active_bet():
    segs = [
        Segment("A", 0.5, 0.5, 0.10, 0.05),
        Segment("B", 0.5, 0.5, 0.04, 0.06),
    ]
    res = bhb(segs)
    assert res.allocation == pytest.approx(0.0, abs=1e-12)
    assert res.interaction == pytest.approx(0.0, abs=1e-12)
    # Selection still nonzero because per-segment R_p ≠ R_b
    assert res.selection == pytest.approx(res.excess_return, abs=1e-12)


def test_bhb_zero_skill():
    segs = [
        Segment("A", 0.6, 0.4, 0.10, 0.10),
        Segment("B", 0.4, 0.6, 0.05, 0.05),
    ]
    res = bhb(segs)
    assert res.selection == pytest.approx(0.0, abs=1e-12)
    assert res.interaction == pytest.approx(0.0, abs=1e-12)
    assert res.allocation == pytest.approx(res.excess_return, abs=1e-12)


def test_bhb_negative_returns_propagate_signs():
    segs = [
        Segment("A", 0.5, 0.5, -0.05, -0.10),
        Segment("B", 0.5, 0.5, -0.10, -0.05),
    ]
    res = bhb(segs)
    # No allocation bet, equal selection magnitudes, opposite signs
    assert res.allocation == pytest.approx(0.0, abs=1e-12)
    assert res.selection == pytest.approx(0.0, abs=1e-12)
    assert res.interaction == pytest.approx(0.0, abs=1e-12)


def test_bhb_rejects_nan_return():
    segs = [
        Segment("A", 0.5, 0.5, float("nan"), 0.05),
        Segment("B", 0.5, 0.5, 0.05, 0.05),
    ]
    with pytest.raises(AttributionError, match="non-finite"):
        bhb(segs)
