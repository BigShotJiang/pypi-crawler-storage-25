"""Multi-level hierarchical attribution tests (T1.1).

These tests verify the v1.1 hierarchical roll-up:

- Single-level (each leaf has an immediate parent, no ``parents`` map)
- Multi-level (leaves under parents under grandparents, via the
  ``parents`` keyword argument on ``bhb`` / ``fachler``)
- Backward compatibility: when no leaf has ``parent`` and ``parents`` is
  not passed, the result is byte-identical to the v1.0 flat shape.

Invariants enforced (per docs/implementation-v1.1.md §T1.1):

- The leaf-level totals match the parent-level totals at every level of
  roll-up to ≤ 1e-12.
- The period-level totals (``allocation``, ``selection``, ``interaction``)
  match the sum of every root-level parent (the trees partition the leaves).
- The identity ``A + S + I == R_p − R_b`` continues to hold at the
  period level.
"""

from __future__ import annotations

import pytest

from pybrinson import AttributionError, Segment, bhb, fachler


# ---------------------------------------------------------------------------
# Single-level hierarchy: each leaf has an immediate parent only.
# ---------------------------------------------------------------------------


def _two_country_segments() -> tuple[Segment, ...]:
    """Two-level fixture: 4 country leaves under 2 region parents."""
    return (
        Segment("UK", 0.20, 0.25, 0.10, 0.08, parent="Europe"),
        Segment("Germany", 0.25, 0.20, 0.05, 0.06, parent="Europe"),
        Segment("US", 0.30, 0.35, 0.12, 0.10, parent="Americas"),
        Segment("Brazil", 0.25, 0.20, -0.04, -0.02, parent="Americas"),
    )


def test_single_level_hierarchy_period_total_unchanged():
    segs = _two_country_segments()
    res = bhb(segs)

    # Period totals are independent of the hierarchy structure.
    flat_segs = tuple(
        Segment(s.name, s.portfolio_weight, s.benchmark_weight, s.portfolio_return, s.benchmark_return)
        for s in segs
    )
    flat_res = bhb(flat_segs)
    assert res.portfolio_return == pytest.approx(flat_res.portfolio_return, abs=1e-12)
    assert res.benchmark_return == pytest.approx(flat_res.benchmark_return, abs=1e-12)
    assert res.excess_return == pytest.approx(flat_res.excess_return, abs=1e-12)
    assert res.allocation == pytest.approx(flat_res.allocation, abs=1e-12)
    assert res.selection == pytest.approx(flat_res.selection, abs=1e-12)
    assert res.interaction == pytest.approx(flat_res.interaction, abs=1e-12)


def test_single_level_parent_totals_equal_sum_of_children():
    res = bhb(_two_country_segments())
    by_name = {s.name: s for s in res.by_segment}

    # Europe parent = UK + Germany
    europe = by_name["Europe"]
    uk = by_name["UK"]
    de = by_name["Germany"]
    assert europe.allocation == pytest.approx(uk.allocation + de.allocation, abs=1e-12)
    assert europe.selection == pytest.approx(uk.selection + de.selection, abs=1e-12)
    assert europe.interaction == pytest.approx(uk.interaction + de.interaction, abs=1e-12)

    # Americas parent = US + Brazil
    am = by_name["Americas"]
    us = by_name["US"]
    br = by_name["Brazil"]
    assert am.allocation == pytest.approx(us.allocation + br.allocation, abs=1e-12)
    assert am.selection == pytest.approx(us.selection + br.selection, abs=1e-12)
    assert am.interaction == pytest.approx(us.interaction + br.interaction, abs=1e-12)


def test_single_level_root_totals_equal_period_totals():
    res = bhb(_two_country_segments())
    by_name = {s.name: s for s in res.by_segment}
    europe = by_name["Europe"]
    am = by_name["Americas"]
    assert europe.allocation + am.allocation == pytest.approx(
        res.allocation, abs=1e-12
    )
    assert europe.selection + am.selection == pytest.approx(res.selection, abs=1e-12)
    assert europe.interaction + am.interaction == pytest.approx(
        res.interaction, abs=1e-12
    )


def test_single_level_hierarchy_levels_and_is_leaf_flags():
    res = bhb(_two_country_segments())
    by_name = {s.name: s for s in res.by_segment}
    # Roots at level 0
    assert by_name["Europe"].level == 0
    assert by_name["Europe"].is_leaf is False
    assert by_name["Americas"].level == 0
    assert by_name["Americas"].is_leaf is False
    # Leaves at level 1 with their parent set
    assert by_name["UK"].level == 1
    assert by_name["UK"].parent == "Europe"
    assert by_name["UK"].is_leaf is True
    assert by_name["Brazil"].parent == "Americas"


# ---------------------------------------------------------------------------
# Multi-level hierarchy: country -> region -> equity, via `parents` mapping.
# ---------------------------------------------------------------------------


def _three_level_segments() -> tuple[Segment, ...]:
    return (
        Segment("UK", 0.20, 0.25, 0.10, 0.08, parent="Europe"),
        Segment("Germany", 0.25, 0.20, 0.05, 0.06, parent="Europe"),
        Segment("US", 0.30, 0.35, 0.12, 0.10, parent="Americas"),
        Segment("Brazil", 0.25, 0.20, -0.04, -0.02, parent="Americas"),
    )


def test_three_level_hierarchy_via_parents_mapping():
    segs = _three_level_segments()
    parents = {"Europe": "Equity", "Americas": "Equity", "Equity": None}
    res = bhb(segs, parents=parents)
    by_name = {s.name: s for s in res.by_segment}

    # Equity is the only root and contains every leaf.
    equity = by_name["Equity"]
    assert equity.level == 0
    assert equity.parent is None
    assert equity.is_leaf is False
    assert equity.allocation == pytest.approx(res.allocation, abs=1e-12)
    assert equity.selection == pytest.approx(res.selection, abs=1e-12)
    assert equity.interaction == pytest.approx(res.interaction, abs=1e-12)

    # Mid-level Europe / Americas at level 1, parent = Equity.
    europe = by_name["Europe"]
    assert europe.level == 1
    assert europe.parent == "Equity"
    am = by_name["Americas"]
    assert am.level == 1
    assert am.parent == "Equity"
    # Their sum equals the root Equity.
    assert europe.allocation + am.allocation == pytest.approx(
        equity.allocation, abs=1e-12
    )

    # Leaves at level 2.
    assert by_name["UK"].level == 2
    assert by_name["UK"].parent == "Europe"


def test_three_level_hierarchy_works_with_fachler():
    segs = _three_level_segments()
    parents = {"Europe": "Equity", "Americas": "Equity", "Equity": None}
    res = fachler(segs, parents=parents)
    by_name = {s.name: s for s in res.by_segment}
    # Identity at the root level.
    assert by_name["Equity"].allocation == pytest.approx(res.allocation, abs=1e-12)
    assert by_name["Equity"].selection == pytest.approx(res.selection, abs=1e-12)
    assert by_name["Equity"].interaction == pytest.approx(res.interaction, abs=1e-12)


# ---------------------------------------------------------------------------
# Backward compatibility: flat input (no parent, no parents kwarg) is unchanged.
# ---------------------------------------------------------------------------


def test_flat_input_byte_identical_to_v1_0():
    flat = (
        Segment("UK Equity", 0.40, 0.40, 0.20, 0.10),
        Segment("Japan Equity", 0.30, 0.20, -0.05, -0.04),
        Segment("US Equity", 0.30, 0.40, 0.06, 0.08),
    )
    res = bhb(flat)
    # Every row is a v1.0-style leaf with no hierarchy decoration.
    for s in res.by_segment:
        assert s.parent is None
        assert s.level == 0
        assert s.is_leaf is True
    # Three rows, no synthetic parents.
    assert len(res.by_segment) == 3


# ---------------------------------------------------------------------------
# Error cases.
# ---------------------------------------------------------------------------


def test_hierarchy_cycle_raises():
    segs = (
        Segment("Toyota", 0.5, 0.5, 0.10, 0.08, parent="Japan"),
        Segment("Sony", 0.5, 0.5, 0.05, 0.06, parent="Japan"),
    )
    parents = {"Japan": "Asia", "Asia": "Japan"}  # cycle
    with pytest.raises(AttributionError, match="cycle"):
        bhb(segs, parents=parents)


def test_dangling_parents_entry_raises():
    segs = (
        Segment("Toyota", 0.5, 0.5, 0.10, 0.08, parent="Japan"),
        Segment("Sony", 0.5, 0.5, 0.05, 0.06, parent="Japan"),
    )
    # "Atlantis" appears in parents but is not reached by any leaf.
    parents = {"Japan": None, "Atlantis": None}
    with pytest.raises(AttributionError, match="Atlantis"):
        bhb(segs, parents=parents)
