"""Multi-period linking methods (Cariño, GRAP, Frongello, geometric).

All take a sequence of :class:`~pybrinson.PeriodAttribution` results
and return a :class:`~pybrinson.LinkedAttribution`. Cariño, GRAP and
Frongello smooth arithmetic effects so that the additive identity
``A + S + I == R_p − R_b`` (compounded) holds within ``1e-9``.
``link_geometric`` uses Bacon's geometric framework where effects
compound multiplicatively; see :func:`link_geometric` for the precise
identity satisfied.

Menchero (2000, 2004) is **not yet shipped**. The Menchero linking
algorithm is patented (US-issued; nominal expiry around the 2019-2024
window per public records) and the v1.1 plan
(``docs/implementation-v1.1.md`` §T1.2 risk #2) requires a primary
patent-status source link in the PR description before the
implementation may merge. Until that verification step is performed,
``link_frongello`` is the recommended drop-in alternative — it carries
no patent encumbrance, closes the additive identity exactly, and
matches Menchero on the compounded portfolio / benchmark returns by
construction.
"""

from .carino import link_carino
from .frongello import link_frongello
from .geometric import link_geometric
from .grap import link_grap

__all__ = ["link_carino", "link_frongello", "link_geometric", "link_grap"]
