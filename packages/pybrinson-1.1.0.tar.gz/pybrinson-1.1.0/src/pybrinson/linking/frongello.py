r"""Frongello recursive multi-period linking of arithmetic effects.

Method
------
Frongello (2002) defines the linked attribution effect recursively. For
periods :math:`t = 1, \dots, T` with single-period arithmetic effect
:math:`a_t` (allocation, selection or interaction):

.. math::

   L_1 &= a_1, \\
   L_t &= a_t \cdot \prod_{s=1}^{t-1}(1 + R_{b,s})
        + L_{t-1} \cdot (1 + R_{p,t}), \qquad t \ge 2.

Unrolling the recursion gives the closed-form scale factor

.. math::

   f_t^{\text{Frongello}} = \prod_{s=1}^{t-1}(1 + R_{b,s}) \cdot
                            \prod_{s=t+1}^{T}(1 + R_{p,s}),

so that the linked effect is the simple weighted sum

.. math::

   L_T = \sum_{t=1}^{T} a_t \cdot f_t^{\text{Frongello}}.

This is the **mirror** of the GRAP factor (which uses
:math:`\prod_{s<t}(1+R_{p,s}) \cdot \prod_{s>t}(1+R_{b,s})`): GRAP carries
prior portfolio returns forward and future benchmark returns back;
Frongello does the opposite. Both methods close the additive identity
exactly without any smoothing residual.

Identity proof (T = 2 sketch)
-----------------------------
With :math:`a_t = R_{p,t} - R_{b,t}`:

.. math::

   L_2 &= (R_{p,2}-R_{b,2})(1+R_{b,1}) + (R_{p,1}-R_{b,1})(1+R_{p,2}) \\
       &= (1+R_{p,1})(1+R_{p,2}) - (1+R_{b,1})(1+R_{b,2}) \\
       &= R_p^{\text{cum}} - R_b^{\text{cum}}.

The cross-terms :math:`-R_{b,1} R_{p,2} + R_{p,2} R_{b,1}` cancel
identically. The same telescoping argument generalises to arbitrary
:math:`T`.

References
----------
Primary:

- Frongello, A. (2002). "Linking Single Period Attribution Results."
  *Journal of Performance Measurement*, 6(3), 10-22.
  Open-access SSRN-style author copy hosted by the Frongello practitioner
  archive (the JPM article itself is paywalled):
  https://www.spauldinggrp.com/wp-content/uploads/2017/02/Linking-Single-Period-Attribution-Results.pdf

Cross-checks (free):

- Bacon, C. R. (2008). *Practical Portfolio Performance Measurement and
  Attribution*, 2nd ed., Wiley, chap. 6, "Frongello smoothing".
  https://www.wiley.com/en-us/Practical+Portfolio+Performance+Measurement+and+Attribution%2C+2nd+Edition-p-9780470059289
- Bacon, C. R. (2019). *Performance Attribution: History and Progress*.
  CFA Institute Research Foundation. Free PDF:
  https://www.cfainstitute.org/-/media/documents/book/rf-publication/2019/rf-v2019-n4-1-pdf.pdf
- EDHEC-Risk Institute, "Multi-period attribution: a survey" (free):
  https://risk.edhec.edu/sites/risk/files/edhec-publication-multi-period-portfolio-performance-attribution.pdf

Sign / convention choices
-------------------------
Frongello (2002) carries *benchmark* returns into the prefix product
and *portfolio* returns into the suffix product. Some practitioner
write-ups present a transposed version (benchmark suffix, portfolio
prefix) — that is the GRAP factor, not Frongello. pybrinson follows
Frongello's original convention to keep the per-period sequence
interpretable as "prior compounding × future portfolio compounding".
"""

from __future__ import annotations

import math
from collections.abc import Sequence

from .._math import check_identity
from .._types import LinkedAttribution, PeriodAttribution
from ..errors import AttributionError


def link_frongello(periods: Sequence[PeriodAttribution]) -> LinkedAttribution:
    """Link a sequence of single-period attributions via Frongello recursion.

    Parameters
    ----------
    periods:
        Output of :func:`~pybrinson.bhb` or :func:`~pybrinson.fachler`,
        one per period, in chronological order. Must contain at least
        two periods (use the :class:`~pybrinson.PeriodAttribution`
        directly for a single period) and all use the same single-period
        method.

    Returns
    -------
    LinkedAttribution
        ``portfolio_return`` and ``benchmark_return`` are the compounded
        single-period returns; ``excess_return = R_p - R_b``; the
        identity ``A + S + I == excess_return`` holds within ``1e-9``.
    """
    if len(periods) < 2:
        raise AttributionError(
            "link_frongello() requires ≥ 2 periods; for a single period "
            "the recursion collapses to the input — use the "
            "PeriodAttribution result directly."
        )
    methods = {p.method for p in periods}
    if len(methods) != 1:
        raise AttributionError(
            f"link_frongello() needs a single attribution method per call; "
            f"got {sorted(methods)!r}"
        )

    n = len(periods)
    # Prefix-of-benchmark: prefix_b[t] = Π_{s<t}(1 + R_b,s).
    prefix_b = [1.0] * n
    for t in range(1, n):
        prefix_b[t] = prefix_b[t - 1] * (1.0 + periods[t - 1].benchmark_return)
    # Suffix-of-portfolio: suffix_p[t] = Π_{s>t}(1 + R_p,s).
    suffix_p = [1.0] * n
    for t in range(n - 2, -1, -1):
        suffix_p[t] = suffix_p[t + 1] * (1.0 + periods[t + 1].portfolio_return)

    alloc = 0.0
    sel = 0.0
    inter = 0.0
    for t, p in enumerate(periods):
        f_t = prefix_b[t] * suffix_p[t]
        alloc += p.allocation * f_t
        sel += p.selection * f_t
        inter += p.interaction * f_t

    log_p = math.fsum(math.log1p(p.portfolio_return) for p in periods)
    log_b = math.fsum(math.log1p(p.benchmark_return) for p in periods)
    r_p_compound = math.expm1(log_p)
    r_b_compound = math.expm1(log_b)
    excess = r_p_compound - r_b_compound

    check_identity(alloc, sel, inter, excess, method="Frongello")

    return LinkedAttribution(
        periods=tuple(periods),
        portfolio_return=r_p_compound,
        benchmark_return=r_b_compound,
        excess_return=excess,
        allocation=alloc,
        selection=sel,
        interaction=inter,
        method="Frongello",
    )
