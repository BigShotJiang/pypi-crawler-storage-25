r"""Public, citable worked-example fixtures for portfolio attribution.

Each function in this submodule returns a small, fully cited worked
example drawn from the academic or practitioner literature on Brinson
attribution. The same fixtures back the test suite — there is one source
of truth, and any change to the expected numbers shows up immediately in
``uv run pytest``.

Why a public fixtures module
----------------------------
No other Python attribution library ships a curated, cited fixture pack
that downstream users can validate their own implementations against.
The goal is for ``pybrinson.fixtures`` to be the educational reference:

>>> from pybrinson import bhb
>>> from pybrinson.fixtures import bacon_2008_ch5_bhb
>>> segments, expected = bacon_2008_ch5_bhb()
>>> result = bhb(segments)
>>> abs(result.excess_return - expected["excess_return"]) < 1e-12
True

Conventions
-----------
Each fixture returns a 2-tuple ``(segments, expected)`` for single-period
examples, or ``(periods, expected)`` for multi-period examples where
``periods`` is a tuple of ``(period_label, segments)`` pairs. The
``expected`` dict contains the totals (``allocation``, ``selection``,
``interaction``, ``excess_return``, ``portfolio_return``,
``benchmark_return``) plus a ``by_segment`` sub-dict keyed on segment
name when relevant.

All numerics are exact rationals expressed as Python floats so that the
identity ``A + S + I == R_p − R_b`` closes to within 1e-12 on every
fixture.

References
----------
The literature URLs cited in each fixture follow the URL preference
order from ``CLAUDE.md``: free PDF on a publisher / institutional page
when available, then DOI / SSRN / JSTOR landing page, then standards
bodies, then long-form practitioner pages.
"""

from __future__ import annotations

from .._types import Segment

__all__ = [
    "bacon_2008_ch5_bhb",
    "bacon_2008_ch5_fachler",
    "two_period_linking_example",
]


def bacon_2008_ch5_bhb() -> tuple[
    tuple[Segment, ...], dict[str, float | dict[str, dict[str, float]]]
]:
    r"""3-sector Brinson-Hood-Beebower worked example.

    Source
    ------
    The canonical UK / Japan / US 3-sector example used as a teaching
    vehicle in:

    - Bacon, C. R. (2008). *Practical Portfolio Performance Measurement
      and Attribution*, 2nd ed., Wiley, chap. 5. ISBN 978-0-470-05928-9.
      https://www.wiley.com/en-us/Practical+Portfolio+Performance+Measurement+and+Attribution%2C+2nd+Edition-p-9780470059289
    - Brinson, G. P., Hood, L. R., & Beebower, G. L. (1986).
      "Determinants of Portfolio Performance." *Financial Analysts
      Journal*, 42(4), 39-44. DOI: https://doi.org/10.2469/faj.v42.n4.39
    - CFA Institute Refresher Reading "Portfolio Performance Evaluation":
      https://www.cfainstitute.org/en/membership/professional-development/refresher-readings/performance-attribution

    Numbers
    -------
    UK : ``w_p = w_b = 0.40``, ``R_p = 20%``, ``R_b = 10%``
    JP : ``w_p = 0.30``, ``w_b = 0.20``, ``R_p = -5%``, ``R_b = -4%``
    US : ``w_p = 0.30``, ``w_b = 0.40``, ``R_p = 6%``, ``R_b = 8%``

    Aggregates: ``R_p = 8.3%``, ``R_b = 6.4%``, ``excess = 1.9%``.
    """
    segments = (
        Segment("UK Equity", 0.40, 0.40, 0.20, 0.10),
        Segment("Japan Equity", 0.30, 0.20, -0.05, -0.04),
        Segment("US Equity", 0.30, 0.40, 0.06, 0.08),
    )
    expected: dict[str, float | dict[str, dict[str, float]]] = {
        "portfolio_return": 0.083,
        "benchmark_return": 0.064,
        "excess_return": 0.019,
        # Hand-derived from the BHB formulas A=(w_p-w_b)R_b, S=w_b(R_p-R_b),
        # I=(w_p-w_b)(R_p-R_b). Identity: A+S+I == 0.019.
        "allocation": (0.30 - 0.20) * -0.04 + (0.30 - 0.40) * 0.08,
        "selection": 0.40 * (0.20 - 0.10)
        + 0.20 * (-0.05 - -0.04)
        + 0.40 * (0.06 - 0.08),
        "interaction": (0.30 - 0.20) * (-0.05 - -0.04)
        + (0.30 - 0.40) * (0.06 - 0.08),
        "by_segment": {
            "UK Equity": {
                "allocation": 0.0,
                "selection": 0.40 * (0.20 - 0.10),
                "interaction": 0.0,
            },
            "Japan Equity": {
                "allocation": (0.30 - 0.20) * -0.04,
                "selection": 0.20 * (-0.05 - -0.04),
                "interaction": (0.30 - 0.20) * (-0.05 - -0.04),
            },
            "US Equity": {
                "allocation": (0.30 - 0.40) * 0.08,
                "selection": 0.40 * (0.06 - 0.08),
                "interaction": (0.30 - 0.40) * (0.06 - 0.08),
            },
        },
    }
    return segments, expected


def bacon_2008_ch5_fachler() -> tuple[
    tuple[Segment, ...], dict[str, float | dict[str, dict[str, float]]]
]:
    r"""3-sector Brinson-Fachler worked example.

    Same input segments as :func:`bacon_2008_ch5_bhb`; only the
    allocation formula differs:

    .. math::

        A_i = (w_{p,i} - w_{b,i}) \cdot (R_{b,i} - R_b)

    where :math:`R_b = 6.4\%` is the total benchmark return.

    Source
    ------
    - Brinson, G. P., & Fachler, N. (1985). "Measuring Non-U.S. Equity
      Portfolio Performance." *Journal of Portfolio Management*, 11(3),
      73-76. DOI: https://doi.org/10.3905/jpm.1985.409005
    - Bacon (2008), op. cit., chap. 5.
    """
    segments = (
        Segment("UK Equity", 0.40, 0.40, 0.20, 0.10),
        Segment("Japan Equity", 0.30, 0.20, -0.05, -0.04),
        Segment("US Equity", 0.30, 0.40, 0.06, 0.08),
    )
    r_b_total = 0.064
    expected: dict[str, float | dict[str, dict[str, float]]] = {
        "portfolio_return": 0.083,
        "benchmark_return": r_b_total,
        "excess_return": 0.019,
        # BF allocation totals coincide with BHB because the extra term
        # Σ(w_p - w_b)·R_b = R_b·Σ(w_p - w_b) = 0 when both vectors sum to 1.
        "allocation": (0.30 - 0.20) * (-0.04 - r_b_total)
        + (0.30 - 0.40) * (0.08 - r_b_total),
        "selection": 0.40 * (0.20 - 0.10)
        + 0.20 * (-0.05 - -0.04)
        + 0.40 * (0.06 - 0.08),
        "interaction": (0.30 - 0.20) * (-0.05 - -0.04)
        + (0.30 - 0.40) * (0.06 - 0.08),
        "by_segment": {
            "UK Equity": {
                "allocation": 0.0,
                "selection": 0.40 * (0.20 - 0.10),
                "interaction": 0.0,
            },
            "Japan Equity": {
                "allocation": (0.30 - 0.20) * (-0.04 - r_b_total),
                "selection": 0.20 * (-0.05 - -0.04),
                "interaction": (0.30 - 0.20) * (-0.05 - -0.04),
            },
            "US Equity": {
                "allocation": (0.30 - 0.40) * (0.08 - r_b_total),
                "selection": 0.40 * (0.06 - 0.08),
                "interaction": (0.30 - 0.40) * (0.06 - 0.08),
            },
        },
    }
    return segments, expected


def two_period_linking_example() -> tuple[
    tuple[tuple[str, tuple[Segment, ...]], ...],
    dict[str, float],
]:
    r"""2-period 2-sector example used by every linking method's tests.

    The example is small enough to derive every linking method by hand.
    Each per-period attribution closes the BHB identity exactly, and
    each linking method (Cariño, GRAP, geometric, Menchero, Frongello)
    can be applied to the same input — which is why this fixture also
    backs ``tests/consistency/`` in pybrinson v1.1.

    Per-period BHB results
    ----------------------
    P1: ``A = -0.5%, S = 0, I = +1.0%, excess = +0.5%``
    P2: ``A = 0,    S = +2.5%, I = 0, excess = +2.5%``

    Compounded: ``R_p = 21.5%``, ``R_b = 18.25%``, arithmetic excess
    ``= 3.25%``, geometric excess ``= (1.215 / 1.1825) − 1 ≈ 2.7484%``.

    Source
    ------
    Hand-constructed from the Brinson-Hood-Beebower formulas in
    Bacon (2008) chap. 5 so that every effect is non-degenerate yet the
    arithmetic remains tractable. Used as a cross-method consistency
    fixture in pybrinson v1.1 — see ``docs/implementation-v1.1.md`` T1.3.

    Linking method references:

    - Cariño, D. R. (1999). "Combining Attribution Effects Over Time."
      *Journal of Performance Measurement*, 3(4), 5-14.
      https://www.russellinvestments.com/-/media/files/us/insights/institutions/strategic-research/combining-attribution-effects-over-time.pdf
    - Bacon, C. R. (2019). *Performance Attribution: History and
      Progress*. CFA Institute Research Foundation. Free PDF:
      https://www.cfainstitute.org/-/media/documents/book/rf-publication/2019/rf-v2019-n4-1-pdf.pdf
    """
    p1 = (
        Segment("A", 0.6, 0.5, 0.10, 0.05),
        Segment("B", 0.4, 0.5, 0.05, 0.10),
    )
    p2 = (
        Segment("A", 0.5, 0.5, 0.20, 0.10),
        Segment("B", 0.5, 0.5, 0.05, 0.10),
    )
    periods = (("P1", p1), ("P2", p2))
    expected = {
        # Per-period BHB totals
        "p1_excess": 0.005,
        "p2_excess": 0.025,
        # Compounded
        "compounded_portfolio_return": 1.08 * 1.125 - 1.0,  # 0.215
        "compounded_benchmark_return": 1.075 * 1.10 - 1.0,  # 0.1825
        "arithmetic_excess": (1.08 * 1.125) - (1.075 * 1.10),  # 0.0325
        "geometric_excess": (1.215 / 1.1825) - 1.0,
    }
    return periods, expected
