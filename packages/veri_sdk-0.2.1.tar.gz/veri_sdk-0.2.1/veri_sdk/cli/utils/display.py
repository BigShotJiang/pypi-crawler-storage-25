"""Output rendering — reads --format/--quiet from click ctx.meta, switches between Rich table and JSON/JSONL/CSV."""

from __future__ import annotations

import csv
import json
import sys
from typing import Any

import click
from rich.console import Console
from rich.table import Table


def _ctx_meta(key: str, default: Any = None) -> Any:
    ctx = click.get_current_context(silent=True)
    while ctx is not None:
        if key in ctx.meta:
            return ctx.meta[key]
        ctx = ctx.parent
    return default


def get_format() -> str:
    return _ctx_meta("format", "table")


def is_quiet() -> bool:
    return bool(_ctx_meta("quiet", False))


def stderr() -> Console:
    return Console(stderr=True)


def stdout() -> Console:
    return Console()


def render(
    rows: list[dict] | dict,
    columns: list[tuple[str, str]] | None = None,
    title: str = "",
) -> None:
    """Render a list of dicts (or single dict) in the user-selected format.

    Single-dict callers (e.g. `veri version`) get a single JSON object on
    `--format json`, not a 1-element list. Tables always wrap to a row list.

    columns: list of (header, rich-style). Used only for table + csv outputs.
    """
    fmt = get_format()
    is_single = isinstance(rows, dict)

    if fmt == "json":
        sys.stdout.write(json.dumps(rows, indent=2, default=str) + "\n")
        return
    if fmt == "jsonl":
        if is_single:
            sys.stdout.write(json.dumps(rows, default=str) + "\n")
        else:
            for row in rows:
                sys.stdout.write(json.dumps(row, default=str) + "\n")
        return

    # table + csv both need a row list.
    row_list: list[dict] = [rows] if is_single else list(rows)
    cols = columns or [(k, "") for k in (row_list[0].keys() if row_list else [])]

    if fmt == "csv":
        writer = csv.DictWriter(sys.stdout, fieldnames=[c[0] for c in cols])
        writer.writeheader()
        for row in row_list:
            writer.writerow({c[0]: row.get(c[0], "") for c in cols})
        return

    table = Table(title=title or None, show_lines=False)
    for header, style in cols:
        table.add_column(header, style=style or "")
    for row in row_list:
        table.add_row(*[str(row.get(h, "")) for h, _ in cols])
    stdout().print(table)


def render_id(resource_id: str) -> None:
    """Emit just the resource id (for --quiet pipe-friendly mode).

    Falls back to render({"id": resource_id}) when not quiet.
    """
    if is_quiet():
        sys.stdout.write(resource_id + "\n")
    else:
        render({"id": resource_id})


def echo(message: str, err: bool = False) -> None:
    """Write a status line, but suppress under --quiet or --format json/jsonl/csv."""
    if is_quiet() or get_format() != "table":
        return
    target = stderr() if err else stdout()
    target.print(message)
