"""Veri Python SDK client."""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

import httpx


@dataclass
class Dataset:
    id: str
    name: str
    source_type: str = "upload"
    source_uri: str | None = None
    huggingface_dataset: str | None = None


@dataclass
class RewardFunction:
    id: str
    name: str
    format: str = "trl"


@dataclass
class TrainingJob:
    id: str
    status: str
    base_model: str
    dashboard_url: str | None
    download_url: str | None
    error: dict | None
    cost_usd: float | None
    _client: "Client"

    @property
    def error_message(self) -> str | None:
        if self.error:
            return self.error.get("message")
        return None

    def wait(self, poll_interval: int = 10, timeout: int = 86400) -> "TrainingJob":
        """Poll until job completes or fails."""
        start = time.time()
        while time.time() - start < timeout:
            job = self._client.training_jobs.get(self.id)
            self.status = job.status
            self.dashboard_url = job.dashboard_url
            self.download_url = job.download_url
            self.error = job.error

            if self.status in ("completed", "failed", "cancelled"):
                return self
            time.sleep(poll_interval)
        raise TimeoutError(f"Job {self.id} did not complete within {timeout}s")

    def download(self, output_dir: str) -> str:
        """Download the final HF checkpoint."""
        if not self.download_url:
            raise ValueError("No download URL — job may not be completed")
        resp = httpx.get(self.download_url, follow_redirects=True)
        resp.raise_for_status()
        out = Path(output_dir) / f"{self.id}"
        out.mkdir(parents=True, exist_ok=True)
        (out / "model.safetensors").write_bytes(resp.content)
        return str(out)


@dataclass
class Deployment:
    id: str
    status: str
    name: str
    model: str
    source: str
    endpoint_url: str | None
    gpu: dict | None
    provider: str | None
    cost_per_hour_usd: float | None
    total_cost_usd: float | None
    total_requests: int
    error: str | None
    _client: "Client"

    def wait(self, poll_interval: int = 10, timeout: int = 3600) -> "Deployment":
        """Poll until deployment is serving (or reaches a terminal failure state)."""
        start = time.time()
        while time.time() - start < timeout:
            dep = self._client.deployments.get(self.id)
            self.status = dep.status
            self.endpoint_url = dep.endpoint_url
            self.error = dep.error
            if self.status in ("serving", "failed", "stopped"):
                return self
            time.sleep(poll_interval)
        raise TimeoutError(f"Deployment {self.id} did not reach serving within {timeout}s")

    def stop(self) -> "Deployment":
        return self._client.deployments.stop(self.id)

    def chat(
        self,
        messages: list[dict],
        *,
        model: str | None = None,
        temperature: float = 1.0,
        max_tokens: int | None = None,
    ) -> dict:
        """Send an OpenAI-compatible chat/completions request to this deployment."""
        return self._client.deployments.chat(
            self.id,
            messages=messages,
            model=model or self.name,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    def metrics(self) -> dict:
        return self._client.deployments.metrics(self.id)

    def requests(self, limit: int = 50, after: str | None = None) -> list[dict]:
        return self._client.deployments.requests(self.id, limit=limit, after=after)


class _Datasets:
    def __init__(self, http: httpx.Client):
        self._http = http

    def upload(self, path: str, name: str | None = None) -> Dataset:
        p = Path(path)
        name = name or p.stem
        with open(p, "rb") as f:
            resp = self._http.post(
                "/v1/datasets",
                data={"name": name},
                files={"file": (p.name, f, "application/jsonl")},
            )
        resp.raise_for_status()
        return self._parse(resp.json())

    def get(self, dataset_id: str) -> Dataset:
        resp = self._http.get(f"/v1/datasets/{dataset_id}")
        resp.raise_for_status()
        return self._parse(resp.json())

    def list(self, limit: int = 20, after: str | None = None) -> list[Dataset]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get("/v1/datasets", params=params)
        resp.raise_for_status()
        return [self._parse(d) for d in resp.json()["data"]]

    def connect(
        self,
        name: str,
        source_type: str,
        source_uri: str | None = None,
        huggingface_dataset: str | None = None,
        huggingface_config: dict | None = None,
        db_connection: str | None = None,
        db_query: str | None = None,
        credentials: dict | None = None,
    ) -> Dataset:
        body: dict = {"name": name, "source_type": source_type}
        if source_uri:
            body["source_uri"] = source_uri
        if huggingface_dataset:
            body["huggingface_dataset"] = huggingface_dataset
        if huggingface_config:
            body["huggingface_config"] = huggingface_config
        if db_connection:
            body["db_connection"] = db_connection
        if db_query:
            body["db_query"] = db_query
        if credentials:
            body["credentials"] = credentials
        resp = self._http.post("/v1/datasets/connect", json=body)
        resp.raise_for_status()
        return self._parse(resp.json())

    def validate(self, **kwargs) -> dict:
        resp = self._http.post("/v1/datasets/connect/validate", json=kwargs)
        resp.raise_for_status()
        return resp.json()

    def delete(self, dataset_id: str) -> None:
        resp = self._http.delete(f"/v1/datasets/{dataset_id}")
        resp.raise_for_status()

    def _parse(self, d: dict) -> Dataset:
        return Dataset(
            id=d["id"], name=d["name"],
            source_type=d.get("source_type", "upload"),
            source_uri=d.get("source_uri"),
            huggingface_dataset=d.get("huggingface_dataset"),
        )


class _RewardFunctions:
    def __init__(self, http: httpx.Client):
        self._http = http

    def upload(self, path: str, name: str | None = None, format: str = "trl") -> RewardFunction:
        p = Path(path)
        name = name or p.stem
        with open(p, "rb") as f:
            resp = self._http.post(
                "/v1/reward_functions",
                data={"name": name, "format": format},
                files={"file": (p.name, f, "text/x-python")},
            )
        resp.raise_for_status()
        d = resp.json()
        return RewardFunction(id=d["id"], name=d["name"], format=d.get("format", "trl"))

    def get(self, reward_id: str) -> RewardFunction:
        resp = self._http.get(f"/v1/reward_functions/{reward_id}")
        resp.raise_for_status()
        d = resp.json()
        return RewardFunction(id=d["id"], name=d["name"], format=d.get("format", "trl"))

    def list(self, limit: int = 20, after: str | None = None) -> list[RewardFunction]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get("/v1/reward_functions", params=params)
        resp.raise_for_status()
        return [
            RewardFunction(id=d["id"], name=d["name"], format=d.get("format", "trl"))
            for d in resp.json()["data"]
        ]

    def delete(self, reward_id: str) -> None:
        resp = self._http.delete(f"/v1/reward_functions/{reward_id}")
        resp.raise_for_status()


class _TrainingJobs:
    def __init__(self, http: httpx.Client, client: "Client"):
        self._http = http
        self._client = client

    def create(
        self,
        base_model: str,
        dataset_id: str,
        output_name: str = "default",
        *,
        gpu_type: str,
        gpu_count: int,
        reward_function_id: str | None = None,
        method: str = "grpo",
        hyperparameters: dict | None = None,
        provider: str | None = None,
        checkpoint_destination: dict | None = None,
    ) -> TrainingJob:
        body: dict = {
            "base_model": base_model,
            "dataset_id": dataset_id,
            "output_name": output_name,
            "method": method,
            "hyperparameters": hyperparameters or {},
            "gpu": {"gpu_type": gpu_type, "gpu_count": gpu_count},
            "checkpoint_destination": checkpoint_destination or {"type": "veri"},
        }
        if reward_function_id:
            body["reward_function_id"] = reward_function_id
        if provider:
            body["provider"] = provider
        resp = self._http.post("/v1/training_jobs", json=body)
        resp.raise_for_status()
        return self._parse(resp.json())

    def get(self, job_id: str) -> TrainingJob:
        resp = self._http.get(f"/v1/training_jobs/{job_id}")
        resp.raise_for_status()
        return self._parse(resp.json())

    def list(self, limit: int = 20, after: str | None = None, status: str | None = None, method: str | None = None) -> list[TrainingJob]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        if status:
            params["status"] = status
        if method:
            params["method"] = method
        resp = self._http.get("/v1/training_jobs", params=params)
        resp.raise_for_status()
        return [self._parse(d) for d in resp.json()["data"]]

    def cancel(self, job_id: str) -> TrainingJob:
        resp = self._http.post(f"/v1/training_jobs/{job_id}/cancel")
        resp.raise_for_status()
        return self._parse(resp.json())

    def _parse(self, d: dict) -> TrainingJob:
        return TrainingJob(
            id=d["id"],
            status=d["status"],
            base_model=d["base_model"],
            dashboard_url=d.get("dashboard_url"),
            download_url=d.get("download_url"),
            error=d.get("error"),
            cost_usd=d.get("cost_usd"),
            _client=self._client,
        )


class _Cost:
    def __init__(self, http: httpx.Client):
        self._http = http

    def estimate(
        self,
        gpu_type: str,
        gpu_count: int = 1,
        duration_minutes: int = 60,
        provider: str | None = None,
        markup: float = 1.3,
    ) -> dict:
        """Estimate job cost before submission."""
        params = {
            "gpu_type": gpu_type,
            "gpu_count": gpu_count,
            "duration_minutes": duration_minutes,
            "markup": markup,
        }
        if provider:
            params["provider"] = provider
        resp = self._http.get("/v1/cost/estimate", params=params)
        resp.raise_for_status()
        return resp.json()

    def rates(self) -> dict:
        """Get all GPU rates across providers."""
        resp = self._http.get("/v1/cost/rates")
        resp.raise_for_status()
        return resp.json()

    def summary(self, days: int = 30) -> dict:
        """Get spend summary for the authenticated user."""
        resp = self._http.get("/v1/cost/summary", params={"days": days})
        resp.raise_for_status()
        return resp.json()

    def compare(self, gpu_type: str, gpu_count: int = 1, duration_minutes: int = 60) -> dict:
        """Compare cost across providers for a given GPU config."""
        resp = self._http.get("/v1/cost/compare", params={
            "gpu_type": gpu_type, "gpu_count": gpu_count, "duration_minutes": duration_minutes,
        })
        resp.raise_for_status()
        return resp.json()


class _Deployments:
    def __init__(self, http: httpx.Client, client: "Client"):
        self._http = http
        self._client = client

    def create(
        self,
        model: str,
        name: str,
        *,
        gpu: dict,
        source: str = "training_job",
        provider: str | None = None,
    ) -> Deployment:
        """Create an inference deployment.

        Args:
            model: Training job ID (when source="training_job") or HuggingFace
                model name (when source="huggingface").
            name: Display name for the endpoint.
            gpu: {"gpu_type": str, "gpu_count": int}.
            source: "training_job" or "huggingface".
            provider: Optional compute provider; auto-selects if omitted.
        """
        body: dict = {
            "model": model,
            "name": name,
            "source": source,
            "gpu": gpu,
        }
        if provider:
            body["provider"] = provider
        resp = self._http.post("/v1/deployments", json=body)
        resp.raise_for_status()
        return self._parse(resp.json())

    def get(self, deployment_id: str) -> Deployment:
        resp = self._http.get(f"/v1/deployments/{deployment_id}")
        resp.raise_for_status()
        return self._parse(resp.json())

    def list(
        self,
        limit: int = 20,
        after: str | None = None,
        status: str | None = None,
    ) -> list[Deployment]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        if status:
            params["status"] = status
        resp = self._http.get("/v1/deployments", params=params)
        resp.raise_for_status()
        return [self._parse(d) for d in resp.json()["data"]]

    def stop(self, deployment_id: str) -> Deployment:
        resp = self._http.post(f"/v1/deployments/{deployment_id}/stop")
        resp.raise_for_status()
        return self._parse(resp.json())

    def chat(
        self,
        deployment_id: str,
        messages: list[dict],
        *,
        model: str,
        temperature: float = 1.0,
        max_tokens: int | None = None,
    ) -> dict:
        body: dict = {"model": model, "messages": messages, "temperature": temperature}
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        resp = self._http.post(
            f"/v1/deployments/{deployment_id}/chat/completions", json=body
        )
        resp.raise_for_status()
        return resp.json()

    def metrics(self, deployment_id: str) -> dict:
        resp = self._http.get(f"/v1/deployments/{deployment_id}/metrics")
        resp.raise_for_status()
        return resp.json()

    def requests(
        self, deployment_id: str, limit: int = 50, after: str | None = None
    ) -> list[dict]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get(
            f"/v1/deployments/{deployment_id}/requests", params=params
        )
        resp.raise_for_status()
        return resp.json()["data"]

    def _parse(self, d: dict) -> Deployment:
        return Deployment(
            id=d["id"],
            status=d["status"],
            name=d["name"],
            model=d["model"],
            source=d["source"],
            endpoint_url=d.get("endpoint_url"),
            gpu=d.get("gpu"),
            provider=d.get("provider"),
            cost_per_hour_usd=d.get("cost_per_hour_usd"),
            total_cost_usd=d.get("total_cost_usd"),
            total_requests=d.get("total_requests", 0),
            error=d.get("error"),
            _client=self._client,
        )


class _Billing:
    def __init__(self, http: httpx.Client):
        self._http = http

    def balance(self) -> dict:
        """Get current credit balance."""
        resp = self._http.get("/v1/billing/balance")
        resp.raise_for_status()
        return resp.json()

    def transactions(self, limit: int = 20) -> dict:
        """Get recent billing transactions."""
        resp = self._http.get("/v1/billing/transactions", params={"limit": limit})
        resp.raise_for_status()
        return resp.json()

    def burn_rate(self) -> dict:
        """Get current burn rate and estimated time remaining."""
        resp = self._http.get("/v1/billing/burn_rate")
        resp.raise_for_status()
        return resp.json()


@dataclass
class Eval:
    id: str
    name: str
    dataset_id: str
    scorers: list[dict]
    created_at: str | None = None


@dataclass
class EvalRun:
    id: str
    eval_id: str
    model: str
    status: str
    processed_items: int | None = None
    total_items: int | None = None
    results: dict | None = None
    error_message: str | None = None
    created_at: str | None = None
    completed_at: str | None = None
    _client: "Client | None" = None

    def wait(self, poll_interval: float = 5.0, timeout: float | None = None) -> "EvalRun":
        if self._client is None:
            raise RuntimeError("EvalRun is detached from a Client; call client.evals.runs.wait() instead.")
        return self._client.evals.runs.wait(
            self.eval_id, self.id, poll_interval=poll_interval, timeout=timeout
        )


@dataclass
class EvalRunItem:
    id: str
    run_id: str
    item_index: int
    input: str
    output: str
    label: str | None
    scores: dict
    latency_ms: float | None = None


class _EvalRuns:
    def __init__(self, http: httpx.Client, client: "Client"):
        self._http = http
        self._client = client

    def create(
        self,
        eval_id: str,
        model: str,
        *,
        num_samples: int | None = None,
        generation_params: dict | None = None,
    ) -> EvalRun:
        body: dict = {"model": model}
        if num_samples is not None:
            body["num_samples"] = num_samples
        if generation_params is not None:
            body["generation_params"] = generation_params
        resp = self._http.post(f"/v1/evals/{eval_id}/runs", json=body)
        resp.raise_for_status()
        return self._parse(resp.json())

    def get(self, eval_id: str, run_id: str) -> EvalRun:
        resp = self._http.get(f"/v1/evals/{eval_id}/runs/{run_id}")
        resp.raise_for_status()
        return self._parse(resp.json())

    def list(
        self, eval_id: str, limit: int = 20, after: str | None = None
    ) -> list[EvalRun]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get(f"/v1/evals/{eval_id}/runs", params=params)
        resp.raise_for_status()
        return [self._parse(d) for d in resp.json()["data"]]

    def items(
        self,
        eval_id: str,
        run_id: str,
        limit: int = 50,
        after: str | None = None,
    ) -> list[EvalRunItem]:
        params: dict = {"limit": limit}
        if after is not None:
            params["after"] = after
        resp = self._http.get(f"/v1/evals/{eval_id}/runs/{run_id}/items", params=params)
        resp.raise_for_status()
        return [
            EvalRunItem(
                id=d["id"],
                run_id=d["run_id"],
                item_index=d["item_index"],
                input=d["input"],
                output=d["output"],
                label=d.get("label"),
                scores=d.get("scores") or {},
                latency_ms=d.get("latency_ms"),
            )
            for d in resp.json()["data"]
        ]

    def cancel(self, eval_id: str, run_id: str) -> EvalRun:
        resp = self._http.post(f"/v1/evals/{eval_id}/runs/{run_id}/cancel")
        resp.raise_for_status()
        return self._parse(resp.json())

    def wait(
        self,
        eval_id: str,
        run_id: str,
        poll_interval: float = 5.0,
        timeout: float | None = None,
    ) -> EvalRun:
        """Poll GET /v1/evals/{id}/runs/{run_id} until terminal."""
        start = time.time()
        terminal = {"completed", "failed", "cancelled"}
        while True:
            run = self.get(eval_id, run_id)
            if run.status in terminal:
                return run
            if timeout is not None and (time.time() - start) > timeout:
                raise TimeoutError(
                    f"Run {run_id} did not reach terminal state within {timeout}s "
                    f"(last status: {run.status})"
                )
            time.sleep(poll_interval)

    def _parse(self, d: dict) -> EvalRun:
        return EvalRun(
            id=d["id"],
            eval_id=d["eval_id"],
            model=d["model"],
            status=d["status"],
            processed_items=d.get("processed_items"),
            total_items=d.get("total_items"),
            results=d.get("results"),
            error_message=d.get("error_message"),
            created_at=d.get("created_at"),
            completed_at=d.get("completed_at"),
            _client=self._client,
        )


class _Evals:
    def __init__(self, http: httpx.Client, client: "Client"):
        self._http = http
        self._client = client
        self.runs = _EvalRuns(http, client)

    def create(
        self,
        name: str,
        dataset_id: str,
        scorers: list[dict],
        *,
        generation_params: dict | None = None,
    ) -> Eval:
        body: dict = {"name": name, "dataset_id": dataset_id, "scorers": scorers}
        if generation_params is not None:
            body["generation_params"] = generation_params
        resp = self._http.post("/v1/evals", json=body)
        resp.raise_for_status()
        return self._parse(resp.json())

    def get(self, eval_id: str) -> Eval:
        resp = self._http.get(f"/v1/evals/{eval_id}")
        resp.raise_for_status()
        return self._parse(resp.json())

    def list(self, limit: int = 20, after: str | None = None) -> list[Eval]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get("/v1/evals", params=params)
        resp.raise_for_status()
        return [self._parse(d) for d in resp.json()["data"]]

    def delete(self, eval_id: str) -> None:
        resp = self._http.delete(f"/v1/evals/{eval_id}")
        resp.raise_for_status()

    def _parse(self, d: dict) -> Eval:
        return Eval(
            id=d["id"],
            name=d["name"],
            dataset_id=d["dataset_id"],
            scorers=d.get("scorers") or [],
            created_at=d.get("created_at"),
        )


class Client:
    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        # Auto-load from ~/.veri/credentials.json if not provided
        if not api_key or not base_url:
            import json as _json
            creds_file = Path.home() / ".veri" / "credentials.json"
            if creds_file.exists():
                creds = _json.loads(creds_file.read_text())
                api_key = api_key or creds.get("api_key")
                base_url = base_url or creds.get("api_url")
        if not api_key:
            raise ValueError(
                "No API key provided. Either pass api_key= or run 'veri login' first."
            )
        base_url = base_url or "https://api.veri.studio"

        self._http = httpx.Client(
            base_url=base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=60,
        )
        self.datasets = _Datasets(self._http)
        self.reward_functions = _RewardFunctions(self._http)
        self.training_jobs = _TrainingJobs(self._http, self)
        self.deployments = _Deployments(self._http, self)
        self.evals = _Evals(self._http, self)
        self.cost = _Cost(self._http)
        self.billing = _Billing(self._http)
