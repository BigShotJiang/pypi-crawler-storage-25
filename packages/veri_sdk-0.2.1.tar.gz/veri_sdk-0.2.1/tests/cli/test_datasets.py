"""Tests for veri_sdk.cli.commands.datasets — CLI sub-app + SDK plumbing."""

from __future__ import annotations

import json
from unittest.mock import MagicMock

from typer.testing import CliRunner

from veri_sdk.cli.commands import datasets as ds_mod
from veri_sdk.cli.main import app

runner = CliRunner()


def _stub_client(monkeypatch) -> MagicMock:
    """Replace get_client() with a MagicMock for the duration of the test."""
    client = MagicMock()
    monkeypatch.setattr(ds_mod, "get_client", lambda: client)
    return client


def _make_dataset(id_="ds_abc", name="my-set", source_type="upload"):
    ds = MagicMock()
    ds.id = id_
    ds.name = name
    ds.source_type = source_type
    ds.source_uri = None
    ds.huggingface_dataset = None
    return ds


# ---------- upload ----------

def test_upload_runs_check_then_uploads(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.datasets.upload.return_value = _make_dataset()
    f = tmp_path / "data.jsonl"
    f.write_text('{"prompt": "hi", "answer": "ok"}\n')

    result = runner.invoke(app, ["datasets", "upload", str(f)])
    assert result.exit_code == 0, result.stdout
    client.datasets.upload.assert_called_once()
    args, kwargs = client.datasets.upload.call_args
    # path is positional; name defaults from filename stem.
    assert args[0] == str(f)


def test_upload_fails_on_malformed_jsonl(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    f = tmp_path / "bad.jsonl"
    f.write_text("not valid json\n")

    result = runner.invoke(app, ["datasets", "upload", str(f)])
    assert result.exit_code != 0
    client.datasets.upload.assert_not_called()


def test_upload_skip_validation_skips_check(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.datasets.upload.return_value = _make_dataset()
    f = tmp_path / "bad.jsonl"
    f.write_text("not valid json\n")

    result = runner.invoke(app, ["datasets", "upload", str(f), "--skip-validation"])
    assert result.exit_code == 0, result.stdout
    client.datasets.upload.assert_called_once()


def test_upload_quiet_emits_only_id(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.datasets.upload.return_value = _make_dataset(id_="ds_xyz")
    f = tmp_path / "ok.jsonl"
    f.write_text('{"a": 1}\n')

    result = runner.invoke(app, ["datasets", "upload", str(f), "--quiet"])
    assert result.exit_code == 0
    assert result.stdout.strip() == "ds_xyz"


# ---------- check ----------

def test_check_standalone_passes(tmp_path):
    f = tmp_path / "ok.jsonl"
    f.write_text('{"a": 1}\n{"a": 2}\n')
    result = runner.invoke(app, ["datasets", "check", str(f)])
    assert result.exit_code == 0
    assert "OK" in result.stdout or "2 rows" in result.stdout


def test_check_standalone_fails_with_errors(tmp_path):
    f = tmp_path / "bad.jsonl"
    f.write_text("not json\n")
    result = runner.invoke(app, ["datasets", "check", str(f)])
    assert result.exit_code != 0


# ---------- list / get / delete ----------

def test_list_renders_rows(monkeypatch):
    client = _stub_client(monkeypatch)
    client.datasets.list.return_value = [
        _make_dataset(id_="ds_a", name="alpha"),
        _make_dataset(id_="ds_b", name="beta"),
    ]

    result = runner.invoke(app, ["datasets", "list", "--format", "json"])
    assert result.exit_code == 0, result.stdout
    rows = json.loads(result.stdout)
    assert {r["id"] for r in rows} == {"ds_a", "ds_b"}


def test_get_renders_single(monkeypatch):
    client = _stub_client(monkeypatch)
    client.datasets.get.return_value = _make_dataset(id_="ds_xyz", name="x")

    result = runner.invoke(app, ["datasets", "get", "ds_xyz", "--format", "json"])
    assert result.exit_code == 0
    row = json.loads(result.stdout)
    assert row["id"] == "ds_xyz"
    client.datasets.get.assert_called_once_with("ds_xyz")


def test_delete_calls_client(monkeypatch):
    client = _stub_client(monkeypatch)
    result = runner.invoke(app, ["datasets", "delete", "ds_xyz"])
    assert result.exit_code == 0
    client.datasets.delete.assert_called_once_with("ds_xyz")


# ---------- connect-* ----------

def test_connect_hf(monkeypatch):
    client = _stub_client(monkeypatch)
    client.datasets.connect.return_value = _make_dataset(id_="ds_hf", source_type="hf")

    result = runner.invoke(
        app,
        ["datasets", "connect-hf", "openai/gsm8k", "--split", "train", "--name", "gsm8k-train"],
    )
    assert result.exit_code == 0, result.stdout
    _, kwargs = client.datasets.connect.call_args
    assert kwargs["source_type"] == "hf"
    assert kwargs["huggingface_dataset"] == "openai/gsm8k"
    assert kwargs["huggingface_config"]["split"] == "train"
    assert kwargs["name"] == "gsm8k-train"


def test_connect_s3(monkeypatch):
    client = _stub_client(monkeypatch)
    client.datasets.connect.return_value = _make_dataset(id_="ds_s3", source_type="s3")

    result = runner.invoke(
        app,
        ["datasets", "connect-s3", "s3://bucket/data.jsonl", "--name", "my-s3"],
    )
    assert result.exit_code == 0, result.stdout
    _, kwargs = client.datasets.connect.call_args
    assert kwargs["source_type"] == "s3"
    assert kwargs["source_uri"] == "s3://bucket/data.jsonl"


def test_connect_postgres_requires_query():
    result = runner.invoke(
        app,
        ["datasets", "connect-postgres", "postgres://localhost/db"],
    )
    # --query is required.
    assert result.exit_code != 0


def test_connect_postgres(monkeypatch):
    client = _stub_client(monkeypatch)
    client.datasets.connect.return_value = _make_dataset(id_="ds_pg", source_type="postgres")

    result = runner.invoke(
        app,
        [
            "datasets",
            "connect-postgres",
            "postgres://localhost/db",
            "--query",
            "SELECT * FROM training",
            "--name",
            "pg-set",
        ],
    )
    assert result.exit_code == 0, result.stdout
    _, kwargs = client.datasets.connect.call_args
    assert kwargs["source_type"] == "postgres"
    assert kwargs["db_query"] == "SELECT * FROM training"


# ---------- group help ----------

def test_datasets_group_no_args_shows_help():
    """Group without a subcommand prints help. Click 9.x exits 2; older exits 0.
    Either is fine — the contract is 'help is visible'."""
    result = runner.invoke(app, ["datasets"])
    assert result.exit_code in (0, 2)
    # Help can land on stdout (older Click) or stderr (newer). Accept either.
    combined = result.stdout + result.stderr
    assert "upload" in combined
    assert "connect-hf" in combined
