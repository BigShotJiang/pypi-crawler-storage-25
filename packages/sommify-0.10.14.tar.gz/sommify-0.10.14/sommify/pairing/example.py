import numpy as np

from sommify.pairing import (
    bin_similarities,
    cosine_similarity_matrix,
    greedy_select_topk_weighted,
)

rng = np.random.default_rng(0)

recipes = rng.standard_normal((10, 256)).astype(np.float32)  # 10 recipes, 256-dim
wines = rng.standard_normal((400, 256)).astype(np.float32)  # 400 wines, 256-dim

sim = cosine_similarity_matrix(recipes, wines)  # shape [10, 400]
binned = bin_similarities(sim, thresholds=[0.6, 0.75, 0.9])  # values in {0,1,2,3}
U = binned.astype(np.float32)  # use discrete pairing scores as the utility matrix

# C[j, k] == 1 if wine j belongs to group k. Here every wine is in all 3 groups.
C = np.ones((400, 3), dtype=np.int32)
caps = [
    10,  # max 10 wines from group 0
    10,  # max 10 wines from group 1
    10,  # max 10 wines from group 2
]

selected = greedy_select_topk_weighted(
    dish_embeddings=recipes,
    wine_embeddings=wines,
    C=C,
    caps=caps,
    precomputed_utility_matrix=U,
    verbose=True,
    lambda_div=0.3,
    top_k=3,
)

print("\n✅ Selected wines:", selected)  # indices of selected wines
