import numpy as np
from numba import njit, prange

from .utils import generate_utility_matrix


class InfeasibleConstraintsError(ValueError):
    """
    Raised when the requested per-constraint demands cannot all be satisfied,
    no matter which wines are chosen.

    Subclasses ``ValueError`` so callers can catch it specifically or fall back
    to a plain ``except ValueError``. The report is carried as structured
    attributes (not just the message) so the caller can build its own UI.

    Attributes
    ----------
    requested : int
        Total number of wine slots demanded (``sum(caps)``).
    max_fillable : int
        The largest number of slots any selection could actually fill.
    shortfalls : dict[int, int]
        A witness breakdown: constraint index -> number of its slots that
        could not be filled in a maximum assignment. With overlapping
        constraints the blame is not always unique; this is one valid
        explanation of the deficiency, not a canonical one.
    """

    def __init__(self, requested: int, max_fillable: int, shortfalls: dict[int, int]):
        self.requested = requested
        self.max_fillable = max_fillable
        self.shortfalls = shortfalls
        breakdown = ", ".join(
            f"constraint {j} short by {d}" for j, d in sorted(shortfalls.items())
        )
        super().__init__(
            f"Cannot satisfy constraint demands: requested {requested} wine "
            f"slot(s), at most {max_fillable} can be filled "
            f"({breakdown or 'no constraints fillable'})."
        )


@njit(fastmath=True, parallel=True)
def calc_utility_gains_incremental(
    U: np.ndarray,  # (n_recipes, n_wines)
    current_top_vals: np.ndarray,  # (n_recipes, top_k) - The current best scores per recipe
    weights: np.ndarray,  # (top_k,)
    candidates: np.ndarray,  # array of wine indices to evaluate
) -> np.ndarray:
    """
    Calculates utility gain only for valid candidates against the current
    state of top-k values per recipe.
    """
    n_candidates = len(candidates)
    n_recipes, k = current_top_vals.shape
    gains = np.zeros(n_candidates, dtype=np.float32)

    # Pre-calculate current utility for all recipes to compute deltas
    # (This is O(n_recipes * k), negligible compared to the loop)
    current_recipe_utils = np.zeros(n_recipes, dtype=np.float32)
    for r in range(n_recipes):
        for x in range(k):
            current_recipe_utils[r] += current_top_vals[r, x] * weights[x]

    for idx in prange(n_candidates):
        wine_idx = candidates[idx]
        total_gain = 0.0

        for r in range(n_recipes):
            u_val = U[r, wine_idx]

            # Optimization: If u_val is smaller than the worst of the current top_k,
            # it cannot possibly improve the score (assuming positive weights).
            if u_val <= current_top_vals[r, k - 1]:
                continue

            # Simulation: Insert u_val into the sorted current_top_vals
            # We don't allocate new arrays; we just do the math on registers
            new_recipe_util = 0.0
            inserted = False

            # Iterate through rank weights
            # This effectively performs an insertion sort + dot product in one pass
            ranks_filled = 0

            for i in range(k):
                val_at_rank = current_top_vals[r, i]

                if not inserted and u_val > val_at_rank:
                    # Our new wine takes this rank
                    new_recipe_util += u_val * weights[i]
                    inserted = True
                    ranks_filled += 1
                    if ranks_filled == k:
                        break

                    # The displaced value bumps down to the next weight
                    new_recipe_util += val_at_rank * weights[ranks_filled]
                    ranks_filled += 1
                else:
                    new_recipe_util += val_at_rank * weights[ranks_filled]
                    ranks_filled += 1

                if ranks_filled == k:
                    break

            total_gain += new_recipe_util - current_recipe_utils[r]

        gains[idx] = total_gain

    return gains


def _facility_diversity_gains(
    wine_sim: np.ndarray,  # (n_wines, n_wines) pairwise wine similarity in [0, 1]
    group_members: list[np.ndarray],  # group_members[g] = wine indices in group g
    cover: list[np.ndarray],  # cover[g] = current best coverage per group member
    C: np.ndarray,  # (n_wines, n_constraints) membership matrix
    candidate_indices: np.ndarray,  # wine indices still eligible for selection
    n_wines: int,
) -> np.ndarray:
    """
    Marginal gain of a per-group facility-location diversity objective.

    For each group ``g`` the objective is
        F_g(S) = sum over members of  max_{s in S} sim(member, s)
    i.e. how well the wines already chosen in ``g`` "cover" the rest of ``g``.
    This is monotone submodular, so greedily picking the largest marginal gain
    keeps the approximation guarantee. It penalises near-duplicates directly:
    a candidate close to an already-selected wine adds almost no new coverage.

    Diversity is membership-based: a wine contributes to every group it belongs
    to, independent of which constraint slot the matching assigns it to (the
    matching is a quota-accounting device, not a diversity concept).
    """
    gains = np.zeros(n_wines, dtype=np.float64)

    for g, members in enumerate(group_members):
        if len(members) == 0:
            continue

        # Restrict to candidates that belong to this group.
        cand_g = candidate_indices[C[candidate_indices, g] == 1]
        if len(cand_g) == 0:
            continue

        # sim[member, candidate] for every (member, candidate) pair in the group
        sub = wine_sim[np.ix_(members, cand_g)]  # (n_members, n_cand_g)

        # Marginal coverage: only the improvement over the current coverage counts.
        marginal = np.maximum(sub - cover[g][:, None], 0.0)
        gains[cand_g] += marginal.sum(axis=0)

    return gains


def _update_group_cover(
    wine_sim: np.ndarray,
    group_members: list[np.ndarray],
    cover: list[np.ndarray],
    groups_of_wine: np.ndarray,  # groups the newly selected wine belongs to
    wine_idx: int,
) -> None:
    """In-place update of per-group coverage after ``wine_idx`` is selected."""
    for g in groups_of_wine:
        members = group_members[g]
        if len(members) == 0:
            continue
        cover[g] = np.maximum(cover[g], wine_sim[members, wine_idx])


def _try_augment(
    wine: int,
    slots_of_constraint: list[list[int]],
    groups_of_wine: list[np.ndarray],
    match_slot: np.ndarray,  # match_slot[s] = wine in slot s, or -1
    visited: np.ndarray,  # bool, per slot, for this augmenting search
) -> bool:
    """
    Kuhn augmenting-path step for the wine <-> constraint-slot bipartite graph.

    Each constraint ``j`` is expanded into ``caps[j]`` interchangeable slots, so
    fitting a wine is plain 1-to-1 matching. Tries to seat ``wine`` in some
    slot, recursively reshuffling earlier assignments if needed.

    Mutates ``match_slot`` only along a successful path; a call that returns
    ``False`` leaves ``match_slot`` untouched.
    """
    for j in groups_of_wine[wine]:
        for s in slots_of_constraint[j]:
            if visited[s]:
                continue
            visited[s] = True
            occupant = match_slot[s]
            if occupant == -1 or _try_augment(
                occupant, slots_of_constraint, groups_of_wine, match_slot, visited
            ):
                match_slot[s] = wine
                return True
    return False


def _can_add(
    wine: int,
    slots_of_constraint: list[list[int]],
    groups_of_wine: list[np.ndarray],
    match_slot: np.ndarray,
    n_slots: int,
) -> bool:
    """
    True iff ``wine`` can be added while keeping every selected wine assignable
    (i.e. ``selected | {wine}`` stays independent in the transversal matroid).

    Tested on a copy so the live matching is left untouched.
    """
    trial = match_slot.copy()
    visited = np.zeros(n_slots, dtype=bool)
    return _try_augment(wine, slots_of_constraint, groups_of_wine, trial, visited)


def greedy_select_topk_weighted(
    dish_embeddings: np.ndarray | None,  # Replaces U
    wine_embeddings: np.ndarray,  # Renamed from W_E
    C: np.ndarray,
    caps: list[int],
    noise_scale: float = 0.05,  # New Param
    max_card_size: int = 999,
    top_k: int = 3,
    lambda_div: float = 0.3,
    verbose: bool = False,
    weights: np.ndarray | None = None,
    precomputed_utility_matrix: np.ndarray | None = None,
    preselected_items: list[int] | None = None,
) -> list[int]:
    """
    Greedily build a wine selection that trades off pairing utility against
    in-group diversity, subject to exact per-constraint demands.

    ``caps`` are treated as *exact demands*: the result is always exactly
    ``sum(caps)`` distinct wines, and each selected wine occupies exactly one
    constraint slot. A wine that belongs to several constraints (e.g. a
    Bordeaux red is both "red" and "bordeaux") therefore counts once, not once
    per membership. Which slot a wine fills is decided -- and freely revised --
    by a bipartite matching (the constraints form a transversal matroid), so
    the greedy never strands a hard-to-fill constraint.

    The objective is a fixed-scale blend of two monotone submodular terms:
        F(S) = (1 - lambda_div) * Utility(S) / utility_norm
             +      lambda_div  * Diversity(S) / diversity_norm
    Greedy maximisation of a monotone submodular objective over a matroid keeps
    the standard 1/2 approximation guarantee.

    Returns
    -------
    selected : list[int]
        Indices of the chosen wines, in selection order (preselected first).

    Raises
    ------
    InfeasibleConstraintsError
        If the demands cannot all be met by any selection of wines.
    ValueError
        If ``max_card_size`` is smaller than ``sum(caps)`` (a hard size cap
        contradicts exact demands), or preselected items cannot be jointly
        assigned to the constraints.
    """
    # --- 1. Pre-Processing ---
    wine_np = np.ascontiguousarray(wine_embeddings)
    # Normalize embeddings once here (Crucial for Cosine Sim)
    wine_norm = wine_np / np.maximum(
        np.linalg.norm(wine_np, axis=1, keepdims=True), 1e-9
    )

    n_wines = wine_np.shape[0]
    n_constraints = C.shape[1]

    # --- 2. Constraint / Matroid Setup ---
    # wine_to_groups[w] : constraints wine w satisfies.
    # group_members[g]  : wines that satisfy constraint g.
    wine_to_groups = [np.where(row == 1)[0] for row in C]
    group_members = [np.where(C[:, g] == 1)[0] for g in range(n_constraints)]

    # Expand each constraint into caps[g] interchangeable slots.
    constraint_of_slot: list[int] = []
    slots_of_constraint: list[list[int]] = []
    for g in range(n_constraints):
        cap = caps[g] if g < len(caps) else 0
        first = len(constraint_of_slot)
        constraint_of_slot.extend([g] * cap)
        slots_of_constraint.append(list(range(first, first + cap)))
    n_slots = len(constraint_of_slot)  # == sum(caps) == target selection size
    target = n_slots

    if max_card_size < target:
        raise ValueError(
            f"max_card_size ({max_card_size}) is smaller than the total "
            f"demand sum(caps) ({target}); exact demands cannot be met under "
            f"a hard size cap."
        )

    # --- 2b. Feasibility Pre-check (transversal matroid rank) ---
    # Maximum matching over ALL wines: if it cannot fill every slot, no
    # selection ever could -- fail fast with a structured report.
    precheck_match = np.full(n_slots, -1, dtype=np.int64)
    for w in range(n_wines):
        visited = np.zeros(n_slots, dtype=bool)
        _try_augment(w, slots_of_constraint, wine_to_groups, precheck_match, visited)
    max_fillable = int((precheck_match != -1).sum())
    if max_fillable < target:
        shortfalls: dict[int, int] = {}
        for s in range(n_slots):
            if precheck_match[s] == -1:
                j = constraint_of_slot[s]
                shortfalls[j] = shortfalls.get(j, 0) + 1
        raise InfeasibleConstraintsError(target, max_fillable, shortfalls)

    # --- 3. Utility Generation ---
    U = None
    n_recipes = 0
    if dish_embeddings is not None:
        dish_np = np.ascontiguousarray(dish_embeddings)
        dish_norm = dish_np / np.maximum(
            np.linalg.norm(dish_np, axis=1, keepdims=True), 1e-9
        )
        if verbose:
            print("Generating deterministic utility matrix...")
        # U: (n_recipes, n_wines)
        U = (
            precomputed_utility_matrix
            if precomputed_utility_matrix is not None
            else generate_utility_matrix(dish_norm, wine_norm, noise_scale)
        )
        U = np.ascontiguousarray(U, dtype=np.float32)
        n_recipes = U.shape[0]

    # --- 4. Objective State ---
    if weights is None:
        weights = np.array([0.6**i for i in range(top_k)], dtype=np.float32)
        weights[0] = 1.0
    weights = weights.astype(np.float32)

    selected: list[int] = []
    # current_top_vals: (n_recipes, k), sorted desc
    current_top_vals = np.zeros((n_recipes, top_k), dtype=np.float32)

    # Diversity: per-group facility location.
    # Pairwise wine similarity mapped from cosine [-1, 1] to [0, 1].
    wine_sim = (wine_norm @ wine_norm.T + 1.0) / 2.0
    # cover[g][i] = best similarity of group member i to any selected wine in g.
    cover = [np.zeros(len(m), dtype=np.float64) for m in group_members]

    # Live matching for the real selection (rebuilt from scratch, fresh state).
    match_slot = np.full(n_slots, -1, dtype=np.int64)

    # --- 4b. Fixed-scale Normalisers (computed once) ---
    if U is not None and n_recipes > 0:
        sorted_U = np.sort(U, axis=1)[:, ::-1][:, :top_k]
        if sorted_U.shape[1] < top_k:  # fewer wines than top_k
            pad = np.zeros((n_recipes, top_k - sorted_U.shape[1]), dtype=sorted_U.dtype)
            sorted_U = np.concatenate([sorted_U, pad], axis=1)
        utility_norm = float((sorted_U * weights).sum())
    else:
        utility_norm = 1.0
    if utility_norm <= 0.0:
        utility_norm = 1.0

    diversity_norm = float(sum(len(m) for m in group_members))
    if diversity_norm <= 0.0:
        diversity_norm = 1.0

    def _insert_topk(wine_idx: int) -> None:
        """Update per-recipe sorted top-k state after selecting a wine."""
        if n_recipes == 0 or U is None:
            return
        for r in range(n_recipes):
            val = U[r, wine_idx]
            if val > current_top_vals[r, -1]:
                row = current_top_vals[r]
                for k_i in range(top_k):
                    if val > row[k_i]:
                        row[k_i + 1 :] = row[k_i:-1]
                        row[k_i] = val
                        break

    # --- 5. Initialize Preselected Items ---
    if preselected_items:
        for wine_idx in preselected_items:
            visited = np.zeros(n_slots, dtype=bool)
            if not _try_augment(
                wine_idx, slots_of_constraint, wine_to_groups, match_slot, visited
            ):
                raise ValueError(
                    f"Preselected wine {wine_idx} cannot be assigned to a "
                    f"constraint slot alongside the other preselected items."
                )
            selected.append(wine_idx)
            _update_group_cover(
                wine_sim, group_members, cover, wine_to_groups[wine_idx], wine_idx
            )
            _insert_topk(wine_idx)

    # --- 6. Main Greedy Loop ---
    while len(selected) < target:
        # A. Eligible candidates: unselected wines that keep the matching
        #    extendable (i.e. preserve transversal-matroid independence).
        selected_mask = np.zeros(n_wines, dtype=bool)
        selected_mask[selected] = True
        eligible = [
            w
            for w in np.where(~selected_mask)[0]
            if _can_add(w, slots_of_constraint, wine_to_groups, match_slot, n_slots)
        ]
        if not eligible:
            # Unreachable: the pre-check guarantees matroid rank == target, and
            # a matroid always lets an independent set grow to a basis.
            raise AssertionError(
                "No eligible wine although demands were pre-verified feasible."
            )
        candidate_indices = np.array(eligible, dtype=np.int64)

        # B. Utility Gains (Incremental)
        full_util_gains = np.zeros(n_wines, dtype=np.float64)
        if U is not None:
            util_gains = calc_utility_gains_incremental(
                U, current_top_vals, weights, candidate_indices
            )
            full_util_gains[candidate_indices] = util_gains

        # C. Diversity Gains (per-group facility location)
        full_div_gains = _facility_diversity_gains(
            wine_sim, group_members, cover, C, candidate_indices, n_wines
        )

        # D. Combine on a fixed scale & Select.
        scores = (
            (1.0 - lambda_div) * full_util_gains / utility_norm
            + lambda_div * full_div_gains / diversity_norm
        )
        best_idx_local = int(np.argmax(scores[candidate_indices]))
        best_wine = int(candidate_indices[best_idx_local])

        # E. Commit: seat the wine in the matching (may reshuffle earlier
        #    assignments) and update objective state.
        visited = np.zeros(n_slots, dtype=bool)
        _try_augment(
            best_wine, slots_of_constraint, wine_to_groups, match_slot, visited
        )
        selected.append(best_wine)
        _update_group_cover(
            wine_sim, group_members, cover, wine_to_groups[best_wine], best_wine
        )
        _insert_topk(best_wine)

        if verbose:
            print(
                f"  + wine {best_wine}: "
                f"util_gain={full_util_gains[best_wine]:.4f}, "
                f"div_gain={full_div_gains[best_wine]:.4f}"
            )

    return selected
