import numpy as np

from sommify.pairing.selection import (
    InfeasibleConstraintsError,
    calc_utility_gains_incremental,
    greedy_select_topk_weighted,
)


def _assert_raises(exc_type, fn):
    """Run fn(), assert it raises exc_type, and return the exception."""
    try:
        fn()
    except exc_type as exc:
        return exc
    raise AssertionError(f"expected {exc_type.__name__} to be raised")


def _ref_utility_gains(U, current_top_vals, weights, candidates):
    """Brute-force reference: full top-k recompute, no incremental tricks."""
    n_recipes, k = current_top_vals.shape
    current = (current_top_vals * weights).sum(axis=1)
    out = np.zeros(len(candidates), dtype=np.float64)
    for i, c in enumerate(candidates):
        total = 0.0
        for r in range(n_recipes):
            merged = np.concatenate([current_top_vals[r], [U[r, c]]])
            new_topk = np.sort(merged)[::-1][:k]
            total += float(new_topk @ weights) - current[r]
        out[i] = total
    return out


def _sorted_desc_rows(arr):
    """Return each row sorted descending (the kernel's required invariant)."""
    return np.sort(arr, axis=1)[:, ::-1].astype(np.float32)


# --- calc_utility_gains_incremental: correctness vs brute force ---------------


def test_incremental_gains_match_bruteforce_random():
    rng = np.random.default_rng(42)
    n_recipes, n_wines, k = 12, 30, 3
    weights = np.array([1.0, 0.6, 0.36], dtype=np.float32)

    U = rng.random((n_recipes, n_wines)).astype(np.float32)
    current_top_vals = _sorted_desc_rows(rng.random((n_recipes, k)))
    candidates = np.arange(n_wines)

    got = calc_utility_gains_incremental(U, current_top_vals, weights, candidates)
    expected = _ref_utility_gains(U, current_top_vals, weights, candidates)

    np.testing.assert_allclose(got, expected, atol=1e-5)


def test_incremental_gains_insertion_at_each_rank():
    # current top-k is [0.9, 0.6, 0.3]; probe a value that lands at front,
    # middle, last rank, and below the worst (no gain).
    weights = np.array([1.0, 0.6, 0.36], dtype=np.float32)
    current_top_vals = np.array([[0.9, 0.6, 0.3]], dtype=np.float32)
    probes = np.array([[0.99, 0.75, 0.45, 0.1]], dtype=np.float32)  # 1 recipe, 4 wines
    candidates = np.arange(4)

    got = calc_utility_gains_incremental(probes, current_top_vals, weights, candidates)
    expected = _ref_utility_gains(probes, current_top_vals, weights, candidates)

    np.testing.assert_allclose(got, expected, atol=1e-5)
    # A value below the current worst (0.1 <= 0.3) yields exactly zero gain.
    assert got[3] == 0.0
    # Gains are monotonically larger for better candidates.
    assert got[0] > got[1] > got[2] > got[3]


def test_incremental_gains_empty_state():
    # With an all-zero current state every candidate fully fills the top-k.
    weights = np.array([1.0, 0.6, 0.36], dtype=np.float32)
    current_top_vals = np.zeros((3, 3), dtype=np.float32)
    U = np.array(
        [[0.5, 0.2], [0.8, 0.1], [0.4, 0.9]], dtype=np.float32
    )  # 3 recipes, 2 wines
    candidates = np.arange(2)

    got = calc_utility_gains_incremental(U, current_top_vals, weights, candidates)
    expected = _ref_utility_gains(U, current_top_vals, weights, candidates)
    np.testing.assert_allclose(got, expected, atol=1e-5)


# --- greedy_select_topk_weighted: end-to-end behaviour ------------------------


def _toy_problem(seed=0, n_wines=40, n_recipes=8, dim=16):
    rng = np.random.default_rng(seed)
    dishes = rng.standard_normal((n_recipes, dim)).astype(np.float32)
    wines = rng.standard_normal((n_wines, dim)).astype(np.float32)
    return dishes, wines


def test_returns_list_and_respects_caps():
    dishes, wines = _toy_problem()
    n_wines = wines.shape[0]
    # 3 groups, every wine in exactly one group.
    C = np.zeros((n_wines, 3), dtype=np.int32)
    C[np.arange(n_wines), np.arange(n_wines) % 3] = 1
    caps = [4, 4, 4]

    selected = greedy_select_topk_weighted(dishes, wines, C, caps, lambda_div=0.3)

    # The function returns a bare list of wine indices.
    assert isinstance(selected, list)
    assert all(isinstance(i, int) for i in selected)

    # No duplicates.
    assert len(selected) == len(set(selected))
    # Per-group caps are never exceeded.
    group_counts = C[selected].sum(axis=0)
    for g, cap in enumerate(caps):
        assert group_counts[g] <= cap
    # The loop fills up to the total cap budget.
    assert len(selected) == sum(caps)


def test_preselected_items_are_kept_first():
    dishes, wines = _toy_problem()
    n_wines = wines.shape[0]
    C = np.ones((n_wines, 1), dtype=np.int32)
    caps = [10]
    preselected = [7, 13]

    selected = greedy_select_topk_weighted(
        dishes, wines, C, caps, preselected_items=preselected
    )

    assert selected[: len(preselected)] == preselected
    assert len(selected) == len(set(selected))


def test_facility_diversity_avoids_near_duplicates():
    # Build wines where indices 0 and 1 are identical. Under a diversity-only
    # objective the greedy picker should not take both before exploring
    # genuinely different wines.
    rng = np.random.default_rng(1)
    dim = 16
    wines = rng.standard_normal((20, dim)).astype(np.float32)
    wines[1] = wines[0]  # exact duplicate

    C = np.ones((20, 1), dtype=np.int32)
    caps = [5]

    # lambda_div=1.0 -> pure diversity; no dish embeddings needed.
    selected = greedy_select_topk_weighted(None, wines, C, caps, lambda_div=1.0)

    # The duplicate pair must not both appear among the first picks: once one
    # of them is chosen the other contributes ~zero marginal coverage.
    if 0 in selected and 1 in selected:
        assert abs(selected.index(0) - selected.index(1)) > 1


def test_selection_is_deterministic():
    dishes, wines = _toy_problem(seed=3)
    n_wines = wines.shape[0]
    C = np.ones((n_wines, 2), dtype=np.int32)
    caps = [6, 6]

    first = greedy_select_topk_weighted(dishes, wines, C, caps, lambda_div=0.4)
    second = greedy_select_topk_weighted(dishes, wines, C, caps, lambda_div=0.4)

    assert first == second


# --- transversal-matroid constraint handling ---------------------------------


def test_overlapping_membership_counts_once():
    # Wine 0 satisfies BOTH constraints; the rest are single-membership.
    # With exact demands a dual-membership wine fills only one slot, so the
    # result is still sum(caps) distinct wines (the old code double-counted
    # and would have stopped one wine short).
    rng = np.random.default_rng(5)
    n_wines = 12
    wines = rng.standard_normal((n_wines, 8)).astype(np.float32)
    C = np.zeros((n_wines, 2), dtype=np.int32)
    C[0, :] = 1  # wine 0 in both constraints
    C[1:7, 0] = 1  # wines 1..6 in constraint 0 only
    C[7:, 1] = 1  # wines 7..11 in constraint 1 only
    caps = [1, 1]

    selected = greedy_select_topk_weighted(None, wines, C, caps, lambda_div=1.0)

    assert len(selected) == 2
    assert len(set(selected)) == 2


def test_corner_painting_does_not_stall():
    # Constraint 1 is satisfiable by exactly one wine (index 3), which also
    # satisfies constraint 0. A feasible result must seat wine 3 in the
    # constraint-1 slot; a naive pick-time assignment could strand it.
    rng = np.random.default_rng(7)
    n_wines = 10
    wines = rng.standard_normal((n_wines, 8)).astype(np.float32)
    C = np.zeros((n_wines, 2), dtype=np.int32)
    C[:, 0] = 1  # every wine satisfies constraint 0
    C[3, 1] = 1  # only wine 3 satisfies constraint 1
    caps = [2, 1]

    selected = greedy_select_topk_weighted(None, wines, C, caps, lambda_div=1.0)

    assert len(selected) == 3
    assert 3 in selected  # the sole constraint-1 wine must be included


def test_infeasible_constraints_raise():
    # Constraint 1 has no eligible wines at all -> demands cannot be met.
    rng = np.random.default_rng(9)
    n_wines = 6
    wines = rng.standard_normal((n_wines, 8)).astype(np.float32)
    C = np.zeros((n_wines, 2), dtype=np.int32)
    C[:, 0] = 1  # all wines in constraint 0, none in constraint 1
    caps = [3, 2]

    err = _assert_raises(
        InfeasibleConstraintsError,
        lambda: greedy_select_topk_weighted(None, wines, C, caps),
    )
    assert err.requested == 5
    assert err.max_fillable == 3
    assert err.shortfalls == {1: 2}


def test_max_card_size_below_demand_raises():
    # A hard size cap below sum(caps) contradicts exact demands: plain
    # ValueError, distinct from an infeasible-stock error.
    rng = np.random.default_rng(11)
    n_wines = 10
    wines = rng.standard_normal((n_wines, 8)).astype(np.float32)
    C = np.ones((n_wines, 1), dtype=np.int32)
    caps = [5]

    err = _assert_raises(
        ValueError,
        lambda: greedy_select_topk_weighted(
            None, wines, C, caps, max_card_size=3
        ),
    )
    assert not isinstance(err, InfeasibleConstraintsError)


if __name__ == "__main__":
    test_incremental_gains_match_bruteforce_random()
    test_incremental_gains_insertion_at_each_rank()
    test_incremental_gains_empty_state()
    test_returns_list_and_respects_caps()
    test_preselected_items_are_kept_first()
    test_facility_diversity_avoids_near_duplicates()
    test_selection_is_deterministic()
    test_overlapping_membership_counts_once()
    test_corner_painting_does_not_stall()
    test_infeasible_constraints_raise()
    test_max_card_size_below_demand_raises()
    print("All selection tests passed")
