"""Structured access to Responses API stream chunks on the client.

The gateway emits SSE: an optional ``event:`` line plus a ``data:`` JSON
object. :func:`keiro.client._iter_parsed_sse` merges the SSE event name
into each parsed JSON dict as ``\"event\"``. The Responses API also uses a
``\"type\"`` field inside the JSON body.

Callers should use :class:`ClientStreamPayload` instead of ad-hoc
``payload.get(\"type\")`` / ``payload.get(\"event\")`` chains so
discrimination logic stays in one place.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

__all__ = ["ClientStreamPayload"]


@dataclass(slots=True)
class ClientStreamPayload:
    """One merged JSON object yielded by :meth:`keiro.client.Client.responses_stream`.

    Attributes:
        raw: The same mapping the client iterator yields (read-only contract —
            do not mutate).
    """

    raw: Mapping[str, Any]

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> ClientStreamPayload:
        """Wrap a stream chunk dict."""
        return cls(raw=payload)

    @property
    def sse_event_name(self) -> str | None:
        """The SSE ``event:`` line when present (e.g. ``message``)."""
        ev = self.raw.get("event")
        return str(ev) if isinstance(ev, str) and ev else None

    @property
    def api_type(self) -> str | None:
        """The JSON ``type`` field when present (e.g. ``response.output_text.delta``)."""
        t = self.raw.get("type")
        return str(t) if isinstance(t, str) and t else None

    @property
    def effective_type(self) -> str:
        """Discriminator for stream handlers.

        Prefer JSON ``type`` (Responses API semantics) when present. The SSE
        envelope name (merged as ``event`` by :func:`keiro.client._iter_parsed_sse`)
        is used for frames without a body ``type`` (for example ``header``,
        ``telemetry``, or ``chunk`` wrappers).

        This ordering matches production streams where ``event`` may be ``chunk``
        while ``type`` is ``response.output_text.delta``.
        """
        t = self.raw.get("type")
        if isinstance(t, str) and t:
            return t
        ev = self.raw.get("event")
        return str(ev) if isinstance(ev, str) else ""
