# Amazon SP-API CLI
__version__ = "0.2.6"
