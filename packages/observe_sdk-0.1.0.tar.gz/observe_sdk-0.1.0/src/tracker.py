import traceback
import threading
import httpx
from typing import Any


class Tracker:
    def __init__(self, api_key: str, server_url: str):
        if not api_key:
            raise ValueError("Tracker: api_key is required")
        if not server_url:
            raise ValueError("Tracker: server_url is required")

        self._api_key = api_key
        self._server_url = server_url.rstrip("/")
        self._headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    # ---- Tracking ----

    def track(self, event_name: str, anonymous_id: str, properties: dict[str, Any] = {}):
        """Track a custom server-side event."""
        if not event_name:
            return
        self._send("/ingest/events", {
            "name": event_name,
            "anonymous_id": anonymous_id,
            "properties": properties,
        })

    def identify(self, anonymous_id: str, user_id: str):
        """Link an anonymous_id to a known user_id."""
        self._send("/ingest/identify", {
            "anonymous_id": anonymous_id,
            "user_id": str(user_id),
        })

    def capture_exception(self, e: Exception, anonymous_id: str = "server", extra: dict = {}):
        """Capture an exception and send it as an event with the stack trace."""
        self.track(
            event_name="exception",
            anonymous_id=anonymous_id,
            properties={
                "exception_type": type(e).__name__,
                "message": str(e),
                "stack_trace": traceback.format_exc(),
                **extra,
            },
        )

    # ---- Transport ----

    def _send(self, endpoint: str, payload: dict):
        """Fire and forget — runs in a background thread so it never blocks."""
        thread = threading.Thread(
            target=self._post,
            args=(endpoint, payload),
            daemon=True,
        )
        thread.start()

    def _post(self, endpoint: str, payload: dict):
        try:
            with httpx.Client() as client:
                client.post(
                    f"{self._server_url}{endpoint}",
                    json=payload,
                    headers=self._headers,
                    timeout=5.0,
                )
        except Exception as e:
            # fail silently — tracking should never crash the host app
            print(f"Tracker: failed to send event — {e}")