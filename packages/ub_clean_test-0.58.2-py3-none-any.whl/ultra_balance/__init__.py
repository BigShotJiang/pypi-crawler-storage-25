__version__ = "0.58.2"
__author__ = "pengyeqin"
__email__ = "xxbj433@qq.com"

from .reasoning.logical import LogicalReasoning

def hello():
    print("Hello from ub-clean-test!")