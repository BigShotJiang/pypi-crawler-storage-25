"""Preflight checks run before the MCP server begins serving tools.

Phase 5 caps the total preflight budget at ~5 seconds (2 attempts at
0s + 3s) and surfaces transient backend-unreachable errors as
WARNING-level log lines that allow the MCP ``initialize`` handshake to
complete. The first tool call that reaches the backend then surfaces
the underlying error via ``call_client_safely``. Fatal 4xx (token
problems, backend-too-old) still raise :class:`StartupError` so the
operator gets a fast-failing exit code.

Why warn-not-raise on transient: an MCP host (Claude Desktop, the
inspector, etc.) often launches ptm-mcp before the backend is fully
warm. The previous 31-second exponential backoff frequently exceeded
the host's startup deadline and produced a confusing "ptm-mcp
crashed" surface that masked the real cause. With the new design the
host gets a working server in <= 5s; the next ``list_tools`` /
``get_prompt`` call surfaces the network error directly.

Each fatal step has a dedicated exit code so an operator can tell at
a glance which layer failed without parsing log lines. See
``docs/mcp-ptm-phase1.md`` section 18.9.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from packaging.version import InvalidVersion, Version
from ptm_client import PTMClient, PTMError
from ptm_client.errors import CloudflareAccessError

from .config import MIN_BACKEND_VERSION, Settings

# Startup exit codes. Keep in sync with docs/mcp-integration.md.
EXIT_HEALTHZ = 2
EXIT_AUTH = 3
EXIT_META = 4
EXIT_CLOUDFLARE_ACCESS = 5

logger = logging.getLogger("ptm_mcp.startup")


# Phase 5: total budget 0 + 3 = 3s of sleeps + 2 HTTP attempts (each
# bounded by the ptm-client default 30s read timeout, but in practice
# the connection error returns in <1s on a refused TCP). Worst-case
# wall time around 5s. Was (0, 1, 2, 4, 8, 16) = up to 31s.
_PREFLIGHT_DELAYS: tuple[int, ...] = (0, 3)


@dataclass
class StartupReport:
    backend_version: str
    token_kind: str | None
    token_expires_at: str | None


class StartupError(RuntimeError):
    """Preflight check failed. Startup should exit with a specific code."""

    def __init__(self, message: str, exit_code: int) -> None:
        super().__init__(message)
        self.exit_code = exit_code


def run_preflight(client: PTMClient, settings: Settings) -> StartupReport:
    """Run the startup checks.

    Steps:
      1. Health probe with the Phase 5 cap; transient failures log a
         WARNING and let the handshake continue.
      2. GET /auth/me - 4xx is fatal (raises ``StartupError``);
         transient failures log a WARNING and continue.
      3. GET /meta - 4xx and version-too-old are fatal; transient
         failures log a WARNING and continue.
      4. Warn if token is a PAT or expires within 7 days.

    The returned :class:`StartupReport` carries empty / ``None`` fields
    when probes fell through transiently; the MCP server starts anyway.
    """
    del settings  # reserved for future checks (e.g. read_only validation)
    healthy = _probe_with_backoff(client, "/healthz", exit_code=EXIT_HEALTHZ)
    if not healthy:
        # Backend still unreachable after the 5s cap. Skip the rest of
        # preflight; the next tool call will surface the error.
        return StartupReport(backend_version="", token_kind=None, token_expires_at=None)
    me = _probe_auth_me(client, exit_code=EXIT_AUTH)
    version = _probe_meta_version(client, exit_code=EXIT_META)
    _warn_token_type(me)
    return StartupReport(
        backend_version=version,
        token_kind=(me or {}).get("token_kind"),
        token_expires_at=(me or {}).get("token_expires_at"),
    )


# ----------------------------------------------------------------------
# Internal probes
# ----------------------------------------------------------------------


def _probe_with_backoff(client: PTMClient, path: str, *, exit_code: int) -> bool:
    """Health-probe the backend with the Phase 5 5s cap.

    Returns True on success, False when the cap was exhausted on
    transient errors. Cloudflare Access blocks and 4xx responses still
    raise :class:`StartupError` because they are unambiguously
    operator-actionable.
    """
    last_err: PTMError | None = None
    for attempt, delay in enumerate(_PREFLIGHT_DELAYS):
        if delay:
            logger.info(
                "[ptm-mcp] %s retry %d/%d in %ds",
                path,
                attempt,
                len(_PREFLIGHT_DELAYS) - 1,
                delay,
            )
            time.sleep(delay)
        try:
            client._get(path)  # type: ignore[attr-defined]
            return True
        except CloudflareAccessError as exc:
            raise StartupError(
                f"Cloudflare Access blocked {path}.\n{exc}\n"
                f"Run 'ptm-mcp doctor' for a step-by-step diagnostic.",
                exit_code=EXIT_CLOUDFLARE_ACCESS,
            ) from exc
        except PTMError as exc:
            if exc.status_code != 0:
                raise StartupError(f"backend rejected {path}: {exc}", exit_code=exit_code) from exc
            last_err = exc
    logger.warning(
        "[ptm-mcp] backend unreachable after %ds preflight cap (%s); "
        "starting MCP server anyway. The next tool call will surface "
        "the error: %s",
        sum(_PREFLIGHT_DELAYS),
        path,
        last_err,
    )
    return False


def _probe_auth_me(client: PTMClient, *, exit_code: int) -> dict:
    try:
        return client._get("/api/v1/auth/me")  # type: ignore[attr-defined]
    except CloudflareAccessError as exc:
        raise StartupError(
            f"Cloudflare Access blocked /auth/me.\n{exc}",
            exit_code=EXIT_CLOUDFLARE_ACCESS,
        ) from exc
    except PTMError as exc:
        if exc.status_code == 0:
            # Transient network failure; warn and let the handshake
            # complete. 4xx remains fatal.
            logger.warning(
                "[ptm-mcp] /auth/me unreachable (transient); skipping. "
                "The next tool call will surface the error: %s",
                exc,
            )
            return {}
        raise StartupError(
            f"GET /auth/me failed: {exc}. Check PTM_API_TOKEN.",
            exit_code=exit_code,
        ) from exc


def _probe_meta_version(client: PTMClient, *, exit_code: int) -> str:
    try:
        meta = client._get("/api/v1/meta")  # type: ignore[attr-defined]
    except CloudflareAccessError as exc:
        raise StartupError(
            f"Cloudflare Access blocked /meta.\n{exc}",
            exit_code=EXIT_CLOUDFLARE_ACCESS,
        ) from exc
    except PTMError as exc:
        if exc.status_code == 0:
            logger.warning(
                "[ptm-mcp] /meta unreachable (transient); skipping "
                "version gate. The next tool call will surface the "
                "error: %s",
                exc,
            )
            return ""
        raise StartupError(f"GET /meta failed: {exc}", exit_code=exit_code) from exc
    raw = (meta or {}).get("version", "")
    version_str = str(raw).strip()
    if not version_str:
        raise StartupError(
            f"backend /meta did not include a version; upgrade PTM to >= {MIN_BACKEND_VERSION}",
            exit_code=exit_code,
        )
    try:
        actual = Version(version_str)
        required = Version(MIN_BACKEND_VERSION)
    except InvalidVersion as exc:
        raise StartupError(
            f"backend returned unparseable version {version_str!r}",
            exit_code=exit_code,
        ) from exc
    # Pre-release-tolerant compare. PEP 440 sorts "1.9.0rc1" < "1.9.0", but
    # the rc is feature-equivalent in our release flow so it must satisfy
    # the gate. Compare against actual.base_version when actual is a
    # prerelease: Version("1.9.0rc1").base_version == "1.9.0", which then
    # compares equal to required. A plain Version >= Version check (and
    # SpecifierSet(prereleases=True)) both still reject the rc against the
    # base release because PEP 440 strictly orders prereleases earlier.
    effective = Version(actual.base_version) if actual.is_prerelease else actual
    if effective < required:
        raise StartupError(
            f"backend version {version_str} < required {MIN_BACKEND_VERSION}",
            exit_code=exit_code,
        )
    return version_str


def _warn_token_type(me: dict) -> None:
    kind = (me or {}).get("token_kind")
    if kind == "pat":
        logger.warning(
            "[ptm-mcp] bearer token is a PAT. Prefer a service-account token "
            "for MCP deployments so per-agent budgets and audit trails are accurate."
        )
    expires_at = (me or {}).get("token_expires_at")
    if expires_at:
        try:
            expiry = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
        except ValueError:
            return
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=UTC)
        if expiry - datetime.now(UTC) < timedelta(days=7):
            logger.warning(
                "[ptm-mcp] bearer token expires at %s (<7 days). Rotate soon.",
                expires_at,
            )
