"""ptm-mcp: MCP stdio server for the Prompt Test Manager API."""

__version__ = "0.14.1"

__all__ = ["__version__"]
