"""Tiny homegrown TTL cache for read-tool results (Phase 5 / A6).

Used by the read tools (``list_prompts``, ``list_tools``,
``list_providers``) to skip the HTTP round-trip on a second call
within ``ttl_seconds``. Write tools call :meth:`invalidate_all` so a
``create_prompt`` immediately followed by ``list_prompts`` always
sees the new entry.

No new dependency on purpose: ``cachetools`` would add ~150 KB and we
need exactly one TTL bucket. ``time.monotonic`` keeps the cache
robust to system clock changes.
"""

from __future__ import annotations

import time
from typing import Any


class TTLCache:
    """Per-key TTL cache. Not thread-safe; the MCP server is single-
    threaded by construction (one request at a time inside the
    asyncio event loop). If we add a worker pool later, swap this
    for ``cachetools.TTLCache`` behind the same interface.
    """

    def __init__(self, ttl_seconds: int = 60) -> None:
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        self._ttl_seconds = float(ttl_seconds)
        # _store: key -> (value, expiry_monotonic)
        self._store: dict[str, tuple[Any, float]] = {}

    def get(self, key: str) -> Any | None:
        """Return the cached value for ``key`` or ``None`` if expired
        or absent. Expired entries are evicted lazily on read."""
        entry = self._store.get(key)
        if entry is None:
            return None
        value, expiry = entry
        if expiry <= time.monotonic():
            self._store.pop(key, None)
            return None
        return value

    def set(self, key: str, value: Any) -> None:
        """Store ``value`` under ``key`` with a fresh TTL window."""
        self._store[key] = (value, time.monotonic() + self._ttl_seconds)

    def invalidate(self, *keys: str) -> None:
        """Drop the listed keys (no-op for absent ones).

        Useful when a write tool only invalidates one specific cache
        bucket instead of nuking every list. Keep in mind: any list
        whose result depends on the mutated entity should be cleared
        on the same write to avoid "stale read after own write".
        """
        for key in keys:
            self._store.pop(key, None)

    def invalidate_all(self) -> None:
        """Drop every entry. Default invalidation strategy on writes;
        cheaper to recompute the four list endpoints than to maintain
        a precise dependency graph."""
        self._store.clear()

    def __len__(self) -> int:
        return len(self._store)
