"""Triage queue MCP tools (Flywheel Phase 4).

One read tool + four write tools. Writes are gated by
``ensure_writes_allowed`` so an operator who flips
``PTM_MCP_READ_ONLY=true`` cannot promote-to-golden by accident.
Backend RBAC (``manage_triage_queue``) is the source of truth; the
MCP layer only translates errors via :func:`call_client_safely`.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ..config import Settings
from ._helpers import call_client_safely, require_str
from ._writes import ensure_writes_allowed

_LIST_STATES = ("flagged", "promoted", "resolved", "all")


def specs(settings: Settings) -> list[tuple[Tool, Any]]:
    """Return (schema, handler) pairs for every triage tool.

    The list_triage handler does NOT call ``ensure_writes_allowed`` so
    the read view is reachable from a read-only deployment; the four
    mutation handlers are gated.
    """
    return [
        (_list_triage_schema(), _make_list_triage_handler()),
        (_promote_schema(), _make_promote_handler(settings)),
        (_resolve_schema(), _make_resolve_handler(settings)),
        (_reopen_schema(), _make_reopen_handler(settings)),
        (_bulk_resolve_schema(), _make_bulk_resolve_handler(settings)),
    ]


# ---------------------------------------------------------------------------
# list_triage (read)
# ---------------------------------------------------------------------------


def _list_triage_schema() -> Tool:
    return Tool(
        name="list_triage",
        description=(
            "Lists Flywheel triage items. Use this to surface flagged runs "
            "that need reviewer attention before promoting them to golden "
            "test cases or resolving them. Filters by state (default "
            "'flagged'), prompt_id, and feedback signal. Page size is "
            "fixed at 25; use 'page' to walk the queue. RBAC: caller "
            "must hold manage_triage_queue."
        ),
        inputSchema={
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "state": {
                    "type": "string",
                    "enum": list(_LIST_STATES),
                    "default": "flagged",
                },
                "prompt_id": {"type": ["string", "null"]},
                "signal": {"type": ["string", "null"]},
                "page": {"type": "integer", "minimum": 1, "default": 1},
            },
        },
    )


def _make_list_triage_handler():
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        state = str(arguments.get("state") or "flagged")
        if state not in _LIST_STATES:
            raise ValueError(f"'state' must be one of {_LIST_STATES}; got {state!r}")
        prompt_id = arguments.get("prompt_id") or None
        signal = arguments.get("signal") or None
        page_raw = arguments.get("page", 1)
        try:
            page = int(page_raw)
        except (TypeError, ValueError) as exc:
            raise ValueError("'page' must be an integer") from exc
        return await call_client_safely(
            client.list_triage,
            state=state,
            prompt_id=prompt_id,
            signal=signal,
            page=page,
        )

    return _handler


# ---------------------------------------------------------------------------
# promote_run_to_golden (write)
# ---------------------------------------------------------------------------


def _promote_schema() -> Tool:
    return Tool(
        name="promote_run_to_golden",
        description=(
            "Promotes a flagged run to a new golden test case on its prompt. "
            "Atomically appends a ManualPromptTestCase, bumps the prompt's "
            "active version, and flips the run's triage_state to "
            "'promoted'. Either expected_output (text-only shorthand) or "
            "golden_output (full structured payload) may be supplied; "
            "supply at most one. Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["run_key"],
            "additionalProperties": False,
            "properties": {
                "run_key": {"type": "string", "description": "Run key to promote."},
                "expected_output": {"type": ["string", "null"]},
                "golden_output": {"type": ["object", "null"]},
                "change_summary": {
                    "type": ["string", "null"],
                    "maxLength": 500,
                    "description": "Override the auto-generated audit note.",
                },
            },
        },
    )


def _make_promote_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        run_key = require_str(arguments, "run_key")
        expected_output = arguments.get("expected_output")
        golden_output = arguments.get("golden_output")
        change_summary = arguments.get("change_summary")
        if expected_output is not None and not isinstance(expected_output, str):
            raise ValueError("'expected_output' must be a string when provided")
        if golden_output is not None and not isinstance(golden_output, dict):
            raise ValueError("'golden_output' must be an object when provided")
        if change_summary is not None and not isinstance(change_summary, str):
            raise ValueError("'change_summary' must be a string when provided")
        return await call_client_safely(
            client.promote_run_to_golden,
            run_key,
            expected_output=expected_output,
            golden_output=golden_output,
            change_summary=change_summary,
        )

    return _handler


# ---------------------------------------------------------------------------
# resolve_triage_item (write)
# ---------------------------------------------------------------------------


def _resolve_schema() -> Tool:
    return Tool(
        name="resolve_triage_item",
        description=(
            "Resolves a flagged run without promoting (reviewer judgment "
            "that the flag does not warrant a golden update). Optional "
            "'reason' is recorded on the audit row. Common reasons: "
            "spam, off_topic, wont_fix, duplicate. Requires "
            "PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["run_key"],
            "additionalProperties": False,
            "properties": {
                "run_key": {"type": "string"},
                "reason": {"type": ["string", "null"]},
            },
        },
    )


def _make_resolve_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        run_key = require_str(arguments, "run_key")
        reason = arguments.get("reason")
        if reason is not None and not isinstance(reason, str):
            raise ValueError("'reason' must be a string when provided")
        return await call_client_safely(
            client.resolve_triage_item,
            run_key,
            reason=reason,
        )

    return _handler


# ---------------------------------------------------------------------------
# reopen_triage_item (write)
# ---------------------------------------------------------------------------


def _reopen_schema() -> Tool:
    return Tool(
        name="reopen_triage_item",
        description=(
            "Reopens a previously-resolved or previously-promoted run "
            "back to 'flagged' so it re-enters the queue. Reopening a "
            "promoted run does NOT roll back the prompt-version bump; "
            "that requires a manual activate_prompt_version call. "
            "Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["run_key"],
            "additionalProperties": False,
            "properties": {"run_key": {"type": "string"}},
        },
    )


def _make_reopen_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        run_key = require_str(arguments, "run_key")
        return await call_client_safely(client.reopen_triage_item, run_key)

    return _handler


# ---------------------------------------------------------------------------
# bulk_resolve_triage (write)
# ---------------------------------------------------------------------------


def _bulk_resolve_schema() -> Tool:
    return Tool(
        name="bulk_resolve_triage",
        description=(
            "Bulk-resolves up to 25 flagged runs in one call. Already-"
            "resolved or already-promoted runs in the request count as "
            "'skipped' in the response. The server rejects 26+ keys "
            "with 422. Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["run_keys"],
            "additionalProperties": False,
            "properties": {
                "run_keys": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "maxItems": 25,
                },
                "reason": {"type": ["string", "null"]},
            },
        },
    )


def _make_bulk_resolve_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        run_keys = arguments.get("run_keys")
        if not isinstance(run_keys, list) or not run_keys:
            raise ValueError("'run_keys' must be a non-empty list of strings")
        if not all(isinstance(k, str) and k for k in run_keys):
            raise ValueError("every entry in 'run_keys' must be a non-empty string")
        if len(run_keys) > 25:
            raise ValueError("'run_keys' is capped at 25 entries per call")
        reason = arguments.get("reason")
        if reason is not None and not isinstance(reason, str):
            raise ValueError("'reason' must be a string when provided")
        return await call_client_safely(
            client.bulk_resolve_triage,
            run_keys,
            reason=reason,
        )

    return _handler
