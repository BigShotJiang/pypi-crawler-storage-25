"""Tool registry tools: read (Phase 1) and write (Phase 2).

Reads wrap ``ptm-client`` 0.9.0 methods. Writes added in 0.6.0 are gated
by ``PTM_MCP_READ_ONLY`` via ``ensure_writes_allowed``; backend RBAC
(``manage_tool_registry`` permission) remains the authority on whether a
caller actually mutates state.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ..config import Settings
from ._helpers import call_client_safely
from ._writes import ensure_writes_allowed


def specs(settings: Settings | None = None) -> list[tuple[Tool, Any]]:
    out: list[tuple[Tool, Any]] = [
        (_list_tools_schema(), _list_tools_handler),
        (_get_tool_dependents_schema(), _get_tool_dependents_handler),
        (_export_tool_registry_schema(), _export_tool_registry_handler),
    ]
    if settings is not None:
        out.extend(
            [
                (_create_tool_schema(), _make_create_tool_handler(settings)),
                (_update_tool_schema(), _make_update_tool_handler(settings)),
                (_deprecate_tool_schema(), _make_deprecate_tool_handler(settings)),
                (_delete_mock_profile_schema(), _make_delete_mock_profile_handler(settings)),
            ]
        )
    return out


# ----------------------------------------------------------------------
# list_tools
# ----------------------------------------------------------------------


def _list_tools_schema() -> Tool:
    return Tool(
        name="list_tools",
        description=(
            "List the tool registry roll-up the caller can see. Each entry is one "
            "tool name with its description, prompt count, deprecation flag, "
            "MCP server hint, tags, and (Phase 5) optional migration_path / "
            "deprecation_message / last_used_at / run_count fields. Pass "
            "include_deprecated=true to surface fully-deprecated tools, and use "
            "search / tags to narrow the listing."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "include_deprecated": {
                    "type": "boolean",
                    "description": (
                        "Include tools where every declaration is marked deprecated. "
                        "Defaults to false."
                    ),
                },
                "search": {
                    "type": ["string", "null"],
                    "description": (
                        "Case-insensitive substring filter on tool name + "
                        "description (Phase 5). Older PTM servers ignore."
                    ),
                },
                "tags": {
                    "type": ["string", "null"],
                    "description": (
                        "Comma-separated tag list with AND semantics: a tool "
                        "is returned only when it carries every listed tag. "
                        "Phase 5; older PTM servers ignore."
                    ),
                },
            },
            "additionalProperties": False,
        },
    )


async def _list_tools_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    include_deprecated = bool(arguments.get("include_deprecated", False))
    search = arguments.get("search") or None
    tags = arguments.get("tags") or None
    return await call_client_safely(
        client.list_tools,
        include_deprecated=include_deprecated,
        search=search,
        tags=tags,
    )


# ----------------------------------------------------------------------
# export_tool_registry (Phase 5 / B3)
# ----------------------------------------------------------------------


def _export_tool_registry_schema() -> Tool:
    return Tool(
        name="export_tool_registry",
        description=(
            "Download the entire tool registry as a YAML document. "
            "Includes every distinct tool declared on a prompt's active "
            "version, with deprecation flags, migration paths, tags, and "
            "prompt counts. Useful for offline review or copy-paste into "
            "a second PTM instance. Phase 5; requires PTM 1.12.0+."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    )


async def _export_tool_registry_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    del arguments  # no inputs; signature kept for handler protocol parity
    return await call_client_safely(client.export_tools)


# ----------------------------------------------------------------------
# get_tool_dependents
# ----------------------------------------------------------------------


def _get_tool_dependents_schema() -> Tool:
    return Tool(
        name="get_tool_dependents",
        description=(
            "Return the prompts that depend on a given tool, filtered by the "
            "caller's visibility. Each entry has prompt_id, prompt_name, and "
            "the version_number that declares the tool."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tool_name": {"type": "string"},
            },
            "required": ["tool_name"],
            "additionalProperties": False,
        },
    )


async def _get_tool_dependents_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    tool_name = arguments.get("tool_name")
    if not isinstance(tool_name, str) or not tool_name:
        raise ValueError("'tool_name' is required and must be a non-empty string")
    return await call_client_safely(client.get_tool_dependents, tool_name)


# ----------------------------------------------------------------------
# Write tools (Phase 2). All gated by ensure_writes_allowed; backend
# enforces manage_tool_registry permission on top.
# ----------------------------------------------------------------------


_TOOL_OBJECT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["name", "description"],
    "additionalProperties": False,
    "properties": {
        "name": {
            "type": "string",
            "minLength": 1,
            "maxLength": 128,
            "pattern": "^[a-z][a-z0-9_]*$",
        },
        "description": {"type": "string", "minLength": 1, "maxLength": 2000},
        "input_schema": {"type": "object"},
        "mock_responses": {"type": "array", "items": {"type": "object"}},
        "tags": {"type": "array", "items": {"type": "string"}},
        "server": {"type": ["string", "null"]},
        "deprecated": {"type": "boolean"},
    },
}


def _require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value


def _require_int(arguments: dict[str, Any], key: str) -> int:
    value = arguments.get(key)
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise ValueError(f"'{key}' is required and must be a positive integer")
    return value


def _create_tool_schema() -> Tool:
    return Tool(
        name="create_tool",
        description=(
            "Create or upsert a tool definition on a specific prompt version. "
            "Re-posting with the same name updates the existing tool. Requires "
            "the manage_tool_registry permission and PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "version_number", "tool"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
                "version_number": {"type": "integer", "minimum": 1},
                "tool": _TOOL_OBJECT_SCHEMA,
            },
        },
    )


def _make_create_tool_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = _require_str(arguments, "prompt_id")
        version_number = _require_int(arguments, "version_number")
        tool = arguments.get("tool")
        if not isinstance(tool, dict):
            raise ValueError("'tool' is required and must be an object")
        return await call_client_safely(client.create_tool, prompt_id, version_number, tool)

    return _handler


def _update_tool_schema() -> Tool:
    return Tool(
        name="update_tool",
        description=(
            "Patch one or more mutable fields on an existing tool definition. "
            "The tool name is immutable. Requires manage_tool_registry "
            "permission and PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "version_number", "tool_name"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
                "version_number": {"type": "integer", "minimum": 1},
                "tool_name": {"type": "string"},
                "description": {"type": "string", "minLength": 1, "maxLength": 2000},
                "input_schema": {"type": "object"},
                "mock_responses": {"type": "array", "items": {"type": "object"}},
                "tags": {"type": "array", "items": {"type": "string"}},
                "server": {"type": ["string", "null"]},
                "deprecated": {"type": "boolean"},
            },
        },
    )


def _make_update_tool_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = _require_str(arguments, "prompt_id")
        version_number = _require_int(arguments, "version_number")
        tool_name = _require_str(arguments, "tool_name")
        patch = {
            k: v
            for k, v in arguments.items()
            if k not in {"prompt_id", "version_number", "tool_name"} and v is not None
        }
        if not patch:
            raise ValueError("No mutable fields supplied to update_tool")
        return await call_client_safely(
            client.update_tool, prompt_id, version_number, tool_name, **patch
        )

    return _handler


def _deprecate_tool_schema() -> Tool:
    return Tool(
        name="deprecate_tool",
        description=(
            "Mark a tool definition deprecated on a specific prompt version. "
            "The tool stays addressable; readers can filter via "
            "include_deprecated=false (the default). Phase 5 adds optional "
            "migration_path (replacement tool name) and deprecation_message "
            "(reason + migration instructions) fields that round-trip on "
            "subsequent list_tools calls. Requires manage_tool_registry "
            "permission and PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "version_number", "tool_name"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
                "version_number": {"type": "integer", "minimum": 1},
                "tool_name": {"type": "string"},
                "migration_path": {
                    "type": ["string", "null"],
                    "maxLength": 255,
                    "description": "Name of the replacement tool.",
                },
                "deprecation_message": {
                    "type": ["string", "null"],
                    "maxLength": 1000,
                    "description": "Human-readable reason + migration instructions.",
                },
            },
        },
    )


def _make_deprecate_tool_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = _require_str(arguments, "prompt_id")
        version_number = _require_int(arguments, "version_number")
        tool_name = _require_str(arguments, "tool_name")
        migration_path = arguments.get("migration_path")
        deprecation_message = arguments.get("deprecation_message")
        if migration_path is not None and not isinstance(migration_path, str):
            raise ValueError("'migration_path' must be a string when provided")
        if deprecation_message is not None and not isinstance(deprecation_message, str):
            raise ValueError("'deprecation_message' must be a string when provided")
        return await call_client_safely(
            client.deprecate_tool,
            prompt_id,
            version_number,
            tool_name,
            migration_path=migration_path,
            deprecation_message=deprecation_message,
        )

    return _handler


def _delete_mock_profile_schema() -> Tool:
    return Tool(
        name="delete_mock_profile",
        description=(
            "Delete a named mock_tool_profile from a prompt version. Requires "
            "manage_tool_registry permission and PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "version_number", "profile_name"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
                "version_number": {"type": "integer", "minimum": 1},
                "profile_name": {"type": "string"},
            },
        },
    )


def _make_delete_mock_profile_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = _require_str(arguments, "prompt_id")
        version_number = _require_int(arguments, "version_number")
        profile_name = _require_str(arguments, "profile_name")
        await call_client_safely(
            client.delete_mock_profile, prompt_id, version_number, profile_name
        )
        return {"deleted": True, "profile_name": profile_name}

    return _handler
