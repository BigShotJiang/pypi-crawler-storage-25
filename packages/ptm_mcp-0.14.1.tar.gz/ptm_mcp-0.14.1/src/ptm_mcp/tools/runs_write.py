"""Run-mutation MCP tools (Flywheel Phase 2).

Single tool today: ``submit_run_feedback``. Gated by
``ensure_writes_allowed`` so an operator who flips
``PTM_MCP_READ_ONLY=true`` cannot accidentally record telemetry from a
read-only deployment. Backend RBAC + the 60-second dedup window remain
the source of truth; the MCP layer only translates errors.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ..config import Settings
from ._helpers import call_client_safely
from ._writes import ensure_writes_allowed

_FEEDBACK_SIGNALS = ("thumbs_up", "thumbs_down", "regen", "refusal", "apology")


def specs(settings: Settings) -> list[tuple[Tool, Any]]:
    return [(_submit_run_feedback_schema(), _make_submit_run_feedback_handler(settings))]


def _submit_run_feedback_schema() -> Tool:
    return Tool(
        name="submit_run_feedback",
        description=(
            "Records a feedback signal on a PTM run. Use this when an agent or "
            "user observes a regression, refusal, retry, or quality issue on a "
            "previously submitted run. Signals: thumbs_up, thumbs_down, regen, "
            "refusal, apology. Server bounds verbatim at 4000 chars and "
            "dedup'es identical caller + signal calls within a 60-second "
            "window. Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["run_id", "signal"],
            "additionalProperties": False,
            "properties": {
                "run_id": {
                    "type": "string",
                    "description": "Run key (the same identifier used by get_run / list_runs).",
                },
                "signal": {
                    "type": "string",
                    "enum": list(_FEEDBACK_SIGNALS),
                },
                "verbatim": {"type": "string", "maxLength": 4000},
                "context": {"type": "object"},
            },
        },
    )


def _make_submit_run_feedback_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        run_id = arguments.get("run_id")
        if not isinstance(run_id, str) or not run_id:
            raise ValueError("'run_id' is required and must be a non-empty string")
        signal = arguments.get("signal")
        if signal not in _FEEDBACK_SIGNALS:
            raise ValueError(f"'signal' must be one of {_FEEDBACK_SIGNALS}; got {signal!r}")
        verbatim = arguments.get("verbatim")
        if verbatim is not None and not isinstance(verbatim, str):
            raise ValueError("'verbatim' must be a string when provided")
        context = arguments.get("context")
        if context is not None and not isinstance(context, dict):
            raise ValueError("'context' must be an object when provided")
        return await call_client_safely(
            client.submit_run_feedback,
            run_id,
            signal,
            verbatim,
            context,
        )

    return _handler
