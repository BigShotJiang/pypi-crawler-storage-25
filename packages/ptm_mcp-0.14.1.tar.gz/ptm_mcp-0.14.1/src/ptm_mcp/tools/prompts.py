"""Prompt-library read tools: list_prompts, get_prompt, get_prompt_tests, load_prompt, list_groups."""  # noqa: E501

from __future__ import annotations

import re
from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ._helpers import call_client_safely


def specs() -> list[tuple[Tool, Any]]:
    return [
        (_list_prompts_schema(), _list_prompts_handler),
        (_get_prompt_schema(), _get_prompt_handler),
        (_get_prompt_tests_schema(), _get_prompt_tests_handler),
        (_get_prompt_contents_schema(), _get_prompt_contents_handler),
        (_load_prompt_schema(), _load_prompt_handler),
        (_list_groups_schema(), _list_groups_handler),
    ]


# ----------------------------------------------------------------------
# list_prompts
# ----------------------------------------------------------------------


def _list_prompts_schema() -> Tool:
    return Tool(
        name="list_prompts",
        description=(
            "List prompts in the PTM library. All filters are optional; pass only the "
            "ones you want to apply. Returns a list of prompt summaries."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tag": {"type": "string", "description": "Filter by a single tag."},
                "team": {"type": "string", "description": "Filter by owning team."},
                "service": {"type": "string", "description": "Filter by service."},
                "source": {
                    "type": "string",
                    "description": "Filter by source (e.g. 'library', 'repository').",
                },
                "search": {"type": "string", "description": "Free-text search."},
                "group": {"type": "string", "description": "Filter by group name."},
            },
            "additionalProperties": False,
        },
    )


async def _list_prompts_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    return await call_client_safely(
        client.list_prompts,
        tag=arguments.get("tag"),
        team=arguments.get("team"),
        service=arguments.get("service"),
        source=arguments.get("source"),
        search=arguments.get("search"),
        group=arguments.get("group"),
    )


# ----------------------------------------------------------------------
# get_prompt
# ----------------------------------------------------------------------


def _get_prompt_schema() -> Tool:
    return Tool(
        name="get_prompt",
        description="Fetch a single prompt record by ID.",
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string"},
            },
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


async def _get_prompt_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    return await call_client_safely(client.get_prompt, prompt_id)


# ----------------------------------------------------------------------
# get_prompt_tests
# ----------------------------------------------------------------------


def _get_prompt_tests_schema() -> Tool:
    return Tool(
        name="get_prompt_tests",
        description="Return test cases and DeepEval metrics attached to a prompt.",
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string"},
            },
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


async def _get_prompt_tests_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    return await call_client_safely(client.get_prompt_tests, prompt_id)


# ----------------------------------------------------------------------
# get_prompt_contents (Phase 18.8)
# ----------------------------------------------------------------------


def _get_prompt_contents_schema() -> Tool:
    return Tool(
        name="get_prompt_contents",
        description=(
            "Cheap fetch: returns prompt_text + tests + DeepEval metrics + tool "
            "definitions. NO LLM call. NO run history row. NO server-side "
            "execution. This is the read primitive that `run_prompt_inline` is "
            "built on. Use this when you already know you want to execute the "
            "prompt on YOUR model and you only need the prompt + tests + tool "
            "definitions. For server-side eval, use `run_prompt_eval_ptm`."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {
                    "type": "string",
                    "description": "PTM prompt_id (e.g. 'devops.vuln_dispatch').",
                },
                "version": {
                    "type": "integer",
                    "minimum": 1,
                    "description": "Optional version pin. Defaults to the active version.",
                },
            },
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


async def _get_prompt_contents_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    version = arguments.get("version")
    return await call_client_safely(
        client.get_prompt_contents,
        prompt_id,
        version=int(version) if version is not None else None,
    )


# ----------------------------------------------------------------------
# load_prompt
# ----------------------------------------------------------------------


def _load_prompt_schema() -> Tool:
    return Tool(
        name="load_prompt",
        description=(
            "Fetch the active prompt text from PTM and render it with your inputs "
            "so you can execute it directly in the current Claude session. NO LLM "
            "call. NO run history row. NO server-side execution - the caller runs "
            "the prompt locally. Returns rendered text for YOU to execute inline. "
            "For server-side eval that produces a scored run row, use "
            "`run_prompt_eval_ptm`."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {
                    "type": "string",
                    "description": "PTM prompt_id (e.g. 'devops.vuln_dispatch').",
                },
                "inputs": {
                    "type": "object",
                    "description": (
                        "Key-value map filling {{variable}} placeholders in the prompt. "
                        "Omit or pass {} if the prompt has no variables."
                    ),
                    "additionalProperties": True,
                },
            },
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


async def _load_prompt_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    inputs: dict[str, Any] = arguments.get("inputs") or {}

    prompt = await call_client_safely(client.get_prompt, prompt_id)
    prompt_text: str = prompt.get("prompt_text") or ""

    for key, value in inputs.items():
        prompt_text = prompt_text.replace("{{" + key + "}}", str(value))

    return {
        "prompt_id": prompt_id,
        "name": prompt.get("name"),
        "description": prompt.get("description"),
        "active_version": prompt.get("active_version"),
        "rendered_prompt": prompt_text,
        "unresolved_variables": [
            token[2:-2] for token in re.findall(r"\{\{[^}]+\}\}", prompt_text)
        ],
    }


# ----------------------------------------------------------------------
# list_groups
# ----------------------------------------------------------------------


def _list_groups_schema() -> Tool:
    return Tool(
        name="list_groups",
        description=(
            "List prompt groups visible to the caller. Returns id, name, and "
            "member count for each group. Use the id as team_group_id when "
            "publishing a skill to a team namespace."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    )


async def _list_groups_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    return await call_client_safely(client.list_groups)


def _require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value
