"""Write tools for evaluation submission: run_manual_eval, run_prompt_eval.

Both tools go through the read-only gate in ``_writes.ensure_writes_allowed``.
``run_prompt_eval`` routes through ``PTMClient.run_prompt_eval`` which
internally POSTs to ``/evaluations/manual`` after fetching the prompt's
stored content and tests - that is the correct shape per
``~/dev/docs/code-review-1.md`` C6.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ..config import Settings
from ._helpers import call_client_safely
from ._writes import ensure_writes_allowed

_VISIBILITY_SCOPES = ("private_only", "org_visible", "group_visible")


def specs(settings: Settings) -> list[tuple[Tool, Any]]:
    """Return (schema, handler) pairs, closing over ``settings`` for the gate."""
    return [
        (_run_manual_eval_schema(), _make_manual_handler(settings)),
        (_run_prompt_eval_schema(), _make_prompt_handler(settings)),
    ]


# ----------------------------------------------------------------------
# run_manual_eval
# ----------------------------------------------------------------------


def _run_manual_eval_schema() -> Tool:
    return Tool(
        name="run_manual_eval",
        description=(
            "QA EVALUATION with a custom prompt (not ad-hoc execution): Submit a "
            "free-form prompt template and your own test cases for scoring. Results are "
            "recorded in PTM history. Use this when you want to evaluate a prompt that "
            "is NOT yet in the PTM library, or when you want to test a one-off variant "
            "with custom test cases. "
            "For prompts already in PTM, use run_prompt_eval (which loads stored tests "
            "automatically). "
            "To just call a prompt and get the answer without running a test suite, "
            "use run_prompt instead. "
            "Returns run_key for fetching results. Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_text": {
                    "type": "string",
                    "description": "The prompt template (supports {{var}} placeholders).",
                },
                "tests": {
                    "type": "array",
                    "description": (
                        "List of {description, vars, assert?, expected_output?} test cases."
                    ),
                    "items": {"type": "object", "additionalProperties": True},
                    "minItems": 1,
                },
                "provider_profiles": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Provider profile names from list_providers.",
                    "minItems": 1,
                },
                "judge_profile": {
                    "type": ["string", "null"],
                    "description": "DeepEval judge profile name.",
                },
                "additional_metrics": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "DeepEval metrics.",
                },
                "additional_kpis": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Weighted KPI expressions.",
                },
                "label": {"type": "string"},
                "visibility_scope": {"type": "string", "enum": list(_VISIBILITY_SCOPES)},
                "cost_threshold": {"type": "number"},
                "latency_threshold_ms": {"type": "integer"},
            },
            "required": ["prompt_text", "tests", "provider_profiles"],
            "additionalProperties": False,
        },
    )


def _make_manual_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_text = _require_str(arguments, "prompt_text")
        tests = _require_non_empty_list(arguments, "tests")
        provider_profiles = _require_non_empty_list(arguments, "provider_profiles")

        payload: dict[str, Any] = {
            "prompt_text": prompt_text,
            "tests": tests,
            "provider_profiles": provider_profiles,
        }
        for optional_key in (
            "judge_profile",
            "additional_metrics",
            "additional_kpis",
            "label",
            "visibility_scope",
            "cost_threshold",
            "latency_threshold_ms",
        ):
            if arguments.get(optional_key) is not None:
                payload[optional_key] = arguments[optional_key]

        return await call_client_safely(client.run_manual_eval, payload)

    return _handler


# ----------------------------------------------------------------------
# run_prompt_eval
# ----------------------------------------------------------------------


def _run_prompt_eval_schema() -> Tool:
    return Tool(
        name="run_prompt_eval",
        description=(
            "QA EVALUATION (not ad-hoc execution): Run a PTM prompt against ALL of its "
            "stored test cases, score every result, and record the run in PTM history for "
            "tracking over time. Use this for regression testing, QA gates, and verifying "
            "a prompt version before promoting it. Returns a run_key you can use with "
            "get_run / get_run_report to check results. "
            "To just call the prompt with specific inputs and get the answer (no test suite, "
            "no history), use run_prompt instead. "
            "Fetches stored prompt content + tests; use inject_vars to override shared "
            "variables across all test cases. Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string"},
                "provider_profiles": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                },
                "inject_vars": {
                    "type": "object",
                    "additionalProperties": {"type": "string"},
                },
                "extra_tests": {"type": "array", "items": {"type": "object"}},
                "visibility_scope": {"type": "string", "enum": list(_VISIBILITY_SCOPES)},
                "label": {"type": "string"},
            },
            "required": ["prompt_id", "provider_profiles"],
            "additionalProperties": False,
        },
    )


def _make_prompt_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = _require_str(arguments, "prompt_id")
        provider_profiles = _require_non_empty_list(arguments, "provider_profiles")

        kwargs: dict[str, Any] = {}
        if arguments.get("inject_vars") is not None:
            kwargs["inject_vars"] = arguments["inject_vars"]
        if arguments.get("extra_tests") is not None:
            kwargs["extra_tests"] = arguments["extra_tests"]
        if arguments.get("visibility_scope") is not None:
            kwargs["visibility_scope"] = arguments["visibility_scope"]
        if arguments.get("label") is not None:
            kwargs["label"] = arguments["label"]

        return await call_client_safely(
            client.run_prompt_eval, prompt_id, provider_profiles, **kwargs
        )

    return _handler


# ----------------------------------------------------------------------
# Argument guards
# ----------------------------------------------------------------------


def _require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value


def _require_non_empty_list(arguments: dict[str, Any], key: str) -> list:
    value = arguments.get(key)
    if not isinstance(value, list) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty list")
    return value
