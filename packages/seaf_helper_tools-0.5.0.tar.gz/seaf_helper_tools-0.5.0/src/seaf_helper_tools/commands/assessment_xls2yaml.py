"""Command: convert a single assessment XLS survey to YAML."""

import logging
from enum import StrEnum
from pathlib import Path
from typing import Any

import typer
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rich.console import Console
from ruamel.yaml.comments import CommentedMap, CommentedSeq
from ruamel.yaml.scalarstring import LiteralScalarString

from seaf_helper_tools.utils.xls_utils import (
    find_col_idx,
    find_col_idx_multi_header,
    find_row_idx,
)
from seaf_helper_tools.utils.yaml_utils import read_yaml_rt, write_yaml

console = Console()

app = typer.Typer()

_OBJECT_KEY = "sber.dka-dzo.assessment.methods.standards.object"

# Поля ответа в req_compliance
_ANSWER_FIELDS = (
    "compliance",
    "comment",
    "method",
    "recommendation",
    "recommendation_short",
    "extra_questions",
)

# Обратный маппинг: XLS-значение (нижний регистр) → YAML-значение
_REVERSE_VALUE_MAP: dict[str, Any] = {
    "да": True,
    "нет": False,
    "монолит на нестандартном аппаратном обеспечении": "no_cloud_2",
    "монолит на стандартном аппаратном обеспечении": "no_cloud_1",
    "монолит на виртуализированном аппаратном обеспечении": "cloud_ready_1",
    "компоненты в контейнерах на виртуализированном аппаратном обеспечении": "cloud_ready_2",
    "компоненты в развёрнутом на виртуализированном аппаратном обеспечении оркестраторе контейнеров": "cloud_ready_3",
    (
        "cloud native (4) компоненты в частном облаке с управляемым облачным"
        " поставщиком программным обеспечением среды исполнения контейнеров"
    ): "cloud_native_1",
    (
        "cloud native (5) компоненты в гибридном публичном облаке/наборе облаков"
        " с управляемыми облачными поставщиками инфраструктурными сервисами"
    ): "cloud_native_2",
    (
        "cloud native (6) бессерверные (serverless) облачные приложения"
        " в публичном облаке/наборе облаков"
    ): "cloud_native_3",
}


class MergeMode(StrEnum):
    ABORT = "abort"
    ONLY_NEW = "only-new"
    OVERWRITE = "overwrite"
    INTERACTIVE = "interactive"
    OVERWRITE_ALL = "overwrite-all"


# ---------------------------------------------------------------------------
# Value helpers
# ---------------------------------------------------------------------------


def _reverse_value(value: Any) -> Any:
    """Map XLS display value back to YAML coded value (case-insensitive)."""
    if value is None:
        return None
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in _REVERSE_VALUE_MAP:
            return _REVERSE_VALUE_MAP[normalized]
    return value


def _wrap_multiline(value: Any) -> Any:
    """Wrap multiline strings in LiteralScalarString for block YAML style."""
    if isinstance(value, str) and ("\n" in value or "\r" in value):
        return LiteralScalarString(value.strip())
    return value


def _to_commented(data: Any) -> Any:
    """Recursively convert plain dict/list to CommentedMap/CommentedSeq."""
    if isinstance(data, (CommentedMap, CommentedSeq)):
        return data
    if isinstance(data, dict):
        cm: CommentedMap = CommentedMap()
        for k, v in data.items():
            cm[k] = _to_commented(v)
        return cm
    if isinstance(data, list):
        cs: CommentedSeq = CommentedSeq()
        for item in data:
            cs.append(_to_commented(item))
        return cs
    return data


# ---------------------------------------------------------------------------
# XLS parsing
# ---------------------------------------------------------------------------


def _read_era_manifest(wb: Any) -> tuple[str, str, str]:
    """Read era-manifest sheet. Returns (company_ref, assessment_ref, object_ref)."""
    ws = wb["era-manifest"]
    props: dict[str, str] = {}
    for row_idx in range(ws.max_row):
        key = ws["A"][row_idx].value
        val = ws["B"][row_idx].value
        if key:
            props[str(key)] = str(val) if val is not None else ""

    for prop in ("company_ref", "assessment_ref", "object_ref"):
        if not props.get(prop):
            raise ValueError(
                f"Лист 'era-manifest' не содержит поле '{prop}'. "
                "Убедитесь что файл является корректной XLS-анкетой объекта оценки, "
                "а не пустым шаблоном. Поля era-manifest заполняются командой survey-standards-yaml2xls."
            )

    return props["company_ref"], props["assessment_ref"], props["object_ref"]


def _read_obshee(wb: Any) -> tuple[str | None, dict[str, Any]]:
    """Read Общее sheet. Returns (object_title, metainfo dict)."""
    ws = wb["Общее"]
    heading_col_a = ws["A"]
    header_row = ws[1]

    prop_names_idx = find_col_idx_multi_header(
        [header_row], ["era-propnames"], fail_fast=False
    )
    prop_values_idx = find_col_idx_multi_header(
        [header_row], ["era-propvalues"], fail_fast=False
    )

    prop_values_col_letter = (
        get_column_letter(prop_values_idx + 1) if prop_values_idx is not None else "B"
    )
    prop_values_col = ws[prop_values_col_letter]

    # Название объекта — специальная строка в col A
    title_row_idx = find_row_idx(
        heading_col_a,
        ["Название", "Имя", "Имя (АС1-АС2)", "Название (title)"],
        fail_fast=False,
        verbose=False,
    )
    object_title: str | None = None
    if title_row_idx is not None:
        raw = prop_values_col[title_row_idx].value
        object_title = str(raw).strip() if raw is not None else None

    # Динамические свойства через era-propnames → era-propvalues
    metainfo: dict[str, Any] = {}
    if prop_names_idx is not None and prop_values_idx is not None:
        for row in ws.iter_rows(min_row=2):
            prop_name = row[prop_names_idx].value
            if prop_name and isinstance(prop_name, str):
                raw_value = row[prop_values_idx].value
                metainfo[prop_name.strip()] = _reverse_value(raw_value)

    return object_title, metainfo


def _read_oprosnik(wb: Any) -> list[dict[str, Any]]:
    """Read Опросник sheet → list of req_compliance items."""
    ws = wb["Опросник"]
    head_row = ws[1]

    idx_era_id = find_col_idx(head_row, ["era-id вопроса"], fail_fast=False)
    if idx_era_id is None:
        logging.warning("Столбец 'era-id вопроса' не найден в листе Опросник")
        return []

    idx_answer = find_col_idx(
        head_row,
        [
            "ОТВЕТ - степень соответсвия стандарту",
            "ОТВЕТ - степень соответствия стандарту",
        ],
        fail_fast=False,
    )
    idx_comment = find_col_idx(head_row, ["Комментарий"], fail_fast=False)
    idx_method = find_col_idx(head_row, ["Метод проверки"], fail_fast=False)
    idx_recommend = find_col_idx(head_row, ["Рекомендации ДКА"], fail_fast=False)
    idx_recommend_short = find_col_idx(
        head_row, ["Рекомендации ДКА коротко"], fail_fast=False
    )
    idx_artefacts = find_col_idx(
        head_row, ["Артефакты", "Оставшиеся открытые вопросы"], fail_fast=False
    )

    def _cell(row: Any, idx: int | None) -> Any:
        if idx is None:
            return None
        val = row[idx].value
        return _wrap_multiline(val) if val is not None else None

    result: list[dict[str, Any]] = []
    for row in ws.iter_rows(min_row=2):
        era_id = row[idx_era_id].value
        if not era_id:
            continue
        result.append(
            {
                "requirement_ref": str(era_id).strip(),
                "compliance": _cell(row, idx_answer),
                "comment": _cell(row, idx_comment),
                "method": _cell(row, idx_method),
                "recommendation": _cell(row, idx_recommend),
                "recommendation_short": _cell(row, idx_recommend_short),
                "extra_questions": _cell(row, idx_artefacts),
            }
        )

    return result


def _parse_xls(xls_file: Path) -> tuple[str, str, CommentedMap]:
    """Parse XLS → (company_ref, object_ref, yaml_structure as CommentedMap)."""
    wb = load_workbook(filename=str(xls_file), data_only=True)
    try:
        if "era-manifest" not in wb.sheetnames:
            raise ValueError(
                f"Лист 'era-manifest' не найден в файле {xls_file}. "
                f"Найденные листы: {', '.join(wb.sheetnames)}. "
                "Убедитесь что передан корректный XLS-файл анкеты объекта оценки "
                "(обычно создаётся командой survey-standards-yaml2xls). "
                "Пустой шаблон без заполненных данных не подходит."
            )

        company_ref, assessment_ref, object_ref = _read_era_manifest(wb)
        object_title, metainfo = (
            _read_obshee(wb) if "Общее" in wb.sheetnames else (None, {})
        )
        req_compliance = _read_oprosnik(wb) if "Опросник" in wb.sheetnames else []

        obj_data: dict[str, Any] = {
            "assessment_ref": assessment_ref,
            "metainfo": metainfo,
            "req_compliance": req_compliance,
        }
        if object_title:
            obj_data["title"] = object_title

        return (
            company_ref,
            object_ref,
            _to_commented({_OBJECT_KEY: {object_ref: obj_data}}),
        )
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Merge logic
# ---------------------------------------------------------------------------


def _has_answers(yaml_data: Any) -> bool:
    """Return True if any req_compliance item has a non-null compliance field."""
    objects = yaml_data.get(_OBJECT_KEY, {}) if hasattr(yaml_data, "get") else {}
    for obj in objects.values():
        for req in obj.get("req_compliance") or []:
            if req.get("compliance") is not None:
                return True
    return False


def _apply_field(
    yaml_req: Any,
    xls_req: dict[str, Any],
    field: str,
    mode: MergeMode,
) -> None:
    """Apply merge mode to a single field of req_compliance item."""
    yaml_val = yaml_req.get(field)
    xls_val = xls_req.get(field)

    if mode == MergeMode.OVERWRITE_ALL:
        yaml_req[field] = xls_val

    elif mode == MergeMode.OVERWRITE:
        if xls_val is not None and xls_val != "":
            yaml_req[field] = xls_val

    elif mode == MergeMode.ONLY_NEW:
        if (
            (yaml_val is None or yaml_val == "")
            and xls_val is not None
            and xls_val != ""
        ):
            yaml_req[field] = xls_val

    elif mode == MergeMode.INTERACTIVE:
        if xls_val != yaml_val:
            if (
                xls_val is not None
                and xls_val != ""
                and yaml_val is not None
                and yaml_val != ""
            ):
                ref = yaml_req.get("requirement_ref", "?")
                if typer.confirm(
                    f"[{ref}] {field}: '{yaml_val}' → '{xls_val}'. Заменить?"
                ):
                    yaml_req[field] = xls_val
            elif xls_val is not None and xls_val != "":
                yaml_req[field] = xls_val


def _merge_req_compliance(
    yaml_reqs: Any,
    xls_reqs: list[dict[str, Any]],
    mode: MergeMode,
) -> None:
    """Merge XLS req_compliance items into existing YAML list (in-place)."""
    yaml_by_ref: dict[str, Any] = {}
    for req in yaml_reqs:
        ref = req.get("requirement_ref")
        if ref:
            yaml_by_ref[str(ref)] = req

    for xls_req in xls_reqs:
        ref = str(xls_req.get("requirement_ref", ""))
        if ref in yaml_by_ref:
            for field in _ANSWER_FIELDS:
                _apply_field(yaml_by_ref[ref], xls_req, field, mode)
        else:
            yaml_reqs.append(_to_commented(xls_req))


def _merge_metainfo(
    yaml_meta: Any,
    xls_meta: dict[str, Any],
    mode: MergeMode,
) -> None:
    """Merge XLS metainfo into existing YAML metainfo (in-place)."""
    for key, xls_val in xls_meta.items():
        yaml_val = yaml_meta.get(key)

        if mode == MergeMode.OVERWRITE_ALL:
            yaml_meta[key] = xls_val

        elif mode == MergeMode.OVERWRITE:
            if xls_val is not None and xls_val != "":
                yaml_meta[key] = xls_val

        elif mode == MergeMode.ONLY_NEW:
            if (
                (yaml_val is None or yaml_val == "")
                and xls_val is not None
                and xls_val != ""
            ):
                yaml_meta[key] = xls_val

        elif mode == MergeMode.INTERACTIVE:
            if xls_val != yaml_val:
                if (
                    xls_val is not None
                    and xls_val != ""
                    and yaml_val is not None
                    and yaml_val != ""
                ):
                    if typer.confirm(
                        f"metainfo[{key}]: '{yaml_val}' → '{xls_val}'. Заменить?"
                    ):
                        yaml_meta[key] = xls_val
                elif xls_val is not None and xls_val != "":
                    yaml_meta[key] = xls_val


def _merge_xls_into_yaml(
    yaml_data: Any, xls_data: CommentedMap, mode: MergeMode
) -> None:
    """Merge XLS-derived data into existing YAML data (in-place)."""
    xls_objects = xls_data.get(_OBJECT_KEY, {})
    if _OBJECT_KEY not in yaml_data:
        yaml_data[_OBJECT_KEY] = CommentedMap()
    yaml_objects = yaml_data[_OBJECT_KEY]

    for obj_ref, xls_obj in xls_objects.items():
        if obj_ref not in yaml_objects:
            yaml_objects[obj_ref] = xls_obj
            continue

        yaml_obj = yaml_objects[obj_ref]

        # Метаданные объекта
        if "assessment_ref" not in yaml_obj and xls_obj.get("assessment_ref"):
            yaml_obj["assessment_ref"] = xls_obj["assessment_ref"]
        if "title" not in yaml_obj and xls_obj.get("title"):
            yaml_obj["title"] = xls_obj["title"]

        # Metainfo
        if "metainfo" not in yaml_obj:
            yaml_obj["metainfo"] = CommentedMap()
        _merge_metainfo(yaml_obj["metainfo"], xls_obj.get("metainfo", {}), mode)

        # req_compliance
        if "req_compliance" not in yaml_obj:
            yaml_obj["req_compliance"] = CommentedSeq()
        _merge_req_compliance(
            yaml_obj["req_compliance"],
            list(xls_obj.get("req_compliance", [])),
            mode,
        )


# ---------------------------------------------------------------------------
# Typer command
# ---------------------------------------------------------------------------


@app.command("survey-standards-xls2yaml")
def assessment_xls2yaml(
    xls_file: Path = typer.Argument(
        ...,
        help=(
            "Путь к заполненному XLS-файлу анкеты объекта оценки. "
            "Файл должен содержать листы: 'era-manifest' (служебные поля), "
            "'Общее' (метаинформация), 'Опросник' (ответы на требования). "
            "Создаётся командой survey-standards-yaml2xls из YAML-файла. "
            "Пример: output/tile_server_survey.xlsx"
        ),
    ),
    output: Path = typer.Argument(
        ...,
        help=(
            "Путь к выходному YAML-файлу объекта оценки. "
            "Если файл не существует — создаётся новый. "
            "Если существует — применяется режим слияния (--mode). "
            "Директория создаётся автоматически. "
            "Пример: data/mybis/2025_0/tile_server.yaml"
        ),
    ),
    mode: MergeMode = typer.Option(
        MergeMode.ABORT,
        "--mode",
        "-m",
        help=(
            "Режим слияния при существующем YAML-файле с ответами. "
            "abort       — прервать с ошибкой (по умолчанию, защита от перезаписи). "
            "only-new    — перенести только поля, которые пусты в YAML (безопасно). "
            "overwrite   — перезаписать непустыми значениями из XLS, пустые XLS-ячейки игнорировать. "
            "interactive — спрашивать при каждом конфликте значений. "
            "overwrite-all — перенести всё из XLS, включая пустые ячейки (затирает YAML)."
        ),
    ),
) -> None:
    """Конвертировать заполненную XLS-анкету объекта оценки в YAML-файл.

    Читает XLS-анкету, созданную командой survey-standards-yaml2xls, и записывает данные
    в YAML-файл для хранения в репозитории:

      Лист 'era-manifest' → служебные поля: company_ref, assessment_ref, object_ref
      Лист 'Общее'        → метаинформация объекта (через era-propnames/era-propvalues)
      Лист 'Опросник'     → ответы на требования стандартов: compliance, comment,
                            method, recommendation, recommendation_short, extra_questions

    Поведение при существующем YAML-файле управляется через --mode.
    По умолчанию (abort) команда прерывается если в файле уже есть ответы,
    чтобы случайно не перезаписать результаты аудита.

    Типичный сценарий: аудитор заполнил XLS-анкету → команда переносит ответы
    обратно в YAML для версионирования в git.

    Пример вызова:
      survey-standards-xls2yaml анкета.xlsx объект.yaml
      survey-standards-xls2yaml анкета.xlsx объект.yaml --mode only-new
      survey-standards-xls2yaml анкета.xlsx объект.yaml --mode overwrite-all
    """
    if not xls_file.exists():
        console.print(
            f"[red]XLS-файл не найден:[/red] {xls_file}\n"
            "[yellow]Укажите путь к заполненному XLS-файлу анкеты объекта оценки. "
            "Файл создаётся командой survey-standards-yaml2xls.[/yellow]"
        )
        raise typer.Exit(1) from None

    try:
        company_ref, object_ref, xls_data = _parse_xls(xls_file)
    except ValueError as e:
        console.print(f"[red]Ошибка при чтении XLS:[/red] {e}")
        raise typer.Exit(1) from None

    if output.exists():
        yaml_existing = read_yaml_rt(output)

        if mode == MergeMode.ABORT:
            if _has_answers(yaml_existing):
                console.print(
                    f"[red]Прерывание:[/red] файл {output} уже содержит ответы.\n"
                    "[yellow]Укажите --mode чтобы управлять слиянием:[/yellow]\n"
                    "  --mode only-new      — перенести только пустые поля (безопасно)\n"
                    "  --mode overwrite     — перезаписать непустыми из XLS\n"
                    "  --mode interactive   — спрашивать при каждом конфликте\n"
                    "  --mode overwrite-all — перенести всё из XLS включая пустые"
                )
                raise typer.Exit(1) from None
            # Файл есть, но ответов нет — просто перезаписываем
            write_yaml(output, xls_data)
        else:
            _merge_xls_into_yaml(yaml_existing, xls_data, mode)
            write_yaml(output, yaml_existing)
    else:
        output.parent.mkdir(parents=True, exist_ok=True)
        write_yaml(output, xls_data)

    xls_objects = xls_data.get(_OBJECT_KEY, {})
    req_compliance_xls: list[dict[str, Any]] = []
    for obj in xls_objects.values():
        req_compliance_xls.extend(obj.get("req_compliance") or [])
    filled_count = sum(1 for r in req_compliance_xls if r.get("compliance") is not None)

    console.print(
        f"[green]Готово:[/green] {output}\n"
        f"  Объект:               {object_ref}\n"
        f"  Оценка:               {xls_objects.get(object_ref, {}).get('assessment_ref') or '(не указана)'}\n"
        f"  Компания:             {company_ref}\n"
        f"  Режим слияния:        {mode}\n"
        f"  Требований перенесено: {len(req_compliance_xls)} "
        f"(с ответом: {filled_count}, без ответа: {len(req_compliance_xls) - filled_count})"
    )
