"""Command: convert a single assessment object YAML to XLS survey."""

import logging
import shutil
from pathlib import Path
from typing import Any

import typer
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from rich.console import Console

from seaf_helper_tools.utils.nsi import build_nsi
from seaf_helper_tools.utils.xls_utils import (
    find_col_idx,
    find_col_idx_multi_header,
    find_row_idx,
)
from seaf_helper_tools.utils.yaml_utils import load_yaml

console = Console()

app = typer.Typer()

_OBJECT_KEY = "sber.dka-dzo.assessment.methods.standards.object"
_REQUIREMENTS_KEY = "seaf.change.requirements.dzo"
_COMPANIES_KEY = "companies"

# Ключи НСИ, которые запрашиваются из удалённого API при наличии конфига
_REMOTE_NSI_KEYS = [_COMPANIES_KEY, _REQUIREMENTS_KEY]

_REQUIRED_TEMPLATE_SHEETS = ("Общее", "Опросник", "era-manifest")

_VALUE_MAP: dict[Any, Any] = {
    True: "Да",
    False: "Нет",
    "no_cloud_2": "Монолит на нестандартном аппаратном обеспечении",
    "no_cloud_1": "Монолит на стандартном аппаратном обеспечении",
    "cloud_ready_1": "Монолит на виртуализированном аппаратном обеспечении",
    "cloud_ready_2": "Компоненты в контейнерах на виртуализированном аппаратном обеспечении",
    "cloud_ready_3": (
        "Компоненты в развёрнутом на виртуализированном аппаратном "
        "обеспечении оркестраторе контейнеров"
    ),
    "cloud_native_1": (
        "cloud native (4) компоненты в частном облаке с управляемым облачным "
        "поставщиком программным обеспечением среды исполнения контейнеров"
    ),
    "cloud_native_2": (
        "cloud native (5) компоненты в гибридном публичном облаке/наборе облаков "
        "с управляемыми облачными поставщиками инфраструктурными сервисами"
    ),
    "cloud_native_3": (
        "cloud native (6) бессерверные (serverless) облачные приложения "
        "в публичном облаке/наборе облаков"
    ),
}


def _decorate_value(value: Any) -> Any:
    return _VALUE_MAP.get(value, value)


# ---------------------------------------------------------------------------
# Sheet fillers
# ---------------------------------------------------------------------------


def _fill_obshee_sheet(
    ws: Any, company_title: str, object_title: str, metainfo: dict[str, Any]
) -> None:
    heading_col_a = ws["A"]

    # Find era-propnames / era-propvalues columns dynamically from row 1
    header_row = ws[1]
    prop_names_col_idx = find_col_idx_multi_header(
        [header_row], ["era-propnames"], fail_fast=False
    )
    prop_values_col_idx = find_col_idx_multi_header(
        [header_row], ["era-propvalues"], fail_fast=False
    )
    prop_values_col_letter = (
        get_column_letter(prop_values_col_idx + 1)
        if prop_values_col_idx is not None
        else "B"
    )
    prop_values_col = ws[prop_values_col_letter]

    # Special: company name
    company_row = find_row_idx(
        heading_col_a, ["Компания"], fail_fast=False, verbose=False
    )
    if company_row is not None:
        prop_values_col[company_row].value = company_title

    # Special: object title
    title_row = find_row_idx(
        heading_col_a,
        ["Название", "Имя", "Имя (АС1-АС2)", "Название (title)"],
        fail_fast=False,
        verbose=False,
    )
    if title_row is not None:
        prop_values_col[title_row].value = object_title

    # Dynamic: era-propnames → metainfo
    if prop_names_col_idx is not None:
        prop_names_col = ws[get_column_letter(prop_names_col_idx + 1)]
        for cell in prop_names_col:
            if cell.value and isinstance(cell.value, str):
                prop_name = cell.value.strip()
                if prop_name in metainfo:
                    row_idx = cell.row - 1
                    prop_values_col[row_idx].value = _decorate_value(
                        metainfo[prop_name]
                    )


def _fill_manifest_sheet(ws: Any, obj_id: str, assessment_ref: str) -> None:
    company_ref = assessment_ref.split(".")[0] if assessment_ref else ""
    ws[1][0].value = "template_version"
    ws[1][1].value = "0.1"
    ws[2][0].value = "company_ref"
    ws[2][1].value = company_ref
    ws[3][0].value = "assessment_ref"
    ws[3][1].value = assessment_ref
    ws[4][0].value = "object_ref"
    ws[4][1].value = obj_id


def _fill_oprosnik_sheet(ws: Any, req_compliance: list[dict[str, Any]]) -> None:
    head_row = ws[1]

    idx_era_id = find_col_idx(head_row, ["era-id вопроса"], fail_fast=False)
    if idx_era_id is None:
        logging.warning("Столбец 'era-id вопроса' не найден в листе Опросник")
        return

    idx_answer = find_col_idx(
        head_row, ["ОТВЕТ - степень соответсвия стандарту"], fail_fast=False
    )
    idx_comment = find_col_idx(head_row, ["Комментарий"], fail_fast=False)
    idx_method = find_col_idx(head_row, ["Метод проверки"], fail_fast=False)
    idx_recommend = find_col_idx(head_row, ["Рекомендации ДКА"], fail_fast=False)
    idx_recommend_short = find_col_idx(
        head_row, ["Рекомендации ДКА коротко"], fail_fast=False
    )
    idx_artefacts = find_col_idx(
        head_row, ["Артефакты", "Оставшиеся открытые вопросы"], fail_fast=False
    )

    # Build era-id → row_idx map (1-based row numbers)
    era_id_to_row: dict[str, int] = {}
    for row_idx in range(2, ws.max_row + 1):
        cell_value = ws[row_idx][idx_era_id].value
        if cell_value:
            era_id_to_row[str(cell_value).strip()] = row_idx

    for req in req_compliance:
        req_ref = req.get("requirement_ref")
        if not req_ref:
            continue
        matched_row = era_id_to_row.get(str(req_ref).strip())
        if matched_row is None:
            logging.debug("requirement_ref %s не найден в шаблоне", req_ref)
            continue

        row = ws[matched_row]
        if idx_answer is not None:
            row[idx_answer].value = req.get("compliance")
        if idx_comment is not None:
            row[idx_comment].value = req.get("comment")
        if idx_method is not None:
            row[idx_method].value = req.get("method")
        if idx_recommend is not None:
            row[idx_recommend].value = req.get("recommendation")
        if idx_recommend_short is not None:
            row[idx_recommend_short].value = req.get("recommendation_short")
        if idx_artefacts is not None:
            row[idx_artefacts].value = req.get("extra_questions")


# ---------------------------------------------------------------------------
# Typer command
# ---------------------------------------------------------------------------


@app.command("survey-standards-yaml2xls")
def assessment_yaml2xls(
    yaml_file: Path = typer.Argument(
        ...,
        help=(
            "Путь к YAML-файлу объекта оценки. "
            "Файл должен содержать ключ верхнего уровня "
            "'sber.dka-dzo.assessment.methods.standards.object' "
            "с одним объектом оценки. "
            "Структура: {id_объекта: {title, assessment_ref, "
            "metainfo: {поле: значение}, req_compliance: [{requirement_ref, compliance, ...}]}}. "
            "Пример: data/mybis/2025_0/tile_server.yaml"
        ),
    ),
    output: Path = typer.Argument(
        ...,
        help=(
            "Путь для сохранения результирующего XLS-файла анкеты. "
            "Директория создаётся автоматически. "
            "Существующий файл перезаписывается без предупреждения. "
            "Пример: output/tile_server_survey.xlsx"
        ),
    ),
    template: Path = typer.Option(
        ...,
        "--template",
        "-t",
        help=(
            "Путь к XLS-шаблону анкеты. "
            "Шаблон должен содержать три листа: "
            "'Общее' (метаинформация, с заголовками era-propnames и era-propvalues), "
            "'Опросник' (список требований с колонкой 'era-id вопроса'), "
            "'era-manifest' (служебные поля). "
            "Данные из YAML записываются поверх шаблона, его структура сохраняется. "
            "Пример: templates/survey_as.xlsx"
        ),
    ),
    company: str = typer.Option(
        ...,
        "--company",
        "-c",
        help=(
            "Название компании — записывается в поле 'Компания' листа 'Общее'. "
            "Берётся из Реестра компаний $.companies. "
            "Пример: 'ООО Лютик'."
        ),
    ),
    extra_data: list[Path] = typer.Option(
        [],
        "--extra_data",
        "-d",
        help=(
            "Дополнительные YAML-файлы или директории для индексации "
            "(опционально, флаг можно повторять несколько раз). "
            "Зарезервировано для будущей функциональности. "
            "Пример: --extra_data dependencies/assess-portal --extra_data dependencies/seafera-portal"
        ),
    ),
) -> None:
    """Сформировать XLS-анкету объекта оценки из YAML-данных.

    Читает YAML-файл с данными объекта оценки и заполняет XLS-шаблон:

      Лист 'Общее'        — название объекта, компания и поля метаинформации
                            (из секции metainfo YAML-файла через колонки era-propnames/era-propvalues)
      Лист 'Опросник'     — ответы на требования стандартов
                            (из секции req_compliance: compliance, comment, method,
                            recommendation, recommendation_short, extra_questions)
      Лист 'era-manifest' — служебные поля: company_ref, assessment_ref, object_ref

    Типичный сценарий: YAML содержит ответы аудитора,
    команда переносит их в XLS-форму для передачи заказчику или заполнения.

    Пример вызова:
      survey-standards-yaml2xls объект.yaml анкета.xlsx --template шаблон.xlsx --company "ООО Лютик"
    """
    if not yaml_file.exists():
        console.print(
            f"[red]YAML-файл не найден:[/red] {yaml_file}\n"
            "[yellow]Укажите путь к существующему YAML-файлу объекта оценки. "
            f"Файл должен содержать ключ верхнего уровня '{_OBJECT_KEY}'.[/yellow]"
        )
        raise typer.Exit(1)

    if not template.exists():
        console.print(
            f"[red]Шаблон XLS не найден:[/red] {template}\n"
            "[yellow]Укажите путь к существующему XLS-файлу шаблона анкеты. "
            f"Шаблон должен содержать листы: {', '.join(_REQUIRED_TEMPLATE_SHEETS)}.[/yellow]"
        )
        raise typer.Exit(1)

    # Проверяем наличие обязательных листов в шаблоне
    _wb_check = load_workbook(filename=str(template), read_only=True)
    missing_sheets = [
        s for s in _REQUIRED_TEMPLATE_SHEETS if s not in _wb_check.sheetnames
    ]
    _wb_check.close()
    if missing_sheets:
        console.print(
            f"[red]Шаблон {template} не содержит обязательные листы:[/red] "
            f"{', '.join(missing_sheets)}\n"
            f"[yellow]Шаблон должен содержать листы: {', '.join(_REQUIRED_TEMPLATE_SHEETS)}. "
            "Проверьте что указан верный файл шаблона.[/yellow]"
        )
        raise typer.Exit(1)

    # Загружаем YAML
    raw = load_yaml(yaml_file)
    objects = raw.get(_OBJECT_KEY, {})
    if not objects:
        console.print(
            f"[red]Неверная структура YAML-файла:[/red] {yaml_file}\n"
            f"[yellow]Не найден ключ верхнего уровня '{_OBJECT_KEY}'.\n"
            "Убедитесь что файл содержит данные объекта оценки.\n"
            "Ожидаемая структура:\n"
            f"  {_OBJECT_KEY}:\n"
            "    <id_объекта>:\n"
            "      title: ...\n"
            "      assessment_ref: ...\n"
            "      metainfo: {{...}}\n"
            "      req_compliance: [{{requirement_ref: ..., compliance: ...}}][/yellow]"
        )
        raise typer.Exit(1)

    obj_id, obj_data = next(iter(objects.items()))
    metainfo: dict[str, Any] = obj_data.get("metainfo") or {}
    req_compliance: list[dict[str, Any]] = obj_data.get("req_compliance") or []
    object_title: str = obj_data.get("title") or ""
    assessment_ref: str = obj_data.get("assessment_ref") or ""

    # Собираем НСИ из локальных YAML и удалённого API (при наличии конфига)
    jsonata_client = None
    from seaf_helper_tools.core.config import get_config

    api_config = get_config().api
    if api_config is not None:
        try:
            from seaf_helper_tools.utils.jsonata import SeafJsonataCall
            from seaf_helper_tools.utils.secured_api import SecuredApiCall

            _api = SecuredApiCall(
                cert_file_path=api_config.cert_path,
                cert_password=api_config.get_cert_password(),
                host_name=api_config.host,
                verify_ssl=api_config.verify_ssl,
            )
            jsonata_client = SeafJsonataCall(_api)
        except Exception as e:
            logging.warning("Не удалось инициализировать API-клиент для НСИ: %s", e)

    _nsi = build_nsi(
        extra_data=list(extra_data),
        jsonata_client=jsonata_client,
        remote_keys=_REMOTE_NSI_KEYS if jsonata_client is not None else None,
    )

    # Copy template → output, then fill
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template, output)

    wb = load_workbook(filename=output, data_only=False)

    _fill_obshee_sheet(wb["Общее"], company, object_title, metainfo)
    _fill_manifest_sheet(wb["era-manifest"], obj_id, assessment_ref)
    _fill_oprosnik_sheet(wb["Опросник"], req_compliance)

    wb.save(output)

    filled_count = sum(1 for r in req_compliance if r.get("compliance") is not None)
    console.print(
        f"[green]Готово:[/green] {output}\n"
        f"  Объект:               {obj_id}\n"
        f"  Оценка:               {assessment_ref or '(не указана)'}\n"
        f"  Компания:             {company}\n"
        f"  Требований перенесено: {len(req_compliance)} "
        f"(с ответом: {filled_count}, без ответа: {len(req_compliance) - filled_count})"
    )
