"""Поиск маршрутов между типами данных через граф связей SEAF.

Помогает LLM выбрать правильные типы для JOIN при написании JSONata запроса
и использовать корректные способы связывания.

Портировано из mcp_tools/tools/link_graph.py.
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger("seaf_helper_tools.mcp.link_graph")


@dataclass
class _GraphCache:
    """Кэш загруженного графа с отслеживанием изменений файла."""

    data: dict[str, Any]
    mtime: float


_cache: dict[Path, _GraphCache] = {}


def get_cached_graph(graph_path: Path) -> dict[str, Any]:
    """Получить данные графа с кэшированием и автоперезагрузкой при изменении файла.

    Args:
        graph_path: Путь к файлу link_graph.json.

    Returns:
        Распарсенные данные графа (из кэша или свежезагруженные).

    Raises:
        FileNotFoundError: Если файл не существует.
        ValueError: Если файл содержит некорректный JSON.
    """
    current_mtime = graph_path.stat().st_mtime if graph_path.exists() else None

    if current_mtime is None:
        raise FileNotFoundError(f"Файл графа связей не найден: {graph_path}")

    cached = _cache.get(graph_path)

    if cached is not None and cached.mtime == current_mtime:
        return cached.data

    if cached is None:
        logger.info("link_graph: загрузка графа из %s", graph_path)
    else:
        logger.info("link_graph: файл изменился, перезагрузка графа из %s", graph_path)

    data = load_graph(graph_path)
    _cache[graph_path] = _GraphCache(data=data, mtime=current_mtime)
    return data


@dataclass
class GraphEdge:
    """Ребро в графе связей типов.

    Attributes:
        source_type: Тип, который содержит свойство-ссылку.
        target_type: Тип, на который ссылается свойство.
        kind: Вид связи (property_id_equal, id_prefix и др.).
        property: Имя свойства для kind=property_id_equal.
    """

    source_type: str
    target_type: str
    kind: str
    property: str | None


@dataclass
class Route:
    """Маршрут от стартового типа до финишного.

    Attributes:
        nodes: Упорядоченный список type_id в маршруте.
        edges: Описания связей между соседними узлами.
    """

    nodes: list[str]
    edges: list[GraphEdge]

    @property
    def length(self) -> int:
        """Количество переходов (рёбер) в маршруте."""
        return len(self.edges)


def load_graph(graph_path: Path) -> dict[str, Any]:
    """Загрузить граф связей из JSON файла.

    Args:
        graph_path: Путь к файлу link_graph.json.

    Returns:
        Распарсенные данные графа.

    Raises:
        FileNotFoundError: Если файл не существует.
        ValueError: Если файл содержит некорректный JSON.
    """
    if not graph_path.exists():
        raise FileNotFoundError(f"Файл графа связей не найден: {graph_path}")

    try:
        return json.loads(graph_path.read_text(encoding="utf-8"))  # type: ignore[no-any-return]
    except json.JSONDecodeError as e:
        raise ValueError(f"Некорректный JSON в файле графа: {graph_path}\n{e}") from e


def build_adjacency(graph_data: dict[str, Any]) -> dict[str, list[GraphEdge]]:
    """Построить двунаправленный список смежности из данных графа.

    Args:
        graph_data: Распарсенный JSON граф.

    Returns:
        Словарь type_id → список рёбер (GraphEdge).
    """
    adj: dict[str, list[GraphEdge]] = defaultdict(list)

    for source_type, connections in graph_data.items():
        for conn in connections:
            target_type: str = conn["type_id"]
            kind: str = conn["kind"]
            prop: str | None = conn.get("property")

            edge = GraphEdge(
                source_type=source_type,
                target_type=target_type,
                kind=kind,
                property=prop,
            )
            adj[source_type].append(edge)
            adj[target_type].append(edge)

    return dict(adj)


def get_all_type_ids(graph_data: dict[str, Any]) -> set[str]:
    """Получить множество всех type_id упомянутых в графе.

    Args:
        graph_data: Распарсенный JSON граф.

    Returns:
        Множество всех type_id (как ключи, так и targets).
    """
    type_ids: set[str] = set(graph_data.keys())
    for connections in graph_data.values():
        for conn in connections:
            type_ids.add(conn["type_id"])
    return type_ids


def find_all_shortest_paths(
    adj: dict[str, list[GraphEdge]],
    start: str,
    end: str,
    max_depth: int = 10,
) -> list[Route]:
    """Найти все кратчайшие простые пути от start до end через BFS.

    Args:
        adj: Двунаправленный список смежности.
        start: Стартовый type_id.
        end: Финишный type_id.
        max_depth: Максимальное количество узлов в пути.

    Returns:
        Список всех кратчайших маршрутов.
    """
    if start == end:
        return [Route(nodes=[start], edges=[])]

    queue: deque[tuple[str, list[str], list[GraphEdge], frozenset[str]]] = deque()
    queue.append((start, [start], [], frozenset({start})))

    all_routes: list[Route] = []
    min_found: int | None = None

    while queue:
        node, path_nodes, path_edges, visited = queue.popleft()

        if min_found is not None and len(path_nodes) >= min_found:
            continue
        if len(path_nodes) >= max_depth:
            continue

        for edge in adj.get(node, []):
            neighbor = (
                edge.target_type if edge.source_type == node else edge.source_type
            )

            if neighbor in visited:
                continue

            new_path_nodes = path_nodes + [neighbor]
            new_path_edges = path_edges + [edge]
            new_visited = visited | {neighbor}
            new_len = len(new_path_nodes)

            if neighbor == end:
                if min_found is None or new_len <= min_found:
                    min_found = new_len
                    all_routes.append(Route(nodes=new_path_nodes, edges=new_path_edges))
            else:
                if min_found is None or new_len < min_found:
                    queue.append(
                        (neighbor, new_path_nodes, new_path_edges, new_visited)
                    )

    return all_routes


def filter_by_intermediates(
    routes: list[Route],
    intermediate_types: list[str],
) -> list[Route]:
    """Отфильтровать маршруты, содержащие все указанные промежуточные типы.

    Args:
        routes: Маршруты для фильтрации.
        intermediate_types: Type ID, которые должны присутствовать как промежуточные.

    Returns:
        Маршруты, содержащие все промежуточные типы.
    """
    if not intermediate_types:
        return routes

    required = set(intermediate_types)
    return [r for r in routes if required.issubset(set(r.nodes[1:-1]))]


def _format_edge_join_hint(edge: GraphEdge, from_node: str) -> str:
    """Сформировать подсказку о способе соединения для ребра."""
    if edge.kind == "property_id_equal":
        return f"JOIN по: {edge.source_type}.{edge.property} = id({edge.target_type})"
    elif edge.kind == "id_prefix":
        return (
            f"JOIN по: id({edge.source_type}) начинается с префикса"
            f" id({edge.target_type})"
        )
    else:
        return f"Связь вида '{edge.kind}'"


def _format_single_route(route: Route, index: int) -> str:
    """Форматировать один маршрут в читаемый текст."""
    path_str = " → ".join(route.nodes)
    lines = [f"Маршрут {index}: {path_str}"]
    for i, edge in enumerate(route.edges):
        from_node = route.nodes[i]
        to_node = route.nodes[i + 1]
        hint = _format_edge_join_hint(edge, from_node)
        lines.append(f"  Шаг {i + 1}: {from_node} → {to_node}")
        lines.append(f"    {hint}")
    return "\n".join(lines)


def find_type_routes(
    graph_path: Path,
    start_type_id: str,
    end_type_id: str,
    intermediate_type_ids: list[str] | None = None,
    max_depth: int = 10,
) -> str:
    """Найти маршруты между двумя типами в графе связей.

    Args:
        graph_path: Путь к файлу link_graph.json.
        start_type_id: Стартовый type_id.
        end_type_id: Финишный type_id.
        intermediate_type_ids: Опциональный список type_id в маршруте.
        max_depth: Максимальная глубина поиска.

    Returns:
        Отформатированная строка с найденными маршрутами или сообщение об ошибке.
    """
    graph_data = get_cached_graph(graph_path)
    all_type_ids = get_all_type_ids(graph_data)

    missing = []
    if start_type_id not in all_type_ids:
        missing.append(f"'{start_type_id}'")
    if end_type_id not in all_type_ids and start_type_id != end_type_id:
        missing.append(f"'{end_type_id}'")

    if missing:
        return (
            f"Тип(ы) {', '.join(missing)} не найден(ы) в графе связей. "
            f"Уточните запрос: проверьте правильность написания type_id "
            f"или запросите у пользователя корректные идентификаторы типов."
        )

    adj = build_adjacency(graph_data)
    routes = find_all_shortest_paths(adj, start_type_id, end_type_id, max_depth)

    if not routes:
        return (
            f"Типы '{start_type_id}' и '{end_type_id}' в хранилище никак не связаны. "
            f"Стоит запросить у пользователя уточнения: какие ещё типы использовать "
            f"для написания запроса и получения нужных данных."
        )

    intermediates = intermediate_type_ids or []
    warning = ""

    if intermediates:
        filtered = filter_by_intermediates(routes, intermediates)
        if filtered:
            routes = filtered
        else:
            all_intermediate_nodes: set[str] = set()
            for r in routes:
                all_intermediate_nodes.update(r.nodes[1:-1])
            missing_intermediates = sorted(set(intermediates) - all_intermediate_nodes)
            warning = (
                f"\n⚠️  Желаемые промежуточные типы не участвуют "
                f"в кратчайших маршрутах: {', '.join(missing_intermediates)}. "
                f"Показаны маршруты без учёта этих типов."
            )

    lines: list[str] = []
    for i, route in enumerate(routes, 1):
        lines.append(_format_single_route(route, i))
        lines.append("")

    if warning:
        lines.append(warning)

    return "\n".join(lines).rstrip()
