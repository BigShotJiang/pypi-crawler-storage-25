"""Логирование JSONata запросов в JSONL-файл.

Портировано из mcp_tools/logging_config.py (только write_jsonata_log_entry).
"""

import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger("seaf_helper_tools.mcp.logging")

# Путь к директории логов — корень проекта (на 2 уровня выше пакета).
# src/seaf_helper_tools/mcp/logging.py -> src/seaf_helper_tools/mcp -> src/seaf_helper_tools -> src -> project_root
DEFAULT_LOG_DIR = Path(__file__).resolve().parents[4] / "logs"
DEFAULT_JSONATA_LOG_FILE = DEFAULT_LOG_DIR / "jsonata_queries.jsonl"


def write_jsonata_log_entry(
    query: str,
    purpose: str,
    expected_data: str,
    status: str,
    tool: str = "jsonata_query",
    user_request: str = "",
    current_plan_step: str = "",
    error: str | None = None,
    log_file: Path | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    """Записать одну запись о вызове JSONata инструмента в JSONL-файл.

    Каждый вызов дописывает одну JSON-строку в конец файла (append).
    При ошибке записи молча игнорирует — не прерывает работу сервера.

    Args:
        query: JSONata выражение или описание запроса.
        purpose: Причина вызова (на русском).
        expected_data: Ожидаемый результат (на русском).
        status: Признак результата: "empty", "non_empty" или "error".
        tool: Имя MCP-инструмента. По умолчанию "jsonata_query".
        user_request: Исходный запрос пользователя.
        current_plan_step: Текущий шаг плана.
        error: Текст ошибки (только при status="error").
        log_file: Путь к JSONL-файлу. По умолчанию logs/jsonata_queries.jsonl.
        extra: Дополнительные поля для записи.
    """
    if log_file is None:
        log_file = DEFAULT_JSONATA_LOG_FILE

    entry: dict[str, Any] = {
        "timestamp": datetime.now(tz=UTC).isoformat(),
        "tool": tool,
        "query": query,
        "purpose": purpose,
        "expected_data": expected_data,
        "status": status,
    }
    if user_request:
        entry["user_request"] = user_request
    if current_plan_step:
        entry["current_plan_step"] = current_plan_step
    if error is not None:
        entry["error"] = error
    if extra:
        entry.update(extra)

    try:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        with log_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass  # Не прерываем работу сервера из-за ошибки логирования
