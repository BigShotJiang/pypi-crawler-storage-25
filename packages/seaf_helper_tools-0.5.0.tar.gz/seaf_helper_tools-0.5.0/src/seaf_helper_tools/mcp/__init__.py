"""MCP сервер для работы с JSONata API Seafile."""
