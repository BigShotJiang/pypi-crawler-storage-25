"""MCP сервер для вызова JSONata API Seafile.

Запуск через CLI:
    seaf-helper-tools mcp-server --api-host seafile.example.com

Или напрямую:
    python -m seaf_helper_tools.mcp.server --api-host seafile.example.com
"""

import json
import logging
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import typer
from mcp.server.fastmcp import Context, FastMCP
from mcp.types import ToolAnnotations
from rich.console import Console
from ruamel.yaml import YAML

from seaf_helper_tools.mcp.api import (
    call_secured_api as api_call_secured_api,
)
from seaf_helper_tools.mcp.api import (
    describe_jsonata_result as api_describe_jsonata_result,
)
from seaf_helper_tools.mcp.api import (
    execute_jsonata_query as api_execute_jsonata_query,
)
from seaf_helper_tools.mcp.api import (
    execute_jsonata_raw as api_execute_jsonata_raw,
)
from seaf_helper_tools.mcp.api import (
    inspect_entities_batch as api_inspect_entities_batch,
)
from seaf_helper_tools.mcp.api import (
    set_max_jsonata_response_chars as api_set_max_jsonata_response_chars,
)
from seaf_helper_tools.mcp.link_graph import find_type_routes as lg_find_type_routes

console = Console(stderr=True)
logger = logging.getLogger("seaf_helper_tools.mcp.server")


def _is_interactive() -> bool:
    """True если сервер запущен в интерактивном терминале, не в stdio MCP режиме."""
    return sys.stdout.isatty()


def _silence_logging_for_stdio() -> None:
    """Убрать все logging-хэндлеры в stdio-режиме."""
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(logging.NullHandler())


# Глобальная конфигурация сервера
_api_host: str | None = None
_api_cert_path: str | None = None
_api_cert_password: str | None = None
_link_graph_path: Path | None = None
_extra_catalog_path: Path | None = None
_workspace_path: Path = Path.cwd()

# Кэш каталога сущностей для search_entity_ids
_entity_catalog: dict[str, dict[str, str]] | None = None
_entity_catalog_built_at: datetime | None = None
_ENTITY_CATALOG_TTL = timedelta(minutes=30)

_CATALOG_QUERY = (
    "$keys($).({$:$lookup($$.'entities',$)"
    '.({"title":$.title,"description":$.description})})'
    "[$.*.title]~>$merge()"
)

# Путь к встроенному cookbook JSONata-запросов
_COOKBOOK_PATH = Path(__file__).parent / "jsonata_query_cookbook.json"

# Поддиректории для поиска portal YAML-файлов
_PORTAL_SUBDIRS = [
    "dependencies/assess-portal",
    "dependencies/kadzo",
    "dependencies/seafera-portal",
]

_yaml_parser = YAML()
_yaml_parser.preserve_quotes = True


@asynccontextmanager
async def _server_lifespan(server: FastMCP) -> AsyncIterator[dict[str, Any]]:
    """Управление жизненным циклом сервера."""
    if _is_interactive():
        console.print("[bold green]MCP сервер запущен[/bold green]")
        if _api_host:
            console.print(f"  SEAF API хост: {_api_host}")
    try:
        yield {}
    finally:
        if _is_interactive():
            console.print("[bold yellow]MCP сервер остановлен[/bold yellow]")


mcp = FastMCP("seaf-helper-mcp", lifespan=_server_lifespan)


def _require_api_host() -> str:
    """Проверить, что API хост настроен, и вернуть его."""
    if not _api_host:
        raise ValueError("SEAF API не настроен: укажите --api-host при запуске")
    return _api_host


@mcp.tool()
async def call_api_endpoint(
    endpoint: str,
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Вызов SEAF API с использованием клиентского сертификата.

    Выполняет GET запрос к указанному endpoint. Хост и сертификат
    задаются при запуске сервера через --api-host и --api-cert-path.

    Args:
        endpoint: Относительный путь API endpoint (например, /api/v2/repos/).
    """
    host = _require_api_host()
    return await api_call_secured_api(
        host, _api_cert_path, _api_cert_password, endpoint, ctx
    )


_READONLY = ToolAnnotations(readOnlyHint=True, destructiveHint=False)


@mcp.tool(annotations=_READONLY)
async def run_jsonata_query(
    query: str,
    purpose: str,
    expected_data: str,
    user_request: str,
    current_plan_step: str,
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Query the SEAF architecture knowledge base using JSONata expressions.

    Use this tool whenever you need to:
    - Find components matching criteria (type, status, owner, tag, technology stack)
    - Aggregate architecture data (count systems per domain, list APIs by protocol)
    - Resolve relationships (which systems use a given technology, which apps belong
      to a business capability)
    - Answer "what exists in the architecture" questions based on real registered data

    Before calling:
    - Run inspect_entity_schema to learn exact field names for any type you will query.
    - If joining data across two types, run find_entity_relation_paths first to find connecting fields.

    Args:
        query: JSONata expression to execute (e.g. "$.'technologies'[vendor='Oracle']").
        purpose: Why this query is needed — which architectural question it answers.
            Write in Russian, 1–2 sentences.
        expected_data: What data this query should return and how it will be used.
            Write in Russian, 1–2 sentences.
        user_request: The original user request verbatim — what the user asked to do.
            Write in Russian, copy the user's words as closely as possible.
        current_plan_step: The current step in the agent's plan being executed.
            Write in Russian, 1 sentence. Filling these fields forces structured thinking
            before the query executes — describe what you expect, not what you've seen.
    """
    host = _require_api_host()
    return await api_execute_jsonata_query(
        host,
        _api_cert_path,
        _api_cert_password,
        query,
        purpose,
        expected_data,
        user_request,
        current_plan_step,
        ctx,
    )


@mcp.tool(annotations=_READONLY)
async def inspect_entity_schema(
    type_ids: list[str],
    ctx: Context,  # type: ignore[type-arg]
    limit: int = 3,
) -> str:
    """Call this BEFORE writing any query — returns schema AND sample records for each type.

    Eliminates "field not found" errors: you see exact field names, nesting, and real
    values before writing filters or transformations.

    When to call:
    - Before run_jsonata_query: to learn exact field names, types, and nesting structure.
    - Before filtering: to discover what values a field takes (status, type, owner, etc.).
    - When joining types: inspect all involved types in a single call.

    Prefer this over describe_query_result when you don't have a draft query yet and
    just need to know what fields a type has.

    Use field names from schema directly in your expression. If the response lists
    enum_values for a field — use those exact values in filter conditions.

    Args:
        type_ids: List of SEAF type identifiers.
                  Examples: ["technologies"], ["seaf.company.ai.agents", "technologies"].
        limit: Number of sample records per type (1-10, default 3).
    """
    host = _require_api_host()
    return await api_inspect_entities_batch(
        host, _api_cert_path, _api_cert_password, type_ids, limit, ctx
    )


@mcp.tool(annotations=_READONLY)
async def describe_query_result(
    query: str,
    query_goal: str,
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Use this instead of guessing: start with a simple query, inspect what it returns,
    then progressively add filters and transformations.

    Writing a complex query in one shot almost always produces errors with unclear causes.
    Pattern: simple → describe → refine → describe → jsonata_query when confident.

    Prefer this over inspect_entities when you already have a draft query and want to
    understand what it returns, not just what fields the type has.

    Response tells you field types, coverage, and — for low-cardinality fields — all
    distinct values. Use those values directly in filter conditions: $[status = "active"].

    Args:
        query: JSONata expression to analyze (e.g. "$.'technologies'").
        query_goal: What you are trying to find with this query. Write in Russian, 1–2 sentences.
    """
    host = _require_api_host()
    return await api_describe_jsonata_result(
        host, _api_cert_path, _api_cert_password, query, ctx, query_goal
    )


@mcp.tool(annotations=_READONLY)
async def find_entity_relation_paths(
    start_type_id: str,
    end_type_id: str,
    ctx: Context,  # type: ignore[type-arg]
    intermediate_type_ids: list[str] | None = None,
) -> str:
    """Find connection paths between two SEAF types — use this to build JOIN queries.

    Call this when you need to relate data across two types (e.g. systems → teams,
    applications → technologies) and don't know which fields connect them.

    Returns field-level JOIN paths with intermediate types and field names. Use the
    returned paths directly when writing your jsonata_query expression.

    Args:
        start_type_id: Starting type ID (e.g. 'kadzo.v2023.systems').
        end_type_id: Target type ID (e.g. 'kadzo.v2023.channels').
        intermediate_type_ids: Optional — constrain to paths through specific types.
    """
    if _link_graph_path is None:
        raise ValueError(
            "Граф связей не настроен. Укажите --link-graph-path при запуске сервера."
        )
    return lg_find_type_routes(
        graph_path=_link_graph_path,
        start_type_id=start_type_id,
        end_type_id=end_type_id,
        intermediate_type_ids=intermediate_type_ids,
    )


async def _build_entity_catalog(ctx: Context) -> dict[str, dict[str, str]]:  # type: ignore[type-arg]
    """Построить каталог сущностей через JSONata-запрос, смёрджить с extra_catalog."""
    global _entity_catalog, _entity_catalog_built_at

    host = _require_api_host()
    raw = await api_execute_jsonata_raw(host, _api_cert_path, _api_cert_password, _CATALOG_QUERY)

    try:
        catalog: dict[str, dict[str, str]] = json.loads(raw)
    except json.JSONDecodeError:
        catalog = {}

    if _extra_catalog_path and _extra_catalog_path.exists():
        try:
            extra: dict[str, dict[str, str]] = json.loads(
                _extra_catalog_path.read_text(encoding="utf-8")
            )
            catalog.update(extra)
        except Exception:  # noqa: BLE001
            pass

    _entity_catalog = catalog
    _entity_catalog_built_at = datetime.now()
    return catalog


@mcp.tool(annotations=_READONLY)
async def search_entity_ids(
    keywords: list[str],
    ctx: Context,  # type: ignore[type-arg]
) -> str:
    """Call this first when you don't know the entity ID.

    Accepts multiple search terms (Russian and/or English) — returns all entities
    matching any of them, ranked by number of matches.

    Searches across entity ID, Russian title, and description simultaneously.
    Results are cached for 30 minutes after the first call.

    Pass the found IDs to inspect_entity_schema to see their schema and sample data.

    Args:
        keywords: List of search terms — parts of entity ID, Russian titles, or
                  descriptions. Use multiple variants to improve recall.
                  Examples: ["оценка", "assessment"], ["стандарт", "требование", "dka-dzo"].
    """
    global _entity_catalog, _entity_catalog_built_at

    now = datetime.now()
    if (
        _entity_catalog is None
        or _entity_catalog_built_at is None
        or (now - _entity_catalog_built_at) > _ENTITY_CATALOG_TTL
    ):
        await ctx.info("Построение каталога сущностей...")
        catalog = await _build_entity_catalog(ctx)
    else:
        catalog = _entity_catalog

    kl = [kw.lower() for kw in keywords]
    matches: list[tuple[str, dict[str, str], int]] = []

    for entity_id, meta in catalog.items():
        title = meta.get("title", "")
        description = meta.get("description", "")
        search_text = f"{entity_id} {title} {description}".lower()
        count = sum(1 for k in kl if k in search_text)
        if count > 0:
            matches.append((entity_id, meta, count))

    matches.sort(key=lambda x: x[2], reverse=True)

    if not matches:
        return (
            f"Ничего не найдено по запросу {keywords!r}.\n"
            "Попробуйте другие термины или части идентификатора."
        )

    lines = [f"Найдено {len(matches)} сущностей по запросу {keywords!r}:\n"]
    for entity_id, meta, count in matches:
        title = meta.get("title", "")
        description = meta.get("description", "")
        lines.append(f"• {entity_id} — {title}  [совпадений: {count}]")
        if description:
            lines.append(f"  {description}")
        lines.append("")
    return "\n".join(lines)


def _extract_jsonata_expressions(
    node: Any, parent_name: str = ""
) -> list[tuple[str, str]]:
    """Рекурсивно извлечь JSONata-выражения из YAML-дерева.

    Returns list of (expression, parent_name).
    """
    results: list[tuple[str, str]] = []
    if isinstance(node, dict):
        current_name = str(node.get("name") or node.get("id") or parent_name)
        for key, value in node.items():
            if key in ("source", "origin") and isinstance(value, str) and value.strip():
                results.append((value, current_name))
            else:
                results.extend(_extract_jsonata_expressions(value, current_name))
    elif isinstance(node, list):
        for item in node:
            results.extend(_extract_jsonata_expressions(item, parent_name))
    return results


def _make_snippet(text: str, keyword: str, context_lines: int = 15) -> str:
    """Создать сниппет ±context_lines строк вокруг первого вхождения keyword."""
    lines = text.splitlines()
    kl = keyword.lower()
    for i, line in enumerate(lines):
        if kl in line.lower():
            start = max(0, i - context_lines)
            end = min(len(lines), i + context_lines + 1)
            return "\n".join(lines[start:end])
    return "\n".join(lines[:context_lines])


def _search_portal_yaml(keywords: list[str], limit: int = 20) -> list[dict[str, Any]]:
    """Найти JSONata-выражения в portal YAML-файлах по ключевым словам."""
    kl = [kw.lower() for kw in keywords]
    candidates: list[dict[str, Any]] = []

    for subdir in _PORTAL_SUBDIRS:
        portal_dir = _workspace_path / subdir
        if not portal_dir.exists():
            continue
        for yaml_file in portal_dir.rglob("*.yaml"):
            try:
                text = yaml_file.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            if not any(k in text.lower() for k in kl):
                continue
            try:
                data = _yaml_parser.load(text)
            except Exception:  # noqa: BLE001
                continue
            if data is None:
                continue
            for expr, parent_name in _extract_jsonata_expressions(data):
                match_count = sum(
                    1 for k in kl if k in expr.lower() or k in parent_name.lower()
                )
                if match_count > 0:
                    focus_kw = next(
                        (kw for kw in keywords if kw.lower() in expr.lower()),
                        keywords[0],
                    )
                    snippet = _make_snippet(expr, focus_kw)
                    candidates.append({
                        "title": parent_name or yaml_file.stem,
                        "snippet": snippet,
                        "match_count": match_count,
                    })

    candidates.sort(key=lambda x: x["match_count"], reverse=True)
    return candidates[:limit]


def _search_cookbook_json(keywords: list[str]) -> list[dict[str, Any]]:
    """Найти JSONata-выражения в cookbook по ключевым словам."""
    if not _COOKBOOK_PATH.exists():
        return []
    try:
        items: list[dict[str, Any]] = json.loads(_COOKBOOK_PATH.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return []

    kl = [kw.lower() for kw in keywords]
    results: list[dict[str, Any]] = []

    for item in items:
        search_text = " ".join([
            item.get("question", ""),
            item.get("group", ""),
            " ".join(item.get("entities", [])),
            item.get("query", ""),
            item.get("notes", ""),
        ]).lower()
        match_count = sum(1 for k in kl if k in search_text)
        if match_count > 0:
            results.append({
                "title": f"{item.get('group', '')}: {item.get('question', '')}",
                "snippet": item.get("query", ""),
                "match_count": match_count,
            })

    results.sort(key=lambda x: x["match_count"], reverse=True)
    return results


@mcp.tool(annotations=_READONLY)
async def find_jsonata_examples(
    keywords: list[str],
    ctx: Context,  # type: ignore[type-arg]
    limit: int = 5,
) -> str:
    """Find real JSONata expression examples from portal YAML files and built-in cookbook.

    Call this before writing a new query to find working examples you can adapt.

    Searches expression content, surrounding context names (dataset name, entity name,
    presentation name), and the built-in query cookbook.

    Args:
        keywords: Names of entity types you are querying, field names, or JSONata function
                  names. Always include entity names from your current query — they are the
                  most useful keywords. Combine several terms for best recall.
                  Examples: ["kadzo.v2023.systems", "kadzo.v2023.integrations", "channel"],
                            ["sber.dka-dzo.assessment", "year_plan", "company_ref", "status"],
                            ["kadzo.v2023.goals", "kadzo.v2023.strategy", "$lookup"],
                            ["$filter", "arch_standards", "requirements"].
        limit: Max number of examples to return (default 5).
    """
    await ctx.info(f"Поиск JSONata-примеров по ключевым словам: {keywords!r}")

    portal_results = _search_portal_yaml(keywords, limit=limit * 2)
    cookbook_results = _search_cookbook_json(keywords)

    portal_found = bool(portal_results)
    all_results = portal_results + cookbook_results
    all_results.sort(key=lambda x: x["match_count"], reverse=True)
    all_results = all_results[:limit]

    portal_dirs_exist = any(
        (_workspace_path / subdir).exists() for subdir in _PORTAL_SUBDIRS
    )

    if not all_results:
        notes = []
        if not portal_dirs_exist:
            notes.append(
                f"Portal-директории не найдены в {_workspace_path}. "
                "Настройте --workspace-path для поиска в YAML файлах портала."
            )
        return (
            f"Ничего не найдено по запросу {keywords!r}.\n"
            + ("\n".join(notes) + "\n" if notes else "")
            + "Попробуйте другие ключевые слова."
        )

    lines: list[str] = [f"Найдено {len(all_results)} примеров по запросу {keywords!r}:\n"]
    for i, result in enumerate(all_results, 1):
        lines.append(f"### {i}. {result['title']}")
        lines.append("```jsonata")
        lines.append(result["snippet"])
        lines.append("```")
        lines.append("")

    if not portal_found and not portal_dirs_exist:
        lines.append(
            f"\n_Примечание: Portal-директории не найдены в {_workspace_path}. "
            "Результаты только из встроенного cookbook. "
            "Настройте --workspace-path для поиска в YAML файлах портала._"
        )

    return "\n".join(lines)


@mcp.resource("config://server")
def get_server_config() -> str:
    """Конфигурация сервера (read-only)."""
    api_configured = bool(_api_host)
    return (
        f"SEAF API host: {_api_host or 'не настроен'}\n"
        f"SEAF API cert: {_api_cert_path or 'не настроен'}\n"
        f"SEAF API ready: {api_configured}\n"
        f"Link graph: {_link_graph_path or 'не настроен'}"
    )


# ---------------------------------------------------------------------------
# CLI для запуска сервера
# ---------------------------------------------------------------------------

app = typer.Typer(
    help="MCP сервер для JSONata API Seafile", invoke_without_command=True
)


@app.callback(invoke_without_command=True)
def serve(
    api_host: str | None = typer.Option(
        None,
        "--api-host",
        help="Хост SEAF JSONata API (например, seafile.example.com). Env: SEAF_API_HOST",
    ),
    api_cert_path: str | None = typer.Option(
        None,
        "--api-cert-path",
        help="Путь к P12/PFX сертификату для SEAF API. Env: SEAF_API_CERT_PATH",
    ),
    api_cert_password: str | None = typer.Option(
        None,
        "--api-cert-password",
        help="Пароль сертификата. Env: SEAF_API_CERT_PASSWORD",
    ),
    link_graph_path: Path | None = typer.Option(
        None,
        "--link-graph-path",
        help="Путь к файлу графа связей типов (link_graph.json). Env: SEAF_LINK_GRAPH_PATH",
    ),
    extra_catalog_path: Path | None = typer.Option(
        None,
        "--extra-catalog-path",
        help="JSON-файл с дополнительными записями каталога сущностей. Env: MCP_EXTRA_CATALOG_PATH",
    ),
    workspace_path: Path | None = typer.Option(
        None,
        "--workspace-path",
        help="Рабочая директория для поиска portal YAML-файлов. Env: WORKSPACE_PATH",
    ),
    log_level: str = typer.Option(
        "INFO",
        "--log-level",
        help="Уровень логирования: DEBUG, INFO, WARNING, ERROR",
    ),
    max_jsonata_response_chars: int | None = typer.Option(
        None,
        "--max-jsonata-response-chars",
        help="Максимальный размер ответа JSONata в символах. По умолчанию: 50000. Env: SEAF_MAX_JSONATA_RESPONSE_CHARS",
    ),
) -> None:
    """Запуск MCP сервера.

    Примеры:
        seaf-helper-tools mcp-server --api-host seafile.example.com
        seaf-helper-tools mcp-server --api-host seafile.example.com --api-cert-path /certs/u.p12
        seaf-helper-tools mcp-server --api-host seafile.example.com --link-graph-path graph.json
    """
    global _api_host, _api_cert_path, _api_cert_password, _link_graph_path, _extra_catalog_path, _workspace_path

    # В stdio режиме глушим stderr
    if not _is_interactive():
        try:
            sys.stderr = open(os.devnull, "w", encoding="utf-8")  # noqa: SIM115
        except Exception:
            pass

    # Настройка логирования
    log_level_value = getattr(logging, log_level.upper(), logging.INFO)
    if _is_interactive():
        logging.basicConfig(level=log_level_value)
    else:
        _silence_logging_for_stdio()

    # Применяем env-var fallback с предупреждениями при незаданных параметрах
    if api_host is None:
        api_host = os.getenv("SEAF_API_HOST")
        if api_host is None:
            logger.warning("Параметр --api-host / SEAF_API_HOST не задан")

    if api_cert_path is None:
        api_cert_path = os.getenv("SEAF_API_CERT_PATH")
        if api_cert_path is None:
            logger.warning("Параметр --api-cert-path / SEAF_API_CERT_PATH не задан")

    if api_cert_password is None:
        api_cert_password = os.getenv("SEAF_API_CERT_PASSWORD")
        if api_cert_password is None:
            logger.warning("Параметр --api-cert-password / SEAF_API_CERT_PASSWORD не задан")

    if link_graph_path is None:
        _lg_str = os.getenv("SEAF_LINK_GRAPH_PATH")
        link_graph_path = Path(_lg_str) if _lg_str else None
        if link_graph_path is None:
            logger.warning("Параметр --link-graph-path / SEAF_LINK_GRAPH_PATH не задан")

    if max_jsonata_response_chars is None:
        _env_chars = os.getenv("SEAF_MAX_JSONATA_RESPONSE_CHARS")
        if _env_chars is not None:
            try:
                max_jsonata_response_chars = int(_env_chars)
            except ValueError:
                logger.warning("Некорректное значение SEAF_MAX_JSONATA_RESPONSE_CHARS: %s", _env_chars)

    if max_jsonata_response_chars is not None:
        api_set_max_jsonata_response_chars(max_jsonata_response_chars)

    if extra_catalog_path is None:
        _ec = os.getenv("MCP_EXTRA_CATALOG_PATH")
        extra_catalog_path = Path(_ec) if _ec else None

    if workspace_path is None:
        _ws = os.getenv("WORKSPACE_PATH")
        workspace_path = Path(_ws) if _ws else Path.cwd()

    _api_host = api_host
    _api_cert_path = api_cert_path
    _api_cert_password = api_cert_password
    _link_graph_path = link_graph_path
    _extra_catalog_path = extra_catalog_path
    _workspace_path = workspace_path

    if _is_interactive():
        console.print("[bold blue]Конфигурация сервера:[/bold blue]")
        console.print(f"  Уровень логирования: {log_level}")
        if api_host:
            console.print(f"  SEAF API хост: {api_host}")
            console.print(f"  SEAF API сертификат: {api_cert_path or 'не указан'}")
        if link_graph_path:
            console.print(f"  Граф связей: {link_graph_path}")
        console.print(f"  Лимит ответа JSONata: {max_jsonata_response_chars or 50_000} символов")
        console.print()
        console.print("[bold green]Запуск сервера...[/bold green]")

    mcp.run()


def main() -> None:
    """Точка входа для python -m seaf_helper_tools.mcp.server."""
    app()


if __name__ == "__main__":
    main()
