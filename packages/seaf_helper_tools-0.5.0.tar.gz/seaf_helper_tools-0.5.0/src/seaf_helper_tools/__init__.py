"""seaf-helper-tools — CLI tools for working with SEAF assessment data."""

__version__ = "0.1.0"
