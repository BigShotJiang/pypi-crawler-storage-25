"""Утилита для загрузки НСИ из локальных YAML-файлов и удалённого JSONata API.

Оба источника производят одинаковую структуру dict и сливаются в единый NSI-словарь.

Пример использования:
    >>> from seaf_helper_tools.utils.nsi import build_nsi
    >>> nsi = build_nsi(extra_data=[Path("deps/")], jsonata_client=client,
    ...                 remote_keys=["companies", "seaf.change.requirements.dzo"])
    >>> companies = nsi.get("companies", {})
"""

import json
import logging
from pathlib import Path
from typing import Any

from seaf_helper_tools.utils.yaml_utils import index_yaml_paths, merge_dicts

logger = logging.getLogger("seaf_helper_tools.nsi")


def _jsonata_expr(key: str) -> str:
    """Построить JSONata-выражение для получения корневого ключа.

    Ключи с точками квотируются backtick-ами: ``$.`key.with.dots` ``.

    Args:
        key: Корневой ключ НСИ словаря.

    Returns:
        str: JSONata-выражение.
    """
    if "." in key:
        return f"$.`{key}`"
    return f"$.{key}"


def fetch_nsi_from_api(
    jsonata_client: Any,
    root_keys: list[str],
) -> dict[str, Any]:
    """Получить НСИ-данные из удалённого API через JSONata-запросы.

    Для каждого ключа выполняется запрос ``$.`key` `` (backtick-квотирование
    для ключей с точками). Результат собирается в dict ``{key: data}``.

    Args:
        jsonata_client: Экземпляр SeafJsonataCall.
        root_keys: Список корневых ключей для запроса.

    Returns:
        dict: НСИ данные с root_keys как ключами верхнего уровня.
    """
    result: dict[str, Any] = {}
    for key in root_keys:
        expr = _jsonata_expr(key)
        try:
            raw = jsonata_client.eval_jsonata(expr)
            data = json.loads(raw)
            if data is not None:
                result[key] = data
                logger.debug("НСИ ключ '%s' загружен из API (%d байт)", key, len(raw))
            else:
                logger.debug("НСИ ключ '%s': API вернул null, пропускаем", key)
        except Exception as e:
            logger.warning("Не удалось загрузить НСИ ключ '%s' из API: %s", key, e)
    return result


def build_nsi(
    extra_data: list[Path],
    jsonata_client: Any | None = None,
    remote_keys: list[str] | None = None,
) -> dict[str, Any]:
    """Собрать единый НСИ-словарь из локальных YAML-файлов и/или удалённого API.

    Оба источника производят одинаковую структуру dict. Удалённые данные
    сливаются поверх локальных (remote дополняет local).

    Args:
        extra_data: Локальные YAML-файлы или директории.
        jsonata_client: JSONata-клиент (если None — только локальные файлы).
        remote_keys: Ключи для запроса из API. Если None или jsonata_client
            не задан — удалённый источник не используется.

    Returns:
        dict: Объединённый НСИ-словарь.

    Example:
        >>> nsi = build_nsi(
        ...     extra_data=[Path("deps/portal")],
        ...     jsonata_client=jsonata,
        ...     remote_keys=["companies", "seaf.change.requirements.dzo"],
        ... )
    """
    result: dict[str, Any] = {}

    if extra_data:
        local = index_yaml_paths(extra_data)
        merge_dicts(result, local)
        logger.debug("НСИ: загружено из локальных файлов, ключей: %d", len(result))

    if jsonata_client is not None and remote_keys:
        remote = fetch_nsi_from_api(jsonata_client, remote_keys)
        if remote:
            merge_dicts(result, remote)
            logger.debug("НСИ: загружено из API, ключей: %d", len(remote))

    return result
