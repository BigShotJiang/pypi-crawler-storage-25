"""Utilities for loading and indexing YAML files with ruamel.yaml."""

from collections.abc import Sequence
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML


def _make_yaml() -> YAML:
    yaml = YAML()
    yaml.preserve_quotes = True
    return yaml


def _make_rt_yaml() -> YAML:
    """Round-trip YAML instance: preserves comments, outputs None as blank."""
    yaml = YAML(typ="rt")
    yaml.preserve_quotes = True
    yaml.default_flow_style = False
    yaml.allow_unicode = True
    yaml.width = 100
    yaml.indent(mapping=2, sequence=4, offset=2)
    yaml.representer.add_representer(
        type(None),
        lambda dumper, value: dumper.represent_scalar("tag:yaml.org,2002:null", ""),
    )
    return yaml


def read_yaml_rt(path: Path | str) -> Any:
    """Load YAML file preserving comments for round-trip editing."""
    yaml = _make_rt_yaml()
    with open(path, encoding="utf-8") as f:
        result = yaml.load(f)
    from ruamel.yaml.comments import CommentedMap

    return result if result is not None else CommentedMap()


def write_yaml(path: Path | str, data: Any) -> None:
    """Write data to YAML file preserving CommentedMap structure and comments."""
    yaml = _make_rt_yaml()
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(data, f)


def load_yaml(path: Path | str) -> dict[str, Any]:
    """Load a single YAML file into a plain dict."""
    yaml = _make_yaml()
    with open(path, encoding="utf-8") as f:
        return yaml.load(f) or {}


def _merge(base: dict[str, Any], extra: dict[str, Any]) -> dict[str, Any]:
    for key, value in extra.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _merge(base[key], value)
        else:
            base[key] = value
    return base


def merge_dicts(base: dict[str, Any], extra: dict[str, Any]) -> dict[str, Any]:
    """Deep-merge extra into base (in-place). Returns base."""
    return _merge(base, extra)


def index_yaml_paths(paths: Sequence[Path | str]) -> dict[str, Any]:
    """Merge YAML data from a list of files and/or directories into one dict."""
    result: dict[str, Any] = {}
    for path in paths:
        p = Path(path)
        files = sorted(p.rglob("*.yaml")) if p.is_dir() else [p]
        for f in files:
            try:
                _merge(result, load_yaml(f))
            except Exception:
                import logging

                logging.warning("Не удалось загрузить %s", f)
    return result
