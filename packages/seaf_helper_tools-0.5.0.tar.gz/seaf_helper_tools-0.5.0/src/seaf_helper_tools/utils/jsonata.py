"""Утилита для выполнения JSONata запросов к хранилищу Seafile.

JSONata — язык запросов для трансформации и агрегации JSON данных.
Этот модуль предоставляет интерфейс для выполнения JSONata выражений
через защищённое API с клиентским сертификатом.

Пример использования:
    >>> from pathlib import Path
    >>> from seaf_helper_tools.utils.secured_api import SecuredApiCall
    >>> from seaf_helper_tools.utils.jsonata import SeafJsonataCall
    >>> api = SecuredApiCall(
    ...     cert_file_path=Path("/path/to/cert.p12"),
    ...     cert_password="secret",
    ...     host_name="seafile.example.com",
    ... )
    >>> jsonata = SeafJsonataCall(api)
    >>> result = jsonata.eval_jsonata("library.files.*.name")
"""

import logging
import re
from urllib.parse import quote

import requests

from seaf_helper_tools.utils.secured_api import SecuredApiCall

logger = logging.getLogger("seaf_helper_tools.jsonata")

# Коды JSONata — постоянные ошибки парсера, типов и вычислений:
#   S0xxx — синтаксис/компиляция
#   T0xxx — ошибки типов
#   D1xxx — ошибки вычислений (D1001 деление на ноль и др.)
# Retry бессмысленен: запрос не изменится.
_JSONATA_ERROR_CODE_RE = re.compile(r"[A-Z]\d{3,}")


def _is_jsonata_permanent_error(response: requests.Response) -> bool:
    """Проверить, является ли 500-ответ постоянной ошибкой JSONata.

    Args:
        response: HTTP ответ от сервера.

    Returns:
        bool: True если ошибка детерминирована (retry бессмысленен).
    """
    return "error" in response.text and bool(
        _JSONATA_ERROR_CODE_RE.search(response.text)
    )


class SeafJsonataCall:
    """Клиент для выполнения JSONata запросов к хранилищу Seafile.

    Использует SecuredApiCall для соединения через клиентский сертификат.

    Attributes:
        _secured_api_call: Клиент защищённого API.

    Example:
        >>> api = SecuredApiCall(...)
        >>> jsonata = SeafJsonataCall(api)
        >>> data = jsonata.eval_jsonata("library.name")
    """

    def __init__(self, secured_api_call: SecuredApiCall) -> None:
        """Инициализация клиента JSONata.

        Args:
            secured_api_call: Клиент защищённого API для соединения.
        """
        self._secured_api_call = secured_api_call

    def eval_jsonata(self, query: str) -> str:
        """Выполнение JSONata запроса к серверу.

        Args:
            query: JSONata выражение для выполнения.

        Returns:
            str: Результат выполнения запроса в виде строки (JSON).

        Raises:
            requests.HTTPError: Если сервер вернул ошибку.

        Example:
            >>> jsonata.eval_jsonata("library.files.*.name")
            '["file1.yaml", "file2.yaml"]'
        """
        logger.debug("JSONata query:\n%s", query)
        encoded_query = quote(query, safe="()*'")
        endpoint = f"/core/storage/jsonata/({encoded_query})?params=null&subject=null"
        response = self._secured_api_call.get(
            endpoint, no_retry_if=_is_jsonata_permanent_error
        )
        response.raise_for_status()
        return str(response.text)
