"""Utilities for working with openpyxl worksheets."""

import logging
import re
from collections.abc import Iterable, Sequence
from typing import Any


def find_col_idx(
    head_row: Iterable[Any],
    titles: Sequence[str],
    fail_fast: bool = True,
    find_last: bool = False,
    verbose: bool = True,
) -> int | None:
    """Return 0-based column index of the first cell in head_row matching any of titles."""
    head_row = list(head_row)
    clean_titles = [re.sub(r"\s+", "", t) for t in titles]
    matches = [
        cell.column
        for cell in head_row
        if cell.value is not None
        and re.sub(r"\s+", "", str(cell.value)) in clean_titles
    ]
    if not matches:
        if fail_fast:
            raise ValueError(f"Колонка {titles} не найдена")
        if verbose:
            logging.warning(
                "Не найдена ячейка с %s в строке %s", titles, head_row[0].row
            )
        return None
    return int(matches[-1] if find_last else matches[0]) - 1


def find_col_idx_multi_header(
    head_rows: Iterable[Iterable[Any]],
    titles: Sequence[str],
    fail_fast: bool = True,
    find_last: bool = False,
    verbose: bool = False,
) -> int | None:
    """Search multiple header rows; return first match."""
    for row in head_rows:
        result = find_col_idx(
            row, titles, find_last=find_last, fail_fast=False, verbose=verbose
        )
        if result is not None:
            return result
    if fail_fast:
        raise ValueError(f"Колонка {titles} не найдена")
    return None


def find_row_idx(
    head_col: Iterable[Any],
    titles: Sequence[str],
    fail_fast: bool = True,
    verbose: bool = True,
) -> int | None:
    """Return 0-based row index of the first cell in head_col matching any of titles."""
    head_col = list(head_col)
    clean_titles = [re.sub(r"\s+", "", t) for t in titles]
    for cell in head_col:
        if (
            cell.value is not None
            and re.sub(r"\s+", "", str(cell.value)) in clean_titles
        ):
            return int(cell.row) - 1
    if fail_fast:
        raise ValueError(f"Не найдена ячейка с заголовком: {titles}")
    if verbose:
        logging.warning(
            "Не найдена ячейка с %s в колонке %s", titles, head_col[0].column
        )
    return None
