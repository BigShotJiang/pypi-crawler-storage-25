"""Утилита для вызова защищённых API с использованием клиентского SSL-сертификата.

Предоставляет класс SecuredApiCall для выполнения HTTP GET запросов
к серверам, требующим аутентификации через P12/PFX сертификат.

Пример использования:
    >>> from pathlib import Path
    >>> from seaf_helper_tools.utils.secured_api import SecuredApiCall
    >>> api = SecuredApiCall(
    ...     cert_file_path=Path("/path/to/cert.p12"),
    ...     cert_password="secret",
    ...     host_name="api.example.com",
    ... )
    >>> response = api.get("/api/v1/data")
"""

import logging
import ssl
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

import requests
import urllib3
from requests.adapters import HTTPAdapter
from urllib3.exceptions import InsecureRequestWarning
from urllib3.util.ssl_ import create_urllib3_context

logger = logging.getLogger("seaf_helper_tools.secured_api")

DEFAULT_REQUEST_TIMEOUT = 30  # секунды

# Задержки между повторными попытками в секундах.
# Суммарное время ожидания: 1+2+4 = 7с.
RETRY_DELAYS = (1, 2, 4)


class SSLContextAdapter(HTTPAdapter):
    """Адаптер HTTP с поддержкой клиентского SSL-сертификата.

    Attributes:
        ssl_context: SSL контекст с загруженным сертификатом.
        verify_ssl: Флаг проверки SSL сертификата сервера.
    """

    def __init__(
        self,
        ssl_context: ssl.SSLContext,
        verify_ssl: bool = True,
        **kwargs: Any,
    ) -> None:
        self.ssl_context = ssl_context
        self.verify_ssl = verify_ssl
        super().__init__(**kwargs)

    def init_poolmanager(self, *args: Any, **kwargs: Any) -> None:
        """Инициализация пула соединений с SSL контекстом."""
        kwargs["ssl_context"] = self.ssl_context
        super().init_poolmanager(*args, **kwargs)  # type: ignore[no-untyped-call]

    def cert_verify(
        self,
        conn: HTTPAdapter,
        url: str,
        verify: bool,
        cert: str | tuple[str, str] | None,
    ) -> None:
        """Переопределение проверки сертификата в зависимости от флага."""
        super().cert_verify(conn, url, self.verify_ssl and verify, cert)  # type: ignore[no-untyped-call]


class SecuredApiCall:
    """Клиент для вызова API с опциональным клиентским сертификатом.

    Если cert_file_path не указан — работает как простой HTTP-клиент
    без SSL-логики клиентского сертификата.

    Поддерживает автоматический retry при 5xx ошибках и сетевых проблемах.
    Ошибки 4xx не вызывают повтора — это ошибки клиента.

    Attributes:
        host_name: Имя хоста сервера.
        cert_file_path: Путь к файлу сертификата (None = без сертификата).

    Example:
        >>> # С сертификатом
        >>> api = SecuredApiCall(
        ...     host_name="api.example.com",
        ...     cert_file_path=Path("/path/to/cert.p12"),
        ...     cert_password="secret",
        ... )
        >>> # Без сертификата
        >>> api = SecuredApiCall(host_name="api.example.com")
        >>> response = api.get("/api/endpoint")
        >>> response.raise_for_status()
    """

    def __init__(
        self,
        host_name: str,
        cert_file_path: Path | None = None,
        cert_password: str | None = None,
        verify_ssl: bool = False,
        timeout: int = DEFAULT_REQUEST_TIMEOUT,
    ) -> None:
        """Инициализация клиента защищённого API.

        Args:
            host_name: Имя хоста целевого сервера.
            cert_file_path: Путь к файлу сертификата (P12/PFX). None — без сертификата.
            cert_password: Пароль для расшифровки сертификата (только при наличии cert).
            verify_ssl: Проверять ли SSL сертификат сервера.
            timeout: Таймаут запроса в секундах (по умолчанию 30).
        """
        self.host_name = host_name
        self.cert_file_path = cert_file_path
        self._verify_ssl = verify_ssl
        self._timeout = timeout
        self._use_cert = cert_file_path is not None

        self._session = requests.Session()

        if self._use_cert:
            if cert_file_path is not None and not cert_file_path.exists():
                raise FileNotFoundError(f"Файл сертификата не найден: {cert_file_path}")

            if not verify_ssl:
                urllib3.disable_warnings(InsecureRequestWarning)

            self._ssl_context = create_urllib3_context()
            self._ssl_context.load_cert_chain(
                certfile=str(cert_file_path),
                password=cert_password,
            )

            if not verify_ssl:
                self._ssl_context.check_hostname = False
                self._ssl_context.verify_mode = ssl.CERT_NONE

            self._session.mount(
                "https://",
                SSLContextAdapter(self._ssl_context, verify_ssl=verify_ssl),
            )

    def get(
        self,
        url_endpoint: str,
        no_retry_if: Callable[[requests.Response], bool] | None = None,
    ) -> requests.Response:
        """Выполнение GET запроса к защищённому API с автоматическими повторами.

        При сетевых ошибках или ответах 5xx выполняет повторные попытки
        с нарастающей задержкой (RETRY_DELAYS). Ошибки 4xx не повторяются.

        Args:
            url_endpoint: Относительный путь endpoint (без хоста).
            no_retry_if: Опциональный предикат; если возвращает True для 5xx
                ответа — retry не выполняется (постоянная ошибка).

        Returns:
            requests.Response: Ответ от сервера.

        Raises:
            requests.ConnectionError: Если все попытки завершились ошибкой.
            requests.Timeout: Если все попытки завершились таймаутом.
        """
        max_attempts = len(RETRY_DELAYS) + 1
        last_response: requests.Response | None = None

        for attempt in range(max_attempts):
            if attempt > 0:
                delay = RETRY_DELAYS[attempt - 1]
                logger.warning(
                    "Повтор запроса через %ds (попытка %d/%d): %s",
                    delay,
                    attempt + 1,
                    max_attempts,
                    url_endpoint,
                )
                time.sleep(delay)

            try:
                if self._use_cert and "PLATFORM_SESSION_2" not in self._session.cookies:
                    self._session.get(
                        f"https://{self.host_name}/",
                        allow_redirects=True,
                        verify=self._verify_ssl,
                        timeout=self._timeout,
                    )

                response = self._session.get(
                    f"https://{self.host_name}{url_endpoint}",
                    allow_redirects=True,
                    verify=self._verify_ssl,
                    timeout=self._timeout,
                )

                if response.status_code < 500:
                    return response

                if no_retry_if is not None and no_retry_if(response):
                    logger.warning(
                        "Получен %d, retry пропущен по предикату: %s",
                        response.status_code,
                        url_endpoint,
                    )
                    return response

                last_response = response
                if attempt < max_attempts - 1:
                    logger.warning(
                        "Сервер вернул %d, повтор запланирован (попытка %d/%d)",
                        response.status_code,
                        attempt + 1,
                        max_attempts,
                    )
                else:
                    logger.error(
                        "Все %d попытки исчерпаны, последний статус: %d",
                        max_attempts,
                        response.status_code,
                    )

            except (requests.ConnectionError, requests.Timeout) as e:
                if attempt < max_attempts - 1:
                    logger.warning(
                        "Ошибка соединения: %s, повтор запланирован (попытка %d/%d)",
                        e,
                        attempt + 1,
                        max_attempts,
                    )
                else:
                    logger.error(
                        "Все %d попытки исчерпаны, последняя ошибка: %s",
                        max_attempts,
                        e,
                    )
                    raise

        return last_response  # type: ignore[return-value]
