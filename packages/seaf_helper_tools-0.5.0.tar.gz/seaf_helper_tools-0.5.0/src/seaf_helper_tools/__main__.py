"""Entry point for `python -m seaf_helper_tools`."""

from seaf_helper_tools.cli import app

if __name__ == "__main__":
    app()
