"""Конфигурация приложения.

Параметры читаются из переменных окружения (или .env файла через --env-file).

Переменные окружения:
    SEAF_API_HOST         — хост API сервера
    SEAF_API_CERT_PATH    — путь к P12/PFX сертификату
    SEAF_API_CERT_PASSWORD — пароль сертификата
    SEAF_API_VERIFY_SSL   — проверять SSL сервера (true/false, по умолчанию false)
"""

import logging
import os
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger("seaf_helper_tools.config")

_ENV_CERT_PASSWORD_PRIMARY = "SEAF_API_CERT_PASSWORD"
_ENV_CERT_PASSWORD_COMPAT = "HELPER_API_CERT_PASSWORD"


class ConfigError(Exception):
    """Ошибка конфигурации."""

    pass


@dataclass
class ApiConfig:
    """Конфигурация доступа к API.

    Attributes:
        host: Хост API сервера.
        cert_path: Путь к файлу сертификата (P12/PFX).
        cert_password: Пароль сертификата (лучше через env SEAF_API_CERT_PASSWORD).
        verify_ssl: Проверять ли SSL сертификат сервера.
    """

    host: str
    cert_path: Path
    cert_password: str | None = None
    verify_ssl: bool = False

    def get_cert_password(self) -> str:
        """Получить пароль сертификата.

        Порядок: SEAF_API_CERT_PASSWORD > HELPER_API_CERT_PASSWORD > значение из конфига.

        Returns:
            str: Пароль сертификата.

        Raises:
            ConfigError: Если пароль не задан ни в одном из источников.
        """
        for env_name in (_ENV_CERT_PASSWORD_PRIMARY, _ENV_CERT_PASSWORD_COMPAT):
            val = os.getenv(env_name)
            if val:
                return val
        if self.cert_password:
            return self.cert_password
        raise ConfigError(
            f"Пароль сертификата не задан. Установите env {_ENV_CERT_PASSWORD_PRIMARY}."
        )


@dataclass
class AppConfig:
    """Конфигурация приложения.

    Attributes:
        api: Конфигурация API (опционально).
    """

    api: ApiConfig | None = None


def get_config() -> AppConfig:
    """Получить конфигурацию из переменных окружения.

    Читает SEAF_API_HOST и SEAF_API_CERT_PATH — если оба заданы,
    возвращает AppConfig с ApiConfig. Иначе — AppConfig без API.

    Returns:
        AppConfig: Конфигурация приложения.
    """
    host = os.getenv("SEAF_API_HOST")
    cert_path_str = os.getenv("SEAF_API_CERT_PATH")
    if not host or not cert_path_str:
        return AppConfig()
    verify_ssl = os.getenv("SEAF_API_VERIFY_SSL", "false").lower() == "true"
    api = ApiConfig(
        host=host,
        cert_path=Path(cert_path_str).expanduser(),
        verify_ssl=verify_ssl,
    )
    logger.debug("API конфиг загружен из env: host=%s", host)
    return AppConfig(api=api)
