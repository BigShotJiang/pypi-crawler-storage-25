# seaf-helper-tools

CLI-инструменты для работы с данными SEAF: конвертация анкет объектов оценки между форматами YAML и XLS, поддержка удалённых источников НСИ через JSONata API.

## Установка

```bash
pip install seaf-helper-tools
```

## Команды

| Команда | Описание |
|---------|----------|
| `survey-standards-yaml2xls` | Конвертировать YAML-анкету объекта оценки в XLS |
| `survey-standards-xls2yaml` | Конвертировать XLS-анкету обратно в YAML |

### Примеры

```bash
# Сгенерировать XLS из YAML
seaf-helper-tools survey-standards-yaml2xls input.yaml output.xlsx --template template.xlsx

# Конвертировать XLS обратно в YAML
seaf-helper-tools survey-standards-xls2yaml input.xlsx output.yaml

# С конфигурационным файлом (для подключения к API)
seaf-helper-tools --config config.yaml survey-standards-yaml2xls input.yaml output.xlsx
```

## Конфигурация

Для подключения к удалённому API NSI создайте `config.yaml` по образцу `config.example.yaml`:

```yaml
api:
  url: https://your-seaf-instance/api
  cert: /path/to/client.crt
  key: /path/to/client.key
```

## Разработка

```bash
git clone https://gitverse.ru/alex314/seaf_helper_tools
cd seaf-helper-tools
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

pytest -v
ruff check .
mypy src/
```

## Лицензия

GPL-3.0 — см. [LICENSE](LICENSE).
