"""Тесты для MCP-инструментов: search_entity_ids и find_jsonata_examples."""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import seaf_helper_tools.mcp.server as srv
from seaf_helper_tools.mcp.server import (
    _ENTITY_CATALOG_TTL,
    _search_cookbook_json,
    _search_portal_yaml,
    find_jsonata_examples,
    search_entity_ids,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_SAMPLE_CATALOG: dict[str, dict[str, str]] = {
    "sber.dka-dzo.assessment": {
        "title": "Ассессменты",
        "description": "Ассессмент на соответствие стандартам",
    },
    "sber.dka-dzo.assessment.year_plan": {
        "title": "Годовой план Оценок",
        "description": "Годовой предварительный план Оценок",
    },
    "kadzo.v2023.systems": {
        "title": "ИС и сервисы",
        "description": "Реестр информационных систем",
    },
}


@pytest.fixture(autouse=True)
def reset_catalog_cache():
    """Сбросить кэш каталога перед каждым тестом."""
    srv._entity_catalog = None
    srv._entity_catalog_built_at = None
    yield
    srv._entity_catalog = None
    srv._entity_catalog_built_at = None


@pytest.fixture
def mock_ctx():
    ctx = AsyncMock()
    ctx.info = AsyncMock()
    return ctx


@pytest.fixture
def populated_cache():
    """Установить каталог в кэш (свежий)."""
    srv._entity_catalog = dict(_SAMPLE_CATALOG)
    srv._entity_catalog_built_at = datetime.now()
    return srv._entity_catalog


# ---------------------------------------------------------------------------
# Tests: search_entity_ids — базовый поиск
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_by_entity_id_fragment(populated_cache, mock_ctx):
    result = await search_entity_ids(["dka-dzo"], mock_ctx)
    assert "sber.dka-dzo.assessment" in result
    assert "sber.dka-dzo.assessment.year_plan" in result
    assert "kadzo.v2023.systems" not in result


@pytest.mark.asyncio
async def test_search_by_title(populated_cache, mock_ctx):
    result = await search_entity_ids(["Ассессменты"], mock_ctx)
    assert "sber.dka-dzo.assessment" in result


@pytest.mark.asyncio
async def test_search_by_description(populated_cache, mock_ctx):
    result = await search_entity_ids(["предварительный план"], mock_ctx)
    assert "year_plan" in result


@pytest.mark.asyncio
async def test_search_or_logic(populated_cache, mock_ctx):
    """Совпадение по любому keyword включает сущность."""
    result = await search_entity_ids(["Ассессменты", "ИС и сервисы"], mock_ctx)
    assert "sber.dka-dzo.assessment" in result
    assert "kadzo.v2023.systems" in result


@pytest.mark.asyncio
async def test_search_ranking(populated_cache, mock_ctx):
    """Сущность с бо́льшим числом совпадений идёт первой."""
    # "assessment" есть и в entity_id и в description у sber.dka-dzo.assessment
    result = await search_entity_ids(["assessment", "Ассессмент"], mock_ctx)
    lines = result.splitlines()
    first_entity_line = next(l for l in lines if l.startswith("•"))
    assert "sber.dka-dzo.assessment" in first_entity_line


@pytest.mark.asyncio
async def test_search_empty_result(populated_cache, mock_ctx):
    result = await search_entity_ids(["nonexistent_xyz_12345"], mock_ctx)
    assert "Ничего не найдено" in result


# ---------------------------------------------------------------------------
# Tests: search_entity_ids — кэш и TTL
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cache_second_call_no_api_request(mock_ctx):
    """Второй вызов не строит каталог заново."""
    srv._entity_catalog = dict(_SAMPLE_CATALOG)
    srv._entity_catalog_built_at = datetime.now()

    with patch.object(srv, "_build_entity_catalog", new_callable=AsyncMock) as mock_build:
        await search_entity_ids(["assessment"], mock_ctx)
        mock_build.assert_not_called()


@pytest.mark.asyncio
async def test_ttl_expired_triggers_rebuild(mock_ctx):
    """Просроченный кэш вызывает пересборку каталога."""
    srv._entity_catalog = dict(_SAMPLE_CATALOG)
    srv._entity_catalog_built_at = datetime.now() - _ENTITY_CATALOG_TTL - timedelta(seconds=1)

    with patch.object(
        srv, "_build_entity_catalog", new_callable=AsyncMock, return_value=dict(_SAMPLE_CATALOG)
    ) as mock_build:
        await search_entity_ids(["assessment"], mock_ctx)
        mock_build.assert_called_once()


@pytest.mark.asyncio
async def test_extra_catalog_merged(tmp_path, mock_ctx):
    """Записи из extra_catalog_path видны в результатах."""
    extra = {
        "custom.local.entity": {
            "title": "Локальная сущность",
            "description": "Только в extra",
        }
    }
    extra_file = tmp_path / "extra.json"
    extra_file.write_text(json.dumps(extra), encoding="utf-8")

    srv._extra_catalog_path = extra_file

    with patch.object(
        srv, "api_execute_jsonata_raw", new_callable=AsyncMock, return_value=json.dumps(_SAMPLE_CATALOG)
    ):
        with patch.object(srv, "_require_api_host", return_value="host.example.com"):
            catalog = await srv._build_entity_catalog(mock_ctx)

    assert "custom.local.entity" in catalog
    srv._extra_catalog_path = None


# ---------------------------------------------------------------------------
# Tests: _search_cookbook_json
# ---------------------------------------------------------------------------


def test_search_cookbook_by_question_word(tmp_path):
    cookbook = [
        {
            "id": "g1_q1",
            "group": "Мониторинг",
            "question": "Список всех оценок",
            "entities": ["sber.dka-dzo.assessment"],
            "query": "$.'sber.dka-dzo.assessment'",
            "notes": "",
            "roles": [],
        }
    ]
    cb_file = tmp_path / "cookbook.json"
    cb_file.write_text(json.dumps(cookbook), encoding="utf-8")

    with patch.object(srv, "_COOKBOOK_PATH", cb_file):
        results = _search_cookbook_json(["оценок"])

    assert len(results) == 1
    assert "Мониторинг" in results[0]["title"]
    assert "assessment" in results[0]["snippet"]


def test_search_cookbook_by_query_fragment(tmp_path):
    cookbook = [
        {
            "id": "g1_q2",
            "group": "Группа",
            "question": "Запрос с lookup",
            "entities": [],
            "query": "$lookup($.'entities', $ref)",
            "notes": "",
            "roles": [],
        }
    ]
    cb_file = tmp_path / "cookbook.json"
    cb_file.write_text(json.dumps(cookbook), encoding="utf-8")

    with patch.object(srv, "_COOKBOOK_PATH", cb_file):
        results = _search_cookbook_json(["$lookup"])

    assert len(results) == 1
    assert "$lookup" in results[0]["snippet"]


def test_search_cookbook_empty_result(tmp_path):
    cookbook = [
        {
            "id": "g1_q1",
            "group": "Группа",
            "question": "Не то",
            "entities": [],
            "query": "$.something",
            "notes": "",
            "roles": [],
        }
    ]
    cb_file = tmp_path / "cookbook.json"
    cb_file.write_text(json.dumps(cookbook), encoding="utf-8")

    with patch.object(srv, "_COOKBOOK_PATH", cb_file):
        results = _search_cookbook_json(["nonexistent_xyz"])

    assert results == []


def test_search_cookbook_nonexistent_file(tmp_path):
    missing = tmp_path / "missing.json"
    with patch.object(srv, "_COOKBOOK_PATH", missing):
        results = _search_cookbook_json(["anything"])
    assert results == []


def test_search_cookbook_ranking(tmp_path):
    cookbook = [
        {
            "id": "q1",
            "group": "Группа",
            "question": "Оценка assessment",
            "entities": ["assessment"],
            "query": "$.assessment",
            "notes": "assessment notes",
            "roles": [],
        },
        {
            "id": "q2",
            "group": "Группа",
            "question": "Только один раз",
            "entities": [],
            "query": "$.assessment",
            "notes": "",
            "roles": [],
        },
    ]
    cb_file = tmp_path / "cookbook.json"
    cb_file.write_text(json.dumps(cookbook), encoding="utf-8")

    with patch.object(srv, "_COOKBOOK_PATH", cb_file):
        results = _search_cookbook_json(["assessment"])

    assert results[0]["match_count"] >= results[1]["match_count"]


# ---------------------------------------------------------------------------
# Tests: _search_portal_yaml
# ---------------------------------------------------------------------------


def _make_yaml_file(directory: Path, name: str, content: str) -> Path:
    f = directory / name
    f.write_text(content, encoding="utf-8")
    return f


def test_search_portal_yaml_snippet_context(tmp_path):
    """Сниппет содержит строки вокруг вхождения keyword."""
    srv._workspace_path = tmp_path
    portal_dir = tmp_path / "dependencies" / "assess-portal"
    portal_dir.mkdir(parents=True)

    lines = [f"line {i}" for i in range(40)]
    lines[20] = "$lookup($ref, key)"
    expr = "\n".join(lines)

    yaml_content = f"datasets:\n  - name: my_dataset\n    source: |\n"
    for line in expr.splitlines():
        yaml_content += f"      {line}\n"

    _make_yaml_file(portal_dir, "test.yaml", yaml_content)

    results = _search_portal_yaml(["$lookup"])
    assert len(results) >= 1
    snippet = results[0]["snippet"]
    assert "$lookup" in snippet
    snippet_lines = snippet.splitlines()
    assert len(snippet_lines) <= 31  # ±15 строк = max 31


def test_search_portal_yaml_parent_name_match(tmp_path):
    """Совпадение по parent_name (имени датасета) включает выражение."""
    srv._workspace_path = tmp_path
    portal_dir = tmp_path / "dependencies" / "kadzo"
    portal_dir.mkdir(parents=True)

    yaml_content = (
        "datasets:\n"
        "  - name: assessment_objects_index\n"
        "    source: |\n"
        "      $.'sber.dka-dzo.assessment'\n"
    )
    _make_yaml_file(portal_dir, "test.yaml", yaml_content)

    results = _search_portal_yaml(["assessment_objects_index"])
    assert len(results) >= 1
    assert "assessment_objects_index" in results[0]["title"]


def test_search_portal_missing_dirs_skipped(tmp_path):
    """Отсутствующие portal-директории пропускаются без ошибок."""
    srv._workspace_path = tmp_path
    results = _search_portal_yaml(["anything"])
    assert results == []


# ---------------------------------------------------------------------------
# Tests: find_jsonata_examples
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_find_examples_portal_absent_cookbook_only(tmp_path, mock_ctx):
    """Если portal dirs нет, возвращает только cookbook с примечанием."""
    srv._workspace_path = tmp_path

    cookbook = [
        {
            "id": "q1",
            "group": "Группа",
            "question": "Пример с lookup",
            "entities": [],
            "query": "$lookup($ref, key)",
            "notes": "",
            "roles": [],
        }
    ]
    cb_file = tmp_path / "cookbook.json"
    cb_file.write_text(json.dumps(cookbook), encoding="utf-8")

    with patch.object(srv, "_COOKBOOK_PATH", cb_file):
        result = await find_jsonata_examples(["$lookup"], mock_ctx)

    assert "$lookup" in result
    assert "Примечание" in result or "Portal" in result


@pytest.mark.asyncio
async def test_find_examples_limit_respected(tmp_path, mock_ctx):
    """Параметр limit ограничивает число результатов."""
    srv._workspace_path = tmp_path

    cookbook = [
        {
            "id": f"q{i}",
            "group": "Группа",
            "question": f"Пример assessment {i}",
            "entities": ["assessment"],
            "query": f"$.assessment[{i}]",
            "notes": "",
            "roles": [],
        }
        for i in range(10)
    ]
    cb_file = tmp_path / "cookbook.json"
    cb_file.write_text(json.dumps(cookbook), encoding="utf-8")

    with patch.object(srv, "_COOKBOOK_PATH", cb_file):
        result = await find_jsonata_examples(["assessment"], mock_ctx, limit=3)

    count = result.count("### ")
    assert count == 3
