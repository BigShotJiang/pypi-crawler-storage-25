"""Тесты для модуля конфигурации."""

from pathlib import Path

import pytest

from seaf_helper_tools.core.config import (
    ApiConfig,
    AppConfig,
    ConfigError,
    get_config,
)


class TestApiConfigGetCertPassword:
    def test_seaf_env_var_takes_priority(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SEAF_API_CERT_PASSWORD", "seaf_password")
        monkeypatch.setenv("HELPER_API_CERT_PASSWORD", "helper_password")
        api_cfg = ApiConfig(
            host="example.com",
            cert_path=Path("/tmp/cert.p12"),
            cert_password="config_password",
        )

        assert api_cfg.get_cert_password() == "seaf_password"

    def test_helper_env_var_as_fallback(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("SEAF_API_CERT_PASSWORD", raising=False)
        monkeypatch.setenv("HELPER_API_CERT_PASSWORD", "helper_password")
        api_cfg = ApiConfig(
            host="example.com",
            cert_path=Path("/tmp/cert.p12"),
            cert_password="config_password",
        )

        assert api_cfg.get_cert_password() == "helper_password"

    def test_falls_back_to_instance_value(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("SEAF_API_CERT_PASSWORD", raising=False)
        monkeypatch.delenv("HELPER_API_CERT_PASSWORD", raising=False)
        api_cfg = ApiConfig(
            host="example.com",
            cert_path=Path("/tmp/cert.p12"),
            cert_password="config_password",
        )

        assert api_cfg.get_cert_password() == "config_password"

    def test_raises_if_no_password(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("SEAF_API_CERT_PASSWORD", raising=False)
        monkeypatch.delenv("HELPER_API_CERT_PASSWORD", raising=False)
        api_cfg = ApiConfig(
            host="example.com",
            cert_path=Path("/tmp/cert.p12"),
        )

        with pytest.raises(ConfigError, match="SEAF_API_CERT_PASSWORD"):
            api_cfg.get_cert_password()


class TestGetConfig:
    def test_returns_api_config_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SEAF_API_HOST", "seafile.example.com")
        monkeypatch.setenv("SEAF_API_CERT_PATH", "/tmp/cert.p12")

        config = get_config()

        assert config.api is not None
        assert config.api.host == "seafile.example.com"
        assert config.api.cert_path == Path("/tmp/cert.p12")
        assert config.api.verify_ssl is False

    def test_returns_empty_when_no_host(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("SEAF_API_HOST", raising=False)
        monkeypatch.delenv("SEAF_API_CERT_PATH", raising=False)

        config = get_config()

        assert isinstance(config, AppConfig)
        assert config.api is None

    def test_returns_empty_when_no_cert_path(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SEAF_API_HOST", "seafile.example.com")
        monkeypatch.delenv("SEAF_API_CERT_PATH", raising=False)

        config = get_config()

        assert config.api is None

    def test_verify_ssl_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SEAF_API_HOST", "seafile.example.com")
        monkeypatch.setenv("SEAF_API_CERT_PATH", "/tmp/cert.p12")
        monkeypatch.setenv("SEAF_API_VERIFY_SSL", "true")

        config = get_config()

        assert config.api is not None
        assert config.api.verify_ssl is True

    def test_verify_ssl_false_by_default(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SEAF_API_HOST", "seafile.example.com")
        monkeypatch.setenv("SEAF_API_CERT_PATH", "/tmp/cert.p12")
        monkeypatch.delenv("SEAF_API_VERIFY_SSL", raising=False)

        config = get_config()

        assert config.api is not None
        assert config.api.verify_ssl is False
