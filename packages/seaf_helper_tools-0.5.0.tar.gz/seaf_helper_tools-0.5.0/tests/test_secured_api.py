"""Тесты для SecuredApiCall."""

import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests

from seaf_helper_tools.utils.secured_api import (
    SecuredApiCall,
)


def _make_api(
    cert_path: Path | None = None,
    host: str = "api.example.com",
    verify_ssl: bool = False,
) -> SecuredApiCall:
    """Создать SecuredApiCall с мок SSL-контекстом."""
    if cert_path is None:
        # Создаём реальный пустой файл — load_cert_chain замокан, нужно только существование
        tmp = tempfile.NamedTemporaryFile(suffix=".p12", delete=False)
        tmp.close()
        cert_path = Path(tmp.name)
    with patch(
        "seaf_helper_tools.utils.secured_api.create_urllib3_context"
    ) as mock_ctx:
        mock_ctx.return_value = MagicMock()
        return SecuredApiCall(
            cert_file_path=cert_path,
            cert_password="test_password",
            host_name=host,
            verify_ssl=verify_ssl,
        )


class TestSecuredApiCallInit:
    def test_init_sets_host(self) -> None:
        api = _make_api(host="myserver.com")

        assert api.host_name == "myserver.com"

    def test_init_sets_cert_path(self, tmp_path: Path) -> None:
        cert = tmp_path / "cert.p12"
        cert.touch()
        api = _make_api(cert_path=cert)

        assert api.cert_file_path == cert


class TestSecuredApiCallGet:
    def _make_response(self, status: int, text: str = "ok") -> MagicMock:
        resp = MagicMock(spec=requests.Response)
        resp.status_code = status
        resp.text = text
        return resp

    def test_successful_get_returns_response(self) -> None:
        api = _make_api()
        ok_response = self._make_response(200)

        with patch.object(api._session, "get", return_value=ok_response) as mock_get:
            result = api.get("/api/data")

        assert result is ok_response
        # Первый вызов — инициализация сессии, второй — реальный запрос
        assert mock_get.call_count == 2

    def test_4xx_returned_without_retry(self) -> None:
        api = _make_api()
        not_found = self._make_response(404)

        with patch.object(api._session, "get", return_value=not_found) as mock_get:
            result = api.get("/api/missing")

        assert result.status_code == 404
        assert mock_get.call_count == 2  # 1 сессия + 1 запрос

    def test_5xx_triggers_retry(self) -> None:
        api = _make_api()
        server_error = self._make_response(500)
        ok_response = self._make_response(200)

        call_count = 0

        def side_effect(*args: object, **kwargs: object) -> MagicMock:
            nonlocal call_count
            call_count += 1
            # 1-й вызов — инициализация сессии (нет PLATFORM_SESSION_2)
            # 2-й вызов — первая попытка (500)
            # 3-й вызов — retry инициализация сессии
            # 4-й вызов — retry запрос (200)
            if call_count in (2,):
                return server_error
            return ok_response

        with patch.object(api._session, "get", side_effect=side_effect):
            with patch("seaf_helper_tools.utils.secured_api.time.sleep"):
                result = api.get("/api/unstable")

        assert result.status_code == 200

    def test_no_retry_if_predicate_skips_retry(self) -> None:
        api = _make_api()
        server_error = self._make_response(500, text='{"error": "S0202"}')

        call_count = 0

        def side_effect(*args: object, **kwargs: object) -> MagicMock:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # Инициализация сессии
                ok = MagicMock(spec=requests.Response)
                ok.status_code = 200
                ok.cookies = {}
                return ok
            return server_error

        no_retry = MagicMock(return_value=True)

        with patch.object(api._session, "get", side_effect=side_effect):
            result = api.get("/api/endpoint", no_retry_if=no_retry)

        assert result.status_code == 500
        no_retry.assert_called_once_with(server_error)
        # Всего 2 вызова: инициализация + первая попытка (без retry)
        assert call_count == 2

    def test_connection_error_raises_after_retries(self) -> None:
        api = _make_api()

        with patch.object(
            api._session, "get", side_effect=requests.ConnectionError("no route")
        ):
            with patch("seaf_helper_tools.utils.secured_api.time.sleep"):
                with pytest.raises(requests.ConnectionError):
                    api.get("/api/endpoint")
