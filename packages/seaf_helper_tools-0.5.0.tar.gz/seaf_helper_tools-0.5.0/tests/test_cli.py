"""Smoke tests for CLI app."""

import re

from typer.testing import CliRunner

from seaf_helper_tools.cli import app

runner = CliRunner()

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def _strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def test_app_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "survey-standards-yaml2xls" in result.stdout


def test_assessment_yaml2xls_help():
    result = runner.invoke(app, ["survey-standards-yaml2xls", "--help"])
    assert result.exit_code == 0
    output = _strip_ansi(result.stdout)
    assert "--template" in output
    assert "--company" in output
