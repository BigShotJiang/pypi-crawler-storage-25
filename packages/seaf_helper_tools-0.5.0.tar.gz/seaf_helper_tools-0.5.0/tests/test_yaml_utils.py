"""Unit tests for yaml_utils."""

from pathlib import Path

import pytest

from seaf_helper_tools.utils.yaml_utils import index_yaml_paths, load_yaml

FIXTURES = Path(__file__).parent / "fixtures"


def test_load_yaml_fixture():
    data = load_yaml(FIXTURES / "tile_server.yaml")
    objects = data["sber.dka-dzo.assessment.methods.standards.object"]
    assert len(objects) == 1


def test_load_yaml_fixture_object_structure():
    data = load_yaml(FIXTURES / "tile_server.yaml")
    objects = data["sber.dka-dzo.assessment.methods.standards.object"]
    obj_id, obj = next(iter(objects.items()))
    assert obj_id == "mybis.2025_0.automated_system.tile_server__fcb1"
    assert obj["title"] == "tile server"
    assert obj["assessment_ref"] == "mybis.2025_0"
    assert isinstance(obj["req_compliance"], list)
    assert len(obj["req_compliance"]) > 0


def test_load_yaml_fixture_req_compliance_fields():
    data = load_yaml(FIXTURES / "tile_server.yaml")
    objects = data["sber.dka-dzo.assessment.methods.standards.object"]
    _, obj = next(iter(objects.items()))
    first_req = obj["req_compliance"][0]
    assert first_req["requirement_ref"] == "sber.standards.TACNW_1-L-1-01"
    assert first_req["compliance"] == "Не применимо"


def test_load_yaml_nonexistent_file():
    with pytest.raises(FileNotFoundError):
        load_yaml("/nonexistent/path/file.yaml")


def test_index_yaml_paths_single_file(tmp_path):
    f = tmp_path / "a.yaml"
    f.write_text("key1:\n  sub1: val1\nkey2: val2\n", encoding="utf-8")
    result = index_yaml_paths([f])
    assert result["key1"]["sub1"] == "val1"
    assert result["key2"] == "val2"


def test_index_yaml_paths_merge_files(tmp_path):
    (tmp_path / "a.yaml").write_text("key1:\n  sub1: val1\n", encoding="utf-8")
    (tmp_path / "b.yaml").write_text(
        "key1:\n  sub2: val2\nkey2: val3\n", encoding="utf-8"
    )
    result = index_yaml_paths([tmp_path])
    assert result["key1"]["sub1"] == "val1"
    assert result["key1"]["sub2"] == "val2"
    assert result["key2"] == "val3"


def test_index_yaml_paths_later_file_wins(tmp_path):
    (tmp_path / "a.yaml").write_text("key1: original\n", encoding="utf-8")
    (tmp_path / "b.yaml").write_text("key1: overwritten\n", encoding="utf-8")
    result = index_yaml_paths([tmp_path])
    # b.yaml comes after a.yaml alphabetically → wins
    assert result["key1"] == "overwritten"


def test_index_yaml_paths_empty():
    result = index_yaml_paths([])
    assert result == {}


def test_index_yaml_paths_from_fixture():
    result = index_yaml_paths([FIXTURES / "tile_server.yaml"])
    assert "sber.dka-dzo.assessment.methods.standards.object" in result
