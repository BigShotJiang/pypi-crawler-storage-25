"""Integration tests for survey-standards-yaml2xls command."""

from pathlib import Path

import pytest
from openpyxl import load_workbook
from typer.testing import CliRunner

from seaf_helper_tools.cli import app
from seaf_helper_tools.commands.assessment_yaml2xls import _decorate_value
from seaf_helper_tools.utils.xls_utils import find_col_idx, find_row_idx

FIXTURES = Path(__file__).parent / "fixtures"
TEMPLATE = FIXTURES / "template_survey.xlsx"
YAML_FILE = FIXTURES / "tile_server.yaml"

runner = CliRunner()


# ---------------------------------------------------------------------------
# _decorate_value
# ---------------------------------------------------------------------------


def test_decorate_value_booleans():
    assert _decorate_value(True) == "Да"
    assert _decorate_value(False) == "Нет"


def test_decorate_value_passthrough():
    assert _decorate_value("some string") == "some string"
    assert _decorate_value(None) is None
    assert _decorate_value(42) == 42


def test_decorate_value_cloud_readiness():
    assert (
        _decorate_value("cloud_ready_1")
        == "Монолит на виртуализированном аппаратном обеспечении"
    )


# ---------------------------------------------------------------------------
# CLI: argument / option validation
# ---------------------------------------------------------------------------


def test_missing_template_option(tmp_path):
    result = runner.invoke(
        app,
        [
            "survey-standards-yaml2xls",
            str(YAML_FILE),
            str(tmp_path / "out.xlsx"),
            "--company",
            "Test",
        ],
    )
    assert result.exit_code != 0


def test_missing_company_option(tmp_path):
    result = runner.invoke(
        app,
        [
            "survey-standards-yaml2xls",
            str(YAML_FILE),
            str(tmp_path / "out.xlsx"),
            "--template",
            str(TEMPLATE),
        ],
    )
    assert result.exit_code != 0


def test_nonexistent_yaml_file(tmp_path):
    result = runner.invoke(
        app,
        [
            "survey-standards-yaml2xls",
            str(tmp_path / "missing.yaml"),
            str(tmp_path / "out.xlsx"),
            "--template",
            str(TEMPLATE),
            "--company",
            "Test",
        ],
    )
    assert result.exit_code != 0


def test_nonexistent_template(tmp_path):
    result = runner.invoke(
        app,
        [
            "survey-standards-yaml2xls",
            str(YAML_FILE),
            str(tmp_path / "out.xlsx"),
            "--template",
            str(tmp_path / "no_template.xlsx"),
            "--company",
            "Test",
        ],
    )
    assert result.exit_code != 0


def test_template_missing_required_sheets(tmp_path):
    """Шаблон без обязательных листов → ошибка с именами листов."""
    from openpyxl import Workbook

    wb = Workbook()
    wb.active.title = "Sheet1"  # type: ignore[union-attr]
    bad_template = tmp_path / "bad_template.xlsx"
    wb.save(str(bad_template))

    result = runner.invoke(
        app,
        [
            "survey-standards-yaml2xls",
            str(YAML_FILE),
            str(tmp_path / "out.xlsx"),
            "--template",
            str(bad_template),
            "--company",
            "Test",
        ],
    )
    assert result.exit_code != 0
    assert (
        "Общее" in result.output
        or "era-manifest" in result.output
        or "Опросник" in result.output
    )


def test_success_message_contains_object_id(tmp_path):
    """Успешное сообщение должно содержать ID объекта и счётчики."""
    out = tmp_path / "out.xlsx"
    result = runner.invoke(
        app,
        [
            "survey-standards-yaml2xls",
            str(YAML_FILE),
            str(out),
            "--template",
            str(TEMPLATE),
            "--company",
            "MyBIS",
        ],
    )
    assert result.exit_code == 0, result.output
    assert "tile_server" in result.output
    assert "mybis.2025_0" in result.output
    assert "Готово" in result.output


# ---------------------------------------------------------------------------
# Full integration: run command, inspect output
# ---------------------------------------------------------------------------


@pytest.fixture()
def output_wb(tmp_path):
    out = tmp_path / "output.xlsx"
    result = runner.invoke(
        app,
        [
            "survey-standards-yaml2xls",
            str(YAML_FILE),
            str(out),
            "--template",
            str(TEMPLATE),
            "--company",
            "MyBIS",
        ],
    )
    assert result.exit_code == 0, result.output
    assert out.exists()
    return load_workbook(out)


def test_output_file_created(tmp_path):
    out = tmp_path / "output.xlsx"
    runner.invoke(
        app,
        [
            "survey-standards-yaml2xls",
            str(YAML_FILE),
            str(out),
            "--template",
            str(TEMPLATE),
            "--company",
            "MyBIS",
        ],
    )
    assert out.exists()


def test_era_manifest_filled(output_wb):
    ws = output_wb["era-manifest"]
    manifest = {ws[r][0].value: ws[r][1].value for r in range(1, 5)}
    assert manifest["assessment_ref"] == "mybis.2025_0"
    assert manifest["object_ref"] == "mybis.2025_0.automated_system.tile_server__fcb1"
    assert manifest["company_ref"] == "mybis"
    assert manifest["template_version"] == "0.1"


def test_obshee_company_name(output_wb):
    ws = output_wb["Общее"]
    company_row = find_row_idx(ws["A"], ["Компания"], fail_fast=False)
    assert company_row is not None
    # era-propvalues column is B (index 1)
    assert ws["B"][company_row].value == "MyBIS"


def test_obshee_object_title(output_wb):
    ws = output_wb["Общее"]
    title_row = find_row_idx(
        ws["A"],
        ["Название", "Имя", "Имя (АС1-АС2)", "Название (title)"],
        fail_fast=False,
    )
    assert title_row is not None
    assert ws["B"][title_row].value == "tile server"


def test_obshee_metainfo_criticality(output_wb):
    ws = output_wb["Общее"]
    # E column has era-propnames; criticality_confirmed → B column
    prop_col = ws["E"]
    crit_row = find_row_idx(prop_col, ["criticality_confirmed"], fail_fast=False)
    assert crit_row is not None
    assert ws["B"][crit_row].value == "Mission Critical"


def test_obshee_metainfo_boolean_decorated(output_wb):
    ws = output_wb["Общее"]
    prop_col = ws["E"]
    conf_row = find_row_idx(prop_col, ["conf_data"], fail_fast=False)
    assert conf_row is not None
    assert ws["B"][conf_row].value == "Нет"  # False → "Нет"

    ext_row = find_row_idx(prop_col, ["external_clients"], fail_fast=False)
    assert ext_row is not None
    assert ws["B"][ext_row].value == "Да"  # True → "Да"


def test_oprosnik_compliance_values(output_wb):
    ws = output_wb["Опросник"]
    head_row = ws[1]
    idx_era_id = find_col_idx(head_row, ["era-id вопроса"])
    idx_answer = find_col_idx(head_row, ["ОТВЕТ - степень соответсвия стандарту"])

    # Build map era-id → compliance from output
    results = {}
    for row_idx in range(2, ws.max_row + 1):
        era_id = ws[row_idx][idx_era_id].value
        if era_id:
            results[str(era_id).strip()] = ws[row_idx][idx_answer].value

    assert results.get("sber.standards.TACNW_1-L-1-01") == "Не применимо"
    assert results.get("sber.standards.TACNW_1-L-4-01") == "Полностью соответствует"
    assert results.get("sber.standards.TACAP_2-07.OKB-2-03") == "Частично соответствует"


def test_oprosnik_comment_written(output_wb):
    ws = output_wb["Опросник"]
    head_row = ws[1]
    idx_era_id = find_col_idx(head_row, ["era-id вопроса"])
    idx_comment = find_col_idx(head_row, ["Комментарий"])

    for row_idx in range(2, ws.max_row + 1):
        era_id = ws[row_idx][idx_era_id].value
        if era_id == "sber.standards.TACNW_1-L-7-01":
            assert (
                ws[row_idx][idx_comment].value
                == "АПИ и воркер во нутренней сети за Ингресом"
            )
            return
    pytest.fail("Row for sber.standards.TACNW_1-L-7-01 not found")


def test_oprosnik_recommendation_written(output_wb):
    ws = output_wb["Опросник"]
    head_row = ws[1]
    idx_era_id = find_col_idx(head_row, ["era-id вопроса"])
    idx_recommend = find_col_idx(head_row, ["Рекомендации ДКА"])
    idx_recommend_short = find_col_idx(head_row, ["Рекомендации ДКА коротко"])

    for row_idx in range(2, ws.max_row + 1):
        era_id = ws[row_idx][idx_era_id].value
        if era_id == "sber.standards.TACAP_2-07.OKB-2-03":
            assert ws[row_idx][idx_recommend].value == "Организовать DMZ на базе NGFW."
            assert ws[row_idx][idx_recommend_short].value == "Привести в соответствие"
            return
    pytest.fail("Row for TACAP_2-07.OKB-2-03 not found")
