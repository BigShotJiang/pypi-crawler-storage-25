"""Tests for survey-standards-xls2yaml command."""

from pathlib import Path
from typing import Any

import pytest
from typer.testing import CliRunner

from seaf_helper_tools.cli import app
from seaf_helper_tools.commands.assessment_xls2yaml import (
    _has_answers,
    _parse_xls,
    _reverse_value,
)
from seaf_helper_tools.utils.yaml_utils import load_yaml, write_yaml

FIXTURES = Path(__file__).parent / "fixtures"
TEMPLATE = FIXTURES / "template_survey.xlsx"
YAML_FILE = FIXTURES / "tile_server.yaml"

runner = CliRunner()

OBJ_KEY = "sber.dka-dzo.assessment.methods.standards.object"
OBJ_REF = "mybis.2025_0.automated_system.tile_server__fcb1"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_xls(tmp_path: Path) -> Path:
    """Run yaml2xls on tile_server fixture → return XLS path."""
    xls = tmp_path / "survey.xlsx"
    result = runner.invoke(
        app,
        [
            "survey-standards-yaml2xls",
            str(YAML_FILE),
            str(xls),
            "--template",
            str(TEMPLATE),
            "--company",
            "MyBIS",
        ],
    )
    assert result.exit_code == 0, result.output
    return xls


def _run_xls2yaml(xls: Path, output: Path, extra_args: list[str] | None = None) -> Any:
    args = ["survey-standards-xls2yaml", str(xls), str(output)]
    if extra_args:
        args += extra_args
    return runner.invoke(app, args)


# ---------------------------------------------------------------------------
# _reverse_value unit tests
# ---------------------------------------------------------------------------


def test_reverse_value_true():
    assert _reverse_value("Да") is True
    assert _reverse_value("да") is True
    assert _reverse_value("ДА") is True


def test_reverse_value_false():
    assert _reverse_value("Нет") is False
    assert _reverse_value("нет") is False


def test_reverse_value_cloud():
    assert (
        _reverse_value("Монолит на стандартном аппаратном обеспечении") == "no_cloud_1"
    )
    assert (
        _reverse_value(
            "Компоненты в контейнерах на виртуализированном аппаратном обеспечении"
        )
        == "cloud_ready_2"
    )


def test_reverse_value_passthrough():
    assert _reverse_value("Полностью соответствует") == "Полностью соответствует"
    assert _reverse_value(None) is None
    assert _reverse_value(42) == 42


# ---------------------------------------------------------------------------
# _parse_xls unit tests
# ---------------------------------------------------------------------------


def test_parse_xls_returns_correct_keys(tmp_path: Path):
    xls = _make_xls(tmp_path)
    company_ref, object_ref, yaml_data = _parse_xls(xls)

    assert company_ref == "mybis"
    assert object_ref == OBJ_REF
    assert OBJ_KEY in yaml_data
    assert OBJ_REF in yaml_data[OBJ_KEY]


def test_parse_xls_req_compliance_not_empty(tmp_path: Path):
    xls = _make_xls(tmp_path)
    _, _, yaml_data = _parse_xls(xls)
    reqs = yaml_data[OBJ_KEY][OBJ_REF]["req_compliance"]
    assert len(reqs) > 0


def test_parse_xls_assessment_ref(tmp_path: Path):
    xls = _make_xls(tmp_path)
    _, _, yaml_data = _parse_xls(xls)
    assert yaml_data[OBJ_KEY][OBJ_REF]["assessment_ref"] == "mybis.2025_0"


# ---------------------------------------------------------------------------
# CLI: validation
# ---------------------------------------------------------------------------


def test_missing_xls_file(tmp_path: Path):
    result = _run_xls2yaml(tmp_path / "nonexistent.xlsx", tmp_path / "out.yaml")
    assert result.exit_code != 0


def test_missing_era_manifest(tmp_path: Path):
    """XLS без era-manifest → ошибка с указанием найденных листов."""
    from openpyxl import Workbook

    wb = Workbook()
    wb.active.title = "Sheet1"  # type: ignore[union-attr]
    bad_xls = tmp_path / "bad.xlsx"
    wb.save(str(bad_xls))

    result = _run_xls2yaml(bad_xls, tmp_path / "out.yaml")
    assert result.exit_code != 0
    assert "era-manifest" in result.output


def test_missing_xls_error_message(tmp_path: Path):
    """Несуществующий XLS → понятное сообщение об ошибке."""
    result = _run_xls2yaml(tmp_path / "nonexistent.xlsx", tmp_path / "out.yaml")
    assert result.exit_code != 0
    assert "не найден" in result.output.lower() or "not found" in result.output.lower()


def test_success_message_contains_counts(tmp_path: Path):
    """Успешное сообщение должно содержать объект, режим и счётчики требований."""
    xls = _make_xls(tmp_path)
    out = tmp_path / "result.yaml"
    result = _run_xls2yaml(xls, out)
    assert result.exit_code == 0, result.output
    assert "Готово" in result.output
    assert "tile_server" in result.output
    assert "mybis.2025_0" in result.output
    # Счётчики требований
    assert "Требований" in result.output


# ---------------------------------------------------------------------------
# Roundtrip: yaml2xls → xls2yaml
# ---------------------------------------------------------------------------


@pytest.fixture()
def roundtrip_yaml(tmp_path: Path) -> dict:
    """Full roundtrip: yaml → xls → yaml, returns parsed result."""
    xls = _make_xls(tmp_path)
    out_yaml = tmp_path / "result.yaml"
    result = _run_xls2yaml(xls, out_yaml)
    assert result.exit_code == 0, result.output
    assert out_yaml.exists()
    return load_yaml(out_yaml)  # type: ignore[return-value]


def test_roundtrip_creates_file(tmp_path: Path):
    xls = _make_xls(tmp_path)
    out = tmp_path / "result.yaml"
    r = _run_xls2yaml(xls, out)
    assert r.exit_code == 0
    assert out.exists()


def test_roundtrip_object_key_present(roundtrip_yaml: dict):
    assert OBJ_KEY in roundtrip_yaml
    assert OBJ_REF in roundtrip_yaml[OBJ_KEY]


def test_roundtrip_assessment_ref(roundtrip_yaml: dict):
    assert roundtrip_yaml[OBJ_KEY][OBJ_REF]["assessment_ref"] == "mybis.2025_0"


def test_roundtrip_req_compliance_values(roundtrip_yaml: dict):
    original = load_yaml(YAML_FILE)
    orig_reqs: dict[str, Any] = {
        r["requirement_ref"]: r for r in original[OBJ_KEY][OBJ_REF]["req_compliance"]
    }
    rt_reqs: dict[str, Any] = {
        r["requirement_ref"]: r
        for r in roundtrip_yaml[OBJ_KEY][OBJ_REF]["req_compliance"]
    }

    for ref, orig_req in orig_reqs.items():
        assert ref in rt_reqs, f"requirement_ref {ref} пропал после roundtrip"
        for field in (
            "compliance",
            "comment",
            "method",
            "recommendation",
            "recommendation_short",
        ):
            assert rt_reqs[ref].get(field) == orig_req.get(field), (
                f"Расхождение в {ref}.{field}: "
                f"original={orig_req.get(field)!r}, "
                f"roundtrip={rt_reqs[ref].get(field)!r}"
            )


def test_roundtrip_metainfo_boolean(roundtrip_yaml: dict):
    meta = roundtrip_yaml[OBJ_KEY][OBJ_REF]["metainfo"]
    assert meta.get("conf_data") is False
    assert meta.get("external_clients") is True


def test_roundtrip_multiline_preserved(roundtrip_yaml: dict):
    """Многострочный комментарий должен сохраниться."""
    rt_reqs = {
        r["requirement_ref"]: r
        for r in roundtrip_yaml[OBJ_KEY][OBJ_REF]["req_compliance"]
    }
    req = rt_reqs.get("sber.standards.TACNW_1-L-9-01")
    assert req is not None
    comment = req.get("comment", "")
    assert "\n" in str(comment)


# ---------------------------------------------------------------------------
# Merge mode: abort
# ---------------------------------------------------------------------------


def test_abort_mode_fails_when_answers_exist(tmp_path: Path):
    xls = _make_xls(tmp_path)
    out = tmp_path / "result.yaml"
    # Первый раз — создаём файл
    r1 = _run_xls2yaml(xls, out)
    assert r1.exit_code == 0

    # Второй раз без --mode → abort
    r2 = _run_xls2yaml(xls, out)
    assert r2.exit_code != 0
    assert "ответы" in r2.output.lower() or "mode" in r2.output.lower()


def test_abort_mode_succeeds_when_no_answers(tmp_path: Path):
    xls = _make_xls(tmp_path)
    out = tmp_path / "result.yaml"

    # Создаём YAML без ответов
    from ruamel.yaml.comments import CommentedMap, CommentedSeq

    empty_yaml: CommentedMap = CommentedMap(
        {
            OBJ_KEY: CommentedMap(
                {
                    OBJ_REF: CommentedMap(
                        {
                            "assessment_ref": "mybis.2025_0",
                            "metainfo": CommentedMap(),
                            "req_compliance": CommentedSeq(),
                        }
                    )
                }
            )
        }
    )
    write_yaml(out, empty_yaml)
    assert not _has_answers(load_yaml(out))

    r = _run_xls2yaml(xls, out)
    assert r.exit_code == 0


# ---------------------------------------------------------------------------
# Merge mode: only-new
# ---------------------------------------------------------------------------


def test_only_new_preserves_existing_values(tmp_path: Path):
    """Существующие ответы не должны перезаписываться в режиме only-new."""
    xls = _make_xls(tmp_path)
    out = tmp_path / "result.yaml"

    # Создаём YAML с одним переопределённым ответом
    original = load_yaml(YAML_FILE)
    obj = original[OBJ_KEY][OBJ_REF]
    sentinel_ref = obj["req_compliance"][0]["requirement_ref"]
    obj["req_compliance"][0]["compliance"] = "SENTINEL_VALUE"

    from ruamel.yaml.comments import CommentedMap

    write_yaml(out, CommentedMap(original))

    r = _run_xls2yaml(xls, out, ["--mode", "only-new"])
    assert r.exit_code == 0

    result = load_yaml(out)
    reqs = {
        req["requirement_ref"]: req
        for req in result[OBJ_KEY][OBJ_REF]["req_compliance"]
    }
    assert reqs[sentinel_ref]["compliance"] == "SENTINEL_VALUE"


def test_only_new_fills_empty_fields(tmp_path: Path):
    """Пустые поля заполняются из XLS в режиме only-new."""
    xls = _make_xls(tmp_path)
    out = tmp_path / "result.yaml"

    original = load_yaml(YAML_FILE)
    obj = original[OBJ_KEY][OBJ_REF]

    # Найдём req с непустым compliance и обнулим его
    target = next(r for r in obj["req_compliance"] if r.get("compliance") is not None)
    target_ref = target["requirement_ref"]
    target_original_compliance = target["compliance"]
    target["compliance"] = None

    from ruamel.yaml.comments import CommentedMap

    write_yaml(out, CommentedMap(original))

    r = _run_xls2yaml(xls, out, ["--mode", "only-new"])
    assert r.exit_code == 0

    result = load_yaml(out)
    reqs = {
        req["requirement_ref"]: req
        for req in result[OBJ_KEY][OBJ_REF]["req_compliance"]
    }
    assert reqs[target_ref]["compliance"] == target_original_compliance


# ---------------------------------------------------------------------------
# Merge mode: overwrite
# ---------------------------------------------------------------------------


def test_overwrite_replaces_existing_nonempty(tmp_path: Path):
    """Режим overwrite перезаписывает непустыми значениями из XLS."""
    xls = _make_xls(tmp_path)
    out = tmp_path / "result.yaml"

    original = load_yaml(YAML_FILE)
    obj = original[OBJ_KEY][OBJ_REF]
    target = next(r for r in obj["req_compliance"] if r.get("compliance") is not None)
    target_ref = target["requirement_ref"]
    target_xls_compliance = target["compliance"]
    target["compliance"] = "SENTINEL_VALUE"

    from ruamel.yaml.comments import CommentedMap

    write_yaml(out, CommentedMap(original))

    r = _run_xls2yaml(xls, out, ["--mode", "overwrite"])
    assert r.exit_code == 0

    result = load_yaml(out)
    reqs = {
        req["requirement_ref"]: req
        for req in result[OBJ_KEY][OBJ_REF]["req_compliance"]
    }
    assert reqs[target_ref]["compliance"] == target_xls_compliance


def test_overwrite_skips_null_xls_values(tmp_path: Path):
    """Режим overwrite не затирает YAML-значения пустыми XLS-ячейками."""
    xls = _make_xls(tmp_path)
    out = tmp_path / "result.yaml"

    original = load_yaml(YAML_FILE)
    obj = original[OBJ_KEY][OBJ_REF]
    # Найдём req где extra_questions = None в XLS (почти все)
    target = obj["req_compliance"][0]
    target_ref = target["requirement_ref"]
    target["extra_questions"] = "KEEP_THIS"

    from ruamel.yaml.comments import CommentedMap

    write_yaml(out, CommentedMap(original))

    r = _run_xls2yaml(xls, out, ["--mode", "overwrite"])
    assert r.exit_code == 0

    result = load_yaml(out)
    reqs = {
        req["requirement_ref"]: req
        for req in result[OBJ_KEY][OBJ_REF]["req_compliance"]
    }
    assert reqs[target_ref]["extra_questions"] == "KEEP_THIS"


# ---------------------------------------------------------------------------
# Merge mode: overwrite-all
# ---------------------------------------------------------------------------


def test_overwrite_all_replaces_even_nulls(tmp_path: Path):
    """Режим overwrite-all переносит всё из XLS, включая пустые значения."""
    xls = _make_xls(tmp_path)
    out = tmp_path / "result.yaml"

    original = load_yaml(YAML_FILE)
    obj = original[OBJ_KEY][OBJ_REF]
    target = obj["req_compliance"][0]
    target_ref = target["requirement_ref"]
    target["extra_questions"] = "WILL_BE_ERASED"

    from ruamel.yaml.comments import CommentedMap

    write_yaml(out, CommentedMap(original))

    r = _run_xls2yaml(xls, out, ["--mode", "overwrite-all"])
    assert r.exit_code == 0

    result = load_yaml(out)
    reqs = {
        req["requirement_ref"]: req
        for req in result[OBJ_KEY][OBJ_REF]["req_compliance"]
    }
    # XLS has None for extra_questions → должно стать None
    assert reqs[target_ref].get("extra_questions") is None
