"""Тесты для SeafJsonataCall."""

from unittest.mock import MagicMock

import pytest
import requests

from seaf_helper_tools.mcp.api import (
    _POLYFILL_HINTS,
    _SLICE_HINT,
    _check_undefined_custom_functions,
    _check_unsupported_syntax,
)
from seaf_helper_tools.utils.jsonata import SeafJsonataCall, _is_jsonata_permanent_error
from seaf_helper_tools.utils.secured_api import SecuredApiCall


def _make_jsonata() -> tuple[SeafJsonataCall, MagicMock]:
    """Создать SeafJsonataCall с мок SecuredApiCall."""
    mock_api = MagicMock(spec=SecuredApiCall)
    return SeafJsonataCall(mock_api), mock_api


def _make_response(status: int, text: str) -> MagicMock:
    resp = MagicMock(spec=requests.Response)
    resp.status_code = status
    resp.text = text
    return resp


class TestIsJsonataPermanentError:
    def test_jsonata_error_code_is_permanent(self) -> None:
        resp = _make_response(500, '{"error": "S0202 syntax error"}')

        assert _is_jsonata_permanent_error(resp) is True

    def test_d1_error_code_is_permanent(self) -> None:
        resp = _make_response(500, '{"error": "D1001 division by zero"}')

        assert _is_jsonata_permanent_error(resp) is True

    def test_regular_server_error_is_not_permanent(self) -> None:
        resp = _make_response(500, "Internal server error")

        assert _is_jsonata_permanent_error(resp) is False

    def test_response_without_error_key_is_not_permanent(self) -> None:
        resp = _make_response(500, "timeout")

        assert _is_jsonata_permanent_error(resp) is False


class TestSeafJsonataCallEvalJsonata:
    def test_successful_query_returns_text(self) -> None:
        jsonata, mock_api = _make_jsonata()
        ok_response = _make_response(200, '["result1", "result2"]')
        ok_response.raise_for_status = MagicMock()
        mock_api.get.return_value = ok_response

        result = jsonata.eval_jsonata("library.files.*.name")

        assert result == '["result1", "result2"]'
        mock_api.get.assert_called_once()

    def test_query_is_url_encoded(self) -> None:
        jsonata, mock_api = _make_jsonata()
        ok_response = _make_response(200, "null")
        ok_response.raise_for_status = MagicMock()
        mock_api.get.return_value = ok_response

        jsonata.eval_jsonata("library/files")

        call_args = mock_api.get.call_args[0][0]
        # слэш закодирован как %2F
        assert "%2F" in call_args

    def test_endpoint_format(self) -> None:
        jsonata, mock_api = _make_jsonata()
        ok_response = _make_response(200, "42")
        ok_response.raise_for_status = MagicMock()
        mock_api.get.return_value = ok_response

        jsonata.eval_jsonata("$count(items)")

        endpoint = mock_api.get.call_args[0][0]
        assert endpoint.startswith("/core/storage/jsonata/(")
        assert "params=null" in endpoint
        assert "subject=null" in endpoint

    def test_http_error_is_raised(self) -> None:
        jsonata, mock_api = _make_jsonata()
        error_response = _make_response(404, "Not found")
        error_response.raise_for_status = MagicMock(
            side_effect=requests.HTTPError("404")
        )
        mock_api.get.return_value = error_response

        with pytest.raises(requests.HTTPError):
            jsonata.eval_jsonata("library.name")

    def test_no_retry_if_predicate_passed(self) -> None:
        jsonata, mock_api = _make_jsonata()
        ok_response = _make_response(200, "ok")
        ok_response.raise_for_status = MagicMock()
        mock_api.get.return_value = ok_response

        jsonata.eval_jsonata("items")

        # Проверяем, что no_retry_if передан (предикат для JSONata ошибок)
        _, kwargs = mock_api.get.call_args
        assert "no_retry_if" in kwargs
        assert callable(kwargs["no_retry_if"])


class TestCheckUndefinedCustomFunctions:
    def test_both_defined_returns_none(self) -> None:
        query = "$values:=function($v){$v}; $take:=function($v,$n){$v}; $values($data)"
        assert _check_undefined_custom_functions(query) is None

    def test_values_defined_take_missing(self) -> None:
        query = "$values:=function($v){$v}; $take($data, 3)"
        result = _check_undefined_custom_functions(query)
        assert result is not None
        assert "$take()" in result
        assert "$take:=function" in result
        assert "$values:=function" not in result

    def test_take_defined_values_missing(self) -> None:
        query = "$take:=function($v,$n){$v}; $values($data)"
        result = _check_undefined_custom_functions(query)
        assert result is not None
        assert "$values()" in result
        assert "$values:=function" in result
        assert "$take:=function" not in result

    def test_both_missing_returns_both_defs(self) -> None:
        query = "$values($data) + $take($data, 2)"
        result = _check_undefined_custom_functions(query)
        assert result is not None
        assert "$values:=function" in result
        assert "$take:=function" in result

    def test_neither_used_returns_none(self) -> None:
        query = "$.'technologies'[vendor='Oracle']"
        assert _check_undefined_custom_functions(query) is None

    def test_hint_contains_array_branch(self) -> None:
        query = "$values($data)"
        result = _check_undefined_custom_functions(query)
        assert result is not None
        assert "'array'" in result

    def test_hint_contains_object_branch(self) -> None:
        query = "$values($data)"
        result = _check_undefined_custom_functions(query)
        assert result is not None
        assert "'object'" in result

    def test_hint_contains_exists_check(self) -> None:
        query = "$values($data)"
        result = _check_undefined_custom_functions(query)
        assert result is not None
        assert "$exists" in result

    def test_hint_wrapped_in_code_block(self) -> None:
        query = "$take($data, 5)"
        result = _check_undefined_custom_functions(query)
        assert result is not None
        assert "```" in result


class TestCheckUnsupportedSyntaxSliceHint:
    def test_slice_syntax_triggers_hint(self) -> None:
        result = _check_unsupported_syntax("$data[0:5]")
        assert result is not None
        assert "$slice:=function" in result

    def test_slice_hint_no_error_string(self) -> None:
        result = _check_unsupported_syntax("$data[1:3]")
        assert result is not None
        assert "Ошибка" not in result

    def test_slice_hint_contains_object_branch(self) -> None:
        assert "'object'" in _SLICE_HINT

    def test_slice_hint_contains_array_branch(self) -> None:
        assert "$filter" in _SLICE_HINT

    def test_slice_hint_fallback_is_empty_array(self) -> None:
        assert ":[])" in _SLICE_HINT

    def test_range_syntax_no_slice_hint(self) -> None:
        result = _check_unsupported_syntax("$data[0..3]")
        assert result is not None
        assert "$slice:=function" not in result

    def test_no_special_syntax_returns_none(self) -> None:
        assert _check_unsupported_syntax("$.items.name") is None


class TestPolyfillHintContent:
    def test_values_polyfill_handles_array(self) -> None:
        assert "'array'" in _POLYFILL_HINTS["values"]

    def test_values_polyfill_handles_object_via_each(self) -> None:
        assert "$each" in _POLYFILL_HINTS["values"]

    def test_values_polyfill_handles_exists(self) -> None:
        assert "$exists" in _POLYFILL_HINTS["values"]

    def test_values_polyfill_returns_empty_for_null(self) -> None:
        assert ":[])" in _POLYFILL_HINTS["values"]

    def test_take_polyfill_handles_array(self) -> None:
        assert "'array'" in _POLYFILL_HINTS["take"]

    def test_take_polyfill_handles_singleton(self) -> None:
        assert "$exists" in _POLYFILL_HINTS["take"]
        assert "[$v]" in _POLYFILL_HINTS["take"]

    def test_take_polyfill_returns_empty_for_null(self) -> None:
        assert ":[])" in _POLYFILL_HINTS["take"]
