"""Unit tests for xls_utils."""

import pytest
from openpyxl import Workbook

from seaf_helper_tools.utils.xls_utils import (
    find_col_idx,
    find_col_idx_multi_header,
    find_row_idx,
)


@pytest.fixture()
def simple_wb():
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Код"
    ws["B1"] = "Требование"
    ws["C1"] = "Комментарий"
    ws["D1"] = "ОТВЕТ - степень соответсвия стандарту"
    return wb


def test_find_col_idx_found(simple_wb):
    head_row = simple_wb.active[1]
    assert find_col_idx(head_row, ["Код"]) == 0
    assert find_col_idx(head_row, ["Требование"]) == 1
    assert find_col_idx(head_row, ["Комментарий"]) == 2


def test_find_col_idx_multiple_titles(simple_wb):
    head_row = simple_wb.active[1]
    # Finds the first matching column
    assert find_col_idx(head_row, ["Комментарий", "Код"]) == 0


def test_find_col_idx_whitespace_ignored(simple_wb):
    ws = simple_wb.active
    ws["E1"] = "Метод  проверки"  # double space inside
    head_row = ws[1]
    assert find_col_idx(head_row, ["Метод проверки"]) == 4


def test_find_col_idx_not_found_fail_fast(simple_wb):
    head_row = simple_wb.active[1]
    with pytest.raises(ValueError):
        find_col_idx(head_row, ["НесуществующаяКолонка"])


def test_find_col_idx_not_found_no_fail(simple_wb):
    head_row = simple_wb.active[1]
    result = find_col_idx(head_row, ["НесуществующаяКолонка"], fail_fast=False)
    assert result is None


def test_find_col_idx_find_last(simple_wb):
    ws = simple_wb.active
    ws["E1"] = "Код"  # duplicate title
    head_row = ws[1]
    assert find_col_idx(head_row, ["Код"], find_last=True) == 4
    assert find_col_idx(head_row, ["Код"], find_last=False) == 0


def test_find_col_idx_multi_header():
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "era-propvalues"
    ws["B1"] = "era-propnames"
    head_rows = [ws[1]]
    assert find_col_idx_multi_header(head_rows, ["era-propnames"]) == 1
    assert find_col_idx_multi_header(head_rows, ["era-propvalues"]) == 0


def test_find_col_idx_multi_header_not_found_fail():
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "something"
    with pytest.raises(ValueError):
        find_col_idx_multi_header([ws[1]], ["missing"])


def test_find_col_idx_multi_header_not_found_no_fail():
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "something"
    assert find_col_idx_multi_header([ws[1]], ["missing"], fail_fast=False) is None


def test_find_row_idx_found():
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Компания"
    ws["A2"] = "Имя"
    ws["A3"] = "Критичность"
    col = ws["A"]
    assert find_row_idx(col, ["Компания"]) == 0
    assert find_row_idx(col, ["Имя"]) == 1
    assert find_row_idx(col, ["Критичность"]) == 2


def test_find_row_idx_multiple_titles():
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Имя"
    ws["A2"] = "Название"
    col = ws["A"]
    # Finds the first match
    assert find_row_idx(col, ["Название", "Имя"]) == 0


def test_find_row_idx_whitespace_ignored():
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Критичность "  # trailing space
    col = ws["A"]
    assert find_row_idx(col, ["Критичность"]) == 0


def test_find_row_idx_not_found_fail_fast():
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Компания"
    with pytest.raises(ValueError):
        find_row_idx(ws["A"], ["НесуществующаяСтрока"])


def test_find_row_idx_not_found_no_fail():
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Компания"
    assert find_row_idx(ws["A"], ["НесуществующаяСтрока"], fail_fast=False) is None
