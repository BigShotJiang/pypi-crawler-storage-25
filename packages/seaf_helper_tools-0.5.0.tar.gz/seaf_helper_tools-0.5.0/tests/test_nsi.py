"""Tests for utils/nsi.py."""

import json
from pathlib import Path
from unittest.mock import MagicMock

from seaf_helper_tools.utils.nsi import _jsonata_expr, build_nsi, fetch_nsi_from_api

# ---------------------------------------------------------------------------
# _jsonata_expr
# ---------------------------------------------------------------------------


def test_jsonata_expr_simple_key() -> None:
    assert _jsonata_expr("companies") == "$.companies"


def test_jsonata_expr_dotted_key() -> None:
    assert (
        _jsonata_expr("seaf.change.requirements.dzo")
        == "$.`seaf.change.requirements.dzo`"
    )


def test_jsonata_expr_no_dots() -> None:
    assert _jsonata_expr("simple") == "$.simple"


# ---------------------------------------------------------------------------
# fetch_nsi_from_api
# ---------------------------------------------------------------------------


def _make_client(responses: dict[str, object]) -> MagicMock:
    """Build a mock SeafJsonataCall that returns JSON for given expressions."""
    client = MagicMock()

    def eval_jsonata(expr: str) -> str:
        for key, value in responses.items():
            if key in expr:
                return json.dumps(value)
        return "null"

    client.eval_jsonata.side_effect = eval_jsonata
    return client


def test_fetch_nsi_from_api_returns_keyed_dict() -> None:
    client = _make_client({"companies": {"acme": {"title": "ACME Corp"}}})
    result = fetch_nsi_from_api(client, ["companies"])
    assert result == {"companies": {"acme": {"title": "ACME Corp"}}}


def test_fetch_nsi_from_api_dotted_key() -> None:
    req_data = {"sber.standards.REQ-1": {"statement": "Some requirement"}}
    client = _make_client({"seaf.change.requirements.dzo": req_data})
    result = fetch_nsi_from_api(client, ["seaf.change.requirements.dzo"])
    assert result["seaf.change.requirements.dzo"] == req_data


def test_fetch_nsi_from_api_null_response_skipped() -> None:
    client = MagicMock()
    client.eval_jsonata.return_value = "null"
    result = fetch_nsi_from_api(client, ["companies"])
    assert result == {}


def test_fetch_nsi_from_api_exception_is_logged_not_raised() -> None:
    client = MagicMock()
    client.eval_jsonata.side_effect = RuntimeError("connection failed")
    # Should not raise — logs warning and returns empty dict
    result = fetch_nsi_from_api(client, ["companies"])
    assert result == {}


def test_fetch_nsi_from_api_multiple_keys() -> None:
    client = _make_client(
        {
            "companies": {"c1": {"title": "Corp 1"}},
            "seaf.change.requirements.dzo": {"req1": {"statement": "Req text"}},
        }
    )
    result = fetch_nsi_from_api(client, ["companies", "seaf.change.requirements.dzo"])
    assert "companies" in result
    assert "seaf.change.requirements.dzo" in result


# ---------------------------------------------------------------------------
# build_nsi
# ---------------------------------------------------------------------------


def test_build_nsi_local_only(tmp_path: Path) -> None:
    yaml_file = tmp_path / "data.yaml"
    yaml_file.write_text("companies:\n  acme:\n    title: ACME\n", encoding="utf-8")

    result = build_nsi(extra_data=[yaml_file])
    assert result["companies"]["acme"]["title"] == "ACME"


def test_build_nsi_remote_only() -> None:
    client = _make_client({"companies": {"acme": {"title": "ACME Corp"}}})
    result = build_nsi(extra_data=[], jsonata_client=client, remote_keys=["companies"])
    assert result["companies"]["acme"]["title"] == "ACME Corp"


def test_build_nsi_merges_local_and_remote(tmp_path: Path) -> None:
    yaml_file = tmp_path / "local.yaml"
    yaml_file.write_text(
        "companies:\n  local_co:\n    title: Local\n", encoding="utf-8"
    )
    client = _make_client({"companies": {"remote_co": {"title": "Remote"}}})

    result = build_nsi(
        extra_data=[yaml_file], jsonata_client=client, remote_keys=["companies"]
    )
    # Both companies present after merge
    assert "local_co" in result["companies"]
    assert "remote_co" in result["companies"]


def test_build_nsi_no_client_no_remote_keys() -> None:
    result = build_nsi(extra_data=[], jsonata_client=None, remote_keys=None)
    assert result == {}


def test_build_nsi_client_without_remote_keys() -> None:
    client = MagicMock()
    result = build_nsi(extra_data=[], jsonata_client=client, remote_keys=None)
    client.eval_jsonata.assert_not_called()
    assert result == {}


def test_build_nsi_empty_extra_data_with_remote() -> None:
    client = _make_client({"companies": {"c": {"title": "C"}}})
    result = build_nsi(extra_data=[], jsonata_client=client, remote_keys=["companies"])
    assert result["companies"]["c"]["title"] == "C"
