# This file was generated automatically. Do not edit it directly.
from typing import (
    Any,
    Dict,
    List,
    Literal,
    NotRequired,
    Optional,
    TypedDict,
    Union,
    Unpack,
    cast,
)
from urllib.parse import quote

from fountain_life_service_clients._base_client import (
    AlphaConfig,
    AlphaResponse,
    BaseClient,
)


class InvokeBasicAgentRequest(TypedDict):
    input: str
    model_id: NotRequired[str]


class InvokeBasicAgentResponse(TypedDict):
    output: str


ScheduleDelayHours = int


CooldownSeconds = int


class ListIftttRulesResponseItem(TypedDict):
    id: str
    account_id: str
    channel: str
    scope: NotRequired[Optional[str]]
    condition_description: str
    evaluation_mode: Literal["llm", "static"]
    static_condition: NotRequired[Optional[str]]
    schedule_delay_hours: NotRequired[Optional[ScheduleDelayHours]]
    action: str
    action_params: Dict[str, Any]
    visibility: Literal["opaque", "transparent"]
    status: Literal["active", "inactive"]
    priority: float
    category: NotRequired[Optional[str]]
    cooldown_seconds: NotRequired[Optional[CooldownSeconds]]
    created: str
    created_by: str
    edited_by: str
    last_edited: str


ListIftttRulesResponse = List[ListIftttRulesResponseItem]


class CreateIftttRuleRequest(TypedDict):
    channel: Literal[
        "fountainmembersagent:member-message",
        "fountaincliniciansagent:clinician-message",
        "fountainclinicanpopulationagent:population-message",
        "patient_change_stream:create",
        "patient_change_stream:update",
        "patient_change_stream:delete",
        "zoom_integration:appointment-event",
    ]
    scope: NotRequired[
        Optional[
            Literal[
                "document_reference",
                "clinical_impression",
                "questionnaire_response",
                "communication",
                "list",
                "appointment",
                "observation:survey_response",
                "medication_request",
                "observation:member-app",
                "send_message",
                "appointment_linked",
                "appointment_cannot_link_to_member",
            ]
        ]
    ]
    condition_description: str
    evaluation_mode: Literal["llm", "static"]
    static_condition: NotRequired[Optional[str]]
    schedule_delay_hours: NotRequired[Optional[ScheduleDelayHours]]
    action: Literal[
        "tool#update_preferences",
        "tool#send_elation_message",
        "tool#slack_post_message",
        "tool#create_zori_rule",
        "tool#update_zori_rule",
        "tool#delete_zori_rule",
        "tool#list_zori_rules",
        "tool#message_care_team",
        "tool#fatal_log",
        "tool#create_async_task",
        "tool#send_member_notification",
    ]
    action_params: Dict[str, Any]
    visibility: Literal["opaque", "transparent"]
    status: Literal["active", "inactive"]
    priority: int
    category: NotRequired[
        Optional[Literal["self_harm", "medication_refill", "critical_finding"]]
    ]
    cooldown_seconds: NotRequired[Optional[CooldownSeconds]]


class CreateIftttRuleResponse(TypedDict):
    id: str
    account_id: str
    channel: str
    scope: NotRequired[Optional[str]]
    condition_description: str
    evaluation_mode: Literal["llm", "static"]
    static_condition: NotRequired[Optional[str]]
    schedule_delay_hours: NotRequired[Optional[ScheduleDelayHours]]
    action: str
    action_params: Dict[str, Any]
    visibility: Literal["opaque", "transparent"]
    status: Literal["active", "inactive"]
    priority: float
    category: NotRequired[Optional[str]]
    cooldown_seconds: NotRequired[Optional[CooldownSeconds]]
    created: str
    created_by: str
    edited_by: str
    last_edited: str


class PatchIftttRuleRequest(TypedDict):
    channel: NotRequired[
        Literal[
            "fountainmembersagent:member-message",
            "fountaincliniciansagent:clinician-message",
            "fountainclinicanpopulationagent:population-message",
            "patient_change_stream:create",
            "patient_change_stream:update",
            "patient_change_stream:delete",
            "zoom_integration:appointment-event",
        ]
    ]
    scope: NotRequired[
        Optional[
            Literal[
                "document_reference",
                "clinical_impression",
                "questionnaire_response",
                "communication",
                "list",
                "appointment",
                "observation:survey_response",
                "medication_request",
                "observation:member-app",
                "send_message",
                "appointment_linked",
                "appointment_cannot_link_to_member",
            ]
        ]
    ]
    condition_description: NotRequired[str]
    evaluation_mode: NotRequired[Literal["llm", "static"]]
    static_condition: NotRequired[Optional[str]]
    schedule_delay_hours: NotRequired[Optional[ScheduleDelayHours]]
    action: NotRequired[
        Literal[
            "tool#update_preferences",
            "tool#send_elation_message",
            "tool#slack_post_message",
            "tool#create_zori_rule",
            "tool#update_zori_rule",
            "tool#delete_zori_rule",
            "tool#list_zori_rules",
            "tool#message_care_team",
            "tool#fatal_log",
            "tool#create_async_task",
            "tool#send_member_notification",
        ]
    ]
    action_params: NotRequired[Dict[str, Any]]
    visibility: NotRequired[Literal["opaque", "transparent"]]
    status: NotRequired[Literal["active", "inactive"]]
    priority: NotRequired[int]
    category: NotRequired[
        Optional[Literal["self_harm", "medication_refill", "critical_finding"]]
    ]
    cooldown_seconds: NotRequired[Optional[CooldownSeconds]]


class PatchIftttRuleResponse(TypedDict):
    id: str
    account_id: str
    channel: str
    scope: NotRequired[Optional[str]]
    condition_description: str
    evaluation_mode: Literal["llm", "static"]
    static_condition: NotRequired[Optional[str]]
    schedule_delay_hours: NotRequired[Optional[ScheduleDelayHours]]
    action: str
    action_params: Dict[str, Any]
    visibility: Literal["opaque", "transparent"]
    status: Literal["active", "inactive"]
    priority: float
    category: NotRequired[Optional[str]]
    cooldown_seconds: NotRequired[Optional[CooldownSeconds]]
    created: str
    created_by: str
    edited_by: str
    last_edited: str


class DeleteIftttRuleResponse(TypedDict):
    id: str
    account_id: str
    channel: str
    scope: NotRequired[Optional[str]]
    condition_description: str
    evaluation_mode: Literal["llm", "static"]
    static_condition: NotRequired[Optional[str]]
    schedule_delay_hours: NotRequired[Optional[ScheduleDelayHours]]
    action: str
    action_params: Dict[str, Any]
    visibility: Literal["opaque", "transparent"]
    status: Literal["active", "inactive"]
    priority: float
    category: NotRequired[Optional[str]]
    cooldown_seconds: NotRequired[Optional[CooldownSeconds]]
    created: str
    created_by: str
    edited_by: str
    last_edited: str


class GetIftttRuleOptionsResponse(TypedDict):
    scopes_by_channel: Dict[str, List[str]]
    actions_by_channel_scope: Dict[str, Dict[str, List[str]]]


class ListZoriAuditTasksParams(TypedDict):
    limit: NotRequired[int]
    agent: NotRequired[str]


class ListZoriAuditTasksResponseItem(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


ListZoriAuditTasksResponse = List[ListZoriAuditTasksResponseItem]


class ListZoriAuditRuleActionsParams(TypedDict):
    limit: NotRequired[int]


class ListZoriAuditRuleActionsResponseItem(TypedDict):
    account_id: str
    subject_id: str
    category: str
    action: str
    timestamp: str
    channel: str
    status: Literal["Queued", "Completed", "Rejected"]
    action_params: Dict[str, Any]
    rule_id: Optional[str]
    ttl: float


ListZoriAuditRuleActionsResponse = List[ListZoriAuditRuleActionsResponseItem]


class Members(TypedDict):
    scheduled_for_ms: NotRequired[Optional[float]]
    status: NotRequired[Optional[str]]
    task_id: NotRequired[Optional[str]]


class Internal(TypedDict):
    scheduled_for_ms: NotRequired[Optional[float]]
    status: NotRequired[Optional[str]]
    task_id: NotRequired[Optional[str]]


class GetKnowledgeBaseSyncStateResponse(TypedDict):
    members: Members
    internal: Internal


class PostKnowledgeBaseSyncNowRequest(TypedDict):
    project_id: str
    kind: NotRequired[Literal["members", "internal", "all"]]


class members(TypedDict):
    ingestion_job_id: str


class internal(TypedDict):
    ingestion_job_id: str


class PostKnowledgeBaseSyncNowResponse(TypedDict):
    members: Optional[members]
    internal: Optional[internal]


class InvokeHealthSummaryAgentRequest1(TypedDict):
    version: Literal["v1"]
    subject_id: str
    project_id: str
    mutate: NotRequired[bool]
    skip_findings_summaries: NotRequired[bool]
    requested_summaries: NotRequired[List[str]]
    skip_summaries: NotRequired[bool]
    skip_action_items: NotRequired[bool]


class Instruction(TypedDict):
    summary_type: str
    instructions: str


class InvokeHealthSummaryAgentRequest2(TypedDict):
    version: Literal["v2"]
    subject_id: str
    project_id: str
    crd_id: str
    model_id: NotRequired[str]
    mutate: NotRequired[bool]
    requested_summaries: NotRequired[List[str]]
    skip_summaries: NotRequired[bool]
    skip_action_items: NotRequired[bool]
    instructions: NotRequired[List[Instruction]]


InvokeHealthSummaryAgentRequest = Union[
    InvokeHealthSummaryAgentRequest1, InvokeHealthSummaryAgentRequest2
]


class InvokeHealthSummaryAgentResponse(TypedDict):
    task_id: str


class GetHealthSummaryInvocationsParams(TypedDict):
    subject_id: str


class GetHealthSummaryInvocationsResponseItem(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


GetHealthSummaryInvocationsResponse = List[GetHealthSummaryInvocationsResponseItem]


class GetHealthSummaryScheduledTaskResponse(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


class FlushHealthSummaryScheduledTaskRequest(TypedDict):
    pass


class InvokeAnnotatedResultsAgentRequest(TypedDict):
    project_id: str
    subject_id: str
    model_id: NotRequired[str]


class InvokeAnnotatedResultsAgentResponse(TypedDict):
    task_id: str


class InvokeDocumentExtractionV2Request(TypedDict):
    subject_id: str
    project_id: str
    source_document_reference_id: str
    include_clinic_only: bool
    reason: NotRequired[Optional[str]]
    force_regenerate: bool
    requested_artifact_version: NotRequired[Optional[str]]


class InvokeDocumentExtractionV2Response(TypedDict):
    task_id: str


CandidateFactCount = int


ErrorCount = int


FhirArtifactCount = int


FhirProjectionCount = int


NumPages = int


TotalEntries = int


ProcessedEntries = int


SkippedEntries = int


TotalPages = int


ProcessedPages = int


SkippedPages = int


TextEntryCount = int


ImageEntryCount = int


BatchCount = int


CompletedChunkCount = int


FailedChunkCount = int


class Output(TypedDict):
    artifact_version: NotRequired[Optional[str]]
    candidate_fact_count: NotRequired[Optional[CandidateFactCount]]
    error_count: NotRequired[Optional[ErrorCount]]
    fhir_artifact_count: NotRequired[Optional[FhirArtifactCount]]
    failure_reason: NotRequired[Optional[str]]
    fhir_projection_count: NotRequired[Optional[FhirProjectionCount]]
    fhir_projection_status: NotRequired[Optional[str]]
    num_pages: NotRequired[Optional[NumPages]]
    total_entries: NotRequired[Optional[TotalEntries]]
    processed_entries: NotRequired[Optional[ProcessedEntries]]
    skipped_entries: NotRequired[Optional[SkippedEntries]]
    total_pages: NotRequired[Optional[TotalPages]]
    processed_pages: NotRequired[Optional[ProcessedPages]]
    skipped_pages: NotRequired[Optional[SkippedPages]]
    text_entry_count: NotRequired[Optional[TextEntryCount]]
    image_entry_count: NotRequired[Optional[ImageEntryCount]]
    batch_count: NotRequired[Optional[BatchCount]]
    completed_chunk_count: NotRequired[Optional[CompletedChunkCount]]
    failed_chunk_count: NotRequired[Optional[FailedChunkCount]]
    partial: NotRequired[Optional[bool]]
    truncated: NotRequired[Optional[bool]]
    source_document_reference_id: NotRequired[Optional[str]]
    summary_available: NotRequired[Optional[bool]]


class GetDocumentExtractionV2InvocationResponse(TypedDict):
    task_id: str
    status: Literal[
        "scheduled",
        "pending",
        "processing",
        "waiting",
        "failed",
        "completed",
        "expired",
    ]
    created: float
    subject_id: str
    project_id: NotRequired[Optional[str]]
    source_document_reference_id: NotRequired[Optional[str]]
    reason: NotRequired[Optional[str]]
    output: NotRequired[Optional[Output]]


class ListDocumentExtractionV2TasksParams(TypedDict):
    subject_id: str
    project_id: NotRequired[str]
    limit: NotRequired[int]


class output(TypedDict):
    artifact_version: NotRequired[Optional[str]]
    candidate_fact_count: NotRequired[Optional[CandidateFactCount]]
    error_count: NotRequired[Optional[ErrorCount]]
    fhir_artifact_count: NotRequired[Optional[FhirArtifactCount]]
    failure_reason: NotRequired[Optional[str]]
    fhir_projection_count: NotRequired[Optional[FhirProjectionCount]]
    fhir_projection_status: NotRequired[Optional[str]]
    num_pages: NotRequired[Optional[NumPages]]
    total_entries: NotRequired[Optional[TotalEntries]]
    processed_entries: NotRequired[Optional[ProcessedEntries]]
    skipped_entries: NotRequired[Optional[SkippedEntries]]
    total_pages: NotRequired[Optional[TotalPages]]
    processed_pages: NotRequired[Optional[ProcessedPages]]
    skipped_pages: NotRequired[Optional[SkippedPages]]
    text_entry_count: NotRequired[Optional[TextEntryCount]]
    image_entry_count: NotRequired[Optional[ImageEntryCount]]
    batch_count: NotRequired[Optional[BatchCount]]
    completed_chunk_count: NotRequired[Optional[CompletedChunkCount]]
    failed_chunk_count: NotRequired[Optional[FailedChunkCount]]
    partial: NotRequired[Optional[bool]]
    truncated: NotRequired[Optional[bool]]
    source_document_reference_id: NotRequired[Optional[str]]
    summary_available: NotRequired[Optional[bool]]


class Task(TypedDict):
    task_id: str
    status: Literal[
        "scheduled",
        "pending",
        "processing",
        "waiting",
        "failed",
        "completed",
        "expired",
    ]
    created: float
    subject_id: str
    project_id: NotRequired[Optional[str]]
    source_document_reference_id: NotRequired[Optional[str]]
    reason: NotRequired[Optional[str]]
    output: NotRequired[Optional[output]]


class ListDocumentExtractionV2TasksResponse(TypedDict):
    tasks: List[Task]


class ProvideMessageFeedbackRequest(TypedDict):
    agent_name: str
    trace_id: str
    feedback: NotRequired[str]
    score: NotRequired[float]
    score_name: NotRequired[str]
    emoji: NotRequired[str]


class InvokeActionPlanNudgeRequest(TypedDict):
    account_id: str
    project_id: str
    subject_id: str
    user_id: str
    correlation_id: NotRequired[str]


class InvokeActionPlanNudgeResponse(TypedDict):
    subject_id: str
    nudge: Dict[str, Any]


class InvokeActionPlanRequest(TypedDict):
    subject_id: str
    project_id: str


class InvokeActionPlanResponse(TypedDict):
    task_id: str


class InvokeTemplateRequest(TypedDict):
    subject_id: str
    project_id: str
    template_id: str
    instructions: NotRequired[str]
    tools_loop: NotRequired[bool]
    model_id: NotRequired[str]


class InvokeTemplateResponse(TypedDict):
    task_id: str


class GetTemplateAgentInvocationsParams(TypedDict):
    subject_id: str


class GetTemplateAgentInvocationsResponseItem(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


GetTemplateAgentInvocationsResponse = List[GetTemplateAgentInvocationsResponseItem]


class GetTemplateAgentInvocationResponse(TypedDict):
    created: float
    expires: NotRequired[float]
    id: str
    scheduled: NotRequired[float]
    status: Literal[
        "scheduled", "pending", "processing", "failed", "completed", "expired"
    ]
    accountId: str
    agent: str
    agentInput: Dict[str, Any]
    subjectId: str


class GetAgentTokenResponse(TypedDict):
    AccessKeyId: str
    SecretAccessKey: str
    SessionToken: str
    Expiration: str


class ValidateFileOwnershipRequest(TypedDict):
    subject_id: str
    file_id: str
    project_id: str
    document_reference_id: str


class Result(TypedDict):
    status: Literal["pending", "valid", "invalid", "inconclusive"]
    reasoning: str
    reasoning_code: Literal[
        "matched-identity",
        "mismatched-identity",
        "insufficient-data",
        "undefined",
        "unsupported-file-type",
    ]


class ValidateFileOwnershipResponse(TypedDict):
    subject_id: str
    file_id: str
    document_reference_id: str
    result: Result


class CreateProviderTokenRequest(TypedDict):
    subject_id: str
    project_id: str
    voice_name: NotRequired[str]


class CreateProviderTokenResponse(TypedDict):
    name: str
    model: str


class GetSimpleMemberContextParams(TypedDict):
    model: str


class GetSimpleMemberContextResponse(TypedDict):
    context_text: str


class Model(TypedDict):
    model_id: str
    model_label: str


class ListModelsResponse(TypedDict):
    models: List[Model]


class GetWearableDataResponse(TypedDict):
    wearable_data: str


class SyncRoutesRequest(TypedDict):
    pass


class SyncRoutesResponse(TypedDict):
    added: float
    removed: float


class RunRouterExperimentRequest(TypedDict):
    dataset_name: str
    experiment_name: NotRequired[str]
    run_metadata: NotRequired[Dict[str, Any]]


class RunRouterExperimentResponse(TypedDict):
    experiment_name: str
    total_items: float
    successful_items: float
    failed_items: float
    item_level_accuracy: float
    run_url: str


class AgentsApiServiceClient(BaseClient):
    def __init__(self, **cfg: Unpack[AlphaConfig]):
        kwargs = {"target": "lambda://agents-api-service-v2:deployed", **(cfg or {})}
        super().__init__(**kwargs)

    async def invoke_basic_agent(self, body: InvokeBasicAgentRequest):
        """Invoke the basic agent"""
        res = await self.client.request(
            path="/v1/agents-v2/basic/invoke", method="POST", body=cast(dict, body)
        )
        return cast(AlphaResponse[InvokeBasicAgentResponse], res)

    async def list_ifttt_rules(self):
        """List all IFTTT rules for the caller's account."""
        res = await self.client.request(path="/v1/agents-v2/ifttt/rules", method="GET")
        return cast(AlphaResponse[ListIftttRulesResponse], res)

    async def create_ifttt_rule(self, body: CreateIftttRuleRequest):
        """Create an IFTTT rule for the caller's account."""
        res = await self.client.request(
            path="/v1/agents-v2/ifttt/rules", method="POST", body=cast(dict, body)
        )
        return cast(AlphaResponse[CreateIftttRuleResponse], res)

    async def patch_ifttt_rule(self, rule_id: str, body: PatchIftttRuleRequest):
        """Patch an existing IFTTT rule for the caller's account."""
        res = await self.client.request(
            path=f"/v1/agents-v2/ifttt/rules/{quote(rule_id)}",
            method="PATCH",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[PatchIftttRuleResponse], res)

    async def delete_ifttt_rule(self, rule_id: str):
        """Soft-delete an IFTTT rule by setting its status to inactive."""
        res = await self.client.request(
            path=f"/v1/agents-v2/ifttt/rules/{quote(rule_id)}", method="DELETE"
        )
        return cast(AlphaResponse[DeleteIftttRuleResponse], res)

    async def get_ifttt_rule_options(self):
        """Return IFTTT rule form options (scopes and actions by channel and scope) derived from supported tool factories."""
        res = await self.client.request(
            path="/v1/agents-v2/ifttt/rule-options", method="GET"
        )
        return cast(AlphaResponse[GetIftttRuleOptionsResponse], res)

    async def list_zori_audit_tasks(self, params: ListZoriAuditTasksParams):
        """List async tasks for account-level Zori audit (newest first)."""
        res = await self.client.request(
            path="/v1/agents-v2/zori-audit/tasks",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[ListZoriAuditTasksResponse], res)

    async def list_zori_audit_rule_actions(
        self, params: ListZoriAuditRuleActionsParams
    ):
        """List rule action records for account-level Zori audit (newest first)."""
        res = await self.client.request(
            path="/v1/agents-v2/zori-audit/rule-actions",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[ListZoriAuditRuleActionsResponse], res)

    async def get_knowledge_base_sync_state(self):
        """Return debounced Bedrock KB ingestion task state per KB (members vs internal)."""
        res = await self.client.request(
            path="/v1/agents-v2/knowledge-base/sync-state", method="GET"
        )
        return cast(AlphaResponse[GetKnowledgeBaseSyncStateResponse], res)

    async def post_knowledge_base_sync_now(self, body: PostKnowledgeBaseSyncNowRequest):
        """Start Bedrock StartIngestionJob for the requested KB data source(s)."""
        res = await self.client.request(
            path="/v1/agents-v2/knowledge-base/sync-now",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[PostKnowledgeBaseSyncNowResponse], res)

    async def invoke_health_summary_agent(self, body: InvokeHealthSummaryAgentRequest):
        """Invoke the health summary agent"""
        res = await self.client.request(
            path="/v1/agents-v2/health-summary/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeHealthSummaryAgentResponse], res)

    async def get_health_summary_invocations(
        self, params: GetHealthSummaryInvocationsParams
    ):
        """Get the health summary invocations"""
        res = await self.client.request(
            path="/v1/agents-v2/health-summary/invocations",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetHealthSummaryInvocationsResponse], res)

    async def get_health_summary_scheduled_task(self, task_id: str):
        """Get a health summary scheduled task"""
        res = await self.client.request(
            path=f"/v1/agents-v2/health-summary/invocations/{quote(task_id)}",
            method="GET",
        )
        return cast(AlphaResponse[GetHealthSummaryScheduledTaskResponse], res)

    async def flush_health_summary_scheduled_task(
        self, task_id: str, body: FlushHealthSummaryScheduledTaskRequest
    ):
        """Flush the health summary scheduled task so it is run immediately"""
        await self.client.request(
            path=f"/v1/agents-v2/health-summary/scheduled/{quote(task_id)}",
            method="PATCH",
            body=cast(dict, body),
        )

    async def invoke_annotated_results_agent(
        self, body: InvokeAnnotatedResultsAgentRequest
    ):
        """Invoke the annotated results agent"""
        res = await self.client.request(
            path="/v1/private/agents-v2/annotated-results/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeAnnotatedResultsAgentResponse], res)

    async def invoke_document_extraction_v2(
        self, body: InvokeDocumentExtractionV2Request
    ):
        """Enqueue a single-document document-extraction-v2 run and return its task id."""
        res = await self.client.request(
            path="/v1/agents-v2/document-extraction-v2/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeDocumentExtractionV2Response], res)

    async def get_document_extraction_v2_invocation(self, task_id: str):
        """Read a document-extraction-v2 task's status plus safe output metadata."""
        res = await self.client.request(
            path=f"/v1/agents-v2/document-extraction-v2/invocations/{quote(task_id)}",
            method="GET",
        )
        return cast(AlphaResponse[GetDocumentExtractionV2InvocationResponse], res)

    async def list_document_extraction_v2_tasks(
        self, params: ListDocumentExtractionV2TasksParams
    ):
        """List active and recent document-extraction-v2 tasks for one subject."""
        res = await self.client.request(
            path="/v1/agents-v2/document-extraction-v2/tasks",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[ListDocumentExtractionV2TasksResponse], res)

    async def provide_message_feedback(self, body: ProvideMessageFeedbackRequest):
        """Provide feedback on a message"""
        await self.client.request(
            path="/v1/agents-v2/feedback", method="POST", body=cast(dict, body)
        )

    async def invoke_action_plan_nudge(self, body: InvokeActionPlanNudgeRequest):
        """Invoke the action plan nudge agent"""
        res = await self.client.request(
            path="/v1/private/agents-v2/action-plan-nudge/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeActionPlanNudgeResponse], res)

    async def invoke_action_plan(self, body: InvokeActionPlanRequest):
        """Invoke the action plan agent"""
        res = await self.client.request(
            path="/v1/agents-v2/action-plan/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeActionPlanResponse], res)

    async def invoke_template(self, body: InvokeTemplateRequest):
        """Invoke the template agent"""
        res = await self.client.request(
            path="/v1/agents-v2/template-agent/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[InvokeTemplateResponse], res)

    async def get_template_agent_invocations(
        self, params: GetTemplateAgentInvocationsParams
    ):
        """Get template agent invocations for a subject"""
        res = await self.client.request(
            path="/v1/agents-v2/template-agent/invocations",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetTemplateAgentInvocationsResponse], res)

    async def get_template_agent_invocation(self, task_id: str):
        """Get a template agent invocation by task id"""
        res = await self.client.request(
            path=f"/v1/agents-v2/template-agent/invocations/{quote(task_id)}",
            method="GET",
        )
        return cast(AlphaResponse[GetTemplateAgentInvocationResponse], res)

    async def get_agent_token(self):
        """Get an agent token for the current user"""
        res = await self.client.request(path="/v1/agents-v2/token", method="GET")
        return cast(AlphaResponse[GetAgentTokenResponse], res)

    async def validate_file_ownership(self, body: ValidateFileOwnershipRequest):
        """Validate file ownership"""
        res = await self.client.request(
            path="/v1/private/agents-v2/validate-ownership/invoke",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[ValidateFileOwnershipResponse], res)

    async def create_provider_token(
        self, provider_type: str, body: CreateProviderTokenRequest
    ):
        """Create an ephemeral provider token for the current user"""
        res = await self.client.request(
            path=f"/v1/agents-v2/providers/{quote(provider_type)}/token",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[CreateProviderTokenResponse], res)

    async def get_simple_member_context(
        self, project_id: str, params: GetSimpleMemberContextParams
    ):
        """Get simple member context for LLM use. Returns the member
        context text formatted and truncated for the specified model. The subject_id is
        derived from the authenticated user's ID."""
        res = await self.client.request(
            path=f"/v1/agents-v2/projects/{quote(project_id)}/simple-member-context",
            method="GET",
            params=cast(dict, params),
        )
        return cast(AlphaResponse[GetSimpleMemberContextResponse], res)

    async def list_models(self):
        """List exposed foundation models"""
        res = await self.client.request(path="/v1/agents-v2/models", method="GET")
        return cast(AlphaResponse[ListModelsResponse], res)

    async def get_wearable_data(self, project_id: str):
        """Get member wearable data (Apple Health, Google Fit, etc.) formatted for LLM consumption."""
        res = await self.client.request(
            path=f"/v1/agents-v2/projects/{quote(project_id)}/wearable-data",
            method="GET",
        )
        return cast(AlphaResponse[GetWearableDataResponse], res)

    async def sync_routes(self, body: SyncRoutesRequest):
        """Sync routes in persistence storage"""
        res = await self.client.request(
            path="/v1/private/agents-v2/routing/sync",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[SyncRoutesResponse], res)

    async def run_router_experiment(self, body: RunRouterExperimentRequest):
        """Run a routing experiment against a dataset"""
        res = await self.client.request(
            path="/v1/private/agents-v2/experiments/run-router-experiment",
            method="POST",
            body=cast(dict, body),
        )
        return cast(AlphaResponse[RunRouterExperimentResponse], res)
