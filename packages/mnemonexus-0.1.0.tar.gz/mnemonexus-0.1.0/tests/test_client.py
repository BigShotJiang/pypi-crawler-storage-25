"""Smoke + unit tests para o SDK mnemonexus."""
from __future__ import annotations

import pytest
import respx
from httpx import Response

from mnemonexus import AsyncNexus, AuthError, NotFoundError, ValidationError


pytestmark = pytest.mark.asyncio


@respx.mock
async def test_search_returns_query_result():
    respx.post("http://api.test/api/v1/query").mock(
        return_value=Response(200, json={"answer": "ok", "sources": [], "mode": "hybrid"})
    )
    nexus = AsyncNexus(api_url="http://api.test", token="t")
    r = await nexus.search("hi")
    assert r.answer == "ok"
    assert r.mode == "hybrid"


@respx.mock
async def test_add_posts_to_ingest():
    route = respx.post("http://api.test/api/v1/ingest").mock(
        return_value=Response(202, json={"status": "queued", "slug": "abc"})
    )
    nexus = AsyncNexus(api_url="http://api.test", token="t")
    out = await nexus.add("hello", domain="memory")
    assert route.called
    assert out["slug"] == "abc"


@respx.mock
async def test_auth_error_raises_AuthError():
    respx.post("http://api.test/api/v1/query").mock(
        return_value=Response(401, json={"message": "Unauthenticated."})
    )
    nexus = AsyncNexus(api_url="http://api.test")
    with pytest.raises(AuthError):
        await nexus.search("hi")


@respx.mock
async def test_not_found_raises_NotFoundError():
    respx.get("http://api.test/api/v1/pages/missing").mock(
        return_value=Response(404, json={"message": "Not found."})
    )
    nexus = AsyncNexus(api_url="http://api.test", token="t")
    with pytest.raises(NotFoundError):
        await nexus.get("missing")


@respx.mock
async def test_validation_error_raises_ValidationError():
    respx.post("http://api.test/api/v1/lessons").mock(
        return_value=Response(422, json={"message": "title required"})
    )
    nexus = AsyncNexus(api_url="http://api.test", token="t")
    with pytest.raises(ValidationError):
        await nexus.lesson(title="", body="")


@respx.mock
async def test_lesson_twice_rule_response():
    respx.post("http://api.test/api/v1/lessons").mock(
        return_value=Response(
            200,
            json={
                "status": "twice_rule_triggered",
                "lesson": {"id": 7, "title": "x", "body": "y", "occurrence_count": 2},
            },
        )
    )
    nexus = AsyncNexus(api_url="http://api.test", token="t")
    r = await nexus.lesson(title="x", body="y")
    assert r.id == 7
    assert r.occurrence_count == 2


@respx.mock
async def test_entity_graph_normalizes_payload():
    respx.get("http://api.test/api/v1/entities/foxpulse/graph").mock(
        return_value=Response(
            200,
            json={
                "root": {"slug": "foxpulse", "name": "FoxPulse"},
                "nodes": [{"slug": "foxpulse"}, {"slug": "luciano"}],
                "edges": [{"from_entity_slug": "luciano", "to_entity_slug": "foxpulse", "kind": "creator"}],
            },
        )
    )
    nexus = AsyncNexus(api_url="http://api.test", token="t")
    g = await nexus.entity("foxpulse").graph()
    assert g.root.slug == "foxpulse"
    assert len(g.nodes) == 2
    assert g.edges[0].kind == "creator"


@respx.mock
async def test_token_sent_as_bearer():
    route = respx.post("http://api.test/api/v1/query").mock(
        return_value=Response(200, json={"answer": "x", "sources": []})
    )
    nexus = AsyncNexus(api_url="http://api.test", token="abc")
    await nexus.search("hi")
    assert route.calls.last.request.headers["authorization"] == "Bearer abc"
