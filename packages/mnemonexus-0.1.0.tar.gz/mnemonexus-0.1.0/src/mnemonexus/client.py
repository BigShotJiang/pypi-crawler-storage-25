"""mnemonexus Python client — async-first with a sync wrapper.

Covers paridade mem0 (add/search/update/delete/history) + the NEXUS-only
operations: compile, extract_facts, lesson, decision, compact_session,
entity().graph(). All HTTP is httpx; types come from pydantic models.
"""
from __future__ import annotations

import asyncio
from typing import Any, Iterable

import httpx

from .errors import NexusError, raise_for_status
from .models import (
    Decision,
    Entity,
    EntityGraph,
    EntityRelation,
    FactExtractionResult,
    Lesson,
    Memory,
    QueryResult,
    Session,
)

_DEFAULT_TIMEOUT = 30.0
_DEFAULT_RETRIES = 2


class _EntityScope:
    """Fluent helper returned by ``nexus.entity(slug)``."""

    def __init__(self, client: "AsyncNexus", slug: str):
        self._client = client
        self._slug = slug

    async def card(self) -> Entity:
        return await self._client._get_entity(self._slug)

    async def graph(self) -> EntityGraph:
        return await self._client._get_entity_graph(self._slug)

    async def relations(self) -> list[EntityRelation]:
        return await self._client._get_entity_relations(self._slug)


class _EntityScopeSync:
    def __init__(self, client: "Nexus", slug: str):
        self._client = client
        self._slug = slug

    def card(self) -> Entity:
        return self._client._run(self._client._async._get_entity(self._slug))

    def graph(self) -> EntityGraph:
        return self._client._run(self._client._async._get_entity_graph(self._slug))

    def relations(self) -> list[EntityRelation]:
        return self._client._run(self._client._async._get_entity_relations(self._slug))


class AsyncNexus:
    """Async client for the mnemonexus REST API."""

    def __init__(
        self,
        api_url: str = "http://localhost:8080",
        token: str | None = None,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        retries: int = _DEFAULT_RETRIES,
        client: httpx.AsyncClient | None = None,
    ):
        self._base = api_url.rstrip("/") + "/api/v1"
        self._token = token
        self._timeout = timeout
        self._retries = max(0, retries)
        self._owns_client = client is None
        self._http = client or httpx.AsyncClient(timeout=timeout)

    async def __aenter__(self) -> "AsyncNexus":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._owns_client:
            await self._http.aclose()

    # ── Auth helpers ────────────────────────────────────────────────────────
    async def login(self, email: str, password: str) -> str:
        """Authenticate via Sanctum and store the token on the client."""
        data = await self._request("POST", "/auth/login", json={"email": email, "password": password})
        token = data.get("token") or data.get("access_token")
        if not token:
            raise NexusError("login succeeded but no token in response", body=data)
        self._token = token
        return token

    # ── mem0 paridade ───────────────────────────────────────────────────────
    async def add(
        self,
        content: str,
        *,
        title: str | None = None,
        domain: str = "memory",
        source_type: str = "text",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"content": content, "domain": domain, "source_type": source_type}
        if title is not None:
            payload["title"] = title
        if metadata is not None:
            payload["metadata"] = metadata
        return await self._request("POST", "/ingest", json=payload)

    async def search(
        self,
        query: str,
        *,
        domain: str | None = None,
        limit: int = 5,
        mode: str = "hybrid",
        history: list[dict[str, str]] | None = None,
    ) -> QueryResult:
        payload: dict[str, Any] = {"query": query, "limit": limit, "mode": mode}
        if domain:
            payload["domain"] = domain
        if history:
            payload["history"] = history
        data = await self._request("POST", "/query", json=payload)
        return QueryResult.model_validate(data)

    async def get(self, slug: str) -> Memory:
        data = await self._request("GET", f"/pages/{slug}")
        return Memory.model_validate(data.get("page") or data)

    async def update(self, slug: str, content: str, *, title: str | None = None) -> Memory:
        payload: dict[str, Any] = {"content": content}
        if title is not None:
            payload["title"] = title
        data = await self._request("PUT", f"/pages/{slug}", json=payload)
        return Memory.model_validate(data.get("page") or data)

    async def delete(self, slug: str) -> None:
        await self._request("DELETE", f"/pages/{slug}")

    async def history(self, slug: str) -> list[Memory]:
        data = await self._request("GET", f"/pages/{slug}/history")
        items = data.get("versions") or []
        if not items:
            # Backend antigo (sem endpoint dedicado): cai pro GET /pages/{slug}
            data = await self._request("GET", f"/pages/{slug}")
            page = data.get("page") or data
            items = page.get("versions") or [page]
        if items and isinstance(items[0], dict) and "data" in items[0]:
            items = [it["data"] for it in items]
        return [Memory.model_validate(p) for p in items]

    # ── NEXUS-only ──────────────────────────────────────────────────────────
    async def compile(self, slug: str) -> Memory:
        data = await self._request("POST", f"/pages/{slug}/compile", json={})
        return Memory.model_validate(data.get("page") or data)

    async def extract_facts(
        self,
        text: str,
        *,
        context_entity: str | None = None,
        sync: bool = True,
    ) -> FactExtractionResult:
        payload: dict[str, Any] = {"text": text, "sync": sync}
        if context_entity:
            payload["context_entity"] = context_entity
        data = await self._request("POST", "/facts/extract", json=payload)
        return FactExtractionResult.model_validate(data)

    async def lesson(
        self,
        title: str,
        body: str,
        *,
        prevention: str | None = None,
        severity: str = "info",
        category: str | None = None,
        tags: Iterable[str] | None = None,
    ) -> Lesson:
        payload: dict[str, Any] = {"title": title, "body": body, "severity": severity}
        if prevention:
            payload["prevention"] = prevention
        if category:
            payload["category"] = category
        if tags:
            payload["tags"] = list(tags)
        data = await self._request("POST", "/lessons", json=payload)
        return Lesson.model_validate(data.get("lesson") or data)

    async def decision(
        self,
        title: str,
        description: str,
        *,
        rationale: str | None = None,
        alternatives: str | None = None,
        category: str | None = None,
        tags: Iterable[str] | None = None,
    ) -> Decision:
        payload: dict[str, Any] = {"title": title, "description": description}
        if rationale:
            payload["rationale"] = rationale
        if alternatives:
            payload["alternatives"] = alternatives
        if category:
            payload["category"] = category
        if tags:
            payload["tags"] = list(tags)
        data = await self._request("POST", "/decisions", json=payload)
        return Decision.model_validate(data.get("decision") or data)

    async def compact_session(self, session_id: int) -> Session:
        data = await self._request("PUT", f"/sessions/{session_id}", json={"status": "closed"})
        return Session.model_validate(data.get("session") or data)

    def entity(self, slug: str) -> _EntityScope:
        return _EntityScope(self, slug)

    async def search_entity(self, query: str, *, limit: int = 10) -> list[Entity]:
        data = await self._request("GET", "/entities", params={"q": query, "limit": limit})
        items = data.get("data") if isinstance(data, dict) else data
        return [Entity.model_validate(e) for e in (items or [])]

    # ── internal ────────────────────────────────────────────────────────────
    async def _get_entity(self, slug: str) -> Entity:
        data = await self._request("GET", f"/entities/{slug}")
        return Entity.model_validate(data.get("entity") or data)

    async def _get_entity_graph(self, slug: str) -> EntityGraph:
        data = await self._request("GET", f"/entities/{slug}/graph")
        root = data.get("root") or data.get("entity") or {"slug": slug, "name": slug}
        return EntityGraph.model_validate(
            {
                "root": root,
                "nodes": data.get("nodes") or [],
                "edges": data.get("edges") or data.get("relations") or [],
            }
        )

    async def _get_entity_relations(self, slug: str) -> list[EntityRelation]:
        data = await self._request("GET", f"/entities/{slug}/relations")
        items = data.get("data") if isinstance(data, dict) else data
        return [EntityRelation.model_validate(r) for r in (items or [])]

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f"{self._base}{path}"
        headers: dict[str, str] = kwargs.pop("headers", {}) or {}
        headers.setdefault("Accept", "application/json")
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"

        attempt = 0
        last_exc: Exception | None = None
        while attempt <= self._retries:
            try:
                resp = await self._http.request(method, url, headers=headers, **kwargs)
            except (httpx.ConnectError, httpx.ReadTimeout) as e:
                last_exc = e
                attempt += 1
                if attempt > self._retries:
                    raise NexusError(f"connection failed: {e}") from e
                await asyncio.sleep(0.5 * attempt)
                continue

            body: Any
            try:
                body = resp.json()
            except Exception:
                body = {"raw": resp.text}

            raise_for_status(resp.status_code, body)
            return body

        # unreachable
        raise NexusError(f"request exhausted retries: {last_exc}")


class Nexus:
    """Sync wrapper for AsyncNexus. Each call drives a fresh event loop."""

    def __init__(self, *args: Any, **kwargs: Any):
        self._async = AsyncNexus(*args, **kwargs)

    def _run(self, coro: Any) -> Any:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # Inside running loop (Jupyter etc): use nested loop fallback.
                return asyncio.run_coroutine_threadsafe(coro, loop).result()
        except RuntimeError:
            pass
        return asyncio.run(coro)

    def close(self) -> None:
        self._run(self._async.aclose())

    # Auth
    def login(self, email: str, password: str) -> str:
        return self._run(self._async.login(email, password))

    # mem0 paridade
    def add(self, content: str, **kw: Any) -> dict[str, Any]:
        return self._run(self._async.add(content, **kw))

    def search(self, query: str, **kw: Any) -> QueryResult:
        return self._run(self._async.search(query, **kw))

    def get(self, slug: str) -> Memory:
        return self._run(self._async.get(slug))

    def update(self, slug: str, content: str, **kw: Any) -> Memory:
        return self._run(self._async.update(slug, content, **kw))

    def delete(self, slug: str) -> None:
        return self._run(self._async.delete(slug))

    def history(self, slug: str) -> list[Memory]:
        return self._run(self._async.history(slug))

    # NEXUS-only
    def compile(self, slug: str) -> Memory:
        return self._run(self._async.compile(slug))

    def extract_facts(self, text: str, **kw: Any) -> FactExtractionResult:
        return self._run(self._async.extract_facts(text, **kw))

    def lesson(self, title: str, body: str, **kw: Any) -> Lesson:
        return self._run(self._async.lesson(title, body, **kw))

    def decision(self, title: str, description: str, **kw: Any) -> Decision:
        return self._run(self._async.decision(title, description, **kw))

    def compact_session(self, session_id: int) -> Session:
        return self._run(self._async.compact_session(session_id))

    def search_entity(self, query: str, **kw: Any) -> list[Entity]:
        return self._run(self._async.search_entity(query, **kw))

    def entity(self, slug: str) -> _EntityScopeSync:
        return _EntityScopeSync(self, slug)
