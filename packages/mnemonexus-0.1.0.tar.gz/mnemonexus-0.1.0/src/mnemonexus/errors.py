from __future__ import annotations

from typing import Any


class NexusError(Exception):
    """Base exception for mnemonexus client errors."""

    def __init__(self, message: str, *, status: int | None = None, body: Any = None):
        super().__init__(message)
        self.status = status
        self.body = body


class AuthError(NexusError):
    """401/403 from the API."""


class NotFoundError(NexusError):
    """404 from the API."""


class ValidationError(NexusError):
    """422 from the API."""


def raise_for_status(status: int, body: Any) -> None:
    if status < 400:
        return
    msg = _extract_message(body) or f"HTTP {status}"
    if status in (401, 403):
        raise AuthError(msg, status=status, body=body)
    if status == 404:
        raise NotFoundError(msg, status=status, body=body)
    if status == 422:
        raise ValidationError(msg, status=status, body=body)
    raise NexusError(msg, status=status, body=body)


def _extract_message(body: Any) -> str | None:
    if isinstance(body, dict):
        return body.get("message") or body.get("error")
    return None
