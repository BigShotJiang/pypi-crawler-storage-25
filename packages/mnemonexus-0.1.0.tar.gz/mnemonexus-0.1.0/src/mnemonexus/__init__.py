"""mnemonexus — cliente Python para o mnemonexus.

>>> from mnemonexus import Nexus
>>> nexus = Nexus(api_url="http://localhost:8080", token="...")
>>> nexus.add("Reunião terça 14h sobre roadmap")
>>> nexus.search("quando é a reunião?")
"""
from .client import AsyncNexus, Nexus
from .errors import NexusError, AuthError, NotFoundError, ValidationError
from .models import (
    Decision,
    Entity,
    EntityGraph,
    Fact,
    FactExtractionResult,
    Lesson,
    Memory,
    QueryResult,
    Session,
)

__version__ = "0.1.0"
__all__ = [
    "Nexus",
    "AsyncNexus",
    "NexusError",
    "AuthError",
    "NotFoundError",
    "ValidationError",
    "Memory",
    "Decision",
    "Lesson",
    "Entity",
    "EntityGraph",
    "Fact",
    "FactExtractionResult",
    "QueryResult",
    "Session",
]
