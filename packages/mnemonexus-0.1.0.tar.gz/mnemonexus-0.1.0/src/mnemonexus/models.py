from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class _Base(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)


class Memory(_Base):
    """A knowledge page in mnemonexus (compiled or raw memory)."""

    id: int | None = None
    slug: str | None = None
    title: str | None = None
    content: str | None = None
    domain: str | None = None
    memory_type: str | None = None
    source_type: str | None = None
    version: int | None = None
    superseded_by_id: int | None = None
    recall_boost: float | None = None
    stale_at: datetime | None = None
    deprecated_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    metadata: dict[str, Any] | None = None


class QueryResult(_Base):
    """Response of POST /api/v1/query — hybrid search + RAG answer."""

    answer: str | None = None
    sources: list[Memory] = Field(default_factory=list)
    mode: str | None = None
    elapsed_ms: float | None = None


class Decision(_Base):
    id: int | None = None
    title: str | None = None
    description: str | None = None
    rationale: str | None = None
    alternatives: str | None = None
    category: str | None = None
    status: str | None = None
    decided_at: datetime | None = None
    tags: list[str] | None = None


class Lesson(_Base):
    id: int | None = None
    title: str | None = None
    body: str | None = None
    prevention: str | None = None
    severity: str | None = None
    category: str | None = None
    occurrence_count: int | None = None
    tags: list[str] | None = None


class Entity(_Base):
    id: int | None = None
    slug: str | None = None
    name: str | None = None
    kind: str | None = None
    summary: str | None = None
    metadata: dict[str, Any] | None = None


class EntityRelation(_Base):
    id: int | None = None
    from_entity_slug: str | None = None
    to_entity_slug: str | None = None
    kind: str | None = None
    weight: float | None = None


class EntityGraph(_Base):
    root: Entity
    nodes: list[Entity] = Field(default_factory=list)
    edges: list[EntityRelation] = Field(default_factory=list)


class Fact(_Base):
    id: int | None = None
    slug: str | None = None
    title: str | None = None
    memory_type: str | None = None


class FactExtractionResult(_Base):
    status: str | None = None
    fact_count: int = 0
    entities_created: int = 0
    entities_seen: int = 0
    relations_created: int = 0
    facts: list[Fact] = Field(default_factory=list)


class Session(_Base):
    id: int | None = None
    agent_id: int | None = None
    status: str | None = None
    started_at: datetime | None = None
    closed_at: datetime | None = None
    summary: str | None = None
