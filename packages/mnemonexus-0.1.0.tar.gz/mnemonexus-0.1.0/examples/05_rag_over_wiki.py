"""05 — RAG completo: ingest de várias fontes → query híbrido com histórico.

Caso clássico: você tem N documentos, quer chatbot que responde sobre eles
mantendo contexto de conversa. mnemonexus já entrega isso.
"""
from __future__ import annotations

import os

from mnemonexus import Nexus

SOURCES = [
    ("Honcho — overview", "Honcho é a deep memory layer do mnemonexus. Armazena fatos per-peer."),
    ("Honcho — modelo", "Cada peer tem session + messages. LanceDB embedded pra vectors 1024d."),
    ("Honcho — uso", "Dialectic query é o endpoint pra perguntar 'o que sabemos sobre X'."),
]


def main() -> None:
    nexus = Nexus(token=os.environ.get("MNEMONEXUS_TOKEN"))

    for title, body in SOURCES:
        nexus.add(content=body, title=title, domain="wiki", source_type="markdown")

    history: list[dict[str, str]] = []
    for turn in ["o que é Honcho?", "como faço dialectic query?", "qual a dimensão do embedding?"]:
        result = nexus.search(turn, domain="wiki", history=history)
        print(f"\nQ: {turn}\nA: {result.answer}")
        history.append({"role": "user", "content": turn})
        history.append({"role": "assistant", "content": result.answer or ""})


if __name__ == "__main__":
    main()
