"""01 — Hello world: add + search.

Pré-requisitos:
    pip install mnemonexus
    export MNEMONEXUS_URL=http://localhost:8080
    export MNEMONEXUS_TOKEN=seu-token-sanctum

Rode com: python examples/01_hello_world.py
"""
from __future__ import annotations

import os

from mnemonexus import Nexus


def main() -> None:
    nexus = Nexus(
        api_url=os.environ.get("MNEMONEXUS_URL", "http://localhost:8080"),
        token=os.environ.get("MNEMONEXUS_TOKEN"),
    )

    nexus.add(
        "A reunião de roadmap acontece toda terça às 14h, sala virtual no Meet.",
        domain="memory",
    )

    result = nexus.search("quando é a reunião de roadmap?")
    print("Resposta:", result.answer)
    print(f"Fontes ({len(result.sources)}):")
    for src in result.sources:
        print(f"  - {src.title or src.slug}")


if __name__ == "__main__":
    main()
