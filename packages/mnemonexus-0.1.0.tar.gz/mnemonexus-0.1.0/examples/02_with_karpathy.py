"""02 — Wiki compilada (Karpathy pattern): ingest → compile → query.

Demonstra o ciclo: dado bruto entra como source, é compilado num KnowledgePage
estruturado e fica disponível pra recall hybrid.
"""
from __future__ import annotations

import os

from mnemonexus import Nexus


def main() -> None:
    nexus = Nexus(token=os.environ.get("MNEMONEXUS_TOKEN"))

    page = nexus.add(
        content=(
            "pgvector é a extensão do PostgreSQL pra busca vetorial. "
            "Suporta IVFFlat e HNSW como índices ANN. No mnemonexus a busca híbrida "
            "combina pgvector (semantic) + Meilisearch (FTS)."
        ),
        title="pgvector — busca vetorial no Postgres",
        domain="wiki",
        source_type="markdown",
    )
    print("Ingest enfileirado:", page.get("status"))

    slug = page.get("slug") or page.get("page", {}).get("slug")
    if slug:
        compiled = nexus.compile(slug)
        print(f"Compilada: {compiled.title} (v{compiled.version})")

    answer = nexus.search("qual a diferença entre IVFFlat e HNSW no pgvector?", domain="wiki")
    print("→", answer.answer)


if __name__ == "__main__":
    main()
