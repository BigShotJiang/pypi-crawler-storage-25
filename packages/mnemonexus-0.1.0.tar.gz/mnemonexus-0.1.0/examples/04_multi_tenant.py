"""04 — Multi-tenant: cliente por agent_id via metadata e domain.

mnemonexus não tem multi-tenancy hard (por org), mas suporta isolamento lógico
por `domain` + `agent_id` em metadata. Use isto pra separar memórias entre
bots ou clientes.
"""
from __future__ import annotations

import os

from mnemonexus import Nexus


def store_for_tenant(nexus: Nexus, tenant: str, content: str) -> None:
    nexus.add(
        content=content,
        domain=f"memory",
        metadata={"tenant": tenant, "agent_id": f"bot-{tenant}"},
    )


def search_for_tenant(nexus: Nexus, tenant: str, q: str) -> None:
    result = nexus.search(q, domain="memory", limit=5)
    relevant = [s for s in result.sources if (s.metadata or {}).get("tenant") == tenant]
    print(f"[{tenant}] {len(relevant)} fontes relevantes")


def main() -> None:
    nexus = Nexus(token=os.environ.get("MNEMONEXUS_TOKEN"))

    store_for_tenant(nexus, "acme", "Acme usa AWS us-east-1, Postgres 15.")
    store_for_tenant(nexus, "globex", "Globex usa GCP, Postgres 16, BigQuery pra analytics.")

    search_for_tenant(nexus, "acme", "qual cloud e versão do Postgres?")
    search_for_tenant(nexus, "globex", "qual cloud e versão do Postgres?")


if __name__ == "__main__":
    main()
