"""03 — Twice rule: registrar a mesma lição duas vezes dispara prevenção.

mnemonexus rastreia ocorrências de lessons similares. Na segunda vez, gera
prevenção automática — o agente pode usar isso pra evitar repetir o erro.
"""
from __future__ import annotations

import os

from mnemonexus import Nexus


def main() -> None:
    nexus = Nexus(token=os.environ.get("MNEMONEXUS_TOKEN"))

    title = "Não dropar tabela em migration sem backup"

    first = nexus.lesson(
        title=title,
        body="DROP TABLE em produção sem dump → perda de 3h de dados.",
        severity="critical",
        category="database",
        tags=["postgres", "backup"],
    )
    print(f"Primeira ocorrência: id={first.id}, count={first.occurrence_count or 1}")

    second = nexus.lesson(
        title=title,
        body="Aconteceu de novo na migration 2026-05-30.",
        severity="critical",
    )
    print(f"Segunda → twice rule: count={second.occurrence_count}")
    print(f"Prevenção gerada: {second.prevention}")


if __name__ == "__main__":
    main()
