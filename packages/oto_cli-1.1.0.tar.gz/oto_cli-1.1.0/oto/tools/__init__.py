"""Otomata tools."""
