"""
Kaspr API Client for LinkedIn profile enrichment.

Requires: requests
"""

from typing import Optional, Dict, Any, List

import requests

from ...config import require_secret


class KasprClient:
    """
    Kaspr API client for:
    - LinkedIn profile enrichment
    - Email and phone number retrieval
    """

    BASE_URL = "https://api.developers.kaspr.io"

    def __init__(self, api_key: str = None):
        """
        Initialize Kaspr client.

        Args:
            api_key: Kaspr API key (or set KASPR_API_KEY env var)
        """
        self.api_key = api_key or require_secret("KASPR_API_KEY")

    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make API request."""
        url = f"{self.BASE_URL}/{endpoint}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "accept-version": "v2.0",
        }

        response = requests.request(method, url, headers=headers, **kwargs)
        response.raise_for_status()
        return response.json()

    def verify_key(self) -> Dict[str, Any]:
        """
        Verify API key and get user info.

        Returns:
            User info with credits
        """
        return self._request("GET", "user")

    def enrich_linkedin(
        self,
        linkedin_id: str,
        name: str = None,
        is_phone_required: bool = False,
        data_to_get: List[str] = None,
    ) -> Dict[str, Any]:
        """
        Enrich a LinkedIn profile.

        Args:
            linkedin_id: LinkedIn profile ID (e.g., "john-doe-12345")
            name: Full name (helps matching)
            is_phone_required: Require phone number
            data_to_get: Data types to retrieve (e.g., ["workEmail", "personalEmail", "phone"])

        Returns:
            Enriched profile with emails and phones
        """
        data = {"id": linkedin_id}
        if name:
            data["name"] = name
        if is_phone_required:
            data["isPhoneRequired"] = True
        data["dataToGet"] = data_to_get or ["workEmail", "phone"]

        return self._request("POST", "profile/linkedin", json=data)
