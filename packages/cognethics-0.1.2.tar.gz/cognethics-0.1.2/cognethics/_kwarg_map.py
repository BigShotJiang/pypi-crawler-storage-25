"""Canonical mapping of prism_introspect axis labels to mega-tool dispatcher kwarg names.

Source: validator-megatool report at
pj/0/00_Teams/4917214c-fd4b-4b90-8c2d-26c3c5de4ff8/agent-validator-megatool.md
(verified live against the 9 mega-tool dispatchers on 2026-05-05).

`prism_introspect` always uses the registry's canonical 4-axis vocabulary:
mega_tool / app / entity / operation. The dispatchers, however, name those
positions differently. This map tells codegen which dispatcher kwarg to set
for the introspect axes called `entity` (axis_2) and `operation` (axis_3).

Axis 0 (mega_tool) and axis 1 (app) are always named the same on both sides.
"""

MEGA_TOOL_KWARG_MAP = {
    "entity_crud":       {"axis_2": "entity",       "axis_3": "operation"},
    "workflow_action":   {"axis_2": "entity",       "axis_3": "action"},
    "report_query":      {"axis_2": None,           "axis_3": "report_type"},
    "agent_command":     {"axis_2": "agent",        "axis_3": "command"},
    "integration_call":  {"axis_2": "integration",  "axis_3": "action"},
    "smart_action":      {"axis_2": "domain",       "axis_3": "action"},
    "document_op":       {"axis_2": "doc_type",     "axis_3": "operation"},
    "notification_send": {"axis_2": "channel",      "axis_3": None},
    "config_manage":     {"axis_2": "config_type",  "axis_3": "operation"},
}

# Mega-tools whose dispatchers do NOT signature-filter kwargs - SDK must only
# emit introspect-declared params (sending unknown kwargs causes TypeError).
NO_SIGNATURE_FILTER = {
    "integration_call",
    "document_op",
    "notification_send",
    "config_manage",
}
