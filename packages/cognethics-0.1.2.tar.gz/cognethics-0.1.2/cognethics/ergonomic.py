"""Ergonomic top-20 wrappers for the most-used Prism handlers.

Imported from cognethics via lazy attribute access on Client.
"""
from __future__ import annotations
from typing import TYPE_CHECKING, Optional, Iterator, Any

if TYPE_CHECKING:
    from cognethics._client import Client


class _Facade:
    def __init__(self, client: "Client"):
        self._client = client


class InvoicesFacade(_Facade):
    """Customer-facing **Accounts Receivable (AR)** invoices.

    These are invoices your organization *issues to customers* — i.e. money owed
    TO you. The underlying entity is ``finance.invoice``.

    For invoices your organization *receives from vendors* (Accounts Payable),
    use :class:`VendorInvoicesFacade` (``client.vendor_invoices``) instead.
    """
    def list(self, *, status: Optional[str] = None, customer_id: Optional[str] = None, page: int = 1, page_size: int = 50) -> dict:
        filters = {}
        if status: filters["status"] = status
        if customer_id: filters["customer_id"] = customer_id
        return self._client.entity_crud.finance.invoice.list(filters=filters or None, page=page, page_size=page_size)
    def get(self, invoice_id: str) -> dict:
        return self._client.entity_crud.finance.invoice.read(id=invoice_id)
    def create(self, **fields) -> dict:
        return self._client.entity_crud.finance.invoice.create(data=fields)
    def update(self, invoice_id: str, **fields) -> dict:
        return self._client.entity_crud.finance.invoice.update(id=invoice_id, data=fields)
    def send(self, invoice_id: str) -> dict:
        return self._client.workflow_action.finance.invoice.send(entity_id=invoice_id)


class VendorInvoicesFacade(_Facade):
    """Vendor-facing **Accounts Payable (AP)** invoices.

    These are invoices your organization *receives from vendors* — i.e. money
    you owe to suppliers. The underlying entity is ``finance.vendor_invoice``.

    For invoices your organization *issues to customers* (Accounts Receivable),
    use :class:`InvoicesFacade` (``client.invoices``) instead.
    """
    def list(self, *, status: Optional[str] = None, vendor_id: Optional[str] = None, page: int = 1, page_size: int = 50) -> dict:
        filters = {}
        if status: filters["status"] = status
        if vendor_id: filters["vendor_id"] = vendor_id
        return self._client.entity_crud.finance.vendor_invoice.list(filters=filters or None, page=page, page_size=page_size)
    def get(self, invoice_id: str) -> dict:
        return self._client.entity_crud.finance.vendor_invoice.read(id=invoice_id)


class CustomersFacade(_Facade):
    def list(self, *, search: Optional[str] = None, page: int = 1, page_size: int = 50) -> dict:
        filters = {"search": search} if search else None
        return self._client.entity_crud.finance.customer.list(filters=filters, page=page, page_size=page_size)
    def get(self, customer_id: str) -> dict:
        return self._client.entity_crud.finance.customer.read(id=customer_id)
    def create(self, **fields) -> dict:
        return self._client.entity_crud.finance.customer.create(data=fields)


class VendorsFacade(_Facade):
    def list(self, *, search: Optional[str] = None, page: int = 1, page_size: int = 50) -> dict:
        filters = {"search": search} if search else None
        return self._client.entity_crud.finance.vendor.list(filters=filters, page=page, page_size=page_size)
    def get(self, vendor_id: str) -> dict:
        return self._client.entity_crud.finance.vendor.read(id=vendor_id)


class PaymentsFacade(_Facade):
    def list(self, *, page: int = 1, page_size: int = 50) -> dict:
        return self._client.entity_crud.finance.payment.list(page=page, page_size=page_size)
    def create(self, **fields) -> dict:
        return self._client.entity_crud.finance.payment.create(data=fields)


class PurchaseOrdersFacade(_Facade):
    def list(self, *, status: Optional[str] = None, page: int = 1, page_size: int = 50) -> dict:
        filters = {"status": status} if status else None
        return self._client.entity_crud.finance.purchase_order.list(filters=filters, page=page, page_size=page_size)
    def get(self, po_id: str) -> dict:
        return self._client.entity_crud.finance.purchase_order.read(id=po_id)
    def create(self, **fields) -> dict:
        return self._client.entity_crud.finance.purchase_order.create(data=fields)
    def submit(self, po_id: str) -> dict:
        return self._client.workflow_action.finance.purchase_order.submit(entity_id=po_id)
    def approve(self, po_id: str) -> dict:
        return self._client.workflow_action.finance.purchase_order.approve(entity_id=po_id)


class WorkOrdersFacade(_Facade):
    """Spare parts work orders."""
    def list(self, *, status: Optional[str] = None, page: int = 1, page_size: int = 50) -> dict:
        filters = {"status": status} if status else None
        return self._client.entity_crud.spare_parts.work_order.list(filters=filters, page=page, page_size=page_size)
    def get(self, wo_id: str) -> dict:
        return self._client.entity_crud.spare_parts.work_order.read(id=wo_id)
    def create(self, **fields) -> dict:
        return self._client.entity_crud.spare_parts.work_order.create(data=fields)


class SparePartsFacade(_Facade):
    """Spare parts inventory."""
    def list(self, *, page: int = 1, page_size: int = 50) -> dict:
        return self._client.entity_crud.spare_parts.item.list(page=page, page_size=page_size)
    def search(self, query: str, *, page_size: int = 20) -> dict:
        return self._client.entity_crud.spare_parts.item.search(filters={"search": query}, page_size=page_size)
    def get(self, item_id: str) -> dict:
        return self._client.entity_crud.spare_parts.item.read(id=item_id)


class DocumentsFacade(_Facade):
    def list(self, *, page: int = 1, page_size: int = 50) -> dict:
        return self._client.entity_crud.documents.document.list(page=page, page_size=page_size)
    def search(self, query: str, *, include_content: bool = False, page_size: int = 20) -> dict:
        filters = {"search": query, "include_content": include_content}
        return self._client.entity_crud.documents.document.search(filters=filters, page_size=page_size)


class ReportsFacade(_Facade):
    """Common finance reports (report_query mega-tool)."""
    def ap_aging(self, *, as_of_date: Optional[str] = None, vendor_id: Optional[str] = None,
                 include_overdue_only: bool = False) -> dict:
        """Accounts Payable aging summary by aging bucket."""
        return self._client.report_query.finance.finance.aging_ap_summary(
            as_of_date=as_of_date,
            vendor_id=vendor_id,
            include_overdue_only=include_overdue_only,
        )

    def ar_aging(self, *, as_of_date: Optional[str] = None, customer_id: Optional[str] = None,
                 include_overdue_only: bool = False) -> dict:
        """Accounts Receivable aging summary by aging bucket."""
        return self._client.report_query.finance.finance.aging_ar_summary(
            as_of_date=as_of_date,
            customer_id=customer_id,
            include_overdue_only=include_overdue_only,
        )

    def cash_flow_forecast(self, *, weeks: int = 8, start_date: Optional[str] = None,
                           starting_balance: Optional[float] = None,
                           collection_rate: float = 0.85) -> dict:
        """Forward-looking cash flow forecast based on AR and AP."""
        return self._client.report_query.finance.finance.cash_flow_forecast(
            weeks=weeks,
            start_date=start_date,
            starting_balance=starting_balance,
            collection_rate=collection_rate,
        )

    def trial_balance(self, *, as_of_date: Optional[str] = None,
                      account_type: Optional[str] = None,
                      include_zero_balances: bool = False,
                      postable_only: bool = True) -> dict:
        """Trial balance summary across the chart of accounts."""
        return self._client.report_query.finance.finance.trial_balance_summary(
            as_of_date=as_of_date,
            account_type=account_type,
            include_zero_balances=include_zero_balances,
            postable_only=postable_only,
        )


# Map of facade name -> facade class. Used by Client lazy-binding.
ERGONOMIC_FACADES = {
    "invoices": InvoicesFacade,
    "vendor_invoices": VendorInvoicesFacade,
    "customers": CustomersFacade,
    "vendors": VendorsFacade,
    "payments": PaymentsFacade,
    "purchase_orders": PurchaseOrdersFacade,
    "work_orders": WorkOrdersFacade,
    "spare_parts": SparePartsFacade,
    "documents": DocumentsFacade,
    "reports": ReportsFacade,
}
