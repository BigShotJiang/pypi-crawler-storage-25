"""Cognethics SDK exceptions."""
from typing import Optional


class Error(Exception):
    """Base exception for all Cognethics SDK errors."""

    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        details: Optional[dict] = None,
        hint: Optional[str] = None,
        request_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.code = code
        self.details = details or {}
        self.hint = hint
        self.request_id = request_id


class PermissionDenied(Error):
    pass


class NotFound(Error):
    pass


class ValidationError(Error):
    pass


class RateLimit(Error):
    def __init__(self, *args, retry_after: Optional[int] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.retry_after = retry_after


class ServerError(Error):
    pass


class AuthenticationError(Error):
    pass


class InvalidOperation(Error):
    pass


# Map PrismResponse error codes -> exception class
ERROR_CODE_MAP = {
    "PERMISSION_DENIED": PermissionDenied,
    "NOT_FOUND": NotFound,
    "VALIDATION_ERROR": ValidationError,
    "INVALID_OPERATION": InvalidOperation,
    "INTERNAL_ERROR": ServerError,
}


def raise_for_response(payload: dict, status_code: int) -> None:
    """Raise the right exception based on PrismResponse error.code or HTTP status."""
    if payload.get("success", True):
        return
    err = payload.get("error", {}) or {}
    code = err.get("code", "UNKNOWN")
    message = err.get("message", "Unknown error")
    details = err.get("details")
    hint = err.get("hint")
    request_id = (payload.get("meta") or {}).get("request_id")
    cls = ERROR_CODE_MAP.get(code, Error)
    raise cls(message, code=code, details=details, hint=hint, request_id=request_id)
