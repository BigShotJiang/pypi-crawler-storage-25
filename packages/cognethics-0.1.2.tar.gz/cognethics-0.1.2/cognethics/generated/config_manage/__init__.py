"""Auto-generated package init — DO NOT EDIT."""
from __future__ import annotations

from typing import Any

from . import core as core

class AppRegistry:
    """Generated registry of apps for the config_manage mega-tool."""

    def __init__(self, _client: Any) -> None:
        self._client = _client
        self.core = core.EntityRegistry(_client)

__all__ = ["AppRegistry", "core"]
