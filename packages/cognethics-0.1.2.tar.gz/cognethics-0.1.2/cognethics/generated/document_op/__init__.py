"""Auto-generated package init — DO NOT EDIT."""
from __future__ import annotations

from typing import Any

from . import documents as documents

class AppRegistry:
    """Generated registry of apps for the document_op mega-tool."""

    def __init__(self, _client: Any) -> None:
        self._client = _client
        self.documents = documents.EntityRegistry(_client)

__all__ = ["AppRegistry", "documents"]
