"""Auto-generated package init — DO NOT EDIT."""
from __future__ import annotations

from typing import Any

from . import agents as agents
from . import app_builder as app_builder
from . import assessments as assessments
from . import conformity as conformity
from . import core as core
from . import crm as crm
from . import data_mapping as data_mapping
from . import documents as documents
from . import ehr as ehr
from . import feature_requests as feature_requests
from . import finance as finance
from . import grc as grc
from . import healthcare as healthcare
from . import hr as hr
from . import ics as ics
from . import infosec as infosec
from . import itsm as itsm
from . import labor_marketplace as labor_marketplace
from . import legal as legal
from . import lms as lms
from . import marketing as marketing
from . import mdm as mdm
from . import pmo as pmo
from . import risk_assessment as risk_assessment
from . import security_analytics as security_analytics
from . import spare_parts as spare_parts
from . import training_data as training_data
from . import transitional_living as transitional_living
from . import vc as vc
from . import vrm as vrm

class AppRegistry:
    """Generated registry of apps for the workflow_action mega-tool."""

    def __init__(self, _client: Any) -> None:
        self._client = _client
        self.agents = agents.EntityRegistry(_client)
        self.app_builder = app_builder.EntityRegistry(_client)
        self.assessments = assessments.EntityRegistry(_client)
        self.conformity = conformity.EntityRegistry(_client)
        self.core = core.EntityRegistry(_client)
        self.crm = crm.EntityRegistry(_client)
        self.data_mapping = data_mapping.EntityRegistry(_client)
        self.documents = documents.EntityRegistry(_client)
        self.ehr = ehr.EntityRegistry(_client)
        self.feature_requests = feature_requests.EntityRegistry(_client)
        self.finance = finance.EntityRegistry(_client)
        self.grc = grc.EntityRegistry(_client)
        self.healthcare = healthcare.EntityRegistry(_client)
        self.hr = hr.EntityRegistry(_client)
        self.ics = ics.EntityRegistry(_client)
        self.infosec = infosec.EntityRegistry(_client)
        self.itsm = itsm.EntityRegistry(_client)
        self.labor_marketplace = labor_marketplace.EntityRegistry(_client)
        self.legal = legal.EntityRegistry(_client)
        self.lms = lms.EntityRegistry(_client)
        self.marketing = marketing.EntityRegistry(_client)
        self.mdm = mdm.EntityRegistry(_client)
        self.pmo = pmo.EntityRegistry(_client)
        self.risk_assessment = risk_assessment.EntityRegistry(_client)
        self.security_analytics = security_analytics.EntityRegistry(_client)
        self.spare_parts = spare_parts.EntityRegistry(_client)
        self.training_data = training_data.EntityRegistry(_client)
        self.transitional_living = transitional_living.EntityRegistry(_client)
        self.vc = vc.EntityRegistry(_client)
        self.vrm = vrm.EntityRegistry(_client)

__all__ = ["AppRegistry", "agents", "app_builder", "assessments", "conformity", "core", "crm", "data_mapping", "documents", "ehr", "feature_requests", "finance", "grc", "healthcare", "hr", "ics", "infosec", "itsm", "labor_marketplace", "legal", "lms", "marketing", "mdm", "pmo", "risk_assessment", "security_analytics", "spare_parts", "training_data", "transitional_living", "vc", "vrm"]
