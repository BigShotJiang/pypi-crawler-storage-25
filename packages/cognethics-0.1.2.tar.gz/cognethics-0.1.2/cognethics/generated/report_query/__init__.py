"""Auto-generated package init — DO NOT EDIT."""
from __future__ import annotations

from typing import Any

from . import app_builder as app_builder
from . import assessments as assessments
from . import crm as crm
from . import data_mapping as data_mapping
from . import documents as documents
from . import ehr as ehr
from . import finance as finance
from . import grc as grc
from . import healthcare as healthcare
from . import hr as hr
from . import hr_onboarding as hr_onboarding
from . import hr_recruiting as hr_recruiting
from . import infosec as infosec
from . import itsm as itsm
from . import labor_marketplace as labor_marketplace
from . import legal as legal
from . import lms as lms
from . import marketing as marketing
from . import mdm as mdm
from . import pmo as pmo
from . import risk_assessment as risk_assessment
from . import spare_parts as spare_parts
from . import training_data as training_data
from . import transitional_living as transitional_living
from . import vc as vc
from . import vrm as vrm

class AppRegistry:
    """Generated registry of apps for the report_query mega-tool."""

    def __init__(self, _client: Any) -> None:
        self._client = _client
        self.app_builder = app_builder.AppBuilderClient(_client)
        self.assessments = assessments.AssessmentsClient(_client)
        self.crm = crm.CrmClient(_client)
        self.data_mapping = data_mapping.DataMappingClient(_client)
        self.documents = documents.DocumentsClient(_client)
        self.ehr = ehr.EhrClient(_client)
        self.finance = finance.FinanceClient(_client)
        self.grc = grc.GrcClient(_client)
        self.healthcare = healthcare.HealthcareClient(_client)
        self.hr = hr.HrClient(_client)
        self.hr_onboarding = hr_onboarding.HrOnboardingClient(_client)
        self.hr_recruiting = hr_recruiting.HrRecruitingClient(_client)
        self.infosec = infosec.InfosecClient(_client)
        self.itsm = itsm.ItsmClient(_client)
        self.labor_marketplace = labor_marketplace.LaborMarketplaceClient(_client)
        self.legal = legal.LegalClient(_client)
        self.lms = lms.LmsClient(_client)
        self.marketing = marketing.MarketingClient(_client)
        self.mdm = mdm.MdmClient(_client)
        self.pmo = pmo.PmoClient(_client)
        self.risk_assessment = risk_assessment.RiskAssessmentClient(_client)
        self.spare_parts = spare_parts.SparePartsClient(_client)
        self.training_data = training_data.TrainingDataClient(_client)
        self.transitional_living = transitional_living.TransitionalLivingClient(_client)
        self.vc = vc.VcClient(_client)
        self.vrm = vrm.VrmClient(_client)

__all__ = ["AppRegistry", "app_builder", "assessments", "crm", "data_mapping", "documents", "ehr", "finance", "grc", "healthcare", "hr", "hr_onboarding", "hr_recruiting", "infosec", "itsm", "labor_marketplace", "legal", "lms", "marketing", "mdm", "pmo", "risk_assessment", "spare_parts", "training_data", "transitional_living", "vc", "vrm"]
