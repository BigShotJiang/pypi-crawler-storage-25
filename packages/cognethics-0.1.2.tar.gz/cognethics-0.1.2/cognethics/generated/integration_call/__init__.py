"""Auto-generated package init — DO NOT EDIT."""
from __future__ import annotations

from typing import Any

from . import healthcare as healthcare

class AppRegistry:
    """Generated registry of apps for the integration_call mega-tool."""

    def __init__(self, _client: Any) -> None:
        self._client = _client
        self.healthcare = healthcare.EntityRegistry(_client)

__all__ = ["AppRegistry", "healthcare"]
