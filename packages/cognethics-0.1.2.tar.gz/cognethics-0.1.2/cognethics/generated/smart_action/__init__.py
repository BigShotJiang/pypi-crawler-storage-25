"""Auto-generated package init — DO NOT EDIT."""
from __future__ import annotations

from typing import Any

from . import app_builder as app_builder
from . import core as core
from . import crm as crm
from . import documents as documents
from . import ehr as ehr
from . import finance as finance
from . import grc as grc
from . import healthcare as healthcare
from . import hr as hr
from . import legal as legal
from . import lms as lms
from . import marketing as marketing
from . import mdm as mdm
from . import spare_parts as spare_parts

class AppRegistry:
    """Generated registry of apps for the smart_action mega-tool."""

    def __init__(self, _client: Any) -> None:
        self._client = _client
        self.app_builder = app_builder.EntityRegistry(_client)
        self.core = core.EntityRegistry(_client)
        self.crm = crm.EntityRegistry(_client)
        self.documents = documents.EntityRegistry(_client)
        self.ehr = ehr.EntityRegistry(_client)
        self.finance = finance.EntityRegistry(_client)
        self.grc = grc.EntityRegistry(_client)
        self.healthcare = healthcare.EntityRegistry(_client)
        self.hr = hr.EntityRegistry(_client)
        self.legal = legal.EntityRegistry(_client)
        self.lms = lms.EntityRegistry(_client)
        self.marketing = marketing.EntityRegistry(_client)
        self.mdm = mdm.EntityRegistry(_client)
        self.spare_parts = spare_parts.EntityRegistry(_client)

__all__ = ["AppRegistry", "app_builder", "core", "crm", "documents", "ehr", "finance", "grc", "healthcare", "hr", "legal", "lms", "marketing", "mdm", "spare_parts"]
