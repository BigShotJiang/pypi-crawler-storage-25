"""Auto-generated package init — DO NOT EDIT."""
from __future__ import annotations

from typing import Any

from . import hive as hive
from . import pj as pj

class AppRegistry:
    """Generated registry of apps for the agent_command mega-tool."""

    def __init__(self, _client: Any) -> None:
        self._client = _client
        self.hive = hive.EntityRegistry(_client)
        self.pj = pj.EntityRegistry(_client)

__all__ = ["AppRegistry", "hive", "pj"]
