"""Cognethics — Official Python SDK for the Cognethics platform."""
from cognethics._client import Client
from cognethics._exceptions import (
    AuthenticationError,
    Error,
    InvalidOperation,
    NotFound,
    PermissionDenied,
    RateLimit,
    ServerError,
    ValidationError,
)

__version__ = "0.1.2"

__all__ = [
    "Client",
    "Error",
    "AuthenticationError",
    "InvalidOperation",
    "NotFound",
    "PermissionDenied",
    "RateLimit",
    "ServerError",
    "ValidationError",
    "__version__",
]

# Ergonomic facade auto-binding (after Client is imported)
from cognethics.ergonomic import ERGONOMIC_FACADES

def _bind_ergonomic(self):
    for name, cls in ERGONOMIC_FACADES.items():
        if not hasattr(self, f"_ergo_{name}"):
            setattr(self, f"_ergo_{name}", cls(self))

# Add convenience properties to Client
for _facade_name in ERGONOMIC_FACADES:
    def _make_prop(name):
        def _get(self):
            _bind_ergonomic(self)
            return getattr(self, f"_ergo_{name}")
        return property(_get)
    setattr(Client, _facade_name, _make_prop(_facade_name))
