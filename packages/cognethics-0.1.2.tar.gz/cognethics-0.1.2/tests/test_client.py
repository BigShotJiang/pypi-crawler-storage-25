import json

import httpx
import pytest

from cognethics import (
    AuthenticationError,
    Client,
    NotFound,
    PermissionDenied,
    RateLimit,
    ValidationError,
)


TOOL_URL = "/api/mcp/tools/prism_introspect/"
ENTITY_CRUD_URL = "/api/mcp/tools/prism_entity_crud/"


def _ok(data=None, meta=None):
    return {"success": True, "data": data if data is not None else {}, "meta": meta or {}}


def _err(code, message="boom", details=None, hint=None):
    return {
        "success": False,
        "error": {"code": code, "message": message, "details": details or {}, "hint": hint},
        "meta": {"request_id": "req-test"},
    }


def test_call_sends_bearer_header(client, respx_mock):
    route = respx_mock.post(TOOL_URL).mock(return_value=httpx.Response(200, json=_ok()))
    client.call("prism_introspect", dimension="mega_tools")
    assert route.called
    req = route.calls.last.request
    assert req.headers["Authorization"] == "Bearer mcp_testkey"


def test_call_sends_org_header_when_set(respx_mock):
    org_uuid = "11111111-1111-1111-1111-111111111111"
    c = Client(api_key="mcp_x", base_url="http://localhost:8000", org=org_uuid)
    route = respx_mock.post(TOOL_URL).mock(return_value=httpx.Response(200, json=_ok()))
    c.call("prism_introspect")
    assert route.calls.last.request.headers["X-Organization-Context"] == org_uuid


def test_call_sends_per_call_org_override(client, respx_mock):
    other = "22222222-2222-2222-2222-222222222222"
    route = respx_mock.post(TOOL_URL).mock(return_value=httpx.Response(200, json=_ok()))
    client.call("prism_introspect", _org=other)
    assert route.calls.last.request.headers["X-Organization-Context"] == other


def test_call_returns_data_dict(client, respx_mock):
    respx_mock.post(TOOL_URL).mock(
        return_value=httpx.Response(200, json={"success": True, "data": [1, 2, 3], "meta": {}})
    )
    out = client.call("prism_introspect")
    assert out["data"] == [1, 2, 3]


def test_permission_denied_raises(client, respx_mock):
    respx_mock.post(TOOL_URL).mock(
        return_value=httpx.Response(200, json=_err("PERMISSION_DENIED", "no access"))
    )
    with pytest.raises(PermissionDenied) as exc:
        client.call("prism_introspect")
    assert exc.value.code == "PERMISSION_DENIED"
    assert "no access" in str(exc.value)


def test_not_found_raises(client, respx_mock):
    respx_mock.post(TOOL_URL).mock(
        return_value=httpx.Response(200, json=_err("NOT_FOUND", "missing"))
    )
    with pytest.raises(NotFound) as exc:
        client.call("prism_introspect")
    assert exc.value.code == "NOT_FOUND"


def test_validation_error_raises(client, respx_mock):
    respx_mock.post(TOOL_URL).mock(
        return_value=httpx.Response(200, json=_err("VALIDATION_ERROR", "bad input"))
    )
    with pytest.raises(ValidationError) as exc:
        client.call("prism_introspect")
    assert exc.value.code == "VALIDATION_ERROR"


def test_retry_on_429_then_success(client, respx_mock):
    route = respx_mock.post(TOOL_URL).mock(
        side_effect=[
            httpx.Response(429, headers={"Retry-After": "0"}, json={"error": "rate"}),
            httpx.Response(200, json=_ok({"hello": "world"})),
        ]
    )
    out = client.call("prism_introspect")
    assert out["data"] == {"hello": "world"}
    assert route.call_count == 2


def test_retry_exhausted_on_429(client, respx_mock):
    respx_mock.post(TOOL_URL).mock(
        return_value=httpx.Response(429, headers={"Retry-After": "0"}, json={"error": "rate"})
    )
    with pytest.raises(RateLimit):
        client.call("prism_introspect")


def test_no_retry_on_400(client, respx_mock):
    route = respx_mock.post(TOOL_URL).mock(
        return_value=httpx.Response(400, json=_err("VALIDATION_ERROR", "bad"))
    )
    with pytest.raises(ValidationError):
        client.call("prism_introspect")
    assert route.call_count == 1


def test_retry_on_503(client, respx_mock):
    route = respx_mock.post(TOOL_URL).mock(
        side_effect=[
            httpx.Response(503, json={"error": "down"}),
            httpx.Response(200, json=_ok({"ok": True})),
        ]
    )
    out = client.call("prism_introspect")
    assert out["data"] == {"ok": True}
    assert route.call_count == 2


def test_401_raises_authentication_error(client, respx_mock):
    respx_mock.post(TOOL_URL).mock(return_value=httpx.Response(401, json={"error": "nope"}))
    with pytest.raises(AuthenticationError):
        client.call("prism_introspect")


def test_paginate_iterates_pages(client, respx_mock):
    pages = [
        httpx.Response(
            200,
            json={
                "success": True,
                "data": [1, 2],
                "pagination": {"has_next": True, "page": 1},
                "meta": {},
            },
        ),
        httpx.Response(
            200,
            json={
                "success": True,
                "data": [3, 4],
                "pagination": {"has_next": True, "page": 2},
                "meta": {},
            },
        ),
        httpx.Response(
            200,
            json={
                "success": True,
                "data": [5],
                "pagination": {"has_next": False, "page": 3},
                "meta": {},
            },
        ),
    ]
    respx_mock.post(ENTITY_CRUD_URL).mock(side_effect=pages)
    rows = list(client.paginate(client.entity_crud.spare_parts.work_order.list, page_size=2))
    assert rows == [1, 2, 3, 4, 5]


def test_call_strips_none_kwargs(client, respx_mock):
    route = respx_mock.post(TOOL_URL).mock(return_value=httpx.Response(200, json=_ok()))
    client.call("prism_introspect", foo=None, bar=1)
    body = json.loads(route.calls.last.request.content)
    assert "foo" not in body
    assert body["bar"] == 1
