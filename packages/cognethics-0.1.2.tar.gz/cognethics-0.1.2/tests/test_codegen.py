import json

import httpx


MEGA_TOOLS = (
    "entity_crud",
    "workflow_action",
    "report_query",
    "agent_command",
    "integration_call",
    "smart_action",
    "document_op",
    "notification_send",
    "config_manage",
)


def test_generated_tree_has_all_megatools():
    import importlib

    import cognethics.generated as gen

    for mt in MEGA_TOOLS:
        mod = importlib.import_module(f"cognethics.generated.{mt}")
        assert mod is not None, f"missing {mt}"
        # And the umbrella package should expose them as submodules
        assert hasattr(gen, mt) or mt in MEGA_TOOLS


def test_entity_crud_spare_parts_work_order_exists(client):
    fn = client.entity_crud.spare_parts.work_order.list
    assert callable(fn)


def test_ergonomic_invoices_list_calls_correct_endpoint(client, respx_mock):
    route = respx_mock.post("/api/mcp/tools/prism_entity_crud/").mock(
        return_value=httpx.Response(200, json={"success": True, "data": [], "meta": {}})
    )
    client.invoices.list(status="overdue")
    body = json.loads(route.calls.last.request.content)
    assert body == {
        "app": "finance",
        "entity": "invoice",
        "operation": "list",
        "filters": {"status": "overdue"},
        "page": 1,
        "page_size": 50,
    }


def test_ergonomic_reports_facade_calls_correct_endpoints(client, respx_mock):
    """ReportsFacade methods must hit prism_report_query with the right report_type.

    Regression guard for SDK-1: pre-0.1.1 the facade called bogus method names
    (`ap_summary`, `ar_summary`, `forecast`, `summary`) which 0.1.0 users hit as
    AttributeError. The fixed facade routes to `aging_ap_summary`,
    `aging_ar_summary`, `cash_flow_forecast`, `trial_balance_summary` — each of
    which serializes to a distinct ``report_type`` on the wire.
    """
    route = respx_mock.post("/api/mcp/tools/prism_report_query/").mock(
        return_value=httpx.Response(200, json={"success": True, "data": {}, "meta": {}})
    )

    expected = [
        ("ap_aging", {}, "ap_summary"),
        ("ar_aging", {}, "ar_summary"),
        ("cash_flow_forecast", {}, "forecast"),
        ("trial_balance", {}, "summary"),
    ]

    for method_name, kwargs, expected_report_type in expected:
        getattr(client.reports, method_name)(**kwargs)
        body = json.loads(route.calls.last.request.content)
        assert body.get("app") == "finance", (
            f"{method_name}: expected app=finance, got {body.get('app')!r}"
        )
        assert body.get("report_type") == expected_report_type, (
            f"{method_name}: expected report_type={expected_report_type!r}, "
            f"got {body.get('report_type')!r}"
        )

    # Sanity-check the broken pre-0.1.1 method names are NOT exposed on the
    # generated FinanceClient (`report_query.finance.finance`) — they would
    # silently mask the bug returning here.
    finance = client.report_query.finance.finance
    assert hasattr(finance, "aging_ap_summary"), (
        "FinanceClient should expose aging_ap_summary"
    )
    assert hasattr(finance, "aging_ar_summary"), (
        "FinanceClient should expose aging_ar_summary"
    )
    assert hasattr(finance, "cash_flow_forecast"), (
        "FinanceClient should expose cash_flow_forecast"
    )
    assert hasattr(finance, "trial_balance_summary"), (
        "FinanceClient should expose trial_balance_summary"
    )
    assert not hasattr(finance, "ap_summary"), (
        "Pre-0.1.1 broken name `ap_summary` should not exist on FinanceClient"
    )
    assert not hasattr(finance, "ar_summary"), (
        "Pre-0.1.1 broken name `ar_summary` should not exist on FinanceClient"
    )
    # `forecast` and `summary` collide across many entities — confirm the
    # bare names don't resolve at the FinanceClient level either.
    assert not hasattr(finance, "forecast"), (
        "Bare `forecast` should not exist; use `cash_flow_forecast` instead"
    )
    assert not hasattr(finance, "summary"), (
        "Bare `summary` should not exist; use entity-prefixed `<entity>_summary`"
    )
