import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
import respx

import cognethics._client as _client_mod


@pytest.fixture
def respx_mock():
    with respx.mock(base_url="http://localhost:8000") as r:
        yield r


@pytest.fixture
def client():
    from cognethics import Client

    return Client(api_key="mcp_testkey", base_url="http://localhost:8000")


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch):
    """Skip backoff sleeps so retry tests run instantly."""
    monkeypatch.setattr(_client_mod.time, "sleep", lambda *_a, **_k: None)
