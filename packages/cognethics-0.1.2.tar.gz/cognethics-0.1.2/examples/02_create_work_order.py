"""Create a maintenance work order via the Cognethics SDK.

Required fields per the platform's create-work-order handler:
- title (str)
- item_id (UUID of an existing spare_parts.Item in the API key's org)
- scheduled_datetime (ISO-8601 datetime, not a bare date)

Optional: priority (emergency|urgent|standard|routine), work_order_number,
assigned_technician_id, technician_skill_level, etc.

Env vars:
  COGNETHICS_API_KEY        — MCP API key starting with ``mcp_``
  COGNETHICS_BASE_URL       — defaults to http://localhost:8000
  COGNETHICS_DEMO_ITEM_ID   — UUID of an existing spare_parts.item in your org
"""
import os
from cognethics import Client

client = Client(
    api_key=os.environ["COGNETHICS_API_KEY"],
    base_url=os.environ.get("COGNETHICS_BASE_URL", "http://localhost:8000"),
)

# Replace ITEM_ID with a real spare_parts.item UUID in your org.
ITEM_ID = os.environ.get("COGNETHICS_DEMO_ITEM_ID", "<spare-parts-item-uuid>")

wo = client.entity_crud.spare_parts.work_order.create(data={
    "title": "Engine oil change - Engine #1",
    "item_id": ITEM_ID,
    "scheduled_datetime": "2026-05-20T09:00:00Z",
    "priority": "standard",
})
print(f"Created work order: {wo['data']['id']}")
