"""List overdue customer invoices via the Cognethics SDK.

Env vars:
  COGNETHICS_API_KEY   — MCP API key starting with ``mcp_``
  COGNETHICS_BASE_URL  — defaults to http://localhost:8000

The API key is bound to a single organization at mint time; that's the org the
list call runs against.
"""
import os
from cognethics import Client

client = Client(
    api_key=os.environ["COGNETHICS_API_KEY"],
    base_url=os.environ.get("COGNETHICS_BASE_URL", "http://localhost:8000"),
)

result = client.entity_crud.finance.invoice.list(filters={"status": "overdue"}, page_size=20)
rows = result.get("data") or []
print(f"Found {len(rows)} overdue invoices")
for inv in rows:
    print(f"{inv.get('id')} | {inv.get('customer_name')} | {inv.get('amount')}")
