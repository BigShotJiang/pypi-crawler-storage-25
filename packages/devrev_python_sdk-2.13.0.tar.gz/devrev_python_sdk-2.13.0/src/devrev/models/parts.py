"""Part models for DevRev SDK."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import Field

from devrev.models.base import (
    DevRevBaseModel,
    DevRevResponseModel,
    PaginatedResponse,
    UserSummary,
)


class PartType(StrEnum):
    """Part type enumeration."""

    PRODUCT = "product"
    CAPABILITY = "capability"
    FEATURE = "feature"
    ENHANCEMENT = "enhancement"


class Part(DevRevResponseModel):
    """DevRev Part model."""

    id: str = Field(..., description="Part ID")
    display_id: str | None = Field(default=None, description="Display ID")
    name: str = Field(..., description="Part name")
    type: PartType | None = Field(default=None, description="Part type")
    description: str | None = Field(default=None, description="Description")
    owned_by: list[UserSummary] | None = Field(default=None, description="Owners")
    created_date: datetime | None = Field(default=None, description="Creation date")
    modified_date: datetime | None = Field(default=None, description="Last modified")


class PartSummary(DevRevResponseModel):
    """Summary of a Part.

    This model represents the part object returned in work item responses.
    The API returns a rich object with type, display_id, name, etc.
    """

    id: str = Field(..., description="Part ID")
    type: str | None = Field(default=None, description="Part type (product, capability, etc.)")
    display_id: str | None = Field(default=None, description="Display ID (e.g., PROD-1)")
    name: str | None = Field(default=None, description="Part name")
    state: str | None = Field(default=None, description="Part state (active, archived, etc.)")
    owned_by: list[UserSummary] | None = Field(default=None, description="Part owners")


class PartsCreateRequest(DevRevBaseModel):
    """Request to create a part.

    For non-product parts (capability, feature, enhancement), the parent_part
    parameter is required to specify the parent part in the hierarchy.
    """

    name: str = Field(..., description="Part name")
    type: PartType = Field(..., description="Part type")
    description: str | None = Field(default=None, description="Description")
    owned_by: list[str] | None = Field(
        default=None,
        description="List of owner user IDs (e.g., ['DEVU-4'] or full DON IDs)",
    )
    parent_part: list[str] | None = Field(
        default=None,
        description="Parent part ID (required for capability/feature/enhancement). "
        "Array with at most 1 element.",
        max_length=1,
    )
    tags: list[str] | None = Field(default=None, description="List of tag IDs")


class PartsGetRequest(DevRevBaseModel):
    """Request to get a part by ID."""

    id: str = Field(..., description="Part ID")


class PartsDeleteRequest(DevRevBaseModel):
    """Request to delete a part."""

    id: str = Field(..., description="Part ID to delete")


class PartsListRequest(DevRevBaseModel):
    """Request to list parts."""

    cursor: str | None = Field(default=None, description="Pagination cursor")
    limit: int | None = Field(default=None, ge=1, le=100, description="Max results")
    type: list[PartType] | None = Field(default=None, description="Filter by type")


class PartsUpdateRequest(DevRevBaseModel):
    """Request to update a part."""

    id: str = Field(..., description="Part ID")
    name: str | None = Field(default=None, description="New name")
    description: str | None = Field(default=None, description="New description")


class PartsCreateResponse(DevRevResponseModel):
    """Response from creating a part."""

    part: Part = Field(..., description="Created part")


class PartsGetResponse(DevRevResponseModel):
    """Response from getting a part."""

    part: Part = Field(..., description="Retrieved part")


class PartsListResponse(PaginatedResponse):
    """Response from listing parts."""

    parts: list[Part] = Field(..., description="List of parts")


class PartsUpdateResponse(DevRevResponseModel):
    """Response from updating a part."""

    part: Part = Field(..., description="Updated part")


class PartsDeleteResponse(DevRevResponseModel):
    """Response from deleting a part."""

    pass
