# Changelog

All notable changes to the DevRev Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.13.0] - 2026-04-08

### Added

- **Article content format detection and bidirectional conversion** (#160, PR #205)
  - `detect_content_format()` — detects `devrev/rt`, `text/markdown`, `text/html`, or `text/plain`
  - `devrev_rt_to_markdown()` — converts ProseMirror JSON to Markdown
  - `devrev_rt_to_html()` — converts ProseMirror JSON to HTML with XSS-safe escaping
  - `OutputFormat` type alias (`Literal["text/markdown", "text/html", "devrev/rt"]`)
  - Four format constants: `CONTENT_FORMAT_DEVREV_RT`, `CONTENT_FORMAT_MARKDOWN`, `CONTENT_FORMAT_HTML`, `CONTENT_FORMAT_PLAIN`
  - `get_with_content()` (sync + async) now accepts optional `output_format` parameter for automatic content conversion
  - MCP tool `devrev_articles_get` accepts `output_format` when `include_content=True`
  - `_convert_content()` validates output format and raises `ValueError` for invalid values
  - All HTML output uses `html.escape()` for text and attributes; links include `rel="noopener noreferrer"`

## [2.12.2] - 2026-04-08

### Maintenance

- **CI dependency updates** — Merged 4 Dependabot PRs:
  - PR #199: Bump `peter-evans/create-pull-request` from 6 to 8
  - PR #201: Bump uv group dependencies (2 updates)
  - PR #202: Bump `actions/configure-pages` from 4 to 6
  - PR #203: Bump `codecov/codecov-action` from 5 to 6

## [2.12.1] - 2026-04-07

### Fixed

- **Search API Bad Request error** (#204) — Fixed `devrev_search_core_devrev` and `devrev_search_hybrid_devrev` MCP tools returning "Validation error: Bad Request" by changing `CoreSearchRequest` and `HybridSearchRequest` models to send `namespaces` (plural, array) instead of `namespace` (singular, string), matching the DevRev API specification.

### Maintenance

- **Cloud Build machine type** — Updated Cloud Build machine type from `N1_HIGHCPU_8` to `E2_HIGHCPU_8`.

## [2.10.2] - 2026-03-11

### Fixed

- **Parts API missing parameters** (#158) — Added `owned_by`, `parent_part`, and `tags` parameters to `devrev_parts_create` MCP tool for full API compatibility.
- **Article API missing properties** (#159) — Added missing `access_level`, `authored_by`, `extracted_content`, `owned_by`, `published_at`, `scope`, `shared_with`, `tags`, and `verified_by` fields to article models.

### Maintenance

- **Dependency updates** (#182) — Consolidated Dependabot updates (March 2026):
  - Multiple dependency version updates via automated security scanning
- **Documentation** — Updated `llms.txt` and `llms-mcp.txt` version references to 2.10.1.

## [2.10.1] - 2026-03-10

### Fixed

- **MCP articles_list bug** (#170) — Fixed `'tuple' object has no attribute 'model_dump'` error in `devrev_articles_list` MCP tool by correctly accessing `response.articles` instead of calling `list()` on the Pydantic response model. Added `paginated_response()` helper for consistent pagination handling.
- **CI formatting** (#175) — Resolved formatting check failures in `scripts/debug_articles.py`.

### Maintenance

- **Dependency updates** (#177) — Consolidated Dependabot updates:
  - `actions/download-artifact` v7 → v8
  - `codecov/codecov-action` v3 → v5
  - `google-github-actions/auth` v2 → v3
  - `authlib` 1.6.6 → 1.6.9 (security fix: removes "none" algorithm from default JWT instance)

## [2.10.0] - 2026-03-09

### Added

- **Article Scope and Tags** (#173) — Added visibility and tagging parameters to MCP article tools:
  - `devrev_articles_create`: Added `scope` (1=internal, 2=external) and `tags` (list of tag IDs) parameters
  - `devrev_articles_update`: Added `access_level` (internal, external, private, public) and `tags` parameters
  - SDK `update_with_content`: Added `access_level` and `tags` parameters for both sync and async methods

## [2.9.0] - 2026-03-09

### Added

- **Article Part Association** (#171) — Added `applies_to_parts` parameter to MCP `articles_create` and `articles_update` tools, and SDK `update_with_content` method for native article-to-part association

## [2.8.1] - 2026-03-06

### Fixed

- **CI/CD** — Installed the `mcp` extra in the integration workflow so MCP dependencies are available during integration runs.
- **Articles integration test** — Updated the articles integration test to match the current response shape.

## [2.8.0] - 2026-03-01

### Added

- **Unified Article Management** (#161) — Simplified article and artifact workflows:
  - **SDK Unified Methods**: `create_with_content()`, `get_with_content()`, `update_content()`, `update_with_content()` automatically handle artifact storage
  - **Reduced Complexity**: Article operations reduced from 15-20 lines to 3-5 lines (70% reduction)
  - **Clear Parameters**: `content` for article body, `description` for metadata summary
  - **Lazy Loading**: `get()` returns metadata only, `get_with_content()` explicit opt-in for content
  - **Parent Client Reference**: Services can now access other services via optional parent client parameter
  - **MCP Tool Updates**: `devrev_articles_create`, `devrev_articles_get`, and `devrev_articles_update` use unified methods
  - **Async Support**: All unified methods available in both sync and async variants

### Changed

- **Article Model**: Added `resource` field to `Article` model for artifact reference storage
- **Base Services**: `BaseService` and `AsyncBaseService` now accept optional `parent_client` parameter

## [2.7.0] - 2026-02-28

### Added

- **Server Version Discoverability**: AI agents can now discover the server's version, capabilities, and update status dynamically
  - **Server Instructions**: `FastMCP` constructor includes `instructions` parameter with version info, delivered to agents on connection
  - **`devrev_server_info` Tool**: Returns server version, uptime, Python version, platform, enabled capabilities, and checks PyPI for the latest published version
  - **`devrev://server/info` Resource**: Static server metadata resource for agents preferring resource-based discovery
  - **PyPI Version Check**: Runtime check against PyPI to determine if the server is running the latest version, with graceful degradation on network failure

### Fixed

- **Version Comparison**: `_compare_versions` now catches `InvalidVersion` from the `packaging` library for graceful degradation with malformed version strings

## [2.6.0] - 2026-02-28

### Added

- **Compliance-grade audit logging** (#153, #155) — Structured JSON audit events for all MCP operations:
  - 5 event types: `auth_success`, `auth_failure`, `tool_invocation`, `resource_access`, `prompt_invocation`
  - Tool classification (read/write/delete/search) for risk categorization
  - Request metadata enrichment: `User-Agent`, `X-Forwarded-For`, `trace_id` (GCP Cloud Trace)
  - Truncation for user-controlled headers (512 chars UA/XFF, 64 chars trace)
  - GCS bucket with WORM retention policy for immutable log storage
  - Cloud Logging sink, monitoring alert policies, and dashboard
  - 31 audit-specific tests, 793 total tests passing

### Documentation

- **MCP Server documentation** (#149) — Added MCP Server to docs site homepage, README features, and navigation with Augment Code-inspired styling
- **LLM context files** (#151) — Updated all `llms*.txt` files with MCP Server coverage, created `llms-mcp.txt`, served from docs site via MkDocs hook
- Version bumped across all LLM context files

### Security

- **cryptography** 46.0.3 → 46.0.5 (CVE-2026-26007: binary elliptic curve key leak)
- **nltk** 3.9.2 → 3.9.3 (CVE-2025-14009: secure ZIP extraction)

### Fixed

- `__version__` now reads from `importlib.metadata` instead of hardcoded string — pyproject.toml is single source of truth
- Removed unused `_IMAGE` substitution from `cloudbuild.yaml`
- Fixed `$COMMIT_SHA` refs in `cloudbuild.yaml` for manual builds (replaced with `$SHORT_SHA`)
- Added Cloud Run hostname to `MCP_ALLOWED_HOSTS` for DNS rebinding protection

### Performance

- Set `min-instances=1` on Cloud Run to eliminate cold starts

### Changed

- Updated Dockerfile version labels

## [2.4.1] - 2026-02-27

### Fixed
- **CI: Resolved all 99 mypy strict-mode type errors** (#145) — Added type annotations across the MCP server codebase and configured mypy overrides for untyped third-party packages (mcp, starlette, httpx).
- **CI: Added mypy overrides for untyped BaseHTTPMiddleware subclassing** — Suppressed `[misc]` errors for Starlette middleware that lacks type stubs.
- **CI: Installed MCP optional dependency for unit tests** — Fixed test collection failures by ensuring `mcp` extras are installed in CI.
- **Style: Auto-formatted code after mypy type annotation additions** — Applied ruff formatting to files modified during mypy fixes.

## [2.4.0] - 2026-02-25

### Added
- **MCP Server: Per-user DevRev PAT authentication** (#145) — The MCP server now supports per-user authentication using DevRev Personal Access Tokens. Each user sends their own DevRev PAT as the Bearer token, which the server validates against the DevRev API and uses to create a per-request client. This provides better security, audit trails, and eliminates shared secrets.
  - New auth mode: `MCP_AUTH_MODE=devrev-pat` (default)
  - Domain restrictions: `MCP_AUTH_ALLOWED_DOMAINS` to limit access by email domain
  - Token caching: `MCP_AUTH_CACHE_TTL_SECONDS` for validation cache (default 5 minutes)
  - Legacy mode: `MCP_AUTH_MODE=static-token` still supported for backward compatibility
  - Updated Cloud Run deployment to use per-user PAT mode by default
  - Updated documentation and client configuration examples

### Fixed
- **SDK: Articles API field naming** — Fixed field name from `content` to `description` to match DevRev API specification. Updated `Article`, `ArticlesCreateRequest`, and `ArticlesUpdateRequest` models. **BREAKING CHANGE**: Code using `article.content` or `ArticlesCreateRequest(content=...)` must be updated to use `description` instead.

### Changed
- **SDK: Migrated all enums from `(str, Enum)` to `StrEnum`** — 32 enum classes across 21 files now use Python 3.11+ `StrEnum` instead of the legacy `(str, Enum)` pattern. This resolves ruff UP042 linting errors and aligns with modern Python best practices. Note: `str(EnumMember)` now returns the value string directly (e.g., `"active"`) instead of `"ClassName.MEMBER"`. (#138)

## [2.3.1] - 2026-02-24

### Fixed

- **DevUserState enum missing states** (#126) - Added missing `DELETED`, `LOCKED`, and `UNASSIGNED` states to the `DevUserState` enum to match the DevRev API `user-state` schema. This is the same fix previously applied to `RevUserState` in v2.1.1 (#115). This fixes Pydantic validation errors when the API returns dev users with these states.

## [2.3.0] - 2026-02-11

### Added
- **Client-side re-ranking** for hybrid search — boosts results where query is a substring of display_name/title
- **Dynamic `_extract_display_name`** — supports all 35 DevRev namespace types for re-ranking
- **MCP Inspector compatibility** — `__main__.py` uses `parse_known_args()` to handle extra arguments

### Fixed
- **SDK: SearchNamespace enum** — Expanded from 9 to 35 values matching all API-supported namespaces
- **SDK: Namespace serialization** — Fixed `namespaces` (plural) → `namespace` (singular) via `serialization_alias`
- **SDK: Namespace type** — Fixed from `list[SearchNamespace]` to single `SearchNamespace` value
- **SDK: SearchResult model** — Restructured with entity-specific dicts, added `modified_date` and `comments` fields
- **SDK: Limit validation** — Added `Field(ge=0, le=50)` to enforce API constraints (was default 25/max 100, now 10/50)
- **Core search ordering** — `devrev_search_core` no longer applies re-ranking, preserving API ordering
- **Namespace parsing resilience** — Handles whitespace, embedded quotes, and case variations from MCP Inspector

### Changed
- Search limit defaults changed from 25 → 10 (matches DevRev API default)
- Search limit maximum changed from 100 → 50 (matches DevRev API constraint)

## [2.2.0] - 2026-02-09

### Added - DevRev MCP Server (Model Context Protocol)

This release introduces a full-featured MCP server that exposes the entire DevRev platform as AI-accessible tools, resources, and prompts.

#### Phase 1: Core Foundation
- FastMCP server with async DevRev client lifecycle management
- `MCPServerConfig` (pydantic-settings) with 14+ configurable environment variables
- 22 initial tools: Works (7), Accounts (6), Users (5), Search beta (2), Recommendations beta (2)
- Pagination utilities with configurable page sizes
- Error formatting and model serialization helpers
- **SDK bug fix**: Enum conversion — `WorkType("TICKET")` fails because `str` enums have lowercase values; fixed to use `WorkType["TICKET"]` (bracket access by name)

#### Phase 2: Full Tool Coverage
- 42 additional tools across 7 modules: Conversations (6), Articles (6), Parts (5), Tags (5), Groups (8), Incidents beta (6), Engagements beta (6)
- Comprehensive KeyError handling for all enum conversions (ArticleStatus, EngagementType, PartType, GroupType, IncidentStage, IncidentSeverity)
- ValueError handling for datetime parsing in engagements

#### Phase 3: Resources & Prompts
- 7 resource templates with `devrev://` URI scheme (ticket, account, article, user/dev, user/rev, part, conversation)
- 8 workflow prompts: triage_ticket, draft_customer_response, escalate_ticket, summarize_account, investigate_issue, weekly_support_report, find_similar_tickets, onboard_customer
- Timeline tools (5), Links tools (4), SLA tools (5)

#### Phase 4: Transport & Security
- Multi-transport support: stdio (default), streamable-http (production), SSE (legacy)
- CLI arguments: `--transport`, `--host`, `--port`
- Bearer token authentication with timing-attack protection (`secrets.compare_digest`)
- Token-bucket rate limiting with LRU eviction (bounded memory, thread-safe)
- Health check endpoint (`GET /health`) with uptime tracking
- Destructive tool gating via `MCP_ENABLE_DESTRUCTIVE_TOOLS`
- DNS rebinding protection and CORS configuration

#### Phase 5: Polish & Deployment
- Dockerfile with multi-stage build and non-root user
- Docker Compose for local development
- Cloud Build configuration for Google Cloud Run deployment
- Comprehensive documentation in README.md
- This changelog entry

#### Bug Fixes (E2E Testing)
- **Critical: HTTP middleware never registered** — `FastMCP` creates its internal Starlette app lazily inside `streamable_http_app()` and `sse_app()`, not at construction time. The health endpoint, bearer token auth middleware, and rate limiting middleware were silently never injected. Fixed by monkey-patching `streamable_http_app()` and `sse_app()` on the `mcp` instance to inject middleware after the Starlette app is created.
- Confirmed 12/14 real API E2E tests pass (2 environmental: SLA 403 permissions, Search 400 beta not enabled)

### Fixed
- All enum conversions across tool modules now use bracket access (by name) with KeyError guards
- `datetime.fromisoformat()` calls wrapped in ValueError handlers
- Rate limiter: zero-RPM config no longer causes ZeroDivisionError
- Auth middleware: timing-safe token comparison prevents side-channel attacks
- Health endpoint: uptime calculated from lifespan init, not module import

## [2.1.2] - 2026-01-28

### Fixed

- **Work.applies_to_part fails to parse API response** (#120) - The DevRev API returns `applies_to_part` as a rich `PartSummary` object in responses, not just a string ID. This caused `pydantic.ValidationError` when parsing API responses. Fixed by:
  - Expanding `PartSummary` model to include `type`, `display_id`, `state`, and `owned_by` fields
  - Changing `Work.applies_to_part` type from `str | None` to `PartSummary | str | None`
  - This is fully backward compatible - string IDs are still accepted for requests

## [2.1.1] - 2026-01-23

### Fixed

- **RevUserState enum missing states** (#115) - Added missing `DEACTIVATED`, `LOCKED`, `SHADOW`, and `UNASSIGNED` states to the `RevUserState` enum to match the DevRev API `user-state` schema. This fixes Pydantic validation errors when the API returns users with these states.

## [2.0.0] - 2026-01-18

🚀 **Major Release** - Beta API support, performance enhancements, and 100% integration test coverage!

### Breaking Changes

#### GroupsMembersCountRequest Parameter Rename (#107)

**Breaking Change**: The `members_count` method parameter and `GroupsMembersCountRequest` model field were renamed to match the actual DevRev API field names.

**Changes Made**:
- **Method Parameter**: `members_count(id=...)` → `members_count(group_id=...)`
- **Model Field**: `GroupsMembersCountRequest.id` → `GroupsMembersCountRequest.group`

**Reason**: The OpenAPI specification and actual API use `group` as the field name, not `id`. This change aligns the SDK with the real API behavior discovered during integration testing.

**Migration**:
```python
# Before (incorrect)
count = client.groups.members_count(id="don:identity:dvrv-us-1:devo/abc123:group/xyz789")

# After (correct)
count = client.groups.members_count(group_id="don:identity:dvrv-us-1:devo/abc123:group/xyz789")
```

**Note**: There are no known existing consumers of this SDK, so the impact is minimal.

🚀 **Beta API Support** - Major release adding support for DevRev Beta API with 74 new endpoints!

This release introduces Beta API support alongside the existing Public API, providing access to advanced features including incident management, customer engagement tracking, AI-powered recommendations, and hybrid search.

### Highlights

- **Beta API Support**: Choose between Public (stable) and Beta (new features) API versions
- **7 New Beta Services**: Incidents, Engagements, Brands, UOMs, Question Answers, Recommendations, Search
- **74 New Endpoints**: Comprehensive coverage of beta API features
- **Fully Backwards Compatible**: All existing Public API functionality unchanged

### Added

#### Beta API Services (#79)
- **IncidentsService** - Incident lifecycle management with SLA integration (6 endpoints)
  - Create, get, list, update, delete, and group incidents
  - Support for incident stages: acknowledged, identified, mitigated, resolved
  - Severity levels: SEV0, SEV1, SEV2, SEV3
- **EngagementsService** - Customer engagement tracking (6 endpoints)
  - Create, get, list, update, delete, and count engagements
  - Support for engagement types: call, email, meeting, default
  - Member and parent relationship tracking
- **BrandsService** - Multi-brand management (5 endpoints)
  - Create, get, list, update, delete brands
  - Brand configuration and customization
- **UomsService** - Unit of Measurement for metering (6 endpoints)
  - Create, get, list, update, delete, count UOMs
  - Aggregation types: sum, minimum, maximum, unique_count, running_total, duration, latest, oldest
  - Metric scopes for usage tracking
- **QuestionAnswersService** - Q&A management (5 endpoints)
  - Create, get, list, update, delete question-answer pairs
  - Knowledge base integration
- **RecommendationsService** - AI-powered recommendations (2 endpoints)
  - Chat completions with OpenAI-compatible interface
  - Reply recommendations for support tickets
- **SearchService** - Advanced search capabilities (2 endpoints)
  - Core search with DevRev query language
  - Hybrid search combining keyword and semantic search
  - Search across multiple namespaces: accounts, articles, conversations, work, users

#### Additional Beta Services (#79)
- **PreferencesService** - User preference management (2 endpoints: get, update)
- **NotificationsService** - Notification sending (1 endpoint: send)
- **TrackEventsService** - Event tracking and analytics (1 endpoint: publish)

#### Configuration & API Version Selection (#79)
- `APIVersion` enum for selecting Public or Beta API
- `DEVREV_API_VERSION` environment variable (default: `public`)
- Client parameter: `DevRevClient(api_version=APIVersion.BETA)`
- Config object support: `DevRevConfig(api_version=APIVersion.BETA)`

#### Exception Handling (#79)
- `BetaAPIRequiredError` - Raised when accessing beta features without beta API enabled
- Clear error messages with migration guidance

#### Models & Enums (#79)
- **Incident Models**: `Incident`, `IncidentStage`, `IncidentSeverity`, `IncidentGroupItem`
- **Engagement Models**: `Engagement`, `EngagementType`
- **Brand Models**: `Brand`, `BrandCreate`, `BrandUpdate`
- **UOM Models**: `Uom`, `UomAggregationType`, `UomMetricScope`
- **Recommendation Models**: `ChatMessage`, `MessageRole`, `ChatCompletionRequest`, `TokenUsage`
- **Search Models**: `SearchNamespace`, `SearchResult`, `CoreSearchRequest`, `HybridSearchRequest`

### Changed

#### Enhanced Services with Beta Endpoints (#79)
- **AccountsService** - Added `count` endpoint (beta only)
- **ArticlesService** - Added `count` endpoint (beta only)
- **ConversationsService** - Added `export` endpoint (beta only)
- **GroupsService** - Added `members.count` endpoint (beta only)

### Configuration

New environment variable:
- `DEVREV_API_VERSION` - API version selection: `public` or `beta` (default: `public`)

### Documentation

- [Beta API Migration Guide](guides/beta-api.md) - Comprehensive migration guide
- [Beta Features Examples](examples/beta-features.md) - Runnable code examples
- [API Differences](api/beta-api-differences.md) - Detailed comparison of Public vs Beta APIs

### Backwards Compatibility

✅ **Fully Backwards Compatible**
- All Public API endpoints continue to work unchanged
- Default API version remains `public` for existing code
- Beta features are opt-in only
- No breaking changes to existing functionality

### Migration Guide

To use beta features:

```python
from devrev import DevRevClient, APIVersion

# Enable beta API
client = DevRevClient(api_version=APIVersion.BETA)

# Access beta services
incidents = client.incidents.list()
search_results = client.search.hybrid("authentication issues")
```

See the [Beta API Migration Guide](guides/beta-api.md) for complete details.

### Performance & Reliability (#78)

- Connection pooling with configurable limits for improved performance
- Fine-grained timeout configuration with `TimeoutConfig` class
- ETag caching for conditional requests to reduce bandwidth
- Circuit breaker pattern for automatic failure detection and recovery
- Structured JSON logging with `JSONFormatter` for production environments
- Health check methods (`health_check()`) for monitoring service availability
- `CircuitBreakerError` exception for circuit breaker state handling
- HTTP/2 support (optional, disabled by default)

### Integration Testing (#103, #104, #105, #106)

- 100% integration test coverage for all read-only endpoints
- Write operation testing strategy with TestDataManager
- Comprehensive integration test suite with 81 tests

### Bug Fixes

- Fix httpx URL resolution issues with leading slashes (#78)
- Fix circuit breaker off-by-one bug in HALF_OPEN transition (#78)
- Fix request attribute on synthetic 304 response (#78)
- Remove unused exception variables for linting (#76, #77)
- Address security audit findings (#76, #77)

### Changed
- Enhanced `DevRevConfig` with new performance and reliability settings
- Improved HTTP client with connection pooling and keep-alive support
- Updated logging to support both text and JSON formats

### Configuration

New environment variables and configuration options:
- `DEVREV_LOG_FORMAT` - Log format: `text` or `json` (default: `text`)
- `DEVREV_MAX_CONNECTIONS` - Maximum connection pool size (default: `100`)
- `DEVREV_MAX_KEEPALIVE_CONNECTIONS` - Maximum keep-alive connections (default: `20`)
- `DEVREV_KEEPALIVE_EXPIRY` - Keep-alive expiry in seconds (default: `30.0`)
- `DEVREV_HTTP2` - Enable HTTP/2 support (default: `false`)
- `DEVREV_CIRCUIT_BREAKER_ENABLED` - Enable circuit breaker (default: `true`)
- `DEVREV_CIRCUIT_BREAKER_THRESHOLD` - Failure threshold (default: `5`)
- `DEVREV_CIRCUIT_BREAKER_RECOVERY_TIMEOUT` - Recovery timeout in seconds (default: `30`)
- `DEVREV_CIRCUIT_BREAKER_HALF_OPEN_MAX_CALLS` - Test requests in half-open state (default: `3`)
- `DEVREV_API_VERSION` - API version selection: `public` or `beta` (default: `public`)

## [1.0.0] - 2026-01-13

🎉 **First Stable Release** of the DevRev Python SDK!

This release marks the completion of all four development phases, providing a production-ready SDK for interacting with the DevRev API.

### Highlights

- **Complete API Coverage**: Full support for all 209 DevRev public API endpoints
- **Type Safety**: Comprehensive Pydantic v2 models for all requests and responses
- **Sync & Async**: Both synchronous and asynchronous clients for maximum flexibility
- **Production Ready**: Security audited, 80%+ test coverage, and comprehensive documentation

### Added

#### Core SDK (Phase 2)
- `DevRevClient` - Synchronous client with context manager support
- `AsyncDevRevClient` - Async client with async context manager support
- HTTP client layer with automatic retry logic and exponential backoff
- Rate limit handling with Retry-After header support
- Configurable timeouts and max retries

#### Full API Coverage (Phase 3)
- **14 Service Classes** with both sync and async implementations:
  - `AccountsService` - Customer account management (7 endpoints)
  - `WorksService` - Work items: tickets, issues, tasks (6 endpoints)
  - `DevUsersService` - Internal user management (10 endpoints)
  - `RevUsersService` - External user management (7 endpoints)
  - `PartsService` - Product parts and components (5 endpoints)
  - `ArticlesService` - Knowledge base articles (5 endpoints)
  - `ConversationsService` - Customer conversations (5 endpoints)
  - `TagsService` - Tagging and categorization (5 endpoints)
  - `GroupsService` - User group management (6 endpoints)
  - `WebhooksService` - Webhook configuration (6 endpoints)
  - `SlasService` - Service level agreements (6 endpoints)
  - `TimelineEntriesService` - Activity timeline (5 endpoints)
  - `LinksService` - Object relationships (5 endpoints)
  - `CodeChangesService` - Code change tracking (5 endpoints)

#### Pydantic Models
- 130+ Pydantic v2 models with strict validation
- Enums for type-safe status, priority, and severity values
- Date filters and pagination models
- Request/response models for all endpoints

#### Pagination Utilities
- `Paginator` and `AsyncPaginator` classes for iterating through results
- Cursor-based pagination following DevRev API patterns
- Helper functions: `paginate()` and `async_paginate()`

#### Documentation (Phase 4)
- Documentation site with MkDocs Material theme
- Comprehensive API reference documentation
- Tutorials and guides for common use cases
- Example applications (basic, advanced, integrations)
- Getting started guide with authentication options

#### Examples
- Basic examples: list accounts, create work items, search users
- Async example with concurrent requests
- Pagination and error handling examples
- Integration examples: FastAPI, Flask, Google Cloud Functions

#### Testing & Quality
- 180+ unit tests with 80%+ code coverage
- Integration test scaffolding for API validation
- Performance benchmarking framework
- ruff linting and mypy strict type checking

#### Security
- **HTTPS Enforcement**: Validation rejects insecure HTTP URLs in `base_url`
- Security audit completed with `bandit` (5,189 lines scanned, 0 issues)
- Dependency audit completed with `pip-audit` (0 known vulnerabilities)
- Token masking with Pydantic `SecretStr`
- SECURITY.md with security policy and best practices

#### CI/CD
- GitHub Actions workflows for CI, documentation, and release
- Automated release workflow triggered by version tags
- Dependabot configuration for dependency updates

### Developer Experience

- Full type annotations with mypy strict mode compliance
- IDE autocomplete support with comprehensive type hints
- Google-style docstrings throughout
- Colored logging support with configurable levels
- Environment-based configuration

### Python Support

- Python 3.11, 3.12, and 3.13 supported
- N-2 version support policy

## [0.1.0] - 2026-01-12

### Added
- Initial release of DevRev Python SDK
- Full API coverage for 209 DevRev public endpoints
- Synchronous and asynchronous clients (`DevRevClient`, `AsyncDevRevClient`)
- Pydantic v2 models for all requests and responses
- Automatic retry with exponential backoff
- Rate limit handling with Retry-After support
- Comprehensive exception hierarchy
- Environment-based configuration
- Colored logging support

### Services Implemented
- Accounts (7 endpoints)
- Works (6 endpoints)
- Dev Users (10 endpoints)
- Rev Users (7 endpoints)
- Parts (5 endpoints)
- Articles (5 endpoints)
- Conversations (5 endpoints)
- Tags (5 endpoints)
- Groups (6 endpoints)
- Webhooks (6 endpoints)
- SLAs (6 endpoints)
- Timeline Entries (5 endpoints)
- Links (5 endpoints)
- Code Changes (5 endpoints)

### Developer Experience
- Full type annotations
- IDE autocomplete support
- Comprehensive docstrings
- Unit and integration test suite (80%+ coverage)

---

## Version History

| Version | Date | Highlights |
|---------|------|------------|
| 2.7.0 | 2026-02-28 | 🔍 Server version discoverability for AI agents |
| 2.6.0 | 2026-02-28 | 🔐 Compliance-grade audit logging, MCP documentation |
| 2.4.1 | 2026-02-27 | 🐛 CI: mypy strict-mode type errors, test collection |
| 2.4.0 | 2026-02-25 | 🔑 MCP Server: Per-user DevRev PAT authentication |
| 2.3.1 | 2026-02-24 | 🐛 Fix DevUserState enum missing states |
| 2.3.0 | 2026-02-11 | 🔍 Search SDK improvements & client-side re-ranking |
| 2.2.0 | 2026-02-09 | 🤖 MCP Server - Full DevRev platform as AI-accessible tools |
| 2.1.2 | 2026-01-28 | 🐛 Fix Work.applies_to_part parsing for API responses |
| 2.1.1 | 2026-01-23 | 🐛 Fix RevUserState enum missing states |
| 2.0.0 | 2026-01-18 | 🚀 Beta API support, performance enhancements, breaking change |
| 1.0.0 | 2026-01-13 | 🎉 First stable release - Production ready |
| 0.1.0 | 2026-01-12 | Initial development release |

## Upgrading

### From 1.0.0 to 2.0.0

The v2.0.0 release includes Beta API support, performance enhancements, and one breaking change:

#### Breaking Change

- **GroupsMembersCountRequest Parameter Rename**: `members_count(id=...)` → `members_count(group_id=...)`

#### New Features

- **Beta API Support**: 7 new beta services with 74 endpoints available when you enable beta API
- **Performance Enhancements**: Connection pooling, circuit breaker, ETag caching
- **Integration Tests**: 100% coverage of read-only endpoints

To use beta features, enable the beta API:

```python
from devrev import DevRevClient, APIVersion

# Enable beta API
client = DevRevClient(api_version=APIVersion.BETA)
```

See the [Beta API Migration Guide](guides/beta-api.md) for complete details.

### From 0.1.0 to 1.0.0

The v1.0.0 release includes one breaking change and several enhancements:

- **HTTPS Required (Breaking Change)**: The SDK now enforces HTTPS URLs for `base_url`. If you were using HTTP URLs (e.g., for local testing), you will need to update to HTTPS. Note that the official DevRev API only supports HTTPS, so this should not affect production usage.
- **New Services**: 10 additional service classes are now available
- **Enhanced Error Messages**: More detailed error information is provided

All existing API calls remain compatible - only the HTTPS enforcement may require configuration changes for non-production environments.

## Reporting Issues

Found a bug or have a suggestion? Please [open an issue](https://github.com/mgmonteleone/py-dev-rev/issues/new).

