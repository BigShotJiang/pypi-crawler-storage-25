import logging
from typing import TypeVar, cast

import numpy as np
from rich.progress import track
from upath import UPath

from ..dataset import Dataset
from ..dataset.defaults import DEFAULT_CHUNK_SHAPE, DEFAULT_DATA_FORMAT
from ..dataset.layer.abstract_layer import LayerCategoryType
from ..dataset_properties import DataFormat, LayerProperties
from ..geometry import BoundingBox, Mag, Vec3Int
from .api_client.models import ApiUnusableDataSource
from .context import _get_context

logger = logging.getLogger(__name__)


T = TypeVar("T")


_DOWNLOAD_CHUNK_SHAPE = Vec3Int(512, 512, 512)


def download_dataset(
    dataset_id: str,
    *,
    sharing_token: str | None = None,
    bbox: BoundingBox | None = None,
    layers: list[str] | None = None,
    mags: list[Mag] | None = None,
    path: UPath | str | None = None,
    exist_ok: bool = False,
    data_format: DataFormat | None = None,
) -> Dataset:
    context = _get_context()
    api_client = context.api_client
    api_dataset = api_client.dataset_info(
        dataset_id=dataset_id, sharing_token=sharing_token
    )

    datastore_client = context.get_datastore_api_client(api_dataset.data_store.url)

    download_path = (
        UPath(f"{api_dataset.name}-{api_dataset.id}") if path is None else UPath(path)
    )
    if download_path.exists():
        logger.warning(f"{download_path} already exists, skipping download.")
        return Dataset.open(download_path)
    if isinstance(api_dataset.data_source, ApiUnusableDataSource):
        raise RuntimeError(
            f"The dataset {api_dataset.id} is unusable {api_dataset.data_source.status}"
        )
    api_data_layers = api_dataset.data_source.data_layers
    scale = api_dataset.data_source.scale

    dataset = Dataset(
        download_path,
        name=api_dataset.name,
        voxel_size_with_unit=scale,
        exist_ok=exist_ok,
    )
    for layer_name in layers or [i.name for i in api_data_layers]:
        matching_api_data_layers = [i for i in api_data_layers if i.name == layer_name]
        assert len(matching_api_data_layers) > 0, (
            f"The provided layer name {layer_name} could not be found in the requested dataset."
        )
        assert len(matching_api_data_layers) == 1, (
            f"The provided layer name {layer_name} was found multiple times in the requested dataset."
        )
        api_data_layer: LayerProperties = matching_api_data_layers[0]
        category = cast(LayerCategoryType, api_data_layer.category)
        layer = dataset.add_layer(
            layer_name=layer_name,
            category=category,
            data_format=data_format or DEFAULT_DATA_FORMAT,
            dtype=api_data_layer.dtype_np,
            num_channels=api_data_layer.bounding_box.size.c,
            largest_segment_id=getattr(api_data_layer, "largest_segment_id", None),
        )

        layer.default_view_configuration = api_data_layer.default_view_configuration

        if bbox is None:
            layer.bounding_box = api_data_layer.bounding_box
        else:
            assert isinstance(bbox, BoundingBox), (
                f"Expected a BoundingBox object for the bbox parameter but got {type(bbox)}"
            )
            layer.bounding_box = bbox
        if mags is None:
            mags = [mag_view.mag for mag_view in api_data_layer.mags]
        for mag in mags:
            mag_view = layer.get_or_add_mag(
                mag,
                compress=True,
                chunk_shape=DEFAULT_CHUNK_SHAPE,
                shard_shape=_DOWNLOAD_CHUNK_SHAPE
                if data_format != DataFormat.Zarr
                else DEFAULT_CHUNK_SHAPE,
            )
            aligned_bbox = layer.bounding_box.align_with_mag(mag, ceil=True)
            download_chunk_shape_in_mag = _DOWNLOAD_CHUNK_SHAPE * mag.to_vec3_int()
            for chunk in track(
                list(
                    aligned_bbox.chunk(
                        download_chunk_shape_in_mag, download_chunk_shape_in_mag
                    )
                ),
                description=f"Downloading layer={layer.name} mag={mag}",
            ):
                chunk_in_mag = chunk.in_mag(mag)
                chunk_bytes, missing_buckets = datastore_client.dataset_get_raw_data(
                    dataset_id=dataset_id,
                    data_layer_name=layer_name,
                    mag=mag.to_long_layer_name(),
                    sharing_token=sharing_token,
                    x=chunk.topleft.x,
                    y=chunk.topleft.y,
                    z=chunk.topleft.z,
                    width=chunk_in_mag.size.x,
                    height=chunk_in_mag.size.y,
                    depth=chunk_in_mag.size.z,
                )
                assert missing_buckets == "[]", (
                    f"Download contained missing buckets {missing_buckets}."
                )
                data = np.frombuffer(chunk_bytes, dtype=layer.dtype).reshape(
                    layer.num_channels, *chunk_in_mag.size, order="F"
                )
                mag_view.write(data, absolute_offset=chunk.topleft)
    return dataset
