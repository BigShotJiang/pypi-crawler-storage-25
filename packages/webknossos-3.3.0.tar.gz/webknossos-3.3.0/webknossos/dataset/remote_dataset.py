import copy
import inspect
import logging
import tempfile
import warnings
from collections.abc import Callable, Mapping, Sequence
from datetime import datetime
from enum import Enum
from os import PathLike
from typing import TYPE_CHECKING, Any, Literal, Union

import attr
from boltons.typeutils import make_sentinel
from cluster_tools import Executor
from numpy.typing import DTypeLike
from upath import UPath

from webknossos.client import webknossos_context
from webknossos.client.api_client.models import (
    ApiAttachmentRenaming,
    ApiDataset,
    ApiDatasetComposeLayer,
    ApiDatasetExploreAndAddRemote,
    ApiLayerRenaming,
    ApiMetadata,
    ApiUnusableDataSource,
)
from webknossos.dataset._metadata import DatasetMetadata
from webknossos.dataset.abstract_dataset import (
    _DATASET_DEPRECATED_URL_REGEX,
    _DATASET_URL_REGEX,
    AbstractDataset,
    AttachmentRenaming,
    LayerRenaming,
    _dtype_maybe,
)
from webknossos.dataset.layer import RemoteLayer, RemoteSegmentationLayer, Zarr3Config
from webknossos.dataset.layer.abstract_layer import (
    _validate_layer_name,
)
from webknossos.dataset.sampling_modes import SamplingModes
from webknossos.dataset_properties import (
    COLOR_CATEGORY,
    SEGMENTATION_CATEGORY,
    DataFormat,
    DatasetProperties,
    LayerCategoryType,
    LayerProperties,
    SegmentationLayerProperties,
    VoxelSize,
)
from webknossos.geometry import BoundingBox, NDBoundingBox, Vec3Int, Vec3IntLike
from webknossos.geometry.mag import Mag, MagLike
from webknossos.utils import infer_metadata_type, warn_deprecated

from ..client.api_client.errors import UnexpectedStatusError
from ..ssl_context import SSL_CONTEXT
from .defaults import DEFAULT_DATA_FORMAT, DEFAULT_DTYPE
from .remote_dataset_registry import RemoteDatasetRegistry
from .remote_folder import RemoteFolder
from .transfer_mode import TransferMode

logger = logging.getLogger(__name__)
_UNSET = make_sentinel("UNSET", var_name="_UNSET")


if TYPE_CHECKING:
    from webknossos.administration.user import Team
    from webknossos.dataset import Dataset
    from webknossos.dataset.layer import Layer


def _assert_same_webknossos_instance(
    dataset1: "RemoteDataset",
    dataset2: "RemoteDataset",
    action: str,
) -> None:
    if dataset1._context._url != dataset2._context._url:
        raise ValueError(
            f"Cannot {action} from a different WEBKNOSSOS instance. "
            + f"Got {dataset2._context._url}, expected {dataset1._context._url}."
        )


class RemoteAccessMode(Enum):
    """Determines how data of a remote dataset is accessed. Note that DIRECT_PATH can only be used if the client has access to the underlying storage."""

    ZARR_STREAMING = "zarr_streaming"
    DIRECT_PATH = "direct_path"
    PROXY_PATH = "proxy_path"


class RemoteDataset(AbstractDataset[RemoteLayer, RemoteSegmentationLayer]):
    """A representation of a dataset managed by a WEBKNOSSOS server.

    This class is returned from `RemoteDataset.open()` and provides read-only access to
    image data streamed from the webknossos server. It uses the same interface as `Dataset`
    but additionally allows metadata manipulation through properties.
    In case of zarr streaming, an even smaller subset of metadata manipulation is possible.

    Properties:
        metadata: Dataset metadata as key-value pairs
        name: Human readable name
        description: Dataset description
        tags: Dataset tags
        is_public: Whether dataset is public
        sharing_token: Dataset sharing token
        allowed_teams: Teams with dataset access
        folder: Dataset folder location

    Examples:
        Opening a remote dataset with organization ID:
        ```
        ds = RemoteDataset.open("my_dataset", "org_id")
        ```

        Opening with dataset URL:
        ```
        ds = RemoteDataset.open("https://webknossos.org/datasets/org/dataset/view")
        ```

        Setting metadata:
        ```
        ds.metadata = {"key": "value", "tags": ["tag1", "tag2"]}
        ds.name = "My_Dataset"
        ds.allowed_teams = [Team.get_by_name("Lab_A")]
        ```

    Note:
        Do not instantiate directly, use `RemoteDataset.open()` or `RemoteDataset.open_remote` instead.
    """

    def __init__(
        self,
        *,
        zarr_streaming_path: UPath | None,
        dataset_properties: DatasetProperties | None,
        dataset_id: str,
        annotation_id: str | None,
        context: webknossos_context,
        read_only: bool,
    ) -> None:
        """Initialize a remote dataset instance.

        Args:
            zarr_streaming_path: Path to the zarr streaming directory
            dataset_properties: Properties of the remote dataset
            dataset_id: dataset id of the remote dataset
            context: Context manager for WEBKNOSSOS connection

        Raises:
            FileNotFoundError: If dataset cannot be opened as zarr format and no metadata exists

        Note:
            Do not call this constructor directly, use RemoteDataset.open() instead.
            This class provides access to remote WEBKNOSSOS datasets with additional metadata manipulation.
        """
        assert (zarr_streaming_path is not None) != (dataset_properties is not None), (
            "Either zarr_streaming_path or dataset_properties must be set, but not both."
        )
        self.zarr_streaming_path = zarr_streaming_path
        self._use_zarr_streaming = zarr_streaming_path is not None
        if self._use_zarr_streaming:
            dataset_properties = self._load_dataset_properties()

        assert dataset_properties is not None
        super().__init__(dataset_properties, read_only)

        self._dataset_id = dataset_id
        self._annotation_id = annotation_id
        self._context = context

    @classmethod
    def open(
        cls,
        dataset_name_or_url: str | None = None,
        *,
        organization_id: str | None = None,
        sharing_token: str | None = None,
        webknossos_url: str | None = None,
        dataset_id: str | None = None,
        annotation_id_or_url: str | None = None,
        access_mode: RemoteAccessMode | None = None,
        read_only: bool = False,
        use_zarr_streaming: bool | None = None,
    ) -> "RemoteDataset":
        """Opens a remote webknossos dataset. Image data is accessed via network requests.
        Dataset metadata such as allowed teams or the sharing token can be read and set
        via the respective `RemoteDataset` properties.

        Args:
            dataset_name_or_url: Either dataset name or full URL to dataset view, e.g.
                https://webknossos.org/datasets/scalable_minds/l4_sample_dev/view
            organization_id: Optional organization ID if using dataset name. Can be found [here](https://webknossos.org/auth/token)
            sharing_token: Optional sharing token for dataset access
            webknossos_url: Optional custom webknossos URL, defaults to context URL, usually https://webknossos.org
            dataset_id: Optional unique ID of the dataset
            annotation_id_or_url: Optional unique ID or URL of the annotation to stream the data from the annotation.
            access_mode: Access mode for the dataset. Defaults to RemoteAccessMode.ZARR_STREAMING.
            use_zarr_streaming: Whether to use zarr streaming. Deprecated, use access_mode instead.

        Returns:
            RemoteDataset: Dataset instance for remote access

        Examples:
            ```
            ds = RemoteDataset.open("`https://webknossos.org/datasets/scalable_minds/l4_sample_dev/view`")
            ```

        Note:
            If supplying an URL, organization_id, webknossos_url and sharing_token
            must not be set.
        """

        if use_zarr_streaming is not None:
            if access_mode is not None:
                raise ValueError(
                    "Both use_zarr_streaming and access_mode were provided. Only one is allowed."
                )
            warn_deprecated("use_zarr_streaming", "access_mode")
            if use_zarr_streaming:
                access_mode = RemoteAccessMode.ZARR_STREAMING
            else:
                access_mode = RemoteAccessMode.DIRECT_PATH

        if access_mode is None:
            access_mode = RemoteAccessMode.ZARR_STREAMING

        if (
            annotation_id_or_url is not None
            and access_mode != RemoteAccessMode.ZARR_STREAMING
        ):
            raise ValueError(
                "Annotations are only supported with zarr streaming. "
                + f"Got {access_mode} instead."
            )

        from ..client.context import _get_context

        (context_manager, dataset_id, annotation_id, sharing_token) = cls._parse_remote(
            dataset_name_or_url=dataset_name_or_url,
            organization_id=organization_id,
            sharing_token=sharing_token,
            webknossos_url=webknossos_url,
            dataset_id=dataset_id,
            annotation_id_or_url=annotation_id_or_url,
        )

        with context_manager:
            wk_context = _get_context()
            token = sharing_token or wk_context.token
            api_dataset_info = wk_context.api_client.dataset_info(
                dataset_id=dataset_id, sharing_token=sharing_token
            )
            datastore_url = api_dataset_info.data_store.url
            url_prefix = wk_context.get_datastore_api_client(datastore_url).url_prefix

            if access_mode == RemoteAccessMode.ZARR_STREAMING:
                if annotation_id is not None:
                    zarr_path = UPath(
                        f"{url_prefix}/annotations/zarr/{annotation_id}/",
                        headers={} if token is None else {"X-Auth-Token": token},
                        ssl=SSL_CONTEXT,
                    )
                else:
                    zarr_path = UPath(
                        f"{url_prefix}/zarr/{dataset_id}/",
                        headers={} if token is None else {"X-Auth-Token": token},
                        ssl=SSL_CONTEXT,
                    )
                return cls(
                    zarr_streaming_path=zarr_path,
                    dataset_properties=None,
                    dataset_id=dataset_id,
                    annotation_id=annotation_id,
                    context=context_manager,
                    read_only=read_only,
                )
            elif access_mode == RemoteAccessMode.DIRECT_PATH:
                if isinstance(api_dataset_info.data_source, ApiUnusableDataSource):
                    raise RuntimeError(
                        f"The dataset {dataset_id} is unusable {api_dataset_info.data_source.status}"
                    )

                return cls(
                    zarr_streaming_path=None,
                    dataset_properties=api_dataset_info.data_source,
                    dataset_id=dataset_id,
                    annotation_id=annotation_id,
                    context=context_manager,
                    read_only=read_only,
                )
            elif access_mode == RemoteAccessMode.PROXY_PATH:
                zarr_path = UPath(
                    f"{url_prefix}/datasets/{dataset_id}/proxy/",
                    headers={} if token is None else {"X-Auth-Token": token},
                    ssl=SSL_CONTEXT,
                )
                return cls(
                    zarr_streaming_path=zarr_path,
                    dataset_properties=None,
                    dataset_id=dataset_id,
                    annotation_id=None,
                    context=context_manager,
                    read_only=read_only,
                )
            else:
                raise ValueError(
                    f"Unsupported access mode {access_mode}. Supported modes are {RemoteAccessMode.__members__}"
                )

    def reopen(self, *, access_mode: RemoteAccessMode) -> "RemoteDataset":
        """Reopens the dataset in the specified access mode.

        Args:
            access_mode: The access mode to reopen the dataset in.

        Returns:
            The reopened dataset.
        """
        with self._context:
            return RemoteDataset.open(
                dataset_id=self.dataset_id,
                annotation_id_or_url=self.annotation_id,
                access_mode=access_mode,
            )

    def _initialize_layer_from_properties(
        self, properties: "LayerProperties", read_only: bool
    ) -> RemoteLayer:
        # When using zarr streaming, layers are read only.
        read_only = self._use_zarr_streaming
        return super()._initialize_layer_from_properties(properties, read_only)

    @property
    def _LayerType(self) -> type[RemoteLayer]:
        return RemoteLayer

    @property
    def _SegmentationLayerType(self) -> type[RemoteSegmentationLayer]:
        return RemoteSegmentationLayer

    def _load_dataset_properties(self) -> DatasetProperties:
        if self._use_zarr_streaming:
            assert self.zarr_streaming_path is not None
            return self._load_dataset_properties_from_path(self.zarr_streaming_path)

        api_dataset_info = self._get_dataset_info()
        assert isinstance(api_dataset_info.data_source, DatasetProperties)
        return api_dataset_info.data_source

    def _apply_server_dataset_properties(self) -> None:
        self._properties = self._load_dataset_properties()
        self._last_read_properties = copy.deepcopy(self._properties)

        # update existing layers
        for layer in self.layers.values():
            layer_properties = next(
                layer_properties
                for layer_properties in self._properties.data_layers
                if layer_properties.name == layer.name
            )
            layer._apply_properties(layer_properties, layer.read_only)

        # add new layers
        for layer_properties in self._properties.data_layers:
            if layer_properties.name not in self.layers:
                layer = self._initialize_layer_from_properties(
                    layer_properties, self._use_zarr_streaming
                )
                self._layers[layer_properties.name] = layer
        # remove deleted layers
        for layer_name in list(self.layers.keys()):
            if not any(
                layer_name == layer_properties.name
                for layer_properties in self._properties.data_layers
            ):
                del self._layers[layer_name]

    def _save_dataset_properties_impl(
        self, *, renamings: Sequence[LayerRenaming | AttachmentRenaming] | None = None
    ) -> None:
        """
        Exports the current dataset properties to the server.
        Note that some edits will not be accepted by the server.
        The client-side RemoteDataset is reinitialized to the new server state.
        Does not work with zarr streaming, as the remote datasource-properties.json is not writable.
        """
        from ..client.context import _get_api_client

        if self._use_zarr_streaming:
            # reset the dataset properties to the server state
            self._apply_server_dataset_properties()
            raise RuntimeError("zarr streaming does not support updating this property")

        layer_renamings = []
        attachment_renamings = []
        if renamings is not None:
            for renaming in renamings:
                if isinstance(renaming, LayerRenaming):
                    layer_renamings.append(
                        ApiLayerRenaming(
                            old_name=renaming.old_name, new_name=renaming.new_name
                        )
                    )
                elif isinstance(renaming, AttachmentRenaming):
                    attachment_renamings.append(
                        ApiAttachmentRenaming(
                            layer_name=renaming.layer_name,
                            attachment_type=renaming.attachment_type,
                            old_name=renaming.old_name,
                            new_name=renaming.new_name,
                        )
                    )
                else:
                    raise ValueError(
                        f"Renaming must be of type LayerRenaming or AttachmentRenaming, got {type(renaming)}"
                    )

        with self._context:
            client = _get_api_client()
            client.dataset_update(
                dataset_id=self._dataset_id,
                dataset_updates={
                    "dataSource": self._properties,
                    "layerRenamings": layer_renamings,
                    "attachmentRenamings": attachment_renamings,
                },
            )
            self._apply_server_dataset_properties()

    def __repr__(self) -> str:
        return f"RemoteDataset({repr(self.url)})"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, self.__class__):
            return self.dataset_id == other.dataset_id
        else:
            return False

    @property
    def dataset_id(self) -> str:
        return self._dataset_id

    @property
    def annotation_id(self) -> str | None:
        return self._annotation_id

    @property
    def url(self) -> str:
        """URL to access this dataset in webknossos.

        Constructs the full URL to the dataset in the webknossos web interface.

        Returns:
            str: Full dataset URL including organization and dataset name

        Examples:
            ```
            print(ds.url) # 'https://webknossos.org/datasets/my_org/my_dataset'
            ```
        """

        from ..client.context import _get_context

        with self._context:
            wk_url = _get_context().url
        return f"{wk_url}/datasets/{self._dataset_id}"

    @property
    def created(self) -> str:
        """Creation date of the dataset.

        Returns:
            str: Date and time when dataset was created
        """

        return datetime.fromtimestamp(self._get_dataset_info().created / 1000).strftime(
            "%B %d, %Y %I:%M:%S"
        )

    @property
    def used_storage_bytes(self) -> int:
        """The amount of storage used by the dataset on the WEBKNOSSOS server. Note that 0 may indicate that the data is either not stored on the WEBKNOSSOS server directly, or that the storage usage was not yet scanned.

        Returns:
            int: The amount of storage used by the dataset in bytes.
        """
        return self._get_dataset_info().used_storage_bytes or 0

    def _get_dataset_info(self) -> ApiDataset:
        from ..client.context import _get_api_client

        with self._context:
            client = _get_api_client()
            return client.dataset_info(dataset_id=self._dataset_id)

    def _update_dataset_info(
        self,
        *,
        name: str = _UNSET,
        description: str | None = _UNSET,
        is_public: bool = _UNSET,
        folder_id: str = _UNSET,
        tags: list[str] = _UNSET,
        metadata: list[ApiMetadata] | None = _UNSET,
    ) -> None:
        self._ensure_writable()
        from ..client.context import _get_api_client

        # Atm, the wk backend needs to get previous parameters passed
        # (this is a race-condition with parallel updates).

        dataset_updates: dict[str, Any] = {}

        if name is not _UNSET:
            dataset_updates["name"] = name
        if description is not _UNSET:
            dataset_updates["description"] = description
        if tags is not _UNSET:
            dataset_updates["tags"] = tags
        if is_public is not _UNSET:
            dataset_updates["isPublic"] = is_public
        if folder_id is not _UNSET:
            dataset_updates["folderId"] = folder_id
        if metadata is not _UNSET:
            dataset_updates["metadata"] = metadata

        with self._context:
            client = _get_api_client()
            client.dataset_update(
                dataset_id=self._dataset_id, dataset_updates=dataset_updates
            )

    @property
    def metadata(self) -> DatasetMetadata:
        """Get or set metadata key-value pairs for the dataset.

        The metadata can contain strings, numbers, and lists of strings as values.
        Changes are immediately synchronized with WEBKNOSSOS.

        Returns:
            DatasetMetadata: Current metadata key-value pairs

        Examples:
            ```
            ds.metadata = {
                "species": "mouse",
                "age_days": 42,
                "tags": ["verified", "published"]
            }
            print(ds.metadata["species"])
            ```
        """

        return DatasetMetadata(f"{self._dataset_id}")

    @metadata.setter
    def metadata(
        self,
        metadata: dict[str, str | int | float | Sequence[str]] | DatasetMetadata | None,
    ) -> None:
        if metadata is not None:
            api_metadata = [
                ApiMetadata(key=k, type=infer_metadata_type(v), value=v)
                for k, v in metadata.items()
            ]
        self._update_dataset_info(metadata=api_metadata)

    @property
    def name(self) -> str:
        """The human-readable name for the dataset in the webknossos interface.

        Changes are immediately synchronized with WEBKNOSSOS.

        Returns:
            str | None: Current display name if set, None otherwise

        Examples:
            ```
            remote_ds.name = "Mouse Brain Sample A"
            ```
        """

        return self._get_dataset_info().name

    @name.setter
    def name(self, name: str) -> None:
        self._update_dataset_info(name=name)

    @property
    def display_name(self) -> str:
        """Deprecated, please use `name`.
        The human-readable name for the dataset in the webknossos interface.

        Changes are immediately synchronized with WEBKNOSSOS.

        Returns:
            str | None: Current display name if set, None otherwise

        Examples:
            ```
            remote_ds.name = "Mouse Brain Sample A"
            ```
        """
        warn_deprecated("display_name", "name")

        return self.name

    @display_name.setter
    def display_name(self, name: str) -> None:
        warn_deprecated("display_name", "name")

        self.name = name

    @property
    def description(self) -> str | None:
        """Free-text description of the dataset.

        Can be edited with markdown formatting. Changes are immediately synchronized
        with WEBKNOSSOS.

        Returns:
            str | None: Current description if set, None otherwise

        Examples:
            ```
            ds.description = "Dataset acquired on *June 1st*"
            ds.description = None  # Remove description
            ```
        """

        return self._get_dataset_info().description

    @description.setter
    def description(self, description: str | None) -> None:
        self._update_dataset_info(description=description)

    @description.deleter
    def description(self) -> None:
        self.description = None

    @property
    def tags(self) -> tuple[str, ...]:
        """User-assigned tags for organizing and filtering datasets.

        Tags allow categorizing and filtering datasets in the webknossos dashboard interface.
        Changes are immediately synchronized with WEBKNOSSOS.

        Returns:
            tuple[str, ...]: Currently assigned tags, in string tuple form

        Examples:
            ```
            ds.tags = ["verified", "published"]
            print(ds.tags)  # ('verified', 'published')
            ds.tags = []  # Remove all tags
            ```
        """

        return tuple(self._get_dataset_info().tags)

    @tags.setter
    def tags(self, tags: Sequence[str]) -> None:
        self._update_dataset_info(tags=list(tags))

    @property
    def is_public(self) -> bool:
        """Control whether the dataset is publicly accessible.

        When True, anyone can view the dataset without logging in to WEBKNOSSOS.
        Changes are immediately synchronized with WEBKNOSSOS.

        Returns:
            bool: True if dataset is public, False if private

        Examples:
            ```
            ds.is_public = True
            ds.is_public = False
            print("Public" if ds.is_public else "Private")  # Private
            ```
        """

        return bool(self._get_dataset_info().is_public)

    @is_public.setter
    def is_public(self, is_public: bool) -> None:
        self._update_dataset_info(is_public=is_public)

    @property
    def sharing_token(self) -> str:
        """Get a new token for sharing access to this dataset.

        Each call generates a fresh token that allows viewing the dataset without logging in.
        The token can be appended to dataset URLs as a query parameter.

        Returns:
            str: Fresh sharing token for dataset access

        Examples:
            ```
            token = ds.sharing_token
            url = f"{ds.url}?token={token}"
            print("Share this link:", url)
            ```

        Note:
            - A new token is generated on each access
            - The token provides read-only access
            - Anyone with the token can view the dataset
        """

        from ..client.context import _get_api_client

        with self._context:
            api_sharing_token = _get_api_client().dataset_sharing_token(
                dataset_id=self._dataset_id
            )
            return api_sharing_token.sharing_token

    @property
    def allowed_teams(self) -> tuple["Team", ...]:
        """Teams that are allowed to access this dataset.

        Controls which teams have read access to view and use this dataset.
        Changes are immediately synchronized with WEBKNOSSOS.

        Returns:
            tuple[Team, ...]: Teams currently having access

        Examples:
            ```
            from webknossos import Team
            team = Team.get_by_name("Lab_A")
            ds.allowed_teams = [team]
            print([t.name for t in ds.allowed_teams])

            # Give access to multiple teams:
            ds.allowed_teams = [
                Team.get_by_name("Lab_A"),
                Team.get_by_name("Lab_B")
            ]
            ```

        Note:
            - Teams must be from the same organization as the dataset
            - Can be set using Team objects or team ID strings
            - An empty list makes the dataset private
        """

        from ..administration.team import Team

        return tuple(
            Team(id=i.id, name=i.name, organization_id=i.organization)
            for i in self._get_dataset_info().allowed_teams
        )

    @allowed_teams.setter
    def allowed_teams(self, allowed_teams: Sequence[Union[str, "Team"]]) -> None:
        """Assign the teams that are allowed to access the dataset. Specify the teams like this `[Team.get_by_name("Lab_A"), ...]`."""
        self._ensure_writable()
        from ..administration.team import Team
        from ..client.context import _get_api_client

        team_ids = [i.id if isinstance(i, Team) else i for i in allowed_teams]

        with self._context:
            client = _get_api_client()
            client.dataset_update_teams(dataset_id=self._dataset_id, team_ids=team_ids)

    @property
    def folder(self) -> RemoteFolder:
        """The (virtual) folder containing this dataset in WEBKNOSSOS.

        Represents the folder location in the WEBKNOSSOS UI folder structure.
        Can be changed to move the dataset to a different folder.
        Changes are immediately synchronized with WEBKNOSSOS.

        Returns:
            RemoteFolder: Current folder containing the dataset

        Examples:
            ```
            folder = RemoteFolder.get_by_path("Datasets/Published")
            ds.folder = folder
            print(ds.folder.path) # 'Datasets/Published'
            ```

        """

        return RemoteFolder.get_by_id(self._get_dataset_info().folder_id)

    @folder.setter
    def folder(self, folder: RemoteFolder) -> None:
        """Move the dataset to a folder. Specify the folder like this `RemoteFolder.get_by_path("Datasets/Folder_A")`."""
        self._update_dataset_info(folder_id=folder.id)

    def download(
        self,
        *,
        sharing_token: str | None = None,
        bounding_box: BoundingBox | None = None,
        bbox: BoundingBox | None = None,
        layers: list[str] | str | None = None,
        mags: list[Mag] | None = None,
        data_format: DataFormat | None = None,
        path: PathLike | UPath | str | None = None,
        exist_ok: bool = False,
    ) -> "Dataset":
        """Downloads a dataset and returns the Dataset instance.
        * `sharing_token` may be supplied if a dataset name was used and can specify a sharing token.
        * `bounding_box`, `layers`, and `mags` specify which parts of the dataset to download.
          If nothing is specified the whole image, all layers, and all mags are downloaded respectively.
        * `path` and `exist_ok` specify where to save the downloaded dataset and whether to overwrite
          if the `path` exists.
        * `data_format` specifies the data format of the downloaded dataset.
        """
        from ..client._download_dataset import download_dataset

        if bbox is not None:
            if bounding_box is not None:
                raise ValueError(
                    "Both bbox and bounding_box were provided. Only one is allowed."
                )
            warn_deprecated("bbox", "bounding_box")
            bounding_box = bbox

        if isinstance(layers, str):
            layers = [layers]
        return download_dataset(
            dataset_id=self.dataset_id,
            sharing_token=sharing_token,
            bbox=bounding_box,
            layers=layers,
            mags=mags,
            data_format=data_format,
            path=UPath(path) if path is not None else None,
            exist_ok=exist_ok,
        )

    def download_mesh(
        self,
        segment_id: int,
        output_dir: PathLike | UPath | str,
        *,
        layer_name: str | None = None,
        mesh_file_name: str | None = None,
        datastore_url: str | None = None,
        lod: int = 0,
        mapping_name: str | None = None,
        mapping_type: Literal["agglomerate", "json"] | None = None,
        mag: MagLike | None = None,
        seed_position: Vec3Int | None = None,
        token: str | None = None,
        sharing_token: str | None = None,
    ) -> UPath:
        warn_deprecated(
            "RemoteDataset.download_mesh", "RemoteSegmentationLayer.download"
        )
        if layer_name is None:
            segmentation_layers = self.get_segmentation_layers()
            if len(segmentation_layers) != 1:
                raise ValueError(
                    "When you attempt to download a mesh without a layer_name, there must be exactly one segmentation layer."
                )
            segmentation_layer = segmentation_layers[0]
        else:
            segmentation_layer = self.get_segmentation_layer(layer_name)
        return segmentation_layer.download_mesh(
            segment_id,
            output_dir,
            mesh_file_name,
            datastore_url,
            lod,
            mapping_name,
            mapping_type,
            mag,
            seed_position,
            token,
            sharing_token,
        )

    def add_layer_as_copy(
        self,
        foreign_layer: Union[str, PathLike, UPath, "Layer", RemoteLayer],
        new_layer_name: str | None = None,
        *,
        data_format: str | DataFormat | None = None,
        exists_ok: bool = False,
        transfer_mode: TransferMode = TransferMode.COPY,
        common_storage_path_prefix: str | None = None,
        overwrite_pending: bool = True,
        with_attachments: bool = True,
    ) -> RemoteLayer:
        """Copy a layer from another dataset to this remote dataset.

        Creates a new layer in this dataset by copying data and metadata from
        a layer in another dataset.

        Args:
            foreign_layer: Layer to copy (path or Layer/RemoteLayer object)
            new_layer_name: Optional name for the new layer, uses original name if None
            data_format: Optional format to store copied data ('zarr', 'zarr3', etc.)
            exists_ok: Whether to overwrite existing layers
            transfer_mode: How data is transferred to remote storage. Defaults to COPY.
            common_storage_path_prefix: Optional path prefix to select one of the
                available WEBKNOSSOS storages.
            overwrite_pending: If there are already pending/unfinished committed mags
                on the server, overwrite them. Defaults to True.
            with_attachments: Whether to copy attachments from segmentation layers.
                Defaults to True.

        Returns:
            RemoteLayer: The newly created copy of the layer

        Raises:
            IndexError: If target layer name already exists and exists_ok is False
            RuntimeError: If dataset is read-only

        Examples:
            Copy layer keeping same name:
            ```
            other_ds = Dataset.open("other/dataset")
            copied = remote_ds.add_layer_as_copy(other_ds.get_layer("color"))
            ```

            Copy with new name:
            ```
            copied = remote_ds.add_layer_as_copy(
                other_ds.get_layer("color"),
                new_layer_name="color_copy",
            )
            ```
        """
        from .layer import Layer
        from .layer.segmentation_layer import SegmentationLayer

        self._ensure_writable()
        foreign_layer = Layer._ensure_layer(foreign_layer)

        if new_layer_name is None:
            new_layer_name = foreign_layer.name
        else:
            _validate_layer_name(new_layer_name)

        if exists_ok:
            layer = self.get_or_add_layer(
                new_layer_name,
                category=foreign_layer.category,
                dtype=foreign_layer.dtype,
                num_channels=foreign_layer.num_channels,
                data_format=data_format or foreign_layer.data_format,
                largest_segment_id=foreign_layer._get_largest_segment_id_maybe(),
                bounding_box=foreign_layer.bounding_box,
            )
        else:
            if new_layer_name in self.layers.keys():
                raise IndexError(
                    f"Cannot copy {foreign_layer}. This dataset already has a layer called {new_layer_name}."
                )
            layer = self.add_layer(
                new_layer_name,
                category=foreign_layer.category,
                dtype=foreign_layer.dtype,
                num_channels=foreign_layer.num_channels,
                data_format=data_format or foreign_layer.data_format,
                largest_segment_id=foreign_layer._get_largest_segment_id_maybe(),
                bounding_box=foreign_layer.bounding_box,
            )

        for mag_view in foreign_layer.mags.values():
            layer.add_mag_as_copy(
                mag_view,
                transfer_mode=transfer_mode,
                common_storage_path_prefix=common_storage_path_prefix,
                overwrite_pending=overwrite_pending,
            )

        if (
            with_attachments
            and isinstance(layer, RemoteSegmentationLayer)
            and isinstance(foreign_layer, SegmentationLayer | RemoteSegmentationLayer)
        ):
            for attachment in foreign_layer.attachments:
                layer.attachments.add_attachment_as_copy(attachment)

        return layer

    def add_layer_as_ref(
        self,
        foreign_layer: Union[str, PathLike, UPath, "Layer", RemoteLayer],
        *,
        new_layer_name: str | None = None,
    ) -> RemoteLayer:
        """Add a layer from another dataset by reference.

        Creates a layer that references data from a remote dataset.

        Args:
            foreign_layer: Foreign layer to add (path or Layer object)
            new_layer_name: Optional name for the new layer, uses original name if None

        Returns:
            Layer: The newly created remote layer referencing the foreign data

        Raises:
            IndexError: If target layer name already exists
            AssertionError: If trying to add non-remote layer or same origin dataset
            RuntimeError: If dataset is read-only

        Examples:
            ```
            remote_ds = RemoteDataset.open("https://webknossos.org/datasets/...")
            other_ds = RemoteDataset.open("https://webknossos.org/datasets/...")
            new_layer = remote_ds.add_layer_as_ref(other_ds.get_layer("color"))
            ```

        Note:
            Changes to the original layer's properties afterwards won't affect this dataset.
            Data is only referenced, not copied.
        """
        from .layer import Layer

        self._ensure_writable()
        foreign_layer = Layer._ensure_layer(foreign_layer)

        if not isinstance(foreign_layer, RemoteLayer):
            raise ValueError(
                f"Cannot add a local layer to a remote dataset. Got {foreign_layer}."
            )

        if new_layer_name is None:
            new_layer_name = foreign_layer.name
        else:
            _validate_layer_name(new_layer_name)

        if new_layer_name in self.layers.keys():
            raise IndexError(
                f"Cannot add foreign layer {foreign_layer}. This dataset already has a layer called {new_layer_name}."
            )
        if foreign_layer.dataset == self:
            raise ValueError(
                "Cannot add layer with the same origin dataset as foreign layer."
            )
        _assert_same_webknossos_instance(self, foreign_layer.dataset, "add a layer")

        from ..client.context import _get_api_client

        with self._context:
            client = _get_api_client()
            client.dataset_add_layer_as_ref(
                dataset_id=self.dataset_id,
                compose_layer=ApiDatasetComposeLayer(
                    source_dataset_id=foreign_layer.dataset.dataset_id,
                    source_layer_name=foreign_layer.name,
                    target_layer_name=new_layer_name,
                ),
            )
        self._apply_server_dataset_properties()

        return self.get_layer(new_layer_name)

    def delete_layer(self, layer_name: str) -> None:
        self._ensure_writable()

        if layer_name not in self.layers.keys():
            raise IndexError(
                f"Removing layer {layer_name} failed. There is no layer with this name"
            )
        del self._layers[layer_name]
        self._properties.data_layers = [
            layer for layer in self._properties.data_layers if layer.name != layer_name
        ]
        self._save_dataset_properties()

    def add_layer(
        self,
        layer_name: str,
        category: LayerCategoryType,
        *,
        dtype: DTypeLike | None = None,
        dtype_per_channel: DTypeLike | None = None,
        num_channels: int | None = None,
        data_format: str | DataFormat = DEFAULT_DATA_FORMAT,
        bounding_box: NDBoundingBox | None = None,
        **kwargs: Any,
    ) -> RemoteLayer:
        self._ensure_writable()

        _validate_layer_name(layer_name)

        if num_channels is None:
            num_channels = 1

        dtype = _dtype_maybe(dtype, dtype_per_channel)
        if dtype is None:
            dtype = DEFAULT_DTYPE

        if layer_name in self.layers.keys():
            raise IndexError(
                f"Adding layer {layer_name} failed. There is already a layer with this name"
            )

        if data_format == DataFormat.WKW:
            warnings.warn(
                "Creating WKW layers in remote datasets is not recommended because of poor performance. "
                + "Use `data_format='zarr3' instead`."
            )

        bounding_box = bounding_box or BoundingBox((0, 0, 0), (0, 0, 0))
        bounding_box = bounding_box.normalize_axes(num_channels)
        layer_properties = LayerProperties(
            name=layer_name,
            category=category,
            bounding_box=bounding_box,
            dtype=dtype.name,
            mags=[],
            data_format=DataFormat(data_format),
        )

        if category == COLOR_CATEGORY:
            self._properties.data_layers += [layer_properties]
            self._layers[layer_name] = RemoteLayer(
                self, layer_properties, read_only=False
            )
        elif category == SEGMENTATION_CATEGORY:
            segmentation_layer_properties: SegmentationLayerProperties = (
                SegmentationLayerProperties(
                    **(
                        attr.asdict(layer_properties, recurse=False)
                    ),  # use all attributes from LayerProperties
                    largest_segment_id=kwargs.get("largest_segment_id"),
                )
            )
            if "mappings" in kwargs:
                segmentation_layer_properties.mappings = kwargs["mappings"]
            self._properties.data_layers += [segmentation_layer_properties]
            self._layers[layer_name] = RemoteSegmentationLayer(
                self, segmentation_layer_properties, read_only=False
            )
        else:
            raise RuntimeError(
                f"Failed to add layer ({layer_name}) because of invalid category ({category}). The supported categories are '{COLOR_CATEGORY}' and '{SEGMENTATION_CATEGORY}'"
            )

        self._save_dataset_properties()
        return self.layers[layer_name]

    @classmethod
    def list(
        cls,
        organization_id: str | None = None,
        tags: str | Sequence[str] | None = None,
        name: str | None = None,
        folder: RemoteFolder | str | None = None,
        folder_id: RemoteFolder | str | None = None,
    ) -> Mapping[str, "RemoteDataset"]:
        """Get all available datasets from the WEBKNOSSOS server.

        Returns a mapping of dataset ids to lazy-initialized RemoteDataset objects for all
        datasets visible to the specified organization or current user. Datasets can be further filtered by tags, name or folder.

        Args:
            organization_id: Optional organization to get datasets from. Defaults to
                organization of logged in user.
            tags: Optional tag(s) to filter datasets by. Can be a single tag string or
                sequence of tags. Only returns datasets with all specified tags.
            name: Optional name to filter datasets by. Only returns datasets with
                matching name.
            folder: Optional folder to filter datasets by. Only returns datasets in
                the specified folder.
            folder_id: Deprecated, use folder instead.

        Returns:
            Mapping[str, RemoteDataset]: Dict mapping dataset ids to RemoteDataset objects

        Examples:
            List all available datasets:
            ```
            datasets = RemoteDataset.list()
            print(sorted(datasets.keys()))
            ```

            Get datasets for specific organization:
            ```
            org_datasets = RemoteDataset.list()("my_organization")
            ds = org_datasets["dataset_name"]
            ```

            Filter datasets by tag:
            ```
            published = RemoteDataset.list(tags="published")
            tagged = RemoteDataset.list(tags=["tag1", "tag2"])
            ```

            Filter datasets by name:
            ```
            fun_datasets = RemoteDataset.list(name="MyFunDataset")
            ```

        Note:
            RemoteDataset objects are initialized lazily when accessed for the first time.
            The mapping object provides a fast way to list and look up available datasets.
        """
        if folder_id is not None:
            warn_deprecated("folder_id", "folder")
            if folder is not None:
                raise ValueError(
                    "Both folder_id and folder were provided. Only one is allowed."
                )
            folder = folder_id

        if isinstance(folder, RemoteFolder):
            folder = folder.id

        return RemoteDatasetRegistry(
            name=name, organization_id=organization_id, tags=tags, folder_id=folder
        )

    @classmethod
    def _disambiguate_remote(
        cls,
        dataset_name: str,
        organization_id: str,
    ) -> str:
        from webknossos import RemoteDataset

        from ..client.context import _get_api_client

        client = _get_api_client()
        possible_ids = list(
            RemoteDataset.list(
                name=dataset_name, organization_id=organization_id
            ).keys()
        )
        if len(possible_ids) == 0:
            try:
                dataset_id = client.dataset_id_from_name(
                    directory_name=dataset_name, organization_id=organization_id
                )
                possible_ids.append(dataset_id)
            except UnexpectedStatusError as e:
                raise ValueError(
                    f"Dataset with name {dataset_name} not found in organization {organization_id}"
                ) from e
        elif len(possible_ids) > 1:
            logger.warning(
                f"There are several datasets with same name '{dataset_name}' available online. Opened dataset with ID {possible_ids[0]}. "
                "If this is not the correct dataset, please provide the dataset ID. You can get the dataset IDs "
                "of your datasets with `Dataset.get_remote_datasets(name=<dataset_name>)."
            )
        return possible_ids[0]

    @classmethod
    def _parse_remote(
        cls,
        *,
        dataset_name_or_url: str | None = None,
        organization_id: str | None = None,
        sharing_token: str | None = None,
        webknossos_url: str | None = None,
        dataset_id: str | None = None,
        annotation_id_or_url: str | None = None,
    ) -> tuple["webknossos_context", str, str | None, str | None]:
        """Parses the given arguments to
        * context_manager that should be entered,
        * dataset_id,
        """
        from .. import Annotation
        from ..client._resolve_short_link import resolve_short_link
        from ..client.context import _get_context, webknossos_context

        caller = inspect.stack()[1].function
        current_context = _get_context()

        if annotation_id_or_url is not None:
            annotation = Annotation.download(
                annotation_id_or_url,
                webknossos_url=webknossos_url,
                skip_volume_data=True,
            )
            if dataset_id is not None:
                assert dataset_id == annotation.dataset_id, (
                    f"The annotation id {annotation.annotation_id} is not from the dataset with id {dataset_id}."
                )
            dataset_id = annotation.dataset_id
            annotation_id = annotation.annotation_id
        else:
            annotation_id = None

        if dataset_id is None:
            assert dataset_name_or_url is not None, (
                f"Please supply either a dataset_id or a dataset name or url to Dataset.{caller}()."
            )
            dataset_name_or_url = resolve_short_link(dataset_name_or_url)

            match = _DATASET_URL_REGEX.match(dataset_name_or_url)
            deprecated_match = _DATASET_DEPRECATED_URL_REGEX.match(dataset_name_or_url)
            if match is not None:
                assert (
                    organization_id is None
                    and sharing_token is None
                    and webknossos_url is None
                ), (
                    f"When Dataset.{caller}() is called with an url, "
                    + f"e.g. Dataset.{caller}('https://webknossos.org/datasets/scalable_minds/l4_sample_dev/view'), "
                    + "organization_id, sharing_token and webknossos_url must not be set."
                )
                dataset_id = match.group("dataset_id")
                sharing_token = match.group("sharing_token")
                webknossos_url = match.group("webknossos_url")
                assert dataset_id is not None
            elif deprecated_match is not None:
                assert (
                    organization_id is None
                    and sharing_token is None
                    and webknossos_url is None
                ), (
                    f"When Dataset.{caller}() is called with an url, "
                    + f"e.g. Dataset.{caller}('https://webknossos.org/datasets/scalable_minds/l4_sample_dev/view'), "
                    + "organization_id, sharing_token and webknossos_url must not be set."
                )
                dataset_name = deprecated_match.group("dataset_name")
                organization_id = deprecated_match.group("organization_id")
                sharing_token = deprecated_match.group("sharing_token")
                webknossos_url = deprecated_match.group("webknossos_url")

                assert organization_id is not None
                assert dataset_name is not None

                dataset_id = cls._disambiguate_remote(dataset_name, organization_id)
            else:
                dataset_name = dataset_name_or_url
                organization_id = organization_id or current_context.organization_id

                dataset_id = cls._disambiguate_remote(dataset_name, organization_id)

        if webknossos_url is None:
            webknossos_url = current_context.url
        webknossos_url = webknossos_url.rstrip("/")
        context_manager = webknossos_context(
            webknossos_url, token=sharing_token or current_context.token
        )
        if webknossos_url != current_context.url:
            if sharing_token is None:
                warnings.warn(
                    f"[INFO] The supplied url {webknossos_url} does not match your current context {current_context.url}. "
                    + f"Using no token, only public datasets can used with Dataset.{caller}(). "
                    + "Please see https://docs.webknossos.org/api/webknossos/client/context.html to adapt the URL and token."
                )
                context_manager = webknossos_context(webknossos_url, None)
        return (context_manager, dataset_id, annotation_id, sharing_token)

    @classmethod
    def trigger_reload_in_datastore(
        cls,
        *,
        dataset_name_or_url: str | None = None,
        organization_id: str | None = None,
        webknossos_url: str | None = None,
        dataset_id: str | None = None,
        organization: str | None = None,  # deprecated, use organization_id instead
        datastore_url: str | None = None,
        token: str | None = None,  # deprecated, use a webknossos context instead
    ) -> None:
        """Trigger a manual reload of the dataset's properties.

        For manually uploaded datasets, properties are normally updated automatically
        after a few minutes. This method forces an immediate reload.

        This is typically only needed after manual changes to the dataset's files.
        Cannot be used for local datasets.

        Args:
            dataset_name_or_url: Name or URL of dataset to reload
            dataset_id: ID of dataset to reload
            organization_id: Organization ID where dataset is located
            datastore_url: Optional URL to the datastore
            webknossos_url: Optional URL to the webknossos server

        Examples:
            ```
            # Force reload after manual file changes
            Dataset.trigger_reload_in_datastore(
                "my_dataset",
                "organization_id"
            )
            ```
        """

        from ..client._upload_dataset import _cached_get_upload_datastore
        from ..client.context import _get_context

        if token is not None:
            warn_deprecated("parameter: token", "a webknossos context")

        if organization is not None:
            warn_deprecated("organization", "organization_id")
            if organization_id is None:
                organization_id = organization
            else:
                raise ValueError(
                    "Both organization and organization_id were provided. Only one is allowed."
                )

        (context_manager, dataset_id, _, _) = cls._parse_remote(
            dataset_name_or_url=dataset_name_or_url,
            organization_id=organization_id,
            sharing_token=token,
            webknossos_url=webknossos_url,
            dataset_id=dataset_id,
        )

        with context_manager:
            context = _get_context()
            datastore_url = datastore_url or _cached_get_upload_datastore(context)
            organization_id = organization_id or context.organization_id

            datastore_client = context.get_datastore_api_client(datastore_url)
            datastore_client.dataset_trigger_reload(
                organization_id=organization_id, dataset_id=dataset_id
            )

    @classmethod
    def explore_and_add_remote(
        cls,
        dataset_uri: str | PathLike | UPath,
        dataset_name: str,
        *,
        folder: str | RemoteFolder | None = None,
        folder_path: str | None = None,
    ) -> "RemoteDataset":
        """Explore and add an external dataset as a remote dataset.

        Adds a dataset from an external location (e.g. S3, Google Cloud Storage, or HTTPs) to WEBKNOSSOS by inspecting
        its layout and metadata without copying the data.

        Args:
            dataset_uri: URI pointing to the remote dataset location
            dataset_name: Name to register dataset under in WEBKNOSSOS
            folder: Path in WEBKNOSSOS folder structure where dataset should appear
            folder_path: Deprecated, use folder instead.

        Returns:
            RemoteDataset: The newly added dataset accessible via WEBKNOSSOS

        Examples:
            ```
            remote = Dataset.explore_and_add_remote(
                "s3://bucket/dataset",
                "my_dataset",
                folder=RemoteFolder.get_by_path("Datasets/Research")
            )
            ```

        Note:
            The dataset files must be accessible from the WEBKNOSSOS server
            for this to work. The data will be streamed through webknossos from the source.
        """
        from ..client.context import _get_api_client

        folder_obj: RemoteFolder | None = None
        if folder_path is not None:
            warn_deprecated("folder_path", "folder")
            if folder is not None:
                raise ValueError(
                    "Both folder_path and folder were provided. Only one is allowed."
                )
            folder_obj = RemoteFolder.get_by_path(folder_path)
        elif isinstance(folder, str):
            folder_obj = RemoteFolder.get_by_path(folder)
        elif isinstance(folder, RemoteFolder):
            folder_obj = folder

        client = _get_api_client()
        dataset = ApiDatasetExploreAndAddRemote(
            UPath(dataset_uri).resolve().as_uri(),
            dataset_name,
            None if folder_obj is None else folder_obj.id,
        )
        dataset_id = client.dataset_explore_and_add_remote(dataset=dataset)

        return cls.open(dataset_id=dataset_id)

    @classmethod
    def from_images(
        cls,
        input_path: str | PathLike | UPath,
        voxel_size: tuple[float, float, float] | None = None,
        name: str | None = None,
        *,
        map_filepath_to_layer_name: Any = None,
        z_slices_sort_key: Callable[[UPath], Any] | None = None,
        voxel_size_with_unit: VoxelSize | None = None,
        layer_name: str | None = None,
        layer_category: LayerCategoryType | None = None,
        data_format: str | DataFormat = DEFAULT_DATA_FORMAT,
        chunk_shape: Vec3IntLike | int | None = None,
        shard_shape: Vec3IntLike | int | None = None,
        chunks_per_shard: int | Vec3IntLike | None = None,
        compress: bool = True,
        swap_xy: bool = False,
        flip_x: bool = False,
        flip_y: bool = False,
        flip_z: bool = False,
        use_bioformats: bool = False,
        max_layers: int = 20,
        batch_size: int | None = None,
        executor: Executor | None = None,
        url: str | None = None,
        token: str | None = None,
        folder: str | RemoteFolder | None = None,
    ) -> "RemoteDataset":
        """Convert images to a WEBKNOSSOS dataset, upload it, and return the RemoteDataset.

        This combines `Dataset.from_images` and `Dataset.upload` into a single step.
        Images are converted to a temporary local dataset which is then uploaded to
        the WEBKNOSSOS server. The temporary files are cleaned up automatically.

        Args:
            input_path: Path to input image files
            voxel_size: Optional tuple of floats (x,y,z) for voxel size in nm
            name: Optional name for the uploaded dataset
            map_filepath_to_layer_name: Strategy for mapping files to layers
            z_slices_sort_key: Optional key function for sorting z-slices
            voxel_size_with_unit: Optional voxel size with unit specification
            layer_name: Optional name for layer(s)
            layer_category: Optional category override
            data_format: Format to store data in
            chunk_shape: Optional shape of chunks
            shard_shape: Optional shape of shards
            chunks_per_shard: Deprecated, use shard_shape
            compress: Whether to compress the data
            swap_xy: Whether to swap x and y axes
            flip_x: Whether to flip the x axis
            flip_y: Whether to flip the y axis
            flip_z: Whether to flip the z axis
            use_bioformats: Whether to use bioformats for reading, defaults to False
            max_layers: Maximum number of layers to create
            batch_size: Size of batches for processing
            executor: Optional executor for parallelization
            url: Optional WEBKNOSSOS server URL
            token: Optional authentication token
            folder: Optional WEBKNOSSOS folder path or RemoteFolder object

        Returns:
            RemoteDataset: The uploaded remote dataset

        Examples:
            ```
            remote_ds = RemoteDataset.from_images(
                "path/to/images/",
                voxel_size=(11.0, 11.0, 20.0),
                name="my_dataset",
                url="https://webknossos.org",
                token="my_token",
            )
            ```
        """
        from ..client.context import webknossos_context as _webknossos_context
        from .dataset import Dataset

        with tempfile.TemporaryDirectory() as tmp_dir:
            dataset: Dataset = Dataset.from_images(
                input_path,
                UPath(tmp_dir) / "dataset",
                voxel_size=voxel_size,
                name=name,
                voxel_size_with_unit=voxel_size_with_unit,
                layer_name=layer_name,
                layer_category=layer_category,
                data_format=data_format,
                chunk_shape=chunk_shape,
                shard_shape=shard_shape,
                chunks_per_shard=chunks_per_shard,
                compress=compress,
                swap_xy=swap_xy,
                flip_x=flip_x,
                flip_y=flip_y,
                flip_z=flip_z,
                use_bioformats=use_bioformats,
                max_layers=max_layers,
                batch_size=batch_size,
                executor=executor,
                map_filepath_to_layer_name=map_filepath_to_layer_name,
                z_slices_sort_key=z_slices_sort_key,
            )

            folder_obj: RemoteFolder | None = None
            if isinstance(folder, str):
                folder_obj = RemoteFolder.get_by_path(folder)
            elif isinstance(folder, RemoteFolder):
                folder_obj = folder

            with _webknossos_context(url=url, token=token):
                remote_dataset = dataset.upload(
                    new_dataset_name=name,
                    folder=folder_obj,
                )

        return remote_dataset

    def downsample(
        self,
        *,
        sampling_mode: SamplingModes = SamplingModes.ANISOTROPIC,
        coarsest_mag: Mag | None = None,
        interpolation_mode: str = "default",
        compress: bool | Zarr3Config = True,
        transfer_mode: TransferMode = TransferMode.COPY,
        common_storage_path_prefix: str | None = None,
        overwrite_pending: bool = True,
        executor: Executor | None = None,
    ) -> None:
        """Generate downsampled magnifications for all layers.

        Creates lower resolution versions (coarser magnifications) of all layers that are not
        yet downsampled, up to the specified coarsest magnification.

        Args:
            sampling_mode: Strategy for downsampling (e.g. ANISOTROPIC, MAX)
            coarsest_mag: Optional maximum/coarsest magnification to generate
            interpolation_mode: Interpolation method to use. Defaults to "default" (= "mode" for segmentation, "median" for color).
            compress: Whether to compress generated magnifications. For Zarr3 datasets, codec configuration and chunk key encoding may also be supplied. Defaults to True.
            transfer_mode (TransferMode). How new mags are transferred to the remote or local storage. Defaults to COPY
            common_storage_path_prefix (str | None): Optional path prefix used when transfer_mode is either COPY or MOVE_AND_SYMLINK
                                        to select one of the available WEBKNOSSOS storages.
            overwrite_pending (bool). If there are already pending/unfinished committed mags on the server, overwrite them. Defaults to True
            executor: Optional executor for parallel processing

        Raises:
            RuntimeError: If dataset is read-only

        Examples:
            Basic downsampling:
                ```
                ds.downsample()
                ```

            With custom parameters:
                ```
                ds.downsample(
                    sampling_mode=SamplingModes.ANISOTROPIC,
                    coarsest_mag=Mag(8),
                )
                ```

        Note:
            - ANISOTROPIC sampling creates anisotropic downsampling until dataset is isotropic
            - Other modes like MAX, CONSTANT etc create regular downsampling patterns
            - If magnifications already exist they will not be regenerated
        """
        for layer in self.layers.values():
            layer.downsample(
                coarsest_mag=coarsest_mag,
                sampling_mode=sampling_mode,
                interpolation_mode=interpolation_mode,
                compress=compress,
                transfer_mode=transfer_mode,
                common_storage_path_prefix=common_storage_path_prefix,
                overwrite_pending=overwrite_pending,
                executor=executor,
            )
