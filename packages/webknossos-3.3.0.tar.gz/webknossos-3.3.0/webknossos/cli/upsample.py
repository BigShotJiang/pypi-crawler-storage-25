"""This module takes care of upsampling WEBKNOSSOS datasets."""

from argparse import Namespace
from multiprocessing import cpu_count
from typing import Annotated

import typer
from upath import UPath

from ..dataset import RemoteDataset, SamplingModes, TransferMode
from ..dataset.remote_dataset import RemoteAccessMode
from ..geometry import Mag
from ..utils import get_executor_for_args
from ._utils import DistributionStrategy, SamplingMode, open_dataset, parse_mag


def main(
    *,
    source: Annotated[
        str,
        typer.Argument(
            help="Path to your WEBKNOSSOS dataset, or URL to a dataset on a WEBKNOSSOS server.",
            show_default=False,
        ),
    ],
    sampling_mode: Annotated[
        SamplingMode, typer.Option(help="The sampling mode to use.")
    ] = SamplingMode.ANISOTROPIC,
    from_mag: Annotated[
        Mag,
        typer.Option(
            help="Mag to start upsampling from. \
Should be number or hyphen-separated string (e.g. 2 or 2-2-2).",
            parser=parse_mag,
        ),
    ],
    layer_name: Annotated[
        str | None,
        typer.Option(
            help="Name of the layer that should be upsampled.", show_default=False
        ),
    ] = None,
    token: Annotated[
        str | None,
        typer.Option(
            help="Authentication token for WEBKNOSSOS instance "
            "(https://webknossos.org/auth/token).",
            rich_help_panel="WEBKNOSSOS context",
            envvar="WK_TOKEN",
        ),
    ] = None,
    jobs: Annotated[
        int,
        typer.Option(
            help="Number of processes to be spawned.",
            rich_help_panel="Executor options",
        ),
    ] = cpu_count(),
    distribution_strategy: Annotated[
        DistributionStrategy,
        typer.Option(
            help="Strategy to distribute the task across CPUs or nodes.",
            rich_help_panel="Executor options",
        ),
    ] = DistributionStrategy.MULTIPROCESSING,
    job_resources: Annotated[
        str | None,
        typer.Option(
            help='Necessary when using slurm as distribution strategy. Should be a JSON string \
(e.g., --job-resources=\'{"mem": "10M"}\')\'',
            rich_help_panel="Executor options",
        ),
    ] = None,
    transfer_mode: Annotated[
        TransferMode | None,
        typer.Option(
            help="The transfer mode to use. Required for remote datasets. "
            "Options: 'copy', 'move+symlink', 'symlink', 'http'.",
            rich_help_panel="WEBKNOSSOS context",
        ),
    ] = None,
    access_mode: Annotated[
        RemoteAccessMode | None,
        typer.Option(
            help="How to access the remote dataset's data. "
            "Defaults to 'direct_path' when --transfer-mode is not 'http', otherwise 'proxy_path'.",
            rich_help_panel="WEBKNOSSOS context",
        ),
    ] = None,
) -> None:
    """Upsample your WEBKNOSSOS dataset."""

    executor_args = Namespace(
        jobs=jobs,
        distribution_strategy=distribution_strategy.value,
        job_resources=job_resources,
    )
    mode = SamplingModes.parse(sampling_mode.value)

    if access_mode is None:
        if transfer_mode is not None and transfer_mode != TransferMode.HTTP:
            access_mode = RemoteAccessMode.DIRECT_PATH
        else:
            access_mode = RemoteAccessMode.PROXY_PATH

    with open_dataset(
        UPath(source), annotation_ok=False, token=token, access_mode=access_mode
    ) as dataset:
        if isinstance(dataset, RemoteDataset):
            if transfer_mode is None:
                raise typer.BadParameter(
                    "--transfer-mode is required for remote datasets.",
                    param_hint="--transfer-mode",
                )
            extra_kwargs: dict = {"transfer_mode": transfer_mode}
        else:
            extra_kwargs = {}
        if layer_name is None:
            for layer in dataset.layers.values():
                with get_executor_for_args(args=executor_args) as executor:
                    layer.upsample(
                        from_mag=from_mag,
                        sampling_mode=mode,
                        executor=executor,
                        **extra_kwargs,
                    )
        else:
            with get_executor_for_args(args=executor_args) as executor:
                dataset.get_layer(layer_name).upsample(
                    from_mag=from_mag,
                    sampling_mode=mode,
                    executor=executor,
                    **extra_kwargs,
                )
