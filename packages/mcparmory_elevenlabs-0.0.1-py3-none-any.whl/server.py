"""MCP server for ElevenLabs API Documentation — placeholder."""

def main() -> None:
    print("mcparmory-elevenlabs: full server coming soon. See https://mcparmory.com")

if __name__ == "__main__":
    main()
