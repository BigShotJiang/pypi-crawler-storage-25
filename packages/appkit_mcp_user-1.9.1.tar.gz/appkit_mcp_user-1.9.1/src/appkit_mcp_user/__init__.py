"""AppKit MCP User component."""
