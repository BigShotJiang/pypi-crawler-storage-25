import json
import os
import random
import string
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterator, List, Optional

from rigour.time import utc_now

ALPHABET = string.ascii_lowercase


class Version(object):
    """A class to represent a dataset version, which consists of a timestamp
    and a string tag."""

    __slots__ = ["dt", "tag"]

    def __init__(self, dt: datetime, tag: str) -> None:
        self.dt: datetime = dt
        self.tag: str = tag

    @classmethod
    def new(cls, tag: Optional[str] = None) -> "Version":
        now = utc_now().replace(tzinfo=None)

        if tag is None:
            # This keeps the tag sortable but short.
            tag_num = (now.microsecond // 1000) * 10
            tag_num_ = tag_num + random.randint(0, 9)
            tag = cls._tag_encode(int(tag_num_))

        tag = tag.ljust(3, "x")[:3]
        now = now.replace(microsecond=0)
        return cls(now, tag)

    @classmethod
    def from_string(cls, id: str) -> "Version":
        if "-" not in id:
            raise ValueError(f"Invalid dataset version: {id}")
        ts, tag = id.split("-", 1)
        dt = datetime.strptime(ts, "%Y%m%d%H%M%S")
        dt = dt.replace(tzinfo=None)
        return cls(dt, tag)

    @classmethod
    def _tag_encode(cls, number: int, alphabet: str = ALPHABET) -> str:
        """Converts an integer to a base36 string."""
        assert number >= 0, "number must be positive"
        if 0 <= number < len(alphabet):
            return alphabet[number]

        encoded = ""
        while number != 0:
            number, i = divmod(number, len(alphabet))
            encoded = alphabet[i] + encoded
        return encoded

    @classmethod
    def from_env(cls, name: str) -> "Version":
        id = os.environ.get(name)
        if id is None:
            return cls.new()
        return cls.from_string(id)

    @property
    def id(self) -> str:
        return f"{self.dt.strftime('%Y%m%d%H%M%S')}-{self.tag}"

    def __str__(self) -> str:
        return self.id

    def __repr__(self) -> str:
        return f"Version({self.id})"

    def __eq__(self, other: Any) -> bool:
        return self.id == str(other)

    def __hash__(self) -> int:
        return hash(self.id)


@dataclass
class VersionHistory(object):
    """A class to represent a history of dataset versions."""

    LENGTH = 100

    items: List[Version]
    last_successful: Optional[Version] = None
    max_length: int = LENGTH

    def append(self, version: Version) -> "VersionHistory":
        """Creates a new history with the given RunID appended."""
        items = list(self.items)
        items.append(version)
        return VersionHistory(items[-self.max_length :], self.last_successful)

    @property
    def latest(self) -> Optional[Version]:
        if not len(self.items):
            return None
        return self.items[-1]

    def to_json(self) -> str:
        """Return a JSON representation of the version history."""
        items = [str(run) for run in self.items[-self.LENGTH :]]
        last_successful = self.last_successful.id if self.last_successful else None
        return json.dumps({"items": items, "last_successful": last_successful})

    @classmethod
    def from_json(cls, data: str) -> "VersionHistory":
        """Create a run history from a JSON representation."""
        items_raw = json.loads(data).get("items", [])
        last_successful_raw = json.loads(data).get("last_successful", None)
        items = [Version.from_string(item_raw) for item_raw in items_raw]
        last_successful = (
            Version.from_string(last_successful_raw) if last_successful_raw else None
        )
        return cls(items=items, last_successful=last_successful)

    def __iter__(self) -> Iterator[Version]:
        return iter(self.items)

    def __len__(self) -> int:
        return len(self.items)
