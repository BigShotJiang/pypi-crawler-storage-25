import shutil
import yaml
import click
import logging
from pathlib import Path
from typing import Generator, Optional, Tuple
from followthemoney import Dataset, ValueEntity, StatementEntity as Entity
from followthemoney.statement import Statement, CSV, FORMATS
from followthemoney.statement import write_statements, read_path_statements
from followthemoney.cli.util import path_writer, InPath, OutPath
from followthemoney.cli.util import path_entities, write_entity
from followthemoney.cli.aggregate import sorted_aggregate

from nomenklatura.cache import Cache
from nomenklatura.matching import train_v1_matcher, train_erun_matcher
from nomenklatura.store import load_entity_file_store
from nomenklatura.resolver import Resolver, Linker
from nomenklatura.enrich import Enricher, make_enricher, match, enrich
from nomenklatura.matching import get_algorithm, DefaultAlgorithm
from nomenklatura.xref import xref as run_xref
from nomenklatura.tui import dedupe_ui
from nomenklatura.matching.bench import bench_matcher

INDEX_SEGMENT = "xref-index"

log = logging.getLogger(__name__)

ResPath = click.Path(dir_okay=False, writable=True, path_type=Path)


def _load_enricher(path: Path) -> Tuple[Dataset, Enricher[Dataset]]:
    with open(path, "r") as fh:
        data = yaml.safe_load(fh)
        dataset = Dataset.make(data)
        cache = Cache.make_default(dataset)
        enricher = make_enricher(dataset, cache, data)
        if enricher is None:
            raise TypeError("Could not load enricher")
        return dataset, enricher


def _get_linker() -> Linker[Entity]:
    resolver = Resolver[Entity].make_default()
    linker = resolver.get_linker()
    resolver.close()
    return linker


def _get_data_path(data_path: Optional[Path]) -> Path:
    if data_path is None:
        data_path = Path.cwd() / "nomenklatura.data"
    return data_path


@click.group(help="Nomenklatura data integration")
def cli() -> None:
    logging.basicConfig(level=logging.INFO)


@cli.command("xref", help="Generate dedupe candidates")
@click.argument("path", type=InPath)
@click.option("-p", "--data-path", type=Path, default=None)
@click.option("-a", "--auto-threshold", type=click.FLOAT, default=None)
@click.option("-l", "--limit", type=click.INT, default=5000)
@click.option("--algorithm", default=DefaultAlgorithm.NAME)
@click.option("--scored/--unscored", is_flag=True, type=click.BOOL, default=True)
@click.option(
    "-f",
    "--focus",
    type=str,
    multiple=True,
    help="Require one of the datasets for a candidate pair",
)
@click.option("-d", "--discount-internal", type=click.FLOAT, default=1.0)
@click.option(
    "-c",
    "--clear",
    is_flag=True,
    default=False,
    help="Clear the index directory, if it exists.",
)
def xref_file(
    path: Path,
    data_path: Optional[Path] = None,
    auto_threshold: Optional[float] = None,
    algorithm: str = DefaultAlgorithm.NAME,
    limit: int = 5000,
    scored: bool = True,
    clear: bool = False,
    focus: tuple[str, ...] = (),
    discount_internal: float = 1.0,
) -> None:
    resolver = Resolver[Entity].make_default()
    resolver.begin()
    data_path = _get_data_path(data_path)

    store = load_entity_file_store(path, resolver=resolver)
    algorithm_type = get_algorithm(algorithm)
    if algorithm_type is None:
        raise click.Abort(f"Unknown algorithm: {algorithm}")

    index_dir = data_path / INDEX_SEGMENT
    if clear and index_dir.exists():
        log.info("Clearing index: %s", index_dir)
        shutil.rmtree(index_dir, ignore_errors=True)
    run_xref(
        resolver,
        store,
        index_dir,
        auto_threshold=auto_threshold,
        algorithm=algorithm_type,
        scored=scored,
        limit=limit,
        focus_datasets=set(focus),
        discount_internal=discount_internal,
    )
    resolver.commit()
    log.info("Xref complete in: %r", resolver)


@cli.command("prune", help="Remove dedupe candidates")
def xref_prune() -> None:
    resolver = Resolver[Entity].make_default()
    resolver.begin()
    resolver.prune()
    resolver.commit()


@cli.command("apply", help="Apply resolver to an entity stream")
@click.argument("path", type=InPath)
@click.option("-o", "--outpath", type=OutPath, default="-")
def apply(path: Path, outpath: Path) -> None:
    linker = _get_linker()
    with path_writer(outpath) as outfh:
        for proxy in path_entities(path, ValueEntity):
            proxy = linker.apply_stream(proxy)
            write_entity(outfh, proxy)


@cli.command("sorted-aggregate", help="Merge sort-order entities")
@click.option("-i", "--infile", type=InPath, default="-")
@click.option("-o", "--outfile", type=OutPath, default="-")
def sorted_aggregate_(infile: Path, outfile: Path) -> None:
    sorted_aggregate(infile, outfile, ValueEntity)


@cli.command("make-sortable", help="Convert entities into plain-text sortable form")
@click.argument("path", type=InPath)
@click.option("-o", "--outpath", type=OutPath, default="-")
def make_sortable(path: Path, outpath: Path) -> None:
    with path_writer(outpath) as outfh:
        for entity in path_entities(path, Entity):
            write_entity(outfh, entity)


@cli.command("dedupe", help="Interactively judge xref candidates")
@click.argument("path", type=InPath)
@click.option("-x", "--xref", is_flag=True, default=False)
@click.option("-p", "--data-path", type=Path, default=None)
def dedupe(path: Path, xref: bool = False, data_path: Optional[Path] = None) -> None:
    resolver = Resolver[Entity].make_default()
    resolver.begin()
    data_path = _get_data_path(data_path)
    store = load_entity_file_store(path, resolver=resolver)
    if xref:
        index_dir = data_path / INDEX_SEGMENT
        run_xref(resolver, store, index_dir)
    resolver.commit()

    dedupe_ui(resolver, store)


@cli.command("train-v1-matcher", help="Train a matching model from judgement pairs")
@click.argument("pairs_file", type=InPath)
def train_v1_matcher_(pairs_file: Path) -> None:
    train_v1_matcher(pairs_file)


@cli.command("train-erun-matcher", help="Train an ER model from judgement pairs")
@click.argument("pairs_file", type=InPath)
def train_erun_matcher_(pairs_file: Path) -> None:
    train_erun_matcher(pairs_file)


@cli.command("match", help="Generate matches from an enrichment source")
@click.argument("config", type=InPath)
@click.argument("entities", type=InPath)
@click.option("-o", "--outpath", type=OutPath, default="-")
def match_command(
    config: Path,
    entities: Path,
    outpath: Path,
) -> None:
    resolver = Resolver[Entity].make_default()
    _, enricher = _load_enricher(config)

    try:
        resolver.begin()
        with path_writer(outpath) as fh:
            stream = path_entities(entities, Entity)
            for proxy in match(enricher, resolver, stream):
                write_entity(fh, proxy)
        resolver.commit()
    finally:
        enricher.close()


@cli.command("enrich", help="Fetch extra info from an enrichment source")
@click.argument("config", type=InPath)
@click.argument("entities", type=InPath)
@click.option("-o", "--outpath", type=OutPath, default="-")  # noqa
def enrich_command(
    config: Path,
    entities: Path,
    outpath: Path,
) -> None:
    resolver = Resolver[Entity].make_default()
    _, enricher = _load_enricher(config)
    try:
        resolver.begin()
        with path_writer(outpath) as fh:
            stream = path_entities(entities, Entity)
            for proxy in enrich(enricher, resolver, stream):
                write_entity(fh, proxy)
        resolver.commit()
    finally:
        enricher.close()


@cli.command("apply-statements", help="Apply a resolver file to a set of statements")
@click.option("-i", "--infile", type=InPath, default="-")
@click.option("-o", "--outpath", type=OutPath, default="-")
@click.option("-f", "--format", type=click.Choice(FORMATS), default=CSV)
def statements_apply(infile: Path, outpath: Path, format: str) -> None:
    linker = _get_linker()

    def _generate() -> Generator[Statement, None, None]:
        for stmt in read_path_statements(infile, format=format):
            yield linker.apply_statement(stmt)

    with path_writer(outpath) as outfh:
        write_statements(outfh, format, _generate())


@cli.command("load-resolver", help="Load resolver edges from file into database")
@click.argument("source", type=InPath)
def load_resolver(source: Path) -> None:
    resolver = Resolver[Entity].make_default()
    resolver.begin()
    resolver.load(source)
    resolver.commit()


@cli.command("dump-resolver", help="Dump resolver decisions from database to file")
@click.argument("target", type=OutPath)
def dump_resolver(target: Path) -> None:
    resolver = Resolver[Entity].make_default()
    resolver.begin()
    resolver.dump(target)
    resolver.rollback()


@cli.command("bench", help="Benchmark a matching algorithm")
@click.argument("name", type=str)
@click.argument("pairs_file", type=InPath)
@click.option("-n", "--number", type=int, default=1000)
def bench(name: str, pairs_file: Path, number: int = 1000) -> None:
    bench_matcher(name, pairs_file, number)


if __name__ == "__main__":
    cli()
