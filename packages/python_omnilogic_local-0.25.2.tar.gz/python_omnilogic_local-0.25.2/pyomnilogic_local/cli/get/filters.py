# Need to figure out how to resolve the 'Untyped decorator makes function "..." untyped' errors in mypy when using click decorators
# mypy: disable-error-code="misc"

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import click

from pyomnilogic_local.cli.utils import echo_properties
from pyomnilogic_local.omnitypes import FilterState, FilterType, FilterValvePosition, FilterWhyOn

if TYPE_CHECKING:
    from pyomnilogic_local import OmniLogic
    from pyomnilogic_local.models.mspconfig import MSPFilter
    from pyomnilogic_local.models.telemetry import TelemetryType


@click.command()
@click.pass_context
def filters(ctx: click.Context) -> None:
    """List all filters and their current settings.

    Displays information about all filters including their system IDs, names,
    current state, speed, valve position, and power usage.

    Example:
        omnilogic get filters
    """
    omnilogic: OmniLogic = ctx.obj["OMNILOGIC"]
    all_filters = omnilogic.all_filters
    for filt in all_filters:
        echo_properties(filt)

    if len(all_filters) == 0:
        click.echo("No filters found in the system configuration.")


def _print_filter_info(filt: MSPFilter, telemetry: TelemetryType | None) -> None:
    """Format and print filter information in a nice table format.

    Args:
        filt: Filter object from MSPConfig with attributes to display
        telemetry: Telemetry object containing current state information
    """
    click.echo("\n" + "=" * 60)
    click.echo("FILTER")
    click.echo("=" * 60)

    filter_data: dict[Any, Any] = {**dict(filt), **dict(telemetry)} if telemetry else dict(filt)
    for attr_name, value in filter_data.items():
        if attr_name == "state":
            value = str(FilterState(value))
        elif attr_name == "type":
            value = str(FilterType(value))
        elif attr_name == "valve_position":
            value = str(FilterValvePosition(value))
        elif attr_name == "why_on":
            value = str(FilterWhyOn(value))
        elif isinstance(value, list):
            # Format lists nicely
            value = ", ".join(str(v) for v in value) if value else "None"

        # Format the attribute name to be more readable
        display_name = attr_name.replace("_", " ").title()
        click.echo(f"{display_name:20} : {value}")
    click.echo("=" * 60)
