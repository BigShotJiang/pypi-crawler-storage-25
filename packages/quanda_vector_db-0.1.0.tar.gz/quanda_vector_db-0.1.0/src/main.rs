mod core;
use core::{StoreConfig, VectorEntry, VectorStore};
use std::time::Instant;

fn make_embedding(seed: usize, dim: usize) -> Vec<f32> {
    (0..dim)
        .map(|j| {
            let mut h: u64 = (seed as u64)
                .wrapping_mul(6_364_136_223_846_793_005)
                .wrapping_add(j as u64 * 1_442_695_040_888_963_407);
            h ^= h >> 32;
            h = h.wrapping_mul(0xbf58476d1ce4e5b9);
            h ^= h >> 32;
            (h as i64) as f32 / i64::MAX as f32
        })
        .collect()
}

fn entry(id: &str, seed: usize, dim: usize) -> VectorEntry {
    VectorEntry {
        id: id.to_string(),
        embedding: make_embedding(seed, dim),
        metadata: format!("metadata for {id}"),
        created_at: "2026-05-17".to_string(),
    }
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let _ = std::fs::remove_file("store.snap");
    let _ = std::fs::remove_file("store.wal");

    const DIM: usize = 64;
    let mut store = VectorStore::open(StoreConfig::default())?;
    println!("Opened: {} entries, dim={:?}\n", store.len(), store.dim);

    // ── Upsert semantics: duplicate ID replaces, not adds ─────────────────────
    println!("=== upsert: duplicate ID replaces existing ===");
    store.upsert(entry("doc_a", 1, DIM))?;
    store.upsert(entry("doc_b", 2, DIM))?;
    println!("  after 2 upserts: len={}", store.len());

    store.upsert(entry("doc_a", 999, DIM))?; // same id, different content
    println!("  after re-upsert doc_a: len={} (still 2, not 3)", store.len());
    println!("  doc_a metadata: {:?}", store.get("doc_a").map(|e| &e.metadata));

    // ── Delete ────────────────────────────────────────────────────────────────
    println!("\n=== delete ===");
    store.delete("doc_b")?;
    println!("  after delete doc_b: len={}", store.len());
    store.delete("nonexistent")?; // no-op, not an error
    println!("  delete nonexistent: ok (no-op)");

    // ── Dimension validation ──────────────────────────────────────────────────
    println!("\n=== dimension validation ===");
    println!("  store dim={:?}", store.dim);
    let bad = VectorEntry {
        id: "bad".to_string(),
        embedding: vec![1.0, 2.0], // wrong dim
        metadata: String::new(),
        created_at: String::new(),
    };
    match store.upsert(bad) {
        Err(e) => println!("  upsert wrong dim: {e}"),
        Ok(_) => println!("  BUG: should have errored"),
    }
    match store.search(&[1.0, 2.0], 1) {
        Err(e) => println!("  search wrong dim: {e}"),
        Ok(_) => println!("  BUG: should have errored"),
    }

    // Empty query must error even when store.dim is None (empty store).
    let mut empty_store = VectorStore::new(StoreConfig {
        snapshot_path: "empty.snap".to_string(),
        wal_path: "empty.wal".to_string(),
    });
    match empty_store.search(&[], 1) {
        Err(e) => println!("  search empty query on empty store: {e}"),
        Ok(_) => println!("  BUG: should have errored"),
    }

    // ── Cosine divide-by-zero guard ───────────────────────────────────────────
    println!("\n=== cosine distance: zero vector ===");
    let zero_entry = VectorEntry {
        id: "zero_vec".to_string(),
        embedding: vec![0.0; DIM],
        metadata: "zero vector".to_string(),
        created_at: "2026-05-17".to_string(),
    };
    store.upsert(zero_entry)?;
    let query = make_embedding(1, DIM);
    let results = store.search(&query, 5)?;
    println!("  search with zero vector in store: {} results", results.len());
    for (e, d) in &results {
        println!("    {} — distance {:.4}", e.id, d);
    }

    // ── Batch upsert ──────────────────────────────────────────────────────────
    println!("\n=== upsert_batch(10_000) — WAL only ===");
    let batch: Vec<VectorEntry> = (0..10_000)
        .map(|i| entry(&format!("vec_{i}"), i + 100, DIM))
        .collect();

    let t = Instant::now();
    store.upsert_batch(batch)?;
    println!("  WAL append: {:?}  (wal_pending={})", t.elapsed(), store.wal_ops_pending());

    // ── Compact once ──────────────────────────────────────────────────────────
    println!("\n=== compact() — HNSW rebuild once ===");
    let t = Instant::now();
    store.compact()?;
    println!("  compact: {:?}  (wal_pending={})", t.elapsed(), store.wal_ops_pending());

    // ── Search after compact ──────────────────────────────────────────────────
    println!("\n=== search (index warm) ===");
    let query = make_embedding(142, DIM); // vec_42 was inserted with seed=142
    let t = Instant::now();
    let results = store.search(&query, 5)?;
    println!("  {:?}", t.elapsed());
    for (e, d) in &results {
        println!("  {} — distance {:.4}", e.id, d);
    }

    // ── Crash recovery ────────────────────────────────────────────────────────
    println!("\n=== crash recovery: insert without compact, then reopen ===");
    store.upsert(entry("post_compact", 77_777, DIM))?;
    println!("  wal_pending={}", store.wal_ops_pending());
    drop(store);

    let mut store2 = VectorStore::open(StoreConfig {
        snapshot_path: "store.snap".to_string(),
        wal_path: "store.wal".to_string(),
    })?;
    println!("  recovered: len={}, wal_pending={}", store2.len(), store2.wal_ops_pending());
    let r = store2.search(&make_embedding(77_777, DIM), 1)?;
    if let Some((e, d)) = r.first() {
        println!("  nearest: {} (distance {:.4})", e.id, d);
    }

    Ok(())
}
