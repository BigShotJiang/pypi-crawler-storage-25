use pyo3::exceptions::{PyIOError, PyValueError};
use pyo3::prelude::*;

mod core;

use crate::core::{StoreConfig, VectorDbError, VectorEntry as RustEntry, VectorStore as RustStore};

// ── Error mapping ─────────────────────────────────────────────────────────────

impl From<VectorDbError> for PyErr {
    fn from(e: VectorDbError) -> Self {
        match e {
            VectorDbError::Io(err) => PyIOError::new_err(err.to_string()),
            VectorDbError::Serde(err) => PyValueError::new_err(err.to_string()),
            VectorDbError::DimensionMismatch { expected, got } => {
                PyValueError::new_err(format!("Dimension mismatch: store is {expected}D, got {got}D"))
            }
            VectorDbError::EmptyEmbedding => PyValueError::new_err("Embedding must not be empty"),
        }
    }
}

// ── VectorEntry ───────────────────────────────────────────────────────────────

// from_py_object: lets Python VectorEntry objects be passed as Vec<VectorEntry> args.
#[pyclass(from_py_object)]
#[derive(Clone)]
pub struct VectorEntry {
    #[pyo3(get, set)]
    pub id: String,
    #[pyo3(get, set)]
    pub embedding: Vec<f32>,
    #[pyo3(get, set)]
    pub metadata: String,
    #[pyo3(get, set)]
    pub created_at: String,
}

#[pymethods]
impl VectorEntry {
    #[new]
    #[pyo3(signature = (id, embedding, metadata="", created_at=""))]
    pub fn new(id: String, embedding: Vec<f32>, metadata: &str, created_at: &str) -> Self {
        VectorEntry {
            id,
            embedding,
            metadata: metadata.to_string(),
            created_at: created_at.to_string(),
        }
    }

    pub fn __repr__(&self) -> String {
        format!("VectorEntry(id={:?}, dim={})", self.id, self.embedding.len())
    }

    pub fn __len__(&self) -> usize {
        self.embedding.len()
    }
}

impl From<RustEntry> for VectorEntry {
    fn from(e: RustEntry) -> Self {
        VectorEntry {
            id: e.id,
            embedding: e.embedding,
            metadata: e.metadata,
            created_at: e.created_at,
        }
    }
}

impl From<VectorEntry> for RustEntry {
    fn from(e: VectorEntry) -> Self {
        RustEntry {
            id: e.id,
            embedding: e.embedding,
            metadata: e.metadata,
            created_at: e.created_at,
        }
    }
}

// ── VectorStore ───────────────────────────────────────────────────────────────

#[pyclass(unsendable)]
pub struct VectorStore {
    inner: RustStore,
}

#[pymethods]
impl VectorStore {
    /// Create a fresh empty store (does not read any existing files).
    #[staticmethod]
    #[pyo3(signature = (snapshot_path="store.snap", wal_path="store.wal"))]
    pub fn new(snapshot_path: &str, wal_path: &str) -> Self {
        VectorStore {
            inner: RustStore::new(StoreConfig {
                snapshot_path: snapshot_path.to_string(),
                wal_path: wal_path.to_string(),
            }),
        }
    }

    /// Open an existing store (loads snapshot + replays WAL), or create fresh.
    #[staticmethod]
    #[pyo3(signature = (snapshot_path="store.snap", wal_path="store.wal"))]
    pub fn open(snapshot_path: &str, wal_path: &str) -> PyResult<Self> {
        let inner = RustStore::open(StoreConfig {
            snapshot_path: snapshot_path.to_string(),
            wal_path: wal_path.to_string(),
        })?;
        Ok(VectorStore { inner })
    }

    /// Insert or replace an entry by ID. O(1) WAL append — no index rebuild.
    pub fn upsert(&mut self, entry: VectorEntry) -> PyResult<()> {
        self.inner.upsert(entry.into())?;
        Ok(())
    }

    /// Batch upsert. Single buffered WAL write for the whole batch.
    pub fn upsert_batch(&mut self, entries: Vec<VectorEntry>) -> PyResult<()> {
        let rust_entries: Vec<RustEntry> = entries.into_iter().map(Into::into).collect();
        self.inner.upsert_batch(rust_entries)?;
        Ok(())
    }

    /// Delete by ID. No-op (not an error) if the ID does not exist.
    pub fn delete(&mut self, id: &str) -> PyResult<()> {
        self.inner.delete(id)?;
        Ok(())
    }

    /// Point lookup by ID. Returns None if not found.
    pub fn get(&self, id: &str) -> Option<VectorEntry> {
        self.inner.get(id).map(|e| VectorEntry::from(e.clone()))
    }

    /// Search top-k nearest neighbours.
    /// Returns a list of (VectorEntry, distance) tuples.
    /// Rebuilds the HNSW index lazily only when the live state has changed.
    #[pyo3(signature = (query, top_k=10))]
    pub fn search(&mut self, query: Vec<f32>, top_k: usize) -> PyResult<Vec<(VectorEntry, f32)>> {
        let results = self.inner.search(&query, top_k)?;
        Ok(results
            .into_iter()
            .map(|(e, d)| (VectorEntry::from(e), d))
            .collect())
    }

    /// Merge WAL into snapshot, truncate WAL file, rebuild HNSW index once.
    /// Call after large batch inserts or on a schedule.
    pub fn compact(&mut self) -> PyResult<()> {
        self.inner.compact()?;
        Ok(())
    }

    /// Number of live entries.
    #[getter]
    pub fn len(&self) -> usize {
        self.inner.len()
    }

    /// Fixed embedding dimension, or None if the store is empty.
    #[getter]
    pub fn dim(&self) -> Option<usize> {
        self.inner.dim
    }

    /// WAL ops not yet merged into the snapshot.
    #[getter]
    pub fn wal_pending(&self) -> usize {
        self.inner.wal_ops_pending()
    }

    pub fn __len__(&self) -> usize {
        self.inner.len()
    }

    pub fn __bool__(&self) -> bool {
        self.inner.len() > 0
    }

    pub fn __repr__(&self) -> String {
        format!(
            "VectorStore(len={}, dim={:?}, wal_pending={})",
            self.inner.len(),
            self.inner.dim,
            self.inner.wal_ops_pending()
        )
    }
}

// ── Module ────────────────────────────────────────────────────────────────────

#[pymodule]
fn quanda_vector_db(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<VectorEntry>()?;
    m.add_class::<VectorStore>()?;
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;
    Ok(())
}
