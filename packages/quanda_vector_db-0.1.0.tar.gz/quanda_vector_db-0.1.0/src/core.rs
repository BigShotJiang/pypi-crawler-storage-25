use serde::{Deserialize, Serialize};
use instant_distance::{Builder, HnswMap, Search};
use std::collections::HashMap;
use std::fmt;
use std::fs::{File, OpenOptions};
use std::io::{BufRead, BufReader, BufWriter, Write};

// ── Public types ──────────────────────────────────────────────────────────────

#[derive(Serialize, Deserialize, Clone)]
pub struct VectorEntry {
    pub id: String,
    pub embedding: Vec<f32>,
    pub metadata: String,
    pub created_at: String,
}

pub struct StoreConfig {
    pub snapshot_path: String,
    pub wal_path: String,
}

impl Default for StoreConfig {
    fn default() -> Self {
        StoreConfig {
            snapshot_path: "store.snap".to_string(),
            wal_path: "store.wal".to_string(),
        }
    }
}

// ── Internal storage types ────────────────────────────────────────────────────

#[derive(Serialize, Deserialize)]
struct Snapshot {
    dim: usize,
    entries: Vec<VectorEntry>,
}

/// Every mutation is one of these two ops. Serialised as newline-delimited JSON
/// in the WAL file so restarts can replay.
#[derive(Serialize, Deserialize)]
#[serde(tag = "op", content = "data", rename_all = "snake_case")]
enum WalRecord {
    Upsert(VectorEntry),
    Delete { id: String },
}

// ── Distance ──────────────────────────────────────────────────────────────────

#[derive(Clone)]
struct Point(Vec<f32>);

impl instant_distance::Point for Point {
    fn distance(&self, other: &Self) -> f32 {
        let dot: f32 = self.0.iter().zip(&other.0).map(|(a, b)| a * b).sum();
        let mag_a: f32 = self.0.iter().map(|x| x * x).sum::<f32>().sqrt();
        let mag_b: f32 = other.0.iter().map(|x| x * x).sum::<f32>().sqrt();
        let denom = mag_a * mag_b;
        if denom == 0.0 {
            // Zero vectors are undefined in cosine space — treat as maximally distant.
            return 2.0;
        }
        (1.0 - dot / denom).clamp(0.0, 2.0)
    }
}

// ── Errors ────────────────────────────────────────────────────────────────────

#[derive(Debug)]
pub enum VectorDbError {
    Io(std::io::Error),
    Serde(serde_json::Error),
    DimensionMismatch { expected: usize, got: usize },
    EmptyEmbedding,
}

impl From<std::io::Error> for VectorDbError {
    fn from(e: std::io::Error) -> Self { VectorDbError::Io(e) }
}
impl From<serde_json::Error> for VectorDbError {
    fn from(e: serde_json::Error) -> Self { VectorDbError::Serde(e) }
}
impl fmt::Display for VectorDbError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            VectorDbError::Io(e) => write!(f, "IO error: {e}"),
            VectorDbError::Serde(e) => write!(f, "Serialization error: {e}"),
            VectorDbError::DimensionMismatch { expected, got } =>
                write!(f, "Dimension mismatch: store is {expected}D, got {got}D"),
            VectorDbError::EmptyEmbedding => write!(f, "Embedding must not be empty"),
        }
    }
}
impl std::error::Error for VectorDbError {}

// ── VectorStore ───────────────────────────────────────────────────────────────

/// WAL-backed vector store with upsert/delete semantics.
///
/// Write path: upsert / delete → WAL append + HashMap update (no index rebuild)
/// Read path:  search → lazy HNSW rebuild, only when live state changed
/// Compaction: compact() → write snapshot, truncate WAL, rebuild index once
pub struct VectorStore {
    /// Effective, deduplicated entries. HashMap ensures no duplicate IDs.
    live: HashMap<String, VectorEntry>,
    /// Number of WAL ops pending since last compact.
    wal_pending: usize,
    /// HNSW index built from live. Maps position → live key via index_keys.
    index: Option<HnswMap<Point, usize>>,
    /// Stable key order captured at last rebuild. Maps HNSW result index → ID.
    index_keys: Vec<String>,
    index_dirty: bool,
    /// Fixed dimension for this store, set on first insert, stored in snapshot.
    pub dim: Option<usize>,
    pub config: StoreConfig,
}

impl VectorStore {
    pub fn new(config: StoreConfig) -> Self {
        VectorStore {
            live: HashMap::new(),
            wal_pending: 0,
            index: None,
            index_keys: Vec::new(),
            index_dirty: false,
            dim: None,
            config,
        }
    }

    /// Open existing store (load snapshot + replay WAL) or create fresh.
    pub fn open(config: StoreConfig) -> Result<Self, VectorDbError> {
        let mut store = VectorStore::new(config);

        if std::path::Path::new(&store.config.snapshot_path).exists() {
            let content = std::fs::read_to_string(&store.config.snapshot_path)?;
            let snap: Snapshot = serde_json::from_str(&content)?;
            store.dim = Some(snap.dim);
            for e in snap.entries {
                store.live.insert(e.id.clone(), e);
            }
        }

        if std::path::Path::new(&store.config.wal_path).exists() {
            let file = File::open(&store.config.wal_path)?;
            let mut count = 0usize;
            for line in BufReader::new(file).lines() {
                let line = line?;
                if line.trim().is_empty() { continue; }
                let record: WalRecord = serde_json::from_str(&line)?;
                match &record {
                    WalRecord::Upsert(e) => {
                        store.validate_dim(&e.embedding)?;
                        store.live.insert(e.id.clone(), e.clone());
                    }
                    WalRecord::Delete { id } => { store.live.remove(id); }
                }
                count += 1;
            }
            store.wal_pending = count;
        }

        store.index_dirty = !store.live.is_empty();
        Ok(store)
    }

    // ── Writes ────────────────────────────────────────────────────────────────

    /// Insert or replace an entry by ID. O(1) WAL append.
    pub fn upsert(&mut self, entry: VectorEntry) -> Result<(), VectorDbError> {
        self.validate_dim(&entry.embedding)?;
        let id = entry.id.clone();
        let record = WalRecord::Upsert(entry.clone());
        self.wal_append(&record)?;
        self.live.insert(id, entry);
        self.wal_pending += 1;
        self.index_dirty = true;
        Ok(())
    }

    /// Batch upsert: one buffered WAL write for the whole batch.
    pub fn upsert_batch(&mut self, entries: Vec<VectorEntry>) -> Result<(), VectorDbError> {
        for e in &entries {
            self.validate_dim(&e.embedding)?;
        }
        let records: Vec<WalRecord> = entries.iter().map(|e| WalRecord::Upsert(e.clone())).collect();
        self.wal_append_many(&records)?;
        let n = records.len();
        for entry in entries {
            self.live.insert(entry.id.clone(), entry);
        }
        self.wal_pending += n;
        self.index_dirty = true;
        Ok(())
    }

    /// Delete an entry by ID. No-op (not an error) if the ID does not exist.
    pub fn delete(&mut self, id: &str) -> Result<(), VectorDbError> {
        if self.live.remove(id).is_none() {
            return Ok(());
        }
        let record = WalRecord::Delete { id: id.to_string() };
        self.wal_append(&record)?;
        self.wal_pending += 1;
        self.index_dirty = true;
        Ok(())
    }

    // ── Query ─────────────────────────────────────────────────────────────────

    /// Point lookup by ID.
    pub fn get(&self, id: &str) -> Option<&VectorEntry> {
        self.live.get(id)
    }

    /// Search top-k nearest neighbours.
    /// Returns `Err` if `query` has the wrong dimension.
    /// Rebuilds the HNSW index lazily when the live state has changed.
    pub fn search(
        &mut self,
        query: &[f32],
        top_k: usize,
    ) -> Result<Vec<(VectorEntry, f32)>, VectorDbError> {
        if query.is_empty() {
            return Err(VectorDbError::EmptyEmbedding);
        }
        if let Some(dim) = self.dim {
            if query.len() != dim {
                return Err(VectorDbError::DimensionMismatch { expected: dim, got: query.len() });
            }
        }

        if self.index_dirty {
            self.rebuild_index();
        }

        let hits: Vec<(usize, f32)> = match &self.index {
            None => return Ok(vec![]),
            Some(index) => {
                let mut search = Search::default();
                index
                    .search(&Point(query.to_vec()), &mut search)
                    .take(top_k)
                    .map(|item| (*item.value, item.distance))
                    .collect()
            }
        };

        // After rebuild_index() above, every index_keys[idx] is guaranteed to be in live.
        // filter_map is a defensive safety net for future multi-threaded callers.
        Ok(hits
            .into_iter()
            .filter_map(|(idx, dist)| {
                self.live.get(&self.index_keys[idx]).map(|e| (e.clone(), dist))
            })
            .collect())
    }

    // ── Compaction ────────────────────────────────────────────────────────────

    /// Merge WAL into snapshot, truncate WAL file, rebuild HNSW once.
    pub fn compact(&mut self) -> Result<(), VectorDbError> {
        if self.wal_pending == 0 {
            return Ok(());
        }
        let dim = self.dim.unwrap_or(0);
        let entries: Vec<VectorEntry> = self.live.values().cloned().collect();
        let snap = Snapshot { dim, entries };
        std::fs::write(&self.config.snapshot_path, serde_json::to_string(&snap)?)?;
        File::create(&self.config.wal_path)?;
        self.wal_pending = 0;
        self.rebuild_index();
        Ok(())
    }

    // ── Stats ─────────────────────────────────────────────────────────────────

    pub fn len(&self) -> usize { self.live.len() }
    pub fn wal_ops_pending(&self) -> usize { self.wal_pending }

    // ── Internals ─────────────────────────────────────────────────────────────

    fn validate_dim(&mut self, embedding: &[f32]) -> Result<(), VectorDbError> {
        if embedding.is_empty() {
            return Err(VectorDbError::EmptyEmbedding);
        }
        match self.dim {
            None => { self.dim = Some(embedding.len()); Ok(()) }
            Some(d) if d == embedding.len() => Ok(()),
            Some(d) => Err(VectorDbError::DimensionMismatch { expected: d, got: embedding.len() }),
        }
    }

    fn rebuild_index(&mut self) {
        // Sort keys for a deterministic mapping: HNSW result index → ID.
        self.index_keys = self.live.keys().cloned().collect();
        self.index_keys.sort_unstable();

        let points: Vec<Point> = self.index_keys
            .iter()
            .map(|k| Point(self.live[k].embedding.clone()))
            .collect();
        let values: Vec<usize> = (0..points.len()).collect();

        self.index = if points.is_empty() {
            None
        } else {
            Some(Builder::default().build(points, values))
        };
        self.index_dirty = false;
    }

    fn wal_append(&self, record: &WalRecord) -> Result<(), VectorDbError> {
        let f = OpenOptions::new().create(true).append(true).open(&self.config.wal_path)?;
        let mut w = BufWriter::new(f);
        writeln!(w, "{}", serde_json::to_string(record)?)?;
        Ok(())
    }

    fn wal_append_many(&self, records: &[WalRecord]) -> Result<(), VectorDbError> {
        let f = OpenOptions::new().create(true).append(true).open(&self.config.wal_path)?;
        let mut w = BufWriter::new(f);
        for r in records {
            writeln!(w, "{}", serde_json::to_string(r)?)?;
        }
        Ok(())
    }
}
