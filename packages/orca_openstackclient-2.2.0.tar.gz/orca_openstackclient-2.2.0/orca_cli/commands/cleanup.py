"""``orca cleanup`` — find and remove orphaned resources in the current project."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import click

from orca_cli.core.context import OrcaContext
from orca_cli.core.exceptions import APIError
from orca_cli.core.output import console
from orca_cli.services.load_balancer import LoadBalancerService
from orca_cli.services.network import NetworkService
from orca_cli.services.orchestration import OrchestrationService
from orca_cli.services.server import ServerService
from orca_cli.services.volume import VolumeService

# Resource types that can be detected and optionally deleted
CLEANUP_TYPES = [
    "floating-ip", "volume", "snapshot", "port",
    "security-group", "server", "router", "stack", "loadbalancer",
]

FAILED_STACK_STATUSES = {
    "CREATE_FAILED", "UPDATE_FAILED", "ROLLBACK_COMPLETE",
    "UPDATE_ROLLBACK_COMPLETE", "DELETE_FAILED",
}


def _safe(fn, *args, **kwargs) -> list:
    """Call a service method; swallow errors (service unavailable)."""
    try:
        return fn(*args, **kwargs)
    except Exception:
        return []


def _age_days(resource: dict, key: str = "created_at") -> int | None:
    created = resource.get(key, "")
    if not created:
        return None
    try:
        dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - dt).days
    except (ValueError, TypeError):
        return None


@click.command()
@click.option("--delete", "do_delete", is_flag=True,
              help="Actually delete the detected orphaned resources.")
@click.option("--older-than", "older_than", type=int, default=None, metavar="DAYS",
              help="Flag volumes and snapshots older than N days (implies age check).")
@click.option("--skip", "skip_types", multiple=True,
              type=click.Choice(CLEANUP_TYPES),
              help="Resource type to skip (repeatable).")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation when deleting.")
@click.pass_context
def cleanup(ctx: click.Context, do_delete: bool, older_than: int | None,  # noqa: C901
            skip_types: tuple, yes: bool) -> None:
    """Find orphaned resources — unused IPs, detached volumes, broken stacks, etc.

    Detects the following by default:
      floating-ip   — not associated with any port
      volume        — detached & available, or in error state
      snapshot      — in error state; or older than --older-than days
      port          — no device attached
      security-group — non-default, not used by any server
      server        — in ERROR state
      router        — no external gateway and no attached interfaces
      stack         — in a failed/rollback state (requires Heat)
      loadbalancer  — in ERROR state (requires Octavia)

    By default only reports findings. Use --delete to clean up.

    \b
    Examples:
      orca cleanup
      orca cleanup --older-than 30
      orca cleanup --skip stack --skip loadbalancer
      orca cleanup --delete --yes
      orca cleanup --older-than 14 --delete --yes
    """
    client = ctx.find_object(OrcaContext).ensure_client()
    net_svc = NetworkService(client)
    lb_svc = LoadBalancerService(client)
    server_svc = ServerService(client)
    volume_svc = VolumeService(client)
    skip = set(skip_types)
    issues: list[tuple[str, str, str, str]] = []  # (type, id, name, reason)

    cutoff: datetime | None = None
    if older_than is not None:
        cutoff = datetime.now(timezone.utc) - timedelta(days=older_than)

    with console.status("[bold cyan]Scanning for orphaned resources…[/bold cyan]"):

        # ── Floating IPs not associated ──────────────────────────────────────
        if "floating-ip" not in skip:
            for f in _safe(net_svc.find_all_floating_ips):
                if not f.get("port_id"):
                    issues.append((
                        "floating-ip", f["id"],
                        f.get("floating_ip_address", ""),
                        "not associated with any port",
                    ))

        # ── Volumes ──────────────────────────────────────────────────────────
        if "volume" not in skip:
            for v in _safe(volume_svc.find_all):
                name = v.get("name") or "—"
                status = v.get("status", "")
                if status == "available" and not v.get("attachments"):
                    age = _age_days(v)
                    reason = "detached & available"
                    if cutoff and age is not None:
                        if age < older_than:
                            continue  # too recent, skip
                        reason = f"detached & available ({age}d old)"
                    issues.append(("volume", v["id"], name, reason))
                elif status == "error":
                    issues.append(("volume", v["id"], name, "error state"))

        # ── Snapshots ────────────────────────────────────────────────────────
        if "snapshot" not in skip:
            for s in _safe(volume_svc.find_snapshots):
                name = s.get("name") or "—"
                if s.get("status") == "error":
                    issues.append(("snapshot", s["id"], name, "error state"))
                elif cutoff:
                    age = _age_days(s)
                    if age is not None and age >= older_than:
                        issues.append(("snapshot", s["id"], name, f"{age}d old"))

        # ── Ports without device ─────────────────────────────────────────────
        if "port" not in skip:
            for p in _safe(net_svc.find_all_ports):
                if not p.get("device_id") and not p.get("device_owner"):
                    ips = ", ".join(
                        ip.get("ip_address", "") for ip in p.get("fixed_ips", [])
                    )
                    issues.append(("port", p["id"], ips or "—", "no device attached"))

        # ── Unused security groups ────────────────────────────────────────────
        if "security-group" not in skip:
            sgs = _safe(net_svc.find_all_security_groups)
            servers = _safe(server_svc.find_all)
            used_sg_ids: set[str] = set()
            for srv in servers:
                for sg in srv.get("security_groups", []):
                    used_sg_ids.add(sg.get("id") or sg.get("name", ""))
            for sg in sgs:
                if sg.get("name") == "default":
                    continue
                if sg["id"] not in used_sg_ids and sg.get("name") not in used_sg_ids:
                    issues.append((
                        "security-group", sg["id"], sg.get("name", ""),
                        "not used by any server",
                    ))

        # ── Servers in ERROR ─────────────────────────────────────────────────
        if "server" not in skip:
            # Reuse servers list if already fetched, otherwise fetch
            _servers = servers if "security-group" not in skip else _safe(
                server_svc.find_all,
            )
            for srv in _servers:
                if srv.get("status") == "ERROR":
                    issues.append((
                        "server", srv["id"], srv.get("name", ""), "error state",
                    ))

        # ── Routers with no gateway and no interfaces ────────────────────────
        if "router" not in skip:
            # One query for ALL router-interface ports, then group by device_id
            # — replaces a 1+N pattern (one ports query per router).
            router_iface_ports: dict[str, list] = {}
            for p in _safe(
                net_svc.find_all_ports,
                params={"device_owner": "network:router_interface"},
            ):
                router_iface_ports.setdefault(p.get("device_id", ""), []).append(p)
            for r in _safe(net_svc.find_all_routers):
                if r.get("external_gateway_info"):
                    continue
                if not router_iface_ports.get(r["id"]):
                    issues.append((
                        "router", r["id"], r.get("name", ""),
                        "no external gateway and no attached interfaces",
                    ))

        # ── Heat stacks in failed/rollback state ─────────────────────────────
        if "stack" not in skip:
            heat_svc = OrchestrationService(client)
            for s in _safe(heat_svc.find):
                if s.get("stack_status") in FAILED_STACK_STATUSES:
                    issues.append((
                        "stack", s["id"], s.get("stack_name", ""),
                        s.get("stack_status", "failed"),
                    ))

        # ── Load balancers in ERROR ───────────────────────────────────────────
        if "loadbalancer" not in skip:
            for lb in _safe(lb_svc.find_all):
                if lb.get("provisioning_status") == "ERROR":
                    issues.append((
                        "loadbalancer", lb["id"], lb.get("name", ""),
                        "provisioning_status=ERROR",
                    ))

    # ── Report ────────────────────────────────────────────────────────────────
    if not issues:
        console.print("[bold green]No orphaned resources found.[/bold green]")
        return

    from rich.table import Table
    tbl = Table(title=f"Orphaned Resources ({len(issues)})", show_lines=False)
    tbl.add_column("Type", style="bold")
    tbl.add_column("ID", style="cyan", no_wrap=True)
    tbl.add_column("Name / Info")
    tbl.add_column("Reason", style="yellow")
    for rtype, rid, rname, reason in issues:
        tbl.add_row(rtype, rid, rname, reason)
    console.print()
    console.print(tbl)
    console.print()

    if not do_delete:
        console.print("[dim]Use --delete to clean up these resources.[/dim]")
        return

    # ── Delete ────────────────────────────────────────────────────────────────
    if not yes:
        click.confirm(f"Delete {len(issues)} orphaned resource(s)?", abort=True)

    success = 0
    for rtype, rid, rname, _reason in issues:
        label = f"{rtype} {rname} ({rid})"
        try:
            if rtype == "floating-ip":
                net_svc.delete_floating_ip(rid)
            elif rtype == "volume":
                volume_svc.delete(rid, cascade=True)
            elif rtype == "snapshot":
                volume_svc.delete_snapshot(rid)
            elif rtype == "port":
                net_svc.delete_port(rid)
            elif rtype == "security-group":
                net_svc.delete_security_group(rid)
            elif rtype == "server":
                server_svc.delete(rid)
            elif rtype == "router":
                net_svc.delete_router(rid)
            elif rtype == "stack":
                OrchestrationService(client).delete(rname, rid)
            elif rtype == "loadbalancer":
                lb_svc.delete(rid, cascade=True)
            console.print(f"  [green]✓[/green] {label}")
            success += 1
        except APIError as exc:
            console.print(f"  [red]✗[/red] {label}: {exc}")
        except Exception as exc:
            console.print(f"  [red]✗[/red] {label}: {exc}")

    console.print(f"\n[bold]{success}/{len(issues)} resources cleaned up.[/bold]")
