from enum import Enum

from pydantic import BaseModel


class LocalesEnum(Enum):
    EN = "EN"
    ES = "ES"


class OutputFormat(Enum):
    CSV = "CSV"
    SARIF = "SARIF"
    ALL = "ALL"


class OutputConfig(BaseModel):
    model_config = {"extra": "forbid"}
    file_path: str
    format: OutputFormat


class FalsePositivesConfig(BaseModel):
    model_config = {"extra": "forbid"}
    findings: list[str] = []
    method_names: list[str] = []
    cve: list[str] = []
