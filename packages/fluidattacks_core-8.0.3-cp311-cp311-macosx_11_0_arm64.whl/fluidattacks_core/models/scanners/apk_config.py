from pydantic import BaseModel, StrictBool


class ApkEnvironment(BaseModel):
    model_config = {"extra": "forbid"}
    apk_file_path: str
    environment_id: str | None = None

    def __eq__(self, other: object) -> bool:
        """Compare only on apk_file_path, ignoring environment_id."""
        if not isinstance(other, ApkEnvironment):
            return NotImplemented
        return self.apk_file_path == other.apk_file_path

    def __hash__(self) -> int:
        """Hash only on apk_file_path, ignoring environment_id."""
        return hash(self.apk_file_path)


class ApkConfig(BaseModel):
    model_config = {"extra": "forbid"}
    include: list[str] = []
    exclude: list[str] = []
    use_sast_analysis: StrictBool = True
    environments: list[ApkEnvironment] | None = None
    feature_preview: StrictBool | None = None
