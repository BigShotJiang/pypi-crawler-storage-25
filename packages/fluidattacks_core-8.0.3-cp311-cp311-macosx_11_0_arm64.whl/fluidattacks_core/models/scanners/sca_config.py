from pydantic import BaseModel, StrictBool


class ScaExclusion(BaseModel):
    model_config = {"extra": "forbid"}
    CVE: str
    paths: list[str]


class ScaConfig(BaseModel):
    model_config = {"extra": "forbid"}
    include: list[str] | None = None
    exclude: list[str] | None = None
    use_spots_sca: StrictBool | None = None
    feature_preview: StrictBool | None = None
    exclusions: list[ScaExclusion] = []
