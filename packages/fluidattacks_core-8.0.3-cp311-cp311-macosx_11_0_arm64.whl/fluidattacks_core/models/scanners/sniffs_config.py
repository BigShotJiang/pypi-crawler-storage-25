from pydantic import BaseModel, StrictBool


class SniffsConfig(BaseModel):
    model_config = {"extra": "allow"}
    include: list[str] | None = None
    exclude: list[str] | None = None
    min_entropy: float | None = None
    feature_preview: StrictBool | None = None
