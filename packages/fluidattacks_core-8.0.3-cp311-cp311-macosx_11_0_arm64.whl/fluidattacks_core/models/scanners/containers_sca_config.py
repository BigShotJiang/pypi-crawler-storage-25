from pydantic import BaseModel, StrictBool


class EcrCredentialsConfig(BaseModel):
    model_config = {"extra": "allow"}
    access_key_id: str | None = None
    secret_access_key: str | None = None
    session_token: str | None = None
    role_arn: str | None = None
    external_id: str | None = None
    aws_region: str | None = None


class DockerCredentialsConfig(BaseModel):
    model_config = {"extra": "allow"}
    docker_username: str
    docker_password: str


class ContainerImageConfig(BaseModel):
    model_config = {"extra": "allow"}
    use_docker_daemon: StrictBool | None = None
    os_override: str | None = None
    arch_override: str | None = None
    ecr_credentials: EcrCredentialsConfig | None = None
    docker_credentials: DockerCredentialsConfig | None = None


class ContainerScaItem(BaseModel):
    model_config = {"extra": "allow"}
    image_uri: str
    image_config: ContainerImageConfig | None = None


class ContainersScaConfig(BaseModel):
    model_config = {"extra": "allow"}
    images: list[ContainerScaItem]
