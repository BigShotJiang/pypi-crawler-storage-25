from enum import Enum

from pydantic import BaseModel, StrictBool


class SourceType(Enum):
    DIRECTORY = "dir"
    DOCKER = "docker"
    DOCKER_DAEMON = "docker-daemon"
    ECR = "ecr"
    ECR_WITH_CREDENTIALS = "ecr-with-credentials"


class SbomDockerCredentials(BaseModel):
    model_config = {"extra": "forbid"}
    username: str | None = None
    password: str | None = None
    use_docker_daemon: StrictBool | None = None


class SbomPlatformOverrides(BaseModel):
    model_config = {"extra": "forbid"}
    os_override: str | None = None
    arch_override: str | None = None


class SbomAwsCredentials(BaseModel):
    model_config = {"extra": "forbid"}
    external_id: str | None = None
    role: str | None = None
    region: str | None = None
    access_key_id: str | None = None
    secret_access_key: str | None = None
    session_token: str | None = None


class SbomOutputConfig(BaseModel):
    model_config = {"extra": "forbid"}
    name: str
    format: str


class SbomConfig(BaseModel):
    model_config = {"extra": "forbid"}
    include: list[str] | None = None
    exclude: list[str] | None = None
    output: SbomOutputConfig | None = None
    source: str | None = None
    source_type: SourceType | None = None
    image_uri: str | None = None
    environment_id: str | None = None
    docker_credentials: SbomDockerCredentials | None = None
    platform_overrides: SbomPlatformOverrides | None = None
    aws_credentials: SbomAwsCredentials | None = None
    include_package_metadata: StrictBool | None = None
    include_package_advisories: StrictBool | None = None
    feature_preview: StrictBool | None = None
