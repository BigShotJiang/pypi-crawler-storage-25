from pydantic import BaseModel, StrictBool

from fluidattacks_core.models.scanners.apk_config import ApkConfig
from fluidattacks_core.models.scanners.common_config import (
    FalsePositivesConfig,
    LocalesEnum,
    OutputConfig,
)
from fluidattacks_core.models.scanners.containers_sca_config import ContainersScaConfig
from fluidattacks_core.models.scanners.cspm_config import CspmConfig
from fluidattacks_core.models.scanners.dast_config import DastConfig
from fluidattacks_core.models.scanners.sast_config import SastConfig
from fluidattacks_core.models.scanners.sbom_config import SbomConfig
from fluidattacks_core.models.scanners.sca_config import ScaConfig
from fluidattacks_core.models.scanners.sniffs_config import SniffsConfig


class ScanConfig(BaseModel):
    model_config = {"extra": "allow"}
    working_dir: str | None = None
    namespace: str | None = None
    commit: str | None = None
    language: LocalesEnum | None = None
    execution_id: str | None = None
    checks: list[str] | None = None
    strict: StrictBool | None = None
    strictness_threshold: str | None = None
    tracing_opt_out: StrictBool | None = None
    debug: StrictBool | None = None
    output: OutputConfig | None = None
    sast: SastConfig | None = None
    sca: ScaConfig | None = None
    containers_sca: ContainersScaConfig | None = None
    sbom: SbomConfig | None = None
    dast: DastConfig | None = None
    cspm: CspmConfig | None = None
    apk: ApkConfig | None = None
    false_positives_identified: FalsePositivesConfig | None = None
    ss: SniffsConfig | None = None
