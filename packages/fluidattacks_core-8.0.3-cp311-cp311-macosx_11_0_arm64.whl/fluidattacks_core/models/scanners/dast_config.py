from pydantic import BaseModel, StrictBool, field_validator

from fluidattacks_core.models.scanners.loader import LoaderValidationInfo, resolve_env_var


class DastUrl(BaseModel):
    model_config = {"extra": "forbid"}
    url: str
    environment_id: str | None = None

    def __eq__(self, other: object) -> bool:
        """Compare only on url, ignoring environment_id."""
        if not isinstance(other, DastUrl):
            return NotImplemented
        return self.url == other.url

    def __hash__(self) -> int:
        """Hash only on url, ignoring environment_id."""
        return hash(self.url)


class DastApiAuth(BaseModel):
    model_config = {"extra": "forbid"}
    type: str
    key: str
    value: str

    @field_validator("key", "value", mode="before")
    @classmethod
    def _resolve_credentials(cls, v: object, info: LoaderValidationInfo) -> object:
        return resolve_env_var(v, info)


class DastApiConfig(BaseModel):
    model_config = {"extra": "forbid"}
    base_url: str
    api_specs: list[str]
    authentication: list[DastApiAuth] = []
    environment_id: str | None = None


class DastConfig(BaseModel):
    model_config = {"extra": "forbid"}
    urls: list[DastUrl] = []
    api: list[DastApiConfig] = []
    feature_preview: StrictBool | None = None
    strict_connectivity: StrictBool = False
