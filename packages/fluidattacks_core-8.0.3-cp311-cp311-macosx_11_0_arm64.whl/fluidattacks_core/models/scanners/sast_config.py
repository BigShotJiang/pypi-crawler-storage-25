from pydantic import BaseModel, StrictBool


class SastConfig(BaseModel):
    model_config = {"extra": "forbid"}
    include: list[str] | None = None
    exclude: list[str] | None = None
    recursion_limit: int | None = None
    use_inspects: StrictBool | None = None
    enable_reachability: StrictBool | None = None
    reachability_sbom_input: str | None = None
    file_size_limit: StrictBool | None = None
    multifile: StrictBool | None = None
    use_report_soon: StrictBool | None = None
    report_reachability: StrictBool | None = None
    report_drafts: StrictBool | None = None
    include_sniffs: StrictBool | None = None
    feature_preview: str | None = None
