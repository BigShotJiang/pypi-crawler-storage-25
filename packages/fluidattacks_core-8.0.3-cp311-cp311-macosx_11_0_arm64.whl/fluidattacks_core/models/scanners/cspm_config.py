from pydantic import BaseModel, Field, StrictBool, field_validator, model_validator

from fluidattacks_core.models.scanners.loader import LoaderValidationInfo, resolve_env_var


class AwsCredentials(BaseModel):
    model_config = {"extra": "forbid"}
    access_key_id: str
    secret_access_key: str
    session_token: str | None = None
    environment_id: str | None = None

    @field_validator("access_key_id", "secret_access_key", "session_token", mode="before")
    @classmethod
    def _resolve_credentials(cls, v: object, info: LoaderValidationInfo) -> object:
        return resolve_env_var(v, info)

    @model_validator(mode="after")
    def _validate_key_session_token_pairing(self) -> "AwsCredentials":
        is_temporary = self.access_key_id.startswith("ASIA")
        if is_temporary and not self.session_token:
            msg = "Temporary credentials (ASIA key) require a session_token"
            raise ValueError(msg)
        if not is_temporary and self.session_token:
            msg = "Static credentials (AKIA key) must not include a session_token"
            raise ValueError(msg)
        return self


class AwsRole(BaseModel):
    model_config = {"extra": "forbid"}
    role: str = Field(repr=False)
    external_id: str | None = Field(default=None, repr=False)
    environment_id: str | None = None

    @field_validator("role", "external_id", mode="before")
    @classmethod
    def _resolve_credentials(cls, v: object, info: LoaderValidationInfo) -> object:
        return resolve_env_var(v, info)


class CspmConfig(BaseModel):
    model_config = {"extra": "forbid"}
    aws_credentials: list[AwsCredentials | AwsRole] = []
    feature_preview: StrictBool | None = None
