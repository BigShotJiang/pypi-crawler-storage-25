import logging
import os
from contextlib import suppress
from pathlib import Path

from pathspec import PathSpec
from pathspec import util as pathspec_util

LOGGER = logging.getLogger(__name__)


def remove_empty_directories(repo_path: str) -> None:
    for root, dirs, _ in os.walk(repo_path, topdown=False):
        for name in dirs:
            path = os.path.join(root, name)  # noqa: PTH118
            try:
                if not os.listdir(path):  # noqa: PTH208
                    Path(path).rmdir()
            except FileNotFoundError:
                LOGGER.exception(
                    "Error removing empty directory", extra={"extra": {"dir_path": path}}
                )
                continue


def delete_out_of_scope_files(git_ignore: list[str], repo_path: str) -> None:
    # Compute what files should be deleted according to the scope rules
    spec: PathSpec = PathSpec.from_lines("gitwildmatch", git_ignore)
    try:
        matches = list(spec.match_tree(repo_path, follow_links=False))
    except pathspec_util.RecursionError:
        LOGGER.exception(
            "RecursionError while matching tree (symlink cycle detected)",
            extra={"extra": {"repo_path": repo_path}},
        )
        return

    for match in matches:
        if match.startswith(".git/"):
            continue

        file_path = os.path.join(repo_path, match)  # noqa: PTH118
        if Path(file_path).is_file():
            with suppress(FileNotFoundError):
                Path(file_path).unlink()

    remove_empty_directories(repo_path)
