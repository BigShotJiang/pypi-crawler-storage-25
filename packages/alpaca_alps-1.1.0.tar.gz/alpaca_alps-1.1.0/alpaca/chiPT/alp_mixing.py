import numpy as np
from . import sm_mixing, u3reprs
from ..rge import ALPcouplings
from ..constants import mpi0, fpi

def cq_axial(couplings: ALPcouplings) -> np.ndarray:
    """Returns the axial couplings in the quark basis."""
    couplings = couplings.translate('VA_below')
    return np.array([[couplings['cuA'][0, 0], 0, 0],
                     [0, couplings['cdA'][0, 0], couplings['cdA'][0, 1]],
                     [0, couplings['cdA'][1, 0], couplings['cdA'][1, 1]]])

def kin_mixing(ma: float, couplings: ALPcouplings) -> np.ndarray:
    res = np.zeros((3, 3), dtype=complex)
    cqA = cq_axial(couplings)
    res += sm_mixing.tr_angle(cqA @ sm_mixing.u_pi_mix()) * ma**2/(ma**2 - mpi0**2) * sm_mixing.u_pi_mix()
    res += sm_mixing.tr_angle(cqA @ sm_mixing.u_eta_mix()) * ma**2/(ma**2 - sm_mixing.m_eta()**2) * sm_mixing.u_eta_mix()
    res += sm_mixing.tr_angle(cqA @ sm_mixing.u_etap_mix()) * ma**2/(ma**2 - sm_mixing.m_etap()**2) * sm_mixing.u_etap_mix()
    res += sm_mixing.tr_angle(cqA @ u3reprs.u_K0) * ma**2/(ma**2 - sm_mixing.m_K0()**2) * u3reprs.u_K0bar
    res += sm_mixing.tr_angle(cqA @ u3reprs.u_K0bar) * ma**2/(ma**2 - sm_mixing.m_K0()**2) * u3reprs.u_K0
    return res

def mass_mixing(ma: float, couplings: ALPcouplings) -> np.ndarray:
    res = np.zeros((3, 3), dtype=complex)
    cG = couplings['cG']
    m2_eta0 = sm_mixing.m2_eta0()
    res -= 2/3 * cG * m2_eta0/(ma**2 - mpi0**2) * sm_mixing.tr_angle(sm_mixing.u_pi_mix()) * sm_mixing.u_pi_mix()
    res -= 2/3 * cG * m2_eta0/(ma**2 - sm_mixing.m_eta()**2) * sm_mixing.tr_angle(sm_mixing.u_eta_mix()) * sm_mixing.u_eta_mix()
    res -= 2/3 * cG * m2_eta0/(ma**2 - sm_mixing.m_etap()**2) * sm_mixing.tr_angle(sm_mixing.u_etap_mix()) * sm_mixing.u_etap_mix()
    return res

def alp_mixing(ma: float, couplings: ALPcouplings) -> np.ndarray:
    return kin_mixing(ma, couplings) + mass_mixing(ma, couplings)

def alp_mass(ma: float, couplings: ALPcouplings, fa: float) -> float:
    F0 = fpi/np.sqrt(2)
    u_alp = alp_mixing(ma, couplings)
    ma_QCD = F0/fa * np.sqrt(2 * sm_mixing.B0 * sm_mixing.tr_angle(sm_mixing.mq @ u_alp @ u_alp) + \
           sm_mixing.m2_eta0()/6 * (2 * sm_mixing.tr_angle(u_alp) - 1)**2)
    return np.sqrt(ma_QCD**2 + ma**2)