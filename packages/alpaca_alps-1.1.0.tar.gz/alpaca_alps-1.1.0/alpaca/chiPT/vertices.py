import numpy as np
from .alp_mixing import alp_mixing, cq_axial
from .sm_mixing import tr_angle, u3
from ..rge import ALPcouplings
from ..constants import mpi0, fpi, mu, md, ms

def ps_k_111(meson1: str, ma: float, couplings: ALPcouplings, fa: float) -> complex:
    '''
    Vertex $k_{111} \\phi_1^3 a$
    '''
    ualp = np.matrix(alp_mixing(ma, couplings))
    um1 = np.matrix(u3[meson1])
    mq = np.matrix(np.diag([mu, md, ms]))
    B0 = mpi0**2 / (mu + md)
    F0 = fpi / np.sqrt(2)
    return B0/(12* F0 * fa) * tr_angle(mq @ (um1**3 @ ualp + um1**2 @ ualp @ um1 + um1 @ ualp @ um1**2 + ualp @ um1**3))

def ps_k_112(meson1: str, meson2: str, ma: float, couplings: ALPcouplings, fa: float) -> complex:
    '''
    Vertex $k_{112} \\phi_1^2 \\phi_2 a$
    '''
    ualp = np.matrix(alp_mixing(ma, couplings))
    um1 = np.matrix(u3[meson1])
    um2 = np.matrix(u3[meson2])
    mq = np.matrix(np.diag([mu, md, ms]))
    B0 = mpi0**2 / (mu + md)
    F0 = fpi / np.sqrt(2)
    return B0/(12* F0 * fa) * tr_angle(mq @ (um1**2 @ um2 @ ualp + um1**2 @ ualp @ um2 + \
                                             um2 @ um1**2 @ ualp + um2 @ ualp @ um1**2 + \
                                             ualp @ um1**2 @ um2 + ualp @ um2 @ um1**2 + \
                                             um1 @ um2 @ um1 @ ualp + um1 @ um2 @ ualp @ um1 + \
                                             um1 @ ualp @ um1 @ um2 + um1 @ ualp @ um2 @ um1 + \
                                             um2 @ um1 @ ualp @ um1 + ualp @ um1 @ um2 @ um1))

def ps_k_123(meson1: str, meson2: str, meson3: str, ma: float, couplings: ALPcouplings, fa: float) -> complex:
    '''
    Vertex $k_{123} \\phi_1 \\phi_2 \\phi_3 a$
    '''
    ualp = np.matrix(alp_mixing(ma, couplings))
    um1 = np.matrix(u3[meson1])
    um2 = np.matrix(u3[meson2])
    um3 = np.matrix(u3[meson3])
    mq = np.matrix(np.diag([mu, md, ms]))
    B0 = mpi0**2 / (mu + md)
    F0 = fpi / np.sqrt(2)
    return B0/(12* F0 * fa) * tr_angle(mq @ (um1 @ um2 @ um3 @ ualp + um1 @ um2 @ ualp @ um3 + um1 @ um3 @ um2 @ ualp + um1 @ um3 @ ualp @ um2 + um1 @ ualp @ um2 @ um3 + um1 @ ualp @ um3 @ um2 + um2 @ um1 @ um3 @ ualp + um2 @ um1 @ ualp @ um3 + um2 @ um3 @ um1 @ ualp + um2 @ um3 @ ualp @ um1 + um2 @ ualp @ um1 @ um3 + um2 @ ualp @ um3 @ um1 + um3 @ um1 @ um2 @ ualp + um3 @ um1 @ ualp @ um2 + um3 @ um2 @ um1 @ ualp + um3 @ um2 @ ualp @ um1 + um3 @ ualp @ um1 @ um2 + um3 @ ualp @ um2 @ um1 + ualp @ um1 @ um2 @ um3 + ualp @ um1 @ um3 @ um2 + ualp @ um2 @ um1 @ um3 + ualp @ um2 @ um3 @ um1 + ualp @ um3 @ um1 @ um2 + ualp @ um3 @ um2 @ um1))

def ps_g_11_2(meson1: str, meson2: str, ma: float, couplings: ALPcouplings, fa: float) -> complex:
    '''
    Vertex $g_{11;2} \\phi_1 \\partial_\\mu a (\\phi_1 \\partial^\\mu\\phi_2 - \\phi_2\\partial^\\mu\\phi_1)$
    '''
    ualp = np.matrix(alp_mixing(ma, couplings))
    um1 = np.matrix(u3[meson1])
    um2 = np.matrix(u3[meson2])
    cqA = cq_axial(couplings)
    F0 = fpi / np.sqrt(2)
    return 1.0/(12* F0 * fa) * tr_angle((2*cqA-ualp) @ ( um1**2 @ um2 + um2 @ um1**2 - 2* um1 @ um2 @ um1))

def ps_g_2_11(meson1: str, meson2: str, ma: float, couplings: ALPcouplings, fa: float) -> complex:
    '''
    Vertex $g_{2;11} a \\partial_\\mu\\phi_1(\\phi_1 \\partial^\\mu\\phi_2 - \\phi_2\\partial^\\mu\\phi_1)$
    '''
    ualp = np.matrix(alp_mixing(ma, couplings))
    um1 = np.matrix(u3[meson1])
    um2 = np.matrix(u3[meson2])
    F0 = fpi / np.sqrt(2)
    return 1.0/(12* F0 * fa) * tr_angle(ualp @ ( um1**2 @ um2 + um2 @ um1**2 - 2* um1 @ um2 @ um1))

def ps_g_12_3(meson1: str, meson2: str, meson3: str, ma: float, couplings: ALPcouplings, fa: float) -> complex:
    '''
    Vertex $g_{12;3} \\phi_1 \\phi_2 \\partial_\\mu a \\partial^\\mu\\phi_3$
    '''
    ualp = np.matrix(alp_mixing(ma, couplings))
    um1 = np.matrix(u3[meson1])
    um2 = np.matrix(u3[meson2])
    um3 = np.matrix(u3[meson3])
    cqA = cq_axial(couplings)
    F0 = fpi / np.sqrt(2)
    return 1.0/(12* F0 * fa) * tr_angle((2*cqA-ualp) @ (um1 @ um2 @ um3 + um2 @ um1 @ um3 + um3 @ um1 @ um2 + um3 @ um2 @ um1 - 2* um1 @ um3 @ um2 -2* um2 @ um3 @ um1))

def ps_g_3_12(meson1: str, meson2: str, meson3: str, ma: float, couplings: ALPcouplings, fa: float) -> complex:
    '''
    Vertex $g_{3;12} a \\phi_3 \\partial_\\mu \\phi_1 \\partial^\\mu\\phi_2$
    '''
    ualp = np.matrix(alp_mixing(ma, couplings))
    um1 = np.matrix(u3[meson1])
    um2 = np.matrix(u3[meson2])
    um3 = np.matrix(u3[meson3])
    F0 = fpi / np.sqrt(2)
    return 1.0/(12* F0 * fa) * tr_angle(ualp @ (um1 @ um2 @ um3 + um2 @ um1 @ um3 + um3 @ um1 @ um2 + um3 @ um2 @ um1 - 2* um1 @ um3 @ um2 -2* um2 @ um3 @ um1))