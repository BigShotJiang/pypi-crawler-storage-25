from ..constants import mpi0, mu, md, ms, theta_eta_etap, epsilonKaon, phiepsilonKaon
from .u3reprs import u_pi0, u_eta, u_etap, u_K0, u_K0bar, u_pi_minus, u_pi_plus, u_K_minus, u_K_plus
from numpy import sqrt, sin, cos
import numpy as np

tr_angle = lambda x: np.trace(x)/2
mq = np.diag([mu, md, ms])
B0 = mpi0**2 / (mu+md)

def m2_eta0():
    return -3*B0 * tr_angle(mq @ u_eta @ u_etap)/(tr_angle(u_eta) * tr_angle(u_etap))

def m_eta():
    return sqrt(2*B0 * tr_angle(mq @ u_eta @ u_eta) + 2/3 * m2_eta0()**2 * tr_angle(u_eta)**2)

def m_etap():
    return sqrt(2*B0 * tr_angle(mq @ u_etap @ u_etap) + 2/3 * m2_eta0()**2 * tr_angle(u_etap)**2)

def m_K0():
    return sqrt(B0 * tr_angle(mq @ ( u_K0 @ u_K0bar + u_K0bar @ u_K0)))

def u_pi_mix():
    m_pi_eta = 2*B0 * tr_angle(mq @ u_pi0 @ u_eta) + 2/3 * m2_eta0()**2 * tr_angle(u_pi0) * tr_angle(u_eta)
    m_pi_etap = 2*B0 * tr_angle(mq @ u_pi0 @ u_etap) + 2/3 * m2_eta0()**2 * tr_angle(u_pi0) * tr_angle(u_etap)
    return u_pi0 + m_pi_eta/(mpi0**2 - m_eta()**2) * u_eta + m_pi_etap/(mpi0**2 - m_etap()**2) * u_etap

def u_eta_mix():
    m_pi_eta = 2*B0 * tr_angle(mq @ u_pi0 @ u_eta) + 2/3 * m2_eta0()**2 * tr_angle(u_pi0) * tr_angle(u_eta)
    return u_eta - m_pi_eta/(mpi0**2 - m_eta()**2) * u_pi0

def u_etap_mix():
    m_pi_etap = 2*B0 * tr_angle(mq @ u_pi0 @ u_etap) + 2/3 * m2_eta0()**2 * tr_angle(u_pi0) * tr_angle(u_etap)
    return u_etap - m_pi_etap/(mpi0**2 - m_etap()**2) * u_pi0

class U3matrices:
    def __init__(self):
        self.initialized = False
    def initialize(self):
        if not self.initialized:
            self.u_pi0 = u_pi_mix()
            self.u_eta = u_eta_mix()
            self.u_etap = u_etap_mix()
            self.initialized = True
    def __getitem__(self, key):
        if key == 'pion0':
            self.initialize()
            return self.u_pi0
        elif key == 'eta':
            self.initialize()
            return self.u_eta
        elif key == "eta'":
            self.initialize()
            return self.u_etap
        elif key == 'K0':
            return u_K0
        elif key == 'K0bar':
            return u_K0bar
        elif key == 'pion-':
            return u_pi_minus
        elif key == 'pion+':
            return u_pi_plus
        elif key == 'K-':
            return u_K_minus
        elif key == 'K+':
            return u_K_plus
        else:
            raise KeyError(f"Unknown key: {key}")

u3 = U3matrices()