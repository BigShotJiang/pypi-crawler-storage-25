import numpy as np
from . import vertices, alp_mixing
from ..rge import ALPcouplings
from ..constants import mpi0, mpi_pm, meta, metap, mK0, mK


def amp_alpdec_chiPT_p2(p1: str, p2: str, p3: str):
    p1s, p2s, p3s = sorted([p1, p2, p3])
    if (p1s != p2s) and (p2s != p3s):
        def ampl(ma, couplings, fa, kinematics):
            k123 = vertices.ps_k_123(p1s, p2s, p3s, ma, couplings, fa)
            g12_3 = vertices.ps_g_12_3(p1s, p2s, p3s, ma, couplings, fa)
            g13_2 = vertices.ps_g_12_3(p1s, p3s, p2s, ma, couplings, fa)
            g23_1 = vertices.ps_g_12_3(p2s, p3s, p1s, ma, couplings, fa)
            g1_23 = vertices.ps_g_3_12(p3s, p2s, p1s, ma, couplings, fa)
            g2_13 = vertices.ps_g_3_12(p1s, p3s, p2s, ma, couplings, fa)
            g3_12 = vertices.ps_g_3_12(p1s, p2s, p3s, ma, couplings, fa)
            return k123 + g12_3 * kinematics[2] + g13_2 * kinematics[1] + g23_1 * kinematics[0] - g1_23 * kinematics[5] - g2_13 * kinematics[4] - g3_12 * kinematics[3]
    elif p2s != p3s:
        def ampl(ma, couplings, fa, kinematics):
            k112 = vertices.ps_k_112(p1s, p3s, ma, couplings, fa)
            g11_2 = vertices.ps_g_11_2(p1s, p3s, ma, couplings, fa)
            g2_11 = vertices.ps_g_2_11(p1s, p3s, ma, couplings, fa)
            return 2 * k112 + g11_2 * (2*kinematics[2] - kinematics[0] - kinematics[1]) + g2_11 * (2*kinematics[3]-kinematics[4]-kinematics[5])
    elif p1s != p2s:
        def ampl(ma, couplings, fa, kinematics):
            k112 = vertices.ps_k_112(p1s, p3s, ma, couplings, fa)
            g11_2 = vertices.ps_g_11_2(p1s, p3s, ma, couplings, fa)
            g2_11 = vertices.ps_g_2_11(p1s, p3s, ma, couplings, fa)
            return 2 * k112 + g11_2 * (2*kinematics[0] - kinematics[1] - kinematics[2]) + g2_11 * (2*kinematics[5] - kinematics[3] - kinematics[4])
    else:
        def ampl(ma, couplings, fa, kinematics):
            k111 = vertices.ps_k_111(p1s, ma, couplings, fa)
            return 6 * k111
    return ampl