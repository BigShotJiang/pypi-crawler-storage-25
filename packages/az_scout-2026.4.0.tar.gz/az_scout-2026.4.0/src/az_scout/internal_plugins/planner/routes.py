"""API routes for the Deployment Planner internal plugin."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from fastapi import APIRouter, Query
from pydantic import BaseModel
from starlette.responses import JSONResponse

from az_scout import azure_api
from az_scout.models.responses import (
    DeploymentConfidenceResponse,
    ErrorResponse,
    SkuInfo,
    SpotScoresResponse,
)
from az_scout.scoring.deployment_confidence import (
    best_spot_label,
    compute_deployment_confidence,
    signals_from_sku,
)

logger = logging.getLogger(__name__)

router = APIRouter()


# ---------------------------------------------------------------------------
# GET /api/skus
# ---------------------------------------------------------------------------


@router.get(
    "/skus",
    tags=["Plugin: planner"],
    summary="Get SKU availability per zone",
    response_model=list[SkuInfo],
    responses={400: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
)
async def get_skus(
    region: str | None = Query(None, description="Azure region name."),
    subscriptionId: str | None = Query(None, description="Subscription ID."),  # noqa: N803
    tenantId: str | None = Query(None, description="Optional tenant ID."),  # noqa: N803
    resourceType: str = Query(  # noqa: N803
        "virtualMachines", description="ARM resource type to filter."
    ),
    name: str | None = Query(
        None,
        description=(
            "Case-insensitive substring match on SKU name (e.g. D2s matches Standard_D2s_v3)."
        ),
    ),
    family: str | None = Query(
        None,
        description="Case-insensitive substring match on SKU family (e.g. DSv3).",
    ),
    minVcpus: int | None = Query(  # noqa: N803
        None, description="Minimum vCPU count (inclusive).", ge=1
    ),
    maxVcpus: int | None = Query(  # noqa: N803
        None, description="Maximum vCPU count (inclusive).", ge=1
    ),
    minMemoryGB: float | None = Query(  # noqa: N803
        None, description="Minimum memory in GB (inclusive).", ge=0
    ),
    maxMemoryGB: float | None = Query(  # noqa: N803
        None, description="Maximum memory in GB (inclusive).", ge=0
    ),
    includePrices: bool = Query(  # noqa: N803
        False, description="Fetch retail prices from the Azure Retail Prices API."
    ),
    currencyCode: str = Query(  # noqa: N803
        "USD", description="ISO 4217 currency code for prices."
    ),
) -> JSONResponse:
    """Return resource SKUs with zone availability, restrictions and capabilities."""
    if not region or not subscriptionId:
        return JSONResponse(
            {"error": "Both 'region' and 'subscriptionId' query parameters are required"},
            status_code=400,
        )

    skus = await asyncio.to_thread(
        azure_api.get_skus,
        region,
        subscriptionId,
        tenantId,
        resourceType,
        name=name,
        family=family,
        min_vcpus=minVcpus,
        max_vcpus=maxVcpus,
        min_memory_gb=minMemoryGB,
        max_memory_gb=maxMemoryGB,
    )
    await azure_api.enrich_skus(
        skus,
        region,
        subscriptionId,
        quotas=True,
        prices=includePrices,
        confidence=True,
        currency_code=currencyCode,
        tenant_id=tenantId or "",
    )

    return JSONResponse(skus)


# ---------------------------------------------------------------------------
# POST /api/deployment-confidence
# ---------------------------------------------------------------------------


class DeploymentConfidenceRequest(BaseModel):
    """Request body for the deployment confidence endpoint."""

    subscriptionId: str
    region: str
    currencyCode: str = "USD"
    preferSpot: bool = False
    instanceCount: int = 1
    skus: list[str]
    includeSignals: bool = True
    includeProvenance: bool = True
    tenantId: str | None = None


@router.post(
    "/deployment-confidence",
    tags=["Plugin: planner"],
    summary="Compute Deployment Confidence Scores (bulk)",
    response_model=DeploymentConfidenceResponse,
    responses={400: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
)
async def deployment_confidence(body: DeploymentConfidenceRequest) -> JSONResponse:
    """Compute the canonical Deployment Confidence Score for a set of SKUs."""
    if not body.region or not body.subscriptionId or not body.skus:
        return JSONResponse(
            {"error": "'region', 'subscriptionId' and 'skus' are required"},
            status_code=400,
        )

    evaluated_at = __import__("datetime").datetime.now(__import__("datetime").UTC).isoformat()
    results: list[dict[str, Any]] = []
    warnings: list[str] = []
    errors: list[str] = []

    all_skus = await asyncio.to_thread(
        azure_api.get_skus,
        body.region,
        body.subscriptionId,
        body.tenantId,
        "virtualMachines",
    )
    await asyncio.to_thread(
        azure_api.enrich_skus_with_quotas,
        all_skus,
        body.region,
        body.subscriptionId,
        body.tenantId,
    )
    await asyncio.to_thread(
        azure_api.enrich_skus_with_prices, all_skus, body.region, body.currencyCode
    )

    sku_map = {s["name"]: s for s in all_skus}

    spot_scores: dict[str, dict[str, str]] = {}
    if body.preferSpot:
        try:
            spot_result = await asyncio.to_thread(
                azure_api.get_spot_placement_scores,
                body.region,
                body.subscriptionId,
                body.skus,
                body.instanceCount,
                body.tenantId,
            )
            spot_scores = spot_result.get("scores", {})
        except Exception:
            logger.warning("Spot placement score fetch failed; continuing without spot")
            warnings.append("Spot placement scores unavailable")

    for sku_name in body.skus:
        sku_data = sku_map.get(sku_name)
        if sku_data is None:
            errors.append(f"SKU '{sku_name}' not found in region '{body.region}'")
            continue

        sku_spot_zones = spot_scores.get(sku_name, {})
        spot_label = best_spot_label(sku_spot_zones)
        if body.preferSpot and sku_spot_zones and spot_label is None:
            zone_values = list(sku_spot_zones.values())
            warnings.append(
                f"Spot data for '{sku_name}' returned non-scorable values "
                f"({', '.join(zone_values)}); excluded from confidence."
            )
        elif body.preferSpot and not sku_spot_zones and not warnings:
            warnings.append(f"No Spot Placement Score data available for '{sku_name}'.")
        sig = signals_from_sku(
            sku_data,
            spot_score_label=spot_label,
            instance_count=body.instanceCount,
        )
        result = compute_deployment_confidence(sig)

        entry: dict[str, Any] = {
            "sku": sku_name,
            "deploymentConfidence": result.model_dump(
                exclude={"provenance"} if not body.includeProvenance else set()
            ),
        }
        if body.includeSignals:
            entry["rawSignals"] = sig.model_dump()

        results.append(entry)

    return JSONResponse(
        {
            "region": body.region,
            "subscriptionId": body.subscriptionId,
            "evaluatedAtUtc": evaluated_at,
            "results": results,
            "warnings": warnings,
            "errors": errors,
        }
    )


# ---------------------------------------------------------------------------
# POST /api/spot-scores
# ---------------------------------------------------------------------------


class SpotScoresRequest(BaseModel):
    """Request body for the spot placement scores endpoint."""

    region: str
    subscriptionId: str
    skus: list[str]
    instanceCount: int = 1
    tenantId: str | None = None


@router.post(
    "/spot-scores",
    tags=["Plugin: planner"],
    summary="Get Spot Placement Scores",
    response_model=SpotScoresResponse,
    responses={400: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
)
async def get_spot_scores(body: SpotScoresRequest) -> JSONResponse:
    """Return Spot Placement Scores for a list of VM sizes."""
    if not body.region or not body.subscriptionId or not body.skus:
        return JSONResponse(
            {"error": "'region', 'subscriptionId' and 'skus' are required"},
            status_code=400,
        )
    result = await asyncio.to_thread(
        azure_api.get_spot_placement_scores,
        body.region,
        body.subscriptionId,
        body.skus,
        body.instanceCount,
        body.tenantId,
    )
    return JSONResponse(result)
