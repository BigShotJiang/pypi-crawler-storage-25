"""Validator — orchestrates checkers and aggregates results."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol, cast

import sqlglot
from sqlglot import exp

from agentic_data_contracts.adapters._normalizer import SqlNormalizer
from agentic_data_contracts.core.contract import DataContract
from agentic_data_contracts.core.principal import (
    Principal,
    principal_in_scope,
    resolve_principal,
)
from agentic_data_contracts.validation.checkers import (
    BlockedColumnsChecker,
    CheckResult,
    MaxJoinsChecker,
    NoSelectStarChecker,
    OperationBlocklistChecker,
    RelationshipChecker,
    RequiredFilterChecker,
    RequiredFilterValuesChecker,
    RequireLimitChecker,
    ResultCheckRunner,
    TableAllowlistChecker,
    extract_tables,
)
from agentic_data_contracts.validation.explain import ExplainAdapter

# (allowed_principals, blocked_principals) snapshot taken at build time. None
# means the rule has no principal restriction. Schema-level mutual exclusion
# guarantees at most one of the two lists is non-None.
PrincipalScope = tuple[list[str] | None, list[str] | None] | None

if TYPE_CHECKING:
    from agentic_data_contracts.semantic.base import SemanticSource


class Checker(Protocol):
    """Protocol for SQL AST checkers.

    Two usage patterns:
    - Structural checkers (TableAllowlist, OperationBlocklist) take (ast, contract)
    - Rule-based checkers (RequiredFilter, NoSelectStar, etc.) take (ast) only
    The Validator calls them through separate paths; *args bridges both.
    """

    def check_ast(self, ast: exp.Expression, *args: Any) -> CheckResult: ...


@dataclass
class ValidationResult:
    blocked: bool
    reasons: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    log_messages: list[str] = field(default_factory=list)
    estimated_cost_usd: float | None = None
    estimated_rows: int | None = None
    schema_valid: bool = True
    explain_errors: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class _QueryRuleEntry:
    enforcement: str
    table_scope: str | None
    principal_scope: PrincipalScope
    checker: Any


@dataclass(frozen=True)
class _ResultRuleEntry:
    enforcement: str
    table_scope: str | None
    principal_scope: PrincipalScope
    runner: ResultCheckRunner


class Validator:
    """Runs all applicable checkers against a SQL query."""

    def __init__(
        self,
        contract: DataContract,
        dialect: str | None = None,
        explain_adapter: ExplainAdapter | None = None,
        sql_normalizer: SqlNormalizer | None = None,
        semantic_source: SemanticSource | None = None,
        *,
        caller_principal: Principal = None,
    ) -> None:
        self.contract = contract
        self.dialect = dialect
        self.explain_adapter = explain_adapter
        self.sql_normalizer = sql_normalizer
        self._caller_principal = caller_principal
        self._relationship_checker: RelationshipChecker | None = None
        if semantic_source is not None:
            rels = semantic_source.get_relationships()
            if rels:
                self._relationship_checker = RelationshipChecker(rels)
        self._build_checkers()

    def _build_checkers(self) -> None:
        semantic = self.contract.schema.semantic

        # The lambda closes over `self`, so each validate() call re-reads
        # self._caller_principal. Do NOT inline this to a precomputed value
        # — the Webex pattern (one Validator, ContextVar-switched identity
        # per message) depends on late binding here.
        self._table_checker = (
            TableAllowlistChecker(
                principal_resolver=lambda: resolve_principal(self._caller_principal)
            )
            if semantic.allowed_tables
            else None
        )
        self._operation_checker = (
            OperationBlocklistChecker() if semantic.forbidden_operations else None
        )

        self._query_checkers: list[_QueryRuleEntry] = []
        self._result_checkers: list[_ResultRuleEntry] = []

        for rule in semantic.rules:
            table_scope = rule.table if rule.table and rule.table != "*" else None
            # Capture the principal scope once at build time so a future
            # schema mutation (mirroring how resolve_tables mutates entries)
            # cannot retroactively change the gating semantics.
            principal_scope: PrincipalScope = (
                (rule.allowed_principals, rule.blocked_principals)
                if rule.allowed_principals is not None
                or rule.blocked_principals is not None
                else None
            )

            if rule.query_check is not None:
                qc = rule.query_check
                if qc.required_filter is not None:
                    self._query_checkers.append(
                        _QueryRuleEntry(
                            enforcement=rule.enforcement.value,
                            table_scope=table_scope,
                            principal_scope=principal_scope,
                            checker=RequiredFilterChecker(qc.required_filter),
                        )
                    )
                if qc.required_filter_values is not None:
                    rfv = qc.required_filter_values
                    self._query_checkers.append(
                        _QueryRuleEntry(
                            enforcement=rule.enforcement.value,
                            table_scope=table_scope,
                            principal_scope=principal_scope,
                            checker=RequiredFilterValuesChecker(
                                rfv.column, rfv.values_by_principal
                            ),
                        )
                    )
                if qc.no_select_star is True:
                    self._query_checkers.append(
                        _QueryRuleEntry(
                            enforcement=rule.enforcement.value,
                            table_scope=table_scope,
                            principal_scope=principal_scope,
                            checker=NoSelectStarChecker(),
                        )
                    )
                if qc.blocked_columns is not None:
                    self._query_checkers.append(
                        _QueryRuleEntry(
                            enforcement=rule.enforcement.value,
                            table_scope=table_scope,
                            principal_scope=principal_scope,
                            checker=BlockedColumnsChecker(qc.blocked_columns),
                        )
                    )
                if qc.require_limit is True:
                    self._query_checkers.append(
                        _QueryRuleEntry(
                            enforcement=rule.enforcement.value,
                            table_scope=table_scope,
                            principal_scope=principal_scope,
                            checker=RequireLimitChecker(),
                        )
                    )
                if qc.max_joins is not None:
                    self._query_checkers.append(
                        _QueryRuleEntry(
                            enforcement=rule.enforcement.value,
                            table_scope=table_scope,
                            principal_scope=principal_scope,
                            checker=MaxJoinsChecker(qc.max_joins),
                        )
                    )

            elif rule.result_check is not None:
                runner = ResultCheckRunner(
                    column=rule.result_check.column,
                    min_value=rule.result_check.min_value,
                    max_value=rule.result_check.max_value,
                    not_null=rule.result_check.not_null,
                    min_rows=rule.result_check.min_rows,
                    max_rows=rule.result_check.max_rows,
                    rule_name=rule.name,
                )
                self._result_checkers.append(
                    _ResultRuleEntry(
                        enforcement=rule.enforcement.value,
                        table_scope=table_scope,
                        principal_scope=principal_scope,
                        runner=runner,
                    )
                )

    def pending_result_check_names(self) -> list[str]:
        """Return names of result checks that will run post-execution.

        Returns the full declared list — a *superset* of what actually
        executes for any given caller. Rules carrying ``allowed_principals``
        or ``blocked_principals`` may be skipped at validate-time when the
        current caller is out of scope; they remain reported here because
        this method has no caller context to resolve and resolving a
        callable principal at unexpected moments would create a TOCTOU
        surface for the only consumer (run_query telemetry).
        """
        return [entry.runner.rule_name for entry in self._result_checkers]

    def _is_table_in_scope(
        self, table_scope: str | None, referenced_tables: set[str]
    ) -> bool:
        if table_scope is None:
            return True
        return table_scope in referenced_tables

    @staticmethod
    def _rule_applies_to_principal(
        principal_scope: PrincipalScope, resolved: str | None
    ) -> bool:
        """Return True when a rule's principal scope admits ``resolved``."""
        if principal_scope is None:
            return True
        return principal_in_scope(resolved, principal_scope[0], principal_scope[1])

    def validate(self, sql: str) -> ValidationResult:
        reasons: list[str] = []
        warnings: list[str] = []
        log_messages: list[str] = []
        estimated_cost_usd: float | None = None
        estimated_rows: int | None = None
        schema_valid: bool = True
        explain_errors: list[str] = []

        try:
            normalized = (
                self.sql_normalizer.normalize_sql(sql) if self.sql_normalizer else sql
            )
            ast = cast(
                exp.Expression, sqlglot.parse_one(normalized, dialect=self.dialect)
            )
        except sqlglot.errors.ParseError as e:
            return ValidationResult(blocked=True, reasons=[f"SQL parse error: {e}"])

        referenced_tables = extract_tables(ast)

        # Resolve once per validate() — matches TableAllowlistChecker's
        # once-per-check_ast contract and gives every rule a consistent
        # snapshot of the caller's identity for this query.
        resolved_principal = resolve_principal(self._caller_principal)

        if self._table_checker is not None:
            result = self._table_checker.check_ast(ast, self.contract)
            if not result.passed:
                reasons.append(result.message)

        if self._operation_checker is not None:
            result = self._operation_checker.check_ast(ast, self.contract)
            if not result.passed:
                reasons.append(result.message)

        for entry in self._query_checkers:
            if not self._is_table_in_scope(entry.table_scope, referenced_tables):
                continue
            if not self._rule_applies_to_principal(
                entry.principal_scope, resolved_principal
            ):
                continue
            result = entry.checker.check_ast(ast, resolved_principal=resolved_principal)
            if not result.passed:
                if entry.enforcement == "block":
                    reasons.append(result.message)
                elif entry.enforcement == "warn":
                    warnings.append(result.message)
                else:
                    log_messages.append(result.message)

        # Relationship advisory checks (warnings only, skip if already blocked)
        if not reasons and self._relationship_checker is not None:
            rel_warnings = self._relationship_checker.check_joins(ast)
            warnings.extend(rel_warnings)

        if not reasons and self.explain_adapter is not None:
            explain_result = self.explain_adapter.explain(sql)
            schema_valid = explain_result.schema_valid
            explain_errors = list(explain_result.errors)
            estimated_cost_usd = explain_result.estimated_cost_usd
            estimated_rows = explain_result.estimated_rows
            if not explain_result.schema_valid:
                # `reasons` blocks the query; `explain_errors` carries raw
                # diagnostics for inspect_query.
                reasons.append(
                    f"Schema validation failed: {', '.join(explain_result.errors)}"
                )
            else:
                res = self.contract.schema.resources
                if res:
                    if (
                        res.cost_limit_usd is not None
                        and explain_result.estimated_cost_usd is not None
                        and explain_result.estimated_cost_usd > res.cost_limit_usd
                    ):
                        cost = explain_result.estimated_cost_usd
                        limit = res.cost_limit_usd
                        reasons.append(
                            f"Estimated cost ${cost:.2f} exceeds limit ${limit:.2f}"
                        )
                    if (
                        res.max_rows_scanned is not None
                        and explain_result.estimated_rows is not None
                        and explain_result.estimated_rows > res.max_rows_scanned
                    ):
                        rows = explain_result.estimated_rows
                        max_rows = res.max_rows_scanned
                        reasons.append(
                            f"Estimated rows {rows:,} exceeds limit {max_rows:,}"
                        )

        return ValidationResult(
            blocked=len(reasons) > 0,
            reasons=reasons,
            warnings=warnings,
            log_messages=log_messages,
            estimated_cost_usd=estimated_cost_usd,
            estimated_rows=estimated_rows,
            schema_valid=schema_valid,
            explain_errors=explain_errors,
        )

    def validate_results(
        self, sql: str, columns: list[str], rows: list[tuple]
    ) -> ValidationResult:
        reasons: list[str] = []
        warnings: list[str] = []
        log_messages: list[str] = []

        try:
            normalized = (
                self.sql_normalizer.normalize_sql(sql) if self.sql_normalizer else sql
            )
            ast = cast(
                exp.Expression, sqlglot.parse_one(normalized, dialect=self.dialect)
            )
        except sqlglot.errors.ParseError:
            referenced_tables: set[str] = set()
        else:
            referenced_tables = extract_tables(ast)

        resolved_principal = resolve_principal(self._caller_principal)

        for entry in self._result_checkers:
            if not self._is_table_in_scope(entry.table_scope, referenced_tables):
                continue
            if not self._rule_applies_to_principal(
                entry.principal_scope, resolved_principal
            ):
                continue
            result = entry.runner.check_results(columns, rows)
            if not result.passed:
                if entry.enforcement == "block":
                    reasons.append(result.message)
                elif entry.enforcement == "warn":
                    warnings.append(result.message)
                else:
                    log_messages.append(result.message)

        return ValidationResult(
            blocked=len(reasons) > 0,
            reasons=reasons,
            warnings=warnings,
            log_messages=log_messages,
        )
