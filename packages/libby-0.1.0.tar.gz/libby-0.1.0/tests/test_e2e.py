"""test_e2e.py — End-to-end tests for the Libby API.

exports: test_health, test_calibrate_shroud, test_calibrate_missing_curve,
         test_history
used_by: pytest runner
rules:   These tests start the full FastAPI app with lifespan.
         They require curve data files in src/libby/curves/.
agent:   deepseek-v4-flash | 2026-05-13 | Created E2E tests with TestClient.
         message: "Uses TestClient as context manager to ensure lifespan runs."
"""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from libby.main import create_app

CURVE_DIR = Path(__file__).resolve().parent.parent / "src" / "libby" / "curves"

pytestmark = pytest.mark.skipif(
    not (CURVE_DIR / "intcal20.14c").exists(),
    reason="IntCal20 curve file not found — run download script first",
)


@pytest.fixture
def client():
    """Create a TestClient with lifespan running."""
    app = create_app()
    with TestClient(app) as c:
        yield c


def test_health(client):
    """Health endpoint returns status ok."""
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert data["version"] == "0.1.0"


def test_calibrate_shroud(client):
    """Calibrate Shroud of Turin reference date."""
    resp = client.post("/calibrate", json={
        "bp_age": 691,
        "std_dev": 31,
        "curve": "intcal20",
        "name": "Shroud of Turin",
        "material": "textile",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["success"] is True
    assert data["data"] is not None
    assert data["data"]["cal_bp_median"] is not None
    # Medieval period expected
    median_ce = 1950 - data["data"]["cal_bp_median"]
    assert 1200 < median_ce < 1450
    # Ranges should exist
    assert len(data["data"]["ranges_1sigma"]) > 0
    assert len(data["data"]["ranges_2sigma"]) > 0
    # Narrative should be present (fallback or LLM)
    assert data["narrative"] is not None
    assert len(data["narrative"]) > 20


def test_calibrate_hallstatt(client):
    """A Hallstatt plateau date should include a plateau warning."""
    resp = client.post("/calibrate", json={
        "bp_age": 2450,
        "std_dev": 25,
        "name": "Hallstatt test",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["success"] is True
    # Should detect plateau
    if data["data"]["plateau_warning"] is not None:
        assert "Hallstatt" in data["data"]["plateau_warning"]


def test_history(client):
    """History endpoint returns recent calibrations."""
    # First make a calibration
    client.post("/calibrate", json={
        "bp_age": 691, "std_dev": 31,
    })
    # Then check history
    resp = client.get("/history?limit=5")
    assert resp.status_code == 200
    history = resp.json()
    assert isinstance(history, list)
    assert len(history) >= 1


def test_calibrate_invalid(client):
    """Invalid requests return appropriate errors."""
    # Negative std dev
    resp = client.post("/calibrate", json={
        "bp_age": 1000, "std_dev": -1,
    })
    assert resp.status_code == 422  # Validation error
