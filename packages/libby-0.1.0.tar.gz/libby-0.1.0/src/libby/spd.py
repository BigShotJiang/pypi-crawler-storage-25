"""spd.py — Summed Probability Distribution computation for multi-date batches.

exports: compute_spd(calibrated_dates) -> SpdResult
used_by: main.py → POST /calibrate/batch
rules:   Each date's PDF is interpolated onto a common calendar-age axis before
         summing. The result is normalised so the area integrates to 1.
agent:   deepseek-v4-flash | 2026-05-13 | Created SPD module for batch
         calibration. Uses linear interpolation onto a shared age axis.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from libby.models import CalibratedDate, ProbabilityDensityPoint, SpdPoint, SpdResult


def _interpolate_pdf(
    cal_age: NDArray[np.float64],
    density: NDArray[np.float64],
    target_axis: NDArray[np.float64],
) -> NDArray[np.float64]:
    """Interpolate a PDF onto a target calendar age axis.

    Handles descending or ascending cal_age arrays. Returns densities
    normalised to integrate to 1 over target_axis.
    """
    # Ensure ascending for interpolation
    if len(cal_age) > 1 and cal_age[0] > cal_age[1]:
        cal_age = cal_age[::-1]
        density = density[::-1]

    # Clip to the range where the PDF has data
    valid = (target_axis >= cal_age[0]) & (target_axis <= cal_age[-1])
    interp = np.zeros_like(target_axis)
    interp[valid] = np.interp(target_axis[valid], cal_age, density, left=0, right=0)

    # Renormalize
    total = np.trapezoid(interp, target_axis)
    if total > 0:
        interp = interp / total

    return interp


def compute_spd(dates: list[CalibratedDate], step: int = 5) -> SpdResult:
    """Compute the Summed Probability Distribution across multiple dates.

    All dates' PDFs are interpolated onto a common calendar-age axis
    (spanning the full range of all dates, with `step`-year resolution),
    summed pointwise, and normalised.

    Args:
        dates: List of calibrated dates.
        step: Year step for the common age axis (default 5).

    Returns:
        SpdResult with the summed PDF and metadata.
    """
    if not dates:
        return SpdResult(spd=[], n_dates=0, age_min=0, age_max=0)

    # Determine common age range
    all_ages = []
    all_densities = []
    for d in dates:
        ages = np.array([p.cal_age for p in d.calibrated_pdf], dtype=np.float64)
        dens = np.array([p.density for p in d.calibrated_pdf], dtype=np.float64)
        all_ages.append(ages)
        all_densities.append(dens)

    age_min = min(a.min() for a in all_ages)
    age_max = max(a.max() for a in all_ages)

    # Build common axis
    common_axis = np.arange(age_min, age_max + step, step, dtype=np.float64)

    # Interpolate and sum
    summed = np.zeros_like(common_axis)
    for ages, dens in zip(all_ages, all_densities):
        interp = _interpolate_pdf(ages, dens, common_axis)
        summed += interp

    # Normalise the SPD
    total = np.trapezoid(summed, common_axis)
    if total > 0:
        summed = summed / total

    # Build output
    spd_points = [
        SpdPoint(cal_age=int(round(float(a))), density=float(d))
        for a, d in zip(common_axis, summed)
    ]

    return SpdResult(
        spd=spd_points,
        n_dates=len(dates),
        age_min=int(round(age_min)),
        age_max=int(round(age_max)),
    )
