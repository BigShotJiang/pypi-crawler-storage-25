"""bayesian.py — Bayesian Phase and Sequence modelling via MCMC.

exports: run_phase_model(dates) -> PhaseResult, run_sequence_model(dates) -> SequenceResult
used_by: main.py → POST /model
rules:   Uses plain numpy/scipy for Metropolis-Hastings MCMC — no external
         MCMC library dependency. The Agreement Index follows OxCal's
         convention (A > 60 indicates acceptable agreement).
agent:   deepseek-v4-flash | 2026-05-13 | Created Bayesian modelling engine
         with Phase (bounded group) and Sequence (stratigraphic order) models.
         message: "Simple Metropolis-Hastings with adaptive proposal width.
         Agreement Index per date and overall model agreement computed.
         Posterior dates computed by re-weighting PDFs with phase boundaries."
"""

from __future__ import annotations

import math
from typing import List

import numpy as np
from numpy.typing import NDArray
from pydantic import BaseModel, Field

from libby.models import CalibratedDate, CalibratedRange, ProbabilityDensityPoint


# ---- Pydantic output models ----

class ModelledDate(BaseModel):
    """A single date with both unmodelled and modelled ranges."""
    name: str | None = None
    bp_age: int = 0
    std_dev: float = 0
    unmodelled_2sigma: List[CalibratedRange] = Field(default_factory=list)
    modelled_2sigma: List[CalibratedRange] = Field(default_factory=list)
    agreement_index: float | None = None


class PhaseResult(BaseModel):
    """Result of a Phase model run."""
    model_type: str = "phase"
    alpha_samples: List[float] = Field(default_factory=list)
    beta_samples: List[float] = Field(default_factory=list)
    alpha_mean: float | None = None
    beta_mean: float | None = None
    alpha_hpd: CalibratedRange | None = None
    beta_hpd: CalibratedRange | None = None
    modelled_dates: List[ModelledDate] = Field(default_factory=list)
    overall_agreement: float | None = None
    narrative: str = ""


class SequenceResult(BaseModel):
    """Result of a Sequence model run."""
    model_type: str = "sequence"
    modelled_dates: List[ModelledDate] = Field(default_factory=list)
    overall_agreement: float | None = None
    narrative: str = ""


# ---- Internal helpers ----

def _interpolate_pdf(
    cal_age: NDArray[np.float64],
    density: NDArray[np.float64],
    target: NDArray[np.float64],
) -> NDArray[np.float64]:
    """Interpolate a calibrated PDF onto a target age axis."""
    if len(cal_age) > 1 and cal_age[0] > cal_age[1]:
        cal_age = cal_age[::-1]
        density = density[::-1]
    interp = np.interp(target, cal_age, density, left=0, right=0)
    total = np.trapezoid(interp, target)
    if total > 0:
        interp = interp / total
    return interp


def _compute_hpd_range_from_samples(samples: NDArray[np.float64], confidence: float = 0.954) -> CalibratedRange:
    """Compute an HPD range from a list of MCMC samples."""
    if len(samples) < 100:
        lo, hi = np.percentile(samples, [2.5, 97.5])
        return CalibratedRange(from_cal_bp=int(round(lo)), to_cal_bp=int(round(hi)), confidence=confidence)

    # Sort samples, find the densest region
    sorted_s = np.sort(samples)
    n = len(sorted_s)
    n_included = max(2, int(round(n * confidence)))
    best_width = float('inf')
    best_lo = float(sorted_s[0])
    best_hi = float(sorted_s[-1])

    for i in range(n - n_included + 1):
        width = sorted_s[i + n_included - 1] - sorted_s[i]
        if width < best_width:
            best_width = width
            best_lo = float(sorted_s[i])
            best_hi = float(sorted_s[i + n_included - 1])

    return CalibratedRange(
        from_cal_bp=int(round(best_lo)),
        to_cal_bp=int(round(best_hi)),
        confidence=confidence,
    )


def _probability_in_range(
    cal_age: NDArray[np.float64],
    density: NDArray[np.float64],
    lo: float,
    hi: float,
) -> float:
    """Compute the probability mass of a PDF within [lo, hi]."""
    if lo >= hi:
        return 0.0
    mask = (cal_age >= lo) & (cal_age <= hi)
    if not np.any(mask):
        return 0.0
    mass = np.trapezoid(density[mask], cal_age[mask])
    return max(0.0, mass)


def _agreement_index(
    cal_age: NDArray[np.float64],
    density: NDArray[np.float64],
    posterior_cal_age: NDArray[np.float64],
    posterior_density: NDArray[np.float64],
) -> float:
    """Compute OxCal-style Agreement Index.

    A = (probability of posterior at prior mode) / (probability of prior at prior mode) * 100
    Simplified: ratio of overlap between prior and posterior.
    """
    # Find prior mode
    prior_mode = cal_age[np.argmax(density)]
    # Probability at prior mode in prior
    prior_prob = np.interp(prior_mode, cal_age, density, left=0, right=0)
    # Probability at prior mode in posterior
    post_prob = np.interp(prior_mode, posterior_cal_age, posterior_density, left=0, right=0)

    if prior_prob <= 0:
        return 100.0  # Flat prior → always acceptable

    agreement = (post_prob / prior_prob) * 100.0
    return min(100.0, max(0.0, agreement))


# ---- Phase Model ----

def run_phase_model(
    dates: List[CalibratedDate],
    n_iterations: int = 15000,
    burn_in: int = 5000,
) -> PhaseResult:
    """Run a Bayesian Phase model: estimate start (α) and end (β) boundaries.

    The model assumes all dates belong to a single phase bounded by α (older)
    and β (younger), with a uniform prior for each date within [α, β].
    Uses Metropolis-Hastings MCMC.

    Args:
        dates: List of calibrated dates in the phase.
        n_iterations: Total MCMC iterations.
        burn_in: Iterations to discard as burn-in.

    Returns:
        PhaseResult with boundary estimates, modelled dates, and agreement.
    """
    if len(dates) < 2:
        return PhaseResult(narrative="Phase modelling requires at least 2 dates.")

    # Build common age axis spanning all dates' PDFs
    all_ages = [np.array([p.cal_age for p in d.calibrated_pdf], dtype=np.float64) for d in dates]
    age_min = max(1, min(a.min() for a in all_ages))
    age_max = max(a.max() for a in all_ages)

    # Pad the range by 20% for boundary exploration
    padding = (age_max - age_min) * 0.2
    age_min = max(1, age_min - padding)
    age_max = age_max + padding

    step = 5
    common_axis = np.arange(age_min, age_max + step, step, dtype=np.float64)

    # Interpolate all PDFs onto common axis
    pdfs = []
    for d in dates:
        ages = np.array([p.cal_age for p in d.calibrated_pdf], dtype=np.float64)
        dens = np.array([p.density for p in d.calibrated_pdf], dtype=np.float64)
        pdf = _interpolate_pdf(ages, dens, common_axis)
        pdfs.append(pdf)
    pdfs = np.array(pdfs)  # shape: (n_dates, n_axis)

    # MCMC: Metropolis-Hastings for α, β
    n_dates = len(dates)
    alpha_init = age_max - padding * 0.5
    beta_init = age_min + padding * 0.5

    alpha_current = float(alpha_init)
    beta_current = float(beta_init)

    alpha_samples = np.zeros(n_iterations)
    beta_samples = np.zeros(n_iterations)

    # Proposal width (adaptive)
    proposal_sigma = max(30.0, (age_max - age_min) * 0.02)

    # Precompute date-wise log-likelihood cache to speed up
    def log_likelihood(alpha: float, beta: float) -> float:
        """Log-likelihood: sum of log-probability of each date within [α, β]."""
        if alpha <= beta:
            return -1e12
        ll = 0.0
        width = alpha - beta
        if width <= 1:
            return -1e12
        for i in range(n_dates):
            mass = _probability_in_range(common_axis, pdfs[i], beta, alpha)
            if mass <= 0:
                return -1e12
            ll += math.log(mass / width)
        return ll

    ll_current = log_likelihood(alpha_current, beta_current)
    accept_count = 0

    for iteration in range(n_iterations):
        # Propose new α, β
        alpha_proposed = alpha_current + np.random.normal(0, proposal_sigma)
        beta_proposed = beta_current + np.random.normal(0, proposal_sigma)

        ll_proposed = log_likelihood(alpha_proposed, beta_proposed)

        # Acceptance
        if ll_proposed > ll_current or np.random.random() < math.exp(ll_proposed - ll_current):
            alpha_current = alpha_proposed
            beta_current = beta_proposed
            ll_current = ll_proposed
            accept_count += 1

        alpha_samples[iteration] = alpha_current
        beta_samples[iteration] = beta_current

    # Discard burn-in
    alpha_post = alpha_samples[burn_in:]
    beta_post = beta_samples[burn_in:]

    # Compute posterior date PDFs by multiplying each date's PDF by the phase boundaries
    modelled_dates_list: List[ModelledDate] = []
    overall_agreement_sum = 0.0

    for idx, (d, pdf) in enumerate(zip(dates, pdfs)):
        # For each MCMC sample, compute the posterior for this date
        # Posterior ~ likelihood × Uniform(α, β)
        posterior_samples = np.zeros(len(alpha_post))
        for i in range(len(alpha_post)):
            a = alpha_post[i]
            b = beta_post[i]
            if a > b and a - b > 1:
                # Re-weight: sample within [b, a] proportional to PDF
                mass = _probability_in_range(common_axis, pdf, b, a)
                if mass > 0:
                    # Sample from PDF within the phase
                    sub_axis = common_axis[(common_axis >= b) & (common_axis <= a)]
                    sub_pdf = pdf[(common_axis >= b) & (common_axis <= a)]
                    if len(sub_axis) > 1:
                        # Weighted sample
                        idx_sample = np.random.choice(len(sub_axis), p=sub_pdf / sub_pdf.sum())
                        posterior_samples[i] = sub_axis[idx_sample]
                    else:
                        posterior_samples[i] = (a + b) / 2
                else:
                    # Fallback: midpoint
                    posterior_samples[i] = (a + b) / 2
            else:
                posterior_samples[i] = (a + b) / 2

        # Compute modelled 2σ range from posterior samples
        modelled_2sigma = [_compute_hpd_range_from_samples(posterior_samples, 0.954)]

        # Agreement index
        ages_arr = np.array([p.cal_age for p in d.calibrated_pdf], dtype=np.float64)
        dens_arr = np.array([p.density for p in d.calibrated_pdf], dtype=np.float64)
        post_hist, post_edges = np.histogram(posterior_samples, bins=len(common_axis), range=(common_axis[0], common_axis[-1]))
        post_centers = (post_edges[:-1] + post_edges[1:]) / 2
        post_density = post_hist.astype(np.float64)
        total_p = np.trapezoid(post_density, post_centers)
        if total_p > 0:
            post_density = post_density / total_p
        agreement = _agreement_index(ages_arr, dens_arr, post_centers, post_density)
        overall_agreement_sum += agreement

        # All unmodelled 2σ ranges (handles discontinuous multimodal distributions)
        unmod_2sigma = [
            CalibratedRange(from_cal_bp=r.from_cal_bp, to_cal_bp=r.to_cal_bp, confidence=r.confidence)
            for r in d.ranges_2sigma
        ]

        modelled_dates_list.append(ModelledDate(
            name=f"Date {idx + 1}",
            bp_age=d.bp_age,
            std_dev=d.std_dev,
            unmodelled_2sigma=unmod_2sigma,
            modelled_2sigma=modelled_2sigma,
            agreement_index=round(agreement, 1),
        ))

    overall_agreement = round(overall_agreement_sum / max(1, len(dates)), 1)

    # Boundary HPD ranges
    alpha_hpd = _compute_hpd_range_from_samples(alpha_post, 0.954)
    beta_hpd = _compute_hpd_range_from_samples(beta_post, 0.954)

    # Narrative
    alpha_ce = 1950 - alpha_hpd.from_cal_bp
    beta_ce = 1950 - beta_hpd.to_cal_bp
    narrative = (
        f"Bayesian Phase model applied to {len(dates)} dates. "
        f"The estimated start boundary falls between {alpha_hpd.from_cal_bp}–{alpha_hpd.to_cal_bp} cal BP "
        f"and the end boundary between {beta_hpd.from_cal_bp}–{beta_hpd.to_cal_bp} cal BP (95.4% HPD). "
        f"The overall model agreement is A = {overall_agreement}. "
        + ("Values above 60 indicate acceptable agreement between the model and the data."
           if overall_agreement >= 60 else
           "Values below 60 suggest the model may be inconsistent with the data — "
           "check for outliers or misplaced dates.")
    )

    return PhaseResult(
        alpha_samples=[float(x) for x in alpha_post[::10]],  # Thin
        beta_samples=[float(x) for x in beta_post[::10]],
        alpha_mean=float(np.mean(alpha_post)),
        beta_mean=float(np.mean(beta_post)),
        alpha_hpd=alpha_hpd,
        beta_hpd=beta_hpd,
        modelled_dates=modelled_dates_list,
        overall_agreement=overall_agreement,
        narrative=narrative,
    )


# ---- Sequence Model ----

def run_sequence_model(
    dates: List[CalibratedDate],
    n_iterations: int = 15000,
    burn_in: int = 5000,
) -> SequenceResult:
    """Run a Bayesian Sequence model: dates in known stratigraphic order.

    Dates must be provided in stratigraphic order (oldest/deepest first).
    Each date's posterior is constrained by its neighbours:
        θ₁ < θ₂ < ... < θₙ

    Args:
        dates: Calibrated dates in stratigraphic order (oldest first).
        n_iterations: Total MCMC iterations.
        burn_in: Iterations to discard.

    Returns:
        SequenceResult with modelled dates and agreement.
    """
    if len(dates) < 2:
        return SequenceResult(narrative="Sequence modelling requires at least 2 dates in order.")

    # Build PDFs on common axis
    all_ages = [np.array([p.cal_age for p in d.calibrated_pdf], dtype=np.float64) for d in dates]
    age_min = max(1, min(a.min() for a in all_ages))
    age_max = max(a.max() for a in all_ages)
    padding = (age_max - age_min) * 0.1
    age_min = max(1, age_min - padding)
    age_max = age_max + padding
    step = 5
    common_axis = np.arange(age_min, age_max + step, step, dtype=np.float64)

    pdfs = []
    for d in dates:
        ages = np.array([p.cal_age for p in d.calibrated_pdf], dtype=np.float64)
        dens = np.array([p.density for p in d.calibrated_pdf], dtype=np.float64)
        pdf = _interpolate_pdf(ages, dens, common_axis)
        pdfs.append(pdf)

    n_dates = len(dates)

    # MCMC: sample each date's calendar age with ordering constraint
    # Initialize at prior modes
    current = np.array([common_axis[np.argmax(pdf)] for pdf in pdfs], dtype=np.float64)
    samples = np.zeros((n_iterations, n_dates))

    proposal_sigma = max(20.0, (age_max - age_min) * 0.01)
    accept_count = 0

    for iteration in range(n_iterations):
        # Random walk on one date at a time
        for idx in range(n_dates):
            proposed = float(current[idx]) + np.random.normal(0, proposal_sigma)

            # Enforce ordering constraint
            if idx > 0:
                if proposed >= current[idx - 1]:
                    continue
            if idx < n_dates - 1:
                if proposed <= current[idx + 1]:
                    continue

            # Likelihood ratio
            current_prob = np.interp(current[idx], common_axis, pdfs[idx], left=0, right=0)
            proposed_prob = np.interp(proposed, common_axis, pdfs[idx], left=0, right=0)

            if proposed_prob > 0 and (proposed_prob >= current_prob or
                                      np.random.random() < proposed_prob / max(current_prob, 1e-10)):
                current[idx] = proposed
                accept_count += 1

        samples[iteration] = current

    # Discard burn-in
    post_samples = samples[burn_in:]

    # Compute modelled dates
    modelled_dates_list: List[ModelledDate] = []
    overall_agreement_sum = 0.0

    for idx, d in enumerate(dates):
        post_vals = post_samples[:, idx]
        modelled_2sigma = [_compute_hpd_range_from_samples(post_vals, 0.954)]

        ages_arr = np.array([p.cal_age for p in d.calibrated_pdf], dtype=np.float64)
        dens_arr = np.array([p.density for p in d.calibrated_pdf], dtype=np.float64)
        post_hist, post_edges = np.histogram(post_vals, bins=len(common_axis), range=(common_axis[0], common_axis[-1]))
        post_centers = (post_edges[:-1] + post_edges[1:]) / 2
        post_density = post_hist.astype(np.float64)
        total_p = np.trapezoid(post_density, post_centers)
        if total_p > 0:
            post_density = post_density / total_p
        agreement = _agreement_index(ages_arr, dens_arr, post_centers, post_density)
        overall_agreement_sum += agreement

        # All unmodelled 2σ ranges (handles discontinuous multimodal distributions)
        unmod_2sigma = [
            CalibratedRange(from_cal_bp=r.from_cal_bp, to_cal_bp=r.to_cal_bp, confidence=r.confidence)
            for r in d.ranges_2sigma
        ]

        modelled_dates_list.append(ModelledDate(
            name=f"Date {idx + 1}",
            bp_age=d.bp_age,
            std_dev=d.std_dev,
            unmodelled_2sigma=unmod_2sigma,
            modelled_2sigma=modelled_2sigma,
            agreement_index=round(agreement, 1),
        ))

    overall_agreement = round(overall_agreement_sum / max(1, len(dates)), 1)

    narrative = (
        f"Bayesian Sequence model applied to {len(dates)} dates in stratigraphic order. "
        f"The ordering constraint narrows the calibrated ranges by {_compute_narrowing(modelled_dates_list)}% on average. "
        f"The overall model agreement is A = {overall_agreement}. "
        + ("Values above 60 indicate the stratigraphic order is consistent with the radiocarbon data."
           if overall_agreement >= 60 else
           "Values below 60 suggest one or more dates may be out of sequence — "
           "check for stratigraphic reversals or reworked material.")
    )

    return SequenceResult(
        modelled_dates=modelled_dates_list,
        overall_agreement=overall_agreement,
        narrative=narrative,
    )


def _compute_narrowing(modelled: List[ModelledDate]) -> int:
    """Compute average percentage narrowing from modelling."""
    reductions = []
    for m in modelled:
        if m.unmodelled_2sigma and m.modelled_2sigma:
            unmod_width = m.unmodelled_2sigma[0].to_cal_bp - m.unmodelled_2sigma[0].from_cal_bp
            mod_width = m.modelled_2sigma[0].to_cal_bp - m.modelled_2sigma[0].from_cal_bp
            if unmod_width > 0:
                pct = int(round((1 - mod_width / unmod_width) * 100))
                reductions.append(max(0, pct))
    if reductions:
        return int(round(sum(reductions) / len(reductions)))
    return 0
