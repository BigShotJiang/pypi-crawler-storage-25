"""nim.py — Nvidia NIM (OpenAI-compatible) LLM provider.

exports: NIMClient
used_by: providers/__init__.py → create_llm_client
rules:   Uses the OpenAI Python SDK pointed at Nvidia's API endpoint.
         Rate limit: 40 req/min per Nvidia's free tier. Handle gracefully.
agent:   deepseek-v4-flash | 2026-05-13 | Implemented NIM client conforming to
         LLMClient protocol. OpenAI-compatible chat completions endpoint.
         message: "Model default: meta/llama-3.1-70b-instruct. Base URL:
         https://integrate.api.nvidia.com/v1 for preview NIMs."
"""

from __future__ import annotations

import logging

from openai import AsyncOpenAI

logger = logging.getLogger(__name__)

NIM_DEFAULT_BASE_URL = "https://integrate.api.nvidia.com/v1"
NIM_DEFAULT_MODEL = "meta/llama-3.1-70b-instruct"


class NIMClient:
    """LLM client for Nvidia NIM (OpenAI-compatible) endpoints.

    Conforms to the LLMClient protocol used by libby.narrative.
    """

    def __init__(
        self,
        api_key: str,
        model: str = NIM_DEFAULT_MODEL,
        base_url: str = NIM_DEFAULT_BASE_URL,
        max_tokens: int = 512,
        temperature: float = 0.2,
    ) -> None:
        self._client = AsyncOpenAI(api_key=api_key, base_url=base_url)
        self._model = model
        self._max_tokens = max_tokens
        self._temperature = temperature

    async def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> str:
        """Call the NIM chat completion endpoint.

        Args:
            system_prompt: System-level instruction (e.g. the constraints).
            user_prompt: The statistical data to narrate.
            max_tokens: Override default max tokens.
            temperature: Override default temperature.

        Returns:
            Generated text string.

        Raises:
            Exception: Propagates OpenAI/network errors; caller should handle.
        """
        response = await self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            max_tokens=max_tokens or self._max_tokens,
            temperature=temperature if temperature is not None else self._temperature,
        )

        choice = response.choices[0]
        content = choice.message.content

        if content is None:
            return ""
        return content

    async def close(self) -> None:
        """Close the underlying HTTP client session."""
        await self._client.close()
