"""providers — LLM provider implementations for narrative generation.

exports: create_llm_client(provider_name, config) -> LLMClient | None
used_by: main.py → lifespan / startup
rules:   All providers must implement the LLMClient protocol defined in
         libby.narrative. Add new providers as pluggable submodules.
agent:   deepseek-v4-flash | 2026-05-13 | Created provider registry dispatch.
         message: "NIM wrapped OpenAI-compatible client. Add local providers below."
"""

from __future__ import annotations

import logging

from libby.config import Settings
from libby.narrative import LLMClient

logger = logging.getLogger(__name__)


def create_llm_client(settings: Settings) -> LLMClient | None:
    """Factory: instantiate the configured LLM provider or return None.

    Returns None if the chosen provider's API key is not set, which causes
    the app to use the deterministic fallback narrative.
    """
    provider = settings.llm_provider.lower()

    if provider == "nim":
        if not settings.nim_api_key:
            logger.warning("NIM provider selected but no NVIDIA_NIM_API_KEY set — using fallback narrative")
            return None
        from libby.providers.nim import NIMClient
        return NIMClient(
            api_key=settings.nim_api_key,
            model=settings.nim_model,
            base_url=settings.nim_base_url,
            max_tokens=settings.llm_max_tokens,
            temperature=settings.llm_temperature,
        )

    if provider == "anthropic":
        if not settings.anthropic_api_key:
            logger.warning("Anthropic provider selected but no ANTHROPIC_API_KEY set — using fallback narrative")
            return None
        from libby.providers.anthropic import AnthropicClient
        return AnthropicClient(
            api_key=settings.anthropic_api_key,
            model=settings.llm_model,
            max_tokens=settings.llm_max_tokens,
            temperature=settings.llm_temperature,
        )

    if provider in ("local", "ollama"):
        logger.info("Local LLM providers not yet implemented — using fallback narrative")
        return None

    logger.warning("Unknown LLM provider '%s' — using fallback narrative", provider)
    return None
