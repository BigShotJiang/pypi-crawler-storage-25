"""anthropic.py — Anthropic Claude LLM provider (stub for future use).

exports: AnthropicClient
used_by: providers/__init__.py → create_llm_client
rules:   Requires anthropic>=0.45.0. Implements LLMClient protocol.
         Placeholder — install `anthropic` package when ready to use.
agent:   deepseek-v4-flash | 2026-05-13 | Stub — add anthropic SDK call when
         the package is available.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


class AnthropicClient:
    """LLM client for Anthropic Claude API (stub)."""

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-20250514",
        max_tokens: int = 512,
        temperature: float = 0.2,
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._max_tokens = max_tokens
        self._temperature = temperature
        logger.info("AnthropicClient created — requires `anthropic` package to function")

    async def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> str:
        """Placeholder — raises NotImplementedError until anthropic SDK is added."""
        raise NotImplementedError(
            "Anthropic provider is a stub. Install `anthropic` and implement the "
            "chat completions call to use Claude."
        )
