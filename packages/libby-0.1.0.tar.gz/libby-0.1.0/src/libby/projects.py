"""projects.py — Project management routes for Phase 2 multi-date support.

exports: router (APIRouter with project CRUD + project-calibration endpoints)
used_by: main.py → app.include_router
rules:   Project names must be non-empty. Deleting a project unlinks its
         calibrations but does not delete them (project_id set to NULL).
agent:   deepseek-v4-flash | 2026-05-13 | Created project CRUD endpoints.
         message: "Full REST-style project management with calibration listing."
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request

from libby.database import (
    calibration_assign,
    project_calibrations,
    project_create,
    project_delete,
    project_get,
    project_list,
    project_update,
)

router = APIRouter(prefix="/projects", tags=["projects"])


@router.get("")
async def list_projects():
    """List all projects with their calibration counts."""
    return await project_list()


@router.post("")
async def create_project(name: str, description: str = ""):
    """Create a new project."""
    if not name or not name.strip():
        raise HTTPException(status_code=422, detail="Project name cannot be empty")
    pid = await project_create(name.strip(), description.strip())
    return {"id": pid, "name": name.strip(), "description": description.strip()}


@router.get("/{project_id}")
async def get_project(project_id: int, request: Request):
    """Get a project with all its calibrations and group narrative."""
    proj = await project_get(project_id)
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")
    cals = await project_calibrations(project_id)
    proj["calibrations"] = cals

    # Build group narrative from calibrated dates
    if cals:
        import json
        from libby.models import CalibratedDate
        from libby.narrative import generate_group_narrative

        dates = []
        for c in cals:
            try:
                dates.append(CalibratedDate.model_validate_json(c["result_json"]))
            except Exception:
                pass

        if dates:
            llm_client = getattr(request.app.state, "llm_client", None)
            proj["group_narrative"] = await generate_group_narrative(dates, llm_client)
        else:
            proj["group_narrative"] = None
    else:
        proj["group_narrative"] = None

    return proj


@router.put("/{project_id}")
async def update_project(project_id: int, name: str | None = None, description: str | None = None):
    """Update a project's name and/or description."""
    ok = await project_update(project_id, name=name, description=description)
    if not ok:
        raise HTTPException(status_code=404, detail="Project not found")
    return await project_get(project_id)


@router.delete("/{project_id}")
async def delete_project(project_id: int):
    """Delete a project (calibrations are unlinked, not deleted)."""
    ok = await project_delete(project_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"ok": True}


@router.post("/{project_id}/calibrations/{calibration_id}")
async def assign_calibration(project_id: int, calibration_id: int):
    """Assign an existing calibration to a project."""
    # Verify project exists
    proj = await project_get(project_id)
    if not proj:
        raise HTTPException(status_code=404, detail="Project not found")
    ok = await calibration_assign(calibration_id, project_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Calibration not found")
    return {"ok": True}
