"""report.py — PDF report generation for projects.

exports: generate_project_report(project_name, calibrations, spd, bayesian) -> bytes
used_by: main.py → GET /export/pdf/{project_id}
rules:   Uses ReportLab for PDF generation. SPD chart rendered via matplotlib.
         CC BY 4.0 attribution included per IntCal licensing requirements.
         Version auto-detected from package metadata.
agent:   deepseek-v4-flash | 2026-05-13 | Created PDF report generator.
         message: "Generates A4 portrait PDF with date table, SPD chart,
         Bayesian results, narrative, and citations."
"""

from __future__ import annotations

import importlib.metadata
import io
import json
from pathlib import Path
from typing import Any

try:
    LIBBY_VERSION = importlib.metadata.version("libby")
except importlib.metadata.PackageNotFoundError:
    LIBBY_VERSION = "0.1.0"

_LOGO_PATH = Path(__file__).resolve().parent.parent.parent / "frontend" / "static" / "libby-logo.png"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, mm
from reportlab.platypus import (
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from libby.models import CalibratedDate, SpdResult
from libby.narrative import build_fallback_narrative, build_group_narrative, get_taphonomic_warning

# Page dimensions
PAGE_W, PAGE_H = A4
MARGIN = 2 * cm


def _bp_to_bce(bp: float) -> str:
    ce = 1950 - bp
    if ce < 0:
        return f"{abs(int(round(ce)))} BCE"
    elif ce == 0:
        return "1 BCE"
    return f"{int(round(ce))} CE"


def _fmt_range_compact(r: Any) -> str:
    """Format a calibrated range as 'lo–hi cal BP'."""
    lo = min(r.from_cal_bp, r.to_cal_bp) if hasattr(r, 'from_cal_bp') else min(r.get("from_cal_bp", 0), r.get("to_cal_bp", 0))
    hi = max(r.from_cal_bp, r.to_cal_bp) if hasattr(r, 'to_cal_bp') else max(r.get("from_cal_bp", 0), r.get("to_cal_bp", 0))
    return f"{lo}–{hi} cal BP"


def _generate_spd_chart(calibrations: list[dict]) -> bytes:
    """Generate an SPD chart as a PNG byte array using matplotlib."""
    from libby.spd import compute_spd

    dates = []
    for c in calibrations:
        try:
            dates.append(CalibratedDate.model_validate_json(c["result_json"]))
        except Exception:
            continue

    if not dates:
        return b""

    spd = compute_spd(dates)
    if not spd.spd:
        return b""

    ages = [p.cal_age for p in spd.spd]
    dens = [p.density for p in spd.spd]

    fig, ax = plt.subplots(figsize=(6, 2.5))
    ax.fill_between(ages, dens, alpha=0.3, color="#2c6e49")
    ax.plot(ages, dens, color="#2c6e49", linewidth=1.5)
    ax.set_xlabel("Calendar age (cal BP)", fontsize=9)
    ax.set_ylabel("Summed probability", fontsize=9)
    ax.set_title(f"Summed Probability Distribution (n={spd.n_dates})", fontsize=10)
    ax.tick_params(labelsize=8)
    ax.set_xlim(max(ages), min(ages))  # Reverse: older on left
    fig.tight_layout(pad=1)

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return buf.read()


def _build_date_rows(calibrations: list[dict]) -> list[list[str]]:
    """Build table rows from calibration data."""
    rows = []
    for c in calibrations:
        name = c.get("name") or f"Date {c['id']}"
        bp = str(c["bp_age"])
        sd = str(c["std_dev"])
        try:
            result = json.loads(c["result_json"])
        except Exception:
            result = {}
        r1 = result.get("ranges_1sigma", [])
        r2 = result.get("ranges_2sigma", [])
        s1 = _fmt_range_compact(r1[0]) if r1 else "—"
        s2 = _fmt_range_compact(r2[0]) if r2 else "—"
        median = str(int(round(result.get("cal_bp_median", 0)))) if result.get("cal_bp_median") else "—"
        notes = []
        if result.get("is_bimodal"):
            notes.append("Multi-peak")
        if result.get("plateau_warning"):
            notes.append("Plateau")
        material = c.get("material", "")
        if material:
            warning = get_taphonomic_warning(material)
            if warning:
                notes.append(material.capitalize())
        rows.append([name, f"{bp}±{sd}", c.get("material", "—"), c.get("site", "—"), s2, s1, median, "; ".join(notes) or "—"])
    return rows


def generate_project_report(
    project_name: str,
    project_description: str,
    calibrations: list[dict],
    bayesian_result: dict | None = None,
) -> bytes:
    """Generate a complete A4 PDF report for a project."""
    buf = io.BytesIO()

    # Draw logo at absolute top-left corner on every page
    def _draw_logo(canvas_obj, doc_obj):
        if _LOGO_PATH.exists():
            canvas_obj.drawImage(
                str(_LOGO_PATH),
                x=MARGIN,
                y=PAGE_H - MARGIN - 2.18 * cm,
                width=2 * cm,
                height=2.18 * cm,
                preserveAspectRatio=True,
            )

    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=MARGIN, rightMargin=MARGIN,
        topMargin=MARGIN + 2.5 * cm, bottomMargin=MARGIN,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("Title2", parent=styles["Heading1"], fontSize=18, textColor=colors.HexColor("#2c6e49"))
    h2_style = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=13, spaceAfter=6)
    h3_style = ParagraphStyle("H3", parent=styles["Heading3"], fontSize=11, spaceAfter=4)
    body_style = ParagraphStyle("Body", parent=styles["Normal"], fontSize=9, leading=13, spaceAfter=6)
    small_style = ParagraphStyle("Small", parent=styles["Normal"], fontSize=7.5, leading=10, textColor=colors.HexColor("#666"))

    elements = []

    # Title
    elements.append(Paragraph(f"Libby Radiocarbon Report: {project_name}", title_style))
    if project_description:
        elements.append(Paragraph(project_description, body_style))
    elements.append(Spacer(1, 4 * mm))

    # Metadata
    n_dates = len(calibrations)
    sites = set(c.get("site") for c in calibrations if c.get("site"))
    site_str = f"; {', '.join(sites)}" if sites else ""
    elements.append(Paragraph(
        f"<b>Generated:</b> {__import__('datetime').datetime.now().strftime('%Y-%m-%d')}<br/>"
        f"<b>Dates:</b> {n_dates}",
        body_style,
    ))
    elements.append(Spacer(1, 4 * mm))

    # Group narrative
    dates_for_narrative = []
    for c in calibrations:
        try:
            dates_for_narrative.append(CalibratedDate.model_validate_json(c["result_json"]))
        except Exception:
            pass
    if dates_for_narrative:
        group_narrative = build_group_narrative(dates_for_narrative)
        elements.append(Paragraph(f"<b>Summary:</b> {group_narrative}", body_style))
        elements.append(Spacer(1, 4 * mm))

    # SPD chart
    spd_png = _generate_spd_chart(calibrations)
    if spd_png:
        img = Image(io.BytesIO(spd_png), width=16 * cm, height=7 * cm)
        elements.append(img)
        elements.append(Spacer(1, 4 * mm))

    # Date table
    elements.append(Paragraph("Date Listings", h2_style))
    date_rows = _build_date_rows(calibrations)
    if date_rows:
        table_data = [["Sample", "¹⁴C age", "Material", "Site", "2σ (95.4%)", "1σ (68.2%)", "Median", "Notes"]] + date_rows
        col_widths = [3.5*cm, 2*cm, 1.8*cm, 2*cm, 3*cm, 3*cm, 1.5*cm, 2.2*cm]
        table = Table(table_data, colWidths=col_widths, repeatRows=1)
        table.setStyle(TableStyle([
            ("FONTSIZE", (0, 0), (-1, -1), 7.5),
            ("FONTSIZE", (0, 0), (-1, 0), 8),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c6e49")),
            ("ALIGN", (1, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#ddd")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8f9fa")]),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        elements.append(table)
    elements.append(Spacer(1, 6 * mm))

    # Bayesian results
    if bayesian_result:
        elements.append(Paragraph("Bayesian Modelling", h2_style))
        elements.append(Paragraph(bayesian_result.get("narrative", ""), body_style))

        if bayesian_result.get("modelled_dates"):
            mod_rows = [["Date", "Unmodelled 2σ", "Modelled 2σ", "A"]]
            for m in bayesian_result["modelled_dates"]:
                unmod = m.get("unmodelled_2sigma", [])
                mod = m.get("modelled_2sigma", [])
                u_str = _fmt_range_compact(unmod[0]) if unmod else "—"
                m_str = _fmt_range_compact(mod[0]) if mod else "—"
                a_str = str(m.get("agreement_index", "—"))
                mod_rows.append([m.get("name", "—"), u_str, m_str, a_str])

            mod_table = Table(mod_rows, colWidths=[3*cm, 4*cm, 4*cm, 2*cm], repeatRows=1)
            mod_table.setStyle(TableStyle([
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#8b5cf6")),
                ("ALIGN", (1, 0), (-1, -1), "CENTER"),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#ddd")),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]))
            elements.append(mod_table)
            elements.append(Spacer(1, 4 * mm))

    # Individual narratives
    elements.append(Paragraph("Individual Date Narratives", h2_style))
    for c in calibrations:
        try:
            date = CalibratedDate.model_validate_json(c["result_json"])
        except Exception:
            continue
        narrative = build_fallback_narrative(date, material=c.get("material"))
        name = c.get("name") or f"Date {c['id']}"
        elements.append(Paragraph(f"<b>{name}</b>", h3_style))
        elements.append(Paragraph(narrative, body_style))

    # Citations and attribution
    elements.append(Spacer(1, 4 * mm))
    elements.append(Paragraph("Methodology & Attribution", h2_style))
    elements.append(Paragraph(
        "Calibration performed against the IntCal20, SHCal20, and Marine20 curves. "
        "Calendar ages reported at 68.2% (1σ) and 95.4% (2σ) confidence using Highest Posterior Density intervals. "
        "Bayesian modelling uses Metropolis-Hastings MCMC with uniform phase/sequence priors.",
        body_style,
    ))
    elements.append(Paragraph(
        "Calibration curves: IntCal20 (Reimer et al. 2020, Radiocarbon 62(4)), "
        "SHCal20 (Hogg et al. 2020, Radiocarbon 62(4)), "
        "Marine20 (Heaton et al. 2020, Radiocarbon 62(4)). "
        "CC BY 4.0 licensed.",
        small_style,
    ))
    elements.append(Paragraph(
        f"Generated by Libby v{LIBBY_VERSION} — https://github.com/mabo-du/libby · https://gitlab.com/mabodu/libby",
        small_style,
    ))

    doc.build(elements, onFirstPage=_draw_logo, onLaterPages=_draw_logo)
    return buf.getvalue()
