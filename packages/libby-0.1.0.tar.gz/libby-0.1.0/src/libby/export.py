"""export.py — CSV and plain-text export for calibrated radiocarbon dates.

exports: calibrations_to_csv(rows) -> str, calibration_to_text(result) -> str
used_by: main.py → /export/csv, /export/text
rules:   CSV follows a format suitable for publication (Radiocarbon journal style).
         Dates reported in both cal BP and BCE/CE per standard practice.
agent:   deepseek-v4-flash | 2026-05-13 | Created CSV and text export formats.
         message: "CSV columns: Sample ID, BP Age, ±, Curve, Material, Median,
         1σ ranges, 2σ ranges, Notes."
"""

from __future__ import annotations

import csv
import io
from typing import Any


def _bp_to_bce(bp: float) -> str:
    """Format a cal BP value as BCE/CE string."""
    year_ce = 1950 - bp
    if year_ce < 0:
        return f"{abs(int(round(year_ce)))} BCE"
    elif year_ce == 0:
        return "1 BCE"
    else:
        return f"{int(round(year_ce))} CE"


def _format_ranges_short(ranges: list[dict]) -> str:
    """Format HPD ranges as compact string: '3081–3090, 3113–3119, ...'"""
    parts = []
    for r in ranges:
        lo = min(r.get("from_cal_bp", r.get("from", 0)), r.get("to_cal_bp", 0))
        hi = max(r.get("from_cal_bp", r.get("from", 0)), r.get("to_cal_bp", 0))
        parts.append(f"{lo}–{hi}")
    return "; ".join(parts) if parts else "—"


def _format_ranges_bce(ranges: list[dict]) -> str:
    """Format HPD ranges in BCE/CE for readability."""
    parts = []
    for r in ranges:
        lo = min(r.get("from_cal_bp", r.get("from", 0)), r.get("to_cal_bp", 0))
        hi = max(r.get("from_cal_bp", r.get("from", 0)), r.get("to_cal_bp", 0))
        from_ce = _bp_to_bce(lo)
        to_ce = _bp_to_bce(hi)
        parts.append(f"{from_ce} to {to_ce}")
    return "; ".join(parts) if parts else "—"


def _build_notes(result: dict) -> str:
    """Build notes column from diagnostics."""
    notes = []
    if result.get("is_bimodal"):
        notes.append("Multimodal distribution")
    if result.get("plateau_warning"):
        notes.append("Hallstatt plateau")
    median = result.get("cal_bp_median")
    if median:
        median_ce = _bp_to_bce(median)
        notes.append(f"Median: {int(round(median))} cal BP ({median_ce})")
    return "; ".join(notes) if notes else "—"


def calibrations_to_csv(rows: list[dict]) -> str:
    """Convert a list of calibration result dicts to CSV string.

    Each row dict has 'name', 'bp_age', 'std_dev', 'curve', 'material',
    'result_json' (JSON string of full CalibratedDate), and 'narrative'.
    """
    output = io.StringIO()
    writer = csv.writer(output)

    # Header
    writer.writerow([
        "Sample ID",
        "14C age (BP)",
        "± 1σ",
        "Curve",
        "Material",
        "Median (cal BP)",
        "1σ ranges (cal BP)",
        "2σ ranges (cal BP)",
        "1σ ranges (BCE/CE)",
        "2σ ranges (BCE/CE)",
        "Notes",
    ])

    for row in rows:
        import json
        result = json.loads(row.get("result_json", "{}")) if isinstance(row.get("result_json"), str) else row

        name = row.get("name") or row.get("id", "") or ""
        bp_age = row.get("bp_age", "")
        std_dev = row.get("std_dev", "")
        curve = row.get("curve", "")
        material = row.get("material", "") or ""

        median = result.get("cal_bp_median", "")
        if median:
            median = int(round(median))

        ranges_1s = _format_ranges_short(result.get("ranges_1sigma", []))
        ranges_2s = _format_ranges_short(result.get("ranges_2sigma", []))
        ranges_1b = _format_ranges_bce(result.get("ranges_1sigma", []))
        ranges_2b = _format_ranges_bce(result.get("ranges_2sigma", []))
        notes = _build_notes(result)

        writer.writerow([
            name, bp_age, std_dev, curve, material,
            median,
            ranges_1s, ranges_2s,
            ranges_1b, ranges_2b,
            notes,
        ])

    return output.getvalue()


def calibration_to_text(result: Any, name: str | None = None, material: str | None = None) -> str:
    """Format a single calibration result as publication-ready plain text.

    Suitable for copy-paste into a site report or manuscript.
    """
    lines = []
    label = f" ({material})" if material else ""
    lines.append(f"Sample: {name or 'Unnamed'}{label}")
    lines.append(f"Conventional radiocarbon age: {result.bp_age} ± {result.std_dev} BP")
    lines.append(f"Calibration curve: {result.curve}")

    if result.cal_bp_median:
        median_ce = _bp_to_bce(result.cal_bp_median)
        lines.append(f"Median probability: {int(round(result.cal_bp_median))} cal BP ({median_ce})")

    # 2σ ranges (most commonly reported in publications)
    if result.ranges_2sigma:
        parts = []
        for r in result.ranges_2sigma:
            lo = min(r.from_cal_bp, r.to_cal_bp)
            hi = max(r.from_cal_bp, r.to_cal_bp)
            from_ce = _bp_to_bce(lo)
            to_ce = _bp_to_bce(hi)
            parts.append(f"{lo}–{hi} cal BP ({from_ce} to {to_ce})")
        lines.append(f"95.4% (2σ) calibrated range{'s' if len(parts) > 1 else ''}: {'; '.join(parts)}")

    # 1σ ranges
    if result.ranges_1sigma:
        parts = []
        for r in result.ranges_1sigma:
            lo = min(r.from_cal_bp, r.to_cal_bp)
            hi = max(r.from_cal_bp, r.to_cal_bp)
            from_ce = _bp_to_bce(lo)
            to_ce = _bp_to_bce(hi)
            parts.append(f"{lo}–{hi} cal BP ({from_ce} to {to_ce})")
        lines.append(f"68.2% (1σ) calibrated range{'s' if len(parts) > 1 else ''}: {'; '.join(parts)}")

    if result.is_bimodal:
        lines.append("Note: multimodal distribution — calibration curve reversals produce multiple possible age ranges.")

    if result.plateau_warning:
        lines.append(f"Note: {result.plateau_warning}")

    lines.append(f"Citation: IntCal20 (Reimer et al. 2020), SHCal20 (Hogg et al. 2020), Marine20 (Heaton et al. 2020)")

    return "\n".join(lines)
