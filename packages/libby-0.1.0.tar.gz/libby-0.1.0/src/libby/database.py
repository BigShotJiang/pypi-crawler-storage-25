"""database.py — SQLite database layer for projects and calibrations.

exports: init_db, save_calibration, get_calibration_history, and all
         project_* and calibration_* query functions
used_by: main.py → API endpoints
rules:   Schema migrations must be additive. Never drop columns in production.
         The site and context columns allow hierarchical project organisation.
agent:   deepseek-v4-flash | 2026-05-13 | Created async SQLite layer.
         deepseek-v4-flash | 2026-05-13 | Added project CRUD, site/context columns,
         migration support for existing databases.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import AsyncGenerator

import aiosqlite

DATABASE_PATH = "libby.db"

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    description TEXT DEFAULT '',
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS calibrations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER REFERENCES projects(id) ON DELETE SET NULL,
    name        TEXT,
    bp_age      INTEGER NOT NULL,
    std_dev     REAL NOT NULL,
    curve       TEXT NOT NULL DEFAULT 'intcal20',
    material    TEXT,
    site        TEXT DEFAULT '',
    context     TEXT DEFAULT '',
    result_json TEXT NOT NULL,
    narrative   TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_calibrations_project
    ON calibrations(project_id);
CREATE INDEX IF NOT EXISTS idx_calibrations_created
    ON calibrations(created_at);
CREATE INDEX IF NOT EXISTS idx_calibrations_site
    ON calibrations(site);
"""

# Additive migration statements for existing databases
MIGRATIONS = [
    "ALTER TABLE calibrations ADD COLUMN site TEXT DEFAULT ''",
    "ALTER TABLE calibrations ADD COLUMN context TEXT DEFAULT ''",
    "ALTER TABLE projects ADD COLUMN updated_at TEXT NOT NULL DEFAULT (datetime('now'))",
]


async def get_db() -> AsyncGenerator[aiosqlite.Connection, None]:
    """Yield an aiosqlite connection for the lifespan."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        yield db


async def init_db() -> None:
    """Initialise the database schema and run additive migrations."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        await db.executescript(SCHEMA_SQL)
        # Run additive migrations (safe to re-run — catches "duplicate column")
        for migration in MIGRATIONS:
            try:
                await db.execute(migration)
            except aiosqlite.OperationalError:
                pass  # Column already exists
        await db.commit()


# ---- Project CRUD ----

async def project_create(name: str, description: str = "") -> int:
    """Create a new project. Returns the project id."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO projects (name, description) VALUES (?, ?)",
            (name, description),
        )
        await db.commit()
        return cursor.lastrowid


async def project_list() -> list[dict]:
    """List all projects with calibration counts."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT p.*, COUNT(c.id) AS date_count
            FROM projects p
            LEFT JOIN calibrations c ON c.project_id = p.id
            GROUP BY p.id
            ORDER BY p.updated_at DESC
        """)
        rows = await cursor.fetchall()
        return [dict(r) for r in rows]


async def project_get(project_id: int) -> dict | None:
    """Get a single project by id."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM projects WHERE id = ?", (project_id,),
        )
        row = await cursor.fetchone()
        return dict(row) if row else None


async def project_update(project_id: int, name: str | None = None, description: str | None = None) -> bool:
    """Update a project's name and/or description."""
    fields = []
    values = []
    if name is not None:
        fields.append("name = ?")
        values.append(name)
    if description is not None:
        fields.append("description = ?")
        values.append(description)
    if not fields:
        return False
    fields.append("updated_at = datetime('now')")
    values.append(project_id)
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            f"UPDATE projects SET {', '.join(fields)} WHERE id = ?", values,
        )
        await db.commit()
        return cursor.rowcount > 0


async def project_delete(project_id: int) -> bool:
    """Delete a project and unlink its calibrations."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            "UPDATE calibrations SET project_id = NULL WHERE project_id = ?",
            (project_id,),
        )
        cursor = await db.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        await db.commit()
        return cursor.rowcount > 0


# ---- Calibration queries ----

async def save_calibration(
    bp_age: int,
    std_dev: float,
    curve: str,
    result_json: str,
    narrative: str | None = None,
    name: str | None = None,
    material: str | None = None,
    site: str | None = None,
    context: str | None = None,
    project_id: int | None = None,
) -> int:
    """Save a calibration result. Returns the row id."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            """INSERT INTO calibrations
               (project_id, name, bp_age, std_dev, curve, material, site, context, result_json, narrative)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (project_id, name, bp_age, std_dev, curve, material, site, context, result_json, narrative),
        )
        await db.commit()
        return cursor.lastrowid


async def get_calibration_history(limit: int = 20) -> list[dict]:
    """Get recent calibrations as a list of dicts."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM calibrations ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )
        rows = await cursor.fetchall()
        return [dict(r) for r in rows]


async def get_calibration_by_id(calibration_id: int) -> dict | None:
    """Get a single calibration by its ID (direct lookup, no limit)."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM calibrations WHERE id = ?", (calibration_id,),
        )
        row = await cursor.fetchone()
        return dict(row) if row else None


async def project_calibrations(project_id: int) -> list[dict]:
    """Get all calibrations belonging to a project."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM calibrations WHERE project_id = ? ORDER BY created_at ASC",
            (project_id,),
        )
        rows = await cursor.fetchall()
        return [dict(r) for r in rows]


async def calibration_assign(calibration_id: int, project_id: int) -> bool:
    """Assign a calibration to a project."""
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            "UPDATE calibrations SET project_id = ? WHERE id = ?",
            (project_id, calibration_id),
        )
        await db.commit()
        return cursor.rowcount > 0
