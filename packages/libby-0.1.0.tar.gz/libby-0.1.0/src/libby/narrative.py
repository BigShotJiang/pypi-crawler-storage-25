"""narrative.py — LLM-powered plain-English explanation of calibration results.

exports: generate_narrative, generate_group_narrative, build_fallback_narrative,
         build_group_narrative, get_taphonomic_warning
used_by: main.py → POST /calibrate, project pages
rules:   The system prompt MUST constrain the LLM to narrate ONLY the provided
         statistical output. It MUST NOT invent historical context, speculate
         about climate, or reference specific events/cultures.
         If no API key is configured, returns a structured fallback string.
agent:   deepseek-v4-flash | 2026-05-13 | Created constrained narrative generator.
         deepseek-v4-flash | 2026-05-13 | Added expanded taphonomic warnings.
         deepseek-v4-flash | 2026-05-13 | Added multi-language support (12 languages)
         via dynamic system prompts and language reinforcement in user prompts.
"""

from __future__ import annotations

from typing import Protocol

from libby.models import CalibratedDate


class LLMClient(Protocol):
    """Protocol for LLM API clients (avoids hard dependency on any provider)."""
    async def generate(self, system_prompt: str, user_prompt: str, **kwargs) -> str:
        ...


# ---- Supported languages ----

SUPPORTED_LANGUAGES: dict[str, str] = {
    "en": "English",
    "fr": "French",
    "de": "German",
    "es": "Spanish",
    "it": "Italian",
    "pt": "Portuguese",
    "ja": "Japanese",
    "ar": "Arabic",
    "zh": "Chinese (Simplified)",
    "nl": "Dutch",
    "sv": "Swedish",
    "pl": "Polish",
}

DEFAULT_LANGUAGE = "en"

# ---- Base system prompts ----

_SYSTEM_PROMPT_BASE = """You are a scientific communication assistant for radiocarbon dating.
Your ONLY job is to explain the statistical calibration result that the user provides.

RULES — you MUST follow all of these:
1. Only describe the numbers and statistical properties in the provided data.
2. Do NOT add historical context, cultural associations, or speculation about what the date means.
3. Do NOT mention specific historical events, rulers, wars, climate events, or civilizations.
4. If the distribution is bimodal, explain that this happens because the calibration curve has reversals at this period — do NOT guess which calendar year is more likely.
5. If a plateau warning is present, explain what it means for precision.
6. Use plain English suitable for a non-specialist (undergraduate level).
7. Keep it to 2-4 sentences.
8. Report dates in both cal BP and BCE/CE for accessibility.
9. If a taphonomic note is provided, include it factually.
10. CRITICAL: If the data lists MULTIPLE RANGES at a confidence level (e.g. "2σ ranges: A; B; C"), you MUST list ALL of them — never collapse them into a single range.
"""

_GROUP_SYSTEM_PROMPT_BASE = """You are a scientific communication assistant for radiocarbon dating.
Your job is to summarise a group of radiocarbon dates from a single research project.

RULES — you MUST follow all of these:
1. Only describe the numbers and statistical properties provided.
2. Do NOT add historical context, cultural associations, or speculation about what the date means.
3. Do NOT mention specific historical events, rulers, wars, climate events, or civilizations.
4. Report the overall date range spanned by the group.
5. Note how many dates are multimodal vs unimodal.
6. If any dates have taphonomic concerns, mention them.
7. Use plain English suitable for a non-specialist (undergraduate level).
8. Keep it to 3-5 sentences.
"""


def _build_system_prompt(language: str = "en") -> str:
    """Build the single-date system prompt, optionally in a target language."""
    lang_name = SUPPORTED_LANGUAGES.get(language, "English")
    if language != "en":
        lang_instruction = (
            f"11. LANGUAGE: Write your response entirely in {lang_name}. "
            f"Scientific notation (cal BP, BCE, CE, σ) remains unchanged. "
            f"Use standard scientific terminology for {lang_name} where it exists."
        )
    else:
        lang_instruction = "11. Write in clear, plain English."
    return _SYSTEM_PROMPT_BASE + "\n" + lang_instruction


def _build_group_system_prompt(language: str = "en") -> str:
    """Build the group system prompt, optionally in a target language."""
    lang_name = SUPPORTED_LANGUAGES.get(language, "English")
    if language != "en":
        lang_instruction = (
            f"9. LANGUAGE: Write your response entirely in {lang_name}. "
            f"Scientific notation (cal BP, BCE, CE, σ) remains unchanged."
        )
    else:
        lang_instruction = "9. Write in clear, plain English."
    return _GROUP_SYSTEM_PROMPT_BASE + "\n" + lang_instruction


# ---- Taphonomic warnings per material ----

TAPHONOMIC_WARNINGS: dict[str, str] = {
    "charcoal": (
        "if from a long-lived tree species, this sample may be subject to the "
        "'old wood effect' where the radiocarbon age predates the archaeological context"
    ),
    "wood": (
        "if from a long-lived tree species, this sample may be subject to the "
        "'old wood effect' where the radiocarbon age predates the archaeological context"
    ),
    "timber": (
        "timber often comes from the inner heartwood of old trees — the radiocarbon "
        "age may significantly predate the felling and use of the timber"
    ),
    "bone": (
        "bone dates reflect the collagen fraction; poor preservation can lead to "
        "younger dates if collagen is contaminated, or unreliable results if collagen "
        "yield is below 1%"
    ),
    "calcined bone": (
        "calcined (cremated) bone dates the structural carbonate, not collagen — "
        "this dates the cremation event itself, but can be affected by "
        "high-temperature recrystallisation"
    ),
    "sediment": (
        "bulk sediment dates reflect mixed organic material and may include older "
        "carbon from reworked sources — interpret as a \u2018terminus ante quem non\u2019 "
        "rather than a precise event date"
    ),
    "seed": (
        "short-lived plant remains (seeds, cereal grains) are ideal for dating — "
        "they represent a single growing season and avoid the old-wood effect"
    ),
    "grain": (
        "short-lived plant remains (seeds, cereal grains) are ideal for dating — "
        "they represent a single growing season and avoid the old-wood effect"
    ),
    "textile": (
        "textiles date the plant or animal fibres themselves — ensure the sample "
        "is not contaminated by conservation treatments or modern handling oils"
    ),
    "shell": (
        "marine shell dates may be affected by the marine reservoir effect — "
        "local ΔR corrections may be needed for accurate calendar ages"
    ),
    "other": None,
}


def get_taphonomic_warning(material: str | None) -> str | None:
    """Get the taphonomic warning for a given material type."""
    if not material:
        return None
    return TAPHONOMIC_WARNINGS.get(material.lower().strip(), None)


def _bp_to_bce(bp: float) -> int:
    """Convert cal BP to BCE/CE (where 0 BP = 1950 CE)."""
    year_ce = 1950 - bp
    return int(round(year_ce))


def _format_range(from_bp: int, to_bp: int) -> str:
    """Format a calibrated range in cal BP and BCE/CE."""
    from_bce = _bp_to_bce(from_bp)
    to_bce = _bp_to_bce(to_bp)
    if from_bp > to_bp:
        older_bp, younger_bp = from_bp, to_bp
        older_bce, younger_bce = from_bce, to_bce
    else:
        older_bp, younger_bp = to_bp, from_bp
        older_bce, younger_bce = to_bce, from_bce

    def _fmt(ce: int) -> str:
        if ce < 0:
            return f"{abs(ce)} BCE"
        elif ce == 0:
            return "1 BCE"
        return f"{ce} CE"

    return f"cal BP {older_bp}–{younger_bp} ({_fmt(older_bce)} to {_fmt(younger_bce)})"


# ---- Single-date narrative ----

def _build_user_prompt(
    date: CalibratedDate,
    material: str | None,
    language: str = "en",
) -> str:
    """Build the user prompt containing ONLY the statistical data to narrate."""
    sections = ["## Calibration Result to Narrate"]

    sections.append(f"\nRadiocarbon age: {date.bp_age} ± {date.std_dev} BP")
    sections.append(f"Calibration curve: {date.curve}")

    if date.ranges_1sigma:
        ranges_str = "; ".join(
            _format_range(r.from_cal_bp, r.to_cal_bp) for r in date.ranges_1sigma
        )
        sections.append(f"1σ (68.2%) ranges: {ranges_str}")

    if date.ranges_2sigma:
        ranges_str = "; ".join(
            _format_range(r.from_cal_bp, r.to_cal_bp) for r in date.ranges_2sigma
        )
        sections.append(f"2σ (95.4%) ranges: {ranges_str}")

    if date.cal_bp_median is not None:
        sections.append(f"Weighted median: {_format_range(int(round(date.cal_bp_median)), int(round(date.cal_bp_median)))}")

    if date.is_bimodal:
        sections.append("Distribution shape: bimodal (multi-peaked)")
    else:
        sections.append("Distribution shape: unimodal (single peak)")

    if date.plateau_warning:
        sections.append(f"Plateau warning: present — {date.plateau_warning}")

    if material:
        sections.append(f"Sample material: {material}")
        warning = get_taphonomic_warning(material)
        if warning:
            sections.append(f"Taphonomic note: {warning}.")

    sections.append("\nWrite a 2-4 sentence plain-English explanation of this result.")
    sections.append("Remember: narrate ONLY the numbers above. Do not add historical context.")

    if language != "en":
        lang_name = SUPPORTED_LANGUAGES.get(language, "English")
        sections.append(f"IMPORTANT: Your entire response must be in {lang_name}.")

    return "\n".join(sections)


def build_fallback_narrative(date: CalibratedDate, material: str | None = None) -> str:
    """Generate a deterministic fallback narrative when no LLM API key is configured."""
    lines = []

    mat = f" ({material})" if material else ""
    lines.append(
        f"Radiocarbon sample{mat} with measurement {date.bp_age} ± {date.std_dev} BP "
        f"was calibrated against the {date.curve.upper()} curve."
    )

    if date.cal_bp_median is not None:
        median_ce = 1950 - date.cal_bp_median
        ce_str = f"{abs(int(round(median_ce)))} BCE" if median_ce < 0 else f"{int(round(median_ce))} CE"
        lines.append(
            f"The weighted median calendar age is {int(round(date.cal_bp_median))} cal BP ({ce_str})."
        )

    if date.ranges_2sigma:
        all_2sigma = [_format_range(r.from_cal_bp, r.to_cal_bp) for r in date.ranges_2sigma]
        if len(all_2sigma) == 1:
            lines.append(f"At 95.4% confidence, the calendar age falls between {all_2sigma[0]}.")
        else:
            lines.append(f"At 95.4% confidence, the calendar age falls within {len(all_2sigma)} possible ranges: {'; '.join(all_2sigma)}.")

    if date.ranges_1sigma:
        all_1sigma = [_format_range(r.from_cal_bp, r.to_cal_bp) for r in date.ranges_1sigma]
        if len(all_1sigma) == 1:
            lines.append(f"At 68.2% confidence, the calendar age falls between {all_1sigma[0]}.")
        elif len(all_1sigma) > 1:
            lines.append(f"At 68.2% confidence, the range splits into {len(all_1sigma)} possible intervals: {'; '.join(all_1sigma)}.")

    if date.is_bimodal:
        lines.append(
            "The probability distribution is multimodal (has multiple distinct peaks), "
            "which means the calibration curve has reversals at this period "
            "and several different calendar ages are possible."
        )

    if date.plateau_warning:
        lines.append(date.plateau_warning)

    if material:
        warning = get_taphonomic_warning(material)
        if warning:
            lines.append(f"Note: {warning}.")

    return " ".join(lines)


# ---- Group (multi-date) narrative ----

def build_group_narrative(dates: list[CalibratedDate]) -> str:
    """Generate a deterministic summary narrative for a group of dates."""
    if not dates:
        return "No dates in this project."

    lines = []
    lines.append(f"This project contains {len(dates)} radiocarbon dates.")

    all_medians = [d.cal_bp_median for d in dates if d.cal_bp_median is not None]
    if all_medians:
        median_min = min(all_medians)
        median_max = max(all_medians)
        lines.append(f"The weighted median ages range from {int(round(median_min))} cal BP to {int(round(median_max))} cal BP.")

    multimodal_count = sum(1 for d in dates if d.is_bimodal)
    if multimodal_count:
        lines.append(f"{multimodal_count} of {len(dates)} dates have multimodal (multi-peak) distributions, indicating calibration curve reversals in those periods.")

    plateau_count = sum(1 for d in dates if d.plateau_warning)
    if plateau_count:
        lines.append(f"{plateau_count} date{'s' if plateau_count > 1 else ''} {'fall' if plateau_count > 1 else 'falls'} within the Hallstatt plateau, where precision is inherently limited.")

    lines.append(
        "The summed probability distribution (SPD) combines all individual "
        "probability curves into a single view for site-level analysis."
    )

    return " ".join(lines)


def _build_group_user_prompt(dates: list[CalibratedDate], language: str = "en") -> str:
    """Build an LLM prompt summarizing multiple dates for group narrative."""
    sections = ["## Group Calibration Result to Narrate"]

    sections.append(f"\nTotal dates in group: {len(dates)}")

    all_medians = [d.cal_bp_median for d in dates if d.cal_bp_median is not None]
    if all_medians:
        sections.append(f"Weighted median range: {int(round(min(all_medians)))}–{int(round(max(all_medians)))} cal BP")

    multimodal = sum(1 for d in dates if d.is_bimodal)
    plateau = sum(1 for d in dates if d.plateau_warning)
    sections.append(f"Multimodal distributions: {multimodal}/{len(dates)}")
    sections.append(f"Hallstatt plateau affected: {plateau}/{len(dates)}")

    sections.append("\nWrite a 3-5 sentence plain-English summary of this group of dates.")
    sections.append("Describe the overall date range, note any multimodal dates or plateaus, and mention if there are taphonomic concerns.")
    sections.append("Remember: narrate ONLY the numbers provided. Do not add historical context.")

    if language != "en":
        lang_name = SUPPORTED_LANGUAGES.get(language, "English")
        sections.append(f"IMPORTANT: Your entire response must be in {lang_name}.")

    return "\n".join(sections)


# ---- Public API ----

async def generate_narrative(
    date: CalibratedDate,
    llm_client: LLMClient | None = None,
    material: str | None = None,
    language: str = "en",
) -> str:
    """Generate a plain-English narrative for a single calibration result.

    If no llm_client is provided, falls back to deterministic template.
    Non-English languages require an LLM client — the fallback annotates this.
    """
    if llm_client is None:
        narrative = build_fallback_narrative(date, material)
        if language != "en":
            lang_name = SUPPORTED_LANGUAGES.get(language, language)
            narrative += (
                f" [Note: plain-English fallback used — "
                f"{lang_name} narrative requires an LLM API key.]"
            )
        return narrative

    user_prompt = _build_user_prompt(date, material, language)
    system_prompt = _build_system_prompt(language)
    try:
        narrative = await llm_client.generate(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=512,
            temperature=0.2,
        )
        return narrative
    except Exception:
        return build_fallback_narrative(date, material)


async def generate_group_narrative(
    dates: list[CalibratedDate],
    llm_client: LLMClient | None = None,
    language: str = "en",
) -> str:
    """Generate a summary narrative for a group of dates.

    Falls back to deterministic build_group_narrative if no LLM client.
    """
    if not dates:
        return "No dates in this project."

    if llm_client is None:
        return build_group_narrative(dates)

    user_prompt = _build_group_user_prompt(dates, language)
    system_prompt = _build_group_system_prompt(language)
    try:
        narrative = await llm_client.generate(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=512,
            temperature=0.2,
        )
        return narrative
    except Exception:
        return build_group_narrative(dates)
