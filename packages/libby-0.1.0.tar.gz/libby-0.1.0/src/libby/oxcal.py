"""oxcal.py — OxCal CQL2 script export for calibration projects.

exports: generate_single_script(name, bp_age, std_dev, curve) -> str
         generate_project_script(project_name, calibrations) -> str
         generate_sequence_script(project_name, calibrations) -> str
used_by: main.py → /export/oxcal endpoints
rules:   Curve names mapped to OxCal's expected format (IntCal20, SHCal20, Marine20).
         Boundary names auto-generated based on phase context.
agent:   deepseek-v4-flash | 2026-05-13 | Created OxCal CQL2 script generator.
         message: "Supports single date, Phase, and Sequence models.
         Output validated against OxCal's CQL2 syntax reference."
"""

from __future__ import annotations

from typing import Any

CURVE_MAP = {
    "intcal20": "IntCal20",
    "shcal20": "SHCal20",
    "marine20": "Marine20",
}

CURVE_FILE_MAP = {
    "intcal20": "intcal20.14c",
    "shcal20": "shcal20.14c",
    "marine20": "marine20.14c",
}


def _oxcal_curve(curve: str) -> str:
    """Map our curve name to OxCal's curve name."""
    return CURVE_MAP.get(curve.lower(), "IntCal20")


def _oxcal_curve_file(curve: str) -> str:
    """Map our curve name to OxCal's curve file."""
    return CURVE_FILE_MAP.get(curve.lower(), "intcal20.14c")


def _escape_name(name: str) -> str:
    """Escape a string for use as an OxCal label."""
    # OxCal labels can contain most characters, but quotes need care
    return name.replace('"', '\\"')


def generate_single_script(
    name: str,
    bp_age: int,
    std_dev: float,
    curve: str = "intcal20",
) -> str:
    """Generate an OxCal CQL2 script for a single date."""
    curve_name = _oxcal_curve(curve)
    curve_file = _oxcal_curve_file(curve)
    label = _escape_name(name or "Sample")

    O_NL = "\n"
    return (
        f"Plot(){O_NL}"
        + "{"
        + f"{O_NL}  Curve(\"{curve_name}\", \"{curve_file}\");{O_NL}"
        + f'  R_Date("{label}", {bp_age}, {int(round(std_dev))});{O_NL}'
        + "};"
        + O_NL
    )


def generate_project_script(
    project_name: str,
    calibrations: list[dict],
) -> str:
    """Generate an OxCal CQL2 script with all dates in a Phase.

    Each date's curve is detected from the stored result_json.
    """
    if not calibrations:
        return ""

    import json
    from collections import Counter

    # Detect the most common curve
    curves = Counter()
    entries: list[tuple[str, int, float, str]] = []

    for c in calibrations:
        try:
            result = json.loads(c["result_json"])
        except Exception:
            result = {}
        curve = result.get("curve", c.get("curve", "intcal20"))
        curves[curve] += 1
        name = c.get("name") or f"Date_{c['id']}"
        entries.append((name, c["bp_age"], c["std_dev"], curve))

    primary_curve = curves.most_common(1)[0][0]
    curve_name = _oxcal_curve(primary_curve)
    curve_file = _oxcal_curve_file(primary_curve)

    B_START = 'Boundary("Start");'
    B_END = 'Boundary("End");'

    lines = [
        f"Plot()",
        "{",
        f'  Curve("{curve_name}", "{curve_file}");',
        f'  Phase("{_escape_name(project_name)}")',
        "  {",
        f"    {B_START}",
    ]

    for name, bp, sd, _ in entries:
        lines.append(f'    R_Date("{_escape_name(name)}", {bp}, {int(round(sd))});')

    lines.extend([
        f"    {B_END}",
        "  };",
        "};",
    ])

    return "\n".join(lines) + "\n"


def generate_sequence_script(
    project_name: str,
    calibrations: list[dict],
) -> str:
    """Generate an OxCal CQL2 script with dates in stratigraphic order.

    Dates should be ordered oldest/deepest first to youngest/top last.
    """
    if len(calibrations) < 2:
        return generate_project_script(project_name, calibrations)

    import json
    from collections import Counter

    curves = Counter()
    entries: list[tuple[str, int, float, str]] = []

    for c in calibrations:
        try:
            result = json.loads(c["result_json"])
        except Exception:
            result = {}
        curve = result.get("curve", c.get("curve", "intcal20"))
        curves[curve] += 1
        name = c.get("name") or f"Date_{c['id']}"
        entries.append((name, c["bp_age"], c["std_dev"], curve))

    primary_curve = curves.most_common(1)[0][0]
    curve_name = _oxcal_curve(primary_curve)
    curve_file = _oxcal_curve_file(primary_curve)

    B_START = 'Boundary("Start");'
    B_END = 'Boundary("End");'

    lines = [
        f"Plot()",
        "{",
        f'  Curve("{curve_name}", "{curve_file}");',
        f'  Sequence("{_escape_name(project_name)}")',
        "  {",
        f"    {B_START}",
    ]

    for name, bp, sd, _ in entries:
        lines.append(f'    R_Date("{_escape_name(name)}", {bp}, {int(round(sd))});')

    lines.extend([
        f"    {B_END}",
        "  };",
        "};",
    ])

    return "\n".join(lines) + "\n"
