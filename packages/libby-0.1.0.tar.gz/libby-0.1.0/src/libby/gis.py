"""gis.py — Curve suggestion logic based on site latitude/longitude.

exports: suggest_curve(lat, lng) -> CurveSuggestion
used_by: main.py → POST /suggest-curve
rules:   Zone boundaries follow the IntCal/SHCal working group recommendations.
         Tropical mixing zone (±23°) uses a linear blend based on latitude.
         Mixed curves widen the calibrated ranges — this is scientifically honest.
agent:   deepseek-v4-flash | 2026-05-13 | Created GIS curve suggestion engine.
         message: "Zones: >30°N → IntCal, 23-30°N → IntCal (transitional),
         23°S-23°N → mixed, 23-30°S → SHCal (transitional), >30°S → SHCal.
         Mixed ratio uses latitude-based linear interpolation."
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class CurveSuggestion(BaseModel):
    """Result of a curve suggestion query."""
    primary_curve: str = Field(..., description="Suggested primary calibration curve")
    secondary_curve: str | None = Field(None, description="Secondary curve for mixing")
    mix_ratio: float | None = Field(None, description="Primary/secondary blend ratio (0-1)")
    zone: str = Field(..., description="Zone classification")
    explanation: str = Field(..., description="Plain-English explanation of the suggestion")


def suggest_curve(lat: float, lng: float) -> CurveSuggestion:
    """Suggest the appropriate calibration curve for a site location.

    Args:
        lat: Site latitude in decimal degrees (-90 to 90).
        lng: Site longitude in decimal degrees (not currently used beyond sanity check).

    Returns:
        CurveSuggestion with the recommended curve(s) and explanation.
    """
    # Validate
    if not -90 <= lat <= 90:
        return CurveSuggestion(
            primary_curve="intcal20",
            zone="error",
            explanation=f"Latitude {lat} is out of range. Defaulting to IntCal20.",
        )

    lat_abs = abs(lat)
    is_south = lat < 0

    # Northern hemisphere: >30°N
    if lat > 30:
        return CurveSuggestion(
            primary_curve="intcal20",
            zone="north_temperate",
            explanation=(
                f"This site at {lat_abs:.1f}°N is in the Northern Hemisphere temperate zone, "
                f"where atmospheric mixing is dominated by northern air masses. "
                f"The IntCal20 curve is the appropriate calibration standard."
            ),
        )

    # Southern hemisphere: < -30°S
    if lat < -30:
        return CurveSuggestion(
            primary_curve="shcal20",
            zone="south_temperate",
            explanation=(
                f"This site at {lat_abs:.1f}°S is in the Southern Hemisphere temperate zone, "
                f"where the larger ocean area depletes atmospheric ¹⁴C relative to the north. "
                f"The SHCal20 curve is the appropriate calibration standard."
            ),
        )

    # Northern transitional: 23°N to 30°N
    if 23 < lat <= 30:
        return CurveSuggestion(
            primary_curve="intcal20",
            zone="north_transitional",
            explanation=(
                f"This site at {lat_abs:.1f}°N is in the subtropical transition zone. "
                f"While IntCal20 is recommended as the primary curve, seasonal ITCZ "
                f"migration may introduce a minor Southern Hemisphere influence. "
                f"Consider a mixed curve (e.g. 90% IntCal20 / 10% SHCal20) for "
                f"higher precision work."
            ),
        )

    # Southern transitional: 23°S to 30°S
    if -30 <= lat < -23:
        return CurveSuggestion(
            primary_curve="shcal20",
            zone="south_transitional",
            explanation=(
                f"This site at {lat_abs:.1f}°S is in the subtropical transition zone. "
                f"While SHCal20 is recommended as the primary curve, seasonal ITCZ "
                f"migration may introduce a minor Northern Hemisphere influence. "
                f"Consider a mixed curve (e.g. 90% SHCal20 / 10% IntCal20) for "
                f"higher precision work."
            ),
        )

    # Tropical zone: ±23° — mixed curve
    # Calculate mix ratio based on latitude
    # At 23°N: 100% IntCal, at 0°: 50/50, at 23°S: 100% SHCal
    if is_south:
        # Southern tropics: 0 to 23°S — blend from 50/50 to 100% SHCal
        mix_ratio = 0.5 + (lat_abs / 23.0) * 0.5  # SHCal proportion
        primary = "shcal20"
        secondary = "intcal20"
        primary_name = "SHCal20"
        secondary_name = "IntCal20"
        primary_pct = int(round(mix_ratio * 100))
        secondary_pct = 100 - primary_pct
    else:
        # Northern tropics: 0 to 23°N — blend from 50/50 to 100% IntCal
        mix_ratio = 0.5 + (lat_abs / 23.0) * 0.5  # IntCal proportion
        primary = "intcal20"
        secondary = "shcal20"
        primary_name = "IntCal20"
        secondary_name = "SHCal20"
        primary_pct = int(round(mix_ratio * 100))
        secondary_pct = 100 - primary_pct

    return CurveSuggestion(
        primary_curve=primary,
        secondary_curve=secondary,
        mix_ratio=mix_ratio,
        zone="tropical_mixing",
        explanation=(
            f"This site at {lat_abs:.1f}°{'S' if is_south else 'N'} lies within "
            f"the tropical mixing zone where the Intertropical Convergence Zone "
            f"(ITCZ) causes seasonal overlap of Northern and Southern Hemisphere air "
            f"masses. A single standard curve is insufficient — we recommend a "
            f"mixed curve of approximately {primary_pct}% {primary_name} / "
            f"{secondary_pct}% {secondary_name}. Note that mixed curves produce "
            f"wider calibrated ranges, which honestly reflects the atmospheric "
            f"uncertainty at tropical latitudes."
        ),
    )
