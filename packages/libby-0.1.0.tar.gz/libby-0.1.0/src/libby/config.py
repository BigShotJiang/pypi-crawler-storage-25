"""config.py — Application settings via pydantic-settings.

exports: Settings dataclass
used_by: main.py, database.py, narrative.py, providers/__init__.py
rules:   Never commit secrets. API keys must come from env or .env file
         that is gitignored. Curve data paths are relative to project root.
         nim_api_key also falls back to NVIDIA_NIM_API_KEY env var for
         compatibility with Nvidia's standard naming convention.
agent:   deepseek-v4-flash | 2026-05-13 | Added NIM-specific settings with
         NVIDIA_NIM_API_KEY fallback. Default provider: nim.
"""

from __future__ import annotations

import os
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application configuration, loaded from env vars or .env file."""

    # --- Paths ---
    project_root: Path = Path(__file__).resolve().parent.parent.parent
    curve_dir: Path = project_root / "src" / "libby" / "curves"
    database_url: str = "sqlite+aiosqlite:///./libby.db"

    # --- LLM provider selection ---
    # One of: "nim", "anthropic", "local", "none"
    llm_provider: str = "nim"
    llm_max_tokens: int = 512
    llm_temperature: float = 0.2

    # --- Nvidia NIM (OpenAI-compatible) ---
    nim_api_key: str = Field(default="")
    nim_model: str = "meta/llama-3.1-70b-instruct"
    nim_base_url: str = "https://integrate.api.nvidia.com/v1"

    # --- Anthropic (future) ---
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-20250514"

    # --- Server ---
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False

    model_config = {
        "env_prefix": "LIBBY_",
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

    @field_validator("nim_api_key", mode="before")
    @classmethod
    def _nim_key_fallback(cls, v: str) -> str:
        """Fall back to standard NVIDIA_NIM_API_KEY if LIBBY_NIM_API_KEY is empty."""
        if not v:
            return os.environ.get("NVIDIA_NIM_API_KEY", "")
        return v
