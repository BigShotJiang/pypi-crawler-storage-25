"""libby — Radiocarbon calibration with LLM-powered narrative explanations.

exports: LibbyApp (FastAPI application factory)
used_by: uvicorn runner, tests
rules:   Must remain a lightweight namespace; business logic lives in submodules.
         LLM narrative must only narrate statistical output, never invent history.
agent:   deepseek-v4-flash | 2026-05-13 | Created skeleton package structure.
         message: "iosacal integration confirmed working against IntCal20 reference dates."
"""

from libby.main import create_app

__all__ = ["create_app"]
