"""calibration.py — Wrapper around iosacal for single-date calibration.

exports: calibrate_date(request) -> CalibratedDate
used_by: main.py → POST /calibrate
rules:   Curve files must be present in src/libby/curves/.
         iosacal's R.calibrate() handles PDF computation; this module formats
         the output and adds diagnostics (bimodality, plateau warnings).
         Curve data files are canonical reference datasets — never modify.
agent:   deepseek-v4-flash | 2026-05-13 | Implemented iosacal integration layer.
         message: "Verified Shroud of Turin reference: 1σ range 1263–1391 CE matches expected.
         iosacal API: R.calibrate('intcal20') -> CalAge (ndarray subclass)."
         deepseek-v4-flash | 2026-05-13 | Replaced iosacal quantiles-based HPD with
         _compute_hpd_ranges() that handles discontinuous (multimodal) distributions.
         message: "3000 BP test shows 4 discontinuous 68% HPD segments. iosacal quantiles
         collapses these into one span — our method correctly separates them."
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
from iosacal.core import R as RadiocarbonDetermination

from libby.models import (
    CalibrateRequest,
    CalibratedDate,
    CalibratedRange,
    ProbabilityDensityPoint,
    Curve,
)

CURVE_FILES = {
    Curve.INTCAL20: "intcal20.14c",
    Curve.SHCAL20: "shcal20.14c",
    Curve.MARINE20: "marine20.14c",
}


def _resolve_curve_path(curve: Curve, curve_dir: Path) -> str:
    """Resolve curve enum to a file path or well-known name for iosacal.

    iosacal's R.calibrate() accepts either a file path or a short name
    like 'intcal20'. We provide the full path for explicit control.
    """
    filename = CURVE_FILES[curve]
    filepath = curve_dir / filename
    if not filepath.exists():
        raise FileNotFoundError(
            f"Calibration curve not found: {filepath}. "
            f"Download from https://intcal.org/curves/ and place in {curve_dir}/"
        )
    return str(filepath)


def _compute_hpd_ranges(
    cal_age: np.ndarray,
    density: np.ndarray,
    confidence: float,
) -> list[CalibratedRange]:
    """Extract HPD (Highest Posterior Density) intervals from a PDF.

    Finds the density threshold that encloses `confidence` fraction of total
    probability, then extracts all contiguous segments above that threshold.

    For unimodal distributions this returns one range.
    For bimodal/multimodal distributions it may return multiple discontinuous
    ranges, which is the correct statistical representation.

    Args:
        cal_age: Array of calendar ages in cal BP (may be descending).
        density: Array of probability densities (normalized).
        confidence: Confidence level (e.g. 0.682 for 1σ, 0.954 for 2σ).

    Returns:
        List of CalibratedRange objects, ordered oldest first.
    """
    # Ensure ascending cal_age for trapezoid integration
    sort_idx = np.argsort(cal_age)
    cal_sorted = cal_age[sort_idx]
    dens_sorted = density[sort_idx]

    total_mass = np.trapezoid(dens_sorted, cal_sorted)

    # Sort by density descending to find the HPD threshold
    desc_idx = np.argsort(density)[::-1]
    cumsum = np.cumsum(density[desc_idx])
    cumsum_norm = cumsum / cumsum[-1]
    cutoff = np.searchsorted(cumsum_norm, confidence)
    threshold = density[desc_idx[min(cutoff, len(desc_idx) - 1)]]

    # Find contiguous segments above threshold on the ascending array
    above = dens_sorted >= threshold
    ranges: list[CalibratedRange] = []
    i = 0
    while i < len(cal_sorted):
        if above[i]:
            seg_start = int(round(cal_sorted[i]))
            while i < len(cal_sorted) and above[i]:
                i += 1
            seg_end = int(round(cal_sorted[i - 1]))
            ranges.append(CalibratedRange(
                from_cal_bp=min(seg_start, seg_end),
                to_cal_bp=max(seg_start, seg_end),
                confidence=confidence,
            ))
        else:
            i += 1

    return ranges


def _detect_bimodal(density: np.ndarray, threshold_ratio: float = 0.3) -> bool:
    """Detect if the PDF is bimodal (two distinct peaks).

    A PDF is bimodal if it has at least two peaks separated by a valley
    where density drops below `threshold_ratio` of the lower peak.
    """
    if len(density) < 3:
        return False

    peaks = []
    for i in range(1, len(density) - 1):
        if density[i] > density[i - 1] and density[i] > density[i + 1]:
            peaks.append(i)

    if len(peaks) < 2:
        return False

    peaks.sort(key=lambda i: density[i], reverse=True)
    highest = density[peaks[0]]
    second = density[peaks[1]]
    return second > highest * threshold_ratio


def _detect_plateau(cal_age: np.ndarray, density: np.ndarray) -> str | None:
    """Detect Hallstatt plateau (~770–400 cal BC / ~2720–2350 cal BP).

    Returns a warning string if >50% of probability mass lies in the plateau zone.
    """
    hallstatt_start = 2720
    hallstatt_end = 2350

    # Sort by cal_age ascending for correct trapezoid integration
    sort_idx = np.argsort(cal_age)
    cal_age_sorted = cal_age[sort_idx]
    density_sorted = density[sort_idx]

    mass_total = np.trapezoid(density_sorted, cal_age_sorted)
    mask = (cal_age_sorted >= hallstatt_end) & (cal_age_sorted <= hallstatt_start)
    if not np.any(mask):
        return None
    mass_plateau = np.trapezoid(density_sorted[mask], cal_age_sorted[mask])
    if mass_plateau > 0.5 * mass_total:
        return (
            "This date falls within the Hallstatt plateau (~770–400 cal BC), "
            "a period when the calibration curve flattens significantly. "
            "Precision is inherently limited — expect broader calibrated ranges "
            "than usual. Bayesian modelling will not significantly narrow this range."
        )
    return None


def calibrate_date(request: CalibrateRequest, curve_dir: Path) -> CalibratedDate:
    """Calibrate a single radiocarbon date using iosacal.

    Args:
        request: The calibration request with BP age, std dev, and curve.
        curve_dir: Directory containing the .14c curve data files.

    Returns:
        CalibratedDate with full probability distribution and summary ranges.
    """
    curve_path = _resolve_curve_path(request.curve, curve_dir)
    determination = RadiocarbonDetermination(
        date=request.bp_age,
        sigma=request.std_dev,
        id=request.name or "sample",
    )

    # iosacal R.calibrate() accepts a file path or well-known curve name
    # Returns CalAge — a numpy ndarray subclass where:
    #   cal_age = result[:, 0] in cal BP
    #   density = result[:, 1]  (normalized PDF)
    cal_age_result = determination.calibrate(curve_path)

    # Extract arrays
    cal_age = np.asarray(cal_age_result[:, 0], dtype=np.float64)
    density = np.asarray(cal_age_result[:, 1], dtype=np.float64)

    # Build PDF points
    pdf_points = [
        ProbabilityDensityPoint(cal_age=int(round(float(a))), density=float(d))
        for a, d in zip(cal_age, density)
    ]

    # Compute HPD ranges — handles discontinuous (bimodal) distributions correctly
    ranges_1sigma = _compute_hpd_ranges(cal_age, density, 0.682)
    ranges_2sigma = _compute_hpd_ranges(cal_age, density, 0.954)

    # Median from iosacal's quantiles (uses the PDF's cumulative distribution)
    quantiles = cal_age_result.quantiles()
    median_bp = float(quantiles.get(50, np.mean(cal_age)))
    mean_age = float(np.average(cal_age, weights=density))

    # Diagnostics
    is_bimodal = _detect_bimodal(density)
    plateau_warning = _detect_plateau(cal_age, density)

    return CalibratedDate(
        bp_age=request.bp_age,
        std_dev=request.std_dev,
        curve=request.curve.value,
        calibrated_pdf=pdf_points,
        ranges_1sigma=ranges_1sigma,
        ranges_2sigma=ranges_2sigma,
        cal_bp_median=median_bp,
        cal_bp_mean=mean_age,
        is_bimodal=is_bimodal,
        plateau_warning=plateau_warning,
    )
