"""importer.py — Parse radiocarbon lab report formats (CSV, TSV, pasted text).

exports: parse_lab_report(text) -> LabReport
used_by: main.py → POST /import/parse
rules:   Supports CSV and TSV with flexible column name matching.
         Common column names auto-detected (Lab ID, 14C age, Sigma, etc.).
         Rows with missing or invalid values are flagged, not silently dropped.
agent:   deepseek-v4-flash | 2026-05-13 | Created lab report importer.
         message: "Flexible column matching via keyword synonyms.
         Detects BP age, sigma, material, curve, sample name, site, context.
         Invalid rows returned with error messages for user correction."
"""

from __future__ import annotations

import csv
import io
import re
from typing import Any

from pydantic import BaseModel, Field


class ImportedRow(BaseModel):
    """A single parsed row from a lab report."""
    row_number: int
    name: str = ""
    lab_id: str = ""
    bp_age: int | None = None
    std_dev: float | None = None
    material: str = ""
    curve: str = "intcal20"
    site: str = ""
    context: str = ""
    error: str | None = None


class LabReport(BaseModel):
    """Result of parsing a lab report."""
    rows: list[ImportedRow] = Field(default_factory=list)
    total_rows: int = 0
    valid_rows: int = 0
    error_rows: int = 0
    detected_columns: list[str] = Field(default_factory=list)
    format_hint: str = ""


# Column synonym maps
COLUMN_SYNONYMS: dict[str, list[str]] = {
    "name": [
        "name", "sample", "sample name", "sample id", "sample_id",
        "sample name/id", "sample name or id", "id", "identifier",
    ],
    "lab_id": [
        "lab", "lab id", "lab code", "lab number", "lab_no",
        "laboratory code", "labcode", "lab-code",
    ],
    "bp_age": [
        "bp", "age", "14c age", "c14 age", "radiocarbon age",
        "conventional age", "conv age", "age bp", "14c bp",
        "c14 bp", "radiocarbon age bp", "14c_age", "age_bp",
        "conventional radiocarbon age",
    ],
    "std_dev": [
        "sigma", "error", "±", "1σ", "sd", "std dev", "stddev",
        "standard deviation", "uncertainty", "+/-", "plusminus",
        "1 sigma", "1-sigma",
    ],
    "material": [
        "material", "sample material", "sample type", "material type",
        "type", "substance",
    ],
    "curve": [
        "curve", "calibration curve", "cal curve", "intcal",
        "cal_curve",
    ],
    "site": [
        "site", "location", "excavation", "trench", "area",
    ],
    "context": [
        "context", "layer", "level", "locus", "square", "unit",
        "stratigraphic unit", "su", "depth",
    ],
}


def _normalise_key(key: str) -> str:
    """Normalise a column name for matching."""
    return key.strip().lower().replace("_", " ").replace("-", " ")


def _match_column(header: str) -> str | None:
    """Match a column header to a known field name using synonyms."""
    normalised = _normalise_key(header)
    for field, synonyms in COLUMN_SYNONYMS.items():
        if any(s == normalised or normalised.startswith(s) or s.startswith(normalised) for s in synonyms):
            return field
        # Also try direct match
        if normalised == field:
            return field
    return None


def _parse_bp_age(value: str) -> int | None:
    """Parse a BP age value from a string, handling common formats."""
    value = value.strip().replace(",", "")
    # Handle "3000±30" or "3000 +/- 30" or "3000 BP" formats
    m = re.match(r"^(\d+)\s*(?:±|\+/\-\s*|bp\s*)?", value, re.IGNORECASE)
    if m:
        try:
            val = int(m.group(1))
            if 0 < val < 60000:
                return val
        except ValueError:
            pass
    # Try plain int
    try:
        val = int(float(value))
        if 0 < val < 60000:
            return val
    except (ValueError, TypeError):
        pass
    return None


def _parse_std_dev(value: str) -> float | None:
    """Parse a standard deviation value."""
    value = value.strip().replace(",", "")
    # Handle "±30" or "+/- 30" or just "30"
    m = re.match(r"^(?:±|\+/\-)\s*(\d+(?:\.\d+)?)", value)
    if m:
        try:
            val = float(m.group(1))
            if 0 < val <= 500:
                return val
        except ValueError:
            pass
    # Handle "3000±30" — extract after ±
    m = re.match(r"\d+\s*(?:±|\+/\-)\s*(\d+(?:\.\d+)?)", value)
    if m:
        try:
            val = float(m.group(1))
            if 0 < val <= 500:
                return val
        except ValueError:
            pass
    # Try plain float
    try:
        val = float(value)
        if 0 < val <= 500:
            return val
    except (ValueError, TypeError):
        pass
    return None


def parse_lab_report(text: str, format: str = "auto") -> LabReport:
    """Parse a lab report from CSV/TSV text.

    Args:
        text: Raw text content of the lab report.
        format: "csv", "tsv", or "auto" (detect from content).

    Returns:
        LabReport with parsed rows.
    """
    # Detect format
    if format == "auto":
        if "\t" in text[:500] and "," not in text[:500]:
            fmt = "tsv"
        else:
            fmt = "csv"
    else:
        fmt = format

    delimiter = "\t" if fmt == "tsv" else ","
    format_hint = "Tab-separated" if fmt == "tsv" else "Comma-separated"

    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if not reader.fieldnames:
        return LabReport(format_hint="No columns detected")

    # Map columns
    column_map: dict[str, str] = {}
    for header in reader.fieldnames:
        matched = _match_column(header)
        if matched:
            column_map[matched] = header

    detected_columns = list(column_map.keys())
    rows: list[ImportedRow] = []

    for row_num, raw_row in enumerate(reader, start=1):
        imported = ImportedRow(row_number=row_num)

        # Extract values using mapped columns
        name_header = column_map.get("name")
        if name_header:
            imported.name = raw_row.get(name_header, "").strip()

        lab_header = column_map.get("lab_id")
        if lab_header:
            imported.lab_id = raw_row.get(lab_header, "").strip()

        # Use lab_id as name if name is empty
        if not imported.name and imported.lab_id:
            imported.name = imported.lab_id

        # BP age (may also contain embedded σ like "3000±30")
        bp_header = column_map.get("bp_age")
        if bp_header:
            bp_raw = raw_row.get(bp_header, "").strip()
            if bp_raw:
                # Try to extract both age and embedded sigma
                embedded_sigma = _parse_std_dev(bp_raw)
                imported.bp_age = _parse_bp_age(bp_raw)
                if embedded_sigma is not None:
                    imported.std_dev = embedded_sigma
                if imported.bp_age is None:
                    imported.error = f"Could not parse BP age '{bp_raw}'"

        # Std dev (only if not already set from embedded sigma)
        sd_header = column_map.get("std_dev")
        if sd_header and imported.std_dev is None:
            sd_raw = raw_row.get(sd_header, "").strip()
            if sd_raw:
                imported.std_dev = _parse_std_dev(sd_raw)
                if imported.std_dev is None:
                    existing = imported.error or ""
                    imported.error = f"{existing}; Could not parse σ '{sd_raw}'".strip("; ")

        # Material
        mat_header = column_map.get("material")
        if mat_header:
            imported.material = raw_row.get(mat_header, "").strip().lower()

        # Curve
        curve_header = column_map.get("curve")
        if curve_header:
            cv = raw_row.get(curve_header, "").strip().lower()
            if cv in ("intcal20", "shcal20", "marine20"):
                imported.curve = cv

        # Site and context
        site_header = column_map.get("site")
        if site_header:
            imported.site = raw_row.get(site_header, "").strip()
        ctx_header = column_map.get("context")
        if ctx_header:
            imported.context = raw_row.get(ctx_header, "").strip()

        # Validate
        if imported.bp_age is None and imported.error is None:
            imported.error = "Missing BP age"
        if imported.std_dev is None and imported.error is None:
            imported.error = "Missing σ"
        if imported.bp_age is not None and imported.std_dev is not None and imported.error is None:
            if imported.std_dev <= 0:
                imported.error = "σ must be positive"
            if imported.bp_age <= 0:
                imported.error = "BP age must be positive"

        rows.append(imported)

    valid = sum(1 for r in rows if r.error is None)
    invalid = sum(1 for r in rows if r.error is not None)

    return LabReport(
        rows=rows,
        total_rows=len(rows),
        valid_rows=valid,
        error_rows=invalid,
        detected_columns=detected_columns,
        format_hint=format_hint,
    )
