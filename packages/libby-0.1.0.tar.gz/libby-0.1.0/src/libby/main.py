"""main.py — FastAPI application factory and route definitions.

exports: create_app() -> FastAPI
used_by: uvicorn runner (__main__), tests
rules:   CORS must be configured for Svelte dev server (localhost:5173).
         LLM client is created at startup via provider factory and stored
         in app.state for the request lifespan. Falls back to deterministic
         narrative if no API key is configured.
agent:   deepseek-v4-flash | 2026-05-13 | Implemented create_app factory and
         POST /calibrate endpoint. NIM client wired via provider factory.
         message: "Creates LLM client in lifespan, stores on app.state.
         Falls back to deterministic narrative cleanly."
"""

from __future__ import annotations

import importlib.metadata
import logging
from contextlib import asynccontextmanager
from pathlib import Path

try:
    _LIBBY_VERSION = importlib.metadata.version("libby")
except importlib.metadata.PackageNotFoundError:
    _LIBBY_VERSION = "0.1.0"

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from fastapi.responses import PlainTextResponse, Response, StreamingResponse

# Path to the static frontend build within the package
_STATIC_DIR = Path(__file__).resolve().parent / "static"

_MIME_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript",
    ".css": "text/css",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".json": "application/json",
    ".txt": "text/plain",
    ".woff2": "font/woff2",
    ".woff": "font/woff",
}


def _get_mime_type(suffix: str) -> str:
    return _MIME_TYPES.get(suffix.lower(), "application/octet-stream")

from libby.calibration import calibrate_date
from libby.config import Settings
from libby.database import init_db, save_calibration
from libby.export import calibration_to_text, calibrations_to_csv
from libby.bayesian import run_phase_model, run_sequence_model
from libby.gis import suggest_curve
from libby.importer import parse_lab_report
from libby.report import generate_project_report
from libby.models import (
    BatchCalibrateRequest,
    BatchCalibrateResponse,
    BayesianModelRequest,
    CalibrateRequest,
    CalibrateResponse,
    CalibratedDate,
)
from libby.narrative import LLMClient, generate_narrative
from libby.oxcal import generate_project_script, generate_sequence_script, generate_single_script
from libby.projects import router as projects_router
from libby.providers import create_llm_client
from libby.spd import compute_spd

logger = logging.getLogger(__name__)
settings = Settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: initialise DB + LLM client on startup."""
    await init_db()

    # Create the configured LLM provider (or None for fallback)
    llm_client = create_llm_client(settings)
    app.state.llm_client = llm_client

    if llm_client is None:
        logger.info("No LLM client configured — using deterministic fallback narrative")
    else:
        logger.info("LLM provider '%s' initialised", settings.llm_provider)

    yield

    # Cleanup
    if hasattr(llm_client, "close"):
        await llm_client.close()


def get_llm_client(app: FastAPI) -> LLMClient | None:
    """Get the LLM client from app state, or None."""
    return getattr(app.state, "llm_client", None)


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="Libby",
        description="Radiocarbon calibration tool with LLM-powered narrative explanations",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Include project management routes
    app.include_router(projects_router)

    # Allow Svelte dev server
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:5173", "http://127.0.0.1:5173",
            "http://localhost:50002", "http://127.0.0.1:50002",
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/health")
    async def health():
        """Health check endpoint."""
        return {
            "status": "ok",
            "version": _LIBBY_VERSION,
            "llm_provider": settings.llm_provider,
            "llm_configured": get_llm_client(app) is not None,
        }

    @app.get("/suggest-curve")
    async def suggest_curve_endpoint(lat: float, lng: float = 0):
        """Suggest calibration curve based on site latitude/longitude.
        Uses the IntCal/SHCal zone boundaries and tropical mixing logic.
        """
        return suggest_curve(lat, lng)

    # ---- Lab import ----

    @app.post("/import/parse")
    async def import_lab_report(text: str, format: str = "auto"):
        """Parse a radiocarbon lab report (CSV/TSV). Returns preview rows
        ready for batch calibration.

        - text: Raw CSV or TSV content.
        - format: "csv", "tsv", or "auto" (default).
        """
        return parse_lab_report(text, format=format)

    @app.post("/calibrate", response_model=CalibrateResponse)
    async def calibrate(request: CalibrateRequest):
        """Calibrate a single radiocarbon date and generate narrative."""
        try:
            result = calibrate_date(request, settings.curve_dir)
        except FileNotFoundError as e:
            raise HTTPException(status_code=503, detail=str(e))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Calibration failed: {e}")

        # Generate narrative via configured LLM provider (or deterministic fallback)
        llm_client = get_llm_client(app)
        narrative = await generate_narrative(
            result,
            llm_client=llm_client,
            material=request.material,
            language=request.language,
        )

        # Persist to SQLite
        result_json = result.model_dump_json()
        await save_calibration(
            bp_age=request.bp_age,
            std_dev=request.std_dev,
            curve=request.curve.value,
            result_json=result_json,
            narrative=narrative,
            name=request.name,
            material=request.material,
            site=request.site,
            context=request.context,
            project_id=request.project_id,
        )

        return CalibrateResponse(success=True, data=result, narrative=narrative)

    @app.post("/calibrate/batch", response_model=BatchCalibrateResponse)
    async def calibrate_batch(request: BatchCalibrateRequest):
        """Calibrate multiple dates and compute their SPD."""
        from libby.database import save_calibration

        results: list[CalibrateResponse] = []
        calibrated_dates: list = []
        llm_client = get_llm_client(app)

        for req in request.dates:
            try:
                result = calibrate_date(req, settings.curve_dir)
                narrative = await generate_narrative(
                    result, llm_client=llm_client, material=req.material, language=req.language,
                )
                calibrated_dates.append(result)

                # Persist
                await save_calibration(
                    bp_age=req.bp_age, std_dev=req.std_dev,
                    curve=req.curve.value,
                    result_json=result.model_dump_json(),
                    narrative=narrative,
                    name=req.name, material=req.material,
                    site=req.site, context=req.context,
                    project_id=req.project_id,
                )

                results.append(CalibrateResponse(
                    success=True, data=result, narrative=narrative,
                ))
            except Exception as e:
                results.append(CalibrateResponse(
                    success=False, error=str(e),
                ))

        # Compute SPD
        spd = compute_spd(calibrated_dates) if calibrated_dates else None

        return BatchCalibrateResponse(
            success=any(r.success for r in results),
            results=results,
            spd=spd,
        )

    @app.get("/calibrate/batch")
    async def batch_form_help():
        """Instructions for the batch input format."""
        return {
            "format": "CSV-like, one date per line",
            "columns": ["name", "bp_age", "std_dev", "curve", "material"],
            "example": "Sample A, 3000, 30, intcal20, charcoal",
            "endpoint": "POST /calibrate/batch with JSON body",
        }

    # ---- Bayesian modelling ----

    @app.post("/model")
    async def bayesian_model(req: BayesianModelRequest):
        """Run a Bayesian Phase or Sequence model on a set of calibrations.

        - model_type="phase": estimates start/end boundaries for a group.
        - model_type="sequence": applies stratigraphic ordering (oldest first).

        Send calibration_ids in stratigraphic order for sequence modelling.
        """
        calibration_ids = req.calibration_ids
        model_type = req.model_type
        from libby.database import get_calibration_by_id
        ordered_rows: list = []
        for cid in calibration_ids:
            row = await get_calibration_by_id(cid)
            if row:
                ordered_rows.append(row)

        if not ordered_rows:
            raise HTTPException(status_code=404, detail="No calibrations found for given IDs")

        dates: list[CalibratedDate] = []
        for r in ordered_rows:
            try:
                dates.append(CalibratedDate.model_validate_json(r["result_json"]))
            except Exception:
                raise HTTPException(status_code=400, detail=f"Invalid calibration data for id {r['id']}")

        if len(dates) < 2:
            raise HTTPException(status_code=422, detail="Need at least 2 dates for Bayesian modelling")

        import asyncio
        loop = asyncio.get_event_loop()
        if model_type == "sequence":
            result = await loop.run_in_executor(None, run_sequence_model, dates)
        else:
            result = await loop.run_in_executor(None, run_phase_model, dates)
        return result

    @app.get("/history")
    async def history(limit: int = 20):
        """Get recent calibration history."""
        from libby.database import get_calibration_history
        return await get_calibration_history(limit)

    # ---- Export endpoints ----

    @app.get("/export/csv")
    async def export_csv(limit: int = 100):
        """Export calibration history as a CSV file."""
        from libby.database import get_calibration_history
        rows = await get_calibration_history(limit)
        csv_content = calibrations_to_csv(rows)
        return StreamingResponse(
            iter([csv_content]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=libby-calibrations.csv"},
        )

    @app.get("/export/text/{calibration_id}")
    async def export_text(calibration_id: int):
        """Export a single calibration as publication-ready plain text."""
        from libby.database import get_calibration_by_id
        target = await get_calibration_by_id(calibration_id)
        if target is None:
            raise HTTPException(status_code=404, detail="Calibration not found")

        from libby.models import CalibratedDate
        result = CalibratedDate.model_validate_json(target["result_json"])
        text = calibration_to_text(result, name=target.get("name"), material=target.get("material"))
        return PlainTextResponse(
            content=text,
            headers={"Content-Disposition": f"inline; filename=libby-{calibration_id}.txt"},
        )

    @app.get("/export/pdf/{project_id}")
    async def export_pdf(project_id: int):
        """Export a project as a formatted PDF report."""
        from libby.database import project_get, project_calibrations

        proj = await project_get(project_id)
        if not proj:
            raise HTTPException(status_code=404, detail="Project not found")
        cals = await project_calibrations(project_id)

        pdf_bytes = generate_project_report(
            project_name=proj["name"],
            project_description=proj.get("description", ""),
            calibrations=cals,
            bayesian_result=None,
        )

        return StreamingResponse(
            iter([pdf_bytes]),
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename=libby-project-{project_id}.pdf",
            },
        )

    @app.get("/export/pdf/single/{calibration_id}")
    async def export_pdf_single(calibration_id: int):
        """Export a single calibration as a PDF report."""
        from libby.database import get_calibration_by_id
        target = await get_calibration_by_id(calibration_id)
        if target is None:
            raise HTTPException(status_code=404, detail="Calibration not found")

        pdf_bytes = generate_project_report(
            project_name=target.get("name") or f"Date {calibration_id}",
            project_description="Single date calibration",
            calibrations=[target],
            bayesian_result=None,
        )

        return StreamingResponse(
            iter([pdf_bytes]),
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename=libby-date-{calibration_id}.pdf",
            },
        )

    # ---- OxCal export ----

    @app.get("/export/oxcal/{project_id}")
    async def export_oxcal(project_id: int, model: str = "phase"):
        """Export a project as an OxCal CQL2 script.
        - model="phase": all dates in an unordered Phase.
        - model="sequence": dates in their database order (oldest first).
        """
        from libby.database import project_get, project_calibrations

        proj = await project_get(project_id)
        if not proj:
            raise HTTPException(status_code=404, detail="Project not found")
        cals = await project_calibrations(project_id)
        if not cals:
            raise HTTPException(status_code=422, detail="Project has no dates")

        ext = "oxcal"

        if model == "sequence":
            script = generate_sequence_script(proj["name"], cals)
        else:
            script = generate_project_script(proj["name"], cals)

        return PlainTextResponse(
            content=script,
            headers={"Content-Disposition": f"attachment; filename=libby-{project_id}.{ext}"},
        )

    @app.get("/export/oxcal/date/{calibration_id}")
    async def export_oxcal_single(calibration_id: int):
        """Export a single calibration as an OxCal CQL2 script."""
        from libby.database import get_calibration_by_id
        target = await get_calibration_by_id(calibration_id)
        if target is None:
            raise HTTPException(status_code=404, detail="Calibration not found")

        script = generate_single_script(
            name=target.get("name") or f"Date_{target['id']}",
            bp_age=target["bp_age"],
            std_dev=target["std_dev"],
            curve=target.get("curve", "intcal20"),
        )
        return PlainTextResponse(
            content=script,
            headers={"Content-Disposition": f"attachment; filename=libby-{calibration_id}.oxcal"},
        )

    # Serve the static frontend build (must be last — after all API routes)
    if _STATIC_DIR.exists() and (_STATIC_DIR / "index.html").exists():
        # SPA fallback: any path that doesn't have a file extension serves index.html
        @app.get("/{path:path}")
        async def serve_frontend(path: str):
            file_path = _STATIC_DIR / path
            if file_path.exists() and file_path.is_file():
                data = file_path.read_bytes()
                return Response(content=data, media_type=_get_mime_type(file_path.suffix))
            index_path = _STATIC_DIR / "index.html"
            if index_path.exists():
                return Response(content=index_path.read_bytes(), media_type="text/html; charset=utf-8")
            raise HTTPException(status_code=404)

    return app


app = create_app()
