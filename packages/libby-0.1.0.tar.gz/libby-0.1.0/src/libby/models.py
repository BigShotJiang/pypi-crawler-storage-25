"""models.py — Pydantic models for API request/response schemas.

exports: CalibrateRequest, CalibrateResponse, CalibratedDate,
         ProbabilityDensityPoint, CalibratedRange
used_by: main.py → calibrate endpoint, tests
rules:   BP age must be positive int. Std dev must be positive float.
         Curve must be one of "intcal20", "shcal20", "marine20".
agent:   deepseek-v4-flash | 2026-05-13 | Created API schema models.
"""

from __future__ import annotations

from enum import Enum
from typing import List

from pydantic import BaseModel, Field


class Curve(str, Enum):
    """Supported calibration curves."""
    INTCAL20 = "intcal20"
    SHCAL20 = "shcal20"
    MARINE20 = "marine20"


class CalibrateRequest(BaseModel):
    """Request payload for single-date calibration."""
    bp_age: int = Field(..., description="Radiocarbon age in BP years", ge=0, lt=60000)
    std_dev: float = Field(..., description="Laboratory uncertainty (1σ)", gt=0, le=500)
    curve: Curve = Field(default=Curve.INTCAL20, description="Calibration curve")
    material: str | None = Field(default=None, description="Sample material (e.g. charcoal, bone)")
    name: str | None = Field(default=None, description="Sample identifier")
    site: str | None = Field(default=None, description="Site or trench name")
    context: str | None = Field(default=None, description="Context or layer number")
    project_id: int | None = Field(default=None, description="Project to assign to")
    language: str = Field(default="en", description="Language for narrative (e.g. 'en', 'fr', 'de', 'es', 'ja')")


class ProbabilityDensityPoint(BaseModel):
    """A single (cal_age, probability) point on the calibrated PDF."""
    cal_age: int = Field(..., description="Calendar age in cal BP")
    density: float = Field(..., description="Probability density at this age")


class CalibratedRange(BaseModel):
    """A contiguous calibrated range at a given confidence level."""
    from_cal_bp: int = Field(..., alias="from", description="Start of range in cal BP")
    to_cal_bp: int = Field(..., description="End of range in cal BP")
    confidence: float = Field(..., description="Confidence level (e.g. 0.682 for 1σ)")

    model_config = {"populate_by_name": True}


class CalibratedDate(BaseModel):
    """Full calibration result for a single date."""
    bp_age: int
    std_dev: float
    curve: str
    calibrated_pdf: List[ProbabilityDensityPoint] = Field(default_factory=list)
    ranges_1sigma: List[CalibratedRange] = Field(default_factory=list)
    ranges_2sigma: List[CalibratedRange] = Field(default_factory=list)
    cal_bp_median: float | None = None
    cal_bp_mean: float | None = None
    is_bimodal: bool = False
    plateau_warning: str | None = None


class CalibrateResponse(BaseModel):
    """Response for a single-date calibration request."""
    success: bool
    data: CalibratedDate | None = None
    narrative: str | None = None
    error: str | None = None


class BatchCalibrateRequest(BaseModel):
    """Request payload for batch calibration of multiple dates."""
    dates: List[CalibrateRequest] = Field(..., min_length=1, max_length=200)


class SpdPoint(BaseModel):
    """A single (cal_age, summed_density) point on the SPD curve."""
    cal_age: int = Field(..., description="Calendar age in cal BP")
    density: float = Field(..., description="Summed probability density at this age")


class SpdResult(BaseModel):
    """Summed Probability Distribution across multiple dates."""
    spd: List[SpdPoint] = Field(default_factory=list)
    n_dates: int = 0
    age_min: int = 0
    age_max: int = 0


class BatchCalibrateResponse(BaseModel):
    """Response for a batch calibration request."""
    success: bool
    results: List[CalibrateResponse] = Field(default_factory=list)
    spd: SpdResult | None = None
    error: str | None = None


class BayesianModelRequest(BaseModel):
    """Request for Bayesian Phase or Sequence modelling."""
    calibration_ids: List[int] = Field(..., min_length=2)
    model_type: str = Field(default="phase", pattern=r"^(phase|sequence)$")
