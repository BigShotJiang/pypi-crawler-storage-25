"""__main__.py — CLI entry point for `python -m libby` or `libby` command.

usage: libby [--port PORT] [--host HOST]

Starts the Libby web server.
"""

from __future__ import annotations

import uvicorn


def main() -> None:
    """Run the Libby web server."""
    import argparse

    parser = argparse.ArgumentParser(description="Libby — Radiocarbon Calibration Tool")
    parser.add_argument("--port", type=int, default=50001, help="Port to listen on (default: 50001)")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Host to bind (default: 0.0.0.0)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload for development")
    args = parser.parse_args()

    uvicorn.run(
        "libby.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
