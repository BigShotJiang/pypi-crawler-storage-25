# lib/harness/ — Context

## Architecture

### Translation Pipeline

Every spawn goes through four steps:

```
SpawnParams                          harness-agnostic inputs
  ↓ adapter.resolve_launch_spec()
HarnessLaunchSpec                    harness-specific typed struct
  ↓ project_<harness>_spec_to_cli_args()
list[str] command + env dict         ready to exec
  ↓ subprocess / connection.start()
Running process                      events flow through SpawnManager drain loop
```

`SpawnParams` is the universal input struct (`adapter.py`). Every adapter declares
which fields it consumes (`consumed_fields`) and which it deliberately ignores
(`explicitly_ignored_fields`). Their union must cover all `SpawnParams` fields, or
`_enforce_spawn_params_accounting()` raises `ImportError` on startup.

At the harness command boundary, `bind_launch_context()` applies
`ModelSelectionContext.harness_model_id` if set — the harness-specific model string
from Mars `RunnablePath` data. This means `--model gpt-5.5 --harness opencode` passes
`openai/gpt-5.5` to the OpenCode subprocess, not bare `gpt-5.5`.

### Two Launch Paths

**Subprocess path** (`lib/launch/`): forks a one-shot process. stdout/stderr are
read back. Process exit signals completion. Used for non-streaming spawns.

**Connection path** (`lib/harness/connections/`): starts a long-lived process then
connects bidirectionally. Events flow through the `SpawnManager` drain loop. Used
for streaming app server and `meridian chat`.

Per-harness mapping:
- Claude subprocess: `claude -p --output-format stream-json --verbose -`
- Claude connection: `claude -p --input-format stream-json --output-format stream-json --verbose` (stdin/stdout NDJSON, not WebSocket despite `claude_ws.py` name)
- Codex subprocess: `codex exec --json`; connection: `codex app-server` (real WebSocket, JSON-RPC 2.0)
- OpenCode subprocess: `opencode run`; connection: `opencode serve` (HTTP+SSE)
- Cursor subprocess: `cursor agent <prompt>` (stdout NDJSON, no connection path — subprocess-only)
- Pi subprocess/connection: `pi rpc --mode rpc` (JSON-RPC stdio); Pi has no subprocess-only path — the RPC mode is the connection

### Pi: Extension-Based Architecture

Pi is the first harness with in-process TypeScript extensions rather than an opaque
subprocess. Two Meridian-owned extensions run inside the Pi process:

- **managed-bash** — replaces Pi's default bash tool with job tracking, background
  execution, and lifecycle event emission. See `src/meridian/pi_runtime/extensions/managed-bash/`.
- **meridian-lifecycle** — consumes internal events, tracks child spawns, manages wave
  notifications, and emits canonical lifecycle events to a sidecar JSONL file. See
  `src/meridian/pi_runtime/extensions/meridian-lifecycle/`.

Extensions are TypeScript, built with `tsup`/esbuild, and materialized per-launch by
`pi_extension_projection.py` into user-level state under `~/.meridian/meridian-pi/agent/extensions/<launch-id>/`.

The runtime itself is resolved by `pi_runtime_resolver.py` — it probes the installed
`pi` binary for compatibility (required `--help` surface tokens differ between primary
and spawned roles) and returns a `PiRuntimeResolution`.

### Pi: Completion Model (Quiescence, Not Process Exit)

Pi spawned sessions do not exit on task completion — they stay alive to track child
spawns and deliver wave notifications. Completion is gated on **quiescence**: the
parent agent is idle, all tracked children have finished, and all pending notifications
have been delivered and acknowledged. The Python drain loop reads lifecycle events from
the sidecar file and terminates the Pi process only when `meridian.quiescence.ready` is
received or the wave deadline expires. See `lib/streaming/spawn_manager.py:_drain_loop()`
and `PiRpcQuiescenceDrainPolicy`.

### Pi: Lifecycle Events

Canonical lifecycle events are written to a sidecar JSONL file by the Pi extensions
and consumed by the Python layer:

- `pi_lifecycle_events.py` — validates and parses lifecycle event lines; enforces
  `schema_version`, `parent_spawn_id`, and allowlist checks
- `pi_lifecycle_file.py` (`PiLifecycleEventTailer`) — incremental JSONL tailer that
  the connection polls during the drain loop
- Events: `meridian.subspawn.start`, `meridian.subspawn.end`,
  `meridian.notification.queued/delivered/completed/failed`, `meridian.quiescence.ready`

Lifecycle events are authoritative from the sidecar — if a lifecycle event appears on
stdout, it is ignored (`PiRpcConnection._parse_stdout_line()` drops them).

### Bootstrap Sequence

`__init__.py:_run_bootstrap()` runs exactly once on package import. Import order
is load-bearing:
1. Adapter modules register `HarnessBundle` entries as side effects.
2. Projection modules execute import-time drift guards.
3. Extractor modules bind `Protocol` implementations.
4. `_enforce_spawn_params_accounting()` validates all adapters account for all fields.

Do not import individual adapter modules before `ensure_bootstrap()` completes —
the accounting guard will run on a partial registration set and fail.

## Contracts

### SpawnParams Accounting Invariant

Every `SpawnParams` field must appear in each adapter's `consumed_fields` **or**
`explicitly_ignored_fields`. Enforced at import time by `launch_spec.py:_enforce_spawn_params_accounting()`. Adding a field to `SpawnParams` without updating all adapters → `ImportError` on startup. This is not documentation — it is enforcement.

Currently ignored fields:
- Claude ignores `report_output_path`, `task_cwd`, `context_from_payload`, `reference_items`
- Codex ignores `skills`, `agent`, `task_cwd`, `context_from_payload`, `reference_items`
- Cursor ignores `skills`, `agent`, `adhoc_agent_payload`, `control_root`,
  `appended_system_prompt`, `report_output_path`, `user_turn_content`,
  `context_from_payload`, `reference_items`, `continue_harness_session_id`,
  `continue_fork`, `effort`

`task_cwd` is ignored by most harness adapters because the `control_root`/`task_cwd` split
assigns different responsibilities to different layers: adapters consume `control_root`
for spawn directory resolution and `--add-dir` roots, while `task_cwd` is injected into
the agent's working context via system prompt in `bind_launch_context()` at the composition
layer. The harness command never needs the raw `task_cwd` value. **Exception:** Cursor
consumes `task_cwd` directly and projects it as `--workspace` — Cursor uses it as the
working directory for the agent subprocess, not as a system-prompt injection.

### Projection Drift Guard

Each `projections/project_<harness>_*.py` module declares `_PROJECTED_FIELDS` and
`_DELEGATED_FIELDS`. `check_projection_drift()` runs at module load. If any spec
field is missing from both sets, it raises `ImportError`. Adding a field to a
harness-specific `LaunchSpec` without updating the corresponding projection module →
startup failure.

### `observe_session_id()` Priority Chain

Called exactly once per launch by the driving adapter after the executor returns.
Must not mutate adapter-instance state:

1. `connection_session_id` — live session ID from transport layer (present for connection-based paths)
2. `extract_session_id()` — extraction from spawn artifacts (`session_id.txt`, then JSONL history)
3. `current_session_id` — previously known ID, returned as fallback
4. `detect_primary_session_id()` — filesystem scan (only when `project_root` and `started_at_epoch` provided)

Callers treat the result as authoritative. Only skip an earlier step if its source is absent (no connection, no artifacts file).

### `HarnessContract` as Inspectable Surface

Every adapter declares a `HarnessContract` — a frozen Pydantic model that makes
capabilities explicit and machine-readable. Call `registry.get_contract(harness_id)`
to inspect without instantiating an adapter. The contract sub-models:

- `HarnessCapabilities` — boolean feature flags
- `ProjectionContract` — how content reaches the harness (which mode, who owns policy)
- `ExtractionContract` — what the adapter extracts from artifacts
- `ApprovalContract` — runtime HITL mode and permission routing
- `BootstrapContract` — subprocess-only vs managed-primary-attach, fork materialization
- `TransportContract` — transport IDs and whether observer/controller is required

### Terminal Event Classification

`semantics.py:terminal_outcome(event)` drives the drain loop's break condition.
Returns `TerminalEventOutcome(status, exit_code, error)` or `None`.
`event_type` is NOT globally unique — always qualified by `event.harness_id`.

Key mappings:
- Claude: `result` event with `is_error=True` → failed; `subtype in ("", "success")` and `terminal_reason in ("", "completed")` → succeeded
- Codex: `turn/completed` → succeeded; `error/connectionClosed` → failed
- OpenCode: `session.idle` → succeeded; `session.error` → failed
- Cursor: `error/connectionClosed` → failed; no explicit success event — stdout EOF
  + process exit code 0 is the success boundary (see `CursorSubprocessConnection.events()`).
- Pi: `agent_end` → succeeded with quiescence check; `cancelled`/`error` → failed.
  The `agent_end` → success mapping is conditional: the drain loop only breaks when
  quiescence is also confirmed (no pending children/notifications). See `PiRpcQuiescenceDrainPolicy`.

## Rationale

### Claude: PTY Capture for Primary Session ID

Claude's TUI emits its session ID to stdout only when stdout is a TTY. Meridian
uses `pty.openpty()` (POSIX) to observe this output without the harness knowing
it's captured. This is the minimum-intrusive mechanism for an otherwise unobservable
value. Windows does not support PTY — Claude primary uses a fallback detection path
(`session_detection.py`) on Windows.

### Claude: System-Prompt File Channel

`--append-system-prompt-file <path>` avoids `ARG_MAX` limits when skills and profile
bodies are large. The adapter writes content to a temp file in the spawn log dir.
This is not an optimization — it is required for spawns with many large skills.

### Content Projection: Inline vs File Channel

Claude has a separate system-prompt channel; Codex and OpenCode do not. All three
use `"inline"` routing for references (rendered via `render_reference_blocks()`),
with `"omitted"` for empty-body files. `supports_native_file_injection=False` for
all current harnesses — `--file` flags are not used.

### Codex: Managed-Primary Approval Routing

In managed-primary mode, Meridian is the first WebSocket client (turn owner).
`requestApproval` and `requestUserInput` are routed to the turn owner by the app
server — the TUI (secondary observer) can only observe notifications.
`CodexConnection._handle_server_request()` dispatches these through an injected
request handler:
- Spawn paths: `AutoAcceptHandler` (auto-approves all)
- Managed-primary attach: `InteractiveHandler` (surfaces as durable events)

### OpenCode: Workspace Env Merging

OpenCode workspace projection goes through `OPENCODE_CONFIG_CONTENT` (JSON env
override). If the parent process already exported this var, Meridian deep-merges
new workspace entries into the parent config rather than suppressing projection.
Suppression would silently drop workspace roots inherited from the spawner.

The implementation (`project_workspace_roots()`, `OPENCODE_CONFIG_CONTENT_ENV`)
lives in `launch/workspace_projection.py`, not in `harness/`. It was moved there
to break a circular import in Python 3.14: `harness/__init__` → `opencode.py` →
`opencode_http.py` → `workspace_projection` as a harness submodule, while harness
was still initializing. The module only depends on `core.types` — it never depended
on harness internals. `opencode_http.py` now imports `OPENCODE_CONFIG_CONTENT_ENV`
from `meridian.lib.launch.workspace_projection`.

### Cursor: Subprocess-Only, Read-Only stdout

Cursor is a single-turn, subprocess-only harness. `cursor agent <prompt>` streams
NDJSON events to stdout then exits — there is no stdin injection, no session resume,
and no bidirectional transport. `CursorSubprocessConnection` is a connection adapter
in name only: it reads stdout until EOF and process exit, then reports done.

`task_cwd` is projected as `--workspace` rather than delegated to the system-prompt
composition layer. Cursor's agent subprocess needs the workspace path as a CLI flag
to set its working directory — system-prompt injection alone is insufficient.

`effort` appears in `_DELEGATED_FIELDS` because Mars resolves `model + effort` →
`harness_model` at bundle-build time. By the time `project_cursor_spec_to_cli_args()`
runs, `spec.model` already contains the effort-resolved model string; `effort` has
served its purpose and is not passed to the CLI.

MVP scope exclusions (enforced by `_assert_supported_for_mvp()`): per-spawn
`mcp_tools`, `continue_fork`, `continue_session_id`, and `interactive` all raise
`HarnessCapabilityMismatch` at projection time.

### Pi: Quiescence Instead of Process Exit

Pi spawned sessions don't exit when a task completes — they stay alive to track
child spawn completion and deliver wave notifications. This means process exit is
not a valid completion signal. Instead, Meridian reads the lifecycle sidecar for
`meridian.quiescence.ready` — emitted when all children are done and all
notifications delivered. The drain loop uses `PiRpcQuiescenceDrainPolicy`, which
classifies `agent_end` as terminal only when the quiescence check passes.

This is the first harness where "done" is not synonymous with "process exited."
All other harnesses (Claude, Codex, OpenCode) use process exit or an explicit
terminal event as the completion boundary.

### Pi: Runtime Compatibility Probing

`pi_runtime_resolver.py` probes the installed `pi` binary before every launch. It
runs `pi --version` and `pi --help`, then checks the help surface for required
CLI flags. The required set differs between `primary` and `spawned` roles —
spawned requires `--mode`, `rpc`, `--no-extensions`, `--no-skills`, `-e`/`--extension`,
etc. If any required token group is missing, the launch fails with a descriptive
`PiRuntimeResolutionError`.

The compatibility probe prevents silent failures where an older Pi binary is on
PATH but lacks the flags Meridian's projection layer emits.

### Pi: Lifecycle Sidecar vs Stdout

Pi's stdout is the JSON-RPC transport channel. Lifecycle events cannot appear there
without polluting the protocol stream. Instead, extensions write lifecycle events to
a sidecar JSONL file via `PI_LIFECYCLE_EVENT_FILE_ENV`. The Python connection layer
tails this file incrementally during the drain loop. If a lifecycle event does appear
on stdout (e.g., from a misconfigured extension), it is silently dropped.

## Patterns

### Adding a Harness

The full end-to-end guide is at [`docs/harness-integration.md`](../../../../docs/harness-integration.md).
It covers probing, adapter implementation, projection, extraction, connection/semantics,
wrapper/runtime packaging, session parity, model/catalog/Mars integration, and a
verification checklist — using Pi as the worked example.

Touch every file in `HARNESS_EXTENSION_TOUCHPOINTS` (listed in `__init__.py`):
1. `core/types.py` — register `HarnessId`/`TransportId`
2. `<new_harness>.py` — adapter with `HarnessContract`, bundle registration, transport map side effect
3. `__init__.py:_run_bootstrap()` — add import wiring
4. `projections/project_<new_harness>_subprocess.py` + `_streaming.py`
5. `extractors/<new_harness>.py`
6. `registry.py:HarnessRegistry.with_defaults()`
7. `launch_spec.py:_enforce_spawn_params_accounting()` — update handled fields
8. `connections/<new_harness>_<transport>.py`
9. `projections/permission_flags.py`
10. `semantics.py:terminal_outcome()`

Missing any of these causes `ImportError` or `ValueError` at startup — the drift
guards make omissions loud.

### Anti-Patterns

**Don't access artifact files directly** — use the `ArtifactStore` protocol.
Direct path access bypasses the abstraction and breaks tests that mock artifacts.

**Don't assume `event_type` is globally unique** — always check `event.harness_id`
first. `turn/completed` is a Codex event; OpenCode uses `session.idle` for the same
semantic.

**Don't call adapter methods before `ensure_bootstrap()`** — the SpawnParams
accounting guard runs on a partial adapter set and will raise false `ImportError`.

**Don't skip `consumed_fields` / `explicitly_ignored_fields` declarations** — the
accounting invariant treats any uncovered field as a bug, not a warning.

## Related KB

> KB lives at `$MERIDIAN_CONTEXT_KB_DIR` (see `meridian context kb`).

- `$MERIDIAN_CONTEXT_KB_DIR/codebase/harness-adapters.md` — capability matrix, per-adapter flag projection, connections subpackage
- `$MERIDIAN_CONTEXT_KB_DIR/codebase/harness/overview.md` — translation pipeline, SpawnParams field table, base commands
- `$MERIDIAN_CONTEXT_KB_DIR/codebase/harness/event-semantics.md` — full terminal event table, activity transitions, drain policy integration
- `$MERIDIAN_CONTEXT_KB_DIR/codebase/harness/claude.md` — Claude flags, PTY path, session detection
- `$MERIDIAN_CONTEXT_KB_DIR/codebase/harness/codex.md` — Codex JSON-RPC, managed-primary, approval routing detail
- `$MERIDIAN_CONTEXT_KB_DIR/codebase/harness/opencode.md` — OpenCode SSE, SQLite sessions, workspace env merging
- `$MERIDIAN_CONTEXT_KB_DIR/codebase/harness/pi.md` — Pi RPC, extension architecture, quiescence drain
- `$MERIDIAN_CONTEXT_KB_DIR/architecture/launch-system.md` — how adapters plug into `build_launch_context()`

## Related .context/

- [../../state/.context/CONTEXT.md](../../state/.context/CONTEXT.md) — artifact store that `SpawnExtractor` reads from; atomic write primitives
- [../../launch/.context/CONTEXT.md](../../launch/.context/CONTEXT.md) — composition seam, four driving adapters, prepare/bind split, invariants
- [../../../pi_runtime/.context/CONTEXT.md](../../../pi_runtime/.context/CONTEXT.md) — Pi TypeScript extensions, build pipeline, lifecycle sidecar writer
