# ops/ — Operation Policy Layer

## Architecture

`ops/` sits between surfaces (CLI commands, MCP tools, REST routes) and mechanisms
(`launch/`, `state/`, `harness/`). It owns *what* to do, not *how* to run a process.

```
CLI / MCP / REST
      │
      ▼
ops/          ← policy: access control, input validation, lifecycle sequencing
      │
      ├──→ launch/      ← composition + execution mechanism
      ├──→ state/       ← spawn/session event stores
      └──→ harness/     ← process adapters (indirectly through launch/)
```

### ops/spawn/ — The Spawn Policy Layer

`ops/spawn/` is the second of four driving adapters into `lib/launch/`. It owns
the foreground and background spawn paths for child spawns (not primary sessions).

**SpawnApplicationService** (in `lib/bootstrap/services.py`, built by `build_spawn_application_service()`)
is the policy coordinator that `ops/spawn/api.py` instantiates. It sits above
`SpawnLifecycleService` (sole state writer) and below the driving adapters:

```
Layer 3: build_launch_context()      ← pure resolution, may fail, no side effects
Layer 4: SpawnApplicationService     ← lifecycle policy
Layer 5: SpawnLifecycleService       ← sole state writer (spawn_store)
```

Key `SpawnApplicationService` methods:
- `prepare_spawn()` — resolve-before-persist; REST and streaming-serve entry point
- `cancel()` — surface-neutral cancel pipeline; managed-primary, signal, finalizing races
- `complete_spawn()` — idempotent terminal seam; acquires per-spawn lock internally
- `archive()` — validates terminal state, emits exactly one `spawn.archived`

### Execution Paths in ops/spawn/execute.py

**Foreground:** `execute_spawn_blocking()` → creates spawn row → calls
`launch_prepared_spawn()` via `asyncio.run()` → `execute_with_streaming()`.

**Background:** `execute_spawn_background()` → creates spawn row → persists
`BackgroundWorkerLaunchRequest` to disk → detaches subprocess. Worker calls
`_execute_existing_spawn()` → `launch_prepared_spawn()`.

Both paths converge at `launch_prepared_spawn()`. This helper:
1. Resolves session continuation (if resuming or forking)
2. Materializes fork (only after spawn row exists — invariant I-10)
3. Builds child env overrides
4. Calls `build_launch_context()`
5. Calls `execute_with_streaming()`

`launch_prepared_spawn()` owns pre-run failure finalization via a broad `except`.
This is safe because `complete_spawn()` is idempotent.

### Resolve-Before-Persist Pattern

The spawn subprocess path creates the row *before* calling `build_launch_context()`.
This is a known gap — it differs from the REST/streaming-serve paths which use
resolve-before-persist (`build_launch_context()` first, row creation only on success).
Row-creation order unification is tracked as follow-up work.

For the REST path, `SpawnApplicationService.prepare_spawn()` enforces:
- **SEAM-1**: No spawn row on resolution failure
- **SEAM-2**: Row metadata always reflects resolved model/agent/harness
- **SEAM-3**: `ConnectionConfig.env_overrides` populated from `LaunchContext.env_overrides`

### ops/spawn/prepare.py — The Exception to SPEC_ONLY

`prepare.py` uses `LaunchCompositionSurface.SPAWN_PREPARE` and
`LaunchArgvIntent.REQUIRED`. This is the only execution path that needs a real
argv — it populates `cli_command` for dry-run display. All actual execution paths
use `SPEC_ONLY`. Do not set `REQUIRED` on execution paths.

### Worktree Lifecycle Protection

`ops/worktree_lifecycle.py` is the raw git worktree layer — it owns creation,
restoration, cleanup, and crash recovery. It is intentionally limited to git/worktree
concerns and returns structured results for callers to persist elsewhere.

`ops/worktree_ensure.py` sits above it and provides high-level ensure semantics used
by `work_worktree.py` and spawn logic. The split is: lifecycle owns raw git operations,
ensure owns state management and idempotency.

Managed worktree creation writes a `mars.local.toml` guard with
`[settings] targets = []` when the worktree is newly created. This prevents
repo-local `meridian mars sync` from materializing harness targets inside each
worktree. Existing `mars.local.toml` files are user-owned and preserved.

**Destructive operations guard against three conditions:**

1. **Manual worktrees** (`managed=False`): paths set via `work set-worktree` are never
   removed or moved by `cleanup_for_done()`, `cleanup_for_delete()`, or `rename_worktree()`.
   These return `skipped_manual` — the user owns the directory lifecycle.
2. **Shared references**: when multiple work items reference the same worktree path,
   cleanup returns `shared_reference` with the list of other item names. The worktree
   is not removed while another item depends on it.
3. **Unpushed commits** (done, not force): `cleanup_for_done()` checks for unpushed
   commits before removal unless `--force` is passed. `cleanup_for_delete()` skips
   this check — delete is already a destructive operation.

**Worktree rename** (`rename_worktree()`) moves both the directory and the git branch
to match the new work slug. Fails if the worktree is shared, missing, or not managed.

**Crash recovery** (`recover_pending()`) handles interrupted `work start` between
`git worktree add` and metadata write. If the worktree directory exists, it heals
the record; otherwise it clears the pending flag.

### ops/init_ops.py — Init Orchestration

`init_ops.py` is the single entry point for all `meridian init --add` and
`meridian init --link` invocations. `run_init_flow()` sequences:

1. `config_init_sync()` — bootstrap `meridian.toml` (idempotent)
2. `mars init` — create `mars.toml` if absent
3. `mars add <sources>` — skipped when no sources requested
4. `mars link <target>` — once per resolved target
5. `maybe_set_primary_agent()` — write `primary.agent` to `meridian.toml` if the
   package declares one and the config field is currently unset

**`_run_mars_json()` helper** consolidates all mars subprocess invocations.
Takes `command: str` and `args: list[str]`, passes `--json`, returns parsed output.
`run_mars_add_json()` is a typed wrapper on top that also calls `_scan_mars_content()`.

**`_scan_mars_content()` uses filesystem scanning, not JSON model parsing.**
It discovers content by walking `.mars/` subdirectories — skills are stored as
directories (containing `SKILL.md`), agents as files, so the scan uses
`f.is_file() or f.is_dir()`. Returns `dict[str, list[str]]` keyed by content
type (e.g., `{"agents": [...], "skills": [...]}`). This avoids coupling Python
to the mars JSON report shape — new content types (hooks, MCP servers, etc.) are
automatically counted without Python model changes.

### ops/worktree_ensure.py — Managed Worktree Orchestration

`worktree_ensure.py` sits above `worktree_lifecycle.py` and provides high-level
ensure semantics with state management, dry-run support, and session-scoped temporary
worktrees. Used by `work_worktree.py` and `spawn/api.py`.

**Key contracts:**

`ensure_work_item_worktree()` is idempotent — calling twice returns `already_available`
on the second call. Once managed metadata (repo_path + name) is persisted, subsequent
calls reuse it regardless of `--repo` or cwd. Accepts dry-run mode and `allow_missing_dry_run`
for work items that don't exist yet. Returns `WorktreeEnsureResult` with status, metadata,
repo_root, canonical_path, and optional warning.

`ensure_temporary_worktree()` provides session-scoped isolation keyed by spawn_id/chat_id
(via `_temporary_key(ctx)` → `worktree-temp/` store). Uses same pending/rollback discipline:
set pending before git, clear on failure, upgrade to ready on success.

`get_temporary_worktree_status()` is read-only; heals pending-but-dir-exists records.

Repo resolution (`_resolve_target_repo()`, `_resolve_repo_root()`) supports path selectors,
workspace aliases, and cwd-based inference. Dry-run mode uses `.git` marker scanning
without running git commands.

Managed path policy: `_canonical_target()` derives `<repo>.worktrees/<name>`. Non-canonical
paths are detected as drift and fail clearly.

### ops/work_worktree.py — Work Worktree Command Orchestration

`work_worktree.py` orchestrates `meridian work worktree` command logic. Accepts
`WorkWorktreeInput` (work_id, ensure, repo, chat_id, project_root), returns
`WorkWorktreeOutput` with worktree path, branch, name, repo_root, managed status,
exists flag, temporary flag, ensured flag, message, and warning.

Routes based on whether a work item is active: calls `ensure_work_item_worktree()`
if present, else delegates to `ensure_temporary_worktree()`. When `ensure=False`,
returns status-only response (no-op) if path already exists. When work_id is empty
and no active work item, uses temporary worktree path.

## Contracts

### OperationRuntime

`runtime.py` provides `OperationRuntime` and `build_runtime()` — the ops-layer
equivalent of `LaunchRuntime`. It resolves runtime root from env (`MERIDIAN_RUNTIME_DIR`),
project state, or user home. Operations that need both project and runtime state
use `resolve_runtime_root_and_config()`.

### Depth Guard

`ops/spawn/api.py` checks `max_depth_reached()` before executing spawns. A spawn
inside a spawn inside a spawn eventually hits the depth limit; the outer caller
gets `depth_exceeded_output()` instead of a new spawn. The reaper also checks
`MERIDIAN_DEPTH` and skips reaping when inside a spawn.

### Session Reference Resolution

`ops/reference.py` exposes `resolve_session_reference()` → `ResolvedSessionReference`.
This resolves spawn IDs (e.g., `p123`), chat IDs, and bare references to canonical
spawn rows. Operations that accept `--from` or `-f` go through this.

### Logging Convention

`ops/` uses `structlog.get_logger()` throughout. Do not use stdlib `logging` —
the logging split between catalog/config (stdlib) and ops/launch/harness (structlog)
matters for the `capture_library_diagnostics()` boundary in `build_launch_context()`.

## Patterns

**ops/ is policy, not mechanism.** If you find yourself building argv, merging
envs, or projecting workspace roots inside ops/, that logic belongs in `launch/`.

**`commands.py` is the operation manifest.** CLI and MCP surfaces discover
available operations through this module. Adding a new operation requires an entry
here; otherwise it is invisible to those surfaces.

**Work item attachment is ops-layer responsibility.** `work_attachment.py:ensure_explicit_work_item()`
handles `--work` resolution before the spawn row is created. The resumed-session
case (reading `preserved_work_id`) is handled inside `run_harness_process()` in
`launch/process/`.

**Sync/conflict boundary: ops resolves roots, autosync_store owns artifacts.**
`sync_conflicts.py` and `context.py` follow the same pattern: ops determines
*which* directories are sync roots (context resolution via `_find_sync_roots()`
and `resolve_context_paths()`), then delegates all artifact access to
`hooks/builtin/autosync_store`. The store is the single owner of
`.meridian/autosync/` path layout and JSON parsing — no other module
constructs those paths directly. `_find_sync_roots()` in `sync_conflicts.py`
uses `autosync_store.has_autosync_state()` to filter candidates, so candidate
discovery stays in ops and artifact presence checking stays in the store.

## Related KB

- `architecture/launch-system.md` — full four-adapter diagram; ops/spawn is adapter #2
- `concepts/spawn-lifecycle.md` — spawn status machine ops surfaces expose
- `architecture/spawn-finalization.md` — `SpawnApplicationService.complete_spawn()`,
  `CompleteSpawnOutcome`, per-spawn lock

## Lateral Links

- `../../launch/.context/CONTEXT.md` — mechanism layer ops/spawn drives
- `../../spawn/.context/CONTEXT.md` — archive visibility ops/spawn reads
