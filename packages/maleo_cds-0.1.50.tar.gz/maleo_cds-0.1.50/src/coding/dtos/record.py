from typing import Annotated
from nexo.enums.identity import OptGender, GenderMixin
from pydantic import Field
from ..mixins.common import (
    OptAge,
    ChiefComplaint,
    OptAdditionalComplaint,
    OptPainScale,
    OptOnset,
    OptChronology,
    OptLocation,
    OptAggravatingFactor,
    OptRelievingFactor,
    OptPersonalMedicalHistory,
    OptFamilyMedicalHistory,
    OptHabitActivityOccupation,
    OptConsumedMedication,
    OptSystolicBloodPressure,
    OptDiastolicBloodPressure,
    OptTemperature,
    OptRespirationRate,
    OptHeartRate,
    OptOxygenSaturation,
    OptAbdominalCircumference,
    OptWaistCircumference,
    OptWeight,
    OptHeight,
    OptBodyMassIndex,
    OptOrganExaminationDetail,
    OptOverallPlan,
    OptTreatment,
)


class PersonalRecordDTO(
    OptAge,
    GenderMixin[OptGender],
):
    gender: Annotated[OptGender, Field(None, description="Gender")] = None


class SubjectiveRecordDTO(
    OptConsumedMedication,
    OptHabitActivityOccupation,
    OptFamilyMedicalHistory,
    OptPersonalMedicalHistory,
    OptRelievingFactor,
    OptAggravatingFactor,
    OptLocation,
    OptChronology,
    OptOnset,
    OptPainScale,
    OptAdditionalComplaint,
    ChiefComplaint,
):
    pass


class ObjectiveRecordDTO(
    OptOrganExaminationDetail,
    OptBodyMassIndex,
    OptWeight,
    OptHeight,
    OptWaistCircumference,
    OptAbdominalCircumference,
    OptOxygenSaturation,
    OptHeartRate,
    OptRespirationRate,
    OptTemperature,
    OptDiastolicBloodPressure,
    OptSystolicBloodPressure,
):
    pass


class PlanRecordDTO(OptTreatment, OptOverallPlan):
    pass
