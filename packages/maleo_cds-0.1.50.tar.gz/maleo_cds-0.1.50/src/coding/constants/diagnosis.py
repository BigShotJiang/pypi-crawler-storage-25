from copy import deepcopy
from nexo.schemas.resource import ResourceIdentifier
from .common import CODING_RESOURCE

DIAGNOSIS_RESOURCE = deepcopy(CODING_RESOURCE)
DIAGNOSIS_RESOURCE.identifiers.append(
    ResourceIdentifier(key="diagnoses", name="Diagnoses", slug="diagnoses")
)
