from copy import deepcopy
from nexo.schemas.resource import ResourceIdentifier
from .common import CODING_RESOURCE

RECORD_RESOURCE = deepcopy(CODING_RESOURCE)
RECORD_RESOURCE.identifiers.append(
    ResourceIdentifier(key="records", name="Records", slug="records")
)
