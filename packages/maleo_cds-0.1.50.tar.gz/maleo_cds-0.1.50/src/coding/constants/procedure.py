from copy import deepcopy
from nexo.schemas.resource import ResourceIdentifier
from .common import CODING_RESOURCE

PROCEDURE_RESOURCE = deepcopy(CODING_RESOURCE)
PROCEDURE_RESOURCE.identifiers.append(
    ResourceIdentifier(key="procedures", name="Procedures", slug="procedures")
)
