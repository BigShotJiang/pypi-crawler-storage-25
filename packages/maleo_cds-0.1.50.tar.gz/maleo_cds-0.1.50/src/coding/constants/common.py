from nexo.schemas.resource import Resource, ResourceIdentifier

CODING_RESOURCE = Resource(
    identifiers=[ResourceIdentifier(key="coding", name="Coding", slug="coding")],
    details=None,
)
