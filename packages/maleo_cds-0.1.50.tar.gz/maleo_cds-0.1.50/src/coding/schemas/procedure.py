from ..dtos.record import PlanRecordDTO


class CreateParameter(PlanRecordDTO):
    @property
    def prompt_format(self) -> str:
        sections = []
        if self.overall_plan is not None:
            sections.append(f"Plan Umum: {self.overall_plan}")
        if self.treatment is not None:
            sections.append(f"Tindakan: {self.treatment}")

        return "\n".join(sections)
