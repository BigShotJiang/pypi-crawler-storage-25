import json
from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from nexo.schemas.mixins.general import Code, Description, Level, Note
from nexo.schemas.mixins.identity import (
    Name,
    DataIdentifier,
    IntOrganizationId,
    IntPrincipalId,
    IntUserId,
)
from nexo.schemas.mixins.timestamp import Duration
from nexo.schemas.security.enums import Domain, DomainMixin
from nexo.types.integer import OptInt
from nexo.types.string import OptStr, ManyStrs
from ..enums.diagnosis import ChosenDiagnosisLevel
from ..enums.record import IdentifierType as RecordIdentifierType
from ..dtos.record import (
    PersonalRecordDTO,
    SubjectiveRecordDTO,
    ObjectiveRecordDTO,
    PlanRecordDTO,
)
from ..mixins.common import OptReasoning
from ..types.record import IdentifierValueType as RecordIdentifierValueType


class DiagnosisDataSchema(OptReasoning, Description, Code[str]):
    pass


OptDiagnosisDataSchema = DiagnosisDataSchema | None
OptDiagnosisDataSchemaT = TypeVar(
    "OptDiagnosisDataSchemaT", bound=OptDiagnosisDataSchema
)


class DiagnosisDataSchemaMixin(BaseModel, Generic[OptDiagnosisDataSchemaT]):
    diagnosis: Annotated[OptDiagnosisDataSchemaT, Field(..., description="Diagnosis")]


ListOfDiagnosisDataSchemas = list[DiagnosisDataSchema]
OptListOfDiagnosisDataSchemas = ListOfDiagnosisDataSchemas | None
OptListOfDiagnosisDataSchemasT = TypeVar(
    "OptListOfDiagnosisDataSchemasT", bound=OptListOfDiagnosisDataSchemas
)


class DiagnosisDataSchemasMixin(BaseModel, Generic[OptListOfDiagnosisDataSchemasT]):
    diagnoses: Annotated[
        OptListOfDiagnosisDataSchemasT, Field(..., description="Diagnoses")
    ]


class DisclaimerMetadataSchema(BaseModel):
    en: str = (
        "The completeness of subjective and objective data greatly influences the results of recommendations from Clinical Decision Support"
    )
    id: str = (
        "Kelengkapan data subjektif dan objektif sangat mempengaruhi hasil rekomendasi dari Clinical Decision Support"
    )


class GenerateDifferentialDiagnosesMetadataSchema(Duration[float]):
    disclaimer: DisclaimerMetadataSchema = Field(
        default_factory=DisclaimerMetadataSchema, description="Disclaimer"
    )


class ChosenDiagnosisDataSchema(
    Note[OptStr],
    Level[ChosenDiagnosisLevel],
    Name[str],
    Code[str],
):
    note: Annotated[OptStr, Field(None, description="Note")] = None


ListOfChosenDiagnosisDataSchemas = list[ChosenDiagnosisDataSchema]


class CompleteDiagnosisSchema(BaseModel):
    generated: ListOfDiagnosisDataSchemas = Field(
        ..., description="Generated diagnoses", min_length=1
    )
    chosen: ListOfChosenDiagnosisDataSchemas = Field(
        ..., description="Chosen diagnoses", min_length=1
    )


class CompleteDiagnosisMixin(BaseModel):
    diagnosis: CompleteDiagnosisSchema = Field(..., description="Complete diagnosis")


class BaseDiagnosisRecordSchema(
    DiagnosisDataSchemasMixin[ListOfDiagnosisDataSchemas],
    ObjectiveRecordDTO,
    SubjectiveRecordDTO,
    PersonalRecordDTO,
    Duration[float],
    IntUserId[int],
    IntOrganizationId[OptInt],
    DomainMixin[Domain],
    IntPrincipalId[int],
):
    pass


class DiagnosisRecordSchema(
    BaseDiagnosisRecordSchema,
    DataIdentifier,
):
    pass


class ProcedureDataSchema(OptReasoning, Description, Code[str]):
    pass


ListOfProcedureDataSchemas = list[ProcedureDataSchema]


class CompleteProcedureSchema(BaseModel):
    primary: Annotated[
        ListOfProcedureDataSchemas, Field(..., description="Primary Procedures")
    ]
    alternatives: Annotated[
        ListOfProcedureDataSchemas, Field(..., description="Alternative Procedures")
    ]


class CompleteProcedureMixin(BaseModel):
    procedure: CompleteProcedureSchema = Field(..., description="Complete procedure")


class GenerateProcedureRecommendationMetadataSchema(Duration[float]):
    pass


class BaseProcedureRecordSchema(
    Duration[float],
    CompleteProcedureMixin,
    PlanRecordDTO,
    IntUserId[int],
    IntOrganizationId[OptInt],
    DomainMixin[Domain],
    IntPrincipalId[int],
):
    pass


class ProcedureRecordSchema(
    BaseProcedureRecordSchema,
    DataIdentifier,
):
    pass


class RecordSchema(
    CompleteProcedureMixin,
    PlanRecordDTO,
    CompleteDiagnosisMixin,
    ObjectiveRecordDTO,
    SubjectiveRecordDTO,
    PersonalRecordDTO,
    DataIdentifier,
):
    @property
    def _identifiers(
        self,
    ) -> tuple[tuple[RecordIdentifierType, RecordIdentifierValueType | str], ...]:
        return (
            (RecordIdentifierType.ID, self.id),
            (RecordIdentifierType.UUID, str(self.uuid)),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )
