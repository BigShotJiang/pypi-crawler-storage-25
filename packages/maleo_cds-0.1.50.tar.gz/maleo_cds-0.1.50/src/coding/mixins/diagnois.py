from pydantic import Field
from typing import Annotated, Literal, TypeGuard
from uuid import UUID
from nexo.schemas.mixins.identity import Identifier
from ..enums.diagnosis import IdentifierType
from ..types.diagnosis import IdentifierValueType


class DiagnosisIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdDiagnosisIdentifier(Identifier[Literal[IdentifierType.ID], int]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID
    value: Annotated[int, Field(..., description="Identifier's value", ge=1)]


class UUIDDiagnosisIdentifier(Identifier[Literal[IdentifierType.UUID], UUID]):
    type: Annotated[
        Literal[IdentifierType.UUID],
        Field(IdentifierType.UUID, description="Identifier's type"),
    ] = IdentifierType.UUID


AnyDiagnosisIdentifier = (
    DiagnosisIdentifier | IdDiagnosisIdentifier | UUIDDiagnosisIdentifier
)


def is_id_identifier(
    identifier: AnyDiagnosisIdentifier,
) -> TypeGuard[IdDiagnosisIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, int)


def is_uuid_identifier(
    identifier: AnyDiagnosisIdentifier,
) -> TypeGuard[UUIDDiagnosisIdentifier]:
    return identifier.type is IdentifierType.UUID and isinstance(identifier.value, UUID)
