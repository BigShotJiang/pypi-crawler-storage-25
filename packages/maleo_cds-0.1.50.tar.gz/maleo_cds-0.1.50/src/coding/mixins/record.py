from pydantic import Field
from typing import Annotated, Literal, TypeGuard
from uuid import UUID
from nexo.schemas.mixins.identity import Identifier
from ..enums.record import IdentifierType
from ..types.record import IdentifierValueType


class RecordIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdRecordIdentifier(Identifier[Literal[IdentifierType.ID], int]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID
    value: Annotated[int, Field(..., description="Identifier's value", ge=1)]


class UUIDRecordIdentifier(Identifier[Literal[IdentifierType.UUID], UUID]):
    type: Annotated[
        Literal[IdentifierType.UUID],
        Field(IdentifierType.UUID, description="Identifier's type"),
    ] = IdentifierType.UUID


AnyRecordIdentifier = RecordIdentifier | IdRecordIdentifier | UUIDRecordIdentifier


def is_id_identifier(
    identifier: AnyRecordIdentifier,
) -> TypeGuard[IdRecordIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, int)


def is_uuid_identifier(
    identifier: AnyRecordIdentifier,
) -> TypeGuard[UUIDRecordIdentifier]:
    return identifier.type is IdentifierType.UUID and isinstance(identifier.value, UUID)
