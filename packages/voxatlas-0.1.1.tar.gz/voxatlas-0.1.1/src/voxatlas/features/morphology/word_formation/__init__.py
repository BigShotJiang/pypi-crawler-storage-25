"""
Word formation feature family.
"""
