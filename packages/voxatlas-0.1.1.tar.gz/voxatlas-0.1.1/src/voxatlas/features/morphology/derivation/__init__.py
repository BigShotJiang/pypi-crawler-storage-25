"""
Derivational morphology feature family.
"""
