"""
Syntax feature extractors.
"""
