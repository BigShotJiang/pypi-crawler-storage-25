"""
Lexical feature extractors.
"""
