"""
Spectral acoustic feature extractors.
"""
