import numpy as np

from voxatlas.acoustic.pitch_utils import DEFAULT_F0_CONFIG, compute_f0, resolve_f0_parameters
from voxatlas.features.base_extractor import BaseExtractor
from voxatlas.features.feature_output import VectorFeatureOutput
from voxatlas.registry.feature_registry import registry


class F0Extractor(BaseExtractor):
    r"""
    Extract the ``acoustic.pitch.f0`` feature within the VoxAtlas pipeline.

    VoxAtlas computes this contour with Praat's filtered-autocorrelation pitch
    tracker through Parselmouth. Filtered autocorrelation low-pass filters the
    waveform before Praat recruits pitch candidates and finds the cheapest path
    through them, which reduces gross octave jumps more reliably than naive
    framewise peak-picking or raw periodicity tracking. Praat recommends this
    method for intonation and vocal-fold vibration measurement.

    The pitch range is the most important control for avoiding octave errors.
    Use ``speaker_preset`` to seed sensible floor/top values for broad speaker
    classes, and then override ``pitch_floor`` or ``pitch_top`` manually when a
    dataset needs tighter bounds.

    Parameters
    ----------
    time_step : float, default=0.010
        Frame step in seconds. Use ``0.0`` to let Praat derive the step from
        the pitch floor.
    pitch_floor : float, default=75.0
        Lowest admissible F0 candidate in Hertz.
    pitch_top : float, default=500.0
        Highest admissible F0 candidate in Hertz.
    max_number_of_candidates : int, default=15
        Maximum number of candidates retained per frame.
    very_accurate : bool, default=False
        Whether to use Praat's longer, more expensive analysis window.
    silence_threshold : float, default=0.09
        Relative silence threshold for voiced/unvoiced path decisions.
    voicing_threshold : float, default=0.50
        Relative threshold for preferring voiced over unvoiced candidates.
    octave_cost : float, default=0.055
        Cost that helps discourage low-frequency octave errors.
    octave_jump_cost : float, default=0.35
        Cost applied to large frame-to-frame octave jumps.
    voiced_unvoiced_cost : float, default=0.14
        Cost applied to voiced/unvoiced transitions.
    attenuation_at_top : float, default=0.03
        Gaussian low-pass attenuation at ``pitch_top``.
    speaker_preset : {"male", "female", "child"} or None, optional
        Optional preset that seeds ``pitch_floor`` and ``pitch_top``.

    Returns
    -------
    VectorFeatureOutput
        Frame-aligned F0 contour in Hertz with ``NaN`` on unvoiced frames.

    Examples
    --------
    >>> import numpy as np
    >>> from voxatlas.audio.audio import Audio
    >>> from voxatlas.features.acoustic.pitch.f0 import F0Extractor
    >>> from voxatlas.features.feature_input import FeatureInput
    >>> sr = 16000
    >>> t = np.arange(0, sr // 10) / sr
    >>> waveform = (0.1 * np.sin(2 * np.pi * 100 * t)).astype(np.float32)
    >>> audio = Audio(waveform=waveform, sample_rate=sr)
    >>> feature_input = FeatureInput(audio=audio, units=None, context={})
    >>> params = F0Extractor.default_config.copy()
    >>> params["speaker_preset"] = "male"
    >>> out = F0Extractor().compute(feature_input, params)
    >>> out.unit
    'frame'
    """

    name = "acoustic.pitch.f0"
    input_units = None
    output_units = "frame"
    dependencies = []
    default_config = DEFAULT_F0_CONFIG.copy()

    def compute(self, feature_input, params):
        """
        Compute the frame-aligned F0 contour for one stream.

        Parameters
        ----------
        feature_input : FeatureInput
            Prepared stream input containing audio and execution context.
        params : dict
            Resolved extractor configuration.

        Returns
        -------
        VectorFeatureOutput
            Frame-aligned F0 contour.

        Raises
        ------
        ValueError
            Raised when audio input is unavailable.

        Notes
        -----
        The output time axis matches the analysis frames used during F0
        estimation.

        Examples
        --------
        >>> import numpy as np
        >>> from voxatlas.audio.audio import Audio
        >>> from voxatlas.features.acoustic.pitch.f0 import F0Extractor
        >>> from voxatlas.features.feature_input import FeatureInput
        >>> sr = 16000
        >>> t = np.arange(0, sr // 10) / sr
        >>> waveform = (0.1 * np.sin(2 * np.pi * 100 * t)).astype(np.float32)
        >>> audio = Audio(waveform=waveform, sample_rate=sr)
        >>> feature_input = FeatureInput(audio=audio, units=None, context={})
        >>> params = F0Extractor.default_config.copy()
        >>> out = F0Extractor().compute(feature_input, params)
        >>> out.time.shape[0] == out.values.shape[0]
        True
        """
        if feature_input.audio is None:
            raise ValueError(f"{self.name} requires audio input")

        resolved = resolve_f0_parameters(params)
        time, values = compute_f0(
            feature_input.audio.waveform,
            feature_input.audio.sample_rate,
            **resolved,
        )

        return VectorFeatureOutput(
            feature=self.name,
            unit="frame",
            time=np.asarray(time, dtype=np.float32),
            values=np.asarray(values, dtype=np.float32),
        )


registry.register(F0Extractor)
