import numpy as np

from voxatlas.acoustic.envelope_utils import compute_rms, smooth_signal
from voxatlas.features.base_extractor import BaseExtractor
from voxatlas.features.feature_output import VectorFeatureOutput
from voxatlas.registry.feature_registry import registry


class RMSEnvelope(BaseExtractor):
    r"""
    Extract the ``acoustic.envelope.rms`` feature within the VoxAtlas pipeline.

    Computes a smoothed, frame-aligned root-mean-square (RMS) amplitude envelope
    from the raw waveform.

    Algorithm
    ---------
    The extractor computes a frame-level root-mean-square amplitude envelope from the waveform.

    1. Frame extraction
       The signal is segmented into overlapping windows determined by ``frame_length`` and ``frame_step``.

    2. Energy accumulation
       For each frame :math:`x_t[n]`, the envelope value is

       .. math::

          \mathrm{RMS}_t = \sqrt{\frac{1}{N}\sum_{n=1}^{N} x_t[n]^2}.

    3. Output alignment
       RMS values are returned with frame midpoints so that derived features such as derivatives, onsets, and peak rate can reuse the same temporal grid.

    Attributes
    ----------
    name : str
        Registry key for this extractor (``"acoustic.envelope.rms"``).
    input_units : str | None
        Required input unit level. ``None`` means this extractor operates
        directly on waveform audio.
    output_units : str | None
        Output alignment unit (``"frame"``).
    dependencies : list[str]
        Upstream features required before execution. Empty for this extractor.
    default_config : dict
        Default runtime parameters:
        ``frame_length=0.025``, ``frame_step=0.01``,
        ``peak_threshold=0.1``, ``smoothing=1``.

    References
    ----------
    Rabiner, L., & Schafer, R. (2011). *Theory and Applications of Digital
    Speech Processing*. Pearson.

    Examples
    --------
    >>> import numpy as np
    >>> from voxatlas.audio.audio import Audio
    >>> from voxatlas.features.acoustic.envelope.rms import RMSEnvelope
    >>> from voxatlas.features.feature_input import FeatureInput
    >>> audio = Audio(waveform=np.zeros(1600, dtype=np.float32), sample_rate=16000)
    >>> feature_input = FeatureInput(audio=audio, units=None, context={})
    >>> params = RMSEnvelope.default_config.copy()
    >>> out = RMSEnvelope().compute(feature_input, params)
    >>> out.unit
    'frame'
    """
    name: str = "acoustic.envelope.rms"
    input_units: str | None = None
    output_units: str | None = "frame"
    dependencies: list[str] = []
    default_config: dict = {
        "frame_length": 0.025,
        "frame_step": 0.010,
        "smoothing": 1,
        "peak_threshold": 0.1,
    }

    def compute(self, feature_input, params):
        """
        Compute the extractor output for a single pipeline invocation.
        
        This method is the reusable execution entry point for the extractor. It receives the standard ``FeatureInput`` bundle, applies the configured algorithm, and returns feature values aligned to the extractor output units for storage in the pipeline feature store.
        
        Parameters
        ----------
        feature_input : object
            Structured extractor input bundling audio, hierarchical units, and execution context for this feature computation.
        params : object
            Resolved feature configuration for this invocation. Keys are feature-specific and merged from defaults and pipeline settings.
        
        Returns
        -------
        FeatureOutput
            Structured output aligned to the ``frame`` unit level when applicable.
        
        Examples
        --------
        >>> import numpy as np
        >>> from voxatlas.audio.audio import Audio
        >>> from voxatlas.features.acoustic.envelope.rms import RMSEnvelope
        >>> from voxatlas.features.feature_input import FeatureInput
        >>> audio = Audio(waveform=np.zeros(1600, dtype=np.float32), sample_rate=16000)
        >>> feature_input = FeatureInput(audio=audio, units=None, context={})
        >>> params = RMSEnvelope.default_config.copy()
        >>> result = RMSEnvelope().compute(feature_input, params)
        >>> result.values.shape[0] > 0
        True
        """
        if feature_input.audio is None:
            raise ValueError(f"{self.name} requires audio input")

        time, values = compute_rms(
            feature_input.audio.waveform,
            feature_input.audio.sample_rate,
            params["frame_length"],
            params["frame_step"],
        )
        values = smooth_signal(values, params.get("smoothing", 1))

        return VectorFeatureOutput(
            feature=self.name,
            unit="frame",
            time=np.asarray(time, dtype=np.float32),
            values=np.asarray(values, dtype=np.float32),
        )


registry.register(RMSEnvelope)
