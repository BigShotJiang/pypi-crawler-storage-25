"""
Spectrogram feature extractors.
"""
