"""
Prosodic phonology feature extractors.
"""
