"""
Articulatory phonology feature extractors.
"""
