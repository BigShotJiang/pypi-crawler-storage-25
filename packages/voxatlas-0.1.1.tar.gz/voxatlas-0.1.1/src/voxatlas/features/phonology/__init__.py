"""
Phonology feature extractors.
"""
