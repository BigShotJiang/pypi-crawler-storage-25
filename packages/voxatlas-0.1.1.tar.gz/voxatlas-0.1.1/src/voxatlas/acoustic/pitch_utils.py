from __future__ import annotations

from typing import Any, Mapping

import numpy as np

PRAAT_FILTERED_AUTOCORRELATION_COMMAND = "To Pitch (filtered autocorrelation)..."

# VoxAtlas keeps a 10 ms hop for frame-aligned acoustic features by default,
# while Praat's path costs follow the filtered-autocorrelation defaults.
DEFAULT_TIME_STEP = 0.010
DEFAULT_PITCH_FLOOR = 75.0
DEFAULT_PITCH_TOP = 500.0
DEFAULT_MAX_NUMBER_OF_CANDIDATES = 15
DEFAULT_VERY_ACCURATE = False
DEFAULT_SILENCE_THRESHOLD = 0.09
DEFAULT_VOICING_THRESHOLD = 0.50
DEFAULT_OCTAVE_COST = 0.055
DEFAULT_OCTAVE_JUMP_COST = 0.35
DEFAULT_VOICED_UNVOICED_COST = 0.14
DEFAULT_ATTENUATION_AT_TOP = 0.03

# The pitch range is the most important control for avoiding octave errors.
SPEAKER_PRESETS: dict[str, dict[str, float]] = {
    "male": {"pitch_floor": 60.0, "pitch_top": 350.0},
    "female": {"pitch_floor": 100.0, "pitch_top": 500.0},
    "child": {"pitch_floor": 120.0, "pitch_top": 800.0},
}

DEFAULT_F0_CONFIG: dict[str, Any] = {
    "time_step": DEFAULT_TIME_STEP,
    "pitch_floor": DEFAULT_PITCH_FLOOR,
    "pitch_top": DEFAULT_PITCH_TOP,
    "max_number_of_candidates": DEFAULT_MAX_NUMBER_OF_CANDIDATES,
    "very_accurate": DEFAULT_VERY_ACCURATE,
    "silence_threshold": DEFAULT_SILENCE_THRESHOLD,
    "voicing_threshold": DEFAULT_VOICING_THRESHOLD,
    "octave_cost": DEFAULT_OCTAVE_COST,
    "octave_jump_cost": DEFAULT_OCTAVE_JUMP_COST,
    "voiced_unvoiced_cost": DEFAULT_VOICED_UNVOICED_COST,
    "attenuation_at_top": DEFAULT_ATTENUATION_AT_TOP,
    "speaker_preset": None,
}


def _coerce_float(value: Any, name: str) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a real number") from exc


def _coerce_int(value: Any, name: str) -> int:
    try:
        coerced = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be an integer") from exc

    if float(coerced) != float(value):
        raise ValueError(f"{name} must be an integer")

    return coerced


def resolve_f0_parameters(params: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """
    Resolve and validate F0 extraction parameters.

    The resolver applies VoxAtlas defaults, optional speaker-aware pitch-range
    presets, and then any explicit user overrides. Speaker presets only seed
    the pitch range because Praat's pitch floor and top are the strongest
    controls for reducing octave errors.

    Parameters
    ----------
    params : mapping of str to object, optional
        User-supplied configuration values. The canonical keys are
        ``time_step``, ``pitch_floor``, ``pitch_top``,
        ``max_number_of_candidates``, ``very_accurate``,
        ``silence_threshold``, ``voicing_threshold``, ``octave_cost``,
        ``octave_jump_cost``, ``voiced_unvoiced_cost``,
        ``attenuation_at_top``, and ``speaker_preset``.
        Backward-compatible aliases ``fmin``, ``fmax``, and ``frame_step`` are
        also accepted.

    Returns
    -------
    dict
        Validated parameter dictionary ready for Praat/Parselmouth calls.

    Raises
    ------
    ValueError
        Raised when the supplied configuration is invalid.

    Examples
    --------
    >>> resolved = resolve_f0_parameters({"speaker_preset": "female", "pitch_top": 550.0})
    >>> resolved["pitch_floor"], resolved["pitch_top"]
    (100.0, 550.0)
    """
    resolved = dict(DEFAULT_F0_CONFIG)
    supplied = dict(params or {})

    preset_name = supplied.get("speaker_preset")
    if preset_name is not None:
        if not isinstance(preset_name, str):
            raise ValueError("speaker_preset must be one of: male, female, child")

        normalized_preset = preset_name.strip().lower()
        if normalized_preset not in SPEAKER_PRESETS:
            choices = ", ".join(sorted(SPEAKER_PRESETS))
            raise ValueError(f"speaker_preset must be one of: {choices}")

        resolved.update(SPEAKER_PRESETS[normalized_preset])
        resolved["speaker_preset"] = normalized_preset

    if "pitch_floor" not in supplied and "fmin" in supplied:
        resolved["pitch_floor"] = supplied["fmin"]
    if "pitch_top" not in supplied and "fmax" in supplied:
        resolved["pitch_top"] = supplied["fmax"]
    if "time_step" not in supplied and "frame_step" in supplied:
        resolved["time_step"] = supplied["frame_step"]

    for key in DEFAULT_F0_CONFIG:
        if key in supplied:
            resolved[key] = supplied[key]

    resolved["time_step"] = _coerce_float(resolved["time_step"], "time_step")
    resolved["pitch_floor"] = _coerce_float(resolved["pitch_floor"], "pitch_floor")
    resolved["pitch_top"] = _coerce_float(resolved["pitch_top"], "pitch_top")
    resolved["max_number_of_candidates"] = _coerce_int(
        resolved["max_number_of_candidates"],
        "max_number_of_candidates",
    )
    if not isinstance(resolved["very_accurate"], bool):
        raise ValueError("very_accurate must be a boolean")
    resolved["silence_threshold"] = _coerce_float(
        resolved["silence_threshold"],
        "silence_threshold",
    )
    resolved["voicing_threshold"] = _coerce_float(
        resolved["voicing_threshold"],
        "voicing_threshold",
    )
    resolved["octave_cost"] = _coerce_float(resolved["octave_cost"], "octave_cost")
    resolved["octave_jump_cost"] = _coerce_float(
        resolved["octave_jump_cost"],
        "octave_jump_cost",
    )
    resolved["voiced_unvoiced_cost"] = _coerce_float(
        resolved["voiced_unvoiced_cost"],
        "voiced_unvoiced_cost",
    )
    resolved["attenuation_at_top"] = _coerce_float(
        resolved["attenuation_at_top"],
        "attenuation_at_top",
    )

    validate_f0_parameters(resolved)
    return resolved


def validate_f0_parameters(params: Mapping[str, Any]) -> None:
    """
    Validate resolved F0 extraction parameters.

    Parameters
    ----------
    params : mapping of str to object
        Resolved F0 parameters, typically from :func:`resolve_f0_parameters`.

    Returns
    -------
    None
        This function returns ``None`` when validation succeeds.

    Raises
    ------
    ValueError
        Raised when any parameter falls outside the accepted range.

    Examples
    --------
    >>> validate_f0_parameters(resolve_f0_parameters({"pitch_floor": 75.0, "pitch_top": 500.0})) is None
    True
    """
    if params["time_step"] < 0.0:
        raise ValueError("time_step must be greater than or equal to 0")
    if params["pitch_floor"] <= 0.0:
        raise ValueError("pitch_floor must be greater than 0")
    if params["pitch_top"] <= params["pitch_floor"]:
        raise ValueError("pitch_top must be greater than pitch_floor")
    if params["max_number_of_candidates"] <= 0:
        raise ValueError("max_number_of_candidates must be greater than 0")

    for name in (
        "silence_threshold",
        "voicing_threshold",
        "octave_cost",
        "octave_jump_cost",
        "voiced_unvoiced_cost",
        "attenuation_at_top",
    ):
        if params[name] < 0.0:
            raise ValueError(f"{name} must be greater than or equal to 0")


def _parselmouth_pitch(
    signal: np.ndarray,
    sr: int | float,
    params: Mapping[str, Any],
):
    try:
        import parselmouth
        from parselmouth.praat import call
    except ImportError as exc:
        raise ImportError(
            "acoustic.pitch.f0 requires Parselmouth. Install the acoustic extras "
            "(for example, `pip install 'voxatlas[acoustic]'`) and use a "
            "Parselmouth build that supports Praat's filtered autocorrelation pitch command."
        ) from exc

    sound = parselmouth.Sound(
        np.asarray(signal, dtype=np.float64),
        sampling_frequency=float(sr),
    )

    try:
        return call(
            sound,
            PRAAT_FILTERED_AUTOCORRELATION_COMMAND,
            params["time_step"],
            params["pitch_floor"],
            params["pitch_top"],
            params["max_number_of_candidates"],
            params["very_accurate"],
            params["attenuation_at_top"],
            params["silence_threshold"],
            params["voicing_threshold"],
            params["octave_cost"],
            params["octave_jump_cost"],
            params["voiced_unvoiced_cost"],
        )
    except Exception as exc:
        raise RuntimeError(
            "Praat filtered-autocorrelation pitch extraction failed. "
            "Check the F0 configuration and ensure the installed Parselmouth "
            "version supports 'To Pitch (filtered autocorrelation)...'."
        ) from exc


def compute_f0(
    signal,
    sr,
    *,
    time_step: float = DEFAULT_TIME_STEP,
    pitch_floor: float = DEFAULT_PITCH_FLOOR,
    pitch_top: float = DEFAULT_PITCH_TOP,
    max_number_of_candidates: int = DEFAULT_MAX_NUMBER_OF_CANDIDATES,
    very_accurate: bool = DEFAULT_VERY_ACCURATE,
    silence_threshold: float = DEFAULT_SILENCE_THRESHOLD,
    voicing_threshold: float = DEFAULT_VOICING_THRESHOLD,
    octave_cost: float = DEFAULT_OCTAVE_COST,
    octave_jump_cost: float = DEFAULT_OCTAVE_JUMP_COST,
    voiced_unvoiced_cost: float = DEFAULT_VOICED_UNVOICED_COST,
    attenuation_at_top: float = DEFAULT_ATTENUATION_AT_TOP,
    speaker_preset: str | None = None,
    fmin: float | None = None,
    fmax: float | None = None,
    frame_step: float | None = None,
):
    r"""
    Estimate frame-level fundamental frequency with Praat filtered autocorrelation.

    This routine wraps Praat's filtered-autocorrelation pitch tracker through
    Parselmouth. Filtered autocorrelation first low-pass filters the waveform
    and then runs Praat's candidate tracking with path costs over the filtered
    signal. Praat recommends this method for intonation and vocal-fold
    vibration measurement because it reduces gross octave errors more reliably
    than naive framewise peak-picking or raw periodicity tracking.

    Parameters
    ----------
    signal : array-like
        One-dimensional waveform with shape ``(n_samples,)``.
    sr : int or float
        Sampling rate in Hertz.
    time_step : float, default=0.010
        Frame step in seconds. Set to ``0.0`` to let Praat derive the step
        from the pitch floor.
    pitch_floor : float, default=75.0
        Lowest admissible F0 candidate in Hertz.
    pitch_top : float, default=500.0
        Highest admissible F0 candidate in Hertz. This range control is the
        most important parameter for reducing octave errors.
    max_number_of_candidates : int, default=15
        Maximum number of candidates retained per frame.
    very_accurate : bool, default=False
        Whether to use Praat's more expensive, longer analysis window.
    silence_threshold : float, default=0.09
        Relative silence threshold used by Praat's voiced/unvoiced path search.
    voicing_threshold : float, default=0.50
        Relative voicing threshold for candidate selection.
    octave_cost : float, default=0.055
        Cost that biases Praat away from low-frequency octave errors.
    octave_jump_cost : float, default=0.35
        Transition cost for rapid octave changes across adjacent frames.
    voiced_unvoiced_cost : float, default=0.14
        Transition cost for switching between voiced and unvoiced states.
    attenuation_at_top : float, default=0.03
        Gaussian low-pass attenuation at ``pitch_top``.
    speaker_preset : {"male", "female", "child"} or None, optional
        Optional preset that seeds ``pitch_floor`` and ``pitch_top`` for a
        broad speaker class. Explicit ``pitch_floor`` or ``pitch_top`` values
        always override the preset.
    fmin : float, optional
        Backward-compatible alias for ``pitch_floor``.
    fmax : float, optional
        Backward-compatible alias for ``pitch_top``.
    frame_step : float, optional
        Backward-compatible alias for ``time_step``.

    Returns
    -------
    tuple of numpy.ndarray
        Pair ``(time, values)`` where ``time`` has shape ``(n_frames,)`` and
        ``values`` contains frame-aligned F0 values in Hertz as ``float32``.
        Unvoiced frames are represented as ``NaN``.

    Raises
    ------
    ValueError
        Raised when the waveform shape or F0 parameters are invalid.
    ImportError
        Raised when Parselmouth is unavailable.
    RuntimeError
        Raised when Praat fails to compute the pitch object.

    Examples
    --------
    >>> import numpy as np
    >>> sr = 16000
    >>> t = np.arange(sr // 5) / sr
    >>> signal = (0.1 * np.sin(2 * np.pi * 120 * t)).astype(np.float32)
    >>> time, f0 = compute_f0(signal, sr, speaker_preset="male")
    >>> time.shape == f0.shape
    True
    """
    signal_array = np.asarray(signal, dtype=np.float32)
    if signal_array.ndim != 1:
        raise ValueError("compute_f0 expects a 1D signal")
    if signal_array.size == 0:
        empty = np.array([], dtype=np.float32)
        return empty, empty

    resolved = resolve_f0_parameters(
        {
            "time_step": time_step,
            "pitch_floor": pitch_floor,
            "pitch_top": pitch_top,
            "max_number_of_candidates": max_number_of_candidates,
            "very_accurate": very_accurate,
            "silence_threshold": silence_threshold,
            "voicing_threshold": voicing_threshold,
            "octave_cost": octave_cost,
            "octave_jump_cost": octave_jump_cost,
            "voiced_unvoiced_cost": voiced_unvoiced_cost,
            "attenuation_at_top": attenuation_at_top,
            "speaker_preset": speaker_preset,
            "fmin": fmin,
            "fmax": fmax,
            "frame_step": frame_step,
        }
    )
    pitch = _parselmouth_pitch(signal_array, sr, resolved)

    time = np.asarray(pitch.xs(), dtype=np.float32)
    values = np.asarray(pitch.selected_array["frequency"], dtype=np.float32)
    values[values <= 0.0] = np.nan
    return time, values


def _is_voiced(value):
    return np.isfinite(value) and value > 0.0


def compute_f0_derivative(f0_values):
    r"""
    Compute the first temporal difference of a pitch contour.

    This helper is used by VoxAtlas pitch-shape features to summarize how
    rapidly F0 changes from one frame to the next.

    Parameters
    ----------
    f0_values : array-like
        Frame-level pitch contour with shape ``(n_frames,)``. Unvoiced frames
        should be encoded as non-positive values or ``NaN``.

    Returns
    -------
    numpy.ndarray
        Float32 array with shape ``(n_frames,)`` containing first differences
        for valid adjacent voiced frames and ``NaN`` elsewhere.

    Examples
    --------
    >>> delta = compute_f0_derivative([100.0, 110.0, np.nan])
    >>> np.isnan(delta[0]), float(delta[1])
    (np.True_, 10.0)
    """
    f0_values = np.asarray(f0_values, dtype=np.float32)
    derivative = np.full(f0_values.shape, np.nan, dtype=np.float32)

    for index in range(1, len(f0_values)):
        previous = float(f0_values[index - 1])
        current = float(f0_values[index])

        if not (_is_voiced(previous) and _is_voiced(current)):
            continue

        derivative[index] = current - previous

    return derivative


def compute_f0_slope(f0_values, window=5):
    r"""
    Estimate local linear slope of a pitch contour.

    Parameters
    ----------
    f0_values : array-like
        Frame-level pitch contour with shape ``(n_frames,)``.
    window : int, default=5
        Number of neighbouring frames used for the local regression window.

    Returns
    -------
    numpy.ndarray
        Float32 array with shape ``(n_frames,)`` containing a local
        least-squares slope for voiced frames.

    Examples
    --------
    >>> slope = compute_f0_slope([100.0, 110.0, 120.0], window=3)
    >>> float(slope[1]) > 0.0
    True
    """
    f0_values = np.asarray(f0_values, dtype=np.float32)
    slopes = np.full(f0_values.shape, np.nan, dtype=np.float32)
    half_window = max(1, int(window) // 2)

    for index, value in enumerate(f0_values):
        if not _is_voiced(float(value)):
            continue

        start = max(0, index - half_window)
        end = min(len(f0_values), index + half_window + 1)
        window_values = f0_values[start:end]
        voiced_mask = np.isfinite(window_values) & (window_values > 0.0)

        if np.count_nonzero(voiced_mask) < 2:
            continue

        x = np.arange(start, end, dtype=np.float32)[voiced_mask]
        y = window_values[voiced_mask].astype(np.float32)
        slope, _ = np.polyfit(x, y, 1)
        slopes[index] = np.float32(slope)

    return slopes


def compute_f0_variability(f0_values):
    r"""
    Compute global pitch dispersion and broadcast it to voiced frames.

    Parameters
    ----------
    f0_values : array-like
        Frame-level pitch contour with shape ``(n_frames,)``.

    Returns
    -------
    numpy.ndarray
        Float32 array with shape ``(n_frames,)`` containing the voiced F0
        standard deviation on voiced frames and ``NaN`` elsewhere.
    """
    f0_values = np.asarray(f0_values, dtype=np.float32)
    variability = np.full(f0_values.shape, np.nan, dtype=np.float32)
    voiced_mask = np.isfinite(f0_values) & (f0_values > 0.0)

    if not np.any(voiced_mask):
        return variability

    variability[voiced_mask] = np.float32(np.std(f0_values[voiced_mask]))
    return variability


def compute_f0_range(f0_values):
    r"""
    Compute voiced pitch range and broadcast it to voiced frames.

    Parameters
    ----------
    f0_values : array-like
        Frame-level pitch contour with shape ``(n_frames,)``.

    Returns
    -------
    numpy.ndarray
        Float32 array with shape ``(n_frames,)`` containing the global voiced
        pitch range on voiced frames and ``NaN`` elsewhere.
    """
    f0_values = np.asarray(f0_values, dtype=np.float32)
    f0_range = np.full(f0_values.shape, np.nan, dtype=np.float32)
    voiced_mask = np.isfinite(f0_values) & (f0_values > 0.0)

    if not np.any(voiced_mask):
        return f0_range

    range_value = np.max(f0_values[voiced_mask]) - np.min(f0_values[voiced_mask])
    f0_range[voiced_mask] = np.float32(range_value)
    return f0_range


def compute_contour_shape(f0_values):
    r"""
    Discretize pitch movement into rising, level, and falling states.

    Parameters
    ----------
    f0_values : array-like
        Frame-level pitch contour with shape ``(n_frames,)``.

    Returns
    -------
    numpy.ndarray
        Float32 array with ``1`` for rising, ``0`` for level, ``-1`` for
        falling, and ``NaN`` where the derivative is undefined.
    """
    derivatives = compute_f0_derivative(f0_values)
    contour = np.full(np.asarray(f0_values).shape, np.nan, dtype=np.float32)

    rising = derivatives > 0.5
    falling = derivatives < -0.5
    level = np.isfinite(derivatives) & ~(rising | falling)

    contour[rising] = 1.0
    contour[falling] = -1.0
    contour[level] = 0.0
    return contour
