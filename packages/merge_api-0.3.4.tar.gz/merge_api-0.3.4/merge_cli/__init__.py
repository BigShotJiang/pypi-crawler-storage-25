"""Merge CLI — search, discover, and execute Agent Handler tools."""

__version__ = "0.3.4"
