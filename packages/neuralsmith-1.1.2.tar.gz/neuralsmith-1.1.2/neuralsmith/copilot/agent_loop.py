"""Agent / Agent-plus interactive loop with JSON tool protocol."""

from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from .agent_prompt import AGENT_SYSTEM_PROMPT
from .agent_tools import dispatch_readonly_tool
from .neuralsmith_argv import build_neuralsmith_argv, format_argv_for_display
from .ui import box, rule, style

MAX_AGENT_TURNS = 15
TOOL_FENCE_RE = re.compile(
    r"```tool-json\s*\n(.*?)```",
    re.IGNORECASE | re.DOTALL,
)


def _strip_tool_fences(text: str) -> str:
    return TOOL_FENCE_RE.sub("", text).strip()


def extract_tool_calls(assistant_text: str) -> Tuple[str, List[Dict[str, Any]]]:
    """Return visible text (fences removed) and list of {tool, args} dicts."""
    visible = _strip_tool_fences(assistant_text)
    calls: List[Dict[str, Any]] = []
    for m in TOOL_FENCE_RE.finditer(assistant_text):
        raw = m.group(1).strip()
        if not raw:
            continue
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            continue
        batch: List[Dict[str, Any]] = []
        if isinstance(data, dict) and "tools" in data:
            t = data["tools"]
            if isinstance(t, list):
                batch = [x for x in t if isinstance(x, dict)]
        elif isinstance(data, dict) and "tool" in data:
            batch = [data]
        elif isinstance(data, list):
            batch = [x for x in data if isinstance(x, dict)]
        for item in batch:
            name = item.get("tool")
            if not isinstance(name, str):
                continue
            args = item.get("args", {})
            if args is None:
                args = {}
            if not isinstance(args, dict):
                continue
            calls.append({"tool": name.strip(), "args": args})
    return visible, calls


def _collect_response_text(response: Any) -> str:
    parts: List[str] = []
    if hasattr(response, "candidates") and response.candidates:
        for cand in response.candidates:
            if hasattr(cand, "content") and hasattr(cand.content, "parts"):
                for part in cand.content.parts:
                    if hasattr(part, "text") and part.text:
                        parts.append(part.text)
    return "".join(parts)


def _summarize_stream(text: Optional[str], *, max_lines: int = 50) -> str:
    if not text:
        return "(empty)"
    s = text.strip()
    if not s:
        return "(empty)"
    lines = s.splitlines()
    if len(lines) <= max_lines:
        return "\n".join(lines)
    tail = lines[-max_lines:]
    omitted = len(lines) - max_lines
    return f"[truncated: omitted {omitted} earlier lines]\n" + "\n".join(tail)


def _execute_run_neuralsmith(
    args: Dict[str, Any],
    *,
    require_confirm: bool,
    confirm_fn: Callable[[List[str]], bool],
) -> str:
    sub = args.get("subcommand")
    flags = args.get("flags")
    cwd = args.get("cwd")
    if not isinstance(sub, str):
        return "run_neuralsmith: missing string subcommand"
    if not isinstance(flags, dict):
        return "run_neuralsmith: flags must be an object"
    base_cwd = str(Path(cwd).resolve()) if cwd else None
    argv, err = build_neuralsmith_argv(sub, flags, cwd=base_cwd)
    if err:
        return f"run_neuralsmith: {err}"
    assert argv is not None
    display = format_argv_for_display(argv)
    print(style(f"Running NeuralSmith {sub}...", color="cyan", bold=True))
    print(style(f"Command: {display}", color="muted"))
    sys.stdout.flush()
    if require_confirm:
        if not confirm_fn(argv):
            return "run_neuralsmith: user declined execution (no command was run)."
    try:
        r = subprocess.run(
            argv,
            cwd=base_cwd or None,
            env=None,
            capture_output=True,
            text=True,
            errors="replace",
        )
        stdout_summary = _summarize_stream(r.stdout)
        stderr_summary = _summarize_stream(r.stderr)
        return (
            f"run_neuralsmith: exit_code={r.returncode}\n"
            f"command: {display}\n"
            f"stdout_summary:\n{stdout_summary}\n"
            f"stderr_summary:\n{stderr_summary}"
        )
    except Exception as e:
        return f"run_neuralsmith: failed to execute: {e}"


def default_confirm(argv: List[str]) -> bool:
    try:
        line = input(style("Approve command? Type 'yes' to run: ", color="yellow", bold=True)).strip().lower()
    except (EOFError, KeyboardInterrupt):
        print(style("\n(cancelled)", color="muted"))
        return False
    return line in ("yes", "y")


def run_agent_turn(
    model: Any,
    prompt: str,
    *,
    require_confirm: bool,
    confirm_fn: Callable[[List[str]], bool],
) -> str:
    """
    One model call; execute tools in a loop until no tool-json or max turns.
    Returns final assistant text for the user (last visible message).
    """
    current = prompt.rstrip()
    if not current.endswith("Assistant:"):
        current = current + "\nAssistant:"
    last_visible = ""
    for _ in range(MAX_AGENT_TURNS):
        try:
            response = model.generate_content(current)
        except Exception as e:
            return f"Error calling model: {e}"
        text = _collect_response_text(response)
        if not text.strip():
            return last_visible or "(empty model response)"
        visible, calls = extract_tool_calls(text)
        if visible:
            print(style("Assistant", color="magenta", bold=True))
            print(rule(color="magenta"))
            print(visible)
            print(rule(color="magenta"))
            print()
            sys.stdout.flush()
            last_visible = visible
        if not calls:
            return visible if visible else last_visible
        results: List[str] = []
        for c in calls:
            name = c["tool"]
            args = c["args"]
            if name == "run_neuralsmith":
                out = _execute_run_neuralsmith(
                    args,
                    require_confirm=require_confirm,
                    confirm_fn=confirm_fn,
                )
            else:
                cwd = args.get("cwd") if isinstance(args, dict) else None
                if isinstance(cwd, str):
                    tcwd: Optional[str] = cwd
                else:
                    tcwd = None
                out = dispatch_readonly_tool(name, args, cwd=tcwd)
            print(style("Result:", color="green", bold=True))
            print(out)
            print()
            results.append(f"- {name}: {out}")
        tool_msg = (
            "Tool results:\n"
            + "\n".join(results)
            + "\n\nContinue. If done, answer the user without a tool-json block."
        )
        current = current + text + "\n\nUser:\n" + tool_msg + "\nAssistant:"
    return last_visible + f"\n\n(Stopped: max agent turns {MAX_AGENT_TURNS} reached.)"


def run_agent_loop(model: Any, *, mode: str) -> int:
    """
    mode: 'agent' | 'agent_plus'
    """
    require_confirm = mode != "agent_plus"
    if mode == "agent_plus":
        print(
            "\n"
            + box(
                "Agent-plus Mode",
                "EXPERIMENTAL mode enabled.\n"
                "`run_neuralsmith` executes without confirmation.\n"
                "Review every proposed command in the transcript.",
                color="yellow",
            )
            + "\n"
        )
    else:
        print("\n" + style("CoPilot Agent mode: training commands require typing 'yes' to run.", color="cyan") + "\n")

    history: List[Dict[str, str]] = []
    print(style("Type 'help' for commands, 'exit' to quit.", color="muted") + "\n")

    while True:
        try:
            user_input = input(style("You > ", color="blue", bold=True)).strip()
            if not user_input:
                continue
            low = user_input.lower()
            if low in ("exit", "quit", "q"):
                print(style("Session ended.", color="muted"))
                return 0
            if low == "help":
                _print_agent_help()
                continue

            # Bang commands match Ask mode
            if low.startswith("!validate "):
                from neuralsmith.copilot.cli import handle_validation

                handle_validation(user_input[10:].strip())
                continue
            if low.startswith("!status"):
                from neuralsmith.copilot.cli import handle_run_status

                handle_run_status(user_input[len("!status") :].strip() or None)
                continue
            if low.startswith("!watch"):
                from neuralsmith.copilot.cli import handle_run_watch

                handle_run_watch(user_input[len("!watch") :].strip() or None)
                continue

            prompt = _build_agent_prompt(history, user_input)
            final = run_agent_turn(
                model,
                prompt,
                require_confirm=require_confirm,
                confirm_fn=default_confirm,
            )
            history.append({"role": "user", "text": user_input})
            history.append({"role": "assistant", "text": final})
            if len(history) > 20:
                history = history[-20:]
        except KeyboardInterrupt:
            print("\n" + style("Session ended.", color="muted"))
            return 0
        except EOFError:
            print("\n" + style("Session ended.", color="muted"))
            return 0
        except Exception as e:
            print(style(f"\nERROR: {e}", color="red", bold=True))

    return 0


def _build_agent_prompt(history: List[Dict[str, str]], user_input: str) -> str:
    if not history:
        return f"{AGENT_SYSTEM_PROMPT}\n\nUser: {user_input}\nAssistant:"
    conversation = "\n".join(
        f"{m['role'].capitalize()}: {m['text']}" for m in history
    )
    return f"{AGENT_SYSTEM_PROMPT}\n\n{conversation}\nUser: {user_input}\nAssistant:"


def _print_agent_help() -> None:
    print(box("Agent Commands", """help              - This message
exit / quit / q   - Exit
!validate <path>  - Validate data (same as Ask mode)
!status [path]    - Read neuralsmith_run_status.json
!watch [path]     - Poll status until done (unbounded; Ctrl+C to stop)

The model may use tools (see agent system prompt). Training runs via run_neuralsmith.""", color="cyan"))
