#!/usr/bin/env python3
import os
import argparse
import numpy as np
import pandas as pd
import gc  # Garbage collection for memory cleanup
import sys
import math
from sklearn.model_selection import train_test_split, cross_val_score, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, VotingClassifier, VotingRegressor, AdaBoostClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge, Lasso
from sklearn.svm import SVC, SVR
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.experimental import enable_iterative_imputer  # noqa: F401
from sklearn.impute import IterativeImputer
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import f1_score, accuracy_score, mean_squared_error, r2_score
from sklearn.utils.class_weight import compute_class_weight
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.feature_selection import SelectKBest, mutual_info_classif, mutual_info_regression
from sklearn.multioutput import MultiOutputRegressor, MultiOutputClassifier
import xgboost as xgb
import lightgbm as lgb
import joblib
import json
from pathlib import Path
import time
import logging
from scipy.stats import randint, uniform, skew
from scipy.special import boxcox1p
try:
    import psutil
except ImportError:
    psutil = None
try:
    from imblearn.over_sampling import SMOTE
except ImportError:
    SMOTE = None
    print("imblearn not installed; SMOTE will be skipped.")

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def convert_numpy_types(obj):
    """Convert numpy types and handle NaN/Inf values for JSON serialization"""
    if isinstance(obj, np.generic):
        val = obj.item()
        # Handle NaN and Infinity
        if isinstance(val, (float, np.floating)):
            if math.isnan(val) or (isinstance(val, float) and str(val) == 'nan'):
                return None
            if math.isinf(val) or (isinstance(val, float) and str(val) in ('inf', '-inf')):
                return None
        return val
    if isinstance(obj, (float, np.floating)):
        if math.isnan(obj) or (isinstance(obj, float) and str(obj) == 'nan'):
            return None
        if math.isinf(obj) or (isinstance(obj, float) and str(obj) in ('inf', '-inf')):
            return None
    if isinstance(obj, dict):
        return {k: convert_numpy_types(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [convert_numpy_types(item) for item in obj]
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

def cleanup_memory():
    """Force garbage collection and clear memory"""
    gc.collect()
    if psutil:
        # Clear system cache if possible (Linux/Unix)
        try:
            if hasattr(os, 'system') and os.name != 'nt':  # Not Windows
                os.system('sync && echo 3 > /proc/sys/vm/drop_caches 2>/dev/null || true')
        except Exception:
            pass

def log_memory_usage(stage=""):
    """Log current memory usage"""
    if psutil:
        memory = psutil.virtual_memory()
        logger.info(f"Memory usage {stage}: {memory.percent:.1f}% ({memory.used / (1024**3):.1f}GB used, {memory.available / (1024**3):.1f}GB available)")
    else:
        logger.info(f"Memory monitoring unavailable {stage}")

def check_memory_pressure():
    """Check if system is under memory pressure"""
    if psutil:
        memory = psutil.virtual_memory()
        if memory.percent > 85:
            logger.warning(f"[WARNING] High memory usage detected: {memory.percent:.1f}%")
            logger.warning("Consider restarting the script or freeing up system memory")
            return True
    return False

class TabularDataAnalyzer:
    def __init__(self, random_search_iters=5):
        self.data = None
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.target_column = None
        self.target_columns = None  # Support multiple targets
        self.is_multi_output = False
        self.is_classification = True
        self.models = {}
        self.results = {}
        self.feature_importance = {}
        self.label_encoder = None
        self.feature_names = None
        self.scaler = None
        self.class_weights = None
        self.random_search_iters = random_search_iters
        self.comparison_table = []
        self.eda_insights = None

        # persistent pipeline artifacts for inference
        self.imputer = None
        self.cat_mappings = {}
        self.cat_fallbacks = {}
        self.selector = None
        self.original_feature_names = None
        self.outlier_caps = {}
        self.boxcox_lambda = 0.15

    def load_data(self, file_path, downsample=False, target_column=None):
        try:
            if downsample:
                df = pd.read_csv(file_path, low_memory=True, nrows=100000)
                logger.info(f"Loaded downsampled {file_path}: {df.shape}")
            else:
                # Check available memory before loading large files
                if psutil:
                    available_memory_gb = psutil.virtual_memory().available / (1024**3)
                    logger.info(f"Available memory: {available_memory_gb:.1f} GB")
                    
                    # Estimate file size and warn if it might cause memory issues
                    file_size_mb = os.path.getsize(file_path) / (1024 * 1024)
                    estimated_memory_mb = file_size_mb * 3  # Rough estimate: CSV loads as ~3x file size in memory
                    estimated_memory_gb = estimated_memory_mb / 1024
                    
                    logger.info(f"File size: {file_size_mb:.1f} MB, estimated memory usage: {estimated_memory_gb:.1f} GB")
                    
                    if estimated_memory_gb > available_memory_gb * 0.8:  # If estimated usage > 80% of available memory
                        logger.warning(f"[WARNING] Large dataset detected! Estimated memory usage ({estimated_memory_gb:.1f} GB) might exceed available memory ({available_memory_gb:.1f} GB)")
                        logger.warning("Consider using --downsample flag or ensure you have sufficient RAM")
                
                df = pd.read_csv(file_path, low_memory=True)
                logger.info(f"Loaded {file_path}: {df.shape}")
                
                # Log actual memory usage after loading
                actual_memory_mb = df.memory_usage(deep=True).sum() / (1024 * 1024)
                logger.info(f"Actual memory usage: {actual_memory_mb:.1f} MB")
                
                # Warn if memory usage is very high
                if psutil and actual_memory_mb > 2000:  # > 2GB
                    available_memory_gb = psutil.virtual_memory().available / (1024**3)
                    logger.warning(f"[WARNING] High memory usage detected: {actual_memory_mb:.1f} MB")
                    logger.warning("Consider using --downsample flag if you encounter memory issues during training")
                    
            self.data = df
            if target_column:
                # Support both single column (string) and multiple columns (list)
                if isinstance(target_column, list):
                    missing = [col for col in target_column if col not in df.columns]
                    if missing:
                        logger.warning(f"Target columns not found: {missing}")
                    else:
                        self.target_columns = target_column
                        self.is_multi_output = True
                        logger.info(f"Set target columns: {target_column}")
                else:
                    if target_column in df.columns:
                        self.target_column = target_column
                        logger.info(f"Set target column: {target_column}")
                    else:
                        logger.warning(f"Target column '{target_column}' not found in data")
            return True
        except Exception as e:
            logger.error(f"Error loading {file_path}: {e}")
            return False

    def perform_eda(self, correlation_threshold=0.9, missing_threshold=0.8, skewness_threshold=1.0, target_column=None, force_sample=False):
        logger.info("Performing EDA...")
        log_memory_usage("before EDA")
        
        df = self.data
        target = target_column or self.target_column
        if target is None:
            target = 'Cover_Type' if 'Cover_Type' in df.columns else df.columns[-1]
            logger.info(f"Auto-detected target for EDA: {target}")
        if target not in df.columns:
            logger.error(f"Target column '{target}' not found in data")
            raise ValueError(f"Target column '{target}' not found")

        # Check memory pressure before starting EDA
        if check_memory_pressure():
            logger.warning("High memory usage detected, forcing sampling for EDA")
            force_sample = True

        # Memory optimization: Check dataset size and use sampling for large datasets
        dataset_size_mb = df.memory_usage(deep=True).sum() / (1024 * 1024)
        logger.info(f"Dataset size: {dataset_size_mb:.1f} MB")
        
        # Use sampling for EDA if dataset is too large (> 500MB) or force_sample is True
        use_sample = dataset_size_mb > 500 or force_sample
        if use_sample:
            sample_size = min(500000, len(df))  # Sample up to 500k rows
            df_eda = df.sample(n=sample_size, random_state=42)
            if force_sample:
                logger.info(f"Using sampled data for EDA ({sample_size:,} rows) due to --sample-eda flag")
            else:
                logger.info(f"Using sampled data for EDA ({sample_size:,} rows) due to large dataset size")
        else:
            df_eda = df

        # Get summary and replace NaN values with None before converting to dict
        summary_df = df_eda.describe(include='all')
        summary_dict = {}
        for col in summary_df.columns:
            summary_dict[col] = {}
            for stat in summary_df.index:
                val = summary_df.loc[stat, col]
                if pd.isna(val) or (isinstance(val, (float, np.floating)) and (math.isnan(val) or math.isinf(val))):
                    summary_dict[col][stat] = None
                else:
                    # Convert numpy types to Python native types
                    if isinstance(val, (np.integer, np.floating)):
                        summary_dict[col][stat] = float(val.item()) if isinstance(val, np.floating) else int(val.item())
                    else:
                        summary_dict[col][stat] = val
        
        # Clean missing_percent dict
        missing_pct_raw = (df_eda.isnull().sum() / len(df_eda) * 100).to_dict()
        missing_percent_clean = {}
        for k, v in missing_pct_raw.items():
            if pd.isna(v) or (isinstance(v, (float, np.floating)) and (math.isnan(v) or math.isinf(v))):
                missing_percent_clean[k] = None
            else:
                missing_percent_clean[k] = float(v) if isinstance(v, (np.integer, np.floating)) else v
        
        eda_insights = {
            'summary': summary_dict,
            'missing_percent': missing_percent_clean,
            'features_to_drop': [],
            'features_to_transform': [],
            'outliers_detected': {},
            'high_correlations': []
        }

        for col, pct in eda_insights['missing_percent'].items():
            # Handle None values (which replaced NaN) - skip comparison if None
            if pct is not None and pct > missing_threshold * 100 and col != target:
                eda_insights['features_to_drop'].append(col)

        for col in df_eda.columns:
            if df_eda[col].nunique() <= 1 and col != target:
                eda_insights['features_to_drop'].append(col)

        numerical_cols = df_eda.select_dtypes(include=[np.number]).columns.drop(target, errors='ignore')
        if len(numerical_cols) > 0:
            # Process skewness in chunks to avoid memory issues
            logger.info("Computing skewness...")
            skew_values = df_eda[numerical_cols].skew()
            for col in numerical_cols:
                if abs(skew_values[col]) > skewness_threshold:
                    eda_insights['features_to_transform'].append(col)
            
            # Cleanup memory after skewness computation
            del skew_values
            cleanup_memory()
            log_memory_usage("after skewness")
            
            # Process outliers in chunks to avoid memory issues
            logger.info("Detecting outliers...")
            chunk_size = 50  # Process 50 columns at a time
            for i in range(0, len(numerical_cols), chunk_size):
                chunk_cols = numerical_cols[i:i+chunk_size]
                for col in chunk_cols:
                    Q1, Q3 = df_eda[col].quantile(0.25), df_eda[col].quantile(0.75)
                    IQR = Q3 - Q1
                    outliers = ((df_eda[col] < (Q1 - 1.5 * IQR)) | (df_eda[col] > (Q3 + 1.5 * IQR))).sum()
                    if outliers > 0:
                        eda_insights['outliers_detected'][col] = int(outliers)
                
                # Cleanup after each chunk
                if i % (chunk_size * 2) == 0:  # Every 2 chunks
                    cleanup_memory()
            
            # Final cleanup after outliers
            cleanup_memory()
            log_memory_usage("after outliers")

            # Process correlation matrix in chunks for large datasets
            logger.info("Computing correlations...")
            if use_sample or len(numerical_cols) > 100:
                # For large datasets or when using samples, process correlations in chunks
                chunk_size = 50
                high_correlations = []
                to_drop = set()
                
                for i in range(0, len(numerical_cols), chunk_size):
                    chunk_cols = numerical_cols[i:i+chunk_size]
                    chunk_df = df_eda[chunk_cols]
                    chunk_corr = chunk_df.corr().abs()
                    chunk_upper = chunk_corr.where(np.triu(np.ones(chunk_corr.shape), k=1).astype(bool))
                    
                    # Find high correlations within this chunk
                    for col1 in chunk_upper.columns:
                        for col2 in chunk_upper.index:
                            if chunk_upper.loc[col2, col1] > correlation_threshold:
                                high_correlations.append((col1, col2))
                                to_drop.add(col2)  # Drop the second column
                
                # Also check correlations between chunks
                if len(numerical_cols) > chunk_size:
                    logger.info("Computing cross-chunk correlations...")
                    for i in range(chunk_size, len(numerical_cols), chunk_size):
                        for j in range(i, min(i + chunk_size, len(numerical_cols))):
                            col1, col2 = numerical_cols[i-chunk_size], numerical_cols[j]
                            if col1 != col2:
                                corr_val = df_eda[col1].corr(df_eda[col2])
                                if abs(corr_val) > correlation_threshold:
                                    high_correlations.append((col1, col2))
                                    to_drop.add(col2)
                
                eda_insights['features_to_drop'].extend(list(to_drop))
                eda_insights['high_correlations'] = high_correlations
            else:
                # For smaller datasets, use the original method
                corr_matrix = df_eda[numerical_cols].corr().abs()
                upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
                to_drop = [column for column in upper.columns if any(upper[column] > correlation_threshold)]
                eda_insights['features_to_drop'].extend(to_drop)
                eda_insights['high_correlations'] = [(col1, col2) for col1 in upper.columns for col2 in upper.index if upper.loc[col2, col1] > correlation_threshold]
                
                # Cleanup correlation matrices
                del corr_matrix, upper
            
            # Cleanup after correlation analysis
            cleanup_memory()
            log_memory_usage("after correlations")
        else:
            eda_insights['features_to_transform'] = []
            eda_insights['outliers_detected'] = {}
            eda_insights['high_correlations'] = []

        if self.is_classification:
            class_dist_raw = df_eda[target].value_counts(normalize=True).to_dict()
            # Clean class_dist to handle any NaN values
            class_dist = {}
            for k, v in class_dist_raw.items():
                if pd.isna(v) or (isinstance(v, (float, np.floating)) and (math.isnan(v) or math.isinf(v))):
                    class_dist[k] = None
                else:
                    class_dist[k] = float(v) if isinstance(v, (np.integer, np.floating)) else v
            eda_insights['class_distribution'] = class_dist
            logger.info(f"Class distribution: {class_dist}")
            # Filter out None values when checking minimum
            valid_values = [v for v in class_dist.values() if v is not None]
            if valid_values and min(valid_values) < 0.05 and SMOTE:
                eda_insights['use_smote'] = True
            else:
                eda_insights['use_smote'] = False

        # Add metadata about sampling
        if use_sample:
            eda_insights['sampling_info'] = {
                'used_sampling': True,
                'sample_size': sample_size,
                'original_size': len(df),
                'dataset_size_mb': dataset_size_mb
            }
        else:
            eda_insights['sampling_info'] = {
                'used_sampling': False,
                'dataset_size_mb': dataset_size_mb
            }

        output_path = Path('eda_report.json')
        
        # Clean the insights dictionary to handle NaN values
        def clean_for_json(obj):
            """Recursively clean object for JSON serialization"""
            if isinstance(obj, dict):
                return {k: clean_for_json(v) for k, v in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [clean_for_json(item) for item in obj]
            elif isinstance(obj, (np.integer, np.floating)):
                val = obj.item()
                if isinstance(val, float):
                    if math.isnan(val) or np.isnan(val) or str(val).lower() == 'nan':
                        return None
                    if math.isinf(val) or np.isinf(val) or str(val).lower() in ('inf', '-inf', 'infinity', '-infinity'):
                        return None
                return val
            elif isinstance(obj, float):
                if math.isnan(obj) or np.isnan(obj) or str(obj).lower() == 'nan':
                    return None
                if math.isinf(obj) or np.isinf(obj) or str(obj).lower() in ('inf', '-inf', 'infinity', '-infinity'):
                    return None
                return obj
            elif pd.isna(obj):
                return None
            else:
                return obj
        
        cleaned_insights = clean_for_json(eda_insights)
        
        with open(output_path, 'w') as f:
            json.dump(cleaned_insights, f, indent=4, default=convert_numpy_types)
        logger.info(f"EDA report saved to {output_path}")

        logger.info(f"Features to drop: {eda_insights['features_to_drop']}")
        logger.info(f"Features to transform (skewed): {eda_insights['features_to_transform']}")
        logger.info(f"Outliers detected: {eda_insights['outliers_detected']}")
        if use_sample:
            if force_sample:
                logger.info(f"[WARNING] EDA performed on sample ({sample_size:,} rows) due to --sample-eda flag")
            else:
                logger.info(f"[WARNING] EDA performed on sample ({sample_size:,} rows) due to large dataset size ({dataset_size_mb:.1f} MB)")
        
        # Final cleanup and memory check
        cleanup_memory()
        log_memory_usage("after EDA")
        check_memory_pressure()
        
        self.eda_insights = eda_insights
        return eda_insights

    def preprocess_data(self, target_column=None, handle_missing=True, handle_imbalance=True,
                       is_classification=True, stratify=True, drop_columns=None, eda_insights=None,
                       train_percent=80.0, val_percent=0.0, test_percent=20.0, random_state=42):
        self.is_classification = is_classification

        # Handle both single and multiple target columns
        if target_column is None:
            if self.target_columns:
                target_column = self.target_columns
            elif self.target_column:
                target_column = self.target_column
            elif 'Cover_Type' in self.data.columns:
                target_column = 'Cover_Type'
            else:
                target_column = self.data.columns[-1]
                logger.info(f"Auto-detected target: {target_column}")
        
        # Set multi-output flag
        if isinstance(target_column, list):
            self.target_columns = target_column
            self.is_multi_output = True
            logger.info(f"Multi-output mode with targets: {target_column}")
        else:
            self.target_column = target_column
            self.is_multi_output = False

        # Validate targets exist
        target_cols = target_column if isinstance(target_column, list) else [target_column]
        for col in target_cols:
            if col not in self.data.columns:
                raise ValueError(f"Target column '{col}' not found")

        drop_cols = []
        if drop_columns:
            drop_cols += [c.strip() for c in drop_columns.split(',') if c.strip()]
        for possible_id in ['id', 'Id', 'ID', 'index']:
            if possible_id in self.data.columns and possible_id not in drop_cols and possible_id not in target_cols:
                drop_cols.append(possible_id)
        if eda_insights:
            drop_cols.extend(eda_insights['features_to_drop'])

        if drop_cols:
            drop_cols = [c for c in drop_cols if c in self.data.columns and c not in target_cols]
            if drop_cols:
                logger.info(f"Dropping columns: {drop_cols}")
                self.data = self.data.drop(columns=drop_cols, errors='ignore')

        if eda_insights and eda_insights['features_to_transform']:
            for col in eda_insights['features_to_transform']:
                if col in self.data.columns and col not in target_cols:
                    self.data[col] = boxcox1p(self.data[col].clip(0), self.boxcox_lambda)
                    logger.info(f"Applied Box-Cox transform to {col}")

        if eda_insights and eda_insights['outliers_detected']:
            for col in eda_insights['outliers_detected']:
                if col in self.data.columns and col not in target_cols:
                    Q1, Q3 = self.data[col].quantile(0.25), self.data[col].quantile(0.75)
                    IQR = Q3 - Q1
                    min_cap, max_cap = (Q1 - 1.5 * IQR), (Q3 + 1.5 * IQR)
                    self.outlier_caps[col] = (float(min_cap), float(max_cap))
                    self.data[col] = self.data[col].clip(min_cap, max_cap)
                    logger.info(f"Capped outliers in {col}")

        # AFTER drops/transforms/outlier-capping -> define original feature names (these are training inputs)
        self.original_feature_names = self.data.drop(columns=target_cols).columns.tolist()
        X = self.data.drop(columns=target_cols)
        y = self.data[target_column]  # Can be Series or DataFrame

        if self.is_classification:
            self.label_encoder = LabelEncoder()
            if self.is_multi_output:
                # For multi-output classification, encode each column separately
                y_encoded = pd.DataFrame()
                for col in target_cols:
                    y_encoded[col] = LabelEncoder().fit_transform(self.data[col].fillna('missing'))
                y = y_encoded
            else:
                y = self.label_encoder.fit_transform(y.fillna('missing'))

        if handle_missing:
            X = self._handle_missing_values(X, eda_insights)

        X = self._encode_categorical_variables(X)

        stratify_param = y if (self.is_classification and stratify and not self.is_multi_output) else None
        if self.is_classification and stratify and not self.is_multi_output:
            class_counts = pd.Series(y).value_counts()
            if class_counts.min() < 2:
                logger.warning("Some classes have <2 samples. Disabling stratification.")
                stratify_param = None

        # Normalize percentages to ensure they sum to 100
        total_percent = train_percent + val_percent + test_percent
        if abs(total_percent - 100.0) > 0.01:
            logger.warning(f"Split percentages sum to {total_percent}%, normalizing to 100%")
            train_percent = (train_percent / total_percent) * 100.0
            val_percent = (val_percent / total_percent) * 100.0
            test_percent = (test_percent / total_percent) * 100.0

        # Convert percentages to fractions
        test_size = test_percent / 100.0
        val_size = val_percent / 100.0
        train_size = train_percent / 100.0

        # First split: separate test set
        self.X_train_val, self.X_test, self.y_train_val, self.y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=stratify_param
        )

        # Second split: separate train and validation from train+val set
        # Calculate the relative size of validation within train+val
        if val_percent > 0:
            val_size_relative = val_size / (train_size + val_size)
            stratify_param_val = self.y_train_val if (self.is_classification and stratify and not self.is_multi_output) else None
            if stratify_param_val is not None:
                class_counts_val = pd.Series(self.y_train_val).value_counts()
                if class_counts_val.min() < 2:
                    stratify_param_val = None
            
            self.X_train, self.X_val, self.y_train, self.y_val = train_test_split(
                self.X_train_val, self.y_train_val, test_size=val_size_relative, 
                random_state=random_state, stratify=stratify_param_val
            )
        else:
            # No validation set - use all train+val as train
            self.X_train = self.X_train_val
            self.y_train = self.y_train_val
            self.X_val = None
            self.y_val = None

        logger.info(f"Data split: Train {len(self.X_train)} ({train_percent:.1f}%), "
                   f"Val {len(self.X_val) if self.X_val is not None and len(self.X_val) > 0 else 0} ({val_percent:.1f}%), "
                   f"Test {len(self.X_test)} ({test_percent:.1f}%)")

        if self.is_classification and handle_imbalance and not self.is_multi_output:
            self._handle_class_imbalance(eda_insights)

        self._scale_features()
        self.feature_engineering()

        return True

    def _handle_missing_values(self, X, eda_insights):
        numerical_cols = X.select_dtypes(include=[np.number]).columns
        categorical_cols = X.select_dtypes(include=['object']).columns

        if len(numerical_cols) > 0:
            imputer = IterativeImputer(random_state=42, max_iter=10)
            try:
                X[numerical_cols] = imputer.fit_transform(X[numerical_cols])
                self.imputer = imputer
            except Exception as e:
                logger.warning(f"IterativeImputer failed ({e}), using median fill.")
                self.imputer = None
                for col in numerical_cols:
                    fill_value = X[col].median() if eda_insights and col in eda_insights.get('features_to_transform', []) else X[col].mean()
                    X[col] = X[col].fillna(fill_value)

        for col in categorical_cols:
            mode_val = X[col].mode()[0] if len(X[col].mode()) > 0 else 'Unknown'
            X[col] = X[col].fillna(mode_val)

        return X

    def _encode_categorical_variables(self, X):
        categorical_cols = X.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            if X[col].nunique() > 50:
                means = X.join(self.data[self.target_column]).groupby(col)[self.target_column].mean()
                mapping = means.to_dict()
                default_val = float(means.mean())
                X[col] = X[col].map(mapping).fillna(default_val)
                self.cat_mappings[col] = mapping
                self.cat_fallbacks[col] = default_val
            else:
                uniques = X[col].astype(str).fillna('missing').unique().tolist()
                mapping = {v: i for i, v in enumerate(uniques)}
                X[col] = X[col].astype(str).fillna('missing').map(mapping)
                self.cat_mappings[col] = mapping
                self.cat_fallbacks[col] = -1
        return X

    def _handle_class_imbalance(self, eda_insights):
        if self.is_classification:
            classes = np.unique(self.y_train)
            self.class_weights = compute_class_weight('balanced', classes=classes, y=self.y_train)
            self.class_weights = dict(zip(classes, self.class_weights))
            logger.info(f"Computed class weights: {self.class_weights}")
            if eda_insights and eda_insights.get('use_smote', False) and SMOTE:
                smote = SMOTE(random_state=42)
                try:
                    self.X_train, self.y_train = smote.fit_resample(self.X_train, self.y_train)
                    logger.info("Applied SMOTE for class imbalance.")
                except Exception as e:
                    logger.warning(f"SMOTE failed ({e}), using class weights only.")

    def _scale_features(self):
        self.scaler = StandardScaler()
        self.X_train = self.scaler.fit_transform(self.X_train)
        self.X_test = self.scaler.transform(self.X_test)
        # Scale validation set if it exists
        if hasattr(self, 'X_val') and self.X_val is not None and len(self.X_val) > 0:
            self.X_val = self.scaler.transform(self.X_val)

    def feature_engineering(self, top_k_features=0.8):
        if len(self.original_feature_names or []) == 0:
            return
        logger.info("Performing feature engineering...")
        selector = mutual_info_classif if self.is_classification else mutual_info_regression
        k = max(1, int(len(self.original_feature_names) * top_k_features))
        skb = SelectKBest(selector, k=k)
        self.selector = skb
        
        # For multi-output regression, use first target for feature selection
        y_for_selection = self.y_train.iloc[:, 0] if self.is_multi_output and hasattr(self.y_train, 'iloc') else self.y_train
        
        self.X_train = skb.fit_transform(self.X_train, y_for_selection)
        self.X_test = skb.transform(self.X_test)
        # Transform validation set if it exists
        if hasattr(self, 'X_val') and self.X_val is not None and len(self.X_val) > 0:
            self.X_val = skb.transform(self.X_val)
        selected_mask = skb.get_support()
        self.feature_names = [f for f, selected in zip(self.original_feature_names, selected_mask) if selected]
        logger.info(f"Selected {len(self.feature_names)} features: {self.feature_names}")

    def get_param_grids(self):
        if self.is_classification:
            param_grids = {
                'Random Forest': {
                    'n_estimators': randint(50, 200),
                    'max_depth': randint(5, 30),
                    'min_samples_split': randint(2, 10),
                    'class_weight': ['balanced', None]
                },
                'Logistic Regression': {
                    'C': uniform(0.1, 10),
                    'solver': ['lbfgs', 'liblinear'],
                    'class_weight': ['balanced', None]
                },
                'XGBoost': {
                    'n_estimators': randint(50, 200),
                    'max_depth': randint(3, 10),
                    'learning_rate': uniform(0.01, 0.3),
                    'subsample': uniform(0.6, 0.4)
                },
                'LightGBM': {
                    'n_estimators': randint(50, 200),
                    'max_depth': randint(3, 10),
                    'learning_rate': uniform(0.01, 0.3),
                    'subsample': uniform(0.6, 0.4)
                },
                'SVM': {
                    'C': uniform(0.1, 10),
                    'kernel': ['rbf', 'linear'],
                    'gamma': ['scale', 'auto']
                },
                'KNN': {
                    'n_neighbors': randint(3, 15),
                    'weights': ['uniform', 'distance'],
                    'p': [1, 2]
                },
                'Naive Bayes': {},
                'Decision Tree': {
                    'max_depth': randint(5, 30),
                    'min_samples_split': randint(2, 10),
                    'class_weight': ['balanced', None]
                },
                'AdaBoost': {
                    'n_estimators': randint(50, 200),
                    'learning_rate': uniform(0.01, 1.0)
                },
                'Gradient Boosting': {
                    'n_estimators': randint(50, 200),
                    'max_depth': randint(3, 10),
                    'learning_rate': uniform(0.01, 0.3),
                    'subsample': uniform(0.6, 0.4)
                },
                'MLP': {
                    'hidden_layer_sizes': [(50,), (100,), (50, 50)],
                    'activation': ['relu', 'tanh'],
                    'alpha': uniform(1e-5, 1e-1),
                    'learning_rate_init': uniform(1e-4, 1e-1)
                }
            }
        else:
            param_grids = {
                'Random Forest': {
                    'n_estimators': randint(50, 200),
                    'max_depth': randint(5, 30),
                    'min_samples_split': randint(2, 10)
                },
                'Linear Regression': {},
                'XGBoost': {
                    'n_estimators': randint(50, 200),
                    'max_depth': randint(3, 10),
                    'learning_rate': uniform(0.01, 0.3),
                    'subsample': uniform(0.6, 0.4)
                },
                'LightGBM': {
                    'n_estimators': randint(50, 200),
                    'max_depth': randint(3, 10),
                    'learning_rate': uniform(0.01, 0.3),
                    'subsample': uniform(0.6, 0.4)
                },
                'Ridge': {
                    'alpha': uniform(0.1, 10)
                },
                'Lasso': {
                    'alpha': uniform(0.1, 10)
                },
                'SVR': {
                    'C': uniform(0.1, 10),
                    'kernel': ['rbf', 'linear'],
                    'gamma': ['scale', 'auto']
                },
                'KNN': {
                    'n_neighbors': randint(3, 15),
                    'weights': ['uniform', 'distance'],
                    'p': [1, 2]
                },
                'Decision Tree': {
                    'max_depth': randint(5, 30),
                    'min_samples_split': randint(2, 10)
                },
                'MLP': {
                    'hidden_layer_sizes': [(50,), (100,), (50, 50)],
                    'activation': ['relu', 'tanh'],
                    'alpha': uniform(1e-5, 1e-1),
                    'learning_rate_init': uniform(1e-4, 1e-1)
                }
            }
        return param_grids

    def _extract_feature_importance(self, estimator, name):
        try:
            if hasattr(estimator, 'feature_importances_'):
                fi = estimator.feature_importances_
            elif hasattr(estimator, 'coef_'):
                coef = estimator.coef_
                fi = np.mean(np.abs(coef), axis=0) if coef.ndim > 1 else np.abs(coef)
            elif name == 'MLP' and hasattr(estimator, 'coefs_'):
                coefs = estimator.coefs_
                if len(coefs) > 0:
                    fi = np.sum([np.abs(w) for w in coefs], axis=0)
                    fi = fi[0] if fi.ndim > 1 else fi
                else:
                    fi = None
            else:
                fi = None
            if fi is not None:
                fi = np.array(fi).astype(float)
                if fi.sum() != 0:
                    fi = fi / np.abs(fi).sum()
            return fi
        except Exception:
            return None

    def train_models(self, mode='exhaustive'):
        if self.is_classification:
            base_models_all = {
                'Random Forest': RandomForestClassifier(random_state=42, class_weight='balanced'),
                'Logistic Regression': LogisticRegression(random_state=42, class_weight='balanced', max_iter=1000),
                'XGBoost': xgb.XGBClassifier(random_state=42, eval_metric='logloss', use_label_encoder=False),
                'LightGBM': lgb.LGBMClassifier(random_state=42, verbose=-1),
                'SVM': SVC(random_state=42, probability=True),
                'KNN': KNeighborsClassifier(),
                'Naive Bayes': GaussianNB(),
                'Decision Tree': DecisionTreeClassifier(random_state=42, class_weight='balanced'),
                'AdaBoost': AdaBoostClassifier(random_state=42),
                'Gradient Boosting': GradientBoostingClassifier(random_state=42),
                'MLP': MLPClassifier(random_state=42, max_iter=300)
            }
            metric = 'f1_macro'
            scorer = lambda y_true, y_pred: f1_score(y_true, y_pred, average='macro')
            cv_scoring = 'f1_macro'
            ensemble_cls = VotingClassifier
            ensemble_voting = 'soft'
        else:
            base_models_all = {
                'Random Forest': RandomForestRegressor(random_state=42),
                'Linear Regression': LinearRegression(),
                'XGBoost': xgb.XGBRegressor(random_state=42),
                'LightGBM': lgb.LGBMRegressor(random_state=42, verbose=-1),
                'Ridge': Ridge(random_state=42),
                'Lasso': Lasso(random_state=42),
                'SVR': SVR(),
                'KNN': KNeighborsRegressor(),
                'Decision Tree': DecisionTreeRegressor(random_state=42),
                'MLP': MLPRegressor(random_state=42, max_iter=300)
            }
            metric = 'r2'
            scorer = r2_score
            cv_scoring = 'r2'
            ensemble_cls = VotingRegressor
            ensemble_voting = None

        # Specialize MLP configuration for fastpp-nn: early stopping + adaptive LR
        if mode == 'fastpp-nn':
            if self.is_classification:
                base_models_all['MLP'] = MLPClassifier(
                    random_state=42,
                    max_iter=2000,
                    early_stopping=True,
                    n_iter_no_change=20,
                    validation_fraction=0.15,
                    solver='sgd',
                    learning_rate='adaptive',
                    learning_rate_init=0.01,
                    momentum=0.9,
                    tol=1e-4
                )
            else:
                base_models_all['MLP'] = MLPRegressor(
                    random_state=42,
                    max_iter=2000,
                    early_stopping=True,
                    n_iter_no_change=20,
                    validation_fraction=0.15,
                    solver='sgd',
                    learning_rate='adaptive',
                    learning_rate_init=0.01,
                    momentum=0.9,
                    tol=1e-4
                )

        # Specialize XGBoost configuration for fastpp-xgb: optimized for speed and performance
        if mode == 'fastpp-xgb':
            if self.is_classification:
                base_models_all['XGBoost'] = xgb.XGBClassifier(
                    random_state=42,
                    eval_metric='logloss',
                    use_label_encoder=False,
                    n_estimators=200,  # Reasonable number for fast training
                    max_depth=6,
                    learning_rate=0.1,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    reg_alpha=0.1,
                    reg_lambda=1.0,
                    verbosity=0  # Suppress XGBoost output
                )
            else:
                base_models_all['XGBoost'] = xgb.XGBRegressor(
                    random_state=42,
                    n_estimators=200,  # Reasonable number for fast training
                    max_depth=6,
                    learning_rate=0.1,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    reg_alpha=0.1,
                    reg_lambda=1.0,
                    verbosity=0  # Suppress XGBoost output
                )

        if mode == 'fast++':
            selected_names = ['LightGBM']
        elif mode == 'fastpp-nn':
            selected_names = ['MLP']
        elif mode == 'fastpp-xgb':
            selected_names = ['XGBoost']
        elif mode == 'fast':
            selected_names = ['LightGBM', 'Random Forest', 'Logistic Regression' if self.is_classification else 'Linear Regression']
        else:
            selected_names = list(base_models_all.keys())
        param_grids = self.get_param_grids()

        # Wrap models in MultiOutput wrapper if needed
        if self.is_multi_output:
            wrapper_cls = MultiOutputClassifier if self.is_classification else MultiOutputRegressor
            for name in selected_names:
                base_models_all[name] = wrapper_cls(base_models_all[name])
                logger.info(f"Wrapped {name} in {wrapper_cls.__name__} for multi-output prediction")

        total_models = len(selected_names)
        logger.info(f"[TRAINING] Starting training of {total_models} model(s) in {mode} mode...")
        print(f"\n{'='*60}")
        print(f"[TRAINING MODE] {mode.upper()}")
        print(f"[INFO] Models to train: {total_models}")
        print(f"[TARGET] Task: {'Classification' if self.is_classification else 'Regression'}")
        print(f"[METRICS] Dataset size: {self.X_train.shape[0]:,} samples × {self.X_train.shape[1]} features")
        print(f"{'='*60}\n")

        for i, name in enumerate(selected_names, 1):
            base_model = base_models_all[name]
            try:
                # Progress indicator
                progress_bar = "█" * (i-1) + "░" * (total_models - i + 1)
                progress_pct = (i-1) / total_models * 100
                print(f"\n[{progress_bar}] {progress_pct:5.1f}% - Model {i}/{total_models}")
                print(f"[TRAINING] Training {name}...")
                
                logger.info(f"Training {name} ({i}/{len(selected_names)})...")
                if mode == 'fastpp-nn' and name == 'MLP':
                    import os
                    import psutil
                    
                    # Calculate optimal cores dynamically
                    dataset_size_mb = (self.X_train.nbytes + self.y_train.nbytes) / (1024 * 1024)
                    
                    if psutil:
                        available_memory_gb = psutil.virtual_memory().available / (1024**3)
                        max_safe_cores = min(4, int(available_memory_gb * 1024 / 200))  # 200MB per core safety margin
                    else:
                        # Fallback: conservative estimate without psutil
                        max_safe_cores = 2
                        available_memory_gb = "unknown"
                    
                    if dataset_size_mb > 100:  # Large dataset
                        max_cores = min(2, max_safe_cores)
                    elif dataset_size_mb > 50:   # Medium dataset  
                        max_cores = min(3, max_safe_cores)
                    else:                        # Small dataset
                        max_cores = min(4, max_safe_cores)
                        
                    max_cores = max(1, max_cores)
                    logger.info(f"Using {max_cores} cores for MLP (dataset: {dataset_size_mb:.1f}MB, available RAM: {available_memory_gb}GB)")
                    print(f"⚡ Using {max_cores} cores for MLP (dataset: {dataset_size_mb:.1f}MB, RAM: {available_memory_gb}GB)")
                elif mode == 'fastpp-xgb' and name == 'XGBoost':
                    import os
                    import psutil
                    
                    # Calculate optimal cores dynamically for XGBoost
                    dataset_size_mb = (self.X_train.nbytes + self.y_train.nbytes) / (1024 * 1024)
                    
                    if psutil:
                        available_memory_gb = psutil.virtual_memory().available / (1024**3)
                        max_safe_cores = min(6, int(available_memory_gb * 1024 / 150))  # 150MB per core for XGBoost
                    else:
                        max_safe_cores = 4
                        available_memory_gb = "unknown"
                    
                    # XGBoost is more memory efficient than MLP
                    if dataset_size_mb > 200:  # Very large dataset
                        max_cores = min(3, max_safe_cores)
                    elif dataset_size_mb > 100:  # Large dataset
                        max_cores = min(4, max_safe_cores)
                    elif dataset_size_mb > 50:   # Medium dataset  
                        max_cores = min(5, max_safe_cores)
                    else:                        # Small dataset
                        max_cores = min(6, max_safe_cores)
                        
                    max_cores = max(1, max_cores)
                    logger.info(f"Using {max_cores} cores for XGBoost (dataset: {dataset_size_mb:.1f}MB, available RAM: {available_memory_gb}GB)")
                    print(f"⚡ Using {max_cores} cores for XGBoost (dataset: {dataset_size_mb:.1f}MB, RAM: {available_memory_gb}GB)")
                elif mode == 'exhaustive':
                    import os
                    import psutil
                    
                    # Calculate optimal cores dynamically for exhaustive mode
                    dataset_size_mb = (self.X_train.nbytes + self.y_train.nbytes) / (1024 * 1024)
                    
                    if psutil:
                        available_memory_gb = psutil.virtual_memory().available / (1024**3)
                        max_safe_cores = min(4, int(available_memory_gb * 1024 / 300))  # 300MB per core for exhaustive
                    else:
                        max_safe_cores = 2
                        available_memory_gb = "unknown"
                    
                    # Use fewer cores for larger datasets in exhaustive mode
                    if dataset_size_mb > 200:  # Very large dataset
                        max_cores = min(2, max_safe_cores)
                    elif dataset_size_mb > 100:  # Large dataset
                        max_cores = min(3, max_safe_cores)
                    else:                        # Medium/small dataset
                        max_cores = min(4, max_safe_cores)
                        
                    max_cores = max(1, max_cores)
                    logger.info(f"Using {max_cores} cores for {name} in exhaustive mode (dataset: {dataset_size_mb:.1f}MB, available RAM: {available_memory_gb}GB)")
                    print(f"[CONFIG] Using {max_cores} cores for {name} in exhaustive mode (dataset: {dataset_size_mb:.1f}MB, RAM: {available_memory_gb}GB)")
                
                start_time = time.time()
                print(f"[TIME] Starting training at {time.strftime('%H:%M:%S')}...")

                param_grid = param_grids.get(name, {})
                # Disable hyperparameter tuning for multi-output mode (not well supported by all models)
                if self.is_multi_output:
                    param_grid = {}
                    print(f"[CONFIG] Multi-output mode: using base model without hyperparameter tuning...")
                
                # Check if validation set exists for early stopping
                has_val_set = hasattr(self, 'X_val') and self.X_val is not None and len(self.X_val) > 0
                fit_params = {}
                
                # Configure early stopping for XGBoost and LightGBM if validation set exists
                # Note: Early stopping works best with base models; RandomizedSearchCV uses CV internally
                if has_val_set and (name == 'XGBoost' or name == 'LightGBM'):
                    if name == 'XGBoost':
                        if self.is_classification:
                            base_model = xgb.XGBClassifier(
                                random_state=42, 
                                eval_metric='logloss', 
                                use_label_encoder=False,
                                early_stopping_rounds=10
                            )
                        else:
                            base_model = xgb.XGBRegressor(
                                random_state=42,
                                early_stopping_rounds=10
                            )
                        fit_params = {
                            'eval_set': [(self.X_val, self.y_val)],
                            'verbose': False
                        }
                    elif name == 'LightGBM':
                        if self.is_classification:
                            base_model = lgb.LGBMClassifier(random_state=42, verbose=-1)
                        else:
                            base_model = lgb.LGBMRegressor(random_state=42, verbose=-1)
                        fit_params = {
                            'eval_set': [(self.X_val, self.y_val)],
                            'callbacks': [lgb.early_stopping(stopping_rounds=10), lgb.log_evaluation(0)]
                        }
                    print(f"[CONFIG] Early stopping enabled using validation set ({len(self.X_val)} samples)")
                    # Note: Early stopping may not work with RandomizedSearchCV (it uses CV internally)
                    if param_grid:
                        print(f"   [WARNING] Note: Early stopping works best without hyperparameter tuning")
                
                if param_grid:
                    print(f"🔍 Using RandomizedSearchCV with {self.random_search_iters} iterations...")
                    # Smart parallelization for MLP and XGBoost: use limited cores to balance memory vs speed
                    if mode == 'fastpp-nn' and name == 'MLP':
                        # Dynamic core allocation based on dataset size and available memory
                        import os
                        import psutil
                        
                        # Estimate memory requirements based on dataset size
                        dataset_size_mb = (self.X_train.nbytes + self.y_train.nbytes) / (1024 * 1024)
                        
                        # Conservative memory estimation: ~50MB per MLP model per core
                        available_memory_gb = psutil.virtual_memory().available / (1024**3)
                        max_safe_cores = min(4, int(available_memory_gb * 1024 / 200))  # 200MB per core safety margin
                        
                        # Use fewer cores for larger datasets
                        if dataset_size_mb > 100:  # Large dataset
                            max_cores = min(2, max_safe_cores)
                        elif dataset_size_mb > 50:   # Medium dataset  
                            max_cores = min(3, max_safe_cores)
                        else:                        # Small dataset
                            max_cores = min(4, max_safe_cores)
                            
                        n_jobs_param = max(1, max_cores)
                    elif mode == 'fastpp-xgb' and name == 'XGBoost':
                        # XGBoost can handle more parallelization than MLP but still needs some limits
                        import os
                        import psutil
                        
                        dataset_size_mb = (self.X_train.nbytes + self.y_train.nbytes) / (1024 * 1024)
                        
                        if psutil:
                            available_memory_gb = psutil.virtual_memory().available / (1024**3)
                            max_safe_cores = min(6, int(available_memory_gb * 1024 / 150))  # 150MB per core for XGBoost
                        else:
                            max_safe_cores = 4
                        
                        # XGBoost is more memory efficient than MLP
                        if dataset_size_mb > 200:  # Very large dataset
                            max_cores = min(3, max_safe_cores)
                        elif dataset_size_mb > 100:  # Large dataset
                            max_cores = min(4, max_safe_cores)
                        elif dataset_size_mb > 50:   # Medium dataset  
                            max_cores = min(5, max_safe_cores)
                        else:                        # Small dataset
                            max_cores = min(6, max_safe_cores)
                            
                        n_jobs_param = max(1, max_cores)
                    elif mode == 'exhaustive':
                        # For exhaustive mode, use conservative parallelization to prevent memory issues
                        import os
                        import psutil
                        
                        dataset_size_mb = (self.X_train.nbytes + self.y_train.nbytes) / (1024 * 1024)
                        
                        if psutil:
                            available_memory_gb = psutil.virtual_memory().available / (1024**3)
                            # Conservative memory estimation for exhaustive mode
                            max_safe_cores = min(4, int(available_memory_gb * 1024 / 300))  # 300MB per core for exhaustive
                        else:
                            max_safe_cores = 2
                        
                        # Use fewer cores for larger datasets in exhaustive mode
                        if dataset_size_mb > 200:  # Very large dataset
                            max_cores = min(2, max_safe_cores)
                        elif dataset_size_mb > 100:  # Large dataset
                            max_cores = min(3, max_safe_cores)
                        else:                        # Medium/small dataset
                            max_cores = min(4, max_safe_cores)
                            
                        n_jobs_param = max(1, max_cores)
                    else:
                        n_jobs_param = -1  # Use all cores for other models
                    
                    print(f"[CONFIG] Setting up RandomizedSearchCV (CV=5, n_jobs={n_jobs_param})...")
                    model = RandomizedSearchCV(
                        base_model,
                        param_distributions=param_grid,
                        n_iter=self.random_search_iters,
                        cv=5,
                        scoring=cv_scoring,
                        random_state=42,
                        n_jobs=n_jobs_param
                    )
                else:
                    print(f"[CONFIG] Using base model without hyperparameter tuning...")
                    model = base_model

                print(f"[TRAINING] Starting model training...")
                if fit_params:
                    model.fit(self.X_train, self.y_train, **fit_params)
                else:
                    model.fit(self.X_train, self.y_train)
                print(f"[OK] Model training completed!")
                
                print(f"[INFO] Evaluating model performance...")
                y_pred_test = model.predict(self.X_test)
                y_pred_train = model.predict(self.X_train)
                score = scorer(self.y_test, y_pred_test)
                score_train = scorer(self.y_train, y_pred_train)
                
                # Calculate validation metrics if validation set exists
                score_val = None
                y_pred_val = None
                if has_val_set:
                    y_pred_val = model.predict(self.X_val)
                    score_val = scorer(self.y_val, y_pred_val)
                    print(f"[METRICS] Validation {metric}: {score_val:.4f}")

                if isinstance(model, RandomizedSearchCV):
                    print(f"[METRICS] Calculating cross-validation scores from RandomizedSearchCV...")
                    cv_mean = np.mean(model.cv_results_['mean_test_score'])
                    cv_std = np.std(model.cv_results_['mean_test_score'])
                else:
                    try:
                        print(f"🔄 Running cross-validation (5-fold)...")
                        # Smart parallelization for MLP and XGBoost: use limited cores to balance memory vs speed
                        if mode == 'fastpp-nn' and name == 'MLP':
                            import os
                            import psutil
                            
                            # Dynamic core allocation based on dataset size and available memory
                            dataset_size_mb = (self.X_train.nbytes + self.y_train.nbytes) / (1024 * 1024)
                            
                            if psutil:
                                available_memory_gb = psutil.virtual_memory().available / (1024**3)
                                max_safe_cores = min(4, int(available_memory_gb * 1024 / 200))  # 200MB per core safety margin
                            else:
                                # Fallback: conservative estimate without psutil
                                max_safe_cores = 2
                            
                            # Use fewer cores for larger datasets
                            if dataset_size_mb > 100:  # Large dataset
                                max_cores = min(2, max_safe_cores)
                            elif dataset_size_mb > 50:   # Medium dataset  
                                max_cores = min(3, max_safe_cores)
                            else:                        # Small dataset
                                max_cores = min(4, max_safe_cores)
                                
                            n_jobs_param = max(1, max_cores)
                        elif mode == 'fastpp-xgb' and name == 'XGBoost':
                            import os
                            import psutil
                            
                            dataset_size_mb = (self.X_train.nbytes + self.y_train.nbytes) / (1024 * 1024)
                            
                            if psutil:
                                available_memory_gb = psutil.virtual_memory().available / (1024**3)
                                max_safe_cores = min(6, int(available_memory_gb * 1024 / 150))  # 150MB per core for XGBoost
                            else:
                                max_safe_cores = 4
                            
                            # XGBoost is more memory efficient than MLP
                            if dataset_size_mb > 200:  # Very large dataset
                                max_cores = min(3, max_safe_cores)
                            elif dataset_size_mb > 100:  # Large dataset
                                max_cores = min(4, max_safe_cores)
                            elif dataset_size_mb > 50:   # Medium dataset  
                                max_cores = min(5, max_safe_cores)
                            else:                        # Small dataset
                                max_cores = min(6, max_safe_cores)
                                
                            n_jobs_param = max(1, max_cores)
                        elif mode == 'exhaustive':
                            # For exhaustive mode, use conservative parallelization to prevent memory issues
                            import os
                            import psutil
                            
                            dataset_size_mb = (self.X_train.nbytes + self.y_train.nbytes) / (1024 * 1024)
                            
                            if psutil:
                                available_memory_gb = psutil.virtual_memory().available / (1024**3)
                                # Conservative memory estimation for exhaustive mode
                                max_safe_cores = min(4, int(available_memory_gb * 1024 / 300))  # 300MB per core for exhaustive
                            else:
                                max_safe_cores = 2
                            
                            # Use fewer cores for larger datasets in exhaustive mode
                            if dataset_size_mb > 200:  # Very large dataset
                                max_cores = min(2, max_safe_cores)
                            elif dataset_size_mb > 100:  # Large dataset
                                max_cores = min(3, max_safe_cores)
                            else:                        # Medium/small dataset
                                max_cores = min(4, max_safe_cores)
                                
                            n_jobs_param = max(1, max_cores)
                        else:
                            n_jobs_param = -1  # Use all cores for other models
                        cv_scores = cross_val_score(model, self.X_train, self.y_train, cv=5, scoring=cv_scoring, n_jobs=n_jobs_param)
                        cv_mean = cv_scores.mean()
                        cv_std = cv_scores.std()
                    except Exception:
                        cv_mean = None
                        cv_std = None

                fit_time = time.time() - start_time
                print(f"[TIME] Total training time: {fit_time:.1f} seconds")

                self.models[name] = model
                self.results[name] = {
                    metric: score,  # Test metric
                    f'{metric}_train': score_train,  # Training metric
                    'cv_mean': float(cv_mean) if cv_mean is not None else None,
                    'cv_std': float(cv_std) if cv_std is not None else None,
                    'fit_time_sec': fit_time
                }
                # Add validation metrics if validation set exists
                if has_val_set and score_val is not None:
                    self.results[name][f'{metric}_val'] = score_val

                if hasattr(model, 'best_estimator_'):
                    estimator = model.best_estimator_
                else:
                    estimator = model
                fi = self._extract_feature_importance(estimator, name)
                if fi is not None:
                    self.feature_importance[name] = fi

                if self.is_classification:
                    acc_test = accuracy_score(self.y_test, y_pred_test)
                    acc_train = accuracy_score(self.y_train, y_pred_train)
                    f1_train = f1_score(self.y_train, y_pred_train, average='macro')
                    
                    # Calculate validation metrics if validation set exists
                    acc_val = None
                    f1_val = None
                    if has_val_set:
                        acc_val = accuracy_score(self.y_val, y_pred_val)
                        f1_val = f1_score(self.y_val, y_pred_val, average='macro')
                    
                    # Add training metrics to results dictionary
                    self.results[name]['accuracy'] = acc_test
                    self.results[name]['accuracy_train'] = acc_train
                    self.results[name]['f1_macro_train'] = f1_train
                    if has_val_set:
                        self.results[name]['accuracy_val'] = acc_val
                        self.results[name]['f1_macro_val'] = f1_val
                    
                    logger.info(f"{name}: F1 (macro) = {score:.4f}, Accuracy = {acc_test:.4f}, CV mean = {cv_mean:.4f} (+/- {cv_std * 2 if cv_std is not None else 'NA'}), time = {fit_time:.1f}s")
                    secondary = {
                        'accuracy': acc_test,
                        'accuracy_train': acc_train,
                        'f1_macro_train': f1_train
                    }
                    if has_val_set:
                        secondary['accuracy_val'] = acc_val
                        secondary['f1_macro_val'] = f1_val
                    
                    # Pretty print results
                    print(f"\n[SUCCESS] {name} Results:")
                    print(f"   [INFO] Test Metrics:")
                    print(f"      F1 Score (macro): {score:.4f}")
                    print(f"      Accuracy: {acc_test:.4f}")
                    if has_val_set:
                        print(f"   [OK] Validation Metrics:")
                        print(f"      F1 Score (macro): {f1_val:.4f}")
                        print(f"      Accuracy: {acc_val:.4f}")
                    print(f"   [TRAIN] Training Metrics:")
                    print(f"      F1 Score (macro): {f1_train:.4f}")
                    print(f"      Accuracy: {acc_train:.4f}")
                    print(f"   [METRICS] CV Mean: {cv_mean:.4f} ± {cv_std:.4f}" if cv_std is not None else f"   [METRICS] CV Mean: {cv_mean:.4f}")
                    print(f"   [TIME] Training Time: {fit_time:.1f}s")
                else:
                    mse_test = mean_squared_error(self.y_test, y_pred_test)
                    mse_train = mean_squared_error(self.y_train, y_pred_train)
                    r2_train = r2_score(self.y_train, y_pred_train)
                    
                    # Calculate validation metrics if validation set exists
                    mse_val = None
                    r2_val = None
                    if has_val_set:
                        mse_val = mean_squared_error(self.y_val, y_pred_val)
                        r2_val = r2_score(self.y_val, y_pred_val)
                    
                    # Add training metrics to results dictionary
                    self.results[name]['mse'] = mse_test
                    self.results[name]['mse_train'] = mse_train
                    self.results[name]['r2_train'] = r2_train
                    if has_val_set:
                        self.results[name]['mse_val'] = mse_val
                        self.results[name]['r2_val'] = r2_val
                    
                    logger.info(f"{name}: R² = {score:.4f}, MSE = {mse_test:.4f}, CV mean = {cv_mean:.4f} (+/- {cv_std * 2 if cv_std is not None else 'NA'}), time = {fit_time:.1f}s")
                    secondary = {
                        'mse': mse_test,
                        'mse_train': mse_train,
                        'r2_train': r2_train
                    }
                    if has_val_set:
                        secondary['mse_val'] = mse_val
                        secondary['r2_val'] = r2_val
                    
                    # Pretty print results
                    print(f"\n[SUCCESS] {name} Results:")
                    print(f"   [INFO] Test Metrics:")
                    print(f"      R² Score: {score:.4f}")
                    print(f"      MSE: {mse_test:.4f}")
                    if has_val_set:
                        print(f"   [OK] Validation Metrics:")
                        print(f"      R² Score: {r2_val:.4f}")
                        print(f"      MSE: {mse_val:.4f}")
                    print(f"   [TRAIN] Training Metrics:")
                    print(f"      R² Score: {r2_train:.4f}")
                    print(f"      MSE: {mse_train:.4f}")
                    print(f"   [METRICS] CV Mean: {cv_mean:.4f} ± {cv_std:.4f}" if cv_std is not None else f"   [METRICS] CV Mean: {cv_mean:.4f}")
                    print(f"   [TIME] Training Time: {fit_time:.1f}s")

                row = {
                    'model': name,
                    metric: float(score) if score is not None else None,
                    'cv_mean': float(cv_mean) if cv_mean is not None else None,
                    'cv_std': float(cv_std) if cv_std is not None else None,
                    'fit_time_sec': fit_time
                }
                row.update(secondary)
                self.comparison_table.append(row)

            except Exception as e:
                logger.error(f"Error training {name}: {e}")
                print(f"[ERROR] Error training {name}: {e}")

        # Final progress indicator
        final_progress_bar = "█" * total_models
        print(f"\n[{final_progress_bar}] 100.0% - All models completed!")
        print(f"{'='*60}")
        print(f"[DONE] TRAINING COMPLETED!")
        print(f"[INFO] Successfully trained: {len(self.models)}/{total_models} models")
        print(f"{'='*60}\n")

        if mode not in ('fast++', 'fastpp-nn', 'fastpp-xgb'):
            # Enhanced ensemble training with multiple strategies
            print(f"\n[TARGET] Training ensemble models...")
            logger.info("Training ensemble models...")
            
            # Sort all models by performance
            all_models_sorted = sorted(self.results.items(), key=lambda x: x[1][metric], reverse=True)
            top_models = all_models_sorted[:3]
            
            if len(top_models) > 1:
                print(f"   [INFO] Available models: {len(all_models_sorted)}")
                print(f"   [INFO] Top 3 models: {[name for name, _ in top_models]}")
                
                # Strategy 1: Top 3 Ensemble
                print(f"\n   [INFO] Strategy 1: Top 3 Ensemble")
                try:
                    estimators = [(name, self.models[name].best_estimator_ if hasattr(self.models[name], 'best_estimator_') else self.models[name]) for name, _ in top_models]
                    ensemble = ensemble_cls(estimators=estimators, voting=ensemble_voting) if self.is_classification else ensemble_cls(estimators=estimators)
                    
                    print(f"      [TRAINING] Fitting Top 3 ensemble...")
                    ensemble_start = time.time()
                    ensemble.fit(self.X_train, self.y_train)
                    ensemble_time = time.time() - ensemble_start
                    
                    print(f"      [INFO] Evaluating Top 3 ensemble...")
                    y_pred = ensemble.predict(self.X_test)
                    score = scorer(self.y_test, y_pred)
                    
                    self.models['Ensemble_Top3'] = ensemble
                    self.results['Ensemble_Top3'] = {metric: score, 'cv_mean': None, 'cv_std': None, 'fit_time_sec': ensemble_time}
                    
                    if self.is_classification:
                        acc = accuracy_score(self.y_test, y_pred)
                        logger.info(f"Ensemble_Top3: F1 (macro) = {score:.4f}, Accuracy = {acc:.4f}")
                        self.comparison_table.append({'model': 'Ensemble_Top3', metric: score, 'accuracy': acc, 'cv_mean': None, 'cv_std': None, 'fit_time_sec': ensemble_time})
                        
                        print(f"      [SUCCESS] Top 3 Ensemble Results:")
                        print(f"         [INFO] F1 Score (macro): {score:.4f}")
                        print(f"         [TARGET] Accuracy: {acc:.4f}")
                        print(f"         [TIME] Training Time: {ensemble_time:.1f}s")
                    else:
                        mse = mean_squared_error(self.y_test, y_pred)
                        logger.info(f"Ensemble_Top3: R² = {score:.4f}, MSE = {mse:.4f}")
                        self.comparison_table.append({'model': 'Ensemble_Top3', metric: score, 'mse': mse, 'cv_mean': None, 'cv_std': None, 'fit_time_sec': ensemble_time})
                        
                        print(f"      [SUCCESS] Top 3 Ensemble Results:")
                        print(f"         [INFO] R² Score: {score:.4f}")
                        print(f"         [INFO] MSE: {mse:.4f}")
                        print(f"         [TIME] Training Time: {ensemble_time:.1f}s")
                except Exception as e:
                    logger.warning(f"Top 3 ensemble failed: {e}")
                    print(f"      [ERROR] Top 3 ensemble failed: {e}")
                
                # Strategy 2: All Models Ensemble (if we have more than 3 models)
                if len(all_models_sorted) > 3:
                    print(f"\n   [INFO] Strategy 2: All Models Ensemble ({len(all_models_sorted)} models)")
                    try:
                        # Use all models for ensemble
                        all_estimators = [(name, self.models[name].best_estimator_ if hasattr(self.models[name], 'best_estimator_') else self.models[name]) for name, _ in all_models_sorted]
                        all_ensemble = ensemble_cls(estimators=all_estimators, voting=ensemble_voting) if self.is_classification else ensemble_cls(estimators=all_estimators)
                        
                        print(f"      [TRAINING] Fitting All Models ensemble...")
                        all_ensemble_start = time.time()
                        all_ensemble.fit(self.X_train, self.y_train)
                        all_ensemble_time = time.time() - all_ensemble_start
                        
                        print(f"      [INFO] Evaluating All Models ensemble...")
                        y_pred_all = all_ensemble.predict(self.X_test)
                        score_all = scorer(self.y_test, y_pred_all)
                        
                        self.models['Ensemble_All'] = all_ensemble
                        self.results['Ensemble_All'] = {metric: score_all, 'cv_mean': None, 'cv_std': None, 'fit_time_sec': all_ensemble_time}
                        
                        if self.is_classification:
                            acc_all = accuracy_score(self.y_test, y_pred_all)
                            logger.info(f"Ensemble_All: F1 (macro) = {score_all:.4f}, Accuracy = {acc_all:.4f}")
                            self.comparison_table.append({'model': 'Ensemble_All', metric: score_all, 'accuracy': acc_all, 'cv_mean': None, 'cv_std': None, 'fit_time_sec': all_ensemble_time})
                            
                            print(f"      [SUCCESS] All Models Ensemble Results:")
                            print(f"         [INFO] F1 Score (macro): {score_all:.4f}")
                            print(f"         [TARGET] Accuracy: {acc_all:.4f}")
                            print(f"         [TIME] Training Time: {all_ensemble_time:.1f}s")
                        else:
                            mse_all = mean_squared_error(self.y_test, y_pred_all)
                            logger.info(f"Ensemble_All: R² = {score_all:.4f}, MSE = {mse_all:.4f}")
                            self.comparison_table.append({'model': 'Ensemble_All', metric: score_all, 'mse': mse_all, 'cv_mean': None, 'cv_std': None, 'fit_time_sec': all_ensemble_time})
                            
                            print(f"      [SUCCESS] All Models Ensemble Results:")
                            print(f"         [INFO] R² Score: {score_all:.4f}")
                            print(f"         [INFO] MSE: {mse_all:.4f}")
                            print(f"         [TIME] Training Time: {all_ensemble_time:.1f}s")
                    except Exception as e:
                        logger.warning(f"All models ensemble failed: {e}")
                        print(f"      [ERROR] All models ensemble failed: {e}")
                
                # Strategy 3: Weighted Ensemble (best 5 models with weights based on performance)
                if len(all_models_sorted) >= 5:
                    print(f"\n   [INFO] Strategy 3: Weighted Ensemble (Top 5 models)")
                    try:
                        top5_models = all_models_sorted[:5]
                        top5_estimators = [(name, self.models[name].best_estimator_ if hasattr(self.models[name], 'best_estimator_') else self.models[name]) for name, _ in top5_models]
                        
                        # Create weights based on performance (higher score = higher weight)
                        weights = [result[metric] for _, result in top5_models]
                        # Normalize weights to sum to 1
                        total_weight = sum(weights)
                        weights = [w/total_weight for w in weights]
                        
                        # For classification, use soft voting with weights
                        if self.is_classification:
                            weighted_ensemble = ensemble_cls(estimators=top5_estimators, voting='soft', weights=weights)
                        else:
                            # For regression, we need to use VotingRegressor with weights
                            weighted_ensemble = ensemble_cls(estimators=top5_estimators, weights=weights)
                        
                        print(f"      [TRAINING] Fitting Weighted ensemble...")
                        print(f"      [INFO] Model weights: {[f'{name}: {w:.3f}' for (name, _), w in zip(top5_estimators, weights)]}")
                        weighted_ensemble_start = time.time()
                        weighted_ensemble.fit(self.X_train, self.y_train)
                        weighted_ensemble_time = time.time() - weighted_ensemble_start
                        
                        print(f"      [INFO] Evaluating Weighted ensemble...")
                        y_pred_weighted = weighted_ensemble.predict(self.X_test)
                        score_weighted = scorer(self.y_test, y_pred_weighted)
                        
                        self.models['Ensemble_Weighted'] = weighted_ensemble
                        self.results['Ensemble_Weighted'] = {metric: score_weighted, 'cv_mean': None, 'cv_std': None, 'fit_time_sec': weighted_ensemble_time}
                        
                        if self.is_classification:
                            acc_weighted = accuracy_score(self.y_test, y_pred_weighted)
                            logger.info(f"Ensemble_Weighted: F1 (macro) = {score_weighted:.4f}, Accuracy = {acc_weighted:.4f}")
                            self.comparison_table.append({'model': 'Ensemble_Weighted', metric: score_weighted, 'accuracy': acc_weighted, 'cv_mean': None, 'cv_std': None, 'fit_time_sec': weighted_ensemble_time})
                            
                            print(f"      [SUCCESS] Weighted Ensemble Results:")
                            print(f"         [INFO] F1 Score (macro): {score_weighted:.4f}")
                            print(f"         [TARGET] Accuracy: {acc_weighted:.4f}")
                            print(f"         [TIME] Training Time: {weighted_ensemble_time:.1f}s")
                        else:
                            mse_weighted = mean_squared_error(self.y_test, y_pred_weighted)
                            logger.info(f"Ensemble_Weighted: R² = {score_weighted:.4f}, MSE = {mse_weighted:.4f}")
                            self.comparison_table.append({'model': 'Ensemble_Weighted', metric: score_weighted, 'mse': mse_weighted, 'cv_mean': None, 'cv_std': None, 'fit_time_sec': weighted_ensemble_time})
                            
                            print(f"      [SUCCESS] Weighted Ensemble Results:")
                            print(f"         [INFO] R² Score: {score_weighted:.4f}")
                            print(f"         [INFO] MSE: {mse_weighted:.4f}")
                            print(f"         [TIME] Training Time: {weighted_ensemble_time:.1f}s")
                    except Exception as e:
                        logger.warning(f"Weighted ensemble failed: {e}")
                        print(f"      [ERROR] Weighted ensemble failed: {e}")
                
                print(f"\n[INFO] Ensemble Summary:")
                ensemble_models = [name for name in self.results.keys() if 'Ensemble' in name]
                for ensemble_name in ensemble_models:
                    ensemble_score = self.results[ensemble_name][metric]
                    print(f"   {ensemble_name}: {ensemble_score:.4f}")
            else:
                print(f"   [WARNING] Not enough models trained for ensemble (need at least 2)")

    def get_best_model(self):
        if not self.results:
            return None, None
        metric = 'f1_macro' if self.is_classification else 'r2'
        try:
            return max(self.results.items(), key=lambda x: x[1].get(metric, -np.inf))
        except Exception:
            return None, None

    def save_preprocessing(self, output_path):
        output_path = Path(output_path)
        output_path.mkdir(parents=True, exist_ok=True)

        if self.scaler is not None:
            joblib.dump(self.scaler, output_path / "scaler.joblib")
        if self.imputer is not None:
            joblib.dump(self.imputer, output_path / "imputer.joblib")
        if self.selector is not None:
            joblib.dump(self.selector, output_path / "selector.joblib")

        artifacts = {
            'cat_mappings': self.cat_mappings,
            'cat_fallbacks': self.cat_fallbacks,
            'original_feature_names': self.original_feature_names,
            'feature_names': self.feature_names,
            'outlier_caps': self.outlier_caps,
            'boxcox_lambda': self.boxcox_lambda,
            'target_column': self.target_column,
            'target_columns': self.target_columns,
            'is_multi_output': self.is_multi_output,
            'is_classification': self.is_classification,
            'eda_insights': self.eda_insights
        }
        joblib.dump(artifacts, output_path / "preprocessing_artifacts.joblib")

        with open(output_path / "preprocessing_metadata.json", "w") as f:
            json.dump(artifacts, f, indent=4, default=convert_numpy_types)

        logger.info(f"Preprocessing artifacts saved to {output_path}")

    def load_preprocessing(self, model_dir):
        model_dir = Path(model_dir)
        artifacts = joblib.load(model_dir / "preprocessing_artifacts.joblib")
        self.cat_mappings = artifacts.get('cat_mappings', {})
        self.cat_fallbacks = artifacts.get('cat_fallbacks', {})
        self.original_feature_names = artifacts.get('original_feature_names', None)
        self.feature_names = artifacts.get('feature_names', None)
        self.outlier_caps = artifacts.get('outlier_caps', {})
        self.boxcox_lambda = artifacts.get('boxcox_lambda', 0.15)
        self.eda_insights = artifacts.get('eda_insights', None)
        self.target_columns = artifacts.get('target_columns', None)
        self.is_multi_output = artifacts.get('is_multi_output', False)

        try:
            self.scaler = joblib.load(model_dir / "scaler.joblib")
        except Exception:
            self.scaler = None
        try:
            self.imputer = joblib.load(model_dir / "imputer.joblib")
        except Exception:
            self.imputer = None
        try:
            self.selector = joblib.load(model_dir / "selector.joblib")
        except Exception:
            self.selector = None

        # load label encoder if present
        try:
            self.label_encoder = joblib.load(model_dir / "label_encoder.joblib")
        except Exception:
            self.label_encoder = None

        logger.info(f"Loaded preprocessing artifacts from {model_dir}")

    def apply_preprocessing_for_inference(self, df_raw):
        df = df_raw.copy()

        # Use eda_insights to apply exact same transforms
        eda = self.eda_insights or {}

        # 1) Apply Box-Cox on the same features (if present)
        for col in eda.get('features_to_transform', []):
            if col in df.columns:
                try:
                    df[col] = boxcox1p(df[col].clip(0), self.boxcox_lambda)
                except Exception:
                    pass

        # 2) Apply outlier caps (exact caps computed at training)
        for col, caps in self.outlier_caps.items():
            if col in df.columns:
                min_cap, max_cap = caps
                df[col] = df[col].clip(min_cap, max_cap)

        # 3) Numeric imputation with saved imputer (apply only to numeric columns present)
        num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        if self.imputer is not None and len(num_cols) > 0:
            cols = [c for c in num_cols if c in df.columns]
            if cols:
                try:
                    df[cols] = self.imputer.transform(df[cols])
                except Exception:
                    # fallback to simple fills if imputer transform fails
                    for c in cols:
                        df[c] = df[c].fillna(df[c].median())

        # 4) Categorical mapping using saved mappings and fallbacks
        for col, mapping in self.cat_mappings.items():
            if col in df.columns:
                df[col] = df[col].astype(str).map(mapping)
                df[col] = df[col].fillna(self.cat_fallbacks.get(col))

        # 5) Make sure all training features exist in test; if missing, add with zeros
        if self.original_feature_names:
            for c in self.original_feature_names:
                if c not in df.columns:
                    df[c] = 0

        # 6) Reorder to original training order
        if self.original_feature_names:
            X = df[self.original_feature_names]
        else:
            X = df

        # 7) Scale then select (matches training order: scale -> selector)
        if self.scaler is not None:
            X_scaled = self.scaler.transform(X)
        else:
            X_scaled = X.values

        if self.selector is not None:
            X_selected = self.selector.transform(X_scaled)
            return X_selected
        else:
            return X_scaled

    def save_best_model(self, output_dir='models'):
        best = self.get_best_model()
        if best is None or best[0] is None:
            raise ValueError("No models trained")

        best_name, best_results = best
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output_path = Path(output_dir) / f"best_model_{timestamp}"
        output_path.mkdir(parents=True, exist_ok=True)

        model_path = output_path / "model.joblib"
        joblib.dump(self.models[best_name], model_path)

        if self.scaler is not None:
            joblib.dump(self.scaler, output_path / "scaler.joblib")
        if self.label_encoder is not None:
            joblib.dump(self.label_encoder, output_path / "label_encoder.joblib")

        if best_name in self.feature_importance:
            fi_path = output_path / "feature_importance.npy"
            np.save(fi_path, np.array(self.feature_importance[best_name]))

        metadata = {
            'model_name': best_name,
            'target_column': self.target_column,
            'target_columns': self.target_columns,
            'is_multi_output': self.is_multi_output,
            'is_classification': self.is_classification,
            'feature_names': self.feature_names,
            'performance': best_results,
            'eda_insights': self.eda_insights
        }
        with open(output_path / "metadata.json", 'w') as f:
            json.dump(metadata, f, indent=4, default=convert_numpy_types)

        # save preprocessing artifacts for inference (includes eda_insights)
        self.save_preprocessing(output_path)

        if len(self.comparison_table) > 0:
            comp_df = pd.DataFrame(self.comparison_table)
            comp_df.to_csv(output_path / "comparison_table.csv", index=False)
            logger.info("\nComparative table across models:")
            metric_col = list(comp_df.columns[1:2])[0] if comp_df.shape[1] > 1 else comp_df.columns[0]
            logger.info(comp_df.sort_values(by=[metric_col], ascending=False).to_string(index=False))

        logger.info(f"Best model saved to {output_path}")
        return str(output_path)

def main():
    # Initial memory cleanup and logging
    cleanup_memory()
    log_memory_usage("at startup")
    
    parser = argparse.ArgumentParser(description="Train ML models on tabular CSV (enhanced)")
    parser.add_argument("train_csv", help="Path to train.csv")
    parser.add_argument("--target", help="Target column name(s) - single column or comma-separated list for multi-output (default: auto-detect)")
    parser.add_argument("--task", choices=['classification', 'regression'], help="Task type: classification or regression (default: auto-detect)")
    parser.add_argument("--downsample", action="store_true", help="Downsample to 100k rows")
    parser.add_argument("--no-stratify", action="store_true", help="Disable stratification for classification")
    parser.add_argument("--drop-columns", type=str, default="", help="Comma-separated list of columns to drop")
    parser.add_argument("--sample-eda", action="store_true", help="Force sampling for EDA (useful for very large datasets)")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--fast", action="store_true", help="Fast mode: only run LightGBM + 2 others")
    group.add_argument("--fastpp", action="store_true", help="Fast++ mode: only run LightGBM with 5 randomized CV iterations")
    group.add_argument("--fastpp-nn", action="store_true", help="Fast++-NN mode: only run MLP with early stopping and adaptive LR (5 CV iters)")
    group.add_argument("--fastpp-xgb", action="store_true", help="Fast++-XGB mode: only run XGBoost with optimized settings and early stopping (5 CV iters)")
    group.add_argument("--exhaustive", action="store_true", help="Exhaustive mode: run all models (default)")
    args = parser.parse_args()

    if args.fastpp:
        mode = 'fast++'
        random_search_iters = 5
    elif args.fastpp_nn:
        mode = 'fastpp-nn'
        random_search_iters = 5
    elif args.fastpp_xgb:
        mode = 'fastpp-xgb'
        random_search_iters = 5
    elif args.fast:
        mode = 'fast'
        random_search_iters = 5
    else:
        mode = 'exhaustive'
        random_search_iters = 5

    analyzer = TabularDataAnalyzer(random_search_iters=random_search_iters)

    # Parse target column(s) - support comma-separated list for multi-output
    target_column = None
    if args.target:
        if ',' in args.target:
            target_column = [t.strip() for t in args.target.split(',')]
            logger.info(f"Multi-output mode with targets: {target_column}")
        else:
            target_column = args.target

    logger.info("Loading data...")
    if not analyzer.load_data(args.train_csv, downsample=args.downsample, target_column=target_column):
        logger.error("Failed to load data")
        return

    # Cleanup after data loading
    cleanup_memory()
    log_memory_usage("after data loading")

    is_classification = args.task == 'classification' if args.task else None
    if is_classification is None:
        # For multi-output, use first target for task detection
        if analyzer.target_columns:
            target_col = analyzer.target_columns[0]
        else:
            target_col = analyzer.target_column or ('Cover_Type' if 'Cover_Type' in analyzer.data.columns else analyzer.data.columns[-1])
        
        if analyzer.data[target_col].dtype in ['object', 'category'] or analyzer.data[target_col].nunique() < 20:
            is_classification = True
            logger.info("Auto-detected task: classification")
        else:
            is_classification = False
            logger.info("Auto-detected task: regression")

    # For EDA, use first target if multi-output
    eda_target = analyzer.target_columns[0] if analyzer.target_columns else (analyzer.target_column or target_column)
    eda_insights = analyzer.perform_eda(target_column=eda_target, force_sample=args.sample_eda)

    logger.info("Preprocessing data...")
    analyzer.preprocess_data(
        target_column=target_column,
        is_classification=is_classification,
        stratify=not args.no_stratify,
        drop_columns=args.drop_columns,
        eda_insights=eda_insights
    )
    
    # Cleanup after preprocessing
    cleanup_memory()
    log_memory_usage("after preprocessing")

    logger.info(f"Training models (mode={mode})...")
    analyzer.train_models(mode=mode)

    logger.info("Saving best model and comparison table...")
    try:
        save_path = analyzer.save_best_model()
        logger.info(f"Done! Best model saved to {save_path}")
    except Exception as e:
        logger.error(f"Error saving model: {e}")

if __name__ == "__main__":
    main()
