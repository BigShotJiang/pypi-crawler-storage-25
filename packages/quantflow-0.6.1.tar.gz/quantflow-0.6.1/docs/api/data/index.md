# Data fetching


The `quantflow.data` module provides classes and functions for fetching data from various sources.
To use the module the package must be installed with the optional `data` extra.
```
pip install quantflow[data]
```
