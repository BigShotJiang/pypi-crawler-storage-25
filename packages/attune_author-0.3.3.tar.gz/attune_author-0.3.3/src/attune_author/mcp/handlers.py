"""MCP tool handlers for attune-author.

Each handler validates inputs (especially paths), calls the
relevant attune-author library function, and returns a uniform
{"success": bool, ...} dict.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from attune_author.mcp.path_validation import validate_file_path

logger = logging.getLogger(__name__)


class _PathValidationError(Exception):
    """Internal marker for path-validation failures.

    Carries the pre-formatted error dict that the caller
    returns directly, so handlers don't repeat the same
    try/except/return-error-dict scaffold for every field.
    """

    def __init__(self, error_dict: dict[str, Any]) -> None:
        super().__init__(error_dict.get("error", ""))
        self.error_dict = error_dict


class AttuneAuthorHandlers:
    """Async handlers for the 6 attune-author MCP tools.

    Holds workspace_root for path containment so user input
    cannot escape the project directory.
    """

    def __init__(self, workspace_root: str) -> None:
        """Initialize with a pinned workspace root.

        Args:
            workspace_root: Absolute path used to constrain
                all file operations.
        """
        self._workspace_root = workspace_root

    def _validated_paths(
        self,
        args: dict[str, Any],
        fields: dict[str, str],
    ) -> dict[str, Path]:
        """Validate a batch of path fields against workspace root.

        Args:
            args: Raw MCP tool arguments.
            fields: Mapping of ``field_name -> default_value``
                for each path argument that must be validated
                and pinned to the workspace root.

        Returns:
            Mapping of ``field_name -> resolved Path``.

        Raises:
            _PathValidationError: If any field fails validation.
                The carried error dict is shaped so the handler
                can return it directly to the MCP caller.
        """
        resolved: dict[str, Path] = {}
        for name, default in fields.items():
            try:
                resolved[name] = validate_file_path(
                    args.get(name, default),
                    allowed_dir=self._workspace_root,
                )
            except ValueError as e:
                raise _PathValidationError({"success": False, "error": str(e)}) from e
        return resolved

    async def author_init(self, args: dict[str, Any]) -> dict[str, Any]:
        """Bootstrap a .help/ directory with discovered features."""
        from attune_author.bootstrap import (
            proposals_to_manifest,
            scan_project,
        )
        from attune_author.manifest import save_manifest

        try:
            paths = self._validated_paths(args, {"project_root": "."})
        except _PathValidationError as e:
            return e.error_dict
        project_root = paths["project_root"]

        help_dir = project_root / ".help"
        if (help_dir / "features.yaml").exists():
            return {
                "success": True,
                "already_initialized": True,
                "manifest_path": str(help_dir / "features.yaml"),
                "message": f"Already initialized at {help_dir / 'features.yaml'}",
            }

        proposals = scan_project(project_root)
        if not proposals:
            return {
                "success": True,
                "discovered": 0,
                "message": "No features discovered.",
            }

        manifest = proposals_to_manifest(proposals)
        manifest_path = save_manifest(manifest, help_dir)

        return {
            "success": True,
            "discovered": len(proposals),
            "manifest_path": str(manifest_path),
            "features": [
                {
                    "name": p.name,
                    "description": p.description,
                    "confidence": p.confidence,
                    "files": p.files,
                }
                for p in proposals
            ],
        }

    async def author_status(self, args: dict[str, Any]) -> dict[str, Any]:
        """Report stale features as a markdown table."""
        from attune_author.maintenance import format_status_report
        from attune_author.manifest import load_manifest
        from attune_author.staleness import check_staleness

        try:
            paths = self._validated_paths(args, {"help_dir": ".help", "project_root": "."})
        except _PathValidationError as e:
            return e.error_dict
        help_dir = paths["help_dir"]
        project_root = paths["project_root"]

        try:
            manifest = load_manifest(help_dir)
        except (FileNotFoundError, ValueError) as e:
            return {"success": False, "error": f"Cannot load manifest: {e}"}

        report = check_staleness(manifest, help_dir, project_root)

        return {
            "success": True,
            "stale_count": report.stale_count,
            "current_count": report.current_count,
            "stale_features": report.stale_features,
            "report": format_status_report(report, help_dir),
        }

    async def author_generate(self, args: dict[str, Any]) -> dict[str, Any]:
        """Generate templates for one feature."""
        from attune_author.generator import generate_feature_templates
        from attune_author.manifest import load_manifest

        feature_name = args.get("feature")
        if not feature_name:
            return {"success": False, "error": "feature name is required"}

        try:
            paths = self._validated_paths(args, {"help_dir": ".help", "project_root": "."})
        except _PathValidationError as e:
            return e.error_dict
        help_dir = paths["help_dir"]
        project_root = paths["project_root"]

        try:
            manifest = load_manifest(help_dir)
        except (FileNotFoundError, ValueError) as e:
            return {"success": False, "error": f"Cannot load manifest: {e}"}

        feature = manifest.features.get(feature_name)
        if not feature:
            return {
                "success": False,
                "error": (
                    f"Feature '{feature_name}' not in manifest. "
                    f"Available: {sorted(manifest.features)}"
                ),
            }

        try:
            result = generate_feature_templates(
                feature=feature,
                help_dir=help_dir,
                project_root=project_root,
                overwrite=bool(args.get("overwrite", False)),
            )
        except (ValueError, OSError) as e:
            return {"success": False, "error": str(e)}

        return {
            "success": True,
            "feature": result.feature,
            "generated": [{"depth": t.depth, "path": str(t.path)} for t in result.templates],
            "source_hash": result.source_hash,
            "matched_files": result.matched_files,
        }

    async def author_maintain(self, args: dict[str, Any]) -> dict[str, Any]:
        """Regenerate all stale features."""
        from attune_author.maintenance import run_maintenance

        try:
            paths = self._validated_paths(args, {"help_dir": ".help", "project_root": "."})
        except _PathValidationError as e:
            return e.error_dict
        help_dir = paths["help_dir"]
        project_root = paths["project_root"]

        features = args.get("features")
        dry_run = bool(args.get("dry_run", False))

        try:
            result = run_maintenance(
                help_dir=help_dir,
                project_root=project_root,
                features=features,
                dry_run=dry_run,
            )
        except (FileNotFoundError, ValueError) as e:
            return {"success": False, "error": str(e)}

        return {
            "success": True,
            "stale_count": result.stale_count,
            "regenerated_count": result.regenerated_count,
            "regenerated": [r.feature for r in result.regenerated],
            "failed": result.failed,
            "dry_run": dry_run,
        }

    async def author_docs(self, args: dict[str, Any]) -> dict[str, Any]:
        """Generate documentation via the 3-stage pipeline."""
        # INTENTIONAL: the doc_gen subpackage depends on the optional
        # `[ai]` extra. ImportError is the expected failure mode when
        # the extra is missing — return a helpful install hint rather
        # than crashing the MCP loop.
        try:
            from attune_author.doc_gen import DocGenConfig, generate_docs
        except ImportError:
            return {
                "success": False,
                "error": (
                    "Doc generation requires the [ai] extra: pip install 'attune-author[ai]'"
                ),
            }

        target = args.get("target")
        if not target:
            return {"success": False, "error": "target is required"}

        # If target is a file path, validate it
        target_path: str = target
        if Path(target).exists():
            try:
                validated = validate_file_path(target, allowed_dir=self._workspace_root)
                target_path = str(validated)
            except ValueError as e:
                return {"success": False, "error": str(e)}

        output_path: str | None = None
        if args.get("output_path"):
            try:
                # Validate the parent BEFORE creating it. The parent
                # may not exist yet, but we must reject paths outside
                # the workspace before mkdir() so we never materialize
                # a directory tree at an attacker-controlled location.
                out = Path(args["output_path"])
                validated_parent = validate_file_path(
                    str(out.parent), allowed_dir=self._workspace_root
                )
                validated_parent.mkdir(parents=True, exist_ok=True)
                output_path = str(validated_parent / out.name)
            except ValueError as e:
                return {"success": False, "error": str(e)}

        config = DocGenConfig(
            doc_type=args.get("doc_type", "api-reference"),
            audience=args.get("audience", "developers"),
        )

        try:
            result = generate_docs(
                target=target_path,
                config=config,
                output_path=output_path,
            )
        except (RuntimeError, FileNotFoundError) as e:
            return {"success": False, "error": str(e)}

        return {
            "success": True,
            "stages_completed": result.stages_completed,
            "source_path": result.source_path,
            "output_path": output_path,
            "content": result.content if not output_path else None,
            "content_length": len(result.content),
        }

    async def author_lookup(self, args: dict[str, Any]) -> dict[str, Any]:
        """Look up help for a topic by name or tag."""
        from attune_author.manifest import (
            is_safe_feature_name,
            load_manifest,
            resolve_topic,
        )

        query = args.get("query")
        if not query:
            return {"success": False, "error": "query is required"}

        depth = args.get("depth", "concept")
        if depth not in ("concept", "task", "reference"):
            return {
                "success": False,
                "error": f"depth must be concept|task|reference, got {depth}",
            }

        try:
            paths = self._validated_paths(args, {"help_dir": ".help"})
        except _PathValidationError as e:
            return e.error_dict
        help_dir = paths["help_dir"]

        try:
            manifest = load_manifest(help_dir)
        except (FileNotFoundError, ValueError) as e:
            return {"success": False, "error": f"Cannot load manifest: {e}"}

        feature_name = resolve_topic(query, manifest)
        if not feature_name:
            return {
                "success": False,
                "error": f"No feature matches query: {query}",
                "available": sorted(manifest.features),
            }

        # Defense in depth: load_manifest already validates names at
        # parse time, but the lookup path is the most security-sensitive
        # boundary so we re-check before joining onto the help dir.
        if not is_safe_feature_name(feature_name):
            return {"success": False, "error": f"Invalid feature name: {feature_name!r}"}

        template_path = help_dir / "templates" / feature_name / f"{depth}.md"
        if not template_path.exists():
            return {
                "success": False,
                "error": (
                    f"No {depth} template for '{feature_name}'. " f"Run author_generate first."
                ),
                "feature": feature_name,
            }

        try:
            content = template_path.read_text(encoding="utf-8")
        except OSError as e:
            return {"success": False, "error": f"Cannot read template: {e}"}

        return {
            "success": True,
            "feature": feature_name,
            "depth": depth,
            "path": str(template_path),
            "content": content,
        }
