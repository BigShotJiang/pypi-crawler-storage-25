"""
This module contains functions to handle label operations.
"""

import logging
import pickle

import numpy as np
import torch
from sklearn.preprocessing import MultiLabelBinarizer

logging.basicConfig(level=logging.INFO)


def get_from_df(genre_id, df_genres, output):
    """
    Recursively retrieves the ancestry of a given genre_id.

    Args:
        genre_id (int): The current genre ID.
        df_genres (pd.DataFrame): DataFrame containing genre hierarchy.
        output (list): The list being built up with the ancestry.

    Returns:
        list: List including this genre_id and its ancestors up to the root.
    """
    if genre_id != 0:
        parent_genre = df_genres[df_genres["genre_id"] == genre_id].parent.values[0]
        output.append(genre_id)
        get_from_df(parent_genre, df_genres, output=output)
    return output


def get_structure(genres_id, df_genres):
    """
    Retrieve the hierarchical structure (ancestry)
    of each genre_id from the DataFrame.

    Args:
        genres_id (list or iterable): List of genre IDs to
        retrieve the structure for.
        df_genres (pd.DataFrame): DataFrame containing the columns
        "genre_id" and "parent".
        It is expected that "parent" is the parent genre_id for each genre.

    Returns:
        list: A list where each element is a list of genre IDs representing
        the hierarchy (ancestry) for the corresponding genre_id in `genres_id`.
        Each list starts from the genre_id and recursively adds its parents
        up to the root (where parent is 0 or missing).
    """
    output_list = []
    for genre_id in genres_id:
        output_list.append(get_from_df(genre_id, df_genres, output=[]))
    return output_list


def group_labels_by_level(df, max_depth):
    """
    Groups hierarchical labels in the DataFrame by each level,
    up to the specified max_depth.

    Args:
        df (pd.DataFrame): DataFrame containing a column 'y_true',
        where each item is a list of
            hierarchical label lists per track.
        max_depth (int): Maximum number of hierarchy levels to consider.

    Returns:
        list: A list of length max_depth, where each element
        is a list of unique labels per example at that level.
    """
    # Initialize empty lists for each level based on max_depth
    levels = [[] for _ in range(max_depth)]

    # Iterate over each row in the DataFrame
    for _, row in df.iterrows():
        # Iterate over each level and append the labels to the corresponding list
        for level in range(max_depth):
            level_labels = []
            for label in row["y_true"]:
                if level < len(label):
                    level_labels.append(label[level])
            levels[level].append(list(set(level_labels)))

    # Return the grouped labels by level
    return levels


def binarize_labels(dataset_df, args):
    """
    Binarizes multi-level hierarchical labels in the dataset,
    using MultiLabelBinarizer per level.

    Args:
        dataset_df (pd.DataFrame): DataFrame containing 'y_true'
        column with hierarchical label lists.
        args (Namespace): Arguments namespace with:
            - max_depth (int): Maximum hierarchy depth.
            - mlb_path (str): Path to save the list of fitted
            MultiLabelBinarizer objects.

    Returns:
        pd.DataFrame: DataFrame with columns
        ['track_id', 'y_true', 'all_binarized'],
        where 'all_binarized' contains binarized label lists per level.
    """
    # Labels
    mlbs = []

    grouped_labels = group_labels_by_level(dataset_df, args.max_depth)

    labels_name = []
    for level, level_labels in enumerate(grouped_labels):
        labels_name.append(f"level{level + 1}")
        # Cria e aplica o MultiLabelBinarizer
        mlb = MultiLabelBinarizer()
        binary_labels = mlb.fit_transform(level_labels).tolist()

        mlbs.append(mlb)
        for i in range(len(dataset_df)):
            # Verifica se o índice está dentro do limite
            if i < len(binary_labels):
                # Adiciona os rótulos binarizados à lista
                binary_labels[i] = binary_labels[i]
            else:
                # Se o índice estiver fora do limite, adiciona uma lista vazia
                binary_labels[i] = [0] * len(mlb.classes_)

        dataset_df.loc[:, labels_name[level]] = binary_labels

    # Serializar a lista de mlb
    with open(args.mlb_path, "wb") as file:
        pickle.dump(mlbs, file)

    dataset_df["all_binarized"] = dataset_df.apply(lambda row: row[labels_name], axis=1)
    tracks_df = dataset_df[["track_id", "y_true", "all_binarized"]]
    return tracks_df


def local_to_global_predictions(
    local_labels,
    local_nodes_idx,
    nodes_idx,
    threshold=0.2,
):
    """
    Converts local-level predictions to global vectors of scores and binary predictions.

    This function processes local predictions and returns both the continuous scores and
    binarized predictions based on a threshold.
    Args:
        local_labels (list of np.ndarray): List where each element is an array of shape
                                           [n_samples, n_classes_at_level] containing
                                           local scores.
        local_nodes_idx (dict): Dictionary mapping level names to their local node indices.
        nodes_idx (dict): Dictionary mapping global node names to their global indices.
        threshold (float): The threshold to use for converting scores to binary
                           predictions (0 or 1). Default: 0.2.

    Returns:
        dict: A dictionary containing two arrays:
            - "global_scores" (np.ndarray): Matrix of shape [n_samples, n_global_labels]
                                          with the continuous scores.
            - "global_binary_preds" (np.ndarray): Matrix of shape [n_samples, n_global_labels]
                                                with the binary predictions (0 or 1).
    """
    if not local_labels:
        return {"global_scores": np.array([]), "global_binary_preds": np.array([])}

    # Initialize both output matrices
    output_values = {
        "global_scores": np.zeros((local_labels[0].shape[0], len(nodes_idx))),
        "global_binary_preds": np.zeros(
            (local_labels[0].shape[0], len(nodes_idx)), dtype=int
        ),
    }

    # Create a reverse mapping of local index to node name for easier lookup
    sorted_levels = sorted(local_nodes_idx.keys())
    local_nodes_reverse = {
        level: {v: k for k, v in local_nodes_idx[level].items()}
        for level in sorted_levels
    }

    logging.info(
        "Processing %d samples with threshold %f...",
        local_labels[0].shape[0],
        threshold,
    )

    # Iterate through each hierarchical level
    for level_index, level in enumerate(sorted_levels):
        for idx_example, sample_scores in enumerate(local_labels[level_index]):
            for local_idx in np.where(sample_scores > 0)[0]:
                if not local_nodes_reverse[level].get(local_idx):
                    continue

                key = local_nodes_reverse[level].get(local_idx).replace("/", ".")

                if nodes_idx.get(key) is None:
                    continue  # Warning for this may be too verbose

                # 1. Assign original score to scores matrix
                score = sample_scores[local_idx]
                output_values["global_scores"][idx_example, nodes_idx.get(key)] = score

                # 2. Binarize score and assign to binary predictions matrix
                if score >= threshold:
                    output_values["global_binary_preds"][
                        idx_example, nodes_idx.get(key)
                    ] = 1

    return output_values


def global_to_local_predictions(
    global_preds,
    local_nodes_idx,
    nodes_idx,
):
    """
    Parâmetros:
        global_preds: np.array [n_samples, n_global_labels] \
            - rótulos/predições globais binárias
        local_nodes_idx: dict[level_name] = dict[node_name_local \
            -> idx_local]
        nodes_idx: dict[node_name_global -> idx_global]
    Retorna:
        local_labels: lista np.array [n_samples, n_local_labels_por_nivel]
    """
    # Inverter nodes_idx: global_idx -> node_name
    idx_to_node = {v: k for k, v in nodes_idx.items()}
    sorted_levels = sorted(local_nodes_idx.keys())

    n_samples = global_preds.shape[0]

    local_labels = []
    for level in sorted_levels:
        n_classes_local = len(local_nodes_idx[level])
        lvl_preds = np.zeros((n_samples, n_classes_local))
        # Inverter local_nodes_idx[level]: node_name_local->idx_local

        for sample_idx in range(n_samples):
            # Quais globais estão ativados neste sample
            active_globals = np.where(global_preds[sample_idx] == 1)[0]
            for global_idx in active_globals:
                node_name_local = idx_to_node[global_idx]
                # Ajustar para nomes locais, se necessário
                # node_name_local = node_name.replace(".", "/")
                # Verifica se é nó deste nível
                if node_name_local in local_nodes_idx[level]:
                    local_idx = local_nodes_idx[level][node_name_local]
                    lvl_preds[sample_idx, local_idx] = 1
        local_labels.append(lvl_preds)
    return local_labels


def apply_hierarchy_consistency(outputs, args):
    """
    outputs: lista de tensores [batch, n_classes_nivel]
    args.r: torch.Tensor [n_classes_global, n_classes_global]
    args.hmc_dataset.level_class_indices: dict nivel → lista de índices globais das classes do nível
    """
    r = args.r.squeeze(0).to(args.device)
    new_outputs = {}
    num_levels = len(args.hmc_dataset.sorted_levels)
    pred_consist = outputs[0].to(args.device)  # nível 0 são raízes, nada para propagar

    new_outputs[args.hmc_dataset.sorted_levels[0]] = pred_consist

    for level_index in range(1, num_levels):
        level = args.hmc_dataset.sorted_levels[level_index]
        curr_preds = outputs[level_index].to(args.device)  # [batch, n_filhos]
        preds_bin = (curr_preds > 0.5).float()

        idx_ancestrais = torch.as_tensor(
            args.hmc_dataset.level_class_indices[
                args.hmc_dataset.sorted_levels[level_index - 1]
            ],
            dtype=torch.long,
            device=args.device,
        )
        idx_filhos = torch.as_tensor(
            args.hmc_dataset.level_class_indices[level],
            dtype=torch.long,
            device=args.device,
        )

        # Relação ancestralidade entre nível anterior e atual
        rel_ancestral = r[idx_ancestrais][
            :, idx_filhos
        ]  # shape: [n_ancestrais, n_filhos]

        # [batch, n_ancestrais] * [n_ancestrais, n_filhos] → [batch, n_filhos]
        # Determina para cada filho se algum ancestral foi ativado naquela amostra
        ancestral_active = torch.matmul(
            pred_consist.double(), rel_ancestral
        )  # [batch, n_filhos]

        # Apenas permite ativação de descendentes com ancestrais ativos
        # (batched AND lógico entre ancestrais ativos e predição do filho)
        pred_consist = preds_bin * (ancestral_active > 0).float()

        new_outputs[level] = pred_consist

    return new_outputs


def get_probs_ancestral_descendent(probs_nivel_ancestral, probs_nivel_desc, r_matrix):
    """
    probs_nivel_ancestral: Tensor [batch, n_ancestrais]
    probs_nivel_desc: Tensor [batch, n_descendentes]
    r_matrix: Tensor [n_ancestrais, n_descendentes] (binária: 1 se i é ancestral de j)
    """
    # Expande dimensões para broadcast
    # batch = probs_nivel_ancestral.shape[0]
    # n_ancestrais = probs_nivel_ancestral.shape[1]
    # n_desc = probs_nivel_desc.shape[1]

    probs_anc_exp = probs_nivel_ancestral.unsqueeze(2)  # [batch, n_ancestrais, 1]
    r_exp = r_matrix.unsqueeze(0)  # [1, n_ancestrais, n_descendentes]

    # Para cada descendente j, para cada sample, pegue probs do(s)
    # ancestral(is) i, se houver relação.
    masked_probs = torch.where(
        r_exp == 1, probs_anc_exp, float("-inf")
    )  # [batch, n_ancestrais, n_desc]

    # Máximo ancestral de cada descendente para cada sample
    prob_ancestral, _ = masked_probs.max(dim=1)
    prob_ancestral[prob_ancestral == float("-inf")] = (
        0  # se não houver ancestral assigna 0
    )

    prob_descendente = probs_nivel_desc  # [batch, n_descendentes]
    return prob_ancestral, prob_descendente


def hierarchy_regularization(outputs, g):
    """
    Penalize child probability > parent probability
    """
    penalty = 0.0
    for parent, child in g.edges():
        parent_probs = torch.sigmoid(outputs[parent[0]][:, parent[1]])
        child_probs = torch.sigmoid(outputs[child[0]][:, child[1]])

        penalty += torch.mean(torch.relu(child_probs - parent_probs))
    return penalty


def show_metrics(losses, scores):
    """
    Show metrics for losses and scores.

    Args:
        losses (list): List of local losses.
        scores (dict): Dictionary of local scores.
    """
    show_local_losses(losses)
    show_local_score(scores)


def show_local_losses(local_losses):
    """
    Logs the local (per-level) losses for a given dataset.

    Args:
        local_losses (list): A list containing the loss value for each
            hierarchy level.

    Returns:
        None
    """
    formatted_string = ""
    for level, local_loss in enumerate(local_losses):
        if local_loss is not None:
            formatted_string += f"level {level}: {local_loss:.4f} // "
    logging.info(formatted_string)


def show_global_loss(global_loss, dataset="Train"):
    """
    Logs the global (average) loss for a given dataset.

    Args:
        global_loss (float): The global loss value.
        dataset (str): The name of the dataset, e.g., "Train",
        "Validation", or "Test". Defaults to "Train".

    Returns:
        None
    """
    logging.info("Global average loss %s Loss: %s", dataset, global_loss)


def show_local_score(local_scores):
    """
    Logs the local (per-level) scores for a given dataset.

    Args:
        local_scores (dict): A dictionary mapping each level to its
            corresponding score.

    Returns:
        None
    """
    formatted_string = ""
    for level, local_score in local_scores.items():
        if local_score is not None and local_score != 0.0:
            formatted_string += f"level {level} score {local_score} // "

    logging.info(formatted_string)
