"""Allow `python -m midas_index ...` to invoke the CLI."""

from .cli import main

if __name__ == "__main__":
    main()
