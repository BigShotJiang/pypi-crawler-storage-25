#!/usr/bin/env python3
"""psinfo — rich process info viewer."""

from __future__ import annotations

import argparse
import os
import sys
import time
from dataclasses import dataclass
from datetime import datetime

try:
    import psutil
    from rich.console import Console, Group
    from rich.live import Live
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.tree import Tree
except ImportError as e:
    print(f"Missing dependency: {e}\nRun: pip install psinfo")
    sys.exit(1)


_SELF_PID = os.getpid()
_WINDOWS = sys.platform == "win32"
_FDS_ATTR = "num_handles" if _WINDOWS else "num_fds"
_FDS_LABEL = "handles" if _WINDOWS else "fds"

PROC_ATTRS = [
    "pid", "ppid", "name", "cmdline", "username", "cpu_percent",
    "memory_info", "memory_percent", "num_threads", "create_time", _FDS_ATTR,
]


@dataclass
class ProcessInfo:
    pid: int
    name: str
    cmdline: list[str]
    username: str
    cpu_percent: float
    mem_percent: float
    rss_mb: float
    num_threads: int
    create_time: float
    num_fds: int
    ppid: int = 0

    @property
    def command(self) -> str:
        return " ".join(self.cmdline) if self.cmdline else self.name

    @property
    def command_parts(self) -> tuple[str, str]:
        """Return (executable, args) split for styled rendering."""
        if not self.cmdline:
            return self.name, ""
        exe = self.cmdline[0]
        args = " ".join(self.cmdline[1:])
        return exe, args

    @property
    def uptime(self) -> str:
        elapsed = time.time() - self.create_time
        if elapsed < 60:
            return f"{int(elapsed)}s"
        elif elapsed < 3600:
            m = int(elapsed / 60)
            s = int(elapsed % 60)
            return f"{m}m {s:02d}s"
        elif elapsed < 86400:
            h = int(elapsed / 3600)
            m = int((elapsed % 3600) / 60)
            return f"{h}h {m:02d}m"
        else:
            d = int(elapsed / 86400)
            h = int((elapsed % 86400) / 3600)
            return f"{d}d {h:02d}h"

    @property
    def rss_human(self) -> str:
        if self.rss_mb >= 1024:
            return f"{self.rss_mb / 1024:.1f} GB"
        return f"{self.rss_mb:.0f} MB"


def _proc_to_info(proc: psutil.Process) -> ProcessInfo | None:
    try:
        info = proc.as_dict(attrs=PROC_ATTRS)
        mem = info.get("memory_info")
        return ProcessInfo(
            pid=info["pid"],
            ppid=info.get("ppid") or 0,
            name=info.get("name") or "",
            cmdline=info.get("cmdline") or [],
            username=info.get("username") or "",
            cpu_percent=info.get("cpu_percent") if info.get("cpu_percent") is not None else 0.0,
            mem_percent=info.get("memory_percent") if info.get("memory_percent") is not None else 0.0,
            rss_mb=(mem.rss / 1024 / 1024) if mem else 0.0,
            num_threads=info.get("num_threads") if info.get("num_threads") is not None else 0,
            create_time=info.get("create_time") if info.get("create_time") is not None else 0.0,
            num_fds=info.get(_FDS_ATTR) if info.get(_FDS_ATTR) is not None else 0,
        )
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None


def _collect_and_measure(candidates: list) -> list[ProcessInfo]:
    """Sleep briefly after seeding so the second cpu_percent call is meaningful."""
    if not candidates:
        return []
    time.sleep(0.1)
    results = []
    for proc in candidates:
        info = _proc_to_info(proc)
        if info:
            results.append(info)
    return results


def find_by_name(pattern: str) -> list[ProcessInfo]:
    pattern_lower = pattern.lower()
    candidates = []
    for proc in psutil.process_iter(PROC_ATTRS):
        try:
            if proc.info.get("pid") == _SELF_PID:
                continue
            name = (proc.info.get("name") or "").lower()
            cmdline = " ".join(proc.info.get("cmdline") or []).lower()
            if pattern_lower in name or pattern_lower in cmdline:
                candidates.append(proc)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return _collect_and_measure(candidates)


def find_by_user(username: str) -> list[ProcessInfo]:
    username_lower = username.lower()
    candidates = []
    for proc in psutil.process_iter(PROC_ATTRS):
        try:
            if proc.info.get("pid") == _SELF_PID:
                continue
            if (proc.info.get("username") or "").lower() == username_lower:
                candidates.append(proc)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return _collect_and_measure(candidates)


def find_by_pid(pid: int) -> ProcessInfo | None:
    try:
        proc = psutil.Process(pid)
        proc.cpu_percent(interval=None)  # seed baseline
        time.sleep(0.1)
        return _proc_to_info(proc)
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None


def find_by_port(port: int) -> ProcessInfo | None:
    connections = psutil.net_connections(kind="inet")  # raises AccessDenied if unprivileged
    # Prefer LISTEN connections, fall back to any connection on that port
    matching = [c for c in connections if c.laddr.port == port and c.pid is not None]
    listening = [c for c in matching if c.status == "LISTEN"]
    candidates = listening if listening else matching
    if candidates:
        return find_by_pid(candidates[0].pid)
    return None


def _metric_color(value: float, warn: float = 10.0, critical: float = 50.0) -> str:
    if value >= critical:
        return "red"
    elif value >= warn:
        return "dark_orange"
    return "green"


def _delta_indicator(current: float, previous: float | None, threshold: float = 0.5) -> tuple[str, str]:
    """Return (symbol, style) for the delta arrow. Empty string when no meaningful change."""
    if previous is None:
        return "", ""
    diff = current - previous
    if diff > threshold:
        return "↑", "bold red"
    if diff < -threshold:
        return "↓", "bold green"
    return "", ""


def render_card(
    proc: ProcessInfo,
    user_width: int = 0,
    uptime_width: int = 0,
    fds_width: int = 0,
    sort_by: str = "cpu",
    expand: bool = False,
    prev_cpu: float | None = None,
    prev_mem: float | None = None,
) -> Panel:
    cpu_color = _metric_color(proc.cpu_percent)
    mem_color = _metric_color(proc.mem_percent)
    primary_color = mem_color if sort_by == "mem" else cpu_color

    # Command line — executable bright, args dimmed; wrap if expand, else truncate
    exe, args = proc.command_parts
    cmd = Text(no_wrap=not expand, overflow="ellipsis" if not expand else "fold")
    cmd.append(exe)
    if args:
        cmd.append(" " + args, style="dim")

    cpu_arrow, cpu_arrow_style = _delta_indicator(proc.cpu_percent, prev_cpu)
    mem_arrow, mem_arrow_style = _delta_indicator(proc.mem_percent, prev_mem)

    # Stats line — fixed-width fields so values align across cards
    stats = Text()
    stats.append("CPU ", style="dim")
    stats.append(f"{proc.cpu_percent:>5.1f}%", style=cpu_color)
    if cpu_arrow:
        stats.append(f" {cpu_arrow}", style=cpu_arrow_style)
    else:
        stats.append("  ")
    stats.append("  MEM ", style="dim")
    stats.append(f"{proc.mem_percent:>5.1f}%", style=mem_color)
    if mem_arrow:
        stats.append(f" {mem_arrow}", style=mem_arrow_style)
    else:
        stats.append("  ")
    stats.append("  RSS ", style="dim")
    stats.append(f"{proc.rss_human:>7}", style="cyan")
    stats.append("   THR ", style="dim")
    stats.append(f"{proc.num_threads:>3}", style="default")

    # Footer — right side of the stats row
    footer = Text(style="dim")
    footer.append(f"{proc.username:<{user_width}}")
    footer.append("   ")
    footer.append(f"{proc.uptime:>{uptime_width}} ago")
    footer.append("   ")
    footer.append(f"{proc.num_fds:>{fds_width}} {_FDS_LABEL}")

    stats_row = Table.grid(expand=True)
    stats_row.add_column(ratio=1)
    stats_row.add_column(justify="right")
    stats_row.add_row(stats, footer)

    content = Group(cmd, stats_row)

    title = Text()
    title.append(proc.name, style=f"bold {primary_color}")
    title.append(f"  PID {proc.pid}", style="dim")

    return Panel(content, title=title, border_style=primary_color, padding=(0, 1))


def sort_procs(procs: list[ProcessInfo], sort_by: str) -> list[ProcessInfo]:
    if sort_by == "mem":
        return sorted(procs, key=lambda p: p.mem_percent, reverse=True)
    else:  # cpu (default)
        return sorted(procs, key=lambda p: p.cpu_percent, reverse=True)


def render_results(
    procs: list[ProcessInfo],
    query_label: str,
    sort_by: str = "cpu",
    top: int | None = None,
    expand: bool = False,
    prev_metrics: dict[int, tuple[float, float]] | None = None,
) -> Group:
    if not procs:
        return Group(Text("No processes found.", style="bold red"))

    sorted_procs = sort_procs(procs, sort_by)
    total = len(sorted_procs)
    if top:
        sorted_procs = sorted_procs[:top]

    user_width = max(len(p.username) for p in sorted_procs)
    uptime_width = max(len(p.uptime) for p in sorted_procs)
    fds_width = max(len(str(p.num_fds)) for p in sorted_procs)

    count = len(sorted_procs)
    noun = "process" if total == 1 else "processes"
    label = f"top {count} of {total}" if top and count < total else str(count)
    header = Text(f'● {label} {noun} matching "{query_label}"', style="dim")

    cards = []
    for p in sorted_procs:
        prev = prev_metrics.get(p.pid) if prev_metrics else None
        prev_cpu, prev_mem = (prev[0], prev[1]) if prev else (None, None)
        cards.append(render_card(
            p,
            user_width=user_width,
            uptime_width=uptime_width,
            fds_width=fds_width,
            sort_by=sort_by,
            expand=expand,
            prev_cpu=prev_cpu,
            prev_mem=prev_mem,
        ))

    total_cpu = sum(p.cpu_percent for p in sorted_procs)
    total_mem = sum(p.mem_percent for p in sorted_procs)
    total_rss = sum(p.rss_mb for p in sorted_procs)
    rss_str = f"{total_rss / 1024:.1f} GB" if total_rss >= 1024 else f"{total_rss:.0f} MB"
    summary = Text(style="dim")
    summary.append(f"  ∑ CPU {total_cpu:.1f}%  MEM {total_mem:.1f}%  RSS {rss_str}")

    return Group(header, *cards, summary)


def _subtree_totals(
    pid: int, children_map: dict[int, list[ProcessInfo]], proc: ProcessInfo
) -> tuple[float, float, float]:
    """Return (cpu, mem, rss) summed across proc and all descendants."""
    cpu, mem, rss = proc.cpu_percent, proc.mem_percent, proc.rss_mb
    for child in children_map.get(pid, []):
        c, m, r = _subtree_totals(child.pid, children_map, child)
        cpu += c; mem += m; rss += r
    return cpu, mem, rss


def _prev_subtree_totals(
    pid: int,
    children_map: dict[int, list[ProcessInfo]],
    prev_metrics: dict[int, tuple[float, float]],
) -> tuple[float, float] | None:
    """Return (cpu, mem) summed from prev_metrics for pid and all descendants.
    Returns None if any pid in the subtree is missing from prev_metrics."""
    if pid not in prev_metrics:
        return None
    cpu, mem = prev_metrics[pid]
    for child in children_map.get(pid, []):
        child_prev = _prev_subtree_totals(child.pid, children_map, prev_metrics)
        if child_prev is None:
            return None
        cpu += child_prev[0]
        mem += child_prev[1]
    return cpu, mem


def _tree_label(
    proc: ProcessInfo,
    totals: tuple[float, float, float] | None = None,
    name_width: int = 0,
    pid_width: int = 4,
    sort_by: str = "cpu",
    prev_cpu: float | None = None,
    prev_mem: float | None = None,
) -> Text:
    label = Text()

    if totals is not None:
        t_cpu, t_mem, t_rss = totals
        cpu_arrow, cpu_arrow_style = _delta_indicator(t_cpu, prev_cpu)
        mem_arrow, mem_arrow_style = _delta_indicator(t_mem, prev_mem)
        primary_color = _metric_color(t_mem if sort_by == "mem" else t_cpu)
        label.append(f"{proc.name:<{name_width}}", style=f"bold {primary_color}")
        label.append(f"  PID {proc.pid:>{pid_width}}", style="dim")
        label.append("  ∑ CPU ", style="dim")
        label.append(f"{t_cpu:>6.1f}%", style=_metric_color(t_cpu))
        label.append(f" {cpu_arrow}" if cpu_arrow else "  ", style=cpu_arrow_style)
        label.append("  MEM ", style="dim")
        label.append(f"{t_mem:>6.1f}%", style=_metric_color(t_mem))
        label.append(f" {mem_arrow}" if mem_arrow else "  ", style=mem_arrow_style)
        label.append("  RSS ", style="dim")
        rss_human = f"{t_rss / 1024:.1f} GB" if t_rss >= 1024 else f"{t_rss:.0f} MB"
        label.append(f"{rss_human:>7}", style="cyan")
    else:
        cpu_arrow, cpu_arrow_style = _delta_indicator(proc.cpu_percent, prev_cpu)
        mem_arrow, mem_arrow_style = _delta_indicator(proc.mem_percent, prev_mem)
        primary_color = _metric_color(proc.mem_percent if sort_by == "mem" else proc.cpu_percent)
        label.append(f"{proc.name:<{name_width}}", style=f"bold {primary_color}")
        label.append(f"  PID {proc.pid:>{pid_width}}", style="dim")
        label.append("    CPU ", style="dim")  # 4 spaces to align with "  ∑ CPU"
        label.append(f"{proc.cpu_percent:>6.1f}%", style=_metric_color(proc.cpu_percent))
        label.append(f" {cpu_arrow}" if cpu_arrow else "  ", style=cpu_arrow_style)
        label.append("  MEM ", style="dim")
        label.append(f"{proc.mem_percent:>6.1f}%", style=_metric_color(proc.mem_percent))
        label.append(f" {mem_arrow}" if mem_arrow else "  ", style=mem_arrow_style)
        label.append("  RSS ", style="dim")
        label.append(f"{proc.rss_human:>7}", style="cyan")

    return label


def render_tree_results(
    procs: list[ProcessInfo],
    query_label: str,
    sort_by: str = "cpu",
    top: int | None = None,
    expand: bool = False,
    prev_metrics: dict[int, tuple[float, float]] | None = None,
) -> Group:
    if not procs:
        return Group(Text("No processes found.", style="bold red"))

    sorted_procs = sort_procs(procs, sort_by)
    pid_set = {p.pid for p in sorted_procs}
    name_width = max(len(p.name) for p in sorted_procs)
    pid_width = max(len(str(p.pid)) for p in sorted_procs)

    children_map: dict[int, list[ProcessInfo]] = {}
    roots: list[ProcessInfo] = []
    for proc in sorted_procs:
        if proc.ppid in pid_set:
            children_map.setdefault(proc.ppid, []).append(proc)
        else:
            roots.append(proc)

    def effective_sort_key(proc: ProcessInfo) -> float:
        if children_map.get(proc.pid):
            t_cpu, t_mem, _ = _subtree_totals(proc.pid, children_map, proc)
            return t_mem if sort_by == "mem" else t_cpu
        return proc.mem_percent if sort_by == "mem" else proc.cpu_percent

    roots.sort(key=effective_sort_key, reverse=True)

    count = len(procs)

    def _node_prev(pid: int, has_children: bool) -> tuple[float | None, float | None]:
        if not prev_metrics:
            return None, None
        if has_children:
            prev = _prev_subtree_totals(pid, children_map, prev_metrics)
            return (prev[0], prev[1]) if prev else (None, None)
        prev = prev_metrics.get(pid)
        return (prev[0], prev[1]) if prev else (None, None)

    def add_children(node, pid: int) -> None:
        for child in children_map.get(pid, []):
            has_children = bool(children_map.get(child.pid))
            totals = _subtree_totals(child.pid, children_map, child) if has_children else None
            prev_cpu, prev_mem = _node_prev(child.pid, has_children)
            add_children(node.add(_tree_label(child, totals, name_width, pid_width, sort_by, prev_cpu, prev_mem)), child.pid)

    total_roots = len(roots)
    if top:
        roots = roots[:top]

    trees = []
    for root in roots:
        has_children = bool(children_map.get(root.pid))
        totals = _subtree_totals(root.pid, children_map, root) if has_children else None
        prev_cpu, prev_mem = _node_prev(root.pid, has_children)
        t = Tree(_tree_label(root, totals, name_width, pid_width, sort_by, prev_cpu, prev_mem))
        add_children(t, root.pid)
        trees.append(t)

    noun = "process" if count == 1 else "processes"
    tree_label = f"top {len(roots)} of {total_roots}" if top and len(roots) < total_roots else str(count)
    header = Text(f'● {tree_label} {noun} matching "{query_label}"', style="dim")

    return Group(header, *trees)


def run_watch(
    console: Console,
    query_fn,
    label: str,
    interval: float,
    sort_by: str,
    tree: bool = False,
    top: int | None = None,
    expand: bool = False,
) -> None:
    # prev_metrics: pid -> (cpu_percent, mem_percent) from the previous tick
    prev_metrics: dict[int, tuple[float, float]] = {}
    try:
        with Live(console=console, refresh_per_second=4, screen=False) as live:
            while True:
                procs = query_fn()
                timestamp = datetime.now().strftime("%H:%M:%S")
                status = Text(
                    f"psinfo {label}  ·  refreshing every {interval:.0f}s  ·  last updated {timestamp}",
                    style="dim italic",
                )
                if tree:
                    content = render_tree_results(procs, label, sort_by, top, expand, prev_metrics=prev_metrics)
                else:
                    content = render_results(procs, label, sort_by, top, expand, prev_metrics=prev_metrics)
                live.update(Group(status, content))
                prev_metrics = {p.pid: (p.cpu_percent, p.mem_percent) for p in procs}
                time.sleep(interval)
    except KeyboardInterrupt:
        console.print("\n[dim]psinfo exited.[/dim]")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="psinfo",
        description="Rich process info viewer.",
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument("name", nargs="?", help="Search by process name or command")
    group.add_argument("-u", "--user", metavar="USERNAME", help="Filter by username")
    group.add_argument("-p", "--port", metavar="PORT", type=int, help="Find process listening on port")
    group.add_argument("-P", "--pid", metavar="PID", type=int, help="Show process by PID")

    parser.add_argument(
        "-w", "--watch", nargs="?", const=2.0, type=float, metavar="SECONDS",
        help="Live refresh mode (default interval: 2s)",
    )
    parser.add_argument(
        "-s", "--sort", choices=["cpu", "mem"], default="cpu",
        help="Sort order for results (default: cpu)",
    )
    parser.add_argument(
        "-t", "--tree", action="store_true",
        help="Group results by process tree hierarchy",
    )
    parser.add_argument(
        "-T", "--top", metavar="N", type=int, default=None,
        help="Show only the top N results",
    )
    parser.add_argument(
        "-e", "--expand", action="store_true",
        help="Show full command line (wrap instead of truncate)",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    console = Console()

    if args.user:
        label = f"user:{args.user}"
        query_fn = lambda: find_by_user(args.user)
        not_found_msg = None
        pid_mode = False
    elif args.port is not None:
        label = f"port:{args.port}"
        query_fn = lambda: ([r] if (r := find_by_port(args.port)) else [])
        not_found_msg = f"Nothing listening on port {args.port}."
        pid_mode = False
    elif args.pid is not None:
        label = f"pid:{args.pid}"
        query_fn = lambda: ([r] if (r := find_by_pid(args.pid)) else [])
        not_found_msg = f"Process {args.pid} not found."
        pid_mode = True
    elif args.name:
        label = args.name
        query_fn = lambda: find_by_name(args.name)
        not_found_msg = None
        pid_mode = False
    else:
        parser.print_help()
        sys.exit(1)

    render_fn = render_tree_results if args.tree else render_results

    try:
        if args.watch is not None:
            run_watch(console, query_fn, label, args.watch, args.sort, tree=args.tree, top=args.top, expand=args.expand)
        else:
            procs = query_fn()
            if not procs and not_found_msg:
                console.print(f"[bold red]{not_found_msg}[/bold red]")
                if pid_mode:
                    sys.exit(1)
            else:
                console.print(render_fn(procs, label, args.sort, args.top, args.expand))
    except psutil.AccessDenied:
        console.print("[bold red]Permission denied. Try: sudo psinfo ...[/bold red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
