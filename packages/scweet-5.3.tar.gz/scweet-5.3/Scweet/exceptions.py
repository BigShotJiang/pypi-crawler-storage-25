from __future__ import annotations

from typing import Any, Optional, Union


class ScweetError(Exception):
    """Base Scweet exception."""


class ConfigError(ScweetError):
    """Configuration parsing/validation error."""


class ManifestError(ScweetError):
    """Manifest loading/validation error."""


class AccountPoolExhausted(ScweetError):
    """No eligible account could be leased."""


class EngineError(ScweetError):
    """Engine-level runtime error."""


class RunFailed(EngineError):
    """A run completed without raising, but could not produce results due to errors."""

    def __init__(self, message: str, *, diagnostics: Optional[dict[str, Any]] = None) -> None:
        self.diagnostics = dict(diagnostics or {})
        super().__init__(message)


class NetworkError(RunFailed):
    """Network/connectivity failure prevented scraping progress."""


class ProxyError(RunFailed):
    """Proxy misconfiguration or proxy connectivity failure prevented scraping progress."""


class RateLimitError(RunFailed):
    """All accounts were rate-limited (429). Wait for cooldowns to expire and retry."""


class AuthError(RunFailed):
    """Account credentials are invalid or expired (401/403). Refresh your auth_token/ct0."""


class ResumeError(ScweetError):
    """Resume mode/checkpoint error."""


class AccountSessionBuildError(ScweetError, ValueError):
    """Typed account-session bootstrap failure with stable classification metadata."""

    default_status_code = 599
    default_category = "transient"

    def __init__(
        self,
        code: str,
        reason: str,
        *,
        status_code: Optional[int] = None,
        category: Optional[str] = None,
    ) -> None:
        self.code = str(code or "session_build_error").strip() or "session_build_error"
        self.reason = str(reason or self.code).strip() or self.code
        self.status_code = int(status_code if status_code is not None else self.default_status_code)
        self.category = str(category or self.default_category).strip() or self.default_category
        super().__init__(f"{self.code}:{self.reason}")

    @property
    def metadata(self) -> dict[str, Union[str, int]]:
        return {
            "code": self.code,
            "reason": self.reason,
            "status_code": self.status_code,
            "category": self.category,
        }


class AccountSessionAuthError(AccountSessionBuildError):
    """Auth material is missing/invalid and account should be cooled as auth-failed."""

    default_status_code = 401
    default_category = "auth"


class AccountSessionRuntimeError(AccountSessionBuildError):
    """Unexpected account session runtime/bootstrap failure."""

    default_status_code = 500
    default_category = "runtime"


class AccountSessionTransientError(AccountSessionBuildError):
    """Transient account session failure that should not poison the account permanently."""

    default_status_code = 599
    default_category = "transient"
