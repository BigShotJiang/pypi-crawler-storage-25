# DGGALPandas module

::: vgridpandas.dggalpandas
