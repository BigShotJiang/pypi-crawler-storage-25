import httpx
import certifi
import ssl
import qiskit
import qiskit.qpy
import base64
import tempfile
import os
import typing

from aqdrop import defs

# qcal imports
import qcal.settings as settings
from qcal.utils import load_from_pickle
import qcal
from qcal.calibration.readout import ReadoutCalibration
from qcal.backend.qubic.qpu import QubicQPU

# TODO: figure out how to generalize for different QPUs
from qcal.interface.superstaq.transpiler import QiskitTranspiler
from qcal.circuit import Barrier
from qcal.gate.single_qubit import Meas, X, X90, Rz, H, Y, Z
from qcal.gate.two_qubit import CX, CZ, CNOT

default_host = "https://aqdrop-api.nersc.gov"


class AQDrop:
    def __init__(self,
                 host: str = default_host,
                 token: str | None = None,
                 operator: bool = False):
        ctx = ssl.create_default_context(cafile=certifi.where())
        self._client = httpx.Client(base_url=host.rstrip("/"), timeout=10, verify=ctx)
        self._token: str | None = token

        self.operator = operator


    def _apply_token(self, headers: dict):
        if self._token is None:
            return headers
        return {**headers, "Authorization": f"Bearer {self._token}"}


    def _request(self, method: str, path: str, **kwargs):
        headers = kwargs.pop("headers", {})
        new_headers = self._apply_token(headers)
        req = self._client.request(method, path, headers=new_headers, **kwargs)
        req.raise_for_status()
        return req


    # TODO: set operator here (see if server returns is_operator - if not, modify it!)
    def login(self, username, password):
        req_json = {"username": username, "password": password}
        login_request = self._request("POST", "/token/",
                                      data=req_json,
                                      headers={"Content-Type": "application/x-www-form-urlencoded"})
        self._token = login_request.json()["access_token"]
        return self._token


    def create_member(self, username: str, email: str | None = None):
        req_json = { "name": username }

        if email is not None:
            req_json["email"] = email

        create_request = self._request("POST", "/members/", json=req_json)
        return create_request.json()


    # TODO: fix request params
    def get_member_list(self, skip: int | None = None, limit: int | None = None):
        req_params = {}
        if skip is not None: req_params["skip"] = skip
        if limit is not None: req_params["limit"] = limit
        get_request = self._request("GET", "/members/", params=req_params)
        return get_request.json()


    def get_member(self, name: str):
        get_request = self._request("GET", f"/members/{name}")
        return get_request.json()


    # TODO: use pydantic for cleaner queries
    def update_member(self, name: str,
                      new_name: str | None = None,
                      new_email: str | None = None,
                      new_password: str | None = None,
                      is_active: bool | None = None
                      ):
        req_json = {}
        if new_name is not None: req_json["name"] = new_name
        if new_email is not None: req_json["email"] = new_email
        if new_password is not None: req_json["password"] = new_password
        if is_active is not None: req_json["is_active"] = is_active
        patch_request = self._request("PATCH", f"/members/{name}", json=req_json)
        # TODO: decide: do we need to log in again?
        return patch_request.json()


    def delete_member(self, name: str):
        delete_request = self._request("DELETE", f"/members/{name}")
        return delete_request.json()


    def update_member_perms(self, name: str,
                            is_admin: bool | None = None,
                            is_operator: bool | None = None,
                            is_suspended: bool | None = None
                            ):
        req_json = {}
        if is_admin is not None: req_json["is_admin"] = is_admin
        if is_operator is not None: req_json["is_operator"] = is_operator
        if is_suspended is not None: req_json["is_suspended"] = is_suspended
        patch_request = self._request("PATCH", f"/members/{name}/role", json=req_json)
        return patch_request.json()


    # TODO: update job_input type?
    def submit_job(self, queue_name: str, job_input: dict):
        req_json = {
                "queue_name": queue_name,
                "input": job_input
                }
        post_request = self._request("POST", "/job/", json=req_json)
        return post_request.json()


    def _embed_qiskit(self, qc: typing.List[qiskit.QuantumCircuit]):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as tf:
            qiskit.qpy.dump(qc, tf)
            tf.close()
            with open(tf.name, 'rb') as tfr:
                b = base64.b64encode(tfr.read())
        return b.decode()


    def _extract_qiskit(self, b: str) -> typing.List[qiskit.QuantumCircuit]:
        embedded_qpy = base64.b64decode(b)
        with tempfile.NamedTemporaryFile(delete_on_close=False) as tf:
            tf.write(embedded_qpy)
            tf.close()
            with open(tf.name, 'rb') as tfr:
                qc = qiskit.qpy.load(tfr)[0]

        if type(qc) == qiskit.QuantumCircuit:
            return [qc]
        elif isinstance(qc, list):
            return qc
        else:
            raise TypeError("Embedded QPY must be a Qiskit circuit or list of Qiskit circuits.")


    def submit_qiskit(self, queue_name: str, qc: typing.List[qiskit.QuantumCircuit]):
        b = self._embed_qiskit(qc)

        job_dd = {
                'qpy': b,
                'shots': 1024
        }

        submitted = self.submit_job(queue_name, job_dd)


    def get_job(self, job_id: int, extract_qpy: bool = False):
        get_request = self._request("GET", f"/job/?job_id={job_id}")
        job_dd: dict = get_request.json()

        if extract_qpy:
            qc = self._extract_qiskit(job_dd["qpy"])
            job_dd.update({"qc": qc})

        return job_dd


    def check_job(self, job_id: int):
        get_request = self._request("GET", f"/job/check/?job_id={job_id}")
        return get_request.json()


    def cancel_job(self, job_id: int):
        r = self._request("PATCH", "/job/cancel/", json={"id": job_id})
        return r.json()


    def run_job(self, job_id: int):
        if not self.operator:
            raise PermissionError("Only operators may run jobs!")

        job = self.get_job(job_id, extract_qpy=True)

        # TODO: do not hardcode this
        if job["queue_name"] != "X6Y3":
            return None

        self._qpu_connect(job["queue_name"])

        transpiled, counts = self.run_circuits(job["qc"])

        output = {
            "counts": counts,
            "transpiled_qpy": self._embed_qiskit(transpiled)
        }

        return self.dispatch_job(job_id, defs.JobStatus.SUCCESS, output)


    def dispatch_job(self, job_id: int,
                     status: defs.JobStatus,
                     output: dict | None = None):
        req_json = {
                "id": job_id,
                "status": status.value,
                "output": output
                }
        r = self._request("PATCH", "/job/dispatch/", json=req_json)
        return r.json()


    # TODO: will this actually return a json?
    def add_queue(self, queue_name: str, default_access: bool = False, limit: int = 5, description: str = ""):
        req_json = {
                "name": queue_name,
                "default_access": default_access,
                "limit": limit, 
                "description": description
                }
        r = self._request("POST", "/queue/", json=req_json)
        return r.json()


    def list_queues(self, state: defs.QueueState | None = None):
        req_params = {}
        if state is not None:
            req_params["state"] = state.value
        return self._request("GET", "/queues/", params=req_params).json()


    # TODO: use pydantic for cleaner queries
    def update_queue(self, queue_name: str,
                     new_name: str | None = None,
                     new_default_access: bool | None = None,
                     new_limit: int | None = None,
                     new_state: defs.QueueState | None = None):
        req_json = {}
        if new_name is not None: req_json["name"] = new_name
        if new_default_access is not None: req_json["default_access"] = new_default_access
        if new_limit is not None: req_json["limit"] = new_limit
        if new_state is not None: req_json["state"] = new_state.value
        r = self._request("PATCH", f"/queue/{queue_name}", json=req_json)
        return r.json()


    # TODO: use pydantic for cleaner queries
    def query_jobs(self,
                   id: int | None = None,
                   queue_name: str | None = None,
                   queue_id: int | None = None,
                   owner_name: str | None = None,
                   owner_id: int | None = None,
                   status: defs.JobStatus | None = None):
        req_params = {}
        if id is not None: req_params["id"] = id
        if queue_name is not None: req_params["queue_name"] = queue_name
        if queue_id is not None: req_params["queue_id"] = queue_id
        if owner_name is not None: req_params["owner_name"] = owner_name
        if owner_id is not None: req_params["owner_id"] = owner_id
        if status is not None: req_params["status"] = status.value
        r = self._request("GET", "/jobs/", params=req_params)
        return r.json()


    def list_members(self,
                     limit: int | None = None,
                     skip: int | None = None):
        req_params = {}
        if limit is not None: req_params["limit"] = limit
        if skip is not None: req_params["skip"] = skip
        r = self._request("GET", "/members/", params=req_params)
        return r.json()


    # NOTE: for now we assume that any job is a qiskit job; this may change later
    def run_circuits(self, qc: qiskit.QuantumCircuit):
        if not self.operator:
            raise PermissionError("Only operators may run circuits!")

        connectivity = [[0,1],[1,2],[2,3],[3,4],[4,5],[5,6],[6,7],[7,0]]
        basis_gates = ["rx", "rz", "cz", "x"]

        # TODO: handle errors from transpilation
        qc_qiskit = qiskit.transpile(qc, basis_gates=basis_gates, coupling_map=connectivity)

        qcal_transpiler = QiskitTranspiler(gate_mapper=self.gate_mapper)
        qc_qcal = qcal_transpiler.transpile(qc_qiskit)[0]

        self.qpu.run(qc_qcal)

        counts = dict(qc_qcal.results.counts)

        return (qc_qcal, counts)


    def _qpu_connect(self, chip_name="X6Y3"):
        # TODO: change this name
        self.settings_config_path = os.getenv(f"AQDROP_QUBIC_CONFIG_{chip_name}")
        if self.settings_config_path is None:
            raise FileNotFoundError(f"environment variable AQDROP_QUBIC_CONFIG_{chip_name} not set!")

        # TODO: we are assuming only one QPU for now; later, this will change
        # match queue name with environment variable
        self.qpu_ip = os.getenv(f"AQDROP_QUBIC_IP_{chip_name}")
        if self.qpu_ip is None:
            raise FileNotFoundError(f"environment variable AQDROP_QUBIC_IP_{chip_name} not set!")

        self.qpu_port = os.getenv(f"AQDROP_QUBIC_PORT_{chip_name}")
        if self.qpu_port is None:
            raise FileNotFoundError(f"environment variable AQDROP_QUBIC_PORT_{chip_name} not set!")

        self.qpu_port = int(self.qpu_port)

        settings.Settings.config_path = self.settings_config_path
        self.cfg = qcal.Config()

        classifier = load_from_pickle(self.settings_config_path.rstrip("/") + "/ClassificationManager.pkl")

        self.qcal_cfg = qcal.Config()
        self.qpu = QubicQPU(self.qcal_cfg, classifier=classifier, ip_address=self.qpu_ip, port=self.qpu_port)


    def _get_qpu_settings(self, queue_name="X6Y3"):
        # TODO: get queue settings and apply
        # TODO: check sx and p mapping as alternate mappings
        self.gate_mapper = {
            'barrier': Barrier,
            'measure': Meas,
            'cz':   CZ,
            'rz':   Rz,
            'rx':   X90,
            'x':    X,
        }
