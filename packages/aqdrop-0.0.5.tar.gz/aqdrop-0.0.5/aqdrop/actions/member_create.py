#!/usr/bin/env python3

import argparse
import pprint
import httpx

from aqdrop import AQDrop
from aqdrop import creds


def add_args(parser):
    parser.add_argument("--name")
    parser.add_argument("--email", default=None)


def main(args):
    parser.add_argument("--name")
    parser.add_argument("--email", default=None)
    args = parser.parse_args()

    c = AQDrop(creds.network)

    c.login(creds.username, creds.password)

    try:
        output = c.create_member(args.name, args.email)
    except httpx.HTTPStatusError as e:
        print(f"Could not create member.")
        print(f"Error {e.response.status_code}: {e.response.json()['detail']}")
    else:
        # print out properly formatted .creds file to stdout so we can route it into a file
        print("#!/usr/bin/bash")
        print(f"export AQDROP_USERNAME={args.name}")
        print(f"export AQDROP_PASSWORD={output['password']}")
        print(f"export AQDROP_EMAIL={args.email}")
        print(f"export AQDROP_HOST_NAME={creds.network}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    add_args(parser)
    args = parser.parse_args()

    main(args)
