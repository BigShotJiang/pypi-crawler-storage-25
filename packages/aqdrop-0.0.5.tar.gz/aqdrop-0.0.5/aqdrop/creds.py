import os

username = os.getenv("AQDROP_USERNAME")
password = os.getenv("AQDROP_PASSWORD")
email = os.getenv("AQDROP_EMAIL")
network = os.getenv("AQDROP_HOST_NAME")

if username is None or password is None or network is None:
    raise NameError("Environment variables AQDROP_USERNAME, AQDROP_PASSWORD, and AQDROP_HOST_NAME must all be set!")
