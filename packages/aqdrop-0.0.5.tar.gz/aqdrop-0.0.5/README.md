# AQDROP Client

This is a placeholder README. More detailed documentation will be added later.
