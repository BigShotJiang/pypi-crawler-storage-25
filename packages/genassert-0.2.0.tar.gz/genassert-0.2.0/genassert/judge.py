"""
LocalJudge: A lightweight local LLM judge for semantic evaluation.

Uses a small local model (via transformers or llama-cpp-python) so that
CI runs have zero API cost. Falls back to embedding-based scoring if
no local model is available.
"""

from __future__ import annotations
import os
from dataclasses import dataclass


@dataclass
class JudgeResult:
    passed: bool
    score: float          # 0.0–1.0
    reasoning: str
    method: str           # "local_model" | "embeddings" | "fallback"


class LocalJudge:
    """
    A reusable judge that evaluates LLM outputs against criteria.

    Parameters
    ----------
    model:
        Local model identifier. Defaults to GENASSERT_JUDGE_MODEL env var
        or "Qwen/Qwen2.5-0.5B-Instruct" (tiny, fast, free).
    threshold:
        Default pass threshold (0–1). Default 0.7.
    backend:
        "transformers" | "llama_cpp" | "embeddings" (auto-detected).

    Examples
    --------
    >>> judge = LocalJudge()
    >>> result = judge.evaluate(
    ...     response="Paris is the capital of France.",
    ...     criterion="The response correctly answers a geography question.",
    ... )
    >>> assert result.passed
    """

    def __init__(
        self,
        model: str | None = None,
        threshold: float = 0.7,
        backend: str = "auto",
    ) -> None:
        self.model = model or os.environ.get(
            "GENASSERT_JUDGE_MODEL", "Qwen/Qwen2.5-0.5B-Instruct"
        )
        self.threshold = threshold
        self.backend = backend
        self._pipeline = None

    def evaluate(
        self,
        response: str,
        criterion: str,
        threshold: float | None = None,
    ) -> JudgeResult:
        """
        Evaluate whether `response` meets the `criterion`.

        Parameters
        ----------
        response:
            The LLM output to evaluate.
        criterion:
            A plain-English description of what constitutes a passing response.
        threshold:
            Override the instance default threshold.

        Returns
        -------
        JudgeResult
            Contains passed (bool), score (float), reasoning (str), method (str).
        """
        cutoff = threshold if threshold is not None else self.threshold

        if self.backend in ("transformers", "auto"):
            try:
                return self._evaluate_transformers(response, criterion, cutoff)
            except ImportError:
                pass

        if self.backend in ("llama_cpp", "auto"):
            try:
                return self._evaluate_llama_cpp(response, criterion, cutoff)
            except ImportError:
                pass

        # Embedding-based fallback
        return self._evaluate_embeddings(response, criterion, cutoff)

    def _evaluate_transformers(
        self, response: str, criterion: str, threshold: float
    ) -> JudgeResult:
        from transformers import pipeline as hf_pipeline

        if self._pipeline is None:
            self._pipeline = hf_pipeline(
                "text-generation",
                model=self.model,
                max_new_tokens=64,
                do_sample=False,
            )

        prompt = _build_judge_prompt(response, criterion)
        output = self._pipeline(prompt)[0]["generated_text"]
        score, reasoning = _parse_judge_output(output, prompt)
        return JudgeResult(
            passed=score >= threshold,
            score=score,
            reasoning=reasoning,
            method="local_model",
        )

    def _evaluate_llama_cpp(
        self, response: str, criterion: str, threshold: float
    ) -> JudgeResult:
        from llama_cpp import Llama

        if self._pipeline is None:
            self._pipeline = Llama.from_pretrained(repo_id=self.model)

        prompt = _build_judge_prompt(response, criterion)
        output = self._pipeline(prompt, max_tokens=64)["choices"][0]["text"]
        score, reasoning = _parse_judge_output(output, "")
        return JudgeResult(
            passed=score >= threshold,
            score=score,
            reasoning=reasoning,
            method="local_model",
        )

    def _evaluate_embeddings(
        self, response: str, criterion: str, threshold: float
    ) -> JudgeResult:
        from genassert._embed import embed_text
        from genassert.assertions.intent import _cosine_similarity

        score = _cosine_similarity(embed_text(response), embed_text(criterion))
        return JudgeResult(
            passed=score >= threshold,
            score=score,
            reasoning=f"Embedding cosine similarity: {score:.3f}",
            method="embeddings",
        )


def _build_judge_prompt(response: str, criterion: str) -> str:
    return (
        f"You are an objective evaluator. Score the following response.\n\n"
        f"CRITERION: {criterion}\n\n"
        f"RESPONSE: {response}\n\n"
        f"Rate on a scale of 0.0 to 1.0 and give one-sentence reasoning.\n"
        f"Format: SCORE: <float> | REASON: <text>\n"
        f"SCORE:"
    )


def _parse_judge_output(output: str, prompt: str) -> tuple[float, str]:
    """Parse 'SCORE: 0.8 | REASON: ...' from judge output."""
    # Remove prompt prefix if present
    text = output.replace(prompt, "").strip()
    if "SCORE:" in text:
        text = text.split("SCORE:")[-1].strip()

    score = 0.5
    reasoning = text

    try:
        parts = text.split("|", 1)
        score_str = parts[0].strip()
        score = max(0.0, min(1.0, float(score_str)))
        if len(parts) > 1:
            reasoning = parts[1].replace("REASON:", "").strip()
    except (ValueError, IndexError):
        pass

    return score, reasoning
