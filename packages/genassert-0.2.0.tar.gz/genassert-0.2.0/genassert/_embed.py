"""
Embedding backend for genassert.

Priority order (auto-detected):
  1. sentence-transformers (local, free, fast) — recommended
  2. openai embeddings (requires OPENAI_API_KEY)
  3. numpy hash-based fallback (no deps, for smoke tests only)

Set GENASSERT_EMBED_BACKEND=openai|local|fallback to force a backend.
"""

from __future__ import annotations
import os
import hashlib
import math
from functools import lru_cache

_BACKEND_ENV = "GENASSERT_EMBED_BACKEND"
_MODEL_ENV = "GENASSERT_EMBED_MODEL"

_DEFAULT_LOCAL_MODEL = "all-MiniLM-L6-v2"
_DEFAULT_OPENAI_MODEL = "text-embedding-3-small"


@lru_cache(maxsize=512)
def embed_text(text: str) -> tuple[float, ...]:
    """
    Embed `text` into a float vector using the best available backend.
    Results are cached in-process for performance.
    """
    backend = os.environ.get(_BACKEND_ENV, "auto").lower()

    if backend == "openai":
        return _embed_openai(text)
    elif backend in ("local", "sentence-transformers"):
        return _embed_local(text)
    elif backend == "fallback":
        return _embed_fallback(text)
    else:
        # auto-detect
        return _embed_auto(text)


def _embed_auto(text: str) -> tuple[float, ...]:
    """Try backends in priority order."""
    try:
        return _embed_local(text)
    except ImportError:
        pass
    try:
        return _embed_openai(text)
    except (ImportError, RuntimeError):
        pass
    return _embed_fallback(text)


def _embed_local(text: str) -> tuple[float, ...]:
    """Use sentence-transformers (local, no API cost)."""
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        raise ImportError(
            "sentence-transformers not installed.\n"
            "  Install: pip install sentence-transformers\n"
            "  Or set GENASSERT_EMBED_BACKEND=openai"
        )
    model_name = os.environ.get(_MODEL_ENV, _DEFAULT_LOCAL_MODEL)
    model = _get_local_model(model_name)
    vec = model.encode(text, normalize_embeddings=True)
    return tuple(float(v) for v in vec)


@lru_cache(maxsize=4)
def _get_local_model(model_name: str):
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(model_name)


def _embed_openai(text: str) -> tuple[float, ...]:
    """Use OpenAI embeddings API."""
    try:
        import openai
    except ImportError:
        raise ImportError("openai not installed. pip install openai")

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY not set. "
            "Set it or use GENASSERT_EMBED_BACKEND=local"
        )

    model = os.environ.get(_MODEL_ENV, _DEFAULT_OPENAI_MODEL)
    client = openai.OpenAI(api_key=api_key)
    result = client.embeddings.create(input=[text], model=model)
    vec = result.data[0].embedding
    return tuple(float(v) for v in vec)


def _embed_fallback(text: str) -> tuple[float, ...]:
    """
    Hash-based pseudo-embedding. No dependencies, but ONLY suitable for
    smoke tests. Will NOT produce meaningful semantic similarity scores.
    """
    dim = 384
    vec = []
    for i in range(dim):
        seed = hashlib.sha256(f"{i}:{text}".encode()).digest()
        val = int.from_bytes(seed[:4], "big") / (2**32)
        vec.append(val - 0.5)
    # normalize
    mag = math.sqrt(sum(v**2 for v in vec))
    return tuple(v / mag for v in vec)
