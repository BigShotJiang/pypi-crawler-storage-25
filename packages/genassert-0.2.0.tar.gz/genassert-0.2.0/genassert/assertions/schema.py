"""
assert_schema: Verify LLM response matches a Pydantic model or JSON schema.
"""

from __future__ import annotations
import json
from typing import Any, Type


def assert_schema(
    response: str,
    schema: Any,
    strict: bool = True,
) -> Any:
    """
    Assert that `response` (JSON string) matches the given schema.

    Parameters
    ----------
    response:
        The LLM output — must be a valid JSON string.
    schema:
        A Pydantic BaseModel class, or a dict representing a JSON Schema.
    strict:
        If True, extra fields not in schema raise an error.
        If False, extra fields are ignored.

    Returns
    -------
    Parsed and validated object (Pydantic model instance or dict).

    Raises
    ------
    AssertionError
        If the response is not valid JSON or does not match the schema.

    Examples
    --------
    >>> from pydantic import BaseModel
    >>> class Summary(BaseModel):
    ...     title: str
    ...     body: str
    ...     word_count: int
    >>> result = assert_schema(response, Summary)
    >>> print(result.title)
    """
    # Parse JSON
    try:
        data = json.loads(response)
    except json.JSONDecodeError as e:
        raise AssertionError(
            f"Schema assertion failed — response is not valid JSON.\n"
            f"  JSON error: {e}\n"
            f"  Response preview: {response[:300]!r}"
        )

    # Pydantic validation
    try:
        from pydantic import BaseModel, ValidationError
        if isinstance(schema, type) and issubclass(schema, BaseModel):
            try:
                model_config = {}
                if not strict:
                    # allow extra fields
                    pass
                return schema.model_validate(data)
            except ValidationError as e:
                raise AssertionError(
                    f"Schema validation failed.\n"
                    f"  Errors: {e.errors()}\n"
                    f"  Response preview: {response[:200]!r}"
                )
    except ImportError:
        pass

    # Dict/JSON Schema fallback
    if isinstance(schema, dict):
        _validate_json_schema(data, schema, strict)
        return data

    raise AssertionError(
        "schema must be a Pydantic BaseModel class or a JSON Schema dict."
    )


def _validate_json_schema(data: Any, schema: dict, strict: bool) -> None:
    try:
        import jsonschema
        jsonschema.validate(instance=data, schema=schema)
    except ImportError:
        # Manual basic validation without jsonschema
        if "properties" in schema and isinstance(data, dict):
            required = schema.get("required", [])
            for field in required:
                if field not in data:
                    raise AssertionError(
                        f"Schema assertion failed — missing required field: {field!r}"
                    )
    except Exception as e:
        raise AssertionError(f"JSON Schema validation failed: {e}")
