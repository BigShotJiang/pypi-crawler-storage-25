"""
assert_similar_to: Verify LLM response is semantically close to a reference.

Useful for golden-baseline regression testing — ensure a response
hasn't drifted too far from a known-good output.
"""

from __future__ import annotations


def assert_similar_to(
    response: str,
    reference: str,
    threshold: float = 0.80,
    message: str | None = None,
) -> float:
    """
    Assert that `response` is semantically similar to `reference`.

    Parameters
    ----------
    response:
        The LLM output to evaluate.
    reference:
        A reference string (e.g. a golden baseline response).
    threshold:
        Cosine similarity threshold (0–1). Default 0.80.
    message:
        Custom failure message.

    Returns
    -------
    float
        The actual cosine similarity score (useful for logging).

    Raises
    ------
    AssertionError
        If similarity is below threshold.

    Examples
    --------
    >>> score = assert_similar_to(response, golden_response, threshold=0.85)
    """
    from genassert._embed import embed_text
    from genassert.assertions.intent import _cosine_similarity

    score = _cosine_similarity(embed_text(response), embed_text(reference))
    if score < threshold:
        msg = message or (
            f"Similarity assertion failed.\n"
            f"  Cosine similarity: {score:.3f} (threshold: {threshold})\n"
            f"  Response  : {response[:150]!r}\n"
            f"  Reference : {reference[:150]!r}"
        )
        raise AssertionError(msg)
    return score
