"""
assert_token_budget: Verify LLM response stays within a token limit.
"""

from __future__ import annotations


def assert_token_budget(
    response: str,
    max_tokens: int,
    tokenizer: str = "approx",
) -> None:
    """
    Assert that `response` does not exceed `max_tokens`.

    Parameters
    ----------
    response:
        The LLM output to evaluate.
    max_tokens:
        Maximum allowed token count.
    tokenizer:
        "approx" uses a fast word-based approximation (~1.3 tokens/word).
        "tiktoken" uses OpenAI's tiktoken (requires `pip install tiktoken`).
        "chars" uses character count divided by 4.

    Raises
    ------
    AssertionError
        If the response exceeds the token budget.

    Examples
    --------
    >>> assert_token_budget(response, max_tokens=200)
    >>> assert_token_budget(response, max_tokens=500, tokenizer="tiktoken")
    """
    count = _count_tokens(response, tokenizer)
    if count > max_tokens:
        raise AssertionError(
            f"Token budget exceeded.\n"
            f"  Max allowed : {max_tokens} tokens\n"
            f"  Actual count: {count} tokens (method: {tokenizer!r})\n"
            f"  Response preview: {response[:200]!r}"
        )


def _count_tokens(text: str, method: str) -> int:
    if method == "tiktoken":
        try:
            import tiktoken
            enc = tiktoken.get_encoding("cl100k_base")
            return len(enc.encode(text))
        except ImportError:
            raise ImportError(
                "tokenizer='tiktoken' requires: pip install tiktoken"
            )
    elif method == "chars":
        return len(text) // 4
    else:
        # approx: ~1.3 tokens per word is a reasonable average
        words = len(text.split())
        return int(words * 1.3)
