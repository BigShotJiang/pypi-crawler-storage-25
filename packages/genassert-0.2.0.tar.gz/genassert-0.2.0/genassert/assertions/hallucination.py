"""
assert_no_hallucination: Verify LLM output doesn't contradict known facts.

Checks that factual claims in the response are consistent with a provided
list of ground-truth facts, using semantic similarity and contradiction detection.
"""

from __future__ import annotations


def assert_no_hallucination(
    response: str,
    known_facts: list[str],
    contradiction_threshold: float = 0.85,
) -> None:
    """
    Assert that `response` does not contradict any of the `known_facts`.

    This does NOT verify that every fact is mentioned — it checks that
    the response does not make claims that semantically contradict the facts.

    Parameters
    ----------
    response:
        The LLM output to evaluate.
    known_facts:
        A list of factual statements that must NOT be contradicted.
        E.g. ["The capital of France is Paris", "The product costs $49/month"]
    contradiction_threshold:
        If the negation of a fact is highly similar to the response, flag it.
        Default 0.85.

    Raises
    ------
    AssertionError
        If the response appears to contradict one or more known facts.

    Examples
    --------
    >>> assert_no_hallucination(
    ...     response,
    ...     known_facts=["Python was created by Guido van Rossum in 1991"]
    ... )
    """
    from genassert._embed import embed_text
    from genassert.assertions.intent import _cosine_similarity

    response_embedding = embed_text(response)
    contradictions = []

    for fact in known_facts:
        # Build negation of the fact to detect contradictions
        negation = _negate_fact(fact)
        negation_embedding = embed_text(negation)
        similarity = _cosine_similarity(response_embedding, negation_embedding)

        if similarity > contradiction_threshold:
            contradictions.append((fact, similarity))

    if contradictions:
        details = "\n".join(
            f"  - Contradicts: {fact!r} (score: {score:.3f})"
            for fact, score in contradictions
        )
        raise AssertionError(
            f"Hallucination detected — response contradicts known facts:\n{details}\n"
            f"  Response preview: {response[:200]!r}"
        )


def _negate_fact(fact: str) -> str:
    """Produce a simple semantic negation of a fact for contradiction detection."""
    fact = fact.strip()
    negations = [
        ("is not", "is"),
        ("are not", "are"),
        ("was not", "was"),
        ("were not", "were"),
        ("does not", "does"),
        ("did not", "did"),
        ("cannot", "can"),
        ("will not", "will"),
    ]
    lower = fact.lower()
    for neg, pos in negations:
        if pos in lower:
            return fact.replace(pos, neg, 1)
    # Fallback: prepend "It is false that"
    return f"It is false that {fact}"
