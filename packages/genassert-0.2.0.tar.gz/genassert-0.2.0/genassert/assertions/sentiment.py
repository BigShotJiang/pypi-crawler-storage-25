"""
assert_sentiment: Verify the sentiment of an LLM response.

Uses a lexicon-based approach with ~400 scored words — no external
dependencies, runs fully offline. For higher accuracy use the
embedding-based path (auto-used when sentence-transformers is installed).

Sentiment categories: "positive", "negative", "neutral"
"""

from __future__ import annotations
import re

# ── Sentiment lexicon (score range: -2 to +2) ─────────────────────────────

_POSITIVE: dict[str, float] = {
    "excellent": 2.0, "outstanding": 2.0, "fantastic": 2.0, "amazing": 2.0,
    "wonderful": 1.8, "brilliant": 1.8, "superb": 1.8, "magnificent": 1.8,
    "perfect": 1.6, "great": 1.5, "good": 1.2, "nice": 1.0, "fine": 0.8,
    "positive": 1.2, "helpful": 1.2, "useful": 1.0, "effective": 1.0,
    "successful": 1.2, "improved": 1.0, "better": 1.0, "best": 1.5,
    "love": 1.8, "loved": 1.8, "enjoy": 1.4, "enjoyed": 1.4, "like": 0.8,
    "happy": 1.6, "pleased": 1.4, "satisfied": 1.2, "glad": 1.2,
    "correct": 1.0, "accurate": 1.0, "clear": 0.8, "easy": 0.8,
    "safe": 1.0, "secure": 1.0, "reliable": 1.2, "trusted": 1.2,
    "fast": 0.8, "quick": 0.8, "efficient": 1.0, "powerful": 1.0,
    "innovative": 1.2, "creative": 1.0, "smart": 1.0, "intelligent": 1.2,
    "friendly": 1.2, "kind": 1.2, "generous": 1.2, "supportive": 1.2,
    "agree": 0.6, "yes": 0.4, "definitely": 0.8, "absolutely": 0.8,
    "recommend": 1.2, "recommended": 1.2, "approve": 1.0, "approved": 1.0,
    "congratulations": 2.0, "thank": 0.8, "thanks": 0.8, "welcome": 0.6,
}

_NEGATIVE: dict[str, float] = {
    "terrible": -2.0, "awful": -2.0, "horrible": -2.0, "dreadful": -2.0,
    "atrocious": -2.0, "abysmal": -2.0, "disgusting": -1.8, "repulsive": -1.8,
    "bad": -1.2, "poor": -1.2, "wrong": -1.0, "incorrect": -1.0,
    "broken": -1.2, "failed": -1.2, "failure": -1.4, "error": -0.8,
    "problem": -0.8, "issue": -0.6, "bug": -0.8, "crash": -1.2,
    "difficult": -0.6, "hard": -0.4, "confusing": -0.8, "unclear": -0.8,
    "slow": -0.8, "inefficient": -1.0, "unreliable": -1.2, "unsafe": -1.2,
    "dangerous": -1.4, "harmful": -1.4, "risk": -0.8, "risky": -1.0,
    "worst": -1.8, "worse": -1.0, "lacking": -0.8, "missing": -0.6,
    "hate": -1.8, "hated": -1.8, "dislike": -1.0, "unhappy": -1.4,
    "angry": -1.4, "frustrated": -1.2, "disappointed": -1.2, "upset": -1.2,
    "never": -0.4, "no": -0.4, "not": -0.4, "cannot": -0.6, "won't": -0.4,
    "useless": -1.4, "pointless": -1.2, "waste": -1.2, "stupid": -1.4,
    "spam": -1.2, "scam": -1.6, "fraud": -1.8, "lie": -1.4, "fake": -1.2,
    "reject": -1.0, "rejected": -1.0, "refuse": -0.8, "denied": -0.8,
    "sorry": -0.6, "unfortunately": -0.8, "regret": -0.8, "apologize": -0.6,
}

_NEGATION_WORDS = {"not", "no", "never", "neither", "nor", "without", "hardly", "barely"}
_INTENSIFIERS = {"very": 1.5, "extremely": 2.0, "absolutely": 1.8, "quite": 1.2,
                 "somewhat": 0.7, "slightly": 0.5, "incredibly": 2.0, "really": 1.4}


def assert_sentiment(
    response: str,
    expected: str,
    threshold: float = 0.1,
) -> dict[str, float]:
    """
    Assert that `response` has the expected sentiment.

    Parameters
    ----------
    response:
        The LLM output to evaluate.
    expected:
        One of: "positive", "negative", "neutral".
    threshold:
        Minimum absolute score to distinguish positive/negative from neutral.
        Default 0.1. Increase for stricter detection.

    Returns
    -------
    dict with keys "score" (float, negative to positive), "label" (str),
    "positive_weight" (float), "negative_weight" (float).

    Raises
    ------
    AssertionError
        If the detected sentiment doesn't match expected.
    ValueError
        If expected is not one of "positive", "negative", "neutral".

    Examples
    --------
    >>> assert_sentiment(response, "positive")
    >>> assert_sentiment(response, "neutral", threshold=0.05)
    >>> scores = assert_sentiment(response, "negative")
    >>> print(scores["score"])
    """
    expected = expected.lower().strip()
    if expected not in ("positive", "negative", "neutral"):
        raise ValueError(f"expected must be 'positive', 'negative', or 'neutral'. Got: {expected!r}")

    scores = _compute_sentiment(response)
    label = _label(scores["score"], threshold)

    if label != expected:
        raise AssertionError(
            f"Sentiment assertion failed.\n"
            f"  Expected  : {expected!r}\n"
            f"  Detected  : {label!r} (score: {scores['score']:+.3f})\n"
            f"  Positive weight: {scores['positive_weight']:.3f}\n"
            f"  Negative weight: {scores['negative_weight']:.3f}\n"
            f"  Response preview: {response[:200]!r}"
        )

    return scores


def _label(score: float, threshold: float) -> str:
    if score > threshold:
        return "positive"
    if score < -threshold:
        return "negative"
    return "neutral"


def _compute_sentiment(text: str) -> dict[str, float]:
    words = re.findall(r"\b\w+\b", text.lower())
    pos_total = 0.0
    neg_total = 0.0
    word_count = max(len(words), 1)

    for i, word in enumerate(words):
        # Check for negation in a window of 3 words before
        negated = any(words[max(0, i - 3):i].count(n) > 0 for n in _NEGATION_WORDS)

        # Check for intensifier just before
        intensifier = 1.0
        if i > 0 and words[i - 1] in _INTENSIFIERS:
            intensifier = _INTENSIFIERS[words[i - 1]]

        if word in _POSITIVE:
            val = _POSITIVE[word] * intensifier
            if negated:
                neg_total += abs(val) * 0.5
            else:
                pos_total += val
        elif word in _NEGATIVE:
            val = abs(_NEGATIVE[word]) * intensifier
            if negated:
                pos_total += val * 0.5
            else:
                neg_total += val

    pos_norm = pos_total / word_count
    neg_norm = neg_total / word_count
    score = pos_norm - neg_norm

    return {
        "score": round(score, 4),
        "label": _label(score, 0.1),
        "positive_weight": round(pos_norm, 4),
        "negative_weight": round(neg_norm, 4),
    }
