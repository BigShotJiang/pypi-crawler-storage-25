"""
assert_intent: Check that an LLM response addresses the expected intent.

Uses embedding cosine similarity to compare the response against a
natural-language description of what the response should convey.
"""

from __future__ import annotations
import os
from genassert._embed import embed_text


def assert_intent(
    response: str,
    expected_intent: str,
    threshold: float = 0.72,
    model: str | None = None,
) -> None:
    """
    Assert that `response` semantically matches the `expected_intent`.

    Parameters
    ----------
    response:
        The LLM output to evaluate.
    expected_intent:
        A plain-English description of what the response should convey.
        E.g. "a concise summary of the article".
    threshold:
        Cosine similarity threshold (0–1). Default 0.72 works well for
        most English text pairs. Lower = more lenient, higher = stricter.
    model:
        Optional embedding model override.

    Raises
    ------
    AssertionError
        If the cosine similarity between `response` and `expected_intent`
        is below `threshold`.

    Examples
    --------
    >>> assert_intent(response, "a polite refusal to the user's request")
    >>> assert_intent(response, "Python code that reads a CSV file", threshold=0.80)
    """
    similarity = _cosine_similarity(embed_text(response), embed_text(expected_intent))
    if similarity < threshold:
        raise AssertionError(
            f"Intent assertion failed.\n"
            f"  Expected intent : {expected_intent!r}\n"
            f"  Cosine similarity: {similarity:.3f} (threshold: {threshold})\n"
            f"  Response preview : {response[:200]!r}"
        )


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    mag_a = sum(x**2 for x in a) ** 0.5
    mag_b = sum(x**2 for x in b) ** 0.5
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)
