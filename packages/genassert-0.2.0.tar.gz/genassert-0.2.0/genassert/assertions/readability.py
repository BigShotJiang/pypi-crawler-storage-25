"""
assert_readability: Verify LLM response meets a reading level / complexity target.

Uses Flesch Reading Ease and Flesch-Kincaid Grade Level — two industry-standard
readability formulas. Zero external dependencies.

Flesch Reading Ease:
  90–100  Very easy (5th grade)
  70–90   Easy (6th grade)
  60–70   Standard (7–8th grade)
  50–60   Fairly difficult (high school)
  30–50   Difficult (college)
  0–30    Very difficult (professional/academic)

Flesch-Kincaid Grade Level:
  Approximate US school grade level (e.g. 8 = 8th grade).
"""

from __future__ import annotations
import re


def assert_readability(
    response: str,
    min_ease: float | None = None,
    max_ease: float | None = None,
    max_grade: float | None = None,
    min_grade: float | None = None,
) -> dict[str, float]:
    """
    Assert that `response` meets the specified readability constraints.

    Parameters
    ----------
    response:
        The LLM output to evaluate.
    min_ease:
        Minimum Flesch Reading Ease score (higher = easier to read).
        E.g. min_ease=60 ensures at most high-school difficulty.
    max_ease:
        Maximum Flesch Reading Ease score.
        E.g. max_ease=50 ensures the text is sufficiently technical.
    max_grade:
        Maximum Flesch-Kincaid Grade Level.
        E.g. max_grade=8 ensures response is readable by an 8th grader.
    min_grade:
        Minimum Flesch-Kincaid Grade Level.
        E.g. min_grade=12 ensures sufficiently advanced language.

    Returns
    -------
    dict with keys "ease" (float) and "grade" (float).

    Raises
    ------
    AssertionError
        If any readability constraint is violated.
    ValueError
        If no constraints are specified.

    Examples
    --------
    >>> assert_readability(response, min_ease=60)           # must be readable
    >>> assert_readability(response, max_grade=8)           # 8th-grade max
    >>> assert_readability(response, min_ease=30, max_grade=14)  # technical but not jargon
    """
    if all(v is None for v in (min_ease, max_ease, max_grade, min_grade)):
        raise ValueError("Specify at least one of: min_ease, max_ease, max_grade, min_grade")

    ease, grade = _flesch_scores(response)
    failures: list[str] = []

    if min_ease is not None and ease < min_ease:
        failures.append(f"Reading ease {ease:.1f} < min_ease {min_ease} (text is too complex)")
    if max_ease is not None and ease > max_ease:
        failures.append(f"Reading ease {ease:.1f} > max_ease {max_ease} (text is too simple)")
    if max_grade is not None and grade > max_grade:
        failures.append(f"Grade level {grade:.1f} > max_grade {max_grade} (text is too advanced)")
    if min_grade is not None and grade < min_grade:
        failures.append(f"Grade level {grade:.1f} < min_grade {min_grade} (text is too basic)")

    if failures:
        raise AssertionError(
            f"Readability assertion failed.\n"
            + "\n".join(f"  - {f}" for f in failures)
            + f"\n  Response preview: {response[:150]!r}"
        )

    return {"ease": ease, "grade": grade}


def _flesch_scores(text: str) -> tuple[float, float]:
    """Compute Flesch Reading Ease and Flesch-Kincaid Grade Level."""
    sentences = _count_sentences(text)
    words = _count_words(text)
    syllables = _count_syllables(text)

    if words == 0 or sentences == 0:
        return 0.0, 0.0

    words_per_sentence = words / sentences
    syllables_per_word = syllables / words

    ease = 206.835 - (1.015 * words_per_sentence) - (84.6 * syllables_per_word)
    grade = (0.39 * words_per_sentence) + (11.8 * syllables_per_word) - 15.59

    return round(ease, 2), round(max(0.0, grade), 2)


def _count_sentences(text: str) -> int:
    sentences = re.split(r"[.!?]+", text)
    return max(1, len([s for s in sentences if s.strip()]))


def _count_words(text: str) -> int:
    return len(re.findall(r"\b[a-zA-Z']+\b", text))


def _count_syllables(text: str) -> int:
    """Fast syllable counter using vowel-group heuristic."""
    total = 0
    for word in re.findall(r"\b[a-zA-Z']+\b", text.lower()):
        total += _syllables_in_word(word)
    return max(total, 1)


def _syllables_in_word(word: str) -> int:
    word = re.sub(r"[^a-z]", "", word)
    if not word:
        return 1
    # Remove trailing 'e' (usually silent)
    if word.endswith("e") and len(word) > 2:
        word = word[:-1]
    count = len(re.findall(r"[aeiou]+", word))
    return max(1, count)
