"""
assert_language: Verify LLM response is written in the expected language.

Uses character n-gram frequency profiles to detect language without
any external dependencies. Supports 20+ common languages.
"""

from __future__ import annotations
import re
import unicodedata

# Script/character-range based fast detection
_SCRIPT_HINTS: list[tuple[str, tuple[int, int]]] = [
    ("arabic",   (0x0600, 0x06FF)),
    ("hebrew",   (0x0590, 0x05FF)),
    ("chinese",  (0x4E00, 0x9FFF)),
    ("japanese", (0x3040, 0x30FF)),
    ("korean",   (0xAC00, 0xD7AF)),
    ("thai",     (0x0E00, 0x0E7F)),
    ("greek",    (0x0370, 0x03FF)),
    ("cyrillic", (0x0400, 0x04FF)),
    ("devanagari", (0x0900, 0x097F)),
]

# Common high-frequency words per language (stop-word fingerprint)
_STOPWORDS: dict[str, list[str]] = {
    "english":    ["the", "and", "is", "in", "to", "of", "a", "that", "it", "was"],
    "spanish":    ["el", "la", "de", "que", "en", "los", "se", "las", "un", "una"],
    "french":     ["le", "la", "les", "de", "et", "en", "un", "une", "du", "que"],
    "german":     ["der", "die", "das", "und", "in", "den", "von", "zu", "ist", "mit"],
    "portuguese": ["de", "da", "do", "que", "em", "os", "as", "um", "uma", "para"],
    "italian":    ["il", "la", "di", "che", "e", "un", "una", "in", "del", "per"],
    "dutch":      ["de", "het", "een", "van", "en", "in", "is", "dat", "op", "te"],
    "russian":    ["и", "в", "не", "на", "я", "что", "с", "он", "как", "это"],
    "polish":     ["i", "w", "nie", "to", "się", "na", "jest", "z", "że", "do"],
    "turkish":    ["bir", "bu", "ve", "da", "de", "için", "ile", "var", "ne", "mi"],
    "swedish":    ["och", "i", "en", "att", "det", "av", "på", "är", "för", "med"],
    "norwegian":  ["og", "i", "en", "er", "til", "av", "på", "et", "som", "for"],
    "danish":     ["og", "i", "en", "er", "til", "af", "på", "et", "som", "for"],
    "finnish":    ["ja", "on", "ei", "se", "että", "hän", "oli", "en", "niin", "jo"],
    "czech":      ["a", "je", "to", "v", "se", "na", "že", "z", "do", "s"],
    "hungarian":  ["a", "az", "és", "hogy", "nem", "van", "egy", "is", "de", "meg"],
    "romanian":   ["și", "în", "de", "că", "este", "la", "cu", "se", "nu", "din"],
    "indonesian": ["yang", "dan", "di", "ke", "dari", "ini", "itu", "untuk", "dengan", "ada"],
}

_LANG_ALIASES: dict[str, str] = {
    "en": "english", "es": "spanish", "fr": "french", "de": "german",
    "pt": "portuguese", "it": "italian", "nl": "dutch", "ru": "russian",
    "pl": "polish", "tr": "turkish", "sv": "swedish", "no": "norwegian",
    "da": "danish", "fi": "finnish", "cs": "czech", "hu": "hungarian",
    "ro": "romanian", "id": "indonesian",
    "ar": "arabic", "he": "hebrew", "zh": "chinese", "ja": "japanese",
    "ko": "korean", "th": "thai", "el": "greek", "hi": "devanagari",
}


def assert_language(
    response: str,
    expected_language: str,
    min_confidence: float = 0.3,
) -> str:
    """
    Assert that `response` is written in the expected language.

    Parameters
    ----------
    response:
        The LLM output to evaluate.
    expected_language:
        Language name (e.g. "english", "spanish", "french") or ISO 639-1
        code (e.g. "en", "es", "fr").
    min_confidence:
        Minimum confidence score (0–1) to accept the detection. Default 0.3.

    Returns
    -------
    str
        The detected language name.

    Raises
    ------
    AssertionError
        If the detected language doesn't match expected.
    ValueError
        If expected_language is not recognised.

    Examples
    --------
    >>> assert_language(response, "english")
    >>> assert_language(response, "fr")          # ISO code
    >>> assert_language(response, "spanish")
    """
    lang = expected_language.lower().strip()
    lang = _LANG_ALIASES.get(lang, lang)

    detected, confidence = _detect_language(response)

    if detected != lang:
        raise AssertionError(
            f"Language assertion failed.\n"
            f"  Expected language : {lang!r}\n"
            f"  Detected language : {detected!r} (confidence: {confidence:.2f})\n"
            f"  Response preview  : {response[:150]!r}"
        )
    if confidence < min_confidence:
        raise AssertionError(
            f"Language detected as {detected!r} but confidence too low.\n"
            f"  Confidence: {confidence:.2f} (min: {min_confidence})\n"
            f"  Response preview: {response[:150]!r}"
        )
    return detected


def _detect_language(text: str) -> tuple[str, float]:
    """Return (language_name, confidence) for `text`."""
    if not text.strip():
        return "unknown", 0.0

    # Fast path: script detection for non-Latin scripts
    for lang, (lo, hi) in _SCRIPT_HINTS:
        count = sum(1 for ch in text if lo <= ord(ch) <= hi)
        ratio = count / max(len(text), 1)
        if ratio > 0.2:
            return lang, min(1.0, ratio * 3)

    # Stopword frequency scoring for Latin-script languages
    words = set(re.findall(r"\b[a-zA-ZÀ-ÿ]+\b", text.lower()))
    scores: dict[str, float] = {}
    for lang, stopwords in _STOPWORDS.items():
        hits = sum(1 for w in stopwords if w in words)
        scores[lang] = hits / len(stopwords)

    if not scores:
        return "unknown", 0.0

    best = max(scores, key=lambda k: scores[k])
    best_score = scores[best]

    # Normalise against second-best to get relative confidence
    sorted_scores = sorted(scores.values(), reverse=True)
    second = sorted_scores[1] if len(sorted_scores) > 1 else 0.0
    confidence = best_score - second if best_score > 0 else 0.0

    return best, min(1.0, confidence * 5)
