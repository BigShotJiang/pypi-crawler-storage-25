"""
assert_tone: Verify the tone/style of an LLM response.

Supported tones: professional, casual, friendly, formal, neutral,
empathetic, assertive, humorous, concise.
"""

from __future__ import annotations

TONE_DESCRIPTORS: dict[str, list[str]] = {
    "professional": [
        "formal language", "business tone", "respectful", "clear", "professional"
    ],
    "casual": [
        "informal", "conversational", "relaxed", "everyday language", "casual"
    ],
    "friendly": [
        "warm", "approachable", "kind", "encouraging", "friendly"
    ],
    "formal": [
        "formal", "official", "structured", "proper", "academic"
    ],
    "neutral": [
        "neutral", "objective", "balanced", "unbiased", "impartial"
    ],
    "empathetic": [
        "empathetic", "understanding", "compassionate", "supportive", "caring"
    ],
    "assertive": [
        "assertive", "direct", "confident", "decisive", "clear"
    ],
    "humorous": [
        "funny", "witty", "playful", "humorous", "light-hearted"
    ],
    "concise": [
        "brief", "concise", "to the point", "succinct", "short"
    ],
}


def assert_tone(
    response: str,
    expected_tone: str,
    threshold: float = 0.65,
) -> None:
    """
    Assert that `response` matches the expected tone.

    Parameters
    ----------
    response:
        The LLM output to evaluate.
    expected_tone:
        One of: professional, casual, friendly, formal, neutral,
        empathetic, assertive, humorous, concise.
        Or a custom description like "formal and empathetic".
    threshold:
        Similarity threshold. Default 0.65.

    Raises
    ------
    AssertionError
        If the response does not match the expected tone.
    ValueError
        If the expected_tone is not a known tone and not a custom string.

    Examples
    --------
    >>> assert_tone(response, "professional")
    >>> assert_tone(response, "friendly and concise")
    """
    from genassert._embed import embed_text
    from genassert.assertions.intent import _cosine_similarity

    if expected_tone in TONE_DESCRIPTORS:
        descriptors = TONE_DESCRIPTORS[expected_tone]
        tone_description = f"text written in a {expected_tone} tone: " + ", ".join(descriptors)
    else:
        # Custom tone description
        tone_description = expected_tone

    similarity = _cosine_similarity(
        embed_text(response),
        embed_text(tone_description),
    )

    if similarity < threshold:
        raise AssertionError(
            f"Tone assertion failed.\n"
            f"  Expected tone    : {expected_tone!r}\n"
            f"  Cosine similarity: {similarity:.3f} (threshold: {threshold})\n"
            f"  Response preview : {response[:200]!r}"
        )
