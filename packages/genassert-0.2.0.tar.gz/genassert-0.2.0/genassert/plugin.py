"""
pytest plugin for genassert.

Auto-registered via entry_points in pyproject.toml.
Provides fixtures and marks for LLM tests.
"""

from __future__ import annotations
import pytest


def pytest_configure(config):
    config.addinivalue_line(
        "markers",
        "llm: mark test as an LLM semantic test (may call embedding APIs)",
    )
    config.addinivalue_line(
        "markers",
        "llm_slow: mark test as slow — uses local judge model inference",
    )


def pytest_addoption(parser):
    group = parser.getgroup("genassert")
    group.addoption(
        "--record-baselines",
        action="store_true",
        default=False,
        help="Record (or overwrite) golden baselines for all LLM tests.",
    )
    group.addoption(
        "--llm-threshold",
        type=float,
        default=None,
        help="Override default similarity threshold for all assertions.",
    )
    group.addoption(
        "--skip-llm",
        action="store_true",
        default=False,
        help="Skip all tests marked with @pytest.mark.llm.",
    )


def pytest_collection_modifyitems(config, items):
    if config.getoption("--skip-llm"):
        skip_llm = pytest.mark.skip(reason="--skip-llm flag set")
        for item in items:
            if "llm" in item.keywords:
                item.add_marker(skip_llm)


@pytest.fixture
def llm_record(request):
    """
    Fixture: returns True if --record-baselines flag is set.

    Usage:
        def test_something(llm_record):
            response = my_llm_call()
            if llm_record:
                record_baseline("my_test", response)
            else:
                compare_baseline("my_test", response)
    """
    return request.config.getoption("--record-baselines", default=False)


@pytest.fixture
def llm_threshold(request):
    """
    Fixture: returns the global threshold override (or None).
    """
    return request.config.getoption("--llm-threshold", default=None)
