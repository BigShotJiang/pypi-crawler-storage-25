"""
genassert — pytest-native semantic testing for generative AI applications.

Drop-in pytest plugin. No servers. No SaaS. No config.
Works with OpenAI, Anthropic, LiteLLM, or any LLM client.
"""

from genassert.assertions.intent import assert_intent
from genassert.assertions.tone import assert_tone
from genassert.assertions.hallucination import assert_no_hallucination
from genassert.assertions.budget import assert_token_budget
from genassert.assertions.schema import assert_schema
from genassert.assertions.similarity import assert_similar_to
from genassert.assertions.language import assert_language
from genassert.assertions.pii import assert_no_pii, PIIMatch
from genassert.assertions.readability import assert_readability
from genassert.assertions.sentiment import assert_sentiment
from genassert.baseline import record_baseline, compare_baseline
from genassert.judge import LocalJudge

__version__ = "0.2.0"
__all__ = [
    # Core semantic assertions
    "assert_intent",
    "assert_tone",
    "assert_no_hallucination",
    "assert_similar_to",
    # Structural assertions
    "assert_token_budget",
    "assert_schema",
    # Advanced assertions (new in 0.2.0)
    "assert_language",
    "assert_no_pii",
    "assert_readability",
    "assert_sentiment",
    # Types
    "PIIMatch",
    # Baseline regression
    "record_baseline",
    "compare_baseline",
    # Local judge
    "LocalJudge",
]
