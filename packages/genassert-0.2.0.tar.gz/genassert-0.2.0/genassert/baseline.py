"""
Golden baseline recording and regression comparison.

Usage:
    # First run — record the baseline
    record_baseline("my_test", response)

    # Subsequent runs — compare against it
    compare_baseline("my_test", response, threshold=0.85)
"""

from __future__ import annotations
import json
import os
import pathlib
from datetime import datetime, timezone


_DEFAULT_DIR = os.environ.get("GENASSERT_BASELINE_DIR", ".genassert_baselines")


def record_baseline(
    name: str,
    response: str,
    baseline_dir: str = _DEFAULT_DIR,
    overwrite: bool = False,
) -> pathlib.Path:
    """
    Record `response` as the golden baseline for `name`.

    Parameters
    ----------
    name:
        Unique identifier for this test (e.g. "test_summarizer_concise").
    response:
        The LLM output to record as the golden reference.
    baseline_dir:
        Directory to store baseline files. Default: .genassert_baselines/
    overwrite:
        If True, overwrite existing baseline. Default False (raises if exists).

    Returns
    -------
    pathlib.Path
        Path to the saved baseline file.

    Raises
    ------
    FileExistsError
        If a baseline for `name` already exists and overwrite=False.
    """
    path = _baseline_path(name, baseline_dir)
    path.parent.mkdir(parents=True, exist_ok=True)

    if path.exists() and not overwrite:
        raise FileExistsError(
            f"Baseline {name!r} already exists at {path}.\n"
            f"Use overwrite=True or delete the file to re-record."
        )

    data = {
        "name": name,
        "response": response,
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "version": 1,
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def compare_baseline(
    name: str,
    response: str,
    threshold: float = 0.82,
    baseline_dir: str = _DEFAULT_DIR,
    auto_record: bool = False,
) -> float:
    """
    Compare `response` against the recorded golden baseline for `name`.

    Parameters
    ----------
    name:
        The baseline name (must match a previously recorded baseline).
    response:
        The current LLM output to compare.
    threshold:
        Cosine similarity threshold. Default 0.82.
    baseline_dir:
        Directory where baselines are stored.
    auto_record:
        If True and no baseline exists, record this response as the baseline
        (useful for first-run CI).

    Returns
    -------
    float
        The cosine similarity score.

    Raises
    ------
    FileNotFoundError
        If no baseline exists for `name` and auto_record=False.
    AssertionError
        If similarity falls below threshold.
    """
    path = _baseline_path(name, baseline_dir)

    if not path.exists():
        if auto_record:
            record_baseline(name, response, baseline_dir)
            return 1.0
        raise FileNotFoundError(
            f"No baseline found for {name!r}.\n"
            f"Run record_baseline({name!r}, response) first.\n"
            f"Expected path: {path}"
        )

    data = json.loads(path.read_text(encoding="utf-8"))
    reference = data["response"]

    from genassert._embed import embed_text
    from genassert.assertions.intent import _cosine_similarity

    score = _cosine_similarity(embed_text(response), embed_text(reference))

    if score < threshold:
        raise AssertionError(
            f"Baseline regression detected for {name!r}.\n"
            f"  Similarity: {score:.3f} (threshold: {threshold})\n"
            f"  Recorded at: {data.get('recorded_at', 'unknown')}\n"
            f"  Current response : {response[:150]!r}\n"
            f"  Baseline response: {reference[:150]!r}\n"
            f"  Hint: if this is intentional, re-record with overwrite=True."
        )

    return score


def _baseline_path(name: str, baseline_dir: str) -> pathlib.Path:
    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in name)
    return pathlib.Path(baseline_dir) / f"{safe_name}.json"
