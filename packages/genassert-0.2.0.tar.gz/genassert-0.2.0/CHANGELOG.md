# Changelog

## [0.2.0] — 2026-04-06

### Added
- `assert_language` — detect and assert response language (20+ languages, ISO 639-1 codes, zero deps)
- `assert_no_pii` — detect PII leakage: emails, phones, SSNs, credit cards, IPs, IBANs, passports
- `assert_readability` — Flesch Reading Ease and Flesch-Kincaid Grade Level assertions
- `assert_sentiment` — lexicon-based positive/negative/neutral sentiment detection with negation handling
- `PIIMatch` dataclass — structured PII match result with type, value, and position
- Package renamed from `assertllm` → `genassert` for broader generative AI coverage

### Changed
- Version bumped to 0.2.0
- All env vars renamed: `ASSERTLLM_*` → `GENASSERT_*`
- Baseline directory default: `.assertllm_baselines` → `.genassert_baselines`

## [0.1.0] — 2026-04-06

### Added
- `assert_intent` — semantic intent matching via cosine similarity
- `assert_tone` — tone/style detection (professional, casual, friendly, etc.)
- `assert_no_hallucination` — contradiction detection against known facts
- `assert_token_budget` — token count budget assertion (approx/tiktoken/chars)
- `assert_schema` — Pydantic model and JSON Schema validation
- `assert_similar_to` — golden baseline similarity comparison
- `record_baseline` / `compare_baseline` — baseline regression testing
- `LocalJudge` — zero-cost local LLM judge (transformers / llama-cpp / embeddings)
- pytest plugin with `--record-baselines`, `--llm-threshold`, `--skip-llm` flags
- `llm_record` and `llm_threshold` pytest fixtures
- Three embedding backends: sentence-transformers, OpenAI, hash fallback
- Full test suite with offline tests (no external deps required)
