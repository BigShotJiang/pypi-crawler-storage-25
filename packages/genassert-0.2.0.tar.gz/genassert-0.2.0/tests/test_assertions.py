"""
Tests for genassert core assertions.

These tests use the hash-based fallback embedder (no external deps needed)
so they run fully offline in CI. For real semantic accuracy, install
sentence-transformers: pip install genassert[local]
"""

import os
import pytest

# Force fallback embedder for tests (no sentence-transformers required)
os.environ.setdefault("GENASSERT_EMBED_BACKEND", "fallback")

from genassert import (
    assert_intent,
    assert_tone,
    assert_no_hallucination,
    assert_token_budget,
    assert_schema,
    assert_similar_to,
    assert_language,
    assert_no_pii,
    assert_readability,
    assert_sentiment,
    record_baseline,
    compare_baseline,
)


# ─────────────────────────────────────────────────────────────────────────────
# assert_token_budget — deterministic, no embedding needed
# ─────────────────────────────────────────────────────────────────────────────

class TestTokenBudget:
    def test_within_budget(self):
        response = "This is a short response."
        assert_token_budget(response, max_tokens=100)

    def test_exceeds_budget(self):
        response = " ".join(["word"] * 200)
        with pytest.raises(AssertionError, match="Token budget exceeded"):
            assert_token_budget(response, max_tokens=50)

    def test_chars_method(self):
        response = "a" * 400
        assert_token_budget(response, max_tokens=200, tokenizer="chars")

    def test_chars_method_exceeds(self):
        response = "a" * 2000
        with pytest.raises(AssertionError):
            assert_token_budget(response, max_tokens=100, tokenizer="chars")

    def test_exact_boundary(self):
        # 10 words * 1.3 = 13 tokens
        response = "one two three four five six seven eight nine ten"
        assert_token_budget(response, max_tokens=13)

    def test_empty_response(self):
        assert_token_budget("", max_tokens=1)


# ─────────────────────────────────────────────────────────────────────────────
# assert_schema — deterministic, no embedding needed
# ─────────────────────────────────────────────────────────────────────────────

class TestSchema:
    def test_valid_json_dict(self):
        response = '{"name": "Alice", "age": 30}'
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["name", "age"],
        }
        result = assert_schema(response, schema)
        assert result["name"] == "Alice"

    def test_invalid_json(self):
        with pytest.raises(AssertionError, match="not valid JSON"):
            assert_schema("not json at all", {"type": "object"})

    def test_missing_required_field(self):
        response = '{"name": "Alice"}'
        schema = {
            "type": "object",
            "properties": {"name": {}, "age": {}},
            "required": ["name", "age"],
        }
        with pytest.raises(AssertionError):
            assert_schema(response, schema)

    def test_pydantic_model(self):
        try:
            from pydantic import BaseModel

            class User(BaseModel):
                name: str
                age: int

            response = '{"name": "Bob", "age": 25}'
            result = assert_schema(response, User)
            assert result.name == "Bob"
            assert result.age == 25
        except ImportError:
            pytest.skip("pydantic not installed")

    def test_pydantic_validation_error(self):
        try:
            from pydantic import BaseModel

            class User(BaseModel):
                name: str
                age: int

            response = '{"name": "Bob", "age": "not-a-number"}'
            with pytest.raises(AssertionError, match="Schema validation failed"):
                assert_schema(response, User)
        except ImportError:
            pytest.skip("pydantic not installed")


# ─────────────────────────────────────────────────────────────────────────────
# Baseline — deterministic (uses hash-based fallback embedder)
# ─────────────────────────────────────────────────────────────────────────────

class TestBaseline:
    def test_record_and_compare_identical(self, tmp_path):
        response = "The sky is blue and the grass is green."
        record_baseline("test_identical", response, baseline_dir=str(tmp_path))
        score = compare_baseline(
            "test_identical", response, baseline_dir=str(tmp_path)
        )
        assert score == pytest.approx(1.0, abs=1e-4)

    def test_overwrite_false_raises(self, tmp_path):
        response = "Hello world."
        record_baseline("test_overwrite", response, baseline_dir=str(tmp_path))
        with pytest.raises(FileExistsError):
            record_baseline(
                "test_overwrite", response, baseline_dir=str(tmp_path), overwrite=False
            )

    def test_overwrite_true_succeeds(self, tmp_path):
        response = "Hello world."
        record_baseline("test_overwrite2", response, baseline_dir=str(tmp_path))
        record_baseline(
            "test_overwrite2", "Different response.", baseline_dir=str(tmp_path), overwrite=True
        )

    def test_missing_baseline_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            compare_baseline("nonexistent", "some response", baseline_dir=str(tmp_path))

    def test_auto_record(self, tmp_path):
        response = "Auto recorded response."
        score = compare_baseline(
            "auto_test", response, baseline_dir=str(tmp_path), auto_record=True
        )
        assert score == pytest.approx(1.0, abs=1e-4)


# ─────────────────────────────────────────────────────────────────────────────
# Embedding-based assertions (use fallback — structural tests only)
# Note: with fallback embedder, similarity scores are hash-based and won't
# reflect real semantics. These tests validate the assertion machinery.
# ─────────────────────────────────────────────────────────────────────────────

class TestAssertSimilarTo:
    def test_identical_strings_pass(self):
        text = "The quick brown fox jumps over the lazy dog."
        score = assert_similar_to(text, text, threshold=0.99)
        assert score == pytest.approx(1.0, abs=1e-4)

    def test_threshold_negative_always_passes(self):
        # Fallback embedder can produce negative cosine values, so use -1.0
        assert_similar_to("anything", "something else", threshold=-1.0)

    def test_threshold_one_fails_for_different(self):
        with pytest.raises(AssertionError):
            assert_similar_to("hello", "goodbye", threshold=1.0)

    def test_custom_message(self):
        with pytest.raises(AssertionError, match="custom message"):
            assert_similar_to("a", "b", threshold=1.0, message="custom message")


class TestAssertIntent:
    def test_threshold_negative_always_passes(self):
        assert_intent("any response", "any intent", threshold=-1.0)

    def test_threshold_one_on_identical(self):
        text = "a summary of a scientific paper about climate change"
        assert_intent(text, text, threshold=0.99)

    def test_threshold_one_fails_for_different(self):
        with pytest.raises(AssertionError, match="Intent assertion failed"):
            assert_intent("hello world", "a Python code snippet", threshold=1.0)


class TestAssertTone:
    def test_threshold_negative_always_passes(self):
        # Fallback embedder can produce negative cosine values, so use -1.0
        assert_tone("any text", "professional", threshold=-1.0)

    def test_custom_tone_description(self):
        assert_tone("any text", "warm and supportive", threshold=-1.0)

    def test_fails_above_threshold(self):
        with pytest.raises(AssertionError, match="Tone assertion failed"):
            assert_tone("hello", "professional", threshold=1.0)


# ─────────────────────────────────────────────────────────────────────────────
# assert_language — zero-dependency language detection
# ─────────────────────────────────────────────────────────────────────────────

class TestAssertLanguage:
    def test_english_detected(self):
        text = "The quick brown fox jumps over the lazy dog and the cat sat on the mat."
        assert_language(text, "english")

    def test_spanish_detected(self):
        text = "El gato se sienta en la alfombra y el perro corre por el parque."
        assert_language(text, "spanish")

    def test_french_detected(self):
        text = "Le chat est assis sur le tapis et le chien court dans le parc."
        assert_language(text, "french")

    def test_iso_code_en(self):
        text = "The quick brown fox jumps over the lazy dog and the cat sat on the mat."
        assert_language(text, "en")

    def test_iso_code_es(self):
        text = "El gato se sienta en la alfombra y el perro corre por el parque."
        assert_language(text, "es")

    def test_arabic_script_detected(self):
        text = "مرحبا بالعالم هذا نص عربي"
        assert_language(text, "arabic")

    def test_chinese_script_detected(self):
        text = "你好世界这是中文文字"
        assert_language(text, "chinese")

    def test_wrong_language_fails(self):
        text = "The quick brown fox jumps over the lazy dog."
        with pytest.raises(AssertionError, match="Language assertion failed"):
            assert_language(text, "french")

    def test_unknown_language_code_falls_through(self):
        # German text detected as german, not english
        text = "Der schnelle braune Fuchs springt über den faulen Hund und die Katze."
        assert_language(text, "german")


# ─────────────────────────────────────────────────────────────────────────────
# assert_no_pii — PII detection
# ─────────────────────────────────────────────────────────────────────────────

class TestAssertNoPII:
    def test_clean_text_passes(self):
        text = "The weather today is sunny and warm. Please plan accordingly."
        result = assert_no_pii(text)
        assert result == []

    def test_email_detected(self):
        text = "Contact us at john.doe@example.com for more info."
        with pytest.raises(AssertionError, match="PII detected"):
            assert_no_pii(text)

    def test_ssn_detected(self):
        text = "Your SSN is 123-45-6789 as on file."
        with pytest.raises(AssertionError, match="PII detected"):
            assert_no_pii(text, checks=["ssn"])

    def test_credit_card_detected(self):
        text = "Card number: 4111 1111 1111 1111"
        with pytest.raises(AssertionError, match="PII detected"):
            assert_no_pii(text, checks=["credit_card"])

    def test_ip_address_detected(self):
        text = "The server IP is 192.168.1.100"
        with pytest.raises(AssertionError, match="PII detected"):
            assert_no_pii(text, checks=["ip_address"])

    def test_ip_allowed(self):
        text = "The server IP is 192.168.1.100"
        result = assert_no_pii(text, allow=["ip_address"])
        assert result == []

    def test_selective_checks(self):
        # Text has an email but we only check for SSN — should pass
        text = "Contact us at hello@example.com"
        result = assert_no_pii(text, checks=["ssn"])
        assert result == []

    def test_invalid_check_type_raises(self):
        with pytest.raises(ValueError, match="Unknown PII type"):
            assert_no_pii("text", checks=["fingerprint"])


# ─────────────────────────────────────────────────────────────────────────────
# assert_readability — Flesch scoring
# ─────────────────────────────────────────────────────────────────────────────

class TestAssertReadability:
    def test_simple_text_high_ease(self):
        text = "The cat sat on the mat. It was a big cat. The cat was red."
        scores = assert_readability(text, min_ease=60)
        assert scores["ease"] >= 60

    def test_no_constraints_raises(self):
        with pytest.raises(ValueError, match="Specify at least one"):
            assert_readability("some text")

    def test_min_ease_fails_on_complex(self):
        complex_text = (
            "The epistemological ramifications of contemporaneous sociolinguistic "
            "paradigms necessitate a comprehensive reconceptualization of the "
            "hermeneutical frameworks underlying poststructuralist discourse."
        )
        with pytest.raises(AssertionError, match="too complex"):
            assert_readability(complex_text, min_ease=80)

    def test_max_grade_passes(self):
        text = "The dog ran fast. He was happy. The sun was bright."
        scores = assert_readability(text, max_grade=6)
        assert scores["grade"] <= 6

    def test_returns_scores_dict(self):
        text = "This is a test sentence with some words in it."
        scores = assert_readability(text, min_ease=0)
        assert "ease" in scores
        assert "grade" in scores
        assert isinstance(scores["ease"], float)
        assert isinstance(scores["grade"], float)

    def test_empty_text_does_not_crash(self):
        scores = assert_readability("", min_ease=-999)
        assert scores["ease"] == 0.0

    def test_max_ease_fails_when_too_simple(self):
        text = "Hi. Go. Run. Yes. No."
        with pytest.raises(AssertionError, match="too simple"):
            assert_readability(text, max_ease=30)


# ─────────────────────────────────────────────────────────────────────────────
# assert_sentiment — lexicon-based sentiment
# ─────────────────────────────────────────────────────────────────────────────

class TestAssertSentiment:
    def test_positive_text(self):
        text = "This is an excellent, wonderful, and amazing product. I love it!"
        scores = assert_sentiment(text, "positive")
        assert scores["score"] > 0

    def test_negative_text(self):
        text = "This is a terrible, horrible, awful failure. I hate it completely."
        scores = assert_sentiment(text, "negative")
        assert scores["score"] < 0

    def test_neutral_text(self):
        text = "The document contains information about the process and the steps."
        scores = assert_sentiment(text, "neutral")

    def test_invalid_expected_raises(self):
        with pytest.raises(ValueError, match="must be 'positive'"):
            assert_sentiment("some text", "angry")

    def test_wrong_sentiment_fails(self):
        text = "This is an excellent, wonderful, and amazing product. I love it!"
        with pytest.raises(AssertionError, match="Sentiment assertion failed"):
            assert_sentiment(text, "negative")

    def test_returns_score_dict(self):
        text = "Great job, excellent work, very good!"
        result = assert_sentiment(text, "positive")
        assert "score" in result
        assert "label" in result
        assert "positive_weight" in result
        assert "negative_weight" in result

    def test_negation_flips_sentiment(self):
        # "not bad" should not be strongly negative
        text = "This is not bad at all, not terrible either."
        result = assert_sentiment(text, "neutral")
