from .fitsy import *

__doc__ = fitsy.__doc__
if hasattr(fitsy, "__all__"):
    __all__ = fitsy.__all__