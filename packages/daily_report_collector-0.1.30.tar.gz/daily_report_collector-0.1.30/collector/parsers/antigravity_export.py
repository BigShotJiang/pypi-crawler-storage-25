"""Antigravity conversation exporter — uses antigravity-history API directly (no CLI)."""

from __future__ import annotations

import hashlib
import json
import logging
from urllib.parse import unquote

logger = logging.getLogger("collector.antigravity_export")

# Cache: cascade_id → content_hash
_last_hashes: dict[str, str] = {}


def export_conversations() -> list[dict]:
    """Export Antigravity conversations via LanguageServer API (fast, no step download).

    Requires: pip install antigravity-history
    Requires: Antigravity IDE to be running

    Returns list of changed conversations with metadata.
    """
    try:
        from antigravity_history.discovery import discover_language_servers, find_all_endpoints
        from antigravity_history.api import get_all_trajectories, get_trajectory_steps
    except ImportError:
        logger.debug("antigravity-history not installed, skipping")
        return []

    try:
        servers = discover_language_servers()
        if not servers:
            logger.debug("No Antigravity LanguageServer found")
            return []

        endpoints = find_all_endpoints(servers)
        if not endpoints:
            logger.debug("No Antigravity endpoints available")
            return []
    except Exception as e:
        logger.debug("Antigravity discovery failed: %s", e)
        return []

    conversations = []

    for ep in endpoints:
        try:
            summaries = get_all_trajectories(ep["port"], ep["csrf"])
        except Exception:
            continue

        for cascade_id, info in summaries.items():
            title = info.get("summary", cascade_id[:8])
            step_count = info.get("stepCount", 0)
            last_modified = info.get("lastModifiedTime", "")
            status = info.get("status", "")
            created = info.get("createdTime", "")

            # Extract workspace
            workspace = ""
            workspaces = info.get("workspaces", [])
            if workspaces and isinstance(workspaces[0], dict):
                workspace = workspaces[0].get("workspaceFolderAbsoluteUri", "")

            # Build a summary hash to detect changes (based on step count + last modified)
            summary_key = f"{cascade_id}:{step_count}:{last_modified}"
            content_hash = hashlib.sha256(summary_key.encode()).hexdigest()[:16]

            if _last_hashes.get(cascade_id) == content_hash:
                continue
            _last_hashes[cascade_id] = content_hash

            # Build content: summary + try to get first few steps for preview
            lines = [
                f"# {title}",
                "",
                f"- **Cascade ID**: `{cascade_id}`",
                f"- **Steps**: {step_count}",
                f"- **Status**: {status}",
                f"- **Created**: {created}",
                f"- **Last Modified**: {last_modified}",
            ]
            if workspace:
                lines.append(f"- **Workspace**: {workspace}")
            lines.append("")

            # Try to get first few user messages as preview (with short timeout)
            try:
                steps = get_trajectory_steps(ep["port"], ep["csrf"], cascade_id, step_count=20)
                for step in steps[:20]:
                    step_type = step.get("type", "")
                    if step_type == "CORTEX_STEP_TYPE_USER_INPUT":
                        text = step.get("userInput", {}).get("userResponse", "")
                        if text:
                            lines.append(f"## User\n\n{text}\n")
                    elif step_type == "CORTEX_STEP_TYPE_PLANNER_RESPONSE":
                        text = step.get("plannerResponse", {}).get("response", "")
                        if text:
                            preview = text[:500] + "..." if len(text) > 500 else text
                            lines.append(f"## Assistant\n\n{preview}\n")
            except Exception:
                lines.append("*(Full conversation requires Antigravity to be running)*\n")

            content = "\n".join(lines)

            # Extract project name from workspace URI
            project_name = None
            if workspace:
                ws = unquote(workspace).replace("\\", "/").rstrip("/")
                if ws.startswith("file:///"):
                    ws = ws[7:] if ws[8:9] != ":" else ws[8:]
                project_name = ws.split("/")[-1] if ws else None

            conversations.append({
                "title": title,
                "cascade_id": cascade_id,
                "workspace": workspace,
                "project_name": project_name,
                "size": len(content),
                "content": content,
                "content_hash": content_hash,
            })

    if conversations:
        logger.info("Exported %d changed Antigravity conversations", len(conversations))
    return conversations
