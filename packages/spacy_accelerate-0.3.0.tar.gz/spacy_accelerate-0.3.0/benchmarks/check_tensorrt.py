#!/usr/bin/env python3
"""Quick TensorRT availability test."""

import sys

# Import spacy_accelerate to trigger automatic LD_LIBRARY_PATH configuration
try:
    import spacy_accelerate

    print(f"✅ spacy-accelerate version: {spacy_accelerate.__version__}")
except ImportError:
    print("⚠️ spacy-accelerate not found, skipping auto-configuration")


def check_tensorrt():
    """Check if TensorRT is available via ONNX Runtime."""
    print("=" * 60)
    print("TensorRT Availability Check")
    print("=" * 60)

    # 1. Check ONNX Runtime
    try:
        import onnxruntime as ort

        print(f"✅ ONNX Runtime version: {ort.__version__}")
    except ImportError:
        print("❌ ONNX Runtime not installed")
        return False

    # 2. List available providers
    providers = ort.get_available_providers()
    print("\n📋 Available Execution Providers:")
    for p in providers:
        print(f"   - {p}")

    # 3. Check TensorRT specifically
    if "TensorrtExecutionProvider" in providers:
        print("\n✅ TensorrtExecutionProvider is available!")
    else:
        print("\n❌ TensorrtExecutionProvider NOT available")
        print("\n🔍 Checking TensorRT libraries...")

        # Try to find libnvinfer
        import subprocess

        result = subprocess.run(["ldconfig", "-p"], capture_output=True, text=True)
        nvinfer_libs = [line for line in result.stdout.split("\n") if "nvinfer" in line]
        if nvinfer_libs:
            print("   Found TensorRT libraries:")
            for lib in nvinfer_libs[:5]:
                print(f"   {lib.strip()}")
        else:
            print("   ❌ No libnvinfer found in ldconfig")

        # Check LD_LIBRARY_PATH
        import os

        ld_path = os.environ.get("LD_LIBRARY_PATH", "")
        print(f"\n   LD_LIBRARY_PATH: {ld_path or '(not set)'}")

        # Try to find TensorRT via pip
        result = subprocess.run(["pip", "list"], capture_output=True, text=True)
        trt_packages = [
            line for line in result.stdout.split("\n") if "tensorrt" in line.lower()
        ]
        if trt_packages:
            print("\n   Installed TensorRT packages:")
            for pkg in trt_packages:
                print(f"   {pkg}")
        else:
            print("\n   ❌ No TensorRT pip packages found")
            print("\n💡 To install TensorRT:")
            print(
                "   pip install tensorrt tensorrt-cu12 tensorrt-cu12-bindings tensorrt-cu12-libs"
            )

        return False

    # 4. Quick inference test with TensorRT
    print("\n🧪 Running quick TensorRT inference test...")
    try:
        import numpy as np

        # Create minimal ONNX model
        from onnx import TensorProto, helper

        X = helper.make_tensor_value_info("X", TensorProto.FLOAT, [1, 3])
        Y = helper.make_tensor_value_info("Y", TensorProto.FLOAT, [1, 3])

        node = helper.make_node("Relu", ["X"], ["Y"])
        graph = helper.make_graph([node], "test", [X], [Y])
        model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 14)])

        import tempfile

        with tempfile.NamedTemporaryFile(suffix=".onnx", delete=False) as f:
            f.write(model.SerializeToString())
            model_path = f.name

        # Run with TensorRT
        sess_options = ort.SessionOptions()
        sess = ort.InferenceSession(
            model_path,
            sess_options,
            providers=["TensorrtExecutionProvider", "CUDAExecutionProvider"],
        )

        input_data = np.array([[1.0, -2.0, 3.0]], dtype=np.float32)
        output = sess.run(None, {"X": input_data})

        print(f"   Input:  {input_data}")
        print(f"   Output: {output[0]}")
        print("   ✅ TensorRT inference successful!")

        import os

        os.unlink(model_path)

        return True
    except Exception as e:
        print(f"   ❌ TensorRT inference failed: {e}")
        return False


if __name__ == "__main__":
    success = check_tensorrt()
    print("\n" + "=" * 60)
    sys.exit(0 if success else 1)
