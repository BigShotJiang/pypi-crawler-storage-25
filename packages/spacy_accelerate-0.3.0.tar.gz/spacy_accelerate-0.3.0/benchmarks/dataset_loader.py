"""Dataset loaders for spacy-accelerate benchmarks."""

import random
from pathlib import Path
from typing import List, Optional, Tuple

from tqdm import tqdm


def load_conll2003(split: str = "test") -> List[Tuple[str, List[dict]]]:
    """
    Load CoNLL-2003 NER dataset.

    Args:
        split: Dataset split - "train", "validation", or "test"

    Returns:
        List of (text, entities) tuples where entities is a list of
        {"start": int, "end": int, "label": str}
    """
    try:
        from datasets import load_dataset
    except ImportError:
        raise ImportError(
            "datasets library is required. Install with: pip install datasets"
        )

    print(f"Loading CoNLL-2003 (CoNLL++) {split} set...")
    # Use conllpp (corrected CoNLL-2003) with parquet revision to bypass script execution
    dataset = load_dataset("conllpp", split=split, revision="refs/convert/parquet")

    # CoNLL-2003 label mapping
    label_map = {
        0: "O",
        1: "B-PER",
        2: "I-PER",
        3: "B-ORG",
        4: "I-ORG",
        5: "B-LOC",
        6: "I-LOC",
        7: "B-MISC",
        8: "I-MISC",
    }

    samples = []
    for item in tqdm(dataset, desc="Processing CoNLL-2003"):
        tokens = item["tokens"]
        ner_tags = item["ner_tags"]

        # Reconstruct text and entity spans
        text_parts = []
        char_offset = 0
        token_starts = []

        for token in tokens:
            token_starts.append(char_offset)
            text_parts.append(token)
            char_offset += len(token) + 1  # +1 for space

        text = " ".join(text_parts)

        # Extract entities
        entities = []
        current_entity = None

        for i, (token, tag_id) in enumerate(zip(tokens, ner_tags)):
            tag = label_map[tag_id]

            if tag.startswith("B-"):
                # Save previous entity if exists
                if current_entity:
                    entities.append(current_entity)

                # Start new entity
                label = tag[2:]  # Remove "B-" prefix
                start = token_starts[i]
                end = start + len(token)
                current_entity = {"start": start, "end": end, "label": label}

            elif tag.startswith("I-") and current_entity:
                # Continue current entity
                label = tag[2:]
                if current_entity["label"] == label:
                    current_entity["end"] = token_starts[i] + len(token)
                else:
                    # Label mismatch, save and reset
                    entities.append(current_entity)
                    current_entity = None

            else:
                # O tag or I- without B-
                if current_entity:
                    entities.append(current_entity)
                    current_entity = None

        # Don't forget last entity
        if current_entity:
            entities.append(current_entity)

        samples.append((text, entities))

    print(f"Loaded {len(samples)} samples from CoNLL-2003 {split}")
    return samples


def generate_synthetic_texts(
    n_samples: int = 10000,
    min_words: int = 10,
    max_words: int = 100,
    seed: int = 42,
) -> List[str]:
    """
    Generate synthetic texts for speed benchmarking.

    Creates texts with realistic word distributions similar to Reddit comments.

    Args:
        n_samples: Number of texts to generate
        min_words: Minimum words per text
        max_words: Maximum words per text
        seed: Random seed for reproducibility

    Returns:
        List of generated texts
    """
    random.seed(seed)

    # Common English words and entities for realistic content
    common_words = [
        "the",
        "be",
        "to",
        "of",
        "and",
        "a",
        "in",
        "that",
        "have",
        "I",
        "it",
        "for",
        "not",
        "on",
        "with",
        "he",
        "as",
        "you",
        "do",
        "at",
        "this",
        "but",
        "his",
        "by",
        "from",
        "they",
        "we",
        "say",
        "her",
        "she",
        "or",
        "an",
        "will",
        "my",
        "one",
        "all",
        "would",
        "there",
        "their",
        "what",
        "so",
        "up",
        "out",
        "if",
        "about",
        "who",
        "get",
        "which",
        "go",
        "me",
        "think",
        "also",
        "could",
        "people",
        "very",
        "just",
        "know",
        "take",
        "time",
        "good",
        "some",
        "see",
        "come",
        "make",
        "like",
        "than",
        "then",
        "now",
        "look",
        "want",
        "give",
        "use",
        "find",
        "tell",
        "work",
        "first",
        "well",
        "way",
        "even",
        "new",
        "because",
        "any",
        "these",
        "two",
        "may",
        "after",
        "should",
        "most",
    ]

    # Named entities for NER testing
    person_names = [
        "John Smith",
        "Mary Johnson",
        "Robert Williams",
        "Patricia Brown",
        "Michael Jones",
        "Jennifer Davis",
        "David Miller",
        "Linda Wilson",
        "Steve Jobs",
        "Elon Musk",
        "Bill Gates",
        "Jeff Bezos",
    ]

    org_names = [
        "Apple",
        "Google",
        "Microsoft",
        "Amazon",
        "Facebook",
        "Tesla",
        "IBM",
        "Intel",
        "Netflix",
        "Twitter",
        "OpenAI",
        "Anthropic",
    ]

    loc_names = [
        "New York",
        "California",
        "London",
        "Paris",
        "Tokyo",
        "Berlin",
        "San Francisco",
        "Los Angeles",
        "Chicago",
        "Seattle",
        "Boston",
    ]

    texts = []
    for _ in tqdm(range(n_samples), desc="Generating synthetic texts"):
        n_words = random.randint(min_words, max_words)
        words = []

        for _ in range(n_words):
            r = random.random()
            if r < 0.85:
                # Common word
                words.append(random.choice(common_words))
            elif r < 0.90:
                # Person name
                words.append(random.choice(person_names))
            elif r < 0.95:
                # Organization
                words.append(random.choice(org_names))
            else:
                # Location
                words.append(random.choice(loc_names))

        text = " ".join(words)
        # Add some sentence structure
        text = text[0].upper() + text[1:]
        if not text.endswith("."):
            text += "."

        texts.append(text)

    print(f"Generated {len(texts)} synthetic texts")
    return texts


def load_reddit_sample(
    n_samples: int = 10000,
    cache_dir: Optional[Path] = None,
) -> List[str]:
    """
    Load Reddit comments sample for speed benchmarking.

    Uses the same approach as spaCy's official benchmarks.
    Falls back to synthetic data if Reddit dataset is unavailable.

    Args:
        n_samples: Number of comments to load
        cache_dir: Optional cache directory

    Returns:
        List of Reddit comment texts
    """
    try:
        from datasets import load_dataset

        print("Loading Reddit comments dataset...")
        # Use a subset of Reddit comments
        dataset = load_dataset(
            "reddit",
            split="train",
            streaming=True,
            trust_remote_code=True,
        )

        texts = []
        for item in tqdm(dataset, desc="Loading Reddit", total=n_samples):
            if "body" in item and item["body"]:
                text = item["body"].strip()
                if 10 < len(text.split()) < 200:  # Filter by length
                    texts.append(text)
                    if len(texts) >= n_samples:
                        break

        if len(texts) < n_samples:
            print(
                f"Only got {len(texts)} Reddit comments, supplementing with synthetic..."
            )
            synthetic = generate_synthetic_texts(n_samples - len(texts))
            texts.extend(synthetic)

        return texts

    except Exception as e:
        print(f"Failed to load Reddit dataset: {e}")
        print("Falling back to synthetic data...")
        return generate_synthetic_texts(n_samples)


def get_speed_benchmark_data(n_samples: int = 10000) -> List[str]:
    """
    Get data for speed benchmarking.

    Tries Reddit first, falls back to synthetic.

    Args:
        n_samples: Number of samples

    Returns:
        List of texts for benchmarking
    """
    try:
        return load_reddit_sample(n_samples)
    except Exception:
        return generate_synthetic_texts(n_samples)


def get_accuracy_benchmark_data() -> List[Tuple[str, List[dict]]]:
    """
    Get data for accuracy benchmarking.

    Returns:
        CoNLL-2003 test set with gold entities
    """
    return load_conll2003(split="test")


if __name__ == "__main__":
    # Test dataset loading
    print("Testing dataset loaders...")

    print("\n--- Synthetic texts ---")
    texts = generate_synthetic_texts(100)
    print(f"Sample: {texts[0][:100]}...")

    print("\n--- CoNLL-2003 ---")
    try:
        conll = load_conll2003("test")
        print(f"Sample text: {conll[0][0][:100]}...")
        print(f"Sample entities: {conll[0][1][:3]}")
    except Exception as e:
        print(f"Failed: {e}")

    print("\nDataset loading test complete!")
