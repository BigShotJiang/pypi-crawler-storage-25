#!/usr/bin/env bash
set -euo pipefail

OUTPUT_ROOT="${BENCHMARK_OUTPUT_DIR:-/artifacts}"
RUN_ID="${BENCHMARK_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
OUTPUT_DIR="${OUTPUT_ROOT%/}/${RUN_ID}"

mkdir -p "${OUTPUT_DIR}"

export PYTHONUNBUFFERED=1
export ORT_TENSORRT_CUDA_GRAPH_ENABLE="${ORT_TENSORRT_CUDA_GRAPH_ENABLE:-0}"
export TRT_LOGGER_LEVEL="${TRT_LOGGER_LEVEL:-ERROR}"
export ORT_LOGGING_LEVEL="${ORT_LOGGING_LEVEL:-3}"

echo "Benchmark artifacts will be written to: ${OUTPUT_DIR}"

cd /workspace
python3 benchmarks/benchmark.py --output-dir "${OUTPUT_DIR}" "$@" | tee "${OUTPUT_DIR}/full_benchmark.log"

echo
echo "Artifacts saved to: ${OUTPUT_DIR}"
