import gc
import json
import os
import re
import sys
import time
from datetime import datetime, timezone

import spacy
import torch

# Ensure we import from the local package
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import spacy_accelerate
from spacy_accelerate.core.discovery import find_transformer_shim, get_model_info

# Configuration
BATCH_SIZE = 128
MAX_SAMPLES = 2000
MODEL_NAME = "en_core_web_trf"
WARMUP_SECONDS = 5.0
PRIME_RUNS = 1
MEASURE_RUNS = 3
SUPPORTED_ARCHITECTURES = {"curated_transformer", "roberta", "bert", "xlm-roberta"}
NER_ONLY_DISABLED_COMPONENTS = ["tagger", "parser", "attribute_ruler", "lemmatizer"]


def load_data():
    """Load CoNLL-2003 data via dataset_loader."""
    try:
        from dataset_loader import load_conll2003

        samples = load_conll2003(split="test")
        if MAX_SAMPLES:
            samples = samples[:MAX_SAMPLES]
        texts = [s[0] for s in samples]
        return texts
    except (ImportError, ModuleNotFoundError):
        print("⚠️ dataset_loader.py not found. Using dummy data.")
        return ["Apple is looking at buying U.K. startup for $1 billion."] * 100


def get_entities(doc):
    """Extract entity spans and labels for comparison."""
    return set((ent.start_char, ent.end_char, ent.label_) for ent in doc.ents)


def model_slug(model_name):
    """Return a filesystem-safe slug for a spaCy model name."""
    return re.sub(r"[^a-zA-Z0-9._-]+", "_", model_name)


def result_filename(model_name, config_name):
    """Per-model worker result path in the current working directory."""
    return f"benchmark_result_{model_slug(model_name)}_{config_name}.json"


def validate_model(model_name):
    """Validate that the requested spaCy model can be benchmarked."""
    try:
        nlp = spacy.load(model_name)
    except Exception as e:
        return {
            "ok": False,
            "model_name": model_name,
            "reason": f"Failed to load spaCy model: {e}",
        }

    if "transformer" not in nlp.pipe_names:
        return {
            "ok": False,
            "model_name": model_name,
            "reason": (
                "Pipeline has no 'transformer' component. "
                f"Available components: {nlp.pipe_names}"
            ),
        }

    try:
        shim = find_transformer_shim(nlp)
        info = get_model_info(shim)
    except Exception as e:
        return {
            "ok": False,
            "model_name": model_name,
            "reason": f"Failed to inspect transformer shim: {e}",
        }

    architecture = info.get("architecture", "unknown")
    if architecture not in SUPPORTED_ARCHITECTURES:
        return {
            "ok": False,
            "model_name": model_name,
            "reason": (
                f"Unsupported architecture '{architecture}'. "
                f"Supported: {sorted(SUPPORTED_ARCHITECTURES)}"
            ),
        }

    return {
        "ok": True,
        "model_name": model_name,
        "architecture": architecture,
        "num_layers": info.get("num_layers"),
        "hidden_size": info.get("hidden_size"),
        "num_heads": info.get("num_heads"),
    }


def discover_benchmark_models():
    """Auto-discover installed spaCy transformer models we can benchmark."""
    candidates = []
    skipped = []

    try:
        installed_models = spacy.util.get_installed_models()
    except Exception as e:
        return candidates, [
            {
                "ok": False,
                "model_name": "(discovery)",
                "reason": f"Failed to enumerate installed spaCy models: {e}",
            }
        ]

    for model_name in installed_models:
        validation = validate_model(model_name)
        if validation["ok"]:
            candidates.append(validation)
        else:
            skipped.append(validation)

    return candidates, skipped


def benchmark_config(
    name,
    nlp,
    texts,
    model_name,
    full_pipeline=True,
    n_process=1,
    use_amp=False,
    warmup_seconds=WARMUP_SECONDS,
    prime_runs=PRIME_RUNS,
    measure_runs=MEASURE_RUNS,
):
    """Run benchmark for a specific configuration."""
    print(
        f"\n🚀 Running: {name} (batch_size={BATCH_SIZE}, n_process={n_process}, amp={use_amp})"
    )
    if full_pipeline:
        print(f"   Benchmark runs {model_name} with full spaCy pipeline enabled.")
    else:
        disabled = ", ".join(NER_ONLY_DISABLED_COMPONENTS)
        print(
            f"   Benchmark runs {model_name} with {disabled} disabled."
        )

    # Warmup
    print(f"   WARMUP for {warmup_seconds:.0f} seconds...")
    warmup_batch = texts[:BATCH_SIZE]
    warmup_start = time.time()
    while time.time() - warmup_start < warmup_seconds:
        if use_amp:
            with torch.cuda.amp.autocast():
                _ = list(nlp.pipe(warmup_batch, batch_size=BATCH_SIZE))
        else:
            _ = list(nlp.pipe(warmup_batch, batch_size=BATCH_SIZE))

    if torch.cuda.is_available():
        torch.cuda.synchronize()

    # Measurement (ensure spawn for multiprocessing)
    if n_process > 1:
        import multiprocessing as mp

        try:
            mp.set_start_method("spawn", force=True)
        except RuntimeError:
            pass

    def run_full_pass():
        start_time = time.perf_counter()
        if use_amp:
            with torch.cuda.amp.autocast():
                docs = list(nlp.pipe(texts, batch_size=BATCH_SIZE, n_process=n_process))
        else:
            docs = list(nlp.pipe(texts, batch_size=BATCH_SIZE, n_process=n_process))

        if torch.cuda.is_available():
            torch.cuda.synchronize()
        duration = time.perf_counter() - start_time
        total_words = sum(len(doc) for doc in docs)
        return docs, duration, total_words

    prime_wps_runs = []
    for prime_idx in range(prime_runs):
        print(f"   PRIME pass {prime_idx + 1}/{prime_runs} (discarded)...")
        prime_docs, prime_duration, prime_words = run_full_pass()
        prime_wps = prime_words / prime_duration
        prime_wps_runs.append(prime_wps)
        print(f"   Prime pass {prime_idx + 1}: {prime_wps:,.0f} WPS")
        del prime_docs
        gc.collect()

    print(f"   MEASURE {measure_runs} full passes...")
    measured_runs = []
    entity_runs = []
    final_docs = None
    for run_idx in range(measure_runs):
        docs, duration, total_words = run_full_pass()
        wps = total_words / duration
        all_entities = [get_entities(doc) for doc in docs]
        measured_runs.append(wps)
        entity_runs.append(all_entities)
        final_docs = docs
        print(f"   Run {run_idx + 1}/{measure_runs}: {wps:,.0f} WPS")

    avg_wps = sum(measured_runs) / len(measured_runs)
    print(f"   ✅ Average: {avg_wps:,.0f} WPS")
    return {
        "name": name,
        "wps": avg_wps,
        "wps_runs": measured_runs,
        "prime_wps_runs": prime_wps_runs,
        "docs": final_docs,
        "entities": entity_runs[-1],
        "entity_runs": entity_runs,
        "full_pipeline": full_pipeline,
    }


def print_final_table(results, baseline_name="PyTorch Baseline"):
    """Print a beautiful results table."""
    print("\n" + render_results_table(results, baseline_name))


def summarize_results(results, baseline_name="PyTorch Baseline (FP32)"):
    """Build a serializable summary with speedup and accuracy."""
    if baseline_name not in results:
        baseline_wps = list(results.values())[0]["wps"]
        baseline_runs = list(results.values())[0]["entity_runs"]
    else:
        baseline = results[baseline_name]
        baseline_wps = baseline["wps"]
        baseline_runs = baseline["entity_runs"]

    summary = []
    for name, res in results.items():
        wps = res["wps"]
        speedup = wps / baseline_wps

        accuracy_runs = []
        for baseline_ents, current_ents in zip(baseline_runs, res["entity_runs"]):
            matches = 0
            total = len(baseline_ents)
            for b_ent, r_ent in zip(baseline_ents, current_ents):
                if b_ent == r_ent:
                    matches += 1
            accuracy_runs.append((matches / total) * 100 if total > 0 else 0)

        accuracy = sum(accuracy_runs) / len(accuracy_runs) if accuracy_runs else 0

        summary.append(
            {
                "name": name,
                "wps": wps,
                "wps_runs": res["wps_runs"],
                "speedup": speedup,
                "accuracy": accuracy,
                "accuracy_runs": accuracy_runs,
                "is_baseline": name == baseline_name,
            }
        )

    return summary


def render_results_table(results, baseline_name="PyTorch Baseline (FP32)"):
    """Render the console results table as a string."""
    lines = [
        "=" * 80,
        f"{'CONFIGURATION':<25} | {'WPS':>12} | {'SPEEDUP':>10} | {'ACCURACY %':>12}",
        "-" * 80,
    ]

    for item in summarize_results(results, baseline_name):
        speedup_str = f"{item['speedup']:.2f}x"
        accuracy_str = f"{item['accuracy']:.2f}%"
        display_name = f"* {item['name']}" if item["is_baseline"] else item["name"]
        lines.append(
            f"{display_name:<25} | {item['wps']:>12,.0f} | {speedup_str:>10} | {accuracy_str:>12}"
        )

    lines.append("=" * 80)
    return "\n".join(lines)


def save_summary(
    results,
    output_dir,
    model_name=MODEL_NAME,
    baseline_name="PyTorch Baseline (FP32)",
    full_pipeline=True,
    warmup_seconds=WARMUP_SECONDS,
    prime_runs=PRIME_RUNS,
    measure_runs=MEASURE_RUNS,
):
    """Persist benchmark summary to disk as JSON and Markdown."""
    os.makedirs(output_dir, exist_ok=True)

    summary = summarize_results(results, baseline_name)
    payload = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "model_name": model_name,
        "batch_size": BATCH_SIZE,
        "max_samples": MAX_SAMPLES,
        "full_pipeline": full_pipeline,
        "disabled_components": [] if full_pipeline else NER_ONLY_DISABLED_COMPONENTS,
        "warmup_seconds": warmup_seconds,
        "prime_runs": prime_runs,
        "measure_runs": measure_runs,
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "baseline_name": baseline_name,
        "results": summary,
    }

    json_path = os.path.join(output_dir, "benchmark_summary.json")
    with open(json_path, "w") as f:
        json.dump(payload, f, indent=2)

    md_lines = [
        "# Benchmark Results",
        "",
        f"- Generated (UTC): `{payload['generated_at_utc']}`",
        f"- Model: `{model_name}`",
        f"- Batch size: `{BATCH_SIZE}`",
        f"- Max samples: `{MAX_SAMPLES}`",
        f"- Pipeline mode: `{'full' if full_pipeline else 'ner-only'}`",
        (
            f"- Disabled components: `{', '.join(NER_ONLY_DISABLED_COMPONENTS)}`"
            if not full_pipeline
            else "- Disabled components: `(none)`"
        ),
        f"- Warmup: `{warmup_seconds:.0f}s`",
        f"- Prime passes (discarded): `{prime_runs}`",
        f"- Measured passes averaged: `{measure_runs}`",
        f"- GPU: `{payload['gpu']}`",
        "",
        "| Configuration | Avg WPS | WPS Runs | Speedup vs PyTorch | Avg Accuracy | Accuracy Runs |",
        "|---|---:|---|---:|---:|---|",
    ]
    for item in summary:
        wps_runs = ", ".join(f"{wps:,.0f}" for wps in item["wps_runs"])
        accuracy_runs = ", ".join(f"{acc:.2f}%" for acc in item["accuracy_runs"])
        md_lines.append(
            f"| {item['name']} | {item['wps']:,.0f} | {wps_runs} | {item['speedup']:.2f}x | {item['accuracy']:.2f}% | {accuracy_runs} |"
        )

    md_path = os.path.join(output_dir, "BENCHMARK_RESULTS.md")
    with open(md_path, "w") as f:
        f.write("\n".join(md_lines) + "\n")

    print(f"📁 Saved summary JSON to {json_path}")
    print(f"📁 Saved summary Markdown to {md_path}")


def save_multi_model_summary(model_summaries, skipped_models, output_dir, full_pipeline):
    """Persist an aggregate multi-model benchmark report."""
    payload = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "batch_size": BATCH_SIZE,
        "max_samples": MAX_SAMPLES,
        "full_pipeline": full_pipeline,
        "disabled_components": [] if full_pipeline else NER_ONLY_DISABLED_COMPONENTS,
        "models": model_summaries,
        "skipped_models": skipped_models,
    }

    json_path = os.path.join(output_dir, "multi_model_summary.json")
    with open(json_path, "w") as f:
        json.dump(payload, f, indent=2)

    md_lines = [
        "# Multi-Model Benchmark Results",
        "",
        f"- Generated (UTC): `{payload['generated_at_utc']}`",
        f"- Batch size: `{BATCH_SIZE}`",
        f"- Max samples: `{MAX_SAMPLES}`",
        f"- Pipeline mode: `{'full' if full_pipeline else 'ner-only'}`",
        (
            f"- Disabled components: `{', '.join(NER_ONLY_DISABLED_COMPONENTS)}`"
            if not full_pipeline
            else "- Disabled components: `(none)`"
        ),
        "",
    ]

    for item in model_summaries:
        md_lines.extend(
            [
                f"## {item['model_name']}",
                "",
                f"- Architecture: `{item.get('architecture', 'unknown')}`",
                "",
                "| Configuration | Avg WPS | WPS Runs | Speedup vs PyTorch | Avg Accuracy | Accuracy Runs |",
                "|---|---:|---|---:|---:|---|",
            ]
        )
        for result in item["results"]:
            wps_runs = ", ".join(f"{wps:,.0f}" for wps in result["wps_runs"])
            accuracy_runs = ", ".join(
                f"{acc:.2f}%" for acc in result["accuracy_runs"]
            )
            md_lines.append(
                f"| {result['name']} | {result['wps']:,.0f} | {wps_runs} | "
                f"{result['speedup']:.2f}x | {result['accuracy']:.2f}% | {accuracy_runs} |"
            )
        md_lines.append("")

    if skipped_models:
        md_lines.extend(["## Skipped Models", ""])
        for item in skipped_models:
            md_lines.append(f"- `{item['model_name']}`: {item['reason']}")
        md_lines.append("")

    md_path = os.path.join(output_dir, "MULTI_MODEL_RESULTS.md")
    with open(md_path, "w") as f:
        f.write("\n".join(md_lines))

    print(f"📁 Saved multi-model JSON to {json_path}")
    print(f"📁 Saved multi-model Markdown to {md_path}")


def run_worker(
    config_name,
    model_name,
    full_pipeline,
    warmup_seconds,
    prime_runs,
    measure_runs,
):
    """Worker function to run a single benchmark configuration."""
    if torch.cuda.is_available():
        spacy.require_gpu()

    texts = load_data()

    # Common load function
    def get_nlp():
        if full_pipeline:
            return spacy.load(model_name)
        return spacy.load(model_name, disable=NER_ONLY_DISABLED_COMPONENTS)

    result = None

    try:
        if config_name == "pytorch_fp32":
            nlp = get_nlp()
            result = benchmark_config(
                "PyTorch Baseline (FP32)",
                nlp,
                texts,
                model_name=model_name,
                full_pipeline=full_pipeline,
                warmup_seconds=warmup_seconds,
                prime_runs=prime_runs,
                measure_runs=measure_runs,
            )

        elif config_name == "pytorch_fp16":
            nlp = get_nlp()
            result = benchmark_config(
                "PyTorch Baseline (FP16)",
                nlp,
                texts,
                model_name=model_name,
                full_pipeline=full_pipeline,
                use_amp=True,
                warmup_seconds=warmup_seconds,
                prime_runs=prime_runs,
                measure_runs=measure_runs,
            )

        elif config_name == "cuda_fp32":
            nlp = get_nlp()
            nlp = spacy_accelerate.optimize(
                nlp,
                provider="cuda",
                precision="fp32",
                max_batch_size=256,
                fixed_batch_size=BATCH_SIZE,
            )
            result = benchmark_config(
                "CUDA FP32",
                nlp,
                texts,
                model_name=model_name,
                full_pipeline=full_pipeline,
                warmup_seconds=warmup_seconds,
                prime_runs=prime_runs,
                measure_runs=measure_runs,
            )

        elif config_name == "cuda_fp16":
            nlp = get_nlp()
            nlp = spacy_accelerate.optimize(
                nlp,
                provider="cuda",
                precision="fp16",
                max_batch_size=256,
                fixed_batch_size=BATCH_SIZE,
            )
            result = benchmark_config(
                "CUDA FP16",
                nlp,
                texts,
                model_name=model_name,
                full_pipeline=full_pipeline,
                warmup_seconds=warmup_seconds,
                prime_runs=prime_runs,
                measure_runs=measure_runs,
            )

        elif config_name == "tensorrt_fp32":
            nlp = get_nlp()
            nlp = spacy_accelerate.optimize(
                nlp,
                provider="tensorrt",
                precision="fp32",
                max_batch_size=256,
                fixed_batch_size=BATCH_SIZE,
                align_seq_length=16,
            )
            result = benchmark_config(
                "TensorRT FP32",
                nlp,
                texts,
                model_name=model_name,
                full_pipeline=full_pipeline,
                warmup_seconds=warmup_seconds,
                prime_runs=prime_runs,
                measure_runs=measure_runs,
            )

        elif config_name == "tensorrt_fp16":
            nlp = get_nlp()
            nlp = spacy_accelerate.optimize(
                nlp,
                provider="tensorrt",
                precision="fp16",
                max_batch_size=256,
                fixed_batch_size=BATCH_SIZE,
                align_seq_length=16,
            )
            result = benchmark_config(
                "TensorRT FP16",
                nlp,
                texts,
                model_name=model_name,
                full_pipeline=full_pipeline,
                warmup_seconds=warmup_seconds,
                prime_runs=prime_runs,
                measure_runs=measure_runs,
            )

    except Exception as e:
        print(f"Error in worker {config_name}: {e}")
        sys.exit(1)

    # Print results in a format parsable by the orchestrator
    # We use a special marker
    if result:
        import json

        # remove docs/entities from json output to avoid huge stdout, we only need stats for now?
        # actually the original script printed the table at the end.
        # Let's just output the WPS and entities for accuracy calculation?
        # Entities are too big to pass via stdout easily.
        # Let's save result to a temporary file.
        output_file = result_filename(model_name, config_name)

        # Serialize entities as list of lists
        serializable_entities = [list(ents) for ents in result["entities"]]

        data = {
            "name": result["name"],
            "wps": result["wps"],
            "wps_runs": result["wps_runs"],
            "prime_wps_runs": result["prime_wps_runs"],
            "full_pipeline": result["full_pipeline"],
            "entities": serializable_entities,
            "entity_runs": [
                [list(ents) for ents in entity_run]
                for entity_run in result["entity_runs"]
            ],
        }
        with open(output_file, "w") as f:
            json.dump(data, f)
        print(f"Result saved to {output_file}")


def main():
    import argparse
    import subprocess

    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", type=str, help="Run specific worker config")
    parser.add_argument(
        "--model-name",
        type=str,
        help="Run worker for a specific spaCy model name.",
    )
    parser.add_argument(
        "--models",
        nargs="+",
        default=None,
        help="One or more spaCy model names to benchmark. Defaults to all installed benchmarkable models.",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="artifacts/benchmarks/local/latest",
        help="Directory for the saved JSON/Markdown benchmark summary.",
    )
    parser.add_argument(
        "--warmup-seconds",
        type=float,
        default=WARMUP_SECONDS,
        help="Warmup duration before priming/measured passes.",
    )
    parser.add_argument(
        "--prime-runs",
        type=int,
        default=PRIME_RUNS,
        help="Number of discarded full priming passes before measurement.",
    )
    parser.add_argument(
        "--measure-runs",
        type=int,
        default=MEASURE_RUNS,
        help="Number of measured full passes to average.",
    )
    parser.add_argument(
        "--ner-only",
        action="store_true",
        help="Measure transformer + NER only by disabling tagger, parser, attribute_ruler, and lemmatizer.",
    )
    args = parser.parse_args()
    full_pipeline = not args.ner_only

    if args.worker:
        if not args.model_name:
            raise SystemExit("--worker requires --model-name")
        run_worker(
            args.worker,
            model_name=args.model_name,
            full_pipeline=full_pipeline,
            warmup_seconds=args.warmup_seconds,
            prime_runs=args.prime_runs,
            measure_runs=args.measure_runs,
        )
        return

    # Orchestrator mode
    if torch.cuda.is_available():
        print(f"🖥️  GPU: {torch.cuda.get_device_name(0)}")

    configs = [
        "pytorch_fp32",
        "pytorch_fp16",
        "cuda_fp32",
        "cuda_fp16",
        "tensorrt_fp32",
        "tensorrt_fp16",
    ]

    os.makedirs(args.output_dir, exist_ok=True)
    model_summaries = []
    skipped_models = []

    if args.models is None:
        discovered_models, discovery_skips = discover_benchmark_models()
        skipped_models.extend(discovery_skips)
        models_to_run = [item["model_name"] for item in discovered_models]
        if not models_to_run:
            print("❌ No installed benchmarkable spaCy transformer models were found.")
            if skipped_models:
                for item in skipped_models:
                    print(f"   - {item['model_name']}: {item['reason']}")
            raise SystemExit(1)

        print("Auto-discovered benchmarkable models:")
        for item in discovered_models:
            print(
                f"   - {item['model_name']} "
                f"({item['architecture']}, "
                f"layers={item['num_layers']}, hidden={item['hidden_size']}, "
                f"heads={item['num_heads']})"
            )
    else:
        models_to_run = args.models

    for model_name in models_to_run:
        print("\n" + "#" * 80)
        print(f"MODEL: {model_name}")
        print("#" * 80)

        validation = validate_model(model_name)
        if not validation["ok"]:
            print(f"⏭️  Skipping {model_name}: {validation['reason']}")
            skipped_models.append(validation)
            continue

        print(
            "Architecture: "
            f"{validation['architecture']} "
            f"(layers={validation['num_layers']}, hidden={validation['hidden_size']}, "
            f"heads={validation['num_heads']})"
        )

        all_results = {}
        for config in configs:
            print(f"\nStopped previous processes. Starting {config} for {model_name}...")
            worker_result_path = result_filename(model_name, config)
            try:
                subprocess.check_call(
                    [
                        sys.executable,
                        __file__,
                        "--worker",
                        config,
                        "--model-name",
                        model_name,
                        "--warmup-seconds",
                        str(args.warmup_seconds),
                        "--prime-runs",
                        str(args.prime_runs),
                        "--measure-runs",
                        str(args.measure_runs),
                        * (["--ner-only"] if args.ner_only else []),
                    ]
                )

                with open(worker_result_path, "r") as f:
                    data = json.load(f)
                    data["entities"] = [
                        set(tuple(e) for e in ents) for ents in data["entities"]
                    ]
                    data["entity_runs"] = [
                        [set(tuple(e) for e in ents) for ents in entity_run]
                        for entity_run in data["entity_runs"]
                    ]
                    all_results[data["name"]] = data

            except subprocess.CalledProcessError:
                print(f"❌ Benchmark {config} failed for {model_name}")
            except Exception as e:
                print(f"❌ Error collecting results for {model_name}/{config}: {e}")
            finally:
                if os.path.exists(worker_result_path):
                    os.remove(worker_result_path)

        if not all_results:
            skipped_models.append(
                {
                    "ok": False,
                    "model_name": model_name,
                    "reason": "All benchmark configurations failed.",
                }
            )
            continue

        print_final_table(all_results, baseline_name="PyTorch Baseline (FP32)")
        model_output_dir = os.path.join(args.output_dir, model_slug(model_name))
        save_summary(
            all_results,
            output_dir=model_output_dir,
            model_name=model_name,
            baseline_name="PyTorch Baseline (FP32)",
            full_pipeline=full_pipeline,
            warmup_seconds=args.warmup_seconds,
            prime_runs=args.prime_runs,
            measure_runs=args.measure_runs,
        )
        model_summaries.append(
            {
                "model_name": model_name,
                "architecture": validation["architecture"],
                "results": summarize_results(
                    all_results, baseline_name="PyTorch Baseline (FP32)"
                ),
            }
        )

    save_multi_model_summary(
        model_summaries,
        skipped_models,
        args.output_dir,
        full_pipeline=full_pipeline,
    )


if __name__ == "__main__":
    main()
