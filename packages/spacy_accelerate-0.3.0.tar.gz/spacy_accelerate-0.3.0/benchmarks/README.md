# spacy-accelerate Benchmarks

This directory contains the benchmark runner, dataset loader, and Docker-based
benchmark environment.

## Quick Start

```bash
# Install project dependencies
pip install -r requirements.txt

# Install spacy-accelerate
pip install -e .. --no-deps

# Download spaCy model
python -m spacy download en_core_web_trf

# Run benchmark
python benchmarks/benchmark.py
```

Run specific models:

```bash
python benchmarks/benchmark.py --models en_core_web_trf another_transformer_model
```

Run NER-only mode:

```bash
python benchmarks/benchmark.py --ner-only
```

## Docker

Build the image:

```bash
make build
```

Run the full benchmark suite in a GPU container and save artifacts on the host:

```bash
make benchmark
```

Run the explicit full-pipeline mode:

```bash
make benchmark-full
```

Run the transformer + NER-only mode:

```bash
make benchmark-ner-only
```

Run only selected models:

```bash
make benchmark MODELS="en_core_web_trf another_transformer_model"
```

You can also pass raw benchmark CLI flags:

```bash
make benchmark BENCHMARK_ARGS="--measure-runs 3 --prime-runs 1"
```

Each run creates a timestamped directory under `/artifacts` containing:

- `full_benchmark.log` — full console log
- `multi_model_summary.json` — aggregate machine-readable results
- `MULTI_MODEL_RESULTS.md` — aggregate markdown report
- `<model-slug>/benchmark_summary.json` — per-model structured results
- `<model-slug>/BENCHMARK_RESULTS.md` — per-model saved table

## Configuration

Edit the constants at the top of `benchmark.py`:

```python
BATCH_SIZE = 128     # Batch size for nlp.pipe()
MAX_SAMPLES = 2000   # Number of CoNLL-2003 test samples
MODEL_NAME = "en_core_web_trf"
WARMUP_SECONDS = 5.0
PRIME_RUNS = 1
MEASURE_RUNS = 3
```

Or override at runtime:

```bash
python benchmarks/benchmark.py \
  --models en_core_web_trf \
  --warmup-seconds 5 \
  --prime-runs 1 \
  --measure-runs 3
```

## Requirements

- NVIDIA GPU with CUDA 12.x
- TensorRT (see root `requirements.txt` for installation)
- `datasets` library for CoNLL-2003 loading

Canonical benchmark tables live in the root [README.md](/Users/nesergeyv/Projects/spacy-accelerate/README.md). Docker benchmark artifacts under `artifacts/benchmarks/docker/` are the source of truth.
