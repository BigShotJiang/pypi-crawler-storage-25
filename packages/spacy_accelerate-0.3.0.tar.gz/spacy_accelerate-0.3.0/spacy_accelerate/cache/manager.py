"""Cache management for ONNX models."""

import hashlib
import json
import shutil
from pathlib import Path
from typing import Any, Callable, Optional

from ..exceptions import CacheError
from .._logging import get_logger


class CacheManager:
    """
    Manages cached ONNX models for spacy-accelerate.

    The cache stores converted ONNX models to avoid re-conversion on
    subsequent loads. Models are identified by a unique key based on
    the spaCy model name, version, and precision.
    """

    def __init__(self, cache_dir: Path, verbose: bool = False):
        """
        Initialize cache manager.

        Args:
            cache_dir: Directory for storing cached models.
            verbose: Enable verbose logging.
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.logger = get_logger(verbose)

    def get_cache_key(
        self,
        nlp: Any,
        precision: str,
        fixed_batch_size: Optional[int] = None,
        provider: str = "cuda",
    ) -> str:
        """
        Generate a unique cache key for a model configuration.

        The key is based on:
        - spaCy model name
        - spaCy model version
        - Precision setting
        - Fixed batch size (if any)
        - Hash of model structure

        Args:
            nlp: spaCy Language object.
            precision: Model precision ("fp32" or "fp16").
            fixed_batch_size: Fixed batch size if used.

        Returns:
            Unique cache key string.
        """
        meta = nlp.meta

        model_info = {
            "name": meta.get("name", "unknown"),
            "version": meta.get("version", "0.0.0"),
            "precision": precision,
            "provider": provider,
            "lang": meta.get("lang", "unknown"),
            "fixed_batch_size": fixed_batch_size,
        }

        # Add structural hash from transformer model
        try:
            trf = nlp.get_pipe("transformer")
            if hasattr(trf, "model") and hasattr(trf.model, "shims"):
                shim = trf.model.shims[0]
                state_dict = shim._model.state_dict()

                # Use weight keys for structural fingerprint
                key_str = "|".join(sorted(state_dict.keys())[:20])
                model_info["structure_hash"] = hashlib.md5(
                    key_str.encode()
                ).hexdigest()[:8]

                # Add shape info from first weight
                first_key = list(state_dict.keys())[0]
                model_info["first_weight_shape"] = str(state_dict[first_key].shape)
        except Exception:
            model_info["structure_hash"] = "unknown"

        # Generate final key
        key_str = json.dumps(model_info, sort_keys=True)
        return hashlib.sha256(key_str.encode()).hexdigest()[:16]

    def get_model_dir(self, cache_key: str) -> Path:
        """
        Get the directory for a cached model.

        Args:
            cache_key: The cache key.

        Returns:
            Path to the model directory.
        """
        return self.cache_dir / cache_key

    def is_cached(self, cache_key: str, precision: str) -> bool:
        """
        Check if a model is already cached.

        Args:
            cache_key: The cache key.
            precision: Model precision.

        Returns:
            True if the model is cached and valid.
        """
        model_dir = self.get_model_dir(cache_key)

        if precision == "fp16":
            onnx_path = model_dir / "model_fp16.onnx"
        else:
            onnx_path = model_dir / "model.onnx"

        return onnx_path.exists()

    def get_onnx_path(self, cache_key: str, precision: str) -> Optional[Path]:
        """
        Get the path to a cached ONNX model.

        Args:
            cache_key: The cache key.
            precision: Model precision.

        Returns:
            Path to the ONNX model, or None if not cached.
        """
        model_dir = self.get_model_dir(cache_key)

        if precision == "fp16":
            onnx_path = model_dir / "model_fp16.onnx"
        else:
            onnx_path = model_dir / "model.onnx"

        if onnx_path.exists():
            return onnx_path
        return None

    def get_or_create(
        self,
        nlp: Any,
        shim: Any,
        precision: str,
        export_fn: Callable,
        provider: str = "cuda",
        verbose: bool = False,
        fixed_batch_size: Optional[int] = None,
    ) -> Path:
        """
        Get cached ONNX model or create it.


        Args:
            nlp: spaCy Language object.
            shim: The PyTorchShim from the transformer.
            precision: Model precision.
            export_fn: Function to export the model if not cached.
            verbose: Enable verbose logging.

        Returns:
            Path to the ONNX model.

        Raises:
            CacheError: If caching or export fails.
        """
        cache_key = self.get_cache_key(
            nlp,
            precision,
            fixed_batch_size,
            provider=provider,
        )
        model_dir = self.get_model_dir(cache_key)

        # Check if already cached
        onnx_path = self.get_onnx_path(cache_key, precision)
        if onnx_path is not None:
            self.logger.info(f"Using cached model: {onnx_path}")
            return onnx_path

        # Export model
        self.logger.info(f"Model not cached, exporting to: {model_dir}")

        try:
            onnx_path = export_fn(
                shim,
                model_dir,
                precision=precision,
                provider=provider,
                verbose=verbose,
                fixed_batch_size=fixed_batch_size,
            )
            self.logger.info(f"Export complete: {onnx_path}")
            return onnx_path
        except Exception as e:
            # Clean up partial export on failure
            if model_dir.exists():
                shutil.rmtree(model_dir, ignore_errors=True)
            raise CacheError(f"Failed to export model: {e}")

    def clear(self, cache_key: Optional[str] = None) -> int:
        """
        Clear cached models.

        Args:
            cache_key: Specific cache key to clear, or None to clear all.

        Returns:
            Number of cache entries cleared.
        """
        cleared = 0

        if cache_key is not None:
            model_dir = self.get_model_dir(cache_key)
            if model_dir.exists():
                shutil.rmtree(model_dir)
                cleared = 1
        else:
            for item in self.cache_dir.iterdir():
                if item.is_dir():
                    shutil.rmtree(item)
                    cleared += 1

        self.logger.info(f"Cleared {cleared} cache entries")
        return cleared

    def list_cached(self) -> list:
        """
        List all cached models.

        Returns:
            List of cache keys for cached models.
        """
        cached = []
        for item in self.cache_dir.iterdir():
            if item.is_dir():
                # Check if it contains an ONNX model
                if (item / "model.onnx").exists() or (
                    item / "model_fp16.onnx"
                ).exists():
                    cached.append(item.name)
        return cached

    def get_cache_size(self) -> int:
        """
        Get total size of cached models in bytes.

        Returns:
            Total cache size in bytes.
        """
        total = 0
        for item in self.cache_dir.rglob("*"):
            if item.is_file():
                total += item.stat().st_size
        return total
