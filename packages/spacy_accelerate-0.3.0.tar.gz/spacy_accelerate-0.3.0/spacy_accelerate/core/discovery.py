"""Discovery module for finding transformer components in spaCy pipelines."""

from typing import Any, Optional

from ..exceptions import ModelNotSupportedError


def find_shim(model: Any) -> Optional[Any]:
    """
    Recursively search for PyTorchShim in a thinc model.

    Args:
        model: A thinc model that may contain a PyTorchShim.

    Returns:
        The PyTorchShim if found, None otherwise.
    """
    if hasattr(model, "shims") and model.shims:
        return model.shims[0]
    if hasattr(model, "layers"):
        for layer in model.layers:
            result = find_shim(layer)
            if result is not None:
                return result
    return None


def find_transformer_shim(nlp: Any) -> Any:
    """
    Find the PyTorchShim in a spaCy transformer pipeline.

    Args:
        nlp: A spaCy Language object with a transformer component.

    Returns:
        The PyTorchShim containing the transformer model.

    Raises:
        ModelNotSupportedError: If no transformer component or PyTorchShim is found.
    """
    # Import here to avoid requiring spacy at import time
    try:
        from thinc.api import PyTorchShim
    except ImportError:
        raise ModelNotSupportedError(
            "thinc is required for spacy-accelerate. "
            "Install with: pip install thinc"
        )

    if "transformer" not in nlp.pipe_names:
        raise ModelNotSupportedError(
            f"No transformer component found in pipeline. "
            f"Available components: {nlp.pipe_names}"
        )

    trf = nlp.get_pipe("transformer")
    shim = find_shim(trf.model)

    if shim is None:
        raise ModelNotSupportedError(
            "Could not find PyTorchShim in transformer model. "
            "Ensure your model uses spacy-transformers."
        )

    if not isinstance(shim, PyTorchShim):
        raise ModelNotSupportedError(
            f"Expected PyTorchShim, got {type(shim).__name__}. "
            "This model architecture is not supported."
        )

    return shim


def get_model_info(shim: Any) -> dict:
    """
    Extract model information from a PyTorchShim.

    Args:
        shim: A PyTorchShim containing the transformer model.

    Returns:
        Dictionary with model information including:
        - architecture: Detected architecture (roberta, bert, etc.)
        - num_layers: Number of transformer layers
        - hidden_size: Hidden dimension size
        - num_heads: Number of attention heads
    """
    model = shim._model
    state_dict = model.state_dict()
    keys = list(state_dict.keys())

    info = {
        "architecture": "unknown",
        "num_layers": 0,
        "hidden_size": 768,
        "num_heads": 12,
    }

    # Detect architecture from state dict structure
    if any("curated_encoder" in k for k in keys):
        info["architecture"] = "curated_transformer"

        # Count layers
        layer_keys = [k for k in keys if "curated_encoder.layers." in k]
        if layer_keys:
            layer_nums = set()
            for k in layer_keys:
                parts = k.split(".")
                for i, p in enumerate(parts):
                    if p == "layers" and i + 1 < len(parts):
                        try:
                            layer_nums.add(int(parts[i + 1]))
                        except ValueError:
                            pass
            if layer_nums:
                info["num_layers"] = max(layer_nums) + 1

        # Get hidden size from embedding
        emb_key = "curated_encoder.embeddings.inner.word_embeddings.weight"
        if emb_key in state_dict:
            info["hidden_size"] = state_dict[emb_key].shape[1]

        # Infer num_heads from MHA weight shape
        for k in keys:
            if "mha.input.weight" in k:
                # Combined Q, K, V weight: (3 * hidden, hidden)
                weight = state_dict[k]
                if weight.shape[0] == 3 * info["hidden_size"]:
                    # Standard multi-head attention
                    # Typically hidden_size // num_heads = 64
                    info["num_heads"] = info["hidden_size"] // 64
                break

    elif any("distilbert" in k.lower() for k in keys):
        info["architecture"] = "distilbert"
    elif any("xlm" in k.lower() for k in keys):
        info["architecture"] = "xlm-roberta"
    elif any("roberta" in k.lower() for k in keys):
        info["architecture"] = "roberta"
    elif any("bert" in k.lower() and "roberta" not in k.lower() for k in keys):
        info["architecture"] = "bert"

    return info
