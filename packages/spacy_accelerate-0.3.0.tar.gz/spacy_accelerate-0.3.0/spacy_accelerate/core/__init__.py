"""Core module for spacy-accelerate."""

from .discovery import find_transformer_shim
from .patcher import patch_pipeline, restore_pipeline
from .validation import validate_pipeline

__all__ = [
    "find_transformer_shim",
    "patch_pipeline",
    "restore_pipeline",
    "validate_pipeline",
]
