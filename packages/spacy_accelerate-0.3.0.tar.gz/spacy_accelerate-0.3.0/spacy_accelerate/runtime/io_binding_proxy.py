"""IO Binding proxy for zero-copy GPU transfers.

Uses ONNX Runtime's IO Binding API to keep tensors on GPU throughout
the inference pipeline, avoiding the costly GPU→CPU→ORT→CPU→GPU roundtrip.
Supports batch bucketing for TensorRT and fixed sequence length padding.
"""

import os
import time
from typing import List, Optional

import numpy as np
import torch
import torch.nn as nn

from ..exceptions import RuntimeInitError
from .proxy_base import BaseProxy

# Suppress ONNX Runtime warnings
os.environ.setdefault("ORT_TENSORRT_LOG_LEVEL", "3")


class IOBindingProxy(BaseProxy):
    """
    ONNX Runtime proxy with IO Binding for zero-copy GPU inference.

    Uses ONNX Runtime's IO Binding API to bind GPU tensors directly,
    avoiding the CPU roundtrip (GPU→numpy→ORT→numpy→GPU). Supports
    batch bucketing to prevent TensorRT engine recompilation for
    different batch sizes, and GPU-side padding for fixed sequence lengths.
    """

    def __init__(
        self,
        onnx_path: str,
        device_id: int = 0,
        max_batch_size: int = 128,
        max_seq_length: int = 512,
        hidden_size: int = 768,
        gpu_mem_limit: int = 4 * 1024**3,  # 4GB
        warmup: bool = True,
        provider: str = "cuda",  # "cuda" or "tensorrt"
        cache_dir: Optional[str] = None,
        fp16_enable: bool = False,
        builder_optimization_level: int = 3,
        timing_cache_enable: bool = True,
        fixed_batch_size: Optional[int] = None,
        num_layers: int = 12,
        align_seq_length: int = 16,
        batch_buckets: Optional[List[int]] = None,
        fixed_seq_length: Optional[int] = None,
    ):
        super().__init__(num_layers=num_layers)

        self.onnx_path = onnx_path
        self.device_id = device_id
        self.max_batch = max_batch_size
        self.max_seq = max_seq_length
        self.hidden_size = hidden_size
        self.gpu_mem_limit = gpu_mem_limit
        self.provider = provider
        self.cache_dir = cache_dir
        self.fp16_enable = fp16_enable
        self.builder_optimization_level = builder_optimization_level
        self.timing_cache_enable = timing_cache_enable
        self.fixed_batch_size = fixed_batch_size
        self.align_seq = align_seq_length

        # Batch bucketing: pre-sorted list of batch sizes to pre-compile TRT engines for.
        # Incoming batches are padded to the nearest bucket to avoid TRT recompilation.
        self.batch_buckets = sorted(batch_buckets) if batch_buckets else None
        self.max_trt_batch = self.batch_buckets[-1] if self.batch_buckets else self.max_batch
        self.fixed_seq_length = fixed_seq_length

        self.session = None
        self.input_names = []
        self.output_names = []

        # CUDA events for profiling
        self._start_evt = None
        self._end_evt = None

        self._initialize_session(warmup=warmup)

    def __getstate__(self):
        """Exclude non-picklable ONNX session and CUDA events for nlp.to_disk()."""
        state = self.__dict__.copy()
        state["session"] = None
        state["_start_evt"] = None
        state["_end_evt"] = None
        return state

    def __setstate__(self, state):
        """Restore ONNX session and CUDA events after unpickling (nlp.from_disk())."""
        self.__dict__.update(state)
        self._initialize_session(warmup=True)

    def _initialize_session(self, warmup: bool = False):
        """Create the ONNX Runtime InferenceSession with appropriate providers."""
        import onnxruntime as ort

        sess_opts = ort.SessionOptions()
        sess_opts.log_severity_level = 3  # ERROR

        if self.provider == "tensorrt":
            from pathlib import Path

            # Use BASIC optimization to avoid fusing ops (e.g. BiasGelu) that
            # TensorRT may not support as custom plugins
            sess_opts.graph_optimization_level = (
                ort.GraphOptimizationLevel.ORT_ENABLE_BASIC
            )

            actual_cache_dir = (
                Path(self.cache_dir or Path.home() / ".cache" / "spacy-accelerate")
                / "trt_engines"
            )
            actual_cache_dir.mkdir(parents=True, exist_ok=True)

            trt_options = {
                "device_id": self.device_id,
                "trt_max_workspace_size": self.gpu_mem_limit,
                "trt_fp16_enable": self.fp16_enable,
                "trt_engine_cache_enable": True,
                "trt_engine_cache_path": str(actual_cache_dir),
                "trt_int8_enable": False,
                "trt_builder_optimization_level": self.builder_optimization_level,
                "trt_timing_cache_enable": self.timing_cache_enable,
            }

            providers = [
                ("TensorrtExecutionProvider", trt_options),
                ("CUDAExecutionProvider", {"device_id": self.device_id}),
                "CPUExecutionProvider",
            ]
        else:
            providers = [
                ("CUDAExecutionProvider", {"device_id": self.device_id}),
                "CPUExecutionProvider",
            ]

        try:
            self.session = ort.InferenceSession(
                self.onnx_path, providers=providers, sess_options=sess_opts
            )
        except Exception as e:
            raise RuntimeInitError(f"Failed to create ONNX Runtime session: {e}")

        self.input_names = [i.name for i in self.session.get_inputs()]
        self.output_names = [o.name for o in self.session.get_outputs()]

        # Create CUDA events for profiling
        if torch.cuda.is_available():
            self._start_evt = torch.cuda.Event(enable_timing=True)
            self._end_evt = torch.cuda.Event(enable_timing=True)

        if warmup:
            self._warmup()

    def _warmup(self) -> None:
        """Pre-compile TRT engines by running dummy inference for each batch bucket.

        TensorRT compiles a separate engine for each unique input shape. By running
        warmup for all expected batch sizes, we avoid compilation delays during
        actual inference.
        """
        seq_len = self.fixed_seq_length or 128

        if self.batch_buckets:
            for bucket_size in self.batch_buckets:
                dummy_ids = np.ones((bucket_size, seq_len), dtype=np.int64)
                dummy_mask = np.ones((bucket_size, seq_len), dtype=np.int64)
                self.session.run(
                    None, {"input_ids": dummy_ids, "attention_mask": dummy_mask}
                )
        else:
            dummy_ids = np.ones((1, seq_len), dtype=np.int64)
            dummy_mask = np.ones((1, seq_len), dtype=np.int64)
            self.session.run(
                None, {"input_ids": dummy_ids, "attention_mask": dummy_mask}
            )

    def _find_bucket(self, batch_size: int) -> int:
        """Find the smallest pre-compiled bucket that fits the given batch size."""
        for bucket in self.batch_buckets:
            if bucket >= batch_size:
                return bucket
        return self.max_trt_batch

    def _run_io_binding(
        self,
        input_ids_tensor: torch.Tensor,
        attention_mask_tensor: torch.Tensor,
    ) -> torch.Tensor:
        """Run inference with IO Binding — zero-copy GPU tensors.

        Instead of converting GPU tensors to numpy (GPU→CPU) and back (CPU→GPU),
        IO Binding passes GPU memory pointers directly to ONNX Runtime. The output
        tensor is pre-allocated on GPU, so the entire inference stays on-device.
        """
        binding = self.session.io_binding()

        # Bind input_ids directly from GPU memory via data_ptr()
        binding.bind_input(
            name="input_ids",
            device_type="cuda",
            device_id=self.device_id,
            element_type=np.int64,
            shape=tuple(input_ids_tensor.shape),
            buffer_ptr=input_ids_tensor.data_ptr(),
        )

        # Bind attention_mask if the model expects it
        if "attention_mask" in self.input_names:
            binding.bind_input(
                name="attention_mask",
                device_type="cuda",
                device_id=self.device_id,
                element_type=np.int64,
                shape=tuple(attention_mask_tensor.shape),
                buffer_ptr=attention_mask_tensor.data_ptr(),
            )

        # Pre-allocate output tensor on GPU (avoids device-to-host transfer)
        output_shape = (
            input_ids_tensor.shape[0],
            input_ids_tensor.shape[1],
            self.hidden_size,
        )
        output_tensor = torch.empty(
            output_shape,
            dtype=torch.float32,
            device=f"cuda:{self.device_id}",
        )

        binding.bind_output(
            name=self.output_names[0],
            device_type="cuda",
            device_id=self.device_id,
            element_type=np.float32,
            shape=tuple(output_shape),
            buffer_ptr=output_tensor.data_ptr(),
        )

        # Run inference — data stays on GPU throughout
        if self.profiling_enabled:
            torch.cuda.synchronize()
            t0 = time.perf_counter()
            self.session.run_with_iobinding(binding)
            torch.cuda.synchronize()
            self.stats["inference_ms"] += (time.perf_counter() - t0) * 1000
        else:
            self.session.run_with_iobinding(binding)

        return output_tensor

    def _forward_bucketed(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        curr_batch: int,
    ) -> torch.Tensor:
        """Run inference with batch bucketing to avoid TRT engine recompilation.

        TensorRT compiles a separate CUDA kernel for each unique input shape.
        By padding batches to the nearest pre-compiled bucket size, we reuse
        existing engines instead of triggering expensive recompilation.

        If the batch exceeds the largest bucket, it is split into chunks.
        """
        if curr_batch > self.max_trt_batch:
            # Chunk large batches that exceed the largest bucket
            all_outputs = []
            for i in range(0, curr_batch, self.max_trt_batch):
                chunk_ids = input_ids[i : i + self.max_trt_batch]
                chunk_mask = attention_mask[i : i + self.max_trt_batch]
                chunk_size = chunk_ids.shape[0]

                target = self._find_bucket(chunk_size)
                if chunk_size < target:
                    pad_batch = target - chunk_size
                    chunk_ids = nn.functional.pad(
                        chunk_ids, (0, 0, 0, pad_batch), value=0
                    )
                    chunk_mask = nn.functional.pad(
                        chunk_mask, (0, 0, 0, pad_batch), value=0
                    )

                chunk_out = self._run_io_binding(chunk_ids, chunk_mask)
                all_outputs.append(chunk_out[:chunk_size])

            return torch.cat(all_outputs, dim=0)
        else:
            # Single batch — pad to nearest bucket
            target = self._find_bucket(curr_batch)
            if curr_batch < target:
                pad_batch = target - curr_batch
                input_ids = nn.functional.pad(
                    input_ids, (0, 0, 0, pad_batch), value=0
                )
                attention_mask = nn.functional.pad(
                    attention_mask, (0, 0, 0, pad_batch), value=0
                )

            return self._run_io_binding(input_ids, attention_mask)

    @torch.no_grad()
    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        token_type_ids=None,
    ):
        """
        Run inference using IO Binding (zero-copy GPU path).

        Args:
            input_ids: Input token IDs [batch, seq_len].
            attention_mask: Attention mask [batch, seq_len].
            token_type_ids: Unused, accepted for interface compatibility.

        Returns:
            UniversalTransformerOutput with embeddings.
        """
        torch.cuda.set_device(self.device_id)

        original_batch_size = input_ids.shape[0]
        original_seq_len = input_ids.shape[1]

        # Ensure inputs are on CUDA
        if input_ids.device.type != "cuda":
            input_ids = input_ids.to(f"cuda:{self.device_id}")

        # Prepare attention mask on GPU
        if attention_mask is not None:
            if attention_mask.device.type != "cuda":
                attention_mask = attention_mask.to(f"cuda:{self.device_id}")
        else:
            # Default: 1 for real tokens, 0 for pad token ID 1 (RoBERTa convention).
            # spaCy pipelines almost always provide the mask, so this is a safety fallback.
            attention_mask = (input_ids != 1).long()

        # GPU-side sequence padding/truncation to fixed_seq_length
        if self.fixed_seq_length is not None:
            if original_seq_len < self.fixed_seq_length:
                pad_seq = self.fixed_seq_length - original_seq_len
                input_ids = nn.functional.pad(input_ids, (0, pad_seq), value=0)
                attention_mask = nn.functional.pad(
                    attention_mask, (0, pad_seq), value=0
                )
            elif original_seq_len > self.fixed_seq_length:
                input_ids = input_ids[:, : self.fixed_seq_length]
                attention_mask = attention_mask[:, : self.fixed_seq_length]

        curr_batch = input_ids.shape[0]

        # Batch bucketing path vs direct IO binding
        if self.batch_buckets:
            output_tensor = self._forward_bucketed(
                input_ids, attention_mask, curr_batch
            )
        else:
            output_tensor = self._run_io_binding(input_ids, attention_mask)

        # Slice to original shape (zero-copy GPU view)
        final_output = output_tensor[:original_batch_size, :original_seq_len, :]

        self.stats["calls"] += 1
        return self._get_transformer_output(final_output)
