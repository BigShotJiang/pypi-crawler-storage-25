"""ONNX Runtime CUDA proxy for spaCy transformers.

Uses ONNX Runtime with CUDA Execution Provider in managed mode:
data is transferred between PyTorch tensors and ONNX Runtime via numpy arrays
(GPU → CPU → ORT → CPU → GPU). For zero-copy GPU inference, use IOBindingProxy.
"""

import time
from typing import Optional

import numpy as np
import torch

from ..exceptions import RuntimeInitError
from .proxy_base import BaseProxy


class ORTProxy(BaseProxy):
    """
    ONNX Runtime CUDA Execution Provider proxy (managed mode).

    This proxy uses ONNX Runtime with CUDA for GPU-accelerated inference.
    Data is transferred between PyTorch tensors and ONNX Runtime via numpy
    arrays. For higher performance, use IOBindingProxy with use_io_binding=True.
    """

    def __init__(
        self,
        onnx_path: str,
        device_id: int = 0,
        warmup: bool = True,
    ):
        """
        Initialize ONNX Runtime CUDA proxy.

        Args:
            onnx_path: Path to the ONNX model file.
            device_id: CUDA device ID.
            warmup: Whether to run warmup inference.

        Raises:
            RuntimeInitError: If initialization fails.
        """
        super().__init__()

        self.device_id = device_id

        try:
            import onnxruntime as ort
        except ImportError:
            raise RuntimeInitError(
                "onnxruntime is required. Install with: pip install onnxruntime-gpu"
            )

        # Configure session options
        sess_opts = ort.SessionOptions()
        sess_opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        sess_opts.log_severity_level = 3  # ERROR

        # Configure CUDA provider
        providers = [
            ("CUDAExecutionProvider", {"device_id": device_id}),
            "CPUExecutionProvider",
        ]

        try:
            self.session = ort.InferenceSession(
                onnx_path,
                providers=providers,
                sess_options=sess_opts,
            )
        except Exception as e:
            raise RuntimeInitError(f"Failed to create ONNX Runtime session: {e}")

        self.input_names = [i.name for i in self.session.get_inputs()]
        self.output_names = [o.name for o in self.session.get_outputs()]

        # Warmup
        if warmup:
            self._warmup()

    def _warmup(self) -> None:
        """Run warmup inference."""
        dummy_ids = np.ones((1, 128), dtype=np.int64)
        dummy_mask = np.ones((1, 128), dtype=np.int64)
        self.session.run(None, {"input_ids": dummy_ids, "attention_mask": dummy_mask})

    @torch.no_grad()
    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        token_type_ids: Optional[torch.Tensor] = None,
    ):
        """
        Run inference using ONNX Runtime CUDA (managed mode).

        Args:
            input_ids: Input token IDs [batch, seq_len].
            attention_mask: Attention mask [batch, seq_len].
            token_type_ids: Unused, accepted for interface compatibility.

        Returns:
            UniversalTransformerOutput with embeddings.
        """
        torch.cuda.set_device(self.device_id)
        device = input_ids.device

        # 1. Device to Host: GPU tensor → numpy
        t0 = time.perf_counter()
        ids_np = input_ids.cpu().numpy().astype("int64")
        self.stats["d2h_ms"] += (time.perf_counter() - t0) * 1000

        # Prepare inputs
        ort_inputs = {"input_ids": ids_np}

        if "attention_mask" in self.input_names:
            if attention_mask is not None:
                mask_np = attention_mask.cpu().numpy().astype("int64")
            else:
                # Default: 1 for real tokens, 0 for pad token ID 1 (RoBERTa convention)
                mask_np = (ids_np != 1).astype("int64")
            ort_inputs["attention_mask"] = mask_np

        # 2. Run ONNX Runtime inference
        t0 = time.perf_counter()
        onnx_outputs = self.session.run(None, ort_inputs)
        self.stats["inference_ms"] += (time.perf_counter() - t0) * 1000

        if not onnx_outputs:
            raise RuntimeError("ONNX Runtime returned empty output")

        # 3. Host to Device: numpy → GPU tensor
        t0 = time.perf_counter()
        last_hidden = torch.from_numpy(onnx_outputs[0]).to(
            device=device, dtype=torch.float32
        )
        torch.cuda.synchronize()
        self.stats["h2d_ms"] += (time.perf_counter() - t0) * 1000

        self.stats["calls"] += 1
        return self._get_transformer_output(last_hidden)
