"""Tests for transformer architecture discovery."""

from collections import OrderedDict
from types import SimpleNamespace

from spacy_accelerate.core.discovery import get_model_info


def _shim_with_keys(*keys):
    state_dict = OrderedDict((key, SimpleNamespace(shape=(1,))) for key in keys)
    model = SimpleNamespace(state_dict=lambda: state_dict)
    return SimpleNamespace(_model=model)


def test_get_model_info_prefers_xlm_over_roberta():
    """XLM-R keys should not be misclassified as plain RoBERTa."""
    shim = _shim_with_keys(
        "xlm_roberta.embeddings.word_embeddings.weight",
        "xlm_roberta.encoder.layer.0.attention.self.query.weight",
    )

    info = get_model_info(shim)

    assert info["architecture"] == "xlm-roberta"


def test_get_model_info_prefers_distilbert_over_bert():
    """DistilBERT keys should not be misclassified as plain BERT."""
    shim = _shim_with_keys(
        "distilbert.embeddings.word_embeddings.weight",
        "distilbert.transformer.layer.0.attention.q_lin.weight",
    )

    info = get_model_info(shim)

    assert info["architecture"] == "distilbert"
