"""Tests for the main API."""

import importlib.util
from pathlib import Path
from types import SimpleNamespace

import pytest

import spacy_accelerate.api as api_module
from spacy_accelerate import OptimizeConfig, __version__, optimize
from spacy_accelerate.exceptions import ProviderNotAvailableError


SPACY_AVAILABLE = importlib.util.find_spec("spacy") is not None


def test_version():
    """Test that version is defined."""
    assert __version__ is not None
    assert isinstance(__version__, str)


def test_optimize_config_defaults():
    """Test OptimizeConfig default values."""
    config = OptimizeConfig()

    assert config.precision == "fp16"
    assert config.provider == "cuda"
    assert config.warmup is True
    assert config.device_id == 0
    assert config.max_batch_size == 128
    assert config.max_seq_length == 512
    assert config.use_io_binding is True


def test_optimize_config_validation():
    """Test OptimizeConfig validation."""
    # Invalid precision
    with pytest.raises(ValueError, match="Invalid precision"):
        OptimizeConfig(precision="fp8")

    # Invalid provider
    with pytest.raises(ValueError, match="Invalid provider"):
        OptimizeConfig(provider="tpu")

    # Invalid device_id
    with pytest.raises(ValueError, match="Invalid device_id"):
        OptimizeConfig(device_id=-1, provider="cuda")


def test_optimize_config_to_dict():
    """Test OptimizeConfig.to_dict()."""
    config = OptimizeConfig(precision="fp32", provider="cpu")
    config_dict = config.to_dict()

    assert config_dict["precision"] == "fp32"
    assert config_dict["provider"] == "cpu"
    assert "cache_dir" in config_dict


def test_optimize_config_from_dict():
    """Test OptimizeConfig.from_dict()."""
    data = {
        "precision": "fp32",
        "provider": "cpu",
        "warmup": False,
    }
    config = OptimizeConfig.from_dict(data)

    assert config.precision == "fp32"
    assert config.provider == "cpu"
    assert config.warmup is False


def test_optimize_patches_pipeline_and_warms_up(monkeypatch, temp_cache_dir):
    """optimize() should orchestrate cache, proxy creation, patching, and warmup."""

    class FakeModel:
        config = SimpleNamespace(num_hidden_layers=4, hidden_size=256)

    class FakeNLP:
        def __init__(self):
            self.meta = {"name": "en_core_web_trf", "version": "1.0.0", "lang": "en"}
            self.calls = []

        def __call__(self, text):
            self.calls.append(text)
            return text

    fake_nlp = FakeNLP()
    fake_shim = SimpleNamespace(_model=FakeModel())
    fake_proxy = object()
    onnx_path = temp_cache_dir / "model.onnx"
    onnx_path.write_text("fake")

    validate_calls = []
    cache_calls = {}
    create_proxy_calls = {}
    patch_calls = []

    def fake_validate_pipeline(nlp):
        validate_calls.append(nlp)

    def fake_get_or_create(
        self,
        *,
        nlp,
        shim,
        precision,
        export_fn,
        provider,
        verbose,
        fixed_batch_size,
    ):
        cache_calls.update(
            {
                "nlp": nlp,
                "shim": shim,
                "precision": precision,
                "export_fn": export_fn,
                "provider": provider,
                "verbose": verbose,
                "fixed_batch_size": fixed_batch_size,
                "cache_dir": self.cache_dir,
            }
        )
        return onnx_path

    def fake_create_proxy(path, config):
        create_proxy_calls.update({"path": path, "config": config})
        return fake_proxy

    def fake_patch_pipeline(shim, proxy):
        patch_calls.append((shim, proxy))

    monkeypatch.setattr(api_module, "validate_pipeline", fake_validate_pipeline)
    monkeypatch.setattr(api_module, "find_transformer_shim", lambda nlp: fake_shim)
    monkeypatch.setattr(api_module, "check_provider_available", lambda provider: True)
    monkeypatch.setattr(api_module.CacheManager, "get_or_create", fake_get_or_create)
    monkeypatch.setattr(api_module, "create_proxy", fake_create_proxy)
    monkeypatch.setattr(api_module, "patch_pipeline", fake_patch_pipeline)

    result = optimize(
        fake_nlp,
        provider="cpu",
        precision="fp32",
        cache_dir=temp_cache_dir,
        warmup=True,
        fixed_batch_size=32,
        batch_buckets=[8, 16],
    )

    assert result is fake_nlp
    assert validate_calls == [fake_nlp]
    assert cache_calls["nlp"] is fake_nlp
    assert cache_calls["shim"] is fake_shim
    assert cache_calls["precision"] == "fp32"
    assert cache_calls["provider"] == "cpu"
    assert cache_calls["fixed_batch_size"] == 32
    assert cache_calls["cache_dir"] == Path(temp_cache_dir)
    assert create_proxy_calls["path"] == onnx_path
    assert create_proxy_calls["config"].provider == "cpu"
    assert create_proxy_calls["config"].precision == "fp32"
    assert create_proxy_calls["config"].fixed_batch_size == 32
    assert create_proxy_calls["config"].num_layers == 5
    assert create_proxy_calls["config"].hidden_size == 256
    assert create_proxy_calls["config"].batch_buckets == [8, 16]
    assert patch_calls == [(fake_shim, fake_proxy)]
    assert len(fake_nlp.calls) == 1
    assert "warmup sentence" in fake_nlp.calls[0]


def test_optimize_raises_for_missing_provider(monkeypatch):
    """optimize() should raise a provider-specific error early when runtime is missing."""

    fake_nlp = SimpleNamespace(meta={"name": "en_core_web_trf", "version": "1.0.0"})
    fake_shim = SimpleNamespace(_model=SimpleNamespace())

    monkeypatch.setattr(api_module, "validate_pipeline", lambda nlp: None)
    monkeypatch.setattr(api_module, "find_transformer_shim", lambda nlp: fake_shim)
    monkeypatch.setattr(api_module, "check_provider_available", lambda provider: False)

    with pytest.raises(ProviderNotAvailableError, match="TensorRT Execution Provider"):
        optimize(fake_nlp, provider="tensorrt", precision="fp16", warmup=False)


# Integration tests require spaCy model and GPU
# These are marked as slow and skipped by default

@pytest.mark.slow
@pytest.mark.skipif(not SPACY_AVAILABLE, reason="spaCy not installed")
def test_optimize_integration():
    """Integration test for optimize function."""
    import spacy

    # This test requires en_core_web_trf model
    try:
        nlp = spacy.load("en_core_web_trf")
    except OSError:
        pytest.skip("en_core_web_trf model not installed")

    # Optimize with CPU provider (no GPU required)
    nlp = optimize(nlp, provider="cpu", precision="fp32", warmup=False)

    # Test inference
    doc = nlp("Apple Inc. was founded by Steve Jobs.")
    assert len(doc.ents) > 0
