"""Tests for spacy-accelerate."""
