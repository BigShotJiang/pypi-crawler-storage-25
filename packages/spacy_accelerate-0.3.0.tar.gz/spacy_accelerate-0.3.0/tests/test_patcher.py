"""Tests for pipeline patching helpers."""

from types import SimpleNamespace

import torch.nn as nn

from spacy_accelerate.core.patcher import is_patched, patch_pipeline, restore_pipeline


def test_patch_pipeline_preserves_original_once():
    """Repeated patching should keep the first original model for restoration."""
    shim = SimpleNamespace(_model="original-model")
    first_proxy = nn.Identity()
    second_proxy = nn.ReLU()

    patch_pipeline(shim, first_proxy)
    patch_pipeline(shim, second_proxy)

    assert shim._model is second_proxy
    assert shim._original_model == "original-model"
    assert is_patched(shim) is True


def test_restore_pipeline_reverts_to_original_model():
    """restore_pipeline() should revert the shim and clear patch metadata."""
    shim = SimpleNamespace(_model="original-model")
    proxy = nn.Identity()

    patch_pipeline(shim, proxy)

    restored = restore_pipeline(shim)

    assert restored is True
    assert shim._model == "original-model"
    assert is_patched(shim) is False


def test_restore_pipeline_is_noop_for_unpatched_shim():
    """restore_pipeline() should return False when nothing was patched."""
    shim = SimpleNamespace(_model="original-model")

    restored = restore_pipeline(shim)

    assert restored is False
    assert shim._model == "original-model"
