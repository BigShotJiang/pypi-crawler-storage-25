"""Pytest fixtures for spacy-accelerate tests."""

import importlib.util
import sys
from types import ModuleType

import pytest


if importlib.util.find_spec("torch") is None:
    class FakeTensor:
        """Minimal tensor stub used by unit tests when torch is absent."""

        def __init__(self, *shape):
            self.shape = shape


    def zeros(*shape):
        return FakeTensor(*shape)


    class Module:
        """Minimal torch.nn.Module replacement for unit tests."""

        pass


    class Identity(Module):
        pass


    class ReLU(Module):
        pass


    torch_module = ModuleType("torch")
    torch_module.Tensor = FakeTensor
    torch_module.zeros = zeros

    nn_module = ModuleType("torch.nn")
    nn_module.Module = Module
    nn_module.Identity = Identity
    nn_module.ReLU = ReLU

    torch_module.nn = nn_module

    sys.modules.setdefault("torch", torch_module)
    sys.modules.setdefault("torch.nn", nn_module)


@pytest.fixture
def sample_texts():
    """Sample texts for testing."""
    return [
        "Apple Inc. was founded by Steve Jobs in Cupertino, California.",
        "Microsoft announced a new partnership with OpenAI.",
        "The Eiffel Tower is located in Paris, France.",
    ]


@pytest.fixture
def temp_cache_dir(tmp_path):
    """Temporary cache directory for testing."""
    cache_dir = tmp_path / "spacy-accelerate-test-cache"
    cache_dir.mkdir()
    return cache_dir
