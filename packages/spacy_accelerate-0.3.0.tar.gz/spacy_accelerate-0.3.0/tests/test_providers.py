"""Tests for provider library path helpers."""

import os
from pathlib import Path

from spacy_accelerate.runtime import providers


def test_find_native_library_dirs_discovers_known_locations(tmp_path):
    """Known pip-style CUDA/TensorRT library directories are discovered."""
    root = tmp_path / "site-packages"
    (root / "tensorrt_libs").mkdir(parents=True)
    (root / "nvidia" / "cublas" / "lib").mkdir(parents=True)
    (root / "nvidia" / "cudnn" / "lib").mkdir(parents=True)

    found = providers._find_native_library_dirs([str(root)])

    assert root / "tensorrt_libs" in found
    assert root / "nvidia" / "cublas" / "lib" in found
    assert root / "nvidia" / "cudnn" / "lib" in found


def test_prepend_library_paths_deduplicates(monkeypatch, tmp_path):
    """Prepended library paths should keep order without duplicates."""
    first = tmp_path / "first"
    second = tmp_path / "second"
    first.mkdir()
    second.mkdir()

    monkeypatch.setenv("LD_LIBRARY_PATH", f"{second}:{first}")
    providers._prepend_library_paths([Path(first), Path(second)])

    assert os.environ["LD_LIBRARY_PATH"] == f"{first}:{second}"
