"""Tests for pipeline validation."""

import sys
from types import ModuleType

import pytest

from spacy_accelerate.core.validation import validate_pipeline
from spacy_accelerate.exceptions import SpacyAccelerateError


class FakeLanguage:
    """Tiny stand-in for spaCy Language used in validation tests."""

    def __init__(self, pipe_names=None):
        self.pipe_names = pipe_names or []


def install_fake_spacy(monkeypatch):
    """Install a minimal fake spacy module for validate_pipeline()."""
    fake_spacy = ModuleType("spacy")
    fake_spacy.Language = FakeLanguage
    monkeypatch.setitem(sys.modules, "spacy", fake_spacy)


def test_validate_pipeline_accepts_transformer_pipeline(monkeypatch):
    """A spaCy-like pipeline with transformer should pass validation."""
    install_fake_spacy(monkeypatch)

    validate_pipeline(FakeLanguage(pipe_names=["transformer", "ner"]))


def test_validate_pipeline_rejects_non_language(monkeypatch):
    """Non-Language objects should fail validation with a clear error."""
    install_fake_spacy(monkeypatch)

    with pytest.raises(SpacyAccelerateError, match="Expected spacy.Language"):
        validate_pipeline(object())


def test_validate_pipeline_requires_transformer_component(monkeypatch):
    """Pipelines without transformer should fail with available component list."""
    install_fake_spacy(monkeypatch)

    with pytest.raises(
        SpacyAccelerateError,
        match="Pipeline must have a 'transformer' component. Available components: tagger, ner",
    ):
        validate_pipeline(FakeLanguage(pipe_names=["tagger", "ner"]))
