"""Tests for cache management."""

from types import SimpleNamespace

import pytest

from spacy_accelerate.cache import CacheManager


def test_cache_manager_init(temp_cache_dir):
    """Test CacheManager initialization."""
    manager = CacheManager(temp_cache_dir)
    assert manager.cache_dir == temp_cache_dir
    assert temp_cache_dir.exists()


def test_cache_manager_get_model_dir(temp_cache_dir):
    """Test CacheManager.get_model_dir()."""
    manager = CacheManager(temp_cache_dir)
    model_dir = manager.get_model_dir("test_key")

    assert model_dir == temp_cache_dir / "test_key"


def test_cache_manager_is_cached_false(temp_cache_dir):
    """Test CacheManager.is_cached() returns False for missing model."""
    manager = CacheManager(temp_cache_dir)

    assert manager.is_cached("nonexistent", "fp32") is False
    assert manager.is_cached("nonexistent", "fp16") is False


def test_cache_manager_is_cached_true(temp_cache_dir):
    """Test CacheManager.is_cached() returns True for existing model."""
    manager = CacheManager(temp_cache_dir)

    # Create a fake cached model
    model_dir = temp_cache_dir / "test_key"
    model_dir.mkdir()
    (model_dir / "model.onnx").touch()

    assert manager.is_cached("test_key", "fp32") is True
    assert manager.is_cached("test_key", "fp16") is False

    # Add FP16 model
    (model_dir / "model_fp16.onnx").touch()
    assert manager.is_cached("test_key", "fp16") is True


def test_cache_manager_list_cached(temp_cache_dir):
    """Test CacheManager.list_cached()."""
    manager = CacheManager(temp_cache_dir)

    # Initially empty
    assert manager.list_cached() == []

    # Add some cached models
    for key in ["key1", "key2", "key3"]:
        model_dir = temp_cache_dir / key
        model_dir.mkdir()
        (model_dir / "model.onnx").touch()

    cached = manager.list_cached()
    assert len(cached) == 3
    assert set(cached) == {"key1", "key2", "key3"}


def test_cache_manager_clear_all(temp_cache_dir):
    """Test CacheManager.clear() clears all cache."""
    manager = CacheManager(temp_cache_dir)

    # Add some cached models
    for key in ["key1", "key2"]:
        model_dir = temp_cache_dir / key
        model_dir.mkdir()
        (model_dir / "model.onnx").touch()

    assert len(manager.list_cached()) == 2

    cleared = manager.clear()
    assert cleared == 2
    assert len(manager.list_cached()) == 0


def test_cache_manager_clear_specific(temp_cache_dir):
    """Test CacheManager.clear() clears specific key."""
    manager = CacheManager(temp_cache_dir)

    # Add some cached models
    for key in ["key1", "key2"]:
        model_dir = temp_cache_dir / key
        model_dir.mkdir()
        (model_dir / "model.onnx").touch()

    cleared = manager.clear("key1")
    assert cleared == 1
    assert manager.list_cached() == ["key2"]


def test_cache_manager_get_cache_size(temp_cache_dir):
    """Test CacheManager.get_cache_size()."""
    manager = CacheManager(temp_cache_dir)

    # Initially empty
    assert manager.get_cache_size() == 0

    # Add a file with content
    model_dir = temp_cache_dir / "test_key"
    model_dir.mkdir()
    test_file = model_dir / "model.onnx"
    test_file.write_bytes(b"x" * 1000)

    assert manager.get_cache_size() == 1000


def test_cache_key_includes_provider(temp_cache_dir):
    """Different providers should not share the same ONNX cache key."""
    manager = CacheManager(temp_cache_dir)
    nlp = SimpleNamespace(meta={"name": "en_core_web_trf", "version": "1.0.0"})

    cuda_key = manager.get_cache_key(
        nlp,
        precision="fp16",
        fixed_batch_size=128,
        provider="cuda",
    )
    tensorrt_key = manager.get_cache_key(
        nlp,
        precision="fp16",
        fixed_batch_size=128,
        provider="tensorrt",
    )

    assert cuda_key != tensorrt_key
