# Accelerating spaCy Transformer Pipelines with ONNX Runtime and TensorRT

This write-up describes what `spacy-accelerate` currently does, using the
implementation in this repository and the `en_core_web_trf-3.8.0` pipeline
configuration as the reference point.

The important distinction is architectural:

- Older spaCy transformer pipelines were commonly built around
  `spacy-transformers` and Hugging Face models.
- Current `en_core_web_trf` uses `factory = "curated_transformer"` and
  `spacy-curated-transformers.RobertaTransformer.v1`, which comes from the
  separate `spacy-curated-transformers` extension package.

This project targets the transformer submodel behind spaCy's `transformer`
pipeline component and swaps its runtime for an ONNX Runtime based proxy. The
goal is inference acceleration, not a general reimplementation of spaCy's full
transformer stack.

---

## 1. What `en_core_web_trf` Actually Looks Like

For `en_core_web_trf-3.8.0`, the pipeline config is:

```text
pipeline = ["transformer","tagger","parser","attribute_ruler","lemmatizer","ner"]
```

The transformer component is configured as:

```text
[components.transformer]
factory = "curated_transformer"
all_layer_outputs = false

[components.transformer.model]
@architectures = "spacy-curated-transformers.RobertaTransformer.v1"
```

The downstream consumers of transformer features are:

- `tagger`
- `parser`
- `ner`

All three use:

```text
@architectures = "spacy-curated-transformers.LastTransformerLayerListener.v1"
```

Two implications matter here:

- The current `en_core_web_trf` architecture is a curated-transformer pipeline,
  not a plain `spacy-transformers` + Hugging Face pipeline.
- `attribute_ruler` and the `lemmatizer` are not transformer listeners.
  The lemmatizer is configured with `mode = "rule"`, so it is not consuming
  transformer hidden states as learned features.

---

## 2. What This Project Optimizes

`spacy-accelerate.optimize()` does not replace the whole spaCy pipeline. It
replaces the model stored inside the transformer shim with an inference proxy.

At a high level, the current code does this:

1. Validate that the pipeline has a component named `transformer`.
2. Walk the thinc model tree and find the first `PyTorchShim`.
3. Inspect `shim._model.state_dict()` to detect the architecture.
4. Export an ONNX model, or reuse a cached export.
5. Create an ONNX Runtime proxy (`CPU`, `CUDA`, or `TensorRT` path).
6. Patch the shim in place:

```python
shim._original_model = shim._model
shim._model = proxy
```

Everything above that shim stays in spaCy/thinc. The tokenizer, listeners, and
downstream statistical components are left intact.

This is a narrow integration point. The current code assumes:

- a `transformer` component exists in the spaCy pipeline
- a discoverable `PyTorchShim` exists inside its thinc model
- the transformer architecture matches one of the export paths supported here

---

## 3. Current Architecture Support

Only `en_core_web_trf` has been tested end-to-end. Other spaCy English models
(`en_core_web_sm/md/lg`) are CNN/tok2vec-based and have no transformer
component — they are not compatible. Non-English transformer models have not
been validated.

Architecture detection in `spacy_accelerate/core/discovery.py` is based on
`state_dict` key patterns. The code contains export paths for `roberta`,
`bert`, and `xlm-roberta` architectures, but none of them have been tested
beyond `en_core_web_trf` (curated RoBERTa).

Two confirmed non-claims:

- `xx_ent_wiki_sm` is not a transformer/XLM-R pipeline — it should not be
  listed as a supported transformer example.
- DistilBERT is not implemented as a supported export target in the current
  code path.

---

## 4. Weight Conversion: Current Implementation

The export path in this repository does not serialize the curated transformer
module directly. Instead, it remaps weights into a Hugging Face style model,
creates a corresponding `RobertaModel` / `BertModel` / `XLMRobertaModel`, and
exports that model to ONNX.

For curated RoBERTa-style models, the mapping code currently expects keys such
as:

```text
curated_encoder.embeddings.inner.word_embeddings.weight
curated_encoder.layers.{i}.mha.input.weight
curated_encoder.layers.{i}.ffn.intermediate.weight
```

The fused QKV projection is split with `torch.chunk(...)`, then written into
literal Hugging Face-style keys such as:

```text
encoder.layer.{i}.attention.self.query.weight
encoder.layer.{i}.attention.self.key.weight
encoder.layer.{i}.attention.self.value.weight
```

That `encoder.layer.{i}...` prefix matters: it is the actual key shape used by
the current mapper.

Another detail worth stating plainly: the current implementation loads the
remapped state dict with:

```python
model.load_state_dict(state_dict, strict=False)
```

So the conversion path is intentionally permissive. At the moment, the code does
not surface `missing_keys` / `unexpected_keys` in the article or in the export
logs as a hard correctness gate.

---

## 5. ONNX Export Path

The export wrapper is intentionally minimal:

```python
class ONNXWrapper(nn.Module):
    def forward(self, input_ids, attention_mask):
        outputs = self.model(
            input_ids,
            attention_mask,
            output_hidden_states=True,
        )
        return outputs.hidden_states[-1]
```

So the ONNX graph currently exports a single tensor: the final hidden state.
This is enough for the current runtime substitution strategy, but it is not a
full export of the original curated-transformer output contract.

The exporter uses dynamic axes for batch and sequence length:

```python
dynamic_axes = {
    "input_ids": {0: "batch", 1: "seq"},
    "attention_mask": {0: "batch", 1: "seq"},
    "last_hidden_state": {0: "batch", 1: "seq"},
}
```

The current code uses a dummy batch of 2 for export. That is a project choice,
not a general rule required for dynamic batching in ONNX.

If `precision="fp16"`, the export is post-processed through the ONNX Runtime
optimizer and then converted to FP16.

---

## 6. Runtime Paths

This repository currently exposes three runtime modes:

- `provider="cpu"`
- `provider="cuda"`
- `provider="tensorrt"`

### ORTProxy

`ORTProxy` runs ONNX Runtime with the CUDA Execution Provider, but it moves data
through NumPy arrays:

```text
GPU tensor -> CPU NumPy -> ONNX Runtime -> CPU NumPy -> GPU tensor
```

That path is simple, but it includes host/device copies.

### IOBindingProxy

`IOBindingProxy` binds GPU memory pointers directly into ONNX Runtime and keeps
inputs and outputs on-device. This is the high-performance GPU path used for
CUDA and TensorRT in the current implementation.

### TensorRT via ONNX Runtime EP

The TensorRT mode here is not a raw TensorRT-only runtime. It is ONNX Runtime
with `TensorrtExecutionProvider`, followed by CUDA and CPU fallbacks:

```python
providers = [
    ("TensorrtExecutionProvider", trt_options),
    ("CUDAExecutionProvider", {"device_id": self.device_id}),
    "CPUExecutionProvider",
]
```

That distinction matters because ONNX Runtime may partition the graph and route
unsupported parts to another provider.

---

## 7. Batch Bucketing and Fixed Sequence Length

This project includes a TensorRT-oriented batching strategy in
`IOBindingProxy`:

- optional batch bucketing
- optional fixed sequence length padding/truncation
- warmup runs to populate engine caches for expected shapes

The current implementation pads incoming batches to the nearest configured
bucket and slices the output back to the original batch size.

For sequence length, `fixed_seq_length` is also a project-level runtime choice.
For `en_core_web_trf`, using `144` is motivated by the model config's
`WithStridedSpans` window:

```text
[components.transformer.model.with_spans]
stride = 104
window = 144
```

What this does **not** prove is that spaCy always produces sequences of exactly
144 tokens, or that `144 = 128 + 16 thinc overhead`. The safe statement is much
narrower: `144` matches the configured span window and is a practical fixed
shape for this project's TensorRT path.

The same caution applies to TensorRT shape handling in general. It is more
accurate to say that TensorRT performance depends on input shape ranges and
optimization profiles than to describe it as "one completely separate kernel
compile for every shape" in all cases.

---

## 8. Output Compatibility: What the Project Does Today

spaCy curated transformers expose richer structured outputs than a single final
hidden state. The current project does not reproduce that structure exactly.

Instead, `spacy-accelerate` wraps the exported tensor in a compatibility object:

```python
class UniversalTransformerOutput:
    def __init__(self, tensor, num_layers):
        self.embedding_output = tensor
        self.last_hidden_layer_state = tensor
        self.all_hidden_layer_states = [tensor for _ in range(num_layers)]
        self.layer_hidden_states = self.all_hidden_layer_states
        self.last_hidden_layer_states = self.all_hidden_layer_states
        self.all_outputs = self.all_hidden_layer_states
```

This is a deliberate approximation.

For the current `en_core_web_trf` pipeline, it lines up with the fact that
`tagger`, `parser`, and `ner` listen to the last transformer layer. But it is
still not a faithful reconstruction of the full `DocTransformerOutput` API or
semantics. In particular, it does not preserve distinct intermediate layer
states or a true embedding-layer output.

So the correct claim is:

- the current export path is designed around final-layer consumers

Not:

- the wrapper is a drop-in reproduction of every curated-transformers output
  contract

---

## 9. Benchmarking: How to Read the Numbers

This repository includes a benchmark harness in `benchmarks/benchmark.py`.
It measures:

- throughput in words per second
- entity agreement against a PyTorch baseline

Model: `en_core_web_trf` (RoBERTa-base, spaCy 3.8). GPU: NVIDIA RTX 4000 SFF
Ada Generation, CUDA 12. Dataset: CoNLL-2003 test set. Batch size: 128.
Averaged over 3 measured passes after 1 discarded warm-up pass.

### Full pipeline

All components active: tokenizer → transformer → tagger → parser →
attribute\_ruler → lemmatizer → ner.

| Configuration          | WPS    | Speedup | Accuracy |
|------------------------|--------|---------|----------|
| PyTorch FP32 (baseline)| 6,241  | 1.00×   | 100.0%   |
| PyTorch FP16 (autocast)| 6,166  | 0.99×   | 100.0%   |
| ONNX Runtime CUDA FP32 | 9,910  | 1.59×   | 99.9%    |
| ONNX Runtime CUDA FP16 | 15,763 | 2.53×   | 99.75%   |
| TensorRT FP32          | 10,552 | 1.69×   | 99.95%   |
| **TensorRT FP16**      | **16,935** | **2.71×** | **99.5%** |

### NER-only

Tagger, parser, attribute\_ruler, lemmatizer disabled.

| Configuration          | WPS    | Speedup | Accuracy |
|------------------------|--------|---------|----------|
| PyTorch FP32 (baseline)| 7,066  | 1.00×   | 100.0%   |
| PyTorch FP16 (autocast)| 6,859  | 0.97×   | 100.0%   |
| ONNX Runtime CUDA FP32 | 11,972 | 1.69×   | 99.9%    |
| ONNX Runtime CUDA FP16 | 22,394 | 3.17×   | 99.75%   |
| TensorRT FP32          | 13,138 | 1.86×   | 99.95%   |
| **TensorRT FP16**      | **24,823** | **3.51×** | **99.65%** |

NER-only speedup (3.51×) exceeds full-pipeline speedup (2.71×) because
Amdahl's law: the non-accelerated components (tagger, parser, lemmatizer) cap
the total gain in full-pipeline mode.

Those numbers are workload-specific. They depend on:

- GPU model
- batch sizes
- sequence lengths
- provider choice
- cache state
- whether the run is measuring first-build cost or steady-state inference

So benchmark tables in this project should be read as measurements for a
specific setup, not as universal claims about PyTorch, ONNX Runtime, or
TensorRT.

The same applies to numerical differences. If FP16 accuracy changes, the safe
claim is simply that the optimized path may introduce numerical drift. It is too
strong to attribute any observed gap to FP16 rounding alone without deeper
profiling and ablation.

---

## 10. Installation Notes

Two different statements need to stay separate:

- This repository is pinned to a tested CUDA 12 / TensorRT environment in
  `requirements.txt`.
- ONNX Runtime packaging changes over time, and TensorRT EP availability should
  be verified in the actual environment instead of assumed from one packaging
  rule.

For the reproducible benchmark environment of this repo, use the pinned
dependencies from `requirements.txt`.

After installation, verify the available providers:

```bash
python -m spacy_accelerate
```

That diagnostic reports whether the current environment exposes:

- `TensorrtExecutionProvider`
- `CUDAExecutionProvider`

If TensorRT EP is missing, the project currently recommends reinstalling
`onnxruntime-gpu` from NVIDIA's extra index because that is the tested path for
this repository. That recommendation should be read as a project environment
instruction, not as a universal statement about every current ONNX Runtime
wheel.

---

## 11. Current Limitations

**Inference only.** The optimized path replaces the model used for forward
execution and is not intended for training or fine-tuning.

**Output approximation.** The ONNX graph exports only the final hidden state,
and the runtime reconstructs a compatibility object rather than the exact
curated-transformers output structure.

**Narrow model support.** The current export path is implemented for
`curated_transformer`, `roberta`, `bert`, and `xlm-roberta` detection paths in
this repository. Other architectures need explicit support.

**Shim-dependent integration.** The patching strategy depends on finding a
replaceable `PyTorchShim` inside the spaCy transformer component.

**TensorRT still depends on shape management.** Engine caching, bucketing, and
fixed-shape choices matter for latency stability and startup cost.

---

## 12. Minimal Usage

```python
import spacy
import spacy_accelerate

nlp = spacy.load("en_core_web_trf")
nlp = spacy_accelerate.optimize(
    nlp,
    provider="tensorrt",
    precision="fp16",
    batch_buckets=[8, 16, 64, 128],
    fixed_seq_length=144,
)

doc = nlp("Apple Inc. was founded by Steve Jobs.")
print([(ent.text, ent.label_) for ent in doc.ents])
```

The API is intentionally small. The engineering complexity sits behind the
export, cache, provider setup, and shim patching layers described above.
